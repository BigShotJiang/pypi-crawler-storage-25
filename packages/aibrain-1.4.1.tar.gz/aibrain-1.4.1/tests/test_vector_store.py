"""
Tests for vector_store — abstracted vector storage layer.

Tests:
  1. NumpyStore: store and search returns nearest neighbor
  2. NumpyStore: delete removes entry
  3. NumpyStore: count tracks entries
  4. NumpyStore: search on empty store returns empty
  5. NumpyStore: cosine distance correctness
  6. Factory: auto-detect returns a VectorStore
  7. Factory: explicit numpy backend works
  8. Factory: unknown backend raises ValueError
  9. available_backends always includes numpy
  10. NumpyStore: search k limits results
  11. SqliteVecStore: CRUD if sqlite-vec available
"""

import math
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.vector_store import (
    NumpyStore,
    VectorStore,
    get_vector_store,
    available_backends,
    _detect_best_backend,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_vec(val: float, dim: int = 8) -> list[float]:
    """Create a simple test vector."""
    return [val] * dim


def _unit_vec(idx: int, dim: int = 8) -> list[float]:
    """Create a one-hot unit vector."""
    v = [0.0] * dim
    v[idx % dim] = 1.0
    return v


# ---------------------------------------------------------------------------
# Test 1: NumpyStore store and search
# ---------------------------------------------------------------------------

class TestNumpyStoreSearch:
    def test_nearest_neighbor(self):
        store = NumpyStore()
        # Use distinct directions so cosine distance differentiates them
        store.store(1, _unit_vec(0))
        store.store(2, _unit_vec(1))
        store.store(3, _unit_vec(2))

        # Search for something close to unit_vec(0) — should find id=1
        query = [0.9, 0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        results = store.search(query, k=2)
        assert len(results) == 2
        # Closest should be id=1 (unit_vec(0))
        assert results[0][0] == 1
        # Distance should be small
        assert results[0][1] < results[1][1]


# ---------------------------------------------------------------------------
# Test 2: NumpyStore delete
# ---------------------------------------------------------------------------

class TestNumpyStoreDelete:
    def test_delete_existing(self):
        store = NumpyStore()
        store.store(1, _make_vec(1.0))
        assert store.delete(1) is True
        assert store.count() == 0

    def test_delete_nonexistent(self):
        store = NumpyStore()
        assert store.delete(999) is False


# ---------------------------------------------------------------------------
# Test 3: NumpyStore count
# ---------------------------------------------------------------------------

class TestNumpyStoreCount:
    def test_count_tracks_entries(self):
        store = NumpyStore()
        assert store.count() == 0
        store.store(1, _make_vec(1.0))
        assert store.count() == 1
        store.store(2, _make_vec(2.0))
        assert store.count() == 2
        store.delete(1)
        assert store.count() == 1

    def test_store_overwrites(self):
        store = NumpyStore()
        store.store(1, _make_vec(1.0))
        store.store(1, _make_vec(2.0))  # overwrite
        assert store.count() == 1


# ---------------------------------------------------------------------------
# Test 4: NumpyStore search on empty
# ---------------------------------------------------------------------------

class TestNumpyStoreEmpty:
    def test_search_empty(self):
        store = NumpyStore()
        results = store.search(_make_vec(1.0), k=5)
        assert results == []


# ---------------------------------------------------------------------------
# Test 5: Cosine distance correctness
# ---------------------------------------------------------------------------

class TestCosineDistance:
    def test_identical_vectors_zero_distance(self):
        dist = NumpyStore._cosine_distance([1.0, 0.0], [1.0, 0.0])
        assert abs(dist) < 1e-6

    def test_orthogonal_vectors_distance_one(self):
        dist = NumpyStore._cosine_distance([1.0, 0.0], [0.0, 1.0])
        assert abs(dist - 1.0) < 1e-6

    def test_opposite_vectors_distance_two(self):
        dist = NumpyStore._cosine_distance([1.0, 0.0], [-1.0, 0.0])
        assert abs(dist - 2.0) < 1e-6

    def test_zero_vector_returns_max(self):
        dist = NumpyStore._cosine_distance([0.0, 0.0], [1.0, 0.0])
        assert dist == 2.0


# ---------------------------------------------------------------------------
# Test 6: Factory auto-detect
# ---------------------------------------------------------------------------

class TestFactoryAutoDetect:
    def test_auto_returns_vector_store(self):
        store = get_vector_store(backend="auto", db_path=":memory:")
        assert isinstance(store, VectorStore)
        assert store.backend_name in ("SqliteVecStore", "FaissStore", "NumpyStore")


# ---------------------------------------------------------------------------
# Test 7: Factory explicit numpy
# ---------------------------------------------------------------------------

class TestFactoryNumpy:
    def test_numpy_backend(self):
        store = get_vector_store(backend="numpy")
        assert isinstance(store, NumpyStore)
        assert store.backend_name == "NumpyStore"


# ---------------------------------------------------------------------------
# Test 8: Factory unknown backend
# ---------------------------------------------------------------------------

class TestFactoryUnknown:
    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown vector store backend"):
            get_vector_store(backend="nonexistent")


# ---------------------------------------------------------------------------
# Test 9: available_backends always includes numpy
# ---------------------------------------------------------------------------

class TestAvailableBackends:
    def test_numpy_always_available(self):
        backends = available_backends()
        assert "numpy" in backends

    def test_returns_list(self):
        backends = available_backends()
        assert isinstance(backends, list)
        assert len(backends) >= 1


# ---------------------------------------------------------------------------
# Test 10: NumpyStore search k limits results
# ---------------------------------------------------------------------------

class TestSearchKLimit:
    def test_k_limits_results(self):
        store = NumpyStore()
        for i in range(10):
            store.store(i, _make_vec(float(i)))
        results = store.search(_make_vec(5.0), k=3)
        assert len(results) == 3

    def test_k_greater_than_total(self):
        store = NumpyStore()
        store.store(1, _make_vec(1.0))
        store.store(2, _make_vec(2.0))
        results = store.search(_make_vec(1.0), k=10)
        assert len(results) == 2


# ---------------------------------------------------------------------------
# Test 11: SqliteVecStore CRUD (skip if sqlite-vec not installed)
# ---------------------------------------------------------------------------

class TestSqliteVecStore:
    @pytest.fixture
    def vec_store(self):
        try:
            from aibrain.core.vector_store import SqliteVecStore
            store = SqliteVecStore(db_path=":memory:", table="test_vec", dim=8)
            return store
        except (ImportError, Exception):
            pytest.skip("sqlite-vec not available")

    def test_store_and_search(self, vec_store):
        vec_store.store(1, _make_vec(1.0))
        vec_store.store(2, _make_vec(2.0))
        results = vec_store.search(_make_vec(1.1), k=2)
        assert len(results) == 2
        assert results[0][0] == 1  # closest

    def test_delete(self, vec_store):
        vec_store.store(1, _make_vec(1.0))
        assert vec_store.count() == 1
        assert vec_store.delete(1) is True
        assert vec_store.count() == 0

    def test_count(self, vec_store):
        assert vec_store.count() == 0
        vec_store.store(1, _make_vec(1.0))
        assert vec_store.count() == 1
