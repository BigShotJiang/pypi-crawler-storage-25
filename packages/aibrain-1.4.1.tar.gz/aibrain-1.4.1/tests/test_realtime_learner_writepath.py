"""Regression test for the Apr 10 vectorless-write bug.

Until 2026-04-10, realtime_learner.save_learnings() did raw INSERT INTO
memories without generating an embedding. Result: every memory written by
the PostToolUse hook landed in the memories table but never in
memories_vec — silently degrading semantic search.

This test verifies that EVERY memory written via save_learnings() lands
with a corresponding row in memories_vec. If anything regresses
realtime_learner back to the raw-INSERT path, this test fails immediately.

See task V97pd2lsTLU and project_aibrain_lobotomy_apr6_apr10 for the bug
class context (silent inconsistency between two writers).
"""
from __future__ import annotations

import sqlite3
import time

import pytest


def _vec_loaded_conn(db_path: str) -> sqlite3.Connection:
    import sqlite_vec
    conn = sqlite3.connect(db_path)
    conn.enable_load_extension(True)
    sqlite_vec.load(conn)
    conn.enable_load_extension(False)
    return conn


def test_save_learnings_writes_embedding():
    """A memory written via realtime_learner must have a vec row immediately."""
    import realtime_learner

    test_id = int(time.time() * 1000)
    name = f"test_writepath_regression_{test_id}"
    learnings = [{
        "name": name,
        "type": "discovery",
        "tags": "auto-extracted,test,writepath-regression",
        "content": (
            f"Regression test for V97pd2lsTLU. The realtime_learner write "
            f"path must route through aibrain_db.create_memory() so the "
            f"embedding lands with the row. Unique tag {test_id}."
        ),
        "importance": 0.5,
    }]

    saved = realtime_learner.save_learnings(learnings, mode="test")
    assert saved == 1, f"expected 1 saved, got {saved}"

    conn = _vec_loaded_conn(str(realtime_learner.DB_PATH))
    try:
        row = conn.execute(
            "SELECT id FROM memories WHERE name = ?", (name,)
        ).fetchone()
        assert row is not None, f"memory row not written for name={name}"
        mem_id = row[0]

        vec = conn.execute(
            "SELECT memory_id FROM memories_vec WHERE memory_id = ?", (mem_id,)
        ).fetchone()
        assert vec is not None, (
            f"memory id={mem_id} written but no vec row — "
            "realtime_learner regressed to raw INSERT path"
        )
    finally:
        conn.close()


def test_no_vectorless_active_memories_invariant():
    """The full DB invariant: 0 active memories without an embedding.

    This is the same check `aibrain doctor` enforces. If this test fails,
    SOME write path is bypassing the canonical writer — find it and fix it.
    """
    import realtime_learner

    conn = _vec_loaded_conn(str(realtime_learner.DB_PATH))
    try:
        vectorless = conn.execute(
            "SELECT COUNT(*) FROM memories m "
            "WHERE m.active=1 AND m.status='active' "
            "AND NOT EXISTS (SELECT 1 FROM memories_vec v WHERE v.memory_id = m.id)"
        ).fetchone()[0]
    finally:
        conn.close()

    assert vectorless == 0, (
        f"{vectorless} active memories WITHOUT embeddings — "
        "some writer is still bypassing the canonical create_memory() path. "
        "Run `aibrain doctor` and grep for raw `INSERT INTO memories`."
    )
