"""
Tests for multi_retrieval.py — Multi-strategy retrieval with RRF fusion.
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.multi_retrieval import _rrf_fuse, _prepare_fts_query, _bm25_search, _temporal_search


@pytest.fixture()
def mem_db():
    """Create a fresh in-memory DB with memories schema and sample data."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            storage_strength REAL DEFAULT 1.0,
            status TEXT DEFAULT 'active',
            valid_until TEXT
        );
        CREATE VIRTUAL TABLE memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        );
        CREATE TRIGGER memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;
    """)

    # Insert sample memories
    memories = [
        ("Deploy guide", "devops", "deploy", "How to deploy the application to production using Docker", 0.9),
        ("Python tips", "reference", "python", "Python best practices for async programming", 0.7),
        ("Bug fix log", "project", "bug", "Fixed the authentication bug in login flow", 0.5),
        ("Old config", "project", "config", "Legacy server configuration that is no longer used", 0.2),
        ("Recent deploy", "devops", "deploy", "Deployed v2.1 to staging environment today", 0.8),
    ]
    for name, mtype, tags, content, imp in memories:
        conn.execute(
            "INSERT INTO memories (name, type, tags, content, importance) VALUES (?, ?, ?, ?, ?)",
            (name, mtype, tags, content, imp),
        )
    conn.commit()
    yield conn
    conn.close()


class TestRRFFuse:
    """Tests for the core RRF fusion algorithm."""

    def test_single_list_preserves_order(self):
        """Single list fusion returns items in original order."""
        items = [{"id": 1, "name": "A"}, {"id": 2, "name": "B"}, {"id": 3, "name": "C"}]
        fused = _rrf_fuse([items], rrf_k=60, weights=[1.0], labels=["test"])
        assert [r["id"] for r in fused] == [1, 2, 3]

    def test_multi_list_boosts_shared_items(self):
        """Items appearing in multiple lists get higher RRF scores."""
        list1 = [{"id": 1, "name": "A"}, {"id": 2, "name": "B"}]
        list2 = [{"id": 2, "name": "B"}, {"id": 3, "name": "C"}]
        fused = _rrf_fuse([list1, list2], rrf_k=60, weights=[1.0, 1.0], labels=["l1", "l2"])
        # Item 2 appears in both lists, should rank highest
        assert fused[0]["id"] == 2
        assert "l1" in fused[0]["retrieval_methods"]
        assert "l2" in fused[0]["retrieval_methods"]

    def test_weights_affect_ranking(self):
        """Higher-weighted lists contribute more to RRF score."""
        list1 = [{"id": 1, "name": "A"}]
        list2 = [{"id": 2, "name": "B"}]
        # Give list2 10x weight
        fused = _rrf_fuse([list1, list2], rrf_k=60, weights=[1.0, 10.0], labels=["l1", "l2"])
        assert fused[0]["id"] == 2  # Should rank higher due to weight

    def test_rrf_score_field_present(self):
        """Each result has rrf_score and retrieval_methods fields."""
        items = [{"id": 1, "name": "A"}]
        fused = _rrf_fuse([items], rrf_k=60, weights=[1.0], labels=["test"])
        assert "rrf_score" in fused[0]
        assert "retrieval_methods" in fused[0]
        assert fused[0]["rrf_score"] > 0

    def test_empty_lists_return_empty(self):
        """Empty input lists return empty result."""
        fused = _rrf_fuse([[], []], rrf_k=60, weights=[1.0, 1.0], labels=["a", "b"])
        assert fused == []

    def test_rrf_k_parameter(self):
        """Changing rrf_k affects scores — lower k gives higher scores."""
        items_a = [{"id": 1, "name": "A"}, {"id": 2, "name": "B"}]
        items_b = [{"id": 1, "name": "A"}, {"id": 2, "name": "B"}]
        fused_low_k = _rrf_fuse([items_a], rrf_k=1, weights=[1.0], labels=["t"])
        fused_high_k = _rrf_fuse([items_b], rrf_k=200, weights=[1.0], labels=["t"])
        # k=1: score = 1/(1+0+1) = 0.5; k=200: score = 1/(200+0+1) ~ 0.005
        assert fused_low_k[0]["rrf_score"] > fused_high_k[0]["rrf_score"]


class TestBM25Search:
    """Tests for BM25/FTS5 retrieval."""

    def test_finds_matching_memories(self, mem_db):
        """BM25 search finds memories matching query terms."""
        results = _bm25_search(mem_db, "deploy production", 10)
        assert len(results) > 0
        names = [r["name"] for r in results]
        assert "Deploy guide" in names

    def test_empty_query_returns_empty(self, mem_db):
        """Empty query returns no results."""
        results = _bm25_search(mem_db, "", 10)
        assert results == []


class TestTemporalSearch:
    """Tests for temporal scoring."""

    def test_returns_results_with_temporal_score(self, mem_db):
        """Temporal search adds temporal_score to each result."""
        results = _temporal_search(mem_db, "deploy", 10)
        assert len(results) > 0
        for r in results:
            assert "temporal_score" in r
            assert r["temporal_score"] > 0

    def test_higher_importance_gets_higher_score(self, mem_db):
        """High-importance memories get higher temporal scores (all else equal)."""
        results = _temporal_search(mem_db, "", 10)
        # Deploy guide (imp=0.9) should score higher than Old config (imp=0.2)
        scores = {r["name"]: r["temporal_score"] for r in results}
        assert scores["Deploy guide"] > scores["Old config"]

    def test_stale_memories_penalized(self, mem_db):
        """Memories with valid_until set get a 0.3 penalty multiplier."""
        # Mark one memory as superseded
        mem_db.execute(
            "UPDATE memories SET valid_until = datetime('now') WHERE name = 'Old config'"
        )
        mem_db.commit()
        results = _temporal_search(mem_db, "", 10)
        scores = {r["name"]: r["temporal_score"] for r in results}
        # Old config (imp=0.2, validity=0.3) vs Python tips (imp=0.7, validity=1.0)
        assert scores["Old config"] < scores["Python tips"]


class TestPrepareFtsQuery:
    """Tests for FTS query preparation."""

    def test_wraps_terms_in_quotes(self):
        """Each word is quoted for FTS5 safety."""
        result = _prepare_fts_query("deploy production")
        assert '"deploy"' in result
        assert '"production"' in result

    def test_single_char_words_skipped(self):
        """Single character words are filtered out."""
        result = _prepare_fts_query("a deploy")
        assert '"a"' not in result
        assert '"deploy"' in result
