"""test_content_pipeline_adapter.py — tests for the adapter layer that
wires the tiered delay scheduler to decker_system/04_tools/content.

Covers:
* each concrete adapter's publish path with mocked publisher hooks
* the registry auto-wire hook
* delete_post returning False honestly (no decker_system delete path)
* end-to-end: enqueue -> scheduler tick -> adapter -> mock publish ->
  execution_log row persisted

No test in this file performs a live publish — the ``set_publisher_hook``
API is used for every call that would otherwise reach a real API, and
the transformer path runs against a disposable temp chapter file in a
tmp_path-rooted decker_system shim so the real decker_system tree is
never touched.
"""
from __future__ import annotations

import importlib
import json
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List

import pytest

from aibrain.core import content_scheduler as cs


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sandbox_db(tmp_path, monkeypatch):
    """Redirect the canonical DB resolver into tmp_path."""
    db_file = tmp_path / "aibrain.db"
    from aibrain.core import harness as _harness_mod
    monkeypatch.setattr(_harness_mod, "_get_or_create_db", lambda: db_file)
    monkeypatch.setattr(
        _harness_mod, "_find_db",
        lambda: db_file if db_file.exists() else None,
    )
    return db_file


@pytest.fixture
def fake_decker_system(tmp_path, monkeypatch):
    """Create a minimal fake ``decker_system/04_tools/content`` tree with
    stub versions of ``content_transformer.py`` and ``social_poster.py``.

    Tests that want the REAL transformer can skip this fixture; tests that
    want a fully isolated environment use this so nothing ever touches
    ``C:\\Users\\sinde\\decker_system``.
    """
    fake_root = tmp_path / "fake_decker_system"
    content_dir = fake_root / "04_tools" / "content"
    content_dir.mkdir(parents=True)

    (content_dir / "content_transformer.py").write_text(
        '''
def transform(filepath, fmt):
    return "TRANSFORMED:" + fmt + ":" + open(filepath, "r", encoding="utf-8").read()
''',
        encoding="utf-8",
    )
    (content_dir / "social_poster.py").write_text(
        '''
def load_env():
    return {}


def post_linkedin(text, env):
    return False


def post_twitter(text, env):
    return False
''',
        encoding="utf-8",
    )

    monkeypatch.setenv("DECKER_SYSTEM_ROOT", str(fake_root))
    # Force reload of adapter module so _decker_root() picks up the env var
    import aibrain.core.content_pipeline_adapter as cpa
    importlib.reload(cpa)
    return fake_root


@pytest.fixture
def captured_publisher():
    """Install a publisher hook that records every call instead of
    hitting social_poster."""
    import aibrain.core.content_pipeline_adapter as cpa
    calls: List[Dict[str, Any]] = []

    def hook(platform: str, body: str, env: Dict[str, Any]) -> Dict[str, Any]:
        calls.append({"platform": platform, "body": body, "env": env})
        return {
            "ok": True,
            "post_id": f"mock_{platform}_123",
            "note": None,
        }

    cpa.set_publisher_hook(hook)
    yield calls
    cpa.set_publisher_hook(None)


@pytest.fixture
def captured_telegram(monkeypatch):
    """Swallow Telegram notifications so tests don't ping Decker."""
    def fake_send(chat_id: int, text: str) -> bool:
        return True
    cs.set_telegram_sender(fake_send)
    yield
    cs.set_telegram_sender(None)


@pytest.fixture(autouse=True)
def _restore_registry():
    """Every test starts from a known-good registry state and restores
    it on exit so a failing test can't leak adapters into the next one.
    """
    cs._reset_registry_for_tests()
    yield
    cs._reset_registry_for_tests()


# ---------------------------------------------------------------------------
# 1. Registry auto-wire hook
# ---------------------------------------------------------------------------

def test_register_channel_adapters_installs_all_platforms(fake_decker_system):
    from aibrain.core import content_pipeline_adapter as cpa
    cs._reset_registry_for_tests()
    cpa.register_channel_adapters()
    assert cs.get_channel("linkedin") is not None
    assert cs.get_channel("twitter") is not None
    assert cs.get_channel("blog") is not None
    assert cs.get_channel("email") is not None
    assert cs.get_channel("reddit") is not None
    # Dry-run adapter remains registered alongside
    assert cs.get_channel("dry_run") is not None


def test_scheduler_import_autoloads_adapters(fake_decker_system, monkeypatch):
    """Reimport content_scheduler and confirm its module init calls the
    adapter registration hook."""
    import aibrain.core.content_scheduler as cs_mod
    importlib.reload(cs_mod)
    # After reimport, linkedin must be registered via the autoload path.
    assert cs_mod.get_channel("linkedin") is not None
    # restore shared module alias for subsequent tests
    globals()["cs"] = cs_mod


# ---------------------------------------------------------------------------
# 2. Individual adapter publish paths
# ---------------------------------------------------------------------------

def _mk_draft(draft_id: str, platform: str, body: str = "A post about agents.") -> cs.ScheduledDraft:
    now = datetime.now(timezone.utc)
    return cs.ScheduledDraft(
        draft_id=draft_id,
        tier="T1",
        title="Test",
        body=body,
        platform=platform,
        author="content_intel_agent",
        metadata={},
        queued_at=now,
        fires_at=now,
        status="queued",
    )


def test_linkedin_adapter_calls_publisher_hook(fake_decker_system, captured_publisher):
    from aibrain.core.content_pipeline_adapter import LinkedInAdapter
    adapter = LinkedInAdapter()
    draft = _mk_draft("d1", "linkedin", "Agent memory story https://myaibrain.org")
    post_id = adapter.publish(draft)
    assert len(captured_publisher) == 1
    assert captured_publisher[0]["platform"] == "linkedin"
    assert "myaibrain.org" in captured_publisher[0]["body"]
    # Mock hook returned a post_id — adapter must echo it.
    assert post_id == "mock_linkedin_123"


def test_twitter_adapter_calls_publisher_hook(fake_decker_system, captured_publisher):
    from aibrain.core.content_pipeline_adapter import TwitterAdapter
    adapter = TwitterAdapter()
    draft = _mk_draft("d2", "twitter", "Short tweet https://myaibrain.org")
    post_id = adapter.publish(draft)
    assert len(captured_publisher) == 1
    assert captured_publisher[0]["platform"] == "twitter"
    assert post_id == "mock_twitter_123"


def test_blog_adapter_produces_transformer_artifact(fake_decker_system):
    from aibrain.core.content_pipeline_adapter import BlogAdapter
    adapter = BlogAdapter()
    draft = _mk_draft("d3", "blog", "# Title\n\nBody https://myaibrain.org")
    post_id = adapter.publish(draft)
    # Blog has no live publisher — post_id is the file path of the rendered artifact.
    out_path = Path(post_id)
    assert out_path.exists(), f"expected blog artifact at {post_id}"
    content = out_path.read_text(encoding="utf-8")
    assert content.startswith("TRANSFORMED:blog:"), content[:80]


def test_email_adapter_produces_transformer_artifact(fake_decker_system):
    from aibrain.core.content_pipeline_adapter import EmailAdapter
    adapter = EmailAdapter()
    draft = _mk_draft("d4", "email", "newsletter body https://myaibrain.org")
    post_id = adapter.publish(draft)
    out_path = Path(post_id)
    assert out_path.exists(), f"expected email artifact at {post_id}"
    content = out_path.read_text(encoding="utf-8")
    assert "TRANSFORMED:email:" in content


def test_reddit_adapter_raises_not_implemented(fake_decker_system):
    from aibrain.core.content_pipeline_adapter import RedditAdapter
    adapter = RedditAdapter()
    draft = _mk_draft("d5", "reddit")
    with pytest.raises(NotImplementedError):
        adapter.publish(draft)


def test_linkedin_publisher_failure_returns_honest_null(fake_decker_system):
    """When the publisher reports ok=False, the adapter must NOT fake a
    successful post_id. It returns a dryrun-tagged string so the audit
    row surfaces the failure."""
    from aibrain.core import content_pipeline_adapter as cpa

    def failing_hook(platform: str, body: str, env: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": False, "post_id": None, "note": "credentials missing"}

    cpa.set_publisher_hook(failing_hook)
    try:
        adapter = cpa.LinkedInAdapter()
        draft = _mk_draft("d6", "linkedin", "body https://myaibrain.org")
        post_id = adapter.publish(draft)
        assert post_id.startswith("linkedin_dryrun_"), post_id
    finally:
        cpa.set_publisher_hook(None)


# ---------------------------------------------------------------------------
# 3. delete_post returns False (never fake success)
# ---------------------------------------------------------------------------

def test_all_adapters_delete_post_returns_false(fake_decker_system):
    from aibrain.core.content_pipeline_adapter import (
        BlogAdapter, EmailAdapter, LinkedInAdapter, RedditAdapter, TwitterAdapter,
    )
    for adapter_cls in (LinkedInAdapter, TwitterAdapter, BlogAdapter,
                        EmailAdapter, RedditAdapter):
        adapter = adapter_cls()
        assert adapter.delete_post("some_post_id") is False


# ---------------------------------------------------------------------------
# 4. End-to-end: enqueue -> tick -> adapter -> execution_log row
# ---------------------------------------------------------------------------

def test_end_to_end_enqueue_tick_adapter_publishes_and_logs(
    sandbox_db, fake_decker_system, captured_publisher, captured_telegram
):
    """T1 draft -> scheduler enqueue -> tick -> adapter invoked ->
    execution_log row written. Full composition integration test.
    """
    # Reimport scheduler under the sandbox_db monkeypatch so the autoload
    # adapters pick up the fake decker_system path.
    from aibrain.core import content_pipeline_adapter as cpa
    cs._reset_registry_for_tests()
    cpa.register_channel_adapters()

    draft = cs.enqueue(
        draft_id="e2e_draft_1",
        tier="T1",
        title="integration test",
        body="An integration test draft https://myaibrain.org",
        platform="linkedin",
        author="content_intel_agent",
        metadata={},
    )
    assert draft.status == "queued"

    # Tick in the future so T1's 0-delay fires_at is definitely reached.
    fired = cs.run_scheduler_tick(now=datetime.now(timezone.utc) + timedelta(seconds=1))
    assert len(fired) == 1, f"expected one fire, got {len(fired)}"
    assert fired[0].status == "published"
    assert fired[0].published_post_id == "mock_linkedin_123"

    # Publisher hook was called exactly once with the LinkedIn payload.
    assert len(captured_publisher) == 1
    assert captured_publisher[0]["platform"] == "linkedin"

    # execution_log row must exist for the content_scheduler_published action.
    db = sqlite3.connect(str(sandbox_db))
    try:
        rows = db.execute(
            """
            SELECT action, entity_id, detail
            FROM execution_log
            WHERE entity_id = ?
            ORDER BY id ASC
            """,
            ("e2e_draft_1",),
        ).fetchall()
    finally:
        db.close()

    actions = [r[0] for r in rows]
    assert "content_scheduler_enqueue" in actions
    assert "content_scheduler_published" in actions

    pub_row = next(r for r in rows if r[0] == "content_scheduler_published")
    detail = json.loads(pub_row[2])
    assert detail["platform"] == "linkedin"
    assert detail["post_id"] == "mock_linkedin_123"
    assert detail["tier"] == "T1"
