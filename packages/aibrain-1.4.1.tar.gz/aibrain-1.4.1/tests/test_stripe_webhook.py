"""Stripe webhook test coverage — previously missing (file was referenced in
test_auth_e2e.py:9 but did not exist).

Covers:
  - HMAC signature verification (good + bad signatures)
  - checkout.session.completed → per-user license_state upsert
  - subscription.deleted / invoice.payment_failed → logged, state unchanged
  - /api/checkout/portal round-trip shape
  - License key generation + refresh payload validity

All Stripe API calls are mocked. No network.
"""

import hmac
import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Signing key MUST be set before aibrain_licensing imports — no fallback.
os.environ.setdefault("AIBRAIN_SIGNING_KEY", "test-signing-key-stripe-webhook")

_TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_TMP_DB.close()
os.environ["AIBRAIN_DB"] = _TMP_DB.name
os.environ["AIBRAIN_COOKIE_INSECURE"] = "1"
os.environ.setdefault("STRIPE_WEBHOOK_SECRET", "whsec_test_dummy")
os.environ.setdefault("STRIPE_SECRET_KEY", "sk_test_dummy")

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "backend"))

import aibrain_db  # noqa: E402
import aibrain_licensing  # noqa: E402
from aibrain_payments import PaymentManager  # noqa: E402


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def user_row():
    """Insert a synthetic user and return (user_id, email)."""
    conn = aibrain_db.get_db()
    user_id = "usr_test_stripe_001"
    email = "stripe-webhook-test@example.com"
    conn.execute("DELETE FROM users WHERE id = ? OR email = ?", (user_id, email))
    conn.execute("DELETE FROM license_state WHERE user_id = ?", (user_id,))
    conn.execute(
        "INSERT INTO users (id, email, password_hash) VALUES (?, ?, 'x')",
        (user_id, email),
    )
    conn.commit()
    yield user_id, email
    conn.execute("DELETE FROM license_state WHERE user_id = ?", (user_id,))
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()


def _make_signed_payload(payload_obj, secret="whsec_test_dummy"):
    """Build a Stripe-compatible signature header for a payload dict."""
    body = json.dumps(payload_obj)
    ts = str(int(time.time()))
    signed = f"{ts}.{body}".encode()
    sig = hmac.new(secret.encode(), signed, hashlib.sha256).hexdigest()
    header = f"t={ts},v1={sig}"
    return body, header


# ---------------------------------------------------------------------------
# Item 8.1 — Signature verification
# ---------------------------------------------------------------------------

def test_webhook_signature_verification_accepts_valid():
    """A correctly-signed payload must pass verification."""
    pm = PaymentManager()
    if not pm.available:
        pytest.skip("stripe SDK not installed in test env")

    event = {
        "type": "checkout.session.completed",
        "data": {
            "object": {
                "customer_email": "test@example.com",
                "customer": "cus_test",
                "subscription": "sub_test",
                "metadata": {"tier": "pro"},
            }
        },
    }
    body, header = _make_signed_payload(event)

    with patch("stripe.Webhook.construct_event", return_value=event) as mock_ce:
        result = pm.handle_webhook(body.encode(), header)
        mock_ce.assert_called_once()

    assert result["action"] == "subscription_activated"
    assert result["data"]["tier"] == "pro"


def test_webhook_signature_verification_rejects_tampered():
    """A tampered body must fail verification."""
    pm = PaymentManager()
    if not pm.available:
        pytest.skip("stripe SDK not installed in test env")

    body = b'{"tampered": true}'
    header = "t=1,v1=deadbeef"

    def raise_bad_sig(*_a, **_kw):
        import stripe
        raise stripe.error.SignatureVerificationError(
            "Invalid signature", "sig", body
        )

    with patch("stripe.Webhook.construct_event", side_effect=raise_bad_sig):
        result = pm.handle_webhook(body, header)

    # Rejected events return {event_type: "error", action: "rejected", data: {error: ...}}
    assert result["action"] == "rejected"
    assert "error" in result.get("data", {})


# ---------------------------------------------------------------------------
# Item 8.2 — checkout.session.completed writes per-user license_state
# ---------------------------------------------------------------------------

def test_checkout_session_completed_writes_license_state(user_row):
    """_write_license_state_per_user must upsert license_state for a known user."""
    user_id, email = user_row

    # Import locally to pick up the patched AIBRAIN_DB path
    from main import _write_license_state_per_user

    _write_license_state_per_user(
        tier="pro",
        email=email,
        customer_id="cus_abc123",
        subscription_id="sub_abc123",
        license_key="PRO-fakepayload-fakesig",
        client_reference_id="",  # force email-path resolution
        raw_event_type="checkout.session.completed",
        raw_data={"tier": "pro"},
    )

    row = aibrain_db.get_db().execute(
        "SELECT tier, stripe_customer_id, stripe_subscription_id, license_key "
        "FROM license_state WHERE user_id = ?",
        (user_id,),
    ).fetchone()
    assert row is not None, "license_state row not written"
    assert row["tier"] == "pro"
    assert row["stripe_customer_id"] == "cus_abc123"
    assert row["stripe_subscription_id"] == "sub_abc123"
    assert row["license_key"].startswith("PRO-")


def test_checkout_session_unattributed_goes_to_audit_table():
    """Events with no user match must land in unattributed_license_events."""
    from main import _write_license_state_per_user

    conn = aibrain_db.get_db()
    before = conn.execute(
        "SELECT COUNT(*) FROM unattributed_license_events"
    ).fetchone()[0]

    _write_license_state_per_user(
        tier="pro",
        email="nobody-ever@example.invalid",
        customer_id="cus_unattr",
        subscription_id="sub_unattr",
        license_key="PRO-unattr-payload",
        client_reference_id="",
        raw_event_type="checkout.session.completed",
        raw_data={"tier": "pro"},
    )

    after = conn.execute(
        "SELECT COUNT(*) FROM unattributed_license_events"
    ).fetchone()[0]
    assert after == before + 1

    # Verify NO license_state row created for a nonexistent user
    count = conn.execute(
        "SELECT COUNT(*) FROM license_state WHERE stripe_customer_id = ?",
        ("cus_unattr",),
    ).fetchone()[0]
    assert count == 0


# ---------------------------------------------------------------------------
# Item 8.3 — subscription lifecycle events
# ---------------------------------------------------------------------------

def test_subscription_deleted_logs_cancellation():
    """customer.subscription.deleted must be dispatched to the cancelled handler."""
    pm = PaymentManager()
    if not pm.available:
        pytest.skip("stripe SDK not installed in test env")

    event = {
        "type": "customer.subscription.deleted",
        "data": {"object": {"id": "sub_del", "customer": "cus_del"}},
    }
    body, header = _make_signed_payload(event)
    with patch("stripe.Webhook.construct_event", return_value=event):
        result = pm.handle_webhook(body.encode(), header)
    assert result["action"] == "subscription_cancelled"
    assert result["data"]["subscription_id"] == "sub_del"


def test_invoice_payment_failed_dispatched():
    pm = PaymentManager()
    if not pm.available:
        pytest.skip("stripe SDK not installed in test env")

    event = {
        "type": "invoice.payment_failed",
        "data": {"object": {"customer": "cus_fail"}},
    }
    body, header = _make_signed_payload(event)
    with patch("stripe.Webhook.construct_event", return_value=event):
        result = pm.handle_webhook(body.encode(), header)
    assert result["action"] == "payment_failed"


# ---------------------------------------------------------------------------
# Item 8.4 — /api/checkout/portal endpoint shape
# ---------------------------------------------------------------------------

def test_billing_portal_endpoint_shape():
    """PaymentManager.create_portal_session must return a {url,id} shape."""
    pm = PaymentManager()
    if not pm.available:
        pytest.skip("stripe SDK not installed in test env")

    fake_session = MagicMock()
    fake_session.url = "https://billing.stripe.com/session/test"
    fake_session.id = "bps_test"
    with patch("stripe.billing_portal.Session.create", return_value=fake_session):
        result = pm.create_portal_session("cus_test_portal")

    assert result["url"].startswith("https://billing.stripe.com/")


# ---------------------------------------------------------------------------
# Item 8.5 — License key generation + refresh round-trip
# ---------------------------------------------------------------------------

def test_license_key_refresh_roundtrip():
    """A key generated with an expiry timestamp must validate + carry the expiry."""
    key = aibrain_licensing.generate_key(
        tier="pro",
        email="refresh-test@example.com",
        expires_at="2026-05-01T00:00:00+00:00",
        stripe_customer_id="cus_refresh",
        stripe_sub_id="sub_refresh",
    )
    validated = aibrain_licensing.validate_key(key)
    assert validated.valid is True
    assert validated.tier == "pro"
    assert validated.stripe_customer_id == "cus_refresh"
    assert validated.expires_at == "2026-05-01T00:00:00+00:00"


def test_license_key_rejects_tampered():
    key = aibrain_licensing.generate_key(
        tier="pro",
        email="tamper@example.com",
        stripe_customer_id="cus_x",
        stripe_sub_id="sub_x",
    )
    # Tamper the signature
    head, _, _sig = key.rpartition("-")
    tampered = f"{head}-0000000000000000"
    validated = aibrain_licensing.validate_key(tampered)
    assert validated.valid is False
    assert validated.tier == "free"
