"""
Tests for aibrain.integrations — LangChain, CrewAI, LangGraph adapters.

Uses mocks so langchain/crewai/langgraph are NOT required to run tests.
"""

import json
import sys
import types
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Fixture: mock Brain so we don't need a real DB
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_brain():
    """Return a MagicMock Brain with sensible defaults."""
    brain = MagicMock()
    brain.add.return_value = [{"id": 1, "memory": "test fact", "event": "ADD"}]
    brain.search.return_value = [
        {"id": 1, "memory": "User likes tennis", "score": 0.95, "reason": "semantic match"},
        {"id": 2, "memory": "User lives in Adelaide", "score": 0.80, "reason": "keyword match"},
    ]
    return brain


# ---------------------------------------------------------------------------
# LangChain adapter tests
# ---------------------------------------------------------------------------

class TestLangChainAdapter:
    """Tests for AIBrainMemory (LangChain BaseMemory subclass)."""

    def _make_adapter(self, mock_brain):
        """Create adapter with mocked Brain, faking langchain import."""
        from aibrain.integrations.langchain_adapter import AIBrainMemory

        # Bypass __new__ (which needs langchain) and construct manually
        mem = object.__new__(AIBrainMemory)
        mem._brain = mock_brain
        mem._user_id = "alice"
        mem._agent_id = None
        mem._k = 3
        mem._compress = False
        mem.memory_key = "history"
        mem.input_key = "input"
        return mem

    def test_memory_variables(self, mock_brain):
        """memory_variables returns the configured key."""
        mem = self._make_adapter(mock_brain)
        assert mem.memory_variables == ["history"]

    def test_load_memory_variables_calls_search(self, mock_brain):
        """load_memory_variables delegates to Brain.search."""
        mem = self._make_adapter(mock_brain)
        result = mem.load_memory_variables({"input": "What does Alice like?"})
        assert "history" in result
        assert "tennis" in result["history"]
        mock_brain.search.assert_called_once()

    def test_save_context_calls_add(self, mock_brain):
        """save_context stores the turn as a memory."""
        mem = self._make_adapter(mock_brain)
        mem.save_context(
            {"input": "I like chess"},
            {"output": "Great, I'll remember that!"},
        )
        mock_brain.add.assert_called_once()
        call_text = mock_brain.add.call_args[0][0]
        assert "chess" in call_text

    def test_clear_is_noop(self, mock_brain):
        """clear() does not raise or delete anything."""
        mem = self._make_adapter(mock_brain)
        mem.clear()  # Should not raise

    def test_empty_input_returns_empty_history(self, mock_brain):
        """Empty input string returns empty history without calling search."""
        mem = self._make_adapter(mock_brain)
        result = mem.load_memory_variables({"input": ""})
        assert result["history"] == ""
        mock_brain.search.assert_not_called()


# ---------------------------------------------------------------------------
# CrewAI adapter tests
# ---------------------------------------------------------------------------

class TestCrewAIAdapter:
    """Tests for AIBrainCrewMemory."""

    def _make_adapter(self, mock_brain):
        from aibrain.integrations.crewai_adapter import AIBrainCrewMemory
        mem = object.__new__(AIBrainCrewMemory)
        mem._brain = mock_brain
        mem._user_id = "crew-1"
        mem._agent_id = None
        mem._compress = False
        return mem

    def test_save_delegates_to_brain_add(self, mock_brain):
        """save() calls Brain.add with correct params."""
        mem = self._make_adapter(mock_brain)
        result = mem.save("Company founded in 2019")
        assert result[0]["event"] == "ADD"
        mock_brain.add.assert_called_once()

    def test_search_returns_results(self, mock_brain):
        """search() returns Brain.search results."""
        mem = self._make_adapter(mock_brain)
        results = mem.search("When was it founded?", limit=5)
        assert len(results) == 2
        assert results[0]["memory"] == "User likes tennis"

    def test_save_with_metadata(self, mock_brain):
        """save() passes metadata through to Brain.add."""
        mem = self._make_adapter(mock_brain)
        mem.save("fact", metadata={"source": "web"})
        _, kwargs = mock_brain.add.call_args
        assert kwargs["metadata"] == {"source": "web"}

    def test_reset_is_noop(self, mock_brain):
        """reset() does not raise."""
        mem = self._make_adapter(mock_brain)
        mem.reset()


# ---------------------------------------------------------------------------
# LangGraph adapter tests
# ---------------------------------------------------------------------------

class TestLangGraphAdapter:
    """Tests for AIBrainCheckpointStore."""

    def _make_store(self, mock_brain):
        from aibrain.integrations.langgraph_adapter import AIBrainCheckpointStore
        store = object.__new__(AIBrainCheckpointStore)
        store._brain = mock_brain
        store._user_id = "workflow-1"
        return store

    def test_put_stores_checkpoint(self, mock_brain):
        """put() calls Brain.add with serialised checkpoint data."""
        store = self._make_store(mock_brain)
        result = store.put("t1", "c1", {"step": 3, "messages": ["hi"]})
        assert result["event"] == "ADD"
        mock_brain.add.assert_called_once()
        # Verify content is valid JSON
        call_text = mock_brain.add.call_args[0][0]
        parsed = json.loads(call_text)
        assert parsed["thread_id"] == "t1"
        assert parsed["data"]["step"] == 3

    def test_get_returns_latest_checkpoint(self, mock_brain):
        """get() returns the most recent checkpoint for a thread."""
        mock_brain.search.return_value = [
            {
                "id": 1,
                "memory": json.dumps({
                    "thread_id": "t1", "checkpoint_id": "c1",
                    "ts": 1000, "data": {"step": 1},
                }),
                "score": 0.9,
            },
            {
                "id": 2,
                "memory": json.dumps({
                    "thread_id": "t1", "checkpoint_id": "c2",
                    "ts": 2000, "data": {"step": 2},
                }),
                "score": 0.85,
            },
        ]
        store = self._make_store(mock_brain)
        data = store.get("t1")
        assert data == {"step": 2}  # Most recent by ts

    def test_get_specific_checkpoint(self, mock_brain):
        """get() with checkpoint_id returns that specific checkpoint."""
        mock_brain.search.return_value = [
            {
                "id": 1,
                "memory": json.dumps({
                    "thread_id": "t1", "checkpoint_id": "c1",
                    "ts": 1000, "data": {"step": 1},
                }),
                "score": 0.9,
            },
        ]
        store = self._make_store(mock_brain)
        data = store.get("t1", checkpoint_id="c1")
        assert data == {"step": 1}

    def test_get_returns_none_when_empty(self, mock_brain):
        """get() returns None when no checkpoints exist."""
        mock_brain.search.return_value = []
        store = self._make_store(mock_brain)
        assert store.get("nonexistent") is None

    def test_list_returns_sorted_checkpoints(self, mock_brain):
        """list() returns checkpoints newest-first."""
        mock_brain.search.return_value = [
            {
                "id": 1,
                "memory": json.dumps({
                    "thread_id": "t1", "checkpoint_id": "c1",
                    "ts": 1000, "data": {"step": 1},
                }),
                "score": 0.9,
            },
            {
                "id": 2,
                "memory": json.dumps({
                    "thread_id": "t1", "checkpoint_id": "c2",
                    "ts": 2000, "data": {"step": 2},
                }),
                "score": 0.85,
            },
        ]
        store = self._make_store(mock_brain)
        cps = store.list("t1")
        assert len(cps) == 2
        assert cps[0]["checkpoint_id"] == "c2"  # Newest first
