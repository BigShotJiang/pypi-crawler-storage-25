"""
Tests for the memory consolidation workflow (sleep cycle).

Covers all 5 steps + idempotency using an isolated in-memory DB.
"""

import json
import os
import struct
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path

import pytest

# Ensure project root is on sys.path
AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AIBRAIN_ROOT))

import aibrain_db
from workflows.memory_consolidation import (
    cluster_memories,
    merge_clusters,
    decay_memories,
    archive_weak_memories,
    rebuild_category_summaries,
    run_consolidation,
    register_workflow,
    _cosine_sim_from_bytes,
    _get_active_memories,
    MIN_CLUSTER_SIZE,
    DECAY_FLOOR,
    ARCHIVE_RETENTION,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def test_db(tmp_path):
    """Create an isolated test DB with schema initialized."""
    db_path = str(tmp_path / "test_consolidation.db")
    # Point aibrain_db at our temp DB
    old_path = aibrain_db.DB_PATH
    old_conn = aibrain_db._conn
    aibrain_db.DB_PATH = Path(db_path)
    aibrain_db._conn = None

    db = aibrain_db.get_db()
    yield db

    # Restore
    try:
        db.close()
    except Exception:
        pass
    aibrain_db._conn = old_conn
    aibrain_db.DB_PATH = old_path


def _insert_memory(db, name, mem_type="project", content="", importance=0.5,
                    storage_strength=1.0, status="active", last_accessed=None,
                    updated=None, consolidated_from=None):
    """Helper to insert a test memory."""
    now = datetime.now(timezone.utc).isoformat()
    db.execute("""
        INSERT INTO memories (name, type, memory_class, tags, content, importance,
                              storage_strength, status, last_accessed, created, updated,
                              active, consolidated_from)
        VALUES (?, ?, 'semantic', '', ?, ?, ?, ?, ?, ?, ?, 1, ?)
    """, (name, mem_type, content, importance, storage_strength, status,
          last_accessed, now, updated or now, consolidated_from))
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


def _make_embedding(dim=384, seed=42):
    """Create a deterministic normalized embedding vector as bytes."""
    import math
    # Simple deterministic pseudo-random vector
    vec = [(((seed * (i + 1) * 7919) % 10000) / 10000.0 - 0.5) for i in range(dim)]
    # Normalize
    norm = math.sqrt(sum(x * x for x in vec))
    if norm > 0:
        vec = [x / norm for x in vec]
    return struct.pack(f"{dim}f", *vec)


def _insert_embedding(db, memory_id, emb_bytes):
    """Insert an embedding into memories_vec (creates table if needed)."""
    try:
        db.execute("SELECT 1 FROM memories_vec LIMIT 1")
    except sqlite3.OperationalError:
        # Create a simple table for testing (not the virtual table)
        db.execute("""
            CREATE TABLE IF NOT EXISTS memories_vec (
                memory_id INTEGER PRIMARY KEY,
                embedding BLOB
            )
        """)
    db.execute(
        "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
        (memory_id, emb_bytes),
    )
    db.commit()


# ---------------------------------------------------------------------------
# Test 1: CLUSTER — groups memories by type + similarity
# ---------------------------------------------------------------------------

class TestCluster:
    def test_cluster_groups_similar_embeddings(self, test_db):
        """Memories with identical embeddings in the same type should cluster."""
        emb = _make_embedding(dim=8, seed=1)
        ids = []
        for i in range(4):
            mid = _insert_memory(test_db, f"mem_{i}", mem_type="project",
                                 content=f"content {i}")
            _insert_embedding(test_db, mid, emb)
            ids.append(mid)

        clusters = cluster_memories(test_db)
        assert "project" in clusters
        assert len(clusters["project"]) == 1
        assert len(clusters["project"][0]) == 4

    def test_cluster_separates_different_types(self, test_db):
        """Memories of different types should not cluster together."""
        emb = _make_embedding(dim=8, seed=1)
        for i in range(3):
            mid = _insert_memory(test_db, f"proj_{i}", mem_type="project")
            _insert_embedding(test_db, mid, emb)
        for i in range(3):
            mid = _insert_memory(test_db, f"user_{i}", mem_type="user")
            _insert_embedding(test_db, mid, emb)

        clusters = cluster_memories(test_db)
        assert "project" in clusters
        assert "user" in clusters
        # Each type has its own cluster
        assert len(clusters["project"]) == 1
        assert len(clusters["user"]) == 1

    def test_cluster_skips_already_consolidated(self, test_db):
        """Memories with consolidated_from set should be excluded."""
        emb = _make_embedding(dim=8, seed=1)
        for i in range(3):
            mid = _insert_memory(test_db, f"mem_{i}", mem_type="project")
            _insert_embedding(test_db, mid, emb)
        # One already-consolidated memory
        mid = _insert_memory(test_db, "consolidated_one", mem_type="project",
                             consolidated_from="[1,2]")
        _insert_embedding(test_db, mid, emb)

        clusters = cluster_memories(test_db)
        # Should only find the 3 non-consolidated ones
        assert "project" in clusters
        assert len(clusters["project"][0]) == 3

    def test_cluster_requires_min_size(self, test_db):
        """Clusters below MIN_CLUSTER_SIZE should not appear."""
        emb1 = _make_embedding(dim=8, seed=1)
        emb2 = _make_embedding(dim=8, seed=99999)  # very different

        # 2 similar memories (below min of 3)
        for i in range(2):
            mid = _insert_memory(test_db, f"small_{i}", mem_type="project")
            _insert_embedding(test_db, mid, emb1)

        clusters = cluster_memories(test_db)
        # No clusters should be returned
        assert clusters.get("project") is None or len(clusters.get("project", [])) == 0


# ---------------------------------------------------------------------------
# Test 2: MERGE — consolidates clusters into single entries
# ---------------------------------------------------------------------------

class TestMerge:
    def test_merge_creates_consolidated_entry(self, test_db):
        """Merging a cluster should create one new memory and supersede sources."""
        emb = _make_embedding(dim=8, seed=1)
        ids = []
        for i in range(3):
            mid = _insert_memory(test_db, f"merge_{i}", mem_type="feedback",
                                 content=f"fact number {i}", importance=0.3 + i * 0.1,
                                 storage_strength=2.0)
            _insert_embedding(test_db, mid, emb)
            ids.append(mid)

        clusters = cluster_memories(test_db)
        actions = merge_clusters(test_db, clusters, dry_run=False)

        assert len(actions) == 1
        new_id = actions[0]["new_id"]

        # Check new entry exists
        new_mem = test_db.execute(
            "SELECT * FROM memories WHERE id = ?", (new_id,)
        ).fetchone()
        assert new_mem is not None
        assert new_mem["status"] == "active"
        assert json.loads(new_mem["consolidated_from"]) == ids
        # importance = max of cluster
        assert new_mem["importance"] == pytest.approx(0.5, abs=0.01)
        # storage_strength = sum, capped at 100
        assert new_mem["storage_strength"] == pytest.approx(6.0, abs=0.01)

        # Check sources are superseded
        for sid in ids:
            src = test_db.execute(
                "SELECT status, superseded_by FROM memories WHERE id = ?", (sid,)
            ).fetchone()
            assert src["status"] == "superseded"
            assert src["superseded_by"] == new_id

    def test_merge_dry_run_no_changes(self, test_db):
        """Dry run should report but not modify the DB."""
        emb = _make_embedding(dim=8, seed=1)
        ids = []
        for i in range(3):
            mid = _insert_memory(test_db, f"dry_{i}", mem_type="project",
                                 content=f"dry content {i}")
            _insert_embedding(test_db, mid, emb)
            ids.append(mid)

        clusters = cluster_memories(test_db)
        actions = merge_clusters(test_db, clusters, dry_run=True)

        assert len(actions) == 1
        assert "new_id" not in actions[0]

        # Sources should still be active
        for sid in ids:
            src = test_db.execute(
                "SELECT status FROM memories WHERE id = ?", (sid,)
            ).fetchone()
            assert src["status"] == "active"


# ---------------------------------------------------------------------------
# Test 3: DECAY — reduces storage_strength for old memories
# ---------------------------------------------------------------------------

class TestDecay:
    def test_decay_reduces_storage_strength(self, test_db):
        """Memories not accessed in 30+ days should decay."""
        old_date = (datetime.now(timezone.utc) - timedelta(days=60)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        mid = _insert_memory(
            test_db, "old_mem", mem_type="project",
            storage_strength=5.0, last_accessed=old_date,
        )

        count = decay_memories(test_db, dry_run=False)
        assert count >= 1

        row = test_db.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mid,)
        ).fetchone()
        # Should be reduced (60 days since access, so 60 * 0.05 = 3.0 decay)
        assert row["storage_strength"] < 5.0
        assert row["storage_strength"] >= DECAY_FLOOR

    def test_decay_respects_floor(self, test_db):
        """Storage strength should never go below DECAY_FLOOR."""
        old_date = (datetime.now(timezone.utc) - timedelta(days=365)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        mid = _insert_memory(
            test_db, "ancient_mem", mem_type="project",
            storage_strength=0.5, last_accessed=old_date,
        )

        decay_memories(test_db, dry_run=False)

        row = test_db.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mid,)
        ).fetchone()
        assert row["storage_strength"] == pytest.approx(DECAY_FLOOR, abs=0.01)

    def test_decay_skips_recent_memories(self, test_db):
        """Recently accessed memories should not decay."""
        recent_date = (datetime.now(timezone.utc) - timedelta(days=5)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        mid = _insert_memory(
            test_db, "recent_mem", mem_type="project",
            storage_strength=5.0, last_accessed=recent_date,
        )

        count = decay_memories(test_db, dry_run=False)

        row = test_db.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mid,)
        ).fetchone()
        assert row["storage_strength"] == pytest.approx(5.0, abs=0.01)


# ---------------------------------------------------------------------------
# Test 4: ARCHIVE — archives weak memories
# ---------------------------------------------------------------------------

class TestArchive:
    def test_archive_very_old_weak_memory(self, test_db):
        """A very old memory with low storage_strength should be archived."""
        # 2 years ago, very low storage
        old_date = (datetime.now(timezone.utc) - timedelta(days=730)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        mid = _insert_memory(
            test_db, "ancient_weak", mem_type="project",
            storage_strength=0.1, updated=old_date,
        )

        count = archive_weak_memories(test_db, dry_run=False)
        assert count >= 1

        row = test_db.execute(
            "SELECT status FROM memories WHERE id = ?", (mid,)
        ).fetchone()
        assert row["status"] == "archived"

    def test_archive_skips_strong_memories(self, test_db):
        """Memories with high storage_strength should not be archived."""
        mid = _insert_memory(
            test_db, "strong_mem", mem_type="project",
            storage_strength=50.0,
        )

        count = archive_weak_memories(test_db, dry_run=False)

        row = test_db.execute(
            "SELECT status FROM memories WHERE id = ?", (mid,)
        ).fetchone()
        assert row["status"] == "active"


# ---------------------------------------------------------------------------
# Test 5: REBUILD — regenerates category summaries
# ---------------------------------------------------------------------------

class TestRebuild:
    def test_rebuild_returns_active_categories(self, test_db):
        """Should return all distinct types from active memories."""
        _insert_memory(test_db, "cat_a", mem_type="project")
        _insert_memory(test_db, "cat_b", mem_type="user")
        _insert_memory(test_db, "cat_c", mem_type="feedback")

        categories = rebuild_category_summaries(test_db, dry_run=True)
        assert set(categories) >= {"project", "user", "feedback"}


# ---------------------------------------------------------------------------
# Test 6: IDEMPOTENCY — running twice yields same result
# ---------------------------------------------------------------------------

class TestIdempotency:
    def test_double_run_no_double_consolidation(self, test_db):
        """Running consolidation twice should not re-cluster superseded entries."""
        emb = _make_embedding(dim=8, seed=42)
        for i in range(4):
            mid = _insert_memory(test_db, f"idem_{i}", mem_type="project",
                                 content=f"idem content {i}")
            _insert_embedding(test_db, mid, emb)

        # First run
        clusters1 = cluster_memories(test_db)
        actions1 = merge_clusters(test_db, clusters1, dry_run=False)
        assert len(actions1) == 1

        # Second run — superseded entries should be excluded
        clusters2 = cluster_memories(test_db)
        # The new consolidated entry has consolidated_from set, so it's excluded too.
        # The original entries are superseded (status != 'active'), so excluded.
        # Only the new consolidated entry might appear, but it has consolidated_from.
        actions2 = merge_clusters(test_db, clusters2, dry_run=False)
        assert len(actions2) == 0

    def test_decay_idempotent_at_floor(self, test_db):
        """Decay should not reduce below floor even on repeated runs."""
        old_date = (datetime.now(timezone.utc) - timedelta(days=365)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        mid = _insert_memory(
            test_db, "floor_mem", mem_type="project",
            storage_strength=0.5, last_accessed=old_date,
        )

        decay_memories(test_db, dry_run=False)
        row1 = test_db.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mid,)
        ).fetchone()

        decay_memories(test_db, dry_run=False)
        row2 = test_db.execute(
            "SELECT storage_strength FROM memories WHERE id = ?", (mid,)
        ).fetchone()

        assert row1["storage_strength"] == pytest.approx(DECAY_FLOOR, abs=0.01)
        assert row2["storage_strength"] == pytest.approx(DECAY_FLOOR, abs=0.01)


# ---------------------------------------------------------------------------
# Test 7: REGISTER — workflow registration
# ---------------------------------------------------------------------------

class TestRegister:
    def test_register_creates_workflow(self, test_db):
        """register_workflow should insert into workflows table."""
        wf_id = register_workflow(db=test_db)
        assert wf_id is not None

        row = test_db.execute(
            "SELECT * FROM workflows WHERE name = 'memory_consolidation'"
        ).fetchone()
        assert row is not None
        assert row["enabled"] == 1
        assert row["cron_schedule"] == "0 3 * * *"

    def test_register_idempotent(self, test_db):
        """Calling register twice should return same ID."""
        id1 = register_workflow(db=test_db)
        id2 = register_workflow(db=test_db)
        assert id1 == id2


# ---------------------------------------------------------------------------
# Test 8: cosine similarity helper
# ---------------------------------------------------------------------------

class TestHelpers:
    def test_cosine_sim_identical_vectors(self):
        """Identical normalized vectors should have similarity ~1.0."""
        vec = [0.5, 0.5, 0.5, 0.5]
        norm = sum(x * x for x in vec) ** 0.5
        vec = [x / norm for x in vec]
        emb = struct.pack(f"{len(vec)}f", *vec)
        sim = _cosine_sim_from_bytes(emb, emb)
        assert sim == pytest.approx(1.0, abs=0.001)

    def test_cosine_sim_orthogonal_vectors(self):
        """Orthogonal vectors should have similarity ~0.0."""
        a = [1.0, 0.0, 0.0, 0.0]
        b = [0.0, 1.0, 0.0, 0.0]
        emb_a = struct.pack(f"{len(a)}f", *a)
        emb_b = struct.pack(f"{len(b)}f", *b)
        sim = _cosine_sim_from_bytes(emb_a, emb_b)
        assert sim == pytest.approx(0.0, abs=0.001)

    def test_cosine_sim_empty(self):
        """Empty/None bytes should return 0."""
        assert _cosine_sim_from_bytes(b"", b"") == 0.0
        assert _cosine_sim_from_bytes(None, None) == 0.0
