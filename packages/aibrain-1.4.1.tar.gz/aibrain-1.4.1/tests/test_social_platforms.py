"""
Tests for social media posting modules: Reddit, Medium, TikTok, and Comment Engager.

At least 3 tests per platform.
"""
from __future__ import annotations

import json
import os
import sys
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

# Add marketing/viral-launch to path so we can import the modules
VIRAL_DIR = str(Path(__file__).parent.parent / "marketing" / "viral-launch")
sys.path.insert(0, VIRAL_DIR)


# =========================================================================
# Reddit poster tests
# =========================================================================

class TestRedditPoster:
    """Tests for reddit_poster.py."""

    def test_has_credentials_missing(self):
        """No creds returns False."""
        from reddit_poster import has_credentials
        with patch.dict(os.environ, {}, clear=True):
            assert has_credentials() is False

    def test_has_credentials_present(self):
        """All creds present returns True."""
        from reddit_poster import has_credentials
        env = {
            "REDDIT_CLIENT_ID": "test_id",
            "REDDIT_CLIENT_SECRET": "test_secret",
            "REDDIT_USERNAME": "test_user",
            "REDDIT_PASSWORD": "test_pass",
        }
        with patch.dict(os.environ, env, clear=True):
            assert has_credentials() is True

    def test_get_credentials_returns_dict(self):
        """Credentials returned as dict with all keys."""
        from reddit_poster import get_reddit_credentials
        env = {
            "REDDIT_CLIENT_ID": "cid",
            "REDDIT_CLIENT_SECRET": "csec",
            "REDDIT_USERNAME": "user",
            "REDDIT_PASSWORD": "pass",
        }
        with patch.dict(os.environ, env, clear=True):
            creds = get_reddit_credentials()
            assert creds is not None
            assert creds["client_id"] == "cid"
            assert creds["username"] == "user"

    def test_get_credentials_missing_returns_none(self):
        """Missing creds returns None."""
        from reddit_poster import get_reddit_credentials
        with patch.dict(os.environ, {"REDDIT_CLIENT_ID": "only_one"}, clear=True):
            assert get_reddit_credentials() is None

    def test_load_markdown_post(self):
        """Load title/body from markdown file."""
        from reddit_poster import load_markdown_post

        # Create temp markdown file
        md_content = """---
title: Test
---
## r/ClaudeAI
**Title:** My Test Post
**Post:**
This is the body of my test post.
It has multiple lines.
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, dir=VIRAL_DIR) as f:
            f.write(md_content)
            f.flush()
            fname = Path(f.name).name

        try:
            result = load_markdown_post(fname, "ClaudeAI")
            assert result["title"] == "My Test Post"
            assert "body of my test post" in result["body"]
        finally:
            os.unlink(os.path.join(VIRAL_DIR, fname))

    def test_post_to_subreddit_no_creds(self):
        """Post without creds returns error dict."""
        from reddit_poster import post_to_subreddit
        with patch.dict(os.environ, {}, clear=True):
            result = post_to_subreddit("test", "title", "body")
            assert result["error"] == "credentials_not_configured"

    def test_target_subreddits_defined(self):
        """Target subreddits list is populated."""
        from reddit_poster import TARGET_SUBREDDITS
        assert len(TARGET_SUBREDDITS) >= 5
        assert "ClaudeAI" in TARGET_SUBREDDITS

    def test_search_subreddit_no_creds(self):
        """Search without creds returns empty list."""
        from reddit_poster import search_subreddit
        with patch.dict(os.environ, {}, clear=True):
            results = search_subreddit("test", "query")
            assert results == []


# =========================================================================
# Medium poster tests
# =========================================================================

class TestMediumPoster:
    """Tests for medium_poster.py."""

    def test_has_api_credentials_missing(self):
        """No token returns False."""
        from medium_poster import has_api_credentials
        with patch.dict(os.environ, {}, clear=True):
            assert has_api_credentials() is False

    def test_has_api_credentials_present(self):
        """Token present returns True."""
        from medium_poster import has_api_credentials
        with patch.dict(os.environ, {"MEDIUM_INTEGRATION_TOKEN": "tok_123"}, clear=True):
            assert has_api_credentials() is True

    def test_has_playwright_credentials(self):
        """Playwright creds check works."""
        from medium_poster import has_playwright_credentials
        with patch.dict(os.environ, {"MEDIUM_EMAIL": "test@test.com"}, clear=True):
            assert has_playwright_credentials() is True
        with patch.dict(os.environ, {}, clear=True):
            assert has_playwright_credentials() is False

    def test_load_markdown_article_with_frontmatter(self):
        """Parse article with YAML front matter."""
        from medium_poster import load_markdown_article

        md = """---
title: My Great Article
tags: AI, Python, Automation
---
This is the article body.

It has **markdown** formatting.
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False) as f:
            f.write(md)
            f.flush()
            path = f.name

        try:
            result = load_markdown_article(path)
            assert result["title"] == "My Great Article"
            assert "AI" in result["tags"]
            assert "Python" in result["tags"]
            assert "article body" in result["body"]
        finally:
            os.unlink(path)

    def test_load_markdown_article_no_frontmatter(self):
        """Parse article without front matter."""
        from medium_poster import load_markdown_article

        md = "Just a plain article body.\nNo front matter here."
        with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False) as f:
            f.write(md)
            f.flush()
            path = f.name

        try:
            result = load_markdown_article(path)
            assert result["title"] == ""
            assert "plain article body" in result["body"]
        finally:
            os.unlink(path)

    def test_post_article_no_creds(self):
        """Post without token returns error."""
        from medium_poster import post_article
        with patch.dict(os.environ, {}, clear=True):
            result = post_article("Test", "Body")
            assert result["error"] == "credentials_not_configured"


# =========================================================================
# TikTok poster tests
# =========================================================================

class TestTikTokPoster:
    """Tests for tiktok_poster.py."""

    def test_has_credentials_missing(self):
        """No TikTok creds returns False."""
        from tiktok_poster import has_credentials
        with patch.dict(os.environ, {}, clear=True):
            assert has_credentials() is False

    def test_has_credentials_present(self):
        """TikTok email present returns True."""
        from tiktok_poster import has_credentials
        with patch.dict(os.environ, {"TIKTOK_EMAIL": "test@test.com"}, clear=True):
            assert has_credentials() is True

    def test_has_session_no_file(self):
        """No session file returns False."""
        from tiktok_poster import has_session, STATE_FILE
        with patch.object(Path, "exists", return_value=False):
            # Directly check — state file unlikely to exist in test env
            if not STATE_FILE.exists():
                assert has_session() is False

    def test_state_file_path(self):
        """State file path is correct."""
        from tiktok_poster import STATE_FILE
        assert "tiktok_state.json" in str(STATE_FILE)
        assert ".playwright" in str(STATE_FILE)


# =========================================================================
# Comment engager tests
# =========================================================================

class TestCommentEngager:
    """Tests for comment_engager.py."""

    def test_score_relevance_high(self):
        """High relevance for matching keywords."""
        from comment_engager import _score_relevance
        score = _score_relevance(
            "Claude Code context window is too small",
            "I keep running into token limits with my AI agent"
        )
        assert score >= 0.5

    def test_score_relevance_low(self):
        """Low relevance for unrelated content."""
        from comment_engager import _score_relevance
        score = _score_relevance(
            "Best pizza recipe",
            "I love making pizza at home"
        )
        assert score < 0.3

    def test_select_template_context_window(self):
        """Context window topic maps to correct template."""
        from comment_engager import select_template
        key, text = select_template("My context window keeps running out")
        assert key == "context_window"  # noqa:PLAIN SECRET COMPARISON
        assert "myaibrain.org" in text

    def test_select_template_memory(self):
        """Memory topic maps to correct template."""
        from comment_engager import select_template
        key, text = select_template("AI agent persistent memory solutions")
        assert key == "agent_memory"  # noqa:PLAIN SECRET COMPARISON
        assert "myaibrain.org" in text

    def test_select_template_token(self):
        """Token topic maps to correct template."""
        from comment_engager import select_template
        key, text = select_template("How to reduce token costs")
        assert key == "token_limits"  # noqa:PLAIN SECRET COMPARISON

    def test_select_template_workflow(self):
        """Workflow topic maps to correct template."""
        from comment_engager import select_template
        key, text = select_template("AI workflow automation pipeline")
        assert key == "workflow_automation"

    def test_select_template_general(self):
        """Unknown topic falls back to general."""
        from comment_engager import select_template
        key, text = select_template("Something completely different about AI")
        assert key == "general_helpful"
        assert "myaibrain.org" in text

    def test_draft_comment(self):
        """Draft comment returns correct structure."""
        from comment_engager import draft_comment

        # Use temp DB to avoid polluting real one
        with patch("comment_engager._DB_PATH", Path(tempfile.mktemp(suffix=".db"))):
            result = draft_comment({
                "platform": "reddit",
                "post_id": "t3_test123",
                "title": "Context window problems with Claude",
                "selftext_preview": "I keep running out of context",
            })
            assert result["platform"] == "reddit"
            assert result["post_id"] == "t3_test123"
            assert result["template_used"] == "context_window"
            assert "myaibrain.org" in result["comment_text"]

    def test_daily_comment_count(self):
        """Daily count starts at 0 on fresh DB."""
        from comment_engager import get_daily_comment_count, ensure_engagement_table

        tmp_db = Path(tempfile.mktemp(suffix=".db"))
        with patch("comment_engager._DB_PATH", tmp_db):
            count = get_daily_comment_count("reddit")
            assert count == 0
        if tmp_db.exists():
            tmp_db.unlink()

    def test_engagement_stats(self):
        """Stats returns dict with all platforms."""
        from comment_engager import get_engagement_stats

        tmp_db = Path(tempfile.mktemp(suffix=".db"))
        with patch("comment_engager._DB_PATH", tmp_db):
            stats = get_engagement_stats()
            assert "reddit" in stats
            assert "x" in stats
            assert "linkedin" in stats
            assert stats["reddit"]["remaining_today"] == 5
        if tmp_db.exists():
            tmp_db.unlink()

    def test_rate_limit_constant(self):
        """Rate limit is 5 per platform per day."""
        from comment_engager import MAX_COMMENTS_PER_PLATFORM_PER_DAY
        assert MAX_COMMENTS_PER_PLATFORM_PER_DAY == 5

    def test_search_topics_defined(self):
        """Search topics list is populated."""
        from comment_engager import SEARCH_TOPICS
        assert len(SEARCH_TOPICS) >= 5

    def test_target_subreddits_defined(self):
        """Target subreddits for engagement are defined."""
        from comment_engager import TARGET_SUBREDDITS
        assert len(TARGET_SUBREDDITS) >= 5
        assert "ClaudeAI" in TARGET_SUBREDDITS

    def test_all_templates_have_link(self):
        """Every comment template mentions myaibrain.org."""
        from comment_engager import COMMENT_TEMPLATES
        for key, text in COMMENT_TEMPLATES.items():
            assert "myaibrain.org" in text, f"Template '{key}' missing myaibrain.org link"

    def test_find_engagement_opportunities_unknown_platform(self):
        """Unknown platform returns empty list."""
        from comment_engager import find_engagement_opportunities
        result = find_engagement_opportunities("fakebook")
        assert result == []

    def test_post_reddit_comment_no_creds(self):
        """Post comment without creds returns error."""
        from comment_engager import post_reddit_comment

        tmp_db = Path(tempfile.mktemp(suffix=".db"))
        with patch("comment_engager._DB_PATH", tmp_db):
            with patch.dict(os.environ, {}, clear=True):
                result = post_reddit_comment("t3_test", "test comment")
                assert "error" in result
        if tmp_db.exists():
            tmp_db.unlink()
