"""
test_mcp_server.py — smoke test for aibrain.mcp.server (HTTP JSON-RPC).

Spins up the server on an ephemeral port against an isolated temp DB,
runs initialize → tools/list → tools/call, and verifies:
  * auth required when a token is set
  * correct JSON-RPC envelope
  * real tool dispatch (memory_store → memory_stats round-trip)
  * honest-rubric: memory_ingest returns null content when the optional
    conversation_observer module is not available OR a proper dict when it is.
"""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest


# Reuse the session-scoped mcp_db fixture from conftest — it points mcp_server
# at a temp DB and skips embeddings so tests stay fast.

@pytest.fixture
def running_server(mcp_db):
    """Start aibrain.mcp.server on an ephemeral port, yield (base_url, token)."""
    from aibrain.mcp import server as mcp_srv

    token = "test-token-abc123"
    # Bind port 0 → kernel picks an ephemeral free port.
    srv = mcp_srv.build_server("127.0.0.1", 0, token, db_path=Path(mcp_db))
    host, port = srv.server_address
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()

    # Tight wait-for-ready loop — the serve_forever thread is up instantly
    # but we want to catch binding failures before tests run.
    base = f"http://{host}:{port}"
    deadline = time.time() + 3.0
    while time.time() < deadline:
        try:
            urllib.request.urlopen(base + "/health", timeout=0.5)
            break
        except Exception:
            time.sleep(0.05)
    else:
        srv.shutdown()
        srv.server_close()
        raise RuntimeError("MCP server did not come up in time")

    try:
        yield base, token
    finally:
        srv.shutdown()
        srv.server_close()


def _rpc(base_url: str, token: str | None, method: str, params: dict | None = None,
         req_id: int = 1):
    body = json.dumps({
        "jsonrpc": "2.0",
        "id": req_id,
        "method": method,
        "params": params or {},
    }).encode()
    headers = {"Content-Type": "application/json"}
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(base_url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=5) as resp:
        return resp.status, json.loads(resp.read().decode())


# ---------------------------------------------------------------------------
# Health / auth
# ---------------------------------------------------------------------------

def test_health_no_auth_required(running_server):
    base, _ = running_server
    with urllib.request.urlopen(base + "/health", timeout=2) as resp:
        payload = json.loads(resp.read().decode())
    assert payload["status"] == "ok"
    assert payload["server"] == "aibrain-memory"
    assert payload["contract"] == "1.0.0"
    assert payload["auth_required"] is True


def test_auth_required(running_server):
    base, _ = running_server
    # No token → 401.
    with pytest.raises(urllib.error.HTTPError) as ei:
        _rpc(base, token=None, method="tools/list")
    assert ei.value.code == 401


# ---------------------------------------------------------------------------
# Protocol handshake
# ---------------------------------------------------------------------------

def test_initialize(running_server):
    base, token = running_server
    status, payload = _rpc(base, token, "initialize")
    assert status == 200
    assert payload["jsonrpc"] == "2.0"
    assert payload["id"] == 1
    result = payload["result"]
    assert result["protocolVersion"] == "2024-11-05"
    assert result["serverInfo"]["name"] == "aibrain-memory"
    assert result["serverInfo"]["version"] == "1.0.0"


def test_tools_list_has_six_memory_tools(running_server):
    base, token = running_server
    status, payload = _rpc(base, token, "tools/list")
    assert status == 200
    names = {t["name"] for t in payload["result"]["tools"]}
    expected = {
        "memory_store",
        "memory_search",
        "memory_recall",
        "memory_stats",
        "memory_ingest",
        "memory_prepare",
    }
    assert expected.issubset(names), f"missing tools: {expected - names}"


# ---------------------------------------------------------------------------
# tools/call round-trip
# ---------------------------------------------------------------------------

def _call_tool(base, token, name, arguments):
    _, payload = _rpc(base, token, "tools/call",
                      {"name": name, "arguments": arguments})
    assert "result" in payload, payload
    content = payload["result"]["content"][0]
    assert content["type"] == "text"
    return json.loads(content["text"])


def test_store_then_stats_roundtrip(running_server):
    base, token = running_server

    store_result = _call_tool(base, token, "memory_store", {
        "name": "mcp_server_smoke_test",
        "content": "This memory was stored via the aibrain.mcp.server HTTP endpoint.",
        "type": "reference",
        "importance": 0.7,
    })
    assert store_result["action"] in {"added", "updated", "none"}
    assert isinstance(store_result.get("id"), int)

    stats = _call_tool(base, token, "memory_stats", {})
    assert stats["total_memories"] >= 1
    assert isinstance(stats["by_type"], dict)
    assert "db_path" in stats
    # Honest-rubric: embeddings are explicitly disabled in the fixture, so
    # embeddings_enabled MUST be False, not faked true.
    assert stats["embeddings_enabled"] is False


def test_search_returns_stored_memory(running_server):
    base, token = running_server
    _call_tool(base, token, "memory_store", {
        "name": "searchable_unique_beacon_zxq",
        "content": "The unique beacon phrase zxq42 lives here for search recall.",
    })
    results = _call_tool(base, token, "memory_search", {
        "query": "zxq42 beacon",
        "limit": 5,
    })
    assert isinstance(results, list)
    # Honest-rubric: an empty result set is a legitimate outcome, not a fake
    # hit. We assert the envelope is a list and, if non-empty, rows have ids.
    for row in results:
        assert "id" in row


def test_invalid_tool_returns_method_not_found(running_server):
    base, token = running_server
    _, payload = _rpc(base, token, "tools/call",
                      {"name": "does_not_exist", "arguments": {}})
    assert "error" in payload
    assert payload["error"]["code"] == -32601


def test_missing_required_argument_returns_invalid_params(running_server):
    base, token = running_server
    _, payload = _rpc(base, token, "tools/call",
                      {"name": "memory_search", "arguments": {}})
    assert "error" in payload
    assert payload["error"]["code"] == -32602
