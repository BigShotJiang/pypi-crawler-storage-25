"""test_workflow_runner_routing.py — integration tests for SelRoute v3 wiring.

Verifies that workflow_runner.run_workflow() correctly:
  - Skips routing when v3_task_type=None (backward compatible)
  - Calls agent_router.route() when v3_task_type is provided
  - Replaces the workflow action with superworker.invoke() when shape == "superworker"
  - Calls agent_router.record_outcome() after the harness returns
  - Falls back to direct execution when routing raises

These tests MOCK both agent_router and superworker — no real LLM calls, no
real harness execution. The point is to verify the wiring contract, not the
behavior of the underlying modules (which have their own tests).
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from aibrain.core import workflow_runner
from aibrain.core.harness import HarnessResult


def _mk_harness_result(quality=0.8, success=True):
    return HarnessResult(
        success=success,
        output={"_cost_cents": 5, "_model_used": "claude-sonnet-4"},
        quality=quality,
        cost_cents=5,
        model_used="claude-sonnet-4",
        duration_ms=100,
    )


def _mk_route_decision(shape="superworker", lens_set=("Systems Architect", "Operator Lens")):
    """Build a fake RouteDecision shape that matches agent_router.RouteDecision."""
    from aibrain.core.agent_router import RouteDecision, SUPERWORKER, SPECIALIST
    if shape == SUPERWORKER:
        return RouteDecision(
            handler_shape=SUPERWORKER,
            task_type="code_review",
            routing_reason="test",
            model_recommendation="sonnet",
            confidence=0.85,
            override_mode="auto",
            lens_set=tuple(lens_set),
        )
    return RouteDecision(
        handler_shape=SPECIALIST,
        task_type="security_review",
        routing_reason="test",
        model_recommendation="sonnet",
        confidence=0.85,
        override_mode="auto",
        agent_name="Security Engineer",
    )


# --- Backward compatibility -------------------------------------------------

def test_run_workflow_no_v3_task_type_skips_routing(monkeypatch, tmp_path):
    """When v3_task_type is None (default), agent_router.route is NEVER called."""
    # Make a fake workflow file the runner can find
    wf_dir = tmp_path / "workflows"
    wf_dir.mkdir()
    (wf_dir / "fake_wf.py").write_text("def run(): return {'ok': True}\n")
    monkeypatch.setattr(workflow_runner, "WORKFLOW_DIR", wf_dir)

    fake_route = MagicMock()
    fake_record = MagicMock()
    monkeypatch.setattr("aibrain.core.agent_router.route", fake_route)
    monkeypatch.setattr("aibrain.core.agent_router.record_outcome", fake_record)

    fake_execute = MagicMock(return_value=_mk_harness_result())
    monkeypatch.setattr(workflow_runner, "execute", fake_execute)

    result = workflow_runner.run_workflow("fake_wf")

    assert result.success is True
    fake_route.assert_not_called()
    fake_record.assert_not_called()


# --- Routing call -----------------------------------------------------------

def test_run_workflow_v3_task_type_calls_route(monkeypatch, tmp_path):
    """When v3_task_type is set, agent_router.route is called once with right kwargs."""
    wf_dir = tmp_path / "workflows"
    wf_dir.mkdir()
    (wf_dir / "fake_wf.py").write_text("def run(): return {'ok': True}\n")
    monkeypatch.setattr(workflow_runner, "WORKFLOW_DIR", wf_dir)

    decision = _mk_route_decision(shape="specialist")
    fake_route = MagicMock(return_value=decision)
    fake_record = MagicMock()
    monkeypatch.setattr("aibrain.core.agent_router.route", fake_route)
    monkeypatch.setattr("aibrain.core.agent_router.record_outcome", fake_record)

    fake_execute = MagicMock(return_value=_mk_harness_result())
    monkeypatch.setattr(workflow_runner, "execute", fake_execute)

    workflow_runner.run_workflow("fake_wf", v3_task_type="security_review", actor="test")

    fake_route.assert_called_once()
    _, kwargs = fake_route.call_args
    assert kwargs["task_type"] == "security_review"
    assert kwargs["task_description"] == "fake_wf"
    assert kwargs["actor"] == "test"


# --- Action substitution for superworker ------------------------------------

def test_run_workflow_v3_superworker_replaces_action(monkeypatch, tmp_path):
    """When shape == superworker, the action passed to harness must be the
    SuperWorker invoke wrapper, NOT the workflow's own run() function."""
    wf_dir = tmp_path / "workflows"
    wf_dir.mkdir()
    # The workflow itself returns a sentinel — if it gets called, the test fails
    (wf_dir / "fake_wf.py").write_text(
        "WORKFLOW_RAN = False\n"
        "def run():\n"
        "    global WORKFLOW_RAN\n"
        "    WORKFLOW_RAN = True\n"
        "    return {'ok': True, 'sentinel': 'workflow_ran'}\n"
    )
    monkeypatch.setattr(workflow_runner, "WORKFLOW_DIR", wf_dir)

    decision = _mk_route_decision(shape="superworker")
    fake_route = MagicMock(return_value=decision)
    fake_record = MagicMock()
    monkeypatch.setattr("aibrain.core.agent_router.route", fake_route)
    monkeypatch.setattr("aibrain.core.agent_router.record_outcome", fake_record)

    # Mock superworker.invoke to return a fake SuperWorkerResult
    sw_result = MagicMock()
    sw_result.to_harness_dict.return_value = {
        "result": sw_result,
        "_cost_cents": 7,
        "_model_used": "claude-sonnet-4-superworker",
    }
    fake_invoke = MagicMock(return_value=sw_result)
    monkeypatch.setattr("aibrain.core.superworker.invoke", fake_invoke)

    # Capture the action that gets passed to harness.execute
    captured = {}
    def capturing_execute(task, action, config):
        captured["task"] = task
        captured["action"] = action
        # Call the action so we know whether SuperWorker or the workflow ran
        captured["output"] = action()
        return _mk_harness_result()
    monkeypatch.setattr(workflow_runner, "execute", capturing_execute)

    workflow_runner.run_workflow("fake_wf", v3_task_type="code_review")

    # SuperWorker.invoke must have been called with the workflow task
    fake_invoke.assert_called_once()
    _, kwargs = fake_invoke.call_args
    assert kwargs["task"] == "workflow.fake_wf"
    assert kwargs["task_type"] == "code_review"

    # The action that ran returned the SuperWorker harness dict, not the workflow's sentinel
    assert captured["output"]["_cost_cents"] == 7
    assert captured["output"]["_model_used"] == "claude-sonnet-4-superworker"


# --- record_outcome called after execute ------------------------------------

def test_run_workflow_v3_records_outcome(monkeypatch, tmp_path):
    """After harness.execute returns, agent_router.record_outcome must be
    called with the quality_score so SelRoute learns from real signal."""
    wf_dir = tmp_path / "workflows"
    wf_dir.mkdir()
    (wf_dir / "fake_wf.py").write_text("def run(): return {'ok': True}\n")
    monkeypatch.setattr(workflow_runner, "WORKFLOW_DIR", wf_dir)

    decision = _mk_route_decision(shape="specialist")
    fake_route = MagicMock(return_value=decision)
    fake_record = MagicMock()
    monkeypatch.setattr("aibrain.core.agent_router.route", fake_route)
    monkeypatch.setattr("aibrain.core.agent_router.record_outcome", fake_record)

    fake_execute = MagicMock(return_value=_mk_harness_result(quality=0.92))
    monkeypatch.setattr(workflow_runner, "execute", fake_execute)

    workflow_runner.run_workflow("fake_wf", v3_task_type="security_review", actor="test")

    fake_record.assert_called_once()
    _, kwargs = fake_record.call_args
    assert kwargs["task_type"] == "security_review"
    assert kwargs["handler_shape"] == "specialist"
    assert kwargs["quality_score"] == 0.92
    assert kwargs["override_mode"] == "auto"
    assert kwargs["actor"] == "test"


# --- record_outcome honest-None propagation ---------------------------------

def test_run_workflow_v3_records_outcome_with_none_quality(monkeypatch, tmp_path):
    """If quality is None (could not measure), record_outcome is still called
    — agent_router.record_outcome filters None internally per honest-rubric."""
    wf_dir = tmp_path / "workflows"
    wf_dir.mkdir()
    (wf_dir / "fake_wf.py").write_text("def run(): return {'ok': True}\n")
    monkeypatch.setattr(workflow_runner, "WORKFLOW_DIR", wf_dir)

    decision = _mk_route_decision(shape="specialist")
    fake_route = MagicMock(return_value=decision)
    fake_record = MagicMock()
    monkeypatch.setattr("aibrain.core.agent_router.route", fake_route)
    monkeypatch.setattr("aibrain.core.agent_router.record_outcome", fake_record)

    fake_execute = MagicMock(return_value=_mk_harness_result(quality=None))
    monkeypatch.setattr(workflow_runner, "execute", fake_execute)

    workflow_runner.run_workflow("fake_wf", v3_task_type="security_review")

    # record_outcome IS called — the honest-None filter lives inside
    # agent_router.record_outcome itself, not in the caller
    fake_record.assert_called_once()
    assert fake_record.call_args.kwargs["quality_score"] is None


# --- Routing failure falls back ---------------------------------------------

def test_run_workflow_v3_route_failure_falls_back_to_direct(monkeypatch, tmp_path):
    """If agent_router.route raises, the workflow runs normally — no SuperWorker
    swap, no record_outcome, but no exception either."""
    wf_dir = tmp_path / "workflows"
    wf_dir.mkdir()
    (wf_dir / "fake_wf.py").write_text("def run(): return {'ok': True}\n")
    monkeypatch.setattr(workflow_runner, "WORKFLOW_DIR", wf_dir)

    fake_route = MagicMock(side_effect=RuntimeError("router blew up"))
    fake_record = MagicMock()
    monkeypatch.setattr("aibrain.core.agent_router.route", fake_route)
    monkeypatch.setattr("aibrain.core.agent_router.record_outcome", fake_record)

    fake_execute = MagicMock(return_value=_mk_harness_result())
    monkeypatch.setattr(workflow_runner, "execute", fake_execute)

    result = workflow_runner.run_workflow("fake_wf", v3_task_type="security_review")

    # Workflow still ran successfully
    assert result.success is True
    fake_route.assert_called_once()
    # record_outcome NOT called because route_decision is None after the failure
    fake_record.assert_not_called()
