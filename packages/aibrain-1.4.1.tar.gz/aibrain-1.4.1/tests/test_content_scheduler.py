"""test_content_scheduler.py — tiered delay scheduler wiring tests.

Verifies the content_intel_agent delay queue that sits between the
12-gate stack and the channel adapters. See
project_content_agent_tiered_delay_decision.md for the framework.

Every test sandboxes the canonical aibrain.db by monkeypatching
harness._get_or_create_db and harness._find_db at a tmp_path — NEVER
touches the real brain DB.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone
from typing import List, Tuple

import pytest

from aibrain.core import content_scheduler as cs


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sandbox_db(tmp_path, monkeypatch):
    """Redirect the canonical DB resolver to a tmp_path for the test.

    Patches BOTH _get_or_create_db (the writer path) and _find_db
    (the reader path) so the scheduler module and its audit hook land
    in the sandbox.
    """
    db_file = tmp_path / "aibrain.db"
    from aibrain.core import harness as _harness_mod
    monkeypatch.setattr(_harness_mod, "_get_or_create_db", lambda: db_file)
    monkeypatch.setattr(
        _harness_mod, "_find_db",
        lambda: db_file if db_file.exists() else None,
    )
    return db_file


@pytest.fixture
def captured_telegram(monkeypatch):
    """Capture outbound telegram messages — never hit the real bot."""
    captured: List[Tuple[int, str]] = []

    def fake_send(chat_id: int, text: str) -> bool:
        captured.append((chat_id, text))
        return True

    cs.set_telegram_sender(fake_send)
    yield captured
    cs.set_telegram_sender(None)


@pytest.fixture
def mock_adapter():
    """Swap in a mock channel adapter that records publish + delete
    calls so the scheduler is testable without the dry-run audit path
    interfering with assertions."""

    class _Mock:
        platform = "dry_run"  # override the default DryRunAdapter

        def __init__(self) -> None:
            self.published: List[cs.ScheduledDraft] = []
            self.deleted: List[str] = []
            self.next_post_id = "mock_post_1"
            self.should_raise: Exception | None = None
            self.delete_ok = True

        def publish(self, draft: cs.ScheduledDraft) -> str:
            if self.should_raise is not None:
                raise self.should_raise
            self.published.append(draft)
            return self.next_post_id

        def delete_post(self, post_id: str) -> bool:
            self.deleted.append(post_id)
            return self.delete_ok

    adapter = _Mock()
    cs._reset_registry_for_tests()
    cs.register_channel(adapter)
    yield adapter
    cs._reset_registry_for_tests()


# ---------------------------------------------------------------------------
# 1. Enqueue + tier delay calculation
# ---------------------------------------------------------------------------

def test_enqueue_computes_tier_delays(sandbox_db, captured_telegram, mock_adapter):
    t1 = cs.enqueue("d_t1", "T1", None, "body t1", "dry_run", "neuro", {})
    t2 = cs.enqueue("d_t2", "T2", None, "body t2", "dry_run", "neuro", {})
    t3 = cs.enqueue("d_t3", "T3", None, "body t3", "dry_run", "neuro", {})

    # Tier 1 fires immediately (0 delay) — fires_at == queued_at
    assert (t1.fires_at - t1.queued_at).total_seconds() == pytest.approx(0, abs=1)
    # Tier 2 fires after 1 hour
    assert (t2.fires_at - t2.queued_at).total_seconds() == pytest.approx(3600, abs=2)
    # Tier 3 fires after 4 hours
    assert (t3.fires_at - t3.queued_at).total_seconds() == pytest.approx(14400, abs=2)

    # Status is queued for all three
    for d in (t1, t2, t3):
        assert d.status == "queued"

    # T1 does NOT notify; T2 + T3 do
    assert len(captured_telegram) == 2
    chat_ids = {msg[0] for msg in captured_telegram}
    assert chat_ids == {cs.DECKER_DM_CHAT_ID}
    texts = [msg[1] for msg in captured_telegram]
    assert any("T2" in t and "d_t2" in t for t in texts)
    assert any("T3" in t and "d_t3" in t for t in texts)


def test_enqueue_rejects_unknown_tier(sandbox_db, captured_telegram, mock_adapter):
    with pytest.raises(ValueError, match="unknown tier"):
        cs.enqueue("bad", "T9", None, "body", "dry_run", "neuro", {})


# ---------------------------------------------------------------------------
# 2. Veto before fire
# ---------------------------------------------------------------------------

def test_veto_before_fire_marks_vetoed(sandbox_db, captured_telegram, mock_adapter):
    cs.enqueue("d_veto", "T2", None, "body", "dry_run", "neuro", {})
    ok = cs.veto("d_veto", "Decker vetoed: benchmark claim unverified")
    assert ok is True

    draft = cs.get_draft("d_veto")
    assert draft is not None
    assert draft.status == "vetoed"
    assert "benchmark claim" in (draft.veto_reason or "")


def test_veto_unknown_draft_returns_false(sandbox_db, captured_telegram, mock_adapter):
    assert cs.veto("does_not_exist", "reason") is False


# ---------------------------------------------------------------------------
# 3. Auto-publish on tick (T1)
# ---------------------------------------------------------------------------

def test_tick_publishes_t1_immediately(sandbox_db, captured_telegram, mock_adapter):
    cs.enqueue("d_now", "T1", "Hello", "body now", "dry_run", "neuro", {})
    fired = cs.run_scheduler_tick()

    assert len(fired) == 1
    assert fired[0].draft_id == "d_now"
    assert fired[0].status == "published"
    assert fired[0].published_post_id == "mock_post_1"

    # Adapter was actually called with the draft
    assert len(mock_adapter.published) == 1
    assert mock_adapter.published[0].draft_id == "d_now"

    # Persisted
    persisted = cs.get_draft("d_now")
    assert persisted.status == "published"
    assert persisted.published_post_id == "mock_post_1"


# ---------------------------------------------------------------------------
# 4. No publish before fires_at (T3 still queued)
# ---------------------------------------------------------------------------

def test_tick_skips_drafts_not_yet_due(sandbox_db, captured_telegram, mock_adapter):
    cs.enqueue("d_later", "T3", None, "body", "dry_run", "neuro", {})

    # Tick immediately — T3 fires 4h later so should NOT publish
    fired = cs.run_scheduler_tick()
    assert fired == []
    assert len(mock_adapter.published) == 0

    draft = cs.get_draft("d_later")
    assert draft.status == "queued"


# ---------------------------------------------------------------------------
# 5. Publish after fires_at (mocked future time)
# ---------------------------------------------------------------------------

def test_tick_publishes_after_window_elapsed(sandbox_db, captured_telegram, mock_adapter):
    cs.enqueue("d_ripe", "T3", None, "body", "dry_run", "neuro", {})

    # Simulate a tick 5 hours in the future
    future = datetime.now(timezone.utc) + timedelta(hours=5)
    fired = cs.run_scheduler_tick(now=future)

    assert len(fired) == 1
    assert fired[0].draft_id == "d_ripe"
    assert fired[0].status == "published"


# ---------------------------------------------------------------------------
# 6. Veto after fire fails
# ---------------------------------------------------------------------------

def test_veto_after_publish_returns_false(sandbox_db, captured_telegram, mock_adapter):
    cs.enqueue("d_published", "T1", None, "body", "dry_run", "neuro", {})
    cs.run_scheduler_tick()

    # Already published — veto must refuse
    assert cs.veto("d_published", "too late") is False
    draft = cs.get_draft("d_published")
    assert draft.status == "published"


# ---------------------------------------------------------------------------
# 7. Kill published draft
# ---------------------------------------------------------------------------

def test_kill_published_updates_status_and_calls_adapter(
    sandbox_db, captured_telegram, mock_adapter
):
    mock_adapter.next_post_id = "post_kill_me"
    cs.enqueue("d_kill", "T1", None, "body", "dry_run", "neuro", {})
    cs.run_scheduler_tick()

    ok = cs.kill_published("post_kill_me", "slipped through — factual error")
    assert ok is True
    assert "post_kill_me" in mock_adapter.deleted

    draft = cs.get_draft("d_kill")
    assert draft.status == "killed"
    assert "factual error" in (draft.veto_reason or "")


def test_kill_unknown_post_returns_false(sandbox_db, captured_telegram, mock_adapter):
    assert cs.kill_published("no_such_post", "reason") is False


# ---------------------------------------------------------------------------
# 8. Rate limit retry
# ---------------------------------------------------------------------------

def test_rate_limit_retries_instead_of_failing(
    sandbox_db, captured_telegram, mock_adapter, monkeypatch
):
    """When rate limit is exceeded at publish time, the draft must stay
    queued with fires_at pushed 1 hour forward — not fail."""
    # Tighten the limit to 1 so the second post exceeds.
    monkeypatch.setattr(cs, "MAX_POSTS_PER_PLATFORM_PER_DAY", 1)

    cs.enqueue("d_first", "T1", None, "body1", "dry_run", "neuro", {})
    cs.enqueue("d_second", "T1", None, "body2", "dry_run", "neuro", {})
    # Tick once — first publishes, second hits the rate wall
    fired = cs.run_scheduler_tick()

    # Only the first one actually fired
    fired_ids = {d.draft_id for d in fired}
    assert "d_first" in fired_ids
    assert "d_second" not in fired_ids

    # d_second is still queued, but fires_at is ~1h in the future
    deferred = cs.get_draft("d_second")
    assert deferred.status == "queued"
    countdown = deferred.countdown_seconds()
    assert 3500 <= countdown <= 3700, f"expected ~3600s retry, got {countdown}"


# ---------------------------------------------------------------------------
# 9. Concurrent tick safety — no double publish
# ---------------------------------------------------------------------------

def test_concurrent_ticks_do_not_double_publish(
    sandbox_db, captured_telegram, mock_adapter
):
    """Two concurrent run_scheduler_tick calls must publish each draft
    exactly once. Guard is a module lock + atomic status transition."""
    import threading

    cs.enqueue("d_race_a", "T1", None, "a", "dry_run", "neuro", {})
    cs.enqueue("d_race_b", "T1", None, "b", "dry_run", "neuro", {})

    results: List[List[cs.ScheduledDraft]] = [[], []]

    def worker(idx: int) -> None:
        results[idx] = cs.run_scheduler_tick()

    t1 = threading.Thread(target=worker, args=(0,))
    t2 = threading.Thread(target=worker, args=(1,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    # Exactly 2 unique drafts published across both ticks combined
    all_fired_ids = [d.draft_id for r in results for d in r]
    assert sorted(all_fired_ids) == ["d_race_a", "d_race_b"]
    # Adapter was called exactly twice total — no double publish
    assert len(mock_adapter.published) == 2

    # Persisted state: both published
    assert cs.get_draft("d_race_a").status == "published"
    assert cs.get_draft("d_race_b").status == "published"


# ---------------------------------------------------------------------------
# Extras — adapter failure path + get_queue_status ordering
# ---------------------------------------------------------------------------

def test_adapter_exception_marks_failed(
    sandbox_db, captured_telegram, mock_adapter
):
    mock_adapter.should_raise = RuntimeError("network down")
    cs.enqueue("d_boom", "T1", None, "body", "dry_run", "neuro", {})
    fired = cs.run_scheduler_tick()

    assert len(fired) == 1
    assert fired[0].status == "failed"
    draft = cs.get_draft("d_boom")
    assert draft.status == "failed"


def test_queue_status_sorted_by_fires_at(
    sandbox_db, captured_telegram, mock_adapter
):
    cs.enqueue("d_slow", "T3", None, "slow", "dry_run", "neuro", {})
    cs.enqueue("d_fast", "T2", None, "fast", "dry_run", "neuro", {})
    queue = cs.get_queue_status()
    assert [d.draft_id for d in queue] == ["d_fast", "d_slow"]
