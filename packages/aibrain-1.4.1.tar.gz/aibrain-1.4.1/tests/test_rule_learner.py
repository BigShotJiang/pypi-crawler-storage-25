"""
Tests for rule_learner — dynamic HARD RULE suggestion from correction patterns.

Tests:
  1. Event handler tracks corrections by category
  2. Session suggestions respect threshold
  3. suggest_new_rules returns patterns above threshold
  4. suggest_new_rules respects -n limit
  5. _draft_rule formats rule text correctly
  6. CLI outputs JSON mode
  7. CLI outputs human-readable mode
  8. reset_session_tracking clears state
  9. Event handler registers on event bus
  10. Empty corrections return empty suggestions
"""

import json
import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.rule_learner import (
    on_correction_received,
    suggest_from_session,
    suggest_new_rules,
    reset_session_tracking,
    _draft_rule,
    cli_suggest_rules,
    DEFAULT_THRESHOLD,
)


@pytest.fixture(autouse=True)
def clean_session():
    """Reset session tracking before each test."""
    reset_session_tracking()
    yield
    reset_session_tracking()


# ---------------------------------------------------------------------------
# Test 1: Event handler tracks corrections by category
# ---------------------------------------------------------------------------

class TestEventHandler:
    def test_tracks_by_category(self):
        on_correction_received({"error_category": "git", "name": "bad push", "content": "pushed wrong"})
        on_correction_received({"error_category": "git", "name": "force push", "content": "forced"})
        on_correction_received({"error_category": "security", "name": "cred leak", "content": "leaked"})

        session = suggest_from_session(threshold=1)
        categories = {s["pattern"] for s in session}
        assert "[session] git" in categories
        assert "[session] security" in categories

    def test_defaults_to_other_category(self):
        on_correction_received({"name": "something", "content": "no category"})
        session = suggest_from_session(threshold=1)
        assert any("other" in s["pattern"] for s in session)


# ---------------------------------------------------------------------------
# Test 2: Session suggestions respect threshold
# ---------------------------------------------------------------------------

class TestSessionSuggestions:
    def test_below_threshold_not_suggested(self):
        on_correction_received({"error_category": "git", "name": "one"})
        on_correction_received({"error_category": "git", "name": "two"})
        # threshold=3, only 2 corrections
        assert suggest_from_session(threshold=3) == []

    def test_at_threshold_suggested(self):
        for i in range(3):
            on_correction_received({"error_category": "git", "name": f"correction_{i}"})
        result = suggest_from_session(threshold=3)
        assert len(result) == 1
        assert result[0]["count"] == 3


# ---------------------------------------------------------------------------
# Test 3: suggest_new_rules returns patterns above threshold
# ---------------------------------------------------------------------------

class TestSuggestNewRules:
    def test_filters_by_threshold(self):
        mock_modes = [
            {"pattern": "git push errors", "count": 5, "representative": "bad push",
             "importance_avg": 0.8, "example_ids": [1, 2, 3, 4, 5]},
            {"pattern": "naming style", "count": 2, "representative": "use snake_case",
             "importance_avg": 0.3, "example_ids": [6, 7]},
        ]
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=mock_modes):
            results = suggest_new_rules(threshold=3)
            assert len(results) == 1
            assert results[0]["pattern"] == "git push errors"
            assert results[0]["count"] == 5

    def test_empty_when_no_modes_above_threshold(self):
        mock_modes = [
            {"pattern": "rare", "count": 1, "representative": "once",
             "importance_avg": 0.5, "example_ids": [1]},
        ]
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=mock_modes):
            assert suggest_new_rules(threshold=3) == []


# ---------------------------------------------------------------------------
# Test 4: suggest_new_rules respects -n limit
# ---------------------------------------------------------------------------

class TestNLimit:
    def test_returns_at_most_n(self):
        mock_modes = [
            {"pattern": f"pattern_{i}", "count": 10 - i, "representative": f"rep_{i}",
             "importance_avg": 0.5, "example_ids": list(range(10 - i))}
            for i in range(5)
        ]
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=mock_modes):
            results = suggest_new_rules(threshold=3, n=2)
            assert len(results) == 2
            # Should be sorted by count descending
            assert results[0]["count"] >= results[1]["count"]


# ---------------------------------------------------------------------------
# Test 5: _draft_rule formats rule text correctly
# ---------------------------------------------------------------------------

class TestDraftRule:
    def test_includes_representative(self):
        mode = {"representative": "never_push_creds", "pattern": "security", "count": 5}
        rule = _draft_rule(mode)
        assert "HARD RULE:" in rule
        assert "5x" in rule

    def test_cleans_up_file_names(self):
        mode = {"representative": "feedback_no_creds_to_git.md", "pattern": "", "count": 3}
        rule = _draft_rule(mode)
        assert "feedback_" not in rule
        assert ".md" not in rule
        assert "no creds to git" in rule

    def test_fallback_to_pattern(self):
        mode = {"representative": "", "pattern": "git errors [push, remote]", "count": 4}
        rule = _draft_rule(mode)
        assert "git errors" in rule


# ---------------------------------------------------------------------------
# Test 6: CLI JSON mode
# ---------------------------------------------------------------------------

class TestCLIJson:
    def test_json_output(self, capsys):
        mock_modes = [
            {"pattern": "test_pattern", "count": 5, "representative": "test_rep",
             "importance_avg": 0.7, "example_ids": [1, 2, 3, 4, 5]},
        ]
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=mock_modes):
            rc = cli_suggest_rules(["--json"])
            assert rc == 0
            output = capsys.readouterr().out
            data = json.loads(output)
            assert isinstance(data, list)
            assert len(data) >= 1

    def test_json_empty(self, capsys):
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=[]):
            rc = cli_suggest_rules(["--json"])
            assert rc == 0
            output = capsys.readouterr().out
            assert json.loads(output) == []


# ---------------------------------------------------------------------------
# Test 7: CLI human-readable mode
# ---------------------------------------------------------------------------

class TestCLIHuman:
    def test_human_output(self, capsys):
        mock_modes = [
            {"pattern": "git push errors", "count": 5, "representative": "bad push",
             "importance_avg": 0.8, "example_ids": [1, 2, 3, 4, 5]},
        ]
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=mock_modes):
            rc = cli_suggest_rules([])
            assert rc == 0
            output = capsys.readouterr().out
            assert "Rule Suggestions" in output
            assert "git push errors" in output
            assert "suggestions only" in output

    def test_no_results_message(self, capsys):
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=[]):
            rc = cli_suggest_rules([])
            assert rc == 0
            output = capsys.readouterr().out
            assert "No correction patterns found" in output


# ---------------------------------------------------------------------------
# Test 8: reset_session_tracking clears state
# ---------------------------------------------------------------------------

class TestReset:
    def test_reset_clears(self):
        on_correction_received({"error_category": "git", "name": "a"})
        on_correction_received({"error_category": "git", "name": "b"})
        on_correction_received({"error_category": "git", "name": "c"})
        assert len(suggest_from_session(threshold=1)) > 0
        reset_session_tracking()
        assert suggest_from_session(threshold=1) == []


# ---------------------------------------------------------------------------
# Test 9: Event handler registers on event bus
# ---------------------------------------------------------------------------

class TestRegistration:
    def test_register_calls_on(self):
        with patch("aibrain.core.event_bus.on") as mock_on:
            from aibrain.core.rule_learner import register_handlers
            register_handlers()
            mock_on.assert_called_once()
            # First arg should be CORRECTION_RECEIVED event type
            call_args = mock_on.call_args
            assert "CORRECTION" in call_args[0][0]


# ---------------------------------------------------------------------------
# Test 10: Empty corrections return empty suggestions
# ---------------------------------------------------------------------------

class TestEmptyState:
    def test_no_corrections_no_suggestions(self):
        with patch("aibrain.core.correction_analysis.top_failure_modes", return_value=[]):
            assert suggest_new_rules() == []
        assert suggest_from_session() == []
