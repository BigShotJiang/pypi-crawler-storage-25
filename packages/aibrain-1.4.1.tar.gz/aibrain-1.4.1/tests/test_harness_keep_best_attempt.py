"""test_harness_keep_best_attempt.py — regression tests for Bug #1 + Bug #3.

These tests verify the Apr 11 SuperWorker dogfood fixes:

  Bug #1: Retry loop overwrote a successful attempt with a failed retry's
          state. Fix: harness keeps the BEST attempt across retries
          (success > failure, higher quality > lower quality), and
          per-attempt state is reset so previous attempt fields can't
          bleed through.

  Bug #3: _check_output_not_error pattern-matched the str repr looking
          for "error" / "failed" / "exception" — false-positives on any
          substantive output that discussed error scenarios. Fix: check
          STRUCTURED indicators only (dict.get('error'), dict.get('success')
          is False, etc.). _evaluate_quality also recognizes the SuperWorker
          dict shape via _self_score / result keys.

Both bugs were caught by the first SuperWorker dogfood run on the DB
schema audit task. Without these fixes the SelRoute feedback loop sees
the failed retry's state instead of the successful first run, AND every
SuperWorker output that mentions errors/failure scenarios scores low.
"""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from aibrain.core.harness import (
    HarnessConfig,
    HarnessResult,
    _check_output_not_error,
    _evaluate_quality,
    evaluate_task_quality,
    execute,
)


# --- Bug #3: _check_output_not_error structural checks --------------------

def test_check_output_not_error_passes_substantive_string_with_error_words():
    """A substantive output that DISCUSSES errors must not be flagged.

    This is the exact case the SuperWorker dogfood hit: a 15K-char migration
    plan with words like 'rollback path', 'exception handling', 'error rate'
    in the synthesis body. Old code returned False (FAIL) on every such
    output. New code only checks structured indicators.
    """
    text = (
        "Migration plan: rollback path is the existing backup_<ts> file. "
        "Risk: typeerror if the schema mismatches. Mitigation: explicit "
        "column list, never SELECT *. Failed runs trigger the rollback."
    )
    passed, detail = _check_output_not_error(text)
    assert passed is True, f"substantive plain string should pass, got {detail}"


def test_check_output_not_error_dict_with_explicit_error_key_fails():
    """Dict with explicit error key is a real failure signal."""
    output = {"error": "DB connection refused", "success": False}
    passed, detail = _check_output_not_error(output)
    assert passed is False
    assert "error" in detail.lower()


def test_check_output_not_error_dict_with_success_false_fails():
    output = {"data": "ok", "success": False}
    passed, detail = _check_output_not_error(output)
    assert passed is False
    assert "success=False" in detail


def test_check_output_not_error_dict_with_status_failed_fails():
    output = {"status": "failed", "data": "ok"}
    passed, detail = _check_output_not_error(output)
    assert passed is False


def test_check_output_not_error_superworker_ok_dict_passes():
    """A SuperWorker harness dict with parse_status='ok' must pass.

    The SuperWorkerResult's synthesis may contain words like 'error' /
    'failed' anywhere in its content — they're describing the migration
    plan, not the run state. We check parse_status + success directly.
    """
    sw_result = MagicMock(parse_status="ok", success=True, synthesis_confidence=0.8)
    output = {"result": sw_result, "_cost_cents": 0, "_model_used": "claude-sonnet-4",
              "_self_score": 0.7}
    passed, detail = _check_output_not_error(output)
    assert passed is True, f"superworker ok dict should pass, got {detail}"


def test_check_output_not_error_superworker_failed_dict_fails():
    """A SuperWorker dict with parse_status='failed' must fail."""
    sw_result = MagicMock(parse_status="failed", success=False, synthesis_confidence=None)
    output = {"result": sw_result, "_cost_cents": None, "_model_used": "m",
              "_self_score": None}
    passed, detail = _check_output_not_error(output)
    assert passed is False
    assert "failed" in detail.lower() or "false" in detail.lower()


def test_check_output_not_error_none_fails():
    passed, detail = _check_output_not_error(None)
    assert passed is False


# --- Bug #3: _evaluate_quality recognizes SuperWorker shape ---------------

def test_evaluate_quality_superworker_ok_uses_synthesis_confidence():
    """SuperWorker dict with parse_status='ok' should score based on
    synthesis_confidence, not the old 'judgment task → no signal' path."""
    sw_result = MagicMock(parse_status="ok", success=True, synthesis_confidence=0.8)
    output = {"result": sw_result, "_cost_cents": 0, "_model_used": "m",
              "_self_score": 0.7}
    score, detail = _evaluate_quality("test", output, HarnessConfig(task_type="judgment"))
    assert score is not None, f"SuperWorker ok should score, got None ({detail})"
    assert 0.7 <= score <= 0.9, f"score {score} should be near synthesis_confidence 0.8"


def test_evaluate_quality_superworker_failed_scores_low():
    sw_result = MagicMock(parse_status="failed", success=False, synthesis_confidence=None)
    output = {"result": sw_result, "_cost_cents": None, "_model_used": "m",
              "_self_score": None}
    score, detail = _evaluate_quality("test", output, HarnessConfig(task_type="judgment"))
    assert score == 0.2, f"failed superworker should score 0.2, got {score}"


def test_evaluate_quality_superworker_partial_uses_discounted_confidence():
    sw_result = MagicMock(parse_status="partial", success=True, synthesis_confidence=0.8)
    output = {"result": sw_result, "_cost_cents": 0, "_model_used": "m",
              "_self_score": 0.6}
    score, detail = _evaluate_quality("test", output, HarnessConfig(task_type="judgment"))
    assert score is not None
    # Partial discounts confidence by 0.85
    assert 0.6 < score < 0.75, f"partial-discount should produce ~0.68, got {score}"


# --- Bug #1: keep best attempt across retries -----------------------------

def test_harness_keeps_best_attempt_when_first_succeeds_second_fails():
    """The Apr 11 dogfood scenario: first attempt succeeds, second attempt
    raises. The persisted result must reflect the SUCCESSFUL first attempt,
    NOT the failed retry.

    Uses SuperWorker shape with low synthesis_confidence so the eval math
    actually pushes the first attempt below the threshold and triggers a
    retry. With (0.4 * checks=1.0 + 0.3 * shape=0.05) / 0.7 = 0.593, below
    the 0.7 threshold."""
    call_count = {"n": 0}

    def flaky_action():
        call_count["n"] += 1
        if call_count["n"] == 1:
            sw_result = MagicMock(parse_status="ok", success=True, synthesis_confidence=0.05)
            # _cost_cents_equivalent=1 simulates the real CLI path which
            # always stamps an equivalent from the envelope's token counts.
            # Without it, the P0-3 refuse gate fires (actual=0 + equiv=None).
            return {"result": sw_result, "_cost_cents": 0,
                    "_cost_cents_equivalent": 1,
                    "_model_used": "claude-sonnet-4-first", "_self_score": 0.05}
        raise RuntimeError("second attempt blew up")

    config = HarnessConfig(task_type="judgment", max_retries=1, quality_threshold=0.7, audit=False)
    result = execute("test_keep_best", flaky_action, config)

    # The action ran twice (first succeeded but quality below threshold,
    # so retry triggered; second failed)
    assert call_count["n"] == 2, f"expected 2 attempts, got {call_count['n']}"

    # CRITICAL: result must reflect the first (successful) attempt,
    # NOT the failed retry that overwrote it before the fix.
    assert result.success is True, "best attempt was successful — should be persisted"
    assert result.cost_cents == 0
    assert result.self_score == 0.05
    assert result.error is None
    assert result.model_used == "claude-sonnet-4-first"


def test_harness_keeps_best_attempt_higher_quality_wins():
    """When both attempts succeed, the higher-quality one wins.
    First attempt synthesis_conf=0.05 (below threshold), second 0.8 (above)."""
    call_count = {"n": 0}

    def varying_quality_action():
        call_count["n"] += 1
        if call_count["n"] == 1:
            sw_result = MagicMock(parse_status="ok", success=True, synthesis_confidence=0.05)
            return {"result": sw_result, "_cost_cents": 0,
                    "_cost_cents_equivalent": 1,
                    "_model_used": "m1", "_self_score": 0.05}
        sw_result = MagicMock(parse_status="ok", success=True, synthesis_confidence=0.8)
        return {"result": sw_result, "_cost_cents": 0,
                "_cost_cents_equivalent": 1,
                "_model_used": "m2", "_self_score": 0.8}

    config = HarnessConfig(task_type="judgment", max_retries=1, quality_threshold=0.7, audit=False)
    result = execute("test_keep_best_quality", varying_quality_action, config)

    assert call_count["n"] == 2, f"expected 2 attempts, got {call_count['n']}"
    assert result.success is True
    # Second attempt scored higher (synthesis_conf 0.8 > 0.05) — it wins
    assert result.self_score == 0.8
    assert result.model_used == "m2"


def test_harness_per_attempt_state_reset_no_bleed_through():
    """Bug #4 root cause: previous attempt's cost_cents/model_used could
    leak into a failed attempt's snapshot because state wasn't reset
    between attempts. After fix: per-attempt reset clears the slate."""
    call_count = {"n": 0}

    def cost_then_fail_action():
        call_count["n"] += 1
        if call_count["n"] == 1:
            # First returns success with cost — but quality below threshold
            sw_result = MagicMock(parse_status="ok", success=True, synthesis_confidence=0.05)
            return {"result": sw_result, "_cost_cents": 50,
                    "_model_used": "first_model", "_self_score": 0.05}
        # Second raises — previously this would inherit cost_cents=50
        # from attempt 1. After fix: reset before attempt 2, so attempt 2's
        # snapshot has cost_cents=None.
        raise RuntimeError("second attempt failed")

    config = HarnessConfig(task_type="judgment", max_retries=1, quality_threshold=0.7, audit=False)
    result = execute("test_no_bleed", cost_then_fail_action, config)

    assert call_count["n"] == 2, f"expected 2 attempts, got {call_count['n']}"
    # The "best" attempt is #1 (success > failure), so result reflects #1
    assert result.success is True
    assert result.cost_cents == 50
    assert result.model_used == "first_model"


def test_harness_no_retries_when_quality_threshold_met_first_attempt():
    """Sanity: a successful first attempt above threshold should NOT trigger
    a retry. Standard happy-path behavior must not regress."""
    call_count = {"n": 0}

    def good_action():
        call_count["n"] += 1
        sw_result = MagicMock(parse_status="ok", success=True, synthesis_confidence=0.9)
        return {"result": sw_result, "_cost_cents": 0,
                "_cost_cents_equivalent": 1,
                "_model_used": "m", "_self_score": 0.9}

    config = HarnessConfig(task_type="judgment", max_retries=3, quality_threshold=0.5, audit=False)
    result = execute("test_first_good", good_action, config)

    assert call_count["n"] == 1, "should NOT retry when first attempt is above threshold"
    assert result.success is True
    assert result.retries == 0
