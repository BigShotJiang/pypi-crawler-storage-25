"""
Tests for memory decay in consolidation workflow.

Verifies that storage_strength decays for stale memories,
including those with NULL last_accessed (fallback to created date).
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from workflows.memory_consolidation import (
    decay_memories,
    DECAY_FLOOR,
    DECAY_RATE,
)


@pytest.fixture()
def db():
    """Create a test DB with the memories schema."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_decaytest_")
    os.close(fd)

    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            storage_strength REAL DEFAULT 1.0,
            status TEXT DEFAULT 'active',
            consolidated_from TEXT
        );
    """)
    conn.commit()

    yield conn

    conn.close()
    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


def _insert_memory(db, name, storage_strength=1.0, last_accessed=None, created=None):
    """Helper to insert a test memory."""
    db.execute("""
        INSERT INTO memories (name, type, content, storage_strength, last_accessed,
                              created, updated, active, status)
        VALUES (?, 'project', 'test content', ?, ?, ?, datetime('now'), 1, 'active')
    """, (name, storage_strength, last_accessed, created or "2026-01-01 00:00:00"))
    db.commit()


class TestDecayMemories:
    """Test the decay_memories function."""

    def test_stale_memories_decay(self, db):
        """Memories accessed >30 days ago should have reduced storage_strength."""
        _insert_memory(db, "stale_mem", storage_strength=1.0,
                       last_accessed="2026-01-01 00:00:00")

        decayed = decay_memories(db, dry_run=False)
        assert decayed >= 1

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='stale_mem'"
        ).fetchone()
        assert row["storage_strength"] < 1.0
        assert row["storage_strength"] >= DECAY_FLOOR

    def test_recent_memories_not_decayed(self, db):
        """Memories accessed recently should not decay."""
        _insert_memory(db, "fresh_mem", storage_strength=1.0,
                       last_accessed="2099-01-01 00:00:00")  # Far future

        decayed = decay_memories(db, dry_run=False)
        assert decayed == 0

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='fresh_mem'"
        ).fetchone()
        assert row["storage_strength"] == 1.0

    def test_null_last_accessed_falls_back_to_created(self, db):
        """Memories with NULL last_accessed should decay based on created date."""
        _insert_memory(db, "never_accessed", storage_strength=1.0,
                       last_accessed=None, created="2025-01-01 00:00:00")

        decayed = decay_memories(db, dry_run=False)
        assert decayed >= 1

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='never_accessed'"
        ).fetchone()
        assert row["storage_strength"] < 1.0
        assert row["storage_strength"] >= DECAY_FLOOR

    def test_floor_is_respected(self, db):
        """Decay should not push storage_strength below DECAY_FLOOR."""
        _insert_memory(db, "very_old", storage_strength=0.15,
                       last_accessed="2020-01-01 00:00:00")

        decay_memories(db, dry_run=False)

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='very_old'"
        ).fetchone()
        assert row["storage_strength"] >= DECAY_FLOOR

    def test_already_at_floor_not_decayed(self, db):
        """Memories already at DECAY_FLOOR should not be touched."""
        _insert_memory(db, "at_floor", storage_strength=DECAY_FLOOR,
                       last_accessed="2020-01-01 00:00:00")

        decayed = decay_memories(db, dry_run=False)
        assert decayed == 0

    def test_dry_run_does_not_modify(self, db):
        """Dry run should count but not modify any memories."""
        _insert_memory(db, "dry_test", storage_strength=1.0,
                       last_accessed="2025-01-01 00:00:00")

        count = decay_memories(db, dry_run=True)
        assert count >= 1

        # Verify strength is unchanged
        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='dry_test'"
        ).fetchone()
        assert row["storage_strength"] == 1.0
