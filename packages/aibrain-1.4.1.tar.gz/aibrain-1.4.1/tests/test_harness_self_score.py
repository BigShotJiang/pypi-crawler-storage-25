"""test_harness_self_score.py — wiring tests for the self_score path.

Verifies that aibrain.core.harness.execute() correctly:
  - Extracts _self_score from output dict (matches _cost_cents convention)
  - Passes it to evaluate_task_quality() instead of hardcoded None
  - Populates HarnessResult.self_score / divergence / flagged from the eval
    result dict
  - Persists all four scoring fields (quality, self_score, divergence,
    flagged) to execution_log via _log_audit
  - Honest-None throughout: missing or invalid _self_score = None,
    out-of-range = None, divergence = None when either side is None

These tests verify that the half-built honest-rubric divergence path is
now wired end-to-end. Without this wiring the SelRoute learning loop has
no signal about chronic over- or under-claim by actions.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from aibrain.core.harness import (
    HarnessConfig,
    HarnessResult,
    execute,
    evaluate_task_quality,
)


# --- HarnessResult dataclass ----------------------------------------------

def test_harness_result_has_self_score_fields():
    """The dataclass must carry the three new scoring fields with safe
    defaults (None / None / False)."""
    r = HarnessResult()
    assert hasattr(r, "self_score")
    assert hasattr(r, "divergence")
    assert hasattr(r, "flagged")
    assert r.self_score is None
    assert r.divergence is None
    assert r.flagged is False


# --- Self-report extraction from output dict ------------------------------

def test_execute_extracts_valid_self_score_from_output():
    """When action returns dict with _self_score in [0.0, 1.0], the harness
    must populate result.self_score from it."""
    def action():
        return {"data": "ok", "_self_score": 0.85}

    config = HarnessConfig(task_type="simple", actor="test", audit=False)
    result = execute("test_task", action, config)

    assert result.success is True
    assert result.self_score == 0.85


def test_execute_drops_out_of_range_self_score_to_none():
    """Honest-rubric: out-of-range scores get clamped to None, not to a
    boundary value. We refuse to fake."""
    for bad in [-0.5, 1.5, 2.0, -1.0]:
        def action(b=bad):
            return {"data": "ok", "_self_score": b}

        config = HarnessConfig(task_type="simple", actor="test", audit=False)
        result = execute(f"test_clamp_{bad}", action, config)

        assert result.success is True
        assert result.self_score is None, f"_self_score={bad} should clamp to None, got {result.self_score}"


def test_execute_drops_invalid_self_score_to_none():
    """Non-numeric values get coerced to None, not raised."""
    for bad in ["not_a_number", [], {}, object()]:
        def action(b=bad):
            return {"data": "ok", "_self_score": b}

        config = HarnessConfig(task_type="simple", actor="test", audit=False)
        result = execute("test_invalid", action, config)

        assert result.success is True
        assert result.self_score is None


def test_execute_explicit_none_self_score_stays_none():
    """If action explicitly passes _self_score=None, result.self_score
    is None — not magically replaced with a default."""
    def action():
        return {"data": "ok", "_self_score": None}

    config = HarnessConfig(task_type="simple", actor="test", audit=False)
    result = execute("test_explicit_none", action, config)

    assert result.success is True
    assert result.self_score is None


def test_execute_missing_self_score_stays_none():
    """When action doesn't include _self_score at all, result.self_score
    is None (the default), not a faked value."""
    def action():
        return {"data": "ok"}  # no _self_score key

    config = HarnessConfig(task_type="simple", actor="test", audit=False)
    result = execute("test_no_key", action, config)

    assert result.success is True
    assert result.self_score is None


# --- Divergence computation -----------------------------------------------

def test_evaluate_task_quality_computes_divergence_when_both_present():
    """Sanity check: when both self_score and eval_score are non-None,
    evaluate_task_quality returns divergence and flagged."""
    output = {"data": "real measurable substance for the eval"}
    eval_result = evaluate_task_quality(
        output=output,
        task_name="test_div",
        config=HarnessConfig(),
        self_score=0.9,
    )
    # Either both scores exist and divergence is computed,
    # OR eval_score is None (no real signal) and divergence is None.
    if eval_result["eval_score"] is not None:
        assert eval_result["divergence"] is not None
        assert eval_result["divergence"] >= 0
        assert isinstance(eval_result["flagged"], bool)
    else:
        assert eval_result["divergence"] is None


def test_evaluate_task_quality_no_self_score_means_no_divergence():
    """When self_score is None (action didn't self-report), divergence
    must be None — never invented from a one-sided score."""
    output = {"data": "real measurable substance for the eval"}
    eval_result = evaluate_task_quality(
        output=output,
        task_name="test_no_self",
        config=HarnessConfig(),
        self_score=None,
    )
    assert eval_result["self_score"] is None
    assert eval_result["divergence"] is None
    assert eval_result["flagged"] is False


# --- _log_audit persistence -----------------------------------------------

def test_log_audit_persists_self_score_divergence_flagged(tmp_path, monkeypatch):
    """After execute() returns, the execution_log row must carry the
    four scoring fields. This is the wire from in-memory result to
    durable audit trail.

    Uses tmp_path + monkeypatch to sandbox the brain DB into a temp
    directory — NEVER touches the canonical brain DB. The temp dir is
    auto-cleaned by pytest after the test exits.
    """
    # Build a fresh empty brain DB in the temp dir
    sandbox_db = tmp_path / "aibrain.db"
    # Patch BOTH the read-path (_find_db) and the write-path
    # (_get_or_create_db) to point at the sandbox. After the Bug #6 split,
    # _log_audit uses _get_or_create_db so writers work on fresh installs.
    from aibrain.core import harness as _harness_mod
    monkeypatch.setattr(_harness_mod, "_find_db", lambda: sandbox_db)
    monkeypatch.setattr(_harness_mod, "_get_or_create_db", lambda: sandbox_db)

    def action():
        return {"data": "ok", "_self_score": 0.95}

    config = HarnessConfig(task_type="simple", actor="test_persist", audit=True)
    result = execute("test_persist_scoring", action, config)
    assert result.success is True
    assert result.audit_id  # _log_audit should have written a row

    # Verify the row landed in the SANDBOX DB, not the canonical brain
    assert sandbox_db.exists(), "sandbox DB should have been created by _log_audit"
    conn = sqlite3.connect(str(sandbox_db))
    try:
        cur = conn.execute(
            "SELECT quality_score, self_score, divergence, flagged "
            "FROM execution_log WHERE id = ?",
            (result.audit_id,),
        )
        row = cur.fetchone()
    finally:
        conn.close()

    assert row is not None, f"audit row {result.audit_id} not found in sandbox execution_log"
    quality, self_score, divergence, flagged = row
    assert self_score == 0.95
    assert flagged in (0, 1)
    assert divergence is None or divergence >= 0


def test_log_audit_persists_on_fresh_install_no_existing_db(tmp_path, monkeypatch):
    """Bug #6 regression — on a FRESH install where aibrain.db does not yet
    exist, _log_audit must still persist its row. Previously _find_db returned
    None when the file was missing, causing the entire audit block to silently
    no-op. The fix split the resolver into _find_db (read, None on missing)
    and _get_or_create_db (write, creates if missing).

    This test sandboxes BOTH functions at a path where no DB file exists,
    runs execute() with audit=True, and verifies the sandbox DB is created
    AND the audit row is present.
    """
    sandbox_db = tmp_path / "nested" / "dir" / "aibrain.db"
    # Deliberately do NOT create the file or its parent directory —
    # _get_or_create_db must handle that.
    assert not sandbox_db.exists()
    assert not sandbox_db.parent.exists()

    from aibrain.core import harness as _harness_mod

    def _fake_get_or_create():
        sandbox_db.parent.mkdir(parents=True, exist_ok=True)
        sandbox_db.touch()
        return sandbox_db

    # Patch _find_db too so it returns None until the write path creates
    # the file (matches real resolver semantics).
    monkeypatch.setattr(
        _harness_mod, "_find_db",
        lambda: sandbox_db if sandbox_db.exists() else None,
    )
    monkeypatch.setattr(_harness_mod, "_get_or_create_db", _fake_get_or_create)

    def action():
        return {"data": "fresh install output", "_self_score": 0.8}

    config = HarnessConfig(task_type="simple", actor="test_fresh_install", audit=True)
    result = execute("test_fresh_install_audit", action, config)

    assert result.success is True
    assert result.audit_id, "audit_id must be set on fresh install, not empty"
    assert sandbox_db.exists(), (
        "sandbox DB must be created by _get_or_create_db during _log_audit — "
        "Bug #6 regression if this fails"
    )

    # Verify the row actually landed in the freshly-created DB
    conn = sqlite3.connect(str(sandbox_db))
    try:
        row = conn.execute(
            "SELECT id, self_score FROM execution_log WHERE id = ?",
            (result.audit_id,),
        ).fetchone()
    finally:
        conn.close()

    assert row is not None, (
        f"audit row {result.audit_id} missing from fresh-install sandbox DB — "
        "Bug #6 regression: _log_audit silently no-op'd on fresh install"
    )
    assert row[1] == 0.8, "self_score must persist on fresh-install audit"


# --- v1.4 P0-3 refuse-gate regression ------------------------------------

def test_harness_refuses_silent_zero_on_judgment_task():
    """v1.4 P0-3: a non-deterministic task that stamps cost_cents_actual=0
    WITHOUT a token-based equivalent signal is dishonest — the harness has
    no way to know what the call cost. Refuse by raising ValueError so the
    caller is forced to either supply real tokens, supply a real cost, or
    mark the task deterministic.

    This is the gate that closes the "1,242 rows with fake $0 sonnet calls"
    failure mode (Karpathy Round 1). Deterministic tasks remain exempt —
    $0 is the honest answer for a code-only path.
    """
    def action():
        # Non-deterministic run that stamps a fake $0 with no token signal.
        # This is exactly the dishonest pattern the gate exists to refuse.
        return {"data": "looks fine", "_cost_cents": 0, "_self_score": 0.9}

    config = HarnessConfig(task_type="judgment", actor="refuse_test", audit=False)
    with pytest.raises(ValueError, match="Cannot measure cost"):
        execute("dishonest_zero_task", action, config)


def test_harness_refuses_silent_zero_complex_task():
    """Complex tasks get the same treatment as judgment — if you can't
    measure, you must admit it explicitly (None) or pay for the measurement."""
    def action():
        return {"data": "ok", "_cost_cents_actual": 0, "_self_score": 0.9}

    config = HarnessConfig(task_type="complex", actor="refuse_test", audit=False)
    with pytest.raises(ValueError, match="Cannot measure cost"):
        execute("dishonest_complex_zero", action, config)


def test_harness_allows_zero_cost_on_deterministic_task():
    """Deterministic tasks never touch an LLM — $0 is the honest answer.
    The refuse gate must not fire on them."""
    def action():
        return {"data": "code-only output", "_cost_cents": 0}

    config = HarnessConfig(task_type="deterministic", actor="det_test", audit=False)
    result = execute("deterministic_zero_ok", action, config)
    assert result.success is True
    assert result.cost_cents_actual == 0


def test_harness_allows_zero_with_equivalent_signal():
    """The CLI-subscription path: cost_cents_actual=0 is honest because it's
    free via subscription, but cost_cents_equivalent carries the list-rate
    signal. The refuse gate must accept this — the honest measurement is
    just on the equivalent side."""
    def action():
        return {
            "data": "cli subscription path",
            "_cost_cents_actual": 0,
            "_cost_cents_equivalent": 42,
            "_self_score": 0.9,
        }

    config = HarnessConfig(task_type="judgment", actor="cli_test", audit=False)
    result = execute("cli_path_ok", action, config)
    assert result.success is True
    assert result.cost_cents_actual == 0
    assert result.cost_cents_equivalent == 42


def test_harness_allows_none_cost_on_judgment_task():
    """cost_cents_actual=None ("could not measure") is honest — the refuse
    gate only fires on the DISHONEST pattern of stamping a literal 0."""
    def action():
        return {"data": "no cost signal at all", "_self_score": 0.9}

    config = HarnessConfig(task_type="judgment", actor="none_test", audit=False)
    result = execute("none_cost_ok", action, config)
    assert result.success is True
    assert result.cost_cents_actual is None


def test_harness_enriches_bare_family_model_name():
    """Bare family names ('sonnet'/'opus'/'haiku') are the old-router-poison
    pattern. The harness must append '-unknown' so downstream analysis can
    tell a version-pinned run apart from a bare-family stamp."""
    def action():
        return {
            "data": "ok",
            "_cost_cents_actual": 0,
            "_cost_cents_equivalent": 1,
            "_model_used": "sonnet",
            "_self_score": 0.9,
        }

    config = HarnessConfig(task_type="judgment", actor="bare_test", audit=False)
    result = execute("bare_family_enrich", action, config)
    assert result.success is True
    assert result.model_used == "sonnet-unknown", (
        f"bare family should be enriched to 'sonnet-unknown', got {result.model_used!r}"
    )


def test_harness_preserves_fully_qualified_model_slug():
    """A fully-qualified slug must pass through unchanged — no '-unknown'
    suffix appended when the version is already specified."""
    def action():
        return {
            "data": "ok",
            "_cost_cents_actual": 0,
            "_cost_cents_equivalent": 1,
            "_model_used": "claude-sonnet-4-20250514",
            "_self_score": 0.9,
        }

    config = HarnessConfig(task_type="judgment", actor="slug_test", audit=False)
    result = execute("full_slug_preserve", action, config)
    assert result.success is True
    assert result.model_used == "claude-sonnet-4-20250514"
