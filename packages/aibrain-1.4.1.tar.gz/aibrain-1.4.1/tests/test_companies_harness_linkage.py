"""test_companies_harness_linkage.py — v1.4 P0-2 regression tests.

Verifies the thread-local wire between aibrain.core.companies and
aibrain.core.harness that links execution_log rows back to specific
company_issues rows.

Background: Internal audit 2026-04-11 found that execution_log.entity_type
was 100% 'task' (the generic fallback) — zero rows were linked to
company_issues.entity_id. The root cause was that checkout_task() returned
the task dict but didn't stash the issue ID anywhere the harness could
read it. harness.execute() had no way to know which company issue it was
servicing.

Fix: companies.py now stashes the checked-out issue ID on a threading.local
at checkout_task time, clears it at complete_task time, and harness.execute
reads it and passes it into _log_audit as linked_issue_id. _log_audit then
writes entity_type='company_issue' with entity_id=<issue id> instead of
the legacy 'task' fallback.

These tests cover:
  1. checkout → harness.execute → execution_log stamps entity_type=company_issue
  2. complete → harness.execute reverts to entity_type='task'
  3. harness.execute without any checkout keeps working (legacy path)
  4. Two threads with different checkouts don't cross-contaminate

All tests use tmp_path + monkeypatch so the canonical brain DB is never
touched. Each test gets its own sandbox DB.
"""
from __future__ import annotations

import sqlite3
import sys
import threading
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.harness import HarnessConfig, execute


# ---------------------------------------------------------------------------
# Sandbox DB schema — mirrors test_companies.py + the execution_log shape
# that _log_audit writes.
# ---------------------------------------------------------------------------

SANDBOX_SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mission TEXT,
    status TEXT DEFAULT 'active',
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_agents (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'general',
    title TEXT,
    status TEXT DEFAULT 'idle',
    reports_to TEXT,
    model TEXT DEFAULT 'auto',
    task_type TEXT DEFAULT 'judgment',
    authority TEXT DEFAULT 'standard',
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    heartbeat_interval_seconds INTEGER DEFAULT 14400,
    last_heartbeat_at TIMESTAMP,
    instructions TEXT,
    capabilities TEXT,
    permissions TEXT,
    metadata TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_issues (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    parent_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'backlog',
    priority TEXT DEFAULT 'medium',
    assignee_agent_id TEXT,
    project TEXT,
    issue_number INTEGER,
    origin TEXT DEFAULT 'manual',
    request_depth INTEGER DEFAULT 0,
    quality_score REAL,
    cost_cents INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT);
"""


@pytest.fixture()
def sandbox(tmp_path, monkeypatch):
    """Provision a sandbox DB and patch every resolver that touches it.

    Patches:
      - companies._get_db → sandbox DB
      - harness._find_db / _get_or_create_db → sandbox DB

    So one file holds both the companies tables AND the execution_log
    table — exactly how the canonical brain DB is laid out in production.
    """
    db_path = tmp_path / "sandbox_aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.executescript(SANDBOX_SCHEMA)
    conn.close()

    def _patched_companies_get_db():
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        return db

    monkeypatch.setattr("aibrain.core.companies._get_db", _patched_companies_get_db)

    from aibrain.core import harness as _harness_mod
    monkeypatch.setattr(_harness_mod, "_find_db", lambda: db_path)
    monkeypatch.setattr(_harness_mod, "_get_or_create_db", lambda: db_path)

    # Scrub any thread-local leftover from previous tests — critical for
    # test isolation since threading.local persists across tests in the
    # same worker process.
    from aibrain.core import companies as _comp
    if hasattr(_comp._current_issue, "id"):
        _comp._current_issue.id = None
    if hasattr(_comp._current_issue, "company_id"):
        _comp._current_issue.company_id = None

    yield db_path

    # Post-test scrub too — belt and braces.
    if hasattr(_comp._current_issue, "id"):
        _comp._current_issue.id = None
    if hasattr(_comp._current_issue, "company_id"):
        _comp._current_issue.company_id = None


def _fetch_audit_row(db_path: Path, audit_id: str) -> dict | None:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            "SELECT id, entity_type, entity_id, action FROM execution_log WHERE id=?",
            (audit_id,),
        ).fetchone()
    finally:
        conn.close()
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# Test 1: checkout → harness.execute links to company_issue
# ---------------------------------------------------------------------------

def test_checkout_sets_threadlocal_harness_picks_it_up(sandbox):
    """After checkout_task, a harness.execute call on the same thread must
    write an execution_log row with entity_type='company_issue' and
    entity_id=<the checked-out task id>."""
    from aibrain.core.companies import (
        create_company, hire_agent, create_task, checkout_task,
    )

    company = create_company("LinkCo")
    agent = hire_agent(company["id"], "Worker")
    task = create_task(company["id"], "Do the thing", priority="medium")

    checked_out = checkout_task(task["id"], agent["id"])
    assert "error" not in checked_out
    assert checked_out["id"] == task["id"]

    # Run a trivial deterministic harness action — the audit row it
    # produces should now be linked to the company_issue.
    def action():
        return {"data": "ok", "_self_score": 0.9}

    config = HarnessConfig(task_type="simple", actor="linkage_test", audit=True)
    result = execute("linked_action", action, config)

    assert result.success is True
    assert result.audit_id, "audit must have written a row"

    row = _fetch_audit_row(sandbox, result.audit_id)
    assert row is not None, "audit row should exist in sandbox DB"
    assert row["entity_type"] == "company_issue", (
        f"expected entity_type='company_issue', got {row['entity_type']!r} — "
        "thread-local wire is broken"
    )
    assert row["entity_id"] == task["id"], (
        f"expected entity_id={task['id']!r}, got {row['entity_id']!r}"
    )


# ---------------------------------------------------------------------------
# Test 2: complete_task clears the thread-local — post-complete rows revert
# ---------------------------------------------------------------------------

def test_complete_task_clears_threadlocal(sandbox):
    """After complete_task, subsequent harness.execute calls on the same
    thread must fall back to entity_type='task' (the legacy default) —
    the thread-local has been cleared."""
    from aibrain.core.companies import (
        create_company, hire_agent, create_task,
        checkout_task, complete_task,
    )

    company = create_company("ClearCo")
    agent = hire_agent(company["id"], "Worker")
    task = create_task(company["id"], "Do and clear")

    checkout_task(task["id"], agent["id"])
    complete_task(task["id"], quality_score=0.9)

    def action():
        return {"data": "post-complete run"}

    config = HarnessConfig(task_type="simple", actor="post_complete", audit=True)
    result = execute("post_complete_action", action, config)

    assert result.success is True
    row = _fetch_audit_row(sandbox, result.audit_id)
    assert row is not None
    assert row["entity_type"] == "task", (
        f"after complete_task the thread-local should be cleared, but "
        f"entity_type is still {row['entity_type']!r}"
    )
    assert row["entity_id"] is None, (
        f"after complete_task entity_id should be NULL, got {row['entity_id']!r}"
    )


# ---------------------------------------------------------------------------
# Test 3: harness.execute WITHOUT any checkout still works (legacy path)
# ---------------------------------------------------------------------------

def test_harness_execute_without_checkout_uses_legacy_task_entity(sandbox):
    """If no checkout_task has been called on this thread, harness.execute
    must still work and write entity_type='task' exactly like before the
    P0-2 fix — no regression to the existing harness behavior."""
    def action():
        return {"data": "unlinked run", "_self_score": 0.7}

    config = HarnessConfig(task_type="simple", actor="unlinked", audit=True)
    result = execute("unlinked_action", action, config)

    assert result.success is True
    row = _fetch_audit_row(sandbox, result.audit_id)
    assert row is not None
    assert row["entity_type"] == "task"
    assert row["entity_id"] is None


# ---------------------------------------------------------------------------
# Test 4: Thread isolation — two threads with different checkouts don't leak
# ---------------------------------------------------------------------------

def test_thread_isolation_no_cross_contamination(sandbox):
    """Two threads each checkout a different task. Each thread's
    harness.execute must see its own checked-out issue ID — the
    threading.local must not leak between threads."""
    from aibrain.core.companies import (
        create_company, hire_agent, create_task, checkout_task,
    )

    company = create_company("ThreadCo")
    agent = hire_agent(company["id"], "Worker")
    task_a = create_task(company["id"], "Thread A task")
    task_b = create_task(company["id"], "Thread B task")

    results: dict[str, str | None] = {}
    errors: list[BaseException] = []
    barrier = threading.Barrier(2)

    def worker(task_id: str, label: str):
        try:
            checkout_task(task_id, agent["id"])
            # Wait for the other thread to also have checked out its task
            # before running harness.execute — this maximises the
            # opportunity for leakage if threading.local weren't actually
            # thread-scoped.
            barrier.wait(timeout=5)

            def action():
                return {"data": f"work from {label}"}

            config = HarnessConfig(
                task_type="simple",
                actor=f"thread_{label}",
                audit=True,
            )
            r = execute(f"thread_{label}_action", action, config)
            results[label] = r.audit_id
        except BaseException as e:  # noqa: BLE001
            errors.append(e)

    t_a = threading.Thread(target=worker, args=(task_a["id"], "A"))
    t_b = threading.Thread(target=worker, args=(task_b["id"], "B"))
    t_a.start()
    t_b.start()
    t_a.join(timeout=30)
    t_b.join(timeout=30)

    assert not errors, f"worker thread raised: {errors}"
    assert "A" in results and "B" in results, "both workers must finish"

    row_a = _fetch_audit_row(sandbox, results["A"])
    row_b = _fetch_audit_row(sandbox, results["B"])

    assert row_a is not None and row_b is not None
    assert row_a["entity_type"] == "company_issue"
    assert row_b["entity_type"] == "company_issue"
    assert row_a["entity_id"] == task_a["id"], (
        f"thread A's audit row should link to task_a={task_a['id']!r}, "
        f"got {row_a['entity_id']!r}"
    )
    assert row_b["entity_id"] == task_b["id"], (
        f"thread B's audit row should link to task_b={task_b['id']!r}, "
        f"got {row_b['entity_id']!r}"
    )
    # And crucially, they must not equal each other — no cross-pollination.
    assert row_a["entity_id"] != row_b["entity_id"]
