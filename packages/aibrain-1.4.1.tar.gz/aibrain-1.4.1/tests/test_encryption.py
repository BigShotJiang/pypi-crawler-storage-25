"""
Tests for aibrain_encryption.py — field-level encryption for AIBrain DB.

Covers: ENC_PREFIX, encrypt_field, decrypt_field, _get_fernet, is_encrypted.
Uses in-memory Fernet instances (no DB dependency for most tests).
"""

import base64
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain_encryption import (
    ENC_PREFIX,
    ENCRYPTED_FIELDS,
    decrypt_field,
    encrypt_field,
    is_encrypted,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_enc_prefix_value(self):
        assert ENC_PREFIX == "enc:v1:"

    def test_enc_prefix_is_string(self):
        assert isinstance(ENC_PREFIX, str)

    def test_encrypted_fields_tuple(self):
        assert isinstance(ENCRYPTED_FIELDS, tuple)
        assert "content" in ENCRYPTED_FIELDS
        assert "tags" in ENCRYPTED_FIELDS


# ---------------------------------------------------------------------------
# is_encrypted
# ---------------------------------------------------------------------------

class TestIsEncrypted:
    def test_encrypted_value(self):
        assert is_encrypted("enc:v1:somedata") is True

    def test_plain_value(self):
        assert is_encrypted("just plain text") is False

    def test_empty_string(self):
        assert is_encrypted("") is False

    def test_none(self):
        assert is_encrypted(None) is False

    def test_partial_prefix(self):
        assert is_encrypted("enc:v1") is False

    def test_prefix_only(self):
        assert is_encrypted("enc:v1:") is True


# ---------------------------------------------------------------------------
# encrypt_field / decrypt_field without Fernet (passthrough)
# ---------------------------------------------------------------------------

class TestEncryptDecryptNoFernet:
    def test_encrypt_none_fernet_passthrough(self):
        assert encrypt_field("hello", None) == "hello"

    def test_decrypt_none_fernet_passthrough(self):
        assert decrypt_field("hello", None) == "hello"

    def test_encrypt_empty_value_passthrough(self):
        assert encrypt_field("", None) == ""

    def test_decrypt_empty_value_passthrough(self):
        assert decrypt_field("", None) == ""

    def test_encrypt_none_value(self):
        assert encrypt_field(None, None) is None

    def test_decrypt_none_value(self):
        assert decrypt_field(None, None) is None


# ---------------------------------------------------------------------------
# encrypt_field / decrypt_field with Fernet (requires cryptography)
# ---------------------------------------------------------------------------

def _make_fernet():
    """Create a test Fernet instance."""
    try:
        from cryptography.fernet import Fernet
        key = Fernet.generate_key()
        return Fernet(key)
    except ImportError:
        return None


@pytest.fixture()
def fernet():
    f = _make_fernet()
    if f is None:
        pytest.skip("cryptography package not installed")
    return f


class TestEncryptDecryptWithFernet:
    def test_roundtrip(self, fernet):
        original = "secret data"
        encrypted = encrypt_field(original, fernet)
        assert encrypted != original
        assert encrypted.startswith(ENC_PREFIX)
        decrypted = decrypt_field(encrypted, fernet)
        assert decrypted == original

    def test_roundtrip_unicode(self, fernet):
        original = "utf8: \u00e9\u00e8\u2603\U0001f600"
        encrypted = encrypt_field(original, fernet)
        decrypted = decrypt_field(encrypted, fernet)
        assert decrypted == original

    def test_roundtrip_long_string(self, fernet):
        original = "A" * 50000
        encrypted = encrypt_field(original, fernet)
        decrypted = decrypt_field(encrypted, fernet)
        assert decrypted == original

    def test_roundtrip_special_chars(self, fernet):
        original = '{"key": "value", "arr": [1,2,3]}'
        decrypted = decrypt_field(encrypt_field(original, fernet), fernet)
        assert decrypted == original

    def test_already_encrypted_not_double_encrypted(self, fernet):
        original = "data"
        encrypted = encrypt_field(original, fernet)
        double = encrypt_field(encrypted, fernet)
        # Should not double-encrypt
        assert double == encrypted

    def test_encrypted_starts_with_prefix(self, fernet):
        encrypted = encrypt_field("test", fernet)
        assert encrypted.startswith(ENC_PREFIX)

    def test_decrypt_plain_text_passthrough(self, fernet):
        # If value doesn't have prefix, decrypt returns as-is
        assert decrypt_field("plain text", fernet) == "plain text"

    def test_decrypt_wrong_key_returns_raw(self):
        """Decryption with wrong key returns the raw value (doesn't crash)."""
        try:
            from cryptography.fernet import Fernet
        except ImportError:
            pytest.skip("cryptography not installed")

        key1 = Fernet(Fernet.generate_key())
        key2 = Fernet(Fernet.generate_key())

        encrypted = encrypt_field("secret", key1)
        # Decrypting with wrong key should return raw value, not crash
        result = decrypt_field(encrypted, key2)
        assert result == encrypted  # returns raw on failure

    def test_empty_string_not_encrypted(self, fernet):
        result = encrypt_field("", fernet)
        assert result == ""


# ---------------------------------------------------------------------------
# _get_fernet
# ---------------------------------------------------------------------------

class TestGetFernet:
    def test_with_valid_password_and_salt(self):
        try:
            from aibrain_encryption import _get_fernet
            from cryptography.fernet import Fernet
        except ImportError:
            pytest.skip("cryptography not installed")

        salt = os.urandom(16)
        f = _get_fernet("test_password", salt)
        assert f is not None

    def test_same_password_same_salt_same_key(self):
        try:
            from aibrain_encryption import _get_fernet
        except ImportError:
            pytest.skip("cryptography not installed")

        salt = os.urandom(16)
        f1 = _get_fernet("password", salt)
        f2 = _get_fernet("password", salt)
        # Both should encrypt/decrypt interchangeably
        encrypted = f1.encrypt(b"test")
        decrypted = f2.decrypt(encrypted)
        assert decrypted == b"test"

    def test_different_passwords_different_keys(self):
        try:
            from aibrain_encryption import _get_fernet
        except ImportError:
            pytest.skip("cryptography not installed")

        salt = os.urandom(16)
        f1 = _get_fernet("password1", salt)
        f2 = _get_fernet("password2", salt)
        encrypted = f1.encrypt(b"test")
        with pytest.raises(Exception):
            f2.decrypt(encrypted)

    def test_different_salts_different_keys(self):
        try:
            from aibrain_encryption import _get_fernet
        except ImportError:
            pytest.skip("cryptography not installed")

        f1 = _get_fernet("password", b"salt1___________")
        f2 = _get_fernet("password", b"salt2___________")
        encrypted = f1.encrypt(b"test")
        with pytest.raises(Exception):
            f2.decrypt(encrypted)


# ---------------------------------------------------------------------------
# encrypt_on_write / decrypt_on_read hooks
# ---------------------------------------------------------------------------

class TestHooks:
    def test_encrypt_on_write_no_encryption(self, monkeypatch):
        """When no password set, passthrough."""
        import aibrain_encryption
        # Reset cached fernet
        aibrain_encryption._fernet_loaded = False
        aibrain_encryption._cached_fernet = None
        monkeypatch.delenv("AIBRAIN_DB_PASSWORD", raising=False)

        content, tags = aibrain_encryption.encrypt_on_write("hello", "tag1")
        assert content == "hello"
        assert tags == "tag1"

        # Cleanup
        aibrain_encryption._fernet_loaded = False
        aibrain_encryption._cached_fernet = None

    def test_decrypt_on_read_no_encryption(self, monkeypatch):
        """When no password set, passthrough."""
        import aibrain_encryption
        aibrain_encryption._fernet_loaded = False
        aibrain_encryption._cached_fernet = None
        monkeypatch.delenv("AIBRAIN_DB_PASSWORD", raising=False)

        content, tags = aibrain_encryption.decrypt_on_read("hello", "tag1")
        assert content == "hello"
        assert tags == "tag1"

        # Cleanup
        aibrain_encryption._fernet_loaded = False
        aibrain_encryption._cached_fernet = None
