"""
Tests for harness quality evaluation — domain correction trend wiring.

Verifies that evaluate_task_quality factors in the correction_baseline
domain trend (learning -> bonus, regressing -> penalty).
"""

import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

from aibrain.core.harness import evaluate_task_quality, HarnessConfig


def _make_db():
    """Create minimal test DB."""
    db_path = Path(_tmpdir) / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS event_bus_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            payload TEXT,
            created TEXT DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_event_bus_type ON event_bus_log(event_type);
    """)
    conn.commit()
    conn.close()
    return db_path


@pytest.fixture(autouse=True)
def _setup_db():
    _make_db()
    yield


# ---------------------------------------------------------------------------
# 1. Learning domain gives a quality bonus
# ---------------------------------------------------------------------------

def test_learning_domain_bonus():
    """A task in a 'learning' domain should get a +0.05 quality bonus."""
    fake_baseline = {
        "domains": {
            "security": {"trend": "learning", "windows": [{"rate": 0.1}]},
        },
        "summary": {"learning": ["security"], "regressing": [], "stable": []},
    }

    with patch("aibrain.core.correction_baseline.classify_domain", return_value="security"), \
         patch("aibrain.core.correction_baseline.correction_baseline", return_value=fake_baseline):
        result = evaluate_task_quality(
            output={"status": "ok", "findings": 3},
            task_name="scan_vuln_target",
            config=HarnessConfig(task_type="deterministic"),
        )

    assert result["domain_trend"] == "learning"
    assert result["eval_score"] > 0.65
    assert "domain_trend:learning" in result["detail"]


# ---------------------------------------------------------------------------
# 2. Regressing domain gives a quality penalty
# ---------------------------------------------------------------------------

def test_regressing_domain_penalty():
    """A task in a 'regressing' domain should get a -0.05 quality penalty."""
    fake_baseline = {
        "domains": {
            "git": {"trend": "regressing", "windows": [{"rate": 0.4}]},
        },
        "summary": {"learning": [], "regressing": ["git"], "stable": []},
    }

    with patch("aibrain.core.correction_baseline.classify_domain", return_value="git"), \
         patch("aibrain.core.correction_baseline.correction_baseline", return_value=fake_baseline):
        result = evaluate_task_quality(
            output={"status": "ok"},
            task_name="git_push_changes",
            config=HarnessConfig(task_type="deterministic"),
        )

    assert result["domain_trend"] == "regressing"
    assert "domain_trend:regressing" in result["detail"]


# ---------------------------------------------------------------------------
# 3. Stable domain gets no adjustment
# ---------------------------------------------------------------------------

def test_stable_domain_no_adjustment():
    """A stable domain should not appear in detail and get no adjustment."""
    fake_baseline = {
        "domains": {
            "testing": {"trend": "stable", "windows": [{"rate": 0.05}]},
        },
        "summary": {"learning": [], "regressing": [], "stable": ["testing"]},
    }

    with patch("aibrain.core.correction_baseline.classify_domain", return_value="testing"), \
         patch("aibrain.core.correction_baseline.correction_baseline", return_value=fake_baseline):
        result = evaluate_task_quality(
            output={"status": "ok"},
            task_name="run_pytest_suite",
            config=HarnessConfig(task_type="deterministic"),
        )

    assert result["domain_trend"] == "stable"
    assert "domain_trend" not in result["detail"]


# ---------------------------------------------------------------------------
# 4. Correction baseline import failure does not break evaluation
# ---------------------------------------------------------------------------

def test_correction_baseline_failure_graceful():
    """If correction_baseline raises, evaluation still returns a valid score."""
    with patch("aibrain.core.correction_baseline.classify_domain", side_effect=Exception("db gone")):
        result = evaluate_task_quality(
            output="some output text here for eval",
            task_name="random_task",
            config=HarnessConfig(task_type="simple"),
        )

    # domain_trend should be None (fallback)
    assert result["domain_trend"] is None
    # eval_score should still be a valid float
    assert 0.0 <= result["eval_score"] <= 1.0


# ---------------------------------------------------------------------------
# 5. Domain with no baseline data gets no adjustment
# ---------------------------------------------------------------------------

def test_unknown_domain_no_adjustment():
    """A domain not in the baseline results gets no trend adjustment."""
    fake_baseline = {
        "domains": {},
        "summary": {"learning": [], "regressing": [], "stable": []},
    }

    with patch("aibrain.core.correction_baseline.classify_domain", return_value="other"), \
         patch("aibrain.core.correction_baseline.correction_baseline", return_value=fake_baseline):
        result = evaluate_task_quality(
            output={"status": "ok"},
            task_name="unknown_domain_task",
            config=HarnessConfig(task_type="deterministic"),
        )

    assert result["domain_trend"] is None
    assert "domain_trend" not in result["detail"]
