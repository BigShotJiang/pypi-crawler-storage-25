"""Tests for aibrain.core.testing — experiment runner and regression detection."""

import json
import shutil
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from aibrain.core.testing import (
    ExperimentResults,
    ExperimentRunner,
    RegressionReport,
)


# ---------------------------------------------------------------------------
# ExperimentResults — metric calculations
# ---------------------------------------------------------------------------

class TestExperimentResults:
    def test_avg_quality(self):
        r = ExperimentResults(workflow="test", iterations=3, scores=[0.8, 0.9, 0.7])
        assert abs(r.avg_quality - 0.8) < 1e-9

    def test_min_quality(self):
        r = ExperimentResults(workflow="test", iterations=3, scores=[0.8, 0.9, 0.7])
        assert r.min_quality == 0.7

    def test_max_quality(self):
        r = ExperimentResults(workflow="test", iterations=3, scores=[0.8, 0.9, 0.7])
        assert r.max_quality == 0.9

    def test_empty_scores(self):
        r = ExperimentResults(workflow="test", iterations=0, scores=[])
        assert r.avg_quality == 0.0
        assert r.min_quality == 0.0
        assert r.max_quality == 0.0
        assert r.stddev == 0.0

    def test_single_score(self):
        r = ExperimentResults(workflow="test", iterations=1, scores=[0.5])
        assert r.avg_quality == 0.5
        assert r.min_quality == 0.5
        assert r.max_quality == 0.5
        assert r.stddev == 0.0  # can't compute stdev with 1 sample

    def test_stddev(self):
        r = ExperimentResults(workflow="test", iterations=3, scores=[0.8, 0.8, 0.8])
        assert r.stddev == 0.0

        r2 = ExperimentResults(workflow="test", iterations=2, scores=[0.0, 1.0])
        assert r2.stddev > 0.0


# ---------------------------------------------------------------------------
# Baseline save/load
# ---------------------------------------------------------------------------

class TestBaseline:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_save_and_load_baseline(self):
        r = ExperimentResults(
            workflow="heartbeat",
            iterations=3,
            scores=[0.8, 0.9, 0.7],
            timestamp="2026-04-07T00:00:00Z",
            duration_seconds=1.5,
        )
        filepath = r.save_baseline(path=self.tmpdir)
        assert filepath.exists()

        # Load it back
        data = json.loads(filepath.read_text(encoding="utf-8"))
        assert data["workflow"] == "heartbeat"
        assert data["iterations"] == 3
        assert abs(data["avg_quality"] - 0.8) < 1e-9
        assert data["min_quality"] == 0.7
        assert data["max_quality"] == 0.9
        assert len(data["scores"]) == 3

    def test_save_creates_directory(self):
        subdir = Path(self.tmpdir) / "nested" / "baselines"
        r = ExperimentResults(workflow="test_wf", iterations=1, scores=[0.5])
        filepath = r.save_baseline(path=str(subdir))
        assert filepath.exists()

    def test_save_sanitizes_workflow_name(self):
        r = ExperimentResults(workflow="team:my/workflow", iterations=1, scores=[0.5])
        filepath = r.save_baseline(path=self.tmpdir)
        assert "team_my_workflow" in filepath.name


# ---------------------------------------------------------------------------
# Regression detection
# ---------------------------------------------------------------------------

class TestRegression:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _save_baseline(self, workflow: str, avg: float):
        """Helper: save a fake baseline."""
        r = ExperimentResults(
            workflow=workflow, iterations=5,
            scores=[avg] * 5, timestamp="2026-01-01T00:00:00Z",
        )
        r.save_baseline(path=self.tmpdir)

    def test_regression_detected(self):
        self._save_baseline("wf_a", avg=0.9)

        current = ExperimentResults(
            workflow="wf_a", iterations=5,
            scores=[0.7, 0.7, 0.7, 0.7, 0.7],
        )
        report = current.check_regression(threshold=0.1, baseline_path=self.tmpdir)

        assert report.regressed is True
        assert abs(report.baseline_avg - 0.9) < 1e-9
        assert abs(report.current_avg - 0.7) < 1e-9
        assert abs(report.delta - 0.2) < 1e-9
        assert "REGRESSION" in report.message

    def test_no_regression(self):
        self._save_baseline("wf_b", avg=0.8)

        current = ExperimentResults(
            workflow="wf_b", iterations=3,
            scores=[0.82, 0.78, 0.80],
        )
        report = current.check_regression(threshold=0.1, baseline_path=self.tmpdir)

        assert report.regressed is False
        assert "OK" in report.message

    def test_no_baseline_exists(self):
        current = ExperimentResults(
            workflow="never_saved", iterations=2, scores=[0.5, 0.5],
        )
        report = current.check_regression(baseline_path=self.tmpdir)

        assert report.regressed is False
        assert "No baseline" in report.message

    def test_assert_no_regression_passes(self):
        self._save_baseline("wf_c", avg=0.8)

        current = ExperimentResults(
            workflow="wf_c", iterations=3, scores=[0.85, 0.80, 0.82],
        )
        # Should not raise
        current.assert_no_regression(threshold=0.1, baseline_path=self.tmpdir)

    def test_assert_no_regression_raises(self):
        self._save_baseline("wf_d", avg=0.9)

        current = ExperimentResults(
            workflow="wf_d", iterations=3, scores=[0.5, 0.5, 0.5],
        )
        with pytest.raises(AssertionError, match="REGRESSION"):
            current.assert_no_regression(threshold=0.1, baseline_path=self.tmpdir)

    def test_quality_improvement_not_regression(self):
        """Quality going UP should not be flagged."""
        self._save_baseline("wf_e", avg=0.6)

        current = ExperimentResults(
            workflow="wf_e", iterations=3, scores=[0.9, 0.9, 0.9],
        )
        report = current.check_regression(threshold=0.1, baseline_path=self.tmpdir)

        assert report.regressed is False
        assert report.delta < 0  # negative delta = improvement


# ---------------------------------------------------------------------------
# print_summary
# ---------------------------------------------------------------------------

class TestPrintSummary:
    def test_print_summary_basic(self, capsys):
        r = ExperimentResults(
            workflow="test_wf", iterations=3,
            scores=[0.8, 0.9, 0.7],
            duration_seconds=2.5,
            timestamp="2026-04-07T00:00:00Z",
        )
        output = r.print_summary()
        assert "test_wf" in output
        assert "0.800" in output  # avg
        assert "0.700" in output  # min
        assert "0.900" in output  # max

    def test_print_summary_with_errors(self, capsys):
        r = ExperimentResults(
            workflow="err_wf", iterations=2,
            scores=[0.5, 0.0],
            errors=["iter 2: connection timeout"],
        )
        output = r.print_summary()
        assert "connection timeout" in output

    def test_print_summary_with_task_scores(self):
        r = ExperimentResults(
            workflow="team_wf", iterations=2,
            scores=[0.8, 0.7],
            task_scores={"research": [0.9, 0.8], "write": [0.7, 0.6]},
        )
        output = r.print_summary()
        assert "research" in output
        assert "write" in output

    def test_print_summary_empty(self):
        r = ExperimentResults(workflow="empty", iterations=0)
        output = r.print_summary()
        assert "empty" in output


# ---------------------------------------------------------------------------
# ExperimentRunner — mocked workflow execution
# ---------------------------------------------------------------------------

class TestExperimentRunner:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = str(Path(self.tmpdir) / "test.db")
        # Create empty DB
        db = sqlite3.connect(self.db_path)
        db.close()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    @patch("aibrain.core.testing.run_workflow")
    def _patch_and_get_runner(self, mock_run):
        """Helper: unavailable since we need to patch at call site."""
        pass

    def test_run_workflow_collects_scores(self):
        runner = ExperimentRunner(db_path=self.db_path)

        mock_result = MagicMock()
        mock_result.quality = 0.85
        mock_result.error = None

        with patch("aibrain.core.workflow_runner.run_workflow", return_value=mock_result):
            results = runner.run("heartbeat", n_iterations=3)

        assert results.workflow == "heartbeat"
        assert results.iterations == 3
        assert len(results.scores) == 3
        assert all(s == 0.85 for s in results.scores)
        assert len(results.errors) == 0
        assert results.duration_seconds >= 0

    def test_run_workflow_captures_errors(self):
        runner = ExperimentRunner(db_path=self.db_path)

        mock_result = MagicMock()
        mock_result.quality = 0.0
        mock_result.error = "timeout"

        with patch("aibrain.core.workflow_runner.run_workflow", return_value=mock_result):
            results = runner.run("flaky_wf", n_iterations=2)

        assert len(results.errors) == 2
        assert all("timeout" in e for e in results.errors)

    def test_run_workflow_handles_exception(self):
        runner = ExperimentRunner(db_path=self.db_path)

        with patch("aibrain.core.workflow_runner.run_workflow",
                    side_effect=RuntimeError("workflow not found")):
            results = runner.run("missing_wf", n_iterations=2)

        assert len(results.scores) == 2
        assert all(s == 0.0 for s in results.scores)
        assert len(results.errors) == 2

    def test_run_saves_to_db(self):
        runner = ExperimentRunner(db_path=self.db_path)

        mock_result = MagicMock()
        mock_result.quality = 0.9
        mock_result.error = None

        with patch("aibrain.core.workflow_runner.run_workflow", return_value=mock_result):
            runner.run("heartbeat", n_iterations=2)

        # Verify DB has the row
        db = sqlite3.connect(self.db_path)
        db.row_factory = sqlite3.Row
        rows = db.execute("SELECT * FROM experiment_results").fetchall()
        db.close()

        assert len(rows) == 1
        assert rows[0]["workflow"] == "heartbeat"
        assert rows[0]["iterations"] == 2
        assert abs(rows[0]["avg_quality"] - 0.9) < 1e-9

    def test_run_team_collects_per_task_scores(self):
        runner = ExperimentRunner(db_path=self.db_path)

        # Build a mock team
        mock_task_output_1 = MagicMock()
        mock_task_output_1.task_id = "research"
        mock_task_output_1.agent_role = "Researcher"
        mock_task_output_1.quality = 0.9

        mock_task_output_2 = MagicMock()
        mock_task_output_2.task_id = "write"
        mock_task_output_2.agent_role = "Writer"
        mock_task_output_2.quality = 0.7

        mock_team_output = MagicMock()
        mock_team_output.task_outputs = [mock_task_output_1, mock_task_output_2]
        mock_team_output.success = True

        mock_team = MagicMock()
        mock_team.name = "content_team"
        mock_team.kickoff.return_value = mock_team_output

        results = runner.run_team(mock_team, n_iterations=2)

        assert results.workflow == "team:content_team"
        assert len(results.scores) == 2
        # Each run avg = (0.9 + 0.7) / 2 = 0.8
        assert all(abs(s - 0.8) < 1e-9 for s in results.scores)
        assert "research" in results.task_scores
        assert "write" in results.task_scores
        assert len(results.task_scores["research"]) == 2

    def test_run_team_handles_failure(self):
        runner = ExperimentRunner(db_path=self.db_path)

        mock_team = MagicMock()
        mock_team.name = "broken_team"
        mock_team.kickoff.side_effect = RuntimeError("LLM unavailable")

        results = runner.run_team(mock_team, n_iterations=2)

        assert len(results.scores) == 2
        assert all(s == 0.0 for s in results.scores)
        assert len(results.errors) == 2

    def test_history(self):
        runner = ExperimentRunner(db_path=self.db_path)

        mock_result = MagicMock()
        mock_result.quality = 0.8
        mock_result.error = None

        with patch("aibrain.core.workflow_runner.run_workflow", return_value=mock_result):
            runner.run("heartbeat", n_iterations=2)
            runner.run("heartbeat", n_iterations=3)

        history = runner.history("heartbeat")
        assert len(history) == 2
        # Most recent first
        assert history[0]["iterations"] == 3
        assert history[1]["iterations"] == 2


# ---------------------------------------------------------------------------
# RegressionReport model
# ---------------------------------------------------------------------------

class TestRegressionReport:
    def test_fields(self):
        report = RegressionReport(
            workflow="test",
            baseline_avg=0.9,
            current_avg=0.7,
            delta=0.2,
            regressed=True,
            threshold=0.1,
            message="quality dropped",
        )
        assert report.regressed is True
        assert report.delta == 0.2
        assert report.workflow == "test"
