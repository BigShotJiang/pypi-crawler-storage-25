"""
test_ingest.py — Tests for the document ingestion system.

Tests sentence-aware chunking, all source types, auto-detection,
incremental ingestion, Brain.ingest() integration, and metadata preservation.
"""

import csv
import json
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Ensure project root is importable
import sys
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from aibrain.core.ingest import (
    BaseKnowledgeSource,
    CSVSource,
    DirectorySource,
    ExcelSource,
    IngestionPipeline,
    IngestionResult,
    JSONSource,
    PDFSource,
    TextSource,
    chunk_text,
    detect_source,
    SOURCE_MAP,
    _check_source_hash,
    _ensure_ingestion_log,
    _record_ingestion,
)


# ---------------------------------------------------------------------------
# Sentence-aware chunking
# ---------------------------------------------------------------------------

class TestChunkText:
    """Test the sentence-aware chunking algorithm."""

    def test_empty_text_returns_empty(self):
        assert chunk_text("") == []
        assert chunk_text("   ") == []

    def test_short_text_single_chunk(self):
        text = "Hello world. This is a test."
        chunks = chunk_text(text, chunk_size=1000)
        assert len(chunks) == 1
        assert chunks[0]["content"].strip() != ""

    def test_splits_on_sentence_boundaries(self):
        # Build text with clear sentence boundaries
        sentences = [f"Sentence number {i} here." for i in range(20)]
        text = " ".join(sentences)
        chunks = chunk_text(text, chunk_size=100, chunk_overlap=20)
        # Should produce multiple chunks
        assert len(chunks) > 1
        # Each chunk should not wildly exceed chunk_size
        for c in chunks:
            # Allow some overshoot because we don't split mid-sentence
            assert len(c["content"]) < 200

    def test_chunk_metadata(self):
        text = "First sentence. Second sentence. Third sentence."
        chunks = chunk_text(text, chunk_size=30, chunk_overlap=0)
        for i, c in enumerate(chunks):
            assert c["metadata"]["chunk_index"] == i
            assert "char_start" in c["metadata"]
            assert "char_end" in c["metadata"]

    def test_custom_metadata_base(self):
        text = "A short sentence. Another one."
        chunks = chunk_text(text, chunk_size=1000, metadata_base={"source": "test.txt"})
        assert len(chunks) == 1
        assert chunks[0]["metadata"]["source"] == "test.txt"
        assert chunks[0]["metadata"]["chunk_index"] == 0

    def test_paragraph_split(self):
        text = "First paragraph content.\n\nSecond paragraph content."
        chunks = chunk_text(text, chunk_size=30, chunk_overlap=0)
        assert len(chunks) >= 2

    def test_overlap_carries_context(self):
        sentences = [f"Sentence {i} with some content." for i in range(10)]
        text = " ".join(sentences)
        chunks = chunk_text(text, chunk_size=80, chunk_overlap=40)
        if len(chunks) >= 2:
            # Content from end of chunk N should appear at start of chunk N+1
            # (overlap means shared content)
            last_words_0 = chunks[0]["content"].split()[-3:]
            first_words_1 = chunks[1]["content"].split()[:10]
            # At least some overlap should exist
            overlap_found = any(w in first_words_1 for w in last_words_0)
            assert overlap_found, "Expected overlap between consecutive chunks"


# ---------------------------------------------------------------------------
# TextSource
# ---------------------------------------------------------------------------

class TestTextSource:
    def test_from_string(self):
        src = TextSource(content="Hello world. This is content.")
        texts = src.load()
        assert len(texts) == 1
        assert "Hello world" in texts[0]

    def test_from_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("Line one. Line two. Line three.", encoding="utf-8")
        src = TextSource(path=str(f))
        texts = src.load()
        assert len(texts) == 1
        assert "Line one" in texts[0]

    def test_load_and_chunk(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("First sentence. Second sentence.", encoding="utf-8")
        src = TextSource(path=str(f))
        chunks = src.load_and_chunk()
        assert len(chunks) >= 1
        assert chunks[0]["metadata"]["source"] == str(f)

    def test_file_hash(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("content", encoding="utf-8")
        src = TextSource(path=str(f))
        h = src.file_hash()
        assert len(h) == 64  # SHA256 hex


# ---------------------------------------------------------------------------
# CSVSource
# ---------------------------------------------------------------------------

class TestCSVSource:
    def test_all_columns(self, tmp_path):
        f = tmp_path / "data.csv"
        with open(f, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=["name", "age", "city"])
            writer.writeheader()
            writer.writerow({"name": "Alice", "age": "30", "city": "NYC"})
            writer.writerow({"name": "Bob", "age": "25", "city": "LA"})

        src = CSVSource(path=str(f))
        rows = src.load()
        assert len(rows) == 2
        assert "name: Alice" in rows[0]
        assert "city: LA" in rows[1]

    def test_text_columns_filter(self, tmp_path):
        f = tmp_path / "data.csv"
        with open(f, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=["id", "description", "notes"])
            writer.writeheader()
            writer.writerow({"id": "1", "description": "Good item", "notes": "Check later"})

        src = CSVSource(path=str(f), text_columns=["description", "notes"])
        rows = src.load()
        assert len(rows) == 1
        assert "Good item" in rows[0]
        assert "Check later" in rows[0]
        assert "id" not in rows[0].lower().split(":")[0] if ":" in rows[0] else True

    def test_load_and_chunk_metadata(self, tmp_path):
        f = tmp_path / "data.csv"
        with open(f, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=["col1", "col2"])
            writer.writeheader()
            writer.writerow({"col1": "val1", "col2": "val2"})

        src = CSVSource(path=str(f))
        chunks = src.load_and_chunk()
        assert len(chunks) == 1
        assert chunks[0]["metadata"]["original_row"] == 1
        assert chunks[0]["metadata"]["source"] == str(f)


# ---------------------------------------------------------------------------
# JSONSource
# ---------------------------------------------------------------------------

class TestJSONSource:
    def test_flat_object(self, tmp_path):
        f = tmp_path / "data.json"
        f.write_text(json.dumps({"name": "Alice", "role": "engineer"}), encoding="utf-8")
        src = JSONSource(path=str(f))
        texts = src.load()
        assert len(texts) == 1
        assert "name: Alice" in texts[0]

    def test_nested_object(self, tmp_path):
        f = tmp_path / "data.json"
        data = {"user": {"name": "Bob", "prefs": {"theme": "dark"}}}
        f.write_text(json.dumps(data), encoding="utf-8")
        src = JSONSource(path=str(f))
        texts = src.load()
        assert len(texts) == 1
        assert "user.name: Bob" in texts[0]
        assert "user.prefs.theme: dark" in texts[0]

    def test_array_of_objects(self, tmp_path):
        f = tmp_path / "data.json"
        data = [{"id": 1, "text": "First"}, {"id": 2, "text": "Second"}]
        f.write_text(json.dumps(data), encoding="utf-8")
        src = JSONSource(path=str(f))
        texts = src.load()
        assert len(texts) == 2

    def test_text_keys_filter(self, tmp_path):
        f = tmp_path / "data.json"
        data = [{"id": 1, "body": "Important content", "meta": "ignore"}]
        f.write_text(json.dumps(data), encoding="utf-8")
        src = JSONSource(path=str(f), text_keys=["body"])
        texts = src.load()
        assert len(texts) == 1
        assert "Important content" in texts[0]
        assert "ignore" not in texts[0]

    def test_jsonl_format(self, tmp_path):
        f = tmp_path / "data.jsonl"
        lines = [json.dumps({"text": f"Line {i}"}) for i in range(3)]
        f.write_text("\n".join(lines), encoding="utf-8")
        src = JSONSource(path=str(f))
        texts = src.load()
        assert len(texts) == 3

    def test_load_and_chunk_metadata(self, tmp_path):
        f = tmp_path / "data.json"
        f.write_text(json.dumps([{"a": "1"}, {"b": "2"}]), encoding="utf-8")
        src = JSONSource(path=str(f))
        chunks = src.load_and_chunk()
        assert len(chunks) == 2
        assert chunks[0]["metadata"]["original_row"] == 1
        assert chunks[1]["metadata"]["original_row"] == 2


# ---------------------------------------------------------------------------
# Auto-detection
# ---------------------------------------------------------------------------

class TestAutoDetection:
    def test_txt_detected(self, tmp_path):
        f = tmp_path / "file.txt"
        f.write_text("hello", encoding="utf-8")
        src = detect_source(str(f))
        assert isinstance(src, TextSource)

    def test_md_detected(self, tmp_path):
        f = tmp_path / "file.md"
        f.write_text("# Title", encoding="utf-8")
        src = detect_source(str(f))
        assert isinstance(src, TextSource)

    def test_csv_detected(self, tmp_path):
        f = tmp_path / "file.csv"
        f.write_text("a,b\n1,2", encoding="utf-8")
        src = detect_source(str(f))
        assert isinstance(src, CSVSource)

    def test_json_detected(self, tmp_path):
        f = tmp_path / "file.json"
        f.write_text("{}", encoding="utf-8")
        src = detect_source(str(f))
        assert isinstance(src, JSONSource)

    def test_directory_detected(self, tmp_path):
        src = detect_source(str(tmp_path))
        assert isinstance(src, DirectorySource)

    def test_unsupported_raises(self, tmp_path):
        f = tmp_path / "file.xyz"
        f.write_text("data", encoding="utf-8")
        with pytest.raises(ValueError, match="Unsupported file type"):
            detect_source(str(f))

    def test_pdf_detected(self, tmp_path):
        f = tmp_path / "file.pdf"
        f.write_bytes(b"%PDF-1.4 fake")
        src = detect_source(str(f))
        assert isinstance(src, PDFSource)

    def test_xlsx_detected(self, tmp_path):
        f = tmp_path / "file.xlsx"
        f.write_bytes(b"fake")
        src = detect_source(str(f))
        assert isinstance(src, ExcelSource)


# ---------------------------------------------------------------------------
# Incremental ingestion (hash-based skip)
# ---------------------------------------------------------------------------

class TestIncrementalIngestion:
    def test_hash_check(self, tmp_path):
        db_path = tmp_path / "test.db"
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        _ensure_ingestion_log(db)

        # First time: not present
        assert not _check_source_hash(db, "/fake/file.txt", "abc123")

        # Record ingestion
        _record_ingestion(db, "/fake/file.txt", "abc123", 5, "default")

        # Same hash: unchanged
        assert _check_source_hash(db, "/fake/file.txt", "abc123")

        # Different hash: changed
        assert not _check_source_hash(db, "/fake/file.txt", "def456")

        db.close()


# ---------------------------------------------------------------------------
# Brain.ingest() integration
# ---------------------------------------------------------------------------

class TestBrainIngestIntegration:
    """Test the Brain.ingest() method end-to-end with a temp DB."""

    @pytest.fixture(autouse=True)
    def _bypass_tier_limits(self, monkeypatch):
        """Bypass tier limit checks — test DBs don't have license keys."""
        try:
            import aibrain_licensing
            monkeypatch.setattr(aibrain_licensing, "check_limit", lambda *a, **kw: None)
        except (ImportError, AttributeError):
            pass

    def test_ingest_text_file(self, tmp_path):
        db_path = tmp_path / "brain.db"
        # We need a minimal aibrain_db setup. Use Brain with custom db_path.
        # Brain.__init__ calls aibrain_db.get_db() which sets up tables.
        from aibrain.core.memory_api import Brain
        brain = Brain(db_path=str(db_path))

        # Create a text file
        txt = tmp_path / "doc.txt"
        txt.write_text(
            "Artificial intelligence is transforming industries. "
            "Machine learning models can process vast amounts of data. "
            "Natural language processing enables human-computer interaction.",
            encoding="utf-8",
        )

        result = brain.ingest(str(txt), collection="test_docs")
        assert isinstance(result, IngestionResult)
        assert result.memories_stored > 0
        assert result.source == str(txt)
        assert result.source_hash != ""
        assert len(result.errors) == 0

    def test_ingest_csv_file(self, tmp_path):
        db_path = tmp_path / "brain.db"
        from aibrain.core.memory_api import Brain
        brain = Brain(db_path=str(db_path))

        csv_file = tmp_path / "people.csv"
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["name", "role"])
            writer.writeheader()
            writer.writerow({"name": "Alice", "role": "Engineer"})
            writer.writerow({"name": "Bob", "role": "Designer"})

        result = brain.ingest(str(csv_file), collection="people")
        assert result.memories_stored == 2
        assert result.chunks_created == 2

    def test_ingest_skips_unchanged(self, tmp_path):
        db_path = tmp_path / "brain.db"
        from aibrain.core.memory_api import Brain
        brain = Brain(db_path=str(db_path))

        txt = tmp_path / "doc.txt"
        txt.write_text("Some content here.", encoding="utf-8")

        # First ingest
        r1 = brain.ingest(str(txt))
        assert not r1.skipped_unchanged
        assert r1.memories_stored > 0

        # Second ingest of same file — should skip
        r2 = brain.ingest(str(txt))
        assert r2.skipped_unchanged

    def test_ingest_json(self, tmp_path):
        db_path = tmp_path / "brain.db"
        from aibrain.core.memory_api import Brain
        brain = Brain(db_path=str(db_path))

        jf = tmp_path / "data.json"
        jf.write_text(json.dumps([
            {"topic": "AI", "detail": "Neural networks are powerful."},
            {"topic": "DB", "detail": "SQLite is lightweight."},
        ]), encoding="utf-8")

        result = brain.ingest(str(jf), collection="notes")
        assert result.memories_stored == 2


# ---------------------------------------------------------------------------
# Directory ingestion
# ---------------------------------------------------------------------------

class TestDirectoryIngestion:
    @pytest.fixture(autouse=True)
    def _bypass_tier_limits(self, monkeypatch):
        """Bypass tier limit checks — test DBs don't have license keys."""
        try:
            import aibrain_licensing
            monkeypatch.setattr(aibrain_licensing, "check_limit", lambda *a, **kw: None)
        except (ImportError, AttributeError):
            pass

    def test_mixed_file_types(self, tmp_path):
        # Create various files
        (tmp_path / "readme.txt").write_text("This is a readme.", encoding="utf-8")
        (tmp_path / "notes.md").write_text("# Notes\nSome notes.", encoding="utf-8")

        csv_file = tmp_path / "data.csv"
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["x"])
            writer.writeheader()
            writer.writerow({"x": "val"})

        (tmp_path / "config.json").write_text(json.dumps({"key": "value"}), encoding="utf-8")

        # Unsupported file should be skipped
        (tmp_path / "image.png").write_bytes(b"\x89PNG")

        src = DirectorySource(path=str(tmp_path))
        sources = src.iter_sources()
        extensions = {Path(str(p)).suffix for p, _ in sources}
        assert ".txt" in extensions
        assert ".md" in extensions
        assert ".csv" in extensions
        assert ".json" in extensions
        assert ".png" not in extensions

    def test_directory_ingest_pipeline(self, tmp_path):
        db_path = tmp_path / "brain.db"
        from aibrain.core.memory_api import Brain
        brain = Brain(db_path=str(db_path))

        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "a.txt").write_text("Document A content.", encoding="utf-8")
        (docs / "b.txt").write_text("Document B content.", encoding="utf-8")

        pipeline = IngestionPipeline(brain=brain)
        result = pipeline.ingest_directory(str(docs))
        assert result.memories_stored >= 2
        assert len(result.errors) == 0

    def test_directory_bad_file_no_crash(self, tmp_path):
        """A broken file should not crash directory ingestion."""
        db_path = tmp_path / "brain.db"
        from aibrain.core.memory_api import Brain
        brain = Brain(db_path=str(db_path))

        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "good.txt").write_text("Good content.", encoding="utf-8")
        # A CSV with invalid encoding shouldn't crash the pipeline
        (docs / "weird.csv").write_bytes(b"a,b\n\xff\xfe,\x00\x01")

        pipeline = IngestionPipeline(brain=brain)
        result = pipeline.ingest_directory(str(docs))
        # Should still have ingested the good file
        assert result.memories_stored >= 1


# ---------------------------------------------------------------------------
# Chunk metadata preservation
# ---------------------------------------------------------------------------

class TestChunkMetadata:
    def test_text_chunk_has_source(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("Content for testing metadata.", encoding="utf-8")
        src = TextSource(path=str(f))
        chunks = src.load_and_chunk()
        assert all(c["metadata"]["source"] == str(f) for c in chunks)

    def test_csv_chunk_has_row_number(self, tmp_path):
        f = tmp_path / "data.csv"
        with open(f, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=["val"])
            writer.writeheader()
            for i in range(3):
                writer.writerow({"val": f"row{i}"})

        src = CSVSource(path=str(f))
        chunks = src.load_and_chunk()
        assert len(chunks) == 3
        assert chunks[0]["metadata"]["original_row"] == 1
        assert chunks[2]["metadata"]["original_row"] == 3

    def test_json_chunk_has_row(self, tmp_path):
        f = tmp_path / "data.json"
        f.write_text(json.dumps([{"a": 1}, {"b": 2}]), encoding="utf-8")
        src = JSONSource(path=str(f))
        chunks = src.load_and_chunk()
        assert chunks[0]["metadata"]["original_row"] == 1
        assert chunks[1]["metadata"]["original_row"] == 2


# ---------------------------------------------------------------------------
# IngestionResult model
# ---------------------------------------------------------------------------

class TestIngestionResult:
    def test_defaults(self):
        r = IngestionResult()
        assert r.chunks_created == 0
        assert r.memories_stored == 0
        assert r.errors == []
        assert r.duration_seconds == 0.0
        assert r.source_hash == ""  # noqa:PLAIN SECRET COMPARISON
        assert r.skipped_unchanged is False

    def test_serialization(self):
        r = IngestionResult(source="test.pdf", chunks_created=10, memories_stored=8)
        d = r.model_dump()
        assert d["source"] == "test.pdf"
        assert d["chunks_created"] == 10
