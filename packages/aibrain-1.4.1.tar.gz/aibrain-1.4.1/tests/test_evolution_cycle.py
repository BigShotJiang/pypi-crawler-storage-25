"""Tests for the evolution cycle — verifies pattern detection actually works."""

import json
import sqlite3
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))
from evolution_engine import (
    get_evolution_db,
    record_outcome,
    run_evolution_cycle,
    detect_patterns,
    detect_positive_patterns,
    _detect_correction_patterns,
    _detect_execution_log_patterns,
    _persist_detected_patterns,
)


@pytest.fixture
def tmp_db(tmp_path):
    """Create a temporary DB with evolution tables."""
    db_path = tmp_path / "test_evo.db"
    db = get_evolution_db(db_path)
    # Also create execution_log table for those tests
    db.execute("""
        CREATE TABLE IF NOT EXISTS execution_log (
            id TEXT PRIMARY KEY,
            run_id TEXT,
            actor TEXT,
            action TEXT,
            entity_type TEXT,
            entity_id TEXT,
            detail TEXT,
            quality_score REAL,
            model_used TEXT,
            cost_cents INTEGER,
            duration_ms INTEGER,
            before_state TEXT,
            after_state TEXT,
            success INTEGER,
            error TEXT,
            task_type TEXT,
            authority TEXT,
            retries INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.commit()
    db.close()
    return db_path


def _seed_outcomes(db_path, outcomes):
    """Insert outcome records into the DB."""
    db = get_evolution_db(db_path)
    for o in outcomes:
        db.execute(
            """INSERT INTO evolution_outcomes
               (source, action, result, details, failure_reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (o.get("source", "workflow"),
             o["action"],
             o["result"],
             o.get("details"),
             o.get("failure_reason"),
             o.get("created_at", datetime.utcnow().isoformat()))
        )
    db.commit()
    db.close()


def _seed_exec_log(db_path, entries):
    """Insert execution_log entries."""
    db = get_evolution_db(db_path)
    for i, e in enumerate(entries):
        db.execute(
            """INSERT INTO execution_log
               (id, run_id, actor, action, quality_score, success, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (f"id_{i}", f"run_{i}",
             e.get("actor", "system"),
             e["action"],
             e.get("quality_score"),
             e.get("success", 1),
             e.get("created_at", datetime.utcnow().isoformat()))
        )
    db.commit()
    db.close()


class TestRunEvolutionCycle:
    """Test that run_evolution_cycle finds patterns from various data sources."""

    def test_cycle_finds_failure_patterns(self, tmp_db):
        """Two failures with the same reason should create a pattern."""
        now = datetime.utcnow().isoformat()
        _seed_outcomes(tmp_db, [
            {"action": "deploy", "result": "failure", "failure_reason": "timeout", "created_at": now},
            {"action": "deploy", "result": "failure", "failure_reason": "timeout", "created_at": now},
        ])
        result = run_evolution_cycle(tmp_db, agent="test")
        assert result["failure_patterns_found"] >= 1
        assert result["outcomes_analyzed"] >= 2

    def test_cycle_finds_correction_patterns(self, tmp_db):
        """Repeated corrections should be detected."""
        now = datetime.utcnow().isoformat()
        _seed_outcomes(tmp_db, [
            {"action": "email_triage", "result": "learned", "created_at": now},
            {"action": "email_triage", "result": "learned", "created_at": now},
            {"action": "email_triage", "result": "learned", "created_at": now},
        ])
        result = run_evolution_cycle(tmp_db, agent="test")
        assert result["correction_patterns_found"] >= 1
        corrections = result["correction_patterns"]
        assert any(p["action"] == "email_triage" for p in corrections)

    def test_cycle_finds_positive_patterns(self, tmp_db):
        """Consistent successes should yield positive patterns."""
        now = datetime.utcnow().isoformat()
        _seed_outcomes(tmp_db, [
            {"action": "backup", "result": "success", "created_at": now},
            {"action": "backup", "result": "success", "created_at": now},
            {"action": "backup", "result": "success", "created_at": now},
        ])
        result = run_evolution_cycle(tmp_db, agent="test")
        assert result["positive_patterns_found"] >= 1

    def test_cycle_detects_exec_log_quality(self, tmp_db):
        """Low-quality workflows in execution_log should be flagged."""
        now = datetime.utcnow().isoformat()
        _seed_exec_log(tmp_db, [
            {"action": "flaky_job", "quality_score": 0.3, "created_at": now},
            {"action": "flaky_job", "quality_score": 0.4, "created_at": now},
            {"action": "flaky_job", "quality_score": 0.2, "created_at": now},
        ])
        result = run_evolution_cycle(tmp_db, agent="test")
        assert result["exec_log_patterns_found"] >= 1
        low_q = [p for p in result["exec_log_patterns"] if p["type"] == "low_quality_workflow"]
        assert len(low_q) >= 1
        assert low_q[0]["action"] == "flaky_job"

    def test_cycle_detects_high_quality_workflow(self, tmp_db):
        """High-quality workflows should also be detected as patterns."""
        now = datetime.utcnow().isoformat()
        _seed_exec_log(tmp_db, [
            {"action": "reliable_job", "quality_score": 0.95, "created_at": now},
            {"action": "reliable_job", "quality_score": 0.92, "created_at": now},
            {"action": "reliable_job", "quality_score": 0.98, "created_at": now},
        ])
        result = run_evolution_cycle(tmp_db, agent="test")
        high_q = [p for p in result["exec_log_patterns"] if p["type"] == "high_quality_workflow"]
        assert len(high_q) >= 1
        assert high_q[0]["action"] == "reliable_job"

    def test_cycle_with_empty_db(self, tmp_db):
        """Cycle should handle empty DB gracefully (no crash, 0 patterns)."""
        result = run_evolution_cycle(tmp_db, agent="test")
        assert result["outcomes_analyzed"] == 0
        assert result["total_new_patterns"] == 0

    def test_cycle_alltime_fallback(self, tmp_db):
        """When lookback window has no data but DB has old data, fall back to all-time."""
        old_date = (datetime.utcnow() - timedelta(days=30)).isoformat()
        _seed_outcomes(tmp_db, [
            {"action": "old_job", "result": "success", "created_at": old_date},
            {"action": "old_job", "result": "success", "created_at": old_date},
        ])
        # Lookback of 1 hour won't find 30-day-old data, but fallback should
        result = run_evolution_cycle(tmp_db, agent="test", lookback_hours=1)
        assert result["outcomes_analyzed"] >= 2

    def test_persist_detected_patterns(self, tmp_db):
        """_persist_detected_patterns should create new pattern rows."""
        db = get_evolution_db(tmp_db)
        patterns = [
            {"description": "Test pattern alpha", "count": 5},
            {"description": "Test pattern beta", "count": 3},
        ]
        new_count = _persist_detected_patterns(db, patterns)
        db.commit()
        assert new_count == 2

        # Running again should NOT create duplicates
        new_count2 = _persist_detected_patterns(db, patterns)
        db.commit()
        assert new_count2 == 0
        db.close()

    def test_agent_performance_detection(self, tmp_db):
        """Agent performance patterns from execution_log should be detected."""
        now = datetime.utcnow().isoformat()
        _seed_exec_log(tmp_db, [
            {"action": "task_a", "actor": "agent_x", "quality_score": 0.95, "created_at": now},
            {"action": "task_b", "actor": "agent_x", "quality_score": 0.90, "created_at": now},
            {"action": "task_c", "actor": "agent_x", "quality_score": 0.88, "created_at": now},
        ])
        db = get_evolution_db(tmp_db)
        patterns = _detect_execution_log_patterns(db, lookback_hours=168)
        db.close()
        agent_perf = [p for p in patterns if p["type"] == "agent_performance"]
        assert len(agent_perf) >= 1
        assert agent_perf[0]["action"] == "agent_x"

    def test_cycle_records_to_cycles_table(self, tmp_db):
        """Each cycle should create a row in evolution_cycles with summary."""
        _seed_outcomes(tmp_db, [
            {"action": "x", "result": "success", "created_at": datetime.utcnow().isoformat()},
        ])
        result = run_evolution_cycle(tmp_db, agent="test_agent")
        db = get_evolution_db(tmp_db)
        row = db.execute(
            "SELECT * FROM evolution_cycles WHERE id = ?", (result["cycle_id"],)
        ).fetchone()
        db.close()
        assert row is not None
        assert row["agent"] == "test_agent"
        assert row["completed_at"] is not None
        summary = json.loads(row["summary"])
        assert "outcomes_analyzed" in summary
