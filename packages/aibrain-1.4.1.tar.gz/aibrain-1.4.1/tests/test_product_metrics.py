"""Tests for aibrain.core.product_metrics — one per claim."""

import sqlite3
import tempfile
from pathlib import Path

import pytest

from aibrain.core.product_metrics import (
    measure_self_improving,
    measure_embedded_memory,
    measure_smart_retrieval,
    measure_portable,
    measure_zero_config,
    product_dashboard,
)


@pytest.fixture
def test_db(tmp_path):
    """Create a minimal aibrain.db with enough schema for all 5 metrics."""
    db = str(tmp_path / "test.db")
    conn = sqlite3.connect(db)
    c = conn.cursor()

    c.execute("""CREATE TABLE evolution_outcomes (
        id INTEGER PRIMARY KEY, source TEXT, source_id TEXT,
        action TEXT, result TEXT, details TEXT, failure_reason TEXT,
        duration_seconds REAL, created_at TIMESTAMP)""")

    c.execute("""CREATE TABLE memories (
        id INTEGER PRIMARY KEY, name TEXT, type TEXT, tags TEXT,
        content TEXT, created TEXT, updated TEXT, active INTEGER,
        memory_class TEXT, importance REAL, access_count INTEGER,
        last_accessed TEXT, source_agent TEXT, consolidated_from TEXT,
        user_id TEXT, agent_id TEXT, storage_strength REAL,
        status VARCHAR(20), superseded_by INTEGER)""")

    c.execute("""CREATE TABLE category_summaries (
        category TEXT, summary TEXT, memory_count INTEGER,
        avg_importance REAL, top_keywords TEXT, embedding BLOB,
        last_updated TEXT)""")

    c.execute("""CREATE TABLE sync_state (
        agent_id TEXT, last_export TEXT, last_import TEXT,
        records_exported INTEGER, records_imported INTEGER)""")

    c.execute("""CREATE TABLE execution_log (
        id TEXT, run_id TEXT, actor TEXT, action TEXT,
        entity_type TEXT, entity_id TEXT, detail TEXT,
        quality_score REAL, model_used TEXT, cost_cents INTEGER,
        duration_ms INTEGER, before_state TEXT, after_state TEXT,
        success INTEGER, error TEXT, task_type TEXT, authority TEXT,
        retries INTEGER, created_at TIMESTAMP)""")

    c.execute("""CREATE TABLE setup_steps (id INTEGER PRIMARY KEY, step TEXT)""")
    c.execute("""CREATE TABLE config (key TEXT, value TEXT)""")

    # Seed: 2 windows of evolution outcomes (correction rate decreasing)
    # Window 0: 5 corrections / 10 total = 50%
    for i in range(10):
        action = "correction" if i < 5 else "completion"
        c.execute("INSERT INTO evolution_outcomes (source, action, result, created_at) VALUES (?, ?, ?, ?)",
                  ("memory" if i < 3 else "harness", action, "success", "2026-04-01 12:00:00"))
    # Window 1: 2 corrections / 10 total = 20%
    for i in range(10):
        action = "correction" if i < 2 else "completion"
        c.execute("INSERT INTO evolution_outcomes (source, action, result, created_at) VALUES (?, ?, ?, ?)",
                  ("memory" if i < 2 else "harness", action, "success", "2026-04-09 12:00:00"))

    # Seed memories
    for i in range(20):
        c.execute("""INSERT INTO memories (name, type, content, created, active, importance,
                     access_count, source_agent) VALUES (?, ?, ?, ?, 1, ?, ?, ?)""",
                  (f"mem_{i}", "project", f"content {i}", "2026-03-20 00:00:00",
                   0.8 if i < 5 else 0.4, i if i < 10 else 0,
                   "neuro" if i < 12 else "case"))

    # Seed category summaries
    c.execute("INSERT INTO category_summaries (category, memory_count, avg_importance) VALUES (?, ?, ?)",
              ("project", 15, 0.6))
    c.execute("INSERT INTO category_summaries (category, memory_count, avg_importance) VALUES (?, ?, ?)",
              ("reference", 5, 0.4))

    # Seed sync_state
    c.execute("INSERT INTO sync_state VALUES (?, ?, ?, ?, ?)",
              ("neuro", "2026-04-09T10:00:00", None, 500, 0))
    c.execute("INSERT INTO sync_state VALUES (?, ?, ?, ?, ?)",
              ("case", None, "2026-04-09T10:00:00", 0, 200))

    # Seed execution_log
    c.execute("INSERT INTO execution_log (action, success, created_at) VALUES (?, ?, ?)",
              ("heartbeat", 1, "2026-04-01 00:05:00"))

    # Seed config
    c.execute("INSERT INTO config VALUES ('mode', 'hive')")

    conn.commit()
    conn.close()
    return db


def test_self_improving(test_db):
    result = measure_self_improving(days=30, db_path=test_db)
    assert result["claim"] == "Self-improving"
    assert result["trend"] == "improving"
    assert len(result["windows"]) >= 2
    # First window correction rate > last window
    assert result["windows"][0]["correction_rate"] > result["windows"][-1]["correction_rate"]


def test_embedded_memory(test_db):
    result = measure_embedded_memory(db_path=test_db)
    assert result["claim"] == "Embedded memory"
    assert result["active_memories"] == 20
    assert result["accessed_memories"] == 9  # i=1..9 have access_count > 0
    assert result["recall_precision"] > 0
    assert result["memory_assist_rate"] > 0  # 5 memory-sourced outcomes


def test_smart_retrieval(test_db):
    result = measure_smart_retrieval(db_path=test_db)
    assert result["claim"] == "Smart retrieval"
    assert result["tier1_categories"] == 2
    assert result["tier1_memory_coverage"] == 20
    assert result["total_active_memories"] == 20
    assert result["coverage_rate"] == 1.0


def test_portable(test_db):
    result = measure_portable(db_path=test_db)
    assert result["claim"] == "Portable"
    assert result["total_exported"] == 500
    assert result["total_imported"] == 200
    assert result["distinct_source_agents"] == 2  # neuro, case
    assert len(result["sync_agents"]) == 2


def test_zero_config(test_db):
    result = measure_zero_config(db_path=test_db)
    assert result["claim"] == "Zero config"
    assert result["first_memory_at"] is not None
    assert result["first_execution_at"] is not None
    assert result["onboarding_seconds"] is not None
    assert result["onboarding_seconds"] >= 0
    assert result["config_entries"] == 1


def test_product_dashboard(test_db):
    result = product_dashboard(db_path=test_db)
    assert set(result.keys()) == {"self_improving", "embedded_memory", "smart_retrieval", "portable", "zero_config"}
    for key, val in result.items():
        assert "claim" in val, f"Missing 'claim' key in {key}"
