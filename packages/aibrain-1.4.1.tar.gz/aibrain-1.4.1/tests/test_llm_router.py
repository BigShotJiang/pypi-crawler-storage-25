"""
Tests for backend/llm_router.py — LLM routing, cost tracking, model discovery.

Covers: DEFAULT_ROUTING, _load_config, cost DB, cost queries, list_models.
Uses tmp_path for DB isolation.
"""

import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


@pytest.fixture(autouse=True)
def isolated_router(tmp_path, monkeypatch):
    """Isolate the router module from real config and cost DB."""
    monkeypatch.setattr("backend.llm_router.COST_DB_PATH", tmp_path / "test_costs.db")
    monkeypatch.setattr("backend.llm_router.CONFIG_FILE", tmp_path / "test_config.json")
    return tmp_path


import backend.llm_router as router
from backend.llm_router import (
    DEFAULT_ROUTING,
    _get_cost_db,
    _guess_provider,
    _load_config,
    _log_cost,
    complete,
    get_cost_by_model,
    get_cost_summary,
    get_daily_costs,
    list_models,
)


# ---------------------------------------------------------------------------
# DEFAULT_ROUTING
# ---------------------------------------------------------------------------

class TestDefaultRouting:
    def test_has_all_categories(self):
        expected = {"deterministic", "simple", "judgment", "complex", "creative", "default"}
        assert expected.issubset(set(DEFAULT_ROUTING.keys()))

    def test_deterministic_is_empty(self):
        assert DEFAULT_ROUTING["deterministic"] == []

    def test_simple_has_models(self):
        assert len(DEFAULT_ROUTING["simple"]) > 0

    def test_judgment_has_models(self):
        assert len(DEFAULT_ROUTING["judgment"]) > 0

    def test_complex_has_models(self):
        assert len(DEFAULT_ROUTING["complex"]) > 0

    def test_default_has_models(self):
        assert len(DEFAULT_ROUTING["default"]) > 0

    def test_all_values_are_lists(self):
        for cat, models in DEFAULT_ROUTING.items():
            assert isinstance(models, list), f"{cat} routing is not a list"

    def test_all_model_names_are_strings(self):
        for cat, models in DEFAULT_ROUTING.items():
            for m in models:
                assert isinstance(m, str), f"Model {m} in {cat} is not a string"

    def test_simple_prefers_local_first(self):
        # First model in simple should be an ollama (local) model
        assert DEFAULT_ROUTING["simple"][0].startswith("ollama/")


# ---------------------------------------------------------------------------
# _load_config
# ---------------------------------------------------------------------------

class TestLoadConfig:
    def test_missing_file_returns_empty_dict(self):
        assert _load_config() == {}

    def test_valid_config_file(self, isolated_router):
        config = {"llm_provider": "claude", "anthropic_api_key": "sk-test"}
        (isolated_router / "test_config.json").write_text(json.dumps(config))
        result = _load_config()
        assert result["llm_provider"] == "claude"

    def test_invalid_json_returns_empty(self, isolated_router):
        (isolated_router / "test_config.json").write_text("{invalid json")
        assert _load_config() == {}

    def test_empty_file_returns_empty(self, isolated_router):
        (isolated_router / "test_config.json").write_text("")
        assert _load_config() == {}


# ---------------------------------------------------------------------------
# Cost DB creation
# ---------------------------------------------------------------------------

class TestCostDB:
    def test_creates_db(self):
        db = _get_cost_db()
        assert db is not None
        # Table should exist
        row = db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='llm_costs'"
        ).fetchone()
        assert row is not None
        db.close()

    def test_has_expected_columns(self):
        db = _get_cost_db()
        cursor = db.execute("PRAGMA table_info(llm_costs)")
        columns = {row[1] for row in cursor.fetchall()}
        expected = {"id", "timestamp", "model", "category", "tokens_in", "tokens_out",
                    "cost_usd", "latency_ms", "workflow_id", "success", "error_msg"}
        assert expected.issubset(columns)
        db.close()

    def test_has_indexes(self):
        db = _get_cost_db()
        rows = db.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='llm_costs'"
        ).fetchall()
        index_names = {r[0] for r in rows}
        assert "idx_llm_costs_timestamp" in index_names
        assert "idx_llm_costs_model" in index_names
        db.close()


# ---------------------------------------------------------------------------
# _log_cost
# ---------------------------------------------------------------------------

class TestLogCost:
    def test_log_inserts_row(self):
        _log_cost("test-model", "simple", 100, 50, 0.001, 200)
        db = _get_cost_db()
        count = db.execute("SELECT COUNT(*) FROM llm_costs").fetchone()[0]
        assert count == 1
        db.close()

    def test_log_stores_correct_data(self):
        _log_cost("gpt-4o", "judgment", 500, 200, 0.05, 1500, workflow_id="test_wf")
        db = _get_cost_db()
        row = db.execute("SELECT * FROM llm_costs ORDER BY id DESC LIMIT 1").fetchone()
        assert row["model"] == "gpt-4o"
        assert row["category"] == "judgment"
        assert row["tokens_in"] == 500
        assert row["tokens_out"] == 200
        assert row["cost_usd"] == 0.05
        assert row["latency_ms"] == 1500
        assert row["workflow_id"] == "test_wf"
        assert row["success"] == 1
        db.close()

    def test_log_failure(self):
        _log_cost("bad-model", "simple", 0, 0, 0.0, 100, success=False, error_msg="timeout")
        db = _get_cost_db()
        row = db.execute("SELECT * FROM llm_costs ORDER BY id DESC LIMIT 1").fetchone()
        assert row["success"] == 0
        assert row["error_msg"] == "timeout"
        db.close()

    def test_log_multiple(self):
        for i in range(10):
            _log_cost(f"model-{i}", "simple", i * 10, i * 5, i * 0.001, i * 100)
        db = _get_cost_db()
        count = db.execute("SELECT COUNT(*) FROM llm_costs").fetchone()[0]
        assert count == 10
        db.close()


# ---------------------------------------------------------------------------
# Cost summary functions
# ---------------------------------------------------------------------------

class TestCostSummary:
    def test_empty_db_summary(self):
        summary = get_cost_summary(days=30)
        assert summary["total_calls"] == 0
        assert summary["total_cost_usd"] == 0.0
        assert summary["period_days"] == 30

    def test_summary_with_data(self):
        _log_cost("m1", "simple", 100, 50, 0.01, 200)
        _log_cost("m2", "judgment", 200, 100, 0.05, 300)
        summary = get_cost_summary(days=30)
        assert summary["total_calls"] == 2
        assert summary["total_tokens_in"] == 300
        assert summary["total_tokens_out"] == 150
        assert summary["total_cost_usd"] == 0.06

    def test_summary_has_all_keys(self):
        summary = get_cost_summary()
        required = {"period_days", "total_calls", "successful_calls",
                    "total_tokens_in", "total_tokens_out",
                    "total_cost_usd", "avg_latency_ms"}
        assert required.issubset(summary.keys())


class TestDailyCosts:
    def test_empty_db(self):
        result = get_daily_costs(days=7)
        assert result == []

    def test_with_data(self):
        _log_cost("m1", "simple", 100, 50, 0.01, 200)
        result = get_daily_costs(days=7)
        assert len(result) >= 1
        day = result[0]
        assert "day" in day
        assert "calls" in day
        assert "cost_usd" in day

    def test_daily_aggregation(self):
        # Log multiple calls
        _log_cost("m1", "simple", 100, 50, 0.01, 200)
        _log_cost("m2", "simple", 200, 100, 0.02, 300)
        result = get_daily_costs(days=1)
        assert len(result) == 1
        assert result[0]["calls"] == 2
        assert result[0]["cost_usd"] == 0.03


class TestCostByModel:
    def test_empty_db(self):
        assert get_cost_by_model() == []

    def test_groups_by_model(self):
        _log_cost("m1", "simple", 100, 50, 0.01, 200)
        _log_cost("m1", "simple", 100, 50, 0.01, 200)
        _log_cost("m2", "judgment", 200, 100, 0.05, 300)
        result = get_cost_by_model()
        assert len(result) == 2
        models = {r["model"] for r in result}
        assert "m1" in models
        assert "m2" in models


# ---------------------------------------------------------------------------
# list_models
# ---------------------------------------------------------------------------

class TestListModels:
    def test_returns_list(self):
        result = list_models()
        assert isinstance(result, list)

    def test_has_models(self):
        result = list_models()
        assert len(result) > 0

    def test_model_has_required_fields(self):
        result = list_models()
        for m in result:
            assert "model" in m
            assert "status" in m
            assert "provider" in m
            assert "categories" in m

    def test_claude_model_detected(self):
        result = list_models()
        claude_models = [m for m in result if m["provider"] == "anthropic"]
        assert len(claude_models) > 0

    def test_ollama_models_detected(self):
        result = list_models()
        ollama_models = [m for m in result if m["provider"] == "ollama"]
        assert len(ollama_models) > 0


# ---------------------------------------------------------------------------
# _guess_provider
# ---------------------------------------------------------------------------

class TestGuessProvider:
    def test_ollama_prefix(self):
        assert _guess_provider("ollama/qwen2.5:7b") == "ollama"

    def test_claude_in_name(self):
        assert _guess_provider("claude-sonnet-4-20250514") == "anthropic"

    def test_gpt_in_name(self):
        assert _guess_provider("gpt-4o") == "openai"

    def test_o3_mini(self):
        assert _guess_provider("o3-mini") == "openai"

    def test_gemini(self):
        assert _guess_provider("gemini-2.5-pro") == "google"

    def test_unknown(self):
        assert _guess_provider("some-random-model") == "unknown"


# ---------------------------------------------------------------------------
# complete() deterministic shortcut
# ---------------------------------------------------------------------------

class TestCompleteDeterministic:
    def test_deterministic_skips_llm(self):
        result = complete("echo hello", category="deterministic")
        assert result["model"] == "code_only"
        assert result["tokens_in"] == 0
        assert result["cost_usd"] == 0.0
        assert result["provider"] == "none"
        assert result["content"] == "echo hello"
