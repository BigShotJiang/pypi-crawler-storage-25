"""
Tests for aibrain.tools.learn.config — learning configuration menu.

Covers: load/save round-trip, defaults, signal toggles, scale clamping,
config-driven learner integration, non-tty fallback, cache invalidation,
missing file fallback, TOML parsing, and menu rendering.
"""
from __future__ import annotations

import io
import sys
from pathlib import Path
from unittest import mock

import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def isolate_config(tmp_path, monkeypatch):
    """Redirect learn.toml to a temp dir so tests don't touch real config."""
    fake_path = tmp_path / 'learn.toml'
    import aibrain.tools.learn.config as mod
    monkeypatch.setattr(mod, '_CONFIG_PATH', fake_path)
    mod._invalidate_cache()
    yield fake_path
    mod._invalidate_cache()


# ---------------------------------------------------------------------------
# 1. Defaults when no config file exists
# ---------------------------------------------------------------------------

def test_defaults_no_file(isolate_config):
    """load_learn_config returns hardcoded defaults when learn.toml is absent."""
    from aibrain.tools.learn.config import load_learn_config, _invalidate_cache
    _invalidate_cache()
    cfg = load_learn_config()

    assert cfg['min_msg_length'] == 40
    assert cfg['max_per_run'] == 10
    assert cfg['precompact_limit'] == 25
    assert cfg['watch_interval_min'] == 15
    assert all(v is True for v in cfg['signals'].values())
    assert cfg['importance']['corrections'] == 0.8
    assert cfg['importance']['completions'] == 0.4


# ---------------------------------------------------------------------------
# 2. Save and reload round-trip
# ---------------------------------------------------------------------------

def test_save_load_roundtrip(isolate_config):
    """Saved config is faithfully reloaded."""
    from aibrain.tools.learn.config import _save_config, load_learn_config, _invalidate_cache

    _save_config(
        signal_states={'corrections': False, 'fixes': True, 'discoveries': True,
                       'decisions': False, 'completions': True},
        importance={'corrections': 0.9, 'fixes': 0.6, 'discoveries': 0.5,
                    'decisions': 0.3, 'completions': 0.2},
        scale_values={'min_msg_length': 80, 'max_per_run': 3,
                      'precompact_limit': 50, 'watch_interval_min': 30},
    )
    _invalidate_cache()
    cfg = load_learn_config()

    assert cfg['min_msg_length'] == 80
    assert cfg['max_per_run'] == 3
    assert cfg['precompact_limit'] == 50
    assert cfg['watch_interval_min'] == 30
    assert cfg['signals']['corrections'] is False
    assert cfg['signals']['decisions'] is False
    assert cfg['signals']['fixes'] is True
    assert cfg['importance']['corrections'] == 0.9
    assert cfg['importance']['completions'] == 0.2


# ---------------------------------------------------------------------------
# 3. Signal type toggling affects detect_signals in realtime_learner
# ---------------------------------------------------------------------------

def test_signal_toggle_disables_detection(isolate_config):
    """Disabling a signal type in config prevents detect_signals from matching it."""
    from aibrain.tools.learn.config import _save_config, _invalidate_cache

    # Disable corrections
    _save_config(
        signal_states={'corrections': False, 'fixes': True, 'discoveries': True,
                       'decisions': True, 'completions': True},
        importance={'corrections': 0.8, 'fixes': 0.7, 'discoveries': 0.7,
                    'decisions': 0.6, 'completions': 0.4},
        scale_values={'min_msg_length': 40, 'max_per_run': 10,
                      'precompact_limit': 25, 'watch_interval_min': 15},
    )
    _invalidate_cache()

    # Reimport to pick up new config
    import importlib
    import realtime_learner as rl
    # Reload the config in the learner
    from aibrain.tools.learn.config import load_learn_config
    rl._learn_cfg = load_learn_config()

    text = "I was wrong about the configuration, actually it turns out the file was elsewhere and needs fixing"
    signals = rl.detect_signals(text)
    # correction should NOT appear (disabled), but fix might
    assert 'correction' not in signals


# ---------------------------------------------------------------------------
# 4. Scale clamping (menu logic)
# ---------------------------------------------------------------------------

def test_scale_clamp_min():
    """Scale values cannot go below their defined minimum."""
    from aibrain.tools.learn.config import _SCALE_ITEMS

    for key, label, step, min_val, max_val, unit in _SCALE_ITEMS:
        # Simulate pressing - at minimum: val should stay at min
        val = min_val
        new_val = max(val - step, min_val)
        assert new_val == min_val


def test_scale_clamp_max():
    """Scale values cannot exceed their defined maximum."""
    from aibrain.tools.learn.config import _SCALE_ITEMS

    for key, label, step, min_val, max_val, unit in _SCALE_ITEMS:
        val = max_val
        new_val = min(val + step, max_val)
        assert new_val == max_val


# ---------------------------------------------------------------------------
# 5. Cache invalidation
# ---------------------------------------------------------------------------

def test_cache_invalidation(isolate_config):
    """After _invalidate_cache, load picks up new file contents."""
    from aibrain.tools.learn.config import (
        load_learn_config, _save_config, _invalidate_cache
    )

    cfg1 = load_learn_config()
    assert cfg1['min_msg_length'] == 40

    _save_config(
        signal_states=cfg1['signals'],
        importance=cfg1['importance'],
        scale_values={**{k: cfg1[k] for k in ['min_msg_length', 'max_per_run',
                                                'precompact_limit', 'watch_interval_min']},
                      'min_msg_length': 100},
    )
    _invalidate_cache()
    cfg2 = load_learn_config()
    assert cfg2['min_msg_length'] == 100


# ---------------------------------------------------------------------------
# 6. Non-tty fallback prints key=value
# ---------------------------------------------------------------------------

def test_non_tty_fallback(isolate_config):
    """When stdout is not a tty, interactive_menu prints plain key=value lines."""
    from aibrain.tools.learn.config import interactive_menu

    buf = io.StringIO()
    with mock.patch.object(sys, 'stdout', buf):
        interactive_menu()

    output = buf.getvalue()
    assert 'min_msg_length=40' in output
    assert 'signals.corrections=enabled' in output
    assert 'importance.corrections=0.8' in output


# ---------------------------------------------------------------------------
# 7. Non-tty fallback reflects saved config
# ---------------------------------------------------------------------------

def test_non_tty_reflects_saved(isolate_config):
    """Non-tty output reflects persisted config, not just defaults."""
    from aibrain.tools.learn.config import _save_config, _invalidate_cache, interactive_menu

    _save_config(
        signal_states={'corrections': True, 'fixes': False, 'discoveries': True,
                       'decisions': True, 'completions': True},
        importance={'corrections': 0.8, 'fixes': 0.7, 'discoveries': 0.7,
                    'decisions': 0.6, 'completions': 0.4},
        scale_values={'min_msg_length': 75, 'max_per_run': 10,
                      'precompact_limit': 25, 'watch_interval_min': 15},
    )
    _invalidate_cache()

    buf = io.StringIO()
    with mock.patch.object(sys, 'stdout', buf):
        interactive_menu()

    output = buf.getvalue()
    assert 'min_msg_length=75' in output
    assert 'signals.fixes=disabled' in output


# ---------------------------------------------------------------------------
# 8. TOML parsing handles all value types
# ---------------------------------------------------------------------------

def test_toml_parsing(isolate_config):
    """Minimal TOML parser handles bool, int, float, string correctly."""
    from aibrain.tools.learn.config import _parse_toml_minimal

    toml_text = """
[learn]
min_msg_length = 60
max_per_run = 5
# This is a comment
precompact_limit = 30
watch_interval_min = 20

[learn.signals]
corrections = true
fixes = false

[learn.importance]
corrections = 0.9
fixes = 0.5
"""
    result = _parse_toml_minimal(toml_text)
    assert result['learn']['min_msg_length'] == 60
    assert result['learn']['signals']['corrections'] is True
    assert result['learn']['signals']['fixes'] is False
    assert result['learn']['importance']['corrections'] == 0.9


# ---------------------------------------------------------------------------
# 9. Menu rendering contains expected structure
# ---------------------------------------------------------------------------

def test_render_menu_structure():
    """_render_menu produces expected labels and structure."""
    from aibrain.tools.learn.config import (
        _render_menu, _SIGNAL_DEFAULTS, _IMPORTANCE_DEFAULTS, _DEFAULTS
    )

    output = _render_menu(
        signal_states=dict(_SIGNAL_DEFAULTS),
        importance=dict(_IMPORTANCE_DEFAULTS),
        scale_values=dict(_DEFAULTS),
        focused=0,
    )

    assert 'Learning Config' in output
    assert 'Corrections' in output
    assert 'Completions' in output
    assert 'Min message length' in output
    assert 'Watch interval' in output
    assert 'ENTER to save' in output
    # First item should be focused
    assert '> [x] 1. Corrections' in output


# ---------------------------------------------------------------------------
# 10. Malformed TOML falls back to defaults gracefully
# ---------------------------------------------------------------------------

def test_malformed_toml_fallback(isolate_config):
    """Corrupted learn.toml is handled gracefully — defaults used."""
    from aibrain.tools.learn.config import load_learn_config, _invalidate_cache

    isolate_config.parent.mkdir(parents=True, exist_ok=True)
    isolate_config.write_text('{{{{not valid toml at all!!!!', encoding='utf-8')
    _invalidate_cache()

    cfg = load_learn_config()
    assert cfg['min_msg_length'] == 40  # default
    assert cfg['signals']['corrections'] is True  # default


# ---------------------------------------------------------------------------
# 11. Importance weights read from config affect _signal_importance
# ---------------------------------------------------------------------------

def test_importance_from_config(isolate_config):
    """Config-driven importance weights are used by realtime_learner."""
    from aibrain.tools.learn.config import _save_config, _invalidate_cache, load_learn_config

    _save_config(
        signal_states={'corrections': True, 'fixes': True, 'discoveries': True,
                       'decisions': True, 'completions': True},
        importance={'corrections': 0.3, 'fixes': 0.7, 'discoveries': 0.7,
                    'decisions': 0.6, 'completions': 0.4},
        scale_values={'min_msg_length': 40, 'max_per_run': 10,
                      'precompact_limit': 25, 'watch_interval_min': 15},
    )
    _invalidate_cache()

    import realtime_learner as rl
    rl._learn_cfg = load_learn_config()

    # With corrections set to 0.3 instead of default 0.8
    imp = rl._signal_importance(['correction'])
    assert imp == pytest.approx(0.3)


# ---------------------------------------------------------------------------
# 12. Partial config file — missing keys use defaults
# ---------------------------------------------------------------------------

def test_partial_config(isolate_config):
    """A learn.toml with only some keys still fills in defaults for the rest."""
    from aibrain.tools.learn.config import load_learn_config, _invalidate_cache

    isolate_config.parent.mkdir(parents=True, exist_ok=True)
    isolate_config.write_text(
        '[learn]\nmin_msg_length = 100\n',
        encoding='utf-8',
    )
    _invalidate_cache()
    cfg = load_learn_config()

    assert cfg['min_msg_length'] == 100  # overridden
    assert cfg['max_per_run'] == 10      # default
    assert cfg['signals']['corrections'] is True  # default
    assert cfg['importance']['fixes'] == 0.7       # default
