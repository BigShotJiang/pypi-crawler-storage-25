#!/usr/bin/env python3
"""
test_brain_marketplace_export.py — Tests for Brain.export_marketplace()

Covers:
1. Export creates a valid .db with brain_manifest table
2. Only active memories are exported (inactive excluded)
3. Entity graph (entities + entity_links) is included
4. Semantic facts are included
5. Category summaries are included
6. No operational tables (config, approvals, execution_log, etc.)
7. Satellite memories are inlined with origin tags
8. Memory passages for exported memories are included
9. Overwrite safety — re-export replaces existing file
"""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest import mock

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _create_source_db(db_path: str) -> sqlite3.Connection:
    """Create a source DB with all tables the export reads from."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic', tags TEXT DEFAULT '',
            content TEXT DEFAULT '', importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0, last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')), active INTEGER DEFAULT 1,
            source_agent TEXT, user_id TEXT DEFAULT '', agent_id TEXT DEFAULT '',
            status TEXT DEFAULT 'active'
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        );
        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;
        CREATE TABLE IF NOT EXISTS memory_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER NOT NULL, action TEXT NOT NULL,
            old_content TEXT, new_content TEXT, changed_by TEXT,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS entities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, type TEXT NOT NULL,
            category TEXT DEFAULT '', mention_count INTEGER DEFAULT 1,
            first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
            UNIQUE(name, type)
        );
        CREATE TABLE IF NOT EXISTS entity_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type TEXT NOT NULL, source_id INTEGER NOT NULL,
            target_type TEXT NOT NULL, target_id INTEGER NOT NULL,
            relationship TEXT NOT NULL DEFAULT 'relates_to',
            metadata TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(source_type, source_id, target_type, target_id, relationship)
        );
        CREATE TABLE IF NOT EXISTS semantic_facts (
            fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL, predicate TEXT NOT NULL,
            object TEXT NOT NULL, fact_type TEXT DEFAULT 'attribute',
            sentiment TEXT DEFAULT 'NEUTRAL', confidence REAL DEFAULT 0.5,
            status TEXT DEFAULT 'ACTIVE',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS fact_evidence (
            evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,
            fact_id INTEGER NOT NULL, source_memory_id INTEGER NOT NULL,
            extraction_method TEXT DEFAULT 'pattern',
            verbatim_snippet TEXT, observed_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS category_summaries (
            category TEXT PRIMARY KEY, summary TEXT NOT NULL,
            memory_count INTEGER DEFAULT 0, avg_importance REAL DEFAULT 0.0,
            top_keywords TEXT DEFAULT '', embedding BLOB,
            last_updated TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS memory_passages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER NOT NULL, passage_index INTEGER NOT NULL,
            content TEXT NOT NULL, role_weight REAL DEFAULT 1.0
        );
        CREATE TABLE IF NOT EXISTS satellite_dbs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL, db_path TEXT NOT NULL,
            description TEXT DEFAULT '', memory_types TEXT DEFAULT '[]',
            search_keywords TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now')), active INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY, value TEXT DEFAULT '',
            updated TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS approvals (
            id INTEGER PRIMARY KEY, title TEXT, status TEXT
        );
        CREATE TABLE IF NOT EXISTS execution_log (
            id INTEGER PRIMARY KEY, source TEXT, result TEXT
        );
        CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY, action TEXT
        );
    """)
    conn.commit()
    return conn


def _seed_source(conn: sqlite3.Connection):
    """Seed the source DB with test data."""
    conn.executescript("""
        INSERT INTO memories (id, name, type, content, importance, active, status)
        VALUES (1, 'active_mem', 'project', 'active memory content', 0.8, 1, 'active');

        INSERT INTO memories (id, name, type, content, importance, active, status)
        VALUES (2, 'inactive_mem', 'project', 'inactive memory', 0.3, 0, 'active');

        INSERT INTO memories (id, name, type, content, importance, active, status)
        VALUES (3, 'deleted_mem', 'project', 'deleted memory', 0.5, 1, 'deleted');

        INSERT INTO entities (name, type, category, mention_count, first_seen, last_seen)
        VALUES ('AIBrain', 'product', 'software', 15, '2026-01-01', '2026-04-01');

        INSERT INTO entity_links (source_type, source_id, target_type, target_id, relationship)
        VALUES ('memory', 1, 'entity', 1, 'mentions');

        INSERT INTO semantic_facts (subject, predicate, object, fact_type, confidence)
        VALUES ('AIBrain', 'is_a', 'brain system', 'attribute', 0.95);

        INSERT INTO fact_evidence (fact_id, source_memory_id, extraction_method, verbatim_snippet)
        VALUES (1, 1, 'pattern', 'AIBrain is a brain system');

        INSERT INTO category_summaries (category, summary, memory_count, avg_importance, last_updated)
        VALUES ('project', 'Project memories summary', 100, 0.65, '2026-04-01');

        INSERT INTO memory_passages (memory_id, passage_index, content, role_weight)
        VALUES (1, 0, 'first passage', 1.0);

        INSERT INTO memory_passages (memory_id, passage_index, content, role_weight)
        VALUES (2, 0, 'passage for inactive', 1.0);

        INSERT INTO memory_history (memory_id, action, new_content, created_at)
        VALUES (1, 'created', 'active memory content', '2026-04-01');

        INSERT INTO config (key, value) VALUES ('agent_name', 'test_agent');
        INSERT INTO config (key, value) VALUES ('anthropic_api_key', 'sk-secret');

        INSERT INTO approvals (title, status) VALUES ('Deploy v2', 'approved');
        INSERT INTO execution_log (source, result) VALUES ('heartbeat', 'ok');
        INSERT INTO activity (action) VALUES ('login');
    """)
    conn.commit()


def _create_satellite_db(sat_path: str) -> None:
    """Create a satellite DB with some memories."""
    conn = sqlite3.connect(sat_path)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, type TEXT DEFAULT 'finding',
            memory_class TEXT DEFAULT 'semantic', tags TEXT DEFAULT '',
            content TEXT DEFAULT '', importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0, last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')), active INTEGER DEFAULT 1,
            source_agent TEXT, user_id TEXT DEFAULT '', agent_id TEXT DEFAULT '',
            status TEXT DEFAULT 'active'
        );
        INSERT INTO memories (name, type, content, importance, active, status)
        VALUES ('sat_finding', 'finding', 'satellite finding content', 0.9, 1, 'active');
    """)
    conn.commit()
    conn.close()


@pytest.fixture
def source_db(tmp_path):
    """Create and seed a source database, monkey-patch aibrain_db."""
    import aibrain_db
    _orig_get_db = aibrain_db.get_db
    _orig_config_get = aibrain_db.config_get
    _orig_file = aibrain_db.__file__

    db_path = str(tmp_path / "source.db")
    conn = _create_source_db(db_path)
    _seed_source(conn)

    # Create satellite DB
    sat_path = str(tmp_path / "sat_findings.db")
    _create_satellite_db(sat_path)
    conn.execute(
        "INSERT INTO satellite_dbs (name, db_path, active) VALUES ('findings', ?, 1)",
        (sat_path,),
    )
    conn.commit()

    def _mock_get_db():
        return conn

    def _mock_config_get(key, default=None):
        row = conn.execute("SELECT value FROM config WHERE key=?", (key,)).fetchone()
        return row[0] if row else default

    aibrain_db.get_db = _mock_get_db
    aibrain_db.config_get = _mock_config_get
    # Point __file__ to tmp_path so satellite relative path resolution works
    aibrain_db.__file__ = str(tmp_path / "aibrain_db.py")

    yield conn, tmp_path

    conn.close()
    aibrain_db.get_db = _orig_get_db
    aibrain_db.config_get = _orig_config_get
    aibrain_db.__file__ = _orig_file


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestMarketplaceExportManifest:
    """Test 1: Export creates a valid .db with brain_manifest."""

    def test_manifest_exists_and_populated(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out, domain="testing", creator_agent="neuro", version="2.0.0")

        exp = sqlite3.connect(out)
        exp.row_factory = sqlite3.Row
        manifest = dict(exp.execute("SELECT * FROM brain_manifest").fetchone())
        exp.close()

        assert manifest["domain"] == "testing"
        assert manifest["creator_agent"] == "neuro"
        assert manifest["version"] == "2.0.0"
        assert manifest["memory_count"] > 0
        assert manifest["quality_score"] > 0
        assert manifest["created_date"] is not None


class TestMarketplaceExportMemories:
    """Test 2: Only active memories are exported."""

    def test_only_active_memories_exported(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out)

        exp = sqlite3.connect(out)
        exp.row_factory = sqlite3.Row
        mems = exp.execute("SELECT name FROM memories").fetchall()
        names = {m["name"] for m in mems}
        exp.close()

        # active_mem is active=1 & status='active'
        assert "active_mem" in names
        # inactive_mem is active=0
        assert "inactive_mem" not in names
        # deleted_mem has status='deleted'
        assert "deleted_mem" not in names


class TestMarketplaceExportEntityGraph:
    """Test 3: Entity graph is included."""

    def test_entities_and_links_exported(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out)

        exp = sqlite3.connect(out)
        ent_ct = exp.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
        link_ct = exp.execute("SELECT COUNT(*) FROM entity_links").fetchone()[0]
        exp.close()

        assert ent_ct >= 1
        assert link_ct >= 1


class TestMarketplaceExportFacts:
    """Test 4: Semantic facts and evidence are included."""

    def test_facts_exported(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out)

        exp = sqlite3.connect(out)
        exp.row_factory = sqlite3.Row
        fact_ct = exp.execute("SELECT COUNT(*) FROM semantic_facts").fetchone()[0]
        evidence_ct = exp.execute("SELECT COUNT(*) FROM fact_evidence").fetchone()[0]
        exp.close()

        assert fact_ct >= 1
        assert evidence_ct >= 1


class TestMarketplaceExportCategorySummaries:
    """Test 5: Category summaries are included."""

    def test_category_summaries_exported(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out)

        exp = sqlite3.connect(out)
        cat_ct = exp.execute("SELECT COUNT(*) FROM category_summaries").fetchone()[0]
        exp.close()

        assert cat_ct >= 1


class TestMarketplaceExportExclusions:
    """Test 6: Operational tables are NOT in the export."""

    def test_no_operational_tables(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out)

        exp = sqlite3.connect(out)
        tables = {r[0] for r in exp.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        exp.close()

        # These should NOT exist in the marketplace export
        assert "config" not in tables
        assert "approvals" not in tables
        assert "execution_log" not in tables
        assert "activity" not in tables
        assert "memory_history" not in tables
        assert "satellite_dbs" not in tables

        # These SHOULD exist
        assert "memories" in tables
        assert "entities" in tables
        assert "entity_links" in tables
        assert "semantic_facts" in tables
        assert "category_summaries" in tables
        assert "brain_manifest" in tables


class TestMarketplaceExportSatellites:
    """Test 7: Satellite memories are inlined with origin tags."""

    def test_satellite_memories_inlined(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out)

        exp = sqlite3.connect(out)
        exp.row_factory = sqlite3.Row
        mems = exp.execute("SELECT * FROM memories WHERE tags LIKE '%satellite:%'").fetchall()  # noqa:LIKE-WILDCARD
        exp.close()

        assert len(mems) >= 1
        # Check satellite origin tag
        tags = mems[0]["tags"]
        assert "satellite:findings" in tags


class TestMarketplaceExportPassages:
    """Test 8: Memory passages for exported memories are included."""

    def test_passages_for_active_memories_only(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        brain.export_marketplace(out)

        exp = sqlite3.connect(out)
        passages = exp.execute("SELECT * FROM memory_passages").fetchall()
        passage_mem_ids = {p[1] for p in passages}  # memory_id column
        exp.close()

        # Passage for memory 1 (active) should be included
        assert 1 in passage_mem_ids
        # Passage for memory 2 (inactive) should NOT be included
        assert 2 not in passage_mem_ids


class TestMarketplaceExportOverwrite:
    """Test 9: Re-export replaces existing file."""

    def test_overwrite_existing(self, source_db):
        conn, tmp_path = source_db
        from aibrain.core.memory_api import Brain
        brain = Brain.__new__(Brain)
        brain._db = conn

        out = str(tmp_path / "export.db")
        # Export twice
        brain.export_marketplace(out, domain="first")
        brain.export_marketplace(out, domain="second")

        exp = sqlite3.connect(out)
        exp.row_factory = sqlite3.Row
        manifest = dict(exp.execute("SELECT * FROM brain_manifest").fetchone())
        exp.close()

        assert manifest["domain"] == "second"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
