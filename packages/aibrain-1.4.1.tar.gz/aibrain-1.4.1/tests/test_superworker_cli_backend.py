"""test_superworker_cli_backend.py — unit tests for the claude CLI backend.

Covers _claude_cli_available(), _run_via_claude_cli(), and _run_llm()'s dispatch
logic. NO real subprocess/API calls are made — all tests mock subprocess.run
and/or the anthropic module the same way test_superworker.py does.

The goal of this backend is: when the `claude` binary is on PATH, SuperWorker
calls go through the user's Pro/Max subscription (cost_cents=0) instead of the
metered Anthropic SDK. On ANY CLI failure, the existing SDK path runs as
fallback so the divergence loop still works.
"""
from __future__ import annotations

import json
import subprocess
import sys
import types
from unittest.mock import MagicMock, patch

import pytest

from aibrain.core import superworker
from aibrain.core.superworker import (
    _claude_cli_available,
    _run_llm,
    _run_via_claude_cli,
)


# --- fixtures --------------------------------------------------------------

@pytest.fixture(autouse=True)
def _reset_cli_cache(monkeypatch):
    """Every test starts with the module-level availability cache cleared so
    tests don't depend on execution order or on whether a real `claude` binary
    happens to be installed on the dev machine. We also pin _CLAUDE_CLI_PATH
    to a known fake value so tests that exercise _run_via_claude_cli directly
    don't fall through to shutil.which() and pick up the real dev-machine
    binary path.

    Post-refactor (canonical helper split): _run_via_claude_cli now delegates
    the actual subprocess call to the canonical helper in decker_system. Tests
    that cover argv shape / tempfile behavior of the subprocess itself have
    been moved to decker_system/04_tools/test_claude_cli.py. Tests here now
    mock _CANONICAL_CALL_CLAUDE_CLI to return a fake (rc, stdout, stderr)
    tuple and exercise only the JSON envelope parsing + cost accounting that
    SuperWorker still owns.
    """
    monkeypatch.setattr(superworker, "_CLAUDE_CLI_AVAILABLE", None)
    monkeypatch.setattr(superworker, "_CLAUDE_CLI_PATH", "/fake/claude")
    monkeypatch.setattr(superworker, "_CANONICAL_CALL_CLAUDE_CLI", None)
    yield


def _fake_canonical_factory(rc: int, stdout: str = "", stderr: str = ""):
    """Build a drop-in for the canonical call_claude_cli helper.

    Returns a callable matching the helper's signature so we can swap it into
    superworker._CANONICAL_CALL_CLAUDE_CLI without touching subprocess at all.
    """
    def fake(prompt=None, system_prompt=None, model=None, timeout_s=None,
             cwd=None, extra_args=None, batch_flags=True):
        return rc, stdout, stderr
    return fake


def _fake_envelope(
    result_text: str = "hello",
    model: str = "claude-sonnet-4-20250514",
    is_error: bool = False,
) -> str:
    """Build a JSON envelope shaped like real `claude -p --output-format json`."""
    return json.dumps({
        "type": "result",
        "subtype": "success" if not is_error else "error",
        "is_error": is_error,
        "duration_ms": 1234,
        "result": result_text,
        "modelUsage": {model: {"inputTokens": 10, "outputTokens": 20}},
    })


def _fake_completed(returncode: int, stdout: str = "", stderr: str = ""):
    cp = MagicMock(spec=subprocess.CompletedProcess)
    cp.returncode = returncode
    cp.stdout = stdout
    cp.stderr = stderr
    return cp


def _fake_anthropic_module(text: str, in_tok: int = 100, out_tok: int = 200):
    """Same pattern as test_superworker.py — builds a stand-in anthropic module."""
    mod = types.ModuleType("anthropic")
    resp = MagicMock()
    resp.content = [MagicMock(text=text)]
    resp.usage = MagicMock(input_tokens=in_tok, output_tokens=out_tok)
    client = MagicMock()
    client.messages.create.return_value = resp
    mod.Anthropic = MagicMock(return_value=client)
    return mod, client


# --- _claude_cli_available -------------------------------------------------

def test_cli_available_returns_false_when_binary_missing(monkeypatch):
    monkeypatch.setattr(superworker.shutil, "which", lambda _: None)
    assert _claude_cli_available() is False
    # Cached — second call must not re-probe.
    assert superworker._CLAUDE_CLI_AVAILABLE is False


def test_cli_available_returns_true_when_version_probe_succeeds(monkeypatch):
    monkeypatch.setattr(superworker.shutil, "which", lambda _: "/fake/claude")

    calls = []
    def fake_run(argv, **kwargs):
        calls.append(argv)
        return _fake_completed(0, stdout="2.1.101 (Claude Code)\n")

    monkeypatch.setattr(superworker.subprocess, "run", fake_run)
    assert _claude_cli_available() is True
    assert calls[0] == ["/fake/claude", "--version"]


def test_cli_available_returns_false_when_version_probe_nonzero(monkeypatch):
    monkeypatch.setattr(superworker.shutil, "which", lambda _: "/fake/claude")
    monkeypatch.setattr(
        superworker.subprocess, "run",
        lambda *a, **k: _fake_completed(1, stderr="boom"),
    )
    assert _claude_cli_available() is False


def test_cli_available_returns_false_on_timeout(monkeypatch):
    monkeypatch.setattr(superworker.shutil, "which", lambda _: "/fake/claude")

    def fake_run(*a, **k):
        raise subprocess.TimeoutExpired(cmd="claude", timeout=10)

    monkeypatch.setattr(superworker.subprocess, "run", fake_run)
    assert _claude_cli_available() is False


def test_cli_available_caches_result(monkeypatch):
    """Expensive probe must only run once per process."""
    monkeypatch.setattr(superworker.shutil, "which", lambda _: "/fake/claude")
    call_count = {"n": 0}

    def fake_run(*a, **k):
        call_count["n"] += 1
        return _fake_completed(0)

    monkeypatch.setattr(superworker.subprocess, "run", fake_run)
    _claude_cli_available()
    _claude_cli_available()
    _claude_cli_available()
    assert call_count["n"] == 1


# --- _run_via_claude_cli ---------------------------------------------------

def test_run_via_cli_delegates_to_canonical_helper_and_parses_result(monkeypatch):
    """Post-refactor: argv shape + tempfile cleanup live in the canonical
    helper (covered by decker_system/04_tools/test_claude_cli.py). Here we
    verify SuperWorker passes the right flags/args through and parses the
    JSON envelope the helper returns on stdout."""
    captured = {}

    def fake_canonical(prompt=None, system_prompt=None, model=None,
                       timeout_s=None, cwd=None, extra_args=None,
                       batch_flags=True):
        captured.update({
            "prompt": prompt,
            "system_prompt": system_prompt,
            "model": model,
            "timeout_s": timeout_s,
            "extra_args": extra_args,
            "batch_flags": batch_flags,
        })
        return 0, _fake_envelope("final answer", "claude-opus-4-6[1m]"), ""

    monkeypatch.setattr(superworker, "_CANONICAL_CALL_CLAUDE_CLI", fake_canonical)

    text, model_used, cost, _ = _run_via_claude_cli(
        prompt="what is 2+2?",
        system="you are helpful",
        model="claude-sonnet-4-20250514",
    )

    assert text == "final answer"
    # modelUsage key wins over requested model (reports what actually ran)
    assert model_used == "claude-opus-4-6[1m]"
    assert cost == 0  # subscription path is always free

    # SuperWorker must opt out of the default batch flags and request the
    # JSON envelope shape it needs.
    assert captured["batch_flags"] is False
    assert "-p" in captured["extra_args"]
    assert "--output-format" in captured["extra_args"]
    assert "json" in captured["extra_args"]
    assert "--no-session-persistence" in captured["extra_args"]
    assert captured["model"] == "claude-sonnet-4-20250514"
    assert captured["prompt"] == "what is 2+2?"
    assert captured["system_prompt"] == "you are helpful"
    assert captured["timeout_s"] and captured["timeout_s"] > 0


def test_run_via_cli_raises_when_helper_missing(monkeypatch):
    """If the canonical helper cannot be loaded (public-only install), the
    backend must raise a clear RuntimeError so _run_llm falls back to SDK."""
    monkeypatch.setattr(superworker, "_load_canonical_claude_cli", lambda: None)
    monkeypatch.setattr(superworker, "_CANONICAL_CALL_CLAUDE_CLI", None)
    with pytest.raises(RuntimeError, match="helper missing"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_raises_on_nonzero_exit(monkeypatch):
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(2, stdout="", stderr="auth failed"),
    )
    with pytest.raises(RuntimeError, match="exit 2"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_raises_on_empty_stdout(monkeypatch):
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(0, stdout=""),
    )
    with pytest.raises(RuntimeError, match="empty stdout"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_raises_on_malformed_json(monkeypatch):
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(0, stdout="not json at all"),
    )
    with pytest.raises(RuntimeError, match="JSON parse failed"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_raises_when_is_error_true(monkeypatch):
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(0, stdout=_fake_envelope(is_error=True)),
    )
    with pytest.raises(RuntimeError, match="is_error"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_raises_when_result_field_missing(monkeypatch):
    envelope = json.dumps({"type": "result", "is_error": False})  # no 'result'
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(0, stdout=envelope),
    )
    with pytest.raises(RuntimeError, match="result"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_raises_on_timeout(monkeypatch):
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(124, stderr="timed out"),
    )
    with pytest.raises(RuntimeError, match="timed out"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_raises_when_cli_not_found(monkeypatch):
    """rc=127 from canonical helper = claude binary missing. SuperWorker
    must surface this as a RuntimeError so _run_llm falls back to SDK."""
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(127, stderr="claude CLI not found on PATH"),
    )
    with pytest.raises(RuntimeError, match="not found"):
        _run_via_claude_cli("p", "s", "m")


def test_run_via_cli_falls_back_to_requested_model_when_envelope_missing_usage(monkeypatch):
    envelope = json.dumps({
        "type": "result",
        "is_error": False,
        "result": "ok",
    })  # no modelUsage key
    monkeypatch.setattr(
        superworker, "_CANONICAL_CALL_CLAUDE_CLI",
        _fake_canonical_factory(0, stdout=envelope),
    )
    text, model_used, cost, _ = _run_via_claude_cli("p", "s", "claude-sonnet-4-20250514")
    assert text == "ok"
    assert model_used == "claude-sonnet-4-20250514"
    assert cost == 0


# --- _run_llm dispatch logic ----------------------------------------------

def test_run_llm_prefers_cli_when_available(monkeypatch):
    """When CLI is available and succeeds, SDK must NOT be touched."""
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: True)

    cli_called = {"n": 0}
    def fake_cli(prompt, system, model):
        cli_called["n"] += 1
        return ("from cli", model, 0, None)  # 4-tuple: added cost_cents_equivalent
    monkeypatch.setattr(superworker, "_run_via_claude_cli", fake_cli)

    # Install a poison anthropic module — if anything touches it, the test fails loudly.
    poison_mod = types.ModuleType("anthropic")
    def poison(*a, **k):
        raise AssertionError("SDK was called when CLI should have been used")
    poison_mod.Anthropic = poison
    monkeypatch.setitem(sys.modules, "anthropic", poison_mod)

    text, model, cost, _ = _run_llm("p", "s", "claude-sonnet-4-20250514")
    assert text == "from cli"
    assert cost == 0
    assert cli_called["n"] == 1


def test_run_llm_falls_back_to_sdk_when_cli_unavailable(monkeypatch):
    """When CLI binary is missing, SDK path runs and cost_cents is computed."""
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    # _run_via_claude_cli must NOT be called at all
    def should_not_be_called(*a, **k):
        raise AssertionError("CLI backend called when unavailable")
    monkeypatch.setattr(superworker, "_run_via_claude_cli", should_not_be_called)

    fake_mod, client = _fake_anthropic_module("from sdk", in_tok=1000, out_tok=2000)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)

    text, model, cost, _ = _run_llm("p", "s", "claude-sonnet-4-20250514")
    assert text == "from sdk"
    assert model == "claude-sonnet-4-20250514"
    assert cost == 3  # 1000/1k * 0.003 + 2000/1k * 0.015 = 0.033 USD = 3 cents
    assert client.messages.create.called


def test_run_llm_falls_back_to_sdk_when_cli_raises(monkeypatch):
    """CLI available but throws — must fall back cleanly to SDK, not propagate."""
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: True)
    monkeypatch.setattr(
        superworker, "_run_via_claude_cli",
        lambda *a, **k: (_ for _ in ()).throw(RuntimeError("CLI blew up")),
    )

    fake_mod, client = _fake_anthropic_module("rescued by sdk")
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)

    text, model, cost, _ = _run_llm("p", "s", "claude-sonnet-4-20250514")
    assert text == "rescued by sdk"
    assert client.messages.create.called


def test_run_llm_sdk_exception_propagates_when_cli_unavailable(monkeypatch):
    """If CLI is unavailable AND SDK fails, the exception must surface (invoke()
    catches it and turns it into a failed result — that's tested in
    test_superworker.py::test_invoke_llm_exception_becomes_failed_result)."""
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    fake_mod = types.ModuleType("anthropic")
    client = MagicMock()
    client.messages.create.side_effect = RuntimeError("sdk rate limit")
    fake_mod.Anthropic = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)

    with pytest.raises(RuntimeError, match="sdk rate limit"):
        _run_llm("p", "s", "claude-sonnet-4-20250514")


def test_run_llm_cli_failure_then_sdk_failure_surfaces_sdk_error(monkeypatch):
    """Both backends broken: the SDK error wins (it's the terminal attempt)."""
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: True)
    monkeypatch.setattr(
        superworker, "_run_via_claude_cli",
        lambda *a, **k: (_ for _ in ()).throw(RuntimeError("cli down")),
    )

    fake_mod = types.ModuleType("anthropic")
    client = MagicMock()
    client.messages.create.side_effect = RuntimeError("sdk down")
    fake_mod.Anthropic = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)

    with pytest.raises(RuntimeError, match="sdk down"):
        _run_llm("p", "s", "claude-sonnet-4-20250514")
