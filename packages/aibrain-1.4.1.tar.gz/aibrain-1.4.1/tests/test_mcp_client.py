"""
test_mcp_client.py — Tests for the universal MCP client package.

Covers: config creation, transport mocking, registry register/unregister,
tool name sanitization, MCPTool spec conversion, retry logic, caching.
"""

import asyncio
import json
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from aibrain.mcp.config import MCPServerStdio, MCPServerHTTP, MCPServerSSE
from aibrain.mcp.client import MCPClient, sanitize_tool_name
from aibrain.mcp.transports import (
    BaseTransport,
    MCPAuthError,
    MCPNetworkError,
    MCPProtocolError,
    MCPTransportError,
)
from aibrain.mcp.registry import MCPServerRegistry, _config_to_dict, _dict_to_config
from aibrain.mcp.tool_bridge import MCPTool


def run_async(coro):
    """Helper to run async tests."""
    return asyncio.get_event_loop().run_until_complete(coro)


async def _async_noop(*args, **kwargs):
    """No-op async function for patching asyncio.sleep in tests."""
    return None


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------

class TestConfigs(unittest.TestCase):
    """MCPServerStdio/HTTP/SSE config creation and serialization."""

    def test_stdio_config(self):
        cfg = MCPServerStdio(command="python", args=["-m", "my_server"])
        self.assertEqual(cfg.command, "python")
        self.assertEqual(cfg.args, ["-m", "my_server"])
        self.assertEqual(cfg.transport, "stdio")
        self.assertIsNone(cfg.tool_filter)

    def test_stdio_with_env_and_filter(self):
        cfg = MCPServerStdio(
            command="node",
            args=["server.js"],
            env={"API_KEY": "test"},
            tool_filter=["search", "create"],
        )
        self.assertEqual(cfg.env, {"API_KEY": "test"})
        self.assertEqual(cfg.tool_filter, ["search", "create"])

    def test_http_config(self):
        cfg = MCPServerHTTP(url="https://mcp.example.com/v1")
        self.assertEqual(cfg.url, "https://mcp.example.com/v1")
        self.assertEqual(cfg.transport, "http")
        self.assertEqual(cfg.headers, {})

    def test_http_with_headers(self):
        cfg = MCPServerHTTP(
            url="https://mcp.example.com",
            headers={"Authorization": "Bearer tok123"},
            tool_filter=["read"],
        )
        self.assertEqual(cfg.headers["Authorization"], "Bearer tok123")
        self.assertEqual(cfg.tool_filter, ["read"])

    def test_sse_config(self):
        cfg = MCPServerSSE(url="https://mcp.example.com/sse")
        self.assertEqual(cfg.transport, "sse")

    def test_config_serialization_roundtrip(self):
        """Config -> dict -> config preserves all fields."""
        configs = [
            MCPServerStdio(command="npx", args=["@github/mcp"], env={"TOKEN": "x"}),
            MCPServerHTTP(url="https://a.com", headers={"X-Key": "v"}),
            MCPServerSSE(url="https://b.com/sse", tool_filter=["foo"]),
        ]
        for cfg in configs:
            d = _config_to_dict(cfg)
            restored = _dict_to_config(d)
            self.assertEqual(type(cfg), type(restored))
            self.assertEqual(_config_to_dict(restored), d)


# ---------------------------------------------------------------------------
# Tool name sanitization
# ---------------------------------------------------------------------------

class TestToolNameSanitization(unittest.TestCase):

    def test_simple_names(self):
        self.assertEqual(sanitize_tool_name("github", "search"), "github_search")

    def test_special_chars(self):
        result = sanitize_tool_name("my-server", "do.thing/now")
        self.assertEqual(result, "my_server_do_thing_now")

    def test_max_length(self):
        long_server = "a" * 40
        long_tool = "b" * 40
        result = sanitize_tool_name(long_server, long_tool)
        self.assertLessEqual(len(result), 64)

    def test_collapses_underscores(self):
        result = sanitize_tool_name("my--server", "the__tool")
        self.assertNotIn("__", result)

    def test_strips_leading_trailing(self):
        result = sanitize_tool_name("-srv-", "-tool-")
        self.assertFalse(result.startswith("_"))


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------

class MockTransport(BaseTransport):
    """Mock transport for testing client logic without real servers."""

    def __init__(self, responses: list[dict] = None):
        super().__init__()
        self._responses = list(responses or [])
        self._sent: list[dict] = []

    async def connect(self):
        self._connected = True

    async def disconnect(self):
        self._connected = False

    async def send(self, message: dict) -> dict:
        self._sent.append(message)
        if self._responses:
            return self._responses.pop(0)
        return {"jsonrpc": "2.0", "result": {}, "id": message.get("id")}


# ---------------------------------------------------------------------------
# Client tests
# ---------------------------------------------------------------------------

class TestMCPClient(unittest.TestCase):

    def _make_client(self, responses: list[dict] = None):
        """Create a client with a mock transport."""
        config = MCPServerStdio(command="echo")
        client = MCPClient(config)
        client.transport = MockTransport(responses or [
            # initialize response
            {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": 1},
            # initialized notification response (ignored)
            {"jsonrpc": "2.0", "result": {}, "id": None},
        ])
        return client

    def test_connect_sends_initialize(self):
        client = self._make_client()
        run_async(client.connect())
        sent = client.transport._sent
        self.assertEqual(sent[0]["method"], "initialize")
        self.assertEqual(sent[1]["method"], "notifications/initialized")

    def test_list_tools(self):
        tools_response = {
            "jsonrpc": "2.0",
            "result": {"tools": [
                {"name": "search", "description": "Search things", "inputSchema": {"type": "object"}},
                {"name": "create", "description": "Create things"},
            ]},
            "id": 3,
        }
        client = self._make_client([
            {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": 1},
            {"jsonrpc": "2.0", "result": {}, "id": None},
            tools_response,
        ])
        run_async(client.connect())
        tools = run_async(client.list_tools())
        self.assertEqual(len(tools), 2)
        self.assertEqual(tools[0]["name"], "search")

    def test_list_tools_with_filter(self):
        config = MCPServerStdio(command="echo", tool_filter=["search"])
        client = MCPClient(config)
        client.transport = MockTransport([
            {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": 1},
            {"jsonrpc": "2.0", "result": {}, "id": None},
            {"jsonrpc": "2.0", "result": {"tools": [
                {"name": "search", "description": "Search"},
                {"name": "create", "description": "Create"},
            ]}, "id": 3},
        ])
        run_async(client.connect())
        tools = run_async(client.list_tools())
        self.assertEqual(len(tools), 1)
        self.assertEqual(tools[0]["name"], "search")

    def test_list_tools_caching(self):
        """Second call uses cache, doesn't hit transport."""
        client = self._make_client([
            {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": 1},
            {"jsonrpc": "2.0", "result": {}, "id": None},
            {"jsonrpc": "2.0", "result": {"tools": [{"name": "t1"}]}, "id": 3},
        ])
        run_async(client.connect())
        tools1 = run_async(client.list_tools())
        # Second call should use cache — no more responses needed
        tools2 = run_async(client.list_tools())
        self.assertEqual(tools1, tools2)
        # Only 3 messages sent: initialize, initialized, tools/list
        self.assertEqual(len(client.transport._sent), 3)

    def test_call_tool(self):
        client = self._make_client([
            {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": 1},
            {"jsonrpc": "2.0", "result": {}, "id": None},
            {"jsonrpc": "2.0", "result": {"content": [{"type": "text", "text": "hello"}]}, "id": 3},
        ])
        run_async(client.connect())
        result = run_async(client.call_tool("greet", {"name": "world"}))
        self.assertEqual(result, "hello")

    def test_call_tool_multi_content(self):
        client = self._make_client([
            {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": 1},
            {"jsonrpc": "2.0", "result": {}, "id": None},
            {"jsonrpc": "2.0", "result": {"content": [
                {"type": "text", "text": "a"},
                {"type": "image", "data": "base64..."},
            ]}, "id": 3},
        ])
        run_async(client.connect())
        result = run_async(client.call_tool("multi", {}))
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------

class TestRetryLogic(unittest.TestCase):

    def test_auth_error_no_retry(self):
        """Auth errors should fail immediately, not retry."""
        config = MCPServerStdio(command="echo")
        client = MCPClient(config, max_retries=3)

        call_count = 0

        class AuthFailTransport(BaseTransport):
            async def connect(self):
                self._connected = True
            async def disconnect(self):
                self._connected = False
            async def send(self, message):
                nonlocal call_count
                if message.get("method") == "tools/call":
                    call_count += 1
                    return {"jsonrpc": "2.0", "error": {"code": -32001, "message": "unauthorized"}, "id": message["id"]}
                return {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": message.get("id")}

        client.transport = AuthFailTransport()
        run_async(client.connect())
        with self.assertRaises(MCPAuthError):
            run_async(client.call_tool("test", {}))
        self.assertEqual(call_count, 1)  # Only 1 attempt, no retries

    def test_network_error_retries(self):
        """Network errors should retry with backoff."""
        config = MCPServerStdio(command="echo")
        client = MCPClient(config, max_retries=3)

        call_count = 0

        class FlakeyTransport(BaseTransport):
            async def connect(self):
                self._connected = True
            async def disconnect(self):
                self._connected = False
            async def send(self, message):
                nonlocal call_count
                if message.get("method") == "tools/call":
                    call_count += 1
                    if call_count < 3:
                        raise MCPNetworkError("connection reset")
                    return {"jsonrpc": "2.0", "result": {"content": [{"type": "text", "text": "ok"}]}, "id": message["id"]}
                return {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": message.get("id")}

        client.transport = FlakeyTransport()
        # Patch sleep to avoid actual delays in tests
        with patch("aibrain.mcp.client.asyncio.sleep", new=_async_noop):
            run_async(client.connect())
            result = run_async(client.call_tool("test", {}))
        self.assertEqual(result, "ok")
        self.assertEqual(call_count, 3)  # 2 failures + 1 success

    def test_network_error_exhausts_retries(self):
        """Network errors that exhaust retries raise MCPNetworkError."""
        config = MCPServerStdio(command="echo")
        client = MCPClient(config, max_retries=2)

        class AlwaysFailTransport(BaseTransport):
            async def connect(self):
                self._connected = True
            async def disconnect(self):
                self._connected = False
            async def send(self, message):
                if message.get("method") == "tools/call":
                    raise MCPNetworkError("always fails")
                return {"jsonrpc": "2.0", "result": {"protocolVersion": "2024-11-05"}, "id": message.get("id")}

        client.transport = AlwaysFailTransport()
        with patch("aibrain.mcp.client.asyncio.sleep", new=_async_noop):
            run_async(client.connect())
            with self.assertRaises(MCPNetworkError):
                run_async(client.call_tool("test", {}))


# ---------------------------------------------------------------------------
# Registry tests
# ---------------------------------------------------------------------------

class TestRegistry(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self._tmp.close()
        self.db_path = self._tmp.name

    def tearDown(self):
        try:
            os.unlink(self.db_path)
        except OSError:
            pass

    def test_register_and_list(self):
        reg = MCPServerRegistry(db_path=self.db_path)
        cfg = MCPServerStdio(command="python", args=["-m", "server"])
        reg.register("test", cfg)
        servers = reg.list_servers()
        self.assertIn("test", servers)
        self.assertEqual(servers["test"].command, "python")

    def test_unregister(self):
        reg = MCPServerRegistry(db_path=self.db_path)
        reg.register("test", MCPServerStdio(command="echo"))
        reg.unregister("test")
        self.assertNotIn("test", reg.list_servers())

    def test_persistence_roundtrip(self):
        """Configs survive DB save/load cycle."""
        reg1 = MCPServerRegistry(db_path=self.db_path)
        reg1.register("stdio_srv", MCPServerStdio(command="npx", args=["@github/mcp"]))
        reg1.register("http_srv", MCPServerHTTP(url="https://example.com/mcp"))
        reg1.register("sse_srv", MCPServerSSE(url="https://example.com/sse"))

        # Create new registry instance — should load from DB
        reg2 = MCPServerRegistry(db_path=self.db_path)
        servers = reg2.list_servers()
        self.assertIn("stdio_srv", servers)
        self.assertIn("http_srv", servers)
        self.assertIn("sse_srv", servers)
        self.assertIsInstance(servers["stdio_srv"], MCPServerStdio)
        self.assertIsInstance(servers["http_srv"], MCPServerHTTP)
        self.assertEqual(servers["stdio_srv"].command, "npx")

    def test_unregister_cleans_db(self):
        reg = MCPServerRegistry(db_path=self.db_path)
        reg.register("test", MCPServerStdio(command="echo"))
        reg.unregister("test")

        reg2 = MCPServerRegistry(db_path=self.db_path)
        self.assertNotIn("test", reg2.list_servers())

    def test_tool_cache_persistence(self):
        """Tool schemas cached in SQLite survive registry restart."""
        reg = MCPServerRegistry(db_path=self.db_path)
        tools = [
            {"name": "search", "description": "Search stuff", "inputSchema": {"type": "object"}},
            {"name": "create", "description": "Make stuff"},
        ]
        reg._cache_tools_to_db("my_server", tools)

        cached = reg._load_cached_tools("my_server")
        self.assertEqual(len(cached), 2)
        cached_names = {t["name"] for t in cached}
        self.assertEqual(cached_names, {"search", "create"})

    def test_get_tools_unknown_server(self):
        reg = MCPServerRegistry(db_path=self.db_path)
        with self.assertRaises(KeyError):
            run_async(reg.get_tools("nonexistent"))

    def test_call_tool_unknown_server(self):
        reg = MCPServerRegistry(db_path=self.db_path)
        with self.assertRaises(KeyError):
            run_async(reg.call_tool("nonexistent", "tool", {}))


# ---------------------------------------------------------------------------
# MCPTool / tool_bridge tests
# ---------------------------------------------------------------------------

class TestMCPTool(unittest.TestCase):

    def _make_tool(self):
        schema = {
            "name": "search_repos",
            "description": "Search GitHub repositories",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "limit": {"type": "integer", "default": 10},
                },
                "required": ["query"],
            },
        }
        registry = MagicMock()
        return MCPTool("github", "search_repos", schema, registry)

    def test_name_prefixed(self):
        tool = self._make_tool()
        self.assertEqual(tool.name, "github_search_repos")

    def test_to_llm_tool_spec(self):
        tool = self._make_tool()
        spec = tool.to_llm_tool_spec()
        self.assertEqual(spec["type"], "function")
        self.assertEqual(spec["function"]["name"], "github_search_repos")
        self.assertIn("properties", spec["function"]["parameters"])
        self.assertIn("query", spec["function"]["parameters"]["properties"])

    def test_to_anthropic_spec(self):
        tool = self._make_tool()
        spec = tool.to_anthropic_spec()
        self.assertEqual(spec["name"], "github_search_repos")
        self.assertIn("input_schema", spec)

    def test_description_fallback(self):
        """Empty description gets a sensible default."""
        schema = {"name": "do_thing", "inputSchema": {}}
        tool = MCPTool("srv", "do_thing", schema, MagicMock())
        spec = tool.to_llm_tool_spec()
        self.assertIn("srv/do_thing", spec["function"]["description"])

    def test_empty_schema_defaults(self):
        """Tool with no inputSchema still produces valid spec."""
        schema = {"name": "ping"}
        tool = MCPTool("srv", "ping", schema, MagicMock())
        spec = tool.to_llm_tool_spec()
        self.assertEqual(spec["function"]["parameters"]["type"], "object")

    def test_repr(self):
        tool = self._make_tool()
        r = repr(tool)
        self.assertIn("github", r)
        self.assertIn("search_repos", r)

    def test_special_chars_in_name(self):
        """Tool names with special chars get sanitized."""
        schema = {"name": "do-complex.thing/now"}
        tool = MCPTool("my-server", "do-complex.thing/now", schema, MagicMock())
        self.assertRegex(tool.name, r"^[a-zA-Z0-9_]+$")


# ---------------------------------------------------------------------------
# Transport error classification
# ---------------------------------------------------------------------------

class TestErrorClassification(unittest.TestCase):

    def test_auth_error_is_transport_error(self):
        self.assertIsInstance(MCPAuthError("test"), MCPTransportError)

    def test_network_error_is_transport_error(self):
        self.assertIsInstance(MCPNetworkError("test"), MCPTransportError)

    def test_protocol_error_is_transport_error(self):
        self.assertIsInstance(MCPProtocolError("test"), MCPTransportError)


if __name__ == "__main__":
    unittest.main()
