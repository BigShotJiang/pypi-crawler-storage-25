"""
Tests for Round 3 security fixes:

- R3-01: API key hashing uses HMAC-SHA256 with server-side secret (not unsalted SHA-256)
- R3-02: JWT requires issuer and audience claims (no legacy skip)
- R3-03: Rate limiter bounded — TTL cleanup, max IP cap, no defaultdict leak
"""

import hashlib
import hmac as hmac_mod
import json
import sys
import time
import threading
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


# ============================================================================
# R3-01: API key hashing — HMAC-SHA256 with server secret
# ============================================================================

class TestApiKeyHashing:
    """Verify API key hashing uses HMAC-SHA256, not plain SHA-256."""

    def test_hash_key_uses_hmac_when_secret_available(self):
        """_hash_key with a secret produces HMAC-SHA256, not plain SHA-256."""
        from security import _hash_key
        key = "test-api-key-abc123"
        secret = "server-secret-xyz"  # noqa:HARDCODED_SECRET — test fixture
        result = _hash_key(key, _secret=secret)
        # Verify it matches HMAC-SHA256
        expected = hmac_mod.new(secret.encode(), key.encode(), hashlib.sha256).hexdigest()
        assert result == expected
        # Verify it does NOT match plain SHA-256
        plain = hashlib.sha256(key.encode()).hexdigest()
        assert result != plain

    def test_hash_key_different_secrets_produce_different_hashes(self):
        """Different server secrets produce different hashes for the same key."""
        from security import _hash_key
        key = "same-api-key"
        h1 = _hash_key(key, _secret="secret-a")  # noqa:HARDCODED_SECRET — test fixture
        h2 = _hash_key(key, _secret="secret-b")  # noqa:HARDCODED_SECRET — test fixture
        assert h1 != h2

    def test_needs_rehash_detects_legacy_sha256(self):
        """_needs_rehash returns True for hashes created with plain SHA-256."""
        from security import _needs_rehash
        key = "legacy-api-key-999"
        legacy_hash = hashlib.sha256(key.encode()).hexdigest()
        # With a secret available, HMAC hash differs from plain — needs rehash
        with patch("security._get_hash_secret", return_value="some-secret"):
            assert _needs_rehash(legacy_hash, key) is True

    def test_needs_rehash_false_for_wrong_key(self):
        """_needs_rehash returns False when key doesn't match stored hash at all."""
        from security import _needs_rehash
        stored = hashlib.sha256(b"correct-key").hexdigest()
        assert _needs_rehash(stored, "wrong-key") is False

    def test_needs_rehash_false_for_already_hmac(self):
        """_needs_rehash returns False for hashes already using HMAC."""
        from security import _hash_key, _needs_rehash
        key = "modern-key"
        secret = "test-secret"
        hmac_hash = _hash_key(key, _secret=secret)
        # HMAC hash won't match plain SHA-256 of the key
        with patch("security._get_hash_secret", return_value=secret):
            assert _needs_rehash(hmac_hash, key) is False

    def test_verify_api_key_migrates_legacy_hash(self):
        """AuthMiddleware._verify_api_key rehashes legacy keys on successful match."""
        from security import AuthMiddleware

        key = "migration-test-key"
        legacy_hash = hashlib.sha256(key.encode()).hexdigest()
        mock_db = MagicMock()
        mock_db.config_get.side_effect = lambda k, default=None: {
            "api_keys": [legacy_hash],
            "api_hash_secret": "test-secret-for-migration",
            "auth_mode": "api_key",
        }.get(k, default)

        stored_updates = []
        def capture_set(k, v):
            if k == "api_keys":
                stored_updates.append(v)
        mock_db.config_set.side_effect = capture_set

        middleware = AuthMiddleware.__new__(AuthMiddleware)
        middleware._db = mock_db

        with patch("security._get_hash_secret", return_value="test-secret-for-migration"):
            result = middleware._verify_api_key(key)

        assert result is True
        # Verify the hash was updated (migrated)
        assert len(stored_updates) == 1
        new_hash = stored_updates[0][0]
        assert new_hash != legacy_hash, "Hash should have been migrated to HMAC"


# ============================================================================
# R3-02: JWT issuer and audience validation — strict, no legacy skip
# ============================================================================

class TestJwtIssuerAudience:
    """Verify JWT decode rejects tokens missing or with wrong iss/aud."""

    def _make_token(self, payload: dict, secret: str) -> str:
        """Build a raw HS256 JWT with arbitrary payload (no forced iss/aud)."""
        import base64
        def b64url(data: bytes) -> str:
            return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

        header = {"alg": "HS256", "typ": "JWT"}
        segments = [
            b64url(json.dumps(header, separators=(",", ":")).encode()),
            b64url(json.dumps(payload, separators=(",", ":")).encode()),
        ]
        signing_input = f"{segments[0]}.{segments[1]}".encode()
        sig = hmac_mod.new(secret.encode(), signing_input, hashlib.sha256).digest()
        segments.append(b64url(sig))
        return ".".join(segments)

    def test_valid_token_accepted(self):
        """Token with correct iss and aud is accepted."""
        from security import jwt_encode, jwt_decode
        secret = "test-secret"
        token = jwt_encode({"sub": "user1"}, secret)
        payload = jwt_decode(token, secret)
        assert payload is not None
        assert payload["sub"] == "user1"
        assert payload["iss"] == "aibrain"
        assert payload["aud"] == "aibrain-api"

    def test_missing_issuer_rejected(self):
        """Token without 'iss' claim is rejected."""
        from security import jwt_decode
        secret = "test-secret"
        token = self._make_token({
            "sub": "attacker",
            "aud": "aibrain-api",
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600,
        }, secret)
        assert jwt_decode(token, secret) is None

    def test_missing_audience_rejected(self):
        """Token without 'aud' claim is rejected."""
        from security import jwt_decode
        secret = "test-secret"
        token = self._make_token({
            "sub": "attacker",
            "iss": "aibrain",
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600,
        }, secret)
        assert jwt_decode(token, secret) is None

    def test_wrong_issuer_rejected(self):
        """Token with wrong issuer is rejected."""
        from security import jwt_decode
        secret = "test-secret"
        token = self._make_token({
            "sub": "attacker",
            "iss": "evil-issuer",
            "aud": "aibrain-api",
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600,
        }, secret)
        assert jwt_decode(token, secret) is None

    def test_wrong_audience_rejected(self):
        """Token with wrong audience is rejected."""
        from security import jwt_decode
        secret = "test-secret"
        token = self._make_token({
            "sub": "attacker",
            "iss": "aibrain",
            "aud": "wrong-audience",
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600,
        }, secret)
        assert jwt_decode(token, secret) is None

    def test_legacy_token_without_claims_rejected(self):
        """Legacy tokens that lack both iss and aud are now rejected (no skip)."""
        from security import jwt_decode
        secret = "test-secret"
        token = self._make_token({
            "sub": "legacy-user",
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600,
        }, secret)
        assert jwt_decode(token, secret) is None


# ============================================================================
# R3-03: Rate limiter — bounded, no memory leak
# ============================================================================

class TestRateLimiterBounded:
    """Verify rate limiter uses bounded storage with TTL cleanup."""

    def _make_middleware(self, **kwargs):
        from security import RateLimitMiddleware
        app = MagicMock()
        return RateLimitMiddleware(app, **kwargs)

    def test_no_defaultdict_auto_creation(self):
        """Accessing a missing IP key does NOT auto-create an entry (no defaultdict)."""
        mw = self._make_middleware()
        # Reading a missing key should raise KeyError, not silently create
        with pytest.raises(KeyError):
            _ = mw._general["nonexistent-ip"]
        assert len(mw._general) == 0, "No phantom entry should exist"

    def test_prune_removes_stale_entries(self):
        """Stale entries (window_start > 120s ago) are removed by prune."""
        mw = self._make_middleware()
        now = time.time()
        # Add entries: one fresh, one stale
        mw._general["1.2.3.4"] = {"count": 5, "window_start": now}
        mw._general["5.6.7.8"] = {"count": 10, "window_start": now - 200}
        mw._auth["9.9.9.9"] = {"count": 3, "window_start": now - 300}
        # Force cleanup by setting last_cleanup far in the past
        mw._last_cleanup = 0.0
        mw._prune_stale_entries()
        assert "1.2.3.4" in mw._general, "Fresh entry should survive"
        assert "5.6.7.8" not in mw._general, "Stale entry should be pruned"
        assert "9.9.9.9" not in mw._auth, "Stale auth entry should be pruned"

    def test_max_ip_cap_evicts_oldest(self):
        """When bucket exceeds _MAX_TRACKED_IPS, oldest entries are evicted."""
        mw = self._make_middleware()
        mw._MAX_TRACKED_IPS = 5  # Low cap for testing
        now = time.time()
        # Add 8 entries with staggered timestamps
        for i in range(8):
            mw._general[f"10.0.0.{i}"] = {"count": 1, "window_start": now - (7 - i)}
        assert len(mw._general) == 8
        # Force prune
        mw._last_cleanup = 0.0
        mw._prune_stale_entries()
        # Should be capped at 5, oldest 3 evicted
        assert len(mw._general) <= 5
        # Newest entries should survive
        assert f"10.0.0.7" in mw._general
        assert f"10.0.0.6" in mw._general
        # Oldest should be gone
        assert f"10.0.0.0" not in mw._general

    def test_prune_interval_respected(self):
        """Prune only runs when enough time has elapsed since last cleanup."""
        mw = self._make_middleware()
        now = time.time()
        mw._general["stale"] = {"count": 1, "window_start": now - 200}
        mw._last_cleanup = now - 30  # Only 30s ago, less than 60s interval
        mw._prune_stale_entries()
        # Should NOT have pruned because interval hasn't elapsed
        assert "stale" in mw._general

    def test_buckets_are_plain_dicts(self):
        """Rate limiter buckets are plain dicts, not defaultdicts."""
        from collections import defaultdict
        mw = self._make_middleware()
        assert type(mw._general) is dict, f"Expected dict, got {type(mw._general)}"
        assert type(mw._auth) is dict, f"Expected dict, got {type(mw._auth)}"
        assert not isinstance(mw._general, defaultdict)
