"""
Tests for SSRF hardening — builtin WebFetchTool and MCP web_fetch.

Fix: _is_ssrf_target in builtin.py failed open on DNS errors and lacked
scheme validation. Now uses validate_url() from backend/security.py or
a strict inline fallback that blocks on any uncertainty.
"""

import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


class TestBuiltinSsrfCheck:
    """Test _is_ssrf_target in aibrain/tools/builtin.py."""

    def test_blocks_file_scheme(self):
        from aibrain.tools.builtin import _is_ssrf_target
        assert _is_ssrf_target("file:///etc/passwd") is True

    def test_blocks_gopher_scheme(self):
        from aibrain.tools.builtin import _is_ssrf_target
        assert _is_ssrf_target("gopher://evil.com/payload") is True

    def test_blocks_localhost(self):
        from aibrain.tools.builtin import _is_ssrf_target
        assert _is_ssrf_target("http://localhost/admin") is True

    def test_blocks_127_0_0_1(self):
        from aibrain.tools.builtin import _is_ssrf_target
        assert _is_ssrf_target("http://127.0.0.1:8080/secret") is True

    def test_blocks_metadata_endpoint(self):
        from aibrain.tools.builtin import _is_ssrf_target
        assert _is_ssrf_target("http://169.254.169.254/latest/meta-data/") is True

    def test_blocks_private_10(self):
        from aibrain.tools.builtin import _is_ssrf_target
        assert _is_ssrf_target("http://10.0.0.1/internal") is True

    def test_blocks_zero_ip(self):
        from aibrain.tools.builtin import _is_ssrf_target
        assert _is_ssrf_target("http://0.0.0.0/") is True

    def test_blocks_dns_failure(self):
        """DNS resolution failure must block (fail closed), not allow."""
        from aibrain.tools.builtin import _is_ssrf_target
        # Use a hostname that will fail to resolve
        assert _is_ssrf_target("http://this-host-does-not-exist-xyzzy.invalid/") is True

    def test_allows_external_https(self):
        """Valid external HTTPS URL should be allowed."""
        from aibrain.tools.builtin import _is_ssrf_target
        # google.com resolves to a public IP
        assert _is_ssrf_target("https://www.google.com/") is False


class TestWebFetchToolSsrf:
    """Test that WebFetchTool rejects SSRF attempts."""

    def test_web_fetch_rejects_localhost(self):
        from aibrain.tools.builtin import WebFetchTool
        tool = WebFetchTool()
        result = tool(url="http://127.0.0.1:11434/api/tags")
        assert "blocked" in result.lower() or "error" in result.lower()

    def test_web_fetch_rejects_file_scheme(self):
        from aibrain.tools.builtin import WebFetchTool
        tool = WebFetchTool()
        result = tool(url="file:///etc/passwd")
        assert "blocked" in result.lower() or "error" in result.lower()

    def test_web_fetch_rejects_internal_ip(self):
        from aibrain.tools.builtin import WebFetchTool
        tool = WebFetchTool()
        result = tool(url="http://192.168.1.1/admin")
        assert "blocked" in result.lower() or "error" in result.lower()


class TestMcpWebFetchSsrf:
    """Test that MCP web_fetch uses validate_url properly."""

    def test_mcp_web_fetch_blocks_localhost(self):
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from mcp_web_search import web_fetch
        result = web_fetch("http://127.0.0.1:9999/secret")
        assert "error" in result or "blocked" in str(result).lower()

    def test_mcp_web_fetch_blocks_private_ip(self):
        from mcp_web_search import web_fetch
        result = web_fetch("http://10.0.0.1:8080/internal")
        assert "error" in result or "blocked" in str(result).lower()

    def test_mcp_web_fetch_blocks_file_scheme(self):
        from mcp_web_search import web_fetch
        result = web_fetch("file:///etc/shadow")
        assert "error" in result or "blocked" in str(result).lower()
