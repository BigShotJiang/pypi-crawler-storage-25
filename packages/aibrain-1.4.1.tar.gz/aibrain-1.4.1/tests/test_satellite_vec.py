"""
Tests for satellite database vector embeddings.

Covers:
  - memories_vec table creation on satellite init
  - Embedding computed and stored on satellite insert
  - Vector search works on satellite memories
  - Existing satellites get vec table on reconnect (migration)
  - Hybrid FTS+vec satellite search
  - Backfill embeddings for existing satellite memories
  - Federated search uses vector similarity
"""

import os
import sqlite3
import struct
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def isolated_db():
    """Create isolated main + satellite DBs for testing."""
    import aibrain_db

    # Save original state
    orig_path = aibrain_db.DB_PATH
    orig_conn = aibrain_db._conn
    orig_sat_conns = aibrain_db._satellite_conns.copy()
    orig_embedder = aibrain_db._db_embedder
    orig_vec_enabled = aibrain_db._db_vec_enabled
    orig_vec_available = aibrain_db._SQLITE_VEC_AVAILABLE

    # Create temp main DB
    fd, main_path = tempfile.mkstemp(suffix=".db", prefix="aibrain_main_test_")
    os.close(fd)
    aibrain_db.DB_PATH = Path(main_path)
    aibrain_db._conn = None
    aibrain_db._satellite_conns = {}

    # Initialize main DB
    aibrain_db.get_db()

    yield aibrain_db, main_path

    # Restore original state
    try:
        aibrain_db._conn.close()
    except Exception:
        pass
    for c in aibrain_db._satellite_conns.values():
        try:
            c.close()
        except Exception:
            pass

    aibrain_db._conn = orig_conn
    aibrain_db.DB_PATH = orig_path
    aibrain_db._satellite_conns = orig_sat_conns
    aibrain_db._db_embedder = orig_embedder
    aibrain_db._db_vec_enabled = orig_vec_enabled
    aibrain_db._SQLITE_VEC_AVAILABLE = orig_vec_available

    # Cleanup temp files
    for p in [main_path]:
        for ext in ("", "-wal", "-shm"):
            try:
                os.unlink(p + ext)
            except OSError:
                pass


def _create_satellite(aibrain_db, name="test_sat"):
    """Register a satellite DB and return its path."""
    fd, sat_path = tempfile.mkstemp(suffix=".db", prefix=f"aibrain_{name}_test_")
    os.close(fd)
    aibrain_db.satellite_register(
        name=name,
        db_path=sat_path,
        description="Test satellite",
        memory_types=["test_type"],
        search_keywords="test,satellite",
    )
    return sat_path


class TestSatelliteVecTableCreation:
    """Test that memories_vec gets created in satellite DBs."""

    def test_vec_table_created_when_vec_available(self, isolated_db):
        """memories_vec should exist in satellite when sqlite_vec is available."""
        aibrain_db, _ = isolated_db

        # Mock: embedder available, sqlite_vec available
        aibrain_db._db_vec_enabled = True
        aibrain_db._db_embedder = True  # Truthy placeholder
        aibrain_db._SQLITE_VEC_AVAILABLE = True

        # We can't actually create a vec0 table without the real extension,
        # so we test that the code TRIES to create it. We'll mock the conn.
        sat_path = None
        try:
            fd, sat_path = tempfile.mkstemp(suffix=".db", prefix="aibrain_vectest_")
            os.close(fd)

            # Check that _get_satellite_db loads extension and creates schema
            aibrain_db.satellite_register(
                name="vec_test",
                db_path=sat_path,
                description="Vec test satellite",
                memory_types=["vec_type"],
                search_keywords="vec",
            )

            # The satellite should at minimum have the memories table
            sat_db = aibrain_db._get_satellite_db("vec_test")
            tables = [r[0] for r in sat_db.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table', 'shadow')"
            ).fetchall()]
            assert "memories" in tables
            assert "memories_fts" in tables

            # If sqlite_vec is truly installed, memories_vec will exist
            try:
                import sqlite_vec
                assert any("memories_vec" in t for t in tables)
            except ImportError:
                pass  # Expected — vec table won't exist without extension
        finally:
            if sat_path:
                for ext in ("", "-wal", "-shm"):
                    try:
                        os.unlink(sat_path + ext)
                    except OSError:
                        pass

    def test_satellite_works_without_vec(self, isolated_db):
        """Satellite should work fine with FTS-only when vec is unavailable."""
        aibrain_db, _ = isolated_db
        aibrain_db._db_vec_enabled = False
        aibrain_db._SQLITE_VEC_AVAILABLE = False

        sat_path = _create_satellite(aibrain_db, "fts_only_sat")
        try:
            sat_db = aibrain_db._get_satellite_db("fts_only_sat")
            # Should have core tables
            tables = [r[0] for r in sat_db.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table', 'shadow')"
            ).fetchall()]
            assert "memories" in tables
            assert "memories_fts" in tables
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass


class TestSatelliteEmbeddingOnInsert:
    """Test that embeddings are computed when inserting into satellites."""

    def test_embedding_stored_on_satellite_create(self, isolated_db):
        """create_memory should store embedding in satellite memories_vec."""
        aibrain_db, _ = isolated_db

        # Check if real embeddings are available
        try:
            import sqlite_vec
            from sentence_transformers import SentenceTransformer
            has_deps = True
        except ImportError:
            has_deps = False

        if not has_deps:
            pytest.skip("sqlite_vec + sentence_transformers required for vec insert test")

        # Enable real embeddings
        aibrain_db.init_embedder()
        aibrain_db._SQLITE_VEC_AVAILABLE = True

        sat_path = _create_satellite(aibrain_db, "embed_test")
        try:
            # Clear satellite conn cache to force re-init with vec
            aibrain_db._satellite_conns.pop("embed_test", None)

            # Create a memory routed to satellite
            mem_id = aibrain_db.create_memory(
                name="test embedding storage",
                content="This is a test of vector embedding in satellites",
                mem_type="test_type",
            )
            assert isinstance(mem_id, int)

            # Verify embedding was stored
            sat_db = aibrain_db._get_satellite_db("embed_test")
            vec_row = sat_db.execute(
                "SELECT memory_id, embedding FROM memories_vec WHERE memory_id=?",
                (mem_id,)
            ).fetchone()
            assert vec_row is not None, "Embedding should be stored in satellite vec table"
            assert vec_row[0] == mem_id

            # Verify embedding has correct dimension
            emb_bytes = vec_row[1]
            dim = len(emb_bytes) // 4  # 4 bytes per float32
            assert dim > 0, "Embedding should have non-zero dimension"
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass

    def test_no_embedding_when_disabled(self, isolated_db):
        """No embedding insert attempted when _db_vec_enabled is False."""
        aibrain_db, _ = isolated_db
        aibrain_db._db_vec_enabled = False
        aibrain_db._db_embedder = None
        aibrain_db._SQLITE_VEC_AVAILABLE = False

        sat_path = _create_satellite(aibrain_db, "no_embed_test")
        try:
            mem_id = aibrain_db.create_memory(
                name="no embedding test",
                content="Should not have embedding",
                mem_type="test_type",
            )
            assert isinstance(mem_id, int)

            # Verify memory exists in satellite but no vec table
            sat_db = aibrain_db._get_satellite_db("no_embed_test")
            row = sat_db.execute("SELECT * FROM memories WHERE id=?", (mem_id,)).fetchone()
            assert row is not None
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass


class TestSatelliteVecSearch:
    """Test vector similarity search on satellite databases."""

    def test_vec_search_on_satellite(self, isolated_db):
        """satellite_search should use vector similarity when available."""
        aibrain_db, _ = isolated_db

        try:
            import sqlite_vec
            from sentence_transformers import SentenceTransformer
            has_deps = True
        except ImportError:
            has_deps = False

        if not has_deps:
            pytest.skip("sqlite_vec + sentence_transformers required")

        aibrain_db.init_embedder()
        aibrain_db._SQLITE_VEC_AVAILABLE = True

        sat_path = _create_satellite(aibrain_db, "search_test")
        try:
            aibrain_db._satellite_conns.pop("search_test", None)

            # Insert several memories with distinct topics
            topics = [
                ("SQL injection defense", "Parameterized queries prevent SQL injection attacks"),
                ("XSS prevention", "Content Security Policy headers block cross-site scripting"),
                ("Buffer overflow", "Stack canaries detect buffer overflow exploitation"),
                ("Network segmentation", "VLANs isolate critical systems from general network"),
                ("Password policy", "Enforce minimum 12 characters with complexity requirements"),
            ]
            for name, content in topics:
                aibrain_db.create_memory(name=name, content=content, mem_type="test_type")

            # Semantic search — should find security-related results
            results = aibrain_db.satellite_search("search_test", "how to stop injection attacks")
            assert len(results) > 0, "Vec search should return results"

            # The SQL injection result should rank high
            names = [r.get("name", "") for r in results]
            assert any("injection" in n.lower() for n in names), \
                f"SQL injection memory should match injection query. Got: {names}"
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass

    def test_fts_fallback_without_vec(self, isolated_db):
        """satellite_search falls back to FTS when vec is unavailable."""
        aibrain_db, _ = isolated_db
        aibrain_db._db_vec_enabled = False
        aibrain_db._db_embedder = None
        aibrain_db._SQLITE_VEC_AVAILABLE = False

        sat_path = _create_satellite(aibrain_db, "fts_fallback_test")
        try:
            aibrain_db._satellite_conns.pop("fts_fallback_test", None)

            aibrain_db.create_memory(
                name="keyword match test",
                content="This memory contains the keyword searchable",
                mem_type="test_type",
            )

            results = aibrain_db.satellite_search("fts_fallback_test", "searchable")
            assert len(results) > 0, "FTS fallback should find keyword matches"
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass


class TestSatelliteMigration:
    """Test migration path for existing satellites without vec tables."""

    def test_existing_satellite_gets_vec_on_reconnect(self, isolated_db):
        """When a satellite without vec is reconnected with vec enabled, it gets the table."""
        aibrain_db, _ = isolated_db

        try:
            import sqlite_vec
            from sentence_transformers import SentenceTransformer
            has_deps = True
        except ImportError:
            has_deps = False

        if not has_deps:
            pytest.skip("sqlite_vec + sentence_transformers required")

        # Step 1: Create satellite WITHOUT vec
        aibrain_db._db_vec_enabled = False
        aibrain_db._SQLITE_VEC_AVAILABLE = False

        sat_path = _create_satellite(aibrain_db, "migrate_test")
        try:
            # Insert a memory (no embedding)
            aibrain_db.create_memory(
                name="pre-vec memory",
                content="This was created before vector support",
                mem_type="test_type",
            )

            # Verify no vec table
            sat_db = aibrain_db._get_satellite_db("migrate_test")
            tables = [r[0] for r in sat_db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()]
            assert "memories_vec" not in tables

            # Step 2: Enable vec and reconnect
            aibrain_db._db_vec_enabled = True
            aibrain_db._SQLITE_VEC_AVAILABLE = True
            aibrain_db.init_embedder()
            # Clear connection cache to force re-init
            aibrain_db._satellite_conns.pop("migrate_test", None)

            # Reconnect — should create vec table
            sat_db = aibrain_db._get_satellite_db("migrate_test")
            tables = [r[0] for r in sat_db.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table', 'shadow')"
            ).fetchall()]
            assert any("memories_vec" in t for t in tables), \
                f"memories_vec should exist after reconnect. Tables: {tables}"

        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass


class TestBackfillEmbeddings:
    """Test satellite_backfill_embeddings function."""

    def test_backfill_with_vec_disabled(self, isolated_db):
        """Backfill should return error dict when embeddings unavailable."""
        aibrain_db, _ = isolated_db
        aibrain_db._db_vec_enabled = False

        result = aibrain_db.satellite_backfill_embeddings("nonexistent")
        assert result["error"] == "embeddings not available"

    def test_backfill_embeds_existing_memories(self, isolated_db):
        """Backfill should embed existing satellite memories."""
        aibrain_db, _ = isolated_db

        try:
            import sqlite_vec
            from sentence_transformers import SentenceTransformer
            has_deps = True
        except ImportError:
            has_deps = False

        if not has_deps:
            pytest.skip("sqlite_vec + sentence_transformers required")

        # Create satellite without vec first
        aibrain_db._db_vec_enabled = False
        aibrain_db._SQLITE_VEC_AVAILABLE = False

        sat_path = _create_satellite(aibrain_db, "backfill_test")
        try:
            # Insert memories without embeddings
            for i in range(3):
                aibrain_db.create_memory(
                    name=f"backfill memory {i}",
                    content=f"Content for backfill test number {i}",
                    mem_type="test_type",
                )

            # Enable vec and reconnect
            aibrain_db._db_vec_enabled = True
            aibrain_db._SQLITE_VEC_AVAILABLE = True
            aibrain_db.init_embedder()
            aibrain_db._satellite_conns.pop("backfill_test", None)

            # Backfill
            result = aibrain_db.satellite_backfill_embeddings("backfill_test")
            assert result["total"] == 3
            assert result["embedded"] == 3
            assert result["skipped"] == 0

            # Verify embeddings exist
            sat_db = aibrain_db._get_satellite_db("backfill_test")
            vec_count = sat_db.execute("SELECT COUNT(*) FROM memories_vec").fetchone()[0]
            assert vec_count == 3
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass


class TestFederatedSearch:
    """Test federated_search uses vector similarity on satellites."""

    def test_federated_search_includes_satellite_results(self, isolated_db):
        """federated_search should return results from satellites."""
        aibrain_db, _ = isolated_db
        aibrain_db._db_vec_enabled = False
        aibrain_db._SQLITE_VEC_AVAILABLE = False

        sat_path = _create_satellite(aibrain_db, "fed_test")
        try:
            aibrain_db.create_memory(
                name="satellite test finding",
                content="This satellite memory should appear in federated search",
                mem_type="test_type",
            )

            results = aibrain_db.federated_search("satellite test")
            assert "fed_test" in results, f"Satellite results missing. Keys: {list(results.keys())}"
            assert len(results["fed_test"]) > 0
        finally:
            for ext in ("", "-wal", "-shm"):
                try:
                    os.unlink(sat_path + ext)
                except OSError:
                    pass
