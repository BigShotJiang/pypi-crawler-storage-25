"""
Tests for aibrain/core/secrets.py — secure secrets vault.

Covers: store, get, update, list, delete, has_secret, scoping.
Uses tmp_path for full DB isolation.
"""

import os
import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture(autouse=True)
def isolated_secrets_db(tmp_path, monkeypatch):
    """Point secrets module at a temp DB for every test."""
    db_path = str(tmp_path / "test_secrets.db")
    monkeypatch.setenv("AIBRAIN_DB", db_path)
    # Also set a stable secret key so encryption is deterministic
    monkeypatch.setenv("AIBRAIN_SECRET_KEY", "test-secret-key-for-unit-tests")
    yield db_path


# Import after fixture setup path is defined (module uses env at call time)
from aibrain.core.secrets import (
    delete_secret,
    get_secret,
    has_secret,
    list_secrets,
    store_secret,
)


# ---------------------------------------------------------------------------
# store_secret
# ---------------------------------------------------------------------------

class TestStoreSecret:
    def test_store_returns_created(self):
        result = store_secret("api_key", "sk-12345")
        assert result["action"] == "created"
        assert result["version"] == 1
        assert result["name"] == "api_key"

    def test_store_with_company_id(self):
        result = store_secret("token", "abc", company_id="comp1")
        assert result["action"] == "created"

    def test_store_with_agent_id(self):
        result = store_secret("token", "def", agent_id="agent1")
        assert result["action"] == "created"

    def test_store_with_scope(self):
        result = store_secret("scoped", "val", scope="agent", agent_id="a1")
        assert result["action"] == "created"

    def test_store_with_created_by(self):
        result = store_secret("audit", "val", created_by="neuro")
        assert result["action"] == "created"


# ---------------------------------------------------------------------------
# get_secret
# ---------------------------------------------------------------------------

class TestGetSecret:
    def test_get_stored_secret(self):
        store_secret("my_key", "my_value_123")
        val = get_secret("my_key")
        assert val == "my_value_123"

    def test_get_nonexistent_returns_none(self):
        assert get_secret("does_not_exist") is None

    def test_get_with_company_scope(self):
        store_secret("ckey", "cval", company_id="c1")
        assert get_secret("ckey", company_id="c1") == "cval"
        # Without company_id should not find it
        assert get_secret("ckey") is None

    def test_get_with_agent_scope(self):
        store_secret("akey", "aval", agent_id="a1")
        assert get_secret("akey", agent_id="a1") == "aval"
        assert get_secret("akey") is None

    def test_roundtrip_special_characters(self):
        special = "p@$$w0rd!#%^&*(){}[]|\\:\";<>?/~`"
        store_secret("special", special)
        assert get_secret("special") == special

    def test_roundtrip_long_value(self):
        long_val = "x" * 10000
        store_secret("long", long_val)
        assert get_secret("long") == long_val

    def test_roundtrip_unicode(self):
        val = "secret_with_unicode_\u00e9\u00e8\u00ea\u2603"
        store_secret("unicode", val)
        assert get_secret("unicode") == val

    def test_roundtrip_empty_string(self):
        store_secret("empty", "")
        # Empty string is stored but may come back as empty or None depending on encrypt behavior
        result = get_secret("empty")
        assert result is not None  # key exists


# ---------------------------------------------------------------------------
# update (store over existing)
# ---------------------------------------------------------------------------

class TestUpdateSecret:
    def test_update_increments_version(self):
        r1 = store_secret("evolving", "v1")
        assert r1["version"] == 1
        r2 = store_secret("evolving", "v2")
        assert r2["version"] == 2
        assert r2["action"] == "updated"

    def test_update_changes_value(self):
        store_secret("mutable", "old")
        store_secret("mutable", "new")
        assert get_secret("mutable") == "new"

    def test_update_multiple_times(self):
        for i in range(5):
            r = store_secret("counter", f"val_{i}")
        assert r["version"] == 5
        assert get_secret("counter") == "val_4"


# ---------------------------------------------------------------------------
# list_secrets
# ---------------------------------------------------------------------------

class TestListSecrets:
    def test_list_empty(self):
        result = list_secrets()
        assert result == []

    def test_list_returns_names_not_values(self):
        store_secret("key1", "secret_value_1")
        store_secret("key2", "secret_value_2")
        result = list_secrets()
        assert len(result) == 2
        for entry in result:
            assert "name" in entry
            assert "encrypted_value" not in entry
            # Values should NOT appear in list output
            assert "secret_value_1" not in str(entry)
            assert "secret_value_2" not in str(entry)

    def test_list_has_metadata(self):
        store_secret("meta_key", "val")
        result = list_secrets()
        assert len(result) == 1
        entry = result[0]
        assert entry["name"] == "meta_key"
        assert "version" in entry
        assert "created_at" in entry
        assert "updated_at" in entry

    def test_list_scoped_by_company(self):
        store_secret("global", "g")
        store_secret("comp", "c", company_id="c1")
        global_list = list_secrets()
        comp_list = list_secrets(company_id="c1")
        assert len(global_list) == 1
        assert global_list[0]["name"] == "global"
        assert len(comp_list) == 1
        assert comp_list[0]["name"] == "comp"

    def test_list_ordered_by_name(self):
        store_secret("zebra", "z")
        store_secret("alpha", "a")
        store_secret("mid", "m")
        result = list_secrets()
        names = [r["name"] for r in result]
        assert names == sorted(names)


# ---------------------------------------------------------------------------
# delete_secret
# ---------------------------------------------------------------------------

class TestDeleteSecret:
    def test_delete_existing(self):
        store_secret("doomed", "val")
        assert delete_secret("doomed") is True
        assert get_secret("doomed") is None

    def test_delete_nonexistent_returns_false(self):
        assert delete_secret("ghost") is False

    def test_delete_scoped(self):
        store_secret("scoped_del", "v", company_id="c1")
        # Deleting without scope should not find it
        assert delete_secret("scoped_del") is False
        # Deleting with correct scope works
        assert delete_secret("scoped_del", company_id="c1") is True

    def test_delete_does_not_affect_other_scopes(self):
        store_secret("shared_name", "global")
        store_secret("shared_name", "comp", company_id="c1")
        delete_secret("shared_name")
        # Company-scoped one should still exist
        assert get_secret("shared_name", company_id="c1") == "comp"


# ---------------------------------------------------------------------------
# has_secret
# ---------------------------------------------------------------------------

class TestHasSecret:
    def test_has_existing_true(self):
        store_secret("exists", "val")
        assert has_secret("exists") is True

    def test_has_nonexistent_false(self):
        assert has_secret("nope") is False

    def test_has_respects_scope(self):
        store_secret("scoped", "v", company_id="c1")
        assert has_secret("scoped", company_id="c1") is True
        assert has_secret("scoped") is False

    def test_has_after_delete(self):
        store_secret("temp", "v")
        assert has_secret("temp") is True
        delete_secret("temp")
        assert has_secret("temp") is False


# ---------------------------------------------------------------------------
# Scoping isolation
# ---------------------------------------------------------------------------

class TestScopeIsolation:
    def test_same_name_different_companies(self):
        store_secret("api_key", "key_a", company_id="a")
        store_secret("api_key", "key_b", company_id="b")
        assert get_secret("api_key", company_id="a") == "key_a"
        assert get_secret("api_key", company_id="b") == "key_b"

    def test_same_name_different_agents(self):
        store_secret("token", "t1", agent_id="agent1")
        store_secret("token", "t2", agent_id="agent2")
        assert get_secret("token", agent_id="agent1") == "t1"
        assert get_secret("token", agent_id="agent2") == "t2"

    def test_company_and_agent_isolation(self):
        store_secret("key", "global_val")
        store_secret("key", "comp_val", company_id="c1")
        store_secret("key", "agent_val", agent_id="a1")
        assert get_secret("key") == "global_val"
        assert get_secret("key", company_id="c1") == "comp_val"
        assert get_secret("key", agent_id="a1") == "agent_val"

    def test_list_isolation(self):
        store_secret("g1", "v")
        store_secret("c1_key", "v", company_id="c1")
        store_secret("a1_key", "v", agent_id="a1")
        assert len(list_secrets()) == 1
        assert len(list_secrets(company_id="c1")) == 1
        assert len(list_secrets(agent_id="a1")) == 1
