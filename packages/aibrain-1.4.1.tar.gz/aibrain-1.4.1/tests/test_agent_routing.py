"""
Tests for aibrain/core/task_router.py — SelRoute-inspired agent routing.

Uses a temporary SQLite DB for full isolation.
"""

import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Schema from test_companies.py
SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, mission TEXT,
    status TEXT DEFAULT 'active', budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS company_agents (
    id TEXT PRIMARY KEY, company_id TEXT NOT NULL, name TEXT NOT NULL,
    role TEXT DEFAULT 'general', title TEXT, status TEXT DEFAULT 'idle',
    reports_to TEXT, model TEXT DEFAULT 'auto', task_type TEXT DEFAULT 'judgment',
    authority TEXT DEFAULT 'standard', budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0, heartbeat_interval_seconds INTEGER DEFAULT 14400,
    last_heartbeat_at TIMESTAMP, instructions TEXT, capabilities TEXT,
    permissions TEXT, metadata TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS company_issues (
    id TEXT PRIMARY KEY, company_id TEXT NOT NULL, parent_id TEXT,
    title TEXT NOT NULL, description TEXT,
    status TEXT DEFAULT 'backlog', priority TEXT DEFAULT 'medium',
    assignee_agent_id TEXT, project TEXT, issue_number INTEGER,
    origin TEXT DEFAULT 'manual', request_depth INTEGER DEFAULT 0,
    quality_score REAL, cost_cents INTEGER DEFAULT 0,
    started_at TIMESTAMP, completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT);
"""


@pytest.fixture()
def routed_db(tmp_path):
    """Create a temp DB with agents for routing tests."""
    db_path = tmp_path / "test_router.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)

    # Insert a company
    conn.execute("INSERT INTO companies (id, name, mission) VALUES ('co1', 'TestCo', 'Test')")

    # Insert agents with different roles/capabilities
    agents = [
        ("a1", "co1", "Lead Engineer", "general", "Lead Engineer",
         "code features bug fixes implementation python javascript"),
        ("a2", "co1", "QA Lead", "manager", "QA Lead",
         "testing verification review quality assurance"),
        ("a3", "co1", "Security Engineer", "general", "Security Engineer",
         "security audits vulnerability scanning penetration testing"),
        ("a4", "co1", "Content Writer", "general", "Content Writer",
         "docs reports written content documentation"),
        ("a5", "co1", "DevOps Engineer", "general", "DevOps Engineer",
         "deployments ci cd infrastructure docker kubernetes"),
    ]
    for aid, cid, name, role, title, caps in agents:
        conn.execute(
            "INSERT INTO company_agents (id, company_id, name, role, title, capabilities) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (aid, cid, name, role, title, caps)
        )
    conn.commit()
    conn.close()

    def _patched_get_db():
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        return db

    with patch("aibrain.core.companies._get_db", _patched_get_db):
        yield db_path


# ---------------------------------------------------------------------------
# Tests for _tokenize
# ---------------------------------------------------------------------------

class TestTokenize:

    def test_basic_tokenize(self):
        from aibrain.core.task_router import _tokenize
        tokens = _tokenize("Fix the security vulnerability")
        assert "fix" in tokens
        assert "security" in tokens
        assert "vulnerability" in tokens
        # Stop words removed
        assert "the" not in tokens

    def test_empty_string(self):
        from aibrain.core.task_router import _tokenize
        assert _tokenize("") == set()


# ---------------------------------------------------------------------------
# Tests for _keyword_score
# ---------------------------------------------------------------------------

class TestKeywordScore:

    def test_perfect_match_scores_high(self):
        from aibrain.core.task_router import _keyword_score, _tokenize
        task_tokens = _tokenize("security audit vulnerability scanning")
        agent = {
            "name": "Security Engineer",
            "role": "general",
            "title": "Security Engineer",
            "capabilities": "security audits vulnerability scanning penetration testing",
        }
        score = _keyword_score(task_tokens, agent)
        assert score > 0.3  # significant overlap

    def test_no_overlap_scores_zero(self):
        from aibrain.core.task_router import _keyword_score, _tokenize
        task_tokens = _tokenize("marketing campaign social media")
        agent = {
            "name": "DevOps Engineer",
            "role": "general",
            "title": "DevOps",
            "capabilities": "docker kubernetes ci cd",
        }
        score = _keyword_score(task_tokens, agent)
        assert score == 0.0

    def test_empty_task_scores_zero(self):
        from aibrain.core.task_router import _keyword_score
        agent = {"name": "Alice", "role": "general", "title": "", "capabilities": "code"}
        assert _keyword_score(set(), agent) == 0.0


# ---------------------------------------------------------------------------
# Tests for score_agents
# ---------------------------------------------------------------------------

class TestScoreAgents:

    def test_scores_all_agents(self, routed_db):
        from aibrain.core.task_router import score_agents
        scores = score_agents("co1", "Fix a bug in Python code")
        assert len(scores) == 5
        # All have agent_id, name, role, score keys
        for s in scores:
            assert "agent_id" in s
            assert "score" in s

    def test_security_task_ranks_security_first(self, routed_db):
        from aibrain.core.task_router import score_agents
        scores = score_agents("co1", "Security audit", "Run vulnerability scanning")
        # Security engineer should be top-scored
        assert scores[0]["agent_id"] == "a3"

    def test_code_task_ranks_engineer_first(self, routed_db):
        from aibrain.core.task_router import score_agents
        scores = score_agents("co1", "Implement feature", "Write Python code for new feature")
        assert scores[0]["agent_id"] == "a1"

    def test_docs_task_ranks_writer_first(self, routed_db):
        from aibrain.core.task_router import score_agents
        scores = score_agents("co1", "Write documentation", "Create docs and reports")
        assert scores[0]["agent_id"] == "a4"

    def test_empty_company_returns_empty(self, routed_db):
        from aibrain.core.task_router import score_agents
        scores = score_agents("nonexistent", "Anything")
        assert scores == []


# ---------------------------------------------------------------------------
# Tests for route_task
# ---------------------------------------------------------------------------

class TestRouteTask:

    def test_routes_primary_and_secondary(self, routed_db):
        from aibrain.core.task_router import route_task
        result = route_task("co1", "Security audit", "Scan for vulnerabilities")
        assert result["primary"] is not None
        assert result["secondary"] is not None
        assert result["primary"] != result["secondary"]

    def test_explicit_assignee_becomes_primary(self, routed_db):
        from aibrain.core.task_router import route_task
        result = route_task("co1", "Any task", explicit_assignee="a5")
        assert result["primary"] == "a5"
        assert result["secondary"] is not None
        assert result["secondary"] != "a5"

    def test_secondary_prefers_manager_role(self, routed_db):
        from aibrain.core.task_router import route_task
        # For a security task, primary should be security engineer (a3)
        # Secondary should prefer QA Lead (a2, manager role) over others
        result = route_task("co1", "Security audit", "Vulnerability scanning")
        assert result["primary"] == "a3"
        # QA Lead (manager) gets review bonus
        assert result["secondary"] == "a2"

    def test_empty_company_returns_none(self, routed_db):
        from aibrain.core.task_router import route_task
        result = route_task("nonexistent", "Task")
        assert result["primary"] is None
        assert result["secondary"] is None

    def test_scores_returned(self, routed_db):
        from aibrain.core.task_router import route_task
        result = route_task("co1", "Deploy infrastructure", "Docker kubernetes setup")
        assert len(result["scores"]) == 5
        assert all(isinstance(s["score"], float) for s in result["scores"])


# ---------------------------------------------------------------------------
# Tests for create_task integration
# ---------------------------------------------------------------------------

class TestCreateTaskRouting:

    def test_auto_route_assigns_agents(self, routed_db):
        from aibrain.core.companies import create_task
        t = create_task("co1", "Security audit", description="Run vulnerability scan")
        # Should have an assignee (auto-routed)
        assert t["assignee_agent_id"] is not None

    def test_auto_route_returns_secondary(self, routed_db):
        from aibrain.core.companies import create_task
        t = create_task("co1", "Security audit", description="Run vulnerability scan")
        # Secondary should be in the returned dict
        assert "secondary_agent_id" in t

    def test_explicit_assignee_preserved(self, routed_db):
        from aibrain.core.companies import create_task
        t = create_task("co1", "Any task", assignee_agent_id="a1")
        assert t["assignee_agent_id"] == "a1"

    def test_auto_route_disabled(self, routed_db):
        from aibrain.core.companies import create_task
        t = create_task("co1", "Test task", auto_route=False)
        # No assignee when auto_route is off and none provided
        assert t["assignee_agent_id"] is None

    def test_auto_route_with_explicit_still_has_secondary(self, routed_db):
        from aibrain.core.companies import create_task
        t = create_task("co1", "Code fix", assignee_agent_id="a1")
        assert t["assignee_agent_id"] == "a1"
        assert "secondary_agent_id" in t
        assert t["secondary_agent_id"] != "a1"
