"""
Tests for MEMORY_STORED → SCAN_FINDING_STORED event bridge.

Verifies that when MEMORY_STORED fires with a security/scan-related memory,
a SCAN_FINDING_STORED follow-up event is emitted for permeate_brain consumption.
"""

import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

from aibrain.core.event_bus import emit, on, clear_handlers, EventTypes
from aibrain.core.reactive_chains import (
    on_memory_stored,
    _is_security_memory,
    register_reactive_chains,
    reset,
)


def _make_db():
    """Create test DB with needed tables."""
    db_path = Path(_tmpdir) / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS event_bus_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            payload TEXT,
            created TEXT DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_event_bus_type ON event_bus_log(event_type);
    """)
    conn.commit()
    conn.close()
    return db_path


@pytest.fixture(autouse=True)
def _clean_state():
    """Reset everything between tests."""
    clear_handlers()
    reset()
    _make_db()
    # Clean event log
    db_path = Path(_tmpdir) / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("DELETE FROM event_bus_log")
    conn.commit()
    conn.close()
    yield
    clear_handlers()
    reset()


# ---------------------------------------------------------------------------
# 1. Security memory triggers SCAN_FINDING_STORED
# ---------------------------------------------------------------------------

def test_security_memory_emits_scan_finding():
    """A memory with security keywords should emit SCAN_FINDING_STORED."""
    captured = []
    on(EventTypes.SCAN_FINDING_STORED, lambda p: captured.append(p))

    on_memory_stored({
        "id": 42,
        "name": "CVE-2024-1234 RCE in target-A",
        "type": "finding",
        "tags": "security,scan",
        "content_preview": "Remote code execution via deserialization",
    })

    assert len(captured) == 1
    assert captured[0]["memory_id"] == 42
    assert captured[0]["source"] == "memory_stored_bridge"
    assert "CVE-2024-1234" in captured[0]["name"]


# ---------------------------------------------------------------------------
# 2. Non-security memory does NOT trigger SCAN_FINDING_STORED
# ---------------------------------------------------------------------------

def test_nonsecurity_memory_no_event():
    """A non-security memory should not emit SCAN_FINDING_STORED."""
    captured = []
    on(EventTypes.SCAN_FINDING_STORED, lambda p: captured.append(p))

    on_memory_stored({
        "id": 99,
        "name": "Decker prefers dark mode",
        "type": "user",
        "tags": "preference",
        "content_preview": "User settings for UI theme",
    })

    assert len(captured) == 0


# ---------------------------------------------------------------------------
# 3. Full event bus integration — MEMORY_STORED fires chain
# ---------------------------------------------------------------------------

def test_full_event_bus_integration():
    """Emitting MEMORY_STORED through the event bus triggers the bridge."""
    register_reactive_chains()

    captured = []
    on(EventTypes.SCAN_FINDING_STORED, lambda p: captured.append(p))

    emit(EventTypes.MEMORY_STORED, {
        "id": 100,
        "name": "XSS reflected in login page",
        "type": "finding",
        "tags": "vuln,scan",
        "content_preview": "Reflected XSS via q parameter",
    })

    assert len(captured) == 1
    assert captured[0]["memory_id"] == 100


# ---------------------------------------------------------------------------
# 4. _is_security_memory classification
# ---------------------------------------------------------------------------

def test_is_security_memory_by_type():
    """Memories with type='finding' are security-related."""
    assert _is_security_memory({"type": "finding"}) is True
    assert _is_security_memory({"type": "scan"}) is True
    assert _is_security_memory({"type": "vulnerability"}) is True


def test_is_security_memory_by_tags():
    """Memories with security tags are detected."""
    assert _is_security_memory({"tags": "security,ops"}) is True
    assert _is_security_memory({"tags": ["exploit", "chain"]}) is True
    assert _is_security_memory({"tags": "preference,ui"}) is False


def test_is_security_memory_by_content():
    """Memories with security keywords in content are detected."""
    assert _is_security_memory({
        "content_preview": "nmap scan revealed open port 445"
    }) is True
    assert _is_security_memory({
        "name": "SQL injection in /api/users endpoint"
    }) is True
    assert _is_security_memory({
        "content_preview": "Updated the README with installation steps"
    }) is False


# ---------------------------------------------------------------------------
# 5. Handler never raises on bad payloads
# ---------------------------------------------------------------------------

def test_handler_tolerates_bad_payloads():
    """on_memory_stored must not raise even with garbage input."""
    on_memory_stored({})
    on_memory_stored({"type": None, "tags": None, "name": None})
    on_memory_stored({"id": None, "content_preview": 12345})


# ---------------------------------------------------------------------------
# 6. SCAN_FINDING_STORED event type exists on EventTypes
# ---------------------------------------------------------------------------

def test_event_type_constant_exists():
    """EventTypes.SCAN_FINDING_STORED should be defined."""
    assert hasattr(EventTypes, "SCAN_FINDING_STORED")
    assert EventTypes.SCAN_FINDING_STORED == "SCAN_FINDING_STORED"
