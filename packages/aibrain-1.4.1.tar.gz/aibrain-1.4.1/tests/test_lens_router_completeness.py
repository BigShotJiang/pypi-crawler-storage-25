"""test_lens_router_completeness.py — regression tests for the lens roster.

Three invariants the SuperWorker routing system must maintain:

1. Every hired company_agent has a matching entry in lens_router.LENSES,
   so the SuperWorker can actually route to them. Special case: the CEO
   "Neuro" in company_agents matches "Neuro (CEO)" in LENSES (intentional
   labeling — same person, two roles).

2. Every entry in LENSES appears in at least one TASK_TYPE_LENSES list.
   Otherwise the lens is "orphaned" — known to the system but unreachable
   via routing because route() picks from the per-task-type lists, not
   from the LENSES dict directly.

3. Every key in TASK_TYPE_LENSES has a matching entry in
   agent_router.SHAPE_TABLE, so route() in agent_router doesn't fall
   through to the broad_unknown default for any registered task type.

These invariants are how we prevent the kind of silent gap Decker caught
on Apr 11 — 13 specialty agents hired in company_agents Apr 8 but never
added to lens_router, so the SuperWorker could never pick them. The Bruce
Lee promise is "channel every relevant lens"; if a lens exists but cannot
be picked, the promise is broken silently.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from aibrain.core.agent_router import SHAPE_TABLE
from aibrain.core.lens_router import LENSES, TASK_TYPE_LENSES


def _resolve_brain_db() -> Path:
    """Use the canonical resolver."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / "aibrain.db"


# --- Invariant 1: every company_agent is in LENSES -----------------------

def test_every_company_agent_has_lens_entry():
    """For each row in company_agents, the agent name must be findable in
    lens_router.LENSES — either by direct match or by the documented Neuro
    name convention."""
    db_path = _resolve_brain_db()
    if not db_path.exists():
        pytest.skip(f"brain DB not found at {db_path}")

    conn = sqlite3.connect(str(db_path))
    try:
        rows = conn.execute(
            "SELECT name, role FROM company_agents WHERE company_id='GT_LRWrEBQQ'"
        ).fetchall()
    finally:
        conn.close()

    if not rows:
        pytest.skip("no DeckerOps agents registered — fresh DB")

    missing = []
    for name, role in rows:
        # Direct match
        if name in LENSES:
            continue
        # Documented exception: "Neuro" (DB) ↔ "Neuro (CEO)" (LENSES)
        # Same person, two labels — Neuro the executor + Neuro the CEO lens
        if name == "Neuro" and "Neuro (CEO)" in LENSES:
            continue
        missing.append((name, role))

    assert not missing, (
        f"{len(missing)} company_agents are missing from lens_router.LENSES — "
        f"the SuperWorker can never route to them: {missing}"
    )


# --- Invariant 2: no orphan lenses ---------------------------------------

def test_every_lens_appears_in_at_least_one_task_type():
    """For each entry in LENSES, the name must appear in at least one
    TASK_TYPE_LENSES list. Otherwise route() can never pick it."""
    routable = set()
    for task_type, names in TASK_TYPE_LENSES.items():
        for name in names:
            routable.add(name)

    # ALWAYS_ON_LENSES are also implicitly routable — they're added to
    # every LensRoute regardless of task type
    from aibrain.core.lens_router import ALWAYS_ON_LENSES
    routable.update(ALWAYS_ON_LENSES)

    orphans = [name for name in LENSES if name not in routable]

    assert not orphans, (
        f"{len(orphans)} lenses in LENSES are not in any TASK_TYPE_LENSES "
        f"list and would never be picked by route(): {orphans}"
    )


# --- Invariant 3: every task type has a SHAPE_TABLE entry ----------------

def test_every_task_type_has_shape_table_entry():
    """For each key in TASK_TYPE_LENSES, agent_router.SHAPE_TABLE must
    have a matching entry — otherwise agent_router.route() falls through
    to the broad_unknown default for that task type."""
    missing = [t for t in TASK_TYPE_LENSES if t not in SHAPE_TABLE]

    assert not missing, (
        f"{len(missing)} task types in TASK_TYPE_LENSES have no SHAPE_TABLE "
        f"entry in agent_router.py — route() will fall through to default "
        f"for: {missing}"
    )


# --- Sanity: counts are what we expect after the Apr 11 expansion --------

def test_lens_count_at_least_74():
    """Apr 11 expansion: 41 named shadows + 20 standing role workers + 13
    specialty workers = 74 lenses minimum. The Neuro/Neuro(CEO) split means
    LENSES has one more entry than company_agents has rows.

    This is a floor check — not a ceiling. New lenses can be added at any
    time. The check fails only if lenses get accidentally REMOVED.
    """
    assert len(LENSES) >= 74, (
        f"LENSES has only {len(LENSES)} entries — expected at least 74 "
        f"after the Apr 11 specialty-worker expansion. If this regressed, "
        f"check git log for accidental deletions."
    )
