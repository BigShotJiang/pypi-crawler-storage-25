"""
Tests for aibrain/core/harness.py — Universal Execution Harness.

Covers: task classification, quality evaluation, budget checking,
        authority checking, execute() pipeline, convenience wrappers.

Uses monkeypatching to avoid needing a real DB for most tests.
"""

import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.harness import (
    TaskType,
    Authority,
    RiskLevel,
    AUTHORITY_CAPABILITIES,
    HIGH_RISK_ACTIONS,
    MEDIUM_RISK_ACTIONS,
    MODEL_MAP,
    HarnessConfig,
    HarnessResult,
    execute,
    execute_deterministic,
    execute_simple,
    execute_judgment,
    execute_complex,
    classify_risk,
    _evaluate_quality,
    _check_authority,
    _check_approval,
    _check_budget,
)


# ---------------------------------------------------------------------------
# Task Classification / Model Routing
# ---------------------------------------------------------------------------


class TestTaskClassification:

    def test_deterministic_maps_to_code_only(self):
        assert MODEL_MAP[TaskType.DETERMINISTIC] == "code_only"

    def test_simple_maps_to_haiku(self):
        assert MODEL_MAP[TaskType.SIMPLE] == "haiku"

    def test_judgment_maps_to_sonnet(self):
        assert MODEL_MAP[TaskType.JUDGMENT] == "sonnet"

    def test_complex_maps_to_opus(self):
        assert MODEL_MAP[TaskType.COMPLEX] == "opus"

    def test_task_type_values(self):
        assert TaskType.DETERMINISTIC.value == "deterministic"
        assert TaskType.SIMPLE.value == "simple"
        assert TaskType.JUDGMENT.value == "judgment"
        assert TaskType.COMPLEX.value == "complex"

    def test_invalid_task_type_raises(self):
        with pytest.raises(ValueError):
            TaskType("nonexistent")


# ---------------------------------------------------------------------------
# Quality Evaluation
# ---------------------------------------------------------------------------


class TestQualityEvaluation:

    def test_none_output_deterministic(self):
        config = HarnessConfig(task_type="deterministic")
        score, detail = _evaluate_quality("test_task", None, config)
        assert score == 0.7
        assert "nothing to do" in detail

    def test_none_output_non_deterministic(self):
        config = HarnessConfig(task_type="judgment")
        score, detail = _evaluate_quality("test_task", None, config)
        assert score == 0.0
        assert "no output" in detail

    def test_dict_with_success(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", {"success": True}, config)
        assert score == 0.9

    def test_dict_with_status_ok(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", {"status": "ok"}, config)
        assert score == 0.9

    def test_dict_with_error(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", {"error": "something broke"}, config)
        assert score == 0.2

    def test_dict_neutral(self):
        # Honest-measurement rebuild: a dict with no success/error signal
        # produces no score (refuses to fake a number). Was 0.7 in v1.2.x.
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", {"data": [1, 2, 3]}, config)
        assert score is None

    def test_tuple_all_ok(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", (5, 0), config)
        assert score == 1.0

    def test_tuple_mixed(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", (3, 2), config)
        assert score == 0.7

    def test_tuple_all_failed(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", (0, 5), config)
        assert score == 0.3

    def test_bool_true(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", True, config)
        assert score == 1.0

    def test_bool_false(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", False, config)
        assert score == 0.0

    def test_list_non_empty(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", [1, 2, 3], config)
        assert score == 0.8

    def test_list_empty(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", [], config)
        assert score == 0.3

    def test_string_deterministic(self):
        config = HarnessConfig(task_type="deterministic")
        score, _ = _evaluate_quality("test_task", "some output", config)
        assert score >= 0.9

    def test_string_simple_long(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", "This is a reasonable output", config)
        assert score >= 0.5

    def test_string_simple_short(self):
        config = HarnessConfig(task_type="simple")
        score, _ = _evaluate_quality("test_task", "hi", config)
        assert score <= 0.5

    def test_error_signals_reduce_score(self):
        config = HarnessConfig(task_type="judgment")
        score, detail = _evaluate_quality("test_task", "error: something failed badly", config)
        assert "error signals" in detail

    def test_success_signals_boost_score(self):
        config = HarnessConfig(task_type="judgment")
        score, detail = _evaluate_quality("test_task", "Task completed successfully and saved the output", config)
        assert "success signals" in detail

    def test_score_clamped_0_to_1(self):
        config = HarnessConfig(task_type="judgment")
        # Very short error string -- should not go below 0.0
        score, _ = _evaluate_quality("test_task", "error failed exception traceback", config)
        assert 0.0 <= score <= 1.0


# ---------------------------------------------------------------------------
# Budget Checking
# ---------------------------------------------------------------------------


class TestBudgetCheck:

    def test_deterministic_always_passes(self):
        config = HarnessConfig(task_type="deterministic")
        ok, msg = _check_budget(config)
        assert ok is True
        assert "deterministic" in msg

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_no_db_allows(self, mock_db):
        config = HarnessConfig(task_type="simple")
        ok, msg = _check_budget(config)
        assert ok is True


# ---------------------------------------------------------------------------
# Authority Checking
# ---------------------------------------------------------------------------


class TestAuthorityCheck:

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_admin_allows_everything(self, mock_db):
        # _check_authority has two layers: (1) Authority enum capabilities,
        # (2) live DB agent_permissions lookup. Admin passes layer 1 via the
        # "*" wildcard but layer 2 may find explicit denies in the live DB.
        # Mock _find_db to None to isolate the layer-1 contract.
        config = HarnessConfig(authority="admin")
        ok, msg = _check_authority("delete_file", config)
        assert ok is True

    def test_read_only_denies_write(self):
        config = HarnessConfig(authority="read_only")
        ok, msg = _check_authority("write_file", config)
        assert ok is False
        assert "denies" in msg

    def test_read_only_allows_read(self):
        config = HarnessConfig(authority="read_only")
        ok, msg = _check_authority("read_file", config)
        assert ok is True

    def test_standard_denies_send_email(self):
        config = HarnessConfig(authority="standard")
        ok, msg = _check_authority("send_email", config)
        assert ok is False

    def test_standard_allows_write_file(self):
        config = HarnessConfig(authority="standard")
        ok, msg = _check_authority("write_file", config)
        assert ok is True

    def test_elevated_allows_git_push(self):
        config = HarnessConfig(authority="elevated")
        ok, msg = _check_authority("git_push", config)
        assert ok is True

    def test_elevated_requires_approval_for_spend(self):
        config = HarnessConfig(authority="elevated")
        ok, msg = _check_authority("spend_money", config)
        assert ok is False
        assert "requires approval" in msg

    def test_unknown_authority_defaults_to_allow(self):
        config = HarnessConfig(authority="totally_unknown")
        ok, msg = _check_authority("anything", config)
        assert ok is True

    def test_authority_capabilities_structure(self):
        """Verify all authority levels have the expected keys."""
        for auth in Authority:
            caps = AUTHORITY_CAPABILITIES[auth]
            assert "allowed" in caps


# ---------------------------------------------------------------------------
# Execute Pipeline
# ---------------------------------------------------------------------------


class TestExecute:

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_successful_execution(self, mock_db):
        result = execute(
            task="test_task",
            action=lambda: {"success": True, "data": "hello"},
            config=HarnessConfig(task_type="deterministic", audit=False),
        )
        assert result.success is True
        assert result.output == {"success": True, "data": "hello"}
        assert result.quality > 0
        assert result.model_used == "code_only"
        assert result.error is None

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_failed_execution(self, mock_db):
        def bad_action():
            raise ValueError("something went wrong")

        result = execute(
            task="failing_task",
            action=bad_action,
            config=HarnessConfig(task_type="simple", max_retries=0, audit=False),
        )
        assert result.success is False
        assert "something went wrong" in result.error

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_retry_on_low_quality(self, mock_db):
        call_count = [0]

        def improving_action():
            call_count[0] += 1
            if call_count[0] == 1:
                return []  # empty list = low quality (0.3)
            return [1, 2, 3]  # non-empty = higher quality (0.8)

        result = execute(
            task="retry_task",
            action=improving_action,
            config=HarnessConfig(
                task_type="simple",
                quality_threshold=0.5,
                max_retries=2,
                audit=False,
            ),
        )
        assert result.success is True
        assert result.retries >= 1

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_authority_failure_blocks_execution(self, mock_db):
        result = execute(
            task="send_email",
            action=lambda: "should not run",
            config=HarnessConfig(authority="read_only", audit=False),
        )
        assert result.success is False
        assert result.authority_check == "failed"

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_timing_recorded(self, mock_db):
        result = execute(
            task="timed_task",
            action=lambda: True,
            config=HarnessConfig(task_type="deterministic", audit=False),
        )
        assert result.duration_ms >= 0

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_run_id_assigned(self, mock_db):
        result = execute(
            task="id_task",
            action=lambda: True,
            config=HarnessConfig(task_type="deterministic", audit=False),
        )
        assert result.run_id != ""

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_default_config(self, mock_db):
        """execute() uses default config when none provided."""
        result = execute(
            task="default_task",
            action=lambda: {"status": "ok"},
        )
        assert result.task_type == "judgment"


# ---------------------------------------------------------------------------
# Convenience Wrappers
# ---------------------------------------------------------------------------


class TestConvenienceWrappers:

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_deterministic(self, mock_db):
        result = execute_deterministic("det_task", lambda: True)
        assert result.success is True
        assert result.model_used == "code_only"

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_simple(self, mock_db):
        result = execute_simple("simple_task", lambda: "output text here")
        assert result.success is True
        # Honest-measurement: model_used is None when no LLM was actually called
        # (lambda runs as code). local_router may also route to a local Ollama model.
        assert result.model_used in (None, "haiku", "ollama/gemma3:4b", "ollama/qwen2.5:7b-instruct", "ollama/qwen3:8b")

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_judgment(self, mock_db):
        # Honest-measurement: model_used reflects what was ACTUALLY called.
        # The lambda doesn't invoke an LLM so model_used is None (or whatever
        # local router selected). The convenience wrapper still classifies the
        # task type, which is what we care about.
        result = execute_judgment("judgment_task", lambda: {"status": "done"})
        assert result.success is True
        assert result.task_type == "judgment"
        assert result.model_used in (None, "sonnet")

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_complex(self, mock_db):
        # Honest-measurement: see test_execute_judgment.
        result = execute_complex("complex_task", lambda: {"success": True})
        assert result.success is True
        assert result.task_type == "complex"
        assert result.model_used in (None, "opus")


# ---------------------------------------------------------------------------
# HarnessConfig defaults
# ---------------------------------------------------------------------------


class TestHarnessConfig:

    def test_defaults(self):
        cfg = HarnessConfig()
        assert cfg.task_type == "judgment"
        assert cfg.authority == "standard"
        assert cfg.max_cost_cents == 1000
        assert cfg.timeout_seconds == 300
        assert cfg.quality_threshold == 0.5
        assert cfg.max_retries == 1
        assert cfg.require_approval is False
        assert cfg.audit is True
        assert cfg.actor == "system"
        assert cfg.tags == []

    def test_custom_config(self):
        cfg = HarnessConfig(
            task_type="complex",
            authority="admin",
            max_cost_cents=5000,
            actor="test_agent",
            tags=["deploy", "critical"],
        )
        assert cfg.task_type == "complex"
        assert cfg.authority == "admin"
        assert cfg.max_cost_cents == 5000
        assert cfg.actor == "test_agent"
        assert cfg.tags == ["deploy", "critical"]


class TestHarnessResult:

    def test_defaults(self):
        # Honest-measurement rebuild: HarnessResult refuses to fake quality
        # or cost. Defaults are None until a real measurement lands. Was
        # quality=0.0 / cost_cents=0 in v1.2.x.
        r = HarnessResult()
        assert r.success is False
        assert r.output is None
        assert r.error is None
        assert r.quality is None
        assert r.cost_cents is None
        assert r.retries == 0
        assert r.approval_status == "not_required"


# ---------------------------------------------------------------------------
# Risk Classification & Approval Gate
# ---------------------------------------------------------------------------


class TestRiskClassification:

    def test_low_risk_for_safe_actions(self):
        """Standard read/write tasks are low risk."""
        config = HarnessConfig(authority="standard")
        assert classify_risk("read_file", config) == RiskLevel.LOW
        assert classify_risk("write_file", config) == RiskLevel.LOW
        assert classify_risk("query_db", config) == RiskLevel.LOW

    def test_high_risk_for_dangerous_actions(self):
        """Spend/delete/publish actions are always high risk."""
        config = HarnessConfig(authority="elevated")
        assert classify_risk("spend_money", config) == RiskLevel.HIGH
        assert classify_risk("delete_file", config) == RiskLevel.HIGH
        assert classify_risk("publish", config) == RiskLevel.HIGH
        assert classify_risk("send_email", config) == RiskLevel.HIGH

    def test_medium_risk_for_git_push(self):
        """git_push is medium risk — auto-approved but flagged."""
        config = HarnessConfig(authority="standard")
        assert classify_risk("git_push", config) == RiskLevel.MEDIUM

    def test_require_approval_forces_high_risk(self):
        """Setting require_approval=True always classifies as high risk."""
        config = HarnessConfig(require_approval=True)
        assert classify_risk("read_file", config) == RiskLevel.HIGH

    def test_elevated_unknown_action_is_medium(self):
        """Elevated authority doing an unknown action = medium risk."""
        config = HarnessConfig(authority="elevated")
        assert classify_risk("custom_action", config) == RiskLevel.MEDIUM

    def test_standard_unknown_action_is_low(self):
        """Standard authority doing an unknown action = low risk."""
        config = HarnessConfig(authority="standard")
        assert classify_risk("custom_action", config) == RiskLevel.LOW


class TestApprovalGate:

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_low_risk_auto_approves_honestly(self, mock_db):
        """Low-risk task returns auto_approved_low_risk — no fake approval."""
        config = HarnessConfig(authority="standard")
        status = _check_approval("read_file", config)
        assert status == "auto_approved_low_risk"

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_medium_risk_auto_approves_with_flag(self, mock_db):
        """Medium-risk task returns auto_approved_medium_risk."""
        config = HarnessConfig(authority="standard")
        status = _check_approval("git_push", config)
        assert status == "auto_approved_medium_risk"

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_high_risk_blocks_without_approval(self, mock_db):
        """High-risk task with no DB approval creates pending and blocks."""
        config = HarnessConfig(authority="elevated")
        status = _check_approval("spend_money", config)
        assert status == "pending_approval"

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_require_approval_blocks_without_db_entry(self, mock_db):
        """require_approval=True blocks execution when no DB approval exists."""
        config = HarnessConfig(require_approval=True)
        status = _check_approval("any_task", config)
        assert status == "pending_approval"

    @patch("aibrain.core.harness._query_approval_db", return_value="approved")
    def test_explicit_db_approval_passes(self, mock_query):
        """Explicit DB approval overrides risk classification."""
        config = HarnessConfig(require_approval=True)
        status = _check_approval("spend_money", config)
        assert status == "approved"

    @patch("aibrain.core.harness._query_approval_db", return_value="denied")
    def test_explicit_db_denial_blocks(self, mock_query):
        """Explicit DB denial blocks even low-risk tasks."""
        config = HarnessConfig(authority="standard")
        status = _check_approval("read_file", config)
        assert status == "denied"

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_blocks_high_risk_task(self, mock_db):
        """Full pipeline: high-risk task is blocked, action never runs."""
        ran = [False]
        def action():
            ran[0] = True
            return "should not run"

        # Use admin authority so authority check passes, but spend_money
        # is still HIGH risk in the approval gate
        result = execute(
            task="spend_money",
            action=action,
            config=HarnessConfig(authority="admin", audit=False),
        )
        assert result.success is False
        assert result.approval_status == "pending_approval"
        assert "approval" in result.error.lower()
        assert ran[0] is False  # action must NOT have executed

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_records_honest_approval_status(self, mock_db):
        """Full pipeline: low-risk task records honest approval status."""
        result = execute(
            task="read_file",
            action=lambda: {"success": True},
            config=HarnessConfig(task_type="deterministic", authority="standard", audit=False),
        )
        assert result.success is True
        assert result.approval_status == "auto_approved_low_risk"
