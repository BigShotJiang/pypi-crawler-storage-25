"""Tests for pre-visibility checklist."""

import os
import textwrap
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from aibrain.core.pre_visibility import (
    run_checklist,
    _check_no_internal_names,
    _check_gitignore_coverage,
    _check_no_todo_fixme,
    _check_file_exists,
    _check_no_creds_in_history,
    cli_main,
)


@pytest.fixture
def fake_repo(tmp_path):
    """Create a minimal fake repo structure."""
    (tmp_path / ".git").mkdir()
    (tmp_path / "README.md").write_text("# My Project\nA cool tool.\n")
    (tmp_path / "SECURITY.md").write_text("Report bugs to security@example.com\n")
    (tmp_path / "LICENSE").write_text("MIT License\n")
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "myproject"\n')
    (tmp_path / ".gitignore").write_text(".env\n*.key\ncredentials\n")
    return tmp_path


def test_clean_repo_passes_all_file_checks(fake_repo):
    """A clean repo with all required files should pass file-based checks."""
    assert _check_file_exists(fake_repo, "SECURITY.md")["passed"] is True
    assert _check_file_exists(fake_repo, "LICENSE")["passed"] is True
    assert _check_no_internal_names(fake_repo)["passed"] is True
    assert _check_gitignore_coverage(fake_repo)["passed"] is True
    assert _check_no_todo_fixme(fake_repo)["passed"] is True


def test_internal_names_detected(fake_repo):
    """Internal tool names in public files should trigger failure."""
    (fake_repo / "README.md").write_text("Built on Wintermute scanning engine.\n")
    result = _check_no_internal_names(fake_repo)
    assert result["passed"] is False
    assert "wintermute" in result["detail"].lower()


def test_missing_gitignore_patterns(fake_repo):
    """Missing .gitignore patterns should trigger failure."""
    (fake_repo / ".gitignore").write_text("node_modules/\n")
    result = _check_gitignore_coverage(fake_repo)
    assert result["passed"] is False
    assert ".env" in result["detail"]


def test_todo_fixme_detected(fake_repo):
    """TODO/FIXME markers in public files should trigger failure."""
    (fake_repo / "README.md").write_text("# Project\nTODO: finish docs\n")
    result = _check_no_todo_fixme(fake_repo)
    assert result["passed"] is False
    assert "README.md:2" in result["detail"]


def test_missing_security_md(fake_repo):
    """Missing SECURITY.md should fail that check."""
    os.remove(fake_repo / "SECURITY.md")
    result = _check_file_exists(fake_repo, "SECURITY.md")
    assert result["passed"] is False
    assert "MISSING" in result["detail"]


def test_cred_check_clean_history(fake_repo):
    """Credential check should pass on a repo with no cred patterns."""
    mock_result = MagicMock()
    mock_result.stdout = "diff --git a/foo.py\n+hello = 'world'\n"
    with patch("subprocess.run", return_value=mock_result):
        result = _check_no_creds_in_history(fake_repo)
    assert result["passed"] is True


def test_cred_check_finds_api_key(fake_repo):
    """Credential check should catch API key patterns in git history."""
    mock_result = MagicMock()
    mock_result.stdout = "+API_KEY = 'ghp_1234567890abcdefghijABCDEFGHIJ123456'\n"
    with patch("subprocess.run", return_value=mock_result):
        result = _check_no_creds_in_history(fake_repo)
    assert result["passed"] is False


def test_run_checklist_overall_structure(fake_repo):
    """run_checklist returns correct structure with overall PASS/FAIL."""
    mock_run = MagicMock()
    # Mock git log (cred check) — clean
    mock_git = MagicMock()
    mock_git.stdout = "clean diff"
    # Mock pytest — all pass
    mock_pytest = MagicMock()
    mock_pytest.returncode = 0
    mock_pytest.stdout = "52 passed\n"

    def side_effect(cmd, **kwargs):
        if "pytest" in cmd:
            return mock_pytest
        return mock_git

    with patch("subprocess.run", side_effect=side_effect):
        result = run_checklist(fake_repo)

    assert "overall" in result
    assert "checks" in result
    assert isinstance(result["checks"], list)
    assert len(result["checks"]) == 7
    assert result["passed"] + result["failed"] == 7


def test_cli_main_returns_exit_code(fake_repo):
    """CLI returns 0 on PASS, 1 on FAIL."""
    with patch("aibrain.core.pre_visibility.run_checklist") as mock:
        mock.return_value = {"overall": "PASS", "checks": [], "passed": 7, "failed": 0}
        assert cli_main(["--path", str(fake_repo)]) == 0

        mock.return_value = {"overall": "FAIL", "checks": [], "passed": 5, "failed": 2}
        assert cli_main(["--path", str(fake_repo)]) == 1
