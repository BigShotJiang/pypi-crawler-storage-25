"""
Tests for the honest quality evaluation system.

Covers: evaluate_task_quality(), automated checks, self_score vs eval_score,
        unverified flagging, divergence detection, complete_task() integration.
"""

import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.harness import (
    HarnessConfig,
    HarnessResult,
    evaluate_task_quality,
    _check_output_not_error,
    _check_output_substantive,
    QUALITY_CHECKS,
    execute,
)


# ---------------------------------------------------------------------------
# Individual Automated Checks
# ---------------------------------------------------------------------------


class TestOutputNotErrorCheck:
    """_check_output_not_error should detect error signals in output."""

    def test_clean_output_passes(self):
        passed, detail = _check_output_not_error({"success": True, "data": [1, 2]})
        assert passed is True

    def test_none_output_fails(self):
        passed, detail = _check_output_not_error(None)
        assert passed is False

    def test_traceback_in_string_fails(self):
        # Honest-rubric rule (commit 4179f61): _check_output_not_error no
        # longer pattern-matches str reprs — that produced false positives
        # on substantive outputs that discuss error scenarios. Non-dict
        # strings now pass by default because a raw string carries no
        # structured error signal.
        passed, detail = _check_output_not_error("Traceback (most recent call last):\n  File...")
        assert passed is True
        assert "no structured error indicator" in detail

    def test_error_in_dict_value_fails(self):
        # Honest-rubric rule (commit 4179f61): only STRUCTURED error keys
        # count. A dict whose 'result' value happens to contain the text
        # "TypeError" does NOT have an explicit `error` / `success=False`
        # signal, so it's treated as passing. Tasks must self-report via
        # the structured fields, not leak error words into the body.
        passed, detail = _check_output_not_error({"result": "TypeError: unsupported operand"})
        assert passed is True

    def test_clean_string_passes(self):
        passed, detail = _check_output_not_error("Task completed, 5 files updated")
        assert passed is True


class TestOutputSubstantiveCheck:
    """_check_output_substantive should detect trivial/empty outputs."""

    def test_success_dict_is_substantive(self):
        passed, _ = _check_output_substantive({"success": True})
        assert passed is True

    def test_error_dict_not_substantive(self):
        passed, _ = _check_output_substantive({"error": "broken"})
        assert passed is False

    def test_empty_list_not_substantive(self):
        passed, _ = _check_output_substantive([])
        assert passed is False

    def test_non_empty_list_substantive(self):
        passed, _ = _check_output_substantive([1, 2, 3])
        assert passed is True

    def test_none_not_substantive(self):
        passed, _ = _check_output_substantive(None)
        assert passed is False

    def test_bool_true_substantive(self):
        passed, _ = _check_output_substantive(True)
        assert passed is True

    def test_bool_false_not_substantive(self):
        passed, _ = _check_output_substantive(False)
        assert passed is False

    def test_short_string_not_substantive(self):
        passed, _ = _check_output_substantive("ok")
        assert passed is False

    def test_reasonable_string_substantive(self):
        passed, _ = _check_output_substantive("Created 3 files and committed changes")
        assert passed is True


# ---------------------------------------------------------------------------
# evaluate_task_quality — Core Evaluation
# ---------------------------------------------------------------------------


class TestEvaluateTaskQuality:
    """evaluate_task_quality() should produce honest, verified scores."""

    def test_successful_output_scores_high(self):
        result = evaluate_task_quality(
            output={"success": True, "data": "all good"},
            task_name="test_task",
        )
        assert result["eval_score"] >= 0.7
        assert result["verified"] is True
        assert "output_no_error" in result["checks"]
        assert "output_substantive" in result["checks"]

    def test_error_output_scores_low(self):
        result = evaluate_task_quality(
            output={"error": "Traceback: ValueError"},
            task_name="test_task",
        )
        assert result["eval_score"] < 0.5
        assert result["verified"] is True

    def test_none_output_unverified(self):
        result = evaluate_task_quality(
            output=None,
            task_name="test_task",
        )
        # None fails both checks, shape score is 0.0 for non-deterministic
        assert result["eval_score"] < 0.3

    def test_self_score_recorded_but_not_used(self):
        """Self-score should be stored but NOT override eval_score."""
        result = evaluate_task_quality(
            output={"error": "totally broken"},
            task_name="test_task",
            self_score=0.95,
        )
        # Eval should be low despite high self-score
        assert result["eval_score"] < 0.5
        assert result["self_score"] == 0.95

    def test_divergence_detected(self):
        """When self_score and eval_score diverge >0.3, flag it."""
        result = evaluate_task_quality(
            output={"error": "broken"},
            task_name="test_task",
            self_score=0.9,
        )
        assert result["divergence"] is not None
        assert result["divergence"] > 0.3
        assert result["flagged"] is True

    def test_no_divergence_when_aligned(self):
        """When self_score is close to eval_score, no flag."""
        result = evaluate_task_quality(
            output={"success": True, "data": "complete"},
            task_name="test_task",
            self_score=0.85,
        )
        # Both should be high, divergence small
        assert result["flagged"] is False

    def test_no_self_score_means_no_divergence(self):
        result = evaluate_task_quality(
            output={"success": True},
            task_name="test_task",
            self_score=None,
        )
        assert result["divergence"] is None
        assert result["flagged"] is False

    def test_checks_structure(self):
        """Each check result should have passed, detail, weight."""
        result = evaluate_task_quality(
            output={"status": "ok"},
            task_name="test_task",
        )
        for name, check in result["checks"].items():
            assert "passed" in check
            assert "detail" in check
            assert "weight" in check
            assert isinstance(check["passed"], bool)
            assert isinstance(check["weight"], float)

    def test_score_clamped_0_to_1(self):
        result = evaluate_task_quality(
            output="error traceback exception failed broken",
            task_name="test_task",
        )
        assert 0.0 <= result["eval_score"] <= 1.0

    def test_custom_checks_list(self):
        """Only specified checks should run."""
        result = evaluate_task_quality(
            output={"success": True},
            task_name="test_task",
            run_checks=["output_no_error"],
        )
        assert "output_no_error" in result["checks"]
        assert "output_substantive" not in result["checks"]

    def test_git_check_skipped_without_repo(self):
        """git_committed check should be skipped if no repo_path."""
        result = evaluate_task_quality(
            output={"success": True},
            task_name="test_task",
            run_checks=["output_no_error", "git_committed"],
            repo_path=None,
        )
        assert "git_committed" not in result["checks"]

    def test_detail_contains_check_results(self):
        result = evaluate_task_quality(
            output={"success": True},
            task_name="test_task",
        )
        assert "PASS" in result["detail"] or "FAIL" in result["detail"]


# ---------------------------------------------------------------------------
# Integration: execute() pipeline uses new evaluation
# ---------------------------------------------------------------------------


class TestExecuteQualityIntegration:

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_populates_quality_verified(self, mock_db):
        result = execute(
            task="test_task",
            action=lambda: {"success": True, "data": "all good"},
            config=HarnessConfig(task_type="deterministic", audit=False),
        )
        assert result.success is True
        assert result.quality_verified is True
        assert isinstance(result.quality_checks, dict)

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_execute_error_output_lower_quality(self, mock_db):
        result = execute(
            task="test_task",
            action=lambda: {"error": "Traceback: ValueError"},
            config=HarnessConfig(task_type="simple", audit=False),
        )
        assert result.success is True  # Action didn't raise
        assert result.quality < 0.5  # But quality should be low

    @patch("aibrain.core.harness._find_db", return_value=None)
    def test_failed_execution_has_no_checks(self, mock_db):
        def bad_action():
            raise RuntimeError("boom")

        result = execute(
            task="test_task",
            action=bad_action,
            config=HarnessConfig(task_type="simple", max_retries=0, audit=False),
        )
        assert result.success is False
        assert result.quality_verified is False


# ---------------------------------------------------------------------------
# QUALITY_CHECKS registry
# ---------------------------------------------------------------------------


class TestQualityChecksRegistry:

    def test_all_checks_have_correct_structure(self):
        """Every registered check should be (callable, float, bool)."""
        for name, (fn, weight, requires_ctx) in QUALITY_CHECKS.items():
            assert callable(fn), f"{name} fn not callable"
            assert 0.0 <= weight <= 1.0, f"{name} weight out of range"
            assert isinstance(requires_ctx, bool), f"{name} requires_ctx not bool"

    def test_weights_sum_to_1(self):
        total = sum(w for _, w, _ in QUALITY_CHECKS.values())
        assert abs(total - 1.0) < 0.01, f"Weights sum to {total}, expected ~1.0"
