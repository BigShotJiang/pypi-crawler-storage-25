"""
Tests for API response shapes — verifies key endpoints return expected structures.

Uses FastAPI TestClient for in-process testing (no live server needed).
Falls back to skip if backend dependencies are unavailable.
"""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def api_db():
    """Create a temp DB with enough schema for the API endpoints."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_apitest_")
    os.close(fd)

    db = sqlite3.connect(path)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'reference',
            content TEXT,
            tags TEXT,
            importance REAL DEFAULT 0.5,
            source TEXT DEFAULT 'test',
            active INTEGER DEFAULT 1,
            embedding BLOB,
            created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, content, tags, content=memories, content_rowid=id
        );
        CREATE TABLE IF NOT EXISTS workflows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            category TEXT,
            description TEXT,
            schedule TEXT,
            enabled INTEGER DEFAULT 1,
            script_path TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent TEXT, action TEXT, detail TEXT, status TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS companies (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            mission TEXT,
            status TEXT DEFAULT 'active',
            budget_monthly_cents INTEGER DEFAULT 0,
            spent_monthly_cents INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS company_agents (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            name TEXT NOT NULL,
            role TEXT DEFAULT 'general',
            title TEXT,
            status TEXT DEFAULT 'idle',
            reports_to TEXT,
            model TEXT DEFAULT 'auto',
            task_type TEXT DEFAULT 'judgment',
            authority TEXT DEFAULT 'standard',
            budget_monthly_cents INTEGER DEFAULT 0,
            spent_monthly_cents INTEGER DEFAULT 0,
            heartbeat_interval_seconds INTEGER DEFAULT 14400,
            last_heartbeat_at TIMESTAMP,
            instructions TEXT,
            capabilities TEXT,
            permissions TEXT,
            metadata TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS company_issues (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            parent_id TEXT,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'backlog',
            priority TEXT DEFAULT 'medium',
            assignee_agent_id TEXT,
            project TEXT,
            issue_number INTEGER,
            origin TEXT DEFAULT 'manual',
            request_depth INTEGER DEFAULT 0,
            quality_score REAL,
            cost_cents INTEGER DEFAULT 0,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS company_approvals (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            type TEXT NOT NULL,
            requested_by_agent_id TEXT,
            status TEXT DEFAULT 'pending',
            payload TEXT,
            decision_note TEXT,
            decided_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS company_heartbeat_runs (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            agent_id TEXT NOT NULL,
            status TEXT DEFAULT 'running',
            trigger_source TEXT,
            started_at TIMESTAMP,
            finished_at TIMESTAMP,
            duration_ms INTEGER,
            quality_score REAL,
            cost_cents INTEGER DEFAULT 0,
            model_used TEXT,
            error TEXT,
            summary TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS scheduled_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            schedule TEXT,
            workflow_name TEXT,
            enabled INTEGER DEFAULT 1,
            last_run TIMESTAMP,
            next_run TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Seed data
        INSERT INTO memories (name, type, content, tags) VALUES
            ('test_mem', 'reference', 'Test content', 'test'),
            ('user_pref', 'user', 'User preference', 'user');
        INSERT INTO workflows (name, category, description, enabled)
            VALUES ('heartbeat', 'system', 'Agent heartbeat', 1);
        INSERT INTO companies (id, name, mission) VALUES ('co1', 'TestCo', 'Testing');
    """)
    db.commit()
    db.close()

    yield path

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


@pytest.fixture(scope="module")
def test_client(api_db):
    """Create a FastAPI TestClient with the main app, pointed at temp DB."""
    try:
        from fastapi.testclient import TestClient
    except ImportError:
        pytest.skip("fastapi not installed")

    # Patch environment so backend modules use our temp DB
    db_dir = str(Path(api_db).parent)
    env_patches = {
        "AIBRAIN_ROOT": db_dir,
        "AIBRAIN_DB": api_db,
    }

    with patch.dict(os.environ, env_patches):
        # Patch aibrain_db to use our temp DB
        try:
            import aibrain_db
            original_path = aibrain_db.DB_PATH
            original_conn = aibrain_db._conn
            aibrain_db.DB_PATH = Path(api_db)
            aibrain_db._conn = None
        except Exception:
            pass

        # Patch companies module
        def _patched_get_db():
            db = sqlite3.connect(api_db)
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA journal_mode=WAL")
            return db

        with patch("aibrain.core.companies._get_db", _patched_get_db), \
             patch("aibrain.core.heartbeat._get_db", _patched_get_db):
            try:
                from fastapi import FastAPI

                # Build a minimal app with the routers we want to test
                app = FastAPI()

                try:
                    from aibrain_api import router as aibrain_router
                    app.include_router(aibrain_router)
                except Exception:
                    pass

                try:
                    from companies_api import router as companies_router
                    app.include_router(companies_router)
                except Exception:
                    pass

                client = TestClient(app)
                yield client

            except Exception as e:
                pytest.skip(f"Could not create test client: {e}")

        # Restore
        try:
            aibrain_db._conn = original_conn
            aibrain_db.DB_PATH = original_path
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestMemorySummaryEndpoint:

    def test_returns_total_and_by_type(self, test_client):
        resp = test_client.get("/api/agent/memories/summary")
        if resp.status_code == 404:
            pytest.skip("memories/summary endpoint not mounted")
        assert resp.status_code == 200
        data = resp.json()
        assert "total" in data
        assert isinstance(data["total"], int)
        assert "by_type" in data
        assert isinstance(data["by_type"], dict)

    def test_summary_includes_recent(self, test_client):
        resp = test_client.get("/api/agent/memories/summary")
        if resp.status_code == 404:
            pytest.skip("memories/summary endpoint not mounted")
        data = resp.json()
        assert "recent" in data
        assert isinstance(data["recent"], list)


class TestWorkflowsEndpoint:

    def test_returns_workflows_list(self, test_client):
        resp = test_client.get("/api/agent/workflows")
        if resp.status_code == 404:
            pytest.skip("workflows endpoint not mounted")
        assert resp.status_code == 200
        data = resp.json()
        assert "workflows" in data
        assert isinstance(data["workflows"], list)
        assert "count" in data

    def test_count_matches_list(self, test_client):
        resp = test_client.get("/api/agent/workflows")
        if resp.status_code == 404:
            pytest.skip("workflows endpoint not mounted")
        data = resp.json()
        assert data["count"] == len(data["workflows"])


class TestStatusEndpoint:

    def test_returns_agents_list(self, test_client):
        resp = test_client.get("/api/agent/status")
        if resp.status_code == 404:
            pytest.skip("status endpoint not mounted")
        assert resp.status_code == 200
        data = resp.json()
        assert "agents" in data
        assert isinstance(data["agents"], list)
        assert len(data["agents"]) >= 1

    def test_local_agent_has_required_fields(self, test_client):
        resp = test_client.get("/api/agent/status")
        if resp.status_code == 404:
            pytest.skip("status endpoint not mounted")
        data = resp.json()
        agent = data["agents"][0]
        assert "name" in agent
        assert "status" in agent
        assert "platform" in agent


class TestCompaniesEndpoint:

    def test_returns_list(self, test_client):
        resp = test_client.get("/api/companies/")
        if resp.status_code == 404:
            pytest.skip("companies endpoint not mounted")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)

    def test_create_company(self, test_client):
        resp = test_client.post("/api/companies/", json={"name": "API Test Co", "mission": "Test"})
        if resp.status_code == 404:
            pytest.skip("companies endpoint not mounted")
        assert resp.status_code == 200
        data = resp.json()
        assert "id" in data
        assert data["name"] == "API Test Co"

    def test_get_company_detail(self, test_client):
        # Use the seeded company
        resp = test_client.get("/api/companies/co1")
        if resp.status_code == 404:
            pytest.skip("companies endpoint not mounted")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "TestCo"
        assert "agent_count" in data
