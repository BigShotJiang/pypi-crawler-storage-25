"""
Tests for Twitter/X API v2 posting in social_poster.py.

Uses mocks so no real API calls are made.
"""

import hmac as hmac_mod
import json
import os
import sys
import time
from unittest.mock import patch, MagicMock, ANY
from pathlib import Path

import pytest

# Add the marketing dir to path so we can import social_poster
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "marketing" / "viral-launch"))

from social_poster import (
    _x_get_credentials,
    _x_oauth_signature,
    _x_oauth_header,
    _x_rate_limit_wait,
    post_x_api,
    post_x_thread_api,
)


# ---------------------------------------------------------------------------
# Credential tests
# ---------------------------------------------------------------------------

class TestXCredentials:

    def test_missing_credentials_raises(self):
        """Missing env vars raise RuntimeError."""
        with patch.dict(os.environ, {}, clear=True):
            # Remove any X_ vars
            for key in ["X_API_KEY", "X_API_SECRET", "X_ACCESS_TOKEN", "X_ACCESS_SECRET"]:
                os.environ.pop(key, None)
            with pytest.raises(RuntimeError, match="Missing X/Twitter credentials"):
                _x_get_credentials()

    def test_valid_credentials_returned(self):
        """All four env vars present returns tuple."""
        env = {
            "X_API_KEY": "key123",
            "X_API_SECRET": "secret456",
            "X_ACCESS_TOKEN": "token789",
            "X_ACCESS_SECRET": "tokensecret000",
        }
        with patch.dict(os.environ, env, clear=False):
            result = _x_get_credentials()
        assert result == ("key123", "secret456", "token789", "tokensecret000")


# ---------------------------------------------------------------------------
# OAuth signature tests
# ---------------------------------------------------------------------------

class TestOAuthSignature:

    def test_signature_is_base64(self):
        """Signature output is valid base64."""
        sig = _x_oauth_signature(
            "POST",
            "https://api.twitter.com/2/tweets",
            {"oauth_consumer_key": "key", "oauth_nonce": "abc123",
             "oauth_signature_method": "HMAC-SHA1", "oauth_timestamp": "1234567890",
             "oauth_token": "token", "oauth_version": "1.0"},
            "consumer_secret",
            "token_secret",
        )
        import base64
        # Should not raise
        decoded = base64.b64decode(sig)
        assert len(decoded) == 20  # SHA1 is 20 bytes

    def test_signature_deterministic(self):
        """Same inputs produce same signature."""
        params = {"a": "1", "b": "2"}
        sig1 = _x_oauth_signature("POST", "https://example.com", params, "sec", "tok")
        sig2 = _x_oauth_signature("POST", "https://example.com", params, "sec", "tok")
        assert hmac_mod.compare_digest(sig1, sig2)  # noqa:PLAIN_SECRET_COMPARISON

    def test_different_secrets_different_sigs(self):
        """Different secrets produce different signatures."""
        params = {"a": "1"}
        sig1 = _x_oauth_signature("POST", "https://example.com", params, "sec1", "tok")
        sig2 = _x_oauth_signature("POST", "https://example.com", params, "sec2", "tok")
        assert sig1 != sig2


# ---------------------------------------------------------------------------
# Rate limiting tests
# ---------------------------------------------------------------------------

class TestRateLimit:

    def test_rate_limit_wait_respects_interval(self):
        """Rate limiter sleeps when called too quickly."""
        import social_poster
        social_poster._x_last_post_ts = time.time()  # Just posted
        with patch("social_poster.time") as mock_time:
            mock_time.time.return_value = social_poster._x_last_post_ts + 1  # 1s later
            mock_time.sleep = MagicMock()
            _x_rate_limit_wait()
            # Should sleep ~4 seconds (5 - 1)
            mock_time.sleep.assert_called_once()
            sleep_dur = mock_time.sleep.call_args[0][0]
            assert 3.5 < sleep_dur < 4.5


# ---------------------------------------------------------------------------
# post_x_api tests
# ---------------------------------------------------------------------------

class TestPostXApi:

    @pytest.fixture(autouse=True)
    def _set_env(self):
        env = {
            "X_API_KEY": "testkey",
            "X_API_SECRET": "testsecret",
            "X_ACCESS_TOKEN": "testtoken",
            "X_ACCESS_SECRET": "testtokensecret",
        }
        with patch.dict(os.environ, env, clear=False):
            yield

    def test_post_single_tweet(self):
        """post_x_api sends correct payload and returns result."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "data": {"id": "12345", "text": "Hello world"}
        }).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_response), \
             patch("social_poster._x_rate_limit_wait"):
            result = post_x_api("Hello world")

        assert result["data"]["id"] == "12345"

    def test_post_with_reply_to(self):
        """post_x_api includes reply field when reply_to is set."""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "data": {"id": "67890", "text": "Reply text"}
        }).encode()
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        captured_req = {}

        def capture_urlopen(req, **kwargs):
            captured_req["body"] = json.loads(req.data.decode())
            return mock_response

        with patch("urllib.request.urlopen", side_effect=capture_urlopen), \
             patch("social_poster._x_rate_limit_wait"):
            post_x_api("Reply text", reply_to="12345")

        assert captured_req["body"]["reply"]["in_reply_to_tweet_id"] == "12345"


# ---------------------------------------------------------------------------
# Thread posting tests
# ---------------------------------------------------------------------------

class TestPostXThreadApi:

    @pytest.fixture(autouse=True)
    def _set_env(self):
        env = {
            "X_API_KEY": "testkey",
            "X_API_SECRET": "testsecret",
            "X_ACCESS_TOKEN": "testtoken",
            "X_ACCESS_SECRET": "testtokensecret",
        }
        with patch.dict(os.environ, env, clear=False):
            yield

    def test_empty_thread_returns_empty(self):
        """Empty tweet list returns empty results."""
        assert post_x_thread_api([]) == []

    def test_thread_chains_replies(self):
        """Thread posts chain reply_to IDs correctly."""
        call_count = {"n": 0}
        tweet_ids = ["100", "200", "300"]

        def mock_post(text, reply_to=None):
            idx = call_count["n"]
            call_count["n"] += 1
            return {"data": {"id": tweet_ids[idx], "text": text}}

        with patch("social_poster.post_x_api", side_effect=mock_post):
            results = post_x_thread_api(["First", "Second", "Third"])

        assert len(results) == 3
        # Verify chain: first has no reply_to, second replies to first, etc.
        # (mock_post was called with correct reply_to via post_x_api)
        assert results[0]["data"]["id"] == "100"
        assert results[2]["data"]["id"] == "300"
