"""Tests for aibrain.cli.approvals — interactive approval queue."""
from __future__ import annotations

import sqlite3
import textwrap
from pathlib import Path

import pytest

from aibrain.cli.approvals import (
    PAGE_SIZE,
    _set_db_path,
    _update_status,
    group_by_category,
    load_pending,
    render_detail,
    render_menu,
    interactive_menu,
)


@pytest.fixture()
def approval_db(tmp_path: Path):
    """Create a temporary DB with the approvals table and sample data."""
    db = tmp_path / "aibrain.db"
    conn = sqlite3.connect(str(db))
    conn.execute(
        """CREATE TABLE approvals (
            id INTEGER PRIMARY KEY,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            category TEXT DEFAULT '',
            title TEXT DEFAULT '',
            detail TEXT DEFAULT '',
            payload TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending',
            decided_at TEXT,
            decision_note TEXT DEFAULT ''
        )"""
    )
    # Insert test rows across categories
    rows = []
    for i in range(1, 25):
        cat = "file_management" if i <= 18 else "email"
        rows.append((f"2026-04-0{min(i,9)}", cat, f"Item {i}", f"Detail {i}", "{}"))
    conn.executemany(
        "INSERT INTO approvals (created, category, title, detail, payload) VALUES (?,?,?,?,?)",
        rows,
    )
    conn.commit()
    conn.close()
    _set_db_path(db)
    yield db
    _set_db_path(None)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# 1. Load pending
# ---------------------------------------------------------------------------

def test_load_pending(approval_db):
    items = load_pending()
    assert len(items) == 24
    assert all(it["status"] == "pending" for it in items)


# ---------------------------------------------------------------------------
# 2. Category grouping
# ---------------------------------------------------------------------------

def test_group_by_category(approval_db):
    items = load_pending()
    groups = group_by_category(items)
    cats = [g[0] for g in groups]
    assert "email" in cats
    assert "file_management" in cats
    # file_management has 18 items
    fm_group = [g for g in groups if g[0] == "file_management"][0]
    assert len(fm_group[1]) == 18


# ---------------------------------------------------------------------------
# 3. Toggle (checked set)
# ---------------------------------------------------------------------------

def test_toggle_checked():
    """Simulate toggling items in/out of the checked set."""
    checked: set[int] = set()
    checked.add(1)
    assert 1 in checked
    checked.discard(1)
    assert 1 not in checked


# ---------------------------------------------------------------------------
# 4. Approve batch
# ---------------------------------------------------------------------------

def test_approve_batch(approval_db):
    items = load_pending()
    ids = [items[0]["id"], items[1]["id"]]
    count = _update_status(ids, "approved")
    assert count == 2
    remaining = load_pending()
    assert len(remaining) == 22
    # Verify they are marked approved in DB
    conn = sqlite3.connect(str(approval_db))
    row = conn.execute("SELECT status, decided_at FROM approvals WHERE id=?", (ids[0],)).fetchone()
    assert row[0] == "approved"
    assert row[1] is not None
    conn.close()


# ---------------------------------------------------------------------------
# 5. Reject batch
# ---------------------------------------------------------------------------

def test_reject_batch(approval_db):
    items = load_pending()
    ids = [items[2]["id"]]
    count = _update_status(ids, "rejected")
    assert count == 1
    conn = sqlite3.connect(str(approval_db))
    row = conn.execute("SELECT status FROM approvals WHERE id=?", (ids[0],)).fetchone()
    assert row[0] == "rejected"
    conn.close()


# ---------------------------------------------------------------------------
# 6. Select all in category
# ---------------------------------------------------------------------------

def test_select_all_category(approval_db):
    items = load_pending()
    groups = group_by_category(items)
    cat, cat_items = groups[0]  # first category
    checked: set[int] = set()
    all_ids = {it["id"] for it in cat_items}
    # Select all
    checked |= all_ids
    assert all_ids.issubset(checked)
    # Toggle = deselect all
    checked -= all_ids
    assert len(checked) == 0


# ---------------------------------------------------------------------------
# 7. Pagination
# ---------------------------------------------------------------------------

def test_pagination(approval_db):
    items = load_pending()
    groups = group_by_category(items)
    fm = [g for g in groups if g[0] == "file_management"][0]
    cat_items = fm[1]
    assert len(cat_items) == 18
    # Page 0: items 0-14, Page 1: items 15-17
    total_pages = (len(cat_items) + PAGE_SIZE - 1) // PAGE_SIZE
    assert total_pages == 2


# ---------------------------------------------------------------------------
# 8. Detail view rendering
# ---------------------------------------------------------------------------

def test_render_detail(approval_db):
    items = load_pending()
    text = render_detail(items[0])
    assert "Detail:" in text
    assert items[0]["title"] in text
    assert "Payload:" in text


# ---------------------------------------------------------------------------
# 9. Non-tty fallback
# ---------------------------------------------------------------------------

def test_non_tty_fallback(approval_db, capsys, monkeypatch):
    """When stdout is not a tty, print pipe-friendly lines."""
    monkeypatch.setattr("sys.stdout.isatty", lambda: False)
    interactive_menu()
    out = capsys.readouterr().out
    lines = [l for l in out.strip().splitlines() if l]
    assert len(lines) == 24
    # Format: id|category|title|status
    first = lines[0]
    parts = first.split("|")
    assert len(parts) == 4
    assert parts[3] == "pending"


# ---------------------------------------------------------------------------
# 10. Empty state
# ---------------------------------------------------------------------------

def test_empty_state(tmp_path: Path, capsys, monkeypatch):
    """No pending items -> non-tty prints nothing, tty prints message."""
    db = tmp_path / "aibrain.db"
    conn = sqlite3.connect(str(db))
    conn.execute(
        """CREATE TABLE approvals (
            id INTEGER PRIMARY KEY,
            created TEXT, updated TEXT, category TEXT, title TEXT,
            detail TEXT, payload TEXT, status TEXT DEFAULT 'pending',
            decided_at TEXT, decision_note TEXT DEFAULT ''
        )"""
    )
    conn.commit()
    conn.close()
    _set_db_path(db)
    try:
        # Non-tty: no items => no output lines
        monkeypatch.setattr("sys.stdout.isatty", lambda: False)
        interactive_menu()
        out = capsys.readouterr().out
        assert out.strip() == ""

        # Verify load_pending returns empty
        assert load_pending() == []

        # Verify render_menu handles empty groups
        text = render_menu([], 0, 0, 0, set(), 0)
        assert "No pending approvals" in text
    finally:
        _set_db_path(None)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# 11. Render menu output
# ---------------------------------------------------------------------------

def test_render_menu_output(approval_db):
    items = load_pending()
    groups = group_by_category(items)
    checked: set[int] = {items[0]["id"]}
    text = render_menu(groups, 0, 0, 0, checked, len(items))
    assert "Pending Approvals" in text
    assert "[x]" in text  # checked item
    assert "[ ]" in text  # unchecked items
    assert "[G] next category" in text


# ---------------------------------------------------------------------------
# 12. Update with empty list is no-op
# ---------------------------------------------------------------------------

def test_update_empty_list(approval_db):
    count = _update_status([], "approved")
    assert count == 0
    assert len(load_pending()) == 24
