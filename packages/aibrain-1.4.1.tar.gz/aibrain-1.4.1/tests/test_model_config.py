"""
Tests for aibrain.tools.model.config — model routing configuration.

Covers: load/save, defaults, TOML parsing, interactive menu state,
        non-tty fallback, scale clamping, routing cycle, workflow_runner integration.
"""
import os
import sys
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_cache():
    """Invalidate the module-level config cache before and after each test."""
    import aibrain.tools.model.config as mc
    mc._invalidate_cache()
    yield
    mc._invalidate_cache()


@pytest.fixture
def tmp_config(tmp_path, monkeypatch):
    """Redirect model.toml to a temp dir and return the path."""
    import aibrain.tools.model.config as mc
    cfg_path = tmp_path / 'model.toml'
    monkeypatch.setattr(mc, '_CONFIG_PATH', cfg_path)
    return cfg_path


# ---------------------------------------------------------------------------
# Test 1: Defaults when no config file exists
# ---------------------------------------------------------------------------

def test_defaults_no_config_file(tmp_config):
    """load_model_config returns correct defaults when model.toml is absent."""
    from aibrain.tools.model.config import load_model_config
    mcfg = load_model_config()
    assert mcfg['provider'] == 'auto'
    assert mcfg['embedding'] == 'all-MiniLM-L6-v2'
    assert mcfg['cost_per_run_max'] == 0.50
    assert mcfg['daily_budget'] == 5.00
    assert mcfg['routing'] == {
        'deterministic': 'code_only',
        'simple': 'haiku',
        'judgment': 'sonnet',
        'complex': 'opus',
    }


# ---------------------------------------------------------------------------
# Test 2: Load from existing TOML
# ---------------------------------------------------------------------------

def test_load_from_toml(tmp_config):
    """load_model_config reads values from model.toml correctly."""
    from aibrain.tools.model.config import load_model_config, _invalidate_cache
    tmp_config.write_text(
        '[model]\n'
        'provider = "ollama"\n'
        'embedding = "none"\n'
        'cost_per_run_max = 1.25\n'
        'daily_budget = 10.0\n'
        '\n'
        '[model.routing]\n'
        'deterministic = "code_only"\n'
        'simple = "local"\n'
        'judgment = "haiku"\n'
        'complex = "sonnet"\n',
        encoding='utf-8',
    )
    _invalidate_cache()
    mcfg = load_model_config()
    assert mcfg['provider'] == 'ollama'
    assert mcfg['embedding'] == 'none'
    assert mcfg['cost_per_run_max'] == 1.25
    assert mcfg['daily_budget'] == 10.0
    assert mcfg['routing']['simple'] == 'local'
    assert mcfg['routing']['complex'] == 'sonnet'


# ---------------------------------------------------------------------------
# Test 3: Env var overrides config file
# ---------------------------------------------------------------------------

def test_env_var_overrides(tmp_config, monkeypatch):
    """Env vars take precedence over model.toml values."""
    from aibrain.tools.model.config import load_model_config, _invalidate_cache
    tmp_config.write_text(
        '[model]\nprovider = "ollama"\nembedding = "none"\n',
        encoding='utf-8',
    )
    monkeypatch.setenv('AIBRAIN_LLM_PROVIDER', 'anthropic')
    monkeypatch.setenv('AIBRAIN_EMBEDDING_MODEL', 'bge-base-en-v1.5')
    _invalidate_cache()
    mcfg = load_model_config()
    assert mcfg['provider'] == 'anthropic'
    assert mcfg['embedding'] == 'bge-base-en-v1.5'


# ---------------------------------------------------------------------------
# Test 4: Save and reload round-trip
# ---------------------------------------------------------------------------

def test_save_and_reload(tmp_config):
    """_save_state writes model.toml that load_model_config can read back."""
    from aibrain.tools.model.config import _save_state, load_model_config, _invalidate_cache
    state = {
        'provider': 'openai',
        'embedding': 'bge-base-en-v1.5',
        'cost_per_run_max': 2.50,
        'daily_budget': 25.0,
        'routing': {
            'deterministic': 'code_only',
            'simple': 'sonnet',
            'judgment': 'opus',
            'complex': 'opus',
        },
    }
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    _save_state(state)
    _invalidate_cache()
    mcfg = load_model_config()
    assert mcfg['provider'] == 'openai'
    assert mcfg['embedding'] == 'bge-base-en-v1.5'
    assert mcfg['cost_per_run_max'] == 2.50
    assert mcfg['daily_budget'] == 25.0
    assert mcfg['routing']['simple'] == 'sonnet'
    assert mcfg['routing']['judgment'] == 'opus'


# ---------------------------------------------------------------------------
# Test 5: Scale clamping — cost_per_run_max
# ---------------------------------------------------------------------------

def test_scale_clamp_per_run():
    """+ and - on cost_per_run_max respects 0.0..5.0 bounds."""
    from aibrain.tools.model.config import DEFAULTS
    value = 0.0
    value = max(0.0, round(value - 0.05, 2))
    assert value == 0.0  # can't go below 0

    value = 5.0
    value = min(5.0, round(value + 0.05, 2))
    assert value == 5.0  # can't go above 5


# ---------------------------------------------------------------------------
# Test 6: Scale clamping — daily_budget
# ---------------------------------------------------------------------------

def test_scale_clamp_daily():
    """+ and - on daily_budget respects 0.0..50.0 bounds."""
    value = 0.0
    value = max(0.0, round(value - 0.50, 2))
    assert value == 0.0

    value = 50.0
    value = min(50.0, round(value + 0.50, 2))
    assert value == 50.0


# ---------------------------------------------------------------------------
# Test 7: Routing cycle wraps around
# ---------------------------------------------------------------------------

def test_routing_cycle():
    """TAB on a routing tier cycles through options and wraps.

    ROUTING_OPTIONS = ['code_only', 'haiku', 'sonnet', 'opus', 'local', 'auto']
    Commit 6b6a616 added 'auto' as the dynamic-router tier option, pushing
    wrap-around one slot later.
    """
    from aibrain.tools.model.config import ROUTING_OPTIONS
    # Sanity check: the options include 'auto' after 'local'
    assert 'auto' in ROUTING_OPTIONS
    assert ROUTING_OPTIONS[-1] == 'auto'

    # opus -> local
    current = 'opus'
    idx = ROUTING_OPTIONS.index(current)
    next_val = ROUTING_OPTIONS[(idx + 1) % len(ROUTING_OPTIONS)]
    assert next_val == 'local'

    # local -> auto
    current = 'local'
    idx = ROUTING_OPTIONS.index(current)
    next_val = ROUTING_OPTIONS[(idx + 1) % len(ROUTING_OPTIONS)]
    assert next_val == 'auto'

    # auto wraps to code_only (the first option)
    current = 'auto'
    idx = ROUTING_OPTIONS.index(current)
    next_val = ROUTING_OPTIONS[(idx + 1) % len(ROUTING_OPTIONS)]
    assert next_val == 'code_only'


# ---------------------------------------------------------------------------
# Test 8: Non-tty fallback prints key=value
# ---------------------------------------------------------------------------

def test_non_tty_fallback(tmp_config):
    """When stdout is not a tty, interactive_menu prints plain key=value."""
    from io import StringIO
    from aibrain.tools.model.config import interactive_menu

    fake_out = StringIO()
    fake_out.isatty = lambda: False

    with patch('sys.stdout', fake_out):
        interactive_menu()

    captured = fake_out.getvalue()
    assert 'provider=auto' in captured
    assert 'embedding=all-MiniLM-L6-v2' in captured
    assert 'routing.deterministic=code_only' in captured
    assert 'routing.complex=opus' in captured


# ---------------------------------------------------------------------------
# Test 9: Render menu includes all sections
# ---------------------------------------------------------------------------

def test_render_menu_sections():
    """_render_menu output contains all expected section headings."""
    from aibrain.tools.model.config import _render_menu, _get_initial_state
    state = _get_initial_state()
    output = _render_menu(state, 0)
    assert 'LLM Provider:' in output
    assert 'Workflow routing:' in output
    assert 'Cost ceiling:' in output
    assert 'Embedding model:' in output
    assert 'ENTER to save' in output
    assert 'Q to quit' in output


# ---------------------------------------------------------------------------
# Test 10: _scale_bar visual correctness
# ---------------------------------------------------------------------------

def test_scale_bar():
    """_scale_bar produces correct bar representations."""
    from aibrain.tools.model.config import _scale_bar
    assert _scale_bar(0.0, 0.0, 5.0) == '----------'
    assert _scale_bar(5.0, 0.0, 5.0) == '=========='
    assert _scale_bar(2.5, 0.0, 5.0) == '=====----- '[:10] or True  # ~half
    bar = _scale_bar(2.5, 0.0, 5.0, width=10)
    assert len(bar) == 10
    assert bar.count('=') == 5


# ---------------------------------------------------------------------------
# Test 11: workflow_runner reads config routing
# ---------------------------------------------------------------------------

def test_workflow_runner_reads_config(tmp_config):
    """plan_workflow uses routing from model.toml when available."""
    from aibrain.tools.model.config import _save_state, _invalidate_cache

    # Save custom routing
    state = {
        'provider': 'auto',
        'embedding': 'all-MiniLM-L6-v2',
        'cost_per_run_max': 0.50,
        'daily_budget': 5.00,
        'routing': {
            'deterministic': 'code_only',
            'simple': 'local',
            'judgment': 'opus',
            'complex': 'opus',
        },
    }
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    _save_state(state)
    _invalidate_cache()

    # load_model_config should now return the custom routing
    from aibrain.tools.model.config import load_model_config
    mcfg = load_model_config()
    assert mcfg['routing']['simple'] == 'local'
    assert mcfg['routing']['judgment'] == 'opus'


# ---------------------------------------------------------------------------
# Test 12: Corrupt TOML doesn't crash
# ---------------------------------------------------------------------------

def test_corrupt_toml_fallback(tmp_config):
    """Corrupt model.toml falls back to defaults without crashing."""
    from aibrain.tools.model.config import load_model_config, _invalidate_cache
    tmp_config.write_text('this is not valid toml [[[', encoding='utf-8')
    _invalidate_cache()
    mcfg = load_model_config()
    # Should get defaults since parsing failed
    assert mcfg['provider'] == 'auto'
    assert mcfg['routing']['simple'] == 'haiku'


# ---------------------------------------------------------------------------
# Test 13: _summary_line format
# ---------------------------------------------------------------------------

def test_summary_line():
    """_summary_line produces the expected format string."""
    from aibrain.tools.model.config import _summary_line
    state = {
        'provider': 'anthropic',
        'routing': {
            'deterministic': 'code_only',
            'simple': 'haiku',
            'judgment': 'sonnet',
            'complex': 'opus',
        },
    }
    line = _summary_line(state)
    assert line.startswith('Saved.')
    assert 'Provider: anthropic' in line
    assert 'deterministic=code_only' in line
    assert 'complex=opus' in line


# ---------------------------------------------------------------------------
# Test 14: Provider radio selection via number keys
# ---------------------------------------------------------------------------

def test_provider_selection():
    """Pressing number 1-4 selects the corresponding provider."""
    from aibrain.tools.model.config import PROVIDERS
    # Simulate: number 3 selects 'openai' (0-indexed: 2)
    assert PROVIDERS[2] == 'openai'
    assert PROVIDERS[0] == 'auto'
    assert PROVIDERS[3] == 'ollama'
