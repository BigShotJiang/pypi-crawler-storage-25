"""test_lens_router.py — tests for the v1.4 public/private lens split.

Covers:
  * Public-floor mode (no overlay): lens counts, archetype presence,
    zero named Shadow Board strings in the public floor.
  * Tier enforcement: free-tier downgrade path + upgrade_notice.
  * Overlay merge semantics: fake fixture replaces public-floor keys.
  * Graceful degrade: missing overlay file produces no exceptions.

The test works by reloading ``aibrain.core.lens_router`` with patched
environment variables that point at the check-in fake fixture under
``tests/fixtures/fake_decker_system/``.
"""
from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path

import pytest


FIXTURE_ROOT = Path(__file__).parent / "fixtures" / "fake_decker_system"

# The 41 real Shadow Board names — public floor must contain ZERO of these.
SHADOW_BOARD_NAMES = [
    "Linus Torvalds", "John Carmack", "Donald Knuth", "Edsger Dijkstra",
    "Leslie Lamport", "Jeff Dean", "Tony Hoare", "Barbara Liskov",
    "Margaret Hamilton", "Andrej Karpathy", "Yann LeCun", "Geoffrey Hinton",
    "Ilya Sutskever", "Demis Hassabis", "Dario Amodei", "Sam Altman",
    "Stuart Russell", "Claude Shannon", "Norbert Wiener", "Rich Hickey",
    "Guido van Rossum", "Bruce Schneier", "John McAfee", "Peter Thiel",
    "Marc Andreessen", "Naval Ravikant", "Charlie Munger", "Jeff Bezos",
    "Brian Chesky", "Patrick Collison", "Elon Musk", "Steve Jobs",
    "Joel Spolsky", "DHH", "Grace Hopper", "Paul Graham", "Timothy Leary",
    "Daniel Kahneman", "Stewart Brand", "Alan Kay", "Jensen Huang",
]


# ---------------------------------------------------------------------------
# Reload helpers — isolate overlay loading per-test
# ---------------------------------------------------------------------------

def _reload_lens_router_with_root(root: str | None) -> object:
    """Reload lens_router with DECKER_SYSTEM_ROOT set (or blocked).

    ``root=None`` means "no overlay should be discoverable" — we point
    USERPROFILE and HOME at an empty throwaway dir so the Windows and
    POSIX platform defaults can't find a real decker_system.
    """
    # Clear any previous overlay modules
    sys.modules.pop("_aibrain_lens_overlay", None)
    sys.modules.pop("aibrain.core.lens_router", None)
    sys.modules.pop("aibrain.core.lenses_public", None)
    sys.modules.pop("aibrain.core.agent_router", None)

    if root is None:
        # Block every lookup path
        os.environ["DECKER_SYSTEM_ROOT"] = str(Path(__file__).parent / "__nonexistent__")
        os.environ.pop("USERPROFILE", None)
        # Point HOME at a throwaway location that has no decker_system subdir
        os.environ["HOME"] = str(Path(__file__).parent / "__nonexistent__")
    else:
        os.environ["DECKER_SYSTEM_ROOT"] = root

    from aibrain.core import lens_router  # noqa: F401
    return importlib.import_module("aibrain.core.lens_router")


@pytest.fixture
def public_only_router(monkeypatch):
    """Load lens_router in public-only mode (no overlay).

    Uses the ``AIBRAIN_DISABLE_OVERLAY=1`` escape hatch — the cleanest
    way to force public-only mode regardless of what's on disk.
    """
    monkeypatch.setenv("AIBRAIN_DISABLE_OVERLAY", "1")

    sys.modules.pop("_aibrain_lens_overlay", None)
    sys.modules.pop("aibrain.core.lens_router", None)
    sys.modules.pop("aibrain.core.lenses_public", None)
    sys.modules.pop("aibrain.core.agent_router", None)
    yield importlib.import_module("aibrain.core.lens_router")
    sys.modules.pop("_aibrain_lens_overlay", None)
    sys.modules.pop("aibrain.core.lens_router", None)
    sys.modules.pop("aibrain.core.agent_router", None)


@pytest.fixture
def overlay_router(monkeypatch):
    """Load lens_router with the fake fixture overlay attached."""
    monkeypatch.delenv("AIBRAIN_DISABLE_OVERLAY", raising=False)
    monkeypatch.setenv("DECKER_SYSTEM_ROOT", str(FIXTURE_ROOT))
    sys.modules.pop("_aibrain_lens_overlay", None)
    sys.modules.pop("aibrain.core.lens_router", None)
    sys.modules.pop("aibrain.core.lenses_public", None)
    sys.modules.pop("aibrain.core.agent_router", None)
    yield importlib.import_module("aibrain.core.lens_router")
    sys.modules.pop("_aibrain_lens_overlay", None)
    sys.modules.pop("aibrain.core.lens_router", None)
    sys.modules.pop("aibrain.core.agent_router", None)


# ---------------------------------------------------------------------------
# Public-floor purity
# ---------------------------------------------------------------------------

def test_public_floor_has_no_named_personas():
    """The shipped public files must contain zero real Shadow Board names."""
    repo_root = Path(__file__).parent.parent
    public_files = [
        repo_root / "aibrain" / "core" / "lenses_public.py",
        repo_root / "aibrain" / "core" / "lens_router.py",
        repo_root / "aibrain" / "core" / "agent_router.py",
    ]
    for fp in public_files:
        text = fp.read_text(encoding="utf-8")
        for name in SHADOW_BOARD_NAMES:
            assert name not in text, (
                f"LEAK: {name!r} found in public file {fp.name} — this name "
                f"must live in the private overlay only."
            )


def test_public_floor_has_archetype_defaults():
    """agent_router public defaults route ml/concurrency/data_modeling to archetypes."""
    from aibrain.core.agent_router import _DEFAULT_SPECIALIST_AGENT_PUBLIC
    assert _DEFAULT_SPECIALIST_AGENT_PUBLIC["ml_implementation"] == "Empirical Metrics"
    assert _DEFAULT_SPECIALIST_AGENT_PUBLIC["concurrency"] == "Distributed Systems"
    assert _DEFAULT_SPECIALIST_AGENT_PUBLIC["data_modeling"] == "Data-First Thinking"


def test_public_floor_lens_count(public_only_router):
    """Public floor should have at least 43 lens keys (design floor)."""
    lr = public_only_router
    assert not lr._OVERLAY_LOADED, "public_only_router should have no overlay"
    # 20 roles + 13 specialty + 10 archetypes + 2 always-on + 5 enterprise = 50
    assert len(lr.LENSES) >= 43, f"public floor has only {len(lr.LENSES)} lenses"


def test_public_floor_always_on_is_neutral(public_only_router):
    lr = public_only_router
    assert lr.ALWAYS_ON_LENSES == ["Operator Lens", "Adversarial Security Lens"]


def test_public_task_type_lists_reference_only_public_keys(public_only_router):
    lr = public_only_router
    for task_type, names in lr.TASK_TYPE_LENSES.items():
        for n in names:
            assert n in lr.LENSES, (
                f"task_type {task_type!r} references unknown lens {n!r} — "
                f"public floor must be self-consistent"
            )


# ---------------------------------------------------------------------------
# Tier enforcement
# ---------------------------------------------------------------------------

def test_tier_enforcement_free_research(public_only_router):
    """Free-tier research_question routes to Research Analyst with no notice."""
    lr = public_only_router
    r = lr.route(task_type="research_question", tier="free")
    assert "Research Analyst" in r.lenses
    # Research Analyst is the natural top pick and is in free tier — no notice.
    assert r.upgrade_notice is None


def test_tier_enforcement_free_legal_triggers_upgrade_notice(public_only_router):
    """Free-tier legal_compliance naturally wants Legal Advisor (Pro) —
    should route to free-tier fallback AND return an upgrade_notice."""
    lr = public_only_router
    r = lr.route(task_type="legal_compliance", tier="free")
    # Natural pick "Legal Advisor" is Pro — must not appear in free output
    assert "Legal Advisor" not in r.lenses
    # Notice must mention both the downgrade target and the Pro lens
    assert r.upgrade_notice is not None
    assert "Legal Advisor" in r.upgrade_notice
    assert "Pro tier" in r.upgrade_notice


def test_tier_enforcement_pro_legal_no_notice(public_only_router):
    """Pro-tier legal_compliance gets Legal Advisor directly, no notice."""
    lr = public_only_router
    r = lr.route(task_type="legal_compliance", tier="pro")
    assert "Legal Advisor" in r.lenses
    assert r.upgrade_notice is None


def test_free_tier_lenses_are_limited(public_only_router):
    """Free tier allowed set should be tiny — not the full public floor."""
    lr = public_only_router
    allowed = lr._effective_allowed("free")
    assert "Research Analyst" in allowed
    assert "Content Writer" in allowed
    assert "CTO" not in allowed
    assert "Chain Logic Reviewer" not in allowed


# ---------------------------------------------------------------------------
# Overlay merge
# ---------------------------------------------------------------------------

def test_overlay_merge_replaces_public_keys(overlay_router):
    """Fake fixture must override the same-key public entries."""
    lr = overlay_router
    assert lr._OVERLAY_LOADED is True
    # Additive keys from the fake fixture
    assert "test_persona_alpha" in lr.LENSES
    assert "test_persona_beta" in lr.LENSES
    assert "test_persona_gamma" in lr.LENSES
    # Same-key replacement — fixture content must win
    assert lr.LENSES["Empirical Metrics"]["specialty"] == "FIXTURE REPLACED empirical metrics"
    assert lr.LENSES["CEO"]["specialty"] == "FIXTURE REPLACED ceo lens"


def test_overlay_replaces_always_on(overlay_router):
    """Overlay OVERLAY_ALWAYS_ON fully replaces the public list."""
    lr = overlay_router
    assert lr.ALWAYS_ON_LENSES == ["test_always_on_alpha", "test_always_on_beta"]


def test_overlay_bypasses_tier_enforcement(overlay_router):
    """With overlay loaded, tier filtering is a no-op — everything is allowed."""
    lr = overlay_router
    allowed = lr._effective_allowed("free")
    # Even with tier=free, overlay grants access to the whole merged registry
    assert len(allowed) == len(lr.LENSES)


def test_overlay_graceful_degrade_missing_file(public_only_router):
    """No overlay file found anywhere = public floor runs clean, no exceptions.
    The public_only_router fixture already exercises this path — if any
    exception was raised we'd have failed in fixture setup."""
    lr = public_only_router
    assert lr._OVERLAY_LOADED is False
    r = lr.route(task_type="code_review", tier="pro")
    assert len(r.lenses) > 0


def test_agent_router_overlay_default_patching(overlay_router):
    """Fake fixture patches ml_implementation → test_persona_alpha."""
    sys.modules.pop("aibrain.core.agent_router", None)
    import aibrain.core.agent_router as ar
    importlib.reload(ar)
    assert ar.DEFAULT_SPECIALIST_AGENT["ml_implementation"] == "test_persona_alpha"


# ---------------------------------------------------------------------------
# Backward-compat smoke — route() still returns usable LensRoute
# ---------------------------------------------------------------------------

def test_route_returns_lens_route_with_basic_fields(public_only_router):
    lr = public_only_router
    r = lr.route(task_type="code_review", tier="pro")
    assert r.task_type == "code_review"
    assert len(r.lenses) >= 1
    assert r.always_on  # non-empty
    assert r.routing_reason
    # LensRoute helper properties still work
    assert r.total_lens_count == len(set(r.lenses) | set(r.always_on))
