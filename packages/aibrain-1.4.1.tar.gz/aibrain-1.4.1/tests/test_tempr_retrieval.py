"""
Tests for tempr_retrieval.py — 4-channel TEMPR hybrid retriever.

Uses an isolated sqlite fixture (either :memory: or tmp_path) — the canonical
brain DB is NEVER touched by this test module.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

# Make sibling modules importable when running pytest from repo root or tests/.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.tempr_retrieval import (  # noqa: E402
    DEFAULT_RRF_K,
    TEMPRRetriever,
    _prepare_fts_query,
    _rrf_fuse,
    _seed_ids,
)
from aibrain.core.memory_recall import memory_recall  # noqa: E402


# ---------------------------------------------------------------------------
# Fixtures — tiny self-contained corpus that exercises all 4 channels
# ---------------------------------------------------------------------------


@pytest.fixture()
def tempr_db():
    """Isolated sqlite DB with memories, memories_fts, and entity_links."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            storage_strength REAL DEFAULT 1.0,
            status TEXT DEFAULT 'active',
            valid_until TEXT
        );
        CREATE VIRTUAL TABLE memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        );
        CREATE TRIGGER memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;
        CREATE TABLE entity_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type TEXT NOT NULL,
            source_id INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_id INTEGER NOT NULL,
            relationship TEXT NOT NULL DEFAULT 'relates_to',
            metadata TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """
    )

    memories = [
        # id 1: high match for "deploy production"
        ("Deploy guide", "devops", "deploy", "How to deploy to production with Docker", 0.9),
        # id 2: related to id 1 via graph (both devops/deploy)
        ("Docker compose", "devops", "docker", "Using docker-compose for multi-container setups", 0.7),
        # id 3: graph neighbour of 1 — rollback runbook
        ("Rollback runbook", "devops", "deploy", "If deploy fails, run rollback.sh on the host", 0.8),
        # id 4: unrelated high-importance
        ("Python tips", "reference", "python", "Python best practices for async programming", 0.7),
        # id 5: stale, low importance
        ("Old config", "project", "config", "Legacy config that is no longer used", 0.2),
        # id 6: recent but unrelated
        ("Status update", "project", "meta", "Today's standup notes for the team", 0.5),
    ]
    for name, mtype, tags, content, imp in memories:
        conn.execute(
            "INSERT INTO memories (name, type, tags, content, importance) "
            "VALUES (?, ?, ?, ?, ?)",
            (name, mtype, tags, content, imp),
        )
    # Graph — 1<->2, 1<->3, 2<->3 form a tight devops triangle
    edges = [(1, 2), (1, 3), (2, 3)]
    for src, tgt in edges:
        conn.execute(
            "INSERT INTO entity_links "
            "(source_type, source_id, target_type, target_id, relationship) "
            "VALUES ('memory', ?, 'memory', ?, 'co_occurrence')",
            (src, tgt),
        )
    conn.commit()
    yield conn
    conn.close()


# ---------------------------------------------------------------------------
# RRF fusion (unit-level)
# ---------------------------------------------------------------------------


class TestRRFFuse:
    def test_single_list_preserves_order(self):
        items = [{"id": 1}, {"id": 2}, {"id": 3}]
        fused = _rrf_fuse([items], rrf_k=60, weights=[1.0], labels=["t"])
        assert [r["id"] for r in fused] == [1, 2, 3]

    def test_shared_items_boosted(self):
        l1 = [{"id": 1}, {"id": 2}]
        l2 = [{"id": 2}, {"id": 3}]
        fused = _rrf_fuse([l1, l2], rrf_k=60, weights=[1.0, 1.0], labels=["a", "b"])
        assert fused[0]["id"] == 2
        assert set(fused[0]["retrieval_methods"]) == {"a", "b"}

    def test_empty_lists_return_empty(self):
        assert _rrf_fuse([[], []], rrf_k=60, weights=[1.0, 1.0], labels=["a", "b"]) == []

    def test_weights_affect_ranking(self):
        l1 = [{"id": 1}]
        l2 = [{"id": 2}]
        fused = _rrf_fuse([l1, l2], rrf_k=60, weights=[1.0, 10.0], labels=["a", "b"])
        assert fused[0]["id"] == 2

    def test_missing_id_skipped_not_crashed(self):
        l1 = [{"no_id": True}, {"id": 7}]
        fused = _rrf_fuse([l1], rrf_k=60, weights=[1.0], labels=["t"])
        assert [r["id"] for r in fused] == [7]


class TestSeedIds:
    def test_round_robin_dedup(self):
        a = [{"id": 1}, {"id": 2}, {"id": 3}]
        b = [{"id": 2}, {"id": 4}]
        seeds = _seed_ids(a, b, limit=5)
        # Round robin: 1 (a[0]), 2 (b[0]), 2-dup-skip, 4 (b[1]), 3 (a[2])
        assert seeds[0] == 1
        assert set(seeds) == {1, 2, 3, 4}
        assert len(seeds) == 4

    def test_respects_limit(self):
        a = [{"id": i} for i in range(20)]
        assert len(_seed_ids(a, limit=5)) == 5


class TestPrepareFtsQuery:
    def test_quotes_and_joins(self):
        q = _prepare_fts_query("deploy production")
        assert '"deploy"' in q and '"production"' in q and " OR " in q

    def test_single_char_skipped(self):
        q = _prepare_fts_query("a deploy")
        assert '"a"' not in q and '"deploy"' in q

    def test_empty_returns_empty(self):
        assert _prepare_fts_query("   ") == ""


# ---------------------------------------------------------------------------
# Channel-level tests — each channel in isolation against the fixture DB
# ---------------------------------------------------------------------------


class TestChannels:
    def test_bm25_channel_finds_match(self, tempr_db):
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr._channel_bm25(tempr_db, "deploy production", 20)
        names = [h["name"] for h in hits]
        assert "Deploy guide" in names

    def test_semantic_channel_no_vec_returns_empty(self, tempr_db):
        """Without sqlite-vec loaded, semantic channel returns [] cleanly."""
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr._channel_semantic(tempr_db, "deploy production", 20)
        # Either empty (no vec) or populated — both are valid; must not crash.
        assert isinstance(hits, list)

    def test_graph_channel_expands_from_seeds(self, tempr_db):
        """Seeding with memory id 1 should pull in ids 2 and 3 via entity_links."""
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr._channel_graph(tempr_db, seed_ids=[1], limit=20)
        returned_ids = {h["id"] for h in hits}
        assert 2 in returned_ids
        assert 3 in returned_ids
        # Seed itself excluded.
        assert 1 not in returned_ids

    def test_graph_channel_empty_seeds(self, tempr_db):
        retr = TEMPRRetriever(db=tempr_db)
        assert retr._channel_graph(tempr_db, seed_ids=[], limit=20) == []

    def test_graph_channel_respects_depth(self, tempr_db):
        # Depth=1 from id 1 should hit 2 and 3 (direct neighbours). The tight
        # triangle means 2<->3 are also 1 hop from 1 either way.
        retr = TEMPRRetriever(db=tempr_db, graph_depth=1)
        hits = retr._channel_graph(tempr_db, seed_ids=[1], limit=20)
        returned_ids = {h["id"] for h in hits}
        assert returned_ids == {2, 3}

    def test_temporal_channel_scores_present(self, tempr_db):
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr._channel_temporal(tempr_db, 20)
        assert hits
        for h in hits:
            assert "temporal_score" in h and h["temporal_score"] > 0

    def test_temporal_channel_importance_affects_order(self, tempr_db):
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr._channel_temporal(tempr_db, 20)
        scores = {h["name"]: h["temporal_score"] for h in hits}
        # Deploy guide (imp=0.9) > Old config (imp=0.2) with same age
        assert scores["Deploy guide"] > scores["Old config"]


# ---------------------------------------------------------------------------
# End-to-end TEMPRRetriever.retrieve
# ---------------------------------------------------------------------------


class TestTEMPRRetrieve:
    def test_retrieve_returns_ranked_hits(self, tempr_db):
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr.retrieve("deploy production", k=5)
        assert hits, "TEMPR returned zero hits for a query that should match"
        # Top hit must be the direct BM25 match.
        assert hits[0]["name"] == "Deploy guide"
        # And it must carry fusion metadata.
        assert "rrf_score" in hits[0]
        assert "retrieval_methods" in hits[0]
        assert hits[0]["rrf_score"] > 0

    def test_retrieve_empty_query_returns_empty(self, tempr_db):
        retr = TEMPRRetriever(db=tempr_db)
        assert retr.retrieve("", k=5) == []
        assert retr.retrieve("   ", k=5) == []

    def test_retrieve_respects_k(self, tempr_db):
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr.retrieve("deploy", k=2)
        assert len(hits) <= 2

    def test_graph_pulls_in_neighbours(self, tempr_db):
        """TEMPR should surface graph-neighbours of direct matches.

        'production' only literally appears in 'Deploy guide' (id=1). But
        'Rollback runbook' (id=3) and 'Docker compose' (id=2) are 1 hop
        away via entity_links — TEMPR should return them in top results.
        """
        retr = TEMPRRetriever(db=tempr_db)
        hits = retr.retrieve("production", k=5)
        names = [h["name"] for h in hits]
        # Direct match present
        assert "Deploy guide" in names
        # At least one graph neighbour surfaced
        assert "Rollback runbook" in names or "Docker compose" in names

    def test_custom_weights_honoured(self, tempr_db):
        # Crank temporal weight way up — top hit becomes the most-recent
        # memory regardless of lexical match.
        retr = TEMPRRetriever(
            db=tempr_db,
            weights={"semantic": 0.0, "bm25": 0.0, "graph": 0.0, "temporal": 100.0},
        )
        hits = retr.retrieve("deploy", k=3)
        assert hits, "Temporal-only TEMPR returned zero hits"
        # Top hit under temporal-only has the highest importance (recency
        # is approximately equal across the fixture).
        top_imp = hits[0].get("importance", 0)
        assert top_imp >= 0.7


# ---------------------------------------------------------------------------
# memory_recall integration — default path MUST be a no-op pass-through
# ---------------------------------------------------------------------------


class TestMemoryRecallWrapper:
    def test_tempr_mode_uses_retriever(self, tempr_db):
        hits = memory_recall("deploy production", limit=5, mode="tempr", db=tempr_db)
        assert hits
        assert hits[0]["name"] == "Deploy guide"
        assert "rrf_score" in hits[0]

    def test_invalid_mode_raises(self, tempr_db):
        with pytest.raises(ValueError):
            memory_recall("x", mode="not_a_mode", db=tempr_db)

    def test_default_mode_delegates(self, monkeypatch):
        """Default mode must call aibrain_db.search_memories and nothing else.

        This pins the contract: importing memory_recall and using the
        default mode is a strict pass-through to the existing canonical
        search. If this test fails, the opt-in promise is broken.
        """
        called = {}

        class _FakeADB:
            @staticmethod
            def search_memories(q, limit=10, search_type=None):
                called["q"] = q
                called["limit"] = limit
                called["search_type"] = search_type
                return [{"id": 42, "name": "fake", "content": "ok"}]

        monkeypatch.setitem(sys.modules, "aibrain_db", _FakeADB)
        out = memory_recall("hello", limit=7, search_type="factual")
        assert out == [{"id": 42, "name": "fake", "content": "ok"}]
        assert called == {"q": "hello", "limit": 7, "search_type": "factual"}


# ---------------------------------------------------------------------------
# Smoke — DEFAULT_RRF_K stays consistent with the RRF paper's canonical 60
# ---------------------------------------------------------------------------


def test_default_rrf_k_is_60():
    assert DEFAULT_RRF_K == 60
