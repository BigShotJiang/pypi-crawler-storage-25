"""
Tests for per-workflow quality evaluation functions.

Covers every registered workflow evaluator plus the generic fallback
and the registry dispatch mechanism.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.workflow_quality import (
    evaluate_workflow,
    evaluate_correction_learner,
    evaluate_evolution,
    evaluate_heartbeat,
    evaluate_memory_consolidation,
    evaluate_social_poster,
    evaluate_interview_prep,
    evaluate_security_scan,
    evaluate_generic,
    QUALITY_FUNCTIONS,
)


# ─── correction_learner ──────────────────────────────────────

class TestCorrectionLearner:
    def test_good_corrections(self):
        output = {
            "corrections": [
                {"text": "fix A", "importance": 0.8},
                {"text": "fix B", "importance": 0.7},
                {"text": "fix C", "importance": 0.6},
            ]
        }
        score = evaluate_correction_learner(output)
        assert score >= 0.8, f"Expected >= 0.8 for good corrections, got {score}"

    def test_empty_corrections(self):
        output = {"corrections": []}
        score = evaluate_correction_learner(output)
        assert 0.3 <= score <= 0.5

    def test_none_output(self):
        assert evaluate_correction_learner(None) == 0.1

    def test_error_output(self):
        assert evaluate_correction_learner({"error": "traceback in module"}) == 0.1

    def test_duplicates_penalised(self):
        output = {
            "corrections": [
                {"text": "fix A", "importance": 0.8},
                {"text": "fix A", "importance": 0.8},  # duplicate
            ]
        }
        score_dup = evaluate_correction_learner(output)
        output_unique = {
            "corrections": [
                {"text": "fix A", "importance": 0.8},
                {"text": "fix B", "importance": 0.8},
            ]
        }
        score_uniq = evaluate_correction_learner(output_unique)
        assert score_uniq >= score_dup, "Unique corrections should score >= duplicates"


# ─── evolution ────────────────────────────────────────────────

class TestEvolution:
    def test_full_output(self):
        output = {
            "patterns": ["pattern1", "pattern2"],
            "metrics": {"accuracy": 0.9},
            "outcomes": [{"entry": 1}],
        }
        score = evaluate_evolution(output)
        assert score >= 0.8

    def test_partial_output(self):
        output = {"patterns": ["p1"]}
        score = evaluate_evolution(output)
        assert 0.4 <= score <= 0.7

    def test_none(self):
        assert evaluate_evolution(None) == 0.1


# ─── heartbeat ────────────────────────────────────────────────

class TestHeartbeat:
    def test_all_healthy(self):
        output = {
            "status": "healthy",
            "services": {
                "api": {"status": "ok"},
                "db": {"status": "healthy"},
                "broker": {"status": "up"},
            },
            "db": "ok",
        }
        score = evaluate_heartbeat(output)
        assert score >= 0.9

    def test_partial_services(self):
        output = {
            "services": {
                "api": {"status": "ok"},
                "db": {"status": "down"},
            }
        }
        score = evaluate_heartbeat(output)
        assert 0.4 <= score <= 0.7

    def test_timeout(self):
        output = {"services": {"api": {"status": "ok"}}, "error": "timeout on broker"}
        score = evaluate_heartbeat(output)
        assert score <= 0.4

    def test_none(self):
        assert evaluate_heartbeat(None) == 0.0

    def test_string_healthy(self):
        score = evaluate_heartbeat("All services healthy")
        assert score >= 0.8


# ─── memory_consolidation ────────────────────────────────────

class TestMemoryConsolidation:
    def test_good_consolidation(self):
        output = {
            "clusters": 5,
            "merges": 3,
            "data_loss": False,
            "success": True,
        }
        score = evaluate_memory_consolidation(output)
        assert score >= 0.8

    def test_no_merges(self):
        output = {"clusters": 2, "merges": 0, "data_loss": False}
        score = evaluate_memory_consolidation(output)
        assert 0.4 <= score <= 0.7

    def test_none(self):
        assert evaluate_memory_consolidation(None) == 0.1


# ─── social_poster ────────────────────────────────────────────

class TestSocialPoster:
    def test_published(self):
        output = {
            "published": True,
            "post_id": "12345",
            "on_schedule": True,
            "success": True,
        }
        score = evaluate_social_poster(output)
        assert score >= 0.9

    def test_not_published(self):
        output = {"published": False}
        score = evaluate_social_poster(output)
        assert score <= 0.5

    def test_none(self):
        assert evaluate_social_poster(None) == 0.1


# ─── interview_prep ──────────────────────────────────────────

class TestInterviewPrep:
    def test_thorough_prep(self):
        output = {
            "company": "Acme Corp",
            "requirements": ["Python", "Docker", "AWS"],
            "questions": [f"Q{i}" for i in range(7)],
        }
        score = evaluate_interview_prep(output)
        assert score >= 0.9

    def test_minimal_prep(self):
        output = {"company": "Acme Corp"}
        score = evaluate_interview_prep(output)
        assert 0.4 <= score <= 0.6

    def test_string_output(self):
        output = "Company: Acme Corp\nRequirement: Python\nQuestion: Tell me about yourself"
        score = evaluate_interview_prep(output)
        assert score >= 0.7

    def test_none(self):
        assert evaluate_interview_prep(None) == 0.1


# ─── security_scan ────────────────────────────────────────────

class TestSecurityScan:
    def test_findings(self):
        output = {
            "findings": [
                {"id": "CVE-2024-001", "severity": "critical"},
                {"id": "CVE-2024-002", "severity": "medium"},
            ],
            "report_generated": True,
            "success": True,
        }
        score = evaluate_security_scan(output)
        assert score >= 0.9

    def test_no_findings(self):
        output = {"findings": [], "success": True}
        score = evaluate_security_scan(output)
        assert 0.4 <= score <= 0.7

    def test_crash(self):
        output = {"error": "crash in scanner module"}
        score = evaluate_security_scan(output)
        assert score <= 0.2

    def test_none(self):
        assert evaluate_security_scan(None) == 0.0


# ─── generic fallback ────────────────────────────────────────

class TestGeneric:
    def test_success_dict(self):
        assert evaluate_generic({"success": True}) == 0.8

    def test_error_dict(self):
        assert evaluate_generic({"error": "something failed"}) == 0.2

    def test_none(self):
        assert evaluate_generic(None) == 0.0

    def test_list(self):
        assert evaluate_generic([1, 2, 3]) == 0.7

    def test_string(self):
        # Honest-rubric rule (commit 730a682): evaluate_generic refuses to
        # stamp a fake baseline score for a plain string — a long string
        # is not the same as a good string. Returns None ("could not
        # measure") so the harness stores NULL instead of inventing 0.6.
        assert evaluate_generic("some meaningful output") is None


# ─── registry dispatch ───────────────────────────────────────

class TestRegistry:
    def test_known_workflow_dispatches(self):
        """evaluate_workflow uses the registered function, not generic."""
        output = {
            "status": "healthy",
            "services": {"api": {"status": "ok"}},
        }
        score = evaluate_workflow("heartbeat", output)
        generic_score = evaluate_generic(output)
        # Heartbeat-specific should differ from generic
        assert score != generic_score or score >= 0.7

    def test_unknown_workflow_uses_generic(self):
        output = {"success": True}
        assert evaluate_workflow("some_unknown_workflow", output) == evaluate_generic(output)

    def test_all_registered_are_callable(self):
        for name, fn in QUALITY_FUNCTIONS.items():
            assert callable(fn), f"{name} is not callable"
            # Each should handle None gracefully
            score = fn(None)
            assert 0.0 <= score <= 1.0, f"{name}(None) returned {score}"

    def test_aliases_work(self):
        """evolution_cycle and evolution_auto_loop should use evolution evaluator."""
        output = {"patterns": ["p1"], "metrics": {"x": 1}, "outcomes": [1]}
        s1 = evaluate_workflow("evolution_cycle", output)
        s2 = evaluate_workflow("evolution_auto_loop", output)
        s3 = evaluate_workflow("evolution", output)
        assert s1 == s2 == s3
