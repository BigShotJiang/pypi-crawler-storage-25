"""
Tests for hive filesystem permission model in profile_ops.py.
"""

import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from aibrain.core.profile_ops import (
    get_profile_permissions,
    check_permissions,
    HIVE_READ_ONLY_DIRS,
    HIVE_WRITABLE,
)


# ---------------------------------------------------------------------------
# get_profile_permissions tests
# ---------------------------------------------------------------------------

class TestGetProfilePermissions:

    def test_hive_mode_permissions(self):
        """Hive profiles get read-write on DB, read-only on shared dirs."""
        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg:
            mock_reg.get_profile_entry.return_value = {"mode": "hive"}
            perms = get_profile_permissions("test-hive")

        assert perms["mode"] == "hive"
        assert perms["db_access"] == "read-write"
        assert "skills" in perms["read_only_dirs"]
        assert "agents" in perms["read_only_dirs"]
        assert "rules" in perms["read_only_dirs"]
        assert perms["writable_dirs"] == []

    def test_isolated_mode_permissions(self):
        """Isolated profiles get own DB and writable dirs."""
        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg:
            mock_reg.get_profile_entry.return_value = {"mode": "isolated"}
            perms = get_profile_permissions("test-iso")

        assert perms["mode"] == "isolated"
        assert perms["db_access"] == "own"
        assert perms["read_only_dirs"] == []
        assert "skills" in perms["writable_dirs"]
        assert "agents" in perms["writable_dirs"]

    def test_unregistered_defaults_to_hive(self):
        """Unregistered profile falls back to hive mode."""
        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg:
            mock_reg.get_profile_entry.return_value = None
            perms = get_profile_permissions("unknown")

        assert perms["mode"] == "hive"

    def test_writable_files_include_db_and_settings(self):
        """Both modes can write CLAUDE.md, settings.json, .claude.json."""
        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg:
            mock_reg.get_profile_entry.return_value = {"mode": "hive"}
            perms = get_profile_permissions("test")

        assert "CLAUDE.md" in perms["writable_files"]
        assert "settings.json" in perms["writable_files"]
        assert "aibrain.db" in perms["writable_files"]


# ---------------------------------------------------------------------------
# check_permissions tests
# ---------------------------------------------------------------------------

class TestCheckPermissions:

    def test_missing_profile_dir_returns_error(self, tmp_path):
        """check_permissions flags missing profile directory."""
        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg, \
             patch("aibrain.core.profile_ops._resolve_profile_dir", return_value=tmp_path / "nonexistent"):
            mock_reg.get_profile_entry.return_value = {"mode": "hive"}
            result = check_permissions("missing")

        assert result["ok"] is False
        assert any("does not exist" in e for e in result["errors"])

    def test_hive_real_dir_flagged_as_error(self, tmp_path):
        """Hive profile with real (non-link) shared dirs gets an error."""
        profile_dir = tmp_path / ".claude-test"
        profile_dir.mkdir()
        # Create real dirs instead of links
        for d in HIVE_READ_ONLY_DIRS:
            (profile_dir / d).mkdir()

        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg, \
             patch("aibrain.core.profile_ops._resolve_profile_dir", return_value=profile_dir), \
             patch("aibrain.core.profile_ops._get_aibrain_root", return_value=tmp_path):
            mock_reg.get_profile_entry.return_value = {"mode": "hive"}
            result = check_permissions("test")

        # Real dirs in hive mode should be flagged
        assert result["ok"] is False
        assert any("should be a symlink" in e for e in result["errors"])

    def test_isolated_with_real_dirs_passes(self, tmp_path):
        """Isolated profile with real directories passes checks."""
        profile_dir = tmp_path / ".claude-iso"
        profile_dir.mkdir()
        for d in HIVE_READ_ONLY_DIRS:
            (profile_dir / d).mkdir()

        # Create a writable DB
        db_path = tmp_path / "aibrain_iso.db"
        db_path.touch()

        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg, \
             patch("aibrain.core.profile_ops._resolve_profile_dir", return_value=profile_dir):
            mock_reg.get_profile_entry.return_value = {
                "mode": "isolated",
                "db_path": str(db_path),
            }
            result = check_permissions("iso")

        assert result["ok"] is True
        assert result["mode"] == "isolated"
        assert result["errors"] == []

    def test_hive_missing_shared_dirs_warns(self, tmp_path):
        """Hive profile with missing shared dirs gets warnings, not errors."""
        profile_dir = tmp_path / ".claude-test"
        profile_dir.mkdir()
        # Don't create any shared dirs

        with patch("aibrain.core.profile_ops.profile_registry") as mock_reg, \
             patch("aibrain.core.profile_ops._resolve_profile_dir", return_value=profile_dir), \
             patch("aibrain.core.profile_ops._get_aibrain_root", return_value=tmp_path):
            mock_reg.get_profile_entry.return_value = {"mode": "hive"}
            result = check_permissions("test")

        # Missing dirs are warnings, not errors
        assert len(result["warnings"]) > 0
        assert all("does not exist" not in e for e in result["errors"])
