"""Tests for aibrain.core.state_predictor — execution log state predictor."""

import math
from datetime import datetime

import pytest

from aibrain.core.state_predictor import (
    _parse_workflow,
    _recency_weight,
    build_transition_model,
    build_time_model,
    build_dow_model,
    predict_next,
    log_prediction_accuracy,
    format_predictions,
)


# ---------------------------------------------------------------------------
# Helpers — build fake execution_log entries (most-recent-first order)
# ---------------------------------------------------------------------------

def _entry(action: str, ts: str = "2026-04-09 10:00:00", success: int = 1, quality: float = 0.9):
    return {"action": action, "created_at": ts, "success": success, "quality_score": quality}


def _workflow_sequence(names_and_times: list[tuple[str, str]]) -> list[dict]:
    """Build entries from (name, timestamp) pairs. Returns most-recent-first."""
    entries = [_entry(f"workflow.{n}", ts) for n, ts in names_and_times]
    entries.reverse()  # most-recent-first
    return entries


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestParseWorkflow:
    def test_workflow_prefix(self):
        assert _parse_workflow("workflow.heartbeat") == "heartbeat"

    def test_non_workflow(self):
        assert _parse_workflow("team.something.abc") is None

    def test_empty(self):
        assert _parse_workflow("") is None


class TestRecencyWeight:
    def test_most_recent_is_1(self):
        assert _recency_weight(0, 100) == 1.0

    def test_decay(self):
        w0 = _recency_weight(0, 100)
        w50 = _recency_weight(50, 100)
        w99 = _recency_weight(99, 100)
        assert w0 > w50 > w99

    def test_single_entry(self):
        assert _recency_weight(0, 1) == 1.0


class TestBuildTransitionModel:
    def test_simple_transitions(self):
        # Chronological: A -> B -> A -> B
        entries = _workflow_sequence([
            ("A", "2026-04-09 10:00:00"),
            ("B", "2026-04-09 10:01:00"),
            ("A", "2026-04-09 10:02:00"),
            ("B", "2026-04-09 10:03:00"),
        ])
        model = build_transition_model(entries)
        assert "A" in model
        assert "B" in model["A"]
        assert "A" in model["B"]
        # A always goes to B
        assert model["A"]["B"] > 0
        # B always goes to A (except last entry has no next)
        assert model["B"]["A"] > 0

    def test_empty_entries(self):
        assert build_transition_model([]) == {}

    def test_non_workflow_entries_ignored(self):
        entries = [
            _entry("team.something.abc", "2026-04-09 10:01:00"),
            _entry("crew.test", "2026-04-09 10:00:00"),
        ]
        assert build_transition_model(entries) == {}


class TestBuildTimeModel:
    def test_hour_grouping(self):
        entries = [
            _entry("workflow.heartbeat", "2026-04-09 08:00:00"),
            _entry("workflow.heartbeat", "2026-04-09 08:30:00"),
            _entry("workflow.db_backup", "2026-04-09 22:00:00"),
        ]
        model = build_time_model(entries)
        assert 8 in model["heartbeat"]
        assert 22 in model["db_backup"]

    def test_non_workflows_excluded(self):
        entries = [_entry("team.foo", "2026-04-09 08:00:00")]
        assert build_time_model(entries) == {}


class TestBuildDowModel:
    def test_dow_grouping(self):
        # 2026-04-09 is a Thursday (weekday=3)
        entries = [_entry("workflow.heartbeat", "2026-04-09 10:00:00")]
        model = build_dow_model(entries)
        assert 3 in model["heartbeat"]

    def test_empty(self):
        assert build_dow_model([]) == {}


class TestPredictNext:
    def test_basic_prediction(self):
        # Pattern: heartbeat -> db_backup -> heartbeat -> db_backup
        entries = _workflow_sequence([
            ("heartbeat", "2026-04-09 08:00:00"),
            ("db_backup", "2026-04-09 08:05:00"),
            ("heartbeat", "2026-04-09 10:00:00"),
            ("db_backup", "2026-04-09 10:05:00"),
            ("heartbeat", "2026-04-09 12:00:00"),
        ])
        # Last workflow is heartbeat (most recent), should predict db_backup
        predictions = predict_next(
            n=3,
            now=datetime(2026, 4, 9, 12, 10),
            entries=entries,
        )
        assert len(predictions) > 0
        assert predictions[0]["workflow"] == "db_backup"
        assert predictions[0]["confidence"] > 0

    def test_empty_entries(self):
        assert predict_next(n=3, entries=[]) == []

    def test_no_workflows_in_entries(self):
        entries = [_entry("team.foo", "2026-04-09 10:00:00")]
        assert predict_next(n=3, entries=entries) == []

    def test_prediction_count(self):
        entries = _workflow_sequence([
            ("A", "2026-04-09 10:00:00"),
            ("B", "2026-04-09 10:01:00"),
            ("C", "2026-04-09 10:02:00"),
            ("A", "2026-04-09 10:03:00"),
        ])
        predictions = predict_next(
            n=2,
            now=datetime(2026, 4, 9, 10, 5),
            entries=entries,
        )
        assert len(predictions) <= 2

    def test_confidence_sorted_descending(self):
        entries = _workflow_sequence([
            ("A", "2026-04-09 10:00:00"),
            ("B", "2026-04-09 10:01:00"),
            ("A", "2026-04-09 10:02:00"),
            ("B", "2026-04-09 10:03:00"),
            ("A", "2026-04-09 10:04:00"),
            ("C", "2026-04-09 10:05:00"),
            ("A", "2026-04-09 10:06:00"),
        ])
        predictions = predict_next(
            n=3,
            now=datetime(2026, 4, 9, 10, 7),
            entries=entries,
        )
        if len(predictions) >= 2:
            assert predictions[0]["confidence"] >= predictions[1]["confidence"]

    def test_reasons_populated(self):
        entries = _workflow_sequence([
            ("heartbeat", "2026-04-09 10:00:00"),
            ("db_backup", "2026-04-09 10:05:00"),
            ("heartbeat", "2026-04-09 10:10:00"),
        ])
        predictions = predict_next(
            n=3,
            now=datetime(2026, 4, 9, 10, 15),
            entries=entries,
        )
        assert len(predictions) > 0
        # Top prediction should have reasons
        assert isinstance(predictions[0]["reasons"], list)


class TestLogPredictionAccuracy:
    def test_hit_when_predicted(self):
        predicted = [
            {"workflow": "heartbeat", "confidence": 0.9, "reasons": []},
            {"workflow": "db_backup", "confidence": 0.5, "reasons": []},
        ]
        result = log_prediction_accuracy(predicted, "heartbeat")
        assert result["hit"] is True
        assert result["rank"] == 1

    def test_miss_when_not_predicted(self):
        predicted = [
            {"workflow": "heartbeat", "confidence": 0.9, "reasons": []},
        ]
        result = log_prediction_accuracy(predicted, "unknown_workflow")
        assert result["hit"] is False
        assert result["rank"] is None

    def test_rank_2_hit(self):
        predicted = [
            {"workflow": "heartbeat", "confidence": 0.9, "reasons": []},
            {"workflow": "db_backup", "confidence": 0.5, "reasons": []},
        ]
        result = log_prediction_accuracy(predicted, "db_backup")
        assert result["hit"] is True
        assert result["rank"] == 2

    def test_empty_predictions(self):
        result = log_prediction_accuracy([], "heartbeat")
        assert result["hit"] is False
        assert result["predicted_top"] is None


class TestFormatPredictions:
    def test_empty(self):
        output = format_predictions([])
        assert "No predictions" in output

    def test_formatted_output(self):
        predictions = [
            {"workflow": "heartbeat", "confidence": 0.82, "reasons": ["follows 'db_backup' 90% of the time"]},
            {"workflow": "db_backup", "confidence": 0.45, "reasons": ["often runs around 10:00"]},
        ]
        output = format_predictions(predictions)
        assert "heartbeat" in output
        assert "db_backup" in output
        assert "82%" in output
        assert "45%" in output
