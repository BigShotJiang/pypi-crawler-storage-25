"""
Tests for aibrain/core/workflow_runner.py — workflow registry and harness integration.

Covers: WORKFLOW_REGISTRY metadata, task type classification, authority levels,
unknown workflow handling, run_workflow basic paths.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.workflow_runner import WORKFLOW_REGISTRY, WORKFLOW_DIR


# ---------------------------------------------------------------------------
# Registry structure
# ---------------------------------------------------------------------------

class TestWorkflowRegistry:
    def test_registry_is_dict(self):
        assert isinstance(WORKFLOW_REGISTRY, dict)

    def test_registry_has_entries(self):
        assert len(WORKFLOW_REGISTRY) > 20

    def test_all_entries_have_task_type(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            assert "task_type" in meta, f"{name} missing task_type"

    def test_all_entries_have_authority(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            assert "authority" in meta, f"{name} missing authority"

    def test_all_entries_have_max_cost(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            assert "max_cost" in meta, f"{name} missing max_cost"

    def test_max_cost_is_numeric(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            assert isinstance(meta["max_cost"], (int, float)), f"{name} max_cost not numeric"

    def test_max_cost_non_negative(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            assert meta["max_cost"] >= 0, f"{name} has negative max_cost"


# ---------------------------------------------------------------------------
# Task type classification
# ---------------------------------------------------------------------------

VALID_TASK_TYPES = {"deterministic", "simple", "judgment", "complex"}


class TestTaskTypes:
    def test_all_types_valid(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            assert meta["task_type"] in VALID_TASK_TYPES, \
                f"{name} has invalid task_type: {meta['task_type']}"

    def test_heartbeat_is_deterministic(self):
        assert WORKFLOW_REGISTRY["heartbeat"]["task_type"] == "deterministic"

    def test_db_backup_is_deterministic(self):
        assert WORKFLOW_REGISTRY["db_backup"]["task_type"] == "deterministic"

    def test_evolution_experiment_is_complex(self):
        assert WORKFLOW_REGISTRY["evolution_experiment"]["task_type"] == "complex"

    def test_cross_domain_is_judgment(self):
        assert WORKFLOW_REGISTRY["cross_domain_questions"]["task_type"] == "judgment"

    def test_deterministic_workflows_zero_cost(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            if meta["task_type"] == "deterministic":
                assert meta["max_cost"] == 0, \
                    f"Deterministic workflow {name} has non-zero max_cost"

    def test_has_at_least_one_of_each_type(self):
        types_present = {meta["task_type"] for meta in WORKFLOW_REGISTRY.values()}
        for t in VALID_TASK_TYPES:
            assert t in types_present, f"No workflow with task_type={t}"


# ---------------------------------------------------------------------------
# Authority levels
# ---------------------------------------------------------------------------

VALID_AUTHORITIES = {"read_only", "standard", "elevated", "admin"}


class TestAuthorityLevels:
    def test_all_authorities_valid(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            assert meta["authority"] in VALID_AUTHORITIES, \
                f"{name} has invalid authority: {meta['authority']}"

    def test_heartbeat_read_only(self):
        assert WORKFLOW_REGISTRY["heartbeat"]["authority"] == "read_only"

    def test_email_auto_reply_elevated(self):
        assert WORKFLOW_REGISTRY["email_auto_reply"]["authority"] == "elevated"

    def test_service_monitor_read_only(self):
        assert WORKFLOW_REGISTRY["service_monitor"]["authority"] == "read_only"

    def test_internal_workflows_marked(self):
        assert WORKFLOW_REGISTRY["service_monitor"].get("internal") is True
        assert WORKFLOW_REGISTRY["telegram_check"].get("internal") is True

    def test_has_read_only_workflows(self):
        read_only = [n for n, m in WORKFLOW_REGISTRY.items() if m["authority"] == "read_only"]
        assert len(read_only) >= 3

    def test_has_standard_workflows(self):
        standard = [n for n, m in WORKFLOW_REGISTRY.items() if m["authority"] == "standard"]
        assert len(standard) >= 5

    def test_has_elevated_workflows(self):
        elevated = [n for n, m in WORKFLOW_REGISTRY.items() if m["authority"] == "elevated"]
        assert len(elevated) >= 3


# ---------------------------------------------------------------------------
# Specific workflow entries
# ---------------------------------------------------------------------------

class TestSpecificWorkflows:
    def test_known_workflows_exist(self):
        expected = [
            "heartbeat", "db_backup", "telegram_check",
            "email_auto_reply", "daily_planner", "arxiv_tracker",
            "job_search_apply", "git_monitor",
        ]
        for name in expected:
            assert name in WORKFLOW_REGISTRY, f"Missing workflow: {name}"

    def test_job_search_is_judgment_elevated(self):
        meta = WORKFLOW_REGISTRY["job_search_apply"]
        assert meta["task_type"] == "judgment"
        assert meta["authority"] == "elevated"

    def test_code_review_is_complex_elevated(self):
        meta = WORKFLOW_REGISTRY["code_review_runner"]
        assert meta["task_type"] == "complex"
        assert meta["authority"] == "elevated"

    def test_risk_analyst_is_complex(self):
        meta = WORKFLOW_REGISTRY["risk_analyst"]
        assert meta["task_type"] == "complex"

    def test_memory_consolidation_is_judgment(self):
        meta = WORKFLOW_REGISTRY["memory_consolidation"]
        assert meta["task_type"] == "judgment"


# ---------------------------------------------------------------------------
# WORKFLOW_DIR
# ---------------------------------------------------------------------------

class TestWorkflowDir:
    def test_workflow_dir_is_path(self):
        assert isinstance(WORKFLOW_DIR, Path)

    def test_workflow_dir_name(self):
        assert WORKFLOW_DIR.name == "workflows"


# ---------------------------------------------------------------------------
# run_workflow — basic path tests (no actual workflow execution)
# ---------------------------------------------------------------------------

class TestRunWorkflowBasics:
    def test_unknown_workflow_returns_failure(self):
        from aibrain.core.workflow_runner import run_workflow
        result = run_workflow("totally_nonexistent_workflow_xyz")
        assert result.success is False
        assert "not found" in (result.error or "").lower()

    def test_unknown_workflow_has_error_message(self):
        from aibrain.core.workflow_runner import run_workflow
        result = run_workflow("does_not_exist_at_all")
        assert result.error is not None
        assert len(result.error) > 0


# ---------------------------------------------------------------------------
# Budget consistency
# ---------------------------------------------------------------------------

class TestBudgetConsistency:
    def test_simple_tasks_low_budget(self):
        for name, meta in WORKFLOW_REGISTRY.items():
            if meta["task_type"] == "simple":
                assert meta["max_cost"] <= 50, \
                    f"Simple workflow {name} has high budget: {meta['max_cost']}"

    def test_complex_tasks_higher_budget(self):
        complex_costs = [
            meta["max_cost"]
            for meta in WORKFLOW_REGISTRY.values()
            if meta["task_type"] == "complex"
        ]
        assert max(complex_costs) >= 200, "Complex tasks should have at least some high-budget entries"

    def test_read_only_not_elevated(self):
        """Read-only authority shouldn't have complex+elevated combos on read_only workflows."""
        for name, meta in WORKFLOW_REGISTRY.items():
            if meta["authority"] == "read_only":
                # Read-only workflows shouldn't have elevated authority
                assert meta["authority"] != "elevated"
