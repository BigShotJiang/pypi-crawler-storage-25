"""
Tests for the search/dedup/salience unification.

Covers:
1. Salience scoring function (various input combinations)
2. Unified dedup (vec table query, threshold behavior)
3. Brain.search() returns reason field
4. Brain.search() uses SelRoute (not bypassing)
5. Score breakdown structure
"""

import math
import os
import sqlite3
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure project root is on sys.path
AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AIBRAIN_ROOT))

import aibrain_db


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def temp_db():
    """Create a temporary DB for isolated testing."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_test_unify_")
    os.close(fd)

    # Point aibrain_db at temp DB
    old_path = aibrain_db.DB_PATH
    old_conn = aibrain_db._conn

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None
    db = aibrain_db.get_db()

    yield db

    # Restore
    if aibrain_db._conn is not None:
        try:
            aibrain_db._conn.close()
        except Exception:
            pass
    aibrain_db.DB_PATH = old_path
    aibrain_db._conn = old_conn

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in (".db-wal", ".db-shm"):
        try:
            os.unlink(path.replace(".db", ext))
        except OSError:
            pass


@pytest.fixture()
def seeded_db(temp_db):
    """Temp DB with a few test memories seeded."""
    db = temp_db
    memories = [
        ("python_pref", "user", "User prefers Python 3.11 for all new projects", "python,preference", 0.8),
        ("go_learning", "project", "Started learning Go for microservices", "go,learning", 0.5),
        ("meeting_notes", "project", "Meeting about API redesign on March 15th", "meeting,api", 0.6),
        ("coffee_pref", "user", "Decker drinks flat white, no sugar", "preference,coffee", 0.9),
        ("security_tool", "reference", "Wintermute scans for CVEs using SARIF output", "security,tool", 0.7),
    ]
    for name, mtype, content, tags, imp in memories:
        db.execute(
            "INSERT INTO memories (name, type, content, tags, importance, created, updated, active) "
            "VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)",
            (name, mtype, content, tags, imp),
        )
    db.commit()
    # Rebuild FTS index
    try:
        db.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
        db.commit()
    except Exception:
        pass
    return db


# ===========================================================================
# 1. Salience scoring function
# ===========================================================================

class TestSalienceScoring:
    """Test _salience_score with various input combinations."""

    def test_basic_salience_returns_tuple(self):
        """Salience function returns (float, dict) tuple."""
        score, breakdown = aibrain_db._salience_score(
            fts_score=0.8, vec_score=0.6, importance=0.7,
            access_count=5, updated_at="2026-04-07 12:00:00",
        )
        assert isinstance(score, float)
        assert isinstance(breakdown, dict)

    def test_breakdown_has_all_keys(self):
        """Breakdown dict contains all expected keys."""
        _, breakdown = aibrain_db._salience_score(
            fts_score=0.5, vec_score=0.5, importance=0.5,
            access_count=0, updated_at="2026-04-07 12:00:00",
        )
        expected_keys = {"fts", "vec", "importance", "retention", "retrieval_strength", "storage_strength", "reinforcement", "combined"}
        assert set(breakdown.keys()) == expected_keys

    def test_combined_equals_weighted_sum(self):
        """Combined score matches the documented formula."""
        fts, vec, imp = 1.0, 0.0, 0.5
        score, bd = aibrain_db._salience_score(
            fts_score=fts, vec_score=vec, importance=imp,
            access_count=0, updated_at="2026-04-07 12:00:00",
        )
        w = aibrain_db._DEFAULT_SALIENCE_WEIGHTS
        expected = (
            w["fts"] * fts + w["vec"] * vec + w["imp"] * imp
            + w["rec"] * bd["retention"] + w["acc"] * bd["reinforcement"]
        )
        assert abs(score - expected) < 0.001

    def test_higher_fts_increases_score(self):
        """Higher FTS score produces higher combined score."""
        score_low, _ = aibrain_db._salience_score(0.2, 0.5, 0.5, 0, "2026-04-07 12:00:00")
        score_high, _ = aibrain_db._salience_score(0.9, 0.5, 0.5, 0, "2026-04-07 12:00:00")
        assert score_high > score_low

    def test_higher_vec_increases_score(self):
        """Higher vec score produces higher combined score."""
        score_low, _ = aibrain_db._salience_score(0.5, 0.1, 0.5, 0, "2026-04-07 12:00:00")
        score_high, _ = aibrain_db._salience_score(0.5, 0.9, 0.5, 0, "2026-04-07 12:00:00")
        assert score_high > score_low

    def test_recency_decays_over_time(self):
        """More recent memories get higher recency scores."""
        now = datetime.now()
        recent = now.strftime("%Y-%m-%d %H:%M:%S")
        old = (now - timedelta(days=90)).strftime("%Y-%m-%d %H:%M:%S")

        _, bd_recent = aibrain_db._salience_score(0.5, 0.5, 0.5, 0, recent)
        _, bd_old = aibrain_db._salience_score(0.5, 0.5, 0.5, 0, old)

        assert bd_recent["retention"] > bd_old["retention"]

    def test_access_count_reinforcement(self):
        """Higher access count gives higher reinforcement."""
        score_low, _ = aibrain_db._salience_score(0.5, 0.5, 0.5, 0, "2026-04-07 12:00:00")
        score_high, _ = aibrain_db._salience_score(0.5, 0.5, 0.5, 100, "2026-04-07 12:00:00")
        assert score_high > score_low

    def test_custom_weights(self):
        """Custom weights override defaults."""
        custom = {"fts": 1.0, "vec": 0.0, "imp": 0.0, "rec": 0.0, "acc": 0.0}
        score, _ = aibrain_db._salience_score(
            0.8, 0.9, 1.0, 100, "2026-04-07 12:00:00", weights=custom,
        )
        # With only FTS weight, score should be exactly 0.8
        assert abs(score - 0.8) < 0.001

    def test_zero_inputs(self):
        """All-zero inputs produce near-zero score."""
        score, bd = aibrain_db._salience_score(0.0, 0.0, 0.0, 0, "")
        assert score >= 0.0
        assert bd["combined"] >= 0.0

    def test_invalid_date_doesnt_crash(self):
        """Invalid date string doesn't raise, retrieval_strength becomes 0."""
        score, bd = aibrain_db._salience_score(0.5, 0.5, 0.5, 0, "not-a-date")
        assert bd["retrieval_strength"] == 0.0


# ===========================================================================
# 2. Unified dedup
# ===========================================================================

class TestUnifiedDedup:
    """Test canonical_dedup function."""

    def test_canonical_dedup_no_vec_returns_none_without_name(self, temp_db):
        """Without embeddings and no name, returns None (no dedup possible)."""
        with patch.object(aibrain_db, '_db_vec_enabled', False):
            result = aibrain_db.canonical_dedup("some new content", name="")
            assert result is None

    def test_canonical_dedup_name_match_same_content(self, seeded_db):
        """Name dedup catches exact content match."""
        with patch.object(aibrain_db, '_db_vec_enabled', False):
            result = aibrain_db.canonical_dedup(
                "User prefers Python 3.11 for all new projects",
                name="python_pref",
            )
            assert result is not None
            assert result["action"] == "dedup"
            assert result["similarity"] == 1.0

    def test_canonical_dedup_name_match_different_content(self, seeded_db):
        """Same name, different content returns merge."""
        with patch.object(aibrain_db, '_db_vec_enabled', False):
            result = aibrain_db.canonical_dedup(
                "User now prefers Python 3.12",
                name="python_pref",
            )
            assert result is not None
            assert result["action"] == "merge"

    def test_canonical_dedup_no_match(self, seeded_db):
        """Completely new content/name returns None."""
        with patch.object(aibrain_db, '_db_vec_enabled', False):
            result = aibrain_db.canonical_dedup(
                "Brand new unique content xyz123",
                name="unique_name_xyz",
            )
            assert result is None

    def test_canonical_dedup_threshold_respected(self, temp_db):
        """Threshold parameter controls dedup sensitivity."""
        with patch.object(aibrain_db, '_db_vec_enabled', False):
            # With threshold=0.0, dedup is disabled (no embedding match possible
            # without vec, and name dedup still works)
            result = aibrain_db.canonical_dedup(
                "anything", name="nonexistent",
                threshold=0.0, merge_threshold=0.0,
            )
            assert result is None

    def test_name_dedup_returns_correct_id(self, seeded_db):
        """Name dedup returns the correct memory ID."""
        with patch.object(aibrain_db, '_db_vec_enabled', False):
            result = aibrain_db.canonical_dedup(
                "Decker drinks flat white, no sugar",
                name="coffee_pref",
            )
            assert result is not None
            assert result["id"] > 0


# ===========================================================================
# 3. Brain.search() returns reason field
# ===========================================================================

class TestBrainSearchReason:
    """Test that Brain.search() surfaces reason field from canonical search."""

    def test_search_results_have_reason(self, seeded_db):
        """Each search result dict contains a 'reason' key."""
        from aibrain.core.memory_api import Brain

        # Point Brain at our temp DB
        brain = Brain.__new__(Brain)
        brain._db = seeded_db

        results = aibrain_db.search_memories("Python projects", limit=5)
        # If we got results, they should all have reason
        for r in results:
            assert "reason" in r, f"Result missing 'reason' field: {r.keys()}"
            assert isinstance(r["reason"], str)
            assert len(r["reason"]) > 0

    def test_brain_search_surfaces_reason(self, seeded_db):
        """Brain.search() includes reason in output dicts."""
        from aibrain.core.memory_api import Brain

        brain = Brain.__new__(Brain)
        brain._db = seeded_db

        results = brain.search("Python")
        for r in results:
            assert "reason" in r
            assert isinstance(r["reason"], str)


# ===========================================================================
# 4. Brain.search() uses SelRoute (not bypassing)
# ===========================================================================

class TestBrainUsesSelRoute:
    """Verify Brain.search() delegates to canonical search_memories."""

    def test_brain_search_calls_search_memories(self, seeded_db):
        """Brain.search() calls aibrain_db.search_memories, not vec directly."""
        from aibrain.core.memory_api import Brain

        brain = Brain.__new__(Brain)
        brain._db = seeded_db

        with patch.object(aibrain_db, 'search_memories', wraps=aibrain_db.search_memories) as mock_search:
            brain.search("Python")
            assert mock_search.called, "Brain.search() should delegate to search_memories()"

    def test_brain_search_does_not_call_vec_similarity_directly(self, seeded_db):
        """Brain.search() should NOT bypass SelRoute by calling _vec_similarity directly."""
        from aibrain.core.memory_api import Brain
        from aibrain.core import memory_api

        brain = Brain.__new__(Brain)
        brain._db = seeded_db

        with patch.object(memory_api, '_vec_similarity', side_effect=AssertionError("Should not be called")) as mock_vec:
            # Should succeed without calling _vec_similarity
            try:
                brain.search("Python")
            except AssertionError:
                pytest.fail("Brain.search() still calls _vec_similarity directly instead of using SelRoute")


# ===========================================================================
# 5. Score breakdown structure
# ===========================================================================

class TestScoreBreakdown:
    """Test score_breakdown is present and correctly structured."""

    def test_search_results_have_score_breakdown(self, seeded_db):
        """search_memories returns score_breakdown dict on each result."""
        results = aibrain_db.search_memories("Python", limit=5)
        for r in results:
            assert "score_breakdown" in r
            bd = r["score_breakdown"]
            assert isinstance(bd, dict)
            expected_keys = {"fts", "vec", "importance", "retention", "retrieval_strength", "storage_strength", "reinforcement", "combined"}
            assert set(bd.keys()) == expected_keys

    def test_breakdown_values_are_numeric(self, seeded_db):
        """All breakdown values are floats/ints."""
        results = aibrain_db.search_memories("coffee", limit=5)
        for r in results:
            bd = r["score_breakdown"]
            for key, val in bd.items():
                assert isinstance(val, (int, float)), f"{key} is {type(val)}, expected numeric"

    def test_brain_search_has_score_breakdown(self, seeded_db):
        """Brain.search() result dicts include score_breakdown."""
        from aibrain.core.memory_api import Brain

        brain = Brain.__new__(Brain)
        brain._db = seeded_db

        results = brain.search("coffee")
        for r in results:
            assert "score_breakdown" in r
            assert isinstance(r["score_breakdown"], dict)

    def test_combined_score_is_nonnegative(self, seeded_db):
        """Combined score should always be >= 0."""
        results = aibrain_db.search_memories("security", limit=5)
        for r in results:
            assert r["score_breakdown"]["combined"] >= 0


# ===========================================================================
# 6. Helper function tests (fusion, routing)
# ===========================================================================

class TestFusionHelpers:
    """Test the ported fusion strategy functions."""

    def test_rrf_fuse_basic(self):
        """RRF fusion produces combined list."""
        list1 = [{"id": 1}, {"id": 2}, {"id": 3}]
        list2 = [{"id": 2}, {"id": 3}, {"id": 4}]
        result = aibrain_db._rrf_fuse([list1, list2])
        ids = [r["id"] for r in result]
        assert 2 in ids
        assert 3 in ids
        # Items in both lists should rank higher
        assert ids.index(2) < ids.index(4)

    def test_interleave_fuse_round_robin(self):
        """Interleave takes one from each list alternately."""
        list1 = [{"id": 1}, {"id": 2}]
        list2 = [{"id": 3}, {"id": 4}]
        result = aibrain_db._interleave_fuse([list1, list2])
        ids = [r["id"] for r in result]
        assert ids == [1, 3, 2, 4]

    def test_consensus_rerank_multi_method(self):
        """Items found by more methods rank higher in consensus."""
        list1 = [{"id": 1}, {"id": 2}]
        list2 = [{"id": 2}, {"id": 3}]
        list3 = [{"id": 2}, {"id": 1}]
        result = aibrain_db._consensus_rerank([list1, list2, list3])
        ids = [r["id"] for r in result]
        assert ids[0] == 2  # Found by all 3 methods

    def test_get_routing_table_default_minilm(self):
        """Default routing table is MiniLM."""
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("AIBRAIN_EMBEDDING_MODEL", None)
            table = aibrain_db._get_routing_table()
            assert table == aibrain_db._ROUTING_TABLE_MINILM

    def test_get_routing_table_bge(self):
        """bge-base model selects BGE routing table."""
        with patch.dict(os.environ, {"AIBRAIN_EMBEDDING_MODEL": "BAAI/bge-base-en-v1.5"}):
            table = aibrain_db._get_routing_table()
            assert table == aibrain_db._ROUTING_TABLE_BGE_BASE

    def test_extract_date_filter_yesterday(self):
        """Date filter extracts 'yesterday' correctly."""
        cleaned, date_from, date_to = aibrain_db._extract_date_filter("what happened yesterday")
        assert date_from is not None
        assert date_to is not None
        assert "yesterday" not in cleaned

    def test_extract_date_filter_iso(self):
        """Date filter extracts ISO dates."""
        cleaned, date_from, date_to = aibrain_db._extract_date_filter("events on 2026-03-20")
        assert date_from == "2026-03-20 00:00:00"
        assert date_to == "2026-03-20 23:59:59"

    def test_prepare_fts_query_filters_stopwords(self):
        """FTS query preparation removes stop words."""
        result = aibrain_db._prepare_fts_query("what is the best way to do it")
        assert "the" not in result.split(" OR ")
        assert "best" in result or "way" in result


class TestClassifyQuery:
    """Test query classification."""

    def test_temporal_classification(self):
        assert aibrain_db.classify_query("what happened last week") == "temporal"

    def test_preference_classification(self):
        assert aibrain_db.classify_query("do i prefer Python or Go") == "preference"

    def test_factual_default(self):
        assert aibrain_db.classify_query("what port does PostgREST use") == "factual"

    def test_knowledge_update(self):
        assert aibrain_db.classify_query("what changed to the API endpoint") == "knowledge_update"

    def test_ss_user(self):
        assert aibrain_db.classify_query("did i say anything about docker") == "ss_user"
