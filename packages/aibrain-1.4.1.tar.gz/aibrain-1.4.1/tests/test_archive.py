"""
Tests for aibrain/core/archive.py — Smart archive system.

Covers: archive_item, restore_item, record_access, purge_expired, list_archived.

Uses tmp_path for file operations and a temporary SQLite DB for isolation.
"""

import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def archive_env(tmp_path):
    """Set up isolated archive environment: temp DB, archive dir, and patches."""
    db_path = tmp_path / "test_archive.db"
    archive_dir = tmp_path / "archive"
    archive_dir.mkdir()

    # Pre-create the archive_items table so _get_db finds it
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS archive_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_path TEXT NOT NULL,
            archive_path TEXT NOT NULL,
            reason TEXT,
            archived_by TEXT DEFAULT 'system',
            archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            access_count INTEGER DEFAULT 0,
            last_accessed_at TIMESTAMP,
            last_access_reason TEXT,
            status TEXT DEFAULT 'archived' CHECK(status IN ('archived','restored','purged')),
            notified INTEGER DEFAULT 0
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_archive_status ON archive_items(status)")
    conn.commit()
    conn.close()

    def _patched_get_db():
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        # Table already exists, but _get_db in archive.py also tries to create it
        db.execute("""
            CREATE TABLE IF NOT EXISTS archive_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_path TEXT NOT NULL,
                archive_path TEXT NOT NULL,
                reason TEXT,
                archived_by TEXT DEFAULT 'system',
                archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                access_count INTEGER DEFAULT 0,
                last_accessed_at TIMESTAMP,
                last_access_reason TEXT,
                status TEXT DEFAULT 'archived' CHECK(status IN ('archived','restored','purged')),
                notified INTEGER DEFAULT 0
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_archive_status ON archive_items(status)")
        db.commit()
        return db

    with patch("aibrain.core.archive._get_db", _patched_get_db), \
         patch("aibrain.core.archive.ARCHIVE_DIR", archive_dir):
        yield {
            "db_path": db_path,
            "archive_dir": archive_dir,
            "tmp_path": tmp_path,
        }


def _create_test_file(tmp_path, name="testfile.txt", content="hello world"):
    """Create a temp file and return its path."""
    f = tmp_path / name
    f.write_text(content)
    return str(f)


# ---------------------------------------------------------------------------
# archive_item
# ---------------------------------------------------------------------------


class TestArchiveItem:

    def test_archive_file(self, archive_env):
        from aibrain.core.archive import archive_item
        filepath = _create_test_file(archive_env["tmp_path"])
        result = archive_item(filepath, reason="Replaced by new version")
        assert result["status"] == "archived"
        assert result["hold_days"] == 30
        assert "archive" in result
        assert "expires" in result
        # Original file should be gone
        assert not Path(filepath).exists()

    def test_archive_nonexistent_path(self, archive_env):
        from aibrain.core.archive import archive_item
        result = archive_item("/nonexistent/path/file.txt")
        assert "error" in result

    def test_archive_directory(self, archive_env):
        from aibrain.core.archive import archive_item
        d = archive_env["tmp_path"] / "test_dir"
        d.mkdir()
        (d / "inner.txt").write_text("inner content")
        result = archive_item(str(d), reason="Directory test")
        assert result["status"] == "archived"
        assert not d.exists()

    def test_force_delete(self, archive_env):
        from aibrain.core.archive import archive_item
        filepath = _create_test_file(archive_env["tmp_path"], "force_del.txt")
        result = archive_item(filepath, reason="Not needed", force_delete=True)
        assert result["status"] == "force_deleted"
        assert not Path(filepath).exists()

    def test_custom_hold_days(self, archive_env):
        from aibrain.core.archive import archive_item
        filepath = _create_test_file(archive_env["tmp_path"], "custom_hold.txt")
        result = archive_item(filepath, hold_days=7)
        assert result["hold_days"] == 7

    def test_archived_by_tracked(self, archive_env):
        from aibrain.core.archive import archive_item
        filepath = _create_test_file(archive_env["tmp_path"], "tracked.txt")
        archive_item(filepath, archived_by="neuro")

        db = sqlite3.connect(str(archive_env["db_path"]))
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT archived_by FROM archive_items ORDER BY id DESC LIMIT 1").fetchone()
        db.close()
        assert row["archived_by"] == "neuro"


# ---------------------------------------------------------------------------
# restore_item
# ---------------------------------------------------------------------------


class TestRestoreItem:

    def test_restore_archived_file(self, archive_env):
        from aibrain.core.archive import archive_item, restore_item
        filepath = _create_test_file(archive_env["tmp_path"], "restore_me.txt", "restore content")
        archive_item(filepath, reason="Temp archive")
        assert not Path(filepath).exists()

        result = restore_item(filepath)
        assert result["status"] == "restored"
        assert Path(filepath).exists()
        assert Path(filepath).read_text() == "restore content"

    def test_restore_nonexistent_archive(self, archive_env):
        from aibrain.core.archive import restore_item
        result = restore_item("/never/archived/file.txt")
        assert "error" in result

    def test_restore_updates_db_status(self, archive_env):
        from aibrain.core.archive import archive_item, restore_item
        filepath = _create_test_file(archive_env["tmp_path"], "db_restore.txt")
        archive_item(filepath)
        restore_item(filepath)

        db = sqlite3.connect(str(archive_env["db_path"]))
        db.row_factory = sqlite3.Row
        row = db.execute(
            "SELECT status FROM archive_items WHERE original_path=? ORDER BY id DESC LIMIT 1",
            (filepath,)
        ).fetchone()
        db.close()
        assert row["status"] == "restored"


# ---------------------------------------------------------------------------
# record_access
# ---------------------------------------------------------------------------


class TestRecordAccess:

    def test_record_access_resets_timer(self, archive_env):
        from aibrain.core.archive import archive_item, record_access
        filepath = _create_test_file(archive_env["tmp_path"], "access_me.txt")
        archive_item(filepath, reason="testing access")

        result = record_access(filepath, access_reason="imported in code")
        assert result is not None
        assert result["timer_reset"] is True
        assert result["access_count"] == 1
        assert "warning" in result

    def test_record_access_increments_count(self, archive_env):
        from aibrain.core.archive import archive_item, record_access
        filepath = _create_test_file(archive_env["tmp_path"], "multi_access.txt")
        archive_item(filepath)

        record_access(filepath, "first")
        result = record_access(filepath, "second")
        assert result["access_count"] == 2

    def test_record_access_nonexistent(self, archive_env):
        from aibrain.core.archive import record_access
        result = record_access("/not/archived/at/all.txt")
        assert result is None


# ---------------------------------------------------------------------------
# purge_expired
# ---------------------------------------------------------------------------


class TestPurgeExpired:

    def test_purge_removes_expired(self, archive_env):
        from aibrain.core.archive import archive_item, purge_expired
        filepath = _create_test_file(archive_env["tmp_path"], "expire_me.txt")
        result = archive_item(filepath, hold_days=0)  # expires immediately

        # Manually backdate the expiry
        db = sqlite3.connect(str(archive_env["db_path"]))
        db.execute(
            "UPDATE archive_items SET expires_at=datetime('now', '-1 day') WHERE original_path=?",
            (filepath,)
        )
        db.commit()
        db.close()

        purge_result = purge_expired()
        assert purge_result["purged"] >= 1

    def test_purge_leaves_unexpired(self, archive_env):
        from aibrain.core.archive import archive_item, purge_expired
        filepath = _create_test_file(archive_env["tmp_path"], "not_expired.txt")
        archive_item(filepath, hold_days=30)

        purge_result = purge_expired()
        # Should not purge items expiring in the future
        db = sqlite3.connect(str(archive_env["db_path"]))
        active = db.execute(
            "SELECT COUNT(*) FROM archive_items WHERE status='archived' AND original_path=?",
            (filepath,)
        ).fetchone()[0]
        db.close()
        assert active == 1


# ---------------------------------------------------------------------------
# list_archived
# ---------------------------------------------------------------------------


class TestListArchived:

    def test_list_empty(self, archive_env):
        from aibrain.core.archive import list_archived
        result = list_archived()
        assert isinstance(result, list)

    def test_list_returns_archived_items(self, archive_env):
        from aibrain.core.archive import archive_item, list_archived
        f1 = _create_test_file(archive_env["tmp_path"], "list1.txt")
        f2 = _create_test_file(archive_env["tmp_path"], "list2.txt")
        archive_item(f1, reason="Reason A")
        archive_item(f2, reason="Reason B")

        items = list_archived()
        assert len(items) >= 2
        paths = [i["original_path"] for i in items]
        assert f1 in paths
        assert f2 in paths
