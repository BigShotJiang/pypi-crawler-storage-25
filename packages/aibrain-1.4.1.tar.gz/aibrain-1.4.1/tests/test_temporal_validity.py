"""
Tests for temporal fact validity — valid_from, valid_until, stale flagging.
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def db_env():
    """Create a fresh, isolated SQLite DB with the full AIBrain schema."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_temporal_")
    os.close(fd)

    import aibrain_db
    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None

    conn = aibrain_db.get_db()

    yield conn, aibrain_db

    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path

    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


class TestTemporalColumns:
    """Verify valid_from and valid_until columns exist after migration."""

    def test_valid_from_column_exists(self, db_env):
        """valid_from column is present in memories table."""
        conn, _ = db_env
        cols = {r[1] for r in conn.execute("PRAGMA table_info(memories)").fetchall()}
        assert "valid_from" in cols

    def test_valid_until_column_exists(self, db_env):
        """valid_until column is present in memories table."""
        conn, _ = db_env
        cols = {r[1] for r in conn.execute("PRAGMA table_info(memories)").fetchall()}
        assert "valid_until" in cols

    def test_new_memory_gets_valid_from(self, db_env):
        """New memories get valid_from set to creation time."""
        conn, aibrain_db = db_env
        mem_id = aibrain_db.create_memory(
            "test temporal", "project", "temporal test content",
            dedup_threshold=0.0,
        )
        row = conn.execute(
            "SELECT valid_from, valid_until FROM memories WHERE id=?", (mem_id,)
        ).fetchone()
        assert row is not None
        assert row["valid_from"] is not None  # Should be set
        assert row["valid_until"] is None  # Not superseded yet

    def test_valid_until_null_by_default(self, db_env):
        """valid_until is NULL for active memories."""
        conn, aibrain_db = db_env
        mem_id = aibrain_db.create_memory(
            "active fact", "project", "this fact is current",
            dedup_threshold=0.0,
        )
        row = conn.execute(
            "SELECT valid_until FROM memories WHERE id=?", (mem_id,)
        ).fetchone()
        assert row["valid_until"] is None


class TestSupersedeSetsValidUntil:
    """When a memory is superseded, valid_until should be set."""

    def test_superseded_memory_gets_valid_until(self, db_env):
        """Directly setting status=superseded also sets valid_until."""
        conn, aibrain_db = db_env
        mem_id = aibrain_db.create_memory(
            "old fact", "project", "Stripe webhook is broken",
            dedup_threshold=0.0,
        )
        # Simulate supersede
        conn.execute(
            "UPDATE memories SET status='superseded', "
            "valid_until=datetime('now') WHERE id=?",
            (mem_id,),
        )
        conn.commit()
        row = conn.execute(
            "SELECT status, valid_until FROM memories WHERE id=?", (mem_id,)
        ).fetchone()
        assert row["status"] == "superseded"
        assert row["valid_until"] is not None


class TestStaleFlag:
    """Search results should flag stale/superseded memories."""

    def test_stale_flag_on_superseded(self, db_env):
        """Memories with valid_until set get stale=True in search results."""
        conn, aibrain_db = db_env
        # Create and immediately supersede
        mem_id = aibrain_db.create_memory(
            "webhook broken", "project", "The Stripe webhook is broken and needs fix",
            dedup_threshold=0.0,
        )
        conn.execute(
            "UPDATE memories SET valid_until=datetime('now'), status='active' WHERE id=?",
            (mem_id,),
        )
        conn.commit()
        # Search — need to use search_memories with fts
        results = aibrain_db.search_memories("webhook broken", limit=5)
        found = [r for r in results if r["id"] == mem_id]
        if found:
            assert found[0].get("stale") is True
            assert "STALE" in found[0].get("reason", "")

    def test_active_memory_not_stale(self, db_env):
        """Active memories (no valid_until) are not flagged stale."""
        conn, aibrain_db = db_env
        mem_id = aibrain_db.create_memory(
            "webhook fixed", "project", "The Stripe webhook is now working correctly",
            dedup_threshold=0.0,
        )
        results = aibrain_db.search_memories("webhook fixed", limit=5)
        found = [r for r in results if r["id"] == mem_id]
        if found:
            assert found[0].get("stale") is False
