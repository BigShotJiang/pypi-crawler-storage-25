"""
Tests for HARD RULE enforcement system.

Tests cover:
  1. Credential detection in diffs
  2. Co-Authored-By blocking
  3. Repo separation (sindecker vs DeckerOps)
  4. Archive-before-delete rule
  5. Communications approval
  6. Spend approval
  7. Browser process kill blocking
  8. Verify before irreversible (warning)
  9. Rule loading from DB
  10. Rule loading from .md files
  11. Enforcement wired into harness
  12. No false positives on safe content
  13. Scan staged content convenience function
  14. EnforcementViolation exception
"""

import os
import sqlite3
import tempfile
from pathlib import Path

import pytest

# Ensure project root is importable
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.enforcement import (
    BUILTIN_RULES,
    EnforcementResult,
    EnforcementViolation,
    HardRule,
    Violation,
    check_archive_before_delete,
    check_comms_approval,
    check_never_kill_browser,
    check_no_co_author,
    check_no_credentials,
    check_repo_separation,
    check_spend_approval,
    check_verify_before_irreversible,
    clear_cache,
    enforce,
    enforce_or_raise,
    load_rules,
    scan_staged_content,
    _parse_memory_to_rule,
    _load_rules_from_db,
    _load_rules_from_files,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clear_rule_cache():
    """Clear cached rules before each test."""
    clear_cache()
    yield
    clear_cache()


@pytest.fixture
def tmp_db(tmp_path):
    """Create a temporary DB with memories table and some HARD RULE memories."""
    db_path = tmp_path / "test.db"
    db = sqlite3.connect(str(db_path))
    db.execute("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            content TEXT DEFAULT '',
            status VARCHAR(20) DEFAULT 'active'
        )
    """)
    db.executemany(
        "INSERT INTO memories (name, content, status) VALUES (?, ?, 'active')",
        [
            ("feedback_no_creds_to_git",
             "HARD RULE: Never commit credentials (API keys, tokens, passwords) to any git repository. EVER."),
            ("feedback_never_delete_files",
             "HARD RULE: NEVER delete files directly. Move to archive first."),
            ("feedback_git_repo_separation",
             "HARD RULE: DeckerOps is for all internal code, sindecker is for public artifacts only."),
            ("some_unrelated_memory",
             "This is just a regular memory about project setup."),
        ],
    )
    db.commit()
    db.close()
    return db_path


@pytest.fixture
def tmp_memory_dir(tmp_path):
    """Create temporary .md memory files."""
    mem_dir = tmp_path / "memory"
    mem_dir.mkdir()

    (mem_dir / "feedback_no_creds.md").write_text(
        "HARD RULE: Never commit credentials to git. API keys, tokens, passwords.",
        encoding="utf-8",
    )
    (mem_dir / "feedback_archive_first.md").write_text(
        "HARD RULE: NEVER delete files. Archive first, 48hr hold.",
        encoding="utf-8",
    )
    (mem_dir / "feedback_unrelated.md").write_text(
        "Always double-check URLs before posting.",
        encoding="utf-8",
    )
    return mem_dir


# ---------------------------------------------------------------------------
# Test 1: Credential detection
# ---------------------------------------------------------------------------

class TestCredentialDetection:
    def test_detects_aws_key(self):
        diff = 'AKIAIOSFODNN7REALKEY01'
        violations = check_no_credentials({"diff": diff})
        assert len(violations) >= 1
        assert any("AWS" in v.message for v in violations)

    def test_detects_github_pat(self):
        diff = 'token = "ghp_1234567890abcdefghijklmnopqrstuvwxyz12"'  # noqa:HARDCODED SECRET
        violations = check_no_credentials({"diff": diff})
        assert len(violations) >= 1
        assert any("GitHub" in v.message for v in violations)

    def test_detects_telegram_token(self):
        diff = 'TELEGRAM_TOKEN = "123456789:ABCDefGHIJKlmnopqRSTUVwxyz0123456789"'
        violations = check_no_credentials({"diff": diff})
        assert len(violations) >= 1

    def test_detects_private_key(self):
        diff = "-----BEGIN RSA PRIVATE KEY-----\nMIIE..."
        violations = check_no_credentials({"diff": diff})
        assert len(violations) >= 1
        assert any("Private key" in v.message for v in violations)

    def test_detects_hardcoded_password(self):
        diff = 'password = "SuperSecret123!"'  # noqa:HARDCODED SECRET
        violations = check_no_credentials({"diff": diff})
        assert len(violations) >= 1

    def test_detects_connection_string(self):
        diff = 'db_url = "postgres://admin:secretpass@localhost:5432/mydb"'
        violations = check_no_credentials({"diff": diff})
        assert len(violations) >= 1

    def test_ignores_placeholder(self):
        diff = 'api_key = "your_api_key_here"'  # noqa:HARDCODED SECRET
        violations = check_no_credentials({"diff": diff})
        assert len(violations) == 0

    def test_ignores_env_get(self):
        diff = 'token = os.environ.get("GITHUB_PAT")'
        violations = check_no_credentials({"diff": diff})
        assert len(violations) == 0

    def test_ignores_example_values(self):
        diff = 'secret_key = "example_key_for_docs_1234567890"'
        violations = check_no_credentials({"diff": diff})
        assert len(violations) == 0

    def test_no_false_positive_on_clean_code(self):
        diff = """
def calculate_total(items):
    return sum(item.price for item in items)

class UserManager:
    def get_user(self, user_id):
        return self.db.query(User).filter_by(id=user_id).first()
"""
        violations = check_no_credentials({"diff": diff})
        assert len(violations) == 0


# ---------------------------------------------------------------------------
# Test 2: Co-Authored-By blocking
# ---------------------------------------------------------------------------

class TestCoAuthorBlocking:
    def test_blocks_claude_co_author(self):
        msg = "Fix bug\n\nCo-Authored-By: Claude <noreply@anthropic.com>"
        violations = check_no_co_author({"message": msg})
        assert len(violations) == 1
        assert "Co-Authored-By" in violations[0].message

    def test_blocks_anthropic_co_author(self):
        msg = "Add feature\n\nCo-Authored-By: Anthropic AI <ai@anthropic.com>"
        violations = check_no_co_author({"message": msg})
        assert len(violations) == 1

    def test_allows_human_co_author(self):
        msg = "Fix bug\n\nCo-Authored-By: John Doe <john@example.com>"
        violations = check_no_co_author({"message": msg})
        assert len(violations) == 0

    def test_allows_no_co_author(self):
        msg = "Simple commit message"
        violations = check_no_co_author({"message": msg})
        assert len(violations) == 0


# ---------------------------------------------------------------------------
# Test 3: Repo separation
# ---------------------------------------------------------------------------

class TestRepoSeparation:
    def test_blocks_internal_code_to_sindecker(self):
        violations = check_repo_separation({
            "remote": "https://github.com/sindecker/some-repo",
            "content": "from aibrain.core import harness",
            "files": ["main.py"],
        })
        assert len(violations) >= 1
        assert any("sindecker" in v.message.lower() for v in violations)

    def test_allows_deckerops_push(self):
        violations = check_repo_separation({
            "remote": "https://github.com/DeckerOps/aibrain",
            "content": "from aibrain.core import harness",
            "files": ["main.py"],
        })
        assert len(violations) == 0

    def test_allows_sindecker_public_artifact(self):
        violations = check_repo_separation({
            "remote": "https://github.com/sindecker/selroute",
            "content": "This is a public paper about routing.",
            "files": ["paper.pdf", "README.md"],
        })
        assert len(violations) == 0

    def test_blocks_wintermute_to_sindecker(self):
        violations = check_repo_separation({
            "remote": "https://github.com/sindecker/oops",
            "content": "import wintermute",
            "files": ["scanner.py"],
        })
        assert len(violations) >= 1


# ---------------------------------------------------------------------------
# Test 4: Archive before delete
# ---------------------------------------------------------------------------

class TestArchiveBeforeDelete:
    def test_blocks_rm_without_archive(self):
        violations = check_archive_before_delete({
            "command": "rm -f important.txt",
            "action": "delete",
            "archived": False,
        })
        assert len(violations) == 1
        assert "archiv" in violations[0].message.lower()

    def test_allows_delete_after_archive(self):
        violations = check_archive_before_delete({
            "command": "rm old_backup.txt",
            "action": "delete",
            "archived": True,
        })
        assert len(violations) == 0

    def test_blocks_python_os_remove(self):
        violations = check_archive_before_delete({
            "command": "os.remove('/path/to/file')",
            "action": "delete",
            "archived": False,
        })
        assert len(violations) == 1

    def test_ignores_non_delete(self):
        violations = check_archive_before_delete({
            "command": "cp file1.txt file2.txt",
            "action": "copy",
            "archived": False,
        })
        assert len(violations) == 0


# ---------------------------------------------------------------------------
# Test 5: Communications approval
# ---------------------------------------------------------------------------

class TestCommsApproval:
    def test_blocks_unapproved_linkedin(self):
        violations = check_comms_approval({
            "content_type": "linkedin",
            "comms_approved": False,
        })
        assert len(violations) == 1

    def test_allows_approved_post(self):
        violations = check_comms_approval({
            "content_type": "twitter",
            "comms_approved": True,
        })
        assert len(violations) == 0

    def test_ignores_internal_content(self):
        violations = check_comms_approval({
            "content_type": "internal_doc",
            "comms_approved": False,
        })
        assert len(violations) == 0


# ---------------------------------------------------------------------------
# Test 6: Spend approval
# ---------------------------------------------------------------------------

class TestSpendApproval:
    def test_blocks_unapproved_spend(self):
        violations = check_spend_approval({
            "amount": 50.0,
            "decker_approved": False,
        })
        assert len(violations) == 1
        assert "$50" in violations[0].message

    def test_allows_approved_spend(self):
        violations = check_spend_approval({
            "amount": 100.0,
            "decker_approved": True,
        })
        assert len(violations) == 0

    def test_allows_zero_spend(self):
        violations = check_spend_approval({
            "amount": 0,
            "decker_approved": False,
        })
        assert len(violations) == 0


# ---------------------------------------------------------------------------
# Test 7: Browser process kill blocking
# ---------------------------------------------------------------------------

class TestBrowserKillBlocking:
    def test_blocks_taskkill_chrome(self):
        violations = check_never_kill_browser({
            "command": "taskkill /F /IM chrome.exe",
        })
        assert len(violations) == 1

    def test_blocks_kill_edge(self):
        violations = check_never_kill_browser({
            "command": "taskkill //F //IM msedge.exe",
        })
        assert len(violations) == 1

    def test_allows_kill_other_process(self):
        violations = check_never_kill_browser({
            "command": "taskkill /F /IM python.exe",
        })
        assert len(violations) == 0

    def test_allows_non_kill_command(self):
        violations = check_never_kill_browser({
            "command": "start chrome.exe",
        })
        assert len(violations) == 0


# ---------------------------------------------------------------------------
# Test 8: Verify before irreversible (warning)
# ---------------------------------------------------------------------------

class TestVerifyBeforeIrreversible:
    def test_warns_on_unverified_publish(self):
        violations = check_verify_before_irreversible({
            "action": "publish",
            "verified": False,
        })
        assert len(violations) == 1
        assert violations[0].severity == "warn"

    def test_no_warn_when_verified(self):
        violations = check_verify_before_irreversible({
            "action": "publish",
            "verified": True,
        })
        assert len(violations) == 0

    def test_no_warn_for_safe_action(self):
        violations = check_verify_before_irreversible({
            "action": "read_file",
            "verified": False,
        })
        assert len(violations) == 0


# ---------------------------------------------------------------------------
# Test 9: Rule loading from DB
# ---------------------------------------------------------------------------

class TestRuleLoadingDB:
    def test_loads_rules_from_db(self, tmp_db):
        rules = _load_rules_from_db(tmp_db)
        assert len(rules) >= 2  # creds + delete + repo separation
        rule_ids = {r.rule_id for r in rules}
        # Should have mapped the HARD RULE memories
        assert any("creds" in rid or "credential" in rid for rid in rule_ids)

    def test_skips_unrelated_memories(self, tmp_db):
        rules = _load_rules_from_db(tmp_db)
        # "some_unrelated_memory" should not be parsed into a rule
        assert not any("unrelated" in r.memory_name for r in rules)


# ---------------------------------------------------------------------------
# Test 10: Rule loading from .md files
# ---------------------------------------------------------------------------

class TestRuleLoadingFiles:
    def test_loads_rules_from_md_files(self, tmp_memory_dir):
        rules = _load_rules_from_files(tmp_memory_dir)
        assert len(rules) >= 2  # creds + archive

    def test_skips_non_hard_rule_files(self, tmp_memory_dir):
        rules = _load_rules_from_files(tmp_memory_dir)
        # "feedback_unrelated.md" has NEVER in upper but not in original
        # It says "Always double-check" — no HARD RULE or NEVER
        rule_names = [r.name for r in rules]
        assert not any("unrelated" in n for n in rule_names)


# ---------------------------------------------------------------------------
# Test 11: Full enforcement pipeline
# ---------------------------------------------------------------------------

class TestEnforcementPipeline:
    def test_enforce_blocks_credential(self):
        result = enforce("pre_commit", {
            "diff": 'API_KEY = "AKIAIOSFODNN7REALKEY01"',
            "content": 'API_KEY = "AKIAIOSFODNN7REALKEY01"',
            "files": [],
        }, rules=BUILTIN_RULES)
        assert not result.passed
        assert len(result.violations) >= 1

    def test_enforce_passes_clean_commit(self):
        result = enforce("pre_commit", {
            "diff": "def hello():\n    return 'world'\n",
            "content": "def hello():\n    return 'world'\n",
            "message": "Add hello function",
            "files": ["main.py"],
        }, rules=BUILTIN_RULES)
        assert result.passed
        assert len(result.violations) == 0

    def test_enforce_or_raise_throws(self):
        with pytest.raises(EnforcementViolation) as exc_info:
            enforce_or_raise("pre_commit", {
                "diff": 'ghp_1234567890abcdefghijklmnopqrstuvwxyz12',
                "content": 'ghp_1234567890abcdefghijklmnopqrstuvwxyz12',
                "files": [],
            }, rules=BUILTIN_RULES)
        assert len(exc_info.value.violations) >= 1


# ---------------------------------------------------------------------------
# Test 12: No false positives on safe content
# ---------------------------------------------------------------------------

class TestNoFalsePositives:
    def test_clean_python_code(self):
        diff = """
import os
from pathlib import Path

def process_data(input_path: str) -> dict:
    data = Path(input_path).read_text()
    token_count = len(data.split())
    return {"tokens": token_count, "path": input_path}
"""
        result = enforce("pre_commit", {
            "diff": diff,
            "content": diff,
            "message": "Add data processor",
            "files": ["processor.py"],
        }, rules=BUILTIN_RULES)
        assert result.passed

    def test_env_var_references_safe(self):
        diff = '''
api_key = os.environ.get("API_KEY")
token = os.getenv("GITHUB_TOKEN", "")
'''
        result = enforce("pre_commit", {
            "diff": diff,
            "content": diff,
            "files": ["config.py"],
        }, rules=BUILTIN_RULES)
        assert result.passed


# ---------------------------------------------------------------------------
# Test 13: scan_staged_content convenience
# ---------------------------------------------------------------------------

class TestScanStagedContent:
    def test_scan_finds_secrets(self):
        diff = 'secret_key = "-----BEGIN RSA PRIVATE KEY-----"'
        result = scan_staged_content(diff)
        assert not result.passed

    def test_scan_passes_clean(self):
        diff = "x = 1 + 2\nprint(x)\n"
        result = scan_staged_content(diff)
        assert result.passed


# ---------------------------------------------------------------------------
# Test 14: load_rules combines all sources
# ---------------------------------------------------------------------------

class TestLoadRules:
    def test_builtins_always_present(self):
        # Load with nonexistent paths — should still get builtins
        rules = load_rules(
            db_path=Path("/nonexistent/test.db"),
            memory_dir=Path("/nonexistent/memory"),
            force_reload=True,
        )
        assert len(rules) >= len(BUILTIN_RULES)
        builtin_ids = {r.rule_id for r in BUILTIN_RULES}
        loaded_ids = {r.rule_id for r in rules}
        assert builtin_ids.issubset(loaded_ids)

    def test_db_rules_augment_builtins(self, tmp_db, tmp_memory_dir):
        rules = load_rules(
            db_path=tmp_db,
            memory_dir=tmp_memory_dir,
            force_reload=True,
        )
        # Should have at least builtins
        assert len(rules) >= len(BUILTIN_RULES)


# ---------------------------------------------------------------------------
# Test 15: parse_memory_to_rule
# ---------------------------------------------------------------------------

class TestParseMemory:
    def test_parses_credential_rule(self):
        rule = _parse_memory_to_rule(
            "test_cred_rule",
            "HARD RULE: Never commit credentials or API keys to git",
        )
        assert rule is not None
        assert rule.check_fn == "check_no_credentials"
        assert rule.severity == "block"

    def test_returns_none_for_unrelated(self):
        rule = _parse_memory_to_rule(
            "test_unrelated",
            "This is about project management and Gantt charts.",
        )
        assert rule is None

    def test_parses_delete_rule(self):
        rule = _parse_memory_to_rule(
            "test_delete",
            "NEVER delete files. Always archive first.",
        )
        assert rule is not None
        assert rule.check_fn == "check_archive_before_delete"


# ---------------------------------------------------------------------------
# Test 16: EnforcementResult helpers
# ---------------------------------------------------------------------------

class TestEnforcementResult:
    def test_add_block_violation(self):
        result = EnforcementResult()
        assert result.passed
        result.add_violation(Violation(
            rule_id="test", rule_name="Test", message="blocked", severity="block",
        ))
        assert not result.passed
        assert len(result.violations) == 1

    def test_add_warn_violation(self):
        result = EnforcementResult()
        result.add_violation(Violation(
            rule_id="test", rule_name="Test", message="warned", severity="warn",
        ))
        assert result.passed  # warnings don't block
        assert len(result.warnings) == 1
