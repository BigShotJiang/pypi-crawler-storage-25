"""
Tests for pre-action deletion guard in enforcement.py.

Tests:
  1. guard_deletion creates archive when none exists
  2. guard_deletion detects existing archive
  3. guard_deletion handles nonexistent file (no-op)
  4. guard_deletion handles directory archiving
  5. guard_deletion blocks when archive creation fails
  6. enforce_deletion extracts path from rm command
  7. enforce_deletion extracts path from os.remove
  8. enforce_deletion raises on unknown command
  9. enforce_deletion raises when archiving fails
  10. _extract_file_path_from_command handles various formats
  11. _archive_exists scans archive subdirectories
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.enforcement import (
    EnforcementViolation,
    _archive_exists,
    _extract_file_path_from_command,
    enforce_deletion,
    guard_deletion,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_archive(tmp_path):
    """Provide a temp archive root."""
    archive = tmp_path / "archive"
    archive.mkdir()
    return archive


@pytest.fixture
def tmp_file(tmp_path):
    """Create a temporary file to 'delete'."""
    f = tmp_path / "target.txt"
    f.write_text("important content", encoding="utf-8")
    return f


@pytest.fixture
def tmp_dir(tmp_path):
    """Create a temporary directory to 'delete'."""
    d = tmp_path / "target_dir"
    d.mkdir()
    (d / "file1.txt").write_text("file 1", encoding="utf-8")
    (d / "file2.txt").write_text("file 2", encoding="utf-8")
    return d


# ---------------------------------------------------------------------------
# Test 1: guard_deletion creates archive
# ---------------------------------------------------------------------------

class TestGuardCreatesArchive:
    def test_creates_archive_for_file(self, tmp_file, tmp_archive):
        result = guard_deletion(str(tmp_file), reason="test", archive_root=tmp_archive)
        assert result["allowed"] is True
        assert result["created"] is True
        assert result["archive_path"]
        # Verify archive file exists
        assert Path(result["archive_path"]).exists()
        # Verify content matches
        assert Path(result["archive_path"]).read_text(encoding="utf-8") == "important content"

    def test_archive_in_timestamped_subdir(self, tmp_file, tmp_archive):
        result = guard_deletion(str(tmp_file), archive_root=tmp_archive)
        archive_path = Path(result["archive_path"])
        # Should be in archive_root/YYYYMMDD_HHMMSS/filename
        assert archive_path.parent.parent == tmp_archive
        assert len(archive_path.parent.name) == 15  # YYYYMMDD_HHMMSS


# ---------------------------------------------------------------------------
# Test 2: guard_deletion detects existing archive
# ---------------------------------------------------------------------------

class TestGuardDetectsExisting:
    def test_finds_existing_archive(self, tmp_file, tmp_archive):
        # Pre-create an archive
        subdir = tmp_archive / "20260409_120000"
        subdir.mkdir()
        (subdir / "target.txt").write_text("archived", encoding="utf-8")

        result = guard_deletion(str(tmp_file), archive_root=tmp_archive)
        assert result["allowed"] is True
        assert result["created"] is False
        assert "already exists" in result["message"]


# ---------------------------------------------------------------------------
# Test 3: nonexistent file
# ---------------------------------------------------------------------------

class TestNonexistentFile:
    def test_allows_deletion_of_nonexistent(self, tmp_archive):
        result = guard_deletion("/nonexistent/path/file.txt", archive_root=tmp_archive)
        assert result["allowed"] is True
        assert result["created"] is False
        assert "does not exist" in result["message"]


# ---------------------------------------------------------------------------
# Test 4: directory archiving
# ---------------------------------------------------------------------------

class TestDirectoryArchiving:
    def test_archives_directory(self, tmp_dir, tmp_archive):
        result = guard_deletion(str(tmp_dir), reason="replacing", archive_root=tmp_archive)
        assert result["allowed"] is True
        assert result["created"] is True
        archived_dir = Path(result["archive_path"])
        assert archived_dir.is_dir()
        assert (archived_dir / "file1.txt").exists()
        assert (archived_dir / "file2.txt").exists()


# ---------------------------------------------------------------------------
# Test 5: blocks when archive fails
# ---------------------------------------------------------------------------

class TestArchiveFailure:
    def test_blocks_on_copy_error(self, tmp_file, tmp_archive, monkeypatch):
        # Simulate a copy failure
        import shutil as _shutil
        def fail_copy2(*args, **kwargs):
            raise PermissionError("simulated permission denied")
        monkeypatch.setattr(_shutil, "copy2", fail_copy2)

        # Also patch the module-level import in enforcement
        import aibrain.core.enforcement as _enf
        monkeypatch.setattr(_enf.shutil, "copy2", fail_copy2)

        result = guard_deletion(
            str(tmp_file),
            archive_root=tmp_archive,
        )
        assert result["allowed"] is False
        assert result["error"]
        assert "BLOCKED" in result["message"]


# ---------------------------------------------------------------------------
# Test 6: enforce_deletion with rm command
# ---------------------------------------------------------------------------

class TestEnforceDeletion:
    def test_extracts_and_guards_rm(self, tmp_file, tmp_archive):
        result = enforce_deletion(
            command=f"rm {tmp_file}",
            archive_root=tmp_archive,
        )
        assert result["allowed"] is True
        assert result["created"] is True

    def test_extracts_and_guards_os_remove(self, tmp_file, tmp_archive):
        result = enforce_deletion(
            command=f"os.remove('{tmp_file}')",
            archive_root=tmp_archive,
        )
        assert result["allowed"] is True

    def test_raises_on_unknown_command(self, tmp_archive):
        with pytest.raises(EnforcementViolation) as exc_info:
            enforce_deletion(command="some random text", archive_root=tmp_archive)
        assert len(exc_info.value.violations) >= 1

    def test_raises_when_archiving_fails(self, tmp_file, tmp_archive, monkeypatch):
        import shutil as _shutil
        import aibrain.core.enforcement as _enf
        def fail_copy2(*args, **kwargs):
            raise PermissionError("simulated permission denied")
        monkeypatch.setattr(_enf.shutil, "copy2", fail_copy2)

        with pytest.raises(EnforcementViolation):
            enforce_deletion(
                file_path=str(tmp_file),
                archive_root=tmp_archive,
            )

    def test_direct_file_path(self, tmp_file, tmp_archive):
        result = enforce_deletion(
            file_path=str(tmp_file),
            archive_root=tmp_archive,
        )
        assert result["allowed"] is True


# ---------------------------------------------------------------------------
# Test 7: _extract_file_path_from_command
# ---------------------------------------------------------------------------

class TestExtractFilePath:
    def test_rm_simple(self):
        assert _extract_file_path_from_command("rm file.txt") == "file.txt"

    def test_rm_with_flags(self):
        assert _extract_file_path_from_command("rm -f /path/to/file.txt") == "/path/to/file.txt"

    def test_rm_rf(self):
        assert _extract_file_path_from_command("rm -rf /tmp/mydir") == "/tmp/mydir"

    def test_os_remove(self):
        assert _extract_file_path_from_command("os.remove('/path/to/file')") == "/path/to/file"

    def test_shutil_rmtree(self):
        assert _extract_file_path_from_command("shutil.rmtree('/tmp/dir')") == "/tmp/dir"

    def test_path_unlink(self):
        assert _extract_file_path_from_command("Path('/tmp/file.txt').unlink()") == "/tmp/file.txt"

    def test_del_command(self):
        assert _extract_file_path_from_command("del myfile.txt") == "myfile.txt"

    def test_returns_none_for_non_delete(self):
        assert _extract_file_path_from_command("cp file1 file2") is None


# ---------------------------------------------------------------------------
# Test 8: _archive_exists
# ---------------------------------------------------------------------------

class TestArchiveExists:
    def test_finds_archived_file(self, tmp_archive):
        subdir = tmp_archive / "20260409_100000"
        subdir.mkdir()
        (subdir / "important.py").write_text("code", encoding="utf-8")

        result = _archive_exists("/some/path/important.py", archive_root=tmp_archive)
        assert result is not None
        assert "important.py" in result

    def test_returns_none_when_not_archived(self, tmp_archive):
        result = _archive_exists("/some/path/missing.py", archive_root=tmp_archive)
        assert result is None

    def test_returns_none_when_no_archive_dir(self):
        result = _archive_exists("/some/file.txt", archive_root=Path("/nonexistent"))
        assert result is None
