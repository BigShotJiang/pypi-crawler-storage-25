"""
Tests for aibrain/core/heartbeat.py — Agent heartbeat scheduler.

Covers: check_due_heartbeats, run_heartbeat.

Uses a temporary SQLite DB with the companies schema for isolation.
Mocks LLM calls since heartbeat execution involves external services.
"""

import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


HEARTBEAT_SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mission TEXT,
    status TEXT DEFAULT 'active',
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_agents (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'general',
    title TEXT,
    status TEXT DEFAULT 'idle',
    reports_to TEXT,
    model TEXT DEFAULT 'auto',
    task_type TEXT DEFAULT 'judgment',
    authority TEXT DEFAULT 'standard',
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    heartbeat_interval_seconds INTEGER DEFAULT 14400,
    last_heartbeat_at TIMESTAMP,
    instructions TEXT,
    capabilities TEXT,
    permissions TEXT,
    metadata TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_issues (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    parent_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'backlog',
    priority TEXT DEFAULT 'medium',
    assignee_agent_id TEXT,
    project TEXT,
    issue_number INTEGER,
    origin TEXT DEFAULT 'manual',
    request_depth INTEGER DEFAULT 0,
    quality_score REAL,
    cost_cents INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_approvals (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    type TEXT NOT NULL,
    requested_by_agent_id TEXT,
    status TEXT DEFAULT 'pending',
    payload TEXT,
    decision_note TEXT,
    decided_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_heartbeat_runs (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    status TEXT DEFAULT 'running',
    trigger_source TEXT,
    started_at TIMESTAMP,
    finished_at TIMESTAMP,
    duration_ms INTEGER,
    quality_score REAL,
    cost_cents INTEGER DEFAULT 0,
    model_used TEXT,
    error TEXT,
    summary TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS execution_log (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    detail TEXT,
    quality_score REAL,
    model_used TEXT,
    cost_cents INTEGER DEFAULT 0,
    duration_ms INTEGER DEFAULT 0,
    before_state TEXT,
    after_state TEXT,
    success INTEGER DEFAULT 0,
    error TEXT,
    task_type TEXT,
    authority TEXT,
    retries INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS evolution_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT, source_id TEXT, action TEXT,
    result TEXT, details TEXT, failure_reason TEXT,
    duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


@pytest.fixture()
def heartbeat_db(tmp_path):
    """Create a temp DB with full schema and patch both heartbeat._get_db and harness._find_db."""
    db_path = tmp_path / "test_heartbeat.db"
    conn = sqlite3.connect(str(db_path))
    conn.executescript(HEARTBEAT_SCHEMA)
    conn.close()

    def _patched_get_db():
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        return db

    with patch("aibrain.core.heartbeat._get_db", _patched_get_db), \
         patch("aibrain.core.harness._find_db", return_value=db_path):
        yield db_path


def _seed_company_and_agent(db_path, agent_status="idle", last_heartbeat=None,
                            interval=3600, role="general"):
    """Insert a company + agent into the DB. Returns (company_id, agent_id)."""
    db = sqlite3.connect(str(db_path))
    db.execute(
        "INSERT INTO companies (id, name, mission, status) VALUES ('co1', 'TestCo', 'Testing', 'active')"
    )
    db.execute("""
        INSERT INTO company_agents
        (id, company_id, name, role, title, status, task_type, authority,
         heartbeat_interval_seconds, last_heartbeat_at)
        VALUES ('ag1', 'co1', 'TestAgent', ?, 'TestAgent', ?, 'judgment', 'standard', ?, ?)
    """, (role, agent_status, interval, last_heartbeat))
    db.commit()
    db.close()
    return "co1", "ag1"


# ---------------------------------------------------------------------------
# check_due_heartbeats
# ---------------------------------------------------------------------------


class TestCheckDueHeartbeats:

    def test_no_agents_returns_empty(self, heartbeat_db):
        from aibrain.core.heartbeat import check_due_heartbeats
        results = check_due_heartbeats()
        assert results == []

    def test_agent_never_beaten_is_due(self, heartbeat_db):
        """An agent with last_heartbeat_at=NULL should be due."""
        _seed_company_and_agent(heartbeat_db, last_heartbeat=None)
        from aibrain.core.heartbeat import check_due_heartbeats

        # Mock run_heartbeat to avoid actual execution
        with patch("aibrain.core.heartbeat.run_heartbeat") as mock_run:
            mock_run.return_value = {
                "run_id": "test", "agent": "TestAgent",
                "status": "succeeded", "summary": "idle",
                "quality": 0.7, "duration_ms": 100,
            }
            results = check_due_heartbeats()
            assert len(results) == 1
            mock_run.assert_called_once_with("ag1")

    def test_recently_beaten_agent_not_due(self, heartbeat_db):
        """An agent beaten recently should not be due."""
        recent = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        _seed_company_and_agent(heartbeat_db, last_heartbeat=recent, interval=86400)
        from aibrain.core.heartbeat import check_due_heartbeats

        with patch("aibrain.core.heartbeat.run_heartbeat") as mock_run:
            results = check_due_heartbeats()
            assert len(results) == 0
            mock_run.assert_not_called()

    def test_paused_company_excluded(self, heartbeat_db):
        """Agents in paused companies should not be due."""
        _seed_company_and_agent(heartbeat_db, last_heartbeat=None)
        # Pause the company
        db = sqlite3.connect(str(heartbeat_db))
        db.execute("UPDATE companies SET status='paused' WHERE id='co1'")
        db.commit()
        db.close()

        from aibrain.core.heartbeat import check_due_heartbeats
        with patch("aibrain.core.heartbeat.run_heartbeat") as mock_run:
            results = check_due_heartbeats()
            assert len(results) == 0

    def test_terminated_agent_excluded(self, heartbeat_db):
        """Terminated agents should not be due."""
        _seed_company_and_agent(heartbeat_db, agent_status="terminated", last_heartbeat=None)
        from aibrain.core.heartbeat import check_due_heartbeats
        with patch("aibrain.core.heartbeat.run_heartbeat") as mock_run:
            results = check_due_heartbeats()
            assert len(results) == 0


# ---------------------------------------------------------------------------
# run_heartbeat
# ---------------------------------------------------------------------------


class TestRunHeartbeat:

    def test_nonexistent_agent_returns_error(self, heartbeat_db):
        from aibrain.core.heartbeat import run_heartbeat
        result = run_heartbeat("nonexistent_agent_id")
        assert "error" in result

    def test_heartbeat_creates_run_record(self, heartbeat_db):
        """A heartbeat should insert into company_heartbeat_runs."""
        _seed_company_and_agent(heartbeat_db, last_heartbeat=None)
        from aibrain.core.heartbeat import run_heartbeat

        # Mock the LLM-dependent parts
        with patch("aibrain.core.heartbeat._execute_agent_task") as mock_exec:
            mock_exec.return_value = {
                "success": True, "output": "done", "summary": "completed",
                "quality": 0.9, "cost_cents": 5,
            }
            result = run_heartbeat("ag1")

        assert result["status"] in ("succeeded", "failed")
        assert "run_id" in result
        assert result["agent"] == "TestAgent"

        # Verify DB record
        db = sqlite3.connect(str(heartbeat_db))
        db.row_factory = sqlite3.Row
        runs = db.execute("SELECT * FROM company_heartbeat_runs").fetchall()
        db.close()
        assert len(runs) >= 1

    def test_heartbeat_updates_agent_status(self, heartbeat_db):
        """After heartbeat, agent status should return to idle."""
        _seed_company_and_agent(heartbeat_db, last_heartbeat=None)
        from aibrain.core.heartbeat import run_heartbeat

        with patch("aibrain.core.heartbeat._execute_agent_task") as mock_exec:
            mock_exec.return_value = {
                "success": True, "output": "done", "summary": "ok",
                "quality": 0.8, "cost_cents": 0,
            }
            run_heartbeat("ag1")

        db = sqlite3.connect(str(heartbeat_db))
        db.row_factory = sqlite3.Row
        agent = db.execute("SELECT status, last_heartbeat_at FROM company_agents WHERE id='ag1'").fetchone()
        db.close()
        assert agent["status"] == "idle"
        assert agent["last_heartbeat_at"] is not None

    def test_heartbeat_idle_when_no_tasks(self, heartbeat_db):
        """Agent with no tasks should report idle heartbeat."""
        _seed_company_and_agent(heartbeat_db, last_heartbeat=None)
        from aibrain.core.heartbeat import run_heartbeat

        result = run_heartbeat("ag1")
        # Should succeed even with no tasks
        assert result["status"] in ("succeeded", "failed")
