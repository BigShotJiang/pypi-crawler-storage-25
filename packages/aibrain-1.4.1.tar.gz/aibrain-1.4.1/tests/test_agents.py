"""
Tests for aibrain/core/agents.py — Agent/Task/Team composition system.

Covers: Agent creation, Task creation, sequential team execution,
        hierarchical team execution, guardrail retry, memory injection,
        task context chaining, TeamOutput structure, companies bridge.

Uses monkeypatching to avoid needing a real DB or LLM for unit tests.
"""

import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.agents import (
    Agent,
    Task,
    TaskOutput,
    Team,
    TeamOutput,
    team_from_company,
    _agent_llm_to_task_type,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _patch_externals(monkeypatch):
    """Patch LLM calls, memory search, and event emission for all tests."""
    monkeypatch.setattr(
        "aibrain.core.agents._call_llm",
        lambda prompt, agent, task_type: f"mock output for {agent.role}",
    )
    monkeypatch.setattr(
        "aibrain.core.agents._search_memory",
        lambda query, agent_id=None: [],
    )
    monkeypatch.setattr(
        "aibrain.core.agents._emit_event",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(
        "aibrain.core.agents._get_durable_workflow",
        lambda wid: None,
    )


# ---------------------------------------------------------------------------
# Agent creation
# ---------------------------------------------------------------------------

class TestAgent:

    def test_agent_defaults(self):
        agent = Agent(role="Tester", goal="Test things")
        assert agent.role == "Tester"
        assert agent.goal == "Test things"
        assert agent.backstory == ""
        assert agent.tools == []
        assert agent.llm is None
        assert agent.memory is True
        assert agent.max_iter == 25
        assert agent.allow_delegation is False
        assert agent.verbose is False
        assert len(agent.id) > 0

    def test_agent_custom_fields(self):
        agent = Agent(
            role="Researcher",
            goal="Find data",
            backstory="Expert in data analysis",
            tools=["web_search", "read_file"],
            llm="claude",
            memory=False,
            max_iter=10,
            allow_delegation=True,
            verbose=True,
        )
        assert agent.backstory == "Expert in data analysis"
        assert agent.tools == ["web_search", "read_file"]
        assert agent.llm == "claude"
        assert agent.memory is False
        assert agent.max_iter == 10
        assert agent.allow_delegation is True

    def test_agent_unique_ids(self):
        a1 = Agent(role="A", goal="X")
        a2 = Agent(role="A", goal="X")
        assert a1.id != a2.id

    def test_agent_system_prompt(self):
        agent = Agent(role="Writer", goal="Write articles", backstory="Journalist")
        prompt = agent._build_system_prompt()
        assert "Writer" in prompt
        assert "Write articles" in prompt
        assert "Journalist" in prompt

    def test_agent_guardrail_callable(self):
        def my_guard(output):
            return True
        agent = Agent(role="X", goal="Y", guardrail=my_guard)
        assert agent.guardrail is my_guard


# ---------------------------------------------------------------------------
# Task creation
# ---------------------------------------------------------------------------

class TestTask:

    def test_task_defaults(self):
        task = Task(description="Do something", expected_output="A result")
        assert task.description == "Do something"
        assert task.expected_output == "A result"
        assert task.agent is None
        assert task.context == []
        assert task.tools == []
        assert task.output_type == "text"
        assert task.guardrail_max_retries == 3
        assert task.async_execution is False
        assert task.human_input is False
        assert len(task.id) > 0

    def test_task_with_agent(self):
        agent = Agent(role="Worker", goal="Work")
        task = Task(
            description="Analyze data",
            expected_output="Analysis report",
            agent=agent,
        )
        assert task.agent is agent
        assert task.agent.role == "Worker"

    def test_task_context_chaining(self):
        t1 = Task(description="Step 1", expected_output="Output 1")
        t2 = Task(description="Step 2", expected_output="Output 2", context=[t1])
        assert len(t2.context) == 1
        assert t2.context[0].id == t1.id

    def test_task_json_output_type(self):
        task = Task(
            description="Return JSON",
            expected_output='{"key": "value"}',
            output_type="json",
        )
        assert task.output_type == "json"


# ---------------------------------------------------------------------------
# TaskOutput / TeamOutput
# ---------------------------------------------------------------------------

class TestOutputModels:

    def test_task_output_defaults(self):
        out = TaskOutput()
        assert out.task_id == ""
        assert out.raw == ""
        assert out.json_dict is None
        # Default is None under the honest-rubric contract (Apr 10 2026).
        assert out.quality is None

    def test_task_output_populated(self):
        out = TaskOutput(
            task_id="abc",
            raw="hello",
            json_dict={"x": 1},
            agent_role="Writer",
            quality=0.85,
        )
        assert out.task_id == "abc"
        assert out.json_dict == {"x": 1}

    def test_team_output_defaults(self):
        out = TeamOutput()
        assert out.team_name == ""
        assert out.task_outputs == []
        assert out.total_tokens == 0
        assert out.total_cost == 0.0
        assert out.success is True

    def test_team_output_with_tasks(self):
        out = TeamOutput(
            team_name="test",
            task_outputs=[
                TaskOutput(task_id="1", raw="a", quality=0.9),
                TaskOutput(task_id="2", raw="b", quality=0.8),
            ],
            success=True,
        )
        assert len(out.task_outputs) == 2


# ---------------------------------------------------------------------------
# Sequential team execution
# ---------------------------------------------------------------------------

class TestSequentialTeam:

    def test_basic_sequential(self):
        agent = Agent(role="Worker", goal="Do work")
        task = Task(description="Task A", expected_output="Output A", agent=agent)
        team = Team(name="seq_team", agents=[agent], tasks=[task])

        result = team.kickoff()

        assert isinstance(result, TeamOutput)
        assert result.team_name == "seq_team"
        assert len(result.task_outputs) == 1
        assert result.task_outputs[0].agent_role == "Worker"
        assert "mock output for Worker" in result.task_outputs[0].raw
        assert result.success is True

    def test_multi_task_sequential(self):
        a1 = Agent(role="Researcher", goal="Research")
        a2 = Agent(role="Writer", goal="Write")
        t1 = Task(description="Research topic", expected_output="Notes", agent=a1)
        t2 = Task(description="Write article", expected_output="Article", agent=a2, context=[t1])
        team = Team(name="pipeline", agents=[a1, a2], tasks=[t1, t2])

        result = team.kickoff()

        assert len(result.task_outputs) == 2
        assert result.task_outputs[0].agent_role == "Researcher"
        assert result.task_outputs[1].agent_role == "Writer"
        assert result.success is True

    def test_task_without_agent_uses_first(self):
        """Task with no agent assigned should use the first team agent."""
        agent = Agent(role="Default", goal="Handle unassigned")
        task = Task(description="Unassigned task", expected_output="Something")
        team = Team(name="fallback", agents=[agent], tasks=[task])

        result = team.kickoff()
        assert result.task_outputs[0].agent_role == "Default"

    def test_no_agents_produces_error(self):
        """Team with no agents should produce error output."""
        task = Task(description="Orphan task", expected_output="Nothing")
        team = Team(name="empty", agents=[], tasks=[task])

        result = team.kickoff()
        assert result.success is False
        assert "ERROR" in result.task_outputs[0].raw

    def test_inputs_passed_to_tasks(self):
        """Inputs dict should be available in prompts."""
        agent = Agent(role="Worker", goal="Work")
        task = Task(description="Use {topic}", expected_output="Result")
        team = Team(name="inputs_test", agents=[agent], tasks=[task])

        result = team.kickoff(inputs={"topic": "AI agents"})
        assert result.success is True


# ---------------------------------------------------------------------------
# Hierarchical team execution
# ---------------------------------------------------------------------------

class TestHierarchicalTeam:

    def test_hierarchical_picks_best_agent(self):
        researcher = Agent(role="Researcher", goal="Research topics")
        writer = Agent(role="Writer", goal="Write content")
        task = Task(description="Research the market", expected_output="Report")

        team = Team(
            name="hier",
            agents=[researcher, writer],
            tasks=[task],
            process="hierarchical",
        )

        result = team.kickoff()
        # "Research" in task description should match "Researcher" agent
        assert result.task_outputs[0].agent_role == "Researcher"

    def test_hierarchical_explicit_assignment_wins(self):
        researcher = Agent(role="Researcher", goal="Research")
        writer = Agent(role="Writer", goal="Write")
        task = Task(
            description="Research something",
            expected_output="Result",
            agent=writer,  # explicitly assigned to writer
        )

        team = Team(
            name="explicit",
            agents=[researcher, writer],
            tasks=[task],
            process="hierarchical",
        )

        result = team.kickoff()
        assert result.task_outputs[0].agent_role == "Writer"


# ---------------------------------------------------------------------------
# Guardrail retry
# ---------------------------------------------------------------------------

class TestGuardrailRetry:

    def test_guardrail_passes_on_first_try(self):
        def good_guard(output):
            return True

        agent = Agent(role="Worker", goal="Work")
        task = Task(
            description="Guarded task",
            expected_output="Good output",
            agent=agent,
            guardrail=good_guard,
        )
        team = Team(name="guard_pass", agents=[agent], tasks=[task])

        result = team.kickoff()
        assert result.success is True

    def test_guardrail_retries_with_feedback(self, monkeypatch):
        call_count = {"n": 0}

        def failing_guard(output):
            call_count["n"] += 1
            if call_count["n"] < 3:
                return (False, "Output must include keyword XYZ")
            return True

        agent = Agent(role="Worker", goal="Work")
        task = Task(
            description="Guarded task",
            expected_output="Good output",
            agent=agent,
            guardrail=failing_guard,
            guardrail_max_retries=5,
        )
        team = Team(name="guard_retry", agents=[agent], tasks=[task])

        result = team.kickoff()
        # Guardrail was called 3 times (2 failures + 1 pass)
        assert call_count["n"] == 3
        assert result.success is True

    def test_agent_level_guardrail_used_when_task_has_none(self):
        guard_called = {"v": False}

        def agent_guard(output):
            guard_called["v"] = True
            return True

        agent = Agent(role="Worker", goal="Work", guardrail=agent_guard)
        task = Task(description="Task", expected_output="Output", agent=agent)
        team = Team(name="agent_guard", agents=[agent], tasks=[task])

        team.kickoff()
        assert guard_called["v"] is True


# ---------------------------------------------------------------------------
# Memory injection
# ---------------------------------------------------------------------------

class TestMemoryInjection:

    def test_memory_injected_when_enabled(self, monkeypatch):
        """When memory=True, _search_memory should be called during prompt building."""
        search_called = {"v": False}

        def mock_search(query, agent_id=None):
            search_called["v"] = True
            return ["Memory A", "Memory B"]

        monkeypatch.setattr("aibrain.core.agents._search_memory", mock_search)

        agent = Agent(role="Worker", goal="Work", memory=True)
        task = Task(description="Do research", expected_output="Result", agent=agent)
        team = Team(name="mem_team", agents=[agent], tasks=[task], memory=True)

        result = team.kickoff()
        assert search_called["v"] is True

    def test_memory_skipped_when_disabled(self, monkeypatch):
        search_called = {"v": False}

        def mock_search(query, agent_id=None):
            search_called["v"] = True
            return []

        monkeypatch.setattr("aibrain.core.agents._search_memory", mock_search)

        agent = Agent(role="Worker", goal="Work", memory=False)
        task = Task(description="Do something", expected_output="Result", agent=agent)
        team = Team(name="no_mem", agents=[agent], tasks=[task], memory=False)

        result = team.kickoff()
        assert search_called["v"] is False


# ---------------------------------------------------------------------------
# Task context chaining
# ---------------------------------------------------------------------------

class TestContextChaining:

    def test_context_output_forwarded(self, monkeypatch):
        """Output from a context task should appear in the prompt of the dependent task."""
        prompts_seen = []

        def capture_llm(prompt, agent, task_type):
            prompts_seen.append(prompt)
            return f"output from {agent.role}"

        monkeypatch.setattr("aibrain.core.agents._call_llm", capture_llm)

        a1 = Agent(role="Researcher", goal="Research")
        a2 = Agent(role="Writer", goal="Write")
        t1 = Task(description="Research AI", expected_output="Notes", agent=a1)
        t2 = Task(description="Write article", expected_output="Article", agent=a2, context=[t1])
        team = Team(name="chain", agents=[a1, a2], tasks=[t1, t2])

        result = team.kickoff()

        # The second prompt should contain the first task's output
        assert len(prompts_seen) == 2
        assert "output from Researcher" in prompts_seen[1]

    def test_multiple_context_tasks(self, monkeypatch):
        prompts_seen = []

        def capture_llm(prompt, agent, task_type):
            prompts_seen.append(prompt)
            return f"output-{agent.role}"

        monkeypatch.setattr("aibrain.core.agents._call_llm", capture_llm)

        a1 = Agent(role="A", goal="Do A")
        a2 = Agent(role="B", goal="Do B")
        a3 = Agent(role="C", goal="Do C")
        t1 = Task(description="Task 1", expected_output="Out 1", agent=a1)
        t2 = Task(description="Task 2", expected_output="Out 2", agent=a2)
        t3 = Task(description="Task 3", expected_output="Out 3", agent=a3, context=[t1, t2])
        team = Team(name="multi_ctx", agents=[a1, a2, a3], tasks=[t1, t2, t3])

        team.kickoff()

        # Third prompt should contain both previous outputs
        assert "output-A" in prompts_seen[2]
        assert "output-B" in prompts_seen[2]


# ---------------------------------------------------------------------------
# LLM task type mapping
# ---------------------------------------------------------------------------

class TestTaskTypeMapping:

    def test_auto_maps_to_judgment(self):
        assert _agent_llm_to_task_type("auto") == "judgment"

    def test_none_maps_to_judgment(self):
        assert _agent_llm_to_task_type(None) == "judgment"

    def test_opus_maps_to_complex(self):
        assert _agent_llm_to_task_type("claude-opus-4-20250514") == "complex"

    def test_haiku_maps_to_simple(self):
        assert _agent_llm_to_task_type("claude-haiku-4-5-20251001") == "simple"

    def test_sonnet_maps_to_judgment(self):
        assert _agent_llm_to_task_type("claude-sonnet-4-20250514") == "judgment"

    def test_ollama_maps_to_simple(self):
        assert _agent_llm_to_task_type("ollama/qwen2.5:7b-instruct") == "simple"

    def test_gpt4o_mini_maps_to_simple(self):
        assert _agent_llm_to_task_type("gpt-4o-mini") == "simple"

    def test_gpt4o_maps_to_judgment(self):
        assert _agent_llm_to_task_type("gpt-4o") == "judgment"


# ---------------------------------------------------------------------------
# Async kickoff
# ---------------------------------------------------------------------------

class TestAsyncKickoff:

    def test_async_kickoff(self):
        import asyncio

        agent = Agent(role="Async", goal="Work async")
        task = Task(description="Async task", expected_output="Result", agent=agent)
        team = Team(name="async_team", agents=[agent], tasks=[task])

        result = asyncio.get_event_loop().run_until_complete(team.kickoff_async())
        assert isinstance(result, TeamOutput)
        assert result.success is True


# ---------------------------------------------------------------------------
# Companies bridge
# ---------------------------------------------------------------------------

class TestCompaniesBridge:

    def test_team_from_company(self, monkeypatch):
        # Patch the companies module functions that team_from_company imports
        from aibrain.core import companies as co_mod
        monkeypatch.setattr(co_mod, "get_company", lambda cid: {
            "id": "co1", "name": "Test Corp", "status": "active",
        })
        monkeypatch.setattr(co_mod, "list_agents", lambda cid: [
            {"id": "ag1", "name": "Alice", "role": "ceo", "title": "CEO",
             "model": "claude", "capabilities": "Leadership"},
        ])
        monkeypatch.setattr(co_mod, "list_tasks", lambda cid, status=None: [
            {"id": "tk1", "title": "Plan Q2", "description": "Plan Q2 strategy",
             "assignee_agent_id": "ag1"},
        ] if status == "todo" else [])

        team = team_from_company("co1")

        assert team.name == "Test Corp"
        assert len(team.agents) == 1
        assert team.agents[0].role == "ceo"
        assert len(team.tasks) == 1
        assert team.tasks[0].description == "Plan Q2"
        assert team.tasks[0].agent is not None
        assert team.tasks[0].agent.id == "ag1"

    def test_team_from_company_not_found(self, monkeypatch):
        from aibrain.core import companies as co_mod
        monkeypatch.setattr(co_mod, "get_company", lambda cid: None)

        with pytest.raises(ValueError, match="Company not found"):
            team_from_company("nonexistent")
