#!/usr/bin/env python3
"""AIBrain Workflow: Bookmark Organizer — parse browser bookmarks, categorize, deduplicate."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path
from urllib.parse import urlparse

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

CATEGORIES = {
    "dev": ["github.com", "stackoverflow.com", "dev.to", "medium.com", "docs.", "api.", "npmjs.com", "pypi.org"],
    "social": ["twitter.com", "x.com", "linkedin.com", "reddit.com", "facebook.com", "instagram.com", "mastodon"],
    "video": ["youtube.com", "vimeo.com", "twitch.tv"],
    "news": ["bbc.", "cnn.", "reuters.", "techcrunch.", "arstechnica.", "theverge."],
    "shopping": ["amazon.", "ebay.", "etsy."],
    "reference": ["wikipedia.", "arxiv.", "scholar.google"],
    "tools": ["notion.", "figma.", "canva.", "trello.", "asana."],
}


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def find_bookmark_files():
    """Find browser bookmark files on the system."""
    home = Path.home()
    paths = []
    # Chrome
    chrome_paths = [
        home / "AppData/Local/Google/Chrome/User Data/Default/Bookmarks",
        home / ".config/google-chrome/Default/Bookmarks",
        home / "Library/Application Support/Google/Chrome/Default/Bookmarks",
    ]
    # Edge
    edge_paths = [
        home / "AppData/Local/Microsoft/Edge/User Data/Default/Bookmarks",
    ]
    # Firefox (bookmarks are in places.sqlite — skip for now, complex)

    for p in chrome_paths + edge_paths:
        if p.exists():
            paths.append(p)
    return paths


def parse_chrome_bookmarks(filepath):
    """Parse Chrome/Edge bookmarks JSON."""
    bookmarks = []
    try:
        data = json.loads(filepath.read_text(encoding="utf-8"))
        def walk(node):
            if node.get("type") == "url":
                bookmarks.append({
                    "name": node.get("name", ""),
                    "url": node.get("url", ""),
                    "added": node.get("date_added", ""),
                })
            for child in node.get("children", []):
                walk(child)
        for root in data.get("roots", {}).values():
            if isinstance(root, dict):
                walk(root)
    except Exception as e:
        print(f"Error parsing {filepath}: {e}", file=sys.stderr)
    return bookmarks


def categorize_url(url):
    domain = urlparse(url).netloc.lower()
    for cat, patterns in CATEGORIES.items():
        if any(p in domain for p in patterns):
            return cat
    return "other"


def format_report(bookmarks, dupes):
    by_cat = {}
    for b in bookmarks:
        cat = categorize_url(b["url"])
        by_cat.setdefault(cat, []).append(b)

    lines = [
        f"BOOKMARK ORGANIZER — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        f"Total bookmarks: {len(bookmarks)} | Duplicates: {len(dupes)}",
        "=" * 50,
        "",
        "BY CATEGORY",
    ]

    for cat in sorted(by_cat, key=lambda c: len(by_cat[c]), reverse=True):
        items = by_cat[cat]
        lines.append(f"\n  {cat.upper()} ({len(items)})")
        for b in items[:5]:
            lines.append(f"    {b['name'][:40]:40s}  {urlparse(b['url']).netloc}")
        if len(items) > 5:
            lines.append(f"    ... and {len(items) - 5} more")

    if dupes:
        lines.append(f"\nDUPLICATES ({len(dupes)})")
        for url, count in list(dupes.items())[:10]:
            lines.append(f"  {url[:60]:60s} ({count}x)")

    lines.append("\n—\nPowered by AIBrain")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Bookmark Organizer")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    # Find and parse bookmarks
    files = find_bookmark_files()
    all_bookmarks = []
    for f in files:
        print(f"  Found: {f}")
        all_bookmarks.extend(parse_chrome_bookmarks(f))

    if not all_bookmarks:
        print("No bookmarks found. Supported: Chrome, Edge")
        return

    # Find duplicates
    url_counts = {}
    for b in all_bookmarks:
        url_counts[b["url"]] = url_counts.get(b["url"], 0) + 1
    dupes = {url: count for url, count in url_counts.items() if count > 1}

    # Deduplicate
    seen = set()
    unique = []
    for b in all_bookmarks:
        if b["url"] not in seen:
            seen.add(b["url"])
            unique.append(b)

    report = format_report(unique, dupes)

    if not email_to or args.dry_run:
        print(report)
    else:
        send_email(email_to, f"Bookmark Report — {len(unique)} bookmarks", report)

    save_state("bookmark_organizer", {
        "last_run": datetime.datetime.now().isoformat(),
        "total": len(unique),
        "duplicates": len(dupes),
    })

    log_activity("bookmark_organizer", f"Organized {len(unique)} bookmarks, {len(dupes)} duplicates removed")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='bookmark_organizer',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
