#!/usr/bin/env python3
"""AIBrain Workflow: Expense Tracker — parse emails/receipts for spending summary."""

import sys, io

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute
if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import argparse
import datetime
import json
import os
import re
import smtplib
import sqlite3
import sys
from email.mime.text import MIMEText
from pathlib import Path

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())

CATEGORIES = {
    "food": ["uber eats", "doordash", "grubhub", "restaurant", "coffee", "starbucks", "mcdonalds"],
    "transport": ["uber", "lyft", "parking", "gas", "fuel", "toll"],
    "subscriptions": ["netflix", "spotify", "hulu", "disney", "openai", "anthropic", "github", "aws"],
    "shopping": ["amazon", "ebay", "walmart", "target"],
    "utilities": ["electric", "water", "internet", "phone", "mobile"],
}


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def add_expense(state, amount, description, category="other", date=None):
    if "expenses" not in state:
        state["expenses"] = []
    state["expenses"].append({
        "amount": amount,
        "description": description,
        "category": category,
        "date": date or datetime.date.today().isoformat(),
    })
    return state


def categorize(description):
    desc_lower = description.lower()
    for cat, keywords in CATEGORIES.items():
        if any(kw in desc_lower for kw in keywords):
            return cat
    return "other"


def format_report(state):
    expenses = state.get("expenses", [])
    today = datetime.date.today()
    month_start = today.replace(day=1).isoformat()
    week_start = (today - datetime.timedelta(days=today.weekday())).isoformat()

    month_expenses = [e for e in expenses if e["date"] >= month_start]
    week_expenses = [e for e in expenses if e["date"] >= week_start]

    lines = [
        f"EXPENSE REPORT — {today.strftime('%B %Y')}",
        "=" * 50,
        "",
        f"This month: ${sum(e['amount'] for e in month_expenses):,.2f} ({len(month_expenses)} transactions)",
        f"This week:  ${sum(e['amount'] for e in week_expenses):,.2f} ({len(week_expenses)} transactions)",
        "",
    ]

    # By category
    cat_totals = {}
    for e in month_expenses:
        cat = e.get("category", "other")
        cat_totals[cat] = cat_totals.get(cat, 0) + e["amount"]

    if cat_totals:
        lines.append("BY CATEGORY (this month)")
        for cat, total in sorted(cat_totals.items(), key=lambda x: x[1], reverse=True):
            bar = "#" * min(int(total / 10), 30)
            lines.append(f"  {cat:15s} ${total:>8,.2f}  {bar}")
        lines.append("")

    # Recent transactions
    recent = sorted(expenses, key=lambda x: x["date"], reverse=True)[:10]
    if recent:
        lines.append("RECENT TRANSACTIONS")
        for e in recent:
            lines.append(f"  {e['date']}  ${e['amount']:>8,.2f}  {e['description'][:30]}  [{e['category']}]")
        lines.append("")

    # Budget alerts
    budget = CONFIG.get("monthly_budget", 0)
    if budget:
        spent = sum(e["amount"] for e in month_expenses)
        pct = (spent / budget) * 100
        lines.append(f"BUDGET: ${spent:,.2f} / ${budget:,.2f} ({pct:.0f}%)")
        if pct > 90:
            lines.append("  ⚠ Over 90% of budget used!")
        elif pct > 75:
            lines.append("  ⚠ Over 75% of budget used")
        lines.append("")

    lines.append("—\nPowered by AIBrain")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Expense Tracker")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--add", nargs=2, metavar=("AMOUNT", "DESCRIPTION"), help="Add expense")
    parser.add_argument("--report", action="store_true", help="Generate spending report")
    args = parser.parse_args()

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("expense_tracker")

    if args.add:
        amount = float(args.add[0])
        desc = args.add[1]
        cat = categorize(desc)
        state = add_expense(state, amount, desc, cat)
        save_state("expense_tracker", state)
        print(f"Added: ${amount:.2f} — {desc} [{cat}]")
        return

    # Default: generate report
    report = format_report(state)
    if not email_to or args.dry_run:
        print(report)
    else:
        send_email(email_to, f"Expense Report — {datetime.date.today().strftime('%B %Y')}", report)
        print(f"Sent expense report to {email_to}")

    state["last_run"] = datetime.datetime.now().isoformat()
    # Trim expenses older than 90 days
    cutoff = (datetime.date.today() - datetime.timedelta(days=90)).isoformat()
    if "expenses" in state:
        state["expenses"] = [e for e in state["expenses"] if e["date"] >= cutoff]
    save_state("expense_tracker", state)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='expense_tracker',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
