"""
cross_domain_questions.py — The Pixel Moment substrate.

6-node reactive graph that detects anomalies and correlations across domains,
then generates cross-domain questions that surface breakthrough insights.

Architecture (3 tiers, 6 nodes):
  Tier 1 — Domain aggregators (3 nodes):
    security_scanner_aggregator: security findings, scan completions, vuln counts
    analytics_aggregator: trading signals, portfolio changes, market events
    aibrain_aggregator: workflow runs, memory changes, evolution experiments

  Tier 2 — Detectors (2 nodes):
    anomaly_detector: Z-score against 7-day rolling baseline (threshold: 2.0 SD)
    correlation_detector: temporal co-occurrence within 30-minute window

  Tier 3 — Generator (1 node):
    cross_domain_question_generator: template-based question generation,
    max 3 per day, saved to cross_domain_questions table

Data flow:
  pattern_bus_events + workflow_runs + memories
    → aggregators
    → detectors
    → question generator
    → cross_domain_questions table

CLI:
  --scan       Run full pipeline
  --dry-run    Analyze but don't save
  --recent     Show recent questions
  --rate ID R  Rate a question (useful/noise/brilliant)
  --stats      Show generation stats
"""

import argparse
import json
import logging
import math
import os
import sqlite3
import sys
import urllib.request
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Paths and constants
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg = json.loads((AIBRAIN_ROOT / "config.json").read_text()) if (AIBRAIN_ROOT / "config.json").exists() else {}


def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = _cfg.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = _cfg.get("db_path", _find_db())
PYTHON = os.environ.get("PYTHON", sys.executable)

# Configurable thresholds
Z_SCORE_THRESHOLD = 2.0
CORRELATION_WINDOW_MINUTES = 30
QUESTION_BUDGET_PER_DAY = 3
BASELINE_DAYS = 7

DOMAINS = ["security_scanner", "analytics", "aibrain"]
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

log = logging.getLogger("cross_domain_questions")


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "intelligence",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass

# ---------------------------------------------------------------------------
# Question templates — no LLM needed
# ---------------------------------------------------------------------------

ANOMALY_TEMPLATES = [
    "{domain} event rate spiked {multiplier}x above baseline in the last hour — what changed?",
    "{domain} had {count} {event_type} events when the 7-day average is {avg} — is this expected or a sign of {possible_cause}?",
    "Unusual pattern in {domain}: {detail}. Has anything in the environment changed?",
]

CORRELATION_TEMPLATES = [
    "{domain_a} and {domain_b} both showed unusual activity within {window} minutes — is the same external event driving both?",
    "Correlation detected: {domain_a} {event_a} coincided with {domain_b} {event_b}. Causal or coincidental?",
    "{count} domains showed anomalies in the same window: {domains}. Cross-domain investigation recommended.",
]

# Possible cause hints per domain — gives templates something meaningful to say
DOMAIN_CAUSE_HINTS = {
    "security_scanner": ["a new scan target", "chain configuration change", "external vulnerability disclosure"],
    "analytics": ["market volatility", "new asset added to watchlist", "signal threshold change"],
    "aibrain": ["workflow batch run", "memory consolidation", "evolution experiment"],
}

# ---------------------------------------------------------------------------
# Database setup
# ---------------------------------------------------------------------------

def ensure_questions_table(db_path: str = DB_PATH):
    """Create the cross_domain_questions table if it doesn't exist."""
    with sqlite3.connect(db_path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cross_domain_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created TEXT NOT NULL,
                question TEXT NOT NULL,
                context TEXT DEFAULT '',
                domains TEXT DEFAULT '',
                trigger_type TEXT DEFAULT '',
                rating TEXT DEFAULT '',
                acted_on INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_cdq_created
            ON cross_domain_questions(created)
        """)
        conn.commit()


def get_questions_today(db_path: str = DB_PATH) -> int:
    """Count questions generated today."""
    today_start = datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0
    ).isoformat()
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT COUNT(*) FROM cross_domain_questions WHERE created >= ?",
            (today_start,)
        ).fetchone()
        return row[0] if row else 0


def save_question(question: str, context: dict, domains: list[str],
                  trigger_type: str, db_path: str = DB_PATH) -> int:
    """Save a generated question. Returns the new row ID."""
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO cross_domain_questions (created, question, context, domains, trigger_type) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                datetime.now(timezone.utc).isoformat(),
                question,
                json.dumps(context, default=str),
                json.dumps(domains),
                trigger_type,
            )
        )
        conn.commit()
        return cur.lastrowid


def rate_question(question_id: int, rating: str, db_path: str = DB_PATH) -> bool:
    """Rate a question. Returns True if the question existed."""
    valid_ratings = {"useful", "noise", "brilliant"}
    if rating not in valid_ratings:
        print(f"Invalid rating '{rating}'. Must be one of: {', '.join(sorted(valid_ratings))}")
        return False
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute(
            "UPDATE cross_domain_questions SET rating = ? WHERE id = ?",
            (rating, question_id)
        )
        conn.commit()
        return cur.rowcount > 0


def get_recent_questions(limit: int = 20, db_path: str = DB_PATH) -> list[dict]:
    """Fetch recent questions."""
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM cross_domain_questions ORDER BY created DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_question_stats(db_path: str = DB_PATH) -> dict:
    """Get generation stats and rating breakdown."""
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        total = conn.execute("SELECT COUNT(*) as c FROM cross_domain_questions").fetchone()["c"]
        today_count = get_questions_today(db_path)

        # Rating breakdown
        ratings = conn.execute(
            "SELECT rating, COUNT(*) as c FROM cross_domain_questions "
            "WHERE rating != '' GROUP BY rating"
        ).fetchall()
        rating_map = {r["rating"]: r["c"] for r in ratings}

        # Trigger type breakdown
        triggers = conn.execute(
            "SELECT trigger_type, COUNT(*) as c FROM cross_domain_questions "
            "WHERE trigger_type != '' GROUP BY trigger_type"
        ).fetchall()
        trigger_map = {r["trigger_type"]: r["c"] for r in triggers}

        # Domain frequency
        domain_counts: dict[str, int] = defaultdict(int)
        domain_rows = conn.execute(
            "SELECT domains FROM cross_domain_questions WHERE domains != ''"
        ).fetchall()
        for row in domain_rows:
            try:
                for d in json.loads(row["domains"]):
                    domain_counts[d] += 1
            except (json.JSONDecodeError, TypeError):
                pass

        return {
            "total_questions": total,
            "questions_today": today_count,
            "budget_remaining": max(0, QUESTION_BUDGET_PER_DAY - today_count),
            "rating_breakdown": rating_map,
            "trigger_breakdown": trigger_map,
            "domain_frequency": dict(domain_counts),
            "unrated": total - sum(rating_map.values()),
        }


# ---------------------------------------------------------------------------
# Tier 1: Domain aggregator nodes
# ---------------------------------------------------------------------------

def _fetch_events(domain: str, hours: float = 24, db_path: str = DB_PATH) -> list[dict]:
    """Fetch pattern_bus_events for a domain within the time window."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM pattern_bus_events WHERE domain = ? AND timestamp >= ? ORDER BY timestamp",
                (domain, cutoff)
            ).fetchall()
            return [dict(r) for r in rows]
    except Exception as e:
        log.warning("Failed to fetch events for %s: %s", domain, e)
        return []


def _fetch_baseline(domain: str, days: int = BASELINE_DAYS, db_path: str = DB_PATH) -> list[float]:
    """Fetch daily event counts for the rolling baseline period.

    Returns a list of daily counts (one per day) for the past N days,
    excluding today.
    """
    now = datetime.now(timezone.utc)
    daily_counts = []
    for day_offset in range(1, days + 1):
        day_start = (now - timedelta(days=day_offset)).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        day_end = day_start + timedelta(days=1)
        try:
            with sqlite3.connect(db_path) as conn:
                row = conn.execute(
                    "SELECT COUNT(*) as c FROM pattern_bus_events "
                    "WHERE domain = ? AND timestamp >= ? AND timestamp < ?",
                    (domain, day_start.isoformat(), day_end.isoformat())
                ).fetchone()
                daily_counts.append(float(row[0]) if row else 0.0)
        except Exception:
            daily_counts.append(0.0)
    return daily_counts


def _fetch_workflow_runs(hours: float = 24, db_path: str = DB_PATH) -> list[dict]:
    """Fetch recent workflow runs."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM workflow_runs WHERE started_at >= ? ORDER BY started_at",
                (cutoff,)
            ).fetchall()
            return [dict(r) for r in rows]
    except Exception as e:
        log.warning("Failed to fetch workflow runs: %s", e)
        return []


def _fetch_memory_changes(hours: float = 24, db_path: str = DB_PATH) -> list[dict]:
    """Fetch memories updated within the time window."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT id, name, type, updated FROM memories WHERE updated >= ? ORDER BY updated",
                (cutoff,)
            ).fetchall()
            return [dict(r) for r in rows]
    except Exception as e:
        log.warning("Failed to fetch memory changes: %s", e)
        return []


def security_scanner_aggregator(db_path: str = DB_PATH) -> dict:
    """Aggregate Security Scanner domain activity."""
    events = _fetch_events("security_scanner", hours=24, db_path=db_path)
    baseline = _fetch_baseline("security_scanner", db_path=db_path)

    # Categorize events by type
    by_type: dict[str, int] = defaultdict(int)
    for e in events:
        by_type[e.get("event_type", "unknown")] += 1

    return {
        "domain": "security_scanner",
        "event_count": len(events),
        "baseline_daily": baseline,
        "by_type": dict(by_type),
        "events": events,
        "top_event_type": max(by_type, key=by_type.get) if by_type else None,
    }


def analytics_aggregator(db_path: str = DB_PATH) -> dict:
    """Aggregate trading/finance domain activity."""
    events = _fetch_events("analytics", hours=24, db_path=db_path)
    baseline = _fetch_baseline("analytics", db_path=db_path)

    by_type: dict[str, int] = defaultdict(int)
    for e in events:
        by_type[e.get("event_type", "unknown")] += 1

    return {
        "domain": "analytics",
        "event_count": len(events),
        "baseline_daily": baseline,
        "by_type": dict(by_type),
        "events": events,
        "top_event_type": max(by_type, key=by_type.get) if by_type else None,
    }


def aibrain_aggregator(db_path: str = DB_PATH) -> dict:
    """Aggregate AIBrain domain activity — events + workflow runs + memory changes."""
    events = _fetch_events("aibrain", hours=24, db_path=db_path)
    baseline = _fetch_baseline("aibrain", db_path=db_path)
    workflow_runs = _fetch_workflow_runs(hours=24, db_path=db_path)
    memory_changes = _fetch_memory_changes(hours=24, db_path=db_path)

    by_type: dict[str, int] = defaultdict(int)
    for e in events:
        by_type[e.get("event_type", "unknown")] += 1

    return {
        "domain": "aibrain",
        "event_count": len(events),
        "baseline_daily": baseline,
        "by_type": dict(by_type),
        "events": events,
        "workflow_runs": len(workflow_runs),
        "memory_changes": len(memory_changes),
        "workflow_details": workflow_runs,
        "memory_details": memory_changes,
        "top_event_type": max(by_type, key=by_type.get) if by_type else None,
    }


# ---------------------------------------------------------------------------
# Tier 2: Detector nodes
# ---------------------------------------------------------------------------

def _z_score(value: float, baseline: list[float]) -> float:
    """Calculate z-score of value against baseline.

    Returns 0.0 if baseline has insufficient data or zero variance.
    """
    if len(baseline) < 2:
        return 0.0
    mean = sum(baseline) / len(baseline)
    variance = sum((x - mean) ** 2 for x in baseline) / len(baseline)
    std = math.sqrt(variance)
    if std == 0:
        # No variance — if value equals mean, z=0; otherwise flag it
        return 0.0 if value == mean else (3.0 if value > mean else -3.0)
    return (value - mean) / std


def anomaly_detector(aggregations: dict[str, dict],
                     threshold: float = Z_SCORE_THRESHOLD) -> list[dict]:
    """Detect anomalies via z-score against 7-day rolling baseline.

    Only events exceeding the threshold (default 2.0 SD) produce anomalies.
    """
    anomalies = []
    for domain, agg in aggregations.items():
        count = agg["event_count"]
        baseline = agg.get("baseline_daily", [])
        z = _z_score(float(count), baseline)
        mean = sum(baseline) / len(baseline) if baseline else 0.0

        agg["z_score"] = round(z, 2)
        agg["baseline_mean"] = round(mean, 1)

        if abs(z) >= threshold:
            multiplier = round(count / mean, 1) if mean > 0 else count
            anomalies.append({
                "domain": domain,
                "z_score": round(z, 2),
                "event_count": count,
                "baseline_mean": round(mean, 1),
                "multiplier": multiplier,
                "top_event_type": agg.get("top_event_type", "unknown"),
                "by_type": agg.get("by_type", {}),
            })
            log.info("Anomaly: %s z=%.2f (count=%d, mean=%.1f)", domain, z, count, mean)

    return anomalies


def correlation_detector(aggregations: dict[str, dict],
                         window_minutes: int = CORRELATION_WINDOW_MINUTES) -> list[dict]:
    """Detect temporal co-occurrence of events across domains.

    Fires when events from 2+ domains occur within the same time window.
    Uses actual event timestamps, not just counts.
    """
    correlations = []
    window = timedelta(minutes=window_minutes)

    # Build flat timeline of all events across domains
    timeline: list[dict] = []
    for domain, agg in aggregations.items():
        for event in agg.get("events", []):
            ts_raw = event.get("timestamp", "")
            try:
                if isinstance(ts_raw, str):
                    # Handle various ISO formats
                    ts = datetime.fromisoformat(ts_raw.replace("Z", "+00:00"))
                else:
                    ts = ts_raw
                timeline.append({
                    "domain": domain,
                    "timestamp": ts,
                    "event_type": event.get("event_type", "unknown"),
                    "key": event.get("key", ""),
                })
            except (ValueError, TypeError):
                continue

    if len(timeline) < 2:
        return []

    # Sort by timestamp
    timeline.sort(key=lambda e: e["timestamp"])

    # Sliding window: find clusters with 2+ domains
    seen_pairs: set[tuple] = set()
    for i, event_a in enumerate(timeline):
        window_end = event_a["timestamp"] + window
        co_occurring_domains: dict[str, dict] = {event_a["domain"]: event_a}

        for j in range(i + 1, len(timeline)):
            event_b = timeline[j]
            if event_b["timestamp"] > window_end:
                break
            if event_b["domain"] != event_a["domain"]:
                co_occurring_domains[event_b["domain"]] = event_b

        if len(co_occurring_domains) >= 2:
            domains_key = tuple(sorted(co_occurring_domains.keys()))
            if domains_key not in seen_pairs:
                seen_pairs.add(domains_key)
                domain_list = sorted(co_occurring_domains.keys())
                events_detail = {
                    d: {
                        "event_type": e["event_type"],
                        "key": e["key"],
                        "timestamp": e["timestamp"].isoformat() if hasattr(e["timestamp"], "isoformat") else str(e["timestamp"]),
                    }
                    for d, e in co_occurring_domains.items()
                }
                correlations.append({
                    "domains": domain_list,
                    "domain_count": len(domain_list),
                    "window_minutes": window_minutes,
                    "events": events_detail,
                })
                log.info("Correlation: %s within %d-min window", domain_list, window_minutes)

    return correlations


# ---------------------------------------------------------------------------
# Tier 3: Question generator
# ---------------------------------------------------------------------------

def _pick_cause(domain: str, idx: int = 0) -> str:
    """Pick a plausible cause hint for a domain."""
    hints = DOMAIN_CAUSE_HINTS.get(domain, ["an external change"])
    return hints[idx % len(hints)]


def generate_questions(anomalies: list[dict], correlations: list[dict],
                       budget_remaining: int) -> list[dict]:
    """Generate cross-domain questions from detected anomalies and correlations.

    Template-based — no LLM needed. Respects daily question budget.
    """
    if budget_remaining <= 0:
        log.info("Question budget exhausted for today")
        return []

    questions: list[dict] = []

    # Generate anomaly questions (higher priority — direct signal)
    for i, anomaly in enumerate(anomalies):
        if len(questions) >= budget_remaining:
            break

        domain = anomaly["domain"]
        count = anomaly["event_count"]
        mean = anomaly["baseline_mean"]
        multiplier = anomaly["multiplier"]
        top_type = anomaly.get("top_event_type", "unknown")

        # Rotate through templates
        template_idx = i % len(ANOMALY_TEMPLATES)
        template = ANOMALY_TEMPLATES[template_idx]

        if template_idx == 0:
            q = template.format(domain=domain, multiplier=multiplier)
        elif template_idx == 1:
            q = template.format(
                domain=domain, count=count, event_type=top_type,
                avg=mean, possible_cause=_pick_cause(domain, i)
            )
        else:
            detail = f"{count} events (z-score {anomaly['z_score']}), dominated by '{top_type}'"
            q = template.format(domain=domain, detail=detail)

        questions.append({
            "question": q,
            "domains": [domain],
            "trigger_type": "anomaly",
            "context": anomaly,
        })

    # Generate correlation questions
    for i, corr in enumerate(correlations):
        if len(questions) >= budget_remaining:
            break

        domain_list = corr["domains"]
        events = corr.get("events", {})
        template_idx = i % len(CORRELATION_TEMPLATES)
        template = CORRELATION_TEMPLATES[template_idx]

        if template_idx == 0 and len(domain_list) >= 2:
            q = template.format(
                domain_a=domain_list[0], domain_b=domain_list[1],
                window=corr["window_minutes"]
            )
        elif template_idx == 1 and len(domain_list) >= 2:
            event_a = events.get(domain_list[0], {}).get("event_type", "activity")
            event_b = events.get(domain_list[1], {}).get("event_type", "activity")
            q = template.format(
                domain_a=domain_list[0], event_a=event_a,
                domain_b=domain_list[1], event_b=event_b
            )
        else:
            q = template.format(
                count=len(domain_list),
                domains=", ".join(domain_list)
            )

        questions.append({
            "question": q,
            "domains": domain_list,
            "trigger_type": "correlation",
            "context": corr,
        })

    return questions[:budget_remaining]


# ---------------------------------------------------------------------------
# Full pipeline
# ---------------------------------------------------------------------------

def run_pipeline(dry_run: bool = False, db_path: str = DB_PATH,
                 z_threshold: float = Z_SCORE_THRESHOLD,
                 corr_window: int = CORRELATION_WINDOW_MINUTES,
                 budget: int = QUESTION_BUDGET_PER_DAY) -> dict:
    """Run the full 6-node pipeline: aggregate -> detect -> generate -> save.

    Returns a result dict with all intermediate data for inspection.
    """
    ensure_questions_table(db_path)
    now = datetime.now(timezone.utc)

    # --- Tier 1: Aggregation ---
    aggregations = {
        "security_scanner": security_scanner_aggregator(db_path),
        "analytics": analytics_aggregator(db_path),
        "aibrain": aibrain_aggregator(db_path),
    }

    # --- Tier 2: Detection ---
    anomalies = anomaly_detector(aggregations, threshold=z_threshold)
    correlations = correlation_detector(aggregations, window_minutes=corr_window)

    # --- Budget check ---
    already_today = get_questions_today(db_path)
    budget_remaining = max(0, budget - already_today)

    # --- Tier 3: Question generation ---
    new_questions = generate_questions(anomalies, correlations, budget_remaining)

    # --- Persist ---
    saved_ids = []
    if not dry_run:
        for q in new_questions:
            qid = save_question(
                question=q["question"],
                context=q["context"],
                domains=q["domains"],
                trigger_type=q["trigger_type"],
                db_path=db_path,
            )
            saved_ids.append(qid)

    # --- Stats ---
    stats = get_question_stats(db_path)

    result = {
        "timestamp": now.isoformat(),
        "dry_run": dry_run,
        "aggregations": {
            d: {
                "event_count": a["event_count"],
                "baseline_mean": a.get("baseline_mean", 0),
                "z_score": a.get("z_score", 0),
            }
            for d, a in aggregations.items()
        },
        "anomalies_detected": len(anomalies),
        "anomalies": anomalies,
        "correlations_detected": len(correlations),
        "correlations": correlations,
        "questions_generated": len(new_questions),
        "questions": [q["question"] for q in new_questions],
        "saved_ids": saved_ids,
        "stats": stats,
    }

    return result


# ---------------------------------------------------------------------------
# CLI output formatting
# ---------------------------------------------------------------------------

def format_report(result: dict) -> str:
    """Format pipeline result as human-readable report."""
    now = datetime.now()
    lines = [
        f"CROSS-DOMAIN ANALYSIS — {now.strftime('%A %B %d, %Y')}",
        "=" * 58,
    ]

    # Domain activity
    lines.append("Domain activity (last 24h):")
    for domain in DOMAINS:
        agg = result["aggregations"].get(domain, {})
        count = agg.get("event_count", 0)
        mean = agg.get("baseline_mean", 0)
        z = agg.get("z_score", 0)
        lines.append(f"  {domain}: {count} events (baseline: {mean}, z-score: {z})")

    lines.append("")

    # Anomalies
    anom_count = result["anomalies_detected"]
    lines.append(f"Anomalies detected: {anom_count} (threshold: z > {Z_SCORE_THRESHOLD})")
    for a in result.get("anomalies", []):
        lines.append(f"  * {a['domain']}: z={a['z_score']}, count={a['event_count']}, "
                     f"mean={a['baseline_mean']}, {a['multiplier']}x spike")

    # Correlations
    corr_count = result["correlations_detected"]
    lines.append(f"Correlations detected: {corr_count}")
    for c in result.get("correlations", []):
        lines.append(f"  * {', '.join(c['domains'])} within {c['window_minutes']}-min window")

    lines.append("")

    # Questions
    stats = result.get("stats", {})
    today = stats.get("questions_today", 0)
    total = stats.get("total_questions", 0)
    ratings = stats.get("rating_breakdown", {})
    lines.append(f"Questions generated today: {today} (budget: {QUESTION_BUDGET_PER_DAY})")
    lines.append(f"Total questions ever: {total}")
    lines.append(
        f"Rating breakdown: {ratings.get('useful', 0)} useful, "
        f"{ratings.get('noise', 0)} noise, {ratings.get('brilliant', 0)} brilliant"
    )

    lines.append("")

    new_qs = result.get("questions", [])
    if new_qs:
        lines.append("New questions:")
        for i, q in enumerate(new_qs, 1):
            prefix = "  [DRY-RUN]" if result.get("dry_run") else f"  [#{result['saved_ids'][i-1]}]"
            lines.append(f"  {prefix} {q}")
    else:
        lines.append("No new questions generated this run.")

    lines.append("=" * 58)
    return "\n".join(lines)


def format_recent(questions: list[dict]) -> str:
    """Format recent questions for display."""
    if not questions:
        return "No questions found."
    lines = ["Recent cross-domain questions:", "-" * 50]
    for q in questions:
        rating_tag = f" [{q['rating']}]" if q.get("rating") else ""
        acted_tag = " (acted on)" if q.get("acted_on") else ""
        domains = json.loads(q["domains"]) if q.get("domains") else []
        lines.append(
            f"  #{q['id']} [{q['trigger_type']}]{rating_tag}{acted_tag} "
            f"({', '.join(domains)})"
        )
        lines.append(f"    {q['question']}")
        lines.append(f"    Created: {q['created']}")
        lines.append("")
    return "\n".join(lines)


def format_stats(stats: dict) -> str:
    """Format stats for display."""
    lines = [
        "Cross-Domain Question Stats",
        "-" * 40,
        f"Total questions: {stats['total_questions']}",
        f"Generated today: {stats['questions_today']}",
        f"Budget remaining: {stats['budget_remaining']}",
        "",
        "Rating breakdown:",
    ]
    for rating in ["useful", "noise", "brilliant"]:
        count = stats.get("rating_breakdown", {}).get(rating, 0)
        lines.append(f"  {rating}: {count}")
    lines.append(f"  unrated: {stats.get('unrated', 0)}")

    lines.append("")
    lines.append("By trigger type:")
    for ttype, count in stats.get("trigger_breakdown", {}).items():
        lines.append(f"  {ttype}: {count}")

    lines.append("")
    lines.append("Domain frequency:")
    for domain, count in sorted(stats.get("domain_frequency", {}).items(), key=lambda x: -x[1]):
        lines.append(f"  {domain}: {count}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# FastAPI router — GET /api/agent/questions, POST /api/agent/questions/{id}/rate
# ---------------------------------------------------------------------------

def create_router():
    """Create FastAPI router for cross-domain questions API.

    Import lazily to avoid requiring FastAPI when running CLI-only.
    """
    from fastapi import APIRouter, Query as FQuery
    from fastapi.responses import JSONResponse

    qrouter = APIRouter(prefix="/api/agent/questions", tags=["Cross-Domain Questions"])

    @qrouter.get("")
    async def list_questions(limit: int = FQuery(default=20, ge=1, le=100)):
        """List recent cross-domain questions."""
        ensure_questions_table()
        questions = get_recent_questions(limit=limit)
        stats = get_question_stats()
        return JSONResponse({"questions": questions, "stats": stats})

    @qrouter.post("/{question_id}/rate")
    async def rate_question_api(question_id: int, rating: str = FQuery(...)):
        """Rate a question: useful, noise, or brilliant."""
        ensure_questions_table()
        ok = rate_question(question_id, rating)
        if not ok:
            return JSONResponse({"error": "Question not found or invalid rating"}, status_code=404)
        return JSONResponse({"ok": True, "id": question_id, "rating": rating})

    @qrouter.post("/scan")
    async def trigger_scan(dry_run: bool = FQuery(default=False)):
        """Run the cross-domain analysis pipeline."""
        result = run_pipeline(dry_run=dry_run)
        return JSONResponse(result)

    @qrouter.get("/stats")
    async def question_stats():
        """Get question generation stats."""
        ensure_questions_table()
        return JSONResponse(get_question_stats())

    return qrouter


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Cross-Domain Question Generator — the Pixel Moment substrate"
    )
    parser.add_argument("--scan", action="store_true", help="Run full pipeline: aggregate -> detect -> generate -> save")
    parser.add_argument("--dry-run", action="store_true", help="Analyze but don't save questions to DB")
    parser.add_argument("--recent", action="store_true", help="Show recent questions")
    parser.add_argument("--rate", nargs=2, metavar=("ID", "RATING"), help="Rate a question (useful/noise/brilliant)")
    parser.add_argument("--stats", action="store_true", help="Show generation stats and rating breakdown")
    parser.add_argument("--db", default=DB_PATH, help="Database path (default: aibrain.db)")
    parser.add_argument("--z-threshold", type=float, default=Z_SCORE_THRESHOLD, help="Z-score anomaly threshold")
    parser.add_argument("--window", type=int, default=CORRELATION_WINDOW_MINUTES, help="Correlation window in minutes")
    parser.add_argument("--budget", type=int, default=QUESTION_BUDGET_PER_DAY, help="Max questions per day")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s %(levelname)s %(message)s")
    else:
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    db = args.db

    if args.rate:
        ensure_questions_table(db)
        qid = int(args.rate[0])
        rating = args.rate[1]
        ok = rate_question(qid, rating, db)
        if ok:
            print(f"Question #{qid} rated as '{rating}'")
        else:
            print(f"Failed to rate question #{qid}")
        return

    if args.recent:
        ensure_questions_table(db)
        questions = get_recent_questions(db_path=db)
        print(format_recent(questions))
        return

    if args.stats:
        ensure_questions_table(db)
        stats = get_question_stats(db)
        print(format_stats(stats))
        return

    if args.scan or args.dry_run:
        result = run_pipeline(
            dry_run=args.dry_run,
            db_path=db,
            z_threshold=args.z_threshold,
            corr_window=args.window,
            budget=args.budget,
        )
        print(format_report(result))
        log_activity("cross_domain_questions",
                     f"{result['anomalies_detected']} anomalies, {result['questions_generated']} questions generated")
        return

    # Default: run scan
    result = run_pipeline(dry_run=False, db_path=db)
    print(format_report(result))

    log_activity("cross_domain_questions",
                 f"{result['anomalies_detected']} anomalies, {result['questions_generated']} questions generated")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='cross_domain_questions',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
