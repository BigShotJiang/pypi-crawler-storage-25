#!/usr/bin/env python3
"""AIBrain Workflow: Job Search & Apply — search jobs via Playwright browser, track applications.

Sources:
  - Indeed (AU + US/UK) via Playwright browser
  - Seek (AU) via Playwright browser
  - HN Who is Hiring (supplementary, via API)

Configure search queries in config.json under "job_queries" key.
If no queries configured, uses example defaults (override in config.json).
"""

import argparse
import datetime
import hashlib
import json
import os
import re
import smtplib
import sqlite3
import sys
import time
import xml.etree.ElementTree as ET
from email.mime.text import MIMEText
from pathlib import Path
from urllib.parse import quote_plus, urlencode

import requests

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# Playwright availability check — graceful fallback if not installed
_PLAYWRIGHT_AVAILABLE = False
try:
    import playwright  # noqa: F401 — probe only, actual use is via browser_pool
    _PLAYWRIGHT_AVAILABLE = True
except ImportError:
    print("WARNING: playwright not available — Indeed and Seek searches will be skipped.",
          file=sys.stderr)
    print("Install with: pip install playwright && playwright install chromium", file=sys.stderr)

# Browser pool — single-browser pool (size=1) with anti-detection args, reused
# across all searches in this process.  Pool is shut down in _close_browser().
_BROWSER_POOL = None
_POOL_LOCK = __import__("threading").Lock()

_LAUNCH_KWARGS = dict(
    headless=False,
    args=[
        "--window-position=-2400,-2400",
        "--disable-blink-features=AutomationControlled",
        "--disable-features=IsolateOrigins,site-per-process",
        "--no-first-run",
        "--no-default-browser-check",
    ],
)

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = {}
if _cfg_path.exists():
    try:
        CONFIG = json.loads(_cfg_path.read_text(encoding="utf-8"))
    except Exception:
        pass

def _find_db():
    """Find best DB path, checking both old and new names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    # Fallback to memory/memory.db for older installs
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())

# Realistic browser headers (used only for HN API requests now)
_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-AU,en-US;q=0.9,en;q=0.8",
}


def _get_pool():
    """Return the module-level BrowserPool, creating it on first call."""
    global _BROWSER_POOL
    if _BROWSER_POOL is None and _PLAYWRIGHT_AVAILABLE:
        with _POOL_LOCK:
            if _BROWSER_POOL is None:
                from aibrain.core.browser_pool import BrowserPool
                _BROWSER_POOL = BrowserPool(size=1, **_LAUNCH_KWARGS)
    return _BROWSER_POOL


def _get_browser():
    """Checkout a browser from the pool (caller must call _checkin_browser)."""
    pool = _get_pool()
    if pool is None:
        return None
    ctx = pool.checkout(timeout=60)
    # Return the raw browser; caller pairs this with _checkin_browser().
    return ctx._browser


def _checkin_browser(browser) -> None:
    """Return a checked-out browser to the pool."""
    pool = _get_pool()
    if pool is not None and browser is not None:
        pool.checkin(browser)


def _close_browser():
    """Shut down the browser pool (called at process exit)."""
    global _BROWSER_POOL
    with _POOL_LOCK:
        if _BROWSER_POOL is not None:
            _BROWSER_POOL.shutdown()
            _BROWSER_POOL = None

# ---------------------------------------------------------------------------
# Search configuration — what to search for and where
# ---------------------------------------------------------------------------
# Default example queries — override in config.json "job_queries" key
_DEFAULT_QUERIES = [
    {"query": "software engineer", "location": "Remote", "country": "us"},
]

SEARCH_QUERIES = CONFIG.get("job_queries", _DEFAULT_QUERIES)

if not CONFIG.get("job_queries"):
    print("NOTE: Using default job queries. Configure 'job_queries' in config.json for your search.",
          file=sys.stderr)

# Keywords for HN filtering — override in config.json "job_keywords" key
_DEFAULT_HN_KEYWORDS = ["remote", "engineer", "developer"]
HN_KEYWORDS = CONFIG.get("job_keywords", _DEFAULT_HN_KEYWORDS)


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def _make_job_id(source, unique_key):
    """Generate a stable short ID for deduplication."""
    return hashlib.md5(f"{source}:{unique_key}".encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------
# Indeed search via Playwright headless browser (Cloudflare blocks HTTP)
# ---------------------------------------------------------------------------

def search_indeed(query, location, country="au"):
    """Search Indeed using Playwright headless browser to bypass Cloudflare."""
    jobs = []
    if not _PLAYWRIGHT_AVAILABLE:
        print(f"  Indeed ({country}) SKIPPED — Playwright not available", file=sys.stderr)
        return jobs

    base_urls = {
        "au": "https://au.indeed.com",
        "us": "https://www.indeed.com",
        "gb": "https://www.indeed.co.uk",
    }
    base = base_urls.get(country, base_urls["au"])

    params = {
        "q": query,
        "l": location,
        "sort": "date",
        "fromage": "7",
    }
    url = f"{base}/jobs?{urlencode(params)}"

    browser = _get_browser()
    if browser is None:
        return jobs
    try:
        page = browser.new_page(
            user_agent=_HEADERS["User-Agent"],
            locale="en-AU",
        )
        page.set_default_timeout(20000)
        try:
            page.goto(url, wait_until="domcontentloaded")

            # Wait for job cards to appear (try multiple selectors)
            try:
                page.wait_for_selector(
                    'div.job_seen_beacon, div[data-testid="job-card"]',
                    timeout=10000,
                )
            except Exception:
                # Page may have loaded but with no results or different layout
                pass

            # Extract job cards using multiple selector strategies
            cards = page.query_selector_all('div.job_seen_beacon, div[data-testid="job-card"]')

            for card in cards:
                try:
                    # Title and link
                    title_el = card.query_selector('h2.jobTitle a, a[data-testid="job-title"]')
                    if not title_el:
                        continue
                    title = title_el.inner_text().strip()
                    href = title_el.get_attribute("href") or ""
                    if href and not href.startswith("http"):
                        href = f"{base}{href}"

                    # Company name
                    company_el = card.query_selector(
                        '[data-testid="company-name"], span.companyName, '
                        'span[data-testid="company-name"]'
                    )
                    company = company_el.inner_text().strip() if company_el else ""

                    # Location
                    loc_el = card.query_selector(
                        '[data-testid="text-location"], div.companyLocation, '
                        'span[data-testid="text-location"]'
                    )
                    job_loc = loc_el.inner_text().strip() if loc_el else location

                    # Snippet / preview
                    snippet_el = card.query_selector(
                        'div.job-snippet, ul.jobCardShelfContainer, '
                        '[data-testid="jobDescriptionSnippet"]'
                    )
                    preview = snippet_el.inner_text().strip()[:200] if snippet_el else ""

                    if not title or not href:
                        continue

                    jobs.append({
                        "title": f"{title} — {company}" if company else title,
                        "company": company,
                        "location": job_loc,
                        "source": f"Indeed ({country.upper()})",
                        "url": href,
                        "preview": preview,
                        "date": "",
                        "id": _make_job_id("indeed", href),
                    })
                except Exception:
                    continue  # Skip individual card extraction errors
        except Exception as e:
            print(f"  Indeed ({country}) browser error for '{query}': {e}", file=sys.stderr)
        finally:
            page.close()
    finally:
        _checkin_browser(browser)

    return jobs


# ---------------------------------------------------------------------------
# Seek search via Playwright headless browser (Cloudflare blocks HTTP)
# ---------------------------------------------------------------------------

def search_seek(query, location="All Australia"):
    """Search Seek.com.au using Playwright headless browser to bypass Cloudflare."""
    jobs = []
    if not _PLAYWRIGHT_AVAILABLE:
        print(f"  Seek SKIPPED — Playwright not available", file=sys.stderr)
        return jobs

    # Build Seek search URL
    kw_slug = quote_plus(query)
    loc_slug = quote_plus(location)
    url = f"https://www.seek.com.au/{kw_slug}-jobs/in-{loc_slug}?sortmode=ListedDate"

    browser = _get_browser()
    if browser is None:
        return jobs
    try:
        page = browser.new_page(
            user_agent=_HEADERS["User-Agent"],
            locale="en-AU",
        )
        page.set_default_timeout(20000)
        try:
            page.goto(url, wait_until="domcontentloaded")

            # Wait for job cards to render
            try:
                page.wait_for_selector(
                    'article[data-testid^="job-card"]',
                    timeout=10000,
                )
            except Exception:
                # No results or different layout — return empty
                return jobs

            cards = page.query_selector_all('article[data-testid^="job-card"]')

            for card in cards:
                try:
                    # Title and link
                    title_el = card.query_selector('a[data-testid="job-card-title"]')
                    if not title_el:
                        continue
                    title = title_el.inner_text().strip()
                    href = title_el.get_attribute("href") or ""
                    if href and not href.startswith("http"):
                        href = f"https://www.seek.com.au{href}"

                    # Company name
                    company_el = card.query_selector(
                        'a[data-testid="job-card-company"], '
                        '[data-testid="job-card-company"]'
                    )
                    company = company_el.inner_text().strip() if company_el else ""

                    # Location
                    loc_el = card.query_selector(
                        'a[data-testid="job-card-location"], '
                        '[data-testid="job-card-location"]'
                    )
                    job_loc = loc_el.inner_text().strip() if loc_el else location

                    # Teaser / preview
                    teaser_el = card.query_selector('[data-testid="job-card-teaser"]')
                    teaser = teaser_el.inner_text().strip()[:200] if teaser_el else ""

                    # Extract job ID from URL for dedup
                    job_id_match = re.search(r'/job/(\d+)', href)
                    job_key = job_id_match.group(1) if job_id_match else href

                    if not title or not href:
                        continue

                    jobs.append({
                        "title": f"{title} — {company}" if company else title,
                        "company": company,
                        "location": job_loc,
                        "source": "Seek",
                        "url": href,
                        "preview": teaser,
                        "date": "",
                        "id": _make_job_id("seek", job_key),
                    })
                except Exception:
                    continue  # Skip individual card extraction errors
        except Exception as e:
            print(f"  Seek browser error for '{query}': {e}", file=sys.stderr)
        finally:
            page.close()
    finally:
        _checkin_browser(browser)

    return jobs


# ---------------------------------------------------------------------------
# HN Who is Hiring (supplementary — monthly thread)
# ---------------------------------------------------------------------------

def search_hn_hiring(keywords):
    """Search HN 'Who is Hiring' threads."""
    jobs = []
    try:
        resp = requests.get(
            "https://hn.algolia.com/api/v1/search?query=who+is+hiring&tags=ask_hn&numericFilters=created_at_i>%d" %
            int((datetime.datetime.now() - datetime.timedelta(days=35)).timestamp()),
            timeout=10,
        )
        threads = resp.json().get("hits", [])
        if not threads:
            return jobs

        thread_id = threads[0]["objectID"]
        resp = requests.get(f"https://hn.algolia.com/api/v1/items/{thread_id}", timeout=15)
        children = resp.json().get("children", [])

        for child in children[:200]:  # Check more comments for security roles
            text = child.get("text", "")
            if not text:
                continue
            text_lower = text.lower()
            if any(kw.lower() in text_lower for kw in keywords):
                first_line = text.split("<p>")[0].split("|")[0].strip()[:80]
                # Clean HTML
                first_line = re.sub(r"<[^>]+>", "", first_line)
                jobs.append({
                    "title": first_line,
                    "company": "",
                    "location": "",
                    "source": "HN Hiring",
                    "url": f"https://news.ycombinator.com/item?id={child.get('id', '')}",
                    "preview": re.sub(r"<[^>]+>", " ", text[:200]).replace("&#x27;", "'"),
                    "date": "",
                    "id": _make_job_id("hn", str(child.get("id", ""))),
                })
    except Exception as e:
        print(f"  HN hiring search error: {e}", file=sys.stderr)
    return jobs


# ---------------------------------------------------------------------------
# Aggregation + deduplication
# ---------------------------------------------------------------------------

def run_all_searches():
    """Run all configured searches across all platforms."""
    all_jobs = []
    seen_urls = set()

    # Indeed + Seek searches from configured queries
    for i, sq in enumerate(SEARCH_QUERIES):
        query = sq["query"]
        location = sq["location"]
        country = sq.get("country", "au")

        print(f"  [{i+1}/{len(SEARCH_QUERIES)}] {query} / {location} ({country.upper()})")

        # Indeed (works for AU, US, GB)
        indeed_jobs = search_indeed(query, location, country)
        for j in indeed_jobs:
            if j["url"] not in seen_urls:
                seen_urls.add(j["url"])
                all_jobs.append(j)

        # Seek (AU only)
        if country == "au":
            seek_jobs = search_seek(query, location)
            for j in seek_jobs:
                if j["url"] not in seen_urls:
                    seen_urls.add(j["url"])
                    all_jobs.append(j)

        # Rate limit: 1 request per second to be respectful
        time.sleep(1)

    # HN Who is Hiring (single query, keyword-filtered)
    print(f"  [HN] Scanning Who is Hiring thread...")
    hn_jobs = search_hn_hiring(HN_KEYWORDS)
    for j in hn_jobs:
        if j["url"] not in seen_urls:
            seen_urls.add(j["url"])
            all_jobs.append(j)

    return all_jobs


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def format_report(jobs, applied, seen_ids):
    new_jobs = [j for j in jobs if j["id"] not in seen_ids]

    # Group new jobs by source
    by_source = {}
    for j in new_jobs:
        by_source.setdefault(j["source"], []).append(j)

    lines = [
        f"JOB SEARCH REPORT -- {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        f"New listings: {len(new_jobs)} | Total scanned: {len(jobs)} | Applied: {len(applied)}",
        "=" * 60,
        "",
    ]

    if new_jobs:
        for source, source_jobs in sorted(by_source.items()):
            lines.append(f"--- {source} ({len(source_jobs)} new) ---")
            for j in source_jobs[:20]:
                lines.append(f"  {j['title']}")
                if j.get("location"):
                    lines.append(f"  Location: {j['location']}")
                lines.append(f"  {j['url']}")
                if j.get("preview"):
                    lines.append(f"  {j['preview'][:120]}...")
                lines.append("")
    else:
        lines.append("No new listings matching your criteria.")
        lines.append("")

    if applied:
        lines.append(f"APPLICATION TRACKER ({len(applied)} total)")
        for app in list(applied.values())[-5:]:
            status = app.get("status", "applied")
            lines.append(f"  {app['date']}  {app['title'][:40]:40s}  [{status}]")
        lines.append("")

    lines.append("--")
    lines.append("Powered by AIBrain (Indeed + Seek via Playwright + HN Hiring)")
    return "\n".join(lines), len(new_jobs)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="AIBrain Job Search")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print report instead of emailing")
    parser.add_argument("--track", nargs=2, metavar=("TITLE", "URL"),
                        help="Track an application")
    parser.add_argument("--source", choices=["indeed", "seek", "hn", "all"],
                        default="all", help="Search specific source only")
    args = parser.parse_args()

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("job_search")
    seen_ids = set(list(state.get("seen_ids", []))[-1000:])
    applied = state.get("applied", {})

    if args.track:
        app_id = hashlib.md5(args.track[1].encode()).hexdigest()[:12]
        applied[app_id] = {
            "title": args.track[0],
            "url": args.track[1],
            "date": datetime.date.today().isoformat(),
            "status": "applied",
        }
        state["applied"] = applied
        save_state("job_search", state)
        print(f"Tracking: {args.track[0]}")
        return

    print(f"Running job search across {len(SEARCH_QUERIES)} queries...")
    print(f"Sources: Indeed (AU/US/UK) + Seek (AU) + HN Hiring")
    print()

    if args.source == "all":
        jobs = run_all_searches()
    elif args.source == "indeed":
        jobs = []
        for sq in SEARCH_QUERIES:
            jobs.extend(search_indeed(sq["query"], sq["location"], sq.get("country", "au")))
            time.sleep(1)
    elif args.source == "seek":
        jobs = []
        for sq in SEARCH_QUERIES:
            if sq.get("country", "au") == "au":
                jobs.extend(search_seek(sq["query"], sq["location"]))
                time.sleep(1)
    elif args.source == "hn":
        jobs = search_hn_hiring(HN_KEYWORDS)

    print(f"\nTotal jobs found: {len(jobs)}")

    report, new_count = format_report(jobs, applied, seen_ids)

    if not email_to or args.dry_run:
        print(report)
    elif new_count > 0:
        send_email(email_to, f"Job Search -- {new_count} new listings", report)
        print(f"Email sent to {email_to} with {new_count} new listings")
    else:
        print("No new listings to email.")

    new_ids = [j["id"] for j in jobs]
    seen_ids.update(new_ids)
    save_state("job_search", {
        "last_run": datetime.datetime.now().isoformat(),
        "seen_ids": list(seen_ids)[-1000:],
        "applied": applied,
    })
    print(f"State saved. {len(seen_ids)} total seen IDs tracked.")

    # Clean up shared browser instance
    _close_browser()


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='job_search_apply',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
