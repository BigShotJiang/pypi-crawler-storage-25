#!/usr/bin/env python3
"""SEO monitoring workflow for myaibrain.org.

Tracks SERP rankings, stores history, generates reports, pings sitemaps.

CLI:
    python seo_monitor.py check   — daily rank check (requires SERPAPI_KEY)
    python seo_monitor.py report  — weekly comparison report
    python seo_monitor.py ping    — ping sitemap to search engines
"""

import json
import os
import sqlite3
import sys
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

TARGET_SITE = "myaibrain.org"
TARGET_KEYWORDS = [
    "ai agent memory", "MCP memory server", "persistent memory for AI agents",
    "how to give AI agent memory", "brain for Claude Code", "AI agent that learns",
    "portable AI memory", "AI agent operating system", "AI brain marketplace",
    "aibrain", "myaibrain", "ai brain",
]
SITEMAP_URL = f"https://{TARGET_SITE}/sitemap.xml"
_AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                     os.environ.get("AIBRAIN_ROOT",
                     Path(__file__).parent.parent)))


def _find_db():
    for name in ["aibrain.db"]:
        p = _AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    mem_db = _AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(_AIBRAIN_ROOT / "aibrain.db")


DB_PATH = os.environ.get("AIBRAIN_DB", _find_db())
SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS seo_rankings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            site TEXT NOT NULL,
            keyword TEXT NOT NULL,
            position INTEGER,
            url TEXT,
            checked_at TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


def check_ranking(keyword: str) -> dict:
    """Query SerpAPI for keyword ranking. Returns {position, url} or None."""
    if not SERPAPI_KEY:
        return {"position": None, "url": None, "error": "no_api_key"}
    params = urllib.parse.urlencode({
        "q": keyword, "api_key": SERPAPI_KEY, "engine": "google", "num": 100
    })
    url = f"https://serpapi.com/search.json?{params}"
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        return {"position": None, "url": None, "error": str(e)}

    for result in data.get("organic_results", []):
        link = result.get("link", "")
        if TARGET_SITE in link:
            return {"position": result.get("position"), "url": link}
    return {"position": None, "url": None}


def cmd_check():
    """Run daily rank check for all keywords."""
    db = get_db()
    now = datetime.utcnow().isoformat()
    results = []

    if not SERPAPI_KEY:
        print(f"[WARN] SERPAPI_KEY not set — storing null positions for tracking.")

    for kw in TARGET_KEYWORDS:
        r = check_ranking(kw)
        db.execute(
            "INSERT INTO seo_rankings (site, keyword, position, url, checked_at) VALUES (?,?,?,?,?)",
            (TARGET_SITE, kw, r.get("position"), r.get("url"), now),
        )
        pos = r.get("position") or "—"
        results.append(f"  {kw}: #{pos}")
        print(f"  [{kw}] position={pos}")

    db.commit()
    db.close()

    summary = f"SEO check ({TARGET_SITE}) — {datetime.utcnow():%Y-%m-%d}\n"
    summary += "\n".join(results)
    print(f"\n{summary}")
    return summary


def cmd_report():
    """Generate weekly report comparing current vs 7-day-ago positions."""
    db = get_db()
    now = datetime.utcnow()
    week_ago = (now - timedelta(days=7)).isoformat()

    lines = [f"SEO Weekly Report — {TARGET_SITE} ({now:%Y-%m-%d})", "=" * 50]
    has_data = False

    for kw in TARGET_KEYWORDS:
        # Latest position
        row = db.execute(
            "SELECT position, checked_at FROM seo_rankings WHERE site=? AND keyword=? ORDER BY checked_at DESC LIMIT 1",
            (TARGET_SITE, kw),
        ).fetchone()
        # Position from ~7 days ago
        old = db.execute(
            "SELECT position FROM seo_rankings WHERE site=? AND keyword=? AND checked_at <= ? ORDER BY checked_at DESC LIMIT 1",
            (TARGET_SITE, kw, week_ago),
        ).fetchone()

        cur_pos = row[0] if row and row[0] else None
        old_pos = old[0] if old and old[0] else None

        if cur_pos is not None:
            has_data = True
            delta = ""
            if old_pos is not None:
                diff = old_pos - cur_pos  # positive = improved
                if diff > 0:
                    delta = f" (+{diff})"
                elif diff < 0:
                    delta = f" ({diff})"
            lines.append(f"  {kw}: #{cur_pos}{delta}")
        else:
            lines.append(f"  {kw}: not ranked")

    db.close()

    if not has_data:
        lines.append("\n  No ranking data yet. Run `python seo_monitor.py check` first.")

    report = "\n".join(lines)
    print(report)
    return report


def cmd_ping():
    """Ping sitemap.xml to Google and Bing."""
    engines = {
        "Google": f"https://www.google.com/ping?sitemap={urllib.parse.quote(SITEMAP_URL, safe='')}",
        "Bing": f"https://www.bing.com/indexnow?url={urllib.parse.quote(SITEMAP_URL, safe='')}",
    }
    results = []
    for name, url in engines.items():
        try:
            with urllib.request.urlopen(url, timeout=10) as resp:
                status = resp.status
            msg = f"  {name}: {status} OK"
        except Exception as e:
            msg = f"  {name}: FAILED ({e})"
        results.append(msg)
        print(msg)

    summary = f"Sitemap ping ({SITEMAP_URL}):\n" + "\n".join(results)
    return summary


def run(command: str = "check"):
    """Entry point for the harness. Runs check by default, or specify 'report'/'ping'."""
    commands = {"check": cmd_check, "report": cmd_report, "ping": cmd_ping}
    fn = commands.get(command, cmd_check)
    return fn()


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        commands = {"check": cmd_check, "report": cmd_report, "ping": cmd_ping}
        if len(sys.argv) < 2 or sys.argv[1] not in commands:
            print(f"Usage: python {sys.argv[0]} <{'|'.join(commands)}>")
            sys.exit(1)
        commands[sys.argv[1]]()
    workflow_execute(
        workflow_name='seo_monitor',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
