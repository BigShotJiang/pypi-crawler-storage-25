#!/usr/bin/env python3
"""
AIBrain Workflow: Evolution Experiment — first complete improve/measure/keep-revert cycle.

Runs a sender-reputation experiment on email_triage:
  1. Record the pattern (keyword-only classification, no sender history)
  2. Propose hypothesis (sender reputation will improve triage accuracy)
  3. Measure baseline classification distribution
  4. Build sender reputation tracker from historical triage state
  5. Run enhanced classification with reputation boosting
  6. After N runs, compare metrics and auto-decide keep/revert

Modes:
  --baseline   Measure current classification distribution only
  --dry-run    Full cycle without calling evolution API or modifying state
  --decide     Evaluate experiment and render keep/revert decision
  (default)    Run one experiment iteration: classify with reputation, record run
"""

import argparse
import datetime
import json
import os
import sqlite3
import sys
import urllib.request
import urllib.error
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & paths
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

EXPERIMENT_NAME = "sender_reputation_triage"
RUNS_TARGET = 5

# Classification buckets email_triage uses
CATEGORIES = ("urgent", "action", "fyi", "spam")

# Reputation thresholds — how much history shifts classification
REPUTATION_BOOST_THRESHOLD = 3   # need 3+ emails from sender to trust reputation
REPUTATION_OVERRIDE_RATIO = 0.7  # if 70%+ of sender's history is one category, boost

# ---------------------------------------------------------------------------
# DB helpers (same pattern as email_triage)
# ---------------------------------------------------------------------------


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute(
                "UPDATE memories SET content=?, updated=? WHERE id=?",
                (json.dumps(state), now, existing["id"]),
            )
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) "
                "VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state,evolution",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------


def api_post(endpoint, payload, dry_run=False):
    """POST JSON to the AIBrain API. Returns parsed response or None."""
    url = f"{API_BASE}/{endpoint.lstrip('/')}"
    data = json.dumps(payload).encode()
    if dry_run:
        print(f"  [dry-run] POST {url}")
        print(f"  [dry-run] body: {json.dumps(payload, indent=2)[:500]}")
        return {"dry_run": True}
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")[:300]
        print(f"  API error {e.code}: {body}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"  API unreachable: {e}", file=sys.stderr)
        return None


def api_get(endpoint):
    """GET from AIBrain API."""
    url = f"{API_BASE}/{endpoint.lstrip('/')}"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        print(f"  API GET error: {e}", file=sys.stderr)
        return None


def log_activity(action, details, dry_run=False):
    """Log to the activity API."""
    api_post("activity", {
        "action": action,
        "details": details,
        "source": "evolution_experiment",
    }, dry_run=dry_run)


# ---------------------------------------------------------------------------
# Sender reputation engine
# ---------------------------------------------------------------------------


def build_sender_reputation(triage_state):
    """
    Build sender reputation scores from historical email_triage state.

    Reads the triage state's classification history and builds a dictionary:
      sender_email -> {urgent: N, action: N, fyi: N, spam: N, total: N, dominant: str, ratio: float}
    """
    reputation = {}

    # The email_triage state stores per-run summaries. We also look at
    # any previously built reputation to accumulate over time.
    existing_rep = load_state("sender_reputation")
    if existing_rep and "senders" in existing_rep:
        reputation = existing_rep["senders"]

    # Pull classification history from the triage state
    # email_triage saves: {last_run, unread_count, urgent, action, per_account}
    # For the experiment, we also look at the raw classification log if available
    classification_log = load_state("email_triage_classifications")
    entries = classification_log.get("entries", []) if classification_log else []

    for entry in entries:
        sender = entry.get("sender_email", "").lower().strip()
        category = entry.get("category", "fyi")
        if not sender:
            continue
        if sender not in reputation:
            reputation[sender] = {c: 0 for c in CATEGORIES}
            reputation[sender]["total"] = 0
        if category in CATEGORIES:
            reputation[sender][category] += 1
            reputation[sender]["total"] += 1

    # Compute dominant category and ratio for each sender
    for sender, counts in reputation.items():
        total = counts.get("total", 0)
        if total == 0:
            counts["dominant"] = "fyi"
            counts["ratio"] = 0.0
            continue
        best_cat = max(CATEGORIES, key=lambda c: counts.get(c, 0))
        counts["dominant"] = best_cat
        counts["ratio"] = round(counts[best_cat] / total, 3)

    return reputation


def apply_reputation(sender_email, keyword_category, reputation):
    """
    Given a keyword-based classification and the sender's reputation,
    return the reputation-adjusted classification.

    Rules:
      - If sender has < REPUTATION_BOOST_THRESHOLD emails, trust keywords only
      - If sender's dominant category ratio >= REPUTATION_OVERRIDE_RATIO, boost toward it
      - Never downgrade urgent to fyi (safety constraint)
      - Can upgrade fyi to action/urgent if sender is historically urgent
    """
    sender = sender_email.lower().strip()
    rep = reputation.get(sender)

    if not rep or rep.get("total", 0) < REPUTATION_BOOST_THRESHOLD:
        return keyword_category, "keyword_only"

    dominant = rep.get("dominant", "fyi")
    ratio = rep.get("ratio", 0.0)

    if ratio < REPUTATION_OVERRIDE_RATIO:
        return keyword_category, "keyword_only"

    # Safety: never downgrade urgent
    if keyword_category == "urgent" and dominant in ("fyi", "spam"):
        return "urgent", "safety_preserved"

    # Reputation overrides keyword classification
    if dominant != keyword_category:
        return dominant, f"reputation_override({ratio:.0%})"

    return keyword_category, f"reputation_confirmed({ratio:.0%})"


# ---------------------------------------------------------------------------
# Classification with reputation (wraps email_triage.classify_email)
# ---------------------------------------------------------------------------

# Import the original classifier
sys.path.insert(0, str(Path(__file__).parent))
try:
    from email_triage import classify_email as keyword_classify
    from email_triage import URGENT_KEYWORDS, ACTION_KEYWORDS, NEWSLETTER_SENDERS
except ImportError:
    # Fallback if import fails — inline the keywords
    URGENT_KEYWORDS = {"urgent", "asap", "critical", "emergency", "down", "security", "breach", "outage"}
    ACTION_KEYWORDS = {"action", "review", "approve", "confirm", "please", "request", "deadline", "respond"}
    NEWSLETTER_SENDERS = {"noreply", "newsletter", "digest", "updates", "notification", "mailer", "no-reply"}

    def keyword_classify(sender, subject, body):
        sender_lower = sender.lower()
        subject_lower = subject.lower()
        body_lower = body.lower()[:300]
        all_text = f"{subject_lower} {body_lower}"
        if any(kw in all_text for kw in URGENT_KEYWORDS):
            return "urgent"
        if any(kw in all_text for kw in ACTION_KEYWORDS) or "?" in subject:
            return "action"
        if any(kw in sender_lower for kw in NEWSLETTER_SENDERS):
            return "fyi"
        if any(kw in subject_lower for kw in {"weekly", "digest", "newsletter", "update", "report"}):
            return "fyi"
        return "fyi"


def classify_with_reputation(sender, sender_email, subject, body, reputation):
    """Classify email using keywords + sender reputation."""
    keyword_cat = keyword_classify(sender, subject, body)
    final_cat, reason = apply_reputation(sender_email, keyword_cat, reputation)
    return {
        "keyword_category": keyword_cat,
        "final_category": final_cat,
        "adjustment_reason": reason,
        "sender_email": sender_email,
    }


# ---------------------------------------------------------------------------
# Metrics computation
# ---------------------------------------------------------------------------


def compute_distribution(classifications):
    """
    Compute classification distribution metrics from a list of classification results.
    Returns: {urgent: N, action: N, fyi: N, spam: N, total: N, ratios: {...},
              adjustments: N, adjustment_rate: float, signal_noise: float}
    """
    counts = {c: 0 for c in CATEGORIES}
    adjustments = 0
    total = len(classifications)

    for cl in classifications:
        cat = cl.get("final_category", cl.get("category", "fyi"))
        if cat in counts:
            counts[cat] += 1
        if cl.get("adjustment_reason", "keyword_only") != "keyword_only":
            adjustments += 1

    ratios = {}
    for c in CATEGORIES:
        ratios[c] = round(counts[c] / total, 4) if total > 0 else 0.0

    # Signal-to-noise: ratio of urgent+action (signal) to fyi+spam (noise)
    signal = counts["urgent"] + counts["action"]
    noise = counts["fyi"] + counts["spam"]
    signal_noise = round(signal / noise, 4) if noise > 0 else float(signal)

    return {
        **counts,
        "total": total,
        "ratios": ratios,
        "adjustments": adjustments,
        "adjustment_rate": round(adjustments / total, 4) if total > 0 else 0.0,
        "signal_noise_ratio": signal_noise,
    }


def compute_reputation_quality(reputation):
    """
    Measure how well reputation data separates senders.
    High quality = senders have strong dominant categories (not evenly split).
    """
    if not reputation:
        return {"sender_count": 0, "avg_dominance": 0.0, "strong_senders": 0}

    ratios = []
    strong = 0
    for sender, counts in reputation.items():
        r = counts.get("ratio", 0.0)
        ratios.append(r)
        if r >= REPUTATION_OVERRIDE_RATIO and counts.get("total", 0) >= REPUTATION_BOOST_THRESHOLD:
            strong += 1

    avg = round(sum(ratios) / len(ratios), 4) if ratios else 0.0
    return {
        "sender_count": len(reputation),
        "avg_dominance": avg,
        "strong_senders": strong,
    }


# ---------------------------------------------------------------------------
# Synthetic test data (for when no real emails are available)
# ---------------------------------------------------------------------------


def generate_synthetic_emails(count=30):
    """
    Generate synthetic email classification entries for testing the evolution cycle.
    Simulates a realistic inbox with known sender patterns.
    """
    import random
    random.seed(42)  # reproducible

    senders = [
        ("alerts@monitoring.company.com", "urgent",  0.8),
        ("boss@company.com",              "action",  0.7),
        ("hr@company.com",                "action",  0.6),
        ("newsletter@techdigest.com",     "fyi",     0.9),
        ("noreply@github.com",            "fyi",     0.85),
        ("security@vendor.com",           "urgent",  0.75),
        ("sales@random.com",              "fyi",     0.95),
        ("cto@company.com",               "action",  0.65),
        ("updates@service.io",            "fyi",     0.9),
        ("support@tool.com",              "action",  0.5),
    ]

    subjects = {
        "urgent": [
            "CRITICAL: Server down in production",
            "Security breach detected — immediate action",
            "URGENT: Database failover triggered",
            "Emergency: API outage affecting customers",
        ],
        "action": [
            "Please review the Q1 report",
            "Action required: approve deployment",
            "Can you confirm the meeting time?",
            "Request for access to staging",
            "Deadline reminder: proposal due Friday",
        ],
        "fyi": [
            "Weekly engineering digest",
            "Your GitHub notifications",
            "Newsletter: top stories this week",
            "Monthly usage report",
            "Update: new features released",
            "Digest: open source highlights",
        ],
    }

    emails = []
    for i in range(count):
        sender_email, natural_cat, cat_prob = random.choice(senders)
        # With cat_prob chance, use the natural category; otherwise random
        if random.random() < cat_prob:
            cat = natural_cat
        else:
            cat = random.choice(["urgent", "action", "fyi"])

        subject = random.choice(subjects.get(cat, subjects["fyi"]))
        emails.append({
            "sender": f"Person <{sender_email}>",
            "sender_email": sender_email,
            "subject": subject,
            "body_preview": f"Body of email {i} about {subject[:30]}...",
            "category": cat,  # keyword-based classification
            "uid": str(1000 + i),
        })

    return emails


# ---------------------------------------------------------------------------
# Experiment phases
# ---------------------------------------------------------------------------


def phase_record_pattern(dry_run=False):
    """Step 1: Record the observation that email_triage uses keyword-only classification."""
    print("Phase 1: Recording pattern...")
    result = api_post("evolution/outcomes", {
        "source": "workflow",
        "source_id": "email_triage",
        "action": "classify_emails",
        "result": "partial",
        "details": "email_triage classification is keyword-only with no sender history. "
                   "Keyword matching produces false urgents from newsletter senders and "
                   "misses urgent emails from known-critical senders with neutral subjects.",
        "failure_reason": "no_sender_reputation_tracking",
    }, dry_run=dry_run)

    if result and not dry_run:
        print(f"  Outcome recorded: {result.get('outcome_id', '?')}")
    return result


def phase_create_hypothesis(dry_run=False):
    """Step 2: Propose the sender reputation hypothesis."""
    print("Phase 2: Creating hypothesis...")

    # First, detect patterns so we have a pattern_id to link to
    api_post("evolution/cycle", {"agent": os.getenv("AGENT_ID", "agent")}, dry_run=dry_run)

    # Record a pattern directly for the experiment
    # Use the evolution DB directly since there's no POST /evolution/patterns endpoint
    # for failure patterns (only positive-patterns has POST)
    pattern_id = None
    if not dry_run:
        try:
            db_path = Path(CONFIG.get("memory_db", str(AIBRAIN_ROOT / "memory" / "memory.db")))
            # Try consolidated DB first
            aibrain_db = AIBRAIN_ROOT / "aibrain.db"
            if aibrain_db.exists():
                db_path = aibrain_db
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row
            # Check if pattern already exists
            existing = db.execute(
                "SELECT id FROM evolution_patterns WHERE pattern LIKE '%keyword-only%sender%' AND status='active'"  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
            ).fetchone()
            if existing:
                pattern_id = existing["id"]
                print(f"  Pattern already exists: {pattern_id}")
            else:
                cur = db.execute(
                    "INSERT INTO evolution_patterns (pattern, frequency, severity, related_outcomes) "
                    "VALUES (?, ?, ?, ?)",
                    ("email_triage classification is keyword-only, no sender history — "
                     "causes false urgents and missed signals",
                     1, "medium", "[]"),
                )
                db.commit()
                pattern_id = cur.lastrowid
                print(f"  Pattern recorded: {pattern_id}")
            db.close()
        except Exception as e:
            print(f"  Could not record pattern directly: {e}", file=sys.stderr)

    # Create the hypothesis via API
    result = api_post("evolution/hypotheses", {
        "pattern_id": pattern_id,
        "hypothesis": "Adding sender reputation tracking to email_triage will improve "
                      "classification accuracy — fewer false urgents, more accurate "
                      "categorization based on sender history patterns.",
        "change_type": "workflow",
        "target": "workflows/email_triage.py",
        "proposed_change": json.dumps({
            "type": "augmentation",
            "description": "Build sender reputation scores from classification history. "
                           "On each triage run, consult reputation to boost/demote "
                           "classifications for known senders.",
            "parameters": {
                "boost_threshold": REPUTATION_BOOST_THRESHOLD,
                "override_ratio": REPUTATION_OVERRIDE_RATIO,
            },
        }),
        "impact_score": 0.7,
        "confidence": 0.6,
    }, dry_run=dry_run)

    hypothesis_id = result.get("hypothesis_id") if result else None
    if hypothesis_id:
        print(f"  Hypothesis created: {hypothesis_id}")
    return hypothesis_id, pattern_id


def phase_measure_baseline(emails=None, dry_run=False):
    """Step 3: Measure baseline classification distribution (keyword-only)."""
    print("Phase 3: Measuring baseline...")

    if emails is None:
        # Try to get real email data from triage state
        triage_state = load_state("email_triage")
        classification_log = load_state("email_triage_classifications")
        entries = classification_log.get("entries", []) if classification_log else []

        if entries:
            emails = entries
            print(f"  Using {len(emails)} historical classification entries")
        else:
            # Fall back to synthetic data
            emails = generate_synthetic_emails(30)
            print(f"  No historical data — using {len(emails)} synthetic emails")
            # Save synthetic entries as classification log for future runs
            if not dry_run:
                save_state("email_triage_classifications", {
                    "entries": emails,
                    "source": "synthetic",
                    "generated_at": datetime.datetime.now().isoformat(),
                })

    # Compute baseline metrics using keyword-only classification
    baseline_classifications = []
    for em in emails:
        keyword_cat = keyword_classify(
            em.get("sender", ""),
            em.get("subject", ""),
            em.get("body_preview", em.get("body", "")),
        )
        baseline_classifications.append({
            "sender_email": em.get("sender_email", "unknown"),
            "subject": em.get("subject", ""),
            "category": keyword_cat,
            "final_category": keyword_cat,
            "adjustment_reason": "keyword_only",
        })

    metrics = compute_distribution(baseline_classifications)
    print(f"  Baseline: {metrics['total']} emails — "
          f"urgent:{metrics['urgent']} action:{metrics['action']} "
          f"fyi:{metrics['fyi']} spam:{metrics['spam']}")
    print(f"  Signal/noise ratio: {metrics['signal_noise_ratio']}")

    # Record baseline metrics via evolution API
    if not dry_run:
        api_post("evolution/metrics", {
            "metric_name": "email_triage_baseline_signal_noise",
            "metric_value": metrics["signal_noise_ratio"],
            "source": "evolution_experiment",
            "period": "baseline",
        })
        for cat in CATEGORIES:
            api_post("evolution/metrics", {
                "metric_name": f"email_triage_baseline_{cat}_ratio",
                "metric_value": metrics["ratios"][cat],
                "source": "evolution_experiment",
                "period": "baseline",
            })

    return metrics, emails


def phase_start_experiment(hypothesis_id, baseline_metrics, dry_run=False):
    """Step 4: Start the experiment via API."""
    print("Phase 4: Starting experiment...")

    if hypothesis_id is None and not dry_run:
        # Look up existing hypothesis
        resp = api_get("evolution/hypotheses?status=testing")
        if resp and resp.get("hypotheses"):
            for h in resp["hypotheses"]:
                if "sender reputation" in h.get("hypothesis", "").lower():
                    hypothesis_id = h["id"]
                    break
        if hypothesis_id is None:
            resp = api_get("evolution/hypotheses?status=proposed")
            if resp and resp.get("hypotheses"):
                for h in resp["hypotheses"]:
                    if "sender reputation" in h.get("hypothesis", "").lower():
                        hypothesis_id = h["id"]
                        break

    if hypothesis_id is None and not dry_run:
        print("  ERROR: No hypothesis found. Run full cycle first.", file=sys.stderr)
        return None

    result = api_post("evolution/experiments", {
        "hypothesis_id": hypothesis_id or 0,
        "baseline_metrics": baseline_metrics,
        "runs_target": RUNS_TARGET,
    }, dry_run=dry_run)

    experiment_id = result.get("experiment_id") if result else None
    if experiment_id:
        print(f"  Experiment started: {experiment_id}")
    return experiment_id


def phase_run_iteration(experiment_id=None, dry_run=False):
    """
    Step 5: Run one experiment iteration.
    - Build/update sender reputation
    - Re-classify emails with reputation
    - Record the run
    - Store updated metrics
    """
    print("Phase 5: Running experiment iteration...")

    # Load classification data
    classification_log = load_state("email_triage_classifications")
    entries = classification_log.get("entries", []) if classification_log else []
    if not entries:
        entries = generate_synthetic_emails(30)
        print(f"  No classification log — using {len(entries)} synthetic emails")

    # Build reputation from historical data
    reputation = build_sender_reputation(load_state("email_triage"))
    rep_quality = compute_reputation_quality(reputation)
    print(f"  Reputation: {rep_quality['sender_count']} senders, "
          f"{rep_quality['strong_senders']} strong, "
          f"avg dominance {rep_quality['avg_dominance']:.1%}")

    # Classify with reputation
    enhanced_classifications = []
    for em in entries:
        result = classify_with_reputation(
            em.get("sender", ""),
            em.get("sender_email", "unknown"),
            em.get("subject", ""),
            em.get("body_preview", em.get("body", "")),
            reputation,
        )
        enhanced_classifications.append(result)

    metrics = compute_distribution(enhanced_classifications)
    print(f"  Enhanced: {metrics['total']} emails — "
          f"urgent:{metrics['urgent']} action:{metrics['action']} "
          f"fyi:{metrics['fyi']} spam:{metrics['spam']}")
    print(f"  Adjustments: {metrics['adjustments']} ({metrics['adjustment_rate']:.1%})")
    print(f"  Signal/noise ratio: {metrics['signal_noise_ratio']}")

    # Update the classification log — feed classifications back as new entries
    # so reputation accumulates over iterations
    updated_entries = []
    for i, em in enumerate(entries):
        cl = enhanced_classifications[i]
        updated = dict(em)
        updated["category"] = cl["final_category"]
        updated["keyword_category"] = cl["keyword_category"]
        updated["adjustment_reason"] = cl["adjustment_reason"]
        updated_entries.append(updated)

    if not dry_run:
        save_state("email_triage_classifications", {
            "entries": updated_entries,
            "source": classification_log.get("source", "synthetic") if classification_log else "synthetic",
            "last_updated": datetime.datetime.now().isoformat(),
            "iteration_count": (classification_log.get("iteration_count", 0) + 1)
                               if classification_log else 1,
        })

        # Save updated reputation
        save_state("sender_reputation", {
            "senders": reputation,
            "quality": rep_quality,
            "last_updated": datetime.datetime.now().isoformat(),
        })

        # Record metrics
        api_post("evolution/metrics", {
            "metric_name": "email_triage_experiment_signal_noise",
            "metric_value": metrics["signal_noise_ratio"],
            "source": "evolution_experiment",
            "period": "experiment_run",
        })
        api_post("evolution/metrics", {
            "metric_name": "email_triage_experiment_adjustment_rate",
            "metric_value": metrics["adjustment_rate"],
            "source": "evolution_experiment",
            "period": "experiment_run",
        })

    # Record experiment run via API
    if experiment_id and not dry_run:
        run_result = api_post(f"evolution/experiments/{experiment_id}/run", {})
        if run_result:
            print(f"  Run {run_result.get('runs_completed', '?')}/{run_result.get('runs_target', '?')} recorded")
            if run_result.get("ready_to_decide"):
                print("  >>> Experiment ready for decision! Run with --decide")

    # Save experiment state locally
    exp_state = load_state(EXPERIMENT_NAME)
    runs = exp_state.get("runs", [])
    runs.append({
        "timestamp": datetime.datetime.now().isoformat(),
        "metrics": metrics,
        "reputation_quality": rep_quality,
    })
    exp_state["runs"] = runs
    exp_state["experiment_id"] = experiment_id or exp_state.get("experiment_id")
    exp_state["last_run"] = datetime.datetime.now().isoformat()

    if not dry_run:
        save_state(EXPERIMENT_NAME, exp_state)
        log_activity("evolution_experiment_run", json.dumps({
            "experiment": EXPERIMENT_NAME,
            "iteration": len(runs),
            "signal_noise": metrics["signal_noise_ratio"],
            "adjustments": metrics["adjustments"],
        }))

    return metrics


def phase_decide(dry_run=False):
    """
    Step 6: Evaluate the experiment and decide keep/revert.

    Compares baseline metrics to experiment metrics across all recorded runs.
    Decision criteria:
      - signal_noise_ratio improved (or at least not degraded)
      - adjustment_rate > 0 (reputation is actually being used)
      - no increase in false urgents (urgent count should not inflate)
    """
    print("Phase 6: Evaluating experiment...")

    exp_state = load_state(EXPERIMENT_NAME)
    runs = exp_state.get("runs", [])
    experiment_id = exp_state.get("experiment_id")

    if not runs:
        print("  No runs recorded. Cannot decide yet.")
        return None

    # Load baseline from experiment state or measure fresh
    baseline = exp_state.get("baseline_metrics")
    if not baseline:
        print("  No baseline stored — measuring now...")
        baseline, _ = phase_measure_baseline(dry_run=True)

    # Aggregate experiment metrics from all runs
    avg_signal_noise = sum(r["metrics"]["signal_noise_ratio"] for r in runs) / len(runs)
    avg_adjustment_rate = sum(r["metrics"]["adjustment_rate"] for r in runs) / len(runs)
    avg_urgent_ratio = sum(r["metrics"]["ratios"]["urgent"] for r in runs) / len(runs)

    baseline_sn = baseline.get("signal_noise_ratio", 0)
    baseline_urgent_ratio = baseline.get("ratios", {}).get("urgent", 0)

    print(f"  Baseline signal/noise:    {baseline_sn:.4f}")
    print(f"  Experiment signal/noise:  {avg_signal_noise:.4f} (avg over {len(runs)} runs)")
    print(f"  Baseline urgent ratio:    {baseline_urgent_ratio:.4f}")
    print(f"  Experiment urgent ratio:  {avg_urgent_ratio:.4f}")
    print(f"  Average adjustment rate:  {avg_adjustment_rate:.1%}")

    # Decision logic
    sn_improved = avg_signal_noise >= baseline_sn
    no_urgent_inflation = avg_urgent_ratio <= baseline_urgent_ratio * 1.2  # allow 20% tolerance
    reputation_active = avg_adjustment_rate > 0.0
    enough_runs = len(runs) >= RUNS_TARGET

    reasons = []
    if sn_improved:
        reasons.append(f"signal/noise improved ({baseline_sn:.4f} -> {avg_signal_noise:.4f})")
    else:
        reasons.append(f"signal/noise degraded ({baseline_sn:.4f} -> {avg_signal_noise:.4f})")

    if no_urgent_inflation:
        reasons.append("no urgent inflation detected")
    else:
        reasons.append(f"urgent ratio inflated ({baseline_urgent_ratio:.4f} -> {avg_urgent_ratio:.4f})")

    if reputation_active:
        reasons.append(f"reputation actively adjusting ({avg_adjustment_rate:.1%} of emails)")
    else:
        reasons.append("reputation not triggering any adjustments")

    if not enough_runs:
        decision = "extend"
        reason = f"Only {len(runs)}/{RUNS_TARGET} runs completed. " + "; ".join(reasons)
    elif sn_improved and no_urgent_inflation and reputation_active:
        decision = "keep"
        reason = "All criteria met: " + "; ".join(reasons)
    elif sn_improved and no_urgent_inflation:
        decision = "keep"
        reason = "Signal improved without inflation (reputation inactive but harmless): " + "; ".join(reasons)
    else:
        decision = "revert"
        reason = "Criteria not met: " + "; ".join(reasons)

    print(f"\n  DECISION: {decision.upper()}")
    print(f"  Reason: {reason}")

    experiment_metrics = {
        "avg_signal_noise_ratio": round(avg_signal_noise, 4),
        "avg_adjustment_rate": round(avg_adjustment_rate, 4),
        "avg_urgent_ratio": round(avg_urgent_ratio, 4),
        "runs_evaluated": len(runs),
        "per_run": [
            {
                "signal_noise": r["metrics"]["signal_noise_ratio"],
                "adjustment_rate": r["metrics"]["adjustment_rate"],
            }
            for r in runs
        ],
    }

    # Submit decision via API
    if experiment_id and not dry_run:
        result = api_post(f"evolution/experiments/{experiment_id}/decide", {
            "decision": decision,
            "experiment_metrics": experiment_metrics,
            "reason": reason,
        })
        if result:
            print(f"  Decision recorded via API: {result}")
    elif dry_run:
        print(f"  [dry-run] Would submit decision: {decision}")
        print(f"  [dry-run] Metrics: {json.dumps(experiment_metrics, indent=2)}")

    # Handle revert: clear reputation state
    if decision == "revert" and not dry_run:
        save_state("sender_reputation", {"reverted": True, "reason": reason,
                                          "reverted_at": datetime.datetime.now().isoformat()})
        print("  Sender reputation state cleared (reverted).")

    # Log final state
    exp_state["decision"] = decision
    exp_state["decision_reason"] = reason
    exp_state["decided_at"] = datetime.datetime.now().isoformat()
    exp_state["experiment_metrics"] = experiment_metrics
    if not dry_run:
        save_state(EXPERIMENT_NAME, exp_state)
        log_activity("evolution_experiment_decide", json.dumps({
            "experiment": EXPERIMENT_NAME,
            "decision": decision,
            "reason": reason[:200],
            "baseline_sn": baseline_sn,
            "experiment_sn": avg_signal_noise,
        }))

    # Record the evolution outcome
    api_post("evolution/outcomes", {
        "source": "evolution_experiment",
        "source_id": EXPERIMENT_NAME,
        "action": f"experiment_decision_{decision}",
        "result": "success" if decision in ("keep", "extend") else "partial",
        "details": reason,
    }, dry_run=dry_run)

    return {"decision": decision, "reason": reason, "metrics": experiment_metrics}


# ---------------------------------------------------------------------------
# Full cycle orchestrator
# ---------------------------------------------------------------------------


def run_full_cycle(dry_run=False):
    """
    Run the complete evolution experiment cycle:
      pattern -> hypothesis -> baseline -> experiment -> run -> (later) decide
    """
    print(f"{'='*60}")
    print(f"EVOLUTION EXPERIMENT: Sender Reputation for Email Triage")
    print(f"{'='*60}")
    print(f"Time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    if dry_run:
        print("MODE: DRY RUN (no state changes, no API calls)")
    print()

    # Check if experiment is already in progress
    exp_state = load_state(EXPERIMENT_NAME)
    if exp_state.get("experiment_id") and not exp_state.get("decision"):
        print(f"Experiment already in progress (id={exp_state['experiment_id']})")
        print(f"Runs completed: {len(exp_state.get('runs', []))}/{RUNS_TARGET}")
        print("Running next iteration...\n")
        metrics = phase_run_iteration(
            experiment_id=exp_state["experiment_id"],
            dry_run=dry_run,
        )
        runs = exp_state.get("runs", [])
        if len(runs) >= RUNS_TARGET:
            print(f"\nTarget runs reached ({len(runs)}/{RUNS_TARGET}). Auto-deciding...\n")
            phase_decide(dry_run=dry_run)
        return

    if exp_state.get("decision"):
        print(f"Previous experiment already decided: {exp_state['decision']}")
        print(f"Reason: {exp_state.get('decision_reason', 'unknown')}")
        print("To re-run, clear the sender_reputation_triage state.")
        return

    # Fresh experiment — full setup
    phase_record_pattern(dry_run=dry_run)
    print()

    hypothesis_id, pattern_id = phase_create_hypothesis(dry_run=dry_run)
    print()

    baseline_metrics, emails = phase_measure_baseline(dry_run=dry_run)
    print()

    experiment_id = phase_start_experiment(hypothesis_id, baseline_metrics, dry_run=dry_run)
    print()

    # Save baseline into experiment state for later decision
    if not dry_run:
        exp_state = load_state(EXPERIMENT_NAME)
        exp_state["baseline_metrics"] = baseline_metrics
        exp_state["hypothesis_id"] = hypothesis_id
        exp_state["pattern_id"] = pattern_id
        exp_state["experiment_id"] = experiment_id
        exp_state["started_at"] = datetime.datetime.now().isoformat()
        save_state(EXPERIMENT_NAME, exp_state)

    # Run first iteration
    phase_run_iteration(experiment_id=experiment_id, dry_run=dry_run)
    print()

    log_activity("evolution_experiment_started", json.dumps({
        "experiment": EXPERIMENT_NAME,
        "hypothesis_id": hypothesis_id,
        "experiment_id": experiment_id,
        "baseline_signal_noise": baseline_metrics["signal_noise_ratio"],
    }), dry_run=dry_run)

    remaining = RUNS_TARGET - 1
    print(f"{'='*60}")
    print(f"Experiment initialized. {remaining} more run(s) needed before decision.")
    print(f"Re-run this workflow (without flags) to record additional iterations.")
    print(f"Run with --decide after {RUNS_TARGET} total runs to evaluate.")
    print(f"{'='*60}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(
        description="AIBrain Evolution Experiment — sender reputation for email triage"
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Full cycle without modifying state or calling API")
    parser.add_argument("--baseline", action="store_true",
                        help="Measure baseline classification distribution only")
    parser.add_argument("--decide", action="store_true",
                        help="Evaluate experiment and render keep/revert decision")
    args = parser.parse_args()

    if args.baseline:
        metrics, _ = phase_measure_baseline(dry_run=args.dry_run)
        print(f"\nBaseline metrics: {json.dumps(metrics, indent=2)}")
        return

    if args.decide:
        result = phase_decide(dry_run=args.dry_run)
        if result:
            print(f"\nFinal result: {json.dumps(result, indent=2)}")
        return

    run_full_cycle(dry_run=args.dry_run)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='evolution_experiment',
        action=_workflow_entry,
        task_type='complex',
        actor='cli',
    )
