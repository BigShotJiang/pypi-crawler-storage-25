#!/usr/bin/env python3
"""AIBrain Workflow: Email Auto-Reply — draft and send replies with human-in-the-loop approval."""

import argparse
import datetime
import email
import imaplib
import json
import os
import re
import smtplib
import sqlite3
import sys
import urllib.request
from email.header import decode_header
from email.mime.text import MIMEText
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & paths
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
APPROVAL_DB = str(AIBRAIN_ROOT / "approval.db")
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

# Reply mode: "auto" sends routine replies immediately, "prompted" queues everything
REPLY_MODE = CONFIG.get("email_reply_mode", "prompted")

# Dry-run mode: log what would happen without sending or modifying anything
DRY_RUN = CONFIG.get("email_dry_run", True)  # Default ON for safety — flip after 72h

# Rate limits — hard caps to prevent email spam on malfunction
RATE_LIMIT_HOURLY = int(CONFIG.get("email_rate_limit_hourly", 5))
RATE_LIMIT_DAILY = int(CONFIG.get("email_rate_limit_daily", 20))

# Max emails to process per run
MAX_EMAILS = int(CONFIG.get("email_reply_max", 25))

# Senders whose emails always get auto-replied (even in prompted mode)
AUTO_REPLY_SENDERS = set(CONFIG.get("email_auto_reply_senders", []))

# Domain blocklist — never auto-reply to these domains
BLOCKED_DOMAINS = set(CONFIG.get("email_blocked_domains", [
    "gov.au", "ato.gov.au", "centrelink.gov.au", "mygov.gov.au",
    "commbank.com.au", "anz.com.au", "nab.com.au", "westpac.com.au",
    "paypal.com", "stripe.com", "linkedin.com", "indeed.com",
]))

# Patterns that identify routine/auto-replyable emails
ROUTINE_SUBJECT_PATTERNS = [
    r"(?i)order\s+confirm",
    r"(?i)shipping\s+(confirm|notif|updat)",
    r"(?i)password\s+reset",
    r"(?i)verify\s+your\s+(email|account)",
    r"(?i)subscription\s+(confirm|renew)",
    r"(?i)receipt\s+(for|from)",
    r"(?i)invoice\s+#?\d",
    r"(?i)your\s+(ticket|case|request)\s+#?\d",
    r"(?i)out\s+of\s+office",
    r"(?i)auto[- ]?reply",
    r"(?i)do[- ]?not[- ]?reply",
]

# Senders that should never receive a reply
NO_REPLY_SENDERS = {"noreply", "no-reply", "donotreply", "do-not-reply",
                    "mailer-daemon", "postmaster", "notifications", "notification"}

# Senders that should never get auto-replies — security scanners, marketing, billing
SKIP_DOMAINS = [
    "getgitguardian.com", "github.com",  # security scanners — action, not reply
    "kogan.com", "e.kogan.com",  # marketing spam
    "hostinger.com", "info.hostinger.com",  # billing receipts
    "realestate.com.au", "campaign.realestate.com.au",  # property alerts
    "meetup.com", "email.meetup.com",  # social events
    "jobalert.indeed.com",  # job alerts (not responses)
    "s.seek.com.au",  # SEEK platform tips
]

sys.path.insert(0, str(AIBRAIN_ROOT / "backend"))
try:
    from approval_queue import add_item as approval_add, get_item as approval_get
except ImportError:
    approval_add = None
    approval_get = None


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def log_activity(action, detail="", status="ok"):
    """Log to the AIBrain activity API."""
    try:
        data = json.dumps({
            "action": action, "category": "email",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Email helpers (shared patterns from email_triage.py)
# ---------------------------------------------------------------------------

def decode_mime_header(header):
    if not header:
        return ""
    parts = decode_header(header)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(str(part))
    return " ".join(decoded)


def get_body(msg):
    """Extract plain text body from email message."""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")[:2000]
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")[:2000]
    return ""


def extract_email_addr(sender):
    """Pull bare email address from a From header."""
    match = re.search(r"[\w.+-]+@[\w.-]+", sender)
    return match.group(0).lower() if match else sender.lower()


def get_email_accounts():
    """Build list of accounts that can send replies (can_reply=True)."""
    accounts = []

    # Primary agent email
    agent_email = CONFIG.get("agent_email", "")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    agent_imap = CONFIG.get("agent_imap_host", CONFIG.get("email_imap_host", "imap.gmail.com"))
    agent_smtp = CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com"))
    if agent_email and agent_password:
        accounts.append({
            "label": "agent",
            "email": agent_email,
            "password": agent_password,
            "imap_host": agent_imap,
            "smtp_host": agent_smtp,
            "can_reply": True,
        })

    # Additional accounts from email_accounts array
    for acct in CONFIG.get("email_accounts", []):
        if acct.get("monitor") and acct.get("email") and acct.get("app_password"):
            accounts.append({
                "label": acct.get("label", acct["email"].split("@")[0]),
                "email": acct["email"],
                "password": acct["app_password"],
                "imap_host": acct.get("imap_host", "imap.gmail.com"),
                "smtp_host": acct.get("smtp_host", "smtp.gmail.com"),
                "can_reply": acct.get("can_reply", False),
            })

    return accounts


# ---------------------------------------------------------------------------
# Email classification for reply decisions
# ---------------------------------------------------------------------------

def is_no_reply_sender(sender_email):
    """Return True if this sender should never receive a reply."""
    local = sender_email.split("@")[0].lower()
    return any(tag in local for tag in NO_REPLY_SENDERS)


def is_blocked_domain(sender_email):
    """Return True if sender's domain is in the blocklist."""
    domain = sender_email.split("@")[-1].lower()
    return any(domain == bd or domain.endswith("." + bd) for bd in BLOCKED_DOMAINS)


def check_rate_limit():
    """Check if we've hit the hourly or daily send limit. Returns (ok, reason)."""
    state = load_state("email_auto_reply")
    send_log = state.get("send_log", [])
    now = datetime.datetime.now()
    hour_ago = (now - datetime.timedelta(hours=1)).isoformat()
    day_ago = (now - datetime.timedelta(hours=24)).isoformat()

    sent_last_hour = sum(1 for t in send_log if t > hour_ago)
    sent_last_day = sum(1 for t in send_log if t > day_ago)

    if sent_last_hour >= RATE_LIMIT_HOURLY:
        return False, f"Hourly limit reached ({sent_last_hour}/{RATE_LIMIT_HOURLY})"
    if sent_last_day >= RATE_LIMIT_DAILY:
        return False, f"Daily limit reached ({sent_last_day}/{RATE_LIMIT_DAILY})"
    return True, ""


def record_send():
    """Record a send event for rate limiting."""
    state = load_state("email_auto_reply")
    send_log = state.get("send_log", [])
    send_log.append(datetime.datetime.now().isoformat())
    # Keep only last 48 hours of send log
    cutoff = (datetime.datetime.now() - datetime.timedelta(hours=48)).isoformat()
    send_log = [t for t in send_log if t > cutoff]
    state["send_log"] = send_log
    save_state("email_auto_reply", state)


def is_routine_email(subject, body):
    """Return True if this is a routine email safe for auto-reply."""
    for pattern in ROUTINE_SUBJECT_PATTERNS:
        if re.search(pattern, subject):
            return True
    return False


def needs_reply(sender_email, subject, body):
    """Decide if an email needs a reply and what mode to use.

    Returns:
        None        — skip (no-reply sender, newsletter, etc.)
        "auto"      — safe for auto-reply (routine confirmation, known sender)
        "prompted"  — needs human approval before sending
    """
    if is_no_reply_sender(sender_email):
        return None

    # Skip domains — security scanners, marketing, billing, property alerts
    sender_domain = sender_email.split("@")[-1].lower()
    if any(d in sender_domain for d in SKIP_DOMAINS):
        return None

    # Domain blocklist — sensitive domains require manual handling
    if is_blocked_domain(sender_email):
        return None

    # Out-of-office and auto-replies — never reply to these
    if re.search(r"(?i)(out\s+of\s+office|auto[- ]?reply|do[- ]?not[- ]?reply)", subject):
        return None

    # Known auto-reply senders override mode
    if sender_email.lower() in {s.lower() for s in AUTO_REPLY_SENDERS}:
        return "auto"

    # Routine emails: auto in auto mode, prompted otherwise
    if is_routine_email(subject, body):
        return "auto" if REPLY_MODE == "auto" else "prompted"

    # Everything else goes through prompted mode
    return "prompted"


# ---------------------------------------------------------------------------
# Draft generation via Claude API
# ---------------------------------------------------------------------------

def draft_reply(sender, subject, body, account_email):
    """Use Claude API to generate a reply draft. Falls back to a template if no API key."""
    api_key = os.environ.get("ANTHROPIC_API_KEY", CONFIG.get("anthropic_api_key", ""))

    prompt = (
        f"You are drafting an email reply on behalf of {account_email}.\n\n"
        f"Original email:\n"
        f"From: {sender}\n"
        f"Subject: {subject}\n"
        f"Body:\n{body[:1500]}\n\n"
        f"Write a concise, professional reply. Match the tone of the original. "
        f"If this is a confirmation/notification, a brief acknowledgment is fine. "
        f"Do NOT include a subject line — just the body text. "
        f"Sign off with the first name from: {account_email}"
    )

    if api_key:
        try:
            import urllib.request
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=json.dumps({
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 512,
                    "messages": [{"role": "user", "content": prompt}],
                }).encode(),
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read())
                return data["content"][0]["text"].strip()
        except Exception as e:
            print(f"  Claude API error: {e}", file=sys.stderr)

    # Fallback: simple template
    name = account_email.split("@")[0].replace(".", " ").title()
    if is_routine_email(subject, ""):
        return f"Received, thank you.\n\n— {name}"
    return f"Thanks for your email. I'll review and get back to you shortly.\n\n— {name}"


# ---------------------------------------------------------------------------
# Fetch emails that need replies
# ---------------------------------------------------------------------------

def fetch_reply_candidates(imap_host, email_addr, password, max_count=MAX_EMAILS):
    """Fetch unread emails and filter to ones that need replies."""
    candidates = []
    try:
        mail = imaplib.IMAP4_SSL(imap_host, 993)
        mail.login(email_addr, password)
        mail.select("INBOX", readonly=True)

        _, data = mail.search(None, "UNSEEN")
        msg_ids = data[0].split()

        if len(msg_ids) > max_count:
            msg_ids = msg_ids[-max_count:]

        for mid in msg_ids:
            _, msg_data = mail.fetch(mid, "(RFC822)")
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)

            sender = decode_mime_header(msg.get("From", ""))
            subject = decode_mime_header(msg.get("Subject", ""))
            message_id = msg.get("Message-ID", "")
            date = msg.get("Date", "")
            body = get_body(msg)
            sender_email = extract_email_addr(sender)

            reply_mode = needs_reply(sender_email, subject, body)
            if reply_mode is None:
                continue

            candidates.append({
                "sender": sender,
                "sender_email": sender_email,
                "subject": subject,
                "date": date,
                "body": body,
                "body_preview": body[:150],
                "message_id": message_id,
                "uid": mid.decode(),
                "reply_mode": reply_mode,
            })

        mail.logout()
    except Exception as e:
        print(f"IMAP error for {email_addr}: {e}", file=sys.stderr)

    return candidates


# ---------------------------------------------------------------------------
# Send reply via SMTP
# ---------------------------------------------------------------------------

def send_reply(smtp_host, from_email, password, to_email, subject, body,
               in_reply_to="", dry_run=False):
    """Send reply email via SMTP."""
    reply_subject = subject if subject.lower().startswith("re:") else f"Re: {subject}"

    if dry_run:
        print(f"  [DRY RUN] Would send reply:")
        print(f"    FROM: {from_email}")
        print(f"    TO: {to_email}")
        print(f"    SUBJECT: {reply_subject}")
        print(f"    BODY: {body[:200]}...")
        return True

    try:
        msg = MIMEText(body, "plain")
        msg["From"] = from_email
        msg["To"] = to_email
        msg["Subject"] = reply_subject
        if in_reply_to:
            msg["In-Reply-To"] = in_reply_to
            msg["References"] = in_reply_to

        with smtplib.SMTP_SSL(smtp_host, 465) as s:
            s.login(from_email, password)
            s.send_message(msg)
        return True
    except Exception as e:
        print(f"  SMTP error: {e}", file=sys.stderr)
        return False


# ---------------------------------------------------------------------------
# Queue for approval
# ---------------------------------------------------------------------------

def queue_for_approval(email_data, draft_body, account):
    """Add a reply draft to the approval queue. Returns item ID or None."""
    if approval_add is None:
        print("  Warning: approval_queue module not available, skipping queue", file=sys.stderr)
        return None

    payload = {
        "type": "email_reply",
        "from_account": account["email"],
        "to": email_data["sender_email"],
        "subject": email_data["subject"],
        "original_body_preview": email_data["body_preview"],
        "draft_body": draft_body,
        "message_id": email_data.get("message_id", ""),
        "smtp_host": account["smtp_host"],
    }

    title = f"Reply to {email_data['sender_email']}: {email_data['subject'][:60]}"
    detail = f"Draft:\n{draft_body}"

    item_id = approval_add(
        db_path=Path(APPROVAL_DB),
        category="email_reply",
        title=title,
        detail=detail,
        payload=payload,
    )
    return item_id


# ---------------------------------------------------------------------------
# Process approved items (called separately or by scheduler)
# ---------------------------------------------------------------------------

def send_approved_replies(dry_run=False):
    """Check approval queue for approved email replies and send them."""
    if approval_get is None:
        print("Approval queue module not available.", file=sys.stderr)
        return 0

    from approval_queue import list_items, decide

    approved = list_items(Path(APPROVAL_DB), status="approved", category="email_reply")
    sent = 0

    for item in approved:
        payload = json.loads(item["payload"]) if isinstance(item["payload"], str) else item["payload"]
        if payload.get("type") != "email_reply":
            continue

        # Find the matching account to get the password
        account = None
        for acct in get_email_accounts():
            if acct["email"] == payload["from_account"]:
                account = acct
                break

        if not account:
            print(f"  No matching account for {payload['from_account']}, skipping", file=sys.stderr)
            continue

        ok = send_reply(
            smtp_host=payload.get("smtp_host", account["smtp_host"]),
            from_email=account["email"],
            password=account["password"],
            to_email=payload["to"],
            subject=payload["subject"],
            body=payload["draft_body"],
            in_reply_to=payload.get("message_id", ""),
            dry_run=dry_run,
        )

        if ok:
            if not dry_run:
                record_send()
            # Mark as sent by updating status to a final state
            decide(Path(APPROVAL_DB), item["id"], approved=True, note="sent")
            log_activity("email_reply_sent",
                         f"to={payload['to']} subject={payload['subject'][:60]}")
            sent += 1
            print(f"  Sent approved reply to {payload['to']}")
        else:
            log_activity("email_reply_failed",
                         f"to={payload['to']} subject={payload['subject'][:60]}",
                         status="error")

    return sent


# ---------------------------------------------------------------------------
# Main workflow
# ---------------------------------------------------------------------------

def run(dry_run=False):
    """Main entry: fetch emails, draft replies, auto-send or queue for approval."""
    # Global dry-run override from config (safety default)
    if DRY_RUN:
        dry_run = True
        print("[DRY RUN MODE] email_dry_run=true in config. Set to false after review period.")

    # Rate limit check before doing any work
    rate_ok, rate_reason = check_rate_limit()
    if not rate_ok:
        print(f"Rate limit hit: {rate_reason}. Skipping this run.")
        log_activity("email_auto_reply_rate_limited", rate_reason, status="warning")
        return

    accounts = get_email_accounts()
    if not accounts:
        print("Error: no email accounts configured. Set agent_email or email_accounts in config.json",
              file=sys.stderr)
        sys.exit(1)

    reply_accounts = [a for a in accounts if a.get("can_reply")]
    if not reply_accounts:
        print("Warning: no accounts have can_reply=true. Will draft but cannot send.", file=sys.stderr)
        reply_accounts = accounts  # still draft, just won't send

    stats = {"checked": 0, "drafted": 0, "auto_sent": 0, "queued": 0, "skipped": 0, "errors": 0}

    for account in accounts:
        label = account["label"]
        can_reply = account.get("can_reply", False)
        print(f"\nChecking {label} ({account['email']})...")

        candidates = fetch_reply_candidates(
            account["imap_host"], account["email"], account["password"]
        )
        stats["checked"] += len(candidates)
        print(f"  {len(candidates)} emails need replies")

        for em in candidates:
            print(f"  [{em['reply_mode']}] {em['sender_email']}: {em['subject'][:50]}")

            # Draft the reply
            draft = draft_reply(em["sender"], em["subject"], em["body"], account["email"])
            stats["drafted"] += 1

            if not can_reply:
                print(f"    Account cannot send replies — draft only")
                stats["skipped"] += 1
                continue

            if em["reply_mode"] == "auto":
                # Rate limit check before each send
                rate_ok, rate_reason = check_rate_limit()
                if not rate_ok:
                    print(f"    Rate limit hit: {rate_reason}. Queuing instead.")
                    queue_for_approval(em, draft, account)
                    stats["queued"] += 1
                    continue

                # Send immediately
                ok = send_reply(
                    smtp_host=account["smtp_host"],
                    from_email=account["email"],
                    password=account["password"],
                    to_email=em["sender_email"],
                    subject=em["subject"],
                    body=draft,
                    in_reply_to=em.get("message_id", ""),
                    dry_run=dry_run,
                )
                if ok:
                    if not dry_run:
                        record_send()
                    stats["auto_sent"] += 1
                    log_activity("email_auto_reply",
                                 f"to={em['sender_email']} subject={em['subject'][:60]}")
                    print(f"    Auto-replied")
                else:
                    stats["errors"] += 1

            else:
                # Queue for human approval
                item_id = queue_for_approval(em, draft, account)
                if item_id:
                    stats["queued"] += 1
                    print(f"    Queued for approval (item #{item_id})")
                else:
                    stats["skipped"] += 1
                    print(f"    Could not queue — draft printed above")

    # Also process any previously approved replies
    approved_sent = send_approved_replies(dry_run=dry_run)
    stats["auto_sent"] += approved_sent

    # Summary
    print(f"\n{'='*50}")
    print(f"Email Auto-Reply Summary")
    print(f"  Mode: {REPLY_MODE}")
    print(f"  Accounts: {len(accounts)}")
    print(f"  Candidates checked: {stats['checked']}")
    print(f"  Drafts generated: {stats['drafted']}")
    print(f"  Auto-sent: {stats['auto_sent']}")
    print(f"  Queued for approval: {stats['queued']}")
    print(f"  Skipped: {stats['skipped']}")
    print(f"  Errors: {stats['errors']}")
    if dry_run:
        print(f"  (DRY RUN — no emails actually sent)")

    # Save state
    save_state("email_auto_reply", {
        "last_run": datetime.datetime.now().isoformat(),
        "mode": REPLY_MODE,
        "stats": stats,
    })

    log_activity("email_auto_reply_run",
                 f"mode={REPLY_MODE} checked={stats['checked']} sent={stats['auto_sent']} queued={stats['queued']}")


def main():
    parser = argparse.ArgumentParser(description="AIBrain Email Auto-Reply — draft and send replies")
    parser.add_argument("--dry-run", action="store_true", help="Print drafts instead of sending")
    parser.add_argument("--send-approved", action="store_true",
                        help="Only process previously approved replies (skip inbox check)")
    args = parser.parse_args()

    if args.send_approved:
        sent = send_approved_replies(dry_run=args.dry_run)
        print(f"Sent {sent} approved replies" + (" (dry run)" if args.dry_run else ""))
    else:
        run(dry_run=args.dry_run)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='email_auto_reply',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
