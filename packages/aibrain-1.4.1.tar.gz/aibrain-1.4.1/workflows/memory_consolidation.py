"""
Memory Consolidation — nightly "sleep cycle" for the brain.

Five-step process:
1. CLUSTER — group active memories by type + embedding similarity (>0.80)
2. MERGE   — consolidate clusters of 3+ into single entries
3. DECAY   — reduce storage_strength for memories not accessed in 30+ days
4. ARCHIVE — archive memories with combined retention < 0.05
5. REBUILD — regenerate all category_summaries from active memories

Idempotent: running twice produces the same result (skips already-consolidated
and already-superseded entries).

Usage:
    python -m aibrain.core.workflow_runner memory_consolidation
    python workflows/memory_consolidation.py --dry-run
    python workflows/memory_consolidation.py --verbose
"""

import argparse
import json
import logging
import os
import struct
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# --- Path setup ---
SCRIPT_DIR = Path(__file__).parent
AIBRAIN_ROOT = SCRIPT_DIR.parent
if str(AIBRAIN_ROOT) not in sys.path:
    sys.path.insert(0, str(AIBRAIN_ROOT))

import aibrain_db

logger = logging.getLogger("aibrain.consolidation")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

SIMILARITY_THRESHOLD = 0.80   # cosine similarity for clustering
MIN_CLUSTER_SIZE = 3          # minimum cluster size to trigger merge
DECAY_DAYS = 30               # days before decay starts
DECAY_RATE = 0.05             # storage_strength loss per day past threshold
DECAY_FLOOR = 0.1             # minimum storage_strength after decay
ARCHIVE_RETENTION = 0.05      # combined retention below this => archive


# ---------------------------------------------------------------------------
# Step 1: CLUSTER
# ---------------------------------------------------------------------------

def _get_active_memories(db: sqlite3.Connection) -> list[dict]:
    """Fetch all active, non-superseded, non-consolidated memories."""
    rows = db.execute("""
        SELECT m.id, m.name, m.type, m.content, m.importance,
               m.storage_strength, m.access_count, m.last_accessed,
               m.created, m.updated, m.status, m.consolidated_from
        FROM memories m
        WHERE m.active = 1
          AND m.status = 'active'
          AND (m.consolidated_from IS NULL OR m.consolidated_from = '')
    """).fetchall()
    return [dict(r) for r in rows]


def _get_embedding(db: sqlite3.Connection, memory_id: int) -> bytes | None:
    """Get raw embedding bytes for a memory from the vec table."""
    try:
        row = db.execute(
            "SELECT embedding FROM memories_vec WHERE memory_id = ?",
            (memory_id,)
        ).fetchone()
        return row[0] if row else None
    except Exception:
        return None


def _cosine_sim_from_bytes(a: bytes, b: bytes) -> float:
    """Compute cosine similarity between two embedding byte blobs.

    Assumes normalized embeddings (dot product = cosine similarity).
    """
    if not a or not b or len(a) != len(b):
        return 0.0
    dim = len(a) // 4  # float32
    va = struct.unpack(f"{dim}f", a)
    vb = struct.unpack(f"{dim}f", b)
    return sum(x * y for x, y in zip(va, vb))


def cluster_memories(db: sqlite3.Connection) -> dict[str, list[list[dict]]]:
    """Group active memories by type, then by embedding similarity.

    Returns: {type: [[mem1, mem2, mem3, ...], [memA, memB, memC, ...], ...]}
    Only includes clusters with >= MIN_CLUSTER_SIZE members.
    """
    memories = _get_active_memories(db)

    # Group by type first
    by_type: dict[str, list[dict]] = defaultdict(list)
    for m in memories:
        by_type[m["type"]].append(m)

    # Load embeddings
    embeddings: dict[int, bytes] = {}
    for m in memories:
        emb = _get_embedding(db, m["id"])
        if emb:
            embeddings[m["id"]] = emb

    all_clusters: dict[str, list[list[dict]]] = {}

    for mem_type, mems in by_type.items():
        # Filter to memories with embeddings for clustering
        with_emb = [m for m in mems if m["id"] in embeddings]

        if len(with_emb) < MIN_CLUSTER_SIZE:
            continue

        # Single-linkage clustering with similarity threshold
        clusters = _single_linkage_cluster(with_emb, embeddings)

        # Only keep clusters >= MIN_CLUSTER_SIZE
        valid = [c for c in clusters if len(c) >= MIN_CLUSTER_SIZE]
        if valid:
            all_clusters[mem_type] = valid

    return all_clusters


def _single_linkage_cluster(
    mems: list[dict], embeddings: dict[int, bytes]
) -> list[list[dict]]:
    """Simple single-linkage agglomerative clustering.

    A memory joins a cluster if it has >= SIMILARITY_THRESHOLD similarity
    with ANY member already in that cluster.
    """
    clusters: list[list[dict]] = []

    for m in mems:
        emb = embeddings[m["id"]]
        placed = False

        for cluster in clusters:
            for member in cluster:
                member_emb = embeddings[member["id"]]
                sim = _cosine_sim_from_bytes(emb, member_emb)
                if sim >= SIMILARITY_THRESHOLD:
                    cluster.append(m)
                    placed = True
                    break
            if placed:
                break

        if not placed:
            clusters.append([m])

    return clusters


# ---------------------------------------------------------------------------
# Step 2: MERGE
# ---------------------------------------------------------------------------

def merge_clusters(
    db: sqlite3.Connection, clusters: dict[str, list[list[dict]]], dry_run: bool = False
) -> list[dict]:
    """For each cluster, create one consolidated memory and supersede sources.

    Returns list of merge actions taken.
    """
    actions = []

    for mem_type, type_clusters in clusters.items():
        for cluster in type_clusters:
            if len(cluster) < MIN_CLUSTER_SIZE:
                continue

            source_ids = [m["id"] for m in cluster]
            max_importance = max(m.get("importance") or 0.5 for m in cluster)
            sum_storage = min(
                sum((m.get("storage_strength") or 1.0) for m in cluster),
                100.0,
            )

            # Concatenate key facts from cluster members
            contents = []
            for m in cluster:
                content = (m.get("content") or "").strip()
                if content:
                    contents.append(content)
            merged_content = " | ".join(contents)
            merged_name = f"[consolidated] {contents[0][:80]}" if contents else "[consolidated]"

            action = {
                "type": mem_type,
                "source_ids": source_ids,
                "merged_content_preview": merged_content[:200],
                "importance": max_importance,
                "storage_strength": sum_storage,
            }

            if not dry_run:
                new_id = _create_consolidated(
                    db,
                    name=merged_name[:120],
                    mem_type=mem_type,
                    content=merged_content,
                    importance=max_importance,
                    storage_strength=sum_storage,
                    source_ids=source_ids,
                )
                action["new_id"] = new_id

                # Mark sources as superseded
                for sid in source_ids:
                    db.execute(
                        "UPDATE memories SET status = 'superseded', superseded_by = ? "
                        "WHERE id = ?",
                        (new_id, sid),
                    )
                db.commit()

            actions.append(action)

    return actions


def _create_consolidated(
    db: sqlite3.Connection,
    name: str,
    mem_type: str,
    content: str,
    importance: float,
    storage_strength: float,
    source_ids: list[int],
) -> int:
    """Insert a new consolidated memory with consolidated_from metadata."""
    consolidated_from = json.dumps(source_ids)
    db.execute("""
        INSERT INTO memories (name, type, memory_class, tags, content, importance,
                              storage_strength, consolidated_from,
                              created, updated, active, status)
        VALUES (?, ?, 'semantic', '', ?, ?, ?, ?, datetime('now'), datetime('now'), 1, 'active')
    """, (name, mem_type, content, importance, storage_strength, consolidated_from))
    db.commit()
    new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Update embedding for consolidated content if vec is available
    if aibrain_db._db_vec_enabled:
        emb = aibrain_db._compute_embedding(f"{name} {content}")
        if emb is not None:
            emb_bytes = struct.pack(f"{len(emb)}f", *emb)
            try:
                db.execute(
                    "INSERT INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                    (new_id, emb_bytes),
                )
                db.commit()
            except Exception:
                pass

    return new_id


# ---------------------------------------------------------------------------
# Step 3: DECAY
# ---------------------------------------------------------------------------

def decay_memories(db: sqlite3.Connection, dry_run: bool = False) -> int:
    """Reduce storage_strength for memories not accessed in 30+ days.

    Falls back to created date when last_accessed is NULL (never-accessed
    memories). Without this fallback, ~95% of memories with NULL last_accessed
    would never decay.

    Returns count of decayed memories.
    """
    if dry_run:
        row = db.execute("""
            SELECT COUNT(*) FROM memories
            WHERE status = 'active' AND active = 1
              AND COALESCE(last_accessed, created) < datetime('now', '-30 days')
              AND COALESCE(last_accessed, created) IS NOT NULL
              AND COALESCE(storage_strength, 1.0) > ?
        """, (DECAY_FLOOR,)).fetchone()
        return row[0] if row else 0

    result = db.execute("""
        UPDATE memories
        SET storage_strength = MAX(
            ?,
            COALESCE(storage_strength, 1.0) - ? * (
                julianday('now') - julianday(COALESCE(last_accessed, created))
            )
        )
        WHERE status = 'active' AND active = 1
          AND COALESCE(last_accessed, created) < datetime('now', '-30 days')
          AND COALESCE(last_accessed, created) IS NOT NULL
          AND COALESCE(storage_strength, 1.0) > ?
    """, (DECAY_FLOOR, DECAY_RATE, DECAY_FLOOR))
    db.commit()
    return result.rowcount


# ---------------------------------------------------------------------------
# Step 4: ARCHIVE
# ---------------------------------------------------------------------------

def archive_weak_memories(db: sqlite3.Connection, dry_run: bool = False) -> int:
    """Archive memories whose combined retention < ARCHIVE_RETENTION.

    Combined retention = 0.7 * retrieval_strength + 0.3 * (storage_strength / 10).
    retrieval_strength approximated by power-law decay from updated timestamp.
    """
    rows = db.execute("""
        SELECT id, updated, storage_strength
        FROM memories
        WHERE status = 'active' AND active = 1
    """).fetchall()

    now = datetime.now(timezone.utc)
    to_archive = []

    for row in rows:
        updated_str = row[1]
        storage = row[2] if row[2] is not None else 1.0

        try:
            dt_str = str(updated_str).replace("T", " ").split(".")[0][:19]
            updated_dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
            updated_dt = updated_dt.replace(tzinfo=timezone.utc)
            days_since = (now - updated_dt).total_seconds() / 86400.0
        except (ValueError, TypeError):
            continue  # skip if we can't parse date

        # Power-law decay matching _salience_score: stability=30 days
        retrieval = (1.0 + days_since / 30.0) ** -1.0 if days_since >= 0 else 1.0
        storage_norm = min(storage / 10.0, 1.0)
        retention = 0.7 * retrieval + 0.3 * storage_norm

        if retention < ARCHIVE_RETENTION:
            to_archive.append(row[0])

    if dry_run:
        return len(to_archive)

    if to_archive:
        placeholders = ",".join("?" * len(to_archive))
        db.execute(
            f"UPDATE memories SET status = 'archived' WHERE id IN ({placeholders})",  # noqa:SQL-FSTRING
            to_archive,
        )
        db.commit()

    return len(to_archive)


# ---------------------------------------------------------------------------
# Step 5: REBUILD category summaries
# ---------------------------------------------------------------------------

def rebuild_category_summaries(db: sqlite3.Connection, dry_run: bool = False) -> list[str]:
    """Regenerate category_summaries for all active memory types.

    Returns list of category names rebuilt.
    """
    rows = db.execute("""
        SELECT DISTINCT type FROM memories
        WHERE active = 1 AND status = 'active'
    """).fetchall()

    categories = [r[0] for r in rows if r[0]]

    if not dry_run:
        for cat in categories:
            try:
                aibrain_db.update_category_summary(cat, db=db)
            except Exception as e:
                logger.warning("Failed to rebuild summary for %s: %s", cat, e)

    return categories


# ---------------------------------------------------------------------------
# Main consolidation runner
# ---------------------------------------------------------------------------

def run_consolidation(dry_run: bool = False, verbose: bool = False) -> dict:
    """Execute the full 5-step consolidation cycle.

    Returns a summary dict with counts for each step.
    """
    db = aibrain_db.get_db()

    if verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    result = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "dry_run": dry_run,
        "clusters_found": 0,
        "memories_merged": 0,
        "consolidated_entries_created": 0,
        "memories_decayed": 0,
        "memories_archived": 0,
        "categories_rebuilt": [],
    }

    # Step 1: CLUSTER
    logger.info("Step 1/5: Clustering memories by type + embedding similarity...")
    clusters = cluster_memories(db)
    total_clustered = sum(len(m) for cl in clusters.values() for m in cl)
    result["clusters_found"] = sum(len(cl) for cl in clusters.values())
    logger.info("  Found %d clusters across %d types (%d memories)",
                result["clusters_found"], len(clusters), total_clustered)

    # Step 2: MERGE
    logger.info("Step 2/5: Merging clusters (min size %d)...", MIN_CLUSTER_SIZE)
    merge_actions = merge_clusters(db, clusters, dry_run=dry_run)
    result["consolidated_entries_created"] = len(merge_actions)
    result["memories_merged"] = sum(len(a["source_ids"]) for a in merge_actions)
    logger.info("  Created %d consolidated entries from %d source memories",
                result["consolidated_entries_created"], result["memories_merged"])

    # Step 3: DECAY
    logger.info("Step 3/5: Decaying stale memories (>%d days)...", DECAY_DAYS)
    result["memories_decayed"] = decay_memories(db, dry_run=dry_run)
    logger.info("  Decayed %d memories", result["memories_decayed"])

    # Step 4: ARCHIVE
    logger.info("Step 4/5: Archiving weak memories (retention < %.2f)...", ARCHIVE_RETENTION)
    result["memories_archived"] = archive_weak_memories(db, dry_run=dry_run)
    logger.info("  Archived %d memories", result["memories_archived"])

    # Step 5: REBUILD
    logger.info("Step 5/5: Rebuilding category summaries...")
    result["categories_rebuilt"] = rebuild_category_summaries(db, dry_run=dry_run)
    logger.info("  Rebuilt %d categories: %s", len(result["categories_rebuilt"]),
                ", ".join(result["categories_rebuilt"][:10]))

    # Log to execution_log
    if not dry_run:
        try:
            db.execute("""
                INSERT INTO execution_log (action, success, quality_score, task_type, created_at)
                VALUES ('memory_consolidation', 1, 1.0, 'deterministic', datetime('now'))
            """)
            db.commit()
        except Exception:
            pass

    return result


# ---------------------------------------------------------------------------
# Workflow registration helper
# ---------------------------------------------------------------------------

def register_workflow(db: sqlite3.Connection | None = None):
    """Register this workflow in the workflows table if not already present."""
    if db is None:
        db = aibrain_db.get_db()

    existing = db.execute(
        "SELECT id FROM workflows WHERE name = 'memory_consolidation'"
    ).fetchone()

    if existing:
        return existing[0]

    db.execute("""
        INSERT INTO workflows (name, display_name, category, description,
                               cron_schedule, script_path, enabled, source,
                               created, updated)
        VALUES (
            'memory_consolidation',
            'Memory Consolidation (Sleep Cycle)',
            'maintenance',
            'Nightly brain consolidation: cluster similar memories, merge clusters of 3+, decay stale entries, archive weak memories, rebuild category summaries.',
            '0 3 * * *',
            'workflows/memory_consolidation.py',
            1,
            'builtin',
            datetime('now'),
            datetime('now')
        )
    """)
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Memory consolidation — nightly sleep cycle for the brain"
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview what would happen without making changes")
    parser.add_argument("--verbose", action="store_true",
                        help="Detailed output")
    args = parser.parse_args()

    result = run_consolidation(dry_run=args.dry_run, verbose=args.verbose)

    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        sys.exit(main())
    workflow_execute(
        workflow_name='memory_consolidation',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
