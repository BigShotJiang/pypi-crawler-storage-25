#!/usr/bin/env python3
"""AIBrain Workflow: Weekly Report — generate a summary of the week's activity, costs, and achievements."""

import argparse
import json
import os
import re
import sqlite3
import subprocess
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))
CONFIG = json.loads((AIBRAIN_ROOT / "config.json").read_text()) if (AIBRAIN_ROOT / "config.json").exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())


def api_get(endpoint):
    """Fetch JSON from the AIBrain API."""
    try:
        url = f"{API_BASE}/{endpoint}"
        req = urllib.request.Request(url)
        resp = urllib.request.urlopen(req, timeout=10)
        return json.loads(resp.read())
    except Exception:
        return None


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def get_week_stats():
    """Gather stats from the past 7 days."""
    stats = {}

    # Memory stats
    db = get_db()
    cutoff = (datetime.now() - timedelta(days=7)).isoformat()
    new_memories = db.execute(
        "SELECT COUNT(*) FROM memories WHERE active = 1 AND created > ?", (cutoff,)
    ).fetchone()[0]
    total_memories = db.execute(
        "SELECT COUNT(*) FROM memories WHERE active = 1"
    ).fetchone()[0]
    db.close()
    stats["new_memories"] = new_memories
    stats["total_memories"] = total_memories

    # Cost summary
    cost_data = api_get("costs/summary?days=7")
    if cost_data:
        stats["weekly_cost"] = cost_data.get("total_cost", cost_data.get("total_cost_usd", 0))
        stats["llm_calls"] = cost_data.get("total_calls", 0)
    else:
        stats["weekly_cost"] = 0
        stats["llm_calls"] = 0

    # Approval summary
    approval_data = api_get("approvals/summary")
    if approval_data:
        stats["approvals_total"] = approval_data.get("total", 0)
        stats["approvals_pending"] = approval_data.get("pending", 0)
    else:
        stats["approvals_total"] = 0
        stats["approvals_pending"] = 0

    # Activity
    activity_data = api_get("activity?limit=100")
    if activity_data:
        entries = activity_data.get("entries", [])
        cutoff_dt = datetime.now() - timedelta(days=7)
        week_entries = [e for e in entries if datetime.fromisoformat(e.get("timestamp", "2000-01-01")[:19]) > cutoff_dt]
        stats["activity_count"] = len(week_entries)

        # Group by category
        categories = {}
        for e in week_entries:
            cat = e.get("category", "other")
            categories[cat] = categories.get(cat, 0) + 1
        stats["activity_by_category"] = categories
    else:
        stats["activity_count"] = 0
        stats["activity_by_category"] = {}

    # Scheduler
    sched_data = api_get("scheduler/status")
    if sched_data:
        stats["scheduled_jobs"] = sched_data.get("job_count", 0)
        stats["scheduler_running"] = sched_data.get("running", False)
    else:
        stats["scheduled_jobs"] = 0
        stats["scheduler_running"] = False

    # --- Workflow Run Summary ---
    stats["workflow_runs"] = None
    runs_data = api_get("workflows/runs")
    if runs_data:
        runs = runs_data if isinstance(runs_data, list) else runs_data.get("runs", [])
        cutoff_dt = datetime.now() - timedelta(days=7)
        week_runs = []
        for r in runs:
            ts = r.get("started_at") or r.get("timestamp") or r.get("created", "2000-01-01")
            try:
                if datetime.fromisoformat(ts[:19]) > cutoff_dt:
                    week_runs.append(r)
            except (ValueError, TypeError):
                pass
        total = len(week_runs)
        passed = sum(1 for r in week_runs if r.get("status") in ("success", "passed", "ok"))
        failed = sum(1 for r in week_runs if r.get("status") in ("failed", "error"))
        durations = [r.get("duration", 0) for r in week_runs if r.get("duration")]
        avg_duration = sum(durations) / len(durations) if durations else 0

        # Top workflows by count
        wf_counts = {}
        for r in week_runs:
            name = r.get("workflow") or r.get("name") or "unknown"
            wf_counts[name] = wf_counts.get(name, 0) + 1
        top_workflows = sorted(wf_counts.items(), key=lambda x: -x[1])[:5]

        # Failed runs with error snippets
        failed_runs = []
        for r in week_runs:
            if r.get("status") in ("failed", "error"):
                error_msg = r.get("error") or r.get("detail") or "unknown error"
                if len(error_msg) > 60:
                    error_msg = error_msg[:57] + "..."
                ts = r.get("started_at") or r.get("timestamp") or ""
                try:
                    fail_date = datetime.fromisoformat(ts[:19]).strftime("%b %d")
                except (ValueError, TypeError):
                    fail_date = "?"
                wf_name = r.get("workflow") or r.get("name") or "unknown"
                failed_runs.append((wf_name, error_msg, fail_date))

        stats["workflow_runs"] = {
            "total": total,
            "passed": passed,
            "failed": failed,
            "avg_duration": avg_duration,
            "top_workflows": top_workflows,
            "failed_runs": failed_runs[:5],
        }

    # --- Git Activity ---
    stats["git"] = None
    try:
        since = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        git_dir = str(AIBRAIN_ROOT)

        commit_count = subprocess.run(
            ["git", "rev-list", "--count", f"--since={since}", "HEAD"],
            capture_output=True, text=True, cwd=git_dir, timeout=15,
        )
        shortlog = subprocess.run(
            ["git", "log", f"--since={since}", "--pretty=format:%h %s", "-5"],
            capture_output=True, text=True, cwd=git_dir, timeout=15,
        )
        diffstat = subprocess.run(
            ["git", "log", f"--since={since}", "--shortstat", "--pretty="],
            capture_output=True, text=True, cwd=git_dir, timeout=15,
        )

        if commit_count.returncode == 0:
            commits = int(commit_count.stdout.strip() or "0")
            recent = [l.strip() for l in shortlog.stdout.strip().splitlines() if l.strip()]

            files_changed = 0
            insertions = 0
            deletions = 0
            for line in diffstat.stdout.strip().splitlines():
                line = line.strip()
                if not line:
                    continue
                # e.g. "3 files changed, 120 insertions(+), 40 deletions(-)"
                m_files = re.search(r"(\d+) files? changed", line)
                m_ins = re.search(r"(\d+) insertions?", line)
                m_del = re.search(r"(\d+) deletions?", line)
                if m_files:
                    files_changed += int(m_files.group(1))
                if m_ins:
                    insertions += int(m_ins.group(1))
                if m_del:
                    deletions += int(m_del.group(1))

            stats["git"] = {
                "commits": commits,
                "files_changed": files_changed,
                "insertions": insertions,
                "deletions": deletions,
                "recent": recent,
            }
    except Exception:
        pass

    # --- Pattern Bus Events ---
    stats["pattern_bus"] = None
    pb_data = api_get("pattern-bus/stats")
    if pb_data:
        stats["pattern_bus"] = {
            "total": pb_data.get("total_events", pb_data.get("total", 0)),
            "by_domain": pb_data.get("by_domain", {}),
            "by_type": pb_data.get("by_type", {}),
        }

    # --- Email Triage Summary ---
    stats["email"] = None
    try:
        db = get_db()
        # Look for email triage state in workflow_state or memories
        row = db.execute(
            "SELECT content FROM memories WHERE name LIKE '%email_triage%' AND active = 1 ORDER BY updated DESC LIMIT 1"  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
        ).fetchone()
        if row:
            try:
                email_state = json.loads(row[0])
            except (json.JSONDecodeError, TypeError):
                email_state = None
            if email_state and isinstance(email_state, dict):
                stats["email"] = {
                    "total": email_state.get("processed", email_state.get("total", 0)),
                    "urgent": email_state.get("urgent", 0),
                    "action": email_state.get("action", 0),
                    "fyi": email_state.get("fyi", 0),
                }
        db.close()
    except Exception:
        pass

    # --- Evolution Summary ---
    stats["evolution"] = None
    evo_data = api_get("evolution/status")
    if evo_data:
        stats["evolution"] = {
            "active_patterns": evo_data.get("active_patterns", 0),
            "experiments_run": evo_data.get("experiments_run", evo_data.get("experiments", 0)),
            "improvements": evo_data.get("improvements_made", evo_data.get("improvements", 0)),
        }

    return stats


def format_report(stats):
    """Format the weekly report as readable text."""
    now = datetime.now()
    week_start = (now - timedelta(days=7)).strftime("%b %d")
    week_end = now.strftime("%b %d, %Y")

    lines = [
        f"AIBRAIN WEEKLY REPORT",
        f"{week_start} — {week_end}",
        "=" * 50,
        "",
        "SYSTEM STATUS",
        f"  Scheduler: {'Running' if stats['scheduler_running'] else 'Stopped'} ({stats['scheduled_jobs']} jobs)",
        f"  Total memories: {stats['total_memories']}",
        "",
        "THIS WEEK",
        f"  New memories created: {stats['new_memories']}",
        f"  Activity events: {stats['activity_count']}",
        f"  LLM calls: {stats['llm_calls']}",
        f"  LLM cost: ${stats['weekly_cost']:.4f}",
        f"  Approvals processed: {stats['approvals_total']}",
        f"  Approvals pending: {stats['approvals_pending']}",
    ]

    if stats["activity_by_category"]:
        lines.append("")
        lines.append("ACTIVITY BY CATEGORY")
        for cat, count in sorted(stats["activity_by_category"].items(), key=lambda x: -x[1]):
            lines.append(f"  {cat:<20} {count}")

    # Workflow Runs
    wr = stats.get("workflow_runs")
    if wr:
        lines.append("")
        lines.append("WORKFLOW RUNS")
        lines.append(f"  Total: {wr['total']} | Passed: {wr['passed']} | Failed: {wr['failed']}")
        lines.append(f"  Avg duration: {wr['avg_duration']:.1f}s")
        if wr["top_workflows"]:
            lines.append("  Top workflows:")
            for name, count in wr["top_workflows"]:
                lines.append(f"    {name:<25} {count} runs")
        if wr["failed_runs"]:
            lines.append("  Failed:")
            for wf_name, error_msg, fail_date in wr["failed_runs"]:
                lines.append(f'    {wf_name} — "{error_msg}" ({fail_date})')

    # Git Activity
    git = stats.get("git")
    if git:
        lines.append("")
        lines.append("GIT ACTIVITY")
        lines.append(f"  Commits: {git['commits']}")
        lines.append(f"  Files changed: {git['files_changed']}")
        lines.append(f"  +{git['insertions']} / -{git['deletions']} lines")
        if git["recent"]:
            lines.append("  Recent:")
            for msg in git["recent"]:
                lines.append(f"    {msg}")

    # Pattern Bus
    pb = stats.get("pattern_bus")
    if pb:
        lines.append("")
        lines.append("PATTERN BUS")
        lines.append(f"  Events this week: {pb['total']}")
        if pb["by_domain"]:
            domain_parts = [f"{k}({v})" for k, v in sorted(pb["by_domain"].items(), key=lambda x: -x[1])]
            lines.append(f"  By domain: {', '.join(domain_parts)}")
        if pb["by_type"]:
            type_parts = [f"{k}({v})" for k, v in sorted(pb["by_type"].items(), key=lambda x: -x[1])]
            lines.append(f"  By type: {', '.join(type_parts)}")

    # Email Triage
    email = stats.get("email")
    if email:
        lines.append("")
        lines.append("EMAIL")
        lines.append(f"  Triaged: {email['total']} emails")
        lines.append(f"  Urgent: {email['urgent']} | Action: {email['action']} | FYI: {email['fyi']}")

    # Evolution
    evo = stats.get("evolution")
    if evo:
        lines.append("")
        lines.append("EVOLUTION")
        lines.append(f"  Active patterns: {evo['active_patterns']}")
        lines.append(f"  Experiments run: {evo['experiments_run']}")
        lines.append(f"  Improvements made: {evo['improvements']}")

    lines.extend([
        "",
        "=" * 50,
        f"Generated: {now.strftime('%Y-%m-%d %H:%M')}",
    ])

    return "\n".join(lines)


def run(dry_run=False):
    """Generate and save the weekly report."""
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Generating weekly report...")

    stats = get_week_stats()
    report = format_report(stats)
    print(report)

    if dry_run:
        print("\n[dry-run] Not saving.")
        return

    # Save to memory
    db = get_db()
    now = datetime.now().isoformat()
    name = f"Weekly Report {datetime.now().strftime('%Y-%m-%d')}"
    db.execute(
        "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
        (name, "reference", "report,weekly,auto-generated", report, now, now),
    )
    db.commit()
    db.close()
    print(f"\nSaved to memory as '{name}'")

    log_activity("weekly_report", f"Generated weekly report: {stats['new_memories']} new memories, ${stats['weekly_cost']:.4f} cost")


def main():
    parser = argparse.ArgumentParser(description="Generate AIBrain weekly summary report")
    parser.add_argument("--dry-run", action="store_true", help="Preview without saving")
    args = parser.parse_args()
    run(dry_run=args.dry_run)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='weekly_report',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
