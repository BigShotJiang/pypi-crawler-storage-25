#!/usr/bin/env python3
"""AIBrain Workflow: Smart File Organizer -- classify files and propose moves via approval queue."""

import argparse
import datetime
import json
import os
import re
import sqlite3
import sys
import urllib.request
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}

def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = Path(os.environ.get("AIBRAIN_DB", _find_db()))

API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

# ---------------------------------------------------------------------------
# Classification rules
# ---------------------------------------------------------------------------

EXTENSION_CATEGORIES = {
    "Documents": {".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".pages", ".md"},
    "Spreadsheets": {".xlsx", ".xls", ".csv", ".ods", ".numbers"},
    "Presentations": {".pptx", ".ppt", ".key", ".odp"},
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".svg", ".webp", ".bmp", ".ico", ".tiff"},
    "Videos": {".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm"},
    "Audio": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"},
    "Archives": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"},
    "Code": {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".java", ".c", ".cpp", ".h", ".rb", ".php"},
    "Data": {".json", ".xml", ".yaml", ".yml", ".toml", ".ini", ".env", ".sql", ".db"},
    "Installers": {".exe", ".msi", ".dmg", ".deb", ".rpm", ".appimage"},
}

# Build reverse lookup: extension -> category
_EXT_TO_CATEGORY = {}
for _cat, _exts in EXTENSION_CATEGORIES.items():
    for _ext in _exts:
        _EXT_TO_CATEGORY[_ext] = _cat

NAME_PATTERNS = [
    (re.compile(r"(?i)(resume|cv)"), "Career"),
    (re.compile(r"(?i)(invoice|receipt|payment)"), "Finance"),
    (re.compile(r"(?i)(screenshot|screen[\s_-]?shot)"), "Screenshots"),
]

DATE_PATTERN = re.compile(r"(\d{4})[-_]?(\d{2})[-_]?(\d{2})")


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def get_db():
    db = sqlite3.connect(str(DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute(
                "UPDATE memories SET content=?, updated=? WHERE id=?",
                (json.dumps(state), now, existing["id"]),
            )
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state,file_organizer",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def create_approval(category, title, detail, payload):
    """Create an approval queue entry in the consolidated DB."""
    db = get_db()
    now = datetime.datetime.now().isoformat()
    payload_str = json.dumps(payload)
    # Try the approvals table (consolidated DB schema)
    try:
        db.execute(
            "INSERT INTO approvals (created, updated, category, title, detail, payload, status) "
            "VALUES (?, ?, ?, ?, ?, ?, 'pending')",
            (now, now, category, title, detail, payload_str),
        )
        db.commit()
        approval_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
        db.close()
        return approval_id
    except sqlite3.OperationalError:
        db.close()
    # Fallback: try the approval_queue table (legacy schema)
    try:
        db = get_db()
        db.execute(
            "INSERT INTO approval_queue (created, updated, category, title, detail, payload, status) "
            "VALUES (?, ?, ?, ?, ?, ?, 'pending')",
            (now, now, category, title, detail, payload_str),
        )
        db.commit()
        approval_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
        db.close()
        return approval_id
    except sqlite3.OperationalError:
        db.close()
    # Last resort: POST to API
    try:
        data = json.dumps({
            "category": category, "title": title,
            "detail": detail, "payload": payload,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/approvals",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        resp = urllib.request.urlopen(req, timeout=5)
        result = json.loads(resp.read())
        return result.get("id", -1)
    except Exception:
        return -1


def log_activity(action, detail="", status="ok"):
    """Log to AIBrain activity feed via API."""
    try:
        data = json.dumps({
            "action": action,
            "category": "file_management",
            "detail": detail,
            "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass  # Non-critical -- don't break the workflow


# ---------------------------------------------------------------------------
# File classification
# ---------------------------------------------------------------------------

def human_size(size_bytes):
    for unit in ("B", "KB", "MB", "GB"):
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def file_fingerprint(path):
    """Quick fingerprint using modification time + size (no full hash needed)."""
    try:
        st = path.stat()
        return f"{st.st_mtime:.6f}:{st.st_size}"
    except (PermissionError, OSError):
        return None


def classify_file(filepath):
    """
    Returns (category, subcategory) for a file.
    subcategory may be None if no name pattern matches.
    """
    ext = filepath.suffix.lower()
    name_lower = filepath.stem.lower()

    # Check name patterns first (they override extension-based category)
    subcategory = None
    for pattern, subcat in NAME_PATTERNS:
        if pattern.search(name_lower):
            subcategory = subcat
            break

    # Extension-based category
    category = _EXT_TO_CATEGORY.get(ext)
    if category is None:
        category = "Other"

    return category, subcategory


def extract_date_from_name(filename):
    """Try to extract a date from the filename. Returns date string or None."""
    m = DATE_PATTERN.search(filename)
    if m:
        try:
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            dt = datetime.date(y, mo, d)
            return dt.isoformat()
        except (ValueError, OverflowError):
            return None
    return None


# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------

def scan_directory(dir_path, min_age_hours=1):
    """
    Scan a directory for files. Returns list of file_info dicts.
    Only top-level files (no recursion into subdirs).
    """
    dir_path = Path(dir_path).expanduser().resolve()
    if not dir_path.exists():
        return []

    now = datetime.datetime.now().timestamp()
    min_age_seconds = min_age_hours * 3600
    results = []

    for item in dir_path.iterdir():
        if item.is_dir():
            continue
        # Skip hidden files
        if item.name.startswith("."):
            continue
        try:
            st = item.stat()
        except (PermissionError, OSError):
            continue

        age_seconds = now - st.st_mtime
        too_new = age_seconds < min_age_seconds

        category, subcategory = classify_file(item)
        date_extracted = extract_date_from_name(item.name)
        modified_dt = datetime.datetime.fromtimestamp(st.st_mtime)

        results.append({
            "path": str(item),
            "name": item.name,
            "size_bytes": st.st_size,
            "size_human": human_size(st.st_size),
            "modified": modified_dt.isoformat(),
            "modified_display": modified_dt.strftime("%Y-%m-%d"),
            "category": category,
            "subcategory": subcategory,
            "date_extracted": date_extracted,
            "fingerprint": file_fingerprint(item),
            "too_new": too_new,
            "source_dir": str(dir_path),
        })

    return results


def determine_destination(file_info, dest_root):
    """Determine where a file should go. Subcategory overrides category."""
    dest_root = Path(dest_root).expanduser().resolve()
    if file_info["subcategory"]:
        return dest_root / file_info["subcategory"]
    if file_info["category"] and file_info["category"] != "Other":
        return dest_root / file_info["category"]
    return None  # Don't propose moves for "Other" files


# ---------------------------------------------------------------------------
# Main workflow
# ---------------------------------------------------------------------------

def run_organizer(dry_run=False, scan_only=False):
    now = datetime.datetime.now()
    header_date = now.strftime("%A %B %d, %Y")

    # Load config
    watch_dirs = CONFIG.get("file_organizer_watch_dirs", ["~/Downloads", "~/Desktop"])
    dest_root = CONFIG.get("file_organizer_dest", "~/Organized")
    min_age_hours = CONFIG.get("file_organizer_min_age_hours", 1)
    max_files = CONFIG.get("file_organizer_max_files", 50)

    # Load previous state
    state = load_state("file_organizer")
    processed_files = {p["fingerprint"] for p in state.get("processed_files", []) if p.get("fingerprint")}

    # Scan all watch directories
    all_files = []
    for wd in watch_dirs:
        all_files.extend(scan_directory(wd, min_age_hours))

    total_found = len(all_files)

    # Separate into new vs already processed
    new_files = []
    already_processed = 0
    for f in all_files:
        if f["fingerprint"] and f["fingerprint"] in processed_files:
            already_processed += 1
        else:
            new_files.append(f)

    # Resolve display paths for watch dirs
    watch_display = ", ".join(str(Path(d).expanduser()) for d in watch_dirs)

    # Build output
    lines = [
        f"SMART FILE ORGANIZER -- {header_date}",
        "=" * 50,
        f"Scanning: {watch_display}",
        f"Files found: {total_found} | New: {len(new_files)} | Already processed: {already_processed}",
        "",
    ]

    if scan_only:
        lines.append("MODE: Scan only (no proposals)")
        lines.append("")
        if new_files:
            lines.append("FILES FOUND:")
            for f in sorted(new_files, key=lambda x: x["category"]):
                dest_dir = determine_destination(f, dest_root)
                dest_label = dest_dir.name + "/" if dest_dir else "(no category)"
                tag = f["subcategory"] or f["category"]
                lines.append(f"  [{tag:14s}] {f['name']:40s} {f['size_human']:>10s}  -> {dest_label}")
        else:
            lines.append("No new files to organize.")
        lines.append("")
        lines.append(f"Summary: {len(new_files)} files found across {len(watch_dirs)} directories")
        lines.append("=" * 50)
        print("\n".join(lines))
        return

    # Build proposed actions
    proposed = []
    skipped = []
    for f in new_files:
        if f["too_new"]:
            skipped.append((f, f"too new, < {min_age_hours}h old"))
            continue
        dest_dir = determine_destination(f, dest_root)
        if dest_dir is None:
            skipped.append((f, "uncategorized extension"))
            continue
        dest_path = dest_dir / f["name"]
        proposed.append({
            "file_info": f,
            "dest_dir": str(dest_dir),
            "dest_path": str(dest_path),
        })

    # Cap to max_files
    if len(proposed) > max_files:
        overflow = len(proposed) - max_files
        proposed = proposed[:max_files]
        skipped.append((None, f"{overflow} more files capped by max_files={max_files}"))

    # Display proposed actions
    if proposed:
        lines.append("PROPOSED ACTIONS:")
        for p in proposed:
            f = p["file_info"]
            dest_label = Path(p["dest_dir"]).name + "/"
            lines.append(f"  MOVE  {f['name']:40s} -> {dest_label}")
    if skipped:
        for s_file, reason in skipped:
            if s_file:
                lines.append(f"  SKIP  {s_file['name']:40s} ({reason})")
            else:
                lines.append(f"  SKIP  ({reason})")
    if not proposed and not skipped:
        lines.append("No new files to organize.")

    lines.append("")
    lines.append(f"Summary: {len(proposed)} actions queued for approval, {len(skipped)} skipped")
    lines.append("=" * 50)

    print("\n".join(lines))

    # If dry run, stop here
    if dry_run:
        return

    # Create approval queue entries
    created_count = 0
    newly_processed = list(state.get("processed_files", []))

    for p in proposed:
        f = p["file_info"]
        title = f"Move: {f['name']} -> {Path(p['dest_dir']).name}/"
        detail = (
            f"File: {f['path']} ({f['size_human']}, modified {f['modified_display']})\n"
            f"Proposed: Move to {p['dest_path']}"
        )
        payload = {
            "source_path": f["path"],
            "dest_path": p["dest_path"],
            "action": "move",
            "category": f["subcategory"] or f["category"],
            "size_bytes": f["size_bytes"],
            "modified": f["modified"],
        }

        approval_id = create_approval("file_management", title, detail, payload)
        if approval_id and approval_id > 0:
            created_count += 1

        # Track as processed regardless of approval success
        newly_processed.append({
            "path": f["path"],
            "fingerprint": f["fingerprint"],
            "proposed_at": now.isoformat(),
        })

    # Also mark skipped-but-scanned files as processed (to avoid re-proposing)
    for s_file, reason in skipped:
        if s_file and s_file.get("fingerprint"):
            newly_processed.append({
                "path": s_file["path"],
                "fingerprint": s_file["fingerprint"],
                "proposed_at": now.isoformat(),
            })

    # Save state
    save_state("file_organizer", {
        "last_run": now.isoformat(),
        "files_scanned": total_found,
        "actions_proposed": created_count,
        "processed_files": newly_processed,
    })

    # Log activity
    log_activity(
        "smart_file_organizer",
        f"Scanned {total_found} files, proposed {created_count} moves for approval",
    )

    if created_count > 0:
        print(f"\n{created_count} approval requests created. Review them in the AIBrain dashboard.")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="AIBrain Smart File Organizer -- classify files and propose moves via approval queue",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print proposed actions without creating approval requests",
    )
    parser.add_argument(
        "--scan-only", action="store_true",
        help="Just report what files are found, no proposals",
    )
    parser.add_argument(
        "--watch-dirs", nargs="+",
        help="Override watch directories (default: from config or ~/Downloads ~/Desktop)",
    )
    parser.add_argument(
        "--dest",
        help="Override destination root (default: from config or ~/Organized)",
    )
    parser.add_argument(
        "--min-age", type=float, default=None,
        help="Minimum file age in hours before organizing (default: 1)",
    )
    parser.add_argument(
        "--max-files", type=int, default=None,
        help="Max files to propose per run (default: 50)",
    )
    parser.add_argument(
        "--reset-state", action="store_true",
        help="Clear processed files list and start fresh",
    )
    args = parser.parse_args()

    # CLI overrides for config values
    if args.watch_dirs:
        CONFIG["file_organizer_watch_dirs"] = args.watch_dirs
    if args.dest:
        CONFIG["file_organizer_dest"] = args.dest
    if args.min_age is not None:
        CONFIG["file_organizer_min_age_hours"] = args.min_age
    if args.max_files is not None:
        CONFIG["file_organizer_max_files"] = args.max_files

    if args.reset_state:
        save_state("file_organizer", {
            "last_run": datetime.datetime.now().isoformat(),
            "files_scanned": 0,
            "actions_proposed": 0,
            "processed_files": [],
        })
        print("State reset. All files will be re-evaluated on next run.")
        return

    run_organizer(dry_run=args.dry_run, scan_only=args.scan_only)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='smart_file_organizer',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
