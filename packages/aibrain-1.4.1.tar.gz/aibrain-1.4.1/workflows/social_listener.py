#!/usr/bin/env python3
"""AIBrain Workflow: Social Listener — monitor mentions across HN, Reddit, RSS."""

import argparse
import datetime
import hashlib
import json
import os
import smtplib
import sqlite3
import sys
import time
from email.mime.text import MIMEText
from pathlib import Path

import feedparser
import requests

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())

DEFAULT_KEYWORDS = ["AIBrain", "ai brain"]
HEADERS = {"User-Agent": "AIBrain/1.0 (social listener)"}


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def search_hn(keywords):
    mentions = []
    try:
        for kw in keywords:
            resp = requests.get(f"https://hn.algolia.com/api/v1/search_by_date?query={kw}&tags=story",
                              headers=HEADERS, timeout=10)
            for hit in resp.json().get("hits", [])[:5]:
                mentions.append({
                    "source": "Hacker News",
                    "title": hit.get("title", ""),
                    "url": hit.get("url", f"https://news.ycombinator.com/item?id={hit.get('objectID')}"),
                    "score": hit.get("points", 0),
                    "date": hit.get("created_at", "")[:10],
                    "keyword": kw,
                })
            time.sleep(0.5)
    except Exception as e:
        print(f"HN search error: {e}", file=sys.stderr)
    return mentions


def search_reddit(keywords, subreddits=None):
    mentions = []
    subs = subreddits or ["all"]
    for kw in keywords:
        for sub in subs[:2]:
            try:
                time.sleep(1)
                resp = requests.get(
                    f"https://www.reddit.com/r/{sub}/search.json?q={kw}&sort=new&t=week&limit=5",
                    headers=HEADERS, timeout=10,
                )
                if resp.status_code == 429:
                    continue
                for post in resp.json().get("data", {}).get("children", []):
                    pd = post["data"]
                    mentions.append({
                        "source": f"r/{sub}",
                        "title": pd.get("title", ""),
                        "url": f"https://reddit.com{pd.get('permalink', '')}",
                        "score": pd.get("score", 0),
                        "date": datetime.datetime.fromtimestamp(pd.get("created_utc", 0)).strftime("%Y-%m-%d"),
                        "keyword": kw,
                    })
            except Exception:
                continue
    return mentions


def format_report(mentions, seen_ids):
    new = [m for m in mentions if hashlib.md5(m["url"].encode()).hexdigest() not in seen_ids]

    lines = [
        f"SOCIAL LISTENER — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        f"Found: {len(new)} new mentions ({len(mentions)} total scanned)",
        "=" * 50,
        "",
    ]

    if new:
        by_source = {}
        for m in new:
            by_source.setdefault(m["source"], []).append(m)

        for source, items in by_source.items():
            lines.append(f"--- {source} ---")
            for m in sorted(items, key=lambda x: x.get("score", 0), reverse=True):
                lines.append(f"  [{m['keyword']}] {m['title']}")
                lines.append(f"  {m['url']}")
                lines.append(f"  Score: {m.get('score', 'n/a')}  Date: {m['date']}")
                lines.append("")
    else:
        lines.append("No new mentions found.")
        lines.append("")

    lines.append("—\nPowered by AIBrain")
    return "\n".join(lines), len(new)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Social Listener")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    keywords = CONFIG.get("social_keywords", DEFAULT_KEYWORDS)
    subreddits = CONFIG.get("social_subreddits", ["selfhosted", "artificial", "automation"])
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("social_listener")
    seen_ids = set(list(state.get("seen_ids", []))[-500:])

    print(f"Scanning for: {', '.join(keywords)}")
    mentions = search_hn(keywords) + search_reddit(keywords, subreddits)

    report, new_count = format_report(mentions, seen_ids)

    if not email_to or args.dry_run:
        print(report)
    elif new_count > 0:
        send_email(email_to, f"Social Listener — {new_count} new mentions", report)
        print(f"Sent {new_count} mentions to {email_to}")
    else:
        print("No new mentions.")

    new_hashes = [hashlib.md5(m["url"].encode()).hexdigest() for m in mentions]
    seen_ids.update(new_hashes)
    save_state("social_listener", {
        "last_run": datetime.datetime.now().isoformat(),
        "seen_ids": list(seen_ids)[-500:],
    })


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='social_listener',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
