#!/usr/bin/env python3
"""AIBrain Workflow: Interview Prep — research companies, generate prep materials."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

import requests
from bs4 import BeautifulSoup

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def research_github(company):
    """Check if company has a GitHub org."""
    info = {}
    try:
        resp = requests.get(f"https://api.github.com/orgs/{company}",
                          headers={"User-Agent": "AIBrain/1.0"}, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            info["github_org"] = data.get("login", "")
            info["public_repos"] = data.get("public_repos", 0)
            info["description"] = data.get("description", "")
            info["blog"] = data.get("blog", "")

            # Get top repos
            repos_resp = requests.get(f"https://api.github.com/orgs/{company}/repos?sort=stars&per_page=5",
                                    headers={"User-Agent": "AIBrain/1.0"}, timeout=10)
            if repos_resp.status_code == 200:
                info["top_repos"] = [
                    {"name": r["name"], "stars": r["stargazers_count"], "language": r.get("language", "")}
                    for r in repos_resp.json()[:5]
                ]
    except Exception:
        pass
    return info


def research_hn(company):
    """Search HN for company mentions."""
    mentions = []
    try:
        resp = requests.get(f"https://hn.algolia.com/api/v1/search?query={company}&tags=story&hitsPerPage=5",
                          timeout=10)
        for hit in resp.json().get("hits", []):
            mentions.append({
                "title": hit.get("title", ""),
                "url": hit.get("url", ""),
                "points": hit.get("points", 0),
                "date": hit.get("created_at", "")[:10],
            })
    except Exception:
        pass
    return mentions


def generate_prep(company, role, github_info, hn_mentions):
    lines = [
        f"INTERVIEW PREP — {company}",
        f"Role: {role}",
        f"Generated: {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        "=" * 50,
        "",
    ]

    # Company research
    lines.append("COMPANY RESEARCH")
    if github_info:
        lines.append(f"  GitHub: {github_info.get('public_repos', 0)} public repos")
        if github_info.get("description"):
            lines.append(f"  About: {github_info['description']}")
        if github_info.get("top_repos"):
            lines.append("  Top repos:")
            for r in github_info["top_repos"]:
                lines.append(f"    {r['name']} ({r.get('language', 'n/a')}) — {r['stars']} stars")
    else:
        lines.append(f"  No GitHub org found for '{company}'")
    lines.append("")

    # HN mentions
    if hn_mentions:
        lines.append(f"HACKER NEWS ({len(hn_mentions)} recent mentions)")
        for m in hn_mentions:
            lines.append(f"  [{m['date']}] {m['title']} ({m['points']} pts)")
        lines.append("")

    # Generic prep questions
    lines.append("PREP QUESTIONS")
    questions = [
        f"Why do you want to work at {company}?",
        f"What experience do you have relevant to {role}?",
        "Tell me about a challenging technical problem you solved.",
        "How do you handle disagreements with team members?",
        f"What would you do in your first 90 days as {role}?",
        "What questions do you have for us?",
    ]
    for i, q in enumerate(questions, 1):
        lines.append(f"  {i}. {q}")
    lines.append("")

    # Things to research further
    lines.append("FURTHER RESEARCH (use Playwright)")
    lines.append(f"  - Company website and recent blog posts")
    lines.append(f"  - Glassdoor reviews for {company}")
    lines.append(f"  - LinkedIn company page — recent hires, team size")
    lines.append(f"  - Crunchbase — funding, investors")
    lines.append("")

    lines.append("—\nPowered by AIBrain")
    return "\n".join(lines)


def _get_recent_applications():
    """Check job_search state for recent tracked applications to auto-prep."""
    try:
        state = load_state("job_search")
        applied = state.get("applied", {})
        if not applied:
            return []
        # Return applications from last 14 days
        cutoff = (datetime.datetime.now() - datetime.timedelta(days=14)).isoformat()[:10]
        recent = [
            app for app in applied.values()
            if app.get("date", "") >= cutoff and app.get("status") in ("applied", "interview")
        ]
        return recent
    except Exception:
        return []


def main():
    parser = argparse.ArgumentParser(description="AIBrain Interview Prep")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--company", help="Company name (omit for auto-scan mode)")
    parser.add_argument("--role", default="Software Engineer", help="Role title")
    args = parser.parse_args()

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    # Auto-scan mode: prep for recent job applications
    if not args.company:
        recent = _get_recent_applications()
        if not recent:
            print("No recent applications found. Use --company to prep for a specific company.")
            return
        print(f"Auto-scan: found {len(recent)} recent applications")
        for app in recent[:3]:
            company = app.get("title", "Unknown").split(" - ")[0].split(" at ")[-1].strip()[:50]
            if company:
                print(f"\nPrepping: {company}")
                github_info = research_github(company)
                hn_mentions = research_hn(company)
                prep = generate_prep(company, args.role, github_info, hn_mentions)
                if not email_to or args.dry_run:
                    print(prep)
                else:
                    send_email(email_to, f"Interview Prep — {company}", prep)
        save_state("interview_prep", {"last_run": datetime.datetime.now().isoformat(), "mode": "auto-scan"})
        log_activity("interview_prep", f"Auto-scan: prepped {min(len(recent), 3)} companies")
        return

    print(f"Researching {args.company}...")
    github_info = research_github(args.company)
    hn_mentions = research_hn(args.company)

    prep = generate_prep(args.company, args.role, github_info, hn_mentions)

    if not email_to or args.dry_run:
        print(prep)
    else:
        send_email(email_to, f"Interview Prep — {args.company} ({args.role})", prep)

    save_state("interview_prep", {
        "last_run": datetime.datetime.now().isoformat(),
        "company": args.company,
        "role": args.role,
    })

    log_activity("interview_prep", f"Prepared interview materials for {args.company} ({args.role})")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='interview_prep',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
