#!/usr/bin/env python3
"""AIBrain Workflow: File Declutter — scan for old files, generate cleanup report."""

import argparse
import datetime
import json
import os
import shutil
import smtplib
import sqlite3
import sys
from email.mime.text import MIMEText
from pathlib import Path

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

import urllib.request

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass

EXTENSION_GROUPS = {
    "Documents": {".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".xls", ".xlsx", ".csv", ".pptx"},
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".ico", ".tiff"},
    "Archives": {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2"},
    "Code": {".py", ".js", ".ts", ".jsx", ".tsx", ".html", ".css", ".json", ".yml", ".yaml", ".md", ".sh"},
    "Media": {".mp4", ".mp3", ".avi", ".mkv", ".mov", ".wav", ".flac", ".m4a"},
    "Installers": {".exe", ".msi", ".dmg", ".deb", ".rpm", ".appimage"},
}

AGE_THRESHOLD_DAYS = 30


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


# ---------------------------------------------------------------------------
# File scanning
# ---------------------------------------------------------------------------

def categorize_file(filepath):
    ext = filepath.suffix.lower()
    for group, extensions in EXTENSION_GROUPS.items():
        if ext in extensions:
            return group
    return "Other"


def human_size(size_bytes):
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def scan_directory(dir_path, threshold_days):
    """Find files older than threshold_days. Returns dict of category -> [file_info]."""
    cutoff = datetime.datetime.now().timestamp() - (threshold_days * 86400)
    results = {}
    total_size = 0
    total_count = 0

    dir_path = Path(dir_path).expanduser()
    if not dir_path.exists():
        return results, 0, 0

    for item in dir_path.iterdir():
        if item.is_dir():
            continue  # only top-level files
        try:
            mtime = item.stat().st_mtime
            if mtime < cutoff:
                cat = categorize_file(item)
                size = item.stat().st_size
                age_days = int((datetime.datetime.now().timestamp() - mtime) / 86400)
                info = {
                    "name": item.name,
                    "path": str(item),
                    "size": size,
                    "size_human": human_size(size),
                    "age_days": age_days,
                    "category": cat,
                }
                results.setdefault(cat, []).append(info)
                total_size += size
                total_count += 1
        except (PermissionError, OSError):
            continue

    # Sort each category by size descending
    for cat in results:
        results[cat].sort(key=lambda x: x["size"], reverse=True)

    return results, total_size, total_count


def organize_files(categorized, scan_dir, dry_run=False):
    """Move files into organized subdirectories."""
    moved = 0
    organize_dir = Path(scan_dir).expanduser() / "_organized"

    for cat, files in categorized.items():
        target = organize_dir / cat
        if not dry_run:
            target.mkdir(parents=True, exist_ok=True)
        for f in files:
            src = Path(f["path"])
            dst = target / f["name"]
            # Avoid overwriting
            if dst.exists():
                stem = dst.stem
                dst = target / f"{stem}_{f['age_days']}d{dst.suffix}"
            if not dry_run:
                try:
                    shutil.move(str(src), str(dst))
                    moved += 1
                except (PermissionError, OSError) as e:
                    print(f"  Skipped {src.name}: {e}", file=sys.stderr)
            else:
                moved += 1
    return moved


def format_report(all_results, total_size, total_count, age_days=30, organized=False):
    lines = [
        f"FILE DECLUTTER REPORT — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        "=" * 50,
        f"Files older than {age_days} days: {total_count}",
        f"Total size: {human_size(total_size)}",
        f"Action: {'Organized into folders' if organized else 'Report only (use --organize to move)'}",
        "",
    ]

    for scan_dir, (categorized, dir_size, dir_count) in all_results.items():
        lines.append(f"--- {scan_dir} ({dir_count} files, {human_size(dir_size)}) ---")
        if not categorized:
            lines.append("  Clean! No old files found.")
            lines.append("")
            continue

        for cat, files in sorted(categorized.items()):
            cat_size = sum(f["size"] for f in files)
            lines.append(f"\n  {cat} ({len(files)} files, {human_size(cat_size)})")
            for f in files[:10]:  # show top 10 per category
                lines.append(f"    {f['name']:40s} {f['size_human']:>10s}  ({f['age_days']}d old)")
            if len(files) > 10:
                lines.append(f"    ... and {len(files) - 10} more")
        lines.append("")

    lines.append("—\nPowered by AIBrain")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain File Declutter")
    parser.add_argument("--dry-run", action="store_true", help="Print instead of emailing")
    parser.add_argument("--organize", action="store_true", help="Actually move files into organized folders")
    parser.add_argument("--days", type=int, default=30, help="Age threshold in days")
    args = parser.parse_args()

    age_threshold = args.days

    default_dirs = ["~/Downloads", "~/Desktop"]
    scan_dirs = CONFIG.get("scan_dirs", default_dirs)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    all_results = {}
    grand_total_size = 0
    grand_total_count = 0

    for d in scan_dirs:
        categorized, dir_size, dir_count = scan_directory(d, args.days)
        all_results[d] = (categorized, dir_size, dir_count)
        grand_total_size += dir_size
        grand_total_count += dir_count

    organized = False
    if args.organize and grand_total_count > 0:
        for d in scan_dirs:
            categorized, _, _ = all_results[d]
            if categorized:
                organize_files(categorized, d, dry_run=args.dry_run)
        organized = not args.dry_run

    report = format_report(all_results, grand_total_size, grand_total_count, age_threshold, organized)

    if not email_to or args.dry_run:
        print(report)
    else:
        send_email(email_to, f"File Declutter — {grand_total_count} old files found", report)
        print(f"Sent declutter report to {email_to}")

    save_state("file_declutter", {
        "last_run": datetime.datetime.now().isoformat(),
        "files_found": grand_total_count,
        "total_size_mb": round(grand_total_size / (1024 * 1024), 1),
        "organized": organized,
    })

    size_mb = round(grand_total_size / (1024 * 1024), 1)
    log_activity(
        "file_declutter",
        f"{grand_total_count} old files ({size_mb} MB)" + (" — organized" if organized else ""),
    )


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='file_declutter',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
