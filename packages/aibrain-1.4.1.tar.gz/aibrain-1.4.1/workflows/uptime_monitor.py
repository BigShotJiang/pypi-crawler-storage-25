#!/usr/bin/env python3
"""AIBrain Workflow: Uptime Monitor — check URLs and report status."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import time
import urllib.request
import urllib.parse
from email.mime.text import MIMEText
from pathlib import Path

import requests

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "devops",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


DEFAULT_TARGETS = [
    {"name": "AIBrain API", "url": "http://localhost:8001/api/agent/status", "expected_status": 200},
]


def get_db():
    db = sqlite3.connect(MEMORY_DB)
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def lookup_ip_geolocation(hostname):
    """Look up geolocation for a hostname via ipinfo.io (free, no key needed)."""
    try:
        # Extract hostname from URL
        if "://" in hostname:
            hostname = urllib.parse.urlparse(hostname).hostname
        if not hostname or hostname in ("localhost", "127.0.0.1", "::1"):
            return None
        url = f"https://ipinfo.io/{hostname}/json"
        req = urllib.request.Request(url, headers={"User-Agent": "AIBrain/1.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        if "bogon" in data:
            return None
        return {
            "ip": data.get("ip", ""),
            "city": data.get("city", ""),
            "region": data.get("region", ""),
            "country": data.get("country", ""),
            "org": data.get("org", ""),
        }
    except Exception:
        return None


def check_target(target):
    """Check a single URL and return result."""
    url = target["url"]
    expected = target.get("expected_status", 200)
    name = target.get("name", url)

    result = {"name": name, "url": url, "expected": expected}
    try:
        start = time.time()
        resp = requests.get(url, timeout=15, allow_redirects=True,
                          headers={"User-Agent": "AIBrain-Uptime/1.0"})
        elapsed = round((time.time() - start) * 1000)

        result["status"] = resp.status_code
        result["response_ms"] = elapsed
        result["up"] = resp.status_code == expected
        result["ssl_ok"] = url.startswith("https://")  # simplified
    except requests.exceptions.Timeout:
        result["status"] = "TIMEOUT"
        result["response_ms"] = 15000
        result["up"] = False
    except requests.exceptions.ConnectionError:
        result["status"] = "CONNECTION_ERROR"
        result["response_ms"] = 0
        result["up"] = False
    except Exception as e:
        result["status"] = f"ERROR: {str(e)[:50]}"
        result["response_ms"] = 0
        result["up"] = False

    # Add geolocation info
    geo = lookup_ip_geolocation(url)
    if geo:
        result["geo"] = geo

    return result


def format_report(results, prev_state):
    up_count = sum(1 for r in results if r["up"])
    down_count = len(results) - up_count

    lines = [
        f"UPTIME MONITOR — {datetime.datetime.now().strftime('%A %B %d, %Y %I:%M %p')}",
        f"Status: {up_count}/{len(results)} UP" + (f" — {down_count} DOWN!" if down_count else ""),
        "=" * 50,
        "",
    ]

    # Down services first
    down = [r for r in results if not r["up"]]
    if down:
        lines.append("DOWN")
        for r in down:
            prev = prev_state.get("results", {}).get(r["name"], {})
            was_up = prev.get("up", True)
            status_change = " (NEW!)" if was_up else " (still down)"
            lines.append(f"  {r['name']}")
            lines.append(f"    URL: {r['url']}")
            lines.append(f"    Status: {r['status']}{status_change}")
            geo = r.get("geo")
            if geo:
                parts = [p for p in [geo.get("city"), geo.get("region"), geo.get("country")] if p]
                if parts:
                    lines.append(f"    Location: {', '.join(parts)}")
                if geo.get("org"):
                    lines.append(f"    Host: {geo['org']}")
            lines.append("")

    # Up services
    up = [r for r in results if r["up"]]
    if up:
        lines.append("UP")
        for r in up:
            speed = "fast" if r["response_ms"] < 500 else "slow" if r["response_ms"] < 2000 else "very slow"
            geo = r.get("geo")
            geo_str = ""
            if geo:
                parts = [p for p in [geo.get("city"), geo.get("region"), geo.get("country")] if p]
                geo_str = f"  [{', '.join(parts)}]" if parts else ""
            lines.append(f"  {r['name']:25s} {r['response_ms']:>5d}ms ({speed}){geo_str}")
            if geo and geo.get("org"):
                lines.append(f"  {'':25s}       {geo['org']}")
        lines.append("")

    lines.append("—\nPowered by AIBrain + ipinfo.io")
    return "\n".join(lines), down_count > 0


def main():
    parser = argparse.ArgumentParser(description="AIBrain Uptime Monitor")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    targets = CONFIG.get("uptime_targets", DEFAULT_TARGETS)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("uptime_monitor")

    print(f"Checking {len(targets)} targets...")
    results = []
    for target in targets:
        result = check_target(target)
        status = "UP" if result["up"] else "DOWN"
        print(f"  {result['name']}: {status} ({result.get('response_ms', 0)}ms)")
        results.append(result)

    report, has_down = format_report(results, state)

    if not email_to or args.dry_run:
        print(report)
    else:
        prefix = "[DOWN] " if has_down else ""
        send_email(email_to, f"{prefix}Uptime: {sum(1 for r in results if r['up'])}/{len(results)} UP", report)

    result_state = {r["name"]: {"up": r["up"], "status": r.get("status")} for r in results}
    save_state("uptime_monitor", {
        "last_run": datetime.datetime.now().isoformat(),
        "results": result_state,
    })

    up_count = sum(1 for r in results if r["up"])
    log_activity("uptime_monitor", f"{up_count}/{len(results)} targets UP", "warning" if has_down else "ok")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='uptime_monitor',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
