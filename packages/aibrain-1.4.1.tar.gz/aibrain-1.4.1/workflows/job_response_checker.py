#!/usr/bin/env python3
"""AIBrain Workflow: Job Application Response Checker
Checks email inbox for replies to job applications, drafts appropriate responses,
and sends them through the approval queue for operator to approve before sending.
Runs twice daily (9am and 3pm).
"""

import argparse
import imaplib
import email
import json
import os
import re
import smtplib
import sqlite3
import sys
import urllib.request
from datetime import datetime, timedelta
from email.header import decode_header
from email.mime.text import MIMEText
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT",
                    os.environ.get("AIBRAIN_ROOT",
                    Path(__file__).parent.parent)))
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "job_hunting",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


# Senders that are NEVER job responses — skip entirely
IGNORE_SENDERS = [
    "donotreply@", "noreply@", "no-reply@", "mailer-daemon@",
    # Marketing / spam
    "kogan.com", "e.kogan.com",
    # Billing / receipts
    "hostinger.com", "info.hostinger.com",
    # Property alerts
    "realestate.com.au", "campaign.realestate.com.au",
    # Social / events
    "meetup.com", "email.meetup.com",
    # Platform tips (not responses)
    "noreply@s.seek.com.au",
    # Security scanners
    "getgitguardian.com", "security@github.com",
    # Our own emails
    # Add your own agent email here to filter out self-sent messages
    # Indeed job ALERTS (not responses)
    "jobalert.indeed.com",
]

# Subject patterns that are NOT job responses
IGNORE_SUBJECTS = [
    "job alert", "new jobs", "new work from home",
    "sale", "% off", "free shipping", "birthday sale",
    "just sold", "property", "auction",
    "subscription", "renewed", "payment",
    "security alert", "sign-in", "secrets detected",
    "token exposed", "possible valid secrets",
    "making great progress",  # SEEK tips
    "celebrate", "happy",  # Meetup events
]

# Job-related email keywords — tightened to reduce false positives
JOB_KEYWORDS = [
    "your application", "your candidacy", "thank you for applying",
    "we regret", "unfortunately your", "not been selected",
    "interview", "phone screen", "assessment centre",
    "shortlisted", "congratulations", "offer of employment",
    "next steps in your application", "screening call",
    "we would like to discuss", "schedule a call",
]

# Keywords indicating rejection (no reply needed)
REJECTION_KEYWORDS = [
    "we regret to inform", "unfortunately", "not been selected",
    "not successful", "other candidates", "will not be progressing",
    "decided not to proceed", "position has been filled",
]

# Keywords indicating positive response (needs quick reply)
POSITIVE_KEYWORDS = [
    "interview", "next steps", "phone screen", "assessment",
    "congratulations", "shortlisted", "would like to discuss",
    "schedule a call", "availability", "offer",
]


def get_tracker_db():
    """Get or create job application tracker database."""
    db_path = AIBRAIN_ROOT / "job_tracker.db"
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT NOT NULL,
            title TEXT NOT NULL,
            platform TEXT DEFAULT 'unknown',
            applied_at TEXT NOT NULL,
            status TEXT DEFAULT 'applied',
            last_response TEXT,
            response_at TEXT,
            notes TEXT DEFAULT '',
            apply_url TEXT DEFAULT ''
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER,
            email_from TEXT,
            email_subject TEXT,
            email_body TEXT,
            response_type TEXT,
            replied BOOLEAN DEFAULT 0,
            received_at TEXT,
            FOREIGN KEY (application_id) REFERENCES applications(id)
        )
    """)
    db.commit()
    return db


def track_application(company, title, platform="indeed", url=""):
    """Record a new job application."""
    db = get_tracker_db()
    now = datetime.now().isoformat()
    db.execute(
        "INSERT INTO applications (company, title, platform, applied_at, status, apply_url) VALUES (?, ?, ?, ?, 'applied', ?)",
        (company, title, platform, now, url),
    )
    db.commit()
    app_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.close()
    return app_id


def get_applications(status=None):
    """Get all tracked applications."""
    db = get_tracker_db()
    if status:
        rows = db.execute("SELECT * FROM applications WHERE status = ? ORDER BY applied_at DESC", (status,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM applications ORDER BY applied_at DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]


def check_inbox_for_responses(dry_run=False):
    """Check email inbox for job-related responses."""
    imap_host = CONFIG.get("email_imap_host", "imap.gmail.com")
    # Use the email account that receives job responses
    email_user = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    email_pass = CONFIG.get("email_app_password", "")

    if not email_pass:
        print("No email password configured — skipping inbox check")
        return []

    responses = []
    try:
        m = imaplib.IMAP4_SSL(imap_host)
        m.login(email_user, email_pass)
        m.select("INBOX")

        # Search for unread emails from the last 7 days
        since_date = (datetime.now() - timedelta(days=7)).strftime("%d-%b-%Y")
        _, nums = m.search(None, f'(SINCE {since_date} UNSEEN)')
        ids = nums[0].split()

        for uid in ids:
            try:
                _, data = m.fetch(uid, "(RFC822)")
                msg = email.message_from_bytes(data[0][1])

                subject = ""
                raw_subj = msg.get("Subject", "")
                decoded = decode_header(raw_subj)
                for part, enc in decoded:
                    if isinstance(part, bytes):
                        subject += part.decode(enc or "utf-8", errors="replace")
                    else:
                        subject += part

                from_addr = msg.get("From", "")
                date_str = msg.get("Date", "")

                # Extract body
                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            body = part.get_payload(decode=True).decode("utf-8", errors="replace")
                            break
                else:
                    body = msg.get_payload(decode=True).decode("utf-8", errors="replace")

                # Skip known non-job senders
                from_lower = from_addr.lower()
                if any(s in from_lower for s in IGNORE_SENDERS):
                    continue

                # Skip known non-job subjects
                subj_lower = subject.lower()
                if any(s in subj_lower for s in IGNORE_SUBJECTS):
                    continue

                # Check if job-related (tightened keywords)
                combined = (subject + " " + body).lower()
                is_job = any(kw in combined for kw in JOB_KEYWORDS)

                if not is_job:
                    continue

                # Classify response type
                if any(kw in combined for kw in POSITIVE_KEYWORDS):
                    resp_type = "positive"
                elif any(kw in combined for kw in REJECTION_KEYWORDS):
                    resp_type = "rejection"
                else:
                    resp_type = "info"

                responses.append({
                    "from": from_addr,
                    "subject": subject,
                    "body": body[:2000],
                    "date": date_str,
                    "type": resp_type,
                    "uid": uid.decode(),
                })

            except Exception as e:
                print(f"Error processing email {uid}: {e}", file=sys.stderr)
                continue

        m.logout()
    except Exception as e:
        print(f"IMAP error: {e}", file=sys.stderr)

    return responses


def draft_reply(response):
    """Draft an appropriate reply based on response type."""
    if response["type"] == "rejection":
        return None  # No reply needed for rejections

    if response["type"] == "positive":
        return f"""Thank you for getting back to me regarding this opportunity.

I'm very interested and available for next steps. I'm flexible with scheduling — please let me know what times work best for you.

I look forward to discussing this further.

Best regards,
Matt"""

    # Info/general response
    return f"""Thank you for your message regarding my application.

I appreciate the update and remain very interested in this opportunity. Please don't hesitate to reach out if you need any additional information from me.

Best regards,
Matt"""


def create_approval_for_reply(response, reply_draft):
    """Create an approval request for the drafted reply."""
    try:
        import requests
        api_base = CONFIG.get("api_url", "http://localhost:8001/api/agent")
        resp = requests.post(
            f"{api_base}/approvals",
            json={
                "category": "email",
                "title": f"Reply to job response: {response['subject'][:60]}",
                "detail": f"From: {response['from']}\nSubject: {response['subject']}\n\n--- Their message ---\n{response['body'][:500]}\n\n--- Drafted reply ---\n{reply_draft}",
                "payload": {
                    "action": "send_email",
                    "to": response["from"],
                    "subject": f"Re: {response['subject']}",
                    "body": reply_draft,
                },
            },
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json().get("id")
    except Exception as e:
        print(f"Failed to create approval: {e}", file=sys.stderr)
    return None


def send_email_report(responses, dry_run=False):
    """Send summary report to operator."""
    if not responses:
        return

    lines = [
        f"JOB RESPONSE CHECK — {datetime.now().strftime('%A %B %d, %Y %I:%M %p')}",
        f"Found {len(responses)} job-related email(s)",
        "=" * 50, "",
    ]

    positive = [r for r in responses if r["type"] == "positive"]
    rejections = [r for r in responses if r["type"] == "rejection"]
    info = [r for r in responses if r["type"] == "info"]

    if positive:
        lines.append(f"POSITIVE RESPONSES ({len(positive)}) — replies drafted & queued for approval")
        for r in positive:
            lines.append(f"  From: {r['from']}")
            lines.append(f"  Subject: {r['subject']}")
            lines.append("")

    if rejections:
        lines.append(f"REJECTIONS ({len(rejections)}) — no reply needed")
        for r in rejections:
            lines.append(f"  From: {r['from']}")
            lines.append(f"  Subject: {r['subject']}")
            lines.append("")

    if info:
        lines.append(f"INFO ({len(info)}) — replies drafted & queued for approval")
        for r in info:
            lines.append(f"  From: {r['from']}")
            lines.append(f"  Subject: {r['subject']}")
            lines.append("")

    lines.append("— AIBrain Agent")
    report = "\n".join(lines)

    if dry_run:
        print(report)
        return

    try:
        agent_email = CONFIG.get("agent_email", "")
        agent_pass = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
        email_to = CONFIG.get("email_to", "")

        msg = MIMEText(report)
        msg["From"] = agent_email
        msg["To"] = email_to
        msg["Subject"] = f"Job Response Check — {len(positive)} positive, {len(rejections)} rejections"

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as s:
            s.login(agent_email, agent_pass)
            s.send_message(msg)
    except Exception as e:
        print(f"Email send error: {e}", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(description="Check for job application responses")
    parser.add_argument("--dry-run", action="store_true", help="Print results without sending")
    parser.add_argument("--track", nargs=3, metavar=("COMPANY", "TITLE", "PLATFORM"),
                        help="Track a new application")
    parser.add_argument("--list", action="store_true", help="List all tracked applications")
    args = parser.parse_args()

    if args.track:
        app_id = track_application(args.track[0], args.track[1], args.track[2])
        print(f"Tracked application #{app_id}: {args.track[1]} at {args.track[0]}")
        return

    if args.list:
        apps = get_applications()
        if not apps:
            print("No tracked applications")
            return
        print(f"{'#':>3}  {'Company':20s}  {'Title':30s}  {'Platform':10s}  {'Status':10s}  Applied")
        for a in apps:
            print(f"{a['id']:3d}  {a['company'][:20]:20s}  {a['title'][:30]:30s}  {a['platform'][:10]:10s}  {a['status'][:10]:10s}  {a['applied_at'][:10]}")
        return

    print(f"[{datetime.now().isoformat()}] Checking inbox for job responses...")
    responses = check_inbox_for_responses(dry_run=args.dry_run)

    # Draft replies for non-rejection responses
    replies_queued = 0
    for resp in responses:
        reply = draft_reply(resp)
        if reply:
            approval_id = create_approval_for_reply(resp, reply)
            if approval_id:
                replies_queued += 1
                print(f"  Queued reply for approval #{approval_id}: {resp['subject'][:60]}")

            # Save to tracker DB
            db = get_tracker_db()
            db.execute(
                "INSERT INTO responses (email_from, email_subject, email_body, response_type, received_at) VALUES (?, ?, ?, ?, ?)",
                (resp["from"], resp["subject"], resp["body"][:2000], resp["type"], datetime.now().isoformat()),
            )
            db.commit()
            db.close()

    print(f"  Found {len(responses)} job emails, {replies_queued} replies queued for approval")

    # Send summary to operator
    send_email_report(responses, dry_run=args.dry_run)

    log_activity("job_response_checker", f"{len(responses)} job emails found, {replies_queued} replies drafted")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='job_response_checker',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
