"""FastAPI auth router — /auth/* endpoints for myaibrain.org user accounts.

Mounted at root ("" prefix), so endpoints live under /auth/signup, /auth/login,
etc. This router is intentionally NOT under /api/ so it doesn't inherit the
AuthMiddleware API-key requirement (see security.py). We handle our own
session cookies here.

Rate limiting: login and password reset endpoints use a dedicated per-email
in-DB rate limiter (5 failed logins per email per 15 min). Other endpoints
rely on the global RateLimitMiddleware at the app level.
"""

import base64
import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import re

from fastapi import APIRouter, Cookie, Depends, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel, field_validator


_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def _validate_email(v: str) -> str:
    if not isinstance(v, str) or not _EMAIL_RE.match(v.strip()):
        raise ValueError("Invalid email address")
    return v.strip().lower()

from auth import oauth, password as pwd, sessions, totp
from auth.db import get_conn
from auth.email_sender import send_email

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

RESET_TOKEN_TTL_MINUTES = 15
VERIFY_TOKEN_TTL_HOURS = 48
LOGIN_ATTEMPT_WINDOW_MINUTES = 15
LOGIN_ATTEMPT_LIMIT = 5


def _base_url(request: Request) -> str:
    return os.environ.get(
        "AIBRAIN_BASE_URL", f"{request.url.scheme}://{request.url.netloc}"
    )


def _site_url() -> str:
    return os.environ.get("MYAIBRAIN_SITE_URL", "https://myaibrain.org")


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _gen_user_id() -> str:
    """11-char URL-safe user ID (matches the RBAC schema's TEXT ids)."""
    return secrets.token_urlsafe(8)[:11]


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class SignupBody(BaseModel):
    email: str
    password: str

    @field_validator("email")
    @classmethod
    def _email_ok(cls, v):
        return _validate_email(v)


class LoginBody(BaseModel):
    email: str
    password: str
    totp: Optional[str] = None

    @field_validator("email")
    @classmethod
    def _email_ok(cls, v):
        return _validate_email(v)


class ResetRequestBody(BaseModel):
    email: str

    @field_validator("email")
    @classmethod
    def _email_ok(cls, v):
        return _validate_email(v)


class ResetConfirmBody(BaseModel):
    token: str
    new_password: str


class TotpSetupBody(BaseModel):
    password: str  # reauth


class TotpVerifyBody(BaseModel):
    code: str


class TotpDisableBody(BaseModel):
    password: str  # reauth
    code: Optional[str] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_user_by_email(email: str) -> dict | None:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM users WHERE email = ? COLLATE NOCASE", (email.lower(),)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def _find_user_by_id(user_id: str) -> dict | None:
    conn = get_conn()
    try:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def _create_user(email: str, password_hash: str | None) -> str:
    """Insert a new user row. Handles both the auth-only schema and the
    extended RBAC schema (which has role/status/etc NOT NULL columns).
    """
    user_id = _gen_user_id()
    conn = get_conn()
    try:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
        # Build insert columns dynamically so we work with either schema.
        fields = ["id", "email", "password_hash", "created_at",
                  "email_verified", "totp_enabled"]
        values: list = [user_id, email.lower(), password_hash, _iso(_now()), 0, 0]
        if "role" in cols:
            fields.append("role")
            values.append("member")
        if "status" in cols:
            fields.append("status")
            values.append("active")
        placeholders = ", ".join(["?"] * len(fields))
        conn.execute(
            f"INSERT INTO users ({', '.join(fields)}) VALUES ({placeholders})",  # noqa: sql-injection
            values,
        )
    finally:
        conn.close()
    return user_id


def _update_user(user_id: str, **cols):
    if not cols:
        return
    fields = ", ".join(f"{k} = ?" for k in cols)
    values = list(cols.values()) + [user_id]
    conn = get_conn()
    try:
        conn.execute(f"UPDATE users SET {fields} WHERE id = ?", values)  # noqa: sql-injection
    finally:
        conn.close()


def _linked_methods(user_id: str) -> dict:
    """Return {password, github, google, microsoft} booleans."""
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT password_hash FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        has_password = bool(row and row["password_hash"])
        providers = {
            r["provider"]
            for r in conn.execute(
                "SELECT provider FROM oauth_links WHERE user_id = ?", (user_id,)
            ).fetchall()
        }
        return {
            "password": has_password,
            "github": "github" in providers,
            "google": "google" in providers,
            "microsoft": "microsoft" in providers,
        }
    finally:
        conn.close()


def _current_user(request: Request) -> dict | None:
    token = request.cookies.get(sessions.COOKIE_NAME)
    if not token:
        return None
    return sessions.load_session(token)


def _record_login_attempt(email: str, success: bool, ip: str = ""):
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO login_attempts (email, attempted_at, success, ip) "
            "VALUES (?, ?, ?, ?)",
            (email.lower(), _iso(_now()), 1 if success else 0, ip),
        )
    finally:
        conn.close()


def _recent_failed_logins(email: str) -> int:
    since = _now() - timedelta(minutes=LOGIN_ATTEMPT_WINDOW_MINUTES)
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT COUNT(*) FROM login_attempts "
            "WHERE email = ? COLLATE NOCASE AND success = 0 AND attempted_at >= ?",
            (email.lower(), _iso(since)),
        ).fetchone()
        return int(row[0]) if row else 0
    finally:
        conn.close()


def _mask_license_key(key: str | None) -> str | None:
    if not key:
        return None
    if len(key) <= 8:
        return "****"
    return f"{key[:4]}{'*' * (len(key) - 8)}{key[-4:]}"


# ---------------------------------------------------------------------------
# Signup / Login / Logout
# ---------------------------------------------------------------------------

@router.post("/signup")
def signup(body: SignupBody, request: Request, response: Response):
    email = body.email.lower()
    ok, reason = pwd.validate_password_strength(body.password)
    if not ok:
        raise HTTPException(400, reason)

    if _find_user_by_email(email):
        # Don't leak existence — return generic error. Signup races are rare.
        raise HTTPException(409, "Account already exists for that email")

    ph = pwd.hash_password(body.password)
    user_id = _create_user(email, ph)

    # Issue verification token
    vtoken = secrets.token_urlsafe(32)
    vexp = _now() + timedelta(hours=VERIFY_TOKEN_TTL_HOURS)
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO email_verification_tokens (token, user_id, created_at, expires_at) "
            "VALUES (?, ?, ?, ?)",
            (vtoken, user_id, _iso(_now()), _iso(vexp)),
        )
    finally:
        conn.close()

    # Send verification email (non-blocking on failure).
    verify_link = f"{_site_url()}/verify-email?token={vtoken}"
    send_email(
        to=email,
        subject="Verify your AIBrain account",
        body=(
            f"Welcome to AIBrain.\n\n"
            f"Click to verify your email:\n{verify_link}\n\n"
            f"This link expires in {VERIFY_TOKEN_TTL_HOURS} hours.\n"
        ),
    )

    # Issue session — user is logged in immediately. email_verified banner shown
    # in dashboard until they click the link.
    client_ip = request.client.host if request.client else ""
    ua = request.headers.get("user-agent", "")[:500]
    token, _exp = sessions.create_session(user_id, ip=client_ip, user_agent=ua)
    sessions.set_session_cookie(response, token)

    return {
        "user_id": user_id,
        "email": email,
        "email_verified": False,
        "message": "Signup successful. Verification email sent.",
    }


@router.post("/login")
def login(body: LoginBody, request: Request, response: Response):
    email = body.email.lower()

    # Rate limit: 5 failed attempts per email per 15 min.
    if _recent_failed_logins(email) >= LOGIN_ATTEMPT_LIMIT:
        raise HTTPException(429, "Too many failed attempts. Try again in 15 minutes.")

    user = _find_user_by_email(email)
    if not user or not user.get("password_hash"):
        _record_login_attempt(email, success=False, ip=request.client.host if request.client else "")
        raise HTTPException(401, "Invalid email or password")

    if not pwd.verify_password(body.password, user["password_hash"]):
        _record_login_attempt(email, success=False, ip=request.client.host if request.client else "")
        raise HTTPException(401, "Invalid email or password")

    # 2FA challenge if enabled
    if user.get("totp_enabled"):
        if not body.totp:
            return JSONResponse(
                {"status": "totp_required", "user_id": user["id"]},
                status_code=200,
            )
        if not totp.verify_code(user.get("totp_secret") or "", body.totp):
            _record_login_attempt(email, success=False, ip=request.client.host if request.client else "")
            raise HTTPException(401, "Invalid 2FA code")

    _record_login_attempt(email, success=True, ip=request.client.host if request.client else "")
    _update_user(user["id"], last_login_at=_iso(_now()))

    client_ip = request.client.host if request.client else ""
    ua = request.headers.get("user-agent", "")[:500]
    token, _exp = sessions.create_session(user["id"], ip=client_ip, user_agent=ua)
    sessions.set_session_cookie(response, token)

    return {
        "user_id": user["id"],
        "email": user["email"],
        "email_verified": bool(user.get("email_verified")),
    }


@router.post("/logout")
def logout(request: Request, response: Response):
    token = request.cookies.get(sessions.COOKIE_NAME)
    if token:
        sessions.destroy_session(token)
    sessions.clear_session_cookie(response)
    return {"status": "logged_out"}


# ---------------------------------------------------------------------------
# Password reset
# ---------------------------------------------------------------------------

@router.post("/password/reset/request")
def password_reset_request(body: ResetRequestBody):
    email = body.email.lower()
    user = _find_user_by_email(email)
    # Don't leak existence — always return 200.
    if user:
        token = secrets.token_urlsafe(32)
        exp = _now() + timedelta(minutes=RESET_TOKEN_TTL_MINUTES)
        conn = get_conn()
        try:
            conn.execute(
                "INSERT INTO password_reset_tokens (token, user_id, created_at, expires_at) "
                "VALUES (?, ?, ?, ?)",
                (token, user["id"], _iso(_now()), _iso(exp)),
            )
        finally:
            conn.close()
        reset_link = f"{_site_url()}/password-reset/confirm?token={token}"
        send_email(
            to=email,
            subject="Reset your AIBrain password",
            body=(
                f"Click to reset your password (expires in {RESET_TOKEN_TTL_MINUTES} minutes):\n"
                f"{reset_link}\n\n"
                f"If you did not request this, ignore this email.\n"
            ),
        )
    return {"status": "ok", "message": "If an account exists, a reset link has been sent."}


@router.post("/password/reset/confirm")
def password_reset_confirm(body: ResetConfirmBody):
    ok, reason = pwd.validate_password_strength(body.new_password)
    if not ok:
        raise HTTPException(400, reason)

    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM password_reset_tokens WHERE token = ?", (body.token,)
        ).fetchone()
        if not row:
            raise HTTPException(400, "Invalid or expired reset token")
        if row["used_at"]:
            raise HTTPException(400, "Reset token already used")
        try:
            exp = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            exp = datetime.fromisoformat(row["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
        if exp < _now():
            raise HTTPException(400, "Reset token expired")

        new_hash = pwd.hash_password(body.new_password)
        conn.execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            (new_hash, row["user_id"]),
        )
        conn.execute(
            "UPDATE password_reset_tokens SET used_at = ? WHERE token = ?",
            (_iso(_now()), body.token),
        )
    finally:
        conn.close()
    # Invalidate all sessions for that user — force re-login on all devices.
    sessions.destroy_all_for_user(row["user_id"])
    return {"status": "password_reset", "message": "Password updated. Please log in again."}


# ---------------------------------------------------------------------------
# Email verification
# ---------------------------------------------------------------------------

@router.get("/verify-email")
def verify_email_link(token: str = Query(...)):
    """GET-friendly verification endpoint so the email link works directly."""
    return _verify_email(token)


@router.post("/verify-email")
def verify_email_post(body: dict):
    return _verify_email(body.get("token", ""))


def _verify_email(token: str):
    if not token:
        raise HTTPException(400, "Token required")
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM email_verification_tokens WHERE token = ?", (token,)
        ).fetchone()
        if not row or row["used_at"]:
            raise HTTPException(400, "Invalid or already-used token")
        try:
            exp = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            exp = datetime.fromisoformat(row["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
        if exp < _now():
            raise HTTPException(400, "Token expired")
        conn.execute(
            "UPDATE users SET email_verified = 1 WHERE id = ?", (row["user_id"],)
        )
        conn.execute(
            "UPDATE email_verification_tokens SET used_at = ? WHERE token = ?",
            (_iso(_now()), token),
        )
    finally:
        conn.close()
    return {"status": "verified"}


# ---------------------------------------------------------------------------
# OAuth
# ---------------------------------------------------------------------------

@router.get("/oauth/providers")
def oauth_providers():
    """Return the list of enabled providers so the frontend can hide buttons."""
    return {"enabled": oauth.enabled_providers(), "supported": list(oauth.PROVIDERS.keys())}


@router.get("/oauth/{provider}/start")
def oauth_start(provider: str, request: Request, link: int = 0, redirect_to: Optional[str] = None):
    if provider not in oauth.PROVIDERS:
        raise HTTPException(404, f"Unknown provider: {provider}")
    if not oauth.provider_configured(provider):
        raise HTTPException(503, f"OAuth provider not configured: {provider}")

    link_user_id = None
    if link:
        user = _current_user(request)
        if not user:
            raise HTTPException(401, "Must be logged in to link an account")
        link_user_id = user["id"]

    url, _state = oauth.build_authorize_url(
        provider,
        link_user_id=link_user_id,
        redirect_to=redirect_to,
        base_url=_base_url(request),
    )
    return RedirectResponse(url, status_code=302)


@router.get("/oauth/{provider}/callback")
def oauth_callback(
    provider: str,
    request: Request,
    response: Response,
    code: Optional[str] = None,
    state: Optional[str] = None,
    error: Optional[str] = None,
):
    if provider not in oauth.PROVIDERS:
        raise HTTPException(404, f"Unknown provider: {provider}")
    if error:
        return RedirectResponse(f"{_site_url()}/login?oauth_error={error}", status_code=302)
    if not code or not state:
        raise HTTPException(400, "Missing code or state")

    state_row = oauth.consume_state(state)
    if not state_row or state_row["provider"] != provider:
        raise HTTPException(400, "Invalid or expired state")

    try:
        provider_uid, provider_email = oauth.exchange_code_for_profile(
            provider, code, state_row["code_verifier"], base_url=_base_url(request),
        )
    except Exception as e:
        logger.warning("OAuth exchange failed: %s", e)
        return RedirectResponse(f"{_site_url()}/login?oauth_error=exchange_failed", status_code=302)

    # Resolve user: link flow, existing oauth link, or existing email.
    conn = get_conn()
    try:
        link_user_id = state_row.get("link_user_id")
        user_id = None

        if link_user_id:
            # Linking flow — the current user already exists.
            user_id = link_user_id
            # Also check that no OTHER user has this provider link already.
            existing = conn.execute(
                "SELECT user_id FROM oauth_links WHERE provider = ? AND provider_user_id = ?",
                (provider, provider_uid),
            ).fetchone()
            if existing and existing["user_id"] != user_id:
                return RedirectResponse(
                    f"{_site_url()}/account?oauth_error=already_linked_to_another", status_code=302
                )
        else:
            # Normal login flow.
            # 1. existing oauth link?
            row = conn.execute(
                "SELECT user_id FROM oauth_links WHERE provider = ? AND provider_user_id = ?",
                (provider, provider_uid),
            ).fetchone()
            if row:
                user_id = row["user_id"]
            else:
                # 2. existing email?
                row = conn.execute(
                    "SELECT id FROM users WHERE email = ? COLLATE NOCASE", (provider_email,)
                ).fetchone()
                if row:
                    user_id = row["id"]
                else:
                    # 3. create new user — no password. OAuth = email verified.
                    user_id = _gen_user_id()
                    _cols = {r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
                    _fields = ["id", "email", "created_at", "email_verified", "totp_enabled"]
                    _vals: list = [user_id, provider_email, _iso(_now()), 1, 0]
                    if "role" in _cols:
                        _fields.append("role"); _vals.append("member")
                    if "status" in _cols:
                        _fields.append("status"); _vals.append("active")
                    _placeholders = ", ".join(["?"] * len(_fields))
                    conn.execute(
                        f"INSERT INTO users ({', '.join(_fields)}) VALUES ({_placeholders})",  # noqa: sql-injection
                        _vals,
                    )

        # Insert oauth_links row (idempotent via PK).
        conn.execute(
            "INSERT OR IGNORE INTO oauth_links (user_id, provider, provider_user_id, provider_email, linked_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (user_id, provider, provider_uid, provider_email, _iso(_now())),
        )
        conn.execute("UPDATE users SET last_login_at = ? WHERE id = ?", (_iso(_now()), user_id))
    finally:
        conn.close()

    # Issue session
    client_ip = request.client.host if request.client else ""
    ua = request.headers.get("user-agent", "")[:500]
    token, _exp = sessions.create_session(user_id, ip=client_ip, user_agent=ua)

    # For linking: redirect to /account. For fresh login: /account.
    target = state_row.get("redirect_to") or f"{_site_url()}/account"
    redirect = RedirectResponse(target, status_code=302)
    sessions.set_session_cookie(redirect, token)
    return redirect


@router.post("/oauth/{provider}/link")
def oauth_link(provider: str, request: Request):
    """Initiate a link flow from the dashboard — returns the authorize URL.

    Frontend opens the URL; after the callback the user_id state is applied.
    """
    if provider not in oauth.PROVIDERS:
        raise HTTPException(404, f"Unknown provider: {provider}")
    if not oauth.provider_configured(provider):
        raise HTTPException(503, f"OAuth provider not configured: {provider}")

    user = _current_user(request)
    if not user:
        raise HTTPException(401, "Not logged in")

    url, _state = oauth.build_authorize_url(
        provider,
        link_user_id=user["id"],
        redirect_to=f"{_site_url()}/account",
        base_url=_base_url(request),
    )
    return {"authorize_url": url}


# ---------------------------------------------------------------------------
# 2FA (TOTP)
# ---------------------------------------------------------------------------

@router.post("/2fa/setup")
def totp_setup(body: TotpSetupBody, request: Request):
    user = _current_user(request)
    if not user:
        raise HTTPException(401, "Not logged in")
    if not user.get("password_hash") or not pwd.verify_password(body.password, user["password_hash"]):
        raise HTTPException(401, "Password reauth failed")

    secret = totp.generate_secret()
    # Stage secret on the user row, but don't flip totp_enabled until verify.
    _update_user(user["id"], totp_secret=secret)
    uri = totp.otpauth_uri(secret, user["email"])
    return {"secret": secret, "otpauth_uri": uri}


@router.post("/2fa/verify")
def totp_verify(body: TotpVerifyBody, request: Request):
    user = _current_user(request)
    if not user:
        raise HTTPException(401, "Not logged in")
    secret = user.get("totp_secret")
    if not secret:
        raise HTTPException(400, "No TOTP secret staged — run /auth/2fa/setup first")
    if not totp.verify_code(secret, body.code):
        raise HTTPException(400, "Invalid code")
    _update_user(user["id"], totp_enabled=1)
    return {"status": "enabled"}


@router.post("/2fa/disable")
def totp_disable(body: TotpDisableBody, request: Request):
    user = _current_user(request)
    if not user:
        raise HTTPException(401, "Not logged in")
    if not user.get("password_hash") or not pwd.verify_password(body.password, user["password_hash"]):
        raise HTTPException(401, "Password reauth failed")
    _update_user(user["id"], totp_enabled=0, totp_secret=None)
    return {"status": "disabled"}


# ---------------------------------------------------------------------------
# /auth/me — current user + linked methods + 2FA + license state
# ---------------------------------------------------------------------------

@router.get("/me")
def me(request: Request):
    user = _current_user(request)
    if not user:
        raise HTTPException(401, "Not logged in")
    methods = _linked_methods(user["id"])
    # Fetch license state
    conn = get_conn()
    try:
        lic_row = conn.execute(
            "SELECT * FROM license_state WHERE user_id = ?", (user["id"],)
        ).fetchone()
    finally:
        conn.close()
    lic = dict(lic_row) if lic_row else {
        "tier": "free",
        "license_key": None,
        "valid_until": None,
        "stripe_customer_id": None,
    }
    return {
        "user_id": user["id"],
        "email": user["email"],
        "email_verified": bool(user.get("email_verified")),
        "created_at": user.get("created_at"),
        "last_login_at": user.get("last_login_at"),
        "linked_methods": methods,
        "totp_enabled": bool(user.get("totp_enabled")),
        "license": {
            "tier": lic.get("tier") or "free",
            "license_key_masked": _mask_license_key(lic.get("license_key")),
            "valid_until": lic.get("valid_until"),
            "stripe_customer_id": lic.get("stripe_customer_id"),
        },
        "oauth_providers_enabled": oauth.enabled_providers(),
    }
