"""Password hashing via bcrypt, cost 12.

Cost 12 is ~250ms on a 2024 laptop — balances brute-force resistance with
signup latency. Every hash has a unique salt baked in by bcrypt, so we store
only the single hash string.
"""

import re
import bcrypt

# Cost factor. 12 is the floor per acceptance criteria #6.
BCRYPT_COST = 12

# Minimum password length. 10 is a compromise — long enough to resist
# dictionary attacks with a modest rate limit, short enough not to annoy
# normal humans.
MIN_PASSWORD_LEN = 10


def hash_password(plain: str) -> str:
    """Hash a plaintext password with bcrypt. Returns the encoded hash."""
    if not isinstance(plain, str):
        raise TypeError("password must be str")
    # bcrypt truncates at 72 bytes — pre-hash with SHA-256 first so long
    # passwords aren't silently truncated. This is what Django and Passlib do.
    import hashlib
    import base64
    digested = base64.b64encode(hashlib.sha256(plain.encode("utf-8")).digest())
    hashed = bcrypt.hashpw(digested, bcrypt.gensalt(rounds=BCRYPT_COST))
    return hashed.decode("ascii")


def verify_password(plain: str, hashed: str) -> bool:
    """Verify plaintext against stored hash. False on any failure."""
    if not plain or not hashed:
        return False
    try:
        import hashlib
        import base64
        digested = base64.b64encode(hashlib.sha256(plain.encode("utf-8")).digest())
        return bcrypt.checkpw(digested, hashed.encode("ascii"))
    except Exception:
        return False


def validate_password_strength(plain: str) -> tuple[bool, str]:
    """Return (ok, reason). Reason empty when ok.

    Rules: min length 10, must contain at least one letter and one digit or
    symbol. Deliberately light — bcrypt cost 12 + rate limit is the real
    defence; password-strength theatre drives users away.
    """
    if not plain or len(plain) < MIN_PASSWORD_LEN:
        return False, f"Password must be at least {MIN_PASSWORD_LEN} characters"
    has_letter = bool(re.search(r"[A-Za-z]", plain))
    has_other = bool(re.search(r"[^A-Za-z]", plain))
    if not (has_letter and has_other):
        return False, "Password must contain letters and at least one number or symbol"
    return True, ""


def is_bcrypt_hash(s: str) -> bool:
    """Cheap check — string looks like a bcrypt hash (starts with $2)."""
    return isinstance(s, str) and s.startswith("$2") and len(s) >= 59
