#!/usr/bin/env python3
"""
aibrain_db.py — Consolidated AIBrain Database (SQLite + FTS5)

Single source of truth for all AIBrain data. Replaces 7 separate DBs + 4 JSON files.
JSON files become seed-only templates for new installs.

Tables:
  memories          — agent knowledge store (FTS5 indexed)
  workflows         — workflow registry (replaces registry.json)
  scheduled_jobs    — cron jobs (replaces scheduled_jobs.json)
  applications      — job applications tracker
  app_emails        — emails linked to job applications
  app_status_history — job application status changes
  approvals         — approval queue for human-in-the-loop
  activity          — agent activity log
  costs             — LLM cost tracking
  traces            — execution traces
  webhooks          — webhook delivery log
  skills            — installed skills registry
  config            — key/value configuration (replaces config.json)
  hyperedges        — HGMem hyperedge definitions (multi-node relationships)
  hyperedge_members — membership/roles linking memories to hyperedges

Usage:
    python aibrain_db.py init                    # Create DB + seed from JSON files
    python aibrain_db.py summary                 # Dashboard stats
    python aibrain_db.py search "query"          # Cross-table FTS search
    python aibrain_db.py config get <key>        # Read config
    python aibrain_db.py config set <key> <val>  # Write config
"""

import json
import logging
import math
import os
import re
import shutil
import sqlite3
import struct
import subprocess
import sys
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# SelRoute — query-type classifier for selective retrieval routing
# Ported from mcp_server.py; derived from LongMemEval experiments.
# ---------------------------------------------------------------------------

def classify_query(query: str) -> str:
    """Classify query type for selective retrieval routing (SelRoute).

    Returns one of: 'temporal', 'preference', 'multi_session', 'ss_user',
    'ss_assistant', 'knowledge_update', 'factual' (default).

    Pure keyword pattern matching — conservative classification.
    'factual' is the safe default (full pipeline works for all types).
    """
    q = query.lower()

    knowledge_update_kw = [
        "changed to", "updated to", "corrected to", "used to be",
        "no longer", "not anymore", "switched from",
        "what changed", "what's different", "what is different",
        "did i change", "did i update", "latest version",
        "most recent", "current value", "new address", "new number",
        "moved to", "changed my",
    ]
    if any(kw in q for kw in knowledge_update_kw):
        return "knowledge_update"

    temporal_kw = [
        "last time", "recently", "last week", "last month",
        "yesterday", "today", "first time", "how long ago",
        "timeline", "chronolog", "when did", "what date",
        "how many times", "how often",
    ]
    if any(kw in q for kw in temporal_kw):
        return "temporal"

    ss_user_kw = [
        "did i say", "did i tell", "did i mention", "i told you",
        "i said", "i asked you", "what did i say", "what did i tell",
        "what did i ask", "remember when i said",
    ]
    if any(kw in q for kw in ss_user_kw):
        return "ss_user"

    preference_kw = [
        "do you prefer", "do i prefer", "does he prefer", "does she prefer",
        "my favorite", "your favorite", "their favorite",
        "my favourite", "your favourite",
        "do you like", "do i like", "what do you think of",
        "fan of", "not a fan",
        "always use", "never use",
        "stopped using", "started using",
        "moved away from",
        "opinion on", "opinion about",
    ]
    if any(kw in q for kw in preference_kw):
        return "preference"

    ss_assistant_kw = [
        "what did you say", "what did you tell", "what did you recommend",
        "you told me", "you said", "you suggested", "you mentioned",
        "your recommendation", "your suggestion", "your advice",
        "what was your", "did you suggest",
    ]
    if any(kw in q for kw in ss_assistant_kw):
        return "ss_assistant"

    multi_kw = [
        "every time", "across all", "across sessions",
        "connection between", "in common", "overlap between",
        "everything about", "all conversations about",
        "summary of all", "how many", "in total",
    ]
    if any(kw in q for kw in multi_kw):
        return "multi_session"

    return "factual"


# Retrieval strategy weights per query type (SelRoute routing table).
# Keys: query_type -> dict with 'fts_weight' and 'vec_weight' for hybrid scoring.
# Derived from LongMemEval experiments: FTS-heavy for factual/knowledge_update,
# vec-heavy for preference/ss_assistant, balanced for temporal/multi_session.
_SELROUTE_WEIGHTS = {
    "factual":          {"fts": 0.8, "vec": 0.2},
    "knowledge_update": {"fts": 0.7, "vec": 0.3},
    "temporal":         {"fts": 0.5, "vec": 0.5},
    "preference":       {"fts": 0.3, "vec": 0.7},
    "ss_user":          {"fts": 0.6, "vec": 0.4},
    "ss_assistant":     {"fts": 0.3, "vec": 0.7},
    "multi_session":    {"fts": 0.5, "vec": 0.5},
}


# ---------------------------------------------------------------------------
# Pluggable embedding support for aibrain_db (dedup + hybrid search)
# ---------------------------------------------------------------------------

_db_embedder = None  # SentenceTransformer instance, set via init_embedder()
_db_vec_enabled = False
_db_embed_backend = None  # "sentence_transformers" | "ollama"
_db_ollama_model = None   # e.g. "all-minilm"

try:
    import sqlite_vec
    _SQLITE_VEC_AVAILABLE = True
except ImportError:
    _SQLITE_VEC_AVAILABLE = False


def _ollama_embed(text: str) -> list[float] | None:
    """Compute embedding via Ollama HTTP API. Returns list of floats or None."""
    import urllib.request
    import json as _json
    url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434") + "/api/embeddings"
    payload = _json.dumps({"model": _db_ollama_model, "prompt": text}).encode()
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
            return data.get("embedding")
    except Exception:
        return None


def init_embedder():
    """Initialize embedding model for aibrain_db (dedup + hybrid search).

    Uses AIBRAIN_EMBEDDING_MODEL env var. Supports:
      - "all-MiniLM-L6-v2" / "bge-base-en-v1.5" — sentence-transformers (default)
      - "ollama/all-minilm" / "ollama/<model>" — Ollama HTTP API (no pip dep)
      - "none" / "off" / "disabled" — disable embeddings

    Returns True if embeddings are available.
    """
    global _db_embedder, _db_vec_enabled, _db_embed_backend, _db_ollama_model
    model_name = os.environ.get("AIBRAIN_EMBEDDING_MODEL", "all-MiniLM-L6-v2")
    if model_name.lower() in ("none", "off", "disabled"):
        return False

    # Ollama backend: model_name starts with "ollama/"
    if model_name.startswith("ollama/"):
        _db_ollama_model = model_name.split("/", 1)[1]
        # Verify Ollama is reachable and model works
        test = _ollama_embed("test")
        if test and len(test) > 0:
            _db_embed_backend = "ollama"
            _db_vec_enabled = True
            _db_embedder = True  # sentinel — marks embeddings as available
            return True
        return False

    # Sentence-transformers backend (default)
    try:
        from sentence_transformers import SentenceTransformer
        _db_embedder = SentenceTransformer(model_name)
        _db_embed_backend = "sentence_transformers"
        _db_vec_enabled = True
        return True
    except ImportError:
        return False


def _compute_embedding(text: str) -> list[float] | None:
    """Compute embedding vector for text. Returns list of floats or None."""
    if _db_embedder is None:
        return None
    if _db_embed_backend == "ollama":
        return _ollama_embed(text)
    try:
        vec = _db_embedder.encode(text, normalize_embeddings=True)
        return vec.tolist()
    except Exception:
        return None


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors. Both assumed normalized."""
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    # For normalized vectors, cosine = dot product
    return dot


def _sanitize_fts5(query: str) -> str:
    """Sanitize user input for FTS5 MATCH — strip operators, escape quotes."""
    import re
    q = re.sub(r'\b(AND|OR|NOT|NEAR)\b', '', query, flags=re.IGNORECASE)
    q = q.replace('"', '""')
    q = re.sub(r'[{}()*^]', '', q)
    q = q.strip()
    if not q:
        return '""'
    return f'"{q}"'


# ---------------------------------------------------------------------------
# Power law decay — FSRS-6 forgetting curve (replaces exponential)
# ---------------------------------------------------------------------------

def _power_law_decay(days_since_access: float, stability: float = 30.0, decay_param: float = 0.1542) -> float:
    """FSRS-6 power law forgetting curve.

    More accurate than exponential — validated against millions of review logs.
    Power law has better long-tail behavior: recent memories decay faster,
    but old memories retain a longer tail instead of going to zero.

    R = (1 + factor * t / S)^(-decay_param)
    where factor = 0.9^(-1/decay_param) - 1
    """
    if days_since_access <= 0:
        return 1.0
    factor = 0.9 ** (-1.0 / decay_param) - 1.0
    return (1.0 + factor * days_since_access / stability) ** (-decay_param)


# ---------------------------------------------------------------------------
# Template-based HyDE query expansion
# ---------------------------------------------------------------------------

QUERY_TEMPLATES = {
    "factual": [
        "{query}",
        "The answer to '{query}' is",
        "Regarding {query}, the key fact is",
    ],
    "temporal": [
        "{query}",
        "The timeline of {query} shows",
        "Recently, {query}",
    ],
    "preference": [
        "{query}",
        "The user prefers {query} because",
        "When it comes to {query}, the preference is",
    ],
    "default": [
        "{query}",
        "{query} refers to",
        "Information about {query} includes",
    ],
}


def hyde_expand(query: str, query_type: str = "default") -> list[str]:
    """Generate HyDE query expansions based on query type.
    Returns list of expanded query strings."""
    templates = QUERY_TEMPLATES.get(query_type, QUERY_TEMPLATES["default"])
    return [t.format(query=query) for t in templates]


def hyde_centroid_embedding(query: str, query_type: str = "default") -> list[float] | None:
    """Compute centroid embedding from HyDE expansions.
    Average multiple embeddings for better semantic coverage."""
    expansions = hyde_expand(query, query_type)
    embeddings = [e for exp in expansions if exp for e in [_compute_embedding(exp)] if e is not None]
    if not embeddings:
        return _compute_embedding(query)
    # Average and L2 normalize
    centroid = [sum(dim) / len(embeddings) for dim in zip(*embeddings)]
    norm = sum(x * x for x in centroid) ** 0.5
    if norm > 0:
        centroid = [x / norm for x in centroid]
    return centroid


# ---------------------------------------------------------------------------
# Salience scoring — combines all available signals for reranking
# ---------------------------------------------------------------------------

_DEFAULT_SALIENCE_WEIGHTS = {
    "fts": 0.35, "vec": 0.35, "imp": 0.15, "rec": 0.10, "acc": 0.05,
}


def _salience_score(
    fts_score: float,
    vec_score: float,
    importance: float,
    access_count: int,
    updated_at: str,
    weights: dict | None = None,
    storage_strength: float = 1.0,
) -> tuple[float, dict]:
    """Combined salience score using all available signals.

    Uses the Bjork & Bjork (1992) dual-strength model:
    - retrieval_strength: FSRS-6 power law decay (current accessibility)
    - storage_strength: encoding quality (never decays, increases on access)
    Combined retention = 0.7 * retrieval + 0.3 * min(storage/10, 1.0)

    Args:
        fts_score: Normalized FTS5 keyword match score (0-1).
        vec_score: Vector cosine similarity score (0-1).
        importance: Memory importance rating (0-1).
        access_count: Number of times this memory has been accessed.
        updated_at: ISO datetime string of last update.
        weights: Optional custom weight dict with keys fts/vec/imp/rec/acc.
        storage_strength: Encoding quality (1.0-100.0). Never decays.

    Returns:
        Tuple of (combined_score, breakdown_dict) where breakdown_dict
        contains individual signal contributions for explainability.
    """
    from datetime import datetime as _dt

    # Dual-strength retention (Bjork & Bjork 1992)
    retrieval = 0.0
    if updated_at:
        try:
            dt_str = str(updated_at).replace("T", " ").split(".")[0]
            updated_dt = _dt.strptime(dt_str[:19], "%Y-%m-%d %H:%M:%S")
            days_since = (_dt.now() - updated_dt).total_seconds() / 86400.0
            retrieval = _power_law_decay(days_since, stability=30.0)
        except (ValueError, TypeError):
            retrieval = 0.0

    storage = min(storage_strength / 10.0, 1.0)
    retention = 0.7 * retrieval + 0.3 * storage

    # Reinforcement: log-scaled access count
    reinforcement = math.log(max(access_count, 0) + 1) * 0.1

    w = weights or _DEFAULT_SALIENCE_WEIGHTS

    breakdown = {
        "fts": round(fts_score, 4),
        "vec": round(vec_score, 4),
        "importance": round(importance, 4),
        "retention": round(retention, 4),
        "retrieval_strength": round(retrieval, 4),
        "storage_strength": round(storage_strength, 4),
        "reinforcement": round(reinforcement, 4),
    }

    combined = (
        w["fts"] * fts_score
        + w["vec"] * vec_score
        + w["imp"] * importance
        + w["rec"] * retention
        + w["acc"] * reinforcement
    )
    breakdown["combined"] = round(combined, 4)

    return combined, breakdown


# ---------------------------------------------------------------------------
# Ported helpers from mcp_server.py — for canonical search implementation
# ---------------------------------------------------------------------------

_STOP_WORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "as", "into", "through", "during",
    "before", "after", "above", "below", "between", "out", "off", "over",
    "under", "again", "further", "then", "once", "here", "there", "when",
    "where", "why", "how", "all", "both", "each", "few", "more", "most",
    "other", "some", "such", "no", "nor", "not", "only", "own", "same",
    "so", "than", "too", "very", "just", "about", "up", "down", "and",
    "but", "or", "if", "what", "which", "who", "whom", "this", "that",
    "these", "those", "am", "it", "its", "i", "me", "my", "we", "our",
    "you", "your", "he", "him", "his", "she", "her", "they", "them",
    "their", "tell", "give", "get", "got", "let", "make", "made",
}

_SYNONYMS = {
    "rrf": "reciprocal rank fusion",
    "fts": "full-text search",
    "mcp": "model context protocol",
    "vps": "virtual private server",
    "pwa": "progressive web app",
    "rn": "react native",
    "ci": "continuous integration",
    "cd": "continuous deployment",
    "db": "database",
    "api": "application programming interface",
    "ui": "user interface",
    "ux": "user experience",
    "llm": "large language model",
    "cve": "common vulnerabilities exposures",
    "grc": "governance risk compliance",
    "cfp": "call for papers",
}

# Fusion routing tables — derived from LongMemEval experiments.
_ROUTING_TABLE_MINILM = {
    "knowledge_update": "rrf",
    "multi_session":    "rrf_all",
    "multi_session_3":  "emb_only",
    "ss_assistant":     "hybrid",
    "preference":       "rrf",
    "ss_user":          "rrf",
    "temporal_1":       "fts_only",
    "temporal":         "consensus",
    "temporal_3":       "rrf_emb_heavy",
    "factual":          "fts_only",
}

_ROUTING_TABLE_BGE_BASE = {
    "knowledge_update": "interleave",
    "multi_session":    "hybrid",
    "multi_session_3":  "rrf_emb_heavy",
    "ss_assistant":     "emb_only",
    "preference":       "interleave",
    "ss_user":          "interleave",
    "temporal_1":       "fts_only",
    "temporal":         "hybrid",
    "temporal_3":       "rrf_emb_heavy",
    "factual":          "fts_only",
}

_RRF_WEIGHTS = {
    "rrf":            {"fts": 2.0, "emb": 0.5, "hyb": 1.0},
    "rrf_all":        {"fts": 1.0, "emb": 1.0, "hyb": 1.0},
    "rrf_emb_heavy":  {"fts": 0.5, "emb": 2.0, "hyb": 1.0},
}


def _get_routing_table() -> dict:
    """Select routing table based on loaded embedding model."""
    model = os.environ.get("AIBRAIN_EMBEDDING_MODEL", "all-MiniLM-L6-v2")
    if "bge-base" in model:
        return _ROUTING_TABLE_BGE_BASE
    return _ROUTING_TABLE_MINILM


def _normalize_query(query: str) -> str:
    """Normalize format variations so searches match regardless of notation style."""
    import re
    q = query

    if "\\" in q:
        q = q + " " + q.replace("\\", "/")
    if re.search(r"[A-Z]:/", q):
        q = re.sub(r"([A-Z]):/", lambda m: f"{m.group(0)} /{m.group(1).lower()}/", q)

    phone_match = re.search(r"\+?\d[\d\s\-]{7,}", q)
    if phone_match:
        digits_only = re.sub(r"[\s\-]", "", phone_match.group())
        q = q + " " + digits_only

    q_lower = q.lower()
    continuity_phrases = [
        "where did we leave off", "where were we", "what were we doing",
        "what was i working on", "last session", "pick up where",
        "continue from", "what happened last time", "resume",
    ]
    if any(phrase in q_lower for phrase in continuity_phrases):
        q = q + " session handoff latest"

    constraint_phrases = [
        "should you never", "should i never", "must not", "must never",
        "not allowed to", "forbidden", "what are the rules",
    ]
    if any(phrase in q_lower for phrase in constraint_phrases):
        q = q + " feedback pattern never"

    mistake_phrases = [
        "handle mistakes", "handle errors", "when things go wrong",
        "about mistakes", "about errors",
    ]
    if any(phrase in q_lower for phrase in mistake_phrases):
        q = q + " feedback minor issue dismiss"

    return q


def _prepare_fts_query(query: str) -> str:
    """Convert natural language query to FTS5 OR query with keywords."""
    import re

    query = _normalize_query(query)
    query = re.sub(r'\b(AND|OR|NOT|NEAR)\b', '', query, flags=re.IGNORECASE)
    query = query.replace('"', '').replace("'", "")
    query = re.sub(r'[{}()*^]', '', query)

    cleaned = re.sub(r"[^\w\s\-_]", " ", query)
    words = cleaned.lower().split()
    keywords = [w for w in words if w not in _STOP_WORDS and len(w) > 1]
    if not keywords:
        keywords = [w for w in words if len(w) > 1]
    if not keywords:
        return '""'

    expanded = list(keywords)
    for kw in keywords:
        if kw in _SYNONYMS:
            expanded.extend(_SYNONYMS[kw].split())

    seen = set()
    unique = []
    for w in expanded:
        if w not in seen:
            seen.add(w)
            unique.append(w)

    return " OR ".join(unique)


def _extract_date_filter(query: str) -> tuple:
    """Extract date references from query and return (cleaned_query, date_from, date_to)."""
    import re
    from datetime import datetime as _dt
    from datetime import timedelta

    now = _dt.now()
    date_from = None
    date_to = None
    cleaned = query

    iso_match = re.search(r'(?:on\s+)?(\d{4}-\d{2}-\d{2})', query)
    if iso_match:
        d = iso_match.group(1)
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = query.replace(iso_match.group(0), "").strip()
        return cleaned or query, date_from, date_to

    slash_match = re.search(r'(?:on\s+)?(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})', query)
    if slash_match:
        a, b, year = int(slash_match.group(1)), int(slash_match.group(2)), int(slash_match.group(3))
        if a > 12:
            day, month = a, b
        elif b > 12:
            month, day = a, b
        else:
            day, month = a, b
        d = f"{year}-{month:02d}-{day:02d}"
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = query.replace(slash_match.group(0), "").strip()
        return cleaned or query, date_from, date_to

    month_names = {
        "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
        "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
    }
    month_pattern = '|'.join(month_names.keys())

    in_month = re.search(r'in\s+(' + month_pattern + r')(?:\s+(\d{4}))?(?!\s+\d)', query.lower())
    if in_month:
        month = month_names[in_month.group(1)]
        year = int(in_month.group(2)) if in_month.group(2) else now.year
        date_from = f"{year}-{month:02d}-01 00:00:00"
        if month == 12:
            date_to = f"{year + 1}-01-01 00:00:00"
        else:
            date_to = f"{year}-{month + 1:02d}-01 00:00:00"
        cleaned = re.sub(re.escape(in_month.group(0)), "", query, flags=re.IGNORECASE).strip()
        return cleaned or query, date_from, date_to

    md_match = re.search(
        r'(?:on\s+)?(' + month_pattern + r')\s+(\d{1,2})(?:st|nd|rd|th)?(?:\s+(\d{4}))?',
        query.lower(),
    )
    if md_match:
        month = month_names[md_match.group(1)]
        day = int(md_match.group(2))
        year = int(md_match.group(3)) if md_match.group(3) else now.year
        d = f"{year}-{month:02d}-{day:02d}"
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = re.sub(re.escape(md_match.group(0)), "", query, flags=re.IGNORECASE).strip()
        return cleaned or query, date_from, date_to

    q_lower = query.lower()
    if "yesterday" in q_lower:
        d = (now - timedelta(days=1)).strftime("%Y-%m-%d")
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = q_lower.replace("yesterday", "").strip()
    elif "today" in q_lower:
        d = now.strftime("%Y-%m-%d")
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = q_lower.replace("today", "").strip()
    elif "last week" in q_lower:
        date_from = (now - timedelta(days=7)).strftime("%Y-%m-%d") + " 00:00:00"
        date_to = now.strftime("%Y-%m-%d") + " 23:59:59"
        cleaned = q_lower.replace("last week", "").strip()
    elif "this week" in q_lower:
        start = now - timedelta(days=now.weekday())
        date_from = start.strftime("%Y-%m-%d") + " 00:00:00"
        date_to = now.strftime("%Y-%m-%d") + " 23:59:59"
        cleaned = q_lower.replace("this week", "").strip()

    return cleaned or query, date_from, date_to


def _rrf_fuse(result_lists: list, k: int = 60, weights: list = None) -> list:
    """Reciprocal Rank Fusion — merge multiple ranked lists."""
    if weights is None:
        weights = [1.0] * len(result_lists)
    scores = {}
    for weight, results in zip(weights, result_lists):
        for rank, mem in enumerate(results):
            mid = mem["id"]
            rrf_score = weight / (k + rank + 1)
            if mid in scores:
                scores[mid] = (scores[mid][0] + rrf_score, scores[mid][1])
            else:
                scores[mid] = (rrf_score, mem)
    fused = sorted(scores.values(), key=lambda x: x[0], reverse=True)
    return [mem for _, mem in fused]


def _interleave_fuse(result_lists: list) -> list:
    """Round-robin interleave from each list, skip duplicates."""
    merged = []
    seen_ids = set()
    max_len = max((len(rl) for rl in result_lists), default=0)
    for i in range(max_len):
        for rl in result_lists:
            if i < len(rl):
                mem = rl[i]
                if mem["id"] not in seen_ids:
                    seen_ids.add(mem["id"])
                    merged.append(mem)
    return merged


def _consensus_rerank(result_lists: list, top_k: int = 15) -> list:
    """Multi-method consensus re-ranking."""
    all_mems = {}
    for rl in result_lists:
        for mem in rl[:top_k]:
            all_mems[mem["id"]] = mem
    scores = {}
    for mid in all_mems:
        methods = 0
        rank_score = 0.0
        for rl in result_lists:
            ids_in_list = [m["id"] for m in rl[:top_k]]
            if mid in ids_in_list:
                methods += 1
                rank_score += 1.0 / (ids_in_list.index(mid) + 1)
        scores[mid] = methods * 2.0 + rank_score
    ranked = sorted(all_mems.keys(), key=lambda x: scores[x], reverse=True)
    return [all_mems[mid] for mid in ranked]


def _passage_rerank(db, fts_query: str, results: list, top_n: int = 20) -> list:
    """Two-stage passage re-ranking within candidate sessions."""
    if not results or not fts_query:
        return results
    candidates = results[:top_n]
    remainder = results[top_n:]
    candidate_ids = [r["id"] for r in candidates]
    if not candidate_ids:
        return results

    ph = ",".join("?" * len(candidate_ids))
    try:
        rows = db.execute(f"""
            SELECT p.memory_id, MAX((rank * -1) * p.role_weight) AS best_score
            FROM memory_passages p
            JOIN passages_fts pf ON p.id=pf.rowid
            WHERE passages_fts MATCH ? AND p.memory_id IN ({ph})
            GROUP BY p.memory_id
            ORDER BY best_score DESC
        """, [fts_query] + candidate_ids).fetchall()
    except (sqlite3.OperationalError, Exception):
        return results

    if not rows:
        return results

    passage_scores = {}
    max_score = max(r[1] for r in rows) if rows else 1.0
    for r in rows:
        passage_scores[r[0]] = r[1] / max_score if max_score > 0 else 0.0

    reranked = []
    for i, r in enumerate(candidates):
        orig_score = 1.0 - (i / len(candidates))
        psg_score = passage_scores.get(r["id"], 0.0)
        combined = orig_score * 0.7 + psg_score * 0.3
        reranked.append((combined, r))
    reranked.sort(key=lambda x: x[0], reverse=True)
    return [r for _, r in reranked] + remainder


def _preference_boost(db, query: str, results: list) -> list:
    """Boost results that have preference edges when query is preference-shaped."""
    if not results:
        return results
    mem_ids = [r["id"] for r in results]
    ph = ",".join("?" * len(mem_ids))
    try:
        pref_rows = db.execute(f"""
            SELECT source_id, relationship, metadata FROM entity_links
            WHERE source_type='memory' AND source_id IN ({ph})
              AND link_type='preference'
        """, mem_ids).fetchall()
    except Exception:
        return results

    if not pref_rows:
        return results

    pref_scores = {}
    for row in pref_rows:
        mid = row[0]
        try:
            meta = json.loads(row[2]) if row[2] else {}
            conf = meta.get("confidence", 0.5)
        except Exception:
            conf = 0.5
        pref_scores[mid] = pref_scores.get(mid, 0) + conf

    boosted = []
    for r in results:
        boost = pref_scores.get(r["id"], 0)
        boosted.append((boost, r))
    boosted.sort(key=lambda x: x[0], reverse=True)
    return [r for _, r in boosted]


# ---------------------------------------------------------------------------
# Contradiction detection — simple heuristic for prediction error gating
# ---------------------------------------------------------------------------

CONTRADICTION_SIGNALS = [
    "actually", "correction", "was wrong", "not anymore", "changed",
    "don't", "doesn't", "never", "no longer", "instead", "but actually",
    "updated", "revised", "contrary", "opposite", "mistake",
]


def _detect_contradiction(new_content: str, existing_content: str) -> bool:
    """Check if new content contradicts existing content.

    Uses keyword heuristic — looks for contradiction signals in the new content.
    This is intentionally simple: false negatives are acceptable (just creates
    a merge instead of supersede), false positives are worse (demotes good memories).
    """
    new_lower = new_content.lower()
    return any(signal in new_lower for signal in CONTRADICTION_SIGNALS)


# ---------------------------------------------------------------------------
# Unified dedup — single canonical function for all store paths
# ---------------------------------------------------------------------------

def canonical_dedup(
    content: str,
    name: str = "",
    threshold: float = 0.92,
    merge_threshold: float = 0.75,
    supersede_threshold: float = 0.70,
) -> dict | None:
    """Canonical deduplication with prediction error gating.

    Used by ALL store paths: aibrain_db.create_memory(), Brain.add(), mcp_server._store().

    Zones (Prediction Error Gating):
    - >= threshold (0.92): Reinforce existing (increment access_count + storage_strength)
    - merge_threshold to threshold (0.75-0.92) + no contradiction: Merge/update content
    - supersede_threshold to threshold (0.70-0.92) + contradiction: Supersede (demote old)
    - < supersede_threshold (< 0.70) or < merge_threshold with no contradiction: Create new

    Args:
        content: The new memory content to check.
        name: Optional name for the memory (used in embedding).
        threshold: Similarity above which we reinforce (near-duplicate). Default 0.92.
        merge_threshold: Similarity above which we merge (no contradiction). Default 0.75.
        supersede_threshold: Similarity above which contradiction triggers supersede. Default 0.70.

    Returns:
        None if no match found (proceed with ADD).
        {"action": "reinforce", "id": ..., "similarity": ...} if >= threshold.
        {"action": "merge", "id": ..., "similarity": ...} if merge zone, no contradiction.
        {"action": "supersede", "old_id": ..., "similarity": ...} if contradiction detected.
        {"action": "create"} if below thresholds.
    """
    if not _db_vec_enabled:
        return _name_dedup(name, content)

    embed_text = f"{name} {content}" if name else content
    new_embedding = _compute_embedding(embed_text)
    if new_embedding is None:
        return _name_dedup(name, content)

    return _vec_dedup(new_embedding, content, threshold, merge_threshold, supersede_threshold)


def _vec_dedup(
    new_embedding: list,
    new_content: str,
    threshold: float,
    merge_threshold: float,
    supersede_threshold: float,
) -> dict | None:
    """Vec-table dedup with prediction error gating.

    Zones:
    - >= threshold: reinforce (bump access_count + storage_strength)
    - merge_threshold to threshold + no contradiction: merge content
    - supersede_threshold to threshold + contradiction: supersede (demote old)
    - below all thresholds: return None (create new)
    """
    db = get_db()
    _logger = logging.getLogger("aibrain.dedup")

    emb_bytes = struct.pack(f"{len(new_embedding)}f", *new_embedding)

    try:
        rows = db.execute(
            "SELECT v.memory_id, v.distance FROM memories_vec v "
            "WHERE v.embedding MATCH ? AND k = ?",
            (emb_bytes, 5),
        ).fetchall()
    except Exception:
        return None

    if not rows:
        return None

    best_id = None
    best_sim = 0.0
    best_content = ""
    for row in rows:
        sim = 1.0 - (row[1] / 2.0)
        mem = db.execute(
            "SELECT id, content FROM memories WHERE id = ? AND active = 1", (row[0],)
        ).fetchone()
        if mem and sim > best_sim:
            best_sim = sim
            best_id = row[0]
            best_content = mem["content"] if mem["content"] else ""

    if best_id is None:
        return None

    # Zone 1: >= threshold — reinforce existing memory
    if best_sim >= threshold:
        try:
            db.execute(
                "UPDATE memories SET access_count = COALESCE(access_count, 0) + 1, "
                "storage_strength = MIN(COALESCE(storage_strength, 1.0) + 0.1, 100.0), "
                "last_accessed = datetime('now') WHERE id = ?",
                (best_id,),
            )
            db.commit()
        except Exception:
            pass
        _logger.info("Reinforce: existing memory ID %d (similarity: %.4f)", best_id, best_sim)
        return {
            "action": "reinforce", "id": best_id,
            "similarity": round(best_sim, 4),
            "message": f"Reinforce: existing memory ID {best_id} (similarity: {best_sim:.4f})",
        }

    # Zone 2/3: merge_threshold to threshold — check for contradiction
    effective_lower = min(merge_threshold, supersede_threshold)
    if best_sim >= effective_lower:
        has_contradiction = _detect_contradiction(new_content, best_content)

        if has_contradiction and best_sim >= supersede_threshold:
            # Zone 3: Supersede — demote old, caller creates new
            try:
                db.execute(
                    "UPDATE memories SET importance = COALESCE(importance, 0.5) * 0.5, "
                    "status = 'superseded', "
                    "valid_until = datetime('now') "
                    "WHERE id = ?",
                    (best_id,),
                )
                db.commit()
            except Exception:
                pass
            _logger.info("Supersede: demoting memory ID %d (similarity: %.4f, contradiction detected)",
                        best_id, best_sim)
            return {
                "action": "supersede", "old_id": best_id,
                "similarity": round(best_sim, 4),
                "message": f"Supersede: demoting memory ID {best_id} (similarity: {best_sim:.4f}, contradiction)",
            }

        if not has_contradiction and best_sim >= merge_threshold:
            # Zone 2: Merge — append new info to existing
            _logger.info("Merge: updating memory ID %d (similarity: %.4f)", best_id, best_sim)
            return {
                "action": "merge", "id": best_id,
                "similarity": round(best_sim, 4),
                "message": f"Merge: updating memory ID {best_id} (similarity: {best_sim:.4f})",
            }

    # Below all thresholds — create new
    return None


def _name_dedup(name: str, content: str) -> dict | None:
    """Fallback dedup by exact name match (when embeddings unavailable)."""
    if not name:
        return None
    db = get_db()
    existing = db.execute(
        "SELECT id, content FROM memories WHERE name = ? AND active = 1", (name,)
    ).fetchone()
    if not existing:
        return None
    if existing["content"].strip() == content.strip():
        return {"action": "dedup", "id": existing["id"], "similarity": 1.0,
                "message": f"Exact name match with memory ID {existing['id']}"}
    return {"action": "merge", "id": existing["id"], "similarity": 0.9,
            "message": f"Same name, different content — memory ID {existing['id']}"}


# ---------------------------------------------------------------------------
# Database location — single source of truth
# ---------------------------------------------------------------------------
# Resolution order (deterministic — never size-based):
#   1. AIBRAIN_ROOT env var (explicit override; must point at a valid root)
#   2. ~/.aibrainrc sentinel file (persisted choice from `aibrain init`)
#   3. Priority scan: ~/projects/aibrain (dev layout) → ~/aibrain (user install)
#   4. If multiple roots contain aibrain.db, WARN loudly listing all of them
#   5. If none found, log a warning and fall back to ~/aibrain (the historical default)
#
# History: 2026-04-06 to 2026-04-10 a "pick the largest" fallback caused a 4-day
# split-brain bug — the "main" DB became whichever stub got most writes. The
# priority-order resolver below makes the choice deterministic. See
# project_aibrain_lobotomy_apr6_apr10 memory.
#
# Every module that needs the brain DB MUST import AIBRAIN_ROOT from here.
# Hardcoded `Path.home() / "aibrain"` outside this file is enforced-rejected
# by the pre-commit linter at .pre-commit-hooks/no-rogue-aibrain-paths.py.

_AIBRAIN_RESOLVE_WARNED = False

def _resolve_root() -> Path:
    """Resolve the canonical AIBRAIN_ROOT directory. See module docstring."""
    import sys
    global _AIBRAIN_RESOLVE_WARNED

    # 1. Explicit env var override
    if "AIBRAIN_ROOT" in os.environ:
        p = Path(os.environ["AIBRAIN_ROOT"])
        return p

    # 2. Sentinel config file
    sentinel = Path.home() / ".aibrainrc"
    if sentinel.exists():
        try:
            configured = Path(sentinel.read_text(encoding="utf-8").strip())
            if (configured / "aibrain.db").exists():
                return configured
        except Exception:
            pass  # fall through

    # 3. Priority-ordered scan — dev first, user install second
    candidates = [
        Path.home() / "projects" / "aibrain",  # dev layout
        Path.home() / "aibrain",                # user install layout
    ]
    found = [c for c in candidates if (c / "aibrain.db").exists()]

    # 4. Multiple roots — warn loudly (rogue-DB detector)
    if len(found) > 1 and not _AIBRAIN_RESOLVE_WARNED:
        _AIBRAIN_RESOLVE_WARNED = True
        sys.stderr.write(
            f"[AIBRAIN] WARNING: Multiple aibrain.db files detected:\n"
        )
        for f in found:
            try:
                sz = (f / "aibrain.db").stat().st_size
                sys.stderr.write(f"  - {f}/aibrain.db  ({sz:,} bytes)\n")
            except Exception:
                sys.stderr.write(f"  - {f}/aibrain.db\n")
        sys.stderr.write(
            f"[AIBRAIN] Using {found[0]} (priority order). "
            f"Set AIBRAIN_ROOT or ~/.aibrainrc to silence this warning.\n"
        )

    if found:
        return found[0]

    # 5. No valid root found — fall back to user install location with a warning
    fallback = Path.home() / "aibrain"
    if not _AIBRAIN_RESOLVE_WARNED:
        _AIBRAIN_RESOLVE_WARNED = True
        sys.stderr.write(
            f"[AIBRAIN] WARNING: No aibrain.db found in {candidates}. "
            f"Falling back to {fallback}. Run `aibrain init` to create a real "
            f"installation, or set AIBRAIN_ROOT explicitly.\n"
        )
    return fallback


def find_all_aibrain_dbs() -> list[Path]:
    """Detect every aibrain.db on the system. For `aibrain doctor` and startup checks."""
    candidates = [
        Path.home() / "projects" / "aibrain" / "aibrain.db",
        Path.home() / "aibrain" / "aibrain.db",
        Path.home() / "projects" / "aibrain" / "dashboard" / "aibrain.db",
        Path.home() / "AppData" / "Local" / "Temp" / "aibrain.db",
        Path("aibrain.db"),
    ]
    seen = set()
    out = []
    for c in candidates:
        try:
            if c.exists():
                resolved = c.resolve()
                if resolved not in seen:
                    seen.add(resolved)
                    out.append(resolved)
        except Exception:
            pass
    return out


AIBRAIN_ROOT = _resolve_root()

# DB filename: pick the largest existing DB in AIBRAIN_ROOT (handles migration)
def _resolve_db_path():
    if "AIBRAIN_DB" in os.environ:
        return Path(os.environ["AIBRAIN_DB"])
    new_db = AIBRAIN_ROOT / "aibrain.db"
    old_db = AIBRAIN_ROOT / "agentos.db"
    if old_db.exists() and new_db.exists():
        # Both exist — use the larger one, but migrate to new name
        if old_db.stat().st_size > new_db.stat().st_size:
            _migrate_db(old_db, new_db)
            return new_db
        return new_db
    if old_db.exists() and not new_db.exists():
        # Only old name exists — rename it
        _migrate_db(old_db, new_db)
        return new_db
    return new_db  # default for fresh installs


def _migrate_db(old_path: Path, new_path: Path):
    """Migrate agentos.db → aibrain.db (rename or merge)."""
    import shutil
    if not old_path.exists():
        return
    if not new_path.exists() or old_path.stat().st_size > new_path.stat().st_size:
        # Copy old → new (keep old as backup until next session)
        shutil.copy2(str(old_path), str(new_path))
        # Also copy WAL files if they exist
        for suffix in ["-shm", "-wal"]:
            wal = old_path.parent / (old_path.name + suffix)
            if wal.exists():
                shutil.copy2(str(wal), str(new_path.parent / (new_path.name + suffix)))

DB_PATH = _resolve_db_path()

_lock = threading.Lock()
_conn = None


def get_db() -> sqlite3.Connection:
    """Thread-safe singleton connection with WAL mode."""
    global _conn
    if _conn is not None:
        return _conn
    with _lock:
        if _conn is not None:
            return _conn
        # Lazy-init embedder if not yet loaded (standalone usage without mcp_server)
        if _db_embedder is None and not _db_vec_enabled:
            init_embedder()
        _conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("PRAGMA foreign_keys=ON")
        _conn.row_factory = sqlite3.Row
        # Load sqlite-vec extension so memories_vec queries work
        if _SQLITE_VEC_AVAILABLE:
            try:
                _conn.enable_load_extension(True)
                sqlite_vec.load(_conn)
                _conn.enable_load_extension(False)
            except Exception:
                pass  # Extension not loadable — vec search degrades to FTS
        _init_schema(_conn)
        # Create vec table if embeddings are available
        if _SQLITE_VEC_AVAILABLE and _db_vec_enabled:
            try:
                dim = len(_compute_embedding("test") or []) or 384
                _conn.execute(f"""
                    CREATE VIRTUAL TABLE IF NOT EXISTS memories_vec USING vec0(
                        memory_id INTEGER PRIMARY KEY,
                        embedding float[{dim}]
                    )
                """)
                _conn.commit()
            except Exception:
                pass  # vec0 creation failed — degrade to FTS-only
        return _conn


def _init_schema(conn: sqlite3.Connection):
    """Create all tables if they don't exist."""
    conn.executescript("""
        -- =====================================================================
        -- MEMORIES (agent knowledge store)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',  -- episodic, semantic, procedural
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,           -- 0.0 to 1.0
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        );

        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;
        CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;

        -- =====================================================================
        -- WORKFLOWS (replaces registry.json)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS workflows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            display_name TEXT DEFAULT '',
            category TEXT DEFAULT 'general',
            description TEXT DEFAULT '',
            cron_schedule TEXT DEFAULT '',
            required_services TEXT DEFAULT '[]',
            playwright_setup TEXT DEFAULT '[]',
            flow TEXT DEFAULT '[]',
            edges TEXT DEFAULT '[]',
            enabled INTEGER DEFAULT 0,
            config_keys TEXT DEFAULT '[]',
            script_path TEXT DEFAULT '',
            source TEXT DEFAULT 'registry',
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now'))
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS workflows_fts USING fts5(
            name, display_name, description, category,
            content=workflows, content_rowid=id
        );

        CREATE TRIGGER IF NOT EXISTS workflows_ai AFTER INSERT ON workflows BEGIN
            INSERT INTO workflows_fts(rowid, name, display_name, description, category)
            VALUES (new.id, new.name, new.display_name, new.description, new.category);
        END;
        CREATE TRIGGER IF NOT EXISTS workflows_au AFTER UPDATE ON workflows BEGIN
            INSERT INTO workflows_fts(workflows_fts, rowid, name, display_name, description, category)
            VALUES ('delete', old.id, old.name, old.display_name, old.description, old.category);
            INSERT INTO workflows_fts(rowid, name, display_name, description, category)
            VALUES (new.id, new.name, new.display_name, new.description, new.category);
        END;

        -- =====================================================================
        -- SCHEDULED_JOBS (replaces scheduled_jobs.json)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS scheduled_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            cron TEXT NOT NULL,
            prompt TEXT DEFAULT '',
            enabled INTEGER DEFAULT 1,
            notes TEXT DEFAULT '',
            workflow_id INTEGER,
            last_run TEXT,
            next_run TEXT,
            created TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (workflow_id) REFERENCES workflows(id)
        );

        -- =====================================================================
        -- JOB APPLICATIONS
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT NOT NULL,
            role TEXT NOT NULL,
            location TEXT DEFAULT '',
            salary TEXT DEFAULT '',
            status TEXT DEFAULT 'applied',
            platform TEXT DEFAULT '',
            portal_url TEXT DEFAULT '',
            job_id TEXT DEFAULT '',
            credentials TEXT DEFAULT '',
            date_applied TEXT DEFAULT '',
            date_updated TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            tags TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            UNIQUE(company, role, platform)
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS applications_fts USING fts5(
            company, role, location, notes, tags,
            content=applications, content_rowid=id
        );

        CREATE TRIGGER IF NOT EXISTS applications_ai AFTER INSERT ON applications BEGIN
            INSERT INTO applications_fts(rowid, company, role, location, notes, tags)
            VALUES (new.id, new.company, new.role, new.location, new.notes, new.tags);
        END;
        CREATE TRIGGER IF NOT EXISTS applications_au AFTER UPDATE ON applications BEGIN
            INSERT INTO applications_fts(applications_fts, rowid, company, role, location, notes, tags)
            VALUES ('delete', old.id, old.company, old.role, old.location, old.notes, old.tags);
            INSERT INTO applications_fts(rowid, company, role, location, notes, tags)
            VALUES (new.id, new.company, new.role, new.location, new.notes, new.tags);
        END;

        CREATE TABLE IF NOT EXISTS app_emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app_id INTEGER,
            direction TEXT DEFAULT 'inbound',
            subject TEXT DEFAULT '',
            sender TEXT DEFAULT '',
            recipient TEXT DEFAULT '',
            body TEXT DEFAULT '',
            email_date TEXT DEFAULT '',
            classification TEXT DEFAULT '',
            gmail_msg_id TEXT DEFAULT '',
            needs_reply INTEGER DEFAULT 0,
            reply_sent INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (app_id) REFERENCES applications(id)
        );

        CREATE TABLE IF NOT EXISTS app_status_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app_id INTEGER NOT NULL,
            old_status TEXT,
            new_status TEXT NOT NULL,
            changed_at TEXT DEFAULT (datetime('now')),
            notes TEXT DEFAULT '',
            FOREIGN KEY (app_id) REFERENCES applications(id)
        );

        -- =====================================================================
        -- APPROVALS (human-in-the-loop queue)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS approvals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            category TEXT DEFAULT '',
            title TEXT DEFAULT '',
            detail TEXT DEFAULT '',
            payload TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending',
            decided_at TEXT,
            decision_note TEXT DEFAULT ''
        );

        -- =====================================================================
        -- ACTIVITY LOG
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT DEFAULT (datetime('now')),
            agent TEXT DEFAULT '',
            action TEXT DEFAULT '',
            category TEXT DEFAULT '',
            detail TEXT DEFAULT '',
            status TEXT DEFAULT 'ok'
        );

        -- =====================================================================
        -- COST TRACKING
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS costs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT DEFAULT (datetime('now')),
            model TEXT DEFAULT '',
            category TEXT DEFAULT '',
            tokens_in INTEGER DEFAULT 0,
            tokens_out INTEGER DEFAULT 0,
            cost_usd REAL DEFAULT 0.0,
            latency_ms INTEGER DEFAULT 0,
            workflow_id TEXT DEFAULT '',
            success INTEGER DEFAULT 1,
            error_msg TEXT DEFAULT ''
        );

        -- =====================================================================
        -- TRACES
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS traces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT DEFAULT (datetime('now')),
            trace_type TEXT DEFAULT '',
            model TEXT DEFAULT '',
            provider TEXT DEFAULT '',
            tokens_in INTEGER DEFAULT 0,
            tokens_out INTEGER DEFAULT 0,
            cost_usd REAL DEFAULT 0.0,
            latency_ms INTEGER DEFAULT 0,
            workflow_id TEXT DEFAULT '',
            action TEXT DEFAULT '',
            detail TEXT DEFAULT '',
            status TEXT DEFAULT 'ok',
            metadata TEXT DEFAULT '{}'
        );

        -- =====================================================================
        -- WEBHOOKS
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS webhook_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hook_name TEXT DEFAULT '',
            timestamp TEXT DEFAULT (datetime('now')),
            source_ip TEXT DEFAULT '',
            payload_preview TEXT DEFAULT '',
            workflow TEXT DEFAULT '',
            exit_code INTEGER DEFAULT 0,
            duration_ms INTEGER DEFAULT 0,
            status TEXT DEFAULT 'ok',
            error TEXT DEFAULT ''
        );

        -- =====================================================================
        -- SKILLS
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            display_name TEXT DEFAULT '',
            description TEXT DEFAULT '',
            category TEXT DEFAULT '',
            file_path TEXT DEFAULT '',
            installed INTEGER DEFAULT 1,
            created TEXT DEFAULT (datetime('now'))
        );

        -- =====================================================================
        -- CONFIG (key/value, replaces config.json)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT DEFAULT '',
            updated TEXT DEFAULT (datetime('now'))
        );

        -- =====================================================================
        -- ENTITY LINKS (universal graph connecting all entity types)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS entity_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type TEXT NOT NULL,
            source_id INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_id INTEGER NOT NULL,
            relationship TEXT NOT NULL DEFAULT 'relates_to',
            metadata TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(source_type, source_id, target_type, target_id, relationship)
        );

        -- =====================================================================
        -- PROJECTS
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'active',
            priority TEXT DEFAULT 'medium',
            category TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- =====================================================================
        -- AGENT PERMISSIONS (human-in-the-loop permission gates)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS agent_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action_type TEXT NOT NULL,
            target TEXT DEFAULT '*',
            permission TEXT NOT NULL,
            granted_by TEXT DEFAULT 'user',
            expires_at TIMESTAMP,
            use_count INTEGER DEFAULT 0,
            last_used_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            notes TEXT
        );

        -- =====================================================================
        -- MEMORY PASSAGES (chunk long memories for better retrieval)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS memory_passages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER NOT NULL,
            passage_index INTEGER NOT NULL,
            content TEXT NOT NULL,
            role_weight REAL DEFAULT 1.0,
            FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_passages_memory ON memory_passages(memory_id);

        CREATE VIRTUAL TABLE IF NOT EXISTS passages_fts USING fts5(
            content, content=memory_passages, content_rowid=id
        );

        CREATE TRIGGER IF NOT EXISTS passages_ai AFTER INSERT ON memory_passages BEGIN
            INSERT INTO passages_fts(rowid, content)
            VALUES (new.id, new.content);
        END;

        CREATE TRIGGER IF NOT EXISTS passages_au AFTER UPDATE ON memory_passages BEGIN
            INSERT INTO passages_fts(passages_fts, rowid, content)
            VALUES ('delete', old.id, old.content);
            INSERT INTO passages_fts(rowid, content)
            VALUES (new.id, new.content);
        END;

        CREATE TRIGGER IF NOT EXISTS passages_ad AFTER DELETE ON memory_passages BEGIN
            INSERT INTO passages_fts(passages_fts, rowid, content)
            VALUES ('delete', old.id, old.content);
        END;

        -- =====================================================================
        -- SEMANTIC FACTS (SPO triples extracted from memories)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS semantic_facts (
            fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            predicate TEXT NOT NULL,
            object TEXT NOT NULL,
            fact_type TEXT NOT NULL DEFAULT 'attribute',
            sentiment TEXT DEFAULT 'NEUTRAL',
            confidence REAL DEFAULT 0.5,
            status TEXT DEFAULT 'ACTIVE',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS fact_evidence (
            evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,
            fact_id INTEGER NOT NULL REFERENCES semantic_facts(fact_id),
            source_memory_id INTEGER NOT NULL,
            extraction_method TEXT NOT NULL DEFAULT 'pattern',
            verbatim_snippet TEXT,
            observed_at TEXT DEFAULT (datetime('now'))
        );

        -- =====================================================================
        -- EVOLUTION PATTERNS (self-improvement tracking)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS evolution_patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern TEXT NOT NULL,
            frequency INTEGER DEFAULT 1,
            severity TEXT DEFAULT 'medium',
            first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active',
            related_outcomes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS evolution_hypotheses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_id INTEGER,
            hypothesis TEXT NOT NULL,
            change_type TEXT NOT NULL,
            target TEXT,
            impact_score REAL DEFAULT 0.5,
            confidence REAL DEFAULT 0.5,
            priority REAL GENERATED ALWAYS AS (impact_score * confidence) STORED,
            status TEXT DEFAULT 'proposed',
            proposed_change TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (pattern_id) REFERENCES evolution_patterns(id)
        );

        -- =====================================================================
        -- HYPEREDGES (HGMem — multi-hop relational memory linking)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS hyperedges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            label TEXT NOT NULL,
            confidence REAL DEFAULT 1.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            metadata TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS hyperedge_members (
            hyperedge_id INTEGER NOT NULL,
            memory_id INTEGER NOT NULL,
            role TEXT DEFAULT 'member',
            FOREIGN KEY (hyperedge_id) REFERENCES hyperedges(id) ON DELETE CASCADE,
            FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE,
            PRIMARY KEY (hyperedge_id, memory_id)
        );

        CREATE INDEX IF NOT EXISTS idx_hyperedge_members_memory ON hyperedge_members(memory_id);

        -- =====================================================================
        -- CATEGORY SUMMARIES (compressed per-type/tag memory summaries)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS category_summaries (
            category TEXT PRIMARY KEY,
            summary TEXT NOT NULL,
            memory_count INTEGER DEFAULT 0,
            avg_importance REAL DEFAULT 0.0,
            top_keywords TEXT DEFAULT '',
            embedding BLOB,
            last_updated TEXT NOT NULL
        );

        -- =====================================================================
        -- SATELLITE DATABASES (domain-specific memory stores)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS satellite_dbs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,          -- e.g. 'findings', 'research', 'logs'
            db_path TEXT NOT NULL,              -- relative to AIBRAIN_ROOT or absolute
            description TEXT DEFAULT '',
            memory_types TEXT DEFAULT '[]',     -- JSON array of types routed here
            search_keywords TEXT DEFAULT '',    -- keywords that trigger federated search
            created TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        );

        -- =====================================================================
        -- COMPANIES (multi-agent orchestration)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS companies (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            mission TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS company_agents (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            name TEXT NOT NULL,
            role TEXT DEFAULT 'general',
            title TEXT DEFAULT '',
            reports_to TEXT,
            model TEXT DEFAULT 'auto',
            task_type TEXT DEFAULT 'simple',
            authority TEXT DEFAULT 'standard',
            capabilities TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (company_id) REFERENCES companies(id)
        );

        CREATE TABLE IF NOT EXISTS company_issues (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            parent_id TEXT,
            parent_task_id TEXT,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            assignee_agent_id TEXT,
            priority TEXT DEFAULT 'medium',
            project TEXT DEFAULT '',
            issue_number INTEGER DEFAULT 0,
            status TEXT DEFAULT 'todo',
            quality_score REAL,
            self_score REAL,
            eval_score REAL,
            quality_verified INTEGER DEFAULT 0,
            quality_flagged INTEGER DEFAULT 0,
            quality_detail TEXT DEFAULT '',
            verification_status TEXT DEFAULT 'unverified',
            verification_notes TEXT,
            cost_cents INTEGER DEFAULT 0,
            started_at TEXT,
            completed_at TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (company_id) REFERENCES companies(id),
            FOREIGN KEY (assignee_agent_id) REFERENCES company_agents(id)
        );
        CREATE INDEX IF NOT EXISTS idx_parent_task ON company_issues(parent_task_id);

        CREATE TABLE IF NOT EXISTS company_approvals (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            type TEXT NOT NULL,
            requested_by_agent_id TEXT,
            payload TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending',
            decision_note TEXT DEFAULT '',
            decided_at TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (company_id) REFERENCES companies(id)
        );

        -- =====================================================================
        -- EXECUTION LOG (harness audit trail)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS execution_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            success INTEGER DEFAULT 0,
            quality_score REAL,
            model_used TEXT,
            cost_cents INTEGER DEFAULT 0,
            duration_ms INTEGER DEFAULT 0,
            task_type TEXT,
            authority TEXT,
            retries INTEGER DEFAULT 0,
            error TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );

        -- =====================================================================
        -- SOCIAL ANALYTICS (marketing engagement tracking)
        -- =====================================================================
        CREATE TABLE IF NOT EXISTS social_analytics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id TEXT,
            platform TEXT NOT NULL,
            posted_at TEXT,
            content_type TEXT,
            content_summary TEXT,
            impressions INTEGER DEFAULT 0,
            likes INTEGER DEFAULT 0,
            comments INTEGER DEFAULT 0,
            shares INTEGER DEFAULT 0,
            clicks INTEGER DEFAULT 0,
            follower_delta INTEGER DEFAULT 0,
            measured_at TEXT,
            created TEXT DEFAULT (datetime('now'))
        );
    """)

    # AFTER DELETE trigger for memories FTS (prevents ghost FTS entries on deletion)
    conn.execute("""
        CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
        END
    """)

    # =========================================================================
    # MIGRATIONS — add new columns to existing DBs (idempotent)
    # =========================================================================
    _migrate_schema(conn)
    conn.commit()


def _migrate_schema(conn: sqlite3.Connection):
    """Add new columns to existing tables. Safe to run multiple times."""
    # Get current memories columns
    cols = {r[1] for r in conn.execute("PRAGMA table_info(memories)").fetchall()}

    migrations = {
        "memory_class": "ALTER TABLE memories ADD COLUMN memory_class TEXT DEFAULT 'semantic'",
        "importance": "ALTER TABLE memories ADD COLUMN importance REAL DEFAULT 0.5",
        "access_count": "ALTER TABLE memories ADD COLUMN access_count INTEGER DEFAULT 0",
        "last_accessed": "ALTER TABLE memories ADD COLUMN last_accessed TEXT",
        "source_agent": "ALTER TABLE memories ADD COLUMN source_agent TEXT",
        "consolidated_from": "ALTER TABLE memories ADD COLUMN consolidated_from TEXT",
        "storage_strength": "ALTER TABLE memories ADD COLUMN storage_strength REAL DEFAULT 1.0",
        "status": "ALTER TABLE memories ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'active'",
        "superseded_by": "ALTER TABLE memories ADD COLUMN superseded_by INTEGER",
        "valid_from": "ALTER TABLE memories ADD COLUMN valid_from TEXT",
        "valid_until": "ALTER TABLE memories ADD COLUMN valid_until TEXT",
    }
    for col, sql in migrations.items():
        if col not in cols:
            conn.execute(sql)

    # Entity links: add valid_from/valid_to for temporal versioning
    link_cols = {r[1] for r in conn.execute("PRAGMA table_info(entity_links)").fetchall()}
    link_migrations = {
        "valid_from": "ALTER TABLE entity_links ADD COLUMN valid_from TEXT",
        "valid_to": "ALTER TABLE entity_links ADD COLUMN valid_to TEXT",
        "link_type": "ALTER TABLE entity_links ADD COLUMN link_type TEXT DEFAULT 'semantic'",
    }
    for col, sql in link_migrations.items():
        if col not in link_cols:
            conn.execute(sql)

    # Backfill valid_from for existing memories that don't have it
    try:
        conn.execute(
            "UPDATE memories SET valid_from = COALESCE(created, datetime('now')) "
            "WHERE valid_from IS NULL"
        )
    except Exception:
        pass  # Column might not exist yet in edge cases

    # Ensure status index exists
    conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_status ON memories(status)")

    # company_issues: verify-and-followup system (parent_task_id, verification_status)
    try:
        issue_cols = {r[1] for r in conn.execute("PRAGMA table_info(company_issues)").fetchall()}
        issue_migrations = {
            "parent_task_id": "ALTER TABLE company_issues ADD COLUMN parent_task_id TEXT",
            "verification_status": "ALTER TABLE company_issues ADD COLUMN verification_status TEXT DEFAULT 'unverified'",
            "verification_notes": "ALTER TABLE company_issues ADD COLUMN verification_notes TEXT",
        }
        for col, sql in issue_migrations.items():
            if col not in issue_cols:
                conn.execute(sql)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_parent_task ON company_issues(parent_task_id)")
    except Exception:
        pass  # Table might not exist yet (fresh DB) — _init_schema will create with base columns

    # =========================================================================
    # USER ACCOUNTS (myaibrain.org — email+password+OAuth+2FA)
    # =========================================================================
    # These run inside _migrate_schema so existing aibrain.db installs pick up
    # the tables without a reinit. All CREATE TABLE IF NOT EXISTS so safe to
    # re-run. Kept here (not _init_schema) because the user-account feature
    # was added after v1.2 shipped — every existing DB needs the migration.
    try:
        # users table: may already exist from rbac.py with a different schema.
        # We CREATE IF NOT EXISTS with the auth schema, then ALTER to add any
        # missing columns. id is TEXT so it's compatible with both subsystems.
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                email TEXT UNIQUE NOT NULL COLLATE NOCASE,
                password_hash TEXT,
                totp_secret TEXT,
                totp_enabled INTEGER NOT NULL DEFAULT 0,
                email_verified INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                last_login_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
        """)
        # Add auth columns if they don't exist (existing RBAC users table).
        _user_cols = {r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
        _user_migrations = {
            "password_hash": "ALTER TABLE users ADD COLUMN password_hash TEXT",
            "totp_secret": "ALTER TABLE users ADD COLUMN totp_secret TEXT",
            "totp_enabled": "ALTER TABLE users ADD COLUMN totp_enabled INTEGER NOT NULL DEFAULT 0",
            "email_verified": "ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0",
            "last_login_at": "ALTER TABLE users ADD COLUMN last_login_at TEXT",
        }
        for _c, _sql in _user_migrations.items():
            if _c not in _user_cols:
                conn.execute(_sql)

        conn.executescript("""

            CREATE TABLE IF NOT EXISTS oauth_links (
                user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                provider TEXT NOT NULL,
                provider_user_id TEXT NOT NULL,
                provider_email TEXT,
                linked_at TEXT NOT NULL DEFAULT (datetime('now')),
                PRIMARY KEY (user_id, provider)
            );
            CREATE INDEX IF NOT EXISTS idx_oauth_provider_uid
                ON oauth_links(provider, provider_user_id);

            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                expires_at TEXT NOT NULL,
                ip TEXT,
                user_agent TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
            CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

            CREATE TABLE IF NOT EXISTS password_reset_tokens (
                token TEXT PRIMARY KEY,
                user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                expires_at TEXT NOT NULL,
                used_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_pwreset_user ON password_reset_tokens(user_id);

            CREATE TABLE IF NOT EXISTS email_verification_tokens (
                token TEXT PRIMARY KEY,
                user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                expires_at TEXT NOT NULL,
                used_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_emailverify_user ON email_verification_tokens(user_id);

            -- license_state: per-user subscription tier + billing state.
            -- Populated by stripe webhook; read by /account dashboard.
            CREATE TABLE IF NOT EXISTS license_state (
                user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                tier TEXT NOT NULL DEFAULT 'free',
                license_key TEXT,
                stripe_customer_id TEXT,
                stripe_subscription_id TEXT,
                valid_until TEXT,
                updated_at TEXT NOT NULL DEFAULT (datetime('now'))
            );

            -- unattributed_license_events: stripe events we could not tie to a
            -- local user (no client_reference_id, no matching users.email).
            -- Kept for manual reconciliation — never written to license_state.
            CREATE TABLE IF NOT EXISTS unattributed_license_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                tier TEXT,
                email TEXT,
                stripe_customer_id TEXT,
                stripe_subscription_id TEXT,
                license_key TEXT,
                raw_data TEXT,
                received_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_unattributed_events_email
                ON unattributed_license_events(email);

            -- login_attempts: rate-limit failed password logins per email.
            CREATE TABLE IF NOT EXISTS login_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL COLLATE NOCASE,
                attempted_at TEXT NOT NULL DEFAULT (datetime('now')),
                success INTEGER NOT NULL DEFAULT 0,
                ip TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_login_attempts_email_time
                ON login_attempts(email, attempted_at);

            -- oauth_states: server-side PKCE+state+nonce storage (short TTL).
            CREATE TABLE IF NOT EXISTS oauth_states (
                state TEXT PRIMARY KEY,
                provider TEXT NOT NULL,
                code_verifier TEXT NOT NULL,
                nonce TEXT,
                link_user_id TEXT,
                redirect_to TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                expires_at TEXT NOT NULL
            );
        """)
    except Exception as _user_migration_err:
        # Don't break DB init if user tables fail — log and continue.
        import logging as _um_log
        _um_log.getLogger(__name__).warning(
            "User-account schema migration failed: %s", _user_migration_err
        )

    # Migrate satellite_dbs: convert absolute paths to relative for portability
    try:
        rows = conn.execute("SELECT id, db_path FROM satellite_dbs").fetchall()
        for row in rows:
            old_path = row[1] if isinstance(row, (list, tuple)) else row["db_path"]
            row_id = row[0] if isinstance(row, (list, tuple)) else row["id"]
            if old_path and os.path.isabs(old_path):
                try:
                    new_path = str(Path(old_path).relative_to(AIBRAIN_ROOT))
                    if new_path != old_path:
                        conn.execute(
                            "UPDATE satellite_dbs SET db_path = ? WHERE id = ?",
                            (new_path, row_id),
                        )
                except ValueError:
                    pass  # Not under AIBRAIN_ROOT — leave as-is
    except Exception:
        pass  # satellite_dbs table might not exist yet

    conn.commit()


# ---------------------------------------------------------------------------
# SEED: Import data from JSON files (first run only)
# ---------------------------------------------------------------------------

def seed_from_json(conn: sqlite3.Connection, force=False):
    """Import data from JSON seed files. Only imports if tables are empty (unless force=True)."""
    stats = {}

    # Seed workflows from registry.json
    registry_path = AIBRAIN_ROOT / "workflows" / "registry.json"
    if registry_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM workflows").fetchone()[0]
        if existing == 0 or force:
            data = json.loads(registry_path.read_text(encoding="utf-8"))
            count = 0
            for wf in data.get("workflows", []):
                try:
                    conn.execute("""
                        INSERT OR REPLACE INTO workflows
                        (name, display_name, category, description, cron_schedule,
                         required_services, playwright_setup, flow, edges,
                         enabled, config_keys, source)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        wf["name"], wf.get("display_name", ""),
                        wf.get("category", "general"), wf.get("description", ""),
                        wf.get("cron_schedule", ""),
                        json.dumps(wf.get("required_services", [])),
                        json.dumps(wf.get("playwright_setup", [])),
                        json.dumps(wf.get("flow", [])),
                        json.dumps(wf.get("edges", [])),
                        1 if wf.get("enabled_by_default", False) else 0,
                        json.dumps(wf.get("config_keys", [])),
                        wf.get("source", "registry"),
                    ))
                    count += 1
                except Exception as e:
                    print(f"  Skip workflow {wf.get('name', '?')}: {e}")
            stats["workflows"] = count

    # Seed scheduled_jobs from scheduled_jobs.json
    sj_path = AIBRAIN_ROOT / "scheduled_jobs.json"
    if sj_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM scheduled_jobs").fetchone()[0]
        if existing == 0 or force:
            data = json.loads(sj_path.read_text(encoding="utf-8"))
            count = 0
            for job in data.get("jobs", []):
                try:
                    conn.execute("""
                        INSERT OR REPLACE INTO scheduled_jobs (name, cron, prompt, enabled, notes)
                        VALUES (?, ?, ?, ?, ?)
                    """, (
                        job["name"], job["cron"], job.get("prompt", ""),
                        1 if job.get("enabled", False) else 0,
                        job.get("notes", ""),
                    ))
                    count += 1
                except Exception as e:
                    print(f"  Skip job {job.get('name', '?')}: {e}")
            stats["scheduled_jobs"] = count

    # Sync config from config.json → DB on every init
    # DB is the source of truth, but config.json edits are picked up
    cfg_path = AIBRAIN_ROOT / "config.json"
    if cfg_path.exists():
        data = json.loads(cfg_path.read_text(encoding="utf-8"))
        count = 0
        synced = 0
        for key, value in data.items():
            val_str = json.dumps(value) if isinstance(value, (dict, list)) else str(value)
            # Skip SET_VIA_ENV markers — placeholders, not real values
            if isinstance(value, str) and value.startswith("SET_VIA_ENV"):
                continue
            # Only update if DB value is different or missing
            existing = conn.execute("SELECT value FROM config WHERE key=?", (key,)).fetchone()
            if existing is None:
                conn.execute(
                    "INSERT INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
                    (key, val_str)
                )
                synced += 1
            elif existing[0] != val_str:
                # config.json was edited — update DB and log revision
                conn.execute(
                    "UPDATE config SET value=?, updated=datetime('now') WHERE key=?",
                    (val_str, key)
                )
                try:
                    conn.execute(
                        "INSERT INTO config_revisions (config_key, changed_by, before_value, after_value, reason) VALUES (?, ?, ?, ?, ?)",
                        (key, "config.json_sync", existing[0], val_str, "Synced from config.json edit")
                    )
                except Exception:
                    pass
                synced += 1
            count += 1
        stats["config"] = count
        if synced > 0:
            stats["config_synced"] = synced

    # Seed memories from existing memory.db (check multiple known locations)
    mem_candidates = [
        Path.home() / ".claude" / "memory" / "memory.db",
        AIBRAIN_ROOT / "memory" / "memory.db",
    ]
    mem_path = next((p for p in mem_candidates if p.exists()), None)
    if mem_path and mem_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        if existing == 0 or force:
            src = sqlite3.connect(str(mem_path))
            src.row_factory = sqlite3.Row
            try:
                rows = src.execute("SELECT * FROM memories WHERE active=1").fetchall()
                count = 0
                for r in rows:
                    conn.execute("""
                        INSERT OR IGNORE INTO memories (name, type, tags, content, created, updated, active)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (r["name"], r["type"], r["tags"], r["content"],
                          r["created"], r["updated"], r["active"]))
                    count += 1
                stats["memories"] = count
            except Exception as e:
                print(f"  Memory import error: {e}")
            finally:
                src.close()

    # Seed approvals from approval.db
    appr_path = AIBRAIN_ROOT / "approval.db"
    if appr_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM approvals").fetchone()[0]
        if existing == 0 or force:
            src = sqlite3.connect(str(appr_path))
            src.row_factory = sqlite3.Row
            try:
                rows = src.execute("SELECT * FROM approval_queue").fetchall()
                count = 0
                for r in rows:
                    conn.execute("""
                        INSERT OR IGNORE INTO approvals
                        (created, updated, category, title, detail, payload, status, decided_at, decision_note)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (r["created"], r["updated"], r["category"], r["title"],
                          r["detail"], r["payload"], r["status"],
                          r["decided_at"], r["decision_note"]))
                    count += 1
                stats["approvals"] = count
            except Exception as e:
                print(f"  Approval import error: {e}")
            finally:
                src.close()

    # Seed activity from activity.db
    act_path = AIBRAIN_ROOT / "activity.db"
    if act_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM activity").fetchone()[0]
        if existing == 0 or force:
            src = sqlite3.connect(str(act_path))
            src.row_factory = sqlite3.Row
            try:
                rows = src.execute("SELECT * FROM activity").fetchall()
                count = 0
                for r in rows:
                    conn.execute("""
                        INSERT OR IGNORE INTO activity (timestamp, agent, action, category, detail, status)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (r["timestamp"], r["agent"], r["action"],
                          r["category"], r["detail"], r["status"]))
                    count += 1
                stats["activity"] = count
            except Exception as e:
                print(f"  Activity import error: {e}")
            finally:
                src.close()

    # Seed job applications from existing job_tracker.db (check multiple locations)
    jt_candidates = [
        AIBRAIN_ROOT / "job_tracker.db",
        AIBRAIN_ROOT / "workflows" / "job_tracker.db",
    ]
    total_apps = 0
    for jt_path in jt_candidates:
        if not jt_path.exists():
            continue
        if not force:
            existing = conn.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
            if existing > 0:
                # Still import but use INSERT OR IGNORE to merge without dupes
                pass
        src = sqlite3.connect(str(jt_path))
        src.row_factory = sqlite3.Row
        try:
            rows = src.execute("SELECT * FROM applications").fetchall()
            for r in rows:
                cols = r.keys()
                # Handle both schemas (old: title/applied_at, new: role/date_applied)
                role = r["title"] if "title" in cols else (r["role"] if "role" in cols else "")
                date = r["applied_at"] if "applied_at" in cols else (r["date_applied"] if "date_applied" in cols else "")
                location = r["location"] if "location" in cols else ""
                platform = r["platform"] if "platform" in cols else ""
                job_id = r["job_id"] if "job_id" in cols else ""
                notes = r["notes"] if "notes" in cols else ""
                tags = r["tags"] if "tags" in cols else ""
                conn.execute("""
                    INSERT OR IGNORE INTO applications
                    (company, role, location, status, platform, job_id, notes, date_applied, tags)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (r["company"], role, location, r["status"], platform, job_id, notes, date, tags))
                total_apps += 1
        except Exception as e:
            print(f"  Job tracker import error ({jt_path.name}): {e}")
        finally:
            src.close()
    stats["applications"] = total_apps

    # Seed skills from skills directory
    skills_dirs = [
        AIBRAIN_ROOT / "skills",
    ]
    skill_count = 0
    for skills_dir in skills_dirs:
        if not skills_dir.exists():
            continue
        for item in skills_dir.rglob("*.md"):
            name = item.stem
            # Derive category from parent dir if nested
            rel = item.relative_to(skills_dir)
            category = str(rel.parent) if str(rel.parent) != "." else "general"
            # Read first line for description
            desc = ""
            try:
                first_lines = item.read_text(encoding="utf-8", errors="ignore").split("\n")
                for line in first_lines[:5]:
                    if line.startswith("# "):
                        desc = line[2:].strip()
                        break
            except Exception:
                pass
            conn.execute("""
                INSERT OR IGNORE INTO skills (name, display_name, description, category, file_path)
                VALUES (?, ?, ?, ?, ?)
            """, (name, name.replace("_", " ").title(), desc, category, str(item)))
            skill_count += 1
    stats["skills"] = skill_count

    conn.commit()
    return stats


# ---------------------------------------------------------------------------
# Cross-table search
# ---------------------------------------------------------------------------

def search_all(query: str, limit=20) -> dict:
    """Search across memories, workflows, applications, and relevant satellite DBs."""
    db = get_db()
    results = {"query": query, "memories": [], "workflows": [], "applications": []}

    # Exclude satellite-routed types from main memory search
    sat_types = _get_satellite_types()
    safe_query = _sanitize_fts5(query)
    params = [safe_query]
    if sat_types:
        placeholders = ", ".join(["?"] * len(sat_types))
        sql = ("SELECT m.* FROM memories m JOIN memories_fts f ON m.id=f.rowid "
               "WHERE memories_fts MATCH ? AND m.active=1 AND m.status = 'active' "
               "AND m.type NOT IN (" + placeholders + ") LIMIT ?")
        params.extend(sat_types)
    else:
        sql = ("SELECT m.* FROM memories m JOIN memories_fts f ON m.id=f.rowid "
               "WHERE memories_fts MATCH ? AND m.active=1 AND m.status = 'active' LIMIT ?")
    params.append(limit)

    query_type = classify_query(query)
    for row in db.execute(sql, params).fetchall():
        r = dict(row)
        r["reason"] = f"Matched keywords: {query[:50]} | Routed via fts for {query_type} query"
        results["memories"].append(r)

    # Federated search: check satellite DBs based on keyword triggers
    query_lower = query.lower()
    for sat in satellite_list():
        keywords = [k.strip().lower() for k in sat.get("search_keywords", "").split(",") if k.strip()]
        if any(kw in query_lower for kw in keywords):
            try:
                sat_results = satellite_search(sat["name"], query, limit=limit)
                if sat_results:
                    results[sat["name"]] = sat_results
            except Exception:
                pass

    for row in db.execute(
        "SELECT w.* FROM workflows w JOIN workflows_fts f ON w.id=f.rowid WHERE workflows_fts MATCH ? LIMIT ?",
        (safe_query, limit)
    ).fetchall():
        r = dict(row)
        for k in ("required_services", "playwright_setup", "flow", "edges", "config_keys"):
            if r.get(k):
                try: r[k] = json.loads(r[k])
                except (json.JSONDecodeError, ValueError): pass
        results["workflows"].append(r)

    for row in db.execute(
        "SELECT a.* FROM applications a JOIN applications_fts f ON a.id=f.rowid WHERE applications_fts MATCH ? LIMIT ?",
        (safe_query, limit)
    ).fetchall():
        results["applications"].append(dict(row))

    results["total"] = sum(len(v) for v in results.values() if isinstance(v, list))
    return results


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

_SENSITIVE_CONFIG_KEYS = frozenset({
    "anthropic_api_key", "openai_api_key", "email_app_password",
    "agent_email_password", "github_token", "stripe_secret_key",
    "telegram_token", "pypi_token", "telegram_bot_token",
    "broker_token", "shodan_api_key", "gumroad_api_key",
})

# Map config key -> env var name(s) to check (first match wins)
_SENSITIVE_ENV_MAP = {
    "github_token": ["GITHUB_PAT", "GITHUB_TOKEN"],
    "anthropic_api_key": ["ANTHROPIC_API_KEY"],
    "openai_api_key": ["OPENAI_API_KEY"],
    "email_app_password": ["GMAIL_APP_PASSWORD", "SMTP_PASSWORD"],
    "agent_email_password": ["GMAIL_APP_PASSWORD", "SMTP_PASSWORD"],
    "stripe_secret_key": ["STRIPE_SECRET_KEY"],
    "telegram_token": ["TELEGRAM_TOKEN"],
    "telegram_bot_token": ["TELEGRAM_TOKEN", "TELEGRAM_BOT_TOKEN"],
    "pypi_token": ["PYPI_TOKEN"],
    "broker_token": ["BROKER_TOKEN"],
    "shodan_api_key": ["SHODAN_API_KEY"],
    "gumroad_api_key": ["GUMROAD_API_KEY"],
}


def _env_override(key: str):
    """Return env-var value for a sensitive config key, or None."""
    env_names = _SENSITIVE_ENV_MAP.get(key)
    if not env_names:
        return None
    for name in env_names:
        val = os.environ.get(name)
        if val:
            return val
    return None


def config_get(key: str, default=None):
    # For sensitive keys, prefer env var over stored config
    if key in _SENSITIVE_CONFIG_KEYS:
        env_val = _env_override(key)
        if env_val is not None:
            return env_val

    db = get_db()
    row = db.execute("SELECT value FROM config WHERE key=?", (key,)).fetchone()
    if row:
        val = row["value"]
        # Transparently decrypt sensitive values
        if key in _SENSITIVE_CONFIG_KEYS:
            try:
                from aibrain_encryption import decrypt_field, _init_fernet
                fernet = _init_fernet()
                if fernet:
                    val = decrypt_field(val, fernet)
            except (ImportError, Exception):
                pass  # encryption not available, return raw
        try:
            return json.loads(val)
        except (json.JSONDecodeError, ValueError):
            return val
    return default


def config_set(key: str, value, changed_by: str = "system", reason: str = ""):
    db = get_db()
    val_str = json.dumps(value) if isinstance(value, (dict, list)) else str(value)

    # Transparently encrypt sensitive values
    if key in _SENSITIVE_CONFIG_KEYS:
        try:
            from aibrain_encryption import encrypt_field, _init_fernet
            fernet = _init_fernet()
            if fernet:
                val_str = encrypt_field(val_str, fernet)
        except (ImportError, Exception):
            pass  # encryption not available, store plaintext

    # Record before state for audit trail
    before = db.execute("SELECT value FROM config WHERE key=?", (key,)).fetchone()
    before_val = before[0] if before else None

    db.execute(
        "INSERT OR REPLACE INTO config (key, value, updated) VALUES (?, ?, datetime('now'))",
        (key, val_str)
    )

    # Log config revision (audit trail)
    try:
        db.execute(
            "INSERT INTO config_revisions (config_key, changed_by, before_value, after_value, reason) VALUES (?, ?, ?, ?, ?)",
            (key, changed_by, before_val, val_str, reason)
        )
    except Exception:
        pass  # config_revisions table may not exist in older installs

    db.commit()


def config_sync_to_file():
    """Write DB config back to config.json (keeps file in sync with DB).

    Called after config_set() to ensure config.json reflects DB state.
    Skips sensitive keys that are encrypted in the DB.
    """
    db = get_db()
    rows = db.execute("SELECT key, value FROM config").fetchall()
    cfg_path = AIBRAIN_ROOT / "config.json"

    # Load existing file config to preserve formatting/comments
    if cfg_path.exists():
        try:
            existing = json.loads(cfg_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            existing = {}
    else:
        existing = {}

    # Update with DB values (skip encrypted sensitive keys)
    for row in rows:
        key = row["key"]
        if key in _SENSITIVE_CONFIG_KEYS:
            continue  # don't write encrypted values to plaintext file
        try:
            existing[key] = json.loads(row["value"])
        except (json.JSONDecodeError, ValueError):
            existing[key] = row["value"]

    # Scrub any sensitive values that leaked into the file previously
    for key in _SENSITIVE_CONFIG_KEYS:
        if key in existing:
            env_names = _SENSITIVE_ENV_MAP.get(key, [])
            marker = f"SET_VIA_ENV:{env_names[0]}" if env_names else "SET_VIA_ENV"
            existing[key] = marker

    cfg_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Scheduled Jobs helpers
# ---------------------------------------------------------------------------

def list_scheduled_jobs(enabled_only=False) -> list:
    db = get_db()
    sql = "SELECT * FROM scheduled_jobs"
    if enabled_only:
        sql += " WHERE enabled=1"
    sql += " ORDER BY name"
    return [dict(r) for r in db.execute(sql).fetchall()]


def get_scheduled_job(name: str) -> dict | None:
    db = get_db()
    row = db.execute("SELECT * FROM scheduled_jobs WHERE name=?", (name,)).fetchone()
    return dict(row) if row else None


def create_scheduled_job(name: str, cron: str, prompt: str, enabled=True, notes="") -> int:
    db = get_db()
    db.execute("""
        INSERT OR REPLACE INTO scheduled_jobs (name, cron, prompt, enabled, notes)
        VALUES (?, ?, ?, ?, ?)
    """, (name, cron, prompt, 1 if enabled else 0, notes))
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


def update_scheduled_job(name: str, **kwargs) -> bool:
    ALLOWED_COLUMNS = frozenset({"cron", "prompt", "enabled", "notes"})
    db = get_db()
    row = db.execute("SELECT id FROM scheduled_jobs WHERE name=?", (name,)).fetchone()
    if not row:
        return False
    sets, vals = [], []
    for key in ALLOWED_COLUMNS:
        if key in kwargs:
            if key not in ALLOWED_COLUMNS:
                continue  # defense-in-depth
            sets.append(key + "=?")
            val = kwargs[key]
            if key == "enabled":  # noqa:plain-secret — comparing column name, not secret
                val = 1 if val else 0
            vals.append(val)
    if not sets:
        return False
    vals.append(row["id"])
    sql = "UPDATE scheduled_jobs SET " + ", ".join(sets) + " WHERE id=?"
    db.execute(sql, vals)
    db.commit()
    return True


def delete_scheduled_job(name: str) -> bool:
    db = get_db()
    c = db.execute("DELETE FROM scheduled_jobs WHERE name=?", (name,))
    db.commit()
    return c.rowcount > 0


# ---------------------------------------------------------------------------
# Workflow helpers
# ---------------------------------------------------------------------------

def _parse_workflow_json_fields(r: dict) -> dict:
    """Parse JSON string fields back to Python objects."""
    for k in ("required_services", "playwright_setup", "flow", "edges", "config_keys"):
        if r.get(k):
            try:
                r[k] = json.loads(r[k])
            except (json.JSONDecodeError, TypeError):
                pass
    return r


def list_workflows(enabled_only=False) -> list:
    db = get_db()
    sql = "SELECT * FROM workflows"
    if enabled_only:
        sql += " WHERE enabled=1"
    sql += " ORDER BY category, name"
    return [_parse_workflow_json_fields(dict(r)) for r in db.execute(sql).fetchall()]


def get_workflow(name: str) -> dict | None:
    db = get_db()
    row = db.execute("SELECT * FROM workflows WHERE name=?", (name,)).fetchone()
    return _parse_workflow_json_fields(dict(row)) if row else None


def update_workflow(name: str, **kwargs) -> bool:
    ALLOWED_COLUMNS = frozenset({
        "enabled", "cron", "description", "category", "tier",
        "required_services", "playwright_setup", "flow", "edges", "config_keys",
    })
    JSON_FIELDS = frozenset({"required_services", "playwright_setup", "flow", "edges", "config_keys"})
    db = get_db()
    row = db.execute("SELECT id FROM workflows WHERE name=?", (name,)).fetchone()
    if not row:
        return False
    sets, vals = [], []
    for key, val in kwargs.items():
        if key not in ALLOWED_COLUMNS:
            continue
        if key == "enabled":  # noqa:plain-secret — comparing column name, not secret
            val = 1 if val else 0
        elif key in JSON_FIELDS and isinstance(val, (dict, list)):
            val = json.dumps(val)
        sets.append(key + "=?")
        vals.append(val)
    if not sets:
        return False
    vals.append(row["id"])
    sql = "UPDATE workflows SET " + ", ".join(sets) + " WHERE id=?"
    db.execute(sql, vals)
    db.commit()
    return True


def enable_workflow(name: str) -> bool:
    try:
        from aibrain_licensing import check_limit
        check_limit("active_workflows")
    except ImportError:
        pass
    return update_workflow(name, enabled=True)


def disable_workflow(name: str) -> bool:
    return update_workflow(name, enabled=False)


# ---------------------------------------------------------------------------
# Activity helpers
# ---------------------------------------------------------------------------

def list_activity(limit=50, agent=None, category=None) -> list:
    db = get_db()
    sql = "SELECT * FROM activity WHERE 1=1"
    params = []
    if agent:
        sql += " AND agent=?"
        params.append(agent)
    if category:
        sql += " AND category=?"
        params.append(category)
    sql += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    return [dict(r) for r in db.execute(sql, params).fetchall()]


def create_activity(agent: str, action: str, category: str, detail="", status="ok") -> int:
    db = get_db()
    db.execute("""
        INSERT INTO activity (timestamp, agent, action, category, detail, status)
        VALUES (datetime('now'), ?, ?, ?, ?, ?)
    """, (agent, action, category, detail, status))
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


def clear_activity() -> int:
    db = get_db()
    count = db.execute("SELECT COUNT(*) FROM activity").fetchone()[0]
    db.execute("DELETE FROM activity")
    db.commit()
    return count


# ---------------------------------------------------------------------------
# Approval helpers
# ---------------------------------------------------------------------------

def list_approvals(status=None, category=None, limit=50) -> list:
    db = get_db()
    sql = "SELECT * FROM approvals WHERE 1=1"
    params = []
    if status:
        sql += " AND status=?"
        params.append(status)
    if category:
        sql += " AND category=?"
        params.append(category)
    sql += " ORDER BY created DESC LIMIT ?"
    params.append(limit)
    return [dict(r) for r in db.execute(sql, params).fetchall()]


def pending_approvals() -> int:
    db = get_db()
    return db.execute("SELECT COUNT(*) FROM approvals WHERE status='pending'").fetchone()[0]


def get_approval(approval_id: int) -> dict | None:
    db = get_db()
    row = db.execute("SELECT * FROM approvals WHERE id=?", (approval_id,)).fetchone()
    if row:
        r = dict(row)
        if r.get("payload"):
            try:
                r["payload"] = json.loads(r["payload"])
            except (json.JSONDecodeError, TypeError):
                pass
        return r
    return None


def create_approval(category: str, title: str, detail: str, payload=None) -> int:
    db = get_db()
    payload_str = json.dumps(payload) if payload else None
    db.execute("""
        INSERT INTO approvals (created, updated, category, title, detail, payload, status)
        VALUES (datetime('now'), datetime('now'), ?, ?, ?, ?, 'pending')
    """, (category, title, detail, payload_str))
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


def decide_approval(approval_id: int, status: str, note="") -> bool:
    db = get_db()
    c = db.execute("""
        UPDATE approvals SET status=?, decided_at=datetime('now'), decision_note=?, updated=datetime('now')
        WHERE id=?
    """, (status, note, approval_id))
    db.commit()
    return c.rowcount > 0


# ---------------------------------------------------------------------------
# Memory helpers (for backend API)
# ---------------------------------------------------------------------------

def list_memories(mem_type=None, tag=None, active_only=True, limit=500) -> list:
    db = get_db()
    sql = "SELECT * FROM memories WHERE 1=1"
    params = []
    if active_only:
        sql += " AND active=1 AND status = 'active'"
    if mem_type:
        sql += " AND type=?"
        params.append(mem_type)
    if tag:
        sql += " AND tags LIKE ?"
        params.append(f"%{tag}%")
    sql += " ORDER BY updated DESC LIMIT ?"
    params.append(limit)
    return [dict(r) for r in db.execute(sql, params).fetchall()]


def get_memory(memory_id: int) -> dict | None:
    db = get_db()
    row = db.execute("SELECT * FROM memories WHERE id=?", (memory_id,)).fetchone()
    return dict(row) if row else None


def check_contradictions(name: str, content: str, threshold=3) -> list:
    """Check if a new memory might contradict existing ones. Returns potential conflicts."""
    db = get_db()
    # Search by name similarity and content overlap
    conflicts = []
    try:
        # FTS search for similar content
        similar = db.execute("""
            SELECT m.id, m.name, m.content, m.type
            FROM memories m JOIN memories_fts f ON m.id=f.rowid
            WHERE memories_fts MATCH ? AND m.active=1 AND m.status = 'active'
            LIMIT ?
        """, (_sanitize_fts5(name.replace('_', ' ')), threshold)).fetchall()
        conflicts = [dict(r) for r in similar]
    except Exception:
        pass
    return conflicts


def _split_into_chunks(text: str, target_size: int = 500) -> list[str]:
    """Split text into ~target_size char chunks at paragraph/sentence boundaries.

    Splits at paragraph breaks first, then sentence boundaries, falling back
    to hard splits at target_size if needed.
    """
    # Split on paragraph boundaries (double newline)
    paragraphs = re.split(r'\n\s*\n', text)
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        # If adding this paragraph stays under target, accumulate
        if len(current) + len(para) + 2 <= target_size:
            current = (current + "\n\n" + para).strip() if current else para
            continue

        # Flush current if non-empty
        if current:
            chunks.append(current)
            current = ""

        # If paragraph itself is under target, start a new chunk with it
        if len(para) <= target_size:
            current = para
            continue

        # Paragraph is too long — split on sentence boundaries
        sentences = re.split(r'(?<=[.!?])\s+', para)
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            if len(current) + len(sentence) + 1 <= target_size:
                current = (current + " " + sentence).strip() if current else sentence
            else:
                if current:
                    chunks.append(current)
                # Hard split if single sentence exceeds target
                if len(sentence) > target_size:
                    for i in range(0, len(sentence), target_size):
                        chunks.append(sentence[i:i + target_size])
                    current = ""
                else:
                    current = sentence

    if current:
        chunks.append(current)

    return chunks


def _create_chunked_memory(
    name: str, mem_type: str, content: str, tags: str = "",
    memory_class: str = "semantic", importance: float = 0.5,
    dedup_threshold: float = 0.92,
    source_agent: str = "unknown",
) -> int:
    """Store a mega-blob memory as parent + chunks.

    The parent is stored with status='active' and the full content.
    Each chunk is stored as a child memory with consolidated_from pointing
    to the parent ID. Embeddings are computed per-chunk for meaningful vectors.

    Returns the parent memory ID.
    """
    db = get_db()

    # 1. Store parent (full content, no embedding — it's too big for useful embedding)
    db.execute("""
        INSERT INTO memories (name, type, memory_class, tags, content, importance,
        storage_strength, created, updated, active, status, valid_from, source_agent)
        VALUES (?, ?, ?, ?, ?, ?, 1.0, datetime('now'), datetime('now'), 1, 'active', datetime('now'), ?)
    """, (name, mem_type, memory_class, tags, content, importance, source_agent))
    db.commit()
    parent_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    # 2. Split into chunks
    chunks = _split_into_chunks(content, target_size=500)

    # 3. Store each chunk as a child memory
    for i, chunk in enumerate(chunks):
        chunk_name = f"{name}__chunk_{i+1}_of_{len(chunks)}"
        consolidated_from = json.dumps([parent_id])

        db.execute("""
            INSERT INTO memories (name, type, memory_class, tags, content, importance,
            storage_strength, consolidated_from, created, updated, active, status, valid_from, source_agent)
            VALUES (?, ?, ?, ?, ?, ?, 1.0, ?, datetime('now'), datetime('now'), 1, 'active', datetime('now'), ?)
        """, (chunk_name, mem_type, memory_class, tags, chunk, importance, consolidated_from, source_agent))
        db.commit()
        chunk_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Compute embedding for chunk (meaningful vector)
        if _db_vec_enabled:
            try:
                embed_text = f"{name} {chunk}" if name else chunk
                emb = _compute_embedding(embed_text)
                if emb is not None:
                    emb_bytes = struct.pack(f"{len(emb)}f", *emb)
                    db.execute(
                        "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                        (chunk_id, emb_bytes),
                    )
                    db.commit()
            except Exception:
                pass

    # Emit event
    try:
        from aibrain.core.event_bus import emit as bus_emit, EventTypes
        bus_emit(EventTypes.MEMORY_STORED, {
            "id": parent_id, "name": name, "type": mem_type,
            "memory_class": memory_class, "importance": importance,
            "chunks": len(chunks),
        })
    except Exception:
        pass

    return parent_id


def create_memory(name: str, mem_type: str, content: str, tags="",
                  memory_class="semantic", importance=0.5,
                  dedup_threshold: float = 0.92,
                  source_agent: str | None = None) -> int | dict:
    """Create a new memory with automatic deduplication and prediction error gating.

    Args:
        dedup_threshold: Cosine similarity threshold (0.0-1.0). If a memory
            with similarity > threshold exists, reinforce instead of creating.
            Set to 0.0 to disable dedup. Default 0.92.
        source_agent: Name of the agent/code path writing this memory. REQUIRED
            for correction/feedback types (learning signal provenance). For
            other types, falls back to env AIBRAIN_ACTOR then 'unknown' with
            a stderr warning. See Apr 11 backfill incident: 1,171 correction
            rows were written with NULL source_agent because this column was
            not plumbed through the canonical write path.

    Returns:
        int: New memory ID if created.
        dict: Action result from canonical_dedup (reinforce/merge/supersede).
    """
    # --- Write-path guard: enforce source_agent attribution ---
    # Added 2026-04-11 after backfill of 1,171 NULL correction rows.
    # Learning signals (correction/feedback/praise/self_reflection) MUST be
    # attributed — no attribution = no trustable evolution_outcomes signal.
    if source_agent is None:
        source_agent = os.environ.get("AIBRAIN_ACTOR")
    if not source_agent:
        if mem_type in ("correction", "feedback", "praise", "self_reflection"):
            raise ValueError(
                f"create_memory(type={mem_type!r}) requires source_agent. "
                f"Pass source_agent= explicitly or set AIBRAIN_ACTOR env var. "
                f"Learning signals must be attributed — see Apr 11 backfill incident."
            )
        # Non-learning types get a warned default rather than a hard fail,
        # so workflows don't break in the middle of a run.
        source_agent = "unknown"
        print(
            f"[create_memory] WARNING: source_agent missing for "
            f"type={mem_type!r} name={name!r} — defaulted to 'unknown'. "
            f"Pass source_agent= or set AIBRAIN_ACTOR.",
            file=sys.stderr,
        )

    # Enforce tier limits
    try:
        from aibrain_licensing import check_limit
        check_limit("memories")
    except ImportError:
        pass  # tier_limits not available, skip enforcement

    # --- Chunk mega-blob memories (>10K chars produce garbage embeddings) ---
    CHUNK_THRESHOLD = 10_000
    if len(content) > CHUNK_THRESHOLD:
        return _create_chunked_memory(
            name=name, mem_type=mem_type, content=content, tags=tags,
            memory_class=memory_class, importance=importance,
            dedup_threshold=dedup_threshold,
            source_agent=source_agent,
        )

    # --- Deduplication check (uses canonical_dedup with prediction error gating) ---
    if dedup_threshold > 0.0:
        dedup_result = canonical_dedup(content, name=name, threshold=dedup_threshold)
        if dedup_result is not None:
            action = dedup_result.get("action")

            if action == "reinforce":
                # Near-duplicate — already reinforced in canonical_dedup
                return dedup_result

            if action == "merge":
                # Merge zone — append new info to existing memory
                merge_id = dedup_result["id"]
                try:
                    db = get_db()
                    existing = db.execute(
                        "SELECT content FROM memories WHERE id = ?", (merge_id,)
                    ).fetchone()
                    if existing:
                        merged_content = existing["content"] + " | " + content
                        db.execute(
                            "UPDATE memories SET content = ?, "
                            "access_count = COALESCE(access_count, 0) + 1, "
                            "storage_strength = MIN(COALESCE(storage_strength, 1.0) + 0.1, 100.0), "
                            "updated = datetime('now') WHERE id = ?",
                            (merged_content, merge_id),
                        )
                        # Update embedding for merged content
                        if _db_vec_enabled:
                            embed_text = f"{name} {merged_content}" if name else merged_content
                            new_emb = _compute_embedding(embed_text)
                            if new_emb is not None:
                                emb_bytes = struct.pack(f"{len(new_emb)}f", *new_emb)
                                try:
                                    db.execute(
                                        "UPDATE memories_vec SET embedding = ? WHERE memory_id = ?",
                                        (emb_bytes, merge_id),
                                    )
                                except Exception:
                                    pass
                        db.commit()
                except Exception:
                    pass
                return dedup_result

            if action == "supersede":
                # Contradiction detected — old memory already demoted,
                # add superseded_by metadata after creating new memory below
                pass
            else:
                # Unknown action or legacy "dedup" — treat as skip
                return dedup_result

    # Check if this type should be routed to a satellite DB
    db = get_db()
    try:
        sat_row = db.execute("""
            SELECT name FROM satellite_dbs WHERE active=1 AND memory_types LIKE ?
        """, (f'%"{mem_type}"%',)).fetchone()
    except Exception:
        sat_row = None

    if sat_row:
        # Route to satellite DB
        sat_db = _get_satellite_db(sat_row["name"])
        sat_db.execute("""
            INSERT INTO memories (name, type, memory_class, tags, content, importance,
            storage_strength, created, updated, active, source_agent)
            VALUES (?, ?, ?, ?, ?, ?, 1.0, datetime('now'), datetime('now'), 1, ?)
        """, (name, mem_type, memory_class, tags, content, importance, source_agent))
        sat_db.commit()
        new_id = sat_db.execute("SELECT last_insert_rowid()").fetchone()[0]

        # Compute and store embedding in satellite's vec table
        if _db_vec_enabled:
            try:
                embed_text = f"{name} {content}" if name else content
                emb = _compute_embedding(embed_text)
                if emb is not None:
                    emb_bytes = struct.pack(f"{len(emb)}f", *emb)
                    sat_db.execute(
                        "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                        (new_id, emb_bytes),
                    )
                    sat_db.commit()
            except Exception:
                pass  # Embedding failure doesn't block storage

        return new_id

    # Enrich correction/feedback memories with structured schema
    if mem_type in ("correction", "feedback"):
        try:
            from aibrain.core.correction_schema import enrich_correction
            content = enrich_correction(name, content)
        except Exception:
            pass  # Schema enrichment is best-effort

    # Default: store in main DB with initial storage_strength = 1.0
    db.execute("""
        INSERT INTO memories (name, type, memory_class, tags, content, importance,
        storage_strength, created, updated, active, valid_from, source_agent)
        VALUES (?, ?, ?, ?, ?, ?, 1.0, datetime('now'), datetime('now'), 1, datetime('now'), ?)
    """, (name, mem_type, memory_class, tags, content, importance, source_agent))
    db.commit()
    mem_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Compute and store embedding in memories_vec
    if _db_vec_enabled:
        try:
            embed_text = f"{name} {content}" if name else content
            emb = _compute_embedding(embed_text)
            if emb is not None:
                emb_bytes = struct.pack(f"{len(emb)}f", *emb)
                db.execute(
                    "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                    (mem_id, emb_bytes),
                )
                db.commit()
        except Exception:
            pass  # Embedding failure doesn't block storage

    # If this was a supersede, update the old memory's metadata
    if dedup_threshold > 0.0 and isinstance(dedup_result, dict) and dedup_result.get("action") == "supersede":
        old_id = dedup_result.get("old_id")
        if old_id:
            try:
                # Store superseded_by reference in old memory's tags
                old_row = db.execute("SELECT tags FROM memories WHERE id = ?", (old_id,)).fetchone()
                old_tags = old_row["tags"] if old_row and old_row["tags"] else ""
                new_tags = old_tags + f" [superseded_by:{mem_id}]" if old_tags else f"[superseded_by:{mem_id}]"
                db.execute("UPDATE memories SET tags = ? WHERE id = ?", (new_tags, old_id))
                db.commit()
            except Exception:
                pass
        dedup_result["new_id"] = mem_id
        return dedup_result

    # Auto-update category summary (debounced)
    try:
        _maybe_update_category_summary(mem_type)
    except Exception:
        pass  # Never fail a create because of summary update

    # Emit event bus events (fire-and-forget)
    try:
        from aibrain.core.event_bus import emit as bus_emit, EventTypes
        bus_emit(EventTypes.MEMORY_STORED, {
            "id": mem_id, "name": name, "type": mem_type,
            "memory_class": memory_class, "importance": importance,
        })
        if mem_type in ("feedback", "correction"):
            bus_emit(EventTypes.CORRECTION_RECEIVED, {
                "id": mem_id, "name": name, "type": mem_type,
                "content_preview": content[:200] if content else "",
            })
    except Exception:
        pass  # Event emission never blocks memory creation

    return mem_id


def _check_dedup(content: str, new_embedding: list[float],
                 threshold: float) -> dict | None:
    """DEPRECATED: Use canonical_dedup() instead.

    Thin backward-compat wrapper. Delegates to canonical_dedup which uses
    the vec table index instead of looping over 500 candidates.
    """
    return canonical_dedup(content, threshold=threshold)


def update_memory(memory_id: int, **kwargs) -> bool:
    db = get_db()
    ALLOWED_COLUMNS = frozenset({"name", "type", "tags", "content", "active"})
    sets, vals = [], []
    for key in ALLOWED_COLUMNS:
        if key in kwargs:
            sets.append(key + "=?")
            vals.append(kwargs[key])
    if not sets:
        return False
    sets.append("updated=datetime('now')")
    vals.append(memory_id)
    sql = "UPDATE memories SET " + ", ".join(sets) + " WHERE id=?"
    db.execute(sql, vals)
    db.commit()

    # Re-compute embedding when name or content changes
    if _db_vec_enabled and ("content" in kwargs or "name" in kwargs):
        try:
            row = db.execute("SELECT name, content FROM memories WHERE id = ?", (memory_id,)).fetchone()
            if row:
                embed_text = f"{row['name']} {row['content']}" if row["name"] else row["content"]
                emb = _compute_embedding(embed_text)
                if emb is not None:
                    emb_bytes = struct.pack(f"{len(emb)}f", *emb)
                    db.execute(
                        "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                        (memory_id, emb_bytes),
                    )
                    db.commit()
        except Exception:
            pass

    return True


def delete_memory(memory_id: int) -> bool:
    """Soft delete."""
    return update_memory(memory_id, active=0)


def _get_satellite_types() -> list:
    """Get memory types that are routed to satellite DBs."""
    try:
        db = get_db()
        rows = db.execute("SELECT memory_types FROM satellite_dbs WHERE active=1").fetchall()
        types = []
        for r in rows:
            types.extend(json.loads(r["memory_types"]))
        return types
    except Exception:
        return []


def search_memories(query: str, limit=20, recency_weight=True,
                    exclude_satellites=True, search_type: str | None = None,
                    salience_weights: dict | None = None) -> list:
    """Canonical search — single implementation used by all entry points.

    Combines the best features from the former triple implementations:
    - Full SelRoute fusion strategies (rrf, consensus, interleave, hybrid, etc.)
    - Passage-level re-ranking within top candidates
    - Temporal date filtering
    - Preference edge boosting
    - Salience scoring (FTS + vec + importance + recency + access count)
    - Explainable recall (reason + score_breakdown on every result)

    Args:
        query: Natural language search query.
        limit: Max results to return.
        recency_weight: Include recency bonus in FTS ordering.
        exclude_satellites: Skip memory types routed to satellite DBs.
        search_type: Optional hint to override query classification.
        salience_weights: Optional custom salience weights dict.

    Returns:
        List of memory dicts, each with 'reason' and 'score_breakdown' fields.
    """
    import time as _time
    _search_start = _time.perf_counter()
    db = get_db()
    _log = logging.getLogger("aibrain.search")

    # SelRoute: classify query type and determine fusion route
    # If search_type is a valid route name, use it directly as the route override
    # Multi-strategy RRF: delegate to multi_retrieval module
    if search_type == "multi_rrf":
        try:
            from aibrain.core.multi_retrieval import multi_search
            return multi_search(query, k=limit, db=db)
        except Exception as _e:
            logging.getLogger("aibrain.search").warning(
                "multi_rrf fallback to standard search: %s", _e)
            # Fall through to standard search

    _VALID_ROUTES = {"fts_only", "emb_only", "hybrid", "rrf", "rrf_all",
                     "rrf_emb_heavy", "consensus", "interleave"}
    if search_type and search_type in _VALID_ROUTES:
        query_type = classify_query(query)
        route = search_type
    else:
        query_type = search_type if search_type else classify_query(query)
        route = _get_routing_table().get(query_type, "fts_only")
    _log.info("SelRoute: query_type=%s route=%s query=%s", query_type, route, query[:80])

    # Extract temporal filters from query
    cleaned_query, date_from, date_to = _extract_date_filter(query)
    search_query = cleaned_query if len(cleaned_query.replace("?", "").strip()) > 3 else query

    # Build type exclusion clause for satellite types
    exclude_type_clause = ""
    exclude_params = []
    if exclude_satellites:
        sat_types = _get_satellite_types()
        if sat_types:
            placeholders = ", ".join(["?"] * len(sat_types))
            exclude_type_clause = " AND m.type NOT IN (" + placeholders + ")"
            exclude_params = sat_types

    # Prepare FTS query (with synonym expansion)
    fts_query = _prepare_fts_query(search_query)
    pool = max(limit * 3, 50)

    # --- Individual retrieval methods ---

    def _run_fts(pool_size: int) -> list:
        try:
            if recency_weight:
                sql = ("SELECT m.*, rank AS fts_score, "
                       "CASE WHEN julianday('now') - julianday(m.updated) < 7 THEN 0.3 "
                       "WHEN julianday('now') - julianday(m.updated) < 30 THEN 0.15 "
                       "ELSE 0.0 END AS recency_bonus, "
                       "COALESCE(m.importance, 0.5) AS imp "
                       "FROM memories m JOIN memories_fts f ON m.id=f.rowid "
                       "WHERE memories_fts MATCH ? AND m.active=1 AND m.status = 'active'"
                       + exclude_type_clause +
                       " ORDER BY (rank * -1) + recency_bonus + imp + (COALESCE(m.access_count, 0) * 0.01) DESC "
                       "LIMIT ?")
                return [dict(r) for r in db.execute(
                    sql, [fts_query] + exclude_params + [pool_size]
                ).fetchall()]
            else:
                sql = ("SELECT m.* FROM memories m JOIN memories_fts f ON m.id=f.rowid "
                       "WHERE memories_fts MATCH ? AND m.active=1 AND m.status = 'active'"
                       + exclude_type_clause + " LIMIT ?")
                return [dict(r) for r in db.execute(
                    sql, [fts_query] + exclude_params + [pool_size]
                ).fetchall()]
        except sqlite3.OperationalError:
            # Fallback to LIKE search
            try:
                return [dict(r) for r in db.execute(
                    "SELECT * FROM memories WHERE active=1 AND status = 'active' AND "
                    "(name LIKE ? OR content LIKE ? OR tags LIKE ?)"
                    + exclude_type_clause + " ORDER BY updated DESC LIMIT ?",
                    [f"%{query}%", f"%{query}%", f"%{query}%"] + exclude_params + [pool_size],
                ).fetchall()]
            except Exception:
                return []

    def _run_emb(pool_size: int) -> list:
        if not _db_vec_enabled:
            return []
        # Use HyDE centroid embedding for queries > 3 words (short queries don't benefit)
        word_count = len(query.split())
        if word_count > 3:
            query_emb = hyde_centroid_embedding(query, query_type)
        else:
            query_emb = _compute_embedding(query)
        if query_emb is None:
            return []
        emb_bytes = struct.pack(f"{len(query_emb)}f", *query_emb)
        try:
            rows = db.execute(
                "SELECT v.memory_id, v.distance FROM memories_vec v "
                "WHERE v.embedding MATCH ? AND k = ?",
                (emb_bytes, pool_size),
            ).fetchall()
            results = []
            for row in rows:
                mem = db.execute(
                    "SELECT * FROM memories WHERE id=? AND active=1 AND status = 'active'", (row[0],)
                ).fetchone()
                if mem:
                    d = dict(mem)
                    d["vec_distance"] = row[1]
                    results.append(d)
            return results
        except Exception:
            return []

    def _run_hyb(pool_size: int) -> list:
        fts = _run_fts(pool_size)
        emb = _run_emb(pool_size)
        if fts and emb:
            return _rrf_fuse([fts, emb], k=60, weights=[1.0, 1.2])
        return fts or emb or []

    # --- Determine which methods to run based on route ---
    needs_fts = route in ("fts_only", "rrf", "rrf_all", "rrf_emb_heavy", "consensus", "interleave")
    needs_emb = route in ("emb_only", "rrf", "rrf_all", "rrf_emb_heavy", "consensus", "interleave")
    needs_hyb = route in ("hybrid", "rrf", "rrf_all", "rrf_emb_heavy", "consensus", "interleave")

    fts_results = _run_fts(pool) if needs_fts else []
    emb_results = _run_emb(pool) if needs_emb else []
    hyb_results = _run_hyb(pool) if needs_hyb else []

    # Graceful degradation
    if needs_emb and not emb_results and not _db_vec_enabled:
        route = "fts_only"
        if not fts_results:
            fts_results = _run_fts(pool)

    # --- Stage 1: Apply fusion strategy ---
    if route == "fts_only":
        results = fts_results
    elif route == "emb_only":
        results = emb_results
    elif route == "hybrid":
        results = hyb_results
    elif route == "consensus":
        results = _consensus_rerank([fts_results, emb_results, hyb_results])
    elif route == "interleave":
        results = _interleave_fuse([fts_results, emb_results, hyb_results])
    elif route in ("rrf", "rrf_all", "rrf_emb_heavy"):
        w = _RRF_WEIGHTS.get(route, {"fts": 1.0, "emb": 1.0, "hyb": 1.0})
        results = _rrf_fuse(
            [fts_results, emb_results, hyb_results],
            k=60,
            weights=[w["fts"], w["emb"], w["hyb"]],
        )
    else:
        results = fts_results if fts_results else []

    # Fallback for empty results on temporal queries
    if not results and query_type == "temporal":
        try:
            recent = db.execute(
                "SELECT m.* FROM memories m WHERE m.active=1 AND m.status = 'active'"
                + exclude_type_clause +
                " ORDER BY m.updated DESC LIMIT ?",
                exclude_params + [limit],
            ).fetchall()
            results = [dict(r) for r in recent]
            for r in results:
                r["reason"] = f"Recent memory from {r.get('updated', 'unknown date')}"
                r["score_breakdown"] = {"fts": 0, "vec": 0, "importance": 0, "retention": 1.0, "retrieval_strength": 1.0, "storage_strength": 1.0, "reinforcement": 0, "combined": 0}
            _log_attention(query, results, route, _time.perf_counter() - _search_start)
            return results
        except Exception:
            return []
    if not results:
        _log_attention(query, [], route, _time.perf_counter() - _search_start)
        return []

    # Stage 2: Passage-level re-ranking
    if results and fts_query:
        results = _passage_rerank(db, fts_query, results, top_n=20)

    # Stage 3: Temporal filtering
    if date_from or date_to:
        temporal_results = []
        non_temporal = []
        for r in results:
            updated = r.get("updated") or r.get("created") or ""
            in_range = True
            if date_from and updated < date_from:
                in_range = False
            if date_to and updated > date_to:
                in_range = False
            if in_range:
                temporal_results.append(r)
            else:
                non_temporal.append(r)
        results = (temporal_results + non_temporal)[:limit]
    else:
        results = results[:limit]

    # Stage 4: Preference boost
    if query_type == "preference" and results:
        results = _preference_boost(db, query, results)

    # Stage 5: Salience scoring + explainable recall
    fts_ids = set(r["id"] for r in fts_results) if fts_results else set()
    emb_ids = set(r["id"] for r in emb_results) if emb_results else set()

    # Build normalized FTS score map
    fts_score_map = {}
    if fts_results:
        raw_scores = []
        for r in fts_results:
            raw = r.get("fts_score", 0)
            score = (-raw) if raw and raw < 0 else abs(raw) if raw else 0.0
            raw_scores.append(score)
        max_fts = max(raw_scores) if raw_scores else 1.0
        for i, r in enumerate(fts_results):
            fts_score_map[r["id"]] = raw_scores[i] / max_fts if max_fts > 0 else 0.0

    # Build vec score map (convert distance to similarity)
    vec_score_map = {}
    for r in (emb_results or []):
        if "vec_distance" in r:
            vec_score_map[r["id"]] = max(0.0, 1.0 - (r["vec_distance"] / 2.0))

    scored_results = []
    for r in results:
        mid = r["id"]
        fts_s = fts_score_map.get(mid, 0.0)
        vec_s = vec_score_map.get(mid, 0.0)
        imp = float(r.get("importance", 0.5) or 0.5)
        acc = int(r.get("access_count", 0) or 0)
        updated = r.get("updated", "")
        ss = float(r.get("storage_strength", 1.0) or 1.0)

        combined, breakdown = _salience_score(
            fts_s, vec_s, imp, acc, updated, weights=salience_weights,
            storage_strength=ss,
        )
        r["score_breakdown"] = breakdown

        # Build reason string
        in_fts = mid in fts_ids
        in_emb = mid in emb_ids
        if in_fts and in_emb:
            r["reason"] = (f"Keyword match ({fts_s:.2f}) + semantic similarity ({vec_s:.2f})"
                          f" | Routed via {route} for {query_type} query")
        elif in_fts:
            r["reason"] = (f"Matched keywords: {query[:50]}"
                          f" | Routed via {route} for {query_type} query")
        elif in_emb:
            r["reason"] = (f"Semantic similarity: {vec_s:.2f}"
                          f" | Routed via {route} for {query_type} query")
        elif date_from or date_to:
            r["reason"] = (f"Recent memory from {r.get('updated', 'unknown date')}"
                          f" | Routed via {route} for {query_type} query")
        else:
            r["reason"] = f"Routed via {route} for {query_type} query"

        # Flag temporal validity
        valid_until = r.get("valid_until")
        if valid_until:
            r["stale"] = True
            r["valid_until"] = valid_until
            r["reason"] = "[STALE — superseded " + valid_until + "] " + r.get("reason", "")
        else:
            r["stale"] = False

        scored_results.append((combined, r))

    # Re-sort by salience score
    scored_results.sort(key=lambda x: x[0], reverse=True)
    results = [r for _, r in scored_results]

    # Track access (non-blocking) — increment both access_count and storage_strength
    try:
        for r in results:
            db.execute(
                "UPDATE memories SET access_count = COALESCE(access_count, 0) + 1, "
                "storage_strength = MIN(COALESCE(storage_strength, 1.0) + 0.1, 100.0), "
                "last_accessed = datetime('now') WHERE id = ?",
                (r["id"],),
            )
        if results:
            db.commit()
    except Exception:
        pass

    _log_attention(query, results, route, _time.perf_counter() - _search_start)
    return results


def _log_attention(query: str, results: list, route: str, elapsed: float):
    """Fire-and-forget telemetry log for a search retrieval."""
    try:
        from aibrain.core.attention_telemetry import log_retrieval
        log_retrieval(query, results, {
            "search_type": route,
            "latency_ms": round(elapsed * 1000, 2),
        })
    except Exception:
        pass


def memory_summary() -> dict:
    db = get_db()
    s = {"total": 0, "by_type": {}, "satellites": {}}
    for row in db.execute("SELECT type, COUNT(*) as c FROM memories WHERE active=1 AND status = 'active' GROUP BY type"):
        s["by_type"][row["type"]] = row["c"]
        s["total"] += row["c"]
    # Include satellite DB stats
    for sat in satellite_list():
        try:
            sat_db = _get_satellite_db(sat["name"])
            count = sat_db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
            s["satellites"][sat["name"]] = count
        except Exception:
            s["satellites"][sat["name"]] = "error"
    return s


# ---------------------------------------------------------------------------
# Satellite DB system (domain-specific memory stores)
# ---------------------------------------------------------------------------

_satellite_conns: dict[str, sqlite3.Connection] = {}


def _get_satellite_db(name: str) -> sqlite3.Connection:
    """Get or create connection to a satellite database."""
    if name in _satellite_conns:
        return _satellite_conns[name]

    db = get_db()
    row = db.execute(
        "SELECT db_path FROM satellite_dbs WHERE name=? AND active=1", (name,)
    ).fetchone()
    if not row:
        raise ValueError(f"Satellite DB '{name}' not registered")

    db_path = row["db_path"]
    if not os.path.isabs(db_path):
        db_path = str(AIBRAIN_ROOT / db_path)

    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.row_factory = sqlite3.Row

    # Load sqlite-vec extension if available (needed for memories_vec)
    if _SQLITE_VEC_AVAILABLE:
        try:
            conn.enable_load_extension(True)
            sqlite_vec.load(conn)
            conn.enable_load_extension(False)
        except Exception:
            pass  # Extension not loadable — vec search will degrade gracefully

    # Ensure satellite has the memories schema
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'finding',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            source_agent TEXT DEFAULT '',
            storage_strength REAL DEFAULT 1.0,
            status TEXT DEFAULT 'active'
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        );
        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;
        CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;
    """)
    conn.commit()

    # Migrate existing satellites: add missing columns
    for col, default in [("storage_strength", "1.0"), ("status", "'active'")]:
        try:
            conn.execute(f"ALTER TABLE memories ADD COLUMN {col} DEFAULT {default}")
            conn.commit()
        except Exception:
            pass  # Column already exists

    # Create vec table for satellite embeddings (migrate existing satellites too)
    if _SQLITE_VEC_AVAILABLE and _db_vec_enabled:
        try:
            dim = len(_compute_embedding("test") or []) or 384
            conn.execute(f"""
                CREATE VIRTUAL TABLE IF NOT EXISTS memories_vec USING vec0(
                    memory_id INTEGER PRIMARY KEY,
                    embedding float[{dim}]
                )
            """)
            conn.commit()
        except Exception:
            pass  # vec0 creation failed — degrade to FTS-only
    _satellite_conns[name] = conn
    return conn


def _to_relative_satellite_path(db_path: str) -> str:
    """Convert an absolute satellite path to relative (relative to AIBRAIN_ROOT).

    If already relative or not under AIBRAIN_ROOT, returns as-is.
    """
    p = Path(db_path)
    if not p.is_absolute():
        return db_path
    try:
        return str(p.relative_to(AIBRAIN_ROOT))
    except ValueError:
        # Not under AIBRAIN_ROOT — store as-is (absolute)
        return db_path


def _to_absolute_satellite_path(db_path: str) -> str:
    """Resolve a satellite path to absolute (relative to AIBRAIN_ROOT).

    If already absolute, returns as-is.
    """
    if os.path.isabs(db_path):
        return db_path
    return str(AIBRAIN_ROOT / db_path)


def satellite_register(name: str, db_path: str, description: str = "",
                       memory_types: list = None, search_keywords: str = "") -> int:
    """Register a new satellite database.

    Args:
        name: Unique name (e.g., 'security_findings', 'benchmark_results')
        db_path: Path to .db file (relative to AIBRAIN_ROOT or absolute).
                 Absolute paths under AIBRAIN_ROOT are converted to relative
                 for portability across machines (brain sync).
        description: What this satellite stores
        memory_types: List of memory types routed to this DB (e.g., ['finding'])
        search_keywords: Comma-separated keywords that trigger federated search
    """
    try:
        from aibrain_licensing import check_limit
        check_limit("satellite_dbs")
    except ImportError:
        pass

    # Store relative path for portability across machines
    stored_path = _to_relative_satellite_path(db_path)

    db = get_db()
    db.execute("""
        INSERT OR REPLACE INTO satellite_dbs (name, db_path, description, memory_types, search_keywords, active)
        VALUES (?, ?, ?, ?, ?, 1)
    """, (name, stored_path, description, json.dumps(memory_types or []), search_keywords))
    db.commit()
    # Initialize the satellite DB schema
    _get_satellite_db(name)
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


def satellite_list() -> list:
    """List all registered satellite databases."""
    db = get_db()
    try:
        rows = db.execute("SELECT * FROM satellite_dbs WHERE active=1").fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


def satellite_search(name: str, query: str, limit=20) -> list:
    """Search a specific satellite database using hybrid FTS + vector similarity.

    Falls back to FTS-only when embeddings are unavailable.
    """
    sat_db = _get_satellite_db(name)

    # FTS results
    fts_results = []
    try:
        fts_results = [dict(r) for r in sat_db.execute("""
            SELECT m.*, rank AS fts_score
            FROM memories m
            JOIN memories_fts f ON m.id=f.rowid
            WHERE memories_fts MATCH ? AND m.active=1
            ORDER BY rank
            LIMIT ?
        """, (_sanitize_fts5(query), limit)).fetchall()]
    except Exception:
        pass

    # Vector results (semantic search)
    vec_results = []
    if _db_vec_enabled:
        try:
            query_emb = _compute_embedding(query)
            if query_emb is not None:
                emb_bytes = struct.pack(f"{len(query_emb)}f", *query_emb)
                rows = sat_db.execute(
                    "SELECT v.memory_id, v.distance FROM memories_vec v "
                    "WHERE v.embedding MATCH ? AND k = ?",
                    (emb_bytes, limit),
                ).fetchall()
                for row in rows:
                    mem = sat_db.execute(
                        "SELECT * FROM memories WHERE id=? AND active=1", (row[0],)
                    ).fetchone()
                    if mem:
                        d = dict(mem)
                        d["vec_distance"] = row[1]
                        vec_results.append(d)
        except Exception:
            pass  # vec table missing or query failed — use FTS only

    # Fuse results with RRF if both sources returned results
    if fts_results and vec_results:
        return _rrf_fuse([fts_results, vec_results], k=60, weights=[1.0, 1.2])[:limit]
    return (fts_results or vec_results)[:limit]


def satellite_stats(name: str) -> dict:
    """Get stats for a satellite database."""
    sat_db = _get_satellite_db(name)
    s = {"total": 0, "by_type": {}}
    for row in sat_db.execute("SELECT type, COUNT(*) as c FROM memories WHERE active=1 GROUP BY type"):
        s["by_type"][row["type"]] = row["c"]
        s["total"] += row["c"]
    try:
        db_path = get_db().execute(
            "SELECT db_path FROM satellite_dbs WHERE name=?", (name,)
        ).fetchone()["db_path"]
        if not os.path.isabs(db_path):
            db_path = str(AIBRAIN_ROOT / db_path)
        s["db_size_kb"] = round(Path(db_path).stat().st_size / 1024)
    except Exception:
        pass
    return s


def backfill_embeddings(batch_size: int = 500) -> dict:
    """Backfill embeddings for main DB memories that don't have them yet.

    Returns stats: {'total_active': N, 'missing_before': M, 'embedded': E, 'skipped': S}.
    """
    if not _db_vec_enabled:
        return {"total_active": 0, "missing_before": 0, "embedded": 0, "skipped": 0,
                "error": "embeddings not available"}

    db = get_db()
    total_active = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]

    # Find active memories without embeddings
    rows = db.execute("""
        SELECT m.id, m.name, m.content FROM memories m
        WHERE m.active=1
        AND m.id NOT IN (SELECT rowid FROM memories_vec_rowids)
        LIMIT ?
    """, (batch_size,)).fetchall()

    missing_before = len(rows)
    embedded = 0
    skipped = 0
    for row in rows:
        try:
            embed_text = f"{row['name']} {row['content']}" if row['name'] else row['content']
            emb = _compute_embedding(embed_text)
            if emb is not None:
                emb_bytes = struct.pack(f"{len(emb)}f", *emb)
                db.execute(
                    "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                    (row['id'], emb_bytes),
                )
                embedded += 1
            else:
                skipped += 1
        except Exception:
            skipped += 1
    db.commit()

    return {"total_active": total_active, "missing_before": missing_before,
            "embedded": embedded, "skipped": skipped}


def satellite_backfill_embeddings(name: str, batch_size: int = 100) -> dict:
    """Backfill embeddings for satellite memories that don't have them yet.

    Call after enabling embeddings on an existing satellite.
    Returns stats: {'total': N, 'embedded': M, 'skipped': S}.
    """
    if not _db_vec_enabled:
        return {"total": 0, "embedded": 0, "skipped": 0, "error": "embeddings not available"}

    sat_db = _get_satellite_db(name)

    # Check if vec table exists
    try:
        sat_db.execute("SELECT COUNT(*) FROM memories_vec").fetchone()
    except Exception:
        return {"total": 0, "embedded": 0, "skipped": 0, "error": "memories_vec table missing"}

    # Find memories without embeddings
    try:
        rows = sat_db.execute("""
            SELECT m.id, m.name, m.content FROM memories m
            WHERE m.active=1
            AND m.id NOT IN (SELECT memory_id FROM memories_vec)
            LIMIT ?
        """, (batch_size,)).fetchall()
    except Exception:
        rows = []

    embedded = 0
    skipped = 0
    for row in rows:
        try:
            embed_text = f"{row['name']} {row['content']}" if row['name'] else row['content']
            emb = _compute_embedding(embed_text)
            if emb is not None:
                emb_bytes = struct.pack(f"{len(emb)}f", *emb)
                sat_db.execute(
                    "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                    (row['id'], emb_bytes),
                )
                embedded += 1
            else:
                skipped += 1
        except Exception:
            skipped += 1
    sat_db.commit()

    total = sat_db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
    return {"total": total, "embedded": embedded, "skipped": skipped}


def federated_search(query: str, limit=20) -> dict:
    """Search main DB + all relevant satellite DBs based on query keywords.

    Returns dict with 'main' results and per-satellite results.
    Satellites are searched when query matches their search_keywords.
    """
    results = {"main": search_memories(query, limit=limit, exclude_satellites=True)}

    for sat in satellite_list():
        keywords = [k.strip().lower() for k in sat.get("search_keywords", "").split(",") if k.strip()]
        query_lower = query.lower()
        # Search satellite if query matches any keyword, or if explicitly requested
        if any(kw in query_lower for kw in keywords) or not keywords:
            try:
                sat_results = satellite_search(sat["name"], query, limit=limit)
                if sat_results:
                    results[sat["name"]] = sat_results
            except Exception:
                pass

    results["total"] = sum(
        len(v) for v in results.values() if isinstance(v, list)
    )
    return results


def migrate_to_satellite(satellite_name: str, type_filter: str = "finding",
                         batch_size: int = 5000) -> dict:
    """Move memories of a specific type from main DB to a satellite DB.

    Returns stats about the migration.
    """
    main_db = get_db()
    sat_db = _get_satellite_db(satellite_name)

    # Count what we're moving
    total = main_db.execute(
        "SELECT COUNT(*) FROM memories WHERE type=? AND active=1", (type_filter,)
    ).fetchone()[0]

    if total == 0:
        return {"moved": 0, "total": total, "message": "No memories to migrate"}

    moved = 0
    skipped = 0
    while True:
        rows = main_db.execute("""
            SELECT * FROM memories WHERE type=? AND active=1 LIMIT ?
        """, (type_filter, batch_size)).fetchall()

        if not rows:
            break

        # Get satellite DB column names
        sat_cols = {r[1] for r in sat_db.execute("PRAGMA table_info(memories)").fetchall()}

        for row in rows:
            r = dict(row)
            mid = r.pop("id")
            # Only insert columns that exist in satellite schema
            filtered = {k: v for k, v in r.items() if k in sat_cols}
            cols = ", ".join(filtered.keys())
            placeholders = ", ".join(["?"] * len(filtered))
            # Skip if already exists in satellite (dedup on content hash)
            if "content" in filtered:
                exists = sat_db.execute(
                    "SELECT 1 FROM memories WHERE content=? LIMIT 1",
                    (filtered["content"],)
                ).fetchone()
                if exists:
                    # Already migrated — just deactivate in main
                    main_db.execute("UPDATE memories SET active=0 WHERE id=?", (mid,))
                    skipped += 1
                    continue
            # Validate column names against known memory columns
            SAFE_MEMORY_COLS = frozenset({
                "id", "name", "type", "tags", "content", "created", "updated",
                "active", "memory_class", "importance", "access_count",
                "last_accessed", "source", "embedding",
            })
            safe_filtered = {k: v for k, v in filtered.items() if k in SAFE_MEMORY_COLS}
            cols = ", ".join(safe_filtered.keys())
            placeholders = ", ".join(["?"] * len(safe_filtered))
            sql = "INSERT INTO memories (" + cols + ") VALUES (" + placeholders + ")"
            sat_db.execute(sql, list(safe_filtered.values()))
            # Soft-delete from main (keeps ID for hyperedge refs)
            main_db.execute("UPDATE memories SET active=0 WHERE id=?", (mid,))
            moved += 1

        sat_db.commit()
        main_db.commit()
        print(f"  Migrated {moved}/{total} (skipped {skipped} dupes)...")

    return {"moved": moved, "skipped": skipped, "total": total, "satellite": satellite_name}


def dedup_satellite(satellite_name: str) -> dict:
    """Remove duplicate records from a satellite DB, keeping the earliest copy."""
    sat_db = _get_satellite_db(satellite_name)

    # Find duplicates by content
    dupes = sat_db.execute("""
        SELECT content, COUNT(*) as cnt, MIN(id) as keep_id
        FROM memories
        WHERE active=1
        GROUP BY content
        HAVING cnt > 1
    """).fetchall()

    removed = 0
    for row in dupes:
        content, cnt, keep_id = row
        sat_db.execute(
            "DELETE FROM memories WHERE content=? AND id != ?",
            (content, keep_id)
        )
        removed += cnt - 1

    sat_db.commit()

    remaining = sat_db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
    print(f"  Removed {removed} duplicates from {satellite_name}. {remaining} records remain.")
    return {"removed": removed, "remaining": remaining, "satellite": satellite_name}


# Satellite templates for natural language creation
SATELLITE_TEMPLATES = {
    "security": {
        "name": "security_findings",
        "db_path": "security_findings.db",
        "types": ["finding"],
        "keywords": "finding,findings,vuln,vulnerability,cve,scan,exploit,pentest,security,attack",
        "desc": "Vulnerability scans, pentest findings, CVEs",
        "triggers": ["security", "vuln", "finding", "scan", "pentest", "cve", "exploit",
                      "attack", "injection", "xss", "sqli", "owasp"],
    },
    "research": {
        "name": "research_papers",
        "db_path": "research_papers.db",
        "types": ["paper", "citation"],
        "keywords": "paper,arxiv,citation,doi,journal,abstract,literature,review",
        "desc": "Research papers, citations, literature reviews",
        "triggers": ["research", "paper", "arxiv", "citation", "academic", "journal",
                      "literature", "publication", "doi"],
    },
    "benchmarks": {
        "name": "benchmark_results",
        "db_path": "benchmark_results.db",
        "types": ["benchmark", "evaluation"],
        "keywords": "benchmark,recall,precision,accuracy,eval,f1,experiment,score,metric",
        "desc": "ML benchmarks, evaluation scores, experiment results",
        "triggers": ["benchmark", "eval", "experiment", "score", "metric", "accuracy",
                      "recall", "precision", "f1", "test result"],
    },
    "logs": {
        "name": "system_logs",
        "db_path": "system_logs.db",
        "types": ["log", "trace"],
        "keywords": "log,trace,error,crash,stacktrace,debug,incident",
        "desc": "System logs, error traces, incident reports",
        "triggers": ["log", "trace", "error", "crash", "stacktrace", "debug",
                      "incident", "monitoring"],
    },
    "trading": {
        "name": "trading_data",
        "db_path": "trading_data.db",
        "types": ["trade", "signal"],
        "keywords": "trade,signal,position,pnl,profit,loss,order,market,edge",
        "desc": "Trading signals, positions, P&L records",
        "triggers": ["trade", "trading", "position", "pnl", "profit", "signal",
                      "market", "order", "portfolio"],
    },
    "notes": {
        "name": "notes_archive",
        "db_path": "notes_archive.db",
        "types": ["note", "journal"],
        "keywords": "note,journal,diary,thought,idea,reflection",
        "desc": "Personal notes, journal entries, ideas",
        "triggers": ["note", "journal", "diary", "thought", "idea", "reflection",
                      "writing"],
    },
    "training": {
        "name": "training_pairs",
        "db_path": "training_pairs.db",
        "types": ["training-pair"],
        "keywords": "training,pair,instruction,response,finetune,dataset,curated,playbook,lesson",
        "desc": "Curated training pairs (instruction/response data)",
        "triggers": ["training", "pair", "instruction", "finetune", "dataset",
                      "curated", "playbook", "lesson", "teach"],
    },
}


def satellite_suggest_from_text(text: str) -> list:
    """Match natural language description to satellite templates.

    Args:
        text: Natural language like "I have lots of security scan results"

    Returns:
        List of matching template dicts, best match first.
    """
    text_lower = text.lower()
    scored = []
    for key, tmpl in SATELLITE_TEMPLATES.items():
        hits = sum(1 for t in tmpl["triggers"] if t in text_lower)
        if hits > 0:
            scored.append((hits, key, tmpl))
    scored.sort(reverse=True)
    return [(key, tmpl) for _, key, tmpl in scored]


def satellite_create_from_text(text: str) -> dict | None:
    """Create a satellite DB from a natural language description.

    Args:
        text: e.g. "I have thousands of security scan results"

    Returns:
        Dict with created satellite info, or None if no match.
    """
    matches = satellite_suggest_from_text(text)
    if not matches:
        return None

    key, tmpl = matches[0]

    # Check if already registered
    existing = {s["name"] for s in satellite_list()}
    if tmpl["name"] in existing:
        return {"name": tmpl["name"], "status": "already_exists",
                "message": f"Satellite '{tmpl['name']}' already registered"}

    sid = satellite_register(
        name=tmpl["name"],
        db_path=tmpl["db_path"],
        description=tmpl["desc"],
        memory_types=tmpl["types"],
        search_keywords=tmpl["keywords"],
    )
    return {
        "name": tmpl["name"],
        "id": sid,
        "status": "created",
        "db_path": tmpl["db_path"],
        "types": tmpl["types"],
        "keywords": tmpl["keywords"],
        "description": tmpl["desc"],
    }


# Threshold for auto-suggesting satellite DBs
SATELLITE_SUGGEST_THRESHOLD = 5000


def satellite_health_check() -> dict | None:
    """Check if main DB is getting large and suggest satellite splits.

    Called by workflows, hooks, or CLI. Returns suggestion dict if main DB
    exceeds threshold and has obvious candidates for splitting, else None.

    Returns:
        Dict with suggestion details, or None if no action needed.
    """
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]

    if total < SATELLITE_SUGGEST_THRESHOLD:
        return None

    # Get type distribution
    type_counts = {}
    for row in db.execute(
        "SELECT type, COUNT(*) as c FROM memories WHERE active=1 GROUP BY type ORDER BY c DESC"
    ):
        type_counts[row["type"]] = row["c"]

    # Already-satellite types
    existing_sat_types = set(_get_satellite_types())

    # Find types that are heavy and could be satellites
    suggestions = []
    for mem_type, count in type_counts.items():
        if mem_type in existing_sat_types:
            continue
        # Suggest if a single type is >20% of total or >1000 memories
        if count > total * 0.2 or count > 1000:
            # Try to match to a template
            template_match = None
            for key, tmpl in SATELLITE_TEMPLATES.items():
                if mem_type in tmpl["types"]:
                    template_match = tmpl
                    break

            suggestions.append({
                "type": mem_type,
                "count": count,
                "pct": round(count / total * 100, 1),
                "template": template_match,
            })

    if not suggestions:
        return None

    return {
        "total_memories": total,
        "threshold": SATELLITE_SUGGEST_THRESHOLD,
        "suggestions": suggestions,
        "message": (
            f"Your main memory DB has {total} memories. "
            f"Consider moving {len(suggestions)} heavy type(s) to satellite DBs "
            f"for faster everyday retrieval."
        ),
    }


def satellite_apply_suggestion(suggestion: dict) -> dict:
    """Apply a satellite health check suggestion — create satellite and migrate.

    Args:
        suggestion: One item from satellite_health_check()['suggestions']

    Returns:
        Migration stats dict.
    """
    mem_type = suggestion["type"]
    tmpl = suggestion.get("template")

    if tmpl:
        name = tmpl["name"]
        db_path = tmpl["db_path"]
        keywords = tmpl["keywords"]
        desc = tmpl["desc"]
    else:
        # No template match — create a generic one
        name = f"{mem_type}_archive"
        db_path = f"{mem_type}_archive.db"
        keywords = mem_type
        desc = f"Archived {mem_type} memories"

    # Register if not exists
    existing = {s["name"] for s in satellite_list()}
    if name not in existing:
        satellite_register(name, db_path, desc, [mem_type], keywords)

    # Migrate
    stats = migrate_to_satellite(name, mem_type)
    return stats


# ---------------------------------------------------------------------------
# Hyperedge helpers (HGMem — multi-hop relational memory)
# ---------------------------------------------------------------------------

def hyperedge_create(label: str, memory_ids: list, roles=None,
                     confidence=1.0, metadata=None) -> int:
    """Create a hyperedge linking multiple memories.

    Args:
        label: Relationship label (e.g., "caused_by", "related_to", "prerequisite").
        memory_ids: List of memory IDs to link (must contain at least 2).
        roles: Optional list of roles parallel to memory_ids (e.g., ["source", "target"]).
               Defaults to "member" for all.
        confidence: Edge confidence score (0.0 to 1.0).
        metadata: Optional dict of extra metadata.

    Returns:
        The new hyperedge ID.
    """
    if len(memory_ids) < 2:
        raise ValueError("Hyperedge must link at least 2 memories")
    if roles and len(roles) != len(memory_ids):
        raise ValueError("roles length must match memory_ids length")

    db = get_db()
    meta_str = json.dumps(metadata) if metadata else "{}"
    db.execute(
        "INSERT INTO hyperedges (label, confidence, metadata) VALUES (?, ?, ?)",
        (label, confidence, meta_str)
    )
    edge_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    for i, mid in enumerate(memory_ids):
        role = roles[i] if roles else "member"
        db.execute(
            "INSERT INTO hyperedge_members (hyperedge_id, memory_id, role) VALUES (?, ?, ?)",
            (edge_id, mid, role)
        )
    db.commit()
    return edge_id


def hyperedge_search(memory_id: int) -> list:
    """Find all hyperedges containing a given memory, return connected memories.

    Returns a list of dicts, each representing a hyperedge with its members:
        [{"edge_id": 1, "label": "caused_by", "confidence": 0.9,
          "metadata": {...}, "members": [{"memory_id": 5, "role": "source", "name": "..."},  ...]}]
    """
    db = get_db()
    # Find all hyperedges this memory belongs to
    edges = db.execute("""
        SELECT h.id, h.label, h.confidence, h.metadata, h.created_at
        FROM hyperedges h
        JOIN hyperedge_members hm ON h.id = hm.hyperedge_id
        WHERE hm.memory_id = ?
    """, (memory_id,)).fetchall()

    results = []
    for e in edges:
        edge = dict(e)
        edge["edge_id"] = edge.pop("id")
        try:
            edge["metadata"] = json.loads(edge["metadata"])
        except (json.JSONDecodeError, ValueError):
            pass
        # Get all members of this hyperedge
        members = db.execute("""
            SELECT hm.memory_id, hm.role, m.name, m.type, m.content
            FROM hyperedge_members hm
            JOIN memories m ON m.id = hm.memory_id
            WHERE hm.hyperedge_id = ? AND m.active = 1
        """, (edge["edge_id"],)).fetchall()
        edge["members"] = [dict(m) for m in members]
        results.append(edge)
    return results


def hyperedge_traverse(memory_id: int, depth=2) -> list:
    """Multi-hop traversal: follow hyperedges up to N hops from a starting memory.

    Returns all reachable memories with path info:
        [{"memory_id": 5, "name": "...", "hop": 1, "path": [{"edge_id": 1, "label": "caused_by"}]}, ...]
    """
    if depth < 1:
        return []

    db = get_db()
    visited = {memory_id}
    # Each entry: (memory_id, hop_number, path_so_far)
    frontier = [(memory_id, 0, [])]
    results = []

    while frontier:
        current_id, current_hop, current_path = frontier.pop(0)
        if current_hop >= depth:
            continue

        # Find all hyperedges this memory belongs to
        edges = db.execute("""
            SELECT h.id, h.label
            FROM hyperedges h
            JOIN hyperedge_members hm ON h.id = hm.hyperedge_id
            WHERE hm.memory_id = ?
        """, (current_id,)).fetchall()

        for edge in edges:
            edge_info = {"edge_id": edge["id"], "label": edge["label"]}
            # Get all other members of this hyperedge
            neighbors = db.execute("""
                SELECT hm.memory_id, hm.role, m.name, m.type
                FROM hyperedge_members hm
                JOIN memories m ON m.id = hm.memory_id
                WHERE hm.hyperedge_id = ? AND hm.memory_id != ? AND m.active = 1
            """, (edge["id"], current_id)).fetchall()

            for nb in neighbors:
                nb_id = nb["memory_id"]
                if nb_id in visited:
                    continue
                visited.add(nb_id)
                new_path = current_path + [edge_info]
                results.append({
                    "memory_id": nb_id,
                    "name": nb["name"],
                    "type": nb["type"],
                    "role": nb["role"],
                    "hop": current_hop + 1,
                    "path": new_path,
                })
                frontier.append((nb_id, current_hop + 1, new_path))

    return results


# ---------------------------------------------------------------------------
# Skills helpers
# ---------------------------------------------------------------------------

def list_skills(category=None) -> list:
    db = get_db()
    sql = "SELECT * FROM skills WHERE installed=1"
    params = []
    if category:
        sql += " AND category=?"
        params.append(category)
    sql += " ORDER BY category, name"
    return [dict(r) for r in db.execute(sql, params).fetchall()]


def get_skill(name: str) -> dict | None:
    db = get_db()
    row = db.execute("SELECT * FROM skills WHERE name=?", (name,)).fetchone()
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# Applications helpers
# ---------------------------------------------------------------------------

def list_applications(status=None, platform=None, limit=100) -> list:
    db = get_db()
    sql = "SELECT * FROM applications WHERE 1=1"
    params = []
    if status:
        sql += " AND status=?"
        params.append(status)
    if platform:
        sql += " AND platform=?"
        params.append(platform)
    sql += " ORDER BY date_applied DESC LIMIT ?"
    params.append(limit)
    return [dict(r) for r in db.execute(sql, params).fetchall()]


def get_application(app_id: int) -> dict | None:
    db = get_db()
    row = db.execute("SELECT * FROM applications WHERE id=?", (app_id,)).fetchone()
    return dict(row) if row else None


def create_application(company: str, role: str, **kwargs) -> int:
    db = get_db()
    db.execute("""
        INSERT OR IGNORE INTO applications
        (company, role, location, salary, status, platform, portal_url, job_id, credentials, date_applied, notes, tags)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        company, role,
        kwargs.get("location", ""), kwargs.get("salary", ""),
        kwargs.get("status", "applied"), kwargs.get("platform", ""),
        kwargs.get("portal_url", ""), kwargs.get("job_id", ""),
        kwargs.get("credentials", ""), kwargs.get("date_applied", ""),
        kwargs.get("notes", ""), kwargs.get("tags", ""),
    ))
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


def update_application(app_id: int, **kwargs) -> bool:
    ALLOWED_COLUMNS = frozenset({
        "company", "role", "location", "salary", "status", "platform",
        "portal_url", "job_id", "credentials", "date_applied", "notes", "tags",
    })
    db = get_db()
    sets, vals = [], []
    for key in ALLOWED_COLUMNS:
        if key in kwargs:
            sets.append(key + "=?")
            vals.append(kwargs[key])
    if not sets:
        return False
    sets.append("updated_at=datetime('now')")
    vals.append(app_id)
    sql = "UPDATE applications SET " + ", ".join(sets) + " WHERE id=?"
    db.execute(sql, vals)
    db.commit()
    return True


# ---------------------------------------------------------------------------
# Export / Import (for frontend backup/restore)
# ---------------------------------------------------------------------------

def export_all() -> dict:
    """Export all data for backup."""
    return {
        "memories": list_memories(limit=10000),
        "workflows": list_workflows(),
        "scheduled_jobs": list_scheduled_jobs(),
        "applications": list_applications(limit=10000),
        "approvals": list_approvals(limit=10000),
        "activity": list_activity(limit=10000),
        "skills": list_skills(),
        "config": {r["key"]: r["value"] for r in get_db().execute("SELECT key, value FROM config").fetchall()},
    }


def import_memories_and_crons(memories: list, crons: list) -> dict:
    """Import memories and crons from backup."""
    db = get_db()
    mem_count = 0
    for m in memories:
        db.execute("""
            INSERT OR IGNORE INTO memories (name, type, tags, content, created, updated, active)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (m["name"], m["type"], m.get("tags", ""), m["content"],
              m.get("created", datetime.now(timezone.utc).isoformat()),
              m.get("updated", datetime.now(timezone.utc).isoformat()),
              m.get("active", 1)))
        mem_count += 1
    cron_count = 0
    for c in crons:
        db.execute("""
            INSERT OR REPLACE INTO scheduled_jobs (name, cron, prompt, enabled, notes)
            VALUES (?, ?, ?, ?, ?)
        """, (c["name"], c["cron"], c["prompt"], c.get("enabled", 1),
              c.get("notes", "")))
        cron_count += 1
    db.commit()
    return {"memories_imported": mem_count, "crons_imported": cron_count}


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

def summary() -> dict:
    db = get_db()
    s = {}
    # Hardcoded allowlist — never interpolate user input into SQL
    _ALLOWED_TABLES = frozenset({"memories", "workflows", "scheduled_jobs", "applications",
                                  "app_emails", "approvals", "activity", "costs", "traces",
                                  "webhook_history", "skills", "config"})
    for table in _ALLOWED_TABLES:
        try:
            # table names can't be parameterized in SQLite, so we validate
            # against the allowlist above before interpolating
            s[table] = db.execute("SELECT COUNT(*) FROM [" + table + "]").fetchone()[0]  # table validated by _ALLOWED_TABLES frozenset above
        except (sqlite3.OperationalError, sqlite3.IntegrityError):
            s[table] = 0

    s["workflows_enabled"] = db.execute("SELECT COUNT(*) FROM workflows WHERE enabled=1").fetchone()[0]
    s["jobs_enabled"] = db.execute("SELECT COUNT(*) FROM scheduled_jobs WHERE enabled=1").fetchone()[0]
    s["approvals_pending"] = db.execute("SELECT COUNT(*) FROM approvals WHERE status='pending'").fetchone()[0]
    s["apps_by_status"] = {}
    for row in db.execute("SELECT status, COUNT(*) as c FROM applications GROUP BY status"):
        s["apps_by_status"][row["status"]] = row["c"]
    s["db_path"] = str(DB_PATH)
    s["db_size_kb"] = round(DB_PATH.stat().st_size / 1024, 1) if DB_PATH.exists() else 0
    return s


# ---------------------------------------------------------------------------
# Brain Export / Import / Merge / Stats
# ---------------------------------------------------------------------------

def brain_export(output_path=None) -> str:
    """Export knowledge tables to a portable JSON file."""
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    agent_name = config_get("agent_name", "unknown")

    # Memories (active only) — stamp origin agent into tags for provenance
    memories = []
    for r in db.execute("SELECT * FROM memories WHERE active=1").fetchall():
        m = dict(r)
        tags = m.get("tags", "") or ""
        # Ensure origin tag is present so merged brains can distinguish sources
        origin_tag = f"origin:{agent_name}"
        if origin_tag not in tags:
            m["tags"] = f"{tags},{origin_tag}" if tags else origin_tag
        memories.append(m)

    # Entity links
    entities = []
    try:
        entities = [dict(r) for r in db.execute("SELECT * FROM entity_links").fetchall()]
    except sqlite3.OperationalError:
        pass

    # Semantic facts
    facts = []
    try:
        facts = [dict(r) for r in db.execute("SELECT * FROM semantic_facts").fetchall()]
    except sqlite3.OperationalError:
        pass

    # Memory passages
    passages = []
    try:
        passages = [dict(r) for r in db.execute("SELECT * FROM memory_passages").fetchall()]
    except sqlite3.OperationalError:
        pass

    # Evolution patterns
    patterns = []
    try:
        patterns = [dict(r) for r in db.execute("SELECT * FROM evolution_patterns").fetchall()]
    except sqlite3.OperationalError:
        pass

    export_data = {
        "metadata": {
            "export_date": now,
            "agent_name": agent_name,
            "memory_count": len(memories),
            "entity_count": len(entities),
            "fact_count": len(facts),
            "passage_count": len(passages),
            "pattern_count": len(patterns),
        },
        "memories": memories,
        "entities": entities,
        "facts": facts,
        "passages": passages,
        "patterns": patterns,
    }

    if output_path:
        out = Path(output_path)
    else:
        out = AIBRAIN_ROOT / "brain_export.json"
    out.write_text(json.dumps(export_data, indent=2, default=str), encoding="utf-8")
    return str(out.resolve())


def brain_export_redacted(output_path=None) -> str:
    """Export a credential-scrubbed brain suitable for git/public sharing.

    Strips passwords, tokens, API keys, and other secrets from all text
    fields before writing.  Safe to commit — uses brain_sync_*.json naming
    so .gitignore rules never block it.
    """
    import re as _re

    # ── Patterns that indicate credential content ─────────────────────────
    # Each tuple: (compiled_regex, replacement_string)
    _CRED_PATTERNS = [
        # Explicit password table rows  |  admin | Password1 | ...
        (_re.compile(r'(\|\s*\S+\s*\|\s*)([^\|]{4,60})(\s*\|\s*(admin|manager|user|internal|api|service|root|staff)\s*\|)',
                     _re.IGNORECASE), r'\1[REDACTED]\3'),
        # password/token/secret/key assignments: "field": "value" or field=value
        (_re.compile(r'("(?:password|passwd|token|secret|api_key|apikey|access_key|private_key|auth_token|bearer|credential)"\s*:\s*")[^"]{3,}(")',
                     _re.IGNORECASE), r'\1[REDACTED]\2'),
        (_re.compile(r'((?:password|passwd|token|secret|api_key|apikey|access_key|private_key|auth_token)\s*=\s*)[\'"][^\'"]{3,}[\'"]',
                     _re.IGNORECASE), r'\1"[REDACTED]"'),
        # High-entropy password-looking strings (uppercase + digits + special, 8+)
        (_re.compile(r'\b([A-Z][a-z]+[0-9]+[!@#$%^&*_\-]{1,3}[A-Za-z0-9]{2,})\b'), '[REDACTED]'),
        (_re.compile(r'\b([A-Za-z0-9]{3,}[!@#$%^&*]{1,2}[A-Za-z0-9!@#$%^&*_\-]{4,})\b'), '[REDACTED]'),
        # GitHub / OAuth tokens
        (_re.compile(r'\bgh[oprsu]_[A-Za-z0-9]{20,}\b'), '[REDACTED_TOKEN]'),
        (_re.compile(r'\bey[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{20,}\b'), '[REDACTED_JWT]'),
        # Environment-specific credential patterns (add your own below)
        # (_re.compile(r'YourPattern'), '[REDACTED]'),
    ]

    def _scrub(text: str) -> str:
        if not isinstance(text, str):
            return text
        for pat, repl in _CRED_PATTERNS:
            text = pat.sub(repl, text)
        return text

    def _scrub_record(record: dict) -> dict:
        """Return a shallow copy of record with all string fields scrubbed."""
        return {k: _scrub(v) if isinstance(v, str) else v for k, v in record.items()}

    # ── Run full export then scrub every text field ───────────────────────
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    agent_name = config_get("agent_name", "unknown")

    memories = []
    for r in db.execute("SELECT * FROM memories WHERE active=1").fetchall():
        m = dict(r)
        tags = m.get("tags", "") or ""
        origin_tag = f"origin:{agent_name}"
        if origin_tag not in tags:
            m["tags"] = f"{tags},{origin_tag}" if tags else origin_tag
        memories.append(_scrub_record(m))

    entities = []
    try:
        entities = [_scrub_record(dict(r)) for r in db.execute("SELECT * FROM entity_links").fetchall()]
    except Exception:
        pass

    facts = []
    try:
        facts = [_scrub_record(dict(r)) for r in db.execute("SELECT * FROM semantic_facts").fetchall()]
    except Exception:
        pass

    passages = []
    try:
        passages = [_scrub_record(dict(r)) for r in db.execute("SELECT * FROM memory_passages").fetchall()]
    except Exception:
        pass

    patterns = []
    try:
        patterns = [_scrub_record(dict(r)) for r in db.execute("SELECT * FROM evolution_patterns").fetchall()]
    except Exception:
        pass

    # ── Helper: safe table dump with scrubbing ────────────────────────────
    # Whitelist of allowed table names to prevent SQL injection
    _SYNC_TABLES = frozenset({  # noqa:sql-fstring
        "companies", "company_agents", "company_issues", "company_goals",
        "company_projects", "skills", "skill_executions", "workflows",
        "evolution_outcomes", "evolution_metrics", "evolution_cycles",
        "entities", "category_summaries", "approvals", "agent_permissions",
        "scheduled_jobs",
    })

    def _dump_table(table_name: str) -> list:
        if table_name not in _SYNC_TABLES:
            return []
        try:
            # table_name is validated against frozen whitelist above  # noqa:sql-fstring
            return [_scrub_record(dict(r)) for r in db.execute(
                "SELECT * FROM " + table_name  # noqa:sql-fstring
            ).fetchall()]
        except Exception:
            return []

    # ── New tables for full brain sync ────────────────────────────────────
    companies = _dump_table("companies")
    company_agents = _dump_table("company_agents")
    company_issues = _dump_table("company_issues")
    company_goals = _dump_table("company_goals")
    company_projects = _dump_table("company_projects")
    skills = _dump_table("skills")
    skill_executions = _dump_table("skill_executions")
    workflows = _dump_table("workflows")
    evolution_outcomes = _dump_table("evolution_outcomes")
    evolution_metrics = _dump_table("evolution_metrics")
    evolution_cycles = _dump_table("evolution_cycles")
    knowledge_entities = _dump_table("entities")
    category_summaries = _dump_table("category_summaries")
    approvals = _dump_table("approvals")
    agent_permissions = _dump_table("agent_permissions")
    scheduled_jobs = _dump_table("scheduled_jobs")

    # Config: scrub sensitive keys by replacing values with [REDACTED]
    config_rows = []
    try:
        for r in db.execute("SELECT * FROM config").fetchall():
            row = dict(r)
            if row.get("key") in _SENSITIVE_CONFIG_KEYS:
                row["value"] = "[REDACTED]"
            else:
                row = _scrub_record(row)
            config_rows.append(row)
    except Exception:
        pass

    # Satellite DBs: convert absolute paths to relative
    satellite_dbs = []
    try:
        _aibrain_root = str(Path(__file__).parent.resolve())
        for r in db.execute("SELECT * FROM satellite_dbs").fetchall():
            row = _scrub_record(dict(r))
            db_path = row.get("db_path", "")
            if db_path and os.path.isabs(db_path):
                try:
                    row["db_path"] = os.path.relpath(db_path, _aibrain_root)
                except ValueError:
                    pass  # different drive on Windows — keep as-is
            satellite_dbs.append(row)
    except Exception:
        pass

    export_data = {
        "metadata": {
            "export_date": now,
            "agent_name": agent_name,
            "redacted": True,
            "sync_version": 2,
            "memory_count": len(memories),
            "entity_count": len(entities),
            "fact_count": len(facts),
            "passage_count": len(passages),
            "pattern_count": len(patterns),
            "companies_count": len(companies),
            "company_agents_count": len(company_agents),
            "company_issues_count": len(company_issues),
            "company_goals_count": len(company_goals),
            "company_projects_count": len(company_projects),
            "skills_count": len(skills),
            "skill_executions_count": len(skill_executions),
            "workflows_count": len(workflows),
            "config_count": len(config_rows),
            "satellite_dbs_count": len(satellite_dbs),
            "evolution_outcomes_count": len(evolution_outcomes),
            "evolution_metrics_count": len(evolution_metrics),
            "evolution_cycles_count": len(evolution_cycles),
            "knowledge_entities_count": len(knowledge_entities),
            "category_summaries_count": len(category_summaries),
            "approvals_count": len(approvals),
            "agent_permissions_count": len(agent_permissions),
            "scheduled_jobs_count": len(scheduled_jobs),
        },
        "memories": memories,
        "entities": entities,
        "facts": facts,
        "passages": passages,
        "patterns": patterns,
        # New tables (sync_version 2)
        "companies": companies,
        "company_agents": company_agents,
        "company_issues": company_issues,
        "company_goals": company_goals,
        "company_projects": company_projects,
        "skills": skills,
        "skill_executions": skill_executions,
        "workflows": workflows,
        "config": config_rows,
        "satellite_dbs": satellite_dbs,
        "evolution_outcomes": evolution_outcomes,
        "evolution_metrics": evolution_metrics,
        "evolution_cycles": evolution_cycles,
        "knowledge_entities": knowledge_entities,
        "category_summaries": category_summaries,
        "approvals": approvals,
        "agent_permissions": agent_permissions,
        "scheduled_jobs": scheduled_jobs,
    }

    # Use brain_sync_ prefix so it IS tracked by git (.gitignore excludes brain_export_*)
    if output_path is None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        output_path = f"brain_sync_{agent_name}_{ts}.json"
    out = Path(output_path)
    out.write_text(json.dumps(export_data, indent=2, default=str), encoding="utf-8")
    return str(out.resolve())


def brain_import(input_path) -> dict:
    """Import another brain's knowledge from a JSON export file."""
    # Validate input path stays within home directory to prevent path traversal
    _import_path = Path(input_path).expanduser().resolve()
    try:
        _import_path.relative_to(Path.home().resolve())
    except ValueError:
        return {"error": "Import path must be within home directory", "imported": False}

    # ── Poisoning detection pre-check (warn but don't block) ──
    try:
        from aibrain.core.poisoning_detection import scan_import_summary
        poison_report = scan_import_summary(str(_import_path))
        if poison_report["total_findings"] > 0:
            import logging as _log
            _logger = _log.getLogger("aibrain.brain_import")
            _logger.warning(
                "Poisoning scan found %d issue(s) in %s: %s",
                poison_report["total_findings"],
                input_path,
                poison_report["by_type"],
            )
            if not poison_report["safe"]:
                _logger.warning(
                    "CRITICAL/HIGH findings detected — import proceeding but review recommended"
                )
    except Exception:
        pass  # Poisoning detection is advisory, never blocks import

    data = json.loads(_import_path.read_text(encoding="utf-8"))
    db = get_db()
    source_agent = data.get("metadata", {}).get("agent_name", "unknown")
    stats = {"memories_new": 0, "memories_skipped": 0,
             "entities_new": 0, "entities_skipped": 0,
             "facts_new": 0, "facts_skipped": 0,
             "passages_new": 0, "passages_skipped": 0,
             "patterns_new": 0, "patterns_skipped": 0,
             "companies_new": 0, "companies_skipped": 0,
             "company_agents_new": 0, "company_agents_replaced": 0, "company_agents_skipped": 0,
             "company_issues_new": 0, "company_issues_skipped": 0,
             "company_goals_new": 0, "company_goals_skipped": 0,
             "company_projects_new": 0, "company_projects_skipped": 0,
             "skills_new": 0, "skills_skipped": 0,
             "skill_executions_new": 0, "skill_executions_skipped": 0,
             "workflows_new": 0, "workflows_skipped": 0,
             "config_new": 0, "config_skipped": 0,
             "satellite_dbs_new": 0, "satellite_dbs_skipped": 0,
             "evolution_outcomes_new": 0, "evolution_outcomes_skipped": 0,
             "evolution_metrics_new": 0, "evolution_metrics_skipped": 0,
             "evolution_cycles_new": 0, "evolution_cycles_skipped": 0,
             "knowledge_entities_new": 0, "knowledge_entities_skipped": 0,
             "category_summaries_new": 0, "category_summaries_skipped": 0,
             "approvals_new": 0, "approvals_skipped": 0,
             "agent_permissions_new": 0, "agent_permissions_skipped": 0,
             "scheduled_jobs_new": 0, "scheduled_jobs_skipped": 0}

    # Track old source memory ID → new destination memory ID for passage remapping
    _memory_id_map: dict[int, int] = {}

    # Track old source TEXT IDs → new destination TEXT IDs to prevent cross-brain
    # collision on INSERT OR IGNORE (which silently drops data if IDs match).
    import secrets as _secrets
    _company_id_map: dict[str, str] = {}
    _agent_id_map: dict[str, str] = {}
    _issue_id_map: dict[str, str] = {}
    _goal_id_map: dict[str, str] = {}
    _project_id_map: dict[str, str] = {}

    def _remap_id(old_id: str | None, id_map: dict) -> str | None:
        """Get or create a new unique ID for an imported record."""
        if old_id is None:
            return None
        if old_id in id_map:
            return id_map[old_id]
        # Check if this ID already exists in the destination DB — if not, keep it
        return id_map.get(old_id, old_id)

    def _new_id(old_id: str | None, id_map: dict, table: str, db_conn,
                name_col: str = "name", name_val: str = None) -> str:
        """Remap an ID: reuse if no collision, generate new if collision with different data.

        If the existing row has the same name (same-brain re-import), map to the
        existing ID (dedup). If the name differs (cross-brain collision), generate
        a new ID to prevent silent data loss.
        """
        if old_id is None:
            new = _secrets.token_urlsafe(8)
            return new
        if old_id in id_map:
            return id_map[old_id]
        # Check for collision in destination DB
        existing = db_conn.execute(f"SELECT id, {name_col} FROM {table} WHERE id=?", (old_id,)).fetchone()  # noqa: S608
        if existing is None:
            # No collision — keep original ID
            id_map[old_id] = old_id
            return old_id
        # Collision exists — check if it's the same record (same-brain re-import)
        if name_val is not None and existing[name_col] == name_val:
            # Same record — map to existing, skip will happen at INSERT
            id_map[old_id] = old_id
            return old_id
        # Different record — cross-brain collision, generate new ID
        new = _secrets.token_urlsafe(8)
        id_map[old_id] = new
        return new

    # Import memories — deduplicate by name+type
    for m in data.get("memories", []):
        source_id = m.get("id")
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND type=?",
            (m["name"], m.get("type", "project"))
        ).fetchone()
        if existing:
            # Map source ID to existing destination ID so passages still attach correctly
            if source_id is not None:
                _memory_id_map[source_id] = existing["id"]
            stats["memories_skipped"] += 1
            continue
        # Add provenance tag
        tags = m.get("tags", "")
        import_tag = f"imported_from:{source_agent}"
        if tags:
            tags = f"{tags},{import_tag}"
        else:
            tags = import_tag
        db.execute("""
            INSERT INTO memories (name, type, memory_class, tags, content, importance,
                                  access_count, last_accessed, created, updated, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (m["name"], m.get("type", "project"), m.get("memory_class", "semantic"),
              tags, m.get("content", ""), m.get("importance", 0.5),
              0, None, m.get("created", datetime.now(timezone.utc).isoformat()),
              datetime.now(timezone.utc).isoformat()))
        new_id = db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
        if source_id is not None:
            _memory_id_map[source_id] = new_id
        stats["memories_new"] += 1

    # Import entity links — skip exact duplicates
    for e in data.get("entities", []):
        existing = db.execute(
            "SELECT id FROM entity_links WHERE source_type=? AND source_id=? AND target_type=? AND target_id=? AND relationship=?",
            (e["source_type"], e["source_id"], e["target_type"], e["target_id"], e["relationship"])
        ).fetchone()
        if existing:
            stats["entities_skipped"] += 1
            continue
        try:
            db.execute("""
                INSERT INTO entity_links (source_type, source_id, target_type, target_id, relationship, metadata)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (e["source_type"], e["source_id"], e["target_type"], e["target_id"],
                  e["relationship"], e.get("metadata")))
            stats["entities_new"] += 1
        except sqlite3.IntegrityError:
            stats["entities_skipped"] += 1

    # Import semantic facts — deduplicate by subject+predicate+object
    for f in data.get("facts", []):
        existing = db.execute(
            "SELECT fact_id FROM semantic_facts WHERE subject=? AND predicate=? AND object=?",
            (f["subject"], f["predicate"], f["object"])
        ).fetchone()
        if existing:
            stats["facts_skipped"] += 1
            continue
        try:
            db.execute("""
                INSERT INTO semantic_facts (subject, predicate, object, fact_type, sentiment, confidence, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (f["subject"], f["predicate"], f["object"],
                  f.get("fact_type", "attribute"), f.get("sentiment", "NEUTRAL"),
                  f.get("confidence", 0.5), f.get("status", "ACTIVE")))
            stats["facts_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["facts_skipped"] += 1

    # Import passages — remap source memory_id to destination memory_id first
    # to prevent passage collision with unrelated pre-existing memories
    for p in data.get("passages", []):
        source_memory_id = p.get("memory_id")
        dest_memory_id = _memory_id_map.get(source_memory_id)
        if dest_memory_id is None:
            # Passage references a memory we didn't import — skip
            stats["passages_skipped"] += 1
            continue
        existing = db.execute(
            "SELECT id FROM memory_passages WHERE memory_id=? AND passage_index=?",
            (dest_memory_id, p["passage_index"])
        ).fetchone()
        if existing:
            stats["passages_skipped"] += 1
            continue
        try:
            db.execute("""
                INSERT INTO memory_passages (memory_id, passage_index, content, role_weight)
                VALUES (?, ?, ?, ?)
            """, (dest_memory_id, p["passage_index"], p["content"],
                  p.get("role_weight", 1.0)))
            stats["passages_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["passages_skipped"] += 1

    # Import evolution patterns — deduplicate by pattern text
    for pat in data.get("patterns", []):
        existing = db.execute(
            "SELECT id FROM evolution_patterns WHERE pattern=?",
            (pat["pattern"],)
        ).fetchone()
        if existing:
            stats["patterns_skipped"] += 1
            continue
        try:
            db.execute("""
                INSERT INTO evolution_patterns (pattern, frequency, severity, status, related_outcomes)
                VALUES (?, ?, ?, ?, ?)
            """, (pat["pattern"], pat.get("frequency", 1), pat.get("severity", "medium"),
                  pat.get("status", "active"), pat.get("related_outcomes")))
            stats["patterns_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["patterns_skipped"] += 1

    # ── Import new tables (sync_version 2) — backward compatible ─────────

    # Companies — remap IDs to prevent cross-brain collision, skip same-brain dupes
    for company in data.get("companies", []):
        try:
            old_id = company.get("id")
            new_id = _new_id(old_id, _company_id_map, "companies", db,
                             name_col="name", name_val=company.get("name"))
            db.execute("""
                INSERT OR IGNORE INTO companies
                (id, name, mission, status, budget_monthly_cents,
                 spent_monthly_cents, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?)
            """, (new_id, company.get("name"), company.get("mission"),
                  company.get("status", "active"),
                  company.get("budget_monthly_cents", 0),
                  company.get("spent_monthly_cents", 0),
                  company.get("created_at"), company.get("updated_at")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["companies_new"] += 1
            else:
                stats["companies_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["companies_skipped"] += 1

    # Company agents — INSERT OR REPLACE with remapped company_id FK.
    # Agent IDs are stable across syncs (not random), so keep original IDs
    # and let INSERT OR REPLACE propagate updates.
    for agent in data.get("company_agents", []):
        try:
            old_id = agent.get("id")
            # Map agent ID to itself (agents keep their IDs for cross-sync stability)
            if old_id:
                _agent_id_map[old_id] = old_id
            new_agent_id = old_id
            new_company_id = _company_id_map.get(agent.get("company_id"), agent.get("company_id"))
            new_reports_to = _agent_id_map.get(agent.get("reports_to"), agent.get("reports_to"))
            db.execute("""
                INSERT OR REPLACE INTO company_agents
                (id, company_id, name, role, title, status, reports_to, model,
                 task_type, authority, budget_monthly_cents, spent_monthly_cents,
                 heartbeat_interval_seconds, last_heartbeat_at, instructions,
                 capabilities, permissions, metadata, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (new_agent_id, new_company_id, agent.get("name"),
                  agent.get("role", "general"), agent.get("title"),
                  agent.get("status", "idle"), new_reports_to,
                  agent.get("model", "auto"), agent.get("task_type", "judgment"),
                  agent.get("authority", "standard"),
                  agent.get("budget_monthly_cents", 0),
                  agent.get("spent_monthly_cents", 0),
                  agent.get("heartbeat_interval_seconds", 14400),
                  agent.get("last_heartbeat_at"), agent.get("instructions"),
                  agent.get("capabilities"), agent.get("permissions"),
                  agent.get("metadata"), agent.get("created_at"),
                  agent.get("updated_at")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["company_agents_replaced"] += 1
            else:
                stats["company_agents_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["company_agents_skipped"] += 1

    # Company issues — remap IDs and FKs, skip same-brain dupes
    for issue in data.get("company_issues", []):
        try:
            old_id = issue.get("id")
            new_issue_id = _new_id(old_id, _issue_id_map, "company_issues", db,
                                   name_col="title", name_val=issue.get("title"))
            new_company_id = _company_id_map.get(issue.get("company_id"), issue.get("company_id"))
            new_parent_id = _issue_id_map.get(issue.get("parent_id"), issue.get("parent_id"))
            new_assignee = _agent_id_map.get(issue.get("assignee_agent_id"), issue.get("assignee_agent_id"))
            db.execute("""
                INSERT OR IGNORE INTO company_issues
                (id, company_id, parent_id, title, description, status,
                 priority, assignee_agent_id, project, issue_number, origin,
                 request_depth, quality_score, cost_cents, started_at,
                 completed_at, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (new_issue_id, new_company_id, new_parent_id,
                  issue.get("title"), issue.get("description"),
                  issue.get("status", "backlog"), issue.get("priority", "medium"),
                  new_assignee, issue.get("project"),
                  issue.get("issue_number"), issue.get("origin", "manual"),
                  issue.get("request_depth", 0), issue.get("quality_score"),
                  issue.get("cost_cents", 0), issue.get("started_at"),
                  issue.get("completed_at"), issue.get("created_at"),
                  issue.get("updated_at")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["company_issues_new"] += 1
            else:
                stats["company_issues_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["company_issues_skipped"] += 1

    # Company goals — remap IDs and FKs, skip same-brain dupes
    for goal in data.get("company_goals", []):
        try:
            old_id = goal.get("id")
            new_goal_id = _new_id(old_id, _goal_id_map, "company_goals", db,
                                  name_col="title", name_val=goal.get("title"))
            new_company_id = _company_id_map.get(goal.get("company_id"), goal.get("company_id"))
            new_assignee = _agent_id_map.get(goal.get("assigned_agent_id"), goal.get("assigned_agent_id"))
            new_parent = _goal_id_map.get(goal.get("parent_goal_id"), goal.get("parent_goal_id"))
            db.execute("""
                INSERT OR IGNORE INTO company_goals
                (id, company_id, title, description, status, priority,
                 target_date, progress, milestones, assigned_agent_id,
                 parent_goal_id, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (new_goal_id, new_company_id, goal.get("title"),
                  goal.get("description", ""), goal.get("status", "active"),
                  goal.get("priority", "medium"), goal.get("target_date"),
                  goal.get("progress", 0.0), goal.get("milestones", "[]"),
                  new_assignee, new_parent,
                  goal.get("created_at"), goal.get("updated_at")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["company_goals_new"] += 1
            else:
                stats["company_goals_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["company_goals_skipped"] += 1

    # Company projects — remap IDs and FKs, skip same-brain dupes
    for proj in data.get("company_projects", []):
        try:
            old_id = proj.get("id")
            new_proj_id = _new_id(old_id, _project_id_map, "company_projects", db,
                                  name_col="name", name_val=proj.get("name"))
            new_company_id = _company_id_map.get(proj.get("company_id"), proj.get("company_id"))
            # Remap related_goal_ids JSON array
            raw_goals = proj.get("related_goal_ids", "[]")
            try:
                goal_ids = json.loads(raw_goals) if isinstance(raw_goals, str) else raw_goals
                remapped_goals = [_goal_id_map.get(g, g) for g in goal_ids]
                related_goals_str = json.dumps(remapped_goals)
            except (json.JSONDecodeError, TypeError):
                related_goals_str = raw_goals
            db.execute("""
                INSERT OR IGNORE INTO company_projects
                (id, company_id, name, tagline, description, status,
                 priority, repo, path, progress, related_goal_ids,
                 tech_stack, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (new_proj_id, new_company_id, proj.get("name"),
                  proj.get("tagline", ""), proj.get("description", ""),
                  proj.get("status", "active"), proj.get("priority", "medium"),
                  proj.get("repo", ""), proj.get("path", ""),
                  proj.get("progress", 0.0), related_goals_str,
                  proj.get("tech_stack", ""), proj.get("created_at"),
                  proj.get("updated_at")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["company_projects_new"] += 1
            else:
                stats["company_projects_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["company_projects_skipped"] += 1

    # Skills — INSERT OR IGNORE by name (UNIQUE)
    for skill in data.get("skills", []):
        try:
            db.execute("""
                INSERT OR IGNORE INTO skills
                (name, display_name, description, category, file_path, installed, created)
                VALUES (?,?,?,?,?,?,?)
            """, (skill.get("name"), skill.get("display_name", ""),
                  skill.get("description", ""), skill.get("category", ""),
                  skill.get("file_path", ""), skill.get("installed", 1),
                  skill.get("created")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["skills_new"] += 1
            else:
                stats["skills_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["skills_skipped"] += 1

    # Skill executions — INSERT OR IGNORE (autoincrement PK, dedupe by skill+created)
    for se in data.get("skill_executions", []):
        try:
            existing = db.execute(
                "SELECT id FROM skill_executions WHERE skill_name=? AND created=?",
                (se.get("skill_name"), se.get("created"))
            ).fetchone()
            if existing:
                stats["skill_executions_skipped"] += 1
                continue
            db.execute("""
                INSERT INTO skill_executions
                (skill_name, success, tokens_used, duration_seconds, error_message, execution_context, created)
                VALUES (?,?,?,?,?,?,?)
            """, (se.get("skill_name"), se.get("success"), se.get("tokens_used"),
                  se.get("duration_seconds"), se.get("error_message"),
                  se.get("execution_context"), se.get("created")))
            stats["skill_executions_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["skill_executions_skipped"] += 1

    # Workflows — INSERT OR IGNORE by name (UNIQUE)
    for wf in data.get("workflows", []):
        try:
            db.execute("""
                INSERT OR IGNORE INTO workflows
                (name, display_name, category, description, cron_schedule,
                 required_services, playwright_setup, flow, edges, enabled,
                 config_keys, script_path, source, created, updated)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (wf.get("name"), wf.get("display_name", ""),
                  wf.get("category", "general"), wf.get("description", ""),
                  wf.get("cron_schedule", ""), wf.get("required_services", "[]"),
                  wf.get("playwright_setup", "[]"), wf.get("flow", "[]"),
                  wf.get("edges", "[]"), wf.get("enabled", 0),
                  wf.get("config_keys", "[]"), wf.get("script_path", ""),
                  wf.get("source", "registry"), wf.get("created"), wf.get("updated")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["workflows_new"] += 1
            else:
                stats["workflows_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["workflows_skipped"] += 1

    # Config — INSERT OR IGNORE by key (PK), skip REDACTED values
    for cfg in data.get("config", []):
        try:
            val = cfg.get("value", "")
            if val == "[REDACTED]":
                stats["config_skipped"] += 1
                continue
            db.execute("""
                INSERT OR IGNORE INTO config (key, value, updated) VALUES (?,?,?)
            """, (cfg.get("key"), val, cfg.get("updated")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["config_new"] += 1
            else:
                stats["config_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["config_skipped"] += 1

    # Satellite DBs — INSERT OR IGNORE by name (UNIQUE), resolve relative paths
    for sat in data.get("satellite_dbs", []):
        try:
            db_path = sat.get("db_path", "")
            # Resolve relative paths back to absolute based on local aibrain root
            if db_path and not os.path.isabs(db_path):
                _local_root = str(Path(__file__).parent.resolve())
                db_path = str(Path(_local_root) / db_path)
            db.execute("""
                INSERT OR IGNORE INTO satellite_dbs
                (name, db_path, description, memory_types, search_keywords, created, active)
                VALUES (?,?,?,?,?,?,?)
            """, (sat.get("name"), db_path, sat.get("description", ""),
                  sat.get("memory_types", "[]"), sat.get("search_keywords", ""),
                  sat.get("created"), sat.get("active", 1)))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["satellite_dbs_new"] += 1
            else:
                stats["satellite_dbs_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["satellite_dbs_skipped"] += 1

    # Evolution outcomes — dedupe by source+source_id+action+created_at
    for eo in data.get("evolution_outcomes", []):
        try:
            existing = db.execute(
                "SELECT id FROM evolution_outcomes WHERE source=? AND action=? AND created_at=?",
                (eo.get("source"), eo.get("action"), eo.get("created_at"))
            ).fetchone()
            if existing:
                stats["evolution_outcomes_skipped"] += 1
                continue
            db.execute("""
                INSERT INTO evolution_outcomes
                (source, source_id, action, result, details, failure_reason, duration_seconds, created_at)
                VALUES (?,?,?,?,?,?,?,?)
            """, (eo.get("source"), eo.get("source_id"), eo.get("action"),
                  eo.get("result"), eo.get("details"), eo.get("failure_reason"),
                  eo.get("duration_seconds"), eo.get("created_at")))
            stats["evolution_outcomes_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["evolution_outcomes_skipped"] += 1

    # Evolution metrics — dedupe by metric_name+source+recorded_at
    for em in data.get("evolution_metrics", []):
        try:
            existing = db.execute(
                "SELECT id FROM evolution_metrics WHERE metric_name=? AND source=? AND recorded_at=?",
                (em.get("metric_name"), em.get("source"), em.get("recorded_at"))
            ).fetchone()
            if existing:
                stats["evolution_metrics_skipped"] += 1
                continue
            db.execute("""
                INSERT INTO evolution_metrics
                (metric_name, metric_value, source, period, recorded_at)
                VALUES (?,?,?,?,?)
            """, (em.get("metric_name"), em.get("metric_value"), em.get("source"),
                  em.get("period"), em.get("recorded_at")))
            stats["evolution_metrics_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["evolution_metrics_skipped"] += 1

    # Evolution cycles — dedupe by started_at+agent
    for ec in data.get("evolution_cycles", []):
        try:
            existing = db.execute(
                "SELECT id FROM evolution_cycles WHERE started_at=? AND agent=?",
                (ec.get("started_at"), ec.get("agent", "neuro"))
            ).fetchone()
            if existing:
                stats["evolution_cycles_skipped"] += 1
                continue
            db.execute("""
                INSERT INTO evolution_cycles
                (started_at, completed_at, outcomes_analyzed, patterns_found,
                 hypotheses_generated, experiments_started, experiments_decided, summary, agent)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (ec.get("started_at"), ec.get("completed_at"),
                  ec.get("outcomes_analyzed", 0), ec.get("patterns_found", 0),
                  ec.get("hypotheses_generated", 0), ec.get("experiments_started", 0),
                  ec.get("experiments_decided", 0), ec.get("summary"),
                  ec.get("agent", "neuro")))
            stats["evolution_cycles_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["evolution_cycles_skipped"] += 1

    # Entities (knowledge graph) — INSERT OR IGNORE by name+type (UNIQUE)
    for ent in data.get("knowledge_entities", []):
        try:
            db.execute("""
                INSERT OR IGNORE INTO entities
                (name, type, category, mention_count, first_seen, last_seen)
                VALUES (?,?,?,?,?,?)
            """, (ent.get("name"), ent.get("type"), ent.get("category", ""),
                  ent.get("mention_count", 1), ent.get("first_seen"),
                  ent.get("last_seen")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["knowledge_entities_new"] += 1
            else:
                stats["knowledge_entities_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["knowledge_entities_skipped"] += 1

    # Category summaries — INSERT OR IGNORE by category (PK)
    for cs in data.get("category_summaries", []):
        try:
            db.execute("""
                INSERT OR IGNORE INTO category_summaries
                (category, summary, memory_count, avg_importance, top_keywords, last_updated)
                VALUES (?,?,?,?,?,?)
            """, (cs.get("category"), cs.get("summary"),
                  cs.get("memory_count", 0), cs.get("avg_importance", 0.0),
                  cs.get("top_keywords", ""), cs.get("last_updated")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["category_summaries_new"] += 1
            else:
                stats["category_summaries_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["category_summaries_skipped"] += 1

    # Approvals — dedupe by title+created (no unique constraint on table)
    for ap in data.get("approvals", []):
        try:
            existing = db.execute(
                "SELECT id FROM approvals WHERE title=? AND created=?",
                (ap.get("title"), ap.get("created"))
            ).fetchone()
            if existing:
                stats["approvals_skipped"] += 1
                continue
            db.execute("""
                INSERT INTO approvals
                (created, updated, category, title, detail, payload, status, decided_at, decision_note)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (ap.get("created"), ap.get("updated"), ap.get("category", ""),
                  ap.get("title", ""), ap.get("detail", ""),
                  ap.get("payload", "{}"), ap.get("status", "pending"),
                  ap.get("decided_at"), ap.get("decision_note", "")))
            stats["approvals_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["approvals_skipped"] += 1

    # Agent permissions — dedupe by action_type+target
    for perm in data.get("agent_permissions", []):
        try:
            existing = db.execute(
                "SELECT id FROM agent_permissions WHERE action_type=? AND target=?",
                (perm.get("action_type"), perm.get("target", "*"))
            ).fetchone()
            if existing:
                stats["agent_permissions_skipped"] += 1
                continue
            db.execute("""
                INSERT INTO agent_permissions
                (action_type, target, permission, granted_by, expires_at,
                 use_count, last_used_at, created_at, updated_at, notes)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, (perm.get("action_type"), perm.get("target", "*"),
                  perm.get("permission"), perm.get("granted_by", "user"),
                  perm.get("expires_at"), perm.get("use_count", 0),
                  perm.get("last_used_at"), perm.get("created_at"),
                  perm.get("updated_at"), perm.get("notes")))
            stats["agent_permissions_new"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["agent_permissions_skipped"] += 1

    # Scheduled jobs — INSERT OR IGNORE by name (UNIQUE)
    for job in data.get("scheduled_jobs", []):
        try:
            db.execute("""
                INSERT OR IGNORE INTO scheduled_jobs
                (name, cron, prompt, enabled, notes, workflow_id, last_run, next_run, created)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (job.get("name"), job.get("cron"), job.get("prompt", ""),
                  job.get("enabled", 1), job.get("notes", ""),
                  job.get("workflow_id"), job.get("last_run"),
                  job.get("next_run"), job.get("created")))
            if db.execute("SELECT changes()").fetchone()[0] > 0:
                stats["scheduled_jobs_new"] += 1
            else:
                stats["scheduled_jobs_skipped"] += 1
        except (sqlite3.IntegrityError, sqlite3.OperationalError):
            stats["scheduled_jobs_skipped"] += 1

    db.commit()
    return stats


def brain_merge(source) -> dict:
    """Merge knowledge from a git repo URL or local path.

    If source is a git URL: clone to temp, find brain_export.json or aibrain.db.
    If source is a local path: look for brain_export.json or aibrain.db directly.
    """
    source_path = Path(source)
    temp_dir = None

    # Determine if it's a git URL or local path
    is_git = source.startswith("http://") or source.startswith("https://") or source.endswith(".git")

    if is_git:
        temp_dir = tempfile.mkdtemp(prefix="brain_merge_")
        print(f"Cloning {source} to {temp_dir}...")
        result = subprocess.run(
            ["git", "clone", "--depth", "1", source, temp_dir],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            if temp_dir:
                shutil.rmtree(temp_dir, ignore_errors=True)
            raise RuntimeError(f"Git clone failed: {result.stderr.strip()}")
        source_path = Path(temp_dir)

    try:
        # Look for brain_export.json first, then aibrain.db
        export_json = source_path / "brain_export.json"
        db_file = source_path / "aibrain.db"

        if export_json.exists():
            print(f"Found brain_export.json — importing directly...")
            return brain_import(str(export_json))

        elif db_file.exists():
            print(f"Found aibrain.db — exporting then importing...")
            # Temporarily export from the source DB
            src_conn = sqlite3.connect(str(db_file), check_same_thread=False)
            src_conn.row_factory = sqlite3.Row

            # Build export from source DB
            export_data = {"metadata": {"export_date": datetime.now(timezone.utc).isoformat(),
                                        "agent_name": "merged_source"},
                           "memories": [], "entities": [], "facts": [],
                           "passages": [], "patterns": []}

            try:
                export_data["memories"] = [dict(r) for r in src_conn.execute(
                    "SELECT * FROM memories WHERE active=1").fetchall()]
            except sqlite3.OperationalError:
                pass
            try:
                export_data["entities"] = [dict(r) for r in src_conn.execute(
                    "SELECT * FROM entity_links").fetchall()]
            except sqlite3.OperationalError:
                pass
            try:
                export_data["facts"] = [dict(r) for r in src_conn.execute(
                    "SELECT * FROM semantic_facts").fetchall()]
            except sqlite3.OperationalError:
                pass
            try:
                export_data["passages"] = [dict(r) for r in src_conn.execute(
                    "SELECT * FROM memory_passages").fetchall()]
            except sqlite3.OperationalError:
                pass
            try:
                export_data["patterns"] = [dict(r) for r in src_conn.execute(
                    "SELECT * FROM evolution_patterns").fetchall()]
            except sqlite3.OperationalError:
                pass
            src_conn.close()

            # Update metadata counts
            export_data["metadata"]["memory_count"] = len(export_data["memories"])
            export_data["metadata"]["entity_count"] = len(export_data["entities"])
            export_data["metadata"]["fact_count"] = len(export_data["facts"])
            export_data["metadata"]["passage_count"] = len(export_data["passages"])
            export_data["metadata"]["pattern_count"] = len(export_data["patterns"])

            # Write temp export and import it
            tmp_export = Path(tempfile.mktemp(suffix=".json", prefix="brain_"))
            tmp_export.write_text(json.dumps(export_data, default=str), encoding="utf-8")
            try:
                return brain_import(str(tmp_export))
            finally:
                tmp_export.unlink(missing_ok=True)

        else:
            raise FileNotFoundError(
                f"No brain_export.json or aibrain.db found in {source_path}")

    finally:
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)


def brain_stats() -> dict:
    """Show brain statistics — knowledge tables only."""
    db = get_db()
    stats = {}

    # Memory count + type breakdown
    stats["memories_total"] = db.execute(
        "SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
    stats["memories_by_type"] = {}
    for row in db.execute(
            "SELECT type, COUNT(*) as c FROM memories WHERE active=1 GROUP BY type ORDER BY c DESC"):
        stats["memories_by_type"][row["type"]] = row["c"]
    stats["memories_by_class"] = {}
    for row in db.execute(
            "SELECT memory_class, COUNT(*) as c FROM memories WHERE active=1 GROUP BY memory_class ORDER BY c DESC"):
        stats["memories_by_class"][row["memory_class"]] = row["c"]

    # Entity links
    try:
        stats["entity_links"] = db.execute("SELECT COUNT(*) FROM entity_links").fetchone()[0]
        stats["entity_types"] = {}
        for row in db.execute(
                "SELECT source_type, COUNT(*) as c FROM entity_links GROUP BY source_type ORDER BY c DESC"):
            stats["entity_types"][row["source_type"]] = row["c"]
    except sqlite3.OperationalError:
        stats["entity_links"] = 0

    # Semantic facts
    try:
        stats["semantic_facts"] = db.execute("SELECT COUNT(*) FROM semantic_facts").fetchone()[0]
    except sqlite3.OperationalError:
        stats["semantic_facts"] = 0

    # Memory passages
    try:
        stats["memory_passages"] = db.execute("SELECT COUNT(*) FROM memory_passages").fetchone()[0]
    except sqlite3.OperationalError:
        stats["memory_passages"] = 0

    # Evolution patterns
    try:
        stats["evolution_patterns"] = db.execute("SELECT COUNT(*) FROM evolution_patterns").fetchone()[0]
        stats["patterns_by_status"] = {}
        for row in db.execute(
                "SELECT status, COUNT(*) as c FROM evolution_patterns GROUP BY status ORDER BY c DESC"):
            stats["patterns_by_status"][row["status"]] = row["c"]
    except sqlite3.OperationalError:
        stats["evolution_patterns"] = 0

    # Top entities by relationship count
    try:
        stats["top_relationships"] = {}
        for row in db.execute(
                "SELECT relationship, COUNT(*) as c FROM entity_links GROUP BY relationship ORDER BY c DESC LIMIT 10"):
            stats["top_relationships"][row["relationship"]] = row["c"]
    except sqlite3.OperationalError:
        pass

    return stats


# ---------------------------------------------------------------------------
# Category Summaries — compressed per-type/tag memory summaries
# ---------------------------------------------------------------------------

import re as _re
from collections import Counter as _Counter

# Debounce tracker: {category: last_updated_timestamp}
_category_update_timestamps: dict[str, float] = {}
_CATEGORY_DEBOUNCE_SECONDS = 3600  # 1 hour


def _extract_keywords(text: str, top_n: int = 10) -> list[str]:
    """Extract top keywords from text using word frequency (no LLM).

    Filters out common stop words and short tokens. Returns top_n keywords
    sorted by frequency.
    """
    _STOP_WORDS = frozenset({
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "need", "dare", "ought",
        "used", "to", "of", "in", "for", "on", "with", "at", "by", "from",
        "as", "into", "through", "during", "before", "after", "above",
        "below", "between", "out", "off", "over", "under", "again",
        "further", "then", "once", "here", "there", "when", "where", "why",
        "how", "all", "each", "every", "both", "few", "more", "most",
        "other", "some", "such", "no", "nor", "not", "only", "own", "same",
        "so", "than", "too", "very", "just", "because", "but", "and", "or",
        "if", "while", "about", "up", "that", "this", "it", "its", "i",
        "me", "my", "we", "our", "you", "your", "he", "him", "his", "she",
        "her", "they", "them", "their", "what", "which", "who", "whom",
        "default", "none", "also", "like", "get", "set", "new",
    })
    words = _re.findall(r'[a-zA-Z_][a-zA-Z0-9_]{2,}', text.lower())
    filtered = [w for w in words if w not in _STOP_WORDS and len(w) > 2]
    counts = _Counter(filtered)
    return [word for word, _ in counts.most_common(top_n)]


def _build_summary_text(memories: list[dict]) -> str:
    """Build a compressed summary from a list of memory dicts (no LLM).

    Extracts the first ~120 chars of each memory's content, deduplicates,
    and concatenates into a compact summary string.
    """
    seen = set()
    parts = []
    for mem in memories:
        content = mem.get("content", "")
        # Take the first meaningful sentence/line
        snippet = content.strip().split("\n")[0][:150].strip()
        if not snippet:
            snippet = mem.get("name", "")[:120].strip()
        key = snippet.lower()
        if key and key not in seen:
            seen.add(key)
            parts.append(snippet)
    return " | ".join(parts)


def update_category_summary(category: str, db=None):
    """Regenerate summary for a category from its top memories.

    Strategy (no LLM needed):
    1. Get top 20 memories by importance for this category
    2. Extract key phrases/names from each
    3. Concatenate into a compressed summary
    4. Compute and store embedding for the summary
    5. Update memory_count and avg_importance
    """
    if db is None:
        db = get_db()

    # Fetch top 20 memories for this category by importance
    rows = db.execute("""
        SELECT id, name, type, content, importance, tags
        FROM memories
        WHERE active = 1 AND type = ?
        ORDER BY COALESCE(importance, 0.5) DESC, updated DESC
        LIMIT 20
    """, (category,)).fetchall()

    memories = [dict(r) for r in rows]

    if not memories:
        # No memories for this category -- remove summary if exists
        db.execute("DELETE FROM category_summaries WHERE category = ?", (category,))
        db.commit()
        return

    # Build summary text
    summary_text = _build_summary_text(memories)

    # Extract keywords from all content
    all_content = " ".join(m.get("content", "") + " " + m.get("tags", "") for m in memories)
    keywords = _extract_keywords(all_content, top_n=15)

    # Count total memories and average importance
    stats = db.execute("""
        SELECT COUNT(*) as cnt, AVG(COALESCE(importance, 0.5)) as avg_imp
        FROM memories WHERE active = 1 AND type = ?
    """, (category,)).fetchone()
    memory_count = stats[0] if stats else 0
    avg_importance = round(stats[1], 4) if stats and stats[1] else 0.0

    # Compute embedding for the summary (if embeddings available)
    embedding_blob = None
    if _db_vec_enabled and _db_embedder is not None:
        emb = _compute_embedding(summary_text)
        if emb is not None:
            embedding_blob = struct.pack(f"{len(emb)}f", *emb)

    now = datetime.now(timezone.utc).isoformat()

    db.execute("""
        INSERT INTO category_summaries (category, summary, memory_count, avg_importance, top_keywords, embedding, last_updated)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(category) DO UPDATE SET
            summary = excluded.summary,
            memory_count = excluded.memory_count,
            avg_importance = excluded.avg_importance,
            top_keywords = excluded.top_keywords,
            embedding = excluded.embedding,
            last_updated = excluded.last_updated
    """, (category, summary_text, memory_count, avg_importance,
          ",".join(keywords), embedding_blob, now))
    db.commit()

    # Update debounce tracker
    import time
    _category_update_timestamps[category] = time.time()


def get_category_summaries(categories: list[str] = None, db=None) -> list[dict]:
    """Get summaries for specified categories (or all)."""
    if db is None:
        db = get_db()

    if categories:
        placeholders = ",".join("?" * len(categories))
        rows = db.execute(
            f"SELECT category, summary, memory_count, avg_importance, top_keywords, last_updated "
            f"FROM category_summaries WHERE category IN ({placeholders})",
            categories
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT category, summary, memory_count, avg_importance, top_keywords, last_updated "
            "FROM category_summaries ORDER BY memory_count DESC"
        ).fetchall()

    return [
        {
            "category": r[0],
            "summary": r[1],
            "memory_count": r[2],
            "avg_importance": r[3],
            "top_keywords": r[4],
            "last_updated": r[5],
        }
        for r in rows
    ]


def search_category_summaries(query: str, limit: int = 5, db=None) -> list[dict]:
    """Vector search against category summary embeddings.

    Falls back to keyword matching if embeddings are not available.
    Returns list of dicts with category, summary, score, etc.
    """
    if db is None:
        db = get_db()

    results = []

    # Try vector search first
    if _db_vec_enabled and _db_embedder is not None:
        query_emb = _compute_embedding(query)
        if query_emb is not None:
            rows = db.execute(
                "SELECT category, summary, memory_count, avg_importance, top_keywords, "
                "last_updated, embedding FROM category_summaries WHERE embedding IS NOT NULL"
            ).fetchall()

            scored = []
            for row in rows:
                emb_blob = row[6]
                if emb_blob is None:
                    continue
                dim = len(emb_blob) // 4
                stored_emb = list(struct.unpack(f"{dim}f", emb_blob))
                score = _cosine_similarity(query_emb, stored_emb)
                scored.append({
                    "category": row[0],
                    "summary": row[1],
                    "memory_count": row[2],
                    "avg_importance": row[3],
                    "top_keywords": row[4],
                    "last_updated": row[5],
                    "score": round(score, 4),
                })

            scored.sort(key=lambda x: x["score"], reverse=True)
            return scored[:limit]

    # Fallback: keyword matching against summary text and keywords
    query_lower = query.lower()
    query_words = set(_re.findall(r'[a-z_][a-z0-9_]{2,}', query_lower))

    rows = db.execute(
        "SELECT category, summary, memory_count, avg_importance, top_keywords, last_updated "
        "FROM category_summaries"
    ).fetchall()

    for row in rows:
        summary_lower = (row[1] + " " + row[4]).lower()
        # Score by word overlap
        summary_words = set(_re.findall(r'[a-z_][a-z0-9_]{2,}', summary_lower))
        overlap = query_words & summary_words
        if overlap:
            score = len(overlap) / max(len(query_words), 1)
            results.append({
                "category": row[0],
                "summary": row[1],
                "memory_count": row[2],
                "avg_importance": row[3],
                "top_keywords": row[4],
                "last_updated": row[5],
                "score": round(score, 4),
            })

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:limit]


def _maybe_update_category_summary(category: str):
    """Check if category summary is stale and regenerate if needed.

    Uses debouncing to avoid regenerating on every single store.
    Called after create_memory().
    """
    import time
    now = time.time()
    last = _category_update_timestamps.get(category, 0)
    if now - last < _CATEGORY_DEBOUNCE_SECONDS:
        return  # Not stale yet, skip

    # Check DB last_updated as well (handles cross-process staleness)
    db = get_db()
    row = db.execute(
        "SELECT last_updated FROM category_summaries WHERE category = ?",
        (category,)
    ).fetchone()

    if row:
        try:
            last_dt = datetime.fromisoformat(row[0])
            age_seconds = (datetime.now(timezone.utc) - last_dt).total_seconds()
            if age_seconds < _CATEGORY_DEBOUNCE_SECONDS:
                _category_update_timestamps[category] = now
                return  # Still fresh
        except (ValueError, TypeError):
            pass

    # Stale or missing -- regenerate
    update_category_summary(category, db=db)


# ---------------------------------------------------------------------------
# Tiered Retrieval — multi-tier search with early stopping
# ---------------------------------------------------------------------------

def tiered_search(query: str, limit: int = 10, sufficiency_threshold: float = 0.85,
                  db=None) -> dict:
    """Three-tier retrieval with early stopping.

    Tier 1: Search category summaries (cheap, ~400 tokens each)
            If top result score > sufficiency_threshold -> return summaries only

    Tier 2: Search individual memories (standard search_memories)
            If top result score > sufficiency_threshold -> return memories

    Tier 3: Search across satellite DBs (federated, expensive)
            Final fallback

    Returns:
        {
            "results": [...],
            "tier_used": 1|2|3,
            "tokens_saved": estimated tokens not loaded,
            "reason": "Answered from category summaries (tier 1)"
        }
    """
    if db is None:
        db = get_db()

    # Classify query to decide tier eligibility
    query_type = classify_query(query)

    # Queries about specific sessions or temporal context should skip tier 1
    skip_tier1 = query_type in ("multi_session", "temporal", "ss_user", "ss_assistant")

    # --- Tier 1: Category summaries ---
    if not skip_tier1:
        cat_results = search_category_summaries(query, limit=limit, db=db)
        if cat_results and cat_results[0].get("score", 0) > sufficiency_threshold:
            # Estimate tokens saved: avg memory is ~200 tokens, we avoided loading them
            est_total_memories = sum(r.get("memory_count", 0) for r in cat_results[:limit])
            tokens_saved = est_total_memories * 200

            return {
                "results": cat_results[:limit],
                "tier_used": 1,
                "tokens_saved": tokens_saved,
                "query_type": query_type,
                "reason": f"Answered from category summaries (tier 1, top score={cat_results[0]['score']:.2f})",
            }

    # --- Tier 2: Individual memory search ---
    mem_results = search_memories(query, limit=limit)

    # Convert to dicts with score field
    tier2_results = []
    for r in mem_results:
        entry = dict(r) if not isinstance(r, dict) else r
        # search_memories doesn't return a normalized 0-1 score directly,
        # but it does rank by combined score. We approximate from position.
        tier2_results.append(entry)

    if tier2_results:
        # Check if we have good enough results
        # Use number of results as a proxy for confidence
        has_enough = len(tier2_results) >= min(3, limit)
        if has_enough:
            # Estimate tokens saved by not searching satellites
            tokens_saved = 0  # Could estimate satellite sizes
            return {
                "results": tier2_results[:limit],
                "tier_used": 2,
                "tokens_saved": tokens_saved,
                "query_type": query_type,
                "reason": f"Answered from individual memories (tier 2, {len(tier2_results)} results)",
            }

    # --- Tier 3: Federated search across satellites ---
    fed_results = federated_search(query, limit=limit)

    # Flatten federated results into a single list
    all_results = []
    for key, val in fed_results.items():
        if key == "total":  # noqa:PLAIN SECRET COMPARISON
            continue
        if isinstance(val, list):
            for item in val:
                entry = dict(item) if not isinstance(item, dict) else item
                entry["_source"] = key
                all_results.append(entry)

    # Estimate: tier 3 means we searched everything, so tokens_saved = 0
    return {
        "results": all_results[:limit],
        "tier_used": 3,
        "tokens_saved": 0,
        "query_type": query_type,
        "reason": f"Federated search across all stores (tier 3, {len(all_results)} results)",
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _cmd_doctor():
    """Scan for shadow DBs, rescue stranded memories, and fix MCP config."""
    import shutil

    # Load profile registry — used throughout to skip isolated profiles
    try:
        from aibrain.core import profile_registry as _profile_registry
    except Exception:
        _profile_registry = None  # Graceful degradation — treat all as unregistered

    def _is_isolated_prof(name: str) -> bool:
        """Return True if profile name is registered as isolated."""
        if _profile_registry is None:
            return False
        try:
            return _profile_registry.is_isolated(name)
        except Exception:
            return False

    # Ensure stdout handles Unicode on Windows consoles (cp1252 crashes on -> arrows)
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass  # Non-fatal — best effort

    home = Path.home()
    candidates = [
        home / "aibrain" / "aibrain.db",
        home / "projects" / "aibrain" / "aibrain.db",
    ]
    if "AIBRAIN_ROOT" in os.environ:
        candidates.insert(0, Path(os.environ["AIBRAIN_ROOT"]) / "aibrain.db")

    existing = [(p.stat().st_size, p) for p in candidates if p.exists()]
    if not existing:
        print("No aibrain.db found anywhere. Run 'aibrain setup' first.")
        return

    existing.sort(reverse=True)
    primary_path = existing[0][1]
    print(f"Primary DB (largest): {primary_path}  ({existing[0][0]//1024}KB)")

    if len(existing) == 1:
        print("Only one DB found — no shadow DB issue.")
    else:
        print(f"\nFound {len(existing)} DB files:")
        for size, path in existing:
            marker = " <-- PRIMARY" if path == primary_path else " <-- SHADOW"
            print(f"  {path}  ({size//1024}KB){marker}")

        primary_db = get_db_at(str(primary_path))
        rescued = 0
        # Whitelist-only columns — never trust arbitrary schema names in SQL
        # NOTE: 'id' is intentionally excluded — shadow DBs have conflicting low IDs
        # (e.g. shadow id=1 vs primary id=1 pointing to a different memory).
        # Excluding 'id' lets the primary DB auto-assign a new non-conflicting id.
        _ALLOWED_COLS = frozenset([
            "name", "type", "memory_class", "tags", "content",
            "importance", "access_count", "last_accessed", "created",
            "updated", "active", "source_agent", "consolidated_from",
            "storage_strength",
        ])
        for size, shadow_path in existing[1:]:
            if size == 0:
                continue
            if shadow_path.is_symlink():
                print(f"\nSkipping symlink (security): {shadow_path}")
                continue
            print(f"\nScanning shadow DB: {shadow_path}")
            try:
                shadow_db = sqlite3.connect(str(shadow_path))
                cols_info = shadow_db.execute("PRAGMA table_info(memories)").fetchall()
                cols = [c[1] for c in cols_info if c[1] in _ALLOWED_COLS]
                if not cols:
                    print(f"  No recognisable columns — skipping")
                    shadow_db.close()
                    continue
                col_sql = ",".join(cols)  # safe: whitelist-filtered
                rows = shadow_db.execute("SELECT " + col_sql + " FROM memories").fetchall()  # noqa:SQL-FSTRING
                print(f"  Found {len(rows)} memories")
                placeholders = ",".join(["?" for _ in cols])
                insert_sql = "INSERT OR IGNORE INTO memories (" + col_sql + ") VALUES (" + placeholders + ")"  # noqa:SQL-FSTRING
                # Wrap entire shadow rescue in a transaction — atomic or nothing
                primary_db.execute("BEGIN")
                try:
                    for row in rows:
                        d = dict(zip(cols, row))
                        name = d.get("name", "")
                        exists = primary_db.execute(
                            "SELECT id FROM memories WHERE name=?", (name,)
                        ).fetchone()
                        if not exists:
                            primary_db.execute(insert_sql, row)
                            rescued += 1
                            print(f"    Rescued: {name}")
                        else:
                            print(f"    Already in primary: {name}")
                    primary_db.execute("COMMIT")
                except Exception as e:
                    primary_db.execute("ROLLBACK")
                    print(f"  ROLLBACK — transaction failed: {e}")
                shadow_db.close()
            except Exception as e:
                print(f"  Error reading shadow DB: {e} — skipping")

        print(f"\nRescued {rescued} memories into primary DB.")

    # Fix MCP config — ensure explicit --db in all Claude config locations
    # Discover all .claude and .claude-* dirs dynamically (not a hardcoded list)
    mcp_configs = []
    claude_dirs = [home / ".claude"]
    try:
        for d in home.iterdir():
            if d.is_dir() and d.name.startswith(".claude-"):
                claude_dirs.append(d)
    except Exception:
        pass
    for d in claude_dirs:
        for fname in [".claude.json", "claude.json"]:
            p = d / fname
            if p.exists():
                mcp_configs.append((d.name, p))
    # Also root .claude.json (global)
    root_claude = home / ".claude.json"
    if root_claude.exists():
        mcp_configs.append(("(root)", root_claude))

    print(f"\nChecking MCP configs ({len(mcp_configs)} found)...")
    mcp_script = str(primary_path.parent / "mcp_server.py")
    db_str = str(primary_path)

    for (dir_name, cfg_path) in mcp_configs:
        # Skip isolated profiles — they carry their own explicit --db config
        # (pointing to their dedicated DB, not the primary one)
        if dir_name.startswith(".claude-"):
            profile_name = dir_name[len(".claude-"):]
            if _is_isolated_prof(profile_name):
                print(f"  SKIP  {dir_name} — isolated profile, own config")
                continue

        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
            servers = cfg.get("mcpServers", {})
            mem = servers.get("aibrain-memory", {})
            # Guard against malformed entries (null, list, etc.)
            if not isinstance(mem, dict):
                mem = {}
            args = mem.get("args", [])
            if not isinstance(args, list):
                args = []
            if "--db" not in args:
                # Back up then fix
                bak = cfg_path.with_suffix(".json.doctor_bak")
                shutil.copy2(cfg_path, bak)
                # Strip any stale script entries, keep other args intact
                args_new = [a for a in args if "mcp_server.py" not in str(a)]
                # Prepend canonical script path
                args_new = [mcp_script] + args_new + ["--db", db_str]
                mem["args"] = args_new
                servers["aibrain-memory"] = mem
                cfg["mcpServers"] = servers
                cfg_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
                print(f"  FIXED {cfg_path} — added --db {db_str}  (backup: {bak.name})")
            else:
                db_idx = args.index("--db")
                if db_idx + 1 >= len(args):
                    print(f"  ERROR {cfg_path} — --db flag present but missing value")
                else:
                    current_db = args[db_idx + 1]
                    if Path(current_db).resolve() != Path(db_str).resolve():
                        print(f"  WARNING {cfg_path} — --db points to {current_db} (primary is {db_str})")
                    else:
                        print(f"  OK {cfg_path}")
        except Exception as e:
            print(f"  ERROR {cfg_path}: {e}")

    # Fix MEMORY.md isolation — ensure all Claude profile dirs share the same
    # projects/ folder so auto-memory writes to one place regardless of which
    # account or profile is active.
    print(f"\nChecking auto-memory (MEMORY.md) isolation...")
    primary_claude = home / ".claude"
    primary_projects = primary_claude / "projects"

    if not primary_projects.exists():
        print(f"  Primary ~/.claude/projects not found — skipping memory sync check")
    else:
        alt_claude_dirs = [
            d for d in home.iterdir()
            if d.is_dir() and d.name.startswith(".claude-") and d != primary_claude
        ]
        if not alt_claude_dirs:
            print(f"  No alternate profiles found — nothing to link")
        for alt_dir in alt_claude_dirs:
            # Skip isolated profiles — they intentionally have their own projects/ dir
            profile_name = alt_dir.name[len(".claude-"):]
            if _is_isolated_prof(profile_name):
                print(f"  SKIP  {alt_dir.name} — isolated profile, own projects/")
                continue

            alt_projects = alt_dir / "projects"
            if alt_projects.is_symlink():
                target = alt_projects.resolve()
                if target == primary_projects.resolve():
                    print(f"  OK {alt_dir.name}/projects → already linked to primary")
                else:
                    print(f"  WARNING {alt_dir.name}/projects → symlink points elsewhere: {target}")
            elif alt_projects.exists():
                # Real dir exists — check if it has diverged MEMORY.md files
                diverged = list(alt_projects.rglob("MEMORY.md"))
                if diverged:
                    print(f"  WARNING {alt_dir.name}/projects has {len(diverged)} MEMORY.md file(s) not shared with primary:")
                    for f in diverged:
                        print(f"    {f}")
                    print(f"  Action needed: manually merge or symlink {alt_projects} → {primary_projects}")
                else:
                    # Empty dir — safe to replace with symlink
                    try:
                        alt_projects.rmdir()
                        alt_projects.symlink_to(primary_projects)
                        print(f"  FIXED {alt_dir.name}/projects — symlinked to primary")
                    except Exception as e:
                        print(f"  ERROR {alt_dir.name}/projects: {e}")
            else:
                # Does not exist — create symlink now
                try:
                    alt_projects.symlink_to(primary_projects)
                    print(f"  FIXED {alt_dir.name}/projects — symlinked to primary (was missing)")
                except Exception as e:
                    # Windows may need junction instead of symlink
                    try:
                        import subprocess as _sp
                        _sp.run(
                            ["cmd", "/c", "mklink", "/J",
                             str(alt_projects), str(primary_projects)],
                            check=True, capture_output=True
                        )
                        print(f"  FIXED {alt_dir.name}/projects — junction created (Windows)")
                    except Exception as e2:
                        print(f"  ERROR {alt_dir.name}/projects — symlink failed: {e} | junction failed: {e2}")
                        print(f"  Manual fix: link {alt_projects} → {primary_projects}")

    # Junction/symlink assertions — hard verification that linking actually worked
    print(f"\nVerifying junction/symlink assertions...")
    if primary_projects.exists():
        assertion_failures = 0
        alt_dirs_check = [
            d for d in home.iterdir()
            if d.is_dir() and d.name.startswith(".claude-") and d != primary_claude
        ]
        if not alt_dirs_check:
            print(f"  PASS  No alternate profiles exist — nothing to assert")
        for alt_dir in alt_dirs_check:
            # Skip isolated profiles in junction assertions — they have real (non-linked) projects/
            profile_name_check = alt_dir.name[len(".claude-"):]
            if _is_isolated_prof(profile_name_check):
                print(f"  SKIP  {alt_dir.name}/projects — isolated profile, own projects/")
                continue

            alt_projects = alt_dir / "projects"
            # Assert 1: junction/symlink must exist
            if not alt_projects.exists() and not alt_projects.is_symlink():
                print(f"  FAIL  {alt_dir.name}/projects does not exist (not linked)")
                assertion_failures += 1
                continue
            # Assert 2: must be a symlink or junction (not a plain dir)
            if not alt_projects.is_symlink():
                # Windows junctions appear as dirs, not symlinks via Python os.path
                # Check via os.stat with follow_symlinks=False
                import stat as _stat
                try:
                    st = alt_projects.stat()
                    # If it resolves to same inode/path as primary, it's a junction
                    if alt_projects.resolve() == primary_projects.resolve():
                        print(f"  PASS  {alt_dir.name}/projects -> (junction) -> primary")
                    else:
                        print(f"  FAIL  {alt_dir.name}/projects is a plain dir, not linked to primary")
                        assertion_failures += 1
                except Exception as e:
                    print(f"  FAIL  {alt_dir.name}/projects stat error: {e}")
                    assertion_failures += 1
            else:
                # Assert 3: symlink must resolve to primary projects
                resolved = alt_projects.resolve()
                if resolved == primary_projects.resolve():
                    print(f"  PASS  {alt_dir.name}/projects -> {primary_projects}")
                else:
                    print(f"  FAIL  {alt_dir.name}/projects -> {resolved} (expected {primary_projects})")
                    assertion_failures += 1
        if alt_dirs_check:
            if assertion_failures == 0:
                print(f"  All {len(alt_dirs_check)} profile(s) correctly share primary projects/")
            else:
                print(f"  {assertion_failures} assertion(s) FAILED — run doctor again or fix manually")
    else:
        print(f"  SKIP  Primary ~/.claude/projects not found")

    # Profile registry check
    print(f"\nChecking profile registry...")
    if _profile_registry is None:
        print(f"  SKIP  profile_registry module unavailable")
    else:
        try:
            profiles = _profile_registry.list_profiles()
            profiles_json_path = _profile_registry._profiles_json()
            if not profiles_json_path.exists():
                print(f"  profiles.json: not found (no profiles registered yet)")
            else:
                print(f"  profiles.json: {len(profiles)} profile(s) registered")

            for p in profiles:
                name = p["name"]
                mode = p["mode"].upper()
                label = p.get("label") or ""
                label_str = f"  [{label}]" if label else ""
                profile_dir = home / f".claude-{name}"

                if p["mode"] == "isolated":
                    db_p = p.get("db_path")
                    if db_p:
                        db_path_obj = Path(db_p)
                        if db_path_obj.exists():
                            size_kb = db_path_obj.stat().st_size // 1024
                            db_info = f"DB: {db_path_obj.name} ({size_kb}KB)"
                        else:
                            db_info = f"WARNING  DB not found at {db_p}"
                    else:
                        db_info = "WARNING  no db_path in registry"
                    dir_status = "exists" if profile_dir.exists() else "MISSING"
                    print(f"  .claude-{name}: {mode}{label_str} — {db_info}  (dir: {dir_status})")
                    # Broken isolated DB check
                    if db_p and not Path(db_p).exists():
                        print(f"  WARNING  {name} — isolated DB not found at {db_p}")
                else:
                    # Hive — verify symlinks
                    dir_status = "exists" if profile_dir.exists() else "MISSING"
                    broken = []
                    for d in ["skills", "agents", "rules", "projects"]:
                        dpath = profile_dir / d
                        if profile_dir.exists() and not dpath.exists() and not dpath.is_symlink():
                            broken.append(d)
                    if broken:
                        print(f"  .claude-{name}: {mode}{label_str} — dir: {dir_status}  BROKEN links: {', '.join(broken)}")
                    else:
                        print(f"  .claude-{name}: {mode}{label_str} — dir: {dir_status}  OK")

            # Report unregistered .claude-* dirs
            registered_names = {p["name"] for p in profiles}
            unregistered = []
            try:
                for d in home.iterdir():
                    if d.is_dir() and d.name.startswith(".claude-"):
                        uname = d.name[len(".claude-"):]
                        if uname and uname not in registered_names:
                            unregistered.append(uname)
            except Exception:
                pass
            for uname in sorted(unregistered):
                print(f"  UNREGISTERED: .claude-{uname} — run 'aibrain profile create {uname}' to register")

        except Exception as e:
            print(f"  ERROR reading profile registry: {e}")

    # Enforcement constraint validation
    try:
        from aibrain.core.constraint_compiler import doctor_check
        doctor_check(db_path=primary_path)
    except Exception as e:
        print(f"\nEnforcement constraint check failed: {e}")

    print(f"\nDoctor complete. Primary DB: {primary_path}")
    print("Restart Claude Code for MCP changes to take effect.")


def get_db_at(path: str):
    """Open a sqlite3 connection at an explicit path (used by doctor)."""
    import sqlite3 as _sq
    return _sq.connect(path)


def main():
    if len(sys.argv) < 2:
        print("Usage: python aibrain_db.py <command>")
        print("Commands: init, summary, search <query>, config get|set <key> [value]")
        print("          brain export [--output path], brain import <file>, brain merge <url|path>, brain stats")
        print("          doctor  — scan for shadow DBs, merge lost memories, fix MCP config")
        return

    cmd = sys.argv[1]

    if cmd == "doctor":
        _cmd_doctor()
        return

    if cmd == "init":
        AIBRAIN_ROOT.mkdir(parents=True, exist_ok=True)
        print(f"Initializing AIBrain DB at {DB_PATH}...")
        db = get_db()
        stats = seed_from_json(db)
        print(f"Seeded: {json.dumps(stats, indent=2)}")

        # Seed workflows
        try:
            from aibrain_workflows import seed_workflows
            wf_count = seed_workflows(str(DB_PATH))
            print(f"Workflows seeded: {wf_count}")
        except Exception as e:
            print(f"Workflow seeding skipped: {e}")

        try:
            from aibrain_skill_workflows import seed_skill_workflows
            sw_count = seed_skill_workflows(str(DB_PATH))
            print(f"Skill workflows seeded: {sw_count}")
        except Exception as e:
            print(f"Skill workflow seeding skipped: {e}")

        try:
            from aibrain_user_workflows import seed_user_workflows
            uw_count = seed_user_workflows(str(DB_PATH))
            print(f"User workflows seeded: {uw_count}")
        except Exception as e:
            print(f"User workflow seeding skipped: {e}")

        try:
            from aibrain_content_workflows import seed_content_workflows
            cw_count = seed_content_workflows(str(DB_PATH))
            print(f"Content workflows seeded: {cw_count} (Pro tier)")
        except Exception as e:
            print(f"Content workflow seeding skipped: {e}")

        try:
            from aibrain_ops_workflows import seed_ops_workflows
            ow_count = seed_ops_workflows(str(DB_PATH))
            print(f"Ops workflows seeded: {ow_count} (Pro tier)")
        except Exception as e:
            print(f"Ops workflow seeding skipped: {e}")

        # Seed skills from bundled .md files
        try:
            skills_dir = Path(__file__).parent / "skills" / "skills"
            if not skills_dir.exists():
                # Try relative to package install location
                skills_dir = Path(sys.prefix) / "skills"
            if skills_dir.exists():
                skill_count = 0
                for md in skills_dir.rglob("*.md"):
                    name = md.stem
                    category = md.parent.name
                    content = md.read_text(encoding="utf-8")
                    db.execute(
                        "INSERT OR REPLACE INTO memories (name, type, tags, content, importance, created, updated, active) "
                        "VALUES (?, 'skill', ?, ?, 0.6, datetime('now'), datetime('now'), 1)",
                        (f"skill_{name}", f"skill,{category}", content)
                    )
                    skill_count += 1
                db.commit()
                print(f"Skills seeded: {skill_count}")
            else:
                print("Skills directory not found — skipped")
        except Exception as e:
            print(f"Skill seeding skipped: {e}")

        s = summary()
        print(f"\nDB Summary:")
        for k, v in s.items():
            if k not in ("apps_by_status",):
                print(f"  {k}: {v}")

    elif cmd == "summary":
        s = summary()
        print(json.dumps(s, indent=2))

    elif cmd == "search" and len(sys.argv) > 2:
        query = " ".join(sys.argv[2:])
        results = search_all(query)
        print(f"Search: '{query}' — {results['total']} results")
        for category in ("memories", "workflows", "applications"):
            if results[category]:
                print(f"\n  {category.upper()}:")
                for r in results[category]:
                    name = r.get("name", r.get("company", "?"))
                    desc = r.get("content", r.get("description", r.get("role", "")))[:80]
                    print(f"    #{r['id']} {name}: {desc}")

    elif cmd == "config":
        if len(sys.argv) < 4:
            print("Usage: config get|set <key> [value]")
            return
        subcmd = sys.argv[2]
        key = sys.argv[3]
        if subcmd == "get":
            val = config_get(key)
            print(f"{key} = {val}")
        elif subcmd == "set" and len(sys.argv) > 4:
            value = " ".join(sys.argv[4:])
            config_set(key, value)
            print(f"Set {key} = {value}")

    elif cmd == "brain":
        if len(sys.argv) < 3:
            print("Usage: brain export [--output path] | brain sync [--output path] | brain import <file> | brain merge <url|path> | brain stats")
            return
        subcmd = sys.argv[2]

        if subcmd == "export":
            output = None
            if "--output" in sys.argv:
                idx = sys.argv.index("--output")
                if idx + 1 < len(sys.argv):
                    output = sys.argv[idx + 1]
            path = brain_export(output)
            print(f"Brain exported to: {path}")

        elif subcmd == "sync":
            # Redacted export safe for git — use this for agent-to-agent sharing
            output = None
            if "--output" in sys.argv:
                idx = sys.argv.index("--output")
                if idx + 1 < len(sys.argv):
                    output = sys.argv[idx + 1]
            path = brain_export_redacted(output)
            print(f"Redacted brain synced to: {path}")
            print("Safe to commit — credentials scrubbed, uses brain_sync_* naming.")

        elif subcmd == "import":
            if len(sys.argv) < 4:
                print("Usage: brain import <file.json>")
                return
            input_path = sys.argv[3]
            if not Path(input_path).exists():
                print(f"File not found: {input_path}")
                return
            stats = brain_import(input_path)
            total_new = stats["memories_new"] + stats["entities_new"] + stats["facts_new"] + stats["passages_new"] + stats["patterns_new"]
            total_skip = stats["memories_skipped"] + stats["entities_skipped"] + stats["facts_skipped"] + stats["passages_skipped"] + stats["patterns_skipped"]
            print(f"Import complete:")
            print(f"  Memories:  {stats['memories_new']} new, {stats['memories_skipped']} skipped")
            print(f"  Entities:  {stats['entities_new']} new, {stats['entities_skipped']} skipped")
            print(f"  Facts:     {stats['facts_new']} new, {stats['facts_skipped']} skipped")
            print(f"  Passages:  {stats['passages_new']} new, {stats['passages_skipped']} skipped")
            print(f"  Patterns:  {stats['patterns_new']} new, {stats['patterns_skipped']} skipped")
            print(f"  Total: {total_new} imported, {total_skip} duplicates skipped")

        elif subcmd == "merge":
            if len(sys.argv) < 4:
                print("Usage: brain merge <git-url|local-path>")
                return
            source = sys.argv[3]
            try:
                stats = brain_merge(source)
                total_new = stats["memories_new"] + stats["entities_new"] + stats["facts_new"] + stats["passages_new"] + stats["patterns_new"]
                total_skip = stats["memories_skipped"] + stats["entities_skipped"] + stats["facts_skipped"] + stats["passages_skipped"] + stats["patterns_skipped"]
                print(f"Merge complete:")
                print(f"  Memories:  {stats['memories_new']} new, {stats['memories_skipped']} skipped")
                print(f"  Entities:  {stats['entities_new']} new, {stats['entities_skipped']} skipped")
                print(f"  Facts:     {stats['facts_new']} new, {stats['facts_skipped']} skipped")
                print(f"  Passages:  {stats['passages_new']} new, {stats['passages_skipped']} skipped")
                print(f"  Patterns:  {stats['patterns_new']} new, {stats['patterns_skipped']} skipped")
                print(f"  Total: {total_new} merged, {total_skip} duplicates skipped")
            except (RuntimeError, FileNotFoundError) as e:
                print(f"Merge failed: {e}")

        elif subcmd == "stats":
            s = brain_stats()
            print("=== Brain Statistics ===")
            print(f"  Memories:           {s['memories_total']}")
            if s.get("memories_by_type"):
                for t, c in s["memories_by_type"].items():
                    print(f"    {t}: {c}")
            if s.get("memories_by_class"):
                print(f"  Memory classes:")
                for cls, c in s["memories_by_class"].items():
                    print(f"    {cls}: {c}")
            print(f"  Entity links:       {s['entity_links']}")
            if s.get("entity_types"):
                for t, c in s["entity_types"].items():
                    print(f"    {t}: {c}")
            if s.get("top_relationships"):
                print(f"  Top relationships:")
                for r, c in s["top_relationships"].items():
                    print(f"    {r}: {c}")
            print(f"  Semantic facts:     {s['semantic_facts']}")
            print(f"  Memory passages:    {s['memory_passages']}")
            print(f"  Evolution patterns: {s['evolution_patterns']}")
            if s.get("patterns_by_status"):
                for st, c in s["patterns_by_status"].items():
                    print(f"    {st}: {c}")

        elif subcmd == "export-marketplace":
            output = None
            domain = ""
            creator = ""
            version = "1.0.0"
            if "--output" in sys.argv:
                idx = sys.argv.index("--output")
                if idx + 1 < len(sys.argv):
                    output = sys.argv[idx + 1]
            if "--domain" in sys.argv:
                idx = sys.argv.index("--domain")
                if idx + 1 < len(sys.argv):
                    domain = sys.argv[idx + 1]
            if "--creator" in sys.argv:
                idx = sys.argv.index("--creator")
                if idx + 1 < len(sys.argv):
                    creator = sys.argv[idx + 1]
            if "--version" in sys.argv:
                idx = sys.argv.index("--version")
                if idx + 1 < len(sys.argv):
                    version = sys.argv[idx + 1]
            if not output:
                output = str(AIBRAIN_ROOT / "marketplace_brain.db")
            from aibrain.core.memory_api import Brain
            brain = Brain()
            path = brain.export_marketplace(output, domain=domain, creator_agent=creator, version=version)
            # Read manifest from exported DB for summary
            import sqlite3 as _sq
            _ec = _sq.connect(path)
            _ec.row_factory = _sq.Row
            _m = dict(_ec.execute("SELECT * FROM brain_manifest").fetchone())
            _mem_ct = _ec.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
            _ent_ct = _ec.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
            _link_ct = _ec.execute("SELECT COUNT(*) FROM entity_links").fetchone()[0]
            _fact_ct = _ec.execute("SELECT COUNT(*) FROM semantic_facts").fetchone()[0]
            _cat_ct = _ec.execute("SELECT COUNT(*) FROM category_summaries").fetchone()[0]
            _emb_ct = _ec.execute("SELECT COUNT(*) FROM memory_embeddings").fetchone()[0]
            _sz = os.path.getsize(path)
            _ec.close()
            print(f"Marketplace brain exported to: {path}")
            print(f"  Memories:    {_mem_ct}")
            print(f"  Embeddings:  {_emb_ct}")
            print(f"  Entities:    {_ent_ct}")
            print(f"  Links:       {_link_ct}")
            print(f"  Facts:       {_fact_ct}")
            print(f"  Summaries:   {_cat_ct}")
            print(f"  Quality:     {_m['quality_score']:.4f}")
            print(f"  Size:        {_sz / 1024:.0f} KB")
            print(f"  Version:     {_m['version']}")

        elif subcmd == "sync":
            # brain sync --push | --pull | --repo <url>
            # Push: export brain → commit → push to shared brain repo
            # Pull: pull from shared brain repo → import new memories
            sync_repo = os.environ.get("BRAIN_SYNC_REPO", "")
            sync_dir = Path(os.environ.get("BRAIN_SYNC_DIR", AIBRAIN_ROOT / ".brain-sync"))

            if "--repo" in sys.argv:
                idx = sys.argv.index("--repo")
                if idx + 1 < len(sys.argv):
                    sync_repo = sys.argv[idx + 1]

            if not sync_repo:
                print("No sync repo configured.")
                print("Set BRAIN_SYNC_REPO env var or use: brain sync --repo <git-url> --push|--pull")
                return

            if "--push" in sys.argv:
                # Clone or pull the sync repo
                if not sync_dir.exists():
                    print(f"Cloning brain sync repo: {sync_repo}")
                    result = subprocess.run(["git", "clone", sync_repo, str(sync_dir)],
                                            capture_output=True, text=True)
                    if result.returncode != 0:
                        print(f"Clone failed: {result.stderr.strip()}")
                        return
                else:
                    subprocess.run(["git", "-C", str(sync_dir), "pull", "--rebase"],
                                   capture_output=True, text=True)

                # Export brain into sync dir
                agent_name = config_get("agent_name", "unknown")
                export_file = sync_dir / f"brain_{agent_name}.json"
                brain_export(str(export_file))
                print(f"Exported brain to: {export_file}")

                # Commit and push
                subprocess.run(["git", "-C", str(sync_dir), "add", "-A"],
                               capture_output=True, text=True)
                msg = f"Brain sync: {agent_name} @ {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}"
                result = subprocess.run(
                    ["git", "-C", str(sync_dir), "commit", "-m", msg],
                    capture_output=True, text=True)
                if "nothing to commit" in result.stdout:
                    print("Brain unchanged — nothing to push.")
                    return
                result = subprocess.run(["git", "-C", str(sync_dir), "push"],
                                        capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"Brain pushed to {sync_repo}")
                else:
                    print(f"Push failed: {result.stderr.strip()}")

            elif "--pull" in sys.argv:
                # Clone or pull
                if not sync_dir.exists():
                    print(f"Cloning brain sync repo: {sync_repo}")
                    result = subprocess.run(["git", "clone", sync_repo, str(sync_dir)],
                                            capture_output=True, text=True)
                    if result.returncode != 0:
                        print(f"Clone failed: {result.stderr.strip()}")
                        return
                else:
                    subprocess.run(["git", "-C", str(sync_dir), "pull", "--rebase"],
                                   capture_output=True, text=True)

                # Import all brain files except our own
                agent_name = config_get("agent_name", "unknown")
                imported = 0
                for brain_file in sync_dir.glob("brain_*.json"):
                    if agent_name in brain_file.stem:
                        continue  # Skip our own export
                    print(f"Importing: {brain_file.name}")
                    stats = brain_import(str(brain_file))
                    new = stats["memories_new"] + stats["entities_new"] + stats["facts_new"]
                    skip = stats["memories_skipped"] + stats["entities_skipped"] + stats["facts_skipped"]
                    print(f"  {new} new, {skip} skipped")
                    imported += new
                print(f"Sync pull complete: {imported} total new items imported")

            else:
                print("Usage: brain sync --push|--pull [--repo <git-url>]")
                print("  --push   Export local brain, commit+push to shared repo")
                print("  --pull   Pull from shared repo, import other agents' brains")
                print("  --repo   Git URL (or set BRAIN_SYNC_REPO env var)")

        else:
            print(f"Unknown brain subcommand: {subcmd}")
            print("Usage: brain export | brain import <file> | brain merge <url|path> | brain sync --push|--pull | brain stats")

    elif cmd == "satellite":
        if len(sys.argv) < 3:
            print("Usage: satellite create \"I have lots of security scan results\"")
            print("       satellite health                     # Check if main DB needs splitting")
            print("       satellite register <name> <db_path> [--types type1,type2] [--keywords kw1,kw2]")
            print("       satellite list")
            print("       satellite stats <name>")
            print("       satellite search <name> <query>")
            print("       satellite migrate <name> [--type finding]")
            print("       satellite dedup <name>                    # Remove duplicate records")
            return
        subcmd = sys.argv[2]

        if subcmd == "create":
            # Natural language satellite creation
            if len(sys.argv) < 4:
                print("Usage: satellite create \"I have lots of security scan results\"")
                print("       Matches your description to a satellite template and creates it.")
                return
            text = " ".join(sys.argv[3:])
            matches = satellite_suggest_from_text(text)
            if not matches:
                print(f"Could not match \"{text}\" to a known satellite type.")
                print("Available types: security, research, benchmarks, logs, trading, notes")
                print("Or use: satellite register <name> <db_path> --types ... --keywords ...")
                return
            # Show matches and let user confirm
            print(f"Matched \"{text}\" to:")
            for i, (key, tmpl) in enumerate(matches[:3], 1):
                existing = {s["name"] for s in satellite_list()}
                status = " (already registered)" if tmpl["name"] in existing else ""
                print(f"  {i}. {tmpl['desc']}{status}")
                print(f"     DB: {tmpl['db_path']} | Types: {tmpl['types']}")
            result = satellite_create_from_text(text)
            if result:
                if result["status"] == "already_exists":
                    print(f"\n{result['message']}")
                else:
                    print(f"\nCreated satellite '{result['name']}' ({result['db_path']})")
                    print(f"  Types routed: {result['types']}")
                    print(f"  Search triggers: {result['keywords'][:80]}...")
                    print(f"\nNew memories of type {result['types']} will auto-route here.")
                    print(f"To migrate existing: satellite migrate {result['name']} --type {result['types'][0]}")

        elif subcmd == "health":
            # Check if main DB needs splitting
            check = satellite_health_check()
            if not check:
                total = get_db().execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
                print(f"Main DB healthy: {total} active memories (threshold: {SATELLITE_SUGGEST_THRESHOLD})")
                return
            print(check["message"])
            print()
            for s in check["suggestions"]:
                tmpl_name = s["template"]["name"] if s["template"] else f"{s['type']}_archive"
                print(f"  Type '{s['type']}': {s['count']} memories ({s['pct']}% of total)")
                print(f"    Suggested satellite: {tmpl_name}")
            print()
            print("To apply: satellite migrate <name> --type <type>")
            print("Or: satellite create \"description of your data\"")

        elif subcmd == "register":
            if len(sys.argv) < 5:
                print("Usage: satellite register <name> <db_path> [--types type1,type2] [--keywords kw1,kw2]")
                return
            name = sys.argv[3]
            db_path = sys.argv[4]
            types = []
            keywords = ""
            if "--types" in sys.argv:
                idx = sys.argv.index("--types")
                if idx + 1 < len(sys.argv):
                    types = [t.strip() for t in sys.argv[idx + 1].split(",")]
            if "--keywords" in sys.argv:
                idx = sys.argv.index("--keywords")
                if idx + 1 < len(sys.argv):
                    keywords = sys.argv[idx + 1]
            sid = satellite_register(name, db_path, f"Satellite DB: {name}", types, keywords)
            print(f"Registered satellite '{name}' (id={sid})")
            print(f"  DB path: {db_path}")
            print(f"  Routed types: {types}")
            print(f"  Search keywords: {keywords}")

        elif subcmd == "list":
            sats = satellite_list()
            if not sats:
                print("No satellite databases registered.")
            else:
                print(f"Satellite databases ({len(sats)}):")
                for s in sats:
                    types = json.loads(s.get("memory_types", "[]"))
                    print(f"  {s['name']}: {s['db_path']}")
                    print(f"    Types: {types}  Keywords: {s.get('search_keywords', '')}")

        elif subcmd == "stats" and len(sys.argv) > 3:
            name = sys.argv[3]
            try:
                s = satellite_stats(name)
                print(f"Satellite '{name}':")
                print(f"  Total memories: {s['total']}")
                for t, c in s.get("by_type", {}).items():
                    print(f"    {t}: {c}")
                if "db_size_kb" in s:
                    print(f"  DB size: {s['db_size_kb']}KB")
            except ValueError as e:
                print(f"Error: {e}")

        elif subcmd == "search" and len(sys.argv) > 4:
            name = sys.argv[3]
            query = " ".join(sys.argv[4:])
            try:
                results = satellite_search(name, query)
                print(f"Search '{query}' in satellite '{name}' — {len(results)} results")
                for r in results[:10]:
                    print(f"  #{r['id']} {r.get('name', '?')}: {r.get('content', '')[:80]}")
            except ValueError as e:
                print(f"Error: {e}")

        elif subcmd == "migrate" and len(sys.argv) > 3:
            name = sys.argv[3]
            type_filter = "finding"
            if "--type" in sys.argv:
                idx = sys.argv.index("--type")
                if idx + 1 < len(sys.argv):
                    type_filter = sys.argv[idx + 1]
            print(f"Migrating type='{type_filter}' from main DB to satellite '{name}'...")
            stats = migrate_to_satellite(name, type_filter)
            print(f"Done: {stats['moved']}/{stats['total']} moved, {stats['skipped']} dupes skipped")

        elif subcmd == "dedup" and len(sys.argv) > 3:
            name = sys.argv[3]
            print(f"Deduplicating satellite '{name}'...")
            stats = dedup_satellite(name)
            print(f"Done: removed {stats['removed']} duplicates, {stats['remaining']} remain")

        else:
            print(f"Unknown satellite subcommand: {subcmd}")

    else:
        print(f"Unknown command: {cmd}")


if __name__ == "__main__":
    main()
