"""`weave thread create / pluck / reply / done / close / wont-do / list / show / update`.

Implements the tracker thread workflow that CLAUDE.md / GEMINI.md / AGENTS.md §4.10
established as the canonical "what's being worked on" surface for every agent
session. The weave-tracker skill (`plugin/skills/weave-tracker/SKILL.md`) describes
the full workflow; this module is the CLI surface that backs it.

Usage examples:

    # File a thread for the work this session is doing
    weave thread create \\
      --project powerloom \\
      --title "Fix Alfred WS connection" \\
      --priority high \\
      --description "..."

    # Claim it (sets status=in_progress)
    weave thread pluck <thread_id>

    # As decisions/blockers land, post replies
    weave thread reply <thread_id> "decided to go with option B because ..."
    weave thread reply <thread_id> --from-stdin < notes.md

    # At PR merge, close out
    weave thread done <thread_id>      # the work shipped
    weave thread close <thread_id>     # thread closed but scope might still matter
    weave thread wont-do <thread_id>   # decided not to ship

    # Find work
    weave thread list --mine                                # what you're on
    weave thread list --project powerloom --status open     # available work
    weave thread show <thread_id>                            # full detail + replies

    # Generic update (status / priority / assignee / metadata)
    weave thread update <thread_id> --status review
    weave thread update <thread_id> --priority critical
    weave thread update <thread_id> --assigned-to <user-uuid>

Project addressing accepts either the slug (`powerloom`) or a UUID. Slug is
resolved via GET /projects + linear lookup — fine for the small project counts
expected. If the lookup misses, raises typer.Exit(1) with a list of available
slugs.

Output rendering matches the `import_project_cmd.py` pattern: terse, rich-
styled lines for command output; tables for list views; full pretty-print for
show. JSON output via --json flag for scripting.
"""
from __future__ import annotations

import json as _json
import os
import sys
import time
import uuid
from collections import Counter
from datetime import datetime, timezone
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table

from loomcli.client import PowerloomApiError, PowerloomClient
from loomcli.config import is_agent_mode, is_json_output, load_runtime_config


app = typer.Typer(help="Manage Powerloom tracker threads (create / pluck / reply / done / list / show / update). See CLAUDE.md / GEMINI.md / AGENTS.md §4.10.")

# Friendly-names L4 — auto-stamp session_attribution into metadata_json on
# create + reply when the caller has registered a sub-principal for this
# session. Env-driven opt-in: the SessionStart hook (Powerloom #142 M3) +
# CC plugin set POWERLOOM_ACTIVE_SUBPRINCIPAL_ID; the CLI lazy-fetches the
# sub-principal details once per command invocation and stamps the metadata.
# When the env var is absent (most current callers), no stamp is added —
# zero behavior change for direct human users.
SUBPRINCIPAL_ENV_VAR = "POWERLOOM_ACTIVE_SUBPRINCIPAL_ID"


def _resolve_active_subprincipal_id() -> Optional[str]:
    """Pick the active sub-principal UUID for this session, with three-tier
    resolution:

      1. `POWERLOOM_ACTIVE_SUBPRINCIPAL_ID` env var — explicit override,
         wins when set (and non-empty). Same as v0.6.4-rc1 behavior.
      2. Per-scope cache file at `<config_dir>/active-subprincipal-<scope>.txt` —
         written by `weave agent-session register`. Fallback because
         shell SessionStart hooks can't propagate env to the parent
         shell, so the env-var-only path is a no-op for every real
         agent session today (verified in the v067 onboarding sprint).
      3. Global attribution lookup (v068+) — if we are in an active
         Gemini/Claude session (GEMINI_CLI=1 or CLAUDE_CODE=1) but no
         branch scope is known, scan for an active session with our
         actor_kind and use that.

    `<scope>` is derived from the current git branch via the
    `session/<scope>-<yyyymmdd>` convention. Branches that don't match
    return None for the file path → fall through to "no attribution"
    (graceful degradation; old behavior).

    Returns None when neither source resolves.
    """
    # Tier 1 — env var
    env_id = os.environ.get(SUBPRINCIPAL_ENV_VAR, "").strip()
    if env_id:
        return env_id

    # Tier 2 — per-scope cache file (git-heavy)
    import subprocess as _subprocess
    branch = None
    try:
        result = _subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True, text=True, timeout=5,
        )
        branch = (result.stdout or "").strip()
    except (FileNotFoundError, _subprocess.TimeoutExpired):
        pass

    if branch and branch.startswith("session/"):
        scope = branch[len("session/"):]
        if scope:
            from loomcli.config import active_subprincipal_file
            path = active_subprincipal_file(scope)
            if path.exists():
                try:
                    cached = path.read_text(encoding="utf-8").strip()
                    uuid.UUID(cached)
                    return cached
                except (OSError, ValueError, TypeError):
                    pass

    # Tier 3 — Global fallback for non-git or non-standard branch sessions
    # if we are explicitly in agent mode.
    if os.environ.get("GEMINI_CLI") or os.environ.get("CLAUDE_CODE") or os.environ.get("AGENT_MODE"):
        # We don't have a scope-file, but we are an agent.
        # We could hit /agent-sessions to find our session, but for now
        # we stick to the local caches to avoid extra latency on every
        # thread reply.
        pass

    return None


def _build_session_attribution(client: PowerloomClient) -> Optional[dict]:
    """Fetch the active sub-principal's details and assemble the
    session_attribution payload to merge into metadata_json.

    Resolution order (see `_resolve_active_subprincipal_id`):
      1. `POWERLOOM_ACTIVE_SUBPRINCIPAL_ID` env var
      2. Per-scope cache file written by `weave agent-session register`

    Returns None when:
    - Neither source resolves a sub-principal id (most direct-human callers)
    - The sub-principal lookup against /me/agents fails (logged + continues)

    The shape matches what the dogfood scripts have been writing manually so
    queries (e.g. "find threads attributed to Claude Code sessions") work
    against both old (manually-stamped) and new (auto-stamped) threads.
    """
    sp_id = _resolve_active_subprincipal_id()
    if not sp_id:
        return None
    try:
        sp = client.get(f"/me/agents/{sp_id}")
    except PowerloomApiError as e:
        # Best-effort. Log + continue without stamping rather than failing
        # the create/reply call. The user can debug separately if attribution
        # is missing.
        _console.print(
            f"[yellow]Warning:[/yellow] could not fetch sub-principal "
            f"{sp_id} for attribution stamp: {e.status_code}. Thread will "
            f"be created without session_attribution metadata.",
            highlight=False,
        )
        return None
    return {
        "subprincipal_id": sp.get("id"),
        "subprincipal_principal_id": sp.get("principal_id"),
        "subprincipal_name": sp.get("name"),
        "client_kind": sp.get("client_kind"),
        "parent_user_id": sp.get("user_id"),
        "stamped_at": datetime.now(timezone.utc).isoformat(),
    }


def _maybe_stamp_attribution(
    client: PowerloomClient,
    thread: dict,
    no_attribution: bool,
) -> dict:
    """If the caller has an active sub-principal, PATCH the thread's
    metadata_json to add session_attribution. Returns the (possibly updated)
    thread dict so callers can use it without a re-fetch.

    No-op (returns the input thread unchanged) when disabled, env-unset, or
    the sub-principal lookup fails.
    """
    if no_attribution:
        return thread
    attribution = _build_session_attribution(client)
    if not attribution:
        return thread
    try:
        # Use the in-memory `thread` rather than re-fetching — the engine
        # just returned it from create/pluck so it's authoritative + fresh.
        meta = dict(thread.get("metadata_json") or {})
        meta["session_attribution"] = attribution
        return client.patch(f"/threads/{thread['id']}", {"metadata_json": meta})
    except PowerloomApiError as e:
        _console.print(
            f"[yellow]Warning:[/yellow] thread created/updated but "
            f"attribution stamp failed: {e}. Run `weave thread show {thread['id']}` "
            f"to verify state.",
            highlight=False,
        )
        return thread
_console = Console()

# Status enum — must match engine's tracker_thread.status. Kept locally so the
# CLI can validate before round-tripping to the engine. If the enum drifts the
# engine returns 422 and the user sees the engine's message verbatim.
_STATUS_CHOICES = ("open", "in_progress", "blocked", "review", "needs_client_review", "done", "closed", "wont_do")
_PRIORITY_CHOICES = ("critical", "high", "medium", "low", "none")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _client_or_exit() -> PowerloomClient:
    cfg = load_runtime_config()
    if not cfg.access_token:
        _console.print("[yellow]Not signed in — run `weave login` first.[/yellow]")
        raise typer.Exit(1)
    return PowerloomClient(cfg)


def _resolve_project(client: PowerloomClient, project: str) -> str:
    """Accept either a project slug or UUID; return the UUID.

    UUID detection is lazy — try uuid.UUID() and fall back to slug lookup.
    Slug lookup queries GET /projects and linear-scans. Fine for small counts.
    """
    try:
        # Already a UUID — use it directly
        return str(uuid.UUID(project))
    except ValueError:
        pass

    # Slug — look up
    try:
        projects = client.get("/projects")
    except PowerloomApiError as e:
        _console.print(f"[red]Could not list projects:[/red] {e}")
        raise typer.Exit(1) from None

    items = projects if isinstance(projects, list) else (projects.get("items") or projects.get("projects") or [])
    for p in items:
        if isinstance(p, dict) and p.get("slug") == project:
            return p["id"]

    available = sorted({p.get("slug", "?") for p in items if isinstance(p, dict)})
    _console.print(f"[red]No project with slug {project!r} found.[/red]")
    if available:
        _console.print(f"[dim]Available slugs: {', '.join(available)}[/dim]")
    raise typer.Exit(1)


def _infer_project_from_cwd() -> Optional[str]:
    """W1.5.1 — Infer project slug from current working directory."""
    try:
        cwd = str(os.getcwd()).replace("\\", "/")
        if "/ui/" in cwd or cwd.endswith("/ui"):
            return "powerloom-ui"
    except Exception:
        pass
    return None


def _resolve_thread(
    client: PowerloomClient,
    ref: str,
    *,
    default_project: Optional[str] = None,
) -> str:
    """W1.5.1 — Accept either a thread UUID, a short 8-char ID, a `project:slug`
    pair, or a bare slug; return the thread UUID.

    Examples:
        "8d2c7502-d79a-..."   -> direct UUID, no lookup
        "d514a54b"            -> short ID lookup (8 chars, hex)
        "powerloom:ki-004"    -> resolve project 'powerloom', GET by-slug
        "ki-004"              -> use default project (profile or cwd), GET by-slug

    Short ID lookup hits GET /projects/{project_id}/threads?limit=100 and
    scans prefixes. Slug lookup hits GET /projects/{project_id}/threads/by-slug/{slug}.
    """
    # 1. UUID — fast path, no network
    try:
        return str(uuid.UUID(ref))
    except ValueError:
        pass

    # Determine default project context
    cfg = load_runtime_config()
    final_default = (
        default_project
        or cfg.default_project
        or _infer_project_from_cwd()
        or "powerloom"
    )

    # 2. Slug form — split out project context if present
    if ":" in ref:
        project_part, _, slug_part = ref.partition(":")
        project_part = project_part.strip()
        slug_part = slug_part.strip()
        if not project_part or not slug_part:
            _console.print(
                f"[red]Invalid thread reference {ref!r}.[/red] "
                "Expected `project-slug:thread-slug`, `thread-slug`, or a UUID."
            )
            raise typer.Exit(2)
    else:
        project_part = final_default
        slug_part = ref.strip()

    project_id = _resolve_project(client, project_part)

    # 3. Short ID resolution (8-char hex prefix)
    import re as _re_mod
    if len(slug_part) == 8 and _re_mod.match(r"^[0-9a-f]{8}$", slug_part):
        try:
            # Query recent threads for this project to resolve prefix
            threads = client.get(f"/projects/{project_id}/threads", limit=100)
            rows = _rows_from_response(threads)
            matches = [t for t in rows if str(t.get("id")).startswith(slug_part)]
            if len(matches) == 1:
                return str(matches[0]["id"])
            if len(matches) > 1:
                _console.print(f"[red]Multiple threads match short ID {slug_part!r}:[/red]")
                for m in matches:
                    _console.print(f"  [dim]{m.get('id')}  {m.get('title')}[/dim]")
                raise typer.Exit(1)
            # No match? Fall through to slug lookup just in case it's a slug
            # that happens to be 8-char hex.
        except PowerloomApiError:
            pass

    # 4. Slug lookup
    if not _re_mod.match(r"^[a-z0-9][a-z0-9-]{0,62}$", slug_part):
        _console.print(
            f"[red]Invalid slug shape {slug_part!r}.[/red] "
            "Slugs are lowercase alphanumeric + hyphens, 1-63 chars."
        )
        raise typer.Exit(2)

    try:
        thread = client.get(f"/projects/{project_id}/threads/by-slug/{slug_part}")
    except PowerloomApiError as e:
        if e.status_code == 404:
            _console.print(
                f"[red]No thread with slug or short ID {slug_part!r} in project "
                f"{project_part!r}.[/red]"
            )
        else:
            _console.print(f"[red]Thread lookup failed:[/red] {e}")
        raise typer.Exit(1) from None
    return str(thread["id"])


def _print_thread_summary(t: dict) -> None:
    """Render a single-thread summary line. Used by create / pluck / done / etc.
    after a mutation lands so the user sees the new state."""
    status = t.get("status", "?")
    priority = t.get("priority", "?")
    title = t.get("title", "(no title)")
    sp_name = ((t.get("metadata_json") or {}).get("session_attribution") or {}).get("subprincipal_name")
    suffix = f" [dim]· {sp_name}[/dim]" if sp_name else ""
    _console.print(f"  [bold]{title}[/bold]{suffix}")
    _console.print(f"  [dim]id={t.get('id')} status={status} priority={priority}[/dim]")


def _output_json(data) -> None:
    """Print data as JSON for --json flag. Handles UUIDs + datetimes."""
    print(_json.dumps(data, indent=2, default=str))


def _rows_from_response(items) -> list[dict]:
    rows = items if isinstance(items, list) else (items.get("items") or items.get("threads") or [])
    return [row for row in rows if isinstance(row, dict)]


def _print_thread_table(rows: list[dict]) -> None:
    table = Table(show_header=True, header_style="bold")
    table.add_column("Status", style="cyan")
    table.add_column("Pri")
    table.add_column("Title", overflow="fold", ratio=3)
    table.add_column("Slug", overflow="fold")
    table.add_column("Owner", overflow="fold")
    table.add_column("ID", overflow="fold")
    for t in rows:
        sp = ((t.get("metadata_json") or {}).get("session_attribution") or {}).get("subprincipal_name") or ""
        owner = sp[:24] if sp else (t.get("assigned_to") or "")[:8]
        table.add_row(
            t.get("status", "?"),
            t.get("priority", "?"),
            t.get("title", "")[:60],
            t.get("slug", "")[:25],
            owner,
            (t.get("id") or "")[:8],
        )
    _console.print(table)
    _console.print(f"[dim]{len(rows)} thread(s)[/dim]")


def _my_work_watch_line(rows: list[dict]) -> str:
    counts = Counter(str(row.get("status", "unknown")) for row in rows)
    counts_text = ", ".join(f"{key}={value}" for key, value in sorted(counts.items()))
    if not counts_text:
        counts_text = "none"
    top = rows[0] if rows else {}
    top_label = ""
    if top:
        top_label = (
            f" | top={top.get('status', '')} "
            f"{str(top.get('title', ''))[:80]}"
        )
    return f"my-work total={len(rows)} statuses={counts_text}{top_label}"


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


def _default_project() -> str:
    """W1.5.1 — Dynamic default project from profile or CWD."""
    cfg = load_runtime_config()
    return cfg.default_project or _infer_project_from_cwd() or "powerloom"


@app.command("create")
def create(
    title: Annotated[str, typer.Option("--title", "-t", help="Imperative phrase. e.g. 'Fix Alfred WS connection'.")],
    project: Annotated[str, typer.Option("--project", "-p", help="Project slug (e.g. 'powerloom') or UUID.")] = None,
    priority: Annotated[str, typer.Option("--priority", help="One of: critical, high, medium, low, none.")] = "medium",
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="Body text. Markdown supported.")] = None,
    description_from_stdin: Annotated[bool, typer.Option("--description-from-stdin", help="Read description from stdin (useful for long content).")] = False,
    milestone_id: Annotated[Optional[str], typer.Option("--milestone-id", help="UUID of an existing milestone in the project.")] = None,
    assigned_to: Annotated[Optional[str], typer.Option("--assigned-to", help="UUID of the user to assign. Default: unassigned.")] = None,
    tag_ids: Annotated[Optional[list[str]], typer.Option("--tag-id", help="Tag UUIDs (repeatable).")] = None,
    id_only: Annotated[bool, typer.Option("--id-only", help="Only print the UUID of the created thread.")] = False,
    slug_only: Annotated[bool, typer.Option("--slug-only", help="Only print the slug of the created thread.")] = False,
    no_attribution: Annotated[
        bool,
        typer.Option(
            "--no-attribution",
            help=(
                "Skip session_attribution metadata stamping even when "
                "POWERLOOM_ACTIVE_SUBPRINCIPAL_ID is set. By default, when the "
                "env var is present, the CLI auto-fetches the sub-principal's "
                "details and writes session_attribution into metadata_json."
            ),
        ),
    ] = False,
) -> None:
    """Create a new tracker thread.

    Per CLAUDE.md §4.10, file a thread at session start (or as soon as work
    scope is known). Title should be an imperative phrase; description should
    follow the canonical four-section shape (Reported / Repro / Definition of
    done / Out of scope). See the weave-tracker skill for the description
    template.

    **Friendly-names L4 — auto-attribution.** When the
    `POWERLOOM_ACTIVE_SUBPRINCIPAL_ID` env var is set (e.g. by a CC SessionStart
    hook or CI runner), the new thread's `metadata_json.session_attribution` is
    populated automatically with the sub-principal's id / name / client_kind /
    parent_user_id + a stamped_at timestamp. Pass `--no-attribution` to suppress
    even when the env is set.
    """
    final_project = project or _default_project()
    if priority not in _PRIORITY_CHOICES:
        _console.print(f"[red]Invalid priority {priority!r}.[/red] One of: {', '.join(_PRIORITY_CHOICES)}")
        raise typer.Exit(2)

    if description_from_stdin:
        if description:
            _console.print("[red]Pick one of --description / --description-from-stdin (not both).[/red]")
            raise typer.Exit(2)
        description = sys.stdin.read()

    body: dict = {
        "title": title,
        "priority": priority,
        "description": description or "",
    }
    if milestone_id:
        body["milestone_id"] = milestone_id
    if assigned_to:
        body["assigned_to"] = assigned_to
    if tag_ids:
        body["tag_ids"] = tag_ids

    with _client_or_exit() as client:
        project_id = _resolve_project(client, final_project)
        try:
            thread = client.post(f"/projects/{project_id}/threads", body)
        except PowerloomApiError as e:
            _console.print(f"[red]Create failed:[/red] {e}")
            raise typer.Exit(1) from None

        # L4 auto-stamp — returns the patched thread (or the original if no-op)
        # so the JSON / summary output reflects the stamped metadata.
        thread = _maybe_stamp_attribution(client, thread, no_attribution)

    if id_only:
        _console.print(thread["id"])
        return
    if slug_only:
        _console.print(thread.get("slug") or "")
        return

    if is_json_output():
        _output_json(thread)
        return

    _console.print(f"[green]Thread created.[/green]")
    _print_thread_summary(thread)
    _console.print(f"  [dim]Next: weave thread pluck {thread.get('id')}[/dim]")


# ---------------------------------------------------------------------------
# pluck
# ---------------------------------------------------------------------------


@app.command("pluck")
def pluck(
    thread_id: Annotated[str, typer.Argument(help="Thread reference: UUID, slug (e.g. 'ki-004'), or 'project:slug' (e.g. 'powerloom:ki-004').")],
    agent_id: Annotated[Optional[str], typer.Option("--agent-id", help="Optional Agent UUID to attribute the pluck to (for hosted-agent claiming).")] = None,
) -> None:
    """Claim a thread for the current session (sets status=in_progress).

    Pluck is one-shot — re-plucking returns 409. To take over a thread someone
    else plucked, use `weave thread update <id> --assigned-to <principal>`.
    """
    pluck_body: dict = {}
    if agent_id:
        pluck_body["agent_id"] = agent_id

    with _client_or_exit() as client:
        thread_uuid = _resolve_thread(client, thread_id)
        try:
            thread = client.post(f"/threads/{thread_uuid}/pluck", pluck_body)
        except PowerloomApiError as e:
            if e.status_code == 409:
                _console.print(f"[yellow]Thread already plucked.[/yellow] Run `weave thread show {thread_uuid}` to see who has it.")
            else:
                _console.print(f"[red]Pluck failed:[/red] {e}")
            raise typer.Exit(1) from None

    if is_json_output():
        _output_json(thread)
        return
    _console.print(f"[green]Plucked.[/green]")
    _print_thread_summary(thread)


# ---------------------------------------------------------------------------
# reply
# ---------------------------------------------------------------------------


@app.command("reply")
def reply(
    thread_id: Annotated[str, typer.Argument(help="Thread reference: UUID, slug, or 'project:slug'.")],
    content: Annotated[Optional[str], typer.Argument(help="Reply text. Use --from-stdin for long content.")] = None,
    from_stdin: Annotated[bool, typer.Option("--from-stdin", help="Read reply content from stdin.")] = False,
    reply_type: Annotated[str, typer.Option("--type", help="Reply kind: comment, system, import_source.")] = "comment",
    no_attribution: Annotated[
        bool,
        typer.Option(
            "--no-attribution",
            help="Skip session_attribution metadata stamping (see `weave thread create --help`).",
        ),
    ] = False,
) -> None:
    """Post a reply to a thread (decisions, blockers, scope changes).

    Use replies for moments future-you would want to see. Don't use them for
    progress narration — that's session noise, not durable signal.

    **Friendly-names L4 — auto-attribution.** When `POWERLOOM_ACTIVE_SUBPRINCIPAL_ID`
    is set, the reply's metadata_json carries `session_attribution` so the
    audit trail shows "who wrote this reply" at sub-principal granularity.
    Pass `--no-attribution` to suppress.
    """
    if from_stdin:
        if content:
            _console.print("[red]Pick one of <content> / --from-stdin (not both).[/red]")
            raise typer.Exit(2)
        content = sys.stdin.read()
    if not content:
        _console.print("[red]Reply content is required (positional arg or --from-stdin).[/red]")
        raise typer.Exit(2)

    body: dict = {"content": content, "reply_type": reply_type}
    with _client_or_exit() as client:
        thread_uuid = _resolve_thread(client, thread_id)
        # L4 auto-stamp — for replies, attribution lives on the reply's own
        # metadata_json (set at create time, not via PATCH afterward; the
        # ReplyCreate schema accepts the field directly).
        if not no_attribution:
            attribution = _build_session_attribution(client)
            if attribution:
                body["metadata_json"] = {"session_attribution": attribution}
        try:
            reply_obj = client.post(f"/threads/{thread_uuid}/replies", body)
        except PowerloomApiError as e:
            _console.print(f"[red]Reply failed:[/red] {e}")
            raise typer.Exit(1) from None

    if is_json_output():
        _output_json(reply_obj)
        return
    _console.print(f"[green]Reply posted.[/green] [dim]id={reply_obj.get('id')}[/dim]")


# ---------------------------------------------------------------------------
# status verbs (done / close / wont-do)
# ---------------------------------------------------------------------------


def _resolve_reason(
    reason: Optional[str], reason_from_stdin: bool
) -> Optional[str]:
    """Pick the reason text from --reason or --reason-from-stdin, with the
    same xor/required guard as --description / --description-from-stdin in
    create + reply. Returns None when neither is supplied (no reason flow)."""
    if reason_from_stdin:
        if reason:
            _console.print(
                "[red]Pick one of --reason / --reason-from-stdin (not both).[/red]"
            )
            raise typer.Exit(2)
        text = sys.stdin.read()
        if not text.strip():
            _console.print("[red]--reason-from-stdin received empty input.[/red]")
            raise typer.Exit(2)
        return text
    return reason


def _set_status(
    thread_id: str,
    status: str,
    reason: Optional[str] = None,
    no_attribution: bool = False,
) -> None:
    """Patch the thread's status. When --reason is provided, follow the patch
    with a reply carrying the rationale — same audit trail you'd get from
    running 'thread <verb>' + 'thread reply' separately, but in a single
    command. The two API calls aren't atomic on the engine yet (separate
    threads can interleave); on a reply failure after a successful patch we
    still exit 0 with the patched status but print a warning so the user can
    re-issue the reply manually if they want."""
    with _client_or_exit() as client:
        thread_uuid = _resolve_thread(client, thread_id)
        try:
            thread = client.patch(f"/threads/{thread_uuid}", {"status": status})
        except PowerloomApiError as e:
            _console.print(f"[red]Status update failed:[/red] {e}")
            raise typer.Exit(1) from None
        reply_obj: Optional[dict] = None
        reply_warning: Optional[str] = None
        if reason:
            body: dict = {"content": reason, "reply_type": "comment"}
            if not no_attribution:
                attribution = _build_session_attribution(client)
                if attribution:
                    body["metadata_json"] = {"session_attribution": attribution}
            try:
                reply_obj = client.post(f"/threads/{thread_uuid}/replies", body)
            except PowerloomApiError as e:
                reply_warning = (
                    f"Status set to {status!r} but the reason-reply failed: {e}. "
                    f"Re-run `weave thread reply {thread_uuid} '<reason>'` to add it."
                )

    if is_json_output():
        payload: dict = {"thread": thread}
        if reply_obj is not None:
            payload["reply"] = reply_obj
        if reply_warning is not None:
            payload["warning"] = reply_warning
        _output_json(payload)
        return
    _console.print(f"[green]Status set to {status}.[/green]")
    _print_thread_summary(thread)
    if reply_obj is not None:
        _console.print(f"[dim]Reason posted as reply id={reply_obj.get('id')}.[/dim]")
    if reply_warning is not None:
        _console.print(f"[yellow]{reply_warning}[/yellow]")


_REASON_HELP = (
    "Closure / completion rationale — posted as a reply alongside the "
    "status change so the audit trail carries the 'why', not just the 'what'."
)
_REASON_STDIN_HELP = "Read --reason content from stdin (useful for long content)."
_NO_ATTRIBUTION_HELP = (
    "Skip session_attribution metadata stamping on the rationale reply "
    "(only relevant with --reason; mirrors the create / reply flag)."
)


@app.command("done")
def done(
    thread_id: Annotated[str, typer.Argument()],
    reason: Annotated[Optional[str], typer.Option("--reason", help=_REASON_HELP)] = None,
    reason_from_stdin: Annotated[
        bool, typer.Option("--reason-from-stdin", help=_REASON_STDIN_HELP)
    ] = False,
    no_attribution: Annotated[
        bool, typer.Option("--no-attribution", help=_NO_ATTRIBUTION_HELP)
    ] = False,
) -> None:
    """Mark a thread as done — the work shipped."""
    resolved = _resolve_reason(reason, reason_from_stdin)
    _set_status(thread_id, "done", resolved, no_attribution)


@app.command("close")
def close(
    thread_id: Annotated[str, typer.Argument()],
    reason: Annotated[Optional[str], typer.Option("--reason", help=_REASON_HELP)] = None,
    reason_from_stdin: Annotated[
        bool, typer.Option("--reason-from-stdin", help=_REASON_STDIN_HELP)
    ] = False,
    no_attribution: Annotated[
        bool, typer.Option("--no-attribution", help=_NO_ATTRIBUTION_HELP)
    ] = False,
) -> None:
    """Close a thread — scope abandoned but might still be relevant."""
    resolved = _resolve_reason(reason, reason_from_stdin)
    _set_status(thread_id, "closed", resolved, no_attribution)


@app.command("wont-do")
def wont_do(
    thread_id: Annotated[str, typer.Argument()],
    reason: Annotated[Optional[str], typer.Option("--reason", help=_REASON_HELP)] = None,
    reason_from_stdin: Annotated[
        bool, typer.Option("--reason-from-stdin", help=_REASON_STDIN_HELP)
    ] = False,
    no_attribution: Annotated[
        bool, typer.Option("--no-attribution", help=_NO_ATTRIBUTION_HELP)
    ] = False,
) -> None:
    """Mark a thread as wont_do — decided not to ship."""
    resolved = _resolve_reason(reason, reason_from_stdin)
    _set_status(thread_id, "wont_do", resolved, no_attribution)


# ---------------------------------------------------------------------------
# update (generic mutation)
# ---------------------------------------------------------------------------


@app.command("update")
def update(
    thread_id: Annotated[str, typer.Argument()],
    title: Annotated[Optional[str], typer.Option("--title")] = None,
    description: Annotated[Optional[str], typer.Option("--description")] = None,
    status: Annotated[Optional[str], typer.Option("--status", help=f"One of: {', '.join(_STATUS_CHOICES)}")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help=f"One of: {', '.join(_PRIORITY_CHOICES)}")] = None,
    assigned_to: Annotated[Optional[str], typer.Option("--assigned-to", help="User UUID, or empty string '' to unassign.")] = None,
    milestone_id: Annotated[Optional[str], typer.Option("--milestone-id")] = None,
) -> None:
    """Generic thread update — set any combination of fields via PATCH."""
    if status and status not in _STATUS_CHOICES:
        _console.print(f"[red]Invalid status {status!r}.[/red] One of: {', '.join(_STATUS_CHOICES)}")
        raise typer.Exit(2)
    if priority and priority not in _PRIORITY_CHOICES:
        _console.print(f"[red]Invalid priority {priority!r}.[/red] One of: {', '.join(_PRIORITY_CHOICES)}")
        raise typer.Exit(2)

    body: dict = {}
    if title is not None:
        body["title"] = title
    if description is not None:
        body["description"] = description
    if status is not None:
        body["status"] = status
    if priority is not None:
        body["priority"] = priority
    if assigned_to is not None:
        body["assigned_to"] = assigned_to or None  # empty string → null (unassign)
    if milestone_id is not None:
        body["milestone_id"] = milestone_id or None

    if not body:
        _console.print("[yellow]No fields to update — pass at least one --field.[/yellow]")
        raise typer.Exit(2)

    with _client_or_exit() as client:
        thread_uuid = _resolve_thread(client, thread_id)
        try:
            thread = client.patch(f"/threads/{thread_uuid}", body)
        except PowerloomApiError as e:
            _console.print(f"[red]Update failed:[/red] {e}")
            raise typer.Exit(1) from None

    if is_json_output():
        _output_json(thread)
        return
    _console.print(f"[green]Updated.[/green]")
    _print_thread_summary(thread)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@app.command("list")
def list_threads(
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project slug or UUID. Required unless --mine is used.")] = None,
    mine: Annotated[bool, typer.Option("--mine", help="List threads currently assigned to the signed-in user.")] = False,
    status: Annotated[Optional[str], typer.Option("--status", help="Comma-separated status filter (e.g. 'open,in_progress').")] = None,
    priority: Annotated[Optional[str], typer.Option("--priority", help="Comma-separated priority filter.")] = None,
    limit: Annotated[int, typer.Option("--limit", min=1, max=200)] = 50,
    full: Annotated[bool, typer.Option("--full", help="Include full descriptions and metadata.")] = False,
) -> None:
    """List tracker threads — by project, by status, or your own queue.

    Examples:
        weave thread list --mine
        weave thread list --project powerloom --status open --priority high,critical
        weave thread list --project powerloom --status in_progress
    """
    with _client_or_exit() as client:
        if mine:
            params: dict = {"limit": limit}
            if status:
                params["status"] = status
            try:
                items = client.get("/threads/my-work", **params)
            except PowerloomApiError as e:
                _console.print(f"[red]Query failed:[/red] {e}")
                raise typer.Exit(1) from None
        else:
            final_project = project or _default_project()
            project_id = _resolve_project(client, final_project)
            params = {"limit": limit}
            if status:
                params["status"] = status
            if priority:
                params["priority"] = priority
            try:
                items = client.get(f"/projects/{project_id}/threads", **params)
            except PowerloomApiError as e:
                _console.print(f"[red]Query failed:[/red] {e}")
                raise typer.Exit(1) from None

    rows = _rows_from_response(items)

    # Brief mode: strip heavy fields in agent mode unless --full is passed
    if is_agent_mode() and not full:
        for r in rows:
            r.pop("description", None)
            r.pop("metadata_json", None)
            r.pop("replies", None)

    if is_json_output():
        _output_json(rows)
        return

    if not rows:
        _console.print("[dim]No threads matched.[/dim]")
        return

    _print_thread_table(rows)


def _fetch_my_work(client, *, status: Optional[str], limit: int) -> list[dict]:
    params: dict = {"limit": limit}
    if status:
        params["status"] = status
    rows = client.get("/threads/my-work", **params)
    if not isinstance(rows, list):
        return []
    return [row for row in rows if isinstance(row, dict)]


def _print_my_work_table(rows: list[dict]) -> None:
    if not rows:
        _console.print("[dim]No threads in my work.[/dim]")
        return
    table = Table(title=f"My work — {len(rows)} thread(s)", show_header=True)
    for col in ("#", "status", "priority", "title", "updated"):
        table.add_column(col)
    for row in rows:
        table.add_row(
            str(row.get("sequence_number", "")),
            str(row.get("status", "")),
            str(row.get("priority", "")),
            str(row.get("title", ""))[:100],
            str(row.get("updated_at", ""))[:19],
        )
    _console.print(table)


def _watch_line(rows: list[dict]) -> str:
    counts = Counter(str(row.get("status", "unknown")) for row in rows)
    counts_text = ", ".join(f"{k}={v}" for k, v in sorted(counts.items())) or "none"
    top = rows[0] if rows else {}
    top_label = ""
    if top:
        top_label = (
            f" | top=#{top.get('sequence_number', '')} "
            f"{top.get('status', '')} {str(top.get('title', ''))[:80]}"
        )
    return f"my-work total={len(rows)} statuses={counts_text}{top_label}"


@app.command("my-work")
def my_work(
    status: Annotated[Optional[str], typer.Option("--status", help="Filter by thread status.")] = None,
    limit: Annotated[int, typer.Option("--limit", min=1, max=200)] = 50,
    watch: Annotated[bool, typer.Option("--watch", help="Poll until interrupted.")] = False,
    interval: Annotated[float, typer.Option("--interval", min=1.0)] = 5.0,
    once: Annotated[bool, typer.Option("--once", help="Poll once and exit (debug; useful with --watch).")] = False,
    full: Annotated[bool, typer.Option("--full", help="Include full descriptions and metadata.")] = False,
) -> None:
    """Show tracker threads assigned to, plucked by, or created by me.

    Richer than `weave thread list --mine` — adds watch-mode polling with a
    compact one-line status summary + JSON output for scripting / heads-up
    displays.
    """
    with _client_or_exit() as client:
        try:
            while True:
                rows = _fetch_my_work(client, status=status, limit=limit)

                # Brief mode: strip heavy fields in agent mode unless --full is passed
                if is_agent_mode() and not full:
                    for r in rows:
                        r.pop("description", None)
                        r.pop("metadata_json", None)
                        r.pop("replies", None)

                if is_json_output():
                    _output_json(rows)
                elif watch:
                    _console.print(_watch_line(rows))
                else:
                    _print_my_work_table(rows)
                if not watch or once:
                    break
                time.sleep(interval)
        except KeyboardInterrupt:
            typer.echo()
        except PowerloomApiError as e:
            _console.print(f"[red]Error:[/red] {e}")
            if e.status_code == 422:
                _console.print(
                    "[yellow]The server may still have /threads/my-work shadowed by "
                    "/threads/{thread_id}. Deploy the route-order fix (Powerloom #143/#145), then retry.[/yellow]"
                )
            raise typer.Exit(1) from None


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


@app.command("search")
def search(
    query: Annotated[str, typer.Argument(help="Substring to match against title, description, or slug.")],
    limit: Annotated[int, typer.Option("--limit", min=1, max=200)] = 50,
    full: Annotated[bool, typer.Option("--full", help="Include full descriptions and metadata.")] = False,
) -> None:
    """Global thread search across every project in your org.

    Closes powerloom thread `2dbbefde`. Pairs with the search bar on
    the /projects page in the console UI. Same engine endpoint
    (`GET /threads/search`); same case-insensitive substring match
    on title / description / slug.

    Examples:
      weave thread search connie
      weave thread search "fix flaky"
      weave thread search agent-onboarding --limit 10
    """
    with _client_or_exit() as client:
        try:
            rows = client.get(
                "/threads/search",
                q=query,
                limit=limit,
            )
        except PowerloomApiError as e:
            _console.print(f"[red]Search failed:[/red] {e}")
            raise typer.Exit(1) from None

    rows = _rows_from_response(rows)

    # Brief mode: strip heavy fields in agent mode unless --full is passed
    if is_agent_mode() and not full:
        for r in rows:
            r.pop("description", None)
            r.pop("metadata_json", None)
            r.pop("replies", None)

    if is_json_output():
        _output_json(rows)
        return

    if not rows:
        _console.print(
            f"[dim]No threads matched {query!r}. "
            f"Try a different keyword or `weave thread list --mine`.[/dim]"
        )
        return

    _console.print(
        f"[dim]{len(rows)} thread(s) matching {query!r} across all projects.[/dim]"
    )
    _print_thread_table(rows)


# ---------------------------------------------------------------------------
# show
# ---------------------------------------------------------------------------


@app.command("show")
def show(
    thread_id: Annotated[str, typer.Argument(help="Thread reference: UUID, slug (e.g. 'ki-004'), or 'project:slug'.")],
    with_replies: Annotated[bool, typer.Option("--with-replies/--no-replies", help="Include reply timeline.")] = True,
) -> None:
    """Show full detail for one thread — fields, metadata, reply timeline."""
    with _client_or_exit() as client:
        thread_uuid = _resolve_thread(client, thread_id)
        try:
            thread = client.get(f"/threads/{thread_uuid}")
        except PowerloomApiError as e:
            _console.print(f"[red]Fetch failed:[/red] {e}")
            raise typer.Exit(1) from None
        replies = []
        if with_replies and not is_json_output():
            try:
                replies = client.get(f"/threads/{thread_uuid}/replies") or []
            except PowerloomApiError:
                replies = []

    if is_json_output():
        if with_replies:
            thread = dict(thread)
            thread["replies"] = thread.get("replies") or []
        _output_json(thread)
        return

    _console.print(f"\n[bold]{thread.get('title','(no title)')}[/bold]")
    _console.print(
        f"  [dim]id={thread.get('id')} status={thread.get('status','?')} "
        f"priority={thread.get('priority','?')}[/dim]"
    )
    sp = ((thread.get("metadata_json") or {}).get("session_attribution") or {}).get("subprincipal_name")
    if sp:
        _console.print(f"  [dim]session: {sp}[/dim]")
    _console.print(f"  [dim]assigned_to={thread.get('assigned_to') or '(unassigned)'}[/dim]")
    _console.print(f"  [dim]created_at={thread.get('created_at')}[/dim]")

    desc = thread.get("description") or ""
    if desc:
        _console.print("\n[bold]Description[/bold]")
        _console.print(desc)

    if replies:
        _console.print(f"\n[bold]Replies[/bold] ([dim]{len(replies)}[/dim])")
        for r in replies:
            if not isinstance(r, dict):
                continue
            ts = r.get("created_at", "")[:19]
            kind = r.get("reply_type", "comment")
            _console.print(f"  [cyan]{ts}[/cyan] [dim]({kind})[/dim] {r.get('content','')[:200]}")


# ---------------------------------------------------------------------------
# tree view (`weave thread tree <ref>`, `weave project orphans`)
# ---------------------------------------------------------------------------


def _render_tree_node(node: dict, prefix: str = "", is_last: bool = True) -> None:
    """ASCII-render a single tree node + recurse into children. Style:

      └─ ki-004  Thread title here
          ├─ child-1  Another thread
          └─ child-2  ...
    """
    thread = node.get("thread") or {}
    title = thread.get("title", "(no title)")
    slug = thread.get("slug") or (thread.get("id") or "?")[:8]
    status = thread.get("status", "?")
    pri = thread.get("priority", "?")
    truncated = node.get("truncated_at_depth", False)
    depth = node.get("depth", 0)

    branch = "└─ " if is_last else "├─ "
    if depth == 0:
        # Root has no prefix
        line_prefix = ""
        branch = ""
    else:
        line_prefix = prefix + branch

    trunc_marker = " [yellow](more...)[/yellow]" if truncated else ""
    _console.print(
        f"{line_prefix}[bold cyan]{slug}[/bold cyan] [dim]({status}/{pri})[/dim] "
        f"{title[:80]}{trunc_marker}"
    )
    children = node.get("children") or []
    new_prefix = prefix + ("   " if is_last else "│  ") if depth > 0 else ""
    for i, child in enumerate(children):
        _render_tree_node(
            child, prefix=new_prefix, is_last=(i == len(children) - 1),
        )


@app.command("tree")
def tree(
    thread_id: Annotated[str, typer.Argument(help="Thread reference: UUID, slug, or 'project:slug'.")],
    max_depth: Annotated[int, typer.Option("--max-depth", min=1, max=50, help="Max levels to descend.")] = 10,
) -> None:
    """Print the parent/child tree rooted at <thread_id>.

    Children are merged from `parent_thread_id` (W1.2 column form) and
    `parent_of` dependency edges (W1.5.2 graph form). Nodes whose
    children weren't expanded show "(more...)"; re-run with a higher
    `--max-depth` or rooted at that node to see the missing subtree.
    """
    with _client_or_exit() as client:
        thread_uuid = _resolve_thread(client, thread_id)
        try:
            tree_data = client.get(
                f"/threads/{thread_uuid}/tree", max_depth=max_depth,
            )
        except PowerloomApiError as e:
            _console.print(f"[red]Tree fetch failed:[/red] {e}")
            raise typer.Exit(1) from None

    if is_json_output():
        _output_json(tree_data)
        return
    _render_tree_node(tree_data)


# ---------------------------------------------------------------------------
# Sprint subcommands — sit on `weave thread tree` for now (singular surface)
# but a sprint-rooted tree is its own command for clarity.
# ---------------------------------------------------------------------------


@app.command("sprint-tree")
def sprint_tree_cmd(
    sprint_id: Annotated[str, typer.Argument(help="Sprint reference: UUID, slug (e.g. 'v064'), or 'project:slug'.")],
    max_depth: Annotated[int, typer.Option("--max-depth", min=1, max=50)] = 10,
) -> None:
    """Render every top-level thread in the sprint as a tree.

    A "top-level" thread in a sprint is one whose parent isn't also in
    the sprint — so a flat sprint of 5 unrelated threads renders as 5
    single-node trees.

    Sprint addressing accepts UUID, `project:slug`, or bare slug — the
    same forms `weave sprint show` accepts.
    """
    # Lazy import — sprint_cmd registers the same /by-slug resolver so
    # we re-use it here. Top-level import would create a cycle since
    # sprint_cmd doesn't import thread_cmd.
    from loomcli.commands.sprint_cmd import _resolve_sprint as _sprint_resolver

    with _client_or_exit() as client:
        sprint_uuid = _sprint_resolver(client, sprint_id)
        try:
            data = client.get(f"/sprints/{sprint_uuid}/tree", max_depth=max_depth)
        except PowerloomApiError as e:
            _console.print(f"[red]Sprint tree fetch failed:[/red] {e}")
            raise typer.Exit(1) from None

    if is_json_output():
        _output_json(data)
        return

    sprint = data.get("sprint") or {}
    _console.print(
        f"\n[bold]Sprint:[/bold] {sprint.get('name','(no name)')} "
        f"[dim]({sprint.get('slug','?')}, status={sprint.get('status','?')})[/dim]"
    )
    trees = data.get("trees") or []
    if not trees:
        _console.print("[dim]No threads in this sprint yet.[/dim]")
        return
    for t in trees:
        _console.print()
        _render_tree_node(t)


@app.command("orphans")
def orphans_cmd(
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project slug or UUID.")] = None,
    include_done: Annotated[bool, typer.Option("--include-done", help="Include done/closed/wont_do threads in the orphan list.")] = False,
    limit: Annotated[int, typer.Option("--limit", min=1, max=500)] = 200,
    full: Annotated[bool, typer.Option("--full", help="Include full descriptions and metadata.")] = False,
) -> None:
    """List threads in the project with no parent and no sprint membership.

    The "what's loose right now?" triage view — work that might fall
    through the cracks if nobody picks it up.
    """
    with _client_or_exit() as client:
        final_project = project or _default_project()
        project_id = _resolve_project(client, final_project)
        try:
            params: dict = {"limit": limit}
            if include_done:
                params["include_done"] = True
            rows = client.get(f"/projects/{project_id}/orphans", **params)
        except PowerloomApiError as e:
            _console.print(f"[red]Orphan fetch failed:[/red] {e}")
            raise typer.Exit(1) from None

    rows = _rows_from_response(rows)

    # Brief mode: strip heavy fields in agent mode unless --full is passed
    if is_agent_mode() and not full:
        for r in rows:
            r.pop("description", None)
            r.pop("metadata_json", None)
            r.pop("replies", None)

    if is_json_output():
        _output_json(rows)
        return
    if not rows:
        _console.print(f"[green]No orphan threads in {project!r}.[/green]")
        return

    _console.print(f"\n[bold]Orphan threads in {project!r}[/bold] ([dim]{len(rows)}[/dim])")
    for t in rows:
        slug = t.get("slug") or (t.get("id") or "?")[:8]
        _console.print(
            f"  [cyan]{slug}[/cyan] [dim]({t.get('status','?')}/{t.get('priority','?')})[/dim] "
            f"{t.get('title','')[:80]}"
        )


# ---------------------------------------------------------------------------
# move - cross-project move (Powerloom #164)
# ---------------------------------------------------------------------------


@app.command("move")
def move_cmd(
    thread_ref: Annotated[str, typer.Argument(help="Thread reference: UUID, slug (e.g. 'ki-004'), or 'project:slug'.")],
    to: Annotated[str, typer.Option("--to", help="Target project — slug (e.g. 'powerloom-engine') or UUID.")],
    force: Annotated[bool, typer.Option("--force", help="Apply cleanups (detach milestone/parent/sprints/dependencies that live in the source project) and proceed with the move. Without this flag, a move that would require any cleanup returns 409 with the plan, so you can preview before committing.")] = False,
) -> None:
    """Move a thread to a different project (with safe cleanup of cross-project references).

    Two-phase: first run without --force to preview what would happen
    (the engine returns 409 with the cleanup plan in the message);
    re-run with --force to apply.

    Pairs with Powerloom PR #164. Engine details: services/tracker.move_thread.
    """
    with _client_or_exit() as client:
        thread_uuid = _resolve_thread(client, thread_ref)
        target_project_uuid = _resolve_project(client, to)
        body = {"target_project_id": target_project_uuid, "force": force}
        try:
            thread = client.post(f"/threads/{thread_uuid}/move", body)
        except PowerloomApiError as e:
            if e.status_code == 409 and not force:
                _console.print(
                    "[yellow]Move would detach cross-project references.[/yellow]"
                )
                _console.print(f"[dim]Engine reply:[/dim] {e}")
                _console.print(
                    "[dim]Re-run with --force to apply the cleanup + move.[/dim]"
                )
            else:
                _console.print(f"[red]Move failed:[/red] {e}")
            raise typer.Exit(1) from None

    if is_json_output():
        _output_json(thread)
        return
    _console.print("[green]Thread moved.[/green]")
    _print_thread_summary(thread)
    _console.print(
        f"  [dim]new project_id={thread.get('project_id','?')} "
        f"new sequence_number={thread.get('sequence_number','?')} "
        f"slug={thread.get('slug','(none)')}[/dim]"
    )


# ---------------------------------------------------------------------------
# bulk operations
# ---------------------------------------------------------------------------


@app.command("bulk-create")
def bulk_create(
    plan_file: Annotated[typer.FileText, typer.Argument(help="YAML or JSON file with thread payloads.")],
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Project slug or UUID.")] = None,
    no_attribution: Annotated[bool, typer.Option("--no-attribution")] = False,
) -> None:
    """Create multiple threads from a structured file.

    File should contain a list of objects with title, priority, description, etc.
    """
    import yaml as _yaml
    try:
        payloads = _yaml.safe_load(plan_file)
    except Exception as e:
        _console.print(f"[red]Could not parse {plan_file.name}:[/red] {e}")
        raise typer.Exit(1)

    if not isinstance(payloads, list):
        _console.print(f"[red]Invalid plan file: expected a list of objects.[/red]")
        raise typer.Exit(1)

    final_project = project or _default_project()
    results = []
    with _client_or_exit() as client:
        project_id = _resolve_project(client, final_project)
        for i, body in enumerate(payloads):
            if not isinstance(body, dict) or "title" not in body:
                _console.print(f"[yellow]Skipping item {i}: missing 'title'.[/yellow]")
                continue

            try:
                thread = client.post(f"/projects/{project_id}/threads", body)
                thread = _maybe_stamp_attribution(client, thread, no_attribution)
                results.append(thread)
                if not is_json_output():
                    _console.print(f"[green]Created {i+1}/{len(payloads)}:[/green] {thread.get('title')}")
            except PowerloomApiError as e:
                _console.print(f"[red]Failed to create item {i}:[/red] {e}")

    if is_json_output():
        _output_json(results)
    else:
        _console.print(f"[bold green]Bulk create complete — {len(results)} threads created.[/bold green]")
