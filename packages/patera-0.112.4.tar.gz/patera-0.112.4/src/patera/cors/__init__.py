"""CORS module"""
