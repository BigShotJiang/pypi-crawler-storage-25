##
# CcpnPKReader.py
#
# Update:
##
""" A collection of classes for parsing CCPN PK files.
"""
__docformat__ = "restructuredtext en"
__author__ = "Masashi Yokochi"
__email__ = "yokochi@protein.osaka-u.ac.jp"
__license__ = "Apache License 2.0"
__version__ = "1.1.1"

import os
import sys
from typing import IO, List, Optional, Tuple

from antlr4 import CommonTokenStream, InputStream, ParseTreeWalker

try:
    from wwpdb.utils.nmr.NmrDpConstant import (MAX_ERROR_REPORT,
                                               REPRESENTATIVE_MODEL_ID,
                                               REPRESENTATIVE_ALT_ID)
    from wwpdb.utils.nmr.ChemCompUtil import ChemCompUtil
    from wwpdb.utils.nmr.BmrbChemShiftStat import BmrbChemShiftStat
    from wwpdb.utils.nmr.nef.NefTranslator import NefTranslator
    from wwpdb.utils.nmr.io.CifReader import CifReader
    from wwpdb.utils.nmr.mr.LexerErrorListener import LexerErrorListener
    from wwpdb.utils.nmr.mr.ParserErrorListener import ParserErrorListener
    from wwpdb.utils.nmr.mr.ParserListenerUtil import coordAssemblyChecker
    from wwpdb.utils.nmr.pk.CcpnPKLexer import CcpnPKLexer
    from wwpdb.utils.nmr.pk.CcpnPKParser import CcpnPKParser
    from wwpdb.utils.nmr.pk.CcpnPKParserListener import CcpnPKParserListener
except ImportError:
    from nmr.NmrDpConstant import (MAX_ERROR_REPORT,
                                   REPRESENTATIVE_MODEL_ID,
                                   REPRESENTATIVE_ALT_ID)
    from nmr.ChemCompUtil import ChemCompUtil
    from nmr.BmrbChemShiftStat import BmrbChemShiftStat
    from nmr.nef.NefTranslator import NefTranslator
    from nmr.io.CifReader import CifReader
    from nmr.mr.LexerErrorListener import LexerErrorListener
    from nmr.mr.ParserErrorListener import ParserErrorListener
    from nmr.mr.ParserListenerUtil import coordAssemblyChecker
    from nmr.pk.CcpnPKLexer import CcpnPKLexer
    from nmr.pk.CcpnPKParser import CcpnPKParser
    from nmr.pk.CcpnPKParserListener import CcpnPKParserListener


class CcpnPKReader:
    """ Accessor methods for parsing CCPN PK files.
    """
    __slots__ = ('__class_name__',
                 '__version__',
                 '__verbose',
                 '__log',
                 '__debug',
                 '__enforcePeakRowFormat',
                 '__internal',
                 '__maxLexerErrorReport',
                 '__maxParserErrorReport',
                 '__representativeModelId',
                 '__representativeAltId',
                 '__mrAtomNameMapping',
                 '__ccU',
                 '__cR',
                 '__caC',
                 '__csStat',
                 '__nefT',
                 '__reasons')

    def __init__(self, verbose: bool = True, log: IO = sys.stdout,
                 representativeModelId: int = REPRESENTATIVE_MODEL_ID,
                 representativeAltId: str = REPRESENTATIVE_ALT_ID,
                 mrAtomNameMapping: Optional[List[dict]] = None,
                 cR: Optional[CifReader] = None, caC: Optional[dict] = None, ccU: Optional[ChemCompUtil] = None,
                 csStat: Optional[BmrbChemShiftStat] = None, nefT: Optional[NefTranslator] = None,
                 reasons: Optional[dict] = None) -> None:
        self.__class_name__ = self.__class__.__name__
        self.__version__ = __version__

        self.__verbose = verbose
        self.__log = log
        self.__debug = False
        self.__enforcePeakRowFormat = False
        self.__internal = False

        self.__maxLexerErrorReport = MAX_ERROR_REPORT
        self.__maxParserErrorReport = MAX_ERROR_REPORT

        self.__representativeModelId = representativeModelId
        self.__representativeAltId = representativeAltId
        self.__mrAtomNameMapping = mrAtomNameMapping

        # CCD accessing utility
        self.__ccU = ChemCompUtil(verbose, log) if ccU is None else ccU

        if cR is not None and caC is None:
            caC = coordAssemblyChecker(verbose, log, representativeModelId, representativeAltId,
                                       cR, self.__ccU, None, None, fullCheck=False)

        self.__cR = cR
        self.__caC = caC

        # BMRB chemical shift statistics
        self.__csStat = BmrbChemShiftStat(verbose, log, self.__ccU) if csStat is None else csStat

        # NefTranslator
        self.__nefT = NefTranslator(verbose, log, self.__ccU, self.__csStat) if nefT is None else nefT
        if nefT is None:
            self.__nefT.set_remediation_mode(True)

        # reasons for re-parsing request from the previous trial
        self.__reasons = reasons

    def setDebugMode(self, debug: bool) -> None:
        """ Set debug mode.
        """

        self.__debug = debug

    def enforcePeakRowFormat(self, enforcePeakRowFormat: bool) -> None:
        """ Whether to enforce peak row format or not.
        """

        self.__enforcePeakRowFormat = enforcePeakRowFormat

    def setInternalMode(self, internal: bool) -> None:
        """ Set internal mode.
        """

        self.__internal = internal

    def setLexerMaxErrorReport(self, maxErrReport: int) -> None:
        """ Set the maximum number of lexer error messages to save.
        """

        self.__maxLexerErrorReport = maxErrReport

    def setParserMaxErrorReport(self, maxErrReport: int) -> None:
        """ Set the maximum number of parser error messages to save.
        """

        self.__maxParserErrorReport = maxErrReport

    def parse(self, pkFilePath: str, cifFilePath: Optional[str] = None, isFilePath: bool = True,
              createSfDict: bool = False, originalFileName: Optional[str] = None, listIdCounter: Optional[dict] = None,
              reservedListIds: Optional[dict] = None, entryId: Optional[str] = None, csLoops: Optional[List[dict]] = None
              ) -> Tuple[Optional[CcpnPKParserListener], Optional[ParserErrorListener], Optional[LexerErrorListener]]:
        """ Parse CCPN PK file.
            @return: CcpnPKParserListener for success or None otherwise, ParserErrorListener, LexerErrorListener.
        """

        ifh = None

        try:

            if isFilePath:
                pkString = None

                if not os.access(pkFilePath, os.R_OK):
                    if self.__verbose:
                        self.__log.write(f"+{self.__class_name__}.parse() {pkFilePath} is not accessible.\n")
                    return None, None, None

                ifh = open(pkFilePath, 'r', encoding='utf-8', errors='ignore')  # pylint: disable=consider-using-with
                input = InputStream(ifh.read())  # pylint: disable=redefined-builtin

            else:
                pkFilePath, pkString = None, pkFilePath

                if pkString is None or len(pkString) == 0:
                    if self.__verbose:
                        self.__log.write(f"+{self.__class_name__}.parse() Empty string.\n")
                    return None, None, None

                input = InputStream(pkString)

            if cifFilePath is not None:
                if not os.access(cifFilePath, os.R_OK):
                    if self.__verbose:
                        self.__log.write(f"+{self.__class_name__}.parse() {cifFilePath} is not accessible.\n")
                    return None, None, None

                if self.__cR is None:
                    self.__cR = CifReader(self.__verbose, self.__log)
                    if not self.__cR.parse(cifFilePath):
                        if self.__verbose:
                            self.__log.write(f"+{self.__class_name__}.parse() {cifFilePath} is not CIF file.\n")
                        return None, None, None

            lexer = CcpnPKLexer(input)
            lexer.removeErrorListeners()

            lexer_error_listener = LexerErrorListener(pkFilePath, maxErrorReport=self.__maxLexerErrorReport, ignoreCodicError=True)
            lexer.addErrorListener(lexer_error_listener)

            messageList = lexer_error_listener.getMessageList()

            if messageList is not None and self.__verbose:
                for description in messageList:
                    self.__log.write(f"[Syntax error] line {description['line_number']}:{description['column_position']} "
                                     f"{description['message']}\n")
                    if 'input' in description:
                        self.__log.write(f"{description['input']}\n")
                        self.__log.write(f"{description['marker']}\n")

            stream = CommonTokenStream(lexer)
            parser = CcpnPKParser(stream)
            # try with simpler/faster SLL prediction mode
            # parser._interp.predictionMode = PredictionMode.SLL  # pylint: disable=protected-access
            parser.removeErrorListeners()
            parser_error_listener =\
                ParserErrorListener(pkFilePath, maxErrorReport=self.__maxParserErrorReport, ignoreCodicError=True)
            parser.addErrorListener(parser_error_listener)
            tree = parser.ccpn_pk()

            walker = ParseTreeWalker()
            listener = CcpnPKParserListener(self.__verbose, self.__log,
                                            self.__representativeModelId,
                                            self.__representativeAltId,
                                            self.__mrAtomNameMapping,
                                            self.__cR, self.__caC,
                                            self.__nefT,
                                            self.__reasons)
            listener.debug = self.__debug
            listener.internal = self.__internal
            listener.createSfDict = createSfDict
            listener.enforcePeakRowFormat = self.__enforcePeakRowFormat
            if createSfDict:
                if originalFileName is not None:
                    listener.originalFileName = originalFileName
                if listIdCounter is not None:
                    listener.listIdCounter = listIdCounter
                if reservedListIds is not None:
                    listener.reservedListIds = reservedListIds
                if entryId is not None:
                    listener.entryId = entryId
                if csLoops is not None:
                    listener.csLoops = csLoops
            walker.walk(listener, tree)

            messageList = parser_error_listener.getMessageList()

            if messageList is not None and self.__verbose:
                for description in messageList:
                    self.__log.write(f"[Syntax error] line {description['line_number']}:{description['column_position']} "
                                     f"{description['message']}\n")
                    if 'input' in description:
                        self.__log.write(f"{description['input']}\n")
                        self.__log.write(f"{description['marker']}\n")

            if self.__verbose and self.__debug:
                if listener.warningMessage is not None and len(listener.warningMessage) > 0:
                    self.__log.write(f"+{self.__class_name__}.parse() ++ Info  -\n" + '\n'.join(listener.warningMessage) + '\n')
                if isFilePath:
                    self.__log.write(f"+{self.__class_name__}.parse() ++ Info  - {listener.getContentSubtype()}\n")

            return listener, parser_error_listener, lexer_error_listener

        except IOError as e:
            if self.__verbose:
                self.__log.write(f"+{self.__class_name__}.parse() ++ Error  - {str(e)}\n")
            return None, None, None
        finally:
            if isFilePath and ifh is not None:
                ifh.close()


if __name__ == "__main__":
    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-daother-10371/nnoe_cnoe_cnPACS1_101-273_600uM_pH65_303K_8_dec23_3.txt',
                 '../../tests-nmr/mock-data-daother-10371/D_800858_model_P1.cif.V3')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-combine-at-upload/bmr36456/data/D_1300025766_nmr-peaks-upload_P1.dat.V1',
                 '../../tests-nmr/mock-data-combine-at-upload/bmr36456/data/D_1300025766_model-release_P1.cif.V1')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/7v6v/bmr36441/work/data/D_1300024190_nmr-peaks-upload_P1.dat.V1',
                 '../../tests-nmr/mock-data-remediation/7v6v/7v6v.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/6m05/bmr28081/work/data/NZ130-peaklist-D2O.txt',
                 '../../tests-nmr/mock-data-remediation/6m05/6m05.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/5ug3/bmr30225/work/data/D_1000225655_nmr-peaks-upload_P2.dat.V2',
                 '../../tests-nmr/mock-data-remediation/5ug3/5ug3.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/5ug5/bmr30226/work/data/D_1000225737_nmr-peaks-upload_P1.dat.V4',
                 '../../tests-nmr/mock-data-remediation/5ug5/5ug5.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/5ug5/bmr30226/work/data/D_1000225737_nmr-peaks-upload_P2.dat.V2',
                 '../../tests-nmr/mock-data-remediation/5ug5/5ug5.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/6ffr/bmr34228/work/data/D_1200008232_nmr-peaks-upload_P1.dat.V3',
                 '../../tests-nmr/mock-data-remediation/6ffr/6ffr.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/6h0q/bmr34301/work/data/D_1200010858_nmr-peaks-upload_P1.dat.V1',
                 '../../tests-nmr/mock-data-remediation/6h0q/6h0q.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/8aou/bmr34748/work/data/D_1292124790_nmr-peaks-upload_P1.dat.V1',
                 '../../tests-nmr/mock-data-remediation/8aou/8aou.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/6h0j/bmr34299/work/data/D_1200010843_nmr-peaks-upload_P1.dat.V1',
                 '../../tests-nmr/mock-data-remediation/6h0j/6h0j.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/6nom/bmr30561/work/data/D_1000238062_nmr-peaks-upload_P1.dat.V3',
                 '../../tests-nmr/mock-data-remediation/6nom/6nom.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/6r28/bmr34380/work/data/D_1292101294_nmr-peaks-upload_P1.dat.V1',
                 '../../tests-nmr/mock-data-remediation/6r28/6r28.cif')

    reader = CcpnPKReader(True)
    reader.setDebugMode(True)
    reader.parse('../../tests-nmr/mock-data-remediation/6vla/bmr30717/work/data/D_1000246592_nmr-peaks-upload_P1.dat.V1',
                 '../../tests-nmr/mock-data-remediation/6vla/6vla.cif')
