from datetime import datetime

from bs4 import BeautifulSoup
from pydantic import BaseModel

from ..bs4_utils import btf, btf_strict, btfa


class FileItem(BaseModel):
    name: str
    size: str


class ItemDetail(BaseModel):
    title: str
    info_hash: str
    file_size: str
    publish_date: int
    movie_info: str
    actor: str
    files: list[FileItem]


def parse_item(html: str) -> ItemDetail:
    soup = BeautifulSoup(html, "lxml")

    title_tag = btf(soup, "h2", class_="magnet-title")
    title = title_tag.get_text(strip=True) if title_tag else ""

    dl = btf_strict(soup, "dl", class_="dl-horizontal")

    info_hash = ""
    file_size = ""
    publish_date = 0
    movie_info = ""
    actor = ""

    dts = btfa(dl, "dt")
    dds = btfa(dl, "dd")

    for dt, dd in zip(dts, dds, strict=True):
        dt_text = dt.get_text(strip=True)
        if "种子特征码" in dt_text:
            info_hash = dd.get_text(strip=True)
        elif "文件大小" in dt_text:
            file_size = dd.get_text(strip=True).split("\n")[0].strip()
        elif "发布日期" in dt_text:
            date_str = dd.get_text(strip=True)
            dt_obj = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")  # noqa: DTZ007
            publish_date = int(dt_obj.timestamp())
        elif "影片信息" in dt_text:
            link = btf(dd, "a")
            if link:
                movie_info = link.get_text(strip=True)
        elif "演员" in dt_text:
            link = btf(dd, "a")
            if link:
                actor = link.get_text(strip=True)

    file_table = btf(soup, "table", class_="file-list")
    files = []
    if file_table:
        tbody = btf(file_table, "tbody")
        if tbody:
            rows = btfa(tbody, "tr")
            for row in rows:
                cols = btfa(row, "td")
                if len(cols) >= 2:  # noqa: PLR2004
                    name = cols[0].get_text(strip=True)
                    size = cols[1].get_text(strip=True)
                    files.append(FileItem(name=name, size=size))

    return ItemDetail(
        title=title,
        info_hash=info_hash,
        file_size=file_size,
        publish_date=publish_date,
        movie_info=movie_info,
        actor=actor,
        files=files,
    )
