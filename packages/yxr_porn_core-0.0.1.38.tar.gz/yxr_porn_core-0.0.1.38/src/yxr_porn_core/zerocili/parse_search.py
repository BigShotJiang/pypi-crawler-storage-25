from bs4 import BeautifulSoup, NavigableString, Tag
from pydantic import BaseModel

from ..bs4_utils import btfa


class SearchResultItem(BaseModel):
    title: str
    subtitle: str
    size_text: str
    url: str


def parse_search(html: str) -> list[SearchResultItem]:
    soup = BeautifulSoup(html, "lxml")

    table = btfa(soup, "table", class_="file-list")[0]
    tbody = btfa(table, "tbody")[0]
    rows = btfa(tbody, "tr")

    results = []
    if "Found 0 results" in btfa(soup, "title")[0].text:
        return []

    for row in rows:
        cols = btfa(row, "td")
        title_col = cols[0]
        size_col = cols[1]

        link = btfa(title_col, "a")[0]

        title_parts = []
        for child in link.children:
            if isinstance(child, NavigableString) and child.strip():
                title_parts.append(child.strip())
            elif isinstance(child, Tag) and child.name == "b":
                title_parts.append(child.get_text(strip=True))
        title = " ".join(title_parts).strip()

        p_tag = btfa(link, "p", class_="sample")
        subtitle = p_tag[0].getText().strip() if p_tag else ""

        size_text = size_col.getText().strip()
        url = link.attrs["href"]

        results.append(
            SearchResultItem(
                title=title,
                subtitle=subtitle,
                size_text=size_text,
                url=url,
            ),
        )

    return results
