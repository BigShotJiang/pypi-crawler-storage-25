import bs4
from bs4 import BeautifulSoup
from pydantic import BaseModel

from ..bs4_utils import btfa


class SearchResultItem(BaseModel):
    title: str
    subtitle: str
    size_text: str
    url: str


# https://cilisousuo.com/search?q=FSDSS-761
def parse_search(html: str) -> list[SearchResultItem]:
    soup = BeautifulSoup(html, "lxml")

    ul: bs4.Tag = btfa(soup, "ul", class_="list")[0]
    items: list[bs4.Tag] = btfa(ul, "li", class_="item")

    return [
        SearchResultItem(
            title=btfa(item, class_="result-title")[0].getText().strip(),
            subtitle=btfa(item, class_="filename")[0].getText().strip(),
            size_text=btfa(item, class_="size")[0].getText().strip(),
            url=btfa(item, class_="link")[0].attrs["href"],
        )
        for item in items
    ]
