#!/usr/bin/env python3
"""
pypi - PyPI publishing automation for gitship.

Handles:
- GitHub Actions workflow generation for OIDC publishing
- PyPI package status detection
- Trusted publisher setup guidance
- Release coordination with GitHub
"""

import os
import sys
import subprocess
from pathlib import Path
from typing import Optional, Dict, Tuple
from glob import glob

# Use tomllib (Python 3.11+) or fallback to tomli
try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None

# Optional: requests for PyPI check
try:
    import requests
except ImportError:
    requests = None


# ANSI color codes
class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_CYAN = '\033[96m'


def run_command(args: list, cwd: Path = None, capture_output: bool = True) -> subprocess.CompletedProcess:
    """Run a command and return result."""
    return subprocess.run(
        args,
        cwd=cwd,
        capture_output=capture_output,
        text=True,
        check=False
    )


def read_package_name(repo_path: Path) -> Optional[str]:
    """Read package name from pyproject.toml.

    For maturin/workspace repos the root pyproject.toml may belong to the
    upstream project (e.g. astral-sh/uv). Search for the pyproject.toml that
    has [tool.maturin] first — that is the actual package being published.
    """
    if tomllib is not None:
        # Check config for a previously saved choice first
        try:
            from . import config as _cfg
            saved = _cfg.get_project_publish_crate(repo_path)
            if saved:
                return saved
        except Exception:
            pass

        # Scan for all pyproject.toml files with [tool.maturin]
        SKIP_DIRS = {'target', 'node_modules', '__pycache__', 'test', 'scripts', 'docs', 'python'}
        maturin_hits = []  # list of (rel_path_str, package_name)
        for candidate in sorted(repo_path.rglob("pyproject.toml"), key=lambda p: len(p.parts)):
            rel = candidate.relative_to(repo_path)
            parts = rel.parts
            if len(parts) > 5:
                continue
            if any(p.startswith('.') or p in SKIP_DIRS for p in parts):
                continue
            try:
                with open(candidate, 'rb') as f:
                    data = tomllib.load(f)
                is_maturin = (
                    ('tool' in data and 'maturin' in data.get('tool', {}))
                    or data.get('build-system', {}).get('build-backend', '') == 'maturin'
                )
                if is_maturin:
                    name = data.get('project', {}).get('name')
                    if not name:
                        # Fall back to directory name (e.g. crates/uv-ffi -> uv-ffi)
                        name = candidate.parent.name
                    if name:
                        maturin_hits.append((str(rel.parent), name))
            except Exception:
                continue

        if len(maturin_hits) == 1:
            return maturin_hits[0][1]

        if len(maturin_hits) > 1:
            print(f"\n⚠️  Multiple maturin crates found in this repo:")
            for i, (path, name) in enumerate(maturin_hits, 1):
                print(f"  [{i}] {name}  ({path})")
            print(f"  [0] None of these — enter manually")
            try:
                choice = input("\nWhich package are you publishing? ").strip()
                if choice.isdigit():
                    idx = int(choice)
                    if 1 <= idx <= len(maturin_hits):
                        chosen = maturin_hits[idx - 1][1]
                    else:
                        chosen = input("Package name: ").strip()
                else:
                    chosen = choice if choice else None
                if chosen:
                    try:
                        from . import config as _cfg
                        _cfg.set_project_publish_crate(chosen, repo_path)
                        print(f"  ✓ Saved '{chosen}' for this project (run 'gitship config' to change)")
                    except Exception:
                        pass
                    return chosen
            except (EOFError, KeyboardInterrupt):
                pass

    # Fall back to root pyproject.toml
    pyproject_path = repo_path / "pyproject.toml"

    if not pyproject_path.exists():
        return None
    
    if tomllib is None:
        print(f"{Colors.YELLOW}Warning: tomllib not available. Install tomli: pip install tomli{Colors.RESET}")
        # Fallback to manual parsing (fragile but works)
        try:
            with open(pyproject_path, 'r') as f:
                for line in f:
                    if line.strip().startswith('name = '):
                        name = line.split('=')[1].strip().strip('"').strip("'")
                        return name
        except Exception as e:
            print(f"{Colors.YELLOW}Warning: Could not read pyproject.toml: {e}{Colors.RESET}")
        return None
    
    try:
        with open(pyproject_path, 'rb') as f:
            data = tomllib.load(f)
        
        return data.get('project', {}).get('name')
    
    except Exception as e:
        print(f"{Colors.YELLOW}Warning: Could not parse pyproject.toml: {e}{Colors.RESET}")
        return None


def get_github_repo_info(repo_path: Path) -> Tuple[Optional[str], Optional[str]]:
    """
    Get GitHub owner and repo name from git remote.
    
    Returns (owner, repo_name) or (None, None) if not found.
    """
    result = run_command(['git', 'remote', 'get-url', 'origin'], cwd=repo_path)
    
    if result.returncode != 0:
        return None, None
    
    remote_url = result.stdout.strip()
    
    # Parse different URL formats:
    # - https://github.com/owner/repo.git
    # - git@github.com:owner/repo.git
    # - git@github-custom:owner/repo.git (SSH config aliases)
    
    # Remove .git suffix
    if remote_url.endswith('.git'):
        remote_url = remote_url[:-4]
    
    # Extract owner/repo
    if 'github.com' in remote_url or 'github-' in remote_url:
        # HTTPS format
        if remote_url.startswith('https://'):
            parts = remote_url.split('/')
            if len(parts) >= 2:
                return parts[-2], parts[-1]
        
        # SSH format (git@github.com:owner/repo or git@github-alias:owner/repo)
        elif ':' in remote_url:
            after_colon = remote_url.split(':', 1)[1]
            parts = after_colon.split('/')
            if len(parts) >= 2:
                return parts[0], parts[1]
    
    return None, None


def check_pypi_status(package_name: str) -> str:
    """
    Check if package exists on PyPI.
    
    Returns:
        'missing' - Package not on PyPI
        'exists' - Package exists on PyPI
        'unknown' - Could not determine (network error, etc.)
    """
    if requests is None:
        print(f"{Colors.YELLOW}⚠ requests library not available{Colors.RESET}")
        print(f"  Install with: {Colors.DIM}python -m pip install requests{Colors.RESET}")
        return 'unknown'
    
    try:
        response = requests.get(f"https://pypi.org/pypi/{package_name}/json", timeout=5)
        
        if response.status_code == 200:
            return 'exists'
        elif response.status_code == 404:
            return 'missing'
        else:
            return 'unknown'
    
    except Exception:
        return 'unknown'


def generate_publish_workflow(repo_path: Path, package_name: str, method: str = "oidc") -> str:
    """
    Generate GitHub Actions workflow for PyPI publishing.
    Uses OIDC with automatic token fallback.
    
    Returns the workflow content as a string.
    """
    
    workflow = f"""name: Publish to PyPI

on:
  release:
    types: [published]

permissions:
  contents: read

jobs:
  pypi-publish:
    name: Upload release to PyPI
    runs-on: ubuntu-latest
    environment:
      name: pypi
      url: https://pypi.org/p/{package_name}
    permissions:
      id-token: write
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.x'
      
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          python -m pip install build
      
      - name: Build package
        run: python -m build
      
      - name: Publish with OIDC (try first)
        id: oidc_publish
        continue-on-error: true
        uses: pypa/gh-action-pypi-publish@release/v1
      
      - name: Publish with token (fallback)
        if: steps.oidc_publish.outcome == 'failure'
        continue-on-error: true
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          password: ${{{{ secrets.PYPI_API_TOKEN }}}}
      
      - name: Show manual instructions
        if: steps.oidc_publish.outcome == 'failure'
        run: |
          echo "⚠️  OIDC publish failed. If PYPI_API_TOKEN secret is set, the token step above ran as fallback."
          echo "If no secret is configured: python -m twine upload dist/*"
"""
    
    return workflow


def ensure_publish_workflow(repo_path: Path, package_name: str, force_recreate: bool = False) -> tuple[bool, str]:
    """
    Create .github/workflows/publish.yml if missing or outdated.
    
    Args:
        force_recreate: If True, delete and recreate the workflow
    
    Returns (workflow_exists, method) where method is 'oidc' or 'token'.
    """
    workflows_dir = repo_path / ".github" / "workflows"
    publish_yml = workflows_dir / "publish.yml"
    
    if publish_yml.exists() and not force_recreate:
        content = publish_yml.read_text()
        
        # Check for outdated version
        if "@v1.8.11" in content:
            print(f"{Colors.YELLOW}⚠ Workflow has BROKEN action version (@v1.8.11){Colors.RESET}")
            print(f"   This causes: 'Metadata is missing required fields' error")
            print("\nOptions:")
            print("  1. Update to @release/v1 (recommended)")
            print("  2. Regenerate entire workflow")
            print("  3. Keep current (will fail)")
            
            choice = input("\nChoice (1-3): ").strip()
            
            if choice == "1":
                content = content.replace("@v1.8.11", "@release/v1")
                publish_yml.write_text(content)
                run_command(['git', 'add', str(publish_yml)], cwd=repo_path)
                print(f"{Colors.GREEN}✓ Updated action version{Colors.RESET}")
                method = "oidc" if "id-token: write" in content else "token"
                return True, method
            elif choice == "2":
                publish_yml.unlink()
                # Fall through to recreation
            else:
                method = "oidc" if "id-token: write" in content else "token"
                return True, method
        else:
            print(f"{Colors.GREEN}✓ GitHub Actions workflow already exists{Colors.RESET}")
            method = "oidc" if "id-token: write" in content else "token"
            return True, method
    
    # Create new workflow
    print(f"\n{Colors.CYAN}📦 PyPI Publishing Setup{Colors.RESET}")
    print(f"{Colors.YELLOW}⚠ No GitHub Actions workflow found{Colors.RESET}\n")
    
    print("Choose publishing method:")
    print("  1. OIDC Trusted Publisher (recommended - no tokens)")
    print("  2. API Token (classic)")
    
    choice = input("\nChoice (1-2): ").strip()
    method = "oidc" if choice == "1" else "token"
    
    workflows_dir.mkdir(parents=True, exist_ok=True)
    workflow_content = generate_publish_workflow(repo_path, package_name, method)
    publish_yml.write_text(workflow_content)
    
    print(f"{Colors.GREEN}✓ Created workflow{Colors.RESET}")
    run_command(['git', 'add', str(publish_yml)], cwd=repo_path)
    
    if method == "token":
        print(f"\n{Colors.YELLOW}Add PYPI_API_TOKEN secret to GitHub{Colors.RESET}")
    
    return True, method


def create_github_environment(repo_path: Path, owner: str, repo_name: str, env_name: str = "pypi") -> bool:
    """
    Create a GitHub environment using gh CLI API.
    
    Returns True if successful.
    """
    print(f"\n{Colors.CYAN}Creating GitHub environment '{env_name}'...{Colors.RESET}")
    
    # Check if gh CLI is available
    result = run_command(['gh', '--version'])
    if result.returncode != 0:
        print(f"{Colors.YELLOW}⚠ GitHub CLI not found - skipping auto-creation{Colors.RESET}")
        print(f"{Colors.DIM}   Manual setup: https://github.com/{owner}/{repo_name}/settings/environments/new{Colors.RESET}")
        return False
    
    # Create environment - use exact command that worked
    result = run_command([
        'gh', 'api',
        '--method', 'PUT',
        '-H', 'Accept: application/vnd.github+json',
        '-H', 'X-GitHub-Api-Version: 2022-11-28',
        f'/repos/{owner}/{repo_name}/environments/{env_name}'
    ], cwd=repo_path)
    
    print(f"[DEBUG] gh api exit code: {result.returncode}")
    print(f"[DEBUG] stdout: {result.stdout[:200] if result.stdout else 'EMPTY'}")
    print(f"[DEBUG] stderr: {result.stderr[:200] if result.stderr else 'EMPTY'}")
    
    if result.returncode == 0:
        print(f"{Colors.GREEN}✓ Created GitHub environment '{env_name}'{Colors.RESET}")
        return True
    else:
        print(f"{Colors.YELLOW}⚠ Could not auto-create environment{Colors.RESET}")
        print(f"{Colors.DIM}   Manual setup: https://github.com/{owner}/{repo_name}/settings/environments/new{Colors.RESET}")
        return False


def guide_trusted_publisher_setup(repo_path: Path, package_name: str, username: str):
    """
    Interactive guide for setting up PyPI trusted publisher.
    """
    print(f"\n{Colors.BOLD}{'=' * 70}{Colors.RESET}")
    print(f"{Colors.BOLD}🔐 PYPI TRUSTED PUBLISHER SETUP{Colors.RESET}")
    print(f"{Colors.BOLD}{'=' * 70}{Colors.RESET}\n")
    
    print(f"{Colors.CYAN}This is a FIRST-TIME RELEASE for '{package_name}'{Colors.RESET}\n")
    
    # Auto-create GitHub environment
    owner, repo = get_github_repo_info(repo_path)
    if owner and repo:
        create_github_environment(repo_path, owner, repo, "pypi")
        print(f"{Colors.GREEN}✓ Step 1/2 complete: GitHub environment created{Colors.RESET}")
    else:
        print(f"{Colors.YELLOW}⚠ Could not detect GitHub repo info{Colors.RESET}")
    
    print(f"\n{Colors.BRIGHT_YELLOW}Final Step - Add Pending Publisher on PyPI:{Colors.RESET}")
    print(f"   Visit: {Colors.BRIGHT_CYAN}https://pypi.org/manage/account/publishing/{Colors.RESET}")
    print(f"   \n   Fill in:")
    print(f"   • PyPI Project Name: {Colors.GREEN}{package_name}{Colors.RESET}")
    print(f"   • Owner: {Colors.GREEN}{owner or username}{Colors.RESET}")
    print(f"   • Repository name: {Colors.GREEN}{repo or package_name}{Colors.RESET}")
    print(f"   • Workflow name: {Colors.GREEN}publish.yml{Colors.RESET}")
    print(f"   • Environment name: {Colors.GREEN}pypi{Colors.RESET}")
    
    print(f"\n{Colors.BRIGHT_YELLOW}How it works:{Colors.RESET}")
    print("   • You create a GitHub Release")
    print("   • Workflow runs automatically")
    print("   • PyPI verifies the workflow via OIDC")
    print("   • Package is published (no API tokens needed!)")
    
    print(f"\n{Colors.DIM}Note: The first release will CREATE the PyPI project automatically{Colors.RESET}")
    print(f"{Colors.DIM}      After that, it becomes a regular trusted publisher{Colors.RESET}")
    
    while True:
        ready = input(f"\n{Colors.BRIGHT_BLUE}Ready to continue? (y/n):{Colors.RESET} ").strip().lower()
        if ready == 'y':
            break
        elif ready == 'n':
            print(f"{Colors.YELLOW}Setup incomplete - please configure PyPI before publishing{Colors.RESET}")
            return
        else:
            print(f"{Colors.YELLOW}Please enter 'y' or 'n'{Colors.RESET}")


def check_existing_release(repo_path: Path, tag: str) -> str:
    """
    Check if a GitHub release exists for a tag.
    
    Returns:
        'none' - No release exists
        'draft' - Draft release exists
        'published' - Published release exists
        'error' - Could not determine
    """
    result = run_command(['gh', 'release', 'view', tag, '--json', 'isDraft,url'], cwd=repo_path)
    
    if result.returncode != 0:
        # Release doesn't exist
        return 'none'
    
    try:
        import json
        data = json.loads(result.stdout)
        
        if data.get('isDraft', False):
            return 'draft'
        else:
            return 'published'
    except:
        return 'error'


def wait_for_draft_to_populate(repo_path: Path, tag: str, max_wait: int = 15) -> bool:
    """
    Wait for GitHub to populate draft content.
    
    GitHub creates drafts immediately but takes 1-5 seconds to populate
    the body content from changelog.
    
    Returns True if draft has content, False if timeout.
    """
    import time
    print(f"{Colors.DIM}Waiting for GitHub to populate draft content...{Colors.RESET}", end='', flush=True)
    
    for attempt in range(max_wait):
        time.sleep(1)
        print('.', end='', flush=True)
        
        # Check if draft has content now
        result = run_command(['gh', 'release', 'view', tag, '--json', 'body'], cwd=repo_path)
        
        if result.returncode == 0:
            try:
                import json
                data = json.loads(result.stdout)
                body = data.get('body', '').strip()
                
                # Check if body has meaningful content (not just empty or placeholder)
                if body and len(body) > 50:  # At least 50 chars of real content
                    print(f" {Colors.GREEN}✓{Colors.RESET}")
                    return True
            except:
                pass
    
    print(f" {Colors.YELLOW}⚠{Colors.RESET}")
    return False


def publish_draft_release(repo_path: Path, version: str) -> bool:
    """
    Publish an existing draft release.
    
    Returns True if successful.
    """
    print(f"\n{Colors.CYAN}Publishing draft release {version}...{Colors.RESET}")
    
    result = run_command(['gh', 'release', 'edit', version, '--draft=false'], cwd=repo_path, capture_output=False)
    
    if result.returncode == 0:
        print(f"{Colors.GREEN}🚀 Release published! PyPI workflow triggered.{Colors.RESET}")
        return True
    else:
        print(f"{Colors.RED}✗ Failed to publish release{Colors.RESET}")
        return False


def create_github_release(repo_path: Path, tag: str, changelog: str, package_name: str, is_draft: bool = False, title_suffix: str = None) -> bool:
    """
    Create a GitHub release using gh CLI.
    
    Returns True if successful.
    """
    action = "draft" if is_draft else "release"
    print(f"\n{Colors.CYAN}Creating GitHub {action}...{Colors.RESET}")
    
    # Check if gh CLI is available
    result = run_command(['gh', '--version'])
    if result.returncode != 0:
        print(f"{Colors.YELLOW}⚠ GitHub CLI not found{Colors.RESET}")
        print(f"  Install with: {Colors.DIM}sudo apt install gh{Colors.RESET} or {Colors.DIM}brew install gh{Colors.RESET}")
        return False

    # Ensure gh has a default repo — detect from 'origin' remote and set it.
    # Without this, gh release create fails with "No default remote repository".
    owner, repo = get_github_repo_info(repo_path)
    if owner and repo:
        set_default = run_command(
            ['gh', 'repo', 'set-default', f'{owner}/{repo}'],
            cwd=repo_path
        )
        if set_default.returncode != 0:
            print(f"{Colors.YELLOW}⚠ Could not set gh default repo to {owner}/{repo}{Colors.RESET}")
            print(f"  Run manually: {Colors.DIM}gh repo set-default {owner}/{repo}{Colors.RESET}")
            return False
    else:
        print(f"{Colors.RED}✗ Could not determine GitHub repo from 'origin' remote{Colors.RESET}")
        print(f"  Run manually: {Colors.DIM}gh repo set-default <owner>/<repo>{Colors.RESET}")
        return False
    
    # Build release title  (owner/repo already resolved above)
    base_title = f'{package_name} {tag}' if package_name else tag
    if title_suffix:
        title = f"{base_title} - {title_suffix}"
    else:
        title = base_title
    
    # DEBUG: Show what we're creating
    print(f"[DEBUG] Creating release:")
    print(f"[DEBUG]   Tag: {tag}")
    print(f"[DEBUG]   Title: {title}")
    print(f"[DEBUG]   Draft: {is_draft}")
    print(f"[DEBUG]   Changelog length: {len(changelog)}")
    print(f"[DEBUG]   Changelog preview: {changelog[:200] if changelog else 'EMPTY'}")
    
    # Create release
    cmd = [
        'gh', 'release', 'create',
        tag,
        '--title', title,
        '--notes', changelog if changelog else f"Release {tag}"
    ]
    
    if is_draft:
        cmd.append('--draft')
    
    result = run_command(cmd, cwd=repo_path, capture_output=False)
    
    if result.returncode == 0:
        print(f"{Colors.GREEN}✅ {action.capitalize()} created successfully{Colors.RESET}")
        
        # Wait for GitHub to populate the draft
        if is_draft:
            print(f"{Colors.DIM}Waiting for GitHub to process...{Colors.RESET}")
            import time
            time.sleep(2)
            
            populated = wait_for_draft_to_populate(repo_path, tag)
            if not populated:
                print(f"{Colors.YELLOW}⚠ Draft created but content may still be processing{Colors.RESET}")
        
        # Verify it was created
        verify = run_command(['gh', 'release', 'view', tag], cwd=repo_path)
        if verify.returncode == 0:
            print(f"{Colors.GREEN}✅ Release verified{Colors.RESET}")
            return True
        else:
            print(f"{Colors.YELLOW}⚠ Release created but verification failed{Colors.RESET}")
            return True  # Still return True since creation succeeded
    else:
        print(f"{Colors.RED}✗ Failed to create release{Colors.RESET}")
        print(f"[DEBUG] Return code: {result.returncode}")
        print(f"[DEBUG] stdout: {result.stdout}")
        print(f"[DEBUG] stderr: {result.stderr}")
        return False


def offer_manual_publish(repo_path: Path):
    """
    Offer manual PyPI publishing using build + twine.
    """
    print(f"\n{Colors.CYAN}Manual PyPI Publishing:{Colors.RESET}\n")
    print("If you prefer to publish manually:")
    print(f"\n{Colors.DIM}# Install dependencies{Colors.RESET}")
    print(f"  python -m pip install build twine")
    print(f"\n{Colors.DIM}# Build package{Colors.RESET}")
    print(f"  python -m build")
    print(f"\n{Colors.DIM}# Upload to PyPI{Colors.RESET}")
    print(f"  python -m twine upload dist/*")
    
    manual = input(f"\n{Colors.BRIGHT_BLUE}Build and upload now? (y/n):{Colors.RESET} ").strip().lower()
    
    if manual == 'y':
        print(f"\n{Colors.CYAN}Building package...{Colors.RESET}")
        
        # Install build and twine using current interpreter
        result = run_command(
            [sys.executable, '-m', 'pip', 'install', 'build', 'twine'],
            cwd=repo_path,
            capture_output=False
        )
        if result.returncode != 0:
            print(f"{Colors.RED}✗ Failed to install dependencies{Colors.RESET}")
            return
        
        # Build
        result = run_command(
            [sys.executable, '-m', 'build'],
            cwd=repo_path,
            capture_output=False
        )
        if result.returncode != 0:
            print(f"{Colors.RED}✗ Build failed{Colors.RESET}")
            return
        
        print(f"{Colors.GREEN}✓ Package built{Colors.RESET}")
        
        # Upload
        upload = input(f"\n{Colors.YELLOW}Upload to PyPI? (y/n):{Colors.RESET} ").strip().lower()
        if upload == 'y':
            # Use glob to expand dist/* properly
            dist_files = glob(str(repo_path / 'dist' / '*'))
            
            if not dist_files:
                print(f"{Colors.RED}✗ No distribution files found in dist/{Colors.RESET}")
                return
            
            result = run_command(
                [sys.executable, '-m', 'twine', 'upload', *dist_files],
                cwd=repo_path,
                capture_output=False
            )
            if result.returncode == 0:
                print(f"{Colors.GREEN}✓ Published to PyPI{Colors.RESET}")
            else:
                print(f"{Colors.RED}✗ Upload failed{Colors.RESET}")


def update_pypi_description(repo_path: Path, package_name: str):
    """
    Update PyPI project description/readme by publishing a new release
    or by editing the pyproject.toml description field.

    PyPI does NOT allow editing description/readme of existing releases via API.
    The only way to update the long description (readme) is to publish a new version.
    However, the short description (summary) and project URLs can be updated
    by publishing a new release with the same or higher version number.

    This function:
    1. Shows the current description from pyproject.toml
    2. Lets the user edit it
    3. Asks whether to bundle it into the next release or just update the file
    """
    print(f"\n{Colors.BOLD}{'=' * 70}{Colors.RESET}")
    print(f"{Colors.BOLD}📝 UPDATE PYPI DESCRIPTION{Colors.RESET}")
    print(f"{Colors.BOLD}{'=' * 70}{Colors.RESET}\n")

    # Find the relevant pyproject.toml (maturin crate or root)
    pyproject_path = None
    if tomllib is not None:
        SKIP_DIRS = {'target', 'node_modules', '__pycache__', 'test', 'scripts', 'docs', 'python'}
        for candidate in sorted(repo_path.rglob("pyproject.toml"), key=lambda p: len(p.parts)):
            rel = candidate.relative_to(repo_path)
            parts = rel.parts
            if len(parts) > 5:
                continue
            if any(p.startswith('.') or p in SKIP_DIRS for p in parts):
                continue
            try:
                with open(candidate, 'rb') as f:
                    data = tomllib.load(f)
                is_maturin = (
                    ('tool' in data and 'maturin' in data.get('tool', {}))
                    or data.get('build-system', {}).get('build-backend', '') == 'maturin'
                )
                if is_maturin:
                    name = data.get('project', {}).get('name', '')
                    if name == package_name or not name:
                        pyproject_path = candidate
                        break
            except Exception:
                continue

    if pyproject_path is None:
        pyproject_path = repo_path / "pyproject.toml"

    if not pyproject_path.exists():
        print(f"{Colors.RED}✗ Could not find pyproject.toml{Colors.RESET}")
        return

    content = pyproject_path.read_text()

    # Show current description
    import re as _re
    desc_match = _re.search(r'^description\s*=\s*"(.*?)"', content, _re.MULTILINE)
    current_desc = desc_match.group(1) if desc_match else "(not set)"

    print(f"Package:          {Colors.GREEN}{package_name}{Colors.RESET}")
    print(f"pyproject.toml:   {Colors.DIM}{pyproject_path.relative_to(repo_path)}{Colors.RESET}")
    print(f"\nCurrent short description:")
    print(f"  {Colors.CYAN}{current_desc}{Colors.RESET}")

    # Check for readme
    readme_match = _re.search(r'readme\s*=\s*"(.*?)"', content, _re.MULTILINE)
    if readme_match:
        readme_file = pyproject_path.parent / readme_match.group(1)
        print(f"\nLong description (readme): {Colors.DIM}{readme_match.group(1)}{Colors.RESET}")
        if readme_file.exists():
            preview = readme_file.read_text()[:300]
            print(f"  {Colors.DIM}{preview}...{Colors.RESET}" if len(preview) == 300 else f"  {Colors.DIM}{preview}{Colors.RESET}")

    print(f"\n{Colors.YELLOW}Note: PyPI only updates descriptions when a NEW version is published.{Colors.RESET}")
    print(f"{Colors.DIM}Editing the description here updates your source files;{Colors.RESET}")
    print(f"{Colors.DIM}the change takes effect on PyPI when you do your next release.{Colors.RESET}")

    print(f"\nWhat would you like to update?")
    print(f"  1. Short description  (pyproject.toml [project] description)")
    print(f"  2. README / long description  (opens editor)")
    print(f"  3. Both")
    print(f"  4. Cancel")

    try:
        upd_choice = input("\nChoice (1-4): ").strip()
    except (KeyboardInterrupt, EOFError):
        return

    if upd_choice == '4':
        return

    changed = False

    if upd_choice in ('1', '3'):
        print(f"\n  Current: {Colors.CYAN}{current_desc}{Colors.RESET}")
        try:
            new_desc = input("  New description (Enter to keep): ").strip()
        except (KeyboardInterrupt, EOFError):
            new_desc = ""
        if new_desc and new_desc != current_desc:
            new_content = _re.sub(
                r'^(description\s*=\s*)".*?"',
                lambda m: f'{m.group(1)}"{new_desc}"',
                content,
                flags=_re.MULTILINE
            )
            pyproject_path.write_text(new_content)
            content = new_content
            print(f"  {Colors.GREEN}✓ Short description updated{Colors.RESET}")
            changed = True
        else:
            print(f"  {Colors.DIM}No change{Colors.RESET}")

    if upd_choice in ('2', '3'):
        if readme_match:
            readme_file = pyproject_path.parent / readme_match.group(1)
            editor = __import__('os').environ.get('EDITOR', 'nano')
            print(f"\n  Opening {readme_file.name} in {editor}...")
            __import__('subprocess').call([editor, str(readme_file)])
            print(f"  {Colors.GREEN}✓ README updated (save the file in your editor){Colors.RESET}")
            changed = True
        else:
            print(f"  {Colors.YELLOW}No readme field found in pyproject.toml{Colors.RESET}")
            print(f"  Add:  readme = \"README.md\"  to [project] and create the file.")

    if changed:
        print(f"\n{Colors.BRIGHT_YELLOW}Description changes saved locally.{Colors.RESET}")
        print(f"They will appear on PyPI when you publish your next release.")
        try:
            stage = input(f"\nStage changes in git now? (y/n): ").strip().lower()
            if stage == 'y':
                import subprocess as _sp
                _sp.run(["git", "add", str(pyproject_path)], cwd=repo_path)
                if readme_match:
                    _sp.run(["git", "add", str(pyproject_path.parent / readme_match.group(1))], cwd=repo_path)
                print(f"  {Colors.GREEN}✓ Staged{Colors.RESET}")
        except (KeyboardInterrupt, EOFError):
            pass


def handle_pypi_publishing(repo_path: Path, version: str, changelog: str, username: str, title_suffix: str = None, offer_description_update: bool = False):
    """
    Main entry point for PyPI publishing flow.
    
    Called from release.py after tagging.
    
    Args:
        repo_path: Path to repository
        version: Version being released (e.g., "v0.3.0")
        changelog: Changelog content for this release
        username: GitHub username
        title_suffix: Optional title suffix (e.g. "Fix commit bug")
    """
    print(f"[DEBUG] changelog length: {len(changelog)}")
    print(f"[DEBUG] changelog preview: {changelog[:200]}")
    print(f"\n{Colors.BOLD}{'=' * 70}{Colors.RESET}")
    print(f"{Colors.BOLD}📦 PYPI PUBLISHING{Colors.RESET}")
    print(f"{Colors.BOLD}{'=' * 70}{Colors.RESET}")
    
    # Get package name
    package_name = read_package_name(repo_path)
    if not package_name:
        print(f"{Colors.RED}✗ Could not read package name from pyproject.toml{Colors.RESET}")
        return
    
    print(f"\nPackage: {Colors.GREEN}{package_name}{Colors.RESET}")
    print(f"Version: {Colors.GREEN}{version}{Colors.RESET}")
    
    # Check PyPI status
    print(f"\n{Colors.CYAN}Checking PyPI status...{Colors.RESET}")
    pypi_status = check_pypi_status(package_name)
    
    if pypi_status == 'missing':
        print(f"{Colors.YELLOW}⚠ Package not found on PyPI (first release!){Colors.RESET}")
        first_release = True
    elif pypi_status == 'exists':
        print(f"{Colors.GREEN}✓ Package exists on PyPI{Colors.RESET}")
        first_release = False
    else:
        print(f"{Colors.YELLOW}⚠ Could not verify PyPI status (network issue?){Colors.RESET}")
        first_release = input(f"{Colors.CYAN}Is this the first release? (y/n):{Colors.RESET} ").strip().lower() == 'y'
    
    # Ensure workflow exists
    workflow_exists, method = ensure_publish_workflow(repo_path, package_name)
    print(f"[DEBUG] workflow_exists={workflow_exists}, method={method}")
    
    # Guide setup for first release with OIDC
    if first_release and method == "oidc":
        guide_trusted_publisher_setup(repo_path, package_name, username)
    
    # Check if release already exists
    release_status = check_existing_release(repo_path, version)
    
    print(f"[DEBUG] Release status for {version}: {release_status}")
    
    # FIXED: Handle draft case properly with menu
    if release_status == 'draft':
        print(f"\n{Colors.YELLOW}📝 Draft release already exists for {version}{Colors.RESET}")
        
        # Check if it has content
        result = run_command(['gh', 'release', 'view', version, '--json', 'body,url'], cwd=repo_path)
        
        draft_url = None
        has_content = False
        
        if result.returncode == 0:
            try:
                import json
                data = json.loads(result.stdout)
                draft_url = data.get('url')
                body = data.get('body', '').strip()
                has_content = len(body) > 50
            except:
                pass
        
        if draft_url:
            print(f"{Colors.DIM}   URL: {draft_url}{Colors.RESET}")
        
        if not has_content:
            print(f"{Colors.YELLOW}   ⚠ Draft appears to be empty or still processing{Colors.RESET}")
            print(f"{Colors.DIM}   Waiting for content to populate...{Colors.RESET}")
            wait_for_draft_to_populate(repo_path, version)
        
        print(f"\n{Colors.BOLD}What would you like to do?{Colors.RESET}")
        print(f"  1. 🚀 PUBLISH existing draft")
        print(f"  2. 🗑️  DELETE draft and create new one")
        print(f"  3. 🚪 EXIT (leave draft as-is)")
        
        choice = input(f"\n{Colors.BRIGHT_BLUE}Choice (1-3):{Colors.RESET} ").strip()
        
        if choice == '1':
            publish_draft_release(repo_path, version)
            print(f"\n{Colors.BOLD}{'=' * 70}{Colors.RESET}")
            print(f"{Colors.GREEN}PyPI publishing complete!{Colors.RESET}")
            print(f"{Colors.BOLD}{'=' * 70}{Colors.RESET}\n")
            return
        
        elif choice == '2':
            print(f"\n{Colors.CYAN}Deleting existing draft...{Colors.RESET}")
            result = run_command(['gh', 'release', 'delete', version, '--yes'], cwd=repo_path)
            
            if result.returncode == 0:
                print(f"{Colors.GREEN}✓ Draft deleted{Colors.RESET}")
                # Fall through to create new one
                release_status = 'none'
            else:
                print(f"{Colors.RED}✗ Failed to delete draft{Colors.RESET}")
                return
        
        elif choice == '3':
            print(f"\n{Colors.DIM}Leaving draft as-is. Publish later with:{Colors.RESET}")
            print(f"   gh release edit {version} --draft=false")
            print(f"\n{Colors.BOLD}{'=' * 70}{Colors.RESET}")
            print(f"{Colors.GREEN}PyPI publishing preparation complete!{Colors.RESET}")
            print(f"{Colors.BOLD}{'=' * 70}{Colors.RESET}\n")
            return
    
    elif release_status == 'published':
        print(f"\n{Colors.GREEN}✓ Release {version} already published{Colors.RESET}")
        print(f"\n{Colors.BOLD}{'=' * 70}{Colors.RESET}")
        print(f"{Colors.GREEN}PyPI publishing preparation complete!{Colors.RESET}")
        print(f"{Colors.BOLD}{'=' * 70}{Colors.RESET}\n")
        return
    
    # Only create new release if status is 'none'
    if release_status == 'none':
        # No release exists - create one
        if workflow_exists:
            print(f"\n{Colors.CYAN}Creating GitHub Release Draft...{Colors.RESET}")
            
            # Always create as draft first for safety
            success = create_github_release(repo_path, version, changelog, package_name, is_draft=True, title_suffix=title_suffix)
            
            if success:
                # Construct URL for review
                owner, repo = get_github_repo_info(repo_path)
                if owner and repo:
                    release_url = f"https://github.com/{owner}/{repo}/releases/tag/{version}"
                    print(f"\n{Colors.BOLD}📝 Draft created:{Colors.RESET} {Colors.BRIGHT_BLUE}{release_url}{Colors.RESET}")
                
                print(f"{Colors.DIM}   Please review the release notes online.{Colors.RESET}")
                
                # Ask to publish
                confirm = input(f"\n{Colors.BRIGHT_GREEN}🚀 Ready to PUBLISH? (y/n):{Colors.RESET} ").strip().lower()
                
                if confirm == 'y':
                    publish_draft_release(repo_path, version)
                else:
                    print(f"\n{Colors.YELLOW}ℹ Left as draft.{Colors.RESET}")
                    print(f"  When ready, run: {Colors.DIM}gh release edit {version} --draft=false{Colors.RESET}")
            else:
                print(f"\n{Colors.YELLOW}⚠ Failed to create release{Colors.RESET}")
                offer_manual_publish(repo_path)
    
    else:
        # Unknown status
        print(f"\n{Colors.YELLOW}⚠ Unknown release status: {release_status}{Colors.RESET}")
        offer_manual_publish(repo_path)
    
    print(f"\n{Colors.BOLD}{'=' * 70}{Colors.RESET}")
    print(f"{Colors.GREEN}PyPI publishing preparation complete!{Colors.RESET}")
    print(f"{Colors.BOLD}{'=' * 70}{Colors.RESET}\n")


def main():
    """Standalone entry point for testing."""
    repo_path = Path.cwd()
    
    # Test functionality
    package_name = read_package_name(repo_path)
    if package_name:
        print(f"Package: {package_name}")
        status = check_pypi_status(package_name)
        print(f"PyPI Status: {status}")
    else:
        print("No package name found")


if __name__ == "__main__":
    main()