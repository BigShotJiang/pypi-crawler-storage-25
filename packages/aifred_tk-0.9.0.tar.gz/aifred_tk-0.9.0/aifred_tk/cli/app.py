"""CLI presentation layer — dynamic Typer command builder over the plugin registry."""

import json
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any, cast, get_args, get_origin

import click
import typer
import typer.core
from dynaconf import Dynaconf
from pydantic import ValidationError
from pydantic.fields import FieldInfo

from aifred_tk.config.settings import create_settings
from aifred_tk.core.interfaces import Tool
from aifred_tk.core.models import ToolExecutionError, ToolNotFoundError
from aifred_tk.core.registry import PluginRegistry
from aifred_tk.logging.setup import setup_logging

_EXIT_TOOL_NOT_FOUND = 1
_EXIT_VALIDATION_ERROR = 2
_EXIT_EXECUTION_ERROR = 3

_CTX_META_REGISTRY = "aifred_tk.registry"
_CTX_META_SETTINGS = "aifred_tk.settings"


def _pydantic_field_to_click_option(name: str, field: FieldInfo) -> click.Option:
    """Convert a single Pydantic v2 field to a :class:`click.Option`.

    :param name: Field name (Python identifier).
    :type name: str
    :param field: Pydantic v2 :class:`~pydantic.fields.FieldInfo` instance.
    :type field: FieldInfo
    :return: Equivalent Click option.
    :rtype: click.Option
    """
    flag = f"--{name.replace('_', '-')}"
    annotation = field.annotation

    is_required = field.is_required()
    if is_required:
        default = None
    elif field.default_factory is not None:
        default = cast(Callable[[], Any], field.default_factory)()
    else:
        default = field.default
    description: str = field.description or ""

    if annotation is bool:
        return click.Option(
            [flag],
            is_flag=True,
            default=False,
            help=description,
        )

    is_multiple = get_origin(annotation) is list
    if is_multiple:
        inner_args = get_args(annotation)
        resolved_annotation = inner_args[0] if inner_args else str
    elif isinstance(annotation, type):
        resolved_annotation = annotation
    else:
        resolved_annotation = str

    type_map: dict[type, click.ParamType] = {
        int: click.INT,
        float: click.FLOAT,
        str: click.STRING,
    }
    click_type: click.ParamType = type_map.get(resolved_annotation, click.STRING)

    return click.Option(
        [flag],
        type=click_type,
        required=is_required,
        default=default,
        multiple=is_multiple,
        help=description,
        show_default=not is_required,
    )


def build_command_for_tool(tool: Tool) -> click.Command:
    """Build a :class:`click.Command` from a :class:`~aifred_tk.core.interfaces.Tool`.

    Introspects the tool's ``args_schema`` (a Pydantic model class) to derive
    Click options. The command callback validates the raw Click values through
    the schema before calling ``execute``.

    :param tool: The tool to wrap as a Click command.
    :type tool: Tool
    :return: A Click command ready to be attached to the CLI group.
    :rtype: click.Command
    """
    schema = tool.args_schema
    params: list[click.Parameter] = [
        _pydantic_field_to_click_option(name, field) for name, field in schema.model_fields.items()
    ]

    @click.pass_context
    def _callback(ctx: click.Context, /, **kwargs: Any) -> None:
        registry: PluginRegistry = ctx.obj["registry"]

        try:
            resolved_tool = registry.get_tool(tool.tool_id)
        except ToolNotFoundError as exc:
            click.echo(str(exc), err=True)
            sys.exit(_EXIT_TOOL_NOT_FOUND)

        try:
            validated_args = resolved_tool.args_schema(**kwargs)
        except ValidationError as exc:
            click.echo(exc.json(indent=2), err=True)
            sys.exit(_EXIT_VALIDATION_ERROR)

        try:
            result = resolved_tool.execute(validated_args)
        except Exception as exc:
            err = ToolExecutionError(tool.tool_id, exc)
            click.echo(str(err), err=True)
            sys.exit(_EXIT_EXECUTION_ERROR)

        click.echo(result if isinstance(result, str) else json.dumps(result, indent=2))

    _callback.__name__ = tool.tool_id

    return click.Command(
        name=tool.tool_id,
        callback=_callback,
        params=params,
        help=tool.description,
    )


def _ensure_registry(ctx: click.Context) -> PluginRegistry:
    """Return (or create) the :class:`~aifred_tk.core.registry.PluginRegistry` for *ctx*.

    In Click 8.x, ``resolve_command`` is called *before* the group callback runs,
    so ``ctx.obj`` is not yet populated.  This function builds the registry from
    ``ctx.params`` (which *is* available post-parse) on first access, then caches
    the result in ``ctx.meta`` for reuse by both ``get_command`` / ``list_commands``
    and the group callback.

    :param ctx: The group's Click context.
    :type ctx: click.Context
    :return: A loaded :class:`~aifred_tk.core.registry.PluginRegistry`.
    :rtype: PluginRegistry
    """
    if _CTX_META_REGISTRY in ctx.meta:
        cached: PluginRegistry = ctx.meta[_CTX_META_REGISTRY]
        return cached

    config: Path | None = ctx.params.get("config") if ctx.params else None
    settings = create_settings(extra_config_file=config)
    setup_logging(mode="cli", settings=settings)
    registry = PluginRegistry(settings)
    registry.load_plugins()

    ctx.meta[_CTX_META_REGISTRY] = registry
    ctx.meta[_CTX_META_SETTINGS] = settings
    return registry


class _RegistryGroup(typer.core.TyperGroup):
    """A :class:`~typer.core.TyperGroup` that derives its commands from the plugin registry.

    Command resolution is driven by the plugin registry, which is initialised
    lazily from ``ctx.params`` and cached in ``ctx.meta`` so that the group
    callback, ``get_command``, and ``list_commands`` all share the same instance.
    """

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        """Return a dynamically built command from the registry.

        :param ctx: The current Click context.
        :type ctx: click.Context
        :param cmd_name: The name of the requested command.
        :type cmd_name: str
        :return: The matching command, or ``None``.
        :rtype: click.Command | None
        """
        registry = _ensure_registry(ctx)
        tool = registry.get_all_tools().get(cmd_name)
        if tool is not None:
            return build_command_for_tool(tool)
        return super().get_command(ctx, cmd_name)

    def list_commands(self, ctx: click.Context) -> list[str]:
        """Return a sorted list of all available command names.

        :param ctx: The current Click context.
        :type ctx: click.Context
        :return: Sorted list of command names.
        :rtype: list[str]
        """
        registry = _ensure_registry(ctx)
        return sorted(registry.get_all_tools().keys())


app = typer.Typer(
    cls=_RegistryGroup,
    invoke_without_command=True,
    no_args_is_help=True,
)


@app.callback()
def _callback(
    ctx: click.Context,
    config: Path | None = typer.Option(
        None,
        "--config",
        exists=True,
        dir_okay=False,
        help="Path to an additional settings file (highest priority after env vars).",
    ),
) -> None:
    """AIfred toolkit — expose AI agent tools via CLI.

    Run ``aifred-tk TOOL_ID --help`` for tool-specific usage.
    """
    ctx.ensure_object(dict)
    registry = _ensure_registry(ctx)
    settings: Dynaconf = ctx.meta[_CTX_META_SETTINGS]
    ctx.obj["settings"] = settings
    ctx.obj["registry"] = registry
