"""Fallback agent wrapper implementing a chain-of-responsibility pattern for LLM failures."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Generic, Protocol, TypeVar

from loguru import logger
from pydantic_ai.agent import AgentRunResult
from pydantic_ai.exceptions import ModelAPIError
from pydantic_ai.messages import ModelMessage, UserContent

_T_co = TypeVar("_T_co", covariant=True)
_T = TypeVar("_T")


class AgentRunner(Protocol[_T_co]):
    """Minimal interface for objects that can execute an agent run.

    Both :class:`~pydantic_ai.Agent` and :class:`FallbackAgent` implement this protocol.
    Callers that only need to invoke an agent should type their references as
    ``AgentRunner[T]`` rather than :class:`~pydantic_ai.Agent` to support transparent
    fallback chaining.
    """

    def run_sync(
        self,
        user_prompt: str | Sequence[UserContent] | None = None,
        *,
        message_history: Sequence[ModelMessage] | None = None,
        **kwargs: Any,
    ) -> AgentRunResult[_T_co]:
        """Run the agent synchronously.

        :param user_prompt: User prompt text or content sequence.
        :param message_history: Prior conversation messages.
        :return: Agent run result.
        :rtype: AgentRunResult[_T_co]
        """
        ...

    async def run(
        self,
        user_prompt: str | Sequence[UserContent] | None = None,
        *,
        message_history: Sequence[ModelMessage] | None = None,
        **kwargs: Any,
    ) -> AgentRunResult[_T_co]:
        """Run the agent asynchronously.

        :param user_prompt: User prompt text or content sequence.
        :param message_history: Prior conversation messages.
        :return: Agent run result.
        :rtype: AgentRunResult[_T_co]
        """
        ...


class FallbackAgent(Generic[_T]):
    """Agent wrapper that delegates to a fallback when the primary raises a transport error.

    On :class:`~pydantic_ai.exceptions.ModelAPIError` (HTTP 4xx/5xx and other API-level
    failures) from the primary agent, a warning is logged and the identical call is
    forwarded to the fallback.  All other exceptions propagate immediately without
    consulting the fallback.

    Instances satisfy the :class:`AgentRunner` protocol and may themselves be used as the
    primary or fallback of another :class:`FallbackAgent`, enabling arbitrary-depth chains:

    .. code-block:: python

        chain = FallbackAgent(agent_a, FallbackAgent(agent_b, agent_c))

    :param primary: Agent to try first.
    :type primary: AgentRunner[_T]
    :param fallback: Agent to delegate to on primary transport failure.
    :type fallback: AgentRunner[_T]
    """

    def __init__(self, primary: AgentRunner[_T], fallback: AgentRunner[_T]) -> None:
        self._primary = primary
        self._fallback = fallback

    def run_sync(
        self,
        user_prompt: str | Sequence[UserContent] | None = None,
        *,
        message_history: Sequence[ModelMessage] | None = None,
        **kwargs: Any,
    ) -> AgentRunResult[_T]:
        """Run synchronously, falling back on transport error.

        :param user_prompt: User prompt text or content sequence.
        :param message_history: Prior conversation messages.
        :return: Agent run result from the first successful agent in the chain.
        :rtype: AgentRunResult[_T]
        :raises ModelAPIError: When both primary and fallback raise transport errors.
        """
        try:
            return self._primary.run_sync(user_prompt, message_history=message_history, **kwargs)
        except ModelAPIError as exc:
            logger.warning(
                "Primary agent transport failure ({}: {}); delegating to fallback.",
                type(exc).__name__,
                exc,
            )
            return self._fallback.run_sync(user_prompt, message_history=message_history, **kwargs)

    async def run(
        self,
        user_prompt: str | Sequence[UserContent] | None = None,
        *,
        message_history: Sequence[ModelMessage] | None = None,
        **kwargs: Any,
    ) -> AgentRunResult[_T]:
        """Run asynchronously, falling back on transport error.

        :param user_prompt: User prompt text or content sequence.
        :param message_history: Prior conversation messages.
        :return: Agent run result from the first successful agent in the chain.
        :rtype: AgentRunResult[_T]
        :raises ModelAPIError: When both primary and fallback raise transport errors.
        """
        try:
            return await self._primary.run(user_prompt, message_history=message_history, **kwargs)
        except ModelAPIError as exc:
            logger.warning(
                "Primary agent transport failure ({}: {}); delegating to fallback.",
                type(exc).__name__,
                exc,
            )
            return await self._fallback.run(user_prompt, message_history=message_history, **kwargs)
