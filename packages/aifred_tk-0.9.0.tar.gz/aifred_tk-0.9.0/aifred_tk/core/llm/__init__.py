"""Core LLM configuration models and pydantic-ai model factory.

This package provides:

- Pydantic models for declaring named LLMs in ``aifred_tk.llms`` settings and for
  referencing them (or defining them inline) inside plugin tool configuration.
- :func:`resolve_llm` — resolves a :data:`PluginLlmSetting` (ref or inline) to a concrete
  :data:`LlmConfig`.
- :func:`build_pydantic_ai_model` — converts a :data:`LlmConfig` to a pydantic-ai
  :class:`~pydantic_ai.models.Model` ready for use in an :class:`~pydantic_ai.Agent`.
- :class:`FallbackLlmConfig` — chain-of-responsibility LLM config that tries a primary
  LLM and transparently falls back on transport failures.
- :class:`FallbackAgent` — agent wrapper implementing the fallback chain at runtime.
- :class:`AgentRunner` — protocol implemented by both :class:`~pydantic_ai.Agent` and
  :class:`FallbackAgent`; use as the type for agent references in plugins.
"""

from ._config import (
    AnthropicLlmConfig,
    FallbackLlmConfig,
    GoogleLlmConfig,
    LlmConfig,
    LlmInlineSetting,
    LlmRefSetting,
    OllamaLlmConfig,
    OpenAICompatLlmConfig,
    OpenAILlmConfig,
    PluginLlmSetting,
)
from ._factory import (
    build_agent_from_settings,
    build_model_settings,
    build_pydantic_ai_model,
    resolve_llm,
    resolve_tool_llm,
)
from ._fallback import AgentRunner, FallbackAgent

__all__ = [
    "AgentRunner",
    "AnthropicLlmConfig",
    "FallbackAgent",
    "FallbackLlmConfig",
    "GoogleLlmConfig",
    "LlmConfig",
    "LlmInlineSetting",
    "LlmRefSetting",
    "OllamaLlmConfig",
    "OpenAICompatLlmConfig",
    "OpenAILlmConfig",
    "PluginLlmSetting",
    "build_agent_from_settings",
    "build_model_settings",
    "build_pydantic_ai_model",
    "resolve_llm",
    "resolve_tool_llm",
]
