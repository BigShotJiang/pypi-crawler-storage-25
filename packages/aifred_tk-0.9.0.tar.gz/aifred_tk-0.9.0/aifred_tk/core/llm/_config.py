"""Pydantic models for LLM configuration used across the aifred-tk core and plugins."""

from __future__ import annotations

from typing import Annotated, Literal, TypeAlias

from pydantic import BaseModel, Field


class OllamaLlmConfig(BaseModel):
    """LLM configuration for a local Ollama server.

    :param provider: Discriminator field; always ``"ollama"``.
    :param model: Ollama model tag, e.g. ``"gemma4:e4b"``.
    :param host: Ollama server hostname. Defaults to ``"127.0.0.1"``.
    :param port: Ollama server port. Defaults to ``11434``.
    :param context_size: Maximum context window in tokens, or ``None`` for server default.
    :param response_size: Maximum response length in tokens, or ``None`` for server default.
    """

    provider: Literal["ollama"] = "ollama"
    model: str = Field(..., description="Ollama model tag, e.g. 'gemma4:e4b'")
    host: str = Field("127.0.0.1", description="Ollama server hostname")
    port: int = Field(11434, description="Ollama server port")
    context_size: int | None = Field(None, description="Maximum context window tokens")
    response_size: int | None = Field(None, description="Maximum response length tokens")


class OpenAILlmConfig(BaseModel):
    """LLM configuration for the OpenAI API.

    :param provider: Discriminator field; always ``"openai"``.
    :param model: OpenAI model name, e.g. ``"gpt-4o-mini"``.
    :param api_key: API key; falls back to the ``OPENAI_API_KEY`` environment variable when
        ``None``.
    :param base_url: Override the OpenAI base URL, e.g. for an Azure endpoint.
    :param context_size: Maximum context window in tokens, or ``None`` for model default.
    :param response_size: Maximum response length in tokens, or ``None`` for model default.
    """

    provider: Literal["openai"] = "openai"
    model: str = Field(..., description="OpenAI model name, e.g. 'gpt-4o-mini'")
    api_key: str | None = Field(None, description="API key; defaults to OPENAI_API_KEY env var")
    base_url: str | None = Field(None, description="Override the OpenAI base URL")
    context_size: int | None = Field(None, description="Maximum context window tokens")
    response_size: int | None = Field(None, description="Maximum response length tokens")


class AnthropicLlmConfig(BaseModel):
    """LLM configuration for the Anthropic API.

    :param provider: Discriminator field; always ``"anthropic"``.
    :param model: Anthropic model name, e.g. ``"claude-sonnet-4-6"``.
    :param api_key: API key; falls back to the ``ANTHROPIC_API_KEY`` environment variable when
        ``None``.
    :param context_size: Maximum context window in tokens, or ``None`` for model default.
    :param response_size: Maximum response length in tokens, or ``None`` for model default.
    """

    provider: Literal["anthropic"] = "anthropic"
    model: str = Field(..., description="Anthropic model name, e.g. 'claude-sonnet-4-6'")
    api_key: str | None = Field(None, description="API key; defaults to ANTHROPIC_API_KEY env var")
    context_size: int | None = Field(None, description="Maximum context window tokens")
    response_size: int | None = Field(None, description="Maximum response length tokens")


class GoogleLlmConfig(BaseModel):
    """LLM configuration for the Google Gemini API.

    :param provider: Discriminator field; always ``"google"``.
    :param model: Gemini model name, e.g. ``"gemini-2.0-flash"``.
    :param api_key: API key; falls back to the ``GOOGLE_API_KEY`` or ``GEMINI_API_KEY``
        environment variable when ``None``.
    :param context_size: Maximum context window in tokens, or ``None`` for model default.
    :param response_size: Maximum response length in tokens, or ``None`` for model default.
    """

    provider: Literal["google"] = "google"
    model: str = Field(..., description="Gemini model name, e.g. 'gemini-2.0-flash'")
    api_key: str | None = Field(None, description="API key; defaults to GOOGLE_API_KEY env var")
    context_size: int | None = Field(None, description="Maximum context window tokens")
    response_size: int | None = Field(None, description="Maximum response length tokens")


class OpenAICompatLlmConfig(BaseModel):
    """LLM configuration for any OpenAI Chat Completions-compatible endpoint.

    Covers servers such as LM Studio, vLLM, and other self-hosted inference engines.

    :param provider: Discriminator field; always ``"openai-compatible"``.
    :param model: Model name as the endpoint expects it.
    :param base_url: Full base URL of the endpoint, e.g. ``"http://localhost:8080/v1"``.
    :param api_key: API key for authentication, or ``None`` if not required.
    :param context_size: Maximum context window in tokens, or ``None`` for server default.
    :param response_size: Maximum response length in tokens, or ``None`` for server default.
    """

    provider: Literal["openai-compatible"] = "openai-compatible"
    model: str = Field(..., description="Model name as the endpoint expects it")
    base_url: str = Field(..., description="Base URL of the OpenAI-compatible endpoint")
    api_key: str | None = Field(None, description="API key for authentication")
    context_size: int | None = Field(None, description="Maximum context window tokens")
    response_size: int | None = Field(None, description="Maximum response length tokens")


class FallbackLlmConfig(BaseModel):
    """LLM chain-of-responsibility configuration: try primary, fall back on transport failure.

    Both ``primary`` and ``fallback`` accept any :data:`LlmConfig`, including another
    :class:`FallbackLlmConfig`, enabling arbitrarily deep fallback chains expressed as
    inline YAML nested maps:

    .. code-block:: yaml

        llms:
          my_chain:
            provider: fallback
            primary:
              provider: ollama
              model: gemma3:4b
            fallback:
              provider: fallback
              primary:
                provider: openai
                model: gpt-4o-mini
              fallback:
                provider: anthropic
                model: claude-haiku-4-5-20251001

    :param provider: Discriminator field; always ``"fallback"``.
    :param primary: LLM configuration to try first.
    :param fallback: LLM configuration to use when primary raises a transport error.
    """

    provider: Literal["fallback"] = "fallback"
    primary: LlmConfig
    fallback: LlmConfig


LlmConfig: TypeAlias = Annotated[
    OllamaLlmConfig
    | OpenAILlmConfig
    | AnthropicLlmConfig
    | OpenAICompatLlmConfig
    | GoogleLlmConfig
    | FallbackLlmConfig,
    Field(discriminator="provider"),
]
"""Discriminated union of all supported LLM configurations, keyed on ``provider``."""

FallbackLlmConfig.model_rebuild()


class LlmRefSetting(BaseModel):
    """Plugin LLM setting that references a named LLM from the core ``llms`` registry.

    :param type: Discriminator field; always ``"ref"``.
    :param ref: Key in the top-level ``llms`` configuration dictionary.
    """

    type: Literal["ref"] = "ref"
    ref: str = Field(..., description="Name of the LLM entry in the top-level llms config")


class LlmInlineSetting(BaseModel):
    """Plugin LLM setting that defines a provider and model inline.

    Fields are a flat superset of all provider-specific options; only the fields relevant
    to the chosen ``provider`` are used when resolving.

    :param type: Discriminator field; always ``"custom"``.
    :param provider: Provider identifier; determines which fields are required.
    :param model: Model name or tag.
    :param context_size: Maximum context window in tokens, or ``None``.
    :param response_size: Maximum response length in tokens, or ``None``.
    :param host: Ollama server hostname (``ollama`` provider only).
    :param port: Ollama server port (``ollama`` provider only).
    :param api_key: API key (``openai``, ``anthropic``, ``openai-compatible`` providers).
    :param base_url: Endpoint base URL (``openai`` and ``openai-compatible`` providers).
    """

    type: Literal["custom"] = "custom"
    provider: Literal["ollama", "openai", "anthropic", "openai-compatible", "google"] = Field(
        ..., description="Provider identifier"
    )
    model: str = Field(..., description="Model name or tag")
    context_size: int | None = Field(None)
    response_size: int | None = Field(None)
    host: str = Field("127.0.0.1")
    port: int = Field(11434)
    api_key: str | None = Field(None)
    base_url: str | None = Field(None)


PluginLlmSetting: TypeAlias = Annotated[
    LlmRefSetting | LlmInlineSetting,
    Field(discriminator="type"),
]
"""Discriminated union for how a plugin specifies its LLM: by reference or inline."""
