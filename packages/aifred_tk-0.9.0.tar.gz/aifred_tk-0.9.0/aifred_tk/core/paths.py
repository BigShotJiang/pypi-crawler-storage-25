"""File path sanitization and access validation utilities for plugins.

Provides two public helpers:

- :func:`sanitize_file_path` — for single-file access where an inaccessible
  path is an error.
- :func:`filter_accessible_paths` — for multi-file operations (e.g., glob
  results) where ignored or missing paths should be silently skipped.
"""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

from aifred_tk.core.ignore import AiIgnoreChecker


class FileAccessError(Exception):
    """Raised when a file path fails access validation."""


def sanitize_file_path(raw: str | Path) -> Path:
    """Resolve and validate a single file path for safe plugin access.

    Resolves the path to its canonical form (eliminates traversal sequences
    and symlinks), then checks existence, regular-file status, and ``.aiignore``.

    Use this when accessing one specific file — failure is an error.
    For multi-file operations use :func:`filter_accessible_paths` instead.

    :param raw: Raw path string or Path from user input.
    :type raw: str | Path
    :raises FileAccessError: if the path is inaccessible or ignored.
    :return: Resolved, validated Path.
    :rtype: Path
    """
    path = Path(raw).resolve()
    if not path.exists():
        raise FileAccessError(f"File not found: {path}")
    if not path.is_file():
        raise FileAccessError(f"Path is not a regular file: {path}")
    if AiIgnoreChecker.for_path(path).is_ignored(path):
        raise FileAccessError(f"File is ignored by .aiignore: {path}")
    return path


def filter_accessible_paths(paths: Iterable[str | Path]) -> list[Path]:
    """Resolve and filter a collection of paths, silently dropping inaccessible ones.

    Resolves each path and drops any that do not exist, are not regular files,
    or are ignored by ``.aiignore``. Intended for multi-file operations (e.g.,
    glob results) where silently skipping protected files is the correct
    behaviour.

    :param paths: Iterable of raw path strings or Path objects.
    :type paths: Iterable[str | Path]
    :return: List of resolved, accessible Paths (may be empty).
    :rtype: list[Path]
    """
    result: list[Path] = []
    for raw in paths:
        path = Path(raw).resolve()
        if not path.exists() or not path.is_file():
            continue
        if AiIgnoreChecker.for_path(path).is_ignored(path):
            continue
        result.append(path)
    return result
