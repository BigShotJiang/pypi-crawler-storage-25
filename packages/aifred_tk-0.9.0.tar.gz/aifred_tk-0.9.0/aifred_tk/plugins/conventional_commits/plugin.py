"""Conventional commits plugin providing the ``commit`` tool.

The tool runs an iterative refinement loop with the LLM. On each iteration, the user can
approve the proposed message, select "Regenerate" to request a generic retry, or provide
free-text feedback which is forwarded as the next user message. Message history accumulates
across iterations, giving the model cumulative conversational context.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import git
from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field
from pydantic_ai.agent import AgentRunResult
from pydantic_ai.messages import ModelMessage

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs
from aifred_tk.core.llm import AgentRunner, build_agent_from_settings
from aifred_tk.core.models import ElicitationCancelledError
from aifred_tk.elicitation import Choice, elicit_choice

from ._agent import CONVENTIONAL_COMMITS_SYSTEM_PROMPT
from ._git import commit, get_staged_diff

_TOOL_ID = "commit"


class ConventionalCommitArgs(ToolArgs):
    """Arguments accepted by :class:`ConventionalCommitTool`.

    :param repo_path: Absolute path to the git repository root. Defaults to the
        current working directory when ``None``.
    """

    repo_path: str | None = Field(
        None,
        description=(
            "Absolute path to the git repository root. Defaults to the current working directory."
        ),
    )


class ConventionalCommitTool(Tool):
    """Generates and commits a conventional commit message via a PydanticAI agent.

    Reads staged changes, invokes an LLM to produce a conventional commit message,
    then enters an interactive approval loop before running ``git commit``.

    The approval loop supports three actions:

    - **Approve** — runs ``git commit`` with the proposed message.
    - **Regenerate** — sends a generic retry prompt in the same conversation thread.
    - **Free-text feedback** — forwards the user's input as the next user message so
      the model can incorporate specific guidance on the next attempt.
    """

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        The pydantic-ai agent is built lazily on first :meth:`execute` call so that
        plugin registration succeeds even when no API key is present in the environment.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings
        self._agent: AgentRunner[str] | None = None

    def _get_agent(self) -> AgentRunner[str]:
        """Return the agent runner, building it on first call.

        :return: Configured commit-message agent runner.
        :rtype: AgentRunner[str]
        """
        if self._agent is None:
            self._agent = build_agent_from_settings(
                _TOOL_ID,
                self._settings,
                output_type=str,
                system_prompt=CONVENTIONAL_COMMITS_SYSTEM_PROMPT,
            )
        return self._agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"commit"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Conventional Commit"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Reads staged git changes and uses an AI agent to generate a conventional commit "
            "message. Supports iterative refinement: approve the message, request a fresh attempt, "
            "or provide free-text feedback to guide the next generation."
        )

    @property
    def args_schema(self) -> type[ConventionalCommitArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`ConventionalCommitArgs` class.
        :rtype: type[ConventionalCommitArgs]
        """
        return ConventionalCommitArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Generate a commit message and drive the approval loop.

        Reads staged changes, invokes the AI agent, and loops until the user approves
        a message, provides feedback for regeneration, or cancels.

        The loop maintains a running ``message_history`` so each refinement iteration
        builds on the full prior conversation rather than starting fresh. Selecting
        "Regenerate" sends ``"Please generate an alternative commit message."`` as the
        next user prompt. Providing free-text input uses that text verbatim as the next
        prompt, allowing targeted feedback such as ``"make it shorter"`` or
        ``"add the api scope"``.

        :param args: Validated :class:`ConventionalCommitArgs` instance.
        :type args: ToolArgs
        :return: Result dict with a ``status`` key: ``"committed"``, ``"cancelled"``,
            or ``"error"``.
        :rtype: dict[str, Any]
        """
        commit_args = cast(ConventionalCommitArgs, args)
        repo_path = Path(commit_args.repo_path) if commit_args.repo_path else Path.cwd()

        try:
            diff = get_staged_diff(repo_path)
        except git.InvalidGitRepositoryError:
            logger.error("Not a git repository: {}", repo_path)
            return {"status": "error", "message": f"Not a git repository: {repo_path}"}
        except git.GitCommandError as exc:
            logger.error("git diff --cached failed: {}", exc)
            return {"status": "error", "message": f"git diff failed: {exc.stderr.strip()}"}

        if not diff.strip():
            return {
                "status": "error",
                "message": (
                    "No staged changes found. Stage files with 'git add' before running this tool."
                ),
            }

        user_prompt = (
            f"Generate a conventional commit message for the following staged diff:\n\n"
            f"```diff\n{diff}\n```"
        )
        message_history: list[ModelMessage] = []

        while True:
            logger.debug("Invoking commit agent")
            run_result: AgentRunResult[str] = self._get_agent().run_sync(
                user_prompt, message_history=message_history
            )
            commit_message: str = run_result.output.strip()
            message_history = list(run_result.all_messages())
            logger.info("Generated commit message: {!r}", commit_message)

            try:
                elicit_result = elicit_choice(
                    "What would you like to do with this commit message?",
                    choices=[
                        Choice("Approve", "Commit with this message"),
                        Choice("Regenerate", "Ask the AI to try again"),
                    ],
                    context=f"Proposed commit message:\n\n{commit_message}",
                    allow_free_input=True,
                    settings=self._settings,
                )
            except ElicitationCancelledError:
                logger.info("Commit cancelled by user")
                return {"status": "cancelled"}

            if elicit_result.is_free_input:
                user_prompt = (
                    elicit_result.free_text or "Please generate an alternative commit message."
                )
                continue

            if elicit_result.selected_label == "Approve":
                break

            user_prompt = "Please generate an alternative commit message."

        returncode, stdout, stderr = commit(commit_message, repo_path)
        if returncode != 0:
            logger.error("git commit failed (rc={}): {}", returncode, stderr)
            return {
                "status": "error",
                "message": "git commit failed",
                "returncode": returncode,
                "stderr": stderr.strip(),
            }

        logger.info("Committed successfully")
        return {
            "status": "committed",
            "commit_message": commit_message,
            "stdout": stdout.strip(),
        }


class ConventionalCommitsPlugin(Plugin):
    """Plugin that provides the :class:`ConventionalCommitTool`."""

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"conventional_commits"``
        :rtype: str
        """
        return "conventional_commits"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "Conventional Commits"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`ConventionalCommitTool`.
        :rtype: list[Tool]
        """
        return [ConventionalCommitTool(self._settings)]


def create_plugin(settings: Dynaconf) -> ConventionalCommitsPlugin:
    """Entry point factory for the conventional_commits plugin.

    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :return: Initialised :class:`ConventionalCommitsPlugin` instance.
    :rtype: ConventionalCommitsPlugin
    """
    return ConventionalCommitsPlugin(settings)
