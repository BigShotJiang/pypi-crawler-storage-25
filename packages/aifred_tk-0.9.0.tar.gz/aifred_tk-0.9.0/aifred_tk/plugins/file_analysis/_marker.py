"""Mark text plugin providing the ``mark_text`` tool."""

from __future__ import annotations

from typing import Any, cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field, model_validator

from aifred_tk.core.interfaces import Tool, ToolArgs
from aifred_tk.core.llm import AgentRunner, build_agent_from_settings
from aifred_tk.core.paths import FileAccessError, sanitize_file_path

from ._marker_agent import MARK_TEXT_SYSTEM_PROMPT

_TOOL_ID = "mark_text"
_MAX_FILE_BYTES = 1_048_576


class MarkTextArgs(ToolArgs):
    """Arguments accepted by :class:`MarkTextTool`.

    Exactly one of ``text`` or ``file_path`` must be provided.

    :param text: Inline text to mark. Mutually exclusive with ``file_path``.
    :param file_path: Path to a UTF-8 text file to mark. Mutually exclusive with ``text``.
    :param instructions: Marking instructions describing what to annotate and how
        (e.g. 'mark technology terms as technological'). Maximum 500 characters.
    :param context: Optional domain hint to resolve ambiguous terms
        (e.g. 'computing context'). Maximum 500 characters.
    """

    text: str | None = Field(
        None,
        max_length=100_000,
        description="Inline text to mark. Mutually exclusive with file_path.",
    )
    file_path: str | None = Field(
        None,
        description="Path to a UTF-8 text file to mark. Mutually exclusive with text.",
    )
    instructions: str = Field(
        ...,
        max_length=500,
        description=(
            "Marking instructions describing what to annotate and how "
            "(e.g. 'mark technology terms as technological'). Maximum 500 characters."
        ),
    )
    context: str | None = Field(
        None,
        max_length=500,
        description=(
            "Optional domain hint used to resolve ambiguous term boundaries "
            "(e.g. 'computing context'). Maximum 500 characters."
        ),
    )

    @model_validator(mode="after")
    def _validate_text_or_file_path(self) -> MarkTextArgs:
        """Enforce that exactly one of ``text`` or ``file_path`` is provided.

        :raises ValueError: When both or neither of ``text`` and ``file_path`` are set.
        :return: Validated instance.
        :rtype: MarkTextArgs
        """
        has_text = self.text is not None
        has_path = self.file_path is not None
        if has_text == has_path:
            raise ValueError("Provide exactly one of 'text' or 'file_path', not both or neither.")
        return self


class MarkTextTool(Tool):
    """Marks spans within text using an LLM agent according to caller-supplied instructions.

    The text content, marking instructions, and optional context are all wrapped in
    XML-style isolation markers before being forwarded to the agent, preventing the
    text content from acting as instructions (prompt injection).
    """

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        The pydantic-ai agent is built lazily on first :meth:`execute` call so that
        plugin registration succeeds even when no API key is present in the environment.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings
        self._agent: AgentRunner[str] | None = None

    def _get_agent(self) -> AgentRunner[str]:
        """Return the agent runner, building it on first call.

        :return: Configured mark-text agent runner.
        :rtype: AgentRunner[str]
        """
        if self._agent is None:
            self._agent = build_agent_from_settings(
                _TOOL_ID,
                self._settings,
                output_type=str,
                system_prompt=MARK_TEXT_SYSTEM_PROMPT,
            )
        return self._agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"mark_text"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Mark Text"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Annotates spans within text using XML-style tags according to marking instructions. "
            "Accepts inline text or a file path. "
            "An optional context string can be provided to help resolve ambiguous terms. "
            "Example: marking 'Python service' with instruction "
            "'mark technology terms as technological' yields "
            "'<technological>Python service</technological>'."
        )

    @property
    def args_schema(self) -> type[MarkTextArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`MarkTextArgs` class.
        :rtype: type[MarkTextArgs]
        """
        return MarkTextArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Mark spans within the provided text and return the annotated result.

        Loads text from a file or uses inline content, then submits it together with
        the marking instructions and optional context to the agent using XML isolation
        markers to prevent prompt injection.

        :param args: Validated :class:`MarkTextArgs` instance.
        :type args: ToolArgs
        :return: Result dict with a ``status`` key: ``"ok"`` or ``"error"``.
            On success, ``marked_text`` contains the annotated text.
        :rtype: dict[str, Any]
        """
        mark_args = cast(MarkTextArgs, args)

        if mark_args.file_path is not None:
            try:
                file_path = sanitize_file_path(mark_args.file_path)
            except FileAccessError as exc:
                logger.warning("File access denied: {}", exc)
                return {"status": "error", "message": str(exc)}

            file_size = file_path.stat().st_size
            if file_size > _MAX_FILE_BYTES:
                logger.error("File exceeds size limit ({} bytes): {}", _MAX_FILE_BYTES, file_path)
                return {
                    "status": "error",
                    "message": (
                        f"File exceeds the {_MAX_FILE_BYTES // 1_048_576} MB size limit "
                        f"({file_size} bytes)."
                    ),
                }

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except OSError as exc:
                logger.error("Failed to read file {}: {}", file_path, exc)
                return {"status": "error", "message": f"Failed to read file: {exc}"}
        else:
            content = mark_args.text or ""

        user_message = (
            f"<marking_instructions>\n{mark_args.instructions}\n</marking_instructions>\n\n"
            f"<text_content>\n{content}\n</text_content>"
        )
        if mark_args.context is not None:
            user_message += f"\n\n<context>\n{mark_args.context}\n</context>"

        logger.debug("Invoking mark-text agent")
        try:
            run_result = self._get_agent().run_sync(user_message)
        except Exception as exc:
            logger.error("Agent error during mark_text: {}", exc)
            return {"status": "error", "message": f"Agent error: {exc}"}

        return {"status": "ok", "marked_text": run_result.output.strip()}
