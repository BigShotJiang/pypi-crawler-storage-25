"""Semantic code analysis tool using LSP symbol extraction and bottom-up LLM analysis."""

from __future__ import annotations

import ast
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal, cast

import yaml
from dynaconf import Dynaconf
from loguru import logger
from multilspy.multilspy_types import UnifiedSymbolInformation
from pydantic import BaseModel, Field

from aifred_tk.core.interfaces import Tool, ToolArgs
from aifred_tk.core.llm import AgentRunner, build_agent_from_settings
from aifred_tk.core.paths import FileAccessError, sanitize_file_path

from ._fast_analysis import _FAST_ANALYSIS_SYSTEM_PROMPT, FastPathAnalysisResult, FastPathSymbol
from ._lsp import (
    build_fqn,
    extract_source_lines,
    extract_symbols,
    resolve_workspace,
    sort_bottom_up,
    symbol_kind_name,
)
from ._symbol_agent import _SYMBOL_ANALYSIS_SYSTEM_PROMPT, SymbolAnalysisResult

_TOOL_ID = "semantic_code_analysis"


class SemanticCodeAnalysisArgs(ToolArgs):
    """Arguments accepted by :class:`SemanticCodeAnalysisTool`.

    :param file_path: Absolute or relative path to the source file to analyse.
    :param language: Programming language identifier used to select the LSP server.
    :param prompt: Analysis request applied to every symbol (max 500 characters).
    :param output_file: Optional path to write the analysis report.
    :param output_format: ``"json"`` (default) returns or writes the full structured report;
        ``"markdown"`` returns or writes a human-readable summary;
        ``"yaml"`` returns or writes the full structured report in YAML block format.
    :param max_retries: Maximum LLM call attempts per symbol before skipping it (LSP path only).
    :param local_symbols_only: When ``True`` (default), restrict analysis to symbols defined
        in the analysed file; set to ``False`` to include imported symbols (LSP path only).
    :param fast_path_max_bytes: When greater than ``0``, files whose byte size is strictly below
        this threshold bypass the LSP. The full file is passed to the LLM in a single call,
        which identifies and analyses symbols itself. ``0`` (default) always uses the LSP.
        The output structure is identical to the LSP path regardless of which is taken.
    :param excluded_symbol_kinds: Symbol kind names to skip during analysis (case-insensitive).
        Symbols of these kinds are silently dropped before any LLM call is made.
        Both paths (LSP and fast) honour this list.
    """

    file_path: str = Field(description="Path to the source file to analyse.")
    language: str = Field(
        description=(
            "Programming language of the file. Supported values: "
            "'python', 'typescript', 'javascript', 'java', 'rust', 'go', "
            "'kotlin', 'csharp', 'ruby', 'dart'."
        )
    )
    prompt: str = Field(
        max_length=500,
        description=(
            "Analysis request applied to every symbol "
            "(e.g. 'describe what this symbol does', 'find security issues'). "
            "Maximum 500 characters."
        ),
    )
    output_file: str | None = Field(
        None,
        description="Optional path to write the analysis report. Defaults to returning inline.",
    )
    output_format: Literal["json", "markdown", "yaml"] = Field(
        "json",
        description=(
            "Output format. "
            "'json' (default) returns/writes the full structured report; "
            "'markdown' returns/writes a human-readable summary; "
            "'yaml' returns/writes the full structured report in YAML block format."
        ),
    )
    max_retries: int = Field(
        3,
        ge=1,
        le=10,
        description="Maximum LLM call attempts per symbol before skipping it. Default 3.",
    )
    local_symbols_only: bool = Field(
        True,
        description=(
            "When True (default), only symbols whose definition resides in the analysed file "
            "are included. Set to False to include all symbols returned by the language server."
        ),
    )
    fast_path_max_bytes: int = Field(
        0,
        ge=0,
        description=(
            "When greater than 0, files strictly smaller than this byte count bypass the LSP "
            "and are passed directly to the LLM for symbol extraction and analysis in one shot. "
            "0 (default) always uses the LSP regardless of file size."
        ),
    )
    excluded_symbol_kinds: list[str] = Field(
        default_factory=list,
        description=(
            "Symbol kind names to exclude from analysis (case-insensitive). "
            "Symbols of matching kinds are silently dropped before any LLM call is made. "
            "Both the LSP and fast paths honour this list. "
            "LSP kinds: 'Function', 'Method', 'Class', 'Constructor', 'Property', "
            "'Variable', 'Constant', 'Field', 'Interface', 'Enum', 'Module', 'Namespace', "
            "'Package', 'String', 'Number', 'Boolean', 'Array', 'Object', 'Key', 'Null', "
            "'EnumMember', 'Struct', 'Event', 'Operator', 'TypeParameter'. "
            "Fast-path LLM also honours: all of the above. "
            "Default: [] (no exclusions)."
        ),
    )


class SymbolRecord(BaseModel):
    """Analysis result for a single code symbol.

    :param fqn: Fully-qualified name (container.name, or name for top-level symbols).
    :param kind: Symbol kind name (e.g. ``"Function"``, ``"Class"``).
    :param start_line: First line of the symbol (1-based).
    :param end_line: Last line of the symbol (1-based).
    :param start_col: Start column (0-based).
    :param end_col: End column (0-based).
    :param analysis: Semantic description of the symbol's behaviour.
    :param issues: Issues identified within this symbol.
    :param error: Error message when the LLM analysis failed for this symbol; ``None`` on success.
    :param children: Nested child symbols (e.g. methods inside a class), sorted by start line.
    """

    fqn: str
    kind: str
    start_line: int
    end_line: int
    start_col: int
    end_col: int
    analysis: str
    issues: list[str]
    error: str | None = Field(
        None, description="Error message when analysis failed for this symbol."
    )
    children: list[SymbolRecord] = Field(default_factory=list)


SymbolRecord.model_rebuild()


class SemanticAnalysisReport(BaseModel):
    """Full semantic analysis report for a source file.

    :param file_path: Workspace-relative path to the analysed file.
    :param language: Language identifier used for LSP.
    :param analyzed_at: UTC timestamp in ISO 8601 format.
    :param symbols: Top-level symbol records with children nested inside them, sorted by start line.
    :param issues: Deduplicated flat list of all issues found across symbols.
    :param errors: Error messages for symbols whose LLM analysis failed after all retries.
    """

    file_path: str
    language: str
    analyzed_at: str
    symbols: list[SymbolRecord]
    issues: list[str]
    errors: list[str] = Field(default_factory=list)


_BLOCK_COMMENT_RE = re.compile(r"/\*\*[\s\S]*?\*/|/\*[\s\S]*?\*/")
_LINE_DOC_RE = re.compile(r"(?:///[^\n]*\n?|//![^\n]*\n?)+")


def _is_local_symbol(sym: UnifiedSymbolInformation, file_path: Path) -> bool:
    """Return True when *sym* is defined in *file_path* (or has no location info).

    :param sym: LSP symbol to check.
    :type sym: UnifiedSymbolInformation
    :param file_path: Resolved absolute path of the file being analysed.
    :type file_path: Path
    :return: True if the symbol is local to *file_path*.
    :rtype: bool
    """
    location = sym.get("location")
    if location is None:
        return True
    abs_path = location.get("absolutePath")
    if abs_path:
        return Path(abs_path) == file_path
    uri: str = location.get("uri", "")
    if uri.startswith("file://"):
        return Path(uri[7:]) == file_path
    return True


def _extract_doc(source: str, language: str) -> str | None:
    """Return only the documentation portion of a container symbol's source.

    For Python, uses :func:`ast.get_docstring` on the first parsed node.
    For other languages, extracts leading block doc comments (``/** */``, ``/* */``)
    or line doc comments (``///``, ``//!``).  Returns ``None`` when no
    documentation is found.

    :param source: Raw source text for the symbol.
    :type source: str
    :param language: Language identifier (e.g. ``"python"``).
    :type language: str
    :return: Documentation string, or ``None``.
    :rtype: str | None
    """
    if language == "python":
        try:
            tree = ast.parse(source)
            if tree.body:
                node = tree.body[0]
                if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef, ast.ClassDef)):
                    return ast.get_docstring(node)
        except SyntaxError:
            pass
        return None
    stripped = source.lstrip()
    m = _BLOCK_COMMENT_RE.match(stripped)
    if m:
        return m.group(0)
    m = _LINE_DOC_RE.match(stripped)
    if m:
        return m.group(0).rstrip()
    return None


def _build_previously_analyzed_md(records: list[SymbolRecord]) -> str:
    if not records:
        return ""
    parts: list[str] = []
    for rec in records:
        if rec.error is None:
            parts.append(f"## `{rec.fqn}` ({rec.kind})\n{rec.analysis}")
    return "\n\n".join(parts)


def _nest_records(records: list[SymbolRecord]) -> list[SymbolRecord]:
    """Arrange a flat list of records into a tree using FQN hierarchy.

    A record whose FQN contains a dot is treated as a child of the record whose
    FQN equals the prefix before the last dot.  Records with no matching parent
    (or no dot in their FQN) become top-level entries.  Both the top-level list
    and each record's ``children`` list are sorted by ``start_line``.

    :param records: Flat list of analysed symbol records (order does not matter).
    :type records: list[SymbolRecord]
    :return: Top-level records with children populated.
    :rtype: list[SymbolRecord]
    """
    fqn_to_record = {rec.fqn: rec for rec in records}
    top_level: list[SymbolRecord] = []
    for rec in records:
        if "." in rec.fqn:
            parent_fqn = rec.fqn.rsplit(".", 1)[0]
            parent = fqn_to_record.get(parent_fqn)
            if parent is not None:
                parent.children.append(rec)
                continue
        top_level.append(rec)
    top_level.sort(key=lambda r: r.start_line)
    for rec in fqn_to_record.values():
        rec.children.sort(key=lambda r: r.start_line)
    return top_level


def _render_symbol_md(sym: SymbolRecord, depth: int) -> list[str]:
    heading = "#" * depth
    lines: list[str] = [
        f"{heading} `{sym.fqn}` ({sym.kind})",
        f"Lines {sym.start_line}–{sym.end_line}",
        "",
    ]
    if sym.error is not None:
        lines += [f"**Analysis failed:** {sym.error}", ""]
    else:
        lines += [sym.analysis, ""]
        if sym.issues:
            lines += ["**Issues:**", ""]
            for issue in sym.issues:
                lines.append(f"- {issue}")
            lines.append("")
    for child in sym.children:
        lines += _render_symbol_md(child, depth + 1)
    return lines


def _render_yaml(report: SemanticAnalysisReport) -> str:
    """Serialise *report* as YAML block style.

    :param report: Completed semantic analysis report.
    :type report: SemanticAnalysisReport
    :return: YAML-formatted string.
    :rtype: str
    """
    return str(
        yaml.dump(
            report.model_dump(), default_flow_style=False, allow_unicode=True, sort_keys=False
        )
    )


def _render_markdown(report: SemanticAnalysisReport) -> str:
    lines: list[str] = [
        f"# Semantic Analysis: `{report.file_path}`",
        f"Language: {report.language}  |  Analyzed at: {report.analyzed_at}",
        "",
    ]
    if report.issues:
        lines += ["## Issues", ""]
        for issue in report.issues:
            lines.append(f"- {issue}")
        lines.append("")
    if report.errors:
        lines += ["## Analysis Errors", ""]
        for err in report.errors:
            lines.append(f"- {err}")
        lines.append("")
    lines += ["## Symbols", ""]
    for sym in report.symbols:
        lines += _render_symbol_md(sym, depth=3)
    return "\n".join(lines)


def _collect_issues_recursive(records: list[SymbolRecord]) -> list[str]:
    """Collect and deduplicate issues from a nested symbol record tree.

    :param records: Top-level records with children already populated.
    :type records: list[SymbolRecord]
    :return: Deduplicated issue strings in traversal order.
    :rtype: list[str]
    """
    seen: set[str] = set()
    issues: list[str] = []

    def _traverse(recs: list[SymbolRecord]) -> None:
        for rec in recs:
            for issue in rec.issues:
                if issue not in seen:
                    seen.add(issue)
                    issues.append(issue)
            _traverse(rec.children)

    _traverse(records)
    return issues


def _filter_fast_path_symbols(
    symbols: list[FastPathSymbol], excluded_kinds: frozenset[str]
) -> list[FastPathSymbol]:
    """Recursively remove symbols whose kind appears in *excluded_kinds*.

    :param symbols: Symbols to filter (may be nested).
    :type symbols: list[FastPathSymbol]
    :param excluded_kinds: Lower-cased kind names to drop.
    :type excluded_kinds: frozenset[str]
    :return: Filtered list with matching symbols and their subtrees removed.
    :rtype: list[FastPathSymbol]
    """
    return [
        sym.model_copy(update={"children": _filter_fast_path_symbols(sym.children, excluded_kinds)})
        for sym in symbols
        if sym.kind.lower() not in excluded_kinds
    ]


def _fast_path_symbol_to_record(sym: FastPathSymbol) -> SymbolRecord:
    """Convert a :class:`FastPathSymbol` to a :class:`SymbolRecord`.

    Column positions are set to ``0`` because the fast path does not use LSP.

    :param sym: Fast-path symbol returned by the LLM.
    :type sym: FastPathSymbol
    :return: Equivalent symbol record compatible with :class:`SemanticAnalysisReport`.
    :rtype: SymbolRecord
    """
    return SymbolRecord(
        fqn=sym.fqn,
        kind=sym.kind,
        start_line=sym.start_line,
        end_line=sym.end_line,
        start_col=0,
        end_col=0,
        analysis=sym.analysis,
        issues=sym.issues,
        error=None,
        children=[_fast_path_symbol_to_record(child) for child in sym.children],
    )


def _emit_report(
    report: SemanticAnalysisReport,
    analysis_args: SemanticCodeAnalysisArgs,
) -> dict[str, Any] | str:
    """Render and return (or write) *report* according to *analysis_args* output settings.

    :param report: Completed semantic analysis report.
    :type report: SemanticAnalysisReport
    :param analysis_args: Validated tool arguments carrying output options.
    :type analysis_args: SemanticCodeAnalysisArgs
    :return: Result dict or raw string depending on format and output_file.
    :rtype: dict[str, Any] | str
    """
    if analysis_args.output_file is not None:
        output_path = Path(analysis_args.output_file)
        report_dict = report.model_dump()
        written_result: dict[str, Any] = {
            "status": "written",
            "output_file": str(output_path),
            "report": report_dict,
        }
        if analysis_args.output_format == "json":
            content = json.dumps(written_result, indent=2)
        elif analysis_args.output_format == "yaml":
            content = _render_yaml(report)
        else:
            content = _render_markdown(report)
        try:
            output_path.write_text(content, encoding="utf-8")
        except OSError as exc:
            logger.error("Failed to write output file {}: {}", output_path, exc)
            return {"status": "error", "message": f"Failed to write output file: {exc}"}
        return written_result
    if analysis_args.output_format == "markdown":
        return _render_markdown(report)
    if analysis_args.output_format == "yaml":
        return _render_yaml(report)
    return {"status": "ok", "report": report.model_dump()}


class SemanticCodeAnalysisTool(Tool):
    """Analyses a source file semantically using LLM, with optional LSP-backed symbol extraction.

    **LSP path (default):** queries a language server for the file's symbol tree, sorts symbols
    bottom-up (leaves first), then calls an LLM agent on each symbol with accumulated context.

    **Fast path:** when ``fast_path_max_bytes`` is set and the file is smaller than the threshold,
    the LSP is skipped and the full file is passed to a single LLM call that identifies symbols
    and analyses them in one shot. The output is identical in structure to the LSP path.

    The final report always contains per-symbol analyses, a deduplicated issue list, and a
    UTC timestamp, regardless of which path was taken.
    """

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        Both agents are built lazily on first :meth:`execute` call.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings
        self._agent: AgentRunner[SymbolAnalysisResult] | None = None
        self._fast_agent: AgentRunner[FastPathAnalysisResult] | None = None

    def _get_agent(self) -> AgentRunner[SymbolAnalysisResult]:
        """Return the LSP-path symbol analysis agent runner, building it on first call.

        :return: Configured symbol analysis agent runner.
        :rtype: AgentRunner[SymbolAnalysisResult]
        """
        if self._agent is None:
            self._agent = build_agent_from_settings(
                _TOOL_ID,
                self._settings,
                output_type=SymbolAnalysisResult,
                system_prompt=_SYMBOL_ANALYSIS_SYSTEM_PROMPT,
                llm_subkey="lsp_llm",
            )
        return self._agent

    def _get_fast_agent(self) -> AgentRunner[FastPathAnalysisResult]:
        """Return the fast-path whole-file analysis agent runner, building it on first call.

        :return: Configured fast-path analysis agent runner.
        :rtype: AgentRunner[FastPathAnalysisResult]
        """
        if self._fast_agent is None:
            self._fast_agent = build_agent_from_settings(
                _TOOL_ID,
                self._settings,
                output_type=FastPathAnalysisResult,
                system_prompt=_FAST_ANALYSIS_SYSTEM_PROMPT,
                llm_subkey="fast_llm",
            )
        return self._fast_agent

    def _execute_fast_path(
        self,
        analysis_args: SemanticCodeAnalysisArgs,
        file_path: Path,
        report_path: str,
    ) -> dict[str, Any] | str:
        """Run whole-file LLM analysis without LSP, returning a compatible report.

        :param analysis_args: Validated tool arguments.
        :type analysis_args: SemanticCodeAnalysisArgs
        :param file_path: Resolved absolute path to the source file.
        :type file_path: Path
        :param report_path: Workspace-relative path used in the report.
        :type report_path: str
        :return: Same shape as :meth:`execute` — dict or raw string.
        :rtype: dict[str, Any] | str
        """
        try:
            file_content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.error("Failed to read file {}: {}", file_path, exc)
            return {"status": "error", "message": f"Failed to read file: {exc}"}

        user_message = (
            f"<analysis_request>\n{analysis_args.prompt}\n</analysis_request>\n\n"
            f"<file_path>\n{report_path}\n</file_path>\n\n"
            f"<source>\n{file_content}\n</source>"
        )

        try:
            result = self._get_fast_agent().run_sync(user_message).output
        except Exception as exc:
            logger.error("Fast-path analysis failed for {}: {}", file_path, exc)
            return {"status": "error", "message": f"Fast-path analysis failed: {exc}"}

        if analysis_args.excluded_symbol_kinds:
            excluded = frozenset(k.lower() for k in analysis_args.excluded_symbol_kinds)
            result = FastPathAnalysisResult(
                symbols=_filter_fast_path_symbols(result.symbols, excluded)
            )

        records = [_fast_path_symbol_to_record(sym) for sym in result.symbols]
        report = SemanticAnalysisReport(
            file_path=report_path,
            language=analysis_args.language,
            analyzed_at=datetime.now(tz=UTC).isoformat(),
            symbols=records,
            issues=_collect_issues_recursive(records),
            errors=[],
        )
        logger.info(
            "Fast-path analysis complete: {} top-level symbol(s) in {}", len(records), file_path
        )
        return _emit_report(report, analysis_args)

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"semantic_code_analysis"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Semantic Code Analysis"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Performs a semantic analysis of a source file and returns a structured report with "
            "per-symbol analyses, a deduplicated issue list, and a UTC timestamp. "
            "By default, uses a language server (LSP) to extract the symbol tree, then analyses "
            "each symbol bottom-up (leaves first) with an LLM, passing prior analyses as context. "
            "When fast_path_max_bytes is set and the file is smaller than that threshold, "
            "the LSP is skipped and the full file is passed to the LLM directly, which identifies "
            "symbols and analyses them in one shot. Both paths return the same report structure."
        )

    @property
    def args_schema(self) -> type[SemanticCodeAnalysisArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`SemanticCodeAnalysisArgs` class.
        :rtype: type[SemanticCodeAnalysisArgs]
        """
        return SemanticCodeAnalysisArgs

    def execute(self, args: ToolArgs) -> dict[str, Any] | str:
        """Run semantic analysis on a source file using either the LSP or the fast path.

        Validates the file and resolves the workspace path, then selects the analysis strategy:

        - **Fast path** (when ``fast_path_max_bytes > 0`` and ``file size < fast_path_max_bytes``):
          passes the full file to a single LLM call via :meth:`_execute_fast_path`.
        - **LSP path** (default): extracts symbols via a language server, sorts them bottom-up,
          and calls the LLM agent on each symbol with accumulated context.

        :param args: Validated :class:`SemanticCodeAnalysisArgs` instance.
        :type args: ToolArgs
        :return: Result dict with ``status`` key (``"ok"``, ``"written"``, or ``"error"``),
            or a raw string when ``output_format`` is ``"markdown"`` or ``"yaml"`` and
            no ``output_file`` is provided.
        :rtype: dict[str, Any] | str
        """
        analysis_args = cast(SemanticCodeAnalysisArgs, args)
        try:
            file_path = sanitize_file_path(analysis_args.file_path)
        except FileAccessError as exc:
            logger.warning("File access denied: {}", exc)
            return {"status": "error", "message": str(exc)}

        workspace = resolve_workspace(file_path)
        logger.debug("LSP workspace resolved to: {}", workspace)
        try:
            report_path = str(file_path.relative_to(workspace))
        except ValueError:
            report_path = str(file_path)

        if (
            analysis_args.fast_path_max_bytes > 0
            and file_path.stat().st_size < analysis_args.fast_path_max_bytes
        ):
            logger.debug(
                "File {} is below fast-path threshold ({} B), skipping LSP",
                file_path,
                analysis_args.fast_path_max_bytes,
            )
            return self._execute_fast_path(analysis_args, file_path, report_path)

        try:
            raw_symbols = extract_symbols(analysis_args.language, workspace, file_path)
        except Exception as exc:
            logger.error("LSP symbol extraction failed for {}: {}", file_path, exc)
            return {"status": "error", "message": f"LSP error: {exc}"}

        if analysis_args.local_symbols_only:
            raw_symbols = [s for s in raw_symbols if _is_local_symbol(s, file_path)]

        if analysis_args.excluded_symbol_kinds:
            excluded = frozenset(k.lower() for k in analysis_args.excluded_symbol_kinds)
            raw_symbols = [s for s in raw_symbols if symbol_kind_name(s).lower() not in excluded]

        if not raw_symbols:
            return {
                "status": "error",
                "message": "No symbols found (language server returned an empty result).",
            }

        try:
            file_lines = file_path.read_text(encoding="utf-8", errors="replace").splitlines(
                keepends=True
            )
        except OSError as exc:
            logger.error("Failed to read file {}: {}", file_path, exc)
            return {"status": "error", "message": f"Failed to read file: {exc}"}

        ordered = sort_bottom_up(raw_symbols)
        container_fqns: set[str] = set()
        for sym in ordered:
            if sym.get("containerName"):
                child_fqn = build_fqn(sym["name"], sym["containerName"])
                container_fqns.add(child_fqn.rsplit(".", 1)[0])

        agent = self._get_agent()
        records: list[SymbolRecord] = []

        for sym in ordered:
            fqn = build_fqn(sym["name"], sym.get("containerName", ""))
            kind = symbol_kind_name(sym)
            sym_range = sym.get("range")

            if sym_range is not None:
                start_line = sym_range["start"]["line"] + 1
                end_line = sym_range["end"]["line"] + 1
                start_col = sym_range["start"]["character"]
                end_col = sym_range["end"]["character"]
                source = extract_source_lines(file_lines, sym_range)
            else:
                start_line = end_line = start_col = end_col = 0
                source = ""

            if fqn in container_fqns:
                display_source: str | None = _extract_doc(source, analysis_args.language)
            else:
                display_source = source

            prev_md = _build_previously_analyzed_md(records)
            user_message = (
                f"<analysis_request>\n{analysis_args.prompt}\n</analysis_request>\n\n"
                f"<symbol_to_analyze>\n"
                f"Name: {fqn}  Kind: {kind}  Lines: {start_line}-{end_line}"
                f"  Cols: {start_col}-{end_col}\n"
            )
            if display_source:
                user_message += f"<symbol_source>\n{display_source}\n</symbol_source>\n"
            user_message += "</symbol_to_analyze>"
            if prev_md:
                user_message += f"\n\n<previously_analyzed>\n{prev_md}\n</previously_analyzed>"

            logger.debug("Analysing symbol: {} ({})", fqn, kind)
            sym_result: SymbolAnalysisResult | None = None
            last_exc: Exception | None = None
            for attempt in range(analysis_args.max_retries):
                try:
                    sym_result = agent.run_sync(user_message).output
                    break
                except Exception as exc:
                    last_exc = exc
                    logger.warning(
                        "Symbol '{}' attempt {}/{} failed: {}",
                        fqn,
                        attempt + 1,
                        analysis_args.max_retries,
                        exc,
                    )

            if sym_result is None:
                error_msg = f"Symbol '{fqn}': {last_exc}"
                logger.error("All retries exhausted for symbol '{}': {}", fqn, last_exc)
                records.append(
                    SymbolRecord(
                        fqn=fqn,
                        kind=kind,
                        start_line=start_line,
                        end_line=end_line,
                        start_col=start_col,
                        end_col=end_col,
                        analysis="",
                        issues=[],
                        error=error_msg,
                    )
                )
                continue

            records.append(
                SymbolRecord(
                    fqn=fqn,
                    kind=kind,
                    start_line=start_line,
                    end_line=end_line,
                    start_col=start_col,
                    end_col=end_col,
                    analysis=sym_result.analysis,
                    issues=sym_result.issues,
                    error=None,
                )
            )

        seen: set[str] = set()
        all_issues: list[str] = []
        for rec in records:
            for issue in rec.issues:
                if issue not in seen:
                    seen.add(issue)
                    all_issues.append(issue)
        all_errors = [rec.error for rec in records if rec.error is not None]

        report = SemanticAnalysisReport(
            file_path=report_path,
            language=analysis_args.language,
            analyzed_at=datetime.now(tz=UTC).isoformat(),
            symbols=_nest_records(records),
            issues=all_issues,
            errors=all_errors,
        )
        logger.info(
            "Semantic analysis complete: {} symbol(s) analysed in {}", len(records), file_path
        )
        return _emit_report(report, analysis_args)
