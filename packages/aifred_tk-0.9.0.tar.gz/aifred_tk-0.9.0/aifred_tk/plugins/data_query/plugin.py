"""Data query plugin providing the ``query_json_data_file`` tool."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal, cast

import yaml
from dynaconf import Dynaconf
from jsonpath_ng.ext import parse as jsonpath_parse
from loguru import logger
from pydantic import Field, model_validator

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs
from aifred_tk.core.paths import FileAccessError, sanitize_file_path

_TOOL_ID = "query_json_data_file"
_YAML_EXTENSIONS = {".yaml", ".yml"}
_JSON_EXTENSIONS = {".json"}


class QueryJsonDataFileArgs(ToolArgs):
    """Arguments accepted by :class:`QueryJsonDataFileTool`.

    Exactly one of ``file_path`` or ``content`` must be provided.
    ``format`` is required when ``content`` is used; it is auto-detected from the
    file extension when ``file_path`` is used but can be overridden.

    :param file_path: Path to a JSON or YAML file on disk.
    :param content: Raw JSON or YAML content string.
    :param format: Data format (``"json"`` or ``"yaml"``).
    :param jsonpath_expression: JSONPath expression to evaluate.
    """

    file_path: str | None = Field(None, description="Path to a JSON or YAML file on disk.")
    content: str | None = Field(None, description="Raw JSON or YAML content string.")
    format: Literal["json", "yaml"] | None = Field(
        None,
        description=(
            "Data format: 'json' or 'yaml'. "
            "Required when 'content' is provided; "
            "auto-detected from extension when 'file_path' is used."
        ),
    )
    jsonpath_expression: str = Field(
        ...,
        description="JSONPath expression to evaluate (e.g. '$.servers[*].host').",
    )

    @model_validator(mode="after")
    def _validate_inputs(self) -> QueryJsonDataFileArgs:
        """Enforce mutual exclusion and format resolution.

        :raises ValueError: When input combination is invalid.
        :return: Validated instance with ``format`` resolved.
        :rtype: QueryJsonDataFileArgs
        """
        has_path = self.file_path is not None
        has_content = self.content is not None

        if has_path == has_content:
            raise ValueError(
                "Provide exactly one of 'file_path' or 'content', not both or neither."
            )

        if has_content and self.format is None:
            raise ValueError("'format' is required when 'content' is provided.")

        if has_path and self.format is None:
            ext = Path(self.file_path).suffix.lower()  # type: ignore[arg-type]
            if ext in _YAML_EXTENSIONS:
                self.format = "yaml"
            elif ext in _JSON_EXTENSIONS:
                self.format = "json"
            else:
                raise ValueError(
                    f"Cannot auto-detect format from extension '{ext}'. "
                    "Provide 'format' explicitly."
                )

        return self


class QueryJsonDataFileTool(Tool):
    """Queries JSON or YAML data using a JSONPath expression."""

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"query_json_data_file"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Query JSON Data File"

    @property
    def description(self) -> str:
        """Return the tool description.

        :return: Description string.
        :rtype: str
        """
        return (
            "Queries a JSON or YAML data source using a JSONPath expression. "
            "Accepts either a file path or an inline content string. "
            "Returns all matched values and their count."
        )

    @property
    def args_schema(self) -> type[QueryJsonDataFileArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`QueryJsonDataFileArgs` class.
        :rtype: type[QueryJsonDataFileArgs]
        """
        return QueryJsonDataFileArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Evaluate a JSONPath expression against a JSON or YAML data source.

        :param args: Validated :class:`QueryJsonDataFileArgs` instance.
        :type args: ToolArgs
        :return: Result dict with ``status``, ``results`` list, and ``count``.
        :rtype: dict[str, Any]
        """
        q_args = cast(QueryJsonDataFileArgs, args)

        raw_text = self._load_text(q_args)
        if isinstance(raw_text, dict):
            return raw_text

        data = self._parse(raw_text, q_args.format)  # type: ignore[arg-type]
        if isinstance(data, dict) and data.get("status") == "error":
            return data

        return self._query(data, q_args.jsonpath_expression)

    def _load_text(self, args: QueryJsonDataFileArgs) -> str | dict[str, Any]:
        """Load raw text from file or inline content.

        :param args: Validated arguments.
        :type args: QueryJsonDataFileArgs
        :return: Raw text string, or an error dict.
        :rtype: str | dict[str, Any]
        """
        if args.content is not None:
            return args.content

        try:
            file_path = sanitize_file_path(args.file_path)  # type: ignore[arg-type]
        except FileAccessError as exc:
            logger.warning("File access denied: {}", exc)
            return {"status": "error", "message": str(exc)}

        return file_path.read_text(encoding="utf-8", errors="replace")

    def _parse(self, text: str, fmt: Literal["json", "yaml"]) -> Any:
        """Parse raw text into a Python object.

        :param text: Raw JSON or YAML text.
        :type text: str
        :param fmt: Format identifier.
        :type fmt: Literal["json", "yaml"]
        :return: Parsed Python object or an error dict.
        :rtype: Any
        """
        try:
            if fmt == "json":
                return json.loads(text)
            return yaml.safe_load(text)
        except Exception as exc:
            logger.error("Failed to parse {} content: {}", fmt, exc)
            return {"status": "error", "message": f"Failed to parse {fmt} content: {exc}"}

    def _query(self, data: Any, expression: str) -> dict[str, Any]:
        """Apply a JSONPath expression to parsed data.

        :param data: Parsed Python data structure.
        :param expression: JSONPath expression string.
        :type expression: str
        :return: Result dict with ``status``, ``results``, and ``count``.
        :rtype: dict[str, Any]
        """
        try:
            jsonpath_expr = jsonpath_parse(expression)
        except Exception as exc:
            logger.error("Invalid JSONPath expression '{}': {}", expression, exc)
            return {"status": "error", "message": f"Invalid JSONPath expression: {exc}"}

        matches = jsonpath_expr.find(data)
        results = [match.value for match in matches]
        return {"status": "ok", "results": results, "count": len(results)}


class DataQueryPlugin(Plugin):
    """Plugin that provides the :class:`QueryJsonDataFileTool`."""

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"data_query"``
        :rtype: str
        """
        return "data_query"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "Data Query"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`QueryJsonDataFileTool`.
        :rtype: list[Tool]
        """
        return [QueryJsonDataFileTool()]


def create_plugin(_settings: Dynaconf) -> DataQueryPlugin:
    """Entry point factory for the data_query plugin.

    :param _settings: Active Dynaconf settings instance (unused but required by interface).
    :type _settings: Dynaconf
    :return: Initialised :class:`DataQueryPlugin` instance.
    :rtype: DataQueryPlugin
    """
    return DataQueryPlugin()
