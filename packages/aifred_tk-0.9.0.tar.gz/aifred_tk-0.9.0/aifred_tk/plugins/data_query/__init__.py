"""Data query plugin package."""
