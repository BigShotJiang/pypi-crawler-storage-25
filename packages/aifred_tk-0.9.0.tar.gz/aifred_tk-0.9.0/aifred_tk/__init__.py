"""AIfred toolkit — AI agent toolkit with CLI and MCP presentation layers."""

__version__ = "0.9.0"
