"""Unit tests for the conventional_commits plugin."""

from contextlib import nullcontext
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import git
import pytest

from aifred_tk.core.models import ConfigurationError, ElicitationCancelledError
from aifred_tk.elicitation import ElicitationResult
from aifred_tk.plugins.conventional_commits.plugin import (
    ConventionalCommitArgs,
    ConventionalCommitsPlugin,
    ConventionalCommitTool,
    create_plugin,
)


def _make_agent(output: str = "feat: add feature") -> MagicMock:
    run_result = MagicMock()
    run_result.output = output
    run_result.all_messages.return_value = []
    agent = MagicMock()
    agent.run_sync.return_value = run_result
    return agent


def _approve_result() -> ElicitationResult:
    return ElicitationResult(selected_index=0, selected_label="Approve", free_text=None)


def _regenerate_result() -> ElicitationResult:
    return ElicitationResult(selected_index=1, selected_label="Regenerate", free_text=None)


def _feedback_result(text: str) -> ElicitationResult:
    return ElicitationResult(selected_index=-1, selected_label=None, free_text=text)


class TestConventionalCommitArgs:
    """Pydantic schema validation for ConventionalCommitArgs."""

    @pytest.mark.parametrize(
        "repo_path, expected_error",
        [
            (None, nullcontext()),
            ("/tmp/repo", nullcontext()),
            ("relative/path", nullcontext()),
        ],
    )
    def test_validation(self, repo_path: str | None, expected_error: Any) -> None:
        """ConventionalCommitArgs accepts optional repo_path."""
        with expected_error:
            args = ConventionalCommitArgs(repo_path=repo_path)
            assert args.repo_path == repo_path

    def test_repo_path_defaults_to_none(self) -> None:
        """repo_path must default to None when not provided."""
        args = ConventionalCommitArgs()
        assert args.repo_path is None


class TestConventionalCommitToolMetadata:
    """Metadata properties of ConventionalCommitTool."""

    @pytest.fixture()
    def tool(self) -> ConventionalCommitTool:
        return ConventionalCommitTool(MagicMock())

    def test_tool_id(self, tool: ConventionalCommitTool) -> None:
        """tool_id must be 'commit'."""
        assert tool.tool_id == "commit"

    def test_name(self, tool: ConventionalCommitTool) -> None:
        """name must be non-empty."""
        assert tool.name

    def test_description(self, tool: ConventionalCommitTool) -> None:
        """description must be non-empty."""
        assert tool.description

    def test_args_schema(self, tool: ConventionalCommitTool) -> None:
        """args_schema must return ConventionalCommitArgs class."""
        assert tool.args_schema is ConventionalCommitArgs


class TestConventionalCommitToolExecute:
    """execute() behaviour of ConventionalCommitTool."""

    def _make_tool(self, output: str = "feat: add feature") -> ConventionalCommitTool:
        tool = ConventionalCommitTool(MagicMock())
        tool._agent = _make_agent(output)
        return tool

    def test_no_staged_changes_returns_error(self) -> None:
        """execute() returns an error dict when git diff --cached is empty."""
        tool = self._make_tool()
        with patch(
            "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
            return_value="",
        ):
            result = tool.execute(ConventionalCommitArgs())

        assert result["status"] == "error"
        assert "staged" in result["message"].lower()

    def test_git_diff_failure_returns_error(self) -> None:
        """execute() returns an error dict when git diff raises GitCommandError."""
        tool = self._make_tool()
        exc = git.GitCommandError("git diff", 128)
        exc.stderr = "not a git repo"
        with patch(
            "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
            side_effect=exc,
        ):
            result = tool.execute(ConventionalCommitArgs())

        assert result["status"] == "error"
        assert "git diff" in result["message"].lower()

    def test_approve_flow_commits_and_returns(self) -> None:
        """execute() runs git commit and returns 'committed' on Approve."""
        commit_msg = "feat(cli): add conventional_commit tool"
        tool = self._make_tool(commit_msg)
        with (
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
                return_value="diff --git a/foo.py ...",
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.elicit_choice",
                return_value=_approve_result(),
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.commit",
                return_value=(0, "1 file changed", ""),
            ),
        ):
            result = tool.execute(ConventionalCommitArgs())

        assert result["status"] == "committed"
        assert result["commit_message"] == commit_msg

    def test_git_commit_failure_returns_error(self) -> None:
        """execute() returns an error dict when git commit exits non-zero."""
        tool = self._make_tool()
        with (
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
                return_value="diff --git a/foo.py ...",
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.elicit_choice",
                return_value=_approve_result(),
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.commit",
                return_value=(1, "", "nothing to commit"),
            ),
        ):
            result = tool.execute(ConventionalCommitArgs())

        assert result["status"] == "error"
        assert result["returncode"] == 1

    def test_elicitation_cancelled_returns_cancelled(self) -> None:
        """execute() returns 'cancelled' when ElicitationCancelledError is raised."""
        tool = self._make_tool()
        with (
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
                return_value="diff --git a/foo.py ...",
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.elicit_choice",
                side_effect=ElicitationCancelledError("cancelled"),
            ),
        ):
            result = tool.execute(ConventionalCommitArgs())

        assert result["status"] == "cancelled"

    def test_regenerate_calls_agent_again(self) -> None:
        """execute() calls agent a second time when Regenerate is selected."""
        tool = self._make_tool()
        elicit_results = [_regenerate_result(), _approve_result()]
        with (
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
                return_value="diff --git a/foo.py ...",
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.elicit_choice",
                side_effect=elicit_results,
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.commit",
                return_value=(0, "ok", ""),
            ),
        ):
            result = tool.execute(ConventionalCommitArgs())

        assert result["status"] == "committed"
        assert tool._agent.run_sync.call_count == 2

    def test_feedback_passes_text_as_next_prompt(self) -> None:
        """execute() uses free_text as the next user_prompt when feedback is given."""
        tool = self._make_tool()
        elicit_results = [_feedback_result("make it shorter"), _approve_result()]
        with (
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
                return_value="diff --git a/foo.py ...",
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.elicit_choice",
                side_effect=elicit_results,
            ),
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.commit",
                return_value=(0, "ok", ""),
            ),
        ):
            tool.execute(ConventionalCommitArgs())

        second_call_prompt = tool._agent.run_sync.call_args_list[1][0][0]
        assert second_call_prompt == "make it shorter"

    def test_repo_path_arg_is_used(self, tmp_path: Path) -> None:
        """execute() passes repo_path to git helpers when provided."""
        tool = self._make_tool()
        with (
            patch(
                "aifred_tk.plugins.conventional_commits.plugin.get_staged_diff",
                return_value="",
            ) as mock_diff,
        ):
            tool.execute(ConventionalCommitArgs(repo_path=str(tmp_path)))

        mock_diff.assert_called_once_with(tmp_path)


class TestConventionalCommitsPlugin:
    """Plugin metadata and tool enumeration for ConventionalCommitsPlugin."""

    @pytest.fixture()
    def plugin(self) -> ConventionalCommitsPlugin:
        return ConventionalCommitsPlugin(MagicMock())

    def test_plugin_id(self, plugin: ConventionalCommitsPlugin) -> None:
        """plugin_id must be 'conventional_commits'."""
        assert plugin.plugin_id == "conventional_commits"

    def test_name(self, plugin: ConventionalCommitsPlugin) -> None:
        """name must be non-empty."""
        assert plugin.name

    def test_get_tools_returns_one_tool(self, plugin: ConventionalCommitsPlugin) -> None:
        """get_tools must return exactly one tool."""
        assert len(plugin.get_tools()) == 1

    def test_get_tools_tool_id(self, plugin: ConventionalCommitsPlugin) -> None:
        """The single tool must have tool_id 'commit'."""
        assert plugin.get_tools()[0].tool_id == "commit"


class TestCreatePlugin:
    """Factory function create_plugin."""

    def test_returns_plugin_instance(self) -> None:
        """create_plugin returns a ConventionalCommitsPlugin without eager validation."""
        plugin = create_plugin(MagicMock())
        assert isinstance(plugin, ConventionalCommitsPlugin)

    def test_raises_when_llm_not_configured_on_agent_build(self) -> None:
        """ConfigurationError is raised on first _get_agent() call when llm is absent."""
        settings = MagicMock()
        settings.get.side_effect = lambda key, *args: {} if key == "LLMS" else None
        plugin = create_plugin(settings)
        tool = plugin.get_tools()[0]
        with pytest.raises(ConfigurationError):
            tool._get_agent()  # type: ignore[union-attr]
