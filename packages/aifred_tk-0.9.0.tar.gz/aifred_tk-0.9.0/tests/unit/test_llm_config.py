"""Unit tests for core LLM configuration models, resolver, and factory."""

from unittest.mock import patch

import pytest
from pydantic import ValidationError
from pydantic_ai.models import Model

from aifred_tk.core.llm import (
    AnthropicLlmConfig,
    GoogleLlmConfig,
    LlmInlineSetting,
    LlmRefSetting,
    OllamaLlmConfig,
    OpenAICompatLlmConfig,
    OpenAILlmConfig,
    PluginLlmSetting,
    build_agent_from_settings,
    build_model_settings,
    build_pydantic_ai_model,
    resolve_llm,
    resolve_tool_llm,
)
from aifred_tk.core.llm._config import LlmConfig
from aifred_tk.core.models import ConfigurationError


class TestOllamaLlmConfig:
    def test_defaults(self) -> None:
        cfg = OllamaLlmConfig(model="gemma4:e4b")
        assert cfg.provider == "ollama"
        assert cfg.host == "127.0.0.1"
        assert cfg.port == 11434
        assert cfg.context_size is None
        assert cfg.response_size is None

    def test_all_fields(self) -> None:
        cfg = OllamaLlmConfig(
            model="llama3.2", host="10.0.0.1", port=9999, context_size=8192, response_size=4096
        )
        assert cfg.host == "10.0.0.1"
        assert cfg.port == 9999
        assert cfg.context_size == 8192
        assert cfg.response_size == 4096

    def test_requires_model(self) -> None:
        with pytest.raises(ValidationError):
            OllamaLlmConfig()  # type: ignore[call-arg]


class TestOpenAILlmConfig:
    def test_defaults(self) -> None:
        cfg = OpenAILlmConfig(model="gpt-4o-mini")
        assert cfg.provider == "openai"
        assert cfg.api_key is None
        assert cfg.base_url is None

    def test_with_api_key(self) -> None:
        cfg = OpenAILlmConfig(model="gpt-4o", api_key="sk-test")
        assert cfg.api_key == "sk-test"

    def test_requires_model(self) -> None:
        with pytest.raises(ValidationError):
            OpenAILlmConfig()  # type: ignore[call-arg]


class TestAnthropicLlmConfig:
    def test_defaults(self) -> None:
        cfg = AnthropicLlmConfig(model="claude-sonnet-4-6")
        assert cfg.provider == "anthropic"
        assert cfg.api_key is None

    def test_requires_model(self) -> None:
        with pytest.raises(ValidationError):
            AnthropicLlmConfig()  # type: ignore[call-arg]


class TestGoogleLlmConfig:
    def test_defaults(self) -> None:
        cfg = GoogleLlmConfig(model="gemini-2.0-flash")
        assert cfg.provider == "google"
        assert cfg.api_key is None
        assert cfg.context_size is None
        assert cfg.response_size is None

    def test_with_api_key(self) -> None:
        cfg = GoogleLlmConfig(model="gemini-2.0-flash", api_key="AIza-test")
        assert cfg.api_key == "AIza-test"

    def test_requires_model(self) -> None:
        with pytest.raises(ValidationError):
            GoogleLlmConfig()  # type: ignore[call-arg]


class TestOpenAICompatLlmConfig:
    def test_requires_base_url(self) -> None:
        with pytest.raises(ValidationError):
            OpenAICompatLlmConfig(model="phi-3")  # type: ignore[call-arg]

    def test_valid(self) -> None:
        cfg = OpenAICompatLlmConfig(model="phi-3", base_url="http://localhost:8080/v1")
        assert cfg.provider == "openai-compatible"
        assert cfg.base_url == "http://localhost:8080/v1"


class TestPluginLlmSettingParsing:
    def test_ref_setting(self) -> None:
        data = {"type": "ref", "ref": "my-model"}
        setting = _parse_plugin_setting(data)
        assert isinstance(setting, LlmRefSetting)
        assert setting.ref == "my-model"

    def test_inline_ollama_setting(self) -> None:
        data = {"type": "custom", "provider": "ollama", "model": "gemma4:e4b", "port": 11434}
        setting = _parse_plugin_setting(data)
        assert isinstance(setting, LlmInlineSetting)
        assert setting.provider == "ollama"
        assert setting.model == "gemma4:e4b"

    def test_inline_openai_setting(self) -> None:
        data = {"type": "custom", "provider": "openai", "model": "gpt-4o"}
        setting = _parse_plugin_setting(data)
        assert isinstance(setting, LlmInlineSetting)
        assert setting.provider == "openai"

    def test_invalid_type_raises(self) -> None:
        from pydantic import TypeAdapter, ValidationError

        with pytest.raises(ValidationError):
            TypeAdapter(PluginLlmSetting).validate_python({"type": "unknown"})


class TestResolveLlm:
    def _make_registry(self) -> dict[str, LlmConfig]:
        return {"my-model": OpenAILlmConfig(model="gpt-4o-mini")}

    def test_resolves_ref(self) -> None:
        setting = LlmRefSetting(ref="my-model")
        resolved = resolve_llm(setting, self._make_registry())
        assert isinstance(resolved, OpenAILlmConfig)
        assert resolved.model == "gpt-4o-mini"

    def test_raises_on_missing_ref(self) -> None:
        setting = LlmRefSetting(ref="does-not-exist")
        with pytest.raises(ConfigurationError, match="does-not-exist"):
            resolve_llm(setting, self._make_registry())

    def test_resolves_inline_ollama(self) -> None:
        setting = LlmInlineSetting(type="custom", provider="ollama", model="llama3.2")
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, OllamaLlmConfig)
        assert resolved.model == "llama3.2"

    def test_resolves_inline_openai(self) -> None:
        setting = LlmInlineSetting(type="custom", provider="openai", model="gpt-4o")
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, OpenAILlmConfig)

    def test_resolves_inline_anthropic(self) -> None:
        setting = LlmInlineSetting(
            type="custom", provider="anthropic", model="claude-haiku-4-5-20251001"
        )
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, AnthropicLlmConfig)

    def test_resolves_inline_openai_compat(self) -> None:
        setting = LlmInlineSetting(
            type="custom", provider="openai-compatible", model="phi-3", base_url="http://host/v1"
        )
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, OpenAICompatLlmConfig)
        assert resolved.base_url == "http://host/v1"

    def test_resolves_inline_google(self) -> None:
        setting = LlmInlineSetting(type="custom", provider="google", model="gemini-2.0-flash")
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, GoogleLlmConfig)
        assert resolved.model == "gemini-2.0-flash"

    def test_empty_registry_ref_raises(self) -> None:
        setting = LlmRefSetting(ref="any")
        with pytest.raises(ConfigurationError):
            resolve_llm(setting, {})


class TestBuildPydanticAiModel:
    def test_ollama_returns_model(self) -> None:
        config = OllamaLlmConfig(model="gemma4:e4b", host="127.0.0.1", port=11434)
        model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_openai_returns_model(self) -> None:
        import os

        config = OpenAILlmConfig(model="gpt-4o-mini")
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
            model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_anthropic_returns_model(self) -> None:
        import os

        config = AnthropicLlmConfig(model="claude-haiku-4-5-20251001")
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-test"}):
            model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_openai_compat_returns_model(self) -> None:
        config = OpenAICompatLlmConfig(model="phi-3", base_url="http://localhost:8080/v1")
        model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_ollama_uses_correct_base_url(self) -> None:
        from pydantic_ai.models.openai import OpenAIChatModel

        config = OllamaLlmConfig(model="gemma4:e4b", host="10.0.0.5", port=9999)
        model = build_pydantic_ai_model(config)
        assert isinstance(model, OpenAIChatModel)

    def test_google_returns_model(self) -> None:
        import os

        config = GoogleLlmConfig(model="gemini-2.0-flash")
        with patch.dict(os.environ, {"GOOGLE_API_KEY": "AIza-test"}):
            model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)


class TestBuildModelSettings:
    def test_response_size_maps_to_max_tokens(self) -> None:
        config = OpenAILlmConfig(model="gpt-4o-mini", response_size=512)
        result = build_model_settings(config)
        assert result is not None
        assert result["max_tokens"] == 512

    def test_no_fields_returns_none(self) -> None:
        config = OpenAILlmConfig(model="gpt-4o-mini")
        assert build_model_settings(config) is None

    def test_context_size_ollama_warns(self) -> None:

        config = OllamaLlmConfig(model="gemma4:e4b", context_size=4096)
        with patch("aifred_tk.core.llm._factory.logger") as mock_logger:
            build_model_settings(config)
        mock_logger.warning.assert_called_once()
        assert "num_ctx" in mock_logger.warning.call_args[0][0]

    def test_context_size_openai_logs_debug(self) -> None:
        config = OpenAILlmConfig(model="gpt-4o-mini", context_size=128000)
        with patch("aifred_tk.core.llm._factory.logger") as mock_logger:
            result = build_model_settings(config)
        mock_logger.debug.assert_called_once()
        assert result is None

    def test_response_and_context_size(self) -> None:
        config = OpenAILlmConfig(model="gpt-4o-mini", context_size=16384, response_size=256)
        result = build_model_settings(config)
        assert result is not None
        assert result["max_tokens"] == 256


class TestResolveToolLlm:
    def _make_settings(self, tool_key: str, llm_raw: dict | None = None) -> object:
        from unittest.mock import MagicMock

        settings = MagicMock()
        settings.get.side_effect = lambda key, default=None: {
            "LLMS": {"default": {"provider": "openai", "model": "gpt-4o-mini"}},
            f"TOOLS__{tool_key.upper()}__LLM": llm_raw,
        }.get(key, default)
        return settings

    def test_resolves_ref_tool_key(self) -> None:
        settings = self._make_settings("commit", {"type": "ref", "ref": "default"})
        config = resolve_tool_llm("commit", settings)  # type: ignore[arg-type]
        assert isinstance(config, OpenAILlmConfig)
        assert config.model == "gpt-4o-mini"

    def test_missing_tool_key_raises(self) -> None:
        settings = self._make_settings("commit", None)
        with pytest.raises(ConfigurationError, match="Missing tools.commit.llm"):
            resolve_tool_llm("commit", settings)  # type: ignore[arg-type]

    def test_inline_tool_llm(self) -> None:
        settings = self._make_settings(
            "commit",
            {"type": "custom", "provider": "anthropic", "model": "claude-haiku-4-5-20251001"},
        )
        config = resolve_tool_llm("commit", settings)  # type: ignore[arg-type]
        assert isinstance(config, AnthropicLlmConfig)


class TestBuildAgentFromSettings:
    def _make_settings(self, tool_key: str) -> object:
        from unittest.mock import MagicMock

        settings = MagicMock()
        settings.get.side_effect = lambda key, default=None: {
            "LLMS": {"default": {"provider": "openai", "model": "gpt-4o-mini"}},
            f"TOOLS__{tool_key.upper()}__LLM": {"type": "ref", "ref": "default"},
        }.get(key, default)
        return settings

    def test_returns_agent(self) -> None:
        import os

        from pydantic_ai import Agent

        settings = self._make_settings("commit")
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
            agent = build_agent_from_settings(
                "commit",
                settings,  # type: ignore[arg-type]
                output_type=str,
                system_prompt="Test prompt",
            )
        assert isinstance(agent, Agent)

    def test_model_settings_applied_when_response_size_set(self) -> None:
        import os
        from unittest.mock import MagicMock

        from pydantic_ai import Agent

        settings = MagicMock()
        settings.get.side_effect = lambda key, default=None: {
            "LLMS": {
                "default": {"provider": "openai", "model": "gpt-4o-mini", "response_size": 128}
            },
            "TOOLS__COMMIT__LLM": {"type": "ref", "ref": "default"},
        }.get(key, default)

        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
            agent = build_agent_from_settings(
                "commit",
                settings,  # type: ignore[arg-type]
                output_type=str,
                system_prompt="Test prompt",
            )
        assert isinstance(agent, Agent)


def _parse_plugin_setting(data: dict) -> PluginLlmSetting:
    from pydantic import TypeAdapter

    return TypeAdapter(PluginLlmSetting).validate_python(data)
