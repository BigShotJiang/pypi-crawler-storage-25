"""Unit tests for the data_query plugin."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from dynaconf import Dynaconf
from pydantic import ValidationError

from aifred_tk.plugins.data_query.plugin import (
    DataQueryPlugin,
    QueryJsonDataFileArgs,
    QueryJsonDataFileTool,
    create_plugin,
)

_SAMPLE = {
    "servers": [
        {"host": "api.example.com", "env": "prod"},
        {"host": "staging.example.com", "env": "staging"},
        {"host": "db.example.com", "env": "prod"},
    ],
    "version": "1.0",
}


@pytest.fixture()
def tool() -> QueryJsonDataFileTool:
    """Return a QueryJsonDataFileTool instance."""
    return QueryJsonDataFileTool()


@pytest.fixture()
def json_file(tmp_path: Path) -> Path:
    """Write sample data as JSON and return the path."""
    p = tmp_path / "data.json"
    p.write_text(json.dumps(_SAMPLE), encoding="utf-8")
    return p


@pytest.fixture()
def yaml_file(tmp_path: Path) -> Path:
    """Write sample data as YAML and return the path."""
    p = tmp_path / "data.yaml"
    p.write_text(yaml.dump(_SAMPLE), encoding="utf-8")
    return p


def test_create_plugin() -> None:
    """Factory returns plugin with correct id and one tool."""
    plugin = create_plugin(Dynaconf())
    assert isinstance(plugin, DataQueryPlugin)
    assert plugin.plugin_id == "data_query"
    tools = plugin.get_tools()
    assert len(tools) == 1
    assert isinstance(tools[0], QueryJsonDataFileTool)


def test_query_json_file(tool: QueryJsonDataFileTool, json_file: Path) -> None:
    """File path to a .json fixture returns scalar result."""
    args = QueryJsonDataFileArgs(
        file_path=str(json_file),
        jsonpath_expression="$.version",
    )
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert result["results"] == ["1.0"]
    assert result["count"] == 1


def test_query_yaml_file(tool: QueryJsonDataFileTool, yaml_file: Path) -> None:
    """File path to a .yaml fixture returns scalar result."""
    args = QueryJsonDataFileArgs(
        file_path=str(yaml_file),
        jsonpath_expression="$.version",
    )
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert result["results"] == ["1.0"]
    assert result["count"] == 1


def test_query_inline_json_content(tool: QueryJsonDataFileTool) -> None:
    """Raw JSON content string with explicit format returns correct result."""
    args = QueryJsonDataFileArgs(
        content=json.dumps(_SAMPLE),
        format="json",
        jsonpath_expression="$.version",
    )
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert result["results"] == ["1.0"]


def test_query_inline_yaml_content(tool: QueryJsonDataFileTool) -> None:
    """Raw YAML content string with explicit format returns correct result."""
    args = QueryJsonDataFileArgs(
        content=yaml.dump(_SAMPLE),
        format="yaml",
        jsonpath_expression="$.version",
    )
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert result["results"] == ["1.0"]


@pytest.mark.parametrize(
    ("expression", "expected_count"),
    [
        ("$.servers[*].host", 3),
        ("$.servers[*].env", 3),
    ],
)
def test_query_multiple_matches(
    tool: QueryJsonDataFileTool,
    json_file: Path,
    expression: str,
    expected_count: int,
) -> None:
    """Wildcard expression returns all matched values."""
    args = QueryJsonDataFileArgs(file_path=str(json_file), jsonpath_expression=expression)
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert result["count"] == expected_count
    assert len(result["results"]) == expected_count


def test_query_filter_expression(tool: QueryJsonDataFileTool, json_file: Path) -> None:
    """Filter expression returns only matching subset."""
    args = QueryJsonDataFileArgs(
        file_path=str(json_file),
        jsonpath_expression="$.servers[?(@.env=='prod')].host",
    )
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert set(result["results"]) == {"api.example.com", "db.example.com"}
    assert result["count"] == 2


def test_query_no_matches(tool: QueryJsonDataFileTool, json_file: Path) -> None:
    """Valid expression that matches nothing returns empty results."""
    args = QueryJsonDataFileArgs(
        file_path=str(json_file),
        jsonpath_expression="$.nonexistent",
    )
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert result["results"] == []
    assert result["count"] == 0


def test_invalid_jsonpath(tool: QueryJsonDataFileTool, json_file: Path) -> None:
    """Malformed expression returns status=error."""
    args = QueryJsonDataFileArgs(
        file_path=str(json_file),
        jsonpath_expression="[[[invalid",
    )
    result = tool.execute(args)
    assert result["status"] == "error"
    assert "JSONPath" in result["message"]


def test_file_not_found(tool: QueryJsonDataFileTool) -> None:
    """Non-existent file path returns status=error."""
    args = QueryJsonDataFileArgs(
        file_path="/no/such/file.json",
        jsonpath_expression="$.x",
    )
    result = tool.execute(args)
    assert result["status"] == "error"
    assert "not found" in result["message"].lower()


def test_aiignore_respected(tool: QueryJsonDataFileTool, tmp_path: Path) -> None:
    """.aiignore blocks file access and returns status=error."""
    (tmp_path / ".aiignore").write_text("secret.json\n", encoding="utf-8")
    secret = tmp_path / "secret.json"
    secret.write_text(json.dumps({"key": "value"}), encoding="utf-8")

    args = QueryJsonDataFileArgs(file_path=str(secret), jsonpath_expression="$.key")
    result = tool.execute(args)
    assert result["status"] == "error"
    assert "aiignore" in result["message"].lower()


def test_missing_format_for_content() -> None:
    """ValidationError raised when content is given without format."""
    with pytest.raises(ValidationError):
        QueryJsonDataFileArgs(content='{"x": 1}', jsonpath_expression="$.x")


def test_both_inputs_rejected() -> None:
    """ValidationError raised when both file_path and content are provided."""
    with pytest.raises(ValidationError):
        QueryJsonDataFileArgs(
            file_path="/some/file.json",
            content='{"x": 1}',
            format="json",
            jsonpath_expression="$.x",
        )


def test_neither_input_rejected() -> None:
    """ValidationError raised when neither file_path nor content is provided."""
    with pytest.raises(ValidationError):
        QueryJsonDataFileArgs(jsonpath_expression="$.x")


def test_format_auto_detected_from_extension(tool: QueryJsonDataFileTool, json_file: Path) -> None:
    """Format is inferred from .json extension without explicit 'format'."""
    args = QueryJsonDataFileArgs(file_path=str(json_file), jsonpath_expression="$.version")
    assert args.format == "json"
    result = tool.execute(args)
    assert result["status"] == "ok"
    assert result["results"] == ["1.0"]


def test_format_auto_detected_yml_extension(tool: QueryJsonDataFileTool, tmp_path: Path) -> None:
    """Format is inferred from .yml extension without explicit 'format'."""
    p = tmp_path / "data.yml"
    p.write_text(yaml.dump(_SAMPLE), encoding="utf-8")
    args = QueryJsonDataFileArgs(file_path=str(p), jsonpath_expression="$.version")
    assert args.format == "yaml"
    result = tool.execute(args)
    assert result["status"] == "ok"


def test_unknown_extension_without_format() -> None:
    """ValidationError raised when extension cannot be auto-detected."""
    with pytest.raises(ValidationError, match="auto-detect"):
        QueryJsonDataFileArgs(file_path="/some/data.csv", jsonpath_expression="$.x")
