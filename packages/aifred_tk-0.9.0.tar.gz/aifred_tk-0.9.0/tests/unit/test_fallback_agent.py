"""Unit tests for FallbackAgent, AgentRunner protocol, and FallbackLlmConfig."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import TypeAdapter
from pydantic_ai.exceptions import ModelAPIError, ModelHTTPError, UnexpectedModelBehavior

from aifred_tk.core.llm import (
    AnthropicLlmConfig,
    FallbackAgent,
    FallbackLlmConfig,
    LlmConfig,
    OllamaLlmConfig,
    OpenAILlmConfig,
    build_agent_from_settings,
    build_model_settings,
    build_pydantic_ai_model,
)
from aifred_tk.core.models import ConfigurationError


def _make_result(value: Any) -> MagicMock:
    result = MagicMock()
    result.output = value
    return result


def _make_agent(return_value: Any = "ok", raises: Exception | None = None) -> MagicMock:
    agent = MagicMock()
    if raises is not None:
        agent.run_sync.side_effect = raises
        agent.run = AsyncMock(side_effect=raises)
    else:
        agent.run_sync.return_value = _make_result(return_value)
        agent.run = AsyncMock(return_value=_make_result(return_value))
    return agent


class TestFallbackAgentRunSync:
    def test_returns_primary_result_on_success(self) -> None:
        primary = _make_agent("primary-ok")
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        result = agent.run_sync("prompt")

        assert result.output == "primary-ok"
        fallback.run_sync.assert_not_called()

    def test_delegates_to_fallback_on_model_http_error(self) -> None:
        exc = ModelHTTPError(503, "test-model")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        result = agent.run_sync("prompt")

        assert result.output == "fallback-ok"
        fallback.run_sync.assert_called_once()

    def test_delegates_to_fallback_on_model_api_error(self) -> None:
        exc = ModelAPIError("test-model", "connection refused")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        result = agent.run_sync("prompt")

        assert result.output == "fallback-ok"

    def test_forwards_message_history_to_both(self) -> None:
        history = [MagicMock()]
        exc = ModelAPIError("test-model", "timeout")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        agent.run_sync("prompt", message_history=history)

        fallback.run_sync.assert_called_once_with("prompt", message_history=history)

    def test_non_transport_error_propagates_immediately(self) -> None:
        exc = UnexpectedModelBehavior("malformed response")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        with pytest.raises(UnexpectedModelBehavior):
            agent.run_sync("prompt")

        fallback.run_sync.assert_not_called()

    def test_config_error_propagates_immediately(self) -> None:
        exc = ConfigurationError("bad config")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        with pytest.raises(ConfigurationError):
            agent.run_sync("prompt")

        fallback.run_sync.assert_not_called()

    def test_fallback_exception_propagates(self) -> None:
        primary_exc = ModelAPIError("m1", "unavailable")
        fallback_exc = ModelAPIError("m2", "also unavailable")
        primary = _make_agent(raises=primary_exc)
        fallback = _make_agent(raises=fallback_exc)
        agent = FallbackAgent(primary, fallback)

        with pytest.raises(ModelAPIError):
            agent.run_sync("prompt")

    def test_warning_logged_on_primary_failure(self) -> None:
        exc = ModelHTTPError(503, "test-model")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("ok")
        agent = FallbackAgent(primary, fallback)

        with patch("aifred_tk.core.llm._fallback.logger") as mock_logger:
            agent.run_sync("prompt")

        mock_logger.warning.assert_called_once()


class TestFallbackAgentRun:
    async def test_returns_primary_result_on_success(self) -> None:
        primary = _make_agent("primary-ok")
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        result = await agent.run("prompt")

        assert result.output == "primary-ok"
        fallback.run.assert_not_called()

    async def test_delegates_to_fallback_on_transport_error(self) -> None:
        exc = ModelHTTPError(429, "test-model")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        result = await agent.run("prompt")

        assert result.output == "fallback-ok"
        fallback.run.assert_called_once()

    async def test_non_transport_error_propagates(self) -> None:
        exc = UnexpectedModelBehavior("bad output")
        primary = _make_agent(raises=exc)
        fallback = _make_agent("fallback-ok")
        agent = FallbackAgent(primary, fallback)

        with pytest.raises(UnexpectedModelBehavior):
            await agent.run("prompt")

        fallback.run.assert_not_called()


class TestFallbackChaining:
    def test_three_level_chain(self) -> None:
        exc = ModelAPIError("m", "unavailable")
        agent_a = _make_agent(raises=exc)
        agent_b = _make_agent(raises=exc)
        agent_c = _make_agent("chain-ok")

        chain = FallbackAgent(agent_a, FallbackAgent(agent_b, agent_c))
        result = chain.run_sync("prompt")

        assert result.output == "chain-ok"
        agent_c.run_sync.assert_called_once()


class TestFallbackLlmConfigParsing:
    def _parse(self, data: dict) -> LlmConfig:
        return TypeAdapter(LlmConfig).validate_python(data)

    def test_parses_flat_fallback_config(self) -> None:
        data = {
            "provider": "fallback",
            "primary": {"provider": "ollama", "model": "gemma3:4b"},
            "fallback": {"provider": "openai", "model": "gpt-4o-mini"},
        }
        config = self._parse(data)
        assert isinstance(config, FallbackLlmConfig)
        assert isinstance(config.primary, OllamaLlmConfig)
        assert isinstance(config.fallback, OpenAILlmConfig)

    def test_parses_nested_fallback_config(self) -> None:
        data = {
            "provider": "fallback",
            "primary": {"provider": "ollama", "model": "gemma3:4b"},
            "fallback": {
                "provider": "fallback",
                "primary": {"provider": "openai", "model": "gpt-4o-mini"},
                "fallback": {"provider": "anthropic", "model": "claude-haiku-4-5-20251001"},
            },
        }
        config = self._parse(data)
        assert isinstance(config, FallbackLlmConfig)
        assert isinstance(config.fallback, FallbackLlmConfig)
        assert isinstance(config.fallback.fallback, AnthropicLlmConfig)

    def test_provider_discriminator(self) -> None:
        data = {
            "provider": "fallback",
            "primary": {"provider": "ollama", "model": "m"},
            "fallback": {"provider": "ollama", "model": "m"},
        }
        config = self._parse(data)
        assert config.provider == "fallback"


class TestBuildPydanticAiModelFallbackGuard:
    def test_raises_configuration_error_for_fallback_config(self) -> None:
        config = FallbackLlmConfig(
            primary=OllamaLlmConfig(model="a"),
            fallback=OllamaLlmConfig(model="b"),
        )
        with pytest.raises(ConfigurationError, match="build_agent_from_settings"):
            build_pydantic_ai_model(config)


class TestBuildModelSettingsFallbackGuard:
    def test_returns_none_for_fallback_config(self) -> None:
        config = FallbackLlmConfig(
            primary=OllamaLlmConfig(model="a"),
            fallback=OllamaLlmConfig(model="b"),
        )
        assert build_model_settings(config) is None


class TestBuildAgentFromSettingsFallback:
    def _make_settings(self, tool_key: str, llm_raw: dict) -> object:
        from unittest.mock import MagicMock

        settings = MagicMock()
        settings.get.side_effect = lambda key, default=None: {
            "LLMS": {
                "ollama_primary": {"provider": "ollama", "model": "gemma3:4b"},
                "openai_backup": {"provider": "openai", "model": "gpt-4o-mini"},
                "my_chain": {
                    "provider": "fallback",
                    "primary": {"provider": "ollama", "model": "gemma3:4b"},
                    "fallback": {"provider": "openai", "model": "gpt-4o-mini"},
                },
            },
            f"TOOLS__{tool_key.upper()}__LLM": llm_raw,
        }.get(key, default)
        return settings

    def test_returns_fallback_agent_for_fallback_config(self) -> None:
        import os

        settings = self._make_settings("commit", {"type": "ref", "ref": "my_chain"})
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
            agent = build_agent_from_settings(
                "commit",
                settings,  # type: ignore[arg-type]
                output_type=str,
                system_prompt="Test",
            )
        assert isinstance(agent, FallbackAgent)

    def test_returns_plain_agent_for_simple_config(self) -> None:
        import os

        from pydantic_ai import Agent

        settings = self._make_settings("commit", {"type": "ref", "ref": "openai_backup"})
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
            agent = build_agent_from_settings(
                "commit",
                settings,  # type: ignore[arg-type]
                output_type=str,
                system_prompt="Test",
            )
        assert isinstance(agent, Agent)
