"""Unit tests for aifred_tk.core.paths."""

from pathlib import Path

import pytest

import aifred_tk.core.ignore as ignore_module
from aifred_tk.core.paths import FileAccessError, filter_accessible_paths, sanitize_file_path


class TestSanitizeFilePath:
    """Tests for sanitize_file_path."""

    def setup_method(self) -> None:
        ignore_module._cache.clear()

    def test_returns_resolved_path_for_valid_file(self, tmp_path: Path) -> None:
        """Returns a resolved Path when the file is accessible."""
        f = tmp_path / "data.txt"
        f.write_text("ok\n", encoding="utf-8")
        result = sanitize_file_path(str(f))
        assert result == f.resolve()
        assert result.is_file()

    def test_raises_for_nonexistent_file(self, tmp_path: Path) -> None:
        """Raises FileAccessError when the file does not exist."""
        missing = tmp_path / "ghost.txt"
        with pytest.raises(FileAccessError, match="File not found"):
            sanitize_file_path(str(missing))

    def test_raises_for_directory(self, tmp_path: Path) -> None:
        """Raises FileAccessError when the path points to a directory."""
        with pytest.raises(FileAccessError, match="not a regular file"):
            sanitize_file_path(str(tmp_path))

    def test_raises_for_aiignore_file(self, tmp_path: Path) -> None:
        """Raises FileAccessError when the file is ignored by .aiignore."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("shh\n", encoding="utf-8")
        with pytest.raises(FileAccessError, match=r"\.aiignore"):
            sanitize_file_path(str(target))

    def test_resolves_traversal_sequences(self, tmp_path: Path) -> None:
        """Path traversal sequences are resolved to the canonical path."""
        sub = tmp_path / "sub"
        sub.mkdir()
        f = tmp_path / "data.txt"
        f.write_text("hi\n", encoding="utf-8")
        traversal = str(sub / ".." / "data.txt")
        result = sanitize_file_path(traversal)
        assert result == f.resolve()

    def test_resolves_symlinks(self, tmp_path: Path) -> None:
        """Symlinks are resolved; the canonical target path is returned."""
        real = tmp_path / "real.txt"
        real.write_text("real\n", encoding="utf-8")
        link = tmp_path / "link.txt"
        link.symlink_to(real)
        result = sanitize_file_path(str(link))
        assert result == real.resolve()

    def test_accepts_path_object(self, tmp_path: Path) -> None:
        """Accepts a Path object as well as a string."""
        f = tmp_path / "data.txt"
        f.write_text("x\n", encoding="utf-8")
        result = sanitize_file_path(f)
        assert result == f.resolve()


class TestFilterAccessiblePaths:
    """Tests for filter_accessible_paths."""

    def setup_method(self) -> None:
        ignore_module._cache.clear()

    def test_returns_accessible_paths(self, tmp_path: Path) -> None:
        """Returns resolved paths for all valid, non-ignored files."""
        a = tmp_path / "a.txt"
        b = tmp_path / "b.txt"
        a.write_text("a\n", encoding="utf-8")
        b.write_text("b\n", encoding="utf-8")
        result = filter_accessible_paths([str(a), str(b)])
        assert set(result) == {a.resolve(), b.resolve()}

    def test_silently_drops_nonexistent(self, tmp_path: Path) -> None:
        """Non-existent paths are silently dropped."""
        existing = tmp_path / "real.txt"
        existing.write_text("x\n", encoding="utf-8")
        result = filter_accessible_paths([str(existing), str(tmp_path / "ghost.txt")])
        assert result == [existing.resolve()]

    def test_silently_drops_directories(self, tmp_path: Path) -> None:
        """Directories are silently dropped."""
        f = tmp_path / "file.txt"
        f.write_text("x\n", encoding="utf-8")
        result = filter_accessible_paths([str(tmp_path), str(f)])
        assert result == [f.resolve()]

    def test_silently_drops_aiignored_files(self, tmp_path: Path) -> None:
        """Files ignored by .aiignore are silently dropped."""
        (tmp_path / ".aiignore").write_text("*.key\n", encoding="utf-8")
        safe = tmp_path / "safe.txt"
        secret = tmp_path / "id.key"
        safe.write_text("ok\n", encoding="utf-8")
        secret.write_text("shh\n", encoding="utf-8")
        result = filter_accessible_paths([str(safe), str(secret)])
        assert result == [safe.resolve()]

    def test_returns_empty_list_when_all_filtered(self, tmp_path: Path) -> None:
        """Returns an empty list when all paths are filtered out."""
        (tmp_path / ".aiignore").write_text("*.txt\n", encoding="utf-8")
        f = tmp_path / "all.txt"
        f.write_text("x\n", encoding="utf-8")
        result = filter_accessible_paths([str(f)])
        assert result == []

    def test_accepts_path_objects(self, tmp_path: Path) -> None:
        """Accepts Path objects in the iterable."""
        f = tmp_path / "data.txt"
        f.write_text("x\n", encoding="utf-8")
        result = filter_accessible_paths([f])
        assert result == [f.resolve()]
