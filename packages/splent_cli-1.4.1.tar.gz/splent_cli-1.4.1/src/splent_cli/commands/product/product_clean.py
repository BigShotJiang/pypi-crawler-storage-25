import os
import subprocess
import click
import tomllib
from splent_cli.services import compose, context
from splent_cli.utils.feature_utils import read_features_from_data


def _docker_down(name: str, base_path: str, env: str):
    compose_file = compose.resolve_file(base_path, env)
    if compose_file is None:
        return
    project_name = compose.project_name(name, env)
    subprocess.run(
        ["docker", "compose", "-p", project_name, "-f", compose_file, "down", "-v"],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    click.echo(f"  🛑  {name} stopped and volumes removed.")


@click.command(
    "product:clean",
    short_help="Full reset: stop containers, wipe volumes, reset DB, clear files.",
)
@click.option("--dev", "env_dev", is_flag=True, help="Use development environment.")
@click.option("--prod", "env_prod", is_flag=True, help="Use production environment.")
@click.option("--yes", is_flag=True, help="Skip confirmation prompt.")
def product_clean(env_dev, env_prod, yes):
    """
    Nuclear reset of the active product's environment:

    \b
    1. Docker Compose down --volumes (product + all features)
    2. Database reset with migration regeneration
    3. Clear uploads directory
    4. Clear application log

    Use when you want a completely clean slate.
    """
    if env_dev and env_prod:
        click.secho("❌ Cannot specify both --dev and --prod.", fg="red")
        raise SystemExit(1)

    env = context.resolve_env(env_dev, env_prod)
    workspace = str(context.workspace())
    product = context.require_app()

    click.secho(f"\n⚠️  This will completely wipe {product} ({env}):", fg="yellow")
    click.echo("  - Stop all Docker containers and remove volumes")
    click.echo("  - Reset the database and regenerate migrations")
    click.echo("  - Clear uploads and application log")
    click.echo()

    if not yes and not click.confirm("Continue?"):
        click.echo("❎ Cancelled.")
        raise SystemExit(0)

    product_path = os.path.join(workspace, product)

    # ── 1. Docker down --volumes ─────────────────────────────────────
    click.secho("\n🐳 Stopping containers and removing volumes...", fg="cyan")

    pyproject_path = os.path.join(product_path, "pyproject.toml")
    features = []
    if os.path.exists(pyproject_path):
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
        features = read_features_from_data(data, env)

    _docker_down(product, product_path, env)
    for feat in features:
        clean = compose.normalize_feature_ref(feat)
        feat_docker = compose.feature_docker_dir(workspace, clean)
        _docker_down(clean, os.path.dirname(feat_docker), env)

    # ── 2. DB reset ──────────────────────────────────────────────────
    click.secho("\n🗄️  Resetting database...", fg="cyan")
    result = subprocess.run(
        ["splent", "db:reset", "--clear-migrations", "--yes"],
        check=False,
    )
    if result.returncode != 0:
        click.secho(
            "  ⚠️  db:reset exited with errors — check output above.", fg="yellow"
        )
    else:
        click.secho("  ✔ Database reset.", fg="green")

    # ── 3. Clear uploads ─────────────────────────────────────────────
    click.secho("\n🗂️  Clearing uploads...", fg="cyan")
    result = subprocess.run(["splent", "clear:uploads"], check=False)
    if result.returncode == 0:
        click.secho("  ✔ Uploads cleared.", fg="green")
    else:
        click.secho("  ⚠️  clear:uploads exited with errors — uploads may not be cleared.", fg="yellow")

    # ── 4. Clear log ─────────────────────────────────────────────────
    click.secho("\n📋 Clearing application log...", fg="cyan")
    result = subprocess.run(["splent", "clear:log"], check=False)
    if result.returncode == 0:
        click.secho("  ✔ Log cleared.", fg="green")
    else:
        click.secho("  ⚠️  clear:log exited with errors — log may not be cleared.", fg="yellow")

    click.echo()
    click.secho(
        f"✅ {product} ({env}) fully cleaned. Run 'splent product:up' to start fresh.",
        fg="green",
    )


cli_command = product_clean
