# Changelog

All notable changes to this package will be documented in this file.

## [0.1.2] - 2026-04-21

### Fixed

- `fmql_semantic.__version__` now reports the installed package version instead of a hand-maintained literal that had drifted (0.1.1 shipped still reporting `0.1.0`). Since this version string is baked into index metadata via `backend.py` and `storage/writer.py`, stale values previously ended up on disk. `__version__` is now derived from `importlib.metadata.version("fmql-semantic")`.

## [0.1.1] - 2026-04-21

### Changed

- `--option env=PATH` now publishes every key from the dotenv file to `os.environ` (via `setdefault`) so LiteLLM provider credentials (`OPENAI_API_KEY`, `AZURE_API_*`, …) are picked up. `FMQL_*` keys still drive the typed config; existing shell env vars are never overridden.

### Fixed

- Suppress a benign `RuntimeWarning: coroutine '…' was never awaited` emitted at interpreter shutdown by LiteLLM's `LoggingWorker`. A narrow `warnings.filterwarnings` entry (matched by message, category, and originating module) silences the noise without masking unrelated warnings.

## [0.1.0] - 2026-04-17

### Added

- Hybrid-retrieval `semantic` backend registered via the `fmql.search_index` entry point.
- Dense embeddings through LiteLLM (`litellm.aembedding`) stored in `sqlite-vec` virtual tables with DDL-pinned dimensions.
- Sparse BM25 retrieval via SQLite FTS5 (`unicode61 remove_diacritics 2` tokenizer).
- Reciprocal Rank Fusion (k=60) combining dense + sparse rankings.
- Optional cross-encoder reranking via `litellm.arerank` with soft-fail fallback to RRF.
- Query modes: hybrid (default), `dense_only`, `sparse_only`, `no_rerank`.
- Incremental indexing keyed on content hash; deletions reconciled on rebuild.
- Model pinning in index metadata; mismatches refuse to build without `--force`.
- Format-version gate (`FORMAT_VERSION = 1`) raises `IndexVersionError` on incompatible indexes.
- Config resolution: `--option KEY=VALUE` > dotenv (`--option env=path`) > `FMQL_*` env > defaults.
- Optional `progress` extra adds `tqdm` progress bars.
