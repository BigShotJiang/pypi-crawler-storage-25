import pytest
from fastapi.testclient import TestClient

from spotfire_community.automation_services import (
    AutomationServicesClient,
    JobDefinition,
)
from spotfire_community.automation_services.models import ExecutionStatus


def test_start_job_definition_and_wait_times_out(test_client: TestClient):
    client = AutomationServicesClient(
        spotfire_url="http://testserver",
        client_id="dummy",
        client_secret="dummy",
    )
    job_definition = JobDefinition()

    with pytest.raises(TimeoutError):
        client.start_job_definition_and_wait(
            job_definition=job_definition, poll_interval=0.1, timeout=0.5
        )


def test_start_job_definition_and_wait_finishes(test_client: TestClient):
    client = AutomationServicesClient(
        spotfire_url="http://testserver",
        client_id="dummy",
        client_secret="dummy",
    )
    job_definition = JobDefinition()

    status = client.start_job_definition_and_wait(
        job_definition=job_definition, poll_interval=0.1, timeout=2
    )
    assert status.status_code == ExecutionStatus.FINISHED
