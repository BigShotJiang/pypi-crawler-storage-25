"""
Logwick — audit logging for AI agents
Official Python SDK
"""

import threading
import time
import json
from typing import Optional, List, Dict, Any, Callable
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

__version__ = "1.0.0"
__all__ = ["LogwickClient", "log", "fire", "init"]

DEFAULT_URL = "https://logwick.io/api/v1/logs"

_default_client = None


def init(api_key: str, **kwargs):
    """Initialize the default Logwick client."""
    global _default_client
    _default_client = LogwickClient(api_key=api_key, **kwargs)
    return _default_client


def log(entry: dict):
    """Log using the default client. Call init() first."""
    if not _default_client:
        raise RuntimeError("Call logwick.init(api_key='...') before using logwick.log()")
    return _default_client.log(entry)


def fire(entry: dict):
    """Fire and forget using the default client. Call init() first."""
    if not _default_client:
        raise RuntimeError("Call logwick.init(api_key='...') before using logwick.fire()")
    _default_client.fire(entry)


class LogwickClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_URL,
        tags: Optional[List[str]] = None,
        silent: bool = True,
    ):
        if not api_key:
            raise ValueError("Logwick: api_key is required. Get yours at logwick.io")
        self.api_key = api_key
        self.base_url = base_url
        self.default_tags = tags or []
        self.silent = silent

    def log(self, entry: dict) -> Optional[dict]:
        """Send a log entry synchronously. Returns the response or None on error."""
        if not entry.get("agent"):
            raise ValueError("Logwick: agent is required")
        if not entry.get("action"):
            raise ValueError("Logwick: action is required")

        payload = {
            "agent":      entry.get("agent"),
            "action":     entry.get("action"),
            "status":     entry.get("status", "success"),
            "input":      entry.get("input"),
            "output":     entry.get("output"),
            "user":       entry.get("user"),
            "tokens":     entry.get("tokens"),
            "latency_ms": entry.get("latency_ms"),
            "cost_usd":   entry.get("cost_usd"),
            "tags":       self.default_tags + entry.get("tags", []),
            "metadata":   entry.get("metadata", {}),
        }

        payload = {k: v for k, v in payload.items() if v is not None}

        try:
            data = json.dumps(payload).encode("utf-8")
            req = Request(
                self.base_url,
                data=data,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    "User-Agent": f"logwick-python/{__version__}",
                },
                method="POST",
            )
            with urlopen(req, timeout=8) as res:
                return json.loads(res.read().decode("utf-8"))
        except HTTPError as e:
            if not self.silent:
                print(f"[Logwick] HTTP error {e.code}: {e.reason}")
            return None
        except (URLError, Exception) as e:
            if not self.silent:
                print(f"[Logwick] Error: {e}")
            return None

    def fire(self, entry: dict):
        """Fire and forget — sends log in background thread, never blocks."""
        thread = threading.Thread(target=self._fire_safe, args=(entry,), daemon=True)
        thread.start()

    def _fire_safe(self, entry: dict):
        try:
            self.log(entry)
        except Exception:
            pass

    def openai(self, call: Callable, entry: dict):
        """
        Wrap an OpenAI chat completion call and log it automatically.

        Usage:
            result = logwick.openai(
                lambda: client.chat.completions.create(model="gpt-4o", messages=messages),
                {"action": "email_draft", "user": user_email}
            )
        """
        start = time.time()
        try:
            result = call()
            self.fire({
                **entry,
                "agent": entry.get("agent", "gpt-4o"),
                "status": "success",
                "output": result.choices[0].message.content if result.choices else None,
                "tokens": result.usage.total_tokens if result.usage else None,
                "latency_ms": int((time.time() - start) * 1000),
            })
            return result
        except Exception as e:
            self.fire({
                **entry,
                "agent": entry.get("agent", "gpt-4o"),
                "status": "error",
                "output": str(e),
                "latency_ms": int((time.time() - start) * 1000),
            })
            raise

    def anthropic(self, call: Callable, entry: dict):
        """
        Wrap an Anthropic messages call and log it automatically.

        Usage:
            result = logwick.anthropic(
                lambda: client.messages.create(model="claude-3-5-sonnet-20241022", messages=messages, max_tokens=1024),
                {"action": "document_review", "user": user_email}
            )
        """
        start = time.time()
        try:
            result = call()
            tokens = None
            if hasattr(result, "usage"):
                tokens = (result.usage.input_tokens or 0) + (result.usage.output_tokens or 0)
            self.fire({
                **entry,
                "agent": entry.get("agent", "claude-3-5-sonnet"),
                "status": "success",
                "output": result.content[0].text if result.content else None,
                "tokens": tokens,
                "latency_ms": int((time.time() - start) * 1000),
            })
            return result
        except Exception as e:
            self.fire({
                **entry,
                "agent": entry.get("agent", "claude-3-5-sonnet"),
                "status": "error",
                "output": str(e),
                "latency_ms": int((time.time() - start) * 1000),
            })
            raise

    def gemini(self, call: Callable, entry: dict):
        """
        Wrap a Google Gemini generate call and log it automatically.

        Usage:
            result = logwick.gemini(
                lambda: model.generate_content(prompt),
                {"action": "data_analysis", "user": user_email}
            )
        """
        start = time.time()
        try:
            result = call()
            tokens = None
            if hasattr(result, "usage_metadata"):
                tokens = getattr(result.usage_metadata, "total_token_count", None)
            self.fire({
                **entry,
                "agent": entry.get("agent", "gemini-1.5-pro"),
                "status": "success",
                "output": result.text if hasattr(result, "text") else None,
                "tokens": tokens,
                "latency_ms": int((time.time() - start) * 1000),
            })
            return result
        except Exception as e:
            self.fire({
                **entry,
                "agent": entry.get("agent", "gemini-1.5-pro"),
                "status": "error",
                "output": str(e),
                "latency_ms": int((time.time() - start) * 1000),
            })
            raise

    def langchain_handler(self, **default_entry):
        """
        Returns a LangChain callback handler that logs every LLM call automatically.

        Usage:
            handler = logwick.langchain_handler(user="ops@acme.com")
            chain = LLMChain(llm=llm, prompt=prompt, callbacks=[handler])
        """
        return LogwickLangChainHandler(self, default_entry)


class LogwickLangChainHandler:
    """LangChain callback handler for automatic logging."""

    def __init__(self, client: LogwickClient, default_entry: dict = {}):
        self.client = client
        self.default_entry = default_entry
        self._starts = {}

    def on_llm_start(self, serialized, prompts, run_id=None, **kwargs):
        self._starts[str(run_id)] = {
            "time": time.time(),
            "input": prompts[0] if prompts else "",
        }

    def on_llm_end(self, response, run_id=None, **kwargs):
        start = self._starts.pop(str(run_id), None)
        if not start:
            return
        text = ""
        tokens = None
        try:
            text = response.generations[0][0].text
            tokens = getattr(response.llm_output, "token_usage", {}).get("total_tokens")
        except Exception:
            pass
        self.client.fire({
            "agent": "langchain",
            "action": "llm_call",
            "status": "success",
            "input": start["input"],
            "output": text,
            "tokens": tokens,
            "latency_ms": int((time.time() - start["time"]) * 1000),
            **self.default_entry,
        })

    def on_llm_error(self, error, run_id=None, **kwargs):
        start = self._starts.pop(str(run_id), None)
        if not start:
            return
        self.client.fire({
            "agent": "langchain",
            "action": "llm_call",
            "status": "error",
            "input": start["input"],
            "output": str(error),
            "latency_ms": int((time.time() - start["time"]) * 1000),
            **self.default_entry,
        })

    def on_chain_start(self, *args, **kwargs): pass
    def on_chain_end(self, *args, **kwargs): pass
    def on_chain_error(self, *args, **kwargs): pass
    def on_tool_start(self, *args, **kwargs): pass
    def on_tool_end(self, *args, **kwargs): pass
    def on_tool_error(self, *args, **kwargs): pass
