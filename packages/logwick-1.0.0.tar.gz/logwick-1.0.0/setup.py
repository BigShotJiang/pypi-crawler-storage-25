from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="logwick",
    version="1.0.0",
    author="Logwick",
    author_email="hello@logwick.io",
    description="Audit logging for AI agents — official Python SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://logwick.io",
    project_urls={
        "Documentation": "https://logwick.io/docs",
        "Source": "https://github.com/logwickio/logwick-python",
        "Bug Tracker": "https://github.com/logwickio/logwick-python/issues",
    },
    py_modules=["logwick"],
    python_requires=">=3.7",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Logging",
        "Intended Audience :: Developers",
    ],
    keywords="logwick ai logging audit llm agents observability openai anthropic gemini langchain",
)
