# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
GStreamer transport settings.

Configuration used by the GStreamer WebRTC client (e.g. supported video/audio codecs
for SDP negotiation, RTP header extensions, encoder/decoder selection, and
:data:`HW_CODECS_ENABLED`). Hardware codecs default off unless
:data:`ENV_GST_HW_CODECS_ENABLED` is set to a truthy value (``1``, ``true``, ``yes``, ``on``).
"""

import os
from typing import List, Tuple

from reactor_runtime.transports.gstreamer.sdp.codec import CodecEntry

# If unset, hardware codecs are off. Set to 1/true/yes/on to enable NVENC/NVDEC/etc.
ENV_GST_HW_CODECS_ENABLED = "GST_HW_CODECS_ENABLED"


def _hw_codecs_enabled_from_env() -> bool:
    raw = os.getenv(ENV_GST_HW_CODECS_ENABLED)
    if raw is None:
        return False
    return raw.strip().lower() in ("1", "true", "yes", "on")


# When False, video encoder/decoder bins use software elements only (e.g. x264/x265,
# libav decoders), not GPU-backed plugins (NVENC, NVDEC, VA-API, etc.).
HW_CODECS_ENABLED: bool = _hw_codecs_enabled_from_env()

# Ordered list of supported video codecs for SDP offer/answer and encoder selection.
# The first entry that appears in the remote SDP offer is chosen.
# Each entry: {"codec": str, "parameters"?: dict}
SUPPORTED_VIDEO_CODECS: List[CodecEntry] = [
    {
        "codec": "H264",
        "parameters": {
            "profile-level-id": "42e01f",
            "packetization-mode": "1",
        },
    },
    {"codec": "VP9", "parameters": {"profile-id": "0"}},
    {"codec": "VP8"},
    {"codec": "AV1", "parameters": {"profile": "0"}},
]

# Ordered list of supported audio codecs for SDP filtering.
# Each entry: {"codec": str, "parameters"?: dict}
SUPPORTED_AUDIO_CODECS: List[CodecEntry] = [
    {"codec": "Opus"},
]

# RTP header extension URIs we mirror in answers and on outgoing video RTP caps when
# the peer offer includes them (order preserved). Add entries to negotiate more.
RTP_HEADER_EXTENSION_URI_TRANSPORT_WIDE_CC = (
    "http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01"
)

SUPPORTED_RTP_HEADER_EXTENSION_URIS: Tuple[str, ...] = (
    RTP_HEADER_EXTENSION_URI_TRANSPORT_WIDE_CC,
)
