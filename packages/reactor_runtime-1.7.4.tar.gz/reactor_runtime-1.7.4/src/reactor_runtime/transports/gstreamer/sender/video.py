# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Video sender: appsrc ! videoconvert ! queue ! encoder ! capsfilter(RTP hdr ext) ! bwe.
"""

from typing import List, Optional

import numpy as np

from reactor_runtime.transports.gstreamer.encoders import EncoderFactory
from reactor_runtime.transports.gstreamer.sdp.codec import CodecEntry
from reactor_runtime.transports.gstreamer.sdp.extmap import SdpExtmap
from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import (
    add_many,
    link_many,
    link_pads,
    make_element,
)
from reactor_runtime.utils.log import get_logger

from .base import _SenderStreamBase

logger = get_logger(__name__)

# BWE bitrate defaults (kbps) when using rtpgccbwe
_DEFAULT_MIN_BITRATE_Kbps = 500
_DEFAULT_MAX_BITRATE_Kbps = 10000
_DEFAULT_BITRATE_Kbps = 4000

# WebRTC stream/track identification (matches SDP a=msid and stream-id)
_DEFAULT_STREAM_ID = "default"


def _gst_caps_for_rtp_header_extensions(extmaps: List[SdpExtmap]) -> Gst.Caps:
    """
    Build ``application/x-rtp`` caps with ``extmap-<id>=(string)"<uri>"`` fields
    so downstream (e.g. rtpgccbwe) matches negotiated SDP ``a=extmap`` lines.
    """
    if not extmaps:
        raise ValueError("extmaps must be non-empty")
    seen_ids: set[int] = set()
    fields = ["application/x-rtp"]
    for em in extmaps:
        if em.id in seen_ids:
            raise ValueError(f"duplicate RTP header extension id: {em.id}")
        seen_ids.add(em.id)
        if em.id <= 0:
            raise ValueError(f"extmap id must be > 0, got {em.id}")
        uri = em.uri.strip()
        if not uri:
            raise ValueError("extmap uri must be non-empty")
        # Gst caps string: escape backslashes and double-quotes in the URI token.
        safe_uri = uri.replace("\\", "\\\\").replace('"', '\\"')
        fields.append(f'extmap-{em.id}=(string)"{safe_uri}"')
    return Gst.Caps.from_string(", ".join(fields))


class VideoSender(_SenderStreamBase):
    """
    A Gst.Bin for video sender:

        appsrc ! videoconvert ! queue ! encoder ! capsfilter(RTP header ext) ! bwe

    After the RTP payloader we add a capsfilter that sets stream-id and msid in the
    application/x-rtp caps so webrtcbin (and the browser) can associate this sender
    with the correct track when multiple sendonly streams are used.

    ``rtp_header_extensions`` is a list of negotiated ``SdpExtmap`` entries for this mid (omit or ``[]`` for none).
    """

    def __init__(
        self,
        codec_entry: CodecEntry,
        name: str = "video_sender",
        min_bitrate_kbps: int = _DEFAULT_MIN_BITRATE_Kbps,
        max_bitrate_kbps: int = _DEFAULT_MAX_BITRATE_Kbps,
        ssrc: Optional[int] = None,
        rtp_header_extensions: Optional[List[SdpExtmap]] = None,
    ):
        super().__init__(name=name)

        encoding_name = codec_entry.get("codec")
        pt = codec_entry.get("payload_type")
        if not encoding_name or pt is None:
            raise ValueError("codec_entry must contain 'codec' and 'payload_type'")
        format_params = codec_entry.get("parameters") or {}

        self._appsrc = make_element("appsrc", "appsrc")
        self._appsrc.set_property("format", Gst.Format.TIME)
        self._appsrc.set_property("is-live", True)
        self._appsrc.set_property("do-timestamp", True)
        self._appsrc.set_property("block", True)

        videoconvert = make_element("videoconvert", "videoconvert")
        queue_el = make_element("queue", "queue")
        queue_el.set_property("max-size-buffers", 1)
        queue_el.set_property("leaky", "downstream")

        self._encoder = EncoderFactory.create(
            encoding_name, pt, format_params, ssrc=ssrc
        )
        self._current_bitrate_kbps = _DEFAULT_BITRATE_Kbps
        self._min_bitrate_kbps = min_bitrate_kbps
        self._max_bitrate_kbps = max_bitrate_kbps

        # Negotiated RTP header extensions (e.g. TWCC for rtpgccbwe); ids must match SDP per mid.
        exts = list(rtp_header_extensions) if rtp_header_extensions is not None else []
        self._rtp_hdr_ext_capsfilter = make_element(
            "capsfilter", "rtp_hdr_ext_capsfilter"
        )
        if exts:
            self._rtp_hdr_ext_capsfilter.set_property(
                "caps", _gst_caps_for_rtp_header_extensions(exts)
            )

        if Gst.ElementFactory.find("rtpgccbwe") is not None:
            bwe = make_element("rtpgccbwe", "bwe")
            bwe.set_property("min-bitrate", min_bitrate_kbps * 1000)
            bwe.set_property("max-bitrate", max_bitrate_kbps * 1000)
            bwe.connect(
                "notify::estimated-bitrate",
                self._on_bitrate_estimate,
            )
        else:
            bwe = make_element("identity", "identity")
            bwe.set_property("signal-handoffs", False)

        add_many(
            self,
            self._appsrc,
            videoconvert,
            queue_el,
            self._encoder,
            self._rtp_hdr_ext_capsfilter,
            bwe,
            sync_with_parent=True,
        )
        link_many(self._appsrc, videoconvert, queue_el)
        link_pads(queue_el.get_static_pad("src"), self._encoder.pad_sink())
        link_pads(
            self._encoder.pad_src(), self._rtp_hdr_ext_capsfilter.get_static_pad("sink")
        )
        link_pads(
            self._rtp_hdr_ext_capsfilter.get_static_pad("src"),
            bwe.get_static_pad("sink"),
        )

        bwe_src = bwe.get_static_pad("src")
        if not bwe_src:
            raise RuntimeError("bwe element has no src pad")
        ghost_src = Gst.GhostPad.new("src", bwe_src)
        if not ghost_src or not self.add_pad(ghost_src):
            raise RuntimeError("Failed to add ghost src pad to VideoSender")
        self._ghost_src: Gst.GhostPad = ghost_src

        # Per-sender caps and PTS (must be used only on GLib thread)
        self._outgoing_width = 0
        self._outgoing_height = 0

    def push_buffer(self, frame: np.ndarray) -> bool:
        """
        Extract dimensions and bytes from the frame (e.g. numpy array with .shape and .tobytes()),
        set appsrc caps if needed, create a Gst.Buffer, set PTS/duration, and push to the appsrc.
        Must be called from the thread that runs the GStreamer main loop.

        Returns:
            True if the buffer was pushed successfully (Gst.FlowReturn.OK), False otherwise
            or if frame has no .shape/.tobytes().
        """
        try:
            height, width = frame.shape[:2]
            data = frame.tobytes()
        except Exception:
            return False

        if width != self._outgoing_width or height != self._outgoing_height:
            caps = Gst.Caps.from_string(
                f"video/x-raw,format=RGB,width={width},height={height},framerate=30/1"
            )
            self._appsrc.set_property("caps", caps)
            self._outgoing_width = width
            self._outgoing_height = height

        buf = Gst.Buffer.new_wrapped(data)
        ret = self._appsrc.emit("push-buffer", buf)
        return ret == Gst.FlowReturn.OK

    def _on_bitrate_estimate(self, element: Gst.Element, pspec: object) -> None:
        """Handle bitrate estimate from rtpgccbwe (Google Congestion Control)."""
        estimated = element.get_property("estimated-bitrate")
        new_bitrate_kbps = estimated // 1000  # Convert to kbps

        logger.debug(
            f"GCC bitrate estimate: {estimated} bps -> {new_bitrate_kbps} kbps"
        )

        # Only update if change is significant (>5%)
        if abs(new_bitrate_kbps - self._current_bitrate_kbps) > (
            self._current_bitrate_kbps * 0.05
        ):
            old_bitrate = self._current_bitrate_kbps
            new_bitrate_kbps = max(
                self._min_bitrate_kbps,
                min(self._max_bitrate_kbps, new_bitrate_kbps),
            )
            self._current_bitrate_kbps = new_bitrate_kbps

            self._encoder.set_target_bitrate(new_bitrate_kbps * 1000)
            direction = "↑" if new_bitrate_kbps > old_bitrate else "↓"
            logger.debug(
                f"GCC bitrate {direction} {old_bitrate} → {new_bitrate_kbps} kbps"
            )
