"""
Profiling module for Reactor Runtime.

Provides profiling capabilities to measure code section durations with nested interval support.
Exports to OTLP histograms in production or writes to files locally for later visualization.

Supports three CUDA timing modes for GPU operations:
- CudaTimingMode.NONE: CPU timing only (default)
- CudaTimingMode.EVENT: CUDA events for single-stream GPU work
- CudaTimingMode.SYNC: Full synchronization for multi-stream GPU work

Instrumenting a New Model
=========================

All metrics export as ``reactor_profiler_section_ms`` histograms with
``model_name`` and ``machine_id`` labels added automatically. In k8s with
Alloy enabled, they reach Grafana with zero config.

Minimal instrumentation (chunk timing + FPS + TTFF)::

    from reactor_runtime import get_ctx
    from reactor_runtime.profiling import CudaTimingMode

    profiler = get_ctx().profiler()
    ttff = profiler.timer("ttff")
    _ttff_done = False

    while not get_ctx().should_stop():
        # ... wait for prompt, setup ...

        if not _ttff_done:
            ttff.start()

        with profiler.section("chunk", cuda_timing=CudaTimingMode.EVENT):
            with profiler.section("dit", cuda_timing=CudaTimingMode.EVENT):
                # ... transformer / diffusion forward pass ...

            with profiler.section("vae_decode", cuda_timing=CudaTimingMode.EVENT):
                # ... VAE decode ...

            frames = video_tensor.cpu().numpy()      # shape [N, H, W, C]
            get_ctx().get_track().emit(frames)

            if not _ttff_done:
                ttff.stop()
                _ttff_done = True

Two APIs for two use cases:

- **section()** — scoped measurements (``with`` block). Supports nesting
  and CUDA timing. Use for ``chunk``, ``dit``, ``vae_decode``, etc.
- **timer()** — cross-scope measurements (``.start()`` / ``.stop()``).
  Stack-independent, CPU timing only. Use for ``ttff`` and other lifecycle
  metrics where start and end don't align with a single block.

Key rules:

- **Section names**: Use ``chunk`` (outer), ``dit`` or ``denoise`` (transformer),
  ``vae_decode``, ``vae_encode``, ``vfi`` or ``frame_interpolation``.
- **TTFF**: Use ``profiler.timer("ttff")`` with ``.start()`` / ``.stop()``.
  Use a ``_ttff_done`` flag to fire once per session (models have reset loops).
- **Timing mode**: Use ``CudaTimingMode.EVENT`` for all GPU sections.
  Note: EVENT measurements flush only at session end, not during streaming.
- **NoOp safety**: When profiling is disabled, ``get_ctx().profiler()`` returns
  a ``NoOpProfiler`` — all calls (sections and timers) are zero-cost no-ops.
"""

from reactor_runtime.profiling.profiler import (
    BucketPreset,
    CudaTimingMode,
    Profiler,
    ProfilerSection,
    ProfilerTimer,
    NoOpProfiler,
)
from reactor_runtime.profiling.backends.base import ProfilerBackend
from reactor_runtime.profiling.helpers import profile_fn

__all__ = [
    "BucketPreset",
    "CudaTimingMode",
    "Profiler",
    "ProfilerSection",
    "ProfilerTimer",
    "NoOpProfiler",
    "ProfilerBackend",
    "profile_fn",
]
