"""
HTTP Runtime for Reactor

An HTTP-based runtime that exposes REST endpoints for session management
and WebRTC for real-time video/audio/data streaming.

Used by the JS SDK's ``LocalCoordinatorClient`` for local development.

Session endpoints:
    POST   /start_session                               - Start session (returns capabilities)
    POST   /stop_session                                - Stop session

Transport endpoints:
    GET    /sessions/{id}/transport/webrtc/ice_servers   - ICE server config
    POST   /sessions/{id}/transport/webrtc/sdp_params    - Send SDP offer (async, 202)
    GET    /sessions/{id}/transport/webrtc/sdp_params    - Poll for SDP answer
    PUT    /sessions/{id}/transport/webrtc/sdp_params    - Reconnect (new SDP offer)

Other:
    GET    /health                                       - Health check
"""

import asyncio
from typing import Optional
import numpy as np
from fastapi import FastAPI, HTTPException
from importlib.metadata import version as _pkg_version, PackageNotFoundError

from omegaconf import DictConfig
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from reactor_runtime.model_state import ModelEvent, ModelState
import uvicorn

from reactor_runtime.runtime_api import Runtime
from reactor_runtime.transports.media import (
    MediaBundle,
    TrackMapping,
)
from reactor_runtime.utils.log import get_logger, session_id_var
from reactor_runtime.utils.messages import ApplicationMessage, RuntimeMessage
from reactor_runtime.transports import (
    WebRTCTransport,
    WebRTCSupersededError,
    EventType,
    MessageEvent,
    DisconnectedEvent,
    VideoFrameEvent,
    PingTimeoutEvent,
)
from reactor_runtime.transports.config import (
    resolve_default_transport,
    validate_transport_available,
)
from reactor_runtime.transports.types import (
    IceTransportPolicy,
    TransportConfig,
    WebRTCSignalingState,
)
from reactor_runtime.runtimes.http.config import HttpRuntimeConfig
from reactor_runtime.runtimes.http.types import (
    SdpOfferRequest,
)

logger = get_logger(__name__)

try:
    _runtime_version = _pkg_version("reactor_runtime")
except PackageNotFoundError:
    _runtime_version = "0.0.0"

# The single session ID used by the HTTP runtime (local dev).
# Not a UUID -- makes logs obvious and avoids unnecessary state.
SESSION_ID = "local"


# =============================================================================
# Helpers to validate session_id in path
# =============================================================================


def _validate_session_id(session_id: str) -> None:
    """Raise 404 if the session_id doesn't match the local session."""
    if session_id != SESSION_ID:
        raise HTTPException(status_code=404, detail="Session not found")


# =============================================================================
# HttpRuntime
# =============================================================================


class HttpRuntime(Runtime):
    """
    An HTTP runtime that exposes REST endpoints for session control
    and uses WebRTC for real-time media streaming.

    Implements the decoupled session/transport protocol:
    - Session endpoints (``/sessions/*``) handle lifecycle
    - Transport endpoints (``.../transport/webrtc/*``) handle signaling
    """

    config: HttpRuntimeConfig

    def __init__(self, config: HttpRuntimeConfig):
        """
        Initialize the HTTP runtime.

        Args:
            config: HttpRuntimeConfig containing model and runtime-specific settings.
        """
        # WebRTC transport - single connection at a time
        # Protected by _client_lock for thread-safe access
        self._webrtc_client: Optional[WebRTCTransport] = None
        self._client_lock = asyncio.Lock()

        # FastAPI app
        self.app = FastAPI(title="Reactor HTTP Runtime")

        # Configure CORS to allow any origin
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        self._setup_routes()

        # Call parent constructor (loads model)
        super().__init__(config)

    # ===============================
    # Route Setup
    # ===============================

    def _setup_routes(self) -> None:
        """Setup FastAPI routes for the local runtime protocol."""

        # -----------------------------------------------------------
        # Session endpoints
        # -----------------------------------------------------------

        @self.app.post("/start_session")
        async def start_session():
            """Start a session and return full capabilities immediately.

            Returns capabilities and transport info in a single response.
            """
            if self.current_state != ModelState.READY:
                raise HTTPException(
                    status_code=400,
                    detail=f"Cannot start session in state {self.current_state.value}",
                )

            self.session_id = SESSION_ID
            session_id_var.set(SESSION_ID)

            capabilities = self.model.capabilities() if self.model else {}

            success = self.send(ModelEvent.START_SESSION)
            if not success:
                raise HTTPException(
                    status_code=400,
                    detail="Failed to start session",
                )

            return {
                "session_id": SESSION_ID,
                "cluster": "local",
                "server_info": {"server_version": _runtime_version},
                "selected_transport": {"protocol": "webrtc", "version": "1.0"},
                "model": {"name": self.config.model_name},
                "capabilities": capabilities,
                "state": self.current_state.value,
            }

        @self.app.post("/stop_session")
        async def stop_session():
            """Stop the current session."""
            success = self.send(ModelEvent.STOP_SESSION)
            if not success:
                if self.current_state in (
                    ModelState.READY,
                    ModelState.CREATED,
                    ModelState.TERMINATED,
                ):
                    return JSONResponse(status_code=200, content=None)
                raise HTTPException(
                    status_code=409,
                    detail=f"Cannot stop session in state {self.current_state.value}",
                )

            return JSONResponse(status_code=200, content=None)

        # -----------------------------------------------------------
        # Transport endpoints
        # -----------------------------------------------------------

        @self.app.get("/sessions/{session_id}/transport/webrtc/ice_servers")
        async def ice_servers(session_id: str):
            """
            Return ICE server configuration for WebRTC peer connection.

            Returns the configured STUN/TURN servers using the coordinator
            proto format (``uris``, ``credentials``).
            """
            _validate_session_id(session_id)
            return {"ice_servers": self.config.ice_servers_json}

        @self.app.post("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def post_sdp_params(session_id: str, request: SdpOfferRequest):
            """
            Accept an SDP offer and start WebRTC connection setup in the background.

            Returns 202 immediately.  The client polls
            ``GET .../sdp_params`` for the answer.

            If a previous connection exists, it is stopped cooperatively
            and its signaling state is cleared before creating the new one.
            """
            _validate_session_id(session_id)

            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")

            track_mapping = TrackMapping.from_client_mapping(
                [entry.model_dump() for entry in request.track_mapping]
            )

            # Stop existing client if any — clears stale signaling state
            await self._clear_existing_transport()

            # Fire-and-forget background task to create the transport
            asyncio.create_task(
                self._create_transport_background(request.sdp_offer, track_mapping)
            )

            return JSONResponse(status_code=202, content=None)

        @self.app.put("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def put_sdp_params(session_id: str, request: SdpOfferRequest):
            """
            Reconnect with a new SDP offer.

            Same logic as POST — stops existing transport and creates a new one.
            """
            _validate_session_id(session_id)

            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")

            track_mapping = TrackMapping.from_client_mapping(
                [entry.model_dump() for entry in request.track_mapping]
            )

            await self._clear_existing_transport()

            asyncio.create_task(
                self._create_transport_background(request.sdp_offer, track_mapping)
            )

            return JSONResponse(status_code=202, content=None)

        @self.app.get("/sessions/{session_id}/transport/webrtc/sdp_params")
        async def get_sdp_params(session_id: str):
            """
            Poll for the SDP answer.

            Returns:
                200 with ``{ "sdp_answer": "..." }`` if the transport is ready.
                202 if the transport is still being created (state is WAITING/ORPHANED).
                404 if no session is active.
            """
            _validate_session_id(session_id)

            # Snapshot the reference to avoid TOCTOU race with _clear_existing_transport
            client = self._webrtc_client
            if client is not None:
                signaling = client.get_signaling()
                if not isinstance(signaling, WebRTCSignalingState):
                    raise HTTPException(
                        status_code=500,
                        detail=f"Unexpected signaling type: {type(signaling).__name__}",
                    )
                if signaling.sdp_answer is not None:
                    return {
                        "sdp_answer": signaling.sdp_answer.sdp,
                    }

            # Transport not ready — check if we're still working on it
            if self.current_state in (ModelState.WAITING, ModelState.ORPHANED):
                return JSONResponse(status_code=202, content=None)

            # No session / nothing in progress
            raise HTTPException(status_code=404, detail="No pending SDP offer")

        # -----------------------------------------------------------
        # Health check (unchanged)
        # -----------------------------------------------------------

        @self.app.get("/health")
        async def health():
            """Health check endpoint."""
            return {
                "status": "healthy",
                "model": self.config.model_name,
                "state": self.current_state.value,
            }

    # ===============================
    # WebRTC Connection Management
    # ===============================

    async def _clear_existing_transport(self) -> None:
        """Stop and null the current WebRTC client, clearing stale signaling state.

        Fires ``CLIENT_DISCONNECTED`` if a transport was active so the
        state machine transitions correctly (e.g. ``STREAMING`` →
        ``ORPHANED``).

        Called by the POST/PUT ``sdp_params`` endpoints *before*
        spawning ``_create_transport_background``, so the teardown
        happens synchronously in the request handler while the creation
        runs as a fire-and-forget background task.
        """
        async with self._client_lock:
            if self._webrtc_client is not None:
                logger.info("Stopping existing WebRTC client")
                self._webrtc_client.stop()
                self._webrtc_client = None
                self.send(ModelEvent.CLIENT_DISCONNECTED)

    async def _create_transport_background(
        self, sdp_offer: str, track_mapping: TrackMapping
    ) -> None:
        """Background task: create a WebRTC transport and install it.

        **Concurrency model — why a post-creation lock check is needed:**

        Teardown and creation are split across two steps:

        1. *Teardown* (in the request handler): the POST/PUT endpoint
           calls ``_clear_existing_transport`` synchronously before
           spawning this background task.
        2. *Creation* (this method, fire-and-forget):
           ``WebRTCTransport.create()`` is async and yields to the event
           loop (SDP exchange, ICE gathering).  During this window the
           client can send another POST/PUT which tears down again and
           spawns a second background task.  Two tasks now race to
           install their transport.

        When installation re-acquires ``_client_lock``, two guards
        prevent stale transports from being installed:

        - ``_webrtc_client is not None``: the other background task
          already won the race and installed its transport.  Ours is
          stale — stop it and return.
        - ``send(CLIENT_CONNECTED)`` returns ``False``: the session was
          stopped or timed out while we were creating the transport, so
          the state machine rejects the transition.  The transport is
          no longer needed — stop it.

        ``WebRTCSupersededError`` can also be raised from *inside*
        ``WebRTCTransport.create()`` if the transport backend detects
        its stop event was set during setup (e.g. runtime shutdown).
        This is a benign abort — the transport was no longer needed.

        On any failure the error is logged but not re-raised; the orphan
        timeout (managed by ``runtime_api.py``) will eventually clean up
        the session.

        Args:
            sdp_offer: The SDP offer string.
            track_mapping: Track mapping from the client.
        """
        try:
            logger.info("Creating new WebRTC connection (background)")
            transport = await WebRTCTransport.create(
                self.config.transport_type,
                sdp_offer=sdp_offer,
                track_mapping=track_mapping,
                config=TransportConfig(
                    ice_servers=self.config.ice_servers,
                    port_range=self.config.webrtc_port_range,
                    transport_policy=self.config.ice_transport_policy,
                ),
            )

            async with self._client_lock:
                if self._webrtc_client is not None:
                    transport.stop()
                    logger.warning("Connection superseded by concurrent request")
                    return

                success = self.send(ModelEvent.CLIENT_CONNECTED, client=transport)
                if not success:
                    transport.stop()
                    logger.warning(
                        "Session expired while waiting for client connection",
                        state=self.current_state.value,
                    )
                    return

        except WebRTCSupersededError:
            logger.warning("WebRTC connection was superseded during creation")
        except Exception as e:
            logger.exception("Failed to create WebRTC transport (background)", error=e)

    def _setup_webrtc_handlers(self, client: WebRTCTransport) -> None:
        """Setup event handlers for a WebRTC client."""

        def on_message(event: MessageEvent):
            """Handle incoming data channel message."""
            if not self.loop.is_closed():
                asyncio.run_coroutine_threadsafe(
                    self._on_data_channel_message(event.data), self.loop
                )

        def on_disconnect(event: DisconnectedEvent):
            """Handle WebRTC disconnection."""
            if not self.loop.is_closed():
                logger.info("WebRTC disconnected", reason=event.reason)
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        def on_video_frame(event: VideoFrameEvent):
            """Handle incoming video frame."""
            if not self.loop.is_closed():
                asyncio.run_coroutine_threadsafe(
                    self._on_incoming_video_frame(event.frame, event.track_name),
                    self.loop,
                )

        def on_ping_timeout(event: PingTimeoutEvent):
            """Handle client ping timeout – treat as disconnection."""
            if not self.loop.is_closed():
                logger.warning(
                    "Client ping timeout, treating as client disconnection",
                    elapsed=f"{event.elapsed:.1f}s",
                )
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        client.on(EventType.MESSAGE, on_message)
        client.on(EventType.DISCONNECTED, on_disconnect)
        client.on(EventType.VIDEO_FRAME, on_video_frame)
        client.on(EventType.PING_TIMEOUT, on_ping_timeout)

    async def _stop_webrtc_client(self) -> None:
        """Stop and clear the current WebRTC client."""
        async with self._client_lock:
            if self._webrtc_client is not None:
                self._webrtc_client.stop()
                self._webrtc_client = None
                logger.debug("WebRTC client stopped")

    async def _on_data_channel_message(self, message: str) -> None:
        """
        Handle incoming data channel message.
        Delegates to the common handler in the abstract Runtime class.
        """
        await self._handle_incoming_data_channel_message(message)

    def _on_ping_received(self) -> None:
        """Forward client ping to the WebRTC client's watchdog."""
        if self._webrtc_client:
            self._webrtc_client.notify_ping()

    async def _on_incoming_video_frame(
        self, frame: np.ndarray, track_name: str = "video"
    ) -> None:
        """Handle incoming video frame from WebRTC.

        Wraps the raw frame into a :class:`MediaBundle` before dispatching
        to the model's ``on_media`` callback.

        Args:
            frame: NumPy array in RGB format with shape (H, W, 3).
            track_name: The MID-derived track name.
        """
        if self.model:
            bundle = MediaBundle.from_video_frame(frame, track_name=track_name)
            self.model._dispatch_media(bundle)

    # ===============================
    # Runtime API implementation - MODEL -> CLIENT (WebRTC)
    # ===============================

    async def send_out_app_message(self, data: ApplicationMessage) -> None:
        """
        Send an application message via the WebRTC data channel.
        """
        # Don't use lock here - send_message is thread-safe and we don't want to block
        client = self._webrtc_client
        if client is not None:
            if client.send_message(data):
                logger.debug("Sent app message via data channel")
            else:
                logger.debug("Data channel not available, message not sent")
        else:
            logger.debug("No WebRTC client, message not sent")

    async def send_out_runtime_message(self, data: RuntimeMessage) -> None:
        """
        Send a runtime message via the WebRTC data channel.
        """
        client = self._webrtc_client

        if not client:
            logger.warning("No WebRTC client, runtime message not sent")
            return

        if not client.send_message(data):
            logger.warning("Failed to send runtime message via data channel")
            return

    async def send_out_app_bundle(self, media_bundle, duplicate: bool) -> None:
        """Send a multi-track media bundle via the WebRTC transport.

        Silently skips if no WebRTC connection is active.
        """
        client = self._webrtc_client
        if client is not None:
            client.send_media(media_bundle)

    # ===============================
    # Runtime API implementation - Model Lifecycle Handlers
    # ===============================

    def on_before_cleanup_complete(self, **kwargs) -> None:
        """
        Called AFTER internal cleanup when the model thread exits.
        """
        error = kwargs.get("error", None)
        if error:
            logger.warning("Model exited with error", error=error)
        else:
            logger.info("Model session ended")
        self.session_id = None
        session_id_var.set(None)

    def on_before_stop_session(self, **kwargs) -> None:
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    def on_before_client_connected(self, **kwargs) -> None:
        """
        Handler called before the client connected event is sent.
        Installs the client setting up event handlers.
        """
        client = kwargs.get("client")
        assert client is not None, "Client must be provided"
        self._setup_webrtc_handlers(client)
        self._webrtc_client = client
        client.start_ping_watchdog()
        logger.debug("WebRTC connection established")

    def on_before_client_disconnected(self, **kwargs) -> None:
        """
        Cleanup called after the WebRTC client is disconnected. This frees the resource used by the WebRTC client thread.
        """
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    async def run(self) -> None:
        """
        Main entry point to run the HTTP runtime.
        Starts the FastAPI server with uvicorn.
        """

        uvicorn_config = uvicorn.Config(
            app=self.app, host=self.config.host, port=self.config.port, log_level="info"
        )
        server = uvicorn.Server(uvicorn_config)

        try:
            await server.serve()
        except KeyboardInterrupt:
            logger.info("HTTP runtime interrupted")
        finally:
            await self._stop_webrtc_client()
            await self.shutdown()


async def serve(
    model_spec: str, model_name: str, model_config: DictConfig, **kwargs
) -> None:
    """
    Entry point for running the HTTP runtime from a CLI.

    Args:
        model_spec: Python import path to the VideoModel class (module:Class)
        model_name: Name of the model
        model_config: DictConfig of kwargs to pass to the model constructor
        **kwargs: Runtime-specific arguments from HttpRuntimeConfig.parser()
            - host: Host to bind to (default: "0.0.0.0")
            - port: Port to bind to (default: 8080)
            - orphan_timeout: Seconds to wait before stopping orphaned session (default: 30.0)
            - max_session_duration: Maximum session duration in seconds (default: None, disabled)
            - webrtc_port_range: WebRTC ICE UDP port range as tuple (min, max) (default: None)
            - stun_servers: List of STUN server URLs (default: None, uses Google STUN)
            - turn_servers: List of TURN servers in format "username;credential;url" (default: None)
            - transport_type: WebRTC transport backend (default: None -> AIORTC)
    """

    transport_type = kwargs.get("transport_type")
    if transport_type is not None:
        try:
            validate_transport_available(transport_type)
        except ImportError as e:
            raise RuntimeError(
                f"Selected transport '{transport_type.name}' is not available: {e}"
            ) from e
    else:
        transport_type = resolve_default_transport()

    config = HttpRuntimeConfig(
        model_name=model_name,
        model_args=model_config,
        model_spec=model_spec,
        host=kwargs.get("host", "0.0.0.0"),
        port=kwargs.get("port", 8080),
        orphan_timeout=kwargs.get("orphan_timeout", 30.0),
        max_session_duration=kwargs.get("max_session_duration"),
        webrtc_port_range=kwargs.get("webrtc_port_range"),
        stun_servers=kwargs.get("stun_servers"),
        turn_servers=kwargs.get("turn_servers"),
        ice_transport_policy=kwargs.get("ice_transport_policy", IceTransportPolicy.ALL),
        transport_type=transport_type,
        # Profiling configuration
        enable_profiling=kwargs.get("enable_profiling", False),
        profiling_output_dir=kwargs.get("profiling_output_dir", "./profiling"),
    )

    runtime = HttpRuntime(config)
    asyncio.create_task(runtime.load())
    await runtime.run()
