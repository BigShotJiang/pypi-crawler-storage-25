"""Brightness Example — A minimal Reactor model template."""

import time
import numpy as np
from omegaconf import DictConfig
from pydantic import Field

from reactor_runtime import VideoModel, model, command, get_ctx


@model(name="brightness-example", config="config.yml")
class BrightnessExample(VideoModel):
    @command("set_brightness", description="Adjust brightness level")
    def set_brightness(
        self,
        brightness: float = Field(
            ...,
            ge=0.0,
            le=2.0,
            description="Brightness multiplier (0=black, 1=normal, 2=bright)",
        ),
    ):
        self._brightness = brightness

    def __init__(self, config: DictConfig):
        self._fps = config.get("fps", 30)
        self._brightness = 1.0

    def start_session(self):
        frame_num = 0
        try:
            while not get_ctx().should_stop():
                frame = _make_gradient(480, 640, self._brightness, frame_num)
                get_ctx().get_track().emit(frame)
                frame_num += 1
                time.sleep(1.0 / self._fps)
        finally:
            self._brightness = 1.0


def _make_gradient(h: int, w: int, brightness: float, frame_num: int) -> np.ndarray:
    img = np.zeros((h, w, 3), dtype=np.uint8)
    shift = frame_num % h
    img[:, :, 0] = np.roll(np.linspace(0, 255, h, dtype=np.uint8), shift)[:, None]
    return np.clip(img * brightness, 0, 255).astype(np.uint8)
