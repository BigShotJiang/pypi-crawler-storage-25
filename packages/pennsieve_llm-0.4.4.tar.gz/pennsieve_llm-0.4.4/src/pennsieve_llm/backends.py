"""Backend infrastructure for the Pennsieve LLM SDK.

This module is intentionally thin: the SDK delegates to the official
``anthropic`` Python SDK for all LLM interactions. We only own:

  * ``_SigV4Auth`` — httpx auth plugin that signs requests against the
    AWS ``lambda`` service (for Function URL invocations).
  * ``MockClient`` — a stand-in for ``anthropic.Anthropic`` used in tests
    when no governor URL or Anthropic API key is configured.

Everything else (request/response types, streaming, tool use, content
blocks, prompt caching) is exposed by returning the underlying
``anthropic.Anthropic`` client via ``Governor.client()``.
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import httpx


class _SigV4Auth(httpx.Auth):
    """httpx auth plugin that SigV4-signs requests against the AWS ``lambda``
    service (the service signing name for Lambda Function URLs).

    Reads credentials from the default boto3 chain (env vars, IAM role, etc.).

    Subclasses ``httpx.Auth`` because httpx 0.28+ rejects duck-typed auth
    objects in ``httpx.Client(auth=...)`` — it requires an isinstance check.
    """

    requires_request_body = True

    def __init__(self, region: str = "us-east-1"):
        try:
            import boto3
            from botocore.auth import SigV4Auth
            from botocore.awsrequest import AWSRequest
        except ImportError as e:
            raise ImportError(
                "boto3 + botocore are required. Install pennsieve-llm with "
                "its default extras: `pip install pennsieve-llm`."
            ) from e
        self._SigV4Auth = SigV4Auth
        self._AWSRequest = AWSRequest
        self._creds = boto3.session.Session().get_credentials()
        self._region = region
        if self._creds is None:
            raise RuntimeError(
                "No AWS credentials found. SigV4 signing requires env vars, "
                "an IAM role, or a configured AWS profile."
            )

    def auth_flow(self, request):
        # Pass only headers we explicitly want signed — botocore will sign
        # every header in the AWSRequest, and any header that httpx then
        # alters or drops before transport (Connection, Accept-Encoding,
        # User-Agent, etc.) breaks the signature. The minimal set is
        # Content-Type when there's a body; Host is re-derived from the
        # URL by botocore on one side and the server on the other, and
        # the X-Amz-* signing headers are added by add_auth.
        sign_headers: dict[str, str] = {}
        for k, v in request.headers.items():
            if k.lower() == "content-type":
                sign_headers["Content-Type"] = v
                break
        aws_request = self._AWSRequest(
            method=request.method,
            url=str(request.url),
            data=request.content if request.content else b"",
            headers=sign_headers,
        )
        self._SigV4Auth(self._creds, "lambda", self._region).add_auth(aws_request)
        # Copy signed headers onto the httpx request (Authorization,
        # X-Amz-Date, X-Amz-Content-Sha256, X-Amz-Security-Token, plus our
        # Content-Type echo). Don't blow away other httpx-managed headers.
        for k, v in aws_request.headers.items():
            request.headers[k] = v
        yield request


class _MockMessages:
    """Mock implementation of ``anthropic.Anthropic.messages``. Stores every
    call's kwargs in ``.calls`` and returns canned responses.

    Tests can:
        - Inspect ``mock_client.messages.calls`` to assert what was sent.
        - Override the response via ``mock_client.set_response(text=...)``.
    """

    def __init__(self):
        self.calls: list[dict] = []
        self._response_text = "[mock] response"
        self._input_tokens = 10
        self._output_tokens = 5

    def set_response(self, text: str = "[mock] response", input_tokens: int = 10, output_tokens: int = 5):
        self._response_text = text
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens

    def create(self, **kwargs) -> Any:
        self.calls.append(kwargs)
        # Return a response shape that matches anthropic.types.Message enough
        # for typical caller code (resp.content[i].text, resp.usage.input_tokens,
        # resp.model, resp.stop_reason).
        return SimpleNamespace(
            id="msg_mock",
            type="message",
            role="assistant",
            content=[SimpleNamespace(type="text", text=self._response_text)],
            model=kwargs.get("model", "mock"),
            stop_reason="end_turn",
            stop_sequence=None,
            usage=SimpleNamespace(
                input_tokens=self._input_tokens,
                output_tokens=self._output_tokens,
            ),
        )


class MockClient:
    """Drop-in replacement for ``anthropic.Anthropic`` for tests.

    Mimics the parts of the anthropic.Anthropic surface that typical caller
    code uses (``.messages.create(...)``). Implements just enough to make
    unit tests pass without making real network calls.

    Use directly or pass into ``Governor(client=MockClient())`` to override
    the auto-selected backend.
    """

    def __init__(self):
        self.messages = _MockMessages()

    def set_response(self, text: str = "[mock] response", input_tokens: int = 10, output_tokens: int = 5):
        """Set the canned response for subsequent ``messages.create()`` calls."""
        self.messages.set_response(text=text, input_tokens=input_tokens, output_tokens=output_tokens)

    @property
    def calls(self) -> list[dict]:
        """Inspect the kwargs of every ``messages.create()`` call so far."""
        return self.messages.calls
