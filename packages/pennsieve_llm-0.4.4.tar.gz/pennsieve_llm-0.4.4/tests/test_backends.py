"""Tests for the slimmed-down SDK (v0.4.0+).

The SDK pivoted to "thin configuration wrapper" — it returns a configured
``anthropic.Anthropic`` client and a ``MockClient`` stand-in for tests.
There are no more parallel types (InvokeRequest/InvokeResponse/etc.), so
the test surface shrunk accordingly.
"""

import os

import pytest

from pennsieve_llm import (
    Governor,
    GovernorError,
    MockClient,
    MODEL_HAIKU_45,
    MODEL_OPUS_47,
    MODEL_SONNET_45,
    MODEL_SONNET_46,
)


# ---------------------------------------------------------------------------
# MockClient
# ---------------------------------------------------------------------------


class TestMockClient:
    def test_basic_create_returns_mock_response(self):
        client = MockClient()
        resp = client.messages.create(
            model=MODEL_SONNET_46,
            messages=[{"role": "user", "content": "hello"}],
            max_tokens=100,
        )
        # Anthropic-shape response
        assert resp.role == "assistant"
        assert resp.type == "message"
        assert resp.content[0].type == "text"
        assert resp.content[0].text == "[mock] response"
        assert resp.model == MODEL_SONNET_46
        assert resp.stop_reason == "end_turn"
        assert resp.usage.input_tokens == 10
        assert resp.usage.output_tokens == 5

    def test_set_response_overrides_text(self):
        client = MockClient()
        client.set_response(text="42", input_tokens=99, output_tokens=1)
        resp = client.messages.create(model="x", messages=[], max_tokens=10)
        assert resp.content[0].text == "42"
        assert resp.usage.input_tokens == 99
        assert resp.usage.output_tokens == 1

    def test_calls_recorded(self):
        client = MockClient()
        client.messages.create(
            model="m1", messages=[{"role": "user", "content": "a"}], max_tokens=1
        )
        client.messages.create(
            model="m2", messages=[{"role": "user", "content": "b"}], max_tokens=2
        )
        assert len(client.calls) == 2
        assert client.calls[0]["model"] == "m1"
        assert client.calls[1]["model"] == "m2"

    def test_extra_kwargs_passed_through_in_calls(self):
        # Verify the mock captures temperature, system, etc. so tests can
        # assert on them.
        client = MockClient()
        client.messages.create(
            model="m",
            messages=[],
            max_tokens=1,
            temperature=0.5,
            system="be helpful",
        )
        assert client.calls[0]["temperature"] == 0.5
        assert client.calls[0]["system"] == "be helpful"


# ---------------------------------------------------------------------------
# Governor — backend auto-selection
# ---------------------------------------------------------------------------


class TestGovernor:
    def test_no_env_raises(self, monkeypatch):
        # Production must NOT silently fall through to MockClient — that
        # masks misconfiguration as a "successful" run with garbage output.
        monkeypatch.delenv("LLM_GOVERNOR_URL", raising=False)
        monkeypatch.delenv("PENNSIEVE_LLM_MOCK", raising=False)
        with pytest.raises(RuntimeError, match="no governor URL configured"):
            Governor()

    def test_mock_opt_in_via_env(self, monkeypatch):
        monkeypatch.delenv("LLM_GOVERNOR_URL", raising=False)
        monkeypatch.setenv("PENNSIEVE_LLM_MOCK", "1")
        gov = Governor()
        assert isinstance(gov.client(), MockClient)
        assert not gov.available()

    def test_explicit_client_overrides_env(self, monkeypatch):
        monkeypatch.setenv("LLM_GOVERNOR_URL", "https://x.lambda-url.us-east-1.on.aws")
        injected = MockClient()
        gov = Governor(client=injected)
        assert gov.client() is injected

    def test_execution_run_id_from_env(self, monkeypatch):
        monkeypatch.setenv("EXECUTION_RUN_ID", "run-xyz")
        gov = Governor(client=MockClient())
        assert gov.execution_run_id == "run-xyz"

    def test_execution_run_id_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("EXECUTION_RUN_ID", "from-env")
        gov = Governor(client=MockClient(), execution_run_id="explicit")
        assert gov.execution_run_id == "explicit"

    def test_check_budget_in_mock_mode(self, monkeypatch):
        monkeypatch.delenv("LLM_GOVERNOR_URL", raising=False)
        monkeypatch.setenv("PENNSIEVE_LLM_MOCK", "1")
        gov = Governor()
        budget = gov.check_budget()
        assert budget["budgetPeriod"] == "none"
        assert budget["periodRemainingUsd"] == float("inf")

    def test_list_models_in_mock_mode(self, monkeypatch):
        monkeypatch.delenv("LLM_GOVERNOR_URL", raising=False)
        monkeypatch.setenv("PENNSIEVE_LLM_MOCK", "1")
        gov = Governor()
        models = gov.list_models()
        assert models == {"models": []}

    def test_efs_document_builder(self):
        gov = Governor(client=MockClient())
        block = gov.efs_document("workdir/paper.pdf")
        assert block == {"type": "efs_document", "path": "workdir/paper.pdf"}

    def test_real_construction_path_with_sigv4(self, monkeypatch):
        # Regression: httpx 0.28 rejects auth objects that aren't httpx.Auth
        # subclasses. Tests previously used MockClient everywhere and never
        # exercised the real anthropic.Anthropic + httpx.Client(auth=...)
        # construction, so the TypeError surfaced only in production.
        import httpx
        from pennsieve_llm.backends import _SigV4Auth

        # Stub creds so the boto3 chain doesn't try to reach IMDS in CI.
        monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIA-TEST")
        monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret-test")
        monkeypatch.setenv("AWS_SESSION_TOKEN", "")
        monkeypatch.setenv("AWS_REGION", "us-east-1")

        gov = Governor(url="https://x.lambda-url.us-east-1.on.aws")
        client = gov.client()
        assert type(client).__name__ == "Anthropic"
        # The httpx auth must be a real httpx.Auth subclass — duck-typing
        # is no longer accepted by httpx >=0.28.
        assert isinstance(client._client.auth, httpx.Auth)
        assert isinstance(client._client.auth, _SigV4Auth)

    def test_sigv4_auth_flow_signs_request(self, monkeypatch):
        # Regression: botocore.AWSRequest.headers (an http.client.HTTPMessage
        # subclass) doesn't expose .pop(), so an earlier `headers.pop("Host")`
        # raised AttributeError at request time. The construction test above
        # doesn't catch this — it never runs a request through auth_flow.
        import httpx
        from pennsieve_llm.backends import _SigV4Auth

        monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIA-TEST")
        monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret-test")
        monkeypatch.setenv("AWS_SESSION_TOKEN", "")
        monkeypatch.setenv("AWS_REGION", "us-east-1")

        auth = _SigV4Auth(region="us-east-1")
        req = httpx.Request(
            "POST",
            "https://x.lambda-url.us-east-1.on.aws/v1/messages",
            content=b'{"test":1}',
            headers={"Content-Type": "application/json"},
        )
        # Drive the auth_flow generator the same way httpx does internally.
        signed = next(auth.auth_flow(req))
        # SigV4 attaches these headers — their presence proves signing ran.
        assert "Authorization" in signed.headers
        assert signed.headers["Authorization"].startswith("AWS4-HMAC-SHA256")
        assert "X-Amz-Date" in signed.headers


# ---------------------------------------------------------------------------
# End-to-end via Governor + MockClient
# ---------------------------------------------------------------------------


class TestGovernorEndToEnd:
    def test_typical_call(self, monkeypatch):
        monkeypatch.delenv("LLM_GOVERNOR_URL", raising=False)
        monkeypatch.setenv("PENNSIEVE_LLM_MOCK", "1")
        gov = Governor()
        resp = gov.client().messages.create(
            model=MODEL_SONNET_46,
            messages=[{"role": "user", "content": "What is 2+2?"}],
            max_tokens=10,
        )
        assert "[mock]" in resp.content[0].text

    def test_canned_response_for_tests(self, monkeypatch):
        monkeypatch.delenv("LLM_GOVERNOR_URL", raising=False)
        mock = MockClient()
        mock.set_response(text="42")
        gov = Governor(client=mock)
        resp = gov.client().messages.create(
            model=MODEL_SONNET_46,
            messages=[{"role": "user", "content": "What is 6*7?"}],
            max_tokens=10,
        )
        assert resp.content[0].text == "42"
        # Inspect what was sent
        assert mock.calls[0]["model"] == MODEL_SONNET_46


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class TestGovernorError:
    def test_predicates(self):
        err = GovernorError(code="budget_exceeded", msg="over budget")
        assert err.is_budget_exceeded()
        assert not err.is_model_not_allowed()

        err = GovernorError(code="model_not_allowed", msg="...", allowed_models=["a", "b"])
        assert err.is_model_not_allowed()
        assert err.allowed_models == ["a", "b"]


# ---------------------------------------------------------------------------
# Model ID constants
# ---------------------------------------------------------------------------


def test_model_constants_are_bedrock_format():
    # All constants should use the us.anthropic.* inference profile prefix.
    for model_id in (MODEL_HAIKU_45, MODEL_SONNET_45, MODEL_SONNET_46, MODEL_OPUS_47):
        assert model_id.startswith("us.anthropic."), (
            f"{model_id} should be a us.* Bedrock inference profile ID"
        )
