"""Off-chain (EIP-712) attestations.

Same schemas, same fields, but the attestation is signed and stored locally
(or wherever the publisher wants) instead of being broadcast on-chain. Zero
gas. Verifiable by anyone who has the envelope and the attester's address.

Implements EAS V2 off-chain attestation domain so envelopes round-trip with
the official @ethereum-attestation-service/eas-sdk.
"""
from __future__ import annotations

import json
import os
import secrets
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Final, Literal

from eth_abi.packed import encode_packed
from eth_account import Account
from eth_account.messages import encode_typed_data
from eth_utils import keccak

from fidemark.errors import FidemarkError, map_chain_error
from fidemark.hashing import hash_content, hash_prompt
from fidemark.networks import NetworkConfig
from fidemark.schema import (
    AI_FIELDS,
    HUMAN_FIELDS,
    decode_schema_data,
    encode_schema_data,
)

# Must match the EAS contract's Semver. Base + Base Sepolia ship 1.3.0.
EAS_DOMAIN_NAME: Final = "EAS Attestation"
EAS_DOMAIN_VERSION: Final = "1.3.0"
DELEGATED_DOMAIN_NAME: Final = "EAS"
DELEGATED_DOMAIN_VERSION: Final = "1.3.0"
OFFCHAIN_VERSION_V2: Final = 2
ZERO_ADDRESS: Final = "0x" + "00" * 20
ZERO_BYTES32: Final = "0x" + "00" * 32

FidemarkSchemaType = Literal["human", "ai", "multi", "pop"]

ATTEST_TYPES_V2: Final = {
    "Attest": [
        {"name": "version", "type": "uint16"},
        {"name": "schema", "type": "bytes32"},
        {"name": "recipient", "type": "address"},
        {"name": "time", "type": "uint64"},
        {"name": "expirationTime", "type": "uint64"},
        {"name": "revocable", "type": "bool"},
        {"name": "refUID", "type": "bytes32"},
        {"name": "data", "type": "bytes"},
        {"name": "salt", "type": "bytes32"},
    ],
}

DELEGATED_ATTEST_TYPES: Final = {
    "Attest": [
        {"name": "attester", "type": "address"},
        {"name": "schema", "type": "bytes32"},
        {"name": "recipient", "type": "address"},
        {"name": "expirationTime", "type": "uint64"},
        {"name": "revocable", "type": "bool"},
        {"name": "refUID", "type": "bytes32"},
        {"name": "data", "type": "bytes"},
        {"name": "value", "type": "uint256"},
        {"name": "nonce", "type": "uint256"},
        {"name": "deadline", "type": "uint64"},
    ],
}


@dataclass
class OffchainSignOptions:
    """Knobs for signing.

    `sign_with_delegated` produces an additional EAS-delegated-attestation
    signature embedded in `OffchainEnvelope.delegated`, so a third party can
    bring the envelope on-chain later via `Fidemark.publish_offchain()`.
    """

    sign_with_delegated: bool = False
    eas_nonce: int | None = None
    deadline: int = 0
    salt: str | None = None


def sign_delegated_attestation(
    *,
    private_key: str,
    network: NetworkConfig,
    attester: str,
    schema_uid: str,
    encoded_data: bytes,
    nonce: int,
    deadline: int = 0,
) -> "DelegatedSignaturePayload":
    """Sign an EAS-delegated attestation. Mirrors the typed data the EAS
    `EIP712Verifier` enforces on `attestByDelegation`.

    The caller is responsible for reading the attester's current nonce from
    the EAS contract (e.g. via `eas.functions.getNonce(attester).call()`).
    Each delegated signature is single-use: EAS bumps the nonce after a
    successful publish, invalidating any signature still bound to it.
    """
    typed = {
        "domain": {
            "name": DELEGATED_DOMAIN_NAME,
            "version": DELEGATED_DOMAIN_VERSION,
            "chainId": network.chain_id,
            "verifyingContract": network.contracts.eas,
        },
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
            **DELEGATED_ATTEST_TYPES,
        },
        "primaryType": "Attest",
        "message": {
            "attester": attester,
            "schema": schema_uid,
            "recipient": ZERO_ADDRESS,
            "expirationTime": 0,
            "revocable": True,
            "refUID": ZERO_BYTES32,
            "data": "0x" + encoded_data.hex(),
            "value": 0,
            "nonce": nonce,
            "deadline": deadline,
        },
    }
    signable = encode_typed_data(full_message=typed)
    signed = Account.sign_message(signable, private_key=private_key)

    return DelegatedSignaturePayload(
        signature={
            "r": "0x" + signed.r.to_bytes(32, "big").hex(),
            "s": "0x" + signed.s.to_bytes(32, "big").hex(),
            "v": signed.v,
        },
        nonce=str(nonce),
        deadline=str(deadline),
        request={
            "schema": schema_uid,
            "recipient": ZERO_ADDRESS,
            "expirationTime": "0",
            "revocable": True,
            "refUID": ZERO_BYTES32,
            "data": "0x" + encoded_data.hex(),
            "value": "0",
        },
    )


@dataclass
class DelegatedSignaturePayload:
    """Compact 65-byte signature plus the EAS message snapshot needed to publish."""

    signature: dict[str, Any]
    nonce: str
    deadline: str
    request: dict[str, Any]


@dataclass
class OffchainSignedMessage:
    """Mirrors EAS-SDK's SignedOffchainAttestation `.message` field."""

    version: int
    schema: str
    recipient: str
    time: int
    expirationTime: int
    revocable: bool
    refUID: str
    data: str
    salt: str


@dataclass
class OffchainSignedAttestation:
    """Mirrors EAS-SDK's SignedOffchainAttestation."""

    domain: dict[str, Any]
    primaryType: str
    types: dict[str, Any]
    message: OffchainSignedMessage
    signature: dict[str, Any]
    uid: str
    version: int


@dataclass
class OffchainEnvelope:
    """Wire format for an off-chain attestation. JSON-serializable end to end."""

    type: FidemarkSchemaType
    fidemark_version: int
    uid: str
    attester: str
    network: dict[str, Any]
    signed: OffchainSignedAttestation
    decoded: dict[str, Any]
    delegated: DelegatedSignaturePayload | None = None


def _eas_domain(network: NetworkConfig) -> dict[str, Any]:
    return {
        "name": EAS_DOMAIN_NAME,
        "version": EAS_DOMAIN_VERSION,
        "chainId": network.chain_id,
        "verifyingContract": network.contracts.eas,
    }


def _offchain_uid_v2(
    *,
    schema: str,
    recipient: str,
    time_unix: int,
    expiration_time: int,
    revocable: bool,
    ref_uid: str,
    data: bytes,
    salt: str,
) -> str:
    packed = encode_packed(
        ["uint16", "bytes32", "address", "uint64", "uint64", "bool", "bytes32", "bytes", "bytes32"],
        [
            OFFCHAIN_VERSION_V2,
            bytes.fromhex(schema[2:]),
            recipient,
            time_unix,
            expiration_time,
            revocable,
            bytes.fromhex(ref_uid[2:]),
            data,
            bytes.fromhex(salt[2:]),
        ],
    )
    return "0x" + keccak(packed).hex()


def _build_typed_message(
    *,
    network: NetworkConfig,
    schema_uid: str,
    recipient: str,
    time_unix: int,
    revocable: bool,
    ref_uid: str,
    data: bytes,
    salt: str,
) -> dict[str, Any]:
    return {
        "domain": _eas_domain(network),
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
            **ATTEST_TYPES_V2,
        },
        "primaryType": "Attest",
        "message": {
            "version": OFFCHAIN_VERSION_V2,
            "schema": schema_uid,
            "recipient": recipient,
            "time": time_unix,
            "expirationTime": 0,
            "revocable": revocable,
            "refUID": ref_uid,
            "data": "0x" + data.hex(),
            "salt": salt,
        },
    }


def _generate_salt() -> str:
    return "0x" + secrets.token_bytes(32).hex()


def _sign_offchain(
    *,
    private_key: str,
    network: NetworkConfig,
    schema_uid: str,
    encoded_data: bytes,
    time_unix: int,
    salt: str | None = None,
) -> OffchainSignedAttestation:
    salt_value = salt or _generate_salt()
    typed = _build_typed_message(
        network=network,
        schema_uid=schema_uid,
        recipient=ZERO_ADDRESS,
        time_unix=time_unix,
        revocable=True,
        ref_uid=ZERO_BYTES32,
        data=encoded_data,
        salt=salt_value,
    )
    signable = encode_typed_data(full_message=typed)
    signed = Account.sign_message(signable, private_key=private_key)

    uid = _offchain_uid_v2(
        schema=schema_uid,
        recipient=ZERO_ADDRESS,
        time_unix=time_unix,
        expiration_time=0,
        revocable=True,
        ref_uid=ZERO_BYTES32,
        data=encoded_data,
        salt=salt_value,
    )

    return OffchainSignedAttestation(
        domain=typed["domain"],
        primaryType="Attest",
        types=ATTEST_TYPES_V2,
        message=OffchainSignedMessage(
            version=OFFCHAIN_VERSION_V2,
            schema=schema_uid,
            recipient=ZERO_ADDRESS,
            time=time_unix,
            expirationTime=0,
            revocable=True,
            refUID=ZERO_BYTES32,
            data="0x" + encoded_data.hex(),
            salt=salt_value,
        ),
        signature={
            "r": "0x" + signed.r.to_bytes(32, "big").hex(),
            "s": "0x" + signed.s.to_bytes(32, "big").hex(),
            "v": signed.v,
        },
        uid=uid,
        version=OFFCHAIN_VERSION_V2,
    )


def sign_human_offchain(
    private_key: str,
    network: NetworkConfig,
    *,
    content: str | bytes,
    content_type: str,
    creator: str | None = None,
    created_at: int | None = None,
    proof_method: str = "wallet-signed",
    options: OffchainSignOptions | None = None,
) -> OffchainEnvelope:
    """Build an off-chain Human Proof envelope. Zero gas, signing only."""
    account = Account.from_key(private_key)
    attester = account.address
    creator_addr = creator or attester
    created = created_at if created_at is not None else int(time.time())
    content_hash = hash_content(content)

    encoded = encode_schema_data(
        HUMAN_FIELDS,
        {
            "contentHash": content_hash,
            "contentType": content_type,
            "creator": creator_addr,
            "createdAt": created,
            "proofMethod": proof_method,
        },
    )

    options = options or OffchainSignOptions()
    signed = _sign_offchain(
        private_key=private_key,
        network=network,
        schema_uid=network.schemas.human,
        encoded_data=encoded,
        time_unix=created,
        salt=options.salt,
    )

    return OffchainEnvelope(
        type="human",
        fidemark_version=1,
        uid=signed.uid,
        attester=attester,
        network={
            "chainId": network.chain_id,
            "name": network.name,
            "eas": network.contracts.eas,
        },
        signed=signed,
        decoded={
            "contentHash": content_hash,
            "contentType": content_type,
            "creator": creator_addr,
            "createdAt": created,
            "proofMethod": proof_method,
        },
    )


def sign_ai_offchain(
    private_key: str,
    network: NetworkConfig,
    *,
    content: str | bytes,
    model_id: str,
    provider: str,
    prompt: str | bytes | None = None,
    prompt_hash: str | None = None,
    parameters: dict[str, Any] | str | None = None,
    options: OffchainSignOptions | None = None,
) -> OffchainEnvelope:
    """Build an off-chain AI Proof envelope. Same shape as human."""
    if prompt is not None and prompt_hash is not None:
        raise FidemarkError("INVALID_INPUT", "Pass either `prompt` or `prompt_hash`, not both.")

    if prompt_hash is not None:
        ph = _normalize_bytes32(prompt_hash, "prompt_hash")
    elif prompt is not None:
        ph = hash_prompt(prompt)
    else:
        ph = ZERO_BYTES32

    if parameters is None:
        params_str = ""
    elif isinstance(parameters, str):
        params_str = parameters
    else:
        params_str = json.dumps(parameters, separators=(",", ":"), sort_keys=True)

    content_hash = hash_content(content)
    account = Account.from_key(private_key)
    attester = account.address

    encoded = encode_schema_data(
        AI_FIELDS,
        {
            "contentHash": content_hash,
            "modelId": model_id,
            "promptHash": ph,
            "parameters": params_str,
            "provider": provider,
        },
    )

    now = int(time.time())
    options = options or OffchainSignOptions()
    signed = _sign_offchain(
        private_key=private_key,
        network=network,
        schema_uid=network.schemas.ai,
        encoded_data=encoded,
        time_unix=now,
        salt=options.salt,
    )

    return OffchainEnvelope(
        type="ai",
        fidemark_version=1,
        uid=signed.uid,
        attester=attester,
        network={
            "chainId": network.chain_id,
            "name": network.name,
            "eas": network.contracts.eas,
        },
        signed=signed,
        decoded={
            "contentHash": content_hash,
            "modelId": model_id,
            "promptHash": ph,
            "parameters": params_str,
            "provider": provider,
        },
    )


def verify_offchain(envelope: OffchainEnvelope, network: NetworkConfig) -> bool:
    """Verify an envelope's signature recovers to the declared attester.

    Returns False (not raises) when the schema, network, or signature are wrong;
    callers branch on the boolean and never see partial/inconsistent results.
    """
    expected_schema = network.schemas.human if envelope.type == "human" else network.schemas.ai
    if envelope.signed.message.schema != expected_schema:
        return False
    if envelope.network.get("eas", "").lower() != network.contracts.eas.lower():
        return False
    if envelope.network.get("chainId") != network.chain_id:
        return False

    try:
        msg = envelope.signed.message
        typed = _build_typed_message(
            network=network,
            schema_uid=msg.schema,
            recipient=msg.recipient,
            time_unix=msg.time,
            revocable=msg.revocable,
            ref_uid=msg.refUID,
            data=bytes.fromhex(msg.data[2:] if msg.data.startswith("0x") else msg.data),
            salt=msg.salt,
        )
        signable = encode_typed_data(full_message=typed)
        sig = envelope.signed.signature
        v = int(sig["v"])
        r = sig["r"]
        s = sig["s"]
        flat_sig = "0x" + r[2:] + s[2:] + format(v, "02x")
        recovered = Account.recover_message(signable, signature=flat_sig)
        return recovered.lower() == envelope.attester.lower()
    except Exception as err:
        raise map_chain_error(err) from err


def decode_offchain(envelope: OffchainEnvelope) -> dict[str, Any]:
    """Decode an envelope's signed payload back into typed fields."""
    raw_data = envelope.signed.message.data
    data = bytes.fromhex(raw_data[2:] if raw_data.startswith("0x") else raw_data)
    fields = HUMAN_FIELDS if envelope.type == "human" else AI_FIELDS
    decoded = decode_schema_data(fields, data)
    if envelope.type == "human":
        return {
            "contentHash": "0x" + decoded["contentHash"].hex(),
            "contentType": decoded["contentType"],
            "creator": decoded["creator"],
            "createdAt": int(decoded["createdAt"]),
            "proofMethod": decoded["proofMethod"],
        }
    return {
        "contentHash": "0x" + decoded["contentHash"].hex(),
        "modelId": decoded["modelId"],
        "promptHash": "0x" + decoded["promptHash"].hex(),
        "parameters": decoded["parameters"],
        "provider": decoded["provider"],
    }


def envelope_to_json(envelope: OffchainEnvelope) -> str:
    """Serialize an envelope for transport. Dataclasses dump to plain dicts."""
    return json.dumps(asdict(envelope), separators=(",", ":"), sort_keys=False)


def envelope_from_json(payload: str | dict[str, Any]) -> OffchainEnvelope:
    """Inverse of `envelope_to_json`. Only validates shape, not signature."""
    raw = json.loads(payload) if isinstance(payload, str) else payload
    signed_raw = raw["signed"]
    msg = signed_raw["message"]
    signed = OffchainSignedAttestation(
        domain=signed_raw["domain"],
        primaryType=signed_raw["primaryType"],
        types=signed_raw["types"],
        message=OffchainSignedMessage(**msg),
        signature=signed_raw["signature"],
        uid=signed_raw["uid"],
        version=signed_raw["version"],
    )
    delegated = None
    if raw.get("delegated"):
        delegated = DelegatedSignaturePayload(**raw["delegated"])
    return OffchainEnvelope(
        type=raw["type"],
        fidemark_version=raw["fidemark_version"],
        uid=raw["uid"],
        attester=raw["attester"],
        network=raw["network"],
        signed=signed,
        decoded=raw["decoded"],
        delegated=delegated,
    )


def _normalize_bytes32(value: str, field_name: str) -> str:
    s = value.lower()
    if not s.startswith("0x") or len(s) != 66:
        raise FidemarkError(
            "INVALID_INPUT",
            f"{field_name} must be a 0x-prefixed 32-byte hex string, got {value}",
        )
    return s
