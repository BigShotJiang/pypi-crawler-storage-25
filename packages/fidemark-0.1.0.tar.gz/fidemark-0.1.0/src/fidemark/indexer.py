"""EAS GraphQL indexer adapter.

The Fidemark resolver indexes ``contentHash`` on its events, so a chain-log
scan via ``verify_by_hash`` is cheap on local + Sepolia. On busy mainnet,
``eth_getLogs`` over the full deployment range can take many seconds and
may be rate-limited by public RPCs. The EAS indexer (e.g.
``base.easscan.org``) already has every attestation in a Postgres-backed
GraphQL endpoint; this module queries that endpoint by schema, filters
client-side by content hash, and returns UIDs ready for
``Fidemark.verify(uid)``.

The implementation mirrors the TypeScript SDK's ``indexer.ts`` so consumers
can rely on the same behaviour regardless of language.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Literal, Protocol
from urllib import request as urllib_request

from fidemark.errors import FidemarkError

IndexerMode = Literal["events", "graphql", "auto"]

QUERY = """query FidemarkAttestations($schema: String!, $first: Int!) {
  attestations(
    where: { schemaId: { equals: $schema } }
    orderBy: { time: desc }
    take: $first
  ) {
    id
    schemaId
    attester
    recipient
    time
    revocationTime
    refUID
    data
  }
}"""


@dataclass
class GraphqlAttestation:
    id: str
    schemaId: str
    attester: str
    recipient: str
    time: int
    revocationTime: int
    refUID: str
    data: str


class GraphqlClient(Protocol):
    """Anything that can issue a single GraphQL POST and return decoded JSON."""

    def query(self, body: dict[str, Any]) -> dict[str, Any]:  # pragma: no cover - structural
        ...


@dataclass
class DefaultGraphqlClient:
    """Stdlib urllib.request-based client. No third-party dependency.

    Pass a custom ``GraphqlClient`` if you need timeouts, retries, auth
    headers, or to mock requests in tests.
    """

    url: str
    timeout_seconds: float = 30.0

    def query(self, body: dict[str, Any]) -> dict[str, Any]:
        payload = json.dumps(body).encode("utf-8")
        req = urllib_request.Request(
            self.url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib_request.urlopen(req, timeout=self.timeout_seconds) as resp:
                if resp.status != 200:
                    raise FidemarkError("RPC_ERROR", f"Indexer returned HTTP {resp.status}")
                return json.loads(resp.read().decode("utf-8"))
        except FidemarkError:
            raise
        except Exception as err:
            raise FidemarkError("RPC_ERROR", f"Indexer request failed: {err}", err) from err


def default_client(url: str) -> GraphqlClient:
    return DefaultGraphqlClient(url=url)


def indexer_verify_by_hash(
    *,
    client: GraphqlClient,
    schemas: dict[str, str],
    content_hash: str,
    type: str | None = None,
    take: int = 1000,
) -> list[str]:
    """Query the indexer for attestations on Fidemark schemas, filter client-side
    by content hash. Returns UIDs sorted newest-first.

    ``schemas`` is a dict with ``human`` and ``ai`` keys (matching
    ``NetworkSchemas``). ``type`` restricts the query to one of the two when set.
    """
    wanted = content_hash.lower()
    targets: list[tuple[str, str]] = []
    if type != "ai":
        targets.append((schemas["human"], "human"))
    if type != "human":
        targets.append((schemas["ai"], "ai"))

    matches: list[GraphqlAttestation] = []
    for schema_uid, _kind in targets:
        out = client.query({"query": QUERY, "variables": {"schema": schema_uid, "first": take}})
        errors = out.get("errors") or []
        if errors:
            raise FidemarkError("RPC_ERROR", f"Indexer error: {errors[0].get('message', 'unknown')}")
        items: Iterable[dict[str, Any]] = (out.get("data") or {}).get("attestations") or []
        for att in items:
            data = att.get("data") or ""
            if len(data) < 66:
                continue
            head_hash = data[:66].lower()
            if head_hash == wanted:
                matches.append(GraphqlAttestation(**att))

    matches.sort(key=lambda a: a.time, reverse=True)
    return [m.id for m in matches]
