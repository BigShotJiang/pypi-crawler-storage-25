"""Minimal EAS contract ABI fragment.

Only the subset the Python SDK needs: attest, multiAttest, attestByDelegation,
revoke, getAttestation, getNonce, plus the Attested event used to recover UIDs
from receipts.
"""
from __future__ import annotations

from typing import Final

EAS_ABI: Final = [
    {
        "type": "event",
        "name": "Attested",
        "inputs": [
            {"name": "recipient", "type": "address", "indexed": True},
            {"name": "attester", "type": "address", "indexed": True},
            {"name": "uid", "type": "bytes32", "indexed": False},
            {"name": "schemaUID", "type": "bytes32", "indexed": True},
        ],
        "anonymous": False,
    },
    {
        "type": "function",
        "name": "attest",
        "stateMutability": "payable",
        "inputs": [
            {
                "name": "request",
                "type": "tuple",
                "components": [
                    {"name": "schema", "type": "bytes32"},
                    {
                        "name": "data",
                        "type": "tuple",
                        "components": [
                            {"name": "recipient", "type": "address"},
                            {"name": "expirationTime", "type": "uint64"},
                            {"name": "revocable", "type": "bool"},
                            {"name": "refUID", "type": "bytes32"},
                            {"name": "data", "type": "bytes"},
                            {"name": "value", "type": "uint256"},
                        ],
                    },
                ],
            }
        ],
        "outputs": [{"name": "", "type": "bytes32"}],
    },
    {
        "type": "function",
        "name": "multiAttest",
        "stateMutability": "payable",
        "inputs": [
            {
                "name": "multiRequests",
                "type": "tuple[]",
                "components": [
                    {"name": "schema", "type": "bytes32"},
                    {
                        "name": "data",
                        "type": "tuple[]",
                        "components": [
                            {"name": "recipient", "type": "address"},
                            {"name": "expirationTime", "type": "uint64"},
                            {"name": "revocable", "type": "bool"},
                            {"name": "refUID", "type": "bytes32"},
                            {"name": "data", "type": "bytes"},
                            {"name": "value", "type": "uint256"},
                        ],
                    },
                ],
            }
        ],
        "outputs": [{"name": "", "type": "bytes32[]"}],
    },
    {
        "type": "function",
        "name": "attestByDelegation",
        "stateMutability": "payable",
        "inputs": [
            {
                "name": "delegatedRequest",
                "type": "tuple",
                "components": [
                    {"name": "schema", "type": "bytes32"},
                    {
                        "name": "data",
                        "type": "tuple",
                        "components": [
                            {"name": "recipient", "type": "address"},
                            {"name": "expirationTime", "type": "uint64"},
                            {"name": "revocable", "type": "bool"},
                            {"name": "refUID", "type": "bytes32"},
                            {"name": "data", "type": "bytes"},
                            {"name": "value", "type": "uint256"},
                        ],
                    },
                    {
                        "name": "signature",
                        "type": "tuple",
                        "components": [
                            {"name": "v", "type": "uint8"},
                            {"name": "r", "type": "bytes32"},
                            {"name": "s", "type": "bytes32"},
                        ],
                    },
                    {"name": "attester", "type": "address"},
                    {"name": "deadline", "type": "uint64"},
                ],
            }
        ],
        "outputs": [{"name": "", "type": "bytes32"}],
    },
    {
        "type": "function",
        "name": "revoke",
        "stateMutability": "payable",
        "inputs": [
            {
                "name": "request",
                "type": "tuple",
                "components": [
                    {"name": "schema", "type": "bytes32"},
                    {
                        "name": "data",
                        "type": "tuple",
                        "components": [
                            {"name": "uid", "type": "bytes32"},
                            {"name": "value", "type": "uint256"},
                        ],
                    },
                ],
            }
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "getAttestation",
        "stateMutability": "view",
        "inputs": [{"name": "uid", "type": "bytes32"}],
        "outputs": [
            {
                "name": "",
                "type": "tuple",
                "components": [
                    {"name": "uid", "type": "bytes32"},
                    {"name": "schema", "type": "bytes32"},
                    {"name": "time", "type": "uint64"},
                    {"name": "expirationTime", "type": "uint64"},
                    {"name": "revocationTime", "type": "uint64"},
                    {"name": "refUID", "type": "bytes32"},
                    {"name": "recipient", "type": "address"},
                    {"name": "attester", "type": "address"},
                    {"name": "revocable", "type": "bool"},
                    {"name": "data", "type": "bytes"},
                ],
            }
        ],
    },
    {
        "type": "function",
        "name": "getNonce",
        "stateMutability": "view",
        "inputs": [{"name": "account", "type": "address"}],
        "outputs": [{"name": "", "type": "uint256"}],
    },
]

RESOLVER_EVENTS_ABI: Final = [
    {
        "type": "event",
        "name": "HumanAttestation",
        "inputs": [
            {"name": "uid", "type": "bytes32", "indexed": True},
            {"name": "creator", "type": "address", "indexed": True},
            {"name": "contentHash", "type": "bytes32", "indexed": True},
            {"name": "proofMethod", "type": "string", "indexed": False},
        ],
        "anonymous": False,
    },
    {
        "type": "event",
        "name": "AIAttestation",
        "inputs": [
            {"name": "uid", "type": "bytes32", "indexed": True},
            {"name": "attester", "type": "address", "indexed": True},
            {"name": "contentHash", "type": "bytes32", "indexed": True},
            {"name": "modelId", "type": "string", "indexed": False},
            {"name": "provider", "type": "string", "indexed": False},
        ],
        "anonymous": False,
    },
]
