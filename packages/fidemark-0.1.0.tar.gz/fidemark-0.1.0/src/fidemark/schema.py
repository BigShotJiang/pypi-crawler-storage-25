"""SchemaEncoder, equivalent to EAS-SDK's schema-data ABI encoder.

Each Fidemark schema is a fixed list of ABI-typed fields; this module ABI-encodes
field values into the `bytes data` payload the on-chain resolver decodes.

Field types and order MUST match the schema string registered on EAS, otherwise
the resolver's decode call reverts with a coalesce error.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from eth_abi import decode as abi_decode
from eth_abi import encode as abi_encode

HUMAN_SCHEMA_DEF = (
    "bytes32 contentHash,string contentType,address creator,uint64 createdAt,string proofMethod"
)
HUMAN_FIELDS = [
    ("contentHash", "bytes32"),
    ("contentType", "string"),
    ("creator", "address"),
    ("createdAt", "uint64"),
    ("proofMethod", "string"),
]

AI_SCHEMA_DEF = (
    "bytes32 contentHash,string modelId,bytes32 promptHash,string parameters,string provider"
)
AI_FIELDS = [
    ("contentHash", "bytes32"),
    ("modelId", "string"),
    ("promptHash", "bytes32"),
    ("parameters", "string"),
    ("provider", "string"),
]

MULTI_SCHEMA_DEF = (
    "bytes32 contentHash,string contentType,address[] attesters,bytes[] signatures,"
    "uint64 createdAt,string proofMethod"
)
MULTI_FIELDS = [
    ("contentHash", "bytes32"),
    ("contentType", "string"),
    ("attesters", "address[]"),
    ("signatures", "bytes[]"),
    ("createdAt", "uint64"),
    ("proofMethod", "string"),
]

POP_SCHEMA_DEF = (
    "bytes32 contentHash,string contentType,address creator,uint64 createdAt,"
    "uint256 root,uint256 nullifierHash,uint256[8] proof,string proofMethod"
)
POP_FIELDS = [
    ("contentHash", "bytes32"),
    ("contentType", "string"),
    ("creator", "address"),
    ("createdAt", "uint64"),
    ("root", "uint256"),
    ("nullifierHash", "uint256"),
    ("proof", "uint256[8]"),
    ("proofMethod", "string"),
]


@dataclass
class FieldSpec:
    name: str
    type: str


def _to_bytes32(value: str | bytes) -> bytes:
    if isinstance(value, bytes):
        if len(value) != 32:
            raise ValueError(f"bytes32 value must be 32 bytes, got {len(value)}")
        return value
    s = value.lower()
    if not s.startswith("0x") or len(s) != 66:
        raise ValueError(f"bytes32 value must be 0x-prefixed 32-byte hex, got {value!r}")
    return bytes.fromhex(s[2:])


def _to_bytes(value: str | bytes) -> bytes:
    if isinstance(value, bytes):
        return value
    s = value
    if s.startswith("0x") or s.startswith("0X"):
        return bytes.fromhex(s[2:])
    return bytes.fromhex(s)


def _normalize_value(typ: str, val: Any) -> Any:
    if typ == "bytes32":
        return _to_bytes32(val)
    if typ == "bytes":
        return _to_bytes(val)
    if typ == "bytes[]":
        return [_to_bytes(v) for v in val]
    if typ.endswith("]") and typ.startswith("uint"):
        return [int(v) for v in val]
    if typ.startswith("uint"):
        return int(val)
    if typ == "address":
        return val
    if typ == "address[]":
        return list(val)
    if typ == "string":
        return str(val)
    return val


def encode_schema_data(fields: list[tuple[str, str]], values: dict[str, Any]) -> bytes:
    """ABI-encode an ordered list of (name, abi_type) pairs into the data blob."""
    types = [t for _, t in fields]
    args = [_normalize_value(t, values[n]) for n, t in fields]
    return abi_encode(types, args)


def decode_schema_data(fields: list[tuple[str, str]], data: bytes) -> dict[str, Any]:
    """Decode the data blob back into a name -> value dict."""
    types = [t for _, t in fields]
    decoded = abi_decode(types, data)
    return {name: decoded[i] for i, (name, _t) in enumerate(fields)}
