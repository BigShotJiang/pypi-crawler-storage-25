"""High-level Fidemark client.

Mirrors the TypeScript Fidemark class. Wraps web3.py against the EAS contract
and the resolver event surface so consumers get the same set of methods,
return shapes, and error codes regardless of language.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Iterable, Literal

from eth_account import Account
from eth_typing import HexStr
from eth_utils import keccak
from web3 import Web3
from web3.types import TxReceipt

from fidemark._eas_abi import EAS_ABI, RESOLVER_EVENTS_ABI
from fidemark.ens import VerifiedENS, resolve_verified_ens
from fidemark.errors import FidemarkError, map_chain_error
from fidemark.hashing import hash_content, hash_prompt
from fidemark.indexer import (
    GraphqlClient,
    IndexerMode,
    default_client as default_indexer_client,
    indexer_verify_by_hash,
)
from fidemark.networks import NetworkConfig, NetworkName, get_network
from fidemark.offchain import (
    DelegatedSignaturePayload,
    OffchainEnvelope,
    OffchainSignOptions,
    sign_ai_offchain,
    sign_delegated_attestation,
    sign_human_offchain,
    verify_offchain as verify_offchain_envelope,
)
from fidemark.pop import WorldIdProof, normalize_world_id_proof
from fidemark.schema import (
    AI_FIELDS,
    HUMAN_FIELDS,
    MULTI_FIELDS,
    POP_FIELDS,
    decode_schema_data,
    encode_schema_data,
)

ZERO_ADDRESS = "0x" + "00" * 20
ZERO_BYTES32 = "0x" + "00" * 32
DEFAULT_VERIFY_URL_BASE = "https://verify.fidemark.dev"

FidemarkSchemaType = Literal["human", "ai", "multi", "pop"]


@dataclass
class AttestHumanInput:
    content: str | bytes
    content_type: str
    creator: str | None = None
    created_at: int | None = None
    proof_method: str = "wallet-signed"
    ref_uid: str | None = None


@dataclass
class AttestAIInput:
    content: str | bytes
    model_id: str
    provider: str
    prompt: str | bytes | None = None
    prompt_hash: str | None = None
    parameters: dict[str, Any] | str | None = None
    ref_uid: str | None = None


@dataclass
class MultiPartySlipInput:
    signer: str
    signature: str


@dataclass
class MultiPartyClaimInput:
    content_hash: str
    content_type: str
    created_at: int


@dataclass
class AttestMultiPartyInput:
    claim: MultiPartyClaimInput
    slips: list[MultiPartySlipInput]
    proof_method: str = "multi-party"
    ref_uid: str | None = None


@dataclass
class AttestHumanWithPoPInput:
    content: str | bytes
    content_type: str
    world_id_proof: WorldIdProof
    creator: str | None = None
    created_at: int | None = None
    proof_method: str = "pop-verified-worldid"
    ref_uid: str | None = None


@dataclass
class AttestResult:
    uid: str
    tx_hash: str
    verify_url: str


@dataclass
class HumanFields:
    content_type: str
    creator: str
    proof_method: str
    created_at_attested: int


@dataclass
class AIFields:
    model_id: str
    provider: str
    prompt_hash: str
    parameters: str


@dataclass
class MultiFields:
    content_type: str
    attesters: list[str]
    signatures: list[str]
    proof_method: str
    created_at_attested: int


@dataclass
class PoPFields:
    content_type: str
    creator: str
    proof_method: str
    created_at_attested: int
    root: str
    nullifier_hash: str
    proof: list[str]


@dataclass
class FidemarkAttestation:
    uid: str
    type: FidemarkSchemaType
    schema_uid: str
    attester: str
    recipient: str
    content_hash: str
    created_at: int
    revoked: bool
    ref_uid: str
    verify_url: str
    revoked_at: int | None = None
    human: HumanFields | None = None
    ai: AIFields | None = None
    multi: MultiFields | None = None
    pop: PoPFields | None = None


@dataclass
class BatchHumanItem(AttestHumanInput):
    type: Literal["human"] = "human"


@dataclass
class BatchAIItem(AttestAIInput):
    type: Literal["ai"] = "ai"


@dataclass
class BatchResult:
    uids: list[str]
    tx_hash: str
    verify_urls: list[str]


@dataclass
class VerifyByHashOptions:
    type: FidemarkSchemaType | None = None
    from_block: int | None = None
    to_block: int | str | None = None


class Fidemark:
    """High-level client mirroring @fidemark/sdk's Fidemark class.

    Either construct with `private_key` (for write operations) or with
    `provider_url` only (read-only). For ENS attestations also pass
    `ens_provider_url` pointing at an Ethereum mainnet RPC.
    """

    def __init__(
        self,
        *,
        network: NetworkName | NetworkConfig,
        private_key: str | None = None,
        provider_url: str | None = None,
        verify_url_base: str = DEFAULT_VERIFY_URL_BASE,
        ens_provider_url: str | None = None,
        indexer: IndexerMode | None = None,
        indexer_url: str | None = None,
        indexer_client: GraphqlClient | None = None,
    ) -> None:
        self.network: NetworkConfig = (
            get_network(network) if isinstance(network, str) else network
        )
        rpc = provider_url or self.network.rpc_url
        self.w3 = Web3(Web3.HTTPProvider(rpc))
        self.eas = self.w3.eth.contract(
            address=Web3.to_checksum_address(self.network.contracts.eas),
            abi=EAS_ABI,
        )
        self._verify_url_base = verify_url_base.rstrip("/")
        self._account = Account.from_key(private_key) if private_key else None
        self._ens_w3 = Web3(Web3.HTTPProvider(ens_provider_url)) if ens_provider_url else None

        # Indexer wiring. Default mirrors the TS SDK: "events" unless the
        # caller passed `indexer_url` or `indexer_client`, in which case
        # "auto" is implied (try GraphQL, fall back to events on error).
        self._indexer_mode: IndexerMode = (
            indexer if indexer is not None else ("auto" if indexer_url or indexer_client else "events")
        )
        self._indexer_client: GraphqlClient | None = (
            indexer_client
            if indexer_client is not None
            else (default_indexer_client(indexer_url) if indexer_url else None)
        )

    @property
    def address(self) -> str:
        if self._account is None:
            raise FidemarkError(
                "INVALID_INPUT",
                "This operation requires a signer. Construct Fidemark with `private_key`.",
            )
        return self._account.address

    def verify_url_for(self, uid: str) -> str:
        return f"{self._verify_url_base}/{uid}"

    def attest_human(self, input: AttestHumanInput) -> AttestResult:
        creator = input.creator or self.address
        created_at = input.created_at if input.created_at is not None else int(time.time())
        encoded = encode_schema_data(
            HUMAN_FIELDS,
            {
                "contentHash": hash_content(input.content),
                "contentType": input.content_type,
                "creator": creator,
                "createdAt": created_at,
                "proofMethod": input.proof_method,
            },
        )
        return self._attest(self.network.schemas.human, encoded, input.ref_uid)

    def attest_ai(self, input: AttestAIInput) -> AttestResult:
        if input.prompt is not None and input.prompt_hash is not None:
            raise FidemarkError("INVALID_INPUT", "Pass either `prompt` or `prompt_hash`, not both.")

        if input.prompt_hash is not None:
            prompt_hash = _normalize_bytes32(input.prompt_hash, "prompt_hash")
        elif input.prompt is not None:
            prompt_hash = hash_prompt(input.prompt)
        else:
            prompt_hash = ZERO_BYTES32

        if input.parameters is None:
            params = ""
        elif isinstance(input.parameters, str):
            params = input.parameters
        else:
            params = json.dumps(input.parameters, separators=(",", ":"), sort_keys=True)

        encoded = encode_schema_data(
            AI_FIELDS,
            {
                "contentHash": hash_content(input.content),
                "modelId": input.model_id,
                "promptHash": prompt_hash,
                "parameters": params,
                "provider": input.provider,
            },
        )
        return self._attest(self.network.schemas.ai, encoded, input.ref_uid)

    def attest_multi_party(self, input: AttestMultiPartyInput) -> AttestResult:
        if not self.network.schemas.multi:
            raise FidemarkError(
                "INVALID_INPUT",
                f"Network {self.network.name} has no multi-party schema deployed.",
            )
        if len(input.slips) < 2:
            raise FidemarkError("INVALID_INPUT", "attest_multi_party requires at least 2 slips.")

        encoded = encode_schema_data(
            MULTI_FIELDS,
            {
                "contentHash": input.claim.content_hash,
                "contentType": input.claim.content_type,
                "attesters": [s.signer for s in input.slips],
                "signatures": [s.signature for s in input.slips],
                "createdAt": input.claim.created_at,
                "proofMethod": input.proof_method,
            },
        )
        return self._attest(self.network.schemas.multi, encoded, input.ref_uid)

    def attest_human_with_pop(self, input: AttestHumanWithPoPInput) -> AttestResult:
        if not self.network.schemas.pop:
            raise FidemarkError(
                "INVALID_INPUT",
                f"Network {self.network.name} has no PoP schema deployed.",
            )
        creator = input.creator or self.address
        created_at = input.created_at if input.created_at is not None else int(time.time())
        content_hash = hash_content(input.content)
        normalized = normalize_world_id_proof(input.world_id_proof)

        encoded = encode_schema_data(
            POP_FIELDS,
            {
                "contentHash": content_hash,
                "contentType": input.content_type,
                "creator": creator,
                "createdAt": created_at,
                "root": normalized["root"],
                "nullifierHash": normalized["nullifier_hash"],
                "proof": list(normalized["proof"]),
                "proofMethod": input.proof_method,
            },
        )
        return self._attest(self.network.schemas.pop, encoded, input.ref_uid)

    def attest_batch(self, items: list[BatchHumanItem | BatchAIItem]) -> BatchResult:
        if not items:
            raise FidemarkError("INVALID_INPUT", "attest_batch requires at least one item.")
        if self._account is None:
            raise FidemarkError(
                "INVALID_INPUT",
                "attest_batch requires a signer. Construct Fidemark with `private_key`.",
            )

        signer_address = self._account.address
        human_data: list[dict[str, Any]] = []
        ai_data: list[dict[str, Any]] = []
        slot_for_item: list[tuple[Literal["human", "ai"], int]] = []

        for item in items:
            if item.type == "human":
                creator = item.creator or signer_address
                created_at = item.created_at if item.created_at is not None else int(time.time())
                encoded = encode_schema_data(
                    HUMAN_FIELDS,
                    {
                        "contentHash": hash_content(item.content),
                        "contentType": item.content_type,
                        "creator": creator,
                        "createdAt": created_at,
                        "proofMethod": item.proof_method,
                    },
                )
                human_data.append(self._attest_data(encoded, item.ref_uid))
                slot_for_item.append(("human", len(human_data) - 1))
            else:
                if item.prompt is not None and item.prompt_hash is not None:
                    raise FidemarkError(
                        "INVALID_INPUT",
                        "Pass either `prompt` or `prompt_hash`, not both.",
                    )
                if item.prompt_hash is not None:
                    prompt_hash = _normalize_bytes32(item.prompt_hash, "prompt_hash")
                elif item.prompt is not None:
                    prompt_hash = hash_prompt(item.prompt)
                else:
                    prompt_hash = ZERO_BYTES32
                if item.parameters is None:
                    params = ""
                elif isinstance(item.parameters, str):
                    params = item.parameters
                else:
                    params = json.dumps(item.parameters, separators=(",", ":"), sort_keys=True)
                encoded = encode_schema_data(
                    AI_FIELDS,
                    {
                        "contentHash": hash_content(item.content),
                        "modelId": item.model_id,
                        "promptHash": prompt_hash,
                        "parameters": params,
                        "provider": item.provider,
                    },
                )
                ai_data.append(self._attest_data(encoded, item.ref_uid))
                slot_for_item.append(("ai", len(ai_data) - 1))

        requests: list[dict[str, Any]] = []
        if human_data:
            requests.append({"schema": self.network.schemas.human, "data": human_data})
        if ai_data:
            requests.append({"schema": self.network.schemas.ai, "data": ai_data})

        receipt = self._send_tx(self.eas.functions.multiAttest(self._tuples_for_multi(requests)))
        uids = self._uids_from_receipt(receipt)
        if len(uids) != len(items):
            raise FidemarkError(
                "RPC_ERROR",
                f"multiAttest emitted {len(uids)} UIDs but expected {len(items)}.",
            )

        # multiAttest emits in the same order as the requests array. Walk the
        # human slots first (if present) then ai slots, and reassign by input index.
        human_uids: list[str] = []
        ai_uids: list[str] = []
        cursor = 0
        if human_data:
            human_uids = uids[cursor : cursor + len(human_data)]
            cursor += len(human_data)
        if ai_data:
            ai_uids = uids[cursor : cursor + len(ai_data)]
        ordered_uids = [
            human_uids[idx] if schema == "human" else ai_uids[idx]
            for schema, idx in slot_for_item
        ]
        return BatchResult(
            uids=ordered_uids,
            tx_hash="0x" + receipt["transactionHash"].hex(),
            verify_urls=[self.verify_url_for(u) for u in ordered_uids],
        )

    def verify(self, uid: str) -> FidemarkAttestation:
        try:
            raw = self.eas.functions.getAttestation(_to_bytes32(uid)).call()
        except Exception as err:
            raise map_chain_error(err) from err

        (
            r_uid,
            r_schema,
            r_time,
            _r_expiration,
            r_revocation_time,
            r_ref_uid,
            r_recipient,
            r_attester,
            _r_revocable,
            r_data,
        ) = raw

        if int.from_bytes(r_uid, "big") == 0 or int(r_attester, 16) == 0:
            raise FidemarkError("ATTESTATION_NOT_FOUND", f"No attestation found for UID {uid}.")

        return self._decode_attestation(
            uid="0x" + r_uid.hex(),
            schema_uid="0x" + r_schema.hex(),
            time_unix=int(r_time),
            revocation_time=int(r_revocation_time),
            ref_uid="0x" + r_ref_uid.hex(),
            recipient=r_recipient,
            attester=r_attester,
            data=bytes(r_data),
        )

    def inspect(self, uid: str) -> dict[str, Any]:
        """Probe a UID without raising. Returns a discriminated dict.

        - {"ok": True, "attestation": FidemarkAttestation}
        - {"ok": False, "reason": "not_found"}
        - {"ok": False, "reason": "foreign_schema", "message": str}
        - {"ok": False, "reason": "rpc_error", "message": str}
        """
        try:
            attestation = self.verify(uid)
            return {"ok": True, "attestation": attestation}
        except FidemarkError as err:
            if err.code == "ATTESTATION_NOT_FOUND":
                return {"ok": False, "reason": "not_found"}
            if err.code == "UNKNOWN_SCHEMA":
                return {"ok": False, "reason": "foreign_schema", "message": str(err)}
            return {"ok": False, "reason": "rpc_error", "message": str(err)}
        except Exception as err:  # network/RPC failure
            return {"ok": False, "reason": "rpc_error", "message": str(err)}

    def verify_by_hash(
        self,
        content_hash: str,
        options: VerifyByHashOptions | None = None,
    ) -> list[FidemarkAttestation]:
        opts = options or VerifyByHashOptions()
        normalized = _normalize_bytes32(content_hash, "content_hash")

        # Indexer path. "graphql" hits the EAS indexer and raises on failure.
        # "auto" tries the indexer first, falls through to the event scan on
        # any error so we don't break callers when the indexer is briefly
        # unreachable. Both modes are no-ops when no client is configured.
        if self._indexer_mode in ("graphql", "auto") and self._indexer_client is not None:
            try:
                uids = indexer_verify_by_hash(
                    client=self._indexer_client,
                    schemas={"human": self.network.schemas.human, "ai": self.network.schemas.ai},
                    content_hash=normalized,
                    type=opts.type,
                )
                results = [self.verify(u) for u in uids]
                results.sort(key=lambda a: a.created_at, reverse=True)
                return results
            except Exception:
                if self._indexer_mode == "graphql":
                    raise
                # auto: fall through to event scan
        if self._indexer_mode == "graphql" and self._indexer_client is None:
            raise FidemarkError(
                "INVALID_INPUT",
                "indexer mode is 'graphql' but no indexer_url/indexer_client was provided.",
            )

        resolver = self.w3.eth.contract(
            address=Web3.to_checksum_address(self.network.contracts.resolver),
            abi=RESOLVER_EVENTS_ABI,
        )
        from_block = opts.from_block if opts.from_block is not None else (self.network.deploy_block or 0)
        to_block = opts.to_block if opts.to_block is not None else "latest"

        topic_value = HexStr(normalized)
        uids: set[str] = set()

        if opts.type != "ai":
            logs = resolver.events.HumanAttestation().get_logs(
                from_block=from_block,
                to_block=to_block,
                argument_filters={"contentHash": topic_value},
            )
            for log in logs:
                uids.add("0x" + log["args"]["uid"].hex())

        if opts.type != "human":
            logs = resolver.events.AIAttestation().get_logs(
                from_block=from_block,
                to_block=to_block,
                argument_filters={"contentHash": topic_value},
            )
            for log in logs:
                uids.add("0x" + log["args"]["uid"].hex())

        results = [self.verify(u) for u in uids]
        results.sort(key=lambda a: a.created_at, reverse=True)
        return results

    def verify_chain(self, uid: str) -> list[FidemarkAttestation]:
        """Walk the refUID chain root -> leaf, capped at 32 hops, cycle-safe."""
        chain: list[FidemarkAttestation] = []
        seen: set[str] = set()
        cursor = uid
        for _ in range(32):
            if cursor in seen:
                break
            seen.add(cursor)
            try:
                att = self.verify(cursor)
            except FidemarkError as err:
                if err.code in ("UNKNOWN_SCHEMA", "VALIDATION_REJECTED", "ATTESTATION_NOT_FOUND"):
                    break
                raise
            chain.insert(0, att)
            if att.ref_uid == ZERO_BYTES32:
                break
            cursor = att.ref_uid
        return chain

    def revoke(self, uid: str) -> dict[str, str]:
        if self._account is None:
            raise FidemarkError("INVALID_INPUT", "revoke requires a signer.")
        try:
            raw = self.eas.functions.getAttestation(_to_bytes32(uid)).call()
        except Exception as err:
            raise map_chain_error(err) from err
        if int.from_bytes(raw[0], "big") == 0:
            raise FidemarkError("ATTESTATION_NOT_FOUND", f"No attestation found for UID {uid}.")

        schema = raw[1]
        request = (schema, (_to_bytes32(uid), 0))
        receipt = self._send_tx(self.eas.functions.revoke(request))
        return {"tx_hash": "0x" + receipt["transactionHash"].hex()}

    def attest_human_offchain(
        self,
        input: AttestHumanInput,
        *,
        sign_with_delegated: bool = False,
        deadline: int = 0,
    ) -> OffchainEnvelope:
        if self._account is None:
            raise FidemarkError("INVALID_INPUT", "attest_human_offchain requires a signer.")
        envelope = sign_human_offchain(
            self._account.key.hex(),
            self.network,
            content=input.content,
            content_type=input.content_type,
            creator=input.creator,
            created_at=input.created_at,
            proof_method=input.proof_method,
            options=OffchainSignOptions(deadline=deadline),
        )
        if sign_with_delegated:
            envelope.delegated = self._sign_delegated(
                schema_uid=self.network.schemas.human,
                encoded_data=bytes.fromhex(envelope.signed.message.data[2:]),
                deadline=deadline,
            )
        return envelope

    def attest_ai_offchain(
        self,
        input: AttestAIInput,
        *,
        sign_with_delegated: bool = False,
        deadline: int = 0,
    ) -> OffchainEnvelope:
        if self._account is None:
            raise FidemarkError("INVALID_INPUT", "attest_ai_offchain requires a signer.")
        envelope = sign_ai_offchain(
            self._account.key.hex(),
            self.network,
            content=input.content,
            model_id=input.model_id,
            provider=input.provider,
            prompt=input.prompt,
            prompt_hash=input.prompt_hash,
            parameters=input.parameters,
            options=OffchainSignOptions(deadline=deadline),
        )
        if sign_with_delegated:
            envelope.delegated = self._sign_delegated(
                schema_uid=self.network.schemas.ai,
                encoded_data=bytes.fromhex(envelope.signed.message.data[2:]),
                deadline=deadline,
            )
        return envelope

    def verify_offchain(self, envelope: OffchainEnvelope) -> bool:
        return verify_offchain_envelope(envelope, self.network)

    def publish_offchain(self, envelope: OffchainEnvelope) -> AttestResult:
        """Bring a delegated-signed off-chain envelope on-chain.

        The current client's signer pays gas; the on-chain attester is
        recorded as the original off-chain signer. The new on-chain UID
        differs from `envelope.uid` because EAS hashes `time = block.timestamp`
        into it.
        """
        if self._account is None:
            raise FidemarkError("INVALID_INPUT", "publish_offchain requires a signer.")
        if envelope.delegated is None:
            raise FidemarkError(
                "INVALID_INPUT",
                "Envelope has no delegated signature. Re-sign with sign_with_delegated=True.",
            )
        if envelope.network.get("chainId") != self.network.chain_id:
            raise FidemarkError(
                "INVALID_INPUT",
                f"Envelope was signed for chainId {envelope.network.get('chainId')}; "
                f"current network is {self.network.chain_id}.",
            )
        if envelope.network.get("eas", "").lower() != self.network.contracts.eas.lower():
            raise FidemarkError(
                "INVALID_INPUT",
                "Envelope was signed against a different EAS contract address.",
            )

        d = envelope.delegated
        sig = d.signature
        delegated_request = (
            _to_bytes32(d.request["schema"]),
            (
                d.request["recipient"],
                int(d.request["expirationTime"]),
                bool(d.request["revocable"]),
                _to_bytes32(d.request["refUID"]),
                bytes.fromhex(d.request["data"][2:] if d.request["data"].startswith("0x") else d.request["data"]),
                int(d.request["value"]),
            ),
            (int(sig["v"]), _to_bytes32(sig["r"]), _to_bytes32(sig["s"])),
            envelope.attester,
            int(d.deadline),
        )
        receipt = self._send_tx(self.eas.functions.attestByDelegation(delegated_request))
        uids = self._uids_from_receipt(receipt)
        if not uids:
            raise FidemarkError("RPC_ERROR", "attestByDelegation receipt had no Attested log.")
        uid = uids[0]
        return AttestResult(
            uid=uid,
            tx_hash="0x" + receipt["transactionHash"].hex(),
            verify_url=self.verify_url_for(uid),
        )

    def _sign_delegated(
        self,
        *,
        schema_uid: str,
        encoded_data: bytes,
        deadline: int,
    ) -> DelegatedSignaturePayload:
        if self._account is None:
            raise FidemarkError("INVALID_INPUT", "Cannot sign delegated, no signer.")
        try:
            nonce = self.eas.functions.getNonce(self._account.address).call()
        except Exception as err:
            raise map_chain_error(err) from err
        return sign_delegated_attestation(
            private_key=self._account.key.hex(),
            network=self.network,
            attester=self._account.address,
            schema_uid=schema_uid,
            encoded_data=encoded_data,
            nonce=int(nonce),
            deadline=deadline,
        )

    def resolve_ens(self, address: str) -> VerifiedENS | None:
        if self._ens_w3 is None:
            raise FidemarkError(
                "INVALID_INPUT",
                "Construct Fidemark with `ens_provider_url` (Ethereum mainnet) to use ENS lookups.",
            )
        return resolve_verified_ens(self._ens_w3, address)

    def attest_human_with_ens(self, input: AttestHumanInput) -> tuple[AttestResult, VerifiedENS]:
        if self._ens_w3 is None:
            raise FidemarkError(
                "INVALID_INPUT",
                "Construct Fidemark with `ens_provider_url` to use attest_human_with_ens.",
            )
        ens = resolve_verified_ens(self._ens_w3, self.address)
        if ens is None:
            raise FidemarkError(
                "INVALID_INPUT",
                f"Wallet {self.address} has no verifiable ENS name. "
                "Reverse + forward resolution must round-trip to use the ens-verified trust layer.",
            )
        result = self.attest_human(
            AttestHumanInput(
                content=input.content,
                content_type=input.content_type,
                creator=input.creator,
                created_at=input.created_at,
                proof_method="ens-verified",
                ref_uid=input.ref_uid,
            )
        )
        return result, ens

    def _attest(self, schema_uid: str, encoded_data: bytes, ref_uid: str | None) -> AttestResult:
        if self._account is None:
            raise FidemarkError("INVALID_INPUT", "Attest requires a signer.")
        request = (
            _to_bytes32(schema_uid),
            (
                ZERO_ADDRESS,
                0,
                True,
                _to_bytes32(ref_uid or ZERO_BYTES32),
                encoded_data,
                0,
            ),
        )
        receipt = self._send_tx(self.eas.functions.attest(request))
        uids = self._uids_from_receipt(receipt)
        if not uids:
            raise FidemarkError("RPC_ERROR", "attest receipt had no Attested log.")
        uid = uids[0]
        return AttestResult(
            uid=uid,
            tx_hash="0x" + receipt["transactionHash"].hex(),
            verify_url=self.verify_url_for(uid),
        )

    def _attest_data(self, data: bytes, ref_uid: str | None) -> dict[str, Any]:
        return {
            "recipient": ZERO_ADDRESS,
            "expirationTime": 0,
            "revocable": True,
            "refUID": _to_bytes32(ref_uid or ZERO_BYTES32),
            "data": data,
            "value": 0,
        }

    def _tuples_for_multi(self, requests: list[dict[str, Any]]) -> list[tuple[Any, ...]]:
        return [
            (
                _to_bytes32(req["schema"]),
                [
                    (
                        d["recipient"],
                        d["expirationTime"],
                        d["revocable"],
                        d["refUID"],
                        d["data"],
                        d["value"],
                    )
                    for d in req["data"]
                ],
            )
            for req in requests
        ]

    def _send_tx(self, fn: Any) -> TxReceipt:
        if self._account is None:
            raise FidemarkError("INVALID_INPUT", "Cannot send tx, no signer configured.")
        try:
            tx = fn.build_transaction(
                {
                    "from": self._account.address,
                    "nonce": self.w3.eth.get_transaction_count(self._account.address, "pending"),
                    "value": 0,
                    "chainId": self.network.chain_id,
                }
            )
            signed = self._account.sign_transaction(tx)
            tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
            return self.w3.eth.wait_for_transaction_receipt(tx_hash)
        except Exception as err:
            raise map_chain_error(err) from err

    def _uids_from_receipt(self, receipt: TxReceipt) -> list[str]:
        uids: list[str] = []
        for log in receipt["logs"]:
            try:
                event = self.eas.events.Attested().process_log(log)
            except Exception:
                continue
            uids.append("0x" + event["args"]["uid"].hex())
        return uids

    def _decode_attestation(
        self,
        *,
        uid: str,
        schema_uid: str,
        time_unix: int,
        revocation_time: int,
        ref_uid: str,
        recipient: str,
        attester: str,
        data: bytes,
    ) -> FidemarkAttestation:
        type_: FidemarkSchemaType
        if schema_uid == self.network.schemas.human:
            type_ = "human"
        elif schema_uid == self.network.schemas.ai:
            type_ = "ai"
        elif self.network.schemas.multi and schema_uid == self.network.schemas.multi:
            type_ = "multi"
        elif self.network.schemas.pop and schema_uid == self.network.schemas.pop:
            type_ = "pop"
        else:
            known = self.network.schemas
            expected = ", ".join(
                part
                for part in (
                    f"human={known.human}",
                    f"ai={known.ai}",
                    f"multi={known.multi}" if known.multi else None,
                    f"pop={known.pop}" if known.pop else None,
                )
                if part
            )
            raise FidemarkError(
                "UNKNOWN_SCHEMA",
                f'Attestation {uid} references schema {schema_uid}, '
                f'which is not registered on network "{self.network.name}". '
                f"Expected one of [{expected}]. Common cause: the local devnet "
                "was rebootstrapped after this attestation was issued.",
            )

        base = FidemarkAttestation(
            uid=uid,
            type=type_,
            schema_uid=schema_uid,
            attester=attester,
            recipient=recipient,
            content_hash=ZERO_BYTES32,
            created_at=time_unix,
            revoked=revocation_time > 0,
            revoked_at=revocation_time if revocation_time > 0 else None,
            ref_uid=ref_uid,
            verify_url=self.verify_url_for(uid),
        )

        if type_ == "human":
            decoded = decode_schema_data(HUMAN_FIELDS, data)
            base.content_hash = "0x" + decoded["contentHash"].hex()
            base.human = HumanFields(
                content_type=decoded["contentType"],
                creator=decoded["creator"],
                proof_method=decoded["proofMethod"],
                created_at_attested=int(decoded["createdAt"]),
            )
            return base

        if type_ == "ai":
            decoded = decode_schema_data(AI_FIELDS, data)
            base.content_hash = "0x" + decoded["contentHash"].hex()
            base.ai = AIFields(
                model_id=decoded["modelId"],
                provider=decoded["provider"],
                prompt_hash="0x" + decoded["promptHash"].hex(),
                parameters=decoded["parameters"],
            )
            return base

        if type_ == "multi":
            decoded = decode_schema_data(MULTI_FIELDS, data)
            base.content_hash = "0x" + decoded["contentHash"].hex()
            base.multi = MultiFields(
                content_type=decoded["contentType"],
                attesters=list(decoded["attesters"]),
                signatures=["0x" + s.hex() for s in decoded["signatures"]],
                proof_method=decoded["proofMethod"],
                created_at_attested=int(decoded["createdAt"]),
            )
            return base

        decoded = decode_schema_data(POP_FIELDS, data)
        base.content_hash = "0x" + decoded["contentHash"].hex()
        base.pop = PoPFields(
            content_type=decoded["contentType"],
            creator=decoded["creator"],
            proof_method=decoded["proofMethod"],
            created_at_attested=int(decoded["createdAt"]),
            root=str(decoded["root"]),
            nullifier_hash=str(decoded["nullifierHash"]),
            proof=[str(p) for p in decoded["proof"]],
        )
        return base


def _to_bytes32(value: str) -> bytes:
    s = value.lower()
    if not s.startswith("0x") or len(s) != 66:
        raise FidemarkError(
            "INVALID_INPUT",
            f"Expected 0x-prefixed 32-byte hex, got {value!r}",
        )
    return bytes.fromhex(s[2:])


def _normalize_bytes32(value: str, field_name: str) -> str:
    s = value.lower()
    if not s.startswith("0x") or len(s) != 66:
        raise FidemarkError(
            "INVALID_INPUT",
            f"{field_name} must be 0x-prefixed 32 bytes hex, got {value}",
        )
    return s
