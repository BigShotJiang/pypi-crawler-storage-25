"""ENS-verified trust layer (Layer 1).

ENS lives on Ethereum mainnet, not Base, so this module needs its own
provider pointed at an Ethereum mainnet RPC, separate from the Fidemark
client's main provider.

Verification rule: a wallet's ENS name is "verified" iff
  1. The wallet has a reverse record (`address -> name`).
  2. Forward resolution of that name (`name -> address`) matches the wallet.

This guards against spoofed reverse records: anyone can set their reverse
to "vitalik.eth", but only the actual ENS owner controls forward resolution.
"""
from __future__ import annotations

from dataclasses import dataclass

from web3 import Web3

from fidemark.errors import FidemarkError


@dataclass
class VerifiedENS:
    name: str
    address: str


def resolve_verified_ens(ens_provider: Web3, address: str) -> VerifiedENS | None:
    """Round-trip resolve an address through ENS reverse + forward lookup.

    Returns ``None`` when the wallet has no ENS, the reverse record is missing,
    or the forward resolution disagrees with the input address (spoofed).
    """
    try:
        name = ens_provider.ens.name(address)  # type: ignore[union-attr]
    except Exception as err:
        raise FidemarkError(
            "RPC_ERROR",
            f"ENS lookup failed for {address}. Is the ens_provider pointed at Ethereum mainnet?",
            err,
        ) from err
    if not name:
        return None

    try:
        resolved = ens_provider.ens.address(name)  # type: ignore[union-attr]
    except Exception as err:
        raise FidemarkError("RPC_ERROR", f"ENS forward resolution failed for {name}.", err) from err

    if not resolved:
        return None
    if resolved.lower() != address.lower():
        return None

    return VerifiedENS(name=name, address=address)
