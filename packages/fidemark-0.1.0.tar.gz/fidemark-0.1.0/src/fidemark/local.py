"""Deployment artifact loader.

Resolves the per-network artifact in this order:
  1. ``explicit_path`` argument.
  2. ``$FIDEMARK_DEPLOYMENT`` env var (single path, applies to whichever
     network it names).
  3. Package-local ``fidemark/deployments/<name>.json`` (bundled with the
     published wheel).
  4. Monorepo ``sources/contracts/deployments/<name>.json``, by walking up
     from the current working directory (kept for in-monorepo development;
     absent from a regular ``pip install fidemark`` install).

Local devnet artifacts are only written by ``npm run dev:chain`` inside the
monorepo, are intentionally not bundled into the published wheel, and are
loaded via the monorepo fallback.
"""
from __future__ import annotations

import json
import os
from importlib import resources
from pathlib import Path

from fidemark.networks import (
    NetworkConfig,
    NetworkContracts,
    NetworkSchemas,
    WorldIdConfig,
    register_network,
)


def load_local_network(explicit_path: str | None = None) -> NetworkConfig:
    """Load `local.json` and register it as the `local` network. Maintainer-only.

    End users targeting a public network (`base-sepolia`, `base`) should
    call ``get_network(name)`` instead, which transparently lazy-loads the
    bundled artifact.
    """
    return load_deployment_artifact("local", explicit_path)


def load_deployment_artifact(
    name: str,
    explicit_path: str | None = None,
) -> NetworkConfig:
    """Load any deployment artifact by network name."""
    path = _resolve_artifact_path(name, explicit_path)
    raw = json.loads(path.read_text(encoding="utf-8"))

    contracts_raw = raw["contracts"]
    schemas_raw = raw["schemas"]
    contracts = NetworkContracts(
        eas=contracts_raw["eas"],
        schema_registry=contracts_raw["schemaRegistry"],
        resolver=contracts_raw["resolver"],
        multi_resolver=contracts_raw.get("multiResolver"),
        pop_resolver=contracts_raw.get("popResolver"),
        world_id_verifier=contracts_raw.get("worldIdVerifier"),
    )
    schemas = NetworkSchemas(
        human=schemas_raw["human"]["uid"],
        ai=schemas_raw["ai"]["uid"],
        multi=schemas_raw.get("multi", {}).get("uid") if "multi" in schemas_raw else None,
        pop=schemas_raw.get("pop", {}).get("uid") if "pop" in schemas_raw else None,
    )
    world_id = None
    if "worldId" in raw and raw["worldId"]:
        world_id = WorldIdConfig(
            app_id=raw["worldId"]["appId"],
            group_id=raw["worldId"]["groupId"],
            is_mock=raw["worldId"].get("isMock", False),
        )

    config = NetworkConfig(
        name=name,
        chain_id=raw["chainId"],
        rpc_url=raw["rpcUrl"],
        deploy_block=raw.get("deployBlock"),
        contracts=contracts,
        schemas=schemas,
        world_id=world_id,
    )
    register_network(name, config)
    return config


def _resolve_artifact_path(name: str, explicit_path: str | None) -> Path:
    # Explicit caller intent wins. If you passed a path or set the env var,
    # we respect it: no silent fallback to a different file. Only when the
    # caller didn't specify do we auto-resolve from package-local /
    # monorepo locations.
    if explicit_path:
        path = Path(explicit_path)
        if path.is_file():
            return path
        raise FileNotFoundError(
            f'Deployment artifact for "{name}" not found at {path}. '
            "Check the path you passed."
        )
    env_path_str = os.environ.get("FIDEMARK_DEPLOYMENT")
    if env_path_str:
        env_path = Path(env_path_str)
        if env_path.is_file():
            return env_path
        raise FileNotFoundError(
            f'Deployment artifact for "{name}" not found at {env_path} '
            "(from $FIDEMARK_DEPLOYMENT). Check the path."
        )

    for candidate in (_package_local_path(name), _monorepo_path(name)):
        if candidate is not None and candidate.is_file():
            return candidate

    if name == "local":
        hint = "Run `npm run dev:chain` in sources/contracts first."
    else:
        hint = (
            f'Network "{name}" has not been deployed yet, or this version of '
            "fidemark was published before that network went live."
        )
    raise FileNotFoundError(
        f'Deployment artifact for "{name}" not found in any known location. {hint}'
    )


def _package_local_path(name: str) -> Path | None:
    """Return the path to ``fidemark/deployments/<name>.json`` shipped in the
    installed wheel, or None when no such file is included.

    ``importlib.resources.files`` returns a path-like for the package's
    install location, which works whether the user did `pip install fidemark`
    or `pip install -e ./sources/sdk/python`.
    """
    try:
        root = resources.files("fidemark") / "deployments"
        candidate = root / f"{name}.json"
        return Path(str(candidate))
    except (ModuleNotFoundError, FileNotFoundError):
        return None


def _monorepo_path(name: str) -> Path:
    """Walk up from cwd looking for ``sources/contracts/deployments/<name>.json``.

    Only meaningful inside the monorepo; for an installed wheel the walk-up
    will simply find nothing and the caller falls through to the not-found
    branch.
    """
    cwd = Path.cwd()
    for _ in range(6):
        candidate = cwd / "sources" / "contracts" / "deployments" / f"{name}.json"
        if candidate.is_file():
            return candidate
        if cwd.parent == cwd:
            break
        cwd = cwd.parent
    return Path.cwd() / "sources" / "contracts" / "deployments" / f"{name}.json"
