"""Multi-party co-attestation (Layer 2).

N independent attesters each sign the same EIP-712 claim over a content
hash. A coordinator collects the signed slips and submits ONE on-chain
attestation containing all of them; FidemarkMultiResolver atomically
recovers each signature and validates it against the declared attesters.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Final

from eth_account import Account
from eth_account.messages import encode_typed_data
from eth_utils import keccak

from fidemark.errors import FidemarkError
from fidemark.hashing import hash_content
from fidemark.networks import NetworkConfig

MULTI_PARTY_DOMAIN_NAME: Final = "Fidemark MultiParty"
MULTI_PARTY_DOMAIN_VERSION: Final = "1"

MULTI_PARTY_TYPES: Final = {
    "MultiPartyClaim": [
        {"name": "contentHash", "type": "bytes32"},
        {"name": "contentType", "type": "string"},
        {"name": "createdAt", "type": "uint64"},
        {"name": "attesters", "type": "address[]"},
    ],
}


@dataclass
class MultiPartyClaim:
    """The exact payload every co-signer signs.

    The `attesters` list is part of the signed payload, so a slip cannot be
    lifted into an attestation grouping the same content with a different
    co-signer set. Coordinator + co-signers must agree on the full ordered
    set up front. The on-chain `attesters[i]` must equal the recovered
    signer for slip `i`.
    """

    content_hash: str
    content_type: str
    created_at: int
    attesters: list[str]


@dataclass
class MultiPartySlip:
    """One co-signer's contribution: address + 65-byte signature."""

    signer: str
    signature: str


def build_multi_party_claim(
    *,
    content: str | bytes,
    content_type: str,
    attesters: list[str],
    created_at: int | None = None,
) -> MultiPartyClaim:
    """Helper: derive a normalized claim from raw content + a coordinator-chosen timestamp.

    All co-signers must produce a slip from the SAME claim object, including the
    same `attesters` list in the same order.
    """
    return MultiPartyClaim(
        content_hash=hash_content(content),
        content_type=content_type,
        created_at=created_at if created_at is not None else int(time.time()),
        attesters=list(attesters),
    )


def _require_multi_resolver(network: NetworkConfig) -> str:
    addr = network.contracts.multi_resolver
    if not addr:
        raise FidemarkError(
            "INVALID_INPUT",
            f"Network {network.name} has no multiResolver address. Multi-party attestation is unavailable.",
        )
    return addr


def _build_typed_data(claim: MultiPartyClaim, network: NetworkConfig) -> dict[str, Any]:
    return {
        "domain": {
            "name": MULTI_PARTY_DOMAIN_NAME,
            "version": MULTI_PARTY_DOMAIN_VERSION,
            "chainId": network.chain_id,
            "verifyingContract": _require_multi_resolver(network),
        },
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
            **MULTI_PARTY_TYPES,
        },
        "primaryType": "MultiPartyClaim",
        "message": {
            "contentHash": claim.content_hash,
            "contentType": claim.content_type,
            "createdAt": claim.created_at,
            "attesters": list(claim.attesters),
        },
    }


def multi_party_claim_digest(claim: MultiPartyClaim, network: NetworkConfig) -> str:
    """Compute the EIP-712 digest a co-signer must sign."""
    msg = encode_typed_data(full_message=_build_typed_data(claim, network))
    digest = keccak(b"\x19\x01" + msg.header + msg.body)
    return "0x" + digest.hex()


def sign_multi_party_claim(
    private_key: str,
    claim: MultiPartyClaim,
    network: NetworkConfig,
) -> MultiPartySlip:
    """Sign one co-signer's slip. The result can be sent over any transport.

    The slip is bound to the chainId + multi-resolver address baked into the
    EIP-712 domain; if either changes (e.g. a new resolver deploy), old slips
    become invalid by design.
    """
    signable = encode_typed_data(full_message=_build_typed_data(claim, network))
    account = Account.from_key(private_key)
    signed = Account.sign_message(signable, private_key=account.key)
    return MultiPartySlip(signer=account.address, signature=signed.signature.hex())
