"""Stable typed error surface for the Python SDK.

Mirrors @fidemark/sdk's FidemarkError with the same `code` taxonomy so
applications that branch on error codes behave identically across languages.
"""
from __future__ import annotations

import json
import re
from typing import Any, Final, Literal

FidemarkErrorCode = Literal[
    "NETWORK_NOT_DEPLOYED",
    "INVALID_INPUT",
    "ATTESTATION_NOT_FOUND",
    "ATTESTATION_REVOKED",
    "UNKNOWN_SCHEMA",
    "INSUFFICIENT_FUNDS",
    "VALIDATION_REJECTED",
    "USER_REJECTED",
    "RPC_ERROR",
    "NOT_YET_IMPLEMENTED",
    "UNKNOWN",
]

_REVERT_RE: Final = re.compile(r"execution reverted|reverted|could not coalesce", re.I)


class FidemarkError(Exception):
    """Wraps every SDK failure with a stable code so callers can branch on it."""

    def __init__(self, code: FidemarkErrorCode, message: str, cause: Any = None) -> None:
        super().__init__(message)
        self.code: FidemarkErrorCode = code
        self.cause = cause

    def __repr__(self) -> str:
        return f"FidemarkError(code={self.code!r}, message={str(self)!r})"


def _safe_stringify(value: Any) -> str:
    if value is None:
        return ""
    try:
        return json.dumps(value, default=str)
    except TypeError:
        return str(value)


def map_chain_error(err: BaseException) -> FidemarkError:
    """Convert a web3 / contract error into a FidemarkError with a useful code."""
    reason = getattr(err, "message", None) or str(err) or "unknown chain error"

    code = getattr(err, "code", None)
    if code == "ACTION_REJECTED":
        return FidemarkError("USER_REJECTED", "User rejected the transaction.", err)
    if code == "INSUFFICIENT_FUNDS":
        return FidemarkError("INSUFFICIENT_FUNDS", "Insufficient funds for gas on this network.", err)

    haystack = " ".join(
        s
        for s in (
            reason,
            _safe_stringify(getattr(err, "data", None)),
            _safe_stringify(getattr(err, "args", None)),
        )
        if s
    )

    matches: list[tuple[str, FidemarkErrorCode, str]] = [
        ("EmptyContentHash", "VALIDATION_REJECTED", "Content hash cannot be zero."),
        ("EmptyField", "VALIDATION_REJECTED", "A required attestation field was empty."),
        (
            "FieldTooLong",
            "VALIDATION_REJECTED",
            "A string field exceeded the resolver's length bound (proofMethod <= 64, contentType <= 128).",
        ),
        (
            "EnforcedPause",
            "VALIDATION_REJECTED",
            "The resolver is paused. Attestations are temporarily disabled by the resolver owner.",
        ),
        ("CreatorMismatch", "VALIDATION_REJECTED", "Human Proof creator must match the signing wallet."),
        ("UnknownProofMethod", "VALIDATION_REJECTED", "proofMethod is not on the resolver allowlist."),
        ("UnknownSchema", "VALIDATION_REJECTED", "The resolver does not recognize this schema. Wrong network?"),
        (
            "TimestampTooFarInFuture",
            "VALIDATION_REJECTED",
            "createdAt is too far in the future. Check your client clock.",
        ),
        (
            "NullifierAlreadyUsed",
            "VALIDATION_REJECTED",
            "This World ID nullifier has already attested this content.",
        ),
        ("InvalidProof", "VALIDATION_REJECTED", "World ID proof verification failed."),
        (
            "WorldIdNotConfigured",
            "VALIDATION_REJECTED",
            "PoP resolver has no World ID verifier or app id configured.",
        ),
        (
            "InvalidSignature",
            "VALIDATION_REJECTED",
            "Multi-party signature did not recover to the declared attester.",
        ),
        ("DuplicateAttester", "VALIDATION_REJECTED", "Duplicate attester address in multi-party slips."),
    ]
    for needle, error_code, message in matches:
        if needle in haystack:
            return FidemarkError(error_code, message, err)

    if any(n in haystack for n in ("AttesterCountMismatch", "TooFewAttesters", "TooManyAttesters")):
        return FidemarkError(
            "VALIDATION_REJECTED",
            "Multi-party attester / signature count is invalid.",
            err,
        )

    if _REVERT_RE.search(haystack):
        return FidemarkError(
            "VALIDATION_REJECTED",
            f"Resolver rejected the attestation: {reason}",
            err,
        )

    return FidemarkError("RPC_ERROR", reason, err)
