"""Proof-of-personhood (Layer 4) helpers.

Mirrors World ID's hash-to-field conventions so frontends and on-chain
resolvers compute identical signal / externalNullifier values.

Domain (matches `FidemarkPoPResolver`):
  - action     = `f1{first28HexCharsOfContentHash}` (30 chars, alphanumeric only)
  - signal     = lowercase string ``"0x<contentHash_hex>:0x<attester_hex>"``
                 (109 chars) -> hash_to_field
  - extNul     = hash_to_field(hash_to_field(appId) || action)
                 (two-pass per Worldcoin's official template)
  - hash_to_field(x) = uint256(keccak256(x)) >> 8
"""
from __future__ import annotations

from dataclasses import dataclass

from eth_utils import keccak, to_bytes

from fidemark.errors import FidemarkError


@dataclass
class WorldIdProof:
    """A World ID Orb-verified zk-proof produced by IDKit."""

    root: int | str
    nullifier_hash: int | str
    proof: tuple[int | str, int | str, int | str, int | str, int | str, int | str, int | str, int | str]


def hash_to_field(input_bytes: bytes) -> int:
    """World ID's hash-to-field reduction: keccak256(input) >> 8 (BN254 field-fit)."""
    return int.from_bytes(keccak(input_bytes), "big") >> 8


def action_for_content(content_hash: str) -> str:
    """Canonical Worldcoin action string for a Fidemark attestation of `content_hash`.

    Format: ``f1{first28HexCharsOfContentHash}`` (30 chars total, alphanumeric only).
    Worldcoin's Developer Portal caps identifiers at 32 chars and strips
    non-alphanumeric characters; the prefix + 28 hex chars (= 14 bytes = 112
    bits of entropy) keeps action strings safely inside that bound.
    """
    lower = content_hash.lower()
    hexpart = lower[2:] if lower.startswith("0x") else lower
    return f"f1{hexpart[:28]}"


def external_nullifier_for(app_id: str, content_hash: str) -> int:
    """Match `FidemarkPoPResolver.externalNullifierFor` (two-pass).

    ``hash_to_field(hash_to_field(appId) || action)`` per Worldcoin's official
    on-chain template. ``abi.encodePacked(uint256, string)`` = 32-byte uint256
    in big-endian followed by the UTF-8 bytes of the action string.
    """
    action = action_for_content(content_hash)
    app_id_hash = hash_to_field(app_id.encode("utf-8"))
    packed = app_id_hash.to_bytes(32, "big") + action.encode("utf-8")
    return hash_to_field(packed)


def signal_string_for(content_hash: str, attester: str) -> str:
    """Canonical signal STRING the dapp must pass to IDKit's ``orbLegacy({ signal })``.

    Returns the lowercase ``"0x<contentHash_hex>:0x<attester_hex>"`` (135 chars).
    """
    h = to_bytes(hexstr=content_hash)
    if len(h) != 32:
        raise FidemarkError(
            "INVALID_INPUT",
            f"contentHash must be 0x-prefixed 32 bytes hex; got {content_hash}",
        )
    addr = to_bytes(hexstr=attester)
    if len(addr) != 20:
        raise FidemarkError("INVALID_INPUT", f"attester must be a 20-byte address; got {attester}")
    return f"0x{h.hex()}:0x{addr.hex()}"


def signal_hash_for(content_hash: str, attester: str) -> int:
    """Match `FidemarkPoPResolver.signalHashFor` (UTF-8 string of canonical signal)."""
    return hash_to_field(signal_string_for(content_hash, attester).encode("utf-8"))


def normalize_world_id_proof(proof: WorldIdProof) -> dict[str, object]:
    """Normalize a World ID proof into bigint-equivalent fields the SDK consumes."""

    def _to_int(v: int | str) -> int:
        if isinstance(v, int):
            return v
        if v.startswith("0x") or v.startswith("0X"):
            return int(v, 16)
        return int(v)

    return {
        "root": _to_int(proof.root),
        "nullifier_hash": _to_int(proof.nullifier_hash),
        "proof": tuple(_to_int(p) for p in proof.proof),
    }
