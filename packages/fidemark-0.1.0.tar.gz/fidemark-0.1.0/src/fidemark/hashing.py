"""Canonical content + prompt hashing.

Both helpers return a 0x-prefixed lowercase 32-byte hex string suitable for
the on-chain `bytes32 contentHash` and `bytes32 promptHash` schema fields.
"""
from __future__ import annotations

import hashlib
import re

_HEX32_RE = re.compile(r"^0x[0-9a-fA-F]{64}$")


def hash_content(data: str | bytes) -> str:
    """SHA-256 of the input. UTF-8 encodes strings before hashing."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return "0x" + hashlib.sha256(data).hexdigest()


def hash_prompt(data: str | bytes) -> str:
    """Same shape as `hash_content`, but passes through a pre-computed digest.

    Useful when callers hashed the prompt off-band (e.g. enterprise pipelines
    that never expose plaintext upstream).
    """
    if isinstance(data, str) and _HEX32_RE.match(data):
        return data.lower()
    return hash_content(data)
