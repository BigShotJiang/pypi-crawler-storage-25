"""Known Fidemark network registry.

Keeps RPC + EAS predeploy info per chain. Resolver and schema UIDs come
from per-network deployment artifacts bundled with the package (see
``local.py``). ``get_network(name)`` lazy-loads the bundled artifact on
first call so applications outside the monorepo only have to write
``Fidemark(network=get_network("base-sepolia"))``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Literal

# EAS predeploy addresses on the OP Stack (Base + Base Sepolia).
OP_STACK_EAS: Final = "0x4200000000000000000000000000000000000021"
OP_STACK_SCHEMA_REGISTRY: Final = "0x4200000000000000000000000000000000000020"

# Public networks consumers can target. ``local`` is a maintainer-only name
# and is registered at runtime by ``load_local_network()``; it is intentionally
# absent from the public Literal so end users can't accidentally point a
# published install at it.
NetworkName = Literal["base-sepolia", "base"]


@dataclass
class NetworkContracts:
    eas: str
    schema_registry: str
    resolver: str
    multi_resolver: str | None = None
    pop_resolver: str | None = None
    world_id_verifier: str | None = None


@dataclass
class NetworkSchemas:
    human: str
    ai: str
    multi: str | None = None
    pop: str | None = None


@dataclass
class WorldIdConfig:
    app_id: str
    group_id: int
    is_mock: bool = False


@dataclass
class NetworkConfig:
    name: str
    chain_id: int
    rpc_url: str
    contracts: NetworkContracts
    schemas: NetworkSchemas
    deploy_block: int | None = None
    world_id: WorldIdConfig | None = None


_REGISTRY: dict[str, NetworkConfig] = {
    "base-sepolia": NetworkConfig(
        name="base-sepolia",
        chain_id=84532,
        rpc_url="https://sepolia.base.org",
        contracts=NetworkContracts(
            eas=OP_STACK_EAS,
            schema_registry=OP_STACK_SCHEMA_REGISTRY,
            resolver="",
        ),
        schemas=NetworkSchemas(human="", ai=""),
    ),
    "base": NetworkConfig(
        name="base",
        chain_id=8453,
        rpc_url="https://mainnet.base.org",
        contracts=NetworkContracts(
            eas=OP_STACK_EAS,
            schema_registry=OP_STACK_SCHEMA_REGISTRY,
            resolver="",
        ),
        schemas=NetworkSchemas(human="", ai=""),
    ),
}


def _is_undeployed(cfg: NetworkConfig) -> bool:
    return not cfg.contracts.resolver or not cfg.schemas.human or not cfg.schemas.ai


def get_network(name: NetworkName) -> NetworkConfig:
    """Look up a network by name; lazy-loads the bundled artifact if needed."""
    cfg = _REGISTRY.get(name)
    if cfg is None:
        known = ", ".join(_REGISTRY.keys())
        raise ValueError(f"Unknown network: {name}. Known: {known}")

    if _is_undeployed(cfg):
        # Defer the import to break the circular dependency between
        # networks.py and local.py.
        from fidemark.local import load_deployment_artifact

        try:
            return load_deployment_artifact(name)
        except FileNotFoundError as err:
            raise ValueError(
                f"Network {name} is not yet deployed in this build of fidemark. "
                f"Try upgrading the package, or call "
                f"`load_deployment_artifact('{name}', '/path/to/artifact.json')` "
                f"manually. Underlying cause: {err}"
            ) from err
    return cfg


def register_network(name: str, config: NetworkConfig) -> None:
    """Inject a deployed network. Used by the artifact loader and tests."""
    _REGISTRY[name] = config
