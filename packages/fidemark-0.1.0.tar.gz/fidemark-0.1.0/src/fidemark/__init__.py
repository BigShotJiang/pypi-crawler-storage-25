"""Fidemark Protocol Python SDK.

Mirrors the TypeScript surface in @fidemark/sdk. Names use snake_case.
"""
from fidemark.client import (
    AttestAIInput,
    AttestHumanInput,
    AttestHumanWithPoPInput,
    AttestMultiPartyInput,
    AttestResult,
    BatchAIItem,
    BatchHumanItem,
    BatchResult,
    Fidemark,
    FidemarkAttestation,
    VerifyByHashOptions,
)
from fidemark.ens import VerifiedENS, resolve_verified_ens
from fidemark.errors import FidemarkError, FidemarkErrorCode, map_chain_error
from fidemark.hashing import hash_content, hash_prompt
from fidemark.indexer import (
    DefaultGraphqlClient,
    GraphqlAttestation,
    GraphqlClient,
    IndexerMode,
    default_client as default_indexer_client,
    indexer_verify_by_hash,
)
from fidemark.local import load_deployment_artifact, load_local_network
from fidemark.multi import (
    MULTI_PARTY_DOMAIN_NAME,
    MULTI_PARTY_DOMAIN_VERSION,
    MULTI_PARTY_TYPES,
    MultiPartyClaim,
    MultiPartySlip,
    build_multi_party_claim,
    multi_party_claim_digest,
    sign_multi_party_claim,
)
from fidemark.networks import (
    NetworkConfig,
    NetworkName,
    get_network,
    register_network,
)
from fidemark.offchain import (
    DelegatedSignaturePayload,
    OffchainEnvelope,
    OffchainSignOptions,
    decode_offchain,
    sign_ai_offchain,
    sign_human_offchain,
    verify_offchain,
)
from fidemark.pop import (
    WorldIdProof,
    action_for_content,
    external_nullifier_for,
    hash_to_field,
    normalize_world_id_proof,
    signal_hash_for,
    signal_string_for,
)

__all__ = [
    "AttestAIInput",
    "AttestHumanInput",
    "AttestHumanWithPoPInput",
    "AttestMultiPartyInput",
    "AttestResult",
    "BatchAIItem",
    "BatchHumanItem",
    "BatchResult",
    "DefaultGraphqlClient",
    "DelegatedSignaturePayload",
    "Fidemark",
    "FidemarkAttestation",
    "FidemarkError",
    "FidemarkErrorCode",
    "GraphqlAttestation",
    "GraphqlClient",
    "IndexerMode",
    "MULTI_PARTY_DOMAIN_NAME",
    "MULTI_PARTY_DOMAIN_VERSION",
    "MULTI_PARTY_TYPES",
    "MultiPartyClaim",
    "MultiPartySlip",
    "NetworkConfig",
    "NetworkName",
    "OffchainEnvelope",
    "OffchainSignOptions",
    "VerifiedENS",
    "VerifyByHashOptions",
    "WorldIdProof",
    "action_for_content",
    "build_multi_party_claim",
    "decode_offchain",
    "default_indexer_client",
    "external_nullifier_for",
    "get_network",
    "hash_content",
    "indexer_verify_by_hash",
    "hash_prompt",
    "hash_to_field",
    "load_deployment_artifact",
    "load_local_network",
    "map_chain_error",
    "multi_party_claim_digest",
    "normalize_world_id_proof",
    "register_network",
    "resolve_verified_ens",
    "sign_ai_offchain",
    "sign_human_offchain",
    "sign_multi_party_claim",
    "signal_hash_for",
    "signal_string_for",
    "verify_offchain",
]
