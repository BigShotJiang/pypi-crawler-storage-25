# fidemark

> *Prove it's real. Prove it's AI. Prove it on-chain.*

Official Python SDK for **Fidemark**, a permissionless, tokenless content-provenance protocol built on
[Ethereum Attestation Service](https://attest.org) on **Base** (L2). Use it to attest human authorship or
AI-generated output, verify those attestations on chain, and walk provenance chains.

- Two complementary attestation flows on one EAS foundation: **Human Proof** and **AI Proof**.
- Permissionless, no allowlist, no consortium, no protocol token.
- Verifiable without trust: every attestation is a public on-chain record.
- Deployed network addresses + schema UIDs ship inside the wheel, so `get_network("base-sepolia")` just works.

## Install

```bash
pip install fidemark
```

Requires Python 3.11 or newer. Server-side only.

## Quickstart

```python
import os
from fidemark import AttestHumanInput, Fidemark, get_network, hash_content

fidemark = Fidemark(
    network=get_network("base-sepolia"),     # or "base"
    private_key=os.environ["PRIVATE_KEY"],
)

# 1. Attest authored content
result = fidemark.attest_human(AttestHumanInput(
    content="An essay I wrote myself.",
    content_type="text/article",
))
print(result.verify_url)                     # https://verify.fidemark.dev/0x...

# 2. Verify any attestation by UID, no signer required
att = fidemark.verify(result.uid)
print(att.attester, att.content_hash)

# 3. Find every attestation on a piece of content
matches = fidemark.verify_by_hash(hash_content(my_article))
```

A standalone read-only client (no `private_key`) is enough for verification:

```python
reader = Fidemark(network=get_network("base"))
att = reader.verify(uid)
```

## What you can do

| Capability                                | Method                                                                  |
| ----------------------------------------- | ----------------------------------------------------------------------- |
| Attest authored content                   | `attest_human(AttestHumanInput(...))`                                   |
| Attest AI output (model + prompt hash)    | `attest_ai(AttestAIInput(...))`                                         |
| ENS-verified Human Proof                  | `attest_human_with_ens(AttestHumanInput(...))`                          |
| Multi-party (N-of-N) co-attestation       | `attest_multi_party(AttestMultiPartyInput(...))`                        |
| Verified-human (Worldcoin PoP)            | `attest_human_with_pop(AttestHumanWithPoPInput(...))`                   |
| Off-chain EIP-712 envelopes (zero gas)    | `attest_human_offchain`, `attest_ai_offchain`, `verify_offchain`        |
| Bring an off-chain envelope on-chain      | `publish_offchain(envelope)` (anyone with funds can publish)            |
| Verify a UID                              | `verify(uid)`                                                           |
| Find every attestation on a content hash  | `verify_by_hash(content_hash)`                                          |
| Walk a provenance chain                   | `verify_chain(uid)`                                                     |
| Revoke (only the original attester)       | `revoke(uid)`                                                           |
| Inspect without raising                   | `inspect(uid)` returns `{"ok": True, "attestation"}` or `{"ok": False, "reason"}` |

Trust layers (`proof_method`) supported today: `wallet-signed` (L0), `ens-verified` (L1), `multi-party` (L2),
`pop-verified-worldid` (L4). See [Trust layers](https://docs.fidemark.dev/concepts/trust-layers/) for the full design.

## Networks

| Network        | Argument                          | Notes                       |
| -------------- | --------------------------------- | --------------------------- |
| Base Sepolia   | `get_network("base-sepolia")`     | testnet (chainId 84532)     |
| Base mainnet   | `get_network("base")`             | (chainId 8453)              |

The published wheel bundles each network's deployment artifact (resolver address + schema UIDs) inside
`fidemark/deployments/`. If you call `get_network(name)` against a network this version of `fidemark`
predates, the call raises `NETWORK_NOT_DEPLOYED`. Upgrade the package or wait for the next release.

## Errors

Every failure surfaces a `FidemarkError` with a stable `code` string so you can branch on it without
parsing messages:

```python
from fidemark import FidemarkError

try:
    fidemark.revoke(uid)
except FidemarkError as err:
    if err.code == "VALIDATION_REJECTED":
        # Only the original attester can revoke.
        ...
```

Codes: `INVALID_INPUT`, `NETWORK_NOT_DEPLOYED`, `ATTESTATION_NOT_FOUND`, `ATTESTATION_REVOKED`,
`UNKNOWN_SCHEMA`, `INSUFFICIENT_FUNDS`, `VALIDATION_REJECTED`, `USER_REJECTED`, `RPC_ERROR`,
`NOT_YET_IMPLEMENTED`, `UNKNOWN`.

## Configuration

```python
Fidemark(
    network,                # required: NetworkConfig
    private_key=...,        # for write ops
    provider_url=...,       # override the default Base RPC
    ens_provider_url=...,   # Ethereum mainnet RPC for ENS-verified attestations
    verify_url_base=...,    # override the verify-URL host (default: https://verify.fidemark.dev)
    indexer=...,            # "events" (default), "graphql", or "auto"
    indexer_url=...,        # EAS GraphQL endpoint for verify_by_hash on busy mainnet RPCs
)
```

See [docs.fidemark.dev/sdk/configuration](https://docs.fidemark.dev/sdk/configuration/) for the full surface.

## Documentation

- **Concepts**: https://docs.fidemark.dev/concepts/how-it-works/
- **SDK reference**: https://docs.fidemark.dev/sdk/installation/
- **Workflow examples**: https://docs.fidemark.dev/guides/workflows/
- **Verify page**: https://verify.fidemark.dev
- **Landing**: https://fidemark.dev

## Versioning

Semantic versioning. The bundled deployment artifacts are versioned alongside the package: pinning to a
specific `fidemark` version pins to a specific snapshot of resolver addresses + schema UIDs, so you can
audit exactly which contracts an installed version routes to.

## Issues

This repository is a **published mirror** of the Fidemark monorepo. Source lives privately, but issues
and feature requests are tracked here, please open one if you hit a bug or want to propose an addition.

## License

Apache License 2.0. See [LICENSE](./LICENSE) and [NOTICE](./NOTICE).

This SDK is the open-source client library for the Fidemark Protocol.
The protocol contracts and all related apps and services live in a
private repository and are licensed separately under proprietary terms; 
the deployed contract bytecode is independently verifiable on-chain at the 
addresses bundled in this package.

© 2026 Vincent Cibelli (VinciDev). The "Fidemark" name, logo, and brand are
reserved by Vincent Cibelli (VinciDev) and are not granted by Apache 2.0.
Forks of this SDK are welcome under the License, but please rename them so
users can tell them apart from the official Fidemark project.
