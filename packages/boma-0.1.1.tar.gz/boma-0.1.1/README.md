# Boma Python SDK

Boma Python SDK for building AI agents, workflows, and service integrations.

## Installation

```bash
pip install boma
```

## CLI

```bash
boma
```
