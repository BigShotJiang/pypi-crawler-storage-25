def main() -> None:
    print("Boma is installed and working.")
