"""Helvetisafe Kubernetes Integration.

Provides a Kubernetes-native way to retrieve secrets from Helvetisafe:

- **Sidecar agent** — a lightweight HTTP server that runs in the same Pod and
  serves decrypted secrets on the loopback interface (``127.0.0.1``).
- **Secret sync** — copies Helvetisafe secrets into a Kubernetes ``Secret``
  object so other workloads can consume them via standard Kubernetes mechanisms.
- **Init-container inject** — writes secrets to an ``.env`` file on a shared
  ``emptyDir`` volume before the main container starts.

All three modes use the Helvetisafe Python client for authenticated,
zero-knowledge secret retrieval.
"""

from .agent import run_agent
from .config import HelvetisafeConfig
from .sync import fetch_secrets, run_sync, sync_to_kubernetes, write_env_file

__version__ = "0.1.0"

__all__ = [
    "HelvetisafeConfig",
    "run_agent",
    "fetch_secrets",
    "run_sync",
    "sync_to_kubernetes",
    "write_env_file",
]
