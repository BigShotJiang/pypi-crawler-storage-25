"""Command-line interface for the Helvetisafe Kubernetes integration.

Three sub-commands are available::

    # Sidecar mode — continuously serve secrets over HTTP on localhost
    helvetisafe-vault-k8s serve [--port PORT] [--host HOST]

    # Sync mode — one-shot sync of Helvetisafe secrets to a Kubernetes Secret
    helvetisafe-vault-k8s sync [--output FILE]

    # Inject mode — write secrets to an env file (init-container pattern)
    helvetisafe-vault-k8s inject --output FILE

All sub-commands read Helvetisafe credentials and configuration from environment
variables (see :class:`~helvetisafe_k8s.config.HelvetisafeConfig`).
"""

import argparse
import logging
import sys


def _configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        level=getattr(logging, level.upper(), logging.INFO),
    )


def _cmd_serve(args: argparse.Namespace) -> int:
    from .agent import run_agent  # noqa: PLC0415
    from .config import HelvetisafeConfig  # noqa: PLC0415

    config = HelvetisafeConfig.from_env()
    if args.port is not None:
        config.agent_port = args.port
    if args.host is not None:
        config.agent_host = args.host

    run_agent(config)
    return 0


def _cmd_sync(args: argparse.Namespace) -> int:
    from .config import HelvetisafeConfig  # noqa: PLC0415
    from .sync import run_sync  # noqa: PLC0415

    config = HelvetisafeConfig.from_env()
    run_sync(config, env_file=args.output)
    return 0


def _cmd_inject(args: argparse.Namespace) -> int:
    from .config import HelvetisafeConfig  # noqa: PLC0415
    from .sync import run_sync  # noqa: PLC0415

    config = HelvetisafeConfig.from_env()
    run_sync(config, env_file=args.output)
    return 0


def main() -> None:
    """Entry point for the ``helvetisafe-vault-k8s`` command-line tool."""
    parser = argparse.ArgumentParser(
        prog="helvetisafe-vault-k8s",
        description="Helvetisafe Kubernetes integration — serve or sync secrets.",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        metavar="LEVEL",
        help="Logging level (default: INFO)",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")

    # -------------------------------------------------------------------------
    # serve — sidecar HTTP agent
    # -------------------------------------------------------------------------
    serve_parser = subparsers.add_parser(
        "serve",
        help="Start the sidecar HTTP agent that serves secrets on localhost.",
    )
    serve_parser.add_argument(
        "--port",
        type=int,
        default=None,
        metavar="PORT",
        help="Port to listen on (default: $HELVETISAFE_AGENT_PORT or 8080).",
    )
    serve_parser.add_argument(
        "--host",
        default=None,
        metavar="HOST",
        help="Host to bind to (default: $HELVETISAFE_AGENT_HOST or 127.0.0.1).",
    )

    # -------------------------------------------------------------------------
    # sync — one-shot Kubernetes Secret sync
    # -------------------------------------------------------------------------
    sync_parser = subparsers.add_parser(
        "sync",
        help="One-shot sync of Helvetisafe secrets to a Kubernetes Secret.",
    )
    sync_parser.add_argument(
        "--output",
        default=None,
        metavar="FILE",
        help="Also write secrets to a shell env file at this path.",
    )

    # -------------------------------------------------------------------------
    # inject — init-container env-file injection
    # -------------------------------------------------------------------------
    inject_parser = subparsers.add_parser(
        "inject",
        help="Write Helvetisafe secrets to an env file (init-container mode).",
    )
    inject_parser.add_argument(
        "--output",
        required=True,
        metavar="FILE",
        help="Path to write the shell environment file.",
    )

    args = parser.parse_args()
    _configure_logging(args.log_level)

    if args.command == "serve":
        sys.exit(_cmd_serve(args))
    elif args.command == "sync":
        sys.exit(_cmd_sync(args))
    elif args.command == "inject":
        sys.exit(_cmd_inject(args))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
