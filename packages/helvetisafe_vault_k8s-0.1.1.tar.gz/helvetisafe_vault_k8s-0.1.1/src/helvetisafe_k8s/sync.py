"""Kubernetes Secret synchronisation for Helvetisafe secrets.

This module provides two ways to materialise Helvetisafe secrets into a
Kubernetes workload:

1. :func:`sync_to_kubernetes` — creates or updates a Kubernetes ``Secret``
   object in the cluster so other Pods can consume it via ``envFrom``,
   ``valueFrom``, or volume mounts.
2. :func:`write_env_file` — writes secrets to a shell-compatible ``.env``
   file on a shared ``emptyDir`` volume (useful for init-container injection).

Both paths use :func:`fetch_secrets` to retrieve and decrypt secrets from
Helvetisafe via the Python client library.
"""

import base64
import logging
from typing import Dict, List, Optional

from helvetisafe import HelvetisafeClient

from .config import HelvetisafeConfig

logger = logging.getLogger(__name__)


def fetch_secrets(client: HelvetisafeClient, keys: List[str]) -> Dict[str, str]:
    """Fetch and decrypt a list of secrets from Helvetisafe.

    Args:
        client: An authenticated :class:`~helvetisafe.HelvetisafeClient` instance.
        keys: Names of the secrets to retrieve.

    Returns:
        A mapping of secret key → plaintext value.

    Raises:
        :exc:`helvetisafe.exceptions.HelvetisafeNotFoundError`: If any key does not exist.
        :exc:`helvetisafe.exceptions.HelvetisafeError`: For any other API or crypto error.
    """
    result: Dict[str, str] = {}
    for key in keys:
        secret = client.secrets.get(key)
        result[key] = secret.value
    return result


def write_env_file(secrets: Dict[str, str], path: str) -> None:
    """Write secrets to a shell-compatible environment file.

    Each line uses the form ``KEY="value"``. The file can be sourced by a
    shell init script or read by any framework that understands ``.env``
    files.

    Special characters in values are escaped:
    - Backslashes are doubled.
    - Double quotes are escaped with a backslash.
    - Newlines are replaced with the two-character sequence ``\\n``.

    Args:
        secrets: Mapping of key → plaintext value.
        path: File-system path where the env file will be written.
    """
    with open(path, "w", encoding="utf-8") as fh:
        for key, value in secrets.items():
            escaped = (
                value.replace("\\", "\\\\")
                .replace('"', '\\"')
                .replace("\n", "\\n")
            )
            fh.write(f'{key}="{escaped}"\n')
    logger.info("Wrote %d secret(s) to %s", len(secrets), path)


def sync_to_kubernetes(
    secrets: Dict[str, str],
    namespace: str,
    secret_name: str,
) -> None:
    """Create or update a Kubernetes ``Secret`` with Helvetisafe secret values.

    The function attempts to load in-cluster configuration first (suitable
    for running inside a Pod), falling back to the local ``~/.kube/config``.

    The Kubernetes ``Secret`` is of type ``Opaque``. Each entry in *secrets*
    becomes a key in the ``Secret``'s ``data`` map (base64-encoded, as
    required by the Kubernetes API).

    Requires the ``kubernetes`` Python package and a service account with
    ``create`` and ``update`` permissions on ``secrets`` in the target
    namespace (see ``examples/secret-sync-cronjob.yaml`` in this repository).

    Args:
        secrets: Mapping of key → plaintext value to store.
        namespace: Kubernetes namespace where the ``Secret`` should live.
        secret_name: Name of the Kubernetes ``Secret`` to create or update.

    Raises:
        ImportError: If the ``kubernetes`` package is not installed.
        :exc:`kubernetes.client.exceptions.ApiException`: On unexpected API
            errors.
    """
    try:
        from kubernetes import client as k8s_client  # noqa: PLC0415
        from kubernetes import config as k8s_config  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "The 'kubernetes' package is required for Kubernetes Secret sync. "
            "Install it with: pip install kubernetes"
        ) from exc

    # Load cluster credentials — in-cluster config first, then local kubeconfig
    try:
        k8s_config.load_incluster_config()
    except k8s_config.ConfigException:
        try:
            k8s_config.load_kube_config()
        except k8s_config.ConfigException as exc:
            raise RuntimeError(
                "Could not load Kubernetes configuration. Ensure the process is "
                "running inside a Pod with a service account, or that a valid "
                "kubeconfig file is available."
            ) from exc

    v1 = k8s_client.CoreV1Api()

    # Kubernetes Secret data values must be base64-encoded strings
    data = {
        key: base64.b64encode(value.encode("utf-8")).decode("utf-8")
        for key, value in secrets.items()
    }

    secret_body = k8s_client.V1Secret(
        metadata=k8s_client.V1ObjectMeta(name=secret_name, namespace=namespace),
        data=data,
        type="Opaque",
    )

    try:
        v1.read_namespaced_secret(name=secret_name, namespace=namespace)
        # Secret exists — replace it
        v1.replace_namespaced_secret(
            name=secret_name, namespace=namespace, body=secret_body
        )
        logger.info(
            "Updated Kubernetes Secret in namespace '%s' with %d key(s)",
            namespace,
            len(secrets),
        )
    except k8s_client.exceptions.ApiException as exc:
        if exc.status == 404:
            # Secret does not exist yet — create it
            v1.create_namespaced_secret(namespace=namespace, body=secret_body)
            logger.info(
                "Created Kubernetes Secret in namespace '%s' with %d key(s)",
                namespace,
                len(secrets),
            )
        else:
            raise


def run_sync(config: HelvetisafeConfig, env_file: Optional[str] = None) -> None:
    """Run a one-shot sync of Helvetisafe secrets.

    The function performs the following steps:

    1. Builds an :class:`~helvetisafe.HelvetisafeClient` from *config*.
    2. Determines the list of secret keys to fetch — uses
       ``config.secret_keys`` when non-empty, otherwise lists all secrets
       visible to the service account.
    3. Fetches and decrypts each secret.
    4. Optionally writes the secrets to *env_file*.
    5. Optionally syncs the secrets to a Kubernetes ``Secret`` if
       ``config.k8s_secret_name`` is set.

    Args:
        config: Helvetisafe and Kubernetes configuration.
        env_file: If provided, the path of an env file to write.
    """
    from .agent import build_client  # noqa: PLC0415

    client = build_client(config)

    if config.secret_keys:
        keys_to_sync = config.secret_keys
    else:
        metadata = client.secrets.list()
        keys_to_sync = [m.key for m in metadata]

    if not keys_to_sync:
        logger.warning("No secret keys to sync.")
        return

    secrets = fetch_secrets(client, keys_to_sync)

    if env_file:
        write_env_file(secrets, env_file)

    if config.k8s_secret_name:
        sync_to_kubernetes(secrets, config.k8s_namespace, config.k8s_secret_name)
