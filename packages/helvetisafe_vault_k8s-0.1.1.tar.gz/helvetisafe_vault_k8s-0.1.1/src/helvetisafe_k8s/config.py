"""Configuration loading for the Helvetisafe Kubernetes integration."""

import os
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class HelvetisafeConfig:
    """Configuration for the Helvetisafe Kubernetes integration.

    All fields can be supplied directly or loaded from environment variables
    via :meth:`from_env`.

    Attributes:
        base_url: Base URL of the Helvetisafe instance
            (e.g. ``https://vault.helvetisafe.ch``).
        client_id: OAuth 2.0 client ID for the service account.
        client_secret: OAuth 2.0 client secret for the service account.
        private_key_path: Path to a PEM file containing the RSA private key.
        private_key_pem: PEM-encoded RSA private key as a string.
        password: Service account password (password auth mode).
        agent_port: Port the sidecar HTTP agent listens on (default: ``8080``).
        agent_host: Host the sidecar HTTP agent binds to (default:
            ``127.0.0.1``).
        k8s_namespace: Kubernetes namespace for Secret sync (default:
            ``default``).
        k8s_secret_name: Name of the Kubernetes ``Secret`` to create or update.
            When ``None``, Kubernetes Secret sync is skipped.
        secret_keys: List of Helvetisafe secret key names to fetch. When empty,
            all secrets visible to the service account are synced.
    """

    base_url: str
    client_id: str
    client_secret: str

    # Authentication — exactly one of these must be set
    private_key_path: Optional[str] = None
    private_key_pem: Optional[str] = None
    password: Optional[str] = None

    # Sidecar agent configuration
    agent_port: int = 8080
    agent_host: str = "127.0.0.1"

    # Kubernetes Secret sync configuration
    k8s_namespace: str = "default"
    k8s_secret_name: Optional[str] = None
    secret_keys: List[str] = field(default_factory=list)

    @classmethod
    def from_env(cls) -> "HelvetisafeConfig":
        """Load configuration from environment variables.

        Required environment variables:
            ``HELVETISAFE_BASE_URL`` — base URL of the Helvetisafe instance.
            ``HELVETISAFE_CLIENT_ID`` — OAuth 2.0 client ID.
            ``HELVETISAFE_CLIENT_SECRET`` — OAuth 2.0 client secret.

        Authentication (exactly one required):
            ``HELVETISAFE_PRIVATE_KEY_PATH`` — path to a PEM private key file.
            ``HELVETISAFE_PRIVATE_KEY_PEM`` — PEM private key content as a string.
            ``HELVETISAFE_PASSWORD`` — service account password.

        Optional environment variables:
            ``HELVETISAFE_AGENT_PORT`` — sidecar agent port (default: ``8080``).
            ``HELVETISAFE_AGENT_HOST`` — sidecar agent bind host
                (default: ``127.0.0.1``).
            ``HELVETISAFE_K8S_NAMESPACE`` — Kubernetes namespace
                (default: ``default``).
            ``HELVETISAFE_K8S_SECRET_NAME`` — Kubernetes Secret name.
            ``HELVETISAFE_SECRET_KEYS`` — comma-separated list of secret key names.

        Returns:
            A populated :class:`HelvetisafeConfig` instance.

        Raises:
            ValueError: If any required environment variable is missing.
        """
        base_url = os.environ.get("HELVETISAFE_BASE_URL")
        if not base_url:
            raise ValueError("HELVETISAFE_BASE_URL environment variable is required")

        client_id = os.environ.get("HELVETISAFE_CLIENT_ID")
        if not client_id:
            raise ValueError("HELVETISAFE_CLIENT_ID environment variable is required")

        client_secret = os.environ.get("HELVETISAFE_CLIENT_SECRET")
        if not client_secret:
            raise ValueError(
                "HELVETISAFE_CLIENT_SECRET environment variable is required"
            )

        secret_keys_env = os.environ.get("HELVETISAFE_SECRET_KEYS", "")
        secret_keys = [k.strip() for k in secret_keys_env.split(",") if k.strip()]

        return cls(
            base_url=base_url,
            client_id=client_id,
            client_secret=client_secret,
            private_key_path=os.environ.get("HELVETISAFE_PRIVATE_KEY_PATH"),
            private_key_pem=os.environ.get("HELVETISAFE_PRIVATE_KEY_PEM"),
            password=os.environ.get("HELVETISAFE_PASSWORD"),
            agent_port=int(os.environ.get("HELVETISAFE_AGENT_PORT", "8080")),
            agent_host=os.environ.get("HELVETISAFE_AGENT_HOST", "127.0.0.1"),
            k8s_namespace=os.environ.get("HELVETISAFE_K8S_NAMESPACE", "default"),
            k8s_secret_name=os.environ.get("HELVETISAFE_K8S_SECRET_NAME"),
            secret_keys=secret_keys,
        )

    def validate_auth(self) -> None:
        """Validate that exactly one authentication method is configured.

        Raises:
            ValueError: If zero or more than one auth source is configured.
        """
        provided = sum(
            x is not None
            for x in [self.private_key_path, self.private_key_pem, self.password]
        )
        if provided != 1:
            raise ValueError(
                "Exactly one of private_key_path, private_key_pem, or password "
                "must be configured (via environment variable or directly)."
            )
