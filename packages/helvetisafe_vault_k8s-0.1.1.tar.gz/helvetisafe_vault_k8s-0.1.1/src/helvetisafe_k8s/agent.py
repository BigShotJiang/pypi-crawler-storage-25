"""Sidecar HTTP agent for serving Helvetisafe secrets on localhost.

The agent runs as a sidecar container in a Kubernetes Pod and exposes decrypted
secrets over a plain HTTP interface bound only to the loopback interface
(``127.0.0.1``). Application containers in the same Pod can retrieve secrets
without implementing any cryptographic logic.

Security note:
    The agent binds exclusively to ``127.0.0.1`` by default, so secrets are
    only accessible to processes running in the same network namespace (i.e.,
    the same Pod). They are never exposed on the Pod's external network
    interface or to other Pods.

API endpoints:
    ``GET /health``
        Returns ``{"status": "ok"}`` — used by Kubernetes liveness/readiness
        probes.
    ``GET /secrets``
        Returns a list of all secret key names visible to the service account
        (metadata only, no plaintext values).
    ``GET /secret/{key}``
        Returns the decrypted plaintext value of the named secret.
"""

import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Optional
from urllib.parse import urlparse

from helvetisafe import HelvetisafeClient
from helvetisafe.exceptions import HelvetisafeError, HelvetisafeNotFoundError

from .config import HelvetisafeConfig

logger = logging.getLogger(__name__)


class SecretRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler that serves Helvetisafe secrets over localhost.

    The :attr:`helvetisafe_client` class attribute must be set to a configured
    :class:`~helvetisafe.HelvetisafeClient` instance before the server is started.
    :func:`run_agent` handles this automatically.
    """

    helvetisafe_client: Optional[HelvetisafeClient] = None

    def log_message(self, format, *args):  # noqa: A002
        logger.debug(
            "%s - [%s] %s",
            self.address_string(),
            self.log_date_time_string(),
            format % args,
        )

    def do_GET(self) -> None:
        """Handle GET requests."""
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")

        if path == "/health":
            self._send_json(200, {"status": "ok"})
            return

        if path == "/secrets":
            self._handle_list_secrets()
            return

        if path.startswith("/secret/"):
            key = path[len("/secret/"):]
            if key:
                self._handle_get_secret(key)
                return

        self._send_json(404, {"error": "Not found"})

    def _handle_get_secret(self, key: str) -> None:
        if self.helvetisafe_client is None:
            self._send_json(503, {"error": "Service initializing, try again shortly"})
            return
        try:
            secret = self.helvetisafe_client.secrets.get(key)
            self._send_json(200, {"key": secret.key, "value": secret.value})
        except HelvetisafeNotFoundError:
            self._send_json(404, {"error": f"Secret '{key}' not found"})
        except HelvetisafeError as exc:
            logger.error("Error retrieving secret '%s': %s", key, exc)
            self._send_json(500, {"error": "Internal server error"})

    def _handle_list_secrets(self) -> None:
        if self.helvetisafe_client is None:
            self._send_json(503, {"error": "Service initializing, try again shortly"})
            return
        try:
            metadata = self.helvetisafe_client.secrets.list()
            self._send_json(200, {"keys": [m.key for m in metadata]})
        except HelvetisafeError as exc:
            logger.error("Error listing secrets: %s", exc)
            self._send_json(500, {"error": "Internal server error"})

    def _send_json(self, status_code: int, body: dict) -> None:
        content = json.dumps(body).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)


def build_client(config: HelvetisafeConfig) -> HelvetisafeClient:
    """Build an :class:`~helvetisafe.HelvetisafeClient` from a :class:`HelvetisafeConfig`.

    Args:
        config: Populated configuration object. :meth:`~HelvetisafeConfig.validate_auth`
            is called automatically.

    Returns:
        An authenticated :class:`~helvetisafe.HelvetisafeClient` instance.

    Raises:
        ValueError: If the auth configuration is invalid.
        :exc:`helvetisafe.exceptions.HelvetisafeAuthError`: If OAuth authentication fails.
        :exc:`helvetisafe.exceptions.HelvetisafeCryptoError`: If key decryption fails.
    """
    config.validate_auth()

    kwargs: dict = {
        "base_url": config.base_url,
        "client_id": config.client_id,
        "client_secret": config.client_secret,
    }

    if config.private_key_path is not None:
        kwargs["private_key_path"] = config.private_key_path
    elif config.private_key_pem is not None:
        kwargs["private_key_pem"] = config.private_key_pem.encode("utf-8")
    else:
        kwargs["password"] = config.password

    return HelvetisafeClient(**kwargs)


def run_agent(config: HelvetisafeConfig) -> None:
    """Start the sidecar HTTP agent and block until interrupted.

    The HTTP server binds to the port immediately so that Kubernetes
    liveness/readiness probes can reach ``/health`` right away.  The
    :class:`~helvetisafe.HelvetisafeClient` (which performs blocking OAuth and
    key-unwrap network calls) is built in a background thread.  Requests to
    ``/secret/{key}`` and ``/secrets`` return ``503`` until initialisation
    completes.  If initialisation fails, the server shuts down so Kubernetes
    restarts the container.

    Args:
        config: Populated :class:`HelvetisafeConfig`.

    Raises:
        ValueError: If the auth configuration is invalid.
        OSError: If the port is already in use.
    """
    # Create the handler subclass with client=None; it will be set below once
    # the background initialisation thread completes.
    class _Handler(SecretRequestHandler):
        helvetisafe_client = None

    server_address = (config.agent_host, config.agent_port)
    httpd = HTTPServer(server_address, _Handler)
    logger.info(
        "Helvetisafe sidecar agent listening on %s:%d",
        config.agent_host,
        config.agent_port,
    )

    def _init_client() -> None:
        try:
            _Handler.helvetisafe_client = build_client(config)
            logger.info("Helvetisafe client initialised successfully")
        except Exception as exc:  # noqa: BLE001
            logger.error("Failed to initialise Helvetisafe client: %s", exc)
            httpd.shutdown()

    threading.Thread(target=_init_client, daemon=True, name="helvetisafe-init").start()
    httpd.serve_forever()
