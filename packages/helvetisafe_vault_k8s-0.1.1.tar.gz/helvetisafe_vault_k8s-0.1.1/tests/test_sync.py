"""Unit tests for Helvetisafe secret sync operations."""

import os
import tempfile
from unittest.mock import MagicMock, call, patch

import pytest

from helvetisafe.models import Secret, SecretMetadata
from helvetisafe_k8s.sync import fetch_secrets, write_env_file


# ---------------------------------------------------------------------------
# fetch_secrets
# ---------------------------------------------------------------------------


class TestFetchSecrets:
    def test_fetches_listed_keys(self):
        client = MagicMock()
        client.secrets.get.side_effect = lambda key: Secret(
            key=key, value=f"value_of_{key}", expires_at=None
        )
        result = fetch_secrets(client, ["db_pass", "api_key"])
        assert result == {"db_pass": "value_of_db_pass", "api_key": "value_of_api_key"}

    def test_returns_empty_dict_for_no_keys(self):
        client = MagicMock()
        result = fetch_secrets(client, [])
        assert result == {}
        client.secrets.get.assert_not_called()

    def test_calls_get_for_each_key(self):
        client = MagicMock()
        client.secrets.get.return_value = Secret(key="k", value="v", expires_at=None)
        fetch_secrets(client, ["a", "b", "c"])
        assert client.secrets.get.call_count == 3
        client.secrets.get.assert_any_call("a")
        client.secrets.get.assert_any_call("b")
        client.secrets.get.assert_any_call("c")

    def test_propagates_helvetisafe_error(self):
        from helvetisafe.exceptions import HelvetisafeNotFoundError

        client = MagicMock()
        client.secrets.get.side_effect = HelvetisafeNotFoundError("missing", 404, {})
        with pytest.raises(HelvetisafeNotFoundError):
            fetch_secrets(client, ["missing_key"])


# ---------------------------------------------------------------------------
# write_env_file
# ---------------------------------------------------------------------------


class TestWriteEnvFile:
    def _read_tmp(self, secrets: dict) -> str:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".env", delete=False
        ) as f:
            path = f.name
        try:
            write_env_file(secrets, path)
            with open(path, encoding="utf-8") as f:
                return f.read()
        finally:
            os.unlink(path)

    def test_writes_simple_key_value(self):
        content = self._read_tmp({"DB_PASS": "hunter2"})
        assert 'DB_PASS="hunter2"' in content

    def test_multiple_secrets_each_on_own_line(self):
        content = self._read_tmp({"A": "1", "B": "2"})
        lines = [ln for ln in content.splitlines() if ln]
        assert len(lines) == 2

    def test_escapes_double_quotes_in_value(self):
        content = self._read_tmp({"KEY": 'val"ue'})
        assert '\\"' in content

    def test_escapes_newlines_in_value(self):
        content = self._read_tmp({"KEY": "line1\nline2"})
        assert "\\n" in content

    def test_escapes_backslashes_in_value(self):
        content = self._read_tmp({"KEY": "back\\slash"})
        assert "\\\\" in content

    def test_empty_dict_writes_empty_file(self):
        content = self._read_tmp({})
        assert content == ""

    def test_five_secrets_produce_five_lines(self):
        secrets = {f"KEY_{i}": f"value_{i}" for i in range(5)}
        content = self._read_tmp(secrets)
        lines = [ln for ln in content.splitlines() if ln]
        assert len(lines) == 5


# ---------------------------------------------------------------------------
# sync_to_kubernetes — ImportError when package missing
# ---------------------------------------------------------------------------


class TestSyncToKubernetesImportError:
    def test_raises_import_error_when_kubernetes_not_installed(self):
        from helvetisafe_k8s.sync import sync_to_kubernetes
        import sys

        # Temporarily hide the kubernetes package
        original = sys.modules.get("kubernetes")
        sys.modules["kubernetes"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="kubernetes"):
                sync_to_kubernetes({"k": "v"}, "default", "my-secret")
        finally:
            if original is None:
                sys.modules.pop("kubernetes", None)
            else:
                sys.modules["kubernetes"] = original


# ---------------------------------------------------------------------------
# run_sync — orchestration
# ---------------------------------------------------------------------------


class TestRunSync:
    def _make_config(self, secret_keys=None, k8s_secret_name=None):
        from helvetisafe_k8s.config import HelvetisafeConfig

        return HelvetisafeConfig(
            base_url="https://vault.helvetisafe.ch",
            client_id="id",
            client_secret="secret",
            password="pw",
            secret_keys=secret_keys or [],
            k8s_secret_name=k8s_secret_name,
            k8s_namespace="default",
        )

    def test_writes_env_file_when_output_provided(self, tmp_path):
        from helvetisafe_k8s.sync import run_sync

        env_file = str(tmp_path / "secrets.env")
        config = self._make_config(secret_keys=["db_pass"])

        mock_client = MagicMock()
        mock_client.secrets.get.return_value = Secret(
            key="db_pass", value="s3cr3t", expires_at=None
        )

        with patch("helvetisafe_k8s.agent.build_client", return_value=mock_client):
            run_sync(config, env_file=env_file)

        assert os.path.exists(env_file)
        with open(env_file) as f:
            content = f.read()
        assert "db_pass" in content
        assert "s3cr3t" in content

    def test_uses_config_secret_keys_when_provided(self, tmp_path):
        from helvetisafe_k8s.sync import run_sync

        config = self._make_config(secret_keys=["k1", "k2"])
        env_file = str(tmp_path / "out.env")

        mock_client = MagicMock()
        mock_client.secrets.get.side_effect = lambda key: Secret(
            key=key, value=f"v_{key}", expires_at=None
        )

        with patch("helvetisafe_k8s.agent.build_client", return_value=mock_client):
            run_sync(config, env_file=env_file)

        mock_client.secrets.list.assert_not_called()
        assert mock_client.secrets.get.call_count == 2

    def test_falls_back_to_list_when_no_secret_keys(self, tmp_path):
        from helvetisafe_k8s.sync import run_sync

        config = self._make_config(secret_keys=[])
        env_file = str(tmp_path / "out.env")

        mock_client = MagicMock()
        mock_client.secrets.list.return_value = [
            SecretMetadata(key="a", created_at=None, updated_at=None, expires_at=None),
        ]
        mock_client.secrets.get.return_value = Secret(
            key="a", value="val_a", expires_at=None
        )

        with patch("helvetisafe_k8s.agent.build_client", return_value=mock_client):
            run_sync(config, env_file=env_file)

        mock_client.secrets.list.assert_called_once()

    def test_does_nothing_when_no_keys_found(self, tmp_path, caplog):
        from helvetisafe_k8s.sync import run_sync
        import logging

        config = self._make_config(secret_keys=[])
        env_file = str(tmp_path / "out.env")

        mock_client = MagicMock()
        mock_client.secrets.list.return_value = []

        with patch("helvetisafe_k8s.agent.build_client", return_value=mock_client):
            with caplog.at_level(logging.WARNING, logger="helvetisafe_k8s.sync"):
                run_sync(config, env_file=env_file)

        mock_client.secrets.get.assert_not_called()
        assert not os.path.exists(env_file)
