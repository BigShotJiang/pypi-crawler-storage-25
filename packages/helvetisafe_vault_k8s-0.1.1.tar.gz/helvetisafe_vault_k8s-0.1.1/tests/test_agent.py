"""Unit tests for the Helvetisafe Kubernetes sidecar agent."""

import json
from io import BytesIO
from unittest.mock import MagicMock

import pytest

from helvetisafe.exceptions import HelvetisafeError, HelvetisafeNotFoundError
from helvetisafe.models import Secret, SecretMetadata
from helvetisafe_k8s.agent import SecretRequestHandler


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_handler(path: str, helvetisafe_client=None) -> SecretRequestHandler:
    """Build a :class:`SecretRequestHandler` wired to an in-memory response buffer."""
    handler = SecretRequestHandler.__new__(SecretRequestHandler)
    handler.path = path

    # Bind the client via the class approach used in production
    handler.__class__ = type(
        "_BoundHandler",
        (SecretRequestHandler,),
        {"helvetisafe_client": helvetisafe_client},
    )

    handler._response_code = None
    handler._response_headers: list = []
    handler._body_buf = BytesIO()
    handler.wfile = handler._body_buf

    def send_response(code):
        handler._response_code = code

    def send_header(key, value):
        handler._response_headers.append((key, value))

    def end_headers():
        pass

    handler.send_response = send_response
    handler.send_header = send_header
    handler.end_headers = end_headers
    return handler


def _response_body(handler: SecretRequestHandler) -> dict:
    return json.loads(handler._body_buf.getvalue().decode())


# ---------------------------------------------------------------------------
# Health endpoint
# ---------------------------------------------------------------------------


class TestHealthEndpoint:
    def test_returns_200_and_ok_status(self):
        handler = _make_handler("/health")
        handler.do_GET()
        assert handler._response_code == 200
        assert _response_body(handler) == {"status": "ok"}

    def test_trailing_slash_accepted(self):
        handler = _make_handler("/health/")
        handler.do_GET()
        assert handler._response_code == 200


# ---------------------------------------------------------------------------
# GET /secret/{key}
# ---------------------------------------------------------------------------


class TestGetSecret:
    def test_returns_503_when_client_not_initialised(self):
        handler = _make_handler("/secret/some_key", helvetisafe_client=None)
        handler.do_GET()
        assert handler._response_code == 503
        assert "initializing" in _response_body(handler)["error"].lower()

    def test_returns_key_and_plaintext_value(self):
        client = MagicMock()
        client.secrets.get.return_value = Secret(
            key="db_pass", value="hunter2", expires_at=None
        )
        handler = _make_handler("/secret/db_pass", helvetisafe_client=client)
        handler.do_GET()

        assert handler._response_code == 200
        body = _response_body(handler)
        assert body["key"] == "db_pass"
        assert body["value"] == "hunter2"
        client.secrets.get.assert_called_once_with("db_pass")

    def test_not_found_returns_404(self):
        client = MagicMock()
        client.secrets.get.side_effect = HelvetisafeNotFoundError("not found", 404, {})
        handler = _make_handler("/secret/missing", helvetisafe_client=client)
        handler.do_GET()

        assert handler._response_code == 404
        body = _response_body(handler)
        assert "not found" in body["error"].lower()

    def test_generic_helvetisafe_error_returns_500(self):
        client = MagicMock()
        client.secrets.get.side_effect = HelvetisafeError("something went wrong")
        handler = _make_handler("/secret/bad", helvetisafe_client=client)
        handler.do_GET()

        assert handler._response_code == 500
        body = _response_body(handler)
        assert "error" in body

    def test_key_with_underscores_routed_correctly(self):
        client = MagicMock()
        client.secrets.get.return_value = Secret(
            key="my_secret_key", value="val", expires_at=None
        )
        handler = _make_handler("/secret/my_secret_key", helvetisafe_client=client)
        handler.do_GET()

        assert handler._response_code == 200
        client.secrets.get.assert_called_once_with("my_secret_key")


# ---------------------------------------------------------------------------
# GET /secrets
# ---------------------------------------------------------------------------


class TestListSecrets:
    def test_returns_503_when_client_not_initialised(self):
        handler = _make_handler("/secrets", helvetisafe_client=None)
        handler.do_GET()
        assert handler._response_code == 503
        assert "initializing" in _response_body(handler)["error"].lower()

    def test_returns_list_of_keys(self):
        client = MagicMock()
        client.secrets.list.return_value = [
            SecretMetadata(key="k1", created_at=None, updated_at=None, expires_at=None),
            SecretMetadata(key="k2", created_at=None, updated_at=None, expires_at=None),
        ]
        handler = _make_handler("/secrets", helvetisafe_client=client)
        handler.do_GET()

        assert handler._response_code == 200
        body = _response_body(handler)
        assert set(body["keys"]) == {"k1", "k2"}

    def test_empty_list(self):
        client = MagicMock()
        client.secrets.list.return_value = []
        handler = _make_handler("/secrets", helvetisafe_client=client)
        handler.do_GET()

        assert handler._response_code == 200
        assert _response_body(handler)["keys"] == []

    def test_helvetisafe_error_returns_500(self):
        client = MagicMock()
        client.secrets.list.side_effect = HelvetisafeError("api down")
        handler = _make_handler("/secrets", helvetisafe_client=client)
        handler.do_GET()

        assert handler._response_code == 500


# ---------------------------------------------------------------------------
# Unknown paths
# ---------------------------------------------------------------------------


class TestUnknownPaths:
    @pytest.mark.parametrize(
        "path",
        [
            "/",
            "/unknown",
            "/secret",  # missing key
            "/secret/",  # empty key after stripping
        ],
    )
    def test_returns_404(self, path):
        handler = _make_handler(path)
        handler.do_GET()
        assert handler._response_code == 404
