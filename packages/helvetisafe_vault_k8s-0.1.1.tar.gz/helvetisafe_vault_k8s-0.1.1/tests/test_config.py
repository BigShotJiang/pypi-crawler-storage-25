"""Unit tests for HelvetisafeConfig."""

import pytest

from helvetisafe_k8s.config import HelvetisafeConfig


class TestHelvetisafeConfigFromEnv:
    """Tests for HelvetisafeConfig.from_env()."""

    def test_loads_required_fields(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "my-client")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "my-secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "my-password")

        config = HelvetisafeConfig.from_env()

        assert config.base_url == "https://vault.helvetisafe.ch"
        assert config.client_id == "my-client"
        assert config.client_secret == "my-secret"
        assert config.password == "my-password"

    def test_missing_base_url_raises(self, monkeypatch):
        monkeypatch.delenv("HELVETISAFE_BASE_URL", raising=False)
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")

        with pytest.raises(ValueError, match="HELVETISAFE_BASE_URL"):
            HelvetisafeConfig.from_env()

    def test_missing_client_id_raises(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.delenv("HELVETISAFE_CLIENT_ID", raising=False)
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")

        with pytest.raises(ValueError, match="HELVETISAFE_CLIENT_ID"):
            HelvetisafeConfig.from_env()

    def test_missing_client_secret_raises(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.delenv("HELVETISAFE_CLIENT_SECRET", raising=False)

        with pytest.raises(ValueError, match="HELVETISAFE_CLIENT_SECRET"):
            HelvetisafeConfig.from_env()

    def test_default_agent_port(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.delenv("HELVETISAFE_AGENT_PORT", raising=False)

        config = HelvetisafeConfig.from_env()

        assert config.agent_port == 8080

    def test_default_agent_host(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.delenv("HELVETISAFE_AGENT_HOST", raising=False)

        config = HelvetisafeConfig.from_env()

        assert config.agent_host == "127.0.0.1"

    def test_default_k8s_namespace(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.delenv("HELVETISAFE_K8S_NAMESPACE", raising=False)

        config = HelvetisafeConfig.from_env()

        assert config.k8s_namespace == "default"

    def test_default_k8s_secret_name_is_none(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.delenv("HELVETISAFE_K8S_SECRET_NAME", raising=False)

        config = HelvetisafeConfig.from_env()

        assert config.k8s_secret_name is None

    def test_default_secret_keys_is_empty(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.delenv("HELVETISAFE_SECRET_KEYS", raising=False)

        config = HelvetisafeConfig.from_env()

        assert config.secret_keys == []

    def test_custom_agent_port(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.setenv("HELVETISAFE_AGENT_PORT", "9090")

        config = HelvetisafeConfig.from_env()

        assert config.agent_port == 9090

    def test_secret_keys_parsed_from_comma_list(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.setenv("HELVETISAFE_SECRET_KEYS", "db_pass, api_key, token")

        config = HelvetisafeConfig.from_env()

        assert config.secret_keys == ["db_pass", "api_key", "token"]

    def test_secret_keys_strips_whitespace(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.setenv("HELVETISAFE_SECRET_KEYS", "  k1  ,  k2  ")

        config = HelvetisafeConfig.from_env()

        assert config.secret_keys == ["k1", "k2"]

    def test_private_key_path_loaded(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PRIVATE_KEY_PATH", "/path/to/key.pem")
        monkeypatch.delenv("HELVETISAFE_PASSWORD", raising=False)

        config = HelvetisafeConfig.from_env()

        assert config.private_key_path == "/path/to/key.pem"
        assert config.password is None

    def test_k8s_secret_name_and_namespace(self, monkeypatch):
        monkeypatch.setenv("HELVETISAFE_BASE_URL", "https://vault.helvetisafe.ch")
        monkeypatch.setenv("HELVETISAFE_CLIENT_ID", "id")
        monkeypatch.setenv("HELVETISAFE_CLIENT_SECRET", "secret")
        monkeypatch.setenv("HELVETISAFE_PASSWORD", "pw")
        monkeypatch.setenv("HELVETISAFE_K8S_SECRET_NAME", "my-app-secrets")
        monkeypatch.setenv("HELVETISAFE_K8S_NAMESPACE", "production")

        config = HelvetisafeConfig.from_env()

        assert config.k8s_secret_name == "my-app-secrets"
        assert config.k8s_namespace == "production"


class TestHelvetisafeConfigValidateAuth:
    """Tests for HelvetisafeConfig.validate_auth()."""

    def test_password_only_is_valid(self):
        config = HelvetisafeConfig(
            base_url="https://vault.helvetisafe.ch",
            client_id="id",
            client_secret="secret",
            password="pw",
        )
        config.validate_auth()  # should not raise

    def test_private_key_path_only_is_valid(self):
        config = HelvetisafeConfig(
            base_url="https://vault.helvetisafe.ch",
            client_id="id",
            client_secret="secret",
            private_key_path="/path/key.pem",
        )
        config.validate_auth()  # should not raise

    def test_private_key_pem_only_is_valid(self):
        config = HelvetisafeConfig(
            base_url="https://vault.helvetisafe.ch",
            client_id="id",
            client_secret="secret",
            private_key_pem="-----BEGIN RSA PRIVATE KEY-----\n...",
        )
        config.validate_auth()  # should not raise

    def test_no_auth_raises(self):
        config = HelvetisafeConfig(
            base_url="https://vault.helvetisafe.ch",
            client_id="id",
            client_secret="secret",
        )
        with pytest.raises(ValueError, match="Exactly one"):
            config.validate_auth()

    def test_password_and_key_path_raises(self):
        config = HelvetisafeConfig(
            base_url="https://vault.helvetisafe.ch",
            client_id="id",
            client_secret="secret",
            password="pw",
            private_key_path="/path/key.pem",
        )
        with pytest.raises(ValueError, match="Exactly one"):
            config.validate_auth()

    def test_all_three_set_raises(self):
        config = HelvetisafeConfig(
            base_url="https://vault.helvetisafe.ch",
            client_id="id",
            client_secret="secret",
            password="pw",
            private_key_path="/path/key.pem",
            private_key_pem="-----BEGIN RSA PRIVATE KEY-----\n...",
        )
        with pytest.raises(ValueError, match="Exactly one"):
            config.validate_auth()
