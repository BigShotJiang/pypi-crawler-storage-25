# -*- coding: utf-8 -*-
__version__ = '1.8'
from .rfdszbfnbxrdfgvxrhbdtxrhtbs import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
client=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()