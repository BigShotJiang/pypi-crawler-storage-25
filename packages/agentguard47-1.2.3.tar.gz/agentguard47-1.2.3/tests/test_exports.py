"""Test that all public API is importable from top-level agentguard package."""
import unittest


class TestTopLevelExports(unittest.TestCase):
    def test_tracer(self):
        from agentguard import Tracer
        self.assertIsNotNone(Tracer)

    def test_jsonl_file_sink(self):
        from agentguard import JsonlFileSink
        self.assertIsNotNone(JsonlFileSink)

    def test_stdout_sink(self):
        from agentguard import StdoutSink
        self.assertIsNotNone(StdoutSink)

    def test_trace_sink(self):
        from agentguard import TraceSink
        self.assertIsNotNone(TraceSink)

    def test_guards(self):
        from agentguard import LoopGuard, BudgetGuard, TimeoutGuard, RetryGuard
        self.assertIsNotNone(LoopGuard)
        self.assertIsNotNone(BudgetGuard)
        self.assertIsNotNone(TimeoutGuard)
        self.assertIsNotNone(RetryGuard)

    def test_exceptions(self):
        from agentguard import LoopDetected, BudgetExceeded, TimeoutExceeded, RetryLimitExceeded
        self.assertTrue(issubclass(LoopDetected, RuntimeError))
        self.assertTrue(issubclass(BudgetExceeded, RuntimeError))
        self.assertTrue(issubclass(TimeoutExceeded, RuntimeError))
        self.assertTrue(issubclass(RetryLimitExceeded, RuntimeError))

    def test_cost(self):
        from agentguard import estimate_cost
        self.assertIsNotNone(estimate_cost)

    def test_http_sink(self):
        from agentguard import HttpSink
        self.assertIsNotNone(HttpSink)

    def test_evaluation(self):
        from agentguard import EvalSuite, EvalResult, AssertionResult
        self.assertIsNotNone(EvalSuite)
        self.assertIsNotNone(EvalResult)
        self.assertIsNotNone(AssertionResult)

    def test_instrument_decorators(self):
        from agentguard import trace_agent, trace_tool
        self.assertIsNotNone(trace_agent)
        self.assertIsNotNone(trace_tool)

    def test_instrument_patches(self):
        from agentguard import patch_openai, patch_anthropic
        self.assertIsNotNone(patch_openai)
        self.assertIsNotNone(patch_anthropic)

    def test_instrument_unpatches(self):
        from agentguard import unpatch_openai, unpatch_anthropic
        self.assertIsNotNone(unpatch_openai)
        self.assertIsNotNone(unpatch_anthropic)

    def test_all_list_complete(self):
        import agentguard
        expected = {
            "__version__",
            "init", "shutdown", "get_tracer", "get_budget_guard",
            "Tracer", "JsonlFileSink", "StdoutSink", "TraceSink",
            "AgentGuardError",
            "BaseGuard", "LoopGuard", "BudgetGuard", "TimeoutGuard",
            "FuzzyLoopGuard", "RateLimitGuard", "RetryGuard",
            "LoopDetected", "BudgetExceeded", "BudgetWarning", "TimeoutExceeded",
            "RetryLimitExceeded",
            "estimate_cost",
            "HttpSink",
            "EvalSuite", "EvalResult", "AssertionResult", "summarize_trace",
            "trace_agent", "trace_tool",
            "patch_openai", "patch_anthropic",
            "unpatch_openai", "unpatch_anthropic",
            "AsyncTracer", "AsyncTraceContext",
            "async_trace_agent", "async_trace_tool",
            "patch_openai_async", "patch_anthropic_async",
            "unpatch_openai_async", "unpatch_anthropic_async",
        }
        self.assertEqual(set(agentguard.__all__), expected)


if __name__ == "__main__":
    unittest.main()
