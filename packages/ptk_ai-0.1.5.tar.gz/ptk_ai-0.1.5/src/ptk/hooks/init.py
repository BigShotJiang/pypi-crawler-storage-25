"""Agent hook installation and `ptk rewrite` (hook command rewriting)."""

from __future__ import annotations

import sys
from typing import Literal

import typer
from rich.console import Console

from ptk.hooks.agents import (
    claude,
    cline,
    codex,
    cursor,
    gemini,
    jules,
    windsurf,
)
from ptk.hooks.gemini_hook import gemini_hook_output_for_stdin

hook_app = typer.Typer(help="Manage specific AI agent hooks")
console = Console()


def cmd_init(
    global_: bool = typer.Option(False, "--global", "-g", help="Install globally"),
    shell: Literal["bash", "powershell"] = typer.Option(
        "bash",
        "--shell",
        "-s",
        help="Shell type to target for the hook",
    ),
    codex_only: bool = typer.Option(
        False,
        "--codex",
        help="Install Codex CLI instruction files only (PTK.md + AGENTS.md)",
    ),
) -> None:
    """Install ptk hooks in supported AI agents."""
    if codex_only:
        console.print("[bold]Installing Codex CLI instructions...[/bold]")
        codex.install(global_=global_, console=console)
        console.print("[bold green]Done.[/bold green]")
        return

    console.print("[bold]Installing agent hooks...[/bold]")
    claude.install(global_=global_, shell=shell)
    if shell == "powershell":
        cursor.install_powershell(console=console)
        gemini.install_powershell(console=console)
    else:
        cursor.install_bash(console=console)
        gemini.install_bash(console=console)
    jules.install(console=console)
    cline.install(console=console)
    windsurf.install(console=console)
    console.print("[bold green]Installation complete![/bold green]")


@hook_app.command("install")
def cmd_hook_install(
    agent: str = typer.Argument(..., help="Agent name to hook"),
    shell: Literal["bash", "powershell"] = typer.Option(
        "bash",
        "--shell",
        "-s",
        help="Shell type to target for the hook",
    ),
    global_: bool = typer.Option(
        False,
        "--global",
        "-g",
        help="Use global paths where supported (e.g. ~/.codex, ~/.claude)",
    ),
) -> None:
    """Install a hook for a specific agent."""
    name = agent.lower()
    if name == "claude":
        claude.install(global_=global_, shell=shell)
    elif name == "cursor":
        if shell == "powershell":
            cursor.install_powershell(console=console)
        else:
            cursor.install_bash(console=console)
    elif name == "gemini":
        if shell == "powershell":
            gemini.install_powershell(console=console)
        else:
            gemini.install_bash(console=console)
    elif name == "codex":
        codex.install(global_=global_, console=console)
    elif name in ("jules", "baton"):
        jules.install(console=console)
    elif name in ("cline", "roo-code"):
        cline.install(console=console)
    elif name == "windsurf":
        windsurf.install(console=console)
    else:
        console.print(f"[yellow]Agent '{agent}' not currently supported for manual hook.[/yellow]")


@hook_app.command("verify")
def cmd_hook_verify(
    agent: str = typer.Argument(None, help="Agent name to verify (leave empty for all)"),
    shell: Literal["bash", "powershell"] = typer.Option(
        "bash",
        "--shell",
        "-s",
        help="Shell type of the hook to verify",
    ),
) -> None:
    """Verify one or all AI agent hooks."""
    import subprocess
    from pathlib import Path

    agents_to_verify = [agent.lower()] if agent else ["claude", "cursor", "gemini", "jules", "cline", "windsurf"]
    home = Path.home()
    results = []

    for name in agents_to_verify:
        script_path = None
        is_project_local = False
        
        # Determine script path for each agent
        if name == "cursor":
            ext = "ps1" if shell == "powershell" else "sh"
            script_path = home / ".cursor" / "hooks" / f"ptk-rewrite.{ext}"
        elif name == "gemini":
            ext = "ps1" if shell == "powershell" else "sh"
            script_path = home / ".gemini" / "hooks" / f"ptk-hook-gemini.{ext}"
        elif name == "claude":
            script_path = home / ".claude" / "settings.json"
        elif name in ("jules", "baton"):
            script_path = Path(".julesrules")
            is_project_local = True
        elif name in ("cline", "roo-code"):
            script_path = Path(".clinerules")
            is_project_local = True
        elif name == "windsurf":
            script_path = Path(".windsurfrules")
            is_project_local = True

        if not script_path:
            continue

        if not script_path.exists():
            if agent:  # Only error out if the user specifically asked for this agent
                console.print(f"[red]Hook target for {name} not found at {script_path}[/red]")
                if is_project_local:
                    console.print("[dim]Note: Jules/Cline/Windsurf use project-local rules files.[/dim]")
                raise typer.Exit(1)
            continue

        console.print(f"[bold]Verifying {name} hook...[/bold]")

        success = False
        if name == "claude":
            content = script_path.read_text(encoding="utf-8")
            if "ptk rewrite" in content:
                console.print("[green]✓ Claude Code settings.json correctly references ptk rewrite.[/green]")
                success = True
            else:
                console.print("[red]! Claude Code settings.json does NOT contain ptk rewrite hook.[/red]")
        
        elif is_project_local:
            content = script_path.read_text(encoding="utf-8")
            if "ptk" in content.lower():
                console.print(f"[green]✓ {script_path} correctly refers to ptk instructions.[/green]")
                success = True
            else:
                console.print(f"[red]! {script_path} does NOT contain ptk optimization rules.[/red]")

        else:
            # Script-based verification for Cursor/Gemini
            test_json = ""
            if name == "cursor":
                test_json = '{"tool_input":{"command":"git status"}}'
            elif name == "gemini":
                test_json = '{"tool_name":"run_shell_command","tool_input":{"command":"git status"}}'

            try:
                if shell == "powershell":
                    from ptk.hooks.powershell import find_powershell_executable
                    pwsh = find_powershell_executable() or "powershell"
                    proc = subprocess.run(
                        [pwsh, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path.resolve())],
                        input=test_json, capture_output=True, text=True, timeout=5,
                    )
                else:
                    proc = subprocess.run(
                        ["bash", str(script_path.resolve())],
                        input=test_json, capture_output=True, text=True, timeout=5,
                    )

                if proc.returncode == 0:
                    output = proc.stdout.strip()
                    if "ptk" in output.lower():
                        console.print(f"[green]✓ {name} hook correctly rewrote test command.[/green]")
                        success = True
                    else:
                        console.print(f"[red]! {name} hook returned output but command was not rewritten.[/red]")
                else:
                    console.print(f"[red]! {name} hook failed with exit code {proc.returncode}[/red]")
            except Exception as e:
                console.print(f"[red]Failed to verify {name}: {e}[/red]")
        
        results.append(success)

    if not results and agent:
        console.print(f"[yellow]Verification for agent '{agent}' is not yet implemented.[/yellow]")
    elif all(results) and results:
        console.print("\n[bold green]All agents verified successfully![/bold green]")
    elif any(results):
        console.print("\n[bold yellow]Some agents failed verification. Check the logs above.[/bold yellow]")
    elif not agent and not results:
        console.print("[yellow]No supported agents found to verify.[/yellow]")


def cmd_hook_gemini() -> None:
    """Gemini CLI BeforeTool hook: read JSON from stdin, print Gemini JSON response."""
    typer.echo(gemini_hook_output_for_stdin(sys.stdin.read()))


def find_rewrite(cmd: str) -> str | None:
    """Map a raw shell command to a `ptk` equivalent when a filter exists."""
    c = cmd.strip()
    if c.startswith("ptk "):
        return None

    parts = c.split()
    if not parts:
        return None

    binary = parts[0]
    subcmds = parts[1:]

    supported_git = [
        "status",
        "diff",
        "log",
        "show",
        "add",
        "commit",
        "push",
        "pull",
        "fetch",
        "branch",
        "stash",
        "worktree",
    ]
    if binary == "git" and subcmds and subcmds[0] in supported_git:
        return f"ptk git {' '.join(subcmds)}"

    if binary in ("npm", "pnpm"):
        return f"ptk {binary} {' '.join(subcmds)}"

    if binary == "pytest":
        return f"ptk pytest {' '.join(subcmds)}"

    if binary == "ruff":
        return f"ptk ruff {' '.join(subcmds)}"

    if binary == "mypy":
        return f"ptk mypy {' '.join(subcmds)}"

    if binary == "pip":
        return f"ptk pip {' '.join(subcmds)}"

    if binary == "uv" and subcmds and subcmds[0] == "pip":
        return f"ptk uv {' '.join(subcmds)}"

    if binary == "python" and len(subcmds) >= 2 and subcmds[0] == "-m":
        module = subcmds[1]
        rest = subcmds[2:]
        if module == "pytest":
            return f"ptk pytest {' '.join(rest)}"
        if module == "ruff":
            return f"ptk ruff {' '.join(rest)}"
        if module == "mypy":
            return f"ptk mypy {' '.join(rest)}"
        if module == "pip":
            return f"ptk pip {' '.join(rest)}"

    if binary == "cargo":
        return "ptk cargo" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "gh":
        return "ptk gh" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "docker":
        return "ptk docker" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "kubectl":
        return "ptk kubectl" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "curl":
        return "ptk curl" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "wget":
        return "ptk wget" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "rg":
        return "ptk rg" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "ls":
        return "ptk ls" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "env":
        return "ptk env" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "tree":
        return "ptk tree" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "diff":
        return "ptk diff" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "grep":
        return "ptk grep" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "find":
        return "ptk find" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "aws":
        return "ptk aws" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "psql":
        return "ptk psql" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "wc":
        return "ptk wc" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "go":
        return "ptk go" + (f" {' '.join(subcmds)}" if subcmds else "")

    if binary == "npx" and subcmds:
        tool = subcmds[0].removeprefix("./").lower()
        routed = {"eslint", "tsc", "vitest", "prettier", "prisma", "next", "playwright"}
        if tool in routed or tool.startswith("eslint") or tool.startswith("vitest"):
            return f"ptk npx {' '.join(subcmds)}"

    return None


def cmd_rewrite(
    args: list[str] = typer.Argument(..., help="Raw command args to rewrite"),  # noqa: B008
) -> None:
    """Rewrite a raw command to its ptk equivalent. Exit 0 if rewritten, 1 if not."""
    cmd = " ".join(args)
    rewritten = find_rewrite(cmd)

    if rewritten:
        typer.echo(rewritten)
        raise typer.Exit(0)
    raise typer.Exit(1)
