# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateVoiceResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'trace_id': 'str',
        'result': 'RegisterVoiceResponseBodyResult'
    }

    attribute_map = {
        'trace_id': 'trace_id',
        'result': 'result'
    }

    def __init__(self, trace_id=None, result=None):
        r"""CreateVoiceResponse

        The model defined in huaweicloud sdk

        :param trace_id: 服务内部的令牌，可用于在日志中追溯具体流程。
        :type trace_id: str
        :param result: 
        :type result: :class:`huaweicloudsdksis.v1.RegisterVoiceResponseBodyResult`
        """
        
        super().__init__()

        self._trace_id = None
        self._result = None
        self.discriminator = None

        if trace_id is not None:
            self.trace_id = trace_id
        if result is not None:
            self.result = result

    @property
    def trace_id(self):
        r"""Gets the trace_id of this CreateVoiceResponse.

        服务内部的令牌，可用于在日志中追溯具体流程。

        :return: The trace_id of this CreateVoiceResponse.
        :rtype: str
        """
        return self._trace_id

    @trace_id.setter
    def trace_id(self, trace_id):
        r"""Sets the trace_id of this CreateVoiceResponse.

        服务内部的令牌，可用于在日志中追溯具体流程。

        :param trace_id: The trace_id of this CreateVoiceResponse.
        :type trace_id: str
        """
        self._trace_id = trace_id

    @property
    def result(self):
        r"""Gets the result of this CreateVoiceResponse.

        :return: The result of this CreateVoiceResponse.
        :rtype: :class:`huaweicloudsdksis.v1.RegisterVoiceResponseBodyResult`
        """
        return self._result

    @result.setter
    def result(self, result):
        r"""Sets the result of this CreateVoiceResponse.

        :param result: The result of this CreateVoiceResponse.
        :type result: :class:`huaweicloudsdksis.v1.RegisterVoiceResponseBodyResult`
        """
        self._result = result

    def to_dict(self):
        import warnings
        warnings.warn("CreateVoiceResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateVoiceResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
