# BimPlugins Licensing SDK

A secure Python SDK for validating licenses with the BIM Plugins Local License Server.

## Overview

The BimPlugins Licensing SDK provides a simple interface for applications to check license validity through a local license server. The SDK handles secure communication via Windows named pipes, including cryptographic handshake and AES-256 encryption.

## Requirements

- **Python**: 3.10 or higher
- **Operating System**: Windows only (uses Windows named pipes and registry)
- **Dependencies**: 
  - `pycryptodome` - Cryptographic operations
  - `netifaces-plus` - Network interface information

## Installation

Install via pip:

```bash
pip install bimplugins-licensing-sdk-sds2
```

## Quick Start

```python
from bimplugins.LicenseManager import LicenseManager
from bimplugins.Models import ResponseStatus

# Check license for your application
response = LicenseManager.CheckForLicense("your-application-id")

# Check the response status
if response.status == ResponseStatus.Success:
    print(f"License valid until: {response.license_expires_at}")
elif response.status == ResponseStatus.Expiring:
    print(f"License is expiring soon! Expires: {response.license_expires_at}")
else:
    print(f"License check failed: {response.error_message} \t status: {response.status}")
```

## API Reference

### LicenseManager

The main entry point for license validation.

#### Methods

**`CheckForLicense(application_id: str) -> LicenseCheckResponse`**

Checks for a valid license for the specified application ID.

- **Parameters:**
  - `application_id` (str): The ID of the application to check
  
- **Returns:** `LicenseCheckResponse` object containing license information and status

### LicenseCheckResponse

Response object containing license validation results.

#### Properties

- `request_id` (str): Unique identifier for this request
- `status` (ResponseStatus): Status code indicating the result
- `license_expires_at` (datetime): Expiration date/time of the license (if valid)
- `error_message` (str): Error description (if applicable)
- `is_trial` (bool): Whether this is a trial license
- `trial_ends_at` (datetime | None): Trial expiration date (if trial license)

#### ResponseStatus Enum

| Status | Value | Description |
|--------|-------|-------------|
| `Success` | 200 | License is valid and active |
| `Expiring` | 201 | License is valid but expiring within 7 days |
| `BadRequest` | 400 | Invalid request format |
| `LicenseExpired` | 401 | License has expired |
| `LicenseNotFound` | 404 | No license found for application |
| `InternalError` | 500 | Internal server error |
| `LicenseNotAssigned` | 503 | License exists but not assigned |
| `ServerNotAvailable` | 504 | License server is not running |
| `CheckoutExpired` | 505 | License checkout has expired |
| `TrialExpired` | 506 | Trial license has expired |

### LicenseCheckRequest

Request object for license validation (typically used internally).

#### Properties

- `request_id` (str): Unique identifier (auto-generated)
- `request_time` (datetime): Request timestamp (auto-generated)
- `application_id` (str): The application ID to validate

## Error Handling

The SDK communicates with a local license server via named pipe. Common failure scenarios:

```python
from bimplugins.LicenseManager import LicenseManager
from bimplugins.Models import ResponseStatus

response = LicenseManager.CheckForLicense("my-app-id")

if response.status == ResponseStatus.ServerNotAvailable:
    print("License server is not running. Please start the BIM Plugins Local License Server.")
elif response.status == ResponseStatus.LicenseNotFound:
    print("No license found for this application.")
elif response.status == ResponseStatus.LicenseExpired:
    print("Your license has expired. Please renew your subscription.")
elif response.status == ResponseStatus.TrialExpired:
    print(f"Your trial has ended (expired {response.trial_ends_at}). Please purchase a license.")
elif response.status == ResponseStatus.CheckoutExpired:
    print("License checkout has expired. Please reconnect to the license server.")
elif response.status == ResponseStatus.Expiring:
    print(f"License valid but expiring soon on {response.license_expires_at}.")
    if response.is_trial:
        print(f"Trial ends: {response.trial_ends_at}")
elif response.status == ResponseStatus.Success:
    print("License validated successfully!")
```

## Platform Requirements

This SDK is designed exclusively for **Windows** platforms and requires:
- The BIM Plugins Local License Server to be installed and running
- Valid Windows registry entries for machine identification
- Named pipe access (`\\.\pipe\BimPlugins`)

## Security

All communications between the SDK and the local license server are encrypted using AES-256-CBC encryption with a machine-specific key derivation. The SDK source code is obfuscated to protect the licensing implementation.

## Support

For support, documentation, or to purchase licenses, visit [https://bim-plugins.com](https://bim-plugins.com)

## License

**Proprietary License** - Copyright © 2026 BIM Plugins. All rights reserved.

You may use this SDK to build and distribute applications, but you may NOT modify or redistribute the SDK itself. See the [LICENSE](LICENSE) file for complete terms and conditions.
