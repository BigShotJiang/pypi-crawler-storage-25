"""
BimPlugins Licensing SDK

A Python SDK for validating licenses with the Bim Plugins Local License Server.

Main Components:
    - LicenseManager: Primary interface for license validation
    - Models: Data classes for requests, responses, and status codes

Example Usage:
    >>> from bimplugins.LicenseManager import LicenseManager
    >>> from bimplugins.Models import ResponseStatus
    >>> 
    >>> manager = LicenseManager()
    >>> response = manager.CheckForLicense("your-application-id")
    >>> 
    >>> if response.status == ResponseStatus.Success:
    >>>     print(f"License valid until: {response.license_expires_at}")
    >>> else:
    >>>     print(f"Error: {response.error_message}")

Requirements:
    - Python 3.12 or higher
    - Windows operating system
    - Bim Plugins Local License Server installed and running

Copyright (c) 2026 Bim Plugins. All Rights Reserved.
Licensed under proprietary license - see LICENSE for details.
"""

from .LicenseManager import LicenseManager
from .Models import (
    LicenseCheckRequest,
    LicenseCheckResponse,
    RequestType,
    ResponseStatus
)

__version__ = "0.1.0"
__author__ = "Travis Pettry"
__email__ = "tpettry@bim-plugins.com"

__all__ = [
    "LicenseManager",
    "LicenseCheckRequest",
    "LicenseCheckResponse",
    "RequestType",
    "ResponseStatus",
]
