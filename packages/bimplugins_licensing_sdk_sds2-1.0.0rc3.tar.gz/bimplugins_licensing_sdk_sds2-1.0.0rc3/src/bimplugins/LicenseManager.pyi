"""
Type stubs for BimPlugins Licensing SDK - LicenseManager module
"""

from .Models import LicenseCheckResponse

class LicenseManager:
	"""
	Main interface for license validation with the Bim Plugins Local License Server.
	
	Example:
		>>> from bimplugins.LicenseManager import LicenseManager
		>>> from bimplugins.Models import ResponseStatus
		>>> 
		>>> manager = LicenseManager()
		>>> response = manager.CheckForLicense("my-application-id")
		>>> 
		>>> if response.status == ResponseStatus.Success:
		>>>     print(f"License valid until: {response.license_expires_at}")
		>>> else:
		>>>     print(f"License check failed: {response.error_message}")
	"""
	
	def __init__(self) -> None:
		"""Initialize the LicenseManager."""
		...
	
	def CheckForLicense(self, application_id: str) -> LicenseCheckResponse:
		"""
		Check for a valid license for the specified application ID.
		
		Args:
			application_id: The unique ID of the application to validate
			
		Returns:
			LicenseCheckResponse containing validation results:
				- status: ResponseStatus enum indicating success or failure reason
				- license_expires_at: Expiration date if license is valid
				- error_message: Description of error if validation failed
				- request_id: Unique identifier for this validation request
		"""
		...
