"""
Type stubs for BimPlugins Licensing SDK - Models module

Provides data models for license validation requests and responses.
"""

import datetime
from enum import Enum
from typing import Optional, Dict, Any

class RequestType(Enum):
    """Type of request being made to the license server."""
    LicenseCheck = "LicenseCheck"

class ResponseStatus(Enum):
    """
    Status codes returned by license validation.
    
    Attributes:
        Success (200): License is valid and active
        BadRequest (400): Invalid request format or parameters
        LicenseExpired (401): License has expired
        LicenseNotFound (404): No license found for the application
        InternalError (500): Internal server error occurred
        LicenseNotAssigned (503): License exists but not assigned to this machine
        ServerNotAvailable (504): License server is not running
        CheckoutExpired (505): License checkout has expired
        Expiring (201): License is valid but expiring within 7 days
    """
    Success: int
    Expiring: int
    BadRequest: int
    LicenseExpired: int
    LicenseNotFound: int
    InternalError: int
    LicenseNotAssigned: int
    ServerNotAvailable: int
    CheckoutExpired: int
    TrialExpired: int

class LicenseCheckRequest:
    """
    Request object for license validation.
    
    Attributes:
        request_id (str): Unique identifier for this request (auto-generated)
        request_time (datetime): Timestamp when request was created (auto-generated)
        application_id (str): The application ID to validate
    """
    
    request_id: Optional[str]
    request_time: Optional[datetime.datetime]
    application_id: Optional[str]
    
    def __init__(self, application_id: Optional[str] = None) -> None:
        """
        Initialize a license check request.
        
        If application_id is provided, request_id and request_time are automatically 
        generated. Otherwise, all fields remain None.
        
        Args:
            application_id: The ID of the application to check license for
        """
        ...
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the request to a dictionary representation.
        
        Returns:
            Dictionary with RequestId, RequestTime, and ApplicationId keys
        """
        ...
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LicenseCheckRequest':
        """
        Create a LicenseCheckRequest from a dictionary.
        
        Args:
            data: Dictionary containing request data
            
        Returns:
            New LicenseCheckRequest instance
        """
        ...

class LicenseCheckResponse:
    """
    Response object containing license validation results.
    
    Attributes:
        request_id (str): Unique identifier matching the request
        status (ResponseStatus): Status code indicating result
        license_expires_at (datetime): Expiration date/time of license (if valid)
        error_message (str): Description of error (if applicable)
    """
    
    request_id: Optional[str]
    status: Optional[ResponseStatus]
    license_expires_at: Optional[datetime.datetime]
    error_message: Optional[str]
    is_trial: Optional[bool]
    trial_ends_at: Optional[datetime.datetime]
    
    def __init__(
        self,
        request_id: Optional[str] = None,
        status: Optional[ResponseStatus] = None,
        license_expires_at: Optional[datetime.datetime] = None,
        error_message: Optional[str] = None,
        is_trial: Optional[bool] = None,
        trial_ends_at: Optional[datetime.datetime] = None
    ) -> None:
        """
        Initialize a license check response.
        
        Args:
            request_id: Unique identifier for the request
            status: Response status code
            license_expires_at: License expiration date/time
            error_message: Error description if validation failed
        """
        ...
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the response to a dictionary representation.
        
        Returns:
            Dictionary with RequestId, Status, LicenseExpiresAt, and ErrorMessage keys
        """
        ...
    
    @staticmethod
    def parse_datetime_with_truncated_microseconds(dt_str: Optional[str]) -> Optional[datetime.datetime]:
        """
        Parse datetime string with microsecond truncation for compatibility.
        
        Args:
            dt_str: ISO format datetime string
            
        Returns:
            Parsed datetime object or None if parsing fails
        """
        ...
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LicenseCheckResponse':
        """
        Create a LicenseCheckResponse from a dictionary.
        
        Args:
            data: Dictionary containing response data
            
        Returns:
            New LicenseCheckResponse instance
        """
        ...
    
    @staticmethod
    def from_json(json_string: str) -> 'LicenseCheckResponse':
        """
        Create a LicenseCheckResponse directly from a JSON string.
        
        Args:
            json_string: JSON-formatted string containing response data
            
        Returns:
            New LicenseCheckResponse instance
        """
        ...
