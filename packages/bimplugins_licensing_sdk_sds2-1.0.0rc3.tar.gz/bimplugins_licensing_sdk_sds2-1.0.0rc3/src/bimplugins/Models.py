import uuid
import datetime
from enum import Enum
import json
import re

class LicenseCheckRequest:
    def __init__(self, application_id=None):
        """
        If application_id is provided, the request_id and request_time 
        are automatically generated. Otherwise, they remain None.
        """
        if application_id is not None:
            self.request_id = str(uuid.uuid4())
            self.request_time = datetime.datetime.utcnow()
            self.application_id = application_id
        else:
            self.request_id = None
            self.request_time = None
            self.application_id = None

    def to_dict(self):
        return {
            "RequestId": self.request_id,
            # Convert `request_time` to string if it's not `None`
            "RequestTime": self.request_time.isoformat() if self.request_time else None,
            "ApplicationId": self.application_id,
        }

    @classmethod
    def from_dict(cls, data: dict):
        """
        Recreate a LicenseCheckRequest from a dict that was created
        by `to_dict()`.
        """
        # We don't necessarily want to generate a new UUID/time if they already exist in data
        # so we'll just build an empty object and set the fields manually.
        obj = cls()
        obj.request_id = data.get("RequestId")
        request_time_str = data.get("RequestTime")
        if request_time_str:
            obj.request_time = datetime.datetime.fromisoformat(request_time_str)
        obj.application_id = data.get("ApplicationId")
        return obj


class LicenseCheckResponse:
    def __init__(self, request_id=None, status=None, license_expires_at=None, error_message=None, is_trial=None, trial_ends_at=None):
        self.request_id = request_id
        self.status = status
        self.license_expires_at = license_expires_at
        self.error_message = error_message
        self.is_trial = is_trial
        self.trial_ends_at = trial_ends_at

    def to_dict(self):
        return {
            "RequestId": self.request_id,
            # If status is an Enum, convert it to its name (or value).
            "Status": self.status.name if self.status else None,
            # Convert license_expires_at to ISO string if not None
            "LicenseExpiresAt": self.license_expires_at.isoformat() if self.license_expires_at else None,
            "ErrorMessage": self.error_message,
            "IsTrial": self.is_trial,
            "TrialEndsAt": self.trial_ends_at.isoformat() if self.trial_ends_at else None,
        }
    
    @staticmethod
    def parse_datetime_with_truncated_microseconds(dt_str):
        if not dt_str:
            return None

        try:
            # Use regex to split datetime and timezone parts
            match = re.match(r"^(.*?)(\+|-)?(\d{2}:\d{2})?$", dt_str)
            if not match:
                raise ValueError("Invalid datetime format")

            base_dt, tz_sign, tz_offset = match.groups()
            if not base_dt:
                raise ValueError("Missing datetime part")

            # Split base datetime into parts (before and after decimal)
            base_dt_parts = base_dt.split(".")
            if len(base_dt_parts) > 1:
                # Validate fractional part is numeric
                fractional_part = base_dt_parts[1].split("+")[0].split("-")[0]  # Remove timezone if present
                if not fractional_part.isdigit():
                    raise ValueError("Invalid fractional part in datetime string")
                if len(fractional_part) > 6:
                    # Truncate microseconds to 6 digits
                    base_dt = f"{base_dt_parts[0]}.{fractional_part[:6]}"

            # Reconstruct the string
            fixed_dt_str = base_dt
            if tz_sign and tz_offset:
                fixed_dt_str += f"{tz_sign}{tz_offset}"

            return datetime.datetime.fromisoformat(fixed_dt_str)
        except (ValueError, IndexError) as e:
            print(f"Error parsing datetime string '{dt_str}': {e}")
            return None

    @classmethod
    def from_dict(cls, data: dict):
        request_id = data.get("RequestId")

        # Convert string back to enum if not None
        status_val = data.get("Status")
        status = None
        if status_val is not None:
            status = ResponseStatus(status_val)  # e.g. 404 -> ResponseStatus.LicenseNotFound

        expires_str = data.get("LicenseExpiresAt")
        license_expires_at = (
            cls.parse_datetime_with_truncated_microseconds(expires_str)
            if expires_str
            else None
        )

        error_message = data.get("ErrorMessage")

        return cls(
            request_id=request_id,
            status=status,
            license_expires_at=license_expires_at,
            error_message=error_message,
            is_trial=data.get("IsTrial"),
            trial_ends_at=(
                cls.parse_datetime_with_truncated_microseconds(data.get("TrialEndsAt"))
                if data.get("TrialEndsAt")
                else None
            )
        )

    @staticmethod
    def from_json(json_string):
        """Build a LicenseCheckResponse directly from a JSON string."""
        d = json.loads(json_string)
        return LicenseCheckResponse.from_dict(d)


class RequestType(Enum):
    LicenseCheck = "LicenseCheck"

class ResponseStatus(Enum):
    Success = 200
    Expiring = 201
    BadRequest = 400
    LicenseExpired = 401
    LicenseNotFound = 404
    InternalError = 500
    LicenseNotAssigned = 503
    ServerNotAvailable = 504,
    CheckoutExpired = 505
    TrialExpired = 506
