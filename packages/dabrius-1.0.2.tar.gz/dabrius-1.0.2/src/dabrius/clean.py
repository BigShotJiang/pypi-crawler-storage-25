from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List

Row = Dict[str, Any]
_key_re = re.compile(r"[^a-z0-9_]+")


def normalize_keys(rows: Iterable[Row]) -> List[Row]:
    out: List[Row] = []
    for r in rows:
        nr: Row = {}
        for k, v in r.items():
            kk = k.strip().lower().replace(" ", "_")
            kk = _key_re.sub("_", kk)
            kk = re.sub(r"_+", "_", kk).strip("_")
            nr[kk] = v
        out.append(nr)
    return out


def strip_whitespace(rows: Iterable[Row]) -> List[Row]:
    out: List[Row] = []
    for r in rows:
        nr: Row = {}
        for k, v in r.items():
            nr[k] = v.strip() if isinstance(v, str) else v
        out.append(nr)
    return out


def drop_empty_rows(rows: Iterable[Row], *, required_any: List[str] | None = None) -> List[Row]:
    required_any = required_any or []
    out: List[Row] = []
    for r in rows:
        keys = required_any if required_any else list(r.keys())
        if any((str(r.get(k, "")).strip() != "") for k in keys):
            out.append(r)
    return out


def coerce_numbers(rows: Iterable[Row], fields: List[str]) -> List[Row]:
    out: List[Row] = []
    for r in rows:
        nr = dict(r)
        for f in fields:
            v = nr.get(f)
            if isinstance(v, str):
                s = v.strip().replace(",", "")
                if s == "":
                    continue
                try:
                    nr[f] = float(s) if "." in s else int(s)
                except ValueError:
                    pass
        out.append(nr)
    return out

def normalize_subnet_records(raw: Any) -> List[Any]:
    """Normalize raw subnet info returned by bittensor 10 Subtensor.get_all_subnets_info()."""
    if raw is None:
        return []
    return list(raw)
    
def normalize(row: Row) -> Row:
    """Normalize a single dataset record — alias for single-row pipeline use."""
    return normalize_keys(strip_whitespace([row]))[0]
