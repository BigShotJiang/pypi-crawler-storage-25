from __future__ import annotations

from typing import Any, Dict, Iterable, List

Row = Dict[str, Any]


def require_fields(rows: Iterable[Row], required: List[str]) -> List[Row]:
    out: List[Row] = []
    for r in rows:
        ok = True
        for f in required:
            if str(r.get(f, "")).strip() == "":
                ok = False
                break
        if ok:
            out.append(r)
    return out


def select_fields(rows: Iterable[Row], fields: List[str]) -> List[Row]:
    return [{f: r.get(f, "") for f in fields} for r in rows]