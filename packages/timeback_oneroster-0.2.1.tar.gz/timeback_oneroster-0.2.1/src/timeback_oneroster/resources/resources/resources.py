"""
Resources Resource

Access and manage digital learning resources.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict, Field

from timeback_common import validate_sourced_id

from ...types.resources import Resource
from ...utils import parse_grades
from ..base import CRUDResourceNoSearch

if TYPE_CHECKING:
    from ...lib.transport import Transport


def normalize_resource_from_api(resource: Resource | dict) -> Resource:
    """
    Normalize API fields on a resource (e.g. string ``metadata.grades`` → numeric grades).

    Shared by scoped ``get()``, ``ResourcesResource._transform``, and course-scoped
    resource paginators.

    Args:
        resource: Raw resource from the OneRoster API (dict or model)

    Returns:
        Resource with normalized metadata when present
    """
    if isinstance(resource, dict):
        resource = Resource(**resource)
    if not resource.metadata:
        return resource

    metadata = dict(resource.metadata)
    metadata["grades"] = parse_grades(metadata.get("grades"))
    return resource.model_copy(update={"metadata": metadata})


# ═══════════════════════════════════════════════════════════════════════════════
# SCOPED RESOURCE RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class ScopedResourceResource:
    """
    Scoped resource for operations on a specific resource.

    Access via `client.resources(resource_id)`.

    Example:
        ```python
        resource = await client.resources(resource_id).get()
        await client.resources(resource_id).export()
        ```
    """

    def __init__(self, transport: Transport, resource_id: str) -> None:
        validate_sourced_id(resource_id, "resource")
        self._transport = transport
        self._resource_id = resource_id
        self._base_path = f"{transport.paths.resources}/resources/{resource_id}"

    async def get(self) -> Resource:
        """Get the resource details."""
        response = await self._transport.get(self._base_path)
        return normalize_resource_from_api(response["resource"])

    async def exists(self) -> bool:
        """Check whether this resource exists."""
        return await self._transport.exists(self._base_path)

    async def export(self) -> bytes:
        """
        Export this resource as a ZIP archive.

        Returns:
            Raw bytes of the exported ZIP file
        """
        response = await self._transport.request_raw(
            "POST",
            f"{self._transport.paths.resources}/resources/export/{self._resource_id}",
            headers={"Accept": "application/zip"},
        )
        return response.content


# ═══════════════════════════════════════════════════════════════════════════════
# RESOURCES RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class ResourcesResource(CRUDResourceNoSearch[Resource]):
    """
    Resource for digital learning resources.

    Resources represent external content that can be assigned to
    students through courses and classes.

    Example:
        ```python
        # List all resources
        resources = await client.resources.list()

        # Get specific resource
        resource = await client.resources.get("resource-id")

        # Create a resource
        await client.resources.create({
            "title": "Algebra Lesson 1",
            "vendorResourceId": "ext-123",
            "importance": "primary",
        })

        # Export a resource
        await client.resources.export("resource-id")
        # Or via scoped resource:
        await client.resources("resource-id").export()
        ```
    """

    def __init__(self, transport: Transport) -> None:
        # Use the resources service path
        super().__init__(transport, "resources", "/resources")

    @property
    def _unwrap_key(self) -> str:
        return "resources"

    @property
    def _wrap_key(self) -> str:
        return "resource"

    @property
    def _model_class(self) -> type[Resource]:
        return Resource

    @property
    def _create_schema(self) -> type[BaseModel]:
        return _ResourceCreateMinimalInput

    @property
    def _update_schema(self) -> type[BaseModel]:
        return _ResourceUpdateMinimalInput

    def _transform(self, entity: dict | Resource) -> Resource:
        """Transform resource response by normalizing metadata grades."""
        return normalize_resource_from_api(entity)

    def __call__(self, resource_id: str) -> ScopedResourceResource:
        """Get scoped resource for a specific resource."""
        return ScopedResourceResource(self._transport, resource_id)

    async def export(self, resource_id: str) -> bytes:
        """
        Export a resource as a ZIP archive by ID.

        Args:
            resource_id: Resource sourcedId

        Returns:
            Raw bytes of the exported ZIP file
        """
        validate_sourced_id(resource_id, "resource")
        response = await self._transport.request_raw(
            "POST",
            f"{self._base_path}/export/{resource_id}",
            headers={"Accept": "application/zip"},
        )
        return response.content


class _ResourceCreateMinimalInput(BaseModel):
    title: str = Field(min_length=1)
    vendor_resource_id: str = Field(alias="vendorResourceId", min_length=1)

    model_config = ConfigDict(extra="allow", populate_by_name=True)


class _ResourceUpdateMinimalInput(BaseModel):
    title: str = Field(min_length=1)

    model_config = ConfigDict(extra="allow")
