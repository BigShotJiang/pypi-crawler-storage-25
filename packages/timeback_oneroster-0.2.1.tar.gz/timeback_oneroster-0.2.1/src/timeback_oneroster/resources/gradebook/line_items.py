"""
Line Items Resource

Access and manage gradebook line items (assignments, tests, etc.).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field

from timeback_common import (
    APIError,
    BulkCreateResponse,
    NotFoundError,
    validate_sourced_id,
    validate_with_schema,
)

from ...lib.pagination import Paginator
from ...lib.params import build_list_params_no_search
from ...types import LineItemCreateInput
from ...types.gradebook import LineItem, Result
from ..base import CRUDResourceNoSearch

if TYPE_CHECKING:
    from ...lib.filter import WhereClause
    from ...lib.transport import Transport


# ═══════════════════════════════════════════════════════════════════════════════
# SCOPED LINE ITEM RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class ScopedLineItemResource:
    """
    Scoped resource for operations on a specific line item.

    Access via `client.line_items(line_item_id)`.

    Example:
        ```python
        line_item = await client.line_items(line_item_id).get()
        results = await client.line_items(line_item_id).results()
        ```
    """

    def __init__(self, transport: Transport, line_item_id: str) -> None:
        validate_sourced_id(line_item_id, "line item")
        self._transport = transport
        self._line_item_id = line_item_id
        self._base_path = f"{transport.paths.gradebook}/lineItems/{line_item_id}"

    async def get(self) -> LineItem:
        """Get the line item details."""
        response = await self._transport.get(self._base_path)
        return LineItem(**response["lineItem"])

    async def exists(self) -> bool:
        """Check whether this line item exists."""
        return await self._transport.exists(self._base_path)

    async def delete(self) -> None:
        """Delete this line item."""
        await self._transport.delete(self._base_path)

    async def create_results(self, results: list[dict[str, Any]]) -> BulkCreateResponse:
        """
        Bulk create results for this line item.

        Use this to submit multiple student grades at once.

        Args:
            results: Array of results to create

        Returns:
            Bulk create response with list of sourcedIdPairs (one per result)

        Example:
            ```python
            response = await client.line_items(line_item_id).create_results([
                {"student": {"sourcedId": "student1"}, "score": 85},
                {"student": {"sourcedId": "student2"}, "score": 92},
            ])
            # Access individual pairs
            for pair in response.sourced_id_pairs:
                print(pair.allocated_sourced_id)
            ```
        """
        validate_with_schema(_CreateResultsInput, {"results": results}, "line item results")
        with_line_item = [
            {**r, "lineItem": r.get("lineItem", {"sourcedId": self._line_item_id})} for r in results
        ]
        response = await self._transport.post(
            f"{self._base_path}/results",
            {"results": with_line_item},
        )
        return BulkCreateResponse.model_validate(response)

    # ── Results ────────────────────────────────────────────────────────────────

    async def results(
        self,
        *,
        limit: int = 100,
        offset: int | None = None,
        sort: str | None = None,
        order_by: str | None = None,
        where: WhereClause | None = None,
        fields: list[str] | None = None,
    ) -> list[Result]:
        """List results for this line item."""
        return await self.stream_results(
            limit=limit,
            offset=offset,
            sort=sort,
            order_by=order_by,
            where=where,
            fields=fields,
        ).to_list()

    def stream_results(
        self,
        *,
        limit: int = 100,
        offset: int | None = None,
        sort: str | None = None,
        order_by: str | None = None,
        where: WhereClause | None = None,
        fields: list[str] | None = None,
        max_items: int | None = None,
    ) -> Paginator[Result]:
        """Stream results with lazy pagination."""
        params = build_list_params_no_search(
            offset=offset,
            sort=sort,
            order_by=order_by,
            where=where,
            fields=fields,
        )

        return Paginator(
            self._transport,
            f"{self._base_path}/results",
            unwrap_key="results",
            params=params,
            limit=limit,
            max_items=max_items,
        )


# ═══════════════════════════════════════════════════════════════════════════════
# LINE ITEMS RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class LineItemsResource(CRUDResourceNoSearch[LineItem]):
    """
    Resource for gradebook line items.

    Line items represent gradable activities (assignments, tests, quizzes).

    Example:
        ```python
        # List all line items
        line_items = await client.line_items.list()

        # Get specific line item
        line_item = await client.line_items.get("line-item-id")

        # Get results for a line item
        results = await client.line_items("line-item-id").results()

        # Create a line item
        await client.line_items.create({
            "title": "Chapter 1 Quiz",
            "class": {"sourcedId": "class-id"},
            "assignDate": "2024-01-15",
            "dueDate": "2024-01-22",
            "resultValueMin": 0,
            "resultValueMax": 100,
        })

        # Filter by class
        class_items = await client.line_items.list(
            where={"class.sourcedId": "class-id"}
        )
        ```
    """

    def __init__(self, transport: Transport) -> None:
        super().__init__(transport, "gradebook", "/lineItems")

    @property
    def _unwrap_key(self) -> str:
        return "lineItems"

    @property
    def _wrap_key(self) -> str:
        return "lineItem"

    @property
    def _model_class(self) -> type[LineItem]:
        return LineItem

    @property
    def _create_schema(self) -> type[BaseModel]:
        """Pydantic model for validating line item create input."""
        return LineItemCreateInput

    @property
    def _update_schema(self) -> type[BaseModel]:
        """Pydantic model for validating line item update input."""
        return LineItemCreateInput

    @property
    def _server_natively_upserts(self) -> bool:
        return True

    async def update(self, sourced_id: str, data: dict[str, Any]) -> LineItem:
        """
        Update a line item and return the updated entity.

        Args:
            sourced_id: The line item sourcedId
            data: Updated line item data

        Returns:
            The updated line item

        Raises:
            NotFoundError: If the line item does not exist
        """
        validate_sourced_id(sourced_id, "update lineItems")
        await self._ensure_exists_for_update(sourced_id)
        return await self._send_update_and_return(sourced_id, data)

    async def upsert(self, sourced_id: str, data: dict[str, Any]) -> LineItem:
        """
        Create or update a line item, returning the entity.

        Tries PUT first. If 404, falls back to create then get.

        Args:
            sourced_id: The line item sourcedId
            data: Line item data (sourcedId is merged automatically)

        Returns:
            The created or updated line item
        """
        validate_sourced_id(sourced_id, "upsert lineItems")
        full_data = {**data, "sourcedId": sourced_id}
        try:
            return await self._send_update_and_return(sourced_id, full_data)
        except NotFoundError:
            await self.create(full_data)
            return await self.get(sourced_id)
        except APIError as error:
            if error.status_code != 404:
                raise
            await self.create(full_data)
            return await self.get(sourced_id)

    def __call__(self, line_item_id: str) -> ScopedLineItemResource:
        """Get scoped resource for a specific line item."""
        return ScopedLineItemResource(self._transport, line_item_id)


class _CreateResultsInput(BaseModel):
    results: list[dict[str, Any]] = Field(min_length=1)

    model_config = ConfigDict(extra="forbid")
