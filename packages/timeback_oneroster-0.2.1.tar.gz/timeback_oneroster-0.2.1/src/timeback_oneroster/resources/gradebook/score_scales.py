"""
Score Scales Resource

Access and manage score scales for grading.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from timeback_common import APIError, NotFoundError, validate_sourced_id

from ...types.gradebook import ScoreScale
from ...types.input import ScoreScaleCreateInput
from ..base import CRUDResourceNoSearch

if TYPE_CHECKING:
    from pydantic import BaseModel

    from ...lib.transport import Transport


# ═══════════════════════════════════════════════════════════════════════════════
# SCOPED SCORE SCALE RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class ScopedScoreScaleResource:
    """
    Scoped resource for operations on a specific score scale.

    Access via `client.score_scales(scale_id)`.

    Example:
        ```python
        scale = await client.score_scales(scale_id).get()
        ```
    """

    def __init__(self, transport: Transport, scale_id: str) -> None:
        self._transport = transport
        self._scale_id = scale_id
        self._base_path = f"{transport.paths.gradebook}/scoreScales/{scale_id}"

    async def get(self) -> ScoreScale:
        """Get the score scale details."""
        response = await self._transport.get(self._base_path)
        return ScoreScale(**response["scoreScale"])

    async def exists(self) -> bool:
        """Check whether this score scale exists."""
        return await self._transport.exists(self._base_path)

    async def delete(self) -> None:
        """Delete this score scale."""
        await self._transport.delete(self._base_path)


# ═══════════════════════════════════════════════════════════════════════════════
# SCORE SCALES RESOURCE
# ═══════════════════════════════════════════════════════════════════════════════


class ScoreScalesResource(CRUDResourceNoSearch[ScoreScale]):
    """
    Resource for score scales.

    Score scales define grading systems (e.g., letter grades, pass/fail).

    Example:
        ```python
        # List all score scales
        scales = await client.score_scales.list()

        # Get specific score scale
        scale = await client.score_scales.get("scale-id")

        # Create a score scale
        await client.score_scales.create({
            "title": "Letter Grades",
            "scoreScaleValues": [
                {"value": "A", "description": "90-100%"},
                {"value": "B", "description": "80-89%"},
                {"value": "C", "description": "70-79%"},
                {"value": "D", "description": "60-69%"},
                {"value": "F", "description": "Below 60%"},
            ]
        })
        ```
    """

    def __init__(self, transport: Transport) -> None:
        super().__init__(transport, "gradebook", "/scoreScales")

    @property
    def _unwrap_key(self) -> str:
        return "scoreScales"

    @property
    def _wrap_key(self) -> str:
        return "scoreScale"

    @property
    def _model_class(self) -> type[ScoreScale]:
        return ScoreScale

    @property
    def _create_schema(self) -> type[BaseModel]:
        return ScoreScaleCreateInput

    @property
    def _update_schema(self) -> type[BaseModel] | None:
        return None

    @property
    def _server_natively_upserts(self) -> bool:
        return True

    async def update(self, sourced_id: str, data: dict[str, Any]) -> ScoreScale:
        """Update a score scale and return the updated entity."""
        validate_sourced_id(sourced_id, "update scoreScales")
        await self._ensure_exists_for_update(sourced_id)
        return await self._send_update_and_return(sourced_id, data)

    async def upsert(self, sourced_id: str, data: dict[str, Any]) -> ScoreScale:
        """Create or update a score scale, returning the entity."""
        validate_sourced_id(sourced_id, "upsert scoreScales")
        full_data = {**data, "sourcedId": sourced_id}
        try:
            return await self._send_update_and_return(sourced_id, full_data)
        except NotFoundError:
            await self.create(full_data)
            return await self.get(sourced_id)
        except APIError as error:
            if error.status_code != 404:
                raise
            await self.create(full_data)
            return await self.get(sourced_id)

    def __call__(self, scale_id: str) -> ScopedScoreScaleResource:
        """Get scoped resource for a specific score scale."""
        return ScopedScoreScaleResource(self._transport, scale_id)
