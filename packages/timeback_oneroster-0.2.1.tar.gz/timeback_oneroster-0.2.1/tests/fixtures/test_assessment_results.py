"""Fixture-driven tests for OneRoster assessment-results resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_oneroster.client import OneRosterClient
from timeback_oneroster.lib.testing import create_recording_transport

FIXTURES_DIR = fixtures_dir("oneroster", "assessment-results")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    client = OneRosterClient(transport=transport)
    return {"resource": client.assessment_results, "calls": transport.calls}


test_oneroster_assessment_results_fixtures = make_resource_fixture_test(
    name="oneroster > assessment-results",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
