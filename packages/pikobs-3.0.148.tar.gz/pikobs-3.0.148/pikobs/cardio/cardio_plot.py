#!/usr/bin/python3

import os
import sys
import math
import sqlite3
import json
import time
import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.dates as mdates
import matplotlib.font_manager as font_manager
from datetime import datetime
import pikobs 

# =========================================================================
# HELPER FUNCTION: FLEXIBLE DATE PARSER
# =========================================================================
def parse_flexible_date(date_str):
    date_str = str(date_str).strip()
    formats = ['%Y%m%d%H', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%Y%m%d']
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    raise ValueError(f"The date format '{date_str}' is unknown.")

# =========================================================================
# HELPER FUNCTION: PANEL LIMITS MANAGEMENT (Region -> Family -> Channel -> Panel)
# =========================================================================
def get_smart_limit(pathwork, region, family, channel, panel_id, current_data_max):
    """
    Reads or calculates the Y limit for a specific panel.
    Uses one file per region. If a new limit is higher than the existing one
    (e.g., across different flag_criteria), it updates the file.
    """
    config_file = os.path.join(pathwork, f'y_limits_{region}.json')
    limits_config = {}

    # 1. ROBUST READ
    if os.path.exists(config_file):
        if os.path.getsize(config_file) == 0:
            time.sleep(random.uniform(0.05, 0.2))
        try:
            with open(config_file, 'r') as f:
                limits_config = json.load(f)
        except (json.JSONDecodeError, IOError):
            limits_config = {}

    # 2. ENSURE DICTIONARY STRUCTURE
    if family not in limits_config: 
        limits_config[family] = {}
    
    chan_key = f"ch_{channel}"
    if chan_key not in limits_config[family] or not isinstance(limits_config[family][chan_key], dict): 
        limits_config[family][chan_key] = {}

    # 3. CALCULATION LOGIC
    # Calculate the potential new limit with 15% margin
    if current_data_max <= 0:
        calculated_limit = 1.0
    else:
        order = 10 ** (int(math.log10(current_data_max))) if current_data_max > 0 else 1
        step = order / 2 if order >= 10 else 0.1
        calculated_limit = float(math.ceil(current_data_max / step) * step * 1.15)

    # 4. SELECT THE LARGEST LIMIT (Compare with existing one in JSON)
    existing_limit = limits_config[family][chan_key].get(panel_id, 0.0)
    
    if calculated_limit > existing_limit:
        # Update the dictionary with the larger value
        limits_config[family][chan_key][panel_id] = calculated_limit
        
        # 5. ATOMIC WRITE
        temp_file = config_file + f".tmp.{random.randint(0, 10000)}"
        try:
            with open(temp_file, 'w') as f:
                json.dump(limits_config, f, indent=4)
            os.replace(temp_file, config_file)
        except Exception:
            if os.path.exists(temp_file):
                os.remove(temp_file)
        return calculated_limit
    else:
        # Use the already stored larger limit
        return existing_limit

# =========================================================================
# MAIN FUNCTION: CARDIO PLOT
# =========================================================================
def cardio_plot(pathwork, datestart, dateend, flag_type, family, fig_title, plot_type, channel, id_stn, varno, region):
    
    plt.close('all')
    GREEN, BLUE, BLACK, RED = '#009900', '#0276FD', '#000000', '#D00000'
    MISSING = -99.9
    
    fig_size = (15.0, 13.5) if plot_type == 'wide' else (9.5, 14.5)
    is_oma = flag_type not in ('monitoring', 'bgckalt', 'bgckalt_qc')
        
    path_output_work = f'{pathwork}/{family}/cardio_{region}_{datestart}_{dateend}_{flag_type}_{family}.db'
    conn = sqlite3.connect(path_output_work)
    cursor = conn.cursor()
    
    crit_stn = f"AND id_stn='{id_stn}'" if id_stn != 'join' else ''
    crit_chan = f"AND Chan='{channel}'" if channel != 'join' else ''
    
    query = f"""
        SELECT DATE, Chan, Nrej, Nacc, AvgOMA, AvgOMP, StdOMA, StdOMP,
               AvgOBS, NDATA, Nprofile, Ntot, AvgBCOR
        FROM serie_cardio WHERE varno='{varno}' {crit_stn} {crit_chan} GROUP BY DATE;"""
            
    cursor.execute(query)
    results = cursor.fetchall() 
    conn.close()

    if not results: return
        
    Dates = [str(row[0]) for row in results]
    aoma, aomp = np.array([row[4] for row in results]), np.array([row[5] for row in results])
    StdOMA, StdOMP = np.array([row[6] for row in results]), np.array([row[7] for row in results])
    aobs, NDATA, Ntot = np.array([row[8] for row in results]), np.array([row[9] for row in results]), np.array([row[11] for row in results])
    abcor = np.array([row[12] for row in results])
    
    if is_oma and (list(set(aoma))[0] == MISSING if len(set(aoma))==1 else False): is_oma = False
    is_bcor = not (len(set(abcor)) == 1 and list(set(abcor))[0] == MISSING)
    if not is_bcor: abcor = np.zeros_like(abcor)
        
    raw_omp, raw_obs = aomp - abcor, aobs - abcor
    p, a = aobs - aomp, aobs - aoma if is_oma else None
    
    # STATISTICS
    sum_N = sum(NDATA) if sum(NDATA) > 0 else 1
    Mean_OMP = sum(aomp*NDATA)/sum_N
    Mean_raw_OMP = sum(raw_omp*NDATA)/sum_N
    Sx2_OMP = (StdOMP*StdOMP + aomp*aomp)*NDATA
    Std_OMP = math.sqrt(max(0, sum(Sx2_OMP)/sum_N - Mean_OMP**2))
    
    if is_oma:
        Mean_OMA = sum(aoma*NDATA)/sum_N
        Sx2_OMA = (StdOMA*StdOMA + aoma*aoma)*NDATA
        Std_OMA = math.sqrt(max(0, sum(Sx2_OMA)/sum_N - Mean_OMA**2))
        
    Avg_BCOR = sum(abcor*NDATA)/sum_N if is_bcor else 0
    Avg_N, Avg_NT = float(sum(NDATA))/len(NDATA), float(sum(Ntot))/len(Ntot)
    
    # TEXT LEGENDS
    MEAN_TITLE1 = f"Mean(O-P) = {round(Mean_OMP,3)}  Raw Mean(O-P) = {round(Mean_raw_OMP,3)}"
    MEAN_TITLE2 = f"Mean(O-A) = {round(Mean_OMA,3)}" if is_oma else ""
    MEAN_TITLE3 = f"Mean(Bcor) = {round(Avg_BCOR,3)}" if is_bcor else ""
    STD_TITLE1  = f"Std(O-P) = {round(Std_OMP,3)}"
    STD_TITLE2  = f"Std(O-A) = {round(Std_OMA,3)}" if is_oma else ""

    # FIGURE
    fig = plt.figure(figsize=fig_size, facecolor='white')
    ax1 = plt.axes([0.1, 0.78, 0.8, 0.16])
    ax2 = plt.axes([0.1, 0.54, 0.8, 0.16])
    ax3 = plt.axes([0.1, 0.30, 0.8, 0.16])
    ax4 = plt.axes([0.1, 0.06, 0.8, 0.16])
    
    variable_name, unit, _ = pikobs.type_varno(f"{varno}")
    pdates = [parse_flexible_date(d) for d in Dates]
    x = mdates.date2num(pdates)
    
    # Fixed X Axis
    xmi, xma = mdates.date2num(parse_flexible_date(datestart)), mdates.date2num(parse_flexible_date(dateend))
    if xmi == xma: xmi, xma = xmi-0.25, xma+0.25

    for ax in [ax1, ax2, ax3, ax4]:
        ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=3, maxticks=8))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %d:%HZ'))
        ax.set_xlim([xmi, xma])
        ax.tick_params(axis='both', which='major', labelsize=10)

    ax1.grid(True, linestyle=':', color='grey')
    ax2.grid(True, linestyle=':', color='grey')


    ax3.grid(True, linestyle=':', color='grey')
    ax4.grid(True, linestyle=':', color='grey')

    # --- PANEL 1: MEAN (Bias) ---
    ax1.plot(x, aomp, color=RED, lw=2, label='O-P')
    if is_oma: ax1.plot(x, aoma, color=BLUE, lw=2, label='O-A')
    if is_bcor: 
        ax1.plot(x, abcor, color=GREEN, lw=2, label='bcor')
        ax1.plot(x, raw_omp, linestyle=':', color=RED, lw=1)
    
    max_b = max(np.abs(aomp).max(), np.abs(aoma).max() if is_oma else 0, np.abs(abcor).max())
    lim1 = get_smart_limit(pathwork, region, family, channel, "ax1_bias", max_b)
    ax1.set_ylim([-lim1, lim1])
    ax1.set_ylabel(f'Mean {unit}', fontsize=12)
    ax1.legend(loc=2, ncol=3, prop={'size': 10})
    ax1.axhline(0, color='black', lw=1.5, zorder=1)

    ax1.text(0.0, 1.04, MEAN_TITLE1, transform=ax1.transAxes, color=RED, fontsize=12, fontweight='bold')
    ax1.text(0.50, 1.04, MEAN_TITLE2, transform=ax1.transAxes, color=BLUE, fontsize=12, fontweight='bold')
    ax1.text(0.78, 1.04, MEAN_TITLE3, transform=ax1.transAxes, color=GREEN, fontsize=12, fontweight='bold')

    # --- PANEL 2: STDDEV ---
    ax2.plot(x, StdOMP, color=RED, lw=2, label='O-P')
    if is_oma: ax2.plot(x, StdOMA, color=BLUE, lw=2, label='O-A')
    max_s = max(StdOMP.max(), StdOMA.max() if is_oma else 0)
    lim2 = get_smart_limit(pathwork, region, family, channel, "ax2_std", max_s)
    ax2.set_ylim([0, lim2])
    ax2.set_ylabel(f'StdDev {unit}', fontsize=12)
    ax2.legend(loc=2, prop={'size': 10})
    ax2.text(0.0, 1.04, STD_TITLE1, transform=ax2.transAxes, color=RED, fontsize=12, fontweight='bold')
    ax2.text(0.25, 1.04, STD_TITLE2, transform=ax2.transAxes, color=BLUE, fontsize=12, fontweight='bold')

    # --- PANEL 3: PHYSICAL ---
    ax3.plot(x, aobs, color=BLACK, label='Obs')
    ax3.plot(x, p, color=RED, label='Trial')
    if is_oma: ax3.plot(x, a, color=BLUE, label='Anal')
    max_v = max(aobs.max(), p.max(), a.max() if is_oma else 0)
    lim3 = get_smart_limit(pathwork, region, family, channel, "ax3_values", max_v)
    min_v = min(aobs.min(), p.min(), a.min() if is_oma else 0)
    ax3.set_ylim([min_v*0.95, lim3])
    ax3.set_ylabel(f'{variable_name} {unit}', fontsize=12)
    ax3.legend(loc=2, prop={'size': 10})

    # --- PANEL 4: COUNTS ---
    ax4.plot(x, NDATA, color=BLACK, label='Ndata')
    ax4.plot(x, Ntot, linestyle=':', color=BLACK, label='Nlocs')
    max_c = max(NDATA.max(), Ntot.max())
    lim4 = get_smart_limit(pathwork, region, family, channel, "ax4_counts", max_c)
    ax4.set_ylim([0, lim4])
    ax4.set_ylabel('Observations', fontsize=12)
    ax4.legend(loc=2, prop={'size': 10})
    ax4.set_title(f"Average number of data = {int(round(Avg_N))}  Avg Nlocs = {int(round(Avg_NT))}", fontsize=11, pad=10)
    
    fig.autofmt_xdate()
    fig.suptitle(f'Exp:{fig_title} Sat:{id_stn} Ch:{channel} ({region},{flag_type})', fontsize=16, fontweight='bold', y=0.98)
    
    os.makedirs(f'{pathwork}/{family}', exist_ok=True)
    out_file = f'{pathwork}/{family}/serie_{flag_type}_{family}_{id_stn}_id_stn_{region}_ch{channel}_varno{varno}.png'
    plt.savefig(out_file, format='png', dpi=110)
    plt.close(fig)
