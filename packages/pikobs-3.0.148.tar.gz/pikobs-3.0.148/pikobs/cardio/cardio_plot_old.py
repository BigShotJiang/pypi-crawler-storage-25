#!/usr/bin/python3

import os
import sys
import math
import sqlite3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.dates as mdates
import matplotlib.font_manager as font_manager
from datetime import datetime
import pikobs 
import os
import sys
import math
import sqlite3
import numpy as np
from datetime import datetime
import pikobs 




# =========================================================================
# FUNCIÓN AUXILIAR: LECTOR DE FECHAS FLEXIBLE
# =========================================================================
def parse_flexible_date(date_str):
    """
    Intenta leer la fecha usando múltiples formatos posibles 
    para evitar que el programa crashee (ValueError).
    """
    date_str = str(date_str).strip()
    
    # Lista de formatos de mayor a menor precisión
    formats = [
        '%Y%m%d%H',           # ej: 2026021000
        '%Y-%m-%d %H:%M:%S',  # ej: 2026-02-10 00:00:00
        '%Y-%m-%d',           # ej: 2026-02-10
        '%Y%m%d'              # ej: 20260210
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
            
    raise ValueError(f"El formato de la fecha '{date_str}' es desconocido.")

# =========================================================================
# FUNCIÓN PRINCIPAL: CARDIO PLOT
# =========================================================================
def cardio_plot(pathwork, datestart, dateend, flag_type, family, fig_title, plot_type, channel, id_stn, varno, region):
    
    plt.close('all')
    GREEN='#009900'
    BLUE='#0276FD'
    BLACK='#000000'
    RED='#D00000'
    MISSING=-99.9
    
    if plot_type == 'classic':
        #             w    h  (inches)
        fig_size = (8.5, 11.0)
    elif plot_type == 'wide':
        fig_size = (15.0, 10.0)
    else:
        print("Invalid plot type =", plot_type)
        sys.exit()
        
    if flag_type in ('monitoring', 'bgckalt', 'bgckalt_qc'):
        is_oma = False
    else:
        is_oma = True
        
    path_output_work = f'{pathwork}/{family}/cardio_{region}_{datestart}_{dateend}_{flag_type}_{family}.db'
    conn = sqlite3.connect(path_output_work)
    cursor = conn.cursor()
    cursor.execute("PRAGMA TEMP_STORE=memory")
    
    critery_stn = f"AND id_stn='{id_stn}'"
    critery_chan = f"AND Chan='{channel}'"
    
    if id_stn == 'join':
        critery_stn = ' '
    if channel == 'join':
        critery_chan = ' '
        
    query = f"""
        SELECT
            DATE, Chan, Nrej, Nacc, AvgOMA, AvgOMP, StdOMA, StdOMP,
            AvgOBS, NDATA, Nprofile, Ntot, AvgBCOR
        FROM
            serie_cardio
        WHERE
            varno='{varno}'
            {critery_stn}
            {critery_chan}
        GROUP BY
            DATE;"""
            
    cursor.execute(query)
    results = cursor.fetchall() 
    conn.close()

    if not results:
        print(f"No data found for {id_stn} - Channel {channel}.")
        return
        
    Dates   = [str(row[0]) for row in results]
    aoma    = np.array([row[4] for row in results])
    aomp    = np.array([row[5] for row in results])
    StdOMA  = np.array([row[6] for row in results])
    StdOMP  = np.array([row[7] for row in results])
    aobs    = np.array([row[8] for row in results])
    NDATA   = np.array([row[9] for row in results])
    Ntot    = np.array([row[11] for row in results])
    abcor   = np.array([row[12] for row in results])
    
    # Check if AvgOMA, StdOMA are missing
    oma = list(set(aoma))
    if len(oma) == 1 and oma[0] == MISSING:
        if is_oma:
            print("OMA data are missing! Aborting....")
            sys.exit()
        else:
            is_oma = False
    else:
        is_oma = True
        
    # Check if AvgBCOR are missing
    bc = list(set(abcor))
    is_bcor = True
    if len(bc) == 1 and bc[0] == MISSING:
        if flag_type != 'monitoring':
            print("WARNING: AvgBCOR data are missing.")
        abcor = np.zeros_like(abcor)
        is_bcor = False
        
    try:
        raw_omp = aomp - abcor
    except:
        raw_omp = aomp  
    try:
        raw_obs = aobs - abcor
    except:
        raw_obs = aobs 
        
    p = aobs - aomp
    if is_oma:
        a = aobs - aoma
        
    N = NDATA
    NT = Ntot
    
    sum_N = sum(N) if sum(N) > 0 else 1
    
    Bias1 = aomp
    Sigma1 = StdOMP
    Mu = sum(Bias1*N)/sum_N
    Sx2 = (Sigma1*Sigma1 + Bias1*Bias1)*N
    Sig = math.sqrt(max(0, sum(Sx2)/sum_N - Mu*Mu))
    
    Mean_OMP = Mu
    Mean_raw_OMP = sum(raw_omp*N)/sum_N
    Std_OMP = Sig
    
    STRING_OMP = 'O-P Mean: '+str(round(Mu,3)) + ' Sigma: '+str(round(Sig,3)) + ' Ndata: '+ str(int(sum(N)))
    
    if is_oma:
        Bias2 = aoma
        Sigma2 = StdOMA
        Mu = sum(Bias2*N)/sum_N
        Mean_OMA = Mu
        Sx2 = (Sigma2*Sigma2 + Bias2*Bias2)*N
        Sig = math.sqrt(max(0, sum(Sx2)/sum_N - Mu*Mu))
        Std_OMA = Sig
        STRING_OMA = 'O-A Mean: '+str(round(Mu,3)) + ' Sigma: '+str(round(Sig,3)) + ' Ndata: '+ str(int(sum(N)))
        
    try:
        Avg_BCOR = sum(abcor*N)/sum_N
    except:
        Avg_BCOR = 0
        
    Avg_N = float(sum(N))/len(N) if len(N) > 0 else 0
    Avg_NT = float(sum(NT))/len(NT) if len(NT) > 0 else 0
    
    debut = Dates[0]
    fin = Dates[-1]
    PERIODE = 'From ' + debut +'   to ' + fin
    TITLE = fig_title
    
    MEAN_TITLE1 = str('Mean(O-P) = '+str(round(Mean_OMP,3))) + '  Raw Mean(O-P) = '+str(round(Mean_raw_OMP,3))
    if is_oma:
        MEAN_TITLE2 = str('Mean(O-A) = '+str(round(Mean_OMA,3)))
    else:
        MEAN_TITLE2 = ''
    if is_bcor:
        MEAN_TITLE3 = str('Mean(Bcor) = '+str(round(Avg_BCOR,3)))
    else:
        MEAN_TITLE3 = ''
    
    STD_TITLE1  = str('Std(O-P) = '+str(round(Std_OMP,3)))
    if is_oma:
        STD_TITLE2  = str('Std(O-A) = '+str(round(Std_OMA,3)))
    else:
        STD_TITLE2  = ''
    
    #----------------------------------------------------------------------
    # Plot Section: 4 plots on 1 page (fig)
    #----------------------------------------------------------------------
    left = 0.1   # left margin
    width = 0.8  # width of the plots
    fp = font_manager.FontProperties(size='small')
    
    fig = plt.figure(figsize=fig_size, facecolor='white')
    
    p1_bottom = 0.73
    p2_bottom = 0.51
    p3_bottom = 0.29
    p4_bottom = 0.07
    height = 0.18
    
    ax1 = plt.axes([left, p1_bottom, width, height])
    ax2 = plt.axes([left, p2_bottom, width, height])
    ax3 = plt.axes([left, p3_bottom, width, height])
    ax4 = plt.axes([left, p4_bottom, width, height])
    
    ax1.grid(False)
    ax2.grid(False)
    ax3.grid(False)
    ax4.grid(False)
    
    variable_name, unit, vcoord_type = pikobs.type_varno(f"{varno}")
    
    # =========================================================================
    # LECTOR DE FECHAS FLEXIBLE (Evita el ValueError de '%Y%m%d%H')
    # =========================================================================
    pdates = [parse_flexible_date(d) for d in Dates]
    x = mdates.date2num(pdates)
    
    # =========================================================================
    # FIX: PREVENCIÓN DE ERRORES DE LÍMITES Y TICKS (MAXTICKS / Singular)
    # =========================================================================
    if len(x) == 1:
        # Si solo hay 1 dato, damos margen de 6h (0.25 días) para que no crashee
        xmi = x[0] - 0.25 
        xma = x[0] + 0.25 
    else:
        xmi = x[0]
        xma = x[-1]
        
    # AutoDateLocator es inteligente y evita el error de MAXTICKS
    locator = mdates.AutoDateLocator(minticks=3, maxticks=8)
    formatter = mdates.DateFormatter('%b %d:%HZ')
    minor_locator = mdates.AutoDateLocator(minticks=5, maxticks=20)
    
    for ax in [ax1, ax2, ax3, ax4]:
        ax.xaxis.set_major_locator(locator)
        ax.xaxis.set_major_formatter(formatter)
        ax.xaxis.set_minor_locator(minor_locator)
        ax.set_xlim([xmi, xma])
        ax.xaxis.grid(True, which='major', linestyle=':', color='grey')
        ax.xaxis.grid(True, which='minor', linestyle=':', color='grey')
        for label in ax.get_xticklabels():
            label.set_fontsize(8)
    # =========================================================================
    
    # AX1
    ax1.plot(x, aomp, linestyle='-', color=RED, lw=2, label='O-P')
    ncols = 1
    if is_oma:
        ax1.plot(x, aoma, linestyle='-', color=BLUE, lw=2, label='O-A')
        ncols += 1
    if is_bcor:
        ax1.plot(x, abcor, linestyle='-', color=GREEN, lw=2, label='bcor')
        ax1.plot(x, raw_omp, linestyle=':', color=RED, lw=2, label='(O-P)raw')
        ncols += 2
        
    ax1.axhline(color='purple', lw=2)
    ax1.set_ylabel(f'Mean {unit}')
    ax1.legend(loc=2, ncol=ncols, prop=fp)
    ax1.yaxis.set_minor_locator(ticker.AutoMinorLocator())
    ax1.yaxis.grid(True, which='major', linestyle='-', color='grey')
    ax1.yaxis.grid(True, which='minor', linestyle=':', color='grey')
    
    ax1.text(0.0, 1.0, MEAN_TITLE1, horizontalalignment='left', verticalalignment='bottom', transform=ax1.transAxes, color=RED, fontsize=11)
    ax1.text(0.52, 1.0, MEAN_TITLE2, horizontalalignment='left', verticalalignment='bottom', transform=ax1.transAxes, color=BLUE, fontsize=11)
    ax1.text(0.77, 1.0, MEAN_TITLE3, horizontalalignment='left', verticalalignment='bottom', transform=ax1.transAxes, color=GREEN, fontsize=11)
    
    yt = ax1.yaxis.get_majorticklocs()
    ylims = ax1.get_ylim()
    if len(yt) > 1 and yt[-1] >= ylims[1]:
        delt = yt[-1] - yt[-2]
        ylim2 = yt[-1] + delt
        ax1.set_ylim([ylims[0], ylim2])
    else:
        ax1.set_ylim([ylims[0], yt[-1] if len(yt)>0 else ylims[1]])
        
    # AX2
    ax2.plot(x, StdOMP, linestyle='-', color=RED, lw=2, label='O-P')
    ncols = 1
    if is_oma:
        ax2.plot(x, StdOMA, linestyle='-', color=BLUE, lw=2, label='O-A')
        ncols += 1
        
    ylims2 = ax2.get_ylim()
    if is_oma:
        ax2.set_ylim([0, ylims2[1]])
    ax2.set_ylabel(f'StdDev {unit}')
    ax2.legend(loc=3, ncol=ncols, prop=fp)
    ax2.yaxis.set_minor_locator(ticker.AutoMinorLocator())
    ax2.yaxis.grid(True, which='major', linestyle='-', color='grey')
    ax2.yaxis.grid(True, which='minor', linestyle=':', color='grey')
    
    ax2.text(0.0, 1.0, STD_TITLE1, horizontalalignment='left', verticalalignment='bottom', transform=ax2.transAxes, color=RED, fontsize=11)
    ax2.text(0.25, 1.0, STD_TITLE2, horizontalalignment='left', verticalalignment='bottom', transform=ax2.transAxes, color=BLUE, fontsize=11)
    
    # AX3
    ax3.plot(x, aobs, linestyle='-', color=BLACK, label='Obs')
    ncols = 1
    if is_bcor:
        ax3.plot(x, raw_obs, linestyle=':', color=BLACK, label='RawObs')
        ncols += 1
    ax3.plot(x, p, color=RED, label='Trial')
    ncols += 1
    if is_oma:
        ax3.plot(x, a, color=BLUE, label='Anal')
        ncols += 1
        
    ax3.set_ylabel(f'{variable_name} {unit}')
    ax3.legend(loc=0, ncol=ncols, prop=fp)
    ax3.yaxis.set_minor_locator(ticker.AutoMinorLocator())
    
    # AX4
    ax4.plot(x, NDATA, linestyle='-', color=BLACK, label='Ndata')
    ax4.plot(x, Ntot, linestyle=':', color=BLACK, label='Nlocs')
    ylims4 = ax4.get_ylim()
    ax4.set_ylim([0, ylims4[1]])
    ax4.set_ylabel('Number of Observations')
    ax4.legend(loc=0, ncol=2, prop=fp)
    ax4.yaxis.set_minor_locator(ticker.AutoMinorLocator())
    
    title4 = "Average number of data = "+str(int(round(Avg_N)))+"  Avg Nlocs = "+str(int(round(Avg_NT)))
    ax4.set_title(title4)
    
    fig.autofmt_xdate()
    fig.suptitle(f'Experience:{TITLE} Satellite:{id_stn} channel:{channel} ({region},{flag_type})', fontsize=15, fontweight='bold')
    
    os.makedirs(f'{pathwork}/{family}', exist_ok=True)
    
    out_file = f'{pathwork}/{family}/serie_{flag_type}_{family}_{id_stn}_id_stn_{region}_ch{channel}_varno{varno}.png'
    plt.savefig(out_file, format='png', dpi=100)
    plt.close(fig)
