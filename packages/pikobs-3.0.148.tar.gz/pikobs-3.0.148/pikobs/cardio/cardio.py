"""
=================
Cardio Diagnostic
=================

The **Pikobs Cardio** is a diagnostic tool designed to evaluate the impact and quality of radiance data within the assimilation cycle through multi-panel time series and interactive web interfaces.

Core Visualization: The 4-Panel Cardiogram
------------------------------------------

The engine generates a synchronized 4-panel vertical plot. This layout allows researchers to cross-reference bias, OMP, OMA, and data volume at any specific timestamp.

.. image:: _static/cardio.png
   :align: center
   :alt: 4-Panel Cardiogram Analysis
   :width: 900px

**Panel Breakdown and Scientific Objectives:**

* **1. Mean (Bias Analysis)**
  Tracks the **Bias Correction** (Bcor), **O-P** (Observation minus Prediction), and **O-A** (Observation minus Analysis). This panel is essential for identifying systematic model drifts and sensor calibration offsets over time.

* **2. Standard Deviation (Uncertainty)**
  Measures the standard deviation of the differences for both OMP and OMA. A lower standard deviation in the analysis (O-A) compared to the background (O-P) serves as a key indicator of a successful assimilation step.

* **3. Mean Observation Values**
  Displays the absolute physical mean values for the Observations, the Trial (Background), and the Analysis. This allows researchers to compare the physical scales and trends directly.

* **4. Data Counts (Volume Metrics)**
  Monitors **Ndata** (assimilated observations) versus **Nlocs** (total available locations). This bottom panel is vital for detecting sudden satellite outages, data link failures, or overly aggressive Quality Control (QC) filtering.

Interactive Web Environment
---------------------------

Beyond static plots, Pikobs automatically generates a **Smart Web Viewer**. This tool is designed for rapid multi-dimensional and comparative analysis:

* **Dynamic Filtering:** The interface only displays valid combinations of satellite, channel, and region available in your dataset.
* **Flip-Flop Mode:** Allows instant toggling between two different plots to detect subtle changes without losing visual focus.
* **Access:** The generated interactive viewer is saved in your output directory and linked directly here:

🔗 **Explore the Viewer:** `Interactive Web Viewer <https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobscardio/pikobs_viewer_cardio.html>`_

HPC Execution & Real-Time Monitoring
------------------------------------

To maintain system stability on Environment and Climate Change Canada (ECCC) clusters, always execute diagnostic tasks using a dedicated compute node.

**1. Initialize Interactive Session:**

.. code-block:: bash

    qsub -I -X -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb -l place=scatter -l walltime=6:0:0

**2. Generate Diagnostics Command:**

.. code-block:: bash

    python -c 'import pikobs; pikobs.cardio.arg_call()' \\
        --path_experience   /home/dlo001/sites8/Data_pikobs/monitoring/ \\
        --experience_name   g0 \\
        --pathwork          /your/custom/output/path \\
        --datestart         2026021000 \\
        --dateend           2026021700 \\
        --region            Monde Canada \\
        --family            to_amsua_allsky atms_allsky \\
        --flags_criteria    clear_sky  cloudy_sky clear_cloudy_sky   \\
        --id_stn            all \\
        --channel           all \\
        --plot_title        "Pikobs Cardio" \\
        --n_cpu             80

**3. Expected Shell Output (Batch Monitoring):**

When executing the command above, you will see the parallel processing progress in your terminal:

.. code-block:: text

    [PIKOBS] Initializing Cardio Diagnostic Engine...
    [INFO] Detected 80 CPUs for parallel processing.
    [DB] Connecting to: /your/path/to/experience/g0/output_fileMonde.db
    [PARALLEL] Processing tasks for family: atms_allsky...
    [PARALLEL] Generating cardiograms for METOP-1 (Channels: 1-15)...
    [PARALLEL] Generating cardiograms for NOAA-20 (Channels: 1-15)...
    [WEB] Compiling interactive web viewer data...
    ✅ Plot successfully saved: /your/path/serie_assimilee_atms_allsky_METOP-1_ch3.png
    ✅ Advanced Web viewer successfully created at: /your/path/pikobs_interactive_viewer.html
    [DONE] All diagnostics completed successfully.

Support and Issues
------------------

Pikobs is maintained for the community. For bug reports, feature requests, or "ValueError" date-parsing issues, please use the official GitLab repository:

🔗 **GitLab Issues:** `https://gitlab.science.gc.ca/dlo001/Pikobs <https://gitlab.science.gc.ca/dlo001/Pikobs>`_


"""

#!/usr/bin/python3
import sqlite3
import pikobs
import re
import os
from  dask.distributed import Client
import numpy as np
import sqlite3
import os
import re
import sqlite3
from  datetime import datetime, timedelta


def create_serie_cardio(family, 
                        new_db_filename, 
                        existing_db_filename,
                        region_seleccionada,
                        selected_flags, 
                        id_stn,
                        channel, 
                        varnos):
    """

    Create a new SQLite database with a 'moyenne' table and populate it with data from an existing database.

    Args:

      new_db_filename (str): Filename of the new database to be created.
  
      existing_db_filename (str): Filename of the existing database to be attached.
  
      region_seleccionada (str): Region selection criteria.
   
      selected_flags (str): Selected flags criteria.
   
      FONCTION (float): Value for sum_fonction column.

    
    Returns:
    
      None
    
    """
 
    pattern = r'(\d{10})'
    match = re.search(pattern, existing_db_filename)

    if match:
        date = match.group(1)
       
    else:
        print("No 10 digits found in the string.")
    
    # Connect to the new database
    if id_stn[0]=='all':
      criteria_id_stn = '    '
    else:
       elemnts = [f"'{element}'" for element in id_stn]

       resultado = f"({','.join(elemnts)})"
       criteria_id_stn = f'   '
    if channel[0]=='all':
      criteria_vcoord = '    '
    else:
       resultado = f"({','.join(channel)})"
       criteria_vcoord = f'    '

    
    filename=f"file::memory:?cache=shared"
    new_db_conn = sqlite3.connect(filename, uri=True, isolation_level=None, timeout=999999)
    new_db_cursor = new_db_conn.cursor()

    FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)
    if id_stn[0]!='all' and id_stn[0]!='join':
       id_stn[0]='all' 
    if varnos:
        element=",".join(varnos)
    if channel=='join':
        VCOORD='  vcoord '
    if channel[0]=='join' and  id_stn[0]=='all':
      group_channel = ' "join" as Chan,    '
      group_id_stn  = ' id_stn as id_stn '
      group_id_stn_vcoord = ' group by id_stn,varno'
    if channel[0]=='all' and  id_stn[0]=='join':
      group_channel = f' {VCOORD} as  Chan, '
      group_id_stn  = ' "join" as id_stn '
      group_id_stn_vcoord = f' group by {VCOORD},varno'
    if channel[0]=='all' and  id_stn[0]=='all':
      group_channel = f'  {VCOORD} as Chan,'
      group_id_stn  = ' id_stn as id_stn '
      group_id_stn_vcoord = f' group by id_stn, {VCOORD},varno'

    if channel[0]=='join' and  id_stn[0]=='join':
      group_channel = ' "join" as Chan, '
      group_id_stn  =  ' "join" as id_stn  '
      group_id_stn_vcoord = 'group by varno  '

    LAT1, LAT2, LON1, LON2 = pikobs.regions(region_seleccionada)
    LATLONCRIT = pikobs.generate_latlon_criteria(LAT1, LAT2, LON1, LON2)
    flag_criteria = pikobs.flag_criteria(selected_flags)

    # Attach the existing database
    new_db_cursor.execute(f"ATTACH DATABASE '{existing_db_filename}' AS db;")
    # load extension CMC 
    new_db_conn.enable_load_extension(True)
    extension_dir = f'{os.path.dirname(pikobs.__file__)}/extension/libudfsqlite-shared.so'
    new_db_conn.execute(f"SELECT load_extension('{extension_dir}')")
    # Create the 'moyenne' table in the new database if it doesn't exist
    new_db_cursor.execute("""
           CREATE TABLE IF NOT EXISTS serie_cardio ( 
            DATE INTEGER,
            Chan INTEGER,
            Nrej INTEGER,
            Nacc INTIGER,
            AvgOMP FLOAT, 
            AvgOMA FLOAT,
            StdOMP FLOAT,
            StdOMA FLOAT,
            NDATA  INTEGER,
            Nprofile INTEGER,
            AvgBCOR FLOAT,
            AvgOBS FLOAT,
            Ntot INTEGER,
            varno INTEGER,
            id_stn  TEXT
        );
    """)
    query=f"""INSERT INTO serie_cardio (

            DATE,
            Chan,
            Nrej,
            Nacc,
            AvgOMP, 
            AvgOMA,
            StdOMP,
            StdOMA,
            NDATA,
            Nprofile,
            AvgBCOR,
            AvgOBS,
            Ntot,
            varno,
            id_stn
        )
    
    
             SELECT 
                 isodatetime({date}) AS DATE,  
                 {group_channel}
                 SUM(flag & 512=512) AS Nrej,
                 SUM(flag & 4096=4096) AS Nacc,
                 ROUND(AVG(OMP), 4) AS AvgOMP,
                 ROUND(AVG(OMA), 4) AS AvgOMA,
                 ROUND(STDDEV(OMP), 4) AS StdOMP,
                 ROUND(STDDEV(OMA), 4) AS StdOMA,
                 SUM(OMP IS NOT NULL) AS NDATA,
                 COUNT(DISTINCT id_obs) AS Nprofils,
                 ROUND(AVG(BIAS_CORR), 4) AS AvgBCOR,
                 ROUND(AVG(OBSVALUE), 4) AS AvgOBS,
                 (SELECT COUNT(*) FROM header h2 WHERE h2.ID_STN = header.ID_STN) AS Ntot,
                 varno AS varno,
                 {group_id_stn}
                 
            FROM 
                 header
             NATURAL JOIN 
                 data
             WHERE 
                 varno IN ({element}) 
                 {criteria_id_stn}
                 {criteria_vcoord}
                 {flag_criteria}
                 {LATLONCRIT}
                 {VCOCRIT}
                {group_id_stn_vcoord};"""
    new_db_cursor.execute(query)
    # Commit changes and detach the existing database
    new_db_conn.commit()

    # Commit changes and detach the existing database
    new_db_cursor.execute("DETACH DATABASE db;")
    try:
         combine(new_db_filename, filename)
    except sqlite3.Error as error:
         print(f"Error while creating a single sqlite file:  {os.path.basename(filename)}", error)

    
    # Close the connections
    #anew_db_conn.close()


def combine(pathfileout, filememory):

    """ Creating a single sqlite file from multiple sqlite files
 
    args:
    ----------------

     pathfileout   : output averaging  sqlite file 
     filememory    : name of the sqlite file in memory to copy
   
    output:
    ----------------

    Nothing
     A sqlite file is made with all averaged volume scans
   
   """

    # write in output averaging  sqlite file
    conn_pathfileout = sqlite3.connect(pathfileout, uri=True, isolation_level=None, timeout=9999)

    conn_pathfileout.execute("""PRAGMA journal_mode=OFF;""")

    # off the journal
    create_table_if_not_exists( conn_pathfileout)
    conn_pathfileout.execute("""PRAGMA journal_mode=OFF;""")
    # SQLite continues without syncing as soon as it has handed data off to the operating system
    conn_pathfileout.execute("""PRAGMA synchronous=OFF;""")
    # Wait to read and write until the next process finishes
    # attach the sqlite file in memory for one PPI
    create_table_if_not_exists(conn_pathfileout)

    conn_pathfileout.execute("ATTACH DATABASE ? AS this_avg_db;", (filememory,))
    order_sql = """ INSERT INTO serie_cardio( DATE, Chan, Nrej, Nacc, AvgOMP, AvgOMA, StdOMP, StdOMA, NDATA, Nprofile, AvgBCOR, AvgOBS, Ntot, varno, id_stn
 

                )
                    SELECT
                    DATE, Chan, Nrej, Nacc, AvgOMP, AvgOMA, StdOMP, StdOMA, NDATA, Nprofile, AvgBCOR, AvgOBS, Ntot, varno, id_stn
 
                    FROM  this_avg_db.serie_cardio"""
    conn_pathfileout.execute(order_sql) 

    conn_pathfileout.commit()
    conn_pathfileout.execute(""" DETACH DATABASE this_avg_db """)

def create_table_if_not_exists(cursor):
    """
    Create the 'serie_cardio' table if it does not already exist.

    Args:
        cursor (sqlite3.Cursor): Database cursor for executing SQL queries.
    """
    query = """
           CREATE TABLE IF NOT EXISTS serie_cardio ( 
            DATE INTEGER,
            Chan INTEGER,
            Nrej INTEGER,
            Nacc INTIGER,
            AvgOMP FLOAT, 
            AvgOMA FLOAT,
            StdOMP FLOAT,
            StdOMA FLOAT,
            NDATA  INTEGER,
            Nprofile INTEGER,
            AvgBCOR FLOAT,
            AvgOBS FLOAT,
            Ntot INTEGER,
            varno INTEGER,
            id_stn  TEXT );
    """
    cursor.execute(query)


def create_data_list_cardio(datestart1, 
                            dateend1,
                            families,
                            pathin, 
                            pathwork,
                            flag_criterias,
                            id_stn,
                            channel,
                            regions,
                            varnos):
    
    data_list_cardio = []
    for family in families:
     for flag_criteria in flag_criterias:
        for region in regions:
             # Convert datestart and dateend to datetime objects
             datestart = datetime.strptime(datestart1, '%Y%m%d%H')
             dateend = datetime.strptime(dateend1, '%Y%m%d%H')

             # Initialize the current_date to datestart
             current_date = datestart

             # Define a timedelta of 6 hours
             delta = timedelta(hours=6)
             FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)

            #  print ("VCOORD", vcoord, element, type(element))
              # Iterate through the date range in 6-hour intervals
             while current_date <= dateend:
                 # Format the current date as a string
                 formatted_date = current_date.strftime('%Y%m%d%H')

                 # Build the file name using the date and family
                 filename = f'{formatted_date}_{family}'

                 file_path_name = f'{pathin}/{filename}'
                 conn = sqlite3.connect(file_path_name)
                 # Create a cursor to execute SQL queries
                 cursor = conn.cursor()

                 #  Create a new dictionary and append it to the list
                 data_dict = {'family': family,
                                   'filein': f'{pathin}/{filename}',
                                   'db_new': f'{pathwork}/{family}/cardio_{region}_{datestart1}_{dateend1}_{flag_criteria}_{family}.db',
                                   'region': region,
                                   'flag_criteria': flag_criteria,
                                   'varno':  varnos,
                                   'vcoord': channel,
                                   'id_stn': id_stn}
                 data_list_cardio.append(data_dict)
                 conn.close()

                 # Update the current_date in the loop by adding 6 hours
                 current_date += delta
    return data_list_cardio


def get_station_ids(cursor, id_stn):
    if id_stn[0] == 'all':
        cursor.execute("SELECT DISTINCT id_stn FROM serie_cardio;")
        return [item[0] for item in cursor.fetchall()]
    return np.array(id_stn)

def fetch_channels_and_varno(cursor, idstn, channel):
    criter = f'WHERE id_stn = "{idstn}"'
    if channel[0] == 'all':
        if idstn=='join':
           query = f"SELECT DISTINCT chan, varno FROM serie_cardio  ;"
        else:
           query = f"SELECT DISTINCT chan, varno FROM serie_cardio {criter} ;"       
        cursor.execute(query)
        return cursor.fetchall()
    else:
        channels_varno = []
        for chan in np.array(channel):
            if idstn=='join':
               query = f"SELECT DISTINCT 'join', varno FROM serie_cardio;"
            else:
               query = f"SELECT DISTINCT 'join', varno FROM serie_cardio;"        
            cursor.execute(query)
            result = cursor.fetchone()
            if result:
                channels_varno.append(result)
        return channels_varno

def create_data_list_plot(datestart1, dateend1, families, pathin, pathwork, flag_criterias, regions, id_stn, channel):
    data_list_plot = []
    for family in families:
        for region in regions: 
         for flag_criteria in flag_criterias:
           filedb = f'{pathwork}/{family}/cardio_{region}_{datestart1}_{dateend1}_{flag_criteria}_{family}.db'
           try:
               with sqlite3.connect(filedb) as conn:
                   cursor = conn.cursor()
                   if id_stn[0]=='all':
                       id_stns = get_station_ids(cursor, id_stn)
                   elif id_stn[0]=='join':  
                       id_stns = ['join']
                   else:
                       id_stns=id_stn
                   for idstn in id_stns:
                       channels_varno = fetch_channels_and_varno(cursor, idstn, channel)
                       for chan, varno in channels_varno:
                           data_dict_plot = {
                               'id_stn': idstn,
                               'vcoord': chan,
                               'varno': varno,
                               'region':region,
                               'family':family,
                               'flag_criteria':flag_criteria
                           }
                           data_list_plot.append(data_dict_plot)
           except sqlite3.Error as e:
               print(f"Database error: {e}")
           except Exception as e:
               print(f"Error: {e}")
    return data_list_plot
import json
import os

import os
import json

def generate_web_viewer(pathwork, data_list, output_filename="pikobs_interactive_viewer.html"):

    json_data = json.dumps(data_list)

    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pikobs Cardio Viewer</title>
<style>
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background-color: #f4f7f6; color: #333; display: flex; flex-direction: column; min-height: 100vh; }
.header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; }
.container { max-width: 1200px; margin: 20px auto; padding: 0 20px; flex: 1; width: 100%; box-sizing: border-box; }
.controls { display: flex; flex-wrap: wrap; gap: 20px; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 20px; justify-content: center; align-items: flex-end; }
.control-group { display: flex; flex-direction: column; }
label { font-weight: bold; margin-bottom: 5px; font-size: 13px; color: #34495e; text-transform: uppercase; letter-spacing: 0.5px; }
select { padding: 10px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px; min-width: 160px; background-color: #fff; cursor: pointer; transition: border-color 0.3s; }
select:focus { outline: none; border-color: #3498db; box-shadow: 0 0 5px rgba(52,152,219,0.3); }
.btn-flipflop { background-color: #3498db; color: white; border: none; padding: 10px 20px; font-size: 14px; font-weight: bold; border-radius: 4px; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: background-color 0.3s, transform 0.1s; height: 40px; }
.btn-flipflop:hover { background-color: #2980b9; }
.btn-flipflop:active { transform: scale(0.96); }
.btn-flipflop:disabled { background-color: #95a5a6; cursor: not-allowed; }
.btn-flipflop.active-flip { background-color: #e67e22; }
.image-container { text-align: center; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); min-height: 500px; display: flex; align-items: center; justify-content: center; flex-direction: column; position: relative; }
img { max-width: 100%; height: auto; border-radius: 4px; display: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
.error-msg { color: #e74c3c; font-weight: bold; font-size: 18px; display: none; flex-direction: column; align-items: center; gap: 10px; }
.path-display { margin-top: 15px; font-family: monospace; color: #7f8c8d; font-size: 13px; background: #ecf0f1; padding: 10px; border-radius: 4px; width: 100%; box-sizing: border-box; }
.badge { background: #2ecc71; color: white; padding: 3px 8px; border-radius: 12px; font-size: 12px; position: absolute; top: 20px; right: 20px; display: none; }
.badge.previous { background: #e67e22; }
.footer { text-align: center; padding: 20px; color: #7f8c8d; font-size: 14px; background-color: #ecf0f1; margin-top: auto; }
.footer a { color: #3498db; text-decoration: none; font-weight: bold; }
.footer a:hover { text-decoration: underline; }
</style>
</head>
<body>

<div class="header">
    <h1>Pikobs Cardio Viewer</h1>
    <p>Smart selection: Dropdowns automatically filter to show only valid data combinations.</p>
</div>

<div class="container">
    <div class="controls">
        <div class="control-group">
            <label for="flag_criteria">1. Criteria</label>
            <select id="flag_criteria" onchange="handleSelectChange(0)"></select>
        </div>
        <div class="control-group">
            <label for="family">2. Family</label>
            <select id="family" onchange="handleSelectChange(1)"></select>
        </div>
        <div class="control-group">
            <label for="region">3. Region</label>
            <select id="region" onchange="handleSelectChange(2)"></select>
        </div>
        <div class="control-group">
            <label for="id_stn">4. Station (id_stn)</label>
            <select id="id_stn" onchange="handleSelectChange(3)"></select>
        </div>
        <div class="control-group">
            <label for="varno">5. Varno</label>
            <select id="varno" onchange="handleSelectChange(4)"></select>
        </div>
        <div class="control-group">
            <label for="vcoord">6. Channel (vcoord)</label>
            <select id="vcoord" onchange="handleSelectChange(5)"></select>
        </div>

        <button id="btn-flip" class="btn-flipflop" onclick="toggleFlipFlop()" disabled>🔁 Flip-Flop</button>
    </div>

    <div class="image-container">
        <div id="status-badge" class="badge">Current Image</div>
        <div id="error-msg" class="error-msg">
            <span>⚠️ Image file physically missing on disk.</span>
            <span style="font-size: 14px; color: #7f8c8d; font-weight: normal;">The combination exists in the database, but the .png could not be loaded.</span>
        </div>
        <img id="plot-image" src="" alt="Plot Image" onerror="handleImageError()" onload="handleImageLoad()">
        <div id="path-display" class="path-display">Expected file: ...</div>
    </div>
</div>

<div class="footer">
    If you encounter any issues or bugs, please open an issue at: <br>
    <a href="https://gitlab.science.gc.ca/dlo001/Pikobs" target="_blank">https://gitlab.science.gc.ca/dlo001/Pikobs</a>
</div>

<script>
const dbData = JSON_DATA_PLACEHOLDER;
const hierarchy = ['flag_criteria','family','region','id_stn','varno','vcoord'];
let currentSrc = "";
let previousSrc = "";
let showingPrevious = false;

function populateSelect(id, values){
    const select = document.getElementById(id);
    const previousValue = select.value; 

    select.innerHTML = '';
    values.forEach(val=>{
        const option = document.createElement('option');
        option.value = val;
        option.textContent = val;
        select.appendChild(option);
    });

    const stringValues = values.map(String);
    if (previousValue && stringValues.includes(String(previousValue))) {
        select.value = previousValue;
    }
}

// Custom sorting function for natural numerical order
function naturalSort(a, b) {
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}

function handleSelectChange(level){
    for(let i=level+1;i<hierarchy.length;i++){
        const currentField = hierarchy[i];
        const filters = {};
        for(let j=0;j<i;j++){ filters[hierarchy[j]] = document.getElementById(hierarchy[j]).value; }
        const validRows = dbData.filter(row =>
            Object.keys(filters).every(key => String(row[key]) === String(filters[key]))
        );
        
        // Applying natural sort here to correctly order channels like 1, 2, 10, 11
        const uniqueVals = [...new Set(validRows.map(row=>row[currentField]))].sort(naturalSort);
        
        populateSelect(currentField, uniqueVals);
    }
    updateImage();
}

function init(){
    const criteria = [...new Set(dbData.map(item=>item.flag_criteria))].sort(naturalSort);
    populateSelect('flag_criteria', criteria);
    handleSelectChange(0);
}

function updateImage(){
    const flag = document.getElementById('flag_criteria').value;
    const family = document.getElementById('family').value;
    const region = document.getElementById('region').value;
    const id_stn = document.getElementById('id_stn').value;
    const varno = document.getElementById('varno').value;
    const vcoord = document.getElementById('vcoord').value;
    if(!flag || !family || !region || !id_stn || !varno || !vcoord) return;
    const fileName = `serie_${flag}_${family}_${id_stn}_id_stn_${region}_ch${vcoord}_varno${varno}.png`;
    const relativePath = `${family}/${fileName}`;
    if(currentSrc !== relativePath){
        if(currentSrc !== ""){ previousSrc = currentSrc; document.getElementById('btn-flip').disabled=false; }
        currentSrc = relativePath; showingPrevious = false;
        document.getElementById('btn-flip').classList.remove('active-flip');
    }
    applyImageSource(currentSrc,false);
}

function applyImageSource(src,isPrevious){
    document.getElementById('error-msg').style.display='none';
    document.getElementById('path-display').textContent = `Looking for file: ${src}`;
    const img = document.getElementById('plot-image');
    img.src = src+'?t='+new Date().getTime();
    img.style.display='block';
    const badge = document.getElementById('status-badge');
    badge.style.display='block';
    if(isPrevious){ badge.textContent='Viewing: Previous Image'; badge.className='badge previous'; }
    else{ badge.textContent='Viewing: Current Image'; badge.className='badge'; }
}

function toggleFlipFlop(){
    if(!previousSrc) return;
    showingPrevious = !showingPrevious;
    if(showingPrevious) applyImageSource(previousSrc,true);
    else applyImageSource(currentSrc,false);
}

function handleImageError(){ document.getElementById('plot-image').style.display='none'; document.getElementById('error-msg').style.display='flex'; document.getElementById('status-badge').style.display='none'; }
function handleImageLoad(){ document.getElementById('plot-image').style.display='block'; document.getElementById('error-msg').style.display='none'; }

init();
</script>

</body>
</html>
"""

    # Sustituimos el JSON
    html_content = html_content.replace("JSON_DATA_PLACEHOLDER", json_data)

    os.makedirs(pathwork, exist_ok=True)
    html_path = os.path.join(pathwork, output_filename)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"✅ Advanced Cardio Web viewer successfully created at: {html_path}")

def make_cardio(path_experience_files,
                experience_names,      
                pathwork, 
                datestart,
                dateend,
                regions, 
                families, 
                flag_criterias, 
                id_stn,
                channel,
                plot_type,
                plot_title,
                n_cpu,
                varnos):
       
       for family in families:
         
           pikobs.delete_create_folder(pathwork, family) 

       data_list_cardio = create_data_list_cardio(datestart,
                                           dateend, 
                                           families, 
                                           path_experience_files, 
                                           pathwork,
                                           flag_criterias, 
                                           id_stn,
                                           channel,
                                           regions,
                                           varnos)

       import time
       import dask
       t0 = time.time()
       if n_cpu==1:
        print (f'in Serie: {len(data_list_cardio)} files for serie calculation')
        for  data_ in data_list_cardio:  
            create_serie_cardio(data_['family'], 
                                data_['db_new'], 
                                data_['filein'],
                                data_['region'],
                                data_['flag_criteria'],
                                data_['id_stn'],
                                data_['vcoord'],
                                data_['varno'])




       else:
        print (f'in Paralle: {len(data_list_cardio)} files for serie calculation')
        with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                           n_workers=n_cpu, 
                                           silence_logs=40) as client:
            delayed_funcs = [dask.delayed(create_serie_cardio)(data_['family'], 
                                              data_['db_new'], 
                                              data_['filein'],
                                              data_['region'],
                                              data_['flag_criteria'],
                                              data_['id_stn'],
                                              data_['vcoord'],
                                              data_['varno'])for data_ in data_list_cardio]
            results = dask.compute(*delayed_funcs)
        
       tn= time.time()
       print ('Total time serie calculation:', round(tn-t0,2) )  
       data_list_plot = create_data_list_plot(datestart,
                                    dateend, 
                                    families, 
                                    path_experience_files, 
                                    pathwork,
                                    flag_criterias, 
                                    regions,
                                    id_stn,
                                    channel)


       t0 = time.time()
       if len(data_list_plot)==0:
          raise ValueError('You must specify best selectoion od id_stn and channel plot==0')

       if n_cpu==1: 
          print (f'in Serie plots = {len(data_list_plot)}')
          for  data_ in data_list_plot:  
              pikobs.cardio_plot(pathwork,
                                 datestart,
                                 dateend,
                                 data_['flag_criteria'],
                                 data_['family'],
                                 plot_title,
                                 plot_type, 
                                 data_['vcoord'],
                                 data_['id_stn'], 
                                 data_['varno'],
                                 data_['region'])
       else:
          print (f'in Paralle = {len(data_list_plot)} plots')
          with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                           n_workers=n_cpu, 
                                           silence_logs=40) as client:
            delayed_funcs = [dask.delayed(pikobs.cardio_plot)(
                               pathwork,
                                 datestart,
                                 dateend,
                                 data_['flag_criteria'],
                                 data_['family'],
                                 plot_title,
                                 plot_type, 
                                 data_['vcoord'],
                                 data_['id_stn'], 
                                 data_['varno'],
                                 data_['region'])for data_ in data_list_plot]

            results = dask.compute(*delayed_funcs)
       tn= time.time()
       print ('Total time for plotting:',tn-t0 )  

       generate_web_viewer(pathwork, data_list_plot, output_filename="pikobs_viewer_cardio.html")



def arg_call():
    import argparse
    import sys

    parser = argparse.ArgumentParser()
    parser.add_argument('--path_experience_files', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--experience_name', default='undefined', type=str, help="experience's name")
    parser.add_argument('--pathwork', default='undefined', type=str, help="Working directory")
    parser.add_argument('--datestart', default='undefined', type=str, help="Start date")
    parser.add_argument('--dateend', default='undefined', type=str, help="End date")
    parser.add_argument('--region', nargs="+", default='undefined', type=str, help="Region")
    parser.add_argument('--family', nargs="+", default='undefined', type=str, help="Family")
    parser.add_argument('--flags_criteria', nargs="+", default='undefined', type=str, help="Flags criteria")
    parser.add_argument('--id_stn',nargs="+", default='all', type=str, help="id_stn") 
    parser.add_argument('--channel',nargs="+",  default='all', type=str, help="channel") 
    parser.add_argument('--plot_type', default='wide', type=str, help="channel")
    parser.add_argument('--plot_title', default='plot', type=str, help="channel")
    parser.add_argument('--n_cpus', default=1, type=int, help="Number of cpus")
    parser.add_argument('--varnos', nargs="+", default='undefined', type=str, help="Function")
   
    args = parser.parse_args()
    print ( "Inputs in cardiogram calculation")
    print ("----------------------------------------")

    for arg in vars(args):
      
       print (f'--{arg} {getattr(args, arg)}')
    print ("----------------------------------------")
    # check if each argument is 'undefined'
    if args.path_experience_files == 'undefined':
        raise ValueError('You must specify --path_experience_files')
    if args.experience_name == 'undefined':      
        raise ValueError('You must specify -experience_name') 
    if args.varnos == 'undefined':
        args.varnos = []
    if args.pathwork  == 'undefined':
        raise ValueError('You must specify --pathwork')
    if args.datestart == 'undefined':
        raise ValueError('You must specify --datestart')
    if args.dateend == 'undefined':
        raise ValueError('You must specify --dateend')
    if args.region == 'undefined':
        raise ValueError('You must specify --region')
    if args.family == 'undefined':
        raise ValueError('You must specify --family')
    if args.flags_criteria == 'undefined':
        raise ValueError('You must specify --flags_criteria')
   # if args.fonction == 'undefined':
   #     raise ValueError('You must specify --fonction')

    #Call your function with the arguments
    sys.exit(make_cardio (args.path_experience_files,
                          args.experience_name,
                          args.pathwork,
                          args.datestart,
                          args.dateend,
                          args.region,
                          args.family,
                          args.flags_criteria,
                          args.id_stn,
                          args.channel,
                          args.plot_type,
                          args.plot_title,
                          args.n_cpus,
                          args.varnos))

