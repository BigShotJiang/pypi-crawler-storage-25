"""
===================
Profile Diagnostic
===================

The **Pikobs Profile** is a diagnostic tool designed to evaluate the vertical
structure of observation residuals and the statistical impact of assimilation
experiments through interactive vertical profile plots and web interfaces.

Core Visualization: The Vertical Profile Plot
---------------------------------------------

The engine generates a synchronized vertical profile plot comparing a
**Control** run against an **Experiment** run. This layout allows researchers
to evaluate changes in bias, spread, and distribution at every pressure level
or channel simultaneously.

.. image:: _static/profile.png
   :align: center
   :alt: Vertical Profile Statistical Analysis — Control vs Experiment
   :width: 900px

.. centered::
   *Example: Vertical profile plot for GOES19 — Var 11002
   (2026031000 to 2026031500). Left panel shows Bias and StdDev curves.
   Right table shows per-level statistical significance for
   F-test, T-Welch, and Chi2-test.*

----

**Plot Structure:**

* **Left panel:** Vertical profile curves showing Bias (solid line),
  Standard Deviation (dashed line), and the min-max residual range
  (shaded band) for both Control (blue) and Experiment (red).

* **Right table:** Per-level statistical metrics with six columns:
  observation counts for each run, RMSE difference, and significance
  results (confidence % and direction) for three independent statistical
  tests.

* **Guide box:** Full explanation of every test, formula, hypothesis,
  and how to read the results — embedded directly in the figure for
  quick reference without needing external documentation.

----

Scientific Background: What Are We Measuring?
---------------------------------------------

The profile diagnostic operates on aggregated residuals stored in the
SQLite database table ``moyenne``. For each pressure level or channel,
the following quantities are computed directly in SQL:

**Bias** (mean residual)::

    Bias = SUM(y_i) / N

**Standard Deviation** (spread around the mean)::

    StdDev = sqrt( SUM(y_i^2) / N  -  ( SUM(y_i) / N )^2 )

where ``y_i`` are the individual observation residuals (OMP or OMA)
and ``N`` is the total observation count at that level.

.. note::

   The profile diagnostic works with **aggregated statistics**, not
   individual observations. This means the tests use the computed
   ``(Bias, StdDev, N)`` triplet rather than raw residuals.
   The F-test and T-test are mathematically exact under this formulation.
   The Chi-squared test uses a normal approximation of the residual
   distribution.

----

Statistical Tests: Complete Reference
--------------------------------------

The profile diagnostic applies **four independent statistical evaluations**
at every pressure level or channel. Each test addresses a different
scientific question about what changed between the control and experiment.

Confidence Level Convention
~~~~~~~~~~~~~~~~~~~~~~~~~~~

All tests report a **confidence percentage** rather than a raw p-value::

    Confidence (%) = (1 - p_value) x 100

This makes the result more intuitive to interpret:

+---------------+----------+-------------------------------------------+
| Confidence    | p-value  | Interpretation                            |
+===============+==========+===========================================+
| > 99.9%       | < 0.001  | Extremely strong evidence of real change  |
+---------------+----------+-------------------------------------------+
| 98.0%         | 0.020    | Strong evidence                           |
+---------------+----------+-------------------------------------------+
| 95.2%         | 0.048    | Just above threshold — significant        |
+---------------+----------+-------------------------------------------+
| 94.0%         | 0.060    | Just below threshold — NOT significant    |
+---------------+----------+-------------------------------------------+
| 50.0%         | 0.500    | No evidence at all                        |
+---------------+----------+-------------------------------------------+

**Threshold:** Confidence >= 95% means statistically significant (p < 0.05).

The key insight is that the p-value answers the question:

   *"If the control and experiment were truly identical, what is the
   probability of observing a difference this large just by chance?"*

If that probability is less than 5% (confidence > 95%), we conclude
the difference is real and not random noise.

----

Test 1: RMSE — Root Mean Square Error
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Scientific question:** Did the experiment reduce the overall
error magnitude?

**Formula**::

    RMSE = sqrt( Bias^2 + StdDev^2 )

**Physical interpretation:**

RMSE decomposes the total error into two orthogonal components:

* ``Bias^2`` — the **systematic** component: a constant offset from truth
  related to model drift or sensor calibration.
* ``StdDev^2`` — the **random** component: observation-to-observation
  variability related to instrument noise and representativity errors.

**Difference metric displayed in the table**::

    RMSE_diff (%) = ( RMSE_ctrl - RMSE_exp ) / RMSE_ctrl  x  100

+------------------+-----------------------------------------------+
| Sign             | Meaning                                       |
+==================+===============================================+
| Positive (+)     | Experiment has LOWER RMSE — improved          |
+------------------+-----------------------------------------------+
| Negative (-)     | Experiment has HIGHER RMSE — degraded         |
+------------------+-----------------------------------------------+

.. note::

   RMSE is a **descriptive metric** only. It has no associated p-value
   or hypothesis test. It quantifies the magnitude of change but cannot
   tell you whether that change is statistically real or due to chance.
   Always cross-reference with the F-test and T-test results.

**Manual calculation example**:

.. code-block:: text

    bias_ctrl = -0.52,  std_ctrl = 1.20
    bias_exp  = -0.31,  std_exp  = 1.18

    RMSE_ctrl = sqrt( (-0.52)^2 + (1.20)^2 )
              = sqrt( 0.2704 + 1.4400 )
              = sqrt( 1.7104 )
              = 1.308

    RMSE_exp  = sqrt( (-0.31)^2 + (1.18)^2 )
              = sqrt( 0.0961 + 1.3924 )
              = sqrt( 1.4885 )
              = 1.220

    RMSE_diff = (1.308 - 1.220) / 1.308 x 100
              = +6.7%   →  experiment improved global error

----

Test 2: F-test — Equality of Variances
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Scientific question:** Did the **spread** (dispersion) of residuals
change significantly between the control and experiment?

**Hypotheses**:

* **H0 (null):**  ``var_ctrl = var_exp``
  (the variances are equal — no real change in spread)
* **H1 (alternative):** ``var_ctrl != var_exp``
  (the variances differ — the experiment changed the spread)

**Test statistic**::

    F = var_ctrl / var_exp
      = std_ctrl^2 / std_exp^2

    Follows an F distribution with:
      df1 = n_ctrl - 1
      df2 = n_exp  - 1
    under H0.

**Two-sided p-value**::

    p = 2 x min( CDF_F(F, df1, df2),  1 - CDF_F(F, df1, df2) )

A **two-sided** test is used because we want to detect both:

* ``F >> 1`` — experiment spread **increased** (potential degradation)
* ``F << 1`` — experiment spread **decreased** (potential improvement)

**Decision rule:**

+--------------------------------------+------------------------------------+
| Condition                            | Table result                       |
+======================================+====================================+
| conf >= 95% and std_exp < std_ctrl   | **Better** — spread reduced        |
+--------------------------------------+------------------------------------+
| conf >= 95% and std_exp > std_ctrl   | **Worse**  — spread increased      |
+--------------------------------------+------------------------------------+
| conf < 95%                           | **—** not significant              |
+--------------------------------------+------------------------------------+

**Manual calculation**:

.. code-block:: text

    std_ctrl = 1.20  →  var_ctrl = 1.44
    std_exp  = 1.18  →  var_exp  = 1.3924
    n_ctrl   = 3614,     n_exp   = 4628

    Step 1: F = 1.44 / 1.3924 = 1.034
    Step 2: df1 = 3613,  df2 = 4627
    Step 3: F near 1.0  →  very little evidence of real change
    Step 4: p >> 0.05   →  NOT significant  (conf << 95%)

    Rule of thumb (large N):
      F > 2.0  or  F < 0.5  →  likely significant
      F between 0.8 and 1.2 →  likely NOT significant

----

Test 3: Welch's T-test — Equality of Means / Bias
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Scientific question:** Did the **systematic bias** (mean residual)
change significantly between the control and experiment?

**Hypotheses**:

* **H0 (null):** ``bias_ctrl = bias_exp``
  (the biases are equal — no real change in systematic error)
* **H1 (alternative):** ``bias_ctrl != bias_exp``
  (the biases differ — the experiment changed the systematic error)

**Test statistic**::

    SE = sqrt( std_ctrl^2/n_ctrl  +  std_exp^2/n_exp )

    t  = ( bias_ctrl - bias_exp ) / SE

**Why Welch and not Student's t-test?**

The classical Student's t-test assumes ``std_ctrl = std_exp``.
This is almost never true in NWP verification where different model
configurations produce different spread characteristics. Welch's t-test
makes **no such assumption** and is therefore more conservative and more
appropriate for this application.

**Degrees of freedom — Welch-Satterthwaite approximation**::

    A   = std_ctrl^2 / n_ctrl
    B   = std_exp^2  / n_exp

    DOF = (A + B)^2  /  ( A^2/(n_ctrl-1)  +  B^2/(n_exp-1) )

This formula adjusts the effective degrees of freedom downward when the
two groups have very different variances, making the test more
conservative and preventing false positives.

**Decision rule:**

+--------------------------------------------+-------------------------------------+
| Condition                                  | Table result                        |
+============================================+=====================================+
| conf >= 95% and |bias_exp| < |bias_ctrl|   | **Better** — bias closer to zero    |
+--------------------------------------------+-------------------------------------+
| conf >= 95% and |bias_exp| > |bias_ctrl|   | **Worse**  — bias further from 0    |
+--------------------------------------------+-------------------------------------+
| conf < 95%                                 | **—** not significant               |
+--------------------------------------------+-------------------------------------+

**Critical t-values for quick manual check** (large N approximates normal):

+---------------------+------------------+
| Absolute t greater  | Confidence       |
+=====================+==================+
| 1.645               | > 90%            |
+---------------------+------------------+
| 1.960               | > 95%  (*)       |
+---------------------+------------------+
| 2.576               | > 99%            |
+---------------------+------------------+
| 3.291               | > 99.9%          |
+---------------------+------------------+

**Manual calculation example**:

.. code-block:: text

    bias_ctrl = -0.52,  std_ctrl = 1.20,  n_ctrl = 3614
    bias_exp  = -0.31,  std_exp  = 1.18,  n_exp  = 4628

    A   = 1.44   / 3614 = 0.000398
    B   = 1.3924 / 4628 = 0.000301

    SE  = sqrt(0.000398 + 0.000301)
        = sqrt(0.000699)
        = 0.02644

    t   = ( -0.52 - (-0.31) ) / 0.02644
        = -0.21 / 0.02644
        = -7.94

    |t| = 7.94  >>  1.960  →  conf > 99.9%  →  SIGNIFICANT
    |bias_exp| = 0.31  <  |bias_ctrl| = 0.52  →  Better

    Welch-Satterthwaite DOF:
    DOF = (0.000398 + 0.000301)^2 /
          ( 0.000398^2/3613  +  0.000301^2/4627 )
        = 4.886e-7 / 6.342e-11
        = 7704   (effectively a normal distribution)

----

Test 4: Chi-squared Test — Distribution Shape
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Scientific question:** Did the **full distribution shape** of residuals
change significantly — beyond just the mean or variance?

This test is complementary to the F-test and T-test. A distribution can
change shape (become skewed, develop heavier tails, bimodal structure, etc.)
without the mean or variance changing significantly. The chi-squared test
catches these more subtle structural changes.

**Hypotheses**:

* **H0 (null):** The experiment residuals follow the same distribution
  as the control residuals (shape unchanged).
* **H1 (alternative):** The distribution shapes differ significantly.

**Test statistic**::

    chi2 = SUM_i  ( O_i - E_i )^2 / E_i

    where:
      O_i = experiment bin counts  (observed)
      E_i = control bin counts scaled to n_exp  (expected)
      k   = number of valid bins after merging

**Bin construction**::

    center = ( bias_ctrl + bias_exp ) / 2
    sigma  = max( std_ctrl, std_exp )
    range  = center  +-  4 x sigma     (captures 99.994% of the distribution)
    bins   = 24 equally spaced bins over this range

Using **+-4 sigma** instead of +-3 sigma is critical:

* +-3 sigma captures only 99.73% of the distribution, leaving 0.27%
  in the tails. This truncation causes ``SUM(E_i) != SUM(O_i)``,
  which triggers a ``ValueError`` in ``scipy.stats.chisquare``.
* +-4 sigma reduces the truncation to 0.006%, essentially eliminating
  the floating-point sum mismatch.

**Sum-mismatch fix**::

    E_i  =  E_i  x  ( SUM(O_i) / SUM(E_i) )

This explicit rescaling forces ``SUM(E_i) == SUM(O_i)`` exactly
before passing to ``scipy.stats.chisquare``.

**Bin merging requirement:**

The chi-squared approximation is only valid when ``E_i >= 5`` in every bin.
Bins with fewer expected counts are merged with their neighbours before
computing the statistic. Degrees of freedom are updated accordingly::

    DOF = k - 1

where ``k`` is the number of bins **after** merging.

**Direction determination:**

The chi-squared statistic has **no sign** — it only tells you whether
the distributions differ, not in which direction. Direction is determined
by comparing RMSE:

+-----------------------------------------------+-------------------------------------+
| Condition                                     | Table result                        |
+===============================================+=====================================+
| conf >= 95% and RMSE_exp < RMSE_ctrl          | **Better** — overall error down     |
+-----------------------------------------------+-------------------------------------+
| conf >= 95% and RMSE_exp >= RMSE_ctrl         | **Worse**  — overall error up       |
+-----------------------------------------------+-------------------------------------+
| conf < 95%                                    | **—** not significant               |
+-----------------------------------------------+-------------------------------------+

**Chi-squared critical values for manual check:**

+-------+--------------------+
| DOF   | chi2 critical 95%  |
+=======+====================+
| 5     | 11.07              |
+-------+--------------------+
| 10    | 18.31              |
+-------+--------------------+
| 15    | 24.99              |
+-------+--------------------+
| 20    | 31.41              |
+-------+--------------------+

----

Reading the Results Table
--------------------------

The right panel of every profile plot contains a table with one row
per pressure level or channel:

+---------------------+----------------------------------------------------------+
| Column              | Content                                                  |
+=====================+==========================================================+
| control (N)         | Number of observations used in the control run           |
+---------------------+----------------------------------------------------------+
| experiment (N)      | Number of observations used in the experiment run        |
+---------------------+----------------------------------------------------------+
| RMSE Diff (%)       | Percentage change in RMSE. Positive = improved.          |
+---------------------+----------------------------------------------------------+
| Var Sig. (F-test)   | F-test confidence % and Better / Worse / — result        |
+---------------------+----------------------------------------------------------+
| Bias Sig. (T-Welch) | T-Welch confidence % and Better / Worse / — result       |
+---------------------+----------------------------------------------------------+
| Dist. Sig. (Chi2)   | Chi2 confidence % and Better / Worse / — result          |
+---------------------+----------------------------------------------------------+

**Colour convention:**

* **Red**   confidence % — experiment is better (improved)
* **Blue**  confidence % — experiment is worse  (degraded)
* **Black** confidence % — below 95% threshold  (not significant)
* **Gray —** — not significant at the 95% level
* **N/A**   — insufficient data to compute the test at this level

.. note::

   **Single-run mode:** If only ``--control_name`` is provided without
   ``--experience_name``, no statistical tests are performed. Only the
   control profile and observation counts are shown.

----

Interactive Web Viewer
-----------------------

Beyond static plots, Pikobs automatically generates a **Smart Web Viewer**
for rapid multi-dimensional analysis directly in your browser.

**Features:**

* **Dynamic dropdowns:** Only valid combinations of family, region,
  station, varno, vcoord, function, and criteria are shown.
  Selecting one filter automatically narrows all downstream options.
* **Flip-Flop mode:** Instantly toggle between two selections to detect
  subtle changes without losing visual focus.
  Press the **Flip-Flop** button or use the keyboard shortcut **F**.
* **Self-contained:** The viewer is a single ``.html`` file with no
  external dependencies — works offline and on any browser.

.. list-table::
   :widths: 30 70

   * - **Dropdown order**
     - Family → Region → Station → Varno → Vcoord → Function → Criteria
   * - **Flip-Flop shortcut**
     - Press ``F`` on the keyboard
   * - **Image not found**
     - A clear warning is shown if the plot was not yet generated

**Explore the Viewer:**
`Interactive Profile Web Viewer <https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobsprofile/pikobs_profile_viewer.html>`_

.. code-block:: text

    Direct URL:
    https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobsprofile/pikobs_profile_viewer.html

----

HPC Execution
--------------

To maintain system stability on ECCC clusters, always execute on a
dedicated compute node.

**1. Initialize interactive session:**

.. code-block:: bash

    qsub -I -X -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb \
         -l place=scatter -l walltime=6:0:0

**2. Generate profile diagnostics:**

.. code-block:: bash

    python -c 'import pikobs; pikobs.profile.arg_call()' \\
        --path_control_files     /home/dlo001/sites8/TESTg0/         \\
        --control_name           control                              \\
        --path_experience_files  /home/dlo001/sites8/TESTg2/         \\
        --experience_name        expericience                         \\
        --pathwork               /home/dlo001/sites8/pikobsprofile    \\
        --datestart              2026031000                           \\
        --dateend                2026031500                           \\
        --region                 Monde                                \\
        --family                 sw                                   \\
        --flags_criteria         assimilee                            \\
        --fonction               omp oma                              \\
        --id_stn                 all                                  \\
        --channel                all                                  \\
        --n_cpu                  80

**Argument Reference:**

+-----------------------------+------------------------------------------------+
| Argument                    | Description                                    |
+=============================+================================================+
| ``--path_control_files``    | Path to the control experiment SQLite files    |
+-----------------------------+------------------------------------------------+
| ``--control_name``          | Label for the control run (e.g. ``control``)   |
+-----------------------------+------------------------------------------------+
| ``--path_experience_files`` | Path to the experiment SQLite files            |
+-----------------------------+------------------------------------------------+
| ``--experience_name``       | Label for the experiment run                   |
+-----------------------------+------------------------------------------------+
| ``--pathwork``              | Output directory for plots and web viewer      |
+-----------------------------+------------------------------------------------+
| ``--datestart``             | Start date ``YYYYMMDDHH`` (e.g. 2026031000)    |
+-----------------------------+------------------------------------------------+
| ``--dateend``               | End date ``YYYYMMDDHH`` (e.g. 2026031500)      |
+-----------------------------+------------------------------------------------+
| ``--region``                | Region(s): ``Monde``, ``Canada``, ``NH``, etc. |
+-----------------------------+------------------------------------------------+
| ``--family``                | Observation family: ``sw``, ``ua``, ``ai``     |
+-----------------------------+------------------------------------------------+
| ``--flags_criteria``        | Quality flag filter: ``assimilee``, etc.       |
+-----------------------------+------------------------------------------------+
| ``--fonction``              | Variable(s) to plot: ``omp``, ``oma``, etc.    |
+-----------------------------+------------------------------------------------+
| ``--id_stn``                | Station / satellite filter (``all`` = all)     |
+-----------------------------+------------------------------------------------+
| ``--channel``               | Channel filter (``all`` = all channels)        |
+-----------------------------+------------------------------------------------+
| ``--n_cpu``                 | Number of CPUs for parallel processing         |
+-----------------------------+------------------------------------------------+

.. note::

   Omitting ``--path_experience_files`` and ``--experience_name`` runs
   the tool in **single-run mode**: only the control profile is plotted
   and no statistical tests are performed.

**3. Expected shell output:**

.. code-block:: text

    [PIKOBS] Initializing Profile Diagnostic Engine...
    [INFO]   Detected 80 CPUs for parallel processing.
    [DB]     Connecting to control    DB: .../TESTg0/profile_control_Monde_...sw.db
    [DB]     Connecting to experiment DB: .../TESTg2/profile_expericience_Monde_...sw.db
    [PARALLEL] Processing GOES19  | varno=11002 | vcoord=all | fonction=omp ...
    [PARALLEL] Processing GOES19  | varno=11002 | vcoord=all | fonction=oma ...
    [PARALLEL] Processing NOAA20  | varno=11003 | vcoord=all | fonction=omp ...
    [PARALLEL] Processing NOAA21  | varno=11004 | vcoord=all | fonction=oma ...
    [WEB]    Compiling interactive profile viewer...
    Plot saved: .../sw/omp_sw_control_vs_expericience_Monde_GOES19_11002_all_..._assimilee.png
    Plot saved: .../sw/oma_sw_control_vs_expericience_Monde_GOES19_11002_all_..._assimilee.png
    Profile viewer saved: .../pikobsprofile/pikobs_profile_viewer.html  (18 entries)
    [DONE]   All profile diagnostics completed successfully.

----

Support and Issues
-------------------

Pikobs is maintained for the ECCC community. For bug reports, feature
requests, or questions about the statistical methodology, please use
the official GitLab repository:

**GitLab Issues:**
`https://gitlab.science.gc.ca/dlo001/Pikobs <https://gitlab.science.gc.ca/dlo001/Pikobs>`_
"""

import os
import sys
import datetime
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import sqlalchemy
import pikobs

mpl.use('Agg')


def days_between(d1, d2):
    d1_obj = datetime.datetime.strptime(d1, "%Y%m%d%H")
    d2_obj = datetime.datetime.strptime(d2, "%Y%m%d%H")
    return abs((d2_obj - d1_obj).days)



    print(f"Saved: {output_file}")
import sqlite3
import pikobs
import re
import os
from  dask.distributed import Client
import numpy as np
import sqlite3
import os
import re
import sqlite3
from datetime import datetime, timedelta
import warnings
# Suppress all Shapely deprecation warnings
warnings.filterwarnings("ignore", ".*ShapelyDeprecationWarning.*")

# Now, import the libraries you're using
import shapely
import cartopy
def create_table_if_not_exists(cursor):
    """
    Create the 'serie_cardio' table if it does not already exist.

    Args:
        cursor (sqlite3.Cursor): Database cursor for executing SQL queries.
    """
    query = """
        CREATE TABLE IF NOT EXISTS moyenne (
            Nrej INTEGER,
            Nacc INTEGER,
            Nprofile INTEGER,
            DATE INTEGER,
            lat FLOAT,
            lon FLOAT,
            boite INTEGER,
            id_stn TEXT,
            varno INTEGER,
            vcoord FLOAT,   -- INTEGER FLOAT canal
            sumx FLOAT,
            sumy FLOAT,
            sumz FLOAT,
            sumStat FLOAT,
            sumx2 FLOAT,
            sumy2 FLOAT,
            sumz2 FLOAT,
            sumStat2 FLOAT,
            n INTEGER,
            flag INTEGER
        ); """
    cursor.execute(query)

def combine(pathfileout: str, filememory: str) -> None:
    """
    Combine multiple SQLite files into a single output file.

    This function copies records from the 'moyenne' table of a source SQLite file 
    (filememory) and inserts them into the 'moyenne' table of a destination/output SQLite file (pathfileout).
    
    Args:
        pathfileout (str): Path to the output SQLite file where combined data will be stored.
        filememory  (str): Path to the source SQLite file (can be memory or disk).
        
    Returns:
        None. The result is saved directly in the specified output file.
    """
    insert_sql = """
        INSERT INTO moyenne(
            Nrej, Nacc, Nprofile, DATE, lat, lon, boite, id_stn, varno, vcoord, sumx, sumy, sumz, 
            sumStat, sumx2, sumy2, sumz2, sumStat2, n, flag
        )
        SELECT 
            Nrej, Nacc, Nprofile, DATE, lat, lon, boite, id_stn, varno, vcoord, sumx, sumy, sumz, 
            sumStat, sumx2, sumy2, sumz2, sumStat2, n, flag
        FROM this_avg_db.moyenne
    """

    # Use 'with' statement to ensure connection is properly closed
    with sqlite3.connect(pathfileout, uri=True, isolation_level=None, timeout=9999) as conn:
        try:
            # Set performance-optimized PRAGMAs, provided your application allows for non-durable writes
            conn.execute("PRAGMA journal_mode=OFF;")
            conn.execute("PRAGMA synchronous=OFF;")

            # Ensure the table exists
            create_table_if_not_exists(conn)

            # Attach the source SQLite database
            conn.execute(f"ATTACH DATABASE '{filememory}' AS this_avg_db;")

            # Copy data
            conn.execute(insert_sql)
            conn.commit()

            # Detach the attached database
            conn.execute("DETACH DATABASE this_avg_db;")
        except sqlite3.Error as e:
            print(f"Error combining SQLite files: {e}")
            raise
def create_and_populate_moyenne_table(
        family,
        new_db_filename: str,
        existing_db_filename: str,
        selected_region,
        selected_flags,
        FUNCTION,
        varnos,
        channel: str,
        id_stn: str) -> None:
    """
    Creates a 'moyenne' aggregation table from a source SQLite observation
    database and merges the result into a destination SQLite database.

    The function operates in three stages:
      1. Opens an in-memory SQLite database for fast aggregation.
      2. Runs a GROUP BY INSERT query that computes sums and counts
         per (date, station, variable, vertical coordinate).
      3. Merges the in-memory result into the persistent output file
         via :func:`combine`.

    Parameters
    ----------
    family : any
        Observation family code passed to ``pikobs.family()``.
        Controls which vertical coordinate and criteria are used.
        Special case: if ``family == 'ra'``, the ``header.elevation``
        column is included in the SELECT and GROUP BY, producing one
        row per unique station elevation. For all other families,
        elevation is set to NULL and ignored in aggregation.
    new_db_filename : str
        Path to the destination SQLite file.
        The 'moyenne' table is created here if it does not exist,
        or new rows are appended if it already exists.
    existing_db_filename : str
        Path to the source SQLite file containing the raw
        ``header`` and ``DATA`` tables.
        The date is extracted automatically from the filename
        (first 10-digit sequence found with regex).
    selected_region : any
        Region identifier passed to ``pikobs.regions()``.
        Determines the lat/lon bounding box applied in the WHERE clause.
    selected_flags : any
        Flag filter passed to ``pikobs.flag_criteria()``.
        Controls which quality-flag conditions are included.
    FUNCTION : any
        Function/operation identifier.
        Reserved for future use — not applied in the current query.
    varnos : list or str
        Variable numbers to filter (e.g. ``[11002, 11003]``).
        If provided, overrides the default element set from
        ``pikobs.family()``.
    channel : str
        Vertical coordinate grouping strategy.
        Accepted values:

        * ``'all'``  — group by the actual vertical coordinate value.
        * ``'join'`` — collapse all channels into a single 'join' label.

    id_stn : str
        Station grouping strategy.
        Accepted values:

        * ``'all'``  — group by the actual station identifier.
        * ``'join'`` — collapse all stations into a single 'join' label.

    Returns
    -------
    None
        The function writes directly to ``new_db_filename``.
        No value is returned.

    Raises
    ------
    ValueError
        If the source filename contains no 10-digit date sequence.
    ValueError
        If the ``channel`` / ``id_stn`` combination is not supported.

    Notes
    -----
    Supported ``channel`` x ``id_stn`` combinations:

    +------------------+------------------+----------------------------------+
    | channel          | id_stn           | GROUP BY behaviour               |
    +==================+==================+==================================+
    | 'join'           | 'all'            | group by station, date           |
    +------------------+------------------+----------------------------------+
    | 'all'            | 'join'           | group by vertical coord, date    |
    +------------------+------------------+----------------------------------+
    | 'all'            | 'all'            | group by station + vcoord, date  |
    +------------------+------------------+----------------------------------+
    | 'join'           | 'join'           | group by date only               |
    +------------------+------------------+----------------------------------+

    Family 'ra' elevation handling:
        Radio-sounding observations store the physical station elevation
        (metres above sea level) in ``header.elevation``. For this family,
        elevation is added to SELECT and GROUP BY so that statistics are
        computed separately for each unique elevation level. For all other
        families, elevation is NULL and does not affect aggregation.

    The ``moyenne`` table schema::

        Nrej      INTEGER   -- rejected observation count  (flag & 512)
        Nacc      INTEGER   -- accepted observation count  (flag & 4096-4094)
        Nprofile  INTEGER   -- distinct profile count      (COUNT DISTINCT id_obs)
        DATE      INTEGER   -- 10-digit date from source filename
        lat       FLOAT     -- latitude
        lon       FLOAT     -- longitude
        boite     INTEGER   -- box index (unused in current query)
        id_stn    TEXT      -- station identifier (or 'join')
        varno     INTEGER   -- variable number
        vcoord    FLOAT     -- vertical coordinate (or 'join')
        sumx      FLOAT     -- SUM(omp)
        sumy      FLOAT     -- SUM(oma)
        sumz      FLOAT     -- SUM(obsvalue)
        sumStat   FLOAT     -- SUM(bias_corr) or NULL
        sumx2     FLOAT     -- SUM(omp * omp)
        sumy2     FLOAT     -- SUM(oma * oma)
        sumz2     FLOAT     -- SUM(obsvalue * obsvalue)
        sumStat2  FLOAT     -- SUM(bias_corr^2) or NULL
        n         INTEGER   -- total observation count
        flag      INTEGER   -- raw flag value
        elevation FLOAT     -- station elevation metres (ra family only, NULL otherwise)

    Performance pragmas applied to the in-memory connection::

        PRAGMA journal_mode = MEMORY
        PRAGMA synchronous  = OFF
        PRAGMA foreign_keys = OFF
    """

    # =========================================================================
    # STEP 1 — Extract 10-digit date from the source filename
    # =========================================================================
    date_match = re.search(r'(\d{10})', existing_db_filename)
    if not date_match:
        raise ValueError(
            f"No 10-digit date sequence found in source filename: "
            f"'{existing_db_filename}'"
        )
    date_str = date_match.group(1)

    # =========================================================================
    # STEP 2 — Resolve family metadata and variable list
    # =========================================================================
    FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)

    # Override the default element set if varnos were explicitly provided
    if varnos:
        element = ",".join(str(v) for v in varnos)

    # =========================================================================
    # STEP 3 — Build channel / station SELECT and GROUP BY clauses
    #
    # Four supported combinations control how observations are aggregated:
    #
    #   channel='join', id_stn='all'  → one row per station,
    #                                   all channels merged
    #   channel='all',  id_stn='join' → one row per channel,
    #                                   all stations merged
    #   channel='all',  id_stn='all'  → one row per station+channel
    #   channel='join', id_stn='join' → single row per date (fully collapsed)
    # =========================================================================
    if channel == 'join' and id_stn == 'all':
        chan_select   = '"join" AS Chan,'
        id_stn_select = 'id_stn AS id_stn,'
        group_by      = 'GROUP BY 2, 3, 4, 5, id_stn'

    elif channel == 'all' and id_stn == 'join':
        chan_select   = f'{VCOORD} AS Chan,'
        id_stn_select = '"join" AS id_stn,'
        group_by      = f'GROUP BY 2, 3, 4, 5, {VCOORD}'

    elif channel == 'all' and id_stn == 'all':
        chan_select   = f'{VCOORD} AS Chan,'
        id_stn_select = 'id_stn AS id_stn,'
        group_by      = f'GROUP BY 2, 3, 4, 5, id_stn, {VCOORD}'

    elif channel == 'join' and id_stn == 'join':
        chan_select   = '"join" AS Chan,'
        id_stn_select = '"join" AS id_stn,'
        group_by      = 'GROUP BY 2, 3, 4, 5, date'

    else:
        raise ValueError(
            f"Unsupported channel/id_stn combination: "
            f"channel='{channel}', id_stn='{id_stn}'. "
            f"Accepted values are 'all' or 'join' for each argument."
        )

    # =========================================================================
    # STEP 3b — Elevation handling (family 'ra' only)
    #
    # Radio-sounding observations (family='ra') store the physical station
    # elevation (metres above sea level) in header.elevation.
    # We add it to SELECT and GROUP BY so that statistics are split by
    # elevation level, which is scientifically meaningful for surface-based
    # radiosonde stations located at very different altitudes.
    #
    # For all other families the column does not exist in the header table,
    # so we emit NULL and do not add anything to GROUP BY.
    # =========================================================================
    if family == 'ra':
        elevation_select = 'header.elevation AS elevation'   # ← no trailing comma
        elevation_group  = ', header.elevation'
    else:
        elevation_select = 'NULL AS elevation'               # ← no trailing comma
        elevation_group  = '' 
    # =========================================================================
    # STEP 4 — Resolve spatial and quality-flag criteria
    # =========================================================================
    LAT1, LAT2, LON1, LON2 = pikobs.regions(selected_region)
    LATLONCRIT    = pikobs.generate_latlon_criteria(LAT1, LAT2, LON1, LON2)
    flag_criteria = pikobs.flag_criteria(selected_flags)

    # =========================================================================
    # STEP 5 — Open in-memory SQLite and run the aggregation INSERT
    # =========================================================================
    in_memory_db = "file::memory:?cache=shared"

    with sqlite3.connect(
            in_memory_db,
            uri=True,
            isolation_level=None,
            timeout=9_999_999) as mem_conn:

        cursor = mem_conn.cursor()

        # Performance pragmas — safe for an in-memory temporary database
        cursor.execute("PRAGMA journal_mode = MEMORY;")
        cursor.execute("PRAGMA synchronous  = OFF;")
        cursor.execute("PRAGMA foreign_keys = OFF;")

        # Attach the source database as schema 'db'
        cursor.execute(f"ATTACH DATABASE '{existing_db_filename}' AS db;")

        # ── Check whether bias_corr column exists in DATA ─────────────────────
        # We inspect the attached 'db' schema, not the in-memory schema,
        # because the in-memory DATA table does not exist yet.
        cursor.execute("PRAGMA db.table_info('DATA');")
        columns       = [col[1] for col in cursor.fetchall()]
        has_bias_corr = 'bias_corr' in columns

        sum_bias_corr  = "SUM(bias_corr)"              if has_bias_corr else "NULL"
        sum_bias_corr2 = "SUM(bias_corr * bias_corr)"  if has_bias_corr else "NULL"

        # ── Create the moyenne table if it does not yet exist ─────────────────
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS moyenne (
                Nrej      INTEGER,
                Nacc      INTEGER,
                Nprofile  INTEGER,
                DATE      INTEGER,
                lat       FLOAT,
                lon       FLOAT,
                boite     INTEGER,
                id_stn    TEXT,
                varno     INTEGER,
                vcoord    FLOAT,
                sumx      FLOAT,
                sumy      FLOAT,
                sumz      FLOAT,
                sumStat   FLOAT,
                sumx2     FLOAT,
                sumy2     FLOAT,
                sumz2     FLOAT,
                sumStat2  FLOAT,
                n         INTEGER,
                flag      INTEGER,
                elevation FLOAT
            );
        """)

        # ── Aggregation INSERT query ──────────────────────────────────────────
        # Column order in INSERT must match SELECT order exactly.
        # elevation is always the last column in both lists.
        insert_query = f"""
        INSERT INTO moyenne (
            DATE, lat, lon, varno, vcoord,
            sumx,  sumy,  sumz,  sumStat,
            sumx2, sumy2, sumz2, sumStat2,
            n, Nrej, Nacc, Nprofile, id_stn, flag,
            elevation
        )
        SELECT
            {date_str},
            LAT,
            LON,
            VARNO,
            {chan_select}
            SUM(omp),
            SUM(oma),
            SUM(obsvalue),
            {sum_bias_corr},
            SUM(omp      * omp),
            SUM(oma      * oma),
            SUM(obsvalue * obsvalue),
            {sum_bias_corr2},
            COUNT(*),
            SUM(flag & 512  = 512),
            SUM(flag & 4096 - 4094),
            COUNT(DISTINCT id_obs),
            {id_stn_select}
            flag,
            {elevation_select}
        FROM
            db.header
            NATURAL JOIN db.DATA
        WHERE
            varno      IN ({element})
            AND obsvalue IS NOT NULL
            {flag_criteria}
            {LATLONCRIT}
            {VCOCRIT}
        {group_by}{elevation_group};
        """
        cursor.execute(insert_query)
        mem_conn.commit()

        # =====================================================================
        # STEP 6 — Merge in-memory result into the persistent output file
        # =====================================================================
        try:
            combine(new_db_filename, in_memory_db)
        except sqlite3.Error as error:
            print(
                f"Error merging in-memory DB into "
                f"'{os.path.basename(new_db_filename)}': {error}"
            )

from datetime import datetime, timedelta
from typing import List, Dict, Any, Tuple

def create_data_list(
    date_start: str,
    date_end: str,
    families: List[str],
    input_paths: List[str],
    names: List[str],
    work_path: str,
    function: str,
    flag_criterias: List[ str],
    regions: List[Any],       # adjust type if you have a region class
    varnos: List[str]
) -> List[Dict[str, Any]]:
    """
    Builds a list of dictionaries containing all configuration info 
    for data processing at 6-hour intervals, for multiple families, 
    regions, input files, and intervals.

    Args:
        date_start (str): Start date string in format 'YYYYMMDDHH'.
        date_end (str): End date string in format 'YYYYMMDDHH'.
        families (List[str]): List of family names/codes.
        input_paths (List[str]): List of input file path prefixes.
        names (List[str]): List of dataset names.
        work_path (str): Path where output databases should be created.
        box_size_x (float): Size of the box in longitude.
        box_size_y (float): Size of the box in latitude.
        function (str): Function being applied (name/purpose).
        regions (List[Any]): List of region specifications.
        varnos (List[str]): List of variable numbers/codes.
        intervals (List[Tuple[Any, Any]]): List of interval tuples (min, max).

    Returns:
        List[Dict[str, Any]]: List of configuration dictionaries.
    """
    data_list = []
    print (date_start)
    
    dt_start = datetime.datetime.strptime(date_start, '%Y%m%d%H')
    dt_end = datetime.datetime.strptime(date_end, '%Y%m%d%H')
    delta = timedelta(hours=6)
    current_date = dt_start

    while current_date <= dt_end:
        formatted_date = current_date.strftime('%Y%m%d%H')
        # Nested loops over all combinations
        for family in families:
          for flag_criteria in flag_criterias:
            for region in regions:
                for name, input_path in zip(names, input_paths):

                        filename = f'{formatted_date}_{family}'
                        filein = f'{input_path}/{filename}'
                        db_new = (
                            f'{work_path}/{family}/profile_{name}_{region}_'
                            f'{date_start}_{date_end}_'
                            f'{flag_criteria}_{family}.db'
                        )

                        data_dict = {
                            'family': family,
                            'filein': filein,
                            'db_new': db_new,
                            'region': region,
                            'flag_criteria': flag_criteria,
                            'function': function,
                            'varnos': varnos,
                        }
                        data_list.append(data_dict)
        current_date += delta

    return data_list   
   
import sqlite3
import numpy as np

def get_id_stns(cursor, id_stn):
    """Obtiene la lista de id_stn desde la base de datos."""
    if id_stn == 'all':
        query = "SELECT DISTINCT id_stn FROM moyenne;"
        cursor.execute(query)
        return np.array([item[0] for item in cursor.fetchall()])
    return ['join']

def fetch_vcoords(cursor, criter):
    """Obtiene las coordenadas verticales y números de variable según el criterio dado."""
    query = f"SELECT DISTINCT 'all', varno FROM moyenne {criter} ORDER BY vcoord ASC;"
    cursor.execute(query)
    return cursor.fetchall()

def fetch_channels_varno(cursor):
    """Obtiene los números de variable de todos los canales."""
    query = "SELECT DISTINCT varno FROM moyenne ORDER BY vcoord ASC;"
    cursor.execute(query)
    return [item[0] for item in cursor.fetchall()]

def create_data_list_plot(
    date_start: str,
    date_end: str,
    families: List[str],
    namein: List[str],
    work_path: str,
    functions: List[str],
    flag_criterias:List[ str],
    regions: List[Any],
    id_stn: str,
    channel: str ) -> List[Dict[str, Any]]:
    """
    Generates a list of plotting dataset configurations for different intervals,
    families, regions, functions, channels, projections, and station IDs.

    Args:
        date_start (str): Starting date as 'YYYYMMDDHH'.
        date_end (str): Ending date as 'YYYYMMDDHH'.
        families (List[str]): List of family names/codes.
        namein (List[str]): Input dataset names (should be 1 or 2).
        work_path (str): Path prefix where database files are located.
        box_size_x (float): Box size in longitude.
        box_size_y (float): Box size in latitude.
        functions (List[str]): List of function names or codes.
        flag_criteria (str): Criteria as string for filtering.
        regions (List[Any]): List of region specifications.
        id_stn (str): 'all', 'join', or specific station ID.
        channel (str): 'all' or 'join'.
        projections (List[str]): List of projections to produce.
        intervals (List[Tuple[Any, Any]]): List of interval tuples (min, max).

    Returns:
        List[Dict[str, Any]]: List of plot dataset configuration dictionaries.
    """
    data_list_plot = []


    for family in families:
       for flag_criteria in flag_criterias:
            for region in regions:
                for function in functions:
                        # Build list of database files for this config
                        fileset = [
                            f'{work_path}/{family}/profile_{namein[0]}_{region}_{date_start}_{date_end}_{flag_criteria}_{family}.db'
                        ]
                        nameset = [namein[0]]
                        if len(namein) > 1:
                            file_b = f'{work_path}/{family}/profile_{namein[1]}_{region}_{date_start}_{date_end}_{flag_criteria}_{family}.db'
                            fileset.append(file_b)
                            nameset.append(namein[1])

                        # Open the first file in the set and process station IDs and vcoords
                        try:
                            with sqlite3.connect(fileset[0]) as conn:
                                cursor = conn.cursor()
                                id_stns = get_id_stns(cursor, id_stn)    # Returns List[str]

                                for idstn in id_stns:
                                    where_clause = '' if id_stn == 'join' else f'WHERE id_stn = "{idstn}"'
                                    if channel == 'all':
                                       vcoords = fetch_vcoords(cursor, where_clause)  # Returns List[Tuple[Any, int]]
                                       for vcoord, varno in vcoords:
                                            data_list_plot.append({
                                                'id_stn': idstn,
                                                'vcoord': 'all',
                                                'files_in': fileset,
                                                'varno': varno,
                                                'region': region,
                                                'function': function,
                                                'family': family,
                                                'criteria':flag_criteria
                                            })
                                    else:  # channel == 'join' or other
                                        channels_varnos = fetch_channels_varno(cursor)  # Returns List[int]
                                        for varno in channels_varnos:
                                            data_list_plot.append({
                                                'id_stn': idstn,
                                                'vcoord': 'join',
                                                'files_in': fileset,
                                                'varno': varno,
                                                'region': region,
                                                'function': function,
                                                'family': family,
                                                'criteria':flag_criteria
                                            })
                        except sqlite3.Error as err:
                            print(f"Warning: Could not open or query {fileset[0]}: {err}")
    return data_list_plot

import os

import os

import os

import os
#!/usr/bin/env python3
"""
generate_web.py
Generates a self-contained HTML monitoring page directly from data_list_plot.
"""

import os
import datetime

def generate_web(data_list_plot, pathwork, namesin, datestart, dateend,
                 output_filename="pikobs_profile_viewer.html"):
    """
    Generates an interactive HTML viewer for profile plots.
    Same style as generate_flags_viewer but adapted for profiles.
    """
    import json
    import os
    import datetime

    # =========================================================================
    # STEP 1 — Build exp_part for filename reconstruction
    # =========================================================================
    def _clean(name):
        return str(name).replace(' ', '').replace('/', '').replace('\\', '')

    exp_part   = (_clean(namesin[0]) if len(namesin) == 1
                  else f"{_clean(namesin[0])}_vs_{_clean(namesin[1])}")
    safe_start = str(datestart).replace('-', '')
    safe_end   = str(dateend).replace('-', '')

    # =========================================================================
    # STEP 2 — Build JS data list
    # =========================================================================
    js_data = []
    for entry in data_list_plot:
        safe_crit = str(entry['criteria']).replace(' ', '_')
        filename  = (
            f"{entry['function']}_"
            f"{entry['family']}_"
            f"{exp_part}_"
            f"{entry['region']}_"
            f"{entry['id_stn']}_"
            f"{entry['varno']}_"
            f"{entry['vcoord']}_"
            f"{safe_start}_"
            f"{safe_end}_"
            f"{safe_crit}.png"
        )
        js_data.append({
            'family'  : str(entry['family']).strip(),
            'region'  : str(entry['region']).strip(),
            'id_stn'  : str(entry['id_stn']).strip(),
            'varno'   : str(entry['varno']).strip(),
            'vcoord'  : str(entry['vcoord']).strip(),
            'function': str(entry['function']).strip(),
            'criteria': str(entry['criteria']).strip(),
            'filename': filename,
        })

    json_data  = json.dumps(js_data)
    run_label  = ' vs '.join(namesin) if len(namesin) > 1 else namesin[0]
    now        = datetime.datetime.now().strftime('%Y-%m-%d %H:%M UTC')

    # =========================================================================
    # STEP 3 — HTML
    # =========================================================================
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pikobs Profile Viewer</title>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        background-color: #f4f7f6;
        color: #333;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }
    .header {
        background-color: #2c3e50;
        color: white;
        padding: 20px;
        text-align: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .header p {
        margin: 5px 0 0 0;
        font-size: 14px;
        color: #bdc3c7;
    }
    .container {
        max-width: 1400px;
        margin: 20px auto;
        padding: 0 20px;
        flex: 1;
        width: 100%;
        box-sizing: border-box;
    }
    .controls {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        margin-bottom: 20px;
        justify-content: center;
        align-items: flex-end;
    }
    .control-group { display: flex; flex-direction: column; }
    label {
        font-weight: bold;
        margin-bottom: 5px;
        font-size: 13px;
        color: #34495e;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    select {
        padding: 10px;
        font-size: 14px;
        border: 1px solid #bdc3c7;
        border-radius: 4px;
        min-width: 160px;
        background-color: #fff;
        cursor: pointer;
        transition: border-color 0.3s;
    }
    select:focus {
        outline: none;
        border-color: #3498db;
        box-shadow: 0 0 5px rgba(52,152,219,0.3);
    }
    .btn-flipflop {
        background-color: #3498db;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: bold;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: background-color 0.3s, transform 0.1s;
        height: 40px;
    }
    .btn-flipflop:hover          { background-color: #2980b9; }
    .btn-flipflop:active         { transform: scale(0.96); }
    .btn-flipflop:disabled       { background-color: #95a5a6; cursor: not-allowed; }
    .btn-flipflop.active-flip    { background-color: #e67e22; }

    .image-container {
        text-align: center;
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        min-height: 500px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        position: relative;
    }
    img {
        max-width: 100%;
        height: auto;
        border-radius: 4px;
        display: none;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .error-msg {
        color: #e74c3c;
        font-weight: bold;
        font-size: 18px;
        display: none;
        flex-direction: column;
        align-items: center;
        gap: 10px;
    }
    .path-display {
        margin-top: 15px;
        font-family: monospace;
        color: #7f8c8d;
        font-size: 13px;
        background: #ecf0f1;
        padding: 10px;
        border-radius: 4px;
        width: 100%;
        box-sizing: border-box;
        word-break: break-all;
    }
    .badge {
        background: #2ecc71;
        color: white;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: bold;
        position: absolute;
        top: 20px;
        right: 20px;
        display: none;
    }
    .badge.previous { background: #e67e22; }

    .info-tags {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: center;
        margin-top: 10px;
    }
    .tag {
        padding: 3px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
    }
    .tag-family   { background: #d6eaf8; color: #1a5276; }
    .tag-station  { background: #d5f5e3; color: #1e8449; }
    .tag-varno    { background: #fef9e7; color: #9a7d0a; }
    .tag-vcoord   { background: #f9ebea; color: #922b21; }
    .tag-function { background: #e8daef; color: #6c3483; }
    .tag-region   { background: #eaf2ff; color: #1f618d; }

    .footer {
        text-align: center;
        padding: 20px;
        color: #7f8c8d;
        font-size: 14px;
        background-color: #ecf0f1;
        margin-top: auto;
    }
    .footer a {
        color: #3498db;
        text-decoration: none;
        font-weight: bold;
    }
    .footer a:hover { text-decoration: underline; }
</style>
</head>
<body>

<div class="header">
    <h1>Pikobs Profile Analysis Viewer</h1>
    <p>RUN_LABEL_PLACEHOLDER &nbsp;|&nbsp; DATESTART_PLACEHOLDER &rarr; DATEEND_PLACEHOLDER</p>
    <p style="font-size:13px;">Smart Selection: Dropdowns automatically adapt to valid combinations.</p>
</div>

<div class="container">
    <div class="controls">
        <div class="control-group">
            <label for="sel_family">1. Family</label>
            <select id="sel_family" onchange="renderSelects(0)"></select>
        </div>
        <div class="control-group">
            <label for="sel_region">2. Region</label>
            <select id="sel_region" onchange="renderSelects(1)"></select>
        </div>
        <div class="control-group">
            <label for="sel_id_stn">3. Station</label>
            <select id="sel_id_stn" onchange="renderSelects(2)"></select>
        </div>
        <div class="control-group">
            <label for="sel_varno">4. Varno</label>
            <select id="sel_varno" onchange="renderSelects(3)"></select>
        </div>
        <div class="control-group">
            <label for="sel_vcoord">5. Vcoord</label>
            <select id="sel_vcoord" onchange="renderSelects(4)"></select>
        </div>
        <div class="control-group">
            <label for="sel_function">6. Function</label>
            <select id="sel_function" onchange="renderSelects(5)"></select>
        </div>
        <div class="control-group">
            <label for="sel_criteria">7. Criteria</label>
            <select id="sel_criteria" onchange="renderSelects(6)"></select>
        </div>

        <button id="btn-flip" class="btn-flipflop"
                onclick="toggleFlipFlop()" disabled>
            &#8644; Flip-Flop
        </button>
    </div>

    <div class="image-container">
        <span id="status-badge" class="badge">Current Image</span>
        <div id="error-msg" class="error-msg">
            <span>&#9888; Image file not found on disk.</span>
            <span style="font-size:14px; color:#7f8c8d; font-weight:normal;">
                The combination exists in the list but the .png could not be loaded.
            </span>
        </div>
        <img id="plot-image" src="" alt="Profile Plot"
             onerror="handleImageError()" onload="handleImageLoad()">
        <div id="info-tags" class="info-tags"></div>
        <div id="path-display" class="path-display">Initializing viewer...</div>
    </div>
</div>

<div class="footer">
    If you encounter any issues or bugs, please open an issue at:<br>
    <a href="https://gitlab.science.gc.ca/dlo001/Pikobs"
       target="_blank">https://gitlab.science.gc.ca/dlo001/Pikobs</a>
</div>

<script>
// ── 1. Data injection ─────────────────────────────────────────────────────────
const rawData = JSON_DATA_PLACEHOLDER;
const dbData  = rawData.map(d => ({
    family  : String(d.family).trim(),
    region  : String(d.region).trim(),
    id_stn  : String(d.id_stn).trim(),
    varno   : String(d.varno).trim(),
    vcoord  : String(d.vcoord).trim(),
    function: String(d.function).trim(),
    criteria: String(d.criteria).trim(),
    filename: String(d.filename).trim(),
}));

// ── 2. Global state ───────────────────────────────────────────────────────────
let state = {
    family: null, region: null, id_stn: null,
    varno: null,  vcoord: null, function: null, criteria: null
};
let currentSrc  = "";
let previousSrc = "";
let showingPrev = false;

// ── 3. Helpers ────────────────────────────────────────────────────────────────
function naturalSort(a, b) {
    return String(a).localeCompare(String(b), undefined,
        { numeric: true, sensitivity: 'base' });
}
function getUnique(data, key) {
    return [...new Set(data.map(d => d[key]))].sort(naturalSort);
}
function populateDOM(id, values, prevValue) {
    const sel = document.getElementById(id);
    sel.innerHTML = '';
    values.forEach(v => sel.add(new Option(v, v)));
    sel.value = (prevValue && values.includes(prevValue))
                ? prevValue : (values[0] ?? '');
}

// ── 4. Cascade rendering ──────────────────────────────────────────────────────
function renderSelects(level) {
    if (level === -1)
        populateDOM('sel_family', getUnique(dbData, 'family'), null);
    state.family = document.getElementById('sel_family').value;

    if (level <= 0) {
        const v = dbData.filter(d => d.family === state.family);
        populateDOM('sel_region', getUnique(v, 'region'), state.region);
    }
    state.region = document.getElementById('sel_region').value;

    if (level <= 1) {
        const v = dbData.filter(d =>
            d.family === state.family &&
            d.region === state.region);
        populateDOM('sel_id_stn', getUnique(v, 'id_stn'), state.id_stn);
    }
    state.id_stn = document.getElementById('sel_id_stn').value;

    if (level <= 2) {
        const v = dbData.filter(d =>
            d.family === state.family &&
            d.region === state.region &&
            d.id_stn === state.id_stn);
        populateDOM('sel_varno', getUnique(v, 'varno'), state.varno);
    }
    state.varno = document.getElementById('sel_varno').value;

    if (level <= 3) {
        const v = dbData.filter(d =>
            d.family === state.family &&
            d.region === state.region &&
            d.id_stn === state.id_stn &&
            d.varno  === state.varno);
        populateDOM('sel_vcoord', getUnique(v, 'vcoord'), state.vcoord);
    }
    state.vcoord = document.getElementById('sel_vcoord').value;

    if (level <= 4) {
        const v = dbData.filter(d =>
            d.family === state.family &&
            d.region === state.region &&
            d.id_stn === state.id_stn &&
            d.varno  === state.varno  &&
            d.vcoord === state.vcoord);
        populateDOM('sel_function', getUnique(v, 'function'), state.function);
    }
    state.function = document.getElementById('sel_function').value;

    if (level <= 5) {
        const v = dbData.filter(d =>
            d.family   === state.family   &&
            d.region   === state.region   &&
            d.id_stn   === state.id_stn   &&
            d.varno    === state.varno    &&
            d.vcoord   === state.vcoord   &&
            d.function === state.function);
        populateDOM('sel_criteria', getUnique(v, 'criteria'), state.criteria);
    }
    state.criteria = document.getElementById('sel_criteria').value;

    updateImage();
}

// ── 5. Image update ───────────────────────────────────────────────────────────
function updateImage() {
    const match = dbData.find(d =>
        d.family   === state.family   &&
        d.region   === state.region   &&
        d.id_stn   === state.id_stn   &&
        d.varno    === state.varno    &&
        d.vcoord   === state.vcoord   &&
        d.function === state.function &&
        d.criteria === state.criteria
    );
    if (!match) return;

    const relPath = match.family + '/' + match.filename;

    if (currentSrc !== relPath) {
        if (currentSrc !== '') {
            previousSrc = currentSrc;
            document.getElementById('btn-flip').disabled = false;
        }
        currentSrc  = relPath;
        showingPrev = false;
        document.getElementById('btn-flip').classList.remove('active-flip');
    }

    applyImageSource(currentSrc, false);
    updateInfoTags(match);
}

// ── 6. Apply image ────────────────────────────────────────────────────────────
function applyImageSource(src, isPrev) {
    document.getElementById('error-msg').style.display  = 'none';
    document.getElementById('path-display').textContent = src;

    const img = document.getElementById('plot-image');
    img.src   = src + '?t=' + Date.now();

    const badge = document.getElementById('status-badge');
    badge.style.display = 'block';
    if (isPrev) {
        badge.textContent = 'Previous Image';
        badge.className   = 'badge previous';
    } else {
        badge.textContent = 'Current Image';
        badge.className   = 'badge';
    }
}

// ── 7. Info tags ──────────────────────────────────────────────────────────────
function updateInfoTags(entry) {
    document.getElementById('info-tags').innerHTML = `
        <span class="tag tag-family">family: ${entry.family}</span>
        <span class="tag tag-station">station: ${entry.id_stn}</span>
        <span class="tag tag-varno">varno: ${entry.varno}</span>
        <span class="tag tag-vcoord">vcoord: ${entry.vcoord}</span>
        <span class="tag tag-function">fn: ${entry.function}</span>
        <span class="tag tag-region">region: ${entry.region}</span>
    `;
}

// ── 8. Flip-Flop ──────────────────────────────────────────────────────────────
function toggleFlipFlop() {
    if (!previousSrc) return;
    showingPrev = !showingPrev;
    const btn   = document.getElementById('btn-flip');
    if (showingPrev) {
        applyImageSource(previousSrc, true);
        btn.classList.add('active-flip');
    } else {
        applyImageSource(currentSrc, false);
        btn.classList.remove('active-flip');
    }
}

// ── 9. Image handlers ─────────────────────────────────────────────────────────
function handleImageError() {
    document.getElementById('plot-image').style.display   = 'none';
    document.getElementById('error-msg').style.display    = 'flex';
    document.getElementById('status-badge').style.display = 'none';
}
function handleImageLoad() {
    document.getElementById('plot-image').style.display = 'block';
    document.getElementById('error-msg').style.display  = 'none';
}

// ── 10. Keyboard shortcut: F = flip-flop ──────────────────────────────────────
document.addEventListener('keydown', e => {
    if (e.key === 'f' || e.key === 'F') toggleFlipFlop();
});

// ── Init ──────────────────────────────────────────────────────────────────────
if (dbData.length > 0) {
    renderSelects(-1);
} else {
    document.getElementById('path-display').textContent =
        'ERROR: data_list_plot is empty.';
}
</script>
</body>
</html>
"""

    # ── Inject Python values ──────────────────────────────────────────────────
    html_content = html_content.replace('JSON_DATA_PLACEHOLDER', json_data)
    html_content = html_content.replace('RUN_LABEL_PLACEHOLDER', run_label)
    html_content = html_content.replace('DATESTART_PLACEHOLDER', datestart)
    html_content = html_content.replace('DATEEND_PLACEHOLDER',   dateend)

    # ── Save ──────────────────────────────────────────────────────────────────
    os.makedirs(pathwork, exist_ok=True)
    html_path = os.path.join(pathwork, output_filename)
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print(f"Profile viewer saved: {html_path}  ({len(js_data)} entries)")
    return html_path


def make_scatter(files_in,
                 names_in,  
                 pathwork, 
                 datestart,
                 dateend,
                 regions, 
                 families, 
                 flag_criteria, 
                 fonctions, 
                 varnos,
                 id_stn,
                 channel,
                 n_cpu):
   
        """
       Perform scatter plot generation based on input parameters.
   
       Args:

        files_in (list): List of input file paths.

        names_in (list): List of input file names.

        pathwork (str): Working directory.

        datestart (str): Start date in YYYYMMDDHH format.

        dateend (str): End date in YYYYMMDDHH format.

        region (str): Region parameter description.

        family (str): Family parameter description.

        flag_criteria (str): Flags criteria.

        fonction (str): Function parameter description.

        boxsizex (int): Box size in X direction.

        boxsizey (int): Box size in Y direction.

        Proj (str or list): Projection type ('cyl', 'OrthoN', 'OrthoS', etc.).

        mode (str): Mode parameter description.

        Points (str): Points parameter description.

        id_stn (str): id_stn parameter description.

        channel (str): Channel parameter description.

        n_cpu (int): Number of CPUs to use.
   
       Returns:
       
         None
        """
        for family in families:
              pikobs.delete_create_folder(pathwork, family)
          
        data_list = create_data_list(datestart,
                                       dateend, 
                                       families, 
                                       files_in,
                                       names_in,
                                       pathwork,
                                       fonctions, 
                                       flag_criteria, 
                                       regions,
                                       varnos)
                                       
       # exit()                             
        import time
        import dask
        t0 = time.time()
        n_cpu=1
        if n_cpu==1:
          print (f'in Serie files: {len(data_list)} used in calculating statistics for {names_in}')
          for  data_ in data_list:  
               create_and_populate_moyenne_table(data_['family'], 
                                                 data_['db_new'], 
                                                 data_['filein'],
                                                 data_['region'],
                                                 data_['flag_criteria'],
                                                 data_['function'],
                                                 data_['varnos'],
                                                 channel,
                                                 id_stn)
               
       
       
       
       
        else:
           print (f'in Paralle number of files: {len(data_list)} used in calculating statistics for {len(data_list)}  {names_in} ')
           with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                              n_workers=n_cpu, 
                                              silence_logs=40) as client:
               delayed_funcs = [dask.delayed(create_and_populate_moyenne_table)(data_['family'], 
                                                 data_['db_new'], 
                                                 data_['filein'],
                                                 data_['region'],
                                                 data_['flag_criteria'],
                                                 data_['function'],
                                                 data_['varnos'],
                                                 channel,
                                                 id_stn,
                                                 )for data_ in data_list]
              # print ('close0')
               results = dask.compute(*delayed_funcs)
               client.close()

        tn= time.time()
        print ('Total time for statistics:',tn-t0 )  
        data_list_plot = create_data_list_plot(datestart,
                                             dateend, 
                                             families, 
                                             names_in,
                                             pathwork,
                                             fonctions, 
                                             flag_criteria, 
                                             regions,
                                             id_stn,
                                             channel
                                            )
         
        t0 = time.time()
        if n_cpu==1:  
         print (f'in Serie plots = {len(data_list_plot)}')
         for  data_ in data_list_plot:  
           pikobs.profile_plot( 
                               data_['region'],
                               data_['family'], 
                               data_['id_stn'], 
                               datestart,
                               dateend, 
                               pathwork,
                               flag_criteria, 
                               data_['function'],
                               data_['vcoord'],
                               data_['files_in'],
                               names_in, 
                               data_['varno'],
                               data_['criteria'])
        else:
         print (f"in Paralle plotsss = {len(data_list_plot)}")
         time.sleep(4)
         with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                          n_workers=n_cpu, 
                                          silence_logs=40) as client:
           delayed_funcs = [dask.delayed(pikobs.profile_plot)( 
                                                              data_['region'],
                                                              data_['family'], 
                                                              data_['id_stn'],
                                                              datestart,
                                                              dateend, 
                                                              pathwork,
                                                              flag_criteria, 
                                                              data_['function'],
                                                              data_['vcoord'],
                                                              data_['files_in'],
                                                              names_in, 
                                                              data_['varno'],
                                                              data_['criteria']
                                                              )for data_ in data_list_plot]
   
           results = dask.compute(*delayed_funcs)
           client.close()
        print ('Total time:',time.time() - t0 )  
        print (f'check: {pathwork}')
        generate_web(data_list_plot ,pathwork,names_in,datestart,dateend)
    
import argparse
import re
import argparse
import re

def parse_intervals(text):
    """Parses a string of intervals formatted as '[(,),(a,b)]' into a list of tuples."""

    # Expresión regular corregida para aceptar paréntesis vacíos y números
    pattern = r'\(\s*(\d*)\s*,\s*(\d*)\s*\)'  
    matches = re.findall(pattern, text)


    result = []
    for a, b in matches:
        val_a = int(a) if a.isdigit() else None
        val_b = int(b) if b.isdigit() else None
        result.append((val_a, val_b))

    return result

def arg_call():

    import argparse
    import sys
    parser = argparse.ArgumentParser()
    parser.add_argument('--path_control_files', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--control_name', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--path_experience_files', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--experience_name', default='undefined', type=str, help="Directory where input sqlite files are located")
  

    
    parser.add_argument('--pathwork', default='undefined', type=str, help="Working directory")
    parser.add_argument('--datestart', default='undefined', type=str, help="Start date")
    parser.add_argument('--dateend', default='undefined', type=str, help="End date")
    parser.add_argument('--region', nargs="+", default='undefined', type=str, help="Region")
    parser.add_argument('--family', nargs="+", default='undefined', type=str, help="Family")
    parser.add_argument('--flags_criteria',nargs="+", default='undefined', type=str, help="Flags criteria")
    parser.add_argument('--fonction', nargs="+", default='undefined', type=str, help="Function") 
    parser.add_argument('--varnos', nargs="+", default='undefined', type=str, help="Function")
    parser.add_argument('--id_stn', default='one_per_plot', type=str, help="id_stn") 
    parser.add_argument('--channel', default='one_per_plot', type=str, help="channel")
    parser.add_argument('--n_cpus', default=1, type=int, help="Number of CPUs")
    
    args = parser.parse_args()
    for arg in vars(args):
       print (f'--{arg} {getattr(args, arg)}')
    # Check if each argument is 'undefined'
    if args.path_control_files == 'undefined':
        files_in = [args.path_experience_files]
        names_in = [args.experience_name]
    else:    
        if args.path_experience_files == 'undefined':
            raise ValueError('You must specify --path_experience_files')
        if args.experience_name == 'undefined':
            raise ValueError('You must specify --experience_name')
        else:

            files_in = [args.path_control_files, args.path_experience_files]
            names_in = [args.control_name, args.experience_name] 
    args = parser.parse_args()


    if args.varnos == 'undefined':
        args.varnos = []
    if args.pathwork == 'undefined':
        raise ValueError('You must specify --pathwork')
    if args.datestart == 'undefined':
        raise ValueError('You must specify --datestart')
    if args.dateend == 'undefined':
        raise ValueError('You must specify --dateend')
    if args.region == 'undefined':
        raise ValueError('You must specify --region')
    if args.family == 'undefined':
        raise ValueError('You must specify --family')
    if args.flags_criteria == 'undefined':
        raise ValueError('You must specify --flags_criteria')
    if args.fonction == 'undefined':
        raise ValueError('You must specify --fonction')


    # Call your function with the arguments
    sys.exit(make_scatter(files_in,
                          names_in,    
                          args.pathwork,
                          args.datestart,
                          args.dateend,
                          args.region,
                          args.family,
                          args.flags_criteria,
                          args.fonction,
                          args.varnos,
                          args.id_stn,
                          args.channel,
                          args.n_cpus))
