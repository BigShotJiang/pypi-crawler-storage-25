#!/usr/bin/env python3
"""
profile_plot.py
Vertical profile plot comparing Control and Experiment model runs.
"""

# ─────────────────────────────────────────────────────────────────────────────
# IMPORTS  (single clean block)
# ─────────────────────────────────────────────────────────────────────────────
import os
import warnings
import datetime

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import sqlalchemy
import scipy.stats as stats

import pikobs

# ─────────────────────────────────────────────────────────────────────────────
# GLOBAL MATPLOTLIB SETTINGS
# ─────────────────────────────────────────────────────────────────────────────
mpl.use('Agg')
plt.rcParams['font.family'] = 'DejaVu Sans'   # broad unicode support

# Suppress missing-glyph warnings (e.g. Greek letters on some systems)
warnings.filterwarnings(
    "ignore",
    message="Glyph.*missing from current font",
    category=UserWarning
)


# ─────────────────────────────────────────────────────────────────────────────
# UTILITY
# ─────────────────────────────────────────────────────────────────────────────
def days_between(d1: str, d2: str) -> int:
    """Return the absolute number of days between two '%Y%m%d%H' strings."""
    fmt = "%Y%m%d%H"
    return abs((datetime.datetime.strptime(d2, fmt)
                - datetime.datetime.strptime(d1, fmt)).days)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN FUNCTION
# ─────────────────────────────────────────────────────────────────────────────
def profile_plot(region, family, id_stn, datestart, dateend,
                 work_path, flag_criteria, function_name,
                vcoord, filesin, namesin, varno, criteria):
    """
    Generates a vertical profile plot comparing Control and Experiment runs.

    Behaviour
    ─────────
    * ONE name  in namesin → control profile only, no statistical tests.
    * TWO names in namesin → full comparison with confidence levels per level.

    Statistical tests
    ══════════════════════════════════════════════════════════════════════════
    1. RMSE   : sqrt(Bias² + StdDev²)  — descriptive, no p-value.
    2. F-test : equality of variances.   H₀: σ²_ctrl = σ²_exp
    3. Welch  : equality of means/bias.  H₀: μ_ctrl  = μ_exp
    4. Chi²   : distribution shape.      H₀: same shape as control

    Confidence = (1 − p) × 100 %.   Significant when confidence ≥ 95 %.
    ══════════════════════════════════════════════════════════════════════════

    Parameters
    ──────────
    mode          : Execution mode.
    region        : Geographic region.
    family        : Observation family ('sw', 'ua', 'ai', …).
    id_stn        : Station / satellite identifier.
    datestart     : Start date string ('%Y%m%d%H').
    dateend       : End   date string ('%Y%m%d%H').
    work_path     : Root directory for output images.
    flag_criteria : Quality-flag filter criterion.
    function_name : Variable label used on the X axis.
    vcoord        : Vertical coordinate type.
    filesin       : [ctrl_sqlite, exp_sqlite]
    namesin       : [ctrl_label,  exp_label]
    varno         : Variable number to query.
    criteria      : Extra tag appended to the output filename.
    """

    # =========================================================================
    # SECTION 1 — LAYOUT CONSTANTS  (edit here to adjust the figure)
    # =========================================================================
    FIG_WIDTH    = 79      # figure width  (inches)
    FIG_HEIGHT   = 45      # figure height (inches)

    PLOT_LEFT    = 0.04    # profile-plot left   edge (figure fraction)
    PLOT_RIGHT   = 0.28    # profile-plot right  edge
    PLOT_TOP     = 0.75    # profile-plot top    edge
    PLOT_BOTTOM  = 0.28    # profile-plot bottom edge

    GUIDE_LEFT   = 0.68    # guide-box left   edge
    GUIDE_BOTTOM = 0.30    # guide-box bottom edge
    GUIDE_WIDTH  = 0.19    # guide-box width
    GUIDE_HEIGHT = 0.52    # guide-box height

    GROUP_GAP    = 0.22    # axes-coord gap between test-group columns
    INNER_GAP    = 0.15    # axes-coord gap between conf% and result columns

    # =========================================================================
    # SECTION 2 — FONT SIZES
    # =========================================================================
    FS_TITLE     = 36
    FS_LABELS    = 28
    FS_LEGEND    = 28
    FS_TABLE_HDR = 28
    FS_TABLE_TXT = 28
    FS_TICKS     = 28
    FS_FORMULA   = 21

    # =========================================================================
    # SECTION 3 — INPUT NORMALISATION
    # Single-element lists are unwrapped to scalars.
    # =========================================================================
    if isinstance(flag_criteria, list) and flag_criteria:
        flag_criteria = flag_criteria[0]
    if isinstance(criteria, list) and criteria:
        criteria = criteria[0]

    selected_flags = pikobs.flag_criteria(flag_criteria)   # noqa: F841
    element = varno
    sat     = id_stn

    # =========================================================================
    # SECTION 4 — DATA LOADING
    # =========================================================================
    FNAM, FBAMP, SUM, SUM2 = pikobs.type_boxes(function_name)   # noqa: F841
    from sqlalchemy import text
    def load_data(dbfile: str) -> pd.DataFrame:
        """
        Query the SQLite database and return per-level statistics.

        SQL fields
        ──────────
        bias    = SUM(SUM)  / N
        std_dev = sqrt( SUM(SUM2)/N − (SUM(SUM)/N)² )
        total_n = SUM(N)
        """
        engine = sqlalchemy.create_engine(f"sqlite:///{dbfile}")
        query = f"""
        SELECT
            varno,
            round(vcoord)                                             AS vcoord,
            SUM({SUM})  * 1.0 / SUM(N)                               AS bias,
            SQRT(
                SUM({SUM2}) * 1.0 / SUM(N)
                - POWER(SUM({SUM}), 2) * 1.0 / (SUM(N) * SUM(N))
            )                                                         AS std_dev,
            MIN({SUM})                                                AS min_sumy,
            MAX({SUM})                                                AS max_sumy,
            SUM(N)                                                    AS total_n
        FROM moyenne
        WHERE
            varno      = {element}
            AND id_stn IN ('{sat}')
            AND {SUM}  IS NOT NULL
        GROUP BY varno, round(vcoord)
        HAVING COUNT(*) > 1
        ORDER BY round(vcoord)
        """
        with engine.connect() as conn:
           return pd.read_sql_query(text(query), conn)
    df0     = load_data(filesin[0])
    has_exp = (
        len(filesin)  > 1
        and len(namesin) > 1
        and os.path.exists(filesin[1])
    )
    df1 = load_data(filesin[1]) if has_exp else pd.DataFrame()

    if df0.empty and df1.empty:
        print(f"No data found for station '{sat}' | varno {element}.")
        return

    # =========================================================================
    # SECTION 5 — FIGURE AND AXES
    # =========================================================================
    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_HEIGHT))
    fig.subplots_adjust(
        left   = PLOT_LEFT,
        right  = PLOT_RIGHT,
        top    = PLOT_TOP,
        bottom = PLOT_BOTTOM,
    )

    # =========================================================================
    # SECTION 6 — CURVE HELPER
    # =========================================================================
    def plot_curve(df, label, color, alpha_fill, marker_bias, marker_std):
        """Draw Bias + StdDev curves and min-max shading."""
        if df.empty:
            return
        if len(df) > 1:
            ax.fill_betweenx(
                df['vcoord'], df['min_sumy'], df['max_sumy'],
                color=color, alpha=alpha_fill,
                label=f'{label} (min-max range)',
            )
        ax.plot(df['bias'],    df['vcoord'],
                label=f'{label} (Bias)',
                color=color, linewidth=2,
                marker=marker_bias, markersize=5)
        ax.plot(df['std_dev'], df['vcoord'],
                label=f'{label} (Std Dev)',
                color=color, linestyle='--',
                marker=marker_std, markersize=5)

    plot_curve(df0, namesin[0], color='blue', alpha_fill=0.07,
               marker_bias='o', marker_std='s')
    if has_exp:
        plot_curve(df1, namesin[1], color='red', alpha_fill=0.07,
                   marker_bias='o', marker_std='s')

    # =========================================================================
    # SECTION 7 — AXES FORMATTING
    # =========================================================================
    variable_name, units, vcoord_type = pikobs.type_varno(element)
    ylabel = vcoord_type
    subtitle = (
        f'Statistical Analysis {family}:  {namesin[0]}  vs  {namesin[1]}'
        if has_exp else
        f'Control run only:  {namesin[0]}'
    )

    ax.set_xlabel(f'{function_name} {units}', fontsize=FS_LABELS)
    ax.set_ylabel(ylabel, fontsize=FS_LABELS)
    ax.axvline(x=0, color='black', linewidth=1.5)
    ax.invert_yaxis()
    ax.grid(True, linestyle=':', alpha=0.7)

    ax.set_title(
        f'Profile  {sat}  -   {variable_name} \n ({datestart} / {dateend})\n'
        f'{subtitle}',
        fontsize=FS_TITLE,
        pad=40,
    )
    plt.setp(ax.get_xticklabels(), fontsize=FS_TICKS)
    plt.setp(ax.get_yticklabels(), fontsize=FS_TICKS)

    # =========================================================================
    # SECTION 8 — SINGLE-RUN MODE  (no tests — exit early)
    # =========================================================================
    if not has_exp:
        COL_N1    = 1.08
        HEADER_Y  = 1.025
        tr        = ax.get_yaxis_transform()

        ax.text(COL_N1, HEADER_Y, f'{namesin[0]}\n(N)',
                transform=ax.transAxes, color='blue',
                fontweight='bold', fontsize=FS_TABLE_HDR,
                ha='center', va='bottom')

        for _, row in df0.iterrows():
            ax.text(COL_N1, row['vcoord'], f"{int(row['total_n'])}",
                    transform=tr, color='blue',
                    fontsize=FS_TABLE_TXT, ha='center', va='center')

        ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.06),
                  ncol=2, fontsize=FS_LEGEND, framealpha=0.9)

        _save_and_close(fig, work_path, family, function_name, region,
                        id_stn, varno, vcoord, datestart, dateend, criteria, namesin,
                        label='control only')
        return

    # =========================================================================
    # SECTION 9 — TABLE COLUMN POSITIONS  (axes coordinates)
    # =========================================================================
    COL_N1    = 1.20
    COL_N2    = COL_N1    + 0.20

    COL_RMSE  = COL_N2    + 0.28

    COL_F_C   = COL_RMSE  + GROUP_GAP
    COL_F_SIG = COL_F_C   + INNER_GAP

    COL_T_C   = COL_F_SIG + GROUP_GAP
    COL_T_SIG = COL_T_C   + INNER_GAP

    COL_X_C   = COL_T_SIG + GROUP_GAP
    COL_X_SIG = COL_X_C   + INNER_GAP

    tr       = ax.get_yaxis_transform()
    HEADER_Y = 1.025
    SUBHDR_Y = 0.990

    # ── Main headers ─────────────────────────────────────────────────────────
    for xp, txt, col in [
        (COL_N1,                    f'{namesin[0]}\n(N)',    'blue'),
        (COL_N2,                    f'{namesin[1]}\n(N)',    'red'),
        (COL_RMSE,                  'RMSE\nDiff (%)',        'black'),
        ((COL_F_C + COL_F_SIG) / 2, 'Var Sig.\n(F-test)',   'black'),
        ((COL_T_C + COL_T_SIG) / 2, 'Bias Sig.\n(T-Welch)', 'black'),
        ((COL_X_C + COL_X_SIG) / 2, 'Dist. Sig.\n(Chi2)',   'black'),
    ]:
        ax.text(xp, HEADER_Y, txt,
                transform=ax.transAxes, color=col,
                fontweight='bold', fontsize=FS_TABLE_HDR,
                ha='center', va='bottom', linespacing=1.4)

    # ── Sub-headers ───────────────────────────────────────────────────────────
    for xp, txt in [
        (COL_F_C,  'conf%'), (COL_F_SIG, 'result'),
        (COL_T_C,  'conf%'), (COL_T_SIG, 'result'),
        (COL_X_C,  'conf%'), (COL_X_SIG, 'result'),
    ]:
        ax.text(xp, SUBHDR_Y, txt,
                transform=ax.transAxes, color='dimgray',
                fontsize=FS_TABLE_HDR - 5,
                ha='center', va='top', style='italic')

    # ── Separator line ────────────────────────────────────────────────────────
    fig.add_artist(plt.Line2D(
        [PLOT_RIGHT + 0.005, GUIDE_LEFT - 0.01],
        [PLOT_TOP - 0.005,   PLOT_TOP - 0.005],
        transform=fig.transFigure,
        color='#adb5bd', linewidth=1.0, linestyle='--',
    ))

    # ── Control N counts ─────────────────────────────────────────────────────
    for _, row in df0.iterrows():
        ax.text(COL_N1, row['vcoord'], f"{int(row['total_n'])}",
                transform=tr, color='blue',
                fontsize=FS_TABLE_TXT, ha='center', va='center')

    # =========================================================================
    # SECTION 10 — STATISTICAL HELPERS
    # =========================================================================
    def _rmse(bias: float, std_dev: float) -> float:
        """Global RMSE = sqrt(Bias² + StdDev²)."""
        return np.sqrt(bias**2 + std_dev**2)

    def _ftest(s1: float, n1: int, s2: float, n2: int) -> tuple:
        """
        Two-sided F-test for equality of variances.
        F = s1²/s2²  ~  F(n1-1, n2-1)
        p = 2 * min(CDF(F), 1-CDF(F))
        Returns (p, confidence_pct).
        """
        F     = (s1**2) / (s2**2)
        p_low = stats.f.cdf(F, n1 - 1, n2 - 1)
        p     = 2.0 * min(p_low, 1.0 - p_low)
        return p, (1.0 - p) * 100.0

    def _welch(m1: float, s1: float, n1: int,
               m2: float, s2: float, n2: int) -> tuple:
        """
        Welch t-test (unequal variances).
        DOF via Welch-Satterthwaite.
        Returns (p, confidence_pct).
        """
        _, p = stats.ttest_ind_from_stats(
            mean1=m1, std1=s1, nobs1=n1,
            mean2=m2, std2=s2, nobs2=n2,
            equal_var=False,
        )
        return p, (1.0 - p) * 100.0

    def _chi2(nc: int, ne: int,
              bc: float, sc: float,
              be: float, se: float) -> tuple:
        """
        Chi-squared goodness-of-fit (distribution shape).
        Bins: 24 over +-4*sigma.
        f_exp rescaled to avoid sum-mismatch ValueError.
        Returns (p, confidence_pct).
        """
        sigma = max(sc, se)
        if sigma <= 0:
            return np.nan, np.nan

        mu   = (bc + be) / 2.0
        bins = np.linspace(mu - 4.0 * sigma, mu + 4.0 * sigma, 25)

        f_exp = np.diff(stats.norm.cdf(bins, bc, sc)) * ne
        f_obs = np.diff(stats.norm.cdf(bins, be, se)) * ne

        s_o, s_e = f_obs.sum(), f_exp.sum()
        if s_e <= 0 or s_o <= 0:
            return np.nan, np.nan

        f_exp *= (s_o / s_e)          # equalise sums → prevents ValueError

        obs_m, exp_m = [], []
        oa, ea = 0.0, 0.0
        for o, e in zip(f_obs, f_exp):
            oa += o
            ea += e
            if ea >= 5.0:
                obs_m.append(oa)
                exp_m.append(ea)
                oa, ea = 0.0, 0.0
        if obs_m and (oa > 0 or ea > 0):
            obs_m[-1] += oa
            exp_m[-1] += ea
        if len(obs_m) < 2:
            return np.nan, np.nan

        f_o = np.array(obs_m)
        f_e = np.array(exp_m)
        f_e *= f_o.sum() / f_e.sum()  # safety rescale after merging

        try:
            _, p = stats.chisquare(f_obs=f_o, f_exp=f_e)
            return p, (1.0 - p) * 100.0
        except ValueError as exc:
            print(f"Chi2 skipped: {exc}")
            return np.nan, np.nan

    def _fmt(conf: float) -> str:
        """Format confidence % for the table."""
        if np.isnan(conf):
            return 'N/A'
        return '>99.9%' if conf > 99.9 else f'{conf:.1f}%'

    def _result(val_exp: float, val_ctrl: float) -> tuple:
        """Return (label, colour): Better/red if improved, Worse/blue if not."""
        return (('Better v', 'red') if val_exp < val_ctrl
                else ('Worse  ^', 'blue'))

    CONF_THR = 95.0   # significance threshold

    # =========================================================================
    # SECTION 11 — ROW-BY-ROW EVALUATION
    # =========================================================================
    df_comp = pd.merge(df0, df1, on='vcoord', suffixes=('_c', '_e'))

    for _, row in df_comp.iterrows():
        vc        = row['vcoord']
        sc, se    = row['std_dev_c'],      row['std_dev_e']
        bc, be    = row['bias_c'],         row['bias_e']
        nc, ne    = int(row['total_n_c']), int(row['total_n_e'])

        ax.text(COL_N2, vc, str(ne), transform=tr,
                color='red', fontsize=FS_TABLE_TXT,
                ha='center', va='center')

        if nc > 1 and ne > 1 and sc > 0 and se > 0:
            rmse_c = _rmse(bc, sc)
            rmse_e = _rmse(be, se)

            # RMSE
            diff = (rmse_c - rmse_e) / rmse_c * 100.0
            ax.text(COL_RMSE, vc, f'{diff:+.1f}%', transform=tr,
                    color='red' if rmse_e < rmse_c else 'blue',
                    fontsize=FS_TABLE_TXT, ha='center', va='center')

            # F-test
            _, conf_f = _ftest(sc, nc, se, ne)
            sig_f     = conf_f >= CONF_THR
            ax.text(COL_F_C, vc, _fmt(conf_f), transform=tr,
                    color=('red' if se < sc else 'blue') if sig_f else 'black',
                    fontsize=FS_TABLE_TXT - 1, ha='center', va='center')
            if sig_f:
                lbl, c = _result(se, sc)
                ax.text(COL_F_SIG, vc, lbl, transform=tr,
                        color=c, fontsize=FS_TABLE_TXT,
                        ha='center', va='center', fontweight='bold')
            else:
                ax.text(COL_F_SIG, vc, '-', transform=tr,
                        color='gray', fontsize=FS_TABLE_TXT,
                        ha='center', va='center')

            # Welch t-test
            _, conf_t = _welch(bc, sc, nc, be, se, ne)
            sig_t     = conf_t >= CONF_THR
            ax.text(COL_T_C, vc, _fmt(conf_t), transform=tr,
                    color=('red' if abs(be) < abs(bc) else 'blue') if sig_t
                          else 'black',
                    fontsize=FS_TABLE_TXT - 1, ha='center', va='center')
            if sig_t:
                lbl, c = _result(abs(be), abs(bc))
                ax.text(COL_T_SIG, vc, lbl, transform=tr,
                        color=c, fontsize=FS_TABLE_TXT,
                        ha='center', va='center', fontweight='bold')
            else:
                ax.text(COL_T_SIG, vc, '-', transform=tr,
                        color='gray', fontsize=FS_TABLE_TXT,
                        ha='center', va='center')

            # Chi-squared
            _, conf_x = _chi2(nc, ne, bc, sc, be, se)
            if np.isnan(conf_x):
                for cx in (COL_X_C, COL_X_SIG):
                    ax.text(cx, vc, 'N/A', transform=tr,
                            color='gray', fontsize=FS_TABLE_TXT,
                            ha='center', va='center')
            else:
                sig_x = conf_x >= CONF_THR
                ax.text(COL_X_C, vc, _fmt(conf_x), transform=tr,
                        color=('red' if rmse_e < rmse_c else 'blue') if sig_x
                              else 'black',
                        fontsize=FS_TABLE_TXT - 1, ha='center', va='center')
                if sig_x:
                    lbl, c = _result(rmse_e, rmse_c)
                    ax.text(COL_X_SIG, vc, lbl, transform=tr,
                            color=c, fontsize=FS_TABLE_TXT,
                            ha='center', va='center', fontweight='bold')
                else:
                    ax.text(COL_X_SIG, vc, '-', transform=tr,
                            color='gray', fontsize=FS_TABLE_TXT,
                            ha='center', va='center')
        else:
            for cx in (COL_RMSE,
                       COL_F_C, COL_F_SIG,
                       COL_T_C, COL_T_SIG,
                       COL_X_C, COL_X_SIG):
                ax.text(cx, vc, 'N/A', transform=tr,
                        color='gray', fontsize=FS_TABLE_TXT,
                        ha='center', va='center')

    # =========================================================================
    # SECTION 12 — STATISTICAL GUIDE BOX
    # =========================================================================
    ax_guide = fig.add_axes(
        [GUIDE_LEFT, GUIDE_BOTTOM, GUIDE_WIDTH, GUIDE_HEIGHT]
    )
    ax_guide.axis('off')

    guide_text = (
        "  Statistical Significance Guide\n"
        "   (threshold: confidence >= 95%)\n"
        "================================================\n"
        "\n"
        "KEY CONCEPT -- Confidence % and p-value\n"
        "  Confidence (%) = (1 - p-value) x 100\n"
        "  How certain are we the change is REAL\n"
        "  and not just random noise?\n"
        "\n"
        "  >= 95% -> significant  (< 5% chance random)\n"
        "  <  95% -> NOT significant\n"
        "\n"
        "  99.9% (p~0.001) -> extremely strong evidence\n"
        "  98.0% (p=0.020) -> strong evidence\n"
        "  95.2% (p=0.048) -> just above threshold [OK]\n"
        "  94.0% (p=0.060) -> just below threshold [NO]\n"
        "  50.0% (p=0.500) -> no evidence at all\n"
        "\n"
        "================================================\n"
        "RMSE -- Root Mean Square Error\n"
        "  (descriptive -- no significance test)\n"
        "  RMSE = sqrt(Bias^2 + StdDev^2)\n"
        "  Diff(%) = (RMSE_ctrl-RMSE_exp)/RMSE_ctrl x100\n"
        "  Positive (+) -> experiment LOWER error  [+]\n"
        "  Negative (-) -> experiment HIGHER error [-]\n"
        "\n"
        "================================================\n"
        "F-test -- Did the SPREAD (variance) change?\n"
        "  H0 : sigma2_ctrl = sigma2_exp  (no change)\n"
        "  H1 : sigma2_ctrl != sigma2_exp (changed)\n"
        "  F  = s2_ctrl / s2_exp ~ F(n_c-1, n_e-1)\n"
        "  p  = 2 x min(CDF(F), 1-CDF(F))  [two-sided]\n"
        "  Better v : sigma_exp < sigma_ctrl [+]\n"
        "  Worse  ^ : sigma_exp > sigma_ctrl [-]\n"
        "\n"
        "================================================\n"
        "T-test Welch -- Did the BIAS (mean) change?\n"
        "  H0 : mu_ctrl = mu_exp   (no change)\n"
        "  H1 : mu_ctrl != mu_exp  (changed)\n"
        "  t  = (b_c-b_e) / sqrt(s2_c/n_c + s2_e/n_e)\n"
        "  DOF: Welch-Satterthwaite\n"
        "  |t|>1.96 -> conf>95%  |t|>2.58 -> conf>99%\n"
        "  Better v : |b_exp|<|b_ctrl| -> nearer 0  [+]\n"
        "  Worse  ^ : |b_exp|>|b_ctrl| -> away from 0 [-]\n"
        "\n"
        "================================================\n"
        "Chi2-test -- Did the DISTRIBUTION SHAPE change?\n"
        "  H0 : same shape as control\n"
        "  H1 : shape changed\n"
        "  X2 = SUM (O_i - E_i)^2 / E_i\n"
        "       O_i = experiment counts\n"
        "       E_i = control counts (scaled to n_exp)\n"
        "  24 bins over +/-4*sigma (99.994% captured)\n"
        "  Direction set by RMSE (X2 has no sign)\n"
        "  Better v : RMSE_exp < RMSE_ctrl  [+]\n"
        "  Worse  ^ : RMSE_exp >= RMSE_ctrl [-]\n"
        "\n"
        "================================================\n"
        "Table columns\n"
        "  conf% : confidence the change is real.\n"
        "          Red/blue >= 95%, black otherwise.\n"
        "  result: Better v  conf>=95% and improved.\n"
        "          Worse  ^  conf>=95% and degraded.\n"
        "          -         conf< 95% (not significant).\n"
        "          N/A       insufficient data."
    )

    ax_guide.text(
        0.3, 0.97, guide_text,
        transform=ax_guide.transAxes,
        fontsize=FS_FORMULA,
        verticalalignment='top',
        horizontalalignment='left',
        fontfamily='monospace',
        linespacing=1.5,
        bbox=dict(
            boxstyle='round,pad=1.0',
            facecolor='#f0f4f8',
            alpha=0.97,
            edgecolor='#4a6fa5',
            linewidth=2.5,
        ),
    )

    # =========================================================================
    # SECTION 13 — LEGEND
    # =========================================================================
    ax.legend(
        loc='upper center',
        bbox_to_anchor=(0.5, -0.06),
        ncol=2,
        fontsize=FS_LEGEND,
        framealpha=0.9,
        markerscale=1.5,
        handlelength=3.0,
    )

    # =========================================================================
    # SECTION 14 — SAVE
    # =========================================================================
    _save_and_close(fig, work_path, family, function_name, region,
                    id_stn, varno, vcoord, datestart, dateend, criteria, namesin)


# ─────────────────────────────────────────────────────────────────────────────
# PRIVATE HELPER — reused by single-run and two-run paths
# ─────────────────────────────────────────────────────────────────────────────
def _build_filename(function_name, family, region, id_stn, varno,
                    vcoord, datestart, dateend, criteria, namesin):
    """
    Build the output filename including experiment names.

    Examples
    ────────
    One run:
      sw_oma_CTRL_Monde_GOES19_11003_all_2026031000_2026031500_assimilee.png

    Two runs:
      sw_oma_CTRL_vs_EXP_Monde_GOES19_11003_all_2026031000_2026031500_assimilee.png
    """
    safe_start    = str(datestart).replace('-', '')
    safe_end      = str(dateend).replace('-', '')
    safe_criteria = str(criteria).replace(' ', '_')

    # Clean each name: remove spaces and special chars
    def _clean(name):
        return str(name).replace(' ', '').replace('/', '').replace('\\', '')

    if len(namesin) == 1:
        exp_part = _clean(namesin[0])
    else:
        exp_part = f"{_clean(namesin[0])}_vs_{_clean(namesin[1])}"

    filename = (
        f"{function_name}_"          # oma / omf / etc.
        f"{family}_"                 # sw / ua / ai
        f"{exp_part}_"               # CTRL  or  CTRL_vs_EXP
        f"{region}_"                 # Monde / NH / SH
        f"{id_stn}_"                 # GOES19
        f"{varno}_"                  # 11003
        f"{vcoord}_"                 # all / pression
        f"{safe_start}_"             # 2026031000
        f"{safe_end}_"               # 2026031500
        f"{safe_criteria}.png"       # assimilee.png
    )
    return filename


def _save_and_close(fig, work_path, family, function_name, region,
                    id_stn, varno, vcoord, datestart, dateend,
                    criteria, namesin, label: str = '') -> str:
    """Save fig to the standard output path and close it. Returns full path."""
    output_dir = os.path.join(work_path, family)
    os.makedirs(output_dir, exist_ok=True)

    filename    = _build_filename(function_name, family, region, id_stn,
                                  varno, vcoord, datestart, dateend,
                                  criteria, namesin)
    output_file = os.path.join(output_dir, filename)
    fig.savefig(output_file, dpi=150, bbox_inches='tight')
    plt.close(fig)
    tag = f' ({label})' if label else ''
    return output_file
