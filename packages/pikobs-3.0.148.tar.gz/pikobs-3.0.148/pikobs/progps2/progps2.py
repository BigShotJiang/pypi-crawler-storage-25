"""
Pikobs vertical-profile pipeline
================================

Overview
--------
``progps.py`` aggregates departure / observation statistics from one or
more SQLite observation databases (one per assimilation cycle, typically
6-hourly) and produces vertical-profile diagnostic plots that compare an
arbitrary number of experiments against a control.

The pipeline is deliberately split in two so that responsibilities stay
clean:

1. **Conversion** (NOT done here). Raw BURP files must be converted to
   SQLite *before* running this script. Use the dedicated converter:

   .. code-block:: bash

      python -c 'import pikobs; pikobs.pikobsburp2db.arg_call()' \\
          --path_experience_files /path/CTL /path/EXP1 ... \\
          --experience_name        Control  Exp1     ... \\
          --pathwork  /workdir/converted/                 \\
          --datestart 2022053100 --dateend 2022062812     \\
          --n_cpu     40

   The converter writes one SQLite file per (experiment, date, family)
   triple, named ``<DATE>_<family>``. ``progps.py`` reads those files
   directly and refuses to start if it sees anything that is not a
   valid SQLite file.

2. **Aggregation + plotting** (this script).

Pipeline phases
---------------

Phase 1 - Aggregation
^^^^^^^^^^^^^^^^^^^^^
For every (experiment, date, family, region, flag-criteria) tuple, the
script runs a single SQL ``SELECT`` against the input SQLite file that
groups observations by ``(lat, lon, varno [, vcoord] [, id_stn]
[, elevation])`` and produces, per group, the running sums needed to
reconstruct unbiased statistics later::

    n          = SUM(CASE WHEN col IS NOT NULL THEN 1 ELSE 0 END)
    sumX       = SUM(col)
    sumX2      = SUM(col*col)
    Nrej, Nacc = bitmask counts on `flag`
    Nprofile   = COUNT(DISTINCT id_obs)

``col`` is one of ``omp`` / ``oma`` / ``obsvalue``, chosen by the
``--fonction`` argument. Filter and counter are tied to the *same*
column so the resulting mean and variance are internally consistent
(this was a real bug in earlier versions where ``COUNT(*)`` over an
``obsvalue IS NOT NULL`` filter inflated ``n`` whenever ``omp`` or
``oma`` were null in some rows).

Phase 2 - Reading & statistics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
For each plot, the per-cycle aggregates are summed across dates and the
unbiased sample variance is computed in streaming form::

    mean = sumX / n
    var  = (sumX2 - n * mean^2) / (n - 1)        for n >= 2
    std  = sqrt(max(var, 0))

A negative ``var`` from numerical cancellation is clipped to zero, with
a warning when the cancellation is suspiciously large (rare for OMP/OMA
which centre around zero, possible for ``obsvalue`` of fields with a
very large mean and a tiny variance, e.g. temperature in K).

Statistical tests — F-test for variance ratio
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Hypotheses.** For every vertical level the panel compares the variance
of the experiment to that of the control:

.. math::

   H_0 : \\; \\sigma_e^2 = \\sigma_c^2
   \\qquad\\text{vs.}\\qquad
   H_1 : \\; \\sigma_e^2 \\neq \\sigma_c^2.

**Test statistic.** Under :math:`H_0`, assuming the two samples are
independent and drawn from normal populations,

.. math::

   F \\;=\\; \\frac{s_e^{\\,2}}{s_c^{\\,2}}
        \\;\\sim\\; F_{\\,n_e-1,\\, n_c-1},

where :math:`s_e^2` and :math:`s_c^2` are the unbiased sample variances
of experiment and control, and :math:`F_{\\nu_1,\\nu_2}` is the
Fisher–Snedecor distribution with :math:`(\\nu_1, \\nu_2)` degrees of
freedom. The numerator carries the **experiment** (subscript *e*), the
denominator carries the **control** (subscript *c*); this is by design,
because the panel orientation maps directly onto the physical question
"is the experiment more or less variable than the control?".

**What the panel actually plots.** Instead of a two-sided p-value the
plot shows the *cdf rank* of the observed :math:`F`,

.. math::

   q(F) \\;=\\; \\Pr\\!\\big[\\,F_{n_e-1,\\,n_c-1} \\le F\\,\\big]
              \\;\\equiv\\; \\mathrm{cdf}\\!\\left(F;\\, n_e-1,\\, n_c-1\\right).

This rank :math:`q \\in [0,1]` has three useful properties:

* :math:`q \\to 0`  when :math:`s_e \\ll s_c` (experiment markedly
  *less variable* than control — usually an *improvement*).
* :math:`q \\to 1`  when :math:`s_e \\gg s_c` (experiment markedly
  *more variable* than control — usually a *degradation*).
* :math:`q = 0.5`  when :math:`s_e = s_c` (variances equal).

The orientation is therefore intuitive: a curve hugging the left edge
of the panel is a "good" experiment, a curve hugging the right edge is
a "bad" one. This is **not** a classical two-sided p-value (which would
fold both tails toward zero); it is the unilateral cdf and it preserves
the *direction* of the difference, which matters for an analyst.

**Rejection regions.** A two-sided test of :math:`H_0` at significance
level :math:`\\alpha` rejects when

.. math::

   F < F_{\\alpha/2,\\,n_e-1,\\,n_c-1}
   \\quad\\text{or}\\quad
   F > F_{1-\\alpha/2,\\,n_e-1,\\,n_c-1},

equivalently when :math:`q(F) < \\alpha/2` **or** :math:`q(F) > 1 -
\\alpha/2`. The shaded red bands at :math:`q < 0.05` and :math:`q > 0.95`
therefore correspond to a **two-sided test at** :math:`\\alpha = 0.10`,
i.e. each tail carries 5 %. To recover the standard two-sided p-value
from what is plotted, use

.. math::

   p \\;=\\; 2\\,\\min\\!\\big(q,\\; 1-q\\big).

**Assumptions and how this code respects (or relaxes) them.**

1. *Normality of the underlying data.* The F-test is sensitive to
   departures from normality. OMP/OMA departures are typically nearly
   Gaussian after gross-error rejection; ``obsvalue`` of physical
   fields is not. Treat the test as a guide rather than as a strict
   inferential decision when ``--fonction obsvalue`` is used.

2. *Independence between samples.* Required by the textbook derivation.
   In our pipeline the two compared time series come from the same
   physical observation network with shared sampling errors and
   correlated synoptic conditions. The samples are therefore **not**
   independent in the strict sense, which inflates the apparent
   significance. The panel is a screening tool, not a publication-grade
   p-value.

3. *Equal sample sizes (common sample).* The variance-ratio test does
   not strictly require :math:`n_e = n_c`, but it does require that
   *the differences* in variance reflect the model rather than the
   sample composition. If the two experiments observe different
   subsets of reality, any apparent variance difference confounds
   "experiment" with "subset". The ``--common_sample`` flag fixes the
   subsets to the intersection across all experiments, which is the
   condition under which the panel deserves to be read literally. When
   the flag is off the panel title turns red and is annotated
   "approximate"; users should treat the curves as qualitative.

4. *Independence within a sample.* The sums :math:`\\sum x_i` and
   :math:`\\sum x_i^{\\,2}` are accumulated across vertical levels of
   the same profile and across many neighbouring observations, so
   nominal degrees of freedom :math:`n - 1` are an upper bound on the
   *effective* degrees of freedom. The actual quantile of the test is
   therefore conservative against significance.

**Numerical recipe (per vertical level).**

.. code-block:: text

    n  = SUM(CASE WHEN col IS NOT NULL THEN 1 ELSE 0 END)
    s  = SUM(col)
    s2 = SUM(col*col)

    mean   = s / n
    var    = (s2 - n*mean^2) / (n - 1)         # unbiased sample variance
    stddev = sqrt(max(var, 0))                 # cancellation guard

    F      = (stddev_e ** 2) / (stddev_c ** 2)
    q      = scipy.stats.f.cdf(F, n_e - 1, n_c - 1)

The level is silently skipped if either side has :math:`n < 2` or
:math:`s = 0`, which would make the ratio undefined.

Common-sample filter
^^^^^^^^^^^^^^^^^^^^
When ``--common_sample`` is given, every experiment's main query is
restricted to data points whose key
``(id_stn, [date], [time], round(lat, 2), round(lon, 2), vcoord, varno)``
appears in **every other** experiment as well. Because the filter is
applied symmetrically (control + experiments), N is identical across
all of them, which is the prerequisite the F-test needs.

Station selection (``--id_stn``)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Three modes:

* ``all``       — group by every distinct station; one set of plots per
  station.
* ``join``      — collapse all stations into a single bucket.
* ``COS%``,
  ``XYZ_5``, ... — any value containing SQL LIKE wildcards (``%``,
  ``_``) is treated as a pattern: only matching stations are kept and
  they are collapsed into a single ``"join"`` bucket. Filenames use a
  sanitized version of the pattern (e.g. ``COS%`` becomes ``COS``) so
  multiple pattern runs do not overwrite each other.

Output layout
-------------
Inside ``--pathwork``::

    pathwork/
    ├── <family>/                    regenerated every run
    │   ├── profile_<exp>_<...>.db   per-experiment aggregated stats
    │   └── *.png                    profile plots
    ├── pikobs_profile_viewer.html   interactive viewer
    └── _aggregation_errors.log      (only if something went wrong)

Cleanup behaviour at start-up
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Every invocation begins by wiping the contents of ``pathwork``
**except** for the directory called ``conversion_db/``. The intent is:

* Aggregated ``.db`` files, PNGs and the HTML viewer are *outputs* and
  are always regenerated, so it is safe (and desirable) to remove the
  stale ones first.
* The ``conversion_db/`` subdirectory is reserved for the BURP -> SQLite
  cache produced by the dedicated converter (``pikobs.pikobsburp2db``).
  Re-running this script must NOT trigger another conversion pass, so
  that folder is preserved verbatim.

Three safety guards prevent disasters:

* ``--pathwork`` cannot be empty,
* ``--pathwork`` cannot be ``/``,
* ``--pathwork`` cannot be the user's ``$HOME``.

Symbolic links are resolved before the walk so the cleanup never
escapes the canonicalised pathwork.

Plot anatomy
------------
Each PNG is a 4-panel figure sharing the vertical-coordinate axis:

1. **Bias** — mean departure profile per experiment.
2. **SD relative diff vs control** — :math:`100\\,(\\sigma_e - \\sigma_c)/\\sigma_c`.
3. **F-test p-value** — two-sided, with rejection bands at the 5 % and
   95 % tails. The panel title goes red when the run is not in
   common-sample mode (i.e. the test is approximate).
4. **N obs** — observation count per level. Compact format for legends:
   ``n = 12.66×10⁶`` instead of raw digits.

Visual style
------------
* Control: solid black, thick. Experiments: Okabe-Ito colour palette
  (colour-blind friendly), each with a distinct line style so that
  curves remain identifiable in greyscale prints and when colours
  visually overlap.
* Single combined legend at the foot of the figure.
* "Open frame" axes (no top/right spines), light grid, scientific
  formatter on the N-obs axis when counts exceed 10⁴.

Environment
-----------
This module is pure SQLite + NumPy + matplotlib. It does **not** invoke
``burp2rdb`` directly any more — that responsibility lives in
``pikobs.pikobsburp2db``. Ensure your inputs are real SQLite databases
(file magic ``"SQLite format 3\\x00"``); otherwise the run aborts with
a clear, actionable message.

Command-line reference
----------------------
The script is invoked through ``arg_call`` and accepts the arguments
listed below. Required arguments are flagged; everything else has a
sensible default.

Inputs (SQLite databases)
^^^^^^^^^^^^^^^^^^^^^^^^^
``--path_control_files PATH``                **(optional)**
    Directory holding the converted SQLite files for the control run.
    The files are looked up by date and family, in that order::

        <PATH>/<DATE>_<family>
        <PATH>/<DATE>_<family>.db
        <PATH>/db_converted_<control_name>_<DATE>_<family>.db

    The first match that is a valid SQLite file is used. Default:
    ``"undefined"``. If left undefined, the pipeline runs without a
    control and the first experiment becomes the reference for the
    plots (degenerate but allowed).

``--control_name NAME``                      **(required when ``--path_control_files`` is given)**
    Short tag identifying the control series. Used in legends and in
    output filenames.

``--path_experience_files PATH [PATH ...]``  **(at least one)**
    Directories of converted SQLite files, one directory per
    experiment. Same naming conventions as the control.

``--experience_name NAME [NAME ...]``        **(must mirror ``--path_experience_files``)**
    One short tag per experiment. The number of names must match the
    number of paths; otherwise the pipeline aborts.

Run identity
^^^^^^^^^^^^
``--pathwork PATH``                          **(required)**
    Output directory. Will be wiped at start-up except for the
    ``conversion_db/`` subdirectory (see "Cleanup behaviour" above).

``--datestart YYYYMMDDHH``                   **(required)**
``--dateend   YYYYMMDDHH``                   **(required)**
    Inclusive range of assimilation cycles to read. Cycles are stepped
    every 6 hours.

Spatial / variable selection
^^^^^^^^^^^^^^^^^^^^^^^^^^^^
``--region REGION [REGION ...]``             **(at least one)**
    Region tag(s) understood by ``pikobs.regions()`` — typically
    ``Monde``, ``Tropics``, ``NHem``, ``SHem``, etc. One full set of
    plots is produced per region.

``--family FAMILY [FAMILY ...]``             **(at least one)**
    Observation family tag(s) understood by ``pikobs.family()``,
    e.g. ``ro``, ``ai``, ``ua``, ``go``, ``amsua``, ``cris``, ``iasi``,
    ``atms``. One folder per family is created under ``pathwork``.

``--varnos VARNO [VARNO ...]``               (optional)
    Override the default varnos that ``pikobs.family()`` returns for
    the chosen family. Useful to plot a specific variable instead of
    every one available.

``--surface {world, sea, land}``             (default ``world``)
    Restrict observations to sea, land, or keep them all.
    Implementation order: explicit ``elevation`` column on the header
    table → land/sea mask columns (``lsm``, ``surface``,
    ``land_sea_mask``). If none of those columns exist, the filter is
    silently dropped and a "world" run is produced.

``--id_stn VALUE``                           (default ``all``)
    Station selection mode. Three behaviours:

    * ``all`` — group by every distinct ``id_stn``. One set of plots
      per station. Useful for instrument or site-by-site diagnostics.
    * any value containing ``%`` or ``_`` — treated as a SQL LIKE
      pattern: only matching stations are kept and they are collapsed
      into a single ``"join"`` bucket. Filenames use the
      alphanumeric-stripped pattern (``"COS%"`` -> ``"COS"``) so two
      pattern runs in the same ``pathwork`` do not overwrite each
      other.
    * any other literal value — collapses every station into a single
      bucket regardless. Equivalent to passing ``join`` directly.

``--channel VALUE``                          (default ``all``)
    Vertical-coordinate selection. ``all`` keeps every level / channel
    distinct; any other value flattens every level into a single
    ``"join"`` group (one row per ``(lat, lon, varno)`` combination).
    Useful for satellite radiances that you do not want to break down
    by channel.

Statistic chosen for the plot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
``--fonction FUNC [FUNC ...]``               **(at least one)**
    What is summed in the variance / bias panels. Each entry must be
    one of:

    * ``omp``      — observation minus background (default for most
      monitoring jobs).
    * ``oma``      — observation minus analysis.
    * ``obsvalue`` — raw observation value (less common; care with
      numerical-cancellation in the variance for very large means,
      e.g. temperature in K).

    The chosen column drives both the running ``n`` count and the
    sums, so the resulting mean and variance are internally
    consistent. If you pass several values, every plot is rendered for
    every function.

``--flags_criteria CRIT [CRIT ...]``         **(at least one)**
    Flag-mask criteria understood by ``pikobs.flag_criteria()`` —
    typically ``assimilee`` (only assimilated obs), ``rejected``,
    ``monitored``, etc. One set of plots per criterion.

Common-sample restriction
^^^^^^^^^^^^^^^^^^^^^^^^^
``--common_sample``                          (boolean flag, default off)
    When set, every experiment's main query is restricted to data
    points whose key
    ``(id_stn, [date], [time], round(lat,2), round(lon,2), vcoord, varno)``
    appears in **every** other experiment as well. Because the filter
    is applied symmetrically (control + experiments), N is identical
    across all of them — the prerequisite the F-test needs to be
    rigorous. Without this flag the F-test panel labels itself
    "approximate" in red.

F-test convention shown in panel 3
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
``--ftest_mode {directional, confidence, pvalue}``  (default ``directional``)
    Selects which transformation of the F-ratio is plotted:

    * ``directional`` — the cdf rank ``q = cdf(F)``. Range ``[0, 1]``,
      direction preserved (``q -> 0`` improvement, ``q -> 1``
      degradation, ``q = 0.5`` equal). Two-sided rejection bands at
      ``q < 0.05`` and ``q > 0.95`` -> alpha = 0.10.
    * ``confidence`` — the legacy ``(1 - p) * 100`` percent scale.
      Range ``[0, 100]``, direction LOST. Single rejection band at
      ``out > 95`` -> alpha = 0.05.
    * ``pvalue`` — textbook two-sided p-value. Range ``[0, 1]``,
      direction LOST. Single rejection band at ``p < 0.05``.

    Filenames carry the suffix ``_F<mode>`` for the two non-default
    modes so you can keep them side by side without overwriting.

Parallelism
^^^^^^^^^^^
``--n_cpus N``                               (default ``1``)
    Dask worker count. ``1`` means strict serial. Aggregation and
    plotting are independently parallelised: each worker owns a single
    output ``.db`` (no per-file write contention) and one figure
    respectively.

Example
^^^^^^^
.. code-block:: bash

   python -c 'import pikobs; pikobs.progps.arg_call()'         \\
       --path_control_files     /path/converted/CTL            \\
       --control_name           Control                        \\
       --path_experience_files  /path/converted/EXP1           \\
                                /path/converted/EXP2           \\
       --experience_name        Exp1 Exp2                      \\
       --pathwork               /workdir/profiles/             \\
       --datestart 2022053100 --dateend 2022062812             \\
       --region    Monde                                       \\
       --family    ro                                          \\
       --flags_criteria assimilee                              \\
       --fonction       omp                                    \\
       --id_stn         "COS%"                                 \\
       --surface        sea                                    \\
       --common_sample                                         \\
       --ftest_mode     directional                            \\
       --n_cpus         40

contact
----------------
https://gitlab.science.gc.ca/dlo001/Pikobs
 """

import os
import sys
import re
import time
import json
import shutil
import sqlite3
import argparse
import datetime
import traceback
from datetime import timedelta
from collections import defaultdict
import warnings

import numpy as np
import scipy.stats as stats
import matplotlib as mpl
import matplotlib.pyplot as plt
import dask
from dask.distributed import Client

import pikobs

mpl.use("Agg")
warnings.filterwarnings("ignore", ".*ShapelyDeprecationWarning.*")


# =============================================================================
#  CONSTANTS / SCHEMA
# =============================================================================

_DDL_MOYENNE = """
    CREATE TABLE IF NOT EXISTS moyenne (
        Nrej INTEGER, Nacc INTEGER, Nprofile INTEGER, DATE INTEGER,
        lat FLOAT, lon FLOAT, boite INTEGER, id_stn TEXT,
        varno INTEGER, vcoord FLOAT, sumx FLOAT, sumy FLOAT,
        sumz FLOAT, sumStat FLOAT, sumx2 FLOAT, sumy2 FLOAT,
        sumz2 FLOAT, sumStat2 FLOAT, n INTEGER, flag INTEGER, elevation FLOAT
    );
"""

_COLS_MOYENNE = (
    "Nrej, Nacc, Nprofile, DATE, lat, lon, boite, id_stn, varno, vcoord, "
    "sumx, sumy, sumz, sumStat, sumx2, sumy2, sumz2, sumStat2, n, flag, elevation"
)

# Subdirectory inside `pathwork` that the cleanup step will preserve. Any
# external converter may place its output here so the cache survives runs.
_CONVERSION_DIR_NAME = "conversion_db"


# =============================================================================
#  LOW-LEVEL DB HELPERS
# =============================================================================

def create_table_if_not_exists(cursor_or_conn) -> None:
    cursor_or_conn.execute(_DDL_MOYENNE)


def combine(pathfileout: str, rows: list) -> None:
    """Insert aggregated rows into the output ``moyenne`` table (WAL)."""
    insert_sql = (
        f"INSERT INTO moyenne({_COLS_MOYENNE}) "
        f"VALUES ({','.join(['?'] * 21)})"
    )
    max_retries, base_delay = 12, 0.5
    for attempt in range(max_retries):
        try:
            with sqlite3.connect(pathfileout, timeout=60) as conn:
                conn.execute("PRAGMA journal_mode=WAL;")
                conn.execute("PRAGMA synchronous=NORMAL;")
                conn.execute("PRAGMA cache_size=-32000;")
                create_table_if_not_exists(conn)
                conn.executemany(insert_sql, rows)
                conn.commit()
            return
        except sqlite3.OperationalError as e:
            if "locked" in str(e) and attempt < max_retries - 1:
                time.sleep(base_delay * (2 ** attempt))
            else:
                raise


def _is_sqlite3(filepath: str) -> bool:
    """Cheap check: first 16 bytes equal the SQLite magic header."""
    if not os.path.isfile(filepath):
        return False
    try:
        with open(filepath, "rb") as fd:
            return fd.read(16) == b"SQLite format 3\x00"
    except OSError:
        return False


def _is_sqlite3_intact(filepath: str) -> bool:
    """Header check + a minimal query; rejects truncated databases."""
    if not _is_sqlite3(filepath):
        return False
    try:
        with sqlite3.connect(filepath, timeout=5) as conn:
            conn.execute("SELECT name FROM sqlite_master LIMIT 1;").fetchone()
        return True
    except sqlite3.DatabaseError:
        return False


def _clean_pathwork_preserving_cache(pathwork: str) -> None:
    """
    Wipe everything inside ``pathwork`` EXCEPT the ``conversion_db/``
    subdirectory. Refuses to operate on ``/``, the user's ``$HOME``, or
    an empty path.
    """
    if not pathwork or pathwork in ("/", os.path.expanduser("~")):
        sys.stderr.write(
            f"[clean] refusing to clean unsafe pathwork: {pathwork!r}\n"
        )
        return

    pathwork = os.path.realpath(pathwork)
    if not os.path.isdir(pathwork):
        os.makedirs(pathwork, exist_ok=True)
        os.makedirs(os.path.join(pathwork, _CONVERSION_DIR_NAME), exist_ok=True)
        return

    cache_dir = os.path.join(pathwork, _CONVERSION_DIR_NAME)
    n_kept, n_removed = 0, 0
    for entry in os.listdir(pathwork):
        full = os.path.join(pathwork, entry)
        if entry == _CONVERSION_DIR_NAME:
            n_kept += 1
            continue
        try:
            if os.path.islink(full) or os.path.isfile(full):
                os.remove(full)
            elif os.path.isdir(full):
                shutil.rmtree(full)
            n_removed += 1
        except OSError as e:
            sys.stderr.write(f"[clean] could not remove {full}: {e}\n")

    os.makedirs(cache_dir, exist_ok=True)
    print(
        f"[clean] pathwork={pathwork} | removed {n_removed} entries | "
        f"preserved {_CONVERSION_DIR_NAME}/"
    )


def _validate_inputs_are_sqlite(files: list) -> None:
    """
    Abort with a clear message if any input is not a valid SQLite file.
    Conversion of BURP -> SQLite is the converter's job, not ours.
    """
    bad = []
    missing = []
    for f in files:
        if not f or not os.path.isfile(f):
            missing.append(f)
        elif not _is_sqlite3(f):
            bad.append(f)

    if missing or bad:
        sys.stderr.write(
            "\n"
            "================================================================\n"
            "  INPUT VALIDATION FAILED\n"
            "================================================================\n"
            "  This pipeline expects SQLite databases as input. BURP files\n"
            "  are NOT converted automatically any more; please run the\n"
            "  conversion step first:\n\n"
            "    python -c 'import pikobs; pikobs.pikobsburp2db.arg_call()' \\\n"
            "        --path_experience_files <BURP_DIR_1> <BURP_DIR_2> ... \\\n"
            "        --experience_name        <NAME_1>    <NAME_2>    ... \\\n"
            "        --pathwork               <WORK_DIR>                  \\\n"
            "        --datestart YYYYMMDDHH --dateend YYYYMMDDHH          \\\n"
            "        --n_cpu  40\n\n"
            "  Then point this script at the converted SQLite files.\n"
            "----------------------------------------------------------------\n"
        )
        if missing:
            sys.stderr.write("  Missing files (none of these exist on disk):\n")
            for f in missing[:10]:
                sys.stderr.write(f"    - {f}\n")
            if len(missing) > 10:
                sys.stderr.write(f"    ... and {len(missing) - 10} more\n")
        if bad:
            sys.stderr.write("  Not a valid SQLite database:\n")
            for f in bad[:10]:
                sys.stderr.write(f"    - {f}\n")
            if len(bad) > 10:
                sys.stderr.write(f"    ... and {len(bad) - 10} more\n")
        sys.stderr.write(
            "================================================================\n\n"
        )
        sys.exit(2)


# =============================================================================
#  AGGREGATION (Phase 1)
# =============================================================================

# Map the user-facing function name to the SQL column we aggregate on.
_FUNCTION_TO_COLUMN = {
    "omp"     : "omp",
    "oma"     : "oma",
    "obsvalue": "obsvalue",
}


def _surface_criterion(surface: str, h_cols: list, elev_col: str = None) -> str:
    if surface in ("world", "overworld"):
        return ""
    is_sea = (surface == "oversea")
    if elev_col:
        op = "<= 0" if is_sea else "> 0"
        return f" AND main_h.{elev_col} {op} "

    for col, sea_op, land_op in [
        ("lsm",           "= 0",  "= 1"),
        ("surface",       "= 0",  "= 1"),
        ("land_sea_mask", "= 0",  "= 1"),
    ]:
        if col in h_cols:
            op = sea_op if is_sea else land_op
            return f" AND main_h.{col} {op} "
    return ""


def _qualify_vcoord(vcoord_expr: str) -> str:
    """
    ``pikobs.family()`` may return either a bare column ``"vcoord"`` or
    an expression like ``"(vcoord - 273.15)"``. In the latter case we
    rewrite ``vcoord`` -> ``main_d.vcoord`` so the JOIN does not become
    ambiguous. Word-boundaries are used so a longer identifier
    (e.g. ``vcoord_abc``) is left alone.
    """
    if "(" in vcoord_expr or " " in vcoord_expr:
        return re.sub(r"\bvcoord\b", "main_d.vcoord", vcoord_expr)
    return f"main_d.{vcoord_expr}"


def create_and_populate_moyenne_table(
        family, new_db_filename, target_db_path, all_db_paths,
        selected_region, selected_flags, FUNCTION, varnos, channel,
        id_stn, surface, common_sample) -> None:
    """Top-level wrapper - logs unexpected aggregation errors per output."""
    try:
        _do_aggregation(
            family, new_db_filename, target_db_path, all_db_paths,
            selected_region, selected_flags, FUNCTION, varnos,
            channel, id_stn, surface, common_sample,
        )
    except Exception as e:
        msg = (
            f"\n[!!] Aggregation FAILED for {os.path.basename(target_db_path)} "
            f"-> {type(e).__name__}: {e}\n{traceback.format_exc()}"
        )
        sys.stderr.write(msg)
        sys.stderr.flush()
        try:
            log_dir = os.path.dirname(new_db_filename)
            os.makedirs(log_dir, exist_ok=True)
            with open(os.path.join(log_dir, "_aggregation_errors.log"), "a") as fh:
                fh.write(msg + "\n")
        except OSError:
            pass


def _do_aggregation(
        family, new_db_filename, target_db_path, all_db_paths,
        selected_region, selected_flags, FUNCTION, varnos, channel,
        id_stn, surface, common_sample) -> None:

    target_db_path = os.path.normpath(target_db_path)

    if not _is_sqlite3(target_db_path):
        sys.stderr.write(
            f"[skip] not an SQLite file: {os.path.basename(target_db_path)}\n"
            f"       (run the burp -> sqlite converter first)\n"
        )
        return

    date_match = re.search(r"(\d{10})", target_db_path)
    if not date_match:
        sys.stderr.write(f"[skip] no date stamp in name: {target_db_path}\n")
        return
    date_str = date_match.group(1)

    FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)
    if varnos:
        element = ",".join(str(v) for v in varnos)
    LAT1, LAT2, LON1, LON2 = pikobs.regions(selected_region)
    LATLONCRIT    = pikobs.generate_latlon_criteria(LAT1, LAT2, LON1, LON2)
    flag_criteria = pikobs.flag_criteria(selected_flags)

    func_lower = (FUNCTION[0] if isinstance(FUNCTION, (list, tuple))
                  else FUNCTION).lower()
    primary_col = _FUNCTION_TO_COLUMN.get(func_lower, "obsvalue")

    try:
        src_conn = sqlite3.connect(target_db_path, timeout=60)
    except sqlite3.OperationalError as e:
        sys.stderr.write(f"[skip] cannot open {target_db_path}: {e}\n")
        return

    attached: list = []
    try:
        src_conn.execute("PRAGMA query_only=1;")
        src_conn.execute("PRAGMA temp_store=MEMORY;")
        src_conn.execute("PRAGMA cache_size=-65536;")
        src_conn.execute("PRAGMA mmap_size=268435456;")
        cursor = src_conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        all_tbls = {r[0].lower(): r[0] for r in cursor.fetchall()}
        if "header" not in all_tbls or "data" not in all_tbls:
            sys.stderr.write(
                f"[skip] {os.path.basename(target_db_path)} missing "
                f"header/data tables.\n"
            )
            return
        T_HEADER = all_tbls["header"]
        T_DATA   = all_tbls["data"]

        cursor.execute(f"PRAGMA table_info('{T_HEADER}');")
        h_cols = [c[1].lower() for c in cursor.fetchall()]
        cursor.execute(f"PRAGMA table_info('{T_DATA}');")
        d_cols = [c[1].lower() for c in cursor.fetchall()]

        elev_col = None
        for cand in ("elevation", "elev"):
            if cand in h_cols:
                elev_col = cand
                break

        if primary_col not in d_cols:
            sys.stderr.write(
                f"[skip] column '{primary_col}' not in data table of "
                f"{os.path.basename(target_db_path)} (have: {d_cols})\n"
            )
            return

        surface_crit = _surface_criterion(surface, h_cols, elev_col)
        has_time     = "time" in h_cols
        has_date     = "date" in h_cols

        # id_stn pattern detection — used both in the common-sample
        # subquery and in the main WHERE clause.
        id_stn_is_pattern = (
            ("%" in id_stn) or ("_" in id_stn and id_stn != "all")
        )
        id_stn_like_sql = ""
        if id_stn_is_pattern:
            safe_pattern    = id_stn.replace("'", "''")
            id_stn_like_sql = f" AND main_h.id_stn LIKE '{safe_pattern}' "
            ref_like_sql    = f" AND rh.id_stn LIKE '{safe_pattern}' "
        else:
            ref_like_sql = ""

        # --- common-sample SQL fragment --------------------------------------
        common_sample_crit = ""
        if common_sample and len(all_db_paths) > 1:
            other_paths = [
                os.path.normpath(p) for p in all_db_paths
                if os.path.normpath(p) != target_db_path
                and os.path.isfile(p) and _is_sqlite3(p)
            ]
            left_keys = ["main_h.id_stn"]
            if has_date: left_keys.append("main_h.date")
            if has_time: left_keys.append("main_h.time")
            left_keys += [
                "ROUND(main_h.lat, 2)",
                "ROUND(main_h.lon, 2)",
                "main_d.vcoord",
                "main_d.varno",
            ]
            left_tuple = "(" + ", ".join(left_keys) + ")"

            in_clauses = []
            for k, other in enumerate(other_paths):
                alias = f"ref_{k}"
                try:
                    cursor.execute(f"ATTACH DATABASE ? AS {alias};", (other,))
                except sqlite3.OperationalError as e:
                    sys.stderr.write(
                        f"[common_sample] could not ATTACH {other}: {e}\n"
                    )
                    continue
                attached.append(alias)

                right_keys = ["rh.id_stn"]
                if has_date: right_keys.append("rh.date")
                if has_time: right_keys.append("rh.time")
                right_keys += [
                    "ROUND(rh.lat, 2)",
                    "ROUND(rh.lon, 2)",
                    "rd.vcoord",
                    "rd.varno",
                ]
                right_select = ", ".join(right_keys)

                in_clauses.append(f"""
                    {left_tuple} IN (
                        SELECT {right_select}
                        FROM {alias}.{T_HEADER} rh
                        JOIN {alias}.{T_DATA} rd USING(id_obs)
                        WHERE rd.varno IN ({element})
                          AND rd.{primary_col} IS NOT NULL
                          {ref_like_sql}
                    )
                """)

            if in_clauses:
                common_sample_crit = " AND " + " AND ".join(in_clauses)

        # --- column expressions (qualified) ----------------------------------
        col       = f"main_d.{primary_col}"
        n_sql     = f"SUM(CASE WHEN {col} IS NOT NULL THEN 1 ELSE 0 END)"

        sum_omp   = "SUM(main_d.omp)"           if "omp"      in d_cols else "NULL"
        sum_omp2  = "SUM(main_d.omp*main_d.omp)" if "omp"      in d_cols else "NULL"
        sum_oma   = "SUM(main_d.oma)"           if "oma"      in d_cols else "NULL"
        sum_oma2  = "SUM(main_d.oma*main_d.oma)" if "oma"      in d_cols else "NULL"
        sum_obs   = "SUM(main_d.obsvalue)"      if "obsvalue" in d_cols else "NULL"
        sum_obs2  = (
            "SUM(main_d.obsvalue*main_d.obsvalue)"
            if "obsvalue" in d_cols else "NULL"
        )
        sum_bias_corr  = "SUM(main_d.bias_corr)" \
            if "bias_corr" in d_cols else "NULL"
        sum_bias_corr2 = "SUM(main_d.bias_corr*main_d.bias_corr)" \
            if "bias_corr" in d_cols else "NULL"

        # moyenne stores sumx<-omp, sumy<-oma, sumz<-obsvalue regardless
        # of which function is plotted (mapping happens at read time).
        sumx_expr,  sumx2_expr  = sum_omp,  sum_omp2
        sumy_expr,  sumy2_expr  = sum_oma,  sum_oma2
        sumz_expr,  sumz2_expr  = sum_obs,  sum_obs2

        # Channel grouping
        if channel == "all":
            vcoord_qual = _qualify_vcoord(VCOORD)
            chan_sel = f"{vcoord_qual} AS Chan,"
            chan_grp = vcoord_qual
        else:
            chan_sel = '"join" AS Chan,'
            chan_grp = None

        # id_stn select / group_by
        if id_stn == "all":
            id_sel = "main_h.id_stn AS id_stn,"
            id_grp = "main_h.id_stn"
        else:
            id_sel = '"join" AS id_stn,'
            id_grp = None
        id_stn_filter = id_stn_like_sql

        grp_parts = ["main_h.lat", "main_h.lon", "main_d.varno"]
        if chan_grp: grp_parts.append(chan_grp)
        if id_grp:   grp_parts.append(id_grp)
        if family == "ra" and elev_col:
            grp_parts.append(f"main_h.{elev_col}")
        group_by = "GROUP BY " + ",".join(grp_parts)

        elevation_select = (
            f"main_h.{elev_col} AS elevation"
            if (family == "ra" and elev_col)
            else "NULL AS elevation"
        )

        # NOTE: pikobs.flag_criteria() returns a fragment that already
        # begins with " AND ", so we splice it in directly.
        select_query = f"""
        SELECT
            {date_str}                            AS DATE,
            main_h.lat                            AS lat,
            main_h.lon                            AS lon,
            main_d.varno                          AS varno,
            {chan_sel}
            {sumx_expr}                           AS sumx,
            {sumy_expr}                           AS sumy,
            {sumz_expr}                           AS sumz,
            {sum_bias_corr}                       AS sumStat,
            {sumx2_expr}                          AS sumx2,
            {sumy2_expr}                          AS sumy2,
            {sumz2_expr}                          AS sumz2,
            {sum_bias_corr2}                      AS sumStat2,
            {n_sql}                               AS n,
            SUM(CASE WHEN (main_d.flag & 512)  = 512  THEN 1 ELSE 0 END) AS Nrej,
            SUM(CASE WHEN (main_d.flag & 4096) = 4096 THEN 1 ELSE 0 END) AS Nacc,
            COUNT(DISTINCT main_h.id_obs)         AS Nprofile,
            {id_sel}
            MIN(main_d.flag)                      AS flag,
            {elevation_select}
        FROM {T_HEADER} main_h
        JOIN {T_DATA}   main_d USING(id_obs)
        WHERE main_d.varno IN ({element})
          AND {col} IS NOT NULL
          {flag_criteria}
          {LATLONCRIT}
          {VCOCRIT}
          {surface_crit}
          {id_stn_filter}
          {common_sample_crit}
        {group_by};
        """

        try:
            cursor.execute(select_query)
            raw_rows = cursor.fetchall()
        except sqlite3.Error as e:
            sys.stderr.write(
                f"[skip] SELECT failed on "
                f"{os.path.basename(target_db_path)}: {e}\n"
                f"  -- query (first 600 chars): {select_query[:600]}\n"
            )
            return

        if not raw_rows:
            sys.stderr.write(
                f"[info] zero rows after filters in "
                f"{os.path.basename(target_db_path)} "
                f"(varno IN ({element}), col={primary_col}, "
                f"surface={surface}, common_sample={common_sample})\n"
            )

    finally:
        for a in attached:
            try: src_conn.execute(f"DETACH DATABASE {a};")
            except sqlite3.Error: pass
        src_conn.close()

    if not raw_rows:
        return

    rows = [
        (
            r[14], r[15], r[16],         # Nrej, Nacc, Nprofile
            r[0],                        # DATE
            r[1], r[2],                  # lat, lon
            None,                        # boite
            r[17],                       # id_stn
            r[3], r[4],                  # varno, vcoord (Chan)
            r[5], r[6], r[7], r[8],      # sumx, sumy, sumz, sumStat
            r[9], r[10], r[11], r[12],   # sumx2, sumy2, sumz2, sumStat2
            r[13],                       # n
            r[18],                       # flag
            r[19],                       # elevation
        )
        for r in raw_rows
    ]

    try:
        combine(new_db_filename, rows)
    except sqlite3.Error as e:
        sys.stderr.write(f"[skip] combine() failed: {e}\n")


# =============================================================================
#  PLAN BUILDERS
# =============================================================================

def _surf_tag(surface: str) -> str:
    return f"over{surface}"


def create_data_list(date_start, date_end, families, input_paths, names,
                     work_path, function, flag_criterias, regions, varnos,
                     surface, common_sample):
    """
    Walk the date range and, for each ``(date, family)``, locate the
    matching SQLite file inside each ``input_path``. The conversion step
    has been removed - inputs are validated up front by the caller.
    """
    data_list = []
    dt_start  = datetime.datetime.strptime(date_start, "%Y%m%d%H")
    dt_end    = datetime.datetime.strptime(date_end,   "%Y%m%d%H")
    stag      = _surf_tag(surface)

    input_paths = [os.path.normpath(p) for p in input_paths]
    work_path   = os.path.normpath(work_path)

    current_date = dt_start
    while current_date <= dt_end:
        fdate = current_date.strftime("%Y%m%d%H")
        for family in families:
            os.makedirs(f"{work_path}/{family}", exist_ok=True)

            resolved_files = []
            for i, path in enumerate(input_paths):
                # Common naming conventions emitted by pikobsburp2db:
                #   <DATE>_<family>             (raw burp-style naming)
                #   <DATE>_<family>.db          (with extension)
                #   db_converted_<NAME>_<DATE>_<family>.db
                exp_name = names[i]
                candidates = [
                    os.path.normpath(f"{path}/{fdate}_{family}"),
                    os.path.normpath(f"{path}/{fdate}_{family}.db"),
                    os.path.normpath(
                        f"{path}/db_converted_{exp_name}_{fdate}_{family}.db"
                    ),
                ]
                actual = next(
                    (c for c in candidates if _is_sqlite3(c)),
                    candidates[0],
                )
                resolved_files.append(actual)

            for flag_criteria in flag_criterias:
                for region in regions:
                    dbs_new = [
                        os.path.normpath(
                            f"{work_path}/{family}/profile_{name}_{region}_"
                            f"{stag}_{date_start}_{date_end}_"
                            f"{flag_criteria}_{family}.db"
                        )
                        for name in names
                    ]
                    data_list.append({
                        "family"        : family,
                        "region"        : region,
                        "flag_criteria" : flag_criteria,
                        "function"      : function,
                        "varnos"        : varnos,
                        "surface"       : stag,
                        "files_in"      : resolved_files,
                        "dbs_new"       : dbs_new,
                    })
        current_date += timedelta(hours=6)
    return data_list


def get_id_stns(cursor, id_stn):
    if id_stn == "all":
        cursor.execute("SELECT DISTINCT id_stn FROM moyenne;")
        return [row[0] for row in cursor.fetchall()]
    return ["join"]


def fetch_vcoords(cursor, where_clause):
    cursor.execute(
        f"SELECT DISTINCT 'all', varno FROM moyenne {where_clause} "
        f"ORDER BY vcoord ASC;"
    )
    return cursor.fetchall()


def fetch_channels_varno(cursor):
    cursor.execute("SELECT DISTINCT varno FROM moyenne ORDER BY vcoord ASC;")
    return [row[0] for row in cursor.fetchall()]


def create_data_list_plot(date_start, date_end, families, names_in, work_path,
                          functions, flag_criterias, regions, id_stn, channel,
                          surface):
    data_list_plot = []
    stag = _surf_tag(surface)

    for family in families:
        for flag_criteria in flag_criterias:
            for region in regions:
                for function in functions:
                    file_ctl = (
                        f"{work_path}/{family}/profile_{names_in[0]}_{region}_"
                        f"{stag}_{date_start}_{date_end}_{flag_criteria}_"
                        f"{family}.db"
                    )
                    if not os.path.isfile(file_ctl):
                        print(f"[plot list] missing: {file_ctl}")
                        continue
                    try:
                        with sqlite3.connect(
                            f"file:{file_ctl}?mode=ro", uri=True
                        ) as conn:
                            cursor = conn.cursor()
                            cursor.execute("SELECT COUNT(*) FROM moyenne;")
                            n_rows = cursor.fetchone()[0]
                            if n_rows == 0:
                                print(
                                    f"[plot list] empty moyenne: "
                                    f"{os.path.basename(file_ctl)}"
                                )
                                continue
                            print(
                                f"[plot list] {os.path.basename(file_ctl)}: "
                                f"{n_rows} rows"
                            )
                            id_stns = get_id_stns(cursor, id_stn)

                            # Filename label for id_stn selection.
                            if id_stn == "all":
                                label_for_filename = None
                            elif "%" in id_stn or "_" in id_stn:
                                label_for_filename = re.sub(
                                    r"[^A-Za-z0-9]", "", id_stn
                                ) or "join"
                            else:
                                label_for_filename = "join"

                            for idstn in id_stns:
                                if id_stn == "all":
                                    where    = f'WHERE id_stn = "{idstn}"'
                                    fname_id = idstn
                                else:
                                    where    = ""
                                    fname_id = label_for_filename

                                target_varnos = (
                                    [v for _, v in fetch_vcoords(cursor, where)]
                                    if channel == "all"
                                    else fetch_channels_varno(cursor)
                                )
                                for varno in target_varnos:
                                    plot_files = [
                                        f"{work_path}/{family}/profile_{n}_"
                                        f"{region}_{stag}_{date_start}_"
                                        f"{date_end}_{flag_criteria}_"
                                        f"{family}.db"
                                        for n in names_in
                                    ]
                                    data_list_plot.append({
                                        "id_stn"   : fname_id,    # filename
                                        "id_stn_db": idstn,       # SQL key
                                        "vcoord"   : "all" if channel == "all" else "join",
                                        "varno"    : varno,
                                        "region"   : region,
                                        "function" : function,
                                        "family"   : family,
                                        "criteria" : flag_criteria,
                                        "surface"  : stag,
                                        "files_in" : plot_files,
                                    })
                    except sqlite3.Error as e:
                        print(f"[plot list] cannot open {file_ctl}: {e}")

    print(f"[plot list] total entries: {len(data_list_plot)}")
    return data_list_plot


# =============================================================================
#  PLOTTING (Phase 2)
# =============================================================================

# moyenne.sumx <- omp,  sumy <- oma,  sumz <- obsvalue   (always)
_FUNC_COLS = {
    "omp"     : ("sumx", "sumx2"),
    "oma"     : ("sumy", "sumy2"),
    "obsvalue": ("sumz", "sumz2"),
}

# --- professional palette -----------------------------------------------------
# Control: solid black, anchor that contrasts with every experiment.
# Experiments: Okabe-Ito qualitative palette - the colour-blind friendly
# standard for scientific publication. Eight hues are available; if more
# than 8 experiments are passed the palette wraps, but the linestyle
# cycle keeps lines distinguishable.
_COLOR_CTL  = "#000000"
_COLORS_EXP = [
    "#E69F00",   # orange
    "#56B4E9",   # sky blue
    "#009E73",   # bluish green
    "#CC79A7",   # reddish purple
    "#D55E00",   # vermillion
    "#0072B2",   # blue
    "#F0E442",   # yellow
    "#7F00FF",   # violet (extra slot beyond Okabe-Ito's 7)
]
_LINESTYLES_EXP = [
    "-",                       # solid
    (0, (5, 2)),               # long dash
    (0, (1, 1.5)),             # dotted
    (0, (3, 1.5, 1, 1.5)),     # dash-dot
    (0, (5, 1, 1, 1, 1, 1)),   # dash-dot-dot
    (0, (6, 2, 2, 2)),         # long-short
    "-",
    (0, (3, 1)),
]


def _exp_style(i: int):
    return (
        _COLORS_EXP[i % len(_COLORS_EXP)],
        _LINESTYLES_EXP[i % len(_LINESTYLES_EXP)],
    )


def _apply_axes_style(ax) -> None:
    """Open-frame style: subtle grid, no top/right spines."""
    ax.grid(True, which="major", color="#cfd6dc",
            linestyle="-", linewidth=0.6, alpha=0.9)
    ax.grid(True, which="minor", color="#e6ebef",
            linestyle="-", linewidth=0.4, alpha=0.6)
    ax.minorticks_on()
    ax.tick_params(axis="both", which="major", labelsize=10,
                   color="#34495e", length=4, width=0.8)
    ax.tick_params(axis="both", which="minor",
                   color="#7f8c8d", length=2, width=0.6)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    for sp in ("left", "bottom"):
        ax.spines[sp].set_color("#34495e")
        ax.spines[sp].set_linewidth(0.9)


def _fmt_n(n: int) -> str:
    """
    Compact representation of an observation count for figure legends:
      ``2 543``      -> ``"2,543"``
      ``12 700``     -> ``"12.7K"``
      ``12 655 954`` -> ``"12.66×10⁶"``
    """
    n = int(n)
    if n < 10_000:
        return f"{n:,}"
    if n < 1_000_000:
        return f"{n/1_000:.1f}K"
    return f"{n/1_000_000:.2f}\u00d710\u2076"


def _read_profile(db_file: str, function: str, varno, id_stn: str):
    """
    Return per-level mean and unbiased sample standard deviation::

        mean   = sumX / n
        var    = (sumX2 - n*mean^2) / (n - 1)        for n >= 2
        stddev = sqrt(max(var, 0))
    """
    col_sum, col_sum2 = _FUNC_COLS.get(function.lower(), ("sumx", "sumx2"))
    try:
        with sqlite3.connect(f"file:{db_file}?mode=ro", uri=True) as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"""
                SELECT vcoord,
                       SUM(n)           AS total_n,
                       SUM({col_sum})   AS total_sum,
                       SUM({col_sum2})  AS total_sum2
                FROM moyenne
                WHERE varno = ? AND id_stn = ?
                GROUP BY vcoord
                ORDER BY vcoord ASC
                """,
                (varno, id_stn),
            )
            rows = cursor.fetchall()
    except sqlite3.Error as e:
        print(f"[read_profile] {os.path.basename(db_file)}: {e}")
        return None

    levels, n_obs, biases, std_devs = [], [], [], []
    for vc, n, s, s2 in rows:
        if n is None or s is None or s2 is None:
            continue
        n = int(n)
        if n < 2:
            continue
        mean = s / n
        var = (s2 - n * mean * mean) / (n - 1)
        if var < 0:
            scale = abs(s2) / max(n - 1, 1)
            if var < -1e-6 * scale and scale > 0:
                print(
                    f"[read_profile] WARN cancellation: "
                    f"db={os.path.basename(db_file)} varno={varno} "
                    f"vcoord={vc} var={var:.3e} scale={scale:.3e} n={n}"
                )
            var = 0.0
        levels.append(float(vc))
        n_obs.append(n)
        biases.append(float(mean))
        std_devs.append(float(np.sqrt(var)))

    if not levels:
        return None
    return {
        "levels": np.array(levels),
        "n"     : np.array(n_obs),
        "bias"  : np.array(biases),
        "std"   : np.array(std_devs),
    }


_FTEST_MODES = ("directional", "confidence", "pvalue")


def _ftest_pvalue(std_a, n_a, std_b, n_b, mode: str = "directional"):
    """
    Two-variance F-test, level by level. Three output conventions.

    Subscript convention: ``a`` = control, ``b`` = experiment.

    Hypotheses
    ----------
    Per vertical level, assuming independent normal samples::

        H0 : sigma_b^2 == sigma_a^2
        H1 : sigma_b^2 != sigma_a^2

    Common test statistic
    ---------------------
    The cumulative-distribution-function rank of the observed ratio,

        q = cdf(F, df_b, df_a)      with  F = s_b^2 / s_a^2,
                                          df_b = n_b - 1,
                                          df_a = n_a - 1.

    From ``q`` we derive every other quantity used below.

    Output modes
    ------------
    ``"directional"`` (default, what the new code uses).
        Returns ``q`` itself, in [0, 1]. Direction is preserved::

            q -> 0       s_b << s_a   (experiment less variable; improvement)
            q  = 0.5     variances equal
            q -> 1       s_b >> s_a   (experiment more variable; degradation)

        Two-sided rejection bands at ``q < 0.05`` and ``q > 0.95`` give
        a test at alpha = 0.10.

    ``"confidence"`` (legacy "confidence-percent" convention).
        Equivalent to placing F = larger / smaller and reporting
        ``(1 - p_two_sided) * 100`` in [0, 100]::

            out -> 0     variances equal       (do NOT reject H0)
            out -> 100   variances very different (reject H0)

        Direction is LOST. Rejection band at ``out > 95`` (alpha = 0.05).
        Computed directly from ``q`` via::

            p_two_sided = 2 * min(q, 1 - q)
            out         = (1 - p_two_sided) * 100

    ``"pvalue"`` (textbook two-sided p-value).
        Returns ``p = 2 * min(q, 1 - q)`` in [0, 1]. Direction is LOST.
        Rejection at ``p < 0.05``.

    Caveats (apply to every mode)
    -----------------------------
    * Sensitive to non-normality. OMP/OMA after gross-error rejection
      are usually fine; raw ``obsvalue`` for physical fields is not.
    * The samples in this pipeline share observation networks and
      synoptic regimes, so they are not strictly independent. Treat the
      bands as a screening tool, not a publication-grade decision.
    * Without ``--common_sample`` the two samples may cover different
      subsets of reality. The panel title turns red and labels itself
      "approximate".
    * Levels with ``std <= 0`` or ``n < 2`` on either side are returned
      as NaN.
    """
    if mode not in _FTEST_MODES:
        raise ValueError(
            f"unknown ftest mode {mode!r}, expected one of {_FTEST_MODES}"
        )

    out = np.full_like(std_a, np.nan, dtype=float)
    for i in range(len(std_a)):
        if (std_a[i] <= 0 or std_b[i] <= 0
                or n_a[i] < 2 or n_b[i] < 2):
            continue
        F    = (std_b[i] ** 2) / (std_a[i] ** 2)
        df_n = n_b[i] - 1
        df_d = n_a[i] - 1
        q    = stats.f.cdf(F, df_n, df_d)

        if mode == "directional":
            out[i] = q
        elif mode == "confidence":
            p = 2.0 * min(q, 1.0 - q)
            out[i] = (1.0 - p) * 100.0
        else:                                # "pvalue"
            out[i] = 2.0 * min(q, 1.0 - q)
    return out



# =============================================================================
#  PLOTTING - 2-panel "satellite-style" view
# =============================================================================
#
# This module deliberately differs from progps.py: the figure is laid out
# the way a satellite-radiance analyst expects (uniform spacing in y, side
# annotations for F-test confidence and N change, % SD difference panel
# next to the absolute SD panel), while still being usable for any other
# vertical coordinate (pressure, height, generic).
#
# Y-axis behaviour by VCOTYP, fixed centrally so the rest of the plotting
# code does not have to special-case it:
#
#   pressure  -> values shown as-is, axis inverted (lower pressure on top).
#   height    -> values shown as-is, axis NOT inverted (high altitude on top).
#   channel   -> uniform integer index, channel numbers as tick labels;
#                NOT inverted (channel 1 at top, channel N at bottom — same
#                convention as the satellite community uses for AMSU/ATMS/
#                MHS/SSMIS/MWHS2). The font and figure height adapt to the
#                channel count so a 350-channel IASI plot stays legible.
#   generic   -> values shown as-is, NOT inverted.

_VCOORD_PRESSURE_KEYWORDS = ("pressure", "press", "hpa", "pa", "isobar")
_VCOORD_HEIGHT_KEYWORDS   = ("height", "altitude", "metre", "meter", "asl",
                             "above_sea")
_VCOORD_CHANNEL_KEYWORDS  = ("channel", "chan", "wavenumber", "wave_number")


def _classify_vcoord(vcotyp: str) -> str:
    """Return one of 'pressure', 'height', 'channel', 'generic'."""
    if not vcotyp:
        return "generic"
    s = str(vcotyp).lower()
    for kw in _VCOORD_PRESSURE_KEYWORDS:
        if kw in s: return "pressure"
    for kw in _VCOORD_HEIGHT_KEYWORDS:
        if kw in s: return "height"
    for kw in _VCOORD_CHANNEL_KEYWORDS:
        if kw in s: return "channel"
    return "generic"


def _vcoord_axis_label(vkind: str, vcotyp: str) -> str:
    if vkind == "pressure": return f"Pressure ({vcotyp})" if vcotyp else "Pressure"
    if vkind == "height"  : return f"Height ({vcotyp})"   if vcotyp else "Height"
    if vkind == "channel" : return "Channel"
    return f"Vertical coordinate ({vcotyp})" if vcotyp else "Vertical coordinate"


def _channel_tick_settings(n_channels: int) -> dict:
    """
    Pick figure size, font size, tick density given the channel count.
    Tuned so AMSU-A (15) and IASI (~350 active channels) both render
    cleanly without the labels overlapping or the figure looking empty.
    """
    if n_channels <= 30:
        return {"fig_h": 7.5, "label_fs": 9,  "tick_step": 1, "marker_s": 32}
    if n_channels <= 80:
        return {"fig_h": 11.0, "label_fs": 8, "tick_step": 1, "marker_s": 22}
    if n_channels <= 200:
        return {"fig_h": 16.0, "label_fs": 7, "tick_step": 5, "marker_s": 14}
    # IASI / CrIS-FSR / hyper-spectral: ~300+ channels
    return {"fig_h": 22.0, "label_fs": 6, "tick_step": 10, "marker_s": 9}


# Single experiment colour. The original uses one method-vs-method
# comparison so we always have CONTROL + ONE EXPERIMENT per figure.
# Control = black, experiment = Okabe-Ito orange.
_COLOR_EXP_SINGLE = "#E69F00"
# Green for the % difference curve in the right panel (matches the
# COLORS["green"] of the original).
_COLOR_PCT_LINE   = "#2ca02c"


def profile_p3(region, family, id_stn, datestart, dateend, pathwork,
                 flag_criteria, function, vcoord, files_in, names_in,
                 varno, criteria, surface, common_sample=False,
                 id_stn_db=None, ftest_mode="confidence",
                 vcotyp: str = ""):
    """
    Two-panel satellite-style plot, faithful to the original
    plot_satellite_results layout.

    Important
    ---------
    This function expects EXACTLY TWO entries in ``files_in``:
    a control and a single experiment. With more experiments
    the orchestrator calls this function once per (control, exp_i)
    pair so each pairwise figure carries its own side annotations
    cleanly.

    Layout (mirrors the original)
    -----------------------------
    LEFT   : OmP standard deviation per method, dotted lines with
             round markers. Y-axis = uniform index; tick labels =
             channel / vcoord values. Side annotations:
                * right of the data, square marker filled red when
                  F-test confidence > 95 % + the numeric value
                  next to it.
                * left of the data, +/- % change in N (red if
                  positive, blue if negative) inside a white box.
    RIGHT  : Percentage change in OmP SD (exp vs control) as a
             dotted green line, one circle per channel filled with
             the colour of the "winning" method (control colour if
             pct > 0, experiment colour if pct < 0; fully filled
             when the F-test is significant). The numeric % value
             sits next to each marker.

    Y-axis inversion follows VCOTYP: ``pressure`` inverts, everything
    else does not (matches the original list ``{AMSUA, ATMS, MHS,
    SSMIS, MWHS2}`` for non-inverted, which are channel-coordinate
    families).
    """
    if not files_in or len(files_in) < 2:
        # Need at least 1 control + 1 experiment
        return
    if id_stn_db is None:
        id_stn_db = id_stn
    if ftest_mode not in _FTEST_MODES:
        raise ValueError(
            f"unknown ftest_mode {ftest_mode!r}, expected one of {_FTEST_MODES}"
        )

    # Strictly one experiment expected. If more, the orchestrator
    # should have split them into separate calls; refuse to draw
    # rather than produce an unreadable figure.
    if len(files_in) != 2:
        sys.stderr.write(
            f"[plot] profile_p3 expects exactly 1 control + 1 "
            f"experiment, got {len(files_in)} files. The orchestrator "
            f"should split multi-experiment runs into pairwise calls.\n"
        )
        return

    ctl = _read_profile(files_in[0], function, varno, id_stn_db)
    exp = _read_profile(files_in[1], function, varno, id_stn_db)
    if ctl is None or exp is None:
        return

    # Restrict to common levels so panels stay aligned.
    common_lvl = np.intersect1d(ctl["levels"], exp["levels"])
    if len(common_lvl) == 0:
        return
    c_m = np.isin(ctl["levels"], common_lvl)
    e_m = np.isin(exp["levels"], common_lvl)

    levels   = ctl["levels"][c_m]
    n_ctl    = ctl["n"][c_m].astype(float)
    n_exp    = exp["n"][e_m].astype(float)
    std_ctl  = ctl["std"][c_m]
    std_exp  = exp["std"][e_m]
    n_levels = len(levels)
    if n_levels < 1:
        return

    # ---- vcoord type & axis behaviour --------------------------------------
    vkind = _classify_vcoord(vcotyp)
    invert_y = (vkind == "pressure")

    # ---- F-test confidence (always in % for the side annotations) ----------
    ftest_vals = _ftest_pvalue(std_ctl, n_ctl, std_exp, n_exp,
                               mode=ftest_mode)
    # Convert any ftest_mode result to a "confidence %" so the side
    # annotation reads as in the original (0 to 100, threshold 95).
    if ftest_mode == "directional":
        # q in [0,1], significant when q<0.05 or q>0.95
        # -> map to 100 * max(1-q, q) so it ranges 50-100.
        conf_pct = np.where(np.isnan(ftest_vals), np.nan,
                            100.0 * np.maximum(ftest_vals,
                                               1.0 - ftest_vals))
    elif ftest_mode == "confidence":
        conf_pct = ftest_vals.copy()
    else:                                    # "pvalue"
        conf_pct = np.where(np.isnan(ftest_vals), np.nan,
                            100.0 * (1.0 - ftest_vals))

    # ---- % change in N (experiment vs control) -----------------------------
    with np.errstate(divide="ignore", invalid="ignore"):
        pct_n = np.where(n_ctl > 0,
                         (n_exp - n_ctl) / n_ctl * 100.0,
                         np.nan)

    # ---- % change in OmP SD ------------------------------------------------
    with np.errstate(divide="ignore", invalid="ignore"):
        pct_sd = np.where(std_ctl > 0,
                          (std_exp - std_ctl) / std_ctl * 100.0,
                          np.nan)

    # ---- figure size ------------------------------------------------------
    fig_height = max(8.0, len(levels) * 0.15)
    fig_height = min(fig_height, 36.0)        # cap so 1000-channel plots stay reasonable
    fig, (ax1, ax2) = plt.subplots(
        1, 2, figsize=(14, fig_height),
        sharey=True, constrained_layout=True,
    )

    y_pos = np.arange(n_levels)

    # ============================================================
    # LEFT PANEL — SD per method
    # ============================================================
    name_ctl = names_in[0]
    name_exp = names_in[1]
    ax1.plot(std_ctl, y_pos, marker="o", linestyle=":", linewidth=2,
             color=_COLOR_CTL, label=name_ctl)
    ax1.plot(std_exp, y_pos, marker="o", linestyle=":", linewidth=2,
             color=_COLOR_EXP_SINGLE, label=name_exp)

    ax1.set_yticks(y_pos)
    if vkind == "channel":
        ax1.set_yticklabels([str(int(v)) for v in levels])
    else:
        ax1.set_yticklabels([f"{v:g}" for v in levels])

    # Tick density for very tall plots
    if n_levels > 30:
        step = max(1, n_levels // 30)
        for i, lbl in enumerate(ax1.get_yticklabels()):
            if i % step != 0:
                lbl.set_visible(False)

    # X range for annotation placement (same logic as the original)
    finite = np.concatenate([std_ctl[np.isfinite(std_ctl)],
                             std_exp[np.isfinite(std_exp)]])
    if finite.size > 0:
        x_min, x_max = float(np.min(finite)), float(np.max(finite))
    else:
        x_min, x_max = 0.0, 1.0
    x_range = x_max - x_min if x_max > x_min else 0.1
    x_annot_right_text   = x_max + 0.08 * x_range
    x_annot_right_marker = x_max + 0.04 * x_range
    x_annot_left         = x_min - 0.05 * x_range

    # Side annotations — exact look of the original
    for i, y in enumerate(y_pos):
        c = conf_pct[i]
        if not np.isnan(c):
            face = "red" if c > 95.0 else "white"
            ax1.scatter(x_annot_right_marker, y, s=80, marker="s",
                        facecolor=face, edgecolor="black", clip_on=False)
            ax1.text(x_annot_right_text, y, f"{c:.2f}%",
                     va="center", fontsize=7, weight="bold",
                     clip_on=False)
        v_n = pct_n[i]
        if not np.isnan(v_n):
            col = "red" if v_n > 0 else "blue"
            ax1.text(x_annot_left, y, f"{v_n:+.2f}%",
                     ha="right", va="center", color=col,
                     fontsize=8, weight="bold",
                     bbox=dict(facecolor="white", edgecolor="none",
                               alpha=0.7),
                     clip_on=False)

    ax1.set_xlim(x_min - 0.2 * x_range, x_max + 0.2 * x_range)
    ax1.set_xlabel("OmP Standard Deviation")
    ax1.set_ylabel("Channel" if vkind == "channel"
                   else _vcoord_axis_label(vkind, vcotyp))
    ax1.set_title(
        f"OmP Standard Deviation per Method — "
        f"{family} (varno {varno})"
    )
    if invert_y:
        ax1.invert_yaxis()
    ax1.grid(True, ls="--", alpha=0.5)
    ax1.legend(loc="lower right", fontsize=9)

    # ============================================================
    # RIGHT PANEL — % change of OmP SD
    # ============================================================
    ax2.plot(pct_sd, y_pos, marker="", linestyle=":", linewidth=2,
             color=_COLOR_PCT_LINE)
    ax2.axvline(0, color="gray", linestyle="--")

    ax2.set_yticks(y_pos)
    if vkind == "channel":
        ax2.set_yticklabels([str(int(v)) for v in levels])
    else:
        ax2.set_yticklabels([f"{v:g}" for v in levels])
    if n_levels > 30:
        step = max(1, n_levels // 30)
        for i, lbl in enumerate(ax2.get_yticklabels()):
            if i % step != 0:
                lbl.set_visible(False)

    # Marker + text per channel, faithful to the original
    TEXT_NEAR_MARKER_OFFSET = 0.01
    for i, y in enumerate(y_pos):
        v = pct_sd[i]
        if np.isnan(v):
            continue
        # "Winning" method colour
        if v < 0:
            marker_color = _COLOR_EXP_SINGLE
        else:
            marker_color = _COLOR_CTL
        # Filled when F-test confidence > 95 %
        c = conf_pct[i]
        face = marker_color if (not np.isnan(c) and c > 95.0) else "white"

        ax2.scatter(v, y, s=80, marker="o", facecolor=face,
                    edgecolor=marker_color, zorder=3)
        ax2.text(v + TEXT_NEAR_MARKER_OFFSET, y,
                 f"{v:+.2f}%", ha="left", va="center",
                 fontsize=8, weight="bold")

    ax2.set_xlabel(
        f"Percentage Change of OmP SD ({name_exp} vs {name_ctl})"
    )
    # Some breathing room on x so the +xx.xx% labels don't get clipped
    finite_pct = pct_sd[np.isfinite(pct_sd)]
    if finite_pct.size > 0:
        p_min = float(np.min(finite_pct))
        p_max = float(np.max(finite_pct))
        p_abs = max(abs(p_min), abs(p_max), 1.0)
        ax2.set_xlim(-p_abs * 1.4, p_abs * 1.4)
    ax2.set_title(
        f"Percentage Difference of OmP SD — "
        f"{family} (varno {varno})"
    )
    if invert_y:
        ax2.invert_yaxis()
    ax2.grid(True, ls="--", alpha=0.5)

    # ============================================================
    # Save
    # ============================================================
    os.makedirs(os.path.join(pathwork, family), exist_ok=True)
    safe_names = f"{name_ctl}_vs_{name_exp}".replace(" ", "").replace("/", "")
    safe_crit  = str(criteria).replace(" ", "_")
    cs_filename_tag    = "_commonSample" if common_sample else ""
    ftest_filename_tag = "" if ftest_mode == "directional" else f"_F{ftest_mode}"
    filename = (
        f"{function}_{family}_{safe_names}_{region}_{surface}_"
        f"{id_stn}_{varno}_{vcoord}_{datestart}_{dateend}_{safe_crit}"
        f"{cs_filename_tag}{ftest_filename_tag}.png"
    )
    out_path = os.path.join(pathwork, family, filename)
    plt.savefig(out_path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"[plot] saved: {filename}")



# =============================================================================
#  HTML VIEWER  (delegated to pikobs.web.viewer)
# =============================================================================

# These per-key labels are the only progps-specific bit. The rest of the
# viewer logic (cascading dropdowns, flip button, layout) lives in
# pikobs.web.viewer.generate_web and is shared by every module.
_PROGPS_VIEWER_KEYS = [
    "family", "region", "surface", "id_stn",
    "varno", "vcoord", "function", "criteria",
    "experiment",
]
_PROGPS_VALUE_LABELS = {
    "surface": {"overworld": "World",
                "oversea":   "Sea",
                "overland":  "Land"},
}


def generate_web(data_list_plot, pathwork, namesin, datestart, dateend,
                 output_filename="pikobs_profile_viewer.html",
                 common_sample=False, ftest_mode="directional"):
    """
    progps2 adapter for the generic viewer module.

    The pairwise comparison scheme (one figure per control + experiment)
    means each ``data_list_plot`` entry produces N figures where N is
    the number of experiments. We emit one viewer record per figure,
    keyed by ``experiment``.
    """
    try:
        from pikobs.web.viewer import generate_web as _viewer
    except ImportError:
        import importlib.util, pathlib
        here   = pathlib.Path(__file__).resolve().parent
        spec   = importlib.util.spec_from_file_location(
            "pikobs_viewer_local", here / "viewer.py",
        )
        if spec is None or spec.loader is None:
            raise
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _viewer = module.generate_web

    def _clean(n):
        return str(n).replace(" ", "").replace("/", "").replace("\\", "")

    cs_filename_tag    = "_commonSample" if common_sample else ""
    ftest_filename_tag = "" if ftest_mode == "directional" else f"_F{ftest_mode}"

    if len(namesin) < 2:
        sys.stderr.write(
            "[viewer] progps2 needs at least 1 control + 1 experiment; "
            "skipping viewer.\n"
        )
        return None

    name_ctl = _clean(namesin[0])

    items = []
    for entry in data_list_plot:
        safe_crit = str(entry["criteria"]).replace(" ", "_")
        for exp_name in namesin[1:]:
            safe_exp_name = _clean(exp_name)
            safe_pair = f"{name_ctl}_vs_{safe_exp_name}"
            filename = (
                f"{entry['function']}_{entry['family']}_{safe_pair}_"
                f"{entry['region']}_{entry['surface']}_{entry['id_stn']}_"
                f"{entry['varno']}_{entry['vcoord']}_{datestart}_{dateend}_"
                f"{safe_crit}{cs_filename_tag}{ftest_filename_tag}.png"
            )
            rec = {k: entry[k] for k in _PROGPS_VIEWER_KEYS if k != "experiment"}
            rec["experiment"] = str(exp_name)
            rec["filename"]   = filename
            items.append(rec)

    cs_label  = " [common_sample]" if common_sample else ""
    run_label = (
        f"control: {namesin[0]} | experiments: " + ", ".join(namesin[1:])
    ) + cs_label
    subtitle = f"{run_label}  |  {datestart} → {dateend}  |  ftest={ftest_mode}"

    return _viewer(
        items=items,
        keys=_PROGPS_VIEWER_KEYS,
        output_path=os.path.join(pathwork, output_filename),
        title="Pikobs Profile Analysis Viewer (satellite-style)",
        subtitle=subtitle,
        image_subdir_key="family",
        value_labels=_PROGPS_VALUE_LABELS,
        issues_url="https://gitlab.science.gc.ca/dlo001/Pikobs",
    )


# =============================================================================
#  MAIN ORCHESTRATOR
# =============================================================================

def make_scatter(files_in, names_in, pathwork, datestart, dateend, regions,
                 families, flag_criteria, fonctions, varnos, id_stn, channel,
                 n_cpu, surface, common_sample,
                 ftest_mode="directional"):

    if ftest_mode not in _FTEST_MODES:
        sys.exit(
            f"ERROR: --ftest_mode must be one of {_FTEST_MODES}, "
            f"got {ftest_mode!r}"
        )

    print("=" * 78)
    print(f"[env] python      : {sys.executable}")
    print(f"[env] PYTHONPATH  : {os.environ.get('PYTHONPATH', '')}")
    print(f"[env] PYTHONNOUSERSITE: {os.environ.get('PYTHONNOUSERSITE', '0')}")
    print(f"[cfg] ftest_mode  : {ftest_mode}")
    print("=" * 78)

    _clean_pathwork_preserving_cache(pathwork)
    for family in families:
        os.makedirs(f"{pathwork}/{family}", exist_ok=True)

    data_list = create_data_list(
        datestart, dateend, families, files_in, names_in, pathwork,
        fonctions, flag_criteria, regions, varnos, surface, common_sample,
    )

    # Validate inputs are real SQLite databases. If not, abort with a
    # clear pointer to the conversion script.
    all_inputs = sorted({f for d in data_list for f in d["files_in"]})
    _validate_inputs_are_sqlite(all_inputs)

    tasks_by_db: dict = defaultdict(list)
    for data_ in data_list:
        for f_in, db_new in zip(data_["files_in"], data_["dbs_new"]):
            tasks_by_db[db_new].append((
                data_["family"], db_new, f_in, data_["files_in"],
                data_["region"], data_["flag_criteria"], data_["function"],
                data_["varnos"], channel, id_stn, data_["surface"],
                common_sample,
            ))

    def _run_db_group(task_list):
        for t in task_list:
            create_and_populate_moyenne_table(*t)

    all_groups = list(tasks_by_db.values())
    t0 = time.time()
    if n_cpu == 1:
        print(
            f"[aggr] serial: {sum(len(g) for g in all_groups)} tasks "
            f"in {len(all_groups)} output files"
        )
        for grp in all_groups:
            _run_db_group(grp)
    else:
        print(
            f"[aggr] parallel: {len(all_groups)} output files -> "
            f"{n_cpu} workers"
        )
        with Client(processes=True, threads_per_worker=1,
                    n_workers=n_cpu, silence_logs=40):
            dask.compute(*[
                dask.delayed(_run_db_group)(grp) for grp in all_groups
            ])
    print(f"[aggr] total time: {time.time() - t0:.1f}s")

    data_list_plot = create_data_list_plot(
        datestart, dateend, families, names_in, pathwork,
        fonctions, flag_criteria, regions, id_stn, channel, surface,
    )

    # Look up VCOTYP per family. pikobs.family returns
    # (FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP). Cache per family
    # so the lookup runs once even when many tasks share a family.
    vcotyp_by_family = {}
    for fam in families:
        try:
            fam_info = pikobs.family(fam)
            vcotyp_by_family[fam] = fam_info[5] if len(fam_info) > 5 else ""
        except Exception:
            vcotyp_by_family[fam] = ""

    t0 = time.time()
    # Build pairwise tasks: one figure per (control, exp_i) pair.
    # ``profile_p3`` is strict about receiving exactly 2 entries
    # (control + one experiment) because each figure carries side
    # annotations that only make sense for a single comparison.
    plot_tasks = []
    for d in data_list_plot:
        files = d["files_in"]
        if len(files) < 2:
            continue
        ctl_file = files[0]
        for k, exp_file in enumerate(files[1:], start=1):
            pair_files = [ctl_file, exp_file]
            pair_names = [names_in[0], names_in[k]]
            plot_tasks.append((
                d["region"], d["family"], d["id_stn"],
                datestart, dateend, pathwork, flag_criteria,
                d["function"], d["vcoord"],
                pair_files, pair_names,
                d["varno"], d["criteria"], d["surface"],
                common_sample, d.get("id_stn_db", d["id_stn"]),
                ftest_mode, vcotyp_by_family.get(d["family"], ""),
            ))

    if n_cpu == 1:
        print(f"[plots] serial: {len(plot_tasks)} figures")
        for t in plot_tasks:
            profile_p3(*t)
    else:
        print(f"[plots] parallel: {len(plot_tasks)} figures with {n_cpu} workers")
        time.sleep(2)
        with Client(processes=True, threads_per_worker=1,
                    n_workers=n_cpu, silence_logs=40):
            dask.compute(*[
                dask.delayed(profile_p3)(*t) for t in plot_tasks
            ])
    print(f"[plots] total time: {time.time() - t0:.1f}s")
    print(f"[main] output directory: {pathwork}")

    generate_web(
        data_list_plot, pathwork, names_in, datestart, dateend,
        common_sample=common_sample, ftest_mode=ftest_mode,
    )


# =============================================================================
#  CLI
# =============================================================================

def arg_call():
    parser = argparse.ArgumentParser(
        description="Pikobs - vertical-profile diagnostic plots from "
                    "converted SQLite observation databases.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Note: BURP -> SQLite conversion is performed by "
            "'pikobs.pikobsburp2db'. Run that script first."
        ),
    )
    parser.add_argument("--path_control_files",    default="undefined")
    parser.add_argument("--control_name",          default="undefined")
    parser.add_argument("--path_experience_files", nargs="+", default=[])
    parser.add_argument("--experience_name",       nargs="+", default=[])
    parser.add_argument("--pathwork",              default="undefined")
    parser.add_argument("--datestart",             default="undefined")
    parser.add_argument("--dateend",               default="undefined")
    parser.add_argument("--region",         nargs="+", default=[])
    parser.add_argument("--family",         nargs="+", default=[])
    parser.add_argument("--flags_criteria", nargs="+", default=[])
    parser.add_argument("--fonction",       nargs="+", default=[])
    parser.add_argument("--varnos",         nargs="+", default=[])
    parser.add_argument("--id_stn",  default="all")
    parser.add_argument("--channel", default="all")
    parser.add_argument("--n_cpus",  default=1, type=int)
    parser.add_argument(
        "--surface", default="world",
        choices=["world", "sea", "land"],
    )
    parser.add_argument("--common_sample", action="store_true")
    parser.add_argument(
        "--ftest_mode", default="directional",
        choices=list(_FTEST_MODES),
        help=(
            "F-test convention shown in panel 3.\n"
            "  directional (default) -> q = cdf(F), preserves sign\n"
            "  confidence            -> (1-p)*100 in [0, 100], legacy\n"
            "  pvalue                -> two-sided p-value in [0, 1]"
        ),
    )

    args = parser.parse_args()

    if len(args.path_experience_files) != len(args.experience_name):
        sys.exit(
            f"ERROR: {len(args.path_experience_files)} experiment paths but "
            f"{len(args.experience_name)} experiment names."
        )

    required = [
        ("pathwork",  "--pathwork"),
        ("datestart", "--datestart"),
        ("dateend",   "--dateend"),
    ]
    for attr, flag in required:
        if getattr(args, attr) == "undefined":
            sys.exit(f"ERROR: {flag} is required")

    for lst, flag in [
        (args.region,         "--region"),
        (args.family,         "--family"),
        (args.flags_criteria, "--flags_criteria"),
        (args.fonction,       "--fonction"),
    ]:
        if not lst:
            sys.exit(f"ERROR: {flag} is required")

    if args.path_control_files == "undefined":
        files_in = args.path_experience_files
        names_in = args.experience_name
    else:
        files_in = [args.path_control_files] + args.path_experience_files
        names_in = [args.control_name]       + args.experience_name

    for n, f in zip(names_in, files_in):
        print(f"  {n:20s}  ->  {f}")

    sys.exit(make_scatter(
        files_in, names_in, args.pathwork,
        args.datestart, args.dateend,
        args.region, args.family,
        args.flags_criteria, args.fonction,
        args.varnos, args.id_stn, args.channel,
        args.n_cpus, args.surface, args.common_sample,
        ftest_mode=args.ftest_mode,
    ))
