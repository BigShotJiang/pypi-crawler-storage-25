#!/usr/bin/python3
"""
===========================================
Verification of Radiance (VDEDR Diagnostic)
===========================================

The **Pikobs VDEDR Suite** is a diagnostic tool designed to evaluate the effectiveness of bias corrections and highlight systematic differences in radiance data across experiments or datasets. By analyzing residual and raw biases, it provides essential insights into the accuracy and consistency of the radiance verification system.

Core Visualization: Bias and Error Analysis
-------------------------------------------

This module produces three key plots to analyze biases and errors across datasets. The **radiance channels** serve as the y-axis in all plots, facilitating direct, channel-wise comparisons.

**1. Bias Plot**

Compares the **residual bias** (the difference between the average OMP values of the two datasets) and the **raw bias** (the difference between the bias-corrected OMP values). This plot highlights variations in bias measurements to aid in detecting dataset performance differences.

.. image:: _static/vdedrbias.png
   :align: center
   :alt: Bias Plot
   :width: 800px

**2. Delta Error Plot (OMP)**

Shows the percentage difference in the Standard Deviation of OMP (**% sigma**) and the number of observations (**% Nobs**) between the two datasets. This evaluates relative changes in measurement errors and observation counts.

.. image:: _static/vdedromp.png
   :align: center
   :alt: Delta Error Plot (OMP)
   :width: 800px

**3. Delta Error Plot (OMA)**

Similar to the OMP plot, but focuses on **OMA** (Observation minus Analysis). It assesses relative changes in OMA errors and observation counts, helping identify patterns specific to analysis deviations.

.. image:: _static/vdedroma.png
   :align: center
   :alt: Delta Error Plot (OMA)
   :width: 800px


Interactive Web Environment
---------------------------

Beyond static plots, Pikobs automatically generates a **Smart Web Viewer**. This tool is designed for rapid multi-dimensional and comparative analysis:

* **Dynamic Filtering:** The interface only displays valid combinations of metrics (OMP Bias, OMP Rel, OMA Rel), satellite, channel, and region available in your dataset.
* **Flip-Flop Mode:** Allows instant toggling between two different plots (e.g., Control vs Experiment) to detect subtle changes without losing visual focus.
* **Access:** The generated interactive viewer is linked directly here:

🔗 **Explore the Viewer:** `Interactive Web Viewer <https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobsvdedr/pikobs_vdedr_viewer.html>`_


HPC Execution & Real-Time Monitoring
------------------------------------

To maintain system stability on Environment and Climate Change Canada (ECCC) clusters, always execute diagnostic tasks using a dedicated compute node.

**1. Initialize Interactive Session:**

.. code-block:: bash

    qsub -I -X -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb -l place=scatter -l walltime=6:0:0

**2. Generate Diagnostics Command:**

.. code-block:: bash

    python -c 'import pikobs; pikobs.vdedr.arg_call()' \\
        --path_control_files      /home/dlo001/sites8/Data_pikobs/monitoring0/ \\
        --control_name            g0 \\
        --path_experience_files   a/home/dlo001/sites8/Data_pikobs/monitoring/ \\
        --experience_name         g2 \\
        --pathwork                /your/custom/output/path \\
        --datestart               2026020100 \\
        --dateend                 2026020600 \\
        --region                  Monde Canada \\
        --family                  to_amsua_allsky atms_allsky \\
        --flags_criteria          iclear_sky cloudy_sky clear_cloudy_sky \\
        --id_stn                  all \\
        --n_cpu                   40

**3. Expected Shell Output (Batch Monitoring):**

When executing the command above, you will see the parallel processing progress in your terminal:

.. code-block:: text

    [PIKOBS] Initializing VDEDR Verification Engine...
    [INFO] Detected 40 CPUs for parallel processing.
    [DB] Connecting to Control: g0
    [DB] Connecting to Experience: g2
    [PARALLEL] Computing Bias and Delta Errors for family: to_amsua_allsky...
    [PARALLEL] Generating plots for METOP-1...
    [WEB] Compiling interactive web viewer data...
    ✅ Plot successfully saved: /your/custom/output/path/to_amsua_allsky/omp_bias_to_amsua_allsky_METOP-1_g0-g2_Monde_assimilee.png
    ✅ Advanced Web viewer successfully created at: /your/custom/output/path/pikobs_vdedr_viewer.html
    [DONE] All verifications completed successfully.


Support and Issues
------------------

Pikobs is maintained for the ECCC community. For bug reports, feature requests, or technical issues, please use the official GitLab repository:

🔗 **GitLab Issues:** `https://gitlab.science.gc.ca/dlo001/Pikobs <https://gitlab.science.gc.ca/dlo001/Pikobs>`_

----

*Document generated automatically for the Pikobs Atmospheric Science Project.*

"""
import sqlite3
import pikobs
import re
import os
from  dask.distributed import Client
import numpy as np
import sqlite3
import os
import re
import sqlite3
from  datetime import datetime, timedelta
import os
import sqlite3
import re

def create_table_if_not_exists(cursor):
    """
    """
    query = """
        CREATE TABLE IF NOT EXISTS serie_vdedr(
            DATE INTEGER,
            vcoord FLOAT,
            Ntot FLOAT,
            AvgOMP FLOAT,
            AvgOMA FLOAT,
            StdOMP FLOAT,
            StdOMA FLOAT,
            varno INTEGER,
            AvgBCOR INTEGER,
            id_stn TEXT
        );
    """
    cursor.execute(query)

import sqlite3
import os
import re
import pikobs


def create_serie_cardio(family, 
                        new_db_filename, 
                        existing_db_filename,
                        region_selected,
                        selected_flags, 
                        id_stn,
                        varno):
    """
    Create and populate a new SQLite database with processed data from an existing database.

    Args:
        family (str): Data family name.
        new_db_filename (str): Output SQLite database file name.
        existing_db_filename (str): Input SQLite database file name.
        region_selected (str): Region selection criteria.
        selected_flags (str): Flag filtering criteria.
        id_stn (str): Station ID or 'all' for all stations.
        varno (int): Variable number for filtering.

    Returns:
        None
    """
    # Extract date from the input database filename
    date_pattern = r'(\d{10})'
    date_match = re.search(date_pattern, existing_db_filename)
    date = date_match.group(1) if date_match else None
    if not date:
        print(f"Error: No valid date found in filename {existing_db_filename}.")
        return

    # Load family and region metadata
    FAM, VCOORD, VCOCRIT, STATB, VCOORD, VCOTYP = pikobs.family(family)
    LAT1, LAT2, LON1, LON2 = pikobs.regions(region_selected)
    LATLONCRIT = pikobs.generate_latlon_criteria(LAT1, LAT2, LON1, LON2)
    flag_criteria = pikobs.flag_criteria(selected_flags)
    criteria_id_stn = f"AND id_stn='{id_stn}'" if id_stn != 'all' else ''
    import random

    # Generar un número entero de 16 bits sin signo
    num_16bit_unsigned = random.randint(0, 2**16 - 1)
    filename=f'{os.path.basename(existing_db_filename)}?mode=memory&cache=shared'
    filename=f"file::memory:?cache=shared"

  


    # Open connection to the new database
    with sqlite3.connect(filename, uri=True, check_same_thread=False) as new_db_conn: 
    #conn_pathfileout = sqlite3.connect(pathfileout, uri=True, isolation_level=None, timeout=9999)


        new_db_cursor = new_db_conn.cursor()

        # Apply performance optimizations
        new_db_cursor.execute("PRAGMA journal_mode = WAL;")
        new_db_cursor.execute("PRAGMA synchronous = OFF;")
        new_db_cursor.execute("PRAGMA cache_size = -100000;")  # 100 MB

        # Create table if it does not exist
        create_table_if_not_exists(new_db_cursor)

        # Load SQLite extension
        extension_dir = os.path.join(os.path.dirname(pikobs.__file__), "extension/libudfsqlite-shared.so")
        new_db_conn.enable_load_extension(True)
        new_db_conn.execute(f"SELECT load_extension('{extension_dir}')")

        # Attach the existing database
        try:
            new_db_cursor.execute(f"ATTACH DATABASE '{existing_db_filename}' AS db;")
        except sqlite3.Error as e:
            print(f"Error attaching database: {e}")
            return

        # Execute the SQL query within a transaction
        try:
            new_db_cursor.execute("BEGIN TRANSACTION;")
            query = f"""
                INSERT INTO serie_vdedr(
                    DATE, vcoord, Ntot, AvgOMP, AvgOMA, StdOMP, StdOMA, AvgBCOR, varno, id_stn
                )
                SELECT 
                    {date},
                    vcoord,
                    COUNT(*) AS Ntot,
                    SUM(omp * 1.0) / COUNT(*) AS AvgOMP,
                    SUM(oma * 1.0) / COUNT(*) AS AvgOMA,
                    STDDEV(omp) AS StdOMP,
                    STDDEV(oma) AS StdOMA,
                    AVG(BIAS_CORR) AS AvgBCOR,
                    varno,
                    id_stn
                FROM
                    db.header
                NATURAL JOIN 
                    db.data
                WHERE 
                    VARNO = {int(varno)}
                    AND obsvalue IS NOT NULL
                    {criteria_id_stn}
                    {flag_criteria}
                    {LATLONCRIT}
                    {VCOCRIT}
                GROUP BY 
                    vcoord, id_stn;
            """
            
            new_db_cursor.execute(query)
            new_db_conn.commit()  # Commit transaction
        except sqlite3.Error as e:
            new_db_conn.rollback()  # Rollback transaction on error
            print(f"Error executing SQL query: {e} {filename} ")
        try:
        
            combine(new_db_filename, filename)
        except sqlite3.Error as error:
            print(f"Error while creating a single sqlite file:  {os.path.basename(filename)}", error)

def combine(pathfileout, filememory):

    """ Creating a single sqlite file from multiple sqlite files
 
    args:
    ----------------

     pathfileout   : output averaging  sqlite file 
     filememory    : name of the sqlite file in memory to copy
   
    output:
    ----------------

    Nothing
     A sqlite file is made with all averaged volume scans
   
   """

    # write in output averaging  sqlite file
    conn_pathfileout = sqlite3.connect(pathfileout, uri=True, isolation_level=None, timeout=9999)

    conn_pathfileout.execute("""PRAGMA journal_mode=OFF;""")

    # off the journal
    create_table_if_not_exists( conn_pathfileout)
    conn_pathfileout.execute("""PRAGMA journal_mode=OFF;""")
    # SQLite continues without syncing as soon as it has handed data off to the operating system
    conn_pathfileout.execute("""PRAGMA synchronous=OFF;""")
    # Wait to read and write until the next process finishes
    # attach the sqlite file in memory for one PPI
    create_table_if_not_exists(conn_pathfileout)

    conn_pathfileout.execute("ATTACH DATABASE ? AS this_avg_db;", (filememory,))
    order_sql = """ INSERT INTO serie_vdedr(
                    DATE, vcoord, Ntot, AvgOMP, AvgOMA, StdOMP, StdOMA, AvgBCOR, varno, id_stn
                )
                    SELECT
                    DATE, vcoord, Ntot, AvgOMP, AvgOMA, StdOMP, StdOMA, AvgBCOR, varno, id_stn
                    FROM  this_avg_db.serie_vdedr"""
    conn_pathfileout.execute(order_sql) 

    conn_pathfileout.commit()
    conn_pathfileout.execute(""" DETACH DATABASE this_avg_db """)

def create_data_list_cardio(datestart1, 
                            dateend1,
                            families,
                            pathin, 
                            names,
                            pathwork,
                            flag_criterias,
                            regions,
                            id_stn):
    """
    Generate a list of dictionaries containing metadata for processing files 
    within a specified date range and conditions.

    Args:
        datestart1 (str): Start date in the format 'YYYYMMDDHH'.
        dateend1 (str): End date in the format 'YYYYMMDDHH'.
        families (list): List of family names.
        pathin (list): List of input directory paths corresponding to family names.
        names (list): List of names associated with each family.
        pathwork (str): Path for output files.
        flag_criteria (str): Criteria for filtering flags.
        regions (list): List of regions to process.
        id_stn (list): List of station IDs to include, or 'all' for all stations.

    Returns:
        list: A list of dictionaries containing metadata for processing.
    """
    data_list_cardio = []
    # Iterate over input paths and corresponding family names
    for path, name in zip(pathin, names):
     for flag_criteria in flag_criterias:
        for region in regions:
            for family in families:
                # Convert start and end dates to datetime objects
                datestart = datetime.strptime(datestart1, '%Y%m%d%H')
                dateend = datetime.strptime(dateend1, '%Y%m%d%H')
                current_date = datestart
                delta = timedelta(hours=6)

                # Retrieve family metadata
                FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)
                element_array = np.array([float(x) for x in element.split(',')])

                # Loop over variables in the family
                for varno in element_array:
                    # Loop through the date range in 6-hour intervals
                    while current_date <= dateend:
                        formatted_date = current_date.strftime('%Y%m%d%H')
                        filename = f'{formatted_date}_{family}'
                        file_path_name = f'{path}/{filename}'

                        # Connect to the database (ensures file existence)
                        try:
                            conn = sqlite3.connect(file_path_name)
                            conn.close()
                        except sqlite3.Error:
                            print(f"Warning: Unable to open file {file_path_name}. Skipping.")
                            current_date += delta
                            continue

                        # Generate data dictionaries
                        channel = 'all'
                        for station in id_stn:
                            data_dict = {
                                'family': family,
                                'filein': file_path_name,
                                'db_new': f'{pathwork}/{family}/vdedr_{region}_{name}_{datestart1}_{dateend1}_{flag_criteria}_{family}.db',
                                'region': region,
                                'flag_criteria': flag_criteria,
                                'varno': varno,
                                'vcoord': channel,
                                'id_stn': station
                            }
                            data_list_cardio.append(data_dict)

                        # Increment the date by 6 hours
                        current_date += delta

    return data_list_cardio

def create_data_list_plot(datestart1,
                          dateend1, 
                          families, 
                          pathwork, 
                          flag_criterias, 
                          regions, 
                          id_s,  
                          channels, 
                          files_in,
                          names_in): 
    """
    Generate a list of dictionaries containing metadata for plotting based on input parameters.

    Args:
        datestart1 (str): Start date in the format 'YYYYMMDDHH'.
        dateend1 (str): End date in the format 'YYYYMMDDHH'.
        families (list): List of family names.
        pathwork (str): Path to the working directory.
        flag_criteria (str): Criteria for filtering flags.
        regions (list): List of selected regions for filtering data.
        id_stns (list): List of station IDs or 'all' to include all stations.
        channels (list): List of channels for processing.
        files_in (list): List of input file names.
        names_in (list): List of names associated with databases (e.g., control, experimental).

    Returns:
        list: A list of dictionaries containing metadata for plotting.
    """
    data_list_plot = []

    # Loop over regions
    for region in regions:
        # Loop over familie
      for flag_criteria in flag_criterias:
        for family in families:
            # Define database paths for control and experimental groups
            filedb_control = f'{pathwork}/{family}/vdedr_{region}_{names_in[0]}_{datestart1}_{dateend1}_{flag_criteria}_{family}.db'
            filedb_experience = f'{pathwork}/{family}/vdedr_{region}_{names_in[1]}_{datestart1}_{dateend1}_{flag_criteria}_{family}.db'
            # Connect to the control database
            conn = sqlite3.connect(filedb_control)
            cursor = conn.cursor()
            # Determine station IDs and variables based on input criteria
            if id_s[0] == 'all':

                # Fetch all distinct station IDs and variables
                query = "SELECT DISTINCT id_stn, varno FROM serie_vdedr;"
                cursor.execute(query)
                id_stns = cursor.fetchall()
            else:
                # Fetch specific station IDs and variables
                stn_str = f"({', '.join(repr(stn) for stn in id_stns)})"
                query = f"SELECT DISTINCT id_stn, varno FROM serie_vdedr WHERE id_stn IN {stn_str};"
                cursor.execute(query)
                id_stns = cursor.fetchall()

            # Generate data dictionaries for each station ID and variable
            for id_stn, varno in id_stns:
                data_dict_plot = {
                    'files_in': [filedb_control, filedb_experience],
                    'names_in': names_in,
                    'id_stn': id_stn,
                    'family': family,
                    'region': region,
                    'varno': varno,
                    'flag_criteria': flag_criteria
                }
                data_list_plot.append(data_dict_plot)

            # Close the database connection
            conn.close()

    return data_list_plot

import os
import json
import os
import json

def generate_web_viewer(pathwork, data_list, output_filename="pikobs_vdedr_viewer.html"):
    # Convert to list for JSON serialization safety
    json_data = json.dumps(list(data_list))

    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pikobs Vdedr Viewer</title>
<style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background-color: #f4f7f6; color: #333; display: flex; flex-direction: column; min-height: 100vh; }
    .header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; }
    .container { max-width: 1200px; margin: 20px auto; padding: 0 20px; flex: 1; width: 100%; box-sizing: border-box; }
    .controls { display: flex; flex-wrap: wrap; gap: 20px; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 20px; justify-content: center; align-items: flex-end; }
    .control-group { display: flex; flex-direction: column; }
    label { font-weight: bold; margin-bottom: 5px; font-size: 13px; color: #34495e; text-transform: uppercase; letter-spacing: 0.5px; }
    select { padding: 10px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px; min-width: 160px; background-color: #fff; cursor: pointer; transition: border-color 0.3s; }
    select:focus { outline: none; border-color: #3498db; box-shadow: 0 0 5px rgba(52,152,219,0.3); }
    .btn-flipflop { background-color: #3498db; color: white; border: none; padding: 10px 20px; font-size: 14px; font-weight: bold; border-radius: 4px; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: background-color 0.3s, transform 0.1s; height: 40px; }
    .btn-flipflop:hover { background-color: #2980b9; }
    .btn-flipflop:active { transform: scale(0.96); }
    .btn-flipflop:disabled { background-color: #95a5a6; cursor: not-allowed; }
    .btn-flipflop.active-flip { background-color: #e67e22; }
    .image-container { text-align: center; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); min-height: 500px; display: flex; align-items: center; justify-content: center; flex-direction: column; position: relative; }
    img { max-width: 100%; height: auto; border-radius: 4px; display: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-top: 15px; }
    .error-msg { color: #e74c3c; font-weight: bold; font-size: 18px; display: none; flex-direction: column; align-items: center; gap: 10px; margin-top: 30px; }
    .path-display { margin-top: 15px; font-family: monospace; color: #7f8c8d; font-size: 13px; background: #ecf0f1; padding: 10px; border-radius: 4px; width: 100%; box-sizing: border-box; }
    .badge { background: #2ecc71; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; position: absolute; top: 20px; right: 20px; display: none; }
    .badge.previous { background: #e67e22; }
    #chart-title { margin: 0 0 10px 0; color: #2c3e50; font-size: 1.4em; }
    .footer { text-align: center; padding: 20px; color: #7f8c8d; font-size: 14px; background-color: #ecf0f1; margin-top: auto; }
    .footer a { color: #3498db; text-decoration: none; font-weight: bold; }
    .footer a:hover { text-decoration: underline; }
</style>
</head>
<body>

<div class="header">
    <h1>Pikobs Vdedr Viewer</h1>
    <p>Smart selection: Dropdowns automatically filter to show only valid data combinations.</p>
</div>

<div class="container">
    <div class="controls">
        <div class="control-group">
            <label for="sel_name">1. Metric</label>
            <select id="sel_name" onchange="updateImage()">
                <option value="omp_bias">OMP Bias</option>
                <option value="omp_rel">OMP Rel</option>
                <option value="oma_rel">OMA Rel</option>
            </select>
        </div>
        <div class="control-group">
            <label for="sel_family">2. Family</label>
            <select id="sel_family" onchange="renderSelects(0)"></select>
        </div>
        <div class="control-group">
            <label for="sel_region">3. Region</label>
            <select id="sel_region" onchange="renderSelects(1)"></select>
        </div>
        <div class="control-group">
            <label for="sel_id_stn">4. Station (id_stn)</label>
            <select id="sel_id_stn" onchange="renderSelects(2)"></select>
        </div>
        <div class="control-group">
            <label for="sel_flag">5. Criteria</label>
            <select id="sel_flag" onchange="renderSelects(3)"></select>
        </div>
        
        <button id="btn-flip" class="btn-flipflop" onclick="toggleFlipFlop()" disabled>🔁 Flip-Flop</button>
    </div>

    <div class="image-container">
        <h3 id="chart-title">---</h3>
        <div id="status-badge" class="badge">Current Image</div>
        <div id="error-msg" class="error-msg">
            <span>⚠️ Image file physically missing on disk.</span>
            <span style="font-size: 14px; color: #7f8c8d; font-weight: normal;">The combination exists in the database, but the .png could not be loaded.</span>
        </div>
        <img id="plot-image" src="" alt="Plot Image" onerror="handleError()" onload="handleLoad()">
        <div id="path-display" class="path-display">Initializing viewer...</div>
    </div>
</div>

<div class="footer">
    If you encounter any issues or bugs, please open an issue at: <br>
    <a href="https://gitlab.science.gc.ca/dlo001/Pikobs" target="_blank">https://gitlab.science.gc.ca/dlo001/Pikobs</a>
</div>

<script>
// Load and sanitize data
const rawData = JSON_DATA_PLACEHOLDER;
const dbData = rawData.map(d => ({
    ...d,
    family: String(d.family).trim(),
    region: String(d.region).trim(),
    id_stn: String(d.id_stn).trim(),
    flag_criteria: String(d.flag_criteria).trim()
}));

// Global UI state
let state = { family: null, region: null, id_stn: null, flag: null };

let currentSrc = "";
let previousSrc = "";
let showingPrevious = false;

// Custom sorting function for natural numerical order
function naturalSort(a, b) {
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}

// Get unique values sorted naturally
function getUnique(data, key) {
    return [...new Set(data.map(d => d[key]))].sort(naturalSort);
}

// Populate dropdown and retain previous selection if valid
function populateDOM(id, values, prevValue) {
    const select = document.getElementById(id);
    select.innerHTML = ''; 
    
    values.forEach(v => select.add(new Option(v, v)));
    
    if (prevValue && values.includes(prevValue)) {
        select.value = prevValue;
    } else if (values.length > 0) {
        select.value = values[0];
    }
}

// Top-down hierarchical dropdown rendering engine
function renderSelects(level) {
    // level: -1 (Init), 0 (Family), 1 (Region), 2 (Station), 3 (Flag)

    // 1. FAMILY
    if (level === -1) {
        populateDOM('sel_family', getUnique(dbData, 'family'), null);
    }
    state.family = document.getElementById('sel_family').value;

    // 2. REGION (Depends on Family)
    if (level <= 0) {
        const validRegions = dbData.filter(d => d.family === state.family);
        populateDOM('sel_region', getUnique(validRegions, 'region'), state.region);
    }
    state.region = document.getElementById('sel_region').value;

    // 3. STATION (Depends on Family + Region)
    if (level <= 1) {
        const validStns = dbData.filter(d => d.family === state.family && d.region === state.region);
        populateDOM('sel_id_stn', getUnique(validStns, 'id_stn'), state.id_stn);
    }
    state.id_stn = document.getElementById('sel_id_stn').value;

    // 4. FLAG (Depends on Family + Region + Station)
    if (level <= 2) {
        const validFlags = dbData.filter(d => 
            d.family === state.family && 
            d.region === state.region && 
            d.id_stn === state.id_stn
        );
        populateDOM('sel_flag', getUnique(validFlags, 'flag_criteria'), state.flag);
    }
    state.flag = document.getElementById('sel_flag').value;

    // Update image based on new selection
    updateImage();
}

function updateImage() {
    const name = document.getElementById('sel_name').value;
    
    // Verify complete state
    if(!state.family || !state.region || !state.id_stn || !state.flag) return;

    // Find exact record to extract names_in for title and path
    const record = dbData.find(r => 
        r.family === state.family && 
        r.id_stn === state.id_stn && 
        r.region === state.region &&
        r.flag_criteria === state.flag
    );

    if(!record || !record.names_in || record.names_in.length < 2) return;

    const n0 = record.names_in[0];
    const n1 = record.names_in[1];

    // Dynamic Title Update
    const comparisonText = `${n0} VS ${n1}`;
    document.getElementById('chart-title').textContent = comparisonText;
    document.title = `Pikobs: ${comparisonText}`;

    // Target Path generation
    const fileName = `${name}_${state.family}_${state.id_stn}_${n0}-${n1}_${state.region}_${state.flag}.png`;
    const relativePath = `${state.family}/${fileName}`;

    if(currentSrc !== relativePath) {
        if(currentSrc !== "") {
            previousSrc = currentSrc;
            document.getElementById('btn-flip').disabled = false;
        }
        currentSrc = relativePath;
        showingPrevious = false;
        document.getElementById('btn-flip').classList.remove('active-flip');
    }
    
    applySource(currentSrc, false);
}

function applySource(src, isPrevious) {
    const img = document.getElementById('plot-image');
    const badge = document.getElementById('status-badge');
    const pathDisplay = document.getElementById('path-display');

    pathDisplay.textContent = "Looking for file: " + src;
    img.src = src + "?t=" + new Date().getTime(); // Prevent caching
    
    badge.style.display = 'block';
    if(isPrevious) {
        badge.textContent = "Viewing: Previous Image";
        badge.className = "badge previous";
    } else {
        badge.textContent = "Viewing: Current Image";
        badge.className = "badge current";
    }
}

function toggleFlipFlop() {
    if(!previousSrc) return;
    showingPrevious = !showingPrevious;
    const btn = document.getElementById('btn-flip');
    if(showingPrevious) {
        applySource(previousSrc, true);
        btn.classList.add('active-flip');
    } else {
        applySource(currentSrc, false);
        btn.classList.remove('active-flip');
    }
}

function handleError() {
    document.getElementById('plot-image').style.display = 'none';
    document.getElementById('error-msg').style.display = 'flex';
    document.getElementById('status-badge').style.display = 'none';
}

function handleLoad() {
    document.getElementById('plot-image').style.display = 'block';
    document.getElementById('error-msg').style.display = 'none';
}

// Initialize application
if(dbData.length > 0) {
    renderSelects(-1);
} else {
    document.getElementById('path-display').textContent = "ERROR: No data available in data_list.";
}
</script>
</body>
</html>
"""

    html_content = html_content.replace("JSON_DATA_PLACEHOLDER", json_data)
    os.makedirs(pathwork, exist_ok=True)
    full_path = os.path.join(pathwork, output_filename)
    
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    
    print(f"✅ Advanced Vdedr Web viewer successfully created at: {full_path}")

def make_cardio( files_in,
                 names_in,
                 pathwork, 
                 datestart,
                 dateend,
                 regions, 
                 families, 
                 flag_criterias, 
                 id_stns,
                 channels,
                 n_cpu):

   for family in families:
       pikobs.delete_create_folder(pathwork, family) 
   
   data_list_cardio = create_data_list_cardio(datestart,
                                           dateend, 
                                           families, 
                                           files_in,
                                           names_in,
                                           pathwork,
                                           flag_criterias, 
                                           regions,
                                           id_stns)
   import time 
   import dask
   t0 = time.time()
 #  n_cpu=1
   if n_cpu==1:
       print (f"in Serie: {filein} files for serie calculation")
       for  data_ in data_list_cardio:  
           create_serie_cardio(data_['family'], 
                                data_['db_new'], 
                                data_['filein'],
                                data_['region'],
                                data_['flag_criteria'],
                                data_['id_stn'],
                                data_['varno'])
    
    
    
   else:
        print (f"in Paralle: {len(data_list_cardio)} files for serie calculation")
        with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                           n_workers=n_cpu, 
                                           silence_logs=40) as client:
            delayed_funcs = [dask.delayed(create_serie_cardio)(data_['family'], 
                                              data_['db_new'], 
                                              data_['filein'],
                                              data_['region'],
                                              data_['flag_criteria'],
                                              data_['id_stn'],
                                              data_['varno'])for data_ in data_list_cardio]
            results = dask.compute(*delayed_funcs)
        
   tn= time.time()
   print (f'Total time for serie calculation:', round(tn-t0,2) ) 
   data_list_plot = create_data_list_plot(datestart,
                                dateend, 
                                families, 
                                pathwork,
                                flag_criterias, 
                                regions,
                                id_stns,
                                channels,
                                files_in,
                                names_in)

    
   t0= time.time()
   mode='bias'
   if n_cpu==1: 
      print (f'in Serie plots = {len(data_list_plot)*3} ')
      for  data_ in data_list_plot:  
          pikobs.vdedr_plot(pathwork,
                            datestart,
                            dateend,
                            data_['family'],
                            data_['region'],
                            data_['files_in'],
                            data_['names_in'],
                            data_['id_stn'], 
                            data_['varno'],
                            mode,
                            data_['flag_criteria'])
   else:
      print (f'in Paralle = {len(data_list_plot)*3} plots')
      with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                       n_workers=n_cpu, 
                                       silence_logs=40) as client:
        delayed_funcs = [dask.delayed(pikobs.vdedr_plot)(
                           pathwork,
                            datestart,
                            dateend,
                            data_['family'],
                            data_['region'],
                            data_['files_in'],
                            data_['names_in'],
                            data_['id_stn'], 
                            data_['varno'],
                            mode,
                            data_['flag_criteria']) for data_ in data_list_plot]

        results = dask.compute(*delayed_funcs)
   tn = time.time()
   print ('Total time for plotting =',round(tn-t0,2) ) 
   generate_web_viewer(pathwork, data_list_plot)

 



def arg_call():
    import argparse
    import sys
    parser = argparse.ArgumentParser()
    parser.add_argument('--path_control_files', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--control_name', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--path_experience_files', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--experience_name', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--pathwork', default='undefined', type=str, help="Working directory")
    parser.add_argument('--datestart', default='undefined', type=str, help="Start date")
    parser.add_argument('--dateend', default='undefined', type=str, help="End date")
    parser.add_argument('--region', nargs="+", default='undefined', type=str, help="Region")
    parser.add_argument('--family', nargs="+",default='undefined', type=str, help="Family")
    parser.add_argument('--flags_criteria', nargs="+", default='undefined', type=str, help="Flags criteria")
    parser.add_argument('--id_stn', nargs="+",  default='all', type=str, help="id_stn") 
    parser.add_argument('--channel', nargs="+", default='all', type=str, help="channel") 
    parser.add_argument('--n_cpus', default=1, type=int, help="Number of CPUs")

    args = parser.parse_args()
    for arg in vars(args):
       print (f'--{arg} {getattr(args, arg)}')
    # Check if each argument is 'undefined'
    if args.path_control_files == 'undefined':
        raise ValueError('You must specify --path_control_files')
    elif args.control_name == 'undefined':
        raise ValueError('You must specify --control_name')
    else:    
      
      if args.path_experience_files == 'undefined':
          raise ValueError('You must specify --path_experience_files')
      if args.experience_name == 'undefined':
          raise ValueError('You must specify --experience_name')
      else:

          files_in = [args.path_control_files, args.path_experience_files]
          names_in = [args.control_name, args.experience_name]

    if args.pathwork == 'undefined':
        raise ValueError('You must specify --pathwork')
    if args.datestart == 'undefined':
        raise ValueError('You must specify --datestart')
    if args.dateend == 'undefined':
        raise ValueError('You must specify --dateend')
    if args.region == 'undefined':
        raise ValueError('You must specify --region')
    if args.family == 'undefined':
        raise ValueError('You must specify --family')
    if args.flags_criteria == 'undefined':
        raise ValueError('You must specify --flags_criteria')


    # Comment
    # Proj='cyl' // Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'
  

    #print("in")
    # Call your function with the arguments
    sys.exit(make_cardio (files_in,
                          names_in,
                          args.pathwork,
                          args.datestart,
                          args.dateend,
                          args.region,
                          args.family,
                          args.flags_criteria,
                          args.id_stn,
                          args.channel,
                          args.n_cpus))

if __name__ == '__main__':
    args = arg_call()




