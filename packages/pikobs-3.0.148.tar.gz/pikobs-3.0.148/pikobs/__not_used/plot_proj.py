import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

def create_map(ax, Proj):
    """
    Create a map on a given axes with specific projection and features.

    Parameters:
    - ax (matplotlib.axes.Axes): Axes object to plot on.
    - Proj (str): Projection type specifier.

    Returns:
    None
    """
    if Proj == 'cyl':
        ax.set_extent([-180, 180, -90, 90], crs=ccrs.PlateCarree())
    elif Proj in ['OrthoN', 'OrthoS']:
        ax.set_global()
    elif Proj == 'robinson':
        ax.set_extent([-180, 180, -90, 90], crs=ccrs.PlateCarree())
    elif Proj == 'Europe':
        ax.set_extent([-20, 50, 30, 90], crs=ccrs.PlateCarree())  # Adjusted to center on Europe
    elif Proj == 'Canada':
        ax.set_extent([-150, -53, 42, 90], crs=ccrs.PlateCarree())
    elif Proj == 'AmeriqueNord':
        ax.set_extent([-140, -40, 20, 90], crs=ccrs.PlateCarree())
    elif Proj == 'Npolar':
        ax.set_extent([-180, 180, 0, 90], crs=ccrs.PlateCarree())
    elif Proj == 'Spolar':
        ax.set_extent([-180, 180, -90, 0], crs=ccrs.PlateCarree())
    elif Proj == 'hrdps':
        lat_0 = 48.8
        delta_lat = 10.
        lon_0 = 266.00
        delta_lon = 40.
        ax.set_extent([lon_0 - delta_lon, lon_0 + delta_lon, lat_0 - delta_lat, lat_0 + delta_lat], crs=ccrs.PlateCarree())

    ax.add_feature(cfeature.OCEAN, facecolor='lightblue')
    ax.add_feature(cfeature.LAND, edgecolor='black', facecolor='white')  # Continents in white
    ax.add_feature(cfeature.COASTLINE, linewidth=0.5)
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)
    ax.add_feature(cfeature.LAKES, linewidth=0.5)

    ax.set_title(Proj, fontsize=30)  # Increase title font size
    ax.gridlines(draw_labels=True)

projections = ['cyl', 'OrthoN', 'OrthoS', 'robinson', 'Europe', 'Canada', 'AmeriqueNord', 'Npolar', 'Spolar', 'hrdps']

# Create the figure and specific subplots for each projection
fig = plt.figure(figsize=(20, 10))

for idx, Proj in enumerate(projections):
    if Proj == 'OrthoN':
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.Orthographic(central_latitude=90.0, central_longitude=-80.0))
    elif Proj == 'OrthoS':
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.Orthographic(central_latitude=-90.0, central_longitude=-80.0))
    elif Proj == 'robinson':
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.Robinson())
    elif Proj == 'Europe':
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.NorthPolarStereo(central_longitude=10.0))
    elif Proj == 'Canada':
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.NorthPolarStereo(central_longitude=-105.0))
    elif Proj in ['AmeriqueNord', 'Npolar']:
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.NorthPolarStereo(central_longitude=-105.0))
    elif Proj == 'Spolar':
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.SouthPolarStereo(central_longitude=-86))
    elif Proj == 'hrdps':
        pole_latitude = 35.7
        pole_longitude = 65.5
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.RotatedPole(pole_latitude=pole_latitude, pole_longitude=pole_longitude))
    else:
        ax = fig.add_subplot(2, 5, idx + 1, projection=ccrs.PlateCarree())

    create_map(ax, Proj)

plt.tight_layout()
plt.savefig('projections_map.png', bbox_inches='tight', dpi=300)

