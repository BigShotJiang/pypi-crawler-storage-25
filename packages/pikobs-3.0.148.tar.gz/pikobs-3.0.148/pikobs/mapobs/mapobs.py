#!/usr/bin/env python3

r"""
================================================================
pikobs.mapobs — Observation Coverage Dashboard
================================================================

``mapobs`` is the **observation coverage** module of Pikobs.  It
answers a central question for every assimilation cycle:

   *Which observations entered the system, where, when, on which
   vertical levels, and from which platforms?*

For each ``(family, flag_criteria, varno)`` combination, ``mapobs``
extracts the rows from the SQLite RDB files produced by the CMC
assimilation cycle and renders two complementary dashboards:

* one **6-hour master dashboard** per assimilation cycle (high DPI,
  intended for reports and presentations), and
* one **15-minute slice dashboard** per sub-interval inside that
  cycle (low DPI, intended for time-resolved inspection of swath
  passes and bursty obs).

Every figure shares the same nine-panel layout — geographic scatter
map on the left, marginal histograms on the top and right, two
vertical cross-sections on the right-upper half, vertical histogram
and per-station bar chart on the right-lower half — so the viewer
can scan dozens of figures and read each one at a glance.

A core design goal is **visual stability**: a given ``id_stn`` (for
example ``NOAA19`` or ``METOP-B``) is rendered with the **same RGBA
colour** across runs, experiments, regions, and flag criteria.  The
colour is derived deterministically from the station name itself
via a 32-bit FNV-1a hash modulo a 20-colour Matplotlib palette — no
lookup table to maintain, no dependence on Python's randomised
``hash()`` (which changes with ``PYTHONHASHSEED``).

.. image:: _static/mapobs.png
   :alt: Example mapobs dashboard
   :align: center
   :width: 100%

---

1. How to run
=============

Download the example shell script, make it executable, and launch
it.  Pikobs ships with an **intelligent PBS job manager**: on a
login node it generates a PBS script and submits itself via
``qsub``; on a compute node it runs locally.

.. code-block:: bash

   wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs/script/run_mapobs.sh
   chmod +x run_mapobs.sh
   ./run_mapobs.sh

Expected output on a login node::

   [pbs] PBS_JOBID= PBS_ENVIRONMENT= --no_submit=False → SUBMIT
   [pbs] qsub: /opt/pbs/bin/qsub
   Job    : 105167730.ppp7pbs-01-ib
   Log    : /home/dlo001/sites8/pikobszone_exp2/pikobs_20260518_214146.log
   Tip    : Ctrl+C to detach — job keeps running.
   ==================================================================
   Pikobs : 3.0.138
   🚀 mapobs | exp=experience | cpus=40
   [viewer] wrote /home/dlo001/sites8/.../index.html  (675 items, 5 keys)
   ==================================================================
   Job 105167730.ppp7pbs-01-ib finished.

---

2. Configuration
================

Edit only the **USER SETTINGS** block at the top of
``run_mapobs.sh``.  The script is intentionally split in three parts:
user settings, system setup, and execution — you should only need to
touch part 1.

.. code-block:: bash

   #!/usr/bin/env bash
   # ============================================================================
   # run_mapobs.sh
   # ----------------------------------------------------------------------------
   # Wrapper to generate 6-hour & 15-min geographic observation coverage maps.
   # Relies on Pikobs' built-in PBS job manager: auto-submits to the queue
   # when run from a login node; runs locally on a compute node.
   # ============================================================================
   set -eo pipefail

   # ============================================================================
   # 1. USER SETTINGS (Edit these parameters)
   # ============================================================================

   # Directory containing the SQLite obs databases (YYYYMMDDHH_<family>).
   PATH_EXPERIENCE="/home/smco500/.suites/gdps/g2/hub/ppp8/monitoring/banco/bgckalt"

   # Label printed on the title of every generated figure.
   EXPERIENCE_NAME="experience"

   # Output directory.  WARNING: wiped on each run to prevent ghost files.
   PATHWORK="/home/dlo001/sites8/pikobszone_exp2"

   # Processing window in YYYYMMDDHH format (UTC).
   DATESTART="2026051000"
   DATEEND="2026051200"

   # Observation family (e.g., sw, tmp, uv, ps).
   FAMILY="sw"

   # Bitmask filter criteria ("all" = include everything).
   FLAGS_CRITERIA="all"

   # Station ID filter ("all" / "join" = process all stations).
   ID_STN="all"

   # Number of parallel Dask workers used to render the maps.
   N_CPUS=40

   # ============================================================================
   # 2. SYSTEM SETUP (Do not edit below this line)
   # ============================================================================
   source /home/${USER}/pikobs_install/load_pikobs.sh

   # ============================================================================
   # 3. EXECUTION
   # ============================================================================
   # Pikobs auto-submits this to PBS when run from a login node.
   # Uncomment --no_submit to force local execution.
   python -c 'import pikobs; pikobs.mapobs.arg_call()' \
          --path_experience "${PATH_EXPERIENCE}"       \
          --experience_name "${EXPERIENCE_NAME}"       \
          --pathwork        "${PATHWORK}"              \
          --datestart       "${DATESTART}"             \
          --dateend         "${DATEEND}"               \
          --family          "${FAMILY}"                \
          --flags_criteria  "${FLAGS_CRITERIA}"        \
          --id_stn          "${ID_STN}"                \
          --n_cpus          "${N_CPUS}"
   #      --no_submit

+---------------------+----------------------------------------------+
| Variable            | Description                                  |
+=====================+==============================================+
| ``PATH_EXPERIENCE`` | Directory of SQLite RDB observation files    |
+---------------------+----------------------------------------------+
| ``EXPERIENCE_NAME`` | Label printed on every figure                |
+---------------------+----------------------------------------------+
| ``PATHWORK``        | Output root (wiped on each run)              |
+---------------------+----------------------------------------------+
| ``DATESTART``       | Start ``YYYYMMDDHH`` (UTC, inclusive)        |
+---------------------+----------------------------------------------+
| ``DATEEND``         | End ``YYYYMMDDHH`` (UTC, inclusive)          |
+---------------------+----------------------------------------------+
| ``FAMILY``          | One or more obs families (``sw``, ``tmp``…)  |
+---------------------+----------------------------------------------+
| ``FLAGS_CRITERIA``  | Bitmask criteria (``all`` = no filter)       |
+---------------------+----------------------------------------------+
| ``ID_STN``          | Station filter (``all`` / ``join`` = none)   |
+---------------------+----------------------------------------------+
| ``N_CPUS``          | Number of parallel Dask workers              |
+---------------------+----------------------------------------------+

---

3. Figure overview
==================

Each dashboard splits into two halves.

**Left half — geographic distribution**

+--------------------------+------------------------------------------+
| Panel                    | Content                                  |
+==========================+==========================================+
| Map (centre)             | Per-obs scatter, coloured by ``id_stn``  |
+--------------------------+------------------------------------------+
| Longitude profile (top)  | Stacked histogram of obs vs longitude    |
+--------------------------+------------------------------------------+
| Latitude profile (right) | Stacked horizontal histogram vs latitude |
+--------------------------+------------------------------------------+

**Right half — vertical and per-station**

+--------------------------+------------------------------------------+
| Panel                    | Content                                  |
+==========================+==========================================+
| Zonal cross-section      | ``vcoord`` vs latitude                   |
+--------------------------+------------------------------------------+
| Meridional cross-section | ``vcoord`` vs longitude                  |
+--------------------------+------------------------------------------+
| Vertical distribution    | Stacked histogram per vertical level     |
+--------------------------+------------------------------------------+
| Total contributions      | Horizontal bar chart per ``id_stn``      |
+--------------------------+------------------------------------------+

The mathematical definition of every panel is provided in the
docstring of its renderer (search for the panel name in this file).

---

4. Output layout
================

::

   $PATHWORK/
   ├── <family>_6h/
   │   └── <family>_6h_<varno>_<flag>_<YYYYMMDDHH>.png
   ├── <family>_15min/
   │   └── dash_<family>_<varno>_<flag>_<YYYYMMDDHH>_<HHMM>.png
   └── index.html                 ← interactive viewer

Open ``index.html`` in any browser — no server required.

A live reference instance:
   `<https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobszone_exp2/index.html>`_

---

5. Support
==========

Bugs and feature requests:
   `<https://gitlab.science.gc.ca/dlo001/Pikobs/-/issues>`_
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────────────
# Imports
# ─────────────────────────────────────────────────────────────────────────────
import argparse
import datetime as _dt
import gc
import logging
import os
import shutil
import sqlite3
import sys
import warnings
from dataclasses import dataclass
from datetime import timedelta
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import dask
import matplotlib as mpl
import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from dask.distributed import Client

import pikobs
from pikobs.pbs_submit import maybe_submit_to_pbs

try:
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    _HAS_CARTOPY = True
except ImportError:                                      # pragma: no cover
    _HAS_CARTOPY = False

mpl.use("Agg")
warnings.filterwarnings("ignore")


# ─────────────────────────────────────────────────────────────────────────────
# Module-level configuration
# ─────────────────────────────────────────────────────────────────────────────

# DPI: hero dashboards vs lightweight per-slice dashboards.
DPI_HIGH: int = 180
DPI_LOW:  int = 100

# Global font scale.  Multiplies every entry in FONTS.
GLOBAL_FONT_SCALE: float = 1.0

FONTS: Dict[str, int] = {
    "sup_title":  int(18 * GLOBAL_FONT_SCALE),
    "h_box":      int(18 * GLOBAL_FONT_SCALE),
    "p_title":    int(18 * GLOBAL_FONT_SCALE),
    "ax_label":   int(18 * GLOBAL_FONT_SCALE),
    "tick_label": int(18 * GLOBAL_FONT_SCALE),
    "annot":      int(8  * GLOBAL_FONT_SCALE),
}

# Layout / binning constants.
N_BINS_LON:        int   = 120     # bins for the longitude marginal
N_BINS_LAT:        int   = 60      # bins for the latitude marginal
N_BINS_VCONT:      int   = 41      # bins for continuous vcoord histogram
PAD_FACTOR_HIST:   float = 1.2     # 20 % headroom above max histogram count
PAD_FACTOR_STN:    float = 1.1     # 10 % headroom for station bar chart
VRANGE_PAD:        float = 0.05    # ±5 % padding on continuous v-range
SCATTER_S:         int   = 3       # scatter marker size (pt²)
SCATTER_ALPHA:     float = 0.7     # scatter marker alpha
DENSITY_THRESHOLD: int   = 100_000 # hexbin density auto-overlay threshold
ANNOT_MIN_FRAC:    float = 0.01    # hide annotations < 1 % of max
HEXBIN_GRIDSIZE:   int   = 60
N_TICKS:           int   = 5       # target tick count for "nice" axes

# Vertical-coordinate keyword tables (case-insensitive substring match).
_PRESSURE_KEYWORDS = ("pres", "pressure", "hpa", "mbar", "millibar", "pascal")
_HEIGHT_KEYWORDS   = ("height", "altitude", "metre", "meter", " m]",
                      "(m)", "agl", "asl", "geopotential")

# Refuse to wipe these paths even when explicitly requested.
_FORBIDDEN_PATHWORK = {"/", "/home", "/root", "/tmp", "/usr", "/var", "/etc"}


# ─────────────────────────────────────────────────────────────────────────────
# Nice ticks
# ─────────────────────────────────────────────────────────────────────────────

def nice_ticks(vmax: float, n: int = N_TICKS) -> List[int]:
    r"""Return tick positions starting at 0 that look round to the eye.

    The step is chosen from :math:`\{1, 2, 5\} \times 10^k`, the smallest
    candidate that produces at most :math:`n` intervals covering
    :math:`v_{max}`.  Equivalent in spirit to Matplotlib's
    ``MaxNLocator(integer=True)`` but emits an explicit list anchored at
    zero — useful for histograms whose lower bound is always 0.

    :param vmax: positive maximum value to span.
    :param n:    target number of intervals.  Default ``N_TICKS``.
    :returns:    list of integer tick positions with ``ticks[0] == 0``
        and ``ticks[-1] >= vmax``.

    :Examples:

    >>> nice_ticks(323)
    [0, 100, 200, 300, 400]
    >>> nice_ticks(1293)
    [0, 500, 1000, 1500, 2000]
    >>> nice_ticks(47)
    [0, 10, 20, 30, 40, 50]
    >>> nice_ticks(8500)
    [0, 2000, 4000, 6000, 8000, 10000]
    """
    if vmax is None or vmax <= 0 or not np.isfinite(vmax):
        return [0, 1]
    rough = vmax / n
    magnitude = 10 ** np.floor(np.log10(rough))
    step = magnitude
    for nice in (1, 2, 5, 10):
        step = nice * magnitude
        if step >= rough:
            break
    step_int = max(1, int(step))                  # guard small vmax
    upper = int(np.ceil(vmax / step_int) * step_int)
    return list(range(0, upper + step_int, step_int))


# ─────────────────────────────────────────────────────────────────────────────
# Deterministic colour assignment per id_stn
# ─────────────────────────────────────────────────────────────────────────────

# FNV-1a 32-bit constants.  FNV-1a is a tiny, fast, well-studied
# non-cryptographic hash with strong avalanche behaviour: flipping one
# input bit changes ≈ half the output bits, so neighbouring strings such
# as ``"NOAA15"`` and ``"NOAA16"`` map to unrelated colours.  Unlike
# Python's built-in :func:`hash`, FNV-1a is fully deterministic and
# machine-independent (no ``PYTHONHASHSEED`` randomisation).
_FNV_OFFSET_BASIS_32 = 0x811C9DC5
_FNV_PRIME_32        = 0x01000193


def _fnv1a_32(text: str) -> int:
    r"""32-bit FNV-1a hash of ``text.upper()``.

    For each byte :math:`b_i` of the upper-cased input, with state
    :math:`h_0 = \text{offset basis}`:

    .. math::

        h_{i+1} = \left( (h_i \oplus b_i) \cdot p \right) \bmod 2^{32}

    where :math:`p = 0x01000193` (FNV prime) and :math:`\oplus` is XOR.
    """
    h = _FNV_OFFSET_BASIS_32
    for ch in text.upper():
        h = ((h ^ ord(ch)) * _FNV_PRIME_32) & 0xFFFFFFFF
    return h


def stable_color_for_stn(stn_name: str) -> Tuple[float, float, float, float]:
    """Return a deterministic RGBA colour for an ``id_stn``.

    Uses Matplotlib's ``tab20`` palette (20 perceptually-distinct
    categorical colours) indexed by the FNV-1a hash modulo 20.  Same
    name → same colour, on any machine, on any Python build.
    """
    return plt.get_cmap("tab20")(_fnv1a_32(stn_name) % 20)


def build_global_color_map(stations: Iterable[str]) -> Dict[str, tuple]:
    """Return ``{id_stn: rgba}`` covering every station in *stations*."""
    return {stn: stable_color_for_stn(stn) for stn in sorted(set(stations))}


# ─────────────────────────────────────────────────────────────────────────────
# Small utilities
# ─────────────────────────────────────────────────────────────────────────────

def fmt_count(n: int) -> str:
    """Compact integer formatter: ``1234 → "1,234"``, ``1.2M``, ``1.2B``."""
    if n < 1_000_000:
        return f"{n:,}"
    if n < 1_000_000_000:
        return f"{n / 1e6:.1f}M"
    return f"{n / 1e9:.1f}B"


# ─────────────────────────────────────────────────────────────────────────────
# Geography & axis helpers
# ─────────────────────────────────────────────────────────────────────────────

def get_rectangular_extent(proj_name: str
                           ) -> Tuple["ccrs.CRS", List[float]]:
    """Return ``(crs, [lon_w, lon_e, lat_s, lat_n])`` for a named region.

    :raises RuntimeError: if cartopy is not installed.
    """
    if not _HAS_CARTOPY:
        raise RuntimeError("cartopy is required; install via pikobs_env.yml")
    proj = ccrs.PlateCarree()
    name = proj_name.lower()
    if "npolar"       in name:                       return proj, [-180, 180,  50,  90]
    if "spolar"       in name:                       return proj, [-180, 180, -90, -50]
    if "ameriquenord" in name or "canada" in name:   return proj, [-150, -40,  30,  85]
    if "europe"       in name:                       return proj, [ -25,  45,  30,  75]
    return proj, [-180, 180, -90, 90]


def region_label(extent: Sequence[float]) -> str:
    """Compact banner label for an extent ``[lon_w, lon_e, lat_s, lat_n]``."""
    lon_w, lon_e, lat_s, lat_n = extent
    def _ns(v: float) -> str: return f"{abs(v):.0f}{'N' if v >= 0 else 'S'}"
    def _ew(v: float) -> str: return f"{abs(v):.0f}{'E' if v >= 0 else 'W'}"
    return f"[{_ns(lat_s)}-{_ns(lat_n)}, {_ew(lon_w)}-{_ew(lon_e)}]"


def resolve_type_varno(varno: int | str) -> Tuple[str, str, str]:
    """Resolve a varno code to ``(name, units, vcoord_label)``.

    Falls back to a generic label if ``pikobs.configobs.type_varno``
    cannot be imported (e.g. during tests).
    """
    try:
        from pikobs.configobs.type_varno import type_varno
        return type_varno(str(varno))
    except Exception:                                    # pragma: no cover
        return f"Varno: {varno}", "", "Vcoord"


def vertical_axis_orientation(vcoord_label: str, is_channel: bool) -> str:
    """Classify the vertical coordinate from its label.

    :returns: one of ``"pressure"`` (axis is inverted on plots),
        ``"height"`` (not inverted, e.g. metres), ``"channel"`` (discrete,
        not inverted), ``"unknown"`` (not inverted).
    """
    if is_channel:
        return "channel"
    lab = vcoord_label.lower()
    if any(k in lab for k in _PRESSURE_KEYWORDS):
        return "pressure"
    if any(k in lab for k in _HEIGHT_KEYWORDS):
        return "height"
    return "unknown"


# ─────────────────────────────────────────────────────────────────────────────
# Data loading
# ─────────────────────────────────────────────────────────────────────────────

def load_coverage_data(db_path: str,
                       varno: int | str,
                       flag_criteria_sql: str,
                       id_stn_list: Sequence[str]) -> pd.DataFrame:
    """Read one ``YYYYMMDDHH_<family>`` SQLite RDB file.

    The SQL query is a straightforward inner-join between header and
    data tables on ``id_obs``, filtered by *varno*, *flag_criteria*, and
    optionally by station ID.  The returned DataFrame is normalised:

    * Column names are lower-cased.
    * ``lat``, ``lon``, ``vcoord`` are coerced to numeric.
    * Rows with NaN ``lat``/``lon`` are dropped.
    * A ``datetime`` column is built from ``DATE`` and ``TIME``.

    :param db_path:           absolute path to the SQLite file.
    :param varno:             BUFR varno used in the WHERE clause.
    :param flag_criteria_sql: pre-built ``AND ...`` fragment from
        :func:`pikobs.flag_criteria`.
    :param id_stn_list:       station filter; ``"all"`` or ``"join"``
        disables it.
    :returns: DataFrame with columns
        ``[lat, lon, vcoord, id_stn, date, time, datetime]`` or an
        empty DataFrame if the file is missing, unreadable, or empty.
    """
    if not os.path.isfile(db_path):
        return pd.DataFrame()

    if "join" in id_stn_list or "all" in id_stn_list:
        stn_sql = ""
    else:
        stn_sql = " AND (" + " OR ".join(
            f"h.id_stn = '{s}'" for s in id_stn_list
        ) + ") "

    query = (
        "SELECT h.lat, h.lon, d.vcoord, h.id_stn, h.DATE, h.TIME "
        "FROM header h JOIN data d USING(id_obs) "
        f"WHERE d.varno = {varno} {flag_criteria_sql} {stn_sql}"
    )

    try:
        with sqlite3.connect(f"file:{db_path}?mode=ro", uri=True) as conn:
            df = pd.read_sql_query(query, conn)
    except Exception as exc:
        print(f"[mapobs] WARN reading {db_path}: {exc}", file=sys.stderr)
        if os.environ.get("PIKOBS_VERBOSE"):
            import traceback
            traceback.print_exc(file=sys.stderr)
        return pd.DataFrame()

    if df.empty:
        return df

    df.columns = [c.lower() for c in df.columns]
    for col in ("lat", "lon", "vcoord"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["lat", "lon"])

    if not df.empty:
        df["datetime"] = pd.to_datetime(
            df["date"].astype(str) + df["time"].astype(str).str.zfill(6),
            format="%Y%m%d%H%M%S", errors="coerce",
        )
        df = df.dropna(subset=["datetime"])
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Plot context
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PlotContext:
    """Immutable bundle of plotting parameters shared by sub-renderers.

    The values come from :func:`make_coverage` and are *frozen* per
    ``(family, region, flag, varno)`` group, then reused for every
    individual dashboard (6-h and 15-min) inside that group.  This
    guarantees consistent colours, axis ranges, and tick scales across
    related figures.
    """
    proj:          "ccrs.CRS"
    extent:        List[float]
    lon_ext:       Tuple[float, float]
    lat_ext:       Tuple[float, float]
    vcoord_label:  str
    var_name:      str
    var_units:     str
    flag_label:    str
    family:        str
    exp_name:      str
    color_map:     Dict[str, tuple]
    v_min:         float
    v_max:         float
    max_counts:    Tuple[int, int, int, int]    # (lon, lat, vert, stn)
    is_channel:    bool
    v_orient:      str
    region_lbl:    str
    show_density:  bool


# ─────────────────────────────────────────────────────────────────────────────
# Top-level dashboard renderer
# ─────────────────────────────────────────────────────────────────────────────

def plot_dashboard(df_chunk: pd.DataFrame,
                   dt_start: _dt.datetime,
                   dt_end:   _dt.datetime,
                   out_png:  str,
                   ctx:      PlotContext,
                   is_total: bool = False) -> None:
    """Render one dashboard PNG.

    Layout (a 2-row × 2-col outer ``GridSpec``):

    * Row 0 spans both columns → header banner.
    * Row 1 col 0 → left block (map + marginal histograms).
    * Row 1 col 1 → right block (cross-sections + vertical hist + bars).

    Empty slices still produce a fully-rendered figure with zero bars
    and a discreet *"no data"* watermark on the map — this is
    intentional, missing tiles in a viewer are harder to interpret than
    explicit zero-count panels.

    :param df_chunk: data for this dashboard.  May be empty.
    :param dt_start: inclusive start of the time window.
    :param dt_end:   exclusive end of the time window.
    :param out_png:  PNG output path.
    :param ctx:      :class:`PlotContext` with shared parameters.
    :param is_total: if ``True``, render at ``DPI_HIGH`` and tag the
        title as *MASTER 6-HOUR*; otherwise ``DPI_LOW`` for fast slices.
    """
    out_dpi = DPI_HIGH if is_total else DPI_LOW
    fig = plt.figure(figsize=(37, 20))
    gs_main = gridspec.GridSpec(
        2, 2, figure=fig,
        height_ratios=[0.08, 1], width_ratios=[1.1, 1],
        wspace=0.25, hspace=0.08,
        left=0.04, right=0.96, top=0.94, bottom=0.08,
    )
    max_c_lon, max_c_lat, max_c_v, max_c_stn = ctx.max_counts

    _plot_header(fig, gs_main, df_chunk, dt_start, dt_end, ctx, is_total)

    by_stn: Dict[str, pd.DataFrame] = {
        s: g for s, g in df_chunk.groupby("id_stn", sort=False)
    } if not df_chunk.empty else {}

    if df_chunk.empty:
        stns_by_vol    = list(ctx.color_map.keys())[:1] or ["—"]
        colors_stacked = [ctx.color_map.get(stns_by_vol[0], (0.7, 0.7, 0.7, 1))]
    else:
        stns_by_vol    = df_chunk["id_stn"].value_counts().index.tolist()
        colors_stacked = [ctx.color_map[s] for s in stns_by_vol]

    _plot_left_block(fig, gs_main, by_stn, df_chunk, ctx,
                     stns_by_vol, colors_stacked, max_c_lon, max_c_lat)
    _plot_right_block(fig, gs_main, by_stn, df_chunk, ctx,
                      stns_by_vol, colors_stacked, max_c_v, max_c_stn)

    save_kwargs = dict(dpi=out_dpi, facecolor="white")
    if is_total:
        save_kwargs["pil_kwargs"] = {"optimize": True}
    fig.savefig(out_png, **save_kwargs)
    plt.close(fig)
    gc.collect()


# ─────────────────────────────────────────────────────────────────────────────
# Header banner
# ─────────────────────────────────────────────────────────────────────────────

def _plot_header(fig, gs_main,
                 df_chunk: pd.DataFrame,
                 dt_start: _dt.datetime, dt_end: _dt.datetime,
                 ctx: PlotContext, is_total: bool) -> None:
    r"""Top banner: title plus a single monospace info box.

    For a non-empty slice, the banner also reports the 5th, 50th and
    95th percentiles of ``vcoord``:

    .. math::

        Q_p(\mathbf{v}) = \inf\{ x : F_{\mathbf{v}}(x) \ge p \},
        \quad p \in \{0.05, 0.50, 0.95\}

    where :math:`F_{\mathbf{v}}` is the empirical CDF of the vertical
    coordinate.  These three numbers summarise the bulk of the vertical
    distribution and let the viewer spot atypical cycles at a glance.
    """
    ax_head = fig.add_subplot(gs_main[0, :])
    ax_head.axis("off")

    title  = "MASTER 6-HOUR" if is_total else "4D Observation Coverage"
    dt_str = (f"{dt_start.strftime('%Y-%m-%d (%a)  %H:%M')} "
              f"to {dt_end.strftime('%H:%M UTC')}")
    fig.suptitle(
        f"{title} Dashboard  —  {ctx.family.upper()}\n"
        f"{dt_str} | exp={ctx.exp_name}",
        fontsize=FONTS["sup_title"], fontweight="bold", y=0.98,
    )

    if not df_chunk.empty:
        vc = df_chunk["vcoord"].dropna()
        p_info = (
            f"p05={np.percentile(vc, 5):.1f} "
            f"p50={np.median(vc):.1f} "
            f"p95={np.percentile(vc, 95):.1f}"
            if len(vc) else "n/a"
        )
    else:
        p_info = "n/a"

    header_text = (
        f"Family: {ctx.family.upper()} | {ctx.var_name} {ctx.var_units} | "
        f"Flags: {ctx.flag_label} | Region: {ctx.region_lbl} | "
        f"Total Obs: {fmt_count(len(df_chunk))} | "
        f"{ctx.vcoord_label}  [{p_info}]"
    )
    ax_head.text(
        0.5, 0.4, header_text, transform=ax_head.transAxes,
        ha="center", va="center", fontsize=FONTS["h_box"],
        family="monospace",
        bbox=dict(boxstyle="round", facecolor="#fafafa", edgecolor="#34495e"),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Tick helper used by several panels
# ─────────────────────────────────────────────────────────────────────────────

def _apply_nice_count_ticks(ax, axis: str, vmax: int,
                            label_fmt=fmt_count) -> None:
    """Apply :func:`nice_ticks` to a count axis and format the labels."""
    ticks = nice_ticks(vmax)
    if axis == "x":
        ax.set_xticks(ticks)
        ax.set_xticklabels([label_fmt(t) for t in ticks])
        ax.set_xlim(0, ticks[-1])
    else:
        ax.set_yticks(ticks)
        ax.set_yticklabels([label_fmt(t) for t in ticks])
        ax.set_ylim(0, ticks[-1])


# ─────────────────────────────────────────────────────────────────────────────
# Left block — map + marginal Lon/Lat histograms
# ─────────────────────────────────────────────────────────────────────────────

def _plot_left_block(fig, gs_main,
                     by_stn: Dict[str, pd.DataFrame],
                     df_chunk: pd.DataFrame,
                     ctx: PlotContext,
                     stns_by_vol: Sequence[str],
                     colors_stacked: Sequence[tuple],
                     max_c_lon: int, max_c_lat: int) -> None:
    r"""Map and its two marginal histograms.

    **Geographic scatter map** — projects each observation
    :math:`(\lambda_i, \varphi_i)` on the chosen ``ccrs`` projection,
    coloured by ``id_stn``.  When ``ctx.show_density`` is enabled and
    :math:`N \ge` :data:`DENSITY_THRESHOLD`, a grey hexbin density layer
    is overlaid using

    .. math::

        \rho(\mathbf{c}) = \sum_{i=1}^{N}
        \mathbb{1}\!\left[(\lambda_i, \varphi_i) \in \mathrm{hex}(\mathbf{c})\right]

    where :math:`\mathrm{hex}(\mathbf{c})` is the hexagonal cell
    centred at :math:`\mathbf{c}` and :math:`\mathbb{1}[\cdot]` is the
    indicator function.

    **Longitude / latitude marginal histograms** — stacked bar
    histograms.  For bin :math:`B_k` and station :math:`s`:

    .. math::

        H^{(s)}_k = \sum_{i=1}^{N}
        \mathbb{1}\!\left[\lambda_i \in B_k\right]\,
        \mathbb{1}\!\left[\text{stn}_i = s\right]

    Total height of the bin is :math:`H_k = \sum_s H^{(s)}_k` and the
    stacking order is *most-observed station at the bottom* so the
    busiest contributor is always visually dominant.
    """
    gs_j = gridspec.GridSpecFromSubplotSpec(
        2, 2, subplot_spec=gs_main[1, 0],
        height_ratios=[0.25, 2], width_ratios=[3, 0.25],
        wspace=0.06, hspace=0.06,
    )
    ax_hx = fig.add_subplot(gs_j[0, 0])
    ax_sc = fig.add_subplot(gs_j[1, 0], projection=ctx.proj)
    ax_hy = fig.add_subplot(gs_j[1, 1])

    is_empty = df_chunk.empty

    # ── Map base layer ──
    ax_sc.set_extent(ctx.extent, crs=ccrs.PlateCarree())
    ax_sc.set_aspect("auto", adjustable="datalim")
    ax_sc.add_feature(cfeature.LAND,      facecolor="#fbfaf6")
    ax_sc.add_feature(cfeature.COASTLINE, lw=0.7)

    gl = ax_sc.gridlines(draw_labels=True, linewidth=0.5,
                         color="gray", alpha=0.6, linestyle="--")
    gl.top_labels = gl.right_labels = False
    gl.xlabel_style = {"size": FONTS["tick_label"]}
    gl.ylabel_style = {"size": FONTS["tick_label"]}

    # Reference lines: equator and Greenwich (only if visible).
    if ctx.lat_ext[0] <= 0 <= ctx.lat_ext[1]:
        ax_sc.axhline(0.0, color="#555", lw=0.5, ls=":", alpha=0.6)
    if ctx.lon_ext[0] <= 0 <= ctx.lon_ext[1]:
        ax_sc.axvline(0.0, color="#555", lw=0.5, ls=":", alpha=0.6)

    # ── Map content ──
    if not is_empty:
        if ctx.show_density and len(df_chunk) >= DENSITY_THRESHOLD:
            ax_sc.hexbin(
                df_chunk["lon"], df_chunk["lat"],
                gridsize=HEXBIN_GRIDSIZE, cmap="Greys",
                mincnt=1, alpha=0.35, linewidths=0,
                transform=ccrs.PlateCarree(),
            )
        for stn in stns_by_vol:
            sub = by_stn[stn]
            ax_sc.scatter(sub["lon"], sub["lat"],
                          c=[ctx.color_map[stn]],
                          s=SCATTER_S, alpha=SCATTER_ALPHA,
                          transform=ccrs.PlateCarree(), edgecolors="none",
                          rasterized=True)
    else:
        ax_sc.text(0.5, 0.5, "no data", color="#aaa",
                   transform=ax_sc.transAxes,
                   ha="center", va="center",
                   fontsize=FONTS["sup_title"], alpha=0.5)

    # ── Marginal histograms ──
    b_lon = np.linspace(ctx.lon_ext[0], ctx.lon_ext[1], N_BINS_LON)
    b_lat = np.linspace(ctx.lat_ext[0], ctx.lat_ext[1], N_BINS_LAT)

    if not is_empty:
        ax_hx.hist([by_stn[s]["lon"] for s in stns_by_vol],
                   bins=b_lon, color=colors_stacked,
                   histtype="stepfilled", stacked=True,
                   edgecolor="black", lw=0.1)
        ax_hy.hist([by_stn[s]["lat"] for s in stns_by_vol],
                   bins=b_lat, color=colors_stacked,
                   histtype="stepfilled", orientation="horizontal",
                   stacked=True, edgecolor="black", lw=0.1)

        tot_lon, _ = np.histogram(df_chunk["lon"], bins=b_lon)
        tot_lat, _ = np.histogram(df_chunk["lat"], bins=b_lat)
        annot_thr_lon = max(1, int(max_c_lon * ANNOT_MIN_FRAC))
        annot_thr_lat = max(1, int(max_c_lat * ANNOT_MIN_FRAC))

        for cx, cnt in zip(0.5 * (b_lon[:-1] + b_lon[1:]), tot_lon):
            if cnt >= annot_thr_lon:
                ax_hx.text(cx, cnt + (max_c_lon * 0.02), fmt_count(int(cnt)),
                           ha="center", va="bottom",
                           fontsize=FONTS["annot"], rotation=90)
        for cy, cnt in zip(0.5 * (b_lat[:-1] + b_lat[1:]), tot_lat):
            if cnt >= annot_thr_lat:
                ax_hy.text(cnt + (max_c_lat * 0.05), cy, fmt_count(int(cnt)),
                           ha="left", va="center",
                           fontsize=FONTS["annot"])

    # Cosmetics — longitude marginal.
    _apply_nice_count_ticks(ax_hx, "y", max_c_lon)
    ax_hx.set_xlim(ctx.lon_ext)
    ax_hx.set_title("Longitude Profile", loc="left",
                    size=FONTS["p_title"], fontweight="bold")
    ax_hx.tick_params(labelbottom=False, labelsize=FONTS["tick_label"])
    ax_hx.grid(axis="y", ls="--", alpha=0.3, color="gray")

    # Cosmetics — latitude marginal.  Panel is very narrow; show only
    # the maximum tick to avoid label overlap.
    ax_hy.set_xticks([max_c_lat])
    ax_hy.set_xticklabels([fmt_count(max_c_lat)])
    ax_hy.set_xlim(0, max_c_lat)
    ax_hy.tick_params(axis="x", labelsize=int(FONTS["tick_label"] * 1.2))
    ax_hy.grid(axis="x", ls="--", alpha=0.3, color="gray")
    ax_hy.set_ylim(ctx.lat_ext)
    ax_hy.set_title("Latitude Profile", loc="left",
                    size=FONTS["p_title"], fontweight="bold")
    ax_hy.tick_params(labelleft=False)


# ─────────────────────────────────────────────────────────────────────────────
# Right block — cross-sections, vertical hist, bar chart
# ─────────────────────────────────────────────────────────────────────────────

def _plot_right_block(fig, gs_main,
                      by_stn: Dict[str, pd.DataFrame],
                      df_chunk: pd.DataFrame,
                      ctx: PlotContext,
                      stns_by_vol: Sequence[str],
                      colors_stacked: Sequence[tuple],
                      max_c_v: int, max_c_stn: int) -> None:
    r"""Right half: a 2 × 2 grid of identically-sized panels.

    Panels:

    * **Zonal cross-section** — :math:`(\varphi_i, v_i)` per obs.
    * **Meridional cross-section** — :math:`(\lambda_i, v_i)` per obs.
    * **Vertical distribution** — stacked histogram of :math:`v_i`,
      with separate treatment for *discrete* (channel) vs *continuous*
      vertical coordinates.
    * **Total contributions** — horizontal bar chart of per-station
      observation counts.
    """
    gs_r = gridspec.GridSpecFromSubplotSpec(
        2, 2, subplot_spec=gs_main[1, 1],
        width_ratios=[1, 1], height_ratios=[1, 1],
        wspace=0.55, hspace=0.75,
    )
    ax_z  = fig.add_subplot(gs_r[0, 0])      # zonal cross-section
    ax_m  = fig.add_subplot(gs_r[0, 1])      # meridional cross-section
    ax_vh = fig.add_subplot(gs_r[1, 0])      # vertical histogram
    ax_b  = fig.add_subplot(gs_r[1, 1])      # contributions

    lon_ticks = np.linspace(ctx.lon_ext[0], ctx.lon_ext[1], 7)
    lat_ticks = np.linspace(ctx.lat_ext[0], ctx.lat_ext[1], 5)
    is_empty = df_chunk.empty

    # ── Zonal and meridional cross-sections ──
    for ax, coord in zip((ax_z, ax_m), ("lat", "lon")):
        if not is_empty:
            for stn in stns_by_vol:
                sub = by_stn[stn]
                ax.scatter(sub[coord], sub["vcoord"],
                           c=[ctx.color_map[stn]],
                           s=SCATTER_S, alpha=SCATTER_ALPHA,
                           edgecolors="none", rasterized=True)
        _set_vertical_axis(ax, df_chunk, ctx)
        ax.set_xlim(ctx.lat_ext if coord == "lat" else ctx.lon_ext)
        ticks = lat_ticks if coord == "lat" else lon_ticks
        ax.set_xticks(ticks)
        ax.set_xticklabels([f"{v:.0f}°" for v in ticks])
        ax.set_title("Zonal Cross-Section" if coord == "lat"
                     else "Meridional Cross-Section",
                     size=FONTS["p_title"], fontweight="bold")
        ax.set_ylabel(ctx.vcoord_label,
                      size=FONTS["ax_label"], fontweight="bold")
        ax.set_xlabel("Latitude" if coord == "lat" else "Longitude",
                      size=FONTS["ax_label"], fontweight="bold")
        ax.tick_params(labelsize=FONTS["tick_label"])
        ax.grid(True, ls="--", alpha=0.5)

    # ── Vertical distribution ──
    if not is_empty:
        if ctx.is_channel:
            _plot_channel_bars(ax_vh, by_stn, ctx, max_c_v)
        else:
            _plot_continuous_vhist(ax_vh, by_stn, df_chunk, ctx,
                                   stns_by_vol, colors_stacked, max_c_v)
    else:
        _set_vertical_axis(ax_vh, df_chunk, ctx)

    _apply_nice_count_ticks(ax_vh, "x", max_c_v)
    ax_vh.set_title("Vertical Data Distribution",
                    size=FONTS["p_title"], fontweight="bold")
    ax_vh.set_xlabel("Observation Count",
                     size=FONTS["ax_label"], fontweight="bold")
    ax_vh.set_ylabel(ctx.vcoord_label,
                     size=FONTS["ax_label"], fontweight="bold")
    ax_vh.tick_params(labelsize=FONTS["tick_label"])
    ax_vh.grid(True, ls="--", alpha=0.5, axis="x")

    # ── Total contributions bar chart ──
    counts = (df_chunk["id_stn"].value_counts() if not is_empty
              else pd.Series(dtype=int))
    all_stns = sorted(list(ctx.color_map.keys()), reverse=True) or ["—"]
    ax_b.barh(all_stns, [int(counts.get(s, 0)) for s in all_stns],
              color=[ctx.color_map.get(s, (0.7, 0.7, 0.7, 1)) for s in all_stns],
              edgecolor="black", lw=0.5)
    _apply_nice_count_ticks(ax_b, "x", max_c_stn)
    ax_b.set_title("Total Contributions",
                   size=FONTS["p_title"], fontweight="bold")
    ax_b.set_xlabel("Total Observations",
                    size=FONTS["ax_label"], fontweight="bold")
    ax_b.set_ylabel("", size=FONTS["ax_label"], fontweight="bold")
    ax_b.tick_params(axis="y", labelsize=FONTS["tick_label"], pad=25)
    ax_b.tick_params(axis="x", labelsize=FONTS["tick_label"])

    annot_thr_stn = max(1, int(max_c_stn * ANNOT_MIN_FRAC))
    for i, stn in enumerate(all_stns):
        if stn in ctx.color_map:
            ax_b.text(-0.03, i, "●", color=ctx.color_map[stn],
                      transform=ax_b.get_yaxis_transform(),
                      ha="right", va="center", size=18, clip_on=False)
        v = int(counts.get(stn, 0))
        if v >= annot_thr_stn and v > 0:
            ax_b.text(v + (max_c_stn * 0.01), i, fmt_count(v),
                      va="center", fontsize=int(FONTS["annot"] * 1.5),
                      fontweight="bold")


# ─────────────────────────────────────────────────────────────────────────────
# Vertical-distribution sub-renderers
# ─────────────────────────────────────────────────────────────────────────────

def _plot_channel_bars(ax,
                       by_stn: Dict[str, pd.DataFrame],
                       ctx:    PlotContext,
                       max_c_v: int) -> None:
    r"""Discrete horizontal bars, one row per channel.

    For each integer channel :math:`c \in \mathcal{C}` and station
    :math:`s`:

    .. math::

        H^{(s)}_c = \sum_{i=1}^{N}
        \mathbb{1}\!\left[\lfloor v_i \rfloor = c\right]\,
        \mathbb{1}\!\left[\text{stn}_i = s\right]

    Bars stack contributions left-to-right in *decreasing total* order,
    so the dominant platform per channel is drawn first.  Total per
    channel is :math:`H_c = \sum_s H^{(s)}_c`; values above
    :data:`ANNOT_MIN_FRAC` × ``max_c_v`` are annotated.
    """
    full = pd.concat(by_stn.values(), ignore_index=True).dropna(subset=["vcoord"])
    if full.empty:
        return
    full["vcoord_int"] = full["vcoord"].astype(int)

    all_channels = sorted(full["vcoord_int"].unique().tolist())
    pivot = (pd.crosstab(full["vcoord_int"], full["id_stn"])
               .reindex(index=all_channels, fill_value=0))

    bar_height = 0.8                                    # 20 % gap between bars
    cumulative = np.zeros(len(all_channels))
    stn_order  = pivot.sum().sort_values(ascending=False).index.tolist()
    for stn in stn_order:
        widths = pivot[stn].values
        ax.barh(all_channels, widths,
                left=cumulative, height=bar_height,
                color=ctx.color_map.get(stn, "gray"),
                edgecolor="black", lw=0.2)
        cumulative += widths

    annot_thr = max(1, int(max_c_v * ANNOT_MIN_FRAC))
    totals = pivot.sum(axis=1).values
    for ch, tot in zip(all_channels, totals):
        if tot >= annot_thr:
            ax.text(tot + max_c_v * 0.02, ch, fmt_count(int(tot)),
                    ha="left", va="center",
                    fontsize=int(FONTS["annot"] * 1.5))

    ax.set_yticks(all_channels)
    ax.set_yticklabels([str(c) for c in all_channels])
    ax.set_ylim(all_channels[0] - 0.5, all_channels[-1] + 0.5)


def _plot_continuous_vhist(ax,
                           by_stn: Dict[str, pd.DataFrame],
                           df_chunk: pd.DataFrame,
                           ctx: PlotContext,
                           stns_by_vol: Sequence[str],
                           colors_stacked: Sequence[tuple],
                           max_c_v: int) -> None:
    r"""Stacked horizontal histogram for continuous vertical coords.

    Vertical bins :math:`B_k` are equally spaced on
    :math:`[v_{\min}, v_{\max}]` with :data:`N_BINS_VCONT` bins.  For
    each bin and station:

    .. math::

        H^{(s)}_k = \sum_{i=1}^{N}
        \mathbb{1}\!\left[v_i \in B_k\right]\,
        \mathbb{1}\!\left[\text{stn}_i = s\right]

    Bars are stacked horizontally so the bin total is read on the
    x-axis.  For *pressure* coordinates the axis is inverted by
    :func:`_set_vertical_axis` so high pressure (low altitude) appears
    at the bottom, matching atmospheric convention.
    """
    v_bins = np.linspace(ctx.v_min, ctx.v_max, N_BINS_VCONT)
    ax.hist(
        [by_stn[s]["vcoord"].dropna() for s in stns_by_vol],
        bins=v_bins, orientation="horizontal", stacked=True,
        color=colors_stacked, edgecolor="black", lw=0.2,
    )
    tot_v, _ = np.histogram(df_chunk["vcoord"].dropna(), bins=v_bins)
    annot_thr = max(1, int(max_c_v * ANNOT_MIN_FRAC))
    for cv, cnt in zip(0.5 * (v_bins[:-1] + v_bins[1:]), tot_v):
        if cnt >= annot_thr:
            ax.text(cnt + (max_c_v * 0.02), cv, fmt_count(int(cnt)),
                    ha="left", va="center",
                    fontsize=int(FONTS["annot"] * 1.5))
    _set_vertical_axis(ax, df_chunk, ctx)


def _set_vertical_axis(ax, df_chunk: pd.DataFrame, ctx: PlotContext) -> None:
    """Set y-axis limits and orientation according to ``ctx.v_orient``.

    * ``"channel"``  – integer ticks at the observed channels.
    * ``"pressure"`` – linear range, **inverted** (high pressure on
      bottom).
    * ``"height"`` / ``"unknown"`` – linear range, not inverted.
    """
    if ctx.v_orient == "channel":
        channels = sorted(df_chunk["vcoord"].dropna().unique().astype(int))
        if channels:
            ax.set_yticks(channels)
            ax.set_yticklabels([str(c) for c in channels])
            ax.set_ylim(channels[0] - 0.5, channels[-1] + 0.5)
        return
    ax.set_ylim(ctx.v_min, ctx.v_max)
    if ctx.v_orient == "pressure":
        ax.invert_yaxis()


# ─────────────────────────────────────────────────────────────────────────────
# Orchestrator helpers
# ─────────────────────────────────────────────────────────────────────────────

def _global_vrange(df_cache: Dict[str, pd.DataFrame]
                   ) -> Tuple[float, float]:
    r"""Return ``(v_min, v_max)`` across all DataFrames in *df_cache*.

    Equivalent to ``min/max`` of the concatenated ``vcoord`` column but
    streamed per DataFrame, so memory stays :math:`O(1)` regardless of
    the cache size.  Returns ``(0, 1)`` as a defensive fallback if no
    finite values are found.
    """
    v_min, v_max = np.inf, -np.inf
    for d in df_cache.values():
        v = d["vcoord"]
        if v.notna().any():
            v_min = min(v_min, float(v.min(skipna=True)))
            v_max = max(v_max, float(v.max(skipna=True)))
    if not np.isfinite(v_min) or not np.isfinite(v_max):
        return 0.0, 1.0
    return v_min, v_max


def _global_max_counts(df_cache:     Dict[str, pd.DataFrame],
                       lon_ext:      Tuple[float, float],
                       lat_ext:      Tuple[float, float],
                       v_bins:       np.ndarray,
                       interval_min: int,
                       is_channel:   bool,
                       ) -> Tuple[Tuple[int, int, int, int],
                                  Tuple[int, int, int, int]]:
    r"""Compute the global maximum per panel for two time scales.

    Returns ``(scales_6h, scales_15m)`` where each tuple has the layout
    ``(max_count_lon, max_count_lat, max_count_v, max_count_stn)``.
    Both tuples are padded:

    .. math::

        m^{\text{padded}} = \lceil m \cdot \text{PAD\_FACTOR} \rceil

    with :data:`PAD_FACTOR_HIST` for the histograms and
    :data:`PAD_FACTOR_STN` for the bar chart.  By construction the
    15-min scale is :math:`\le` the 6-hour scale for every panel, so
    sliced dashboards never look truncated relative to their master.

    For channels (``is_channel=True``) the v-max is the largest *per
    channel total* — matching what :func:`_plot_channel_bars` draws.
    """
    m15 = dict(lon=0, lat=0, v=0, stn=0)
    m6h = dict(lon=0, lat=0, v=0, stn=0)

    def _v_max(g: pd.DataFrame) -> int:
        v = g["vcoord"].dropna()
        if v.empty:
            return 0
        if is_channel:
            counts = v.astype(int).value_counts()
            return int(counts.max()) if not counts.empty else 0
        return int(np.histogram(v, bins=v_bins)[0].max())

    for dfc in df_cache.values():
        if dfc.empty:
            continue
        m6h["lon"] = max(m6h["lon"], int(np.histogram(dfc["lon"], bins=N_BINS_LON, range=lon_ext)[0].max()))
        m6h["lat"] = max(m6h["lat"], int(np.histogram(dfc["lat"], bins=N_BINS_LAT, range=lat_ext)[0].max()))
        m6h["stn"] = max(m6h["stn"], int(dfc["id_stn"].value_counts().max()))
        m6h["v"]   = max(m6h["v"],   _v_max(dfc))

        for _, g in dfc.groupby(pd.Grouper(key="datetime",
                                           freq=f"{interval_min}min")):
            if g.empty:
                continue
            m15["lon"] = max(m15["lon"], int(np.histogram(g["lon"], bins=N_BINS_LON, range=lon_ext)[0].max()))
            m15["lat"] = max(m15["lat"], int(np.histogram(g["lat"], bins=N_BINS_LAT, range=lat_ext)[0].max()))
            m15["stn"] = max(m15["stn"], int(g["id_stn"].value_counts().max()))
            m15["v"]   = max(m15["v"],   _v_max(g))

    def _pad(d):
        return (int(d["lon"] * PAD_FACTOR_HIST),
                int(d["lat"] * PAD_FACTOR_HIST),
                int(d["v"]   * PAD_FACTOR_HIST),
                int(d["stn"] * PAD_FACTOR_STN))

    pad6  = tuple(max(v, 1) for v in _pad(m6h))
    pad15 = tuple(max(v, 1) for v in _pad(m15))
    return pad6, pad15


def _validate_pathwork(pathwork: str) -> None:
    """Refuse to wipe system / home directories.

    :raises ValueError: if ``pathwork`` resolves to a forbidden path
        (root, ``/home``, ``/tmp``, ``$HOME`` …).
    """
    abs_p = os.path.abspath(pathwork).rstrip("/")
    if abs_p in _FORBIDDEN_PATHWORK or abs_p == os.path.expanduser("~"):
        raise ValueError(
            f"Refusing to wipe '{abs_p}'. Choose a dedicated --pathwork."
        )


def _validate_dates(datestart: str,
                    dateend: str) -> Tuple[_dt.datetime, _dt.datetime]:
    """Parse and sanity-check ``YYYYMMDDHH`` strings.

    :raises ValueError: on bad format or on ``dateend < datestart``.
    """
    try:
        dt_s = _dt.datetime.strptime(datestart, "%Y%m%d%H")
        dt_e = _dt.datetime.strptime(dateend,   "%Y%m%d%H")
    except ValueError as exc:
        raise ValueError(
            f"Invalid date format (expected YYYYMMDDHH): {exc}") from exc
    if dt_e < dt_s:
        raise ValueError(
            f"dateend ({dateend}) precedes datestart ({datestart}).")
    return dt_s, dt_e


def _silence_distributed_loggers() -> None:
    """Set ``CRITICAL`` level on Dask / Tornado / asyncio loggers.

    These libraries emit ``StreamClosedError`` / ``CommClosedError``
    tracebacks during teardown.  They are HARMLESS — the work is
    already complete; only async cleanup is in flight — but they
    pollute the user's terminal at the end of a successful run.
    """
    for name in (
        "distributed", "distributed.client",  "distributed.scheduler",
        "distributed.worker", "distributed.nanny",
        "distributed.core",   "distributed.comm",
        "distributed.utils",  "distributed.utils_perf",
        "tornado", "tornado.application", "asyncio",
    ):
        logging.getLogger(name).setLevel(logging.CRITICAL)


# ─────────────────────────────────────────────────────────────────────────────
# Top-level orchestrator
# ─────────────────────────────────────────────────────────────────────────────

def make_coverage(exp_path:      str,
                  exp_name:      str,
                  pathwork:      str,
                  datestart:     str,
                  dateend:       str,
                  families:      List[str],
                  flag_criteria: List[str],
                  interval_min:  int,
                  id_stn:        List[str],
                  varno_list:    Optional[List[int]],
                  projections:   List[str],
                  n_cpus:        int,
                  build_viewer:  bool = True,
                  show_density:  bool = False) -> None:
    """Scan obs databases, plan plotting tasks, dispatch via Dask, build viewer.

    High-level workflow:

    1. Validate ``--pathwork`` and the date range.
    2. Wipe and recreate ``--pathwork``.
    3. For each ``(family, projection, flag_criteria, varno)``:

       a. Read every cycle's SQLite RDB into an in-memory DataFrame
          cache.
       b. Compute the global vertical range and the two count scales
          (6-h, 15-min) shared by every panel of the group.
       c. Build a deterministic colour map covering all stations seen.
       d. Queue one 6-h master task per cycle + one 15-min task per
          ``interval_min`` slot inside that cycle.

    4. Launch a Dask local cluster, execute all tasks in parallel,
       tear down cleanly (no traceback noise).
    5. Optionally generate the HTML viewer.

    :param exp_path:      directory of ``YYYYMMDDHH_<family>`` files.
    :param exp_name:      experiment label printed on every figure.
    :param pathwork:      output root (wiped on each run; protected).
    :param datestart:     start ``YYYYMMDDHH`` (UTC, inclusive).
    :param dateend:       end ``YYYYMMDDHH`` (UTC, inclusive).
    :param families:      observation families to process.
    :param flag_criteria: flag-criteria keys.
    :param interval_min:  slice interval in minutes (typically 15).
    :param id_stn:        station filter; ``["all"]`` / ``["join"]`` = none.
    :param varno_list:    optional varno overrides.
    :param projections:   region / projection names.
    :param n_cpus:        Dask worker count; clamped to available CPUs.
    :param build_viewer:  if ``True``, generate ``index.html``.
    :param show_density:  if ``True``, overlay hexbin density on maps
        whose slice has :math:`\\ge` :data:`DENSITY_THRESHOLD` obs.
    """
    print(f"\n🚀 mapobs | exp={exp_name} | cpus={n_cpus}")

    _validate_pathwork(pathwork)
    dt_s, dt_e = _validate_dates(datestart, dateend)
    cpu_avail = os.cpu_count() or 1
    if n_cpus > cpu_avail:
        print(f"[mapobs] WARN n_cpus={n_cpus} exceeds available CPUs "
              f"({cpu_avail}); clamping.", file=sys.stderr)
        n_cpus = cpu_avail

    if os.path.exists(pathwork):
        shutil.rmtree(pathwork, ignore_errors=True)
    os.makedirs(pathwork, exist_ok=True)

    tasks: list           = []
    viewer_items: list    = []

    for fam in families:
        for proj_name in projections:
            dir_15 = os.path.join(pathwork, f"{fam}_15min")
            dir_6h = os.path.join(pathwork, f"{fam}_6h")
            os.makedirs(dir_15, exist_ok=True)
            os.makedirs(dir_6h, exist_ok=True)

            for fc in flag_criteria:
                sql_f         = pikobs.flag_criteria(fc)
                proj, extent  = get_rectangular_extent(proj_name)
                lon_ext       = (extent[0], extent[1])
                lat_ext       = (extent[2], extent[3])
                reg_lbl       = region_label(extent)

                _, _, _, _, elem, _ = pikobs.family(fam)
                if varno_list:
                    active_v = [str(v) for v in varno_list]
                else:
                    active_v = [v.strip() for v in
                                str(elem).replace("(", "").replace(")", "").split(",")
                                if v.strip()]

                for v in active_v:
                    v_name, v_unit, v_lab = resolve_type_varno(v)
                    is_chan  = ("channel" in v_lab.lower()
                                or "canal" in v_lab.lower())
                    v_orient = vertical_axis_orientation(v_lab, is_chan)

                    # ── Read every cycle into memory ──
                    df_cache: Dict[str, pd.DataFrame] = {}
                    master_stns: set = set()
                    scan_d = dt_s
                    while scan_d <= dt_e:
                        fdate = scan_d.strftime("%Y%m%d%H")
                        db    = os.path.join(exp_path, f"{fdate}_{fam}")
                        df    = load_coverage_data(db, v, sql_f, id_stn)
                        if not df.empty:
                            df_cache[fdate] = df
                            master_stns.update(df["id_stn"].unique())
                        scan_d += timedelta(hours=6)

                    if not df_cache:
                        continue

                    # ── Group-wide vertical range ──
                    g_v_min, g_v_max = _global_vrange(df_cache)
                    if not is_chan:
                        g_v_min *= (1 - VRANGE_PAD)
                        g_v_max *= (1 + VRANGE_PAD)
                    if abs(g_v_max - g_v_min) < 1e-9:
                        g_v_min -= 1
                        g_v_max += 1

                    # ── Bins for vertical histogram ──
                    if is_chan:
                        all_channels = sorted({
                            int(x) for d in df_cache.values()
                            for x in d["vcoord"].dropna().unique()
                        })
                        v_bins = (np.arange(all_channels[0] - 0.5,
                                            all_channels[-1] + 1.5, 1)
                                  if all_channels else np.array([0, 1]))
                    else:
                        v_bins = np.linspace(g_v_min, g_v_max, N_BINS_VCONT)

                    # ── Two count scales shared by the group ──
                    scales_6h, scales_15m = _global_max_counts(
                        df_cache, lon_ext, lat_ext, v_bins,
                        interval_min, is_chan,
                    )
                    if scales_15m[2] > scales_6h[2]:
                        print(f"[mapobs] WARN 15-min v-scale {scales_15m[2]} > "
                              f"6h v-scale {scales_6h[2]} (fam={fam}, "
                              f"varno={v}); investigating data.",
                              file=sys.stderr)

                    color_map = build_global_color_map(master_stns)

                    base_ctx = dict(
                        proj=proj, extent=extent,
                        lon_ext=lon_ext, lat_ext=lat_ext,
                        vcoord_label=v_lab, var_name=v_name, var_units=v_unit,
                        flag_label=fc, family=fam, exp_name=exp_name,
                        color_map=color_map,
                        v_min=g_v_min, v_max=g_v_max,
                        is_channel=is_chan, v_orient=v_orient,
                        region_lbl=reg_lbl,
                        show_density=show_density,
                    )
                    ctx_6h  = PlotContext(max_counts=scales_6h,  **base_ctx)
                    ctx_15m = PlotContext(max_counts=scales_15m, **base_ctx)

                    # ── Queue tasks ──
                    for fdate, df6h in df_cache.items():
                        fdt = _dt.datetime.strptime(fdate, "%Y%m%d%H")
                        n6  = f"{fam}_6h_{v}_{fc}_{fdate}.png"

                        tasks.append(dask.delayed(plot_dashboard)(
                            df6h,
                            fdt - timedelta(hours=3),
                            fdt + timedelta(hours=3),
                            os.path.join(dir_6h, n6),
                            ctx_6h, True,
                        ))
                        viewer_items.append(dict(
                            family=fam, mode="6h", varno=str(v),
                            flag=fc, date=fdate,
                            filename=f"{fam}_6h/{n6}",
                        ))

                        tc = fdt - timedelta(hours=3)
                        while tc < fdt + timedelta(hours=3):
                            tn  = tc + timedelta(minutes=interval_min)
                            dfs = df6h[(df6h["datetime"] >= tc) &
                                       (df6h["datetime"] <  tn)]
                            if not dfs.empty:
                                ts  = tc.strftime("%H%M")
                                n15 = f"dash_{fam}_{v}_{fc}_{fdate}_{ts}.png"
                                tasks.append(dask.delayed(plot_dashboard)(
                                    dfs, tc, tn,
                                    os.path.join(dir_15, n15),
                                    ctx_15m, False,
                                ))
                                viewer_items.append(dict(
                                    family=fam, mode="15min", varno=str(v),
                                    flag=fc, date=f"{fdate}_{ts}",
                                    filename=f"{fam}_15min/{n15}",
                                ))
                            tc = tn

                    del df_cache
                    gc.collect()

    # ── Dispatch ──
    if not tasks:
        return

    _silence_distributed_loggers()

    # Do NOT mix `with Client(...) as client:` with manual shutdown().
    # The context manager runs its own close() and races with the
    # manual one, producing harmless but ugly tracebacks.  A plain
    # try/finally with explicit close() then shutdown() keeps both
    # old (sync) and new (async) Dask versions happy.
    client = Client(
        n_workers=n_cpus,
        silence_logs=50,
        dashboard_address=None,             # avoid port-8787 warning
    )
    try:
        dask.compute(*tasks)
    finally:
        try:
            client.close(timeout=30)
        except Exception:
            pass
        try:
            client.shutdown()
        except Exception:
            pass

    if build_viewer:
        pikobs.generate_web(
            viewer_items,
            ["family", "mode", "varno", "flag", "date"],
            os.path.join(pathwork, "index.html"),
            title="Pikobs Coverage Dashboard",
        )


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────────────────────────────────────

def arg_call() -> None:
    """Parse the command line and dispatch to :func:`make_coverage`.

    Auto-submits to PBS through :func:`pikobs.pbs_submit.maybe_submit_to_pbs`
    when invoked on a login node, unless ``--no_submit`` is passed.
    """
    parser = argparse.ArgumentParser(
        prog="pikobs-mapobs",
        description="Render 6-hour and 15-min observation coverage dashboards.",
    )

    # I/O & date range
    parser.add_argument("--path_experience", required=True,
        help="Directory with YYYYMMDDHH_<family> SQLite files.")
    parser.add_argument("--experience_name", required=True,
        help="Experiment label printed on every figure.")
    parser.add_argument("--pathwork", required=True,
        help="Output directory (wiped on each run).")
    parser.add_argument("--datestart", required=True,
        help="Start date YYYYMMDDHH (UTC, inclusive).")
    parser.add_argument("--dateend", required=True,
        help="End date YYYYMMDDHH (UTC, inclusive).")

    # Selection
    parser.add_argument("--family", nargs="+", required=True,
        help="One or more observation families.")
    parser.add_argument("--flags_criteria", nargs="+", default=["all"],
        help="Flag-criteria keys (see pikobs.flag_criteria).")
    parser.add_argument("--id_stn", nargs="+", default=["join"],
        help='Station filter; use "all" / "join" for no filter.')
    parser.add_argument("--varno", nargs="+", type=int, default=None,
        help="Optional varno overrides.")
    parser.add_argument("--projection", nargs="+", default=["cyl"],
        help="Region(s): cyl, npolar, spolar, canada, europe.")

    # Behaviour
    parser.add_argument("--interval_min", type=int, default=15,
        help="Sub-cycle interval in minutes (default: 15).")
    parser.add_argument("--n_cpus", type=int, default=10,
        help="Number of Dask workers.")
    parser.add_argument("--no_viewer", action="store_true",
        help="Skip the HTML viewer generation.")
    parser.add_argument("--show_density", action="store_true",
        help=f"Overlay hexbin density when a slice has "
             f">= {DENSITY_THRESHOLD} observations.")

    # PBS auto-submit
    parser.add_argument("--walltime", default="02:00:00",
        help="PBS walltime HH:MM:SS (default: 02:00:00).")
    parser.add_argument("--no_submit", action="store_true",
        help="Skip PBS auto-submit and run locally.")

    args = parser.parse_args()
    maybe_submit_to_pbs(args)

    make_coverage(
        exp_path      = args.path_experience,
        exp_name      = args.experience_name,
        pathwork      = args.pathwork,
        datestart     = args.datestart,
        dateend       = args.dateend,
        families      = args.family,
        flag_criteria = args.flags_criteria,
        interval_min  = args.interval_min,
        id_stn        = args.id_stn,
        varno_list    = args.varno,
        projections   = args.projection,
        n_cpus        = args.n_cpus,
        build_viewer  = not args.no_viewer,
        show_density  = args.show_density,
    )


if __name__ == "__main__":
    arg_call()
