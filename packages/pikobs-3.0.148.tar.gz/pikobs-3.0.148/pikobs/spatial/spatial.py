"""
Pikobs spatial diagnostic pipeline
==================================
https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobszone_exp2/
Overview
--------
``spatial.py`` evaluates the spatial structure of departures (OMP / OMA /
obsvalue) from a single experiment — there is no control here. Unlike
``progps.py`` which collapses observations into vertical-profile
statistics, this module preserves the (lat, lon, vcoord) triplet of every
observation and produces three families of diagnostic figures:

1. **Global map** — gridded average of the chosen statistic on a
   regular ``--grid_size`` (degrees) lat/lon mesh.

2. **Zonal cross-section** — gridded average on a (lat, vcoord) plane.
   The vertical axis is auto-detected from the family's VCOTYP and
   labelled accordingly:

   * pressure-like coordinates (Pa, hPa) -> y-axis inverted.
   * height-above-sea-level coordinates -> y-axis natural.
   * channel-like coordinates (satellite radiances) -> rendered as
     categorical bins; one figure per (channel) bucket if you set
     ``--channel all``.

3. **Spatial structure**: empirical semivariogram :math:`\\gamma(h)`
   AND empirical correlation :math:`\\rho(h)` as functions of the
   haversine distance :math:`h` between observations. The
   correlation is exactly :math:`\\rho(h) = 1 - \\gamma(h) / \\sigma^2`
   where :math:`\\sigma^2` is the global variance of the field, but
   computing both directly from station pairs gives a useful sanity
   check — they must agree on a common scale.

   The semivariogram and the correlation are computed on **station
   averages**, not raw observations, to keep the pairwise loop
   tractable and to denoise the field.

Mathematical recap
^^^^^^^^^^^^^^^^^^

Given station averages :math:`v_1, \\ldots, v_N` at locations
:math:`(\\phi_i, \\lambda_i)` (lat, lon), and bins
:math:`B_k = [h_k, h_k + \\Delta h)`,

.. math::

   \\widehat{\\gamma}(h_k) \\;=\\; \\frac{1}{2\\,|B_k|}
       \\sum_{(i,j) \\in B_k} (v_i - v_j)^2

.. math::

   \\widehat{\\rho}(h_k) \\;=\\; \\frac{1}{|B_k|\\, s^2}
       \\sum_{(i,j) \\in B_k} (v_i - \\bar{v})(v_j - \\bar{v})

where :math:`|B_k|` is the number of station pairs whose haversine
distance falls in bin :math:`B_k`, :math:`\\bar{v}` is the global
mean and :math:`s^2` the global variance of the station averages.
A bin is dropped when :math:`|B_k| <` ``--corr_min_pairs`` (default
30); plotting too few pairs gives a noisy curve that is easy to
misread.

Output layout
-------------
::

    pathwork/
    ├── conversion_db/                 (preserved between runs)
    ├── <family>/
    │   ├── spatial_<func>_<exp>_..._map.png
    │   ├── spatial_<func>_<exp>_..._zonal.png
    │   └── spatial_<func>_<exp>_..._structure.png
    └── pikobs_spatial_viewer.html

The whole ``pathwork`` directory is wiped at the start of every run,
**except** ``conversion_db/`` which holds the BURP -> SQLite cache
produced by ``pikobs.pikobsburp2db`` and must survive between runs.

Command-line reference
----------------------

Inputs (SQLite databases)
^^^^^^^^^^^^^^^^^^^^^^^^^
``--path_experience_files PATH [PATH ...]``  **(at least one)**
    One directory per experiment. Each directory must contain SQLite
    files named ``<DATE>_<family>`` (or ``.db``, or
    ``db_converted_<NAME>_<DATE>_<family>.db``). BURP -> SQLite
    conversion is **not** done here; run ``pikobs.pikobsburp2db``
    first.

``--experience_name NAME [NAME ...]``        **(must mirror paths)**
    Short tag per experiment. Number of names must equal number of
    paths.

Run identity
^^^^^^^^^^^^
``--pathwork PATH``                          **(required)**
    Output directory; wiped at start-up except for ``conversion_db/``.

``--datestart YYYYMMDDHH``                   **(required)**
``--dateend   YYYYMMDDHH``                   **(required)**
    Inclusive range; cycles stepped every 6 hours.

Spatial / variable selection
^^^^^^^^^^^^^^^^^^^^^^^^^^^^
``--family FAMILY [FAMILY ...]``             **(at least one)**
    Tags understood by ``pikobs.family()`` (``ro``, ``ai``, ``ua``,
    ``amsua``, ``cris``, ``iasi``, ``atms``, ...). One folder per
    family is created.

``--varnos VARNO [VARNO ...]``               (optional)
    Variable codes to plot. If omitted, the default list returned by
    ``pikobs.family()`` for each ``--family`` is used — same
    convention as ``progps.py``. Pass explicit values to restrict to
    a subset.

``--region REGION [REGION ...]``             (default ``Monde``)
    Currently informational only — the spatial plots already cover
    the chosen region by virtue of the lat/lon span of the data.

``--id_stn VALUE``                           (default ``join``)
    Station selection. ``all`` produces one set of plots per distinct
    station; a SQL LIKE pattern (containing ``%`` or ``_``) is
    matched and collapsed; any other literal value is collapsed too.

``--channel VALUE``                          (default ``join``)
    Vertical / channel selection. ``all`` produces one set of plots
    per distinct vcoord/channel value; anything else collapses every
    level into a single bucket.

Statistic chosen for the plot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
``--fonction FUNC [FUNC ...]``               **(at least one)**
    What is averaged in every grid box. Each entry must be ``omp``,
    ``oma`` or ``obsvalue``.

``--flags_criteria CRIT [CRIT ...]``         **(at least one)**
    Tags understood by ``pikobs.flag_criteria()`` — typically
    ``assimilee``.

Spatial-structure tuning (all auto by default)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
The four parameters below are normally **picked from the data
itself** — you only set them if you want to override the auto-choice
for a specific run. Just leave them out for the typical case.

``--grid_size DEGREES``                      (default ``auto``)
    Lat/lon bin size for the global map and zonal section. Auto rule:
    target ~30 boxes along the longest axis of the actual data
    extent.

``--max_dist KM``                            (default ``auto``)
    Furthest haversine distance plotted in the structure figure.
    Auto rule: 80th percentile of the actual pairwise distances of
    your data — going further would just add noise from a regime
    where pairs are sparse.

``--bin_size KM``                            (default ``auto``)
    Width of every distance bin in the structure plot. Auto rule:
    ``max_dist / 25`` rounded to a friendly number, so you get ~25
    bins of equal width.

``--corr_min_pairs N``                       (default ``auto``)
    Bins with fewer pairs are dropped from the structure plot. Auto
    rule: ``max(30, total_pairs / 500)``.

The structure plot also auto-fits an exponential
:math:`\\rho(h) \\approx \\exp(-h / L)` to the empirical correlation
curve and prints the verdict ("distance IS / IS NOT a meaningful
predictor of OMP similarity, with characteristic length L ≈ ... km")
in plain language at the bottom of the figure.

Parallelism
^^^^^^^^^^^
``--n_cpus N``                               (default ``1``)
    Dask worker count (one task per (experiment, family, criterion,
    function, varno) tuple).

Example
^^^^^^^
.. code-block:: bash

   python -c 'import pikobs; pikobs.spatial.arg_call()'             \\
       --path_experience_files /workdir/converted/Exp1              \\
                               /workdir/converted/Exp2              \\
       --experience_name        Exp1 Exp2                           \\
       --pathwork               /workdir/spatial/                   \\
       --datestart 2022060100 --dateend 2022060512                  \\
       --family    ro                                               \\
       --flags_criteria assimilee                                   \\
       --fonction       omp                                         \\
       --varnos 15036                                               \\
       --grid_size  5.0                                             \\
       --max_dist   5000                                            \\
       --bin_size   250                                             \\
       --n_cpus     8
"""

import os
import sys
import re
import shutil
import sqlite3
import argparse
import datetime
import warnings
from datetime import timedelta

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

import dask
from dask.distributed import Client

import pikobs

mpl.use("Agg")
warnings.filterwarnings("ignore")


# =============================================================================
#  CONSTANTS
# =============================================================================

_FUNC_COLS = {
    "omp"     : "omp",
    "oma"     : "oma",
    "obsvalue": "obsvalue",
}

_CONVERSION_DIR_NAME = "conversion_db"

# Plot palette (Okabe-Ito, colour-blind safe). Spatial plots use one
# colour per experiment but are rarely overlaid, so we mostly use the
# diverging colormap for the maps and a single accent for line plots.
_COLOR_LINE = "#0072B2"      # blue
_COLOR_GAMMA = "#D55E00"     # vermillion
_COLOR_RHO   = "#009E73"     # bluish green
_DIVERGING_CMAP = "RdBu_r"

# A coarse classification of vcoord types so we can label and orient the
# zonal axis correctly. ``pikobs.family()`` returns VCOTYP as a free-form
# string — we recognise a few keywords. Anything we don't recognise is
# treated as "generic" and we just label it "Vertical coordinate".
_VCOORD_PRESSURE_KEYWORDS = (
    "pressure", "press", "hpa", "pa", "level", "isobar",
)
_VCOORD_HEIGHT_KEYWORDS = (
    "height", "altitude", "metre", "meter", "asl", "above_sea",
)
_VCOORD_CHANNEL_KEYWORDS = (
    "channel", "chan", "wavenumber", "wave_number",
)


def _classify_vcoord(vcotyp: str) -> str:
    """Return one of 'pressure', 'height', 'channel', 'generic'."""
    if not vcotyp:
        return "generic"
    s = str(vcotyp).lower()
    for kw in _VCOORD_PRESSURE_KEYWORDS:
        if kw in s:
            return "pressure"
    for kw in _VCOORD_HEIGHT_KEYWORDS:
        if kw in s:
            return "height"
    for kw in _VCOORD_CHANNEL_KEYWORDS:
        if kw in s:
            return "channel"
    return "generic"


def _vcoord_label(vkind: str, vcotyp: str) -> str:
    """Pretty axis label given the classification."""
    if vkind == "pressure":
        return f"Pressure ({vcotyp})"
    if vkind == "height":
        return f"Height ({vcotyp})"
    if vkind == "channel":
        return f"Channel ({vcotyp})" if vcotyp else "Channel"
    return f"Vertical coordinate ({vcotyp})" if vcotyp else "Vertical coordinate"


# =============================================================================
#  LOW-LEVEL DB / FILESYSTEM HELPERS
# =============================================================================

def _is_sqlite3(filepath: str) -> bool:
    if not filepath or not os.path.isfile(filepath):
        return False
    try:
        with open(filepath, "rb") as fd:
            return fd.read(16) == b"SQLite format 3\x00"
    except OSError:
        return False


def _clean_pathwork_preserving_cache(pathwork: str) -> None:
    """Wipe pathwork EXCEPT conversion_db/. Same logic as progps.py."""
    if not pathwork or pathwork in ("/", os.path.expanduser("~")):
        sys.stderr.write(
            f"[clean] refusing to clean unsafe pathwork: {pathwork!r}\n"
        )
        return
    pathwork = os.path.realpath(pathwork)
    if not os.path.isdir(pathwork):
        os.makedirs(pathwork, exist_ok=True)
        os.makedirs(os.path.join(pathwork, _CONVERSION_DIR_NAME), exist_ok=True)
        return
    cache_dir = os.path.join(pathwork, _CONVERSION_DIR_NAME)
    n_removed = 0
    for entry in os.listdir(pathwork):
        full = os.path.join(pathwork, entry)
        if entry == _CONVERSION_DIR_NAME:
            continue
        try:
            if os.path.islink(full) or os.path.isfile(full):
                os.remove(full)
            elif os.path.isdir(full):
                shutil.rmtree(full)
            n_removed += 1
        except OSError as e:
            sys.stderr.write(f"[clean] could not remove {full}: {e}\n")
    os.makedirs(cache_dir, exist_ok=True)
    print(
        f"[clean] pathwork={pathwork} | removed {n_removed} entries | "
        f"preserved {_CONVERSION_DIR_NAME}/"
    )


def _resolve_input(path: str, fdate: str, family: str, exp_name: str) -> str:
    """
    Resolve the SQLite input file for a (path, date, family) triple.
    Tries the three naming conventions emitted by pikobs.pikobsburp2db.
    Returns "" if no candidate is a valid SQLite file.
    """
    candidates = [
        os.path.normpath(f"{path}/{fdate}_{family}"),
        os.path.normpath(f"{path}/{fdate}_{family}.db"),
        os.path.normpath(
            f"{path}/db_converted_{exp_name}_{fdate}_{family}.db"
        ),
    ]
    for c in candidates:
        if _is_sqlite3(c):
            return c
    return ""


# =============================================================================
#  SPATIAL MATH
# =============================================================================

def _haversine_pairwise(lat: np.ndarray, lon: np.ndarray) -> np.ndarray:
    """
    Pairwise haversine distance (km), upper triangle only flattened.
    Returns (distances, i, j) so the caller can re-index any
    associated array. Memory-quadratic on N — fine for station
    averages where N is rarely > 5000.
    """
    n = len(lat)
    lat_r = np.radians(lat)
    lon_r = np.radians(lon)
    iu, ju = np.triu_indices(n, k=1)
    dlat = lat_r[ju] - lat_r[iu]
    dlon = lon_r[ju] - lon_r[iu]
    a = (np.sin(dlat / 2.0) ** 2
         + np.cos(lat_r[iu]) * np.cos(lat_r[ju]) * np.sin(dlon / 2.0) ** 2)
    return 6371.0 * 2.0 * np.arcsin(np.sqrt(a)), iu, ju


def _auto_distance_bins(distances: np.ndarray, n_obs: int = None) -> dict:
    """
    Pick reasonable distance-binning parameters from the data itself.

    Logic
    -----
    * ``max_dist`` = 80th percentile of the actual pairwise distances.
    * ``bin_size`` = max_dist / 25.
    * ``min_pairs`` is scaled to the total number of pairs:
      ``n_obs*(n_obs-1)/2 / 25 / 5`` (= one fifth of the average bin
      occupancy expected for ~25 bins), clipped to [5, 30]. If
      ``n_obs`` is None, the size of ``distances`` is used as a
      proxy.
    """
    n_dist = len(distances)
    if n_dist == 0:
        return {"max_dist": 5000.0, "bin_size": 250.0, "min_pairs": 5}

    max_dist = float(np.percentile(distances, 80))
    if max_dist > 8000:
        max_dist = round(max_dist / 1000) * 1000
    elif max_dist > 1000:
        max_dist = round(max_dist / 500) * 500
    elif max_dist > 200:
        max_dist = round(max_dist / 100) * 100
    else:
        max_dist = max(round(max_dist / 10) * 10, 50.0)

    bin_size  = max(max_dist / 25.0, 1.0)
    if bin_size > 100:
        bin_size = round(bin_size / 50) * 50
    elif bin_size > 20:
        bin_size = round(bin_size / 10) * 10
    else:
        bin_size = round(bin_size)
    bin_size = max(bin_size, 1.0)

    # Real total pair count (preferred) or fallback to probe size.
    if n_obs is not None and n_obs >= 2:
        # Of the n*(n-1)/2 pairs, only ~80% fall under the 80th
        # percentile we'll plot.
        total_pairs_in_range = 0.8 * n_obs * (n_obs - 1) / 2.0
    else:
        total_pairs_in_range = n_dist
    expected_per_bin = max(total_pairs_in_range / 25.0, 1.0)
    min_pairs = int(np.clip(round(expected_per_bin / 5.0), 5, 30))

    return {
        "max_dist" : max_dist,
        "bin_size" : bin_size,
        "min_pairs": min_pairs,
    }


def _fit_exponential(h: np.ndarray, rho: np.ndarray) -> dict:
    """
    Fit ρ(h) ≈ exp(−h / L) to the empirical correlation curve.
    Uses a robust least-squares on log(ρ) where ρ > 0.05.

    Returns
    -------
    dict with keys
        L              : float, decorrelation length (km).  None if fit failed.
        valid          : bool, True if the fit is meaningful.
        diagnosis      : str,  human-readable verdict.
        crossing_1e    : float, distance where ρ first drops below 1/e (km).
                         None if the curve never crosses 1/e.
    """
    if len(h) == 0 or np.all(np.isnan(rho)):
        return {"L": None, "valid": False,
                "diagnosis": "No data for spatial correlation.",
                "crossing_1e": None}

    h_v   = h[~np.isnan(rho)]
    rho_v = rho[~np.isnan(rho)]
    if len(h_v) < 4:
        return {"L": None, "valid": False,
                "diagnosis": "Too few bins for spatial correlation.",
                "crossing_1e": None}

    # 1/e crossing — read straight off the empirical curve, no fit.
    # If the curve crosses 1/e, that alone is strong evidence of
    # spatial structure regardless of whether an exponential fit
    # converges nicely.
    one_e = 1.0 / np.e
    crossing = None
    for i in range(len(h_v) - 1):
        if rho_v[i] >= one_e and rho_v[i+1] < one_e:
            # Linear interpolation between the two bins
            f = (rho_v[i] - one_e) / (rho_v[i] - rho_v[i+1])
            crossing = float(h_v[i] + f * (h_v[i+1] - h_v[i]))
            break

    # Try an exponential fit on bins with positive ρ. Threshold lowered
    # to 0.02 so short-correlation-length fields (where only the first
    # 1-2 bins have ρ >> 0) still produce a fit.
    mask = rho_v > 0.02
    fit_L = None
    fit_slope = None
    if mask.sum() >= 3:
        try:
            log_rho = np.log(rho_v[mask])
            slope, _ = np.polyfit(h_v[mask], log_rho, 1)
            if slope < 0:
                fit_L = -1.0 / slope
                fit_slope = slope
        except (ValueError, np.linalg.LinAlgError):
            pass

    # ---- Decide the verdict ----
    # The 1/e crossing is the most reliable indicator with limited bins.
    # The fitted L is a complement; if both exist they should be similar.
    if crossing is not None:
        # Pick the more reliable estimate.
        if fit_L is not None:
            # If the two agree to within a factor of 2, average them
            # geometrically for a robust point estimate; else trust
            # the crossing (it's model-free).
            ratio = max(fit_L, crossing) / min(fit_L, crossing)
            if ratio < 2.0:
                L_est = float(np.sqrt(fit_L * crossing))
            else:
                L_est = float(crossing)
        else:
            L_est = float(crossing)
        diagnosis = (
            f"OMP correlation decays with distance: characteristic "
            f"length L ≈ {L_est:.0f} km. Distance IS a predictor of "
            f"OMP similarity."
        )
        return {
            "L": L_est, "valid": True,
            "diagnosis": diagnosis,
            "crossing_1e": crossing,
        }

    # No 1/e crossing. Either flat noise or a very long-range field
    # whose correlation never drops to 1/e in our window.
    rho_max = float(np.nanmax(rho_v))
    rho_first = float(rho_v[0])
    if fit_L is not None and fit_L < 5 * h_v.max():
        diagnosis = (
            f"OMP correlation decays slowly: fit gives L ≈ {fit_L:.0f} "
            f"km (no 1/e crossing in the analysed window). Treat with "
            f"caution — extend --max_dist for a clearer answer."
        )
        return {
            "L": float(fit_L), "valid": True,
            "diagnosis": diagnosis,
            "crossing_1e": None,
        }
    if rho_max < 0.1:
        return {
            "L": None, "valid": False,
            "diagnosis": (
                "No clear spatial correlation: ρ stays near zero "
                f"(max ρ = {rho_max:.2f}). Distance is NOT a strong "
                "predictor of OMP similarity."
            ),
            "crossing_1e": None,
        }
    return {
        "L": None, "valid": False,
        "diagnosis": (
            f"Correlation present (ρ at first bin = {rho_first:.2f}) "
            "but no clear decay: distance is a WEAK predictor here."
        ),
        "crossing_1e": None,
    }


def _empirical_structure(
    lat: np.ndarray,
    lon: np.ndarray,
    val: np.ndarray,
    max_dist_km: float = None,
    bin_size_km: float = None,
    min_pairs: int = None,
    max_obs: int = 30000,
    chunk: int = 4000,
    rng_seed: int = 0,
) -> dict:
    """
    Empirical semivariogram and correlation, computed all-against-all
    on raw observations — every observation is paired with every other,
    no station averaging, no spatial boxing.

    Memory & speed
    --------------
    Naively this needs an N x N distance matrix (8 bytes per entry,
    so 30000^2 ≈ 7 GB — impossible). Instead we walk the upper
    triangle of (i, j) pairs in CHUNKS of size ``chunk x chunk`` and
    accumulate per-bin sums on the fly. Memory use is O(chunk^2),
    independent of N.

    For very large N we apply uniform random sub-sampling down to
    ``max_obs`` points before the loop. The estimate stays unbiased
    because the sample is uniform over the field; only the variance
    of the per-bin estimate gets larger. The header of the plot
    reports whether a sub-sample was used.

    Parameters
    ----------
    lat, lon, val : 1-D arrays
        Raw observation coordinates and the value to test (e.g. OMP).
    max_dist_km, bin_size_km, min_pairs : optional
        If None, picked from the data by :func:`_auto_distance_bins`.
    max_obs : int
        Hard cap on the number of observations actually used in the
        pairwise loop; defaults to 30000 (≈ 4.5e8 pairs).
    chunk : int
        Block size of the (i, j) iteration. Memory ≈ 24 * chunk^2 bytes.
    rng_seed : int
        Seed for the sub-sampling, so the result is reproducible.

    Returns
    -------
    dict with keys
        bin_centers (km)   : np.ndarray
        n_pairs            : np.ndarray (int)
        gamma              : np.ndarray  (semivariance)
        rho                : np.ndarray  (correlation)
        sigma2             : float
        mean               : float
        max_dist_km        : float
        bin_size_km        : float
        min_pairs          : int
        n_used             : int      (obs after sub-sampling)
        n_total            : int      (obs before sub-sampling)
        subsampled         : bool
    """
    val = np.asarray(val, dtype=float)
    lat = np.asarray(lat, dtype=float)
    lon = np.asarray(lon, dtype=float)
    n_total = len(val)
    if n_total < 2:
        return None

    # Uniform random sub-sample if we exceed the cap. Unbiased: the
    # population from which we sample is exchangeable in lat/lon.
    subsampled = False
    if n_total > max_obs:
        rng = np.random.default_rng(rng_seed)
        keep = rng.choice(n_total, size=max_obs, replace=False)
        lat, lon, val = lat[keep], lon[keep], val[keep]
        subsampled = True
    n = len(val)

    mean = float(np.nanmean(val))
    sigma2 = float(np.nanvar(val, ddof=1))

    # Probe a few thousand random pairs to pick max_dist / bin_size
    # (the percentile of the true pairwise distribution). We pass
    # n_obs separately so min_pairs is calibrated against the real
    # all-pairs count, not the probe count.
    rng2 = np.random.default_rng(rng_seed + 1)
    n_probe = min(20000, n * (n - 1) // 2)
    if n_probe > 0:
        ip = rng2.integers(0, n, size=n_probe)
        jp = rng2.integers(0, n, size=n_probe)
        m  = ip != jp
        ip, jp = ip[m], jp[m]
        probe_dist = _haversine_arrays(lat[ip], lon[ip], lat[jp], lon[jp])
    else:
        probe_dist = np.array([0.0])

    auto = _auto_distance_bins(probe_dist, n_obs=n)
    if max_dist_km is None: max_dist_km = auto["max_dist"]
    if bin_size_km is None: bin_size_km = auto["bin_size"]
    if min_pairs   is None: min_pairs   = auto["min_pairs"]

    edges   = np.arange(0.0, max_dist_km + bin_size_km, bin_size_km)
    centres = 0.5 * (edges[:-1] + edges[1:])
    n_bins  = len(centres)

    # Per-bin running sums
    sum_diff2  = np.zeros(n_bins, dtype=np.float64)   # sum of (v_i - v_j)^2
    sum_centd  = np.zeros(n_bins, dtype=np.float64)   # sum of (v_i - m)(v_j - m)
    n_pairs    = np.zeros(n_bins, dtype=np.int64)

    val_c = val - mean

    # Walk the upper triangle in chunks
    for i0 in range(0, n, chunk):
        i1 = min(i0 + chunk, n)
        lat_i = lat[i0:i1, None]
        lon_i = lon[i0:i1, None]
        val_i = val[i0:i1, None]
        valc_i = val_c[i0:i1, None]
        for j0 in range(i0, n, chunk):
            j1 = min(j0 + chunk, n)
            lat_j = lat[j0:j1][None, :]
            lon_j = lon[j0:j1][None, :]
            val_j = val[j0:j1][None, :]
            valc_j = val_c[j0:j1][None, :]

            d = _haversine_arrays(lat_i, lon_i, lat_j, lon_j)
            dv2 = (val_i - val_j) ** 2
            cv  = valc_i * valc_j

            # Mask: take only strict upper triangle (i < j) and
            # distances within max_dist (so we don't waste bins beyond
            # the cap).
            if i0 == j0:
                # Same chunk: keep i < j only
                mask = np.triu(np.ones_like(d, dtype=bool), k=1)
            else:
                mask = np.ones_like(d, dtype=bool)
            mask &= (d < max_dist_km)
            if not mask.any():
                continue

            d_flat   = d[mask]
            dv2_flat = dv2[mask]
            cv_flat  = cv[mask]

            idx = np.digitize(d_flat, edges) - 1
            valid = (idx >= 0) & (idx < n_bins)
            idx, dv2_flat, cv_flat = idx[valid], dv2_flat[valid], cv_flat[valid]

            np.add.at(sum_diff2, idx, dv2_flat)
            np.add.at(sum_centd, idx, cv_flat)
            np.add.at(n_pairs,   idx, 1)

    gamma = np.full(n_bins, np.nan)
    rho   = np.full(n_bins, np.nan)
    enough = n_pairs >= min_pairs
    gamma[enough] = 0.5 * sum_diff2[enough] / n_pairs[enough]
    if sigma2 > 0:
        rho[enough] = (sum_centd[enough] / n_pairs[enough]) / sigma2

    return {
        "bin_centers": centres,
        "n_pairs"    : n_pairs.astype(int),
        "gamma"      : gamma,
        "rho"        : rho,
        "sigma2"     : sigma2,
        "mean"       : mean,
        "max_dist_km": float(max_dist_km),
        "bin_size_km": float(bin_size_km),
        "min_pairs"  : int(min_pairs),
        "n_used"     : int(n),
        "n_total"    : int(n_total),
        "subsampled" : bool(subsampled),
    }


def _haversine_arrays(lat1, lon1, lat2, lon2):
    """
    Element-wise haversine distance (km) between (lat1, lon1) and
    (lat2, lon2). Inputs are broadcastable arrays of any shape;
    output has the broadcast shape.
    """
    la1 = np.radians(lat1); la2 = np.radians(lat2)
    lo1 = np.radians(lon1); lo2 = np.radians(lon2)
    dla = la2 - la1
    dlo = lo2 - lo1
    a = np.sin(dla / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin(dlo / 2.0) ** 2
    return 6371.0 * 2.0 * np.arcsin(np.sqrt(a))


# =============================================================================
#  DATA EXTRACTION
# =============================================================================

def _extract(db_file: str, varno: int, func_col: str,
             flag_criteria_sql: str, id_stn: str) -> pd.DataFrame:
    """Load (lat, lon, vcoord, val, id_stn) for one (db, varno) into a DataFrame."""
    if not _is_sqlite3(db_file):
        return None
    if id_stn in ("all", "join"):
        id_stn_filter = ""
    elif "%" in id_stn or "_" in id_stn:
        id_stn_filter = f" AND h.id_stn LIKE '{id_stn}' "
    else:
        id_stn_filter = f" AND h.id_stn = '{id_stn}' "

    query = f"""
        SELECT h.lat AS lat, h.lon AS lon,
               d.vcoord AS vcoord,
               d.{func_col} AS val,
               h.id_stn AS id_stn
        FROM header h
        JOIN data d USING(id_obs)
        WHERE d.varno = {varno}
          AND d.{func_col} IS NOT NULL
          {flag_criteria_sql}
          {id_stn_filter}
    """
    try:
        with sqlite3.connect(f"file:{db_file}?mode=ro", uri=True) as conn:
            return pd.read_sql_query(query, conn)
    except sqlite3.Error as e:
        sys.stderr.write(f"[ERROR] read {db_file}: {e}\n")
        return None


# =============================================================================
#  PLOTTING
# =============================================================================

def _apply_axes_style(ax) -> None:
    ax.grid(True, which="major", color="#cfd6dc",
            linestyle="-", linewidth=0.6, alpha=0.9)
    ax.minorticks_on()
    ax.tick_params(axis="both", which="major", labelsize=10,
                   color="#34495e", length=4, width=0.8)
    ax.tick_params(axis="both", which="minor",
                   color="#7f8c8d", length=2, width=0.6)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    for sp in ("left", "bottom"):
        ax.spines[sp].set_color("#34495e")
        ax.spines[sp].set_linewidth(0.9)


def _auto_grid_size(lat_span: float, lon_span: float) -> float:
    """
    Pick a reasonable lat/lon bin size from the data extent. Targets
    around 30 boxes along the longest axis so the map doesn't look
    pixelated nor washed out.
    """
    span = max(lat_span, lon_span)
    if span < 1.0:    return 0.05
    if span < 5.0:    return 0.2
    if span < 20.0:   return 0.5
    if span < 60.0:   return 1.0
    if span < 120.0:  return 2.0
    return 5.0


def _plot_global_map(df: pd.DataFrame, base_path: str,
                     exp_name: str, func: str, vc_label: str,
                     grid_size: float, header_meta: str) -> str:
    """
    Auto-zoomed lat/lon bias map. The plot extent fits the actual
    bounding box of the observations (with a 5° margin) instead of
    forcing a global view; ``grid_size`` is auto-picked from the
    data span if not given.
    """
    if df.empty:
        return ""

    # --- adapt to the observed extent -----------------------------------
    lat_min = float(df["lat"].min()); lat_max = float(df["lat"].max())
    lon_min = float(df["lon"].min()); lon_max = float(df["lon"].max())
    lat_span = max(lat_max - lat_min, 1.0)
    lon_span = max(lon_max - lon_min, 1.0)

    # Auto grid size if the caller did not pass one
    if grid_size is None or grid_size <= 0:
        grid_size = _auto_grid_size(lat_span, lon_span)

    df = df.copy()
    df["lat_box"] = np.floor(df["lat"] / grid_size) * grid_size
    df["lon_box"] = np.floor(df["lon"] / grid_size) * grid_size
    map_data = (df.groupby(["lat_box", "lon_box"])["val"]
                  .mean().reset_index())
    if map_data.empty:
        return ""

    vmax = float(np.nanpercentile(np.abs(map_data["val"]), 95)) or 1.0
    vmin = -vmax

    # Aspect-aware figure size so a tall/narrow region doesn't look squashed.
    aspect = max(0.3, min(2.5, lon_span / max(lat_span, 1e-3)))
    fig_w  = max(8.0, min(15.0, 7.0 * aspect))
    fig_h  = max(6.0, min(10.0, fig_w / max(aspect, 0.5)))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))

    # Build a regular 2-D grid that exactly tiles the visible extent.
    # pcolormesh fills cells perfectly (unlike scatter, which uses a
    # fixed point size that does not track the axis units), so the
    # map looks dense even at coarse grid sizes.
    lat_edges = np.arange(
        np.floor(lat_min / grid_size) * grid_size,
        np.ceil(lat_max  / grid_size) * grid_size + grid_size,
        grid_size,
    )
    lon_edges = np.arange(
        np.floor(lon_min / grid_size) * grid_size,
        np.ceil(lon_max  / grid_size) * grid_size + grid_size,
        grid_size,
    )
    grid_z = np.full((len(lat_edges) - 1, len(lon_edges) - 1), np.nan)
    # Fill the grid with the per-cell mean
    lat_idx = np.searchsorted(lat_edges, map_data["lat_box"].values, side="right") - 1
    lon_idx = np.searchsorted(lon_edges, map_data["lon_box"].values, side="right") - 1
    valid_idx = (
        (lat_idx >= 0) & (lat_idx < grid_z.shape[0]) &
        (lon_idx >= 0) & (lon_idx < grid_z.shape[1])
    )
    grid_z[lat_idx[valid_idx], lon_idx[valid_idx]] = (
        map_data["val"].values[valid_idx]
    )
    sc = ax.pcolormesh(
        lon_edges, lat_edges, grid_z,
        cmap=_DIVERGING_CMAP, vmin=vmin, vmax=vmax,
        shading="flat",
    )

    # Extent + 5° margin (or 0.5° margin for very small regions),
    # clipped to the legal range
    margin_lat = 5.0 if lat_span > 10 else 0.5
    margin_lon = 5.0 if lon_span > 10 else 0.5
    ax.set_xlim(max(-180, lon_min - margin_lon),
                min( 180, lon_max + margin_lon))
    ax.set_ylim(max(-90,  lat_min - margin_lat),
                min( 90,  lat_max + margin_lat))

    ax.set_xlabel("Longitude", fontsize=11, color="#34495e")
    ax.set_ylabel("Latitude",  fontsize=11, color="#34495e")
    title = f"Spatial bias map  —  {func.upper()}  •  {exp_name}"
    fig.suptitle(title, fontsize=14, fontweight="600",
                 color="#1f2d3d", y=0.98)
    extent_note = (
        f"Extent: {lat_min:.1f}°→{lat_max:.1f}° lat, "
        f"{lon_min:.1f}°→{lon_max:.1f}° lon    grid: {grid_size}°"
    )
    fig.text(0.5, 0.93, header_meta + "\n" + extent_note,
             ha="center", va="top",
             fontsize=10, color="#52606d", fontstyle="italic")
    _apply_axes_style(ax)

    cb = fig.colorbar(sc, ax=ax, pad=0.02, shrink=0.85)
    cb.set_label(f"Mean {func.upper()}", fontsize=10, color="#34495e")
    cb.outline.set_color("#34495e")

    out = f"{base_path}_map.png"
    fig.subplots_adjust(top=0.86, bottom=0.10, left=0.08, right=0.985)
    plt.savefig(out, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out


def _plot_zonal_section(df: pd.DataFrame, base_path: str,
                        exp_name: str, func: str, header_meta: str,
                        vkind: str, vcotyp: str, grid_size) -> str:
    if df["vcoord"].nunique() < 2:
        return ""

    df = df.copy()

    # Auto-pick lat bin size if the caller did not give one. Same logic
    # as in _plot_global_map but only the lat span matters here, since
    # the y-axis is vertical coordinate, not longitude.
    if grid_size is None or grid_size <= 0:
        lat_span = max(float(df["lat"].max() - df["lat"].min()), 1.0)
        grid_size = _auto_grid_size(lat_span, lat_span)

    df["lat_box"] = np.floor(df["lat"] / grid_size) * grid_size

    # Vertical bin width depends on vcoord magnitude.
    vmax_abs = float(df["vcoord"].abs().max())
    if vkind == "channel" or vmax_abs < 100:
        v_step = 1.0
    elif vmax_abs < 5000:
        v_step = 50.0
    else:
        v_step = 500.0
    df["vcoord_box"] = np.floor(df["vcoord"] / v_step) * v_step
    zonal = (df.groupby(["lat_box", "vcoord_box"])["val"]
               .mean().reset_index())
    if zonal.empty:
        return ""

    vmax = float(np.nanpercentile(np.abs(zonal["val"]), 95)) or 1.0
    vmin = -vmax

    fig, ax = plt.subplots(figsize=(11, 6.5))

    # pcolormesh on a regular grid that tiles the actual data extent.
    lat_min, lat_max = float(df["lat"].min()), float(df["lat"].max())
    vc_min,  vc_max  = float(df["vcoord"].min()), float(df["vcoord"].max())
    lat_edges = np.arange(
        np.floor(lat_min / grid_size) * grid_size,
        np.ceil(lat_max  / grid_size) * grid_size + grid_size,
        grid_size,
    )
    vc_edges = np.arange(
        np.floor(vc_min / v_step) * v_step,
        np.ceil(vc_max  / v_step) * v_step + v_step,
        v_step,
    )
    grid_z = np.full((len(vc_edges) - 1, len(lat_edges) - 1), np.nan)
    lat_idx = np.searchsorted(lat_edges, zonal["lat_box"].values, side="right") - 1
    vc_idx  = np.searchsorted(vc_edges,  zonal["vcoord_box"].values, side="right") - 1
    valid = (
        (lat_idx >= 0) & (lat_idx < grid_z.shape[1]) &
        (vc_idx  >= 0) & (vc_idx  < grid_z.shape[0])
    )
    grid_z[vc_idx[valid], lat_idx[valid]] = zonal["val"].values[valid]
    sc = ax.pcolormesh(
        lat_edges, vc_edges, grid_z,
        cmap=_DIVERGING_CMAP, vmin=vmin, vmax=vmax,
        shading="flat",
    )
    ax.set_xlim(-90, 90)
    ax.set_xlabel("Latitude", fontsize=11, color="#34495e")
    ax.set_ylabel(_vcoord_label(vkind, vcotyp),
                  fontsize=11, color="#34495e")
    if vkind == "pressure":
        ax.invert_yaxis()
    fig.suptitle(
        f"Zonal cross-section  —  {func.upper()}  •  {exp_name}",
        fontsize=14, fontweight="600", color="#1f2d3d", y=0.98,
    )
    fig.text(0.5, 0.93, header_meta, ha="center", va="top",
             fontsize=10, color="#52606d", fontstyle="italic")
    _apply_axes_style(ax)
    cb = fig.colorbar(sc, ax=ax, pad=0.02, shrink=0.85)
    cb.set_label(f"Mean {func.upper()}", fontsize=10, color="#34495e")
    cb.outline.set_color("#34495e")

    out = f"{base_path}_zonal.png"
    fig.subplots_adjust(top=0.86, bottom=0.10, left=0.08, right=0.985)
    plt.savefig(out, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out


def _plot_structure(stn_df: pd.DataFrame, base_path: str,
                    exp_name: str, func: str, header_meta: str,
                    max_dist=None, bin_size=None, min_pairs=None) -> str:
    """
    Three-panel structure plot:

      top-left   : empirical semivariogram γ(h)  vs distance
      top-right  : empirical correlation  ρ(h)  vs distance + exponential fit
      bottom     : bar chart of pairs per bin (sanity check)

    Each binning parameter that is None will be picked from the data.
    A verdict box at the bottom states in plain language whether
    distance is a meaningful predictor of OMP similarity.
    """
    if len(stn_df) < 5:
        return ""

    stats = _empirical_structure(
        stn_df["lat"].values,
        stn_df["lon"].values,
        stn_df["val"].values,
        max_dist_km=max_dist,
        bin_size_km=bin_size,
        min_pairs=min_pairs,
    )
    if stats is None:
        return ""

    h        = stats["bin_centers"]
    gamma    = stats["gamma"]
    rho      = stats["rho"]
    sigma2   = stats["sigma2"]
    bin_size = stats["bin_size_km"]
    min_pairs = stats["min_pairs"]

    fit = _fit_exponential(h, rho)

    fig = plt.figure(figsize=(15, 7.5))
    gs  = fig.add_gridspec(2, 2, height_ratios=[3.5, 1.2], hspace=0.40)
    ax_g = fig.add_subplot(gs[0, 0])
    ax_r = fig.add_subplot(gs[0, 1])
    ax_n = fig.add_subplot(gs[1, :])

    # ---- semivariogram ----------------------------------------------------
    ax_g.plot(h, gamma, marker="o", color=_COLOR_GAMMA,
              linewidth=2.2, markersize=5,
              markerfacecolor=_COLOR_GAMMA, zorder=3)
    ax_g.axhline(sigma2, color="#7f8c8d", linestyle="--", linewidth=0.9,
                 label=f"σ² (global variance) = {sigma2:.3g}")
    ax_g.set_xlabel("Distance between stations (km)",
                    fontsize=11, color="#34495e")
    ax_g.set_ylabel(r"Semivariance  $\gamma(h)$",
                    fontsize=11, color="#34495e")
    ax_g.set_title("Semivariogram", fontsize=12, fontweight="600",
                   color="#1f2d3d", pad=8)
    ax_g.legend(loc="lower right", frameon=False, fontsize=9)
    _apply_axes_style(ax_g)

    # ---- correlation curve + fit -----------------------------------------
    ax_r.plot(h, rho, marker="o", color=_COLOR_RHO,
              linewidth=2.2, markersize=5,
              markerfacecolor=_COLOR_RHO, zorder=3,
              label="empirical ρ(h)")
    ax_r.axhline(0.0, color="#7f8c8d", linestyle=":", linewidth=0.9)
    ax_r.axhline(1.0/np.e, color="#c0392b", linestyle="--", linewidth=0.8,
                 label=f"1/e ≈ {1.0/np.e:.3f}")
    if fit["valid"] and fit["L"] is not None:
        h_fine = np.linspace(0, h.max(), 200)
        rho_fit = np.exp(-h_fine / fit["L"])
        ax_r.plot(h_fine, rho_fit, color="#1f2d3d",
                  linewidth=1.8, linestyle="-", alpha=0.7, zorder=2,
                  label=f"fit: exp(−h / {fit['L']:.0f} km)")
        # Vertical line at the fitted L
        ax_r.axvline(fit["L"], color="#1f2d3d", linestyle=":",
                     linewidth=0.9, alpha=0.6)
        ax_r.text(fit["L"], 1.0/np.e + 0.04, f"L = {fit['L']:.0f} km",
                  fontsize=9, color="#1f2d3d", fontweight="600",
                  ha="left", va="bottom",
                  bbox=dict(boxstyle="round,pad=0.2",
                            fc="white", ec="none", alpha=0.85))
    elif fit.get("crossing_1e") is not None:
        # No exp fit, but we still see a 1/e crossing - mark it
        c = fit["crossing_1e"]
        ax_r.axvline(c, color="#c0392b", linestyle=":",
                     linewidth=0.9, alpha=0.6)
        ax_r.text(c, 1.0/np.e + 0.04, f"1/e at {c:.0f} km",
                  fontsize=9, color="#c0392b", fontweight="600",
                  ha="left", va="bottom",
                  bbox=dict(boxstyle="round,pad=0.2",
                            fc="white", ec="none", alpha=0.85))

    ax_r.set_xlabel("Distance between stations (km)",
                    fontsize=11, color="#34495e")
    ax_r.set_ylabel(r"Correlation  $\rho(h)$",
                    fontsize=11, color="#34495e")
    ax_r.set_title("Spatial correlation", fontsize=12, fontweight="600",
                   color="#1f2d3d", pad=8)
    rho_min = (np.nanmin(rho) - 0.05
               if not np.all(np.isnan(rho)) else -0.3)
    ax_r.set_ylim(min(-0.3, rho_min), 1.05)
    ax_r.legend(loc="upper right", frameon=False, fontsize=9)
    _apply_axes_style(ax_r)

    # ---- pairs per bin (log) ---------------------------------------------
    npair = stats["n_pairs"].astype(float)
    npair[npair == 0] = np.nan
    ax_n.bar(h, npair, width=bin_size * 0.85, align="center",
             color="#bdc3c7", edgecolor="#7f8c8d", linewidth=0.5)
    ax_n.axhline(min_pairs, color="#c0392b", linestyle="--", linewidth=0.8,
                 label=f"min pairs = {min_pairs} (auto)")
    ax_n.set_yscale("log")
    ax_n.set_xlabel("Distance between stations (km)",
                    fontsize=10, color="#34495e")
    ax_n.set_ylabel("Pairs per bin", fontsize=10, color="#34495e")
    ax_n.legend(loc="upper right", frameon=False, fontsize=9)
    _apply_axes_style(ax_n)

    # ---- verdict + parameters --------------------------------------------
    fig.suptitle(
        f"Spatial structure of {func.upper()}  —  {exp_name}",
        fontsize=14, fontweight="600", color="#1f2d3d", y=0.985,
    )
    # Two-line header: meta + auto-binning info + verdict
    n_used    = stats.get("n_used", "?")
    n_total   = stats.get("n_total", n_used)
    sub_note  = ""
    if stats.get("subsampled"):
        sub_note = (f"  •  {n_used:,} of {n_total:,} obs sampled "
                    f"(uniform random)")
    else:
        sub_note = f"  •  {n_used:,} obs (all-pairs)"

    auto_info = (
        f"max distance: {stats['max_dist_km']:.0f} km  •  "
        f"bin size: {stats['bin_size_km']:.0f} km  •  "
        f"min pairs: {stats['min_pairs']}{sub_note}"
    )
    fig.text(0.5, 0.945, header_meta, ha="center", va="top",
             fontsize=10, color="#52606d", fontstyle="italic")
    fig.text(0.5, 0.918, auto_info, ha="center", va="top",
             fontsize=9, color="#7f8c8d")

    # Verdict at the very bottom (above the bar chart)
    verdict_color = "#27ae60" if fit["valid"] else "#c0392b"
    fig.text(0.5, 0.005, fit["diagnosis"], ha="center", va="bottom",
             fontsize=11, color=verdict_color, fontweight="600",
             bbox=dict(boxstyle="round,pad=0.4",
                       fc="white", ec=verdict_color, linewidth=1.2))

    out = f"{base_path}_structure.png"
    fig.subplots_adjust(top=0.88, bottom=0.10, left=0.06, right=0.985)
    plt.savefig(out, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out


# =============================================================================
#  CORE WORKER
# =============================================================================

def _process_task(exp_path, exp_name, family, flag_crit, func, varno,
                  dt_start, dt_end, pathwork, grid_size, id_stn, channel,
                  max_dist, bin_size, min_pairs):
    """Aggregate cycles, then for every (station, channel) bucket render plots."""
    # Same calling convention as progps.py: pass the bare string, not a list.
    sql_flag = pikobs.flag_criteria(flag_crit)
    func_col = _FUNC_COLS.get(func.lower(), "obsvalue")

    # VCOTYP from pikobs.family - used for axis labelling
    fam_info = pikobs.family(family)
    # pikobs.family returns (FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP)
    vcotyp   = fam_info[5] if len(fam_info) > 5 else ""
    vkind    = _classify_vcoord(vcotyp)

    # Walk the date range, accumulate dataframes
    parts = []
    current = dt_start
    while current <= dt_end:
        fdate = current.strftime("%Y%m%d%H")
        db = _resolve_input(exp_path, fdate, family, exp_name)
        if db:
            d = _extract(db, varno, func_col, sql_flag, id_stn)
            if d is not None and not d.empty:
                parts.append(d)
        current += timedelta(hours=6)

    if not parts:
        sys.stderr.write(
            f"[skip] no data for exp={exp_name} fam={family} varno={varno}\n"
        )
        return []

    full = pd.concat(parts, ignore_index=True)
    safe_crit = str(flag_crit).replace(" ", "_")
    date_str  = (f"{dt_start.strftime('%Y%m%d%H')}_"
                 f"{dt_end.strftime('%Y%m%d%H')}")

    # Station bucketing
    if id_stn == "all":
        stn_groups = [(s, full[full["id_stn"] == s])
                      for s in full["id_stn"].unique()]
    elif "%" in id_stn or "_" in id_stn:
        label = re.sub(r"[^A-Za-z0-9]", "", id_stn) or "join"
        stn_groups = [(label, full)]
    else:
        stn_groups = [("join", full)]

    # Channel / vcoord bucketing
    def chan_groups(df_):
        if channel == "all":
            return [(v, df_[df_["vcoord"] == v])
                    for v in sorted(df_["vcoord"].unique())]
        return [("join", df_)]

    items = []   # records for the viewer
    for stn_label, df_stn in stn_groups:
        if df_stn.empty:
            continue
        for vc_label, df_vc in chan_groups(df_stn):
            if df_vc.empty or len(df_vc) < 5:
                continue

            vc_label_str = str(vc_label) if vc_label != "join" else "join"
            suffix = (f"{stn_label}_{varno}_{vc_label_str}_"
                      f"{date_str}_{safe_crit}")
            base = os.path.join(
                pathwork, family,
                f"spatial_{func}_{family}_{exp_name}_{suffix}",
            )
            os.makedirs(os.path.dirname(base), exist_ok=True)

            header_meta = (
                f"varno {varno}    fonction {func.upper()}    "
                f"flag {flag_crit}    station {stn_label}    "
                f"channel {vc_label_str}    "
                f"period {dt_start:%Y%m%d%H} → {dt_end:%Y%m%d%H}"
            )

            map_png = _plot_global_map(
                df_vc, base, exp_name, func, vc_label_str,
                grid_size, header_meta,
            )
            zonal_png = _plot_zonal_section(
                df_vc, base, exp_name, func, header_meta,
                vkind, vcotyp, grid_size,
            )
            # No aggregation: pass every raw observation. The structure
            # function will subsample if N is too large for a full
            # all-pairs computation.
            struct_png = _plot_structure(
                df_vc[["lat", "lon", "val"]].rename(columns={"val": "val"}),
                base, exp_name, func, header_meta,
                max_dist=max_dist, bin_size=bin_size, min_pairs=min_pairs,
            )

            common = {
                "experiment": exp_name,
                "family"    : family,
                "varno"     : str(varno),
                "id_stn"    : str(stn_label),
                "channel"   : vc_label_str,
                "function"  : func,
                "criteria"  : str(flag_crit),
            }
            for plot_kind, png in (
                ("map", map_png), ("zonal", zonal_png),
                ("structure", struct_png),
            ):
                if png and os.path.isfile(png):
                    items.append({
                        **common,
                        "plot": plot_kind,
                        "filename": os.path.basename(png),
                    })

    return items


# =============================================================================
#  MAIN ORCHESTRATOR
# =============================================================================

def make_spatial(files_in, names_in, pathwork, datestart, dateend, regions,
                 families, flag_criteria, fonctions, varnos, grid_size,
                 id_stn, channel, n_cpus,
                 max_dist=None, bin_size=None, min_pairs=None):

    def _auto(v): return "auto" if v is None else v

    print("=" * 78)
    print("  PIKOBS SPATIAL DIAGNOSTIC PIPELINE")
    print(f"  pathwork    : {pathwork}")
    print(f"  experiments : {names_in}")
    print(f"  period      : {datestart} → {dateend}")
    print(f"  grid_size   : {_auto(grid_size)}°    "
          f"(auto adapts to data extent)")
    print(f"  max_dist    : {_auto(max_dist)} km   "
          f"bin_size: {_auto(bin_size)} km")
    print(f"  min_pairs   : {_auto(min_pairs)}")
    print("=" * 78)

    _clean_pathwork_preserving_cache(pathwork)
    for fam in families:
        os.makedirs(os.path.join(pathwork, fam), exist_ok=True)

    dt_start = datetime.datetime.strptime(datestart, "%Y%m%d%H")
    dt_end   = datetime.datetime.strptime(dateend,   "%Y%m%d%H")

    # Validate at least one input file is real SQLite, per (exp, family,
    # date). Be tolerant: missing files are warned, not fatal.
    sample_checked = 0
    for exp_path, exp_name in zip(files_in, names_in):
        for fam in families:
            db = _resolve_input(
                exp_path, dt_start.strftime("%Y%m%d%H"), fam, exp_name,
            )
            if db:
                sample_checked += 1
    if sample_checked == 0:
        sys.exit(
            "[ERROR] none of the (experiment, family, datestart) tuples "
            "matched a valid SQLite file. Did you run pikobsburp2db?"
        )

    # Resolve which varnos apply to each family. The user can override
    # via --varnos, otherwise we read the default list returned by
    # pikobs.family() — same convention as progps.py.
    def _resolve_varnos_for(fam: str) -> list:
        if varnos:
            return list(varnos)
        try:
            fam_info = pikobs.family(fam)   # (FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP)
            element  = fam_info[4]
        except Exception as e:
            sys.stderr.write(
                f"[skip] cannot resolve default varnos for family={fam!r}: {e}\n"
            )
            return []
        if element is None or element == "":
            sys.stderr.write(
                f"[skip] pikobs.family({fam!r}) returned no default varnos.\n"
            )
            return []
        # `element` may be "12001,12004,12192" or just "15036". Split on commas.
        out = []
        for piece in str(element).split(","):
            piece = piece.strip()
            if not piece:
                continue
            try:
                out.append(int(piece))
            except ValueError:
                sys.stderr.write(
                    f"[warn] non-integer default varno {piece!r} for family={fam}; skipped.\n"
                )
        return out

    tasks = []
    for exp_path, exp_name in zip(files_in, names_in):
        for family in families:
            family_varnos = _resolve_varnos_for(family)
            if not family_varnos:
                continue
            for flag_crit in flag_criteria:
                for func in fonctions:
                    for varno in family_varnos:
                        tasks.append((
                            exp_path, exp_name, family, flag_crit, func,
                            varno, dt_start, dt_end, pathwork, grid_size,
                            id_stn, channel, max_dist, bin_size, min_pairs,
                        ))
    if not tasks:
        sys.exit(
            "[ERROR] no tasks to run. Check that --family is correct and "
            "(if --varnos is omitted) that pikobs.family() returns at least "
            "one default varno for each requested family."
        )
    print(f"[pipeline] {len(tasks)} tasks queued "
          f"(varnos source: {'CLI' if varnos else 'pikobs.family() defaults'})")

    if n_cpus <= 1:
        all_items = []
        for t in tasks:
            all_items.extend(_process_task(*t))
    else:
        with Client(processes=True, threads_per_worker=1,
                    n_workers=n_cpus, silence_logs=40):
            results = dask.compute(*[
                dask.delayed(_process_task)(*t) for t in tasks
            ])
        all_items = [it for sub in results for it in sub]

    print(f"[pipeline] generated {len(all_items)} PNG records")

    # --- Generate the universal HTML viewer -------------------------------
    if all_items:
        try:
            from pikobs.web.viewer import generate_web
        except ImportError:
            # Fallback: viewer.py side-by-side with this file
            import importlib.util, pathlib
            here = pathlib.Path(__file__).resolve().parent
            for cand in (here / "viewer.py",
                         here.parent / "web" / "viewer.py",
                         here.parent / "viewer.py"):
                if cand.is_file():
                    spec = importlib.util.spec_from_file_location(
                        "pikobs_viewer_local", cand,
                    )
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    generate_web = module.generate_web
                    break
            else:
                sys.stderr.write(
                    "[viewer] cannot import pikobs.web.viewer; skipping HTML\n"
                )
                generate_web = None

        if generate_web is not None:
            run_label = " vs ".join(names_in) if len(names_in) > 1 else names_in[0]
            generate_web(
                items=all_items,
                keys=["experiment", "family", "id_stn", "varno",
                      "channel", "function", "criteria", "plot"],
                output_path=os.path.join(pathwork,
                                         "pikobs_spatial_viewer.html"),
                title="Pikobs Spatial Analysis Viewer",
                subtitle=f"{run_label}  |  {datestart} → {dateend}",
                image_subdir_key="family",
                value_labels={
                    "plot": {"map":       "Global map",
                             "zonal":     "Zonal section",
                             "structure": "Structure (γ + ρ)"},
                },
                key_labels={
                    "experiment": "Experiment",
                    "family"    : "Family",
                    "id_stn"    : "Station",
                    "varno"     : "Varno",
                    "channel"   : "Channel",
                    "function"  : "Function",
                    "criteria"  : "Criteria",
                    "plot"      : "Plot",
                },
                issues_url="https://gitlab.science.gc.ca/dlo001/Pikobs",
            )

    print(f"[pipeline] done. Output directory: {pathwork}")


# =============================================================================
#  CLI
# =============================================================================

def arg_call():
    parser = argparse.ArgumentParser(
        description="Pikobs spatial diagnostic pipeline (single experiment).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--path_experience_files", nargs="+", required=True)
    parser.add_argument("--experience_name",       nargs="+", required=True)
    parser.add_argument("--pathwork",              required=True)
    parser.add_argument("--datestart",             required=True)
    parser.add_argument("--dateend",               required=True)
    parser.add_argument("--region",         nargs="+", default=["Monde"])
    parser.add_argument("--family",         nargs="+", required=True)
    parser.add_argument("--flags_criteria", nargs="+", required=True)
    parser.add_argument("--fonction",       nargs="+", required=True)
    parser.add_argument(
        "--varnos", nargs="+", default=[], type=int,
        help=("Variable codes to plot. Optional. If omitted, the "
              "default varnos returned by pikobs.family() for each "
              "--family are used (same behaviour as progps.py).")
    )
    parser.add_argument("--id_stn",  default="join")
    parser.add_argument("--channel", default="join")
    parser.add_argument(
        "--grid_size", default=None, type=float,
        help=("Lat/lon bin size in degrees. Default: auto-picked from "
              "the data extent (~30 boxes along the longest axis).")
    )
    parser.add_argument(
        "--max_dist", default=None, type=float,
        help=("Max distance in the structure plot, km. Default: 80th "
              "percentile of actual pairwise distances.")
    )
    parser.add_argument(
        "--bin_size", default=None, type=float,
        help=("Distance bin width, km. Default: max_dist / 25 "
              "rounded to a friendly number.")
    )
    parser.add_argument(
        "--corr_min_pairs", default=None, type=int,
        help=("Minimum pairs per bin; below this the bin is dropped. "
              "Default: max(30, total_pairs / 500).")
    )
    parser.add_argument("--n_cpus",  default=1, type=int,
                        help="Dask worker count (default 1)")

    args = parser.parse_args()

    if len(args.path_experience_files) != len(args.experience_name):
        sys.exit(
            f"[ERROR] {len(args.path_experience_files)} paths but "
            f"{len(args.experience_name)} names."
        )

    sys.exit(make_spatial(
        args.path_experience_files, args.experience_name,
        args.pathwork, args.datestart, args.dateend,
        args.region, args.family, args.flags_criteria, args.fonction,
        args.varnos, args.grid_size, args.id_stn, args.channel,
        args.n_cpus,
        max_dist=args.max_dist, bin_size=args.bin_size,
        min_pairs=args.corr_min_pairs,
    ))


if __name__ == "__main__":
    arg_call()
