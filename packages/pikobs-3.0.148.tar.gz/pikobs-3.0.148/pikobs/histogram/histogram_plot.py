import os
import sys
import json
import sqlite3
import argparse
import datetime
from typing import List

import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

import dask
from dask.distributed import Client

import pikobs

# =============================================================================
#  MATH HELPERS
# =============================================================================

def calculate_gaussian_pdf(x, mu, sigma):
    """Calculates the Probability Density Function (PDF) for a Normal distribution."""
    if sigma == 0:
        return np.zeros_like(x)
    return (1 / (sigma * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x - mu) / sigma) ** 2)

# =============================================================================
#  CORE PLOTTING & JSON EXPORT
# =============================================================================

#!/usr/bin/env python3
"""
Pikobs Supreme Histogram Plotter
================================
Genera un histograma dual de alta precisión con panel de diferencias
y exporta los datos para el visor web universal.
"""

import os
import json
import sqlite3
import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

def calculate_gaussian_pdf(x, mu, sigma):
    """Calcula la Función de Densidad de Probabilidad (PDF) de una Gaussiana."""
    if sigma == 0:
        return np.zeros_like(x)
    return (1 / (sigma * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x - mu) / sigma) ** 2)

def histogram_plot(
    region: str, family: str, id_stn: str, datestart: str, dateend: str,
    pathwork: str, flag_criteria: str, vcoord: str, filesin: list,
    namesin: list, varno: int
):
    """
    Función core de dibujo. Genera el PNG y devuelve los metadatos para
    el visor HTML generado por make_histogram.
    """
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10})
    
    # 1. Layout de 2 paneles (Principal + Diferencia)
    fig = plt.figure(figsize=(12, 10), facecolor='white')
    gs = gridspec.GridSpec(2, 1, height_ratios=[3, 1], hspace=0.12)
    ax_main = fig.add_subplot(gs[0])
    ax_diff = fig.add_subplot(gs[1], sharex=ax_main)

    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()

    # 2. Extracción de Datos
    valid_results = []
    colors = ['#2E86C1', '#E74C3C', '#27AE60', '#F39C12']

    for i, fpath in enumerate(filesin):
        alias = f"db{i+1}"
        try:
            cursor.execute(f"ATTACH DATABASE '{fpath}' AS {alias}")
            query = f"""
                SELECT bin_range, omp_frequency 
                FROM {alias}.moyenne 
                WHERE varno={varno} AND id_stn='{id_stn}' 
                ORDER BY bin_range
            """
            cursor.execute(query)
            data = cursor.fetchall()
            
            if data:
                bins = np.array([r[0] for r in data])
                counts = np.array([r[1] for r in data])
                if np.sum(counts) > 0:
                    valid_results.append({
                        'name': namesin[i], 'bins': bins, 'counts': counts,
                        'color': colors[i % len(colors)]
                    })
        except Exception as e:
            print(f"[-] Error cargando {namesin[i]} en histogram_plot: {e}")

    if len(valid_results) == 0:
        plt.close(fig); conn.close()
        return None

    # 3. Alineación Matemática de Bins (Solución al error de Broadcast de Numpy)
    common_bins = np.unique(np.concatenate([res['bins'] for res in valid_results]))
    all_counts = []

    for res in valid_results:
        aligned_counts = np.zeros(len(common_bins))
        indices = np.searchsorted(common_bins, res['bins'])
        aligned_counts[indices] = res['counts']
        
        res['bins'] = common_bins
        res['counts'] = aligned_counts
        all_counts.append(aligned_counts)

    # --- Preparar JSON Export ---
    export_data = {
        "metadata": {
            "id_stn": id_stn, "varno": varno, "family": family,
            "region": region, "date": datestart, "flag": flag_criteria
        },
        "bins": common_bins.tolist(), 
        "experiments": []
    }

    # 4. Renderizado (Histogramas + Gaussianas)
    for res in valid_results:
        # Dibujar área escalonada
        ax_main.step(res['bins'], res['counts'], where='mid', color=res['color'], lw=1.5, alpha=0.8, zorder=3)
        ax_main.fill_between(res['bins'], res['counts'], step="mid", alpha=0.15, color=res['color'])
        
        # Calcular y escalar Gaussiana
        mu = np.average(res['bins'], weights=res['counts'])
        sigma = np.sqrt(np.average((res['bins'] - mu)**2, weights=res['counts']))
        x_smooth = np.linspace(res['bins'].min(), res['bins'].max(), 500)
        pdf_math = calculate_gaussian_pdf(x_smooth, mu, sigma)
        
        max_pdf = np.max(pdf_math)
        y_scaled = pdf_math * (np.max(res['counts']) / max_pdf) if max_pdf > 0 else pdf_math
        
        ax_main.plot(x_smooth, y_scaled, color=res['color'], lw=3, ls='--', 
                     label=f"{res['name']} ($\mu={mu:.2f}$, $\sigma={sigma:.2f}$)")
        
        export_data["experiments"].append({
            "name": res['name'],
            "counts": res['counts'].tolist(),
            "stats": {"mu": round(mu, 4), "sigma": round(sigma, 4)}
        })

    # 5. Panel de Diferencias (Análisis Residual)
    if len(all_counts) >= 2:
        diff = all_counts[1] - all_counts[0]
        bar_colors = ['#E74C3C' if x > 0 else '#2E86C1' for x in diff]
        ax_diff.bar(common_bins, diff, width=(common_bins[1]-common_bins[0]), 
                    color=bar_colors, alpha=0.7)
        ax_diff.set_ylabel(f"Diff ({namesin[1]} - {namesin[0]})", fontsize=9, fontweight='bold')
        ax_diff.axhline(0, color='black', lw=1)
    else:
        ax_diff.text(0.5, 0.5, "Comparación requiere min. 2 experimentos", ha='center', transform=ax_diff.transAxes)

    # 6. Estética y Textos
    ax_main.set_title(f"OMP RESIDUAL SUPREME ANALYZER: {id_stn}\nFamily: {family} | Varno: {varno} | Region: {region}", 
                      fontsize=14, fontweight='bold', loc='left', pad=20, color='#2C3E50')
    ax_main.axvline(0, color='black', lw=1.2, ls='-')
    ax_main.legend(loc='upper right', frameon=True, shadow=True, fontsize=9)
    ax_main.set_ylabel("Observation Frequency", fontweight='bold')
    ax_diff.set_xlabel("Residual (Observation - Prediction)", fontweight='bold')
    
    for ax in [ax_main, ax_diff]:
        ax.grid(True, ls=':', alpha=0.6)
        for sp in ['top', 'right']: ax.spines[sp].set_visible(False)

    # 7. Guardado (PNG y JSON)
    os.makedirs(os.path.join(pathwork, family), exist_ok=True)
    
    filename = f"hist_{id_stn}_{varno}_{flag_criteria}_{datestart}_{dateend}_{region}.png"
    save_path = os.path.join(pathwork, family, filename)
    plt.savefig(save_path, bbox_inches='tight', dpi=200)
    
    # Liberar memoria agresivamente para evitar colapsos en Dask
    fig.clf()
    plt.close('all')
    conn.close()
    
    json_filename = filename.replace('.png', '.json')
    json_path = os.path.join(pathwork, family, json_filename)
    with open(json_path, 'w') as f:
        json.dump(export_data, f)

    # 8. Devolver los metadatos al orquestador make_histogram
    return {
        "family": family,
        "region": region,
        "surface": "world", # o la superficie que uses
        "id_stn": id_stn,
        "varno": str(varno),
        "vcoord": str(vcoord),
        "criteria": flag_criteria,
        "filename": f"{filename}"
    }
