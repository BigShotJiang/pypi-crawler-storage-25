"""
==================================
Flag Distribution Analysis (Flags)
==================================

The **Pikobs Flags Suite** is a diagnostic tool designed to provide deep insights into the Quality Control (QC) and Assimilation status of meteorological observations. By evaluating the 24-bit flag criteria assigned to each observation, it generates comprehensive time series reports detailing the exact fate of the data (e.g., assimilation percentages and specific rejection reasons).

Core Visualization: Flag Distribution Time Series
-------------------------------------------------

The engine decodes complex SQLite bitmasks to track the distribution of data across critical stages—such as Background Check, Assimilated, or rejected due to Clouds, Topography, or Blacklists.

.. image:: _static/flags_plot.png
   :align: center
   :alt: Flags Distribution Time Series Plot
   :width: 900px

**Plot Breakdown and Scientific Objectives:**

* **1. Top Panel (Time Series Stacked Bar Chart)**
  Displays the normalized percentage of different bitmask combinations at 6-hour assimilation intervals. This helps identify sudden drops in data quality, instrument anomalies, or changes in assimilation behavior over time.

* **2. Bottom Left (Bit Legend & Statistics)**
  Lists the exact active bit combinations (e.g., ``Bits [6, 12]``), their overall average percentage across the period, and the total raw number of observations that received that specific flag combination.

* **3. Bottom Right (Diagnostic Summary Pie Charts)**
  Groups the raw bits into meteorological concepts. It instantly visualizes the percentage of data successfully **Assimilated** (Bit 12) versus data rejected by the **Background Check** (Bit 9), **Clouds** (Bit 23), **Topography** (Bit 18), or **Blacklists** (Bit 8).

Interactive Web Environment
---------------------------

Beyond static plots, Pikobs automatically generates a **Smart Web Viewer**. This tool is designed for rapid multi-dimensional and comparative analysis:

* **Dynamic Filtering:** The interface only displays valid combinations of satellite, channel, and region available in your dataset. *(Note: Criteria/Flag filtering is omitted here as this module analyzes all flags simultaneously).*
* **Flip-Flop Mode:** Allows instant toggling between two different plots to detect subtle changes without losing visual focus.
* **Access:** The generated interactive viewer is saved in your output directory and linked directly here:

🔗 **Explore the Viewer:** `Interactive Web Viewer <https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobsflag/pikobs_flags_viewer.html>`_


HPC Execution & Real-Time Monitoring
------------------------------------

To maintain system stability on Environment and Climate Change Canada (ECCC) clusters, always execute diagnostic tasks using a dedicated compute node.

**1. Initialize Interactive Session:**

.. code-block:: bash

    qsub -I -X -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb -l place=scatter -l walltime=6:0:0

**2. Generate Diagnostics Command:**

.. code-block:: bash

    python -c 'import pikobs; pikobs.flags.arg_call()' \\
        --path_experience_files   /home/dlo001/sites8/Data_pikobs/monitoring0/ \\
        --experience_name         g0 \\
        --pathwork                /your/custom/output/path \\
        --datestart               2026021000 \\
        --dateend                 2026021700 \\
        --region                  Monde Canada \\
        --family                  to_amsua_allsky atms_allsky \\
        --id_stn                  all \\
        --channel                 all \\
        --n_cpu                   40

*(Note: The* ``--flags_criteria`` *parameter is not required here, as the module automatically processes the entire 24-bit spectrum).*

**3. Expected Shell Output (Batch Monitoring):**

When executing the command above, you will see the parallel processing progress in your terminal:

.. code-block:: text

    [PIKOBS] Initializing Flags Diagnostic Engine...
    [INFO] Detected 40 CPUs for parallel processing.
    [DB] Connecting to Experience: g0
    [PARALLEL] Decoding bitmasks for family: atms_allsky...
    [PARALLEL] Generating Time Series and Pie Charts for METOP-1...
    [WEB] Compiling interactive web viewer data...
    ✅ Plot successfully saved: /your/custom/output/path/atms_allsky/flags_vcoord_1_id_stn_METOP-1_119_Monde_atms_allsky.png
    ✅ Advanced Flag Web viewer successfully created at: /your/custom/output/path/pikobs_flags_viewer.html
    [DONE] All flag distributions completed successfully.


Support and Issues
------------------

Pikobs is maintained for the ECCC community. For bug reports, feature requests, or technical issues, please use the official GitLab repository:

🔗 **GitLab Issues:** `https://gitlab.science.gc.ca/dlo001/Pikobs <https://gitlab.science.gc.ca/dlo001/Pikobs>`_

----

*Document generated automatically for the Pikobs Atmospheric Science Project.*

"""

#!/usr/bin/python3
import sqlite3
import pikobs
import re
import os
from  dask.distributed import Client
import numpy as np
import sqlite3
import os
import re
import sqlite3
from  datetime import datetime, timedelta
import glob
import sqlite3
import pikobs  # Assuming this is a custom module for region processing

def create_and_insert_flag_observations(input_file, output_file, region,pathwork,family):
    # Connect to the input SQLite file
    conn_input = sqlite3.connect(input_file)
    basename = os.path.basename(input_file)
    cursor_input = conn_input.cursor()

    # Get region criteria
    LAT1, LAT2, LON1, LON2 = pikobs.regions(region)
    LATLONCRIT = pikobs.generate_latlon_criteria(LAT1, LAT2, LON1, LON2)
    LATLONCRIT = LATLONCRIT.strip().removeprefix("and").strip()
    # Connect to the output SQLite file with optimizations
    conn_output = sqlite3.connect(f'{pathwork}/{family}/{output_file}', uri=True, isolation_level=None, timeout=99999)
    conn_output.execute('PRAGMA synchronous = OFF')  # Turn off synchronous mode for faster writes
    conn_output.execute('PRAGMA journal_mode = MEMORY')  # Use memory journal mode for faster writes
    cursor_output = conn_output.cursor()

    # Create a table in the output database if it does not exist
    cursor_output.execute('''
        CREATE TABLE IF NOT EXISTS flag_observations (
            date TEXT,
            flag INTEGER,
            num_data_entries INTEGER,
            id_stn INTEGER,
            varno interger,
            vcoord integer
        )
    ''')

    # Query to get the required data
    query = f'''
        SELECT 
    {basename[0:10]},
    flag, 
    COUNT(*) AS num_data_entries, 
    id_stn, 
    varno,
    vcoord
    
FROM 
    data 
natural join  
    header 
    where {LATLONCRIT}
GROUP BY 
    date, 
    varno,
    flag, 
    id_stn,
    vcoord;
    '''
    # Execute the query and fetch results
    cursor_input.execute(query)
    results = cursor_input.fetchall()

    # Insert results into the output database in batches
    cursor_output.executemany('''
        INSERT INTO flag_observations (date, flag, num_data_entries, id_stn, varno, vcoord)
        VALUES (?, ?, ?, ?, ?,?)
    ''', results)

    # Commit and close the connections
    conn_input.close()
    conn_output.commit()
    conn_output.close()



def create_data_list_cardio(datestart1, 
                            dateend1,
                            family,
                            pathin, 
                            pathwork,
                            flag_criteria,
                            id_stn,
                            channel,
                            region_seleccionada):
    
    data_list_cardio = []

    # Convert datestart and dateend to datetime objects
    datestart = datetime.strptime(datestart1, '%Y%m%d%H')
    dateend = datetime.strptime(dateend1, '%Y%m%d%H')

    # Initialize the current_date to datestart
    current_date = datestart

    # Define a timedelta of 6 hours
    delta = timedelta(hours=6)
    FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)

    element_array = np.array([float(x) for x in element.split(',')])
    for varno in element_array:
   #  print ("VCOORD", vcoord, element, type(element))
     # Iterate through the date range in 6-hour intervals
     while current_date <= dateend:
        # Format the current date as a string
        formatted_date = current_date.strftime('%Y%m%d%H')

        # Build the file name using the date and family
        filename = f'{formatted_date}_{family}'

        file_path_name = f'{pathin}/{filename}'
        conn = sqlite3.connect(file_path_name)
        # Create a cursor to execute SQL queries
        cursor = conn.cursor()

        #  Create a new dictionary and append it to the list
        data_dict = {'family': family,
                     'filein': f'{pathin}/{filename}',
                     'db_new': f'{pathwork}/cardio_{datestart1}_{dateend1}_{flag_criteria}_{family}.db',
                     'region': region_seleccionada,
                     'flag_criteria': flag_criteria,
                     'varno':  varno,
                     'vcoord': channel,
                     'id_stn': id_stn}
        data_list_cardio.append(data_dict)
        conn.close()

        # Update the current_date in the loop by adding 6 hours
        current_date += delta

    return data_list_cardio


def get_station_ids(cursor, id_stn):
    if id_stn[0] == 'all':
        cursor.execute("SELECT DISTINCT id_stn FROM data natural join header;")
        return [item[0] for item in cursor.fetchall()]
    else:
        
        return np.array(id_stn)

def fetch_channels_and_varno(cursor, idstn, channel):
    criter = f'WHERE id_stn = "{idstn}"'
    if channel[0] == 'all':
        query = f"SELECT DISTINCT vcoord, varno FROM data natural join header {criter} ORDER BY vcoord ASC;"
        cursor.execute(query)
        return cursor.fetchall()
    if channel[0] == 'join':
        return channel, idstn

def create_data_list_plot2(datestart1, dateend1, family, pathwork, region, id_stn, channel):
    data_list_plot = []
    import glob
    filedb = f'{pathwork}/output_file{region}.db'
    try:
        with sqlite3.connect(filedb) as conn:
            cursor = conn.cursor()
            id_stns = get_station_ids(cursor, id_stn)

            for idstn in id_stns:
                channels_varno = fetch_channels_and_varno(cursor, idstn, channel)
                for chan, varno in channels_varno:
                    data_dict_plot = {
                        'id_stn': idstn,
                        'vcoord': chan,
                        'varno': varno
                    }
                    data_list_plot.append(data_dict_plot)
    except sqlite3.Error as e:
        print(f"Database error: {e}")
    except Exception as e:
        print(f"Error: {e}")
    return data_list_plot
import sqlite3

def create_data_list_plot(familys, pathwork, regions, id_stn, vcoord):
    data_dict_plot = []
    
    # Extraemos las banderas una sola vez para evitar accesos repetidos a la lista
    join_vcoord = vcoord[0] == 'join'
    join_id_stn = id_stn[0] == 'join'
    print (familys, pathwork, regions, id_stn, vcoord)
    for region in regions:
        for family in familys:
            filedb = f'{pathwork}/{family}/output_file{region}_{family}.db'
            
            try:
                with sqlite3.connect(filedb) as conn:
                    cursor = conn.cursor()
                    
                    # 1. Obtenemos varnos una sola vez
                    cursor.execute("SELECT DISTINCT varno FROM flag_observations")
                    varnos = [v[0] for v in cursor.fetchall()]

                    for varno in varnos:
                        # Caso 1: Ambos son 'join'
                        if join_vcoord and join_id_stn:
                            data_dict_plot.append({
                                'id_stn': 'join', 'vcoord': 'join', 'varno': varno,
                                'region': region, 'family': family
                            })

                        # Caso 2: vcoord join, id_stn all
                        elif join_vcoord and not join_id_stn:
                            cursor.execute("SELECT DISTINCT id_stn FROM flag_observations WHERE varno = ?", (varno,))
                            for (stn,) in cursor.fetchall():
                                data_dict_plot.append({
                                    'id_stn': stn, 'vcoord': 'join', 'varno': varno,
                                    'region': region, 'family': family
                                })

                        # Caso 3: vcoord all, id_stn join
                        elif not join_vcoord and join_id_stn:
                            cursor.execute("SELECT DISTINCT vcoord FROM flag_observations WHERE varno = ?", (varno,))
                            for (vc,) in cursor.fetchall():
                                data_dict_plot.append({
                                    'id_stn': 'join', 'vcoord': vc, 'varno': varno,
                                    'region': region, 'family': family
                                })

                        # Caso 4: Ambos son 'all'
                        else:
                            cursor.execute("SELECT DISTINCT id_stn, vcoord FROM flag_observations WHERE varno = ?", (varno,))
                            for stn, vc in cursor.fetchall():
                                data_dict_plot.append({
                                    'id_stn': stn, 'vcoord': vc, 'varno': varno,
                                    'region': region, 'family': family
                                })
            except sqlite3.Error as e:
                print(f"Error en {filedb}: {e}")

    return data_dict_plot


def filter_files_by_date(path_experience_files, family, date1, date2):
    # Lista todos los archivos que coinciden con el patrón
    file_list = glob.glob(os.path.join(path_experience_files, f'*{family}'))

    # Convertir las fechas de los archivos y el rango a objetos datetime
    date_format = "%Y%m%d%H"
    date1_dt = datetime.strptime(date1, date_format)
    date2_dt = datetime.strptime(date2, date_format)

    filtered_files = []

    for file in file_list:
        # Extraer la parte de la fecha del nombre del archivo
        basename = os.path.basename(file)
        date_str = basename.split('_')[0]  # Esto asume que la fecha está al principio y seguida de '_'
        
        try:
            file_date = datetime.strptime(date_str, date_format)
        except ValueError:
            # Si no se puede convertir la fecha, ignorar el archivo
            continue
        
        # Verificar si la fecha del archivo está dentro del rango
        if date1_dt <= file_date <= date2_dt:
            filtered_files.append(file)
    
    return filtered_files  
import os
import json

import os
import json

def generate_flags_viewer(pathwork, data_list, output_filename="pikobs_flags_viewer.html"):
    """
    Generates an interactive HTML viewer for the flags plots.
    It uses a robust state-machine to filter the dropdowns dynamically based on valid data.
    """
    # Ensure data is a valid list of dictionaries and convert to JSON
    json_data = json.dumps(list(data_list))

    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pikobs Flags Viewer</title>
<style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background-color: #f4f7f6; color: #333; display: flex; flex-direction: column; min-height: 100vh; }
    .header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .container { max-width: 1300px; margin: 20px auto; padding: 0 20px; flex: 1; width: 100%; box-sizing: border-box; }
    .controls { 
        display: flex; flex-wrap: wrap; gap: 15px; background: white; padding: 20px; 
        border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 20px; 
        justify-content: center; align-items: flex-end; 
    }
    .control-group { display: flex; flex-direction: column; }
    label { font-weight: bold; margin-bottom: 5px; font-size: 13px; color: #34495e; text-transform: uppercase; letter-spacing: 0.5px; }
    select { 
        padding: 10px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px; 
        min-width: 160px; background-color: #fff; cursor: pointer; transition: border-color 0.3s; 
    }
    select:focus { outline: none; border-color: #3498db; box-shadow: 0 0 5px rgba(52,152,219,0.3); }
    
    .btn-flipflop { 
        background-color: #3498db; color: white; border: none; padding: 10px 20px; 
        font-size: 14px; font-weight: bold; border-radius: 4px; cursor: pointer; 
        display: flex; align-items: center; gap: 8px; transition: background-color 0.3s, transform 0.1s; height: 40px; 
    }
    .btn-flipflop:hover { background-color: #2980b9; }
    .btn-flipflop:active { transform: scale(0.96); }
    .btn-flipflop:disabled { background-color: #95a5a6; cursor: not-allowed; }
    .btn-flipflop.active-flip { background-color: #e67e22; }

    .image-container { 
        text-align: center; background: white; padding: 20px; border-radius: 8px; 
        box-shadow: 0 4px 6px rgba(0,0,0,0.1); min-height: 500px; 
        display: flex; align-items: center; justify-content: center; flex-direction: column; position: relative; 
    }
    img { max-width: 100%; height: auto; border-radius: 4px; display: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
    
    .error-msg { color: #e74c3c; font-weight: bold; font-size: 18px; display: none; flex-direction: column; align-items: center; gap: 10px; }
    .path-display { 
        margin-top: 15px; font-family: monospace; color: #7f8c8d; font-size: 13px; 
        background: #ecf0f1; padding: 10px; border-radius: 4px; width: 100%; box-sizing: border-box; word-break: break-all;
    }
    .badge { 
        background: #2ecc71; color: white; padding: 4px 12px; border-radius: 12px; 
        font-size: 12px; font-weight: bold; position: absolute; top: 20px; right: 20px; display: none; 
    }
    .badge.previous { background: #e67e22; }
    .footer { text-align: center; padding: 20px; color: #7f8c8d; font-size: 14px; background-color: #ecf0f1; margin-top: auto; }
    .footer a { color: #3498db; text-decoration: none; font-weight: bold; }
    .footer a:hover { text-decoration: underline; }
</style>
</head>
<body>

<div class="header">
    <h1>Pikobs Flags Analysis Viewer</h1>
    <p style="margin: 5px 0 0 0; font-size: 14px; color: #bdc3c7;">Smart Selection Engine: Dropdowns automatically adapt to valid combinations.</p>
</div>

<div class="container">
    <div class="controls">
        <div class="control-group"><label for="sel_family">1. Family</label><select id="sel_family" onchange="renderSelects(0)"></select></div>
        <div class="control-group"><label for="sel_region">2. Region</label><select id="sel_region" onchange="renderSelects(1)"></select></div>
        <div class="control-group"><label for="sel_id_stn">3. Station (id_stn)</label><select id="sel_id_stn" onchange="renderSelects(2)"></select></div>
        <div class="control-group"><label for="sel_varno">4. Varno</label><select id="sel_varno" onchange="renderSelects(3)"></select></div>
        <div class="control-group"><label for="sel_vcoord">5. Channel (vcoord)</label><select id="sel_vcoord" onchange="renderSelects(4)"></select></div>

        <button id="btn-flip" class="btn-flipflop" onclick="toggleFlipFlop()" disabled>🔁 Flip-Flop</button>
    </div>

    <div class="image-container">
        <div id="status-badge" class="badge">Current Image</div>
        <div id="error-msg" class="error-msg">
            <span>⚠️ Image file physically missing on disk.</span>
            <span style="font-size: 14px; color: #7f8c8d; font-weight: normal;">The combination exists in the database, but the .png could not be loaded.</span>
        </div>
        <img id="plot-image" src="" alt="Plot Image" onerror="handleImageError()" onload="handleImageLoad()">
        <div id="path-display" class="path-display">Initializing viewer...</div>
    </div>
</div>

<div class="footer">
    If you encounter any issues or bugs, please open an issue at: <br>
    <a href="https://gitlab.science.gc.ca/dlo001/Pikobs" target="_blank">https://gitlab.science.gc.ca/dlo001/Pikobs</a>
</div>

<script>
// 1. Data Injection and Cleaning
const rawData = JSON_DATA_PLACEHOLDER;
const dbData = rawData.map(d => ({
    family: String(d.family).trim(),
    region: String(d.region).trim(),
    id_stn: String(d.id_stn).trim(),
    varno: String(d.varno).trim(),
    vcoord: String(d.vcoord).trim()
}));

// 2. Global State for the UI (Criteria removed)
let state = { family: null, region: null, id_stn: null, varno: null, vcoord: null };

// Variables for Flip-Flop logic
let currentSrc = "";
let previousSrc = "";
let showingPrevious = false;

// Custom sorting function for natural numerical order
function naturalSort(a, b) {
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}

// Helper: Get unique sorted values for a specific key
function getUnique(data, key) {
    return [...new Set(data.map(d => d[key]))].sort(naturalSort);
}

// Helper: Populate a dropdown and retain previous selection if valid
function populateDOM(id, values, prevValue) {
    const select = document.getElementById(id);
    select.innerHTML = ''; 
    values.forEach(v => select.add(new Option(v, v)));
    
    if (prevValue && values.includes(prevValue)) {
        select.value = prevValue;
    } else if (values.length > 0) {
        select.value = values[0];
    }
}

// 3. Robust Cascade Rendering Engine
function renderSelects(level) {
    // level: -1 (Init), 0 (Family), 1 (Region), 2 (Station), 3 (Varno), 4 (Channel)

    if (level === -1) populateDOM('sel_family', getUnique(dbData, 'family'), null);
    state.family = document.getElementById('sel_family').value;

    if (level <= 0) {
        const valid = dbData.filter(d => d.family === state.family);
        populateDOM('sel_region', getUnique(valid, 'region'), state.region);
    }
    state.region = document.getElementById('sel_region').value;

    if (level <= 1) {
        const valid = dbData.filter(d => d.family === state.family && d.region === state.region);
        populateDOM('sel_id_stn', getUnique(valid, 'id_stn'), state.id_stn);
    }
    state.id_stn = document.getElementById('sel_id_stn').value;

    if (level <= 2) {
        const valid = dbData.filter(d => d.family === state.family && d.region === state.region && d.id_stn === state.id_stn);
        populateDOM('sel_varno', getUnique(valid, 'varno'), state.varno);
    }
    state.varno = document.getElementById('sel_varno').value;

    if (level <= 3) {
        const valid = dbData.filter(d => d.family === state.family && d.region === state.region && d.id_stn === state.id_stn && d.varno === state.varno);
        populateDOM('sel_vcoord', getUnique(valid, 'vcoord'), state.vcoord);
    }
    state.vcoord = document.getElementById('sel_vcoord').value;

    // Trigger image update after DOM logic finishes
    updateImage();
}

// 4. Image Construction Logic
function updateImage() {
    if(!state.family || !state.id_stn || !state.varno || !state.vcoord) return;

    // Construct the filename to match the output from flags_plotv2.
    const fileName = `flags_vcoord_${state.vcoord}_id_stn_${state.id_stn}_${state.varno}_${state.region}_${state.family}.png`;
    const relativePath = `${state.family}/${fileName}`;

    if(currentSrc !== relativePath){
        if(currentSrc !== "") { 
            previousSrc = currentSrc; 
            document.getElementById('btn-flip').disabled = false; 
        }
        currentSrc = relativePath; 
        showingPrevious = false;
        document.getElementById('btn-flip').classList.remove('active-flip');
    }
    
    applyImageSource(currentSrc, false);
}

// 5. DOM Image Handlers
function applyImageSource(src, isPrevious){
    document.getElementById('error-msg').style.display = 'none';
    document.getElementById('path-display').textContent = `Looking for file: ${src}`;
    
    const img = document.getElementById('plot-image');
    img.src = src + '?t=' + new Date().getTime(); // Cache busting
    
    const badge = document.getElementById('status-badge');
    badge.style.display = 'block';
    
    if(isPrevious){ 
        badge.textContent = 'Viewing: Previous Image'; 
        badge.className = 'badge previous'; 
    } else { 
        badge.textContent = 'Viewing: Current Selection'; 
        badge.className = 'badge'; 
    }
}

function toggleFlipFlop(){
    if(!previousSrc) return;
    showingPrevious = !showingPrevious;
    const btn = document.getElementById('btn-flip');
    
    if(showingPrevious) {
        applyImageSource(previousSrc, true);
        btn.classList.add('active-flip');
    } else {
        applyImageSource(currentSrc, false);
        btn.classList.remove('active-flip');
    }
}

function handleImageError(){ 
    document.getElementById('plot-image').style.display = 'none'; 
    document.getElementById('error-msg').style.display = 'flex'; 
    document.getElementById('status-badge').style.display = 'none'; 
}

function handleImageLoad(){ 
    document.getElementById('plot-image').style.display = 'block'; 
    document.getElementById('error-msg').style.display = 'none'; 
}

// Initialize application
if(dbData.length > 0) {
    renderSelects(-1);
} else {
    document.getElementById('path-display').textContent = "ERROR: data_list is empty.";
}
</script>

</body>
</html>
"""

    # Inject the JSON string into the HTML
    html_content = html_content.replace("JSON_DATA_PLACEHOLDER", json_data)

    # Create directory and save file
    os.makedirs(pathwork, exist_ok=True)
    html_path = os.path.join(pathwork, output_filename)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"✅ Advanced Flag Web viewer successfully created at: {html_path}")
 
        

def make_flags(path_experience_files,
                experience_names,      
                pathwork, 
                datestart,
                dateend,
                regions, 
                familys, 
             #   flag_criteria, 
                id_stn,
                channel,
            #    plot_type,
                plot_title,
                n_cpu):
   
   #pikobs.delete_create_folder(pathwork, family)
       for family in familys: 
         pikobs.delete_create_folder(pathwork, family)


       for family in familys: 


         for region in regions:

            import time
            import dask


            file_list = filter_files_by_date(path_experience_files, family, datestart, dateend)
            output_file=f"output_file{region}_{family}.db"
            t0= time.time()

            if n_cpu==1: 
 
               for input_file in file_list:
                  create_and_insert_flag_observations(input_file, output_file, region, pathwork,family)
            else:

                with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                           n_workers=n_cpu, 
                                           silence_logs=40) as client:
                   delayed_funcs = [dask.delayed(create_and_insert_flag_observations)(
                               input_file, output_file, region, pathwork,family)for input_file in file_list]

                results = dask.compute(*delayed_funcs)
            tn= time.time() 
       
       data_list_plot = create_data_list_plot(familys, pathwork, regions, id_stn, channel)
      # os.makedirs(f'{pathwork}/plots_{family}')
       t0 = time.time()   
       print (data_list_plot)
       if len(data_list_plot)==0:
          raise ValueError('You must specify best selectoion od id_stn and channel plot==0')
      # print (data_list_plot)
       if n_cpu==1: 
          print (f'in Serie plots = {len(data_list_plot)}')
          for  data_ in data_list_plot: 


              pikobs.flags_plotv2(pathwork,
                                 datestart,
                                 dateend,
                                 data_['family'],
                                 plot_title,
                                 data_['vcoord'],
                                 data_['id_stn'], 
                                 data_['varno'],
                                 data_['region'])
       else:
          print (f'Number of plot in paralle = {len(data_list_plot)}')
          with dask.distributed.Client(processes=True, threads_per_worker=1, 
                                           n_workers=n_cpu, 
                                           silence_logs=40) as client:
            delayed_funcs = [dask.delayed(pikobs.flags_plotv2)(
                                 pathwork,
                                 datestart,
                                 dateend,
                                 data_['family'],
                                 plot_title,
                                 data_['vcoord'],
                                 data_['id_stn'], 
                                 data_['varno'],
                                 data_['region'])for data_ in data_list_plot]

            results = dask.compute(*delayed_funcs)
       tn= time.time()
       print ('Total time for plotting:',tn-t0 )  
       generate_flags_viewer(pathwork, data_list_plot) 

def arg_call():
    import argparse
    import sys

    parser = argparse.ArgumentParser()
    parser.add_argument('--path_experience_files', default='undefined', type=str, help="Directory where input sqlite files are located")
    parser.add_argument('--experience_name', default='undefined', type=str, help="experience's name")
    parser.add_argument('--pathwork', default='undefined', type=str, help="Working directory")
    parser.add_argument('--datestart', default='undefined', type=str, help="Start date")
    parser.add_argument('--dateend', default='undefined', type=str, help="End date")
    parser.add_argument('--region', nargs="+", default='undefined', type=str, help="Region")
    parser.add_argument('--family', nargs="+", default='undefined', type=str, help="Family")
  #  parser.add_argument('--flags_criteria', default='undefined', type=str, help="Flags criteria")
    parser.add_argument('--id_stn',nargs="+", default='all', type=str, help="id_stn") 
    parser.add_argument('--channel',nargs="+",  default='all', type=str, help="channel") 
  #  parser.add_argument('--plot_type', default='wide', type=str, help="channel")
    parser.add_argument('--plot_title', default='plot', type=str, help="channel")
    parser.add_argument('--n_cpus', default=1, type=int, help="Number of cpus")

    args = parser.parse_args()
    print ( "Inputs in cardiogram calculation")
    print ("----------------------------------------")

    for arg in vars(args):
      
       print (f'--{arg} {getattr(args, arg)}')
    print ("----------------------------------------")
    # check if each argument is 'undefined'
    if args.path_experience_files == 'undefined':
        raise ValueError('You must specify --path_experience_files')
    if args.experience_name == 'undefined':      
        raise ValueError('You must specify -experience_name')
    if args.pathwork  == 'undefined':
        raise ValueError('You must specify --pathwork')
    if args.datestart == 'undefined':
        raise ValueError('You must specify --datestart')
    if args.dateend == 'undefined':
        raise ValueError('You must specify --dateend')
    if args.region == 'undefined':
        raise ValueError('You must specify --region')
    if args.family == 'undefined':
        raise ValueError('You must specify --family')
 #   if args.flags_criteria == 'undefined':
 #       raise ValueError('You must specify --flags_criteria')
   # if args.fonction == 'undefined':
   #     raise ValueError('You must specify --fonction')

    #Call your function with the arguments
    sys.exit(make_flags(args.path_experience_files,
                        args.experience_name,
                        args.pathwork,
                        args.datestart,
                        args.dateend,
                        args.region,
                        args.family,
                        args.id_stn,
                        args.channel,
                        args.plot_title,
                        args.n_cpus))

