import os
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import StrMethodFormatter
from glob import glob
import re
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Optional

# --- 1. ENVIRONMENT CONFIG & CORE FUNCTIONS ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def extract_date(filepath: str) -> Optional[pd.Timestamp]:
    """Extracts the YYYYMMDDHH date from the filename."""
    match = re.search(r'(\d{10})', os.path.basename(filepath))
    return pd.to_datetime(match.group(1), format='%Y%m%d%H') if match else None

def process_single_file(filepath: str) -> Optional[Dict]:
    """Processes a single SQLite file with schema fallback tolerance."""
    f_date = extract_date(filepath)
    if not f_date:
        return None
    
    uri = f"file:{filepath}?mode=ro"
    
    try:
        # Attempt 1: INNER JOIN
        with sqlite3.connect(uri, uri=True) as conn:
            query = """
            SELECT 
                COUNT(d.id_data)          as data_points,
                COUNT(d.id_obs)           as observations
            FROM data d
            INNER JOIN header h ON d.id_data = h.id;
            """
            cursor = conn.cursor()
            cursor.execute(query)
            row = cursor.fetchone()
            return {'Date': f_date, 'data_points': row[0], 'observations': row[1]}
            
    except sqlite3.OperationalError:
        # Attempt 2 (Fallback): Count directly from data table if JOIN fails
        try:
            with sqlite3.connect(uri, uri=True) as conn:
                query_fallback = """
                SELECT 
                    COUNT(id_data)          as data_points,
                    COUNT(id_obs)           as observations
                FROM data;
                """
                cursor = conn.cursor()
                cursor.execute(query_fallback)
                row = cursor.fetchone()
                return {'Date': f_date, 'data_points': row[0], 'observations': row[1]}
        except Exception as e:
            logging.error(f"Fallback failed for {os.path.basename(filepath)}: {e}")
            return None
    except Exception as e:
        logging.error(f"Error processing {os.path.basename(filepath)}: {e}")
        return None

def get_detailed_counts_parallel(path: str, pattern: str, start_dt: pd.Timestamp, end_dt: pd.Timestamp) -> pd.DataFrame:
    """Scans the directory and processes files in parallel using multiple threads."""
    search_path = os.path.join(path, f"*{pattern}*")
    all_files = glob(search_path)
    
    valid_files = [f for f in all_files if extract_date(f) and start_dt <= extract_date(f) <= end_dt]
    logging.info(f"[{pattern}] Analyzing {len(valid_files)} valid files...")
    
    daily_data = []
    
    with ThreadPoolExecutor(max_workers=8) as executor:
        future_to_file = {executor.submit(process_single_file, f): f for f in valid_files}
        for future in as_completed(future_to_file):
            res = future.result()
            if res:
                daily_data.append(res)
    
    if not daily_data:
        logging.warning(f"[{pattern}] No data found/extracted in the given date range.")
        return pd.DataFrame(columns=['Date', 'data_points', 'observations'])
    
    return pd.DataFrame(daily_data).groupby('Date').sum().reset_index()

# --- 2. PATHS & DYNAMIC INSTRUMENT CONFIGURATION ---

BASE_WORK_PATH = '/home/smco500/.suites'

# >>> CAMBIA ESTA VARIABLE PARA ALTERNAR ENTRE ATMS Y CrIS <<<
INSTRUMENT_FAMILY = 'CRIS'  # Options: 'ATMS' or 'CrIS'

# Auto-configure paths based on selected instrument
if INSTRUMENT_FAMILY.upper() == 'ATMS':
    config = {
        'dbase':   {'path': f'{BASE_WORK_PATH}/psmon/monitoring/g2/hub/ppp7/sqlite/banco/dbase/', 'pattern': 'atms_dbase'},
        'evalat':  {'path': f'{BASE_WORK_PATH}/gdps/g2/hub/ppp7/monitoring/banco/evalalt/', 'pattern': 'atms_allsky_qc'},
        'postalt': {'path': f'{BASE_WORK_PATH}/gdps/g2/hub/ppp7/monitoring/banco/postalt/', 'pattern': 'atms_allsky'}
    }
elif INSTRUMENT_FAMILY.upper() == 'CRIS':
    config = {
        'dbase':   {'path': f'{BASE_WORK_PATH}/psmon/monitoring/g2/hub/ppp7/sqlite/banco/dbase/', 'pattern': 'cris_dbase'},
        'evalat':  {'path': f'{BASE_WORK_PATH}/gdps/g2/hub/ppp7/monitoring/banco/evalalt/', 'pattern': 'cris*_qc'},
        'postalt': {'path': f'{BASE_WORK_PATH}/gdps/g2/hub/ppp7/monitoring/banco/postalt/', 'pattern': 'cris'} 
    }
else:
    raise ValueError("Instrument family not recognized. Choose 'ATMS' or 'CrIS'.")

start_date_str = '2026040500'
end_date_str   = '2026040900'
start_dt = pd.to_datetime(start_date_str, format='%Y%m%d%H')
end_dt   = pd.to_datetime(end_date_str,   format='%Y%m%d%H')

# --- 3. DATA EXTRACTION & MERGING ---

logging.info(f"Starting metrics extraction for {INSTRUMENT_FAMILY}...")
steps_data = {step: get_detailed_counts_parallel(cfg['path'], cfg['pattern'], start_dt, end_dt) 
              for step, cfg in config.items()}

# Consolidate (Merge)
df_master = steps_data['dbase'].rename(columns={'data_points': 'data_dbase', 'observations': 'obs_dbase'})

for step in ['evalat', 'postalt']:
    temp_df = steps_data[step].rename(columns={
        'data_points': f'data_{step}', 'observations': f'obs_{step}'
    })
    if not temp_df.empty:
        df_master = df_master.merge(temp_df, on='Date', how='outer')
    else:
        df_master[f'data_{step}'] = 0
        df_master[f'obs_{step}'] = 0

if df_master.empty:
    logging.error("THE FINAL DATAFRAME IS EMPTY. Check your paths and patterns.")
    exit()

df_master = df_master.sort_values('Date')

# --- 4. TYPE CORRECTION & ADVANCED CALCULATIONS ---

# 1. Ensure date format
df_master['Date'] = pd.to_datetime(df_master['Date'])

# 2. Force numeric types
numeric_columns = ['obs_dbase', 'obs_evalat', 'obs_postalt']
for col in numeric_columns:
    if col in df_master.columns:
        df_master[col] = pd.to_numeric(df_master[col], errors='coerce').fillna(0)

# 3. Survival Calculations (Observations)
df_master['Ret_QC_Total_%']    = (df_master['obs_evalat'] / df_master['obs_dbase'].replace(0, 1)) * 100
df_master['Ret_Final_Total_%'] = (df_master['obs_postalt'] / df_master['obs_dbase'].replace(0, 1)) * 100

for col in ['Ret_QC_Total_%', 'Ret_Final_Total_%']:
    df_master[col] = pd.to_numeric(df_master[col], errors='coerce').fillna(0)

# --- 5. VISUALIZATION: HIGH-DENSITY DASHBOARD (2 PANELS) ---

plt.style.use('ggplot')
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 10), sharex=True, constrained_layout=True)
fig.suptitle(f'{INSTRUMENT_FAMILY.upper()} Pipeline Performance Analysis: {start_date_str[:8]} to {end_date_str[:8]}', fontsize=20, fontweight='bold')

# ---------------------------------------------------------
# PANEL 1: Absolute Volumes (LINEAR SCALE)
# ---------------------------------------------------------
ax1.plot(df_master['Date'], df_master['obs_dbase'], 'o-', color='#2c3e50', label='1. Raw Input (dbase)', lw=3, markersize=8)
ax1.plot(df_master['Date'], df_master['obs_evalat'], 's-', color='#2980b9', label='2. Post-QC (evalalt)', lw=3, markersize=8)
ax1.plot(df_master['Date'], df_master['obs_postalt'], 'd-', color='#27ae60', label='3. Final Output (postalt)', lw=3, markersize=8)

# Add NOBS labels (Only First, Last, and every 5th point to prevent overlap)
total_points = len(df_master)
for i in range(total_points):
    if df_master['obs_postalt'].iloc[i] > 0:
        if i == 0 or i == total_points - 1 or i % 5 == 0:
            ax1.annotate(f"{int(df_master['obs_postalt'].iloc[i]):,}", 
                         (df_master['Date'].iloc[i], df_master['obs_postalt'].iloc[i]),
                         textcoords="offset points", xytext=(0, 12), ha='center', fontsize=10, weight='bold', color='#145a32')

ax1.yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}')) 
ax1.set_ylabel('Observation Count (nobs)', fontweight='bold', fontsize=12)
ax1.set_ylim(bottom=0) 
ax1.legend(loc='center left', bbox_to_anchor=(1.01, 0.5), frameon=True, shadow=True)
ax1.grid(True, ls="--", alpha=0.4)

# ---------------------------------------------------------
# PANEL 2: Retention Percentages (DYNAMIC Y-AXIS)
# ---------------------------------------------------------
ax2.fill_between(df_master['Date'], 100, df_master['Ret_QC_Total_%'], color='#e74c3c', alpha=0.03, label='Loss at QC')
ax2.fill_between(df_master['Date'], df_master['Ret_QC_Total_%'], df_master['Ret_Final_Total_%'], color='#f39c12', alpha=0.05, label='Loss at Post-Processing')

ax2.plot(df_master['Date'], df_master['Ret_QC_Total_%'], 's--', color='#2980b9', label='% QC Retention', lw=3, markersize=8)
ax2.plot(df_master['Date'], df_master['Ret_Final_Total_%'], 'd-', color='#27ae60', label='% Total Retention', lw=4, markersize=10)

# Percentage Labels (Only First, Last, and every 5th point)
for i in range(total_points):
    if df_master['Ret_Final_Total_%'].iloc[i] > 0:
        if i == 0 or i == total_points - 1 or i % 5 == 0:
            ax2.annotate(f"{df_master['Ret_Final_Total_%'].iloc[i]:.2f}%", 
                         (df_master['Date'].iloc[i], df_master['Ret_Final_Total_%'].iloc[i]),
                         textcoords="offset points", xytext=(0, 12), ha='center', fontsize=10, weight='bold', color='#145a32')

# --- Add Formula Text Box to Panel 2 ---
formula_text = (
    "Calculations:\n"
    "• % QC Retention = (evalalt / dbase) $\\times$ 100\n"
    "• % Total Retention = (postalt / dbase) $\\times$ 100"
)
# Places the text at 2% from the left, 95% from the top
ax2.text(0.02, 0.95, formula_text, transform=ax2.transAxes, fontsize=10,
         verticalalignment='top', bbox=dict(boxstyle='round,pad=0.5', facecolor='white', edgecolor='gray', alpha=0.9))

ax2.set_ylabel('Obs. Retention (%)', fontweight='bold', fontsize=12)
ax2.set_xlabel('Assimilation Cycle Date', fontweight='bold', fontsize=13)

# DYNAMIC Y-AXIS ZOOM
max_pct = df_master[['Ret_QC_Total_%', 'Ret_Final_Total_%']].max().max()
if pd.notna(max_pct) and max_pct > 0:
    ax2.set_ylim(0, max_pct * 1.4) # Increased margin to fit the formula box
else:
    ax2.set_ylim(0, 100)

ax2.legend(loc='center left', bbox_to_anchor=(1.01, 0.5), frameon=True, shadow=True)
ax2.grid(True, alpha=0.6)

# Format X-axis dates
ax2.xaxis.set_major_formatter(mdates.DateFormatter('%b %d - %H:00'))
plt.xticks(rotation=45, ha='right')

# Save and Show dynamically named by instrument
output_fn = f"pipeline_loss_{INSTRUMENT_FAMILY.upper()}_2PANELS_{start_date_str}_{end_date_str}.png"
plt.savefig(output_fn, dpi=300, bbox_inches='tight')
logging.info(f"Process completed. Chart saved successfully to: {output_fn}")

print("\n--- CALCULATED DATA SUMMARY ---")
print(df_master[['Date', 'obs_dbase', 'Ret_QC_Total_%', 'Ret_Final_Total_%']].tail())

plt.show()
