import glob
import sqlite3
import os
import matplotlib.pyplot as plt
import numpy as np
from collections import defaultdict
import json
import os
import random
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
def load_color_mapping( mapping_file):
        """Carga el mapeo de colores desde el archivo JSON."""
        if os.path.exists(mapping_file):
            with open(mapping_file, 'r') as file:
                try:
                    mapping = json.load(file)
                    return mapping
                except json.JSONDecodeError:
                    print("Error decoding JSON from the file. Returning empty mapping.")
                    return {}
        return {}
    
def save_color_mapping(mapping,mapping_file):
        """Guarda el mapeo de colores en el archivo JSON."""
        with open(mapping_file, 'w') as file:
            json.dump(mapping, file, indent=4)
    
def get_color_for_flag(flag, color_mapping,mapping_file):
        """Obtiene el color para un flag. Si no existe, asigna uno nuevo y actualiza el archivo."""
        if flag not in color_mapping:
            new_color = generate_random_color()
            color_mapping[flag] = new_color
            save_color_mapping(color_mapping,mapping_file)  # Guarda solo el nuevo mapeo
        return color_mapping[flag]
    
def generate_random_color():
        """Genera un color hexadecimal aleatorio."""
        return "#{:06x}".format(random.randint(0, 0xFFFFFF))
    

def parse_date(date_str):
    """Convierte un string en formato YYYYMMDDHH a un objeto datetime."""
    return datetime.strptime(date_str, '%Y%m%d%H')

def format_date(date):
    """Convierte un objeto datetime a un string en formato YYYYMMDDHH."""
    return date.strftime('%Y%m%d%H')

def generate_date_range(datestart_str, dateend_str):
    """Genera una lista de fechas desde datestart menos 6 horas hasta dateend en formato YYYYMMDDHH."""
    # Convierte las cadenas en objetos datetime
    datestart = parse_date(datestart_str)
    dateend = parse_date(dateend_str)

    # Resta 6 horas a datestart
   # datestart -= timedelta(hours=6)

    # Genera una lista de fechas desde datestart hasta dateend
    date_list = []
    current_date = datestart
    while current_date <= dateend:
        date_list.append(format_date(current_date))
        current_date += timedelta(hours=6)  # Cambia el intervalo según sea necesario

    return date_list# Directory and file pattern
def generate_random_color():
        """Genera un color hexadecimal aleatorio."""
        return "#{:06x}".format(random.randint(0, 0xFFFFFF))
def format_avg_obs(avg_obs, num_files):
                avg_per_file = avg_obs / num_files
                if avg_per_file >= 1:
                    return f"{int(round(avg_per_file))}"
                else:
                    # Redondear a la primera cifra significativa
                    return f"{avg_per_file:.1g}"
def format_avg_percentage(avg_percentage):
                if avg_percentage >= 0.001:
                    return f"{avg_percentage:.3f}"  # 3 decimales
                else:
                    return f"{avg_percentage:.1g}"  # Primera cifra significativa
                        # Usar la función en el código

def bits_active(number):
        if number == 0:
            return [0]  # Si el número es 0, devolver [0] explícitamente
        return [bit for bit in range(24) if (number & (1 << bit)) != 0]
import sqlite3
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from collections import defaultdict
import json
import os

def bits_to_decimal(*bit_positions):
    """
    Convierte una lista de posiciones de bits activados a su valor decimal.
    bit_positions: una lista de enteros que representan las posiciones de los bits encendidos.
    """
    decimal = 0
    for bit in bit_positions:
        decimal += 2**bit  # Sumar el valor de 2 elevado a la posición del bit
    return decimal

def parse_date(date_str):
    try:
        # Assuming date format is 'YYYYMMDDHH' or 'YYYY-MM-DD HH:MM:SS'
        return pd.to_datetime(date_str, format='%Y%m%d%H', errors='coerce')
    except ValueError:
        return pd.NaT
#def bits_active(flag):
#    """
#    Devuelve una lista de los bits activos para un flag (valor decimal).
##    """
#    return [i for i in range(24) if flag & (1 << i)]
       
def has_predefined_pair(bits,  predefined_bit_pairs):
    """
    Verifies if the active bits satisfy the conditions specified in predefined_bit_pairs.
    Handles conditions before and after multiple 'or', and supports excluded bits (e.g., 'n23').
    
    :param bits: A list of active bits (e.g., [6, 12, 15]).
    :param predefined_bit_pairs: A list of tuples representing predefined bit pairs.
                                 Example: [(12, 6, 'n23', 'or', 6, 'or', 9)].
                                 'n' prefix indicates the bit must be inactive.
    :return: A list of valid bit pairs that satisfy the conditions.
    """
    valid_pairs = []  # List to store all valid pairs

    for bit_pair in predefined_bit_pairs:
        active_conditions = []  # List of conditions to check
        excluded_bits = []  # Bits that must be inactive (prefixed with 'n')
        
        condition_sets = []  # Multiple sets of conditions, split by 'or'
        current_set = []  # The current set of conditions before the next 'or'
        
        for bit in bit_pair:
            if isinstance(bit, str) and bit.startswith('n'):
                excluded_bits.append(int(bit[1:]))  # 'n23' -> bit 23 must be inactive
            elif bit == 'or':
                # When encountering 'or', save the current set and start a new one
                condition_sets.append(current_set)
                current_set = []  # Reset for the next condition set
            else:
                current_set.append(bit)  # Add bits to the current set of conditions
        
        # Append the final set of conditions if there were no more 'or' separators
        if current_set:
            condition_sets.append(current_set)
        
        # Now check each condition set (separated by 'or')
        found_valid_set = False
        for condition_set in condition_sets:
      #      # Check if all bits in the set are active and all excluded bits are inactive
            if all(bit in bits for bit in condition_set) and all(bit not in bits for bit in excluded_bits):
                found_valid_set = True
                break  # If one set is valid, no need to check further

        if found_valid_set:
            valid_pairs.append(bit_pair)

    return valid_pairs  # Return the list of valid pairs


import os
import json
import sqlite3
import hashlib
import colorsys
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
from collections import defaultdict
import pikobs 

# ==========================================
# HELPER FUNCTION: CONSISTENT & UNIQUE COLORS
# ==========================================
def get_consistent_color(identifier, color_mapping):
    """
    Returns a mathematically unique and consistent color for a flag.
    If not in color_mapping, it uses an MD5 hash converted to HSV space
    to guarantee thousands of unique, pleasant colors (preventing visual collisions).
    """
    ident_str = str(identifier)
    if color_mapping and ident_str in color_mapping:
        return color_mapping[ident_str]
    
    # Generate deterministic HSV based on MD5 hash
    hash_int = int(hashlib.md5(ident_str.encode('utf-8')).hexdigest(), 16)
    
    # Hue: 0.0 to 1.0, Saturation: 0.5 to 0.9, Value: 0.6 to 0.9
    hue = (hash_int % 1000) / 1000.0 
    sat = 0.5 + ((hash_int // 1000) % 40) / 100.0
    val = 0.6 + ((hash_int // 40000) % 30) / 100.0
    
    r, g, b = colorsys.hsv_to_rgb(hue, sat, val)
    return mcolors.to_hex((r, g, b))

# ==========================================
# HELPER FUNCTIONS: BIT EXTRACTION & MAPPING
# ==========================================
def bits_active(decimal):
    """Returns a list of the active bit positions for a given decimal integer."""
    return [i for i in range(decimal.bit_length()) if decimal & (1 << i) != 0]

def bit_pair_to_flag(bit_pair):
    """
    Converts a bit_pair tuple (e.g., (9, 16, 'n8') or (0, 'or', 7)) to a base decimal flag.
    This mathematically links the pie chart back to the exact same integer
    used in the bar chart, perfectly matching their colors.
    """
    base_flag = 0
    for item in bit_pair:
        if isinstance(item, int):
            base_flag |= (1 << item)
    return str(base_flag)


import os
import json
import sqlite3
import hashlib
import colorsys
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
from collections import defaultdict
import pikobs 

# ==========================================
# HELPER FUNCTION: CONSISTENT & UNIQUE COLORS
# ==========================================
def get_consistent_color(identifier, color_mapping):
    """
    Returns a mathematically unique and consistent color for a flag.
    If not in color_mapping, it uses an MD5 hash converted to HSV space
    to guarantee thousands of unique, pleasant colors (preventing visual collisions).
    """
    ident_str = str(identifier)
    if color_mapping and ident_str in color_mapping:
        return color_mapping[ident_str]
    
    # Generate deterministic HSV based on MD5 hash
    hash_int = int(hashlib.md5(ident_str.encode('utf-8')).hexdigest(), 16)
    
    # Hue: 0.0 to 1.0, Saturation: 0.5 to 0.9, Value: 0.6 to 0.9
    hue = (hash_int % 1000) / 1000.0 
    sat = 0.5 + ((hash_int // 1000) % 50) / 100.0
    val = 0.6 + ((hash_int // 50000) % 30) / 100.0
    
    r, g, b = colorsys.hsv_to_rgb(hue, sat, val)
    return mcolors.to_hex((r, g, b))

# ==========================================
# HELPER FUNCTIONS: BIT EXTRACTION & MAPPING
# ==========================================
def bits_active(decimal):
    """Returns a list of the active bit positions for a given decimal integer."""
    return [i for i in range(decimal.bit_length()) if decimal & (1 << i) != 0]

def bit_pair_to_flag(bit_pair):
    """
    Converts a bit_pair tuple (e.g., (9, 16, 'n8') or (0, 'or', 7)) to a base decimal flag.
    This mathematically links the pie chart back to the exact same integer
    used in the bar chart, perfectly matching their colors.
    """
    base_flag = 0
    for item in bit_pair:
        if isinstance(item, int):
            base_flag |= (1 << item)
    return str(base_flag)

# ==========================================
# MAIN PLOTTING FUNCTION
# ==========================================
def flags_plotv2(pathwork, datestart, dateend, family, plot_title, vcoord, id_stn, varno, region):
    """
    Generates a standardized, fixed-dimension plot showing the distribution of quality 
    control flags (bits) across time, both as a bar chart and detailed pie charts.
    """
    db_path = f'{pathwork}/{family}/output_file{region}_{family}.db'
    
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()
    
    # Generate and sort dates to ensure chronological order
    # (Assuming generate_date_range is defined in your environment)
    dates = generate_date_range(datestart, dateend)
    dates.sort()  
    
    results_by_file = defaultdict(lambda: defaultdict(int))
    total_observations_by_file = {}
    
    bit_descriptions = {
        0: "Modified or generated by ADE", 1: "Exceeds climate extreme", 2: "Erroneous", 3: "Possibly erroneous",
        4: "Doubtful", 5: "Interpolated", 6: "Bias corrected", 7: "Rejected by satellite QC",
        8: "Unselected (blacklisted)", 9: "Rejected for background check", 10: "Generated by analysis",
        11: "Unselected channel", 12: "Assimilated", 13: "O-P rogue check failure level 1",
        14: "O-P rogue check failure level 2", 15: "O-P rogue check failure level 3",
        16: "Rejection for O-P magnitude", 17: "Rejected by QC-Var 3DVAR", 18: "Rejected over land due to higher topography",
        19: "Rejected due to land/sea mask", 20: "Aircraft TrackQC rejection",
        21: "Rejected due to transmittance above model top", 22: "QC Obs rejection", 23: "Cloud affected radiance"
    }
    
    # ---------------------------------------------------------
    # 1. Main Data Extraction (For Bar Chart)
    # ---------------------------------------------------------
    query_id_stn = f" and id_stn='{id_stn}'" if id_stn != 'join' else ''
    query_vcoord = f" and vcoord='{vcoord}'" if vcoord != 'join' else ''

    for date in dates:
        cursor.execute(f"""
            SELECT flag, sum(num_data_entries)
            FROM flag_observations
            WHERE varno={varno} AND date={date} {query_id_stn} {query_vcoord}
            GROUP BY flag
        """)
        flag_data = cursor.fetchall()
        
        total_observations = sum(num for _, num in flag_data)
        total_observations_by_file[date] = total_observations
        
        for flag, num_observations in flag_data:
            results_by_file[date][flag] = num_observations

    # Data normalization and cumulative percentages
    normalized_data = defaultdict(dict)
    numberobs_data = defaultdict(dict)
    
    for date, counts in results_by_file.items():
        total_observations = total_observations_by_file[date]
        accumulated = 0
        for flag, num_observations in sorted(counts.items(), key=lambda item: item[1], reverse=True):
            percentage = (num_observations / total_observations) * 100 if total_observations else 0
            normalized_data[date][flag] = (accumulated, accumulated + percentage)
            numberobs_data[date][flag] = num_observations
            accumulated += percentage

    # Calculate average percentage and observations for each flag
    average_percentage_by_flag = {}
    average_obs_by_flag = {}
    total_observations_all_files = sum(total_observations_by_file.values())
    all_flags = set(flag for counts in results_by_file.values() for flag in counts)
    
    for flag in all_flags:
        total_flag_observations = sum(results_by_file[date].get(flag, 0) for date in dates)
        average_percentage_by_flag[flag] = (total_flag_observations / total_observations_all_files) * 100 if total_observations_all_files else 0
        average_obs_by_flag[flag] = total_flag_observations
    
    # ---------------------------------------------------------
    # 2. Main Chart Configuration (STATIC STRICT LAYOUT)
    # ---------------------------------------------------------
    cols_per_row = 5
    max_pie_rows = 4 
    
    # EXTRA WIDE CANVAS: Increased to 50 inches width. Height to 26.
    fig = plt.figure(figsize=(50, 26))
    
    # CRITICAL FIX: Changed right from 0.75 to 0.60
    # This dedicates a massive 40% of the 50-inch width (20 inches) EXCLUSIVELY to the legend and right text.
    fig.subplots_adjust(left=0.03, right=0.60, top=0.92, bottom=0.05) 
    
    gs = fig.add_gridspec(max_pie_rows + 2, cols_per_row, 
                          height_ratios=[6, 0.8] + [3.5]*max_pie_rows, 
                          hspace=0.7, wspace=0.3)
                          
    ax1 = fig.add_subplot(gs[0, :])
    
    file_names = list(total_observations_by_file.keys())
    x = np.arange(len(file_names))
    bar_width = 1 / len(file_names)

    color_map_path = f"{os.path.dirname(pikobs.__file__)}/extension/color_mapping.json"
    try:
        with open(color_map_path) as f:
            color_mapping = json.load(f)
    except FileNotFoundError:
        color_mapping = {}
    
    x_positions = []
    added_labels = set()
    
    for file_idx, date in enumerate(dates):
        sorted_flags = sorted(average_percentage_by_flag.items(), key=lambda item: item[1], reverse=True)
        sorted_flags_keys = [flag for flag, _ in sorted_flags]
        
        for flag in sorted_flags_keys:
            if flag not in normalized_data[date]:
                continue
                
            start, end = normalized_data[date][flag]
            
            if flag not in added_labels:
                label = (f'Flag {flag} (Active bits: {bits_active(flag)}), '
                         f'Average % $^1$: {format_avg_percentage(average_percentage_by_flag[flag])}%, '
                         f'Average Obs $^2$: {format_avg_obs(average_obs_by_flag[flag], len(dates))}')
                added_labels.add(flag)
            else:
                label = ""
            
            x_position = file_idx + bar_width * np.arange(len(dates)) - 0.5
            x_positions.extend(x_position)
            
            flag_color = get_consistent_color(str(flag), color_mapping)
            ax1.bar(x_position, end - start, bottom=start, width=bar_width, label=label, color=flag_color)
    
    if x_positions:
        ax1.set_xlim(min(x_positions), max(x_positions) + bar_width)
    ax1.set_ylim(0, 100)
    ax1.set_yticks(np.arange(0, 101, 20))
    
    # LARGE FONT SIZES
    ax1.set_xlabel('Date', fontsize=24, fontweight='bold')
    ax1.set_ylabel('Percentage of N. Obs.', fontsize=24, fontweight='bold')
    ax1.set_title(f'Normalized Distribution of Bits Presented per File of 6h\n {datestart}-{dateend} # Family:{family} # Channel:{vcoord} # Sat:{id_stn}', fontsize=28, pad=20)
    
    step = max(1, len(file_names) // 6)
    ax1.set_xticks(x[::step])
    ax1.set_xticklabels([os.path.basename(file)[0:10] for file in file_names][::step])
    
    ax1.tick_params(axis='x', labelsize=22)
    ax1.tick_params(axis='y', labelsize=22)
    
    # Legend safely placed with larger font, now with 40% margin to live in
    ax1.legend(loc='upper left', bbox_to_anchor=(1.2, 1.0), ncol=1, frameon=False, fontsize=20)
    
    explanation_text = (
        r"$^1$ Average percentage is calculated based on the total number of observations." "\n"
        r"$^2$ Average number of observations per 6-hour intervals."
    )
    ax1.text(0.5, -0.20, explanation_text, ha='center', va='top', transform=ax1.transAxes, fontsize=20, linespacing=1.5)

    # ---------------------------------------------------------
    # 3. Pie Charts (Multicolored Slices Matching the Bar Chart)
    # ---------------------------------------------------------
    predefined_bit_pairs = []
    if family in ('cris','iasi', 'csr'):
        predefined_bit_pairs = [(0,'or',2,'or',9,'n16'),(8,),(9,16),(11,7),(11,19),(11,21),(11,23),(9,'or',11),(12,)]
    elif family in ('amsua_allsky','to_amsua_allsky', 'amsub_allsky','atms_allsky.db' ,'atms_allsky', 'mwhs2', 'mwhs2.db','ssmis' ,'ssmis.db'): 
        predefined_bit_pairs = [(0,'or',7),(8,),(9,16,),(9,18,),(9,23,),(9,),(12,),(23,12,),(23,),(19,)]
    elif family == 'radar':
        predefined_bit_pairs = [(12,),(11,),(9,'n11')]

    bit_pair_observations = defaultdict(lambda: defaultdict(int)) 
    bit_pair_observations_assi = defaultdict(lambda: defaultdict(int))
    TOTAL = 0  
    TOTAL_ASSI = 0 
    
    for date in dates:
        cursor.execute(f"""
            SELECT flag, sum(num_data_entries), vcoord
            FROM flag_observations
            WHERE varno={varno} AND date={date} {query_id_stn} {query_vcoord}
            GROUP BY flag, vcoord
        """)
        flag_data = cursor.fetchall()
        
        cursor.execute("SELECT distinct(vcoord) FROM flag_observations WHERE (flag & 4096) = 4096;")
        vcoord_data = [row[0] for row in cursor.fetchall()]

        for flag, num_observations, vcoord_ in flag_data: 
            bits = bits_active(flag)
            valid_bit_pairs = has_predefined_pair(bits, predefined_bit_pairs) 
            
            TOTAL += num_observations
            for bit_pair in valid_bit_pairs:
                bit_pair_observations[bit_pair][flag] += num_observations

            if vcoord_ in vcoord_data:
                TOTAL_ASSI += num_observations
                for bit_pair in valid_bit_pairs:
                    bit_pair_observations_assi[bit_pair][flag] += num_observations

    bit_pair_totals = {pair: sum(obs.values()) for pair, obs in bit_pair_observations.items()}
    bit_pair_totals_assi = {pair: sum(obs.values()) for pair, obs in bit_pair_observations_assi.items()}

    bit_pair_percentages_sorted = dict(sorted(
        {p: (tot / TOTAL) * 100 for p, tot in bit_pair_totals.items() if TOTAL > 0}.items(),
        key=lambda x: x[1], reverse=True
    ))

    bit_pair_titles = {
        (0, 'or', 2, 'or', 9, 'n16'): "ERRONEOUS DATA",
        (8,): "CHANNELS ON THE BLACKLIST",
        (9, 16, 'n8'): "BACKGROUND CHECK (O-P INNOVATION ROGUE CHECK)",
        (9, 16): "BACKGROUND CHECK (O-P INNOVATION ROGUE CHECK)",
        (11, 7, 'n8'): "NOT ASSIMILATED DURING THE DAY",
        (11, 7): "NOT ASSIMILATED DURING THE DAY",
        (11, 19, 'n8'): "LAND / SEA-ICE SENSITIVITY",
        (11, 19): "LAND / SEA-ICE SENSITIVITY",
        (11, 21, 'n8'): "SENSITIVITY OVER MODEL TOP",
        (11, 21): "SENSITIVITY OVER MODEL TOP",
        (11, 23, 'n8'): "AFFECTED BY CLOUDS",
        (11, 23): "AFFECTED BY CLOUDS AND BIT 11",
        (9, 'n8', 'or', 11, 'n8'): "REJECTED BY OVERALL QUALITY CONTROL",
        (9, 'or', 11): "REJECTED BY OVERALL QUALITY CONTROL",
        (12,): "ASSIMILATED",
        (0, 'n8', 'or', 7, 'n8'): "ERRONEOUS DATA",
        (0, 'or', 7): "ERRONEOUS DATA",
        (0, 'or', 7, 'n8'): "ERRONEOUS DATA",
        (9, 18, 'n8'): "TOPOGRAPHY SENSITIVITY",
        (9, 18): "TOPOGRAPHY SENSITIVITY",
        (9, 23, 'n8'): "AFFECTED BY CLOUDS NOT ASSIMILATED",
        (9, 23): "AFFECTED BY CLOUDS AND BIT 9",
        (23, 12): "AFFECTED BY CLOUDS BUT ASSIMILATED",
        (23,): "AFFECTED BY CLOUDS",
        (9, 'n8'): "REJECTED BY OVERALL QUALITY CONTROL",
        (9,): "REJECTED BY OVERALL QUALITY CONTROL",
        (11,): "REJECTED BY THINNING",
        (9,'n11'): "REJECTED BY BACKGROUND CHECK",
        (19,): "LAND / SEA-ICE SENSITIVITY",
    }

    for i, (bit_pair, total_percentage) in enumerate(bit_pair_percentages_sorted.items()):
        if i >= (cols_per_row * max_pie_rows):
            break
            
        row = (i // cols_per_row) + 2
        col = i % cols_per_row
        ax2 = fig.add_subplot(gs[row, col])
        
        flag_counts = bit_pair_observations[bit_pair]
        sorted_flags = sorted(flag_counts.items(), key=lambda x: x[1], reverse=True)
        
        sizes = []
        colors = []
        labels = []
        
        for flag, count in sorted_flags:
            pct = (count / TOTAL) * 100
            sizes.append(pct)
            colors.append(get_consistent_color(str(flag), color_mapping))
            labels.append("") 
            
        rest_pct = max(0, 100 - total_percentage)
        sizes.append(rest_pct)
        colors.append('white')
        labels.append(f'Rest\n{round(rest_pct, 3)}%')

        textprops = {'color': 'black', 'fontweight': 'bold', 'fontsize': 22}
        
        ax2.pie(sizes, labels=labels, colors=colors, autopct=None, startangle=190,
                wedgeprops={'edgecolor': 'black', 'linewidth': 0.5}, textprops=textprops, 
                labeldistance=1.1, radius=1.3)  
        
        additional_title = bit_pair_titles.get(tuple(bit_pair), "Default Title")
        bit_descriptions_str = "\n ".join([bit_descriptions.get(bit, f"Unknown ({bit})") 
                                           for bit in bit_pair 
                                           if isinstance(bit, int) or (isinstance(bit, str) and not bit.startswith('n') and bit != 'or')])
        
        ax2.set_title(f'{additional_title}\n Bits {bit_pair} (Total: {round(total_percentage, 3)}%)\n{bit_descriptions_str}', pad=30, fontsize=22)
        ax2.axis('equal')

    # ---------------------------------------------------------
    # SUMMARY TEXT (Moved to start of pies, Massive Font)
    # ---------------------------------------------------------
    percentages_text = "Percentages considering only the desired channels.\n"
    percentages_text += "-"*50 + "\n"
    
    has_assimilation_data = False
    
    if family != 'radar' and TOTAL_ASSI > 0:
        bit_pair_totals_assi_sorted = sorted(bit_pair_totals_assi.items(), key=lambda x: x[1], reverse=True)
        for bit_pair, observations in bit_pair_totals_assi_sorted:
            if bit_pair not in [(8,), (0,'or',2,'or',9,'n16'), (11,23)]:
                additional_title = bit_pair_titles.get(tuple(bit_pair), f"Bits {bit_pair}")
                percentages_text += f"*{additional_title}:  {(observations*100/TOTAL_ASSI):.4g}%\n\n"
                has_assimilation_data = True
                
    if not has_assimilation_data:
        percentages_text += "No assimilated data available for this selection.\n\n"

    # Aligned with the right margin bound (0.95 so it doesn't touch the literal edge)
    fig.text(0.95, 0.35, percentages_text, ha='right', va='top', fontsize=20, 
             bbox=dict(facecolor='white', alpha=0.8, edgecolor='none'))

    # ---------------------------------------------------------
    # 4. Save Output
    # ---------------------------------------------------------
    os.makedirs(f'{pathwork}/{family}', exist_ok=True)
    out_file = f'{pathwork}/{family}/flags_vcoord_{vcoord}_id_stn_{id_stn}_{varno}_{region}_{family}.png'
    
    plt.savefig(out_file, dpi=100) 
    
    plt.close(fig)
    cursor.close()
    connection.close()
