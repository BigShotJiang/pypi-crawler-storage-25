"""
pikobs.scatter — Geographic tiled observation statistics
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────────────
# Imports
# ─────────────────────────────────────────────────────────────────────────────
import argparse
import datetime as _dt
import logging
import os
import re
import sqlite3
import sys
import time
import warnings
from typing import Any, Dict, List, Optional, Sequence, Tuple

import dask
import matplotlib as mpl
import numpy as np
import pandas as pd
from dask.distributed import Client

mpl.use('Agg')

import matplotlib.cm        as cm
import matplotlib.colorbar  as cbar
import matplotlib.colors    as colors
import matplotlib.pyplot    as plt
from matplotlib.collections import PatchCollection
from matplotlib.ticker      import FuncFormatter
from mpl_toolkits.axes_grid1 import make_axes_locatable

import cartopy.feature
from pikobs.pbs_submit import maybe_submit_to_pbs

import pikobs

warnings.filterwarnings("ignore", ".*ShapelyDeprecationWarning.*")


# ─────────────────────────────────────────────────────────────────────────────
# Module-level configuration
# ─────────────────────────────────────────────────────────────────────────────

DPI:           int   = 600
FIG_SIZE:      tuple = (10, 10)
ALPHA_TILES:   float = 0.85
N_INTERVALS:   int   = 10
EARTH_RADIUS_KM: float = 6371.0

_DIFF_VMIN, _DIFF_VMAX = -100, 100
_DIFF_NEUTRAL          = 5
_DIFF_STEP             = 20

# Wind-derivation method codes (BUFR table 002023).
WIND_TYPE_MAPPING: Dict[int, str] = {
    1: "Wind derived from cloud motion observed in the infrared channel",
    2: "Wind derived from cloud motion observed in the visible channel",
    3: "Wind derived from cloud motion observed in the water vapour channel",
    4: "Wind derived from motion observed in a combination of spectral channels",
    5: "Wind derived from motion observed in the water vapour channel in clear air",
    6: "Wind derived from motion observed in the ozone channel",
    7: "Wind derived from motion observed in water vapour channel (cloud or clear air not specified)",
}

# ── ADDITION A: BUFR observation type codes → long names ─────────────────────
DICT_CODTYP = {
     '12': 'SYNOP',        '13': 'SHIP',          '14': 'SYNOP MOBIL',
     '15': 'METAR',        '16': 'SPECI',          '18': 'DRIFTER',
     '32': 'PILOT',        '33': 'PILOT SHIP',     '34': 'PILOT MOBIL',
     '35': 'TEMP',         '36': 'TEMP SHIP',      '37': 'TEMP DROP',
     '38': 'TEMP MOBIL',   '42': 'AMDAR',         '128': 'AIREP',
    '134': 'PAOBS',       '135': 'TEMP + PILOT',  '136': 'TEMP + SYNOP',
    '139': 'TEMP SHIP + PILOT SHIP',              '143': 'SWOB-NONAUTO',
    '144': 'SWOB-AUTO',   '145': 'Patrol ship',   '146': 'ASYNOP',
    '147': 'BUOYS',       '148': 'SWOBNONAUTO-SPECIAL',
    '149': 'SWOBAUTO-SPECIAL',                    '157': 'BUFR',
    '159': 'TEMP PILOT MOBIL',                    '163': 'RADAR',
    '164': 'AMSUA',       '168': 'SSMIS',         '169': 'GPSRO',
    '177': 'ADS',         '181': 'AMSUB',         '182': 'MHS',
    '183': 'AIRS',        '185': 'CSR',            '186': 'IASI',
    '188': 'AMVS',        '189': 'GROUND BASED GPS',
    '192': 'ATMS',        '193': 'CRIS NSR',
    '195': 'constituants chimiques (remote)',
    '196': 'constituants chimiques (in-situ)',
    '198': 'NetWork of Network',
    '200': 'MWHS-2',      '202': 'CRIS FSR',      '254': 'SCAT',
}


def _codtyp_label(id_stn: str) -> str:
    """Return a human-readable label for an id_stn value.

    If id_stn starts with a numeric code present in DICT_CODTYP
    (e.g. '35_XXXXX' or '035') return 'TEMP (35_XXXXX)'.
    Otherwise return id_stn unchanged.
    """
    code = str(id_stn).strip()
    if code in DICT_CODTYP:
        return f"{DICT_CODTYP[code]} ({code})"
    for c, name in DICT_CODTYP.items():
        if code.startswith(c + '_') or code.startswith(c + ' '):
            return f"{name} ({code})"
    return code


# ─────────────────────────────────────────────────────────────────────────────
# Schema constants
# ─────────────────────────────────────────────────────────────────────────────

_MOYENNE_COLS = (
    "Nrej, Nacc, Nprofile, DATE, lat, lon, boite, id_stn, varno, vcoord, "
    "sumx, sumy, sumz, sumStat, sumx2, sumy2, sumz2, sumStat2, n, flag"
)

_DDL_MOYENNE = """
    CREATE TABLE IF NOT EXISTS moyenne (
        Nrej     INTEGER, Nacc      INTEGER, Nprofile INTEGER,
        DATE     INTEGER, lat       FLOAT,   lon      FLOAT,
        boite    INTEGER, id_stn    TEXT,    varno    INTEGER,
        vcoord   FLOAT,
        sumx     FLOAT,   sumy      FLOAT,   sumz     FLOAT, sumStat  FLOAT,
        sumx2    FLOAT,   sumy2     FLOAT,   sumz2    FLOAT, sumStat2 FLOAT,
        n        INTEGER, flag      INTEGER
        {extra}
    );
"""


# ─────────────────────────────────────────────────────────────────────────────
# Small helpers
# ─────────────────────────────────────────────────────────────────────────────

def _days_between(d1: str, d2: str) -> float:
    """Inclusive-window length in days between two ``YYYYMMDDHH`` strings."""
    a = _dt.datetime.strptime(d1, "%Y%m%d%H")
    b = _dt.datetime.strptime(d2, "%Y%m%d%H")
    return (b - a).total_seconds() / 86_400.0


def _surface_area_km2(lat1: np.ndarray, lat2: np.ndarray,
                      lon1: np.ndarray, lon2: np.ndarray) -> np.ndarray:
    lat1 = np.clip(lat1, -90.0, 90.0)
    lat2 = np.clip(lat2, -90.0, 90.0)
    return (EARTH_RADIUS_KM ** 2
            * np.abs(np.sin(np.deg2rad(lat2)) - np.sin(np.deg2rad(lat1)))
            * np.abs(lon2 - lon1)
            * np.deg2rad(1.0))


def _format_scientific_adaptive(x: float) -> str:
    if x == 0:
        return "0"
    a = abs(x)
    if a >= 10:
        return f"{int(x)}"
    if a >= 0.1:
        return f"{round(x, 2)}"
    m, e = f"{x:.1e}".split("e")
    return f"{m.split('.')[0]}e{int(e)}"


def get_wind_type(code: Any) -> Any:
    """Return the WMO description for a wind-derivation method code."""
    def _one(c: Any) -> str:
        try:
            return WIND_TYPE_MAPPING.get(int(c), f"Unknown code {c}")
        except (ValueError, TypeError):
            return f"Unknown code {c}"

    if isinstance(code, (list, tuple, set)):
        return [_one(c) for c in code]
    if isinstance(code, pd.Series):
        return code.map(_one)
    return _one(code)


def _safe_filename(text: str) -> str:
    return (str(text)
            .replace(' ', '_')
            .replace(':', '')
            .replace('/', '_')
            .replace('\\', '_'))


# ─────────────────────────────────────────────────────────────────────────────
# SQLite helpers
# ─────────────────────────────────────────────────────────────────────────────

def create_table_if_not_exists(cursor, extra_sw: str = "") -> None:
    cursor.execute(_DDL_MOYENNE.format(extra=extra_sw))


def combine(pathfileout: str, filememory: str, extra_sw: str = "") -> None:
    cols = _MOYENNE_COLS + extra_sw
    insert_sql = (f"INSERT INTO moyenne ({cols}) "
                  f"SELECT {cols} FROM this_avg_db.moyenne")
    with sqlite3.connect(pathfileout, uri=True,
                         isolation_level=None, timeout=9_999) as conn:
        try:
            conn.execute("PRAGMA journal_mode=OFF;")
            conn.execute("PRAGMA synchronous=OFF;")
            create_table_if_not_exists(conn, extra_sw)
            conn.execute(f"ATTACH DATABASE '{filememory}' AS this_avg_db;")
            conn.execute(insert_sql)
            conn.commit()
            conn.execute("DETACH DATABASE this_avg_db;")
        except sqlite3.Error as exc:
            print(f"[scatter] Error combining SQLite files: {exc}",
                  file=sys.stderr)
            raise


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 1 — Aggregation
# ─────────────────────────────────────────────────────────────────────────────

def _group_by_clauses(channel: str, id_stn: str, vcoord_expr: str,
                      extra_sw: str) -> Tuple[str, str, str]:
    if channel == 'join' and id_stn == 'all':
        return ('"join" AS Chan,',
                'id_stn AS id_stn,',
                f'GROUP BY 2, 3, 4, 5, id_stn {extra_sw}')
    if channel == 'all' and id_stn == 'join':
        return (f'{vcoord_expr} AS Chan,',
                '"join" AS id_stn,',
                f'GROUP BY 2, 3, 4, 5, {vcoord_expr} {extra_sw}')
    if channel == 'all' and id_stn == 'all':
        return (f'{vcoord_expr} AS Chan,',
                'id_stn AS id_stn,',
                f'GROUP BY 2, 3, 4, 5, id_stn, {vcoord_expr} {extra_sw}')
    if channel == 'join' and id_stn == 'join':
        return ('"join" AS Chan,',
                '"join" AS id_stn,',
                f'GROUP BY 2, 3, 4, 5 {extra_sw}')
    raise ValueError(
        f"Unsupported combination: channel={channel!r}, id_stn={id_stn!r}"
    )


def create_and_populate_moyenne_table(
        family,
        new_db_filename:      str,
        existing_db_filename: str,
        selected_region,
        selected_flags:       str,
        FUNCTION,
        boxsizex:             float,
        boxsizey:             float,
        varnos,
        channel:              str,
        id_stn:               str,
        interval:             Tuple[Optional[int], Optional[int]]) -> None:
    date_match = re.search(r'(\d{10})', existing_db_filename)
    if not date_match:
        raise ValueError(
            "No 10-digit date in source filename: "
            f"{os.path.basename(existing_db_filename)}"
        )
    date_str = date_match.group(1)

    in_memory_db = "file::memory:?cache=shared"
    with sqlite3.connect(in_memory_db, uri=True,
                         isolation_level=None, timeout=9_999_999) as mem_conn:
        cursor = mem_conn.cursor()

        FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)
        element = ",".join(varnos) if varnos else element

        LAT1, LAT2, LON1, LON2 = pikobs.regions(selected_region)
        LATLONCRIT    = pikobs.generate_latlon_criteria(LAT1, LAT2, LON1, LON2)
        print(selected_flags)
        flag_criteria = pikobs.flag_criteria(selected_flags)
        print(flag_criteria)
        STNID = (f"floor(360. / {boxsizex}) * floor(lat / {boxsizey}) "
                 f"+ floor(MIN(179.99, lon) / {boxsizex})")
        LAT   = f"floor(lat / {boxsizey}) * {boxsizey} + {boxsizey} / 2."
        LON   = (f"floor(MIN(179.99, lon) / {boxsizex}) * {boxsizex} "
                 f"+ {boxsizex} / 2.")

        cursor.execute("PRAGMA journal_mode = MEMORY;")
        cursor.execute("PRAGMA synchronous = OFF;")
        cursor.execute("PRAGMA foreign_keys = OFF;")
        cursor.execute(f"ATTACH DATABASE '{existing_db_filename}' AS db;")

        cursor.execute("PRAGMA table_info('DATA');")
        data_cols = [c[1] for c in cursor.fetchall()]
        has_bias_corr = 'BIAS_CORR' in data_cols

        cursor.execute("PRAGMA table_info('HEADER');")
        head_cols = [c[1] for c in cursor.fetchall()]
        has_wind_method = 'WIND_COMP_METHOD' in head_cols
        extra_sw = ' ' if has_wind_method else ''

        chan_select, id_stn_select, group_by = _group_by_clauses(
            channel, id_stn, VCOORD, extra_sw,
        )

        a, b = interval
        interval_criteria = ('' if (a is None and b is None)
                             else f"AND vcoord >= {a*100} AND vcoord <= {b*100}")

        sum_bc  = "sum(bias_corr)"           if has_bias_corr else "NULL"
        sum_bc2 = "sum(bias_corr*bias_corr)" if has_bias_corr else "NULL"

        create_table_if_not_exists(cursor, extra_sw)

        insert_query = f"""
        INSERT INTO moyenne (
            DATE, lat, lon, boite, varno, vcoord,
            sumx, sumy, sumz, sumStat,
            sumx2, sumy2, sumz2, sumStat2,
            n, Nrej, Nacc, Nprofile, id_stn, flag {extra_sw}
        )
        SELECT
            {date_str},
            {LAT}, {LON}, {STNID}, VARNO,
            {chan_select}
            sum(omp), sum(oma), sum(obsvalue), {sum_bc},
            sum(omp*omp), sum(oma*oma), sum(obsvalue*obsvalue), {sum_bc2},
            COUNT(*),
            sum((flag & 512) = 512),
            sum((flag & 4096) - 4094),
            COUNT(DISTINCT id_obs),
            {id_stn_select}
            flag {extra_sw}
        FROM db.header NATURAL JOIN db.DATA
        WHERE varno IN ({element})
          AND obsvalue IS NOT NULL
          {flag_criteria}
          {LATLONCRIT}
          {VCOCRIT}
          {interval_criteria}
        {group_by};
        """
        print(insert_query)
        cursor.execute(insert_query)
        mem_conn.commit()

        try:
            combine(new_db_filename, in_memory_db, extra_sw)
        except sqlite3.Error as exc:
            print(f"[scatter] merge failed for "
                  f"{os.path.basename(new_db_filename)}: {exc}",
                  file=sys.stderr)


# ─────────────────────────────────────────────────────────────────────────────
# Task list builders
# ─────────────────────────────────────────────────────────────────────────────

def _layer_label(interval: Tuple[Optional[int], Optional[int]]) -> str:
    a, b = interval
    if a is None and b is None:
        return 'layer_all'
    return f'layer_from{a}MPato{b}MPa'


def _layer_display(interval: Tuple[Optional[int], Optional[int]]) -> str:
    a, b = interval
    if a is None and b is None:
        return 'layer_all'
    return f'Layer {a} hPa - {b} hPa'


def create_data_list(date_start:    str,
                     date_end:      str,
                     families:      List[str],
                     input_paths:   List[str],
                     names:         List[str],
                     work_path:     str,
                     box_size_x:    float,
                     box_size_y:    float,
                     function:      List[str],
                     flag_criteria: str,
                     regions:       List[Any],
                     varnos:        List[str],
                     intervals:     List[Tuple[Optional[int], Optional[int]]]
                     ) -> List[Dict[str, Any]]:
    data_list: List[Dict[str, Any]] = []
    dt_start = _dt.datetime.strptime(date_start, '%Y%m%d%H')
    dt_end   = _dt.datetime.strptime(date_end,   '%Y%m%d%H')

    cur = dt_start
    while cur <= dt_end:
        fdate = cur.strftime('%Y%m%d%H')
        for family in families:
            for region in regions:
                for name, in_path in zip(names, input_paths):
                    for interval in intervals:
                        layer = _layer_label(interval)
                        filein = f'{in_path}/{fdate}_{family}'
                        db_new = (
                            f'{work_path}/{family}/scatter_{layer}_{name}_'
                            f'{region}_{date_start}_{date_end}_'
                            f'bx{box_size_x}_by{box_size_y}_'
                            f'{flag_criteria}_{family}.db'
                        )
                        data_list.append({
                            'family':        family,
                            'filein':        filein,
                            'db_new':        db_new,
                            'region':        region,
                            'flag_criteria': flag_criteria,
                            'function':      function,
                            'boxsizex':      box_size_x,
                            'boxsizey':      box_size_y,
                            'varnos':        varnos,
                            'interval':      interval,
                        })
        cur += _dt.timedelta(hours=6)
    return data_list


def get_id_stns(cursor, id_stn: str,
                has_wind_method: bool) -> List[Tuple[str, Any]]:
    if id_stn == 'all' and has_wind_method:
        cursor.execute(
            "SELECT DISTINCT id_stn, WIND_COMP_METHOD FROM moyenne;"
        )
        return list(cursor.fetchall())

    if id_stn == 'all' and not has_wind_method:
        cursor.execute("SELECT DISTINCT id_stn FROM moyenne;")
        return [(row[0], None) for row in cursor.fetchall()]

    if id_stn == 'join' and has_wind_method:
        cursor.execute("SELECT DISTINCT WIND_COMP_METHOD FROM moyenne;")
        return [('join', row[0]) for row in cursor.fetchall()]

    return [('join', None)]


def fetch_vcoords(cursor, where_clause: str) -> List[Tuple[Any, int]]:
    cursor.execute(
        "SELECT DISTINCT vcoord, varno FROM moyenne "
        f"{where_clause} ORDER BY vcoord ASC;"
    )
    return cursor.fetchall()


def fetch_channels_varno(cursor) -> List[int]:
    cursor.execute("SELECT DISTINCT varno FROM moyenne ORDER BY vcoord ASC;")
    return [row[0] for row in cursor.fetchall()]


def create_data_list_plot(date_start:    str,
                          date_end:      str,
                          families:      List[str],
                          namein:        List[str],
                          work_path:     str,
                          box_size_x:    float,
                          box_size_y:    float,
                          functions:     List[str],
                          flag_criteria: str,
                          regions:       List[Any],
                          id_stn:        str,
                          channel:       str,
                          projections:   List[str],
                          intervals:     List[Tuple[Optional[int], Optional[int]]]
                          ) -> List[Dict[str, Any]]:
    data_list_plot: List[Dict[str, Any]] = []

    for interval in intervals:
        layer = _layer_label(interval)
        for family in families:
            for region in regions:
                for function in functions:
                    for proj in projections:
                        fileset = [
                            f'{work_path}/{family}/scatter_{layer}_'
                            f'{namein[0]}_{region}_{date_start}_{date_end}_'
                            f'bx{box_size_x}_by{box_size_y}_'
                            f'{flag_criteria}_{family}.db'
                        ]
                        if len(namein) > 1:
                            fileset.append(
                                f'{work_path}/{family}/scatter_{layer}_'
                                f'{namein[1]}_{region}_{date_start}_{date_end}_'
                                f'bx{box_size_x}_by{box_size_y}_'
                                f'{flag_criteria}_{family}.db'
                            )
                        try:
                            with sqlite3.connect(fileset[0]) as conn:
                                cursor = conn.cursor()
                                cursor.execute(
                                    "PRAGMA table_info('moyenne');"
                                )
                                cols   = [c[1] for c in cursor.fetchall()]
                                has_wm = 'WIND_COMP_METHOD' in cols
                                for idstn, wm in get_id_stns(
                                        cursor, id_stn, has_wm):
                                    where = ('' if id_stn == 'join'
                                             else f'WHERE id_stn = "{idstn}"')
                                    if channel == 'all':
                                        items = fetch_vcoords(cursor, where)
                                    else:
                                        items = [('join', vn) for vn in
                                                 fetch_channels_varno(cursor)]
                                    for vc, vn in items:
                                        data_list_plot.append({
                                            'id_stn':           idstn,
                                            'vcoord':           vc,
                                            'files_in':         fileset,
                                            'varno':            vn,
                                            'region':           region,
                                            'function':         function,
                                            'proj':             proj,
                                            'interval':         interval,
                                            'family':           family,
                                            'flag_criteria':    flag_criteria,
                                            'WIND_COMP_METHOD': wm,
                                        })
                        except sqlite3.Error as exc:
                            print(f"[scatter] Could not query "
                                  f"{fileset[0]}: {exc}", file=sys.stderr)
    return data_list_plot


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 2 — Plot rendering
# ─────────────────────────────────────────────────────────────────────────────

def _build_where_clause(id_stn: str, vcoord: Any) -> str:
    if id_stn == 'join' and vcoord == 'join':
        return ""
    if id_stn == 'join' and vcoord != 'join':
        return f" AND vcoord = {vcoord}"
    if id_stn != 'join' and vcoord == 'join':
        return f" AND id_stn = '{id_stn}'"
    return f" AND vcoord = {vcoord} AND id_stn = '{id_stn}'"


def _project_polygon(proj, lat: float, lon: float,
                     dx: float, dy: float, src_crs) -> List[List[float]]:
    out: List[List[float]] = []
    for dlon, dlat in ((-dx, -dy), (-dx, dy), (dx, dy), (dx, -dy)):
        x, y = proj.transform_point(lon + dlon, lat + dlat, src_crs)
        out.append([x, y])
    return out


def _query_tiles_single(cursor, varno: int, where: str, wind_crit: str,
                        sum_str: str, sum2_str: str) -> None:
    query = f"""
    CREATE TEMPORARY TABLE AVG AS
    SELECT  boite, lat, lon, varno, vcoord,
            SUM({sum_str}) / SUM(CAST(N AS FLOAT))                              AS AVG,
            SQRT(MAX(0.0,
                    SUM({sum2_str}) / SUM(CAST(N AS FLOAT))
                  - (SUM({sum_str})  / SUM(CAST(N AS FLOAT)))
                  * (SUM({sum_str})  / SUM(CAST(N AS FLOAT)))))                 AS STD,
            SUM(sumstat) / SUM(CAST(N AS FLOAT))                                AS BCORR,
            SUM(n)                                                              AS N
    FROM db1.moyenne
    WHERE varno = {varno} {where} {wind_crit}
    GROUP BY boite, lat, lon, varno HAVING SUM(n) > 3;
    """
    cursor.execute(query)


def _query_tiles_diff(cursor, varno: int, where: str, wind_crit: str,
                      sum_str: str, sum2_str: str) -> None:
    for label, db in (('BOITES1', 'db1'), ('BOITES2', 'db2')):
        cursor.execute(f"""
        CREATE TEMPORARY TABLE {label} AS
        SELECT  boite, lat, lon, varno, vcoord,
                SUM({sum_str}) / SUM(CAST(N AS FLOAT))                            AS AVG,
                SQRT(MAX(0.0,
                        SUM({sum2_str}) / SUM(CAST(N AS FLOAT))
                      - (SUM({sum_str})  / SUM(CAST(N AS FLOAT)))
                      * (SUM({sum_str})  / SUM(CAST(N AS FLOAT)))))               AS STD,
                SUM(sumstat) / SUM(CAST(N AS FLOAT))                              AS BCORR,
                SUM(n)                                                            AS N
        FROM {db}.moyenne
        WHERE varno = {varno} {where} {wind_crit}
        GROUP BY boite, lat, lon, varno HAVING SUM(n) > 3;
        """)

    cursor.execute("""
    CREATE TEMPORARY TABLE AVG AS
    SELECT  BOITES1.boite                  AS BOITE,
            BOITES1.lat                    AS LAT,
            BOITES1.lon                    AS LON,
            BOITES1.vcoord                 AS VCOORD,
            BOITES1.varno                  AS VARNO,
            ABS(BOITES1.avg) - ABS(BOITES2.avg)         AS AVG,
            COALESCE(ABS(BOITES1.avg),   8888)          AS AVG1,
            COALESCE(ABS(BOITES2.avg),   8888)          AS AVG2,
            ABS(BOITES1.std) - ABS(BOITES2.std)         AS STD,
            COALESCE(ABS(BOITES1.std),   8888)          AS std1,
            COALESCE(ABS(BOITES2.std),   8888)          AS std2,
            ABS(BOITES1.bcorr) - ABS(BOITES2.bcorr)     AS BCORR,
            COALESCE(ABS(BOITES1.bcorr), 8888)          AS bcorr1,
            COALESCE(ABS(BOITES2.bcorr), 8888)          AS bcorr2,
            BOITES1.N - BOITES2.N                       AS N,
            COALESCE(BOITES1.N,          8888)          AS N1,
            COALESCE(BOITES2.N,          8888)          AS N2
    FROM BOITES1
    JOIN BOITES2 ON BOITES1.boite = BOITES2.boite
                AND BOITES1.VCOORD = BOITES2.VCOORD;
    """)


def _relative_pct(num: np.ndarray, ref: np.ndarray) -> np.ndarray:
    with np.errstate(divide='ignore', invalid='ignore'):
        return np.where(np.abs(ref) > 0,
                        (np.abs(num) - np.abs(ref)) * 100.0 / np.abs(ref),
                        np.nan)


def _diff_boundaries() -> np.ndarray:
    neg = np.arange(_DIFF_VMIN, -_DIFF_NEUTRAL, _DIFF_STEP)
    pos = -neg[::-1]
    return np.concatenate(
        [neg, [-_DIFF_NEUTRAL, _DIFF_NEUTRAL], pos[:-1] if len(pos) else pos]
    )


def _diff_cmap_and_norm(boundaries: np.ndarray
                        ) -> Tuple[colors.ListedColormap, colors.BoundaryNorm]:
    n_neg = int((boundaries < -_DIFF_NEUTRAL).sum())
    n_pos = int((boundaries >  _DIFF_NEUTRAL).sum())
    neg_colors = [cm.RdYlBu_r(x) for x in np.linspace(0.08, 0.40, n_neg)]
    pos_colors = [cm.RdYlBu_r(x) for x in np.linspace(0.60, 0.92, n_pos)]
    cmap = colors.ListedColormap(neg_colors + [(1, 1, 1, 1)] + pos_colors)
    cmap.set_under('#0235ad')
    cmap.set_over('#b30000')
    return cmap, colors.BoundaryNorm(boundaries, cmap.N)


def _render_tile_map(mode:          str,
                     region:        str,
                     family:        str,
                     id_stn:        str,
                     datestart:     str,
                     dateend:       str,
                     Points:        str,
                     boxsizex:      float,
                     boxsizey:      float,
                     proj:          str,
                     pathwork:      str,
                     flag_criteria: str,
                     fonction:      str,
                     vcoord:        Any,
                     filesin:       List[str],
                     namesin:       List[str],
                     varno:         int,
                     interval:      Tuple[Optional[int], Optional[int]],
                     wind_method:   Optional[int] = None) -> Optional[str]:
    deltax, deltay = float(boxsizex) / 2.0, float(boxsizey) / 2.0
    a, b           = interval
    layer_label    = _layer_display(interval)

    conn = sqlite3.connect(":memory:")
    cur  = conn.cursor()
    cur.execute("PRAGMA TEMP_STORE=memory;")
    cur.execute(f"ATTACH DATABASE '{filesin[0]}' AS db1;")

    FNAM, FNAMP, SUM_STR, SUM2_STR = pikobs.type_boxes(fonction)
    where = _build_where_clause(id_stn, vcoord)

    wind_crit   = (f' AND WIND_COMP_METHOD = {wind_method}'
                   if wind_method is not None else '')
    wind_suffix = (f'_OBS_SWMT_{wind_method}_'
                   if wind_method is not None else '')
    wind_desc   = (get_wind_type(wind_method)
                   if wind_method is not None else '')

    if len(filesin) > 1:
        cur.execute(f"ATTACH DATABASE '{filesin[1]}' AS db2;")
        _query_tiles_diff(cur, varno, where, wind_crit, SUM_STR, SUM2_STR)
    else:
        _query_tiles_single(cur, varno, where, wind_crit, SUM_STR, SUM2_STR)

    if len(filesin) > 1:
        cur.execute("SELECT lat, lon, AVG, STD, N, N1, N2, "
                    "AVG1, AVG2, std1, std2, BCORR, bcorr1, bcorr2 "
                    "FROM AVG;")
    else:
        cur.execute("SELECT lat, lon, AVG, STD, BCORR, N FROM AVG;")
    rows = cur.fetchall()
    if not rows:
        conn.close()
        return None

    arr = np.array(rows, dtype=object)
    lat = arr[:, 0].astype(float)
    lon = arr[:, 1].astype(float)

    if len(filesin) > 1:
        avg, std         = arr[:, 2].astype(float), arr[:, 3].astype(float)
        n_obs, n1, n2    = (arr[:, 4].astype(float),
                            arr[:, 5].astype(float),
                            arr[:, 6].astype(float))
        avg1, avg2       = arr[:, 7].astype(float), arr[:, 8].astype(float)
        std1, std2       = arr[:, 9].astype(float), arr[:, 10].astype(float)
        bcorr            = arr[:, 11].astype(float)
        bcorr1, bcorr2   = arr[:, 12].astype(float), arr[:, 13].astype(float)

        cur.execute("""
            SELECT b1.boite, b1.lat, b1.lon FROM boites1 b1
            LEFT JOIN boites2 b2 ON b1.boite = b2.boite WHERE b2.boite IS NULL
            UNION
            SELECT b2.boite, b2.lat, b2.lon FROM boites2 b2
            LEFT JOIN boites1 b1 ON b2.boite = b1.boite WHERE b1.boite IS NULL
        """)
        diff_exclusive_boxes = cur.fetchall()
    else:
        avg, std         = arr[:, 2].astype(float), arr[:, 3].astype(float)
        bcorr            = arr[:, 4].astype(float)
        n_obs            = arr[:, 5].astype(float)
        diff_exclusive_boxes = []

    cur.execute("SELECT AVG(avg), AVG(std), SUM(N) FROM AVG;")
    mu_val, sigma_val, total_obs = cur.fetchone()
    conn.close()

    if sigma_val is None:
        return None

    sigma_val  = np.round(sigma_val, 3)
    period_str = f'From {datestart} To {dateend}'
    n_days     = max(0.25, _days_between(datestart, dateend))
    var_name, units, vcoord_type = pikobs.type_varno(varno)

    if vcoord == 'join':
        title_var = (f"{var_name} {units} \n id_stn:{id_stn} "
                     f"vcoord/channel:{vcoord} {layer_label} \n {wind_desc}")
    else:
        title_var = (f"{var_name} {units} \n id_stn:{id_stn} "
                     f"vcoord/channel:{int(vcoord)} {layer_label}")

    areas = _surface_area_km2(lat - deltay, lat + deltay,
                              lon - deltax, lon + deltax)
    with np.errstate(divide='ignore', invalid='ignore'):
        density = np.where(areas > 0, n_obs / areas, 0.0)

    is_diff = len(filesin) > 1

    if fonction in ('dens', 'dens%'):
        if is_diff:
            den1 = np.where(areas > 0, n1 / areas, 0.0)
            den2 = np.where(areas > 0, n2 / areas, 0.0)
            plot_values = _relative_pct(den2, den1)
        else:
            plot_values = density / n_days
        cmap_base = cm.get_cmap('PuRd', lut=N_INTERVALS)

    elif fonction in ('nobs', 'NOBSHDR'):
        if is_diff:
            plot_values = _relative_pct(n2 / n_days, n1 / n_days)
        else:
            plot_values = n_obs / n_days
        cmap_base = cm.get_cmap('PuRd', lut=N_INTERVALS + 1)

    elif fonction == 'obs':
        plot_values = _relative_pct(avg2, avg1) if is_diff else avg
        cmap_base   = cm.get_cmap('RdYlBu_r', lut=N_INTERVALS)

    elif fonction == 'bcorr':
        plot_values = (_relative_pct(bcorr2, bcorr1) if is_diff else bcorr)
        cmap_base   = cm.get_cmap('RdYlBu_r', lut=N_INTERVALS)

    elif fonction in ('omp', 'oma'):
        if is_diff:
            plot_values = _relative_pct(avg2, avg1)
            cmap_base   = cm.get_cmap('RdYlBu_r', lut=N_INTERVALS)
        else:
            plot_values = avg
            cmap_base   = cm.get_cmap('seismic', lut=N_INTERVALS)

    elif fonction in ('stdomp', 'stdoma'):
        if is_diff:
            plot_values = _relative_pct(std2, std1)
            cmap_base   = cm.get_cmap('RdYlBu_r', lut=N_INTERVALS)
        else:
            plot_values = std
            cmap_base   = cm.get_cmap('PuRd', lut=N_INTERVALS)
    else:
        plot_values = avg
        cmap_base   = cm.get_cmap('RdYlBu_r', lut=N_INTERVALS)

    if is_diff:
        boundaries     = _diff_boundaries()
        cmap, norm     = _diff_cmap_and_norm(boundaries)
        ticks          = list(boundaries[boundaries < -_DIFF_NEUTRAL]) \
                         + [-_DIFF_NEUTRAL, _DIFF_NEUTRAL] \
                         + list(boundaries[boundaries > _DIFF_NEUTRAL])
        y_centres      = boundaries
        extend_color   = 'both'
    else:
        finite = plot_values[np.isfinite(plot_values)]
        if finite.size == 0:
            return None
        if fonction in ('omp', 'oma'):
            vmax = np.nanmax(np.abs(finite))
            vmin = -vmax
        else:
            vmin, vmax = float(np.nanmin(finite)), float(np.nanmax(finite))
            if vmin == vmax:
                vmax = vmin + 1.0
        boundaries  = np.linspace(vmin, vmax, N_INTERVALS + 1)
        y_centres   = boundaries[:-1] + (boundaries[1] - boundaries[0]) / 2
        cmap        = cmap_base
        norm        = colors.Normalize(vmin=vmin, vmax=vmax)
        ticks       = list(boundaries)
        extend_color = None

    mapper        = cm.ScalarMappable(norm=norm, cmap=cmap)
    rgba_centres  = [mapper.to_rgba(x) for x in y_centres]
    bin_idx       = np.clip(np.digitize(plot_values, boundaries) - 1,
                            0, len(rgba_centres) - 1)

    plt.close('all')
    plt.figure(figsize=FIG_SIZE)
    plt.rcParams['axes.linewidth'] = 1

    ax, fig, lat_pos, proj_obj, pc = pikobs.type_projection(proj)

    pts_xy = proj_obj.transform_points(pc, lon, lat)[:, :2]
    fig_xy = ax.transData.transform(pts_xy)
    ax_xy  = ax.transAxes.inverted().transform(fig_xy)
    in_axes = ((ax_xy[:, 0] >= -0.01) & (ax_xy[:, 0] <= 1.01)
               & (ax_xy[:, 1] >= -0.01) & (ax_xy[:, 1] <= 1.01))

    on_map_obs  = float(n_obs[in_axes].sum())
    on_map_obs2 = float(n1[in_axes].sum()) if is_diff else 0.0

    patches, facecolors_list = [], []
    for i in np.flatnonzero(in_axes):
        val = plot_values[i]
        if Points == 'ON':
            plt.text(pts_xy[i, 0], pts_xy[i, 1], int(np.floor(n_obs[i])),
                     color="k", fontsize=17, zorder=5,
                     ha='center', va='center', weight='bold')
            continue

        if boxsizex >= 10:
            plt.text(pts_xy[i, 0], pts_xy[i, 1],
                     _format_scientific_adaptive(val),
                     color="b", fontsize=5, zorder=5,
                     ha='center', va='center', weight='bold')

        poly_pts = _project_polygon(proj_obj, lat[i], lon[i],
                                    deltax, deltay, pc)
        if is_diff:
            if   val < _DIFF_VMIN: col = '#0235ad'
            elif val > _DIFF_VMAX: col = '#b30000'
            elif np.isnan(val):    col = (0.7, 0.7, 0.7, 0.5)
            else:                  col = rgba_centres[bin_idx[i]]
        else:
            col = rgba_centres[bin_idx[i]]

        patches.append(plt.Polygon(poly_pts))
        facecolors_list.append(col)

    if patches:
        ax.add_collection(PatchCollection(
            patches, facecolor=facecolors_list,
            edgecolor='none', alpha=ALPHA_TILES, zorder=4,
        ))

    if is_diff and diff_exclusive_boxes:
        excl = [plt.Polygon(_project_polygon(proj_obj, lt, ln,
                                             deltax, deltay, pc))
                for _, lt, ln in diff_exclusive_boxes]
        ax.add_collection(PatchCollection(
            excl, facecolor=(0, 0, 0, 1),
            edgecolor='k', linewidth=0.8, alpha=1.0, zorder=5,
        ))

    res = '50m'
    ax.add_feature(cartopy.feature.NaturalEarthFeature(
        'physical', 'ocean', res,
        edgecolor='#7f7f7f', facecolor='#e0f3f8'), zorder=0)
    ax.add_feature(cartopy.feature.NaturalEarthFeature(
        'physical', 'land',  res,
        edgecolor='#C0C0C0', facecolor='#f4f3f0'), zorder=1)
    ax.add_feature(cartopy.feature.NaturalEarthFeature(
        'physical', 'coastline', res,
        edgecolor='#333333', facecolor='none', linewidth=0.8), zorder=10)
    ax.add_feature(cartopy.feature.NaturalEarthFeature(
        'cultural', 'admin_0_boundary_lines_land', res,
        edgecolor='#555555', facecolor='none', linewidth=0.5), zorder=10)

    ax.gridlines(color='gray', linestyle='--',
                 xlocs=range(-180, 190, 20), ylocs=lat_pos,
                 draw_labels=False, zorder=2, alpha=0.4)

    divider = make_axes_locatable(ax)
    cax     = divider.append_axes("right", size="5%", pad=0.05,
                                  axes_class=plt.Axes)
    cb = cbar.ColorbarBase(
        cax, cmap=cmap, norm=norm, orientation='vertical', drawedges=True,
        extend=extend_color, ticks=ticks, boundaries=boundaries, alpha=1.0,
    )

    if fonction == 'dens' and not is_diff:
        cb.ax.yaxis.set_major_formatter(FuncFormatter(lambda x, p: f'{x:.1e}'))

    y_labels = {
        'dens':   ('Increase in sum(dens)/days rel. to {ref} [%]',
                   'Density [obs/km²]/day'),
        'nobs':   ('Increase in sum(obs)/days rel. to {ref} [%]',
                   'Total Obs/day'),
        'omp':    ('Improvement in OMP rel. to {ref} [%]',
                   'OMP {units}'),
        'oma':    ('Improvement in OMA rel. to {ref} [%]',
                   'OMA {units}'),
        'obs':    ('Improvement in {var} rel. to {ref} [%]',
                   '{var} {units}'),
        'bcorr':  ('Increase in Bias Correction rel. to {ref} [%]',
                   'Bias Correction {units}'),
        'stdomp': ('Increase in STD(OMP) rel. to {ref} [%]',
                   'STD(OMP) {units}'),
        'stdoma': ('Increase in STD(OMA) rel. to {ref} [%]',
                   'STD(OMA) {units}'),
    }
    if fonction in y_labels:
        tmpl = y_labels[fonction][0] if is_diff else y_labels[fonction][1]
        cb.ax.set_ylabel(
            tmpl.format(ref=namesin[0], var=var_name, units=units),
            fontsize=15 if fonction == 'obs' else 18,
            rotation=90, labelpad=20,
        )

    if not is_diff:
        ax.set_title(namesin[0], loc='left',
                     fontsize=12, color='blue', pad=25)
    else:
        ax.set_title(f"Diff {namesin[0]}",  loc='left',
                     fontsize=12, color='blue', pad=25)
        ax.set_title(f"- {namesin[1]}",     loc='center',
                     fontsize=12, color='red',  pad=25)

    ax.text(0.00, 1.02, period_str, fontsize=12, color='#3366FF',
            transform=ax.transAxes)
    ax.text(0.35, 1.05, title_var,  fontsize=12, color='black',
            transform=ax.transAxes, fontweight='bold')
    ax.text(0.5, -0.08, 'Longitude', transform=ax.transAxes,
            ha='center', va='top',    fontsize=14)
    ax.text(-0.06, 0.5, 'Latitude',  transform=ax.transAxes,
            ha='center', va='bottom', rotation='vertical', fontsize=14)

    props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
    if not is_diff:
        if fonction in ('dens', 'nobs'):
            textstr = f'Nobs={int(on_map_obs)} (for {n_days:.2f} days)'
        else:
            textstr = (f'$\\bar{{\\mu}}={mu_val:.3f}$ '
                       f'$\\bar{{\\sigma}}={sigma_val:.3f}$ \n'
                       f'Nobs={int(on_map_obs)} (for {n_days:.2f} days)')
    else:
        denom   = max(on_map_obs2 * n_days, 1e-9)
        pct     = (on_map_obs / denom) * 100.0
        textstr = (f'Diff Nobs={int(on_map_obs)} \n'
                   f'Diff%={pct:.2f}% for {n_days:.2f} days')
    ax.text(0.85, 1.10, textstr, transform=ax.transAxes,
            fontsize=12, verticalalignment='top', bbox=props)

    plt.rcParams['axes.linewidth'] = 2
    vc_tag   = (f"_{int(vcoord)}" if vcoord != 'join' else "_join")
    out      = (f"{fonction}_{proj}_{_safe_filename(layer_label)}_"
                f"flag_{_safe_filename(flag_criteria)}_"
                f"id_stn_{_safe_filename(id_stn)}_{region}_"
                f"vcoord{vc_tag}_varno{varno}{wind_suffix}.png")
    out_path = os.path.join(pathwork, family, out)
    plt.savefig(out_path, dpi=DPI, format='png', bbox_inches='tight')
    plt.close('all')
    return out


scatter_plot = _render_tile_map


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 3 — HTML viewer
# ─────────────────────────────────────────────────────────────────────────────

def _viewer_filename(entry: Dict[str, Any]) -> str:
    layer = _layer_display(entry['interval'])
    vc    = (f"_{int(entry['vcoord'])}"
             if entry['vcoord'] != 'join' else "_join")
    wm    = (f"_OBS_SWMT_{entry['WIND_COMP_METHOD']}_"
             if entry.get('WIND_COMP_METHOD') is not None else "")
    return (f"{entry['function']}_{entry['proj']}_"
            f"{_safe_filename(layer)}_"
            f"flag_{_safe_filename(entry['flag_criteria'])}_"
            f"id_stn_{_safe_filename(entry['id_stn'])}_"
            f"{entry['region']}_vcoord{vc}_varno{entry['varno']}{wm}.png")


def _build_viewer_items(data_list_plot: List[Dict[str, Any]]
                        ) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    for d in data_list_plot:
        items.append({
            'family':   str(d['family']).strip(),
            'region':   str(d['region']).strip(),
            'flag':     str(d['flag_criteria']).strip(),
            'function': str(d['function']).strip(),
            'varno':    str(d['varno']).strip(),
            'vcoord':   str(d['vcoord']).strip(),
            'proj':     str(d['proj']).strip(),
            'id_stn':   _codtyp_label(str(d['id_stn']).strip()),  # PATCH A
            'wind':     str(d.get('WIND_COMP_METHOD') or '-').strip(),
            'filename': f"{d['family']}/{_viewer_filename(d)}",
        })
    return items


# ─────────────────────────────────────────────────────────────────────────────
# Utility
# ─────────────────────────────────────────────────────────────────────────────

def _silence_distributed_loggers() -> None:
    for name in (
        "distributed", "distributed.client",  "distributed.scheduler",
        "distributed.worker", "distributed.nanny",
        "distributed.core",   "distributed.comm",
        "distributed.utils",  "distributed.utils_perf",
        "tornado", "tornado.application", "asyncio",
    ):
        logging.getLogger(name).setLevel(logging.CRITICAL)


# ─────────────────────────────────────────────────────────────────────────────
# Orchestrator
# ─────────────────────────────────────────────────────────────────────────────

def make_scatter(files_in:      List[str],
                 names_in:      List[str],
                 pathwork:      str,
                 datestart:     str,
                 dateend:       str,
                 regions:       List[str],
                 families:      List[str],
                 flag_criteria: str,
                 fonctions:     List[str],
                 varnos:        List[str],
                 boxsizex:      float,
                 boxsizey:      float,
                 projs:         List[str],
                 mode:          str,
                 Points:        str,
                 id_stn:        str,
                 channel:       str,
                 n_cpu:         int,
                 intervales:    List[Tuple[Optional[int], Optional[int]]]
                 ) -> None:
    """End-to-end scatter pipeline: aggregate → plot → HTML viewer."""
    for family in families:
        pikobs.delete_create_folder(pathwork, family)

    data_list = create_data_list(
        datestart, dateend, families, files_in, names_in, pathwork,
        boxsizex, boxsizey, fonctions, flag_criteria, regions, varnos,
        intervales,
    )

    _silence_distributed_loggers()

    # Phase 1: aggregation
    t0 = time.time()
    if n_cpu == 1:
        print(f"[scatter] Serial aggregation: {len(data_list)} tasks")
        for d in data_list:
            create_and_populate_moyenne_table(
                d['family'], d['db_new'], d['filein'],
                d['region'], d['flag_criteria'], d['function'],
                d['boxsizex'], d['boxsizey'], d['varnos'],
                channel, id_stn, d['interval'],
            )
    else:
        print(f"[scatter] Parallel aggregation: "
              f"{len(data_list)} × {n_cpu} workers")
        client = Client(processes=True, threads_per_worker=1,
                        n_workers=n_cpu, silence_logs=50,
                        dashboard_address=None)
        try:
            dask.compute(*[
                dask.delayed(create_and_populate_moyenne_table)(
                    d['family'], d['db_new'], d['filein'],
                    d['region'], d['flag_criteria'], d['function'],
                    d['boxsizex'], d['boxsizey'], d['varnos'],
                    channel, id_stn, d['interval'],
                ) for d in data_list
            ])
        finally:
            try: client.close(timeout=30)
            except Exception: pass
            try: client.shutdown()
            except Exception: pass
    print(f"[scatter] aggregation time: {time.time() - t0:.1f}s")

    # Phase 2: plots
    data_list_plot = create_data_list_plot(
        datestart, dateend, families, names_in, pathwork,
        boxsizex, boxsizey, fonctions, flag_criteria, regions,
        id_stn, channel, projs, intervales,
    )

    t0 = time.time()
    if n_cpu == 1:
        print(f"[scatter] Serial plots: {len(data_list_plot)}")
        for d in data_list_plot:
            _render_tile_map(
                mode, d['region'], d['family'], d['id_stn'],
                datestart, dateend, Points,
                boxsizex, boxsizey, d['proj'], pathwork,
                flag_criteria, d['function'], d['vcoord'],
                d['files_in'], names_in, d['varno'],
                d['interval'], d['WIND_COMP_METHOD'],
            )
    else:
        print(f"[scatter] Parallel plots: "
              f"{len(data_list_plot)} × {n_cpu} workers")
        time.sleep(2)
        client = Client(processes=True, threads_per_worker=1,
                        n_workers=n_cpu, silence_logs=50,
                        dashboard_address=None)
        try:
            dask.compute(*[
                dask.delayed(_render_tile_map)(
                    mode, d['region'], d['family'], d['id_stn'],
                    datestart, dateend, Points,
                    boxsizex, boxsizey, d['proj'], pathwork,
                    flag_criteria, d['function'], d['vcoord'],
                    d['files_in'], names_in, d['varno'],
                    d['interval'], d['WIND_COMP_METHOD'],
                ) for d in data_list_plot
            ])
        finally:
            try: client.close(timeout=30)
            except Exception: pass
            try: client.shutdown()
            except Exception: pass
    print(f"[scatter] plot time: {time.time() - t0:.1f}s")

    # Phase 3: HTML viewer
    pikobs.generate_web(
        _build_viewer_items(data_list_plot),
        ["family", "region", "flag", "function",
         "varno",  "vcoord", "proj", "id_stn", "wind"],
        os.path.join(pathwork, "pikobs_scatter_viewer.html"),
        title="Pikobs Scatter Viewer",
    )

    print(f"[scatter] done — output in: {pathwork}")


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def parse_intervals(text: str
                    ) -> List[Tuple[Optional[int], Optional[int]]]:
    pattern = r'\(\s*(\d*)\s*,\s*(\d*)\s*\)'
    out: List[Tuple[Optional[int], Optional[int]]] = []
    for a, b in re.findall(pattern, text):
        out.append((
            int(a) if a.isdigit() else None,
            int(b) if b.isdigit() else None,
        ))
    return out


def arg_call() -> None:
    """Parse the command line and dispatch to :func:`make_scatter`."""
    p = argparse.ArgumentParser(
        prog="pikobs-scatter",
        description="Geographic tiled statistics with optional A/B compare.",
    )
    p.add_argument('--path_control_files',    default='undefined')
    p.add_argument('--control_name',          default='undefined')
    p.add_argument('--path_experience_files', default='undefined')
    p.add_argument('--experience_name',       default='undefined')
    p.add_argument('--pathwork',              default='undefined')
    p.add_argument('--datestart',             default='undefined')
    p.add_argument('--dateend',               default='undefined')
    p.add_argument('--region',         nargs='+', default='undefined')
    p.add_argument('--family',         nargs='+', default='undefined')
    p.add_argument('--flags_criteria', default='undefined',
                   help="Single flag-criteria key.")
    p.add_argument('--fonction',       nargs='+', default='undefined')
    p.add_argument('--varnos',         nargs='+', default='undefined')
    p.add_argument('--boxsizex',   type=int, default='undefined')
    p.add_argument('--boxsizey',   type=int, default='undefined')
    p.add_argument('--projection', nargs='+', default=['cyl'],
                   help="cyl, OrthoN, OrthoS, robinson, Europe, Canada, "
                        "AmeriqueNord, Npolar, Spolar, reg.")
    p.add_argument('--mode',    default='SIGMA')
    p.add_argument('--Points',  default='OFF')
    p.add_argument('--id_stn',  default='one_per_plot')
    p.add_argument('--channel', default='one_per_plot')
    p.add_argument('--n_cpus',  type=int, default=1)
    p.add_argument('--layer',   nargs='?', default='[(,)]',
                   help="Intervals string, e.g. '[(,),(700,900)]'.")
    p.add_argument('--walltime', default='02:00:00',        # PATCH 3
                   help="PBS walltime HH:MM:SS (default: 02:00:00).")
    p.add_argument('--no_submit', action='store_true',
                   help="Skip PBS auto-submission and run locally.")

    args = p.parse_args()
    for arg in vars(args):
        print(f'--{arg} {getattr(args, arg)}')

    if args.path_control_files == 'undefined':
        files_in = [args.path_experience_files]
        names_in = [args.experience_name]
    else:
        if args.path_experience_files == 'undefined':
            raise ValueError("--path_experience_files is required")
        if args.experience_name == 'undefined':
            raise ValueError("--experience_name is required")
        files_in = [args.path_control_files, args.path_experience_files]
        names_in = [args.control_name,       args.experience_name]

    intervals = parse_intervals(args.layer)

    if args.varnos == 'undefined':
        args.varnos = []

    for attr, flag in [
        ('pathwork',       '--pathwork'),
        ('datestart',      '--datestart'),
        ('dateend',        '--dateend'),
        ('region',         '--region'),
        ('family',         '--family'),
        ('flags_criteria', '--flags_criteria'),
        ('fonction',       '--fonction'),
        ('boxsizex',       '--boxsizex'),
        ('boxsizey',       '--boxsizey'),
    ]:
        if getattr(args, attr) == 'undefined':
            raise ValueError(f"{flag} is required")

    maybe_submit_to_pbs(args)

    sys.exit(make_scatter(
        files_in, names_in, args.pathwork,
        args.datestart, args.dateend,
        args.region, args.family, args.flags_criteria,
        args.fonction, args.varnos,
        args.boxsizex, args.boxsizey,
        args.projection, args.mode, args.Points,
        args.id_stn, args.channel, args.n_cpus, intervals,
    ))


if __name__ == "__main__":
    arg_call()
