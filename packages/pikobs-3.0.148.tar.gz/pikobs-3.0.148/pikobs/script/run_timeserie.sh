#/bin/bash
which python
#/home/sprj700/data_maestro/ppp6/maestro_archives/G2FC900V2E22/monitoring/banco/postalt/
#/home/dlo001/data_maestro/ppp5/maestro_archives/E22S2T50C/banco/postalt/
python -c 'import pikobs; pikobs.timeserie.arg_call()'\
         --path_control_files /home/dlo001/sites8/TESTg0/ \
         --control_name  g0 \
         --path_experience_files /home/dlo001/sites8/TESTg2/ \
         --experience_name  g2 \
         --pathwork /home/dlo001/sites8/pikoks/work    \
         --datestart  2026031000            \
         --dateend    2026031500            \
         --region     Monde PoleNord                \
         --family     to_amsua_allsky \
         --flags_criteria assimilee         \
         --fonction   oma omp            \
         --id_stn     all              \
         --channel    all                \
         --n_cpu      40

         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

