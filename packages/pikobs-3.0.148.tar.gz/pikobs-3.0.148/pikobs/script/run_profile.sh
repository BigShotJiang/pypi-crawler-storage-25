#/bin/bash
which python

python -c 'import pikobs; pikobs.profile.arg_call()'\
         --path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
         --experience_name  GIC5DA1E22_DDT \
         --path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
         --experience_name  GIC5DA1E22_DDT \
         --pathwork work_to_amsua_allsky   \
         --datestart  2022061500           \
         --dateend    2022061700           \
         --region     Monde                \
         --family     sw      \
         --flags_criteria assimilee         \
         --fonction  omp                    \
         --boxsizex 2 \
         --boxsizey 2  \
         --id_stn     all               \
         --channel    all               \
         --n_cpu      40

         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

