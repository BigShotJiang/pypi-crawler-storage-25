#!/usr/bin/env bash
# ============================================================================
# run_mapobs.sh 
# ----------------------------------------------------------------------------
# Wrapper to generate 6-hour & 15-min geographic observation coverage maps.
# This script relies on Pikobs' built-in intelligent PBS job manager to
# automatically submit to the queue if run from a login node.
# ============================================================================
set -eo pipefail

# ============================================================================
# 1. USER SETTINGS (Edit these parameters)
# ============================================================================

# Directory containing the SQLite observation databases (YYYYMMDDHH_<family>).
PATH_EXPERIENCE="/home/smco500/.suites/gdps/g2/hub/ppp8/monitoring/banco/bgckalt"

# Label printed on the title of every generated figure.
EXPERIENCE_NAME="experience"

# Output directory where the generated maps and HTML viewer will be saved.
# Warning: This directory is wiped on each run to prevent ghost files.
PATHWORK="/home/dlo001/sites8/pikobszone_exp2"

# Start and end dates for the processing window in YYYYMMDDHH format (UTC).
DATESTART="2026051000"
DATEEND="2026051200"

# Observation family to process (e.g., sw, tmp, uv, ps).
FAMILY="sw"

# Bitmask filter criteria (use "all" to include everything, or specific keys).
FLAGS_CRITERIA="all"

# Station ID filter (use "all" or "join" to process all available stations).
ID_STN="all"

# Number of parallel Dask workers to use for rendering the maps.
N_CPUS=40


# ============================================================================
# 2. SYSTEM SETUP (Do not edit below this line)
# ============================================================================

# --- Load Pikobs Conda Environment ---
source /home/${USER}/pikobs_install/load_pikobs.sh


# ============================================================================
# 3. EXECUTION
# ============================================================================
# Pikobs will automatically submit this to PBS if run on a login node.

python -c 'import pikobs; pikobs.mapobs.arg_call()' \
       --path_experience "${PATH_EXPERIENCE}" \
       --experience_name "${EXPERIENCE_NAME}" \
       --pathwork "${PATHWORK}" \
       --datestart "${DATESTART}" \
       --dateend "${DATEEND}" \
       --family "${FAMILY}" \
       --flags_criteria "${FLAGS_CRITERIA}" \
       --id_stn "${ID_STN}" \
       --n_cpus "${N_CPUS}"
#      --no_submit
