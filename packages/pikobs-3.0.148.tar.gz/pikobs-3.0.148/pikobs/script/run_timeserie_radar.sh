#/bin/bash
which python

python -c 'import pikobs; pikobs.timeserie.arg_call()'\
         --pathin  /home/dlo001/data_maestro/ppp5/maestro_archives/E22S2T50C/banco/postalt/ \
         --pathwork work_to_amsua_allsky    \
         --datestart  2022060100            \
         --dateend    2022061000         \
         --region     Monde                 \
         --family     radar      \
         --flags_criteria assimilee         \
         --fonction  omp                    \
         --boxsizex   2                     \
         --boxsizey   2                     \
         --Proj       cyl                   \
         --mode       SIGMA                 \
         --Points     OFF                   \
         --id_stn     all                \
         --channel    all                 \
         --n_cpu      1

         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

