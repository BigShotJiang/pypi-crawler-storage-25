#/bin/bach
exp1="experience"
exp2="control"
dir1="/home/dlo001/sites8/Data_pikobs/monitoring/"
dir1="/home/dlo001/sites8/Data_pikobs/monitoring0/"

python -c 'import pikobs; pikobs.zone.arg_call()' \
     --path_control_files /home/dlo001/sites8/Data_pikobs/monitoring0 \
     --control_name control \
     --path_experience_files /home/dlo001/sites8/Data_pikobs/monitoring \
     --experience_name experience \
     --pathwork /home/dlo001/sites8/pikobszone \
     --datestart 2026021000 \
     --dateend 2026021500 \
     --region Monde \
     --family sw \
     --flags_criteria assimilee \
     --projection cyl \
     --id_stn join \
     --channel all \
     --n_cpus 80


#   --path_control_files ${dir1}                       \
#     --control_name  ${exp1}                            \
   

#--path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
# --experience_name  GIC5DA1E22_DDT\
#
# --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
#  --control_name G2IC5DA1E22 \

