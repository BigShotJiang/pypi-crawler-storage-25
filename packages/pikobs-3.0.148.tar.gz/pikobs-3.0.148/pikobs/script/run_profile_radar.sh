#/bin/bash
which python

python -c 'import pikobs; pikobs.profile.arg_call()'\
         --path_control_files  /home/dlo001/data_maestro/ppp5/maestro_archives/E22S5T50C/banco/postalt/ \
         --control_name  E22SLT50NWAI \
         --path_experience_files  /home/dlo001/data_maestro/ppp5/maestro_archives/E22SLT50NWAI/banco/postalt/ \
         --experience_name  E22SLT50NWAI2 \
         --pathwork work_to_amsua_allsky    \
         --datestart  2022060100           \
         --dateend    2022061000            \
         --region     Monde                 \
         --family     radar                 \
         --flags_criteria assimilee         \
         --fonction  omp                    \
         --id_stn     all                 \
         --channel    all                   \
         --plot_title  TEST_RADAR                \
         --plot_type  wide                  \
         --n_cpu      40

         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

