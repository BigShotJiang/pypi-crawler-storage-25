#/bin/bach

python -c 'import pikobs; pikobs.scatter.arg_call()' \
      --path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
      --experience_name G2IC5DA1E22_post\
      --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
      --control_name GIC5DA1E22_DDT\
      --pathwork /fs/site5/eccc/cmd/a/dlo001/work_zone_s/work_scatter_diff2\
      --datestart 2022053100 \
      --dateend 2022063000 \
      --region Monde \
      --family ssmis \
      --flags_criteria assimilee \
      --fonction  oma omp nobs dens obs\
      --boxsizex 10\
      --boxsizey 10  \
      --projection cyl\
     --id_stn all \
     --channel all \
     --n_cpu 80  
     
     #--path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
     # --control_name G2IC5DA1E22_post\
     
     #--path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
    # --control_name G2IC5DA1E22_post\
    #  --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
    #  --control_name G2IC5DA1E22_post\
  
    # --path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
   #  --experience_name GIC5DA1E22_DDT\
 
     #  --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
   #  --control_name G2IC5DA1E22 \
#/home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ 
#control : /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/banco/postalt/     
#--path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
#--control_name GIC5DA1E22_DDT \
#a#    --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
  
