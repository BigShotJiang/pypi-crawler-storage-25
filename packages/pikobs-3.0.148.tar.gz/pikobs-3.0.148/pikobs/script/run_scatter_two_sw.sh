#/bin/bash
which python

#exp1="G2FC900V2E23"
exp1="G2900E22JK26"
#exp2="G2900E22JK27"
#exp2="G2900E22JK30"
exp2="G2900E22JK31"

#dir1="/home/sprj700//data/ppp6/maestro_archives/G2FC900V2E22/monitoring/banco/postalt"
dir1="/home/jwk001/sitestore5/maestro_archives/${exp1}/monitoring/banco/postalt"
dir2="/home/jwk001/sitestore5/maestro_archives/${exp2}/monitoring/banco/postalt"

python -c 'import pikobs; pikobs.scatter.arg_call()'\
         --path_experience_files  ${dir2}           \
         --experience_name  ${exp2}                 \
         --path_control_files  ${dir1}           \
         --control_name  ${exp1}                 \
         --pathwork   /fs/site6/eccc/cmd/a/dlo001/work_pikobs_scatter  \
         --datestart  2022060100                    \
         --dateend    2022072518                    \
         --region     Monde                         \
         --family     sw               \
         --flags_criteria assimilee                 \
         --fonction   omp stdomp  \
         --boxsizex   10                            \
         --boxsizey   10                            \
         --projection cyl                           \
         --id_stn     join                         \
         --channel    join                          \
         --n_cpu      40                            \
         --layer      "[(,)]"            \


       
# Comment
# projectio     = 'cyl' 'OrthoN' 'OrthoS' 'robinson' 'Europe' 'Canada' 'AmeriqueNord' 'Npolar' 'Spolar' 'hrdps'
# flagPcriteria = 'all' 'assimille' 'bgckalt' 'bgckalt_qc' 'monitoring' 'postalt'
# fonction      = 'omp' 'oma' 'obs' 'dens' 'bcorr'
        
