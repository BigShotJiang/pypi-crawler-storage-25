#/bin/bash
which python

python -c 'import pikobs; pikobs.histogram.arg_call()' \
         --path_experience_files /home/dlo001/sites8/Data_pikobs/monitoring/ \
         --experience_name experience \
         --control_name control \
         --path_control_files /home/dlo001/sites8/Data_pikobs/monitoring0/  \
         --pathwork /home/dlo001/sites8/pikobshitogram \
         --datestart 2026020100 \
         --dateend 2026020600 \
         --region Monde \
         --family sw \
         --id_stn all \
         --channel join \
         --flags_criteria assimilee \
         --n_cpus 40
         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

