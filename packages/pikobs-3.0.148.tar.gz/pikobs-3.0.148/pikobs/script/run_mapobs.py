#/bin/bash
exp1="experience"
exp2="control"
dir1="/home/dlo001/sites8/Data_pikobs/monitoring/"
dir1="/home/dlo001/sites8/Data_pikobs/monitoring0/"

python -c 'import pikobs; pikobs.mapobs.arg_call()' \
     --path_experience /home/dlo001/sites8/Data_pikobs/monitoring \
     --experience_name experience \
     --pathwork /home/dlo001/sites8/pikobszone_exp2\
     --datestart 2026021000 \
     --dateend 2026021200 \
     --family sw ch to_amsua_allsky to_amsub_allsky\
     --flags_criteria  all \
     --id_stn all \
     --n_cpus 40  \
     --projection cly
 #ch to_amsua_allsky to_amsub_allsky \
    
#   --path_control_files ${dir1}                       \
#     --control_name  ${exp1}                            \
   

#--path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
# --experience_name  GIC5DA1E22_DDT\
#
# --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
#  --control_name G2IC5DA1E22 \

