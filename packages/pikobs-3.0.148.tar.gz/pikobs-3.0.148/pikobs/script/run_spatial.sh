#/bin/bach
. r.load.dot cmd/cmda/utils/20260202/burp2rdb_5.25_rhel-9-amd64-64
. ssmuse-sh -d eccc/cmd/cmda/utils/20260202

. ssmuse-sh -d eccc/cmo/cmoi/base/20260205
export BURP2RDB_BIN="/fs/ssm/eccc/cmd/cmda/utils/20260202/burp2rdb_5.25_rhel-9-amd64-64/bin/burp2rdb"
echo "Herramienta burp2rdb encontrada en: $BURP2RDB_BIN"

# 1. Define cuál es TU Python (el que sí tiene numpy/pandas que funcionan):



#--path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
# --experience_name  GIC5DA1E22_DDT\
#
# --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
#  --control_name G2IC5DA1E22 \
# Caso típico — sin parámetros de tuning, todo automático:
python -c 'import pikobs; pikobs.spatial.arg_call()' \
    --path_experience_files /home/dlo001/sites8/comvert/Expericience1/ \
    --experience_name        Exp1 \
    --pathwork               /home/dlo001/sites8/spatial/ \
    --datestart 2022060100 --dateend 2022060512 \
    --family    ro \
    --flags_criteria all \
    --id_stn all \
    --fonction       omp \
    --n_cpus         8
