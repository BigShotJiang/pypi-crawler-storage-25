#/bin/bash
which python

python -c 'import pikobs; pikobs.scatter.arg_call()'\
         --path_experience_files /home/dlo001/data_maestro/ppp5/maestro_archives/E22NWAI2/monitoring/banco/postalt/ \
         --experience_name E22NWAI2                        \
         --pathwork work_to_amsua_allsky_scatter_omp \
         --datestart  2022061400            \
         --dateend    2022062400            \
         --region     Monde                 \
         --family     atms_allsky           \
         --flags_criteria assimilee         \
         --fonction   omp oma bcorr dens obs \
         --boxsizex   2                     \
         --boxsizey   2                     \
         --Proj       robinson              \
         --id_stn     alone                 \
         --channel      alone                 \
         --n_cpu      40      
         
