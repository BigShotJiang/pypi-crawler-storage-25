#/bin/bash
which python
#/home/sprj700/data_maestro/ppp6/maestro_archives/G2FC900V2E22/monitoring/banco/postalt/
#/home/dlo001/data_maestro/ppp5/maestro_archives/E22S2T50C/banco/postalt/
python -c 'import pikobs; pikobs.flags.arg_call()'\
         --path_experience_files /home/smco500/.suites/gdps/g2/hub/ppp7/monitoring/banco/postalt/ \
         --experience_name   g2   \
         --pathwork   /home/dlo001/sites8/pikobsflag  \
         --datestart  2026040500           \
         --dateend    2026040900            \
         --region     Monde Canada                 \
         --family     atms_allsky cris  \
         --id_stn     join \
         --channel    join \
         --n_cpu      80

         # /home/kas002/.suites/ASSIMCYCLE/ac110_glbic5da1/hub/ppp8/monitoring/banco/postalt/ \
          
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

