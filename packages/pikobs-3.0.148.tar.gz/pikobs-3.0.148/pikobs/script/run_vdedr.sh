#/bin/bash
which python

python -c 'import pikobs; pikobs.vdedr.arg_call()'\
         --path_control_files /home/dlo001/sites8/Data_pikobs/monitoring0/  \
         --control_name  g0 \
         --path_experience_files /home/dlo001/sites8/Data_pikobs/monitoring/  \
         --experience_name  g2    \
         --pathwork /home/dlo001/sites8/pikobsvdedr    \
         --datestart  2026020100            \
         --dateend    2026020600            \
         --region     Monde Canada  \
         --family     to_amsua_allsky atms_allsky      \
         --flags_criteria clear_sky cloudy_sky clear_cloudy_sky       \
         --id_stn 'all' \
         --n_cpu      40

         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

