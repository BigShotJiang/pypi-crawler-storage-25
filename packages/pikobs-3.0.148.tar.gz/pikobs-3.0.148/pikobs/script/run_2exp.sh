#/bin/bash
which python

python -c 'import pikobs; pikobs.cardio.arg_call()'\
         --pathin  /home/sprj700/data_maestro/ppp6/maestro_archives/G2FC900V2E22/monitoring/banco/postalt/ \
         --pathwork work_to_amsua_allsky    \
         --datestart  2022061500            \
         --dateend    2022071500            \
         --region     Monde                 \
         --family     to_amsua_allsky       \
         --flags_criteria assimilee         \
         --fonction  omp                    \
         --id_stn     alone                 \
         --channel    alone                 \
         --plot_title Plot                  \
         --plot_type  wide                  \
         --n_cpu      40

         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

