#/bin/bach

python -c 'import pikobs; pikobs.scatter.arg_call()' \
     --path_experience_files /home/dlo001/sites8/Data_pikobs/monitoring0/ \
     --experience_name  GIC5DA1E22_DDT2 \
     --pathwork /home/dlo001/sites8/Data_pikobs2\
     --datestart 2026020100 \
     --dateend 2026020500 \
     --region Monde\
     --family to_amsua_allsky\
     --flags_criteria assimilee \
     --fonction omp oma nobs obs dens bcorr\
     --boxsizex 2 \
     --boxsizey 2  \
     --projection cyl\
     --id_stn all \
     --channel all \
     --n_cpu 80



#  --control_name G2IC5DA1E22 \

