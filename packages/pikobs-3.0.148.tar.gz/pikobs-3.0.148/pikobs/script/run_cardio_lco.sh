#/bin/bash
which python

python -c 'import pikobs; pikobs.cardio.arg_call()'\
         --path_experience   /home/lco000/data_maestro/ppp8/investigation/sqlite/amsuaAtms/maestro_rdb/amsuaAtms/postalt/ \
         --experience_name amsuaAtms               \
         --pathwork   /home/dlo001/sites8/pikobs/amsuaAtms         \
         --datestart  2026020100                \
         --dateend    2026022800                \
         --region     Monde                     \
         --family     to_amsua_allsky atms_allsky       \
         --flags_criteria assimilee             \
         --id_stn     all       \
         --channel    all        \
         --plot_title amsuaAtms                      \
         --n_cpu      40

#    family            mwhs2 mwhs2_qc to_amsua_qc to_amsua to_amsua_allsky 
#                      to_amsua_allsky_qc to_amsub_qc to_amsub ssmis_qc ssmis 
#                      iasi iasi_qc crisfsr1_qc crisfsr2_qc cris atms_allsky atms_qc csr csr_qc
#    region            Monde PoleNord PoleSud AmeriqueduNord OuestAmeriqueduNord AmeriqueDuNordPlus 
#                      ExtratropiquesNord HemisphereNord HemisphereSud Asie Europe Mexique Canada
#                      BaieDhudson Arctiquecanadien EtatsUnis Tropiques30 Tropiques Australie Pacifique
#                      Atlantique
#    flags_criteria    all assimilee bgckalt bgckalt_qc monitoring postalt   
