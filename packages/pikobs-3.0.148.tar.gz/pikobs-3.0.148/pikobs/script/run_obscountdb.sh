#/bin/bash
which python

python -c 'import pikobs; pikobs.obscountdb.arg_call()'\
         --path_experience_files /home/dlo001/sites8/Data_pikobs/monitoring/ \
         --experience_name  exprecience  \
         --control_name Control \
         --path_control_files /home/dlo001/sites8/Data_pikobs/monitoring0/ \
         --pathwork /home/dlo001/sites8/pikobsobscountdb \
         --datestart  2026020100            \
         --dateend    2026020500        \
         --region     Monde \
         --family     ai  sc atms_allsky sf ch ssmis cris sw csr  gp to_amsua_allsky iasi mwhs2 to_amsub_allsky  ro ua      \
         --flags_criteria assimilee         \
         --n_cpu      120

         
         
         # Proj=='OrthoN'// Proj=='OrthoS'// Proj=='robinson' // Proj=='Europe' // Proj=='Canada' // Proj=='AmeriqueNord' // Proj=='Npolar' //  Proj=='Spolar' // Proj == 'reg'

