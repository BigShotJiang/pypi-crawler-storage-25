#/bin/bach

python -c 'import pikobs; pikobs.profile.arg_call()' \
     --path_experience_files /home/dlo001/sites8/TESTg2/  \
     --experience_name  expericience \
     --pathwork /home/dlo001/sites8/pikobsprofile \
     --datestart 2026031000 \
     --dateend   2026031500\
     --region Monde\
     --family sw \
     --flags_criteria assimilee \
     --fonction omp \
     --boxsizex 2 \
     --boxsizey 2  \
     --id_stn all \
     --channel all \
     --n_cpu 80



#--path_experience_files /home/ata000/data_maestro/ppp5/maestro_archives/GIC5DA1E22_DDT/monitoring/banco/postalt/ \
# --experience_name  GIC5DA1E22_DDT\
#
# --path_control_files /home/ata000/data_maestro/ppp5/maestro_archives/G2IC5DA1E22_post/monitoring/banco/postalt/ \
#  --control_name G2IC5DA1E22 \

