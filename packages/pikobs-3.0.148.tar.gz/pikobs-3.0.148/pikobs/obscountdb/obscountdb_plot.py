import os
import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import io
import base64
from rich.console import Console
from rich.table import Table
from rich import box

def obscountdb_plot(
    region,
    families, 
    datestart,
    dateend, 
    pathwork, 
    namesin,
    flag_criteria
):
    if len(namesin) != 2:
        raise ValueError("The 'namesin' list must contain exactly two names to compare.")
    
    name1, name2 = namesin[0], namesin[1]  # name1 is the REFERENCE (0)
    console = Console(width=220)
    
    list_df_overall = []
    list_df_stn = []
    list_df_stn_ts = []  

    console.print(f"[bold yellow]Extracting data from databases in: {pathwork}[/bold yellow]")

    # 1. DATA EXTRACTION
    for family in families:
        for name in namesin:
            db_file = os.path.join(pathwork, f"{name}_{family}", f'{name}_{region}_{datestart}_{dateend}_{flag_criteria}_{family}.db')
            
            if not os.path.exists(db_file):
                db_file = os.path.join(pathwork, family, f'{name}_{region}_{datestart}_{dateend}_{flag_criteria}_{family}.db')

            if not os.path.exists(db_file):
                console.print(f"[red]  Warning: File not found {db_file}[/red]")
                continue
                
            conn = sqlite3.connect(db_file)
            
            # OVERALL TOTALS
            query_overall = "SELECT SUM(Nobsdata) as Nobs, SUM(Nobsprofile) as NobsProfiles FROM moyenne;"
            df_ov = pd.read_sql_query(query_overall, conn)
            df_ov['family'], df_ov['name'] = family, name
            list_df_overall.append(df_ov)
            
            # BY STATION
            if family in ['spp']:
                console.print(f"[cyan]  Skipping station breakdown for '{family}' (Too many id_stn).[/cyan]")
            else:
                query_stn = "SELECT id_stn, SUM(Nobsdata) as Nobs, SUM(Nobsprofile) as NobsProfiles FROM moyenne GROUP BY id_stn;"
                df_stn = pd.read_sql_query(query_stn, conn)
                df_stn['family'], df_stn['name'] = family, name
                list_df_stn.append(df_stn)

                try:
                    query_stn_ts = "SELECT date, id_stn, SUM(Nobsdata) as Nobs FROM moyenne GROUP BY date, id_stn;"
                    df_stn_ts = pd.read_sql_query(query_stn_ts, conn)
                    df_stn_ts['family'], df_stn_ts['name'] = family, name
                    list_df_stn_ts.append(df_stn_ts)
                except Exception as e:
                    console.print(f"[red]Could not extract 'date' for plots: {e}[/red]")
            
            conn.close()

    # --- Compute number of 6h timesteps in the period ---
    # datestart and dateend are YYYYMMDDHH strings; interval is 6h
    try:
        dt_start = pd.to_datetime(str(datestart), format='%Y%m%d%H')
        dt_end   = pd.to_datetime(str(dateend),   format='%Y%m%d%H')
        n_timesteps = max(1, int((dt_end - dt_start).total_seconds() / (6 * 3600)) + 1)
    except Exception:
        n_timesteps = 1
    console.print(f"[bold yellow]  Period: {datestart} -> {dateend}  |  6h timesteps: {n_timesteps}[/bold yellow]")

    def calculate_pct(diff, ref):
        return np.where(ref == 0, np.where(diff > 0, 100.0, 0.0), (diff / ref) * 100.0)

    def format_df_for_png(df):
        df_png = df.copy()
        # Total counts — thousands separator for readability on large periods
        for col in df_png.columns:
            if col.startswith('Nobs') or col.startswith('Profiles'):
                if df_png[col].dtype in ['int64', 'int32', 'float64']:
                    df_png[col] = df_png[col].apply(lambda x: f"{int(x):,}")
        for col in ['Diff_Nobs', 'Diff_Profiles']:
            if col in df_png.columns:
                df_png[col] = df_png[col].apply(
                    lambda x: f"+{int(x):,}" if x > 0 else f"{int(x):,}")
        for col in ['Pct_Nobs', 'Pct_Profiles']:
            if col in df_png.columns:
                df_png[col] = df_png[col].apply(
                    lambda x: f"+{x:.1f}%" if x > 0 else f"{x:.1f}%")
        # Mean columns are already formatted strings
        return df_png

    def save_df_as_png(df, filename, title):
        fig_height = max(2, len(df) * 0.35 + 1.5)
        fig, ax = plt.subplots(figsize=(18, fig_height))
        ax.axis('off')
        ax.axis('tight')

        mpl_table = ax.table(
            cellText=df.values,
            colLabels=df.columns,
            cellLoc='center',
            loc='center',
            colColours=['#4C72B0'] * len(df.columns)
        )
        
        mpl_table.auto_set_font_size(False)
        mpl_table.set_fontsize(10)
        mpl_table.scale(1.2, 1.5)
        for k, cell in mpl_table._cells.items():
            cell.set_edgecolor('white')
            if k[0] == 0:
                cell.set_text_props(weight='bold', color='white')

        plt.title(title, fontsize=14, fontweight='bold', pad=20)
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()

    def color_html_diff(val):
        if isinstance(val, (int, float)):
            if val > 0: return 'color: green; font-weight: bold;'
            elif val < 0: return 'color: red; font-weight: bold;'
        return ''

    def _fmt_mean(val):
        """Format a mean value with appropriate precision and thousands separator."""
        if val >= 10000:
            return f"{val:,.0f}"
        elif val >= 1000:
            return f"{val:,.0f}"
        elif val >= 100:
            return f"{val:,.1f}"
        elif val >= 10:
            return f"{val:.1f}"
        elif val >= 1:
            return f"{val:.2f}"
        else:
            return f"{val:.3f}"

    def add_mean_cols(df, nobs_col1, nobs_col2, prof_col1, prof_col2, n_ts):
        """Add mean-per-6h-timestep columns for Nobs and Profiles (ref and exp).
        Values are formatted as strings with thousands separators and
        adaptive decimal precision so large numbers stay readable."""
        df[f'MeanNobs_REF']  = (df[nobs_col1] / n_ts).apply(_fmt_mean)
        df[f'MeanNobs_EXP']  = (df[nobs_col2] / n_ts).apply(_fmt_mean)
        if prof_col1 in df.columns and prof_col2 in df.columns:
            df[f'MeanProf_REF'] = (df[prof_col1] / n_ts).apply(_fmt_mean)
            df[f'MeanProf_EXP'] = (df[prof_col2] / n_ts).apply(_fmt_mean)
        return df

    # --- HTML REPORT INITIALIZATION ---
    html_content = f"""
    <html>
    <head>
        <meta charset="utf-8">
        <title>Observation Report ({region}) | Criteria: {flag_criteria} | Period: {datestart} {dateend}</title>
        <style>
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 40px; background-color: #f9f9f9; }}
            h1, h2, h3, h4 {{ color: #333; }}
            h1 {{ border-bottom: 2px solid #4C72B0; padding-bottom: 10px; }}
            table {{ border-collapse: collapse; width: 95%; margin-bottom: 40px; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            th, td {{ border: 1px solid #ddd; padding: 12px; text-align: center; }}
            th {{ background-color: #4C72B0; color: white; position: sticky; top: 0; }}
            tr:nth-child(even) {{ background-color: #f2f2f2; }}
            tr:hover {{ background-color: #ddd; }}
            td.mean-col {{ background-color: #eef4ff; font-style: italic; color: #2a4d8f; }}
            .note {{ font-size: 0.85em; color: #666; font-style: italic; margin-bottom: 8px; }}
            .note {{ font-size: 0.85em; color: #666; font-style: italic; margin-bottom: 8px; }}
        </style>
    </head>
    <body>
        <h1>Period: {datestart}-{dateend} every 06h: {name1} (Ref) vs {name2} | Region: {region} | Criteria: {flag_criteria}</h1>
        <p class="note">Mean columns = total / {n_timesteps} 6h timesteps in the period.</p>
    """

    cols_order = [
        'family',
        f'Nobs (Ref: {name1})', f'Nobs ({name2})', 'Diff_Nobs', 'Pct_Nobs',
        'MeanNobs_REF', 'MeanNobs_EXP',
        f'Profiles (Ref: {name1})', f'Profiles ({name2})', 'Diff_Profiles', 'Pct_Profiles',
        'MeanProf_REF', 'MeanProf_EXP',
    ]

    # 2. PROCESS AND DISPLAY OVERALL DATA
    if list_df_overall:
        df_all = pd.concat(list_df_overall).fillna(0)
        pivot_ov = df_all.pivot(index='family', columns='name', values=['Nobs', 'NobsProfiles']).fillna(0)
        pivot_ov.columns = [f"{col[0]}_{col[1]}" for col in pivot_ov.columns]
        
        pivot_ov['Diff_Nobs'] = pivot_ov[f'Nobs_{name2}'] - pivot_ov[f'Nobs_{name1}']
        pivot_ov['Pct_Nobs'] = calculate_pct(pivot_ov['Diff_Nobs'], pivot_ov[f'Nobs_{name1}'])
        
        pivot_ov['Diff_Profiles'] = pivot_ov[f'NobsProfiles_{name2}'] - pivot_ov[f'NobsProfiles_{name1}']
        pivot_ov['Pct_Profiles'] = calculate_pct(pivot_ov['Diff_Profiles'], pivot_ov[f'NobsProfiles_{name1}'])
        
        pivot_ov = pivot_ov.rename(columns={
            f'Nobs_{name1}': f'Nobs (Ref: {name1})', f'Nobs_{name2}': f'Nobs ({name2})',
            f'NobsProfiles_{name1}': f'Profiles (Ref: {name1})', f'NobsProfiles_{name2}': f'Profiles ({name2})'
        }).reset_index()

        # Add mean-per-6h columns
        pivot_ov = add_mean_cols(
            pivot_ov,
            f'Nobs (Ref: {name1})', f'Nobs ({name2})',
            f'Profiles (Ref: {name1})', f'Profiles ({name2})',
            n_timesteps
        )

        ov_cols = ['family'] + [c for c in cols_order[1:] if c in pivot_ov.columns]
        pivot_ov = pivot_ov[ov_cols]
        for col in [f'Nobs (Ref: {name1})', f'Nobs ({name2})', 'Diff_Nobs',
                    f'Profiles (Ref: {name1})', f'Profiles ({name2})', 'Diff_Profiles']:
            pivot_ov[col] = pivot_ov[col].astype(int)

        # Short display names for Rich console (avoids truncation)
        _ov_display = {
            f'Nobs (Ref: {name1})' : f'Nobs_REF',
            f'Nobs ({name2})'      : f'Nobs_EXP',
            f'Profiles (Ref: {name1})': 'Prof_REF',
            f'Profiles ({name2})'  : 'Prof_EXP',
            'Diff_Nobs'            : 'dNobs',
            'Pct_Nobs'             : '%Nobs',
            'Diff_Profiles'        : 'dProf',
            'Pct_Profiles'         : '%Prof',
            'MeanNobs_REF'         : f'~Nobs_REF\n(/6h)',
            'MeanNobs_EXP'         : f'~Nobs_EXP\n(/6h)',
            'MeanProf_REF'         : f'~Prof_REF\n(/6h)',
            'MeanProf_EXP'         : f'~Prof_EXP\n(/6h)',
        }
        table_ov = Table(
            title=(f"OVERALL SUMMARY - {region} {flag_criteria} | Period: {datestart} {dateend} every 06h\n"
                   f"  {name1} (Ref) vs {name2} | Mean = total / {n_timesteps} timesteps"),
            box=box.ROUNDED, header_style="bold cyan")
        _col_widths = {
            'family': 8, 'id_stn': 10,
            'Nobs_REF': 12, 'Nobs_EXP': 12,
            'dNobs': 10, '%Nobs': 7,
            '~Nobs_REF\n(/6h)': 11, '~Nobs_EXP\n(/6h)': 11,
            'Prof_REF': 10, 'Prof_EXP': 10,
            'dProf': 10, '%Prof': 7,
            '~Prof_REF\n(/6h)': 10, '~Prof_EXP\n(/6h)': 10,
        }
        for col in pivot_ov.columns:
            label = _ov_display.get(col, col)
            table_ov.add_column(label, justify="right",
                                min_width=_col_widths.get(label, 10),
                                overflow="fold", no_wrap=True)

        for _, row in pivot_ov.iterrows():
            d_nobs = f"[bold green]+{row['Diff_Nobs']}[/]" if row['Diff_Nobs'] > 0 else (f"[bold red]{row['Diff_Nobs']}[/]" if row['Diff_Nobs'] < 0 else "0")
            p_nobs = f"[bold green]+{row['Pct_Nobs']:.1f}%[/]" if row['Pct_Nobs'] > 0 else (f"[bold red]{row['Pct_Nobs']:.1f}%[/]" if row['Pct_Nobs'] < 0 else "0.0%")
            d_prof = f"[bold green]+{row['Diff_Profiles']}[/]" if row['Diff_Profiles'] > 0 else (f"[bold red]{row['Diff_Profiles']}[/]" if row['Diff_Profiles'] < 0 else "0")
            p_prof = f"[bold green]+{row['Pct_Profiles']:.1f}%[/]" if row['Pct_Profiles'] > 0 else (f"[bold red]{row['Pct_Profiles']:.1f}%[/]" if row['Pct_Profiles'] < 0 else "0.0%")

            row_vals = [str(row['family'])]
            row_vals += [f"{int(row[f'Nobs (Ref: {name1})'])  :,}",
                         f"{int(row[f'Nobs ({name2})'])         :,}",
                         d_nobs, p_nobs]
            row_vals += [str(row['MeanNobs_REF']),
                         str(row['MeanNobs_EXP'])]
            row_vals += [f"{int(row[f'Profiles (Ref: {name1})'])  :,}",
                         f"{int(row[f'Profiles ({name2})'])         :,}",
                         d_prof, p_prof]
            if 'MeanProf_REF' in row.index:
                row_vals += [str(row['MeanProf_REF']),
                             str(row['MeanProf_EXP'])]
            table_ov.add_row(*row_vals)
        console.print(table_ov)
        
        overall_png_path = os.path.join(pathwork, f"Overall_Summary_{region}_{flag_criteria}.png")
        save_df_as_png(format_df_for_png(pivot_ov), overall_png_path,
                       f"Overall Comparison ({region}) - {flag_criteria} | Mean per 6h timestep ({n_timesteps} steps)")
        console.print(f"[green]✔ Overall PNG saved to: {overall_png_path}[/green]\n")
        
        html_content += "<h2>Overall Summary</h2>"
        html_content += f"<p class='note'>Mean columns = total obs / {n_timesteps} 6h timesteps (YYYYMMDDHH format).</p>"
        format_dict = {'Pct_Nobs': '{:+.1f}%', 'Pct_Profiles': '{:+.1f}%'}
        styled_ov = pivot_ov.style.applymap(color_html_diff, subset=['Diff_Nobs', 'Pct_Nobs', 'Diff_Profiles', 'Pct_Profiles']).format(format_dict).hide(axis='index')
        html_content += styled_ov.to_html()

    # 3. PROCESS AND DISPLAY STATION & FAMILY DATA
    if list_df_stn:
        df_stn_all = pd.concat(list_df_stn).fillna(0)
        pivot_stn = df_stn_all.pivot(index=['family', 'id_stn'], columns='name', values=['Nobs', 'NobsProfiles']).fillna(0)
        pivot_stn.columns = [f"{col[0]}_{col[1]}" for col in pivot_stn.columns]
        
        pivot_stn['Diff_Nobs'] = pivot_stn[f'Nobs_{name2}'] - pivot_stn[f'Nobs_{name1}']
        pivot_stn['Pct_Nobs'] = calculate_pct(pivot_stn['Diff_Nobs'], pivot_stn[f'Nobs_{name1}'])
        
        pivot_stn['Diff_Profiles'] = pivot_stn[f'NobsProfiles_{name2}'] - pivot_stn[f'NobsProfiles_{name1}']
        pivot_stn['Pct_Profiles'] = calculate_pct(pivot_stn['Diff_Profiles'], pivot_stn[f'NobsProfiles_{name1}'])
        
        pivot_stn = pivot_stn.rename(columns={
            f'Nobs_{name1}': f'Nobs (Ref: {name1})', f'Nobs_{name2}': f'Nobs ({name2})',
            f'NobsProfiles_{name1}': f'Profiles (Ref: {name1})', f'NobsProfiles_{name2}': f'Profiles ({name2})'
        }).reset_index()

        # Add mean-per-6h columns
        pivot_stn = add_mean_cols(
            pivot_stn,
            f'Nobs (Ref: {name1})', f'Nobs ({name2})',
            f'Profiles (Ref: {name1})', f'Profiles ({name2})',
            n_timesteps
        )

        stn_cols = (['family', 'id_stn'] +
                    [c for c in cols_order[1:] if c in pivot_stn.columns])
        pivot_stn = pivot_stn[stn_cols]
        for col in [f'Nobs (Ref: {name1})', f'Nobs ({name2})', 'Diff_Nobs',
                    f'Profiles (Ref: {name1})', f'Profiles ({name2})', 'Diff_Profiles']:
            pivot_stn[col] = pivot_stn[col].astype(int)

        html_content += "<h2>Station Breakdown by Family</h2>"
        html_content += f"<p class='note'>Mean columns = total obs / {n_timesteps} 6h timesteps (YYYYMMDDHH format).</p>"

        if list_df_stn_ts:
            df_stn_ts_all = pd.concat(list_df_stn_ts)
            df_stn_ts_all['date'] = pd.to_datetime(df_stn_ts_all['date'].astype(str).str.strip(), format='%Y%m%d%H', errors='coerce')
            df_stn_ts_all = df_stn_ts_all.dropna(subset=['date'])
            pivot_ts = df_stn_ts_all.pivot_table(index=['family', 'id_stn', 'date'], columns='name', values='Nobs').reset_index()

        for fam in families:
            if fam not in pivot_stn['family'].values:
                continue

            df_fam = pivot_stn[pivot_stn['family'] == fam].drop(columns=['family'])
            if df_fam.empty:
                continue
                
            _fam_display = {
                f'Nobs (Ref: {name1})' : 'Nobs_REF',
                f'Nobs ({name2})'      : 'Nobs_EXP',
                f'Profiles (Ref: {name1})': 'Prof_REF',
                f'Profiles ({name2})'  : 'Prof_EXP',
                'Diff_Nobs'            : 'dNobs',
                'Pct_Nobs'             : '%Nobs',
                'Diff_Profiles'        : 'dProf',
                'Pct_Profiles'         : '%Prof',
                'MeanNobs_REF'         : '~Nobs_REF\n(/6h)',
                'MeanNobs_EXP'         : '~Nobs_EXP\n(/6h)',
                'MeanProf_REF'         : '~Prof_REF\n(/6h)',
                'MeanProf_EXP'         : '~Prof_EXP\n(/6h)',
            }
            table_fam = Table(
                title=(f"STATIONS - {region} {flag_criteria} - Family: {fam} | "
                       f"Mean per 6h timestep ({n_timesteps} steps)"),
                box=box.SIMPLE, header_style="bold magenta")
            for col in df_fam.columns:
                label = _fam_display.get(col, col)
                table_fam.add_column(label, justify="right",
                                     min_width=_col_widths.get(label, 10),
                                     overflow="fold", no_wrap=True)

            for _, row in df_fam.iterrows():
                d_nobs = f"[green]+{row['Diff_Nobs']}[/]" if row['Diff_Nobs'] > 0 else (f"[red]{row['Diff_Nobs']}[/]" if row['Diff_Nobs'] < 0 else "0")
                p_nobs = f"[green]+{row['Pct_Nobs']:.1f}%[/]" if row['Pct_Nobs'] > 0 else (f"[red]{row['Pct_Nobs']:.1f}%[/]" if row['Pct_Nobs'] < 0 else "0.0%")
                d_prof = f"[green]+{row['Diff_Profiles']}[/]" if row['Diff_Profiles'] > 0 else (f"[red]{row['Diff_Profiles']}[/]" if row['Diff_Profiles'] < 0 else "0")
                p_prof = f"[green]+{row['Pct_Profiles']:.1f}%[/]" if row['Pct_Profiles'] > 0 else (f"[red]{row['Pct_Profiles']:.1f}%[/]" if row['Pct_Profiles'] < 0 else "0.0%")

                row_vals = [str(row['id_stn'])]
                row_vals += [f"{int(row[f'Nobs (Ref: {name1})'])  :,}",
                             f"{int(row[f'Nobs ({name2})'])         :,}",
                             d_nobs, p_nobs]
                row_vals += [str(row['MeanNobs_REF']),
                             str(row['MeanNobs_EXP'])]
                row_vals += [f"{int(row[f'Profiles (Ref: {name1})'])  :,}",
                             f"{int(row[f'Profiles ({name2})'])         :,}",
                             d_prof, p_prof]
                if 'MeanProf_REF' in row.index:
                    row_vals += [str(row['MeanProf_REF']),
                                 str(row['MeanProf_EXP'])]
                table_fam.add_row(*row_vals)
            console.print(table_fam)
            
            stn_png_path = os.path.join(pathwork, f"Stations_{fam}_{region}_{flag_criteria}.png")
            save_df_as_png(format_df_for_png(df_fam), stn_png_path,
                           f"Station Breakdown - Family: {fam} ({region}) - {flag_criteria} | Mean per 6h ({n_timesteps} steps)")
            console.print(f"[green]✔ Stations PNG saved to: {stn_png_path}[/green]\n")
            
            html_content += f"<h3>Family: {fam}</h3>"
            format_dict = {'Pct_Nobs': '{:+.1f}%', 'Pct_Profiles': '{:+.1f}%'}
            styled_fam = df_fam.style.applymap(color_html_diff, subset=['Diff_Nobs', 'Pct_Nobs', 'Diff_Profiles', 'Pct_Profiles']).format(format_dict).hide(axis='index')
            html_content += styled_fam.to_html()

            if list_df_stn_ts:
                html_content += f"<h4 style='margin-top: 30px; color: #4C72B0;'>Time Series: Nobs per Station ({fam})</h4>"
                html_content += "<div style='display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; margin-bottom: 50px;'>"

                df_fam_ts = pivot_ts[pivot_ts['family'] == fam]
                stns_in_fam = df_fam['id_stn'].unique()

                for stn in stns_in_fam:
                    df_plot = df_fam_ts[df_fam_ts['id_stn'] == stn].sort_values('date')
                    if df_plot.empty:
                        continue

                    fig, ax = plt.subplots(figsize=(7, 4))
                    
                    if name1 in df_plot.columns:
                        ax.plot(df_plot['date'], df_plot[name1], marker='o', markersize=4,
                                linestyle='-', linewidth=1.5, label=f'Ref: {name1}', color='#4C72B0')
                    if name2 in df_plot.columns:
                        ax.plot(df_plot['date'], df_plot[name2], marker='x', markersize=4,
                                linestyle='--', linewidth=1.5, label=f'Exp: {name2}', color='#DD8452')

                    ax.set_title(f'Station: {stn}', fontsize=11, fontweight='bold')
                    ax.set_xlabel('Date', fontsize=9)
                    ax.set_ylabel('Nobs', fontsize=9)
                    ax.grid(True, linestyle=':', alpha=0.6)
                    ax.legend(fontsize=8)

                    locator = mdates.AutoDateLocator(minticks=5, maxticks=10)
                    formatter = mdates.ConciseDateFormatter(locator)
                    ax.xaxis.set_major_locator(locator)
                    ax.xaxis.set_major_formatter(formatter)
                    
                    fig.tight_layout()

                    buf = io.BytesIO()
                    plt.savefig(buf, format='png', dpi=100)
                    plt.close(fig)
                    buf.seek(0)
                    img_base64 = base64.b64encode(buf.read()).decode('utf-8')

                    html_content += (f"<div style='background: white; padding: 10px; border: 1px solid #ddd; "
                                     f"border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);'>"
                                     f"<img src='data:image/png;base64,{img_base64}' alt='Plot {stn}'></div>")

                html_content += "</div>"

    html_content += """
    </body>
    </html>
    """
    
    html_filepath = os.path.join(pathwork, f"Full_Report_{region}_{flag_criteria}.html")
    with open(html_filepath, "w", encoding="utf-8") as f:
        f.write(html_content)
    
    console.print(f"[bold cyan]Process finished! Web report saved to: {html_filepath}[/bold cyan]")
