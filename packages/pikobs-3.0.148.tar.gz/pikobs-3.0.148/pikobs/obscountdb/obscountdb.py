#!/usr/bin/env python3

"""
=====================
ObsCountDB Diagnostic
=====================

The **Pikobs ObsCountDB** is a diagnostic tool designed to extract, compare, and visualize the volume of assimilated observations between two different experimental runs (e.g., a Control and an Experience). It generates comprehensive comparative tables and multi-station time series to evaluate data usage across different observation families.

Core Visualization: Comparative Reports & Time Series
-----------------------------------------------------

The engine generates both static tabular PNG summaries and dynamic time-series line plots. This layout allows researchers to cross-reference total observation counts (Nobs) and profiles (Nobsprofile) at an overall level, by family, and down to specific individual stations.

**Report Breakdown and Scientific Objectives:**

* **1. Overall Summary**
  Tracks the total aggregated Nobs and Nobsprofiles across all processed families, calculating absolute differences and percentage shifts between the Control and Experience runs. 

* **2. Station Breakdown by Family**
  Provides a granular view of the data assimilation volume for individual stations (``id_stn``) within each family, highlighting stations that gained or lost observations.

* **3. Time Series Fluctuations**
  Displays individual line charts for each station, mapping the ``Nobsprofile`` fluctuations over the specified temporal windows (e.g., every 06h cycle) to detect sudden drops or spikes in data availability at specific timestamps.

Interactive Web Environment
---------------------------

Beyond static PNGs, Pikobs automatically generates a **Comprehensive Web Report**. This self-contained HTML file is designed for rapid comparative analysis:

* **Color-Coded Deltas:** The interface automatically highlights positive data gains in bold green and data losses in bold red for immediate visual triage.
* **Embedded Graphics:** Time series charts are rendered directly into the HTML without requiring separate image files, scaling automatically for clean grid layouts.
* **Access:** The generated web report is saved directly in your output directory and linked here:

🔗 **Explore the Report:** `ObsCountDB Full Report (Monde) <https://goc-dx-u3.science.gc.ca/~dlo001/sites8/pikobsobscountdb/Full_Report_Monde.html>`_

HPC Execution & Real-Time Monitoring
------------------------------------

To maintain system stability on Environment and Climate Change Canada (ECCC) clusters, always execute diagnostic tasks using a dedicated compute node.

**1. Initialize Interactive Session:**

.. code-block:: bash

    qsub -I -X -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb -l place=scatter -l walltime=6:0:0

**2. Generate Diagnostics Command:**

.. code-block:: bash

    python -c 'import pikobs; pikobs.obscountdb.arg_call()' \\
        --path_control_files      /home/dlo001/sites8/Data_pikobs/monitoring0/ \\
        --control_name            Control \\
        --path_experience_files   /home/dlo001/sites8/Data_pikobs/monitoring/ \\
        --experience_name         experience \\
        --pathwork                /your/custom/output/path  \\
        --datestart               2026020100 \\
        --dateend                 2026020500 \\
        --region                  Monde \\
        --family                  ai sc atms_allsky sf ch ssmis cris sw csr gp to_amsua_allsky iasi mwhs2 to_amsub_allsky ro ua \\
        --flags_criteria          assimilee \\
        --n_cpu                   80

**3. Expected Shell Output (Batch Monitoring):**

When executing the command above, you will see the parallel processing progress and rich terminal tables summarizing the data volume comparison:

.. code-block:: text

                  OVERALL SUMMARY - Monde | Period: 2026020100 2026020500 every 06h  :                    
                                          Control (Ref) vs experience                                       
    ╭───────────┬───────────┬───────────┬───────────┬──────────┬───────────┬───────────┬───────────┬───────────╮
    │           │   Nobs    │           │           │          │ Profiles  │           │           │           │
    │           │   (Ref:   │   Nobs    │           │          │   (Ref:   │ Profiles  │           │           │
    │  family   │ Control)  │ (experi…  │ Diff_Nobs │ Pct_Nobs │ Control)  │ (experi…  │ Diff_Pro… │ Pct_Prof… │
    ├───────────┼───────────┼───────────┼───────────┼──────────┼───────────┼───────────┼───────────┼───────────┤
    │    ai     │  6545536  │  8119394  │ +1573858  │  +24.0%  │  1126541  │  1396694  │  +270153  │  +24.0%   │
    │ atms_all… │  5629463  │  8874109  │ +3244646  │  +57.6%  │  490937   │  775162   │  +284225  │  +57.9%   │
    │    ch     │  596951   │  984153   │  +387202  │  +64.9%  │  404630   │  630871   │  +226241  │  +55.9%   │
    │   cris    │  7902743  │ 12641008  │ +4738265  │  +60.0%  │  250107   │  400729   │  +150622  │  +60.2%   │
    │    csr    │  680044   │  881442   │  +201398  │  +29.6%  │  254463   │  335679   │  +81216   │  +31.9%   │
    │    gp     │   31020   │   46615   │  +15595   │  +50.3%  │   31020   │   46615   │  +15595   │  +50.3%   │
    │   iasi    │  9821231  │ 15759525  │ +5938294  │  +60.5%  │  209815   │  344267   │  +134452  │  +64.1%   │
    │   mwhs2   │  127940   │  160770   │  +32830   │  +25.7%  │   36938   │   46050   │   +9112   │  +24.7%   │
    │    ro     │  1995907  │  3239986  │ +1244079  │  +62.3%  │   48639   │   79108   │  +30469   │  +62.6%   │
    │    sc     │  1250665  │  2933715  │ +1683050  │ +134.6%  │  250133   │  586743   │  +336610  │ +134.6%   │
    │    sf     │  798896   │  806344   │   +7448   │  +0.9%   │  226312   │  227827   │   +1515   │   +0.7%   │
    │   ssmis   │   23050   │   30213   │   +7163   │  +31.1%  │   3711    │   4856    │   +1145   │  +30.9%   │
    │    sw     │  3128410  │  4130595  │ +1002185  │  +32.0%  │  625682   │  826119   │  +200437  │  +32.0%   │
    │ to_amsua… │  2583873  │  3484075  │  +900202  │  +34.8%  │  343453   │  465129   │  +121676  │  +35.4%   │
    │ to_amsub… │  751060   │  1004888  │  +253828  │  +33.8%  │  227537   │  309464   │  +81927   │  +36.0%   │
    │    ua     │  1761132  │  2034324  │  +273192  │  +15.5%  │   5449    │   5970    │   +521    │   +9.6%   │
    ╰───────────┴───────────┴───────────┴───────────┴──────────┴───────────┴───────────┴───────────┴───────────╯
    ✔ Overall PNG saved to: /home/dlo001/sites8/pikobsobscountdb/Overall_Summary_Monde.png
    🚀 Process finished! Web report saved to: /home/dlo001/sites8/pikobsobscountdb/Full_Report_Monde.html
    [TIMER] Total time for Plotting: 4.30 seconds
    [SUCCESS] Check outputs in: /home/dlo001/sites8/pikobsobscountdb


Support and Issues
------------------

Pikobs is maintained for the community. For bug reports, feature requests, or database extraction issues, please use the official GitLab repository:

🔗 **GitLab Issues:** `https://gitlab.science.gc.ca/dlo001/Pikobs <https://gitlab.science.gc.ca/dlo001/Pikobs>`_

"""

import os
import re
import sys
import time
import sqlite3
import warnings
from datetime import datetime, timedelta
from typing import List, Dict, Any, Tuple, Optional

# Suppress all Shapely deprecation warnings before importing cartopy/shapely
warnings.filterwarnings("ignore", ".*ShapelyDeprecationWarning.*")
import shapely
import cartopy

import numpy as np
import dask
from dask.distributed import Client

import pikobs

DICT_CODTYP = {
    '12':'SYNOP', '13':'SHIP', '14':'SYNOP MOBIL', '15':'METAR', '16':'SPECI',
    '18':'DRIFTER', '32':'PILOT', '33':'PILOT SHIP', '34':'PILOT MOBIL',
    '35':'TEMP', '36':'TEMP SHIP', '37':'TEMP DROP', '38':'TEMP MOBIL',
    '42':'AMDAR', '128':'AIREP', '134':'PAOBS', '135':'TEMP + PILOT',
    '136':'TEMP + SYNOP', '139':'TEMP SHIP + PILOT SHIP', '143':'SWOB-NONAUTO',
    '144':'SWOB-AUTO', '145':'Patrol ship', '146':'ASYNOP', '147':'BUOYS',
    '148':'SWOBNONAUTO-SPECIAL', '149':'SWOBAUTO-SPECIAL', '157':'BUFR',
    '159':'TEMP PILOT MOBIL', '163':'RADAR', '164':'AMSUA', '168':'SSMIS',
    '169':'GPSRO', '177':'ADS', '181':'AMSUB', '182':'MHS', '183':'AIRS',
    '185':'CSR', '186':'IASI', '188':'AMVS', '189':'GROUND BASED GPS',
    '192':'ATMS', '193':'CRIS NSR', '195':'constituants chimiques (remote)',
    '196':'constituants chimiques (in-situ)', '198':'NetWork of Network',
    '200':'MWHS-2', '202':'CRIS FSR', '254':'SCAT'
}

FAMILY_CODES = {
    'ai': ['42', '128', '157', '177'],
    'sf': ['12', '13', '14', '15', '16', '18', '143', '144', '145', '146', '147', '148', '149', '198'],
    'gp': ['189'],
    'csr': ['185'],
    'ua': ['32', '33', '34', '35', '36', '37', '38', '135', '139']
}


def create_table_if_not_exists(cursor: sqlite3.Cursor) -> None:
    query = """
        CREATE TABLE IF NOT EXISTS moyenne (
            Nobsdata NUMERIC,
            Nobsprofile NUMERIC,
            id_stn TEXT,
            date integer
        );
    """
    cursor.execute(query)

def combine(pathfileout: str, filememory: str) -> None:
    insert_sql = """
        INSERT INTO moyenne (Nobsdata, Nobsprofile, id_stn, date)
        SELECT Nobsdata, Nobsprofile, id_stn, date
        FROM this_avg_db.moyenne;
    """
    with sqlite3.connect(pathfileout, uri=True, isolation_level=None, timeout=9999) as conn:
        try:
            conn.execute("PRAGMA journal_mode=OFF;")
            conn.execute("PRAGMA synchronous=OFF;")
            create_table_if_not_exists(conn)
            
            conn.execute(f"ATTACH DATABASE '{filememory}' AS this_avg_db;")
            conn.execute(insert_sql)
            conn.commit()
            conn.execute("DETACH DATABASE this_avg_db;")
        except sqlite3.Error as e:
            print(f"[ERROR] Combining SQLite files failed: {e}", flush=True)
            raise

def remove_combine(pathfileout: str, filememory: str) -> None:
    with sqlite3.connect(pathfileout, uri=True, isolation_level=None, timeout=9999) as conn:
        conn.execute("PRAGMA journal_mode=OFF;")
        conn.execute("PRAGMA synchronous=OFF;")
        create_table_if_not_exists(conn)
        
        conn.execute(f"ATTACH DATABASE '{filememory}' AS this_avg_db;")
        order_sql = """
            INSERT INTO moyenne (Nobsdata, Nobsprofile, id_stn, date)
            SELECT Nobsdata, Nobsprofile, id_stn, date
            FROM this_avg_db.moyenne;
        """
        conn.execute(order_sql)
        conn.commit()
        conn.execute("DETACH DATABASE this_avg_db;")

def create_and_populate_moyenne_table(
    family: str, new_db_filename: str, existing_db_filename: str, selected_region: str, selected_flags: str
) -> None:
    date_match = re.search(r'(\d{10})', existing_db_filename)
    if not date_match:
        raise ValueError(f"No 10-digit sequence found in: {existing_db_filename}")
    
    in_memory_db = "file::memory:?cache=shared"

    with sqlite3.connect(in_memory_db, uri=True, isolation_level=None, timeout=9999999) as mem_conn:
        cursor = mem_conn.cursor()

        FAM, VCOORD, VCOCRIT, STATB, element, VCOTYP = pikobs.family(family)
        LAT1, LAT2, LON1, LON2 = pikobs.regions(selected_region)
        LATLONCRIT = pikobs.generate_latlon_criteria(LAT1, LAT2, LON1, LON2)
        flag_criteria = pikobs.flag_criteria(selected_flags)

        cursor.execute("PRAGMA journal_mode = MEMORY;")
        cursor.execute("PRAGMA synchronous = OFF;")
        cursor.execute("PRAGMA foreign_keys = OFF;")
        
        cursor.execute(f"ATTACH DATABASE '{existing_db_filename}' AS db;")
        create_table_if_not_exists(cursor)

        # -------------------------------------------------------------------
        # LÓGICA DE MAPEO DINÁMICO (Para ai, sf, gp, csr, ua)
        # -------------------------------------------------------------------
        if family in FAMILY_CODES:
            # 1. Crear el CASE WHEN para mapear nombres
            case_lines = ["CASE CAST(codtyp AS TEXT)"]
            for code, name in DICT_CODTYP.items():
                if code != 'ALL':
                    case_lines.append(f"WHEN '{code}' THEN '{name}'")
            case_lines.append("ELSE CAST(codtyp AS TEXT) END")
            
            id_stn_expr = " ".join(case_lines)
            
            codes_str = ", ".join([f"'{c}'" for c in FAMILY_CODES[family]])
            family_filter = f"AND CAST(codtyp AS TEXT) IN ({codes_str})"
            group_col = "codtyp"
        else:
            # Si es otra familia (radiances, satélites, etc.), usar id_stn normal
            id_stn_expr = "id_stn"
            family_filter = ""
            group_col = "id_stn"
        
        insert_query = f"""
            INSERT INTO moyenne (Nobsdata, Nobsprofile, id_stn, date)
            SELECT
                count(DISTINCT(id_data)),
                count(DISTINCT(id_obs)),
                {id_stn_expr},
                {date_match.group(1)} 
            FROM db.header
            NATURAL JOIN db.DATA
            WHERE obsvalue IS NOT NULL
                {flag_criteria}
                {LATLONCRIT}
                {VCOCRIT}
                {family_filter}
            GROUP BY {group_col};  
        """     

        cursor.execute(insert_query)
        mem_conn.commit()

        try:
            combine(new_db_filename, in_memory_db)
        except sqlite3.Error as error:
            print(f"[ERROR] Creating single sqlite file: {os.path.basename(in_memory_db)} -- {error}", flush=True)

def create_data_list(
    date_start: str, date_end: str, families: List[str], input_paths: List[str],
    names: List[str], work_path: str, flag_criteria: str, regions: List[str],
    intervals: List[Tuple[Optional[int], Optional[int]]] = [(None, None)]
) -> List[Dict[str, Any]]:
    data_list = []
    dt_start = datetime.strptime(date_start, '%Y%m%d%H')
    dt_end = datetime.strptime(date_end, '%Y%m%d%H')
    delta = timedelta(hours=6)
    
    current_date = dt_start

    while current_date <= dt_end:
        formatted_date = current_date.strftime('%Y%m%d%H')
        for family in families:
            for name, input_path in zip(names, input_paths):
                # 1. Armamos la ruta del archivo que queremos procesar
                filename = f'{formatted_date}_{family}'
                filein = os.path.join(input_path, filename)

                # 2. Comprobamos si existe ANTES de añadirlo a la lista
                if not os.path.exists(filein):
                    print(f"[WARNING] Missing file for family '{family}': {filein}", flush=True)
                    continue  # Si no existe, ignoramos este archivo y pasamos al siguiente

                # 3. Si existe, iteramos sobre las regiones y lo añadimos a la lista de tareas
                for region in regions:
                    for interval in intervals:
                        db_new = os.path.join(work_path, family, f'{name}_{region}_{date_start}_{date_end}_{flag_criteria}_{family}.db')

                        data_list.append({
                            'family': family, 'filein': filein, 'db_new': db_new,
                            'region': region, 'flag_criteria': flag_criteria,
                        })
        current_date += delta
    return data_list


def make_scatter(
    files_in: List[str], names_in: List[str], pathwork: str, datestart: str,
    dateend: str, regions: List[str], families: List[str], flag_criteria: str, n_cpu: int
) -> None:
    
    for family in families:
        pikobs.delete_create_folder(pathwork, family)
          
    data_list = create_data_list(datestart, dateend, families, files_in, names_in, pathwork, flag_criteria, regions)
                                       
    t0 = time.time()
    
    if n_cpu == 1:
        print(f'[INFO] Serial mode: {len(data_list)} files used in calculating statistics for {names_in}', flush=True)
        for data_ in data_list:  
            create_and_populate_moyenne_table(
                data_['family'], data_['db_new'], data_['filein'], data_['region'], data_['flag_criteria']
            )
    else:
        print(f'[INFO] Parallel mode: {len(data_list)} files used for {names_in} with {n_cpu} workers.', flush=True)
        with Client(processes=True, threads_per_worker=1, n_workers=n_cpu, silence_logs=40):
            delayed_funcs = [
                dask.delayed(create_and_populate_moyenne_table)(
                    data_['family'], data_['db_new'], data_['filein'], data_['region'], data_['flag_criteria']
                ) for data_ in data_list
            ]
            dask.compute(*delayed_funcs)

    tn = time.time()
    print(f'[TIMER] Total time for DB Extraction: {tn - t0:.2f} seconds', flush=True)  

    # ---------------- PLOTTING SECTION ----------------
    t0 = time.time()
    if n_cpu == 1:  
        print(f'[INFO] Serial mode: Generating plots for {len(regions)} regions.', flush=True)
        for region in regions:
            pikobs.obscountdb_plot(region, families, datestart, dateend, pathwork, names_in, flag_criteria)
    else:
        print(f"[INFO] Parallel mode: Generating plots for {len(regions)} regions.", flush=True)
        with Client(processes=True, threads_per_worker=1, n_workers=n_cpu, silence_logs=40):
            delayed_funcs = [
                dask.delayed(pikobs.obscountdb_plot)(
                    region, families, datestart, dateend, pathwork, names_in, flag_criteria
                ) for region in regions
            ]
            dask.compute(*delayed_funcs)
            
    print(f'[TIMER] Total time for Plotting: {time.time() - t0:.2f} seconds', flush=True)  
    print(f'[SUCCESS] Check outputs in: {pathwork}', flush=True)
    
def arg_call() -> None:
    import argparse
    
    parser = argparse.ArgumentParser(description="Pikobs ObsCountDB Scatter Generator")
    parser.add_argument('--path_control_files', default='undefined', type=str)
    parser.add_argument('--control_name', default='undefined', type=str)
    parser.add_argument('--path_experience_files', default='undefined', type=str)
    parser.add_argument('--experience_name', default='undefined', type=str)
    
    parser.add_argument('--pathwork', default='undefined', type=str)
    parser.add_argument('--datestart', default='undefined', type=str)
    parser.add_argument('--dateend', default='undefined', type=str)
    parser.add_argument('--region', nargs="+", default='undefined', type=str)
    parser.add_argument('--family', nargs="+", default='undefined', type=str)
    parser.add_argument('--flags_criteria', default='undefined', type=str)
    parser.add_argument('--n_cpus', '--n_cpu', default=1, type=int, dest='n_cpus')
    
    args = parser.parse_args()
    
    for arg in vars(args):
        print(f'--{arg} {getattr(args, arg)}', flush=True)

    if args.path_control_files == 'undefined':
        files_in = [args.path_experience_files]
        names_in = [args.experience_name]
    else:    
        if args.path_experience_files == 'undefined': raise ValueError('Missing --path_experience_files')
        if args.experience_name == 'undefined': raise ValueError('Missing --experience_name')
        
        files_in = [args.path_control_files, args.path_experience_files]
        names_in = [args.control_name, args.experience_name] 

    if args.pathwork == 'undefined': raise ValueError('Missing --pathwork')
    if args.datestart == 'undefined': raise ValueError('Missing --datestart')
    if args.dateend == 'undefined': raise ValueError('Missing --dateend')
    if args.region == 'undefined': raise ValueError('Missing --region')
    if args.family == 'undefined': raise ValueError('Missing --family')
    if args.flags_criteria == 'undefined': raise ValueError('Missing --flags_criteria')

    make_scatter(
        files_in=files_in, names_in=names_in, pathwork=args.pathwork,
        datestart=args.datestart, dateend=args.dateend, regions=args.region,
        families=args.family, flag_criteria=args.flags_criteria, n_cpu=args.n_cpus
    )

if __name__ == "__main__":
    arg_call()
