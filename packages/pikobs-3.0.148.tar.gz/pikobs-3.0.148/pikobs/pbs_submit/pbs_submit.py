"""
pikobs.pbs_submit
=================
Auto-submit helper for pikobs CLI commands.
"""
import os
import sys
import shutil
import subprocess
import tempfile
import time
from pathlib import Path


# ==============================================================================
# VERSION CHECK
# ==============================================================================
def _resolve_project_dir() -> str:
    project_dir = os.environ.get('PIKOBS_PROJECT_DIR', '')
    if not project_dir:
        try:
            import pikobs as _pk
            for _p in [Path(_pk.__file__).parent, *Path(_pk.__file__).parents]:
                if (_p / 'load_pikobs.sh').exists():
                    project_dir = str(_p)
                    break
        except Exception:
            pass
    if not project_dir:
        project_dir = os.environ.get('CONDA_PREFIX',
                      os.environ.get('VIRTUAL_ENV', ''))
    return project_dir


def _pikobs_install_location() -> str:
    try:
        import pikobs
        return str(Path(pikobs.__file__).parent)
    except Exception:
        return ''


def _read_installed_version_fresh() -> str:
    """Read pikobs version in a CLEAN subprocess to bypass the
    metadata cache of the current Python process.

    Key points:
      - DO NOT pass `-S` (it disables site-packages, so metadata is gone).
      - DO remove PYTHONPATH so an old source checkout doesn't shadow
        the freshly-installed wheel.
      - Print stderr too on failure so we can see what broke.
    """
    env = {k: v for k, v in os.environ.items() if k != 'PYTHONPATH'}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    # Multi-line script via real newlines — passing `;`-joined try/except
    # is a SyntaxError because `try:` needs its block on subsequent lines.
    code = (
        "import importlib.metadata as m\n"
        "import sys\n"
        "try:\n"
        "    print(m.version('pikobs'))\n"
        "except Exception as e:\n"
        "    sys.stderr.write('VERR:' + type(e).__name__ + ':' + str(e))\n"
        "    sys.exit(2)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, '-c', code],
            capture_output=True, text=True, env=env,
        )
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
        err = (r.stderr or '').strip()
        if err:
            print(f'  [verify] subprocess stderr: {err[:200]}')
        return ''
    except Exception as e:
        print(f'  [verify] subprocess crashed: {e}')
        return ''


def _pip_can_install(pip_cmd: list, spec: str) -> bool:
    """Dry-run check: can pip resolve this version on the configured
    index right now?  Returns True if `pip index versions` lists it,
    or if `pip install --dry-run` succeeds.

    PyPI's JSON API publishes new versions a few seconds before the
    simple index, and corporate mirrors lag even more — so we must
    confirm before offering the upgrade."""
    # Try `pip index versions pikobs` (pip ≥21.2)
    try:
        r = subprocess.run(
            pip_cmd + ['index', 'versions', 'pikobs'],
            capture_output=True, text=True, timeout=15,
        )
        if r.returncode == 0:
            # Output: "Available versions: 3.0.127, 3.0.126, ..."
            target = spec.split('==', 1)[1] if '==' in spec else ''
            if target and target in r.stdout:
                return True
            if target and target not in r.stdout:
                return False
    except Exception:
        pass
    # Fallback: dry-run install (slower but works on older pip)
    try:
        r = subprocess.run(
            pip_cmd + ['install', '--dry-run', '--no-deps', spec],
            capture_output=True, text=True, timeout=30,
        )
        return r.returncode == 0
    except Exception:
        return False


def _check_version(project_dir: str) -> None:
    """Print version banner.  If a newer PyPI version exists, is reachable
    by the local pip index, and stdin is a TTY, prompt to upgrade."""
    try:
        import pikobs                                # noqa
        try:
            from importlib.metadata import version as _v
            local = _v('pikobs')
        except Exception:
            local = getattr(__import__('pikobs'), '__version__', 'installed')
    except ImportError:
        print("ERROR: cannot import pikobs.", file=sys.stderr)
        sys.exit(1)

    latest = ''
    try:
        import urllib.request, json
        with urllib.request.urlopen(
                'https://pypi.org/pypi/pikobs/json', timeout=10) as r:
            latest = json.loads(r.read())['info']['version']
    except Exception:
        pass

    suffix = f'  (latest on PyPI: {latest})' if latest and latest != local else ''
    print(f'Pikobs : {local}{suffix}')

    if not (latest and latest != local):
        return

    try:
        from packaging.version import Version
        if Version(local) >= Version(latest):
            print(f'  ℹ️  Dev build ({local} > PyPI {latest})')
            return
    except Exception:
        return

    # Build pip command early — we need it to verify availability
    _prefix = (os.environ.get('CONDA_PREFIX')
               or os.environ.get('VIRTUAL_ENV')
               or project_dir)
    pip_path = None
    if _prefix:
        cand = Path(_prefix) / 'bin' / 'pip'
        if cand.exists():
            pip_path = str(cand)
    pip_cmd = [pip_path] if pip_path else [sys.executable, '-m', 'pip']

    # GUARD: PyPI's JSON may have published the new version a few seconds
    # before it appears on the simple index (used by pip).  Corporate
    # mirrors can lag minutes.  If pip can't see it yet, don't offer
    # the upgrade — just tell the user.
    spec = f'pikobs=={latest}'
    if not _pip_can_install(pip_cmd, spec):
        print(f'  ⏳ {latest} is on PyPI metadata but not yet on your pip '
              f'index. Try again in a minute, or run:')
        print(f'       {" ".join(pip_cmd)} install --upgrade --no-deps {spec}')
        return

    if not sys.stdin.isatty():
        print(f'  ⚠️  PyPI has {latest} — run: pip install --upgrade pikobs')
        return

    ans = input(
        f'\n  ⚠️  A newer version is available: {latest}\n'
        f'  Installed: {local}\n'
        f'  Update now? [y/N] '
    ).strip().lower()
    if ans != 'y':
        return

    cur_loc = _pikobs_install_location()
    print(f'  → currently imported pikobs lives at: {cur_loc}')

    cmd = pip_cmd + [
        'install',
        '--upgrade', '--upgrade-strategy', 'only-if-needed',
        '--no-deps',
        spec,
    ]
    print(f"  ⏳ {' '.join(cmd)}")
    t0 = time.time()
    rc = subprocess.run(cmd).returncode
    print(f'  ⏱  pip finished in {time.time()-t0:.1f}s (rc={rc})')

    if rc != 0:
        print(f'  ❌ Upgrade failed. Continuing with {local}.')
        return

    installed = _read_installed_version_fresh()
    if installed != latest:
        print(f'  ❌ Upgrade reported success but on-disk version is '
              f'{installed or "unknown"} (expected {latest}).')
        print(f'     Manual fix:')
        print(f'       {" ".join(pip_cmd)} install --upgrade --no-deps '
              f'pikobs=={latest}')
        print(f'     Continuing with {local}.\n')
        return

    print(f'  ✅ Updated to {installed} — restarting with new version...\n')

    python_exe = sys.executable
    if not Path(python_exe).is_file():
        cand = Path(_prefix) / 'bin' / 'python' if _prefix else None
        if cand and cand.is_file():
            python_exe = str(cand)
        else:
            print(f'  ⚠️  Cannot re-exec (no Python binary). '
                  f'Please re-run your command manually.')
            sys.exit(0)

    # FIX: Recuperar el comando exacto (incluyendo el código de -c) para el reinicio
    try:
        with open('/proc/self/cmdline', 'r') as f:
            full_cmd = f.read().split('\0')[:-1]
        real_args = full_cmd[1:] # Ignora el ejecutable 'python'
    except Exception:
        real_args = sys.argv

    new_argv = [python_exe] + real_args
    
    # Importar shlex solo para imprimir el comando de forma legible en el log
    import shlex
    print(f'  → exec: {" ".join(shlex.quote(a) for a in new_argv)}')
    sys.stdout.flush()
    
    # Reiniciar el proceso con los argumentos reales
    os.execv(python_exe, new_argv)

# ==============================================================================
# PBS AUTO-SUBMIT
# ==============================================================================
def maybe_submit_to_pbs(args) -> None:
    """If running on a login node (no PBS_JOBID) and --no_submit is not
    given, generate a PBS script, submit it via qsub, tail the log, exit.
    Otherwise return immediately."""

    in_compute_node = bool(os.environ.get('PBS_JOBID')
                           or os.environ.get('PBS_ENVIRONMENT'))
    is_no_submit    = getattr(args, 'no_submit', False)

    print(f"[pbs] PBS_JOBID={os.environ.get('PBS_JOBID', '')} "
          f"PBS_ENVIRONMENT={os.environ.get('PBS_ENVIRONMENT', '')} "
          f"--no_submit={is_no_submit} "
          f"→ {'LOCAL/COMPUTE' if (in_compute_node or is_no_submit) else 'SUBMIT'}")

    # ==========================================================================
    # 1. LOCAL / COMPUTE NODE MODE
    # ==========================================================================
    if in_compute_node or is_no_submit:
        if is_no_submit and not in_compute_node:
            print("\n⚠️  WARNING: You are using '--no_submit' on a Login Node.")
            print("   Recommended: qsub -I -lselect=1:ncpus=80:mem=185gb,"
                  "place=scatter:excl -lwalltime=6:0:0")
            ans = input(
                "Have you opened an interactive session (e.g., qsub -I) "
                "before running this? [y/N]: "
            ).strip().lower()
            if ans != 'y':
                print("❌ Cancelled. Please open a compute node first "
                      "or run without '--no_submit'.\n")
                sys.exit(1)
            print("Continuing on the login node at your own risk...\n")

        _check_version(_resolve_project_dir())
        return

    # ==========================================================================
    # 2. SUBMIT MODE (PBS queue)
    # ==========================================================================
    pathwork = Path(getattr(args, 'pathwork', '.')).expanduser()
    pathwork.mkdir(parents=True, exist_ok=True)

    project_dir = _resolve_project_dir()
    _check_version(project_dir)

    qsub_path = shutil.which('qsub')
    if not qsub_path:
        print('[pbs] ⚠️  qsub not found on PATH — running locally instead.')
        return
    print(f'[pbs] qsub: {qsub_path}')

    n_cpus   = getattr(args, 'n_cpus',   4)
    walltime = getattr(args, 'walltime', '02:00:00')

    pikobs_src = os.environ.get('PIKOBS_SRC', '')
    if not pikobs_src:
        try:
            import pikobs as _pk
            pikobs_src = str(Path(_pk.__file__).parent.parent)
        except Exception:
            pikobs_src = ''

    loader = Path(project_dir) / 'load_pikobs.sh' if project_dir else None

    python_exe = sys.executable
    try:
        import pikobs as _pk
        _env_python = Path(_pk.__file__).parent.parent.parent / 'bin' / 'python'
        if _env_python.exists():
            python_exe = str(_env_python)
    except Exception:
        pass

    log_file = pathwork / f'pikobs_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_file.touch()

    import shlex
    try:
        with open('/proc/self/cmdline', 'r') as f:
            full_cmd = f.read().split('\0')[:-1]
        args_list = full_cmd[1:]
    except Exception:
        args_list = sys.argv

    import shlex

    # Reconstruct the original command (FIXED for python -c)
    try:
        # Lee el comando exacto desde Linux (recuperando el código de -c)
        with open('/proc/self/cmdline', 'r') as f:
            full_cmd = f.read().split('\0')[:-1]
        args_list = full_cmd[1:] # Ignora el ejecutable 'python' de la posición 0
    except Exception:
        args_list = sys.argv

    # shlex.quote pone automáticamente las comillas perfectas donde hagan falta
    cmd_args = ' '.join(shlex.quote(a) for a in args_list)
    pbs_script = f"""\
#!/usr/bin/env bash
set -eo pipefail
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export HDF5_USE_FILE_LOCKING=FALSE
export DASK_LOGGING__DISTRIBUTED=critical
export PYTHONWARNINGS="ignore::DeprecationWarning,ignore::ResourceWarning"
echo "Running on: $(hostname)  JobID: $PBS_JOBID"
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"
[ -f "{loader}" ] && source "{loader}"
[ -n "{pikobs_src}" ] && export PYTHONPATH="{pikobs_src}:${{PYTHONPATH:-}}"
{python_exe} -u {cmd_args} --no_submit 2> >(grep -v -E \\
  'tornado|distributed|asyncio|StreamClosedError|CommClosedError|CancelledError|_handle_report|_reconnect|_ensure_connected|read_bytes|convert_stream_closed|^Traceback|^\\s+File |^\\s+await |^\\s+msgs |^\\s+comm |^\\s+frames|^\\s+return |^\\s+raise |^During handling|^The above exception' >&2)
"""

    with tempfile.NamedTemporaryFile(
            dir=pathwork, mode='w', suffix='.sh',
            prefix='pikobs_pbs_', delete=False) as tmp:
        tmp.write(pbs_script)
        tmp_path = tmp.name
    os.chmod(tmp_path, 0o755)

    try:
        result = subprocess.run(
            ['qsub', '-V',
             '-N', 'pikobs',
             '-l', f'select=1:ncpus={n_cpus}:mem=185gb',
             '-l', f'walltime={walltime}',
             '-j', 'oe',
             '-o', str(log_file),
             '--', tmp_path],
            capture_output=True, text=True, check=True
        )
        job_id = result.stdout.strip().split()[0]
    except subprocess.CalledProcessError as e:
        print(f'ERROR qsub failed: {e.stderr}', file=sys.stderr)
        sys.exit(1)

    print(f'\nJob    : {job_id}')
    print(f'Log    : {log_file}')
    print('Tip    : Ctrl+C to detach — job keeps running.')
    print(f'         Re-attach: tail -f {log_file}')
    print('=' * 65)

    waited = 0
    while True:
        try:
            if log_file.exists() and log_file.stat().st_size > 0:
                break
        except FileNotFoundError:
            pass
        time.sleep(3)
        waited += 3
        if waited >= 120:
            try:
                subprocess.run(['qstat', job_id],
                               capture_output=True, check=True)
            except subprocess.CalledProcessError:
                print(f'ERROR job gone, empty log. Check: qstat -xf {job_id}',
                      file=sys.stderr)
                sys.exit(1)
            print('Still waiting for job to start...')
            waited = 0

    tail = subprocess.Popen(['tail', '-n', '+1', '-f', str(log_file)])
    try:
        while True:
            try:
                subprocess.run(['qstat', job_id],
                               capture_output=True, check=True)
                time.sleep(5)
            except subprocess.CalledProcessError:
                break
    except KeyboardInterrupt:
        print('\nDetached — job keeps running.')
    finally:
        time.sleep(3)
        tail.terminate()

    print('=' * 65)
    print(f'Job {job_id} finished.  Log: {log_file}')
    sys.exit(0)
