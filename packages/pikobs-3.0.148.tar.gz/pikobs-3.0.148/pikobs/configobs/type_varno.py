def type_varno(varno):
    """
======================================
Data Families & Variables Reference
======================================

Pikobs processes a wide array of meteorological data. To effectively use the modules (e.g., when specifying ``--family`` or filtering by channel), it is essential to understand the supported observation families and their corresponding variable numbers (``varno``).

This reference details the internal configuration used by Pikobs to categorize data, assign vertical coordinates, and map observation types to physical variables.

Supported Observation Families
------------------------------

The following table outlines the exact family arguments you can pass to the CLI, along with their internal grouping, default vertical coordinate type, and default evaluation elements (Variables/Varnos).

.. list-table:: Observation Families Configuration
   :widths: 20 15 15 30 20
   :header-rows: 1
   :align: left

   * - CLI Argument (``--family``)
     - Internal Group
     - Vertical Coord
     - Default Varnos (Elements)
     - Type
   * - ``ai`` / ``ai_qc``
     - AIRCRAFTS
     - Pressure
     - 11004, 11003, 12001, 12192
     - Conventional
   * - ``gp`` / ``gp_qc``
     - GBGPS
     - Surface
     - 15031
     - Conventional
   * - ``sf``
     - Surface
     - Surface
     - 11215, 11216, 10051, 10004, 12004, 12203, 11011, 11012
     - Conventional
   * - ``synop_b``
     - SHIPS
     - Surface
     - *(Varies)*
     - Conventional
   * - ``ua`` / ``ua_qc``
     - Radiosondes
     - Pressure
     - 11004, 11003, 12001, 12192
     - Conventional
   * - ``atms`` / ``atms_allsky``
     - ATMS
     - Channel
     - 12163
     - Satellite
   * - ``cris`` / ``crisfsr1_qc``
     - CRISFSR
     - Channel
     - 12163
     - Satellite
   * - ``csr`` / ``csr_qc``
     - CSR
     - Channel
     - 12163
     - Satellite
   * - ``iasi`` / ``iasi_qc``
     - IASI
     - Channel
     - 12163
     - Satellite
   * - ``mwhs2`` / ``mwhs2_qc``
     - MWHS2
     - Channel
     - 12163
     - Satellite
   * - ``ro`` / ``ro_qc``
     - GPSRO
     - Height (m)
     - 15036
     - Satellite
   * - ``sc`` / ``sc_qc``
     - SCATS
     - Surface
     - 11215, 11216
     - Satellite
   * - ``ssmis`` / ``ssmis_qc``
     - SSMIS
     - Channel
     - 12163
     - Satellite
   * - ``sw`` / ``sw_polar``
     - AMVS
     - Pressure
     - 11002, 11004, 11003
     - Satellite
   * - ``to_amsua`` / ``allsky``
     - AMSUA
     - Channel
     - 12163
     - Satellite
   * - ``to_amsub`` / ``allsky``
     - AMSUB
     - Channel
     - 12163
     - Satellite
   * - ``ch`` / ``ch_db``
     - OZONE
     - Level
     - 15198, 15008
     - Trace Gas
   * - ``radar``
     - RADAR
     - Height
     - 21014
     - Radar

Variable Numbers (Varnos) Reference
-----------------------------------

The ``varno`` (Variable Number) is the internal code used in the SQLite databases to identify specific meteorological elements. Pikobs automatically maps these codes to readable text and units for the generated plots.

.. tip::
   When viewing statistical outputs or defining custom filters, use this table to understand exactly which physical parameter corresponds to a specific Varno code and what that parameter represents in the assimilation system.

.. list-table:: Meteorological Variables Mapping
   :widths: 10 20 10 15 45
   :header-rows: 1
   :align: left

   * - Varno
     - Variable Name
     - Unit
     - Domain
     - Description / Meaning
   * - ``10004``
     - Pressure
     - [hPa]
     - Surface/Level
     - Atmospheric pressure recorded by stations, sondes, or aircraft at their specific location or flight level.
   * - ``10051``
     - Mean Sea Level Pressure
     - [hPa]
     - Surface
     - Surface station pressure mathematically reduced to mean sea level. Crucial for identifying synoptic weather patterns (highs and lows).
   * - ``11001``
     - Wind Direction
     - Degrees
     - Pressure
     - The direction from which the wind is blowing at upper levels, reported in degrees (0-360).
   * - ``11002``
     - Wind Speed
     - [m/s]
     - Pressure
     - Scalar magnitude of the wind speed at upper atmospheric levels, essential for tracking jet streams.
   * - ``11003``
     - U Component of Wind
     - [m/s]
     - Pressure
     - The zonal (East-West) component of the wind vector. Positive values indicate a westerly wind (blowing from West to East).
   * - ``11004``
     - V Component of Wind
     - [m/s]
     - Pressure
     - The meridional (North-South) component of the wind vector. Positive values indicate a southerly wind (blowing from South to North).
   * - ``11011``
     - Wind Direction (10m)
     - Degrees
     - Surface
     - The direction from which the surface wind is blowing, measured at standard 10 meters height.
   * - ``11012``
     - Wind Speed (10m)
     - [m/s]
     - Surface
     - Scalar magnitude of the surface wind speed, measured at standard 10 meters height.
   * - ``11214``
     - Vector Diff. of Wind
     - [m/s]
     - Level
     - The vector magnitude difference between observed winds and model predicted winds (used heavily in AMV tracking quality).
   * - ``11215``
     - U Component Wind (10m)
     - [m/s]
     - Surface
     - The zonal (East-West) component of the surface wind vector at 10m height (commonly from scatterometers or buoys).
   * - ``11216``
     - V Component Wind (10m)
     - [m/s]
     - Surface
     - The meridional (North-South) component of the surface wind vector at 10m height.
   * - ``12001``
     - Temp / Dry Bulb
     - [K]
     - Pressure
     - True air temperature recorded in the upper atmosphere by radiosondes or aircraft.
   * - ``12004``
     - Temp Dry Bulb (2m)
     - [K]
     - Surface
     - Surface air temperature recorded at the standard meteorological shelter height of 2 meters.
   * - ``12163``
     - Brightness Temperature
     - [K]
     - Channel
     - The effective temperature of microwave or infrared radiation measured by satellite instruments at a specific frequency (channel). The primary variable for radiance assimilation.
   * - ``12192``
     - Dew Point Depression
     - [K]
     - Pressure
     - The difference between the air temperature and the dew point temperature aloft. Indicates atmospheric moisture (smaller values mean higher relative humidity).
   * - ``12203``
     - Dew Point Dep. (2m)
     - [K]
     - Surface
     - The difference between air temperature and dew point at the surface (2m). Crucial for forecasting fog and precipitation type.
   * - ``15008``
     - Volumetric Mixing Ratio
     - Ratio
     - Level
     - The proportion of a specific trace gas (usually Ozone) relative to the total volume of air at a specific pressure level.
   * - ``15031``
     - Zenith Total Delay
     - [m]
     - Surface
     - Ground-Based GPS (GBGPS) delay caused by the atmosphere. Used to estimate integrated atmospheric water vapor.
   * - ``15036``
     - Atm. Refractivity
     - N-units
     - Height (m)
     - Measure of how much GPS radio signals are bent by the atmosphere. Directly related to density, temperature, and moisture profiles (used by GPSRO).
   * - ``15198``
     - Total/Partial Column
     - Dobson
     - Level
     - A measure of the total amount of Ozone in a vertical column of the atmosphere from the surface to space.
   * - ``21014``
     - Doppler Velocity
     - [m/s]
     - Height
     - The radial velocity of precipitation particles moving towards or away from a weather radar. Used to analyze high-resolution mesoscale wind fields.
    """


    GRAPHE_NOMVAR = {
        '11215': ('11215:U COMPONENT OF WIND (10M)', '[m/s]', 'review type_varno.py'),
        '11216': ('11216:V COMPONENT OF WIND (10M)', '[m/s]', 'review type_varno.py'),
        '12004': ('12004:DRY BULB TEMPERATURE AT 2M', '', 'review type_varno.py'),
        '10051': ('10051:PRESSURE REDUCED TO MEAN SEA LEVEL', '', 'review type_varno.py'),
        '10004': ('10004:PRESSURE', '', 'review type_varno.py'),
        '12203': ('12203:DEW POINT DEPRESSION (2M)', '', 'review type_varno.py'),
        '12001': ('12001:TEMPERATURE/DRY BULB', '', 'review type_varno.py'),
        '11003': ('11003:U COMPONENT OF WIND', '[m/s]', 'Pressure [hPa]'),
        '11004': ('11004:V COMPONENT OF WIND', '[m/s]', 'Pressure [hPa]'),
        '12192': ('12192:DEW POINT DEPRESSION', '', 'review type_varno.py'),
        '12163': ('12163:BRIGHTNESS TEMPERATURE', '[K]', 'Channel'),
        '21014': ('21014:Doppler velocity', '[m/s]', 'Height'),
        '15036': ('15036:ATMOSPHERIC REFRACTIVITY', '[-]', 'Height [m]'),
        '11001': ('11001:WIND DIRECTION', '', 'review type_varno.py'),
        '11002': ('11002:WIND SPEED', '[m/s]', 'Pressure [hPa]'),
        '11011': ('11011:WIND DIRECTION AT 10M', '', 'review type_varno.py'),
        '11012': ('11012:WIND SPEED AT 10M', '[m/s]', 'review type_varno.py'),
        '11214': ('11214:VECTOR DIFFERENCE OF WIND', '', 'review type_varno.py'),
        '15198': ('15198:TOTAL OR PARTIAL COLUMN (DOBSON)', '', 'review type_varno.py'),
        '15008': ('15008:VOLUMETRIC MIXING RATIO(PROPORTIONED)', '', 'review type_varno.py')
    }

    # Ensure varno is a string for dictionary lookup
    varno_str = str(varno)

    # Check if the variable number is in the dictionary
    if varno_str in GRAPHE_NOMVAR:
        # If it is, retrieve the variable name and units
        variable_name, units, vcoord_type = GRAPHE_NOMVAR[varno_str]
        # Return the variable name along with its units and vcoord_type
        return variable_name, units, vcoord_type
    else:
        # If the variable number is not found, raise an exception
        raise ValueError(f"Varno '{varno}' not found in the dictionary")

