## Generating Cardiograms for Radiance Assimilation Analysis ##

This script is designed to generate cardiograms that analyze the results of radiance assimilation. Below is a description of the generated graphs, their characteristics, and their importance in the context of data assimilation.

## Cardiograms of Radiance Assimilation ##
The script generates four main types of cardiograms, each providing critical information to assess the performance of radiance assimilation.
![Ejemplo de ](readme/serie_Test_cris_NOAA20_Monde_ch19.png)

# 1. Mean of Differences  #

This cardiogram shows the averages of the differences between observations and predictions (O-P) and, if available, the differences between observations and adjustments (O-A). It also includes bias corrections (Bcor) if present. Importance: Analyzing the averages of O-P and O-A helps identify and quantify any systematic bias in the assimilation process, which is crucial for improving the accuracy of prediction models.

# 2. Standard Deviations of Differences #

This cardiogram shows the standard deviations of the differences between observations and predictions (O-P) and, if available, the standard deviations of the differences between observations and adjustments (O-A). Importance: Standard deviations measure the dispersion of errors. Analyzing these deviations helps understand the variability and uncertainty in the predictions and adjustments made during radiance assimilation.

# 3. Obsvale of  Data  #
This cardiogram shows the obsvalue  in the assimilation process. Importance: Evaluating the obsvalue of accepted data is essential to understand the efficiency of the assimilation system and the quality of the data being used. A high number of accepted data points can indicate an efficient and reliable filtering process.

# 4. Total Number of Processed Data (Data Processing Analysis) #
This cardiogram shows the total number of processed data points (Ntot) during assimilation. Importance: The total number of processed data points provides an overview of the amount of information handled by the system. It is an indicator of the data volume and the system's capacity to process large datasets.

## Usage ##

## Installation ##

Install pikobs using pip:

```
pip install pikobs
```

# Interactive Session #
To start an interactive session for generating cardiograms, use the following qsub command
( [`Info`]( https://portal.science.gc.ca/confluence/display/SCIDOCS/DDT#DDT-PPP5,PPP6,underhillandrobert) ):

```
qsub -I -X -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb -l place=scatter -l walltime=6:0:0
```

# Generating Cardiograms #

To generate cardiograms using pikobs, use the following command format:

```
python -c 'import pikobs; pikobs.cardio.arg_call()' \
    --path_experience /path/to/experience_directory \
    --experience_name EXPERIENCE_NAME \
    --pathwork WORK_DIRECTORY \
    --datestart START_DATE \
    --dateend END_DATE \
    --region REGION \
    --family FAMILY_NAME \
    --flags_criteria FLAGS_CRITERIA \
    --id_stn SATELLITE_IDS \
    --channel CHANNELS \
    --plot_title PLOT_TITLE \
    --n_cpu CPU_COUNT
```

# Parameters Explanation #


*  ***--path_experience:*** Path to the directory where the experience data is stored.

*  ***--experience_name:***  Name of the specific experience .

*  ***--pathwork:*** Directory path indicating the working directory for the script.

*  ***--datestart:*** Start date and time of the assimilation process (format: YYYYMMDDHH).

*  ***--dateend:*** End date and time of the assimilation process (format: YYYYMMDDHH).

*  ***--region*** [`Geographic region`](https://gitlab.science.gc.ca/dlo001/Pikobs/-/blob/master/readme/geographic.md)  or area of interest for the assimilation analysis. (e.g., Monde, PoleNord, PoleSud, AmeriqueduNord, OuestAmeriqueduNord, AmeriqueDuNordPlus, 
                      ExtratropiquesNord, HemisphereNord, HemisphereSud, Asie, Europe, Mexique, Canada,BaieDhudson, Arctiquecanadien, EtatsUnis, Tropiques30, Tropiques, Australie,
Pacifique and Atlantique)


*   ***--family:*** Family of data assimilated (e.g.,  mwhs2, mwhs2_qc, to_amsua_qc, to_amsua, to_amsua_allsky, 
                     to_amsua_allsky_qc, to_amsub_qc, to_amsub, ssmis_qc, ssmis, 
                      iasi iasi_qc, crisfsr1_qc, crisfsr2_qc, cris, atms_allsky, atms_qc and  csr csr_qc)

*  ***--flags_criteria:*** Specific [`flag criteria`]( https://gitlab.science.gc.ca/dlo001/Pikobs/-/blob/master/readme/flag_criteria.md) used during assimilation (e.g., all,  assimilee,  bgckalt,  bgckalt_qc and postalt).

*    ***--id_stn:*** *all* or satellite IDs for which assimilation results are analyzed (e.g., METOP-1, METOP-3). Modify as needed to specify particular satellites.

*    ***--channel:*** *all* or specific channels to analyze. Use 'all' to analyze all available channels. Modify as needed to specify particular channels of interest.

*  ***--plot_title:*** Title for the generated cardiogram.

*  ***--n_cpu:*** Number of CPU cores to be used for parallel processing. Adjust according to your system capabilities.

# Additional Note #


*  Modify ***--channel*** and ***--id_stn*** parameters as needed to specify particular satellites and channels of interest.

*  Ensure paths (path_experience, pathwork) are correctly set to point to your data directories.

*  The script leverages parallel processing (***--n_cpu:***) to optimize performance, adjust according to your system capabilities.

*  The generated cardiograms provide comprehensive visual insights into the assimilation performance metrics across selected satellites, channels, and criteria.

*  Adjust the parameters (***--channel***, ***--id_stn***, etc.) according to your specific requirements and data.
