## Geographic Coordinates by Region ##

This document details the geographic coordinates (latitudes and longitudes) used to define various regions in a program. Each region is identified by a key name and has a specific range of latitudes and longitudes associated with it.

## Regions and their Coordinates ##


*  PoleNord: (60, 90, -180, 180)

*  PoleSud: (-90, -60, -180, 180)

*  AmeriqueduNord: (25, 60, -145, -50)

*  OuestAmeriqueduNord: (25, 60, -145, -97.5)

*  AmeriqueDuNordPlus: (25, 85, -170, -40)

*  Monde: (-90, 90, -180, 180)

*  Global: (-90, 90, -180, 180)

*  ExtratropiquesNord: (20, 90, -180, 180)

*  ExtratropiquesSud: (-90, -20, -180, 180)

*  HemisphereNord: (0, 90, -180, 180)

*  HemisphereSud: (-90, 0, -180, 180)

*  Asie: (25, 60, 65, 145)

*  Europe: (25, 70, -10, 28)

*  Mexique: (15, 30, -130, -60)

*  Canada: (45, 90, -151, -50)

*  BaieDhudson: (55, 90, -90, -60)

*  Arctiquecanadien: (58, 90, -141, -50)

*  EtatsUnis: (25, 45, -130, -70)

*  SudestEtatsUnis: (25, 40, -100, -70)

*  EstAmeriqueduNord: (25, 60, -97.5, -50)

*  EstAmeriqueduNordPlus: (25, 85, -97.5, -50)

*  OuestAmeriqueduNordPlus: (25, 85, -170, -97.5)

*  Tropiques30: (-30, 30, -180, 180)

*  Tropiques: (-20, 20, -180, 180)

*  Australie: (-55, -10, 90, 180)

*  Pacifique: (20, 65, 130, -150)

*  Atlantique: (20, 65, -80, -1)

* Alaska : (50, 75, -180, -140)

*  HIMAPEst: (35, 65, -105, -50)

*  HIMAPOuest: (40, 65, -145, -100)

*  ExtremeSud: (-90, -87, -180, 180)

*  ExtremeNord: (87, 90, -180, 180)

*  TropiquesOuest: (-20, 0, 180, -90)

*  Bande60a90: (60, 90, -180, 180)

*  Bande30a60: (30, 60, -180, 180)

*  Bande00a30: (0, 30, -180, 180)

*  BandeM30a00: (-30, 0, -180, 180)

*  BandeM60aM30: (-60, -30, -180, 180)

*  BandeM90aM60: (-90, -60, -180, 180)

*  Rapidscat: (-55, 55, -180, 180)

*  npstere: (0, 90, -180, 180)

*  spstere: (-90, 0, -180, 180)