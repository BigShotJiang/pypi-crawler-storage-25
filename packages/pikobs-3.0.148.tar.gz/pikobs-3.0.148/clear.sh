#!/bin/bash

# Detener el script si ocurre algún error grave
set -e

echo "========================================="
echo "🧹 Iniciando limpieza masiva de Pikobs..."
echo "========================================="

# 1. Borrar carpetas de empaquetado y compilación
echo "[1/6] Eliminando carpetas build/, dist/ y egg-info..."
rm -rf build/ dist/ pikobs.egg-info/

# 2. Borrar documentación generada por Sphinx
echo "[2/6] Eliminando HTMLs y compilados de docs/build/..."
rm -rf docs/build/

# 3. Borrar bases de datos y plots pesados de la carpeta estática
echo "[3/6] Eliminando archivos .db, .png y .html generados en docs/source/_static/..."
find docs/source/_static -name "*.db" -type f -delete
find docs/source/_static -name "*.png" -type f -delete
find docs/source/_static -name "*.html" -type f -delete

# Limpiar archivos basura de la carpeta de scripts
find pikobs/script -name "core.burp2bufr.*" -type f -delete
find pikobs/script -name "file::memory*" -type f -delete
rm -f pikobs/script/encout pikobs/script/reject pikobs/script/journal pikobs/script/headers

# 4. Asegurar que existe el .gitignore para proteger el nuevo repositorio
echo "[4/6] Configurando .gitignore..."
cat << 'EOF' > .gitignore
build/
dist/
*.egg-info/
__pycache__/
*.py[cod]
*$py.class
*.so
*.o
pikobs/extension/libudfsqlite-shared.so
docs/build/
docs/source/_static/**/*.html
docs/source/_static/**/*.png
docs/source/_static/**/*.db
!docs/source/_static/basic.css
*.png
*.html
*.db
*.sqlite
journal
headers
encout
reject
core.*
*.swp
*file::memory*
EOF

# 5. Reiniciar Git
echo "[5/6] Destruyendo historial pesado y reiniciando Git..."
rm -rf .git/
git init
git add .
git commit -m "chore: initial commit (repositorio limpio y reiniciado)"

# 6. Forzar la subida a GitLab
echo "[6/6] Conectando a GitLab y forzando la subida..."
git remote add origin https://gitlab.science.gc.ca/dlo001/Pikobs.git

echo "========================================="
echo "🚀 ¡Todo listo! Subiendo al servidor..."
echo "========================================="
# Forzamos el push. Te pedirá tus credenciales aquí.
git push -u origin master --force

echo "✅ Proceso completado. ¡Tu repositorio ahora está limpio y ligero!"
