Varno
=====

.. automodule:: pikobs.type_varno

