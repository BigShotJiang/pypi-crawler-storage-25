Timeserie
=========

.. automodule:: pikobs.timeserie.timeserie
