import os
import sys
#sys.path.insert(0, os.path.abspath('..')) 
sys.path.insert(0, os.path.abspath('../../'))
autodoc_mock_imports = ["dask", "distributed", "sqlite3"]

project = 'Pikobs'

html_theme = "sphinx_rtd_theme"
html_static_path = ['_static']
project = 'Pikobs'
copyright = '2023, David Lobon'
author = 'David Lobon'
html_theme_options = {
    'collapse_navigation': False,  
    'sticky_navigation': True,    
    'navigation_depth': 4,     
    'includehidden': True,
    'titles_only': False
}
extensions = ['sphinx.ext.napoleon',
              'sphinx.ext.doctest', 
              'sphinx_autodoc_typehints',
              "sphinx.ext.autodoc"]

napoleon_include_private_with_doc = False

