histogram
=========

.. automodule:: pikobs.histogram.histogram
