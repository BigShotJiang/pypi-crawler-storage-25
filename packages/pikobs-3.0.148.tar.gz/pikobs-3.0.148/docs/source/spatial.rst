spatial
=======

.. automodule:: pikobs.spatial.spatial
