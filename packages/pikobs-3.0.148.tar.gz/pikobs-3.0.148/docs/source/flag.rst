Flag
====

.. automodule:: pikobs.flags.flags
