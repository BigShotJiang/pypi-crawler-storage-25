=========================================================
Pikobs: CMC Observational Data Processing Toolkit
=========================================================

.. image:: https://img.shields.io/badge/python-3.10+-blue.svg
   :target: https://www.python.org/downloads/
   :alt: Python Version

.. image:: https://img.shields.io/badge/docs-Sphinx-green.svg
   :target: https://www.sphinx-doc.org/
   :alt: Built with Sphinx

Welcome to the **Pikobs** documentation. Pikobs is a Python toolkit
for the extraction, processing, and visualization of **CMC (Canadian
Meteorological Centre)** observational data. It bundles a coherent set
of modules to analyze, statistically monitor, and quality-control both
conventional and satellite meteorological observations.

---

Overview
--------

Pikobs bridges raw assimilation-cycle files and data-driven
decision-making. The core workflow lets researchers and meteorologists:

* **Extract** data from the CMC assimilation-cycle outputs
  (monitoring/banco) used by the ``psmon`` system, including
  `RDB files <https://wiki.cmc.ec.gc.ca/wiki/Tables_Relationnelles_pour_les_observations>`_
  from ``evalalt``, ``bgckalt`` and ``postalt``.
* **Filter** observations with precise bitmask criteria — see
  :doc:`assimilation flags <flags_criteria>` and
  :doc:`geographical regions <region>`.
* **Compute** statistical metrics including O-B (omp), O-A (oma),
  observation density and bias corrections.
* **Visualize** results with metric-specific renderers — see
  :doc:`Scatter Plots <scatter>`, :doc:`Geographical Maps <mapobs>`,
  :doc:`Histograms <histogram>`, and more.

---

Installation
------------

Pikobs relies on a Conda environment and is designed to run seamlessly 
on CMC HPC infrastructure. The installation is a **one-time process**.

Step 1: Run the Bootstrap Script
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

We provide an automated script that configures the CMC proxy, loads the 
official Mamba module, and creates a pinned Conda environment.

.. code-block:: bash

   wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/setup_pikobs.sh
   chmod +x setup_pikobs.sh

   # Install in the default location ($HOME/pikobs_install):
   ./setup_pikobs.sh

   # OR specify a custom project directory:
   ./setup_pikobs.sh --project-dir /home/your_user/my_pikobs

Step 2: Verify Installation
~~~~~~~~~~~~~~~~~~~~~~~~~~

When the script finishes, it generates a ``load_pikobs.sh`` helper. 
Verify that the environment loads correctly:

.. code-block:: bash

   source $HOME/pikobs_install/load_pikobs.sh
   python -c "import pikobs; print('Pikobs Ready:', pikobs.__version__)"

---

How to Use Pikobs
-----------------

Pikobs modules are executed using **bash wrapper scripts** (e.g., ``run_mapobs.sh``, 
``run_scatter.sh``). You do not need to interact with Python directly. 

1. Download and Configure a Wrapper
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Each module has a template wrapper in the repository's ``script/`` folder. 
Download the one you need and modify the arguments (dates, paths, CPUs) inside the file:

.. code-block:: bash

   wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs/script/run_mapobs.sh
   chmod +x run_mapobs.sh
   nano run_mapobs.sh  # Edit paths, datestart, dateend, etc.

2. Execution Modes (PBS Auto-Submit vs. Interactive)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pikobs features an **intelligent PBS job manager**. How it behaves depends entirely 
on *where* you run the wrapper script:

* **Mode A: Running on a Login Node (Recommended)**
  If you execute ``./run_mapobs.sh`` from a standard login node (e.g., ``ppp7login``), 
  Pikobs will **automatically generate a PBS script and submit it to the queue via qsub**. 
  It will then tail the log live in your terminal. You can press ``Ctrl+C`` to detach 
  safely without stopping the background job.

* **Mode B: Running on a Compute Node**
  If you open an interactive session first (``qsub -I -lselect=1:ncpus=40:mem=185gb...``) 
  and then execute the script, Pikobs will detect the ``PBS_JOBID`` and run the 
  processing **locally** on that node immediately.

* **Local Debugging (--no_submit)**
  You can pass the ``--no_submit`` flag inside your wrapper to bypass PBS entirely. 
  *Warning:* Never do this on a login node for heavy jobs, as it will consume shared resources.

Updating Pikobs
~~~~~~~~~~~~~~

Pikobs checks for updates automatically upon execution. If a newer version is available 
on the internal PyPI index, it will prompt you in the terminal. Press ``y`` to safely 
hot-update the tool without breaking your Conda environment.

---

.. _core-modules:

Core Modules Overview
---------------------

Explore the individual pages for detailed parameters and capabilities of each module:

* :doc:`scatter`: Generate 2-D geographical scatter plots of metrics.
* :doc:`timeserie`: Analyze the temporal evolution of statistics.
* :doc:`cardio`: Monitor system health and assimilation flow.
* :doc:`vdedr`: Vertical profiles and specific observational metrics.
* :doc:`zone`: Statistical aggregations across regional zones.
* :doc:`flag`: Quality-Control deep dive on rejection / assimilation flags.
* :doc:`mapobs`: Detailed geographical maps of observation locations.
* :doc:`histogram`: Statistical distributions and frequencies.
* :doc:`profile`: Vertical distribution of metrics across pressure levels or channels.
* :doc:`profile_ft`: Bias and standard deviation across pressure levels or channels.
* :doc:`profile_ft2`: Pairwise comparisons between experiments with F-test significance.
* :doc:`spatial`: Multi-dimensional correlation of observational statistics.
* :doc:`obscountdb`: Compare observation volumes between two cycles.

Utility
-------

* :doc:`pikobsburp2rdb`: Convert raw BURP/BUFR data into standard RDB structures.

Documentation Index
-------------------

.. toctree::
   :maxdepth: 2
   :caption: 🛠️ Core Modules

   scatter
   timeserie
   cardio
   vdedr
   zone
   flag
   mapobs
   histogram
   profile
   profile_ft
   profile_ft2
   spatial
   obscountdb

.. toctree::
   :maxdepth: 2
   :caption: 🔧 Utility

   pikobsburp2rdb

.. toctree::
   :maxdepth: 2
   :caption: ⚙️ Configuration

   region
   projection
   flags_criteria
   families
   varno

.. toctree::
   :maxdepth: 2
   :caption: 🧪 Development

   unittest

---

Resources & Contact
-------------------

* **Repository:**
  `Pikobs on GitLab <https://gitlab.science.gc.ca/dlo001/Pikobs>`_
* **Issues / bug reports:**
  `<https://gitlab.science.gc.ca/dlo001/Pikobs/-/issues>`_
* **RDB Data Reference:**
  `RDB Files Documentation (Wiki) <https://wiki.cmc.ec.gc.ca/wiki/Tables_Relationnelles_pour_les_observations>`_
