Vdedr
=======

.. automodule:: pikobs.vdedr.vdedr
