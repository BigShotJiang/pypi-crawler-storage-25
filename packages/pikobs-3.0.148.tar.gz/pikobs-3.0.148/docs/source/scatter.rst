Scatter
=======

.. automodule:: pikobs.scatter.scatter
