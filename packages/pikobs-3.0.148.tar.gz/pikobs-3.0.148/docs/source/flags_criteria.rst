flags criteria
==============

.. automodule:: pikobs.flag_criteria

