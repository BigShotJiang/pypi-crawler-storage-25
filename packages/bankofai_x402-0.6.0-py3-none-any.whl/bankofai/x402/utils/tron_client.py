"""
Shared AsyncTron client factory.

Centralizes tronpy AsyncTron initialization with TronGrid API key support.
"""

import logging
import os
from typing import Any

from tronpy import AsyncTron
from tronpy.defaults import conf_for_name
from tronpy.providers.async_http import AsyncHTTPProvider

logger = logging.getLogger(__name__)

TRON_MAINNET_FALLBACK_URL = "https://hptg.bankofai.io"
TRON_NILE_FALLBACK_URL = "https://api.nileex.io"
TRON_SHASTA_FALLBACK_URL = "https://api.shasta.trongrid.io"


def create_async_tron_client(network: str) -> Any:
    """Create an AsyncTron client for the given network.

    When TRON_GRID_API_KEY env var is set, uses TronGrid with the API key.
    When not set and network is mainnet, uses the BankOfAI fallback RPC
    (https://hptg.bankofai.io). For other networks without an API key,
    tronpy defaults are used.

    Args:
        network: TRON network name (e.g. "nile", "mainnet") or full identifier (e.g. "tron:nile")

    Returns:
        tronpy.AsyncTron instance
    """
    # Strip "tron:" prefix if present (e.g. "tron:nile" -> "nile")
    if network.startswith("tron:"):
        network = network[len("tron:") :]

    api_key = os.getenv("TRON_GRID_API_KEY")
    if not api_key:
        if network == "mainnet":
            logger.warning(
                "TRON_GRID_API_KEY is not set. Mainnet RPC calls will be routed to %s. "
                "Set TRON_GRID_API_KEY to use TronGrid.",
                TRON_MAINNET_FALLBACK_URL,
            )
            provider = AsyncHTTPProvider(endpoint_uri=TRON_MAINNET_FALLBACK_URL)
            logger.info(
                "Creating AsyncTron client with fallback provider for network=%s (%s)",
                network,
                TRON_MAINNET_FALLBACK_URL,
            )
            return AsyncTron(provider=provider, network=network)

        if network == "nile":
            provider = AsyncHTTPProvider(endpoint_uri=TRON_NILE_FALLBACK_URL)
            logger.info(
                "Creating AsyncTron client with fallback provider for network=%s (%s)",
                network,
                TRON_NILE_FALLBACK_URL,
            )
            return AsyncTron(provider=provider, network=network)

        if network == "shasta":
            provider = AsyncHTTPProvider(endpoint_uri=TRON_SHASTA_FALLBACK_URL)
            logger.info(
                "Creating AsyncTron client with fallback provider for network=%s (%s)",
                network,
                TRON_SHASTA_FALLBACK_URL,
            )
            return AsyncTron(provider=provider, network=network)

        logger.warning(
            "TRON_GRID_API_KEY is not set. Requests may be rate-limited or fail; "
            "set TRON_GRID_API_KEY in your environment/.env to use TronGrid reliably."
        )
        logger.info("Creating AsyncTron client for network=%s", network)
        return AsyncTron(network=network)

    conf = conf_for_name(network)
    if not conf:
        raise ValueError(
            f"Unknown TRON network '{network}'. Expected one of: mainnet, nile, shasta."
        )

    endpoint_uri = conf["fullnode"]
    provider = AsyncHTTPProvider(endpoint_uri=endpoint_uri, api_key=api_key)
    logger.info(
        "Creating AsyncTron client with TronGrid API key for network=%s (%s)",
        network,
        endpoint_uri,
    )
    return AsyncTron(provider=provider, network=network)
