import traceback

import redis
from redis import Redis, ConnectionPool, Sentinel
from sshtunnel import SSHTunnelForwarder
import threading
import time
import logging
import json
import pickle
import zlib
from typing import Any, List, Dict, Callable, Union
from functools import wraps
from contextlib import contextmanager

from .cache_util import CacheClient
from ...common.log_util import LogUtil
from ...common.functions import filter_by_array, Serialize


class RedisClient(CacheClient):
    """
    高性能Redis客户端，支持SSH隧道、连接池、集群和哨兵模式

    特性：
    1. SSH隧道支持（密码/密钥认证）
    2. 原生连接池和连接复用
    3. 支持Redis集群和哨兵模式
    4. 自动重连和故障转移
    5. 序列化/压缩支持
    6. 缓存装饰器和批量操作
    7. 管道和事务支持
    8. 性能监控和统计
    """

    def __init__(self, *,
                 logger: logging.Logger = None,
                 # SSH配置
                 ssh_host: str = "",
                 ssh_port: int = 22,
                 ssh_username: str = "",
                 ssh_password: str = "",
                 ssh_private_key: str = "",
                 ssh_private_key_password: str = "",

                 # Redis配置
                 redis_host: str = "",
                 redis_port: int = 6379,
                 redis_password: str = None,
                 redis_db: int = 0,

                 # 连接池配置
                 max_connections: int = 50,
                 socket_timeout: int = 5,
                 socket_connect_timeout: int = 5,
                 socket_keepalive: bool = True,

                 # 高级配置
                 use_cluster: bool = False,  # 注：暂时不支持cluster
                 cluster_nodes: list = None,
                 use_sentinel: bool = False,
                 sentinel_master: str = "",
                 sentinel_nodes: list = None,

                 # 序列化配置
                 serializer: str = "json",  # json, pickle, msgpack
                 compress: bool = False,
                 compress_threshold: int = 1024,  # 压缩阈值（字节）

                 # 性能优化
                 retry_on_timeout: bool = True,
                 retry_on_error: list = None,
                 health_check_interval: int = 30,
                 decode_responses: bool = True,
                 encoding: str = "utf-8"):
        """
        初始化Redis客户端

        """
        if not logger:
            logger = LogUtil(name="redis")
        self.logger = logger
        self._lock = threading.RLock()
        self._ssh_tunnel = None
        self._redis_client = None
        self._connection_pool = None
        self._stats = {
            "commands": 0,
            "hits": 0,
            "misses": 0,
            "errors": 0,
            "reconnects": 0,
            "start_time": time.time()
        }

        # 配置
        self.config = {
            "ssh": {
                "host": ssh_host,
                "port": ssh_port,
                "username": ssh_username,
                "password": ssh_password,
                "private_key": ssh_private_key,
                "private_key_password": ssh_private_key_password
            },
            "redis": {
                "host": redis_host,
                "port": redis_port,
                "password": redis_password,
                "db": redis_db,
                "socket_timeout": socket_timeout,
                "socket_connect_timeout": socket_connect_timeout,
                "socket_keepalive": socket_keepalive,
                "max_connections": max_connections,
                "retry_on_timeout": retry_on_timeout,
                "retry_on_error": retry_on_error or [redis.ConnectionError],
                "health_check_interval": health_check_interval,
                "decode_responses": decode_responses,
                "encoding": encoding
            },
            "cluster": {
                "enabled": use_cluster,
                "nodes": cluster_nodes or [{"host": redis_host, "port": redis_port}]
            },
            "sentinel": {
                "enabled": use_sentinel,
                "master": sentinel_master,
                "nodes": sentinel_nodes or [{"host": redis_host, "port": 26379}]
            },
            "serializer": {
                "type": filter_by_array(serializer, ["json", "pickle", "msgpack"]),
                "compress": compress,
                "compress_threshold": compress_threshold
            }
        }

        # 是否使用SSH隧道
        self.use_ssh = all([ssh_host, ssh_username])

        # 初始化连接
        self._initialize_connection()

        # 启动健康检查
        if health_check_interval > 0:
            self._start_health_check(health_check_interval)

    def __del__(self):
        if isinstance(self.logger, LogUtil) and self.logger.name == 'redis':
            self.logger.close()

    def _initialize_connection(self):
        """初始化Redis连接"""
        try:
            local_port = None

            # 1. 建立SSH隧道
            if self.use_ssh:
                local_port = self._create_ssh_tunnel()

            # 2. 创建Redis连接
            if self.config.get('redis', {}).get('port', 0) <= 0:
                self._create_redis_connection(local_port)
            else:
                self._create_redis_connection()

            self.logger.info(f"Redis连接已建立，模式: {self._get_connection_mode()}")

        except Exception:
            self.logger.error(f"初始化Redis连接失败")
            self.logger.error(traceback.format_exc())
            self.close()
            raise

    def _create_ssh_tunnel(self) -> int:
        """创建SSH隧道"""
        ssh_config = self.config["ssh"]

        self.logger.info(f"正在建立SSH隧道连接到 {ssh_config['host']}:{ssh_config['port']}")

        ssh_params = {
            'ssh_address_or_host': (ssh_config['host'], ssh_config['port']),
            'ssh_username': ssh_config['username'],
            'remote_bind_address': (self.config["redis"]["host"],
                                    self.config["redis"]["port"]),
            'local_bind_address': ('127.0.0.1', 0),  # 自动分配本地端口
            'set_keepalive': 30,  # 保持连接
            'logger': self.logger.get_logger()
        }

        # 认证方式
        if ssh_config.get('password'):
            ssh_params['ssh_password'] = ssh_config['password']
        elif ssh_config.get('private_key'):
            ssh_params['ssh_pkey'] = ssh_config['private_key']
            if ssh_config.get('private_key_password'):
                ssh_params['ssh_pkey_password'] = ssh_config['private_key_password']

        self._ssh_tunnel = SSHTunnelForwarder(**ssh_params)
        self._ssh_tunnel.start()

        local_port = self._ssh_tunnel.local_bind_port
        self.logger.info(f"SSH隧道已建立，本地端口: {local_port}")

        return local_port

    # 暂时不支持cluster，这里注释掉
    # def _create_cluster_connection(self, config: dict):
    #     """创建集群模式连接"""
    #     cluster_config = self.config["cluster"]
    #
    #     startup_nodes = [
    #         {"host": node["host"], "port": node["port"]}
    #         for node in cluster_config["nodes"]
    #     ]
    #
    #     self._redis_client = RedisCluster(
    #         startup_nodes=startup_nodes,
    #         password=config["password"],
    #         socket_timeout=config["socket_timeout"],
    #         socket_connect_timeout=config["socket_connect_timeout"],
    #         decode_responses=config["decode_responses"],
    #         skip_full_coverage_check=True,
    #         max_connections=config["max_connections"]
    #     )

    def _create_redis_connection(self, local_port: int = None):
        """创建Redis连接"""
        redis_config = self.config["redis"].copy()

        # 更新连接参数（SSH隧道）
        if local_port:
            redis_config["host"] = "127.0.0.1"
            redis_config["port"] = local_port

        # 根据模式创建连接
        if self.config["sentinel"]["enabled"]:
            self._create_sentinel_connection(redis_config)
        # elif self.config["cluster"]["enabled"]:
        #     self._create_cluster_connection(redis_config)
        else:
            self._create_standalone_connection(redis_config)

    def _create_standalone_connection(self, config: dict):
        """创建单节点连接"""
        # 创建连接池
        self._connection_pool = ConnectionPool(
            host=config["host"],
            port=config["port"],
            password=config["password"],
            db=config["db"],
            max_connections=config["max_connections"],
            socket_timeout=config["socket_timeout"],
            socket_connect_timeout=config["socket_connect_timeout"],
            socket_keepalive=config["socket_keepalive"],
            retry_on_timeout=config["retry_on_timeout"],
            health_check_interval=config["health_check_interval"],
            decode_responses=config["decode_responses"],
            encoding=config["encoding"]
        )

        # 创建Redis客户端
        self._redis_client = Redis(
            connection_pool=self._connection_pool,
            retry_on_error=config["retry_on_error"]
        )

    def _create_sentinel_connection(self, config: dict):
        """创建哨兵模式连接"""
        sentinel_config = self.config["sentinel"]

        # 创建哨兵连接
        sentinel = Sentinel(
            [(node["host"], node["port"]) for node in sentinel_config["nodes"]],
            socket_timeout=config["socket_timeout"],
            password=config["password"],
            decode_responses=config["decode_responses"]
        )

        # 获取主节点连接
        self._redis_client = sentinel.master_for(
            sentinel_config["master"],
            socket_timeout=config["socket_timeout"],
            password=config["password"],
            db=config["db"]
        )

    def _get_connection_mode(self) -> str:
        """获取连接模式"""
        if self.config["cluster"]["enabled"]:
            return "cluster"
        elif self.config["sentinel"]["enabled"]:
            return "sentinel"
        else:
            return "standalone"

    def _start_health_check(self, interval: int):
        """启动健康检查线程"""

        def health_check():
            while True:
                time.sleep(interval)
                try:
                    if not self.ping():
                        self.logger.warning("Redis健康检查失败，尝试重连...")
                        self._reconnect()
                except Exception:
                    self.logger.error(f"健康检查异常:")
                    self.logger.error(traceback.format_exc())

        thread = threading.Thread(target=health_check, daemon=True)
        thread.start()

    def _reconnect(self):
        """重新连接"""
        with self._lock:
            self._stats["reconnects"] += 1
            self.logger.info("正在重新连接Redis...")

            old_client = self._redis_client
            old_pool = self._connection_pool

            try:
                self._initialize_connection()
                self.logger.info("Redis重新连接成功")

                # 关闭旧连接
                if old_pool:
                    try:
                        old_pool.disconnect()
                    except:
                        pass

            except Exception:
                self.logger.error(f"重新连接失败:")
                self.logger.error(traceback.format_exc())
                self._redis_client = old_client
                self._connection_pool = old_pool
                raise

    # ========== 基础操作方法 ==========

    def _record_command(self, hit: bool = None):
        """记录命令统计"""
        self._stats["commands"] += 1
        if hit is True:
            self._stats["hits"] += 1
        elif hit is False:
            self._stats["misses"] += 1

    def _serialize(self, value: Any) -> bytes:
        """序列化数据"""
        serializer = self.config["serializer"]

        # 序列化
        if serializer["type"] == "json":
            data = json.dumps(value, ensure_ascii=False, cls=Serialize).encode('utf-8')
        elif serializer["type"] == "pickle":
            data = pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL)
        else:
            data = str(value).encode('utf-8')

        # 压缩
        if serializer["compress"] and len(data) > serializer["compress_threshold"]:
            data = zlib.compress(data)
            data = b"C:" + data  # 添加压缩标记

        return data

    def _deserialize(self, data: Union[bytes, str]) -> Any:
        """反序列化数据"""
        if data is None:
            return None

        if isinstance(data, str):
            data = data.encode('utf-8')

        serializer = self.config["serializer"]

        # 检查是否为压缩数据
        if data.startswith(b"C:"):
            data = zlib.decompress(data[2:])

        # 反序列化
        try:
            if serializer["type"] == "json":
                return json.loads(data.decode('utf-8'))
            elif serializer["type"] == "pickle":
                return pickle.loads(data)
            else:
                return data.decode('utf-8')
        except:
            return data

    # ========== Redis操作封装 ==========

    def get(self, key: str, default: Any = None) -> Any:
        """获取值"""
        try:
            value = self._redis_client.get(key)
            self._record_command(hit=value is not None)
            if value is None:
                return default
            else:
                try:
                    return self._deserialize(value)
                except Exception:
                    return value
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"GET {key} 失败:")
            self.logger.error(traceback.format_exc())
            return default

    def set(self, key: str, value: Any, *, ex: int = None, px: int = None,
            nx: bool = False, xx: bool = False) -> bool:
        """设置值"""
        try:
            serialized = self._serialize(value)
            result = self._redis_client.set(
                key, serialized,
                ex=ex, px=px, nx=nx, xx=xx
            )
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"SET {key} 失败:")
            self.logger.error(traceback.format_exc())
            return False

    def delete(self, *keys) -> int:
        """删除键"""
        try:
            result = self._redis_client.delete(*keys)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"DELETE {keys} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def exists(self, *keys) -> int:
        """检查键是否存在"""
        try:
            result = self._redis_client.exists(*keys)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"EXISTS {keys} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def expire(self, key: str, _time: int) -> bool:
        """设置过期时间"""
        try:
            result = self._redis_client.expire(key, _time)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"EXPIRE {key} 失败:")
            self.logger.error(traceback.format_exc())
            return False

    def ttl(self, key: str) -> int:
        """获取剩余过期时间"""
        try:
            result = self._redis_client.ttl(key)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"TTL {key} 失败:")
            self.logger.error(traceback.format_exc())
            return -2

    def incr(self, key: str, amount: int = 1) -> int:
        """自增"""
        try:
            result = self._redis_client.incr(key, amount)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"INCR {key} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def decr(self, key: str, amount: int = 1) -> int:
        """自减"""
        try:
            result = self._redis_client.decr(key, amount)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"DECR {key} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    # ========== 哈希表操作 ==========

    def hget(self, key: str, field: str, default: Any = None) -> Any:
        """获取哈希字段值"""
        try:
            value = self._redis_client.hget(key, field)
            self._record_command(hit=value is not None)
            if value is None:
                return default
            else:
                try:
                    return self._deserialize(value)
                except Exception:
                    return value
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"HGET {key}:{field} 失败:")
            self.logger.error(traceback.format_exc())
            return default

    def hset(self, key: str, field: str, value: Any) -> int:
        """设置哈希字段值"""
        try:
            serialized = self._serialize(value)
            result = self._redis_client.hset(key, field, serialized)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"HSET {key}:{field} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def h_get_all(self, key: str) -> Dict:
        """获取所有哈希字段"""
        try:
            result = self._redis_client.hgetall(key)
            self._record_command()
            return {k: self._deserialize(v) for k, v in result.items()}
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"HGETALL {key} 失败:")
            self.logger.error(traceback.format_exc())
            return {}

    def hm_set(self, key: str, mapping: Dict) -> bool:
        """批量设置哈希字段"""
        try:
            serialized = {k: self._serialize(v) for k, v in mapping.items()}
            result = self._redis_client.hmset(key, serialized)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"HMSET {key} 失败:")
            self.logger.error(traceback.format_exc())
            return False

    # ========== 列表操作 ==========

    def l_push(self, key: str, *values) -> int:
        """从左侧推入列表"""
        try:
            serialized = [self._serialize(v) for v in values]
            result = self._redis_client.lpush(key, *serialized)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"LPUSH {key} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def r_push(self, key: str, *values) -> int:
        """从右侧推入列表"""
        try:
            serialized = [self._serialize(v) for v in values]
            result = self._redis_client.rpush(key, *serialized)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"RPUSH {key} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def lrange(self, key: str, start: int = 0, end: int = -1) -> List:
        """获取列表范围"""
        try:
            result = self._redis_client.lrange(key, start, end)
            self._record_command()
            return [self._deserialize(v) for v in result]
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"LRANGE {key} 失败:")
            self.logger.error(traceback.format_exc())
            return []

    # ========== 集合操作 ==========

    def s_add(self, key: str, *values) -> int:
        """添加集合元素"""
        try:
            serialized = [self._serialize(v) for v in values]
            result = self._redis_client.sadd(key, *serialized)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"SADD {key} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def s_members(self, key: str) -> set:
        """获取集合所有元素"""
        try:
            result = self._redis_client.smembers(key)
            self._record_command()
            return {self._deserialize(v) for v in result}
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"SMEMBERS {key} 失败:")
            self.logger.error(traceback.format_exc())
            return set()

    # ========== 有序集合操作 ==========

    def z_add(self, key: str, mapping: Dict[Any, float]) -> int:
        """添加有序集合元素"""
        try:
            serialized = {self._serialize(k): v for k, v in mapping.items()}
            result = self._redis_client.zadd(key, serialized)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"ZADD {key} 失败:")
            self.logger.error(traceback.format_exc())
            return 0

    def z_range(self, key: str, start: int = 0, end: int = -1,
                with_scores: bool = False) -> List:
        """获取有序集合范围"""
        try:
            result = self._redis_client.zrange(key, start, end, withscores=with_scores)
            self._record_command()

            if with_scores:
                return [(self._deserialize(v[0]), v[1]) for v in result]
            else:
                return [self._deserialize(v) for v in result]
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"ZRANGE {key} 失败:")
            self.logger.error(traceback.format_exc())
            return []

    # ========== 高级功能 ==========

    @contextmanager
    def pipeline(self, transaction: bool = True):
        """管道上下文管理器"""
        pipe = None
        try:
            pipe = self._redis_client.pipeline(transaction=transaction)
            yield pipe
            pipe.execute()
        except Exception:
            if pipe:
                pipe.reset()
            self.logger.error(f"管道操作失败:")
            self.logger.error(traceback.format_exc())
            raise
        finally:
            if pipe:
                try:
                    pipe.reset()
                except:
                    pass

    def mget(self, keys: List[str]) -> List:
        """批量获取"""
        try:
            result = self._redis_client.mget(keys)
            self._record_command()
            return [self._deserialize(v) if v else None for v in result]
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"MGET {keys} 失败:")
            self.logger.error(traceback.format_exc())
            return [None] * len(keys)

    def mset(self, mapping: Dict[str, Any]) -> bool:
        """批量设置"""
        try:
            serialized = {k: self._serialize(v) for k, v in mapping.items()}
            result = self._redis_client.mset(serialized)
            self._record_command()
            return result
        except Exception:
            self._stats["errors"] += 1
            self.logger.error(f"MSET {list(mapping.keys())} 失败:")
            self.logger.error(traceback.format_exc())
            return False

    def scan_iter(self, match: str = None, count: int = 100) -> List:
        """扫描键（迭代器）"""
        try:
            for key in self._redis_client.scan_iter(match=match, count=count):
                yield key.decode() if isinstance(key, bytes) else key
        except Exception:
            self.logger.error(f"SCAN {match} 失败:")
            self.logger.error(traceback.format_exc())
            return []

    def get_keys(self, pattern: str = "*") -> List[str]:
        """获取匹配的键（使用scan，避免阻塞）"""
        return list(self.scan_iter(match=pattern))

    def clear_db(self, pattern: str = "*") -> int:
        """清空匹配的键"""
        keys = self.get_keys(pattern)
        if keys:
            return self.delete(*keys)
        return 0

    # ========== 缓存装饰器 ==========

    def cached(self,
               key_func: Callable = None,
               ttl: int = 300,
               prefix: str = "cache"):
        """
        缓存装饰器

        Args:
            key_func: 键生成函数
            ttl: 缓存时间（秒）
            prefix: 键前缀
        """

        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # 生成缓存键
                if key_func:
                    cache_key = key_func(*args, **kwargs)
                else:
                    # 默认键生成策略
                    func_name = func.__name__
                    args_str = str(args) + str(kwargs)
                    cache_key = f"{prefix}:{func_name}:{hash(args_str)}"

                # 尝试从缓存获取
                cached_value = self.get(cache_key)
                if cached_value is not None:
                    return cached_value

                # 执行函数
                result = func(*args, **kwargs)

                # 存入缓存
                self.set(cache_key, result, ex=ttl)

                return result

            return wrapper

        return decorator

    def cache_delete(self, key_func: Callable, *args, **kwargs):
        """删除缓存"""
        cache_key = key_func(*args, **kwargs)
        return self.delete(cache_key)

    # ========== 性能监控 ==========

    def ping(self) -> bool:
        """检查连接状态"""
        try:
            return self._redis_client.ping()
        except:
            return False

    def info(self, section: str = None) -> Dict:
        """获取Redis信息"""
        try:
            return self._redis_client.info(section)
        except Exception:
            self.logger.error(f"INFO 失败:")
            self.logger.error(traceback.format_exc())
            return {}

    def get_stats(self) -> Dict:
        """获取统计信息"""
        uptime = time.time() - self._stats["start_time"]

        stats = self._stats.copy()
        stats["uptime"] = uptime
        stats["qps"] = stats["commands"] / uptime if uptime > 0 else 0

        if stats["hits"] + stats["misses"] > 0:
            stats["hit_rate"] = stats["hits"] / (stats["hits"] + stats["misses"])
        else:
            stats["hit_rate"] = 0

        return stats

    def get_connection_info(self) -> Dict:
        """获取连接信息"""
        if not self._connection_pool:
            return {}

        try:
            return {
                "mode": self._get_connection_mode(),
                "max_connections": self._connection_pool.max_connections,
                "idle_connections": len(self._connection_pool._available_connections),
                "in_use_connections": len(self._connection_pool._in_use_connections),
                "connection_kwargs": self._connection_pool.connection_kwargs
            }
        except:
            return {}

    # ========== 资源管理 ==========

    def close(self):
        """关闭连接"""
        with self._lock:
            # 关闭Redis客户端
            if self._redis_client:
                try:
                    if hasattr(self._redis_client, 'close'):
                        self._redis_client.close()
                except Exception:
                    self.logger.error(f"关闭Redis客户端失败:")
                    self.logger.error(traceback.format_exc())
                finally:
                    self._redis_client = None

            # 关闭Redis连接池
            if self._connection_pool:
                try:
                    self._connection_pool.disconnect()
                except Exception:
                    self.logger.error(f"关闭连接池失败:")
                    self.logger.error(traceback.format_exc())
                finally:
                    self._connection_pool = None
                    self.logger.info("Redis连接池已关闭")

            # 关闭SSH隧道
            if self._ssh_tunnel:
                try:
                    self._ssh_tunnel.stop()
                    self.logger.info("SSH隧道已关闭")
                except Exception:
                    self.logger.error(f"关闭SSH隧道失败:")
                    self.logger.error(traceback.format_exc())
                finally:
                    self._ssh_tunnel = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __del__(self):
        try:
            self.close()
        except:
            pass

    def __getattr__(self, name):
        """将未实现的方法转发给Redis客户端"""
        if hasattr(self._redis_client, name):
            def method(*args, **kwargs):
                try:
                    self._record_command()
                    return getattr(self._redis_client, name)(*args, **kwargs)
                except Exception:
                    self._stats["errors"] += 1
                    self.logger.error(f"{name} 失败:")
                    self.logger.error(traceback.format_exc())
                    raise

            return method
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")


class RedisUtil:
    @staticmethod
    def new_redis_client(**kwargs):
        return RedisClient(**kwargs)


# if __name__ == '__main__':
#     from ...common import config
#     redis = RedisUtil.new_redis_client(**config.REDIS_INFO)
#     keys = redis.get_keys("*")
#     print(keys)
