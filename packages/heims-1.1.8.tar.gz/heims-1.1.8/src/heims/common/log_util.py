import datetime
import logging
import os
from random import random
from typing import List

from . import config


class LogUtil:
    _loggers_cache = {}  # 缓存已创建的logger，避免重复添加handler

    def __init__(self, *, base_dir:str="", name: str=""):
        if not name:
            name = str(random())[2:12]
        self.name = name
        self._handlers: List[logging.FileHandler] = []
        self._logger = None
        if not base_dir:
            base_dir = config.BASE_INFO['base_dir']
        log_folder = os.path.join(base_dir, "log")
        if not os.path.exists(log_folder):
            os.mkdir(log_folder)
        today = datetime.datetime.now().strftime('%Y%m%d')

        # 检查是否已经有handler添加到这个logger
        if name not in LogUtil._loggers_cache:
            LogUtil._loggers_cache[name] = True
            self._logger = logging.getLogger(name)
            self._logger.setLevel(logging.DEBUG)
            # 合并为一个日志文件
            file_handler = logging.FileHandler(
                os.path.join(log_folder, f"{today}.log"),
                encoding="utf-8"
            )
            file_handler.setFormatter(logging.Formatter(f'%(asctime)s - %(levelname)s - %(message)s'))
            self._logger.addHandler(file_handler)
            self._handlers.append(file_handler)
        else:
            # 已存在handler，直接获取logger引用
            self._logger = logging.getLogger(name)

    def close(self):
        """关闭并移除所有由本实例创建的handler"""
        for handler in self._handlers:
            try:
                if isinstance(handler, logging.FileHandler):
                    handler.close()
                    # 从logger中移除handler
                    for logger in logging.Logger.manager.loggerDict.values():
                        if isinstance(logger, logging.Logger):
                            if handler in logger.handlers:
                                logger.removeHandler(handler)
            except Exception:
                pass
        self._handlers.clear()
        # 从缓存中移除
        if self.name in LogUtil._loggers_cache:
            del LogUtil._loggers_cache[self.name]

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def info(self, msg, *args, **kwargs):
        if self._logger:
            self._logger.info(msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        if self._logger:
            self._logger.error(msg, *args, **kwargs)

    def debug(self, msg, *args, **kwargs):
        if self._logger:
            self._logger.debug(msg, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        if self._logger:
            self._logger.warning(msg, *args, **kwargs)

    def get_logger(self):
        return self._logger
