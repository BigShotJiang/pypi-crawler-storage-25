import datetime
import json
import hashlib
import os.path
import re
import time
import random
import decimal
from typing import Union, List, Tuple, Dict, Any

import yaml

from ..common import config


class Serialize(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.__str__()[:19].replace('T', ' ')
        elif isinstance(obj, datetime.date):
            return obj.__str__().replace('T', ' ')
        elif isinstance(obj, decimal.Decimal):
            if obj.__str__().startswith('0E-'):
                return "0"
            res_str = obj.__str__()
            while True:
                if ('.' not in res_str) or not res_str.endswith('0'):
                    break
                if res_str[len(res_str) - 2:len(res_str) - 1] == '0':
                    res_str = res_str[:-1]
                else:
                    res_str = res_str + "0"
                    break
            return res_str
        return json.JSONEncoder.default(self, obj)


def md5(string: str) -> str:
    """
    计算字符串的md5值
    """
    return hashlib.md5(string.encode()).hexdigest()


def crypt(input_str: str, *, has_md5: bool = False, salt: Union[str, None] = None) -> str:
    """
    加盐加密
    """
    if not has_md5:
        input_str = md5(input_str)
    if salt is None:
        salt = config.BASE_INFO['secret_key']

    return md5(input_str + salt)


def json_dumps(obj: dict) -> str:
    """
    序列化，增加了对部分特殊类型的支持
    """
    return json.dumps(obj, ensure_ascii=False, cls=Serialize)


def make_id() -> str:
    """
    生成随机字符串
    """
    return md5(f"{time.time()}{random.random()}")


def is_integer(input_str: str) -> bool:
    """
    判断是否整数字符串
    """
    return bool(re.match(r'^[0-9]+$', input_str))

def set_default_int(input_value, default_value:int=0)->int:
    """
    将获取到的值转换为int类型，如果不是int类型，则返回默认值
    """
    if not (isinstance(input_value, str) and is_integer(input_value)):
        return default_value
    return int(input_value)

def get_data_from_dict(_dict: dict, keys: List[str], default_value: Any = None):
    """
    从一个dict里面按照一个key列表获取值，如果key不存在就用下一个key尝试，直到找到为止
    """
    if not isinstance(keys, (list, tuple)):
        keys = [keys]

    for key in keys:
        v = _dict.get(key, None)
        if v is not None:
            return v

    return default_value


def build_tree(input_array: Union[List[Dict], Tuple[Dict]], *, sort_field: Union[str, None] = None,
               reverse_type: bool = True,
               parent_field: str = "parent", children_field: str = 'children'):
    """
    根据带上下级关系的普通字典列表建立树状列表
    """
    nodes = {item['id']: {**item, children_field: []} for item in input_array}
    tree = []
    for node_id, node in nodes.items():
        parent_id = node[parent_field]
        if parent_id == 0:
            tree.append(node)
        else:
            parent = nodes.get(parent_id)
            if parent:
                parent[children_field].append(node)
    # 对所有子节点按 id 排序
    if sort_field:
        for node in nodes.values():
            node[children_field].sort(key=lambda x: x[sort_field] if x[sort_field] is not None else 0, reverse=reverse_type)
    return tree


def deep_copy_dict(source_dict: dict, dest_dict:dict):
    for key, value in source_dict.items():
        if key not in dest_dict:
            dest_dict[key] = value
        else:
            if isinstance(value, dict):
                if not isinstance(dest_dict[key], dict):
                    dest_dict[key] = value
                else:
                    deep_copy_dict(value, dest_dict[key])
            else:
                dest_dict[key] = value

def copy_dict(source_dict: dict, dest_dict: dict=None, *, keys: Union[list, tuple, None] = None,
              filter_keys: Union[list, tuple, None] = None):

    if dest_dict is None:
        dest_dict = {}

    all_keys = set(source_dict.keys())
    if keys:
        all_keys = all_keys.intersection(set(keys))
    if filter_keys:
        all_keys = all_keys.difference(set(filter_keys))

    for key in all_keys:
        dest_dict[key] = source_dict[key]

    return dest_dict


def drop_key_from_dict(source_dict: dict, *, keys: Union[list, tuple, None] = None,
                       filter_keys: Union[list, tuple, None] = None):
    """

    :param source_dict: 要处理的dict
    :param keys: 要保留的字段
    :param filter_keys: 要删除的字段
    :return:
    """
    for key in list(source_dict.keys()):
        if keys:
            if key not in keys:
                del source_dict[key]
        if filter_keys:
            if key in filter_keys:
                del source_dict[key]


def to_snake_case(camel_str: str) -> str:
    """
    驼峰写法改下划线写法
    """
    buffer = []
    for c in camel_str:
        if 'A' <= c <= 'Z':
            buffer.append(f"_{c.lower()}")
        else:
            buffer.append(c)
    return ''.join(buffer)


def to_camel_case(snake_str: str) -> str:
    """
    下划线写法改驼峰写法
    """
    components = snake_str.split('_')
    return ''.join([item if index == 0 else item.capitalize() for index, item in enumerate(components)])


def change_keys(source_dict: dict, trans_key: dict, delete_old=True):
    """
    将一个dict里面的某些字段改名，需要改名的字段使用{old_key: new_key}的格式传入
    """
    for key in list(source_dict.keys()):
        if key in trans_key:
            source_dict[trans_key[key]] = source_dict[key]
            if delete_old:
                del source_dict[key]


def cal_next_day(*, days: int = 1) -> str:
    """
    计算几天后的日期
    """
    return_time = datetime.datetime.now()
    if days:
        return_time = return_time + datetime.timedelta(days=days)

    return return_time.strftime('%Y-%m-%d %H:%M:%S')


def get_fk_name(_dict: dict, _key: str, field_name='name') -> str:
    # 获取某个dict里面某个外键字段的name，这个字段一般为dict，往往写作{"id":xxx, "name":xxx}
    value = _dict.get(_key, None)
    if isinstance(value, dict):
        return value.get(field_name, '')
    return ''


def filter_by_array(val: Any, _list: List, index: int = 0):
    """
    检查一个变量是否在列表中，如果不在则返回默认值
    """
    if val not in _list:
        if not 0 <= index < len(_list):
            return None
        return _list[index]
    return val


def check_data_type(dest_data: Union[dict, list, tuple], source_data: Union[dict, list, tuple], *,
                    overwrite: bool = False, prefix:List=None) -> (bool, str):
    _type1 = type(dest_data)
    _type2 = type(source_data)

    if not is_type_equal(_type1, _type2):
        return False

    flag = True

    if _type1 == dict:
        for key, value in dest_data.items():
            if key in source_data:
                _type1 = type(value)
                _type2 = type(source_data[key])
                if _type1 in (list, tuple, dict) and _type2 in (list, tuple, dict):
                    _flag = is_type_equal(_type1, _type2)
                    if not _flag:
                        flag = False
                    else:
                        flag = check_data_type(value, source_data[key], overwrite=overwrite, prefix=prefix + key)
                elif _type1 in (list, tuple, dict) or _type2 in (list, tuple, dict):
                    flag = False
                else:
                    if _type1 != _type2:
                        if overwrite:
                            if _type2 == bool:
                                if str(value).lower() in ('false', '0'):
                                    value = False
                                else:
                                    value = bool(value)
                            try:
                                dest_data[key] = _type2(value)
                            except:
                                flag = False
                        else:
                            flag = False
                if not flag:
                    return False, f"格式错误：{':'.join(prefix+key)}"

    return flag

def is_type_equal(_type1, _type2)->bool:
    """
    判断复合类型是否相等，考虑list，tuple的区别
    """
    if _type1 == _type2:
        return True

    if _type1 in (list, tuple) and _type2 in (list, tuple):
        return True

    return False


def trans_key(data:dict, _type:str):
    """
    驼峰和下划线写法修改
    """
    func = to_camel_case if _type == 'camel' else to_snake_case
    keys = list(data.keys())
    for key in keys:
        _key = func(key)
        if key != _key:
            data[_key] = data[key]
            del data[key]
        if isinstance(data[_key], dict):
            trans_key(data[_key], _type)
        elif isinstance(data[_key], (tuple, list, set)):
            for item in data[_key]:
                if isinstance(item, dict):
                    trans_key(item, _type)

    return data


def trans_str_to_arr(input_str:str, split_char:str=','):
    """
    字符串转为数组，一般用于数据库检索出来的内容转换
    """
    try:
        return json.loads(input_str)
    except Exception:
        return input_str.split(split_char)


def read_yaml_file(file_name: str) -> dict:
    """
    从 YAML 文件中读取配置
    """
    if not os.path.exists(file_name):
        return {}

    with open(file_name, 'r', encoding='utf-8') as file:
        try:
            return yaml.safe_load(file)
        except yaml.YAMLError:
            return {}


def write_yaml_file(data: dict, file_name: str):
    """
    将配置写入 YAML 文件
    """
    if not data:
        return

    dir_name = os.path.dirname(file_name)
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)

    with open(file_name, 'w', encoding='utf-8') as file:
        yaml.dump(data, file, default_flow_style=False, allow_unicode=True)