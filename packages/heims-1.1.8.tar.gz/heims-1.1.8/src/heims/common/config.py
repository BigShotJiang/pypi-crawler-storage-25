import os

BASE_INFO = {
    'base_dir': os.getcwd(),
    'secret_key': '',
    'is_camel_case': False,
    'token_name': 'Authorization',
    "check_page_permission": True,
    "datetime_format": "%Y-%m-%d %H:%M:%S",
    "date_format": "%Y-%m-%d",
    "time_format": "%H:%M:%S",
    "create_time_field": "create_time",
    "update_time_field": "update_time",
    "create_user_field": "create_id",
    "update_user_field": "update_id",
    "user_tables": {
        "user": "user",
        "user_table_fk": "id",
        "user_role": "sys_user_role",
        "role_permission": "role_permission",
        "user_department": "user_department",
        "menu": "sys_menu",
        "role_menu": "sys_role_menu",
        "report_to": {
            "table": "user",
            "parent_field": "report_to",
            "child_field": "id",
        }
    },
    "admin_role_id": -1,
    "auth_token_expire_time": 3600,
}

ERROR_INFO = {
    "no_login": {
        "code": 60001,
        "msg": "您尚未登录或长时间未操作已被踢出"
    },
    "no_permission": {
        "code": 60002,
        "msg": "您无权访问该页面"
    },
    "code_error": {
        "code": 61001,
        "msg": "验证码错误"
    },
    "code_expired": {
        "code": 61002,
        "msg": "验证码已过期"
    },
    "code_used": {
        "code": 61003,
        "msg": "验证码已被使用"
    },
    "user_disabled": {
        "code": 62001,
        "msg": "用户已被禁用",
    },
    "user_not_exist": {
        "code": 62002,
        "msg": "用户不存在",
    },
    "system_error": {
        "code": 500,
        "msg": "未知错误"
    }
}

MYSQL_INFO = {
    "ssh_host": "",
    "ssh_port": 22,
    "ssh_username": "",
    "ssh_password": "",
    "ssh_private_key": "",
    "ssh_private_key_password": "",

    "mysql_host": "localhost",
    "mysql_port": 3306,
    "mysql_user": "",
    "mysql_password": "",
    "mysql_database": "",

    "pool_size": 5,
    "max_overflow": 10,
    "pool_recycle": 3600,
    "charset": "utf8mb4",
    "use_unicode": True
}

REDIS_INFO = {
    "ssh_host": "",
    "ssh_port": 22,
    "ssh_username": "",
    "ssh_password": "",
    "ssh_private_key": "",
    "ssh_private_key_password": "",

    # Redis配置,
    "redis_host": "localhost",
    "redis_port": 6379,
    "redis_password": "",
    "redis_db": 0,

    # 连接池配置,
    "max_connections": 50,
    "socket_timeout": 5,
    "socket_connect_timeout": 5,
    "socket_keepalive": True,

    # 高级配置,
    "use_cluster": False,
    "cluster_nodes": [],
    "use_sentinel": False,
    "sentinel_master": "my_master",
    "sentinel_nodes": [],

    # 序列化配置,
    "serializer": "json",
    "compress": False,
    "compress_threshold": 1024,

    # 性能优化,
    "retry_on_timeout": True,
    "retry_on_error": [],
    "health_check_interval": 80,
    "decode_responses": True,
    "encoding": "utf-8"
}

WECHAT_INFO = {
    "applet": {},
    "public_account": {}
}


__all__ = ['BASE_INFO', 'MYSQL_INFO', "REDIS_INFO", "WECHAT_INFO"]
