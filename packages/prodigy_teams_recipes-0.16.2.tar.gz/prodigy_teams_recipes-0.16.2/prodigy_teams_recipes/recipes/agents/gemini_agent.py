"""Gemini annotation agent recipe."""

from prodigy_teams_recipes_sdk import (
    Annotator,
    FloatProps,
    IntProps,
    Secret,
    TextProps,
    agent_recipe,
    detect_task_type,
    format_prompt,
    parse_response,
)

from .llm import Gemini, LLMError


@agent_recipe(
    title="Gemini Annotation Agent",
    description="Autonomous annotation agent powered by Google Gemini",
    field_props={
        "model": TextProps(title="Gemini model name"),
        "poll_interval": FloatProps(title="Poll interval (seconds)", min=0.1),
        "idle_shutdown_seconds": FloatProps(
            title="Idle shutdown (seconds)",
            min=0.0,
            description="Idle timeout before the agent exits (0 = keep running).",
        ),
        "thinking_budget": IntProps(title="Thinking token budget (0 = off)", min=0),
    },
)
def gemini_agent(
    *,
    api_key: Secret,
    model: str = "gemini-2.0-flash",
    poll_interval: float = 1.0,
    idle_shutdown_seconds: float = 0.0,
    thinking_budget: int = 0,
) -> Annotator:
    gemini_key = api_key.get_secret_value("GEMINI_API_KEY")
    llm = Gemini(api_key=gemini_key, model_name=model, thinking=thinking_budget)

    async def annotate(task: dict, config: dict) -> dict:
        task_type = detect_task_type(task)
        prompt = format_prompt(task, task_type, config)
        try:
            raw = await llm.ask(prompt)
        except LLMError:
            return {**task, "answer": "ignore"}
        return parse_response(raw, task, task_type, model_name=llm.model_name)

    return annotate
