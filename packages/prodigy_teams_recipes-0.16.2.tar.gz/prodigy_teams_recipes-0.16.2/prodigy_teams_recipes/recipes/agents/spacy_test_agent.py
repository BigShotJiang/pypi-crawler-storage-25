"""Deterministic local agent recipe for tests and development."""

import logging
from typing import Any

import spacy

from prodigy_teams_recipes_sdk import Annotator, FloatProps, TextProps, agent_recipe

logger = logging.getLogger(__name__)

DEFAULT_MODEL_NAME = "spacy-test-agent"
DEFAULT_PATTERNS = [
    {"label": "PERSON", "pattern": "Barack Obama"},
    {"label": "PERSON", "pattern": "Jane Doe"},
    {"label": "PERSON", "pattern": "Taylor Swift"},
    {"label": "PERSON", "pattern": "Alice Johnson"},
    {"label": "ORG", "pattern": "Microsoft"},
    {"label": "ORG", "pattern": "Apple"},
    {"label": "ORG", "pattern": "Amazon"},
    {"label": "ORG", "pattern": "Spotify"},
    {"label": "ORG", "pattern": "Google"},
    {"label": "ORG", "pattern": "Meta"},
    {"label": "GPE", "pattern": "Seattle"},
    {"label": "GPE", "pattern": "New York"},
    {"label": "GPE", "pattern": "London"},
    {"label": "GPE", "pattern": "Los Angeles"},
    {"label": "GPE", "pattern": "Paris"},
    {"label": "GPE", "pattern": "Berlin"},
    {"label": "MONEY", "pattern": [{"TEXT": "$"}, {"LIKE_NUM": True}]},
]


@agent_recipe(
    title="spaCy Test Agent",
    description="Deterministic local annotation agent for tests and development",
    field_props={
        "model": TextProps(
            title="spaCy model name",
            description="Optional installed spaCy model to load before adding rules",
        ),
        "poll_interval": FloatProps(title="Poll interval (seconds)", min=0.1),
        "idle_shutdown_seconds": FloatProps(
            title="Idle shutdown (seconds)",
            min=0.0,
            description="Idle timeout before the agent exits (0 = keep running).",
        ),
    },
)
def spacy_test_agent(
    *,
    model: str = "",
    poll_interval: float = 0.25,
    idle_shutdown_seconds: float = 0.0,
) -> Annotator:
    annotator_id = model or DEFAULT_MODEL_NAME
    nlp = make_test_nlp(model)

    def annotate(task: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
        return annotate_task(task, config, nlp=nlp, annotator_id=annotator_id)

    return annotate


def make_test_nlp(model: str = ""):
    if model:
        try:
            nlp = spacy.load(model)
        except OSError:
            logger.warning(
                "Could not load spaCy model %r, falling back to blank 'en'", model
            )
            nlp = spacy.blank("en")
    else:
        nlp = spacy.blank("en")
    if "entity_ruler" in nlp.pipe_names:
        ruler = nlp.get_pipe("entity_ruler")
    else:
        ruler = nlp.add_pipe("entity_ruler", config={"overwrite_ents": True})
    ruler.add_patterns(DEFAULT_PATTERNS)  # type: ignore
    return nlp


def annotate_task(
    task: dict[str, Any],
    config: dict[str, Any],
    *,
    nlp,
    annotator_id: str = DEFAULT_MODEL_NAME,
) -> dict[str, Any]:
    labels = {
        str(label)
        for label in config.get("labels", [])
        if isinstance(label, str) and label
    }
    result = {
        **task,
        "_annotator_id": annotator_id,
        "_session_id": annotator_id,
    }
    text = task.get("text")
    tokens = task.get("tokens")
    if not isinstance(text, str) or not isinstance(tokens, list):
        result["answer"] = "ignore"
        return result

    spans = [
        span
        for ent in nlp(text).ents
        if (not labels or ent.label_ in labels)
        if (
            span := _doc_ent_to_task_span(
                tokens, ent.start_char, ent.end_char, ent.label_
            )
        )
    ]
    if spans:
        result["spans"] = _dedupe_spans(spans)
        result["answer"] = "accept"
    else:
        result["spans"] = []
        result["answer"] = "ignore"
    return result


def _doc_ent_to_task_span(
    tokens: list[dict[str, Any]],
    start: int,
    end: int,
    label: str,
) -> dict[str, Any] | None:
    overlapping = [
        token
        for token in tokens
        if int(token["start"]) < end and int(token["end"]) > start
    ]
    if not overlapping:
        return None
    return {
        "start": start,
        "end": end,
        "token_start": overlapping[0]["id"],
        "token_end": overlapping[-1]["id"],
        "label": label,
    }


def _dedupe_spans(spans: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple[int, int, str]] = set()
    unique: list[dict[str, Any]] = []
    for span in sorted(
        spans, key=lambda item: (item["start"], item["end"], item["label"])
    ):
        key = (int(span["start"]), int(span["end"]), str(span["label"]))
        if key in seen:
            continue
        seen.add(key)
        unique.append(span)
    return unique
