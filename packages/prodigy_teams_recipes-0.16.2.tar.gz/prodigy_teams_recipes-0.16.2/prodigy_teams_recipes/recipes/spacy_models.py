import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin

import httpx
import spacy
import spacy.about
from cloudpathlib import AnyPath, CloudPath
from prodigy.util import msg

import prodigy_teams_pam_sdk.models as pam_models
from prodigy_teams_pam_sdk.client.full_client import Client
from prodigy_teams_pam_sdk.errors import ProdigyTeamsError
from prodigy_teams_pam_sdk.recipe_client import Settings
from prodigy_teams_recipes_sdk import (
    BoolProps,
    Lang,
    ListProps,
    TextProps,
    action_recipe,
    props,
    resolve_remote_path,
)
from prodigy_teams_recipes_sdk import __version__ as pt_recipes_sdk_version


def _get_compatibility(custom_url: Optional[str] = None) -> dict:
    """Fetch the spaCy model compatibility table for the current spaCy version."""
    from spacy import about
    from spacy.util import get_minor_version, is_prerelease_version

    if is_prerelease_version(about.__version__):
        version: Optional[str] = about.__version__
    else:
        version = get_minor_version(about.__version__)
    compat_url = (
        custom_url.rstrip("/") + "/compatibility.json"
        if custom_url
        else about.__compatibility__
    )
    r = httpx.get(compat_url)
    if r.status_code != 200:
        msg.fail(
            f"Server error ({r.status_code})",
            f"Couldn't fetch compatibility table from {compat_url}.",
            exits=1,
        )
    comp_table = r.json()
    comp = comp_table["spacy"]
    if version not in comp:
        msg.fail(f"No compatible packages found for v{version} of spaCy", exits=1)
    return comp[version]


def _list_models_for_lang(lang: str, compatibility: dict) -> list[str]:
    """Return all model names matching the given language code."""
    prefix = f"{lang}_"
    return sorted(name for name in compatibility if name.startswith(prefix))


def _download_model_to_dir(
    model_name: str,
    version: str,
    dest_dir: Path,
    custom_url: Optional[str] = None,
) -> Path:
    """Download a spaCy model wheel and extract it into dest_dir.

    Returns the path to the extracted model directory inside dest_dir
    (i.e. dest_dir / model_name / model_name-version).
    """
    from spacy import about

    suffix = "-py3-none-any.whl"
    filename = f"{model_name}-{version}/{model_name}-{version}{suffix}"
    base_url = custom_url if custom_url else about.__download_url__
    if not base_url.endswith("/"):
        base_url = base_url + "/"
    download_url = urljoin(base_url, filename)

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        # Download and install to a temporary target so we can copy just the
        # model data directory without polluting the worker's site-packages.
        msg.info(f"Downloading {model_name}-{version} from {download_url}")
        subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--no-deps",
                "--target",
                str(tmp_path),
                download_url,
            ],
            check=True,
        )
        # The installed package puts the model data inside
        # <model_name>/<model_name>-<version>
        installed = tmp_path / model_name / f"{model_name}-{version}"
        if not installed.exists():
            # Fallback: look for any directory matching the model name
            candidates = list(tmp_path.glob(f"{model_name}*/{model_name}*"))
            if candidates:
                installed = candidates[0]
            else:
                msg.fail(
                    f"Could not locate model data for {model_name} after install",
                    exits=1,
                )

        # Verify the model loads
        nlp = spacy.load(installed)
        msg.good(
            f"Verified {model_name}-{version} ({nlp.lang}, "
            f"{len(nlp.pipe_names)} components: {', '.join(nlp.pipe_names)})"
        )

        # Copy to the final destination
        final_dest = dest_dir / model_name
        if final_dest.exists():
            shutil.rmtree(final_dest)
        shutil.copytree(installed, final_dest)

    return final_dest


@action_recipe(
    title="Download spaCy models",
    description=(
        "Download and install one or more spaCy models to shared storage "
        "so they can be loaded with spacy.load()"
    ),
    field_props={
        # fmt: off
        "lang": props.lang,
        "models": ListProps(
            title="Model name(s)",
            description="Specific model names to download (e.g. en_core_web_sm). Leave empty and enable 'all models' to download all models for the language.",
            exists=False,
            min=0,
        ),
        "all_models": BoolProps(
            title="Download all models for the language",
            description="If enabled, downloads every available model for the selected language. Overrides the model name(s) list.",
        ),
        "output_path": TextProps(
            title="Output path",
            description="Path on shared storage where models will be saved. Supports {__nfs__} paths. Each model is placed in a subdirectory named after the model.",
        ),
        "source_url": TextProps(
            title="Source repository URL",
            description="Custom URL to download models from. Leave empty to use the default spaCy GitHub releases.",
        ),
        "register": BoolProps(
            title="Register models as assets",
            description="Register each downloaded model as an asset in Prodigy Teams.",
        ),
        # fmt: on
    },
    cli_names={"lang": "lang"},
)
def download_spacy_models(
    *,
    lang: Lang,  # type: ignore[reportInvalidTypeForm]
    models: Optional[list[str]] = None,
    all_models: bool = False,
    output_path: str = "{__nfs__}/spacy-models",
    source_url: Optional[str] = None,
    register: bool = True,
) -> None:
    """Download spaCy models for a language and place them on shared storage.

    Models are saved to subdirectories under the output path, named after each
    model (e.g. {__nfs__}/spacy-models/en_core_web_sm). They can then be loaded
    with spacy.load() pointing at that directory.
    """
    lang_code = lang if isinstance(lang, str) else lang.value
    compatibility = _get_compatibility(source_url)

    # Determine which models to download
    if all_models:
        model_names = _list_models_for_lang(lang_code, compatibility)
        if not model_names:
            msg.fail(
                f"No models found for language '{lang_code}' in compatibility table",
                exits=1,
            )
        msg.info(
            f"Found {len(model_names)} model(s) for '{lang_code}': "
            f"{', '.join(model_names)}"
        )
    elif models:
        model_names = models
    else:
        msg.fail(
            "No models specified. Provide model name(s) or enable 'all models'.",
            exits=1,
        )
        return  # unreachable, but keeps the type checker happy

    # Validate all requested models exist in the compatibility table
    for name in model_names:
        if name not in compatibility:
            msg.fail(
                f"Model '{name}' not found in compatibility table "
                f"for spaCy v{spacy.about.__version__}",
                exits=1,
            )

    # Resolve the output path
    cfg = Settings()
    if cfg.is_valid():
        assert cfg.broker_id
        pam_client = Client.from_job_token_sync(cfg.pam_host, cfg.job_token)
        resolved_output = resolve_remote_path(pam_client, output_path, cfg.broker_id)
    else:
        # Local execution (e.g. during development/testing)
        pam_client = None
        resolved_output = output_path
        msg.warn(
            "Prodigy Teams client settings not available. "
            "Writing to local path and skipping asset registration."
        )

    dest_root = AnyPath(resolved_output)
    if isinstance(dest_root, CloudPath):
        dest_root.mkdir(parents=True, exist_ok=True)
    else:
        assert isinstance(dest_root, Path)
        dest_root.mkdir(parents=True, exist_ok=True)

    msg.divider(f"Downloading {len(model_names)} model(s)")

    downloaded = []
    for model_name in model_names:
        version = compatibility[model_name][0]
        msg.divider(f"{model_name}-{version}")

        with tempfile.TemporaryDirectory() as staging:
            staging_path = Path(staging)
            local_model = _download_model_to_dir(
                model_name, version, staging_path, source_url
            )

            # Upload to final destination
            model_dest = dest_root / model_name
            if isinstance(model_dest, CloudPath):
                model_dest.upload_from(local_model, force_overwrite_to_cloud=True)
            else:
                assert isinstance(model_dest, Path)
                if model_dest.exists():
                    shutil.rmtree(model_dest)
                shutil.copytree(local_model, model_dest)

            msg.good(f"Saved {model_name} to {output_path}/{model_name}")
            downloaded.append((model_name, version))

    # Register assets in PAM
    if register and pam_client is not None and cfg.is_valid():
        assert cfg.broker_id
        msg.divider("Registering assets")
        for model_name, version in downloaded:
            model_path = f"{output_path}/{model_name}"
            body = pam_models.AssetCreating(
                broker_id=cfg.broker_id,
                name=model_name,
                version=version,
                path=model_path,
                kind="model",
                meta={
                    "spacy_version": spacy.about.__version__,
                    "prodigy_teams_recipes_sdk_version": pt_recipes_sdk_version,
                },
            )
            try:
                pam_client.asset.create(body)
            except ProdigyTeamsError as e:
                msg.fail(f"Failed to register {model_name} as asset.", e, exits=1)
            except httpx.HTTPStatusError as e:
                msg.fail(
                    f"Unexpected error registering {model_name} as asset.",
                    e,
                    exits=1,
                )
            else:
                msg.good(f"Registered {model_name} (v{version}) as asset")

    msg.divider("Summary")
    msg.good(f"Downloaded {len(downloaded)} model(s):")
    for model_name, version in downloaded:
        msg.text(f"  {model_name}-{version} → {output_path}/{model_name}")
    msg.info("Load models with: spacy.load('{output_path}/{model_name}')")
