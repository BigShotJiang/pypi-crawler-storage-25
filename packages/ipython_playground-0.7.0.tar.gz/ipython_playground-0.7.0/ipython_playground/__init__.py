import importlib.metadata
import inspect
import logging
import sys
from pathlib import Path
from typing import Any, get_type_hints

from rich.console import Console
from rich.text import Text

from ipython_playground.create import create_playground_file

from . import extras
from .version import __version__ as __version__


def _format_signature(obj: Any) -> str:
    try:
        sig = str(inspect.signature(obj.__init__ if inspect.isclass(obj) else obj))
        if sig in (
            "(self, *args, **kwargs)",
            "(self, /, *args, **kwargs)",
            "(self, *args)",
            "(__pydantic_self__, **data: Any) -> None",
            "(__pydantic_self__, **data: 'Any') -> 'None'",
        ):
            return ""
        return sig
    except (TypeError, ValueError):
        return ""


def output():
    """Display relevant custom functions and variables with minimal formatting"""

    console = Console()
    width = console.width
    frame = inspect.currentframe()
    calling_frame = frame.f_back  # type: ignore
    current_module = (
        calling_frame.f_globals if calling_frame else frame.f_globals  # type: ignore
    )  # type: ignore

    # Make sure to delete the references to avoid reference cycles
    del frame
    del calling_frame

    ipython_path = Path.home() / ".ipython"
    builtin_modules = {
        "os",
        "sys",
        "json",
        "tempfile",
        "subprocess",
        "importlib",
        "pkgutil",
        "ipython_playground",
    }
    exclude_vars = {"In", "Out", "PIPE", "get_ipython", "exit", "quit", "c"}
    exclude_classes = {"Popen"}

    def truncate_text(text: str, max_width: int) -> str:
        if len(text) > max_width:
            return text[: max_width - 3] + "..."
        return text

    def get_module_info(module) -> str:
        # Get path
        path = ""
        if hasattr(module, "__path__") and module.__path__:
            path = module.__path__[0]
        elif hasattr(module, "__file__"):
            path = module.__file__

        if path:
            try:
                cwd = Path.cwd()
                abs_path = Path(path).resolve()
                if abs_path.is_relative_to(cwd):
                    path = str(abs_path.relative_to(cwd))
            except (ValueError, OSError):
                pass

        # Get version
        v = None
        # Try modern way first (metadata)
        pkg_name = module.__name__.split(".")[0]
        try:
            v = importlib.metadata.version(pkg_name)
        except (importlib.metadata.PackageNotFoundError, AttributeError, ValueError):
            # Fallback to __version__ attribute
            v = getattr(module, "__version__", None)

        if v and v != "unknown version":
            return f"{module.__name__} ({v}) from {path}"
        return f"{module.__name__} from {path}"

    # Functions Section
    console.print("\n[bold blue]Custom Functions[/bold blue]")
    console.print("─" * width)

    for name, obj in current_module.items():
        if (
            inspect.isfunction(obj) and not name.startswith("_")
            # and obj.__module__ == "__main__"
        ):
            # Get the source file of the function
            try:
                source_file = Path(inspect.getfile(obj))
                # Skip if function is from .ipython directory
                if ipython_path in source_file.parents:
                    continue
            except (TypeError, ValueError):
                continue

            sig = _format_signature(obj)

            try:
                return_type = get_type_hints(obj).get("return", None)
                if return_type:
                    sig += f" -> {return_type.__name__}"
            except NameError:
                # This happens if the object was created with a class (like Engine) that was imported and used, but the
                # symbol Engine is not present in the current module's namespace—maybe it was imported in another module,
                # or imported and then deleted, or only referenced as a string in type hints. The object still has the
                # correct type, but get_type_hints can't resolve the name unless Engine is available in the current globalns.
                pass

            text = Text()
            text.append(f"{name:<30}", style="cyan bold")
            text.append(truncate_text(sig, width - 30), style="green")
            console.print(text)

    # Classes Section
    console.print("\n[bold blue]Classes[/bold blue]")
    console.print("─" * width)

    for name, obj in current_module.items():
        if (
            inspect.isclass(obj)
            and not name.startswith("_")
            and name not in exclude_classes
        ):
            sig = _format_signature(obj)
            text = Text()
            text.append(f"{name:<30}", style="cyan bold")
            text.append(truncate_text(sig, width - 30), style="green")
            console.print(text)

    # Modules Section
    console.print("\n[bold blue]Imported Modules[/bold blue]")
    console.print("─" * width)

    for name, obj in current_module.items():
        if (
            inspect.ismodule(obj)
            and not name.startswith("_")
            and name not in builtin_modules
            and name not in exclude_vars
        ):
            text = Text()
            text.append(f"{name:<30}", style="cyan bold")
            text.append(truncate_text(get_module_info(obj), width - 30), style="yellow")
            console.print(text)

    # Variables Section
    console.print("\n[bold blue]Variables[/bold blue]")
    console.print("─" * width)

    for name, obj in current_module.items():
        if (
            not inspect.isfunction(obj)
            and not inspect.ismodule(obj)
            and not inspect.isclass(obj)
            and not name.startswith("_")
            and name not in builtin_modules
            and name not in exclude_vars
        ):
            type_info = type(obj).__name__
            if hasattr(obj, "__annotations__"):
                annotations = getattr(obj, "__annotations__", {})
                if annotations:
                    type_info += f" [{', '.join(str(v) for v in annotations.values())}]"
            text = Text()
            text.append(f"{name:<30}", style="cyan bold")
            text.append(truncate_text(type_info, width - 30), style="green")
            console.print(text)


def all_extras(**kwargs):
    return extras.all(**kwargs)


log = logging.getLogger(__name__)


def main():
    """
    Creates a playground file for IPython.

    This creates a new playground file with the necessary boilerplate
    for interactive Python development.

    Options:
        --help     Show this help message and exit

    For more detailed information, please refer to the README at:
    https://github.com/yourusername/ipython_playground
    """

    if len(sys.argv) > 1 and sys.argv[1] == "--help":
        print(main.__doc__)
        return

    create_playground_file()
