from __future__ import annotations

from pathlib import Path

from .history import build_history_selection
import subprocess
import sys
from .troubleshooting import confidence_troubleshooting_steps


ONLINE_STEPS = (
    "Check the output folder and saved PipeWire targets.",
    "Playback target = the DAC, headphones, speakers, or interface output that should play the sweep.",
    "Capture target = the mic, recorder, or interface input that should hear it.",
    "If you are unsure, run 'headmatch list-targets' first and paste the exact node names.",
    "Press Start when your rig is ready.",
    "HeadMatch runs the shared online pipeline and then shows the output folder.",
)


OFFLINE_STEPS = (
    "Write a sweep package if you need to record with a handheld recorder first.",
    "After recording, point the GUI at the WAV file and run the offline fit.",
    "Both actions reuse the shared sweep and fitting pipeline.",
)



SECTION_PAD = 12
FIELD_PAD_Y = 3
BODY_WRAP = 560
DETAIL_WRAP = 520
COMPARISON_WRAP = 240


def add_readonly_row(ttk, parent, row: int, label: str, variable) -> None:
    ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=FIELD_PAD_Y)
    entry = ttk.Entry(parent, textvariable=variable)
    entry.state(["readonly"])
    entry.grid(row=row, column=1, sticky="ew", pady=FIELD_PAD_Y)


def add_combobox_row(ttk, parent, row: int, label: str, variable, values: tuple[str, ...], *, empty_label: str) -> None:
    ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=FIELD_PAD_Y)
    state = "readonly" if values else "normal"
    combo = ttk.Combobox(parent, textvariable=variable, values=values, state=state)
    combo.grid(row=row, column=1, sticky="ew", pady=FIELD_PAD_Y)
    if not values and not variable.get().strip():
        combo.set("")


def add_entry_row(ttk, parent, row: int, label: str, variable) -> None:
    ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=FIELD_PAD_Y)
    ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=FIELD_PAD_Y)


def add_picker_row(ttk, parent, row: int, label: str, variable, *, button_text: str, command) -> None:
    ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=FIELD_PAD_Y)
    entry_frame = ttk.Frame(parent)
    entry_frame.grid(row=row, column=1, sticky="ew", pady=FIELD_PAD_Y)
    entry_frame.columnconfigure(0, weight=1)
    ttk.Entry(entry_frame, textvariable=variable).grid(row=0, column=0, sticky="ew")
    ttk.Button(entry_frame, text=button_text, command=command).grid(row=0, column=1, sticky="w", padx=(8, 0))


def render_online_wizard(ttk, frame, *, variables, on_start) -> None:
    ttk.Label(frame, text="Online measurement wizard", style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(
        frame,
        text="Use this when PipeWire playback and capture are available now. Choose the output that should play the sweep and the input that should hear it.",
        wraplength=BODY_WRAP,
        justify="left",
    ).grid(row=1, column=0, sticky="w", pady=(8, 12))
    steps = ttk.LabelFrame(frame, text="What happens", padding=SECTION_PAD)
    steps.grid(row=2, column=0, sticky="ew")
    for idx, step in enumerate(ONLINE_STEPS):
        ttk.Label(steps, text=f"{idx + 1}. {step}", wraplength=DETAIL_WRAP, justify="left").grid(row=idx, column=0, sticky="w", pady=2)

    form = ttk.LabelFrame(frame, text="Run details", padding=SECTION_PAD)
    form.grid(row=3, column=0, sticky="ew", pady=(12, 0))
    form.columnconfigure(1, weight=1)
    add_picker_row(ttk, form, 0, "Output folder", variables.output_dir_var, button_text="Browse…", command=variables.choose_output_dir)
    add_combobox_row(ttk, form, 1, "Playback target", variables.output_target_var, variables.output_target_options, empty_label="No playback targets found")
    add_combobox_row(ttk, form, 2, "Capture target", variables.input_target_var, variables.input_target_options, empty_label="No capture targets found")
    add_picker_row(ttk, form, 3, "Target CSV (optional)", variables.target_csv_var, button_text="Browse…", command=variables.choose_target_csv)
    add_entry_row(ttk, form, 4, "Iterations", variables.iterations_var)
    add_entry_row(ttk, form, 5, "Max PEQ filters", variables.max_filters_var)
    add_combobox_row(ttk, form, 6, "Iteration mode", variables.iteration_mode_var, ("independent", "average"), empty_label="")

    actions = ttk.Frame(frame, padding=(0, 12, 0, 0))
    actions.grid(row=4, column=0, sticky="w")
    ttk.Button(actions, text="Start guided measurement", command=on_start).grid(row=0, column=0, sticky="w")
    ttk.Label(
        actions,
        text="Rig ready and room quiet. Need a quick check? Run 'headmatch doctor'. Unsure about device names? Run 'headmatch list-targets'.",
        wraplength=DETAIL_WRAP,
        justify="left",
    ).grid(row=0, column=1, sticky="w", padx=(12, 0))


def render_setup_check(ttk, frame, *, report: str, on_refresh, on_measure) -> None:
    ttk.Label(frame, text="Setup check", style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(
        frame,
        text="Run a quick readiness check before your first measurement. This reuses the same beginner-friendly doctor report as the CLI.",
        wraplength=BODY_WRAP,
        justify="left",
    ).grid(row=1, column=0, sticky="w", pady=(8, 12))

    actions = ttk.Frame(frame)
    actions.grid(row=2, column=0, sticky="w")
    ttk.Button(actions, text="Refresh setup check", command=on_refresh).grid(row=0, column=0, sticky="w")
    ttk.Button(actions, text="Go to Measure", command=on_measure).grid(row=0, column=1, sticky="w", padx=(12, 0))

    # Desktop shortcut button
    from .desktop import shortcut_exists, create_shortcut, find_gui_binary
    gui = find_gui_binary()
    if gui:
        def _toggle_shortcut():
            try:
                if shortcut_exists():
                    from .desktop import remove_shortcut
                    remove_shortcut()
                else:
                    create_shortcut(gui)
            except Exception:
                pass
            on_refresh()
        shortcut_label = "Remove desktop shortcut" if shortcut_exists() else "Create desktop shortcut"
        ttk.Button(actions, text=shortcut_label, command=_toggle_shortcut).grid(row=0, column=2, sticky="w", padx=(12, 0))

    report_card = ttk.LabelFrame(frame, text="Readiness report", padding=SECTION_PAD)
    report_card.grid(row=3, column=0, sticky="nsew", pady=(12, 0))
    report_card.columnconfigure(0, weight=1)
    report_card.rowconfigure(0, weight=1)
    frame.rowconfigure(3, weight=1)
    try:
        import tkinter as tk
        text_widget = tk.Text(report_card, wrap="word", height=12, relief="flat", bg=report_card.cget("background") if hasattr(report_card, 'cget') else "#ffffff")
        text_widget.insert("1.0", report)
        text_widget.config(state="disabled")
        scrollbar = ttk.Scrollbar(report_card, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        text_widget.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
    except Exception:
        ttk.Label(report_card, text=report, wraplength=DETAIL_WRAP, justify="left").grid(row=0, column=0, sticky="w")


def render_offline_wizard(ttk, frame, *, variables, on_prepare, on_fit) -> None:
    ttk.Label(frame, text="Offline measurement wizard", style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(
        frame,
        text="Use this when a handheld recorder is more reliable than live capture. First write the sweep package, then fit the imported WAV.",
        wraplength=BODY_WRAP,
        justify="left",
    ).grid(row=1, column=0, sticky="w", pady=(8, 12))
    steps = ttk.LabelFrame(frame, text="What happens", padding=SECTION_PAD)
    steps.grid(row=2, column=0, sticky="ew")
    for idx, step in enumerate(OFFLINE_STEPS):
        ttk.Label(steps, text=f"{idx + 1}. {step}", wraplength=DETAIL_WRAP, justify="left").grid(row=idx, column=0, sticky="w", pady=2)

    prep = ttk.LabelFrame(frame, text="Step A — prepare the recorder package", padding=SECTION_PAD)
    prep.grid(row=3, column=0, sticky="ew", pady=(12, 0))
    prep.columnconfigure(1, weight=1)
    add_picker_row(ttk, prep, 0, "Package folder", variables.output_dir_var, button_text="Browse…", command=variables.choose_output_dir)
    add_entry_row(ttk, prep, 1, "Notes (optional)", variables.offline_notes_var)
    ttk.Button(prep, text="Write sweep package", command=on_prepare).grid(row=2, column=0, columnspan=2, sticky="w", pady=(8, 0))

    fit = ttk.LabelFrame(frame, text="Step B — fit an imported recording", padding=SECTION_PAD)
    fit.grid(row=4, column=0, sticky="ew", pady=(12, 0))
    fit.columnconfigure(1, weight=1)
    add_picker_row(ttk, fit, 0, "Recorded WAV", variables.offline_recording_var, button_text="Browse…", command=variables.choose_offline_recording)
    add_picker_row(ttk, fit, 1, "Fit output folder", variables.offline_fit_output_var, button_text="Browse…", command=variables.choose_offline_fit_output_dir)
    add_picker_row(ttk, fit, 2, "Target CSV (optional)", variables.target_csv_var, button_text="Browse…", command=variables.choose_target_csv)
    add_entry_row(ttk, fit, 3, "Max PEQ filters", variables.max_filters_var)
    ttk.Button(fit, text="Fit imported recording", command=on_fit).grid(row=4, column=0, columnspan=2, sticky="w", pady=(8, 0))


def render_progress(ttk, frame, *, title: str, body: str) -> None:
    ttk.Label(frame, text=title, style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(frame, text=body, wraplength=BODY_WRAP, justify="left").grid(row=1, column=0, sticky="w", pady=(8, 12))
    note = ttk.LabelFrame(frame, text="What to do now", padding=SECTION_PAD)
    note.grid(row=2, column=0, sticky="ew")
    ttk.Label(
        note,
        text="Keep this window open while the shared pipeline runs. This screen will switch to a completion summary when it finishes.",
        wraplength=DETAIL_WRAP,
        justify="left",
    ).grid(row=0, column=0, sticky="w")


def render_completion(ttk, frame, *, title: str, body: str, steps: tuple[str, ...], on_home, on_history) -> None:
    ttk.Label(frame, text=title, style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(frame, text=body, wraplength=BODY_WRAP, justify="left").grid(row=1, column=0, sticky="w", pady=(8, 12))
    card = ttk.LabelFrame(frame, text="Next steps", padding=SECTION_PAD)
    card.grid(row=2, column=0, sticky="ew")
    for idx, step in enumerate(steps):
        ttk.Label(card, text=f"- {step}", wraplength=DETAIL_WRAP, justify="left").grid(row=idx, column=0, sticky="w", pady=2)
    actions = ttk.Frame(frame, padding=(0, 12, 0, 0))
    actions.grid(row=3, column=0, sticky="w")
    ttk.Button(actions, text="Back to Measure", command=on_home).grid(row=0, column=0, sticky="w")
    ttk.Button(actions, text="Open Results", command=on_history).grid(row=0, column=1, sticky="w", padx=(12, 0))


def render_history(ttk, frame, *, history_root_var, config_path: Path):
    return build_history_selection(history_root_var.get(), config_path.parent)


_CONFIDENCE_BADGES = {
    'high': '✓',
    'medium': '⚠',
    'low': '✗',
}


def _confidence_display(label: str) -> str:
    return label.replace('_', ' ').title()


def _confidence_badge(label: str) -> str:
    badge = _CONFIDENCE_BADGES.get(label, '')
    return f"{badge} {_confidence_display(label)}" if badge else _confidence_display(label)


def render_history_results(ttk, frame, *, selection) -> None:
    if not selection.items:
        ttk.Label(
            frame,
            text=(
                f"No run_summary.json files were found under {selection.search_root}. "
                "Finish one run with the online or offline wizard, then refresh."
            ),
            wraplength=DETAIL_WRAP,
            justify="left",
        ).grid(row=3, column=0, sticky="w")
        return

    results = ttk.LabelFrame(frame, text="Recent runs", padding=SECTION_PAD)
    results.grid(row=3, column=0, sticky="nsew", pady=(12, 0))
    results.columnconfigure(0, weight=1)
    frame.rowconfigure(3, weight=1)

    for idx, entry in enumerate(selection.items):
        confidence = entry.summary.confidence
        ttk.Label(results, text=entry.summary.out_dir, style="Heading.TLabel").grid(row=idx * 3, column=0, sticky="w")
        ttk.Label(
            results,
            text=f"Confidence: {_confidence_badge(confidence.label)} ({confidence.score}/100) — {confidence.headline}",
            wraplength=DETAIL_WRAP,
            justify="left",
        ).grid(row=idx * 3 + 1, column=0, sticky="w")
        ttk.Label(
            results,
            text=f"{entry.summary.kind} | {entry.summary.target} | {entry.summary.sample_rate} Hz",
            wraplength=DETAIL_WRAP,
            justify="left",
        ).grid(row=idx * 3 + 2, column=0, sticky="w", pady=(0, 8))

    next_row = 4
    comparison = selection.comparison
    if comparison is not None:
        compare = ttk.LabelFrame(frame, text="Compare the two most recent runs", padding=SECTION_PAD)
        compare.grid(row=4, column=0, sticky="ew", pady=(12, 0))
        compare.columnconfigure(1, weight=1)
        compare.columnconfigure(2, weight=1)
        ttk.Label(compare, text="Field", style="Heading.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 12))
        ttk.Label(compare, text=comparison.left_entry.summary.out_dir, style="Heading.TLabel", wraplength=COMPARISON_WRAP, justify="left").grid(row=0, column=1, sticky="w", padx=(0, 12))
        ttk.Label(compare, text=comparison.right_entry.summary.out_dir, style="Heading.TLabel", wraplength=COMPARISON_WRAP, justify="left").grid(row=0, column=2, sticky="w")
        for idx, field in enumerate(comparison.fields, start=1):
            ttk.Label(compare, text=field.label, style="Heading.TLabel").grid(row=idx, column=0, sticky="nw", padx=(0, 12), pady=(6, 0))
            ttk.Label(compare, text=field.left, wraplength=COMPARISON_WRAP, justify="left").grid(row=idx, column=1, sticky="w", padx=(0, 12), pady=(6, 0))
            ttk.Label(compare, text=field.right, wraplength=COMPARISON_WRAP, justify="left").grid(row=idx, column=2, sticky="w", pady=(6, 0))
        next_row = 5

    guide = ttk.LabelFrame(frame, text="Selected run summary", padding=SECTION_PAD)
    guide.grid(row=next_row, column=0, sticky="ew", pady=(12, 0))
    guide.columnconfigure(0, weight=1)
    summary_text = selection.selected_summary or "No summary selected."
    ttk.Label(guide, text=f"Summary: {summary_text}", wraplength=DETAIL_WRAP, justify="left").grid(row=0, column=0, sticky="w")

    selected = selection.selected_entry
    if selected is not None:
        confidence = selected.summary.confidence
        ttk.Label(
            guide,
            text=f"Confidence: {_confidence_badge(confidence.label)} ({confidence.score}/100)",
            style="Heading.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Label(guide, text=confidence.headline, wraplength=DETAIL_WRAP, justify="left").grid(row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Label(guide, text=confidence.interpretation, wraplength=DETAIL_WRAP, justify="left").grid(row=3, column=0, sticky="w", pady=(4, 0))
        row = 4
        if confidence.warnings:
            ttk.Label(guide, text="Warnings", style="Heading.TLabel").grid(row=row, column=0, sticky="w", pady=(8, 0))
            row += 1
            for warning in confidence.warnings[:3]:
                ttk.Label(guide, text=f"- {warning}", wraplength=DETAIL_WRAP, justify="left").grid(row=row, column=0, sticky="w", pady=(2, 0))
                row += 1
        steps = confidence_troubleshooting_steps(confidence)
        if steps:
            ttk.Label(guide, text="What to try next", style="Heading.TLabel").grid(row=row, column=0, sticky="w", pady=(8, 0))
            row += 1
            for step in steps:
                ttk.Label(guide, text=f"- {step}", wraplength=DETAIL_WRAP, justify="left").grid(row=row, column=0, sticky="w", pady=(2, 0))
                row += 1
        ttk.Label(guide, text=selection.selected_guide or "", wraplength=DETAIL_WRAP, justify="left").grid(row=row, column=0, sticky="w", pady=(10, 0))
        row += 1
        # TASK-066: Graph display button
        import os
        overview_svg = os.path.join(selected.summary.out_dir, 'fit_overview.svg')
        if os.path.isfile(overview_svg):
            def _open_graph(path=overview_svg):
                try:
                    if sys.platform == 'linux':
                        subprocess.Popen(['xdg-open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    elif sys.platform == 'darwin':
                        subprocess.Popen(['open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    elif sys.platform == 'win32':
                        import os as _os
                        _os.startfile(path)
                except OSError:
                    pass
            ttk.Button(guide, text="Open fit graph", command=_open_graph).grid(row=row, column=0, sticky="w", pady=(8, 0))
        else:
            ttk.Label(guide, text="Graph not available.", wraplength=DETAIL_WRAP, justify="left").grid(row=row, column=0, sticky="w", pady=(8, 0))


def render_target_editor(ttk, frame, *, editor, on_save, on_reset, on_load=None, on_update=None):
    """Render an interactive target curve editor with editable control points."""
    import tkinter as tk

    ttk.Label(frame, text="Target curve editor", style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(
        frame,
        text="Edit control points to shape your target curve. The curve is smoothly interpolated between points using PCHIP.",
        wraplength=BODY_WRAP,
        justify="left",
    ).grid(row=1, column=0, sticky="w", pady=(8, 12))

    points_frame = ttk.LabelFrame(frame, text="Control points", padding=SECTION_PAD)
    points_frame.grid(row=2, column=0, sticky="nsew", pady=(0, 12))
    points_frame.columnconfigure(1, weight=1)
    frame.rowconfigure(2, weight=1)

    # Header
    ttk.Label(points_frame, text="Freq (Hz)", style="Heading.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8))
    ttk.Label(points_frame, text="Gain (dB)", style="Heading.TLabel").grid(row=0, column=1, sticky="w", padx=(0, 8))

    freq_vars = []
    gain_vars = []

    def _apply_changes():
        """Read all fields back into the editor model."""
        for i, (fv, gv) in enumerate(zip(freq_vars, gain_vars)):
            try:
                freq = float(fv.get())
                gain = float(gv.get())
                if i < len(editor.points):
                    editor.move_point(i, max(20.0, min(20000.0, freq)), max(-20.0, min(20.0, gain)))
            except (ValueError, IndexError):
                pass
        if on_update:
            on_update()

    def _remove_point(idx):
        editor.remove_point(idx)
        if on_update:
            on_update()

    for idx, point in enumerate(editor.points):
        row = idx + 1
        fv = tk.StringVar(value=f"{point.freq_hz:.0f}")
        gv = tk.StringVar(value=f"{point.gain_db:.1f}")
        freq_vars.append(fv)
        gain_vars.append(gv)

        freq_entry = ttk.Entry(points_frame, textvariable=fv, width=10)
        freq_entry.grid(row=row, column=0, sticky="w", padx=(0, 8), pady=2)

        gain_scale = ttk.Scale(points_frame, from_=-20.0, to=20.0, orient="horizontal",
                               command=lambda val, gvar=gv: gvar.set(f"{float(val):.1f}"))
        try:
            gain_scale.set(point.gain_db)
        except Exception:
            pass
        gain_scale.grid(row=row, column=1, sticky="ew", padx=(0, 8), pady=2)

        gain_entry = ttk.Entry(points_frame, textvariable=gv, width=8)
        gain_entry.grid(row=row, column=2, sticky="w", padx=(0, 8), pady=2)

        def _add_after(i=idx):
            # Insert a new point between this point and the next one
            pts = editor.points
            if i < len(pts) - 1:
                new_freq = (pts[i].freq_hz + pts[i + 1].freq_hz) / 2
                new_gain = (pts[i].gain_db + pts[i + 1].gain_db) / 2
            else:
                # Last point: extrapolate slightly above
                new_freq = min(pts[i].freq_hz * 1.5, 20000.0)
                new_gain = pts[i].gain_db
            editor.add_point(new_freq, new_gain)
            if on_update:
                on_update()

        ttk.Button(points_frame, text="+",
                   command=_add_after, width=3).grid(
            row=row, column=3, sticky="w", pady=2)
        if len(editor.points) > 2:
            ttk.Button(points_frame, text="✕",
                       command=lambda i=idx: _remove_point(i), width=3).grid(
                row=row, column=4, sticky="w", pady=2)

    # Actions
    actions = ttk.Frame(frame, padding=(0, 8, 0, 0))
    actions.grid(row=3, column=0, sticky="w")
    ttk.Button(actions, text="Apply changes", command=_apply_changes).grid(row=0, column=0, sticky="w")
    ttk.Button(actions, text="Save as CSV", command=lambda: [_apply_changes(), on_save()]).grid(row=0, column=1, sticky="w", padx=(12, 0))
    if on_load:
        ttk.Button(actions, text="Load CSV", command=on_load).grid(row=0, column=2, sticky="w", padx=(12, 0))
    ttk.Button(actions, text="Reset to flat", command=on_reset).grid(row=0, column=3 if on_load else 2, sticky="w", padx=(12, 0))
    ttk.Label(
        actions,
        text="After saving, use the CSV as --target-csv in your next measurement or fit.",
        wraplength=DETAIL_WRAP,
        justify="left",
    ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(8, 0))
