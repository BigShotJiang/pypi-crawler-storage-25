# extractor.py
from pathlib import Path
import logging
from typing import List

from .ocr import ocr_pdf_page  # your OCR implementation
import fitz  # PyMuPDF

logger = logging.getLogger(__name__)

# =========================
# --- INTERNAL FUNCTIONS ---
# =========================
def _extract_text_with_pymupdf(file_path: Path) -> List[str]:
    doc = fitz.open(file_path)
    texts = [page.get_text() for page in doc]
    doc.close()
    return texts

def _extract_text_with_ocr(file_path: Path, lang: str = "ara") -> List[str]:
    """
    Extract text using OCR from each page.
    """
    doc = fitz.open(file_path)
    texts = []
    for page in doc:
        img = page.get_pixmap()
        text = ocr_pdf_page(img, lang=lang)
        texts.append(text)
    doc.close()
    return texts

# =========================
# --- PUBLIC FUNCTION ---
# =========================
def extract_text_from_file(file_path: Path, method: str = "ocr", lang: str = "ara") -> List[str]:
    """
    Extract text from a PDF using different methods.

    Parameters
    ----------
    file_path : Path
        Path to PDF file.
    method : str
        "auto", "text", or "ocr".
    lang : str
        OCR language (default: "ara").

    Returns
    -------
    List[str]
        List of page texts.
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"{file_path} not found")

    logger.info(f"Extracting text from: {file_path} | method={method}")

    if method == "text":
        return _extract_text_with_pymupdf(file_path)

    if method == "ocr":
        return _extract_text_with_ocr(file_path, lang=lang)

    if method == "auto":
        texts = _extract_text_with_pymupdf(file_path)
        if all(not t.strip() for t in texts):
            logger.info("No text found, switching to OCR...")
            return _extract_text_with_ocr(file_path, lang=lang)
        return texts

    raise ValueError(f"Invalid method: {method}")