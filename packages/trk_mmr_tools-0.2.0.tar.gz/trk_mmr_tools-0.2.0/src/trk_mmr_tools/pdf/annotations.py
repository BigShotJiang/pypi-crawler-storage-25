# annotations.py
from pathlib import Path
import logging
import fitz
import pandas as pd
from typing import Optional

logger = logging.getLogger(__name__)

# =========================
# --- EXTRACT ANNOTATIONS ---
# =========================
def extract_annotations(pdf_path: Path, list_mode: bool = False) -> pd.DataFrame:
    pdf_path = Path(pdf_path)
    doc = fitz.open(pdf_path)
    records = []

    for page_num, page in enumerate(doc, start=1):
        annots = page.annots()
        if not annots:
            continue

        if list_mode:
            texts = [a.info["content"] for a in annots if a.info["content"]]
            if texts:
                records.append({
                    "file_name": pdf_path.name,
                    "file_path": str(pdf_path.resolve()),
                    "page": page_num,
                    "annotation": texts
                })
        else:
            for a in annots:
                content = a.info["content"]
                if content:
                    records.append({
                        "file_name": pdf_path.name,
                        "file_path": str(pdf_path.resolve()),
                        "page": page_num,
                        "annotation": content
                    })
    doc.close()
    return pd.DataFrame(records)

def extract_annotations_with_text(pdf_path: Path, list_mode: bool = False) -> pd.DataFrame:
    pdf_path = Path(pdf_path)
    doc = fitz.open(pdf_path)
    records = []

    for page_num, page in enumerate(doc, start=1):
        annots = page.annots()
        page_text = page.get_text()
        if not annots:
            continue

        if list_mode:
            texts = [a.info["content"] for a in annots if a.info["content"]]
            if texts:
                records.append({
                    "file_name": pdf_path.name,
                    "file_path": str(pdf_path.resolve()),
                    "page": page_num,
                    "annotation": texts,
                    "text": page_text
                })
        else:
            for a in annots:
                content = a.info["content"]
                if content:
                    records.append({
                        "file_name": pdf_path.name,
                        "file_path": str(pdf_path.resolve()),
                        "page": page_num,
                        "annotation": content,
                        "text": page_text
                    })
    doc.close()
    return pd.DataFrame(records)

# =========================
# --- PROCESS ANNOTATIONS ---
# =========================
def process_annotations(
    source: Path,
    output_dir: Path,
    with_text: bool = False,
    list_mode: bool = False,
    separate_excel: bool = True
):
    source = Path(source)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if source.is_file() and source.suffix.lower() == ".pdf":
        df = extract_annotations_with_text(source, list_mode) if with_text else extract_annotations(source, list_mode)
        out_file = output_dir / f"{source.stem}_annotations.xlsx"
        save_annotations_to_excel(df, out_file)

    elif source.is_dir():
        pdf_files = list(source.glob("*.pdf"))
        all_dfs = []

        for pdf_path in pdf_files:
            df = extract_annotations_with_text(pdf_path, list_mode) if with_text else extract_annotations(pdf_path, list_mode)
            if separate_excel:
                out_file = output_dir / f"{pdf_path.stem}_annotations.xlsx"
                save_annotations_to_excel(df, out_file)
            else:
                all_dfs.append(df)

        if not separate_excel and all_dfs:
            combined_df = pd.concat(all_dfs, ignore_index=True)
            out_file = output_dir / "all_annotations.xlsx"
            save_annotations_to_excel(combined_df, out_file)
    else:
        logging.warning(f"No PDFs found at {source}")

def save_annotations_to_excel(df: pd.DataFrame, output_file: Path):
    output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(output_file, index=False)
    logger.info(f"Saved annotations to {output_file}")