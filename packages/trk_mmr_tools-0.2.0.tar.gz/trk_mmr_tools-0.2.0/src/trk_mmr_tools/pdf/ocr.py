# ocr.py
# =========================
# OCR implementation using pytesseract
# =========================

from PIL import Image
import pytesseract
import fitz  # PyMuPDF

def ocr_pdf_page(page_image: fitz.Pixmap, lang: str = "ara") -> str:
    """
    Perform OCR on a PDF page image using pytesseract.

    Parameters
    ----------
    page_image : fitz.Pixmap
        PDF page rendered as an image from PyMuPDF.
    lang : str
        OCR language (default Arabic, "ara").

    Returns
    -------
    str
        Extracted text from the page.
    """
    # Convert PyMuPDF Pixmap to PIL Image
    mode = "RGB" if page_image.n < 4 else "RGBA"
    img = Image.frombytes(mode, [page_image.width, page_image.height], page_image.samples)

    # Run OCR
    try:
        text = pytesseract.image_to_string(img, lang=lang)
        return text
    except pytesseract.TesseractError as e:
        raise RuntimeError(f"OCR failed: {e}")