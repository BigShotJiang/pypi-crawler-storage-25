# directory.py
from pathlib import Path
import logging
from typing import Union

from .extractor import extract_text_from_file
from .correction import TextCorrection
from tqdm import tqdm

logger = logging.getLogger(__name__)

def process_pdf_directory(
    folder: Union[str, Path],
    output_dir: Union[str, Path],
    method: str = "ocr",
    lang: str = "ara",
    clean: bool = False,
    corrector: TextCorrection = None,
) -> None:
    """
    Process all PDFs in a directory: extract text, optionally correct, and save per-page.

    Parameters
    ----------
    folder : str | Path
        Path to directory containing PDFs.
    output_dir : str | Path
        Folder to save extracted text folders.
    method : str
        Extraction method: "auto", "text", or "ocr".
    lang : str
        OCR language if method involves OCR.
    clean : bool
        Apply text correction if True.
    corrector : TextCorrection, optional
        Instance of TextCorrection to apply corrections.
    """
    folder = Path(folder)
    output_dir = Path(output_dir)

    pdf_files = list(folder.glob("*.pdf"))
    logger.info(f"Found {len(pdf_files)} PDF(s) in {folder}")

    if not pdf_files:
        logger.warning(f"No PDFs found in {folder}")
        return

    for pdf_path in tqdm(pdf_files, desc=f"Processing PDFs in {folder}", unit="file"):
        page_texts = extract_text_from_file(pdf_path, method=method, lang=lang)

        # Ensure list of pages
        if isinstance(page_texts, str):
            page_texts = [page_texts]

        # Create PDF-specific folder
        pdf_output_dir = output_dir / pdf_path.stem
        pdf_output_dir.mkdir(parents=True, exist_ok=True)

        # Save pages with optional correction
        for i, text in enumerate(page_texts, start=1):
            if clean and corrector is not None:
                text = corrector.correct_text(text)

            output_file = pdf_output_dir / f"page_{i:03d}.txt"
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(text)

        logger.info(f"Saved {len(page_texts)} pages from {pdf_path.name} in {pdf_output_dir}")