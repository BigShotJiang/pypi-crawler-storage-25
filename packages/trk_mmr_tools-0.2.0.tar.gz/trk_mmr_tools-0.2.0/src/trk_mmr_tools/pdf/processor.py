# processor.py
from pathlib import Path
import logging
from tqdm import tqdm
from typing import Optional, Union

# ✅ Correct imports from text package
from trk_mmr_tools.text.correction import TextCorrection
from trk_mmr_tools.pdf.extractor import extract_text_from_file

# =========================
# --- LOGGER CONFIG ---
# =========================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)


# =========================
# --- PUBLIC FUNCTION ---
# =========================
def process_pdfs(
    source: Union[str, Path],
    output_dir: Union[str, Path],
    method: str = "ocr",
    lang: str = "ara",
    clean: bool = False,
    corrector: Optional[TextCorrection] = None,
) -> None:
    """
    Process PDF(s) from a single file or a directory.

    Parameters
    ----------
    source : str | Path
        Path to a PDF file or a folder containing PDFs.
    output_dir : str | Path
        Folder to save extracted pages.
    method : str
        Extraction method: "auto", "text", or "ocr".
    lang : str
        OCR language if OCR is used.
    clean : bool
        Apply text correction if True.
    corrector : TextCorrection, optional
        Instance of TextCorrection to apply corrections.
    """
    source = Path(source)
    output_dir = Path(output_dir)

    # Single PDF file
    if source.is_file() and source.suffix.lower() == ".pdf":
        logging.info(f"Single PDF detected: {source}")
        _process_single_pdf(source, output_dir, method, lang, clean, corrector)

    # Directory of PDFs
    elif source.is_dir():
        pdf_files = list(source.glob("*.pdf"))
        logging.info(f"Directory detected: {source}, {len(pdf_files)} PDF(s) found")

        for pdf_path in pdf_files:
            _process_single_pdf(pdf_path, output_dir, method, lang, clean, corrector)

    else:
        logging.warning(f"No PDFs found at {source}")


# =========================
# --- INTERNAL FUNCTION ---
# =========================
def _process_single_pdf(
    pdf_path: Path,
    output_dir: Path,
    method: str = "ocr",
    lang: str = "ara",
    clean: bool = False,
    corrector: Optional[TextCorrection] = None,
) -> None:
    """
    Process a single PDF file: extract text, optionally correct it, and save each page.

    Parameters
    ----------
    pdf_path : Path
        Path to the PDF file.
    output_dir : Path
        Folder to save extracted page text.
    method : str
        Extraction method: "auto", "text", or "ocr".
    lang : str
        OCR language if method involves OCR.
    clean : bool
        Whether to apply TextCorrection.
    corrector : TextCorrection, optional
        Instance of TextCorrection to apply corrections.
    """
    pdf_path = Path(pdf_path)
    output_dir = Path(output_dir)
    logging.info(f"Processing PDF: {pdf_path}")

    # 1️⃣ Extract text from PDF
    page_texts = extract_text_from_file(pdf_path, method=method, lang=lang)

    # Ensure we always have a list of pages
    if isinstance(page_texts, str):
        page_texts = [page_texts]

    # 2️⃣ Create PDF-specific output folder
    pdf_output_dir = output_dir / pdf_path.stem
    pdf_output_dir.mkdir(parents=True, exist_ok=True)

    # 3️⃣ Loop over pages with tqdm progress bar
    for i, text in enumerate(tqdm(page_texts, desc=f"Processing {pdf_path.name}", unit="page"), start=1):

        # Apply correction if requested
        if clean and corrector is not None:
            text = corrector.correct_text(text)

        # Save page to text file
        output_file = pdf_output_dir / f"page_{i:03d}.txt"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(text)

    logging.info(f"Finished {pdf_path} | {len(page_texts)} pages saved in {pdf_output_dir}")