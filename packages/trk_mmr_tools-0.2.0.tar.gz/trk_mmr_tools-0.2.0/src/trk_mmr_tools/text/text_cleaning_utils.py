# =========================
# text_cleaning.py
# =========================

import re
import string
import unicodedata


# ======================================================
# Basic cleaning helpers
# ======================================================

def remove_emails_numbers_non_arabic(text: str) -> str:
    """
    Remove emails, numbers, and non-Arabic characters.
    """
    text = re.sub(r'\S+@\S+\.\S+', ' ', text)
    text = re.sub(r'\d+', ' ', text)
    text = re.sub(r'[^\u0600-\u06FF\s]', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


def remove_punctuation(text: str) -> str:
    """
    Remove punctuation and digits.
    """
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'[؟،؛«»ـ]', '', text)  # Arabic punctuation
    return re.sub(r'\d+', '', text).strip()


def remove_diacritics(text: str) -> str:
    """
    Remove Arabic diacritics (tashkeel).
    """
    arabic_diacritics = re.compile(
        r'[\u064B-\u065F\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7-\u06E8\u06EA-\u06ED]'
    )
    return re.sub(arabic_diacritics, '', text)


def normalize_rtl(text: str) -> str:
    """
    Normalize RTL text and remove invisible characters.
    """
    text = text.replace('\u200e', '').replace('\u200f', '')
    return unicodedata.normalize('NFKC', text)


def normalize_arabic_letters(text: str) -> str:
    """
    Normalize Arabic letters for consistency with WordBank.
    """
    text = text.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    text = text.replace("ى", "ي")
    text = text.replace("ؤ", "و").replace("ئ", "ي")
    # Optional depending on dataset:
    # text = text.replace("ة", "ه")
    return text


def replace_repeated_chars(text: str) -> str:
    """
    Replace repeated Arabic characters (OCR noise).
    Example: كثثثييرا → كثيرا
    """
    chars_to_check = [
        'ه','غ','ي','ب','ف','م','ٱ','ص','خ','ى','و','ع','ة','ن','ئ','ت','ً',
        'ك','ز','ق','ج','ط','ؤ','ش','س','د','ـ','ر','إ','لا','آ','ْ','أ','ل','ا','ء','ح'
    ]
    pattern = f"({'|'.join(chars_to_check)})\\1+"
    return re.sub(pattern, r'\1', text)


def separate_special_characters(text: str) -> str:
    """
    Add spaces around punctuation/special characters.
    Useful before removing them.
    """
    special_chars = (
        "'", '!', '"', '#', '$', '%', '&', '(', ')', "؟", '*', '+', ',', '-',
        '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^',
        '_', '`', '{', '|', '}', '~', '،', '؛'
    )
    pattern = '|'.join(re.escape(c) for c in special_chars)
    text = re.sub(f"({pattern})", r" \1 ", text)
    return ' '.join(text.split())


def normalize_spaces(text: str) -> str:
    """
    Normalize multiple spaces into single space.
    """
    return " ".join(text.split())


# ======================================================
# Full cleaning pipeline
# ======================================================

def clean_text(
    text: str,
    *,
    normalize_rtl_flag: bool = False,
    remove_non_arabic: bool = False,
    separate_chars: bool = False,
    remove_diacritics_flag: bool = False,
    normalize_letters: bool = False,
    fix_repeated_chars: bool = False,
    remove_punct: bool = False,
    normalize_spaces_flag: bool = False
) -> str:
    """
    Flexible Arabic text cleaning pipeline.

    Parameters
    ----------
    text : str
        Raw input text
    normalize_rtl_flag : bool
        Normalize RTL/invisible characters
    remove_non_arabic : bool
        Remove emails, numbers, non-Arabic characters
    separate_chars : bool
        Add spaces around punctuation
    remove_diacritics_flag : bool
        Remove tashkeel
    normalize_letters : bool
        Normalize Arabic letters (أ → ا, etc.)
    fix_repeated_chars : bool
        Fix OCR repeated characters
    remove_punct : bool
        Remove punctuation
    normalize_spaces_flag : bool
        Normalize spaces

    Returns
    -------
    str
        Cleaned text
    """
    if normalize_rtl_flag:
        text = normalize_rtl(text)

    if remove_non_arabic:
        text = remove_emails_numbers_non_arabic(text)

    if separate_chars:
        text = separate_special_characters(text)

    if remove_diacritics_flag:
        text = remove_diacritics(text)

    if normalize_letters:
        text = normalize_arabic_letters(text)

    if fix_repeated_chars:
        text = replace_repeated_chars(text)

    if remove_punct:
        text = remove_punctuation(text)

    if normalize_spaces_flag:
        text = normalize_spaces(text)

    return text