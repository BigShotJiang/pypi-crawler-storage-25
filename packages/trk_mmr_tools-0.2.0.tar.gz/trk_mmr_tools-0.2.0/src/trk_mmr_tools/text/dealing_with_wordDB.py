# =========================
# dealing_with_wordDB.py
# =========================

from collections import defaultdict
from typing import List, Union, Optional
import os
import pickle
import pandas as pd

# ======================================================
# WordBank loading (optional registry for built-in PKLs)
# ======================================================
FILE_MAP = {
    # "chaab": "chaab_website_WordBankDB.pkl",
    "elkhaber": "el_khaber_WordBankDB.pkl",
    # "clean_web": "clean_vocabfrom_arabic_websites.pkl",
    # "clean_camel": "clean_whole_vocab_from_colab_camel_tools_data_disambig_mle_calima.pkl",
    # "combined": "combined_data_no_duplicates.pkl",
    # "df_vocab": "df_vocab_parquet.pkl",
    # "mkhalett": "whole_mkhalett.pkl",  # DEFAULT
}

DEFAULT_DATASET = "elkhaber"


def load_wordbank(name: str = DEFAULT_DATASET, filename: Optional[str] = None, data_dir: Optional[str] = None):
    """
    Load a WordBank .pkl dataset from package assets folder.
    Returns a Python object (usually list or dict) loaded from pickle.
    """
    if filename is None:
        if name not in FILE_MAP:
            raise ValueError(f"Unknown dataset name '{name}'. Available: {list(FILE_MAP.keys())}")
        filename = FILE_MAP[name]

    if data_dir is None:
        current_dir = os.path.dirname(__file__)
        data_dir = os.path.join(current_dir, "..", "assets")  # relative to module

    file_path = os.path.abspath(os.path.join(data_dir, filename))
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    with open(file_path, "rb") as f:
        data = pickle.load(f)

    # Ensure everything is string
    if isinstance(data, list):
        data = [str(w) for w in data if w is not None]
    return data


def list_wordbanks() -> List[str]:
    """Return all available dataset short names."""
    return list(FILE_MAP.keys())


# ======================================================
# WordDict creation & searching
# ======================================================

def create_word_dict_wordbankDB(word_list: List[str]) -> defaultdict:
    """
    Create a nested dictionary: word_dict[length][first_letter][last_letter] -> list of words
    """
    word_dict = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for word in word_list:
        if not isinstance(word, str) or len(word) < 2:
            continue
        length = len(word)
        first_letter = word[0]
        last_letter = word[-1]
        word_dict[length][first_letter][last_letter].append(word)
    return word_dict


def search_word_in_dict_wordbankDB(word: str, word_dict: Union[dict, defaultdict]) -> bool:
    """Check if a word exists in the WordBank dictionary."""
    if not isinstance(word, str) or len(word) < 2:
        return False
    length = len(word)
    first_letter = word[0]
    last_letter = word[-1]
    return (length in word_dict and
            first_letter in word_dict[length] and
            last_letter in word_dict[length][first_letter] and
            word in word_dict[length][first_letter][last_letter])


def search_words_not_in_dict(text: str, word_dict: Union[dict, defaultdict]) -> List[str]:
    """Return words from text that are not found in the WordBank."""
    words = text.split()
    missing = []
    for word in words:
        if not isinstance(word, str) or len(word) < 2:
            continue
        if not search_word_in_dict_wordbankDB(word, word_dict):
            missing.append(word)
    return missing


def get_wrong_words(text: str, wordbank: Optional[Union[dict, defaultdict]] = None, load_default: bool = True) -> List[str]:
    """
    Quick helper to return words not in the WordBank.
    """
    if wordbank is None and load_default:
        wordbank_data = load_wordbank()
        wordbank = create_word_dict_wordbankDB(wordbank_data)
    if wordbank is None:
        raise ValueError("No WordBank provided and load_default=False.")
    return search_words_not_in_dict(text, wordbank)


# ======================================================
# Save / Load WordBank dictionary to/from pickle
# ======================================================

def convert_defaultdict_to_dict(d):
    """Recursively convert defaultdict to regular dict."""
    if isinstance(d, defaultdict):
        return {k: convert_defaultdict_to_dict(v) for k, v in d.items()}
    return d


def recreate_defaultdict(d):
    """Recursively convert regular dict back to nested defaultdict."""
    if isinstance(d, dict):
        return defaultdict(lambda: defaultdict(lambda: defaultdict(list)),
                           {k: recreate_defaultdict(v) for k, v in d.items()})
    return d


def save_WordBankDB_dict(word_dict, filename):
    """Save a WordBank dictionary (defaultdict or dict) as pickle."""
    normal_dict = convert_defaultdict_to_dict(word_dict)
    with open(filename, "wb") as f:
        pickle.dump(normal_dict, f)
    print(f"Dictionary saved successfully to {filename}!")


def load_WordBankDB_dict(filename):
    """Load a pickle file into a nested WordBank defaultdict."""
    with open(filename, "rb") as f:
        normal_dict = pickle.load(f)
    return recreate_defaultdict(normal_dict)


def bankword_creator_and_saver_to_folder_as_pkl(vocab_list: List[str], outputfolder: str, name: str):
    """Create a WordBank dictionary from a list of words and save as pickle."""
    vocab_list = [str(w) for w in vocab_list if w is not None]
    wordbankDB_pkl = create_word_dict_wordbankDB(vocab_list)
    fname = f"{name}_wordbank_db_pkl.pkl"
    filename = os.path.join(outputfolder, fname)
    save_WordBankDB_dict(wordbankDB_pkl, filename)


def get_wrong_position_words(text: str, word_dict=None, dataset_name=DEFAULT_DATASET, return_positions: bool = False):
    """Return wrong words and optionally their positions in text."""
    if word_dict is None:
        raw_data = load_wordbank(name=dataset_name)
        word_dict = create_word_dict_wordbankDB(raw_data)

    wrong_words_list = search_words_not_in_dict(text, word_dict)

    if not return_positions:
        return wrong_words_list

    # Compute positions
    positions = []
    start = 0
    for word in text.split():
        end = start + len(word)
        if word in wrong_words_list:
            positions.append((word, start, end))
        start = end + 1  # skip space
    return positions


def load_wrong_correct_dict(excel_path: str) -> dict:
    """
    Load wrong→correct dictionary from Excel.
    Expected columns:
    - word
    - correction
    """
    df = pd.read_excel(excel_path)
    df.columns = [c.strip().lower() for c in df.columns]
    return dict(zip(df["word"], df["correction"]))