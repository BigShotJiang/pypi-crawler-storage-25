# =========================
# correction.py
# =========================

from trk_mmr_tools.text.text_cleaning_utils import (
    remove_emails_numbers_non_arabic,
    remove_diacritics,
    normalize_rtl,
    replace_repeated_chars,
    separate_special_characters
)
from trk_mmr_tools.text.dealing_with_wordDB import search_word_in_dict_wordbankDB

import os
from typing import Optional


class TextCorrection:
    """
    High-level text correction pipeline for Arabic text.

    Features:
    - Basic text cleaning (emails, numbers, diacritics, repeated chars, punctuation)
    - Word DB correction (split joined words using a WordBank)
    - Wrong→Correct dictionary correction
    - OCR + correction page-by-page

    Usage Example:
    --------------
    tc = TextCorrection(word_db=my_dict, wrong_correct_dict=wrong_dict)
    corrected_text = tc.correct_text(text)

    OCR + correction per file:
    --------------------------
    tc.ocr_and_correct(file_path, apply_correction=True)

    OCR + save pages:
    -----------------
    tc.ocr_and_save_pages(file_path, output_folder, apply_correction=True)
    """

    def __init__(self, word_db: Optional[dict] = None, wrong_correct_dict: Optional[dict] = None):
        self.word_db = word_db
        self.wrong_correct_dict = wrong_correct_dict or {}

    # ------------------------------------
    # Word DB splitting
    # ------------------------------------
    def tafrik_horrof_motalasika(self, text: str):
        """
        Split joined Arabic words using WordBank.

        Returns a list of words.
        """
        if not self.word_db:
            return text.split()

        words = []
        while text:
            found = False
            for length in range(20, 0, -1):
                candidate = text[-length:]
                if search_word_in_dict_wordbankDB(candidate, self.word_db):
                    words.append(candidate)
                    text = text[:-length]
                    found = True
                    break
            if not found:
                words.append(text[-1])
                text = text[:-1]
        return words[::-1]

    # ------------------------------------
    # Cleaning + Correction
    # ------------------------------------
    def correct_text(
        self,
        text: str,
        return_list: bool = False,
        clean_emails_numbers: bool = True,
        clean_diacritics: bool = True,
        normalize_text: bool = True,
        reduce_repeated_chars: bool = True,
        separate_specials: bool = True
    ):
        """
        Apply full cleaning pipeline and dictionary-based corrections.

        Parameters
        ----------
        text : str
            Raw text input.
        return_list : bool
            Return list of words instead of joined string.
        clean_emails_numbers : bool
            Remove emails, numbers, non-Arabic characters.
        clean_diacritics : bool
            Remove Arabic diacritics.
        normalize_text : bool
            Normalize RTL and remove invisible characters.
        reduce_repeated_chars : bool
            Reduce repeated Arabic letters.
        separate_specials : bool
            Add spaces around punctuation/special characters.
        """
        # --- Step 1: Basic cleaning ---
        if clean_emails_numbers:
            text = remove_emails_numbers_non_arabic(text)
        if clean_diacritics:
            text = remove_diacritics(text)
        if normalize_text:
            text = normalize_rtl(text)
        if reduce_repeated_chars:
            text = replace_repeated_chars(text)
        if separate_specials:
            text = separate_special_characters(text)

        words = text.split()

        # --- Step 2: Word DB correction ---
        if self.word_db:
            corrected_words = []
            i = 0
            while i < len(words):
                w = words[i]
                split_words = self.tafrik_horrof_motalasika(w)
                if all(search_word_in_dict_wordbankDB(sw, self.word_db) for sw in split_words):
                    corrected_words.extend(split_words)
                else:
                    corrected_words.append(w)
                i += 1
            words = corrected_words

        # --- Step 3: Wrong→Correct dict correction ---
        if self.wrong_correct_dict:
            for i, word in enumerate(words):
                if word in self.wrong_correct_dict:
                    words[i] = self.wrong_correct_dict[word]

        return words if return_list else " ".join(words)

    # ------------------------------------
    # OCR + Correction per file
    # ------------------------------------
    def ocr_and_correct(self, file_path: str, apply_correction: bool = True) -> str:
        """
        Extract text from a file and optionally apply correction.

        Parameters
        ----------
        file_path : str
            Path to PDF or multi-page image.
        apply_correction : bool
            Apply cleaning/correction pipeline if True.

        Returns
        -------
        str
            Full extracted text (corrected if apply_correction=True)
        """
        text = self.extract_text_from_file(file_path)

        if apply_correction:
            text = self.correct_text(text)

        return text

    # ------------------------------------
    # OCR + page-by-page saving
    # ------------------------------------
    def ocr_and_save_pages(self, file_path: str, output_folder: str, apply_correction: bool = True):
        """
        Extract text from each page and save as separate text files.

        Parameters
        ----------
        file_path : str
            Path to PDF or multi-page image.
        output_folder : str
            Folder where page text files will be saved.
        apply_correction : bool
            Apply cleaning/correction pipeline or save raw OCR.
        """
        os.makedirs(output_folder, exist_ok=True)

        pages_text = self.extract_text_from_file(file_path)
        if isinstance(pages_text, str):
            pages_text = [pages_text]

        for i, page_text in enumerate(pages_text, 1):
            if apply_correction:
                page_text = self.correct_text(page_text)
            fname = f"page_{i:03d}.txt"
            fpath = os.path.join(output_folder, fname)
            with open(fpath, "w", encoding="utf-8") as f:
                f.write(page_text)

    # ------------------------------------
    # Placeholder OCR extractor
    # ------------------------------------
    def extract_text_from_file(self, file_path: str):
        """
        Replace this with your actual OCR function.

        Returns either:
        - str (single-page)
        - list[str] (multi-page)
        """
        raise NotImplementedError("Please replace extract_text_from_file with your OCR function.")