# =========================
# __init__.py for trt_tarek_tools.text
# =========================

"""
trt_tarek_tools.text
====================

This subpackage provides tools for Arabic text cleaning, wordbank handling,
and text correction pipelines.

Modules:
--------
- text_cleaning_utils : Basic and full Arabic text cleaning functions.
- dealing_with_wordDB : WordBank loading, searching, and dictionary utilities.
- correction : High-level text correction pipeline using cleaning and WordBank.

Usage:
------
from trt_tarek_tools.text import TextCorrection
from trt_tarek_tools.text.text_cleaning_utils import clean_text
from trt_tarek_tools.text.dealing_with_wordDB import load_wordbank, get_wrong_words
"""

from .text_cleaning_utils import (
    remove_emails_numbers_non_arabic,
    remove_diacritics,
    normalize_rtl,
    normalize_arabic_letters,
    replace_repeated_chars,
    separate_special_characters,
    normalize_spaces,
    clean_text
)

from .dealing_with_wordDB import (
    load_wordbank,
    list_wordbanks,
    create_word_dict_wordbankDB,
    search_word_in_dict_wordbankDB,
    search_words_not_in_dict,
    get_wrong_words,
    convert_defaultdict_to_dict,
    recreate_defaultdict,
    save_WordBankDB_dict,
    load_WordBankDB_dict,
    bankword_creator_and_saver_to_folder_as_pkl,
    get_wrong_position_words,
    load_wrong_correct_dict
)

from .correction import TextCorrection