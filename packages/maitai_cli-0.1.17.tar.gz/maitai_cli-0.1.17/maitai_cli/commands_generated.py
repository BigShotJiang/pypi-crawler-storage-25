"""Generated CLI commands from OpenAPI spec. Do not edit by hand."""

from typing import Optional

import typer
from maitai_cli.utils import console, get_client, handle_api_errors, print_json

agents_app = typer.Typer(name="agents", help="Manage agents.", no_args_is_help=True)


@handle_api_errors
def _agents_list(
    include_subagents: Optional[bool] = typer.Option(
        None, "--include-subagents", help="Include sub-agents in the response."
    ),
    include_actions: Optional[bool] = typer.Option(
        None, "--include-actions", help="Include agent actions in the response."
    ),
):
    """List agents."""
    client = get_client()
    params: dict = {}
    if include_subagents is not None:
        params["include_subagents"] = include_subagents
    if include_actions is not None:
        params["include_actions"] = include_actions
    r = client.get(f"/agents", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="list", help="List agents")(_agents_list)


@handle_api_errors
def _agents_get(
    agent_id: int = typer.Argument(..., help="agent_id"),
    detailed: Optional[bool] = typer.Option(
        None, "--detailed", help="Include full configuration details in results."
    ),
):
    """Get agent."""
    client = get_client()
    params: dict = {}
    if detailed is not None:
        params["detailed"] = detailed
    r = client.get(f"/agents/{agent_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get", help="Get agent")(_agents_get)


@handle_api_errors
def _agents_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_application_id: Optional[int] = typer.Option(
        None, "--application-id", help="application_id. Required."
    ),
    body_arg_agent_name: Optional[str] = typer.Option(
        None, "--agent-name", help="agent_name. Required."
    ),
):
    """Create agent."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_application_id is not None:
        body["application_id"] = body_arg_application_id
    if body_arg_agent_name is not None:
        body["agent_name"] = body_arg_agent_name
    required_fields = ("application_id", "agent_name")
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/agents", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="create", help="Create agent")(_agents_create)


@handle_api_errors
def _agents_update(
    agent_id: int = typer.Argument(..., help="agent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update agent."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/agents/{agent_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="update", help="Update agent")(_agents_update)


@handle_api_errors
def _agents_delete(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """Delete agent."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/agents/{agent_id}", params=params)
    console.print("[green]Deleted.[/green]")


agents_app.command(name="delete", help="Delete agent")(_agents_delete)


@handle_api_errors
def _agents_disable_action(
    action_id: int = typer.Argument(..., help="action_id"),
):
    """Disable action."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/agents/actions/{action_id}/disable")
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="disable-action", help="Disable action")(_agents_disable_action)


@handle_api_errors
def _agents_enable_action(
    action_id: int = typer.Argument(..., help="action_id"),
):
    """Enable action."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/agents/actions/{action_id}/enable")
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="enable-action", help="Enable action")(_agents_enable_action)


@handle_api_errors
def _agents_publish_action_version(
    action_id: int = typer.Argument(..., help="action_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Publish action version."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/agents/actions/{action_id}/publish", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="publish-action-version", help="Publish action version")(
    _agents_publish_action_version
)


@handle_api_errors
def _agents_list_action_versions(
    action_id: int = typer.Argument(..., help="action_id"),
):
    """List action versions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/actions/{action_id}/versions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="list-action-versions", help="List action versions")(
    _agents_list_action_versions
)


@handle_api_errors
def _agents_delete_action(
    action_id: int = typer.Argument(..., help="action_id"),
):
    """Delete agent action."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/agents/actions/{action_id}", params=params)
    console.print("[green]Deleted.[/green]")


agents_app.command(name="delete-action", help="Delete agent action")(
    _agents_delete_action
)


@handle_api_errors
def _agents_get_action(
    action_id: int = typer.Argument(..., help="action_id"),
):
    """Get agent action."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/actions/{action_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-action", help="Get agent action")(_agents_get_action)


@handle_api_errors
def _agents_update_action(
    action_id: int = typer.Argument(..., help="action_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update agent action."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/agents/actions/{action_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="update-action", help="Update agent action")(
    _agents_update_action
)


@handle_api_errors
def _agents_get_task_tree(
    task_id: int = typer.Argument(..., help="task_id"),
):
    """Get agent task tree."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/tasks/{task_id}/tree", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-task-tree", help="Get agent task tree")(
    _agents_get_task_tree
)


@handle_api_errors
def _agents_list_actions(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """List agent actions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/actions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="list-actions", help="List agent actions")(_agents_list_actions)


@handle_api_errors
def _agents_create_action(
    agent_id: int = typer.Argument(..., help="agent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_action_name: Optional[str] = typer.Option(
        None, "--action-name", help="action_name. Required."
    ),
    body_arg_action_type: Optional[str] = typer.Option(
        None, "--action-type", help="action_type. Required."
    ),
    body_arg_description: Optional[str] = typer.Option(
        None, "--description", help="description. Required."
    ),
):
    """Create agent action."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_action_name is not None:
        body["action_name"] = body_arg_action_name
    if body_arg_action_type is not None:
        body["action_type"] = body_arg_action_type
    if body_arg_description is not None:
        body["description"] = body_arg_description
    required_fields = ("action_name", "action_type", "description")
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/agents/{agent_id}/actions", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="create-action", help="Create agent action")(
    _agents_create_action
)


@handle_api_errors
def _agents_delete_form_fields(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """Delete form fields."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/agents/{agent_id}/form-fields", params=params)
    console.print("[green]Deleted.[/green]")


agents_app.command(name="delete-form-fields", help="Delete form fields")(
    _agents_delete_form_fields
)


@handle_api_errors
def _agents_get_form_fields(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """Get form fields."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/form-fields", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-form-fields", help="Get form fields")(
    _agents_get_form_fields
)


@handle_api_errors
def _agents_update_form_fields(
    agent_id: int = typer.Argument(..., help="agent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update form fields."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/agents/{agent_id}/form-fields", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="update-form-fields", help="Update form fields")(
    _agents_update_form_fields
)


@handle_api_errors
def _agents_publish_version(
    agent_id: int = typer.Argument(..., help="agent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Publish agent version."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/agents/{agent_id}/publish", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="publish-version", help="Publish agent version")(
    _agents_publish_version
)


@handle_api_errors
def _agents_delete_release(
    agent_id: int = typer.Argument(..., help="agent_id"),
    name: str = typer.Argument(..., help="name"),
):
    """Delete agent release."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/agents/{agent_id}/releases/{name}", params=params)
    console.print("[green]Deleted.[/green]")


agents_app.command(name="delete-release", help="Delete agent release")(
    _agents_delete_release
)


@handle_api_errors
def _agents_upsert_release(
    agent_id: int = typer.Argument(..., help="agent_id"),
    name: str = typer.Argument(..., help="name"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Upsert agent release."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/agents/{agent_id}/releases/{name}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="upsert-release", help="Upsert agent release")(
    _agents_upsert_release
)


@handle_api_errors
def _agents_list_releases(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """List agent releases."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/releases", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="list-releases", help="List agent releases")(
    _agents_list_releases
)


@handle_api_errors
def _agents_get_routing_config(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """Get routing config."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/routing/config", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-routing-config", help="Get routing config")(
    _agents_get_routing_config
)


@handle_api_errors
def _agents_update_routing_config(
    agent_id: int = typer.Argument(..., help="agent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update routing config."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/agents/{agent_id}/routing/config", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="update-routing-config", help="Update routing config")(
    _agents_update_routing_config
)


@handle_api_errors
def _agents_get_routing_result(
    agent_id: int = typer.Argument(..., help="agent_id"),
    routing_result_id: int = typer.Argument(..., help="routing_result_id"),
):
    """Get routing result."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/agents/{agent_id}/routing/results/{routing_result_id}", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-routing-result", help="Get routing result")(
    _agents_get_routing_result
)


@handle_api_errors
def _agents_reorder_routing_rule(
    agent_id: int = typer.Argument(..., help="agent_id"),
    rule_id: int = typer.Argument(..., help="rule_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Reorder routing rule."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/agents/{agent_id}/routing/rules/{rule_id}/reorder", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="reorder-routing-rule", help="Reorder routing rule")(
    _agents_reorder_routing_rule
)


@handle_api_errors
def _agents_test_routing_rule(
    agent_id: int = typer.Argument(..., help="agent_id"),
    rule_id: int = typer.Argument(..., help="rule_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Test routing rule."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/agents/{agent_id}/routing/rules/{rule_id}/test", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="test-routing-rule", help="Test routing rule")(
    _agents_test_routing_rule
)


@handle_api_errors
def _agents_delete_routing_rule(
    agent_id: int = typer.Argument(..., help="agent_id"),
    rule_id: int = typer.Argument(..., help="rule_id"),
):
    """Delete routing rule."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/agents/{agent_id}/routing/rules/{rule_id}", params=params)
    console.print("[green]Deleted.[/green]")


agents_app.command(name="delete-routing-rule", help="Delete routing rule")(
    _agents_delete_routing_rule
)


@handle_api_errors
def _agents_update_routing_rule(
    agent_id: int = typer.Argument(..., help="agent_id"),
    rule_id: int = typer.Argument(..., help="rule_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update routing rule."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/agents/{agent_id}/routing/rules/{rule_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="update-routing-rule", help="Update routing rule")(
    _agents_update_routing_rule
)


@handle_api_errors
def _agents_create_routing_rule(
    agent_id: int = typer.Argument(..., help="agent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Create routing rule."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/agents/{agent_id}/routing/rules", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="create-routing-rule", help="Create routing rule")(
    _agents_create_routing_rule
)


@handle_api_errors
def _agents_get_session_timeline(
    agent_id: int = typer.Argument(..., help="agent_id"),
    session_id: str = typer.Argument(..., help="session_id"),
):
    """Get agent session timeline."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/sessions/{session_id}/timeline", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-session-timeline", help="Get agent session timeline")(
    _agents_get_session_timeline
)


@handle_api_errors
def _agents_get_session_detail(
    agent_id: int = typer.Argument(..., help="agent_id"),
    session_id: str = typer.Argument(..., help="session_id"),
):
    """Get agent session detail."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/sessions/{session_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-session-detail", help="Get agent session detail")(
    _agents_get_session_detail
)


@handle_api_errors
def _agents_list_sessions(
    agent_id: int = typer.Argument(..., help="agent_id"),
    page: Optional[int] = typer.Option(
        None, "--page", help="Page number (1-indexed) for page-based pagination."
    ),
    page_size: Optional[int] = typer.Option(
        None, "--page-size", help="Number of items per page."
    ),
    version: Optional[str] = typer.Option(
        None, "--version", help="Filter by version string."
    ),
):
    """List agent sessions."""
    client = get_client()
    params: dict = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if version is not None:
        params["version"] = version
    r = client.get(f"/agents/{agent_id}/sessions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="list-sessions", help="List agent sessions")(
    _agents_list_sessions
)


@handle_api_errors
def _agents_disable_sub(
    agent_id: int = typer.Argument(..., help="agent_id"),
    child_agent_id: int = typer.Argument(..., help="child_agent_id"),
):
    """Disable sub agent."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/agents/{agent_id}/subagents/{child_agent_id}/disable")
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="disable-sub", help="Disable sub agent")(_agents_disable_sub)


@handle_api_errors
def _agents_enable_sub(
    agent_id: int = typer.Argument(..., help="agent_id"),
    child_agent_id: int = typer.Argument(..., help="child_agent_id"),
):
    """Enable sub agent."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/agents/{agent_id}/subagents/{child_agent_id}/enable")
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="enable-sub", help="Enable sub agent")(_agents_enable_sub)


@handle_api_errors
def _agents_remove_sub(
    agent_id: int = typer.Argument(..., help="agent_id"),
    child_agent_id: int = typer.Argument(..., help="child_agent_id"),
):
    """Remove sub agent."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/agents/{agent_id}/subagents/{child_agent_id}", params=params)
    console.print("[green]Deleted.[/green]")


agents_app.command(name="remove-sub", help="Remove sub agent")(_agents_remove_sub)


@handle_api_errors
def _agents_list_sub(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """List sub agents."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/subagents", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="list-sub", help="List sub agents")(_agents_list_sub)


@handle_api_errors
def _agents_add_sub(
    agent_id: int = typer.Argument(..., help="agent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_child_agent_id: Optional[int] = typer.Option(
        None, "--child-agent-id", help="child_agent_id. Required."
    ),
):
    """Add sub agent."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_child_agent_id is not None:
        body["child_agent_id"] = body_arg_child_agent_id
    required_fields = ("child_agent_id",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/agents/{agent_id}/subagents", json=body)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="add-sub", help="Add sub agent")(_agents_add_sub)


@handle_api_errors
def _agents_get_task_timeline(
    agent_id: int = typer.Argument(..., help="agent_id"),
    task_id: int = typer.Argument(..., help="task_id"),
):
    """Get agent task timeline."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/tasks/{task_id}/timeline", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-task-timeline", help="Get agent task timeline")(
    _agents_get_task_timeline
)


@handle_api_errors
def _agents_get_version(
    agent_id: int = typer.Argument(..., help="agent_id"),
    version: str = typer.Argument(..., help="version"),
):
    """Get agent version."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/versions/{version}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="get-version", help="Get agent version")(_agents_get_version)


@handle_api_errors
def _agents_list_versions(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """List agent versions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/agents/{agent_id}/versions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


agents_app.command(name="list-versions", help="List agent versions")(
    _agents_list_versions
)


analytics_app = typer.Typer(
    name="analytics", help="Manage analytics.", no_args_is_help=True
)


@handle_api_errors
def _analytics_get_agent_request(
    agent_id: int = typer.Argument(..., help="agent_id"),
):
    """Get agent request analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/analytics/agents/{agent_id}/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(name="get-agent-request", help="Get agent request analytics")(
    _analytics_get_agent_request
)


@handle_api_errors
def _analytics_get_application_fault_rate(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """Get application fault rate analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/analytics/applications/{application_id}/fault-rate", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-application-fault-rate", help="Get application fault rate analytics"
)(_analytics_get_application_fault_rate)


@handle_api_errors
def _analytics_get_application_action_fault_rate(
    application_id: int = typer.Argument(..., help="application_id"),
    action_id: int = typer.Argument(..., help="action_id"),
):
    """Get application action fault rate analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/analytics/applications/{application_id}/intents/{action_id}/fault-rate",
        params=params,
    )
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-application-action-fault-rate",
    help="Get application action fault rate analytics",
)(_analytics_get_application_action_fault_rate)


@handle_api_errors
def _analytics_get_application_action_request(
    application_id: int = typer.Argument(..., help="application_id"),
    action_id: int = typer.Argument(..., help="action_id"),
):
    """Get application action request analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/analytics/applications/{application_id}/intents/{action_id}/requests",
        params=params,
    )
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-application-action-request",
    help="Get application action request analytics",
)(_analytics_get_application_action_request)


@handle_api_errors
def _analytics_get_application_request(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """Get application request analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/analytics/applications/{application_id}/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-application-request", help="Get application request analytics"
)(_analytics_get_application_request)


@handle_api_errors
def _analytics_get_company_application_activity():
    """Get company application activity analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/analytics/company/application-activity", params=params)
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-company-application-activity",
    help="Get company application activity analytics",
)(_analytics_get_company_application_activity)


@handle_api_errors
def _analytics_get_company_model_usage():
    """Get company model usage analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/analytics/company/model-usage", params=params)
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-company-model-usage", help="Get company model usage analytics"
)(_analytics_get_company_model_usage)


@handle_api_errors
def _analytics_get_company_request():
    """Get company request analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/analytics/company/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(name="get-company-request", help="Get company request analytics")(
    _analytics_get_company_request
)


@handle_api_errors
def _analytics_get_intent_group_fault_rate(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """Get intent group fault rate analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/analytics/intent-groups/{intent_group_id}/fault-rate", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-intent-group-fault-rate", help="Get intent group fault rate analytics"
)(_analytics_get_intent_group_fault_rate)


@handle_api_errors
def _analytics_get_intent_group_request(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """Get intent group request analytics."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/analytics/intent-groups/{intent_group_id}/requests", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


analytics_app.command(
    name="get-intent-group-request", help="Get intent group request analytics"
)(_analytics_get_intent_group_request)


applications_app = typer.Typer(
    name="applications", help="Manage applications.", no_args_is_help=True
)


@handle_api_errors
def _applications_list(
    detailed: Optional[bool] = typer.Option(
        None, "--detailed", help="Include full configuration details in results."
    ),
):
    """List applications."""
    client = get_client()
    params: dict = {}
    if detailed is not None:
        params["detailed"] = detailed
    r = client.get(f"/applications", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="list", help="List applications")(_applications_list)


@handle_api_errors
def _applications_get(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """Get application."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/applications/{application_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="get", help="Get application")(_applications_get)


@handle_api_errors
def _applications_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_application_name: Optional[str] = typer.Option(
        None, "--application-name", help="application_name. Required."
    ),
):
    """Create application."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_application_name is not None:
        body["application_name"] = body_arg_application_name
    required_fields = ("application_name",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/applications", json=body)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="create", help="Create application")(_applications_create)


@handle_api_errors
def _applications_update(
    application_id: int = typer.Argument(..., help="application_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update application."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/applications/{application_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="update", help="Update application")(_applications_update)


@handle_api_errors
def _applications_delete(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """Delete application."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/applications/{application_id}", params=params)
    console.print("[green]Deleted.[/green]")


applications_app.command(name="delete", help="Delete application")(_applications_delete)


@handle_api_errors
def _applications_get_config(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """Get application config."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/applications/{application_id}/config", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="get-config", help="Get application config")(
    _applications_get_config
)


@handle_api_errors
def _applications_update_config(
    application_id: int = typer.Argument(..., help="application_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update application config."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/applications/{application_id}/config", json=body)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="update-config", help="Update application config")(
    _applications_update_config
)


@handle_api_errors
def _applications_reset_intent_config(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """Reset intent config."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/applications/{application_id}/intents/{intent_id}/config/reset")
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="reset-intent-config", help="Reset intent config")(
    _applications_reset_intent_config
)


@handle_api_errors
def _applications_get_intent_config(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """Get intent config."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/applications/{application_id}/intents/{intent_id}/config", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="get-intent-config", help="Get intent config")(
    _applications_get_intent_config
)


@handle_api_errors
def _applications_update_intent_config(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update intent config."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(
        f"/applications/{application_id}/intents/{intent_id}/config", json=body
    )
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="update-intent-config", help="Update intent config")(
    _applications_update_intent_config
)


@handle_api_errors
def _applications_disable_intent_notifications(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """Disable intent notifications."""
    client = get_client()
    params: dict = {}
    r = client.put(
        f"/applications/{application_id}/intents/{intent_id}/notifications/disable"
    )
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(
    name="disable-intent-notifications", help="Disable intent notifications"
)(_applications_disable_intent_notifications)


@handle_api_errors
def _applications_enable_intent_notifications(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """Enable intent notifications."""
    client = get_client()
    params: dict = {}
    r = client.put(
        f"/applications/{application_id}/intents/{intent_id}/notifications/enable"
    )
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(
    name="enable-intent-notifications", help="Enable intent notifications"
)(_applications_enable_intent_notifications)


@handle_api_errors
def _applications_delete_intent(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """Delete application intent."""
    client = get_client()
    params: dict = {}
    r = client.delete(
        f"/applications/{application_id}/intents/{intent_id}", params=params
    )
    console.print("[green]Deleted.[/green]")


applications_app.command(name="delete-intent", help="Delete application intent")(
    _applications_delete_intent
)


@handle_api_errors
def _applications_get_intent(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """Get application intent."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/applications/{application_id}/intents/{intent_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="get-intent", help="Get application intent")(
    _applications_get_intent
)


@handle_api_errors
def _applications_list_intents(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """List application intents."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/applications/{application_id}/intents", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="list-intents", help="List application intents")(
    _applications_list_intents
)


@handle_api_errors
def _applications_create_intent(
    application_id: int = typer.Argument(..., help="application_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Create application intent."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/applications/{application_id}/intents", json=body)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="create-intent", help="Create application intent")(
    _applications_create_intent
)


@handle_api_errors
def _applications_list_models(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """List application models."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/applications/{application_id}/models", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="list-models", help="List application models")(
    _applications_list_models
)


@handle_api_errors
def _applications_list_sessions(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """List application sessions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/applications/{application_id}/sessions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(name="list-sessions", help="List application sessions")(
    _applications_list_sessions
)


@handle_api_errors
def _applications_list_workflow_runs(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """List application workflow runs."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/applications/{application_id}/workflow-runs", params=params)
    print_json(r.get("data", r), r.get("pagination"))


applications_app.command(
    name="list-workflow-runs", help="List application workflow runs"
)(_applications_list_workflow_runs)


compositions_app = typer.Typer(
    name="compositions", help="Manage compositions.", no_args_is_help=True
)


@handle_api_errors
def _compositions_list(
    composition_type: Optional[str] = typer.Option(
        None, "--composition-type", help="composition_type"
    ),
):
    """List compositions."""
    client = get_client()
    params: dict = {}
    if composition_type is not None:
        params["composition_type"] = composition_type
    r = client.get(f"/compositions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(name="list", help="List compositions")(_compositions_list)


@handle_api_errors
def _compositions_get(
    composition_id: int = typer.Argument(..., help="composition_id"),
):
    """Get composition."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/compositions/{composition_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(name="get", help="Get composition")(_compositions_get)


@handle_api_errors
def _compositions_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Create composition."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/compositions", json=body)
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(name="create", help="Create composition")(_compositions_create)


@handle_api_errors
def _compositions_update(
    composition_id: int = typer.Argument(..., help="composition_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update composition."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/compositions/{composition_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(name="update", help="Update composition")(_compositions_update)


@handle_api_errors
def _compositions_delete(
    composition_id: int = typer.Argument(..., help="composition_id"),
):
    """Delete composition."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/compositions/{composition_id}", params=params)
    console.print("[green]Deleted.[/green]")


compositions_app.command(name="delete", help="Delete composition")(_compositions_delete)


@handle_api_errors
def _compositions_list_by_application_intent(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """List compositions by application intent."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/compositions/applications/{application_id}/intents/{intent_id}",
        params=params,
    )
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(
    name="list-by-application-intent", help="List compositions by application intent"
)(_compositions_list_by_application_intent)


@handle_api_errors
def _compositions_list_by_intent_group(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List compositions by intent group."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/compositions/intent-groups/{intent_group_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(
    name="list-by-intent-group", help="List compositions by intent group"
)(_compositions_list_by_intent_group)


@handle_api_errors
def _compositions_validate_rl(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Validate rl composition."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/compositions/validate-rl", json=body)
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(name="validate-rl", help="Validate rl composition")(
    _compositions_validate_rl
)


@handle_api_errors
def _compositions_list_versions(
    composition_id: int = typer.Argument(..., help="composition_id"),
):
    """List composition versions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/compositions/{composition_id}/versions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


compositions_app.command(name="list-versions", help="List composition versions")(
    _compositions_list_versions
)


conversation_trees_app = typer.Typer(
    name="conversation-trees", help="Manage conversation-trees.", no_args_is_help=True
)


@handle_api_errors
def _conversation_trees_list(
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
):
    """List conversation trees."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    r = client.get(f"/conversation-trees", params=params)
    print_json(r.get("data", r), r.get("pagination"))


conversation_trees_app.command(name="list", help="List conversation trees")(
    _conversation_trees_list
)


@handle_api_errors
def _conversation_trees_get(
    tree_id: str = typer.Argument(..., help="tree_id"),
):
    """Get conversation tree."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/conversation-trees/{tree_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


conversation_trees_app.command(name="get", help="Get conversation tree")(
    _conversation_trees_get
)


@handle_api_errors
def _conversation_trees_delete(
    tree_id: str = typer.Argument(..., help="tree_id"),
):
    """Delete conversation tree."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/conversation-trees/{tree_id}", params=params)
    console.print("[green]Deleted.[/green]")


conversation_trees_app.command(name="delete", help="Delete conversation tree")(
    _conversation_trees_delete
)


@handle_api_errors
def _conversation_trees_get_status(
    tree_id: str = typer.Argument(..., help="tree_id"),
):
    """Get conversation tree status."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/conversation-trees/{tree_id}/status", params=params)
    print_json(r.get("data", r), r.get("pagination"))


conversation_trees_app.command(name="get-status", help="Get conversation tree status")(
    _conversation_trees_get_status
)


@handle_api_errors
def _conversation_trees_list_versions(
    tree_id: str = typer.Argument(..., help="tree_id"),
):
    """List conversation tree versions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/conversation-trees/{tree_id}/versions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


conversation_trees_app.command(
    name="list-versions", help="List conversation tree versions"
)(_conversation_trees_list_versions)


dashboard_app = typer.Typer(
    name="dashboard", help="Manage dashboard.", no_args_is_help=True
)


@handle_api_errors
def _dashboard_get_action_items():
    """Get action items."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/dashboard/action-items", params=params)
    print_json(r.get("data", r), r.get("pagination"))


dashboard_app.command(name="get-action-items", help="Get action items")(
    _dashboard_get_action_items
)


@handle_api_errors
def _dashboard_get_alerts():
    """Get alerts."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/dashboard/alerts", params=params)
    print_json(r.get("data", r), r.get("pagination"))


dashboard_app.command(name="get-alerts", help="Get alerts")(_dashboard_get_alerts)


datasets_app = typer.Typer(
    name="datasets", help="Manage datasets.", no_args_is_help=True
)


@handle_api_errors
def _datasets_list():
    """List datasets."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list", help="List datasets")(_datasets_list)


@handle_api_errors
def _datasets_get(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Get dataset."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="get", help="Get dataset")(_datasets_get)


@handle_api_errors
def _datasets_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_name: Optional[str] = typer.Option(None, "--name", help="name. Required."),
    body_arg_data_source: Optional[str] = typer.Option(
        None, "--data-source", help="data_source. Required."
    ),
    body_arg_intent_group_id: Optional[int] = typer.Option(
        None, "--intent-group-id", help="intent_group_id."
    ),
    body_arg_application_id: Optional[int] = typer.Option(
        None, "--application-id", help="application_id."
    ),
    body_arg_intent_id: Optional[int] = typer.Option(
        None, "--intent-id", help="intent_id."
    ),
    body_arg_description: Optional[str] = typer.Option(
        None, "--description", help="description."
    ),
    body_arg_sample_type: Optional[str] = typer.Option(
        None, "--sample-type", help="sample_type."
    ),
    body_arg_sample_percentage: Optional[int] = typer.Option(
        None, "--sample-percentage", help="sample_percentage."
    ),
    body_arg_date_start: Optional[int] = typer.Option(
        None, "--date-start", help="date_start."
    ),
    body_arg_date_end: Optional[int] = typer.Option(
        None, "--date-end", help="date_end."
    ),
    body_arg_s3_url: Optional[str] = typer.Option(None, "--s3-url", help="s3_url."),
    body_arg_s3_region: Optional[str] = typer.Option(
        None, "--s3-region", help="s3_region."
    ),
    body_arg_s3_file_glob: Optional[str] = typer.Option(
        None, "--s3-file-glob", help="s3_file_glob."
    ),
):
    """Create dataset."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_name is not None:
        body["name"] = body_arg_name
    if body_arg_data_source is not None:
        body["data_source"] = body_arg_data_source
    if body_arg_intent_group_id is not None:
        body["intent_group_id"] = body_arg_intent_group_id
    if body_arg_application_id is not None:
        body["application_id"] = body_arg_application_id
    if body_arg_intent_id is not None:
        body["intent_id"] = body_arg_intent_id
    if body_arg_description is not None:
        body["description"] = body_arg_description
    if body_arg_sample_type is not None:
        body["sample_type"] = body_arg_sample_type
    if body_arg_sample_percentage is not None:
        body["sample_percentage"] = body_arg_sample_percentage
    if body_arg_date_start is not None:
        body["date_start"] = body_arg_date_start
    if body_arg_date_end is not None:
        body["date_end"] = body_arg_date_end
    if body_arg_s3_url is not None:
        body["s3_url"] = body_arg_s3_url
    if body_arg_s3_region is not None:
        body["s3_region"] = body_arg_s3_region
    if body_arg_s3_file_glob is not None:
        body["s3_file_glob"] = body_arg_s3_file_glob
    required_fields = ("name", "data_source")
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/datasets", json=body)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="create", help="Create dataset")(_datasets_create)


@handle_api_errors
def _datasets_update(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update dataset."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/datasets/{dataset_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="update", help="Update dataset")(_datasets_update)


@handle_api_errors
def _datasets_delete(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
    cascade: Optional[str] = typer.Option(None, "--cascade", help="cascade"),
):
    """Delete dataset."""
    client = get_client()
    params: dict = {}
    if cascade is not None:
        params["cascade"] = cascade
    r = client.delete(f"/datasets/{dataset_id}", params=params)
    console.print("[green]Deleted.[/green]")


datasets_app.command(name="delete", help="Delete dataset")(_datasets_delete)


@handle_api_errors
def _datasets_list_by_intent(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """List datasets by intent."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/datasets/applications/{application_id}/intents/{intent_id}", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-by-intent", help="List datasets by intent")(
    _datasets_list_by_intent
)


@handle_api_errors
def _datasets_list_by_tags():
    """List datasets by tags."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/by-tags", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-by-tags", help="List datasets by tags")(
    _datasets_list_by_tags
)


@handle_api_errors
def _datasets_get_estimated_request_count():
    """Get estimated dataset request count."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/estimated-request-count", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="get-estimated-request-count", help="Get estimated dataset request count"
)(_datasets_get_estimated_request_count)


@handle_api_errors
def _datasets_estimate_generation_cost():
    """Estimate dataset generation cost."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/generate/estimate-cost")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="estimate-generation-cost", help="Estimate dataset generation cost"
)(_datasets_estimate_generation_cost)


@handle_api_errors
def _datasets_preview_generation():
    """Preview dataset generation."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/generate/preview")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="preview-generation", help="Preview dataset generation")(
    _datasets_preview_generation
)


@handle_api_errors
def _datasets_start_generation():
    """Start dataset generation."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/generate")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="start-generation", help="Start dataset generation")(
    _datasets_start_generation
)


@handle_api_errors
def _datasets_list_by_intent_group(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List datasets by intent group."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/intent-groups/{intent_group_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-by-intent-group", help="List datasets by intent group")(
    _datasets_list_by_intent_group
)


@handle_api_errors
def _datasets_get_3_syncer_info():
    """Get dataset s3 syncer info."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/s3/syncer-info", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="get-3-syncer-info", help="Get dataset s3 syncer info")(
    _datasets_get_3_syncer_info
)


@handle_api_errors
def _datasets_validate_3_source():
    """Validate dataset s3 source."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/s3/validate")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="validate-3-source", help="Validate dataset s3 source")(
    _datasets_validate_3_source
)


@handle_api_errors
def _datasets_list_valid_tags():
    """List valid dataset tags."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/tags/valid", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-valid-tags", help="List valid dataset tags")(
    _datasets_list_valid_tags
)


@handle_api_errors
def _datasets_list_by_test_set(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """List datasets by test set."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/test-sets/{test_set_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-by-test-set", help="List datasets by test set")(
    _datasets_list_by_test_set
)


@handle_api_errors
def _datasets_search_added_requests(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Search added dataset requests."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/added-requests/search")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="search-added-requests", help="Search added dataset requests"
)(_datasets_search_added_requests)


@handle_api_errors
def _datasets_clone(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Clone dataset."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/clone")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="clone", help="Clone dataset")(_datasets_clone)


@handle_api_errors
def _datasets_get_delete_impact(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Get dataset delete impact."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/delete-impact", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="get-delete-impact", help="Get dataset delete impact")(
    _datasets_get_delete_impact
)


@handle_api_errors
def _datasets_search_eligible_requests(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Search eligible dataset requests."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/eligible-requests/search")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="search-eligible-requests", help="Search eligible dataset requests"
)(_datasets_search_eligible_requests)


@handle_api_errors
def _datasets_list_eligible_requests(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """List eligible dataset requests."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/eligible-requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="list-eligible-requests", help="List eligible dataset requests"
)(_datasets_list_eligible_requests)


@handle_api_errors
def _datasets_cancel_generation(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Cancel dataset generation."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/generate/cancel")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="cancel-generation", help="Cancel dataset generation")(
    _datasets_cancel_generation
)


@handle_api_errors
def _datasets_pause_generation(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Pause dataset generation."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/generate/pause")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="pause-generation", help="Pause dataset generation")(
    _datasets_pause_generation
)


@handle_api_errors
def _datasets_resume_generation(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Resume dataset generation."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/generate/resume")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="resume-generation", help="Resume dataset generation")(
    _datasets_resume_generation
)


@handle_api_errors
def _datasets_get_prompt(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Get dataset prompt."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/prompt", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="get-prompt", help="Get dataset prompt")(_datasets_get_prompt)


@handle_api_errors
def _datasets_apply_prune(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Apply dataset prune."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/prune/apply")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="apply-prune", help="Apply dataset prune")(
    _datasets_apply_prune
)


@handle_api_errors
def _datasets_preview_prune(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Preview dataset prune."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/prune/preview")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="preview-prune", help="Preview dataset prune")(
    _datasets_preview_prune
)


@handle_api_errors
def _datasets_augment_reasoning(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Augment dataset reasoning."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/reasoning/augment")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="augment-reasoning", help="Augment dataset reasoning")(
    _datasets_augment_reasoning
)


@handle_api_errors
def _datasets_get_regex_replacements_applicable_count(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Get dataset regex replacements applicable count."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/regex-replacements/count")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="get-regex-replacements-applicable-count",
    help="Get dataset regex replacements applicable count",
)(_datasets_get_regex_replacements_applicable_count)


@handle_api_errors
def _datasets_apply_regex_replacements(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Apply dataset regex replacements."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/regex-replacements")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="apply-regex-replacements", help="Apply dataset regex replacements"
)(_datasets_apply_regex_replacements)


@handle_api_errors
def _datasets_get_request_distribution(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Get dataset request distribution."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/request-distribution", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="get-request-distribution", help="Get dataset request distribution"
)(_datasets_get_request_distribution)


@handle_api_errors
def _datasets_list_request_ids(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """List dataset request ids."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/request-ids", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-request-ids", help="List dataset request ids")(
    _datasets_list_request_ids
)


@handle_api_errors
def _datasets_add_requests_bulk(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Add dataset requests bulk."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/datasets/{dataset_id}/requests/add")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="add-requests-bulk", help="Add dataset requests bulk")(
    _datasets_add_requests_bulk
)


@handle_api_errors
def _datasets_remove_requests_bulk(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Remove dataset requests bulk."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/datasets/{dataset_id}/requests/remove")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="remove-requests-bulk", help="Remove dataset requests bulk")(
    _datasets_remove_requests_bulk
)


@handle_api_errors
def _datasets_get_request_reasoning(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
    request_id: int = typer.Argument(..., help="request_id"),
):
    """Get dataset request reasoning."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/datasets/{dataset_id}/requests/{request_id}/reasoning", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(
    name="get-request-reasoning", help="Get dataset request reasoning"
)(_datasets_get_request_reasoning)


@handle_api_errors
def _datasets_remove_requests(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Remove requests from dataset."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/datasets/{dataset_id}/requests", params=params)
    console.print("[green]Deleted.[/green]")


datasets_app.command(name="remove-requests", help="Remove requests from dataset")(
    _datasets_remove_requests
)


@handle_api_errors
def _datasets_list_requests(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """List dataset requests."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-requests", help="List dataset requests")(
    _datasets_list_requests
)


@handle_api_errors
def _datasets_add_requests(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_request_ids: Optional[str] = typer.Option(
        None, "--request-ids", help="request_ids. Required. Pass as JSON."
    ),
):
    """Add requests to dataset."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_request_ids is not None:
        body["request_ids"] = json.loads(body_arg_request_ids)
    required_fields = ("request_ids",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/datasets/{dataset_id}/requests", json=body)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="add-requests", help="Add requests to dataset")(
    _datasets_add_requests
)


@handle_api_errors
def _datasets_cancel_3_import(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Cancel dataset s3 import."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/s3/cancel")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="cancel-3-import", help="Cancel dataset s3 import")(
    _datasets_cancel_3_import
)


@handle_api_errors
def _datasets_reimport_3_source(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Reimport dataset s3 source."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/s3/reimport")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="reimport-3-source", help="Reimport dataset s3 source")(
    _datasets_reimport_3_source
)


@handle_api_errors
def _datasets_sample_clone(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Sample clone dataset."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/sample-clone")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="sample-clone", help="Sample clone dataset")(
    _datasets_sample_clone
)


@handle_api_errors
def _datasets_get_status(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Get dataset status."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/status", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="get-status", help="Get dataset status")(_datasets_get_status)


@handle_api_errors
def _datasets_remove_tag(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
    tag: int = typer.Argument(..., help="tag"),
):
    """Remove dataset tag."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/datasets/{dataset_id}/tags/{tag}", params=params)
    console.print("[green]Deleted.[/green]")


datasets_app.command(name="remove-tag", help="Remove dataset tag")(_datasets_remove_tag)


@handle_api_errors
def _datasets_list_tags(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """List dataset tags."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/tags", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-tags", help="List dataset tags")(_datasets_list_tags)


@handle_api_errors
def _datasets_add_tag(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Add dataset tag."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/datasets/{dataset_id}/tags")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="add-tag", help="Add dataset tag")(_datasets_add_tag)


@handle_api_errors
def _datasets_set_tags(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """Set dataset tags."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/datasets/{dataset_id}/tags")
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="set-tags", help="Set dataset tags")(_datasets_set_tags)


@handle_api_errors
def _datasets_list_versions(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """List dataset versions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/datasets/{dataset_id}/versions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


datasets_app.command(name="list-versions", help="List dataset versions")(
    _datasets_list_versions
)


evaluation_criteria_app = typer.Typer(
    name="evaluation-criteria", help="Manage evaluation-criteria.", no_args_is_help=True
)


@handle_api_errors
def _evaluation_criteria_list():
    """List evaluation criteria."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/evaluation-criteria", params=params)
    print_json(r.get("data", r), r.get("pagination"))


evaluation_criteria_app.command(name="list", help="List evaluation criteria")(
    _evaluation_criteria_list
)


@handle_api_errors
def _evaluation_criteria_create():
    """Create evaluation criteria."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/evaluation-criteria")
    print_json(r.get("data", r), r.get("pagination"))


evaluation_criteria_app.command(name="create", help="Create evaluation criteria")(
    _evaluation_criteria_create
)


@handle_api_errors
def _evaluation_criteria_update(
    criteria_id: int = typer.Argument(..., help="criteria_id"),
):
    """Update evaluation criteria."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/evaluation-criteria/{criteria_id}")
    print_json(r.get("data", r), r.get("pagination"))


evaluation_criteria_app.command(name="update", help="Update evaluation criteria")(
    _evaluation_criteria_update
)


@handle_api_errors
def _evaluation_criteria_delete(
    criteria_id: int = typer.Argument(..., help="criteria_id"),
):
    """Delete evaluation criteria."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/evaluation-criteria/{criteria_id}", params=params)
    console.print("[green]Deleted.[/green]")


evaluation_criteria_app.command(name="delete", help="Delete evaluation criteria")(
    _evaluation_criteria_delete
)


@handle_api_errors
def _evaluation_criteria_list_available():
    """List available evaluation criteria."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/evaluation-criteria/available", params=params)
    print_json(r.get("data", r), r.get("pagination"))


evaluation_criteria_app.command(
    name="list-available", help="List available evaluation criteria"
)(_evaluation_criteria_list_available)


evaluations_app = typer.Typer(
    name="evaluations", help="Manage evaluations.", no_args_is_help=True
)


@handle_api_errors
def _evaluations_list():
    """List evaluations."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/evaluations", params=params)
    print_json(r.get("data", r), r.get("pagination"))


evaluations_app.command(name="list", help="List evaluations")(_evaluations_list)


@handle_api_errors
def _evaluations_get(
    evaluation_run_id: str = typer.Argument(..., help="evaluation_run_id"),
    full: Optional[bool] = typer.Option(
        None, "--full", help="Include full evaluation details."
    ),
):
    """Get evaluation."""
    client = get_client()
    params: dict = {}
    if full is not None:
        params["full"] = full
    r = client.get(f"/evaluations/{evaluation_run_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


evaluations_app.command(name="get", help="Get evaluation")(_evaluations_get)


@handle_api_errors
def _evaluations_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_application_id: Optional[int] = typer.Option(
        None, "--application-id", help="application_id. Required."
    ),
    body_arg_intent_id: Optional[int] = typer.Option(
        None, "--intent-id", help="intent_id. Required."
    ),
):
    """Create evaluation."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_application_id is not None:
        body["application_id"] = body_arg_application_id
    if body_arg_intent_id is not None:
        body["intent_id"] = body_arg_intent_id
    required_fields = ("application_id", "intent_id")
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/evaluations", json=body)
    print_json(r.get("data", r), r.get("pagination"))


evaluations_app.command(name="create", help="Create evaluation")(_evaluations_create)


@handle_api_errors
def _evaluations_get_results(
    evaluation_run_id: str = typer.Argument(..., help="evaluation_run_id"),
):
    """Get evaluation results."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/evaluations/{evaluation_run_id}/results", params=params)
    print_json(r.get("data", r), r.get("pagination"))


evaluations_app.command(name="get-results", help="Get evaluation results")(
    _evaluations_get_results
)


finetune_runs_app = typer.Typer(
    name="finetune-runs", help="Manage finetune-runs.", no_args_is_help=True
)


@handle_api_errors
def _finetune_runs_list(
    status: Optional[str] = typer.Option(
        None, "--status", help="Filter by status (can be specified multiple times)."
    ),
):
    """List finetune runs."""
    client = get_client()
    params: dict = {}
    if status is not None:
        params["status"] = status
    r = client.get(f"/finetune-runs", params=params)
    print_json(r.get("data", r), r.get("pagination"))


finetune_runs_app.command(name="list", help="List finetune runs")(_finetune_runs_list)


@handle_api_errors
def _finetune_runs_get(
    run_id: int = typer.Argument(..., help="run_id"),
):
    """Get finetune run."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/finetune-runs/{run_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


finetune_runs_app.command(name="get", help="Get finetune run")(_finetune_runs_get)


@handle_api_errors
def _finetune_runs_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_display_name: Optional[str] = typer.Option(
        None, "--display-name", help="display_name. Required."
    ),
    body_arg_base_model: Optional[str] = typer.Option(
        None, "--base-model", help="base_model. Required."
    ),
    body_arg_status: Optional[str] = typer.Option(
        None, "--run-status", help="status. Required."
    ),
    body_arg_meta: Optional[str] = typer.Option(
        None, "--meta", help="meta. Required. Pass as JSON."
    ),
):
    """Create finetune run."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_display_name is not None:
        body["display_name"] = body_arg_display_name
    if body_arg_base_model is not None:
        body["base_model"] = body_arg_base_model
    if body_arg_status is not None:
        body["status"] = body_arg_status
    if body_arg_meta is not None:
        body["meta"] = json.loads(body_arg_meta)
    required_fields = ("display_name", "base_model", "status", "meta")
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/finetune-runs", json=body)
    print_json(r.get("data", r), r.get("pagination"))


finetune_runs_app.command(name="create", help="Create finetune run")(
    _finetune_runs_create
)


@handle_api_errors
def _finetune_runs_cancel(
    run_id: int = typer.Argument(..., help="run_id"),
):
    """Cancel finetune run."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/finetune-runs/{run_id}/cancel")
    print_json(r.get("data", r), r.get("pagination"))


finetune_runs_app.command(name="cancel", help="Cancel finetune run")(
    _finetune_runs_cancel
)


@handle_api_errors
def _finetune_runs_get_metrics(
    run_id: int = typer.Argument(..., help="run_id"),
):
    """Get finetune run metrics."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/finetune-runs/{run_id}/metrics", params=params)
    print_json(r.get("data", r), r.get("pagination"))


finetune_runs_app.command(name="get-metrics", help="Get finetune run metrics")(
    _finetune_runs_get_metrics
)


intent_groups_app = typer.Typer(
    name="intent-groups", help="Manage intent-groups.", no_args_is_help=True
)


@handle_api_errors
def _intent_groups_list():
    """List intent groups."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="list", help="List intent groups")(_intent_groups_list)


@handle_api_errors
def _intent_groups_get(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
    detailed: Optional[bool] = typer.Option(
        None, "--detailed", help="Include full configuration details in results."
    ),
):
    """Get intent group."""
    client = get_client()
    params: dict = {}
    if detailed is not None:
        params["detailed"] = detailed
    r = client.get(f"/intent-groups/{intent_group_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="get", help="Get intent group")(_intent_groups_get)


@handle_api_errors
def _intent_groups_list_compositions(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List intent group compositions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups/{intent_group_id}/compositions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(
    name="list-compositions", help="List intent group compositions"
)(_intent_groups_list_compositions)


@handle_api_errors
def _intent_groups_get_config(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """Get intent group config."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups/{intent_group_id}/config", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="get-config", help="Get intent group config")(
    _intent_groups_get_config
)


@handle_api_errors
def _intent_groups_update_config(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update intent group config."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/intent-groups/{intent_group_id}/config", json=body)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="update-config", help="Update intent group config")(
    _intent_groups_update_config
)


@handle_api_errors
def _intent_groups_list_datasets(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List intent group datasets."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups/{intent_group_id}/datasets", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="list-datasets", help="List intent group datasets")(
    _intent_groups_list_datasets
)


@handle_api_errors
def _intent_groups_list_intents(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List intents by group."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups/{intent_group_id}/intents", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="list-intents", help="List intents by group")(
    _intent_groups_list_intents
)


@handle_api_errors
def _intent_groups_list_models(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List intent group models."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups/{intent_group_id}/models", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="list-models", help="List intent group models")(
    _intent_groups_list_models
)


@handle_api_errors
def _intent_groups_list_requests(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
    start_date: Optional[int] = typer.Option(
        None,
        "--start-date",
        help="Start of date range as Unix timestamp (milliseconds).",
    ),
    end_date: Optional[int] = typer.Option(
        None, "--end-date", help="End of date range as Unix timestamp (milliseconds)."
    ),
    include_messages: Optional[bool] = typer.Option(
        None, "--include-messages", help="Include full message history in results."
    ),
):
    """List intent group requests."""
    client = get_client()
    params: dict = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if include_messages is not None:
        params["include_messages"] = include_messages
    r = client.get(f"/intent-groups/{intent_group_id}/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="list-requests", help="List intent group requests")(
    _intent_groups_list_requests
)


@handle_api_errors
def _intent_groups_list_sentinels(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List intent group sentinels."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups/{intent_group_id}/sentinels", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="list-sentinels", help="List intent group sentinels")(
    _intent_groups_list_sentinels
)


@handle_api_errors
def _intent_groups_list_test_sets(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List intent group test sets."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/intent-groups/{intent_group_id}/test-sets", params=params)
    print_json(r.get("data", r), r.get("pagination"))


intent_groups_app.command(name="list-test-sets", help="List intent group test sets")(
    _intent_groups_list_test_sets
)


models_app = typer.Typer(name="models", help="Manage models.", no_args_is_help=True)


@handle_api_errors
def _models_list(
    model_type: Optional[str] = typer.Option(
        None,
        "--model-type",
        help="Filter by model type (can be specified multiple times).",
    ),
):
    """List models."""
    client = get_client()
    params: dict = {}
    if model_type is not None:
        params["model_type"] = model_type
    r = client.get(f"/models", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="list", help="List models")(_models_list)


@handle_api_errors
def _models_get(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Get model."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/{model_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="get", help="Get model")(_models_get)


@handle_api_errors
def _models_list_by_application(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """List models by application."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/applications/{application_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="list-by-application", help="List models by application")(
    _models_list_by_application
)


@handle_api_errors
def _models_list_available():
    """List available models."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/available", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="list-available", help="List available models")(
    _models_list_available
)


@handle_api_errors
def _models_create_base():
    """Create base model."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/base-model")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="create-base", help="Create base model")(_models_create_base)


@handle_api_errors
def _models_list_by_intent_group(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List models by intent group."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/intent-groups/{intent_group_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="list-by-intent-group", help="List models by intent group")(
    _models_list_by_intent_group
)


@handle_api_errors
def _models_list_by_intent(
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """List models by intent."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/intents/{intent_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="list-by-intent", help="List models by intent")(
    _models_list_by_intent
)


@handle_api_errors
def _models_disable(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Disable model."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/{model_id}/disable")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="disable", help="Disable model")(_models_disable)


@handle_api_errors
def _models_enable(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Enable model."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/{model_id}/enable")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="enable", help="Enable model")(_models_enable)


@handle_api_errors
def _models_list_inference_pool_attach_candidates(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """List model inference pool attach candidates."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/models/{model_id}/inference-pool/attach-candidates", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(
    name="list-inference-pool-attach-candidates",
    help="List model inference pool attach candidates",
)(_models_list_inference_pool_attach_candidates)


@handle_api_errors
def _models_attach_inference_pool(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Attach model inference pool."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/{model_id}/inference-pool/attach")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="attach-inference-pool", help="Attach model inference pool")(
    _models_attach_inference_pool
)


@handle_api_errors
def _models_get_inference_pool_debug(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Get model inference pool debug."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/{model_id}/inference-pool/debug", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(
    name="get-inference-pool-debug", help="Get model inference pool debug"
)(_models_get_inference_pool_debug)


@handle_api_errors
def _models_detach_inference_pool(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Detach model inference pool."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/{model_id}/inference-pool/detach")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="detach-inference-pool", help="Detach model inference pool")(
    _models_detach_inference_pool
)


@handle_api_errors
def _models_get_inference_pool(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Get model inference pool."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/{model_id}/inference-pool", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="get-inference-pool", help="Get model inference pool")(
    _models_get_inference_pool
)


@handle_api_errors
def _models_patch_registry(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Patch model registry."""
    client = get_client()
    params: dict = {}
    r = client.patch(f"/models/{model_id}/registry")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="patch-registry", help="Patch model registry")(
    _models_patch_registry
)


@handle_api_errors
def _models_get_repoint_options(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Get model repoint options."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/models/{model_id}/repoint-options", params=params)
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="get-repoint-options", help="Get model repoint options")(
    _models_get_repoint_options
)


@handle_api_errors
def _models_repoint(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Repoint model."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/{model_id}/repoint")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="repoint", help="Repoint model")(_models_repoint)


@handle_api_errors
def _models_execute_swap_ref(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Execute swap model ref."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/{model_id}/swap-model-ref/execute")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="execute-swap-ref", help="Execute swap model ref")(
    _models_execute_swap_ref
)


@handle_api_errors
def _models_preview_swap_ref(
    model_id: int = typer.Argument(..., help="model_id"),
):
    """Preview swap model ref."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/models/{model_id}/swap-model-ref/preview")
    print_json(r.get("data", r), r.get("pagination"))


models_app.command(name="preview-swap-ref", help="Preview swap model ref")(
    _models_preview_swap_ref
)


monitors_app = typer.Typer(
    name="monitors", help="Manage monitors.", no_args_is_help=True
)


@handle_api_errors
def _monitors_list(
    search: Optional[str] = typer.Option(None, "--search", help="search"),
    status: Optional[str] = typer.Option(
        None, "--status", help="Filter by status (can be specified multiple times)."
    ),
):
    """List monitors."""
    client = get_client()
    params: dict = {}
    if search is not None:
        params["search"] = search
    if status is not None:
        params["status"] = status
    r = client.get(f"/monitors", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list", help="List monitors")(_monitors_list)


@handle_api_errors
def _monitors_get(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """Get monitor."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get", help="Get monitor")(_monitors_get)


@handle_api_errors
def _monitors_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Create monitor."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/monitors", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="create", help="Create monitor")(_monitors_create)


@handle_api_errors
def _monitors_update(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update monitor."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/monitors/{monitor_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="update", help="Update monitor")(_monitors_update)


@handle_api_errors
def _monitors_delete(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """Delete monitor."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/monitors/{monitor_id}", params=params)
    console.print("[green]Deleted.[/green]")


monitors_app.command(name="delete", help="Delete monitor")(_monitors_delete)


@handle_api_errors
def _monitors_list_by_target(
    target_type: Optional[str] = typer.Option(
        None, "--target-type", help="target_type"
    ),
    target_id: Optional[str] = typer.Option(None, "--target-id", help="target_id"),
):
    """List monitors by target."""
    client = get_client()
    params: dict = {}
    if target_type is not None:
        params["target_type"] = target_type
    if target_id is not None:
        params["target_id"] = target_id
    r = client.get(f"/monitors/by-target", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list-by-target", help="List monitors by target")(
    _monitors_list_by_target
)


@handle_api_errors
def _monitors_list_runs_by_source(
    source_type: Optional[str] = typer.Option(
        None, "--source-type", help="source_type"
    ),
    source_type_id: Optional[str] = typer.Option(
        None, "--source-type-id", help="source_type_id"
    ),
):
    """List runs by source."""
    client = get_client()
    params: dict = {}
    if source_type is not None:
        params["source_type"] = source_type
    if source_type_id is not None:
        params["source_type_id"] = source_type_id
    r = client.get(f"/monitors/runs/by-source", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list-runs-by-source", help="List runs by source")(
    _monitors_list_runs_by_source
)


@handle_api_errors
def _monitors_get_run_global(
    run_id: int = typer.Argument(..., help="run_id"),
):
    """Get run global."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/runs/{run_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-run-global", help="Get run global")(
    _monitors_get_run_global
)


@handle_api_errors
def _monitors_list_runs_global(
    monitor_id: Optional[int] = typer.Option(None, "--monitor-id", help="monitor_id"),
):
    """List runs global."""
    client = get_client()
    params: dict = {}
    if monitor_id is not None:
        params["monitor_id"] = monitor_id
    r = client.get(f"/monitors/runs", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list-runs-global", help="List runs global")(
    _monitors_list_runs_global
)


@handle_api_errors
def _monitors_get_target_sample(
    target_type: Optional[str] = typer.Option(
        None, "--target-type", help="target_type"
    ),
    target_id: Optional[str] = typer.Option(None, "--target-id", help="target_id"),
):
    """Get target sample."""
    client = get_client()
    params: dict = {}
    if target_type is not None:
        params["target_type"] = target_type
    if target_id is not None:
        params["target_id"] = target_id
    r = client.get(f"/monitors/sample-target", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-target-sample", help="Get target sample")(
    _monitors_get_target_sample
)


@handle_api_errors
def _monitors_activate(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """Activate monitor."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/monitors/{monitor_id}/activate")
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="activate", help="Activate monitor")(_monitors_activate)


@handle_api_errors
def _monitors_get_activity(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: Optional[int] = typer.Option(
        None, "--monitor-target-id", help="monitor_target_id"
    ),
    bucket_seconds: Optional[int] = typer.Option(
        None, "--bucket-seconds", help="bucket_seconds"
    ),
):
    """Get monitor activity."""
    client = get_client()
    params: dict = {}
    if monitor_target_id is not None:
        params["monitor_target_id"] = monitor_target_id
    if bucket_seconds is not None:
        params["bucket_seconds"] = bucket_seconds
    r = client.get(f"/monitors/{monitor_id}/activity", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-activity", help="Get monitor activity")(
    _monitors_get_activity
)


@handle_api_errors
def _monitors_get_metrics_by_target(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """Get monitor metrics by target."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/metrics/by-target", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(
    name="get-metrics-by-target", help="Get monitor metrics by target"
)(_monitors_get_metrics_by_target)


@handle_api_errors
def _monitors_get_metrics(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: Optional[int] = typer.Option(
        None, "--monitor-target-id", help="monitor_target_id"
    ),
):
    """Get monitor metrics."""
    client = get_client()
    params: dict = {}
    if monitor_target_id is not None:
        params["monitor_target_id"] = monitor_target_id
    r = client.get(f"/monitors/{monitor_id}/metrics", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-metrics", help="Get monitor metrics")(
    _monitors_get_metrics
)


@handle_api_errors
def _monitors_pause(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """Pause monitor."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/monitors/{monitor_id}/pause")
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="pause", help="Pause monitor")(_monitors_pause)


@handle_api_errors
def _monitors_preview(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Preview monitor."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/monitors/{monitor_id}/preview", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="preview", help="Preview monitor")(_monitors_preview)


@handle_api_errors
def _monitors_get_default_version(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """Get default monitor version."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/releases/default", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-default-version", help="Get default monitor version")(
    _monitors_get_default_version
)


@handle_api_errors
def _monitors_promote_release(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    release_name: int = typer.Argument(..., help="release_name"),
):
    """Promote monitor release."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/monitors/{monitor_id}/releases/{release_name}/promote")
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="promote-release", help="Promote monitor release")(
    _monitors_promote_release
)


@handle_api_errors
def _monitors_delete_release(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    release_name: int = typer.Argument(..., help="release_name"),
):
    """Delete monitor release."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/monitors/{monitor_id}/releases/{release_name}", params=params)
    console.print("[green]Deleted.[/green]")


monitors_app.command(name="delete-release", help="Delete monitor release")(
    _monitors_delete_release
)


@handle_api_errors
def _monitors_list_releases(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """List monitor releases."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/releases", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list-releases", help="List monitor releases")(
    _monitors_list_releases
)


@handle_api_errors
def _monitors_upsert_release(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Upsert monitor release."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/monitors/{monitor_id}/releases", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="upsert-release", help="Upsert monitor release")(
    _monitors_upsert_release
)


@handle_api_errors
def _monitors_upsert_release_put_monitor_id_releases(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Upsert monitor release."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/monitors/{monitor_id}/releases", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(
    name="upsert-release-put-monitor-id-releases", help="Upsert monitor release"
)(_monitors_upsert_release_put_monitor_id_releases)


@handle_api_errors
def _monitors_get_run_scoped(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    run_id: int = typer.Argument(..., help="run_id"),
):
    """Get run scoped."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/runs/{run_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-run-scoped", help="Get run scoped")(
    _monitors_get_run_scoped
)


@handle_api_errors
def _monitors_list_runs(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """List runs for monitor."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/runs", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list-runs", help="List runs for monitor")(
    _monitors_list_runs
)


@handle_api_errors
def _monitors_disable_target(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: int = typer.Argument(..., help="monitor_target_id"),
):
    """Disable monitor target."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/monitors/{monitor_id}/targets/{monitor_target_id}/disable")
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="disable-target", help="Disable monitor target")(
    _monitors_disable_target
)


@handle_api_errors
def _monitors_enable_target(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: int = typer.Argument(..., help="monitor_target_id"),
):
    """Enable monitor target."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/monitors/{monitor_id}/targets/{monitor_target_id}/enable")
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="enable-target", help="Enable monitor target")(
    _monitors_enable_target
)


@handle_api_errors
def _monitors_get_target_metrics(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: int = typer.Argument(..., help="monitor_target_id"),
):
    """Get monitor target metrics."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/monitors/{monitor_id}/targets/{monitor_target_id}/metrics", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-target-metrics", help="Get monitor target metrics")(
    _monitors_get_target_metrics
)


@handle_api_errors
def _monitors_get_target_sparkline(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: int = typer.Argument(..., help="monitor_target_id"),
    bucket_seconds: Optional[int] = typer.Option(
        None, "--bucket-seconds", help="bucket_seconds"
    ),
):
    """Get monitor target sparkline."""
    client = get_client()
    params: dict = {}
    if bucket_seconds is not None:
        params["bucket_seconds"] = bucket_seconds
    r = client.get(
        f"/monitors/{monitor_id}/targets/{monitor_target_id}/sparkline", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-target-sparkline", help="Get monitor target sparkline")(
    _monitors_get_target_sparkline
)


@handle_api_errors
def _monitors_delete_target(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: int = typer.Argument(..., help="monitor_target_id"),
):
    """Delete monitor target."""
    client = get_client()
    params: dict = {}
    r = client.delete(
        f"/monitors/{monitor_id}/targets/{monitor_target_id}", params=params
    )
    console.print("[green]Deleted.[/green]")


monitors_app.command(name="delete-target", help="Delete monitor target")(
    _monitors_delete_target
)


@handle_api_errors
def _monitors_update_target_patch_monitor_id_targets_monitor_target_id(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: int = typer.Argument(..., help="monitor_target_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update monitor target."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.patch(f"/monitors/{monitor_id}/targets/{monitor_target_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(
    name="update-target-patch-monitor-id-targets-monitor-target-id",
    help="Update monitor target",
)(_monitors_update_target_patch_monitor_id_targets_monitor_target_id)


@handle_api_errors
def _monitors_update_target(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    monitor_target_id: int = typer.Argument(..., help="monitor_target_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update monitor target."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/monitors/{monitor_id}/targets/{monitor_target_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="update-target", help="Update monitor target")(
    _monitors_update_target
)


@handle_api_errors
def _monitors_list_targets(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """List monitor targets."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/targets", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list-targets", help="List monitor targets")(
    _monitors_list_targets
)


@handle_api_errors
def _monitors_create_target(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Create monitor target."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/monitors/{monitor_id}/targets", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="create-target", help="Create monitor target")(
    _monitors_create_target
)


@handle_api_errors
def _monitors_get_version(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    version_id: int = typer.Argument(..., help="version_id"),
):
    """Get monitor version."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/versions/{version_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="get-version", help="Get monitor version")(
    _monitors_get_version
)


@handle_api_errors
def _monitors_list_versions(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
):
    """List monitor versions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/monitors/{monitor_id}/versions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="list-versions", help="List monitor versions")(
    _monitors_list_versions
)


@handle_api_errors
def _monitors_publish_version(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Publish monitor version."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/monitors/{monitor_id}/versions", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="publish-version", help="Publish monitor version")(
    _monitors_publish_version
)


@handle_api_errors
def _monitors_update_patch_monitor_id(
    monitor_id: int = typer.Argument(..., help="monitor_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update monitor."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.patch(f"/monitors/{monitor_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


monitors_app.command(name="update-patch-monitor-id", help="Update monitor")(
    _monitors_update_patch_monitor_id
)


reports_app = typer.Typer(name="reports", help="Manage reports.", no_args_is_help=True)


@handle_api_errors
def _reports_list_fallbacks():
    """List fallbacks."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/reports/fallbacks", params=params)
    print_json(r.get("data", r), r.get("pagination"))


reports_app.command(name="list-fallbacks", help="List fallbacks")(
    _reports_list_fallbacks
)


@handle_api_errors
def _reports_list_faults():
    """List faults."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/reports/faults", params=params)
    print_json(r.get("data", r), r.get("pagination"))


reports_app.command(name="list-faults", help="List faults")(_reports_list_faults)


@handle_api_errors
def _reports_list_fallbacks_by_intent(
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """List fallbacks by intent."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/reports/intents/{intent_id}/fallbacks", params=params)
    print_json(r.get("data", r), r.get("pagination"))


reports_app.command(name="list-fallbacks-by-intent", help="List fallbacks by intent")(
    _reports_list_fallbacks_by_intent
)


@handle_api_errors
def _reports_list_faults_by_intent(
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """List faults by intent."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/reports/intents/{intent_id}/faults", params=params)
    print_json(r.get("data", r), r.get("pagination"))


reports_app.command(name="list-faults-by-intent", help="List faults by intent")(
    _reports_list_faults_by_intent
)


requests_app = typer.Typer(
    name="requests", help="Manage requests.", no_args_is_help=True
)


@handle_api_errors
def _requests_list(
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
    intent_id: Optional[int] = typer.Option(
        None, "--intent-id", help="Filter by intent ID."
    ),
    start_date: Optional[int] = typer.Option(
        None,
        "--start-date",
        help="Start of date range as Unix timestamp (milliseconds).",
    ),
    end_date: Optional[int] = typer.Option(
        None, "--end-date", help="End of date range as Unix timestamp (milliseconds)."
    ),
    include_messages: Optional[bool] = typer.Option(
        None, "--include-messages", help="Include full message history in results."
    ),
):
    """List requests."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    if intent_id is not None:
        params["intent_id"] = intent_id
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if include_messages is not None:
        params["include_messages"] = include_messages
    r = client.get(f"/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


requests_app.command(name="list", help="List requests")(_requests_list)


@handle_api_errors
def _requests_get(
    request_id: int = typer.Argument(..., help="request_id"),
):
    """Get request."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/requests/{request_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


requests_app.command(name="get", help="Get request")(_requests_get)


@handle_api_errors
def _requests_update_response(
    request_id: int = typer.Argument(..., help="request_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update request response."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/requests/{request_id}/response", json=body)
    print_json(r.get("data", r), r.get("pagination"))


requests_app.command(name="update-response", help="Update request response")(
    _requests_update_response
)


sentinels_app = typer.Typer(
    name="sentinels", help="Manage sentinels.", no_args_is_help=True
)


@handle_api_errors
def _sentinels_list():
    """List sentinels."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/sentinels", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="list", help="List sentinels")(_sentinels_list)


@handle_api_errors
def _sentinels_get(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
):
    """Get sentinel."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/sentinels/{sentinel_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="get", help="Get sentinel")(_sentinels_get)


@handle_api_errors
def _sentinels_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_sentinel_name: Optional[str] = typer.Option(
        None, "--sentinel-name", help="sentinel_name. Required."
    ),
    body_arg_severity: Optional[int] = typer.Option(
        None, "--severity", help="severity. Required."
    ),
):
    """Create sentinel."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_sentinel_name is not None:
        body["sentinel_name"] = body_arg_sentinel_name
    if body_arg_severity is not None:
        body["severity"] = body_arg_severity
    required_fields = ("sentinel_name", "severity")
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/sentinels", json=body)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="create", help="Create sentinel")(_sentinels_create)


@handle_api_errors
def _sentinels_update(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update sentinel."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/sentinels/{sentinel_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="update", help="Update sentinel")(_sentinels_update)


@handle_api_errors
def _sentinels_delete(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
):
    """Delete sentinel."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/sentinels/{sentinel_id}", params=params)
    console.print("[green]Deleted.[/green]")


sentinels_app.command(name="delete", help="Delete sentinel")(_sentinels_delete)


@handle_api_errors
def _sentinels_list_by_application_human_needs(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """List sentinels by application human needs."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/sentinels/applications/{application_id}/human-needs", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(
    name="list-by-application-human-needs",
    help="List sentinels by application human needs",
)(_sentinels_list_by_application_human_needs)


@handle_api_errors
def _sentinels_list_by_application(
    application_id: int = typer.Argument(..., help="application_id"),
):
    """List sentinels by application."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/sentinels/applications/{application_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="list-by-application", help="List sentinels by application")(
    _sentinels_list_by_application
)


@handle_api_errors
def _sentinels_generate_new():
    """Generate new sentinel."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/sentinels/generate/new")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="generate-new", help="Generate new sentinel")(
    _sentinels_generate_new
)


@handle_api_errors
def _sentinels_generate():
    """Generate sentinels."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/sentinels/generate")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="generate", help="Generate sentinels")(_sentinels_generate)


@handle_api_errors
def _sentinels_list_by_intent_name(
    intent_name: int = typer.Argument(..., help="intent_name"),
):
    """List sentinels by intent name."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/sentinels/intent-groups/by-name/{intent_name}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="list-by-intent-name", help="List sentinels by intent name")(
    _sentinels_list_by_intent_name
)


@handle_api_errors
def _sentinels_list_by_intent_group(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List sentinels by intent group."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/sentinels/intent-groups/{intent_group_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(
    name="list-by-intent-group", help="List sentinels by intent group"
)(_sentinels_list_by_intent_group)


@handle_api_errors
def _sentinels_regenerate():
    """Regenerate sentinels."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/sentinels/regenerate")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="regenerate", help="Regenerate sentinels")(
    _sentinels_regenerate
)


@handle_api_errors
def _sentinels_list_simple():
    """List simple sentinels."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/sentinels/simple", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="list-simple", help="List simple sentinels")(
    _sentinels_list_simple
)


@handle_api_errors
def _sentinels_update_directive(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
):
    """Update sentinel directive."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/sentinels/{sentinel_id}/directive")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(name="update-directive", help="Update sentinel directive")(
    _sentinels_update_directive
)


@handle_api_errors
def _sentinels_regenerate_correction(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
):
    """Regenerate sentinel correction."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/sentinels/{sentinel_id}/regenerate/correction")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(
    name="regenerate-correction", help="Regenerate sentinel correction"
)(_sentinels_regenerate_correction)


@handle_api_errors
def _sentinels_regenerate_evaluation(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
):
    """Regenerate sentinel evaluation."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/sentinels/{sentinel_id}/regenerate/evaluation")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(
    name="regenerate-evaluation", help="Regenerate sentinel evaluation"
)(_sentinels_regenerate_evaluation)


@handle_api_errors
def _sentinels_regenerate_qualification(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
):
    """Regenerate sentinel qualification."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/sentinels/{sentinel_id}/regenerate/qualification")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(
    name="regenerate-qualification", help="Regenerate sentinel qualification"
)(_sentinels_regenerate_qualification)


@handle_api_errors
def _sentinels_regenerate_post_sentinel_id_regenerate(
    sentinel_id: int = typer.Argument(..., help="sentinel_id"),
):
    """Regenerate sentinel."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/sentinels/{sentinel_id}/regenerate")
    print_json(r.get("data", r), r.get("pagination"))


sentinels_app.command(
    name="regenerate-post-sentinel-id-regenerate", help="Regenerate sentinel"
)(_sentinels_regenerate_post_sentinel_id_regenerate)


sessions_app = typer.Typer(
    name="sessions", help="Manage sessions.", no_args_is_help=True
)


@handle_api_errors
def _sessions_list(
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
):
    """List sessions."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    r = client.get(f"/sessions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sessions_app.command(name="list", help="List sessions")(_sessions_list)


@handle_api_errors
def _sessions_get(
    session_id: str = typer.Argument(..., help="session_id"),
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
):
    """Get session."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    r = client.get(f"/sessions/{session_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sessions_app.command(name="get", help="Get session")(_sessions_get)


@handle_api_errors
def _sessions_set_feedback(
    session_id: str = typer.Argument(..., help="session_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Set session feedback."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/sessions/{session_id}/feedback", json=body)
    print_json(r.get("data", r), r.get("pagination"))


sessions_app.command(name="set-feedback", help="Set session feedback")(
    _sessions_set_feedback
)


@handle_api_errors
def _sessions_get_timeline(
    session_id: str = typer.Argument(..., help="session_id"),
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
):
    """Get session timeline."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    r = client.get(f"/sessions/{session_id}/timeline", params=params)
    print_json(r.get("data", r), r.get("pagination"))


sessions_app.command(name="get-timeline", help="Get session timeline")(
    _sessions_get_timeline
)


test_runs_app = typer.Typer(
    name="test-runs", help="Manage test-runs.", no_args_is_help=True
)


@handle_api_errors
def _test_runs_list(
    intent_group_id: Optional[int] = typer.Option(
        None, "--intent-group-id", help="intent_group_id"
    ),
):
    """List test runs."""
    client = get_client()
    params: dict = {}
    if intent_group_id is not None:
        params["intent_group_id"] = intent_group_id
    r = client.get(f"/test-runs", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="list", help="List test runs")(_test_runs_list)


@handle_api_errors
def _test_runs_get(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Get test run."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/{test_run_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="get", help="Get test run")(_test_runs_get)


@handle_api_errors
def _test_runs_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_test_set_id: Optional[int] = typer.Option(
        None, "--test-set-id", help="test_set_id. Required."
    ),
    body_arg_description: Optional[str] = typer.Option(
        None, "--description", help="description."
    ),
    body_arg_config: Optional[str] = typer.Option(
        None, "--config", help="config. Pass as JSON."
    ),
    type: Optional[str] = typer.Option(
        None, "--type", help="Test run type: request or workflow."
    ),
):
    """Create test run."""
    client = get_client()
    params: dict = {}
    if type is not None:
        params["type"] = type
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_test_set_id is not None:
        body["test_set_id"] = body_arg_test_set_id
    if body_arg_description is not None:
        body["description"] = body_arg_description
    if body_arg_config is not None:
        body["config"] = json.loads(body_arg_config)
    required_fields = ("test_set_id",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/test-runs", json=body)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="create", help="Create test run")(_test_runs_create)


@handle_api_errors
def _test_runs_delete(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Delete test run."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/test-runs/{test_run_id}", params=params)
    console.print("[green]Deleted.[/green]")


test_runs_app.command(name="delete", help="Delete test run")(_test_runs_delete)


@handle_api_errors
def _test_runs_compare(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Compare test runs."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.post(f"/test-runs/compare", json=body)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="compare", help="Compare test runs")(_test_runs_compare)


@handle_api_errors
def _test_runs_list_by_intent_group(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List test runs by intent group."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/intent-groups/{intent_group_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(
    name="list-by-intent-group", help="List test runs by intent group"
)(_test_runs_list_by_intent_group)


@handle_api_errors
def _test_runs_get_request_comparison(
    base_request_id: int = typer.Argument(..., help="base_request_id"),
    compare_request_id: int = typer.Argument(..., help="compare_request_id"),
):
    """Get test run request comparison."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/test-runs/requests/compare/{base_request_id}/{compare_request_id}",
        params=params,
    )
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(
    name="get-request-comparison", help="Get test run request comparison"
)(_test_runs_get_request_comparison)


@handle_api_errors
def _test_runs_get_progress_by_set(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """Get test run progress by test set."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/test-sets/{test_set_id}/progress", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(
    name="get-progress-by-set", help="Get test run progress by test set"
)(_test_runs_get_progress_by_set)


@handle_api_errors
def _test_runs_list_by_set(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """List test runs by test set."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/test-sets/{test_set_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="list-by-set", help="List test runs by test set")(
    _test_runs_list_by_set
)


@handle_api_errors
def _test_runs_evaluate(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Evaluate test run."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/test-runs/{test_run_id}/evaluate")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="evaluate", help="Evaluate test run")(_test_runs_evaluate)


@handle_api_errors
def _test_runs_update_item(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
    item_id: int = typer.Argument(..., help="item_id"),
):
    """Update test run item."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/test-runs/{test_run_id}/items/{item_id}")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="update-item", help="Update test run item")(
    _test_runs_update_item
)


@handle_api_errors
def _test_runs_list_items(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """List test run items."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/{test_run_id}/items", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="list-items", help="List test run items")(
    _test_runs_list_items
)


@handle_api_errors
def _test_runs_get_progress(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Get test run progress."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/{test_run_id}/progress", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="get-progress", help="Get test run progress")(
    _test_runs_get_progress
)


@handle_api_errors
def _test_runs_list_requests_with_filters(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
    offset: int = typer.Argument(..., help="offset"),
    limit: int = typer.Argument(..., help="limit"),
):
    """List test run requests with filters."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/test-runs/{test_run_id}/requests/{offset}/{limit}")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(
    name="list-requests-with-filters", help="List test run requests with filters"
)(_test_runs_list_requests_with_filters)


@handle_api_errors
def _test_runs_evaluate_request(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
    test_run_request_id: int = typer.Argument(..., help="test_run_request_id"),
):
    """Evaluate test run request."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/test-runs/{test_run_id}/requests/{test_run_request_id}/evaluate")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="evaluate-request", help="Evaluate test run request")(
    _test_runs_evaluate_request
)


@handle_api_errors
def _test_runs_list_requests(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """List test run requests."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/{test_run_id}/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="list-requests", help="List test run requests")(
    _test_runs_list_requests
)


@handle_api_errors
def _test_runs_get_results(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Get test run results."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/{test_run_id}/results", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="get-results", help="Get test run results")(
    _test_runs_get_results
)


@handle_api_errors
def _test_runs_resume(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Resume test run."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/test-runs/{test_run_id}/resume")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="resume", help="Resume test run")(_test_runs_resume)


@handle_api_errors
def _test_runs_retry(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Retry test run."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/test-runs/{test_run_id}/retry")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="retry", help="Retry test run")(_test_runs_retry)


@handle_api_errors
def _test_runs_list_review_segments(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """List test run review segments."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-runs/{test_run_id}/review-segments", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(
    name="list-review-segments", help="List test run review segments"
)(_test_runs_list_review_segments)


@handle_api_errors
def _test_runs_update_status(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
    status: int = typer.Argument(..., help="status"),
):
    """Update test run status."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/test-runs/{test_run_id}/status/{status}")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="update-status", help="Update test run status")(
    _test_runs_update_status
)


@handle_api_errors
def _test_runs_stop(
    test_run_id: int = typer.Argument(..., help="test_run_id"),
):
    """Stop test run."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/test-runs/{test_run_id}/stop")
    print_json(r.get("data", r), r.get("pagination"))


test_runs_app.command(name="stop", help="Stop test run")(_test_runs_stop)


test_sets_app = typer.Typer(
    name="test-sets", help="Manage test-sets.", no_args_is_help=True
)


@handle_api_errors
def _test_sets_list():
    """List test sets."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="list", help="List test sets")(_test_sets_list)


@handle_api_errors
def _test_sets_get(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """Get test set."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets/{test_set_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="get", help="Get test set")(_test_sets_get)


@handle_api_errors
def _test_sets_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_name: Optional[str] = typer.Option(None, "--name", help="name. Required."),
    body_arg_intent_group_id: Optional[int] = typer.Option(
        None, "--intent-group-id", help="intent_group_id."
    ),
    body_arg_description: Optional[str] = typer.Option(
        None, "--description", help="description."
    ),
    body_arg_golden: Optional[bool] = typer.Option(None, "--golden", help="golden."),
    body_arg_test_set_source: Optional[str] = typer.Option(
        None, "--test-set-source", help="test_set_source."
    ),
    body_arg_request_ids: Optional[str] = typer.Option(
        None, "--request-ids", help="request_ids. Pass as JSON."
    ),
    body_arg_sample_method: Optional[str] = typer.Option(
        None, "--sample-method", help="sample_method."
    ),
    body_arg_sample_percentage: Optional[int] = typer.Option(
        None, "--sample-percentage", help="sample_percentage."
    ),
    body_arg_dataset_id: Optional[int] = typer.Option(
        None, "--dataset-id", help="dataset_id."
    ),
    type: Optional[str] = typer.Option(
        None, "--type", help="Test set type: request or workflow."
    ),
):
    """Create test set."""
    client = get_client()
    params: dict = {}
    if type is not None:
        params["type"] = type
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_name is not None:
        body["name"] = body_arg_name
    if body_arg_intent_group_id is not None:
        body["intent_group_id"] = body_arg_intent_group_id
    if body_arg_description is not None:
        body["description"] = body_arg_description
    if body_arg_golden is not None:
        body["golden"] = body_arg_golden
    if body_arg_test_set_source is not None:
        body["test_set_source"] = body_arg_test_set_source
    if body_arg_request_ids is not None:
        body["request_ids"] = json.loads(body_arg_request_ids)
    if body_arg_sample_method is not None:
        body["sample_method"] = body_arg_sample_method
    if body_arg_sample_percentage is not None:
        body["sample_percentage"] = body_arg_sample_percentage
    if body_arg_dataset_id is not None:
        body["dataset_id"] = body_arg_dataset_id
    required_fields = ("name",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/test-sets", json=body)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="create", help="Create test set")(_test_sets_create)


@handle_api_errors
def _test_sets_update(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
):
    """Update test set."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    r = client.put(f"/test-sets/{test_set_id}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="update", help="Update test set")(_test_sets_update)


@handle_api_errors
def _test_sets_delete(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """Delete test set."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/test-sets/{test_set_id}", params=params)
    console.print("[green]Deleted.[/green]")


test_sets_app.command(name="delete", help="Delete test set")(_test_sets_delete)


@handle_api_errors
def _test_sets_list_by_application_intent(
    application_id: int = typer.Argument(..., help="application_id"),
    intent_id: int = typer.Argument(..., help="intent_id"),
):
    """List test sets by application intent."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/test-sets/applications/{application_id}/intents/{intent_id}", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="list-by-application-intent", help="List test sets by application intent"
)(_test_sets_list_by_application_intent)


@handle_api_errors
def _test_sets_convert_to_workflow():
    """Convert test set to workflow."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/test-sets/convert-to-workflow")
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="convert-to-workflow", help="Convert test set to workflow")(
    _test_sets_convert_to_workflow
)


@handle_api_errors
def _test_sets_list_created_from_dataset(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """List test sets created from dataset."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets/datasets/{dataset_id}/source", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="list-created-from-dataset", help="List test sets created from dataset"
)(_test_sets_list_created_from_dataset)


@handle_api_errors
def _test_sets_list_by_dataset(
    dataset_id: int = typer.Argument(..., help="dataset_id"),
):
    """List test sets by dataset."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets/datasets/{dataset_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="list-by-dataset", help="List test sets by dataset")(
    _test_sets_list_by_dataset
)


@handle_api_errors
def _test_sets_search_eligible_requests(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """Search eligible test set requests."""
    client = get_client()
    params: dict = {}
    r = client.post(
        f"/test-sets/eligible-requests/{intent_group_id}/{test_set_id}/search"
    )
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="search-eligible-requests", help="Search eligible test set requests"
)(_test_sets_search_eligible_requests)


@handle_api_errors
def _test_sets_list_eligible_requests(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
    test_set_id: int = typer.Argument(..., help="test_set_id"),
    before_date: Optional[int] = typer.Option(
        None, "--before-date", help="before_date"
    ),
):
    """List eligible test set requests."""
    client = get_client()
    params: dict = {}
    if before_date is not None:
        params["before_date"] = before_date
    r = client.get(
        f"/test-sets/eligible-requests/{intent_group_id}/{test_set_id}", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="list-eligible-requests", help="List eligible test set requests"
)(_test_sets_list_eligible_requests)


@handle_api_errors
def _test_sets_list_by_intent_group_name(
    intent_group_name: int = typer.Argument(..., help="intent_group_name"),
):
    """List test sets by intent group name."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/test-sets/intent-groups/by-name/{intent_group_name}", params=params
    )
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="list-by-intent-group-name", help="List test sets by intent group name"
)(_test_sets_list_by_intent_group_name)


@handle_api_errors
def _test_sets_list_by_intent_group(
    intent_group_id: int = typer.Argument(..., help="intent_group_id"),
):
    """List test sets by intent group."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets/intent-groups/{intent_group_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="list-by-intent-group", help="List test sets by intent group"
)(_test_sets_list_by_intent_group)


@handle_api_errors
def _test_sets_add_single_request():
    """Add single request to test set."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/test-sets/request/add")
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="add-single-request", help="Add single request to test set")(
    _test_sets_add_single_request
)


@handle_api_errors
def _test_sets_remove_single_request():
    """Remove single request from test set."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/test-sets/request/remove", params=params)
    console.print("[green]Deleted.[/green]")


test_sets_app.command(
    name="remove-single-request", help="Remove single request from test set"
)(_test_sets_remove_single_request)


@handle_api_errors
def _test_sets_add_requests_bulk():
    """Add test set requests bulk."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/test-sets/requests/add")
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="add-requests-bulk", help="Add test set requests bulk")(
    _test_sets_add_requests_bulk
)


@handle_api_errors
def _test_sets_remove_requests_bulk():
    """Remove test set requests bulk."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/test-sets/requests/remove")
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="remove-requests-bulk", help="Remove test set requests bulk"
)(_test_sets_remove_requests_bulk)


@handle_api_errors
def _test_sets_clone(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_new_test_set_name: Optional[str] = typer.Option(
        None, "--new-test-set-name", help="new_test_set_name. Required."
    ),
    body_arg_new_test_set_description: Optional[str] = typer.Option(
        None, "--new-test-set-description", help="new_test_set_description."
    ),
    body_arg_sample_mode: Optional[str] = typer.Option(
        None, "--sample-mode", help="sample_mode."
    ),
    body_arg_percentage: Optional[float] = typer.Option(
        None, "--percentage", help="percentage."
    ),
    body_arg_request_count: Optional[int] = typer.Option(
        None, "--request-count", help="request_count."
    ),
    type: Optional[str] = typer.Option(
        None, "--type", help="Test set type: request or workflow."
    ),
):
    """Clone test set."""
    client = get_client()
    params: dict = {}
    if type is not None:
        params["type"] = type
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_new_test_set_name is not None:
        body["new_test_set_name"] = body_arg_new_test_set_name
    if body_arg_new_test_set_description is not None:
        body["new_test_set_description"] = body_arg_new_test_set_description
    if body_arg_sample_mode is not None:
        body["sample_mode"] = body_arg_sample_mode
    if body_arg_percentage is not None:
        body["percentage"] = body_arg_percentage
    if body_arg_request_count is not None:
        body["request_count"] = body_arg_request_count
    required_fields = ("new_test_set_name",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/test-sets/{test_set_id}/clone", json=body)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="clone", help="Clone test set")(_test_sets_clone)


@handle_api_errors
def _test_sets_get_prompt_template(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """Get test set prompt template."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets/{test_set_id}/prompt-template", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="get-prompt-template", help="Get test set prompt template")(
    _test_sets_get_prompt_template
)


@handle_api_errors
def _test_sets_get_request_distribution(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """Get test set request distribution."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets/{test_set_id}/request-distribution", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="get-request-distribution", help="Get test set request distribution"
)(_test_sets_get_request_distribution)


@handle_api_errors
def _test_sets_update_request_response(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
    request_id: int = typer.Argument(..., help="request_id"),
):
    """Update test set request response."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/test-sets/{test_set_id}/requests/{request_id}/response")
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(
    name="update-request-response", help="Update test set request response"
)(_test_sets_update_request_response)


@handle_api_errors
def _test_sets_update_request_tags(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
    request_id: int = typer.Argument(..., help="request_id"),
):
    """Update test set request tags."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/test-sets/{test_set_id}/requests/{request_id}/tags")
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="update-request-tags", help="Update test set request tags")(
    _test_sets_update_request_tags
)


@handle_api_errors
def _test_sets_remove_requests(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """Remove requests from test set."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/test-sets/{test_set_id}/requests", params=params)
    console.print("[green]Deleted.[/green]")


test_sets_app.command(name="remove-requests", help="Remove requests from test set")(
    _test_sets_remove_requests
)


@handle_api_errors
def _test_sets_list_requests(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
    start_date: Optional[int] = typer.Option(
        None,
        "--start-date",
        help="Start of date range as Unix timestamp (milliseconds).",
    ),
    end_date: Optional[int] = typer.Option(
        None, "--end-date", help="End of date range as Unix timestamp (milliseconds)."
    ),
    tags: Optional[str] = typer.Option(None, "--tags", help="tags"),
    session_id: Optional[str] = typer.Option(None, "--session-id", help="session_id"),
):
    """List test set requests."""
    client = get_client()
    params: dict = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if tags is not None:
        params["tags"] = tags
    if session_id is not None:
        params["session_id"] = session_id
    r = client.get(f"/test-sets/{test_set_id}/requests", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="list-requests", help="List test set requests")(
    _test_sets_list_requests
)


@handle_api_errors
def _test_sets_add_requests(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_request_ids: Optional[str] = typer.Option(
        None, "--request-ids", help="request_ids. Required. Pass as JSON."
    ),
):
    """Add requests to test set."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_request_ids is not None:
        body["request_ids"] = json.loads(body_arg_request_ids)
    required_fields = ("request_ids",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/test-sets/{test_set_id}/requests", json=body)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="add-requests", help="Add requests to test set")(
    _test_sets_add_requests
)


@handle_api_errors
def _test_sets_list_session_facets(
    test_set_id: int = typer.Argument(..., help="test_set_id"),
):
    """List test set session facets."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/test-sets/{test_set_id}/sessions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


test_sets_app.command(name="list-session-facets", help="List test set session facets")(
    _test_sets_list_session_facets
)


workflows_app = typer.Typer(
    name="workflows", help="Manage workflows.", no_args_is_help=True
)


@handle_api_errors
def _workflows_list():
    """List workflows."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="list", help="List workflows")(_workflows_list)


@handle_api_errors
def _workflows_get(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Get workflow."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="get", help="Get workflow")(_workflows_get)


@handle_api_errors
def _workflows_create(
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_workflow_name: Optional[str] = typer.Option(
        None, "--workflow-name", help="workflow_name. Required."
    ),
    body_arg_workflow_ref_name: Optional[str] = typer.Option(
        None, "--workflow-ref-name", help="workflow_ref_name. Required."
    ),
    body_arg_script: Optional[str] = typer.Option(
        None, "--script", help="script. Required."
    ),
    body_arg_application_id: Optional[int] = typer.Option(
        None, "--application-id", help="application_id. Required."
    ),
    body_arg_description: Optional[str] = typer.Option(
        None, "--description", help="description."
    ),
    body_arg_timeout_seconds: Optional[int] = typer.Option(
        None, "--timeout-seconds", help="timeout_seconds."
    ),
    body_arg_transform_enabled: Optional[bool] = typer.Option(
        None, "--transform-enabled", help="transform_enabled."
    ),
    body_arg_transform_session: Optional[str] = typer.Option(
        None, "--transform-session", help="transform_session."
    ),
):
    """Create workflow."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_workflow_name is not None:
        body["workflow_name"] = body_arg_workflow_name
    if body_arg_workflow_ref_name is not None:
        body["workflow_ref_name"] = body_arg_workflow_ref_name
    if body_arg_script is not None:
        body["script"] = body_arg_script
    if body_arg_application_id is not None:
        body["application_id"] = body_arg_application_id
    if body_arg_description is not None:
        body["description"] = body_arg_description
    if body_arg_timeout_seconds is not None:
        body["timeout_seconds"] = body_arg_timeout_seconds
    if body_arg_transform_enabled is not None:
        body["transform_enabled"] = body_arg_transform_enabled
    if body_arg_transform_session is not None:
        body["transform_session"] = body_arg_transform_session
    required_fields = ("workflow_name", "workflow_ref_name", "script", "application_id")
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/workflows", json=body)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="create", help="Create workflow")(_workflows_create)


@handle_api_errors
def _workflows_update(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Update workflow."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/workflows/{workflow_id}")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="update", help="Update workflow")(_workflows_update)


@handle_api_errors
def _workflows_delete(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Delete workflow."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/workflows/{workflow_id}", params=params)
    console.print("[green]Deleted.[/green]")


workflows_app.command(name="delete", help="Delete workflow")(_workflows_delete)


@handle_api_errors
def _workflows_create_chat_completion():
    """Create workflow chat completion."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/workflows/chat/completions")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(
    name="create-chat-completion", help="Create workflow chat completion"
)(_workflows_create_chat_completion)


@handle_api_errors
def _workflows_get_default_script():
    """Get default workflow script."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/default-script", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="get-default-script", help="Get default workflow script")(
    _workflows_get_default_script
)


@handle_api_errors
def _workflows_get_run(
    session_id: str = typer.Argument(..., help="session_id"),
):
    """Get workflow run."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/runs/{session_id}", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="get-run", help="Get workflow run")(_workflows_get_run)


@handle_api_errors
def _workflows_list_runs():
    """List workflow runs."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/runs", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="list-runs", help="List workflow runs")(_workflows_list_runs)


@handle_api_errors
def _workflows_validate_script():
    """Validate workflow script."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/workflows/validate")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="validate-script", help="Validate workflow script")(
    _workflows_validate_script
)


@handle_api_errors
def _workflows_delete_accessory(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Delete workflow accessory."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/workflows/{workflow_id}/accessories", params=params)
    console.print("[green]Deleted.[/green]")


workflows_app.command(name="delete-accessory", help="Delete workflow accessory")(
    _workflows_delete_accessory
)


@handle_api_errors
def _workflows_upload_accessory(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Upload workflow accessory."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/workflows/{workflow_id}/accessories")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="upload-accessory", help="Upload workflow accessory")(
    _workflows_upload_accessory
)


@handle_api_errors
def _workflows_get_artifact_files(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Get workflow artifact files."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/artifact-files", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="get-artifact-files", help="Get workflow artifact files")(
    _workflows_get_artifact_files
)


@handle_api_errors
def _workflows_upload_datastore(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
    name: str = typer.Argument(..., help="name"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_s3_uri: Optional[str] = typer.Option(None, "--s3-uri", help="s3_uri."),
    body_arg_records: Optional[str] = typer.Option(
        None, "--records", help="records. Pass as JSON."
    ),
):
    """Upload workflow datastore."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_s3_uri is not None:
        body["s3_uri"] = body_arg_s3_uri
    if body_arg_records is not None:
        body["records"] = json.loads(body_arg_records)
    r = client.post(f"/workflows/{workflow_id}/datastores/{name}/upload", json=body)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="upload-datastore", help="Upload workflow datastore")(
    _workflows_upload_datastore
)


@handle_api_errors
def _workflows_delete_datastore(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
    name: str = typer.Argument(..., help="name"),
):
    """Delete workflow datastore."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/workflows/{workflow_id}/datastores/{name}", params=params)
    console.print("[green]Deleted.[/green]")


workflows_app.command(name="delete-datastore", help="Delete workflow datastore")(
    _workflows_delete_datastore
)


@handle_api_errors
def _workflows_upsert_datastore(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
    name: str = typer.Argument(..., help="name"),
    body_json: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body escape hatch"
    ),
    body_arg_schema: Optional[str] = typer.Option(
        None, "--schema", help="schema. Required. Pass as JSON."
    ),
):
    """Upsert workflow datastore."""
    client = get_client()
    params: dict = {}
    import json

    body = json.loads(body_json) if body_json else {}
    if body_arg_schema is not None:
        body["schema"] = json.loads(body_arg_schema)
    required_fields = ("schema",)
    missing = [name for name in required_fields if body.get(name) is None]
    if missing:
        raise typer.BadParameter(
            f"Missing required option(s): {', '.join(missing)}. Pass named -- options or include them in --body JSON."
        )
    r = client.post(f"/workflows/{workflow_id}/datastores/{name}", json=body)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="upsert-datastore", help="Upsert workflow datastore")(
    _workflows_upsert_datastore
)


@handle_api_errors
def _workflows_list_datastores(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """List workflow datastores."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/datastores", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="list-datastores", help="List workflow datastores")(
    _workflows_list_datastores
)


@handle_api_errors
def _workflows_check_transforms(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Check workflow transforms."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/has-transforms", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="check-transforms", help="Check workflow transforms")(
    _workflows_check_transforms
)


@handle_api_errors
def _workflows_clear_default_release(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Clear workflow default release."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/workflows/{workflow_id}/releases/clear-default")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(
    name="clear-default-release", help="Clear workflow default release"
)(_workflows_clear_default_release)


@handle_api_errors
def _workflows_delete_release(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
    name: str = typer.Argument(..., help="name"),
):
    """Delete workflow release."""
    client = get_client()
    params: dict = {}
    r = client.delete(f"/workflows/{workflow_id}/releases/{name}", params=params)
    console.print("[green]Deleted.[/green]")


workflows_app.command(name="delete-release", help="Delete workflow release")(
    _workflows_delete_release
)


@handle_api_errors
def _workflows_update_release(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
    name: str = typer.Argument(..., help="name"),
):
    """Update workflow release."""
    client = get_client()
    params: dict = {}
    r = client.put(f"/workflows/{workflow_id}/releases/{name}")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="update-release", help="Update workflow release")(
    _workflows_update_release
)


@handle_api_errors
def _workflows_list_releases(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """List workflow releases."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/releases", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="list-releases", help="List workflow releases")(
    _workflows_list_releases
)


@handle_api_errors
def _workflows_create_release(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Create workflow release."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/workflows/{workflow_id}/releases")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="create-release", help="Create workflow release")(
    _workflows_create_release
)


@handle_api_errors
def _workflows_get_schema(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Get workflow schema."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/schema", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="get-schema", help="Get workflow schema")(
    _workflows_get_schema
)


@handle_api_errors
def _workflows_get_script(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Get workflow script."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/script", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="get-script", help="Get workflow script")(
    _workflows_get_script
)


@handle_api_errors
def _workflows_get_transform_info(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Get workflow transform info."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/transform-info", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="get-transform-info", help="Get workflow transform info")(
    _workflows_get_transform_info
)


@handle_api_errors
def _workflows_preview_transform(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Preview workflow transform."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/workflows/{workflow_id}/transform-preview")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="preview-transform", help="Preview workflow transform")(
    _workflows_preview_transform
)


@handle_api_errors
def _workflows_get_version_artifact_files(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
    version_number: int = typer.Argument(..., help="version_number"),
):
    """Get workflow version artifact files."""
    client = get_client()
    params: dict = {}
    r = client.get(
        f"/workflows/{workflow_id}/versions/{version_number}/artifact-files",
        params=params,
    )
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(
    name="get-version-artifact-files", help="Get workflow version artifact files"
)(_workflows_get_version_artifact_files)


@handle_api_errors
def _workflows_list_versions(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """List workflow versions."""
    client = get_client()
    params: dict = {}
    r = client.get(f"/workflows/{workflow_id}/versions", params=params)
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="list-versions", help="List workflow versions")(
    _workflows_list_versions
)


@handle_api_errors
def _workflows_publish_version(
    workflow_id: int = typer.Argument(..., help="workflow_id"),
):
    """Publish workflow version."""
    client = get_client()
    params: dict = {}
    r = client.post(f"/workflows/{workflow_id}/versions")
    print_json(r.get("data", r), r.get("pagination"))


workflows_app.command(name="publish-version", help="Publish workflow version")(
    _workflows_publish_version
)


def register_commands(typer_app: typer.Typer) -> None:
    """Register all generated commands with the Typer app."""
    typer_app.add_typer(agents_app, name="agents")
    typer_app.add_typer(analytics_app, name="analytics")
    typer_app.add_typer(applications_app, name="applications")
    typer_app.add_typer(compositions_app, name="compositions")
    typer_app.add_typer(conversation_trees_app, name="conversation-trees")
    typer_app.add_typer(dashboard_app, name="dashboard")
    typer_app.add_typer(datasets_app, name="datasets")
    typer_app.add_typer(evaluation_criteria_app, name="evaluation-criteria")
    typer_app.add_typer(evaluations_app, name="evaluations")
    typer_app.add_typer(finetune_runs_app, name="finetune-runs")
    typer_app.add_typer(intent_groups_app, name="intent-groups")
    typer_app.add_typer(models_app, name="models")
    typer_app.add_typer(monitors_app, name="monitors")
    typer_app.add_typer(reports_app, name="reports")
    typer_app.add_typer(requests_app, name="requests")
    typer_app.add_typer(sentinels_app, name="sentinels")
    typer_app.add_typer(sessions_app, name="sessions")
    typer_app.add_typer(test_runs_app, name="test-runs")
    typer_app.add_typer(test_sets_app, name="test-sets")
    typer_app.add_typer(workflows_app, name="workflows")
