"""Maitai CLI - Command-line interface for the Maitai Platform Developer API."""

__version__ = "0.1.17"
