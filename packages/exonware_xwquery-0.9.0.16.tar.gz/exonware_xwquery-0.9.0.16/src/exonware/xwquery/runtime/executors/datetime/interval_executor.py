#!/usr/bin/env python3
"""
INTERVAL Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.16
"""

from datetime import datetime, date, timedelta, timezone
from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


def _parse_datetime(val):
    if isinstance(val, datetime):
        return val
    if isinstance(val, date):
        return datetime.combine(val, datetime.min.time())
    if isinstance(val, (int, float)):
        return datetime.fromtimestamp(val)
    if isinstance(val, str):
        for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%m/%d/%Y'):
            try:
                return datetime.strptime(val, fmt)
            except ValueError:
                continue
    return None


class IntervalExecutor(AUniversalOperationExecutor):
    OPERATION_NAME = "INTERVAL"
    OPERATION_TYPE = OperationType.ADVANCED
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_op(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _build_timedelta(self, value: int, unit: str) -> Optional[timedelta]:
        mapping = {
            "days": {"days": value},
            "hours": {"hours": value},
            "minutes": {"minutes": value},
            "seconds": {"seconds": value},
            "weeks": {"weeks": value},
        }
        kwargs = mapping.get(unit)
        if not kwargs:
            return None
        return timedelta(**kwargs)

    def _execute_op(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        items = extract_items(node)
        as_field = params.get("as_field", "_interval")
        unit = str(params.get("unit", "seconds")).lower()
        value = params.get("value", 0)

        try:
            int_value = int(value)
        except (TypeError, ValueError):
            int_value = 0

        delta = self._build_timedelta(int_value, unit)
        interval_seconds = delta.total_seconds() if delta is not None else None

        if not items:
            return {"value": interval_seconds, "count": 1}

        result_items = []
        for item in items:
            item_copy = item.copy() if isinstance(item, dict) else {"value": item}
            item_copy[as_field] = interval_seconds
            result_items.append(item_copy)

        return {"items": result_items, "count": len(result_items), "field": as_field}


__all__ = ["IntervalExecutor"]
