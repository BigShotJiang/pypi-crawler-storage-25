#!/usr/bin/env python3
"""
ARRAY_CONCAT Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.16
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class ArrayConcatExecutor(AUniversalOperationExecutor):
    """ARRAY_CONCAT - Concatenate values from multiple array fields."""
    OPERATION_NAME = "ARRAY_CONCAT"
    OPERATION_TYPE = OperationType.ARRAY
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_op(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _execute_op(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        fields: list[str] = params.get("fields", [])
        as_field: str = params.get("as_field", "_array_concat")
        items = extract_items(node)

        result_items = []
        for item in items:
            item_copy = item.copy() if isinstance(item, dict) else {"value": item}
            concatenated: list[Any] = []
            for field in fields:
                value = extract_field_value(item, field)
                if isinstance(value, list):
                    concatenated.extend(value)
                elif value is not None:
                    concatenated.append(value)
            item_copy[as_field] = concatenated
            result_items.append(item_copy)

        return {
            "items": result_items,
            "count": len(result_items),
            "total_items": len(items),
            "fields": fields,
            "as_field": as_field,
        }


__all__ = ["ArrayConcatExecutor"]
