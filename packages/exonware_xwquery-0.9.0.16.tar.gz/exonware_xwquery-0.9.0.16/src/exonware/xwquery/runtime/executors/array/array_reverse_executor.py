#!/usr/bin/env python3
"""
ARRAY_REVERSE Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.16
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class ArrayReverseExecutor(AUniversalOperationExecutor):
    """ARRAY_REVERSE - Reverse an array using list slicing."""
    OPERATION_NAME = "ARRAY_REVERSE"
    OPERATION_TYPE = OperationType.ARRAY
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_op(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _execute_op(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        field: Optional[str] = params.get("field")
        as_field: str = params.get("as_field", field or "_array_reversed")
        items = extract_items(node)

        result_items = []
        for item in items:
            item_copy = item.copy() if isinstance(item, dict) else {"value": item}
            array_value = extract_field_value(item, field) if field else None
            item_copy[as_field] = array_value[::-1] if isinstance(array_value, list) else []
            result_items.append(item_copy)

        return {
            "items": result_items,
            "count": len(result_items),
            "total_items": len(items),
            "field": field,
            "as_field": as_field,
        }


__all__ = ["ArrayReverseExecutor"]
