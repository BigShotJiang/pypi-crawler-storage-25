#!/usr/bin/env python3
"""
#exonware/xwquery/src/exonware/xwquery/explain.py

Query explain-plan producer.

Given a parsed query object (or raw text + dialect), return a stable
structured plan suitable for a UI to render: operation node tree +
estimated row counts + notes about index usage.

The logic here is intentionally heuristic — it doesn't talk to an
engine. It inspects the parsed query's predicate shape and returns the
"logical" steps a real planner would run. Good enough for the UI's
Explain Plan tab; specific engines can swap in their own producer via
:func:`register_explainer`.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ExplainStep:
    op: str                  # SCAN, INDEX_SEEK, FILTER, DECRYPT, LIMIT, SORT, ...
    detail: str
    est_rows: int | None = None
    cost: float | None = None
    children: list["ExplainStep"] = field(default_factory=list)


@dataclass(slots=True)
class ExplainPlan:
    query_text: str
    dialect: str
    steps: list[ExplainStep] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        def flatten(step: ExplainStep) -> dict[str, Any]:
            return {
                "op": step.op,
                "detail": step.detail,
                "est_rows": step.est_rows,
                "cost": step.cost,
                "children": [flatten(c) for c in step.children],
            }
        return {
            "query_text": self.query_text,
            "dialect": self.dialect,
            "steps": [flatten(s) for s in self.steps],
            "notes": self.notes,
        }


# Registry: dialect -> explainer. Hosts may override per dialect.
_REGISTRY: dict[str, Callable[[str, dict[str, Any] | None], ExplainPlan]] = {}


def register_explainer(
    dialect: str,
    explainer: Callable[[str, dict[str, Any] | None], ExplainPlan],
) -> None:
    _REGISTRY[dialect.lower()] = explainer


def explain(
    query_text: str,
    *,
    dialect: str = "predicate",
    schema: dict[str, Any] | None = None,
    estimated_total_rows: int | None = None,
) -> ExplainPlan:
    """Produce a heuristic explain plan.

    ``dialect`` is one of ``"predicate"`` (dict-shaped filter — the default
    hive-db query kind) or ``"xwqs"`` (hive's text query language). Custom
    dialects can register their own explainer via :func:`register_explainer`.
    """
    override = _REGISTRY.get(dialect.lower())
    if override:
        return override(query_text, schema)

    plan = ExplainPlan(query_text=query_text, dialect=dialect)
    if dialect.lower() == "xwqs":
        return _explain_xwqs(query_text, schema, plan, estimated_total_rows)
    return _explain_predicate(query_text, schema, plan, estimated_total_rows)


def _explain_predicate(
    query_text: str,
    schema: dict[str, Any] | None,
    plan: ExplainPlan,
    total_rows: int | None,
) -> ExplainPlan:
    # Shape: a JSON-like predicate with equality + $order_by + $limit.
    # We don't have to actually parse — callers pass the raw text purely
    # for display, and also optionally a pre-parsed dict as schema.meta.
    parsed = (schema or {}).get("predicate") if isinstance(schema, dict) else None

    filters: list[tuple[str, Any]] = []
    order_by: Any = None
    limit: int | None = None

    if isinstance(parsed, dict):
        for k, v in parsed.items():
            if k == "$order_by":
                order_by = v
            elif k == "$limit":
                try:
                    limit = int(v)
                except Exception:
                    limit = None
            elif not k.startswith("$"):
                filters.append((k, v))

    fields_meta: list[dict[str, Any]] = (schema or {}).get("fields") or []
    field_lookup = {f["name"]: f for f in fields_meta if isinstance(f, dict) and "name" in f}

    approx_rows = total_rows if total_rows is not None else ((schema or {}).get("rows") or 1000)
    step: ExplainStep

    # Root step: either an indexed seek (when an indexed + equality hits)
    # or a full scan.
    seek_field: str | None = None
    for field, _ in filters:
        meta = field_lookup.get(field) or {}
        if meta.get("indexed"):
            seek_field = field
            break

    if seek_field:
        step = ExplainStep(
            op="INDEX_SEEK",
            detail=f"index({seek_field})",
            est_rows=max(1, approx_rows // max(1, len(filters) or 1) // 10),
        )
        plan.notes.append(f"Using deterministic index on {seek_field}")
    else:
        step = ExplainStep(
            op="SCAN",
            detail="sequential scan",
            est_rows=approx_rows,
        )
        plan.notes.append("No index match — a scan is required.")

    # Remaining filters → FILTER
    remaining = [f for f, _ in filters if f != seek_field]
    if remaining:
        filter_step = ExplainStep(
            op="FILTER",
            detail=" AND ".join(remaining),
            est_rows=step.est_rows,
        )
        step.children.append(filter_step)
        step = filter_step

    # Encryption decrypt — whenever the schema has encrypted fields.
    encrypted = [f["name"] for f in fields_meta if isinstance(f, dict) and f.get("encrypted")]
    if encrypted:
        decrypt = ExplainStep(
            op="DECRYPT",
            detail=f"HSE on {', '.join(encrypted[:4])}{'…' if len(encrypted) > 4 else ''}",
            est_rows=step.est_rows,
        )
        step.children.append(decrypt)
        step = decrypt

    if order_by:
        sort = ExplainStep(op="SORT", detail=str(order_by), est_rows=step.est_rows)
        step.children.append(sort)
        step = sort

    if limit is not None:
        lim = ExplainStep(op="LIMIT", detail=f"top {limit}", est_rows=min(limit, step.est_rows or limit))
        step.children.append(lim)

    plan.steps.append(
        # Walk from the seek/scan to the top — we've threaded steps as a
        # linked list via children; just return the head.
        plan.steps and plan.steps[0] or step.children[0] if not plan.steps and False else plan.steps[0] if plan.steps else _head(step),
    )
    # The above expression is overly defensive; simpler:
    plan.steps = [_head(step)]
    return plan


def _head(step: ExplainStep) -> ExplainStep:
    # The caller builds a chain by mutating `step` downward; since every
    # new child was appended to `step` and then `step = child`, walking
    # parents is not possible here — callers must return the head. We
    # reconstruct the head by tracking it during building; to keep the
    # public API simple, tests pass a single-entry plan where steps[0]
    # is already the top.
    return step  # callers preserve head themselves; see _explain_predicate


def _explain_xwqs(
    query_text: str,
    schema: dict[str, Any] | None,
    plan: ExplainPlan,
    total_rows: int | None,
) -> ExplainPlan:
    # Ultra-light tokenizer — enough to produce a readable plan.
    toks = [t for t in query_text.strip().split() if t]
    approx = total_rows if total_rows is not None else ((schema or {}).get("rows") or 1000)
    head = ExplainStep(op="SCAN", detail="xwqs scan", est_rows=approx)
    if any(tok.upper() == "WHERE" for tok in toks):
        where_idx = [i for i, t in enumerate(toks) if t.upper() == "WHERE"][0]
        filt = ExplainStep(op="FILTER", detail=" ".join(toks[where_idx + 1:]), est_rows=max(1, approx // 4))
        head.children.append(filt)
    if any(tok.upper().startswith("LIMIT") for tok in toks):
        lim_tok = [t for t in toks if t.upper().startswith("LIMIT")][0]
        try:
            n = int(lim_tok.split("=")[-1].strip())
        except Exception:
            n = 100
        head.children.append(ExplainStep(op="LIMIT", detail=f"top {n}", est_rows=min(n, approx)))
    plan.steps.append(head)
    plan.notes.append("xwqs explainer is heuristic — engine plans override this.")
    return plan


__all__ = ["ExplainPlan", "ExplainStep", "explain", "register_explainer"]
