import logging
from dataclasses import dataclass
from fractions import Fraction
from functools import cached_property
from typing import NamedTuple, Any
from urllib.parse import urlencode

import requests
from urlobject import URLObject

from papaya.errors import IdentifierProblem, ManifestNotFound, ServiceProblem, ManifestNotAvailable
from papaya.source import (
    Resource,
    SolrService,
    RepositoryService,
    IdentifierError,
    URLError,
    SolrDocumentNotFound,
    SolrLookupError,
    TaggedText,
)

logger = logging.getLogger(__name__)

PRESENTATION_API_CONTEXT = 'http://iiif.io/api/presentation/2/context.json'
DEFAULT_THUMBNAIL_WIDTH = 250


class ImageParams(NamedTuple):
    """Tuple for holding a set of IIIF Image API parameters. See
    https://iiif.io/api/image/2.0/#image-request-parameters for information
    about each parameter."""

    region: str = 'full'
    """`full` | `{x},{y},{w},{h}` | `pct:{x},{y},{w},{h}`"""
    size: str = 'full'
    """`full` | `{w},` | `,{h}` | `pct:{n}` | `{w},{h}` | `!{w},{h}`"""
    rotation: str = '0'
    """`{n}` | `!{n}`"""
    quality: str = 'default'
    """`color` | `gray` | `bitonal` | `default`"""
    format: str = 'jpg'
    """`jpg` | `tif` | `png` | `gif` | `jp2` | `pdf` | `webp`"""

    def __str__(self):
        return f'/{self.region}/{self.size}/{self.rotation}/{self.quality}.{self.format}'


class ImageInfo(NamedTuple):
    """Image information from the IIIF Image API service"""

    uri: str
    """Image URI"""
    context: str | dict
    """JSON-LD context"""
    profile: str | dict
    """IIIF Image API profile"""
    width: int
    """Image width"""
    height: int
    """Image height"""

    @property
    def aspect_ratio(self) -> Fraction:
        """Image aspect ratio (`width / height`)"""
        return Fraction(self.width, self.height)


class ImageServiceError(Exception):
    """There was a problem communicating with the IIIF Image API server"""


@dataclass
class ImageResource:
    endpoint: URLObject
    image_id: str
    origin: URLObject = None

    def request_url(self, params: ImageParams = None) -> str:
        base = self.origin if self.origin else self.endpoint
        if params is not None:
            return f'{base}/{self.image_id}{params}'
        else:
            return f'{base}/{self.image_id}'

    @property
    def info_url(self):
        return f'{self.request_url()}/info.json'

    def uri(self, params: ImageParams = None) -> str:
        if params is not None:
            return f'{self.endpoint}/{self.image_id}{params}'
        else:
            return f'{self.endpoint}/{self.image_id}'

    @property
    def forwarding_headers(self) -> dict[str, str]:
        if self.origin is None:
            return {}

        forwarding_headers = {
            'X-Forwarded-Proto': self.endpoint.scheme,
            'X-Forwarded-Host': self.endpoint.hostname,
        }
        if self.endpoint.path != self.origin.path:
            forwarding_headers['X-Forwarded-Path'] = str(self.endpoint.path).removesuffix(self.origin.path)

        return forwarding_headers


class ImageService:
    """IIIF Image API service endpoint."""

    def __init__(self, endpoint: str, origin: str = None, thumbnail_width: int = 250):
        self.endpoint = URLObject(endpoint)
        self.origin = URLObject(origin) if origin is not None else None
        self.thumbnail_width = thumbnail_width

    def resource(self, image_id: str) -> ImageResource:
        return ImageResource(endpoint=self.endpoint, origin=self.origin, image_id=image_id)

    def get_metadata(self, image_id: str) -> ImageInfo:
        image_resource = self.resource(image_id)
        try:
            response = requests.get(image_resource.info_url, headers=image_resource.forwarding_headers)
        except requests.ConnectionError as e:
            logger.error(f'Unable to retrieve metadata from IIIF Image Service: {e}')
            raise ImageServiceError(f'Problem retrieving image: {e}') from e
        if not response.ok:
            raise ImageServiceError(f'Problem retrieving image: {response.status_code}')
        info = response.json()
        return ImageInfo(
            uri=info['@id'],
            context=info['@context'],
            profile=info['profile'],
            width=info['width'],
            height=info['height'],
        )


FULL_IMAGE_PARAMS = ImageParams('full', 'full', '0', 'default', 'jpg')


class Manifest:
    """IIIF Manifest"""

    def __init__(self, ctx: PresentationContext, id: str, text_query: str = None):
        self.ctx: PresentationContext = ctx
        self.id: str = id
        self.text_query: str = text_query

    @property
    def base_uri(self) -> str:
        return self.ctx.endpoint_url

    @property
    def uri(self) -> str:
        uri = f'{self.base_uri}/{self.id}/manifest'
        if self.text_query is not None:
            uri += '?' + urlencode({'q': self.text_query})
        return uri

    @cached_property
    def resource(self) -> Resource:
        return self.ctx.get_resource(self.id)

    @cached_property
    def sequences(self) -> list[Sequence]:
        return [Sequence(manifest=self, name='normal')]

    def find_sequence(self, name: str) -> Sequence:
        for sequence in self.sequences:
            if sequence.name == name:
                return sequence
        else:
            raise KeyError(name)

    def find_canvas(self, name: str) -> Canvas:
        for sequence in self.sequences:
            for canvas in sequence.canvases:
                if canvas.name == name:
                    return canvas
        else:
            raise KeyError(name)

    def find_annotation(self, name: str) -> ImageAnnotation:
        for sequence in self.sequences:
            for canvas in sequence.canvases:
                if canvas.image_annotation.name == name:
                    return canvas.image_annotation
        else:
            raise KeyError(name)

    def json(self, with_context: bool = False) -> dict[str, Any]:
        manifest_info: dict[str, Any] = {
            '@id': self.uri,
            '@type': 'sc:Manifest',
            'label': self.resource.label,
            'metadata': self.resource.metadata,
            'description': self.resource.description,
            'sequences': [seq.json() for seq in self.sequences],
            'navDate': self.resource.date,
            'license': self.resource.license,
        }
        try:
            manifest_info['thumbnail'] = self.sequences[0].canvases[0].thumbnail.json()
        except IndexError:
            pass

        if self.ctx.logo_url is not None:
            manifest_info['logo'] = {'@id': self.ctx.logo_url}

        if with_context:
            manifest_info.update({'@context': PRESENTATION_API_CONTEXT})

        return manifest_info


class Sequence:
    """IIIF Sequence"""

    def __init__(self, manifest: Manifest, name: str):
        self.manifest: Manifest = manifest
        self.name: str = name
        self.ctx: PresentationContext = self.manifest.ctx
        self.resource: Resource = self.manifest.resource

    @property
    def uri(self) -> str:
        return f'{self.manifest.base_uri}/{self.manifest.id}/sequence/{self.name}'

    @cached_property
    def canvases(self) -> list[Canvas]:
        return [
            Canvas(sequence=self, name=str(index), page_uri=page_uri)
            for index, page_uri in enumerate(self.resource.page_uris)
        ]

    def get_canvas(self, name: str) -> Canvas:
        for canvas in self.canvases:
            if canvas.name == name:
                return canvas
        else:
            raise KeyError(name)

    def json(self, with_context: bool = False) -> dict[str, Any]:
        sequence_info = {
            '@id': self.uri,
            '@type': 'sc:Sequence',
            'canvases': [canvas.json() for canvas in self.canvases],
        }
        if len(self.canvases) > 0:
            sequence_info['startCanvas'] = self.canvases[0].uri

        if with_context:
            sequence_info.update({'@context': PRESENTATION_API_CONTEXT})

        return sequence_info


class Canvas:
    """IIIF Canvas"""

    def __init__(self, sequence: Sequence, name: str, page_uri: str):
        self.sequence = sequence
        self.name = name
        self.page_uri = page_uri
        self.manifest = self.sequence.manifest
        self.resource = self.manifest.resource
        self.image_id = self.resource.get_page_image_id(self.page_uri)

    @property
    def uri(self) -> str:
        return f'{self.manifest.base_uri}/{self.manifest.id}/canvas/{self.name}'

    @cached_property
    def image_annotation(self) -> ImageAnnotation:
        return ImageAnnotation(
            canvas=self,
            name=f'{self.name}-image',
            image=Image(
                service=self.manifest.ctx.image_service,
                image_id=self.image_id,
                iiif_params=FULL_IMAGE_PARAMS,
            ),
        )

    @cached_property
    def thumbnail(self) -> ThumbnailImage:
        return ThumbnailImage(self.manifest.ctx.image_service, self.image_id)

    def search_text(self, query: str) -> list[TaggedText]:
        resource_uri = self.manifest.resource.uri
        page_index = int(self.name)
        return self.manifest.ctx.solr_service.get_text_matches(resource_uri, query, page_index)

    def json(self, with_context: bool = False) -> dict[str, Any]:
        canvas_info = {
            '@id': self.uri,
            '@type': 'sc:Canvas',
            'label': self.resource.get_page_label(self.page_uri),
            'images': [self.image_annotation.json()],
            'thumbnail': self.thumbnail.json(),
            'height': self.image_annotation.height,
            'width': self.image_annotation.width,
            'otherContent': [],
        }

        if self.manifest.text_query is not None:
            canvas_info['otherContent'].append(
                {
                    '@id': SearchHitsList(self, self.manifest.text_query).uri,
                    '@type': 'sc:AnnotationList',
                }
            )

        if with_context:
            canvas_info.update({'@context': PRESENTATION_API_CONTEXT})

        return canvas_info


class ImageAnnotation:
    """IIIF Image Annotation"""

    def __init__(self, canvas: Canvas, name: str, image: Image, motivation: str = 'sc:painting'):
        self.canvas = canvas
        self.manifest = self.canvas.manifest
        self.name = name
        self.motivation = motivation
        self.image = image

    @property
    def uri(self) -> str:
        return f'{self.manifest.base_uri}/{self.manifest.id}/annotation/{self.name}'

    @property
    def width(self) -> int:
        return self.image.info.width

    @property
    def height(self) -> int:
        return self.image.info.height

    def json(self, with_context: bool = False) -> dict[str, Any]:
        annotation_info = {
            '@id': self.uri,
            '@type': 'oa:Annotation',
            'motivation': self.motivation,
            'resource': self.image.json(),
            'on': self.canvas.uri,
        }

        if with_context:
            annotation_info.update({'@context': PRESENTATION_API_CONTEXT})

        return annotation_info


class Image:
    """IIIF Image"""

    def __init__(self, service: ImageService, image_id: str, iiif_params: ImageParams = None):
        self.service = service
        self.image_id = image_id
        self.iiif_params = iiif_params

    @property
    def uri(self) -> str:
        if self.iiif_params is not None:
            return self.info.uri + str(self.iiif_params)
        else:
            return self.info.uri

    @cached_property
    def info(self) -> ImageInfo:
        return self.service.get_metadata(self.image_id)

    def json(self) -> dict[str, Any]:
        return {
            '@id': self.uri,
            '@type': 'dctypes:Image',
            'service': {
                '@context': self.info.context,
                '@id': self.info.uri,
                'profile': self.info.profile,
            },
            'format': 'image/jpeg',
            'height': self.info.height,
            'width': self.info.width,
        }


class ThumbnailImage(Image):
    """IIIF thumbnail image"""

    def __init__(self, service: ImageService, image_id: str):
        super().__init__(service, image_id)
        self.width = self.service.thumbnail_width
        self.height = int(self.width / self.info.aspect_ratio)
        self.iiif_params = ImageParams(size=f'{self.width},{self.height}')

    def json(self) -> dict[str, Any]:
        image = super().json()
        image['width'] = self.width
        image['height'] = self.height
        return image


class SearchHitsList:
    """IIIF Annotation List of full text search hits"""

    def __init__(self, canvas: Canvas, query: str):
        self.canvas = canvas
        self.manifest = self.canvas.manifest
        self.query = query

    @property
    def uri(self) -> str:
        query_string = urlencode({'q': self.query})
        return f'{self.manifest.base_uri}/{self.manifest.id}/list/{self.canvas.name}-search?{query_string}'

    @cached_property
    def search_hits(self) -> list[TaggedText]:
        return self.canvas.search_text(self.query)

    @cached_property
    def annotations(self) -> list[SearchResult]:
        return [
            SearchResult(self.canvas, f'{self.uri}#result-{i:03d}', hit) for i, hit in enumerate(self.search_hits, 1)
        ]

    def json(self, with_context: bool = False) -> dict[str, Any]:
        list_info = {
            '@id': self.uri,
            '@type': 'sc:AnnotationList',
            'resources': [annotation.json() for annotation in self.annotations],
        }

        if with_context:
            list_info.update({'@context': PRESENTATION_API_CONTEXT})

        return list_info


class SearchResult:
    """IIIF Annotation of a single search result"""

    def __init__(self, canvas: Canvas, uri: str, hit: TaggedText):
        self.canvas = canvas
        self.uri = uri
        self.hit = hit

    def json(self) -> dict[str, Any]:
        return {
            '@id': self.uri,
            '@type': [
                'oa:Annotation',
                'umd:searchResult',
            ],
            'motivation': 'oa:highlighting',
            'on': {
                '@type': 'oa:SpecificResource',
                'full': self.canvas.uri,
                'selector': {
                    '@type': 'oa:FragmentSelector',
                    'value': f'xywh={self.hit.params["xywh"]}',
                },
            },
        }


@dataclass
class PresentationContext:
    """Configured service information for retrieving Solr documents
    and images, and generating manifests."""

    solr_service: SolrService
    repo_service: RepositoryService
    image_service: ImageService
    endpoint_url: str
    logo_url: str

    def get_resource_uri(self, iiif_id: str) -> str:
        try:
            return self.repo_service.get_resource_uri(iiif_id)
        except IdentifierError as e:
            raise IdentifierProblem(iiif_id=str(e)) from e

    def get_iiif_id(self, resource_uri: str) -> str:
        try:
            return self.repo_service.get_iiif_id(resource_uri)
        except URLError as e:
            raise ManifestNotAvailable(uri=resource_uri) from e

    def get_resource(self, manifest_id: str) -> Resource:
        try:
            return self.solr_service.get_resource(self.get_resource_uri(manifest_id))
        except SolrDocumentNotFound as e:
            raise ManifestNotFound(id=manifest_id) from e
        except SolrLookupError as e:
            raise ServiceProblem from e

    def get_manifest(self, manifest_id: str, text_query: str = None) -> Manifest:
        return Manifest(ctx=self, id=manifest_id, text_query=text_query)
