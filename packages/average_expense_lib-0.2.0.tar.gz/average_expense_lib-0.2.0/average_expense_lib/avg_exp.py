def calculate_average_expense(amounts):
    """Calculate average expense from a list of amounts"""
    if not amounts:
        return 0
    return sum(amounts) / len(amounts)