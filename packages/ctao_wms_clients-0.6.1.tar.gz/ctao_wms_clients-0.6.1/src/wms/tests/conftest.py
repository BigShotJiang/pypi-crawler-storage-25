"""pytest setup and fixtures for wms integration tests"""

import json
import os
import subprocess as sp
from pathlib import Path

import pytest


@pytest.fixture(scope="session")
def _dirac_token(_dirac_proxy):
    """Get token to talk to DiracX"""
    from DIRAC.Core.Security.DiracX import diracxTokenFromPEM, getDefaultProxyLocation

    proxy = getDefaultProxyLocation()
    token = diracxTokenFromPEM(proxy)
    token_file = Path.home() / ".cache" / "diracx" / "credentials.json"
    token_file.parent.mkdir(parents=True, exist_ok=True)
    with open(
        token_file,
        "w",
        encoding="utf-8",
        opener=lambda p, f: os.open(p, f | os.O_TRUNC, 0o600),
    ) as f:
        json.dump(token, f)


@pytest.fixture(scope="session")
def _dirac_proxy():
    cmd = ["dirac-proxy-init", "-d", "-g", "dpps_group"]
    ret = sp.run(cmd, stdout=sp.PIPE, stderr=sp.STDOUT, encoding="utf-8")
    assert ret.returncode == 0, ret.stdout


@pytest.fixture(scope="session")
def _init_dirac(_dirac_proxy):
    """Import and init DIRAC, needs to be run first for anything using DIRAC"""
    import DIRAC

    DIRAC.initialize()
