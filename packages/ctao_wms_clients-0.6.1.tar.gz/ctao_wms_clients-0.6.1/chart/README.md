# wms

![Version: 0.0.0-dev](https://img.shields.io/badge/Version-0.0.0--dev-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: dev](https://img.shields.io/badge/AppVersion-dev-informational?style=flat-square)

A Helm chart to deploy the Workload Management System of CTAO

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://diracgrid.github.io/diracx-charts | diracx | 1.0.12 |
| oci://harbor.cta-observatory.org/common | cert-generator-grid | v5.0.0 |
| oci://harbor.cta-observatory.org/dpps | cvmfs | v0.8.0 |
| oci://harbor.cta-observatory.org/dpps | iam(dpps-iam) | v0.1.4 |
| oci://harbor.cta-observatory.org/proxy_cache/bitnamicharts | mariadb | 20.5.5 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| cert-generator-grid | object | `{"enabled":true,"extra_server_names":["iam.test.example","voms.test.example","git-cs-repo.test.example","fts","opensearch-cluster-master","dirac-master-cs","dirac-ce","dirac-web-app","dirac-client","dirac-proxy-manager","dirac-bundle-delivery","dirac-system-admin","dirac-component-monitoring","dirac-job-manager","dirac-job-monitoring","dirac-job-state-update","dirac-wms-admin","dirac-matcher","dirac-pilot-manager","dirac-pilot-status","dirac-optimization-mind","dirac-sandbox-store","dirac-file-catalog","dirac-storage-element","dirac-req-proxy","dirac-resource-status","dirac-resource-management","dirac-publisher","dirac-req-executing","dirac-req-manager","dirac-clean-req-db","dirac-site-director","dirac-pilot-sync","dirac-optimizers","dirac-voms2cs","dirac-token-manager"],"generatePreHooks":true,"users":[{"name":"DPPS User","suffix":""},{"name":"DPPS User Unprivileged","suffix":"-unprivileged"},{"name":"Non-DPPS User","suffix":"-non-dpps"}]}` | Settings for the certificate generator |
| csRepo.enabled | bool | `true` |  |
| csRepo.ingress.annotations | object | `{}` |  |
| csRepo.ingress.className | string | `"haproxy"` |  |
| csRepo.ingress.enabled | bool | `true` |  |
| csRepo.ingress.hosts[0] | string | `"git-cs-repo.test.example"` |  |
| csRepo.ingress.tls[0].hosts[0] | string | `"git-cs-repo.test.example"` |  |
| csRepo.ingress.tls[0].secretName | string | `"git-cs-repo-tls"` |  |
| csRepo.password | string | `"admin"` |  |
| csRepo.username | string | `"admin"` |  |
| cvmfs | object | `{"enabled":true}` | Configuration for the cvmfs subchart, included for testing |
| dev | object | `{"client_image_tag":null,"mount_repo":true,"run_tests":true,"sleep":false}` | Settings for local development |
| dev.client_image_tag | string | `nil` | tag of the image used to run helm tests |
| dev.mount_repo | bool | `true` | mount the repo volume to test the code as it is being developed |
| dev.run_tests | bool | `true` | run tests in the container |
| dev.sleep | bool | `false` | sleep after test to allow interactive development |
| diracCE | object | `{"ceName":"dirac-ce","enabled":true,"extraVolumes":[],"hostkey":{"secretFullName":""},"image":"harbor.cta-observatory.org/dpps/wms-ce:v0.6.0-rc7","resources":{}}` | A simple SSH compute element for testing |
| diracClient.hostkey.secretFullName | string | `""` |  |
| diracNoSqlDatabase | object | `{"cacerts":"/etc/pki/tls/certs/ca-bundle.crt","createSecret":true,"host":"opensearch-cluster-master","password":"admin","port":9200,"secretName":"dirac-no-sql-db-password","ssl":true,"user":"admin"}` | No SQL database use by DIRAC |
| diracServer | object | `{"bootstrap":{"enabled":true,"initDiracDb":{"enabled":true},"patchCoreDNS":{"enabled":false},"proxyInit":{"enabled":true,"groups":["dpps_genpilot","dirac_admin"],"retry":2},"resources":{},"syncDiracxCS":{"enabled":true,"schedule":"1 */1 * * *"},"syncIamUsers":{"enabled":true,"retry":5},"syncRSS":{"activeCEs":["dirac-ce"],"allowedSites":["CTAO.CI.de"],"enabled":true},"timeout":"1200s"},"commonVolumes":{"caBundleClaimName":"{{ printf \"%s-ca-bundle-pvc\" (include \"indigo-iam.fullname\" .Subcharts.iam) }}","gridcaBundleClaimName":"{{ printf \"%s-grid-ca-bundle-pvc\" (include \"indigo-iam.fullname\" .Subcharts.iam) }}","vomsdirConfigMapName":"{{ printf \"%s-voms-lsc\" (include \"indigo-iam.fullname\" .Subcharts.iam) }}","vomsesConfigMapName":"{{ printf \"%s-vomses\" (include \"indigo-iam.fullname\" .Subcharts.iam) }}"},"configmap":{"create":true,"name":null},"configurationName":"DPPS-Tests","diracComponents":{"_agentDefaults":{"port":null,"replicaCount":1,"type":"agent"},"_executorDefaults":{"port":null,"replicaCount":1,"type":"executor"},"_serviceDefaults":{"replicaCount":1,"type":"service"},"bundleDelivery":{"<<":{"replicaCount":1,"type":"service"},"cmd":"Framework/BundleDelivery","port":9158},"cleanReqDB":{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"RequestManagement/CleanReqDBAgent","port":null},"componentMonitoring":{"<<":{"replicaCount":1,"type":"service"},"cmd":"Framework/ComponentMonitoring","port":9190},"fileCatalog":{"<<":{"replicaCount":1,"type":"service"},"cmd":"DataManagement/FileCatalog","port":9197},"jobManager":{"cmd":"WorkloadManagement/JobManager","port":9132,"replicaCount":1,"type":"service"},"jobMonitoring":{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/JobMonitoring","port":9130},"jobStateUpdate":{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/JobStateUpdate","port":9136},"matcher":{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/Matcher","port":9170},"optimizationMind":{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/OptimizationMind","port":9175},"optimizers":{"<<":{"port":null,"replicaCount":1,"type":"executor"},"cmd":"WorkloadManagement/Optimizers","port":null},"pilotManager":{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/PilotManager","port":9171},"pilotStatus":{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"WorkloadManagement/PilotStatusAgent","port":null},"proxyManager":{"<<":{"replicaCount":1,"type":"service"},"cmd":"Framework/ProxyManager","port":9152},"publisher":{"<<":{"replicaCount":1,"type":"service"},"cmd":"ResourceStatus/Publisher","port":9165},"reqExecuting":{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"RequestManagement/RequestExecutingAgent","port":null},"reqManager":{"<<":{"replicaCount":1,"type":"service"},"cmd":"RequestManagement/ReqManager","port":9140},"reqProxy":{"<<":{"replicaCount":1,"type":"service"},"cmd":"RequestManagement/ReqProxy","port":9161},"resourceManagement":{"<<":{"replicaCount":1,"type":"service"},"cmd":"ResourceStatus/ResourceManagement","port":9172},"resourceStatus":{"<<":{"replicaCount":1,"type":"service"},"cmd":"ResourceStatus/ResourceStatus","port":9160},"sandboxStore":{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/SandboxStore","port":9196},"siteDirector":{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"WorkloadManagement/SiteDirector","port":null},"storageElement":{"<<":{"replicaCount":1,"type":"service"},"cmd":"DataManagement/StorageElement","port":9148},"systemAdmin":{"<<":{"replicaCount":1,"type":"service"},"cmd":"Framework/SystemAdministrator","port":9162},"tokenManager":{"<<":{"replicaCount":1,"type":"service"},"cmd":"Framework/TokenManager","port":9181},"voms2cs":{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"Configuration/VOMS2CSAgent"},"wmsAdmin":{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/WMSAdministrator","port":9145}},"diracConfig":{"registry":{"DefaultGroup":"dirac_user","groups":{"dirac_admin":{"properties":["AlarmsManagement","ServiceAdministrator","CSAdministrator","JobAdministrator","FullDelegation","ProxyManagement","Operator"],"users":["test-user"],"vo":"ctao.dpps.test"},"dirac_user":{"properties":["NormalUser"],"users":["test-user"],"vo":"ctao.dpps.test"},"dpps_genpilot":{"properties":["GenericPilot","LimitedDelegation"],"users":["test-user"],"vo":"ctao.dpps.test"},"dpps_group":{"properties":["NormalUser","PrivateLimitedDelegation"],"users":["test-user"],"vo":"ctao.dpps.test","vomsrole":"/ctao.dpps.test/Role=user"}},"hosts":null,"users":{"test-user":{"CA":"/CN=DPPS Development CA","DN":"/CN=DPPS User"}},"vos":{"ctao.dpps.test":{"ClientID":"dpps-test-client","DefaultGroup":"dirac_user","IdPUrl":"http://wms-iam-login-service","IdProvider":"wms-iam-login-service","VOAdmin":"test-user","VOAdminGroup":"dirac_admin","VOMSName":"ctao.dpps.test"}}},"resources":{"fileCatalog":"RucioFileCatalog\n{\n  CatalogType = FileCatalog\n  AccessType = Read-Write\n  Status = Active\n  Master = True\n  CatalogURL = DataManagement/FileCatalog\n  MetaCatalog = True\n}\n","idProviders":"wms-iam-login-service\n{\n issuer = {{ default \"https://iam.test.example\" $.Values.iam_external.loginServiceURL }}\n ProviderType = OAuth2\n scope = openid profile email offline_access\n {{ if .Values.iam_external.enabled -}}\n client_id = {{ .Values.iam_external.client_id }}\n client_secret = {{ .Values.iam_external.client_secret }}\n {{- else if .Values.iam.enabled -}}\n client_id = {{ index .Values.iam.bootstrap.config.clients 0 \"client_id\" }}\n client_secret = {{ index .Values.iam.bootstrap.config.clients 0 \"client_secret\" }}\n {{- end }}\n}\n","sites":"CTAO\n{\n  CTAO.CI.de\n  {\n    Name = CTAO.CI.de\n    CE = {{ $.Values.diracCE.ceName }}\n    CEs\n    {\n      {{ $.Values.diracCE.ceName }}\n      {\n        CEType = SSH\n        SubmissionMode = Direct\n        SSHHost = dirac-ce\n        SSHUser = dirac\n        SSHKey = /home/dirac/.ssh/diracuser_sshkey\n        SSHOptions = -o StrictHostKeyChecking=no\n        wnTmpDir = /tmp\n        Pilot = True\n        SharedArea = /home/dirac\n        ExtraPilotOptions = --PollingTime 10 --CVMFS_locations=/\n        UserEnvVariables = RUCIO_CONFIG:::/cvmfs/sw.ctao.dpps.test/rucio/etc/rucio.cfg\n\n        Queues\n        {\n          normal\n          {\n            maxCPUTime = 172800\n            SI00 = 2155\n            MaxTotalJobs = 2500\n            MaxWaitingJobs = 300\n            VO = ctao.dpps.test\n            BundleProxy = True\n          }\n        }\n      }\n    }\n  }\n}\n","storageElements":"SandboxSE\n{\n  BackendType = DISET\n  AccessProtocol.1\n  {\n    Host = {{ include \"wms.dirac-service-name\" (dict \"root\" . \"comp\" \"sandboxStore\") }}\n    Port = {{ .Values.diracServer.diracComponents.sandboxStore.port }}\n    PluginName = DIP\n    Protocol = dips\n    Path = /WorkloadManagement/SandboxStore\n    Access = remote\n    WSUrl =\n  }\n}\n"}},"diracDatabases":["AccountingDB","FileCatalogDB","InstalledComponentsDB","JobDB","JobLoggingDB","PilotAgentsDB","ProxyDB","ReqDB","ResourceManagementDB","ResourceStatusDB","SandboxMetadataDB","StorageManagementDB","TaskQueueDB","TokenDB"],"diracx":{"legacyExchangeApiKey":"diracx:legacy:Mr8ostGuB_SsdmcjZb7LPkMkDyp9rNuHX6w1qAqahDg="},"environment":{"REQUESTS_CA_BUNDLE":"/etc/pki/tls/certs/ca-bundle.crt"},"initContainers":{"certKeys":{"volumeMounts":[{"mountPath":"/home/dirac/.ssh","name":"ssh-dir"},{"mountPath":"/opt/dirac/etc/grid-security","name":"certs-dir"},{"mountPath":"/home/dirac/.globus","name":"globus-dir"}],"volumes":[{"emptyDir":{},"name":"ssh-dir"},{"emptyDir":{},"name":"globus-dir"},{"emptyDir":{},"name":"certs-dir"}]}},"masterCS":{"PVStorageRequest":"1Mi","enabled":true,"extraVolumeMounts":null,"extraVolumes":null,"hostkey":{"secretFullName":""},"hostname":"dirac-master-cs","port":9135,"resources":{"limits":{"cpu":"2","memory":"2Gi"},"requests":{"cpu":"0.2","memory":"512Mi"}},"tornado":false},"podAnnotations":{},"podLabels":{},"podSecurityContext":{},"rucio":{"configMap":{"create":true,"name":"{{ include \"wms.fullname\" . }}-rucio-config-server"}},"secrets":{"create":true,"name":null},"securityContext":{},"siteName":"test.dpps.cta-observatory.org","voName":"ctao.dpps.test","vomsConfig":{"dirName":"voms.test.example.lsc","mountPath":"","voName":"ctao.dpps.test"},"webApp":{"configmap":{"name":null},"enabled":true,"extraVolumeMounts":null,"extraVolumes":null,"hostkey":{"secretFullName":""},"hostname":"dirac-web-app","resources":{},"runPilotSync":true}}` | Setting for the DIRAC components |
| diracServer.diracComponents.fileCatalog | object | `{"<<":{"replicaCount":1,"type":"service"},"cmd":"DataManagement/FileCatalog","port":9197}` | DataManagement System |
| diracServer.diracComponents.jobMonitoring | object | `{"<<":{"replicaCount":1,"type":"service"},"cmd":"WorkloadManagement/JobMonitoring","port":9130}` | Workload Management System |
| diracServer.diracComponents.proxyManager | object | `{"<<":{"replicaCount":1,"type":"service"},"cmd":"Framework/ProxyManager","port":9152}` | Framework System |
| diracServer.diracComponents.reqExecuting | object | `{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"RequestManagement/RequestExecutingAgent","port":null}` | RMS |
| diracServer.diracComponents.reqProxy | object | `{"<<":{"replicaCount":1,"type":"service"},"cmd":"RequestManagement/ReqProxy","port":9161}` | Request Management System |
| diracServer.diracComponents.resourceStatus | object | `{"<<":{"replicaCount":1,"type":"service"},"cmd":"ResourceStatus/ResourceStatus","port":9160}` | Resource Status System |
| diracServer.diracComponents.siteDirector | object | `{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"WorkloadManagement/SiteDirector","port":null}` | Workload |
| diracServer.diracComponents.voms2cs | object | `{"<<":{"port":null,"replicaCount":1,"type":"agent"},"cmd":"Configuration/VOMS2CSAgent"}` | Configuration System |
| diracServer.voName | string | `"ctao.dpps.test"` | if set, is used as Hostname in component local config single_hostname: |
| diracSqlDatabase | object | `{"createSecret":true,"host":"dirac-db","password":"dirac-db","port":3306,"rootPassword":"dirac-db-root","rootUser":"root","secretName":"dirac-sql-db-password","user":"Dirac"}` | SQL database use by DIRAC |
| diracx.cert-manager.cainjector.image.repository | string | `"harbor.cta-observatory.org/dpps/quay-io-jetstack-cert-manager-cainjector"` |  |
| diracx.cert-manager.image.repository | string | `"harbor.cta-observatory.org/dpps/quay-io-jetstack-cert-manager-controller"` |  |
| diracx.cert-manager.startupapicheck.image.repository | string | `"harbor.cta-observatory.org/dpps/quay-io-jetstack-cert-manager-ctl"` |  |
| diracx.cert-manager.webhook.image.repository | string | `"harbor.cta-observatory.org/dpps/quay-io-jetstack-cert-manager-webhook"` |  |
| diracx.developer.enabled | bool | `false` |  |
| diracx.developer.localCSPath | string | `"/cs_store"` |  |
| diracx.developer.urls.diracx | string | `"http://wms-diracx:8000"` |  |
| diracx.developer.urls.iam | string | `"http://wms-iam-login-service:8080"` |  |
| diracx.developer.urls.minio | string | `"http://wms-minio:32000"` |  |
| diracx.dex.enabled | bool | `false` |  |
| diracx.diracx.hostname | string | `"wms-diracx"` |  |
| diracx.diracx.osDbs.dbs.JobParametersDB | string | `nil` |  |
| diracx.diracx.settings.DIRACX_CONFIG_BACKEND_URL | string | `"git+https://admin:admin@git-cs-repo.test.example/git"` |  |
| diracx.diracx.settings.DIRACX_LEGACY_EXCHANGE_HASHED_API_KEY | string | `"19628aa0cb14b69f75b2164f7fda40215be289f6e903d1acf77b54caed61a720"` |  |
| diracx.diracx.settings.DIRACX_SANDBOX_STORE_AUTO_CREATE_BUCKET | string | `"true"` |  |
| diracx.diracx.settings.DIRACX_SANDBOX_STORE_BUCKET_NAME | string | `"sandboxes"` |  |
| diracx.diracx.settings.DIRACX_SANDBOX_STORE_S3_CLIENT_KWARGS | string | `"{\"endpoint_url\": \"http://wms-minio:9000\", \"aws_access_key_id\": \"rootuser\", \"aws_secret_access_key\": \"rootpass123\"}"` |  |
| diracx.diracx.settings.DIRACX_SERVICE_AUTH_ACCESS_TOKEN_EXPIRE_MINUTES | string | `"120"` |  |
| diracx.diracx.settings.DIRACX_SERVICE_AUTH_ALLOWED_REDIRECTS | string | `"[\"http://wms-diracx:8000/api/docs/oauth2-redirect\", \"http://wms-diracx:8000/#authentication-callback\"]"` |  |
| diracx.diracx.settings.DIRACX_SERVICE_AUTH_REFRESH_TOKEN_EXPIRE_MINUTES | string | `"360"` |  |
| diracx.diracx.settings.DIRACX_SERVICE_AUTH_TOKEN_ISSUER | string | `"http://wms-diracx:8000"` |  |
| diracx.diracx.settings.DIRACX_SERVICE_AUTH_TOKEN_KEYSTORE | string | `"file:///keystore/jwks.json"` |  |
| diracx.diracx.settings.GIT_SSL_NO_VERIFY | string | `"true"` |  |
| diracx.diracx.sqlDbs.dbs.AuthDB.internalName | string | `"DiracXAuthDB"` |  |
| diracx.diracx.sqlDbs.dbs.JobDB | string | `nil` |  |
| diracx.diracx.sqlDbs.dbs.JobLoggingDB | string | `nil` |  |
| diracx.diracx.sqlDbs.dbs.SandboxMetadataDB | string | `nil` |  |
| diracx.diracx.sqlDbs.dbs.TaskQueueDB | string | `nil` |  |
| diracx.diracx.sqlDbs.default.host | string | `"dirac-db:3306"` |  |
| diracx.diracx.sqlDbs.default.password | string | `"dirac-db"` |  |
| diracx.diracx.sqlDbs.default.rootPassword | string | `"dirac-db-root"` |  |
| diracx.diracx.sqlDbs.default.rootUser | string | `"root"` |  |
| diracx.diracx.sqlDbs.default.user | string | `"Dirac"` |  |
| diracx.diracx.startupProbe.failureThreshold | int | `60` |  |
| diracx.diracx.startupProbe.periodSeconds | int | `15` |  |
| diracx.diracx.startupProbe.timeoutSeconds | int | `5` |  |
| diracx.elasticsearch.enabled | bool | `false` |  |
| diracx.enabled | bool | `true` |  |
| diracx.global.activeDeadlineSeconds | int | `900` |  |
| diracx.global.batchJobTTL | int | `3600` |  |
| diracx.global.imagePullPolicy | string | `"Always"` |  |
| diracx.global.images.busybox.registryType | string | `"harbor"` |  |
| diracx.global.images.busybox.repository | string | `"proxy_cache/busybox"` |  |
| diracx.global.images.busybox.tag | string | `"latest"` |  |
| diracx.global.images.client | string | `"dpps/diracgrid-diracx-client"` |  |
| diracx.global.images.diracx_base_image | string | `"dpps/diracgrid-diracx-base-image"` |  |
| diracx.global.images.ghcr_registry | string | `"harbor.cta-observatory.org"` |  |
| diracx.global.images.harbor_registry | string | `"harbor.cta-observatory.org"` |  |
| diracx.global.images.secret_generation | string | `"dpps/diracgrid-diracx-secret-generation"` |  |
| diracx.global.images.services | string | `"dpps/diracgrid-diracx-services"` |  |
| diracx.global.images.tag | string | `"v0.0.8"` |  |
| diracx.global.images.web.repository | string | `"dpps/diracgrid-diracx-web-static"` |  |
| diracx.global.images.web.tag | string | `"v0.1.0-a10"` |  |
| diracx.grafana.enabled | bool | `false` |  |
| diracx.indigoiam.enabled | bool | `false` |  |
| diracx.indigoiam.image.repository | string | `"indigoiam/iam-login-service"` |  |
| diracx.indigoiam.image.tag | string | `"v1.13.0-rc2"` |  |
| diracx.ingress.annotations."haproxy.org/ssl-redirect" | string | `"true"` |  |
| diracx.ingress.annotations."haproxy.org/ssl-redirect-port" | string | `"443"` |  |
| diracx.ingress.className | string | `"haproxy"` |  |
| diracx.initSql.enabled | bool | `false` |  |
| diracx.initSql.env | object | `{}` |  |
| diracx.jaeger.enabled | bool | `false` |  |
| diracx.minio.environment.MINIO_BROWSER_REDIRECT_URL | string | `"http://wms-minio:32001/"` |  |
| diracx.minio.image.repository | string | `"harbor.cta-observatory.org/dpps/quay-io-minio-minio"` |  |
| diracx.minio.image.tag | string | `"RELEASE.2025-09-07T16-13-09Z"` |  |
| diracx.minio.mcImage.repository | string | `"harbor.cta-observatory.org/dpps/quay-io-minio-mc"` |  |
| diracx.minio.mcImage.tag | string | `"RELEASE.2025-08-13T08-35-41Z"` |  |
| diracx.minio.rootPassword | string | `"rootpass123"` |  |
| diracx.minio.rootUser | string | `"rootuser"` |  |
| diracx.mysql.enabled | bool | `false` |  |
| diracx.opensearch.config."opensearch.yml" | string | `"cluster.name: opensearch-cluster\n\n# Bind to all interfaces because we don't know what IP address Docker will assign to us.\nnetwork.host: 0.0.0.0\n\n# Setting network.host to a non-loopback address enables the annoying bootstrap checks. \"Single-node\" mode disables them again.\n# Implicitly done if \".singleNode\" is set to \"true\".\n# discovery.type: single-node\n\n# Start OpenSearch Security Demo Configuration\n# WARNING: revise all the lines below before you go into production\nplugins:\n  security:\n    ssl:\n      transport:\n        pemcert_filepath: hostcert.pem\n        pemkey_filepath: hostkey.pem\n        pemtrustedcas_filepath: ca.pem\n        enforce_hostname_verification: false\n      http:\n        enabled: true\n        pemcert_filepath: hostcert.pem\n        pemkey_filepath: hostkey.pem\n        pemtrustedcas_filepath: ca.pem\n    allow_unsafe_democertificates: true\n    allow_default_init_securityindex: true\n    authcz:\n      admin_dn:\n        - CN=kirk,OU=client,O=client,L=test,C=de\n        - CN={{ include \"certprefix\" . }}-dirac-master-cs\n        - CN={{ include \"certprefix\" . }}-{{ include \"wms.dirac-comp-suffix\" \"wmsAdmin\"}}\n        - CN={{ include \"certprefix\" . }}-{{ include \"wms.dirac-comp-suffix\" \"jobStateUpdate\"}}\n    audit.type: internal_opensearch\n    enable_snapshot_restore_privilege: true\n    check_snapshot_restore_write_privileges: true\n    restapi:\n      roles_enabled: [\"all_access\", \"security_rest_api_access\"]\n    system_indices:\n      enabled: true\n      indices:\n        [\n          \".opendistro-alerting-config\",\n          \".opendistro-alerting-alert*\",\n          \".opendistro-anomaly-results*\",\n          \".opendistro-anomaly-detector*\",\n          \".opendistro-anomaly-checkpoints\",\n          \".opendistro-anomaly-detection-state\",\n          \".opendistro-reports-*\",\n          \".opendistro-notifications-*\",\n          \".opendistro-notebooks\",\n          \".opendistro-asynchronous-search-response*\",\n        ]\n######## End OpenSearch Security Demo Configuration ########\n"` |  |
| diracx.opensearch.enabled | bool | `true` |  |
| diracx.opensearch.extraVolumeMounts[0].mountPath | string | `"/usr/share/opensearch/config/ca.pem"` |  |
| diracx.opensearch.extraVolumeMounts[0].name | string | `"cafile"` |  |
| diracx.opensearch.extraVolumeMounts[0].subPath | string | `"ca.pem"` |  |
| diracx.opensearch.extraVolumeMounts[1].mountPath | string | `"/usr/share/opensearch/config/hostcert.pem"` |  |
| diracx.opensearch.extraVolumeMounts[1].name | string | `"dpps-certkey-600"` |  |
| diracx.opensearch.extraVolumeMounts[1].subPath | string | `"hostcert.pem"` |  |
| diracx.opensearch.extraVolumeMounts[2].mountPath | string | `"/usr/share/opensearch/config/hostkey.pem"` |  |
| diracx.opensearch.extraVolumeMounts[2].name | string | `"dpps-certkey-400"` |  |
| diracx.opensearch.extraVolumeMounts[2].subPath | string | `"hostkey.pem"` |  |
| diracx.opensearch.extraVolumes | string | `"- name: cafile\n  secret:\n    defaultMode: 420\n    secretName: {{ include \"certprefix\" . }}-server-cafile\n- name: dpps-certkey-600\n  secret:\n    defaultMode: 0600\n    secretName: {{ include \"certprefix\" . }}-opensearch-cluster-master-hostkey\n- name: dpps-certkey-400\n  secret:\n    defaultMode: 0400\n    secretName: {{ include \"certprefix\" . }}-opensearch-cluster-master-hostkey\n"` |  |
| diracx.opensearch.image.repository | string | `"opensearchproject/opensearch"` |  |
| diracx.opentelemetry-collector.enabled | bool | `false` |  |
| diracx.prometheus.enabled | bool | `false` |  |
| diracx.rabbitmq.auth.existingErlangSecret | string | `"rabbitmq-secret"` |  |
| diracx.rabbitmq.auth.existingPasswordSecret | string | `"rabbitmq-secret"` |  |
| diracx.rabbitmq.containerSecurityContext.enabled | bool | `false` |  |
| diracx.rabbitmq.enabled | bool | `true` |  |
| diracx.rabbitmq.image.registry | string | `"harbor.cta-observatory.org/proxy_cache"` |  |
| diracx.rabbitmq.image.repository | string | `"bitnamilegacy/rabbitmq"` |  |
| diracx.rabbitmq.podSecurityContext.enabled | bool | `false` |  |
| diracx_alias_service.enabled | bool | `true` |  |
| diracx_alias_service.name | string | `"wms-diracx"` |  |
| diracx_deployment_fullname | string | `"{{ .Release.Name }}-diracx"` |  |
| fullnameOverride | string | `""` |  |
| global.dockerRegistry | string | `"harbor.cta-observatory.org/proxy_cache"` |  |
| global.registry | string | `"harbor.cta-observatory.org/proxy_cache"` |  |
| global.storageClassName | string | `"standard"` |  |
| iam_alias_service.enabled | bool | `true` |  |
| iam_alias_service.name | string | `"wms-iam-login-service"` |  |
| iam_external.client_id | string | `"dpps-test-client"` |  |
| iam_external.client_secret | string | `"secret"` |  |
| iam_external.enabled | bool | `true` |  |
| iam_external.loginServiceURL | string | `"https://iam.test.example"` |  |
| image | object | `{"pullPolicy":"IfNotPresent","repository_prefix":"harbor.cta-observatory.org/dpps/wms","tag":null}` | Image settings. |
| image.repository_prefix | string | `"harbor.cta-observatory.org/dpps/wms"` | Prefix of the repository, pods will use <repository_prefix>-{server,client,ce} |
| image.tag | string | `nil` | Image tag, if not set, the chart's appVersion will be used |
| imagePullSecrets | list | `[{"name":"harbor-pull-secret"}]` | Secrets needed to access image registries |
| mariadb | object | `{"auth":{"rootPassword":"dirac-db-root"},"enabled":true,"global":{"security":{"allowInsecureImages":true}},"image":{"registry":"harbor.cta-observatory.org/proxy_cache","repository":"bitnamilegacy/mariadb"},"initdbScripts":{"create-user.sql":"CREATE USER IF NOT EXISTS 'Dirac'@'%' IDENTIFIED BY 'dirac-db';\nCREATE USER IF NOT EXISTS 'indigo-iam'@'%' IDENTIFIED BY 'PassW0rd';\nCREATE DATABASE IF NOT EXISTS `indigo-iam`;\nGRANT ALL PRIVILEGES ON `indigo-iam`.* TO `indigo-iam`@`%`;\nFLUSH PRIVILEGES;\n"}}` | Configuration for the bitnami mariadb subchart. Disable if DIRAC database is provided externally. |
| minio_alias_service.enabled | bool | `true` |  |
| minio_alias_service.name | string | `"wms-minio"` |  |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| resources | object | `{}` |  |
| rucio.authHost | string | `""` | auth-host to insert into rucio-configmap, by default same as host |
| rucio.host | string | `"https://{{ .Release.Name }}-rucio-server"` | host to insert into rucio-configmap |
| service.port | int | `8080` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.automount | bool | `true` | Automatically mount a ServiceAccount's API credentials? |
| serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| serviceAccount.name | string | `""` | If not set and create is true, a name is generated using the fullname template |
| tolerations | list | `[]` |  |
| volumeMounts | list | `[]` |  |
| volumes | list | `[]` |  |
| waitForLoginService.image.pullPolicy | string | `"IfNotPresent"` |  |
| waitForLoginService.image.repository | string | `"proxy_cache/almalinux"` |  |
| waitForLoginService.image.tag | int | `9` |  |

