{{/*
Expand the name of the chart.
*/}}
{{- define "wms.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "wms.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "wms.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "wms.labels" -}}
helm.sh/chart: {{ include "wms.chart" . }}
{{ include "wms.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "wms.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wms.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "wms.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "wms.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
Certificate prefix
*/}}
{{- define "certprefix" -}}
{{- .Release.Name -}}
{{- end }}

{{/*
Return the master Configuration Server short hostname
*/}}
{{- define "wms.master-short-name" -}}
{{- coalesce .Values.diracServer.masterCS.hostname "dirac-master-cs" -}}
{{- end }}

{{/*
Return the full name of the master Configuration Server
*/}}
{{- define "wms.master-full-name" -}}
{{ include "wms.fullname" .  }}-{{ include "wms.master-short-name" . }}
{{- end }}

{{/*
Return the full hostname of the master Configuration Server
*/}}
{{- define "wms.master-hostname" -}}
{{- if .Values.diracServer.masterCS.fullHostname -}}
{{- .Values.diracServer.masterCS.fullHostname }}
{{- else -}}
{{- include "wms.master-full-name" . -}}
{{- end }}
{{- end }}

{{/*
Return the master Configuration Server URL
*/}}
{{- define "wms.master-cs-url" -}}
{{- $schema := ternary "https" "dips" .Values.diracServer.masterCS.tornado -}}
{{ $schema }}://{{ include "wms.master-hostname" . }}:{{ .Values.diracServer.masterCS.port }}/Configuration/Server
{{- end }}


{{/*
Return the DIRAC component with 'dirac-compName' suffix
Usage:
  {{ include "wms.dirac-comp-suffix" "componentName" }}
*/}}
{{- define "wms.dirac-comp-suffix" -}}
{{- $compName := . -}}
{{- printf "dirac-%s" $compName }}
{{- end }}

{{/*
Return the DIRAC component service name
Usage:
  {{ include "wms.dirac-service-name" (dict "root" . "comp" "componentName") }}
*/}}
{{- define "wms.dirac-service-name" -}}
{{- $root := .root -}}
{{- $compName := .comp -}}
{{ include "wms.fullname" $root }}-{{ include "wms.dirac-comp-suffix" (include "wms.kebab" $compName) }}
{{- end }}

{{/*
Return the DIRAC component app name
Usage:
  {{ include "wms.dirac-app-name" (dict "root" . "comp" "componentName") }}
*/}}
{{- define "wms.dirac-app-name" -}}
{{- $root := .root -}}
{{- $compName := .comp -}}
{{ include "wms.name" $root }}-{{ include "wms.dirac-comp-suffix" (include "wms.kebab" $compName) }}
{{- end }}


{{/*
Convert a string to kebab-case
e.g., proxyManager -> proxy-manager
*/}}
{{- define "wms.kebab" -}}
{{- $str := . -}}
{{- $str = regexReplaceAll "([a-z0-9])([A-Z])" $str "${1}-${2}" -}}
{{- $str | lower -}}
{{- end }}

{{/*
Generate a DIPS URL for a given DIRAC service
Usage:
  {{ include "wms.dipsUrl" (dict "root" . "svc" "wms") }}
*/}}
{{- define "wms.dipsUrl" -}}
{{- $root := .root -}}
{{- $svc := .svc -}}
{{- $svcVal := index $root.Values.diracServer.diracComponents $svc -}}
dips://{{ include "wms.dirac-service-name" (dict "root" $root "comp" $svc) }}:{{ $svcVal.port }}/{{ $svcVal.cmd }}
{{- end }}

{{/*
Init Container waiting for master CS statefulset.
*/}}
{{- define "wms.initContainer.waitForMasterCS" -}}
- name: {{ include "wms.fullname" $ }}-wait-for-master-cs
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
    - bash
    - -c
    - |
      set -ex

      echo "[$(date)] Waiting for master CS StatefulSet to be ready..."
      until kubectl rollout status statefulset/{{ include "wms.master-full-name" $ }} --timeout=5s; do
        echo "Still waiting..."
        sleep 5
      done

      until nc -w5 -z -v {{ include "wms.master-full-name" $ }} 9135; do
        echo "Still waiting for CS service..."
        sleep 5
      done

      echo "Master CS is ready!"
{{- end }}

{{/*
Init Container waiting for bootstrap dirac db.
*/}}
{{- define "wms.initContainer.waitForBootstrapDB" -}}
{{- if $.Values.diracServer.bootstrap.initDiracDb.enabled }}
- name: {{ include "wms.fullname" $ }}-wait-for-bootstrap-dirac-db
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
    - /bin/bash
    - -c
    - |
      set -ex
      echo "[$(date)] Wait for DIRAC databases to be installed..."
      kubectl wait job/{{ include "wms.fullname" $ }}-bootstrap-dirac-db-{{ $.Release.Revision }} --for=condition=complete --timeout=600s || (echo "failed to wait for Job bootstrap-dirac-db";  exit 1)
      echo "DIRAC databases are ready"
{{- end }}
{{- end }}

{{/*
Init Container waiting for DIRAC deployment.
Usage:
  {{ include "wms.initContainer.waitForDiracDeploy" (dict "root" . "compName" "ComponentMonitoring") }}
*/}}
{{- define "wms.initContainer.waitForDiracDeploy" -}}
{{- $root := .root -}}
{{- $compName := .compName -}}
{{- $svcName := include "wms.dirac-service-name" (dict "root" $root "comp" $compName) -}}
- name: {{ include "wms.fullname" $root }}-wait-for-{{ $svcName }}
  image: {{ $root.Values.image.repository_prefix }}-bootstrap:{{ $root.Values.image.tag | default $root.Chart.AppVersion }}
  command:
    - /bin/bash
    - -c
    - |
      set -ex
      echo "[$(date)] Wait for {{ $svcName }} deployment to be ready..."
      kubectl wait deployment/{{ $svcName }} --for=condition=Available=True --timeout={{ $root.Values.diracServer.bootstrap.timeout }} || (echo "failed to wait for {{ $svcName }} deployment";  exit 1)
      echo "{{ $svcName }} ready"
{{- end }}

{{/*
Init Container waiting for DiracX deployment.
Usage:
  {{ include "wms.initContainer.waitForDiracX" $ }}
*/}}
{{- define "wms.initContainer.waitForDiracX" -}}
- name: {{ include "wms.fullname" $ }}-wait-for-diracx
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
    - /bin/bash
    - -c
    - |
      set -ex
      echo "[$(date)] Wait for DiracX to be ready"
      kubectl wait deployment/{{ tpl .Values.diracx_deployment_fullname $ }} --for=condition=Available=True --timeout={{ $.Values.diracServer.bootstrap.timeout }} || (echo "failed to wait for DiracX deployment";  exit 1)
      echo "DiracX ready"
{{- end }}


{{/*
VOMS dirs mount path
Usage:
  {{ include "wms.voms-mount-path" . }}
*/}}
{{- define "wms.voms-mount-path" -}}
{{ default "/etc/grid-security" .Values.diracServer.vomsConfig.mountPath }}
{{- end }}


{{/*
Define init container to set up SSH keys for dirac user
Usage:
  {{ include "wms.initContainer.certKeys" . | nindent 6 }}
*/}}
{{- define "wms.initContainer.certKeys" -}}
- name: setup-cert-and-ssh-keys
  image: harbor.cta-observatory.org/proxy_cache/busybox:latest
  securityContext:
    runAsUser: 0
  command:
    - sh
    - -c
    - |
      set -xe
      echo dirac:x:1000:1000:nobody:/home:/bin/bash >> /etc/passwd
      echo dirac:x:1000: >> /etc/group

      mkdir -p /home/dirac/.ssh
      cp -fv /etc/diracuser_sshkey /home/dirac/.ssh/diracuser_sshkey
      cp -fv /etc/diracuser_sshkey.pub /home/dirac/.ssh/diracuser_sshkey.pub
      cp -fv /etc/diracuser_sshkey.pub /home/dirac/.ssh/authorized_keys
      ls -l /home/dirac/.ssh

      mkdir -p /home/dirac/.globus
      cp -fv /globus/usercert.pem /home/dirac/.globus/usercert.pem
      cp -fv /globus/userkey.pem /home/dirac/.globus/userkey.pem

      chown dirac:dirac -R /home/dirac/
      chmod -R u=rwX,go= /home/dirac/.ssh

      cp -fv /etc/grid-security/hostcert.pem /opt/dirac/etc/grid-security/hostcert.pem
      cp -fv /etc/grid-security/hostkey.pem /opt/dirac/etc/grid-security/hostkey.pem

      chmod 600 /opt/dirac/etc/grid-security/hostcert.pem
      chmod 400 /opt/dirac/etc/grid-security/hostkey.pem

      cp -fvr /etc/grid-security/certificates /opt/dirac/etc/grid-security/certificates
      ln -s {{ include "wms.voms-mount-path" . }}/vomses /opt/dirac/etc/grid-security
      ln -s {{ include "wms.voms-mount-path" . }}/vomsdir /opt/dirac/etc/grid-security
      chown -R dirac:dirac /opt/dirac/etc/

      ls -l /opt/dirac/etc
      ls -l /home/dirac/.ssh
      ls -l /home/dirac/.globus

  volumeMounts:
    {{ include "dpps.common-cert-mounts" . | nindent 4 }}
    {{- if .Values.diracServer.initContainers.certKeys.volumeMounts }}
    {{- toYaml .Values.diracServer.initContainers.certKeys.volumeMounts | nindent 4 }}
    {{- end }}
{{- end }}

{{/*
Init Container synchronizing DiracX CS.
Usage:
  {{ include "wms.initContainer.syncDiracxCS" $ }}
*/}}
{{- define "wms.initContainer.syncDiracxCS" -}}
{{ if $.Values.diracServer.bootstrap.syncDiracxCS.enabled }}
- name: sync-diracx-cs
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
  - /bin/sh
  - -c
  - |
    set -ex

    REMOTE_URL=$(echo $DIRACX_CONFIG_BACKEND_URL | sed 's/git+//;s/?revision=master//')

    echo "Synchronizing DiracX CS"
    kubectl exec statefulset/{{ include "wms.master-full-name" $ }} -- bash -c '
      set -xe
      # Delete eventual non accepted section

      # TODO: make conditional
      export GIT_SSL_CAPATH=/etc/grid-security/certificates/
      export X509_CERT_DIR=/etc/grid-security/certificates

      export DIRACX_CS_PATH=/tmp/$$-$RANDOM-$(date +%s)

      python /home/dirac/delete_section.py -c yes LocalInstallation || true

      git config --global user.name "DIRAC Server CI"
      git config --global user.email "dirac-server-ci@invalid"
      git config --global --add safe.directory $DIRACX_CS_PATH

      git clone '"$REMOTE_URL"' $DIRACX_CS_PATH || true # might already exist
      git -C $DIRACX_CS_PATH checkout master || true

      DIRAC_COMPAT_ENABLE_CS_CONVERSION=x dirac internal legacy cs-sync "/opt/dirac/etc/{{ $.Values.diracServer.configurationName }}.cfg" $DIRACX_CS_PATH/default.yml
      git --git-dir=.git -C $DIRACX_CS_PATH/ commit -am "export $(date)" || true
      git --git-dir=.git -C $DIRACX_CS_PATH/ push --set-upstream origin master
    '
  envFrom:
  - configMapRef:
      name: {{ $.Release.Name }}-dirac-env
  - secretRef:
      name: diracx-secrets
{{- end }}
{{- end }}

{{/*
Init Container to wait for IAM bootstrap job.
Usage:
  {{ include "wms.initContainer.waitBootstrapIAM" $ }}
*/}}
{{- define "wms.initContainer.waitBootstrapIAM" -}}
{{- if $.Values.iam.enabled }}
- name: {{ include "wms.fullname" . }}-wait-for-boostrap-iam
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
    - /bin/sh
    - -c
    - |
      set -ex
      echo "Waiting for iam bootstrap"
      kubectl wait --for=condition=complete job/{{ .Values.iam.fullnameOverride }}-bootstrap-{{ .Release.Revision }} --timeout={{ $.Values.diracServer.bootstrap.timeout }} || (echo "failed to wait for bootstrap IAM job";  exit 1)
{{- end }}
{{- end }}

{{/*
Init Container to wait for DIRAC Configure bootstrap job.
Usage:
  {{ include "wms.initContainer.waitForBootstrapConf" $ }}
*/}}
{{- define "wms.initContainer.waitForBootstrapConf" -}}
- name: {{ include "wms.fullname" . }}-wait-for-boostrap-dirac-configure
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
    - /bin/sh
    - -c
    - |
      set -ex
      echo "Waiting for bootstrap dirac configure"
      kubectl wait --for=condition=complete job/{{ include "wms.fullname" $ }}-bootstrap-dirac-configure-{{ .Release.Revision }} --timeout={{ $.Values.diracServer.bootstrap.timeout }} || (echo "failed to wait for bootstrap dirac configure job";  exit 1)
{{- end }}

{{/*
Init Container to wait for sync DIRAC bootstrap job.
Usage:
  {{ include "wms.initContainer.waitForBootstrapSyncDirac" $ }}
*/}}
{{- define "wms.initContainer.waitForBootstrapSyncDirac" -}}
- name: {{ include "wms.fullname" . }}-wait-for-boostrap-dirac-sync-dirac
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
    - /bin/sh
    - -c
    - |
      set -ex
      echo "Waiting for bootstrap sync dirac"
      kubectl wait --for=condition=complete job/{{ include "wms.fullname" $ }}-bootstrap-sync-dirac-{{ $.Release.Revision }} --timeout={{ $.Values.diracServer.bootstrap.timeout }} || (echo "failed to wait for bootstrap sync dirac job";  exit 1)
{{- end }}

{{/*
Command to wait for IAM login service.
Usage:
  {{ include "wms.waitIamLoginService" $ }}
*/}}
{{- define "wms.waitIamLoginService" -}}
{{- if or .Values.iam.enabled .Values.iam_external.enabled }}
echo "wait IAM (login-service) UP"
until curl -sf --capath /etc/grid-security/certificates {{ .Values.iam_external.loginServiceURL | default "https://iam.test.example" }}/actuator/health | grep -q '"status":"UP"'; do
  echo "Waiting for IAM login service..."
  sleep 5
done
{{- end }}
{{- end }}


{{/*
Init Container to run custom sync IAM script
Usage:
  {{ include "wms.initContainer.syncIamUsers" $ }}
*/}}
{{- define "wms.initContainer.syncIamUsers" -}}
- name: {{ include "wms.fullname" . }}-sync-iam-users
  image: {{ $.Values.image.repository_prefix }}-bootstrap:{{ $.Values.image.tag | default $.Chart.AppVersion }}
  command:
    - /bin/sh
    - -c
    - |
      set -ex
      echo "Syncing IAM users to DIRAC..."

      REMOTE_URL=$(echo $DIRACX_CONFIG_BACKEND_URL | sed 's/git+//;s/?revision=master//')

      count=1

      while [ $count -le {{ .Values.diracServer.bootstrap.syncIamUsers.retry }} ]; do
        if kubectl exec statefulset/{{ include "wms.master-full-name" $ }} -- bash -c '
          source /opt/dirac/bashrc

          export GIT_SSL_CAPATH=/etc/grid-security/certificates
          python /home/dirac/sync_iam_users.py -c yes

        '; then
          echo "Sync completed successfully"
          break
        else
          echo "Sync IAM users failed at attempt $count/{{ .Values.diracServer.bootstrap.syncIamUsers.retry }}"
          if [ $count -lt {{ .Values.diracServer.bootstrap.syncIamUsers.retry }} ];then
            echo "Retrying in 10s..."
            sleep 10
          fi
        fi
        count=$((count + 1))
      done
  envFrom:
  - secretRef:
      name: diracx-secrets

{{- end }}


# SSH keys volumes and mounts
{{- define "dpps.ssh-keys-volumes" }}
- name: diracuser-sshkey-600
  secret:
    defaultMode: 0600
    secretName: {{ include "certprefix" . }}-diracuser-sshkey
- name: diracuser-sshkey-644
  secret:
    defaultMode: 0644
    secretName: {{ include "certprefix" . }}-diracuser-sshkey
{{- end }}

{{- define "dpps.ssh-keys-volume-mounts" }}
- name: diracuser-sshkey-600
  subPath: ssh-diracuser_sshkey
  mountPath: /etc/diracuser_sshkey
- name: diracuser-sshkey-644
  subPath: ssh-diracuser_sshkey.pub
  mountPath: /etc/diracuser_sshkey.pub
{{- end }}

# Grid certs volumes and mounts
{{- define "dpps.certkeys-volumes" }}
- name: dppsuser-certkey-600
  secret:
    defaultMode: 0600
    secretName: {{ include "certprefix" . }}-dppsuser-certkey
- name: dppsuser-certkey-400
  secret:
    defaultMode: 0400
    secretName: {{ include "certprefix" . }}-dppsuser-certkey
{{- end }}

{{- define "dpps.certkeys-volume-mounts" }}
- name: dppsuser-certkey-400
  mountPath: /globus/userkey.pem
  subPath: dppsuser.key.pem
- name: dppsuser-certkey-600
  mountPath: /globus/usercert.pem
  subPath: dppsuser.pem
{{- end }}

# Host certs volumes mounts
{{- define "dpps.hostcerts-volume-mounts" }}
# host certificates volumes are not defined in the diracServer.volumes
# they must be defined at deployment lvl
- name: dpps-certkey-600
  subPath: hostcert.pem
  mountPath: /etc/grid-security/hostcert.pem
- name: dpps-certkey-400
  subPath: hostkey.pem
  mountPath: /etc/grid-security/hostkey.pem
{{- end }}

# CA Bundle volumes and mounts
{{- define "dpps.grid-ca-bundle-volumes" }}
- name: trust-anchors
  persistentVolumeClaim:
    claimName: {{ tpl .Values.diracServer.commonVolumes.gridcaBundleClaimName . }}
{{- end }}

{{- define "dpps.grid-ca-bundle-volume-mounts" }}
- name: trust-anchors
  mountPath: /etc/grid-security/certificates
  readOnly: true
{{- end }}

{{- define "dpps.ca-bundle-volumes" }}
- name: ca-bundle
  persistentVolumeClaim:
    claimName: {{ tpl  .Values.diracServer.commonVolumes.caBundleClaimName . }}
{{- end }}

{{- define "dpps.ca-bundle-volume-mounts" }}
- name: ca-bundle
  mountPath: /etc/pki
  readOnly: true
{{- end }}

# IAM VOMS dirs volumes and mounts
{{- define "dpps.voms-volumes" }}
- name: vomses
  configMap:
    name: {{ tpl .Values.diracServer.commonVolumes.vomsesConfigMapName . }}
- name: vomsdir
  configMap:
    name: {{ tpl .Values.diracServer.commonVolumes.vomsdirConfigMapName . }}
{{- end }}

{{- define "dpps.voms-volume-mounts" }}
- name: vomses
  mountPath: {{ include "wms.voms-mount-path" . }}/vomses/{{ .Values.diracServer.vomsConfig.voName }}
  subPath: vomses
- name: vomsdir
  subPath: {{ .Values.diracServer.vomsConfig.voName }}
  mountPath: {{ include "wms.voms-mount-path" . }}/vomsdir/{{ .Values.diracServer.vomsConfig.voName }}/{{ .Values.diracServer.vomsConfig.dirName }}
{{- end }}


{{/*
Common DPPS volumes
Usage:
  {{ include "dpps.common-cert-volumes" $ }}
*/}}
{{- define "dpps.common-cert-volumes" }}
{{- include "dpps.ssh-keys-volumes" . }}
{{- include "dpps.certkeys-volumes" . }}
{{- include "dpps.ca-bundle-volumes" . }}
{{- include "dpps.grid-ca-bundle-volumes" . }}
{{- include "dpps.voms-volumes" . }}
{{- end }}

{{/*
Common DPPS volume mounts
Usage:
  {{ include "dpps.common-cert-mounts" $ }}
*/}}
{{- define "dpps.common-cert-mounts" }}
{{- include "dpps.ssh-keys-volume-mounts" . }}
{{- include "dpps.certkeys-volume-mounts" . }}
{{- include "dpps.hostcerts-volume-mounts" . }}
{{- include "dpps.ca-bundle-volume-mounts" . }}
{{- include "dpps.grid-ca-bundle-volume-mounts" . }}
{{- include "dpps.voms-volume-mounts" . }}
{{- end }}


# example usage:
# {{ include "dpps.common-hostkey-volumes" (dict "root" . "secretFullName" .Values.diracServer.masterCS.hostkey.secretFullName "suffix" "dirac-master-cs") }}
{{ define "dpps.common-hostkey-volumes" }}
- name: dpps-certkey-600
  secret:
    defaultMode: 0600
    secretName: {{ coalesce .secretFullName (printf "%s-%s-hostkey" .root.Release.Name .suffix)  }}
- name: dpps-certkey-400
  secret:
    defaultMode: 0400
    secretName: {{ coalesce .secretFullName (printf "%s-%s-hostkey" .root.Release.Name .suffix) }}
{{- end }}


{{/*
Return default environment variables for DIRAC
*/}}
{{- define "wms.defaultEnv" -}}
DB_HOSTNAME: {{ .Values.diracSqlDatabase.host }}
DIRAC_CFG_PATH: "/configurations"
{{- if .Values.diracx.enabled }}
{{- if .Values.diracx.developer.enabled }}
DIRACX_CS_PATH: "/local_cs_store/initialRepo"
{{- else }}
DIRACX_CS_PATH: "{{ .Values.diracx.diracx.settings.DIRACX_CONFIG_BACKEND_URL }}"
{{- end }}
{{- end }}
DIRAC_CFG_MASTER_CS: "/local/masterCS.cfg"
{{- end }}


{{/*
Return default pod resources for DIRAC component
Minimal request + generous limit
*/}}
{{- define "wms.default-resources" -}}
requests:
  cpu: "0.005"
  memory: "64Mi"
limits:
  cpu: "2"
  memory: "2Gi"
{{- end }}


{{/*
Get resources from values or provide default
Usage: {{- include "wms.get-resources" (dict "resources" $.Values.resources $) }}
*/}}
{{- define "wms.get-resources" -}}
{{- $resources := .resources -}}
{{- if $resources -}}
{{- toYaml $resources | nindent 2 -}}
{{- else -}}
{{- include "wms.default-resources" $ | nindent 2 -}}
{{- end }}
{{- end }}


{{/*
General-purpose helper to format a list as a series of assignments in DIRAC format, like:
Users = user1
Users += user2
...
Usage: {{ include "wms.formatDiracConfigListValues" (dict "list" $groupConfig.users "key" "Users") }}
*/}}
{{- define "wms.formatDiracConfigListValues" -}}
  {{- $key := .key -}}
  {{- $list := .list -}}
  {{- $first := true -}}
  {{- range $item := $list -}}
    {{- if $first -}}
      {{- printf "%s = %s" $key $item -}}
      {{- $first = false -}}
    {{- else -}}
      {{- printf "\n%s += %s" $key $item -}}
    {{- end -}}
  {{- end -}}
{{- end -}}


{{/*
Format DIRAC config optional values/
Usage: {{ include "wms.formatDiracConfigOptional" (dict "diracKey" VO "val" $groupConfig.vo "indent" 10) }}
*/}}
{{- define "wms.formatDiracConfigOptional" -}}
{{- $diracKey := .diracKey -}}
{{- $val := .val -}}
{{- $indent := .indent | default 10 -}}
{{- if $val }}{{ printf "%s = %s" $diracKey $val | nindent $indent }}{{- end }}
{{- end -}}
