"""Script for creating users, groups and VOs in DiracX configuration."""

import contextlib
import logging
import os
import subprocess as sp
import tempfile

import requests
import yaml
from DIRAC.ConfigurationSystem.Client.Config import gConfig
from DIRAC.ConfigurationSystem.Client.CSAPI import CSAPI
from DIRAC.Core.Base import Script
from diracx.cli.internal.config import (
    add_group,
    add_user,
    add_vo,
    get_config_from_repo_path,
    get_repo_path,
    update_config_and_commit,
)
from diracx.core.config.schema import Config as CSConfig
from pydantic import BaseModel, field_validator

Script.parseCommandLine()

args = Script.getPositionalArgs()


class User(BaseModel):
    """User to create."""

    username: str
    password: str
    given_name: str | None = None
    family_name: str | None = None
    email: str | None = None
    role: str | None = None
    subject_dn: str | None = None
    groups: list[str] | None = []
    cert: dict | None = None

    @field_validator("given_name", mode="before")
    @classmethod
    def set_given_name(cls, v, values):
        """Use the username to set the given_name if it's not provided."""
        if v is None and values.data and "username" in values.data:
            return values.data["username"].capitalize()
        return v

    @field_validator("family_name", mode="before")
    @classmethod
    def set_family_name(cls, v):
        """Set the family_name to an empty string if it's not provided."""
        return v or ""


class GroupLabel(BaseModel):
    """IAM Groups labels."""

    key: str


class Group(BaseModel):
    """Group to create."""

    name: str
    labels: list[GroupLabel] = []


class Config(BaseModel):
    """IAM helm values config."""

    url: str
    client_id: str
    client_secret: str


def _extract_config(config_path: str):
    """Extract yaml config from file."""
    try:
        # Load and parse the configuration using Pydantic
        with open(config_path) as file:
            config_data = yaml.safe_load(file)
        return Config.model_validate(config_data)
    except FileNotFoundError:
        logging.error("Config file not found")
        raise RuntimeError("Config file not found")
    except ValueError as e:
        logging.error("Error parsing config file: %s", e)
        raise RuntimeError(f"Error parsing config file: {e}")
    except Exception as e:
        logging.error("Error parsing config file: %s", e)
        raise RuntimeError(f"Error parsing config file: {e}")


def _get_iam_token(iam_config: Config) -> str:
    """Get a token using the client credentials flow."""
    query = os.path.join(iam_config.url, "token")
    params = {"grant_type": "client_credentials"}

    response = requests.post(
        query,
        auth=(iam_config.client_id, iam_config.client_secret),
        params=params,
        timeout=5,
    )
    if not response.ok:
        logging.error(
            "Failed to get an admin token: %s %s", response.status_code, response.reason
        )

        raise RuntimeError("Failed to get an admin token")
    return response.json()["access_token"]


def get_iam_users(token: str, url: str, start_index: int) -> dict:
    """Retrieve users and ids from IAM api."""
    query = os.path.join(url, "scim/Users")
    #  "filter": f"userName eq \"{user_name}\"" doesn't seems to work
    params = {"attributes": "userName", "startIndex": start_index}
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    response = requests.get(
        query,
        headers=headers,
        params=params,
        timeout=5,
    )
    if not response.ok:
        logging.error(
            "Failed to query scim/Users %s %s", response.status_code, response.reason
        )

        raise RuntimeError(
            f"Failed to query scim/Users: {response.status_code} { response.reason}"
        )
    return response.json()


def find_user_ids(token: str, iam_config: Config, users: set, max_index: int = 400):
    """Find IAM users id."""
    user_ids = {}
    for start_index in range(1, max_index, 100):
        iam_users = get_iam_users(token, iam_config.url, start_index)
        if iam_users["Resources"]:
            for resource in iam_users["Resources"]:
                if resource["userName"] in users:
                    user_ids[resource["userName"]] = resource["id"]
        else:
            logging.warning("get_iam_users returned no resources: %s", iam_users)
    if not user_ids:
        raise RuntimeError(f"Users {users} not found in IAM, found: {user_ids.keys()}")
    return user_ids


def get_groups_infos() -> dict:
    """Extract group infos from DIRAC api."""
    cs_api = CSAPI()
    res_group_list = cs_api.listGroups()
    if res_group_list["OK"]:
        group_list = res_group_list["Value"]
    else:
        logging.warning(res_group_list)
        exit(1)
    groups_infos = {}
    for group in group_list:
        res_group_info = cs_api.describeGroups(group)
        if res_group_info["OK"]:
            groups_infos.update(res_group_info["Value"])
        else:
            logging.warning(res_group_info)
    return groups_infos


def get_registry_vo():
    """Extract VOs from DIRAC registry."""
    res_vos = gConfig.getSections("/Registry/VO")
    if res_vos["OK"]:
        return res_vos["Value"]
    else:
        logging.warning(res_vos)


def get_default_group():
    """Extract default_group from DIRAC registry."""
    default_group = gConfig.getValue("/Registry/DefaultGroup")
    if default_group:
        return default_group
    else:
        logging.warning(default_group)


def set_idp_client_id(vo: str, client_id: str):
    """Set the IdP ClientID value in DIRAC cfg."""
    cs_api = CSAPI()
    section = f"/DiracX/CsSync/VOs/{vo}/IdP"
    res_section = cs_api.createSection(section)
    if not res_section["OK"]:
        logging.warning("Can't create section %s", section)
    res_set_option = cs_api.setOption(f"{section}/ClientID", str(client_id))
    if res_set_option["OK"]:
        res_commit = cs_api.commit()
        if res_commit["OK"]:
            logging.info("DiracX IdP client ID set to %s for vo %s.", client_id, vo)
        else:
            logging.warning("Did not commit: %s", res_commit)
    else:
        logging.warning("Cannot set ClientID value for vo %s: %s", vo, res_set_option)


def set_user_subjects(vo: str, users: dict):
    """Update DIRAC DiracX UserSubjects."""
    cs_api = CSAPI()
    section = f"/DiracX/CsSync/VOs/{vo}/UserSubjects"
    res_section = cs_api.createSection(section)
    if not res_section["OK"]:
        logging.warning("Can't create section %s", section)

    for user_name, user_subject in users.items():
        res_set_option = cs_api.setOption(f"{section}/{user_name}", user_subject)
        if res_set_option["OK"]:
            res_commit = cs_api.commit()
            if res_commit["OK"]:
                logging.info("UserSubject set for user %s in vo %s.", user_name, vo)
            else:
                logging.warning("Did not commit: %s", res_commit)
        else:
            logging.warning(
                "Cannot set %s subject in vo %s: %s", user_name, vo, res_set_option
            )


def set_default_group(vo: str, default_group: str):
    """Set DIRAC DiracX DefaultGroup."""
    cs_api = CSAPI()
    section = f"/DiracX/CsSync/VOs/{vo}"
    res_section = cs_api.createSection(section)
    if not res_section["OK"]:
        logging.warning("Can't create section %s ", section)

    res_set_option = cs_api.setOption(f"{section}/DefaultGroup", default_group)
    if res_set_option["OK"]:
        res_commit = cs_api.commit()
        if res_commit["OK"]:
            logging.info("DefaultGroup for vo %s set to %s", vo, default_group)
        else:
            logging.warning("Did not commit: %s", res_commit)
    else:
        logging.warning("Cannot set DefaultGroup for vo %s: %s", vo, res_set_option)


def update_dirac_diracx_section(registry_infos: dict, client_id: str):
    """Update DIRAC DiracX section with registry information."""
    for vo, infos in registry_infos.items():
        set_default_group(vo, infos.get("default_group"))
        set_idp_client_id(vo, client_id)
        set_user_subjects(vo, infos.get("users"))


def delete_registry_section(config_repo):
    """Delete DiracX cfg registry section."""
    repo_path = get_repo_path(config_repo)
    config = get_config_from_repo_path(repo_path)

    if config.Registry:
        config = CSConfig(**config.model_dump(exclude={"Registry"}), Registry={})
        update_config_and_commit(
            repo_path=repo_path,
            config=config,
            message="Empty Registry section.",
        )
        logging.info("Successfully empty Registry section in Diracx CS")


def _add_vo(client_id, config_repo, issuer, default_group, vo):
    try:
        add_vo(
            config_repo=config_repo,
            vo=vo,
            default_group=default_group,
            idp_url=issuer,
            idp_client_id=client_id,
        )
    except Exception as e:
        if "already exists" in str(e):
            logging.warning("VO %s already exists, skipping creation", vo)
        else:
            raise


def _add_group(config_repo, registry, users, vo):
    user_group_map = {}
    for group_name, group_values in registry["groups"].items():
        if group_name == registry["default_group"]:
            continue
        properties = group_values["Properties"]
        for user in users:
            if user in group_values["Users"]:
                user_group_map.setdefault(user, []).append(group_name)

        logging.info(
            "Creating group %s , with properties %s in DiracX cfg",
            group_name,
            properties,
        )
        try:
            add_group(
                config_repo=config_repo,
                vo=vo,
                group=group_name,
                properties=properties,
            )
            logging.info("group %s created, with properties %s", group_name, properties)
        except Exception as e:
            if "already exists" in str(e):
                logging.warning(
                    "group %s already exists, skipping creation", group_name
                )
            else:
                continue

    return user_group_map


def _add_user(users, user_group_map, config_repo, vo):
    for username, sub in users.items():
        logging.info("Creating user %s in DiracX cfg", username)
        if username in user_group_map:
            try:
                add_user(
                    config_repo=config_repo,
                    vo=vo,
                    groups=user_group_map[username],
                    sub=sub,
                    preferred_username=username,
                )
                logging.info("user %s created", username)
            except Exception as e:
                if "already exists" in str(e):
                    logging.warning(
                        "user %s already exists, skipping creation", username
                    )
                else:
                    continue


def update_diracx_cs(
    registry_config: dict,
    iam_config: Config,
    users: dict,
    config_repo: str,
):
    """Add vo, users and groups to the DiracX cfg."""
    logging.info("Updating DiracX config")
    # We first need to reset the Registry section in DiracX CS
    # otherwise we can't set the IdP client id using add_vo
    delete_registry_section(config_repo)
    for vo, registry in registry_config.items():
        _add_vo(
            iam_config.client_id,
            config_repo,
            iam_config.url,
            registry["default_group"],
            vo,
        )

        user_group_map = _add_group(config_repo, registry, users, vo)

        _add_user(users, user_group_map, config_repo, vo)


def create_users(config_repo):
    """Create VO, Users and Groups in DiracX configuration."""
    iam_config = _extract_config(os.environ["IAM_CONFIG_PATH"])

    admin_access_token = _get_iam_token(iam_config)

    groups_infos = get_groups_infos()
    users = {user for info in groups_infos.values() for user in info["Users"]}

    users_infos = find_user_ids(admin_access_token, iam_config, users)
    vos = get_registry_vo()
    registry_infos = {}
    default_group = get_default_group()

    for vo in vos:
        registry_infos[vo] = {
            "default_group": default_group,
            "users": users_infos,
            "groups": groups_infos,
        }

    update_diracx_cs(
        registry_config=registry_infos,
        iam_config=iam_config,
        users=users_infos,
        config_repo=config_repo,
    )
    update_dirac_diracx_section(registry_infos, iam_config.client_id)


def set_git_user(repo_path: str):
    """Set git user for the repo."""
    sp.run(
        ["git", "config", "user.name", "DiracX Sync Script"], cwd=repo_path, check=True
    )
    sp.run(
        ["git", "config", "user.email", "diracx-sync@example.com"],
        cwd=repo_path,
        check=True,
    )


@contextlib.contextmanager
def cs_repo():
    """Context manager to handle config repo cloning and cleanup."""
    dirac_cs_path = os.environ["DIRACX_CS_PATH"]

    if dirac_cs_path.startswith("git+file://"):
        repo_path = dirac_cs_path.replace("git+file://", "")
        yield repo_path
        return

    if dirac_cs_path.startswith("git+https://"):
        with tempfile.TemporaryDirectory() as tmp_dir:
            repo_path = os.path.join(tmp_dir, "config-repo")
            remote_url = dirac_cs_path.replace("git+", "")
            logging.info("Cloning config repo from %s to %s", remote_url, repo_path)
            sp.run(["git", "clone", remote_url, repo_path], check=True)

            # checkout the branch specified in DIRACX_CS_PATH or master if not specified
            branch = "master"
            if "?" in dirac_cs_path:
                query = dirac_cs_path.split("?")[1]
                params = dict(param.split("=") for param in query.split("&"))
                branch = params.get("revision", "master")
            logging.info("Checking out branch %s", branch)

            # if branch does not exist, create it
            result = sp.run(
                ["git", "rev-parse", "--verify", branch],
                cwd=repo_path,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                logging.info(
                    "Branch %s does not exist, creating it based on master", branch
                )
                sp.run(
                    ["git", "checkout", "-b", branch, "origin/master"],
                    cwd=repo_path,
                    check=True,
                )
            else:
                sp.run(["git", "checkout", branch], cwd=repo_path, check=True)

            yield repo_path

            logging.info("Pushing changes to remote %s", remote_url)
            sp.run(["git", "push"], cwd=repo_path, check=True)
            return

    raise ValueError("DIRACX_CS_PATH must start with git+file:// or git+https://")


if __name__ == "__main__":
    with cs_repo() as config_repo:
        create_users(config_repo)
