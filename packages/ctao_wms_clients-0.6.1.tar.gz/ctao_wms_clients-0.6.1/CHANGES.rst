WMS 0.6.1 (2026-04-17)
----------------------


API Changes
~~~~~~~~~~~


Bug Fixes
~~~~~~~~~

- Support a case when dirac component service name does not match service hostname. [`!215 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/215>`__]

- Create secrets for configuration containing database credentials. [`!217 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/217>`__]


New Features
~~~~~~~~~~~~

- Rework bootstrap sequence ensuring Master CS is correctly configure before installing DBs and components. [`!210 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/210>`__]


Maintenance
~~~~~~~~~~~


Refactoring and Optimization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

WMS 0.6.0 (2026-04-08)
----------------------


API Changes
~~~~~~~~~~~


Bug Fixes
~~~~~~~~~


New Features
~~~~~~~~~~~~

- Add pods resources [`!109 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/109>`__]

- feat: add PV to keep cs_backup for statefulset [`!144 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/144>`__]

- Enable k8 upgrade test. [`!149 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/149>`__]

- Enable VOMS2CS Agent to replace custom sync IAM script. [`!153 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/153>`__]

- Restore Master CS cfg on restart [`!156 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/156>`__]

- Init proxy for multiple groups and allow retries [`!158 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/158>`__]

- Refactor enabling bootstrap jobs.
  List sites in the values to 'allow' in RSS. [`!159 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/159>`__]

- Sync IAM users in the cron job.
  Wait for the cron job to have run once before init proxy. [`!160 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/160>`__]

- Change default values to disable diracx developer mode. Integration test now also runs not in diracx dev mode. [`!164 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/164>`__]

- Use setOption instead of modifyValue while updating DiracX section.
  Restore sync DiracX CS and IAM in bootstrap DIRAC job instead of waiting for the cronjob [`!168 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/168>`__]

- Add VO, VOMSRole and more in DIRAC registry groups values. [`!175 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/175>`__]

- Allow VOMSServer configuration in DIRAC Registry. [`!178 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/178>`__]


Maintenance
~~~~~~~~~~~

- Update AIV toolkit from cta-computing common [`!145 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/145>`__]

- Update the cvmfs subchart used for integration tests to version v0.7.0.
  Configure dirac to expect the rucio configuration for jobs in CVMFS. [`!150 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/150>`__]

- Remove resetDatabasesOnStart from values. [`!161 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/161>`__]

- Update CTADIRAC version using CWLJob fix. [`!202 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/202>`__]


Refactoring and Optimization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

WMS v0.5.4 (2026-02-17)
-----------------------

- Update diracx charts to diracx-1.0.9 [`!139 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/139>`__]

- Update diracx services and client images to v0.0.8 [`!139 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/139>`__]

- Fix unused volumes / volumeMounts options for dirac components.  [`!140 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/140>`__]

- Allow separate configuration of rucio config for dirac server components and test CE.  [`!140 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/140>`__]

- Refactor DIRAC bootstrap logic. [`!136 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/136>`__]

- Create a cron job to sync DiracX CS. [`!136 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/136>`__]

WMS v0.5.3 (2026-02-02)
-----------------------

- Update cert-generator subchart and fix aiv dependency reference to CVMFS. [`!137 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/137>`__]

WMS v0.5.2 (2026-01-30)
-----------------------

- Make wait-timeout for bootstrap jobs configurable. [`!135 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/135>`__]

WMS v0.5.1 (2026-01-30)
-----------------------

- Update the CVMFS subchart to v0.6.0 [`!134 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/134>`__]


WMS v0.5.0 (2026-01-30)
-----------------------

New Features
~~~~~~~~~~~~

- Deploy one pod per DIRAC component, create a Statefulset for the master CS [`!86 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/86>`__]

- Update diracx release to v0.0.2 [`!95 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/95>`__]

- Add installation of dirac-cwl prototype in the client image. [`!96 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/96>`__]

- Registry section can now be configurable from the values [`!120 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/120>`__]

- Create default DIRAC component configuration template [`!120 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/120>`__]

- Allow to provide custom component configuration under ``diracComponent.<comp>.config`` [`!120 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/120>`__]


Maintenance
~~~~~~~~~~~

- Disable authentication mechanisms other than public key in the sshd server of the test ce.
  This should fix AppArmor preventing login from dirac-server to dirac-ce. [`!105 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/105>`__]

- fix CWLJob issue using CTADIRAC 3.0.8 [`!121 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/121>`__]


WMS v0.4.0 (2025-09-26)
-----------------------

Major update including update to DIRAC 9.0 + DiracX.

We do not fore-see an upgrade path from an existing WMS v0.3.1 installation.


New Features
~~~~~~~~~~~~

- Update charts with DiracX + CTADIRAC 3.0.2 (DIRAC 9.0) [`!57 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/57>`__]

- Update rucio to 38.2 to sync with BDMS. [`!68 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/68>`__]


Bug Fixes
~~~~~~~~~

- Replace bitnami images with legacy versions, make configurable to allow future replacement with custom updated images. [`!66 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/66>`__]


WMS v0.3.1 (2025-07-14)
-----------------------


Maintenance
~~~~~~~~~~~

- Update cvmfs chart to version 0.5.0. [`!61 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/61>`__]


WMS v0.3.0 (2025-06-26)
-----------------------

API Changes
~~~~~~~~~~~

- Replace custom mysql deployment by including the bitnami mariadb helm chart.
- Improve structure in values to more clearly show which options apply to which
  pods. See the chart documentation for new values. [`!51 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/51>`__]


New Features
~~~~~~~~~~~~

- Update CTADIRAC dependency to 2.2.81 to enable CWLJob running CWL workflows [`!58 <https://gitlab.cta-observatory.org/cta-computing/dpps/workload/wms/-/merge_requests/58>`__]


WMS v0.2.0 (2025-05-08)
-----------------------

* New CWL interface for job submission

WMS v0.1.0 (2025-02-21)
-----------------------

Initial release of the Workload Management System.

* Deployment of DIRAC 8 with CTADIRAC using helm.
* Python client package pinning correct version of CTADIRAC.
* Docker image for DIRAC server, clients and a test computing element
