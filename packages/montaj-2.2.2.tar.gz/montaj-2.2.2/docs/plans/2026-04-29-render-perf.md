# Render Performance — Parallel Segments + Hardware Encode

## Atomized Changes

| File | Action | Purpose |
|---|---|---|
| `montaj_assets/render/compose.js` | Modify | Replace serial `for` loop over `segments` with bounded-concurrency `pMap`. Make the encode call awaitable. |
| `montaj_assets/render/encode-segment.js` | Modify | Add async variant `encodeSegmentAsync(segment, outputPath, opts)` using `spawn` + Promise wrapper. Keep `encodeSegment` (sync) as a thin shim around it for backwards-compat with any direct callers. Stream stderr through to caller log so parallel segments don't get their errors swallowed. |
| `montaj_assets/render/encode-segment.js` | Modify | Honor `opts.encoder` override: when set to `videotoolbox`, swap `libx264`/`libx265` for `h264_videotoolbox`/`hevc_videotoolbox` and replace `-preset fast -crf N` with `-q:v N`. Leave color-conversion filter chain untouched. |
| `montaj_assets/render/render.js` | Modify | Add `--fast` CLI flag. When set, threads `{ encoder: 'videotoolbox', concurrency: 4 }` through to `compose()`. Default behavior unchanged. |
| `montaj_assets/render/compose.js` | Modify | Accept `opts.encoder` and `opts.concurrency` from caller; pass `opts.encoder` into each `encodeSegmentAsync()`; cap `concurrency` at 2 for libx264/libx265, 4 for videotoolbox. |
| `montaj_assets/render/encode-segment.js` | Keep | Existing filter graph builders (`buildColorConversionFilter`, layering loop, audio mux) — no changes; the encoder swap is a single argv substitution at the end. |
| `tests/render/test_encode_segment.js` *(if exists; else create)* | Create/Modify | Add a dry-run test asserting that `opts.encoder: 'videotoolbox'` produces argv with `h264_videotoolbox` for SDR and `hevc_videotoolbox` for HDR, and that color args (`-colorspace`, `-color_primaries`, `-color_trc`) are still emitted. |
| `tests/render/test_compose_parallel.js` *(create)* | Create | Spy-based test: invoke `compose()` with 5 segments and a mocked `encodeSegmentAsync` that records start/end timestamps. Assert at most `concurrency` segments overlap in time, all complete, and `segPaths` are in segment-index order. |
| `docs/plans/2026-04-29-render-perf.md` | Create | This plan. |
| `../landing-montaj/docs/content/docs/render.mdx` | Modify | Document the parallel segment behavior (Step 7 — Compositing) and the `--fast` flag (under "GPU acceleration"). |

---

## Plain-English Summary

**The problem.** Rendering a project with many cuts is slow. The render engine encodes each timeline segment one after another, even though every segment is an independent ffmpeg job. On a typical 30-cut talking-head project the compose stage spends most of its time blocking on a single ffmpeg process while the rest of the CPU sits idle.

**What changes for the user.**
- **By default, faster renders.** The compose stage encodes multiple segments at the same time (capped at 2 to avoid blowing out memory on 4K projects). Expect roughly a 2× wall-clock speedup on cut-heavy projects with no quality change. No flag, no config — it just gets faster.
- **A new opt-in `--fast` flag** swaps software encoding (libx264 / libx265) for macOS's built-in hardware encoder (VideoToolbox). When it works, it's another 5–10× faster on top of the parallelism win. Quality is slightly lower at the same bitrate (hardware encoders are coarser than libx264 medium), so it stays opt-in. Picture: a 5-minute project that today takes 8 minutes to compose drops to under a minute with `--fast`.

**What is NOT changing.**
- File format, codec, color space, container — all unchanged. Output is still bit-identical in format, just produced faster.
- The normalize pre-pass, Puppeteer overlay rendering, and final concat are already parallel or trivially fast — they're not touched here.
- The default render path stays on libx264/libx265. `--fast` is opt-in until we have field data on quality acceptability.
- Project.json schema — no changes.

**The trade.** Parallelism means we sometimes hold N decoded segments worth of pixel buffers in memory simultaneously. We cap concurrency at 2 for libx264/libx265 (the same cap normalize uses) so a 4K HDR project on an 8GB-free machine still fits. VideoToolbox is much lighter on RAM since the encode is offloaded to the media engine, so its cap can be 4.

**Decisions made and why.**
- **Cap = 2 for software encode**, not "number of CPU cores." libx264 internally uses multiple threads already; running 8 instances doesn't make it 8× faster, it makes it contend on cache and memory bandwidth. 2 is the sweet spot empirically (matches normalize) and is what other tools in this codebase already do.
- **VideoToolbox is opt-in, not default.** Hardware encoders trade quality for speed. We don't yet have systematic A/B comparisons of perceptual quality on Montaj's typical content (talking heads, captioned overlays). Until we do, the safe default is libx264.
- **No filter-graph changes.** The aspect-fit, color-conversion, and overlay layering all stay on the CPU — they have to, because VideoToolbox doesn't accept the same filter chain as libx264. Only the *encode* step is swapped. This is also why the perf headline is "5–10×" not "20×" — we save on the encode but still pay for the filter chain.
- **No `concurrency` flag in v1.** The internal cap is good enough; exposing it invites users to crank it past safe values. Revisit if a power user has a real reason.

**Follow-up plans that complete the story.**
- A separate plan would add VideoToolbox quality validation (PSNR/SSIM vs libx264 reference, on talking-head + caption-heavy + overlay-heavy projects) before considering making `--fast` the default.
- A separate plan would benchmark whether the same parallelism win applies to the normalize pre-pass at higher caps — the current cap of 2 was set conservatively for libx265 4K HDR; it may be safe to bump to 3 for libx264 SDR.

---

## Background

`compose.js:73` iterates `segments` serially:

```js
for (let i = 0; i < segments.length; i++) {
  const seg = segments[i]
  seg.colorSpace = projectColorSpace
  const segPath = join(segDir, `seg-${String(i).padStart(4, '0')}.mp4`)
  clog(...)
  encodeSegment(seg, segPath)   // ← spawnSync, blocks
  segPaths.push(segPath)
}
```

`encodeSegment()` at `encode-segment.js:120` builds a filter graph and shells out to `ffmpeg` via `spawnSync`. For a 29-segment compose with ~3-second segments at 4K, total wall time is roughly `29 × per-segment-encode` — dominated by libx264. The CPU on segments 2..N is under-utilized while segment 1 encodes. There is no shared state between segments; they read different items, write different output files, and concat picks them up by name in order.

Two orthogonal levers:

1. **Run them in parallel.** Trivially correct (segments are independent); the only constraint is memory + libx264 thread contention.
2. **Use a faster encoder.** VideoToolbox on macOS is hardware-accelerated and roughly an order of magnitude faster at the cost of slightly worse rate-distortion than libx264 medium. Both `h264_videotoolbox` and `hevc_videotoolbox` are widely supported by Homebrew ffmpeg builds.

The two stack: parallel + VideoToolbox is the maximum win.

---

## Task A — Parallelise the segment encoder

### Implementation

1. **Add `encodeSegmentAsync(segment, outputPath, opts)`** alongside the existing sync version. Use `child_process.spawn` (not `spawnSync`) and resolve the returned Promise on `close`. Keep the timeout via `setTimeout` + `proc.kill('SIGKILL')`, mirroring the pattern already used in `render.js::normalizeIfNeeded`. Pipe stderr through to the caller's log so concurrent failures don't get swallowed.

2. **Keep the sync `encodeSegment()`** as a thin shim that calls the async version and uses a deasync-style wait — actually no, simpler: just keep the sync version unchanged for any direct callers. Compose.js will call the async version directly.

3. **Replace the serial loop in `compose.js:73`** with a bounded-concurrency `pMap` (we already have one in `render.js`; lift it into a shared `montaj_assets/render/p-map.js` to avoid duplication, OR just inline a small copy — it's 12 lines):

```js
const SEGMENT_CONCURRENCY = opts.encoder === 'videotoolbox' ? 4 : 2

await pMap(segments, async (seg, i) => {
  seg.colorSpace = projectColorSpace
  const segPath = join(segDir, `seg-${String(i).padStart(4, '0')}.mp4`)
  clog(`segment ${i + 1}/${segments.length} (${seg.start.toFixed(2)}-${seg.end.toFixed(2)}s): ` +
       `${seg.items.length} item(s), ${seg.overlays.length} overlay(s)`)
  await encodeSegmentAsync(seg, segPath, { encoder: opts.encoder })
  segPaths[i] = segPath
}, SEGMENT_CONCURRENCY)
```

Note the `segPaths[i] = segPath` assignment by index, not `push` — concat order must be preserved regardless of completion order.

### Validation

- Existing render snapshot tests must still pass byte-for-byte (libx264 produces identical output regardless of which order segments encode in, assuming inputs are deterministic).
- New test: invoke `compose()` with a mocked `encodeSegmentAsync` that records `(segIdx, start, end)` timestamps; assert no more than `SEGMENT_CONCURRENCY` segments overlap in time and final `segPaths` order matches segment index order.
- Manual: render a 30-cut project; confirm wall time drops by approximately the concurrency factor and final video frames byte-match the serial-render reference.

### Risk

Low. Each ffmpeg invocation reads disjoint inputs and writes disjoint outputs. No shared mutable state.

---

## Task B — VideoToolbox opt-in via `--fast`

### Implementation

1. **CLI flag in `render.js`.** Add `--fast` to argv parsing. When set, pass `encoder: 'videotoolbox'` through `compose()`'s opts.

2. **Encoder swap in `encode-segment.js`.** At the point where the spec's encoder argv is appended (currently `-c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p` for SDR, `-c:v libx265 -preset fast -crf 22 -pix_fmt yuv420p10le` for HDR), branch on `opts.encoder`:

```js
if (opts.encoder === 'videotoolbox') {
  const isHdr = projectColorSpace !== 'sdr_bt709'
  args.push(
    '-c:v', isHdr ? 'hevc_videotoolbox' : 'h264_videotoolbox',
    '-q:v', isHdr ? '50' : '60',         // quality scale, 0-100, higher = better
    '-pix_fmt', spec.outputPixFmt,
    '-tag:v', isHdr ? 'hvc1' : 'avc1',   // ensures Apple-ecosystem playability
  )
} else {
  // existing libx264/libx265 path, unchanged
}
```

The `-q:v` values above are starting points; tune against libx264/libx265 reference. VideoToolbox does not honor `-preset` or `-crf`.

3. **Color args stay.** The existing `*spec.outputColorArgs` (which writes `-colorspace bt709 -color_primaries bt709 -color_trc bt709` and equivalents for HDR) work with VideoToolbox. The metadata stamping happens at the muxer, not the encoder.

4. **HDR caveat to surface in `--help`:** `hevc_videotoolbox` does not write the HDR10 mastering metadata that libx265 with `hdr-opt=1` does. PQ projects rendered with `--fast` will play correctly on most HDR-capable players (the transfer/primaries metadata is correct), but won't carry the static mastering display info. Document this.

### Validation

- Smoke test on each color space (`sdr_bt709`, `hdr_hlg`, `hdr_pq`): render a short project with `--fast`, ffprobe the output, assert codec + transfer + primaries match expectations.
- Visual A/B: render the same SDR project with and without `--fast`; spot-check a few frames for obvious artifacts. (Systematic PSNR/SSIM is out of scope here — that's the follow-up plan.)
- Wall-time benchmark: report before/after on a 30-cut, 5-minute project at 1080p and 4K.

### Risk

Medium. Hardware encoders have edge cases — some filter graphs that libx264 accepts will fail on `_videotoolbox` due to pixel format negotiation. We sidestep this by keeping the entire filter chain on the CPU and only swapping the final encoder; output of the filter chain is `yuv420p` or `yuv420p10le`, both of which VideoToolbox accepts. Still: test on real projects, not just synthetic ones.

---

## Task ordering

A and B are independent. Ship A first (lower risk, default-on benefit), validate snapshot tests still pass, then ship B as opt-in.

If only one ships: A. The default-on perf win for everyone is more valuable than a hardware-only opt-in for macOS users.
