# Container Release Pipeline — Official `montaj` Docker image on ghcr.io

> **Status: Deferred (2026-05-02).** Not implementing in V1. Strategic decision:
> Hub (the closed-source consumer) maintains the Dockerfile in its own repo at
> `~/Work/ByCrux/dev/hub/montaj-sidecar/Dockerfile` and publishes the image to
> Hub's container registry. Montaj OSS continues to distribute via PyPI only.
>
> **Why deferred.** Shipping an official Montaj container in this OSS repo
> lowers the bar for competitors to build Hub-equivalent products. The hard
> half of "wrap Montaj as a sidecar" isn't `pip install` — it's the system
> deps (ffmpeg-with-zscale, Chromium for Puppeteer, whisper.cpp build, Node,
> the volume-mount semantics, the canonical whisper-model path mapping) that
> this Dockerfile encodes. Keeping it in Hub's closed repo is a soft moat —
> not impenetrable (anyone can write their own), but raises activation energy.
>
> **When to revisit:**
> - A real third-party Montaj user asks for an official container.
> - We decide containerization is a Montaj-OSS feature worth advertising.
> - A competitor ships their own Montaj container and the moat collapses.
>
> **The plan content below remains accurate** as a starting point if/when this
> gets reactivated — system deps inventory, multi-stage build pattern, GHA
> workflow shape, PyPI-propagation polling, conditional `:latest` gating,
> smoke test contract — all carry over to either Hub-side or Montaj-side
> implementation. Do not delete; do not implement.
>
> **For now**, see Hub's `montaj-sidecar/Dockerfile` (closed) and Hub's
> `docs/MONTAJ.md` "Image strategy" section for the active V1 design.

---

## Atomized Changes

| File | Action | Purpose |
|---|---|---|
| `Dockerfile` | Create | Reproducible Linux/amd64 container image. **Multi-stage build**: stage 1 (`whisper-builder`) compiles whisper.cpp; stage 2 (runtime) installs only what's needed at runtime (no `build-essential`/`cmake`) and copies the whisper-cli binary across. Base: `python:3.12-slim` (bookworm). Runtime stage installs git, ffmpeg-with-zscale via Jellyfin's repo (with build-time verification that the binary path + zscale filter are present, fail loud if not), Node 20, Chromium, ca-certificates, curl. Installs Montaj from PyPI **with the `[connectors]` extra** (`pip install "montaj[connectors]==${MONTAJ_VERSION}"`) so common steps (Kling, Gemini, OpenAI) work out of the box; `[rvm]` and `[demucs]` deferred (large torch deps). Runs `montaj install ui` at build time to populate the UI runtime cache. **Bakes the default `base.en` whisper model** into the image at the canonical Montaj-managed path `/root/.local/share/montaj/models/whisper/ggml-base.en.bin` (~150MB) — same path `montaj install whisper --model base.en` would write to, and the primary path `lib/common.py:135` reads from at runtime. Also creates a symlink from the legacy path `/root/.local/share/whisper.cpp/models/ggml-base.en.bin` → canonical, so `cli/deps.py:check_deps()` (which still scans the legacy path for backwards compatibility with brew-installed users) passes and `montaj serve` starts cleanly. Exposes :3000. Sets `PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium` + `PUPPETEER_SKIP_DOWNLOAD=true`. Default `CMD` is `["montaj", "serve", "--network"]` (network-bound is required for any container use; without `--network` Montaj binds 127.0.0.1 and `-p` is useless). Includes a comment explaining why the image runs as root (Puppeteer's `--no-sandbox` requires it). |
| `.dockerignore` | Create | Excludes `node_modules`, `dist`, `.git`, `tests`, `docs`, IDE files. Mostly cosmetic since the runtime stage installs from PyPI not from the build context, but keeps the build context lean (~5MB instead of potentially hundreds with checked-in `node_modules`) and avoids accidentally COPY-ing secrets if a future change adds a COPY step. |
| `.github/workflows/container-release.yml` | Create | GitHub Actions workflow. Trigger: `push` to tags matching `v*.*.*` (the same tag `scripts/tag.sh` creates after a PyPI release). Steps: (1) parse tag → version + stable-vs-prerelease flag (`-rc`/`-beta`/etc. → prerelease); (2) **wait for PyPI propagation** by polling `pip download --no-deps montaj==<version>` with a 5-min timeout; (3) `docker/login-action` against ghcr.io; (4) `docker/build-push-action` builds + loads locally; (5) runs `tests/container/test_image_smoke.sh` against the loaded image; (6) pushes the immutable `:vX.Y.Z` tag always, **`:latest` only when the tag is a stable release** (no prerelease suffix) — prevents `v2.1.3-rc1` from regressing production consumers pinned to `:latest`. amd64-only for V1; arm64 follow-up. |
| `tests/container/test_image_smoke.sh` | Create | Smoke test runnable locally and in CI. Runs the passed image with `serve --headless --network`, waits for healthy `/api/info` response on :3000 via `curl`, then verifies system deps inside the running container: `ffmpeg -filters` contains `zscale`, `whisper-cli --help` exits 0, `node --version` ≥ 18, `/usr/bin/chromium` exists, the canonical whisper model `/root/.local/share/montaj/models/whisper/ggml-base.en.bin` exists (size > 100MB), the legacy-path symlink `/root/.local/share/whisper.cpp/models/ggml-base.en.bin` resolves to it, and `git --version` works (required by per-project versioning in `serve/server.py`). Exits 0 on all-pass. |
| `README.md` | Modify | Add a "Container deployment" section near the install instructions: ghcr.io image location, the **two recommended invocations** (standalone with `serve --network`, sidecar with `serve --headless --network`), volume mount semantics (`/root/Montaj` for workspaces, `/root/.local/share/montaj/models/whisper` for additional whisper models if downloading non-default ones at runtime — this is the canonical Montaj-managed path that `montaj install whisper --model X` writes to), example `docker run` commands. Link to landing-montaj container docs for full reference. |
| `../landing-montaj/docs/content/docs/deploy/container.mdx` | Create | User-facing docs. Covers: pulling from ghcr.io, standalone usage, sidecar usage, env vars, volume mount semantics (workspace + whisper-models), image internals (what's baked in: connectors extras, whisper base.en model, ffmpeg-with-zscale, Chromium for Puppeteer), updating to new versions, FAQ on root user. **Verify whether landing-montaj's docs site requires explicit nav config** (`meta.json` or similar) to surface the new page; if so, that file is also Modify in scope. |
| `CHANGELOG.md` | Modify | Note: "Added official Docker image at `ghcr.io/thesampadilla/montaj`. Released alongside PyPI on every tag." |
| `docs/plans/2026-05-02-container-release.md` | Create | This plan. |

---

## Plain-English Summary

**The problem.** Today Montaj installs via PyPI (`pip install montaj`) and is documented for laptop use — `brew install ffmpeg`, `montaj install ui`, etc. There's no first-class containerized distribution. Anyone deploying Montaj as a sidecar to another product (Hub being the immediate driver, but plausibly others later) has to write their own Dockerfile, track Montaj's system deps as they evolve, and maintain that container forever. That's the wrong place to put the cost — containerization belongs with the project being containerized.

**What changes for the user.**
- A new official Docker image at `ghcr.io/thesampadilla/montaj`, published on every PyPI release tag.
- `docker run -p 3000:3000 -v ~/Montaj:/root/Montaj ghcr.io/thesampadilla/montaj:latest` Just Works for laptop-style usage (default CMD is `serve --network`, so the port is actually reachable).
- `docker run --rm ghcr.io/thesampadilla/montaj:latest serve --headless --network` Just Works for sidecar use.
- `:vX.Y.Z` (immutable, **including pre-releases like `v2.1.3-rc1`**) and `:latest` (rolling, **stable releases only — never points at a prerelease**) tags available. Production consumers should pin to `:vX.Y.Z`; `:latest` is for casual / dev use.
- All system deps baked in: ffmpeg-with-zscale (HDR), Node, Chromium, whisper-cli + base.en model, connectors (Kling/Gemini/OpenAI). No follow-up `montaj install …` commands needed at runtime.

**What is NOT changing.**
- PyPI installation continues to work exactly as today. The container is additive.
- Montaj's CLI surface, API surface, workflow registry — unchanged.
- The release process (`version-bump.sh` → commit → `build.sh` → `twine upload` → `tag.sh`) keeps working. The container release rides the existing `v*.*.*` tag push.
- macOS Homebrew install paths (`brew install whisper-cpp`, etc.) unchanged for laptop users not using the container.

**The trade.** Image size is **~2.5GB** (Chromium ~300MB, ffmpeg-with-zscale ~150MB, Node deps + UI build ~500MB, whisper.cpp binary + base.en model ~170MB, connectors Python deps ~100MB, base Python image ~150MB, the rest is core Python deps). Larger than a minimal Python image but unavoidable given Montaj's actual runtime needs. Multi-stage build keeps `build-essential` + `cmake` (~400MB) out of the runtime image — they only exist in the throwaway whisper-builder stage. Single image with everything is the right V1 default; slimmer variants can come later if size becomes painful.

**Decisions made and why.**
- **Single image, not multiple variants** (no separate `:headless`, `:no-whisper`, etc.). One thing to maintain, one thing to test, one thing to publish. Variants are a slimming optimization that should be data-driven (do users actually complain about pull time?) rather than premature.
- **`pip install montaj[connectors]==X.Y.Z`, not bare `pip install montaj`.** The `[connectors]` extra (`pyjwt`, `requests`, `google-genai`, `openai`) is small (~100MB total) and required by common steps (Kling, Gemini, OpenAI). Without it, those steps fail with `ModuleNotFoundError` at runtime — a footgun no container user wants to debug. The other extras (`[rvm]` and `[demucs]`, both ~2GB of torch) are deliberately deferred — too large to bake in by default; users who need them run `pip install montaj[rvm]` against a Python venv volume or build a custom variant.
- **Bake the default `base.en` whisper model into the image** (~150MB) at the canonical path `~/.local/share/montaj/models/whisper/ggml-base.en.bin`. The alternative (require `montaj install whisper` at runtime against a persistent volume mount) is a real footgun: docker users routinely recreate containers, losing the model. `base.en` is Montaj's documented default (`cli/deps.py:WHISPER_MODEL = 'base.en'`); baking it isn't a model lock-in any more than picking that default already was. **Path consistency matters here**: the canonical location is what `cli/commands/models._download` writes to (so a future `montaj install whisper --model small.en` slots into the same directory), what `lib/common.py:135` reads as its primary path, and what `cli/commands/models.is_downloaded` checks (so a re-run of `montaj install whisper --model base.en` is a no-op). The model URL `https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin` is byte-identical to what Montaj's own downloader uses (`cli/commands/models.HF_BASE`), so a hash mismatch on re-install is impossible. The legacy path `~/.local/share/whisper.cpp/models/` (still scanned by `check_deps()` for backwards compat with brew-installed users) is created as a symlink to the canonical path so `montaj serve` startup checks pass. Users wanting alternative models still run `montaj install whisper --model <name>` against a `-v montaj-whisper:/root/.local/share/montaj/models/whisper` named volume — same canonical path that the bake-in uses, so the volume captures both baked and installed models in one mount.
- **Multi-stage build** (`whisper-builder` + runtime). Whisper.cpp's compile pulls `build-essential` + `cmake` (~400-500MB combined) which never get used at runtime; copying just the compiled binary across stages is idiomatic and saves substantial size. `apt purge` in the same stage is the alternative but multi-stage is cleaner.
- **`pip install montaj==X.Y.Z`, not COPY-from-source.** Treats the container as a PyPI consumer like any other — keeps the release artifact (the wheel on PyPI) authoritative. Building from working tree would diverge over time. Cost: a ~30-90s window after `twine upload` where the version isn't visible on PyPI's CDN; mitigated by a polling step in the workflow (Task B).
- **Build arg `MONTAJ_VERSION`, derived from the git tag in CI.** Keeps Dockerfile usable for ad-hoc local builds (`docker build --build-arg MONTAJ_VERSION=2.1.3 .`) and lets CI inject the right version automatically.
- **`scripts/tag.sh` stays the canonical release trigger.** PyPI release happens first (manual), tag push fires the container workflow. Keeps the existing release sequence intact.
- **ghcr.io over Docker Hub.** Free, integrated with GitHub auth, and the `thesampadilla/montaj` namespace mirrors the GitHub repo URL. Docker Hub's rate limits on anonymous pulls would bite consumers.
- **amd64-only for V1.** Multi-arch (arm64) doubles build time and adds complexity; lands as a follow-up when an arm64 consumer asks.
- **`:latest` tag conditional on stable releases only.** Workflow tag pattern `v*.*.*` matches both `v2.1.3` and `v2.1.3-rc1`. Pushing `:latest` for a prerelease would silently regress production consumers pinned to `:latest`. The workflow detects prereleases (tag contains `-`) and skips the `:latest` push for them; pinned `:vX.Y.Z` is always pushed.
- **Default `CMD` is `["montaj", "serve", "--network"]`** (with `--network`, no `--headless`). `--network` is mandatory: without it Montaj binds 127.0.0.1, making `docker run -p 3000:3000` useless because port 3000 inside the container isn't reachable from the host. Headless is *not* default — standalone users get the UI; sidecar users override with their own command (`serve --headless --network`). The `--network` "trusted networks" warning still prints; container deployments satisfy that constraint via the host's port mapping + firewall.
- **Image runs as root.** Puppeteer (used by `montaj_assets/render/`) is invoked with `--no-sandbox --disable-setuid-sandbox`, which only works as root in containers. Switching to a non-root user would break Chromium silently; documented in a Dockerfile comment so a future security pass doesn't naively flip it.

**Follow-up plans that complete the story.**
- **Headless serve mode** ([`./2026-05-02-headless-serve.md`](./2026-05-02-headless-serve.md)) — must land before this plan's container is meaningfully usable as a sidecar. Without `--headless`, sidecar invocations spawn Vite + try to open a browser inside the container, both failing modes. The container release plan does not technically depend on headless landing first, but practically it should.
- **Multi-arch (arm64) build** — as a separate plan once there's an arm64 consumer.
- **Slimming** — a future plan if image size becomes a real complaint. Options: separate `:headless` variant without UI deps, separate `:no-whisper` variant, or moving from `python:3.12-slim` to `python:3.12-alpine` (riskier — alpine's musl can break compiled wheels).
- **Hub's deploy plan** (in the Hub repo) consumes this image. That plan does not block on this one in the abstract — Hub's plan can be written and reviewed in parallel — but Hub cannot **deploy** until this image exists at `ghcr.io/thesampadilla/montaj:vX.Y.Z`.

---

## Background

Montaj's current distribution is PyPI-only. The release sequence today (after editing code):

1. `scripts/version-bump.sh X.Y.Z` — updates `pyproject.toml`, the three `montaj_assets/*/package.json` files, and their lock files.
2. Review diff, commit.
3. `scripts/build.sh` — builds sdist + wheel into `dist/`.
4. `twine upload dist/*` — publishes to PyPI.
5. `scripts/tag.sh` — creates and pushes `vX.Y.Z` git tag.

There are currently **no GitHub Actions workflows** in `.github/`. Everything is manual. This plan adds the first workflow.

The Hub product (`~/Work/ByCrux/dev/hub`) deploys Montaj as a sidecar in its own infrastructure. Hub's deploy story (documented at `~/Work/ByCrux/dev/hub/docs/MONTAJ.md`) calls for pulling `ghcr.io/thesampadilla/montaj:vX.Y.Z` from a Hetzner VM via Cloudflare Tunnel. That story doesn't work until this plan ships.

System deps that need to be baked into the image (verified against current source):

- **ffmpeg with `zscale` filter (libzimg)** — `lib/normalize.py:192–193` checks for it. Default Debian `ffmpeg` ships without zscale → HDR conversions fail. Use Jellyfin's apt repo (`jellyfin-ffmpeg7` package) which ships zscale-enabled. (Strictly speaking it's a third-party apt repo at `repo.jellyfin.org`, not a Launchpad PPA.)
- **git** — `serve/server.py` and `project/init.py` invoke git for per-project history (`git init`, `git add project.json`, `git commit`, `git log`).
- **node ≥ 18** — `montaj_assets/render/package.json` declares `engines.node: >=18`. Render engine uses Puppeteer + esbuild + React.
- **chromium** — Puppeteer needs a browser. Without `PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium`, Puppeteer downloads its own ~300MB Chromium at runtime, which fails in the container's read-only image layer. Setting the env var + `PUPPETEER_SKIP_DOWNLOAD=true` makes Puppeteer reuse the system Chromium.
- **whisper-cli** — `lib/common.py:96–104` resolves whisper.cpp via Montaj-managed binary OR system PATH. Today's `cli/commands/install.py:91–99` only handles `brew install whisper-cpp` on macOS; Linux falls back to "build instructions." This Dockerfile builds whisper.cpp from source during image build and installs the binary at `/usr/local/bin/whisper-cli` so Montaj's runtime PATH fallback finds it.
- **ca-certificates, curl** — TLS for outbound HTTPS (yt-dlp, REST API calls, etc.).

Python deps install transitively from `pip install montaj` (Pillow, yt-dlp, curl_cffi, fastapi, uvicorn, watchdog, httpx, python-multipart per `pyproject.toml`).

Node deps install via `montaj install ui` invocation at build time, which runs `npm install` in the UI runtime dir (`~/.cache/montaj/ui` for prod installs).

---

## Task A — Dockerfile

### Implementation

1. Create `Dockerfile` at the repo root. Multi-stage build:

   ```dockerfile
   # syntax=docker/dockerfile:1.6

   # ---------------------------------------------------------------------------
   # Stage 1: build whisper.cpp (build-essential + cmake stay in this throwaway
   # stage; only the compiled binary makes it to runtime).
   # ---------------------------------------------------------------------------
   FROM python:3.12-slim AS whisper-builder
   ARG DEBIAN_FRONTEND=noninteractive
   RUN apt-get update && \
       apt-get install -y --no-install-recommends \
         git build-essential cmake ca-certificates && \
       rm -rf /var/lib/apt/lists/*
   RUN git clone --depth 1 https://github.com/ggml-org/whisper.cpp /tmp/whisper && \
       cd /tmp/whisper && \
       cmake -B build -DGGML_CUDA=OFF && \
       cmake --build build -j --config Release

   # ---------------------------------------------------------------------------
   # Stage 2: runtime
   # ---------------------------------------------------------------------------
   FROM python:3.12-slim
   ARG MONTAJ_VERSION
   ARG DEBIAN_FRONTEND=noninteractive

   # NOTE: image runs as root. Puppeteer (used by montaj_assets/render/) invokes
   # Chromium with --no-sandbox --disable-setuid-sandbox, which only works as
   # root in containers. Do NOT add `USER nonroot` without first reworking
   # Puppeteer's sandbox setup (would require seccomp profile + capability tuning).

   # Runtime system packages (no build-essential, no cmake)
   RUN apt-get update && \
       apt-get install -y --no-install-recommends \
         ca-certificates curl gnupg \
         git \
         chromium \
       && rm -rf /var/lib/apt/lists/*

   # ffmpeg with zscale (HDR) via Jellyfin's repo. Verify the binary path and
   # zscale availability at build time — Jellyfin's package layout has shifted
   # in past versions; symlinking to a missing path would fall back to /usr/bin/ffmpeg
   # (Debian's stock build, no zscale) and HDR conversions would fail in production
   # with no obvious cause.
   RUN curl -fsSL https://repo.jellyfin.org/jellyfin_team.gpg.key \
         | gpg --dearmor -o /usr/share/keyrings/jellyfin.gpg && \
       echo "deb [signed-by=/usr/share/keyrings/jellyfin.gpg] https://repo.jellyfin.org/master/debian bookworm main" \
         > /etc/apt/sources.list.d/jellyfin.list && \
       apt-get update && \
       apt-get install -y --no-install-recommends jellyfin-ffmpeg7 && \
       rm -rf /var/lib/apt/lists/* && \
       # Verify expected binary path
       test -x /usr/lib/jellyfin-ffmpeg/ffmpeg || \
         (echo "ERROR: jellyfin-ffmpeg7 ffmpeg not at expected path; package layout changed" && exit 1) && \
       test -x /usr/lib/jellyfin-ffmpeg/ffprobe || \
         (echo "ERROR: jellyfin-ffmpeg7 ffprobe not at expected path; package layout changed" && exit 1) && \
       ln -sf /usr/lib/jellyfin-ffmpeg/ffmpeg /usr/local/bin/ffmpeg && \
       ln -sf /usr/lib/jellyfin-ffmpeg/ffprobe /usr/local/bin/ffprobe && \
       # Verify zscale filter is actually present
       ffmpeg -filters 2>/dev/null | grep -q '\bzscale\b' || \
         (echo "ERROR: ffmpeg lacks zscale filter (HDR conversions would fail)" && exit 1)

   # Node 20
   RUN curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && \
       apt-get install -y --no-install-recommends nodejs && \
       rm -rf /var/lib/apt/lists/*

   # whisper-cli — copy compiled binary from stage 1
   COPY --from=whisper-builder /tmp/whisper/build/bin/whisper-cli /usr/local/bin/whisper-cli

   # Pre-download the default whisper model (base.en, ~150MB) so transcribe
   # works out-of-the-box. Three constraints govern the path layout:
   #   1. Canonical write path: ~/.local/share/montaj/models/whisper/ — this is
   #      what `cli/commands/models._download` writes to (the one Montaj uses
   #      when a user runs `montaj install whisper --model X`). Source of truth.
   #   2. Runtime read path: lib/common.py:135 reads from the canonical path
   #      first, falls back to ~/.local/share/whisper.cpp/models/ for users
   #      with brew-installed legacy installs.
   #   3. check_deps() path: cli/deps.py:9 still scans only the LEGACY path
   #      (`~/.local/share/whisper.cpp/models/`) — `montaj serve` aborts at
   #      startup if it doesn't find a model there.
   # We bake at the canonical path AND symlink legacy → canonical, so all three
   # paths see the same file and a future `montaj install whisper --model X`
   # writes to the same directory the volume mount captures.
   #
   # URL is the SAME one cli/commands/models.HF_BASE uses, so re-running
   # `montaj install whisper --model base.en` against the canonical path is
   # a byte-identical no-op (cli/commands/models.is_downloaded short-circuits).
   RUN mkdir -p /root/.local/share/montaj/models/whisper \
                /root/.local/share/whisper.cpp/models && \
       curl -fsSL -o /root/.local/share/montaj/models/whisper/ggml-base.en.bin \
         https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin && \
       # Sanity-check size — partial downloads would silently produce a broken model
       test "$(stat -c%s /root/.local/share/montaj/models/whisper/ggml-base.en.bin)" -gt 100000000 || \
         (echo "ERROR: ggml-base.en.bin download is suspiciously small" && exit 1) && \
       # Symlink legacy path → canonical so cli/deps.py:check_deps() finds it
       # at /root/.local/share/whisper.cpp/models/ggml-base.en.bin.
       ln -sf /root/.local/share/montaj/models/whisper/ggml-base.en.bin \
              /root/.local/share/whisper.cpp/models/ggml-base.en.bin

   # Puppeteer: reuse system Chromium. PUPPETEER_SKIP_DOWNLOAD must be set
   # BEFORE `montaj install ui` runs `npm install` (which triggers Puppeteer's
   # postinstall download otherwise — failing in the layer's read-only context).
   ENV PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium \
       PUPPETEER_SKIP_DOWNLOAD=true

   # Install Montaj from PyPI with the [connectors] extra so common steps
   # (Kling, Gemini TTS, OpenAI) work without a separate runtime install.
   # [rvm] and [demucs] omitted — both pull torch (~2GB) and most users don't need them.
   RUN pip install --no-cache-dir "montaj[connectors]==${MONTAJ_VERSION}"

   # Populate the UI runtime cache (npm install for the UI assets)
   RUN montaj install ui

   # Default workspace mount point
   VOLUME ["/root/Montaj"]

   # Default port (override via MONTAJ_SERVE_PORT)
   ENV MONTAJ_SERVE_PORT=3000
   EXPOSE 3000

   # Default to standalone mode WITH --network (without it, Montaj binds
   # 127.0.0.1 inside the container and `docker run -p 3000:3000` is a no-op).
   # Sidecar consumers override:
   #   docker run ... ghcr.io/thesampadilla/montaj:latest serve --headless --network
   CMD ["montaj", "serve", "--network"]
   ```

2. Create `.dockerignore` at the repo root:
   ```
   .git
   .github
   docs
   tests
   dist
   *.egg-info
   __pycache__
   *.pyc
   .pytest_cache
   .vscode
   .idea
   node_modules
   montaj_assets/*/node_modules
   montaj_assets/*/dist
   ```
   This keeps the build context lean — without it, Docker would tar up `.git/` (potentially hundreds of MB) and ship it to the daemon.

### Validation

- `docker build --build-arg MONTAJ_VERSION=2.1.3 -t montaj:test .` completes successfully. Build fails loudly if the Jellyfin ffmpeg path or zscale filter is missing (build-time `test`/`grep` checks).
- Final image size: **under 3GB** (realistic with multi-stage). If much larger, the multi-stage stripping isn't working — investigate.
- `docker run --rm -p 3000:3000 montaj:test serve --headless --network` boots and listens on :3000.
- `curl http://localhost:3000/api/info` returns 200.
- `docker run --rm montaj:test ffmpeg -filters | grep -w zscale` returns the zscale row.
- `docker run --rm montaj:test whisper-cli --help` returns whisper.cpp usage.
- `docker run --rm montaj:test ls -lh /root/.local/share/montaj/models/whisper/ggml-base.en.bin` shows a ~150MB file (the canonical bake path).
- `docker run --rm montaj:test readlink /root/.local/share/whisper.cpp/models/ggml-base.en.bin` resolves to the canonical path (legacy-path symlink for `check_deps()` compatibility).
- `docker run --rm montaj:test montaj install whisper --model base.en` is a no-op (`cli/commands/models.is_downloaded` finds the baked file at the canonical path and skips the download). Confirms URL + path consistency end-to-end.
- `docker run --rm montaj:test python -c "import google.genai, openai, requests, jwt"` exits 0 (verifies `[connectors]` extras installed).
- `docker run --rm montaj:test node --version` prints v20.x.
- `docker run --rm montaj:test test -x /usr/bin/chromium` exits 0.
- `docker run --rm montaj:test which ffmpeg` returns `/usr/local/bin/ffmpeg` (the symlink), and `readlink /usr/local/bin/ffmpeg` resolves to `/usr/lib/jellyfin-ffmpeg/ffmpeg` (or wherever Jellyfin installs it — verify in case of package layout drift).

### Risk

Medium. Two load-bearing externals:

- **Jellyfin's `jellyfin-ffmpeg7` package layout.** Build-time verification (`test -x ...`) catches a path change immediately rather than producing a silently-broken image; a Jellyfin major version bump (the package name pin to `jellyfin-ffmpeg7` prevents this) would still need a Dockerfile edit.
- **whisper.cpp build from source.** ~2-3 minutes per build. Cacheable via GHA layer cache (Task B), so subsequent builds skip it unless the git ref changes. Can switch to a prebuilt binary download if/when whisper.cpp publishes amd64 Linux binaries on a stable URL.

The `base.en` model download from HuggingFace is the third external dependency. URL is the same one `cli/commands/models.HF_BASE` uses (`https://huggingface.co/ggerganov/whisper.cpp/resolve/main`), so the baked file and a runtime `montaj install whisper --model base.en` produce byte-identical results. Sanity-checked at build time (>100MB size assertion). Note: the whisper.cpp source repo moved from `ggerganov` to `ggml-org` on GitHub (per the message in `cli/commands/install.py:113`), but the **HuggingFace model repo** is still under `ggerganov/whisper.cpp` — that's the canonical model location and is independent of the GitHub org rename.

---

## Task B — GitHub Actions release workflow

### Implementation

1. Create `.github/workflows/container-release.yml`:
   ```yaml
   name: container-release

   on:
     push:
       tags:
         - 'v*.*.*'
     workflow_dispatch:   # allow manual re-runs for a given tag
       inputs:
         tag:
           description: 'Tag to (re-)build'
           required: true
           type: string

   permissions:
     contents: read
     packages: write

   jobs:
     build-and-push:
       runs-on: ubuntu-latest
       steps:
         - name: Determine version + stable-vs-prerelease
           id: version
           run: |
             # Strip the leading 'v' from the tag — pyproject.toml uses bare X.Y.Z
             TAG="${{ github.event.inputs.tag || github.ref_name }}"
             VERSION="${TAG#v}"
             # Stable release = no prerelease suffix (no '-rc1', '-beta', etc.)
             if [[ "$TAG" == *-* ]]; then
               IS_STABLE=false
             else
               IS_STABLE=true
             fi
             echo "tag=$TAG"           >> "$GITHUB_OUTPUT"
             echo "version=$VERSION"   >> "$GITHUB_OUTPUT"
             echo "is_stable=$IS_STABLE" >> "$GITHUB_OUTPUT"
             echo "Tag $TAG → version $VERSION, stable=$IS_STABLE"

         - uses: actions/checkout@v4
           with:
             ref: ${{ steps.version.outputs.tag }}

         # Wait for PyPI's CDN to propagate the new version before the Docker
         # build tries to `pip install`. Otherwise we race with twine upload
         # and get "no matching distribution" failures on ~30-90s of every release.
         - name: Wait for montaj==${{ steps.version.outputs.version }} on PyPI
           run: |
             set -e
             for i in $(seq 1 20); do
               if pip download --no-deps --no-cache-dir -d /tmp/pip-check \
                    "montaj==${{ steps.version.outputs.version }}" >/dev/null 2>&1; then
                 echo "✓ available on PyPI (attempt $i)"
                 rm -rf /tmp/pip-check
                 exit 0
               fi
               echo "  attempt $i: not yet visible on PyPI, sleeping 15s"
               sleep 15
             done
             echo "✗ timed out after 5min waiting for montaj==${{ steps.version.outputs.version }}"
             exit 1

         - name: Set up Docker Buildx
           uses: docker/setup-buildx-action@v3

         - name: Log in to ghcr.io
           uses: docker/login-action@v3
           with:
             registry: ghcr.io
             username: ${{ github.actor }}
             password: ${{ secrets.GITHUB_TOKEN }}

         - name: Build image (load locally first for smoke test)
           uses: docker/build-push-action@v5
           with:
             context: .
             load: true                                 # load into local docker for smoke test
             tags: ghcr.io/thesampadilla/montaj:smoke
             build-args: |
               MONTAJ_VERSION=${{ steps.version.outputs.version }}
             cache-from: type=gha
             cache-to:   type=gha,mode=max

         - name: Smoke test
           run: ./tests/container/test_image_smoke.sh ghcr.io/thesampadilla/montaj:smoke

         - name: Push immutable :vX.Y.Z tag (always)
           uses: docker/build-push-action@v5
           with:
             context: .
             push: true
             tags: ghcr.io/thesampadilla/montaj:${{ steps.version.outputs.tag }}
             build-args: |
               MONTAJ_VERSION=${{ steps.version.outputs.version }}
             cache-from: type=gha
             cache-to:   type=gha,mode=max

         - name: Push :latest tag (stable releases only)
           if: steps.version.outputs.is_stable == 'true'
           uses: docker/build-push-action@v5
           with:
             context: .
             push: true
             tags: ghcr.io/thesampadilla/montaj:latest
             build-args: |
               MONTAJ_VERSION=${{ steps.version.outputs.version }}
             cache-from: type=gha
   ```

   Notes:
   - **PyPI propagation polling** — 20 attempts × 15s = 5 min timeout. Generous; first hit usually within 30-60s. Without this, every `~/release` cycle has a non-trivial chance of CI-flake on the first attempt with "no matching distribution."
   - **Stable-release detection** — `[[ "$TAG" == *-* ]]` is the simplest check. Pre-release tags follow PEP 440 / semver convention (`-rc1`, `-beta.1`, etc., always include a hyphen). Stable releases are bare `vX.Y.Z`. Edge case: a hypothetical `v2.1.3-2026.05` (date suffix without prerelease semantics) would also be detected as prerelease — acceptable since we don't use that pattern.
   - **Three `build-push-action` invocations** — load-for-smoke, push-pinned, push-latest-conditional. Layers are cached via GHA cache so the latter two are fast (no rebuild).
   - **`workflow_dispatch` with manual `tag` input** — lets us re-trigger a build if smoke reveals an issue and we need to rebuild after a fix, without cutting a new PyPI release.
   - **`packages: write` permission** is required for ghcr.io push. Repository-level "Allow GitHub Actions to create and approve packages" must also be enabled in Settings → Actions.
   - **No matrix for amd64/arm64.** amd64-only for V1.

2. Make `ghcr.io/thesampadilla/montaj` public after first push (in GitHub package settings) so consumers can pull without auth.

### Validation

- After this workflow lands, push a test prerelease tag (e.g., `v2.1.3-rc1`) and confirm:
  - The workflow runs end-to-end.
  - `docker pull ghcr.io/thesampadilla/montaj:v2.1.3-rc1` from a local machine succeeds.
  - `docker pull ghcr.io/thesampadilla/montaj:latest` does **NOT** return the prerelease image — `:latest` should still point to the previous stable build (or be absent if no stable release has happened yet). Verify the `:latest` push step was skipped in the workflow logs (`if: ... is_stable == 'true'` evaluated false).
- A subsequent push to a stable tag (e.g., `v2.1.4`) does push `:latest` to the new build.
- The PyPI propagation polling step succeeds — check workflow logs for `✓ available on PyPI (attempt N)`.
- The package appears at `https://github.com/users/theSamPadilla/packages/container/package/montaj`.

### Risk

Low–Medium. The actions used (`docker/setup-buildx-action`, `docker/login-action`, `docker/build-push-action`) are standard and well-maintained. The one thing to verify on first run: GitHub package permissions for the repo. If `packages: write` isn't permitted at the org/repo level, the push fails with a 403 — fix in repo Settings → Actions → General → Workflow permissions.

---

## Task C — Smoke test

### Implementation

1. Create `tests/container/test_image_smoke.sh`:
   ```bash
   #!/usr/bin/env bash
   # Smoke test: verify the built container image boots, serves the API,
   # and has all the baked-in deps in the right places.
   # Usage: tests/container/test_image_smoke.sh <image:tag>
   set -euo pipefail

   IMAGE="${1:?usage: $0 <image:tag>}"
   CONTAINER_NAME="montaj-smoke-$$"

   cleanup() {
     docker logs "$CONTAINER_NAME" 2>&1 | tail -50 || true
     docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
   }
   trap cleanup EXIT

   echo "→ starting container in headless mode"
   docker run -d --name "$CONTAINER_NAME" \
     -p 13000:3000 \
     "$IMAGE" \
     serve --headless --network

   echo "→ waiting for /api/info to respond (30s timeout)"
   for i in $(seq 1 30); do
     if curl -fsS http://localhost:13000/api/info >/dev/null 2>&1; then
       echo "✓ /api/info responded on attempt $i"
       break
     fi
     [ "$i" -eq 30 ] && { echo "✗ /api/info did not respond within 30s"; exit 1; }
     sleep 1
   done

   # Verify baked-in deps inside the running container
   echo "→ verifying baked deps"
   docker exec "$CONTAINER_NAME" sh -c '
     set -e
     ffmpeg -filters 2>/dev/null | grep -qw zscale       || { echo "✗ ffmpeg lacks zscale"; exit 1; }
     whisper-cli --help >/dev/null 2>&1                  || { echo "✗ whisper-cli broken"; exit 1; }
     # Canonical bake path — what lib/common.py:135 reads first and what
     # `montaj install whisper --model X` writes to.
     CANONICAL=/root/.local/share/montaj/models/whisper/ggml-base.en.bin
     test -f "$CANONICAL" \
       && [ "$(stat -c%s "$CANONICAL")" -gt 100000000 ] \
                                                          || { echo "✗ whisper base.en model missing or truncated at canonical path"; exit 1; }
     # Legacy-path symlink — required for cli/deps.py:check_deps() (the
     # `montaj serve` startup gate) to find the model.
     LEGACY=/root/.local/share/whisper.cpp/models/ggml-base.en.bin
     test -L "$LEGACY" && test "$(readlink -f "$LEGACY")" = "$CANONICAL" \
                                                          || { echo "✗ legacy whisper-path symlink missing or points elsewhere"; exit 1; }
     test -x /usr/bin/chromium                           || { echo "✗ chromium not at /usr/bin/chromium"; exit 1; }
     node --version | grep -q "^v20\."                   || { echo "✗ node not v20"; exit 1; }
     git --version >/dev/null 2>&1                       || { echo "✗ git missing (required by serve/server.py per-project versioning)"; exit 1; }
     python -c "import google.genai, openai, requests, jwt" 2>/dev/null \
                                                          || { echo "✗ [connectors] extras missing"; exit 1; }
     echo "✓ all baked deps present"
   '
   echo "✓ smoke test passed"
   ```

2. `chmod +x tests/container/test_image_smoke.sh`.

### Validation

- Locally: `docker build --build-arg MONTAJ_VERSION=2.1.3 -t montaj:test . && tests/container/test_image_smoke.sh montaj:test` exits 0.
- In CI: same script runs against the loaded image after Task B's first build step.

### Risk

Low. Bash + docker + curl. The 30s timeout is generous (image boot is typically <5s once loaded); bump if real CI environments need more.

---

## Task D — Documentation

### Implementation

1. Add a "Container deployment" section to `README.md`, near the existing install instructions:
   ```markdown
   ### Container

   Official image at `ghcr.io/thesampadilla/montaj`, published on every release tag.
   Use `:vX.Y.Z` for production (immutable, safe for prerelease versions too).
   `:latest` only ever points to a stable release (never a prerelease).

   **Standalone (single user, with UI):**
   ```sh
   docker run -p 3000:3000 \
     -v ~/Montaj:/root/Montaj \
     ghcr.io/thesampadilla/montaj:latest
   ```
   The default `CMD` is `montaj serve --network` — `--network` is required for
   the `-p 3000:3000` mapping to work (without it, Montaj binds 127.0.0.1
   inside the container and the port mapping is a no-op).

   **Headless (sidecar, no UI):**
   ```sh
   docker run --rm -p 3000:3000 \
     ghcr.io/thesampadilla/montaj:latest \
     serve --headless --network
   ```

   **Persistent whisper models** (only needed if you want models other than
   the bundled `base.en`). Mount the canonical Montaj-managed path — that's
   where both the baked-in model lives and where `montaj install whisper
   --model X` writes new ones, so a single mount captures both:
   ```sh
   docker run -p 3000:3000 \
     -v ~/Montaj:/root/Montaj \
     -v montaj-whisper:/root/.local/share/montaj/models/whisper \
     ghcr.io/thesampadilla/montaj:latest
   # Then in another shell:
   docker exec -it <container> montaj install whisper --model small.en
   ```

   See [docs.montaj.ag/deploy/container](https://docs.montaj.ag/deploy/container) for the full guide including env vars, volume mounts, and update procedure.
   ```

2. Create `../landing-montaj/docs/content/docs/deploy/container.mdx`:
   ```mdx
   # Container deployment

   ## Image location

   `ghcr.io/thesampadilla/montaj`

   - `:vX.Y.Z` — immutable, pinned to a specific release. **Recommended for production deployments.**
   - `:latest` — rolling pointer to the most recent release. Convenient for development; risky for production because it changes under you.

   ## Standalone usage

   ...

   ## Sidecar usage (headless)

   ...

   ## Environment variables

   ...

   ## Volume mounts

   ...

   ## Updating

   ...

   ## Image variants

   V1 ships a single image. Slimmer variants (no-UI, no-whisper) may follow if image size becomes a real complaint.

   ## Image internals

   For the curious — the image bundles ffmpeg (via Jellyfin's apt repo at `repo.jellyfin.org`, with zscale for HDR), Node 20 + Chromium for Puppeteer-based overlay rendering, whisper.cpp built from source, and Python 3.12 with all of Montaj's PyPI deps.
   ```
   Fill in the section bodies with what's relevant.

3. Update `CHANGELOG.md` under the next release entry:
   ```
   - **Added official Docker image** at `ghcr.io/thesampadilla/montaj`. Released alongside PyPI on every `vX.Y.Z` tag. Both pinned (`:vX.Y.Z`) and rolling (`:latest`) tags published. See `docs/container.mdx` for usage.
   ```

### Validation

- README's Container section renders correctly on GitHub.
- `landing-montaj/docs/content/docs/deploy/container.mdx` builds without errors and is reachable from the docs site nav.
- Both reference each other (README → docs site, docs site back to GitHub for the source).

### Risk

None. Doc edits.

---

## Task ordering

A → B → C → D, but with a coupling between A and C (Task C tests the image Task A produces) and between B and C (Task B's CI runs Task C).

If only part ships in a session: A + C is the minimum useful checkpoint (image builds locally and can be smoke-tested manually). B unlocks automation; D unlocks discoverability.

The headless plan ([`./2026-05-02-headless-serve.md`](./2026-05-02-headless-serve.md)) is technically not a dependency — Task A's Dockerfile defaults to `serve` (non-headless), which works for laptop use even without `--headless` support. But the sidecar consumers we're doing this work for need `--headless`. Practically: land headless first, then this.

---

## Verification Checklist

Run after Task D:

- [ ] `docker build --build-arg MONTAJ_VERSION=$(awk -F'"' '/^version/ {print $2; exit}' pyproject.toml) -t montaj:local .` builds clean from a fresh clone. Build fails loudly if the Jellyfin ffmpeg path is missing, the zscale filter is absent, or the whisper model download is truncated.
- [ ] Final image size is **under 3GB** (multi-stage strips ~400MB of build tools that would otherwise leak in).
- [ ] `tests/container/test_image_smoke.sh montaj:local` exits 0 — verifies API boot + ffmpeg/zscale + whisper-cli + base.en model present + chromium + node 20 + `[connectors]` extras importable.
- [ ] `docker run --rm montaj:local serve --headless --network` boots; `curl http://localhost:3000/api/info` returns 200.
- [ ] `docker run --rm -p 3000:3000 montaj:local` (default CMD, no override) is reachable from the host on `localhost:3000` — confirms `--network` is in the default CMD and binds 0.0.0.0.
- [ ] **Whisper bake-in at canonical path**: `docker run --rm montaj:local ls -lh /root/.local/share/montaj/models/whisper/ggml-base.en.bin` shows ~150MB file.
- [ ] **Legacy-path symlink resolves to canonical**: `docker run --rm montaj:local readlink -f /root/.local/share/whisper.cpp/models/ggml-base.en.bin` prints the canonical path. (Required for `cli/deps.py:check_deps()` to pass on `montaj serve` startup.)
- [ ] **Path consistency end-to-end**: `docker run --rm montaj:local montaj install whisper --model base.en` is a no-op (logs "already downloaded") — confirms the baked file is at the path Montaj's own downloader checks, with the same URL/bytes.
- [ ] **`[connectors]` extras present**: `docker run --rm montaj:local python -c "import google.genai, openai, requests, jwt"` exits 0.
- [ ] **`[rvm]` and `[demucs]` are NOT present** (intentional): `docker run --rm montaj:local python -c "import torch"` exits 1 with `ModuleNotFoundError`.
- [ ] **PyPI propagation polling works in CI**: workflow logs include `✓ available on PyPI (attempt N)` line.
- [ ] **Prerelease tag does NOT push `:latest`**: push `v2.1.3-rc1`, verify `:latest` still points to the previous stable build (or is absent), and the workflow's `:latest` push step shows as skipped.
- [ ] **Stable tag DOES push `:latest`**: push `v2.1.4`, verify `:latest` updates to the new build.
- [ ] `docker pull ghcr.io/thesampadilla/montaj:v2.1.3-rc1` from a clean machine succeeds (**requires one-time setup**: after the very first push, flip the package to public in GitHub package settings — see Task B step 2. This is a manual, one-time action and cannot be checked off automatically; subsequent pushes inherit the visibility.).
- [ ] README's Container section is present, includes both invocations (standalone + sidecar), explains `--network` requirement, mentions persistent whisper-models volume.
- [ ] `landing-montaj/docs/content/docs/deploy/container.mdx` exists and is reachable from the docs site (verify nav-config requirement).
- [ ] CHANGELOG mentions the container image addition.
- [ ] No breaking changes to PyPI distribution — `pip install montaj==<same-version>` still works for non-container users.
