# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from typing import Any

from aiperf.common.models import (
    BaseResponseData,
    InferenceServerResponse,
    ParsedResponse,
    ReasoningResponseData,
    RequestInfo,
    ToolCallResponseData,
    Turn,
)
from aiperf.common.types import JsonObject
from aiperf.endpoints.base_endpoint import BaseEndpoint

_DEFAULT_ROLE: str = "user"


class ChatEndpoint(BaseEndpoint):
    """OpenAI Chat Completions endpoint.

    Supports multi-modal inputs (text, images, audio, video) and both
    streaming and non-streaming responses.
    """

    def format_payload(self, request_info: RequestInfo) -> dict[str, Any]:
        """Format OpenAI Chat Completions request payload from RequestInfo.

        Args:
            request_info: Request context including model endpoint, metadata, and turns

        Returns:
            OpenAI Chat Completions API payload
        """
        if not request_info.turns:
            raise ValueError("Chat endpoint requires at least one turn.")

        turns = request_info.turns
        model_endpoint = request_info.model_endpoint

        if turns[-1].raw_messages is not None:
            messages = turns[-1].raw_messages
        else:
            messages = self._create_messages(
                turns, request_info.system_message, request_info.user_context_message
            )

        payload = {
            "messages": messages,
            "model": turns[-1].model or model_endpoint.primary_model_name,
            "stream": model_endpoint.endpoint.streaming,
        }

        if turns[-1].raw_tools is not None:
            payload["tools"] = turns[-1].raw_tools

        if turns[-1].max_tokens is not None:
            token_field = (
                "max_tokens"
                if model_endpoint.endpoint.use_legacy_max_tokens
                else "max_completion_tokens"
            )
            payload[token_field] = turns[-1].max_tokens

        if model_endpoint.endpoint.extra:
            payload.update(model_endpoint.endpoint.extra)

        if (
            model_endpoint.endpoint.streaming
            and model_endpoint.endpoint.use_server_token_count
        ):
            # Automatically set stream_options to include usage when using server token counts
            if "stream_options" not in payload:
                payload["stream_options"] = {"include_usage": True}
            elif (
                isinstance(payload["stream_options"], dict)
                and "include_usage" not in payload["stream_options"]
            ):
                payload["stream_options"]["include_usage"] = True

        self.trace(lambda: f"Formatted payload: {payload}")
        return payload

    def _create_messages(
        self,
        turns: list[Turn],
        system_message: str | None,
        user_context_message: str | None,
    ) -> list[dict[str, Any]]:
        """Create messages from turns for OpenAI Chat Completions.

        Args:
            turns: List of turns in the request
            system_message: Optional shared system message to prepend
            user_context_message: Optional per-conversation user context to prepend

        Returns:
            List of formatted message dicts for OpenAI Chat Completions API
        """
        messages = []

        # Prepend system_message and user_context_message if present
        if system_message:
            messages.append(
                {
                    "role": "system",
                    "content": system_message,
                }
            )

        if user_context_message:
            messages.append(
                {
                    "role": "user",
                    "content": user_context_message,
                }
            )

        for turn in turns:
            message = {
                "role": turn.role or _DEFAULT_ROLE,
            }
            self._set_message_content(message, turn)
            messages.append(message)
        return messages

    def _set_message_content(self, message: dict[str, Any], turn: Turn) -> None:
        """Create message content from turn for OpenAI Chat Completions."""
        if (
            len(turn.texts) == 1
            and len(turn.texts[0].contents) == 1
            and len(turn.images) == 0
            and len(turn.audios) == 0
            and len(turn.videos) == 0
        ):
            # Hotfix for Dynamo API which does not yet support a list of messages
            message["content"] = (
                turn.texts[0].contents[0] if turn.texts[0].contents else ""
            )
            return

        message_content: list[dict[str, Any]] = []

        for text in turn.texts:
            for content in text.contents:
                if not content:
                    continue
                message_content.append({"type": "text", "text": content})

        for image in turn.images:
            for content in image.contents:
                if not content:
                    continue
                message_content.append(
                    {"type": "image_url", "image_url": {"url": content}}
                )

        for audio in turn.audios:
            for content in audio.contents:
                if not content:
                    continue
                if "," not in content:
                    raise ValueError(
                        "Audio content must be in the format 'format,b64_audio'."
                    )
                format, b64_audio = content.split(",", 1)
                message_content.append(
                    {
                        "type": "input_audio",
                        "input_audio": {
                            "data": b64_audio,
                            "format": format,
                        },
                    }
                )
        for video in turn.videos:
            for content in video.contents:
                if not content:
                    continue
                message_content.append(
                    {"type": "video_url", "video_url": {"url": content}}
                )

        message["content"] = message_content

    def parse_response(
        self, response: InferenceServerResponse
    ) -> ParsedResponse | None:
        """Parse OpenAI Chat Completions response.

        Args:
            response: Raw response from inference server

        Returns:
            Parsed response with extracted text/reasoning content and usage data
        """
        json_obj = response.get_json()
        if not json_obj:
            return None

        data = self.extract_chat_response_data(json_obj)
        usage = json_obj.get("usage") or None

        if data or usage:
            return ParsedResponse(perf_ns=response.perf_ns, data=data, usage=usage)

        return None

    def extract_chat_response_data(
        self, json_obj: JsonObject
    ) -> BaseResponseData | None:
        """Extract content from OpenAI JSON response.

        Handles both streaming (chat.completion.chunk) and non-streaming
        (chat.completion) formats using pattern matching.

        Args:
            json_obj: Deserialized OpenAI response

        Returns:
            Extracted response data or None if no content
        """
        match json_obj.get("object"):
            case "chat.completion":
                data_key = "message"
            case "chat.completion.chunk":
                data_key = "delta"
            case _:
                object_type = json_obj.get("object")
                raise ValueError(f"Unsupported OpenAI object type: {object_type!r}")

        choices = json_obj.get("choices")
        if not choices:
            self.debug(lambda: f"No choices found in response: {json_obj}")
            return None

        data = choices[0].get(data_key)
        if not data:
            self.debug(lambda: f"No data found in response: {json_obj}")
            return None

        content = data.get("content")
        reasoning = data.get("reasoning_content") or data.get("reasoning")

        if reasoning:
            return ReasoningResponseData(content=content, reasoning=reasoning)

        if content:
            return self.make_text_response_data(content)

        tool_calls = data.get("tool_calls") or []
        tool_call_parts: list[str] = []
        for tc in tool_calls:
            func = tc.get("function", {})
            name = func.get("name", "")
            arguments = func.get("arguments", "")
            if name:
                tool_call_parts.append(name)
            if arguments:
                tool_call_parts.append(arguments)
        tool_call_text = "".join(tool_call_parts)
        if tool_call_text:
            return ToolCallResponseData(text=tool_call_text)

        return None
