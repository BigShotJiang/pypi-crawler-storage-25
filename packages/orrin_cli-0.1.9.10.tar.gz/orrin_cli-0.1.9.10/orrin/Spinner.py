import itertools
import sys
import threading
import time

class Spinner:
    def __init__(self, message="Loading"):
        self.message = message
        self.spinner = itertools.cycle([
            "◜", "◠", "◝", "◞", "◡", "◟"
        ])

        self.running = False
        self.thread = None

    def animate(self):
        while self.running:
            sys.stdout.write(
                f"\r{next(self.spinner)} {self.message}"
            )
            sys.stdout.flush()
            time.sleep(0.1)

    def start(self, message=None):
        if message:
            self.message = message

        self.running = True
        self.thread = threading.Thread(target=self.animate)
        self.thread.daemon = True
        self.thread.start()

    def update(self, message):
        self.message = message

    def stop(self, message=None):
        self.running = False

        if self.thread:
            self.thread.join()

        # Clear line
        sys.stdout.write("\r" + " " * 100 + "\r")
        sys.stdout.flush()

        if message:
            print(message)

    def prompt(self, text="Press enter to continue"):
        self.stop()

        response = input(f"{text}: ")

        return response

    def wait_for_key(
        self,
        message="Press ENTER to continue",
        done_message="Done"
    ):
        self.start(message)

        input()

        self.stop(f"✓ {done_message}")