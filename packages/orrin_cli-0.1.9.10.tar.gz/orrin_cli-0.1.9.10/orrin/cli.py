import webbrowser
from click import Choice
import typer
import requests
import json
import os
from pathlib import Path
from platformdirs import user_config_dir
import yaml, tomli, toml
from pathlib import Path
from orrin.Spinner import Spinner

app = typer.Typer(help="""
Welcome to Orrin CLI v0.1.9!\n\n
                  
Orrin CLI enables you to perform actions within your terminal that would otherwise require
an entire dashboard. Though there is a dashboard, Orrin CLI enables a feasible development
experience for all developers, as they can swiftly run a command to upload their frontend,
perform checks on their app review status, and more!
""", no_args_is_help=True)

config = typer.Typer(help="Configure your Orrin Apps developer API with Orrin CLI")
app.add_typer(config, name='config')

ui = typer.Typer(help="UI related commands")
app.add_typer(ui, name="ui")

projects = typer.Typer(help='OrrinSDK project commands')
app.add_typer(projects, name='projects')

API_BASE = "https://stellr-company.com"

APP_NAME = "orrin"
APP_AUTHOR = "orrin"  # optional but recommended on Windows

config_dir = Path(user_config_dir(APP_NAME, APP_AUTHOR))
config_dir.mkdir(parents=True, exist_ok=True)

config_file = config_dir / "config.json"

# ---- Configuration based commands/helper functions ----

def save_config_data(api_key: str, email: str):
    data = {"api_key": api_key, 'email': email}
    with open(config_file, "w") as f:
        json.dump(data, f)
        f.close()

def write_config(config: dict):
    with open(config_file, 'w') as f:
        json.dump(config, f)
        f.close()

def load_config():
    if not config_file.exists():
        return None
    with open(config_file) as f:
        return json.load(f)#json.load(f).get("api_key")

@config.command(help="""
Add your Developer API key and email to the Orrin CLI to perform tasks explicitly relating to your developer account.
Your email will be added to your developer account details, and correspondence regarding your submission
will take place via the dashboard and email, if the email is valid.
""")
def configure_dev():
    dev_email = typer.prompt(
        'Enter your email',
        hide_input=False,
        confirmation_prompt=True
    )

    dev_api = typer.prompt(
        "Enter your Developer API key",
        hide_input=True,
        confirmation_prompt=True,
    )
    
    resp = requests.post(
        f'{API_BASE}/api/orrin_apps/developer_api_exists',
        json={'developer_api_key': dev_api}
    )
    
    if not resp.ok:
        typer.echo(f'❌ No developer account was found with API key:\n\n{dev_api}')
        raise typer.Exit(1)
    
    # Add email to developer account
    resp = requests.post(
        f'{API_BASE}/api/orrin_apps/add_email_to_developer_account',
        json={'email': dev_email, 'developer_id': dev_api}
    )

    if not resp.ok:
        typer.echo(f'❌ Something went wrong adding email to developer account. Try again.\n\nIf the problem persists, contact us:\n\thttps://stellr-company.com/contact')
        raise typer.Exit(1)
    
    save_config_data(api_key=dev_api, email=dev_email)
    typer.echo("✅ Developer API and email configured with Orrin CLI")

@config.command(help='Revokes the Developer API currently configured with Orrin CLI')
def revoke_config():
    if not config_file.exists():
        typer.echo("ℹ️ No configuration found to revoke.")
        raise typer.Exit(code=0)

    try:
        config_file.unlink()
        typer.echo("✅ Credentials revoked. Local config removed.")
    except Exception as e:
        typer.echo(f"❌ Failed to revoke credentials: {e}")
        raise typer.Exit(code=1)

@config.command(help='Show configured Developer API key')
def show_configuration():
    if not config_file.exists():
        typer.echo("ℹ️ No Developer API key configured with Orrin CLI")
        raise typer.Exit(code=0)
    
    config = load_config()

    typer.echo(f'\n\tConfigured Developer API key:\n\t\t{config["api_key"]}\n\n\tConfigured Developer Email:\n\t\t{config["email"]}\n')

@config.command(help='Create a new OAuth Configuration')
def create_oauth_config():
    config = load_config()

    if not 'api_key' in config or config is None:
        typer.echo('\nYou have not configured a developer API. Please run:')
        typer.echo('\t' + typer.style('  orrin config configure-dev  ', fg=typer.colors.YELLOW) + '\n')
        return
    
    webbrowser.open(f'{API_BASE}/developer/create-oauth-config/{config["api_key"]}')
    done = input('Press enter when done...')
    spinner = Spinner('Obtaining information over created config...')
    
    spinner.start()

    resp = requests.get(
        f'{API_BASE}/api/temp_oauth_config',
        headers={ 'developer-api': config['api_key'] }
    )

    spinner.stop()

    if not resp.ok:
        typer.echo('\n' + typer.style('Something went wrong obtaining your temporary configurations..', fg=typer.colors.RED) + '\n')
        return
    else:
        entries = resp.json()['TempOAuthConfigs']

        entry_count = len(entries)

        typer.echo(
            f"\nFound {typer.style(str(entry_count), fg=typer.colors.CYAN)} OAuth configuration entr{'y' if entry_count == 1 else 'ies'}.\n"
        )

        for index, entry in enumerate(entries, start=1):
            typer.echo(
                typer.style(
                    f"Entry {index}/{entry_count}",
                    fg=typer.colors.BLUE,
                    bold=True
                )
            )

            typer.echo(
                typer.style("─" * 50, fg=typer.colors.BRIGHT_BLACK)
            )

            typer.echo(
                f"{typer.style('OAuth Name:', fg=typer.colors.CYAN)} {entry.get('OAuthName', '')}"
            )

            typer.echo(
                f"{typer.style('App Name:', fg=typer.colors.CYAN)} {entry.get('app_name', '')}"
            )

            typer.echo(
                f"{typer.style('Organization:', fg=typer.colors.CYAN)} {entry.get('organization_name', '')}"
            )

            typer.echo(
                f"{typer.style('App URL:', fg=typer.colors.CYAN)} {entry.get('app_url', '')}"
            )

            typer.echo(
                f"{typer.style('Handle Auth:', fg=typer.colors.CYAN)} {entry.get('handle_auth', '')}"
            )

            typer.echo(
                f"{typer.style('Reason:', fg=typer.colors.CYAN)} {entry.get('OAuthReason', '')}"
            )

            typer.echo(
                f"{typer.style('Video:', fg=typer.colors.CYAN)} {entry.get('app_video', '') or 'None'}"
            )

            typer.echo(
                f"{typer.style('Intents:', fg=typer.colors.CYAN)}"
            )

            intents = entry.get('intents', [])

            if intents:
                for intent in intents:
                    typer.echo(f"  • {intent}")
            else:
                typer.echo("  None")

            typer.echo()

            confirm = typer.confirm(
                "Finalize this OAuth configuration?",
                default=True
            )

            if confirm:
                spinner = Spinner('Finalizing OAuth configuration...')

                spinner.start()

                create_resp = requests.post(
                    f'{API_BASE}/api/orrin_apps/create_oauth_config',
                    headers={
                        'authorization': config['api_key']
                    },
                    json=entry
                )

                spinner.stop()

                if create_resp.ok:
                    spinner.start('Removing from temporary storage...')
                    resp = requests.post(
                        f'{API_BASE}/api/remove_temp_oauth_config',
                        headers={ 'developer-api': config['api_key'] },
                        json={ 'OAuthName': entry.get('OAuthName', '') }
                    )
                    spinner.stop()

                    if not resp.ok:
                        typer.echo(
                            '\n' + typer.style(
                                f'Failed to remove {entry.get("OAuthName", "")} from temporary storage.',
                                fg=typer.colors.RED
                            )
                        )

                    typer.echo(
                        '\n' + typer.style(
                            'OAuth configuration finalized successfully.',
                            fg=typer.colors.GREEN
                        ) + '\n'
                    )
                else:
                    try:
                        create_resp = create_resp.json()

                        if create_resp['Message'] == 'oauth_exists':
                            typer.echo(
                                '\n' + typer.style(
                                    f'OAuth "{entry.get("OAuthName", "")}" already exists..',
                                    fg=typer.colors.RED
                                ) + '\n'
                            )

                            spinner.start('Removing from temporary storage...')
                            resp = requests.post(
                                f'{API_BASE}/api/remove_temp_oauth_config',
                                headers={ 'developer-api': config['api_key'] },
                                json={ 'OAuthName': entry.get('OAuthName', '') }
                            )
                            spinner.stop()

                            if not resp.ok:
                                typer.echo(
                                    typer.style(
                                        f'Failed to remove {entry.get("OAuthName", "")} from temporary storage.',
                                        fg=typer.colors.RED
                                    ) + '\n'
                                )
                            else:
                                typer.echo(
                                    typer.style(
                                        f'Removed temporary OAuth Config: "{entry.get("OAuthName", "")}"',
                                        fg=typer.colors.RED
                                    ) + '\n'
                                )
                    except:
                        typer.echo(
                            '\n' + typer.style(
                                'Failed to finalize OAuth configuration.',
                                fg=typer.colors.RED
                            ) + '\n'
                        )

                return

            typer.echo()

        typer.echo(
            typer.style(
                'No OAuth configuration was finalized.',
                fg=typer.colors.YELLOW
            )
        )

@config.command(help='''
Create a new OAuth Configuration\n\n
coac - shorthand for create-oauth-config
''')
def coac():
    create_oauth_config()

@config.command(help='Obtain all temporary OAuth Configurations to be displayed/finalized')
def display_temp_oauth_configurations():
    config = load_config()

    if not 'api_key' in config or config is None:
        typer.echo('\nYou have not configured a developer API. Please run:')
        typer.echo('\t' + typer.style('  orrin config configure-dev  ', fg=typer.colors.YELLOW) + '\n')
        return
    
    spinner = Spinner('Obtaining information over created config...')
    
    spinner.start()

    resp = requests.get(
        f'{API_BASE}/api/temp_oauth_config',
        headers={ 'developer-api': config['api_key'] }
    )

    spinner.stop()

    if not resp.ok:
        try:
            resp = resp.json()
            
            if resp['Message'] == 'no_temp_configs':
                typer.echo('\n' + typer.style('You have no temporary configurations.', fg=typer.colors.GREEN) + '\n')
            else:
                typer.echo('\n' + typer.style('Something went wrong obtaining your temporary configurations..', fg=typer.colors.RED) + '\n')
        except:
            typer.echo('\n' + typer.style('Something went wrong obtaining your temporary configurations..', fg=typer.colors.RED) + '\n')
        return
    else:
        entries = resp.json()['TempOAuthConfigs']

        entry_count = len(entries)

        typer.echo(
            f"\nFound {typer.style(str(entry_count), fg=typer.colors.CYAN)} OAuth configuration entr{'y' if entry_count == 1 else 'ies'}.\n"
        )

        for index, entry in enumerate(entries, start=1):
            typer.echo(
                typer.style(
                    f"Entry {index}/{entry_count}",
                    fg=typer.colors.BLUE,
                    bold=True
                )
            )

            typer.echo(
                typer.style("─" * 50, fg=typer.colors.BRIGHT_BLACK)
            )

            typer.echo(
                f"{typer.style('OAuth Name:', fg=typer.colors.CYAN)} {entry.get('OAuthName', '')}"
            )

            typer.echo(
                f"{typer.style('App Name:', fg=typer.colors.CYAN)} {entry.get('app_name', '')}"
            )

            typer.echo(
                f"{typer.style('Organization:', fg=typer.colors.CYAN)} {entry.get('organization_name', '')}"
            )

            typer.echo(
                f"{typer.style('App URL:', fg=typer.colors.CYAN)} {entry.get('app_url', '')}"
            )

            typer.echo(
                f"{typer.style('Handle Auth:', fg=typer.colors.CYAN)} {entry.get('handle_auth', '')}"
            )

            typer.echo(
                f"{typer.style('Reason:', fg=typer.colors.CYAN)} {entry.get('OAuthReason', '')}"
            )

            typer.echo(
                f"{typer.style('Video:', fg=typer.colors.CYAN)} {entry.get('app_video', '') or 'None'}"
            )

            typer.echo(
                f"{typer.style('Intents:', fg=typer.colors.CYAN)}"
            )

            intents = entry.get('intents', [])

            if intents:
                for intent in intents:
                    typer.echo(f"  • {intent}")
            else:
                typer.echo("  None")

            typer.echo()

            confirm = typer.confirm(
                "Finalize this OAuth configuration?",
                default=True
            )

            if confirm:
                spinner.start('Finalizing OAuth configuration...')

                create_resp = requests.post(
                    f'{API_BASE}/api/orrin_apps/create_oauth_config',
                    headers={
                        'authorization': config['api_key']
                    },
                    json=entry
                )

                spinner.stop()

                if create_resp.ok:
                    spinner.start('Removing from temporary storage...')
                    resp = requests.post(
                        f'{API_BASE}/api/remove_temp_oauth_config',
                        headers={ 'developer-api': config['api_key'] },
                        json={ 'OAuthName': entry.get('OAuthName', '') }
                    )
                    spinner.stop()

                    if not resp.ok:
                        typer.echo(
                            '\n' + typer.style(
                                f'Failed to remove {entry.get("OAuthName", "")} from temporary storage.',
                                fg=typer.colors.RED
                            )
                        )
                        
                    typer.echo(
                        '\n' + typer.style(
                            'OAuth configuration finalized successfully.',
                            fg=typer.colors.GREEN
                        ) + '\n'
                    )
                else:
                    try:
                        create_resp = create_resp.json()

                        if create_resp['Message'] == 'oauth_exists':
                            typer.echo(
                                '\n' + typer.style(
                                    f'OAuth "{entry.get("OAuthName", "")}" already exists..',
                                    fg=typer.colors.RED
                                ) + '\n'
                            )

                            spinner.start('Removing from temporary storage...')
                            resp = requests.post(
                                f'{API_BASE}/api/remove_temp_oauth_config',
                                headers={ 'developer-api': config['api_key'] },
                                json={ 'OAuthName': entry.get('OAuthName', '') }
                            )
                            spinner.stop()

                            if not resp.ok:
                                typer.echo(
                                    '\n' + typer.style(
                                        f'Failed to remove {entry.get("OAuthName", "")} from temporary storage.',
                                        fg=typer.colors.RED
                                    ) + '\n'
                                )
                            else:
                                typer.echo(
                                    typer.style(
                                        f'Removed temporary OAuth Config: "{entry.get("OAuthName", "")}"',
                                        fg=typer.colors.RED
                                    ) + '\n'
                                )
                    except:
                        typer.echo(
                            '\n' + typer.style(
                                'Failed to finalize OAuth configuration.',
                                fg=typer.colors.RED
                            ) + '\n'
                        )
            else:
                typer.echo(
                    '\n' + typer.style(
                        f'Skipped {entry.get("OAuthName", "")}',
                        fg=typer.colors.RED
                    ) + '\n'
                )

            typer.echo()

@config.command(help='''
Obtain all temporary OAuth Configurations to be displayed/finalized\n\n
dtoc - shorthand for display-temp-oauth-configurations
''')
def dtoc():
    display_temp_oauth_configurations()

# -------------------------------------------------------

# ---- UI based commands/helper functions ----

@ui.command(help='''Build static output for next.js code, and generate a zip file to be uploaded.\n\nEnsure you have the following in next.config.tsx:\n\n
------------------------------------------------------\n\n
/** @type {import('next').NextConfig} */\n\n
const nextConfig = {\n\n
  output: 'export',\n\n
  trailingSlash: true,\n\n
  basePath: '/<your_app_name>/current',\n\n
  reactStrictMode: true,\n\n
};\n\n
\n\n
module.exports = nextConfig;
------------------------------------------------------\n\n
\n\n
Where <your_app_name> is the name of your app, which was configured in your backend.
''')
def generate_zip():
    os.system('npm install && npm run build')
    os.system('cd out && zip -r ../ui-build.zip .')

@ui.command(help="Upload your frontend code to be reviewed")
def upload(
    #zip_path: Path = typer.Argument(..., exists=True),
    app_name: str = typer.Option(..., "--app")
):
    """
    Upload a UI zip to Orrin.
    """
    if not os.path.isfile(os.path.join(os.getcwd(), 'ui-build.zip')):
        typer.echo(f"❌ Path {os.path.join(os.getcwd(), 'ui-build.zip')} does not exist.\n\nEnsure you run `orrin ui generate-zip`, or build the zip yourself.")
        raise typer.Exit(1)
    
    dev_api = load_config()['api_key']

    if dev_api is None:
        typer.echo("❌ You have not configured an API key. Please register with `orrin configure configure-dev-api`.")
        raise typer.Exit(1)
    
    with open(os.path.join(os.getcwd(), 'ui-build.zip'), "rb") as f:
        response = requests.post(
            f"{API_BASE}/ui/upload",
            files={"file": f},
            data={
                "developer_id": dev_api,
                "app_name": app_name
            }
        )

    if response.status_code != 200:
        try:
            data = response.json()
            typer.echo(f'❌ Upload failed: {response.status_code}\n\nMessage: {data["Message"]}')
        except:
            typer.echo("❌ Upload failed")
        raise typer.Exit(1)

    data = response.json()
    typer.echo("✅ Uploaded")
    typer.echo(f"Upload ID: {data.get('upload_id')}")

# --------------------------------------------

# ---- For SDK based projects ----

@projects.command(help='Create a project for an app backend with OrrinAppsSDK')
def init_app_backend_project():
    project_name = typer.prompt(
        "Project Name",
        hide_input=False,
        confirmation_prompt=True,
    )

    project_desc = typer.prompt(
        'Project Description',
        hide_input=False
    )

    project_toml = {
        'general': {
            'project_type': 'app',
            'name': project_name,
            'desc': project_desc
        },
        'public': {
            'display_name': project_name,
            'display_desc': project_desc,
            'whats_new': '<describe_version>',
            'authors': [],
            'open_source': False,
            'copyright': '<your_copyright>',
            'dependencies': [
                {}
            ]
        }
    }

    path = os.path.join(os.getcwd(), project_name)
    os.mkdir(path)

    config = load_config()

    source_code = f'''
from orrinsdk import OrrinAppsSDK

orrin_sdk = OrrinAppsSDK(
    developer_api='{config["api_key"]}'
)

@orrin_sdk.action(
    'ExampleBackendAction',
    required_payload=[{{'name': 'a', 'type': 'any'}}]
)
def ExampleBackendAction(a):
    # Do something here
    return {{ 'status': 200, ... }}

orrin_sdk.finalize()
'''
    
    with open(os.path.join(path, 'project.toml'), 'w') as file:
        file.write(toml.dumps(project_toml))

    with open(os.path.join(path, 'main.py'), 'w') as file:
        file.write(source_code)

@projects.command(help='init-app-backend-project')
def iabp():
    init_app_backend_project()

@projects.command(help='Create a project for creating a tool with OrrinToolsSDK')
def init_tool_project():
    project_name = typer.prompt(
        "Project Name",
        hide_input=False,
        confirmation_prompt=True,
    )

    typer.echo(f'\n\t[orrin-cli] Version for {project_name} will default to 1.0.0\n')

    project_desc = typer.prompt(
        'Project Description',
        hide_input=False
    )

    has_plugins = typer.confirm(
        'Support Plugins?'
    )

    project_toml = {
        'general': {
            'project_type': 'tool',
            'name': project_name,
            'desc': project_desc,
            'nuances': {},
            'icons': {
                '24x24': '<path>',
                '32x32': '<path>',
                '48x48': '<path>',
                '64x64': '<path>'
            },
        },
        'plugins': {
            'supported': False
        },
        'metadata': {},
        'public': {
            'display_name': project_name,
            'display_desc': project_desc,
            'usage_rundown': '<rundown_of_tool_usage>',
            'whats_new': '<explain_version>',
            'authors': [],
            'open_source': False,
            'copyright': '<your_copyright>'
        }
    }
    
    # Create project
    path = os.path.join(os.getcwd(), project_name)
    os.mkdir(path)

    config = load_config()

    plugin_entries = []

    if has_plugins:
        project_toml['plugins']['supported'] = True
        project_toml['plugins']['config'] = 'plugins.yaml'
        
        number_of_plugins = int(typer.prompt(
            'How Many Plugins?',
            hide_input=False
        ))

        plugins = []

        for i in range(number_of_plugins):
            plugin_for = typer.prompt(
                f'Plugin {i} For',
                hide_input=False
            )

            plugin_type = typer.prompt(
                f'Plugin {i} Type',
                hide_input=False,
                type=Choice(["internal", "external"], case_sensitive=False)
            )

            plugin_name = typer.prompt(
                f'Plugin {i} Name',
                hide_input=False
            )

            plugin_display_name = typer.prompt(
                f'Plugin {i} Display Name',
                hide_input=False
            )

            plugins.append({
                'for': plugin_for,
                'type': plugin_type,
                'name': plugin_name,
                'display_name': plugin_display_name,
                'actions': [
                    {
                        'action': '',
                        'helper': '',
                        'type': ''
                    }
                ]
            })

            if plugin_for == 'blink':
                plugin_entries.append('''
@orrin_sdk.plugin_entry(
    plugin='blink'
)
def blink_plugin_entry(cc: any, all_context: any):
    if not isinstance(cc, dict):
        return {'status': 400, 'message': 'invalid_type'}
        
    if not isinstance(all_context, str):
        return {'status': 400, 'message': 'invalid_type'}

    # Handoff to Exegesis or process contextual data yourself
    pass
''')
            else:
                plugin_entries.append(f'''
@orrin_sdk.plugin_entry(
    plugin='{plugin_for}'
)
def custom_plugin_entry(cc: any, all_context: any):
    if not isinstance(cc, dict):
        return {{'status': 400, 'message': 'invalid_type'}}
        
    if not isinstance(all_context, str):
        return {{'status': 400, 'message': 'invalid_type'}}

    # Handoff to Exegesis or process contextual data yourself
    pass
''')
        
        with open(os.path.join(path, 'plugins.yaml'), 'w') as file:
            yaml.safe_dump({'plugins': plugins}, file)
            file.close()
    
    plugin_entries.append('') # filler to trigger another newline

    source_code = f'''
from orrinsdk import OrrinToolsSDK

orrin_sdk = OrrinToolsSDK(
    developer_api_key='{config["api_key"]}'
)''' + "\n".join(plugin_entries) + '''
@orrin_sdk.action(
    name='ExampleAction',
    payload_schema='',
    desc=''
)
def ExampleAction(data: any):
    if not isinstance(data, dict):
        return { 'status': 400, 'message': 'invalid_data' }
    
    # Process data. Perform some sort of action
        
    return { 'status': 200 }

orrin_sdk.finalize()
'''
    
    with open(os.path.join(path, 'project.toml'), 'w') as file:
        file.write(toml.dumps(project_toml))

    with open(os.path.join(path, 'main.py'), 'w') as file:
        file.write(source_code)

@projects.command(help='init-tool-project')
def itp():
    init_tool_project()

# --------------------------------

def main():
    app()

if __name__ == "__main__":
    main()
