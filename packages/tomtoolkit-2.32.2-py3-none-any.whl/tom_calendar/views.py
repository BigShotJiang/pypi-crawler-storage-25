from tom_targets.models import TargetList
import calendar as cal_module
import math
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from astropy.coordinates import get_body, get_sun
from astropy.time import Time
from django import forms
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django_htmx.http import trigger_client_event

from .models import CalendarEvent, EventTodo

DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
MOON_EMOJIS = ["🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"]
DATETIME_INPUT = forms.DateTimeInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M')


@dataclass
class MoonPhase:
    illumination: float
    emoji: str

    @classmethod
    def from_date(cls, date: date) -> "MoonPhase":
        d = datetime.combine(date, time(12, 0))
        t = Time(d)
        moon = get_body("moon", t)
        sun = get_sun(t)
        moon_lon = moon.geocentricmeanecliptic.lon
        sun_lon = sun.geocentricmeanecliptic.lon
        phase_angle = (moon_lon - sun_lon).wrap_at('360d').deg

        # Illumination fraction from elongation
        # 0 (new) -> 0.0, 90 (quarter) -> 0.5, 180 (full) -> 1.0
        illumination = (1 - math.cos(math.radians(phase_angle))) / 2

        # 8 45deg slices map to the phase emoji
        emoji = MOON_EMOJIS[int(phase_angle / 45) % 8]

        return cls(illumination, emoji)


def render_calendar(request, month: int | None = None):
    utc_offset = int(request.GET.get("utc_offset", 0))
    offset = timedelta(hours=utc_offset)
    now = timezone.now()
    now_offset = now + offset
    today = now_offset.date()
    if month is None:
        month = int(request.GET.get("month", now_offset.month))
    month = max(1, min(12, month))
    year = int(request.GET.get("year", now_offset.year))

    # Sunday is 6 in python calendar for some reason
    calendar = cal_module.Calendar(firstweekday=6)

    if month == 1:
        prev_month, prev_year = 12, year - 1
    else:
        prev_month, prev_year = month - 1, year

    if month == 12:
        next_month, next_year = 1, year + 1
    else:
        next_month, next_year = month + 1, year

    month_name = date(year, month, 1).strftime("%B %Y")
    weeks = calendar.monthdatescalendar(year, month)

    # Fetch all events for this month instead of querying for each day
    events = CalendarEvent.objects.filter(
        start_time__date__lte=weeks[-1][-1],
        end_time__date__gte=weeks[0][0],
    )

    def offset_date(dt):
        return (dt + offset).date()

    events = list(events)
    weeks_with_events = [
        [
            {
                "date": d,
                "moon": MoonPhase.from_date(d),
                "all_day_events": [
                    e for e in events
                    if offset_date(e.start_time) <= d <= offset_date(e.end_time)
                    and offset_date(e.start_time) != offset_date(e.end_time)
                ],
                "events": [
                    e for e in events
                    if offset_date(e.start_time) == offset_date(e.end_time) == d
                ],
            }
            for d in week
        ]
        for week in weeks
    ]

    context = {
        "month": month,
        "year": year,
        "month_name": month_name,
        "weeks": weeks_with_events,
        "day_names": DAY_NAMES,
        "today": today,
        "prev_month": prev_month,
        "prev_year": prev_year,
        "next_month": next_month,
        "next_year": next_year,
        "target_lists": TargetList.objects.filter(calendarevent__in=events).distinct(),
        "utc_offset": utc_offset,
        "utc_offset_choices": range(-12, 13),
    }

    if request.htmx:
        template = "tom_calendar/partials/calendar.html"
    else:
        template = "tom_calendar/calendar_page.html"

    return render(request, template, context)


class EventForm(forms.ModelForm):
    class Meta:
        model = CalendarEvent
        fields = [
            'title', 'start_time', 'end_time', 'description', 'url',
            'target_list', 'user', 'proposal', 'telescope', 'instrument'
        ]
        widgets = {
            'start_time': DATETIME_INPUT,
            'end_time': DATETIME_INPUT,
            'description': forms.Textarea(attrs={'rows': 5}),
        }

    def clean(self):
        cleaned_data = super().clean() or {}
        start = cleaned_data.get('start_time')
        end = cleaned_data.get('end_time')
        if start and end and end < start:
            raise forms.ValidationError('End time must be after start time.')
        return cleaned_data


def create_event(request):
    if request.method == "POST":
        form = EventForm(request.POST)
        if form.is_valid():
            event = form.save()
            if "save_and_edit" in request.POST:
                form = EventForm(instance=event)
                response = render(
                    request,
                    "tom_calendar/partials/event_form.html",
                    {"form": form, "event": event, "action": "update"}
                )
                response["HX-Retarget"] = "#cal-modal-body"
                response["HX-Reswap"] = "innerHTML"
                return trigger_client_event(response, "calRefresh")
            response = render_calendar(request, month=event.start_time.month)
            return trigger_client_event(response, "calClose")
        else:
            response = render(request, "tom_calendar/partials/event_form.html", {"form": form, "action": "create"})
            response["HX-Retarget"] = "#cal-modal-body"
            response["HX-Reswap"] = "innerHTML"
            return response

    else:
        try:
            date_str = request.GET["date"]
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
            initial_data = {
                "start_time": datetime.combine(date_obj, datetime.min.time()),
                "end_time": datetime.combine(date_obj, datetime.max.time()),
            }
            form = EventForm(initial=initial_data)
        except KeyError:
            form = EventForm()

        return render(request, "tom_calendar/partials/event_form.html", {"form": form, "action": "create"})


def update_event(request, event_id):
    event = get_object_or_404(CalendarEvent, pk=event_id)

    if request.method == "POST":
        form = EventForm(request.POST, instance=event)
        if form.is_valid():
            event = form.save()
            response = render_calendar(request, month=event.start_time.month)
            return trigger_client_event(response, "calClose")
        else:
            response = render(
                request,
                "tom_calendar/partials/event_form.html",
                {"form": form, "event": event, "action": "update"}
            )
            response["HX-Retarget"] = "#cal-modal-body"
            response["HX-Reswap"] = "innerHTML"
            return response

    else:
        form = EventForm(instance=event)
        return render(
            request,
            "tom_calendar/partials/event_form.html",
            {"form": form, "event": event, "action": "update"}
        )


def delete_event(request, event_id):
    event = get_object_or_404(CalendarEvent, pk=event_id)
    event.delete()
    response = render_calendar(request)
    return trigger_client_event(response, "calClose")


def create_todo(request, event_id):
    event = get_object_or_404(CalendarEvent, pk=event_id)
    description = request.POST.get("description", "").strip()
    if description:
        event.todos.create(description=description)
        response = render(request, "tom_calendar/partials/todos.html", {"event": event})
        return trigger_client_event(response, "calRefresh")


def update_todo(request, todo_id):
    todo = get_object_or_404(EventTodo, pk=todo_id)
    is_completed = request.POST.get("is_completed") == "true"
    description = request.POST.get("description", "").strip()
    todo.is_completed = is_completed
    todo.description = description
    todo.save()
    response = render(request, "tom_calendar/partials/todos.html", {"event": todo.event})
    return trigger_client_event(response, "calRefresh")
