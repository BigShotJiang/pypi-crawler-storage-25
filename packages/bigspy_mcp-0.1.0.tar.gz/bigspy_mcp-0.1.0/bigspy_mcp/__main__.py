"""支持 python -m bigspy_mcp 启动"""

from .server import main

main()
