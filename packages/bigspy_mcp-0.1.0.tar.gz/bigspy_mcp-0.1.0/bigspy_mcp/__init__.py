"""BigSpy MCP Server - 通过 Chrome CDP 查询 BigSpy 广告数据"""

__version__ = "0.1.0"
