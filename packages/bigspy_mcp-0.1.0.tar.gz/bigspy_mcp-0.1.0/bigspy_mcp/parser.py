"""
parser.py
解析 BigSpy creative/list API 响应
"""
import json
from typing import Optional


def parse_creative_list(raw: dict, advertiser: str, platform: str) -> dict:
    """解析 fetch_ads 返回的数据"""
    creative_list = raw.get("creative_list", [])
    total = raw.get("total", 0)
    fetched = raw.get("fetched", len(creative_list))

    creatives = [_parse_one(item, platform) for item in creative_list]

    biz_breakdown = {}
    for c in creatives:
        bl = c["advertiser_name"]
        biz_breakdown[bl] = biz_breakdown.get(bl, 0) + 1

    top_by_impressions = sorted(
        creatives, key=lambda x: x["impressions"], reverse=True
    )[:5]

    return {
        "advertiser": advertiser,
        "platform": platform,
        "total_in_db": total,
        "fetched": fetched,
        "advertiser_breakdown": biz_breakdown,
        "top5_by_impressions": top_by_impressions,
        "all_creatives": creatives,
    }


def _parse_one(raw: dict, platform: str) -> dict:
    return {
        "ad_key": str(raw.get("ad_key", "")),
        "advertiser_name": raw.get("advertiser_name", ""),
        "platform": raw.get("platform", platform),
        "title": raw.get("title", ""),
        "body": raw.get("body", ""),
        "message": raw.get("message", ""),
        "call_to_action": raw.get("call_to_action", ""),
        "impressions": _safe_int(raw.get("impression", 0)),
        "heat_score": _safe_int(raw.get("heat", 0)),
        "like_count": _safe_int(raw.get("like_count", 0)),
        "comment_count": _safe_int(raw.get("comment_count", 0)),
        "share_count": _safe_int(raw.get("share_count", 0)),
        "view_count": _safe_int(raw.get("view_count", 0)),
        "run_days": _safe_int(raw.get("days_count", 0)),
        "first_seen": raw.get("first_seen", ""),
        "last_seen": raw.get("last_seen", ""),
        "os": raw.get("os", ""),
        "ads_type": raw.get("ads_type", ""),
        "media_type": _infer_media_type(raw),
        "landing_url": raw.get("has_source_url", ""),
        "preview_img": raw.get("preview_img_url", ""),
    }


def _infer_media_type(raw: dict) -> str:
    duration = raw.get("video_duration", 0)
    if duration and int(duration) > 0:
        return "video"
    resource = json.dumps(raw.get("resource_urls", "")).lower()
    if any(ext in resource for ext in [".mp4", ".mov", "video"]):
        return "video"
    if any(ext in resource for ext in [".jpg", ".png", ".gif", "image"]):
        return "image"
    if raw.get("preview_img_url"):
        return "image"
    return "unknown"


def _safe_int(val) -> int:
    try:
        return int(val)
    except (TypeError, ValueError):
        return 0


def group_by_platform(creatives: list) -> dict:
    """按 platform 字段分组，返回 {platform: [creatives]}"""
    groups = {}
    for c in creatives:
        plat = c.get("platform", "unknown")
        groups.setdefault(plat, []).append(c)
    return groups


def platform_summary(creatives: list) -> dict:
    """按平台分组并生成汇总统计"""
    groups = group_by_platform(creatives)
    total = len(creatives)
    summary = {}
    for plat, items in sorted(groups.items(), key=lambda x: -len(x[1])):
        top = sorted(items, key=lambda x: x.get("impressions", 0), reverse=True)[:3]
        summary[plat] = {
            "count": len(items),
            "percentage": round(len(items) / total * 100, 1) if total else 0,
            "top_creatives": [
                {"title": c["title"][:80], "impressions": c["impressions"]}
                for c in top
            ],
        }
    return summary


def summarize_for_claude(parsed: dict) -> str:
    lines = [
        f"广告主：{parsed['advertiser']} | 平台：{parsed['platform']}",
        f"共找到 {parsed['total_in_db']} 条（本次获取 {parsed['fetched']} 条）",
    ]

    # 平台分布
    groups = group_by_platform(parsed["all_creatives"])
    if len(groups) > 1:
        lines.append("")
        lines.append("── 渠道分布 ──")
        total = len(parsed["all_creatives"])
        for plat, items in sorted(groups.items(), key=lambda x: -len(x[1])):
            pct = round(len(items) / total * 100, 1) if total else 0
            lines.append(f"  {plat}: {len(items)} ({pct}%)")

    lines.append("")
    lines.append(f"广告主分布：{parsed['advertiser_breakdown']}")
    lines.append("")
    lines.append("── 展示量 Top5 素材 ──")

    for i, c in enumerate(parsed["top5_by_impressions"], 1):
        title = c["title"] or c["body"] or "(无标题)"
        if len(title) > 50:
            title = title[:50] + "..."
        lines.append(
            f"{i}. [{c['platform']}] {title} | "
            f"展示: {c['impressions']:,} | 热度: {c['heat_score']} | "
            f"投放: {c['run_days']}天 | "
            f"互动: {c['like_count']}❤ {c['comment_count']}💬 {c['share_count']}↗"
        )
    return "\n".join(lines)
