"""
exporter.py
将广告数据导出为 CSV / JSON / Excel
"""
import csv
import json
import os
from datetime import datetime
from typing import Optional


EXPORT_FIELDS = [
    "ad_key",
    "advertiser_name",
    "platform",
    "title",
    "body",
    "call_to_action",
    "impressions",
    "heat_score",
    "like_count",
    "comment_count",
    "share_count",
    "view_count",
    "run_days",
    "first_seen",
    "last_seen",
    "os",
    "media_type",
    "landing_url",
]


def export_data(
    creatives: list[dict],
    format: str = "csv",
    save_path: Optional[str] = None,
    filename: Optional[str] = None,
) -> str:
    """
    导出广告数据。

    Args:
        creatives: parse_creative_list 返回的 all_creatives 列表
        format:    csv / json / excel（excel 实际输出为 .xlsx）
        save_path: 保存目录，默认桌面
        filename:  文件名（不含扩展名），默认自动生成

    Returns:
        保存的完整文件路径
    """
    if not save_path:
        save_path = os.path.expanduser("~/Desktop")

    if not filename:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"bigspy_export_{ts}"

    os.makedirs(save_path, exist_ok=True)

    format = format.lower().strip()

    if format == "csv":
        return _export_csv(creatives, save_path, filename)
    elif format == "json":
        return _export_json(creatives, save_path, filename)
    elif format in ("excel", "xlsx"):
        return _export_excel(creatives, save_path, filename)
    else:
        raise ValueError(f"不支持的格式: {format}，请选择 csv / json / excel")


def _export_csv(creatives: list[dict], save_path: str, filename: str) -> str:
    filepath = os.path.join(save_path, f"{filename}.csv")
    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=EXPORT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for c in creatives:
            row = {k: c.get(k, "") for k in EXPORT_FIELDS}
            if isinstance(row.get("first_seen"), int) and row["first_seen"] > 0:
                row["first_seen"] = datetime.fromtimestamp(row["first_seen"]).strftime("%Y-%m-%d")
            if isinstance(row.get("last_seen"), int) and row["last_seen"] > 0:
                row["last_seen"] = datetime.fromtimestamp(row["last_seen"]).strftime("%Y-%m-%d")
            writer.writerow(row)
    return filepath


def _export_json(creatives: list[dict], save_path: str, filename: str) -> str:
    filepath = os.path.join(save_path, f"{filename}.json")
    export = []
    for c in creatives:
        row = {k: c.get(k, "") for k in EXPORT_FIELDS}
        export.append(row)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(export, f, ensure_ascii=False, indent=2)
    return filepath


def _export_excel(creatives: list[dict], save_path: str, filename: str) -> str:
    try:
        from openpyxl import Workbook
    except ImportError:
        filepath = os.path.join(save_path, f"{filename}.csv")
        _export_csv(creatives, save_path, filename)
        return filepath + " (openpyxl 未安装，已降级为 CSV)"

    filepath = os.path.join(save_path, f"{filename}.xlsx")
    wb = Workbook()
    ws = wb.active
    ws.title = "BigSpy Ads"

    ws.append(EXPORT_FIELDS)

    for c in creatives:
        row = []
        for k in EXPORT_FIELDS:
            val = c.get(k, "")
            if k in ("first_seen", "last_seen") and isinstance(val, int) and val > 0:
                val = datetime.fromtimestamp(val).strftime("%Y-%m-%d")
            row.append(val)
        ws.append(row)

    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)

    wb.save(filepath)
    return filepath
