#!/usr/bin/env python3
"""
BigSpy MCP Server

两种使用模式：
  模式1（抓当前页）：用户在 Chrome 里设好筛选条件 → 调用 grab_current_search → 自动翻页拉完
  模式2（Prompt 驱动）：用户描述需求 → 调用 search_ads → 自动翻页拉完

导出：调用 export_data 保存为 CSV / JSON / Excel
"""
from fastmcp import FastMCP
from .browser import get_browser, reset_browser
from .parser import parse_creative_list, summarize_for_claude, platform_summary
from .exporter import export_data

mcp = FastMCP(
    name="bigspy",
    instructions=(
        "BigSpy 广告情报工具。Chrome 调试模式会自动启动，无需用户手动操作。\n\n"
        "【重要】搜索前必须确认筛选条件：\n"
        "1. 搜索类型：是搜「关键词」还是搜「广告主」？（如果搜广告主，需要 advertiser_key）\n"
        "2. 国家：哪个国家？（默认 US）\n"
        "3. 时间范围：最近多少天？（7 / 30 / 90）\n"
        "4. 平台：全部还是某个特定平台？\n"
        "用户 prompt 里没提到的参数必须主动询问，不能自己假设。\n\n"
        "【重要】数据受用户套餐限制：\n"
        "不同用户的付费套餐不同，可访问的平台和功能也不同。\n"
        "首次连接时调用 check_connection 获取账户信息，根据 available_platforms 判断哪些平台可查。\n"
        "如果某平台 API 返回 PARAMS ERROR，说明该用户套餐不支持该平台，要如实告知用户。\n\n"
        "模式1 - 抓当前页：用户在 Chrome 里选好筛选条件，说「帮我抓当前搜索结果」。\n"
        "模式2 - Prompt 驱动：用户描述需求，确认筛选条件后调用 search_ads。\n\n"
        "数据获取后，询问用户是否需要导出，确认格式和保存位置后调用 export_data。"
    ),
)

# 保存最近一次获取的数据，供 export_data 使用
_last_result = {"creatives": [], "meta": {}}


@mcp.tool()
async def check_connection() -> dict:
    """
    检查 Chrome 连接和 BigSpy 登录状态，获取账户权限信息。
    如果 Chrome 调试模式未启动，会自动启动。

    返回账户信息包括：
    - plan_code: 当前套餐
    - available_platforms: 可用平台列表（受套餐限制）
    - daily_search_quota: 每日搜索配额

    首次使用或出错时调用。
    """
    try:
        browser = await get_browser()
        logged_in = await browser.is_logged_in()
        if logged_in:
            account = browser.get_account_info()
            return {
                "status": "ready",
                "message": "Chrome 已连接，BigSpy 已登录，可以开始查询。",
                "account": account,
            }
        else:
            return {
                "status": "not_logged_in",
                "message": (
                    "Chrome 已连接，但 BigSpy 未登录。\n"
                    "请在调试模式的 Chrome 里打开 bigspy.com 并登录，然后重试。"
                ),
            }
    except ConnectionError as e:
        return {"status": "chrome_not_connected", "message": str(e)}


@mcp.tool()
async def grab_current_search(limit: int = 500) -> dict:
    """
    【模式1】抓取用户在 BigSpy Chrome 页面当前的搜索结果。

    使用方式：用户先在 Chrome 的 BigSpy 页面里选好所有筛选条件
    （平台、时间范围、广告主、国家等），然后调用此工具。
    工具会自动读取当前的搜索参数，然后翻页拉完所有数据。

    支持 BigSpy 上的所有筛选项，不需要用户在 prompt 里重新指定。

    Args:
        limit: 最多获取多少条数据，默认 500
    """
    global _last_result
    try:
        browser = await get_browser()

        params = await browser.grab_current_params(timeout=15)
        if not params:
            return {
                "error": "no_search",
                "message": (
                    "未检测到搜索请求。请先在 Chrome 的 BigSpy 页面里进行一次搜索，"
                    "然后再调用此工具。"
                ),
            }

        raw = await browser.fetch_with_params(params, limit=limit)

        if raw.get("fetched", 0) == 0:
            return {"error": "no_data", "message": "搜索结果为空"}

        parsed = parse_creative_list(raw, "当前搜索", "auto")
        _last_result = {"creatives": parsed["all_creatives"], "meta": raw}

        return {
            "total_in_db": raw["total"],
            "fetched": raw["fetched"],
            "pages_fetched": raw["pages_fetched"],
            "remain_req_count": raw.get("remain_req_count"),
            "summary": summarize_for_claude(parsed),
            "message": (
                f"已获取 {raw['fetched']} 条数据（共 {raw['total']} 条）。\n"
                "需要导出数据吗？支持 CSV / JSON / Excel 格式。"
            ),
        }

    except ConnectionError as e:
        return {"error": "connection_failed", "message": str(e)}
    except PermissionError as e:
        return {"error": "permission_denied", "message": str(e)}
    except Exception as e:
        return {"error": "unknown", "message": f"出错了：{e}"}


@mcp.tool()
async def search_ads(
    keyword: str = "",
    advertiser_key: str = "",
    platform: str = "all",
    country: str = "US",
    days: int = 30,
    limit: int = 500,
) -> dict:
    """
    【模式2】通过参数搜索广告数据，自动翻页。

    当用户在 prompt 里描述搜索需求时使用此工具。

    重要：搜索广告主时，请用 advertiser_key（如 com.upside.consumer.android），
    并将 platform 设为 all，这样会拉取所有平台数据并自动按渠道分组统计。
    仅搜关键词时可以指定 platform。

    如果用户没有指定某些参数，请先询问用户：
    - country: 哪个国家？（US / GB / JP / CN 等）
    - days: 最近多少天？（7 / 30 / 90）

    Args:
        keyword:        搜索关键词，如 uber / lyft / doordash
        advertiser_key: 广告主 ID（推荐），如 com.upside.consumer.android
        platform:       投放平台，默认 all（全部）。可选 facebook / instagram / tiktok / twitter / youtube
        country:        国家代码，默认 US
        days:           近多少天，默认 30
        limit:          获取条数上限，默认 500
    """
    global _last_result
    try:
        browser = await get_browser()

        fetch_platform = "all" if advertiser_key else platform

        raw = await browser.fetch_ads(
            keyword=keyword,
            advertiser_key=advertiser_key,
            platform=fetch_platform,
            country=country,
            days=days,
            limit=limit,
        )

        if not raw or raw.get("fetched", 0) == 0:
            return {
                "error": "no_data",
                "message": "未获取到数据，请确认搜索条件或登录状态",
            }

        label = advertiser_key or keyword
        parsed = parse_creative_list(raw, label, fetch_platform)

        # 按平台过滤（如果用户指定了特定平台且是按广告主搜的）
        if advertiser_key and platform != "all":
            filtered = [c for c in parsed["all_creatives"] if c["platform"] == platform]
            if not filtered:
                return {
                    "error": "no_data",
                    "message": f"该广告主在 {platform} 上没有广告数据",
                }
            parsed["all_creatives"] = filtered
            parsed["fetched"] = len(filtered)

        _last_result = {"creatives": parsed["all_creatives"], "meta": raw}

        result = {
            "total_in_db": parsed["total_in_db"],
            "fetched": len(parsed["all_creatives"]),
            "pages_fetched": raw.get("pages_fetched", 0),
            "remain_req_count": raw.get("remain_req_count"),
            "platform_breakdown": platform_summary(parsed["all_creatives"]),
            "summary": summarize_for_claude(parsed),
            "message": (
                f"已获取 {len(parsed['all_creatives'])} 条数据（共 {parsed['total_in_db']} 条）。\n"
                "需要导出数据吗？支持 CSV / JSON / Excel 格式。"
            ),
        }
        return result

    except ConnectionError as e:
        return {"error": "connection_failed", "message": str(e)}
    except PermissionError as e:
        browser = await get_browser()
        account = browser.get_account_info()
        return {
            "error": "permission_denied",
            "message": str(e),
            "available_platforms": account.get("available_platforms", []),
            "hint": "当前套餐可用的平台见 available_platforms，请换一个支持的平台或升级套餐。",
        }
    except Exception as e:
        return {"error": "unknown", "message": f"出错了：{e}"}


@mcp.tool()
async def export_ads(
    format: str = "csv",
    save_path: str = "",
    filename: str = "",
) -> dict:
    """
    导出最近一次获取的广告数据。

    调用前需要先用 grab_current_search 或 search_ads 获取数据。
    如果用户没有指定格式和路径，请先询问：
    - format: 什么格式？（csv / json / excel）
    - save_path: 保存到哪里？（默认桌面）

    Args:
        format:    导出格式：csv / json / excel
        save_path: 保存目录，默认桌面 ~/Desktop
        filename:  文件名（不含扩展名），默认自动生成
    """
    global _last_result
    creatives = _last_result.get("creatives", [])
    if not creatives:
        return {
            "error": "no_data",
            "message": "没有可导出的数据。请先用 grab_current_search 或 search_ads 获取数据。",
        }

    try:
        filepath = export_data(
            creatives=creatives,
            format=format,
            save_path=save_path or None,
            filename=filename or None,
        )
        return {
            "status": "success",
            "filepath": filepath,
            "count": len(creatives),
            "format": format,
            "message": f"已导出 {len(creatives)} 条数据到：{filepath}",
        }
    except Exception as e:
        return {"error": "export_failed", "message": str(e)}


@mcp.tool()
async def get_cross_platform_summary(
    keyword: str = "",
    advertiser_key: str = "",
    country: str = "US",
    days: int = 30,
    limit: int = 500,
) -> dict:
    """
    获取广告主在所有平台的投放汇总对比，自动按渠道分组统计。

    只需查询一次，自动按返回数据中的平台字段分组。
    推荐使用 advertiser_key 以获得准确的广告主数据。

    Args:
        keyword:        搜索关键词
        advertiser_key: 广告主 ID（推荐），如 com.upside.consumer.android
        country:        国家代码
        days:           近多少天
        limit:          获取条数上限，默认 500
    """
    global _last_result
    try:
        browser = await get_browser()
        raw = await browser.fetch_ads(
            keyword=keyword,
            advertiser_key=advertiser_key,
            platform="all",
            country=country,
            days=days,
            limit=limit,
        )

        if not raw or raw.get("fetched", 0) == 0:
            return {"error": "no_data", "message": "未获取到数据"}

        label = advertiser_key or keyword
        parsed = parse_creative_list(raw, label, "all")
        _last_result = {"creatives": parsed["all_creatives"], "meta": raw}

        breakdown = platform_summary(parsed["all_creatives"])

        return {
            "advertiser": label,
            "country": country,
            "days": days,
            "total": parsed["total_in_db"],
            "fetched": len(parsed["all_creatives"]),
            "remain_req_count": raw.get("remain_req_count"),
            "by_platform": breakdown,
            "summary": summarize_for_claude(parsed),
            "message": (
                f"已获取 {len(parsed['all_creatives'])} 条数据（共 {parsed['total_in_db']} 条）。\n"
                "需要导出数据吗？支持 CSV / JSON / Excel 格式。"
            ),
        }

    except ConnectionError as e:
        return {"error": "connection_failed", "message": str(e)}
    except PermissionError as e:
        return {"error": "permission_denied", "message": str(e)}
    except Exception as e:
        return {"error": "unknown", "message": f"出错了：{e}"}


@mcp.tool()
async def compare_advertisers(
    advertiser_keys: list[str],
    country: str = "US",
    days: int = 30,
    limit: int = 200,
) -> dict:
    """
    对比多个广告主的投放数据。

    使用 advertiser_key 列表进行对比，自动获取各平台分布。

    Args:
        advertiser_keys: 广告主 ID 列表，如 ["com.upside.consumer.android", "com.ubercab"]
        country:         国家代码
        days:            近多少天
        limit:           每个广告主获取条数上限
    """
    browser = await get_browser()
    results = {}

    for key in advertiser_keys:
        try:
            raw = await browser.fetch_ads(
                keyword="",
                advertiser_key=key,
                platform="all",
                country=country,
                days=days,
                limit=limit,
            )
            if raw and raw.get("fetched", 0) > 0:
                parsed = parse_creative_list(raw, key, "all")
                top = parsed["top5_by_impressions"]
                results[key] = {
                    "total_ads": parsed["total_in_db"],
                    "fetched": parsed["fetched"],
                    "platform_breakdown": platform_summary(parsed["all_creatives"]),
                    "max_impressions": max((c["impressions"] for c in top), default=0),
                    "top_creative_title": top[0]["title"][:60] if top else "",
                }
            else:
                results[key] = {"total_ads": 0}
        except Exception as e:
            results[key] = {"error": str(e)}

    ranked = sorted(results.items(), key=lambda x: x[1].get("total_ads", 0), reverse=True)
    return {
        "country": country,
        "days": days,
        "results": results,
        "ranked_by_volume": [r[0] for r in ranked],
    }


@mcp.tool()
async def reset_connection() -> dict:
    """重置 Chrome 连接。Chrome 重启后或连接断开时调用。"""
    await reset_browser()
    return {"status": "reset", "message": "连接已重置，下次调用工具时会重新连接"}


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
