"""
browser.py
CDP 连接管理 + 通过 iframe fetch() 自动翻页抓取
自动检测并启动 Chrome 调试模式
"""

import asyncio
import json
import os
import platform
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path
from typing import Optional
from playwright.async_api import async_playwright, Browser, Page, Frame

CDP_URL = "http://127.0.0.1:9222"
BIGSPY_BASE = "https://bigspy.com"

POSITION_MAP = {
    "all": "0",
    "facebook": "2",
    "instagram": "3",
    "youtube": "4",
    "twitter": "5",
    "pinterest": "6",
    "tiktok": "7",
}

COUNTRY_MAP = {
    "US": "USA", "GB": "GBR", "CA": "CAN", "AU": "AUS",
    "DE": "DEU", "FR": "FRA", "JP": "JPN", "CN": "CHN",
    "IN": "IND", "BR": "BRA", "MX": "MEX", "KR": "KOR",
    "SG": "SGP", "TW": "TWN", "HK": "HKG", "TH": "THA",
}


DEBUG_PROFILE_DIR = str(Path.home() / ".chrome-debug-profile")


def _find_chrome() -> Optional[str]:
    system = platform.system()
    if system == "Darwin":
        candidates = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]
    elif system == "Windows":
        base_dirs = [
            os.environ.get("PROGRAMFILES", "C:\\Program Files"),
            os.environ.get("PROGRAMFILES(X86)", "C:\\Program Files (x86)"),
            os.environ.get("LOCALAPPDATA", ""),
        ]
        candidates = []
        for d in base_dirs:
            if d:
                candidates.append(os.path.join(d, "Google", "Chrome", "Application", "chrome.exe"))
    else:
        candidates = ["google-chrome", "google-chrome-stable", "chromium-browser", "chromium"]
    for c in candidates:
        if system == "Linux":
            import shutil
            if shutil.which(c):
                return c
        elif os.path.exists(c):
            return c
    return None


def _is_chrome_debug_running() -> bool:
    import urllib.request
    try:
        urllib.request.urlopen("http://127.0.0.1:9222/json/version", timeout=2)
        return True
    except Exception:
        return False


def _launch_chrome() -> bool:
    if _is_chrome_debug_running():
        return True

    chrome_path = _find_chrome()
    if not chrome_path:
        return False

    cmd = [
        chrome_path,
        "--remote-debugging-port=9222",
        f"--user-data-dir={DEBUG_PROFILE_DIR}",
    ]

    try:
        popen_kwargs = {
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
        }
        if platform.system() == "Windows":
            popen_kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            popen_kwargs["start_new_session"] = True

        subprocess.Popen(cmd, **popen_kwargs)
    except Exception:
        return False

    for _ in range(15):
        time.sleep(1)
        if _is_chrome_debug_running():
            return True
    return False


class BigSpyBrowser:
    def __init__(self):
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._page: Optional[Page] = None
        self._token: Optional[str] = None
        self._device_id: Optional[str] = None
        self._timezone: str = "+0000"
        self._user_info: Optional[dict] = None

    async def connect(self) -> bool:
        if not _is_chrome_debug_running():
            launched = _launch_chrome()
            if not launched:
                chrome_path = _find_chrome()
                if not chrome_path:
                    raise ConnectionError(
                        "未找到 Chrome 浏览器。请安装 Google Chrome 后重试。"
                    )
                raise ConnectionError(
                    f"Chrome 调试模式启动失败。请手动运行：\n"
                    f'  "{chrome_path}" --remote-debugging-port=9222'
                    f' --user-data-dir="{DEBUG_PROFILE_DIR}"'
                )

        try:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.connect_over_cdp(CDP_URL)
            contexts = self._browser.contexts
            if not contexts:
                raise Exception("Chrome 里没有打开的页面")
            ctx = contexts[0]

            self._page = None
            for page in ctx.pages:
                if "bigspy.com" in page.url:
                    self._page = page
                    break

            if not self._page:
                self._page = await ctx.new_page()
                await self._page.goto(
                    f"{BIGSPY_BASE}/adspy/facebook/?app_type=2",
                    wait_until="domcontentloaded",
                )
                await self._page.wait_for_timeout(3000)

            await self._extract_auth()
            await self._fetch_user_info()
            return True

        except Exception as e:
            raise ConnectionError(
                f"Chrome 已启动但连接失败：{e}\n\n"
                "请确认 Chrome 里已登录 BigSpy（bigspy.com），然后重试。"
            )

    async def _extract_auth(self):
        """从 iframe URL 提取 JWT token，从请求头提取 device-id"""
        # 1. 从 iframe URL 拿 token
        for f in self._page.frames:
            if "iframe/adspy" in f.url:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(f.url).query)
                self._token = qs.get("token", [None])[0]
                break

        if not self._token:
            await self._page.reload(wait_until="domcontentloaded")
            await self._page.wait_for_timeout(3000)
            for f in self._page.frames:
                if "iframe/adspy" in f.url:
                    qs = urllib.parse.parse_qs(urllib.parse.urlparse(f.url).query)
                    self._token = qs.get("token", [None])[0]
                    break

        # 2. 从请求头拿 device-id 和 timezone
        captured = {}

        async def grab(request):
            if "napi/v1/creative" in request.url:
                captured.update(request.headers)

        self._page.on("request", grab)
        await self._page.reload(wait_until="domcontentloaded")
        await self._page.wait_for_timeout(5000)
        self._page.remove_listener("request", grab)

        self._device_id = captured.get("x-device-id", "")
        self._timezone = captured.get("x-timezone", "+0000")

    async def _fetch_user_info(self):
        """获取用户账户信息（套餐、权限、配额等）"""
        iframe = self._get_iframe()
        if not iframe or not self._token:
            return
        try:
            result = await iframe.evaluate("""
                async (token) => {
                    const resp = await fetch('/napi/v1/bs-user/info', {
                        headers: { 'Authorization': token }
                    });
                    return await resp.json();
                }
            """, self._token)
            if result.get("id") == "SUCCESS":
                self._user_info = result.get("data", {})
        except Exception:
            pass

    def get_account_info(self) -> dict:
        """返回当前账户的套餐和权限信息"""
        if not self._user_info:
            return {"error": "未获取到账户信息"}

        perm = self._user_info.get("permission", {})
        filt = perm.get("filter", {})
        user_count = perm.get("user_count", {})
        search_quota = user_count.get("search", {})

        return {
            "username": self._user_info.get("username", ""),
            "plan_code": self._user_info.get("plan_code", ""),
            "plan_expires": self._user_info.get("plan_end_ts", 0),
            "available_platforms": filt.get("platforms", []),
            "app_types": filt.get("app_types", []),
            "daily_search_quota": search_quota.get("count", 0),
            "modules": perm.get("module", {}),
        }

    def _get_iframe(self) -> Optional[Frame]:
        for f in self._page.frames:
            if "iframe/adspy" in f.url:
                return f
        return None

    async def is_logged_in(self) -> bool:
        if not self._token:
            return False
        iframe = self._get_iframe()
        if not iframe:
            return False
        result = await iframe.evaluate("""
            async (token) => {
                const resp = await fetch('/napi/v1/bs-user/info', {
                    headers: { 'Authorization': token }
                });
                return await resp.json();
            }
        """, self._token)
        return (
            result.get("id") == "SUCCESS"
            and result.get("data", {}).get("plan_code", "Anonymity") != "Anonymity"
        )

    async def get_count(self, params: dict) -> dict:
        iframe = self._get_iframe()
        if not iframe:
            raise ConnectionError("BigSpy iframe 未找到，请确认页面已打开")
        result = await iframe.evaluate("""
            async ({ params, token, deviceId, timezone }) => {
                const resp = await fetch('/napi/v1/creative/count', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': token,
                        'x-device-id': deviceId,
                        'x-timezone': timezone,
                    },
                    body: JSON.stringify(params)
                });
                return await resp.json();
            }
        """, {
            "params": params,
            "token": self._token,
            "deviceId": self._device_id,
            "timezone": self._timezone,
        })
        if result.get("id") == "PARAMS ERROR":
            raise PermissionError(
                f"当前套餐不支持此查询条件（API 返回 PARAMS ERROR）。"
                f"请检查平台权限或搜索参数。"
            )
        return result.get("data", {})

    async def _fetch_one_page(self, params: dict) -> dict:
        iframe = self._get_iframe()
        if not iframe:
            raise ConnectionError("BigSpy iframe 未找到")
        return await iframe.evaluate("""
            async ({ params, token, deviceId, timezone }) => {
                const resp = await fetch('/napi/v1/creative/list', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': token,
                        'x-device-id': deviceId,
                        'x-timezone': timezone,
                    },
                    body: JSON.stringify(params)
                });
                return await resp.json();
            }
        """, {
            "params": params,
            "token": self._token,
            "deviceId": self._device_id,
            "timezone": self._timezone,
        })

    def _build_params(
        self,
        keyword: str = "",
        advertiser_key: str = "",
        platform: str = "facebook",
        country: str = "",
        days: int = 30,
        sort: str = "-correlation",
        page: int = 1,
        page_size: int = 60,
    ) -> dict:
        now = int(time.time())
        params = {
            "page": page,
            "page_size": page_size,
            "app_type": "2",
            "search_type": 1,
            "sort_field": sort,
            "seen_begin": now - days * 86400,
            "seen_end": now,
            "position": POSITION_MAP.get(platform.lower(), "0"),
        }
        if keyword:
            params["keyword"] = [keyword]
        if advertiser_key:
            params["advertiser_key"] = [advertiser_key]
        if country:
            geo = COUNTRY_MAP.get(country.upper(), country.upper())
            params["geo"] = [geo]
        return params

    async def fetch_ads(
        self,
        keyword: str = "",
        advertiser_key: str = "",
        platform: str = "facebook",
        country: str = "",
        days: int = 30,
        limit: int = 200,
        page_size: int = 60,
    ) -> dict:
        """
        自动翻页获取广告数据。

        返回: {
            "total": 总数,
            "fetched": 实际获取条数,
            "pages_fetched": 翻了几页,
            "creative_list": [...],
            "remain_req_count": 剩余请求配额,
        }
        """
        params = self._build_params(
            keyword=keyword,
            advertiser_key=advertiser_key,
            platform=platform,
            country=country,
            days=days,
            page=1,
            page_size=page_size,
        )

        # 先查总数
        count_data = await self.get_count(params) or {}
        total = count_data.get("result_total", 0)

        all_creatives = []
        pages_needed = min(
            (limit + page_size - 1) // page_size,
            (total + page_size - 1) // page_size if total > 0 else 1,
        )

        remain = None
        pages_fetched = 0

        for page_num in range(1, pages_needed + 1):
            params["page"] = page_num
            params["is_first"] = (page_num == 1)

            result = await self._fetch_one_page(params)

            if result.get("id") != "SUCCESS":
                break

            creative_list = result.get("data", {}).get("creative_list", [])
            remain = result.get("remain_req_count")
            pages_fetched = page_num

            if not creative_list:
                break

            all_creatives.extend(creative_list)

            if len(all_creatives) >= limit:
                all_creatives = all_creatives[:limit]
                break

            if page_num < pages_needed:
                await asyncio.sleep(0.5)

        return {
            "total": total,
            "fetched": len(all_creatives),
            "pages_fetched": pages_fetched,
            "creative_list": all_creatives,
            "remain_req_count": remain,
        }

    async def grab_current_params(self, timeout: int = 30) -> dict:
        """
        监听当前 BigSpy 页面，抓取最近一次 creative/list 请求的完整参数。
        用户在 Chrome 里设好筛选条件后调用此方法。

        如果页面上已有搜索结果，会先尝试刷新触发请求。
        如果没有，等待用户手动触发搜索（最多等 timeout 秒）。
        """
        captured_params = {"data": None, "done": asyncio.Event()}

        async def on_request(request):
            if (
                "napi/v1/creative/list" in request.url
                and request.method == "POST"
                and request.post_data
            ):
                try:
                    captured_params["data"] = json.loads(request.post_data)
                    captured_params["done"].set()
                except Exception:
                    pass

        self._page.on("request", on_request)

        try:
            # 刷新页面触发已有搜索条件的请求
            await self._page.reload(wait_until="domcontentloaded")
            try:
                await asyncio.wait_for(
                    captured_params["done"].wait(), timeout=timeout
                )
            except asyncio.TimeoutError:
                return None
            return captured_params["data"]
        finally:
            self._page.remove_listener("request", on_request)

    async def fetch_with_params(self, params: dict, limit: int = 500) -> dict:
        """
        用给定的参数（通常来自 grab_current_params）自动翻页获取数据。
        """
        page_size = params.get("page_size", 60)

        count_data = await self.get_count(params)
        total = count_data.get("result_total", 0)

        all_creatives = []
        pages_needed = min(
            (limit + page_size - 1) // page_size,
            (total + page_size - 1) // page_size if total > 0 else 1,
        )

        remain = None
        pages_fetched = 0

        for page_num in range(1, pages_needed + 1):
            params["page"] = page_num
            params["is_first"] = (page_num == 1)

            result = await self._fetch_one_page(params)

            if result.get("id") != "SUCCESS":
                break

            creative_list = result.get("data", {}).get("creative_list", [])
            remain = result.get("remain_req_count")
            pages_fetched = page_num

            if not creative_list:
                break

            all_creatives.extend(creative_list)

            if len(all_creatives) >= limit:
                all_creatives = all_creatives[:limit]
                break

            if page_num < pages_needed:
                await asyncio.sleep(0.5)

        return {
            "total": total,
            "fetched": len(all_creatives),
            "pages_fetched": pages_fetched,
            "creative_list": all_creatives,
            "remain_req_count": remain,
            "params_used": params,
        }

    async def close(self):
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()


_browser_instance: Optional[BigSpyBrowser] = None


async def get_browser() -> BigSpyBrowser:
    global _browser_instance
    if _browser_instance is None:
        _browser_instance = BigSpyBrowser()
        await _browser_instance.connect()
    return _browser_instance


async def reset_browser():
    global _browser_instance
    if _browser_instance:
        await _browser_instance.close()
    _browser_instance = None
