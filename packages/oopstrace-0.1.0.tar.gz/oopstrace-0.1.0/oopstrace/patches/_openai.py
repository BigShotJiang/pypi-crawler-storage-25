"""Auto-instrumentation patch for the openai SDK (>= 1.0).

Wraps `Completions.create` and `AsyncCompletions.create` so that every chat
call is automatically captured as a child LLM span — no decorators required.

The patch is idempotent: calling patch_openai() twice is safe.
"""

from __future__ import annotations

import functools
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from oopstrace.client import OopstraceClient


def patch_openai(client: "OopstraceClient") -> None:
    """Monkey-patch openai SDK classes to emit LLM spans automatically."""
    try:
        from openai.resources.chat.completions import AsyncCompletions, Completions
    except ImportError:
        return

    if getattr(Completions, "_oopstrace_patched", False):
        return

    _orig_sync = Completions.create
    _orig_async = AsyncCompletions.create

    @functools.wraps(_orig_sync)
    def _sync_create(self_c, *args: Any, **kwargs: Any):
        model = kwargs.get("model") or ""
        messages = kwargs.get("messages") or []
        inp = (messages[-1].get("content") or "") if messages else ""

        with client.start_span("openai.chat", span_kind="LLM", input=inp, model_name=model) as s:
            result = _orig_sync(self_c, *args, **kwargs)
            if hasattr(result, "usage") and result.usage:
                s.input_tokens = result.usage.prompt_tokens
                s.output_tokens = result.usage.completion_tokens
            if hasattr(result, "choices") and result.choices:
                content = result.choices[0].message.content
                if content:
                    s.output = content
            return result

    @functools.wraps(_orig_async)
    async def _async_create(self_c, *args: Any, **kwargs: Any):
        model = kwargs.get("model") or ""
        messages = kwargs.get("messages") or []
        inp = (messages[-1].get("content") or "") if messages else ""

        with client.start_span("openai.chat", span_kind="LLM", input=inp, model_name=model) as s:
            result = await _orig_async(self_c, *args, **kwargs)
            if hasattr(result, "usage") and result.usage:
                s.input_tokens = result.usage.prompt_tokens
                s.output_tokens = result.usage.completion_tokens
            if hasattr(result, "choices") and result.choices:
                content = result.choices[0].message.content
                if content:
                    s.output = content
            return result

    Completions.create = _sync_create
    AsyncCompletions.create = _async_create
    Completions._oopstrace_patched = True
