"""Auto-instrumentation patch for the anthropic SDK.

Wraps `Messages.create` and `AsyncMessages.create` so that every Anthropic
call is automatically captured as a child LLM span — no decorators required.

The patch is idempotent: calling patch_anthropic() twice is safe.
"""

from __future__ import annotations

import functools
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from oopstrace.client import OopstraceClient


def _extract_last_user_text(messages: list[dict]) -> str:
    """Pull the text content out of the last user message."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        return block.get("text", "")
    return ""


def patch_anthropic(client: "OopstraceClient") -> None:
    """Monkey-patch anthropic SDK classes to emit LLM spans automatically."""
    try:
        from anthropic.resources.messages import AsyncMessages, Messages
    except ImportError:
        return

    if getattr(Messages, "_oopstrace_patched", False):
        return

    _orig_sync = Messages.create
    _orig_async = AsyncMessages.create

    @functools.wraps(_orig_sync)
    def _sync_create(self_m, *args: Any, **kwargs: Any):
        model = kwargs.get("model") or ""
        messages = kwargs.get("messages") or []
        inp = _extract_last_user_text(messages)

        with client.start_span("anthropic.messages", span_kind="LLM", input=inp, model_name=model) as s:
            result = _orig_sync(self_m, *args, **kwargs)
            if hasattr(result, "usage") and result.usage:
                s.input_tokens = result.usage.input_tokens
                s.output_tokens = result.usage.output_tokens
            if hasattr(result, "content") and result.content:
                first = result.content[0]
                if hasattr(first, "text"):
                    s.output = first.text
            return result

    @functools.wraps(_orig_async)
    async def _async_create(self_m, *args: Any, **kwargs: Any):
        model = kwargs.get("model") or ""
        messages = kwargs.get("messages") or []
        inp = _extract_last_user_text(messages)

        with client.start_span("anthropic.messages", span_kind="LLM", input=inp, model_name=model) as s:
            result = await _orig_async(self_m, *args, **kwargs)
            if hasattr(result, "usage") and result.usage:
                s.input_tokens = result.usage.input_tokens
                s.output_tokens = result.usage.output_tokens
            if hasattr(result, "content") and result.content:
                first = result.content[0]
                if hasattr(first, "text"):
                    s.output = first.text
            return result

    Messages.create = _sync_create
    AsyncMessages.create = _async_create
    Messages._oopstrace_patched = True
