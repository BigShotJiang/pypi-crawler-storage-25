"""Monkey-patching registry for auto-instrumentation.

Call apply_all(client) to patch every SDK that is installed.
Individual patch functions are safe to call when the target library is absent.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from oopstrace.client import OopstraceClient


def apply_all(client: "OopstraceClient") -> None:
    """Apply all available patches against *client*."""
    from oopstrace.patches._anthropic import patch_anthropic
    from oopstrace.patches._openai import patch_openai

    patch_openai(client)
    patch_anthropic(client)
