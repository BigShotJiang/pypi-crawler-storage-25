# OopsTrace Python SDK

LLM observability for Python. Trace every call, span, token count, and cost — visible instantly at [app.oopstrace.com](https://app.oopstrace.com).

## Install

```bash
pip install oopstrace
```

## Quickstart

```python
import oopstrace

oopstrace.init(
    api_key="tr_...",       # from app.oopstrace.com → project → Access Keys
    project_id="...",       # your project ID
)

@oopstrace.trace
def run_agent(user_input: str) -> str:
    with oopstrace.span("llm-call", span_kind="LLM") as s:
        s.set_output("Hello from OopsTrace")
        return "Hello from OopsTrace"

run_agent("test")
oopstrace.flush()
```

## Auto-instrument OpenAI / Anthropic

```python
oopstrace.init(api_key="tr_...", project_id="...", auto_instrument=True)

# All openai.chat.completions.create() and anthropic.messages.create()
# calls are now traced automatically — no decorators needed.
```

## Manual spans

```python
@oopstrace.trace
def pipeline(query: str):
    with oopstrace.span("retrieval", span_kind="TOOL") as s:
        docs = retrieve(query)
        s.set_input(query)
        s.set_output(str(docs))

    with oopstrace.span("generate", span_kind="LLM") as s:
        answer = llm(query, docs)
        s.set_model("gpt-4o")
        s.set_tokens(input=100, output=50)
        return answer
```

## Self-hosted

```python
oopstrace.init(
    api_key="tr_...",
    project_id="...",
    endpoint="https://app.yourdomain.com",  # point at your own server
)
```
