import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram

def calculate_euclidian(p1, p2):
    s = 0
    for i in range(len(p1)):
        s += (p1[i] - p2[i]) ** 2
    return s ** 0.5

def find_min(cluster, dis_mat):
    min_dist = float('inf')
    for i in range(len(cluster)):
        for j in range(i+1, len(cluster)):
            for p in cluster[i]:
                for q in cluster[j]:
                    d = dis_mat[p][q]
                    if d < min_dist:
                        min_dist = d
                        pos = (i, j)
    return pos, min_dist

def to_label(cluster):
    return ["C" + str(i+1) for i in cluster]

def merge_cluster(i, j, cluster):
    new_cluster = cluster[i] + cluster[j]
    if i < j:
        cluster.pop(j)
        cluster.pop(i)
    else:
        cluster.pop(i)
        cluster.pop(j)
    cluster.append(new_cluster)
    return cluster

if __name__ == "__main__":
    df=pd.read_csv("data.csv")
    df=df[:50]
    df.isnull().sum()
    df = df.drop("CustomerID",axis=1)
    print(df.head())
    df["Gender"] = df["Gender"].map({"Male": 0, "Female": 1})
    print(df.head())
    gender = df["Gender"].value_counts()
    print(gender)
    df["Age"]=df["Age"].fillna(df["Age"].mean())
    plt.figure()
    plt.pie(gender.values, labels=["Male","Female"], autopct="%1.1f%%")
    plt.title("Male vs Female Ratio")
    plt.legend()
    plt.show()
    x= np.arange(len(df))
    
    plt.figure(figsize=(20, 6))
    
    plt.bar(x - 0.2, df["Age"], width=0.4, label="Age")
    plt.bar(x + 0.2, df["Annual Income (k$)"], width=0.4, label="Income")
    
    plt.xlabel("Customers (Top 100)")
    plt.ylabel("Values")
    plt.title("Age vs Annual Income (Top 100)")
    plt.legend()
    
    plt.show()
    points = df.values
    print("Points:\n", points)
    n = len(points)
    dis_mat = np.zeros((n, n))
    
    for i in range(n):
        for j in range(n):
            dis_mat[i][j] = calculate_euclidian(points[i], points[j])
    
    print("\nDistance Matrix:\n", dis_mat)
    # -----------------------------------
    # Step 6: Initialize Clusters
    # -----------------------------------
    cluster = [[i] for i in range(n)]
    print("\nInitial Clusters:", cluster)
    
    # -----------------------------------
    # Step 10: Agglomerative Clustering
    # -----------------------------------
    step = 1
    while len(cluster) > 1:
        (i, j), min_dist = find_min(cluster, dis_mat)
        
        print(f"\nStep {step}:")
        print(f"Merging {to_label(cluster[i])} and {to_label(cluster[j])} at distance {round(min_dist,2)}")
        
        cluster = merge_cluster(i, j, cluster)
        
        print("Clusters now:", [to_label(c) for c in cluster])
        
        step += 1
    z = linkage(points, method='ward')
    plt.figure(figsize=(15, 10))
    dendrogram(z, labels=to_label(range(n)))
    plt.title("Dendrogram")
    plt.xlabel("Customers")
    plt.ylabel("Distance")
    plt.show()
    
    
    # +=======
    # Dbscan
    # =======
    
    
    from sklearn.cluster  import DBSCAN
    core_indices = db.core_sample_indices_
    print("\nCore Sample Indices:", core_indices)
    print("Core Points:")
    for i in core_indices:
        print(points[i])
    
    print("\nBorder Points:")
    for i in range(len(points)):
        if labels[i] != -1 and i not in core_set:
            print(points[i])
    
    print("\nNoise Points:")
    for i in range(len(points)):
        if labels[i] == -1:
            print(points[i])
    import matplotlib.pyplot as plt
    from sklearn.cluster import DBSCAN
    import numpy as np
    
    points = np.array([
        [1, 1], [1, 2], [2, 1], [2, 2], [2, 3], [3, 2], [3, 3],
        [4, 3],
        [8, 8], [8, 9], [9, 8], [9, 9], [10, 9],
        [11, 10],
        [15, 15], [16, 15], [15, 16], [16, 16], [17, 16],
        [30, 30], [50, 5], [60, 60], [0, 10]
    ])
    
    db = DBSCAN(eps=2, min_samples=3)
    labels = db.fit_predict(points)
    core_indices = db.core_sample_indices_
    plt.figure()
    
    # Plot each cluster separately
    for label in set(labels):
        x = []
        y = []
        
        for i in range(len(points)):
            if labels[i] == label:
                x.append(points[i][0])
                y.append(points[i][1])
        
        if label == -1:
            plt.scatter(x, y, marker='x', label='Noise')
        else:
            plt.scatter(x, y, label=f'Cluster {label}')
    
    plt.legend()
    plt.title("Clusters Differentiated")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.show()
    
    data = df[["Milk", "Grocery"]]
    
    # Convert to numpy
    points = data.values
    mean = np.mean(points, axis=0)
    std = np.std(points, axis=0)
    
    norm_points = (points - mean) / std
    
    print("\nNormalized Data (first 5):")
    print(norm_points[:5])
    import matplotlib.pyplot as plt
    
    plt.figure()
    plt.scatter(norm_points[:, 0], norm_points[:, 1])
    plt.xlabel("Milk (normalized)")
    plt.ylabel("Grocery (normalized)")
    plt.title("Normalized Data")
    plt.show()