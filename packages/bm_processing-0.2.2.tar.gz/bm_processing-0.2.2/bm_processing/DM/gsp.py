import re
from collections import defaultdict
from itertools import product


def read_para(file):
    MIS = {}
    SDC = 0
    with open(file, 'r') as f:
        for line in f:
            if "MIS" in line:
                item = int(re.findall(r'\((\d+)\)', line)[0])
                val = float(line.split('=')[1])
                MIS[item] = val
            if "SDC" in line:
                SDC = float(line.split('=')[1])
    return MIS, SDC

def read_data(file):
    sequences = []
    with open(file, 'r') as f:
        for line in f:
            line = line.strip()
            sets = re.findall(r'\{([^}]*)\}', line)
            seq = []
            for s in sets:
                items = list(map(int, s.split(',')))
                seq.append(sorted(items))
            sequences.append(seq)
    return sequences

if __name__ == "__main__":
    data = [
        [[30], [30, 70, 80]],
        [[40, 50], [40, 90]],
        [[30], [70, 80], [20, 30, 70]],
        [[40, 50], [40, 90]],
        [[40, 50], [70, 90]],
        [[30], [70, 80], [20, 30, 70]],
        [[40], [40]],
        [[40, 50], [40, 90]],
        [[30], [30, 70, 80]],
        [[40], [40]],
    ]
    
    MIS = {10:0.6, 30:0.2, 40:0.3, 50:0.3, 70:0.2, 80:0.2, 90:0.2, 20:0.2}
    SDC = 0.2
    
    # -------------------------------
    # ITEM SUPPORT
    # -------------------------------
    def get_support(data):
        count = {}
        for seq in data:
            items = set()
            for s in seq:
                items.update(s)
            for i in items:
                count[i] = count.get(i, 0) + 1
    
        total = len(data)
        return {i: count[i]/total for i in count}
    
    support = get_support(data)
    
    # -------------------------------
    # SUBSEQUENCE CHECK
    # -------------------------------
    def is_subsequence(cand, seq):
        i = 0
        for s in seq:
            if set(cand[i]).issubset(set(s)):
                i += 1
                if i == len(cand):
                    return True
        return False
    
    # -------------------------------
    # MIN MIS
    # -------------------------------
    def min_mis(cand):
        items = []
        for sub in cand:
            for i in sub:
                items.append(i)
    
        min_val = float('inf')
        for i in items:
            if MIS.get(i, 0) < min_val:
                min_val = MIS.get(i, 0)
    
        return min_val
    
    # -------------------------------
    # SDC CHECK
    # -------------------------------
    def check_sdc(cand):
        items = []
        for sub in cand:
            for i in sub:
                items.append(i)
    
        n = len(items)
    
        for i in range(n):
            for j in range(i+1, n):
                diff = abs(support[items[i]] - support[items[j]])
                if diff > SDC:
                    return False
    
        return True
    
    
    # -------------------------------
    # L1
    # -------------------------------
    L = []
    
    L1 = []
    for i in support:
        if support[i] >= MIS.get(i, 0):
            L1.append([[i]])
    
    L.append(L1)
    
    # -------------------------------
    # GENERATE L2, L3
    # -------------------------------
    k = 0
    while k < 2:   # till L3
        next_L = []
    
        for a, b in product(L[k], repeat=2):
    
            # 1. sequence join
            c1 = a + [b[-1]]
    
            # 2. same itemset join
            c2 = a[:-1] + [sorted(list(set(a[-1] + b[-1])))]
    
            for cand in [c1, c2]:
    
                count = 0
                for seq in data:
                    if is_subsequence(cand, seq):
                        count += 1
    
                sup = count / len(data)
    
                if sup >= min_mis(cand) and check_sdc(cand):
                    if cand not in next_L:
                        next_L.append(cand)
    
        if not next_L:
            break
    
        L.append(next_L)
        k += 1
    
    # -------------------------------
    # OUTPUT
    # -------------------------------
    for i in range(len(L)):
        print(f"\nL{i+1}:")
        for seq in L[i]:
            print(seq)