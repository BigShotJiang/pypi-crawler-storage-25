from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
import json
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from packages.contracts.runtime import (
    EventEnvelope,
    ExecutionResult,
    ExperienceRecord,
    GoalNode,
    IntentCandidateScore,
    IntentDecision,
    IntentReason,
    MemoryRecord,
    PlanDraft,
    ProfileGrowthState,
    ProfileState,
    SessionState,
)
from packages.experience import capture_turn_experience
from packages.growth import GrowthTurnSignals, apply_turn_growth
from packages.kernel import KernelOutcome

if TYPE_CHECKING:
    from apps.cli.runtime import CliRuntime


def load_snapshot(runtime: CliRuntime) -> dict[str, Any] | None:
    if not runtime.snapshot_path.exists():
        return None
    return json.loads(runtime.snapshot_path.read_text(encoding="utf-8"))


def load_snapshot_intent(runtime: CliRuntime, *, session_id: str | None = None) -> IntentDecision | None:
    snapshot = load_snapshot(runtime)
    return restore_snapshot_intent(snapshot, session_id=session_id)


def restore_snapshot_intent(
    snapshot: Mapping[str, Any] | None,
    *,
    session_id: str | None = None,
) -> IntentDecision | None:
    if not snapshot:
        return None
    if session_id is not None:
        session = snapshot.get("session")
        if not isinstance(session, Mapping) or str(session.get("session_id") or "") != session_id:
            return None
    payload = snapshot.get("intent")
    if not isinstance(payload, Mapping):
        return None
    reasons = tuple(_restore_intent_reason(reason) for reason in payload.get("reasons", ()) if isinstance(reason, Mapping))
    candidate_scores = tuple(
        _restore_intent_candidate_score(score)
        for score in payload.get("candidate_scores", ())
        if isinstance(score, Mapping)
    )
    return IntentDecision(
        intent=str(payload.get("intent") or "").strip(),
        confidence=float(payload.get("confidence") or 0.0),
        focus_activity_ids=_as_str_tuple(payload.get("focus_activity_ids")),
        provisional_activity_seed=_optional_str(payload.get("provisional_activity_seed")),
        resume_signal=str(payload.get("resume_signal") or "none"),
        scope_suggestion=str(payload.get("scope_suggestion") or "session"),
        budget_class=str(payload.get("budget_class") or "standard"),
        embedding_available=bool(payload.get("embedding_available", False)),
        degradation_mode=str(payload.get("degradation_mode") or "none"),
        needs_weak_model_assist=bool(payload.get("needs_weak_model_assist", False)),
        weak_assist_outcome=str(payload.get("weak_assist_outcome") or "not-requested"),
        fallback_path=str(payload.get("fallback_path") or "direct"),
        reasons=reasons,
        candidate_scores=candidate_scores,
        audit_trace=_as_str_tuple(payload.get("audit_trace")),
    )


def append_outcome_memory(runtime: CliRuntime, outcome: KernelOutcome) -> None:
    goal_ids: tuple[str, ...] = ()
    tags: tuple[str, ...] = ("continuity", "assistant")
    content = outcome.execution.summary.strip()
    if outcome.decision is not None:
        selected_goal_id = outcome.decision.selected_move.goal_id
        if selected_goal_id:
            goal_ids = (selected_goal_id,)
        tags = tags + (outcome.decision.selected_move.kind,)
        rationale = outcome.decision.rationale.summary.strip()
        if rationale and rationale not in content:
            content = f"{rationale}\n{content}" if content else rationale
    elif outcome.plan is not None and outcome.plan.goal_id:
        goal_ids = (outcome.plan.goal_id,)
    if not content:
        return
    event = EventEnvelope(
        event_id=f"event:{uuid4().hex}",
        event_type="decision",
        session_id=outcome.session.session_id,
        source="cli",
        payload={
            "content": content,
            "summary": content.splitlines()[0],
            "memory_kind": "decision",
            "goal_ids": ",".join(goal_ids),
            "tags": ",".join(tags),
            "source_event_id": outcome.event.event_id,
        },
    )
    runtime.memory_runtime.append_event(event)


def append_outcome_experience(runtime: CliRuntime, outcome: KernelOutcome) -> ExperienceRecord | None:
    execution = outcome.execution
    if execution is None:
        return None
    goal_id: str | None = None
    if outcome.decision is not None:
        goal_id = outcome.decision.selected_move.goal_id
    elif outcome.plan is not None and outcome.plan.goal_id:
        goal_id = outcome.plan.goal_id
    active_skills = runtime.skill_runtime.resolve_for_context(
        profile_id=outcome.session.profile_id,
        workspace_id=outcome.session.workspace_id,
        session_id=outcome.session.session_id,
        mode=outcome.profile.mode,
    )
    extra_tags: list[str] = [f"outcome:{execution.outcome}"]
    if outcome.decision is not None:
        extra_tags.append(f"decision:{outcome.decision.selected_move.kind}")
    record = capture_turn_experience(
        session_id=outcome.session.session_id,
        profile_id=outcome.session.profile_id,
        workspace_id=outcome.session.workspace_id,
        summary=execution.summary,
        source_event_id=outcome.event.event_id,
        run_id=outcome.run.run_id if outcome.run is not None else None,
        goal_id=goal_id,
        tool_call_count=outcome.run.tool_call_count if outcome.run is not None else 0,
        model_turn_count=outcome.run.model_turn_count if outcome.run is not None else 0,
        related_skill_ids=tuple(skill.skill_id for skill in active_skills),
        produced_artifact_ids=execution.produced_artifact_ids,
        tags=tuple(extra_tags),
    )
    if record is None:
        return None
    runtime.repository.upsert_experience(record)
    return record


def append_outcome_growth(
    runtime: CliRuntime,
    outcome: KernelOutcome,
    *,
    experience: ExperienceRecord | None,
) -> ProfileGrowthState:
    profile_id = outcome.session.profile_id
    current = runtime.repository.load_profile_growth(profile_id)
    update = apply_turn_growth(
        current,
        GrowthTurnSignals(
            session_id=outcome.session.session_id,
            profile_id=profile_id,
            total_tokens=outcome.execution.total_tokens,
            captured_experiences=1 if experience is not None else 0,
            continuity_bonus=outcome.continuity.requires_recovery,
        ),
    )
    runtime.repository.upsert_profile_growth(update.after.state)
    runtime.growth_updates[outcome.session.session_id] = update
    return update.after.state


def write_snapshot(
    runtime: CliRuntime,
    *,
    profile: ProfileState,
    session: SessionState,
    goals: tuple[GoalNode, ...],
    memories: tuple[MemoryRecord, ...],
    plan: PlanDraft | None,
    execution: ExecutionResult | None,
    delivery: ExecutionResult | None,
    stages: tuple[Any, ...],
    event: EventEnvelope | None,
    clone_text: str | None,
    intent: IntentDecision | None,
) -> None:
    existing = load_snapshot(runtime) or {}
    payload = {
        "profile": _profile_payload(profile, clone_text=clone_text),
        "session": _session_payload(session),
        "goals": [_goal_payload(goal) for goal in goals],
        "memories": [_memory_payload(memory) for memory in memories],
        "plan": _plan_payload(plan),
        "execution": _execution_payload(execution),
        "delivery": _execution_payload(delivery),
        "stages": [_stage_payload(stage) for stage in stages],
        "event": _event_payload(event),
        "intent": _intent_payload(intent),
        "telemetry": existing.get("telemetry", ()),
    }
    runtime.snapshot_path.parent.mkdir(parents=True, exist_ok=True)
    runtime.snapshot_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _profile_payload(profile: ProfileState, *, clone_text: str | None) -> dict[str, Any]:
    return {
        "profile_id": profile.profile_id,
        "display_name": profile.display_name,
        "mode": profile.mode,
        "clone_path": profile.clone_path,
        "preferences": list(profile.preferences),
        "enabled_capabilities": list(profile.enabled_capabilities),
        "clone_text": clone_text,
    }


def _session_payload(session: SessionState) -> dict[str, Any]:
    return {
        "session_id": session.session_id,
        "profile_id": session.profile_id,
        "workspace_id": session.workspace_id,
        "status": session.status,
        "started_at": _iso(session.started_at),
        "updated_at": _iso(session.updated_at),
        "parent_session_id": session.parent_session_id,
        "interruption_state": session.interruption_state,
    }


def _goal_payload(goal: GoalNode) -> dict[str, Any]:
    return {
        "goal_id": goal.goal_id,
        "session_id": goal.session_id,
        "title": goal.title,
        "status": goal.status,
        "priority": goal.priority,
        "dependencies": list(goal.dependencies),
        "evidence_refs": list(goal.evidence_refs),
        "owner": goal.owner,
        "parent_goal_id": goal.parent_goal_id,
        "related_memory_ids": list(goal.related_memory_ids),
        "deadline": _iso(goal.deadline) if goal.deadline is not None else None,
        "time_sensitivity": goal.time_sensitivity,
        "review_checkpoint": goal.review_checkpoint,
        "revision_id": goal.revision_id,
        "updated_at": _iso(goal.updated_at) if goal.updated_at is not None else None,
    }


def _memory_payload(memory: MemoryRecord) -> dict[str, Any]:
    return {
        "memory_id": memory.memory_id,
        "session_id": memory.session_id,
        "kind": memory.kind,
        "content": memory.content,
        "source_event_id": memory.source_event_id,
        "goal_refs": list(memory.goal_refs),
        "tags": list(memory.tags),
        "created_at": _iso(memory.created_at) if memory.created_at is not None else None,
    }


def _plan_payload(plan: PlanDraft | None) -> dict[str, Any] | None:
    if plan is None:
        return None
    return {
        "plan_id": plan.plan_id,
        "goal_id": plan.goal_id,
        "session_id": plan.session_id,
        "steps": [
            {
                "step_id": step.step_id,
                "title": step.title,
                "rationale": step.rationale,
                "dependency_refs": list(step.dependency_refs),
            }
            for step in plan.steps
        ],
        "rationale": plan.rationale,
    }


def _execution_payload(execution: ExecutionResult | None) -> dict[str, Any] | None:
    if execution is None:
        return None
    return {
        "execution_id": execution.execution_id,
        "session_id": execution.session_id,
        "outcome": execution.outcome,
        "summary": execution.summary,
        "prompt_tokens": execution.prompt_tokens,
        "completion_tokens": execution.completion_tokens,
        "total_tokens": execution.total_tokens,
        "produced_artifact_ids": list(execution.produced_artifact_ids),
        "telemetry_event_ids": list(execution.telemetry_event_ids),
        "side_effects": list(execution.side_effects),
    }


def _intent_payload(intent: IntentDecision | None) -> dict[str, Any] | None:
    if intent is None:
        return None
    return {
        "intent": intent.intent,
        "confidence": intent.confidence,
        "focus_activity_ids": list(intent.focus_activity_ids),
        "provisional_activity_seed": intent.provisional_activity_seed,
        "resume_signal": intent.resume_signal,
        "scope_suggestion": intent.scope_suggestion,
        "budget_class": intent.budget_class,
        "embedding_available": intent.embedding_available,
        "degradation_mode": intent.degradation_mode,
        "needs_weak_model_assist": intent.needs_weak_model_assist,
        "weak_assist_outcome": intent.weak_assist_outcome,
        "fallback_path": intent.fallback_path,
        "reasons": [_intent_reason_payload(reason) for reason in intent.reasons],
        "candidate_scores": [_intent_candidate_score_payload(score) for score in intent.candidate_scores],
        "audit_trace": list(intent.audit_trace),
    }


def _intent_reason_payload(reason: IntentReason) -> dict[str, Any]:
    return {
        "code": reason.code,
        "detail": reason.detail,
        "weight": reason.weight,
    }


def _intent_candidate_score_payload(score: IntentCandidateScore) -> dict[str, Any]:
    return {
        "candidate_id": score.candidate_id,
        "kind": score.kind,
        "label": score.label,
        "total_score": score.total_score,
        "heuristics_score": score.heuristics_score,
        "embedding_score": score.embedding_score,
        "reasons": [_intent_reason_payload(reason) for reason in score.reasons],
        "metadata": dict(score.metadata),
    }


def _stage_payload(stage: Any) -> Any:
    return {
        "stage": stage.stage,
        "detail": stage.detail,
        "recorded_at": _iso(stage.recorded_at),
    }


def _restore_intent_reason(payload: Mapping[str, Any]) -> IntentReason:
    return IntentReason(
        code=str(payload.get("code") or "").strip(),
        detail=str(payload.get("detail") or "").strip(),
        weight=float(payload.get("weight") or 0.0),
    )


def _restore_intent_candidate_score(payload: Mapping[str, Any]) -> IntentCandidateScore:
    return IntentCandidateScore(
        candidate_id=str(payload.get("candidate_id") or "").strip(),
        kind=str(payload.get("kind") or "").strip(),
        label=str(payload.get("label") or "").strip(),
        total_score=float(payload.get("total_score") or 0.0),
        heuristics_score=float(payload.get("heuristics_score") or 0.0),
        embedding_score=float(payload.get("embedding_score") or 0.0),
        reasons=tuple(
            _restore_intent_reason(reason)
            for reason in payload.get("reasons", ())
            if isinstance(reason, Mapping)
        ),
        metadata={
            str(key): str(value)
            for key, value in dict(payload.get("metadata") or {}).items()
        },
    )


def _as_str_tuple(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value,) if value else ()
    return tuple(str(item) for item in value if str(item))


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _event_payload(event: EventEnvelope | None) -> dict[str, Any] | None:
    if event is None:
        return None
    return {
        "event_id": event.event_id,
        "event_type": event.event_type,
        "session_id": event.session_id,
        "source": event.source,
        "payload": dict(event.payload),
    }


def _iso(value: datetime) -> str:
    return value.isoformat()
