import logging
from collections import defaultdict
from typing import Optional

import numpy as np

from geneml.gene_caller import get_gene_ml_events, produce_gene_calls, score_gene_call
from geneml.model_loader import ResidualModelBase
from geneml.params import Params
from geneml.types import CDS_END, CDS_START, EXON_END, EXON_START, Exon, Gene, GeneEvent, Transcript

logger = logging.getLogger("geneml")


def run_model(model: ResidualModelBase, seq: str, context_length, chunk_size=100000) -> np.ndarray:
    """Predict model scores for a sequence in memory-safe chunks.

    Args:
        model: Loaded model wrapper used for inference.
        seq: DNA sequence to score.
        context_length: Model context window length.
        chunk_size: Maximum chunk size processed per inference call.

    Returns:
        Concatenated score matrix with shape (num_features, sequence_length).
    """
    seq_len = len(seq)
    pred_list = []
    padding = context_length // 2
    for i in range(0, seq_len, chunk_size):
        start = i
        end = min(seq_len, i + chunk_size)
        padded_start = max(0, start - padding)
        padded_end = min(seq_len, end + padding)
        preds = model.predict(seq[padded_start:padded_end], return_dict=False)
        pred_list.append(preds[:, (start-padded_start):(end-padded_start)])
    return np.concatenate(pred_list, axis=1)


def create_exons(gene_events: list[GeneEvent], preds: np.ndarray,
                 contig_length: int, is_rc: bool) -> list[Exon]:
    """Convert ordered gene events into Exon objects with phase metadata.

    Args:
        gene_events: Ordered start/end events defining exon boundaries.
        preds: Model score matrix used for exon scoring.
        contig_length: Length of the contig sequence.
        is_rc: Whether the events come from reverse-complement predictions.

    Returns:
        List of Exon objects in transcript order.
    """
    if not gene_events:
        return []
    assert len(gene_events) % 2 == 0, f'There should be an even number of gene events: {gene_events}'
    exons = []
    frame = 0  # Tracks the reading frame position at the end of the previous exon
    for event, next_event in zip(gene_events[::2], gene_events[1::2]):
        if not (event.type in (CDS_START, EXON_START) and next_event.type in (CDS_END, EXON_END)):
            raise ValueError(f'Invalid gene events pair (expected start event and end event): {event}, {next_event}')
        if is_rc:
            start_pos = contig_length - next_event.pos - 1
            end_pos = contig_length - event.pos - 1
        else:
            start_pos = event.pos
            end_pos = next_event.pos

        # Phase indicates how many bases from the previous exon are needed to complete a codon
        phase = (3 - frame) % 3

        exon = Exon(
            start=start_pos,
            end=end_pos + 1,  # end is exclusive
            events=(event, next_event),
            score=score_gene_call(preds, [event, next_event]),
            phase=phase,
        )
        exons.append(exon)
        exon_length = exon.end - exon.start
        frame = (frame + exon_length) % 3
    return exons


def create_transcripts(scored_gene_calls: list[tuple[int, float, list[GeneEvent]]],
                       preds: np.ndarray, contig_length: int, is_rc: bool) -> list[Transcript]:
    """Create Transcript objects from scored gene-call event chains.

    Args:
        scored_gene_calls: Tuples of group ID, score, and event chain.
        preds: Model score matrix used for exon scoring.
        contig_length: Length of the contig sequence.
        is_rc: Whether calls originate from reverse-complement predictions.

    Returns:
        List of Transcript objects.
    """
    transcripts = []
    strand = -1 if is_rc else 1
    for group_id, score, gene_events in scored_gene_calls:
        if is_rc:
            start_pos = contig_length - gene_events[-1].pos - 1
            end_pos = contig_length - gene_events[0].pos - 1
        else:
            start_pos = gene_events[0].pos
            end_pos = gene_events[-1].pos
        transcript = Transcript(
            start=start_pos,
            end=end_pos + 1,    #end is exclusive
            strand=strand,
            events=tuple(gene_events),
            score=score,
            exons=tuple(create_exons(gene_events, preds, contig_length, is_rc)),
            group_id=group_id,
        )
        transcripts.append(transcript)
    return transcripts


def filter_overlapping_transcripts(transcripts: list[Transcript]) -> list[Transcript]:
    """Filter opposite-strand overlaps by retaining the higher-scoring transcript.

    Args:
        transcripts: Transcript candidates to evaluate.

    Returns:
        Filtered transcript list.
    """

    if not transcripts:
        return []

    sorted_transcripts = sorted(transcripts, key=lambda x: (x.start, x.end))

    non_overlapping = [sorted_transcripts[0]]
    for t in sorted_transcripts[1:]:
        if (t.strand != non_overlapping[-1].strand and
            non_overlapping[-1].overlaps_with(t, ignore_strand=True) and
            t.score > non_overlapping[-1].score):
            non_overlapping[-1] = t
            continue
        non_overlapping.append(t)

    return non_overlapping


def build_transcripts(preds: Optional[np.ndarray], rc_preds: Optional[np.ndarray],
                     seq: str, rc_seq: Optional[str], contig_id: str, params: Params) -> list[Transcript]:
    """Build transcript candidates from forward and reverse model predictions.

    Build gene calls from a sequence using the GeneML model. Note that the coordinates in filtered_scored_gene_calls are
    relative to the sequence and the strand, so they are not absolute coordinates in the genome or even of the input
    sequence. See build_coords for converting to genomic absolute coordinates.

    Args:
        preds: Forward-strand model scores, or None.
        rc_preds: Reverse-strand model scores, or None.
        seq: Forward-strand DNA sequence.
        rc_seq: Reverse-complement sequence when available.
        contig_id: Contig identifier for logging.
        params: Runtime parameters.

    Returns:
        List of predicted transcripts.
    """
    if preds is None and rc_preds is None:
        raise ValueError("Cannot build gene calls without any model predictions.")

    scored_gene_calls = None
    rc_scored_gene_calls = None
    transcripts = []
    seq_length = len(seq)
    if preds is not None:
        logger.info('%s 3/5: Building gene calls on forward strand', contig_id)
        events = get_gene_ml_events(preds, params)
        scored_gene_calls = produce_gene_calls(preds, events, seq, contig_id + ' forward strand', params)
        if scored_gene_calls:
            transcripts.extend(create_transcripts(scored_gene_calls, preds, seq_length, is_rc=False))

    if rc_preds is not None:
        logger.info('%s 4/5: Building gene calls on reverse strand', contig_id)
        rc_events = get_gene_ml_events(rc_preds, params)
        rc_scored_gene_calls = produce_gene_calls(rc_preds, rc_events, rc_seq, contig_id + ' reverse strand', params)
        if rc_scored_gene_calls:
            transcripts.extend(create_transcripts(rc_scored_gene_calls, rc_preds, seq_length, is_rc=True))

    logger.info('%s 5/5: Selecting best gene calls', contig_id)

    if not params.allow_opposite_strand_overlaps:
        transcripts = filter_overlapping_transcripts(transcripts)

    return transcripts


def collect_max_scores(transcripts_by_contig_id: dict[str, list[Transcript]]
                           ) -> list[float]:
    """Collect representative scores from all gene loci.

    For each locus (defined by contig, strand, and group_id), only the maximum
    transcript score is included. This prevents bias from loci with multiple
    isoforms artificially inflating the high-confidence peak.

    Args:
        transcripts_by_contig_id: Dictionary mapping contig IDs to lists of Transcript objects

    Returns:
        List of maximum scores, one per gene locus
    """
    # Group transcripts by locus (contig, strand, group_id)
    locus_scores = defaultdict(list)
    for contig_id, transcripts in transcripts_by_contig_id.items():
        for t in transcripts:
            key = (contig_id, t.strand, t.group_id)
            locus_scores[key].append(t.score)

    # Take max score per locus
    all_scores = [max(scores) for scores in locus_scores.values()]
    return all_scores


def build_histogram(scores: np.ndarray, num_bins: int, smoothing_window: int
                    ) -> tuple[np.ndarray, np.ndarray]:
    """Build a histogram of transcript scores.

    Args:
        scores: 1D numpy array of transcript scores
        num_bins: Number of bins to use for the histogram
        smoothing_window: Window size for smoothing the histogram

    Returns:
        hist: Counts for each bin
        bin_centers: Centers of the bins
    """
    hist, bin_edges = np.histogram(scores, bins=num_bins, range=(0, 1))
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

    # Smooth the histogram with a rolling average to reduce noise
    window_size = smoothing_window
    smoothed_hist = np.convolve(hist, np.ones(window_size)/window_size, mode='same')

    return smoothed_hist, bin_centers


def get_dynamic_threshold(transcripts_by_contig_id: dict[str, list[Transcript]],
                          fallback_threshold: float, min_threshold: float = 0.2,
                          max_threshold: float = 0.8) -> float:
    """Determine a dynamic minimum gene score threshold based on the distribution of transcript
    scores across all contigs.

    Finds the deepest valley between two peaks in a bimodal score distribution. The distribution
    is expected to have two major peaks (low-confidence and high-confidence predictions), and this
    function identifies the threshold at the deepest valley between them, constrained to the
    [min_threshold, max_threshold] range.

    Args:
        transcripts_by_contig_id: Dictionary mapping contig IDs to lists of Transcript objects
        fallback_threshold: Threshold to use if dynamic calculation is not possible
        min_threshold: Minimum allowed threshold value (default: 0.2)
        max_threshold: Maximum allowed threshold value (default: 0.8)

    Returns:
        Float threshold value representing the score at the deepest valley within
        [min_threshold, max_threshold]. Falls back to fallback_threshold if insufficient
        data or no valid valley is found in the allowed range.
    """
    # Collect all transcript scores
    assert min_threshold < max_threshold, "min_threshold must be less than max_threshold"

    all_scores = collect_max_scores(transcripts_by_contig_id)
    num_scores = len(all_scores)
    if num_scores < 100:
        logger.warning(
            'Insufficient gene loci (%d) for dynamic scoring, using fallback threshold of %.1f',
            num_scores, fallback_threshold
        )
        return fallback_threshold

    # Set number of bins using square-root rule, capped between 10 and 150
    num_bins = min(150, max(10, int(np.sqrt(num_scores))))

    # Set smoothing window adaptively: use ~20% of bins, capped between 5 and 30
    smoothing_window = min(30, max(5, int(num_bins * 0.2)))

    # Create histogram to smooth the distribution
    scores_array = np.array(all_scores)
    smoothed_hist, bin_centers = build_histogram(scores_array, num_bins=num_bins,
                                                 smoothing_window=smoothing_window)

    # Find local minima (valleys) and maxima (peaks).
    # Use the sign of the first derivative, but ignore flat runs so that
    # plateau-shaped extrema are still detected. If a flat valley exists,
    # choose its midpoint.
    diff = np.diff(smoothed_hist)
    trend = np.sign(diff)
    nonzero_trend_indices = np.flatnonzero(trend)

    minima_indices: list[int] = []
    maxima_indices: list[int] = []
    if len(nonzero_trend_indices) >= 2:
        compressed_trend = trend[nonzero_trend_indices]
        for i in range(len(compressed_trend) - 1):
            left_sign = compressed_trend[i]
            right_sign = compressed_trend[i + 1]
            left_idx = nonzero_trend_indices[i]
            right_idx = nonzero_trend_indices[i + 1]

            if left_sign < 0 and right_sign > 0:
                valley_start = left_idx + 1
                valley_end = right_idx + 1
                extrema_idx = (valley_start + valley_end - 1) // 2
                minima_indices.append(extrema_idx)
            elif left_sign > 0 and right_sign < 0:
                peak_start = left_idx + 1
                peak_end = right_idx + 1
                extrema_idx = (peak_start + peak_end - 1) // 2
                maxima_indices.append(extrema_idx)

    if len(maxima_indices) < 2 or len(minima_indices) == 0:
        logger.warning(
            'No clear multimodal distribution found (peaks: %d, valleys: %d), '
            'using fallback threshold of %.1f',
            len(maxima_indices), len(minima_indices), fallback_threshold
        )
        return fallback_threshold

    # Select the two most prominent peaks (highest smoothed density).
    # Candidate valleys must lie between these peaks.
    top_peak_indices = sorted(maxima_indices, key=lambda idx: smoothed_hist[idx], reverse=True)[:2]
    left_peak_idx, right_peak_idx = sorted(top_peak_indices)

    # For each minimum, check if it's between the two most prominent peaks
    # AND within the allowed threshold range.
    valid_minima = []
    for minimum_idx in minima_indices:
        threshold_value = bin_centers[minimum_idx]

        # Skip minima outside the allowed range
        if threshold_value < min_threshold or threshold_value > max_threshold:
            continue

        if left_peak_idx < minimum_idx < right_peak_idx:
            valid_minima.append(minimum_idx)

    if len(valid_minima) == 0:
        logger.warning(
            'No local minimum found between the two most prominent peaks in range [%.2f, %.2f], '
            'using fallback threshold of %.1f',
            min_threshold, max_threshold, fallback_threshold
        )
        return fallback_threshold

    # Find the lowest valid minimum
    minimum_depths = smoothed_hist[valid_minima]
    lowest_minimum_idx = valid_minima[np.argmin(minimum_depths)]

    threshold = round(bin_centers[lowest_minimum_idx], 2)

    logger.info(
        'Dynamic threshold calculated: %.2f (based on %d gene loci)',
        threshold, len(all_scores)
    )

    return float(threshold)


def filter_by_dynamic_threshold(transcripts_by_contig_id: dict[str, list[Transcript]],
                                fallback_threshold: float) -> dict[str, list[Transcript]]:
    """Filter transcripts by a dynamically determined score threshold.

    Args:
        transcripts_by_contig_id: Dictionary mapping contig IDs to lists of Transcript objects
        fallback_threshold: Threshold to use if dynamic calculation is not possible

    Returns:
        Dictionary mapping contig IDs to lists of Transcript objects that pass the dynamic threshold
    """
    threshold = get_dynamic_threshold(transcripts_by_contig_id, fallback_threshold)

    filtered_transcripts_by_contig_id = {}
    for contig_id, transcripts in transcripts_by_contig_id.items():
        filtered_transcripts = [t for t in transcripts if t.score >= threshold]
        filtered_transcripts_by_contig_id[contig_id] = filtered_transcripts

    return filtered_transcripts_by_contig_id


def assign_transcripts_to_genes(transcripts_by_contig_id: dict[str, list[Transcript]],
                                gene_id_prefix: str | None) -> tuple[dict[str, list[Gene]], float | None]:
    """Assign transcripts to genes and generate unique gene identifiers.

    Groups transcripts into gene loci based on the group_id assigned during gene calling.
    Transcripts sharing the same contig, strand, and group_id are considered alternative
    isoforms of the same gene. Within each provisional locus, transcripts are sorted so the
    primary transcript is first (longest CDS, then highest score), and transcripts that do not
    overlap the current primary are split into separate loci. Each gene is assigned a unique
    sequential identifier in the format 'GML######'. Optionally, a user-provided prefix can be
    prepended to the gene ID.

    Args:
        transcripts_by_contig_id: Dictionary mapping contig IDs to lists of Transcript objects
        gene_id_prefix: Prefix for gene identifiers

    Returns:
        Tuple containing:
        - Dictionary mapping contig IDs to lists of Gene objects, where each Gene contains
          one or more alternative transcript isoforms
        - Average score across all predicted genes, or None if no genes were predicted
    """
    genes_by_contig = defaultdict(list)
    gene_count = 0
    transcript_count = 0
    gene_score_sum = 0.0

    def cds_length(transcript: Transcript) -> int:
        """Return CDS length in nucleotides for one transcript."""
        return sum(exon.end - exon.start for exon in transcript.exons)

    for contig_id, transcripts in transcripts_by_contig_id.items():
        if not transcripts:
            continue

        transcript_count += len(transcripts)

        # Group by (strand, group_id) to create genes
        gene_groups = defaultdict(list)
        for t in transcripts:
            key = (t.strand, t.group_id)
            gene_groups[key].append(t)

        # Sort groups by genomic start position
        sorted_groups = sorted(gene_groups.items(), key=lambda x: min(t.start for t in x[1]))

        # Create Gene objects
        for _, group in sorted_groups:
            # Ensure primary is first by sorting transcripts by CDS length (desc),
            # then by score (desc), then genomic coordinates for stable tie-breaking.
            ordered_group = sorted(group, key=lambda t: (-cds_length(t), -t.score, t.start, t.end))

            # If transcripts within one (strand, group_id) do not overlap with the
            # locus primary, split them into separate loci.
            split_loci: list[list[Transcript]] = []
            for transcript in ordered_group:
                assigned = False
                for locus in split_loci:
                    primary = locus[0]
                    if transcript.overlaps_with(primary):
                        locus.append(transcript)
                        assigned = True
                        break
                if not assigned:
                    split_loci.append([transcript])

            split_loci.sort(key=lambda locus: min(t.start for t in locus))

            for locus in split_loci:
                gene_count += 1
                if gene_count == 1_000_000:
                    logger.warning('Reached 1 million predicted genes, '
                                   'will produce gene IDs with more than 6 digits.')
                if gene_id_prefix:
                    gene_id = f'{gene_id_prefix}_GML{gene_count:06d}'
                else:
                    gene_id = f'GML{gene_count:06d}'
                gene = Gene(
                    gene_id=gene_id,
                    start=min(t.start for t in locus),
                    end=max(t.end for t in locus),
                    strand=locus[0].strand,
                    transcripts=tuple(locus),
                    score=max(t.score for t in locus),
                )
                gene_score_sum += gene.score
                genes_by_contig[contig_id].append(gene)

    logger.info('Total predicted transcripts: %d', transcript_count)
    logger.info('Total predicted genes: %d (%.2f transcripts per gene)',
                gene_count, transcript_count / gene_count if gene_count > 0 else 0)

    mean_gene_score = gene_score_sum / gene_count if gene_count > 0 else None
    logger.info('Average gene score: %.3f', mean_gene_score if mean_gene_score is not None else 0.0)

    return genes_by_contig, mean_gene_score
