import gzip
import os
import sys

UPSTREAM_FLANK_SIZE = 1000
DOWNSTREAM_FLANK_SIZE = 500
MIN_FLANK_SIZE = 200

genome_id = sys.argv[1]
path = sys.argv[2]
data_dir = sys.argv[3]

if len(sys.argv) > 4:
    allowed_genes = set()
    with open(sys.argv[4]) as f:
        for line in f:
            if line.startswith('#'):
                continue
            cols = line.strip().split('\t')
            allowed_genes.add(cols[0].replace('"', ''))
else:
    allowed_genes = None

data = {}
inferred_contig_sizes = {}
extents_by_cs = {}
mitochondrial_contigs = set()

# First pass: identify mitochondrial contigs from region features
with open(path) if not path.endswith('.gz') else gzip.open(path, mode='rt') as f:
    for line in f:
        if line.startswith('#'):
            continue
        cols = line.strip().split('\t')
        if cols[2] != 'region':
            continue

        info = {}
        split_char = '=' if '=' in cols[8] else ' '
        for row in cols[8].strip(';').split(';'):
            try:
                k, v = row.strip().split(split_char, 1)
                info[k] = v
            except ValueError:
                pass

        # Mark as mitochondrial if genome=mitochondrion
        if info.get('genome', '').lower() == 'mitochondrion':
            mitochondrial_contigs.add(cols[0])

with open(path) if not path.endswith('.gz') else gzip.open(path, mode='rt') as f:
    for line in f:
        if line.startswith('#'):
            continue
        cols = line.strip().split('\t')
        chrom = cols[0]
        feature_type = cols[2]
        if feature_type != 'CDS':
            continue

        # Skip CDS on mitochondrial contigs
        if chrom in mitochondrial_contigs:
            continue

        start = int(cols[3])
        end = int(cols[4])

        if end > inferred_contig_sizes.get(chrom, 0):
            inferred_contig_sizes[chrom] = end
        strand = cols[6]
        info = {}
        split_char = '=' if 'Parent' in cols[8] else ' '
        skip_line = False
        for row in cols[8].strip(';').split(';'):
            try:
                k, v = row.strip().split(split_char, 1)
                info[k] = v
            except ValueError:
                print(f'problems parsing {row} in {path}, line: {line.strip()}')
                skip_line = True
                break
        if skip_line:
            continue

        # Skip pseudogenes
        if info.get('pseudo') == 'true' or 'pseudogene' in info:
            continue

        if 'ID' in info:
            # ID=cds-XP_024343564.1 in GCF_002117355.1 gff
            if '-' in info['ID']:
                id = info['ID'].split('-')[1]
            else:
                id = info['ID']
        elif 'name' in info:
            id = info['name']
        elif 'Parent' in info:
            id = info['Parent']  # ncbi GCA_ genomes
        elif 'gene_id' in info:
            id = info['gene_id'].replace('"', '')  # stringtie format
        else:
            assert False, 'failed: False'
        key = chrom, strand, id
        if key not in data:
            data[key] = []
        data[key].append(tuple([start, end]))

        # We'll compute neighbour boundaries using non-overlapping gene extents
        # (start of first exon, end of last exon) per (chrom, strand, id)

# Build per-(chrom, strand) lists of (start, end, name) extents
for (chrom, strand, name), exons in data.items():
    exons.sort()
    start = exons[0][0]
    end = exons[-1][1]
    key_cs = (chrom, strand)
    if key_cs not in extents_by_cs:
        extents_by_cs[key_cs] = []
    extents_by_cs[key_cs].append((start, end, name))

for key_cs in extents_by_cs:
    # Sort by start for deterministic traversal
    extents_by_cs[key_cs].sort(key=lambda x: x[0])

with open(os.path.join(data_dir, f'{genome_id}.tsv'), 'w') as f:
    for (chrom, strand, name), exons in sorted(data.items()):

        if allowed_genes is not None and name not in allowed_genes:
            continue

        # ncbi can be in reverse order for reverse strand genes
        exons.sort()

        exon_ends = [x[1] for x in exons]  # already one-based
        exon_starts = [x[0] for x in exons]  # since parsed from gff, already one-based

        key = chrom, strand
        start = exon_starts[0]
        end = exon_ends[-1]

        # Add flanks, but not beyond non-overlapping neighbouring genes or contig boundaries
        # Define upstream neighbour as the closest gene whose end < start
        # Define downstream neighbour as the closest gene whose start > end
        upstream_bound = 1
        downstream_bound = inferred_contig_sizes[chrom]

        for s2, e2, name2 in extents_by_cs.get(key, []):
            if name2 == name:
                continue
            # Only consider non-overlapping intervals as neighbours on same strand
            if e2 < start:
                if e2 > upstream_bound:
                    upstream_bound = e2
            elif s2 > end:
                if s2 < downstream_bound:
                    downstream_bound = s2
            # Overlapping intervals (isoforms at same locus) are ignored

        if strand == '+':
            flank_start = max(start - UPSTREAM_FLANK_SIZE, upstream_bound, 1)
            flank_end = min(end + DOWNSTREAM_FLANK_SIZE, downstream_bound, inferred_contig_sizes[chrom])
        else:
            flank_start = max(start - DOWNSTREAM_FLANK_SIZE, upstream_bound, 1)
            flank_end = min(end + UPSTREAM_FLANK_SIZE, downstream_bound, inferred_contig_sizes[chrom])

        # Skip genes with insufficient flanking sequence at contig boundaries
        if start - flank_start < MIN_FLANK_SIZE and flank_start == 1:
            continue
        if flank_end - end < MIN_FLANK_SIZE and flank_end == inferred_contig_sizes[chrom]:
            continue

        print(name.replace('"', ''),  # gene name
              0,  # paralogous, not used in downstream code
              chrom,
              strand,
              flank_start, flank_end,
              ''.join(f'{x},' for x in exon_ends),
               ''.join(f'{x},' for x in exon_starts),
              sep='\t', file=f)
