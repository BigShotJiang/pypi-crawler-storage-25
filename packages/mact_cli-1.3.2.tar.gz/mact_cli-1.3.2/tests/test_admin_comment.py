"""Tests for admin comment PATCH on commits."""


def test_admin_can_comment_on_commit(client, room_tokens):
    auth = {"Authorization": f"Bearer {room_tokens['member_token']}"}
    admin_auth = {"Authorization": f"Bearer {room_tokens['admin_token']}"}

    # Report a commit
    client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "aabbccd",
            "branch": "main",
            "message": "feature work",
        },
        headers=auth,
    )

    # Admin comments on it
    resp = client.patch(
        f"/rooms/{room_tokens['room_id']}/commits/aabbccd/comment",
        json={"comment": "Great work!"},
        headers=admin_auth,
    )
    assert resp.status_code == 200
    assert resp.json()["status"] == "updated"

    # Verify comment appears in status
    status = client.get(f"/rooms/{room_tokens['room_id']}/status")
    latest = status.json()["latest_commit"]
    assert latest["admin_comment"] == "Great work!"


def test_non_admin_cannot_comment(client, room_tokens):
    auth = {"Authorization": f"Bearer {room_tokens['member_token']}"}

    client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "1122334",
            "branch": "main",
            "message": "test",
        },
        headers=auth,
    )

    # Member token, not admin token
    resp = client.patch(
        f"/rooms/{room_tokens['room_id']}/commits/1122334/comment",
        json={"comment": "Not allowed"},
        headers=auth,
    )
    assert resp.status_code == 403


def test_comment_on_nonexistent_commit(client, room_tokens):
    admin_auth = {"Authorization": f"Bearer {room_tokens['admin_token']}"}
    resp = client.patch(
        f"/rooms/{room_tokens['room_id']}/commits/deadbeef/comment",
        json={"comment": "Should fail"},
        headers=admin_auth,
    )
    assert resp.status_code == 404


def test_null_comment_clears_it(client, room_tokens):
    auth = {"Authorization": f"Bearer {room_tokens['member_token']}"}
    admin_auth = {"Authorization": f"Bearer {room_tokens['admin_token']}"}

    client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "5566778",
            "branch": "main",
            "message": "another commit",
        },
        headers=auth,
    )

    # Set comment
    client.patch(
        f"/rooms/{room_tokens['room_id']}/commits/5566778/comment",
        json={"comment": "initial comment"},
        headers=admin_auth,
    )

    # Clear comment
    resp = client.patch(
        f"/rooms/{room_tokens['room_id']}/commits/5566778/comment",
        json={"comment": None},
        headers=admin_auth,
    )
    assert resp.status_code == 200
