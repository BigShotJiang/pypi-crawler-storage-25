"""Tests for tunnel config generation and lifecycle (mocked subprocess)."""

from unittest.mock import MagicMock, patch

import pytest

from mact.tunnel.frpc import FrpcTunnel


def test_public_url_format():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="tunnel.m-act.live",
        public_scheme="https",
    )
    assert t.public_url == "https://alice-demo.tunnel.m-act.live"


def test_public_url_https_custom_port():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="tunnel.example.com",
        vhost_http_port=8443,
        public_scheme="https",
    )
    assert t.public_url == "https://alice-demo.tunnel.example.com:8443"


def test_public_url_http_localhost():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="localhost",
        vhost_http_port=18180,
        public_scheme="http",
    )
    assert t.public_url == "http://alice-demo.localhost:18180"


def test_proxy_name():
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="bob")
    assert t.proxy_name == "mact-bob-demo"


def test_mixed_case_developer_normalizes_for_dns_and_frps():
    """DEV_RE allows uppercase; Host / customDomains must be lowercase for stable routing."""
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="Alice",
        vhost_domain="Tunnel.EXAMPLE.com",
        public_scheme="https",
    )
    assert t.proxy_name == "mact-alice-demo"
    assert t.public_url == "https://alice-demo.tunnel.example.com"
    cfg = t.generate_config()
    assert 'customDomains = ["alice-demo.tunnel.example.com"]' in cfg
    assert 'name = "mact-alice-demo"' in cfg


def test_empty_server_addr_falls_back_to_default():
    t = FrpcTunnel(
        local_port=3000,
        room_id="r",
        developer_id="d",
        server_addr="   ",
        server_port=7000,
    )
    assert 'serverAddr = "m-act.live"' in t.generate_config()


def test_empty_vhost_domain_falls_back_to_default():
    t = FrpcTunnel(
        local_port=3000,
        room_id="r",
        developer_id="d",
        vhost_domain="",
    )
    assert "tunnel.m-act.live" in t.generate_config()


def test_generate_config_contains_essentials():
    t = FrpcTunnel(
        local_port=4000,
        room_id="proj",
        developer_id="carol",
        server_addr="frp.example.com",
        server_port=7777,
        auth_token="secret123",
        vhost_domain="tunnel.example.com",
    )
    cfg = t.generate_config()
    assert 'serverAddr = "frp.example.com"' in cfg
    assert "serverPort = 7777" in cfg
    assert 'auth.token = "secret123"' in cfg
    assert "localPort = 4000" in cfg
    assert "carol-proj.tunnel.example.com" in cfg


def test_generate_config_no_auth_token():
    t = FrpcTunnel(
        local_port=3000, room_id="demo", developer_id="alice", auth_token=""
    )
    cfg = t.generate_config()
    assert "auth.token" not in cfg


def test_is_running_initially_false():
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    assert t.is_running() is False


@patch(
    "mact.tunnel.frpc.ensure_frpc_executable",
    side_effect=OSError("simulated frpc unavailable"),
)
def test_start_raises_when_frpc_unavailable(mock_ensure):
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    with pytest.raises(OSError, match="simulated frpc unavailable"):
        t.start()


@patch("mact.tunnel.frpc.time.sleep", autospec=True)
@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("mact.tunnel.frpc.subprocess.run")
@patch("subprocess.Popen")
def test_start_fails_when_frpc_exits_immediately(mock_popen, mock_run, mock_ensure, _mock_sleep):
    mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = 1
    mock_proc.stderr.read.return_value = b"login to the server failed"
    mock_popen.return_value = mock_proc
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    with pytest.raises(RuntimeError, match="frpc exited immediately"):
        t.start()


@patch("mact.tunnel.frpc.time.sleep", autospec=True)
@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("mact.tunnel.frpc.subprocess.run")
@patch("subprocess.Popen")
def test_start_spawns_frpc(mock_popen, mock_run, mock_ensure, _mock_sleep):
    mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_popen.return_value = mock_proc

    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    t.start()

    assert mock_popen.called
    call_args = mock_popen.call_args
    assert "/usr/bin/frpc" in call_args[0][0][0]
    assert t.is_running() is True

    t.stop()
    mock_proc.send_signal.assert_called()
