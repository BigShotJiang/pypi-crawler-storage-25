"""End-to-end vertical slice: create → join → commit → status, with security."""


def test_create_join_commit_and_status_flow(client):
    # 1. Create room → get tokens
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "demo-room",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200
    tokens = create_resp.json()
    assert "join_secret" in tokens
    assert "admin_token" in tokens
    assert "member_token" in tokens
    alice_token = tokens["member_token"]

    # 2. Join with the join secret → get member token
    join_resp = client.post(
        "/rooms/demo-room/join",
        json={
            "developer_id": "bob",
            "upstream_url": "http://127.0.0.1:3001",
            "join_secret": tokens["join_secret"],
        },
    )
    assert join_resp.status_code == 200
    bob_token = join_resp.json()["member_token"]

    # 3. Report commit (alice, authenticated)
    first_commit = client.post(
        "/rooms/demo-room/commits",
        json={
            "developer_id": "alice",
            "commit_hash": "a1b2c3d",
            "branch": "main",
            "message": "Initial commit",
        },
        headers={"Authorization": f"Bearer {alice_token}"},
    )
    assert first_commit.status_code == 200
    assert first_commit.json() == {"inserted": True}

    # 4. Duplicate commit → inserted: False
    dup = client.post(
        "/rooms/demo-room/commits",
        json={
            "developer_id": "alice",
            "commit_hash": "a1b2c3d",
            "branch": "main",
            "message": "Initial commit",
        },
        headers={"Authorization": f"Bearer {alice_token}"},
    )
    assert dup.status_code == 200
    assert dup.json() == {"inserted": False}

    # 5. Status
    status_resp = client.get("/rooms/demo-room/status")
    assert status_resp.status_code == 200
    payload = status_resp.json()
    assert payload["room_id"] == "demo-room"
    assert payload["latest_commit"]["commit_hash"] == "a1b2c3d"
    assert payload["active_upstream"] == "http://127.0.0.1:3000"
    assert len(payload["participants"]) == 2

    # 6. Bob can also report a commit
    bob_commit = client.post(
        "/rooms/demo-room/commits",
        json={
            "developer_id": "bob",
            "commit_hash": "b2c3d4e",
            "branch": "main",
            "message": "Second commit",
        },
        headers={"Authorization": f"Bearer {bob_token}"},
    )
    assert bob_commit.status_code == 200
    assert bob_commit.json()["inserted"] is True


def test_join_with_wrong_secret_fails(client):
    client.post(
        "/rooms",
        json={
            "room_id": "secret-room",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    resp = client.post(
        "/rooms/secret-room/join",
        json={
            "developer_id": "eve",
            "upstream_url": "http://evil.local",
            "join_secret": "wrong-secret",
        },
    )
    assert resp.status_code == 403


def test_commit_without_auth_fails(client, room_tokens):
    resp = client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "a1b2c3d",
            "branch": "main",
            "message": "test",
        },
    )
    assert resp.status_code == 401


def test_commit_with_wrong_token_fails(client, room_tokens):
    resp = client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "a1b2c3d",
            "branch": "main",
            "message": "test",
        },
        headers={"Authorization": "Bearer wrong-token"},
    )
    assert resp.status_code == 403
