"""Tests for token generation, hashing, and verification (pure Python — no app deps)."""

from mact.security import generate_token, hash_token, verify_token


def test_generate_token_length_and_uniqueness():
    t1 = generate_token()
    t2 = generate_token()
    assert len(t1) >= 40
    assert t1 != t2


def test_hash_deterministic():
    token = "test-token-abc"
    assert hash_token(token) == hash_token(token)


def test_verify_correct_token():
    token = generate_token()
    h = hash_token(token)
    assert verify_token(token, h) is True


def test_verify_wrong_token():
    token = generate_token()
    h = hash_token(token)
    assert verify_token("wrong-token", h) is False


def test_verify_wrong_hash():
    token = generate_token()
    assert verify_token(token, "0" * 64) is False
