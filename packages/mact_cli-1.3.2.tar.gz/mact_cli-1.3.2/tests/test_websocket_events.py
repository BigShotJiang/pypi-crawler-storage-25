"""WebSocket room events: initial snapshot and push after room updates."""

import pytest

pytest.importorskip("httpx")


def test_websocket_receives_initial_room_status(client, room_tokens):
    with client.websocket_connect(
        f"/rooms/{room_tokens['room_id']}/events"
    ) as ws:
        msg = ws.receive_json()
        assert msg["type"] == "room_status"
        assert msg["payload"]["room_id"] == room_tokens["room_id"]


def test_websocket_push_after_commit(client, room_tokens):
    with client.websocket_connect(
        f"/rooms/{room_tokens['room_id']}/events"
    ) as ws:
        ws.receive_json()

    client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "a1b2c3d4",
            "branch": "main",
            "message": "second",
        },
        headers={"Authorization": f"Bearer {room_tokens['member_token']}"},
    )

    with client.websocket_connect(
        f"/rooms/{room_tokens['room_id']}/events"
    ) as ws:
        first = ws.receive_json()
        assert first["payload"]["latest_commit"]["message"] == "second"


def test_mirror_live_page_exists(client, room_tokens):
    r = client.get(f"/r/{room_tokens['room_id']}/live")
    assert r.status_code == 200
    assert "mact-mirror-frame" in r.text
    assert "WebSocket" in r.text or "WebSocket" in r.text.lower()
