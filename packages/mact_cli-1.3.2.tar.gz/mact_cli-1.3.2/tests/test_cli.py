"""Tests for CLI commands (HTTP calls mocked)."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from mact.cli.main import build_parser


@pytest.fixture(autouse=True)
def isolate_config(tmp_path, monkeypatch):
    """Redirect CLI config files to a temp directory."""
    monkeypatch.setattr("mact.cli.config.CONFIG_PATH", tmp_path / "config.json")
    monkeypatch.setattr("mact.cli.config.ROOMS_PATH", tmp_path / "rooms.json")
    return tmp_path


def _run(argv: list[str]) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


def test_init_sets_developer():
    rc = _run(["init", "--developer", "alice"])
    assert rc == 0
    from mact.cli.config import get_developer_id

    assert get_developer_id() == "alice"


def test_merge_save_room_upstream_updates_local_json(isolate_config):
    """After tunnel starts, upstream_url must not stay localhost in ~/.mact_rooms.json."""
    from mact.cli.config import get_room, save_room
    from mact.cli.main import _merge_save_room_upstream

    save_room(
        "demo",
        {
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
            "member_token": "mt",
        },
    )
    _merge_save_room_upstream("demo", "https://alice-demo.tunnel.m-act.live")
    assert get_room("demo")["upstream_url"] == "https://alice-demo.tunnel.m-act.live"
    assert get_room("demo")["member_token"] == "mt"


def test_configure_frp():
    rc = _run(
        [
            "configure-frp",
            "--server-addr",
            "frp.example.com",
            "--server-port",
            "7777",
            "--auth-token",
            "test-token-secret",
        ]
    )
    assert rc == 0
    from mact.cli.config import get_frp_config

    cfg = get_frp_config()
    assert cfg["server_addr"] == "frp.example.com"
    assert cfg["server_port"] == 7777
    assert cfg["auth_token"] == "test-token-secret"


def test_configure_frp_builtin_token_when_omitted(isolate_config):
    """No --auth-token uses built-in default for m-act.live (see mact.tunnel.constants)."""
    from mact.tunnel.constants import DEFAULT_FRPS_AUTH_TOKEN

    rc = _run(["configure-frp", "--server-addr", "frp.example.com", "--server-port", "7777"])
    assert rc == 0
    from mact.cli.config import get_frp_config

    cfg = get_frp_config()
    assert cfg["auth_token"] == DEFAULT_FRPS_AUTH_TOKEN


@patch("mact.cli.main.requests.post")
def test_create_stores_tokens(mock_post, isolate_config, monkeypatch):
    from mact.cli.config import get_room, set_developer_id

    subprocess.run(["git", "init"], cwd=isolate_config, check=True)
    monkeypatch.chdir(isolate_config)

    set_developer_id("alice")
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "room_id": "demo",
        "join_secret": "js-123",
        "admin_token": "at-456",
        "member_token": "mt-789",
    }
    mock_post.return_value = mock_resp

    rc = _run(["create", "--room", "demo", "--port", "3000", "--no-live"])
    assert rc == 0

    room = get_room("demo")
    assert room is not None
    assert room["member_token"] == "mt-789"
    assert room["join_secret"] == "js-123"


@patch("mact.cli.main.requests.post")
def test_join_stores_member_token(mock_post, isolate_config, monkeypatch):
    from mact.cli.config import get_room, set_developer_id

    subprocess.run(["git", "init"], cwd=isolate_config, check=True)
    monkeypatch.chdir(isolate_config)

    set_developer_id("bob")
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"status": "joined", "member_token": "mt-bob"}
    mock_post.return_value = mock_resp

    rc = _run(["join", "--room", "demo", "--port", "3001", "--secret", "js-123", "--no-live"])
    assert rc == 0

    room = get_room("demo")
    assert room["member_token"] == "mt-bob"


@patch("mact.cli.main.requests.get")
def test_status_displays_info(mock_get, capsys, isolate_config):
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "room_id": "demo",
        "active_upstream": "http://127.0.0.1:3000",
        "latest_commit": {
            "commit_hash": "abc1234",
            "developer_id": "alice",
            "message": "init",
        },
        "participants": [
            {
                "developer_id": "alice",
                "upstream_url": "http://127.0.0.1:3000",
                "connected": True,
                "last_seen_at": "2026-01-01T00:00:00",
            }
        ],
    }
    mock_get.return_value = mock_resp

    rc = _run(["status", "--room", "demo"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "demo" in captured.out
    assert "alice" in captured.out


@patch("mact.cli.main.requests.post")
def test_commit_report(mock_post, isolate_config):
    from mact.cli.config import save_room, set_developer_id

    set_developer_id("alice")
    save_room("demo", {"developer_id": "alice", "member_token": "mt-123"})

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"inserted": True}
    mock_post.return_value = mock_resp

    rc = _run(
        [
            "commit-report",
            "--room",
            "demo",
            "--hash",
            "a1b2c3d",
            "--branch",
            "main",
            "--message",
            "test commit",
        ]
    )
    assert rc == 0

    call_kwargs = mock_post.call_args
    assert "Authorization" in call_kwargs.kwargs.get("headers", {}) or (
        len(call_kwargs.args) > 0
    )


def test_rooms_empty(capsys, isolate_config):
    rc = _run(["rooms"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "No local room metadata" in captured.out


@patch("mact.cli.main.requests.post")
def test_leave_disconnects(mock_post, isolate_config):
    from mact.cli.config import save_room, set_developer_id

    set_developer_id("alice")
    save_room("demo", {"developer_id": "alice", "member_token": "mt-123"})

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"status": "ok"}
    mock_post.return_value = mock_resp

    rc = _run(["leave", "--room", "demo"])
    assert rc == 0

    call_args = mock_post.call_args
    assert "/presence/disconnect" in call_args.args[0]
    assert call_args.kwargs["headers"]["Authorization"] == "Bearer mt-123"


def test_leave_no_room(capsys, isolate_config):
    rc = _run(["leave", "--room", "nonexistent"])
    assert rc == 1
    captured = capsys.readouterr()
    assert "not found locally" in captured.err


def test_forget_removes_local(isolate_config):
    from mact.cli.config import get_room, save_room, set_developer_id

    set_developer_id("alice")
    save_room("demo", {"developer_id": "alice", "member_token": "mt-123"})
    rc = _run(["forget", "--room", "demo"])
    assert rc == 0
    assert get_room("demo") is None


def test_version_flag():
    parser = build_parser()
    with pytest.raises(SystemExit) as exc_info:
        parser.parse_args(["--version"])
    assert exc_info.value.code == 0


@patch("mact.cli.main.requests.post")
def test_create_requires_git_repo(mock_post, isolate_config, monkeypatch, capsys):
    from mact.cli.config import set_developer_id

    monkeypatch.chdir(isolate_config)
    set_developer_id("alice")

    rc = _run(["create", "--room", "demo", "--port", "3000", "--no-live"])
    assert rc == 1
    assert "git" in capsys.readouterr().err.lower()
    mock_post.assert_not_called()
