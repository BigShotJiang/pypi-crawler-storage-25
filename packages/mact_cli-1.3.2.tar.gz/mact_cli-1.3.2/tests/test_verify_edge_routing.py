"""Regression: nginx must expose HTTPS for room + tunnel wildcards (see deployment/README.md)."""

from __future__ import annotations

from pathlib import Path

import pytest

from mact.deployment.nginx_verify import verify_nginx_config

_REPO = Path(__file__).resolve().parent.parent
_CANONICAL = _REPO / "deployment" / "nginx" / "mact.live.conf"


def test_canonical_nginx_passes_verifier():
    errs = verify_nginx_config(_CANONICAL)
    assert errs == [], errs


def test_broken_tunnel_block_detected(tmp_path: Path):
    """HTTPS tunnel block proxying to uvicorn instead of frps must fail."""
    bad = """
map $http_upgrade $connection_upgrade { default upgrade; '' close; }
upstream mact_backend { server 127.0.0.1:8000; }
upstream frps_vhost { server 127.0.0.1:8080; }
server {
    listen 80;
    server_name m-act.live *.m-act.live *.tunnel.m-act.live;
    location / { return 301 https://$host$request_uri; }
}
server {
    listen 443 ssl http2;
    server_name m-act.live *.m-act.live;
    location / { proxy_pass http://mact_backend; }
}
server {
    listen 443 ssl http2;
    server_name *.tunnel.m-act.live;
    location / { proxy_pass http://mact_backend; }
}
"""
    p = tmp_path / "bad.conf"
    p.write_text(bad, encoding="utf-8")
    errs = verify_nginx_config(p)
    assert any("frps_vhost" in e for e in errs) or any("Missing" in e for e in errs)
    assert errs
