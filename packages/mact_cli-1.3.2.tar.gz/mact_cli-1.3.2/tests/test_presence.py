"""Presence (heartbeat / disconnect) affects active-upstream resolution."""

from dataclasses import replace

from mact.server.main import fastapi_app


def test_presence_disconnect_and_heartbeat_affect_active_upstream(client):
    # Create room and get tokens
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "presence-room",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200
    tokens = create_resp.json()
    member_token = tokens["member_token"]
    auth = {"Authorization": f"Bearer {member_token}"}

    # Active upstream should be alice
    status_before = client.get("/rooms/presence-room/status")
    assert status_before.status_code == 200
    assert status_before.json()["active_upstream"] == "http://127.0.0.1:3000"

    # Disconnect alice
    disconnect_resp = client.post(
        "/rooms/presence-room/presence/disconnect",
        json={"developer_id": "alice"},
        headers=auth,
    )
    assert disconnect_resp.status_code == 200

    # No active upstream
    status_disc = client.get("/rooms/presence-room/status")
    assert status_disc.status_code == 200
    disc_payload = status_disc.json()
    assert disc_payload["active_upstream"] is None
    assert disc_payload["participants"][0]["connected"] is False

    # Heartbeat alice back
    hb_resp = client.post(
        "/rooms/presence-room/presence/heartbeat",
        json={"developer_id": "alice"},
        headers=auth,
    )
    assert hb_resp.status_code == 200

    # Active upstream restored
    status_after = client.get("/rooms/presence-room/status")
    assert status_after.status_code == 200
    after_payload = status_after.json()
    assert after_payload["active_upstream"] == "http://127.0.0.1:3000"
    assert after_payload["participants"][0]["connected"] is True


def test_heartbeat_updates_upstream_url(client):
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "upstream-update",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    tokens = create_resp.json()
    auth = {"Authorization": f"Bearer {tokens['member_token']}"}

    # Heartbeat with new upstream URL
    client.post(
        "/rooms/upstream-update/presence/heartbeat",
        json={
            "developer_id": "alice",
            "upstream_url": "http://tunnel.example.com",
        },
        headers=auth,
    )

    status = client.get("/rooms/upstream-update/status")
    payload = status.json()
    assert payload["active_upstream"] == "http://tunnel.example.com"
    assert payload["participants"][0]["upstream_url"] == "http://tunnel.example.com"


def test_heartbeat_rejects_loopback_when_public_deployment(client, monkeypatch):
    """Production-style settings: localhost upstreams must not be registered."""
    s = fastapi_app.state.settings
    monkeypatch.setattr(
        fastapi_app.state,
        "settings",
        replace(s, public_base_domain="m-act.live", allow_loopback_upstream=False),
    )
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "hb-loopback",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200
    tokens = create_resp.json()
    auth = {"Authorization": f"Bearer {tokens['member_token']}"}

    st = client.get("/rooms/hb-loopback/status")
    assert st.json()["active_upstream"] is None
    assert st.json()["participants"][0]["connected"] is False

    hb = client.post(
        "/rooms/hb-loopback/presence/heartbeat",
        json={"developer_id": "alice", "upstream_url": "http://127.0.0.1:3000"},
        headers=auth,
    )
    assert hb.status_code == 400
    assert "tunnel" in hb.json()["detail"].lower() or "localhost" in hb.json()["detail"].lower()


def test_heartbeat_rejects_private_ip_when_public_deployment(client, monkeypatch):
    """Non-tunnel URLs must not be registered when serving public mirrors."""
    s = fastapi_app.state.settings
    monkeypatch.setattr(
        fastapi_app.state,
        "settings",
        replace(
            s,
            public_base_domain="m-act.live",
            allow_loopback_upstream=False,
            mirror_upstream_host_suffix="tunnel.m-act.live",
        ),
    )
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "hb-private",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200
    tokens = create_resp.json()
    auth = {"Authorization": f"Bearer {tokens['member_token']}"}

    hb = client.post(
        "/rooms/hb-private/presence/heartbeat",
        json={
            "developer_id": "alice",
            "upstream_url": "http://10.0.0.1:8080",
        },
        headers=auth,
    )
    assert hb.status_code == 400
    assert "rejected" in hb.json()["detail"].lower()


def test_heartbeat_accepts_tunnel_url_when_public_deployment(client, monkeypatch):
    s = fastapi_app.state.settings
    monkeypatch.setattr(
        fastapi_app.state,
        "settings",
        replace(s, public_base_domain="m-act.live", allow_loopback_upstream=False),
    )
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "hb-tunnel",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    tokens = create_resp.json()
    auth = {"Authorization": f"Bearer {tokens['member_token']}"}
    assert client.get("/rooms/hb-tunnel/status").json()["active_upstream"] is None

    hb = client.post(
        "/rooms/hb-tunnel/presence/heartbeat",
        json={
            "developer_id": "alice",
            "upstream_url": "https://alice-hb-tunnel.tunnel.m-act.live",
        },
        headers=auth,
    )
    assert hb.status_code == 200


def test_presence_requires_auth(client):
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "auth-presence",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200

    # Heartbeat without auth → 401
    resp = client.post(
        "/rooms/auth-presence/presence/heartbeat",
        json={"developer_id": "alice"},
    )
    assert resp.status_code == 401

    # Disconnect without auth → 401
    resp = client.post(
        "/rooms/auth-presence/presence/disconnect",
        json={"developer_id": "alice"},
    )
    assert resp.status_code == 401


def test_public_active_upstream_no_random_member_fallback(client, monkeypatch):
    """Latest commit author must drive the mirror; do not pick another live member."""
    from dataclasses import replace

    from mact.server.main import fastapi_app

    s = fastapi_app.state.settings
    monkeypatch.setattr(
        fastapi_app.state,
        "settings",
        replace(
            s,
            public_base_domain="m-act.live",
            allow_loopback_upstream=False,
            mirror_upstream_host_suffix="tunnel.m-act.live",
        ),
    )

    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "rank-fallback",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200
    tokens_a = create_resp.json()
    join_resp = client.post(
        "/rooms/rank-fallback/join",
        json={
            "developer_id": "bob",
            "upstream_url": "http://127.0.0.1:3001",
            "join_secret": tokens_a["join_secret"],
        },
    )
    assert join_resp.status_code == 200
    bob_token = join_resp.json()["member_token"]

    client.post(
        "/rooms/rank-fallback/commits",
        json={
            "developer_id": "alice",
            "commit_hash": "aaa1111111111111111111111111111111111111",
            "branch": "main",
            "message": "only alice committed",
        },
        headers={"Authorization": f"Bearer {tokens_a['member_token']}"},
    )

    client.post(
        "/rooms/rank-fallback/presence/heartbeat",
        json={
            "developer_id": "bob",
            "upstream_url": "https://bob-rank-fallback.tunnel.m-act.live",
        },
        headers={"Authorization": f"Bearer {bob_token}"},
    )
    st = client.get("/rooms/rank-fallback/status").json()
    assert st["active_upstream"] is None
    assert any(
        p["developer_id"] == "bob" and p["connected"] for p in st["participants"]
    )
