"""Shared validation patterns — single source of truth for slug/format regexes."""

from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlparse

ROOM_RE = re.compile(r"^(?:[a-z0-9]|[a-z0-9][a-z0-9_-]{0,48}[a-z0-9])$")

# Must not collide with API paths, dashboard, or well-known subdomains (see subdomain.py).
RESERVED_ROOM_IDS = frozenset(
    {
        "admin",
        "api",
        "assets",
        "dashboard",
        "dev",
        "docs",
        "health",
        "internal",
        "live",
        "metrics",
        "openapi",
        "r",
        "ready",
        "redoc",
        "rooms",
        "static",
        "tunnel",
        "websocket",
        "www",
        "ws",
        "wss",
    }
)
DEV_RE = re.compile(r"^[a-zA-Z0-9_-]{1,30}$")
HASH_RE = re.compile(r"^[a-f0-9]{7,40}$")
BRANCH_RE = re.compile(r"^[a-zA-Z0-9/_.-]{1,80}$")


def upstream_url_is_loopback(url: str) -> bool:
    """
    True if ``url`` points at loopback (localhost / 127.x / ::1).

    The control-plane server cannot mirror those hosts — the dev's machine is not
    the same as the droplet's loopback.
    """
    if not url or not str(url).strip():
        return True
    try:
        p = urlparse(url.strip())
    except Exception:
        return True
    host = (p.hostname or "").lower()
    if not host:
        return True
    if host == "localhost" or host.endswith(".localhost"):
        return True
    if host == "::1":
        return True
    if host.startswith("127."):
        return True
    return False


def is_reserved_room_id(room_id: str) -> bool:
    return room_id.strip().lower() in RESERVED_ROOM_IDS


def mirror_upstream_url_forbidden_reason(
    url: str,
    *,
    host_suffix: str | None,
) -> str | None:
    """
    If non-None, *url* must not be used for server-side mirror fetches (SSRF mitigation).

    When *host_suffix* is set (e.g. ``tunnel.m-act.live``), the hostname must be under that
    suffix; IP-literal hosts are rejected. When *host_suffix* is None/empty, only obviously
    unsafe hosts (private/link-local IP literals, non-http(s)) are rejected.
    """
    if not url or not str(url).strip():
        return "empty upstream URL"
    try:
        p = urlparse(url.strip())
    except Exception:
        return "unparseable URL"
    if p.scheme not in ("http", "https"):
        return "only http/https upstream URLs are allowed"
    host = (p.hostname or "").strip().lower()
    if not host:
        return "missing host in upstream URL"
    # Strip zone id for IPv6 literals
    host_for_ip = host.split("%", 1)[0].strip("[]")
    try:
        ip = ipaddress.ip_address(host_for_ip)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return "upstream host must not be a private, loopback, or link-local address"
        return "mirror upstream must use a tunnel hostname, not a raw IP address"
    except ValueError:
        pass  # not an IP literal — expect DNS name
    suffix = (host_suffix or "").strip().lower().rstrip(".")
    if not suffix:
        return None
    if host == suffix or host.endswith("." + suffix):
        return None
    return f"upstream host must be under {suffix}"
