"""MACT — Mirrored Active Collaborative Tunnel."""

try:
    from importlib.metadata import PackageNotFoundError, version

    __version__ = version("mact-cli")
except PackageNotFoundError:  # pragma: no cover - editable / vendored tree
    __version__ = "1.3.1"
