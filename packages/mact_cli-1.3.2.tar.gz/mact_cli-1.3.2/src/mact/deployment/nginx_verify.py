"""Validate nginx site config for MACT edge routing (HTTPS room + tunnel wildcards)."""

from __future__ import annotations

import re
import sys
from pathlib import Path


def _strip_hash_comments(text: str) -> str:
    lines = []
    for line in text.splitlines():
        if "#" in line:
            line = line.split("#", 1)[0]
        lines.append(line)
    return "\n".join(lines)


def _split_server_blocks(text: str) -> list[str]:
    """Split nginx config into `server { ... }` blocks (brace-aware)."""
    out: list[str] = []
    i = 0
    while i < len(text):
        m = re.search(r"\bserver\s*\{", text[i:])
        if not m:
            break
        start = i + m.start()
        depth = 0
        j = start
        while j < len(text):
            c = text[j]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    out.append(text[start : j + 1])
                    i = j + 1
                    break
            j += 1
        else:
            break
    return out


def verify_nginx_config(path: Path) -> list[str]:
    """Return error messages; empty list means the config passes checks."""
    errors: list[str] = []
    if not path.is_file():
        return [f"not a file: {path}"]

    raw = path.read_text(encoding="utf-8")
    text = _strip_hash_comments(raw)

    blocks = _split_server_blocks(text)
    if not blocks:
        errors.append("no `server { ... }` blocks found")
        return errors

    tunnel_https_to_frps = False
    room_https_to_mact = False
    http_redirects_tls = False

    for b in blocks:
        has_443 = "listen" in b and "443" in b
        if "return 301" in b and "https://" in b and "listen" in b and "80" in b:
            if "tunnel.m-act.live" in b or "*.m-act.live" in b or "m-act.live" in b:
                http_redirects_tls = True

        if "tunnel.m-act.live" in b and "server_name" in b:
            if has_443 and "frps_vhost" in b:
                tunnel_https_to_frps = True
            elif has_443 and "mact_backend" in b:
                errors.append(
                    "HTTPS server block for *.tunnel.m-act.live must proxy to "
                    "`frps_vhost`, not `mact_backend` (tunnel would hit uvicorn)."
                )

        if "server_name" in b and "*.m-act.live" in b and "tunnel" not in b:
            if has_443 and "mact_backend" in b:
                room_https_to_mact = True

    if not tunnel_https_to_frps:
        errors.append(
            "Missing or invalid: `listen 443` server block for "
            "`server_name *.tunnel.m-act.live` proxying to `http://frps_vhost`."
        )

    if not room_https_to_mact:
        errors.append(
            "Missing or invalid: `listen 443` server block for "
            "`server_name m-act.live *.m-act.live` proxying to `http://mact_backend`."
        )

    if not http_redirects_tls:
        errors.append(
            "Expected HTTP (port 80) server block(s) that redirect to HTTPS "
            "for m-act.live / *.m-act.live / *.tunnel.m-act.live (see repo template)."
        )

    return errors


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    default = Path(__file__).resolve().parents[3] / "deployment" / "nginx" / "mact.live.conf"
    path = Path(argv[0]).expanduser() if argv else default

    errs = verify_nginx_config(path)
    if errs:
        print(f"verify_edge_routing: FAILED ({path})", file=sys.stderr)
        for e in errs:
            print(f"  - {e}", file=sys.stderr)
        return 1
    print(f"verify_edge_routing: OK ({path})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
