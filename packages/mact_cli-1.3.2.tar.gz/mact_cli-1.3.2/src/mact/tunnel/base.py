from __future__ import annotations

import abc


class Tunnel(abc.ABC):
    """Abstract base for a tunnel that exposes a local port via a public URL."""

    @abc.abstractmethod
    def start(self) -> None: ...

    @abc.abstractmethod
    def stop(self) -> None: ...

    @abc.abstractmethod
    def is_running(self) -> bool: ...

    @property
    @abc.abstractmethod
    def public_url(self) -> str: ...
