from __future__ import annotations

import os
import signal
import subprocess
import tempfile
import time
from pathlib import Path

from mact.tunnel.base import Tunnel
from mact.tunnel.constants import (
    DEFAULT_FRPS_ADDR,
    DEFAULT_FRPS_PORT,
    DEFAULT_PUBLIC_SCHEME,
    DEFAULT_VHOST_DOMAIN,
    DEFAULT_VHOST_HTTP_PORT,
)
from mact.tunnel.frpc_download import ensure_frpc_executable


class FrpcTunnel(Tunnel):
    """Manages an frpc process that tunnels a local port via frps."""

    def __init__(
        self,
        local_port: int,
        room_id: str,
        developer_id: str,
        server_addr: str = DEFAULT_FRPS_ADDR,
        server_port: int = DEFAULT_FRPS_PORT,
        auth_token: str = "",
        vhost_domain: str = DEFAULT_VHOST_DOMAIN,
        vhost_http_port: int = DEFAULT_VHOST_HTTP_PORT,
        public_scheme: str = DEFAULT_PUBLIC_SCHEME,
    ) -> None:
        self._local_port = local_port
        self._room_id = room_id.strip()
        self._developer_id = developer_id.strip()
        addr = (server_addr or "").strip()
        self._server_addr = addr if addr else DEFAULT_FRPS_ADDR
        self._server_port = server_port
        self._auth_token = auth_token
        vd = (vhost_domain or "").strip()
        self._vhost_domain = vd if vd else DEFAULT_VHOST_DOMAIN
        self._vhost_http_port = vhost_http_port
        self._public_scheme = public_scheme if public_scheme in ("http", "https") else "https"
        self._process: subprocess.Popen | None = None
        self._config_path: Path | None = None

    @property
    def proxy_name(self) -> str:
        # Lowercase: frps proxy name + DNS labels must match Host (nginx lowercases).
        d = self._developer_id.lower()
        r = self._room_id.lower()
        return f"mact-{d}-{r}"

    @property
    def _tunnel_fqdn(self) -> str:
        """Must match `customDomains` in frpc and the Host header nginx forwards to frps."""
        d = self._developer_id.lower()
        r = self._room_id.lower()
        v = self._vhost_domain.lower()
        return f"{d}-{r}.{v}"

    @property
    def public_url(self) -> str:
        """URL registered with the API for mirroring; must match how nginx exposes the tunnel."""
        host = self._tunnel_fqdn
        port = self._vhost_http_port
        if self._public_scheme == "https":
            # Config may still say 80 from older installs; public TLS is on 443.
            if port and port not in (80, 443):
                return f"https://{host}:{port}"
            return f"https://{host}"
        if port and port != 80:
            return f"http://{host}:{port}"
        return f"http://{host}"

    def generate_config(self) -> str:
        # Minimal TOML-safe escaping for quoted string values.
        def _toml_escape(value: str) -> str:
            return value.replace("\\", "\\\\").replace('"', '\\"')

        lines = [
            f'serverAddr = "{self._server_addr}"',
            f"serverPort = {self._server_port}",
        ]
        if self._auth_token:
            lines.append(f'auth.token = "{_toml_escape(self._auth_token)}"')
        lines.extend(
            [
                "",
                "[[proxies]]",
                f'name = "{self.proxy_name}"',
                'type = "http"',
                f"localPort = {self._local_port}",
                f'customDomains = ["{self._tunnel_fqdn}"]',
            ]
        )
        return "\n".join(lines) + "\n"

    def start(self) -> None:
        if self._process and self._process.poll() is None:
            return

        frpc = ensure_frpc_executable()

        config_content = self.generate_config()
        fd, path = tempfile.mkstemp(suffix=".toml", prefix="mact-frpc-")
        try:
            os.write(fd, config_content.encode())
        finally:
            os.close(fd)
        self._config_path = Path(path)

        try:
            verify = subprocess.run(
                [frpc, "verify", "-c", str(self._config_path)],
                capture_output=True,
                text=True,
                timeout=15,
            )
            if verify.returncode != 0:
                detail = (verify.stderr or verify.stdout or "").strip() or "(no output)"
                raise RuntimeError(f"frpc verify failed: {detail[:2000]}")

            self._process = subprocess.Popen(
                [frpc, "-c", str(self._config_path)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            # Auth / TCP to frps can take longer than a few hundred ms; catch early exit.
            deadline = time.monotonic() + 4.0
            while time.monotonic() < deadline:
                if self._process.poll() is not None:
                    break
                time.sleep(0.1)
            if self._process.poll() is not None:
                err = b""
                if self._process.stderr:
                    try:
                        err = self._process.stderr.read()
                    except Exception:
                        pass
                detail = err.decode(errors="replace").strip() or "(no stderr)"
                raise RuntimeError(f"frpc exited immediately: {detail[:2000]}")
        except Exception:
            self._unlink_config_file()
            self._process = None
            raise

    def _unlink_config_file(self) -> None:
        if self._config_path and self._config_path.exists():
            self._config_path.unlink(missing_ok=True)

    def stop(self) -> None:
        if self._process and self._process.poll() is None:
            self._process.send_signal(signal.SIGTERM)
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
        self._unlink_config_file()
        self._process = None
        self._config_path = None

    def is_running(self) -> bool:
        return self._process is not None and self._process.poll() is None
