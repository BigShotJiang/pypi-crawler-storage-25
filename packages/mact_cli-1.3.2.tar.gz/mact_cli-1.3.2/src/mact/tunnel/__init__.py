"""Tunnel abstraction for exposing local ports to the MACT server."""

from mact.tunnel.base import Tunnel
from mact.tunnel.frpc import FrpcTunnel

__all__ = ["Tunnel", "FrpcTunnel"]
