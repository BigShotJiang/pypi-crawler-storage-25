"""Download and cache the frpc binary on first use (GitHub releases)."""

from __future__ import annotations

import io
import os
import platform
import shutil
import stat
import sys
import tarfile
import zipfile
from pathlib import Path

import requests

# Pin a release for reproducible installs; override with MACT_FRP_VERSION=v0.xx.x
DEFAULT_FRP_VERSION = "0.61.0"


def _version_tag() -> str:
    raw = os.environ.get("MACT_FRP_VERSION", DEFAULT_FRP_VERSION).strip()
    return raw if raw.startswith("v") else f"v{raw}"


def _platform_asset_suffix() -> str:
    machine = platform.machine().lower()
    if sys.platform == "linux":
        arch = "arm64" if machine in ("aarch64", "arm64") else "amd64"
        return f"linux_{arch}"
    if sys.platform == "darwin":
        arch = "arm64" if machine in ("arm64", "aarch64") else "amd64"
        return f"darwin_{arch}"
    if sys.platform == "win32":
        return "windows_amd64"
    raise OSError(
        f"MACT: unsupported OS/arch for bundled frpc: {sys.platform}/{machine}"
    )


def _cache_dir() -> Path:
    base = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    return base / "mact" / "frp" / _version_tag().lstrip("v")


def _download_url() -> str:
    tag = _version_tag()
    suffix = _platform_asset_suffix()
    ext = "zip" if sys.platform == "win32" else "tar.gz"
    name = f"frp_{tag.lstrip('v')}_{suffix}.{ext}"
    return f"https://github.com/fatedier/frp/releases/download/{tag}/{name}"


def _extract_frpc(archive: Path, dest_dir: Path) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    if archive.suffix == ".zip":
        with zipfile.ZipFile(archive) as zf:
            names = [n for n in zf.namelist() if n.replace("\\", "/").endswith("frpc.exe")]
            if not names:
                raise RuntimeError("frpc.exe not found in frp zip archive")
            member = names[0]
            out = dest_dir / "frpc.exe"
            out.write_bytes(zf.read(member))
            return out
    with tarfile.open(archive, "r:*") as tf:
        member = next(
            (m for m in tf.getmembers() if m.name.endswith("/frpc") and m.isfile()),
            None,
        )
        if member is None:
            raise RuntimeError("frpc not found in frp tarball")
        f = tf.extractfile(member)
        if f is None:
            raise RuntimeError("could not read frpc from frp tarball")
        data = f.read()
        out = dest_dir / "frpc"
        out.write_bytes(data)
        return out


def ensure_frpc_executable() -> str:
    """
    Return a path to an ``frpc`` executable: PATH first, else a cached download.
    """
    existing = shutil.which("frpc")
    if existing:
        return existing

    dest_dir = _cache_dir()
    if sys.platform == "win32":
        cached = dest_dir / "frpc.exe"
    else:
        cached = dest_dir / "frpc"
    if cached.is_file():
        mode = cached.stat().st_mode
        if sys.platform != "win32" and not (mode & stat.S_IXUSR):
            cached.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        return str(cached)

    dest_dir.mkdir(parents=True, exist_ok=True)
    url = _download_url()
    resp = requests.get(url, timeout=120, stream=True)
    resp.raise_for_status()
    buf = io.BytesIO()
    for chunk in resp.iter_content(chunk_size=65536):
        if chunk:
            buf.write(chunk)
    buf.seek(0)
    ext = ".zip" if sys.platform == "win32" else ".tar.gz"
    tmp_archive = dest_dir / f"download{ext}"
    tmp_archive.write_bytes(buf.getvalue())
    try:
        frpc_path = _extract_frpc(tmp_archive, dest_dir)
    finally:
        tmp_archive.unlink(missing_ok=True)

    if sys.platform != "win32":
        mode = frpc_path.stat().st_mode
        frpc_path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    return str(frpc_path)
