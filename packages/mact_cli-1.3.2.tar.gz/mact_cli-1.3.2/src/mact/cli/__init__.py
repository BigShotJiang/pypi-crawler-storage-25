"""CLI package for MACT."""

