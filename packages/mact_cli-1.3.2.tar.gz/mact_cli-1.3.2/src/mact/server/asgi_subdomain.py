from __future__ import annotations

from starlette.datastructures import State
from starlette.types import ASGIApp, Receive, Scope, Send

from mact.server.settings import load_settings
from mact.server.subdomain import parse_room_from_host, should_rewrite_subdomain_path


class SubdomainRewriteMiddleware:
    """
    For requests to ``{room}.m-act.live``, rewrite the path to ``/r/{room}/...`` so the
    existing mirror handler runs. Dashboard stays at ``/dashboard`` on that host.

    Set ``MACT_PUBLIC_BASE_DOMAIN`` to empty to disable (local tests / path-only mode).
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        # Re-read settings so env changes in tests / reloads match the app lifespan.
        base = load_settings().public_base_domain
        if not base:
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers") or [])
        raw_host = headers.get(b"host", b"").decode("latin-1")
        host = raw_host.split(":")[0]
        room = parse_room_from_host(host, base)

        scope = dict(scope)
        # Starlette may leave scope["state"] as a plain dict in some stacks; only State
        # supports attribute assignment for request.state used by route handlers.
        if not isinstance(scope.get("state"), State):
            scope["state"] = State()
        if room:
            scope["state"].mact_room_from_host = room

        path = scope.get("path") or "/"
        if room and should_rewrite_subdomain_path(path):
            rest = path.lstrip("/")
            scope["path"] = f"/r/{room}" if not rest else f"/r/{room}/{rest}"

        await self.app(scope, receive, send)
