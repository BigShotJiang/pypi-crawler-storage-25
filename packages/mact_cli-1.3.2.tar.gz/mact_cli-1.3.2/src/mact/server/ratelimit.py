"""In-memory sliding-window rate limiter for MACT API endpoints."""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from threading import Lock

from fastapi import HTTPException, Request


@dataclass
class RateLimitConfig:
    """Max *requests* per *window_seconds* for a given key."""

    requests: int
    window_seconds: int


@dataclass
class _Bucket:
    timestamps: list[float] = field(default_factory=list)


class RateLimiter:
    """Thread-safe per-key sliding-window counter."""

    def __init__(self) -> None:
        self._lock = Lock()
        self._buckets: dict[str, _Bucket] = defaultdict(_Bucket)

    def check(self, key: str, config: RateLimitConfig) -> None:
        """Raise 429 if *key* has exceeded *config* limits."""
        now = time.monotonic()
        cutoff = now - config.window_seconds

        with self._lock:
            bucket = self._buckets[key]
            bucket.timestamps = [t for t in bucket.timestamps if t > cutoff]
            if len(bucket.timestamps) >= config.requests:
                raise HTTPException(
                    status_code=429,
                    detail="rate limit exceeded — try again later",
                )
            bucket.timestamps.append(now)

    def cleanup(self, max_age: float = 300.0) -> None:
        """Evict stale keys older than *max_age* seconds (call periodically)."""
        now = time.monotonic()
        cutoff = now - max_age
        with self._lock:
            stale = [k for k, b in self._buckets.items() if not b.timestamps or b.timestamps[-1] < cutoff]
            for k in stale:
                del self._buckets[k]


RATE_LIMITS: dict[str, RateLimitConfig] = {
    "/rooms": RateLimitConfig(requests=10, window_seconds=60),
    "join": RateLimitConfig(requests=20, window_seconds=60),
    "commits": RateLimitConfig(requests=60, window_seconds=60),
    "heartbeat": RateLimitConfig(requests=120, window_seconds=60),
    "disconnect": RateLimitConfig(requests=30, window_seconds=60),
    "comment": RateLimitConfig(requests=30, window_seconds=60),
}


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limit_key(request: Request, bucket_name: str) -> str:
    return f"{bucket_name}:{_client_ip(request)}"
