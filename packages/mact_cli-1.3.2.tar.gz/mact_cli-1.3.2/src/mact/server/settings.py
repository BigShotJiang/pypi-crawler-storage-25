from __future__ import annotations

import os
from dataclasses import dataclass

from mact.validation import upstream_url_is_loopback


@dataclass(frozen=True)
class Settings:
    """Loaded once per process from environment (see `load_settings`)."""

    database_url: str
    auto_create_tables: bool
    presence_ttl_seconds: int
    #: e.g. ``m-act.live`` for ``{room}.m-act.live``. Empty string disables subdomain routing.
    public_base_domain: str | None
    #: If true, heartbeats may register ``127.0.0.1`` / localhost upstreams (local dev only).
    allow_loopback_upstream: bool
    #: Tunnel host suffix for mirror/heartbeat URL policy (public mode). Empty env = suffix only optional.
    mirror_upstream_host_suffix: str | None


def load_settings() -> Settings:
    domain_raw = os.getenv("MACT_PUBLIC_BASE_DOMAIN", "m-act.live").strip()
    mirror_suffix_raw = os.getenv(
        "MACT_MIRROR_UPSTREAM_HOST_SUFFIX", "tunnel.m-act.live"
    ).strip()
    return Settings(
        database_url=os.getenv("DATABASE_URL", "sqlite:///./mact.db"),
        auto_create_tables=os.getenv("MACT_AUTO_CREATE_TABLES", "true").lower()
        in ("1", "true", "yes"),
        presence_ttl_seconds=int(os.getenv("MACT_PRESENCE_TTL_SECONDS", "60")),
        public_base_domain=domain_raw or None,
        allow_loopback_upstream=os.getenv("MACT_ALLOW_LOOPBACK_UPSTREAM", "").lower()
        in ("1", "true", "yes"),
        mirror_upstream_host_suffix=mirror_suffix_raw or None,
    )


def deployment_ignores_loopback_upstream(settings: Settings) -> bool:
    """Public deployments must not treat loopback URLs as the mirror upstream."""
    return bool(settings.public_base_domain) and not settings.allow_loopback_upstream


def member_starts_connected_for_upstream(settings: Settings, upstream_url: str) -> bool:
    """Avoid marking members live with loopback upstreams heartbeats will reject."""
    if deployment_ignores_loopback_upstream(settings) and upstream_url_is_loopback(
        upstream_url
    ):
        return False
    return True
