from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from fastapi import WebSocket

from mact.server.settings import deployment_ignores_loopback_upstream

logger = logging.getLogger(__name__)


class RoomEventBroker:
    """In-memory pub/sub for room status (one server process)."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._rooms: dict[str, set[WebSocket]] = {}

    async def connect(self, room_id: str, websocket: WebSocket) -> None:
        async with self._lock:
            self._rooms.setdefault(room_id, set()).add(websocket)

    async def disconnect(self, room_id: str, websocket: WebSocket) -> None:
        async with self._lock:
            if room_id in self._rooms:
                self._rooms[room_id].discard(websocket)
                if not self._rooms[room_id]:
                    del self._rooms[room_id]

    async def broadcast_json(self, room_id: str, data: dict[str, Any]) -> None:
        async with self._lock:
            sockets = list(self._rooms.get(room_id, ()))
        text = json.dumps(data, default=str)
        dead: list[WebSocket] = []
        for ws in sockets:
            try:
                await ws.send_text(text)
            except Exception:
                dead.append(ws)
        if dead:
            async with self._lock:
                for ws in dead:
                    self._rooms.get(room_id, set()).discard(ws)


def schedule_room_broadcast(app: Any, room_id: str) -> None:
    """Notify subscribers from sync route handlers (runs on thread pool)."""
    state = getattr(app, "state", None)
    if state is None:
        return
    loop = getattr(state, "main_loop", None)
    broker = getattr(state, "room_broker", None)
    if loop is None or broker is None:
        return

    async def _run() -> None:
        from mact.db import repository as repo

        SessionLocal = app.state.SessionLocal
        db = SessionLocal()
        settings = app.state.settings
        try:
            payload = repo.get_room_status(
                db,
                room_id,
                presence_ttl_seconds=settings.presence_ttl_seconds,
                ignore_loopback_upstream=deployment_ignores_loopback_upstream(settings),
            )
            msg = {"type": "room_status", "payload": payload}
            await broker.broadcast_json(room_id, msg)
        finally:
            db.close()

    try:
        fut = asyncio.run_coroutine_threadsafe(_run(), loop)

        def _log_err(f: asyncio.Future) -> None:
            try:
                f.result()
            except Exception as exc:  # noqa: BLE001
                logger.warning("room broadcast failed: %s", exc)

        fut.add_done_callback(_log_err)
    except RuntimeError:
        logger.warning("schedule_room_broadcast: could not schedule on main loop")
