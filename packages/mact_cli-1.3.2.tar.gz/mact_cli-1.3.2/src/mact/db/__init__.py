"""Database models and persistence."""

from mact.db.models import Base

__all__ = ["Base"]
