"""
工具函数测试

测试 utils 模块中的所有函数。
"""

import pytest
from decimal import Decimal
from example_package.utils import (
    greet, calculate_sum, format_date, validate_email,
    safe_divide, truncate_string, is_palindrome
)


class TestGreet:
    """测试 greet 函数"""
    
    def test_greet_default(self):
        """测试默认问候语"""
        result = greet("World")
        assert result == "Hello, World!"
    
    def test_greet_custom(self):
        """测试自定义问候语"""
        result = greet("Alice", "Hi")
        assert result == "Hi, Alice!"
    
    def test_greet_empty_name(self):
        """测试空名字"""
        result = greet("")
        assert result == "Hello, !"


class TestCalculateSum:
    """测试 calculate_sum 函数"""
    
    def test_calculate_sum_integers(self):
        """测试整数列表"""
        result = calculate_sum([1, 2, 3, 4, 5])
        assert result == 15
    
    def test_calculate_sum_floats(self):
        """测试浮点数列表"""
        result = calculate_sum([1.5, 2.5, 3.5])
        assert result == 7.5
    
    def test_calculate_sum_decimals(self):
        """测试 Decimal 列表"""
        result = calculate_sum([Decimal('1.5'), Decimal('2.5'), Decimal('3.5')])
        assert result == Decimal('7.5')
    
    def test_calculate_sum_mixed(self):
        """测试混合类型列表"""
        result = calculate_sum([1, 2.5, Decimal('3.5')])
        assert result == Decimal('7.0')
    
    def test_calculate_sum_empty(self):
        """测试空列表"""
        with pytest.raises(ValueError, match="数字列表不能为空"):
            calculate_sum([])
    
    def test_calculate_sum_single(self):
        """测试单个数字"""
        result = calculate_sum([42])
        assert result == 42


class TestFormatDate:
    """测试 format_date 函数"""
    
    def test_format_date_default(self):
        """测试默认格式"""
        result = format_date("2024-01-15")
        assert result == "2024年01月15日"
    
    def test_format_date_custom_format(self):
        """测试自定义格式"""
        result = format_date("15/01/2024", "%d/%m/%Y", "%d-%b-%Y")
        assert result == "15-Jan-2024"
    
    def test_format_date_invalid(self):
        """测试无效日期格式"""
        with pytest.raises(ValueError, match="日期格式错误"):
            format_date("invalid-date")
    
    def test_format_date_different_locale(self):
        """测试不同地区日期格式"""
        result = format_date("01/15/2024", "%m/%d/%Y", "%B %d, %Y")
        assert result == "January 15, 2024"


class TestValidateEmail:
    """测试 validate_email 函数"""
    
    def test_validate_email_valid(self):
        """测试有效电子邮件地址"""
        assert validate_email("user@example.com") is True
        assert validate_email("user.name@example.co.uk") is True
        assert validate_email("user+tag@example.com") is True
    
    def test_validate_email_invalid(self):
        """测试无效电子邮件地址"""
        assert validate_email("invalid-email") is False
        assert validate_email("user@") is False
        assert validate_email("@example.com") is False
        assert validate_email("user@example.") is False
    
    def test_validate_email_edge_cases(self):
        """测试边界情况"""
        assert validate_email("") is False
        assert validate_email("a@b.c") is True  # 最小有效电子邮件


class TestSafeDivide:
    """测试 safe_divide 函数"""
    
    def test_safe_divide_integers(self):
        """测试整数除法"""
        result = safe_divide(10, 2)
        assert result == 5.0
    
    def test_safe_divide_floats(self):
        """测试浮点数除法"""
        result = safe_divide(10.0, 2.0)
        assert result == 5.0
    
    def test_safe_divide_decimals(self):
        """测试 Decimal 除法"""
        result = safe_divide(Decimal('10'), Decimal('2'))
        assert result == Decimal('5')
    
    def test_safe_divide_by_zero(self):
        """测试除零"""
        result = safe_divide(10, 0)
        assert result is None
    
    def test_safe_divide_zero_by_zero(self):
        """测试零除以零"""
        result = safe_divide(0, 0)
        assert result is None
    
    def test_safe_divide_mixed_types(self):
        """测试混合类型除法"""
        result = safe_divide(10, Decimal('2'))
        assert result == Decimal('5')


class TestTruncateString:
    """测试 truncate_string 函数"""
    
    def test_truncate_string_short(self):
        """测试短字符串"""
        result = truncate_string("Hello", 10)
        assert result == "Hello"
    
    def test_truncate_string_long(self):
        """测试长字符串"""
        result = truncate_string("This is a very long string", 10)
        assert result == "This is a..."
    
    def test_truncate_string_exact_length(self):
        """测试恰好长度的字符串"""
        result = truncate_string("Exactly10", 9)
        assert result == "Exactly10"
    
    def test_truncate_string_custom_suffix(self):
        """测试自定义后缀"""
        result = truncate_string("Very long string", 10, " [more]")
        assert result == "Ver [more]"
    
    def test_truncate_string_empty(self):
        """测试空字符串"""
        result = truncate_string("", 10)
        assert result == ""


class TestIsPalindrome:
    """测试 is_palindrome 函数"""
    
    def test_is_palindrome_true(self):
        """测试回文字符串"""
        assert is_palindrome("racecar") is True
        assert is_palindrome("A man a plan a canal Panama") is True
        assert is_palindrome("12321") is True
    
    def test_is_palindrome_false(self):
        """测试非回文字符串"""
        assert is_palindrome("hello") is False
        assert is_palindrome("python") is False
        assert is_palindrome("12345") is False
    
    def test_is_palindrome_case_insensitive(self):
        """测试大小写不敏感"""
        assert is_palindrome("RaceCar") is True
        assert is_palindrome("Madam") is True
    
    def test_is_palindrome_with_punctuation(self):
        """测试带标点的回文"""
        assert is_palindrome("A man, a plan, a canal: Panama") is True
    
    def test_is_palindrome_single_character(self):
        """测试单字符"""
        assert is_palindrome("a") is True
        assert is_palindrome("1") is True
    
    def test_is_palindrome_empty(self):
        """测试空字符串"""
        assert is_palindrome("") is True