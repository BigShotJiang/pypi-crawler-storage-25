"""
API 测试

测试 api 模块中的所有类和方法。
注意：这些测试主要测试代码逻辑，不进行实际的网络请求。
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from example_package.api import (
    HttpMethod, ApiResponse, ApiError, ApiClient,
    fetch_data, post_data
)


class TestHttpMethod:
    """测试 HttpMethod 枚举"""
    
    def test_http_method_values(self):
        """测试枚举值"""
        assert HttpMethod.GET.value == "GET"
        assert HttpMethod.POST.value == "POST"
        assert HttpMethod.PUT.value == "PUT"
        assert HttpMethod.DELETE.value == "DELETE"
        assert HttpMethod.PATCH.value == "PATCH"
        assert HttpMethod.HEAD.value == "HEAD"
        assert HttpMethod.OPTIONS.value == "OPTIONS"


class TestApiResponse:
    """测试 ApiResponse 数据类"""
    
    def test_api_response_success(self):
        """测试成功响应"""
        response = ApiResponse(
            success=True,
            status_code=200,
            data={"key": "value"},
            headers={"Content-Type": "application/json"},
            elapsed_time=0.5
        )
        assert response.success is True
        assert response.status_code == 200
        assert response.data == {"key": "value"}
        assert response.headers == {"Content-Type": "application/json"}
        assert response.elapsed_time == 0.5
        assert response.error is None
    
    def test_api_response_error(self):
        """测试错误响应"""
        response = ApiResponse(
            success=False,
            status_code=404,
            error="Not Found",
            elapsed_time=0.1
        )
        assert response.success is False
        assert response.status_code == 404
        assert response.error == "Not Found"
        assert response.data is None
        assert response.headers == {}
        assert response.elapsed_time == 0.1
    
    def test_api_response_default_headers(self):
        """测试默认 headers"""
        response = ApiResponse(
            success=True,
            status_code=200,
            data="test"
        )
        assert response.headers == {}


class TestApiError:
    """测试 ApiError 异常"""
    
    def test_api_error_basic(self):
        """测试基本错误"""
        error = ApiError("Something went wrong")
        assert str(error) == "Something went wrong"
        assert error.message == "Something went wrong"
        assert error.status_code is None
        assert error.response is None
    
    def test_api_error_with_status_code(self):
        """测试带状态码的错误"""
        error = ApiError("Not Found", 404)
        assert str(error) == "Not Found (状态码: 404)"
        assert error.status_code == 404
    
    def test_api_error_with_response(self):
        """测试带响应的错误"""
        response = ApiResponse(success=False, status_code=500, error="Internal Server Error")
        error = ApiError("API Error", 500, response)
        assert error.response == response


class TestFetchData:
    """测试 fetch_data 函数"""
    
    @patch('example_package.api.requests.request')
    def test_fetch_data_success(self, mock_request):
        """测试成功获取数据"""
        # 模拟响应
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"key": "value"}
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.text = '{"key": "value"}'
        mock_request.return_value = mock_response
        
        response = fetch_data("https://api.example.com/data")
        
        assert response.success is True
        assert response.status_code == 200
        assert response.data == {"key": "value"}
        assert response.headers["Content-Type"] == "application/json"
        assert response.error is None
    
    @patch('example_package.api.requests.request')
    def test_fetch_data_with_params(self, mock_request):
        """测试带参数的获取数据"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_response.text = '{}'
        mock_request.return_value = mock_response
        
        params = {"page": 1, "limit": 10}
        headers = {"Authorization": "Bearer token"}
        
        fetch_data(
            "https://api.example.com/data",
            method=HttpMethod.GET,
            params=params,
            headers=headers,
            timeout=60
        )
        
        # 验证请求参数
        mock_request.assert_called_once_with(
            method="GET",
            url="https://api.example.com/data",
            params=params,
            headers=headers,
            timeout=60
        )
    
    @patch('example_package.api.requests.request')
    def test_fetch_data_error_response(self, mock_request):
        """测试错误响应"""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.json.return_value = {"error": "Not Found"}
        mock_response.headers = {}
        mock_response.text = '{"error": "Not Found"}'
        mock_request.return_value = mock_response
        
        response = fetch_data("https://api.example.com/nonexistent")
        
        assert response.success is False
        assert response.status_code == 404
        assert response.data == {"error": "Not Found"}
    
    @patch('example_package.api.requests.request')
    def test_fetch_data_timeout(self, mock_request):
        """测试超时"""
        mock_request.side_effect = Timeout("Request timed out")
        
        response = fetch_data("https://api.example.com/data", timeout=1)
        
        assert response.success is False
        assert response.status_code == 408
        assert "请求超时" in response.error
    
    @patch('example_package.api.requests.request')
    def test_fetch_data_connection_error(self, mock_request):
        """测试连接错误"""
        mock_request.side_effect = ConnectionError("Connection failed")
        
        response = fetch_data("https://api.example.com/data")
        
        assert response.success is False
        assert response.status_code == 0
        assert "连接错误" in response.error
    
    def test_fetch_data_requests_not_installed(self):
        """测试 requests 库未安装"""
        # 临时模拟 requests 不可用
        with patch('example_package.api.REQUESTS_AVAILABLE', False):
            with pytest.raises(ImportError, match="requests 库未安装"):
                fetch_data("https://api.example.com/data")


class TestPostData:
    """测试 post_data 函数"""
    
    @patch('example_package.api.requests.post')
    def test_post_data_success(self, mock_post):
        """测试成功发送 POST 请求"""
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": 123, "status": "created"}
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.text = '{"id": 123, "status": "created"}'
        mock_post.return_value = mock_response
        
        response = post_data(
            "https://api.example.com/data",
            json_data={"name": "test", "value": 42}
        )
        
        assert response.success is True
        assert response.status_code == 201
        assert response.data == {"id": 123, "status": "created"}
    
    @patch('example_package.api.requests.post')
    def test_post_data_with_form_data(self, mock_post):
        """测试发送表单数据"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_response.text = '{}'
        mock_post.return_value = mock_response
        
        post_data(
            "https://api.example.com/form",
            data={"field1": "value1", "field2": "value2"}
        )
        
        # 验证请求参数
        mock_post.assert_called_once_with(
            url="https://api.example.com/form",
            data={"field1": "value1", "field2": "value2"},
            json_data=None,
            headers=None,
            timeout=30
        )
    
    def test_post_data_requests_not_installed(self):
        """测试 requests 库未安装"""
        with patch('example_package.api.REQUESTS_AVAILABLE', False):
            with pytest.raises(ImportError, match="requests 库未安装"):
                post_data("https://api.example.com/data")


class TestApiClient:
    """测试 ApiClient 类"""
    
    def test_api_client_init(self):
        """测试初始化"""
        client = ApiClient(
            base_url="https://api.example.com",
            default_headers={"X-Custom-Header": "value"},
            timeout=60,
            max_retries=5,
            retry_delay=2.0
        )
        
        assert client.base_url == "https://api.example.com"
        assert client.default_headers["X-Custom-Header"] == "value"
        assert "User-Agent" in client.default_headers
        assert "Accept" in client.default_headers
        assert client.timeout == 60
        assert client.max_retries == 5
        assert client.retry_delay == 2.0
        assert client.session is not None
    
    def test_api_client_init_requests_not_installed(self):
        """测试 requests 库未安装时的初始化"""
        with patch('example_package.api.REQUESTS_AVAILABLE', False):
            with pytest.raises(ImportError, match="requests 库未安装"):
                ApiClient()
    
    @patch('example_package.api.requests.Session')
    def test_api_client_request_success(self, mock_session_class):
        """测试成功请求"""
        # 模拟会话和响应
        mock_session = Mock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"result": "success"}
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.text = '{"result": "success"}'
        mock_session.request.return_value = mock_response
        mock_session_class.return_value = mock_session
        
        client = ApiClient(base_url="https://api.example.com")
        response = client.request("data", HttpMethod.GET)
        
        assert response.success is True
        assert response.status_code == 200
        assert response.data == {"result": "success"}
        
        # 验证请求参数
        mock_session.request.assert_called_once_with(
            method="GET",
            url="https://api.example.com/data",
            params=None,
            data=None,
            json_data=None,
            headers=client.default_headers,
            timeout=30
        )
    
    @patch('example_package.api.requests.Session')
    def test_api_client_request_with_retry(self, mock_session_class):
        """测试带重试的请求"""
        mock_session = Mock()
        
        # 第一次失败，第二次成功
        mock_session.request.side_effect = [
            Timeout("First attempt timed out"),
            Mock(status_code=200, json=lambda: {"result": "success"}, 
                 headers={}, text='{"result": "success"}')
        ]
        
        mock_session_class.return_value = mock_session
        
        client = ApiClient(base_url="https://api.example.com", max_retries=3)
        response = client.request("data", HttpMethod.GET)
        
        assert response.success is True
        assert response.status_code == 200
        assert mock_session.request.call_count == 2
    
    @patch('example_package.api.requests.Session')
    def test_api_client_request_all_retries_fail(self, mock_session_class):
        """测试所有重试都失败"""
        mock_session = Mock()
        mock_session.request.side_effect = Timeout("Request timed out")
        mock_session_class.return_value = mock_session
        
        client = ApiClient(base_url="https://api.example.com", max_retries=2)
        response = client.request("data", HttpMethod.GET)
        
        assert response.success is False
        assert "所有重试都失败" in response.error
        assert mock_session.request.call_count == 2
    
    @patch('example_package.api.requests.Session')
    def test_api_client_get_method(self, mock_session_class):
        """测试 GET 方法"""
        mock_session = Mock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_response.text = '{}'
        mock_session.request.return_value = mock_response
        mock_session_class.return_value = mock_session
        
        client = ApiClient(base_url="https://api.example.com")
        response = client.get("data", params={"page": 1})
        
        assert response.success is True
        mock_session.request.assert_called_once_with(
            method="GET",
            url="https://api.example.com/data",
            params={"page": 1},
            data=None,
            json_data=None,
            headers=client.default_headers,
            timeout=30
        )
    
    @patch('example_package.api.requests.Session')
    def test_api_client_post_method(self, mock_session_class):
        """测试 POST 方法"""
        mock_session = Mock()
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {}
        mock_response.headers = {}
        mock_response.text = '{}'
        mock_session.request.return_value = mock_response
        mock_session_class.return_value = mock_session
        
        client = ApiClient(base_url="https://api.example.com")
        response = client.post("data", json_data={"name": "test"})
        
        assert response.success is True
        mock_session.request.assert_called_once_with(
            method="POST",
            url="https://api.example.com/data",
            params=None,
            data=None,
            json_data={"name": "test"},
            headers=client.default_headers,
            timeout=30
        )
    
    def test_api_client_set_auth_token(self):
        """测试设置认证令牌"""
        client = ApiClient()
        client.set_auth_token("test-token-123", "Bearer")
        
        assert client.default_headers["Authorization"] == "Bearer test-token-123"
    
    def test_api_client_clear_auth_token(self):
        """测试清除认证令牌"""
        client = ApiClient()
        client.default_headers["Authorization"] = "Bearer test-token"
        
        client.clear_auth_token()
        assert "Authorization" not in client.default_headers
    
    @patch('example_package.api.requests.Session')
    def test_api_client_context_manager(self, mock_session_class):
        """测试上下文管理器"""
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        
        with ApiClient() as client:
            assert client.session is not None
        
        # 验证会话已关闭
        mock_session.close.assert_called_once()
    
    def test_api_client_close(self):
        """测试关闭会话"""
        mock_session = Mock()
        client = ApiClient()
        client.session = mock_session
        
        client.close()
        mock_session.close.assert_called_once()