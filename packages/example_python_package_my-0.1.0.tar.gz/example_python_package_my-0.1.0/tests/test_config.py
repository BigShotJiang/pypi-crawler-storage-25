"""
配置管理测试

测试 config 模块中的所有类和方法。
"""

import pytest
import tempfile
import os
import json
import yaml
from pathlib import Path
from example_package.config import Config, ConfigManager


class TestConfig:
    """测试 Config 数据类"""
    
    def test_config_defaults(self):
        """测试默认值"""
        config = Config()
        assert config.debug is False
        assert config.log_level == "INFO"
        assert config.database_url == "sqlite:///database.db"
        assert config.api_timeout == 30
        assert config.max_retries == 3
        assert config.custom_settings == {}
    
    def test_config_custom_values(self):
        """测试自定义值"""
        config = Config(
            debug=True,
            log_level="DEBUG",
            database_url="postgresql://user:pass@localhost/db",
            api_timeout=60,
            max_retries=5,
            custom_settings={"key": "value"}
        )
        assert config.debug is True
        assert config.log_level == "DEBUG"
        assert config.database_url == "postgresql://user:pass@localhost/db"
        assert config.api_timeout == 60
        assert config.max_retries == 5
        assert config.custom_settings == {"key": "value"}
    
    def test_config_to_dict(self):
        """测试转换为字典"""
        config = Config(debug=True, custom_settings={"test": "value"})
        config_dict = config.__dict__
        assert config_dict["debug"] is True
        assert config_dict["custom_settings"] == {"test": "value"}


class TestConfigManager:
    """测试 ConfigManager 类"""
    
    def test_config_manager_default(self):
        """测试默认初始化"""
        manager = ConfigManager()
        assert manager.config_path is None
        assert manager.config_format == "auto"
        assert manager.is_loaded is False
    
    def test_config_manager_with_path(self):
        """测试带路径初始化"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write("debug: true\nlog_level: DEBUG")
            temp_path = f.name
        
        try:
            manager = ConfigManager(temp_path)
            assert manager.config_path == temp_path
            assert manager.is_loaded is True
            assert manager.get("debug") is True
            assert manager.get("log_level") == "DEBUG"
        finally:
            os.unlink(temp_path)
    
    def test_config_manager_load_yaml(self):
        """测试加载 YAML 文件"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write("""
debug: true
log_level: DEBUG
database_url: postgresql://localhost/test
api_timeout: 60
max_retries: 5
custom_settings:
  key1: value1
  key2: value2
""")
            temp_path = f.name
        
        try:
            manager = ConfigManager(temp_path, "yaml")
            assert manager.is_loaded is True
            
            # 测试获取值
            assert manager.get("debug") is True
            assert manager.get("log_level") == "DEBUG"
            assert manager.get("database_url") == "postgresql://localhost/test"
            assert manager.get("api_timeout") == 60
            assert manager.get("max_retries") == 5
            assert manager.get("custom_settings.key1") == "value1"
            assert manager.get("custom_settings.key2") == "value2"
            
            # 测试转换为字典
            config_dict = manager.to_dict()
            assert config_dict["debug"] is True
            assert config_dict["custom_settings"]["key1"] == "value1"
        finally:
            os.unlink(temp_path)
    
    def test_config_manager_load_json(self):
        """测试加载 JSON 文件"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump({
                "debug": True,
                "log_level": "DEBUG",
                "custom_settings": {"key": "value"}
            }, f)
            temp_path = f.name
        
        try:
            manager = ConfigManager(temp_path, "json")
            assert manager.is_loaded is True
            assert manager.get("debug") is True
            assert manager.get("log_level") == "DEBUG"
            assert manager.get("custom_settings.key") == "value"
        finally:
            os.unlink(temp_path)
    
    def test_config_manager_load_ini(self):
        """测试加载 INI 文件"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.ini', delete=False) as f:
            f.write("""[DEFAULT]
debug = true
log_level = DEBUG

[database]
url = postgresql://localhost/test
timeout = 30

[api]
timeout = 60
max_retries = 5
""")
            temp_path = f.name
        
        try:
            manager = ConfigManager(temp_path, "ini")
            assert manager.is_loaded is True
            
            # INI 文件加载后结构会有所不同
            # 这里主要测试是否能成功加载而不报错
            assert manager.get("debug") == "true"  # INI 中所有值都是字符串
        finally:
            os.unlink(temp_path)
    
    def test_config_manager_load_nonexistent(self):
        """测试加载不存在的文件"""
        manager = ConfigManager("nonexistent.yaml")
        assert manager.is_loaded is False
        
        with pytest.raises(FileNotFoundError):
            manager.load()
    
    def test_config_manager_set_and_get(self):
        """测试设置和获取值"""
        manager = ConfigManager()
        manager.from_dict({})
        
        # 测试设置和获取简单值
        manager.set("debug", True)
        assert manager.get("debug") is True
        
        # 测试设置和获取嵌套值
        manager.set("database.host", "localhost")
        manager.set("database.port", 5432)
        assert manager.get("database.host") == "localhost"
        assert manager.get("database.port") == 5432
        
        # 测试获取不存在的值
        assert manager.get("nonexistent") is None
        assert manager.get("nonexistent", "default") == "default"
    
    def test_config_manager_save_yaml(self):
        """测试保存 YAML 文件"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            temp_path = f.name
        
        try:
            manager = ConfigManager()
            manager.config_path = temp_path
            manager.config_format = "yaml"
            
            # 设置一些值
            manager.set("debug", True)
            manager.set("log_level", "DEBUG")
            manager.set("database.host", "localhost")
            
            # 保存文件
            manager.save()
            
            # 验证文件内容
            with open(temp_path, 'r') as f:
                content = yaml.safe_load(f)
            
            assert content["debug"] is True
            assert content["log_level"] == "DEBUG"
            assert content["database"]["host"] == "localhost"
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def test_config_manager_save_json(self):
        """测试保存 JSON 文件"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_path = f.name
        
        try:
            manager = ConfigManager()
            manager.config_path = temp_path
            manager.config_format = "json"
            
            # 设置一些值
            manager.set("debug", True)
            manager.set("custom.key", "value")
            
            # 保存文件
            manager.save()
            
            # 验证文件内容
            with open(temp_path, 'r') as f:
                content = json.load(f)
            
            assert content["debug"] is True
            assert content["custom"]["key"] == "value"
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def test_config_manager_dict_interface(self):
        """测试字典式接口"""
        manager = ConfigManager()
        manager.from_dict({})
        
        # 测试 __setitem__ 和 __getitem__
        manager["debug"] = True
        assert manager["debug"] is True
        
        # 测试 __contains__
        assert "debug" in manager
        assert "nonexistent" not in manager
    
    def test_config_manager_auto_detect_format(self):
        """测试自动检测文件格式"""
        test_cases = [
            ("config.yaml", "yaml"),
            ("config.yml", "yaml"),
            ("config.json", "json"),
            ("config.ini", "ini"),
            ("config.txt", "yaml"),  # 默认使用 YAML
        ]
        
        for filename, expected_format in test_cases:
            manager = ConfigManager(filename, "auto")
            # 由于文件不存在，我们无法实际加载，但可以测试格式检测逻辑
            # 这里我们直接测试内部方法
            detected = manager._detect_format(filename)
            assert detected == expected_format
    
    def test_config_manager_from_dict(self):
        """测试从字典加载"""
        manager = ConfigManager()
        
        config_dict = {
            "debug": True,
            "log_level": "DEBUG",
            "custom": {
                "key1": "value1",
                "key2": "value2"
            }
        }
        
        manager.from_dict(config_dict)
        assert manager.is_loaded is True
        assert manager.get("debug") is True
        assert manager.get("custom.key1") == "value1"
        assert manager.get("custom.key2") == "value2"