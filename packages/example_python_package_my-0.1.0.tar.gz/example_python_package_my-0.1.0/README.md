# Example Python Package

一个示例 Python 包，用于演示如何创建和发布到 PyPI。

## 功能特性

- **实用工具函数**: 提供常用的工具函数
- **命令行接口**: 提供简单的命令行工具
- **配置管理**: 支持配置文件管理
- **网络请求**: 封装常用的网络请求功能

## 安装

### 从 PyPI 安装

```bash
pip install example-python-package
```

### 从源代码安装

```bash
git clone https://github.com/example/example-python-package.git
cd example-python-package
pip install -e .
```

## 快速开始

### 使用 Python API

```python
from example_package.utils import greet, calculate_sum
from example_package.config import ConfigManager

# 使用工具函数
print(greet("World"))  # 输出: Hello, World!
print(calculate_sum([1, 2, 3, 4, 5]))  # 输出: 15

# 使用配置管理
config = ConfigManager("config.yaml")
value = config.get("key", "default")
```

### 使用命令行工具

```bash
# 显示帮助信息
example-cli --help

# 执行命令
example-cli greet --name "World"
example-cli calculate --numbers 1 2 3 4 5
```

## 开发指南

### 设置开发环境

1. 克隆仓库：
   ```bash
   git clone https://github.com/example/example-python-package.git
   cd example-python-package
   ```

2. 创建虚拟环境：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # 或
   venv\Scripts\activate  # Windows
   ```

3. 安装开发依赖：
   ```bash
   pip install -e ".[dev]"
   ```

### 运行测试

```bash
# 运行所有测试
pytest

# 运行测试并生成覆盖率报告
pytest --cov=example_package

# 运行特定测试
pytest tests/test_utils.py
```

### 代码质量检查

```bash
# 代码格式化
black src tests

# 代码检查
flake8 src tests

# 类型检查
mypy src
```

### 构建包

```bash
# 构建 wheel 和 sdist
python -m build

# 检查包质量
twine check dist/*
```

## 发布到 PyPI

### 测试发布到 TestPyPI

```bash
# 构建包
python -m build

# 上传到 TestPyPI
twine upload --repository testpypi dist/*
```

### 正式发布到 PyPI

```bash
# 构建包
python -m build

# 上传到 PyPI
twine upload dist/*
```

## 项目结构

```
example-python-package/
├── src/
│   └── example_package/
│       ├── __init__.py
│       ├── utils.py
│       ├── config.py
│       ├── api.py
│       └── cli.py
├── tests/
│   ├── __init__.py
│   ├── test_utils.py
│   ├── test_config.py
│   └── test_api.py
├── docs/
│   ├── index.md
│   └── api.md
├── pyproject.toml
├── README.md
├── LICENSE
└── .github/
    └── workflows/
        └── publish.yml
```

## 许可证

本项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

## 贡献指南

欢迎贡献！请阅读 [CONTRIBUTING.md](CONTRIBUTING.md) 了解如何参与项目开发。

## 支持

- 问题报告: [GitHub Issues](https://github.com/example/example-python-package/issues)
- 讨论: [GitHub Discussions](https://github.com/example/example-python-package/discussions)