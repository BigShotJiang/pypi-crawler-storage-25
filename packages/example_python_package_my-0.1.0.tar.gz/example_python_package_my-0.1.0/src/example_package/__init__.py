"""
Example Python Package

一个示例 Python 包，用于演示如何创建和发布到 PyPI。
"""

__version__ = "0.1.0"
__author__ = "Example Developer"
__email__ = "developer@example.com"

from .utils import greet, calculate_sum, format_date, validate_email
from .config import ConfigManager
from .api import fetch_data, post_data, ApiClient
from .cli import main as cli_main

__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    "__email__",
    
    # 工具函数
    "greet",
    "calculate_sum",
    "format_date",
    "validate_email",
    
    # 配置管理
    "ConfigManager",
    
    # API 功能
    "fetch_data",
    "post_data",
    "ApiClient",
    
    # 命令行接口
    "cli_main",
]