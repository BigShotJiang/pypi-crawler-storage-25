"""
命令行接口模块

提供命令行工具，方便用户使用包的功能。
"""

import sys
import json
import click
from typing import List, Optional
from pathlib import Path

from .utils import greet, calculate_sum, format_date, validate_email, is_palindrome
from .config import ConfigManager
from .api import fetch_data, ApiClient, HttpMethod


@click.group()
@click.version_option()
def main():
    """
    Example Python Package 命令行工具
    
    一个示例 Python 包，提供各种实用功能。
    """
    pass


@main.command()
@click.argument('name')
@click.option('--greeting', '-g', default='Hello', 
              help='问候语，默认为 "Hello"')
def greet_command(name: str, greeting: str):
    """
    生成问候语
    
    NAME: 要问候的名字
    """
    result = greet(name, greeting)
    click.echo(result)


@main.command()
@click.argument('numbers', nargs=-1, type=float)
def calculate(numbers: List[float]):
    """
    计算数字的总和
    
    NUMBERS: 要计算的数字（多个）
    """
    if not numbers:
        click.echo("错误：请提供至少一个数字", err=True)
        sys.exit(1)
    
    try:
        result = calculate_sum(numbers)
        click.echo(f"总和: {result}")
    except ValueError as e:
        click.echo(f"错误: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('date_string')
@click.option('--input-format', '-i', default='%Y-%m-%d',
              help='输入日期格式，默认为 "%%Y-%%m-%%d"')
@click.option('--output-format', '-o', default='%Y年%m月%d日',
              help='输出日期格式，默认为 "%%Y年%%m月%%d日"')
def format_date_command(date_string: str, input_format: str, output_format: str):
    """
    格式化日期
    
    DATE_STRING: 日期字符串
    """
    try:
        result = format_date(date_string, input_format, output_format)
        click.echo(f"格式化结果: {result}")
    except ValueError as e:
        click.echo(f"错误: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument('email')
def validate_email_command(email: str):
    """
    验证电子邮件地址
    
    EMAIL: 要验证的电子邮件地址
    """
    is_valid = validate_email(email)
    if is_valid:
        click.echo(f"✅ {email} 是有效的电子邮件地址")
    else:
        click.echo(f"❌ {email} 不是有效的电子邮件地址")
        sys.exit(1)


@main.command()
@click.argument('text')
def palindrome(text: str):
    """
    检查字符串是否是回文
    
    TEXT: 要检查的字符串
    """
    is_pal = is_palindrome(text)
    if is_pal:
        click.echo(f"✅ '{text}' 是回文")
    else:
        click.echo(f"❌ '{text}' 不是回文")


@main.group()
def config():
    """配置管理命令"""
    pass


@config.command()
@click.argument('config_file', type=click.Path())
@click.option('--format', '-f', type=click.Choice(['auto', 'yaml', 'json', 'ini']),
              default='auto', help='配置文件格式')
def load(config_file: str, format: str):
    """
    加载配置文件
    
    CONFIG_FILE: 配置文件路径
    """
    try:
        manager = ConfigManager(config_file, format)
        click.echo(f"✅ 配置文件加载成功: {config_file}")
        
        # 显示配置内容
        config_dict = manager.to_dict()
        click.echo("\n配置内容:")
        click.echo(json.dumps(config_dict, indent=2, ensure_ascii=False))
    except Exception as e:
        click.echo(f"❌ 加载配置文件失败: {e}", err=True)
        sys.exit(1)


@config.command()
@click.argument('config_file', type=click.Path())
@click.option('--format', '-f', type=click.Choice(['yaml', 'json', 'ini']),
              default='yaml', help='配置文件格式')
@click.option('--debug/--no-debug', default=False, help='是否启用调试模式')
@click.option('--log-level', type=click.Choice(['DEBUG', 'INFO', 'WARNING', 'ERROR']),
              default='INFO', help='日志级别')
@click.option('--database-url', help='数据库连接 URL')
def create(config_file: str, format: str, debug: bool, log_level: str, 
           database_url: Optional[str]):
    """
    创建配置文件
    
    CONFIG_FILE: 配置文件路径
    """
    try:
        manager = ConfigManager()
        manager.config_path = config_file
        manager.config_format = format
        
        # 设置配置值
        manager.set('debug', debug)
        manager.set('log_level', log_level)
        
        if database_url:
            manager.set('database_url', database_url)
        
        # 保存配置文件
        manager.save()
        click.echo(f"✅ 配置文件创建成功: {config_file}")
        
        # 显示文件内容
        if Path(config_file).exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                content = f.read()
            click.echo(f"\n文件内容:\n{content}")
    except Exception as e:
        click.echo(f"❌ 创建配置文件失败: {e}", err=True)
        sys.exit(1)


@main.group()
def api():
    """API 相关命令"""
    pass


@api.command()
@click.argument('url')
@click.option('--method', '-m', type=click.Choice(['GET', 'POST', 'PUT', 'DELETE']),
              default='GET', help='HTTP 方法')
@click.option('--timeout', '-t', type=int, default=30, help='超时时间（秒）')
@click.option('--output', '-o', type=click.Path(), help='输出文件路径')
def fetch(url: str, method: str, timeout: int, output: Optional[str]):
    """
    发送 HTTP 请求
    
    URL: 请求 URL
    """
    try:
        response = fetch_data(url, method, timeout=timeout)
        
        if response.success:
            click.echo(f"✅ 请求成功 (状态码: {response.status_code})")
            click.echo(f"响应时间: {response.elapsed_time:.2f}秒")
            
            # 格式化输出
            if isinstance(response.data, (dict, list)):
                output_data = json.dumps(response.data, indent=2, ensure_ascii=False)
            else:
                output_data = str(response.data)
            
            if output:
                with open(output, 'w', encoding='utf-8') as f:
                    f.write(output_data)
                click.echo(f"响应已保存到: {output}")
            else:
                click.echo("\n响应内容:")
                click.echo(output_data)
        else:
            click.echo(f"❌ 请求失败 (状态码: {response.status_code})", err=True)
            if response.error:
                click.echo(f"错误信息: {response.error}", err=True)
            sys.exit(1)
    except ImportError as e:
        click.echo(f"❌ {e}", err=True)
        click.echo("请安装 requests 库: pip install requests", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ 请求失败: {e}", err=True)
        sys.exit(1)


@api.command()
@click.argument('base_url')
@click.option('--endpoint', '-e', required=True, help='API 端点')
@click.option('--method', '-m', type=click.Choice(['GET', 'POST', 'PUT', 'DELETE']),
              default='GET', help='HTTP 方法')
@click.option('--token', '-t', help='认证令牌')
@click.option('--timeout', type=int, default=30, help='超时时间（秒）')
def client(base_url: str, endpoint: str, method: str, token: Optional[str], 
           timeout: int):
    """
    使用 API 客户端发送请求
    
    BASE_URL: 基础 URL
    """
    try:
        with ApiClient(base_url, timeout=timeout) as client:
            if token:
                client.set_auth_token(token)
            
            if method == 'GET':
                response = client.get(endpoint)
            elif method == 'POST':
                response = client.post(endpoint)
            elif method == 'PUT':
                response = client.put(endpoint)
            elif method == 'DELETE':
                response = client.delete(endpoint)
            else:
                click.echo(f"❌ 不支持的 HTTP 方法: {method}", err=True)
                sys.exit(1)
            
            if response.success:
                click.echo(f"✅ 请求成功 (状态码: {response.status_code})")
                
                # 格式化输出
                if isinstance(response.data, (dict, list)):
                    output_data = json.dumps(response.data, indent=2, ensure_ascii=False)
                else:
                    output_data = str(response.data)
                
                click.echo("\n响应内容:")
                click.echo(output_data)
            else:
                click.echo(f"❌ 请求失败 (状态码: {response.status_code})", err=True)
                if response.error:
                    click.echo(f"错误信息: {response.error}", err=True)
                sys.exit(1)
    except ImportError as e:
        click.echo(f"❌ {e}", err=True)
        click.echo("请安装 requests 库: pip install requests", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ 请求失败: {e}", err=True)
        sys.exit(1)


@main.command()
def version():
    """显示版本信息"""
    from . import __version__
    click.echo(f"Example Python Package 版本: {__version__}")


@main.command()
def info():
    """显示包信息"""
    from . import __version__, __author__, __email__
    
    click.echo("📦 Example Python Package")
    click.echo("=" * 40)
    click.echo(f"版本: {__version__}")
    click.echo(f"作者: {__author__}")
    click.echo(f"邮箱: {__email__}")
    click.echo("\n可用命令:")
    
    # 显示所有命令
    for name, cmd in main.commands.items():
        if cmd.help:
            click.echo(f"  {name:20} - {cmd.help.splitlines()[0]}")
        else:
            click.echo(f"  {name:20} - 无描述")


if __name__ == '__main__':
    main()