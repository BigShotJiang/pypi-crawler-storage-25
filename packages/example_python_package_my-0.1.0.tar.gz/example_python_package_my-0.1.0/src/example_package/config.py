"""
配置管理模块

提供配置文件读取、写入和管理功能，支持 YAML、JSON 和 INI 格式。
"""

import os
import json
import yaml
import configparser
from pathlib import Path
from typing import Any, Dict, Optional, Union
from dataclasses import dataclass, asdict, field


@dataclass
class Config:
    """配置数据类"""
    debug: bool = False
    log_level: str = "INFO"
    database_url: str = "sqlite:///database.db"
    api_timeout: int = 30
    max_retries: int = 3
    custom_settings: Dict[str, Any] = field(default_factory=dict)


class ConfigManager:
    """
    配置管理器
    
    支持多种配置文件格式（YAML、JSON、INI）的读取和写入。
    """
    
    def __init__(self, config_path: Optional[str] = None, 
                 config_format: str = "auto"):
        """
        初始化配置管理器
        
        Args:
            config_path: 配置文件路径，如果为 None 则使用默认路径
            config_format: 配置文件格式，可选值: "auto", "yaml", "json", "ini"
        """
        self.config_path = config_path
        self.config_format = config_format
        self._config = Config()
        self._loaded = False
        
        if config_path and os.path.exists(config_path):
            self.load()
    
    def load(self, config_path: Optional[str] = None) -> None:
        """
        加载配置文件
        
        Args:
            config_path: 配置文件路径，如果为 None 则使用初始化时设置的路径
        
        Raises:
            FileNotFoundError: 如果配置文件不存在
            ValueError: 如果配置文件格式不支持
        """
        if config_path:
            self.config_path = config_path
        
        if not self.config_path or not os.path.exists(self.config_path):
            raise FileNotFoundError(f"配置文件不存在: {self.config_path}")
        
        # 自动检测文件格式
        if self.config_format == "auto":
            self.config_format = self._detect_format(self.config_path)
        
        # 根据格式加载配置
        if self.config_format == "yaml":
            self._load_yaml()
        elif self.config_format == "json":
            self._load_json()
        elif self.config_format == "ini":
            self._load_ini()
        else:
            raise ValueError(f"不支持的配置文件格式: {self.config_format}")
        
        self._loaded = True
    
    def save(self, config_path: Optional[str] = None) -> None:
        """
        保存配置文件
        
        Args:
            config_path: 配置文件路径，如果为 None 则使用当前配置路径
        """
        if config_path:
            self.config_path = config_path
        
        if not self.config_path:
            raise ValueError("未指定配置文件路径")
        
        # 确保目录存在
        os.makedirs(os.path.dirname(os.path.abspath(self.config_path)), exist_ok=True)
        
        # 根据格式保存配置
        if self.config_format == "yaml":
            self._save_yaml()
        elif self.config_format == "json":
            self._save_json()
        elif self.config_format == "ini":
            self._save_ini()
        else:
            raise ValueError(f"不支持的配置文件格式: {self.config_format}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值
        
        Args:
            key: 配置键，支持点号分隔的嵌套键（如 "database.host"）
            default: 如果键不存在时返回的默认值
        
        Returns:
            配置值
        """
        if not self._loaded:
            self.load()
        
        # 将点号分隔的键转换为属性访问
        value = self._config
        for part in key.split('.'):
            if hasattr(value, part):
                value = getattr(value, part)
            elif isinstance(value, dict) and part in value:
                value = value[part]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any) -> None:
        """
        设置配置值
        
        Args:
            key: 配置键，支持点号分隔的嵌套键（如 "database.host"）
            value: 配置值
        """
        if not self._loaded:
            self._config = Config()
            self._loaded = True
        
        # 将点号分隔的键转换为属性设置
        parts = key.split('.')
        target = self._config
        
        # 遍历到倒数第二部分
        for part in parts[:-1]:
            if hasattr(target, part):
                target = getattr(target, part)
            elif isinstance(target, dict) and part in target:
                target = target[part]
            else:
                # 创建新的字典或对象
                if hasattr(target, '__dict__'):
                    setattr(target, part, {})
                    target = getattr(target, part)
                else:
                    target[part] = {}
                    target = target[part]
        
        # 设置最后一部分的值
        last_part = parts[-1]
        if hasattr(target, '__dict__'):
            setattr(target, last_part, value)
        else:
            target[last_part] = value
    
    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典
        
        Returns:
            配置字典
        """
        return asdict(self._config)
    
    def from_dict(self, config_dict: Dict[str, Any]) -> None:
        """
        从字典加载配置
        
        Args:
            config_dict: 配置字典
        """
        self._config = Config(**config_dict)
        self._loaded = True
    
    def _detect_format(self, file_path: str) -> str:
        """检测文件格式"""
        ext = Path(file_path).suffix.lower()
        
        if ext in ['.yaml', '.yml']:
            return "yaml"
        elif ext == '.json':
            return "json"
        elif ext == '.ini':
            return "ini"
        else:
            # 默认使用 YAML
            return "yaml"
    
    def _load_yaml(self) -> None:
        """加载 YAML 配置文件"""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config_dict = yaml.safe_load(f) or {}
        self.from_dict(config_dict)
    
    def _load_json(self) -> None:
        """加载 JSON 配置文件"""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config_dict = json.load(f)
        self.from_dict(config_dict)
    
    def _load_ini(self) -> None:
        """加载 INI 配置文件"""
        parser = configparser.ConfigParser()
        parser.read(self.config_path, encoding='utf-8')
        
        config_dict = {}
        for section in parser.sections():
            config_dict[section] = dict(parser.items(section))
        
        self.from_dict(config_dict)
    
    def _save_yaml(self) -> None:
        """保存 YAML 配置文件"""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False, allow_unicode=True)
    
    def _save_json(self) -> None:
        """保存 JSON 配置文件"""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
    
    def _save_ini(self) -> None:
        """保存 INI 配置文件"""
        config_dict = self.to_dict()
        parser = configparser.ConfigParser()
        
        # 将字典转换为 INI 格式
        for key, value in config_dict.items():
            if isinstance(value, dict):
                parser[key] = value
            else:
                # 将非字典值放在 DEFAULT 节
                if 'DEFAULT' not in parser:
                    parser['DEFAULT'] = {}
                parser['DEFAULT'][key] = str(value)
        
        with open(self.config_path, 'w', encoding='utf-8') as f:
            parser.write(f)
    
    def __getitem__(self, key: str) -> Any:
        """支持字典式访问"""
        return self.get(key)
    
    def __setitem__(self, key: str, value: Any) -> None:
        """支持字典式设置"""
        self.set(key, value)
    
    def __contains__(self, key: str) -> bool:
        """检查键是否存在"""
        return self.get(key) is not None
    
    @property
    def is_loaded(self) -> bool:
        """检查配置是否已加载"""
        return self._loaded