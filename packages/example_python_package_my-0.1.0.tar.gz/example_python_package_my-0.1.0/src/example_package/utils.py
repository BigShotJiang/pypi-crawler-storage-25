"""
工具函数模块

提供常用的工具函数，包括字符串处理、数学计算、日期格式化和验证等功能。
"""

import re
from datetime import datetime
from typing import List, Union, Optional
from decimal import Decimal, InvalidOperation


def greet(name: str, greeting: str = "Hello") -> str:
    """
    生成问候语
    
    Args:
        name: 要问候的名字
        greeting: 问候语，默认为 "Hello"
    
    Returns:
        格式化后的问候语
    
    Examples:
        >>> greet("World")
        'Hello, World!'
        >>> greet("Alice", "Hi")
        'Hi, Alice!'
    """
    return f"{greeting}, {name}!"


def calculate_sum(numbers: List[Union[int, float, Decimal]]) -> Union[int, float, Decimal]:
    """
    计算数字列表的总和
    
    Args:
        numbers: 数字列表
    
    Returns:
        所有数字的总和
    
    Raises:
        ValueError: 如果列表为空
    
    Examples:
        >>> calculate_sum([1, 2, 3])
        6
        >>> calculate_sum([1.5, 2.5, 3.5])
        7.5
    """
    if not numbers:
        raise ValueError("数字列表不能为空")
    
    # 检查列表中是否包含 Decimal 类型
    has_decimal = any(isinstance(n, Decimal) for n in numbers)
    
    if has_decimal:
        total = Decimal('0')
        for num in numbers:
            if isinstance(num, Decimal):
                total += num
            else:
                total += Decimal(str(num))
        return total
    else:
        # 检查列表中是否包含浮点数
        has_float = any(isinstance(n, float) for n in numbers)
        
        if has_float:
            total = 0.0
            for num in numbers:
                total += float(num)
            return total
        else:
            total = 0
            for num in numbers:
                total += int(num)
            return total


def format_date(date_string: str, input_format: str = "%Y-%m-%d", 
                output_format: str = "%Y年%m月%d日") -> str:
    """
    格式化日期字符串
    
    Args:
        date_string: 日期字符串
        input_format: 输入日期格式，默认为 "%Y-%m-%d"
        output_format: 输出日期格式，默认为 "%Y年%m月%d日"
    
    Returns:
        格式化后的日期字符串
    
    Raises:
        ValueError: 如果日期字符串格式不正确
    
    Examples:
        >>> format_date("2024-01-15")
        '2024年01月15日'
        >>> format_date("15/01/2024", "%d/%m/%Y", "%d-%b-%Y")
        '15-Jan-2024'
    """
    try:
        date_obj = datetime.strptime(date_string, input_format)
        return date_obj.strftime(output_format)
    except ValueError as e:
        raise ValueError(f"日期格式错误: {date_string} (期望格式: {input_format})") from e


def validate_email(email: str) -> bool:
    """
    验证电子邮件地址格式
    
    Args:
        email: 要验证的电子邮件地址
    
    Returns:
        如果电子邮件地址格式有效则返回 True，否则返回 False
    
    Examples:
        >>> validate_email("user@example.com")
        True
        >>> validate_email("invalid-email")
        False
    """
    # 简单的电子邮件验证正则表达式
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def safe_divide(dividend: Union[int, float, Decimal], 
                divisor: Union[int, float, Decimal]) -> Optional[Union[int, float, Decimal]]:
    """
    安全除法，避免除零错误
    
    Args:
        dividend: 被除数
        divisor: 除数
    
    Returns:
        除法结果，如果除数为零则返回 None
    
    Examples:
        >>> safe_divide(10, 2)
        5.0
        >>> safe_divide(10, 0) is None
        True
    """
    if divisor == 0:
        return None
    
    try:
        if isinstance(dividend, Decimal) or isinstance(divisor, Decimal):
            dividend_dec = dividend if isinstance(dividend, Decimal) else Decimal(str(dividend))
            divisor_dec = divisor if isinstance(divisor, Decimal) else Decimal(str(divisor))
            return dividend_dec / divisor_dec
        else:
            return float(dividend) / float(divisor)
    except (InvalidOperation, ZeroDivisionError):
        return None


def truncate_string(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """
    截断字符串到指定长度
    
    Args:
        text: 要截断的字符串
        max_length: 最大长度
        suffix: 截断后添加的后缀
    
    Returns:
        截断后的字符串
    
    Examples:
        >>> truncate_string("This is a very long string that needs to be truncated", 20)
        'This is a very long...'
    """
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def is_palindrome(text: str) -> bool:
    """
    检查字符串是否是回文
    
    Args:
        text: 要检查的字符串
    
    Returns:
        如果是回文则返回 True，否则返回 False
    
    Examples:
        >>> is_palindrome("racecar")
        True
        >>> is_palindrome("hello")
        False
    """
    # 移除空格和标点，转换为小写
    cleaned = re.sub(r'[^a-zA-Z0-9]', '', text).lower()
    return cleaned == cleaned[::-1]