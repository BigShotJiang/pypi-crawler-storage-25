"""
API 模块

提供网络请求功能，包括 HTTP 请求、API 客户端和错误处理。
"""

import json
import time
from typing import Any, Dict, Optional, Union
from dataclasses import dataclass, asdict
from enum import Enum

try:
    import requests
    from requests.exceptions import RequestException, Timeout, ConnectionError
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


class HttpMethod(Enum):
    """HTTP 方法枚举"""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


@dataclass
class ApiResponse:
    """API 响应数据类"""
    success: bool
    status_code: int
    data: Optional[Any] = None
    error: Optional[str] = None
    headers: Dict[str, str] = None
    elapsed_time: float = 0.0
    
    def __post_init__(self):
        if self.headers is None:
            self.headers = {}


class ApiError(Exception):
    """API 错误异常"""
    
    def __init__(self, message: str, status_code: Optional[int] = None,
                 response: Optional[ApiResponse] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response
    
    def __str__(self) -> str:
        if self.status_code:
            return f"{self.message} (状态码: {self.status_code})"
        return self.message


def fetch_data(url: str, method: Union[str, HttpMethod] = HttpMethod.GET,
               params: Optional[Dict[str, Any]] = None,
               headers: Optional[Dict[str, str]] = None,
               timeout: int = 30) -> ApiResponse:
    """
    获取数据
    
    Args:
        url: 请求 URL
        method: HTTP 方法
        params: 查询参数
        headers: 请求头
        timeout: 超时时间（秒）
    
    Returns:
        ApiResponse 对象
    
    Raises:
        ImportError: 如果 requests 库未安装
    """
    if not REQUESTS_AVAILABLE:
        raise ImportError("requests 库未安装，请运行: pip install requests")
    
    # 转换方法为字符串
    if isinstance(method, HttpMethod):
        method = method.value
    
    start_time = time.time()
    
    try:
        response = requests.request(
            method=method,
            url=url,
            params=params,
            headers=headers,
            timeout=timeout
        )
        
        elapsed_time = time.time() - start_time
        
        # 尝试解析 JSON 响应
        try:
            data = response.json()
        except json.JSONDecodeError:
            data = response.text
        
        return ApiResponse(
            success=response.status_code < 400,
            status_code=response.status_code,
            data=data,
            headers=dict(response.headers),
            elapsed_time=elapsed_time
        )
        
    except Timeout as e:
        elapsed_time = time.time() - start_time
        return ApiResponse(
            success=False,
            status_code=408,
            error=f"请求超时: {str(e)}",
            elapsed_time=elapsed_time
        )
    except ConnectionError as e:
        elapsed_time = time.time() - start_time
        return ApiResponse(
            success=False,
            status_code=0,
            error=f"连接错误: {str(e)}",
            elapsed_time=elapsed_time
        )
    except RequestException as e:
        elapsed_time = time.time() - start_time
        return ApiResponse(
            success=False,
            status_code=0,
            error=f"请求错误: {str(e)}",
            elapsed_time=elapsed_time
        )


def post_data(url: str, data: Optional[Dict[str, Any]] = None,
              json_data: Optional[Dict[str, Any]] = None,
              headers: Optional[Dict[str, str]] = None,
              timeout: int = 30) -> ApiResponse:
    """
    发送 POST 请求
    
    Args:
        url: 请求 URL
        data: 表单数据
        json_data: JSON 数据
        headers: 请求头
        timeout: 超时时间（秒）
    
    Returns:
        ApiResponse 对象
    
    Raises:
        ImportError: 如果 requests 库未安装
    """
    if not REQUESTS_AVAILABLE:
        raise ImportError("requests 库未安装，请运行: pip install requests")
    
    start_time = time.time()
    
    try:
        if json_data is not None:
            response = requests.post(
                url=url,
                json=json_data,
                headers=headers,
                timeout=timeout
            )
        else:
            response = requests.post(
                url=url,
                data=data,
                headers=headers,
                timeout=timeout
            )
        
        elapsed_time = time.time() - start_time
        
        # 尝试解析 JSON 响应
        try:
            response_data = response.json()
        except json.JSONDecodeError:
            response_data = response.text
        
        return ApiResponse(
            success=response.status_code < 400,
            status_code=response.status_code,
            data=response_data,
            headers=dict(response.headers),
            elapsed_time=elapsed_time
        )
        
    except Timeout as e:
        elapsed_time = time.time() - start_time
        return ApiResponse(
            success=False,
            status_code=408,
            error=f"请求超时: {str(e)}",
            elapsed_time=elapsed_time
        )
    except ConnectionError as e:
        elapsed_time = time.time() - start_time
        return ApiResponse(
            success=False,
            status_code=0,
            error=f"连接错误: {str(e)}",
            elapsed_time=elapsed_time
        )
    except RequestException as e:
        elapsed_time = time.time() - start_time
        return ApiResponse(
            success=False,
            status_code=0,
            error=f"请求错误: {str(e)}",
            elapsed_time=elapsed_time
        )


class ApiClient:
    """
    API 客户端
    
    提供高级 API 调用功能，包括重试、认证和错误处理。
    """
    
    def __init__(self, base_url: str = "", 
                 default_headers: Optional[Dict[str, str]] = None,
                 timeout: int = 30,
                 max_retries: int = 3,
                 retry_delay: float = 1.0):
        """
        初始化 API 客户端
        
        Args:
            base_url: 基础 URL
            default_headers: 默认请求头
            timeout: 默认超时时间（秒）
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
        """
        if not REQUESTS_AVAILABLE:
            raise ImportError("requests 库未安装，请运行: pip install requests")
        
        self.base_url = base_url.rstrip('/')
        self.default_headers = default_headers or {}
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.session = requests.Session()
        
        # 设置默认请求头
        if 'User-Agent' not in self.default_headers:
            self.default_headers['User-Agent'] = 'ExamplePythonPackage/0.1.0'
        if 'Accept' not in self.default_headers:
            self.default_headers['Accept'] = 'application/json'
    
    def request(self, endpoint: str, method: Union[str, HttpMethod] = HttpMethod.GET,
                params: Optional[Dict[str, Any]] = None,
                data: Optional[Dict[str, Any]] = None,
                json_data: Optional[Dict[str, Any]] = None,
                headers: Optional[Dict[str, str]] = None,
                timeout: Optional[int] = None) -> ApiResponse:
        """
        发送请求
        
        Args:
            endpoint: API 端点
            method: HTTP 方法
            params: 查询参数
            data: 表单数据
            json_data: JSON 数据
            headers: 请求头
            timeout: 超时时间（秒），如果为 None 则使用默认值
        
        Returns:
            ApiResponse 对象
        """
        # 构建完整 URL
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        # 合并请求头
        request_headers = {**self.default_headers, **(headers or {})}
        
        # 使用指定的超时时间或默认值
        request_timeout = timeout or self.timeout
        
        # 重试逻辑
        last_error = None
        for attempt in range(self.max_retries):
            try:
                if attempt > 0:
                    time.sleep(self.retry_delay * attempt)  # 指数退避
                
                response = self.session.request(
                    method=method.value if isinstance(method, HttpMethod) else method,
                    url=url,
                    params=params,
                    data=data,
                    json=json_data,
                    headers=request_headers,
                    timeout=request_timeout
                )
                
                # 尝试解析 JSON 响应
                try:
                    response_data = response.json()
                except json.JSONDecodeError:
                    response_data = response.text
                
                return ApiResponse(
                    success=response.status_code < 400,
                    status_code=response.status_code,
                    data=response_data,
                    headers=dict(response.headers),
                    elapsed_time=0.0  # 实际时间需要在调用处计算
                )
                
            except (Timeout, ConnectionError) as e:
                last_error = e
                if attempt == self.max_retries - 1:
                    return ApiResponse(
                        success=False,
                        status_code=408 if isinstance(e, Timeout) else 0,
                        error=f"请求失败: {str(e)}",
                        elapsed_time=0.0
                    )
            except RequestException as e:
                last_error = e
                return ApiResponse(
                    success=False,
                    status_code=0,
                    error=f"请求错误: {str(e)}",
                    elapsed_time=0.0
                )
        
        # 如果所有重试都失败
        return ApiResponse(
            success=False,
            status_code=0,
            error=f"所有重试都失败: {str(last_error)}",
            elapsed_time=0.0
        )
    
    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None,
            headers: Optional[Dict[str, str]] = None,
            timeout: Optional[int] = None) -> ApiResponse:
        """发送 GET 请求"""
        return self.request(endpoint, HttpMethod.GET, params=params, 
                           headers=headers, timeout=timeout)
    
    def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None,
             json_data: Optional[Dict[str, Any]] = None,
             headers: Optional[Dict[str, str]] = None,
             timeout: Optional[int] = None) -> ApiResponse:
        """发送 POST 请求"""
        return self.request(endpoint, HttpMethod.POST, data=data, json_data=json_data,
                           headers=headers, timeout=timeout)
    
    def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None,
            json_data: Optional[Dict[str, Any]] = None,
            headers: Optional[Dict[str, str]] = None,
            timeout: Optional[int] = None) -> ApiResponse:
        """发送 PUT 请求"""
        return self.request(endpoint, HttpMethod.PUT, data=data, json_data=json_data,
                           headers=headers, timeout=timeout)
    
    def delete(self, endpoint: str, headers: Optional[Dict[str, str]] = None,
               timeout: Optional[int] = None) -> ApiResponse:
        """发送 DELETE 请求"""
        return self.request(endpoint, HttpMethod.DELETE, headers=headers, 
                           timeout=timeout)
    
    def set_auth_token(self, token: str, token_type: str = "Bearer") -> None:
        """
        设置认证令牌
        
        Args:
            token: 认证令牌
            token_type: 令牌类型，默认为 "Bearer"
        """
        self.default_headers['Authorization'] = f"{token_type} {token}"
    
    def clear_auth_token(self) -> None:
        """清除认证令牌"""
        if 'Authorization' in self.default_headers:
            del self.default_headers['Authorization']
    
    def close(self) -> None:
        """关闭会话"""
        self.session.close()
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()