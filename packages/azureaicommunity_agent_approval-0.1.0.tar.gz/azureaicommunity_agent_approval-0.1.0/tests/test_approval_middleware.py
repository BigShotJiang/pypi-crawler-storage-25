"""Unit tests for ApprovalMiddleware.

Covers:
- Non-gated tools bypass the approval gate entirely
- Approved gated tools execute normally via call_next()
- Denied gated tools (False) get denial message as result
- Denied gated tools (None) get denial message as result
- Sync callbacks are supported
- Async callbacks are supported
- Custom denial_message template is respected
- Constructor validation: empty approval_tools raises ValueError
- Constructor validation: None approval_callback raises ValueError
"""
from __future__ import annotations

import pytest
from agent_framework import FunctionInvocationContext
from agent_framework._tools import FunctionTool

from approval_middleware import ApprovalMiddleware


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_function(name: str) -> FunctionTool:
    """Return a minimal FunctionTool with the given name."""
    return FunctionTool(name=name, func=None, input_model={})


def _make_context(tool_name: str) -> FunctionInvocationContext:
    return FunctionInvocationContext(
        function=_make_function(tool_name),
        arguments={},
    )


async def _noop() -> None:
    pass


# ---------------------------------------------------------------------------
# Constructor validation
# ---------------------------------------------------------------------------


def test_empty_approval_tools_raises() -> None:
    with pytest.raises(ValueError, match="approval_tools must not be empty"):
        ApprovalMiddleware(
            approval_tools=[],
            approval_callback=lambda ctx: True,
        )


def test_none_approval_callback_raises() -> None:
    with pytest.raises((ValueError, TypeError)):
        ApprovalMiddleware(
            approval_tools=["some_tool"],
            approval_callback=None,  # type: ignore[arg-type]
        )


# ---------------------------------------------------------------------------
# Non-gated tools — transparent pass-through
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_non_gated_tool_calls_next_without_callback() -> None:
    callback_invoked = False

    async def callback(ctx: FunctionInvocationContext) -> bool | None:
        nonlocal callback_invoked
        callback_invoked = True
        return True

    mw = ApprovalMiddleware(
        approval_tools=["gated_tool"],
        approval_callback=callback,
    )
    ctx = _make_context("free_tool")
    called = False

    async def mark_called() -> None:
        nonlocal called
        called = True

    await mw.process(ctx, mark_called)

    assert called, "call_next must be invoked for non-gated tools"
    assert not callback_invoked, "callback must NOT be invoked for non-gated tools"


# ---------------------------------------------------------------------------
# Approved gated tools
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_callback_approves_gated_tool() -> None:
    async def approve(ctx: FunctionInvocationContext) -> bool:
        return True

    mw = ApprovalMiddleware(approval_tools=["turn_on"], approval_callback=approve)
    ctx = _make_context("turn_on")
    called = False

    async def mark_called() -> None:
        nonlocal called
        called = True

    await mw.process(ctx, mark_called)

    assert called, "call_next must be invoked when callback returns True"
    assert ctx.result is None, "result must not be set on approval"


@pytest.mark.asyncio
async def test_sync_callback_approves_gated_tool() -> None:
    def approve(ctx: FunctionInvocationContext) -> bool:
        return True

    mw = ApprovalMiddleware(approval_tools=["turn_on"], approval_callback=approve)
    ctx = _make_context("turn_on")
    called = False

    async def mark_called() -> None:
        nonlocal called
        called = True

    await mw.process(ctx, mark_called)

    assert called
    assert ctx.result is None


# ---------------------------------------------------------------------------
# Denied gated tools
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_callback_returning_false_sets_denial_result() -> None:
    async def deny(ctx: FunctionInvocationContext) -> bool:
        return False

    mw = ApprovalMiddleware(approval_tools=["turn_off"], approval_callback=deny)
    ctx = _make_context("turn_off")
    called = False

    async def mark_called() -> None:
        nonlocal called
        called = True

    await mw.process(ctx, mark_called)

    assert not called, "call_next must NOT be invoked when denied"
    assert ctx.result is not None, "result must be set to denial message"
    assert "turn_off" in ctx.result


@pytest.mark.asyncio
async def test_callback_returning_none_sets_denial_result() -> None:
    async def deny(ctx: FunctionInvocationContext) -> None:
        return None

    mw = ApprovalMiddleware(approval_tools=["turn_off"], approval_callback=deny)
    ctx = _make_context("turn_off")
    called = False

    async def mark_called() -> None:
        nonlocal called
        called = True

    await mw.process(ctx, mark_called)

    assert not called
    assert ctx.result is not None
    assert "turn_off" in ctx.result


# ---------------------------------------------------------------------------
# Custom denial message
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_custom_denial_message_template() -> None:
    async def deny(ctx: FunctionInvocationContext) -> bool:
        return False

    mw = ApprovalMiddleware(
        approval_tools=["risky_op"],
        approval_callback=deny,
        denial_message="Operation '{tool_name}' was blocked by the user.",
    )
    ctx = _make_context("risky_op")
    await mw.process(ctx, _noop)

    assert ctx.result == "Operation 'risky_op' was blocked by the user."


# ---------------------------------------------------------------------------
# Multiple tools — partial gating
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_only_listed_tools_are_gated() -> None:
    """Of three tools, only two are gated; the third runs freely."""
    approved_calls: list[str] = []

    async def track_and_approve(ctx: FunctionInvocationContext) -> bool:
        approved_calls.append(ctx.function.name)
        return True

    mw = ApprovalMiddleware(
        approval_tools=["turn_on", "turn_off"],
        approval_callback=track_and_approve,
    )

    for tool_name in ["get_status", "turn_on", "turn_off"]:
        ctx = _make_context(tool_name)
        await mw.process(ctx, _noop)

    # Only gated tools should appear in the callback log
    assert approved_calls == ["turn_on", "turn_off"]
