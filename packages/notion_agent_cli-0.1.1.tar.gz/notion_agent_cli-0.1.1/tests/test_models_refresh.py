"""Unit tests for the models-refresh subsystem.

Covers:

- :func:`parse_available_models` against a real captured Notion
  ``/getAvailableModels`` response (``tests/fixtures/get_available_models.json``).
- :func:`load_user_model_map` / :func:`save_user_model_map` round-trip
  + malformed input tolerance.
- :func:`resolve_model` with ``user_map`` override (precedence vs
  :data:`DEFAULT_MODEL_MAP`, including passthrough of overridden ids).
- :meth:`NotionAgentClient.fetch_available_models` via
  ``httpx.MockTransport`` (happy path + 401 surface).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from notion_agent_cli import NotionAgentClient, NotionAgentError
from notion_agent_cli.models import (
    DEFAULT_MODEL_MAP,
    load_user_model_map,
    parse_available_models,
    resolve_model,
    save_user_model_map,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _load_fixture(name: str) -> dict[str, Any]:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


# --------------------------------------------------------------------------- #
# parse_available_models — against captured live response
# --------------------------------------------------------------------------- #

class TestParseAvailableModels:
    def test_real_response_matches_default_map_entries(self):
        data = _load_fixture("get_available_models.json")
        aliases = parse_available_models(data)
        # Every alias currently hard-coded in DEFAULT_MODEL_MAP should
        # resolve to the same Notion id in the live response — drift
        # detector. If this test fails, /getAvailableModels has renamed
        # something and DEFAULT_MODEL_MAP needs updating.
        for friendly, expected_id in DEFAULT_MODEL_MAP.items():
            if friendly in aliases:
                assert aliases[friendly] == expected_id, (
                    f"DEFAULT_MODEL_MAP[{friendly!r}] = {expected_id!r} "
                    f"but Notion now reports {aliases[friendly]!r}"
                )

    def test_real_response_yields_known_aliases(self):
        aliases = parse_available_models(_load_fixture("get_available_models.json"))
        assert aliases["opus-4.7"] == "apricot-sorbet-high"
        assert aliases["sonnet-4.6"] == "almond-croissant-low"
        assert aliases["haiku-4.5"] == "anthropic-haiku-4.5"

    def test_real_response_surfaces_new_models(self):
        """Models present in /getAvailableModels but missing from DEFAULT_MODEL_MAP
        are exactly what the refresh subcommand exists to surface."""
        aliases = parse_available_models(_load_fixture("get_available_models.json"))
        new_only = set(aliases) - set(DEFAULT_MODEL_MAP)
        # Captured 2026-05-16 — at least these new GPT/Kimi/DeepSeek
        # variants are not in our hard-coded map.
        assert "gpt-5.5" in new_only or "gpt-5.4-mini" in new_only

    def test_empty_response(self):
        assert parse_available_models({}) == {}
        assert parse_available_models({"models": []}) == {}

    def test_skips_disabled(self):
        data = {"models": [
            {"model": "x-id", "modelMessage": "X 1.0", "isDisabled": True},
            {"model": "y-id", "modelMessage": "Y 1.0", "isDisabled": False},
        ]}
        assert parse_available_models(data) == {"y-1.0": "y-id"}

    def test_skips_malformed_entries(self):
        data = {"models": [
            "not-a-dict",
            {"model": "no-message"},
            {"modelMessage": "No Id"},
            {"model": 42, "modelMessage": "Bad Types"},
            {"model": "good-id", "modelMessage": "Good 1.0"},
        ]}
        assert parse_available_models(data) == {"good-1.0": "good-id"}

    def test_alias_lowercases_and_dashes(self):
        data = {"models": [
            {"model": "x", "modelMessage": "Multi Word Name"},
            {"model": "y", "modelMessage": "Already-Dashed Thing"},
        ]}
        result = parse_available_models(data)
        assert result == {
            "multi-word-name":      "x",
            "already-dashed-thing": "y",
        }


# --------------------------------------------------------------------------- #
# load_user_model_map / save_user_model_map round-trip
# --------------------------------------------------------------------------- #

class TestUserModelMapPersistence:
    def test_round_trip(self, tmp_path: Path):
        p = tmp_path / "models.json"
        m = {"opus-4.7": "new-id-for-opus", "experimental": "x-id"}
        out_path = save_user_model_map(m, p)
        assert out_path == p
        # File is sorted + has updated_at timestamp.
        body = json.loads(p.read_text())
        assert list(body["friendly_aliases"]) == ["experimental", "opus-4.7"]
        assert "updated_at" in body
        # Round trip ignores the timestamp.
        assert load_user_model_map(p) == m

    def test_missing_file_returns_empty(self, tmp_path: Path):
        assert load_user_model_map(tmp_path / "nope.json") == {}

    def test_malformed_json_returns_empty(self, tmp_path: Path):
        p = tmp_path / "bad.json"
        p.write_text("not json{", encoding="utf-8")
        # filterwarnings=error in pytest.ini → warning becomes failure if
        # save path warns. Should NOT warn here; load just returns {}.
        assert load_user_model_map(p) == {}

    def test_missing_friendly_aliases_key_returns_empty(self, tmp_path: Path):
        p = tmp_path / "rogue.json"
        p.write_text(json.dumps({"something_else": {}}), encoding="utf-8")
        assert load_user_model_map(p) == {}

    def test_non_string_values_filtered(self, tmp_path: Path):
        p = tmp_path / "mixed.json"
        p.write_text(json.dumps({"friendly_aliases": {
            "ok":         "good-id",
            "bad-int":    42,
            "bad-nested": {"deep": "x"},
            "ok-2":       "good-id-2",
        }}), encoding="utf-8")
        assert load_user_model_map(p) == {"ok": "good-id", "ok-2": "good-id-2"}


# --------------------------------------------------------------------------- #
# resolve_model + user_map precedence
# --------------------------------------------------------------------------- #

class TestResolveModelWithUserMap:
    def test_user_map_overrides_default(self):
        # User refresh says opus-4.7 has been renamed to a hypothetical
        # new id; resolve_model must prefer it.
        assert resolve_model(
            "opus-4.7", user_map={"opus-4.7": "shiny-new-id"},
        ) == "shiny-new-id"

    def test_user_map_value_treated_as_passthrough(self):
        # If the caller hands us the new internal id directly,
        # resolve_model should recognize it (so logging doesn't lie).
        assert resolve_model(
            "shiny-new-id", user_map={"opus-4.7": "shiny-new-id"},
        ) == "shiny-new-id"

    def test_user_map_adds_new_alias(self):
        # New "kimi-k2.6" friendly alias didn't exist before; user_map
        # adds it.
        assert resolve_model(
            "kimi-k2.6", user_map={"kimi-k2.6": "fireworks-kimi-k2.6"},
        ) == "fireworks-kimi-k2.6"

    def test_anthropic_alias_routes_through_user_map(self):
        # claude-opus-4-7 → opus-4.7 (ANTHROPIC_ALIASES) → user_map value
        assert resolve_model(
            "claude-opus-4-7", user_map={"opus-4.7": "shiny-new-id"},
        ) == "shiny-new-id"

    def test_empty_user_map_is_no_op(self):
        assert resolve_model("opus-4.7", user_map={}) == "apricot-sorbet-high"

    def test_none_user_map_is_no_op(self):
        assert resolve_model("opus-4.7", user_map=None) == "apricot-sorbet-high"

    def test_empty_model_with_user_map_overrides_default(self):
        # Default (empty model) → opus-4.7 → user_map value.
        assert resolve_model(
            "", user_map={"opus-4.7": "shiny-new-id"},
        ) == "shiny-new-id"


# --------------------------------------------------------------------------- #
# NotionAgentClient.fetch_available_models via MockTransport
# --------------------------------------------------------------------------- #

def _account_file(tmp_path: Path) -> Path:
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps({
        "token_v2":      "v03:test",
        "user_id":       "11111111-1111-1111-1111-111111111111",
        "space_id":      "22222222-2222-2222-2222-222222222222",
        "space_name":    "Test Space",
        "browser_id":    "bid",
        "device_id":     "did",
    }), encoding="utf-8")
    return p


class TestFetchAvailableModels:
    async def test_happy_path_returns_models_list(self, tmp_path: Path):
        fixture = _load_fixture("get_available_models.json")
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=fixture)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            data = await client.fetch_available_models()

        assert isinstance(data.get("models"), list)
        assert len(data["models"]) == len(fixture["models"])
        # Request shape spot check
        assert len(captured) == 1
        req = captured[0]
        assert str(req.url).endswith("/getAvailableModels")
        assert req.headers["accept"] == "application/json"
        body = json.loads(req.content)
        assert body == {"spaceId": "22222222-2222-2222-2222-222222222222"}

    async def test_401_raises_with_token_hint(self, tmp_path: Path):
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(401, text='{"name":"Unauthorized"}')

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            with pytest.raises(NotionAgentError, match="token_v2"):
                await client.fetch_available_models()

    async def test_500_raises_with_marker(self, tmp_path: Path):
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(500, text="boom")

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            with pytest.raises(NotionAgentError, match="getAvailableModels failed"):
                await client.fetch_available_models()
