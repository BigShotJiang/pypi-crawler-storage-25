"""Tests for ``notion-agent init`` CLI plumbing.

The live HTTP path (``/api/v3/loadUserContent``) is covered by
``test_bootstrap.py``; this file pins the CLI's argv/stdin handling so
``--cookie -`` keeps reading from stdin rather than argv.
"""
from __future__ import annotations

import io
from pathlib import Path

import pytest

from notion_agent_cli.account import NotionAccount
from notion_agent_cli.cli.__main__ import main


@pytest.fixture
def stub_bootstrap(monkeypatch):
    """Replace bootstrap_account with a sink that records its kwargs."""
    captured: dict[str, str] = {}

    async def _fake(**kwargs) -> NotionAccount:
        captured.update(kwargs)
        return NotionAccount(
            token_v2=kwargs.get("token_v2", ""),
            user_id=kwargs.get("user_id", ""),
            space_id="space-id-stub",
            space_name="Stub Space",
            space_view_id="",
            browser_id=kwargs.get("browser_id") or "",
            device_id="",
            timezone=kwargs.get("timezone", "America/Los_Angeles"),
            agent_name=kwargs.get("agent_name", ""),
            agent_accessory=kwargs.get("agent_accessory", ""),
            agent_context_page_id=kwargs.get("agent_context_page_id", ""),
            default_model=kwargs.get("default_model", "opus-4.7"),
        )

    monkeypatch.setattr(
        "notion_agent_cli.cli.__main__.bootstrap_account", _fake,
    )
    return captured


class TestInitStdin:
    def test_dash_cookie_reads_from_stdin(
        self, tmp_path: Path, monkeypatch, stub_bootstrap,
    ):
        """`--cookie -` reads the cookie string from stdin, not argv."""
        cookie = (
            "notion_user_id=11111111-1111-1111-1111-111111111111; "
            "token_v2=v03:secret; "
            "notion_browser_id=44444444-4444-4444-4444-444444444444"
        )
        monkeypatch.setattr("sys.stdin", io.StringIO(cookie))

        out_path = tmp_path / "acc.json"
        rc = main(["init", "--cookie", "-", "--account", str(out_path)])
        assert rc == 0
        assert out_path.exists()
        # The stdin-supplied cookie was parsed into token_v2 + user_id.
        assert stub_bootstrap["token_v2"] == "v03:secret"
        assert stub_bootstrap["user_id"] == "11111111-1111-1111-1111-111111111111"
        assert stub_bootstrap["browser_id"] == "44444444-4444-4444-4444-444444444444"

    def test_dash_cookie_empty_stdin_errors(
        self, tmp_path: Path, monkeypatch, capsys,
    ):
        monkeypatch.setattr("sys.stdin", io.StringIO("   \n"))
        out_path = tmp_path / "acc.json"
        rc = main(["init", "--cookie", "-", "--account", str(out_path)])
        assert rc == 2
        assert "empty" in capsys.readouterr().err.lower()
