"""Unit tests for the agents module + /getCustomAgents wrapper.

Uses ``tests/fixtures/get_custom_agents.json`` — a sanitized copy of a
real Notion response (UUIDs and titles redacted to synthetic patterns
``a0000001-...`` for agents, ``70000001-...`` for threads, etc.).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from notion_agent_cli import NotionAgentClient, NotionAgentError
from notion_agent_cli.agents import (
    AgentSummary,
    ThreadSummary,
    parse_agents,
    parse_threads,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _load_fixture(name: str) -> dict[str, Any]:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


# --------------------------------------------------------------------------- #
# parse_threads
# --------------------------------------------------------------------------- #

class TestParseThreads:
    def test_real_fixture_yields_all_entries(self):
        data = _load_fixture("get_custom_agents.json")
        threads = parse_threads(data)
        assert len(threads) == len(data["mostRecentTranscripts"])
        # All ids preserved as strings
        for t in threads:
            assert isinstance(t.thread_id, str)
            assert t.thread_id.startswith("7")  # sanitized prefix for threads

    def test_real_fixture_sorted_newest_first(self):
        threads = parse_threads(_load_fixture("get_custom_agents.json"))
        # Take entries with timestamps; verify monotonic non-increasing.
        timestamps = [
            (t.updated_at_ms or t.created_at_ms or 0) for t in threads
        ]
        assert timestamps == sorted(timestamps, reverse=True)

    def test_real_fixture_titles_round_trip_with_none(self):
        threads = parse_threads(_load_fixture("get_custom_agents.json"))
        # Some real transcripts had null titles — that should survive as None.
        any_none = any(t.title is None for t in threads)
        any_str = any(isinstance(t.title, str) for t in threads)
        assert any_none, "fixture should contain at least one null title"
        assert any_str

    def test_empty_response(self):
        assert parse_threads({}) == []
        assert parse_threads({"mostRecentTranscripts": []}) == []

    def test_skips_non_dict_and_missing_id(self):
        data = {"mostRecentTranscripts": [
            "not-a-dict",
            {"no_id_field": True},
            {"id": 42},
            {"id": "good", "title": "ok"},
        ]}
        threads = parse_threads(data)
        assert len(threads) == 1
        assert threads[0].thread_id == "good"

    def test_int_coercion_of_timestamps(self):
        # Notion returns timestamps as strings.
        data = {"mostRecentTranscripts": [
            {"id": "t1", "created_time": "1778017615141",
             "updated_time": "1778021049107"},
        ]}
        t = parse_threads(data)[0]
        assert t.created_at_ms == 1778017615141
        assert t.updated_at_ms == 1778021049107


# --------------------------------------------------------------------------- #
# parse_agents
# --------------------------------------------------------------------------- #

class TestParseAgents:
    def test_real_fixture_yields_all_agents(self):
        data = _load_fixture("get_custom_agents.json")
        agents = parse_agents(data)
        assert len(agents) == len(data["agentIds"])
        for a in agents:
            assert isinstance(a.agent_id, str)

    def test_real_fixture_active_agents_have_scores(self):
        data = _load_fixture("get_custom_agents.json")
        agents = parse_agents(data)
        # activityScores covered 12 of 19 agents in the captured fixture.
        scored = [a for a in agents if a.activity_score is not None]
        unscored = [a for a in agents if a.activity_score is None]
        assert len(scored) == len(data["activityScores"])
        assert len(unscored) == len(data["agentIds"]) - len(data["activityScores"])

    def test_active_agents_sort_before_inactive(self):
        agents = parse_agents(_load_fixture("get_custom_agents.json"))
        seen_none = False
        for a in agents:
            if a.activity_score is None:
                seen_none = True
            elif seen_none:
                pytest.fail(
                    f"agent {a.agent_id} (score={a.activity_score}) followed "
                    f"a None-score agent — sort order broken"
                )

    def test_breadcrumb_uses_most_recent_thread_per_agent(self):
        agents = parse_agents(_load_fixture("get_custom_agents.json"))
        # At least one agent in the fixture has its breadcrumb set.
        with_breadcrumb = [a for a in agents if a.most_recent_thread_id]
        assert len(with_breadcrumb) >= 1
        # Spot check: breadcrumb thread id should belong to an entry whose
        # parent_id matches the agent_id.
        data = _load_fixture("get_custom_agents.json")
        ts_by_id = {t["id"]: t for t in data["mostRecentTranscripts"] if t.get("id")}
        for a in with_breadcrumb:
            assert ts_by_id[a.most_recent_thread_id]["parent_id"] == a.agent_id

    def test_empty_agent_ids(self):
        assert parse_agents({}) == []
        assert parse_agents({"agentIds": []}) == []

    def test_activity_score_dedup_keeps_highest(self):
        data = {
            "agentIds": ["a1"],
            "activityScores": [
                {"parent_id": "a1", "activity_score": "100"},
                {"parent_id": "a1", "activity_score": "200"},
                {"parent_id": "a1", "activity_score": "50"},
            ],
        }
        a = parse_agents(data)[0]
        assert a.activity_score == 200


# --------------------------------------------------------------------------- #
# NotionAgentClient.fetch_custom_agents via MockTransport
# --------------------------------------------------------------------------- #

def _account_file(tmp_path: Path) -> Path:
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps({
        "token_v2":   "v03:test",
        "user_id":    "11111111-1111-1111-1111-111111111111",
        "space_id":   "22222222-2222-2222-2222-222222222222",
        "space_name": "T",
        "browser_id": "bid",
    }), encoding="utf-8")
    return p


class TestFetchCustomAgents:
    async def test_happy_path_returns_top_keys(self, tmp_path: Path):
        fixture = _load_fixture("get_custom_agents.json")
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=fixture)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            data = await client.fetch_custom_agents()

        assert set(data.keys()) >= {"agentIds", "mostRecentTranscripts",
                                    "activityScores"}
        req = captured[0]
        assert str(req.url).endswith("/getCustomAgents")
        assert req.headers["accept"] == "application/json"
        body = json.loads(req.content)
        assert body == {"spaceId": "22222222-2222-2222-2222-222222222222"}

    async def test_401_surfaces_auth_invalid_code(self, tmp_path: Path):
        from notion_agent_cli import ErrorCode

        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(401, text="nope")

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            with pytest.raises(NotionAgentError) as exc:
                await client.fetch_custom_agents()
        assert exc.value.code == ErrorCode.AUTH_INVALID


# --------------------------------------------------------------------------- #
# Cross-check: parse_agents + parse_threads on the same fixture stay
# consistent — every breadcrumb thread id appears in the threads list.
# --------------------------------------------------------------------------- #

def test_breadcrumb_thread_ids_are_subset_of_threads_list():
    data = _load_fixture("get_custom_agents.json")
    agents = parse_agents(data)
    threads = parse_threads(data)
    thread_ids = {t.thread_id for t in threads}
    for a in agents:
        if a.most_recent_thread_id is not None:
            assert a.most_recent_thread_id in thread_ids


def test_dataclasses_are_frozen():
    # Frozen dataclasses are immutable — tests + downstream wrappers
    # can stash them in sets / dict keys safely.
    a = AgentSummary("x", None, None, None)
    t = ThreadSummary("y", None, None, None, None, None, None)
    with pytest.raises((AttributeError, Exception)):  # FrozenInstanceError
        a.agent_id = "z"  # type: ignore[misc]
    with pytest.raises((AttributeError, Exception)):
        t.thread_id = "z"  # type: ignore[misc]
