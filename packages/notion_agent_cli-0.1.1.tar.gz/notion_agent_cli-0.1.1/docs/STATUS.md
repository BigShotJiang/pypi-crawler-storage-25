# Status — what's already done

This repo was bootstrapped from the M4 reverse-engineering work in
[NotionAgents](https://github.com/chenyqthu/NotionAgents) (the
`src/notionagents/llm/` modules + accompanying tests + capture docs).
Live testing against a real Notion account succeeded there — see
[`docs/01-notion-chat-protocol.md`](01-notion-chat-protocol.md) for the
captured traffic that drove the implementation.

## Verified live

### Inherited from NotionAgents M4 (code identical here)

- 🟢 **Endpoint shape**: POST `https://www.notion.so/api/v3/runInferenceTranscript`
- 🟢 **Auth**: `token_v2` cookie (long-lived JWT, signed by
  `production:token-v3:2024-11-07`) — Notion accepts our request as a
  legitimate browser request when paired with `x-notion-active-user-header`
  + `notion-client-version` + `cookie`
- 🟢 **Round-trip**: 3 separate live chats run by Lucien against Jarvis
  custom agent (opus-4.7 / apricot-sorbet-high), all returned correct
  responses (`"在线，随时待命 🐲"` / `"5/15"` / full Jarvis status report)
- 🟢 **Chat-panel visibility**: with `agentName` + `agent_context_page_id`
  in the context block, threads surface in Notion's ✦ AI UI under the
  bound persona — verified visually by the operator
- 🟢 **Custom Agent instruction injection**: Jarvis pulled 17
  `trackedInstructionTreePages` into the context (≈100k input tokens),
  with `cachedTokensRead` ≈ 36k showing Notion's prompt cache is doing
  its job between turns
- 🟢 **`asPatchResponse=true` parsing**: handles patch-start, /s/-
  section appends with inline `value`, /s/N/value/- entry registration,
  /s/N/value/M/content op=x / op=p, /s/N/*Tokens, error / premium events
- 🟢 **Token cache fields**: `cachedTokensRead` / `cachedTokensCreated`
  parsed into `TokenUsage.cache_read` / `cache_creation`
- 🟢 **brotli decompression**: httpx auto-negotiates `Accept-Encoding`
  when `brotli` package is installed; Notion picks `br` over identity

### Re-validated in this repo 2026-05-16 (TP-Link account, fresh token)

- 🟢 **`notion-agent init --cookie "..."`** with TP-Link space + Jarvis
  binding — wrote a valid `notion_account.json` from one pasted cookie
  string, workspace + email + space_view_id all auto-populated
- 🟢 **`notion-agent chat "..."`** — `apricot-sorbet-high` (opus-4.7) is
  still the active id; `cachedTokensRead = 36760` matches the original
  M4 capture (prompt cache still warm across the Jarvis instruction tree)
- 🟢 **`notion-agent chat --json` / `--stream`** — both return non-empty
  text + correct exit code
- 🟢 **`notion-agent doctor`** — 6/6 checks pass on the valid account;
  fails cleanly with `[account_missing]` for a missing file and
  `[auth_invalid]` for a tampered token
- 🟢 **`notion-agent models refresh`** — 15 models returned from
  `/getAvailableModels`; all 9 hard-coded `DEFAULT_MODEL_MAP` aliases
  still match Notion's current internal id (no rename drift yet);
  surfaced 6 new models not previously catalogued (GPT-5.5, GPT-5.4
  Mini/Nano, Kimi K2.6, DeepSeek V4 Pro, Gemini 3.1 Pro)
- 🟢 **`notion-agent agents list`** + **`threads list`** — 19 agents,
  16 recent transcripts ranked by activity, breadcrumb titles resolve
- 🟢 **`notion-agent chat --thread-id <uuid>` continuation** —
  end-to-end implemented + tested against the 2026-05-16 chat-panel
  capture (see `docs/01-notion-chat-protocol.md §6`). Per-thread state
  persists under `~/.notionagents/threads/<id>.json`; first turn writes
  it on success, subsequent turns rebuild the partial transcript with
  reused `config_id` / `context_id` / `original_datetime` + one fresh
  `updated-config` uuid per past turn. Model is locked to the thread's
  turn-1 choice. **Live-validated 2026-05-16** (fresh token, TP-Link):
  round-1 `chat --json` opened thread `a374fbd9-…d016`, round-2
  `chat --thread-id` round-tripped on the same thread, model stayed at
  `apricot-sorbet-high`, `cache_read` grew 36760 → 56746 between turns
  (transcript replay hits Notion's prompt cache as expected), and the
  state file's `updated_config_ids` extended by one new uuid. Operator
  re-confirmed chat-panel visibility: the 2-turn thread surfaces under
  the Jarvis persona with both round-1 + round-2 messages visible.
- 🟢 **Claude Code skill** at `.claude/skills/notion-agent/SKILL.md` —
  auto-loads when CC opens this repo. Frontmatter packs trigger
  phrases ("ask Jarvis", "Notion AI", "via the chat panel") into the
  description; body covers all 8 subcommands + B1 continuation
  pipeline + pre-flight + troubleshooting + 8-row ErrorCode reference.
- 🟢 **NotionAgents adopted as a consumer** — already done in
  NotionAgents `ef476a3 M5: hoist LLM client to notion-agent-cli`
  (the 6 duplicated modules under `src/notionagents/llm/` were
  replaced by a thin `NotionAgentProvider` adapter wrapping
  `notion_agent_cli.NotionAgentClient`). NotionAgents' .venv is on a
  `pip install -e /Users/chenyuanquan/Documents/notion-agent-cli`,
  so D3 + backlog changes here propagate instantly. NotionAgents 147
  tests stayed green across every refactor in this session — public
  API (`NotionAgentClient`, `NotionAgentError`, `ChatResponse`,
  `TokenUsage`, `ErrorCode`) is stable.

### Newly mapped endpoints (2026-05-16)

- 🟢 **POST `/api/v3/getAvailableModels`** body `{"spaceId"}` →
  `{models: [{model, modelMessage, modelFamily, displayGroup,
  isDisabled, ...}]}`. Powers `models refresh`.
- 🟢 **POST `/api/v3/getCustomAgents`** body `{"spaceId"}` →
  `{agentIds, mostRecentTranscripts, activityScores, dependencies}`.
  Powers `agents list` + `threads list`.
- 🟢 **POST `/api/v3/loadUserContent`** with `token_v2` cookie + no
  `x-notion-active-user-header` header is accepted. user_id is
  recoverable from the response — bootstrap could be made
  user_id-optional in a future revision.

## CLI subcommands (8 total)

```
notion-agent init     --cookie "..." | --token-v2 / --user-id / --browser-id
                      (`--cookie -` reads from stdin to skip shell history)
notion-agent chat     "<prompt>" [--system ...] [--model ...]
                                 [--stream | --json | --ndjson]
                                 [--ask-mode] [--no-web-search] [--no-workspace-search]
                                 [--thread-id <uuid>]
notion-agent doctor   [--account ...] [--json]
notion-agent models   refresh [--account ...] [--output ...] [--json]
notion-agent agents   list    [--account ...] [--limit N] [--json]
notion-agent threads  list    [--account ...] [--limit N] [--agent <id>] [--json]
notion-agent profile  list / current / use <name> / migrate <name>
notion-agent serve    [--host 127.0.0.1] [--port 8000] [--account ...] [--reload]
                      Requires the [serve] install extra (FastAPI + uvicorn).
```

- 🟡 **`--stream` mode tty buffering** — code path live-validated end
  to end; but bash command capture flattens incremental chunks, so the
  *visual* "chunks appear as they stream" behavior on a real interactive
  tty hasn't been eyeballed.
- 🟢 **`init --cookie -` (stdin)** — live-validated 2026-05-16: piped a
  constructed cookie string (new token + saved user_id / browser_id)
  via `printf '%s' "$COOKIE" | notion-agent init --cookie -`, writes a
  valid account file end-to-end.
- 🟢 **`profile` subcommand** — live-validated 2026-05-16:
  `profile migrate tplink` promoted the account, `profile use scratch`
  retargeted the symlink, `profile current` agreed, `doctor` passed
  against the switched-in profile, `profile use tplink` flipped back.
- 🟢 **`chat --ndjson`** — live-validated 2026-05-16: 13 raw events
  (`patch-start` + 11 `patch` + `record-map`), step types observed =
  config / context / user / title / agent-instruction-state /
  agent-turn-full-record-map / agent-tool-result / agent-inference
  (carries text + per-turn token usage) / updated-config — matches
  the captured chat-panel protocol 1:1.
- 🟢 **`notion-agent serve`** — live-validated 2026-05-16 against
  Notion: `POST /chat {stream:false}` returned the full ChatResponse
  JSON; `POST /chat {stream:true}` returned `data: {...}\n\ndata: [DONE]`
  SSE; `GET /healthz` reports `account` + `live_ping` both ok; `GET
  /agents` returned 19 agents; `GET /threads?limit=3` returned the 3
  most recent transcripts with parent-agent breadcrumbs.

## Library surface (stable across v0.1)

```python
from notion_agent_cli import (
    NotionAgentClient,        # async client; .complete() + .stream_lines()
    NotionAgentError,         # single error type, branch on .code
    ErrorCode,                # StrEnum taxonomy (16 codes today)
    ChatResponse, TokenUsage, # response dataclasses
)
```

Streaming knobs on `complete()`:

- `on_text_delta=fn`            — sync callback fired per chunk
- `on_text_delta_async=coro`    — async callback awaited per chunk (used
                                  by the FastAPI SSE branch + any HTTP
                                  consumer that needs `await queue.put()`)
- both set → raises `INVALID_CALLBACK`

`stream_lines()` is the raw NDJSON passthrough (powers `chat --ndjson`
in the CLI). State still persists, so `--thread-id` continuation works
from raw consumers too.

## Unit tests (180 in this repo, all passing)

`tests/test_notion_agent_cli.py` — original 46 + 5 continuation tests +
2 async-callback + 3 stream_lines + 2 tz-honoring → **59**

`tests/test_bootstrap.py` — 20 (cookie parser + bootstrap_account via
MockTransport)

`tests/test_models_refresh.py` — 22 (drift detector against captured
`/getAvailableModels` fixture, user_map persistence + precedence,
fetch_available_models via MockTransport)

`tests/test_error_codes.py` — 22 (ErrorCode taxonomy + propagation
from every annotated raise site: account / bootstrap / ndjson /
provider chat path / provider fetch path / thread_state /
invalid_callback)

`tests/test_cli_doctor.py` — 3 (`_render_doctor` pure formatter,
human + JSON modes)

`tests/test_cli_init.py` — **2** (new) — `init --cookie -` reads
from stdin instead of argv

`tests/test_agents.py` — 16 (parse_threads + parse_agents over a
sanitized `/getCustomAgents` fixture, fetch_custom_agents via
MockTransport, cross-consistency between agents + threads parse)

`tests/test_thread_state.py` — 7 (per-file JSON round-trip, parent
dir auto-create, overwrite, default path resolution, missing /
malformed error codes, schema key set)

`tests/test_profile.py` — **22** (new) — `list_profiles` /
`current_profile` / `use_profile` / `migrate_account_to_profile` +
CLI smoke

`tests/test_serve.py` — **8** (new) — FastAPI app via
`httpx.ASGITransport`: `/chat` blocking + SSE + thread continuation +
401 bubbling, `/healthz` pass + fail, `/agents` + `/threads`
with filters

Run via `./.venv/bin/pytest -q` (≈0.5s). Lint via
`./.venv/bin/ruff check src tests`.

## Inherited research artifacts

- [`docs/01-notion-chat-protocol.md`](01-notion-chat-protocol.md) —
  full captured request + response from a real chat-panel invocation
  on 2026-05-15, with field-by-field comparison vs notion_manager Go
  implementation. **Don't lose this** — it's the protocol spec that
  the implementation is built against.

## Known gaps (see ROADMAP for the plan)

- Per-thread state file TTL / pruning — state files accumulate forever
  under `~/.notionagents/threads/`; harmless (small JSON, ~350 bytes
  each) but worth a `threads gc --older-than 30d` someday. Affects
  NotionAgents' long-running runner most: every `complete()` writes a
  state file even though the adapter never passes `thread_id` for
  reuse — ~17 KB/day at 50 calls/day cadence.
- Multi-thread / per-day rolling strategy not implemented (each
  `chat` call without `--thread-id` still opens a fresh thread)
- `notion-agent threads show <id>` — **endpoint resolved 2026-05-16**,
  implementation pending. The three nominal candidates
  (`loadInferenceTranscript` / `getInferenceTranscript` /
  `loadCachedPageChunk` keyed by thread_id) all 404 or return an
  empty `recordMap`. The real two-step path the chat panel uses is:
  1. `POST /api/v3/syncRecordValuesMain` with
     `{requests:[{pointer:{table:"thread",id:THREAD_ID,spaceId},version:-1}]}`
     → returns the thread record incl. `messages: [msg_id, ...]`
     ordered chronologically + `data.title` + `data.usage_summary`.
  2. `POST /api/v3/syncRecordValuesMain` with the same shape but
     `table:"thread_message"`, batching all message ids in one request
     → returns each step's `value.value.step`. Observed step types on
     a B1 thread: `config / context / user / title /
     agent-instruction-state / agent-turn-full-record-map /
     agent-tool-result / agent-inference / updated-config`.
     `agent-inference.value[].content` is the reply text;
     `updated-config` records align 1:1 with the state file's
     `updated_config_ids`. Build `threads show <id>` on top of this.
