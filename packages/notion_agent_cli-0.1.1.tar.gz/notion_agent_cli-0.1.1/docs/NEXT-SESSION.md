# Next-session handoff — Phase 2 closeout

> Updated 2026-05-16 evening, after the session that shipped B1 + D1 +
> D2 (commits `65233c3 b1ac5f5 5470525 1ab5b3c`). Goal of next session:
> close out Phase 2 entirely — D3 FastAPI serve + 5 backlog essentials
> + v0.1.0 tag, then this repo can sit at "done for now".
>
> Should take a fresh agent ~3 min to absorb. ~1 long day to execute.

## TL;DR — execution order

1. **Startup**: `.venv/bin/pytest -q` (expect 140) + `.venv/bin/ruff check src tests` + `git log --oneline -10` + `gh repo view` to confirm origin still points at `ChenyqThu/notion-agent-cli` (private).
2. **D3.0** — async callback refactor. Add `on_text_delta_async` to `complete()` alongside the sync one. Non-breaking. Decision already made (see §D3 below); just execute.
3. **D3.1** — `notion-agent serve` subcommand. FastAPI wrapper, SSE for streaming, JSON for blocking. Optional install group `[serve]`.
4. **Backlog essentials** in this order — each is ≤2h:
   - `chat --ndjson` raw stream passthrough
   - `init --stdin` for keeping token out of shell history
   - `_now_iso` honors `acc.timezone` (currently uses system tz)
   - `profile list / use <name>` for multi-workspace
   - `threads show <id>` (probe 3-5 endpoint candidates first via a live account; defer if no probe target)
5. **README sweep** — current README says "CLI surface is currently a thin scaffold (`init` + `chat`)" — stale. Refresh to reflect 6 subcommands + skill packaging + library API stability.
6. **Tag v0.1.0** — bump `pyproject.toml` version + `__init__.__version__` from `0.1.0.dev0` to `0.1.0`, commit, `git tag v0.1.0`, `gh release create v0.1.0 --generate-notes --target main`.
7. **Optional**: B1 live validation if operator re-binds a token — actually run `notion-agent chat "..."; notion-agent chat --thread-id <id> "follow up"` against a real account, confirm the second turn surfaces in the same chat-panel thread.

## State of play

- **140 unit tests** in this repo, ruff clean; **NotionAgents 147 tests** green against an editable install of this repo (so no public-API regression goes unnoticed mid-D3).
- **6 CLI subcommands** wired + B1 continuation working in unit tests.
- **Claude Code skill** at `.claude/skills/notion-agent/SKILL.md` auto-loads when CC opens this repo.
- **3 commits/B1 + 1 commit/D1 + 1 commit/D2-bookkeeping** all pushed to `origin/main`.

## §D3 — `notion-agent serve` (architecture + plan)

### Decision (committed)

**Option 1: add async callback variant, non-breaking.** Signature becomes:

```python
async def complete(
    self,
    *,
    prompt: str,
    ...,
    on_text_delta: Callable[[str], None] | None = None,                          # existing
    on_text_delta_async: Callable[[str], Awaitable[None]] | None = None,         # new
    ...
) -> ChatResponse:
```

Provider checks which is set:

```python
if on_text_delta_async is not None:
    await on_text_delta_async(chunk)
elif on_text_delta is not None:
    on_text_delta(chunk)
```

Reject both being set (`raise NotionAgentError("set one of on_text_delta / on_text_delta_async, not both", code=...)` — or just document and trust callers). Lean: validate at top of complete(), code=`EMPTY_PROMPT`-equivalent new code `INVALID_CALLBACK` (or reuse `UNKNOWN`).

**Not chosen**: Option 2 (convert to AsyncGenerator). Breaking; CLI doesn't need it; can add a separate `client.stream()` method later if any HTTP consumer actually needs it.

### Endpoint surface

```
POST /chat
  body: {prompt, system?, model?, web_search?, workspace_search?,
         ask_mode?, thread_id?, stream?}
  stream=false → 200 + ChatResponse JSON
  stream=true  → SSE; "data: <chunk>\n\n" per delta, "data: [DONE]\n\n" final

GET  /healthz → doctor's check list (200 / 503)
GET  /agents  → agents list JSON (limit query param)
GET  /threads → threads list JSON (limit / agent_id query params)
```

### Subcommand surface

```
notion-agent serve [--host 0.0.0.0] [--port 8000] [--account PATH]
                   [--reload]
```

### Optional install group

```toml
[project.optional-dependencies]
serve = ["fastapi>=0.110", "uvicorn[standard]>=0.27"]
```

So `pip install notion-agent-cli` stays light; `pip install notion-agent-cli[serve]` for the HTTP wrapper.

### Tests

`tests/test_serve.py` using `httpx.AsyncClient(transport=httpx.ASGITransport(app))` over the FastAPI app. Reuse the existing `MockTransport` pattern for the Notion side by injecting a pre-built `NotionAgentClient(http_client=...)` into the FastAPI dependency.

Test cases (~6):
- POST /chat blocking happy path
- POST /chat SSE streaming — confirm chunks arrive incrementally + terminator present
- POST /chat with thread_id — confirm state is loaded
- GET /healthz on a doctor-passing config → 200
- GET /healthz on a missing account → 503
- 401 from Notion bubbles up as 401 with code=auth_invalid

### Gotchas

- SSE client disconnect mid-stream: FastAPI `Request.is_disconnected()` polling, or just let `StreamingResponse` raise. Don't over-engineer.
- Heartbeat (`hasHeartbeat=true`) isn't needed unless we see real connection drops in practice — keep `false`.
- `--reload` is dev-only; production should run uvicorn standalone with our app factory.

## §Backlog essentials (in suggested order)

### `chat --ndjson` (≤1h)
Add `--ndjson` flag mutually exclusive with `--json` / `--stream`. Pipe the raw NDJSON stream from `client._get_client().stream(...)` straight to stdout. Reuse the same auth + body-building path as `chat`; just don't run the parser. Useful as a `serve`-internal codepath too (SSE can share the raw NDJSON line iterator).

### `init --stdin` (≤30 min)
`--cookie -` or new `--stdin` flag — read the cookie string from stdin instead of argv so it doesn't show in shell history. `bootstrap_account` already takes the values as kwargs; just plumb the stdin read.

### `_now_iso` honors `acc.timezone` (≤1h)
Currently `datetime.now(UTC).astimezone()` uses the system's local tz. Should use `zoneinfo.ZoneInfo(acc.timezone)`. Pass `acc` into `_now_iso` (or rename the function and have it take a tz arg). Update both call sites in `build_full_transcript` + `build_partial_transcript`. Update `tests/test_notion_agent_cli.py::TestTranscript` to assert the tz offset matches `acc.timezone`.

### `profile list / use <name>` (≤2h)
Multiple `~/.notionagents/<name>.json` profiles. `profile use <name>` swaps `notion_account.json` symlink. `profile list` enumerates JSON files in the dir. `profile current` shows which one is active. Keep simple: no migration tooling, no merge — just a symlink swap.

### `threads show <id>` (≤3h, only if probable)
**Investigate first**: probe candidate endpoints with a live account before committing:
- `/api/v3/loadInferenceTranscript {threadId}`
- `/api/v3/getInferenceTranscript {threadId}`
- `/api/v3/loadCachedPageChunk {pageId: threadId}`

If one returns a usable transcript shape, build `threads show <id>` to render it. If all 404, defer. **Skip if no live access.**

## §README sweep (~30 min)

Current README at `README.md:14-25` says:
> The CLI surface is currently a thin scaffold (`init` + `chat`). Streaming output, JSON output, multi-account profiles, skill packaging — all on the roadmap.

Refresh to:
- 6 subcommands list with one-line description each
- Add "Continuation" section pointing at `chat --thread-id`
- Add "Claude Code skill" section mentioning `.claude/skills/notion-agent/`
- Mention NotionAgents as a known consumer
- Keep the "Why this exists" + "Library use" + "License" sections as-is

## §v0.1.0 tag

```bash
# Bump version
# pyproject.toml: 0.1.0.dev0 → 0.1.0
# src/notion_agent_cli/__init__.py:__version__: 0.1.0.dev0 → 0.1.0
git commit -am "Bump version to 0.1.0"
git tag v0.1.0
git push origin main --tags
gh release create v0.1.0 --generate-notes --target main \
  --notes "First tagged release. See CHANGELOG / commit history for the path from M4 extraction to here."
```

Then in NotionAgents repo:
```bash
# Update the pin
# pyproject.toml: "notion-agent-cli>=0.1.0.dev0" → "notion-agent-cli>=0.1,<0.2"
# But keep the editable install in .venv for ongoing dev
```

## §Non-obvious context (read once)

- **Editable install in NotionAgents** — `~/Documents/NotionAgents/.venv` has `notion-agent-cli` as `Editable project location: /Users/chenyuanquan/Documents/notion-agent-cli`. Any change you make here propagates instantly. NotionAgents has its own 147-test suite that'll catch public-API regressions — `cd ~/Documents/NotionAgents && .venv/bin/pytest -q` after public-facing changes here.
- **Thread state file accumulation** — every successful `complete()` writes a JSON file under `~/.notionagents/threads/`. NotionAgents adapter never reuses thread_id, so files accumulate. Not blocking, but if you implement `serve`, consider adding a `gc_older_than` parameter or expose `threads gc` as a subcommand.
- **B1 live validation can use `chat --json | jq -r .thread_id`** to capture turn-1's thread id without manually copying. Then `chat --thread-id "$THREAD" "..."` for turn 2. Verify in Notion UI that both turns surface in the same chat-panel thread.
- **gh CLI auth is `ChenyqThu`** (capital). Repo is at `https://github.com/ChenyqThu/notion-agent-cli`, private.
- **The `.omc/` directory** in the working tree is session state from oh-my-claudecode. Not in .gitignore but treated as such by convention — never `git add` it. (You could explicitly add it to .gitignore as a defensive measure during the README sweep.)
- **Stale `tests/test_notion_agent_cli.py::TestProviderHappy::test_stream_callback_fires_on_each_chunk`** — once you add `on_text_delta_async`, add a parallel test exercising the async branch. Don't remove the sync test; both code paths matter.
