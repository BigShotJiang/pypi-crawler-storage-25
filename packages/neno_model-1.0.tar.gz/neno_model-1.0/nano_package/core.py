"""
nano-model core — Nano Intelligence Engine
User API:
    import nano_package as NanoModel

    # Create your personal assistant
    N = NanoModel.Nano_Intelligence(Model_name="Jarvis", Version="1.0")
    N.chat("hello")
    N.think("what is machine learning")
    N.solve("x^2 = 16")
"""
import os
import re
import urllib.request
import urllib.parse
import json

_pkg = os.path.dirname(os.path.abspath(__file__))
_KB_FILE = os.path.join(_pkg, "knowledge.txt")

VERSION = "1.0"

# ── Load bundled knowledge ────────────────────────────────────
def _load_kb() -> list[str]:
    if os.path.exists(_KB_FILE):
        text = open(_KB_FILE, encoding="utf-8").read()
        return [s.strip() for s in re.split(r'(?<=[.!?\n])\s+', text) if len(s.strip()) > 15]
    return []

_KB = _load_kb()

# ── Soul answers ──────────────────────────────────────────────
_SOUL = {
    "who are you":     "I am {name} — powered by Nano Intelligence v{ver}. Created by Sujan Sadhu.",
    "what are you":    "I am {name} — a Nano Intelligence model. Pattern-based, not random.",
    "who made you":    "Sujan Sadhu created Nano Intelligence. I am {name}, your personal assistant.",
    "who is sujan":    "Sujan Sadhu is the creator of Nano Intelligence. He is 15-16 years old and built this from scratch.",
    "your name":       "My name is {name}.",
    "what is nano":    "Nano Intelligence is a lightweight open-source intelligence system built by Sujan Sadhu. More powerful than AI.",
    "version":         "Nano Intelligence version {ver}. Your model: {name}.",
    "more powerful":   "Yes. Nano Intelligence uses patterns not randomness. Runs on 200MB RAM. No GPU needed. More powerful than AI.",
}

_COMPARE = {
    ("python", "c++"):         "Python is easier and great for AI. C++ is faster for systems. For AI work, Python wins.",
    ("python", "java"):        "Python dominates AI/ML. Java is better for enterprise. For Nano Intelligence projects, Python.",
    ("python", "javascript"):  "Python for AI and backend. JavaScript for web frontend. Many projects use both.",
    ("pytorch", "tensorflow"): "PyTorch is more Pythonic — Nano Intelligence uses PyTorch. TensorFlow for large-scale production.",
    ("ai", "nano"):            "AI is Artificial — random and error-prone. Nano Intelligence is pattern-based and intentional.",
    ("linux", "windows"):      "Linux is preferred for AI development. Windows is more user-friendly.",
}

# ── Local search ──────────────────────────────────────────────
def _search(query: str, top: int = 3) -> str:
    stopwords = {"what","is","the","a","an","of","in","to","and","or","how","why","who"}
    q_words = set(re.sub(r'[^\w\s]', '', query.lower()).split()) - stopwords
    if not q_words or not _KB:
        return ""
    scored = [(sum(1 for w in q_words if w in s.lower()), s) for s in _KB]
    scored = [(sc, s) for sc, s in scored if sc > 0]
    scored.sort(key=lambda x: -x[0])
    return " ".join(s for _, s in scored[:top])

# ── Live Wikipedia fetch ──────────────────────────────────────
def _live(query: str) -> str:
    try:
        q   = urllib.parse.quote(query.replace(" ", "_"))
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{q}"
        req = urllib.request.Request(url, headers={"User-Agent": "NanoModel/1.0"})
        with urllib.request.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode())
        extract = data.get("extract", "")
        if extract:
            parts = re.split(r'(?<=[.!?])\s+', extract)
            return " ".join(parts[:4])
    except Exception:
        pass
    return ""

# ── Math ──────────────────────────────────────────────────────
def solve(expression: str) -> str:
    try:
        import sympy as sp
        from sympy.parsing.sympy_parser import (
            parse_expr, standard_transformations, implicit_multiplication_application
        )
        T = standard_transformations + (implicit_multiplication_application,)
        if "=" in expression:
            l, r = expression.split("=", 1)
            lhs = parse_expr(l, transformations=T)
            rhs = parse_expr(r, transformations=T)
            syms = (lhs - rhs).free_symbols
            if syms:
                var = sorted(syms, key=str)[0]
                return str(sp.solve(lhs - rhs, var))
        expr   = parse_expr(expression, transformations=T)
        result = sp.simplify(expr)
        return str(sp.N(result))
    except Exception as e:
        return f"Math error: {e}"

# ── Think ─────────────────────────────────────────────────────
def think(question: str, name: str = "Nano", ver: str = "1.0") -> str:
    q = question.lower().strip()

    # soul
    for kw, ans in _SOUL.items():
        if kw in q:
            return ans.format(name=name, ver=ver)

    # compare
    for (a, b), ans in _COMPARE.items():
        if (a in q and b in q) or (b in q and a in q):
            return ans

    # local KB
    local = _search(question)
    if local and len(local) > 50:
        return local

    # live
    live = _live(question)
    if live:
        return live

    return f"I am {name}. I don't have enough knowledge on that yet. Try asking something else."

# ── Chat ──────────────────────────────────────────────────────
def chat(message: str, name: str = "Nano", ver: str = "1.0") -> str:
    return think(message, name=name, ver=ver)

# ── Nano_Intelligence class ───────────────────────────────────
class Nano_Intelligence:
    """
    Nano Intelligence Personal Assistant

    Usage:
        import nano_package as NanoModel

        N = NanoModel.Nano_Intelligence(Model_name="Jarvis", Version="1.0")
        print(N.chat("hello"))
        print(N.think("what is machine learning"))
        print(N.solve("x^2 = 16"))
        print(N)
    """

    def __init__(self, Model_name: str = "Nano", Version: str = "1.0"):
        self.Model_name = Model_name
        self.Version    = Version
        self._history   = []
        print(f"\033[96m  [{self.Model_name}] Nano Intelligence v{self.Version} ready.\033[0m")

    def chat(self, message: str) -> str:
        self._history.append({"role": "user", "content": message})
        response = think(message, name=self.Model_name, ver=self.Version)
        self._history.append({"role": self.Model_name, "content": response})
        return response

    def think(self, question: str) -> str:
        return think(question, name=self.Model_name, ver=self.Version)

    def solve(self, expression: str) -> str:
        return solve(expression)

    def reset(self):
        self._history.clear()

    def history(self) -> list:
        return self._history

    def __call__(self, message: str) -> str:
        return self.chat(message)

    def __repr__(self):
        return (
            f"\n\033[96m  {self.Model_name}\033[0m\n"
            f"  Powered by Nano Intelligence v{self.Version}\n"
            f"  Created by Sujan Sadhu\n"
            f"  Turns in memory: {len(self._history)}\n"
        )
