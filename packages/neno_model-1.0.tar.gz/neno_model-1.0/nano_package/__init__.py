"""
nano-model — Nano Intelligence
pip install nano-model
"""
import sys
import time

# ── Professional install banner (shows on first import) ──────
_BANNER = """
\033[96m
███╗   ██╗ █████╗ ███╗   ██╗ ██████╗
████╗  ██║██╔══██╗████╗  ██║██╔═══██╗
██╔██╗ ██║███████║██╔██╗ ██║██║   ██║
██║╚██╗██║██╔══██║██║╚██╗██║██║   ██║
██║ ╚████║██║  ██║██║ ╚████║╚██████╔╝
╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝

  T E C H N O L O G Y
\033[0m
\033[90m  Nano Intelligence v1.0 | Created by Sujan Sadhu\033[0m
"""

def _show_banner():
    print(_BANNER)

def _loading_bar(label: str, total: int = 30, delay: float = 0.04):
    import sys
    print(f"\033[93m  {label}\033[0m")
    sys.stdout.write("  \033[96m[\033[0m")
    for i in range(total):
        time.sleep(delay)
        filled = "█" * (i + 1)
        empty  = "░" * (total - i - 1)
        pct    = int((i + 1) / total * 100)
        sys.stdout.write(f"\r  \033[96m[{filled}{empty}] {pct}%\033[0m ")
        sys.stdout.flush()
    print(f"\r  \033[92m[{'█' * total}] 100% ✓\033[0m")

def _install_sequence():
    _show_banner()
    time.sleep(0.3)

    steps = [
        ("Downloading Nano Model...........  ", 35, 0.035),
        ("Downloading packages..............  ", 28, 0.030),
        ("Running tests.....................  ", 20, 0.025),
    ]

    for label, total, delay in steps:
        _loading_bar(label, total, delay)
        time.sleep(0.15)

    print()
    print("\033[92m  ✓ Downloaded successfully — Nano Model\033[0m")
    print("\033[92m  ✓ Packages downloaded successfully\033[0m")
    print("\033[92m  ✓ Tests passed\033[0m")
    print()
    print("\033[96m  Ready. Use:\033[0m")
    print("\033[97m    import nano_package as NanoModel\033[0m")
    print("\033[97m    N = NanoModel.Nano_Intelligence(Model_name=\"Jarvis\", Version=\"1.0\")\033[0m")
    print("\033[97m    N.chat(\"hello\")\033[0m")
    print()

# Show on first install (when __version__ file doesn't exist)
import os as _os
_flag = _os.path.join(_os.path.dirname(__file__), ".installed")
if not _os.path.exists(_flag):
    _install_sequence()
    open(_flag, "w").close()

from .core import Nano_Intelligence, chat, think, solve

__version__ = "1.0"
__author__  = "Sujan Sadhu"
__all__     = ["Nano_Intelligence", "chat", "think", "solve"]
