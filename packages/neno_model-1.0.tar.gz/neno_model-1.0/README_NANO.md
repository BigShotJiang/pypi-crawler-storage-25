# nano-model — Nano Intelligence

More powerful than AI. Lightweight. Open source. Built by Sujan Sadhu (age 15-16).

## Install

```bash
pip install nano-model
```

## Usage

```python
import nano_package as NanoModel

# Create your personal assistant with your own name
N = NanoModel.Nano_Intelligence(Model_name="Jarvis", Version="1.0")

# Chat
print(N.chat("hello"))
print(N.think("what is machine learning"))
print(N.solve("x^2 = 16"))

# Print model info
print(N)
```

## Output

```
  [Jarvis] Nano Intelligence v1.0 ready.

  Jarvis
  Powered by Nano Intelligence v1.0
  Created by Sujan Sadhu
```

## Features

- Runs on CPU, 200MB RAM, no GPU
- Pattern-based intelligence
- Live knowledge from Wikipedia
- Math solver
- Custom model naming
- MIT license

## Created By

Sujan Sadhu — age 15-16 — built from scratch.

## Keywords

nano intelligence, nano model, NI, lightweight AI, python AI, open source LLM,
small language model, CPU AI, no GPU, sujan sadhu, nano-model pip
