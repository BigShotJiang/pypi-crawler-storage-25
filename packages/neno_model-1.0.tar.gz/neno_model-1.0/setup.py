from setuptools import setup, find_packages

setup(
    name="neno-model",
    version="1.0",
    author="Sujan Sadhu",
    description="Nano Intelligence — More powerful than AI. Built by Sujan Sadhu (age 15-16).",
    long_description=open("README_NANO.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=["nano_package"],
    package_data={"nano_package": ["knowledge.txt"]},
    include_package_data=True,
    python_requires=">=3.10",
    install_requires=["sympy"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
