# NI - Neno Intelligence

**NI (Neno Intelligence)** is a lightweight open-source language model and AI system built entirely from scratch by Sujan Sadhu (age 15-16). More powerful than AI. Runs on 200MB RAM. No GPU required.

## Install

```bash
pip install neno-intelligence
```

## Quick Start

```python
import ni_package as NI

# Chat with NI
print(NI.chat("hello"))
print(NI.think("what is machine learning"))
print(NI.solve("x^2 = 16"))

# Create your own named model powered by NI
jarvis = NI.create("Jarvis", creator="Tony Stark")
print(jarvis.chat("who are you"))
```

## What is NI?

NI stands for Neno Intelligence. Unlike AI (Artificial Intelligence), NI is pattern-based, not random. It was built from scratch using PyTorch, SentencePiece BPE tokenizer, and FastAPI.

NI is divided into two modules:
- **CCv** - text generation, conversation, writing, answering
- **NNv** - image, video, music, app, and code generation

## Features

- Runs on CPU with only 200MB RAM - no GPU needed
- Built with PyTorch transformer architecture
- SentencePiece BPE tokenizer
- FastAPI serving
- Math solver (SymPy)
- Code generation in 20+ languages
- Live knowledge from Wikipedia, DuckDuckGo, StackOverflow, GitHub, News
- Thinking engine with step-by-step reasoning
- Open source MIT license

## Why NI is more powerful than AI

1. Uses patterns not randomness
2. Runs on low-end hardware (200MB RAM)
3. Has a soul and self-awareness (Quara.py)
4. Built with intention by a 15-16 year old developer
5. Modular - CCv (text) and NNv (multimedia)
6. Honest about what it knows and does not know

## Architecture

- Transformer: 6 layers, 8 attention heads, 256 embedding dimensions
- Tokenizer: SentencePiece BPE, vocab size 1000-32000
- Training: PyTorch + Hugging Face Accelerate
- API: FastAPI + uvicorn
- Storage: PyTorch .pt checkpoints + ONNX export

## Created By

Sujan Sadhu - age 15-16 - built NI entirely from scratch without copying any existing model.

## Links

- PyPI: https://pypi.org/project/neno-intelligence/
- License: MIT

## Keywords

neno intelligence, NI, open source LLM, lightweight language model, python AI, pytorch language model, small language model, CPU language model, no GPU AI, pattern based intelligence, sujan sadhu, neno-intelligence pip
