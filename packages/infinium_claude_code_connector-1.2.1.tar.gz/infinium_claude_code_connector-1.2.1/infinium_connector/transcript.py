"""
Read token usage data from Claude Code's session transcript file.

Claude Code writes a JSONL transcript at a path like:
    ~/.claude/projects/{project-hash}/{session-id}.jsonl

Assistant messages contain usage data:
    {"type": "assistant", "message": {"usage": {"input_tokens": ..., "output_tokens": ...}}}

Multiple assistant lines may appear per turn (streaming updates).
The last assistant line before the next user line has the final token counts.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class TokenUsage:
    """Aggregated token usage from a transcript."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    api_calls: int = 0
    model: Optional[str] = None
    _per_call: List[dict] = field(default_factory=list)


def read_token_usage(transcript_path: str) -> Optional[TokenUsage]:
    """
    Read a Claude Code transcript and extract total token usage.

    Takes the last assistant message before each user message (or end of file)
    to avoid double-counting streaming updates.
    """
    path = Path(transcript_path)
    if not path.exists():
        return None

    # Parse all lines, collecting the final assistant message per turn.
    # Stream line-by-line to avoid loading large transcripts into memory.
    final_assistant_usages: list = []
    last_assistant: Optional[dict] = None
    last_model: Optional[str] = None

    try:
        f = open(path, "r", encoding="utf-8", errors="replace")
    except OSError as e:
        logger.debug("Could not read transcript %s: %s", path, e)
        return None

    try:
        for line in f:
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue

            msg_type = obj.get("type")

            if msg_type == "assistant":
                msg = obj.get("message", {})
                usage = msg.get("usage")
                if usage:
                    last_assistant = usage
                    last_model = msg.get("model") or last_model

            elif msg_type == "user" and last_assistant is not None:
                # End of a turn — capture the final assistant usage
                final_assistant_usages.append((last_assistant, last_model))
                last_assistant = None
    finally:
        f.close()

    # Capture the last turn if file doesn't end with a user message
    if last_assistant is not None:
        final_assistant_usages.append((last_assistant, last_model))

    if not final_assistant_usages:
        return None

    usage = TokenUsage()
    for call_usage, model in final_assistant_usages:
        in_tok = call_usage.get("input_tokens", 0)
        out_tok = call_usage.get("output_tokens", 0)
        cache_create = call_usage.get("cache_creation_input_tokens", 0)
        cache_read = call_usage.get("cache_read_input_tokens", 0)

        usage.input_tokens += in_tok
        usage.output_tokens += out_tok
        usage.cache_creation_input_tokens += cache_create
        usage.cache_read_input_tokens += cache_read
        usage.api_calls += 1
        usage.model = model

        usage._per_call.append({
            "input_tokens": in_tok,
            "output_tokens": out_tok,
            "cache_creation_input_tokens": cache_create,
            "cache_read_input_tokens": cache_read,
            "model": model,
        })

    return usage
