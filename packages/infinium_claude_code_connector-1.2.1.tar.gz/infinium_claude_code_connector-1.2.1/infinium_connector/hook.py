"""
Command hook entry point for Claude Code.

Claude Code invokes this script for each hook event, passing JSON on stdin.
Events are accumulated in session JSONL files. On flush events (Stop, SessionEnd),
a detached background process is spawned to aggregate and send the trace so that
Claude Code is never blocked waiting for network I/O.

Usage (configured automatically by `infinium init`):
    echo '{"hook_event_name":"Stop","session_id":"abc"}' | python -m infinium_connector.hook
"""
from __future__ import annotations

import json
import logging
import random
import subprocess
import sys

logger = logging.getLogger(__name__)

# Events that trigger a trace flush (in a background worker)
_FLUSH_EVENTS = frozenset({"Stop", "SessionEnd"})

# Probability of running stale-file cleanup on non-flush events (1 in 20)
_CLEANUP_PROBABILITY = 0.05


def _spawn_flush(session_id: str, event_name: str, cwd: str, session_dir: str | None = None) -> None:
    """Spawn a detached background process to flush the session.

    The worker performs all slow operations (file reads, transcript parsing,
    HTTP requests, retries) outside of the hook process so Claude Code can
    continue immediately.
    """
    cmd = [
        sys.executable, "-m", "infinium_connector.flush_worker",
        "--session-id", session_id,
        "--event-name", event_name,
        "--cwd", cwd,
    ]
    if session_dir:
        cmd.extend(["--session-dir", session_dir])

    kwargs: dict = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        DETACHED_PROCESS = 0x00000008
        CREATE_NO_WINDOW = 0x08000000
        kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NO_WINDOW
    else:
        kwargs["start_new_session"] = True

    try:
        subprocess.Popen(cmd, **kwargs)
    except Exception:
        logger.debug("Failed to spawn flush worker", exc_info=True)


def _spawn_cleanup(cwd: str, session_dir: str | None = None) -> None:
    """Spawn a detached background process to clean up stale session files."""
    cmd = [
        sys.executable, "-m", "infinium_connector.flush_worker",
        "--cleanup",
        "--cwd", cwd,
    ]
    if session_dir:
        cmd.extend(["--session-dir", session_dir])

    kwargs: dict = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        DETACHED_PROCESS = 0x00000008
        CREATE_NO_WINDOW = 0x08000000
        kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NO_WINDOW
    else:
        kwargs["start_new_session"] = True

    try:
        subprocess.Popen(cmd, **kwargs)
    except Exception:
        logger.debug("Failed to spawn cleanup worker", exc_info=True)


def main() -> None:
    """Read a hook event from stdin, store it, and spawn background flush if needed."""
    # Minimal logging setup — errors go to stderr
    logging.basicConfig(
        level=logging.WARNING,
        format="[infinium-connector] %(levelname)s: %(message)s",
        stream=sys.stderr,
    )

    # Read JSON from stdin
    try:
        raw = sys.stdin.read()
    except Exception:
        logger.debug("Failed to read from stdin", exc_info=True)
        return

    if not raw.strip():
        return

    try:
        event = json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("Invalid JSON from Claude Code hook")
        return

    if not isinstance(event, dict):
        return

    # Stamp arrival time if Claude Code didn't include a timestamp.
    if not event.get("timestamp"):
        from datetime import datetime, timezone
        event["timestamp"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    event_name = event.get("hook_event_name", "Unknown")
    session_id = event.get("session_id", "unknown")

    # Resolve cwd: always use the cwd from SessionStart so that traces go
    # to the project where the session was launched.
    from pathlib import Path
    from . import session_store
    from .config import ConnectorConfig

    event_cwd = Path(event["cwd"]) if event.get("cwd") else None

    if event_name != "SessionStart":
        origin = session_store.read_origin_cwd(session_id)
        if origin:
            event_cwd = Path(origin)

    # Lightweight config load — skips keyring access (the hook never needs
    # the agent secret; only the background flush worker does).
    config, paused = ConnectorConfig.load_hook_config(cwd=event_cwd)
    session_dir = config.session_dir

    if event_name == "SessionStart" and event_cwd:
        session_store.write_origin_cwd(session_id, str(event_cwd), session_dir)

    # Always store the event — even when paused — so that the session
    # file is complete when tracing resumes.  Only the *flush* is skipped.
    try:
        session_store.append_event(session_id, event, session_dir)
    except Exception:
        logger.exception("Failed to store event")
        return

    if paused and event_name != "SessionEnd":
        return

    # Spawn background worker for flush or cleanup — never block the hook.
    cwd_str = str(event_cwd) if event_cwd else "."

    if event_name == "Stop" and config.flush_on_stop:
        _spawn_flush(session_id, event_name, cwd_str, session_dir)
    elif event_name == "SessionEnd" and config.flush_on_session_end:
        _spawn_flush(session_id, event_name, cwd_str, session_dir)
    elif event_name == "SessionEnd":
        # Not flushing, but still clean up session files
        _spawn_cleanup(cwd_str, session_dir)
    elif random.random() < _CLEANUP_PROBABILITY:
        _spawn_cleanup(cwd_str, session_dir)


if __name__ == "__main__":
    main()
