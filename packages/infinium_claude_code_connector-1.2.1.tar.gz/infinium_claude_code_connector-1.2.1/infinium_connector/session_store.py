"""
JSONL-based session file storage for command hook mode.

Each Claude Code session gets a .jsonl file in a temp directory.
Events are appended as single JSON lines. On flush, all events
are read back and replayed through the aggregator.

Session metadata (flush offset, failure count, token snapshot, origin cwd)
is stored in a single .meta JSON sidecar file per session.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_SESSION_DIR_NAME = "infinium-sessions"


def get_session_dir(override: Optional[str] = None) -> Path:
    """Return the directory for session JSONL files, creating it if needed."""
    if override:
        d = Path(override)
    else:
        d = Path(tempfile.gettempdir()) / _SESSION_DIR_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def _session_path(session_id: str, session_dir: Optional[str] = None) -> Path:
    """Return the JSONL file path for a given session ID."""
    # Sanitize session_id for filesystem safety
    safe_id = "".join(c for c in session_id if c.isalnum() or c in "-_")
    if not safe_id:
        safe_id = f"unknown-{uuid.uuid4().hex[:8]}"
    return get_session_dir(session_dir) / f"{safe_id}.jsonl"


# ---------------------------------------------------------------------------
# Event I/O
# ---------------------------------------------------------------------------


def append_event(
    session_id: str,
    event: Dict[str, Any],
    session_dir: Optional[str] = None,
) -> None:
    """Append a single event as a JSON line to the session file."""
    path = _session_path(session_id, session_dir)
    line = json.dumps(event, default=str, separators=(",", ":")) + "\n"

    if sys.platform == "win32":
        _append_locked_win32(path, line.encode("utf-8"))
    else:
        # On Unix, O_APPEND + write is atomic for payloads < PIPE_BUF (4096+)
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)


def _lock_path(session_dir_path: Path) -> Path:
    """Return the shared lock file path for a session directory."""
    return session_dir_path / "infinium.lock"


def _append_locked_win32(path: Path, data: bytes) -> None:
    """Append with exclusive file lock on Windows to prevent concurrent write corruption.

    Uses a separate lock file rather than locking the data file itself,
    because msvcrt.locking operates on byte ranges relative to the current
    file position — which is unreliable with O_APPEND.

    Attempts a non-blocking lock first so the hook exits quickly.  Falls back
    to a short blocking retry (up to ~1s), then writes without a lock rather
    than blocking Claude Code for 10+ seconds.
    """
    import msvcrt

    lock = _lock_path(path.parent)
    lock_fd = os.open(str(lock), os.O_WRONLY | os.O_CREAT, 0o666)
    got_lock = False
    try:
        # Try non-blocking lock first
        try:
            msvcrt.locking(lock_fd, msvcrt.LK_NBLCK, 1)
            got_lock = True
        except OSError:
            # Brief retry — 3 attempts with 100ms spacing (~300ms total)
            for _attempt in range(3):
                time.sleep(0.1)
                try:
                    msvcrt.locking(lock_fd, msvcrt.LK_NBLCK, 1)
                    got_lock = True
                    break
                except OSError:
                    pass

        if not got_lock:
            logger.debug("Could not acquire lock for %s, writing without lock", path.name)

        # Write data to the actual session file (O_APPEND for atomicity)
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o666)
        try:
            os.write(fd, data)
            os.fsync(fd)
        finally:
            os.close(fd)

        if got_lock:
            os.lseek(lock_fd, 0, os.SEEK_SET)
            msvcrt.locking(lock_fd, msvcrt.LK_UNLCK, 1)
    finally:
        os.close(lock_fd)


def read_events(
    session_id: str,
    session_dir: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Read all events for a session, skipping malformed lines."""
    path = _session_path(session_id, session_dir)
    if not path.exists():
        return []

    events: List[Dict[str, Any]] = []
    skipped = 0
    total_lines = 0
    with open(path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            total_lines = line_num
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                skipped += 1
                logger.warning(
                    "Skipping malformed JSON on line %d of %s",
                    line_num,
                    path.name,
                )

    if skipped > 0:
        try:
            from . import error_log

            error_log.append_error(
                error_type="corrupted_jsonl",
                session_id=session_id[:12] if session_id else "unknown",
                message=f"Skipped {skipped} malformed line(s) in session file",
                context={"file": path.name, "total_lines": total_lines},
            )
        except Exception:
            pass

    return events


# ---------------------------------------------------------------------------
# Session metadata (.meta sidecar)
# ---------------------------------------------------------------------------


def _meta_path(session_id: str, session_dir: Optional[str] = None) -> Path:
    """Return the .meta sidecar path for a session."""
    return _session_path(session_id, session_dir).with_suffix(".meta")


def _read_meta(session_id: str, session_dir: Optional[str] = None) -> Dict[str, Any]:
    """Read the metadata sidecar. Returns empty dict if missing or corrupt."""
    path = _meta_path(session_id, session_dir)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _write_meta(
    session_id: str, data: Dict[str, Any], session_dir: Optional[str] = None
) -> None:
    """Write the metadata sidecar atomically."""
    path = _meta_path(session_id, session_dir)
    _atomic_write_sidecar(path, json.dumps(data, default=str) + "\n")


def _update_meta(
    session_id: str,
    updates: Dict[str, Any],
    session_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Read-modify-write the metadata sidecar with file locking.

    Holds a lock around the read-modify-write cycle to prevent concurrent
    hook processes from clobbering each other's updates.
    """
    d = get_session_dir(session_dir)
    if sys.platform == "win32":
        import msvcrt

        lock = _lock_path(d)
        lock_fd = os.open(str(lock), os.O_WRONLY | os.O_CREAT, 0o666)
        try:
            msvcrt.locking(lock_fd, msvcrt.LK_LOCK, 1)
            try:
                meta = _read_meta(session_id, session_dir)
                meta.update(updates)
                _write_meta(session_id, meta, session_dir)
            finally:
                os.lseek(lock_fd, 0, os.SEEK_SET)
                msvcrt.locking(lock_fd, msvcrt.LK_UNLCK, 1)
        finally:
            os.close(lock_fd)
    else:
        import fcntl

        lock = _lock_path(d)
        lock_fd = os.open(str(lock), os.O_WRONLY | os.O_CREAT, 0o666)
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            try:
                meta = _read_meta(session_id, session_dir)
                meta.update(updates)
                _write_meta(session_id, meta, session_dir)
            finally:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
        finally:
            os.close(lock_fd)
    return meta


def _atomic_write_sidecar(path: Path, content: str) -> None:
    """Write content atomically via temp file + os.replace."""
    tmp: Optional[str] = None
    try:
        fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp, str(path))
    except OSError:
        # Clean up temp file if it was created
        if tmp is not None:
            try:
                os.unlink(tmp)
            except OSError:
                pass
        # Fall back to direct write (metadata is small and recoverable)
        path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------------------
# Public metadata accessors (delegate to .meta sidecar)
# ---------------------------------------------------------------------------


def read_flush_offset(session_id: str, session_dir: Optional[str] = None) -> int:
    """Read the number of events already flushed. Returns 0 if missing."""
    return _read_meta(session_id, session_dir).get("flush_offset", 0)


def write_flush_offset(
    session_id: str, count: int, session_dir: Optional[str] = None
) -> None:
    """Write the flush offset (number of events already sent)."""
    _update_meta(session_id, {"flush_offset": count}, session_dir)


def read_failure_count(session_id: str, session_dir: Optional[str] = None) -> int:
    """Read the number of consecutive flush failures. Returns 0 if missing."""
    return _read_meta(session_id, session_dir).get("failure_count", 0)


def increment_failure_count(
    session_id: str, session_dir: Optional[str] = None
) -> int:
    """Increment and return the consecutive failure count."""
    count = read_failure_count(session_id, session_dir) + 1
    _update_meta(session_id, {"failure_count": count}, session_dir)
    return count


def reset_failure_count(session_id: str, session_dir: Optional[str] = None) -> None:
    """Reset the failure count (on successful flush)."""
    meta = _read_meta(session_id, session_dir)
    if "failure_count" in meta:
        meta.pop("failure_count")
        _write_meta(session_id, meta, session_dir)


def read_origin_cwd(session_id: str, session_dir: Optional[str] = None) -> Optional[str]:
    """Read the origin cwd recorded at SessionStart. Returns None if not set."""
    return _read_meta(session_id, session_dir).get("origin_cwd")


def write_origin_cwd(
    session_id: str, cwd: str, session_dir: Optional[str] = None
) -> None:
    """Record the cwd from SessionStart so all events use the same config."""
    meta = _read_meta(session_id, session_dir)
    if "origin_cwd" not in meta:  # only write once per session
        meta["origin_cwd"] = cwd
        _write_meta(session_id, meta, session_dir)


def read_token_snapshot(session_id: str, session_dir: Optional[str] = None) -> Dict[str, int]:
    """Read the cumulative token snapshot from the last successful flush."""
    return _read_meta(session_id, session_dir).get("token_snapshot", {})


def write_token_snapshot(
    session_id: str,
    snapshot: Dict[str, int],
    session_dir: Optional[str] = None,
) -> None:
    """Write the cumulative token snapshot after a successful flush."""
    _update_meta(session_id, {"token_snapshot": snapshot}, session_dir)


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------


def remove_session(
    session_id: str,
    session_dir: Optional[str] = None,
) -> None:
    """Delete the session file and its metadata sidecar."""
    for path in (
        _session_path(session_id, session_dir),
        _meta_path(session_id, session_dir),
    ):
        try:
            path.unlink(missing_ok=True)
        except OSError as e:
            logger.warning("Could not remove %s: %s", path, e)


def _failed_dir(session_dir: Optional[str] = None) -> Path:
    """Return the failed/ subdirectory inside the session directory."""
    d = get_session_dir(session_dir) / "failed"
    d.mkdir(parents=True, exist_ok=True)
    return d


def move_to_failed(
    session_id: str,
    session_dir: Optional[str] = None,
) -> Optional[Path]:
    """Move a session file (and its metadata) to the failed/ directory for later retry."""
    src = _session_path(session_id, session_dir)
    if not src.exists():
        return None

    dest = _failed_dir(session_dir) / src.name
    try:
        src.rename(dest)
        logger.info("Moved failed session to: %s", dest)
    except OSError as e:
        logger.warning("Could not move session to failed/: %s", e)
        return None

    # Also move the .meta sidecar
    meta = _meta_path(session_id, session_dir)
    if meta.exists():
        try:
            meta.rename(_failed_dir(session_dir) / meta.name)
        except OSError as e:
            logger.warning("Could not move sidecar to failed/: %s", e)

    return dest


def list_failed(session_dir: Optional[str] = None) -> List[Path]:
    """Return list of JSONL files in the failed/ directory."""
    d = get_session_dir(session_dir) / "failed"
    if not d.exists():
        return []
    return sorted(d.glob("*.jsonl"))


def count_failed(session_dir: Optional[str] = None) -> int:
    """Count the number of failed session files."""
    return len(list_failed(session_dir))


def read_failed_events(path: Path) -> List[Dict[str, Any]]:
    """Read all events from a failed session file."""
    if not path.exists():
        return []

    events: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return events


def remove_failed(path: Path) -> None:
    """Delete a specific failed session file and its metadata."""
    try:
        path.unlink(missing_ok=True)
    except OSError as e:
        logger.warning("Could not remove failed file %s: %s", path, e)
    # Also remove the .meta sidecar
    meta = path.with_suffix(".meta")
    try:
        meta.unlink(missing_ok=True)
    except OSError:
        pass


def cleanup_stale(
    max_age_seconds: int = 3600,
    session_dir: Optional[str] = None,
) -> List[str]:
    """Remove session files older than max_age_seconds. Returns removed filenames."""
    d = get_session_dir(session_dir)
    now = time.time()
    removed: List[str] = []

    for path in d.glob("*.jsonl"):
        try:
            age = now - path.stat().st_mtime
            if age > max_age_seconds:
                path.unlink()
                # Remove sidecar files (.meta and legacy formats)
                for suffix in (".meta", ".flushed", ".failures", ".tokens", ".origin"):
                    sidecar = path.with_suffix(suffix)
                    if sidecar.exists():
                        sidecar.unlink(missing_ok=True)
                removed.append(path.stem)
                logger.info("Removed stale session file: %s (age: %ds)", path.name, int(age))
        except OSError as e:
            logger.warning("Error cleaning up %s: %s", path, e)

    # Clean up orphaned sidecar files (no matching .jsonl)
    # Includes legacy suffixes from before the .meta consolidation.
    for suffix in ("*.meta", "*.flushed", "*.failures", "*.tokens", "*.origin"):
        for sidecar in d.glob(suffix):
            jsonl = sidecar.with_suffix(".jsonl")
            if not jsonl.exists():
                try:
                    sidecar.unlink()
                except OSError:
                    pass

    return removed
