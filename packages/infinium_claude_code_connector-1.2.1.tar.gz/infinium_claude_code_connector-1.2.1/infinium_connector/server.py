"""
HTTP server that receives Claude Code hook events and forwards traces to Infinium.

Requires the [server] optional extra: pip install infinium-claude-code-connector[server]
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

from . import __version__

try:
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import JSONResponse
    from starlette.routing import Route
except ImportError:
    raise ImportError(
        "HTTP server mode requires the [server] extra. "
        "Install with: pip install infinium-claude-code-connector[server]"
    )

from .aggregator import SessionAggregator
from .config import ConnectorConfig
from . import sdk_bridge
from .types import InfiniumTracePayload

logger = logging.getLogger(__name__)


def create_app(config: Optional[ConnectorConfig] = None) -> Starlette:
    """
    Build the ASGI application.

    The app exposes:
      POST {webhook_path}  — receive Claude Code hook events
      GET  /health          — health check
      POST /flush           — force-flush all sessions
      GET  /status          — current session stats
    """
    if config is None:
        config = ConnectorConfig.from_env()

    config.validate()

    aggregator = SessionAggregator(config)

    # Background task: evict stale sessions periodically
    async def _eviction_loop() -> None:
        while True:
            await asyncio.sleep(min(config.session_ttl_seconds / 2, 300))
            evicted = aggregator.evict_stale()
            if evicted:
                logger.info("Evicted %d stale session(s)", len(evicted))

    # ------------------------------------------------------------------
    # Route handlers
    # ------------------------------------------------------------------

    async def hook_handler(request: Request) -> JSONResponse:
        """Receive a Claude Code hook event."""
        try:
            body = await request.json()
        except (json.JSONDecodeError, ValueError):
            return JSONResponse(
                {"error": "Invalid JSON"}, status_code=400
            )

        if not isinstance(body, dict):
            return JSONResponse(
                {"error": "Expected JSON object"}, status_code=400
            )

        event_name = body.get("hook_event_name", "Unknown")
        session_id = body.get("session_id", "unknown")

        logger.debug(
            "Received %s from session %s", event_name, session_id[:12]
        )

        try:
            event, payload = aggregator.ingest(body)
        except Exception:
            logger.exception("Error ingesting event")
            return JSONResponse(
                {"error": "Internal processing error"}, status_code=500
            )

        # If a payload was produced (session end or stop), send it async
        if payload is not None:
            asyncio.create_task(
                _send_payload(payload, config, session_id)
            )

        return JSONResponse({"status": "ok", "event": event_name})

    async def health_handler(request: Request) -> JSONResponse:
        return JSONResponse({
            "status": "healthy",
            "version": __version__,
            "active_sessions": aggregator.active_session_count,
        })

    async def status_handler(request: Request) -> JSONResponse:
        return JSONResponse({
            "active_sessions": aggregator.active_session_count,
            "agent_id": config.agent_id[:8] + "...",
            "hook_url": config.hook_url,
        })

    async def flush_handler(request: Request) -> JSONResponse:
        """Force-flush all active sessions."""
        payloads = aggregator.flush_all()
        sent = 0
        errors = 0
        for payload in payloads:
            try:
                await asyncio.to_thread(sdk_bridge.send_trace, config, payload)
                sent += 1
            except Exception:
                logger.exception("Error sending flushed trace")
                errors += 1
        return JSONResponse({
            "flushed": sent,
            "errors": errors,
        })

    # ------------------------------------------------------------------
    # App lifecycle
    # ------------------------------------------------------------------

    async def on_startup() -> None:
        logger.info(
            "Infinium Claude Code Connector started on %s", config.hook_url
        )
        logger.info("Agent ID: %s...", config.agent_id[:8])
        asyncio.create_task(_eviction_loop())

    async def on_shutdown() -> None:
        # Flush remaining sessions
        payloads = aggregator.flush_all()
        for payload in payloads:
            try:
                await asyncio.to_thread(sdk_bridge.send_trace, config, payload)
            except Exception:
                logger.exception("Error sending trace during shutdown")
        logger.info("Connector shut down.")

    routes = [
        Route(config.webhook_path, hook_handler, methods=["POST"]),
        Route("/health", health_handler, methods=["GET"]),
        Route("/status", status_handler, methods=["GET"]),
        Route("/flush", flush_handler, methods=["POST"]),
    ]

    app = Starlette(
        routes=routes,
        on_startup=[on_startup],
        on_shutdown=[on_shutdown],
    )

    return app


async def _send_payload(
    payload: InfiniumTracePayload,
    config: ConnectorConfig,
    session_id: str,
) -> None:
    """Fire-and-forget sender with error logging. Runs SDK sync client in thread."""
    try:
        result = await asyncio.to_thread(sdk_bridge.send_trace, config, payload)
        trace_id = result.get("traceId", result.get("id", "unknown"))
        logger.info(
            "Trace sent for session %s (traceId=%s)",
            session_id[:12],
            trace_id,
        )
    except Exception:
        logger.exception(
            "Failed to send trace for session %s", session_id[:12]
        )
