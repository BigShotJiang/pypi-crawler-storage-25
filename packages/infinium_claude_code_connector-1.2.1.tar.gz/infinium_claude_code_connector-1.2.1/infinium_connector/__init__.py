"""
Infinium Claude Code Connector — bridge between Claude Code hooks and Infinium agent tracing.
"""

__version__ = "1.2.1"

from .config import ConnectorConfig
from .aggregator import SessionAggregator

__all__ = ["ConnectorConfig", "SessionAggregator", "__version__"]
