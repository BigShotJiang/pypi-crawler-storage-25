"""Enable `python -m infinium_connector` as CLI entry point."""
from infinium_connector.cli import main

main()
