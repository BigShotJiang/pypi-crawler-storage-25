"""
Bridge between connector's InfiniumTracePayload and the infinium-o2 SDK.

Converts aggregated trace payloads into SDK TaskData objects
and sends them via InfiniumClient.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from infinium import (
    InfiniumClient,
    TaskData,
    ExecutionStep,
    ErrorDetail,
    EnvironmentContext,
    Development,
    General,
    LlmUsage,
    get_current_iso_datetime,
)

from . import __version__
from .config import ConnectorConfig
from .types import InfiniumTracePayload

logger = logging.getLogger(__name__)


def payload_to_task_data(payload: InfiniumTracePayload) -> TaskData:
    """Convert an InfiniumTracePayload into an SDK TaskData."""
    # Build ExecutionStep list from raw step dicts
    steps: Optional[List[ExecutionStep]] = None
    if payload.steps:
        steps = []
        for s in payload.steps:
            step_error = None
            if s.get("error"):
                step_error = ErrorDetail(
                    error_type=s["error"].get("error_type", "Error"),
                    message=s["error"].get("message", ""),
                    recoverable=s["error"].get("recoverable", True),
                )

            steps.append(
                ExecutionStep(
                    step_number=s.get("step_number", 0),
                    action=s.get("action", "unknown"),
                    description=s.get("description", ""),
                    duration_ms=s.get("duration_ms"),
                    input_preview=s.get("input_preview"),
                    output_preview=s.get("output_preview"),
                    error=step_error,
                    metadata=s.get("metadata"),
                )
            )

    # Build ErrorDetail list
    errors: Optional[List[ErrorDetail]] = None
    if payload.errors:
        errors = [
            ErrorDetail(
                error_type=e.get("error_type", "Error"),
                message=e.get("message", ""),
                recoverable=e.get("recoverable", True),
            )
            for e in payload.errors
        ]

    # Build EnvironmentContext
    environment: Optional[EnvironmentContext] = None
    if payload.environment:
        env = payload.environment
        environment = EnvironmentContext(
            framework=env.get("framework"),
            framework_version=env.get("framework_version"),
            sdk_version=env.get("sdk_version"),
            runtime=env.get("runtime"),
            region=env.get("region"),
            custom_tags=env.get("custom_tags"),
        )

    # Build domain sections
    development: Optional[Development] = None
    general: Optional[General] = None
    if payload.sections:
        dev_dict = payload.sections.get("development")
        if dev_dict:
            development = Development(
                framework_used=dev_dict.get("framework_used"),
                files_modified=dev_dict.get("files_modified"),
            )
        gen_dict = payload.sections.get("general")
        if gen_dict:
            general = General(
                tools_used=gen_dict.get("tools_used"),
                tags=gen_dict.get("tags"),
            )

    # Build LlmUsage
    llm_usage: Optional[LlmUsage] = None
    if payload.llm_usage:
        u = payload.llm_usage
        llm_usage = LlmUsage(
            model=u.get("model"),
            provider=u.get("provider"),
            prompt_tokens=u.get("prompt_tokens"),
            completion_tokens=u.get("completion_tokens"),
            total_tokens=u.get("total_tokens"),
            api_calls_count=u.get("api_calls_count"),
        )
        # SDK doesn't have dedicated cache token fields — preserve them in
        # custom_tags so they reach Infinium and aren't silently dropped.
        cache_create = u.get("cache_creation_input_tokens", 0)
        cache_read = u.get("cache_read_input_tokens", 0)
        if environment and (cache_create or cache_read):
            tags = dict(environment.custom_tags or {})
            tags["cache_creation_input_tokens"] = str(cache_create)
            tags["cache_read_input_tokens"] = str(cache_read)
            environment.custom_tags = tags

    return TaskData(
        name=payload.name,
        description=payload.description,
        current_datetime=payload.current_datetime,
        duration=payload.duration,
        input_summary=payload.input_summary,
        output_summary=payload.output_summary,
        steps=steps,
        errors=errors,
        environment=environment,
        llm_usage=llm_usage,
        development=development,
        general=general,
    )


def sanitize_str(text: str) -> str:
    """Remove lone surrogates that break strict UTF-8 encoding."""
    return text.encode("utf-8", errors="replace").decode("utf-8")


def sanitize_strings(obj: Any) -> Any:
    """Recursively replace lone surrogates in all strings to prevent UTF-8 encoding errors."""
    if isinstance(obj, str):
        return obj.encode("utf-8", errors="replace").decode("utf-8")
    if isinstance(obj, dict):
        return {k: sanitize_strings(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return type(obj)(sanitize_strings(item) for item in obj)
    return obj


def send_trace(config: ConnectorConfig, payload: InfiniumTracePayload) -> Dict[str, Any]:
    """
    Convert payload to TaskData and send via InfiniumClient.

    Returns the API response data dict.
    """
    # Sanitize all string-containing fields to remove lone surrogates that
    # break UTF-8 encoding.  Claude Code occasionally sends text with invalid
    # Unicode (e.g. \udc9d) which can appear in any field.
    for attr in ("name", "description", "input_summary", "output_summary",
                 "steps", "errors", "environment", "llm_usage", "sections"):
        val = getattr(payload, attr, None)
        if val is not None:
            setattr(payload, attr, sanitize_strings(val))

    task_data = payload_to_task_data(payload)

    with InfiniumClient(
        agent_id=config.agent_id,
        agent_secret=config.agent_secret,
        base_url=config.base_url,
        timeout=config.timeout,
        max_retries=config.max_retries,
        verify_ssl=config.verify_ssl,
        user_agent=f"infinium-claude-code-connector/{__version__}",
    ) as client:
        response = client.send_task_data(task_data)

    logger.info("Trace sent successfully: %s", getattr(response, "message", "OK"))
    return getattr(response, "data", None) or {}
