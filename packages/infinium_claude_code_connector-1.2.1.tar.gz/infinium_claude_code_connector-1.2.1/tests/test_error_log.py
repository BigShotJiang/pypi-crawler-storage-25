"""Tests for infinium_connector.error_log — persistent error logging."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from infinium_connector.jsonl_log import JsonlLog


# Use a fresh JsonlLog instance to avoid touching the real ~/.infinium/ path.


class TestErrorLog:
    def _make_log(self, tmp_path: Path) -> JsonlLog:
        return JsonlLog(tmp_path / "errors.jsonl", max_entries=500)

    def test_append_error(self, tmp_path):
        log = self._make_log(tmp_path)
        log.append({
            "timestamp": "2026-03-31T10:00:00Z",
            "error_type": "flush_failed",
            "session_id": "sess-abc123",
            "message": "Connection refused",
        })
        entries = log.read()
        assert len(entries) == 1
        assert entries[0]["error_type"] == "flush_failed"

    def test_read_last_n(self, tmp_path):
        log = self._make_log(tmp_path)
        for i in range(10):
            log.append({"index": i, "error_type": "test"})
        entries = log.read(limit=3)
        assert len(entries) == 3
        assert entries[0]["index"] == 7

    def test_clear(self, tmp_path):
        log = self._make_log(tmp_path)
        log.append({"error_type": "test"})
        assert log.clear() is True
        assert log.read() == []

    def test_append_never_crashes(self, tmp_path):
        """error_log.append_error is designed to never raise."""
        from infinium_connector import error_log

        # Patch the module-level _log to use our temp path
        test_log = self._make_log(tmp_path)
        with patch.object(error_log, "_log", test_log):
            # Normal call
            error_log.append_error("test", "sess-1", "test message")
            assert len(test_log.read()) == 1

    def test_append_with_context(self, tmp_path):
        from infinium_connector import error_log

        test_log = self._make_log(tmp_path)
        with patch.object(error_log, "_log", test_log):
            error_log.append_error(
                "config_error", "sess-1", "Missing agent_id",
                context={"event_name": "Stop"},
            )
            entry = test_log.read()[0]
            assert entry["context"]["event_name"] == "Stop"

    def test_last_error(self, tmp_path):
        from infinium_connector import error_log

        test_log = self._make_log(tmp_path)
        with patch.object(error_log, "_log", test_log):
            assert error_log.last_error() is None
            error_log.append_error("e1", "s1", "first")
            error_log.append_error("e2", "s2", "second")
            last = error_log.last_error()
            assert last["error_type"] == "e2"

    def test_message_truncated_to_200(self, tmp_path):
        from infinium_connector import error_log

        test_log = self._make_log(tmp_path)
        with patch.object(error_log, "_log", test_log):
            error_log.append_error("test", "s1", "x" * 500)
            entry = test_log.read()[0]
            assert len(entry["message"]) <= 200

    def test_session_id_truncated(self, tmp_path):
        from infinium_connector import error_log

        test_log = self._make_log(tmp_path)
        with patch.object(error_log, "_log", test_log):
            error_log.append_error("test", "a" * 50, "msg")
            entry = test_log.read()[0]
            assert len(entry["session_id"]) == 12
