"""Tests for infinium_connector.session_store — JSONL I/O, metadata, locking."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict
from unittest.mock import patch, MagicMock

import pytest

from infinium_connector import session_store


# ---------------------------------------------------------------------------
# Event I/O
# ---------------------------------------------------------------------------


class TestAppendAndReadEvents:
    def test_append_creates_session_file(self, session_dir: str):
        session_store.append_event("sess-1", {"msg": "hello"}, session_dir)
        events = session_store.read_events("sess-1", session_dir)
        assert len(events) == 1
        assert events[0]["msg"] == "hello"

    def test_append_multiple_events(self, session_dir: str):
        for i in range(5):
            session_store.append_event("sess-1", {"i": i}, session_dir)
        events = session_store.read_events("sess-1", session_dir)
        assert len(events) == 5
        assert [e["i"] for e in events] == [0, 1, 2, 3, 4]

    def test_read_nonexistent_session(self, session_dir: str):
        assert session_store.read_events("nope", session_dir) == []

    def test_read_skips_malformed_json(self, session_dir: str):
        # Write a file with a corrupt line
        d = session_store.get_session_dir(session_dir)
        path = d / "sess-corrupt.jsonl"
        path.write_text(
            '{"good":1}\nBAD LINE\n{"good":2}\n', encoding="utf-8"
        )
        events = session_store.read_events("sess-corrupt", session_dir)
        assert len(events) == 2

    def test_sanitizes_session_id(self, session_dir: str):
        # Special characters should be stripped
        session_store.append_event("../../evil", {"attack": True}, session_dir)
        events = session_store.read_events("../../evil", session_dir)
        # The sanitized ID should still work
        assert len(events) == 1

    def test_empty_session_id_gets_uuid(self, session_dir: str):
        # Empty session_id should get a UUID-based fallback
        session_store.append_event("", {"empty": True}, session_dir)
        # Can't easily read it back without knowing the UUID, but no crash


# ---------------------------------------------------------------------------
# Windows file locking (fsync fix)
# ---------------------------------------------------------------------------


@pytest.mark.skipif(sys.platform != "win32", reason="Windows-only")
class TestWindowsLocking:
    def test_append_locked_win32_fsyncs(self, session_dir: str):
        """Fix #2: os.fsync must be called after write."""
        d = session_store.get_session_dir(session_dir)
        path = d / "test-fsync.jsonl"
        data = b'{"test": true}\n'

        with patch("os.fsync") as mock_fsync:
            session_store._append_locked_win32(path, data)
            mock_fsync.assert_called_once()

    def test_append_locked_win32_writes_data(self, session_dir: str):
        d = session_store.get_session_dir(session_dir)
        path = d / "test-write.jsonl"
        data = b'{"key":"value"}\n'
        session_store._append_locked_win32(path, data)
        content = path.read_text(encoding="utf-8")
        assert '"key":"value"' in content


# ---------------------------------------------------------------------------
# Metadata sidecar
# ---------------------------------------------------------------------------


class TestMetadata:
    def test_flush_offset_default(self, session_dir: str):
        assert session_store.read_flush_offset("sess-1", session_dir) == 0

    def test_write_and_read_flush_offset(self, session_dir: str):
        session_store.write_flush_offset("sess-1", 5, session_dir)
        assert session_store.read_flush_offset("sess-1", session_dir) == 5

    def test_failure_count_default(self, session_dir: str):
        assert session_store.read_failure_count("sess-1", session_dir) == 0

    def test_increment_failure_count(self, session_dir: str):
        assert session_store.increment_failure_count("sess-1", session_dir) == 1
        assert session_store.increment_failure_count("sess-1", session_dir) == 2
        assert session_store.increment_failure_count("sess-1", session_dir) == 3
        assert session_store.read_failure_count("sess-1", session_dir) == 3

    def test_reset_failure_count(self, session_dir: str):
        session_store.increment_failure_count("sess-1", session_dir)
        session_store.increment_failure_count("sess-1", session_dir)
        session_store.reset_failure_count("sess-1", session_dir)
        assert session_store.read_failure_count("sess-1", session_dir) == 0

    def test_reset_noop_when_no_failures(self, session_dir: str):
        # Should not crash or create metadata
        session_store.reset_failure_count("sess-1", session_dir)
        assert session_store.read_failure_count("sess-1", session_dir) == 0

    def test_origin_cwd(self, session_dir: str):
        assert session_store.read_origin_cwd("sess-1", session_dir) is None
        session_store.write_origin_cwd("sess-1", "/home/user/project", session_dir)
        assert session_store.read_origin_cwd("sess-1", session_dir) == "/home/user/project"

    def test_origin_cwd_write_once(self, session_dir: str):
        session_store.write_origin_cwd("sess-1", "/first", session_dir)
        session_store.write_origin_cwd("sess-1", "/second", session_dir)
        # Should keep the first value
        assert session_store.read_origin_cwd("sess-1", session_dir) == "/first"

    def test_token_snapshot(self, session_dir: str):
        assert session_store.read_token_snapshot("sess-1", session_dir) == {}
        snapshot = {"prompt_tokens": 100, "completion_tokens": 50}
        session_store.write_token_snapshot("sess-1", snapshot, session_dir)
        result = session_store.read_token_snapshot("sess-1", session_dir)
        assert result["prompt_tokens"] == 100
        assert result["completion_tokens"] == 50

    def test_corrupt_meta_returns_empty(self, session_dir: str):
        """Corrupt .meta file should return empty dict, not crash."""
        # Create a session file first so the path resolves
        session_store.append_event("sess-bad", {"x": 1}, session_dir)
        # Write corrupt metadata
        meta = session_store._meta_path("sess-bad", session_dir)
        meta.write_text("NOT JSON", encoding="utf-8")
        assert session_store.read_flush_offset("sess-bad", session_dir) == 0


# ---------------------------------------------------------------------------
# Metadata locking (Fix #6)
# ---------------------------------------------------------------------------


class TestMetaLocking:
    def test_update_meta_uses_file_lock(self, session_dir: str):
        """Fix #6: _update_meta must hold a lock during read-modify-write."""
        # We verify indirectly: concurrent increments should not lose counts.
        # Since we can't easily test true concurrency in a unit test, we verify
        # the lock mechanism is invoked.
        if sys.platform == "win32":
            with patch("msvcrt.locking") as mock_lock:
                session_store.increment_failure_count("sess-lock", session_dir)
                # Should have called locking at least once (lock + unlock)
                assert mock_lock.call_count >= 2
        else:
            with patch("fcntl.flock") as mock_flock:
                session_store.increment_failure_count("sess-lock", session_dir)
                assert mock_flock.call_count >= 2

    def test_metadata_consistency_after_multiple_updates(self, session_dir: str):
        """Multiple metadata fields should coexist correctly."""
        session_store.write_origin_cwd("sess-multi", "/project", session_dir)
        session_store.write_flush_offset("sess-multi", 10, session_dir)
        session_store.increment_failure_count("sess-multi", session_dir)
        snapshot = {"prompt_tokens": 500}
        session_store.write_token_snapshot("sess-multi", snapshot, session_dir)

        assert session_store.read_origin_cwd("sess-multi", session_dir) == "/project"
        assert session_store.read_flush_offset("sess-multi", session_dir) == 10
        assert session_store.read_failure_count("sess-multi", session_dir) == 1
        assert session_store.read_token_snapshot("sess-multi", session_dir)["prompt_tokens"] == 500


# ---------------------------------------------------------------------------
# Atomic write sidecar (Fix #7)
# ---------------------------------------------------------------------------


class TestAtomicWriteSidecar:
    def test_atomic_write_basic(self, session_dir: str):
        d = session_store.get_session_dir(session_dir)
        path = d / "test.meta"
        session_store._atomic_write_sidecar(path, '{"ok": true}\n')
        assert json.loads(path.read_text(encoding="utf-8"))["ok"] is True

    def test_atomic_write_fallback_on_replace_failure(self, session_dir: str):
        d = session_store.get_session_dir(session_dir)
        path = d / "test.meta"
        with patch("os.replace", side_effect=OSError("fail")):
            session_store._atomic_write_sidecar(path, '{"fallback": true}\n')
        # Fallback should still write the data
        assert json.loads(path.read_text(encoding="utf-8"))["fallback"] is True

    def test_atomic_write_no_unbound_error_on_mkstemp_failure(self, session_dir: str):
        """Fix #7: mkstemp failure must not cause UnboundLocalError."""
        d = session_store.get_session_dir(session_dir)
        path = d / "test.meta"
        with patch("tempfile.mkstemp", side_effect=OSError("no space")):
            # Should fall back to direct write, not raise UnboundLocalError
            session_store._atomic_write_sidecar(path, '{"safe": true}\n')
        assert json.loads(path.read_text(encoding="utf-8"))["safe"] is True

    def test_atomic_write_cleans_temp_file(self, session_dir: str):
        d = session_store.get_session_dir(session_dir)
        path = d / "test.meta"
        with patch("os.replace", side_effect=OSError("fail")):
            session_store._atomic_write_sidecar(path, '{"data": 1}\n')
        # No orphaned .tmp files
        tmp_files = list(d.glob("*.tmp"))
        assert len(tmp_files) == 0


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------


class TestSessionLifecycle:
    def test_remove_session(self, session_dir: str):
        session_store.append_event("sess-rm", {"x": 1}, session_dir)
        session_store.write_flush_offset("sess-rm", 1, session_dir)
        session_store.remove_session("sess-rm", session_dir)
        assert session_store.read_events("sess-rm", session_dir) == []
        assert session_store.read_flush_offset("sess-rm", session_dir) == 0

    def test_move_to_failed(self, session_dir: str):
        session_store.append_event("sess-fail", {"x": 1}, session_dir)
        session_store.write_flush_offset("sess-fail", 1, session_dir)
        dest = session_store.move_to_failed("sess-fail", session_dir)
        assert dest is not None
        assert dest.exists()
        # Original should be gone
        assert session_store.read_events("sess-fail", session_dir) == []

    def test_move_nonexistent_returns_none(self, session_dir: str):
        assert session_store.move_to_failed("nope", session_dir) is None

    def test_list_failed(self, session_dir: str):
        session_store.append_event("sess-f1", {"x": 1}, session_dir)
        session_store.move_to_failed("sess-f1", session_dir)
        failed = session_store.list_failed(session_dir)
        assert len(failed) == 1
        assert "sess-f1" in failed[0].stem

    def test_count_failed(self, session_dir: str):
        assert session_store.count_failed(session_dir) == 0
        session_store.append_event("sess-f1", {"x": 1}, session_dir)
        session_store.move_to_failed("sess-f1", session_dir)
        assert session_store.count_failed(session_dir) == 1

    def test_read_failed_events(self, session_dir: str):
        session_store.append_event("sess-f1", {"val": 42}, session_dir)
        dest = session_store.move_to_failed("sess-f1", session_dir)
        events = session_store.read_failed_events(dest)
        assert len(events) == 1
        assert events[0]["val"] == 42

    def test_remove_failed(self, session_dir: str):
        session_store.append_event("sess-f1", {"x": 1}, session_dir)
        dest = session_store.move_to_failed("sess-f1", session_dir)
        session_store.remove_failed(dest)
        assert not dest.exists()


# ---------------------------------------------------------------------------
# Stale cleanup
# ---------------------------------------------------------------------------


class TestCleanupStale:
    def test_cleanup_removes_old_files(self, session_dir: str):
        session_store.append_event("sess-old", {"x": 1}, session_dir)
        # Set mtime to 2 hours ago
        path = session_store._session_path("sess-old", session_dir)
        old_time = path.stat().st_mtime - 7200
        os.utime(str(path), (old_time, old_time))

        removed = session_store.cleanup_stale(max_age_seconds=3600, session_dir=session_dir)
        assert "sess-old" in removed

    def test_cleanup_keeps_recent_files(self, session_dir: str):
        session_store.append_event("sess-new", {"x": 1}, session_dir)
        removed = session_store.cleanup_stale(max_age_seconds=3600, session_dir=session_dir)
        assert "sess-new" not in removed

    def test_cleanup_removes_orphaned_sidecars(self, session_dir: str):
        d = session_store.get_session_dir(session_dir)
        # Create an orphaned .meta file (no matching .jsonl)
        orphan = d / "orphan-sess.meta"
        orphan.write_text("{}", encoding="utf-8")
        session_store.cleanup_stale(max_age_seconds=3600, session_dir=session_dir)
        assert not orphan.exists()

    def test_sidecar_move_failure_logs_warning(self, session_dir: str):
        """Fix #11: sidecar move failure should log, not silently pass."""
        session_store.append_event("sess-f1", {"x": 1}, session_dir)
        session_store.write_flush_offset("sess-f1", 1, session_dir)

        meta_path = session_store._meta_path("sess-f1", session_dir)
        assert meta_path.exists()

        with patch.object(Path, "rename", side_effect=[None, OSError("perm denied")]):
            with patch("infinium_connector.session_store.logger") as mock_logger:
                session_store.move_to_failed("sess-f1", session_dir)
                mock_logger.warning.assert_called()
