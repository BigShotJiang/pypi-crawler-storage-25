"""Shared fixtures for infinium_connector tests."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict

import pytest

from infinium_connector.types import InfiniumTracePayload


@pytest.fixture()
def tmp_dir(tmp_path: Path) -> Path:
    """A temporary directory for test artifacts."""
    return tmp_path


@pytest.fixture()
def session_dir(tmp_path: Path) -> str:
    """A temporary session directory (as string, matching config.session_dir)."""
    d = tmp_path / "sessions"
    d.mkdir()
    return str(d)


@pytest.fixture()
def sample_session_start() -> Dict[str, Any]:
    return {
        "hook_event_name": "SessionStart",
        "session_id": "sess-abc123",
        "timestamp": "2026-03-31T10:00:00Z",
        "cwd": "/home/user/project",
        "source": "startup",
        "model": "claude-sonnet-4-6",
        "permission_mode": "default",
    }


@pytest.fixture()
def sample_user_prompt() -> Dict[str, Any]:
    return {
        "hook_event_name": "UserPromptSubmit",
        "session_id": "sess-abc123",
        "timestamp": "2026-03-31T10:00:05Z",
        "prompt": "Fix the login bug",
    }


@pytest.fixture()
def sample_pre_tool_use() -> Dict[str, Any]:
    return {
        "hook_event_name": "PreToolUse",
        "session_id": "sess-abc123",
        "timestamp": "2026-03-31T10:00:10Z",
        "tool_name": "Read",
        "tool_use_id": "tool-001",
        "tool_input": {"file_path": "/home/user/project/src/login.py"},
    }


@pytest.fixture()
def sample_post_tool_use() -> Dict[str, Any]:
    return {
        "hook_event_name": "PostToolUse",
        "session_id": "sess-abc123",
        "timestamp": "2026-03-31T10:00:15Z",
        "tool_name": "Read",
        "tool_use_id": "tool-001",
        "tool_response": "file contents here...",
    }


@pytest.fixture()
def sample_stop() -> Dict[str, Any]:
    return {
        "hook_event_name": "Stop",
        "session_id": "sess-abc123",
        "timestamp": "2026-03-31T10:00:20Z",
        "last_assistant_message": "I fixed the login bug.",
    }


@pytest.fixture()
def sample_session_end() -> Dict[str, Any]:
    return {
        "hook_event_name": "SessionEnd",
        "session_id": "sess-abc123",
        "timestamp": "2026-03-31T10:01:00Z",
    }


@pytest.fixture()
def full_session_events(
    sample_session_start,
    sample_user_prompt,
    sample_pre_tool_use,
    sample_post_tool_use,
    sample_stop,
    sample_session_end,
) -> list:
    """A complete session lifecycle as a list of events."""
    return [
        sample_session_start,
        sample_user_prompt,
        sample_pre_tool_use,
        sample_post_tool_use,
        sample_stop,
        sample_session_end,
    ]


@pytest.fixture()
def small_payload() -> InfiniumTracePayload:
    """A minimal payload that fits well within size limits."""
    return InfiniumTracePayload(
        name="Test trace",
        description="A test trace",
        current_datetime="2026-03-31T10:00:00Z",
        duration=10.0,
        steps=[
            {"step_number": 1, "action": "user_prompt", "description": "Turn 1"},
        ],
        environment={"framework": "claude-code", "custom_tags": {}},
    )


@pytest.fixture()
def large_payload() -> InfiniumTracePayload:
    """A payload that exceeds the 950KB size limit."""
    big_text = "x" * 5000
    steps = [
        {
            "step_number": i,
            "action": "tool_use",
            "description": f"Step {i}",
            "input_preview": big_text,
            "output_preview": big_text,
        }
        for i in range(1, 201)
    ]
    return InfiniumTracePayload(
        name="Large trace",
        description="An oversized trace",
        current_datetime="2026-03-31T10:00:00Z",
        duration=60.0,
        steps=steps,
        environment={"framework": "claude-code", "custom_tags": {}},
    )


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Remove connector env vars so tests don't leak state."""
    for key in list(os.environ):
        if key.startswith(("CONNECTOR_", "INFINIUM_")):
            monkeypatch.delenv(key, raising=False)
