"""Tests for infinium_connector.transcript — token usage extraction."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from infinium_connector.transcript import read_token_usage


# ---------------------------------------------------------------------------
# Basic reading
# ---------------------------------------------------------------------------


class TestReadTokenUsage:
    def test_nonexistent_file(self):
        assert read_token_usage("/nonexistent/path.jsonl") is None

    def test_empty_file(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        path.write_text("", encoding="utf-8")
        assert read_token_usage(str(path)) is None

    def test_no_assistant_messages(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({"type": "user", "message": "hello"}),
            json.dumps({"type": "system", "message": "init"}),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        assert read_token_usage(str(path)) is None

    def test_single_turn(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 100, "output_tokens": 50},
                    "model": "claude-sonnet-4-6",
                },
            }),
            json.dumps({"type": "user", "message": "thanks"}),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        usage = read_token_usage(str(path))
        assert usage is not None
        assert usage.input_tokens == 100
        assert usage.output_tokens == 50
        assert usage.api_calls == 1
        assert usage.model == "claude-sonnet-4-6"

    def test_multiple_turns(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        lines = [
            # Turn 1
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 100, "output_tokens": 50},
                    "model": "claude-sonnet-4-6",
                },
            }),
            json.dumps({"type": "user", "message": "next"}),
            # Turn 2
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 200, "output_tokens": 80},
                    "model": "claude-sonnet-4-6",
                },
            }),
            json.dumps({"type": "user", "message": "done"}),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        usage = read_token_usage(str(path))
        assert usage.input_tokens == 300  # 100 + 200
        assert usage.output_tokens == 130  # 50 + 80
        assert usage.api_calls == 2

    def test_streaming_updates_deduplicated(self, tmp_path):
        """Multiple assistant messages before user should only count the last one."""
        path = tmp_path / "transcript.jsonl"
        lines = [
            # Streaming updates (intermediate)
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 50, "output_tokens": 10},
                    "model": "claude-sonnet-4-6",
                },
            }),
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 100, "output_tokens": 50},
                    "model": "claude-sonnet-4-6",
                },
            }),
            # Final count before user
            json.dumps({"type": "user", "message": "thanks"}),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        usage = read_token_usage(str(path))
        # Should use the last assistant message (100, 50), not sum both
        assert usage.input_tokens == 100
        assert usage.output_tokens == 50
        assert usage.api_calls == 1

    def test_cache_tokens(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {
                        "input_tokens": 1000,
                        "output_tokens": 200,
                        "cache_creation_input_tokens": 500,
                        "cache_read_input_tokens": 300,
                    },
                    "model": "claude-sonnet-4-6",
                },
            }),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        usage = read_token_usage(str(path))
        assert usage.cache_creation_input_tokens == 500
        assert usage.cache_read_input_tokens == 300

    def test_malformed_json_lines_skipped(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        content = (
            '{"type":"assistant","message":{"usage":{"input_tokens":100,"output_tokens":50},"model":"claude-sonnet-4-6"}}\n'
            "NOT JSON\n"
            '{"type":"user","message":"ok"}\n'
        )
        path.write_text(content, encoding="utf-8")

        usage = read_token_usage(str(path))
        assert usage is not None
        assert usage.input_tokens == 100

    def test_assistant_without_usage_skipped(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({"type": "assistant", "message": {"content": "hi"}}),
            json.dumps({"type": "user", "message": "ok"}),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        assert read_token_usage(str(path)) is None

    def test_last_turn_captured_without_trailing_user(self, tmp_path):
        """If file doesn't end with a user message, last assistant should still count."""
        path = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 100, "output_tokens": 50},
                    "model": "claude-sonnet-4-6",
                },
            }),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        usage = read_token_usage(str(path))
        assert usage is not None
        assert usage.api_calls == 1

    def test_per_call_data(self, tmp_path):
        path = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 100, "output_tokens": 50},
                    "model": "claude-sonnet-4-6",
                },
            }),
            json.dumps({"type": "user", "message": "ok"}),
            json.dumps({
                "type": "assistant",
                "message": {
                    "usage": {"input_tokens": 200, "output_tokens": 80},
                    "model": "claude-opus-4-6",
                },
            }),
        ]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        usage = read_token_usage(str(path))
        assert len(usage._per_call) == 2
        assert usage._per_call[0]["model"] == "claude-sonnet-4-6"
        assert usage._per_call[1]["model"] == "claude-opus-4-6"
        # Model should be the last one seen
        assert usage.model == "claude-opus-4-6"
