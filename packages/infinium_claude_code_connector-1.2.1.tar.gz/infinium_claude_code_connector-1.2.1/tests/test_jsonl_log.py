"""Tests for infinium_connector.jsonl_log — JSONL append, read, rotation."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from unittest.mock import patch

import pytest

from infinium_connector.jsonl_log import JsonlLog


# ---------------------------------------------------------------------------
# Basic append / read
# ---------------------------------------------------------------------------


class TestAppendRead:
    def test_append_creates_file(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        log.append({"msg": "hello"})
        assert log.path.exists()

    def test_read_empty_file(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        assert log.read() == []

    def test_append_and_read_single(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        log.append({"key": "value"})
        entries = log.read()
        assert len(entries) == 1
        assert entries[0]["key"] == "value"

    def test_append_multiple_and_read(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        for i in range(5):
            log.append({"index": i})
        entries = log.read()
        assert len(entries) == 5
        assert [e["index"] for e in entries] == [0, 1, 2, 3, 4]

    def test_read_with_limit(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        for i in range(10):
            log.append({"index": i})
        entries = log.read(limit=3)
        assert len(entries) == 3
        assert entries[0]["index"] == 7  # last 3

    def test_read_skips_malformed_lines(self, tmp_dir: Path):
        path = tmp_dir / "test.jsonl"
        path.write_text(
            '{"good": 1}\nNOT JSON\n{"good": 2}\n', encoding="utf-8"
        )
        log = JsonlLog(path, max_entries=100)
        entries = log.read()
        assert len(entries) == 2

    def test_read_skips_blank_lines(self, tmp_dir: Path):
        path = tmp_dir / "test.jsonl"
        path.write_text('{"a":1}\n\n\n{"b":2}\n', encoding="utf-8")
        log = JsonlLog(path, max_entries=100)
        assert len(log.read()) == 2

    def test_append_creates_parent_dirs(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "sub" / "deep" / "test.jsonl", max_entries=100)
        log.append({"nested": True})
        assert log.path.exists()
        assert log.read()[0]["nested"] is True


# ---------------------------------------------------------------------------
# Count and clear
# ---------------------------------------------------------------------------


class TestCountClear:
    def test_count_empty(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        assert log.count() == 0

    def test_count_entries(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        for i in range(7):
            log.append({"i": i})
        assert log.count() == 7

    def test_clear_removes_file(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=100)
        log.append({"msg": "bye"})
        assert log.clear() is True
        assert not log.path.exists()

    def test_clear_nonexistent_returns_false(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "nope.jsonl", max_entries=100)
        assert log.clear() is False


# ---------------------------------------------------------------------------
# Rotation
# ---------------------------------------------------------------------------


class TestRotation:
    def test_no_rotation_under_threshold(self, tmp_dir: Path):
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=10)
        for i in range(10):
            log.append({"i": i})
        # 10 entries, threshold is 10 * 1.2 = 12 → no rotation
        assert log.count() == 10

    def test_rotation_trims_to_max_entries(self, tmp_dir: Path):
        # max_entries=10, threshold=12.  Need > 12 entries to trigger rotation.
        # After 13th append, rotation fires: keeps last 10.
        # But the 13th entry is appended before rotation, so file has 13, then trimmed to 10.
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=10)
        for i in range(13):
            log.append({"i": i})
        entries = log.read()
        assert len(entries) == 10
        assert entries[0]["i"] == 3
        assert entries[-1]["i"] == 12

    def test_rotation_preserves_newest_entries(self, tmp_dir: Path):
        # max_entries=5, threshold=6.  Need > 6 entries to trigger.
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=5)
        for i in range(7):
            log.append({"i": i})
        entries = log.read()
        assert len(entries) == 5
        assert [e["i"] for e in entries] == [2, 3, 4, 5, 6]

    def test_rotation_failure_leaves_file_intact(self, tmp_dir: Path):
        """Fix #1: rotation failure must not truncate the file."""
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=5)
        for i in range(8):
            log.append({"i": i})

        # Reset to a known over-limit state
        lines = []
        for i in range(10):
            lines.append(json.dumps({"i": i}) + "\n")
        log.path.write_text("".join(lines), encoding="utf-8")

        # Make os.replace fail — the file should remain intact
        with patch("os.replace", side_effect=OSError("disk error")):
            log._rotate_if_needed()

        # Original file must still have all 10 entries (not truncated)
        entries = log.read()
        assert len(entries) == 10

    def test_rotation_cleans_up_temp_on_failure(self, tmp_dir: Path):
        """Fix #7: temp file should be cleaned up on failure."""
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=5)
        lines = [json.dumps({"i": i}) + "\n" for i in range(10)]
        log.path.write_text("".join(lines), encoding="utf-8")

        with patch("os.replace", side_effect=OSError("fail")):
            log._rotate_if_needed()

        # No .tmp files left behind
        tmp_files = list(tmp_dir.glob("*.tmp"))
        assert len(tmp_files) == 0

    def test_rotation_skipped_when_mtime_changes(self, tmp_dir: Path):
        """Fix #14: rotation should be skipped if another writer modified the file.

        We verify this by modifying the file between the first and second stat
        calls inside _rotate_if_needed. The open() call for reading happens
        between the two stat calls, so we hook into that to simulate a
        concurrent writer.
        """
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=5)
        lines = [json.dumps({"i": i}) + "\n" for i in range(10)]
        log.path.write_text("".join(lines), encoding="utf-8")

        _real_open = open
        opened_for_read = [False]

        def intercepting_open(path, mode="r", *args, **kwargs):
            f = _real_open(path, mode, *args, **kwargs)
            # After the file is opened for reading (between stat calls),
            # append to it to change the mtime
            if str(path) == str(log.path) and "r" in mode and not opened_for_read[0]:
                opened_for_read[0] = True
                # Append after a tiny delay to ensure mtime changes
                with _real_open(log.path, "a", encoding="utf-8") as w:
                    w.write(json.dumps({"concurrent": True}) + "\n")
                    w.flush()
                    os.fsync(w.fileno())
                # Touch with explicit future time to guarantee mtime differs
                import time
                future = time.time() + 2
                os.utime(str(log.path), (future, future))
            return f

        import builtins
        with patch.object(builtins, "open", intercepting_open):
            log._rotate_if_needed()

        # Rotation should have been skipped because mtime changed
        entries = log.read()
        assert len(entries) >= 10

    def test_tmp_path_none_when_mkstemp_fails(self, tmp_dir: Path):
        """Fix #7: UnboundLocalError must not occur if mkstemp fails."""
        log = JsonlLog(tmp_dir / "test.jsonl", max_entries=5)
        lines = [json.dumps({"i": i}) + "\n" for i in range(10)]
        log.path.write_text("".join(lines), encoding="utf-8")

        with patch("tempfile.mkstemp", side_effect=OSError("no space")):
            # Should not raise UnboundLocalError
            log._rotate_if_needed()

        # File should still be intact
        assert len(log.read()) == 10
