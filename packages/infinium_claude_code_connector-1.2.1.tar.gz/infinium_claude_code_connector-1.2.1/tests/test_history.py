"""Tests for infinium_connector.history — local trace history."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from infinium_connector.jsonl_log import JsonlLog


class TestHistory:
    def _make_log(self, tmp_path: Path) -> JsonlLog:
        return JsonlLog(tmp_path / "history.jsonl", max_entries=1000)

    def test_append_and_read(self, tmp_path):
        from infinium_connector import history

        test_log = self._make_log(tmp_path)
        with patch.object(history, "_log", test_log):
            history.append_entry({
                "timestamp": "2026-03-31T10:00:00Z",
                "session_id": "sess-abc123",
                "trace_id": "trace-1",
                "name": "Fix login bug",
                "turns": 3,
                "tool_calls": 5,
                "errors": 0,
                "duration_s": 45.2,
                "status": "sent",
            })
            entries = history.read_entries(limit=10)
            assert len(entries) == 1
            assert entries[0]["trace_id"] == "trace-1"

    def test_read_entries_with_limit(self, tmp_path):
        from infinium_connector import history

        test_log = self._make_log(tmp_path)
        with patch.object(history, "_log", test_log):
            for i in range(20):
                history.append_entry({"index": i, "status": "sent"})
            entries = history.read_entries(limit=5)
            assert len(entries) == 5
            assert entries[0]["index"] == 15

    def test_clear_history(self, tmp_path):
        from infinium_connector import history

        test_log = self._make_log(tmp_path)
        with patch.object(history, "_log", test_log):
            history.append_entry({"status": "sent"})
            assert history.clear_history() is True
            assert history.read_entries() == []

    def test_count_entries(self, tmp_path):
        from infinium_connector import history

        test_log = self._make_log(tmp_path)
        with patch.object(history, "_log", test_log):
            assert history.count_entries() == 0
            for i in range(5):
                history.append_entry({"index": i})
            assert history.count_entries() == 5
