"""Tests for infinium_connector.hook and infinium_connector.flush_worker."""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict
from unittest.mock import patch, MagicMock, call

import pytest

from infinium_connector.config import ConnectorConfig
from infinium_connector.flush_worker import (
    _compute_duration_from_events,
    _fit_payload,
    _mark_truncated,
    _payload_size,
    _MAX_PAYLOAD_BYTES,
    _MAX_CONSECUTIVE_FAILURES,
    flush_session,
    cleanup_stale_with_rescue,
)
from infinium_connector.hook import main
from infinium_connector.types import InfiniumTracePayload


# ---------------------------------------------------------------------------
# Duration computation
# ---------------------------------------------------------------------------


class TestComputeDuration:
    def test_two_timestamps(self):
        events = [
            {"timestamp": "2026-03-31T10:00:00Z"},
            {"timestamp": "2026-03-31T10:00:30Z"},
        ]
        assert _compute_duration_from_events(events) == 30.0

    def test_single_timestamp_returns_zero(self):
        events = [{"timestamp": "2026-03-31T10:00:00Z"}]
        assert _compute_duration_from_events(events) == 0.0

    def test_no_timestamps_returns_zero(self):
        events = [{"msg": "no timestamp"}, {}]
        assert _compute_duration_from_events(events) == 0.0

    def test_malformed_timestamp_skipped(self):
        events = [
            {"timestamp": "2026-03-31T10:00:00Z"},
            {"timestamp": "INVALID"},
            {"timestamp": "2026-03-31T10:00:10Z"},
        ]
        assert _compute_duration_from_events(events) == 10.0

    def test_none_timestamp_skipped(self):
        events = [
            {"timestamp": "2026-03-31T10:00:00Z"},
            {"timestamp": None},
            {"timestamp": "2026-03-31T10:05:00Z"},
        ]
        assert _compute_duration_from_events(events) == 300.0

    def test_unordered_timestamps(self):
        events = [
            {"timestamp": "2026-03-31T10:05:00Z"},
            {"timestamp": "2026-03-31T10:00:00Z"},
            {"timestamp": "2026-03-31T10:02:00Z"},
        ]
        # max - min = 5 minutes
        assert _compute_duration_from_events(events) == 300.0


# ---------------------------------------------------------------------------
# Payload size
# ---------------------------------------------------------------------------


class TestPayloadSize:
    def test_small_payload(self, small_payload):
        size = _payload_size(small_payload)
        assert size > 0
        assert size < _MAX_PAYLOAD_BYTES

    def test_large_payload(self, large_payload):
        size = _payload_size(large_payload)
        assert size > _MAX_PAYLOAD_BYTES


# ---------------------------------------------------------------------------
# Payload fitting / truncation (Fix #15)
# ---------------------------------------------------------------------------


class TestFitPayload:
    def test_small_payload_unchanged(self, small_payload):
        result = _fit_payload(small_payload)
        assert result.steps == small_payload.steps
        # No truncation flag
        tags = result.environment.get("custom_tags", {})
        assert tags.get("truncated") != "true"

    def test_large_payload_fits_after_truncation(self, large_payload):
        result = _fit_payload(large_payload)
        assert _payload_size(result) <= _MAX_PAYLOAD_BYTES

    def test_truncation_sets_flag(self, large_payload):
        """Fix #15: truncated payloads should be flagged."""
        result = _fit_payload(large_payload)
        tags = result.environment.get("custom_tags", {})
        assert tags.get("truncated") == "true"

    def test_preview_truncation(self):
        """Round 1: previews should be shortened."""
        steps = [
            {
                "step_number": i,
                "action": "tool_use",
                "description": f"Step {i}",
                "input_preview": "x" * 500,
                "output_preview": "y" * 500,
            }
            for i in range(1, 100)
        ]
        payload = InfiniumTracePayload(
            name="test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=10.0,
            steps=steps,
            environment={"framework": "claude-code", "custom_tags": {}},
        )
        if _payload_size(payload) > _MAX_PAYLOAD_BYTES:
            result = _fit_payload(payload)
            # Previews should be truncated
            for step in result.steps:
                preview = step.get("input_preview", "")
                if preview:
                    assert len(preview) <= 200 or preview.endswith("...")

    def test_step_dropping(self):
        """Round 2: oldest steps should be dropped."""
        steps = [
            {
                "step_number": i,
                "action": "tool_use",
                "description": f"Step {i}" + ("x" * 3000),
            }
            for i in range(1, 500)
        ]
        payload = InfiniumTracePayload(
            name="test",
            description="test desc",
            current_datetime="2026-03-31T10:00:00Z",
            duration=10.0,
            steps=steps,
            environment={"framework": "claude-code", "custom_tags": {}},
        )
        result = _fit_payload(payload)
        assert len(result.steps) < 500
        # Description should note truncation
        assert "truncated" in result.description.lower()

    def test_mark_truncated_helper(self, small_payload):
        _mark_truncated(small_payload)
        assert small_payload.environment["custom_tags"]["truncated"] == "true"

    def test_mark_truncated_no_custom_tags(self):
        """_mark_truncated should be safe if custom_tags doesn't exist."""
        payload = InfiniumTracePayload(
            name="test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=1.0,
            environment={"framework": "test"},
        )
        # Should not crash
        _mark_truncated(payload)

    def test_mark_truncated_no_environment(self):
        payload = InfiniumTracePayload(
            name="test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=1.0,
        )
        _mark_truncated(payload)  # Should not crash


# ---------------------------------------------------------------------------
# main() stdin handling (Fix #4)
# ---------------------------------------------------------------------------


class TestMain:
    def test_empty_stdin_exits_cleanly(self):
        with patch("sys.stdin") as mock_stdin:
            mock_stdin.read.return_value = ""
            main()  # Should not raise

    def test_invalid_json_logs_warning(self):
        with patch("sys.stdin") as mock_stdin:
            mock_stdin.read.return_value = "NOT JSON"
            with patch("infinium_connector.hook.logger") as mock_logger:
                main()
                mock_logger.warning.assert_called_once()

    def test_stdin_exception_logs_debug(self):
        """Fix #4: stdin read failure should log, not just silently return."""
        with patch("sys.stdin") as mock_stdin:
            mock_stdin.read.side_effect = IOError("broken pipe")
            with patch("infinium_connector.hook.logger") as mock_logger:
                main()
                mock_logger.debug.assert_called()

    def test_non_dict_event_exits_cleanly(self):
        with patch("sys.stdin") as mock_stdin:
            mock_stdin.read.return_value = json.dumps([1, 2, 3])
            main()  # Should not raise

    def test_timestamps_added_when_missing(self):
        """Events without timestamps should get one stamped."""
        event = {"hook_event_name": "Notification", "session_id": "sess-1"}

        stored_events = []

        with patch("sys.stdin") as mock_stdin, \
             patch("infinium_connector.session_store.append_event") as mock_append, \
             patch("infinium_connector.config.ConnectorConfig.load_hook_config",
                   return_value=(MagicMock(session_dir=None), False)), \
             patch("infinium_connector.session_store.read_origin_cwd", return_value=None):
            mock_stdin.read.return_value = json.dumps(event)
            try:
                main()
            except Exception:
                pass
            if mock_append.called:
                stored = mock_append.call_args[0][1]
                assert "timestamp" in stored


# ---------------------------------------------------------------------------
# flush_session
# ---------------------------------------------------------------------------


class TestFlushSession:
    def test_flush_with_no_events_returns_early(self, session_dir):
        config = MagicMock()
        config.session_dir = session_dir
        config.validate.return_value = None

        with patch("infinium_connector.session_store.read_events", return_value=[]):
            flush_session("sess-empty", "Stop", config)
            # Should return without error

    def test_flush_validation_failure_logs_error(self, session_dir):
        """Config validation failure should be logged to error_log."""
        config = MagicMock()
        config.session_dir = session_dir
        config.validate.side_effect = ValueError("Agent ID is required")

        with patch("infinium_connector.error_log.append_error") as mock_append:
            flush_session("sess-1", "Stop", config)
            mock_append.assert_called_once()
            assert mock_append.call_args[0][0] == "config_error"

    def test_flush_empty_payload_logs_warning(self, session_dir):
        """Fix #13: empty payload should log a warning and record in error_log."""
        config = MagicMock()
        config.session_dir = session_dir
        config.validate.return_value = None
        config.flush_on_stop = True
        config.flush_on_session_end = True
        config.max_input_preview = 200
        config.max_output_preview = 300
        config.session_ttl_seconds = 3600

        events = [{"hook_event_name": "Stop", "session_id": "sess-1", "timestamp": "2026-03-31T10:00:00Z"}]

        # Mock the aggregator to return None payload
        mock_aggregator_cls = MagicMock()
        mock_aggregator = mock_aggregator_cls.return_value
        mock_aggregator.ingest.return_value = (MagicMock(), None)
        mock_aggregator.flush_all.return_value = []

        with patch("infinium_connector.session_store.read_events", return_value=events):
            with patch("infinium_connector.session_store.read_flush_offset", return_value=0):
                with patch("infinium_connector.session_store.read_failure_count", return_value=0):
                    with patch("infinium_connector.flush_worker.logger") as mock_logger:
                        with patch("infinium_connector.error_log.append_error") as mock_append:
                            with patch("infinium_connector.aggregator.SessionAggregator", mock_aggregator_cls):
                                flush_session("sess-1", "Stop", config)
                                # Should log a warning about empty payload
                                warning_messages = [str(c) for c in mock_logger.warning.call_args_list]
                                assert any("payload" in m.lower() for m in warning_messages)
                                # Should record in error_log
                                append_calls = [str(c) for c in mock_append.call_args_list]
                                assert any("empty_payload" in c for c in append_calls)

    def test_circuit_breaker_skips_after_max_failures(self, session_dir):
        config = MagicMock()
        config.session_dir = session_dir
        config.validate.return_value = None

        events = [{"hook_event_name": "Stop", "session_id": "sess-1", "timestamp": "2026-03-31T10:00:00Z"}]

        with patch("infinium_connector.session_store.read_events", return_value=events):
            with patch(
                "infinium_connector.session_store.read_failure_count",
                return_value=_MAX_CONSECUTIVE_FAILURES,
            ):
                with patch("infinium_connector.sdk_bridge.send_trace") as mock_send:
                    flush_session("sess-1", "Stop", config)
                    # SDK should NOT be called — circuit breaker tripped
                    mock_send.assert_not_called()

    def test_circuit_breaker_allows_session_end(self, session_dir):
        """SessionEnd should always attempt flush regardless of failure count."""
        config = MagicMock()
        config.session_dir = session_dir
        config.validate.return_value = None
        config.flush_on_session_end = True
        config.max_input_preview = 200
        config.max_output_preview = 300

        events = [
            {"hook_event_name": "SessionStart", "session_id": "sess-1", "timestamp": "2026-03-31T10:00:00Z"},
            {"hook_event_name": "SessionEnd", "session_id": "sess-1", "timestamp": "2026-03-31T10:01:00Z"},
        ]

        with patch("infinium_connector.session_store.read_events", return_value=events):
            with patch(
                "infinium_connector.session_store.read_failure_count",
                return_value=_MAX_CONSECUTIVE_FAILURES + 5,
            ):
                with patch("infinium_connector.sdk_bridge.send_trace", return_value={"traceId": "trace-123"}) as mock_send:
                    with patch("infinium_connector.history.append_entry"):
                        with patch("infinium_connector.session_store.write_flush_offset"):
                            with patch("infinium_connector.session_store.reset_failure_count"):
                                with patch("infinium_connector.session_store.remove_session"):
                                    flush_session("sess-1", "SessionEnd", config)
                                    mock_send.assert_called_once()


# ---------------------------------------------------------------------------
# Token snapshot safety (Fix #5)
# ---------------------------------------------------------------------------


class TestTokenSnapshotSafety:
    def test_token_snapshot_failure_does_not_crash(self, session_dir):
        """Fix #5: write_token_snapshot failure should not propagate."""
        config = MagicMock()
        config.session_dir = session_dir
        config.validate.return_value = None
        config.flush_on_stop = True
        config.max_input_preview = 200
        config.max_output_preview = 300

        events = [
            {"hook_event_name": "SessionStart", "session_id": "sess-1", "timestamp": "2026-03-31T10:00:00Z", "model": "claude-sonnet-4-6"},
            {"hook_event_name": "UserPromptSubmit", "session_id": "sess-1", "timestamp": "2026-03-31T10:00:05Z", "prompt": "hello"},
            {"hook_event_name": "Stop", "session_id": "sess-1", "timestamp": "2026-03-31T10:00:10Z", "last_assistant_message": "hi"},
        ]

        with patch("infinium_connector.session_store.read_events", return_value=events):
            with patch("infinium_connector.session_store.read_flush_offset", return_value=0):
                with patch("infinium_connector.session_store.read_failure_count", return_value=0):
                    with patch("infinium_connector.sdk_bridge.send_trace", return_value={"traceId": "t-1"}) as mock_send:
                        with patch("infinium_connector.session_store.write_flush_offset"):
                            with patch("infinium_connector.session_store.reset_failure_count"):
                                with patch(
                                    "infinium_connector.session_store.write_token_snapshot",
                                    side_effect=OSError("disk full"),
                                ):
                                    with patch("infinium_connector.history.append_entry"):
                                        # Should NOT raise
                                        flush_session("sess-1", "Stop", config)
                                        mock_send.assert_called_once()


# ---------------------------------------------------------------------------
# Stale cleanup race (Fix #12)
# ---------------------------------------------------------------------------


class TestStaleCleanup:
    def test_cleanup_skips_modified_files(self, session_dir):
        """Fix #12: stale cleanup should skip files modified during flush."""
        from infinium_connector import session_store

        config = MagicMock()
        config.session_dir = session_dir
        config.session_ttl_seconds = 1  # 1 second TTL

        # Create a session file
        session_store.append_event("sess-stale", {"x": 1}, session_dir)
        path = session_store._session_path("sess-stale", session_dir)

        # Make it stale
        old_time = time.time() - 100
        os.utime(str(path), (old_time, old_time))

        # Mock flush_session to update mtime (simulating concurrent write)
        def fake_flush(sid, event_name, cfg):
            # Touch the file to simulate another process updating it
            path.write_text('{"updated": true}\n', encoding="utf-8")

        with patch("infinium_connector.flush_worker.flush_session", side_effect=fake_flush):
            cleanup_stale_with_rescue(config)

        # File should still exist because mtime changed during cleanup
        assert path.exists()

    def test_cleanup_removes_truly_stale_files(self, session_dir):
        from infinium_connector import session_store

        config = MagicMock()
        config.session_dir = session_dir
        config.session_ttl_seconds = 1

        session_store.append_event("sess-stale", {"x": 1}, session_dir)
        path = session_store._session_path("sess-stale", session_dir)
        old_time = time.time() - 100
        os.utime(str(path), (old_time, old_time))

        with patch("infinium_connector.flush_worker.flush_session"):
            cleanup_stale_with_rescue(config)

        # File should be removed
        assert not path.exists()


# ---------------------------------------------------------------------------
# Background spawn (non-blocking hook)
# ---------------------------------------------------------------------------


class TestBackgroundSpawn:
    def test_stop_event_spawns_flush_worker(self):
        """Stop events should spawn a background worker, not flush inline."""
        event = {
            "hook_event_name": "Stop",
            "session_id": "sess-1",
            "cwd": "/tmp/test",
            "timestamp": "2026-03-31T10:00:00Z",
            "last_assistant_message": "done",
        }

        with patch("sys.stdin") as mock_stdin, \
             patch("infinium_connector.config.ConnectorConfig.load_hook_config",
                   return_value=(MagicMock(session_dir=None), False)), \
             patch("infinium_connector.session_store.append_event"), \
             patch("infinium_connector.session_store.read_origin_cwd", return_value=None), \
             patch("infinium_connector.hook._spawn_flush") as mock_spawn:
            mock_stdin.read.return_value = json.dumps(event)
            main()
            mock_spawn.assert_called_once()

    def test_non_flush_event_does_not_spawn(self):
        """Non-flush events should not spawn a worker."""
        event = {
            "hook_event_name": "PostToolUse",
            "session_id": "sess-1",
            "cwd": "/tmp/test",
            "timestamp": "2026-03-31T10:00:00Z",
        }

        with patch("sys.stdin") as mock_stdin, \
             patch("infinium_connector.config.ConnectorConfig.load_hook_config",
                   return_value=(MagicMock(session_dir=None), False)), \
             patch("infinium_connector.session_store.append_event"), \
             patch("infinium_connector.session_store.read_origin_cwd", return_value=None), \
             patch("infinium_connector.hook._spawn_flush") as mock_spawn, \
             patch("random.random", return_value=0.99):
            mock_stdin.read.return_value = json.dumps(event)
            main()
            mock_spawn.assert_not_called()
