"""Tests for infinium_connector.aggregator — event ingestion and payload building."""
from __future__ import annotations

from typing import Any, Dict, List

import pytest

from infinium_connector.aggregator import SessionAggregator, _truncate, _short_path
from infinium_connector.config import ConnectorConfig
from infinium_connector.types import InfiniumTracePayload


@pytest.fixture()
def config() -> ConnectorConfig:
    return ConnectorConfig(
        agent_id="test-agent",
        agent_secret="test-secret",
        max_input_preview=200,
        max_output_preview=300,
    )


@pytest.fixture()
def aggregator(config) -> SessionAggregator:
    return SessionAggregator(config)


# ---------------------------------------------------------------------------
# Truncate helper
# ---------------------------------------------------------------------------


class TestTruncate:
    def test_none_returns_none(self):
        assert _truncate(None, 100) is None

    def test_short_string_unchanged(self):
        assert _truncate("hello", 100) == "hello"

    def test_long_string_truncated(self):
        result = _truncate("a" * 200, 50)
        assert len(result) == 50
        assert result.endswith("...")

    def test_non_string_coerced(self):
        result = _truncate({"key": "value"}, 100)
        assert isinstance(result, str)

    def test_list_coerced(self):
        result = _truncate([1, 2, 3], 100)
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# Short path helper
# ---------------------------------------------------------------------------


class TestShortPath:
    def test_empty_path(self):
        assert _short_path("") == ""

    def test_filename_only(self):
        assert _short_path("file.py") == "file.py"

    def test_long_path_shortened(self):
        result = _short_path("/home/user/project/src/deep/file.py")
        assert "file.py" in result
        # Should only have last 2 components
        parts = result.split("/")
        assert len(parts) <= 2

    def test_windows_path(self):
        result = _short_path("C:\\Users\\dev\\project\\src\\file.py")
        assert "file.py" in result


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------


class TestSessionLifecycle:
    def test_ingest_session_start(self, aggregator, sample_session_start):
        event, payload = aggregator.ingest(sample_session_start)
        assert event.event_name == "SessionStart"
        assert payload is None  # No flush on SessionStart
        assert aggregator.active_session_count == 1

    def test_ingest_full_session(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        # SessionEnd should produce a payload
        assert payload is not None
        assert payload.name is not None
        assert payload.duration >= 0

    def test_stop_produces_payload(self, aggregator, sample_session_start, sample_user_prompt, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        _, payload = aggregator.ingest(sample_stop)
        assert payload is not None

    def test_session_end_removes_session(self, aggregator, full_session_events):
        for ev in full_session_events:
            aggregator.ingest(ev)
        assert aggregator.active_session_count == 0

    def test_stop_keeps_session_alive(self, aggregator, sample_session_start, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_stop)
        assert aggregator.active_session_count == 1


# ---------------------------------------------------------------------------
# Event handlers
# ---------------------------------------------------------------------------


class TestEventHandlers:
    def test_user_prompt_creates_turn(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        session = aggregator._sessions["sess-abc123"]
        assert len(session.turns) == 1
        assert session.turns[0].prompt == "Fix the login bug"

    def test_tool_use_recorded(
        self, aggregator, sample_session_start, sample_user_prompt,
        sample_pre_tool_use, sample_post_tool_use,
    ):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest(sample_pre_tool_use)
        aggregator.ingest(sample_post_tool_use)

        session = aggregator._sessions["sess-abc123"]
        assert session.total_tool_calls == 1
        turn = session.turns[0]
        assert len(turn.tool_uses) == 1
        assert turn.tool_uses[0].tool_name == "Read"

    def test_tool_failure_increments_errors(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "PreToolUse",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "tool_name": "Bash",
            "tool_use_id": "tool-fail",
            "tool_input": {"command": "rm -rf /"},
        })
        aggregator.ingest({
            "hook_event_name": "PostToolUseFailure",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:11Z",
            "tool_name": "Bash",
            "tool_use_id": "tool-fail",
            "error": "Permission denied",
        })

        session = aggregator._sessions["sess-abc123"]
        assert session.total_errors == 1
        assert session.total_tool_calls == 1

    def test_post_tool_use_without_pre(self, aggregator, sample_session_start, sample_user_prompt):
        """PostToolUse without matching PreToolUse should create inline record."""
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "PostToolUse",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "tool_name": "Grep",
            "tool_use_id": "orphan-tool",
            "tool_response": "3 matches found",
        })

        session = aggregator._sessions["sess-abc123"]
        assert session.total_tool_calls == 1

    def test_subagent_lifecycle(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "SubagentStart",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "agent_id": "sub-1",
            "agent_type": "Explore",
        })
        aggregator.ingest({
            "hook_event_name": "SubagentStop",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:20Z",
            "agent_id": "sub-1",
            "agent_transcript_path": "/tmp/transcript.jsonl",
        })

        session = aggregator._sessions["sess-abc123"]
        assert session.total_subagents == 1
        turn = session.turns[0]
        assert len(turn.subagents) == 1
        assert turn.subagents[0].completed_at is not None

    def test_stop_sets_response(self, aggregator, sample_session_start, sample_user_prompt, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest(sample_stop)

        session = aggregator._sessions["sess-abc123"]
        assert session.turns[0].response == "I fixed the login bug."

    def test_unhandled_event_no_crash(self, aggregator, sample_session_start):
        aggregator.ingest(sample_session_start)
        aggregator.ingest({
            "hook_event_name": "FutureEvent",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:01Z",
        })
        # Should not crash


# ---------------------------------------------------------------------------
# Payload building
# ---------------------------------------------------------------------------


class TestPayloadBuilding:
    def test_payload_has_name_from_prompt(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert "Fix the login bug" in (payload.name or "")

    def test_payload_has_steps(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.steps is not None
        assert len(payload.steps) > 0

    def test_payload_has_environment(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.environment is not None
        assert payload.environment["framework"] == "claude-code"
        assert "session_id" in payload.environment.get("custom_tags", {})

    def test_payload_has_errors_when_tool_fails(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "PreToolUse",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "tool_name": "Bash",
            "tool_use_id": "t-1",
        })
        aggregator.ingest({
            "hook_event_name": "PostToolUseFailure",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:11Z",
            "tool_use_id": "t-1",
            "error": "Command failed",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "Stop",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:12Z",
        })

        assert payload.errors is not None
        assert len(payload.errors) == 1

    def test_payload_no_errors_on_clean_session(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.errors is None or len(payload.errors) == 0

    def test_payload_output_summary_from_last_response(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.output_summary == "I fixed the login bug."

    def test_turn_trace_uses_turn_timestamp_not_session_start(self, aggregator):
        """current_datetime should reflect the turn time, not session start."""
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-ts",
            "timestamp": "2026-03-31T08:00:00Z",  # Session started hours ago
        })
        aggregator.ingest({
            "hook_event_name": "UserPromptSubmit",
            "session_id": "sess-ts",
            "timestamp": "2026-03-31T11:30:00Z",  # Turn started much later
            "prompt": "Fix the bug",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "Stop",
            "session_id": "sess-ts",
            "timestamp": "2026-03-31T11:31:00Z",
        })

        # current_datetime should be the turn time (11:30), NOT session start (08:00)
        assert payload.current_datetime == "2026-03-31T11:30:00Z"

    def test_session_summary_uses_session_start(self, aggregator):
        """SessionEnd summary should still use session start time."""
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-sum",
            "timestamp": "2026-03-31T08:00:00Z",
        })
        aggregator.ingest({
            "hook_event_name": "UserPromptSubmit",
            "session_id": "sess-sum",
            "timestamp": "2026-03-31T08:00:05Z",
            "prompt": "hello",
        })
        # SessionEnd flushes the whole session — should use first turn's time
        _, payload = aggregator.ingest({
            "hook_event_name": "SessionEnd",
            "session_id": "sess-sum",
            "timestamp": "2026-03-31T08:01:00Z",
        })

        # With one turn, current_datetime is the turn's started_at
        assert payload.current_datetime == "2026-03-31T08:00:05Z"

    def test_no_prompt_session_gets_generic_name(self, aggregator):
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-noprompt",
            "timestamp": "2026-03-31T10:00:00Z",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "SessionEnd",
            "session_id": "sess-noprompt",
            "timestamp": "2026-03-31T10:00:10Z",
        })

        assert "session" in payload.name.lower()

    def test_to_dict_omits_none_fields(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        d = payload.to_dict()
        for key, val in d.items():
            assert val is not None


# ---------------------------------------------------------------------------
# Flush / replay
# ---------------------------------------------------------------------------


class TestFlushReplay:
    def test_flush_session(self, aggregator, sample_session_start, sample_user_prompt, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest(sample_stop)

        payload = aggregator.flush_session("sess-abc123")
        assert payload is not None
        assert aggregator.active_session_count == 0

    def test_flush_nonexistent_session(self, aggregator):
        assert aggregator.flush_session("nope") is None

    def test_flush_all(self, aggregator, sample_session_start, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_stop)

        # Start another session
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-222",
            "timestamp": "2026-03-31T10:00:00Z",
        })

        payloads = aggregator.flush_all()
        assert len(payloads) == 2
        assert aggregator.active_session_count == 0

    def test_replay_events(self, aggregator, full_session_events):
        payload = aggregator.replay_events(full_session_events)
        assert payload is not None
        assert payload.name is not None

    def test_replay_empty_events(self, aggregator):
        assert aggregator.replay_events([]) is None

    def test_evict_stale(self, aggregator, sample_session_start):
        aggregator.ingest(sample_session_start)
        # Fake the timestamp to be old
        aggregator._session_timestamps["sess-abc123"] = 0.0
        aggregator.config.session_ttl_seconds = 1

        evicted = aggregator.evict_stale()
        assert "sess-abc123" in evicted
        assert aggregator.active_session_count == 0


# ---------------------------------------------------------------------------
# Duration computation
# ---------------------------------------------------------------------------


class TestDuration:
    def test_duration_from_timestamps(self, aggregator):
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-dur",
            "timestamp": "2026-03-31T10:00:00Z",
        })
        aggregator.ingest({
            "hook_event_name": "UserPromptSubmit",
            "session_id": "sess-dur",
            "timestamp": "2026-03-31T10:00:05Z",
            "prompt": "test",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "Stop",
            "session_id": "sess-dur",
            "timestamp": "2026-03-31T10:00:30Z",
        })
        assert payload.duration >= 25.0

    def test_duration_ms_computation(self, aggregator):
        ms = aggregator._compute_duration_ms(
            "2026-03-31T10:00:00Z", "2026-03-31T10:00:05Z"
        )
        assert ms == 5000

    def test_duration_ms_none_inputs(self, aggregator):
        assert aggregator._compute_duration_ms(None, "2026-03-31T10:00:00Z") is None
        assert aggregator._compute_duration_ms("2026-03-31T10:00:00Z", None) is None

    def test_duration_ms_invalid_format(self, aggregator):
        assert aggregator._compute_duration_ms("bad", "also bad") is None
