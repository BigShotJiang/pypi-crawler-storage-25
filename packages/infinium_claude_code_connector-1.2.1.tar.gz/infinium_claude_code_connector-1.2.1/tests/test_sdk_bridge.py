"""Tests for infinium_connector.sdk_bridge — payload conversion and sanitization."""
from __future__ import annotations

from unittest.mock import patch, MagicMock

import pytest

from infinium_connector.sdk_bridge import (
    payload_to_task_data,
    sanitize_str,
    sanitize_strings,
    send_trace,
)
from infinium_connector.types import InfiniumTracePayload
from infinium_connector.config import ConnectorConfig


# ---------------------------------------------------------------------------
# Sanitization
# ---------------------------------------------------------------------------


class TestSanitization:
    def test_sanitize_str_clean(self):
        assert sanitize_str("hello world") == "hello world"

    def test_sanitize_str_with_surrogates(self):
        # Lone surrogates should be replaced
        text = "hello\ud800world"
        result = sanitize_str(text)
        assert "\ud800" not in result
        assert "hello" in result

    def test_sanitize_strings_dict(self):
        data = {"key": "hello\ud800", "nested": {"inner": "test\udc00"}}
        result = sanitize_strings(data)
        assert "\ud800" not in result["key"]
        assert "\udc00" not in result["nested"]["inner"]

    def test_sanitize_strings_list(self):
        data = ["hello\ud800", "normal", "world\udc00"]
        result = sanitize_strings(data)
        for item in result:
            assert "\ud800" not in item
            assert "\udc00" not in item

    def test_sanitize_strings_tuple(self):
        data = ("hello\ud800", "normal")
        result = sanitize_strings(data)
        assert isinstance(result, tuple)

    def test_sanitize_strings_non_string(self):
        assert sanitize_strings(42) == 42
        assert sanitize_strings(None) is None
        assert sanitize_strings(True) is True


# ---------------------------------------------------------------------------
# Payload to TaskData conversion
# ---------------------------------------------------------------------------


class TestPayloadConversion:
    def test_minimal_payload(self):
        payload = InfiniumTracePayload(
            name="Test",
            description="A test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
        )
        task_data = payload_to_task_data(payload)
        assert task_data.name == "Test"
        assert task_data.description == "A test"
        assert task_data.duration == 5.0

    def test_payload_with_steps(self):
        payload = InfiniumTracePayload(
            name="Test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
            steps=[
                {
                    "step_number": 1,
                    "action": "tool_use",
                    "description": "Read file",
                    "duration_ms": 100,
                    "input_preview": "src/main.py",
                    "output_preview": "file contents",
                },
            ],
        )
        task_data = payload_to_task_data(payload)
        assert task_data.steps is not None
        assert len(task_data.steps) == 1
        assert task_data.steps[0].action == "tool_use"

    def test_payload_with_errors(self):
        payload = InfiniumTracePayload(
            name="Test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
            errors=[
                {
                    "error_type": "ToolError",
                    "message": "Permission denied",
                    "recoverable": True,
                },
            ],
        )
        task_data = payload_to_task_data(payload)
        assert task_data.errors is not None
        assert len(task_data.errors) == 1
        assert task_data.errors[0].message == "Permission denied"

    def test_payload_with_environment(self):
        payload = InfiniumTracePayload(
            name="Test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
            environment={
                "framework": "claude-code",
                "sdk_version": "1.0.0",
                "custom_tags": {"model": "opus"},
            },
        )
        task_data = payload_to_task_data(payload)
        assert task_data.environment is not None
        assert task_data.environment.framework == "claude-code"

    def test_payload_with_step_errors(self):
        payload = InfiniumTracePayload(
            name="Test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
            steps=[
                {
                    "step_number": 1,
                    "action": "tool_use",
                    "description": "Failed bash",
                    "error": {
                        "error_type": "ToolError",
                        "message": "exit code 1",
                        "recoverable": True,
                    },
                },
            ],
        )
        task_data = payload_to_task_data(payload)
        assert task_data.steps[0].error is not None
        assert task_data.steps[0].error.error_type == "ToolError"

    def test_payload_with_llm_usage(self):
        payload = InfiniumTracePayload(
            name="Test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
            llm_usage={
                "model": "claude-sonnet-4-6",
                "provider": "anthropic",
                "prompt_tokens": 1000,
                "completion_tokens": 500,
                "total_tokens": 1500,
                "api_calls_count": 3,
            },
        )
        task_data = payload_to_task_data(payload)
        assert task_data.llm_usage is not None
        assert task_data.llm_usage.prompt_tokens == 1000

    def test_payload_with_cache_tokens_in_custom_tags(self):
        """Cache tokens should be preserved in custom_tags."""
        payload = InfiniumTracePayload(
            name="Test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
            llm_usage={
                "model": "claude-sonnet-4-6",
                "provider": "anthropic",
                "prompt_tokens": 1000,
                "completion_tokens": 500,
                "total_tokens": 1500,
                "cache_creation_input_tokens": 200,
                "cache_read_input_tokens": 800,
            },
            environment={
                "framework": "claude-code",
                "custom_tags": {"existing": "tag"},
            },
        )
        task_data = payload_to_task_data(payload)
        tags = task_data.environment.custom_tags
        assert tags["cache_creation_input_tokens"] == "200"
        assert tags["cache_read_input_tokens"] == "800"
        assert tags["existing"] == "tag"

    def test_payload_with_sections(self):
        payload = InfiniumTracePayload(
            name="Test",
            description="test",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
            sections={
                "development": {
                    "framework_used": "claude-code",
                    "files_modified": ["/src/main.py"],
                },
                "general": {
                    "tools_used": ["Read", "Edit"],
                    "tags": ["coding"],
                },
            },
        )
        task_data = payload_to_task_data(payload)
        assert task_data.development is not None
        assert task_data.development.framework_used == "claude-code"
        assert task_data.general is not None
        assert "Read" in task_data.general.tools_used


# ---------------------------------------------------------------------------
# send_trace
# ---------------------------------------------------------------------------


class TestSendTrace:
    def test_send_trace_sanitizes_payload(self):
        """send_trace should sanitize strings before sending."""
        config = ConnectorConfig(
            agent_id="test-agent",
            agent_secret="test-secret",
        )
        payload = InfiniumTracePayload(
            name="Test\ud800name",
            description="desc",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
        )

        mock_response = MagicMock()
        mock_response.data = {"traceId": "t-1"}
        mock_response.message = "OK"

        with patch("infinium_connector.sdk_bridge.InfiniumClient") as MockClient:
            client_instance = MockClient.return_value.__enter__.return_value
            client_instance.send_task_data.return_value = mock_response

            result = send_trace(config, payload)

        assert result == {"traceId": "t-1"}
        # Name should be sanitized (no surrogate)
        assert "\ud800" not in payload.name

    def test_send_trace_returns_empty_dict_on_no_data(self):
        config = ConnectorConfig(
            agent_id="test-agent",
            agent_secret="test-secret",
        )
        payload = InfiniumTracePayload(
            name="Test",
            description="desc",
            current_datetime="2026-03-31T10:00:00Z",
            duration=5.0,
        )

        mock_response = MagicMock()
        mock_response.data = None
        mock_response.message = "OK"

        with patch("infinium_connector.sdk_bridge.InfiniumClient") as MockClient:
            client_instance = MockClient.return_value.__enter__.return_value
            client_instance.send_task_data.return_value = mock_response

            result = send_trace(config, payload)

        assert result == {}
