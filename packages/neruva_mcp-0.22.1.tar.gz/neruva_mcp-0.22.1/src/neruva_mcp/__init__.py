"""Neruva MCP server (Python).

Thin stdio Model Context Protocol wrapper over the Neruva REST API.
"""
from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("neruva-mcp")
except PackageNotFoundError:
    __version__ = "0.0.0+local"
