from setuptools import setup
setup(name="playtika-depconfusion-poc", version="1.0.0", packages=["toktest"])
