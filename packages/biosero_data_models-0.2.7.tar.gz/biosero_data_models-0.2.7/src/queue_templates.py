from biosero.datamodels.queueagent.decorators import parameter

@parameter(
    queue_name="DataProcessingQueueTest",
    category="Data Processing",
    description="Queue for processing data records",
    input_schema='{"recordId":125,"operation":"process"}',
    input_content_type="Json",
    output_schema='{"success":true}',
    output_content_type="Json"
)
def my_queue():
    pass