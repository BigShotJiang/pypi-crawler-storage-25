from datetime import datetime
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, get_origin, get_args


class InputContentType(Enum):
    NONE = "None"
    JSON = "Json"
    PARAMETER_COLLECTION = "ParameterCollection"
    UNKNOWN = "Unknown"


class OutputContentType(Enum):
    NONE = "None"
    JSON = "Json"
    PARAMETER_COLLECTION = "ParameterCollection"
    UNKNOWN = "Unknown"


class QueueTaskStatus(Enum):
    CREATED = "Created"
    PROCESSING = "Processing"
    COMPLETED = "Completed"
    CANCELED = "Canceled"
    UNKNOWN = "Unknown"


@dataclass
class QueueInfo:
    queueId: Optional[int] = None
    queueName: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    inputSchema: Optional[str] = None
    inputContentType: Optional[InputContentType] = None
    outputSchema: Optional[str] = None
    outputContentType: Optional[OutputContentType] = None


@dataclass
class QueueTask:
    queueTaskId: Optional[int] = None
    queueId: Optional[int] = None
    queueName: Optional[str] = None
    category: Optional[str] = None
    orderIdentifier: Optional[str] = None
    status: Optional[QueueTaskStatus] = None
    input: Optional[str] = None
    inputContentType: Optional[InputContentType] = None
    output: Optional[str] = None
    outputContentType: Optional[OutputContentType] = None
    modifiedDateUtc: Optional[datetime] = None


@dataclass
class QueueTaskIdOnly:
    queueTaskId: Optional[int] = None


@dataclass
class QueueTaskPage:
    rows: Optional[List[QueueTask]] = None
    totalCount: Optional[int] = None


@dataclass
class QueuesEnabledOnly:
    queuesEnabled: bool = False