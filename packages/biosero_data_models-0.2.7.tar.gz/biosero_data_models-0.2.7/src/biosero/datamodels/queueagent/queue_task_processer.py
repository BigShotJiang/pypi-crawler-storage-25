import requests
import time
import json
import logging
import threading
import inspect
import asyncio
import importlib
from rich.logging import RichHandler
from biosero.datamodels.events import (
    Event,
    EventMessage,
    ModuleStatusUpdateEvent,
    ModuleStatus,
)
from typing import Optional, TypeVar

T = TypeVar("T")

from biosero.datamodels.restclients import EventClient
from biosero.dataservices.restclient.queclient import QueClient
from biosero.datamodels.queues.queue import QueueTaskStatus

# Clear existing handlers
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# Setup the logger
FORMAT = "%(message)s"
logging.basicConfig(
    level=logging.INFO,
    format=FORMAT,
    handlers=[RichHandler(markup=True, rich_tracebacks=True)]
)

# Always use the root logger
logger = logging.getLogger()


class AbortExecution(Exception):
    def __init__(self, reason, status="Cancelled"):
        super().__init__(reason)
        self.status = status


class QueueTaskProcessor():
    def __init__(self, url, queue_templates, queue_actions_instance, adapter_id=None, adapter_name=None):
        """
        Initializes the QueueTaskProcessor with a Data Services URL and queue action handlers.
        
        :param url: The base URL for Data Services.
        :param queue_templates: The queue templates module containing function stubs decorated with @parameter.
        :param queue_actions_instance: An instance of the class containing actual action implementations.
        :param adapter_id: Optional adapter identifier.
        :param adapter_name: Optional adapter name.
        """
        self.data_services_url = url
        self.queue_templates = queue_templates
        self.action_mapping = self.generate_action_mapping(queue_templates, queue_actions_instance)
        self.adapter_id = adapter_id
        self.adapter_name = adapter_name
        
        if adapter_id and adapter_name:
            module_update_event = ModuleStatusUpdateEvent(
                Id=0,
                ModuleIdentifier=self.adapter_id,
                ModuleName=self.adapter_name,
                Status=ModuleStatus.Ready
            )
            self.publish_event(module_update_event, "Python Script", "Python Operator")

    def complete_task(self, task_id, output):
        """Marks a queue task as complete with the specified output."""
        with QueClient(self.data_services_url) as que_client:
            que_client.complete_queue_task(task_id, output)
            logger.info(f"[i][grey7] - Task {task_id} completed successfully[/grey7][/i]", extra={"markup": True})

    def cancel_task(self, task_id):
        """Cancels a queue task."""
        with QueClient(self.data_services_url) as que_client:
            que_client.cancel_queue_task(task_id)
            logger.info(f"[i][grey7] - Task {task_id} cancelled[/grey7][/i]", extra={"markup": True})

    def process_task(self, task):
        """
        Processes a single queue task.
        
        :param task: QueueTask object containing task details.
        """
        queue_name = task.queueName
        action_tuple = self.action_mapping.get(queue_name)

        if action_tuple:
            action_function = action_tuple[0]
            task_id = task.queueTaskId
            
            logger.info(f'Task {task_id} (Queue: {queue_name}) - Processing started')

            if self.adapter_id and self.adapter_name:
                module_update_event = ModuleStatusUpdateEvent(
                    Id=0,
                    ModuleIdentifier=self.adapter_id,
                    ModuleName=self.adapter_name,
                    Status=ModuleStatus.Busy
                )
                self.publish_event(module_update_event, "Python Script", "Python Operator")

            try:
                # Parse input JSON
                input_data = {}
                if task.input:
                    try:
                        input_data = json.loads(task.input)
                    except json.JSONDecodeError:
                        # If input is not valid JSON, pass as-is
                        input_data = {"input": task.input}
                
                logger.info(f'Task {task_id}: Input data: {input_data}')

                # Execute the action
                output = action_function(task, **input_data)
                
                # If the result is a coroutine, run it in an event loop
                if asyncio.iscoroutine(output):
                    logger.debug(f"Detected async result from {action_function.__name__} — running in event loop")
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        output = loop.run_until_complete(output)
                    finally:
                        loop.close()

                # Convert output to JSON string if it's a dict
                if isinstance(output, dict):
                    output_str = json.dumps(output)
                elif output is None:
                    output_str = json.dumps({"success": True})
                else:
                    output_str = str(output)

                logger.info(f'Task {task_id}: Output: {output_str}')

                # Complete the task
                self.complete_task(task_id, output_str)

                logger.info(f'Task {task_id} (Queue: {queue_name}) - Completed')

                if self.adapter_id and self.adapter_name:
                    module_update_event = ModuleStatusUpdateEvent(
                        Id=0,
                        ModuleIdentifier=self.adapter_id,
                        ModuleName=self.adapter_name,
                        Status=ModuleStatus.Ready
                    )
                    self.publish_event(module_update_event, "Python Script", "Python Operator")

            except AbortExecution as e:
                logger.warning(f'Task {task_id} (Queue: {queue_name}): Aborted - {str(e)}')
                self.cancel_task(task_id)

                if self.adapter_id and self.adapter_name:
                    module_update_event = ModuleStatusUpdateEvent(
                        Id=0,
                        ModuleIdentifier=self.adapter_id,
                        ModuleName=self.adapter_name,
                        Status=ModuleStatus.Ready
                    )
                    self.publish_event(module_update_event, "Python Script", "Python Operator")

            except Exception as e:
                logger.error(f'Error processing task {task_id}: {str(e)}')
                # For errors, we cancel the task
                self.cancel_task(task_id)

                logger.info(f'Task {task_id} (Queue: {queue_name}): Error Details {str(e)}')

                if self.adapter_id and self.adapter_name:
                    module_update_event = ModuleStatusUpdateEvent(
                        Id=0,
                        ModuleIdentifier=self.adapter_id,
                        ModuleName=self.adapter_name,
                        Status=ModuleStatus.Error
                    )
                    self.publish_event(module_update_event, "Python Script", "Python Operator")
        else:
            logger.warning(f"No action mapping found for queue: {queue_name}")

    def poll_pending_tasks(self, poll_interval=1):
        """
        Continuously polls for pending queue tasks and processes them.
        
        :param poll_interval: Time in seconds between polls. Default is 1 second.
        """
        # Extract queue names from templates before starting the polling loop
        queue_names = []
        stub_functions = [
            obj for name, obj in inspect.getmembers(self.queue_templates)
            if inspect.isfunction(obj) and hasattr(obj, '_parameter_decorator')
        ]
        
        for stub_function in stub_functions:
            queue_name = stub_function._parameter_decorator.get('queueName')
            if queue_name:
                queue_names.append(queue_name)
        
        if not queue_names:
            logger.error("No queue names found in templates")
            return
        
        logger.info(f"Monitoring {len(queue_names)} queue(s): {queue_names}")
        
        connected = False

        while True:
            try:
                task = None
                with QueClient(self.data_services_url) as que_client:
                    # Try to get the next available task from any of the registered queues
                    for queue_name in queue_names:
                        try:
                            task = que_client.get_next_queue_task(queue_name)
                            if task:
                                break  # Found a task, stop checking other queues
                        except requests.exceptions.HTTPError as e:
                            if e.response.status_code == 404:
                                logger.debug(f"No tasks available for queue '{queue_name}' (404)")
                                continue  # Try next queue
                            else:
                                raise  # Re-raise other HTTP errors

                if not connected:
                    logger.info(f"[bold green]Connected to Queue Service @ {self.data_services_url}[/bold green]", extra={"markup": True})
                    connected = True

                if task:
                    # Process the task in a separate thread
                    task_thread = threading.Thread(target=self.process_task, args=(task,))
                    task_thread.start()

                time.sleep(poll_interval)

            except requests.exceptions.RequestException as e:
                logger.error(f"Failed to poll queue tasks: {e}")
                connected = False
                time.sleep(3)
            except Exception as e:
                logger.error(f"Unexpected error in polling: {e}")
                time.sleep(3)

    def publish_event(self, event_item: T, actor_id: Optional[str] = None, operator_id: Optional[str] = None) -> None:
        """Publishes an event to the Data Services event system."""
        transfer_event = Event(event_item)
        transfer_msg = EventMessage.from_event(transfer_event)
        transfer_msg.ActorId = actor_id
        transfer_msg.OperatorId = operator_id

        event_client = EventClient(self.data_services_url)
        event_client.publish_event(transfer_msg)

    def generate_action_mapping(self, queue_templates=None, queue_actions_instance=None):
        """
        Generates a mapping between queue names and their corresponding action functions.
        
        :param queue_templates: Module containing queue template functions decorated with @parameter.
        :param queue_actions_instance: Instance of the class containing actual action implementations.
        :return: Dictionary mapping queue names to action functions.
        """
        action_mapping = {}

        if queue_templates is None:
            logger.warning("No queue_templates provided for action mapping")
            return {}

        if queue_actions_instance is None:
            logger.warning("No queue_actions_instance provided for action mapping")
            return {}

        # Get all functions from queue_templates that have _parameter_decorator
        stub_functions = [
            obj for name, obj in inspect.getmembers(queue_templates)
            if inspect.isfunction(obj) and hasattr(obj, '_parameter_decorator')
        ]

        # Get all methods from the queue actions instance
        action_methods = {
            name: obj for name, obj in inspect.getmembers(queue_actions_instance, predicate=inspect.ismethod)
            if name != '__init__'
        }

        # Create a mapping from the queue name in the @parameter decorator to the corresponding method
        for stub_function in stub_functions:
            queue_name = stub_function._parameter_decorator.get('queueName')
            action_method = action_methods.get(stub_function.__name__)

            if action_method and queue_name:
                action_mapping[queue_name] = (action_method,)
                logger.debug(f"Mapped queue '{queue_name}' to action '{stub_function.__name__}'")
            else:
                if not action_method:
                    logger.warning(f"No matching method found for queue template {stub_function.__name__}")
                if not queue_name:
                    logger.warning(f"No queue name found in decorator for {stub_function.__name__}")

        return action_mapping
