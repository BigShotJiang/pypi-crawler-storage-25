import inspect
import sys
from typing import get_type_hints
import logging
import requests
import datetime
from rich.logging import RichHandler


from biosero.datamodels.queues import QueueInfo, InputContentType, OutputContentType
from biosero.datamodels.queueagent.decorators import parameter, task
from biosero.dataservices.restclient.queclient import QueClient


logger = logging.getLogger("rich")
# Configure the logging module
logging.basicConfig(
    level=logging.INFO, 
    format="%(message)s",
    handlers=[RichHandler(rich_tracebacks=True)]
)

class QueueRegistrar():
    def __init__(self, data_services_url, queue_templates):
        """
        Initializes the QueueRegistrar with a Data Services URL and queue templates module.
        
        :param data_services_url: The base URL for Data Services.
        :param queue_templates: The queue templates module containing function stubs decorated with @parameter.
        """
        self.data_services_url = data_services_url
        self.queue_templates = queue_templates

    def extract_queue_info_from_stub(self, func):
        """Extracts queue metadata from a function decorated with @parameter."""
        parameter_decorator = getattr(func, '_parameter_decorator', None)
        if parameter_decorator is None:
            raise ValueError(f"No @parameter decorator found for {func.__name__}")

        # Construct the queue info dictionary
        queue_info = {
            "queueName": parameter_decorator.get('queueName'),
            "category": parameter_decorator.get('category'),
            "description": parameter_decorator.get('description'),
            "inputSchema": parameter_decorator.get('inputSchema'),
            "inputContentType": parameter_decorator.get('inputContentType'),
            "outputSchema": parameter_decorator.get('outputSchema'),
            "outputContentType": parameter_decorator.get('outputContentType')
        }
        
        return queue_info

    def register_queue(self, queue_info):
        """Registers a queue with the Data Services API using QueClient."""
        with QueClient(self.data_services_url) as que_client:
            # Convert string content types to enums if needed
            input_content_type = queue_info.get('inputContentType')
            if isinstance(input_content_type, str):
                input_content_type = InputContentType[input_content_type.upper()]
            
            output_content_type = queue_info.get('outputContentType')
            if isinstance(output_content_type, str):
                output_content_type = OutputContentType[output_content_type.upper()]
            
            # Use create_or_update_queue to handle existing queues
            result = que_client.create_or_update_queue(
                queue_name=queue_info.get('queueName'),
                category=queue_info.get('category'),
                description=queue_info.get('description'),
                input_schema=queue_info.get('inputSchema'),
                input_content_type=input_content_type,
                output_schema=queue_info.get('outputSchema'),
                output_content_type=output_content_type
            )
            
            return result

    def register_all_queues(self):
        """Registers all queues from the provided queue_templates module."""
        with QueClient(self.data_services_url) as que_client:
            for name, func in inspect.getmembers(self.queue_templates, inspect.isfunction):
                if not hasattr(func, '_parameter_decorator'):
                    continue   
                try:
                    queue_info = self.extract_queue_info_from_stub(func)
                    
                    # Convert string content types to enums if needed
                    input_content_type = queue_info.get('inputContentType')
                    if isinstance(input_content_type, str):
                        input_content_type = InputContentType[input_content_type.upper()]
                    
                    output_content_type = queue_info.get('outputContentType')
                    if isinstance(output_content_type, str):
                        output_content_type = OutputContentType[output_content_type.upper()]
                    
                    result = que_client.create_or_update_queue(
                        queue_name=queue_info.get('queueName'),
                        category=queue_info.get('category'),
                        description=queue_info.get('description'),
                        input_schema=queue_info.get('inputSchema'),
                        input_content_type=input_content_type,
                        output_schema=queue_info.get('outputSchema'),
                        output_content_type=output_content_type
                    )
                    logger.info(f'Successfully registered queue: {queue_info["queueName"]}')
                except Exception as e:
                    logger.error(f"Failed to register queue from {name}: {e}")