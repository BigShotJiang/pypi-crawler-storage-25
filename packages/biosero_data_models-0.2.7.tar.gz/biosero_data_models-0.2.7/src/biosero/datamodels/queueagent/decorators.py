import logging

from rich.logging import RichHandler
import functools
from biosero.datamodels.adapter.template_icons import Icons

logger = logging.getLogger("rich")
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    handlers=[RichHandler(rich_tracebacks=True)]
)

def parameter(queue_name=None, category=None, description=None, 
              input_schema=None, input_content_type="Json", 
              output_schema=None, output_content_type="Json"):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            return result

        # Attach the metadata to the wrapper function
        wrapper._parameter_decorator = {
            'queueName': queue_name,
            'category': category,
            'description': description,
            'inputSchema': input_schema,
            'inputContentType': input_content_type,
            'outputSchema': output_schema,
            'outputContentType': output_content_type
        }
        
        return wrapper
    
    return decorator

def task(name=None, description=None):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger.info(f"[blue]Task: {func.__name__} is being executed.[/blue]", extra={"markup": True})
            result = func(*args, **kwargs)
            return result
        
        # Attach the metadata to the wrapper function
        wrapper._task_decorator = {
            'name': name or func.__name__,
            'description': description
        }
        
        return wrapper
    
    return decorator
