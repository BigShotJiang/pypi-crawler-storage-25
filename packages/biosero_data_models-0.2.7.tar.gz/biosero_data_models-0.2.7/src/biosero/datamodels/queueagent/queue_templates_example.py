"""
Example queue templates using the @parameter decorator.
Each function decorated with @parameter represents a queue to be registered.
"""

from biosero.datamodels.queueagent.decorators import parameter


@parameter(
    queue_name="DataProcessingQueue",
    category="Data Processing",
    description="Queue for processing data records",
    input_schema='{"recordId":123,"operation":"process","data":{}}',
    input_content_type="Json",
    output_schema='{"success":true,"processedRecordId":123,"timestamp":""}',
    output_content_type="Json"
)
def data_processing_queue():
    """Template for data processing queue."""
    pass


@parameter(
    queue_name="SampleAnalysisQueue",
    category="Analysis",
    description="Queue for analyzing sample data",
    input_schema='{"sampleId":"string","testType":"string","parameters":{}}',
    input_content_type="Json",
    output_schema='{"status":"string","results":{},"completedAt":""}',
    output_content_type="Json"
)
def sample_analysis_queue():
    """Template for sample analysis queue."""
    pass


@parameter(
    queue_name="ReportGenerationQueue",
    category="Reporting",
    description="Queue for generating reports",
    input_schema='{"reportType":"string","dataSource":"string","filters":{}}',
    input_content_type="Json",
    output_schema='{"reportId":"string","url":"string","generatedAt":""}',
    output_content_type="Json"
)
def report_generation_queue():
    """Template for report generation queue."""
    pass
