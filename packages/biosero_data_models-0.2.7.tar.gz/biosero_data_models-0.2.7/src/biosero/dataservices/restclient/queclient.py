
from urllib.parse import quote
import requests
import json
from datetime import datetime
from dataclasses import asdict
from biosero.datamodels.queues.queue import (
    QueueInfo, 
    QueueTask, 
    QueueTaskIdOnly, 
    QueueTaskPage,
    QueueTaskStatus,
    QueuesEnabledOnly,
    InputContentType,
    OutputContentType
)


class QueClient:
    def __init__(self, url):
        if callable(url):
            url = url()
        self._session = requests.Session()
        self._session.headers.update({'base_url': url})
        self._created_client = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._created_client:
            self._session.close()

    def get(self, endpoint, params=None):
        return self._session.get(self._session.headers['base_url'] + endpoint, params=params)

    def post(self, endpoint, data=None):
        return self._session.post(self._session.headers['base_url'] + endpoint, data=data)

    def put(self, endpoint, data=None):
        return self._session.put(self._session.headers['base_url'] + endpoint, data=data)

    def delete(self, endpoint):
        return self._session.delete(self._session.headers['base_url'] + endpoint)

    def create_queue(self, queue_name, category=None, description=None, 
                     input_schema=None, input_content_type=None, 
                     output_schema=None, output_content_type=None):
        """
        Creates a new queue.

        Parameters:
        queue_name (str): The name of the queue.
        category (str, optional): The category of the queue.
        description (str, optional): Description of the queue.
        input_schema (str, optional): JSON schema for input validation.
        input_content_type (InputContentType or str, optional): Type of input content.
        output_schema (str, optional): JSON schema for output validation.
        output_content_type (OutputContentType or str, optional): Type of output content.

        Returns:
        QueueInfo: The created queue information.
        """
        # Prepare the queue data
        queue_data = {
            'queueName': queue_name
        }
        
        if category is not None:
            queue_data['category'] = category
        if description is not None:
            queue_data['description'] = description
        if input_schema is not None:
            queue_data['inputSchema'] = input_schema
        if input_content_type is not None:
            # Handle enum or string
            if isinstance(input_content_type, InputContentType):
                queue_data['inputContentType'] = input_content_type.value
            else:
                queue_data['inputContentType'] = input_content_type
        if output_schema is not None:
            queue_data['outputSchema'] = output_schema
        if output_content_type is not None:
            # Handle enum or string
            if isinstance(output_content_type, OutputContentType):
                queue_data['outputContentType'] = output_content_type.value
            else:
                queue_data['outputContentType'] = output_content_type
        
        path = f"{self._session.headers['base_url']}/api/v3.0/queues"
        response = self._session.post(path, 
                                     data=json.dumps(queue_data), 
                                     headers={'Content-Type': 'application/json'})
        response.raise_for_status()
        
        # Parse response and return QueueInfo
        response_data = response.json()
        return QueueInfo(
            queueId=response_data.get('queueId'),
            queueName=response_data.get('queueName'),
            category=response_data.get('category'),
            description=response_data.get('description'),
            inputSchema=response_data.get('inputSchema'),
            inputContentType=InputContentType(response_data['inputContentType']) if response_data.get('inputContentType') else None,
            outputSchema=response_data.get('outputSchema'),
            outputContentType=OutputContentType(response_data['outputContentType']) if response_data.get('outputContentType') else None
        )

    def get_queues(self, queue_names=None, limit=None, offset=None):
        """
        Retrieves queues based on the specified criteria.

        Parameters:
        queue_names (List[str], optional): List of queue names to filter by.
        limit (int, optional): Maximum number of queues to retrieve.
        offset (int, optional): Number of queues to skip before starting to retrieve.

        Returns:
        List[QueueInfo]: A list of queues that match the criteria.
        """
        from urllib.parse import urlencode
        
        # Build query parameters
        params = []
        
        if queue_names:
            for queue_name in queue_names:
                params.append(('queueNames', queue_name))
        
        if limit is not None:
            params.append(('limit', limit))
        
        if offset is not None:
            params.append(('offset', offset))
        
        # Build the URL with query parameters
        path = f"{self._session.headers['base_url']}/api/v3.0/queues"
        if params:
            query_string = urlencode(params)
            path = f"{path}?{query_string}"
        
        response = self._session.get(path, headers={'accept': 'application/json'})
        response.raise_for_status()
        
        # Parse response and return list of QueueInfo objects
        response_data = response.json()
        queues = []
        
        for queue_data in response_data:
            queue = QueueInfo(
                queueId=queue_data.get('queueId'),
                queueName=queue_data.get('queueName'),
                category=queue_data.get('category'),
                description=queue_data.get('description'),
                inputSchema=queue_data.get('inputSchema'),
                inputContentType=InputContentType(queue_data['inputContentType']) if queue_data.get('inputContentType') else None,
                outputSchema=queue_data.get('outputSchema'),
                outputContentType=OutputContentType(queue_data['outputContentType']) if queue_data.get('outputContentType') else None
            )
            queues.append(queue)
        
        return queues

    def update_queue(self, queue_id, queue_name=None, category=None, description=None, 
                     input_schema=None, input_content_type=None, 
                     output_schema=None, output_content_type=None):
        """
        Updates an existing queue.

        Parameters:
        queue_id (int): The ID of the queue to update.
        queue_name (str, optional): The name of the queue.
        category (str, optional): The category of the queue.
        description (str, optional): Description of the queue.
        input_schema (str, optional): JSON schema for input validation.
        input_content_type (InputContentType or str, optional): Type of input content.
        output_schema (str, optional): JSON schema for output validation.
        output_content_type (OutputContentType or str, optional): Type of output content.

        Returns:
        QueueInfo: The updated queue information.
        """
        # Prepare the queue data
        queue_data = {}
        
        if queue_name is not None:
            queue_data['queueName'] = queue_name
        if category is not None:
            queue_data['category'] = category
        if description is not None:
            queue_data['description'] = description
        if input_schema is not None:
            queue_data['inputSchema'] = input_schema
        if input_content_type is not None:
            # Handle enum or string
            if isinstance(input_content_type, InputContentType):
                queue_data['inputContentType'] = input_content_type.value
            else:
                queue_data['inputContentType'] = input_content_type
        if output_schema is not None:
            queue_data['outputSchema'] = output_schema
        if output_content_type is not None:
            # Handle enum or string
            if isinstance(output_content_type, OutputContentType):
                queue_data['outputContentType'] = output_content_type.value
            else:
                queue_data['outputContentType'] = output_content_type
        
        path = f"{self._session.headers['base_url']}/api/v3.0/queues/{queue_id}"
        response = self._session.put(path, 
                                     data=json.dumps(queue_data), 
                                     headers={'Content-Type': 'application/json', 'accept': '*/*'})
        response.raise_for_status()
        
        # Return QueueInfo with the data we have
        return QueueInfo(
            queueId=queue_id,
            queueName=queue_name,
            category=category,
            description=description,
            inputSchema=input_schema,
            inputContentType=InputContentType(input_content_type) if isinstance(input_content_type, str) else input_content_type,
            outputSchema=output_schema,
            outputContentType=OutputContentType(output_content_type) if isinstance(output_content_type, str) else output_content_type
        )

    def create_or_update_queue(self, queue_name, category=None, description=None, 
                               input_schema=None, input_content_type=None, 
                               output_schema=None, output_content_type=None):
        """
        Creates a new queue or updates an existing one if it already exists.

        Parameters:
        queue_name (str): The name of the queue.
        category (str, optional): The category of the queue.
        description (str, optional): Description of the queue.
        input_schema (str, optional): JSON schema for input validation.
        input_content_type (InputContentType or str, optional): Type of input content.
        output_schema (str, optional): JSON schema for output validation.
        output_content_type (OutputContentType or str, optional): Type of output content.

        Returns:
        QueueInfo: The created or updated queue information.
        """
        # Check if queue already exists
        existing_queues = self.get_queues(queue_names=[queue_name])
        
        if existing_queues and len(existing_queues) > 0:
            # Queue exists, update it
            existing_queue = existing_queues[0]
            return self.update_queue(
                queue_id=existing_queue.queueId,
                queue_name=queue_name,
                category=category,
                description=description,
                input_schema=input_schema,
                input_content_type=input_content_type,
                output_schema=output_schema,
                output_content_type=output_content_type
            )
        else:
            # Queue doesn't exist, create it
            return self.create_queue(
                queue_name=queue_name,
                category=category,
                description=description,
                input_schema=input_schema,
                input_content_type=input_content_type,
                output_schema=output_schema,
                output_content_type=output_content_type
            )

    def create_queue_task(self, queue_id, order_identifier, input_data):
        """
        Creates a new task in the specified queue.

        Parameters:
        queue_id (int): The ID of the queue.
        order_identifier (str): The order identifier for the task.
        input_data (str or dict): The input data for the task. If a dict is provided, 
                                  it will be converted to a JSON string.

        Returns:
        dict: The created task information from the API response.
        """
        # Convert input_data to string if it's a dict
        if isinstance(input_data, dict):
            input_string = json.dumps(input_data)
        else:
            input_string = input_data
        
        # Prepare the task data
        task_data = {
            'orderIdentifier': order_identifier,
            'input': input_string
        }
        
        path = f"{self._session.headers['base_url']}/api/v3.0/queues/{queue_id}/tasks"
        response = self._session.post(path, 
                                     data=json.dumps(task_data), 
                                     headers={'Content-Type': 'application/json', 'accept': 'application/json'})
        response.raise_for_status()
        
        # Return the response data
        return response.json()

    def complete_queue_task(self, task_id, output):
        """
        Marks a queue task as complete with the specified output.

        Parameters:
        task_id (int): The ID of the task to complete.
        output (str or dict): The output data for the task. If a dict is provided, 
                              it will be converted to a JSON string.

        Returns:
        response: The API response.
        """
        # Convert output to string if it's a dict
        if isinstance(output, dict):
            output_string = json.dumps(output)
        else:
            output_string = output
        
        # Prepare the completion data
        completion_data = {
            'output': output_string
        }
        
        path = f"{self._session.headers['base_url']}/api/v3.0/queue-tasks/{task_id}/complete"
        response = self._session.post(path, 
                                     data=json.dumps(completion_data), 
                                     headers={'Content-Type': 'application/json', 'accept': '*/*'})
        response.raise_for_status()
        
        return response

    def cancel_queue_task(self, task_id):
        """
        Cancels a queue task.

        Parameters:
        task_id (int): The ID of the task to cancel.

        Returns:
        response: The API response.
        """
        path = f"{self._session.headers['base_url']}/api/v3.0/queue-tasks/{task_id}/cancel"
        response = self._session.post(path, headers={'accept': '*/*'})
        response.raise_for_status()
        
        return response

    def get_pending_queue_tasks(self, queue_id=None):
        """
        Retrieves pending (Created status) queue tasks from the active tasks endpoint.

        Parameters:
        queue_id (int, optional): Filter by specific queue ID.

        Returns:
        List[QueueTask]: A list of pending queue tasks with "Created" status.
        """
        # Use the active tasks endpoint
        path = f"{self._session.headers['base_url']}/api/v3.0/queue-tasks/active"
        
        response = self._session.get(path, headers={'accept': 'application/json'})
        response.raise_for_status()
        
        # Parse response - it's a page object with 'rows' and 'totalCount'
        response_data = response.json()
        
        # Extract the rows from the response
        if isinstance(response_data, dict) and 'rows' in response_data:
            task_list = response_data['rows']
        else:
            task_list = response_data if isinstance(response_data, list) else []
        
        tasks = []
        for task_data in task_list:
            # Filter for "Created" status
            if task_data.get('status') != 'Created':
                continue
            
            # Filter by queue_id if specified
            if queue_id is not None and task_data.get('queueId') != queue_id:
                continue
            
            task = QueueTask(
                queueTaskId=task_data.get('queueTaskId'),
                queueId=task_data.get('queueId'),
                queueName=task_data.get('queueName'),
                category=task_data.get('category'),
                orderIdentifier=task_data.get('orderIdentifier'),
                status=QueueTaskStatus(task_data['status']) if task_data.get('status') else None,
                input=task_data.get('input'),
                inputContentType=InputContentType(task_data['inputContentType']) if task_data.get('inputContentType') else None,
                output=task_data.get('output'),
                outputContentType=OutputContentType(task_data['outputContentType']) if task_data.get('outputContentType') else None,
                modifiedDateUtc=task_data.get('modifiedDateUtc')
            )
            tasks.append(task)
        
        return tasks

    def get_next_queue_task(self, queue_name):
        """
        Gets the next available task from the specified queue.

        Parameters:
        queue_name (str): Queue name to get the next task from.

        Returns:
        QueueTask or None: The next available task, or None if no tasks available.
        """
        # Prepare the request data with queue name in a list
        request_data = {
            'queueNames': [queue_name]
        }
        
        path = f"{self._session.headers['base_url']}/api/v3.0/queue-tasks/get-next"
        response = self._session.post(path, 
                                     data=json.dumps(request_data), 
                                     headers={'Content-Type': 'application/json', 'accept': 'application/json'})
        response.raise_for_status()
        
        # Parse response - it's a list with a single task or empty list
        response_data = response.json()
        
        # If no task available, response will be an empty list
        if not response_data or len(response_data) == 0:
            return None
        
        # Extract the first (and only) task from the list
        task_data = response_data[0]
        
        # Create and return QueueTask object
        task = QueueTask(
            queueTaskId=task_data.get('queueTaskId'),
            queueId=task_data.get('queueId'),
            queueName=task_data.get('queueName'),
            category=task_data.get('category'),
            orderIdentifier=task_data.get('orderIdentifier'),
            status=QueueTaskStatus(task_data['status']) if task_data.get('status') else None,
            input=task_data.get('input'),
            inputContentType=InputContentType(task_data['inputContentType']) if task_data.get('inputContentType') else None,
            output=task_data.get('output'),
            outputContentType=OutputContentType(task_data['outputContentType']) if task_data.get('outputContentType') else None,
            modifiedDateUtc=task_data.get('modifiedDateUtc')
        )
        
        return task