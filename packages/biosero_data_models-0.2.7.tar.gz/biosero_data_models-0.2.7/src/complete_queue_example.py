"""
Complete example showing queue registration and task processing workflow.

This example demonstrates:
1. Defining queue templates using decorators
2. Registering queues with Data Services
3. Implementing queue action handlers
4. Processing queue tasks
"""

# Step 1: Define queue templates (usually in a separate module)
from biosero.datamodels.queueagent.decorators import parameter


@parameter(
    queue_name="OrderProcessingQueue",
    category="Order Management",
    description="Processes customer orders",
    input_schema='{"orderId":"string","items":[],"customerId":"string"}',
    input_content_type="Json",
    output_schema='{"orderId":"string","status":"string","processedAt":"string"}',
    output_content_type="Json"
)
def order_processing_queue():
    """Template for order processing queue."""
    pass


# Step 2: Implement queue action handlers
import time
import logging

logger = logging.getLogger()


class MyQueueActions:
    """Implements the actual queue task processing logic."""
    
    def order_processing_queue(self, task, **kwargs):
        """
        Processes orders from the OrderProcessingQueue.
        Method name must match the queue template function name.
        """
        order_id = kwargs.get('orderId')
        items = kwargs.get('items', [])
        customer_id = kwargs.get('customerId')
        
        logger.info(f"Processing order {order_id} for customer {customer_id}")
        logger.info(f"Order items: {items}")
        
        # Your business logic here
        time.sleep(1)  # Simulate processing
        
        # Return structured output matching the output schema
        return {
            "orderId": order_id,
            "status": "processed",
            "processedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ")
        }


if __name__ == "__main__":
    import sys
    
    # Configuration
    data_services_url = "http://10.0.0.234:8105"
    
    # Import this module as queue_templates
    import __main__ as queue_templates
    
    # Step 3: Register queues (run once to set up queues)
    if len(sys.argv) > 1 and sys.argv[1] == "register":
        from biosero.datamodels.queueagent import QueueRegistrar
        
        print("Registering queues...")
        registrar = QueueRegistrar(data_services_url, queue_templates)
        registrar.register_all_queues()
        print("Queue registration complete!")
    
    # Step 4: Start task processor (run continuously to process tasks)
    elif len(sys.argv) > 1 and sys.argv[1] == "process":
        from biosero.datamodels.queueagent import QueueTaskProcessor
        
        # Create actions instance
        actions = MyQueueActions()
        
        # Create processor
        processor = QueueTaskProcessor(
            url=data_services_url,
            queue_templates=queue_templates,
            queue_actions_instance=actions,
            adapter_id="ORDER-PROCESSOR-1",
            adapter_name="Order Processor"
        )
        
        print("Starting queue task processor...")
        print("Press Ctrl+C to stop")
        
        try:
            # Start polling for tasks
            processor.poll_pending_tasks()
        except KeyboardInterrupt:
            print("\nStopping processor...")
    
    else:
        print("Usage:")
        print("  python complete_queue_example.py register   # Register queues")
        print("  python complete_queue_example.py process    # Start processing tasks")
