"""
Example usage of QueueTaskProcessor to process queue tasks.
"""

from biosero.datamodels.queueagent.queue_actions_example import QueueActions
from biosero.datamodels.queueagent.queue_task_processer import QueueTaskProcessor
import biosero.datamodels.queueagent.queue_templates_example as queue_templates
from biosero.datamodels.queueagent.queue_actions_with_task_decorator import QueueActionsWithTaskDecorator

# Initialize the queue actions instance
queue_actions = QueueActionsWithTaskDecorator()

# Set up your Data Services URL
data_services_url = "http://10.0.0.234:8105"

# Create the QueueTaskProcessor
processor = QueueTaskProcessor(
    url=data_services_url,
    queue_templates=queue_templates,
    queue_actions_instance=queue_actions,
    adapter_id="QUEUE-PROCESSOR-1",
    adapter_name="Queue Task Processor"
)

# Start polling for pending tasks
# This will continuously poll and process tasks from all registered queues
print("Starting queue task processor...")
print("Polling for pending tasks...")

processor.poll_pending_tasks()
