"""
Example usage of QueueRegistrar to register queues from templates.
"""

from biosero.datamodels.queueagent import QueueRegistrar
import queue_templates as queue_templates

# Initialize the QueueRegistrar with your Data Services URL
data_services_url = "http://10.0.0.234:8105"

# Create the registrar instance
queue_registrar = QueueRegistrar(data_services_url, queue_templates)

# Register all queues defined in the queue_templates module
queue_registrar.register_all_queues()

print("All queues registered successfully!")
