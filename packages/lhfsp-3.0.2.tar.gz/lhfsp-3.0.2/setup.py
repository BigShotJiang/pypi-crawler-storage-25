from setuptools import setup, find_packages

setup(
    name='lhfsp',
    version='3.0.2',
    packages=find_packages(),
    install_requires=['pyperclip'],
)