# lhfsp
import random
import string 
import pyperclip

def manualhash(text, z, copyresult=False):
    hashtextlist = []
    y = 0
    i = 0
    for char in text:
        if i==0:
            y = ord(char)
        else:
            y *= ord(char)
            i += 1
    for char in text:
        x = ord(char)
        r = pow(x, y, z)
        hashchar = chr(r)
        hashtextlist.append(hashchar)
    hashtext = "".join(hashtextlist)
    if copyresult:
        pyperclip.copy(hashtext)
    return hashtext

def classichash(text, copyresult=False):
    return manualhash(text, 2908, copyresult)

def keyhash(text, key, copyresult=False):
    if not (len(key) == 4 and key.isalpha()):
        raise ValueError(f'{key}: key should be 4 letters long and alphabetic!')
    
    z = 0
    for char in key:
        z += ord(char)
        
    return manualhash(text, z, copyresult)
    
def rkeyhash(text, copyresult=False):
    rkey = ''.join(random.choices(string.ascii_letters, k=4))
    print(f'key: {rkey}')
    return keyhash(text, rkey, copyresult)