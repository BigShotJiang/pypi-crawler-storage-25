"""Normal form computation for symplectic DA maps.

Algorithm: order-by-order elimination in the complex eigenvector basis.

For a 2n-dimensional symplectic map M expressed in phase space coordinates
(x1, px1, ..., xn, pxn), the normal form procedure:

1. Extracts the Jacobian matrix and eigendecomposes it to find tunes
   and the Courant-Snyder (Floquet) transformation.

2. Transforms the map to normalized coordinates where the linear part
   is a pure rotation.

3. Order by order, eliminates non-resonant monomials via near-identity
   canonical transformations, leaving only amplitude-dependent terms.

4. The surviving terms encode detuning coefficients (amplitude-dependent
   tune shifts) and resonance driving terms.

Reference: Bazzani, Servizi, Turchetti, "A Normal Form Approach to the
Theory of Nonlinear Betatronic Motion," CERN 94-02 (1994).
"""

import numpy as np
from daceypy import DA, array as DAarray

from danf.complex_nf import compute_detuning_1d


class NormalForm:
    """Compute the normal form of a symplectic map.

    Parameters
    ----------
    da_map : list of DA
        The symplectic map components [x', px', (y', py')].
        Must have 2 components (1 DOF) or 4 components (2 DOF).

    Attributes
    ----------
    ndof : int
        Number of degrees of freedom (1 or 2).
    tunes : ndarray
        Linear tunes [nu_x, (nu_y)].
    detuning : dict
        Amplitude-dependent tune shift coefficients.
    """

    def __init__(self, da_map):
        if isinstance(da_map, DAarray):
            self._map = [da_map[i] for i in range(len(da_map))]
        else:
            self._map = list(da_map)

        dim = len(self._map)
        if dim not in (2, 4, 6):
            raise ValueError(f"Map must have 2, 4, or 6 components, got {dim}")
        self.ndof = dim // 2

        self._order = DA.getMaxOrder()
        self._nvar = DA.getMaxVariables()

        self.tunes = None
        self.detuning = {}
        self._jacobian = None
        self._eigvals = None
        self._eigvecs = None
        self._cs_matrix = None
        self._cs_matrix_inv = None
        self._nf_map = None
        self._computed = False

    def compute(self):
        """Run the full normal form computation."""
        self._extract_jacobian()
        self._linear_normal_form()
        self._absorb_parameter_dispersion()
        self._transform_to_floquet()
        self._nonlinear_normal_form()
        self._computed = True

    # ------------------------------------------------------------------
    # Step 2.5: if the map carries passive parameters (DA variables
    # beyond the 2*ndof transverse ones), the linear closed orbit
    # depends linearly on each parameter. Subtract that linear
    # dispersion from the map so that the NF expansion is around the
    # parametric closed orbit rather than the reference origin.
    # ------------------------------------------------------------------

    def _absorb_parameter_dispersion(self):
        """Shift the map so the parametric closed orbit is at the origin
        to all orders in the passive parameters.

        This follows COSY INFINITY's FM procedure: the closed-orbit shift
        is the fixed point of the transverse residual map treated as a
        polynomial in both transverse coordinates and passive parameters.
        We invert that residual as a DA map and evaluate it with zeros
        in the transverse slots and identity in the parameter slots.
        The linear dispersion only is not enough — nonlinear dispersion
        (D2 delta^2 + ...) contributes to amplitude-dependent tunes at
        the resonant order we care about.
        """
        from daceypy import array as DAarray
        dim = 2 * self.ndof
        nvar = DA.getMaxVariables()
        if nvar <= dim:
            return

        # Build residual N: transverse components are M_i - x_i, and
        # the parameter slots are the identity so MI has a square map.
        v = [DA(i + 1) for i in range(nvar)]
        N = [self._map[i] - v[i] for i in range(dim)] + [v[i] for i in range(dim, nvar)]

        try:
            NI = DAarray(N).invert()
        except Exception:
            return  # no inverse -> we are on a linear resonance

        # XF(delta) = NI(0,...,0, delta_1,...,delta_p). Its transverse
        # components are the parametric closed orbit.
        C = [DA(0.0)] * dim + [DA(k + 1) for k in range(dim, nvar)]
        XF = [NI[i].eval(C) for i in range(nvar)]

        # Shift coordinates: q_new = q - XF(delta). The new map is
        #   M_new(q_new, delta) = M(q_new + XF, delta) - XF.
        shifted_state = [v[i] + XF[i] for i in range(dim)] + [v[i] for i in range(dim, nvar)]
        new_map = []
        for i in range(dim):
            m_shifted = self._map[i].eval(shifted_state)
            new_map.append(m_shifted - XF[i])

        self._map = new_map

    # ------------------------------------------------------------------
    # Step 1: Jacobian extraction
    # ------------------------------------------------------------------

    def _extract_jacobian(self):
        dim = 2 * self.ndof
        self._jacobian = np.zeros((dim, dim))
        for i in range(dim):
            lin = self._map[i].linear()
            self._jacobian[i, :dim] = lin[:dim]

    # ------------------------------------------------------------------
    # Step 2: Linear normal form (eigendecomposition)
    # ------------------------------------------------------------------

    def _linear_normal_form(self):
        M = self._jacobian
        eigenvalues, eigenvectors = np.linalg.eig(M)

        idx = _sort_eigenvalues(eigenvalues, self.ndof)
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        self._eigvals = eigenvalues
        self._eigvecs = eigenvectors

        self.tunes = np.zeros(self.ndof)
        for k in range(self.ndof):
            lam = eigenvalues[2 * k]
            self.tunes[k] = np.angle(lam) / (2 * np.pi)
            if self.tunes[k] < 0:
                self.tunes[k] += 1.0

        self._cs_matrix = _build_real_cs_matrix(eigenvectors, self.ndof)
        self._cs_matrix_inv = np.linalg.inv(self._cs_matrix)

    # ------------------------------------------------------------------
    # Step 3: Transform to Floquet (normalized) coordinates
    # ------------------------------------------------------------------

    def _transform_to_floquet(self):
        dim = 2 * self.ndof
        S = self._cs_matrix
        Sinv = self._cs_matrix_inv

        nvar = DA.getMaxVariables()
        w = [DA(i + 1) for i in range(dim)]
        phys = _matvec_da(S, w)
        # Pass any DA variables beyond the 2*ndof transverse ones through
        # the eval-substitution unchanged; otherwise daceypy's eval would
        # silently set them to zero when phys is shorter than nvar.
        if nvar > dim:
            phys = list(phys) + [DA(k + 1) for k in range(dim, nvar)]
        mapped = [self._map[i].eval(phys) for i in range(dim)]
        self._nf_map = _matvec_da(Sinv, mapped)

        # The eigenvector-based CS matrix can produce either rotation
        # direction (tune nu or 1-nu). Extract the actual phase advance
        # from the Floquet map's linear part and update self.tunes.
        for k in range(self.ndof):
            j = 2 * k
            cos_mu = self._nf_map[j].getCoefficient(
                [int(i == j) for i in range(dim)])
            sin_mu = self._nf_map[j].getCoefficient(
                [int(i == j + 1) for i in range(dim)])
            mu = np.arctan2(sin_mu, cos_mu)
            if mu < 0:
                mu += 2 * np.pi
            self.tunes[k] = mu / (2 * np.pi)

    # ------------------------------------------------------------------
    # Step 3b: Chromatic (delta-dependent) Courant-Snyder Floquet.
    # Use when the map carries passive parameters that induce chromatic
    # linear couplings. The action variables become delta-dependent and
    # the linear part becomes pure rotation at every order in delta,
    # which is what is needed for a proper Birkhoff normal form when
    # parameters are retained.
    # ------------------------------------------------------------------

    def _transform_to_chromatic_floquet(self):
        dim = 2 * self.ndof
        nvar = DA.getMaxVariables()
        order = DA.getMaxOrder()
        n_extra = nvar - dim
        assert n_extra >= 1

        def _delta_monomial(exps):
            d = DA(0.0)
            d.setCoefficient(exps, 1.0)
            return d

        # Extract M_ij as a DA that depends only on the passive-parameter
        # variables (indices dim..nvar-1).
        M_da = [[DA(0.0) for _ in range(dim)] for _ in range(dim)]

        def _iter_param_exps(total_order):
            # yield tuples of length n_extra with nonnegative entries summing to <= total_order
            from itertools import product
            for tup in product(range(total_order + 1), repeat=n_extra):
                if sum(tup) <= total_order:
                    yield tup

        # The transverse coefficient picks up one unit of transverse
        # order; cap parameter exponents so we stay within DA order.
        for i in range(dim):
            for j in range(dim):
                for param_exp in _iter_param_exps(order - 1):
                    exps = [0] * nvar
                    exps[j] = 1
                    for k, p in enumerate(param_exp):
                        exps[dim + k] = p
                    c = self._map[i].getCoefficient(exps)
                    if abs(c) > 1e-15:
                        mono_exps = [0] * nvar
                        for k, p in enumerate(param_exp):
                            mono_exps[dim + k] = p
                        M_da[i][j] = M_da[i][j] + c * _delta_monomial(mono_exps)

        # Per-plane chromatic CS. For each 2x2 block, compute
        # beta(param), alpha(param) as DAs, build CS matrix.
        css_S = []     # S_plane (CS)
        css_Sinv = []  # CS inverse

        for plane in range(self.ndof):
            j1 = 2 * plane
            j2 = 2 * plane + 1
            a_da = M_da[j1][j1]
            b_da = M_da[j1][j2]
            c_da = M_da[j2][j1]
            d_da = M_da[j2][j2]

            trace = a_da + d_da
            cos_mu = 0.5 * trace
            sin_mu_sq = 1.0 - cos_mu * cos_mu
            sin_mu_pos = DA.sqrt(sin_mu_sq)
            # Sign of sin_mu such that beta = b / sin_mu is positive
            # b is the (q -> p) matrix element; beta > 0 always.
            if b_da.cons() > 0 and sin_mu_pos.cons() > 0:
                sin_mu = sin_mu_pos
            elif b_da.cons() < 0 and sin_mu_pos.cons() > 0:
                sin_mu = -sin_mu_pos
            else:
                sin_mu = sin_mu_pos

            beta = b_da / sin_mu
            alpha = (a_da - d_da) / (2.0 * sin_mu)
            sqrt_beta = DA.sqrt(beta)
            inv_sqrt_beta = 1.0 / sqrt_beta

            # CS: q_NF = CS * q_phys
            # CS = [[1/sqrt(b),       0    ],
            #       [ alpha/sqrt(b), sqrt(b)]]
            S = [[inv_sqrt_beta, DA(0.0)],
                 [alpha * inv_sqrt_beta, sqrt_beta]]
            # CS inverse (det=1)
            Sinv = [[sqrt_beta, DA(0.0)],
                    [-alpha * inv_sqrt_beta, inv_sqrt_beta]]
            css_S.append(S)
            css_Sinv.append(Sinv)

        # NF_map(u, delta) = S_full(delta) * M(S_inv_full(delta) * u, delta)
        u_NF = [DA(i + 1) for i in range(dim)]
        extra_vars = [DA(k + 1) for k in range(dim, nvar)]

        # q_phys = Sinv_full * u_NF  (block diagonal)
        q_phys = []
        for plane in range(self.ndof):
            Sinv = css_Sinv[plane]
            j1 = 2 * plane
            j2 = 2 * plane + 1
            q_phys.append(Sinv[0][0] * u_NF[j1] + Sinv[0][1] * u_NF[j2])
            q_phys.append(Sinv[1][0] * u_NF[j1] + Sinv[1][1] * u_NF[j2])

        q_phys_full = q_phys + extra_vars
        mapped = [self._map[i].eval(q_phys_full) for i in range(dim)]

        # Apply S_full
        nf_map = []
        for plane in range(self.ndof):
            S = css_S[plane]
            j1 = 2 * plane
            j2 = 2 * plane + 1
            nf_map.append(S[0][0] * mapped[j1] + S[0][1] * mapped[j2])
            nf_map.append(S[1][0] * mapped[j1] + S[1][1] * mapped[j2])

        self._nf_map = nf_map

        # Update tunes from the on-momentum linear part of the new map.
        for k in range(self.ndof):
            j = 2 * k
            cos_mu_val = nf_map[j].getCoefficient(
                [int(i == j) for i in range(dim)] + [0] * n_extra)
            sin_mu_val = nf_map[j].getCoefficient(
                [int(i == j + 1) for i in range(dim)] + [0] * n_extra)
            mu = np.arctan2(sin_mu_val, cos_mu_val)
            if mu < 0:
                mu += 2 * np.pi
            self.tunes[k] = mu / (2 * np.pi)

    # ------------------------------------------------------------------
    # Step 4: Nonlinear normal form via complex-variable engine
    # ------------------------------------------------------------------

    def _nonlinear_normal_form(self):
        if self.ndof == 1:
            self._nonlinear_nf_1d()
        elif self.ndof == 2:
            self._nonlinear_nf_2d()
        elif self.ndof == 3:
            self._nonlinear_nf_3d()

    def _nonlinear_nf_1d(self):
        dnu_dJ, c21, nf_x, nf_px = compute_detuning_1d(
            self._nf_map[0], self._nf_map[1], self.tunes[0]
        )

        self._nf_map = [nf_x, nf_px]

        self.detuning = {
            "dnux_dJx": dnu_dJ,
            "alpha_xx": dnu_dJ,
            "c21": c21,
        }

    def _nonlinear_nf_2d(self):
        from danf.complex_nf_2d import compute_detuning_2d

        detuning, nf_map = compute_detuning_2d(self._nf_map, self.tunes)
        self._nf_map = nf_map
        self.detuning = detuning

    def _nonlinear_nf_3d(self):
        from danf.complex_nf_3d import compute_detuning_3d

        detuning, nf_map = compute_detuning_3d(self._nf_map, self.tunes)
        self._nf_map = nf_map
        self.detuning = detuning


# ======================================================================
# Helper functions
# ======================================================================

def _sort_eigenvalues(eigenvalues, ndof):
    """Sort eigenvalues into pairs (λ, λ*) with Im(λ) > 0."""
    n = len(eigenvalues)
    used = [False] * n
    order = []

    for _ in range(ndof):
        best = None
        for i in range(n):
            if not used[i] and eigenvalues[i].imag > 0:
                if best is None or abs(eigenvalues[i].imag) > abs(eigenvalues[best].imag):
                    best = i

        if best is None:
            raise ValueError("Cannot find eigenvalue pair with positive imaginary part")

        lam = eigenvalues[best]
        used[best] = True
        order.append(best)

        conj_idx = None
        for i in range(n):
            if not used[i] and abs(eigenvalues[i] - lam.conjugate()) < 1e-10:
                conj_idx = i
                break
        if conj_idx is None:
            raise ValueError("Cannot find conjugate eigenvalue")
        used[conj_idx] = True
        order.append(conj_idx)

    return order


def _build_real_cs_matrix(eigenvectors, ndof):
    """Build real Courant-Snyder matrix from complex eigenvectors.

    For each plane k, use eigenvector v_k with positive imaginary tune.
    The symplectic product v_k^T J conj(v_k) / (2i) summed across all
    canonical pairs gives the normalization; this is the correct
    generalisation for coupled systems (e.g. 3 DOF where the eigenvectors
    have components across multiple transverse/longitudinal pairs).
    """
    dim = 2 * ndof
    S = np.zeros((dim, dim))

    for k in range(ndof):
        v = eigenvectors[:, 2 * k]
        re_v = v.real
        im_v = v.imag

        # Full symplectic product sum_i [re_v[2i] im_v[2i+1] - re_v[2i+1] im_v[2i]]
        symp_prod = 0.0
        for i in range(ndof):
            symp_prod += re_v[2 * i] * im_v[2 * i + 1] - re_v[2 * i + 1] * im_v[2 * i]

        if abs(symp_prod) < 1e-14:
            raise ValueError(
                f"Plane {k}: symplectic product ~0; eigenvectors may be degenerate.")

        scale = 1.0 / np.sqrt(abs(symp_prod))
        sign = np.sign(symp_prod)

        j1 = 2 * k
        j2 = 2 * k + 1
        S[:, j1] = re_v * scale
        S[:, j2] = im_v * scale * sign

    return S


def _matvec_da(matrix, da_vec):
    """Multiply a numpy matrix by a vector of DA objects."""
    dim = len(da_vec)
    result = []
    for i in range(dim):
        s = DA(0.0)
        for j in range(dim):
            s = s + matrix[i, j] * da_vec[j]
        result.append(s)
    return result
