"""2D (4-variable) complex-variable normal form via Lie algebra.

For a 4D symplectic map, the NF transformation must be canonical. This
requires deriving both delta_z1 and delta_z2 from a single Hamiltonian
generating function W, solved via the homological equation:

  {W, H_0} + h_n = 0

where h_n is the Hamiltonian perturbation at order n, H_0 = mu1*J1 + mu2*J2,
and the Poisson bracket gives:

  W_{k1l1k2l2} = h_n_{k1l1k2l2} / [i * (mu1*(k1-l1) + mu2*(k2-l2))]

The Hamiltonian perturbation h is recovered from the map residual R via:
  h_{k1l1k2l2} = i * R_z1_{k1,l1-1,k2,l2} / l1  (for l1 >= 1)
  h_{k1l1k2l2} = i * R_z2_{k1,l1,k2,l2-1} / l2  (for l2 >= 1)

The resulting transformation delta_zk = -i * dW/d(zk*) is guaranteed
canonical, preserving the symmetry of the detuning matrix.
"""

import numpy as np
from math import comb
from daceypy import DA


def _real_to_complex_1pair(a, b):
    """Expand u^a pu^b in (z, z*) for one DOF."""
    n = a + b
    sq2n = np.sqrt(2) ** n
    result = {}
    for r in range(a + 1):
        for s in range(b + 1):
            k = r + s
            l = (a - r) + (b - s)
            coeff = ((1j) ** b / sq2n
                     * comb(a, r) * comb(b, s) * (-1) ** (b - s))
            key = (k, l)
            result[key] = result.get(key, 0.0) + coeff
    return result


def real_to_complex_monomial_2d(a, b, c, d):
    """Expand u1^a pu1^b u2^c pu2^d in complex (k1,l1,k2,l2)."""
    pair1 = _real_to_complex_1pair(a, b)
    pair2 = _real_to_complex_1pair(c, d)
    result = {}
    for (k1, l1), c1 in pair1.items():
        for (k2, l2), c2 in pair2.items():
            key = (k1, l1, k2, l2)
            result[key] = result.get(key, 0.0) + c1 * c2
    return result


def _complex_to_real_1pair(k, l):
    """Express z^k z*^l in (u, pu) for one DOF."""
    n = k + l
    sq2n = np.sqrt(2) ** n
    result = {}
    for r in range(k + 1):
        for s in range(l + 1):
            a = r + s
            b = (k - r) + (l - s)
            coeff = (1.0 / sq2n
                     * comb(k, r) * (-1j) ** (k - r)
                     * comb(l, s) * (1j) ** (l - s))
            key = (a, b)
            result[key] = result.get(key, 0.0) + coeff
    return result


def complex_to_real_monomial_2d(k1, l1, k2, l2):
    """Express z1^k1 z1*^l1 z2^k2 z2*^l2 in real (a,b,c,d)."""
    pair1 = _complex_to_real_1pair(k1, l1)
    pair2 = _complex_to_real_1pair(k2, l2)
    result = {}
    for (a, b), c1 in pair1.items():
        for (c, d), c2 in pair2.items():
            key = (a, b, c, d)
            result[key] = result.get(key, 0.0) + c1 * c2
    return result


def extract_complex_coefficients_2d(da_map, dof_index, order):
    """Extract complex z-coefficients for z_{dof_index} at given transverse order.

    Returns a dict whose keys are (k1, l1, k2, l2, *extra) where
    `extra` is a tuple of exponents of any DA variables beyond the first
    four transverse ones. For a plain 4-variable DA, keys are the usual
    4-tuples; if the DA carries additional variables, their exponents
    are appended and the result is keyed by the full tuple. Transverse
    order is the sum of the first four exponents.
    """
    j = 2 * dof_index
    da_u = da_map[j]
    da_pu = da_map[j + 1]
    nvar = DA.getMaxVariables()
    result = {}
    for da_comp, multiplier in [(da_u, 1.0 / np.sqrt(2)),
                                 (da_pu, -1j / np.sqrt(2))]:
        for mono in da_comp.getMonomials():
            jj = mono.m_jj
            a, b, c, d = jj[0], jj[1], jj[2], jj[3]
            if a + b + c + d != order:
                continue
            extra = tuple(jj[i] for i in range(4, nvar))
            real_coeff = mono.m_coeff.value
            expansion = real_to_complex_monomial_2d(a, b, c, d)
            for key, conv_coeff in expansion.items():
                full_key = key + extra
                result[full_key] = result.get(full_key, 0j) + multiplier * real_coeff * conv_coeff
    return result


def _hamiltonian_from_map_residual(R_z1, R_z2, order):
    """Recover the Hamiltonian perturbation h from map residual (R_z1, R_z2).

    Retained for backward compatibility; not used by the direct-divisor
    pipeline in :func:`compute_detuning_2d`.
    """
    h = {}

    all_indices = set()
    for key in R_z1:
        k1, l1, k2, l2 = key[:4]
        extra = key[4:]
        if k1 + l1 + k2 + l2 == order:
            all_indices.add((k1, l1 + 1, k2, l2) + extra)
    for key in R_z2:
        k1, l1, k2, l2 = key[:4]
        extra = key[4:]
        if k1 + l1 + k2 + l2 == order:
            all_indices.add((k1, l1, k2, l2 + 1) + extra)

    for full_key in all_indices:
        k1, l1, k2, l2 = full_key[:4]
        extra = full_key[4:]
        if k1 + l1 + k2 + l2 != order + 1:
            continue
        if l1 == 0 and l2 == 0:
            continue

        if l1 >= 1:
            r_key = (k1, l1 - 1, k2, l2) + extra
            if r_key in R_z1:
                h[full_key] = 1j * R_z1[r_key] / l1
                continue

        if l2 >= 1:
            r_key = (k1, l1, k2, l2 - 1) + extra
            if r_key in R_z2:
                h[full_key] = 1j * R_z2[r_key] / l2
                continue

    return h


def _generating_function_from_hamiltonian(h, mu1, mu2):
    """Solve homological equation: W = h / [i*(mu1*(k1-l1) + mu2*(k2-l2))]."""
    W = {}
    for full_key, h_kl in h.items():
        k1, l1, k2, l2 = full_key[:4]
        D = mu1 * (k1 - l1) + mu2 * (k2 - l2)
        if abs(D) > 1e-8:
            W[full_key] = h_kl / (1j * D)
    return W


def _transformation_from_W(W):
    """Compute delta_z1, delta_z2 from Hamiltonian generating function W."""
    g_z1 = {}
    g_z2 = {}
    for full_key, w_kl in W.items():
        k1, l1, k2, l2 = full_key[:4]
        extra = full_key[4:]
        if l1 >= 1:
            key1 = (k1, l1 - 1, k2, l2) + extra
            g_z1[key1] = g_z1.get(key1, 0j) + (-1j) * l1 * w_kl
        if l2 >= 1:
            key2 = (k1, l1, k2, l2 - 1) + extra
            g_z2[key2] = g_z2.get(key2, 0j) + (-1j) * l2 * w_kl
    return g_z1, g_z2


def _build_real_generating_function(g_z1, g_z2):
    """Convert complex generating functions to real DA components."""
    g = [DA(0.0) for _ in range(4)]

    for g_complex, g_idx in [(g_z1, 0), (g_z2, 1)]:
        j = 2 * g_idx
        for full_key, c_kl in g_complex.items():
            k1, l1, k2, l2 = full_key[:4]
            extra = full_key[4:]
            real_exp = complex_to_real_monomial_2d(k1, l1, k2, l2)
            for (a, b, c, d), real_coeff in real_exp.items():
                full_coeff = c_kl * real_coeff
                exponents = [a, b, c, d] + list(extra)
                cur_u = g[j].getCoefficient(exponents)
                g[j].setCoefficient(exponents, cur_u + np.sqrt(2) * full_coeff.real)
                cur_pu = g[j + 1].getCoefficient(exponents)
                g[j + 1].setCoefficient(exponents, cur_pu - np.sqrt(2) * full_coeff.imag)

    return g


def compute_detuning_2d(da_map, tunes):
    """Compute the 2D detuning matrix via symplectic Birkhoff normal form.

    At each transverse order we recover the Hamiltonian perturbation h
    from the post-Floquet map residual R via the Deprit relation
    h_{k,l} = -i R_{k,l-1} / (l * lam_j), solve the homological equation
    W = i h / [mu_x (k1-l1) + mu_y (k2-l2)] for the generating function,
    and apply the induced canonical transformation. This preserves
    symplecticity, which matters when passive parameters (eg. delta)
    couple chromatic linear terms into nonlinear orders.

    Parameters
    ----------
    da_map : list of DA (length 4)
        [u1', pu1', u2', pu2'] in Floquet coordinates.
    tunes : array-like, length 2
        [nu1, nu2] fractional tunes.

    Returns
    -------
    detuning : dict
    nf_map : list of DA (length 4)
    """
    mu1 = 2 * np.pi * tunes[0]
    mu2 = 2 * np.pi * tunes[1]
    lam1 = np.exp(1j * mu1)
    lam2 = np.exp(1j * mu2)
    order = DA.getMaxOrder()
    nvar = DA.getMaxVariables()
    n_extra = max(0, nvar - 4)

    cur = [DA(m) for m in da_map]

    # Chromatic linear couplings cause single-pass elimination to leave
    # residuals at higher parameter powers of the same transverse order.
    # Iterate each order to convergence when parameters are present.
    max_passes = 4 * order + 4 if n_extra > 0 else 1

    for n in range(2, order + 1):
        for _pass in range(max_passes):
            R_z1 = extract_complex_coefficients_2d(cur, 0, n)
            R_z2 = extract_complex_coefficients_2d(cur, 1, n)

            if not R_z1 and not R_z2:
                break

            g_z1 = {}
            g_z2 = {}
            for full_key, f in R_z1.items():
                k1, l1, k2, l2 = full_key[:4]
                mon = lam1 ** k1 * np.conj(lam1) ** l1 * lam2 ** k2 * np.conj(lam2) ** l2
                divisor = lam1 - mon
                if abs(divisor) > 1e-10:
                    g_z1[full_key] = -f / divisor

            for full_key, f in R_z2.items():
                k1, l1, k2, l2 = full_key[:4]
                mon = lam1 ** k1 * np.conj(lam1) ** l1 * lam2 ** k2 * np.conj(lam2) ** l2
                divisor = lam2 - mon
                if abs(divisor) > 1e-10:
                    g_z2[full_key] = -f / divisor

            if not g_z1 and not g_z2:
                break

            max_g = max([abs(v) for v in g_z1.values()] + [abs(v) for v in g_z2.values()] + [0.0])
            if max_g < 1e-12:
                break

            g = _build_real_generating_function(g_z1, g_z2)

            v = [DA(i + 1) for i in range(4)]
            T = [v[i] + g[i] for i in range(4)]
            extra_vars = [DA(k + 1) for k in range(4, nvar)]
            T_full = T + extra_vars

            Tinv = [DA(v[i]) for i in range(4)]
            for _ in range(order):
                Tinv_full = Tinv + extra_vars
                Tinv = [v[i] - g[i].eval(Tinv_full) for i in range(4)]

            MoT = [cur[i].eval(T_full) for i in range(4)]
            MoT_full = MoT + extra_vars
            cur = [Tinv[i].eval(MoT_full) for i in range(4)]

    c3_z1 = extract_complex_coefficients_2d(cur, 0, 3)
    c3_z2 = extract_complex_coefficients_2d(cur, 1, 3)

    def _scalar_coeff(d, base4):
        # Retrieve the (k1,l1,k2,l2,0,...,0) entry.
        key = base4 + (0,) * n_extra
        return d.get(key, 0j)

    c21_xx = _scalar_coeff(c3_z1, (2, 1, 0, 0))
    c21_xy = _scalar_coeff(c3_z1, (1, 0, 1, 1))
    c21_yy = _scalar_coeff(c3_z2, (0, 0, 2, 1))
    c21_yx = _scalar_coeff(c3_z2, (1, 1, 1, 0))

    dnux_dJx = (c21_xx / lam1).imag / (2 * np.pi)
    dnux_dJy = (c21_xy / lam1).imag / (2 * np.pi)
    dnuy_dJx = (c21_yx / lam2).imag / (2 * np.pi)
    dnuy_dJy = (c21_yy / lam2).imag / (2 * np.pi)

    result = {
        'dnux_dJx': dnux_dJx, 'dnux_dJy': dnux_dJy,
        'dnuy_dJx': dnuy_dJx, 'dnuy_dJy': dnuy_dJy,
        'c21_xx': c21_xx, 'c21_xy': c21_xy,
        'c21_yx': c21_yx, 'c21_yy': c21_yy,
    }

    if n_extra > 0:
        def _collect_da(d, base4, lam):
            out = DA(0.0)
            for full_key, val in d.items():
                if full_key[:4] != base4:
                    continue
                extra = full_key[4:]
                coef = (val / lam).imag / (2 * np.pi)
                exponents = [0, 0, 0, 0] + list(extra)
                out.setCoefficient(exponents, coef)
            return out

        result['dnux_dJx_da'] = _collect_da(c3_z1, (2, 1, 0, 0), lam1)
        result['dnux_dJy_da'] = _collect_da(c3_z1, (1, 0, 1, 1), lam1)
        result['dnuy_dJx_da'] = _collect_da(c3_z2, (1, 1, 1, 0), lam2)
        result['dnuy_dJy_da'] = _collect_da(c3_z2, (0, 0, 2, 1), lam2)

    return result, cur
