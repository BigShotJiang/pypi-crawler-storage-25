"""3D (6-variable) complex-variable normal form via per-plane homological elimination.

Extends the 2D (4-variable) pipeline in complex_nf_2d.py to three degrees
of freedom. For 3 DOF with stable (rotational) linear normal form, the
Courant-Snyder transformation makes each pair (u_i, pu_i) a rotation at
angle mu_i. In the complex basis z_i = (u_i - i pu_i)/sqrt(2) the linear
map is z_i -> lam_i z_i with lam_i = exp(i mu_i).

Resonance condition for plane j: for a monomial
    z1^k1 z1*^l1 z2^k2 z2*^l2 z3^k3 z3*^l3
to be resonant in z_j' we need
    k_i - l_i = delta_{ij}    for all i.

At order n (transverse order = sum of k_i + l_i) the non-resonant
monomials are eliminated by
    g_zj_{full_key} = -R_zj_{full_key} / (lam_j - prod_i lam_i^{k_i} conj(lam_i)^{l_i}).
"""
import numpy as np
from math import comb
from daceypy import DA


def _real_to_complex_1pair(a, b):
    """Expand u^a pu^b in (z, z*) for one DOF."""
    n = a + b
    sq2n = np.sqrt(2) ** n
    result = {}
    for r in range(a + 1):
        for s in range(b + 1):
            k = r + s
            l = (a - r) + (b - s)
            coeff = ((1j) ** b / sq2n
                     * comb(a, r) * comb(b, s) * (-1) ** (b - s))
            key = (k, l)
            result[key] = result.get(key, 0.0) + coeff
    return result


def real_to_complex_monomial_3d(a, b, c, d, e, f):
    """Expand u1^a pu1^b u2^c pu2^d u3^e pu3^f in complex (k1..l3)."""
    pair1 = _real_to_complex_1pair(a, b)
    pair2 = _real_to_complex_1pair(c, d)
    pair3 = _real_to_complex_1pair(e, f)
    result = {}
    for (k1, l1), c1 in pair1.items():
        for (k2, l2), c2 in pair2.items():
            for (k3, l3), c3 in pair3.items():
                key = (k1, l1, k2, l2, k3, l3)
                result[key] = result.get(key, 0.0) + c1 * c2 * c3
    return result


def _complex_to_real_1pair(k, l):
    """Express z^k z*^l in (u, pu) for one DOF."""
    n = k + l
    sq2n = np.sqrt(2) ** n
    result = {}
    for r in range(k + 1):
        for s in range(l + 1):
            a = r + s
            b = (k - r) + (l - s)
            coeff = (1.0 / sq2n
                     * comb(k, r) * (-1j) ** (k - r)
                     * comb(l, s) * (1j) ** (l - s))
            key = (a, b)
            result[key] = result.get(key, 0.0) + coeff
    return result


def complex_to_real_monomial_3d(k1, l1, k2, l2, k3, l3):
    """Express z1^k1 z1*^l1 z2^k2 z2*^l2 z3^k3 z3*^l3 in real (a,b,c,d,e,f)."""
    pair1 = _complex_to_real_1pair(k1, l1)
    pair2 = _complex_to_real_1pair(k2, l2)
    pair3 = _complex_to_real_1pair(k3, l3)
    result = {}
    for (a, b), c1 in pair1.items():
        for (c, d), c2 in pair2.items():
            for (e, f), c3 in pair3.items():
                key = (a, b, c, d, e, f)
                result[key] = result.get(key, 0.0) + c1 * c2 * c3
    return result


def extract_complex_coefficients_3d(da_map, dof_index, order):
    """Extract complex z-coefficients for z_{dof_index} at given transverse order.

    Returns dict whose keys are (k1, l1, k2, l2, k3, l3, *extra). For a
    6-variable DA, keys are length-6 tuples. If the DA carries additional
    passive parameters, their exponents are appended. Transverse order
    is the sum of the first six exponents.
    """
    j = 2 * dof_index
    da_u = da_map[j]
    da_pu = da_map[j + 1]
    nvar = DA.getMaxVariables()
    result = {}
    for da_comp, multiplier in [(da_u, 1.0 / np.sqrt(2)),
                                 (da_pu, -1j / np.sqrt(2))]:
        for mono in da_comp.getMonomials():
            jj = mono.m_jj
            a, b, c, d, e, f = jj[0], jj[1], jj[2], jj[3], jj[4], jj[5]
            if a + b + c + d + e + f != order:
                continue
            extra = tuple(jj[i] for i in range(6, nvar))
            real_coeff = mono.m_coeff.value
            expansion = real_to_complex_monomial_3d(a, b, c, d, e, f)
            for key, conv_coeff in expansion.items():
                full_key = key + extra
                result[full_key] = result.get(full_key, 0j) + multiplier * real_coeff * conv_coeff
    return result


def _build_real_generating_function_3d(g_z_per_plane):
    """Convert complex generating functions (one dict per plane) to real DA g[i].

    g_z_per_plane: list of 3 dicts, each keyed by (k1,l1,k2,l2,k3,l3,*extra),
    corresponding to z1, z2, z3 plane generators.
    """
    g = [DA(0.0) for _ in range(6)]

    for plane_idx, g_complex in enumerate(g_z_per_plane):
        j = 2 * plane_idx
        for full_key, c_kl in g_complex.items():
            k1, l1, k2, l2, k3, l3 = full_key[:6]
            extra = full_key[6:]
            real_exp = complex_to_real_monomial_3d(k1, l1, k2, l2, k3, l3)
            for (a, b, c, d, e, f), real_coeff in real_exp.items():
                full_coeff = c_kl * real_coeff
                exponents = [a, b, c, d, e, f] + list(extra)
                cur_u = g[j].getCoefficient(exponents)
                g[j].setCoefficient(exponents, cur_u + np.sqrt(2) * full_coeff.real)
                cur_pu = g[j + 1].getCoefficient(exponents)
                g[j + 1].setCoefficient(exponents, cur_pu - np.sqrt(2) * full_coeff.imag)

    return g


def compute_detuning_3d(da_map, tunes):
    """Compute the 3-DOF detuning coefficients via per-plane homological elimination.

    Parameters
    ----------
    da_map : list of DA (length 6)
        [u1', pu1', u2', pu2', u3', pu3'] in Floquet coordinates.
    tunes : array-like, length 3
        [nu1, nu2, nu3] fractional tunes.

    Returns
    -------
    detuning : dict with keys 'dnu{k}_dJ{l}' and, if passive parameters
               exist, 'dnu{k}_dJ{l}_da' DA polynomials.
    nf_map : list of DA (length 6)
    """
    mu = [2 * np.pi * t for t in tunes]
    lam = [np.exp(1j * m) for m in mu]
    order = DA.getMaxOrder()
    nvar = DA.getMaxVariables()
    n_extra = max(0, nvar - 6)

    cur = [DA(m) for m in da_map]

    # Multi-pass iteration at each transverse order to handle linear
    # chromatic residuals if any extra parameters are present.
    max_passes = 4 * order + 4 if n_extra > 0 else 2

    for n in range(2, order + 1):
        for _pass in range(max_passes):
            R_list = [extract_complex_coefficients_3d(cur, j, n) for j in range(3)]

            if not any(R_list):
                break

            g_list = [{} for _ in range(3)]
            for plane, R in enumerate(R_list):
                lam_plane = lam[plane]
                for full_key, f in R.items():
                    k1, l1, k2, l2, k3, l3 = full_key[:6]
                    mon = (lam[0] ** k1 * np.conj(lam[0]) ** l1
                           * lam[1] ** k2 * np.conj(lam[1]) ** l2
                           * lam[2] ** k3 * np.conj(lam[2]) ** l3)
                    divisor = lam_plane - mon
                    if abs(divisor) > 1e-10:
                        g_list[plane][full_key] = -f / divisor

            if not any(g_list):
                break

            max_g = 0.0
            for g in g_list:
                for v in g.values():
                    if abs(v) > max_g:
                        max_g = abs(v)
            if max_g < 1e-12:
                break

            g_real = _build_real_generating_function_3d(g_list)

            v_da = [DA(i + 1) for i in range(6)]
            T = [v_da[i] + g_real[i] for i in range(6)]
            extra_vars = [DA(k + 1) for k in range(6, nvar)]
            T_full = T + extra_vars

            Tinv = [DA(v_da[i]) for i in range(6)]
            for _ in range(order):
                Tinv_full = Tinv + extra_vars
                Tinv = [v_da[i] - g_real[i].eval(Tinv_full) for i in range(6)]

            MoT = [cur[i].eval(T_full) for i in range(6)]
            MoT_full = MoT + extra_vars
            cur = [Tinv[i].eval(MoT_full) for i in range(6)]

    # Extract order-3 coefficients (first-order detuning)
    c3 = [extract_complex_coefficients_3d(cur, j, 3) for j in range(3)]

    def _scalar(d, base6):
        key = base6 + (0,) * n_extra
        return d.get(key, 0j)

    # dnu_i/dJ_j comes from the (k1..l3) monomial where plane i is the
    # "self" (k_i=1, l_i=1-delta_{i=self_j}) times plane j as action (k_j=1, l_j=1)
    # For plane i self-detuning: resonant monomial is delta_{ik}=1, k_j-l_j=0 for others.
    # The coefficient of "z_i self times J_j" is at:
    #   (k1..l3) with k_i=1+delta_{ij}, l_i=delta_{ij}, k_j=l_j=(1-delta_{ij}) for j!=i? confusing.

    # For plane i=1, 2, 3: dnu_i/dJ_j is captured by the resonant monomial
    # z_i * J_j = z_i * z_j * z_j* (if j!=i) or z_i * z_i * z_i* (if j==i).
    # Keys (k1,l1,k2,l2,k3,l3):
    #   dnu_1/dJ_1: (2,1,0,0,0,0)
    #   dnu_1/dJ_2: (1,0,1,1,0,0)
    #   dnu_1/dJ_3: (1,0,0,0,1,1)
    #   dnu_2/dJ_1: (1,1,1,0,0,0)
    #   dnu_2/dJ_2: (0,0,2,1,0,0)
    #   dnu_2/dJ_3: (0,0,1,0,1,1)
    #   dnu_3/dJ_1: (1,1,0,0,1,0)
    #   dnu_3/dJ_2: (0,0,1,1,1,0)
    #   dnu_3/dJ_3: (0,0,0,0,2,1)
    # Use plane indices 1..3 directly; callers resolve labels via self.tunes
    # Key (pi, pj): pi = plane the tune is from (1..3), pj = which J factor.
    # Monomial has k_pi - l_pi = 1 (resonance for plane pi) and k_pj = l_pj = 1
    # for j != i (amplitude factor), or k_i = 2, l_i = 1 for the self-case.
    detuning_keys = {
        (1, 1): (2, 1, 0, 0, 0, 0), (1, 2): (1, 0, 1, 1, 0, 0), (1, 3): (1, 0, 0, 0, 1, 1),
        (2, 1): (1, 1, 1, 0, 0, 0), (2, 2): (0, 0, 2, 1, 0, 0), (2, 3): (0, 0, 1, 0, 1, 1),
        (3, 1): (1, 1, 0, 0, 1, 0), (3, 2): (0, 0, 1, 1, 1, 0), (3, 3): (0, 0, 0, 0, 2, 1),
    }

    result = {}
    for (plane_i, plane_j), key in detuning_keys.items():
        c = _scalar(c3[plane_i - 1], key)
        val = (c / lam[plane_i - 1]).imag / (2 * np.pi)
        result[f'dnu{plane_i}_dJ{plane_j}'] = val
        # Also emit xyl labels assuming sort order = (x, y, l) (common in FFAG
        # where x-tune > y-tune > s-tune after folding). Callers should
        # prefer the numeric keys for unambiguous interpretation.
        label_i = ['x', 'y', 'l'][plane_i - 1]
        label_j = ['x', 'y', 'l'][plane_j - 1]
        result[f'dnu{label_i}_dJ{label_j}'] = val

    # Second-order mixed detuning: d^2 nu_i / (dJ_j dJ_k)
    # Comes from order-5 resonant monomials.
    # d^2 nu_i / (dJ_j dJ_k) for j != k coupling: key has k_i=1+delta_{ij or ik}, ...
    # Specifically for i, j, k all different:
    #   resonant: k_i-l_i=1, (k_other - l_other)=0 for the two other planes
    #   amplitude factor J_j * J_k = (z_j z_j*)(z_k z_k*), so k_j=l_j=1 and k_k=l_k=1.
    # For d^2 nu_y / (dJ_y dJ_l) (i=2, j=2, k=3):
    #   k_i=2+1=3? no wait. For d^2 nu_y / (dJ_y dJ_l): ν_y has J_y × J_l term.
    #   The MAP coefficient of z_y * J_y * J_l in z_y' (so plane i=2, z_i * J_2 * J_3):
    #   = z_2^{1+1=2} z_2*^1 z_3 z_3*. Key (0,0,2,1,1,1).
    # Extract at order 5.
    c5 = [extract_complex_coefficients_3d(cur, j, 5) for j in range(3)]

    cross_keys = {
        # d^2 nu_y / (dJ_y dJ_l) for plane i=2 (y):
        ('y', 'y', 'l'): (0, 0, 2, 1, 1, 1),
        ('y', 'l', 'l'): (0, 0, 1, 0, 2, 2),
        ('y', 'y', 'y'): (0, 0, 3, 2, 0, 0),
        ('y', 'x', 'l'): (1, 1, 1, 0, 1, 1),
        ('y', 'x', 'y'): (1, 1, 2, 1, 0, 0),
        ('y', 'x', 'x'): (2, 2, 1, 0, 0, 0),
        # d^2 nu_x / (...):
        ('x', 'x', 'x'): (3, 2, 0, 0, 0, 0),
        ('x', 'y', 'y'): (1, 0, 2, 2, 0, 0),
        ('x', 'l', 'l'): (1, 0, 0, 0, 2, 2),
        ('x', 'x', 'l'): (2, 1, 0, 0, 1, 1),
        ('x', 'x', 'y'): (2, 1, 1, 1, 0, 0),
        ('x', 'y', 'l'): (1, 0, 1, 1, 1, 1),
    }
    plane_idx = {'x': 0, 'y': 1, 'l': 2}
    for (plane_i, pj, pk), key in cross_keys.items():
        pi = plane_idx[plane_i]
        c = _scalar(c5[pi], key)
        val = (c / lam[pi]).imag / (2 * np.pi)
        result[f'd2nu{plane_i}_dJ{pj}_dJ{pk}'] = val
        # Also emit by numeric plane index for unambiguous access
        pi1 = pi + 1
        pj1 = plane_idx[pj] + 1
        pk1 = plane_idx[pk] + 1
        result[f'd2nu{pi1}_dJ{pj1}_dJ{pk1}'] = val

    return result, cur
