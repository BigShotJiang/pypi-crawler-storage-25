# kongming_rs — backwards compatibility shim
#
# New code should use: from kongming import hv
# This module will be removed in a future release.
import warnings as _warnings

_warnings.warn(
    "Import from 'kongming' instead of 'kongming_rs'. This alias will be removed in a future release.",
    DeprecationWarning,
    stacklevel=2,
)

from .kongming_rs import (  # noqa: F401, E402
    REASON_NOT_FOUND,
    HvError,
    __version__,
    hv,
)
