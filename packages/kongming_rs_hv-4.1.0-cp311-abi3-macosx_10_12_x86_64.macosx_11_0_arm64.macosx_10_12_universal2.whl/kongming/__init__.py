# kongming — top-level import path for kongming-rs-hv
#
# The native extension lives in kongming_rs (PyO3). This package
# re-exports everything so users can write:
#   from kongming import hv
#   from kongming import memory
from enum import IntEnum

from kongming_rs import (  # noqa: F401
    REASON_NOT_FOUND,
    HvError,
    __version__,
    hv,
)

try:
    from kongming_rs import memory  # noqa: F401
except ImportError:
    pass  # memory module may not be available in minimal builds

try:
    from kongming_rs import lisp  # noqa: F401
except ImportError:
    pass


def _promote_enum(prefix: str, enum_name: str) -> None:
    """Replace bare-int constants on `hv` with IntEnum members of the same name.

    The native `hv` module exposes constants like ``MODEL_64K_8BIT`` as plain
    ints. This shim wraps each prefixed group into an ``IntEnum`` class
    (e.g. ``hv.Model``) and rebinds every constant on the module to the
    corresponding enum member. Names stay identical, existing code keeps
    working, and ``isinstance(hv.MODEL_64K_8BIT, IntEnum)`` is now ``True``.
    """
    members = {
        name: getattr(hv, name)
        for name in dir(hv)
        if name.startswith(prefix) and isinstance(getattr(hv, name), int) and not isinstance(getattr(hv, name), bool)
    }
    if not members:
        return
    cls = IntEnum(enum_name, members)
    cls.__module__ = "kongming.hv"
    setattr(hv, enum_name, cls)
    for member in cls:
        setattr(hv, member.name, member)


_promote_enum("MODEL_", "Model")
_promote_enum("PREWIRED_", "Prewired")
_promote_enum("HINT_", "Hint")
_promote_enum("DOMAIN_PREFIX_", "DomainPrefix")

del _promote_enum
