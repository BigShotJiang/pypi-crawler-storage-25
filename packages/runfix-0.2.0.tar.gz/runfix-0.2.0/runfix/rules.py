import re
import sys
import difflib
from . import messages

STD_LIBS = ["os", "sys", "json", "re", "math", "time", "datetime", "random", "subprocess", "requests", "pandas",
            "numpy"]


class ErrorHandler:


    def match(self, err_type, msg, file, line):
        return False

    def resolve(self, msg, file, line, lang):
        return None, {}, None



class MissingPackageRule(ErrorHandler):
    def match(self, err_type, msg, file, line):
        return err_type == "ModuleNotFoundError"

    def resolve(self, msg, file, line, lang):
        m = re.search(r"named '([^']+)'", msg)
        pkg = m.group(1) if m else "unknown"
        return "cmd", {"cmd": f"pip install {pkg}"}, messages.get(lang, "rule_missing_pkg", pkg=pkg)


class FileNotFoundRule(ErrorHandler):
    def match(self, err_type, msg, file, line):
        return "[Errno 2] No such file or directory" in msg or err_type == "FileNotFoundError"

    def resolve(self, msg, file, line, lang):
        m1 = re.search(r"can't open file '([^']+)':", msg)
        m2 = re.search(r"No such file or directory: '([^']+)'", msg)
        target = m1.group(1) if m1 else (m2.group(1) if m2 else None)

        if target:
            return "create", {"target": target}, messages.get(lang, "rule_create_file", f=target)
        return None, {}, None


class NameErrorRule(ErrorHandler):
    def match(self, err_type, msg, file, line):
        return err_type == "NameError" and file

    def resolve(self, msg, file, line, lang):
        m = re.search(r"name '([^']+)' is not defined", msg)
        if not m: return None, {}, None
        var = m.group(1)


        if var in STD_LIBS:
            return "edit", {"file": file, "mode": "import", "val": var}, messages.get(lang, "rule_import", lib=var)


        if sys.version_info >= (3, 10):
            sug_m = re.search(r"Did you mean: '([^']+)'", msg)
            if sug_m:
                closest = sug_m.group(1)
                return "edit", {"file": file, "mode": "typo", "line": line, "old": var, "new": closest}, messages.get(
                    lang, "rule_typo", line=line, wrong=var, right=closest)


        try:
            with open(file, "r", encoding="utf-8") as f:
                words = re.findall(r'\w+', f.read())
            words = [w for w in words if w != var]  # Yanlış kelimeyi listeden çıkar
            closest = difflib.get_close_matches(var, set(words), n=1)
            if closest:
                return "edit", {"file": file, "mode": "typo", "line": line, "old": var,
                                "new": closest[0]}, messages.get(lang, "rule_typo", line=line, wrong=var,
                                                                 right=closest[0])
        except:
            pass

        return None, {}, None


class IndentationRule(ErrorHandler):
    def match(self, err_type, msg, file, line):
        return err_type in ["IndentationError", "TabError"] and file and line

    def resolve(self, msg, file, line, lang):
        return "edit", {"file": file, "mode": "indent", "line": line}, messages.get(lang, "rule_indent", line=line)



HANDLERS = [
    MissingPackageRule(),
    FileNotFoundRule(),
    NameErrorRule(),
    IndentationRule()
]


def resolve(info, lang):
    err = info.get("type")
    msg = info.get("msg")
    file = info.get("file")
    line = info.get("line")

    for handler in HANDLERS:
        if handler.match(err, msg, file, line):
            action, payload, note = handler.resolve(msg, file, line, lang)
            if action:
                return action, payload, note


    return None, {}, messages.get(lang, "rule_unknown")