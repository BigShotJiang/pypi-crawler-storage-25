import subprocess
from . import messages


def smart_parse(args, lang):
    if not args: return ""
    first = args[0]

    cmaps = {".py": "python", ".js": "node", ".sh": "bash"}
    for ext, cmd in cmaps.items():
        if first.endswith(ext):
            print(messages.get(lang, "smart_run", ext=ext, cmd=cmd))
            args.insert(0, cmd)
            break

    return " ".join(args)


def exec_cmd(cmd):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        return {"out": p.stdout, "err": p.stderr, "code": p.returncode}
    except Exception as e:
        return {"out": "", "err": str(e), "code": 1}