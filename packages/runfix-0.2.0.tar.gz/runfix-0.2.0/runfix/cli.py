import argparse
import sys
from . import config, runner, parser, rules, fixer, messages


def main():
    lang = config.check_first_run()
    cfg = config.load()
    use_c = cfg.get("color", True)

    epi = """
Examples:
  runfix run app.py           (Auto-detects and runs 'python app.py')
  runfix config --auto-fix on (Applies code fixes instantly)
"""

    p = argparse.ArgumentParser(prog="runfix", description=messages.get(lang, "desc"),
                                formatter_class=argparse.RawTextHelpFormatter, epilog=epi)
    p.add_argument('-v', '--version', action='version', version='runfix 0.2.0')
    sub = p.add_subparsers(dest="cmd")

    run_p = sub.add_parser("run", help="Run a command or file")
    run_p.add_argument("target", nargs='+', help="Target file/command")

    cfg_p = sub.add_parser("config", help="Manage settings")
    cfg_p.add_argument("--lang", choices=["tr", "en"])
    cfg_p.add_argument("--auto-fix", choices=["on", "off"])
    cfg_p.add_argument("--color", choices=["on", "off"])

    args = p.parse_args()
    if not args.cmd:
        p.print_help()
        return

    if args.cmd == "config":
        if args.lang: config.save("lang", args.lang)
        if args.auto_fix: config.save("auto_fix", args.auto_fix == "on")
        if args.color: config.save("color", args.color == "on")

        print("\n[i] Current config:")
        for k, v in config.load().items(): print(f"  {k} = {v}")
        return

    if args.cmd == "run":
        full_cmd = runner.smart_parse(args.target, lang)
        res = runner.exec_cmd(full_cmd)

        if res["code"] == 0:
            if res["out"]: print(res["out"])
            sys.exit(0)

        info = parser.parse_err(res["err"])
        action, payload, note = rules.resolve(info, lang)

        red = "\033[91m" if use_c else ""
        rst = "\033[0m" if use_c else ""

        print(f"{red}{messages.get(lang, 'err_title', type=info['type'])}{rst}")
        print(messages.get(lang, "err_msg", msg=info['msg']))
        print(messages.get(lang, "err_note", note=note))

        if action: fixer.apply(action, payload, lang)


if __name__ == "__main__": main()