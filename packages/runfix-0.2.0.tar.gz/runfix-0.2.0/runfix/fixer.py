import subprocess
import os
import shutil
import re
from . import messages, config

C = {"G": "\033[92m", "R": "\033[91m", "Y": "\033[93m", "0": "\033[0m"}


def backup(f):
    if os.path.exists(f): shutil.copy(f, f + ".bak")


def apply(action, payload, lang):
    cfg = config.load()
    use_color = cfg.get("color", True)

    print(C["Y"] if use_color else "", end="")
    if cfg.get("auto_fix"):
        print(messages.get(lang, "auto_fix"))
        do_it = True
    else:
        ans = input(messages.get(lang, "ask_fix"))
        do_it = ans.lower() == 'y'
    print(C["0"] if use_color else "", end="")

    if not do_it: return

    try:
        if action == "cmd":
            subprocess.run(payload["cmd"], shell=True, check=True)

        elif action == "create":
            path = payload["target"]
            d = os.path.dirname(path)
            if d: os.makedirs(d, exist_ok=True)
            open(path, 'w').close()

        elif action == "edit":
            f_path = payload["file"]
            backup(f_path)
            with open(f_path, "r") as f:
                lines = f.readlines()

            mode = payload["mode"]
            if mode == "import":
                lines.insert(0, f"import {payload['val']}\n")

            elif mode == "typo":
                idx = payload["line"] - 1
                lines[idx] = re.sub(rf"\b{payload['old']}\b", payload["new"], lines[idx])

            elif mode == "indent":
                idx = payload["line"] - 1
                prev = idx - 1
                while prev >= 0 and not lines[prev].strip(): prev -= 1
                if prev >= 0:
                    indent = len(lines[prev]) - len(lines[prev].lstrip())
                    if lines[prev].strip().endswith(":"): indent += 4
                    lines[idx] = (" " * indent) + lines[idx].lstrip()

            with open(f_path, "w") as f:
                f.writelines(lines)

        msg = messages.get(lang, "fix_ok")
        print(f"{C['G']}{msg}{C['0']}" if use_color else msg)

    except Exception as e:
        msg = messages.get(lang, "fix_err")
        print(f"{C['R']}{msg} ({e}){C['0']}" if use_color else msg)