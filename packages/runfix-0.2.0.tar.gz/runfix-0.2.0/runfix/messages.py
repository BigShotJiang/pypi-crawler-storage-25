TEXTS = {
    "tr": {
        "desc": "Komut hatalarını yakalar, analiz eder ve kodu tamir eder.",
        "first_run": "\n🚀 runfix'e hoş geldin! Hızlıca ayarlarımızı yapalım.",
        "smart_run": "[+] Smart Detect: {ext} dosyası -> '{cmd}'",
        "err_title": "\n[!] Hata: {type}",
        "err_msg": "[-] Mesaj: {msg}",
        "err_note": "[*] Çözüm: {note}",
        "ask_fix": "\n? Uygulayalım mı? [y/N]: ",
        "auto_fix": "[+] Auto-fix devrede, uygulanıyor...",
        "fix_ok": "[✓] İşlem tamamlandı!",
        "fix_err": "[X] Bir şeyler ters gitti.",

        "rule_missing_pkg": "'{pkg}' kütüphanesi eksik. Pip ile kuralım mı?",
        "rule_create_file": "'{f}' dosyası yok. Senin için boş bir tane oluşturayım mı?",
        "rule_import": "'{lib}' import edilmemiş. Dosyanın en üstüne ekleyelim mi?",
        "rule_typo": "Satır {line}'de '{wrong}' yazmışsın, doğrusu '{right}' olabilir mi? Düzelteyim mi?",
        "rule_indent": "Satır {line}'de boşluk/hizalama hatası var. Otomatik hizalayayım mı?",
        "rule_unknown": "Bu hataya henüz bir çözüm yazmadım."
    },
    "en": {
        "desc": "Intercepts command errors, analyzes, and fixes your code.",
        "first_run": "\n🚀 Welcome to runfix! Let's set things up.",
        "smart_run": "[+] Smart Detect: {ext} file -> '{cmd}'",
        "err_title": "\n[!] Error: {type}",
        "err_msg": "[-] Message: {msg}",
        "err_note": "[*] Fix: {note}",
        "ask_fix": "\n? Apply this? [y/N]: ",
        "auto_fix": "[+] Auto-fix enabled, applying...",
        "fix_ok": "[✓] All done!",
        "fix_err": "[X] Something went wrong.",

        "rule_missing_pkg": "Package '{pkg}' is missing. Install via pip?",
        "rule_create_file": "File '{f}' not found. Create an empty one?",
        "rule_import": "'{lib}' is missing. Add import to the top of the file?",
        "rule_typo": "Typo at line {line}: '{wrong}'. Did you mean '{right}'? Fix it?",
        "rule_indent": "Indentation error at line {line}. Auto-align it?",
        "rule_unknown": "No fix available for this error yet."
    }
}


def get(lang, key, **kwargs):
    t = TEXTS.get(lang, TEXTS["en"]).get(key, TEXTS["en"].get(key, key))
    if kwargs: return t.format(**kwargs)
    return t