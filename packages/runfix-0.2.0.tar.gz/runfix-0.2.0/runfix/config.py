import json
import os
import sys

SETTINGS_FILE = os.path.expanduser("~/.runfix_settings.json")
DEFAULT = {"lang": "en", "auto_fix": False, "color": True}


def load():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                return {**DEFAULT, **json.load(f)}
        except:
            pass
    return DEFAULT


def save(key, value):
    s = load()
    s[key] = value
    with open(SETTINGS_FILE, "w") as f:
        json.dump(s, f)


def check_first_run():
    if not os.path.exists(SETTINGS_FILE):
        print("\n🚀 Welcome to runfix! / runfix'e hoş geldin!")
        l = input("? Dil / Language [tr/en] (def: en): ").strip().lower()
        lang = "tr" if l == "tr" else "en"

        a = input("? Otomatik tamir edilsin mi? / Enable auto-fix? [y/N]: ").strip().lower()
        auto = a == 'y'

        c = input("? Renkli çıktı? / Enable colors? [Y/n]: ").strip().lower()
        color = c != 'n'

        save("lang", lang)
        save("auto_fix", auto)
        save("color", color)

        print(f"\n✅ All set! Type 'runfix --help' to see what you can do.\n")
        sys.exit(0)

    return load().get("lang", "en")