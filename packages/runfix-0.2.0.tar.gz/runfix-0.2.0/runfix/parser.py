import re


def parse_err(stderr):
    if not stderr:
        return {"type": "Unknown", "msg": "", "file": None, "line": None}

    tb = re.findall(r'File "([^"]+)", line (\d+)', stderr)
    f_path, line_no = tb[-1] if tb else (None, None)

    match = re.search(r"(\w+Error): (.+)", stderr)
    if match:
        return {
            "type": match.group(1),
            "msg": match.group(2).strip(),
            "file": f_path,
            "line": int(line_no) if line_no else None
        }

    lines = [l for l in stderr.strip().split('\n') if l.strip()]
    return {"type": "RuntimeError", "msg": lines[-1] if lines else "", "file": f_path, "line": line_no}