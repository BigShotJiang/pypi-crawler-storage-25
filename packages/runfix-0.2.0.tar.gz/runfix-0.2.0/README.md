# 🛠️ runfix

Stop googling errors. Let `runfix` do the dirty work. 

A lightweight, smart CLI tool that executes commands, intercepts errors, and actively **fixes your code** so you can stay in the flow.

[🇹🇷 Türkçe döküman için buraya tıklayın.](README.TR.MD)

---

## 🚀 Overview

`runfix` is not just an error formatter; it's your local terminal copilot. Instead of manually copying tracebacks to search for solutions, `runfix` analyzes `stderr` and offers active fixes—from installing missing packages to repairing typos and indentations directly in your Python scripts.

## ✨ Key Features

- **🧠 Smart Execution:** Auto-detects file types. Just type `runfix run app.py` and it knows to run `python app.py`. (Also supports `.js` and `.sh`).
- **🔧 Active Code Fixer:** - 📦 Missing a library? It prompts to run `pip install`.
  - 📝 Forgot to `import json`? It adds the import to the top of your file.
  - 🔤 Typo in a variable? It scans your file, finds the closest match, and replaces it.
  - 📑 Indentation broken? It auto-aligns the broken line based on context.
- **🛡️ Safe by Design:** Before altering any of your source code, it automatically creates a `.bak` backup file.
- **🪄 First-Run Wizard:** Setup your language, color preferences, and auto-fix rules on the first run.
- **⚡ Minimalist:** Zero heavy dependencies. Pure Python power.

## 📦 Installation

Grab the latest version directly from PyPI:

```bash
pip install --upgrade runfix
 ```
And Setup with:
```bash
runfix
```
## 💡 Quick Start
Simply wrap your target file with `runfix run`:
```bash
runfix run my_script.py
```
If it fails, `runfix` catches the error and offers a fix:
```bash
[+] Smart Detect: .py file -> 'python'

[!] Error: NameError
[-] Message: name 'jsn' is not defined
[*] Fix: Typo at line 12: 'jsn'. Did you mean 'json'? Fix it?

? Apply this? [y/N]: y
-> Applying fix...
[✓] All done!
```

## ⚙️ Configuration
Don't want to confirm every fix? Turn on auto-fix to let `runfix` apply solutions instantly:
```bash
runfix config --auto-fix on
```
Change the output language to supported languages like Turkish:
```bash
runfix config --lang tr
```
Disable colorful output:
```bash
runfix config --color off
```
## 📜 License
Distributed under the MIT License. See `LICENSE` for more information.