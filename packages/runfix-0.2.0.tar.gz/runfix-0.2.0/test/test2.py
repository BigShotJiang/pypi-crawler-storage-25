sayac = 10
print(sayac)