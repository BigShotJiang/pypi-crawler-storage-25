def karsilama():
    print("runfix hizalama testini geçti!")