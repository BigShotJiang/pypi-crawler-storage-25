# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD 3-Clause license found in the
# LICENSE file in the root directory of this source tree.

"""
FP8 attention using FA3 backend.
"""

from torchao.prototype.attention.fp8_fa3.attention import (
    fp8_fa3_rope_sdpa,
    fp8_fa3_sdpa,
)
from torchao.prototype.attention.quantization import _fp8_sdpa_quantize

__all__ = [
    "fp8_fa3_sdpa",
    "fp8_fa3_rope_sdpa",
    "_fp8_sdpa_quantize",
]
