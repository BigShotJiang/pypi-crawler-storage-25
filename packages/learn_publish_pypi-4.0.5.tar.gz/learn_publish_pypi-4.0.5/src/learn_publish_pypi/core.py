def greet(name: str) -> str:
    normalized = name.strip() or "world"
    return f"Hello, {normalized}!"

def bye(name: str) -> str:
    normalized = name.strip() or "world"
    return f"Goodbye, {normalized}!"