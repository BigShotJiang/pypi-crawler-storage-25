from importlib.metadata import PackageNotFoundError, version

from .core import greet

try:
    __version__ = version("learn-publish-pypi")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["greet", "__version__"]
