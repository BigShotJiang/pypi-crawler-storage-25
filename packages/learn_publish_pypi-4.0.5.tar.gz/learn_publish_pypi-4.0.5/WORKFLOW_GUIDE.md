# Python Publish Workflow Guide

This project uses GitHub Actions to create releases and publish to PyPI automatically.

## What this workflow does

File: `.github/workflows/python-publish.yml`

It runs on:
- Push to any branch
- Manual run (`workflow_dispatch`)

Main flow:
1. `release` job
- Builds a version string in `4.x.x` format.
- Creates a Git tag with the same value (for example `4.0.125`).
- Creates a GitHub Release only when allowed by branch/toggle rules.

2. `build` job
- Builds wheel and source distribution.
- Forces package version to match the release version.
- Fails if a `dev` artifact appears.

3. `publish` job
- Publishes built artifacts to PyPI using Trusted Publishing only from `main`.

## Branch policy (exact behavior)

This is controlled by `ENABLE_NON_MAIN_PRERELEASE` in the workflow YAML.

Default in workflow:

```yaml
env:
	ENABLE_NON_MAIN_PRERELEASE: "false"
```

Rules:
- If branch is `main`: always create normal release and publish to PyPI.
- If branch is NOT `main` and toggle is `false`: do not create release, do not publish to PyPI.
- If branch is NOT `main` and toggle is `true`: create GitHub pre-release, do not publish to PyPI.

This matches your requested behavior:
- `main`: release `4.x.x`
- non-main + `false`: no release
- non-main + `true`: pre-release only

## Version and tag format

Current format:
- Main release version: `4.0.<GITHUB_RUN_NUMBER>`
- Non-main pre-release version: `4.0.<GITHUB_RUN_NUMBER>rc<attempt>`
- Retry format: `4.0.<GITHUB_RUN_NUMBER>.post<attempt>`
- Tag: exactly same as version (no `v` prefix)

Examples:
- Main first run: `4.0.88`
- Main re-run same workflow: `4.0.88.post2`
- Non-main with prerelease enabled: `4.0.89rc1`

Why `.postN` exists:
- PyPI does not allow uploading the same version twice.
- On workflow retry, `.postN` prevents duplicate upload errors.

## Branch examples

### Case 1: Main branch (production)
1. Push commit to `main`.
2. Workflow creates tag/release in GitHub.
3. Workflow publishes to PyPI.

### Case 2: Feature branch with default toggle (`false`)
1. Push commit to `two` (or any non-main branch).
2. No GitHub release/tag is created.
3. No PyPI publish occurs.

### Case 3: Feature branch with toggle set to `true`
1. Edit workflow and set `ENABLE_NON_MAIN_PRERELEASE: "true"`.
2. Push commit to `two` (or any non-main branch).
3. GitHub pre-release is created.
4. PyPI publish still does not happen.

## How to use it

### Normal release from `main`
1. Commit your changes.
2. Push to `main`.
3. Check Actions tab for `Publish Python Package`.
4. Confirm:
- GitHub tag created (`4.x.x`)
- GitHub Release created
- PyPI version published

### Optional pre-release from non-main branch
1. Set `ENABLE_NON_MAIN_PRERELEASE` to `"true"` in workflow.
2. Commit your changes in non-main branch.
3. Push branch and verify a GitHub pre-release is created.
4. Set toggle back to `"false"` when done testing.

## Required setup (must exist)

### GitHub
1. Workflow file in repository.
2. Environment named `pypi`.

### PyPI
1. Project created: `learn-publish-pypi`.
2. Trusted Publisher configured for this repository and workflow file.
3. Environment name in PyPI Trusted Publisher should match `pypi`.

No `PYPI_API_TOKEN` secret is needed when using Trusted Publishing.

## Common problems and fixes

### 1) GitHub Release not created
- Check `release` job logs.
- Ensure workflow has `permissions: contents: write` in `release` job.

### 2) PyPI upload failed with duplicate version
- This usually happens when uploading the exact same version again.
- Re-run generates `.postN`, which should resolve it.

### 3) Dev/pre-release version appears (`.dev`)
- Ensure `SETUPTOOLS_SCM_PRETEND_VERSION` is set in `build` job.
- Ensure `Validate release version` step passes.

### 4) Branch not publishing
- Confirm whether branch is `main`.
- Non-main branches never publish to PyPI in this workflow.
- Confirm `ENABLE_NON_MAIN_PRERELEASE` value if expecting pre-release.

## How to change from 4.0.x to 4.1.x

Edit this line in workflow:

```yaml
BASE_VERSION="4.0.${GITHUB_RUN_NUMBER}"
```

Change to:

```yaml
BASE_VERSION="4.1.${GITHUB_RUN_NUMBER}"
```

Commit and push. New releases will start using `4.1.x`.

## Recommended safe practice

- Keep `ENABLE_NON_MAIN_PRERELEASE` as `"false"` most of the time.
- Turn it `"true"` only when you intentionally want GitHub pre-releases from non-main.
- Merge to `main` for stable release + PyPI publish.
