# learn-publish-pypi

A minimal Python package that demonstrates automated publishing to PyPI from GitHub Actions when pushing to `main`.

## Installation

```bash
pip install learn-publish-pypi
```

## Quick usage

```python
from learn_publish_pypi import greet

print(greet("Ridwaan"))
```
