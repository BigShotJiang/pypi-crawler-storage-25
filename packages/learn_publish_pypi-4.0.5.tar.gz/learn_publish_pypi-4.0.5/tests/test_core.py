from learn_publish_pypi import greet


def test_greet_name() -> None:
    assert greet("Ridwaan") == "Hello, Ridwaan!"


def test_greet_blank_name() -> None:
    assert greet("   ") == "Hello, world!"

def test_bye_name() -> None:
    from learn_publish_pypi.core import bye
    assert bye("Ridwaan") == "Goodbye, Ridwaan!"
    
def test_bye_blank_name() -> None:
    from learn_publish_pypi.core import bye
    assert bye("   ") == "Goodbye, world!"
