"""A python library for degree calculations and conversions."""
from ._degrees import (Degree,
                       degree2radian,
                       radian2degree,
                       normalize,
                       DEGREE,
                       MINUTE,
                       SECOND)
from ._version import version_info
from sys import version_info as _version_info

if _version_info >= (3, 9):
    List = list
else:
    from typing import List  # pragma: no cover

__all__: List[str] = [
    'Degree',
    'degree2radian',
    'radian2degree',
    'normalize',
    'version_info',
    'DEGREE',
    'MINUTE',
    'SECOND'
]
del List
