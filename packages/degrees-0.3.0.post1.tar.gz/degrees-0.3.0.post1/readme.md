# degrees V0.3.0.post1
> # Note:
> # This is the only version that is stable and compatible with python 3.8.
> # The older versions are _NOT_ stable.

# Contents
* Introduction
* Importing
* Class
  * Degree
* Functions
  * degree2radian
  * radian2degree
  * normalize
* Changelog
# Introduction
### A python library for degree calculations and conversions.
> ### _Added in version 0.2:_ Supported `pickle`.
# Importing
### Just type `import degrees`.
# Class
- ## _class_ degrees.Degree(number)<br>_class_ degrees.Degree(degree_obj)<br>_class_ degrees.Degree(degree=0, minute=0, second=0)
  - ### Creating a Degree object

```python 
import degrees

print(degrees.Degree(1))  # 1°
print(degrees.Degree(2, 3, 4))  # 2°3'4"
print(degrees.Degree(1, second=2))  # 1°0'2"
print(degrees.Degree(1, 3))  # 1°3'
print(degrees.Degree(0, -1))  # -1'
print(degrees.Degree(1.5))  # 1°30'
print(degrees.Degree(2, -4))  # ValueError: if degree is not 0, minute and second must be positive integer
```

  - ### calculating:
    | `a + b`  | `a - b`        | `a * b`         | `a / b`   | `math.trunc(a)` |
    |----------|----------------|-----------------|-----------|-----------------|
    | `abs(a)` | `math.ceil(a)` | `math.floor(a)` | `a % b`   |                 |
    | `a // b` | `+a`           | `-a`            | `hash(a)` |                 |
     > _Added in version 0.1.7:_ Implemented the `math.trunc` function on the Degree objects.

  - ### conversions:
    | `int(a)` | `float(a)` | `str(a)` | `repr(a)` | `bool(a)` | `complex(a)` |
    |----------|------------|----------|-----------|-----------|--------------|
    > The `complex(degree_obj)` is different from `degree_obj.to_complex(length)`. The former returns
    `int(degree_obj)+0j`, but the latter returns `complex(length * cos(theta), length * sin(theta))`,
    `theta=degree2radian(degree_obj)`.

For example:
```python
import degrees
a = degrees.Degree(45)
print(complex(a))  # (45+0j)
print(a.to_complex(2 ** 0.5))  # about (1+1j)
```

  - ### comparisons:
    | `a >= b` | `a > b` | `a = b`  |
    |----------|---------|----------|
    | `a <= b` | `a < b` | `a != b` |

  - ### _staticmethod_ from_str(string)
     Return a degree object from a string. The **dms** characters should be **`°`, `'` and `"`**.
  - ### _staticmethod_ from_unicode(string)
     Similar to `from_str`, but the **dms** characters should be **`°`, `′` and `″`**.
     > _Added in version 0.1.10._
  - ### _staticmethod_ from_iter(iterable)
     Return a degree object from an iterable.
  - ### _property_ total_seconds
     The total seconds of a degree object.
  - ### deg
     The degree of a degree object(without sign).
  - ### min
     The minute of a degree object(without sign).
  - ### sec
     The second of a degree object(without sign).
  - ### sign
     The sign of a degree object.
  - ### to_complex(length: Union[int, float])
     Returns the complex number corresponding to `(angle=self, radius=length)`.
     > _Added in version 0.2.1._
  - ### _property_ dms
     A tuple of `(degree, minute, second)`.
   
   > ### Note
   > The attributes of Degree are read-only.
# Functions
## _def_ degree2radian(x: Degree, /)
   - Convert angle x from a degree object to radians.
## _def_ radian2degree(x: Union[int, float], /)
   - Convert angle x from radians to a degree object.
## _def_ normalize(x: Degree, /)
   - Be using for angle normalization.
# Version
## version_info
   - The version of this package, like
[`sys.version_info`](https://docs.python.org/3.14/library/sys.html#sys.version_info)
&larr; click for more info.
# Consts
## DEGREE<br>MINUTE<br>SECOND
   Equals to `°`, `′` and `″`.
# Changelog
   1. Nothing.
> ### Write in the end
> If you found the bug in the code, you can email me at `snake830@vip.163.com`. I am happy to receive the advice!
