# spawnhub

Instrument your AI agents and watch them live in [SpawnHub](https://spawnhub.ai).

```bash
pip install spawnhub
```

```python
from spawnhub import instrument

result = instrument(api_key="spwnhub_...")
# ... run your agents (LangChain, OpenAI Agents SDK, CrewAI, AutoGen, Google ADK) ...
result.force_flush()
```

Auto-detects the installed framework and configures telemetry accordingly.
