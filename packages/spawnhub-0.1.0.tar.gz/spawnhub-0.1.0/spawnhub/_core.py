"""
Core instrument() function — auto-detects installed AI frameworks and
configures SpawnHub telemetry for each one found.

OTEL-native frameworks (LangChain, CrewAI, AutoGen, Google ADK):
    A global TracerProvider with OTLPSpanExporter is configured.
    The framework picks it up automatically — no extra code needed.

OpenAI Agents SDK (no native OTEL):
    A SpawnHubTracingProcessor is injected into the SDK's trace system.
"""

from __future__ import annotations

import importlib
import logging

logger = logging.getLogger(__name__)


class InstrumentResult:
    """
    Returned by instrument(). Provides a framework-agnostic force_flush().

    Always call result.force_flush() after your top-level agent span closes
    to ensure all buffered spans/events reach SpawnHub before the process
    exits or the next run begins.
    """

    def __init__(self, provider=None, processor=None) -> None:
        self._provider  = provider   # TracerProvider (OTEL path)
        self._processor = processor  # SpawnHubTracingProcessor (OpenAI Agents path)

    def force_flush(self, timeout_ms: int = 10_000) -> None:
        """Flush all buffered telemetry to SpawnHub."""
        if self._provider is not None and hasattr(self._provider, "force_flush"):
            self._provider.force_flush(timeout_millis=timeout_ms)
        if self._processor is not None:
            self._processor.force_flush()


def _is_installed(package: str) -> bool:
    """Return True if a Python package is importable."""
    try:
        importlib.import_module(package)
        return True
    except ImportError:
        return False


def instrument(
    api_key: str = "",
    endpoint: str = "https://ingest.spawnhub.ai",
    service_name: str = "spawnhub-agent",
    pattern: str = "orchestrator",
    personas: dict[str, dict[str, str]] | None = None,
) -> InstrumentResult:
    """
    Instrument your AI agents to stream live telemetry to SpawnHub.

    Auto-detects installed frameworks and configures each one:
      - LangChain / LangGraph / CrewAI / AutoGen / Google ADK -> OTEL exporter
      - OpenAI Agents SDK -> SpawnHubTracingProcessor injection

    Args:
        api_key:      Tenant API key from the SpawnHub admin portal.
                      Optional for local development (omit or pass "").
        endpoint:     SpawnHub ingestion URL. Defaults to the hosted service.
                      Use "http://localhost:8000" for local development.
        service_name: OTEL service.name resource attribute.
        pattern:      Agentic pattern — drives the renderer theme.
                      One of: orchestrator | sequential | parallel |
                      conversational | reflection
        personas:     Optional map of agent_name -> persona dict for avatar styling.
                      Example: {"ResearchAgent": {"name": "Ibrahim", "country": "SA"}}

    Returns:
        InstrumentResult with a force_flush() method. Always call this after
        your top-level agent run completes.

    Examples:
        # Local development — no API key needed
        result = instrument(endpoint="http://localhost:8000")
        # ... run your agents ...
        result.force_flush()

        # Production
        result = instrument(
            api_key="spwnhub_abc123",
            pattern="orchestrator",
            personas={"Orchestrator": {"name": "Zara", "country": "AE"}},
        )
    """
    from ._otel import setup_otel

    # Always set up the OTEL provider — covers LangChain, LangGraph, CrewAI,
    # AutoGen, Google ADK, and any other OTEL-native framework.
    provider = setup_otel(endpoint=endpoint, api_key=api_key, service_name=service_name)

    # Additionally inject the OpenAI Agents processor if that SDK is installed.
    processor = None
    if _is_installed("agents"):
        processor = _inject_openai_processor(
            endpoint=endpoint,
            api_key=api_key,
            pattern=pattern,
            personas=personas,
        )

    detected = []
    if _is_installed("langchain"):
        detected.append("langchain")
    if _is_installed("langgraph"):
        detected.append("langgraph")
    if _is_installed("crewai"):
        detected.append("crewai")
    if _is_installed("autogen"):
        detected.append("autogen")
    if _is_installed("google.adk"):
        detected.append("google-adk")
    if processor is not None:
        detected.append("openai-agents")

    if detected:
        logger.info("[SpawnHub] Instrumented: %s", ", ".join(detected))
    else:
        logger.warning(
            "[SpawnHub] No supported AI framework detected. "
            "Install one of: langchain, openai-agents, crewai, autogen"
        )

    return InstrumentResult(provider=provider, processor=processor)


# ── Module-level singleton so instrument() is idempotent ───────────────────
_processor_instance: object | None = None


def _inject_openai_processor(
    endpoint: str,
    api_key: str,
    pattern: str,
    personas: dict | None,
) -> "SpawnHubTracingProcessor":  # noqa: F821
    global _processor_instance

    if _processor_instance is not None:
        return _processor_instance  # type: ignore[return-value]

    from ._processor import SpawnHubTracingProcessor
    from agents import add_trace_processor  # type: ignore

    proc = SpawnHubTracingProcessor(
        endpoint=endpoint,
        api_key=api_key,
        pattern=pattern,
        personas=personas,
    )
    add_trace_processor(proc)
    _processor_instance = proc
    logger.info("[SpawnHub] OpenAI Agents SDK processor registered")
    return proc
