"""
SpawnHub SDK — instrument your AI agents in one line.

    from spawnhub import instrument
    instrument(api_key="spwnhub_abc123")

Auto-detects the installed framework (LangChain, OpenAI Agents SDK, CrewAI,
AutoGen, Google ADK) and configures telemetry accordingly.

For OTEL-native frameworks (LangChain, CrewAI, AutoGen, Google ADK):
    Sets up an OTLPSpanExporter pointing at SpawnHub. No further code needed.

For OpenAI Agents SDK (no native OTEL):
    Injects a SpawnHubTracingProcessor into the SDK's tracing system.
"""

from ._core import InstrumentResult, instrument
from ._processor import SpawnHubTracingProcessor

__all__ = ["instrument", "InstrumentResult", "SpawnHubTracingProcessor"]
