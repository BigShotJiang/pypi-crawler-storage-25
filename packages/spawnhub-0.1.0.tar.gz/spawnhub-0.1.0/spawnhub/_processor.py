"""
SpawnHubTracingProcessor — OpenAI Agents SDK -> SpawnHub bridge.

Hooks into the OpenAI Agents SDK tracing system and forwards every span
to the SpawnHub ingestion server as GameEvents via POST /v1/events.

HTTP calls run in a background thread so the async agent runtime is never blocked.

Span -> GameEvent mapping:
    AgentSpanData    on_start -> agent_spawn
    AgentSpanData    on_end   -> agent_complete
    ResponseSpanData on_end   -> agent_think   (token counts available at end)
    FunctionSpanData on_start -> agent_action  (show immediately while tool runs)
    HandoffSpanData  on_start -> agent_action  ("handoff -> <agent>" label)
"""

from __future__ import annotations

import logging
import queue
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx

logger = logging.getLogger(__name__)


def _import_sdk():
    """Lazy-import SDK internals — handles different SDK versions."""
    try:
        from agents.tracing.processor_interface import TracingProcessor  # type: ignore
    except ImportError:
        try:
            from agents.tracing import TracingProcessor  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "openai-agents package not found. Install it with:\n"
                "    pip install spawnhub[openai]  or  pip install openai-agents"
            ) from exc

    try:
        from agents.tracing.spans import (  # type: ignore
            AgentSpanData, FunctionSpanData, HandoffSpanData, ResponseSpanData,
        )
    except ImportError:
        from agents.tracing import (  # type: ignore
            AgentSpanData, FunctionSpanData, HandoffSpanData, ResponseSpanData,
        )

    return TracingProcessor, AgentSpanData, FunctionSpanData, ResponseSpanData, HandoffSpanData


def _epoch_to_dt(ts: float | None) -> str:
    if ts is None:
        ts = datetime.now(tz=timezone.utc).timestamp()
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


def _model_from_response(response: Any) -> str:
    try:
        return str(response.model)
    except AttributeError:
        return "unknown"


def _tokens_from_response(response: Any) -> tuple[int | None, int | None]:
    try:
        usage = response.usage
        inp = getattr(usage, "input_tokens", None) or getattr(usage, "prompt_tokens", None)
        out = getattr(usage, "output_tokens", None) or getattr(usage, "completion_tokens", None)
        return (int(inp) if inp is not None else None,
                int(out) if out is not None else None)
    except Exception:
        return None, None


class SpawnHubTracingProcessor:
    """
    OpenAI Agents SDK TracingProcessor that streams GameEvents to SpawnHub.

    Register via instrument() or manually:
        from agents import add_trace_processor
        add_trace_processor(SpawnHubTracingProcessor(api_key="spwnhub_..."))
    """

    def __init__(
        self,
        endpoint: str = "http://localhost:8000",
        api_key: str = "",
        pattern: str = "orchestrator",
        personas: dict[str, dict[str, str]] | None = None,
        session_group_id: str | None = None,
    ) -> None:
        (
            self._TracingProcessor,
            self._AgentSpanData,
            self._FunctionSpanData,
            self._ResponseSpanData,
            self._HandoffSpanData,
        ) = _import_sdk()

        self._endpoint   = endpoint.rstrip("/")
        self._api_key    = api_key
        self._pattern    = pattern
        self._personas   = personas or {}
        self._group_id   = session_group_id

        self._session_ids: dict[str, str]       = {}
        self._agent_names: dict[str, str]        = {}
        self._span_parents: dict[str, str | None] = {}

        self._queue: queue.SimpleQueue[dict | None] = queue.SimpleQueue()
        self._worker = threading.Thread(
            target=self._flush_worker, daemon=True, name="spawnhub-poster"
        )
        self._worker.start()

        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["X-SpawnHub-Key"] = api_key
        self._client = httpx.Client(timeout=5.0, headers=headers)

    # ── TracingProcessor interface ──────────────────────────────────────────

    def on_trace_start(self, trace: Any) -> None:
        session_id = self._group_id or getattr(trace, "group_id", None) or trace.trace_id
        self._session_ids[trace.trace_id] = session_id

    def on_trace_end(self, trace: Any) -> None:
        self._session_ids.pop(trace.trace_id, None)

    def on_span_start(self, span: Any) -> None:
        self._span_parents[span.span_id] = span.parent_id
        data = span.span_data

        if isinstance(data, self._AgentSpanData):
            self._agent_names[span.span_id] = data.name
            self._post(self._build_agent_spawn(span, data))
        elif isinstance(data, self._FunctionSpanData):
            event = self._build_agent_action(span, data)
            if event:
                self._post(event)
        elif isinstance(data, self._HandoffSpanData):
            event = self._build_handoff_action(span, data)
            if event:
                self._post(event)

    def on_span_end(self, span: Any) -> None:
        data = span.span_data

        if isinstance(data, self._AgentSpanData):
            self._post(self._build_agent_complete(span))
            self._agent_names.pop(span.span_id, None)
        elif isinstance(data, self._ResponseSpanData):
            event = self._build_agent_think(span, data)
            if event:
                self._post(event)

        self._span_parents.pop(span.span_id, None)

    def shutdown(self) -> None:
        self._queue.put(None)
        self._worker.join(timeout=5)
        self._client.close()

    def force_flush(self) -> None:
        """Drain the queue before returning (blocks up to 5 s)."""
        import time
        deadline = time.monotonic() + 5
        while not self._queue.empty() and time.monotonic() < deadline:
            time.sleep(0.05)

    # ── Event builders ──────────────────────────────────────────────────────

    def _build_agent_spawn(self, span: Any, data: Any) -> dict:
        persona = self._personas.get(data.name, {})
        return {
            "event_type":      "agent_spawn",
            "event_id":        str(uuid.uuid4()),
            "trace_id":        span.trace_id,
            "span_id":         span.span_id,
            "session_id":      self._session_id(span),
            "agent_id":        span.span_id,
            "agent_name":      data.name,
            "parent_agent_id": self._parent_agent_id(span),
            "pattern":         self._pattern,
            "timestamp":       _epoch_to_dt(span.started_at),
            "agent_type":      "openai_agents",
            "persona": {
                "name":      persona.get("name"),
                "gender":    persona.get("gender"),
                "country":   persona.get("country"),
                "framework": "openai",
            },
        }

    def _build_agent_complete(self, span: Any) -> dict:
        error = getattr(span, "error", None)
        return {
            "event_type":      "agent_complete",
            "event_id":        str(uuid.uuid4()),
            "trace_id":        span.trace_id,
            "span_id":         span.span_id,
            "session_id":      self._session_id(span),
            "agent_id":        span.span_id,
            "agent_name":      self._agent_names.get(span.span_id, "unknown"),
            "parent_agent_id": self._parent_agent_id(span),
            "pattern":         self._pattern,
            "timestamp":       _epoch_to_dt(span.ended_at),
            "success":         error is None,
            "output_summary":  str(error) if error else None,
        }

    def _build_agent_think(self, span: Any, data: Any) -> dict | None:
        owner_id = self._agent_owner(span.parent_id)
        if owner_id is None:
            return None
        response     = getattr(data, "response", None)
        inp, out     = _tokens_from_response(response)
        return {
            "event_type":      "agent_think",
            "event_id":        str(uuid.uuid4()),
            "trace_id":        span.trace_id,
            "span_id":         span.span_id,
            "session_id":      self._session_id(span),
            "agent_id":        owner_id,
            "agent_name":      self._agent_names.get(owner_id, "unknown"),
            "parent_agent_id": None,
            "pattern":         self._pattern,
            "timestamp":       _epoch_to_dt(span.ended_at),
            "model":           _model_from_response(response),
            "prompt_tokens":   inp,
            "completion_tokens": out,
        }

    def _build_agent_action(self, span: Any, data: Any) -> dict | None:
        owner_id = self._agent_owner(span.parent_id)
        if owner_id is None:
            return None
        raw = getattr(data, "input", None)
        return {
            "event_type":      "agent_action",
            "event_id":        str(uuid.uuid4()),
            "trace_id":        span.trace_id,
            "span_id":         span.span_id,
            "session_id":      self._session_id(span),
            "agent_id":        owner_id,
            "agent_name":      self._agent_names.get(owner_id, "unknown"),
            "parent_agent_id": None,
            "pattern":         self._pattern,
            "timestamp":       _epoch_to_dt(span.started_at),
            "tool_name":       data.name,
            "tool_input":      {"raw": str(raw)} if raw else None,
        }

    def _build_handoff_action(self, span: Any, data: Any) -> dict | None:
        owner_id = self._agent_owner(span.parent_id)
        if owner_id is None:
            return None
        to_agent = getattr(data, "to_agent", None) or "unknown"
        return {
            "event_type":      "agent_action",
            "event_id":        str(uuid.uuid4()),
            "trace_id":        span.trace_id,
            "span_id":         span.span_id,
            "session_id":      self._session_id(span),
            "agent_id":        owner_id,
            "agent_name":      self._agent_names.get(owner_id, "unknown"),
            "parent_agent_id": None,
            "pattern":         self._pattern,
            "timestamp":       _epoch_to_dt(span.started_at),
            "tool_name":       f"handoff -> {to_agent}",
            "tool_input":      None,
        }

    # ── Helpers ─────────────────────────────────────────────────────────────

    def _session_id(self, span: Any) -> str:
        return self._session_ids.get(span.trace_id, span.trace_id)

    def _agent_owner(self, span_id: str | None, _depth: int = 0) -> str | None:
        if span_id is None or _depth > 16:
            return None
        if span_id in self._agent_names:
            return span_id
        return self._agent_owner(self._span_parents.get(span_id), _depth + 1)

    def _parent_agent_id(self, span: Any) -> str | None:
        return self._agent_owner(span.parent_id)

    def _flush_worker(self) -> None:
        while True:
            item = self._queue.get()
            if item is None:
                break
            try:
                resp = self._client.post(f"{self._endpoint}/v1/events", json=[item])
                if resp.status_code not in (200, 202):
                    logger.warning(
                        "[SpawnHub] POST /v1/events %d: %s",
                        resp.status_code, resp.text[:200],
                    )
            except Exception as exc:
                logger.debug("[SpawnHub] POST /v1/events failed: %s", exc)

    def _post(self, event: dict) -> None:
        self._queue.put(event)
