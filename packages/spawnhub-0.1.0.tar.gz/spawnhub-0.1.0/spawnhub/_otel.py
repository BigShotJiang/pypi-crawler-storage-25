"""
OTEL exporter setup for SpawnHub.

Configures a TracerProvider with an OTLPSpanExporter that sends spans to
the SpawnHub ingestion endpoint with the tenant API key in the header.

Used by all OTEL-native frameworks: LangChain, LangGraph, CrewAI, AutoGen,
Google ADK. They pick up the global TracerProvider automatically.
"""

from __future__ import annotations

import logging

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

logger = logging.getLogger(__name__)

_initialized = False
_provider: TracerProvider | None = None


def setup_otel(
    endpoint: str,
    api_key: str,
    service_name: str,
) -> TracerProvider:
    """
    Configure the global OTEL TracerProvider for SpawnHub.

    Idempotent — safe to call multiple times; only configures on first call.

    Args:
        endpoint:     SpawnHub ingestion base URL, e.g. https://ingest.spawnhub.ai
        api_key:      Tenant API key (X-SpawnHub-Key header). Empty string = local dev.
        service_name: Value for the service.name OTEL resource attribute.

    Returns:
        The configured TracerProvider.
    """
    global _initialized, _provider

    if _initialized and _provider is not None:
        return _provider

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)

    headers = {}
    if api_key:
        headers["X-SpawnHub-Key"] = api_key

    exporter = OTLPSpanExporter(
        endpoint=f"{endpoint.rstrip('/')}/v1/traces",
        headers=headers,
    )

    # Long delay so spans don't auto-export mid-pipeline.
    # Callers must call force_flush() after the top-level span closes.
    provider.add_span_processor(
        BatchSpanProcessor(exporter, schedule_delay_millis=600_000)
    )

    trace.set_tracer_provider(provider)
    _initialized = True
    _provider = provider

    logger.info("[SpawnHub] OTEL configured -> %s/v1/traces", endpoint.rstrip("/"))
    return provider
