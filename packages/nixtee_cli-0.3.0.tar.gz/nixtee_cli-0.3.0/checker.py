import torch
import torch.fx
import yaml
import click

class NixteeValidator:
    def __init__(self, model, config_path):
        self.model = model
        self.config_path = config_path
        self.config = {}
        self.errors = []

    def validate_all(self):
        """Runs a series of local pre-flight checks."""
        self._check_yaml_syntax()
        if not self.errors:
            self._check_required_sections()
            self._check_search_space_logic()
        self._check_fx_compatibility()
        
        if self.errors:
            click.secho("\nPre-flight check failed:", fg="red", bold=True)
            for err in self.errors:
                click.echo(f"  - {err}")
            return False
        
        click.secho("Pre-flight check successful.", fg="green")
        return True

    def _check_yaml_syntax(self):
        try:
            with open(self.config_path, 'r') as f:
                self.config = yaml.safe_load(f)
        except Exception as e:
            self.errors.append(f"YAML syntax error: {e}")

    def _check_required_sections(self):
        """Validates the new schema: settings, search_space, targets."""
        required = ["settings", "search_space", "targets"]
        for section in required:
            if section not in self.config:
                self.errors.append(f"Missing required section: '{section}'")
        
        # Check nested settings
        if "settings" in self.config:
            settings = self.config["settings"]
            if "target_hardware" not in settings:
                self.errors.append("Missing 'target_hardware' in settings.")
            if "optimization_target" not in settings:
                self.errors.append("Missing 'optimization_target' (e.g., accuracy).")

    def _check_search_space_logic(self):
        """Ensures search_space contains lists or valid ranges."""
        search_space = self.config.get("search_space", {})
        if not search_space:
            self.errors.append("The 'search_space' section cannot be empty.")
            return

        for param, values in search_space.items():
            if not isinstance(values, list):
                self.errors.append(f"Parameter '{param}' in search_space must be a list of options.")

    def _check_fx_compatibility(self):
        """Checks if the model can be traced using torch.fx."""
        try:
            # We use a simple tracer to ensure the graph is static
            torch.fx.Tracer().trace(self.model)
        except Exception as e:
            self.errors.append(
                f"Model is incompatible with Nixtee GNN parser. "
                f"Ensure no dynamic branching (if/else) exists in the forward pass. "
                f"Torch.fx Error: {e}"
            )

    def get_config(self):
        """Returns the loaded config for use in the main CLI."""
        return self.config