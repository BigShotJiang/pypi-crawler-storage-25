import warnings
import os

# 1. Potlačení Python varování (jako je to od urllib3)
warnings.filterwarnings("ignore")

# 2. Potlačení varování z C++ backendu (jako je to z PyTorch/NumPy)
os.environ['PYTHONWARNINGS'] = 'ignore'
os.environ['TORCH_CPP_LOG_LEVEL'] = 'ERROR'

import json
import sys

from checker import NixteeValidator
import torch
import torch.fx
import yaml
import requests
import click
import configparser
import importlib.util
import sys
from pathlib import Path

# Path to credentials
NIXTEE_CONFIG_PATH = Path.home() / ".nixtee" / "credentials"
API_URL = "https://api.nixtee.com"

# --- ASCII Art Logo for "Nixtee" ---
LOGO = r"""
 _   _ _      _            
| \ | (_)    | |           
|  \| |___  _| |_ ___  ___ 
|     | \ \/ / __/ _ \/ _ \
| |\  | |>  <| ||  __/  __/
\_| \_/_/_/\_\\__\___|\___|
"""

# Tato třída vloží logo před každou nápovědu
class NixteeGroup(click.Group):
    def format_help(self, ctx, formatter):
        click.secho(LOGO, fg="cyan", bold=True)
        click.echo("--- Intelligence for Neural Architectures ---\n")
        super().format_help(ctx, formatter)

@click.group(cls=NixteeGroup, invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """Nixtee CLI – Performance Prediction SaaS."""
    # This prints before any subcommand
    if not ctx.resilient_parsing:
        # Vypíšeme logo jen pokud neběží help (ten už ho má z NixteeGroup)
        # Click nastavuje ctx.resilient_parsing na True během helpu
        pass

    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())

@cli.command()
def configure():
    """Sets access credentials (API Key and Secret)."""
    click.secho("--- Nixtee Configuration ---")
    api_key = click.prompt("Nixtee API Key")
    api_secret = click.prompt("Nixtee API Secret", hide_input=True)
    
    # Create the folder if it does not exist
    NIXTEE_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    config = configparser.ConfigParser()
    config['default'] = {
        'nixtee_api_key': api_key,
        'nixtee_api_secret': api_secret
    }
    
    with open(NIXTEE_CONFIG_PATH, 'w') as f:
        config.write(f)
    
    click.secho(f"Credentials sucessfully save to {NIXTEE_CONFIG_PATH}", fg="green")

@cli.command()
@click.option('--model-path', type=click.Path(exists=True), help="Path to .py file with mdoel.")
@click.option('--class-name', default="Net", help="Model class name (default: Net)")
@click.option('--config', type=click.Path(exists=True), help="Path to nixtee.yaml")
@click.pass_context
def predict(ctx, model_path, class_name, config):
    """Predict the network by GNN model."""
    conf = configparser.ConfigParser()
    if not NIXTEE_CONFIG_PATH.exists():
        click.secho("Credentials not found. Run 'nixtee_cli.py configure' first.", fg="red")
        return
    
    conf.read(NIXTEE_CONFIG_PATH)
    try:
        api_key = conf['default']['nixtee_api_key']
        api_secret = conf['default']['nixtee_api_secret']
    except KeyError:
        click.secho("Error in crendtial file. Run 'configure' again.", fg="red")
        return


    # 1. Load YAML file
    with open(config, 'r') as f:
        config_data = yaml.safe_load(f)
    
    # 2. Dynamic import of the model (assuming the model is in the 'Net' class)
    try:
        click.secho(f"Load model '{class_name}' from file {model_path}...")
        model = load_model_from_file(model_path, class_name)
    except Exception as e:
        click.secho(f"Failed to load model: {e}", fg="red")
        return

    # 2. Run validations
    validator = NixteeValidator(model, config)
    if not validator.validate_all():
        sys.exit(1)
        
    # 3. Graph extraction
    try:
        with click.progressbar(length=100,
                                label='Parsing architecture using torch.fx...',
                                show_percent=True,
                                show_pos=False) as barParser:

            barParser.update(10)
            
            graph_payload = extract_nixtee_graph(model)

            barParser.update(90)
    except Exception as e:
        click.secho(f"\nParing error: {e}", fg="red")

    # 4. Build the final JSON for the Rest API
    final_payload = {
        "metadata": {
            "experiment": config_data.get("experiment_name"),
            "hardware": config_data.get("settings", {}).get("target_hardware"),
            "version": config_data.get("version")
        },
        "architecture": graph_payload,
        "search_space": config_data.get("hyperparameter_space"),
        "targets": config_data.get("targets")
    }

    # 5. Send to cloud
    click.secho(f"Sending {len(graph_payload['nodes'])} nodes to Nixtee...")
    
    headers = {
        "X-Nixtee-Key": api_key,
        "X-Nixtee-Secret": api_secret,
        "Content-Type": "application/json"
    }

    # Print the payload for debugging
    # click.secho("\nDEBUG: Outgoing JSON Payload:", fg="yellow", bold=True)
    # debug_json = json.dumps(final_payload, indent=2)
    # print(debug_json)
    
    try:
        # label určuje text vedle baru, length=0 + show_percent=False vytvoří pulzující efekt
        with click.progressbar(length=100, 
                            label='Predicting performance via Nixtee',
                            show_percent=True,
                            show_pos=False) as bar:
            
            # Aby bar aspoň trochu "pulzoval" před samotným requestem
            bar.update(10)
            
            response = requests.post(API_URL+"/v1/predict", json=final_payload, headers=headers)
            
            bar.update(90)

        response.raise_for_status()
        
        click.secho("\nPrediction complete!", fg="green", bold=True)
        
        if response.status_code == 200:
            display_results(response.json())
        else:
            click.secho(f"Error: {response.text}")

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 401:
            click.secho("\nAuth failed: Invalid API Key or Secret.", fg="red")
        else:
            click.secho(f"\nServer error: {e}", fg="red")
    except Exception as e:
        click.secho(f"\nConnection error: {e}", fg="red")

@cli.command()
def history():
    """Get last 10 optimization experiments."""
    # 1. Načtení credentials (stejné jako v predict)
    conf = configparser.ConfigParser()
    conf.read(NIXTEE_CONFIG_PATH)
    headers = {
        "X-Nixtee-Key": conf['default']['nixtee_api_key'],
        "X-Nixtee-Secret": conf['default']['nixtee_api_secret']
    }

    click.echo("Fetching your experiment history...")
    
    try:
        response = requests.get(f"{API_URL}/v1/history", headers=headers)
        response.raise_for_status()
        data = response.json()

        if not data:
            click.secho("No history found. Try running 'predict' first!", fg="red")
            return

        # 2. Vykreslení tabulky
        header = f"{'Id':<20} | {'Date':<20} | {'Experiment':<25} | {'Target':<10} | {'Result':<10}"
        click.secho(header, fg="cyan", bold=True)
        click.echo("-" * len(header))

        for item in data:
            id = item.get('Id', 'unnamed')[:32]
            # GORM vrací CreatedAt jako ISO string
            date = item['CreatedAt'][:16].replace("T", " ")
            name = item.get('ModelName', 'unnamed')[:25]
            acc = f"{item.get('PredictedAcc', 0)*100:.2f}%"
            
            click.echo(f"{id:<20} | {date:<20} | {name:<25} | {'accuracy':<10} | {acc:<10}")

    except Exception as e:
        click.secho(f"Could not fetch history: {e}", fg="red")

def display_results(res):
    """
    Nicely displays prediction results for a data scientist.
    """
    predictions = res.get("predictions", {})
    best_params = res.get("best_parameters", {})

    # 1. Výpis predikovaných metrik
    click.secho("\nPredicted Performance (at optimal settings):", fg="cyan", bold=True)
    for metric, value in predictions.items():
        unit = "ms" if "latency" in metric else "MB" if "memory" in metric else "%"
        display_val = value * 100 if metric == "accuracy" else value
        click.echo(f"  - {metric:15}: {display_val:>8.2f} {unit}")

    # 2. Výpis doporučených parametrů
    if best_params:
        click.echo("")
        click.secho("Nixtee Recommendation:", fg="yellow", bold=True)
        click.secho("   To achieve these results, use the following configuration:", fg="white")
        
        # Vytvoříme hezký boxík nebo tabulku
        for param, val in best_params.items():
            click.echo(f"   [+] {param:15}: {click.style(str(val), fg='green', bold=True)}")

        # Bonus: Příkaz pro copy-paste do trénování
        click.echo("")
        click.secho("Run training with:", dim=True)
        click.echo(f"   python nixtee_cli.py train --lr {best_params['learning_rate']} --batch {best_params['batch_size']}")

@cli.command()
@click.option('--id', 'exp_id', required=True, type=int, help="Experiment ID from 'nixtee history'")
@click.option('--actual', required=True, type=float, help="The real accuracy you achieved (e.g. 0.82)")
def feedback(exp_id, actual):
    """Submit real-world results to improve the Nixtee Oracle."""
    conf = configparser.ConfigParser()
    if not NIXTEE_CONFIG_PATH.exists():
        click.secho("Credentials not found. Run 'nixtee_cli.py configure' first.", fg="red")
        return
    
    conf.read(NIXTEE_CONFIG_PATH)
    try:
        api_key = conf['default']['nixtee_api_key']
        api_secret = conf['default']['nixtee_api_secret']
    except KeyError:
        click.secho("Error in crendtial file. Run 'configure' again.", fg="red")
        return
    
    headers = {
        "X-Nixtee-Key": api_key,
        "X-Nixtee-Secret": api_secret,
        "Content-Type": "application/json"
    }
    
    payload = {
        "experiment_id": exp_id,
        "actual_accuracy": actual
    }

    try:
        response = requests.post(f"{API_URL}/v1/feedback", json=payload, headers=headers)
        response.raise_for_status()
        click.secho("Feedback submitted! Our GNN will learn from this.", fg="green", bold=True)
    except Exception as e:
        click.secho(f"Failed to submit feedback: {e}", fg="red")

def load_model_from_file(model_path, class_name="Net"):
    """
    Dynamically loads a Python file and initializes the model class.
    """
    path = Path(model_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"File {model_path} not found.")

    # Create module name and load it
    module_name = path.stem
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    module = importlib.util.module_from_spec(spec)
    
    # Add the model directory to sys.path (for local imports in the model file)
    sys.path.insert(0, str(path.parent))
    
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        raise ImportError(f"Modul of the model failed: {e}")

    # Get class with the model
    if not hasattr(module, class_name):
        raise AttributeError(f"In file {model_path} class '{class_name}' not found.")
    
    model_class = getattr(module, class_name)
    return model_class()

def extract_nixtee_graph(model):
    """Converts a PyTorch model to a serializable graph for GNN."""
    symbolic_tracer = torch.fx.Tracer()
    graph = symbolic_tracer.trace(model)
    
    nodes_data = []
    # Mapping node name to index for edge definition
    node_to_idx = {node.name: i for i, node in enumerate(graph.nodes)}
    
    edges = []
    
    for node in graph.nodes:
        # Extract meta-dat about operation
        node_info = {
            "id": node_to_idx[node.name],
            "name": node.name,
            "op": node.op,
            "target": str(node.target),
        }
        nodes_data.append(node_info)
        
        # Building edges using indices
        for user in node.users:
            edges.append([node_to_idx[node.name], node_to_idx[user.name]])
            
    return {"nodes": nodes_data, "edges": edges}

if __name__ == '__main__':
    cli()