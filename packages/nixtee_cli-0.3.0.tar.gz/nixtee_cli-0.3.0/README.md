# 🌀 Nixtee CLI

**Nixtee** is a SaaS platform for neural network performance prediction using GNNs (Graph Neural Networks). This CLI allows data scientists to analyze their model architecture locally and send it to the **Nixtee Oracle** in AWS for optimization without ever needing to run a single training epoch.

## 🚀 Quick Start

### 1. Development Environment (via Nix)

If you have Nix installed, you can enter a perfectly reproducible environment containing all dependencies (Python, PyTorch, Click, Requests):

```bash
nix develop

```

### 2. Configuration

Before your first prediction, set up your API credentials provided in your Nixtee Dashboard:

```bash
python3 nixtee_cli.py configure

```

*Your keys will be securely stored in `~/.nixtee/credentials`.*

---

## 🛠️ Usage

### Predict & Optimize

The primary command that takes your model code and a configuration YAML, performs static analysis, and returns predicted metrics (Accuracy, Latency, Memory) along with the optimal hyperparameters.

```bash
python3 nixtee_cli.py predict \
    --model-path ./models/my_net.py \
    --config ./nixtee.yaml

```

**Options:**

* `--model-path`: Path to the `.py` file containing your model class.
* `--config`: Path to the `nixtee.yaml` file defining the experiment.
* `--class-name` *(optional)*: Name of the model class (defaults to `Net`).

---

## 📄 File Formats

### `nixtee.yaml`

Define your hardware target and the search space you want Nixtee to explore.

```yaml
version: 1.0
experiment_name: "resnet_cifar10_optimization"

settings:
  target_hardware: "nvidia-t4"
  optimization_target: "accuracy"

search_space:
  learning_rate: [0.0001, 0.001, 0.01]
  batch_size: [32, 64, 128]
  optimizer: ["adamw", "sgd"]

targets:
  - accuracy
  - latency_ms
  - peak_memory_mb

```

### `model.py`

Your model must be a valid `torch.nn.Module`. The CLI uses `torch.fx` to extract the graph representation.

```python
import torch.nn as nn

class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv2d(3, 16, 3)
        self.fc = nn.Linear(16 * 222 * 222, 10)

    def forward(self, x):
        x = self.conv(x)
        return self.fc(x.view(x.size(0), -1))

```

---

## 🔍 How it Works

1. **Pre-flight Check**: The CLI validates YAML syntax and ensures the model is compatible with the FX tracer.
2. **Graph Extraction**: The architecture is converted into a structured JSON representation of nodes and edges.
3. **SaaS Inference**: Data is sent to the Nixtee Go API (AWS), where a GNN model predicts performance on the target hardware.
4. **Recommendation**: The Oracle identifies the best combination from your `search_space` and returns it instantly.

---

## 📂 Project Structure

* `nixtee_cli.py`: Main CLI entry point (Click).
* `checker.py`: Logic for validation and pre-flight checks.
* `model_loader.py`: Utility for dynamic Python module imports.
* `flake.nix`: Nix Flake for zero-install environment setup.