from setuptools import setup

setup(
    name="nixtee-cli",
    version="0.3.0",
    # Místo find_packages() použijeme toto:
    py_modules=["nixtee_cli", "checker", "model_loader"],
    install_requires=[
        "click",
        "requests",
        "torch",
        "pyyaml",
    ],
    entry_points={
        'console_scripts': [
            'nixtee=nixtee_cli:cli',
        ],
    },
    author="Nixtee s.r.o",
    description="GNN-based Neural Network Performance Predictor",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/ajandera/nixtee-cli",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)