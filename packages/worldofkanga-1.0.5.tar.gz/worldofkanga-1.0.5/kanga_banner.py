#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import time
import os
import sys

# Cores ANSI
CYAN = "\033[1;36m"
GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
RED = "\033[1;31m"
RESET = "\033[0m"

# Função para limpar tela (multiplataforma)
def limpar_tela():
    """Limpa a tela no Windows (cls) ou Linux/Mac/Termux (clear)"""
    os.system('cls' if sys.platform == 'win32' else 'clear')

# BANNER PRINCIPAL
BANNER = f"""{CYAN}
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║     ██╗  ██╗ █████╗ ███╗   ██╗ ██████╗  █████╗                  ║
║     ██║ ██╔╝██╔══██╗████╗  ██║██╔════╝ ██╔══██╗                 ║
║     █████╔╝ ███████║██╔██╗ ██║██║  ███╗███████║                 ║
║     ██╔═██╗ ██╔══██║██║╚██╗██║██║   ██║██╔══██║                 ║
║     ██║  ██╗██║  ██║██║ ╚████║╚██████╔╝██║  ██║                 ║
║     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝                 ║
║                                                                  ║
║                 W O R L D   O F   K . A . N . G . A              ║
║                                                                  ║
║                    By Denny-a Gvo | @Denny_a_gvo                 ║
╚══════════════════════════════════════════════════════════════════╝
{RESET}"""

HACKER_ASCII = r"""
          (\_/)
         ( •_•)
        / >⚡/>  HACK TIME!
        \___)__)
"""

def mostrar_banner():
    """Mostra o banner principal"""
    print(BANNER)

def digita_ascii():
    """Digita o ASCII art caracter por caracter"""
    print()
    for ch in HACKER_ASCII:
        print(ch, end="", flush=True)
        time.sleep(0.01)
    print("\n")
    time.sleep(1)

def mostrar_banner_intro():
    """Mostra introdução completa"""
    limpar_tela()
    digita_ascii()
    mostrar_banner()