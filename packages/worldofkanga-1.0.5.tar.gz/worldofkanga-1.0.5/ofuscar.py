#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ofuscador KANGA-HACK
Técnica: zlib (nível 9) + base64 + wrapper try/except KeyboardInterrupt
Compatível com qualquer Python, sem marshal, sem dependências externas.
"""
import base64
import zlib
import os

ARQUIVOS = [
    "KANGA.py",
]

WRAPPER = '''try:
    import base64,zlib
    exec(zlib.decompress(base64.b64decode("{payload}")).decode())
except KeyboardInterrupt:
    print("\\nOperação cancelada.")
'''

def ofuscar(codigo: str) -> str:
    """Ofusca código Python com compressão zlib + base64"""
    compressed = zlib.compress(codigo.encode("utf-8"), level=9)
    encoded = base64.b64encode(compressed).decode("ascii")
    return WRAPPER.format(payload=encoded)

def main():
    src_dir = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(src_dir, "ofuscado")
    os.makedirs(out_dir, exist_ok=True)
    
    print("=" * 60)
    print("  KANGA-HACK - Ofuscador v2.0")
    print("=" * 60)
    
    ok = 0
    for nome in ARQUIVOS:
        src = os.path.join(src_dir, nome)
        if not os.path.isfile(src):
            print(f"  [!] Não encontrado: {nome}")
            continue
        
        with open(src, "r", encoding="utf-8") as f:
            codigo = f.read()
        
        ofuscado = ofuscar(codigo)
        dst = os.path.join(out_dir, nome)
        
        with open(dst, "w", encoding="utf-8") as f:
            f.write(ofuscado)
        
        tamanho_antes = len(codigo.encode())
        tamanho_depois = len(ofuscado.encode())
        ratio = round((1 - tamanho_depois / tamanho_antes) * 100, 1) if tamanho_antes else 0
        
        print(f"  [✔] {nome:<35} {tamanho_antes:>6} → {tamanho_depois:>6} bytes  ({ratio:+.1f}%)")
        ok += 1
    
    print("=" * 60)
    print(f"  {ok}/{len(ARQUIVOS)} arquivos ofuscados → pasta: ofuscado/")
    print("=" * 60)
    print("\n  Para usar os arquivos ofuscados, copie-os para o diretório principal.")
    print("  Eles funcionam exatamente igual aos originais.\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nOperação cancelada.")