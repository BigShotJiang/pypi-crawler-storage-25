from setuptools import setup
from pathlib import Path

long_description = Path("README.md").read_text(encoding="utf-8")

setup(
    name="worldofkanga",
    version="1.0.5",
    author="Denny-a Gvo",
    author_email="adaokangapedro@gmail.com",
    description="Ferramenta multifuncional para pentest, DNS, IPs e payloads",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Adaokanga/KANGA-HACK",
    py_modules=[
        "KANGA",
        "kanga_banner",  # ← ADICIONADO AQUI!
        "delimitador",
        "denny",
        "divide_uni_arquivo",
        "dnsfinder",
        "extractor_hosts_e_ips",
        "host_to_payload",
        "ip_range_e_CIDR",
        "kanga_cli",
        "proxy_finder",
        "ofuscar",       # ← ADICIONADO TAMBÉM
    ],
    install_requires=[
        "requests>=2.31.0",
        "dnspython>=2.6.0",
    ],
    entry_points={
        "console_scripts": [
            "kanga = KANGA:main",
        ],
    },
    python_requires=">=3.7",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
