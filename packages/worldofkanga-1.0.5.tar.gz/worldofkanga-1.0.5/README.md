# KANGA-HACK — Versão Python

Projeto 100% em Python, com banner compartilhado e ofuscação zlib+base64.

## Estrutura

```
KANGA-HACK/
├── kanga_banner.py          ← Banner/cores compartilhado (importado por todos)
├── KANGA.py                 ← Menu principal
├── denny.py                 ← Instalador (substitui denny.sh)
├── dnsfinder.py             ← DNS Finder
├── divide_uni_arquivo.py    ← Dividir / Unir arquivos
├── extractor_hosts_e_ips.py ← Extrator de IPs e Hosts
├── host-to-payload.py       ← Gerador de Payload por Host
├── ip_range_e_CIDR.py       ← Expansão de IP Range / CIDR
├── proxy_finder.py          ← Scanner de Proxy
├── kanga_cli.py             ← Abrir Arquivos VPN (novo)
├── ofuscar.py               ← Ofuscador do projeto
└── ofuscado/                ← Versões ofuscadas de todos os scripts
```

## Instalação (Termux)

```bash
pkg install python git unzip -y
pip install requests dnspython
python3 denny.py
```

## Uso

```bash
python3 KANGA.py
```

## Menu

| Opção | Ferramenta             |
|-------|------------------------|
| 1     | DNS FINDER             |
| 2     | DIVIDIR / UNIR         |
| 3     | EXTRACTOR              |
| 4     | IP RANGE / CIDR        |
| 5     | SCANEAR PROXY          |
| 6     | DELIMITADOR            |
| 7     | GERADOR PAYLOAD        |
| 8     | BUGSCANX (pip)         |
| 9     | HOST → PAYLOAD         |
| 10    | ABRIR ARQUIVOS VPN     |
| 11    | DESINSTALAR KANGA      |
| 0     | SAIR                   |

## Ofuscação

Para gerar a versão ofuscada de todos os scripts:

```bash
python3 ofuscar.py
```

Os arquivos ofuscados ficam em `ofuscado/`. Cada arquivo tem 2 linhas:

```python
try:
    import base64,zlib
    exec(zlib.decompress(base64.b64decode("...")).decode())
except KeyboardInterrupt:
    print("Operação cancelada.")
```

**Técnica usada:**
- Compressão zlib nível 9
- Codificação base64
- Wrapper try/except para Ctrl+C
- Sem marshal (compatível com Termux)
- Sem dependências externas para desofuscar

## By Denny-a Gvo | @Denny_a_gvo (Telegram)
