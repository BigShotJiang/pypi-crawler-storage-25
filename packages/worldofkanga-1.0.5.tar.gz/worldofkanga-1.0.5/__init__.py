#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
KANGA-HACK - Ferramenta multifuncional para pentest
By Denny-a Gvo | @Denny_a_gvo
"""

__version__ = "1.0.0"
__author__ = "Denny-a Gvo"
__license__ = "MIT"

# Exporta funções principais
from .KANGA import main
from .dnsfinder import resolver_dns
from .extractor_hosts_e_ips import extrair
from .proxy_finder import main as scan_proxy

__all__ = [
    "main",
    "resolver_dns",
    "extrair",
    "scan_proxy",
    "__version__",
    "__author__",
]