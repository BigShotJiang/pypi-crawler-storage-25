"""Single-file echo bot — proves a waggle integration in one process.

Skips the claude subprocess entirely. The orchestrator pipeline still
runs (access gate + rate limit + accept/reject events + working-status
indicator) but instead of dispatching to claude, we echo each accepted
inbound back via the Telegram client.

Use this to:
  • smoke-test a waggle build before wiring claude
  • see end-to-end inbound → outbound flow in 80 lines
  • crib from when adding a non-claude orchestrator (e.g. a different
    LLM, or a deterministic rules bot)

Run:
    pip install -e ".[telegram]"
    export WAGGLE_TG_BOT_TOKEN=<your bot token>
    python examples/echo_bot.py

Stop with Ctrl-C.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import yaml

from waggle.access import AccessControl
from waggle.clients.telegram import TelegramClient
from waggle.events import AcceptEvent, build_sink
from waggle.rate_limit import RateLimiter

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("echo")


class EchoOrchestrator:
    """Stand-in for WaggleOrchestrator. Same surface (`submit_inbound`)
    minus the claude subprocess. Echoes the inbound text back."""

    def __init__(self, config: dict, config_path: Path):
        self.config = config
        self.access = AccessControl(config_path)
        self.events = build_sink(config.get("events", {}).get("sink"))
        self.rate_limiter = RateLimiter(self.access.rate_limit)
        self.access.on_rate_limit_change(self.rate_limiter.update_config)
        self.telegram: TelegramClient | None = None

    async def submit_inbound(self, *, chat_id, user_id, username,
                              message_id, text, attachments=()):
        if not self.access.allows(chat_id, user_id):
            log.info("dropped non-allowlisted user_id=%s chat=%s", user_id, chat_id)
            return
        decision = self.rate_limiter.check(chat_id=chat_id, user_id=user_id)
        if not decision.allow:
            log.info("rate-limit drop user=%s chat=%s scope=%s", user_id, chat_id, decision.scope)
            return
        await self.events.emit_accept(
            AcceptEvent(
                source="telegram", chat=str(chat_id), user=str(user_id),
                username=username, message_id=str(message_id),
                body=text or "", attachments=tuple(attachments),
                ts=datetime.now(timezone.utc),
            )
        )
        if self.telegram is not None:
            await self.telegram.reply(
                chat_id=str(chat_id),
                text=f"echo: {text}",
                reply_to=str(message_id),
            )

    async def run(self):
        await self.access.start()
        try:
            await self.telegram.run(self)
        finally:
            await self.access.stop()
            await self.events.aclose()


def _write_config(token: str, owner_id: int) -> Path:
    """Build a minimal YAML config in a temp dir. The user can edit
    this file at runtime (the AccessControl mtime poll picks it up)."""
    tmp = Path(tempfile.mkdtemp(prefix="waggle-echo-"))
    cfg_path = tmp / "config.yaml"
    cfg_path.write_text(yaml.safe_dump({
        "transports": [{"name": "tg", "kind": "telegram", "bot_token": token}],
        "access": {
            "users": [owner_id],
            "rate_limit": {
                "user_per_minute": 10,
                "chat_per_minute": 10,
            },
        },
        "owner": {"user_id": owner_id},
    }))
    return cfg_path


async def main():
    token = os.environ.get("WAGGLE_TG_BOT_TOKEN")
    owner = int(os.environ.get("WAGGLE_OWNER_ID") or 0)
    if not token or not owner:
        raise SystemExit(
            "Set WAGGLE_TG_BOT_TOKEN and WAGGLE_OWNER_ID env vars before running."
        )
    cfg_path = _write_config(token, owner)
    cfg = yaml.safe_load(cfg_path.read_text())
    orch = EchoOrchestrator(cfg, cfg_path)
    orch.telegram = TelegramClient.from_config(cfg["transports"][0])
    log.info("echo bot ready; chat with @<your_bot> to test")
    log.info("config at: %s — edit and watch for hot-reload", cfg_path)

    # Cooperative shutdown on SIGINT
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    runner = asyncio.create_task(orch.run())
    await stop.wait()
    runner.cancel()
    try:
        await runner
    except asyncio.CancelledError:
        pass


if __name__ == "__main__":
    asyncio.run(main())
