# Test catalogue & regression checklist

> Author: Your Name (Claude)
> Status: living doc — updated whenever a test is added, removed, or its
> contract changes.
> Coverage: batches 1 (P0+P1), 2 (P2 v0.3), 3 (P2.5), 4 (P3 /inject), 5 (P4 owner-ops + P5 notifications), 6 (P6 persistence + observability), 8 (P8 rate limits + typing indicator + hot reload + examples + DESIGN.md). P7 (Matrix transport) intentionally skipped — no current need for a second platform.

This doc is the regression-test source of truth. Every public contract
waggle ships is pinned by at least one of the tests below. When a future
batch lands, the new module gets its own row group AND the totals at the
top get bumped; bug fixes that close a regression must add a test here
even when the underlying fix is one line.

Run the full suite:

```bash
.venv/bin/pytest tests/
```

Run one module:

```bash
.venv/bin/pytest tests/test_orchestrator.py -v
```

---

## Coverage summary (183 tests)

| Module | Tests | Happy | Unhappy | Edge | Batch |
|---|---:|---:|---:|---:|:---:|
| `tests/test_channel_tag.py`     | 8  | 5  | 0  | 3  | 1 |
| `tests/test_config.py`          | 22 | 7  | 13 | 2  | 1+P3+P6 |
| `tests/test_access.py`          | 14 | 6  | 5  | 3  | 1+8 |
| `tests/test_telegram_client.py` | 12 | 8  | 2  | 2  | 2+6 |
| `tests/test_orchestrator.py`    | 11 | 6  | 4  | 1  | 2+6+8 |
| `tests/test_stream_claude.py`   | 7  | 3  | 3  | 1  | 2 |
| `tests/test_tools_server.py`    | 11 | 6  | 3  | 2  | 2 |
| `tests/test_status_indicator.py`| 10 | 4  | 1  | 5  | 3 |
| `tests/test_inject.py`          | 21 | 8  | 9  | 4  | 4 |
| `tests/test_owner_ops.py`       | 29 | 17 | 7  | 5  | 5 |
| `tests/test_events.py`          | 20 | 8  | 5  | 7  | 6 |
| `tests/test_rate_limit.py`      | 11 | 6  | 1  | 4  | 8 |
| `tests/test_typing_indicator.py`| 6  | 3  | 1  | 2  | 8 |
| **total**                       | **183** | **87** | **54** | **42** | |

Kind tags:

- **Happy** — the success path with valid inputs
- **Unhappy** — an explicit rejection, validation failure, or surfaced error
- **Edge** — boundary, byte-level format pin, or "surprising-but-load-bearing" behavior

When a new module lands without all three kinds, the merger has to either
add the missing one or document why it's N/A.

---

## Batch 1 — Foundation + Telegram echo

### `tests/test_channel_tag.py` — wire format v1

Frozen wire format: `<channel source="…" chat="…" user="…" ts="…">BODY</channel>`. Any change here is a wire-protocol break — every transport speaking it would need a coordinated update.

| Name | Kind | What it covers |
|---|---|---|
| `test_render_basic` | happy | One known input → exact serialized bytes |
| `test_round_trip` | happy | Render then parse returns the original tag and body verbatim |
| `test_empty_body_round_trips` | happy | Empty body survives render+parse |
| `test_unicode_body_round_trips` | happy | Multi-line + emoji body survives render+parse |
| `test_now_normalises_utc` | happy | `.now()` always emits UTC |
| `test_attribute_escapes` | edge | `& < > "` in any attribute escape to XML entities |
| `test_now_truncates_microseconds_when_rendered` | edge | Wire format frozen at second granularity; `.now()` micros are dropped |
| `test_body_with_literal_close_tag_breaks_parser` | edge | Greedy parser pin: a body containing `</channel>` round-trips with the embedded close inside the body. Callers must reject upstream — the test pins this contract |

### `tests/test_config.py` — YAML + env-ref + pydantic validation

| Name | Kind | What it covers |
|---|---|---|
| `test_minimal_valid` | happy | Smallest valid config loads; defaults applied |
| `test_groups_parse` | happy | Per-group `users` list parses correctly under string→int coercion |
| `test_env_ref_in_non_token_field_passes_through` | happy | `env:VAR` works in any string field, not just `bot_token` |
| `test_multiple_transports_allowed` | happy | Two telegram transports with distinct names load |
| `test_missing_required_fails` | unhappy | Empty `transports` rejected by validator |
| `test_owner_must_be_in_allowlist` | unhappy | Owner not in `access.users` fails loudly at load |
| `test_env_ref_missing_resolves_empty` | unhappy | Unset env var resolves to `""`; downstream `min_length=10` validator catches the empty token |
| `test_short_bot_token_fails` | unhappy | Token under 10 chars rejected |
| `test_invalid_yaml_fails` | unhappy | Malformed YAML raises before pydantic gets to it |
| `test_file_not_found` | unhappy | Missing config file raises `FileNotFoundError` |
| `test_unsupported_transport_kind` | unhappy | Unknown kind (`discord`) rejected by the literal-typed discriminator |
| `test_owner_in_per_group_list_satisfies_owner_validator` | unhappy | Owner being only in a per-group `users` list does NOT satisfy the global allowlist requirement — pin that the gate rejects |
| `test_env_ref_only_replaces_exact_match` | edge | `env:VAR` is the marker; a string containing `env:` inline (e.g. inside a name) is NOT substituted |
| `test_negative_chat_id_for_groups` | edge | Telegram supergroup ids are negative — schema's `dict[int, ...]` accepts them |
| `test_inject_enabled_requires_secret` | unhappy | `inject.enabled: true` without `shared_secret` fails the validator at load |
| `test_inject_enabled_requires_long_secret` | unhappy | `shared_secret` shorter than 16 chars fails the validator (defends against trivially guessable bearers) |
| `test_inject_enabled_requires_default_chat` | unhappy | `inject.enabled: true` without `default_chat_id` fails the validator |
| `test_inject_disabled_skips_validation` | happy | When `inject.enabled: false` (the default), the inject sub-validator is skipped — operators don't need to fill in fields they're not using |

### `tests/test_access.py` — allow-list rules + hot reload

| Name | Kind | What it covers |
|---|---|---|
| `test_dm_requires_user_in_allowlist` | happy + unhappy | Allow-listed user can DM; non-allow-listed cannot |
| `test_group_per_group_users` | happy + unhappy | Per-group `users` enforced; global `users` does NOT bypass it |
| `test_group_empty_users_admits_anyone` | happy | Empty per-group `users[]` admits anyone in the group (group chat_id is the trust boundary; matches Anthropic claude-code MCP semantics) |
| `test_require_mention_blocks_unmentioned` | happy + unhappy | Group with `require_mention: true` only accepts `@bot` mentions or replies to bot messages |
| `test_require_mention_does_not_apply_to_dm` | edge | `require_mention` is a group concept; DMs ignore it |
| `test_parse_rules_from_yaml_dict` | happy | Mixed dict input maps to immutable `AccessRules` correctly |
| `test_hot_reload_mtime` | happy | Editing the file (with mtime bump) flips the in-memory rules within poll-interval |
| `test_group_requires_chat_in_allowlist` | unhappy | Group not listed rejects everyone, even global users |
| `test_empty_rules_rejects_everyone` | unhappy | Default empty rules are deny-all |
| `test_chat_zero_treated_as_dm` | edge | `chat_id == 0` lands in the DM branch (boundary pin against signed-int tweaks) |
| `test_start_fails_when_file_missing` | edge | Initial load raises so the runtime cannot enforce a list it never read |
| `test_reload_keeps_old_rules_on_yaml_error` | edge | Malformed mid-flight edit keeps last-good rules in memory + logs warning |
| `test_reload_keeps_old_rules_on_file_deleted` | edge | File deleted post-start does NOT wipe enforcement; last-good rules continue |

---

## Batch 2 — Stream-json orchestrator + tools-only outbound (P2 v0.3)

### `tests/test_telegram_client.py` — inbound dispatch + edge filtering

| Name | Kind | What it covers |
|---|---|---|
| `test_inbound_with_text_dispatches` | happy | Allow-listed inbound calls `orchestrator.submit_inbound(...)` with the expected fields |
| `test_inbound_with_caption_dispatches` | happy | Caption (photo + caption) flows through the same path as plain text |
| `test_inbound_username_falls_back_to_id` | happy | No public username — substitute the numeric id so `meta` has a stable identifier |
| `test_orchestrator_failure_doesnt_kill_handler` | unhappy | `submit_inbound` raising propagates — pin the current contract; if we ever swallow it, change here AND the test |
| `test_no_from_user_dropped` | unhappy | Channel posts (`from_user=None`) and anonymous-admin messages can't be allow-list-gated → silently dropped |
| `test_empty_message_is_dropped` | edge | No text and no caption — orchestrator never called (service messages don't reach the agent) |
| `test_no_orchestrator_bound_skips` | edge | Handler firing during shutdown (`_orchestrator=None`) does not raise |

### `tests/test_orchestrator.py` — turn lock + access gate + status pump

| Name | Kind | What it covers |
|---|---|---|
| `test_allowed_inbound_reaches_claude_with_channel_tag` | happy | Allow-listed inbound: status posted, channel-tag wrap reaches claude, status deleted on success |
| `test_full_event_flow_drives_status_through_states` | happy | Stream-json events drive Thinking → Tool → Writing transitions; final state is "Writing" (debounce coalesce) |
| `test_rejected_inbound_emits_event` | unhappy | Non-allow-listed inbound dropped before claude; structured JSON reject event hits stdout |
| `test_group_rejection_uses_group_reason` | unhappy | Group-chat rejections carry `reason: group-not-allowlisted` |
| `test_subprocess_error_deletes_status_and_posts_error` | unhappy | `is_error=True` from claude → status deleted + new "❌ Error" reply posted (per §1.9 + operator option B) |
| `test_concurrent_inbound_serialised_by_lock` | edge | Two same-chat inbound submissions serialise their stdin writes via `_stdin_lock` — newline-delimited JSON frames mustn't interleave even though mid-turn inject lets them fold logically |
| `test_mid_turn_inject_same_chat_folds` | happy | Second inbound from the SAME chat that arrives while the first turn's `result` is still pending pushes to stdin without waiting (REQUIREMENTS §1.10 — mid-turn fold) |
| `test_mid_turn_inject_different_chat_waits` | happy | Different-chat inbound waits for the active-chat slot — cross-chat folding would leak context across users |
| `test_extract_tasklist_pulls_todos_from_TodoWrite` | happy | A TodoWrite tool_use yields the todos array; the indicator gets the snapshot for the Show-tasks surface |
| `test_extract_tasklist_returns_none_for_unrelated_events` | edge | Assistant events without TodoWrite return None (don't accidentally clear the snapshot) |

### `tests/test_stream_claude.py` — subprocess wrapper

| Name | Kind | What it covers |
|---|---|---|
| `test_single_turn_round_trip` | happy | Send user → read result, full happy round-trip against a shell-script impostor |
| `test_multi_turn_on_one_process` | happy | Two send/read cycles on ONE process — unified-context invariant the v0.3 architecture relies on |
| `test_read_events_yields_all_kinds` | happy | The status-indicator drives off `read_events()` — pin that assistant + tool_use + result events are yielded in order |
| `test_subprocess_exits_immediately` | unhappy | Subprocess that exits without producing a `result` returns `('', True)` |
| `test_missing_executable_raises_at_construction` | unhappy | Misconfig fails fast at construct time, not first turn |
| `test_send_user_before_start_raises` | unhappy | Programmer error: calling `send_user` before `start()` |
| `test_garbage_lines_are_skipped` | edge | Forward-compat: malformed JSON or blank lines on stdout don't crash the parser; we walk past and pick up the real `result` |

### `tests/test_tools_server.py` — outbound MCP tools

| Name | Kind | What it covers |
|---|---|---|
| `test_advertised_tools_have_required_fields` | happy | All five tools (reply / send_to_chat / react / edit_message / download_attachment) declare description + input schema |
| `test_reply_forwards_args` | happy | `reply` with `chat_id`, `text`, `reply_to` calls Bot.send_message with the right kwargs |
| `test_send_to_chat_drops_reply_to` | happy | Proactive send: caller's `reply_to` is intentionally dropped — this is the "post into a chat without threading" path |
| `test_react_forwards_emoji` | happy | `react` constructs a `ReactionTypeEmoji` with the caller's emoji |
| `test_edit_message_forwards_text` | happy | `edit_message` calls Bot.edit_message_text with the right ids |
| `test_download_attachment_returns_path` | happy | Two-step (`get_file` then `download_file`) flow yields a usable path |
| `test_unknown_tool_returns_error` | unhappy | Calling an undeclared tool name returns an `error:` text response, not a crash |
| `test_missing_required_arg_returns_error` | unhappy | Tool dispatch surfaces `KeyError` style failures as a tool-error response |
| `test_bot_failure_propagates_as_tool_error` | unhappy | Telegram API hiccup → tool response carries the exception text; dispatcher keeps running |
| `test_format_markdownv2_sets_parse_mode` | edge | `format=markdownv2` maps to `ParseMode.MARKDOWN_V2` so the model can use Telegram MarkdownV2 escaping |
| `test_format_text_overrides_default_html` | edge | Bot defaults to HTML parse mode; `format=text` must explicitly null it out so user content is sent verbatim |

---

## Batch 3 — Working-status indicator (P2.5)

### `tests/test_status_indicator.py`

| Name | Kind | What it covers |
|---|---|---|
| `test_attach_posts_thinking_label` | happy | First call per turn posts "🤔 Thinking…" and remembers the message id |
| `test_success_deletes_status` | happy | Normal `success()` deletes the rolling status message |
| `test_error_deletes_status_and_posts_error_reply` | happy | `error(msg)` deletes status AND posts a new "❌ Error" reply (§1.9 option B) |
| `test_set_state_changes_label_after_debounce` | happy | An edit lands inside one debounce window |
| `test_attach_failure_doesnt_register` | unhappy | If the initial post fails (e.g. rate limit), no chat is registered → later `set_state` is a silent no-op |
| `test_attach_is_idempotent_within_turn` | edge | Same chat sending multiple inbounds during ONE turn re-uses the existing status message; we never stack |
| `test_set_state_to_same_label_is_noop` | edge | Setting the current label triggers no Telegram traffic |
| `test_bursty_set_state_coalesces` | edge | Three rapid label changes coalesce into ≤2 edits with the latest label winning — Telegram rate-limit safe |
| `test_error_with_empty_message_falls_back` | edge | `error("")` still posts a usable "❌ Error" reply |
| `test_set_state_on_unattached_chat_is_silent` | edge | Calling `set_state` before `attach` doesn't crash — orchestrator startup race tolerated |
| `test_attach_posts_show_transcript_button` | happy | Indicator's keyboard ships with a `🧠 Show thinking` button (callback `t:show`) |
| `test_attach_posts_tasks_button_alongside_transcript` | happy | Indicator keyboard has BOTH thinking + tasks buttons by default |
| `test_show_thinking_posts_new_message_with_refresh_button` | happy | First tap on Show thinking posts a NEW reply (replying to the original inbound) carrying its own 🔄 Refresh button — indicator's keyboard is NOT swapped |
| `test_show_thinking_with_empty_buffer_shows_placeholder` | edge | Empty thinking buffer shows a placeholder explaining why content might be missing (model didn't reason / Opus redacts / gateway strips) |
| `test_show_thinking_refresh_edits_existing_message` | happy | Second tap (Refresh) edits the existing thinking message; never spawns a duplicate |
| `test_show_thinking_truncates_overflowing_buffer` | edge | Long buffers tail-clipped with marker; never exceeds Telegram's 4096-char cap |
| `test_set_state_continues_after_transcript_opened` | happy | Indicator keeps rolling its state label after the user opens thinking — surfaces are independent |
| `test_show_tasklist_renders_todos_with_refresh_button` | happy | Tap on Show tasks renders `📋 Tasks N/M` + per-task emoji line; surface owns its Refresh button |
| `test_show_tasklist_refresh_edits_existing_message` | happy | Second tap on Refresh tasks edits the same message rather than posting another |
| `test_update_tasklist_overwrites_snapshot` | edge | TodoWrite emits the full list each call; snapshots overwrite (older versions are stale) |
| `test_success_finalises_tasklist_message_too` | happy | `success()` does one final refresh on both surface messages so post-mortem reflects last state |
| `test_both_surfaces_can_be_open_simultaneously` | edge | Thinking + tasks open at the same time; indicator's keyboard is NEVER swapped (Show/Show stays static) |
| `test_append_thinking_buffers_raw_block` | happy | append_thinking stores the raw extended-thinking text — no emoji prefix added |

---

### `tests/test_tools_server.py` — permission prompts (P11.5)

| Name | Kind | What it covers |
|---|---|---|
| `test_request_permission_auto_allow_for_safe_tool` | happy | Bash + non-claude path → auto-allow; no Telegram traffic |
| `test_request_permission_writes_telegram_for_claude_edit` | happy | Edit on a path containing `claude` posts a Telegram prompt with 3 buttons (Allow/Deny/See more); waits for verdict file |
| `test_request_permission_deny_returns_message` | happy | Owner taps Deny → tool returns `behavior=deny` with the operator's note ferried back to claude |
| `test_request_permission_no_owner_defaults_allow` | edge | No owner configured → default-allow + warning log (otherwise the prompt would hang forever) |

---

## Batch 4 — External triggers (P3 /inject)

### `tests/test_inject.py`

| Name | Kind | What it covers |
|---|---|---|
| `test_explicit_chat_id_is_used` | happy | A request with `chat_id` in the body targets that chat |
| `test_omitted_chat_id_falls_back_to_default` | happy | Missing `chat_id` → endpoint substitutes the configured `default_chat_id` |
| `test_source_label_propagated` | happy | The `source` field in the body becomes the channel-tag's `source` attribute (e.g. "alertmanager") |
| `test_healthz_no_auth_required` | happy | `/healthz` is a free probe — no bearer required |
| `test_orchestrator_runtime_error_returns_503` | happy | Orchestrator raising `RuntimeError` (claude down) maps to a 503, not a 500 |
| `test_no_auth_header_returns_401` | unhappy | Missing `Authorization` header → 401, orchestrator never called |
| `test_wrong_bearer_returns_401` | unhappy | Wrong token → 401, orchestrator never called |
| `test_non_bearer_scheme_returns_401` | unhappy | `Authorization: Basic <secret>` rejected — bearer-only endpoint |
| `test_short_partial_secret_rejected` | unhappy | A near-miss bearer (correct prefix, wrong suffix) → 401; constant-time compare prevents timing leak |
| `test_malformed_json_returns_400` | unhappy | Non-JSON body → 400 |
| `test_body_must_be_object` | unhappy | JSON array / scalar instead of object → 400 |
| `test_missing_prompt_returns_400` | unhappy | No `prompt` field → 400 |
| `test_empty_prompt_returns_400` | unhappy | Whitespace-only `prompt` → 400 |
| `test_invalid_chat_id_returns_400` | unhappy | `chat_id` that isn't an int → 400 |
| `test_source_label_truncated_to_32_chars` | edge | Adversarial caller sends a 999-char `source` — endpoint truncates to 32 chars before it lands in the channel tag |
| `test_concurrent_injects_all_accepted_and_serialized` | happy | 5 parallel injects all return 200; orchestrator sees exactly 5 submissions (turn lock serialises them, none lost) |
| `test_inject_during_in_flight_turn_queues` | edge | Inject arriving while a user turn holds the orchestrator lock blocks (queues), then runs once the turn releases. Pins lock-shared semantics with `submit_inbound` |
| `test_large_payload_rejected_gracefully` | unhappy | 5 MB body → 400 (or 413) — no 5xx, no crash. Server still serves the next request normally |
| `test_just_below_max_size_accepted` | edge | 900 KB body lands as 200; pins the aiohttp `client_max_size`=1 MB boundary so a future upgrade that lowers the limit surfaces here |
| `test_repeated_identical_inject_is_not_deduped` | edge | Contract pin: identical bodies posted twice produce TWO submissions. If we ever add idempotency keys, change here AND the test together |
| `test_burst_50_requests_no_state_leak` | happy | 50-request burst all return 200; orchestrator counter increments exactly 50× — no state leak / no rate limiter today |

---

## Batch 5 — Owner-only privileged ops + proactive notifications (P4 + P5)

### `tests/test_owner_ops.py`

Slash commands that ONLY fire for the configured `owner.user_id`. Anyone else's `/foo` falls through to claude. Commands: `/status`, `/pause`, `/resume`, `/abort`, `/restart`, `/new`, `/compact`. Destructive ops (`/restart`, `/new`) arm a 5-second cancel window — plain text "cancel" within the window aborts the pending op.

`notify_owner` is a best-effort §1.8 helper used by the orchestrator to ping the owner when claude crashes / is auto-restarted / hits a timeout. Failures must never propagate.

| Name | Kind | What it covers |
|---|---|---|
| `test_status_reports_running_when_idle` | happy | First `/status` (no traffic yet) reports "idle" + zero turns |
| `test_status_includes_last_inbound_preview` | happy | After traffic, `/status` shows turn count + last-inbound preview |
| `test_pause_flips_state_and_drops_subsequent` | happy | `/pause` flips `paused=True` and is idempotent on second call |
| `test_resume_restores_state` | happy | `/resume` clears the flag and is idempotent |
| `test_abort_stops_and_restarts_subprocess` | happy | `/abort` stops + restarts claude immediately (no cancel window) |
| `test_restart_arms_cancel_window` | happy | `/restart` arms a 5s pending op; `pending_destructive` populated; confirmation reply mentions "cancel" |
| `test_new_arms_cancel_window_with_correct_label` | happy | `/new` arms with label `"new"` (distinct from restart) |
| `test_cancel_aborts_pending_destructive` | happy | Plain "cancel" text clears the pending op + posts "Cancelled" reply |
| `test_compact_pipes_to_claude` | happy | `/compact` writes a `/compact` user-event to claude's stdin (uses claude's own conversation-compact slash command) |
| `test_compact_drains_result_so_next_turn_is_not_desynced` | happy | Regression: an earlier version of `/compact` wrote to stdin without consuming the resulting `result` event, so the next user turn's `read_events()` returned with empty text (silently dropping the prompt). Pin: `/compact` drains to its own `result` event |
| `test_compact_folds_concurrent_same_chat_inbound` | happy | While `/compact` is in flight, a same-chat inbound folds into the active turn (mid-turn inject §1.10) — both pushes appear in the agent's `received` before the result event |
| `test_destructive_restart_actually_fires` | happy | After the cancel window elapses, the restart task actually stops + starts claude |
| `test_destructive_new_drops_session` | happy | After the cancel window elapses, `/new` clears `continue_session` and assigns a fresh `session_id` (drops conversation context) |
| `test_notify_owner_formats_all_fields` | happy | `🔔 what / why: … / what to do: …` formatting pin |
| `test_notify_owner_minimal` | happy | `notify_owner(headline)` works without `why`/`todo` fields |
| `test_submit_inbound_owner_gate_runs_before_access` | happy | Owner `/status` is consumed by the gate at the TOP of `submit_inbound`, never reaches claude — pin the ordering |
| `test_submit_inbound_tracks_last_activity` | happy | Every accepted inbound updates `last_inbound_chat`/`preview`/`ts` and increments `turn_count` |
| `test_non_owner_slash_falls_through` | unhappy | A non-owner sending `/pause` does NOT consume the inbound; falls through to access-list. Owner-state unchanged |
| `test_unknown_slash_falls_through` | unhappy | Owner sending unknown command (`/explain`) falls through — claude can handle it |
| `test_plain_text_owner_falls_through` | unhappy | Owner's plain text reaches claude (no destructive pending → "cancel" check is also a no-op) |
| `test_arm_destructive_twice_warns` | unhappy | Arming `/restart` while one is already pending warns "already pending — reply 'cancel' to abort" instead of stacking |
| `test_compact_no_agent_attached` | unhappy | `/compact` when `claude is None` reports "No agent attached" instead of crashing |
| `test_handler_crash_returns_consumed_and_warns` | unhappy | A buggy handler that raises must still return `True` (consumed) — letting it fall through would double-process. Owner gets a "crashed" warning |
| `test_notify_owner_swallows_errors` | unhappy | If telegram is unavailable, `notify_owner` does NOT raise — best-effort |
| `test_commands_dict_shape_pin` | edge | The exact set of supported commands is pinned. Renames or additions surface here |
| `test_slash_is_case_insensitive` | edge | `/STATUS` and `/status` both work — friendlier on mobile keyboards |
| `test_cancel_with_no_pending_falls_through` | edge | Plain "cancel" with no pending op is NOT consumed (claude treats it as normal text) |
| `test_status_shows_pending_destructive` | edge | `/status` while a destructive op is armed reports "restart pending (Xs)" instead of "running" |
| `test_submit_inbound_paused_drops_silently` | edge | `paused=True` state drops new inbound silently — no claude turn, no reply |

§1.8 proactive notifications fired from the orchestrator:

- `_respawn_if_dead()` runs after every turn (both `submit_inbound` and `submit_external`). If claude exited between turns, it respawns and pings the owner with `notify_owner(...)` — exit code in `why`, "re-send the last message" in `todo`. Failure to respawn is also notified ("agent respawn FAILED"). Pinned by the integration tests above (orchestrator turns + the existing `_StubClaude` whose `_proc` attribute is `None`, which keeps `_respawn_if_dead` a no-op in unit tests).

---

## Batch 6 — Persistence + observability hooks (P6)

### `tests/test_events.py`

Pluggable `EventSink` interface. `AcceptEvent` for accepted inbound, `RejectEvent` for dropped. `StdoutSink` (dev), `HttpSink` (prod) — both implement `emit_accept` + `emit_reject`. `build_sink(config)` dispatches by `kind`. Fail-soft is mandatory: every adapter swallows errors at WARN level so external-store outage cannot back-pressure the runtime (spec §1.2 + P6 risk note).

| Name | Kind | What it covers |
|---|---|---|
| `test_accept_event_to_dict_shape` | happy | `AcceptEvent.to_dict()` produces the exact wire shape (type, source, chat, user, username, message_id, body in full, attachments list, ts ISO). Wire-format pin |
| `test_reject_event_to_dict_shape` | happy | RejectEvent shape pin |
| `test_accept_event_attachments_round_trip` | happy | Attachments tuple of opaque dicts round-trips through `to_dict()` |
| `test_stdout_sink_emits_one_json_line_per_event` | happy | StdoutSink prints one JSON object per line for both accept and reject |
| `test_http_sink_posts_accept_with_bearer` | happy | HttpSink.emit_accept POSTs JSON to the configured URL with `Authorization: Bearer <secret>` and `Content-Type: application/json`. Pinned against a real aiohttp catcher |
| `test_http_sink_posts_reject` | happy | RejectEvent flows through the same POST path |
| `test_http_sink_burst_100_messages` | happy | **P6 acceptance**: 100 sequential `emit_accept` calls produce 100 POSTs with bodies in order. No drops, no batching, no de-dup |
| `test_http_sink_swallows_connection_refused` | unhappy | Endpoint unreachable → WARN logged, no exception propagates. Spec §1.2 fail-soft pinned |
| `test_http_sink_swallows_non_2xx` | unhappy | 5xx response → WARN logged, no exception |
| `test_http_sink_swallows_timeout` | unhappy | Endpoint hangs forever → sink times out within `timeout_seconds`, WARN logged, returns |
| `test_build_sink_unknown_kind_raises` | unhappy | `kind: postgres` (not implemented) raises at startup, NOT silently in a swallowed warning |
| `test_build_sink_unknown_legacy_string_raises` | unhappy | Legacy string form: unknown name raises |
| `test_http_sink_requires_url` | edge | Empty `url` raises at construct time, not at first POST |
| `test_http_sink_requires_secret` | edge | Empty `secret` raises at construct time |
| `test_build_sink_legacy_stdout_string` | edge | P1-era `events.reject_sink: stdout` still resolves to StdoutSink (back-compat) |
| `test_build_sink_none_defaults_to_stdout` | edge | No config at all → StdoutSink. Deployments without a sink block keep working |
| `test_build_sink_dict_stdout_kind` | edge | Structured form `{kind: stdout}` resolves |
| `test_build_sink_dict_http_kind` | edge | Structured form `{kind: http, url, secret, timeout_seconds}` resolves to HttpSink with the right URL |
| `test_build_sink_pydantic_model_via_model_dump` | edge | `build_sink` accepts a pydantic model via `.model_dump()` so the parsed config block can be passed straight through |
| `test_event_sink_aclose_default_no_op` | edge | Base `aclose()` is a default no-op so `StdoutSink` (no override) doesn't raise on shutdown |

### `tests/test_telegram_client.py` (5 new attachment-extractor tests, batch 6 additions)

`_extract_attachments(message)` produces `(kind, file_id, mime_type?)` tuples without downloading binaries. Photo: keep the largest PhotoSize only (smaller ones are server-side downscales).

| Name | Kind | What it covers |
|---|---|---|
| `test_inbound_with_photo_extracts_largest_file_id` | happy | Photo → only the largest `file_id` (smaller PhotoSizes dropped — they're redundant references to the same image) |
| `test_inbound_with_document_includes_mime_type` | happy | Document → `{kind: document, file_id, mime_type}` |
| `test_inbound_with_voice_video_audio_sticker_all_extract` | happy | Pin every kind we recognise; sticker carries no `mime_type` (Telegram doesn't expose one) |
| `test_inbound_no_attachments_yields_empty_tuple` | happy | Plain text → `attachments == ()` |
| `test_inbound_document_without_mime_type_omits_field` | edge | Optional field omitted entirely (don't ship `mime_type: null`) |

### `tests/test_orchestrator.py` (3 new integration tests, batch 6 additions)

| Name | Kind | What it covers |
|---|---|---|
| `test_accepted_inbound_emits_accept_event` | happy | Allow-listed inbound triggers `events.emit_accept(AcceptEvent)` with full body, message_id, source. Pin so a refactor can't silently drop the call |
| `test_rejected_inbound_emits_reject_not_accept` | unhappy | Access-list rejection emits RejectEvent ONLY — pin: rejects never get cross-tagged as accepts (would clutter the dashboard with bot-probe spam) |
| `test_attachments_flow_through_to_accept_event` | happy | Telegram client's attachment tuple lands in `AcceptEvent.attachments` byte-for-byte |
| `test_emit_accept_failure_does_not_block_turn` | unhappy | Sink raising propagates from the orchestrator — explicit invariant pin: the orchestrator does NOT try/except around the sink. Adapters are responsible for being fail-soft. If a future change adds an orchestrator try/except, change here AND the test |

### `tests/test_config.py` (4 new sink-config tests, batch 6 additions)

| Name | Kind | What it covers |
|---|---|---|
| `test_events_sink_http_requires_url` | unhappy | `kind: http` with empty url fails at config load (loud, not silent in a swallowed warning) |
| `test_events_sink_http_requires_long_secret` | unhappy | Secret < 16 chars fails — defends against trivially guessable bearers when the ingest URL is internet-facing |
| `test_events_sink_http_valid` | happy | Full structured P6 sink config (with env-ref secret) loads cleanly |
| `test_events_sink_stdout_requires_no_url` | happy | `kind: stdout` does not require url/secret — operator can use the structured form without filling in fields they don't need |

---

## Batch 8 — Rate limits + typing indicator + hot reload + polish (P8)

### `tests/test_rate_limit.py`

Sliding-window `RateLimiter` with two independent budgets (per-chat, per-user). Either dimension can be `0` to disable. Denied calls do NOT count toward future budget — locked-out for `window_seconds`, not longer (friendlier to brief bursts; pinned by `test_denied_calls_do_not_count_against_future_budget`).

| Name | Kind | What it covers |
|---|---|---|
| `test_disabled_limiter_always_allows` | happy | Default config (0/0) is the no-op limiter |
| `test_user_dimension_limits` | happy | First N allowed, N+1 denied with `scope=user` |
| `test_chat_dimension_limits` | happy | Multi-user noisy chat: per-chat budget catches cross-user bursts |
| `test_window_slides` | happy | Old samples age out; budget refreshes |
| `test_independent_users_have_independent_budgets` | happy | One user's budget doesn't leak into another's |
| `test_retry_after_is_seconds_until_oldest_falls_out` | happy | `retry_after` math: oldest_sample + window - now |
| `test_denied_calls_do_not_count_against_future_budget` | unhappy | Design pin: hammering at the limit doesn't lock you out longer than the window |
| `test_zero_chat_disables_chat_dimension_only` | edge | Mixed config (chat=0, user=N) only enforces user dimension |
| `test_update_config_takes_effect_on_next_call` | edge | Hot-reload tightening takes effect immediately |
| `test_loosen_config_immediately_unblocks` | edge | Hot-reload loosening unblocks pending denials |
| `test_window_seconds_can_be_short` | edge | 0.5s windows work (CI compatible, fast tests) |

### `tests/test_typing_indicator.py`

Per-chat polling helper that calls `transport.send_chat_action` every 4s while a turn is in flight. Reference-counted attach/detach (forward-compat for concurrent turns on the same chat). Fail-soft: send errors are logged, the poller continues.

| Name | Kind | What it covers |
|---|---|---|
| `test_attach_starts_polling` | happy | Repeated chat_action calls fired while attached |
| `test_detach_stops_polling` | happy | After detach, no further calls |
| `test_two_chats_polled_independently` | happy | Two attached chats produce independent poll streams |
| `test_send_failure_does_not_kill_poller` | unhappy | Send raises → next tick still fires (fail-soft) |
| `test_attach_is_reference_counted` | edge | Two attaches → one task; one detach keeps polling, two detaches stop |
| `test_detach_unattached_chat_is_safe` | edge | Detach without prior attach is a no-op (no crash) |

### `tests/test_access.py` (3 new tests, batch 8 additions)

| Name | Kind | What it covers |
|---|---|---|
| `test_rate_limit_parses_from_access_block` | happy | `access.rate_limit` block parses to `RateLimitConfig` correctly |
| `test_rate_limit_default_is_zeros` | happy | No rate_limit block → all-zero (disabled). Don't surprise operators |
| `test_rate_limit_hot_reload_fires_callback` | happy | Editing the configmap fires `on_rate_limit_change` (also fires on initial load so the orchestrator doesn't have to push the value manually) |

### `tests/test_orchestrator.py` (2 new tests, batch 8 additions)

| Name | Kind | What it covers |
|---|---|---|
| `test_rate_limit_drops_with_reject_event` | unhappy | Non-owner over budget → RejectEvent reason='rate-limited-user', message never reaches claude. Pin: rate gate runs AFTER access gate |
| `test_owner_is_exempt_from_rate_limit` | happy | Owner sends 5 messages with `user_per_minute=1` and all 5 are accepted. Operator must reach the bot during a flood |

---

## Acceptance scripts (out-of-band, e2e against real Telegram)

These are NOT pytest — they talk to live Telegram and burn API quota. Run when finalising a batch:

```bash
set -a && source <(grep -v TEST_DC_ADDR .env) && set +a
.venv/bin/python scripts/smoke_p1_echo.py
.venv/bin/python scripts/smoke_p2_claude.py
.venv/bin/python scripts/smoke_p4_owner.py        # batch 5: non-owner gate fall-through
.venv/bin/python scripts/smoke_p4_owner_full.py   # batch 5: full owner-side e2e (10/10 commands)
                                                  #   — temporarily set owner.user_id to the
                                                  #   test user's id in the configmap, restart
                                                  #   pod, run, then revert.
.venv/bin/python scripts/smoke_p6_persistence.py  # batch 6: 3 inbound → 3 AcceptEvents at catcher
                                                  #   — needs the catcher pod from
                                                  #   /tmp/catcher.yaml deployed and configmap
                                                  #   pointing events.sink at it.
.venv/bin/python scripts/smoke_p6_failsoft.py     # batch 6: catcher down → bot still replies
                                                  #   — scale catcher to 0 first, run, expect
                                                  #   reply within 90s + WARN log entry.
.venv/bin/python scripts/smoke_p8_rate_limit.py   # batch 8: spam → rate-limit drops in pod logs
                                                  #   — temporarily set access.rate_limit.user_per_minute=3
                                                  #   in configmap, restart pod, run; expect at
                                                  #   least 2 'rate-limit drop' lines in logs.
```

Both are kept around for historical reference; the v0.3+ deploy is exercised end-to-end by sending a message via the Trung user session and verifying the reply nonce makes it back. See the deploy README for the loop.

---

## Adding new tests

When a new capability lands, this catalogue should grow with at least one
row per kind for the new module. Aim for:

- **Happy** — the success path with the simplest valid inputs
- **Unhappy** — at least one explicit rejection or validation failure
- **Edge** — at least one boundary, byte-level format pin, or
  "surprising-but-load-bearing" behavior

If the new code has no obvious unhappy path, ask whether that's because
the function trusts its inputs (then no unhappy needed) or because the
rejection is implicit and could regress silently (then add one anyway).

When closing a bug, add a test here named after the symptom — e.g.
`test_subprocess_id_collision_returns_error` — so the regression suite
keeps the bug from sneaking back.
