# Waggle — Design notes

> Author: Your Name (Claude)
> Status: living doc — fills in the technology choices REQUIREMENTS.md
> deliberately keeps abstract.

This doc captures the *why* behind concrete implementation decisions
that REQUIREMENTS.md and ROADMAP.md hold at arms' length. If you're
reading code and wondering "why this and not the obvious other thing?",
the answer is here.

---

## 1. Why a long-lived `claude -p` subprocess (vs MCP-channel push)

The natural design for "agent receives chat events" is the MCP
`claude/channel` capability: an MCP server pushes
`notifications/claude/channel` to claude, claude treats them as user
turns. waggle would be a stdio MCP server.

That capability is **gated server-side** by the Anthropic API and the
chat.trollllm.xyz proxy waggle deploys against. Repeated probing in
March 2026 confirmed the channel notification raises *"channels
feature is not currently available"* on third-party-gateway tokens
(anthropics/claude-code#36665). It is not a transient gating; the
feature is not yet implemented for non-Anthropic-Max consumers.

The fallback is the stream-json subprocess pattern used by ductor and
others:

```
waggle (parent)
  ├─ claude -p --input-format stream-json --output-format stream-json
  │       (long-lived; one subprocess per pod; restart on /restart)
  └─ MCP server: tools_server.py (loaded by claude via --mcp-config)
```

Inbound: a Telegram message becomes a stream-json `user` event written
to claude's stdin. Outbound: claude calls the MCP `reply` tool, which
runs in a child of claude and talks to Telegram directly.

Trade-offs:

| Capability | MCP-channels (blocked) | stream-json (shipped) |
|---|---|---|
| Multi-source push | Cleanly per-source | Per-source via channel-tag wrapping in stdin |
| Cross-restart context | claude session persists | `--continue` restores |
| One process, many transports | Yes | Yes |
| Backpressure semantics | MCP-defined | Single-turn lock |
| Operator visibility | Server-side | `kubectl logs` |

The stream-json form has one downside: claude reads from stdin, which
means waggle has to wrap inbound in a synthetic user-message block.
The `<channel source="…" chat="…" user="…" ts="…">BODY</channel>` tag
is the wire format that lets claude tell sources apart in the same
session (see §2).

## 2. Channel-tag wire format

Pinned by `tests/test_channel_tag.py`. The tag is **frozen** — every
transport speaking it would need a coordinated update.

```
<channel source="telegram" chat="42" user="908624017" ts="2026-04-30T07:00:00Z">
hello agent
</channel>
```

Decisions:

- **XML-ish syntax** — claude is good at reading structured tags. JSON
  inside the prompt would invite the model to echo it back.
- **Attribute escaping** — `&  <  >  "` escape to XML entities; bodies
  are NOT escaped (they're chat content). A body containing
  `</channel>` round-trips as the literal close — callers must reject
  upstream. Pinned by `test_body_with_literal_close_tag_breaks_parser`.
- **Second-resolution timestamp** — coarser than Telegram's; finer
  than humans need. `microseconds_truncate` test pins this.

## 3. Outbound via MCP tools (vs parsing claude's `result` text)

claude's `result` event in stream-json mode contains the model's final
free-text turn. An obvious design is "read the result, send to Telegram".

We don't, because:

1. The model often emits intermediate tool calls (`reply`, `react`)
   AND a final `result`. Both should reach the user — the tools render
   fine; the result text is usually a redundant summary.
2. Multiple replies in one turn (e.g. a reaction + a long answer) need
   distinct sends. Tool calls already give us that.
3. The model can choose richer surfaces: `react`, `edit_message`,
   `send_to_chat` to a different room. Parsing text can't.

So waggle reads `result` only for telemetry (truncated preview in
logs); user-facing delivery is exclusively via MCP tools.
`tools_server.py` is the dispatcher.

## 4. Sink interface evolution (P1 → P6)

P1 shipped only `events.reject_sink: stdout` — a string field. P6
needs structured config (kind/url/secret/timeout for HTTP). Backwards
compat matters because pre-P6 deployments must keep working without a
config bump.

`build_sink(spec)` accepts both:

- Legacy string: `"stdout"` → `StdoutSink()`
- Structured dict / pydantic: `{kind: http, url: …, secret: …}` → `HttpSink(...)`

Pinned by `test_build_sink_legacy_stdout_string` and
`test_build_sink_dict_http_kind`.

`Events.sink` (structured) takes precedence when present; otherwise
`Events.reject_sink` (legacy) is used. Both fields coexist in the
pydantic model so a typo on the new field doesn't silently fall back
to the legacy field.

## 5. Hot reload via mtime polling

`AccessControl` polls the config file's mtime every 1s. On change, it
re-loads and atomically swaps the in-memory `AccessRules`. Failures
during reload **keep the last-good rules** — pinned by
`test_reload_keeps_old_rules_on_yaml_error` and
`test_reload_keeps_old_rules_on_file_deleted`.

Why mtime polling vs inotify:

- inotify needs Linux-specific mounts and is fiddly across container
  filesystem layers (overlayfs, configmap projection, …)
- The poll cost is negligible (one stat/sec)
- Cross-platform: same code runs on macOS dev laptops

The same poller now also reloads `RateLimitConfig` (P8). The
orchestrator registers a callback (`on_rate_limit_change`) so the
RateLimiter updates its budget atomically. Existing window samples
are kept — the new budget evaluates the next call, doesn't
retroactively reject.

## 6. Two indicators (StatusIndicator + TypingIndicator)

P2.5 ships `StatusIndicator` — a rolling reply message that walks
through "🤔 Thinking…" → "🔧 Tool: …" → "✏️ Writing…" and
deletes/replaces on success/error.

P8 adds `TypingIndicator` — Telegram's native chat-header `typing…`
indicator, refreshed every 4 seconds.

The two are complementary, not redundant:

| Surface | StatusIndicator | TypingIndicator |
|---|---|---|
| Where shown | Reply message in chat | Chat header / list item |
| Information | Stage name (Tool: foo) | Generic "typing" |
| Persists past turn | No (deleted on success) | Auto-clears after 5s |
| Telegram primitive | sendMessage + edit | sendChatAction |
| Best for | Long turns, debugging | Quick visual feedback |

Both can be disabled independently. A future polish: a config knob
`indicators: [status, typing]` to opt out per chat.

## 7. Rate limiting — sliding window, in-memory, per-pod

Two dimensions: per-chat (one noisy room can't burst) and per-user
(one chatty user across rooms can't drown the agent). Either dimension
being over budget rejects.

Decisions:

- **Sliding window over a deque of timestamps.** Token bucket would
  also work; deque is dead simple and the constants are small.
- **In-memory, per-pod.** No external store. Pod restart resets the
  budget. This is a noisy-neighbour defence, not a billing primitive
  — durable budgets belong in a dedicated quota service.
- **Owner is exempt.** The operator must be able to `/pause`, `/status`
  during a flood. Pinned by orchestrator: `if user_id !=
  config.owner.user_id: rate_limiter.check(...)`.
- **Hits are counted on every call**, including rejected ones. A flood
  pushes the window forward and the limit becomes durable. Without
  this, a rejected sender could be just-below-the-limit forever.

## 8. Why no Postgres / S3 sink today

`HttpSink` is the only non-stdout adapter shipped. Spec §1.2 says
"interface-defined; concrete adapter could be Postgres / S3 / dashboard
ingest endpoint" — so the choice is deliberately not in the spec.

Reasons HTTP first:

- Most dashboards expose an ingest endpoint already
- Bearer auth is standard; we can re-use the same secret-handling
  shape as `/inject`
- aiohttp is already a dep (used by the inject server)
- Postgres adds asyncpg + connection pool + schema migrations
- S3 adds boto3 + bucket policy management

Adding Postgres is ~30 lines of `events.py` plus a config branch;
nothing in the call sites changes.

## 9. What's intentionally NOT in waggle

Per REQUIREMENTS.md §3 "won't do", and confirmed during build:

- **Scheduling.** `/inject` accepts external triggers; what hands them
  in (cron, Linear webhook, alertmanager) is the operator's choice.
- **Tool registries / multi-agent supervision.** waggle is the chat
  layer. Tool routing belongs to claude-code or whatever agent is
  driving.
- **E2E encryption (Matrix).** v1 explicitly skips e2ee — unencrypted
  rooms only. Re-evaluate when there's a real Matrix user need.
- **Persistent message archives in waggle.** P6 emits to an external
  store; we never write to local disk. The archive is the operator's
  problem.
