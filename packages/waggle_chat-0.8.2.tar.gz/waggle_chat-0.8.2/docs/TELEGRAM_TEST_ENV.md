# Telegram Test Environment

This repo has two separate Telegram test paths:

- Telegram Bot API smoke tests for a real bot token.
- Telegram test data center (test DC) user login tests for MTProto clients such as Pyrogram and Telethon.

Use the test DC path when an automated agent needs a disposable Telegram user without a real phone number.

## Install

From the repo root:

```bash
uv venv --python 3.12
uv pip install -e ".[dev,telegram-test]"
uv run python scripts/check_test_env.py
```

Set your Telegram app credentials before running MTProto scripts:

```bash
export WAGGLE_TG_API_ID=33895351
export WAGGLE_TG_API_HASH="<your-api-hash>"
export WAGGLE_TG_TEST_DC=2
export WAGGLE_TG_TEST_DC_ADDR=149.154.167.40:443
```

Do not commit the real API hash. `.env.example` contains placeholders only.

The current local `.venv` was created by `uv` and already has Pyrogram, Telethon, and TgCrypto installed, but it was missing `pip`. Prefer `uv pip ...` for repeatable setup.

## Test DC Rules

Telegram test DC phone numbers use this form:

```text
99966XYYYY
```

- `X` is the test DC id: `1`, `2`, or `3`.
- `YYYY` is any four digits.
- The login code is usually `X` repeated five times, for example `22222` for `9996621234`.
- Some Telegram client docs note that six digits may be required, so the scripts try both five and six digits.
- Test DC accounts are public/disposable. Never store sensitive data there.

Known test DC addresses used by the scripts:

```text
1 -> 149.154.175.10:80
2 -> 149.154.167.40:80
3 -> 149.154.175.117:80
```

Override the address with `WAGGLE_TG_TEST_DC_ADDR` if your Telegram app page shows a different endpoint.

## Agent-Friendly Commands

Run the environment check:

```bash
uv run python scripts/check_test_env.py
```

Run a non-interactive Pyrogram test DC login:

```bash
uv run python scripts/test_dc_login.py 9996621234
```

Run a non-interactive Telethon test DC login:

```bash
uv run python scripts/test_dc_telethon.py 9996621234
```

Avoid `scripts/test_dc_login_v2.py` for automated runs. It uses Pyrogram's `start()` flow and can fall back to stdin if Telegram rejects the supplied code.

Current observed behavior with Pyrogram 2.0.106 and Telethon 1.43.2:

- Network connectivity to test DC works.
- `send_code` succeeds.
- Login can still fail with `PHONE_CODE_INVALID` for generated test accounts.
- Telethon 1.43 refuses third-party sign-up with `Third-party applications cannot sign up for Telegram`.

So this path is useful for verifying connectivity and auth-flow code, but a fully automated end-to-end user test now needs either a pre-created reusable test DC session or the production user-session path below.

## Production Bot Smoke Test

For a real Telegram bot token, create a user session once:

```bash
uv run python scripts/login_programmatic.py +<real-phone-number>
```

When the script says the code was sent, write the code to:

```bash
/tmp/waggle-tg-code.txt
```

Then test a bot:

```bash
uv run python scripts/echo_to_bot.py @<bot_username>
```

This production path uses a real Telegram user account and is not the same as the test DC path.
