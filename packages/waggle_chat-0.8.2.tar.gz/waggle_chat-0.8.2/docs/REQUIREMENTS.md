# waggle — Requirements

> Author: Your Name (Claude)
> Status: Draft v0.3
> Audience: business / product. Implementation details (libraries, endpoints, metric names, file formats, auth mechanics) live in `docs/DESIGN.md`, not here.

---

## 0. Overview

waggle is a thin runtime that wires **one agent** to **many chat platforms**. It carries messages between the two, nothing more — it does not decide what the agent should remember, when it should speak, or which tools it can call.

The product question we are answering: *"Where should the chat-side plumbing of an AI agent live?"* Today it is half inside the agent, half inside ad-hoc plugins. waggle pulls that plumbing into one well-scoped layer that one human can control.

### Design pillars

- **One agent, many channels.** The same agent answers from Telegram, Matrix, Discord, … and always carries a single, unified context — never split into per-chat or per-topic conversations.
- **Strict scope: the chat layer only.** Scheduling, tool registries, multi-agent supervision, persistent message archives — all out of scope. They live upstream or downstream of waggle, not inside it.
- **Owner is sovereign.** Exactly one human is the owner. Only the owner can restart the agent, reset a session, compact memory, or see runtime status. Everyone else just chats.
- **External world can knock.** Alerting tools, CI, or schedulers can push prompts into the agent's active chat through authenticated triggers — but they can never invoke owner-only operations.
- **Tweakable settings, stable runtime.** Most configuration changes apply hot. Restarts are rare and predictable.

### Mental model

```
external trigger ─┐
                  ├─→ waggle ─→ agent ─→ waggle ─→ chat platforms
chat platforms ───┘
```

waggle sits in the middle. Inputs (chat messages, external triggers) flow in. Outputs (replies, reactions, edits) flow out. Owner-only operations (restart, status, …) are a side-channel only the configured owner can reach.

---

## 1. Capabilities (must)

> Each subsection lists the phase that first delivers it. See `ROADMAP.md` § "Requirement → phase map" for the full matrix and dependency analysis.


### 1.1 Multi-platform reach
*Phase: P1 (Telegram) → P7 (Matrix)*

- Reach the user through Telegram on day 1
- Add a new chat platform (Matrix, Discord, …) later without breaking existing ones
- Run multiple platforms in parallel for the same agent when the owner wants

### 1.2 Receive messages
*Phase: P1 (text) → P2 (attachments) → P6 (persist)*

- Every incoming message reaches the agent labelled with: which platform it came from, which chat, and which user sent it
- Attachments (images, audio, documents) reach the agent in a form it can use
- Inbound messages are acknowledged to the platform fast — never make the platform wait on agent latency
- Every accepted incoming message is persisted in full (body, attachments-by-reference, metadata) to an external store so a dashboard can render the history later — never to local disk on the agent host

### 1.3 Send messages
*Phase: P1 (text) → P2 (reply, react, edit, choices)*

- Agent can reply (text, with optional formatting)
- Agent can react with an emoji to a previous message, where the platform supports it
- Agent can edit a message it previously sent, where supported
- Agent can attach **selectable choices** to a reply (Telegram inline keyboard, Matrix buttons / quick replies, …); the user's choice flows back to the agent as a labelled incoming message just like a normal text message
- When a feature is not supported by a particular platform, fail gracefully — never crash

### 1.4 External triggers (inject)
*Phase: P3*

- An external system (alerting tool, CI, scheduler, …) can push a prompt that gets delivered to the agent's active chat
- Every external trigger requires a shared secret — no anonymous injects
- The trigger can target a specific chat, or fall back to a configured default chat

### 1.5 Access control
*Phase: P1, refined P11*

- DMs: only allow-listed users can send messages to the agent
- Groups: the group chat itself must be on the allow-list. Per-group `users` is a finer-grained filter:
  - Non-empty → only those user_ids in this group are allowed (use when only a few trusted humans in a noisy group should drive the agent)
  - Empty / omitted → ANYONE in the group is allowed (the group whitelist is the trust boundary; matches the semantics of Anthropic's claude-code Telegram MCP)
- Groups can additionally require explicit addressing via `require_mention: true` — only `@bot` mentions or replies to bot messages reach the agent. Lets the bot live silently in a noisy group.
- Rejected messages are silently dropped (no reply to the rejected sender); rejection events are emitted to an external observability channel (a dashboard later on) — never written to local disk
- The allow-list can be updated without restarting the agent
- Slash commands sent in groups are rejected outright (the operator surface is DM-only) — never spend an agent turn on `/something`-prefixed messages from a group

### 1.6 Configuration
*Phase: P0*

- All settings live in a single configuration source
- Most settings can be changed without restart (allow-list, language, rate limits, …)
- Ship a documented sample configuration

### 1.7 Owner-only operations
*Phase: P4*

There is exactly **one owner**. Only the owner may invoke the following — every other sender is rejected.

- **Agent supervision**
  - See the agent's liveness and what it is currently doing (idle / processing / waiting on a tool / blocked)
  - Restart the agent
  - Pause / resume new-message processing without killing the agent

- **Session management**
  - Start a fresh session for the current chat (drops accumulated context)
  - Cancel the in-flight turn without ending the session

- **Memory compaction**
  - Trigger the underlying CLI's conversation-compact action

Constraints:

- Every privileged op verifies the caller is the configured owner
- Privileged ops are never invoked from external triggers (those are for non-human callers)
- Destructive ops (restart, fresh session, …) honour a short cancel window

### 1.8 Owner notifications
*Phase: P5*

waggle proactively notifies the owner whenever the agent's session or conversation changes by itself (not because the owner asked). The owner is the only audience — these never reach the chat.

Examples of events that should notify:

- The conversation was auto-compacted because it hit the model's context limit
- The agent restarted itself after a crash or supervisor signal
- A turn was aborted because it ran past its timeout
- New-message processing was paused or resumed by something other than an owner command
- The current session was reset by a recovery routine

Constraints:

- Notifications are best-effort — losing one is acceptable; never block the agent waiting on delivery
- Each notification states what happened, why, and what the owner can / should do about it (if anything)

### 1.9 Working-status indicator
*Phase: P2.5, expanded with Show-thinking + Show-tasks surfaces*

While the agent is processing one or more pending inbound messages, waggle MUST surface its current activity inline in each affected chat as a single rolling status message that updates in place.

Rolling-state lifecycle (per turn):

- An inbound message from chat C creates one status message in chat C if none currently exists for the active turn; subsequent inbounds from the same chat during the same turn reuse the existing status message
- The set of chats with an active status message is tracked in a per-turn working-set
- While the agent's state changes, every status message in the working-set is edited in place to reflect the new state
- The status message uses a short emoji-prefixed label:
  - `🤔 Thinking…`
  - `🔧 Tool: <tool_name>` (tool name only — never arguments)
  - `📝 Writing reply…`
- On normal stop (turn finished), every status message in the working-set is deleted and the working-set is cleared
- On error (agent failure), every status message in the working-set is deleted, a new error reply (`❌ Error: <message>`) is sent in each chat in the working-set, and the working-set is cleared

The status message also carries an inline-keyboard with two buttons that open richer post-mortem surfaces in their own messages:

- **🧠 Show thinking** — first tap posts a NEW reply (replying to the original inbound for context) containing the agent's accumulated extended-thinking blocks. Subsequent taps refresh that same message with the latest buffer. The thinking message itself carries a 🔄 Refresh button — the user refreshes from the surface they're reading, not from the indicator.
- **✅ Show tasks** — same lifecycle as thinking, but renders the latest TodoWrite snapshot (`✅ completed / 🔄 in_progress / ⏳ pending` per item, header `📋 Tasks N/M`). TodoWrite snapshots overwrite (the agent emits the full list each call), so older versions don't matter.

Constraints:

- Edits are debounced to stay under the platform's edit rate limit (Telegram: ~20 edits/min/message). State changes faster than the debounce window are coalesced into the latest state.
- Status messages live in the same chat as the inbound that created them — never cross-chat broadcast
- The status message is independent of the actual reply: replies are posted as their own messages alongside, not by editing the status
- Tool arguments must never appear in the status message — privacy concern in group chats
- The thinking and tasks surfaces are NEW messages, not edits of the indicator. The indicator's keyboard is static (Show/Show); each surface message owns its own Refresh button.
- The indicator is deleted on success regardless of whether the user opened thinking/tasks. The thinking and tasks messages persist (post-mortem), with one final refresh on turn end so they reflect the full final state.
- This indicator is visible to every member of each affected chat, not owner-only.
- Extended thinking content is model-dependent: sonnet and haiku emit non-empty blocks; opus redacts content (always empty); some 3rd-party Anthropic-compatible gateways strip thinking blocks entirely. The empty-buffer placeholder explains this so the user understands why content might be missing.

Out of scope:

- Per-step progress (1/5, 2/5…) — the granularity is just thinking / tool / writing
- Per-inbound acknowledgement reactions when the same chat sends multiple messages during one turn — the single rolling status is enough
- Crash watchdog / orphan cleanup — agent crashes are assumed not to occur in this deployment

### 1.10 Mid-turn message folding
*Phase: P12*

When a user sends multiple messages in quick succession from the same chat, waggle MUST fold the later ones into the running turn — the agent picks them up between agentic-loop rounds and merges them into the current response, rather than queueing them as separate turns.

Behaviour:

- Same chat, second-and-later inbound during a running turn: push the new user event onto the agent's stdin immediately, do not start a new turn
- Different chat inbound during a running turn: wait for the current turn to end, then claim the active-chat slot and push (cross-chat folding would leak context across users)
- All folded waiters return when the agent emits its single `result` event covering the merged turn

Why: a chatty operator typing "do X. and also Y." across two messages should not pay two full agent turns; the fold pattern lets the agent see both messages in the same conversation round so the response is coherent.

Constraints:

- Concurrent stdin writes to the agent subprocess are serialised (newline-delimited JSON frames mustn't interleave) — the fold is logical, but the wire is one event at a time
- The active-chat slot uses condition-variable semantics: same chat folds without waiting; different chat waits on the slot becoming free
- Cross-chat isolation is non-negotiable: a stranger's message must never reach the agent while another user's turn is running

Out of scope:

- Folding across multiple chats simultaneously — explicitly forbidden
- Pre-empting an in-flight tool call mid-execution — the new user event arrives at the next inference round, not mid-tool

### 1.11 Permission prompts
*Phase: P11.5*

When the agent attempts a tool whose effect could surprise the operator (writes/edits to files that look operator-relevant), waggle MUST ask the operator for explicit allow/deny via Telegram before the tool runs.

Modes (configured per agent):

- **bypass** — pass `--dangerously-skip-permissions` to the agent; every tool runs without prompting. Trust boundary is the container, not per-tool. Default for sandboxed deployments.
- **claude_files** — auto-allow safe tools; route Edit/Write/MultiEdit/NotebookEdit on a path containing the substring `claude` to Telegram for owner approval. Mirrors the Anthropic plugin's behaviour for editing files inside `~/.claude/`.
- **strict** — every tool_use prompts for owner approval (slow; for admin bots).

Prompt UX:

- Telegram message to each owner chat with the tool name, target path, and three buttons: ✅ Allow, ❌ Deny, 🔍 See more (to expand the full input on demand)
- 10-minute timeout — silent owner means deny (so an absent operator doesn't accidentally allow a destructive op)
- No owner configured → default-allow with a warning log (otherwise the prompt would hang forever waiting for nobody to tap)

Constraints:

- Tool input is persisted to a per-request file under a shared `/tmp/waggle/permissions/` directory so the parent waggle's callback handler can read the full args on demand. Cleaned up after the verdict arrives.
- Verdicts ferry across the parent ↔ tools_server boundary via the same file directory (request_id keyed) — same pod, shared filesystem, no extra IPC stack needed.
- The "ask" decision lives entirely in the tools_server child; waggle's parent only renders the prompt and writes the verdict back.

### 1.12 Per-agent model + reasoning effort knobs
*Phase: P12*

The operator MUST be able to pin the model and the extended-thinking effort level per agent without rebuilding the runtime image.

- `CLAUDE_MODEL` env → forwarded to the agent CLI as `--model X` (alias or full version, e.g. `sonnet`, `opus`, `claude-sonnet-4-6`)
- `CLAUDE_EFFORT` env (optional) → forwarded as `--effort X` where X is one of `low / medium / high / xhigh / max`

Why explicit: the agent CLI's baseline default model emits empty extended-thinking blocks even for reasoning-heavy prompts (verified live). Naming a model that's known to emit reasoning content (sonnet, haiku) is what makes the §1.9 Show-thinking surface useful. Without these knobs, every bot would silently fall back to the empty-thinking default.

---

## 2. Nice to have

- Matrix support on day 1 alongside Telegram
- Rate limits per chat and per user
- A small working example so a new user can verify the integration in minutes

---

## 3. Won't do

- Cron / scheduling — that lives in a separate scheduler that fires our inject trigger
- Managing more than one agent — waggle owns exactly one agent
- Acting as a tool registry — waggle is a chat layer, not a tool layer
- Switching between CLIs (Claude / Codex / Gemini) — that is the agent's concern
- Storing message history beyond what the chat platform itself keeps
- Splitting forum-group topics into separate conversations — the agent always has a single, unified context across every chat it participates in
- Exposing the owner-only operations to anyone other than the owner

---

## 4. Open questions

- How does the owner reach the privileged operations — through chat commands, a host-side CLI, an authenticated remote call, or any combination? (Decide at implementation time.)
- Do rate limits apply globally, per platform, per chat, or all three?
- How is the allow-list reloaded — automatic on file change, on a manual command, or on a signal?

---

## 5. Why a separate project (vs ductor)

The headline reasons live in the README. The short version: we want only the chat-layer slice; our deployment is multi-pod Kubernetes, not a single user laptop; and we want to evolve the channel wire format without staying compatible with an upstream that has a broader audience.
