# waggle — Implementation Roadmap

> Author: Your Name (Claude)
> Status: Draft v0.1
> Source of truth: `docs/REQUIREMENTS.md`

The roadmap turns the requirements into deliverable phases. Each phase is **shippable on its own** — the previous phase keeps working while the next one is built. We move forward only when the current phase's acceptance gate is green.

---

## Phase 0 — Foundation

**Goal.** Lay down the skeleton no other phase can start without.

**Includes**

- Python package layout, lint/test/build pipeline
- Transport interface (`BotProtocol`-equivalent): one shared contract every chat platform plugs into
- Single configuration source (file + env override) with a documented sample
- Channel-tag wire format (`<channel source=… chat=… user=…>`) frozen as v1

**Acceptance**

- `pip install -e .[dev]` plus `pytest` runs green on a stub transport
- Sample config validates on load; missing required fields fail loudly
- A no-op transport can be loaded by name from config and registered in the runtime

**Out of scope here.** Any specific platform. No real Telegram yet.

---

## Phase 1 — Telegram echo (proof of life)

**Goal.** A real Telegram bot that receives a message, ack's the platform fast, and sends back a static reply. No agent yet — the "agent" is a deterministic echo function.

**Includes**

- Telegram adapter implementing the transport interface
- Inbound: message → channel tag → handler queue
- Outbound: text reply
- Dual allow-list enforcement (group + user); rejected messages silently dropped
- Allow-list hot reload (file-watched)
- Reject events emitted as structured outbound events (printed to stdout for now; external channel comes later)

**Acceptance**

- Allow-listed user DMs the bot and receives an echo within 1s
- Non-allow-listed user gets no reply; a reject event appears in stdout
- Editing the allow-list file takes effect without restart, verified by adding a new user mid-run

**Risk.** Telegram API rate limits; long-poll vs webhook choice. Pick long-poll for simplicity in this phase.

---

## Phase 2 — Real agent + rich messaging

**Goal.** Replace the echo with a real Claude Code subprocess; expose the full reply surface (reactions, edits, inline-keyboard choices, attachments).

**Includes**

- Embed/spawn the agent CLI (`claude` to start) and bridge stdin/stdout to the transport
- Inbound attachments (images required; audio + documents nice-to-have here, MUST in P-Polish)
- Outbound: reply (with formatting), react with emoji, edit prior message
- **Selectable choices** (Telegram inline keyboard); user's tap delivered back as a labelled inbound message
- Graceful degrade: if a feature isn't supported by the platform, log and skip — never crash

**Acceptance**

- Real agent answers a question end-to-end through Telegram
- Bot can offer "yes / no / cancel" inline buttons; clicking returns a usable message to the agent
- Image sent to bot reaches the agent as a usable file path / URL
- Graceful-degrade test: a fake feature flag set to off causes "not supported" log, no crash

**Risk.** CLI lifecycle (zombie processes, resume on crash). Defer crash recovery to P5.

---

## Phase 2.5 — Working-status indicator

**Goal.** Surface the agent's live activity in each affected chat as a single rolling status message that edits in place during a turn and is removed on completion.

**Includes**

- Per-turn working-set: in-memory `set[chat_id]` tracking which chats have an active status message
- State source: parse `claude --output-format stream-json` events into a small set of states — `thinking` / `tool:<name>` / `writing` / `done` / `error`
- Adapter responsibilities:
  - Inbound from chat not in the set → create status message, add chat to set
  - State change → edit every status message in the set to the new label
  - Stop → delete every status message in the set, clear set
  - Error → delete every status message in the set, send `❌ Error: <message>` reply in each chat, clear set
- Debounce: coalesce state changes faster than the platform edit rate limit (Telegram ~20 edits/min/message). 1.5s window is a reasonable default.

**Acceptance**

- A message that triggers one tool call shows: `🤔 Thinking…` → `🔧 Tool: <name>` → `📝 Writing reply…` → bot reply (separate message) → status message deleted
- Two chats both messaging during one turn each see their own status message, both edited in lockstep with the agent's state
- A forced agent failure produces an error reply in every pending chat and removes the status messages
- Two messages from the same chat during one turn share one status message (no duplicate)

**Risk.** Stream-json event coverage if claude-code adds new event shapes — keep the parser strict on known events and ignore unknown ones rather than crashing.

---

## Phase 3 — External triggers (inject)

**Goal.** Let alerting / CI / cron systems push prompts into the agent's active chat.

**Includes**

- Authenticated HTTP endpoint accepting JSON payloads (shared-secret check; bearer or HMAC)
- Inject targets a specific chat, or falls back to a configured default chat
- Inject events flow through the same channel-tag pipeline as user messages, with `source="external"` label

**Acceptance**

- `curl -H "Authorization: Bearer <secret>" -d '{"prompt":"..."}' https://.../inject` lands in the configured chat as a user-style message
- Wrong / missing secret returns 401, never reaches the agent
- Omitting `chat_id` falls back to default; specifying `chat_id` overrides

**Risk.** Endpoint abuse. Always secret-required, no public path.

---

## Phase 4 — Owner controls

**Goal.** Hand the human operator a private console for the agent.

**Includes**

- Owner identification (single `owner_user_id` in config)
- Owner-only operations exposed via slash commands in the owner's DM:
  - `agent status`, `agent restart`, `agent pause`, `agent resume`
  - `session new`, `session abort`
  - `memory compact`
- Caller-is-owner gate; non-owner attempts get a structured rejection
- Privileged ops never invoked from external triggers (P3 endpoint blocked path)
- Destructive ops (`agent restart`, `session new`) honour a 5-second cancel window

**Acceptance**

- Owner runs `/agent status` and sees liveness + current activity (idle / processing / waiting / blocked)
- Non-owner runs the same command and gets denied; reject event emitted
- `/agent restart` countdown shows and can be cancelled within 5s; if not cancelled, agent process restarts cleanly

**Risk.** Privileged surface mistakes are unrecoverable; favour confirmation prompts and a generous cancel window.

---

## Phase 5 — Owner notifications

**Goal.** Pro-actively tell the owner when the agent's session changed by itself.

**Includes**

- Notification dispatch path (owner-only DM, never to chat)
- Triggers wired in:
  - Auto-compact happened (CLI emitted compact event)
  - Agent process crashed and was restarted by supervisor
  - In-flight turn aborted on timeout
  - Recovery routine reset the session
  - Pause / resume was triggered by something other than an owner command
- Each notification states **what / why / what to do**; best-effort delivery

**Acceptance**

- Force-killing the agent process triggers a "I restarted, last activity was X" notification within 10s
- Triggering an oversized prompt that hits context limit results in an "auto-compacted" notification

**Risk.** Notification spam if events bunch up. De-duplicate within a short window (e.g. 30s).

---

## Phase 6 — Persistence & observability hooks

**Goal.** Push everything outward so a dashboard can render history without waggle keeping local state.

**Includes**

- Every accepted incoming message persisted in full (body, attachments-by-reference, metadata) to an external store (interface-defined; concrete adapter could be Postgres / S3 / dashboard ingest endpoint)
- Reject events also pushed to the same external observability channel
- No local disk writes for either of the above
- Adapter interface for "where do these go?" so the deployment can choose

**Acceptance**

- Sending 100 messages results in 100 rows / objects in the external store, none on local disk
- Disabling the external store does not break message routing — events are dropped with a logged warning instead

**Risk.** External store outage causing back-pressure on the agent. Drop with warning, never block.

---

## Phase 7 — Second transport (Matrix)

**Goal.** Prove the transport interface holds up by adding a second platform end-to-end.

**Includes**

- Matrix adapter implementing the same interface as Telegram
- Parallel transports: Telegram + Matrix can both run for the same agent in one process
- Feature parity check: every Phase 2/3/4 feature works on Matrix or degrades gracefully

**Acceptance**

- Same agent answers a Matrix room user and a Telegram DM user; both replies are correct
- Inline keyboard on Telegram and m.reaction-style buttons on Matrix both round-trip the user's choice

**Risk.** Matrix login / e2ee complexity. Keep e2ee out of v1; require unencrypted rooms.

---

## Phase 8 — Polish & nice-to-haves

**Goal.** Land the quality-of-life features that aren't on the critical path.

**Includes**

- Rate limits per chat and per user
- Visible "agent is thinking" indicator (typing indicator on Telegram, m.typing on Matrix)
- Hot reload for non-allow-list settings (language, rate limits)
- A `examples/` runnable bot in one file (proves integration in minutes)
- `docs/DESIGN.md` filled in with the tech-mapping notes that we deliberately kept out of REQUIREMENTS

**Acceptance**

- Spamming the bot triggers rate-limit drops with a logged event
- Typing indicator visibly toggles during a long-running tool call
- A first-time user clones the repo and gets the example bot replying in under 10 minutes

---

## Phase 11 — Group access policy refinement

**Goal.** Match the access semantics operators expect from group chats.

**Implements**

- `require_mention: true` per group — only `@bot` mentions or replies to bot messages reach the agent (REQUIREMENTS §1.5)
- Group `users: []` flips meaning from "inherit global allowlist" to "anyone in this group is allowed" — the group chat_id whitelist itself is the trust boundary (matches Anthropic claude-code Telegram MCP semantics)
- Slash commands sent in groups are rejected outright (operator surface is DM-only)

**Acceptance**

- A bot in a group with `require_mention: true` stays silent until @-mentioned or replied to
- A bot in a group with `users: []` accepts messages from any group member, including other bots that share the group
- Sending `/status` in a group with the owner's user-id never reaches `maybe_handle_owner` — emits a `command-in-group` reject event

---

## Phase 11.5 — Permission prompts

**Goal.** Forward sensitive tool calls to Telegram for owner approval (REQUIREMENTS §1.11).

**Implements**

- `agent.permission_mode: bypass | claude_files | strict` config knob
- `--permission-prompt-tool mcp__waggle-tools__request_permission` wired into the agent CLI args (when mode != bypass)
- File-based IPC between waggle parent and tools_server child via `/tmp/waggle/permissions/<id>.{details,verdict}`
- Inline-keyboard prompt with ✅ Allow / ❌ Deny / 🔍 See more
- 10-min timeout = deny; no owner configured = default-allow with warning log

**Acceptance**

- `claude_files` mode + Edit on `/home/node/.claude/CLAUDE.md` pings the owner; tap Allow → tool runs; tap Deny → tool blocked with the deny message reaching the agent
- Bash on a non-claude path auto-allows without contacting Telegram

---

## Phase 12 — Mid-turn inject + model knobs

**Goal.** Same-chat messages pile into the running turn instead of queueing as new turns; per-bot model + reasoning effort are configurable without rebuild (REQUIREMENTS §1.10, §1.12).

**Implements**

- Replace the global per-turn `_turn_lock` with three finer pieces:
  - `_stdin_lock` — serialise concurrent stdin writes
  - `_claim_cv` — claim/fold/release the active-chat slot
  - `_turn_done` — fired by the long-running reader task on each `result` event
- A long-running `_reader_loop` task drives indicator/typing state changes and fires turn-done; replaces the per-turn synchronous `read_events` drain
- Same-chat second inbound folds (push to stdin without waiting); different-chat inbound waits on the active-chat slot
- `CLAUDE_MODEL` / `CLAUDE_EFFORT` env → `--model` / `--effort` CLI args

**Acceptance**

- Two messages from the same chat 2s apart land in the agent's stdin before the first `result` event; the agent's response acknowledges both in one turn
- A message from a different chat sent while the first chat's turn is running is delayed until the first turn ends (no context bleed)
- A bot with `CLAUDE_MODEL=sonnet` reasons visibly via Show-thinking; the same bot with `CLAUDE_MODEL=opus` shows the redacted-content placeholder

---

## Cross-cutting concerns (every phase)

- Tests: each phase ships unit tests for new code and at least one integration test that exercises the new path end-to-end
- Docs: each phase updates `docs/REQUIREMENTS.md` only if the contract changed; otherwise `docs/DESIGN.md`
- Security: each phase explicitly answers "can this introduce a way for a non-owner to do something they shouldn't?"

## Phase dependency graph

```
P0 Foundation
  └─ P1 Telegram echo
       └─ P2 Real agent + rich messaging
            ├─ P2.5 Working-status indicator
            ├─ P3 External triggers
            ├─ P4 Owner controls
            │    └─ P5 Owner notifications
            ├─ P6 Persistence + obs hooks
            └─ P7 Matrix
                 └─ P8 Polish
```

P2.5, P3, P4, P6, P7 can be parallelised after P2 if there are multiple contributors. P5 needs P4. P8 closes everything out.

## Requirement → phase map

Each capability in [`REQUIREMENTS.md`](./REQUIREMENTS.md) lands in one or more phases. The order below reflects build-time dependencies, not requirements-doc reading order.

| § | Requirement | First phase | Notes |
|---|---|---|---|
| 1.6 | Configuration | P0 | Config loader is a prerequisite for every adapter |
| 1.1 | Multi-platform reach | P1 (Telegram), P7 (Matrix) | §1.1 demands many platforms; satisfied incrementally |
| 1.2 | Receive messages | P1 (text), P2 (attachments), P6 (persist) | Persist sub-clause moves to P6 |
| 1.3 | Send messages | P1 (text), P2 (reply, react, edit, choices) | Rich features deferred to P2 |
| 1.5 | Access control | P1 | Allow-list + reject events; required before any meaningful traffic |
| 1.4 | External triggers (inject) | P3 | Reuses §1.2/§1.3 pipeline + access gate |
| 1.7 | Owner-only operations | P4 | Sits on top of §1.5 (caller-is-owner gate) |
| 1.8 | Owner notifications | P5 | Reuses §1.7 owner channel |
| 1.9 | Working-status indicator | P2.5 | Needs §1.3 send + edit + delete; can run parallel to P3/P4 |
| §2 | Nice-to-have | P8 | Rate limits, typing indicator, examples |

## Build dependency analysis

Reading the dependency graph as a build order: P0 unblocks P1, P1 unblocks P2 (rich messaging needed before any feature requiring `edit` works). After P2 the graph fans out — P2.5/P3/P4/P6/P7 are independent of each other.

Hard dependencies:

- P0 → P1: every adapter needs the config loader and transport interface
- P1 → P2: claude subprocess must talk to a real transport, not a stub
- P2 → P2.5: status indicator edits messages via §1.3 send/edit primitives
- P2 → P3: inject delivers prompts as user-style messages through the same pipeline
- P2 → P4: owner ops are slash commands routed through inbound handler
- P4 → P5: notifications go through the owner side-channel set up in P4
- P2 → P6: persistence taps the inbound pipeline established in P2
- P2 → P7: Matrix is a second adapter against the interface frozen in P1

Soft (none): P2.5, P3, P4, P6, P7 do not depend on each other and can be parallelised by independent contributors after P2 lands.

## Suggested batching for one-contributor work

When a single person ships waggle, the smallest meaningful demo per batch:

| Batch | Phases | LOC est. | Demo at the end | Where to test |
|---|---|---|---|---|
| 1 | P0 + P1 | ~800 | Telegram bot echoes inside the allow-list | **Local dev** — `python -m waggle.cli` against the smoke-test bot fixture (`@waggle_smoke_457737_bot`) |
| 2 | P2 | ~600 | Real claude reply with reactions / inline keyboard | **K8s pod** in `geisha-house` namespace with a dedicated dev bot (e.g. `@waggle_dev_bot`); mounts the existing `creds-sync` sidecar |
| 3 | P2.5 | ~300 | Status message edits in place during a tool call | K8s pod (same as B2) |
| 4 | P3 | ~250 | `curl /inject` lands a prompt in the chat | K8s pod + ingress / port-forward for the inject endpoint |
| 5 | P4 + P5 | ~500 | Owner can `/agent restart` and gets a crash notification | K8s pod |
| 6 | P6 | ~300 | Every accepted message ends up in the external store | K8s pod + chosen external store (Postgres / S3 / dashboard) |
| 7 | P7 | ~600 | Matrix room user gets the same agent's reply | K8s pod with both Telegram + Matrix transports running |
| 8 | P8 | ~200 | Rate-limit drops show a logged event; example bot replies in <10 min | Either |

Each batch ends green against the corresponding acceptance criteria above before the next one starts.

### Testing strategy notes

- **Batch 1 is local-only on purpose.** No agent yet, no per-bot identity needed. Reusing the existing user session (Trung, `waggle-test-user.session`) and the smoke-test bot keeps the dev loop tight.
- **Batch 2 is the cut-over to K8s.** Once a real agent runs, the bot needs a stable identity, the credential-sync sidecar, AgentGateway JWT, and the rest of the geisha-house wiring. From this point the same pod template carries forward unchanged through later batches.
- **Tooling already in place that batches reuse:** real-DC user account login (`scripts/login_programmatic.py`), bot creation via BotFather (`scripts/create_test_bot.py`), echo smoke test (`scripts/echo_to_bot.py`).

## Visual roadmap

```mermaid
flowchart TB
    classDef phase fill:#eef0f5,stroke:#7080a0,color:#1f2e4a
    classDef demo fill:#fff8e1,stroke:#a07810,color:#3a2900,stroke-dasharray:3 3
    classDef batch fill:#dfe9f5,stroke:#3060a0,color:#0a2748,font-weight:bold

    subgraph B1[Batch 1 · local dev]
        P0["P0 · Foundation<br/>config + transport interface<br/>~200 LOC"]:::phase
        P1["P1 · Telegram echo<br/>allow-list + hot reload<br/>~600 LOC"]:::phase
    end
    class B1 batch

    subgraph B2[Batch 2 · first K8s pod]
        P2["P2 · Real agent<br/>claude subprocess + rich UI<br/>~600 LOC"]:::phase
    end
    class B2 batch

    subgraph FAN[Parallelisable after Batch 2]
        direction LR
        P25["P2.5 · Working-status<br/>~300 LOC"]:::phase
        P3["P3 · External triggers<br/>~250 LOC"]:::phase
        P4["P4 · Owner controls<br/>~400 LOC"]:::phase
        P6["P6 · Persistence<br/>~300 LOC"]:::phase
        P7["P7 · Matrix transport<br/>~600 LOC"]:::phase
    end

    P5["P5 · Owner notifs<br/>~100 LOC"]:::phase
    P8["P8 · Polish<br/>~200 LOC"]:::phase

    D1>"Demo · TG echo via allow-list"]:::demo
    D2>"Demo · real claude reply"]:::demo
    D8>"Demo · rate limits + example bot"]:::demo

    P0 --> P1 --> D1 --> P2 --> D2
    D2 --> P25
    D2 --> P3
    D2 --> P4 --> P5
    D2 --> P6
    D2 --> P7
    P25 --> P8
    P3 --> P8
    P5 --> P8
    P6 --> P8
    P7 --> P8
    P8 --> D8
```

### At-a-glance ASCII view

```
       ┌─────────────────── one-contributor build path ──────────────────┐
       │                                                                  │
Batch  │ 1 ──▶ 2 ──▶ ┬──▶ 3 ──┐                                            │
       │             ├──▶ 4 ──┤                                            │
       │             ├──▶ 5 ──┼──▶ 8                                       │
       │             ├──▶ 6 ──┤                                            │
       │             └──▶ 7 ──┘                                            │
Phase  │ P0+P1  P2   P2.5  P3  P4→P5  P6  P7   P8                          │
LOC    │ ~800   ~600 ~300  ~250 ~500  ~300 ~600 ~200                       │
Test   │ local  K8s  K8s   K8s+ K8s   K8s+ K8s  any                        │
       │                    ingr      store                                │
       └──────────────────────────────────────────────────────────────────┘

Legend  · Hard deps drawn as ──▶
        · Anything between B2 and B8 can be parallelised by independent contributors
        · K8s+ingr/store: extra K8s wiring (HTTP ingress, external store) needed
```
