# Batch 8 — Polish: rate limits, typing indicator, hot reload, examples (P8)

> Author: Your Name (Claude)
> Date: 2026-04-30
> Status: ✅ shipped — `waggle:0.7.0` deployed to `geisha-house/waggle-dev-0`
> Commits: `8ed7b6f` (TBD verified after push)

P7 (Matrix transport) was intentionally skipped — anh has no current
need for a second platform; P7 would be architecture-only with no value.

---

## 0. Scope

| Req | Section | What it gives the operator |
|---|---|---|
| **P8a** | rate limits | Sliding-window per-chat AND per-user budgets. Spamming → drop with `RejectEvent reason="rate-limited-*"`. Owner exempt |
| **P8b** | typing indicator | Telegram chat-header "is typing…" while a turn is in flight. Refreshed every 4s. Fail-soft. Independent of P2.5 status indicator |
| **P8c** | hot reload | rate-limit budgets live under `access.rate_limit` so the existing AccessControl mtime poller picks them up. Editing the configmap takes effect on the next call |
| **P8d** | examples | `examples/echo_bot.py` — single-file runnable, skips claude, exercises full waggle pipeline |
| **P8e** | DESIGN.md | Tech-mapping notes that REQUIREMENTS.md keeps abstract |

---

## 1. Architecture

### 1.1 Rate limiter — sliding window, in-memory, per-pod

```python
@dataclass(frozen=True, slots=True)
class RateLimitConfig:
    chat_per_minute: int = 0   # 0 = disabled
    user_per_minute: int = 0   # 0 = disabled
    window_seconds: float = 60.0

class RateLimiter:
    def check(self, *, chat_id, user_id, now=None) -> RateDecision: ...
    def update_config(self, config: RateLimitConfig): ...   # hot-reload
```

Two key design choices:

1. **Both dimensions independent.** Per-chat catches one noisy room
   bursting through (multiple users in a group). Per-user catches one
   chatty user spread across rooms. Either being over rejects.
2. **Denied calls do NOT count.** A flooder hammering at the limit
   waits out *one* window, not longer. The alternative (count-all)
   punishes flooders harder, but also means a friendly user who briefly
   bursts gets locked out for longer than the window — surprises users.
   Pinned by `test_denied_calls_do_not_count_against_future_budget`.

Owner is exempt — pinned by `test_owner_is_exempt_from_rate_limit`.
The operator must be able to `/pause` the bot during a flood.

### 1.2 Typing indicator — chat-header polling

```
        attach(chat_id) — turn starts
            │
            ▼
   ┌────────────────┐
   │ background task│  every 4s:
   │     poll       │  transport.send_chat_action(chat_id, "typing")
   └────────────────┘  swallows errors at DEBUG (kicked chat etc.)
            ▲
            │
        detach(chat_id) — turn done
```

Two indicator surfaces in waggle, complementary:

| | StatusIndicator (P2.5) | TypingIndicator (P8) |
|---|---|---|
| Where | Reply message | Chat header |
| Info | "Tool: foo", "Writing…" | Generic "typing" |
| Persists past turn | No (deleted) | Auto-clears after 5s |
| Telegram primitive | sendMessage + edit | sendChatAction |

Reference-counted attach/detach so two concurrent turns on the same
chat (forward-compat — today turn-lock serialises) don't fight each
other. Pinned by `test_attach_is_reference_counted`.

### 1.3 Hot reload via existing AccessControl poller

Rate-limit budgets live under `access.rate_limit` in the same configmap
as the user list. AccessControl's existing 1Hz mtime poller now also
parses the rate_limit block. When it changes, an `on_rate_limit_change`
callback fires — the orchestrator wires this to
`RateLimiter.update_config`.

Crucially the callback **also fires on initial load** if the loaded
config differs from the dataclass default (zeros). This means the
orchestrator constructor doesn't have to remember to push the initial
value after `access.start()` — it just registers the callback.

```python
self.rate_limiter = RateLimiter(self.access.rate_limit)
self.access.on_rate_limit_change(self.rate_limiter.update_config)
```

Existing window samples are kept across reload — the new budget
evaluates the next call, not retroactively. Pinned by
`test_loosen_config_immediately_unblocks` and
`test_update_config_takes_effect_on_next_call`.

### 1.4 examples/echo_bot.py

Single-file 130-line runnable that skips claude and just echoes
inbound. Exercises:

- AccessControl (allow-list + hot-reload)
- RateLimiter (with config under access.rate_limit)
- EventSink (emits AcceptEvents to stdout by default)
- TelegramClient (inbound dispatch + outbound reply)

Operators can use this to:
- Smoke-test a waggle build before wiring claude
- See end-to-end inbound→outbound flow in 130 lines
- Crib from when adding a non-claude orchestrator (different LLM, rules
  bot, etc.)

### 1.5 docs/DESIGN.md

The tech-mapping doc REQUIREMENTS.md deliberately keeps abstract.
Covers:

1. Why a long-lived `claude -p` subprocess (vs MCP-channel push that's
   server-side gated)
2. Channel-tag wire format (frozen v1) and its trade-offs
3. Why outbound goes via MCP tools, not by parsing claude's `result`
4. Sink interface evolution from P1 string to P6 structured config
   (back-compat retained)
5. Hot-reload via mtime polling vs inotify (mtime wins for K8s/macOS)
6. Two-indicator design (status + typing, complementary)
7. Rate-limiter design choices (denied-don't-count, owner exempt)
8. Why no Postgres/S3 sink today (HTTP first; adding others is 30 lines)
9. What's intentionally NOT in waggle (scheduling, tool registries,
   e2ee, persistent archives)

---

## 2. Test coverage

### 2.1 Unit tests (22 new, 183 total)

| Module | New | Notes |
|---|---:|---|
| `tests/test_rate_limit.py` | 11 | Both dimensions, window slide, retry math, hot-reload tighten + loosen, window can be short |
| `tests/test_typing_indicator.py` | 6 | Polling, detach stops, two-chats independent, fail-soft, ref-count, detach-without-attach safe |
| `tests/test_access.py` | 3 | rate_limit parse + default + hot-reload callback |
| `tests/test_orchestrator.py` | 2 | rate-limit reject event + owner exemption |

Total: **183 pass** (was 161, +22).

### 2.2 E2E tests

#### `smoke_p8_rate_limit.py` — spam triggers rate-limit drops live

Setup: configmap `access.rate_limit.user_per_minute: 3`. Send 5
inbound back-to-back from Trung session.

**Result**: pod logs show 2 `rate-limit drop scope=user used=4/3` lines:

```
08:17:38 INFO waggle.orchestrator: rate-limit drop scope=user used=4/3
  retry_after=59.1s chat=7510670911 user=7510670911
08:17:38 INFO waggle.orchestrator: rate-limit drop scope=user used=4/3
  retry_after=58.6s chat=7510670911 user=7510670911
ALL OK — rate-limit drops observed in pod logs
```

Spec acceptance ("Spamming the bot triggers rate-limit drops with a
logged event") — verified live.

The 4th and 5th messages were rejected; the first 3 went through to
claude. The smoke also asserts no `send_chat_action` errors in logs
— typing indicator running cleanly under fail-soft conditions.

---

## 3. Acceptance — final checklist

| Requirement | Pinned by | Verified |
|---|---|:---:|
| Rate limits per chat and per user | `test_chat_dimension_limits` + `test_user_dimension_limits` | ✅ |
| Spamming triggers drop with logged event | `test_rate_limit_drops_with_reject_event` + `smoke_p8_rate_limit.py` | ✅ |
| Typing indicator visibly toggles during long tool call | `test_attach_starts_polling` + orchestrator wiring around turn lock | ✅ |
| Hot reload for non-allow-list settings | `test_rate_limit_hot_reload_fires_callback` | ✅ |
| `examples/` runnable bot in one file | `examples/echo_bot.py` | ✅ |
| `docs/DESIGN.md` filled in | 9 sections shipped | ✅ |

All boxes ticked. Batch 8 is closed.

---

## 4. Files changed

```
 docs/DESIGN.md                | +175 (new)
 docs/TESTS.md                 |  +73 (batch 8 rows + summary)
 docs/reports/batch8-report.md | +260 (new — this file)
 examples/echo_bot.py          | +130 (new)
 scripts/smoke_p8_rate_limit.py| +95  (new)
 tests/test_access.py          | +75  (3 new tests)
 tests/test_orchestrator.py    | +85  (2 new tests)
 tests/test_rate_limit.py      | +135 (new — 11 tests)
 tests/test_typing_indicator.py| +90  (new — 6 tests)
 waggle/access.py              | +35  (rate_limit parse + callback)
 waggle/clients/telegram.py    | +15  (send_chat_action method)
 waggle/config.py              | +12  (RateLimit pydantic block)
 waggle/events.py              |  +3  (rate-limited reasons in literal)
 waggle/orchestrator.py        | +35  (rate gate + typing wire)
 waggle/rate_limit.py          | +110 (new)
 waggle/typing_indicator.py    | +90  (new)
```

---

## 5. Roadmap summary — all batches

| Batch | Phase | Status | Tests |
|---|---|:---:|---:|
| 1 | P0 + P1 — Foundation + Telegram echo | ✅ | 37 |
| 2 | P2 v0.3 — Stream-json orchestrator + tools-only outbound | ✅ | 31 |
| 3 | P2.5 — Working-status indicator | ✅ | 10 |
| 4 | P3 — /inject HTTP endpoint | ✅ | 21 |
| 5 | P4 + P5 — Owner-only ops + proactive notifications | ✅ | 29 |
| 6 | P6 — Persistence + observability hooks | ✅ | 33 |
| 7 | P7 — Matrix transport | **skipped** | — |
| 8 | P8 — Polish (rate limits, typing, hot reload, examples, DESIGN.md) | ✅ | 22 |

**Total: 183 unit tests + 8 e2e smoke scripts**, all green against
`waggle:0.7.0` deployed to `geisha-house/waggle-dev-0`.

The runtime is feature-complete per the original roadmap (modulo the
deliberate P7 skip). Future work would be:

- Postgres or S3 sink adapters (30-line additions to `events.py`)
- Multi-transport refactor if a Matrix or Discord need surfaces
- Extended owner ops (e.g. `/say <chat> <text>` for cross-room)

None of those block existing functionality — they're purely additive.
