# Batch 5 — Owner controls + proactive notifications (P4 + P5)

> Author: Your Name (Claude)
> Date: 2026-04-30
> Status: ✅ shipped — `waggle:0.5.2` deployed to `geisha-house/waggle-dev-0`
> Commits: `ea17e7a` → `be6b3f0` → `44b7c94`

---

## 0. Scope

Two requirement groups close in this batch:

| Req | Section | What it gives the operator |
|---|---|---|
| **P4** | §1.7 Owner-only operations | Slash-command control plane on Telegram: status, pause/resume, restart, new session, abort, compact |
| **P5** | §1.8 Owner notifications | Best-effort owner ping when claude crashes / is auto-restarted / hits a turn timeout |

Out of scope (intentionally deferred):

- Persistence of accepted messages → P6
- Matrix transport → P7
- Per-chat rate limits + typing indicator → P8

---

## 1. Architecture

### 1.1 Owner-ops dispatcher

`waggle/owner_ops.py` owns three things:

```
┌──────────────────────────────────────────────────────────────────────┐
│  submit_inbound(chat_id, user_id, text)                              │
│  └── maybe_handle_owner(orch, chat_id, user_id, text) ───┐           │
│                                                          ▼           │
│   ┌──────────────────────────────────────────────────────────────┐  │
│   │ 1. is_owner? — gate on config.owner.user_id                  │  │
│   │ 2. cancel-window check — plain "cancel" cancels pending op   │  │
│   │ 3. _slash_command(text) → (cmd, arg)                         │  │
│   │ 4. COMMANDS[cmd] handler runs; returns True iff consumed     │  │
│   └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  • Non-owner sender → returns False, falls through to access-list    │
│  • Owner unknown slash → returns False, claude decides what to do    │
│  • Handler crashed → returns True (consumed) + warns owner (no       │
│    double-process)                                                   │
└──────────────────────────────────────────────────────────────────────┘
```

Key invariant: **the owner gate runs at the top of `submit_inbound`, before
the access-list**, so owner ops cannot be accidentally locked out by a
config change. Pinned by `test_submit_inbound_owner_gate_runs_before_access`.

### 1.2 Commands

| Command | Effect | Cancel window | Side-effect on claude |
|---|---|:---:|---|
| `/status` | Print liveness, turn count, last inbound preview | — | none |
| `/pause` | Drop new inbound silently until /resume | — | none |
| `/resume` | Restore normal flow | — | none |
| `/abort` | Kill + restart subprocess immediately | — | `stop()` then `start()` |
| `/restart` | Restart subprocess after 5s | ✅ | `stop()` then `start()` (window expiry) |
| `/new` | Drop session context after 5s | ✅ | new `session_id` UUID, `continue=False` |
| `/compact` | Pipe `/compact` to claude (uses claude's own slash) | — | `send_user("/compact")` + drain |

Cancel: while a destructive op is pending, plain text **`cancel`** within
the 5-second window aborts it. Owner sees `✋ Cancelled the pending {label}.`

### 1.3 Proactive notifications

After every turn (both `submit_inbound` and `submit_external`),
`_respawn_if_dead()` runs:

```python
proc = self.claude._proc
if proc is None or proc.returncode is None:
    return                        # claude alive — no-op
# claude exited mid-turn:
await self.claude.start()          # respawn (uses --continue)
notify_owner(ctx, "agent restarted (rc=…)",
             why="subprocess exited between turns",
             todo="re-send the last message if you didn't get a reply")
```

`notify_owner` is best-effort: a failure to deliver the ping (Telegram
down, owner blocked the bot) is logged at WARNING and never propagates.
Pinned by `test_notify_owner_swallows_errors`.

---

## 2. Test coverage

### 2.1 Unit tests

`tests/test_owner_ops.py` — **29 tests**, all pass:

| Kind | Count | Coverage |
|---|---:|---|
| Happy | 17 | Each of the 7 commands' happy path; cancel window arms/fires/cancels; `notify_owner` formatting; submit_inbound owner gate ordering |
| Unhappy | 7 | Non-owner falls through; owner unknown slash falls through; handler crash consumed; `/compact` no-agent; arm-twice warns |
| Edge | 5 | COMMANDS dict shape pin; case-insensitive slash; "cancel" without pending falls through; `/status` while pending; paused drops silently |

Plus the two regression pins added after the e2e bug-find (see §3):

- `test_compact_drains_result_so_next_turn_is_not_desynced`
- `test_compact_holds_turn_lock_during_drain`

Total project tests: **128 pass** (was 99 before this batch — +29).

### 2.2 E2E tests

Two scripts in `scripts/`, run against the real `waggle-dev-0` pod:

#### `smoke_p4_owner.py` — non-owner gate fall-through (Trung session)

| Case | Result |
|---|---|
| Trung sends `/status` | bot shows "🤔 Thinking…" (gate fall-through, claude takes over) |
| Trung sends `/pause` then plain text | bot still replies the plain text (non-owner CANNOT pause) |

#### `smoke_p4_owner_full.py` — full owner-side e2e (configmap swap)

Runs with `owner.user_id` temporarily swapped to the Trung test
account. Final result: **10/10 cases pass**.

| # | Case | Result |
|--:|---|---|
| 1 | `/status` | `🐝 status: running\nturns processed: 3\nlast inbound: …` |
| 2a | `/pause` | `⏸ Paused. New inbound is dropped until /resume.` |
| 2b | plain text after pause | silent (no reply within 12s) |
| 3a | `/resume` | `▶ Resumed.` |
| 3b | plain echo after resume | claude echoes the nonce |
| 4a | `/restart` | `⚠ Restart in 5s. Reply 'cancel' to abort.` |
| 4b | `cancel` | `✋ Cancelled the pending restart.` |
| 5 | `/restart` (let it fire) | `🔁 Agent restarted.` |
| 6 | `/new` (let it fire) | `🆕 New session started — prior context dropped.` |
| 7 | `/abort` | `✋ Aborted in-flight turn.` |
| 8 | `/compact` | `🗜 Sent /compact to agent.` |
| 9 | `/STATUS` (uppercase) | status reply (case-insensitive) |
| 10 | `/unknown_slash_42` | claude reply ("I don't recognize that command…") |

Limitation: anh's main account (`908624017`) hasn't `/start`'d the dev
bot in DM, so the owner-side e2e cannot run as anh directly. The
configmap-swap approach exercises identical code paths.

---

## 3. Bug found and fixed during e2e

### 3.1 Symptom

After the first e2e run on `waggle:0.5.1`, case 10 (`/unknown_slash_42`
falls through to claude) consistently failed: claude received the
message but the next turn returned `is_error=False` with empty result
text in 0 seconds.

### 3.2 Root cause

The original `/compact` handler:

```python
async def _cmd_compact(orch, chat_id, _arg) -> bool:
    await orch.claude.send_user("/compact")
    await orch.telegram.reply(...)
    return True
```

wrote `/compact` to claude's stdin and returned **without consuming the
resulting `result` event**. claude-code processed the slash and emitted
its `result` to stdout — buffered by the OS pipe.

The next user turn called `submit_inbound` → `claude.send_user(...)` →
`claude.read_events()`. `read_events()` returned on the FIRST `result`
event it saw — which was `/compact`'s, not the new turn's. The user's
prompt landed in claude's input queue but its actual response was
swallowed by a third turn (or never read at all).

### 3.3 Fix

Drain stdout up to and including the `result` event under the turn lock:

```python
async with orch._turn_lock:
    await orch.claude.send_user("/compact")
    async for kind, _event in orch.claude.read_events():
        if kind == "result":
            break
```

Acquiring the turn lock for the duration prevents concurrent inbound
from racing the drain and corrupting stream state.

### 3.4 Regression pins

Two unit tests added that would have caught this on day one:

- `test_compact_drains_result_so_next_turn_is_not_desynced` — uses a
  stub claude that yields one result event per call, asserts that
  /compact + a follow-up turn read DIFFERENT result events.
- `test_compact_holds_turn_lock_during_drain` — uses a stub that blocks
  inside read_events until released; asserts a concurrent inbound is
  queued, not racing.

### 3.5 Lesson learned

Anytime owner-ops manipulates claude's stdin, it must respect the
stream-json full-duplex protocol — every send_user has exactly one
result event the orchestrator must consume.

---

## 4. Files changed

```
 docs/TESTS.md                   |  +66
 scripts/smoke_p4_owner.py       |  +110 (new)
 scripts/smoke_p4_owner_full.py  |  +245 (new)
 tests/test_owner_ops.py         |  +545 (new) + 96 modified
 waggle/orchestrator.py          |  +63
 waggle/owner_ops.py             |  +319 (new)
```

Three commits on `main`:

| SHA | Subject |
|---|---|
| `ea17e7a` | 🐝👮‍♀️🔔 feat(P4+P5): owner-only slash commands + proactive notifications |
| `be6b3f0` | 🐝🧪🌐 test(P4): non-owner gate fall-through e2e smoke |
| `44b7c94` | 🐝🐛✨ fix(P4): /compact drains stdout to keep stream-json in sync |

---

## 5. Acceptance — final checklist

| Requirement | Pinned by | Verified |
|---|---|:---:|
| §1.7 `/status` shows liveness, last activity | `test_status_*` + smoke case 1 | ✅ |
| §1.7 `/pause` drops inbound; `/resume` restores | `test_pause_*` + `test_resume_*` + smoke 2/3 | ✅ |
| §1.7 `/restart` has cancel window | `test_restart_arms_cancel_window` + `test_destructive_restart_actually_fires` + smoke 4/5 | ✅ |
| §1.7 `/new` drops context | `test_destructive_new_drops_session` + smoke 6 | ✅ |
| §1.7 `/abort` kills in-flight turn | `test_abort_stops_and_restarts_subprocess` + smoke 7 | ✅ |
| §1.7 `/compact` triggers claude's compact | `test_compact_pipes_to_claude` + smoke 8 | ✅ |
| §1.7 Owner-only — non-owner falls through | `test_non_owner_slash_falls_through` + smoke_p4_owner | ✅ |
| §1.8 Notify on agent restart | `_respawn_if_dead()` integration + `test_notify_owner_*` | ✅ |
| §1.8 Best-effort (no propagate) | `test_notify_owner_swallows_errors` | ✅ |

All boxes ticked. Batch 5 is closed.

---

## 6. What's next

**Batch 6 — P6 persistence + observability hooks.** Push every accepted
inbound + reject event to an external store (Postgres / S3 / ingest
endpoint), with a clean adapter interface so the deployment chooses.
External-store outage must NOT block the agent — drop with a logged
warning instead. Acceptance: 100 messages → 100 rows externally, zero on
local disk; disabling the store doesn't break routing.
