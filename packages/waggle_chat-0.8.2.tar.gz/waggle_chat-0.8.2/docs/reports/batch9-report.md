# Batch 9 — Inline-keyboard buttons (P2 backfill)

> Author: Your Name (Claude)
> Date: 2026-04-30
> Status: ✅ shipped — `waggle:0.7.2` deployed to `geisha-house/waggle-dev-0`
> Commits: `e4e67af`

---

## 0. Scope

This batch closes a gap discovered during the regression-test session:
spec **§1.3** and **P2 acceptance** call for selectable inline-keyboard
buttons whose taps round-trip back to the agent as labelled inbound
messages. P2 (batch 2) shipped without this surface — the audit caught
it, and this batch backfills it.

| Req | Section | What it gives the operator |
|---|---|---|
| **§1.3 sub-clause** | Send messages — selectable choices | Agent attaches yes/no/cancel-style buttons to a reply; user's tap delivers a labelled message back to the agent |
| **P2 acceptance** | "Bot can offer 'yes / no / cancel' inline buttons; clicking returns a usable message to the agent" | Live e2e verified |

---

## 1. Architecture

### 1.1 Surface

Two endpoints close the round-trip:

```
                      reply_with_choices                         _on_callback_query
agent ─────tool call──────────────► waggle ──────► Telegram ──► waggle ──── submit_inbound ──► agent
        {chat, text, choices}         tools_server      tap        client    body="choice: <label>"
```

### 1.2 `reply_with_choices` MCP tool

```python
# tools_server.py
"reply_with_choices": {
    "chat_id":  str,
    "text":     str,
    "choices":  list[str],   # 1..20 entries
    "columns":  int,         # 1..5, default 1
    "reply_to": str,         # optional
    "format":   "text" | "markdownv2",
}
```

The handler builds `InlineKeyboardMarkup` with one button per choice.
**`callback_data` carries an integer index (`c:<i>`)**, NOT the label —
Telegram caps `callback_data` at 64 bytes, but labels can be much
longer. The label is looked up on tap from the message's
`reply_markup` attribute. This means:

- Long descriptive labels work (`"Approve & deploy to prod"`)
- Adversarial / stale callback indices are gracefully dropped (no crash)
- `callback_data` is forward-compatible — adding a `kind:` prefix later
  would let buttons carry typed payloads

### 1.3 `_on_callback_query` handler

```python
# clients/telegram.py
async def _on_callback_query(self, callback: CallbackQuery) -> None:
    await callback.answer()              # clear spinner — best-effort
    if data.startswith("c:"):
        idx = int(data[2:])
        flat = [b for row in callback.message.reply_markup.inline_keyboard for b in row]
        label = flat[idx].text
    await self._orchestrator.submit_inbound(
        chat_id=callback.message.chat.id,
        user_id=callback.from_user.id,
        message_id=str(callback.id),    # synthesised from callback id
        text=f"choice: {label}",
        attachments=(),
    )
```

Three properties pinned:

1. **Always answer the callback** so the user's spinner clears, even
   if dispatch fails. Answer failure does NOT block dispatch.
2. **Synthesised `message_id`** — Telegram's CallbackQuery doesn't
   carry the user's tap as a Message, so we use the callback id as
   a stable handle for owner-state's last-inbound tracking.
3. **Body prefix `choice: `** — the agent can distinguish a button
   tap from free-form text in the same chat. No structured tag needed
   on the wire format yet (could promote to a `<choice>` tag later if
   needed).

---

## 2. Test coverage

### 2.1 Unit tests (11 new, 194 total)

**`tests/test_tools_server.py` — 5 new tests:**

| Name | Kind | What it covers |
|---|---|---|
| `test_reply_with_choices_builds_inline_keyboard` | happy | One button per choice; callback_data shape `c:<i>` |
| `test_reply_with_choices_columns_arrange_rows` | happy | `columns=2` with 5 choices → rows [2, 2, 1] |
| `test_reply_with_choices_long_label_truncated` | edge | 200-char label truncated to ≤64 bytes |
| `test_reply_with_choices_with_reply_to` | happy | `reply_to_message_id` forwarded |
| `test_reply_with_choices_empty_choices_errors` | unhappy | Empty list → MCP SDK validation error, no Bot.send_message attempted |

**`tests/test_telegram_client.py` — 5 new tests:**

| Name | Kind | What it covers |
|---|---|---|
| `test_callback_query_resolves_label_and_dispatches` | happy | Tap on button index 1 → submit_inbound text='choice: <label>' + answer() called |
| `test_callback_query_unparsable_data_dropped` | unhappy | callback_data we don't recognise → log + drop, spinner still cleared |
| `test_callback_query_index_out_of_range_dropped` | unhappy | Stale / adversarial index past keyboard length → drop, no crash |
| `test_callback_query_no_orchestrator_safe` | edge | Callback during shutdown when orchestrator detached → no crash |
| `test_callback_query_answer_failure_does_not_block_dispatch` | edge | Network blip during answer() → dispatch still happens |

Plus 1 changed: `test_advertised_tools_have_required_fields` — added
`reply_with_choices` to the expected set.

Total: **194 pass** (was 183, +11).

### 2.2 E2E test

**`scripts/smoke_p9_inline_keyboard.py`** — live round-trip:

1. Bot sends a 3-button keyboard to Trung's DM via direct Bot API HTTP
   call (bypasses claude — we're testing the keyboard surface, not
   the model's tool-call decision)
2. Trung user session (pyrogram) looks up the bot's most recent
   message in DM history, finds the one with `reply_markup`, and
   calls `request_callback_answer` with `callback_data="c:1"`
3. Pod's `_on_callback_query` receives the update, resolves index 1
   to its label, dispatches as `submit_inbound`
4. Pod logs show:
   ```json
   {"type": "accept", "source": "telegram",
    "chat": "7510670911", "user": "7510670911",
    "body": "choice: OK-fba4c5", "attachments": []}
   ```

**Pass against `waggle:0.7.2`.**

Bug discovered while writing the smoke: pyrogram's MTProto and
Telegram's Bot API use **different `message_id` namespaces**. The
Bot API `sendMessage` returns a Bot-API-side message_id, but pyrogram
needs its own MTProto id to call `request_callback_answer`. The smoke
looks up the message via `get_chat_history` first to bridge the two.
Documented in the script's docstring.

---

## 3. Acceptance — final checklist

| Requirement | Pinned by | Verified |
|---|---|:---:|
| §1.3: agent can attach selectable choices | `test_reply_with_choices_builds_inline_keyboard` + smoke | ✅ |
| §1.3: user's choice flows back as labelled inbound message | `test_callback_query_resolves_label_and_dispatches` + smoke | ✅ |
| P2 acceptance: yes/no/cancel buttons round-trip | smoke (live) | ✅ |
| Long labels work (Telegram 64-byte callback_data cap) | `test_reply_with_choices_long_label_truncated` | ✅ |
| Stale / adversarial callback data dropped safely | `test_callback_query_index_out_of_range_dropped` + `test_callback_query_unparsable_data_dropped` | ✅ |
| Spinner clears even when dispatch fails | `test_callback_query_answer_failure_does_not_block_dispatch` | ✅ |

All boxes ticked. Batch 9 is closed.

---

## 4. Files changed

```
 docs/reports/batch9-report.md   | +220 (new — this file)
 scripts/smoke_p9_inline_keyboard.py | +120 (new)
 tests/test_telegram_client.py   | +130 (5 new tests)
 tests/test_tools_server.py      | +90  (5 new tests + 1 update)
 waggle/clients/telegram.py      | +60  (callback_query handler + import)
 waggle/tools_server.py          | +75  (tool schema + helper)
```

One commit on `main`:

| SHA | Subject |
|---|---|
| `e4e67af` | 🐝⌨️🎯 feat(P2 backfill): inline-keyboard buttons round-trip choices to agent |

---

## 5. Operational notes

- **For the agent**: prefer `reply_with_choices` over free-text "type
  yes or no" prompts. The model gets back a constrained, structured
  response (`"choice: Yes"` / `"choice: No"`) instead of the user's
  potentially mistyped free-form reply.
- **Buttons in groups**: Telegram's bot privacy mode applies the
  same way to button keyboards as to messages — only group admins
  see all messages. Promote the bot to admin (or disable privacy
  via @BotFather) if you want non-mention button taps to reach the
  bot in groups.
- **Callback_data evolution**: today shape is `c:<index>`. If a
  future batch needs typed payloads (e.g. `vote:foo`, `cancel:`),
  update both the tool helper AND the resolver atomically. Test
  changes go in `test_callback_query_unparsable_data_dropped` to pin
  the legacy-shape rejection vs the new shape acceptance.

---

## 6. Roadmap status — final

| Batch | Phase | Status | Tests |
|---|---|:---:|---:|
| 1 | P0 + P1 — Foundation + Telegram echo | ✅ | 37 |
| 2 | P2 v0.3 — Stream-json orchestrator + tools-only outbound | ✅ | 31 |
| 3 | P2.5 — Working-status indicator | ✅ | 10 |
| 4 | P3 — /inject HTTP endpoint | ✅ (with fire-and-forget fix) | 22 |
| 5 | P4 + P5 — Owner-only ops + proactive notifications | ✅ | 29 |
| 6 | P6 — Persistence + observability hooks | ✅ | 33 |
| 7 | P7 — Matrix transport | **skipped** (no need) | — |
| 8 | P8 — Polish (rate limits, typing, hot reload, examples, DESIGN.md) | ✅ | 22 |
| **9** | **P2 backfill — inline keyboard** | **✅** | **11** |

**Total: 194 unit tests + 9 e2e smokes**, all green against
`waggle:0.7.2` deployed to `geisha-house/waggle-dev-0`.
