# Batch 6 — Persistence + observability hooks (P6)

> Author: Your Name (Claude)
> Date: 2026-04-30
> Status: ✅ shipped — `waggle:0.6.0` deployed to `geisha-house/waggle-dev-0`
> Commits: `1529b9d` → `263854a`

---

## 0. Scope

| Req | Section | What it gives the operator |
|---|---|---|
| **P6** | §1.2 sub-clause + §1.5 reject events | Every accepted inbound persists to an external store (full body + attachments-by-reference + metadata). Reject events ride the same channel. No local-disk writes. Adapter interface so deployment chooses the backend. External-store outage drops with a logged warning, never blocks the agent. |

Out of scope (intentional): Postgres / S3 sink implementations,
dashboard frontend. The interface is in place — adding a new sink is
isolated to `waggle/events.py` plus a config field. None of the call
sites change.

---

## 1. Architecture

### 1.1 Sink interface

```
┌────────────────────────────────────────────────────────────┐
│  WaggleOrchestrator.submit_inbound(...)                    │
│                                                            │
│      ┌─ access denied ──┐                                  │
│      ↓                  │                                  │
│  emit_reject(RejectEvent) ─────────────┐                   │
│      ↓                                 │                   │
│      access OK                         ↓                   │
│      ↓                              EventSink              │
│  emit_accept(AcceptEvent) ─────────────┤  (abstract)       │
│      ↓                                 │                   │
│   turn lock + claude turn              ▼                   │
│                                  ┌─────────────────┐       │
│                                  │  StdoutSink     │ dev   │
│                                  │  HttpSink       │ prod  │
│                                  │  (PostgresSink) │ TODO  │
│                                  │  (S3Sink)       │ TODO  │
│                                  └─────────────────┘       │
└────────────────────────────────────────────────────────────┘
```

The orchestrator only sees `EventSink`. `build_sink(config)` picks the
adapter by `kind`. Adding Postgres later is a 30-line file and a
config row — no changes to orchestrator, no changes to call sites.

### 1.2 Event shapes

```python
@dataclass(frozen=True, slots=True)
class AcceptEvent:
    source: str            # "telegram" | "matrix" | …
    chat: str
    user: str
    username: str
    message_id: str
    body: str              # full text (no truncation per spec)
    attachments: tuple[dict, ...]  # by-reference: {kind, file_id, mime_type?}
    ts: datetime

@dataclass(frozen=True, slots=True)
class RejectEvent:
    reason: Literal["not-allowlisted", "group-not-allowlisted", "owner-only"]
    source: str
    chat: str
    user: str
    text_preview: str  # first ~80 chars; never the whole body
    ts: datetime
```

**Reject events carry only a preview**, accept events carry the full
body. Reasoning: a non-allowlisted sender is by definition a probe or
abuse; storing their full message risks logging spam content. Accept
events are intentional traffic from authorised senders, where the
dashboard wants the whole conversation.

### 1.3 HttpSink

```python
class HttpSink(EventSink):
    def __init__(self, *, url, secret, timeout_seconds=5.0): …
    async def emit_accept(self, event): await self._post(event.to_dict())
    async def emit_reject(self, event): await self._post(event.to_dict())

    async def _post(self, payload):
        try:
            session = self._ensure_session()
            async with session.post(self.url, json=payload, headers=self._headers) as r:
                if r.status >= 400:
                    log.warning("HttpSink: %s returned %d: %s", ...)
        except asyncio.TimeoutError:
            log.warning("HttpSink: %s timed out (>%.1fs)", ...)
        except aiohttp.ClientError as e:
            log.warning("HttpSink: %s client error: %r", ...)
        except Exception as e:  # last-resort guard: never propagate
            log.warning("HttpSink: %s unexpected error: %r", ...)
```

**Fail-soft contract**: every failure path logs WARN and returns. The
runtime never sees a sink exception. Pinned by 3 unit tests
(connection refused / 5xx / timeout) and 1 live e2e
(`smoke_p6_failsoft.py`).

### 1.4 Attachments-by-reference

The Telegram client extracts `(kind, file_id, mime_type?)` tuples from
inbound messages without downloading anything:

| Telegram type | Extraction note |
|---|---|
| `photo` | Keep ONLY the largest PhotoSize. Smaller ones are server-side downscales of the same image — redundant for persistence. |
| `document` | Includes `mime_type` when present. |
| `video` | Includes `mime_type`. |
| `audio` | Includes `mime_type`. |
| `voice` | Includes `mime_type`. |
| `sticker` | No `mime_type` (Telegram doesn't expose one). |

The `file_id` is durable across Telegram's CDN edges, so the dashboard
can fetch the binary on demand without waggle holding any state.

### 1.5 Config

```yaml
# waggle/config.yaml
events:
  sink:
    kind: http                                    # stdout | http
    url: http://catcher.svc.cluster.local:8090/ingest
    secret: env:WAGGLE_OBS_SECRET                 # >= 16 chars
    timeout_seconds: 5.0
```

The legacy P1 form `events.reject_sink: stdout` still works — when
`sink` is not set, the legacy field is used. This keeps deployments
without a sink configured running on `StdoutSink` without a config
bump. **Misconfigured `kind: http`** (missing url, short secret)
fails LOUDLY at config load time, not silently in a swallowed warning.

---

## 2. Test coverage

### 2.1 Unit tests (28 new, 161 total)

`tests/test_events.py` — **20 tests**:

| Kind | Count | Coverage |
|---|---:|---|
| Happy | 8 | AcceptEvent / RejectEvent shape pin; StdoutSink JSON format; HttpSink POSTs accept + reject with bearer; 100-message burst (P6 acceptance); attachments tuple round-trip; build_sink dispatch (legacy string, dict, pydantic model) |
| Unhappy | 5 | HttpSink swallows ConnectionRefused, swallows non-2xx, swallows timeout (3 distinct fail-soft paths); build_sink raises on unknown kinds (fail-loud at startup) |
| Edge | 7 | HttpSink rejects empty url at construct time; HttpSink rejects empty secret; legacy stdout string still resolves; None defaults to stdout; structured stdout config; structured http config; aclose default no-op |

`tests/test_telegram_client.py` — **5 new tests**:

- `test_inbound_with_photo_extracts_largest_file_id`
- `test_inbound_with_document_includes_mime_type`
- `test_inbound_with_voice_video_audio_sticker_all_extract`
- `test_inbound_no_attachments_yields_empty_tuple`
- `test_inbound_document_without_mime_type_omits_field`

`tests/test_orchestrator.py` — **3 new tests**:

- `test_accepted_inbound_emits_accept_event` — accept emitted with full body
- `test_rejected_inbound_emits_reject_not_accept` — pin: rejects don't get cross-tagged as accepts
- `test_attachments_flow_through_to_accept_event` — telegram client tuple → AcceptEvent.attachments

`tests/test_config.py` — **4 new tests**: http requires url, http
requires long secret, http happy load, stdout needs no url/secret.

Total: **161 pass** (was 128, +33 batch 6).

### 2.2 E2E tests

#### `smoke_p6_persistence.py` — accept events flow to catcher

Setup: deploy a tiny aiohttp catcher pod in-cluster
(`/tmp/catcher.yaml`), bearer-authenticated. Patch waggle's configmap
to point `events.sink.url` at it. Send 3 Telegram inbounds.

**Result**: 3/3 AcceptEvents arrived at the catcher with full body,
correct source / chat / user / message_id, and bearer auth honoured.

```
[i] catcher saw 3 events
    OK: AcceptEvent for 'persistent-7f6436'
    OK: AcceptEvent for 'persistent-2e6302'
    OK: AcceptEvent for 'persistent-d623b3'
ALL OK
```

#### `smoke_p6_failsoft.py` — sink down, agent keeps replying

Scale catcher to 0 replicas. Send another inbound. Verify the bot
replies to the user despite the sink being unreachable.

**Result**: bot replied with the nonce within the deadline. Pod logs
showed:

```
WARNING waggle.events: HttpSink: http://catcher.geisha-house.svc:8090/ingest
  client error: ClientConnectorError(... ConnectionRefusedError ...)
INFO __main__: tool reply chat=…: failsoft-ce82b9
INFO waggle.orchestrator: ← chat=… is_error=False: Echoed the requested identifier.
```

WARNING logged, agent kept processing. Spec §1.2 "Drop with warning,
never block" — verified live.

---

## 3. Acceptance — final checklist

| Requirement | Pinned by | Verified |
|---|---|:---:|
| Every accepted inbound → external store | `test_accepted_inbound_emits_accept_event` + `smoke_p6_persistence.py` | ✅ |
| Full body, no truncation | `test_accept_event_to_dict_shape` (no `[:80]` slice) | ✅ |
| Attachments-by-reference | `test_attachments_flow_through_to_accept_event` + telegram extractor tests | ✅ |
| Reject events also routed | `test_http_sink_posts_reject` + `test_rejected_inbound_emits_reject_not_accept` | ✅ |
| No local disk writes | StdoutSink uses stdout only; HttpSink does not touch disk | ✅ (by inspection) |
| Adapter interface | `EventSink` ABC + `build_sink(config)` dispatch + 3 build_sink tests | ✅ |
| 100 messages → 100 rows | `test_http_sink_burst_100_messages` | ✅ |
| External store outage → log warning, no block | 3 fail-soft unit tests + `smoke_p6_failsoft.py` live | ✅ |
| Disabled sink doesn't break routing | StdoutSink default + `test_build_sink_none_defaults_to_stdout` | ✅ |

All boxes ticked. Batch 6 is closed.

---

## 4. Files changed

```
 waggle/clients/telegram.py    | +47   (attachment extractor)
 waggle/config.py              | +30   (EventSinkConfig + validator)
 waggle/events.py              | +190  (AcceptEvent + HttpSink + build_sink)
 waggle/orchestrator.py        | +25   (emit_accept + attachments param)
 tests/test_config.py          | +90   (4 sink-config validation tests)
 tests/test_events.py          | +330  (NEW; 20 tests)
 tests/test_orchestrator.py    | +90   (3 integration tests)
 tests/test_telegram_client.py | +85   (5 attachment extractor tests)
 scripts/smoke_p6_persistence.py | +110 (NEW)
 scripts/smoke_p6_failsoft.py    | +50  (NEW)
```

Two commits on `main`:

| SHA | Subject |
|---|---|
| `1529b9d` | 🐝🪺📤 feat(P6): persistence + observability hooks via pluggable EventSink |
| `263854a` | 🐝🪺📎 feat(P6): attachments-by-reference in AcceptEvent |

---

## 5. Operational notes

- **In production**: replace the catcher pod with a real ingest endpoint
  (Postgres-backed, or a dashboard backend). The interface is stable —
  the receiver gets `{type: accept|reject, ...}` JSON, bearer-auth.
- **Migration from P5 deployments**: existing `events.reject_sink: stdout`
  configs continue to work. Switch to `events.sink: {kind: http, ...}`
  when ready; both forms coexist without restart.
- **Log noise**: HttpSink WARN logs include the URL on every failure. If
  the sink is genuinely down for hours, this floods `kubectl logs`.
  Future improvement: log-throttle (e.g. one warning per minute).

---

## 6. What's next

**Batch 7 — P7 Matrix transport.** A second transport
(`waggle/clients/matrix.py`) that speaks the same `submit_inbound`
contract. Reuses the existing access gate, owner ops, sink layer, and
inject endpoint without modification. Dependency-graph isolated from
P6, so could have run in parallel.

Alternatively **batch 8 — P8 polish** (rate limits per chat/user,
typing indicator, examples). Anh chooses.
