"""E2E smoke for batch 8 (P8 rate limiting).

Pre-requisite: pod's configmap has access.rate_limit set with a small
budget (e.g. user_per_minute: 3) AND owner.user_id is the test user
(so the test user is NOT exempt). This test temporarily configures
that, runs, then restores.

Spec acceptance: "Spamming the bot triggers rate-limit drops with a
logged event."

Verification:
  1. Send N+1 messages quickly where N = budget.
  2. Confirm only N produce a bot reply within the deadline.
  3. Confirm the pod logs show "rate-limit drop scope=user".

Typing indicator e2e is harder to assert via pyrogram (it doesn't
expose chat actions reliably). We log-inspect: pod logs should NOT
show send_chat_action errors, which would indicate the indicator
broke under fail-soft conditions.
"""

from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")
NS = "geisha-house"
POD = "waggle-dev-0"


async def _send(c: Client, text: str) -> int:
    return (await c.send_message(BOT_USERNAME, text)).id


async def main() -> int:
    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO))
    failures: list[str] = []
    async with client:
        nonces = [uuid.uuid4().hex[:6] for _ in range(5)]
        # Send 5 messages back-to-back. Budget is user_per_minute=3, so the
        # 4th and 5th must be rate-limited.
        for n in nonces:
            await _send(client, f"rate-{n}")
            await asyncio.sleep(0.2)

        # Wait for pod to process — claude turns are slow.
        await asyncio.sleep(60)

        # Look at pod logs for "rate-limit drop"
        try:
            log_out = subprocess.run(
                ["kubectl", "-n", NS, "logs", POD, "--tail=500"],
                capture_output=True, text=True, check=True,
            ).stdout
        except subprocess.CalledProcessError as e:
            failures.append(f"kubectl logs failed: {e.stderr}")
            return 1

        rate_drops = [l for l in log_out.splitlines() if "rate-limit drop" in l]
        print(f"[i] saw {len(rate_drops)} rate-limit drop log lines:")
        for l in rate_drops[-5:]:
            print(f"    {l}")

        if len(rate_drops) < 2:
            failures.append(
                f"expected at least 2 rate-limit drops (budget=3, sent=5), "
                f"saw {len(rate_drops)}"
            )

        # Sanity: chat_action sends should NOT show errors
        chat_action_errors = [
            l for l in log_out.splitlines()
            if "send_chat_action" in l and ("ERROR" in l or "Traceback" in l)
        ]
        if chat_action_errors:
            failures.append(
                f"send_chat_action errors found ({len(chat_action_errors)}): "
                f"{chat_action_errors[0][:200]}"
            )

    if failures:
        print()
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("ALL OK — rate-limit drops observed in pod logs")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
