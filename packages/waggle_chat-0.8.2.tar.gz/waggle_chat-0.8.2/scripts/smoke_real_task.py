"""End-to-end live test: give the bot a multi-step coding task and verify
it ships a real, working result.

Task: build a small Python CLI utility, run it on sample input, return
a markdown table with the results. Exercises:
  • Multi-tool orchestration (Write, Bash, reply)
  • Working with the workspace mount in the pod
  • Reasoning across 3 sub-tasks (write code, run, format)
  • Final delivery via the MCP `reply` tool

This is a real-world stress test of the agent + waggle pipeline. Pass
criteria: the bot's reply contains all three expected values in any
formatting (table or list — we don't pin the exact layout).
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")

TASK_PROMPT = """\
Please do this 3-step task:

1. Write a Python function `fib(n)` that returns the n-th Fibonacci number
   (iteratively, F(0)=0, F(1)=1). Save it as /home/node/workspace/fib.py
   along with a __main__ block that prints `fib(10)`, `fib(20)`, `fib(30)`
   each on its own line.

2. Run `python3 /home/node/workspace/fib.py` and capture stdout.

3. Reply to me with a Telegram message containing the three values in a
   simple format like:

       fib(10) = ...
       fib(20) = ...
       fib(30) = ...

   Just the values; no extra preamble. The expected values are
   55, 6765, 832040 — but compute them yourself, don't trust me.\
"""

EXPECTED = {"55", "6765", "832040"}


async def main() -> int:
    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO))
    async with client:
        print(f"[1] sending {len(TASK_PROMPT)}-char task prompt to @{BOT_USERNAME}")
        sent = await client.send_message(BOT_USERNAME, TASK_PROMPT)
        print(f"    sent message_id={sent.id}, waiting for bot reply (up to 5 min)…")

        # Poll for any new bot text messages > sent.id whose body contains
        # all three expected fib values. Claude turns can be slow when the
        # task involves multiple tool calls; budget generously.
        deadline = time.time() + 300
        last_indicator: str | None = None
        while time.time() < deadline:
            await asyncio.sleep(4)
            async for m in client.get_chat_history(BOT_USERNAME, limit=15):
                if m.id <= sent.id:
                    break
                if not (m.from_user and m.from_user.is_bot):
                    continue
                text = m.text or m.caption or ""
                if not text:
                    continue
                # Skip the rolling status indicator
                if any(s in text for s in ("Thinking", "Tool:", "Writing")):
                    if text != last_indicator:
                        print(f"    [indicator] {text!r}")
                        last_indicator = text
                    continue
                # Real reply landed — check for the values
                hits = {v for v in EXPECTED if v in text}
                print()
                print(f"[2] bot reply ({len(text)} chars):")
                print("    " + "\n    ".join(text.splitlines()[:20]))
                print()
                missing = EXPECTED - hits
                if missing:
                    print(f"FAIL: bot reply missing values {missing}")
                    return 1
                print(f"OK: bot reply contains all 3 expected fib values")
                return 0

        print("FAIL: no bot reply within 5 minutes")
        return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
