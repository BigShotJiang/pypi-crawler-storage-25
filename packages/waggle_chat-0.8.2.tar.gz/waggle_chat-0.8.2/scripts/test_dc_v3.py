"""V3: Try multiple DC + code length combos to find what works."""
import asyncio
from telethon import TelegramClient

API_ID = 17349
API_HASH = "344583e45741c457fe1862106095a5eb"

# Documented test DC IPs
TEST_DCS = {
    1: "149.154.175.10",
    2: "149.154.167.40",
    3: "149.154.175.117",
}


async def try_login(dc: int, ip: str, port: int, suffix: str, code_len: int) -> bool:
    phone = f"99966{dc}{suffix}"
    code = str(dc) * code_len
    print(f"\n--- DC={dc} ip={ip}:{port} phone={phone} code={code} (len={code_len}) ---")
    client = TelegramClient(None, API_ID, API_HASH)
    client.session.set_dc(dc, ip, port)
    try:
        await client.connect()
    except Exception as e:
        print(f"  connect fail: {type(e).__name__}: {e}")
        return False
    try:
        sent = await client.send_code_request(phone)
        print(f"  send_code OK type={type(sent.type).__name__}")
        try:
            l = sent.type.length if hasattr(sent.type, 'length') else None
            print(f"  expected code length = {l}")
        except: pass
    except Exception as e:
        print(f"  send_code fail: {type(e).__name__}: {e}")
        await client.disconnect()
        return False
    try:
        me = await client.sign_in(phone, code)
        print(f"  ✓ Logged in: {me.first_name} (id={me.id})")
        await client.disconnect()
        return True
    except Exception as e:
        emsg = str(e)
        print(f"  sign_in fail: {type(e).__name__}: {emsg[:80]}")
        if "UNOCCUPIED" in emsg.upper():
            try:
                me = await client.sign_up(code, "Waggle", "Test")
                print(f"  ✓ Signed up: {me.first_name}")
                await client.disconnect()
                return True
            except Exception as e2:
                print(f"  sign_up also fail: {type(e2).__name__}: {e2}")
        await client.disconnect()
        return False


async def main():
    suffix = "5742"  # random unique
    for dc, ip in TEST_DCS.items():
        for port in (80, 443):
            for code_len in (5, 6):
                ok = await try_login(dc, ip, port, suffix, code_len)
                if ok:
                    print(f"\n✓✓ WORKS: DC={dc} port={port} code_len={code_len}")
                    return
                await asyncio.sleep(2)


if __name__ == "__main__":
    asyncio.run(main())
