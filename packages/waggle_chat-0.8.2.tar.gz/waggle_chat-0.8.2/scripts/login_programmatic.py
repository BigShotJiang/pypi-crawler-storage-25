"""Programmatic Pyrogram login: takes phone as arg, reads code from a file or env.

Usage:
    python scripts/login_programmatic.py <phone>

Wait for the script to print "Code sent". Then put the 5-6 digit code that
arrives in your Telegram app into /tmp/waggle-tg-code.txt OR set TG_CODE env.
Optional: set TG_PASSWORD env if your account has 2FA.
"""

import asyncio
import os
import sys
from pyrogram import Client
from pyrogram.errors import SessionPasswordNeeded

from telegram_env import api_hash, api_id

SESSION = "waggle-test-user"
CODE_PATH = "/tmp/waggle-tg-code.txt"


async def main(phone: str) -> int:
    app = Client(SESSION, api_id=api_id(), api_hash=api_hash(), workdir=".")
    await app.connect()
    try:
        sent = await app.send_code(phone)
    except Exception as e:
        print(f"send_code failed: {type(e).__name__}: {e}")
        await app.disconnect()
        return 2
    print(f"Code sent (type={sent.type}). Waiting for code at {CODE_PATH} or env TG_CODE...")

    code = os.environ.get("TG_CODE")
    if not code:
        for _ in range(150):  # 5 min @ 2s
            await asyncio.sleep(2)
            if os.path.exists(CODE_PATH):
                code = open(CODE_PATH).read().strip()
                os.remove(CODE_PATH)
                break
    if not code:
        print("timeout — no code provided in 5 minutes")
        await app.disconnect()
        return 3

    try:
        await app.sign_in(phone, sent.phone_code_hash, code)
    except SessionPasswordNeeded:
        pwd = os.environ.get("TG_PASSWORD")
        if not pwd:
            print("2FA password required — set TG_PASSWORD env and rerun")
            await app.disconnect()
            return 4
        await app.check_password(pwd)
    except Exception as e:
        print(f"sign_in failed: {type(e).__name__}: {e}")
        await app.disconnect()
        return 5

    me = await app.get_me()
    print(f"\n✓ Logged in: {me.first_name or ''} (@{me.username or '-'}, id={me.id})")
    print(f"  Session saved to: {SESSION}.session")
    await app.disconnect()
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(asyncio.run(main(sys.argv[1])))
