"""Live e2e for batch 10 (send_photo + spoiler + ts plumb).

Two checks:

  A. Bot generates a small PNG and sends it with `spoiler: true`. Trung
     session inspects the message in DM history and confirms:
       • message has a photo
       • photo has the `has_spoiler` flag set (Telegram exposes this on
         received photos via the `Photo` field)

  B. The pod's accept event for our task prompt carries Trung's send-time
     (from message.date), NOT waggle's wall clock. Verifying via stdout
     sink output: parse the JSON line and check `ts` is close to when we
     sent (within a few seconds).
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")
NS = "geisha-house"
POD = "waggle-dev-0"

TASK_PROMPT = """\
3-step task. NO preamble in your reply — just do it:

1. Use Bash to generate a small PNG file at /tmp/p10-test.png. The simplest
   way: write a tiny Python script that makes a 100x100 red square with PIL,
   or use ImageMagick `convert -size 100x100 xc:red /tmp/p10-test.png`.

2. Send that file to me via the `send_photo` MCP tool with caption "p10 test"
   AND `spoiler: true`. My chat_id is in the channel-tag.

3. Reply with the literal word DONE on a new line.\
"""


async def main() -> int:
    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO))
    failures: list[str] = []

    sent_ts = datetime.now(timezone.utc)

    async with client:
        print(f"[1] sending photo+spoiler task to @{BOT_USERNAME}")
        sent = await client.send_message(BOT_USERNAME, TASK_PROMPT)
        sent_id = sent.id

        # Wait up to 5 min for the bot to deliver a photo + DONE reply
        print("[2] waiting up to 5 min for bot photo + DONE reply…")
        deadline = time.time() + 300
        photo_msg = None
        done_seen = False
        while time.time() < deadline and (photo_msg is None or not done_seen):
            await asyncio.sleep(4)
            async for m in client.get_chat_history(BOT_USERNAME, limit=15):
                if m.id <= sent_id:
                    break
                if not (m.from_user and m.from_user.is_bot):
                    continue
                if m.photo and photo_msg is None:
                    photo_msg = m
                    print(f"    photo arrived: message_id={m.id}, "
                          f"has_spoiler={getattr(m, 'has_media_spoiler', '?')}")
                text = m.text or m.caption or ""
                if text and "DONE" in text:
                    done_seen = True

        if photo_msg is None:
            failures.append("no photo received from bot")
        else:
            # Telegram exposes `has_media_spoiler` on the Message; pyrogram
            # surfaces it as a top-level attribute.
            spoiler_flag = getattr(photo_msg, "has_media_spoiler", None)
            if spoiler_flag is not True:
                failures.append(
                    f"photo arrived but has_media_spoiler={spoiler_flag!r} "
                    "(expected True)"
                )
            else:
                print("    OK: photo carries the has_media_spoiler flag")

        if not done_seen:
            failures.append("no 'DONE' reply from bot")

    # Verify the AcceptEvent timestamp came from Telegram (sent_ts), NOT
    # from waggle's wall clock at receive-time. Both are within seconds, so
    # we just check ts is close to sent_ts (not minutes off).
    print("[3] checking AcceptEvent ts in pod stdout sink…")
    log = subprocess.run(
        ["kubectl", "-n", NS, "logs", POD, "--tail=2000"],
        capture_output=True, text=True, check=True,
    ).stdout
    found_accept = None
    for line in log.splitlines():
        if '"type": "accept"' not in line:
            continue
        if "p10-test" not in line and "step task" not in line and "DONE" not in line:
            continue
        try:
            payload = json.loads(line)
            if payload.get("body", "").startswith("3-step task"):
                found_accept = payload
                break
        except json.JSONDecodeError:
            pass
    if found_accept is None:
        failures.append("could not find our AcceptEvent in pod logs")
    else:
        ts_str = found_accept["ts"]
        accept_ts = datetime.strptime(ts_str, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        delta = abs((accept_ts - sent_ts).total_seconds())
        print(f"    AcceptEvent ts={ts_str}, sent_ts delta={delta:.1f}s")
        # Telegram timestamps and our sent_ts are within ~5s in normal case
        if delta > 30:
            failures.append(
                f"AcceptEvent ts is {delta:.0f}s off sent_ts — "
                f"expected close match (Telegram message.date)"
            )

    print()
    if failures:
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("ALL OK — photo+spoiler delivered, AcceptEvent ts matches send-time")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
