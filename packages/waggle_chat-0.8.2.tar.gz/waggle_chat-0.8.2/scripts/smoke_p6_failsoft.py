"""Verify fail-soft: catcher down → bot still replies. Spec §1.2 + P6 risk."""

from __future__ import annotations

import asyncio
import os
import sys
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")


async def main() -> int:
    client = Client(
        USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO),
    )
    async with client:
        nonce = uuid.uuid4().hex[:6]
        sent = (await client.send_message(BOT_USERNAME, f"failsoft-{nonce} please echo")).id
        deadline = time.time() + 90
        got = False
        while time.time() < deadline and not got:
            await asyncio.sleep(2)
            async for m in client.get_chat_history(BOT_USERNAME, limit=10):
                if m.id <= sent:
                    break
                if m.from_user and m.from_user.is_bot:
                    text = m.text or m.caption or ""
                    if nonce in text:
                        got = True
                        print(f"OK: bot replied with nonce {nonce!r} despite catcher down")
                        return 0
        print(f"FAIL: bot did not reply within 90s — sink failure may have blocked agent")
        return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
