"""Telethon-based test DC login per official docs (port 80, not 443)."""
import asyncio
import sys
from telethon import TelegramClient
from telethon.errors import PhoneCodeInvalidError, PhoneNumberUnoccupiedError

from telegram_env import DEFAULT_TEST_DCS, api_hash, api_id, test_dc_addr


async def main(phone: str) -> int:
    phone_digits = phone.removeprefix("+")
    dc_digit = int(phone_digits[5])
    if dc_digit not in DEFAULT_TEST_DCS:
        print(f"invalid test phone: expected 99966XYYYY with X in 1..3, got dc={dc_digit}")
        return 2
    codes = [str(dc_digit) * 5, str(dc_digit) * 6]
    host, port = test_dc_addr(dc_digit)
    print(f"phone={phone} dc={dc_digit} addr={host}:{port} codes={', '.join(codes)}")

    # None session = fresh auth key (test DC requires this)
    client = TelegramClient(None, api_id(), api_hash())
    client.session.set_dc(dc_digit, host, port)
    await client.connect()
    sent = await client.send_code_request(phone)
    print(f"send_code OK")

    me = None
    last_error = None
    code = codes[0]
    for candidate in codes:
        code = candidate
        try:
            me = await client.sign_in(
                phone=phone,
                code=candidate,
                phone_code_hash=sent.phone_code_hash,
            )
            break
        except Exception as e:
            last_error = e
            if isinstance(e, PhoneCodeInvalidError) or "PHONE_CODE_INVALID" in str(e).upper():
                print(f"sign_in failed with len={len(candidate)}; trying next code length")
                continue
            break

    try:
        if me is None:
            if isinstance(last_error, PhoneNumberUnoccupiedError) or "UNOCCUPIED" in str(last_error).upper():
                print("Phone unoccupied — signing up")
                me = await client.sign_up(
                    code,
                    "Waggle",
                    "Test",
                    phone=phone,
                    phone_code_hash=sent.phone_code_hash,
                )
            elif isinstance(last_error, PhoneCodeInvalidError):
                print("sign_in rejected all code lengths; trying sign_up directly")
                for candidate in codes:
                    try:
                        me = await client.sign_up(
                            candidate,
                            "Waggle",
                            "Test",
                            phone=phone,
                            phone_code_hash=sent.phone_code_hash,
                        )
                        break
                    except PhoneCodeInvalidError:
                        print(f"sign_up failed with len={len(candidate)}; trying next code length")
                if me is None:
                    print("sign_up failed: all code lengths were rejected")
                    await client.disconnect()
                    return 1
            else:
                print(f"sign_in failed: {type(last_error).__name__}: {last_error}")
                await client.disconnect()
                return 1
    except Exception as e:
        print(f"sign_up failed: {type(e).__name__}: {e}")
        await client.disconnect()
        return 1

    print(f"\n✓ Logged in: {me.first_name} (id={me.id})")
    # Save string session for reuse
    from telethon.sessions import StringSession
    ss = StringSession.save(client.session)
    print(f"\nString session (save this for reuse):\n{ss}")
    await client.disconnect()
    return 0


if __name__ == "__main__":
    phone = sys.argv[1] if len(sys.argv) > 1 else "9996628867"
    sys.exit(asyncio.run(main(phone)))
