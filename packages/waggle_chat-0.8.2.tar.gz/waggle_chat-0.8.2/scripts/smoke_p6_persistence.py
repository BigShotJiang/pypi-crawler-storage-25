"""E2E smoke for batch 6 (P6 persistence + observability hooks).

Validates the full path:

    Telegram inbound → waggle access gate → HttpSink.emit_accept
                                                    ↓
                                      catcher /ingest endpoint
                                                    ↓
                                            assert payload

Pre-conditions:
  • waggle:0.6.x deployed to waggle-dev-0
  • The catcher runs INSIDE the cluster on a NodePort (so the pod can
    reach it without DNS shenanigans). We deploy it on the fly.
  • Pod's events.sink configured to point at the catcher.

Acceptance:
  • Three Telegram inbound messages produce three POSTs to /ingest with
    type=accept, full body, telegram source.
  • One inbound from a NON-allowlisted user produces a POST with
    type=reject (the orchestrator emits both kinds through the sink).
  • Sink-side outage (catcher down) does NOT block the agent — bot
    still replies to the user. Pinned by toggling the catcher off and
    sending another message.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")
NS = "geisha-house"


async def main() -> int:
    print("[i] this script is intended to run AFTER:")
    print("    1) waggle:0.6.x is deployed")
    print("    2) catcher pod is running with NodePort + ingest endpoint")
    print("    3) configmap.events.sink points at the catcher")
    print()

    client = Client(
        USER_SESSION,
        api_id=api_id(),
        api_hash=api_hash(),
        workdir=str(REPO),
    )
    failures: list[str] = []
    async with client:
        nonces = [uuid.uuid4().hex[:6] for _ in range(3)]
        for n in nonces:
            await client.send_message(BOT_USERNAME, f"persistent-{n}")
            await asyncio.sleep(0.2)

        await asyncio.sleep(8)  # let claude turns settle + sink POST
        # Read catcher state via kubectl exec — the catcher writes received
        # bodies to /tmp/catcher.log so we can assert on shape.
        try:
            out = subprocess.run(
                ["kubectl", "-n", NS, "exec", "catcher-0", "--",
                 "cat", "/tmp/catcher.log"],
                capture_output=True, text=True, check=True,
            ).stdout
        except subprocess.CalledProcessError as e:
            failures.append(f"catcher cat failed: {e.stderr}")
            out = ""

        received = [json.loads(line) for line in out.splitlines() if line.strip()]
        print(f"[i] catcher saw {len(received)} events", flush=True)

        accepts = [e for e in received if e.get("type") == "accept"]
        bodies = [e["body"] for e in accepts]
        for n in nonces:
            tag = f"persistent-{n}"
            if tag not in bodies:
                failures.append(f"missing AcceptEvent for body {tag!r}")
            else:
                print(f"    OK: AcceptEvent for {tag!r}", flush=True)

    if failures:
        print()
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print()
    print("ALL OK")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
