"""Check the local dependencies needed for Waggle Telegram smoke tests."""

from __future__ import annotations

import importlib.metadata as metadata
import importlib.util
import sys


REQUIRED = ("pyrogram", "telethon", "tgcrypto")


def main() -> int:
    print(f"python={sys.executable}")
    missing: list[str] = []

    for package in REQUIRED:
        if importlib.util.find_spec(package) is None:
            print(f"{package}: MISSING")
            missing.append(package)
            continue
        print(f"{package}: {metadata.version(package)}")

    if missing:
        print("\nInstall with:")
        print('  uv pip install -e ".[telegram-test]"')
        return 1

    print("\nOK: Telegram test dependencies are importable.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
