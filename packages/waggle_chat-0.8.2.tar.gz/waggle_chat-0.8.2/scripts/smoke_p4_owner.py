"""E2E smoke for batch 5 (P4 owner-ops + P5 notifications).

We run as the **non-owner** Trung user account. The contract we can verify
from a non-owner session:

  • Sending `/status` from Trung must NOT consume the inbound; it falls
    through to claude. claude then decides what to do with it (probably
    treats it as a chatty prompt). The pod must still respond — that
    proves the owner-gate didn't accidentally swallow the message.
  • Sending `/pause` from Trung must NOT actually pause the bot. After
    sending, a follow-up plain-text message must STILL get a reply.
  • Sending plain text continues to work (turn pipeline intact).

Owner-side commands (`/status` from anh's DM) cannot be tested from this
script because anh hasn't /start'd the dev bot. Manual verification only.
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")


async def _send(c: Client, text: str) -> int:
    sent = await c.send_message(BOT_USERNAME, text)
    return sent.id


async def _wait_for_bot_reply_after(
    c: Client, after_id: int, *, deadline_s: float = 90,
    needle: str | None = None,
) -> str | None:
    deadline = time.time() + deadline_s
    while time.time() < deadline:
        await asyncio.sleep(2)
        async for m in c.get_chat_history(BOT_USERNAME, limit=20):
            if m.id <= after_id:
                break
            if m.from_user and m.from_user.is_bot:
                text = m.text or m.caption or ""
                if needle is None or needle in text:
                    return text
    return None


async def main() -> int:
    client = Client(
        USER_SESSION,
        api_id=api_id(),
        api_hash=api_hash(),
        workdir=str(REPO),
    )
    failures: list[str] = []
    async with client:
        # Case 1: non-owner /status — should fall through to claude.
        # claude has been told it's a Telegram bridge; /status should
        # produce SOME reply (the gate didn't swallow it).
        nonce = uuid.uuid4().hex[:6]
        print(f"[1] non-owner /status → expect any bot reply", flush=True)
        sent = await _send(client, f"/status nonce={nonce}")
        reply = await _wait_for_bot_reply_after(client, sent, deadline_s=90)
        if reply is None:
            failures.append("case-1: no reply within 90s — owner-gate may have swallowed /status")
        else:
            print(f"    OK: bot replied with {reply[:80]!r}", flush=True)

        # Case 2: non-owner /pause — should NOT actually pause. Send a
        # regular message after, expect a reply (proves bot still active).
        nonce = uuid.uuid4().hex[:6]
        print(f"[2] non-owner /pause then plain text — expect normal reply", flush=True)
        await _send(client, "/pause")
        await asyncio.sleep(2)
        sent = await _send(client, f"echo this back: PROOF-{nonce}")
        # Up to 3 claude turns may queue here (case-1 /status, /pause, echo);
        # each takes ~70s on slow days. Give it room.
        reply = await _wait_for_bot_reply_after(
            client, sent, deadline_s=300, needle=nonce,
        )
        if reply is None:
            failures.append(
                "case-2: bot did not reply after /pause from non-owner — "
                "bot may have been paused (gate misidentified Trung as owner)"
            )
        else:
            print(f"    OK: bot still active, replied with {reply[:80]!r}", flush=True)

    print()
    if failures:
        print("FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("ALL OK")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
