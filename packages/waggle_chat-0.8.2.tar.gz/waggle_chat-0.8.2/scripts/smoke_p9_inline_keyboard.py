"""E2E for P9 inline keyboard backfill.

Round-trip: bot sends a message with 3 inline buttons → Trung user
session taps one programmatically → pod's callback_query handler
dispatches as inbound `choice: <label>` → AcceptEvent observed in
pod logs with the right body.

We don't go through claude here — claude calling reply_with_choices
takes ~70s and is unreliable to assert on. Instead we:

  1. Use the bot token to POST sendMessage directly to Telegram's Bot
     API (a one-shot HTTPS call, doesn't conflict with the pod's
     polling). This produces a button message in Trung's DM.
  2. Pyrogram USER session subscribes to its DM history, finds the
     button message, and calls answer_callback_query equivalent —
     pyrogram's `click` button method does this.
  3. The pod's bot polling receives the callback_query, our handler
     resolves the label and dispatches submit_inbound.
  4. We tail pod logs and assert on '→ chat=… choice: <label>'.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import aiohttp
from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")
BOT_TOKEN = os.environ.get("WAGGLE_TG_DEV_BOT_TOKEN", "")
TRUNG_USER_ID = 7510670911
NS = "geisha-house"
POD = "waggle-dev-0"


async def _send_keyboard(token: str, chat_id: int, text: str,
                          choices: list[str]) -> int:
    """Direct Bot API HTTP call. Returns message_id of the sent button msg."""
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    keyboard = [
        [{"text": label, "callback_data": f"c:{i}"}]
        for i, label in enumerate(choices)
    ]
    payload = {
        "chat_id": chat_id, "text": text,
        "reply_markup": {"inline_keyboard": keyboard},
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=payload) as r:
            r.raise_for_status()
            data = await r.json()
            return data["result"]["message_id"]


async def main() -> int:
    if not BOT_TOKEN:
        print("set WAGGLE_TG_DEV_BOT_TOKEN", file=sys.stderr)
        return 2

    failures: list[str] = []
    nonce_label = f"OK-{uuid.uuid4().hex[:6]}"
    choices = ["Yes", nonce_label, "No"]   # tap index 1 → label has nonce

    # 1. Bot sends button keyboard to Trung
    print(f"[1] sending keyboard via Bot API to chat={TRUNG_USER_ID}")
    msg_id = await _send_keyboard(
        BOT_TOKEN, TRUNG_USER_ID,
        text="P9 e2e — pick one",
        choices=choices,
    )
    print(f"    sent message_id={msg_id}")
    await asyncio.sleep(2)

    # 2. Trung clicks the middle button
    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO))
    async with client:
        # Bot API and pyrogram use different message_id namespaces. Look up
        # the bot's most recent message in the DM with the bot — that's the
        # one we just sent — and use its pyrogram message_id to click.
        print(f"[2] looking up button message in Trung's history with the bot")
        target = None
        async for m in client.get_chat_history(BOT_USERNAME, limit=10):
            if m.from_user and m.from_user.is_bot and m.reply_markup:
                target = m
                break
        if target is None:
            print("    FAIL: could not find the button message in history")
            return 1
        print(f"    found pyrogram message_id={target.id}")
        print(f"[3] Trung tapping button #1 ({nonce_label!r})")
        try:
            await client.request_callback_answer(
                chat_id=BOT_USERNAME, message_id=target.id,
                callback_data="c:1",
            )
        except Exception as e:
            # Bot may answer with empty text → pyrogram raises a benign
            # exception. We only care that the callback REACHED the bot.
            print(f"    note: request_callback_answer responded: {e!r}")

    # 4. Wait for pod log line showing the dispatched choice
    print(f"[4] waiting up to 30s for pod log 'choice: {nonce_label}'")
    deadline = time.time() + 30
    seen = False
    while time.time() < deadline:
        await asyncio.sleep(2)
        log = subprocess.run(
            ["kubectl", "-n", NS, "logs", POD, "--tail=100"],
            capture_output=True, text=True, check=True,
        ).stdout
        if f"choice: {nonce_label}" in log:
            seen = True
            for line in log.splitlines():
                if f"choice: {nonce_label}" in line:
                    print(f"    OK: {line.strip()[:200]}")
                    break
            break

    if not seen:
        failures.append(
            f"no 'choice: {nonce_label}' in pod logs within 30s — "
            "callback_query handler did not dispatch correctly"
        )

    if failures:
        print()
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print()
    print("ALL OK — inline keyboard round-trip works")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
