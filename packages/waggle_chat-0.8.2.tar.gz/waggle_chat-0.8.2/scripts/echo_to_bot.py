"""Smoke-test: send a message to a Telegram bot as a logged-in user, wait for reply.

Reuses the session created by `scripts/login.py`. Send a /ping, expect a /pong-style
reply from the bot within 30 seconds.

Usage:
    python scripts/echo_to_bot.py @<bot_username>
"""

import asyncio
import sys
import time
from pyrogram import Client

from telegram_env import api_hash, api_id

SESSION_NAME = "waggle-test-user"


async def main(bot: str) -> int:
    async with Client(SESSION_NAME, api_id=api_id(), api_hash=api_hash(), workdir=".") as app:
        sent = await app.send_message(bot, "/ping waggle smoke test")
        print(f"sent message_id={sent.id} to {bot}")

        deadline = time.time() + 30
        async for msg in app.get_chat_history(bot, limit=20):
            if msg.id == sent.id:
                break
            if msg.from_user and msg.from_user.is_bot:
                print(f"reply: {msg.text or msg.caption or '<non-text>'}")
                return 0

        # if not found in immediate history, poll
        while time.time() < deadline:
            await asyncio.sleep(2)
            async for msg in app.get_chat_history(bot, limit=5):
                if msg.from_user and msg.from_user.is_bot and msg.id > sent.id:
                    print(f"reply: {msg.text or msg.caption or '<non-text>'}")
                    return 0

        print("timeout waiting for bot reply")
        return 1


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(asyncio.run(main(sys.argv[1])))
