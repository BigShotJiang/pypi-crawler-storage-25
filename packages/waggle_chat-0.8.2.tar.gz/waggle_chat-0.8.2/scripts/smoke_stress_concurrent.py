"""Stress test: 50 concurrent /inject requests, verify all are accepted
and serialized through the turn lock.

Goes through /inject (HTTP) NOT Telegram so we bypass per-user rate
limiting and aiogram polling order. /inject is the lowest-overhead
ingress to the orchestrator.

We only verify the burst-acceptance contract — NOT that all turns
complete. With claude turns running 12-180s each, 50 sequential turns
would take hours; that's a soak test, not a stress test. The
stress concern is "does the orchestrator survive a burst of
ingress without dropping requests, racing the lock, or OOMing?"

Acceptance:
  • All 50 POSTs return 200 with `submitted: true`
  • Pod is still ready after the burst — no OOM, no crash
  • The first ~5 turns visibly processed (sanity)
"""

from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import aiohttp

NS = "geisha-house"
POD = "waggle-dev-0"
N = 50


def _kubectl_secret() -> str:
    return subprocess.run(
        ["kubectl", "-n", NS, "get", "secret", "waggle-dev-inject",
         "-o", "jsonpath={.data.shared_secret}"],
        capture_output=True, text=True, check=True,
    ).stdout


async def _post(session, url, secret, payload):
    headers = {"Authorization": f"Bearer {secret}", "Content-Type": "application/json"}
    async with session.post(url, json=payload, headers=headers) as r:
        return r.status, await r.json()


async def main() -> int:
    import base64
    secret_b64 = _kubectl_secret()
    secret = base64.b64decode(secret_b64).decode().strip()
    # Port-forward inject through kubectl so we don't need to know the pod IP
    pf = subprocess.Popen(
        ["kubectl", "-n", NS, "port-forward", f"pod/{POD}", "8088:8080"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    await asyncio.sleep(2)
    url = "http://127.0.0.1:8088/inject"

    nonces = [uuid.uuid4().hex[:6] for _ in range(N)]
    failures: list[str] = []
    t0 = time.time()
    try:
        async with aiohttp.ClientSession() as session:
            tasks = [
                _post(session, url, secret, {
                    "prompt": f"stress {n} — reply with the literal word OK and nothing else",
                    "source": f"stress-{i}",
                })
                for i, n in enumerate(nonces)
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
        ok_count = sum(1 for r in results
                       if isinstance(r, tuple) and r[0] == 200
                       and r[1].get("submitted"))
        print(f"[i] burst result: {ok_count}/{N} POSTs returned 200 + submitted=true")
        if ok_count != N:
            failures.append(f"only {ok_count}/{N} accepted at /inject")
        elapsed = time.time() - t0
        print(f"[i] burst took {elapsed:.1f}s")

        # Sanity: at least the FIRST turn started — proves the
        # orchestrator picked up a queued submission and the turn lock is
        # actually serialising rather than hanging. We only need to see
        # ≥1 turn, not all 50 (that would take hours of real claude time).
        print("[i] waiting up to 60s for first '↪ external chat=' log line …")
        deadline = time.time() + 60
        seen = 0
        while time.time() < deadline:
            await asyncio.sleep(3)
            log = subprocess.run(
                ["kubectl", "-n", NS, "logs", POD, "--tail=500"],
                capture_output=True, text=True, check=True,
            ).stdout
            seen = log.count("↪ external chat=")
            if seen >= 1:
                break
        print(f"[i] orchestrator processed {seen} turn(s) of 50 queued")
        if seen < 1:
            failures.append("no '↪ external chat=' log line within 60s — orchestrator may be stuck")

        # Pod still healthy?
        pod_ready = subprocess.run(
            ["kubectl", "-n", NS, "get", "pod", POD,
             "-o", "jsonpath={.status.containerStatuses[0].ready}"],
            capture_output=True, text=True, check=True,
        ).stdout.strip()
        if pod_ready != "true":
            failures.append(f"pod not ready after burst (ready={pod_ready!r})")
        else:
            print("[i] pod still ready after burst")
    finally:
        pf.terminate()
        try:
            pf.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pf.kill()

    print()
    if failures:
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("ALL OK — pod survived 50-burst, all submissions accepted, no crash")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
