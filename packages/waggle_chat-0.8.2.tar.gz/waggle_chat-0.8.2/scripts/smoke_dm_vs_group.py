"""E2E: DM vs group access gating.

Pin the §1.5 access-control contract live:

  • DM (chat_id positive): allow-listed user_id reaches claude
  • Group (chat_id negative): bot rejects unless chat_id is in
    access.groups; per-group `users` filters who in that group can talk

Strategy:
  1. Trung's user account creates a brand-new group, adds the bot
  2. Phase A — Trung sends a message FROM the new group while
     access.groups is still {}. Pod logs MUST show
     'group-not-allowlisted' reject. claude MUST NOT see the message
  3. Phase B — patch configmap to add the group's chat_id under
     access.groups (with empty users so the global allowlist applies),
     hot-reload picks it up. Trung sends again. Pod logs MUST show
     accept event with chat=<negative-id>. Channel tag must reflect
     it
  4. Cleanup — Trung leaves + deletes the group
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import textwrap
import time
import uuid
from pathlib import Path

import yaml
from pyrogram import Client
from pyrogram.types import ChatPrivileges

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")
NS = "geisha-house"
POD = "waggle-dev-0"
CONFIGMAP = "waggle-dev-config"


def _read_config() -> dict:
    raw = subprocess.run(
        ["kubectl", "-n", NS, "get", "configmap", CONFIGMAP,
         "-o", "jsonpath={.data.config\\.yaml}"],
        capture_output=True, text=True, check=True,
    ).stdout
    return yaml.safe_load(raw)


def _patch_config(cfg: dict) -> None:
    body = yaml.safe_dump(cfg, sort_keys=False)
    payload = json.dumps({"data": {"config.yaml": body}})
    subprocess.run(
        ["kubectl", "-n", NS, "patch", "configmap", CONFIGMAP,
         "--type=merge", "-p", payload],
        check=True, capture_output=True, text=True,
    )


def _pod_logs_since(since_ts: float) -> list[str]:
    """Return log lines since `since_ts` (epoch seconds). Use --since-time."""
    iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(since_ts))
    out = subprocess.run(
        ["kubectl", "-n", NS, "logs", POD, "--since-time", iso],
        capture_output=True, text=True, check=True,
    ).stdout
    return out.splitlines()


async def _wait_for_log(pred, *, since_ts: float, deadline_s: float = 90) -> str | None:
    deadline = time.time() + deadline_s
    while time.time() < deadline:
        await asyncio.sleep(2)
        for line in _pod_logs_since(since_ts):
            if pred(line):
                return line
    return None


async def main() -> int:
    failures: list[str] = []
    cfg_orig = _read_config()
    print(f"[i] original config snapshot kept ({len(cfg_orig.get('access', {}).get('groups', {}))} groups)")

    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO))
    group_id: int | None = None
    async with client:
        # ---- Setup: create supergroup + add bot + promote ----
        # Supergroup vs basic group: supergroups give us proper negative
        # chat_ids and let us promote the bot. Bot privacy mode means bots
        # in groups only receive @-mentions UNLESS they're admins. We
        # promote so the bot sees every message.
        title = f"waggle-rg-{uuid.uuid4().hex[:6]}"
        print(f"[setup] creating supergroup {title!r} + adding @{BOT_USERNAME}")
        group = await client.create_supergroup(title=title)
        group_id = group.id   # negative for groups in pyrogram
        print(f"    group chat_id={group_id}")
        await client.add_chat_members(group_id, BOT_USERNAME)
        print(f"    promoting @{BOT_USERNAME} to admin (bypass group privacy mode)")
        await client.promote_chat_member(
            group_id, BOT_USERNAME,
            privileges=ChatPrivileges(
                can_manage_chat=True,
                can_delete_messages=False,
                can_invite_users=False,
                can_restrict_members=False,
                can_pin_messages=False,
                can_promote_members=False,
                can_change_info=False,
                can_post_messages=False,
                can_edit_messages=False,
            ),
        )
        await asyncio.sleep(2)  # let promotion propagate

        try:
            # ---- Phase A: group not in allowlist → reject ----
            print()
            print("[A] sending in group while access.groups is {} → expect REJECT")
            since_a = time.time()
            await client.send_message(group_id, f"probe-A {uuid.uuid4().hex[:6]}")
            line = await _wait_for_log(
                lambda l: "group-not-allowlisted" in l and str(group_id) in l,
                since_ts=since_a, deadline_s=30,
            )
            if line is None:
                failures.append(
                    "A: no 'group-not-allowlisted' reject event for group="
                    f"{group_id} within 30s"
                )
            else:
                print(f"    OK: reject event seen — {line.strip()[:160]}")

            # ---- Phase B: add group → accept ----
            print()
            print(f"[B] patching configmap.access.groups[{group_id}] = {{}}")
            cfg_b = json.loads(json.dumps(cfg_orig))  # deep copy
            cfg_b.setdefault("access", {}).setdefault("groups", {})[group_id] = {"users": []}
            _patch_config(cfg_b)
            # Wait for k8s configmap propagation + waggle's mtime poll (1s)
            await asyncio.sleep(70)
            since_b = time.time()
            nonce = uuid.uuid4().hex[:6]
            await client.send_message(group_id, f"probe-B {nonce}")
            # Look for accept event in stdout sink AND incoming-turn log line
            accept_line = await _wait_for_log(
                lambda l: '"type": "accept"' in l and str(group_id) in l and nonce in l,
                since_ts=since_b, deadline_s=30,
            )
            if accept_line is None:
                failures.append(
                    f"B: no accept event for nonce={nonce} chat={group_id} within 30s"
                )
            else:
                print(f"    OK: accept event seen — {accept_line.strip()[:200]}")
                # Sanity: chat field must be the negative group id
                payload = json.loads(accept_line)
                if str(group_id) != payload.get("chat"):
                    failures.append(
                        f"B: chat field mismatch in accept event: "
                        f"expected {group_id}, got {payload.get('chat')}"
                    )

        finally:
            # ---- Cleanup ----
            print()
            print(f"[cleanup] reverting configmap + leaving group")
            try:
                _patch_config(cfg_orig)
            except Exception as e:
                print(f"    WARN: revert failed: {e!r}")
            if group_id is not None:
                try:
                    await client.leave_chat(group_id, delete=True)
                except Exception as e:
                    print(f"    WARN: leave/delete group failed: {e!r}")

    print()
    if failures:
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("ALL OK — DM/group gating works correctly")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
