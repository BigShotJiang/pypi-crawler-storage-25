"""End-to-end P2 acceptance smoke: real claude subprocess answers a Telegram
question via waggle.

What this exercises:
  • config kind=claude wires through to a real `claude -p` invocation
  • channel-tag wrapping reaches the subprocess as stdin
  • the subprocess's `result` event becomes the bot reply
  • Trung user session sees the reply within ~30s (claude can be slow)

The buttons + attachment paths are covered by tests/test_telegram_rich.py
(unit) — exercising inline-keyboard callback round-trips end-to-end needs
either a custom agent or human interaction, both out of scope here.

Usage:
    python scripts/smoke_p2_claude.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
CONFIG_PATH = REPO / "tmp-smoke-p2-config.yaml"
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_TEST_BOT_USERNAME", "waggle_smoke_457737_bot")
BOT_TOKEN = os.environ["WAGGLE_TG_TEST_BOT_TOKEN"]
TRUNG_ID = 7510670911
OWNER_ID = 908624017


CONFIG_TPL = """
transports:
  - name: smoke-p2
    kind: telegram
    bot_token: {token}
    drop_pending_updates: true
access:
  users: [{owner}, {trung}]
  groups: {{}}
owner:
  user_id: {owner}
events:
  reject_sink: stdout
agent:
  kind: claude
  session_id: {sid}
  timeout_seconds: 60
  extra_args:
    - "--model"
    - "haiku"
    - "--system-prompt"
    - "You are a minimal test responder. Reply with exactly what the user asks for, in plain text, no commentary."
"""


async def _wait_for_bot_reply(app: Client, sent_id: int, deadline: float) -> str | None:
    while time.time() < deadline:
        await asyncio.sleep(1)
        async for msg in app.get_chat_history(BOT_USERNAME, limit=10):
            if msg.id <= sent_id:
                break
            if msg.from_user and msg.from_user.is_bot:
                return msg.text or msg.caption or "<empty>"
    return None


async def main() -> int:
    sid = str(uuid.uuid4())
    CONFIG_PATH.write_text(
        CONFIG_TPL.format(token=BOT_TOKEN, owner=OWNER_ID, trung=TRUNG_ID, sid=sid).lstrip()
    )

    waggle = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "waggle.cli", "-c", str(CONFIG_PATH),
        cwd=str(REPO),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    print(f"started waggle pid={waggle.pid} session_id={sid}")
    await asyncio.sleep(3)

    rc = 1
    try:
        async with Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO)) as user:
            nonce = uuid.uuid4().hex[:6]
            prompt = f"Reply with just the word PONG-{nonce} and nothing else."
            print(f"send: {prompt}")
            sent = await user.send_message(BOT_USERNAME, prompt)
            reply = await _wait_for_bot_reply(user, sent.id, deadline=time.time() + 90)
            if reply is None:
                print("FAIL: no reply within 90s")
                return 1
            print(f"recv: {reply!r}")
            if f"PONG-{nonce}" in reply:
                print("OK: real claude subprocess answered through telegram")
                rc = 0
            else:
                print("FAIL: reply did not contain expected token")
                rc = 1
    finally:
        waggle.terminate()
        try:
            await asyncio.wait_for(waggle.wait(), timeout=5)
        except asyncio.TimeoutError:
            waggle.kill()
            await waggle.wait()
        if waggle.stdout is not None:
            data = await waggle.stdout.read()
            if rc != 0 or os.environ.get("VERBOSE"):
                print("\n--- waggle stdout/stderr ---")
                sys.stdout.write(data.decode(errors="replace"))
        try:
            CONFIG_PATH.unlink()
        except FileNotFoundError:
            pass
    return rc


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
