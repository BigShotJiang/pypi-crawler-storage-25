"""Test: Does claude code stream-json pick up mid-turn user injections?

Setup:
  claude -p --input-format stream-json --output-format stream-json --verbose
    (no system prompt, no MCP tools — pure inference, but with Bash)

Procedure:
  T+0  : push user event "đếm từ 1 đến 5, mỗi số chạy bash sleep 3s rồi echo số đó"
  T+5s : while claude is running tool calls inside that turn,
         push user event "STOP đếm, thay vào đó hát 1 bài thơ ngắn"
  Then read all stream events until EOF or 90s deadline.

Observation:
  Behavior A (queue): claude finishes counting 1-5 (emits result), then
    a SECOND result with the poem. Two distinct turns.
  Behavior B (mid-turn inject): claude stops counting partway, mid-loop
    notices the second user message, switches to poem. One turn or
    interleaved turns where the poem text comes before count finishes.

We log every event with a timestamp so we can decide.
"""

from __future__ import annotations

import asyncio
import json
import time

CLAUDE = "claude"


async def main():
    proc = await asyncio.create_subprocess_exec(
        CLAUDE,
        "-p",
        "--input-format", "stream-json",
        "--output-format", "stream-json",
        "--verbose",
        "--dangerously-skip-permissions",
        "--allowedTools", "Bash",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    t0 = time.time()

    def push(content):
        ev = {"type": "user", "message": {"role": "user", "content": content}}
        line = (json.dumps(ev, ensure_ascii=False) + "\n").encode("utf-8")
        proc.stdin.write(line)
        return ev

    async def reader():
        results_seen = 0
        while True:
            line = await proc.stdout.readline()
            if not line:
                print(f"[{time.time()-t0:5.1f}s] EOF stdout")
                return
            try:
                ev = json.loads(line)
            except Exception:
                print(f"[{time.time()-t0:5.1f}s] non-json: {line[:100]!r}")
                continue
            kind = ev.get("type")
            if kind == "assistant":
                content = ev.get("message", {}).get("content", [])
                for block in content:
                    if block.get("type") == "text":
                        snippet = block.get("text", "")[:120].replace("\n", " ")
                        print(f"[{time.time()-t0:5.1f}s] assistant text: {snippet!r}")
                    elif block.get("type") == "tool_use":
                        tool = block.get("name")
                        inp = json.dumps(block.get("input", {}))[:120]
                        print(f"[{time.time()-t0:5.1f}s] assistant tool_use {tool}: {inp}")
                    elif block.get("type") == "thinking":
                        print(f"[{time.time()-t0:5.1f}s] assistant thinking: {block.get('thinking','')[:80]!r}")
            elif kind == "user":
                # tool_result event
                content = ev.get("message", {}).get("content", [])
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_result":
                        out = str(block.get("content", ""))[:80].replace("\n", " ")
                        print(f"[{time.time()-t0:5.1f}s] tool_result: {out!r}")
            elif kind == "result":
                results_seen += 1
                txt = str(ev.get("result", ""))[:200].replace("\n", " ")
                print(f"[{time.time()-t0:5.1f}s] *** RESULT #{results_seen}: {txt!r}")
            elif kind == "system":
                print(f"[{time.time()-t0:5.1f}s] system: subtype={ev.get('subtype')}")
            else:
                print(f"[{time.time()-t0:5.1f}s] {kind}: {json.dumps(ev)[:160]}")

    async def driver():
        # T+0
        push("Đếm từ 1 đến 5. Với mỗi số, dùng tool Bash chạy `sleep 3 && echo <số>` rồi báo cáo. Phải đếm xong cả 5 số rồi mới được dừng.")
        await proc.stdin.drain()
        print(f"[{time.time()-t0:5.1f}s] >>> pushed user 1 (count 1→5)")

        # Wait until claude is mid-loop (after first tool call ~~ 4-5s)
        await asyncio.sleep(7)

        # T+7
        push("STOP! Quên cái đếm đi. Trả lời ngay: 'POEM_TIME' rồi đọc câu thơ 'Trăng sáng đầu non'.")
        await proc.stdin.drain()
        print(f"[{time.time()-t0:5.1f}s] >>> pushed user 2 (poem interrupt)")

    reader_task = asyncio.create_task(reader())
    driver_task = asyncio.create_task(driver())

    try:
        await asyncio.wait_for(asyncio.gather(reader_task, driver_task), timeout=90)
    except asyncio.TimeoutError:
        print(f"[{time.time()-t0:5.1f}s] TIMEOUT — killing")
        proc.kill()
        await proc.wait()


asyncio.run(main())
