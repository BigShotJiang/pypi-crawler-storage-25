"""Create a Telegram bot programmatically by chatting with @BotFather.

Uses the logged-in user session (waggle-test-user) to DM /newbot to BotFather,
walk through the conversational prompts, and capture the resulting bot token.

Usage:
    python scripts/create_test_bot.py <display_name> <username>

`username` must end in "bot" (Telegram requirement) and be globally unique.
"""

import asyncio
import re
import sys
import time

from pyrogram import Client

from telegram_env import api_hash, api_id

SESSION = "waggle-test-user"
BOTFATHER = "@BotFather"
TIMEOUT = 30


async def wait_reply(app: Client, after_id: int) -> str:
    """Poll BotFather chat for the next message after `after_id`."""
    deadline = time.time() + TIMEOUT
    while time.time() < deadline:
        await asyncio.sleep(1)
        async for msg in app.get_chat_history(BOTFATHER, limit=5):
            if msg.id > after_id and msg.from_user and msg.from_user.username == "BotFather":
                return msg.text or ""
    raise TimeoutError("BotFather did not reply within 30s")


async def main(display_name: str, username: str) -> int:
    if not username.lower().endswith("bot"):
        print(f"username must end in 'bot' — got: {username}")
        return 2

    app = Client(SESSION, api_id=api_id(), api_hash=api_hash(), workdir=".")
    await app.start()

    print(f"sending /newbot to {BOTFATHER}")
    sent = await app.send_message(BOTFATHER, "/newbot")
    reply = await wait_reply(app, sent.id)
    print(f"  ← {reply[:80]}")

    sent = await app.send_message(BOTFATHER, display_name)
    reply = await wait_reply(app, sent.id)
    print(f"  ← {reply[:80]}")

    sent = await app.send_message(BOTFATHER, username)
    reply = await wait_reply(app, sent.id)
    print(f"  ← {reply[:160]}")

    # Token format: digits:alphanumeric, e.g. 8536956547:AAH...
    m = re.search(r"\b(\d{8,12}:[A-Za-z0-9_-]{30,})\b", reply)
    if not m:
        print("token not found in reply")
        await app.stop()
        return 1
    token = m.group(1)
    print(f"\n✓ Bot created: @{username}")
    print(f"  display_name: {display_name}")
    print(f"  token: {token}")

    await app.stop()
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("usage: create_test_bot.py <display_name> <username_ending_in_bot>")
        sys.exit(2)
    sys.exit(asyncio.run(main(sys.argv[1], sys.argv[2])))
