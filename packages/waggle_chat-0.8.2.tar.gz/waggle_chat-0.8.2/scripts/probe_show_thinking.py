"""Send a chat-style prompt to the dev bot, then tap the 🧠 Show thinking
button on the bot's indicator message and dump what the bot edits the
message to. Used to debug why anh sees 'agent hasn't emitted any thinking
yet' even when claude DOES emit thinking blocks in stream-json."""

from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

from pyrogram import Client
from pyrogram.raw.functions.messages import GetBotCallbackAnswer
from pyrogram.raw.types import InputPeerUser

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")


async def main():
    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO))
    async with client:
        # 1. Send a prompt that should trigger thinking
        sent = await client.send_message(
            BOT_USERNAME,
            "Hello em chào anh, em đang thử show thinking. Anh kể em nghe vài phương án refactor cái module waggle/orchestrator.py — phân tích pros/cons từng cái cho em",
        )
        print(f"[1] sent prompt id={sent.id}")

        # 2. Wait for the bot's indicator message to land (with the button)
        indicator_msg = None
        for _ in range(30):
            await asyncio.sleep(1)
            async for m in client.get_chat_history(BOT_USERNAME, limit=10):
                if m.id <= sent.id:
                    break
                if m.from_user and m.from_user.is_bot and m.reply_markup:
                    indicator_msg = m
                    break
            if indicator_msg is not None:
                break
        if indicator_msg is None:
            print("FAIL: no indicator message with button appeared")
            return 1
        print(f"[2] indicator id={indicator_msg.id} text={indicator_msg.text[:40]!r}")

        # 3. Wait a bit so claude has time to emit some thinking
        await asyncio.sleep(8)

        # 4. Tap the Show thinking button
        chat = await client.resolve_peer(BOT_USERNAME)
        await client.invoke(GetBotCallbackAnswer(
            peer=chat, msg_id=indicator_msg.id, data=b"t:show",
        ))
        print(f"[3] tapped Show thinking button")

        # 5. Re-fetch the indicator message and print what it now shows
        await asyncio.sleep(2)
        async for m in client.get_chat_history(BOT_USERNAME, limit=5):
            if m.id == indicator_msg.id:
                snippet = (m.text or m.caption or "(empty)")[:500]
                print(f"\n[4] indicator after tap:\n{snippet}\n")
                break
        # And keep watching for a few more seconds in case it edits later
        await asyncio.sleep(5)
        async for m in client.get_chat_history(BOT_USERNAME, limit=5):
            if m.id == indicator_msg.id:
                snippet = (m.text or m.caption or "(empty)")[:500]
                print(f"[5] indicator 7s after tap:\n{snippet}\n")
                break


if __name__ == "__main__":
    asyncio.run(main())
