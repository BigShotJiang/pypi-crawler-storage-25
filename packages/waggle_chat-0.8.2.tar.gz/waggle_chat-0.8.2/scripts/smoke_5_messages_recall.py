"""Memory-across-turns smoke test.

Sends 5 distinct messages 2s apart, lets the bot drain its turn queue,
then asks the bot to recall all 5. Pin the answer contains every key
phrase. Tests:
  • turn-lock serialisation (5 inbound queued, processed one at a time)
  • conversation context maintained across turns (claude --continue)
  • the agent's working memory after a burst inbound

Targets `waggle-dev-0` (owner=Trung in the dev pod's configmap).
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")

# Five distinctive ideas — each has a memorable noun the recall reply must
# include. Designed to be unambiguous: dates, numbers, proper-noun phrases.
IDEAS = [
    "Ý 1: Cuốn sách yêu thích của anh là 'Đắc Nhân Tâm' xuất bản năm 1936.",
    "Ý 2: Anh nuôi một con mèo Anh lông ngắn tên Mochi, 3 tuổi.",
    "Ý 3: Anh thích uống cà phê đen không đường, mỗi sáng đúng 7h30.",
    "Ý 4: Anh sinh ngày 15 tháng 8 năm 1990 tại Hà Nội.",
    "Ý 5: Anh từng đạp xe vòng quanh Hồ Tây hết 28 phút năm 2019.",
]

# Tokens we expect to see in the recall — picked so a paraphrase still
# matches (proper nouns, distinctive numbers).
EXPECTED_TOKENS = [
    "Đắc Nhân Tâm",
    "Mochi",
    "7h30",
    "15 tháng 8",
    "Hồ Tây",
]


async def _send(c, text):
    return await c.send_message(BOT_USERNAME, text)


async def _wait_for_recall_reply(c, after_id, expected_tokens, *,
                                  deadline_s=600, min_match=3):
    """The bot answers ideas 1-5 individually first, then the recall.
    Skip per-idea replies (each contains ≤1 expected token) and wait for
    the recall reply (≥`min_match` of 5 tokens). Also skip status
    indicator labels."""
    deadline = time.time() + deadline_s
    seen_replies: set[int] = set()
    while time.time() < deadline:
        await asyncio.sleep(4)
        async for m in c.get_chat_history(BOT_USERNAME, limit=30):
            if m.id <= after_id or m.id in seen_replies:
                break
            if m.from_user and m.from_user.is_bot:
                text = m.text or m.caption or ""
                if not text:
                    continue
                if any(s in text for s in ("Thinking", "Tool:", "Writing")):
                    continue
                seen_replies.add(m.id)
                hits = sum(1 for t in expected_tokens if t in text)
                print(f"    bot reply id={m.id} ({hits}/{len(expected_tokens)} tokens): {text[:80]!r}")
                if hits >= min_match:
                    return text
    return None


async def main() -> int:
    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO))
    failures: list[str] = []
    async with client:
        # 1. Send 5 ideas back-to-back, 2s apart
        print(f"[1] sending 5 ideas to @{BOT_USERNAME}, 2s apart")
        last_send_id = 0
        for i, idea in enumerate(IDEAS, 1):
            sent = await _send(client, idea)
            last_send_id = sent.id
            print(f"    [{i}] sent id={sent.id}: {idea[:60]}")
            if i < len(IDEAS):
                await asyncio.sleep(2)

        # 2. Wait a moment so the bot has at least started processing the
        #    burst (won't drain in 5s — claude turns are slow — but we
        #    want all 5 to be queued before the recall question lands)
        print("[2] sleeping 8s to let queue settle…")
        await asyncio.sleep(8)

        # 3. Recall question — also queued, will be processed AFTER the
        #    5 ideas so claude's context has all of them.
        print("[3] sending recall question")
        recall_q = (
            "OK, anh vừa nói 5 ý ở trên. Em hãy liệt kê lại đầy đủ cả 5 ý "
            "trong một message duy nhất, đánh số 1-5, dùng đúng từ ngữ anh "
            "đã dùng (Đắc Nhân Tâm, Mochi, 7h30, 15 tháng 8, Hồ Tây)."
        )
        sent = await _send(client, recall_q)
        recall_id = sent.id

        # 4. Wait up to 10 min for the recall reply. Bot answers 5 ideas
        #    individually first (1 token match each — skip), then the
        #    recall reply (≥3 token matches — capture).
        print("[4] waiting up to 10 min, scanning replies for ≥3/5 token matches…")
        reply = await _wait_for_recall_reply(
            client, recall_id, EXPECTED_TOKENS,
            deadline_s=600, min_match=3,
        )
        if reply is None:
            print("FAIL: no recall reply within 10 min (or recall didn't gather ≥3 tokens)")
            return 1

        print()
        print("[recall reply]")
        for line in reply.splitlines()[:20]:
            print(f"    {line}")
        print()

        # 5. Verify each expected token is present
        missing = [t for t in EXPECTED_TOKENS if t not in reply]
        if missing:
            failures.append(f"recall missing tokens: {missing}")

    if failures:
        print()
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"ALL OK — recall has all {len(EXPECTED_TOKENS)} expected tokens")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
