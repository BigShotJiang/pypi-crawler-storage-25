"""One-time login helper for Pyrogram tests.

Uses Telethon/Pyrogram public test credentials so no my.telegram.org
app is required for development. Saves a session file for reuse.

Usage:
    python scripts/login.py

You will be prompted for:
    1. Phone number (international format, e.g. +84xxxxxxxxx)
    2. The login code Telegram sends to your existing Telegram app
       (find it in your chat with the official "Telegram" account)
    3. Optional 2FA password if you have one set

Output:
    waggle-test-user.session  (binary file — DO NOT COMMIT)

Reuse the session by passing the same name to Client():
    Client("waggle-test-user", api_id=..., api_hash=...)
"""

import asyncio
from pyrogram import Client

# Public test credentials shipped by Pyrogram / Telethon for development.
# Rate-limited; do not use in production.
API_ID = 6
API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"

SESSION_NAME = "waggle-test-user"


async def main() -> None:
    async with Client(
        SESSION_NAME,
        api_id=API_ID,
        api_hash=API_HASH,
        workdir=".",
    ) as app:
        me = await app.get_me()
        print(f"\nLogged in as: {me.first_name or ''} {me.last_name or ''} (@{me.username or '-'}) id={me.id}")
        print(f"Session saved to: {SESSION_NAME}.session")
        print("\nNext: run an integration test, e.g.")
        print(f"    python scripts/echo_to_bot.py @<your_test_bot_username>")


if __name__ == "__main__":
    asyncio.run(main())
