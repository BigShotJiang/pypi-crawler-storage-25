"""V2: Pyrogram test DC login using Client interactive mode with phone+code preset.

This script is kept as a Pyrogram start() compatibility probe. For automated
agent runs prefer scripts/test_dc_login.py, which never falls back to stdin.
"""
import asyncio
import sys
from pyrogram import Client

API_ID = 6
API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"
SESSION_PREFIX = "waggle-test-dc-user"


async def main(phone: str, code: str) -> int:
    print(f"phone={phone} code={code} test_mode=True")
    async with Client(
        f"{SESSION_PREFIX}-{phone}",
        api_id=API_ID,
        api_hash=API_HASH,
        test_mode=True,
        phone_number=phone,
        phone_code=code,
        in_memory=False,
        workdir=".",
    ) as app:
        me = await app.get_me()
        print(f"\n✓ Logged in: {me.first_name} (@{me.username or '-'} id={me.id} dc={me.dc_id})")
        print(f"  is_bot={me.is_bot}")
    return 0


if __name__ == "__main__":
    phone = sys.argv[1] if len(sys.argv) > 1 else "9996628867"
    # Pyrogram wants the code as string; for test phones DC=2 → 22222 or 222222
    code = sys.argv[2] if len(sys.argv) > 2 else "22222"
    sys.exit(asyncio.run(main(phone, code)))
