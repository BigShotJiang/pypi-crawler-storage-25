"""Shared Telegram test configuration for local scripts."""

from __future__ import annotations

import os

DEFAULT_API_ID = 6
DEFAULT_API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"
DEFAULT_TEST_DCS = {
    1: ("149.154.175.10", 80),
    2: ("149.154.167.40", 80),
    3: ("149.154.175.117", 80),
}


def api_id() -> int:
    return int(os.environ.get("WAGGLE_TG_API_ID", DEFAULT_API_ID))


def api_hash() -> str:
    return os.environ.get("WAGGLE_TG_API_HASH", DEFAULT_API_HASH)


def test_dc() -> int:
    return int(os.environ.get("WAGGLE_TG_TEST_DC", "2"))


def test_dc_addr(dc: int | None = None) -> tuple[str, int]:
    dc = test_dc() if dc is None else dc
    raw = os.environ.get("WAGGLE_TG_TEST_DC_ADDR")
    if raw:
        host, _, port = raw.partition(":")
        return host, int(port or "443")
    return DEFAULT_TEST_DCS[dc]

