"""Login a Pyrogram client on Telegram TEST DC (no real phone needed).

Telegram test data centers accept phones in the format 99966XYYYY where:
  - X is the DC number (1, 2, or 3)
  - YYYY is any 4-digit suffix
  - The login code is the DC digit repeated 5 or 6 times (e.g. DC=2 → "22222")

This is a sandbox isolated from production. Bots, users and chats here do
not exist on production and vice-versa.

Usage:
  python scripts/test_dc_login.py [phone]

If phone is omitted a default 9996621234 (DC 2) is used.
"""

import asyncio
import os
import sys
from pyrogram import Client
from pyrogram.errors import PhoneCodeInvalid

from telegram_env import api_hash, api_id

SESSION_PREFIX = "waggle-test-dc-user"


async def main(phone: str) -> int:
    phone_digits = phone.removeprefix("+")
    dc = phone_digits[5]  # 5th char is the DC digit (e.g. 9996[2]1234 → DC 2)
    codes = [dc * 5, dc * 6]
    session = f"{SESSION_PREFIX}-{phone_digits}"
    print(f"phone={phone}  dc={dc}  expected codes={', '.join(codes)}")

    app = Client(
        session,
        api_id=api_id(),
        api_hash=api_hash(),
        test_mode=True,
        workdir=".",
    )
    await app.connect()

    sent = await app.send_code(phone)
    print(f"send_code OK (type={sent.type})")

    last_error: Exception | None = None
    for code in codes:
        try:
            await app.sign_in(phone, sent.phone_code_hash, code)
            last_error = None
            break
        except Exception as e:
            last_error = e
            if isinstance(e, PhoneCodeInvalid) or "PHONE_CODE_INVALID" in str(e).upper():
                print(f"sign_in failed with len={len(code)}; trying next code length")
                continue
            break

    if last_error:
        from pyrogram.errors import SessionPasswordNeeded
        if isinstance(last_error, SessionPasswordNeeded):
            print("ERROR: 2FA set on this test account — unexpected")
        elif (
            "phone_number_unoccupied" in str(last_error).lower()
            or "PHONE_NUMBER_UNOCCUPIED" in str(last_error)
        ):
            # Account does not exist yet — sign up
            print("Account not registered yet, signing up...")
            await app.sign_up(phone, sent.phone_code_hash, "Waggle", "Test")
        else:
            print(f"sign_in failed: {type(last_error).__name__}: {last_error}")
            await app.disconnect()
            return 1

    me = await app.get_me()
    print(f"\n✓ Logged in: {me.first_name} {me.last_name or ''} (@{me.username or '-'} id={me.id})")
    print(f"  Session: {session}.session")
    await app.disconnect()
    return 0


if __name__ == "__main__":
    phone = sys.argv[1] if len(sys.argv) > 1 else "9996621234"
    sys.exit(asyncio.run(main(phone)))
