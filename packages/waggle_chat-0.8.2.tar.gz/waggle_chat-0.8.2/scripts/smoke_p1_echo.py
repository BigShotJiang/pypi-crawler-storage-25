"""End-to-end P1 acceptance smoke test.

Spins up `waggle` against the smoke-test bot fixture, has the Trung user
session DM `/p1-smoke <nonce>` to it, expects the same body back as a reply
within 5 seconds. Then edits the config to add a fake user, expects the new
allow-list to take effect without restart (logs the reload, second nonce
gets through).

Usage:
    python scripts/smoke_p1_echo.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import textwrap
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id


REPO = Path(__file__).resolve().parent.parent
CONFIG_PATH = REPO / "tmp-smoke-config.yaml"
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_TEST_BOT_USERNAME", "waggle_smoke_457737_bot")
BOT_TOKEN = os.environ["WAGGLE_TG_TEST_BOT_TOKEN"]
TRUNG_ID = 7510670911
OWNER_ID = 908624017


CONFIG_BASE = """
transports:
  - name: smoke
    kind: telegram
    bot_token: {token}
    drop_pending_updates: true
access:
  users: {users}
  groups: {{}}
owner:
  user_id: {owner}
events:
  reject_sink: stdout
agent:
  kind: echo
"""


def _write_config(users: list[int], owner: int) -> None:
    CONFIG_PATH.write_text(
        CONFIG_BASE.format(token=BOT_TOKEN, users=users, owner=owner).lstrip()
    )


async def _wait_for_echo(app: Client, sent_id: int, expected_body: str, deadline: float) -> bool:
    while time.time() < deadline:
        await asyncio.sleep(0.5)
        async for msg in app.get_chat_history(BOT_USERNAME, limit=10):
            if msg.id <= sent_id:
                break
            if msg.from_user and msg.from_user.is_bot and (msg.text or "") == expected_body:
                return True
    return False


async def main() -> int:
    _write_config(users=[OWNER_ID, TRUNG_ID], owner=OWNER_ID)
    waggle = await asyncio.create_subprocess_exec(
        sys.executable,
        "-m",
        "waggle.cli",
        "-c",
        str(CONFIG_PATH),
        cwd=str(REPO),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    print(f"started waggle pid={waggle.pid}")

    # Give waggle ~3s to come online (aiogram drops pending updates first)
    await asyncio.sleep(3)

    rc = 1
    try:
        async with Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO)) as user:
            # 1. Send first nonce
            nonce1 = f"/p1-smoke {uuid.uuid4().hex[:8]}"
            print(f"send: {nonce1}")
            sent = await user.send_message(BOT_USERNAME, nonce1)
            ok1 = await _wait_for_echo(user, sent.id, nonce1, deadline=time.time() + 8)
            print(f"first echo: {'OK' if ok1 else 'TIMEOUT'}")
            if not ok1:
                return 1

            # 2. Edit config to flip allow-list — drop TRUNG, add a fake id.
            #    Trung's next message should be REJECTED.
            _write_config(users=[OWNER_ID, 99999999], owner=OWNER_ID)
            os.utime(CONFIG_PATH, (time.time() + 1, time.time() + 1))
            await asyncio.sleep(2)  # wait for AccessControl poll-reload

            nonce_blocked = f"/p1-smoke-blocked {uuid.uuid4().hex[:8]}"
            print(f"send (expect reject): {nonce_blocked}")
            sent2 = await user.send_message(BOT_USERNAME, nonce_blocked)
            blocked = not await _wait_for_echo(user, sent2.id, nonce_blocked, deadline=time.time() + 5)
            print(f"reject path: {'OK (no echo)' if blocked else 'FAIL (got echo)'}")
            if not blocked:
                return 1

            # 3. Edit config back — Trung allowed again. Hot reload picked up?
            _write_config(users=[OWNER_ID, TRUNG_ID], owner=OWNER_ID)
            os.utime(CONFIG_PATH, (time.time() + 2, time.time() + 2))
            await asyncio.sleep(2)

            nonce3 = f"/p1-smoke-after-reload {uuid.uuid4().hex[:8]}"
            print(f"send: {nonce3}")
            sent3 = await user.send_message(BOT_USERNAME, nonce3)
            ok3 = await _wait_for_echo(user, sent3.id, nonce3, deadline=time.time() + 8)
            print(f"third echo (after re-allow): {'OK' if ok3 else 'TIMEOUT'}")
            if not ok3:
                return 1

        rc = 0
    finally:
        waggle.terminate()
        try:
            await asyncio.wait_for(waggle.wait(), timeout=5)
        except asyncio.TimeoutError:
            waggle.kill()
            await waggle.wait()
        # Capture output for debugging
        stdout_data = b""
        if waggle.stdout is not None:
            try:
                stdout_data = await waggle.stdout.read()
            except Exception:
                pass
        if rc != 0 or os.environ.get("VERBOSE"):
            print("\n--- waggle stdout/stderr ---")
            sys.stdout.write(stdout_data.decode(errors="replace"))
        try:
            CONFIG_PATH.unlink()
        except FileNotFoundError:
            pass

    return rc


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
