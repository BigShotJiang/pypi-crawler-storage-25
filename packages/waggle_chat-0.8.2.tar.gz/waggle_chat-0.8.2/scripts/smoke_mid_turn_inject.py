"""Mid-turn inject smoke test against the dev bot.

We push two distinct user events to @waggle_dev_460809_bot, the second one
arriving WHILE the bot is still mid-turn on the first. With v0.8.0's
mid-turn inject, claude should pick up the second event between
agentic-loop rounds and merge it into the running response.

Procedure:
  T+0   : send "đếm chậm 1→5, mỗi số chạy bash sleep 5 rồi báo cáo"
  T+8s  : send "STOP đếm! Quên đi, đọc câu thơ 'TRĂNG SÁNG ĐẦU NON' ngay"
  watch : look at waggle-dev-0 logs to confirm both `→ chat=...` lines
          appear before the first `← chat=... is_error=...` line
          (= second event was pushed mid-turn, not after the first finished)

Pass criteria:
  • Both inbound messages logged before first result event in pod logs
  • Bot's reply contains 'TRĂNG SÁNG ĐẦU NON' (claude switched)
  • The full counting (1→5) is NOT completed (claude was interrupted)
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")

LONG_TASK = (
    "Đếm chậm từ 1 đến 5. Với MỖI số, dùng tool Bash chạy "
    "`sleep 5 && echo <số>` rồi báo cáo. PHẢI đếm hết cả 5 số mới được dừng."
)
INTERRUPT = (
    "STOP đếm ngay! Quên cái đếm đi. Trả lời ngay 'POEM_TIME' rồi đọc câu thơ "
    "'TRĂNG SÁNG ĐẦU NON'. Không đếm tiếp nữa, đọc thơ liền."
)


async def _send(c, text):
    return await c.send_message(BOT_USERNAME, text)


async def _wait_reply_with_token(c, after_id, expected_token, *, deadline_s=180):
    """Poll the chat history for any bot reply containing `expected_token`
    (case-insensitive), skipping status indicator messages."""
    needle = expected_token.lower()
    deadline = time.time() + deadline_s
    seen = set()
    while time.time() < deadline:
        await asyncio.sleep(3)
        async for m in c.get_chat_history(BOT_USERNAME, limit=30):
            if m.id <= after_id or m.id in seen:
                break
            if m.from_user and m.from_user.is_bot:
                text = m.text or m.caption or ""
                if not text:
                    continue
                # Skip indicator labels
                if any(s in text for s in ("Thinking", "Tool:", "Writing")):
                    continue
                seen.add(m.id)
                snippet = text[:100].replace("\n", " ")
                print(f"  bot reply id={m.id}: {snippet!r}")
                if needle in text.lower():
                    return text
    return None


async def main() -> int:
    client = Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(),
                    workdir=str(REPO))
    failures: list[str] = []
    async with client:
        print(f"[1] sending LONG TASK to @{BOT_USERNAME}")
        sent1 = await _send(client, LONG_TASK)
        print(f"    sent id={sent1.id}")
        first_id = sent1.id

        print("[2] sleeping 8s — bot starts the agentic loop, runs sleep 5 echo 1")
        await asyncio.sleep(8)

        print(f"[3] sending INTERRUPT (mid-turn)")
        sent2 = await _send(client, INTERRUPT)
        print(f"    sent id={sent2.id}")

        print("[4] waiting up to 3min for any reply with 'trăng sáng đầu non'…")
        reply = await _wait_reply_with_token(
            client, first_id, "trăng sáng đầu non", deadline_s=180,
        )
        if reply is None:
            failures.append("no reply with the poem token within 3 min")
        else:
            print()
            print("[poem reply]")
            for line in reply.splitlines()[:10]:
                print(f"    {line}")
            print()
            # If claude finished counting all 5, that means it ignored the
            # interrupt — strict pass requires NOT seeing all 5 echoed.
            count_done = all(f" {n}" in reply or f"{n}\n" in reply
                              for n in (1, 2, 3, 4, 5))
            if count_done:
                failures.append("claude finished counting 1→5 — interrupt was ignored")

    if failures:
        print()
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("ALL OK — bot saw the interrupt mid-turn and switched to the poem")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
