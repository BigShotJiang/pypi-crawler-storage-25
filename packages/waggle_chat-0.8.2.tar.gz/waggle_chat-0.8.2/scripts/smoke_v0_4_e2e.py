"""End-to-end smoke regression for the deployed waggle-dev pod (v0.3+v0.4).

Talks to live Telegram via the Trung user session and verifies each batch's
acceptance criteria against the real bot. Pre-conditions:

  • The pod `waggle-dev-0` is Running in `geisha-house`.
  • `.env` has WAGGLE_TG_DEV_BOT_USERNAME and the Trung session file
    (`waggle-test-user.session`) is in the repo root.
  • `kubectl` reaches the cluster.

Each case posts a unique nonce. We never block forever — every wait has a
deadline. The script PASSES when every case prints `OK`. Run when finalising
a batch; treat any failure as a release blocker.
"""

from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")
NS = "geisha-house"
POD = "waggle-dev-0"
CONTAINER = "waggle"
CONFIGMAP = "waggle-dev-config"


def _kubectl(*args: str) -> str:
    return subprocess.run(
        ["kubectl", *args],
        capture_output=True,
        text=True,
        check=True,
    ).stdout


async def _send(c: Client, text: str) -> int:
    sent = await c.send_message(BOT_USERNAME, text)
    return sent.id


async def _wait_for_reply_containing(c: Client, after_id: int, needle: str, *,
                                      deadline_s: float = 90) -> str | None:
    """Poll the bot's history for the first BOT message > after_id whose text
    contains `needle`. Returns the matched text, or None on timeout."""
    deadline = time.time() + deadline_s
    while time.time() < deadline:
        await asyncio.sleep(2)
        async for m in c.get_chat_history(BOT_USERNAME, limit=20):
            if m.id <= after_id:
                break
            if m.from_user and m.from_user.is_bot:
                text = m.text or m.caption or ""
                if needle in text:
                    return text
    return None


async def _observe_status_indicator(c: Client, after_id: int, *,
                                     window_s: float = 60) -> bool:
    """Look for a Bot message containing one of the status-indicator labels
    AT ANY POINT during the window. The indicator deletes itself, so we may
    miss it if the model is too fast — return True on first sighting, False
    on window expiration."""
    deadline = time.time() + window_s
    labels = ("Thinking", "Tool:", "Writing")
    while time.time() < deadline:
        await asyncio.sleep(0.8)
        async for m in c.get_chat_history(BOT_USERNAME, limit=10):
            if m.id <= after_id:
                break
            if m.from_user and m.from_user.is_bot:
                text = m.text or m.caption or ""
                if any(lbl in text for lbl in labels):
                    return True
    return False


# ---- Cases ----


async def case_happy_simple_reply(c: Client) -> bool:
    nonce = uuid.uuid4().hex[:6]
    sent = await _send(c, f"Reply with just the literal token PONG-{nonce} and nothing else.")
    found = await _wait_for_reply_containing(c, sent, f"PONG-{nonce}", deadline_s=120)
    print(f"  happy_simple_reply: {'OK' if found else 'FAIL'} (nonce {nonce})")
    return bool(found)


async def case_happy_unicode_emoji(c: Client) -> bool:
    nonce = uuid.uuid4().hex[:6]
    body = f"Phản hồi đúng chuỗi này không thay đổi: 🐝 PONG-{nonce} 🔥"
    sent = await _send(c, body)
    found = await _wait_for_reply_containing(c, sent, f"PONG-{nonce}", deadline_s=120)
    print(f"  happy_unicode_emoji: {'OK' if found else 'FAIL'} (nonce {nonce})")
    return bool(found)


async def case_status_indicator_visible(c: Client) -> bool:
    nonce = uuid.uuid4().hex[:6]
    # A short prompt is fine — we just need the indicator to be visible at all
    # during the turn. The status message gets deleted on success, so we poll
    # aggressively.
    sent = await _send(c, f"Reply with just PONG-{nonce}.")
    seen = await _observe_status_indicator(c, sent, window_s=60)
    # Then wait for the actual reply to make sure we don't leave the chat noisy.
    await _wait_for_reply_containing(c, sent, f"PONG-{nonce}", deadline_s=120)
    print(f"  status_indicator_visible: {'OK' if seen else 'FAIL'} (nonce {nonce})")
    return seen


async def case_multi_turn_unified_context(c: Client) -> bool:
    fact = uuid.uuid4().hex[:6]
    sent1 = await _send(c, f"Remember this magic word, do not say it back yet: APPLE-{fact}")
    # Wait for any bot reply to turn 1 (model likely acknowledges)
    await _wait_for_reply_containing(c, sent1, "", deadline_s=120)
    sent2 = await _send(c, "Now repeat back ONLY the exact magic word from the previous turn.")
    found = await _wait_for_reply_containing(c, sent2, f"APPLE-{fact}", deadline_s=120)
    print(f"  multi_turn_unified_context: {'OK' if found else 'FAIL'} (fact {fact})")
    return bool(found)


def _wait_pod_ready(timeout_s: float = 90) -> bool:
    """Poll until the waggle-dev pod's containers are all ready."""
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        out = subprocess.run(
            ["kubectl", "-n", NS, "get", "pod", POD, "-o",
             "jsonpath={.status.containerStatuses[*].ready}"],
            capture_output=True, text=True,
        ).stdout
        if out.strip() and all(t == "true" for t in out.split()):
            return True
        time.sleep(2)
    return False


def _patch_cm_data(config_yaml: str) -> None:
    """Strategic-merge patch ONLY the .data.config\\.yaml field of the
    ConfigMap. Avoids the resourceVersion / uid metadata bear-traps that
    a full re-apply hits."""
    # JSON patch path needs the "/" in the key escaped as "~1"
    import json as _json
    body = _json.dumps({"data": {"config.yaml": config_yaml}})
    subprocess.run(
        ["kubectl", "-n", NS, "patch", "configmap", CONFIGMAP,
         "--type=merge", "-p", body],
        check=True, capture_output=True,
    )


async def case_allowlist_reject_after_remove(c: Client) -> bool:
    """Patch the ConfigMap to drop Trung's user_id, restart the pod, send a
    message — expect NO reply. Then restore the allow-list."""
    nonce = uuid.uuid4().hex[:6]
    original = _kubectl("-n", NS, "get", "configmap", CONFIGMAP,
                        "-o", "jsonpath={.data.config\\.yaml}")
    if "7510670911" not in original:
        print("  allowlist_reject_after_remove: FAIL (Trung not in CM, can't drop)")
        return False

    print("    flipping allow-list to drop Trung…")
    flipped = original.replace(
        "    - 7510670911",
        "    # - 7510670911 (dropped for smoke test)",
    )
    _patch_cm_data(flipped)
    subprocess.run(["kubectl", "-n", NS, "delete", "pod", POD,
                    "--grace-period=10"], capture_output=True)
    if not _wait_pod_ready():
        print("  allowlist_reject_after_remove: FAIL (pod didn't become ready after flip)")
        return False

    sent = await _send(c, f"This should be silently dropped: {nonce}")
    found = await _wait_for_reply_containing(c, sent, nonce, deadline_s=30)
    rc = found is None
    print(f"  allowlist_reject_after_remove: {'OK' if rc else 'FAIL'} (nonce {nonce})")

    print("    restoring allow-list…")
    _patch_cm_data(original)
    subprocess.run(["kubectl", "-n", NS, "delete", "pod", POD,
                    "--grace-period=10"], capture_output=True)
    _wait_pod_ready()
    return rc


# ---- Runner ----


async def main() -> int:
    print(f"e2e smoke against bot {BOT_USERNAME!r}, pod {NS}/{POD}")
    cases = [
        ("happy/simple_reply",          case_happy_simple_reply),
        ("happy/unicode_emoji",         case_happy_unicode_emoji),
        ("happy/multi_turn_context",    case_multi_turn_unified_context),
        ("edge/status_indicator",       case_status_indicator_visible),
        ("unhappy/allowlist_reject",    case_allowlist_reject_after_remove),
    ]

    rc = 0
    async with Client(USER_SESSION, api_id=api_id(), api_hash=api_hash(), workdir=str(REPO)) as c:
        for label, fn in cases:
            print(f"[{label}]")
            try:
                ok = await fn(c)
            except Exception as e:
                print(f"  EXCEPTION: {type(e).__name__}: {e}")
                ok = False
            if not ok:
                rc = 1

    print()
    print("PASS" if rc == 0 else "FAIL — see lines marked FAIL above")
    return rc


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
