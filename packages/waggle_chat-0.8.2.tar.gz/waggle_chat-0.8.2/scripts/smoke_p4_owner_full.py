"""Full owner-side e2e for batch 5 (P4 owner-ops + P5 notifications).

Pre-requisite: the pod must be configured with `owner.user_id =
<the test user account id>` so the Trung session counts as owner.
This is a TEMPORARY config swap — revert after running.

Coverage:
  1. /status reports running, includes turn count
  2. /pause replies "Paused" + plain text after is dropped silently
  3. /resume replies "Resumed" + plain text after gets a normal reply
  4. /restart arms 5s window → "cancel" aborts → "Cancelled" reply
  5. /restart arms 5s window → wait → "Agent restarted" reply
  6. /new arms 5s window → wait → "New session started" reply
  7. /abort replies "Aborted in-flight turn" immediately
  8. /compact replies "Sent /compact to agent"
  9. /STATUS uppercase → handled (case-insensitive)
 10. /unknown_slash falls through to claude (gets a normal reply)
 11. After /pause: bot ignores everything until /resume

Each case posts a unique nonce. Every wait has a deadline. The script
exits 0 only when every case prints OK.
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
import uuid
from pathlib import Path

from pyrogram import Client

sys.path.insert(0, str(Path(__file__).parent))
from telegram_env import api_hash, api_id

REPO = Path(__file__).resolve().parent.parent
USER_SESSION = "waggle-test-user"
BOT_USERNAME = os.environ.get("WAGGLE_TG_DEV_BOT_USERNAME", "waggle_dev_460809_bot")


async def _send(c: Client, text: str) -> int:
    sent = await c.send_message(BOT_USERNAME, text)
    return sent.id


async def _wait_for_bot_text(
    c: Client, after_id: int, *, deadline_s: float = 30,
    needle: str | None = None,
) -> str | None:
    """Return first bot message > after_id whose text contains `needle`
    (or any text if needle is None). None on timeout."""
    deadline = time.time() + deadline_s
    while time.time() < deadline:
        await asyncio.sleep(1)
        async for m in c.get_chat_history(BOT_USERNAME, limit=20):
            if m.id <= after_id:
                break
            if m.from_user and m.from_user.is_bot:
                text = m.text or m.caption or ""
                if needle is None or needle in text:
                    return text
    return None


async def _expect_no_reply(
    c: Client, after_id: int, *, window_s: float = 15,
) -> bool:
    """Verify NO bot text reply lands in `window_s` seconds (other than
    the working-status indicator which is allowed). Returns True if quiet."""
    deadline = time.time() + window_s
    seen_only_status = True
    while time.time() < deadline:
        await asyncio.sleep(1)
        async for m in c.get_chat_history(BOT_USERNAME, limit=10):
            if m.id <= after_id:
                break
            if m.from_user and m.from_user.is_bot:
                text = m.text or m.caption or ""
                if text and "Thinking" not in text and "Tool:" not in text \
                        and "Writing" not in text:
                    # An actual reply landed → bot is NOT paused
                    print(f"      [unexpected reply] {text[:120]!r}", flush=True)
                    return False
    return seen_only_status


async def main() -> int:
    client = Client(
        USER_SESSION,
        api_id=api_id(),
        api_hash=api_hash(),
        workdir=str(REPO),
    )
    failures: list[str] = []
    async with client:
        # Anchor: capture the latest message id WITHOUT sending anything,
        # so claude isn't doing a slow turn while we run owner-ops cases.
        # We don't actually need anchor for any specific case here — each
        # case captures its own `sent_id` and waits for a reply > sent_id.
        pass

        # ---- 1. /status ----
        print("[1] /status → expect '🐝 status' reply", flush=True)
        sent = await _send(client, "/status")
        reply = await _wait_for_bot_text(client, sent, needle="🐝 status")
        if reply is None:
            failures.append("1: /status got no '🐝 status' reply")
        else:
            print(f"    OK: {reply[:120]!r}", flush=True)

        # ---- 2. /pause + plain text dropped ----
        print("[2] /pause → expect 'Paused' + follow-up dropped silently", flush=True)
        sent = await _send(client, "/pause")
        reply = await _wait_for_bot_text(client, sent, needle="Paused")
        if reply is None:
            failures.append("2a: /pause got no 'Paused' reply")
        else:
            print(f"    OK 2a: {reply[:80]!r}", flush=True)
            # Send plain text — should be dropped silently
            sent2 = await _send(client, f"this should be ignored {uuid.uuid4().hex[:6]}")
            quiet = await _expect_no_reply(client, sent2, window_s=12)
            if not quiet:
                failures.append("2b: bot replied to plain text while paused")
            else:
                print("    OK 2b: silent while paused", flush=True)

        # ---- 3. /resume + plain text replied ----
        print("[3] /resume → expect 'Resumed' + follow-up gets reply", flush=True)
        sent = await _send(client, "/resume")
        reply = await _wait_for_bot_text(client, sent, needle="Resumed")
        if reply is None:
            failures.append("3a: /resume got no 'Resumed' reply")
        else:
            print(f"    OK 3a: {reply[:80]!r}", flush=True)
            nonce = uuid.uuid4().hex[:6]
            sent2 = await _send(client, f"echo back nonce {nonce} please")
            reply2 = await _wait_for_bot_text(client, sent2, needle=nonce, deadline_s=90)
            if reply2 is None:
                failures.append("3b: bot did not reply after /resume")
            else:
                print(f"    OK 3b: {reply2[:80]!r}", flush=True)

        # ---- 4. /restart with cancel ----
        print("[4] /restart → expect cancel window → type 'cancel' → 'Cancelled'", flush=True)
        sent = await _send(client, "/restart")
        reply = await _wait_for_bot_text(client, sent, needle="Restart in")
        if reply is None:
            failures.append("4a: /restart got no 'Restart in' reply")
        else:
            print(f"    OK 4a: {reply[:80]!r}", flush=True)
            sent2 = await _send(client, "cancel")
            reply2 = await _wait_for_bot_text(client, sent2, needle="Cancelled")
            if reply2 is None:
                failures.append("4b: 'cancel' did not abort pending /restart")
            else:
                print(f"    OK 4b: {reply2[:80]!r}", flush=True)

        # ---- 5. /restart fires ----
        print("[5] /restart → wait 6s → expect 'Agent restarted'", flush=True)
        sent = await _send(client, "/restart")
        reply = await _wait_for_bot_text(client, sent, needle="Agent restarted",
                                          deadline_s=20)
        if reply is None:
            failures.append("5: /restart did not fire ('Agent restarted')")
        else:
            print(f"    OK: {reply[:80]!r}", flush=True)

        # Wait for the new claude process to be ready
        await asyncio.sleep(3)

        # ---- 6. /new fires + drops session ----
        print("[6] /new → wait 6s → expect 'New session started'", flush=True)
        sent = await _send(client, "/new")
        reply = await _wait_for_bot_text(client, sent, needle="New session",
                                          deadline_s=20)
        if reply is None:
            failures.append("6: /new did not fire ('New session started')")
        else:
            print(f"    OK: {reply[:80]!r}", flush=True)

        await asyncio.sleep(3)

        # ---- 7. /abort ----
        print("[7] /abort → expect 'Aborted'", flush=True)
        sent = await _send(client, "/abort")
        reply = await _wait_for_bot_text(client, sent, needle="Aborted",
                                          deadline_s=15)
        if reply is None:
            failures.append("7: /abort got no 'Aborted' reply")
        else:
            print(f"    OK: {reply[:80]!r}", flush=True)

        await asyncio.sleep(3)

        # ---- 8. /compact ----
        print("[8] /compact → expect 'Sent /compact to agent'", flush=True)
        sent = await _send(client, "/compact")
        reply = await _wait_for_bot_text(client, sent, needle="Sent /compact",
                                          deadline_s=20)
        if reply is None:
            failures.append("8: /compact got no 'Sent /compact' reply")
        else:
            print(f"    OK: {reply[:80]!r}", flush=True)

        # Wait for the compact turn (pipes /compact to claude as user msg) to settle
        await asyncio.sleep(8)

        # ---- 9. /STATUS uppercase ----
        print("[9] /STATUS uppercase → handler is case-insensitive", flush=True)
        sent = await _send(client, "/STATUS")
        reply = await _wait_for_bot_text(client, sent, needle="🐝 status",
                                          deadline_s=15)
        if reply is None:
            failures.append("9: /STATUS uppercase did not match")
        else:
            print(f"    OK: {reply[:80]!r}", flush=True)

        # ---- 10. /unknown falls through to claude ----
        # Falling through means claude receives the message and responds
        # AS THE MODEL would — paraphrasing is fine, we don't pin exact
        # text. We just need SOME non-status reply that isn't an owner-op
        # confirmation. Easiest signal: a tool-reply with body that does
        # NOT match any of the owner-op canned strings.
        print("[10] /unknown_slash_42 → falls through to claude", flush=True)
        sent = await _send(client, "/unknown_slash_42 — please respond")
        deadline = time.time() + 90
        got_through = False
        owner_op_strings = (
            "🐝 status", "Paused", "Resumed", "Restart in",
            "Cancelled", "Agent restarted", "New session",
            "Aborted", "Sent /compact",
        )
        while time.time() < deadline and not got_through:
            await asyncio.sleep(2)
            async for m in client.get_chat_history(BOT_USERNAME, limit=10):
                if m.id <= sent:
                    break
                if m.from_user and m.from_user.is_bot:
                    text = m.text or m.caption or ""
                    if not text:
                        continue
                    if any(s in text for s in owner_op_strings):
                        # Owner-op canned reply — keep waiting for claude
                        continue
                    if "Thinking" in text or "Tool:" in text or "Writing" in text:
                        continue
                    got_through = True
                    print(f"    OK: claude replied {text[:120]!r}", flush=True)
                    break
        if not got_through:
            failures.append("10: /unknown_slash_42 did not produce a claude reply")

    print()
    if failures:
        print(f"FAIL ({len(failures)}):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("ALL OK — 10/10 cases pass")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
