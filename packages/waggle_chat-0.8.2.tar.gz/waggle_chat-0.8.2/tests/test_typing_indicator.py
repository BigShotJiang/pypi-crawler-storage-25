"""TypingIndicator (P8) — periodic chat-action poll while a turn is in flight.

The actual interval is 4 s in production. Tests use a short interval
(0.05s) so they're fast and deterministic. We assert on call counts +
per-chat scoping, not wall-clock timing.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from waggle.typing_indicator import TypingIndicator


class _StubTransport:
    def __init__(self):
        self.actions: list[dict] = []
        self.fail_after: int | None = None

    async def send_chat_action(self, *, chat_id, action="typing"):
        self.actions.append({"chat_id": chat_id, "action": action})
        if self.fail_after is not None and len(self.actions) > self.fail_after:
            raise RuntimeError("forced")


# ---------- Happy ----------


@pytest.mark.asyncio
async def test_attach_starts_polling():
    tg = _StubTransport()
    ti = TypingIndicator(tg, interval_seconds=0.05)
    await ti.attach(42)
    await asyncio.sleep(0.18)  # ~3-4 cycles
    await ti.detach(42)
    assert len(tg.actions) >= 2
    assert all(a["chat_id"] == "42" and a["action"] == "typing" for a in tg.actions)


@pytest.mark.asyncio
async def test_detach_stops_polling():
    tg = _StubTransport()
    ti = TypingIndicator(tg, interval_seconds=0.05)
    await ti.attach(42)
    await asyncio.sleep(0.10)
    await ti.detach(42)
    n_after_detach = len(tg.actions)
    await asyncio.sleep(0.20)
    # No more sends after detach
    assert len(tg.actions) == n_after_detach


@pytest.mark.asyncio
async def test_two_chats_polled_independently():
    tg = _StubTransport()
    ti = TypingIndicator(tg, interval_seconds=0.05)
    await ti.attach(11)
    await ti.attach(22)
    await asyncio.sleep(0.18)
    await ti.detach(11)
    await ti.detach(22)
    chats = {a["chat_id"] for a in tg.actions}
    assert chats == {"11", "22"}


# ---------- Edge / fail-soft ----------


@pytest.mark.asyncio
async def test_send_failure_does_not_kill_poller():
    """A kicked / deleted chat raises in send_chat_action — poller logs
    and continues. The next poll-tick must still fire."""
    tg = _StubTransport()
    tg.fail_after = 1   # raise on calls #2, #3, …
    ti = TypingIndicator(tg, interval_seconds=0.05)
    await ti.attach(42)
    await asyncio.sleep(0.20)
    await ti.detach(42)
    # >= 3 attempts, including the ones that raised
    assert len(tg.actions) >= 3


@pytest.mark.asyncio
async def test_attach_is_reference_counted():
    """Two concurrent turns on the same chat → one poll task; detaching
    once leaves the task running until the second detach."""
    tg = _StubTransport()
    ti = TypingIndicator(tg, interval_seconds=0.05)
    await ti.attach(42)
    await ti.attach(42)
    # Only ONE task even though attach was called twice
    assert len(ti._tasks) == 1
    assert ti._refs[42] == 2
    await ti.detach(42)
    assert ti._refs[42] == 1
    assert len(ti._tasks) == 1  # still polling
    await ti.detach(42)
    assert 42 not in ti._refs
    assert 42 not in ti._tasks


@pytest.mark.asyncio
async def test_detach_unattached_chat_is_safe():
    """No attach was ever made — detach is a no-op, doesn't raise."""
    tg = _StubTransport()
    ti = TypingIndicator(tg, interval_seconds=0.05)
    await ti.detach(999)  # must not raise
