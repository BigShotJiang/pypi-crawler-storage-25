"""Inject HTTP endpoint (§1.4 / Phase 3).

Brings the InjectServer up against an in-process aiohttp test client and a
stubbed orchestrator. We don't talk to claude or telegram here — the test
verifies the auth gate, payload validation, chat-target resolution, and
that the orchestrator gets called with the right shape.
"""

from __future__ import annotations

import asyncio
import json

import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from waggle.inject import InjectServer


SECRET = "x" * 32  # min 16 per config validator; longer is fine


class _StubOrch:
    def __init__(self, *, raise_runtime: bool = False):
        self.calls: list[dict] = []
        self._raise = raise_runtime

    async def submit_external(self, *, chat_id, prompt, source_label="external"):
        if self._raise:
            raise RuntimeError("claude down")
        self.calls.append({"chat_id": chat_id, "prompt": prompt, "source_label": source_label})


@pytest.fixture
async def client():
    """Drive the InjectServer's routes through aiohttp's TestClient. We
    don't use start()/TCPSite — TestClient owns the loop instead. The
    fixture yields (test_client, orchestrator stub) so each test can
    inspect what was submitted."""
    orch = _StubOrch()
    server = InjectServer(
        bind="127.0.0.1:0",
        shared_secret=SECRET,
        default_chat_id=908624017,
        orchestrator=orch,
    )
    app = web.Application()
    app.router.add_post("/inject", server._handle_inject)
    app.router.add_get("/healthz", server._handle_healthz)

    async with TestClient(TestServer(app)) as c:
        yield c, orch


# --------------- Auth ---------------


@pytest.mark.asyncio
async def test_no_auth_header_returns_401(client):
    c, orch = client
    r = await c.post("/inject", json={"prompt": "hi"})
    assert r.status == 401
    assert orch.calls == []


@pytest.mark.asyncio
async def test_wrong_bearer_returns_401(client):
    c, orch = client
    r = await c.post("/inject",
                     headers={"Authorization": "Bearer wrong"},
                     json={"prompt": "hi"})
    assert r.status == 401
    assert orch.calls == []


@pytest.mark.asyncio
async def test_non_bearer_scheme_returns_401(client):
    c, orch = client
    r = await c.post("/inject",
                     headers={"Authorization": f"Basic {SECRET}"},
                     json={"prompt": "hi"})
    assert r.status == 401
    assert orch.calls == []


# --------------- Body validation ---------------


@pytest.mark.asyncio
async def test_malformed_json_returns_400(client):
    c, _ = client
    r = await c.post("/inject",
                     headers={"Authorization": f"Bearer {SECRET}"},
                     data=b"not json {")
    assert r.status == 400


@pytest.mark.asyncio
async def test_body_must_be_object(client):
    c, _ = client
    r = await c.post("/inject",
                     headers={"Authorization": f"Bearer {SECRET}"},
                     json=["array", "instead"])
    assert r.status == 400


@pytest.mark.asyncio
async def test_missing_prompt_returns_400(client):
    c, _ = client
    r = await c.post("/inject",
                     headers={"Authorization": f"Bearer {SECRET}"},
                     json={"chat_id": 42})
    assert r.status == 400


@pytest.mark.asyncio
async def test_empty_prompt_returns_400(client):
    c, _ = client
    r = await c.post("/inject",
                     headers={"Authorization": f"Bearer {SECRET}"},
                     json={"prompt": "   "})
    assert r.status == 400


@pytest.mark.asyncio
async def test_invalid_chat_id_returns_400(client):
    c, _ = client
    r = await c.post("/inject",
                     headers={"Authorization": f"Bearer {SECRET}"},
                     json={"prompt": "hi", "chat_id": "not-a-number"})
    assert r.status == 400


# --------------- Happy ---------------


@pytest.mark.asyncio
async def test_explicit_chat_id_is_used(client):
    c, orch = client
    r = await c.post(
        "/inject",
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"prompt": "alert: prod-down", "chat_id": -1001234567890},
    )
    assert r.status == 200
    payload = await r.json()
    assert payload["submitted"] is True
    assert payload["chat_id"] == "-1001234567890"
    assert orch.calls == [{
        "chat_id": -1001234567890,
        "prompt": "alert: prod-down",
        "source_label": "external",
    }]


@pytest.mark.asyncio
async def test_omitted_chat_id_falls_back_to_default(client):
    c, orch = client
    r = await c.post(
        "/inject",
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"prompt": "ping"},
    )
    assert r.status == 200
    assert orch.calls[0]["chat_id"] == 908624017


@pytest.mark.asyncio
async def test_source_label_propagated(client):
    """A trigger can self-identify (e.g. "alertmanager", "ci"). The
    orchestrator wraps it into the channel tag so the agent can tell who
    knocked."""
    c, orch = client
    await c.post(
        "/inject",
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"prompt": "hi", "source": "alertmanager"},
    )
    assert orch.calls[0]["source_label"] == "alertmanager"


@pytest.mark.asyncio
async def test_source_label_truncated_to_32_chars(client):
    """Edge: a malicious caller can't blow up the channel tag with a
    multi-megabyte source label."""
    c, orch = client
    await c.post(
        "/inject",
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"prompt": "hi", "source": "x" * 999},
    )
    assert len(orch.calls[0]["source_label"]) == 32


@pytest.mark.asyncio
async def test_healthz_no_auth_required():
    """/healthz is the K8s readiness probe — we don't gate it. Any prober
    poking the bearer-protected endpoints would log a noisy 401 otherwise."""
    orch = _StubOrch()
    server = InjectServer(
        bind="127.0.0.1:0", shared_secret=SECRET,
        default_chat_id=42, orchestrator=orch,
    )
    app = web.Application()
    app.router.add_get("/healthz", server._handle_healthz)
    async with TestClient(TestServer(app)) as c:
        r = await c.get("/healthz")
        assert r.status == 200


# --------------- Unhappy: orchestrator down ---------------


@pytest.mark.asyncio
async def test_orchestrator_runtime_error_logged_not_5xx():
    """Fire-and-forget contract: when submit_external raises after the
    HTTP handler has returned 200, the exception is logged at WARNING
    but the caller has already gotten its 200. The HTTP layer is no
    longer a synchronous proxy for orchestrator health.

    Why fire-and-forget: real callers (alertmanager, CI, scheduler, …)
    expect /inject to be a notify-and-go ingress; they don't want to
    block on claude's turn latency (~70s). The agent's reply comes
    back via the MCP `reply` tool independently."""
    from waggle.inject import InjectServer
    from aiohttp.test_utils import TestServer, TestClient
    from aiohttp import web
    orch = _StubOrch(raise_runtime=True)
    server = InjectServer(
        bind="127.0.0.1:0",
        shared_secret=SECRET,
        default_chat_id=42,
        orchestrator=orch,
    )
    app = web.Application()
    app.router.add_post("/inject", server._handle_inject)
    async with TestClient(TestServer(app)) as c:
        r = await c.post(
            "/inject",
            headers={"Authorization": f"Bearer {SECRET}"},
            json={"prompt": "hi"},
        )
        # Returns 200 immediately — submission accepted; the failure
        # happens in the background task and lands in pod logs.
        assert r.status == 200
        body = await r.json()
        assert body["submitted"] is True


@pytest.mark.asyncio
async def test_inject_returns_fast_under_slow_orchestrator():
    """Stress acceptance: even when submit_external blocks for a long
    time (claude turn taking minutes), /inject returns within ~100ms.
    This is the bug-fix pin: we hit this in the live stress smoke
    where 50 concurrent POSTs serialised on the turn lock and only
    1 completed in 5 minutes."""
    from waggle.inject import InjectServer
    from aiohttp.test_utils import TestServer, TestClient
    from aiohttp import web

    class _SlowOrch:
        async def submit_external(self, *, chat_id, prompt, source_label):
            await asyncio.sleep(60)  # claude turn duration

    orch = _SlowOrch()
    server = InjectServer(
        bind="127.0.0.1:0",
        shared_secret=SECRET,
        default_chat_id=42,
        orchestrator=orch,
    )
    app = web.Application()
    app.router.add_post("/inject", server._handle_inject)
    async with TestClient(TestServer(app)) as c:
        import time
        t0 = time.time()
        r = await c.post(
            "/inject",
            headers={"Authorization": f"Bearer {SECRET}"},
            json={"prompt": "hi"},
        )
        elapsed = time.time() - t0
        assert r.status == 200
        # Tight bound: should be <0.5s, not the 60s the orchestrator
        # would block for. CI host can be slow, so 1s is the budget.
        assert elapsed < 1.0, f"inject took {elapsed:.2f}s — handler is blocking on submit_external"


# --------------- Edge: constant-time comparison ---------------


@pytest.mark.asyncio
async def test_short_partial_secret_rejected(client):
    """A near-miss bearer (correct prefix, wrong suffix) must still 401.
    `secrets.compare_digest` ensures no timing leak — pin the rejection."""
    c, _ = client
    near_miss = SECRET[:-1] + "y"
    r = await c.post("/inject",
                     headers={"Authorization": f"Bearer {near_miss}"},
                     json={"prompt": "hi"})
    assert r.status == 401


# --------------- Stress / concurrency / abuse ---------------


@pytest.mark.asyncio
async def test_concurrent_injects_all_accepted_and_serialized(client):
    """Stress: fire 5 valid injects in parallel. The HTTP layer accepts all
    five at once, but the orchestrator's turn lock serialises them — pin
    that every submit lands exactly once and all 5 get a 200."""
    c, orch = client
    bodies = [{"prompt": f"msg-{i}"} for i in range(5)]

    async def fire(b):
        r = await c.post(
            "/inject",
            headers={"Authorization": f"Bearer {SECRET}"},
            json=b,
        )
        return r.status

    statuses = await asyncio.gather(*(fire(b) for b in bodies))
    assert statuses == [200] * 5
    assert len(orch.calls) == 5
    seen = sorted(call["prompt"] for call in orch.calls)
    assert seen == [f"msg-{i}" for i in range(5)]


@pytest.mark.asyncio
async def test_inject_during_in_flight_turn_queues(monkeypatch):
    """Edge: a user turn is already running when /inject arrives. The
    orchestrator's `submit_external` blocks on the same turn lock as
    user-driven `submit_inbound`, so the inject is queued, not lost."""
    from waggle.orchestrator import WaggleOrchestrator
    from waggle.config import load
    import textwrap, tempfile

    # Real orchestrator + stubbed claude that reports completion only when
    # we set an external event. Lets us hold the lock open while firing
    # an inject from another task.
    cfg_text = textwrap.dedent(
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: "1234567890:secret-token"
        access:
          users: [42]
        owner:
          user_id: 42
        """
    ).lstrip()
    from pathlib import Path
    with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as fh:
        fh.write(cfg_text)
        cfg_path = Path(fh.name)

    cfg = load(cfg_path)
    orch = WaggleOrchestrator(cfg, cfg_path)

    release = asyncio.Event()
    started = asyncio.Event()

    class _SlowClaude:
        async def start(self): ...
        async def stop(self): ...
        async def send_user(self, content):
            started.set()
            await release.wait()  # turn1 holds the lock until released

        async def read_events(self):
            # First turn yields a result only after release
            await release.wait()
            yield "result", {"type": "result", "result": "first done", "is_error": False}

    orch.claude = _SlowClaude()  # type: ignore

    class _T:
        async def reply(self, **kw): return "1"
        async def edit_text(self, **kw): pass
        async def delete_message(self, **kw): pass
    orch.telegram = _T()  # type: ignore
    await orch.access.start()

    # Start turn 1 (will block in send_user until release)
    turn1 = asyncio.create_task(orch.submit_inbound(
        chat_id=42, user_id=42, username="u",
        message_id="1", text="user msg",
    ))
    await started.wait()

    # Fire an inject — submit_external must block on the lock, not crash
    inject_task = asyncio.create_task(orch.submit_external(
        chat_id=99, prompt="external!",
    ))
    # Confirm inject hasn't completed (waiting on lock)
    await asyncio.sleep(0.05)
    assert not inject_task.done()

    # Release turn1 — now turn1 finishes, then inject runs
    release.set()
    await turn1
    # Without a separate release for turn 2 we'd block forever; signal
    # again so the second turn's read_events returns
    # (single-shot Event already set; the generator yields once and exits)
    await asyncio.wait_for(inject_task, timeout=2)
    assert inject_task.done() and inject_task.exception() is None

    await orch.access.stop()


@pytest.mark.asyncio
async def test_large_payload_rejected_gracefully(client):
    """A 5 MB prompt must not crash the server. aiohttp's `client_max_size`
    defaults to 1 MB — bodies above the limit fail to parse and our handler
    converts the exception into a 400. 413 (request entity too large) is
    also acceptable if a future aiohttp version surfaces the limit
    explicitly. The contract is "no 5xx, no crash, the next request still
    works"."""
    c, orch = client
    huge = "x" * (5 * 1024 * 1024)
    r = await c.post(
        "/inject",
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"prompt": huge},
    )
    assert r.status in (400, 413), f"unexpected status {r.status}"
    assert orch.calls == []  # never reached the orchestrator
    # Server still alive after the rejection — a normal request still works
    r2 = await c.post(
        "/inject",
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"prompt": "tiny"},
    )
    assert r2.status == 200


@pytest.mark.asyncio
async def test_just_below_max_size_accepted(client):
    """Edge: a payload just under aiohttp's 1 MB default lands as 200.
    Pin the boundary so a future aiohttp upgrade that drops the limit
    surfaces here."""
    c, orch = client
    # Leave room for the JSON envelope ('{"prompt":"…"}') around the body
    body = "x" * (900 * 1024)
    r = await c.post(
        "/inject",
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"prompt": body},
    )
    assert r.status == 200
    assert len(orch.calls) == 1


@pytest.mark.asyncio
async def test_repeated_identical_inject_is_not_deduped(client):
    """Edge / contract pin: the endpoint does NOT deduplicate identical
    bodies. Two posts of the same payload land as two submissions. If we
    ever add idempotency keys, change here AND the test together."""
    c, orch = client
    body = {"prompt": "ring", "chat_id": 42}
    for _ in range(2):
        r = await c.post("/inject",
                         headers={"Authorization": f"Bearer {SECRET}"},
                         json=body)
        assert r.status == 200
    assert len(orch.calls) == 2


@pytest.mark.asyncio
async def test_burst_50_requests_no_state_leak(client):
    """A 50-request burst must not blow up the server (no rate limiter
    today — pin that the absence is at least non-fatal). Each call
    increments the orchestrator counter exactly once."""
    c, orch = client

    async def one(i):
        r = await c.post(
            "/inject",
            headers={"Authorization": f"Bearer {SECRET}"},
            json={"prompt": f"burst-{i}"},
        )
        return r.status

    rs = await asyncio.gather(*(one(i) for i in range(50)))
    assert all(s == 200 for s in rs)
    assert len(orch.calls) == 50
