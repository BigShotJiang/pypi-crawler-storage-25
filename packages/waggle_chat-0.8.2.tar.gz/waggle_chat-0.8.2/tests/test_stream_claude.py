"""StreamClaude — long-lived subprocess wrapper around `claude -p stream-json`.

A real claude binary isn't required; we drive the wrapper with a tiny
shell-script impostor that prints canned NDJSON lines on stdout and
optionally echoes stdin.

Tests pin:
  • happy: send_user → read_events yields each event; final result returns
  • happy: multi-turn (two send_user / read_result cycles on one process)
  • unhappy: subprocess exits early → read_result returns ('', True)
  • unhappy: missing executable raises at construction time
  • edge: malformed JSON lines are skipped, not crashing the parser
  • edge: send_user before start raises a clear RuntimeError
"""

from __future__ import annotations

import asyncio
import textwrap
from datetime import datetime, timezone
from pathlib import Path

import pytest

from waggle.orchestrator import StreamClaude


def _make_fake(tmp_path: Path, behavior: str) -> Path:
    """Tiny shell-script claude impostor."""
    script = tmp_path / "claude"
    if behavior == "echo_then_result":
        # Read one stdin line, emit two events, pause, repeat for next stdin.
        body = textwrap.dedent(
            r"""
            #!/usr/bin/env bash
            while IFS= read -r line; do
                printf '%s\n' '{"type":"system","subtype":"init","session_id":"sid"}'
                printf '%s\n' "$(printf '{"type":"result","subtype":"success","result":%s,"is_error":false}' \
                    "$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$line")")"
            done
            """
        ).strip()
    elif behavior == "with_tool_use":
        body = textwrap.dedent(
            r"""
            #!/usr/bin/env bash
            read -r line
            printf '%s\n' '{"type":"assistant","message":{"content":[{"type":"text","text":"hmm"}]}}'
            printf '%s\n' '{"type":"assistant","message":{"content":[{"type":"tool_use","name":"mcp__waggle-tools__reply","input":{}}]}}'
            printf '%s\n' '{"type":"result","subtype":"success","result":"done","is_error":false}'
            """
        ).strip()
    elif behavior == "exits_immediately":
        body = "#!/usr/bin/env bash\nexit 0\n"
    elif behavior == "garbage_lines":
        body = textwrap.dedent(
            r"""
            #!/usr/bin/env bash
            read -r line
            printf '%s\n' 'not json at all'
            printf '%s\n' ''
            printf '%s\n' '{"type":"result","result":"survived","is_error":false}'
            """
        ).strip()
    else:
        raise ValueError(behavior)
    script.write_text(body + "\n")
    script.chmod(0o755)
    return script


# --------------- Happy ---------------


@pytest.mark.asyncio
async def test_single_turn_round_trip(tmp_path: Path):
    fake = _make_fake(tmp_path, "echo_then_result")
    sc = StreamClaude(executable=str(fake), session_id="abc", cwd=str(tmp_path))
    await sc.start()
    try:
        await sc.send_user("hello")
        result, is_error = await sc.read_result()
        assert is_error is False
        # The script echoes stdin back as the result text.
        assert "hello" in result
    finally:
        await sc.stop()


@pytest.mark.asyncio
async def test_multi_turn_on_one_process(tmp_path: Path):
    """Same subprocess handles two send_user/read_result cycles — the
    'unified context across turns' invariant the v0.3 architecture relies on."""
    fake = _make_fake(tmp_path, "echo_then_result")
    sc = StreamClaude(executable=str(fake), session_id="abc", cwd=str(tmp_path))
    await sc.start()
    try:
        await sc.send_user("turn1")
        r1, _ = await sc.read_result()
        await sc.send_user("turn2")
        r2, _ = await sc.read_result()
        assert "turn1" in r1
        assert "turn2" in r2
    finally:
        await sc.stop()


@pytest.mark.asyncio
async def test_read_events_yields_all_kinds(tmp_path: Path):
    """The orchestrator drives the working-status indicator off this stream;
    pin that we yield assistant + tool_use + result in order."""
    fake = _make_fake(tmp_path, "with_tool_use")
    sc = StreamClaude(executable=str(fake), session_id="abc", cwd=str(tmp_path))
    await sc.start()
    try:
        await sc.send_user("go")
        seen = []
        async for kind, _ in sc.read_events():
            seen.append(kind)
        assert "assistant" in seen
        # tool_use is delivered as an assistant event whose content has a
        # tool_use block (the orchestrator extracts the name from the inner
        # block); the impostor uses that nested shape.
        assert seen[-1] == "result"
    finally:
        await sc.stop()


# --------------- Unhappy ---------------


@pytest.mark.asyncio
async def test_subprocess_exits_immediately(tmp_path: Path):
    fake = _make_fake(tmp_path, "exits_immediately")
    sc = StreamClaude(executable=str(fake), session_id="abc", cwd=str(tmp_path))
    await sc.start()
    try:
        # Don't send anything — script exits without consuming stdin
        result, is_error = await sc.read_result()
        assert is_error is True
        assert result == ""
    finally:
        await sc.stop()


def test_missing_executable_raises_at_construction(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        StreamClaude(executable="absolutely-not-a-real-binary-xyz")


@pytest.mark.asyncio
async def test_send_user_before_start_raises(tmp_path: Path):
    fake = _make_fake(tmp_path, "echo_then_result")
    sc = StreamClaude(executable=str(fake))
    with pytest.raises(RuntimeError):
        await sc.send_user("oops")


# --------------- Edge ---------------


@pytest.mark.asyncio
async def test_garbage_lines_are_skipped(tmp_path: Path):
    """Forward-compat: a non-JSON line on stdout doesn't crash the parser —
    we walk past it and pick up the real result event."""
    fake = _make_fake(tmp_path, "garbage_lines")
    sc = StreamClaude(executable=str(fake), session_id="abc", cwd=str(tmp_path))
    await sc.start()
    try:
        await sc.send_user("go")
        result, is_error = await sc.read_result()
        assert result == "survived"
        assert is_error is False
    finally:
        await sc.stop()
