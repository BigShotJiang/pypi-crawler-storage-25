"""Config loader: env-ref resolution, validation, owner-in-allowlist rule."""

import os
import textwrap
from pathlib import Path

import pytest
from pydantic import ValidationError

from waggle.config import load


def _write(tmp_path: Path, body: str) -> Path:
    p = tmp_path / "config.yaml"
    p.write_text(textwrap.dedent(body).lstrip())
    return p


def test_minimal_valid(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        """,
    )
    cfg = load(cfg_path)
    assert cfg.transports[0].bot_token == "1234567890:secret-token"
    assert cfg.access.users == [42]
    assert cfg.owner.user_id == 42
    assert cfg.events.reject_sink == "stdout"  # default


def test_missing_required_fails(tmp_path: Path):
    cfg_path = _write(tmp_path, "transports: []\naccess:\n  users: []\n")
    with pytest.raises(ValidationError):
        load(cfg_path)


def test_events_sink_http_requires_url(tmp_path: Path, monkeypatch):
    """P6: a misconfigured http sink fails LOUDLY at load time, not silently
    in a swallowed warning the operator can't see."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        events:
          sink:
            kind: http
            url: ""
            secret: 0123456789abcdef0123456789abcdef
        """,
    )
    with pytest.raises(ValidationError, match="url"):
        load(cfg_path)


def test_events_sink_http_requires_long_secret(tmp_path: Path, monkeypatch):
    """Spec: same min-length rule as inject.shared_secret — defends against
    trivially guessable bearers when the ingest URL is internet-facing."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        events:
          sink:
            kind: http
            url: https://obs.example/ingest
            secret: short
        """,
    )
    with pytest.raises(ValidationError, match="secret"):
        load(cfg_path)


def test_events_sink_http_valid(tmp_path: Path, monkeypatch):
    """Happy path — full structured P6 sink config loads cleanly."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    monkeypatch.setenv("WAGGLE_OBS_SECRET", "0123456789abcdef0123456789abcdef")
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        events:
          sink:
            kind: http
            url: https://obs.example/ingest
            secret: env:WAGGLE_OBS_SECRET
            timeout_seconds: 7.5
        """,
    )
    cfg = load(cfg_path)
    assert cfg.events.sink.kind == "http"
    assert cfg.events.sink.url == "https://obs.example/ingest"
    assert cfg.events.sink.secret == "0123456789abcdef0123456789abcdef"
    assert cfg.events.sink.timeout_seconds == 7.5


def test_events_sink_stdout_requires_no_url(tmp_path: Path, monkeypatch):
    """`kind: stdout` does not require url/secret. Operator can use the
    structured form without filling in fields they don't need."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        events:
          sink:
            kind: stdout
        """,
    )
    cfg = load(cfg_path)
    assert cfg.events.sink.kind == "stdout"


def test_owner_must_be_in_allowlist(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 999
        """,
    )
    with pytest.raises(ValidationError) as ei:
        load(cfg_path)
    assert "owner.user_id must be present" in str(ei.value)


def test_env_ref_missing_resolves_empty(tmp_path: Path, monkeypatch):
    monkeypatch.delenv("WAGGLE_TG_BOT_TOKEN", raising=False)
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        """,
    )
    # bot_token has min_length=10; empty string fails validation loudly
    with pytest.raises(ValidationError):
        load(cfg_path)


def test_groups_parse(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
          groups:
            -1001234567890:
              users: [42, 99]
        owner:
          user_id: 42
        """,
    )
    cfg = load(cfg_path)
    assert -1001234567890 in cfg.access.groups
    assert cfg.access.groups[-1001234567890].users == [42, 99]


def test_short_bot_token_fails(tmp_path: Path):
    cfg_path = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: short
        access:
          users: [42]
        owner:
          user_id: 42
        """,
    )
    with pytest.raises(ValidationError):
        load(cfg_path)


def test_invalid_yaml_fails(tmp_path: Path):
    p = tmp_path / "config.yaml"
    p.write_text("transports: [\n  - name: tg\n  bot_token: invalid")  # broken yaml
    with pytest.raises(Exception):  # yaml.YAMLError or wrapper
        load(p)


def test_file_not_found(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        load(tmp_path / "does-not-exist.yaml")


def test_unsupported_transport_kind(tmp_path: Path):
    p = _write(
        tmp_path,
        """
        transports:
          - name: x
            kind: discord
            bot_token: 1234567890:totally-real
        access:
          users: [42]
        owner:
          user_id: 42
        """,
    )
    with pytest.raises(ValidationError):
        load(p)


def test_env_ref_in_non_token_field_passes_through(tmp_path: Path, monkeypatch):
    """env: refs work everywhere strings are accepted; we don't restrict
    to bot_token. Verifies the loader's general resolver."""
    monkeypatch.setenv("WAGGLE_TG_NAME", "tg-from-env")
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: env:WAGGLE_TG_NAME
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        """,
    )
    cfg = load(p)
    assert cfg.transports[0].name == "tg-from-env"


def test_env_ref_only_replaces_exact_match(tmp_path: Path, monkeypatch):
    """Edge: `env:VAR` is the marker. A value containing the literal text
    'env:something' inline should NOT be substituted — we only treat a
    string that's EXACTLY the env-ref form."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: "tg-not-env:VAR"
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        """,
    )
    cfg = load(p)
    # Name with embedded colon is preserved verbatim
    assert cfg.transports[0].name == "tg-not-env:VAR"


def test_negative_chat_id_for_groups(tmp_path: Path, monkeypatch):
    """Edge: Telegram supergroup chat ids are negative. The schema uses
    `dict[int, AccessGroup]` — pin that the YAML int parser handles
    negative keys."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
          groups:
            -1009999999999:
              users: [42]
        owner:
          user_id: 42
        """,
    )
    cfg = load(p)
    assert -1009999999999 in cfg.access.groups


def test_owner_in_per_group_list_satisfies_owner_validator(tmp_path: Path, monkeypatch):
    """Edge: the owner-must-be-in-allowlist validator checks the GLOBAL
    users list. Owner being only in a per-group list shouldn't satisfy it
    — they need to be in `access.users` to DM the bot at all."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: []
          groups:
            -1001234:
              users: [42]
        owner:
          user_id: 42
        """,
    )
    with pytest.raises(ValidationError):
        load(p)


def test_inject_enabled_requires_secret(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        inject:
          enabled: true
          default_chat_id: 42
        """,
    )
    with pytest.raises(ValidationError) as ei:
        load(p)
    assert "shared_secret" in str(ei.value)


def test_inject_enabled_requires_long_secret(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        inject:
          enabled: true
          shared_secret: short
          default_chat_id: 42
        """,
    )
    with pytest.raises(ValidationError):
        load(p)


def test_inject_enabled_requires_default_chat(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        inject:
          enabled: true
          shared_secret: aaaaaaaaaaaaaaaaaa
        """,
    )
    with pytest.raises(ValidationError) as ei:
        load(p)
    assert "default_chat_id" in str(ei.value)


def test_inject_disabled_skips_validation(tmp_path: Path, monkeypatch):
    """Edge: when `inject.enabled` is false (the default), the secret +
    default_chat_id checks must be skipped — operators shouldn't have to
    fill in fields they're not using."""
    monkeypatch.setenv("WAGGLE_TG_BOT_TOKEN", "1234567890:secret-token")
    p = _write(
        tmp_path,
        """
        transports:
          - name: tg
            kind: telegram
            bot_token: env:WAGGLE_TG_BOT_TOKEN
        access:
          users: [42]
        owner:
          user_id: 42
        inject:
          enabled: false
        """,
    )
    cfg = load(p)
    assert cfg.inject.enabled is False
    assert cfg.inject.shared_secret == ""


def test_multiple_transports_allowed(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("TOK1", "1234567890:tok-one")
    monkeypatch.setenv("TOK2", "1234567890:tok-two")
    p = _write(
        tmp_path,
        """
        transports:
          - name: tg-a
            kind: telegram
            bot_token: env:TOK1
          - name: tg-b
            kind: telegram
            bot_token: env:TOK2
        access:
          users: [42]
        owner:
          user_id: 42
        """,
    )
    cfg = load(p)
    assert len(cfg.transports) == 2
    assert cfg.transports[0].name == "tg-a"
    assert cfg.transports[1].name == "tg-b"
