"""Working-status indicator (§1.9 / Phase 2.5).

Per-turn lifecycle: attach → set_state × N → success() OR error(msg).

The tests pin:
  • attach posts "🤔 Thinking…" and remembers the message id
  • set_state edits the message in place — debounced, coalescing bursts
  • success() deletes the status message
  • error() deletes status AND posts a new ❌ Error reply
  • set_state with the same label as current is a no-op (no edit traffic)
"""

from __future__ import annotations

import asyncio

import pytest

from waggle.status_indicator import StatusIndicator


class _FakeTelegram:
    def __init__(self):
        self.replies: list[dict] = []
        self.edits: list[dict] = []
        self.deletes: list[dict] = []
        self.markup_edits: list[dict] = []
        self._next_id = 100

    async def reply(self, *, chat_id, text, reply_to=None, format="text",
                     reply_markup=None):
        self._next_id += 1
        mid = str(self._next_id)
        self.replies.append({
            "chat_id": chat_id, "text": text, "reply_to": reply_to,
            "message_id": mid, "reply_markup": reply_markup,
        })
        return mid

    async def edit_text(self, *, chat_id, message_id, text, reply_markup=None):
        self.edits.append({
            "chat_id": chat_id, "message_id": message_id, "text": text,
            "reply_markup": reply_markup,
        })

    async def edit_reply_markup(self, *, chat_id, message_id, reply_markup=None):
        self.markup_edits.append({
            "chat_id": chat_id, "message_id": message_id,
            "reply_markup": reply_markup,
        })

    async def delete_message(self, *, chat_id, message_id):
        self.deletes.append({"chat_id": chat_id, "message_id": message_id})


# --------------- Lifecycle ---------------


@pytest.mark.asyncio
async def test_attach_posts_thinking_label():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42, reply_to="9")
    assert len(tg.replies) == 1
    assert tg.replies[0]["chat_id"] == "42"
    assert tg.replies[0]["reply_to"] == "9"
    assert "Thinking" in tg.replies[0]["text"]


@pytest.mark.asyncio
async def test_attach_is_idempotent_within_turn():
    """Per §1.9 — same chat sending multiple inbounds during ONE turn
    should re-use the existing status message, not stack new ones."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.attach(42)
    await ind.attach(42)
    assert len(tg.replies) == 1


@pytest.mark.asyncio
async def test_success_deletes_status():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.success()
    assert len(tg.deletes) == 1
    assert tg.deletes[0]["chat_id"] == "42"
    assert tg.deletes[0]["message_id"] == tg.replies[0]["message_id"]


@pytest.mark.asyncio
async def test_error_deletes_status_and_posts_error_reply():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.error("subprocess died")
    # Original Thinking + new error reply
    assert len(tg.replies) == 2
    assert "Error" in tg.replies[1]["text"]
    assert "subprocess died" in tg.replies[1]["text"]
    assert len(tg.deletes) == 1


@pytest.mark.asyncio
async def test_error_with_empty_message_falls_back():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.error("")
    assert "❌ Error" in tg.replies[1]["text"]


# --------------- Edits ---------------


@pytest.mark.asyncio
async def test_set_state_to_same_label_is_noop():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.set_state(StatusIndicator.LABEL_THINKING)  # already that label
    await asyncio.sleep(0.05)
    assert tg.edits == []


@pytest.mark.asyncio
async def test_set_state_changes_label_after_debounce(monkeypatch):
    """Edit lands after the debounce window. We compress the window so the
    test stays fast."""
    monkeypatch.setattr("waggle.status_indicator.DEBOUNCE_SECONDS", 0.05)
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.set_state("🔧 Tool: web_search")
    # The edit fires inside an asyncio.create_task → wait long enough for it
    await asyncio.sleep(0.2)
    assert len(tg.edits) == 1
    assert tg.edits[0]["text"] == "🔧 Tool: web_search"


@pytest.mark.asyncio
async def test_bursty_set_state_coalesces(monkeypatch):
    """Two state changes within the debounce window collapse into ONE
    edit carrying the latest label — Telegram rate-limit safe."""
    monkeypatch.setattr("waggle.status_indicator.DEBOUNCE_SECONDS", 0.05)
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.set_state("🔧 Tool: a")
    await ind.set_state("🔧 Tool: b")
    await ind.set_state("🔧 Tool: c")
    await asyncio.sleep(0.2)
    # Could be 1 (perfect coalesce) or 2 (one before debounce window arms).
    # Pin: never more than 2 edits for 3 inputs, and the last one must be 'c'.
    assert 1 <= len(tg.edits) <= 2
    assert tg.edits[-1]["text"] == "🔧 Tool: c"


@pytest.mark.asyncio
async def test_attach_failure_doesnt_register():
    """If posting the status message fails, we silently skip — operator
    isn't blocked by Telegram hiccups."""
    class _BadTelegram(_FakeTelegram):
        async def reply(self, **kw):
            raise RuntimeError("rate limited")
    tg = _BadTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    # No state to change — set_state on missing chat is a silent no-op
    await ind.set_state("🔧 Tool: x")
    await ind.success()
    assert tg.deletes == []


@pytest.mark.asyncio
async def test_set_state_on_unattached_chat_is_silent():
    """Edge: orchestrator might call set_state before attach (race during
    pod startup). Don't crash — there's nothing to edit yet."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.set_state("🔧 Tool: x")
    assert tg.edits == []


# ---- Show-transcript inline-keyboard button ----


@pytest.mark.asyncio
async def test_attach_posts_show_thinking_button():
    """Initial Thinking message has a `📋 Show thinking` button as the
    first button in the indicator's keyboard row."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    markup = tg.replies[0]["reply_markup"]
    assert markup is not None
    rows = markup.inline_keyboard
    assert len(rows) == 1
    btn = rows[0][0]
    assert "Show thinking" in btn.text
    assert btn.callback_data == "t:show"


@pytest.mark.asyncio
async def test_show_thinking_posts_new_message_with_refresh_button():
    """First tap on Show thinking posts a NEW reply with a `🔄 Refresh`
    button on the message itself. The indicator's keyboard stays
    untouched — refresh lives on the surface message, not the indicator."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42, reply_to="9")
    ind.append_thinking(42, "first thought block")
    ind.append_thinking(42, "reply tool call")
    await ind.show_thinking(42)
    # 1 indicator reply + 1 thinking reply
    assert len(tg.replies) == 2
    thinking_reply = tg.replies[1]
    assert "first thought block" in thinking_reply["text"]
    assert "reply" in thinking_reply["text"]
    # Thinking message has 🧠 Thinking header
    assert thinking_reply["text"].startswith("🧠 Thinking")
    # Replies-to the original inbound for context
    assert thinking_reply["reply_to"] == "9"
    # Refresh button is on the thinking message itself
    btn = thinking_reply["reply_markup"].inline_keyboard[0][0]
    assert "Refresh" in btn.text
    assert btn.callback_data == "t:refresh"
    # Indicator's keyboard NOT swapped (no markup edits on indicator)
    assert tg.markup_edits == []


@pytest.mark.asyncio
async def test_show_thinking_with_empty_buffer_shows_placeholder():
    """No events buffered yet — placeholder instead of empty text."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.show_thinking(42)
    assert len(tg.replies) == 2
    body = tg.replies[1]["text"].lower()
    assert "no events yet" in body or "spinning up" in body


@pytest.mark.asyncio
async def test_show_thinking_refresh_edits_existing_message():
    """Second tap (Refresh) edits the existing transcript message rather
    than posting another one."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.append_thinking(42, "💬 first")
    await ind.show_thinking(42)  # first tap → posts
    ind.append_thinking(42, "🔧 tool")
    await ind.show_thinking(42)  # second tap → edits
    # Still only 2 replies (indicator + transcript), but 1 edit landed
    assert len(tg.replies) == 2
    assert len(tg.edits) == 1
    assert "first" in tg.edits[0]["text"]
    assert "tool" in tg.edits[0]["text"]


@pytest.mark.asyncio
async def test_show_thinking_truncates_overflowing_buffer():
    """Telegram caps message text at 4096 chars. Long buffers get a
    marker prefix and are tail-clipped."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    for _ in range(20):
        ind.append_thinking(42, "💬 " + "x" * 600)
    await ind.show_thinking(42)
    text = tg.replies[1]["text"]
    assert len(text) <= 4000
    assert "truncated" in text.lower()


@pytest.mark.asyncio
async def test_set_state_continues_after_transcript_opened(monkeypatch):
    """The transcript view is its own message; the indicator keeps
    rolling its label independently. set_state must keep landing edits
    on the indicator after the user opens the transcript."""
    monkeypatch.setattr("waggle.status_indicator.DEBOUNCE_SECONDS", 0.05)
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.show_thinking(42)
    edits_before = len(tg.edits)
    await ind.set_state("🔧 Tool: foo")
    await asyncio.sleep(0.2)
    # A new edit on the indicator landed (label change after transcript open)
    assert len(tg.edits) == edits_before + 1
    assert tg.edits[-1]["text"] == "🔧 Tool: foo"


@pytest.mark.asyncio
async def test_success_always_deletes_indicator():
    """The indicator gets cleaned up on success even when the user has
    opened the transcript — the transcript message is its own surface
    with its own lifetime."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.append_thinking(42, "💬 hi")
    await ind.show_thinking(42)
    await ind.success()
    # Indicator deleted
    assert len(tg.deletes) == 1
    indicator_mid = tg.replies[0]["message_id"]
    assert tg.deletes[0]["message_id"] == indicator_mid


@pytest.mark.asyncio
async def test_success_deletes_when_transcript_never_opened():
    """No transcript opened → indicator deleted, no extra surfaces."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.append_thinking(42, "💬 internal blah")
    await ind.success()
    assert len(tg.deletes) == 1
    assert len(tg.replies) == 1  # only the indicator was posted


@pytest.mark.asyncio
async def test_show_thinking_on_unattached_chat_is_safe():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.show_thinking(999)
    assert tg.replies == []
    assert tg.edits == []


def test_append_thinking_on_unattached_chat_is_safe():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    ind.append_thinking(999, "stray entry")


@pytest.mark.asyncio
async def test_append_thinking_buffers_raw_block():
    """append_thinking stores the raw extended-thinking text — no emoji
    prefix added (the model's reasoning speaks for itself)."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.append_thinking(42, "old-style block")
    await ind.show_thinking(42)
    body = tg.replies[1]["text"]
    assert "old-style block" in body


# ---- Show-tasklist inline-keyboard button ----


@pytest.mark.asyncio
async def test_attach_posts_tasks_button_alongside_transcript():
    """The indicator's inline keyboard ships with TWO buttons by default:
    transcript + tasks. Both start in 'Show' mode."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    rows = tg.replies[0]["reply_markup"].inline_keyboard
    assert len(rows) == 1 and len(rows[0]) == 2
    transcript_btn, tasks_btn = rows[0]
    assert "Show thinking" in transcript_btn.text
    assert transcript_btn.callback_data == "t:show"
    assert "Show tasks" in tasks_btn.text
    assert tasks_btn.callback_data == "tk:show"


@pytest.mark.asyncio
async def test_show_tasklist_renders_todos_with_refresh_button():
    """Tap on Show tasks → post a new reply with the rendered TodoWrite
    snapshot. Refresh button is on the tasklist message itself; indicator
    keyboard stays the same."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42, reply_to="9")
    ind.update_tasklist(42, [
        {"content": "Set up project", "status": "completed"},
        {"content": "Write tests", "status": "in_progress"},
        {"content": "Add docs", "status": "pending"},
    ])
    await ind.show_tasklist(42)
    assert len(tg.replies) == 2
    body = tg.replies[1]["text"]
    assert "📋" in body
    assert "1/3" in body
    assert "✅ Set up project" in body
    assert "🔄 Write tests" in body
    assert "⏳ Add docs" in body
    # Refresh button is on the tasklist message itself
    btn = tg.replies[1]["reply_markup"].inline_keyboard[0][0]
    assert "Refresh" in btn.text
    assert btn.callback_data == "tk:refresh"
    # Indicator's keyboard untouched
    assert tg.markup_edits == []


@pytest.mark.asyncio
async def test_show_tasklist_with_no_todos_shows_placeholder():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    await ind.show_tasklist(42)
    body = tg.replies[1]["text"].lower()
    assert "no tasks" in body


@pytest.mark.asyncio
async def test_show_tasklist_refresh_edits_existing_message():
    """Second tap on tasks (Refresh) edits the existing tasklist message
    rather than posting another one. Captures live updates as TodoWrite
    snapshots overwrite the previous one."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.update_tasklist(42, [{"content": "first", "status": "pending"}])
    await ind.show_tasklist(42)  # post
    ind.update_tasklist(42, [
        {"content": "first", "status": "completed"},
        {"content": "second", "status": "in_progress"},
    ])
    await ind.show_tasklist(42)  # refresh
    assert len(tg.replies) == 2  # still just indicator + tasklist
    assert len(tg.edits) == 1
    assert "1/2" in tg.edits[0]["text"]
    assert "✅ first" in tg.edits[0]["text"]
    assert "🔄 second" in tg.edits[0]["text"]


@pytest.mark.asyncio
async def test_update_tasklist_overwrites_snapshot():
    """update_tasklist replaces (not appends) — TodoWrite emits the full
    list each time, so older snapshots are stale."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.update_tasklist(42, [{"content": "old", "status": "pending"}])
    ind.update_tasklist(42, [{"content": "new", "status": "completed"}])
    await ind.show_tasklist(42)
    body = tg.replies[1]["text"]
    assert "old" not in body
    assert "new" in body


@pytest.mark.asyncio
async def test_show_tasklist_on_unattached_chat_is_safe():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.show_tasklist(999)
    assert tg.replies == []


def test_update_tasklist_on_unattached_chat_is_safe():
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    ind.update_tasklist(999, [{"content": "x", "status": "pending"}])


@pytest.mark.asyncio
async def test_success_finalises_tasklist_message_too():
    """If user opened tasks during the turn, the persistent message gets
    a final refresh on success so it shows the last state, not a stale
    snapshot from when the user first tapped."""
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.update_tasklist(42, [{"content": "a", "status": "pending"}])
    await ind.show_tasklist(42)
    ind.update_tasklist(42, [{"content": "a", "status": "completed"}])
    await ind.success()
    # Final refresh should have edited the tasklist message with the
    # completed status.
    last_edit = tg.edits[-1]
    assert "✅ a" in last_edit["text"]


@pytest.mark.asyncio
async def test_both_surfaces_can_be_open_simultaneously(monkeypatch):
    """User can have BOTH thinking and tasks open at the same time;
    each lives in its own message with its own Refresh button. The
    indicator's keyboard is NEVER swapped — it stays Show/Show."""
    monkeypatch.setattr("waggle.status_indicator.DEBOUNCE_SECONDS", 0.01)
    tg = _FakeTelegram()
    ind = StatusIndicator(tg)
    await ind.attach(42)
    ind.append_thinking(42, "hi")
    ind.update_tasklist(42, [{"content": "task", "status": "pending"}])
    await ind.show_thinking(42)
    await ind.show_tasklist(42)
    # Indicator + thinking message + tasklist message = 3 replies
    assert len(tg.replies) == 3
    # Each surface message carries its own Refresh button
    thinking_btn = tg.replies[1]["reply_markup"].inline_keyboard[0][0]
    tasks_btn = tg.replies[2]["reply_markup"].inline_keyboard[0][0]
    assert thinking_btn.callback_data == "t:refresh"
    assert tasks_btn.callback_data == "tk:refresh"
    # Indicator's keyboard untouched
    assert tg.markup_edits == []
