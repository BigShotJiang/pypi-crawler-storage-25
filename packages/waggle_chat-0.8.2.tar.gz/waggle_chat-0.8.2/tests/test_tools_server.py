"""tools_server — MCP outbound tools for claude.

We don't bring up a real MCP session here. Instead we drive the tool
dispatcher directly via the `_call_tool` handler the SDK registers, with
a stubbed Bot so no Telegram traffic happens.

Tests pin:
  • Tool list shape — five tools, each with a description + input schema
  • happy: reply tool sends with right args (chat_id, text, reply_to)
  • happy: send_to_chat omits reply_to even if caller provides one
  • happy: react / edit_message / download_attachment forward args correctly
  • unhappy: missing required argument surfaces an error response
  • unhappy: bot raising propagates as a tool error response (no crash)
  • edge: format=markdownv2 maps to the right parse_mode override
"""

from __future__ import annotations

import os

import pytest

from waggle.tools_server import _TOOL_SCHEMAS, ToolsServer


class _FakeBot:
    def __init__(self, *, raise_on=None):
        self.calls: list[tuple[str, dict]] = []
        self._raise_on = raise_on
        self._counter = 1000

    async def send_message(self, **kwargs):
        if self._raise_on == "send_message":
            raise RuntimeError("simulated send fail")
        self.calls.append(("send_message", kwargs))
        self._counter += 1
        return type("Sent", (), {"message_id": self._counter})()

    async def send_photo(self, **kwargs):
        if self._raise_on == "send_photo":
            raise RuntimeError("simulated send_photo fail")
        self.calls.append(("send_photo", kwargs))
        self._counter += 1
        return type("Sent", (), {"message_id": self._counter})()

    async def send_document(self, **kwargs):
        if self._raise_on == "send_document":
            raise RuntimeError("simulated send_document fail")
        self.calls.append(("send_document", kwargs))
        self._counter += 1
        return type("Sent", (), {"message_id": self._counter})()

    async def set_message_reaction(self, **kwargs):
        if self._raise_on == "set_message_reaction":
            raise RuntimeError("simulated react fail")
        self.calls.append(("set_message_reaction", kwargs))

    async def edit_message_text(self, **kwargs):
        if self._raise_on == "edit_message_text":
            raise RuntimeError("simulated edit fail")
        self.calls.append(("edit_message_text", kwargs))

    async def get_file(self, file_id):
        self.calls.append(("get_file", {"file_id": file_id}))
        return type("F", (), {"file_path": f"docs/{file_id}.bin"})()

    async def download_file(self, source, *, destination):
        self.calls.append(("download_file", {"source": source, "destination": destination}))


def _make_server(monkeypatch, *, raise_on=None) -> tuple[ToolsServer, _FakeBot]:
    server = ToolsServer(bot_token="x" * 30)
    fake = _FakeBot(raise_on=raise_on)

    async def fake_ensure(self):
        return fake

    monkeypatch.setattr(ToolsServer, "_ensure_bot", fake_ensure)
    return server, fake


async def _call(server: ToolsServer, name: str, args: dict):
    """Drive the call_tool handler directly without an MCP session."""
    from mcp.types import CallToolRequest
    handler = server.mcp.request_handlers[CallToolRequest]
    req = CallToolRequest(method="tools/call", params={"name": name, "arguments": args})
    result = await handler(req)
    return result.root.content[0].text


# --------------- Tool list shape ---------------


def test_advertised_tools_have_required_fields():
    expected = {"reply", "send_to_chat", "react", "edit_message",
                "download_attachment", "reply_with_choices",
                "send_photo", "send_document",
                "request_permission"}
    assert set(_TOOL_SCHEMAS) == expected


def test_tools_server_has_run_method():
    """Regression pin: a previous edit accidentally promoted a helper
    function above `run` so `run` ended up at module level instead of
    on the class. Unit tests in this file invoke the MCP handler
    dispatcher directly and DON'T call `server.run()`, so the bug
    only surfaces in production where claude does spawn the process.

    Live symptom: claude logs 'Initializing server' but never calls
    ListToolsRequest, then says 'MCP tools are disconnected'. Pin the
    method-on-class invariant so a future structural edit can't repeat
    the regression silently."""
    server = ToolsServer(bot_token="x" * 30)
    assert hasattr(server, "run") and callable(getattr(server, "run"))
    # Importable as a method, not a free function
    import inspect
    assert inspect.iscoroutinefunction(server.run)
    for name, (desc, schema) in _TOOL_SCHEMAS.items():
        assert isinstance(desc, str) and len(desc) > 20, f"{name} description too short"
        assert schema.get("type") == "object"
        assert "properties" in schema and schema["properties"]
        assert "required" in schema


# --------------- Happy ---------------


@pytest.mark.asyncio
async def test_reply_forwards_args(monkeypatch):
    server, fake = _make_server(monkeypatch)
    out = await _call(server, "reply", {"chat_id": "42", "text": "hi", "reply_to": "9"})
    assert "sent" in out
    assert fake.calls == [
        ("send_message", {"chat_id": 42, "text": "hi",
                          "parse_mode": None, "reply_to_message_id": 9}),
    ]


@pytest.mark.asyncio
async def test_send_to_chat_drops_reply_to(monkeypatch):
    """`send_to_chat` is the proactive path — it must NOT thread under any
    earlier message even if the caller sends `reply_to`."""
    server, fake = _make_server(monkeypatch)
    await _call(server, "send_to_chat", {"chat_id": "42", "text": "proactive", "reply_to": "9"})
    sent = fake.calls[0][1]
    assert "reply_to_message_id" not in sent


@pytest.mark.asyncio
async def test_react_forwards_emoji(monkeypatch):
    server, fake = _make_server(monkeypatch)
    out = await _call(server, "react", {"chat_id": "42", "message_id": "9", "emoji": "🔥"})
    assert "reacted" in out
    method, args = fake.calls[0]
    assert method == "set_message_reaction"
    assert args["chat_id"] == 42 and args["message_id"] == 9
    assert args["reaction"][0].emoji == "🔥"


@pytest.mark.asyncio
async def test_edit_message_forwards_text(monkeypatch):
    server, fake = _make_server(monkeypatch)
    await _call(server, "edit_message", {"chat_id": "42", "message_id": "9", "text": "v2"})
    assert fake.calls[0] == (
        "edit_message_text",
        {"chat_id": 42, "message_id": 9, "text": "v2"},
    )


@pytest.mark.asyncio
async def test_download_attachment_returns_path(monkeypatch, tmp_path):
    server, fake = _make_server(monkeypatch)
    server._attachments_dir = str(tmp_path)
    out = await _call(server, "download_attachment", {"file_id": "abc123"})
    assert "path=" in out
    # get_file then download_file
    methods = [c[0] for c in fake.calls]
    assert methods == ["get_file", "download_file"]


# --------------- Unhappy ---------------


@pytest.mark.asyncio
async def test_unknown_tool_returns_error(monkeypatch):
    server, _ = _make_server(monkeypatch)
    out = await _call(server, "nope", {})
    assert "unknown tool" in out or "error:" in out


@pytest.mark.asyncio
async def test_missing_required_arg_returns_error(monkeypatch):
    server, _ = _make_server(monkeypatch)
    out = await _call(server, "reply", {"chat_id": "42"})  # no text
    assert "error:" in out


@pytest.mark.asyncio
async def test_bot_failure_propagates_as_tool_error(monkeypatch):
    """A Telegram API hiccup must not crash the dispatcher — the MCP tool
    response just carries the error string."""
    server, _ = _make_server(monkeypatch, raise_on="send_message")
    out = await _call(server, "reply", {"chat_id": "42", "text": "x"})
    assert "error:" in out
    assert "RuntimeError" in out or "send fail" in out


# --------------- Edge ---------------


@pytest.mark.asyncio
async def test_format_markdownv2_sets_parse_mode(monkeypatch):
    server, fake = _make_server(monkeypatch)
    await _call(server, "reply", {"chat_id": "42", "text": "*bold*", "format": "markdownv2"})
    args = fake.calls[0][1]
    # aiogram's ParseMode.MARKDOWN_V2 is the enum we want; its repr varies
    # across versions, so check the underlying value string.
    assert args["parse_mode"] is not None
    assert args["parse_mode"].value == "MarkdownV2"


@pytest.mark.asyncio
async def test_format_text_overrides_default_html(monkeypatch):
    """The Bot is constructed with HTML default parse_mode; calls passing
    `format=text` must explicitly override to None so user content is sent
    verbatim and not interpreted as HTML."""
    server, fake = _make_server(monkeypatch)
    await _call(server, "reply", {"chat_id": "42", "text": "<not html>", "format": "text"})
    args = fake.calls[0][1]
    assert args["parse_mode"] is None


# --------------- reply_with_choices (P9) ---------------


@pytest.mark.asyncio
async def test_reply_with_choices_builds_inline_keyboard(monkeypatch):
    """Happy: send_message gets reply_markup with one button per choice.
    callback_data shape is `c:<index>` — the telegram client looks up the
    label from the markup on tap."""
    server, fake = _make_server(monkeypatch)
    result = await _call(server, "reply_with_choices", {
        "chat_id": "42",
        "text": "Yes or no?",
        "choices": ["Yes", "No"],
    })
    assert "with 2 choices" in result
    args = fake.calls[0][1]
    markup = args["reply_markup"]
    # InlineKeyboardMarkup.inline_keyboard is list[list[InlineKeyboardButton]]
    flat = [b for row in markup.inline_keyboard for b in row]
    assert [b.text for b in flat] == ["Yes", "No"]
    assert [b.callback_data for b in flat] == ["c:0", "c:1"]


@pytest.mark.asyncio
async def test_reply_with_choices_columns_arrange_rows(monkeypatch):
    server, fake = _make_server(monkeypatch)
    await _call(server, "reply_with_choices", {
        "chat_id": "42",
        "text": "Pick",
        "choices": ["A", "B", "C", "D", "E"],
        "columns": 2,
    })
    markup = fake.calls[0][1]["reply_markup"]
    rows = markup.inline_keyboard
    # 5 buttons, 2 per row → 3 rows: [A,B], [C,D], [E]
    assert [len(r) for r in rows] == [2, 2, 1]
    assert rows[0][0].text == "A" and rows[0][1].text == "B"
    assert rows[2][0].text == "E"


@pytest.mark.asyncio
async def test_reply_with_choices_long_label_truncated(monkeypatch):
    """Telegram caps button text at 64 bytes. Pin: longer labels are
    truncated client-side so the API call doesn't error."""
    server, fake = _make_server(monkeypatch)
    long = "x" * 200
    await _call(server, "reply_with_choices", {
        "chat_id": "42",
        "text": "long",
        "choices": [long],
    })
    markup = fake.calls[0][1]["reply_markup"]
    btn = markup.inline_keyboard[0][0]
    assert len(btn.text) <= 64


@pytest.mark.asyncio
async def test_reply_with_choices_with_reply_to(monkeypatch):
    server, fake = _make_server(monkeypatch)
    await _call(server, "reply_with_choices", {
        "chat_id": "42",
        "text": "?",
        "choices": ["A"],
        "reply_to": "99",
    })
    args = fake.calls[0][1]
    assert args["reply_to_message_id"] == 99


@pytest.mark.asyncio
async def test_reply_with_choices_empty_choices_errors(monkeypatch):
    """Unhappy: empty choices list. The MCP SDK enforces `minItems: 1`
    via the input schema → returns a validation error response, not a
    crash. Either spelling is acceptable contract — pin that the
    response is an error and no Bot.send_message was attempted."""
    server, fake = _make_server(monkeypatch)
    result = await _call(server, "reply_with_choices", {
        "chat_id": "42",
        "text": "?",
        "choices": [],
    })
    assert "error" in result.lower() or "non-empty" in result.lower(), result
    assert fake.calls == [], "no Bot call should have been made"


# --------------- Batch 10: spoiler ---------------


@pytest.mark.asyncio
async def test_reply_with_spoiler_wraps_text(monkeypatch):
    """Happy: spoiler=True wraps text in MarkdownV2 ||...|| syntax and
    forces parse_mode=MarkdownV2 even when caller asked for text."""
    server, fake = _make_server(monkeypatch)
    await _call(server, "reply", {
        "chat_id": "42", "text": "secret answer", "spoiler": True,
    })
    args = fake.calls[0][1]
    assert args["text"] == "||secret answer||"
    assert args["parse_mode"].value == "MarkdownV2"


@pytest.mark.asyncio
async def test_reply_with_spoiler_escapes_special_chars(monkeypatch):
    """Edge: when spoiler upgrades plain text → MarkdownV2, special chars
    in the body MUST be escaped so parse-mode doesn't choke (Telegram is
    strict)."""
    server, fake = _make_server(monkeypatch)
    await _call(server, "reply", {
        "chat_id": "42",
        "text": "hello.world (with stuff)!",
        "spoiler": True,
    })
    args = fake.calls[0][1]
    # Wrap is the OUTER ||...||; everything inside has special chars escaped
    assert args["text"].startswith("||") and args["text"].endswith("||")
    inner = args["text"][2:-2]
    # Spec: . ( ) ! all escaped
    assert "\\." in inner
    assert "\\(" in inner and "\\)" in inner
    assert "\\!" in inner


@pytest.mark.asyncio
async def test_reply_without_spoiler_unchanged(monkeypatch):
    """Pin back-compat: spoiler omitted → text passes through verbatim."""
    server, fake = _make_server(monkeypatch)
    await _call(server, "reply", {"chat_id": "42", "text": "normal"})
    args = fake.calls[0][1]
    assert args["text"] == "normal"
    assert args["parse_mode"] is None


# --------------- Batch 10: send_photo / send_document ---------------


import tempfile


def _make_temp_file(suffix=".bin", content=b"x") -> str:
    """Create a temp file the tool can FSInputFile, return its path."""
    fh = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
    fh.write(content)
    fh.close()
    return fh.name


@pytest.mark.asyncio
async def test_send_photo_uploads_file(monkeypatch):
    server, fake = _make_server(monkeypatch)
    path = _make_temp_file(".png", b"\x89PNG fake")
    try:
        result = await _call(server, "send_photo", {
            "chat_id": "42", "path": path, "caption": "look",
        })
        assert "photo=" in result
        kind, kwargs = fake.calls[0]
        assert kind == "send_photo"
        assert kwargs["chat_id"] == 42
        assert kwargs["caption"] == "look"
        # FSInputFile object — has a `path` attribute
        assert hasattr(kwargs["photo"], "path")
        assert "has_spoiler" not in kwargs
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_send_photo_with_spoiler_sets_has_spoiler(monkeypatch):
    server, fake = _make_server(monkeypatch)
    path = _make_temp_file(".png")
    try:
        await _call(server, "send_photo", {
            "chat_id": "42", "path": path, "spoiler": True,
        })
        kwargs = fake.calls[0][1]
        assert kwargs["has_spoiler"] is True
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_send_photo_missing_file_returns_error(monkeypatch):
    """Unhappy: path doesn't exist on disk → tool error response, not crash."""
    server, fake = _make_server(monkeypatch)
    result = await _call(server, "send_photo", {
        "chat_id": "42", "path": "/nonexistent/path.png",
    })
    assert result.startswith("error:"), result
    # No upload attempt
    assert all(k != "send_photo" for k, _ in fake.calls)


@pytest.mark.asyncio
async def test_send_document_uploads_file(monkeypatch):
    server, fake = _make_server(monkeypatch)
    path = _make_temp_file(".pdf", b"%PDF-1.4 fake")
    try:
        result = await _call(server, "send_document", {
            "chat_id": "42", "path": path, "caption": "report",
        })
        assert "document=" in result
        kind, kwargs = fake.calls[0]
        assert kind == "send_document"
        assert kwargs["chat_id"] == 42
        assert kwargs["caption"] == "report"
    finally:
        os.unlink(path)


@pytest.mark.asyncio
async def test_send_document_with_reply_to(monkeypatch):
    server, fake = _make_server(monkeypatch)
    path = _make_temp_file(".log", b"hello")
    try:
        await _call(server, "send_document", {
            "chat_id": "42", "path": path, "reply_to": "99",
        })
        kwargs = fake.calls[0][1]
        assert kwargs["reply_to_message_id"] == 99
    finally:
        os.unlink(path)


# --------------- Batch 10: _escape_md_v2 helper ---------------


def test_escape_md_v2_handles_all_special_chars():
    from waggle.tools_server import _escape_md_v2
    s = "_*[]()~`>#+-=|{}.!\\"
    out = _escape_md_v2(s)
    # Every special char should be backslash-prefixed (backslash itself is
    # NOT in the spec list — pin that the function only escapes spec chars)
    assert out == "\\_\\*\\[\\]\\(\\)\\~\\`\\>\\#\\+\\-\\=\\|\\{\\}\\.\\!\\"


def test_escape_md_v2_leaves_normal_text_alone():
    from waggle.tools_server import _escape_md_v2
    assert _escape_md_v2("hello world 123") == "hello world 123"


# ---- request_permission policy ----


def test_path_triggers_ask_matches_claude_substring():
    from waggle.tools_server import ToolsServer
    assert ToolsServer._path_triggers_ask({"file_path": "/home/node/.claude/CLAUDE.md"}) is True
    # Case-insensitive
    assert ToolsServer._path_triggers_ask({"file_path": "/foo/Claude_settings.json"}) is True
    # Notebook path
    assert ToolsServer._path_triggers_ask({"notebook_path": "/x/.claude/nb.ipynb"}) is True
    # Generic path field
    assert ToolsServer._path_triggers_ask({"path": "/etc/claude/config"}) is True


def test_path_does_not_trigger_for_unrelated_paths():
    from waggle.tools_server import ToolsServer
    assert ToolsServer._path_triggers_ask({"file_path": "/tmp/foo.txt"}) is False
    assert ToolsServer._path_triggers_ask({"file_path": "/etc/waggle/config.yaml"}) is False
    assert ToolsServer._path_triggers_ask({}) is False
    assert ToolsServer._path_triggers_ask({"file_path": None}) is False


def test_should_ask_claude_files_mode(monkeypatch):
    """`claude_files` mode: only Edit/Write family on claude paths asks."""
    monkeypatch.setenv("WAGGLE_PERMISSION_MODE", "claude_files")
    from waggle.tools_server import ToolsServer
    s = ToolsServer(bot_token="x" * 30)
    # Edit on claude file → ask
    assert s._should_ask("Edit", {"file_path": "/home/node/.claude/CLAUDE.md"}) is True
    # Edit on non-claude file → no ask
    assert s._should_ask("Edit", {"file_path": "/tmp/foo.py"}) is False
    # Bash → no ask (not in ASK_TOOLS)
    assert s._should_ask("Bash", {"command": "rm -rf /"}) is False
    # Read on claude file → no ask (read-only)
    assert s._should_ask("Read", {"file_path": "/home/node/.claude/CLAUDE.md"}) is False


def test_should_ask_strict_mode(monkeypatch):
    """`strict` mode: every tool asks."""
    monkeypatch.setenv("WAGGLE_PERMISSION_MODE", "strict")
    from waggle.tools_server import ToolsServer
    s = ToolsServer(bot_token="x" * 30)
    assert s._should_ask("Bash", {"command": "ls"}) is True
    assert s._should_ask("Read", {"file_path": "/tmp/foo"}) is True
    assert s._should_ask("Edit", {"file_path": "/tmp/bar.txt"}) is True


@pytest.mark.asyncio
async def test_request_permission_auto_allow_for_safe_tool(monkeypatch):
    """Bash + non-claude path → auto-allow, no Bot calls."""
    monkeypatch.setenv("WAGGLE_PERMISSION_MODE", "claude_files")
    server, fake = _make_server(monkeypatch)
    result = await _call(server, "request_permission", {
        "tool_name": "Bash",
        "input": {"command": "echo hi"},
    })
    import json
    payload = json.loads(result)
    assert payload["behavior"] == "allow"
    # No Telegram traffic for auto-allow
    assert all(k != "send_message" for k, _ in fake.calls)


@pytest.mark.asyncio
async def test_request_permission_writes_telegram_for_claude_edit(monkeypatch, tmp_path):
    """Edit on /home/node/.claude/CLAUDE.md must produce a Telegram send
    with Allow/Deny/See-more keyboard, then wait for the verdict file.
    Pre-create the verdict to avoid hanging."""
    monkeypatch.setenv("WAGGLE_PERMISSION_MODE", "claude_files")
    monkeypatch.setenv("WAGGLE_PERMISSION_DIR", str(tmp_path))
    monkeypatch.setenv("WAGGLE_PERMISSION_CHAT_IDS", "908624017")
    server, fake = _make_server(monkeypatch)

    # Pre-write the verdict so the tool returns immediately.
    import json
    request_id_holder = {}

    # Patch send_message to capture the request_id from callback_data
    orig_send = fake.send_message

    async def capture_send(**kwargs):
        markup = kwargs.get("reply_markup")
        if markup is not None:
            for row in markup.inline_keyboard:
                for btn in row:
                    cd = btn.callback_data or ""
                    if cd.startswith("perm:"):
                        request_id_holder["id"] = cd.split(":", 2)[2]
        # Also pre-write verdict so the polling loop sees it
        rid = request_id_holder.get("id")
        if rid:
            (tmp_path / f"{rid}.verdict").write_text(json.dumps({"behavior": "allow"}))
        return await orig_send(**kwargs)

    fake.send_message = capture_send  # type: ignore

    result = await _call(server, "request_permission", {
        "tool_name": "Edit",
        "input": {"file_path": "/home/node/.claude/CLAUDE.md",
                  "old_string": "x", "new_string": "y"},
    })
    payload = json.loads(result)
    assert payload["behavior"] == "allow"
    # Verify Telegram was sent
    sends = [c for c in fake.calls if c[0] == "send_message"]
    assert len(sends) == 1
    sent_kwargs = sends[0][1]
    assert "🔐 Permission" in sent_kwargs["text"]
    assert "/.claude/CLAUDE.md" in sent_kwargs["text"]
    # Keyboard has 3 buttons
    rows = sent_kwargs["reply_markup"].inline_keyboard
    flat = [b for row in rows for b in row]
    assert len(flat) == 3
    assert any(b.callback_data.startswith("perm:allow:") for b in flat)
    assert any(b.callback_data.startswith("perm:deny:") for b in flat)
    assert any(b.callback_data.startswith("perm:more:") for b in flat)


@pytest.mark.asyncio
async def test_request_permission_deny_returns_message(monkeypatch, tmp_path):
    """When verdict is deny, behavior=deny + a message reaches claude."""
    monkeypatch.setenv("WAGGLE_PERMISSION_MODE", "claude_files")
    monkeypatch.setenv("WAGGLE_PERMISSION_DIR", str(tmp_path))
    monkeypatch.setenv("WAGGLE_PERMISSION_CHAT_IDS", "908624017")
    server, fake = _make_server(monkeypatch)

    import json
    request_id_holder = {}

    async def capture_send(**kwargs):
        markup = kwargs.get("reply_markup")
        for row in markup.inline_keyboard:
            for btn in row:
                cd = btn.callback_data or ""
                if cd.startswith("perm:"):
                    request_id_holder["id"] = cd.split(":", 2)[2]
        rid = request_id_holder["id"]
        (tmp_path / f"{rid}.verdict").write_text(json.dumps({
            "behavior": "deny",
            "message": "no thanks",
        }))
        fake.calls.append(("send_message", kwargs))
        fake._counter += 1
        return type("Sent", (), {"message_id": fake._counter})()

    fake.send_message = capture_send  # type: ignore

    result = await _call(server, "request_permission", {
        "tool_name": "Write",
        "input": {"file_path": "/home/node/.claude/settings.json",
                  "content": "..."},
    })
    payload = json.loads(result)
    assert payload["behavior"] == "deny"
    assert payload["message"] == "no thanks"


@pytest.mark.asyncio
async def test_request_permission_no_owner_defaults_allow(monkeypatch, tmp_path):
    """Edge: if no owner chat_id is configured, prompt would hang forever
    waiting for a verdict no one can write. Default to allow + log warn."""
    monkeypatch.setenv("WAGGLE_PERMISSION_MODE", "claude_files")
    monkeypatch.setenv("WAGGLE_PERMISSION_DIR", str(tmp_path))
    monkeypatch.delenv("WAGGLE_PERMISSION_CHAT_IDS", raising=False)
    monkeypatch.setenv("WAGGLE_CONFIG", "/nonexistent.yaml")
    server, fake = _make_server(monkeypatch)
    import json
    result = await _call(server, "request_permission", {
        "tool_name": "Edit",
        "input": {"file_path": "/home/node/.claude/CLAUDE.md"},
    })
    payload = json.loads(result)
    assert payload["behavior"] == "allow"


def test_load_owner_chat_ids_from_env(monkeypatch):
    monkeypatch.setenv("WAGGLE_PERMISSION_CHAT_IDS", "908624017,1234,-1009999")
    from waggle.tools_server import _load_owner_chat_ids
    assert _load_owner_chat_ids() == [908624017, 1234, -1009999]


def test_load_owner_chat_ids_from_config(monkeypatch, tmp_path):
    monkeypatch.delenv("WAGGLE_PERMISSION_CHAT_IDS", raising=False)
    cfg = tmp_path / "config.yaml"
    cfg.write_text("owner:\n  user_id: 42\n")
    monkeypatch.setenv("WAGGLE_CONFIG", str(cfg))
    from waggle.tools_server import _load_owner_chat_ids
    assert _load_owner_chat_ids() == [42]
