"""Channel-tag wire format v1 round-trip + escape rules."""

from datetime import datetime, timezone

from waggle.channel_tag import ChannelTag, parse


def test_render_basic():
    tag = ChannelTag(
        source="telegram",
        chat="-1001234",
        user="908624017",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    out = tag.render("hello world")
    assert out == (
        '<channel source="telegram" chat="-1001234" user="908624017" '
        'ts="2026-04-29T10:00:00Z">\nhello world\n</channel>'
    )


def test_round_trip():
    original = ChannelTag(
        source="telegram",
        chat="-1001234",
        user="908624017",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    rendered = original.render("body with multiple\nlines")
    parsed_tag, parsed_body = parse(rendered)
    assert parsed_tag == original
    assert parsed_body == "body with multiple\nlines"


def test_attribute_escapes():
    # The four chars XML attributes care about
    tag = ChannelTag(
        source="evil&plat",
        chat='evil"chat',
        user="user<x>",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    out = tag.render("body")
    assert "evil&amp;plat" in out
    assert 'evil&quot;chat' in out
    assert "user&lt;x&gt;" in out


def test_now_normalises_utc():
    tag = ChannelTag.now("telegram", -100, 9000)
    assert tag.ts.tzinfo == timezone.utc
    assert tag.chat == "-100"
    assert tag.user == "9000"


def test_empty_body_round_trips():
    tag = ChannelTag(
        source="telegram",
        chat="1",
        user="2",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    parsed_tag, parsed_body = parse(tag.render(""))
    assert parsed_tag == tag
    assert parsed_body == ""


def test_unicode_body_round_trips():
    tag = ChannelTag(
        source="telegram",
        chat="1",
        user="2",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    body = "đ*t mẹ 🔥 — multiline\nwith emoji"
    parsed_tag, parsed_body = parse(tag.render(body))
    assert parsed_tag == tag
    assert parsed_body == body


def test_now_truncates_microseconds_when_rendered():
    """Wire format v1 frozen at second granularity; ChannelTag.now() can
    carry sub-second precision in memory but a render+parse round-trip
    drops microseconds. Pin this so changes to .now() don't accidentally
    break wire format compatibility."""
    tag = ChannelTag.now("telegram", 1, 2)
    parsed, _ = parse(tag.render("body"))
    # Second-level equality
    assert parsed.ts.replace(microsecond=0) == tag.ts.replace(microsecond=0)
    assert parsed.ts.microsecond == 0  # serialized form has no micros


def test_body_with_literal_close_tag_breaks_parser():
    """Documented attack surface: callers must reject `</channel>` upstream.
    The parser is greedy on `body`, so a literal `</channel>` mid-body causes
    a mis-parse — this test pins that behavior so a future refactor that
    silently changes it shows up in CI."""
    import pytest

    tag = ChannelTag.now("telegram", 1, 2)
    rendered = tag.render("a </channel> b")
    # Greedy match captures up to the LAST </channel>, so it parses but
    # body now contains the inner '</channel>'. We document this here.
    parsed_tag, parsed_body = parse(rendered)
    assert "</channel>" in parsed_body  # the embedded one survives
    # And a genuinely malformed block fails to parse
    with pytest.raises(ValueError):
        parse("not a channel tag at all")


# ---- Batch 10: ChannelTag.at() with explicit timestamp ----


def test_at_uses_explicit_ts():
    """When the source carries a real send-time (Telegram message.date),
    the channel-tag ts MUST be that value, not waggle's wall clock."""
    explicit = datetime(2026, 4, 30, 10, 30, 0, tzinfo=timezone.utc)
    tag = ChannelTag.at(source="telegram", chat=42, user=7, ts=explicit)
    assert tag.ts == explicit


def test_at_normalizes_naive_to_utc():
    """Edge: a naive datetime (no tzinfo) is treated as UTC. Telegram's
    pyrogram returns naive UTC; aiogram returns aware UTC. Either works."""
    naive = datetime(2026, 4, 30, 10, 30, 0)
    tag = ChannelTag.at(source="telegram", chat=42, user=7, ts=naive)
    assert tag.ts.tzinfo == timezone.utc
    assert tag.ts.year == 2026 and tag.ts.hour == 10


def test_at_render_emits_explicit_ts():
    explicit = datetime(2026, 4, 30, 10, 30, 0, tzinfo=timezone.utc)
    tag = ChannelTag.at(source="telegram", chat=42, user=7, ts=explicit)
    rendered = tag.render("hello")
    assert "2026-04-30T10:30:00Z" in rendered
