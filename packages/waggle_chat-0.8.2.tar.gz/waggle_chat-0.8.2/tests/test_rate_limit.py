"""Sliding-window rate limiter (P8).

Tests use injected `now=` to drive time deterministically — no asyncio.sleep,
no flakiness from CI host load.
"""

from __future__ import annotations

import pytest

from waggle.rate_limit import RateLimitConfig, RateLimiter


# ---------- Happy ----------


def test_disabled_limiter_always_allows():
    """Default config (0/0) is the no-op limiter."""
    rl = RateLimiter(RateLimitConfig())
    for i in range(50):
        d = rl.check(chat_id=42, user_id=42, now=float(i))
        assert d.allow is True
        assert d.scope == "ok"


def test_user_dimension_limits():
    rl = RateLimiter(RateLimitConfig(user_per_minute=3, window_seconds=60.0))
    # First 3 allowed
    for i in range(3):
        assert rl.check(chat_id=42, user_id=42, now=float(i)).allow
    # 4th over budget
    d = rl.check(chat_id=42, user_id=42, now=3.0)
    assert d.allow is False
    assert d.scope == "user"
    assert d.used == 4
    assert d.limit == 3


def test_chat_dimension_limits():
    """Per-chat budget defends one noisy room from bursting through. Two
    different users in the same chat both contribute to the chat counter."""
    rl = RateLimiter(RateLimitConfig(chat_per_minute=3, window_seconds=60.0))
    assert rl.check(chat_id=1, user_id=42, now=0.0).allow
    assert rl.check(chat_id=1, user_id=43, now=1.0).allow
    assert rl.check(chat_id=1, user_id=44, now=2.0).allow
    d = rl.check(chat_id=1, user_id=45, now=3.0)
    assert d.allow is False
    assert d.scope == "chat"


def test_window_slides():
    """An old hit falls out after window_seconds and frees up a slot."""
    rl = RateLimiter(RateLimitConfig(user_per_minute=2, window_seconds=10.0))
    assert rl.check(chat_id=1, user_id=1, now=0.0).allow
    assert rl.check(chat_id=1, user_id=1, now=5.0).allow
    # 3rd within window — denied
    assert rl.check(chat_id=1, user_id=1, now=8.0).allow is False
    # First sample (t=0) ages out at t=10 → t=11 is allowed
    assert rl.check(chat_id=1, user_id=1, now=11.0).allow


def test_independent_users_have_independent_budgets():
    rl = RateLimiter(RateLimitConfig(user_per_minute=1, window_seconds=60.0))
    assert rl.check(chat_id=1, user_id=1, now=0.0).allow
    # Different user can still send
    assert rl.check(chat_id=1, user_id=2, now=0.5).allow
    # User 1 retried — denied
    assert rl.check(chat_id=1, user_id=1, now=1.0).allow is False


def test_retry_after_is_seconds_until_oldest_falls_out():
    """`retry_after` tells the operator/user how long to wait. Should
    match: oldest_sample + window - now."""
    rl = RateLimiter(RateLimitConfig(user_per_minute=1, window_seconds=10.0))
    rl.check(chat_id=1, user_id=1, now=0.0)
    d = rl.check(chat_id=1, user_id=1, now=3.0)
    assert d.allow is False
    assert d.retry_after == pytest.approx(7.0)  # 0 + 10 - 3


# ---------- Unhappy / edge ----------


def test_denied_calls_do_not_count_against_future_budget():
    """Design choice: denied calls do NOT push the window forward. A
    sender hammering at the limit waits out one window and can try
    again — locked out for window_seconds, not longer.

    The alternative (count-all) punishes flooders harder, but also
    means a friendly user who briefly bursts is locked out
    longer-than-the-window which surprises users."""
    rl = RateLimiter(RateLimitConfig(user_per_minute=2, window_seconds=10.0))
    assert rl.check(chat_id=1, user_id=1, now=0.0).allow
    assert rl.check(chat_id=1, user_id=1, now=1.0).allow
    # 3rd through 10th: all denied, none counted
    for i in range(2, 10):
        assert rl.check(chat_id=1, user_id=1, now=float(i)).allow is False
    # At t=11, the oldest allowed sample (t=0) has just aged out.
    # Window now holds only [1] — we're back under the limit.
    assert rl.check(chat_id=1, user_id=1, now=11.0).allow


def test_zero_chat_disables_chat_dimension_only():
    rl = RateLimiter(RateLimitConfig(chat_per_minute=0, user_per_minute=1, window_seconds=60.0))
    assert rl.check(chat_id=1, user_id=1, now=0.0).allow
    # Chat dim disabled, but user dim catches it
    assert rl.check(chat_id=1, user_id=1, now=1.0).allow is False


def test_update_config_takes_effect_on_next_call():
    rl = RateLimiter(RateLimitConfig(user_per_minute=10, window_seconds=60.0))
    for i in range(5):
        assert rl.check(chat_id=1, user_id=1, now=float(i)).allow
    # Tighten to 2 — existing 5 samples stay in window. Next call denied.
    rl.update_config(RateLimitConfig(user_per_minute=2, window_seconds=60.0))
    d = rl.check(chat_id=1, user_id=1, now=5.0)
    assert d.allow is False
    assert d.scope == "user"


def test_loosen_config_immediately_unblocks():
    """Hot-reloading a HIGHER budget must allow traffic right away,
    not be stuck on old denials."""
    rl = RateLimiter(RateLimitConfig(user_per_minute=2, window_seconds=60.0))
    rl.check(chat_id=1, user_id=1, now=0.0)
    rl.check(chat_id=1, user_id=1, now=1.0)
    # 3rd denied with old config
    assert rl.check(chat_id=1, user_id=1, now=2.0).allow is False
    # Operator raises the limit
    rl.update_config(RateLimitConfig(user_per_minute=10, window_seconds=60.0))
    # Next call allowed
    assert rl.check(chat_id=1, user_id=1, now=3.0).allow


def test_window_seconds_can_be_short():
    """Edge: a 0.5s window with 1 hit/call is the minimum sane config."""
    rl = RateLimiter(RateLimitConfig(user_per_minute=1, window_seconds=0.5))
    assert rl.check(chat_id=1, user_id=1, now=0.0).allow
    assert rl.check(chat_id=1, user_id=1, now=0.4).allow is False
    assert rl.check(chat_id=1, user_id=1, now=0.6).allow  # window slid
