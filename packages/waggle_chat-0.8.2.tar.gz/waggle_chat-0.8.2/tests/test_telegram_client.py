"""Telegram client v0.3: inbound dispatch to orchestrator + drop-empty edge.

Outbound primitives (reply/react/edit/download) are thin aiogram wrappers
exercised by the orchestrator at integration time. Their unit tests would
just be testing aiogram's mocks. The v0.3 unit value is that:

  • Allow-listed inbound calls `orchestrator.submit_inbound(...)` with the
    expected fields.
  • Empty inbound (no text, no caption) is dropped without contacting the
    orchestrator.

Allow-list gating itself moved from the client into the orchestrator —
the client no longer rejects on its own. So the client tests are now
strictly about dispatch shape.
"""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from waggle.clients.telegram import TelegramClient


def _make_message(*, chat_id: int, user_id: int, text: str | None = "hi",
                  message_id: int = 7, username: str | None = "tester",
                  photo: list | None = None, document=None,
                  video=None, audio=None, voice=None, sticker=None,
                  caption: str | None = None, date=None,
                  entities: list | None = None,
                  caption_entities: list | None = None,
                  reply_to_message=None):
    from datetime import datetime, timezone
    chat = SimpleNamespace(id=chat_id, type="private" if chat_id >= 0 else "supergroup")
    user = SimpleNamespace(id=user_id, is_bot=False, username=username)
    return SimpleNamespace(
        chat=chat,
        from_user=user,
        text=text,
        caption=caption,
        message_id=message_id,
        photo=photo,
        document=document,
        video=video,
        audio=audio,
        voice=voice,
        sticker=sticker,
        date=date if date is not None else datetime(2026, 4, 30, 12, 0, 0, tzinfo=timezone.utc),
        entities=entities,
        caption_entities=caption_entities,
        reply_to_message=reply_to_message,
    )


class _FakeOrchestrator:
    def __init__(self):
        self.calls: list[dict] = []

    async def submit_inbound(self, *, chat_id, user_id, username, message_id, text,
                              attachments: tuple = (), ts=None,
                              is_mentioned: bool = False):
        self.calls.append(
            {
                "chat_id": chat_id,
                "user_id": user_id,
                "username": username,
                "message_id": message_id,
                "text": text,
                "attachments": attachments,
                "ts": ts,
                "is_mentioned": is_mentioned,
            }
        )


@pytest.mark.asyncio
async def test_inbound_with_text_dispatches():
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(chat_id=42, user_id=42, text="hello world", message_id=11)
    await client._on_message(msg)
    assert len(orch.calls) == 1
    call = orch.calls[0]
    # Shape pin: every fixed field plus ts is forwarded. ts defaulted in
    # the fixture matches what the orchestrator should see.
    assert call["chat_id"] == 42
    assert call["user_id"] == 42
    assert call["username"] == "tester"
    assert call["message_id"] == "11"
    assert call["text"] == "hello world"
    assert call["attachments"] == ()
    assert call["ts"] == msg.date  # original Telegram send-time


@pytest.mark.asyncio
async def test_inbound_with_caption_dispatches():
    """Caption (used for messages that carry a photo + text caption) flows
    through the same path as plain text."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(chat_id=42, user_id=42, text=None, message_id=11)
    msg.caption = "captioned"
    await client._on_message(msg)
    assert len(orch.calls) == 1
    call = orch.calls[0]
    assert call["text"] == "captioned"
    assert call["attachments"] == ()


@pytest.mark.asyncio
async def test_inbound_username_falls_back_to_id():
    """No public username — substitute the numeric id so meta has a
    stable identifier downstream."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(chat_id=42, user_id=42, text="hi", username=None)
    await client._on_message(msg)
    assert orch.calls[0]["username"] == "42"


@pytest.mark.asyncio
async def test_empty_message_is_dropped():
    """No text, no caption — orchestrator never called. Service messages
    and bot-as-sender chatter shouldn't reach the agent."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(chat_id=42, user_id=42, text=None)
    await client._on_message(msg)
    assert orch.calls == []


@pytest.mark.asyncio
async def test_no_orchestrator_bound_skips():
    """Edge case during shutdown: handler can fire after orchestrator
    is detached. Don't crash."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    msg = _make_message(chat_id=42, user_id=42)
    # client._orchestrator is None
    await client._on_message(msg)  # must not raise


@pytest.mark.asyncio
async def test_orchestrator_failure_doesnt_kill_handler():
    """Unhappy: if `submit_inbound` raises (e.g. claude crashed mid-turn),
    we want the dispatcher to NOT crash so the next inbound still flows.
    Today the client doesn't try/except — pin the current contract: the
    exception propagates out of `_on_message`. If we ever want to swallow
    it instead, change here AND the test together."""
    class _RaisingOrch:
        async def submit_inbound(self, **kw):
            raise RuntimeError("claude died")

    client = TelegramClient(name="t", bot_token="x" * 20)
    client._orchestrator = _RaisingOrch()
    msg = _make_message(chat_id=42, user_id=42, text="ping")
    with pytest.raises(RuntimeError):
        await client._on_message(msg)


@pytest.mark.asyncio
async def test_no_from_user_dropped():
    """Unhappy: channel posts (from_user is None on Telegram channels) and
    anonymous group admin messages have no sender — we can't allow-list-gate
    them and shouldn't surface them to claude."""
    client = TelegramClient(name="t", bot_token="x" * 20)

    class _Orch:
        def __init__(self): self.calls = []
        async def submit_inbound(self, **kw): self.calls.append(kw)

    orch = _Orch()
    client._orchestrator = orch
    msg = _make_message(chat_id=42, user_id=0)
    msg.from_user = None
    await client._on_message(msg)
    assert orch.calls == []


# ---- P6 attachment-by-reference extraction ----


@pytest.mark.asyncio
async def test_inbound_with_photo_extracts_largest_file_id():
    """A photo arrives as a list of PhotoSizes (server-side downscales of the
    same image). For persistence we keep ONLY the largest — the small ones
    are redundant references."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    photo = [
        SimpleNamespace(file_id="thumb-id"),
        SimpleNamespace(file_id="medium-id"),
        SimpleNamespace(file_id="large-id"),  # last == largest
    ]
    msg = _make_message(chat_id=42, user_id=42, text=None, caption="see this", photo=photo)
    await client._on_message(msg)
    assert orch.calls[0]["attachments"] == (
        {"kind": "photo", "file_id": "large-id"},
    )


@pytest.mark.asyncio
async def test_inbound_with_document_includes_mime_type():
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    document = SimpleNamespace(file_id="doc-id", mime_type="application/pdf")
    msg = _make_message(chat_id=42, user_id=42, text="here is the file", document=document)
    await client._on_message(msg)
    assert orch.calls[0]["attachments"] == (
        {"kind": "document", "file_id": "doc-id", "mime_type": "application/pdf"},
    )


@pytest.mark.asyncio
async def test_inbound_with_voice_video_audio_sticker_all_extract():
    """Pin every attachment kind we recognise so adding a new one is a
    deliberate change with a test."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(
        chat_id=42, user_id=42, text="multimedia",
        video=SimpleNamespace(file_id="v-id", mime_type="video/mp4"),
        audio=SimpleNamespace(file_id="a-id", mime_type="audio/mpeg"),
        voice=SimpleNamespace(file_id="o-id", mime_type="audio/ogg"),
        sticker=SimpleNamespace(file_id="s-id"),
    )
    await client._on_message(msg)
    kinds = {a["kind"] for a in orch.calls[0]["attachments"]}
    assert kinds == {"video", "audio", "voice", "sticker"}
    by_kind = {a["kind"]: a for a in orch.calls[0]["attachments"]}
    assert by_kind["video"]["mime_type"] == "video/mp4"
    assert by_kind["sticker"].get("mime_type") is None  # stickers don't carry mime


@pytest.mark.asyncio
async def test_inbound_no_attachments_yields_empty_tuple():
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(chat_id=42, user_id=42, text="plain text")
    await client._on_message(msg)
    assert orch.calls[0]["attachments"] == ()


@pytest.mark.asyncio
async def test_inbound_document_without_mime_type_omits_field():
    """Edge: not every Document has a mime_type. Don't ship a {kind, file_id,
    mime_type: null} entry — just skip the field entirely."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    document = SimpleNamespace(file_id="doc-id", mime_type=None)
    msg = _make_message(chat_id=42, user_id=42, text="hi", document=document)
    await client._on_message(msg)
    att = orch.calls[0]["attachments"][0]
    assert att == {"kind": "document", "file_id": "doc-id"}
    assert "mime_type" not in att


# ---- P9 callback_query (inline keyboard click) ----


def _make_callback(*, chat_id: int, user_id: int, callback_data: str,
                    button_labels: list[str], callback_id: str = "cb-1"):
    """Build a SimpleNamespace mimicking aiogram's CallbackQuery, with a
    message that has reply_markup carrying the buttons in one row."""
    chat = SimpleNamespace(id=chat_id, type="private" if chat_id >= 0 else "supergroup")
    user = SimpleNamespace(id=user_id, is_bot=False, username="trung_zin")
    buttons = [SimpleNamespace(text=l) for l in button_labels]
    markup = SimpleNamespace(inline_keyboard=[buttons])
    message = SimpleNamespace(chat=chat, reply_markup=markup, message_id=99)
    answered = []

    async def answer(*args, **kwargs):
        answered.append(True)

    cb = SimpleNamespace(
        from_user=user, message=message, data=callback_data, id=callback_id,
        answer=answer,
    )
    cb._answered = answered  # exposed for assertions
    return cb


@pytest.mark.asyncio
async def test_callback_query_resolves_label_and_dispatches():
    """Happy: tap on button index 1 → submit_inbound with text='choice: <label>'."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="c:1",
        button_labels=["Yes", "No", "Maybe"],
    )
    await client._on_callback_query(cb)
    assert cb._answered, "callback.answer must be invoked to clear the spinner"
    assert len(orch.calls) == 1
    call = orch.calls[0]
    assert call["text"] == "choice: No"
    assert call["chat_id"] == 42
    assert call["user_id"] == 7510670911
    # message_id synthesised from callback id (real msg has no own id)
    assert call["message_id"] == "cb-1"


@pytest.mark.asyncio
async def test_callback_query_unparsable_data_dropped():
    """Unhappy: callback_data we don't recognise → log + drop, NOT crash.
    The spinner is still cleared."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="not-our-format",
        button_labels=["A", "B"],
    )
    await client._on_callback_query(cb)
    assert cb._answered
    assert orch.calls == []


@pytest.mark.asyncio
async def test_callback_query_index_out_of_range_dropped():
    """Adversarial / stale: callback_data index past the keyboard length →
    drop, no crash."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="c:99",
        button_labels=["A", "B"],
    )
    await client._on_callback_query(cb)
    assert orch.calls == []


@pytest.mark.asyncio
async def test_callback_query_no_orchestrator_safe():
    """Edge: callback fires during shutdown when orchestrator is None.
    Don't crash. Still answer the callback to be polite to Telegram."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._orchestrator = None
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="c:0",
        button_labels=["A"],
    )
    await client._on_callback_query(cb)  # must not raise
    assert cb._answered


@pytest.mark.asyncio
async def test_callback_query_answer_failure_does_not_block_dispatch():
    """A flaky `callback.answer` (network blip) must NOT prevent the
    dispatch — we'd rather lose the spinner clear than the user's vote."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="c:0",
        button_labels=["Yes"],
    )

    async def boom(*a, **kw):
        raise RuntimeError("network blip")
    cb.answer = boom

    await client._on_callback_query(cb)  # must not raise
    assert len(orch.calls) == 1
    assert orch.calls[0]["text"] == "choice: Yes"
    # Button taps are by definition addressed to the bot — bypass require_mention
    assert orch.calls[0]["is_mentioned"] is True


# ---- Batch 11: mention detection ----


@pytest.mark.asyncio
async def test_mention_via_at_username():
    """User typed @bot_username inside the message."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    # "@captain_jack_movie_bot" = 23 chars (1 @ + 22 letters)
    msg = _make_message(
        chat_id=-1001234, user_id=42,
        text="@captain_jack_movie_bot sống chưa?",
        entities=[SimpleNamespace(type="mention", offset=0, length=23, user=None)],
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is True


@pytest.mark.asyncio
async def test_mention_username_case_insensitive():
    """Telegram usernames are case-insensitive — `@CaptainJack` matches
    `captainjack`."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(
        chat_id=-1001234, user_id=42,
        text="@Captain_Jack_Movie_BOT sống chưa?",
        entities=[SimpleNamespace(type="mention", offset=0, length=23, user=None)],
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is True


@pytest.mark.asyncio
async def test_mention_via_text_mention_entity():
    """Telegram apps render private-account mentions as a `text_mention`
    entity (deep-link style) instead of `mention` — the user object is
    embedded in the entity itself."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = ""  # unset is fine for text_mention
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    bot_user = SimpleNamespace(id=8888, is_bot=True, username="captain_jack_movie_bot")
    msg = _make_message(
        chat_id=-1001234, user_id=42, text="hey bot",
        entities=[SimpleNamespace(type="text_mention", offset=4, length=3, user=bot_user)],
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is True


@pytest.mark.asyncio
async def test_mention_via_reply_to_bot():
    """User long-pressed bot's earlier message and replied — implicit
    mention. Pin: the bot's `id` matches the reply_to_message.from_user.id."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    bot_msg_user = SimpleNamespace(id=8888, is_bot=True, username="captain_jack_movie_bot")
    reply_target = SimpleNamespace(from_user=bot_msg_user)
    msg = _make_message(
        chat_id=-1001234, user_id=42, text="cảm ơn",
        reply_to_message=reply_target,
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is True


@pytest.mark.asyncio
async def test_mention_via_reply_to_other_user_does_not_count():
    """Replying to ANOTHER user's message in the same group is NOT a
    mention of the bot."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    other_user = SimpleNamespace(id=99, is_bot=False, username="alice")
    reply_target = SimpleNamespace(from_user=other_user)
    msg = _make_message(
        chat_id=-1001234, user_id=42, text="ok",
        reply_to_message=reply_target,
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is False


@pytest.mark.asyncio
async def test_no_mention_plain_text():
    """No @ entity, no reply, just plain text in a group → not mentioned."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(chat_id=-1001234, user_id=42, text="just chatting in the group")
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is False


@pytest.mark.asyncio
async def test_bot_command_with_at_username_counts_as_mention():
    """Real-world scenario: user types `/status@captain_jack_movie_bot`
    in a group. Telegram turns the WHOLE thing into a single
    `bot_command` entity — there's no separate `mention` entity for the
    `@bot_username` suffix. Our addressed-detection has to peek into
    bot_command entities and look for @bot_username inside.

    Pin the bug-fix: anh hit this when testing /status in Thị Đào's
    require_mention group; the message was rejected because we missed
    this entity type."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(
        chat_id=-1001234, user_id=42,
        text="/status@captain_jack_movie_bot",
        entities=[SimpleNamespace(
            type="bot_command", offset=0, length=30, user=None,
        )],
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is True


@pytest.mark.asyncio
async def test_bot_command_without_at_username_does_not_count():
    """Plain `/status` (no `@bot_username` suffix) is a bot_command but
    NOT an implicit mention of THIS bot — could be a different bot."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(
        chat_id=-1001234, user_id=42,
        text="/status",
        entities=[SimpleNamespace(type="bot_command", offset=0, length=7, user=None)],
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is False


@pytest.mark.asyncio
async def test_bot_command_for_other_bot_does_not_count():
    """`/status@some_other_bot` in a group with multiple bots — we are
    NOT addressed; the other bot is."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(
        chat_id=-1001234, user_id=42,
        text="/status@some_other_bot",
        entities=[SimpleNamespace(type="bot_command", offset=0, length=22, user=None)],
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is False


@pytest.mark.asyncio
async def test_mention_in_caption_entity():
    """Photo with a caption that mentions the bot — caption_entities
    field, not entities."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    msg = _make_message(
        chat_id=-1001234, user_id=42,
        text=None, caption="@captain_jack_movie_bot xem hộ",
        photo=[SimpleNamespace(file_id="img-id")],
        caption_entities=[SimpleNamespace(type="mention", offset=0, length=23, user=None)],
    )
    await client._on_message(msg)
    assert orch.calls[0]["is_mentioned"] is True


# ---- Choice callback edits source message + dispatches ----


@pytest.mark.asyncio
async def test_choice_callback_edits_source_and_removes_keyboard():
    """User taps an inline keyboard button: source message gets edited
    to append `✅ <label>` AND the keyboard is removed (so the user
    can't double-tap). Then the choice is dispatched as inbound."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    client._bot_username = "captain_jack_movie_bot"
    edits: list = []

    async def fake_edit_text(*, chat_id, message_id, text, reply_markup=None):
        edits.append({
            "chat_id": chat_id, "message_id": message_id,
            "text": text, "reply_markup": reply_markup,
        })

    client.edit_text = fake_edit_text  # type: ignore
    orch = _FakeOrchestrator()
    client._orchestrator = orch
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="c:1",
        button_labels=["Yes", "Maybe", "No"],
    )
    cb.message.text = "Pick one:"
    await client._on_callback_query(cb)
    # Edit fired with confirmation footer + keyboard removed
    assert len(edits) == 1
    e = edits[0]
    assert e["text"].startswith("Pick one:")
    assert "✅ Maybe" in e["text"]
    assert e["reply_markup"] is None
    # Dispatch still happened
    assert len(orch.calls) == 1
    assert orch.calls[0]["text"] == "choice: Maybe"


# ---- Show-transcript callback forwards to status indicator ----


@pytest.mark.asyncio
async def test_thinking_callback_calls_status_show_thinking():
    """`t:show` and `t:refresh` are forwarded to the orchestrator's
    StatusIndicator (`_status.show_thinking(chat_id)`); they do NOT
    dispatch as inbound (transcript button is a UI op, not a user reply)."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    orch = _FakeOrchestrator()
    show_calls: list = []

    class _Status:
        async def show_thinking(self, chat_id):
            show_calls.append(chat_id)

    orch._status = _Status()  # type: ignore
    client._orchestrator = orch
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="t:show",
        button_labels=["Show thinking"],
    )
    await client._on_callback_query(cb)
    assert show_calls == [42]
    assert orch.calls == []


@pytest.mark.asyncio
async def test_thinking_refresh_callback_also_forwards():
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    orch = _FakeOrchestrator()
    show_calls: list = []

    class _Status:
        async def show_thinking(self, chat_id):
            show_calls.append(chat_id)

    orch._status = _Status()  # type: ignore
    client._orchestrator = orch
    cb = _make_callback(
        chat_id=42, user_id=7510670911,
        callback_data="t:refresh",
        button_labels=["Refresh thinking"],
    )
    await client._on_callback_query(cb)
    assert show_calls == [42]
    assert orch.calls == []


@pytest.mark.asyncio
async def test_tasklist_callback_calls_status_show_tasklist():
    """`tk:show` and `tk:refresh` are forwarded to the orchestrator's
    StatusIndicator (`_status.show_tasklist(chat_id)`); they do NOT
    dispatch as inbound."""
    client = TelegramClient(name="t", bot_token="x" * 20)
    client._bot_id = 8888
    orch = _FakeOrchestrator()
    show_calls: list = []

    class _Status:
        async def show_tasklist(self, chat_id):
            show_calls.append(chat_id)

    orch._status = _Status()  # type: ignore
    client._orchestrator = orch
    for data in ("tk:show", "tk:refresh"):
        cb = _make_callback(
            chat_id=42, user_id=7510670911,
            callback_data=data,
            button_labels=["Show tasks"],
        )
        await client._on_callback_query(cb)
    assert show_calls == [42, 42]
    assert orch.calls == []
