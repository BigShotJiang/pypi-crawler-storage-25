"""Event sinks (P6 — persistence + observability hooks).

Coverage:

  Happy:
    • AcceptEvent / RejectEvent serialise as expected (shape pin)
    • StdoutSink prints one JSON line per event
    • HttpSink POSTs JSON with bearer auth on emit_accept and emit_reject
    • build_sink dispatches by `kind` field

  Unhappy:
    • HttpSink swallows network errors (caller does NOT see exception)
    • HttpSink swallows non-2xx responses (warn-and-continue)
    • HttpSink swallows timeouts
    • build_sink rejects unknown kinds at startup (fail-loud, not silently)

  Edge:
    • HttpSink rejects empty url/secret at construct time (not first POST)
    • Legacy P1 string spec ("stdout") still resolves
    • EventSink.aclose default no-op doesn't raise
"""

from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch

import aiohttp
import pytest
from aiohttp import web

from waggle.events import (
    AcceptEvent,
    EventSink,
    HttpSink,
    RejectEvent,
    StdoutSink,
    build_sink,
)


def _accept(body: str = "hello") -> AcceptEvent:
    return AcceptEvent(
        source="telegram", chat="42", user="42", username="anh",
        message_id="9", body=body,
        ts=datetime(2026, 4, 30, 12, 0, 0, tzinfo=timezone.utc),
    )


def _reject() -> RejectEvent:
    return RejectEvent(
        reason="not-allowlisted",
        source="telegram", chat="999", user="999",
        text_preview="probe",
        ts=datetime(2026, 4, 30, 12, 0, 0, tzinfo=timezone.utc),
    )


# ---------- Happy: serialisation ----------


def test_accept_event_to_dict_shape():
    e = _accept(body="hi 🐝")
    d = e.to_dict()
    assert d == {
        "type": "accept",
        "source": "telegram",
        "chat": "42",
        "user": "42",
        "username": "anh",
        "message_id": "9",
        "body": "hi 🐝",
        "attachments": [],
        "ts": "2026-04-30T12:00:00Z",
    }


def test_reject_event_to_dict_shape():
    e = _reject()
    d = e.to_dict()
    assert d["type"] == "reject"
    assert d["reason"] == "not-allowlisted"
    assert d["ts"] == "2026-04-30T12:00:00Z"


def test_accept_event_attachments_round_trip():
    """Attachments are stored by reference (file_id, kind, mime). The shape
    is opaque to the sink — the dashboard interprets it. We only pin that
    the tuple round-trips through to_dict."""
    a = AcceptEvent(
        source="telegram", chat="1", user="2", username="x", message_id="3",
        body="see image",
        attachments=(
            {"file_id": "BAADBA...", "kind": "photo", "mime": "image/jpeg"},
        ),
    )
    d = a.to_dict()
    assert d["attachments"] == [
        {"file_id": "BAADBA...", "kind": "photo", "mime": "image/jpeg"}
    ]


# ---------- Happy: StdoutSink ----------


@pytest.mark.asyncio
async def test_stdout_sink_emits_one_json_line_per_event(capsys):
    sink = StdoutSink()
    await sink.emit_accept(_accept())
    await sink.emit_reject(_reject())
    out = capsys.readouterr().out.strip().splitlines()
    assert len(out) == 2
    a = json.loads(out[0])
    r = json.loads(out[1])
    assert a["type"] == "accept"
    assert r["type"] == "reject"


# ---------- Happy: HttpSink ----------


class _CatcherServer:
    """Tiny aiohttp app that records every request body. Used as the
    HttpSink target so we can assert real wire shape without mocking out
    aiohttp internals."""

    def __init__(self, *, status: int = 204):
        self.received: list[dict] = []
        self.headers: list[dict] = []
        self.status = status
        self._runner: web.AppRunner | None = None
        self._site: web.TCPSite | None = None

    async def handler(self, request: web.Request) -> web.Response:
        body = await request.json()
        self.received.append(body)
        self.headers.append(dict(request.headers))
        return web.Response(status=self.status)

    async def start(self) -> str:
        app = web.Application()
        app.router.add_post("/ingest", self.handler)
        self._runner = web.AppRunner(app)
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, "127.0.0.1", 0)
        await self._site.start()
        port = self._site._server.sockets[0].getsockname()[1]
        return f"http://127.0.0.1:{port}/ingest"

    async def stop(self) -> None:
        if self._runner is not None:
            await self._runner.cleanup()


@pytest.mark.asyncio
async def test_http_sink_posts_accept_with_bearer():
    catcher = _CatcherServer(status=204)
    url = await catcher.start()
    try:
        sink = HttpSink(url=url, secret="0123456789abcdef0123456789abcdef")
        await sink.emit_accept(_accept(body="hello via http"))
        await sink.aclose()
        assert len(catcher.received) == 1
        assert catcher.received[0]["type"] == "accept"
        assert catcher.received[0]["body"] == "hello via http"
        # Bearer header pinned
        auth = catcher.headers[0].get("Authorization")
        assert auth == "Bearer 0123456789abcdef0123456789abcdef"
        ct = catcher.headers[0].get("Content-Type")
        assert ct == "application/json"
    finally:
        await catcher.stop()


@pytest.mark.asyncio
async def test_http_sink_posts_reject():
    catcher = _CatcherServer(status=200)
    url = await catcher.start()
    try:
        sink = HttpSink(url=url, secret="0123456789abcdef0123456789abcdef")
        await sink.emit_reject(_reject())
        await sink.aclose()
        assert len(catcher.received) == 1
        assert catcher.received[0]["type"] == "reject"
    finally:
        await catcher.stop()


@pytest.mark.asyncio
async def test_http_sink_burst_100_messages():
    """P6 acceptance: 100 inbound messages produce 100 sink calls — no
    drops, no batching, no de-dup. Pin the contract."""
    catcher = _CatcherServer(status=204)
    url = await catcher.start()
    try:
        sink = HttpSink(url=url, secret="0123456789abcdef0123456789abcdef")
        for i in range(100):
            await sink.emit_accept(_accept(body=f"msg-{i:03d}"))
        await sink.aclose()
        assert len(catcher.received) == 100
        bodies = [r["body"] for r in catcher.received]
        assert bodies == [f"msg-{i:03d}" for i in range(100)]
    finally:
        await catcher.stop()


# ---------- Unhappy: HttpSink fail-soft ----------


@pytest.mark.asyncio
async def test_http_sink_swallows_connection_refused(caplog):
    """Server unreachable → log a warning, never propagate. Spec §1.2 + P6
    risk note: 'External store outage causing back-pressure on the agent.
    Drop with warning, never block.'"""
    # Find a free port and DON'T bind anything to it
    import socket
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    sink = HttpSink(
        url=f"http://127.0.0.1:{port}/dead",
        secret="0123456789abcdef0123456789abcdef",
        timeout_seconds=2.0,
    )
    # Must NOT raise
    await sink.emit_accept(_accept())
    await sink.aclose()
    # Warning was logged
    assert any("HttpSink" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_http_sink_swallows_non_2xx(caplog):
    catcher = _CatcherServer(status=500)
    url = await catcher.start()
    try:
        sink = HttpSink(url=url, secret="0123456789abcdef0123456789abcdef")
        # Must NOT raise
        await sink.emit_accept(_accept())
        await sink.aclose()
        assert any(
            "500" in r.message and "HttpSink" in r.message for r in caplog.records
        )
    finally:
        await catcher.stop()


@pytest.mark.asyncio
async def test_http_sink_swallows_timeout(caplog):
    """Endpoint that hangs forever — sink must time out and continue."""
    started = asyncio.Event()
    release = asyncio.Event()

    async def hang(_request):
        started.set()
        await release.wait()
        return web.Response(status=204)

    app = web.Application()
    app.router.add_post("/slow", hang)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    try:
        sink = HttpSink(
            url=f"http://127.0.0.1:{port}/slow",
            secret="0123456789abcdef0123456789abcdef",
            timeout_seconds=0.3,
        )
        # Run the sink call — must return within ~timeout, not hang forever
        await asyncio.wait_for(sink.emit_accept(_accept()), timeout=2.0)
        await sink.aclose()
        # Release the server so cleanup proceeds
        release.set()
        assert any(
            "timed out" in r.message.lower() or "timeout" in r.message.lower()
            for r in caplog.records
        )
    finally:
        release.set()
        await runner.cleanup()


# ---------- Unhappy: build_sink ----------


def test_build_sink_unknown_kind_raises():
    with pytest.raises(ValueError, match="postgres"):
        build_sink({"kind": "postgres"})


def test_build_sink_unknown_legacy_string_raises():
    with pytest.raises(ValueError, match="snowflake"):
        build_sink("snowflake")


# ---------- Edge ----------


def test_http_sink_requires_url():
    with pytest.raises(ValueError, match="url"):
        HttpSink(url="", secret="0123456789abcdef0123456789abcdef")


def test_http_sink_requires_secret():
    with pytest.raises(ValueError, match="secret"):
        HttpSink(url="http://x/", secret="")


def test_build_sink_legacy_stdout_string():
    sink = build_sink("stdout")
    assert isinstance(sink, StdoutSink)


def test_build_sink_none_defaults_to_stdout():
    """No config at all → StdoutSink. Keeps deployments without a sink
    block working without a config bump."""
    assert isinstance(build_sink(None), StdoutSink)


def test_build_sink_dict_stdout_kind():
    assert isinstance(build_sink({"kind": "stdout"}), StdoutSink)


def test_build_sink_dict_http_kind():
    sink = build_sink({
        "kind": "http",
        "url": "http://obs.example/ingest",
        "secret": "0123456789abcdef0123456789abcdef",
        "timeout_seconds": 7.5,
    })
    assert isinstance(sink, HttpSink)
    assert sink.url == "http://obs.example/ingest"


def test_build_sink_pydantic_model_via_model_dump():
    """Accepts pydantic models via .model_dump() so config can pass the
    parsed sink block straight through."""
    class _Stub:
        def model_dump(self):
            return {"kind": "stdout"}
    assert isinstance(build_sink(_Stub()), StdoutSink)


@pytest.mark.asyncio
async def test_event_sink_aclose_default_no_op():
    """StdoutSink doesn't override aclose — the base default must not
    raise. Pin the duck-type contract."""
    sink = StdoutSink()
    await sink.aclose()  # must not raise
