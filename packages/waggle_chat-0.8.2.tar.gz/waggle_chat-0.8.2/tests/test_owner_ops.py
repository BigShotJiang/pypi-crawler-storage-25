"""Owner-only privileged operations (§1.7) + proactive notifications (§1.8).

The dispatcher is wired into the orchestrator via `maybe_handle_owner` —
when the sender is the configured owner AND the inbound is a known slash
command, the inbound is consumed (returns True) and never reaches claude.

Coverage targets:

  Happy:
    • /status reports liveness + activity
    • /pause flips state, drops subsequent inbound
    • /resume restores normal flow
    • /abort kills+restarts subprocess
    • /restart and /new arm a 5s cancel window
    • Plain text "cancel" within window cancels the pending op
    • /compact pipes a `/compact` user-event to claude

  Unhappy:
    • Non-owner sending /pause: NOT consumed, falls through to access-list
    • Owner sending unknown slash like /explain: falls through to claude
    • COMMANDS shape pin (which commands exist)

  Edge:
    • /status formatting includes turn count + last-inbound preview
    • Cancel window: arming twice without cancelling shows "already pending"
    • Cancel arrives AFTER deadline: ignored (op already fired)
    • notify_owner swallows telegram errors (best-effort)
"""

from __future__ import annotations

import asyncio
import textwrap
from pathlib import Path

import pytest

from waggle.config import load
from waggle.orchestrator import WaggleOrchestrator
from waggle.owner_ops import (
    CANCEL_WINDOW_SECONDS,
    COMMANDS,
    NotifyContext,
    OwnerState,
    PendingDestructive,
    maybe_handle_owner,
    notify_owner,
)


def _write_config(tmp_path: Path) -> Path:
    p = tmp_path / "config.yaml"
    p.write_text(
        textwrap.dedent(
            """
            transports:
              - name: tg
                kind: telegram
                bot_token: "1234567890:secret-token"
            access:
              users: [42, 99]
              groups: {}
            owner:
              user_id: 42
            """
        ).lstrip()
    )
    return p


class _StubTelegram:
    def __init__(self):
        self.replies: list[dict] = []
        self.deletes: list[dict] = []
        self.edits: list[dict] = []
        self._next_id = 1000

    async def reply(self, *, chat_id, text, reply_to=None, format="text",
                    reply_markup=None):
        self._next_id += 1
        mid = str(self._next_id)
        self.replies.append({"chat_id": chat_id, "text": text,
                             "message_id": mid, "reply_markup": reply_markup})
        return mid

    async def edit_text(self, *, chat_id, message_id, text, reply_markup=None):
        self.edits.append({"chat_id": chat_id, "message_id": message_id,
                           "text": text})

    async def edit_reply_markup(self, *, chat_id, message_id, reply_markup=None):
        pass

    async def delete_message(self, *, chat_id, message_id):
        self.deletes.append({"chat_id": chat_id, "message_id": message_id})


class _StubClaude:
    def __init__(self):
        self.started = False
        self.stopped = False
        self.sent: list[str] = []
        self.session_id: str | None = None
        self.continue_session: bool = True

    async def start(self):
        self.started = True

    async def stop(self):
        self.stopped = True

    async def send_user(self, text: str):
        self.sent.append(text)

    async def read_events(self):
        # Default: one minimal result event so /compact drain returns.
        yield "result", {"type": "result", "result": "", "is_error": False}


def _orch(tmp_path: Path) -> WaggleOrchestrator:
    cfg_path = _write_config(tmp_path)
    o = WaggleOrchestrator(load(cfg_path), cfg_path)
    o.claude = _StubClaude()  # type: ignore
    o.telegram = _StubTelegram()  # type: ignore
    return o


# ---------- Happy paths ----------


@pytest.mark.asyncio
async def test_status_reports_running_when_idle(tmp_path):
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/status")
    assert consumed is True
    assert len(o.telegram.replies) == 1
    body = o.telegram.replies[0]["text"]
    assert "🐝 status" in body
    # No traffic yet → 'idle' marker
    assert "idle" in body
    assert "turns processed: 0" in body


@pytest.mark.asyncio
async def test_status_includes_last_inbound_preview(tmp_path):
    o = _orch(tmp_path)
    o.owner_state.last_inbound_ts = 1.0
    o.owner_state.last_inbound_chat = 42
    o.owner_state.last_inbound_preview = "hello world"
    o.owner_state.turn_count = 3
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/status")
    body = o.telegram.replies[0]["text"]
    assert "turns processed: 3" in body
    assert "last inbound" in body
    assert "hello world" in body


@pytest.mark.asyncio
async def test_pause_flips_state_and_drops_subsequent(tmp_path):
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/pause")
    assert consumed is True
    assert o.owner_state.paused is True
    # 2nd /pause is idempotent
    o.telegram.replies.clear()
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/pause")
    assert "Already paused" in o.telegram.replies[0]["text"]


@pytest.mark.asyncio
async def test_resume_restores_state(tmp_path):
    o = _orch(tmp_path)
    o.owner_state.paused = True
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/resume")
    assert consumed is True
    assert o.owner_state.paused is False
    # 2nd /resume is idempotent
    o.telegram.replies.clear()
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/resume")
    assert "Already running" in o.telegram.replies[0]["text"]


@pytest.mark.asyncio
async def test_abort_stops_and_restarts_subprocess(tmp_path):
    o = _orch(tmp_path)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/abort")
    assert o.claude.stopped is True
    assert o.claude.started is True
    assert "Aborted" in o.telegram.replies[0]["text"]


@pytest.mark.asyncio
async def test_restart_arms_cancel_window(tmp_path):
    o = _orch(tmp_path)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/restart")
    pending = o.owner_state.pending_destructive
    assert pending is not None
    assert pending.label == "restart"
    assert 0 < pending.remaining() <= CANCEL_WINDOW_SECONDS
    assert "Restart" in o.telegram.replies[0]["text"]
    assert "cancel" in o.telegram.replies[0]["text"]
    # Don't let the timer actually fire during the test
    pending.task.cancel()


@pytest.mark.asyncio
async def test_new_arms_cancel_window_with_correct_label(tmp_path):
    o = _orch(tmp_path)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/new")
    pending = o.owner_state.pending_destructive
    assert pending is not None
    assert pending.label == "new"
    pending.task.cancel()


@pytest.mark.asyncio
async def test_cancel_aborts_pending_destructive(tmp_path):
    o = _orch(tmp_path)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/restart")
    assert o.owner_state.pending_destructive is not None
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="cancel")
    assert consumed is True
    assert o.owner_state.pending_destructive is None
    assert "Cancelled" in o.telegram.replies[-1]["text"]


@pytest.mark.asyncio
async def test_compact_pipes_to_claude(tmp_path):
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/compact")
    assert consumed is True
    assert o.claude.sent == ["/compact"]
    # /compact uses the same claim/fold/wait machinery as user inbound,
    # so the indicator post (🤔 Thinking…) appears first; the "Sent
    # /compact" confirmation comes after the result event drains.
    assert any("/compact" in r["text"] for r in o.telegram.replies)


@pytest.mark.asyncio
async def test_compact_drains_result_so_next_turn_is_not_desynced(tmp_path):
    """Regression: an earlier version of /compact wrote to claude's stdin
    without consuming the resulting `result` event. The next user turn's
    `read_events()` would then pick up the /compact result and return
    immediately with empty text — silently dropping the user's prompt.

    Pin: after /compact, the stub's pre-loaded events are exhausted, so a
    follow-up turn reads its OWN result event."""
    o = _orch(tmp_path)

    # Replace the stub with one that yields two distinct result events:
    # one for /compact, one for the follow-up turn.
    class _TwoTurnStub:
        def __init__(self):
            self.sent: list[str] = []
            self._queue: list[list[tuple[str, dict]]] = [
                [("result", {"type": "result", "result": "compacted", "is_error": False})],
                [("result", {"type": "result", "result": "second-turn-output", "is_error": False})],
            ]

        async def send_user(self, text):
            self.sent.append(text)

        async def read_events(self):
            if not self._queue:
                return
            for kind, event in self._queue.pop(0):
                yield kind, event

    o.claude = _TwoTurnStub()  # type: ignore
    await o.access.start()
    try:
        await maybe_handle_owner(o, chat_id=42, user_id=42, text="/compact")
        assert o.claude.sent == ["/compact"]
        # Follow-up: a normal inbound. The orchestrator should read THE
        # SECOND result event, not the first (already consumed by /compact).
        await o.submit_inbound(
            chat_id=42, user_id=42, username="x", message_id="9", text="next prompt",
        )
        assert o.claude.sent == ["/compact", "<channel"] \
            or o.claude.sent[1].startswith("<channel"), \
            f"Expected wrapped second turn, got: {o.claude.sent}"
        # Both pushes are full turns from claude's perspective: /compact
        # emits its own result event and the follow-up emits another.
        # The reader processes each result and increments turn_count.
        assert o.owner_state.turn_count == 2
    finally:
        await o.access.stop()


@pytest.mark.asyncio
async def test_compact_folds_concurrent_same_chat_inbound(tmp_path):
    """With mid-turn inject, a concurrent inbound from the SAME chat as
    the running /compact folds into the active turn — both stdin pushes
    happen before the result event arrives. claude (in real life) merges
    them into one inference; the test stub yields a single result.

    Different-chat behavior is checked separately below.
    """
    o = _orch(tmp_path)

    drain_started = asyncio.Event()
    release_drain = asyncio.Event()

    class _SlowStub:
        def __init__(self):
            self.sent: list[str] = []

        async def send_user(self, text):
            self.sent.append(text)

        async def read_events(self):
            drain_started.set()
            await release_drain.wait()
            yield "result", {"type": "result", "result": "", "is_error": False}

    o.claude = _SlowStub()  # type: ignore
    await o.access.start()
    try:
        # Start /compact — it claims the active chat and pushes /compact.
        # The reader blocks in read_events waiting for release_drain.
        compact_task = asyncio.create_task(
            maybe_handle_owner(o, chat_id=42, user_id=42, text="/compact")
        )
        await drain_started.wait()
        # While drain is in flight, send a normal inbound from the SAME
        # chat. With mid-turn inject this folds in immediately.
        async def _try_inbound():
            await o.submit_inbound(
                chat_id=42, user_id=42, username="x",
                message_id="9", text="folded",
            )

        inbound_task = asyncio.create_task(_try_inbound())
        # Give the fold push a chance to land.
        await asyncio.sleep(0.05)
        # Both pushes are present even before the result event arrives —
        # this is the mid-turn inject contract.
        assert len(o.claude.sent) == 2
        assert o.claude.sent[0] == "/compact"
        assert o.claude.sent[1].startswith("<channel")
        # Release the drain so both tasks finish.
        release_drain.set()
        await compact_task
        await inbound_task
    finally:
        await o.access.stop()


@pytest.mark.asyncio
async def test_destructive_restart_actually_fires(tmp_path, monkeypatch):
    o = _orch(tmp_path)
    # Shrink the window so the test doesn't sleep for 5s
    monkeypatch.setattr("waggle.owner_ops.CANCEL_WINDOW_SECONDS", 0.05)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/restart")
    pending = o.owner_state.pending_destructive
    assert pending is not None
    await asyncio.wait_for(pending.task, timeout=1.0)
    assert o.claude.stopped is True
    assert o.claude.started is True
    assert any("restarted" in r["text"].lower() for r in o.telegram.replies)


@pytest.mark.asyncio
async def test_destructive_new_drops_session(tmp_path, monkeypatch):
    o = _orch(tmp_path)
    monkeypatch.setattr("waggle.owner_ops.CANCEL_WINDOW_SECONDS", 0.05)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/new")
    pending = o.owner_state.pending_destructive
    assert pending is not None
    await asyncio.wait_for(pending.task, timeout=1.0)
    assert o.claude.continue_session is False
    assert isinstance(o.claude.session_id, str) and len(o.claude.session_id) > 0
    assert any("new session" in r["text"].lower() for r in o.telegram.replies)


# ---------- Unhappy paths ----------


@pytest.mark.asyncio
async def test_non_owner_slash_falls_through(tmp_path):
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=99, user_id=99, text="/pause")
    assert consumed is False
    assert o.owner_state.paused is False
    # No reply was sent (non-owner gets normal handling, not owner-ops feedback)
    assert o.telegram.replies == []


@pytest.mark.asyncio
async def test_owner_ops_in_group_falls_through(tmp_path):
    """Owner sending /pause in a group does NOT trigger owner ops —
    state leaks (turn count, last-inbound preview) shouldn't reach
    other group members. Owner ops are a DM-only operator surface."""
    o = _orch(tmp_path)
    # chat_id < 0 == group/supergroup
    consumed = await maybe_handle_owner(o, chat_id=-1001234, user_id=42, text="/pause")
    assert consumed is False
    assert o.owner_state.paused is False
    assert o.telegram.replies == []


@pytest.mark.asyncio
async def test_owner_ops_at_bot_in_group_also_falls_through(tmp_path):
    """`/pause@bot_username` in a group: same rule, owner ops do not
    fire. Otherwise a malicious group member could observe operator
    feedback."""
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(
        o, chat_id=-1001234, user_id=42,
        text="/pause@waggle_dev_bot",
    )
    assert consumed is False
    assert o.owner_state.paused is False


@pytest.mark.asyncio
async def test_unknown_slash_falls_through(tmp_path):
    """Owner sending /explain (or any unknown command) is NOT consumed —
    let claude decide what to do with it."""
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/explain foo")
    assert consumed is False
    assert o.telegram.replies == []


@pytest.mark.asyncio
async def test_plain_text_owner_falls_through(tmp_path):
    """Non-slash plain text from owner reaches claude (no destructive
    pending, so 'cancel' check returns False too)."""
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="hello")
    assert consumed is False
    assert o.telegram.replies == []


@pytest.mark.asyncio
async def test_arm_destructive_twice_warns(tmp_path):
    o = _orch(tmp_path)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/restart")
    o.telegram.replies.clear()
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/restart")
    assert "already pending" in o.telegram.replies[0]["text"]
    o.owner_state.pending_destructive.task.cancel()


@pytest.mark.asyncio
async def test_compact_no_agent_attached(tmp_path):
    o = _orch(tmp_path)
    o.claude = None  # type: ignore
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/compact")
    assert consumed is True
    assert "No agent attached" in o.telegram.replies[0]["text"]


@pytest.mark.asyncio
async def test_handler_crash_returns_consumed_and_warns(tmp_path):
    """A bug inside a handler should NOT cause the inbound to fall through
    to claude (would double-process). Returns True (consumed) + warns owner."""
    o = _orch(tmp_path)

    async def boom(*args, **kwargs):
        raise RuntimeError("forced")

    # Patch one of the handlers to crash
    from waggle import owner_ops
    orig = owner_ops.COMMANDS["/status"]
    owner_ops.COMMANDS["/status"] = boom
    try:
        consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/status")
        assert consumed is True
        # Crash-warning reply
        assert any("crashed" in r["text"] for r in o.telegram.replies)
    finally:
        owner_ops.COMMANDS["/status"] = orig


# ---------- Edge cases ----------


def test_commands_dict_shape_pin():
    """Pin the exact set of supported commands so a typo doesn't silently
    add or rename a command without a test update."""
    assert set(COMMANDS.keys()) == {
        "/status", "/pause", "/resume",
        "/abort", "/restart", "/new", "/compact",
    }


@pytest.mark.asyncio
async def test_slash_is_case_insensitive(tmp_path):
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="/STATUS")
    assert consumed is True


@pytest.mark.asyncio
async def test_cancel_with_no_pending_falls_through(tmp_path):
    """Plain 'cancel' text without a pending destructive op is NOT
    consumed — let claude treat it as a normal message."""
    o = _orch(tmp_path)
    consumed = await maybe_handle_owner(o, chat_id=42, user_id=42, text="cancel")
    assert consumed is False


@pytest.mark.asyncio
async def test_status_shows_pending_destructive(tmp_path):
    o = _orch(tmp_path)
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/restart")
    o.telegram.replies.clear()
    await maybe_handle_owner(o, chat_id=42, user_id=42, text="/status")
    body = o.telegram.replies[0]["text"]
    assert "restart pending" in body
    o.owner_state.pending_destructive.task.cancel()


# ---------- §1.8 notify_owner ----------


class _BadTelegram:
    async def reply(self, *, chat_id, text, reply_to=None, format="text"):
        raise RuntimeError("network down")


@pytest.mark.asyncio
async def test_notify_owner_swallows_errors():
    """Best-effort: a failed notification must NOT blow up the orchestrator."""
    ctx = NotifyContext(telegram=_BadTelegram(), owner_chat=42)
    # Should not raise
    await notify_owner(ctx, "test", why="x", todo="y")


@pytest.mark.asyncio
async def test_notify_owner_formats_all_fields():
    tg = _StubTelegram()
    ctx = NotifyContext(telegram=tg, owner_chat=42)
    await notify_owner(ctx, "agent restarted", why="rc=1", todo="re-send last")
    text = tg.replies[0]["text"]
    assert "🔔 agent restarted" in text
    assert "why: rc=1" in text
    assert "what to do: re-send last" in text


@pytest.mark.asyncio
async def test_notify_owner_minimal():
    tg = _StubTelegram()
    ctx = NotifyContext(telegram=tg, owner_chat=42)
    await notify_owner(ctx, "just the headline")
    text = tg.replies[0]["text"]
    assert "🔔 just the headline" in text
    assert "why" not in text
    assert "what to do" not in text


# ---------- Owner-ops gate ordering inside submit_inbound ----------


@pytest.mark.asyncio
async def test_submit_inbound_owner_gate_runs_before_access(tmp_path):
    """Owner /status must be consumed even though access-list also allows
    user 42 — the gate must run FIRST so the inbound never reaches claude."""
    o = _orch(tmp_path)
    await o.access.start()
    try:
        await o.submit_inbound(
            chat_id=42, user_id=42, username="x",
            message_id="1", text="/status",
        )
        # No claude.send_user — owner-op consumed
        assert o.claude.sent == []
        # Status reply was sent
        assert any("🐝 status" in r["text"] for r in o.telegram.replies)
    finally:
        await o.access.stop()


@pytest.mark.asyncio
async def test_submit_inbound_paused_drops_silently(tmp_path):
    o = _orch(tmp_path)
    o.owner_state.paused = True
    await o.access.start()
    try:
        await o.submit_inbound(
            chat_id=42, user_id=99, username="x",
            message_id="1", text="hello",
        )
        # No claude turn
        assert o.claude.sent == []
        # No reply (silent drop)
        assert o.telegram.replies == []
    finally:
        await o.access.stop()


@pytest.mark.asyncio
async def test_submit_inbound_tracks_last_activity(tmp_path):
    """Every accepted inbound updates last_inbound_* state for /status."""
    o = _orch(tmp_path)

    # Patch claude with a stream-capable stub so submit_inbound can run
    class _Stream:
        async def send_user(self, _): pass
        async def read_events(self):
            yield "result", {"type": "result", "result": "ok", "is_error": False}

    o.claude = _Stream()  # type: ignore
    await o.access.start()
    try:
        await o.submit_inbound(
            chat_id=42, user_id=42, username="x",
            message_id="1", text="track me",
        )
        assert o.owner_state.last_inbound_chat == 42
        assert "track me" in o.owner_state.last_inbound_preview
        assert o.owner_state.last_inbound_ts > 0
        assert o.owner_state.turn_count == 1
    finally:
        await o.access.stop()
