# waggle — K8s deploy

This directory holds the manifests for the dev pod that runs in the Tiny Hive cluster (`geisha-house` namespace, single-node K3s on `centaur`). The intent: one isolated pod per bot identity, mirroring the layout of every other bot in the namespace, so credentials, telemetry and lifecycle stay consistent across the fleet.

## What ships

`waggle-dev.yaml` — ConfigMap + PVC + StatefulSet for the dev pod.

The pod has three containers:

- **`creds-sync-init`** (init) — pulls the latest credentials from the geisha-house Redis once, exits. Blocks the main container from starting with stale tokens.
- **`waggle`** (main) — `waggle:0.1.0`, runs `python -m waggle.cli -c /etc/waggle/config.yaml`. Reads its config from the ConfigMap, the bot token from the secret described below.
- **`creds-sync`** (sidecar) — keeps `~/.claude/.credentials.json` in sync with the geisha-house Redis broadcast channel after refresh.

The `waggle` container does NOT load the Anthropic-bundled telegram MCP plugin — its config passes `--strict-mcp-config` plus an empty `mcpServers` JSON to the `claude` subprocess, so claude treats the runtime as having zero MCP servers. waggle handles Telegram natively.

## One-time setup

```bash
# 1. Bot token — created via @BotFather; do NOT commit.
kubectl -n geisha-house create secret generic waggle-dev-tg-token \
    --from-literal=bot_token="$WAGGLE_TG_DEV_BOT_TOKEN"

# 2. Build + import the image into the local containerd
sudo docker build -t waggle:0.1.0 .
sudo docker save waggle:0.1.0 | sudo k3s ctr images import -

# 3. Apply manifests
kubectl apply -f deploy/k8s/waggle-dev.yaml
```

Verify:

```bash
kubectl -n geisha-house get pod waggle-dev-0
kubectl -n geisha-house logs waggle-dev-0 -c waggle --tail=10
```

You should see:

```
INFO waggle.transports.telegram: telegram[tg-dev] connected as @waggle_dev_<NNN>_bot ...
INFO aiogram.dispatcher: Start polling
```

## Update flow (build → test → fix → redeploy)

```bash
# Build a new image tag
sudo docker build -t waggle:0.1.1 .
sudo docker save waggle:0.1.1 | sudo k3s ctr images import -

# Bump the image in the StatefulSet
kubectl -n geisha-house set image statefulset/waggle-dev waggle=waggle:0.1.1

# (or edit waggle-dev.yaml and re-apply)
```

The StatefulSet rolls a new pod automatically. The `creds-sync-init` container blocks the new main container from starting until it has fresh credentials in place, so cut-overs are clean even if the rolled pod runs on a different node.

## Allow-list edits

The `users` list lives in the ConfigMap and reloads in-process via mtime polling — but a ConfigMap edit only updates the file in the pod after a kubelet refresh (~60 s default). For an instant change, edit the YAML, re-apply, and `kubectl rollout restart statefulset/waggle-dev`.

## Tearing down

```bash
kubectl -n geisha-house delete -f deploy/k8s/waggle-dev.yaml
kubectl -n geisha-house delete secret waggle-dev-tg-token
```

The PVC is retained by default (its `storageClassName: local-path` provisioner uses `Retain` policy in this cluster) — delete it explicitly if you want a fresh data dir on next deploy.
