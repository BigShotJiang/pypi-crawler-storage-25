"""Channel-tag wire format v1.

Every inbound message handed to the agent is wrapped in a `<channel …>` tag so
the agent can tell where it came from without the runtime needing a special
prompt-construction protocol per platform.

Format (v1, frozen):

    <channel source="telegram" chat="-1001234" user="908624017" ts="2026-04-29T10:00:00Z">
    body
    </channel>

Attributes are escaped with the standard XML attribute rules (we limit
ourselves to the four chars XML cares about). The body is wrapped verbatim;
agent prompts that contain the literal string `</channel>` are an attack
surface — callers must reject those upstream, not us.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone


_ATTR_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
}


def _escape_attr(value: str) -> str:
    out = []
    for c in value:
        out.append(_ATTR_ESCAPES.get(c, c))
    return "".join(out)


@dataclass(frozen=True, slots=True)
class ChannelTag:
    """Identifies the platform-side origin of one inbound message."""

    source: str  # "telegram", "matrix", "external", …
    chat: str  # platform-native chat id (string for safety even when numeric)
    user: str  # platform-native sender id; "" for synthetic / external sources
    ts: datetime

    @staticmethod
    def now(source: str, chat: str | int, user: str | int) -> "ChannelTag":
        return ChannelTag(
            source=source,
            chat=str(chat),
            user=str(user),
            ts=datetime.now(timezone.utc),
        )

    @staticmethod
    def at(source: str, chat: str | int, user: str | int,
           ts: datetime) -> "ChannelTag":
        """Build a tag with an explicit timestamp — use this when the
        source provides one (e.g. Telegram's `message.date`) so the
        channel-tag carries when the user actually sent the message,
        not when waggle received it."""
        return ChannelTag(
            source=source,
            chat=str(chat),
            user=str(user),
            ts=ts.astimezone(timezone.utc) if ts.tzinfo else ts.replace(tzinfo=timezone.utc),
        )

    def render(self, body: str) -> str:
        """Render the full `<channel …>body</channel>` block."""
        ts_iso = self.ts.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        opening = (
            f'<channel source="{_escape_attr(self.source)}" '
            f'chat="{_escape_attr(self.chat)}" '
            f'user="{_escape_attr(self.user)}" '
            f'ts="{ts_iso}">'
        )
        return f"{opening}\n{body}\n</channel>"


# Parser — used only by tests today. Production agents speak text; this lets
# unit tests verify round-trip without exposing internal struct.
_TAG_RE = re.compile(
    r'^<channel\s+source="(?P<source>[^"]*)"\s+chat="(?P<chat>[^"]*)"\s+'
    r'user="(?P<user>[^"]*)"\s+ts="(?P<ts>[^"]*)">\n(?P<body>.*)\n</channel>$',
    re.DOTALL,
)


def parse(rendered: str) -> tuple[ChannelTag, str]:
    m = _TAG_RE.match(rendered)
    if not m:
        raise ValueError("not a channel-tag v1 block")
    ts = datetime.strptime(m.group("ts"), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    tag = ChannelTag(
        source=m.group("source"),
        chat=m.group("chat"),
        user=m.group("user"),
        ts=ts,
    )
    return tag, m.group("body")
