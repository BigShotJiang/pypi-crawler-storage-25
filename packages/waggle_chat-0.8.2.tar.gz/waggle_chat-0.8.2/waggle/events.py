"""Outbound event sinks (P1 → P6).

Two event types flow through the sink interface:

  • `AcceptEvent` — every accepted inbound message (full body + metadata +
    attachments-by-reference). One sink call per accepted user turn.
  • `RejectEvent` — every dropped inbound (allow-list miss, bad transport).

Sinks are the **adapter boundary** between waggle and whichever external
observability/storage system the deployment chose. The orchestrator only
talks to the abstract `EventSink`; concrete adapters (`StdoutSink`,
`HttpSink`, future Postgres/S3) plug in via `build_sink(config)`.

Failure model: external storage going down MUST NOT propagate to the
runtime. Every sink swallows its own errors at WARNING level. The agent
keeps replying; the dashboard just loses a row. This is an explicit
acceptance clause of P6.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal

import aiohttp

log = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RejectEvent:
    reason: Literal[
        "not-allowlisted", "group-not-allowlisted", "owner-only",
        "rate-limited-chat", "rate-limited-user",
        "command-in-group",
    ]
    source: str
    chat: str
    user: str
    text_preview: str  # first ~80 chars; never the whole body
    ts: datetime

    def to_dict(self) -> dict:
        return {
            "type": "reject",
            "reason": self.reason,
            "source": self.source,
            "chat": self.chat,
            "user": self.user,
            "text_preview": self.text_preview,
            "ts": _iso(self.ts),
        }


@dataclass(frozen=True, slots=True)
class AcceptEvent:
    """An accepted inbound message — body in full, plus attachments by
    reference (transport-native ids; the actual bytes never touch waggle's
    persistence layer). The dashboard is expected to fetch attachments
    on-demand using the source-specific id."""

    source: str           # "telegram" | "matrix" | …
    chat: str
    user: str
    username: str
    message_id: str
    body: str             # full text (no truncation — spec §1.2 "in full")
    attachments: tuple[dict, ...] = field(default_factory=tuple)
    ts: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict:
        return {
            "type": "accept",
            "source": self.source,
            "chat": self.chat,
            "user": self.user,
            "username": self.username,
            "message_id": self.message_id,
            "body": self.body,
            "attachments": list(self.attachments),
            "ts": _iso(self.ts),
        }


def _iso(ts: datetime) -> str:
    return ts.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class EventSink(ABC):
    @abstractmethod
    async def emit_accept(self, event: AcceptEvent) -> None: ...

    @abstractmethod
    async def emit_reject(self, event: RejectEvent) -> None: ...

    async def aclose(self) -> None:
        """Optional: free transport-level resources (HTTP session). Default
        no-op so existing sinks don't have to override."""
        return None


class StdoutSink(EventSink):
    """Pretty-print one JSON event per line. Useful for local dev and the
    default-deny config when no external store is configured.

    Note: writes to stdout, NOT local disk — `kubectl logs` is the operator's
    observability surface in production. Spec §1.2 forbids local-disk writes;
    stdout is not a local-disk write."""

    async def emit_accept(self, event: AcceptEvent) -> None:
        self._print(event.to_dict())

    async def emit_reject(self, event: RejectEvent) -> None:
        self._print(event.to_dict())

    @staticmethod
    def _print(payload: dict) -> None:
        print(json.dumps(payload, ensure_ascii=False), file=sys.stdout, flush=True)


class HttpSink(EventSink):
    """POST each event as JSON to a configured ingest endpoint. Bearer-
    authenticated. Best-effort: every error is logged at WARNING and
    swallowed — the agent must never block on observability.

    The endpoint receives the same shape `to_dict()` returns; `type` field
    distinguishes accept vs reject. Idempotency is the receiver's problem
    (waggle has no retry-with-id semantics today)."""

    def __init__(
        self,
        *,
        url: str,
        secret: str,
        timeout_seconds: float = 5.0,
    ):
        if not url:
            raise ValueError("HttpSink: url is required")
        if not secret:
            raise ValueError("HttpSink: secret is required")
        self.url = url
        self._headers = {
            "Authorization": f"Bearer {secret}",
            "Content-Type": "application/json",
        }
        self._timeout = aiohttp.ClientTimeout(total=timeout_seconds)
        self._session: aiohttp.ClientSession | None = None

    def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=self._timeout)
        return self._session

    async def emit_accept(self, event: AcceptEvent) -> None:
        await self._post(event.to_dict())

    async def emit_reject(self, event: RejectEvent) -> None:
        await self._post(event.to_dict())

    async def _post(self, payload: dict) -> None:
        try:
            session = self._ensure_session()
            async with session.post(
                self.url, json=payload, headers=self._headers,
            ) as resp:
                if resp.status >= 400:
                    body = await resp.text()
                    log.warning(
                        "HttpSink: %s returned %d: %s",
                        self.url, resp.status, body[:200],
                    )
        except asyncio.TimeoutError:
            log.warning("HttpSink: %s timed out (>%.1fs)",
                        self.url, self._timeout.total)
        except aiohttp.ClientError as e:
            log.warning("HttpSink: %s client error: %r", self.url, e)
        except Exception as e:  # last-resort guard: never propagate
            log.warning("HttpSink: %s unexpected error: %r", self.url, e)

    async def aclose(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
            self._session = None


def build_sink(spec: object) -> EventSink:
    """Build a sink from config. Accepts either a legacy string (`"stdout"`,
    P1-era) OR a dict-like config (`{"kind": "http", "url": …, "secret": …}`).

    Unknown kinds raise `ValueError`. Empty-string / None falls back to
    `StdoutSink` so the legacy default keeps working without a config bump.
    """
    # Legacy string form (P1 — `events.reject_sink: stdout`)
    if spec is None or isinstance(spec, str):
        kind = (spec or "stdout").strip()
        if kind == "stdout":
            return StdoutSink()
        raise ValueError(f"unsupported event sink: {kind!r}")
    # Structured form (P6+)
    if hasattr(spec, "model_dump"):  # pydantic model
        spec = spec.model_dump()
    if not isinstance(spec, dict):
        raise ValueError(f"unsupported sink spec type: {type(spec).__name__}")
    kind = (spec.get("kind") or "stdout").strip()
    if kind == "stdout":
        return StdoutSink()
    if kind == "http":
        return HttpSink(
            url=spec.get("url") or "",
            secret=spec.get("secret") or "",
            timeout_seconds=float(spec.get("timeout_seconds") or 5.0),
        )
    raise ValueError(f"unsupported event sink kind: {kind!r}")
