"""`python -m waggle.cli -c config.yaml` — runs the v0.3 stream-json orchestrator."""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import sys
from pathlib import Path

from .clients.telegram import TelegramClient
from .config import load as load_config
from .orchestrator import WaggleOrchestrator


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="waggle")
    p.add_argument(
        "-c", "--config",
        type=Path,
        default=Path(os.environ.get("WAGGLE_CONFIG", "config.yaml")),
    )
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args(argv)


def _install_logging(verbose: bool) -> None:
    # When WAGGLE_LOG_FILE is set, write ONLY to the file. The CLI then spawns
    # `tail -F` on that file targeting stderr, which produces a single
    # consolidated stream covering both orchestrator and tools_server (the
    # grandchild process whose stderr claude swallows). Without WAGGLE_LOG_FILE,
    # fall back to plain stderr logging — useful for unit tests / local dev.
    log_file = os.environ.get("WAGGLE_LOG_FILE")
    if log_file:
        handlers: list[logging.Handler] = [logging.FileHandler(log_file)]
    else:
        handlers = [logging.StreamHandler(sys.stderr)]
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        handlers=handlers,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        force=True,
    )


async def _amain(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    orch = WaggleOrchestrator(cfg, args.config)
    orch.telegram = TelegramClient.from_config(cfg.transports[0].model_dump())

    # Stream the consolidated log file to stderr so `kubectl logs` shows
    # both orchestrator and tools_server activity in one place. tools_server
    # is a grandchild process (claude → tools_server) — its stderr would
    # otherwise be swallowed by claude's MCP-server-stderr capture.
    log_path = os.environ.get("WAGGLE_LOG_FILE")
    tail_proc = None
    if log_path:
        # Touch the file so tail -F has something to follow before any
        # writer opens it.
        Path(log_path).touch(exist_ok=True)
        tail_proc = await asyncio.create_subprocess_exec(
            "tail", "-Fn0", log_path,
            stdout=sys.stderr.fileno(),
            stderr=asyncio.subprocess.DEVNULL,
        )

    stop = asyncio.Event()

    def _sig(*_: object) -> None:
        stop.set()

    loop = asyncio.get_running_loop()
    for s in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(s, _sig)
        except NotImplementedError:
            pass

    run_task = asyncio.create_task(orch.run(), name="orchestrator")
    stop_task = asyncio.create_task(stop.wait(), name="signal-wait")
    done, _ = await asyncio.wait(
        {run_task, stop_task},
        return_when=asyncio.FIRST_COMPLETED,
    )
    if stop_task in done and not run_task.done():
        run_task.cancel()
        try:
            await run_task
        except (asyncio.CancelledError, Exception):
            pass
    if run_task in done:
        try:
            run_task.result()
        except Exception as e:
            logging.error("orchestrator crashed: %r", e)
            return 1
    if tail_proc is not None:
        tail_proc.terminate()
        try:
            await asyncio.wait_for(tail_proc.wait(), timeout=2)
        except asyncio.TimeoutError:
            tail_proc.kill()
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    _install_logging(args.verbose)
    return asyncio.run(_amain(args))


if __name__ == "__main__":
    sys.exit(main())
