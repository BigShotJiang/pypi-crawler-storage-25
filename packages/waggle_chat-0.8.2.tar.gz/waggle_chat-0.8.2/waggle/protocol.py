"""Lightweight typed structures shared by the MCP server and platform clients.

The Phase 1 BotProtocol abstract base + Handler are gone — the MCP-server
architecture has only one transport per platform at a time, owned by the
server, so a polymorphic adapter interface adds bureaucracy without value.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .channel_tag import ChannelTag


@dataclass(frozen=True, slots=True)
class Attachment:
    kind: str  # "image" | "audio" | "document" | "video" | …
    file_id: str  # platform-native handle for the bytes
    file_name: str | None = None
    mime: str | None = None
    size: int | None = None


@dataclass(frozen=True, slots=True)
class InboundMessage:
    """Normalised inbound — built by the platform client before pushing into
    the MCP notification queue. Claude never sees this struct directly; it
    receives the rendered notification (content + meta dict)."""

    tag: ChannelTag
    text: str
    message_id: str
    attachments: tuple[Attachment, ...] = ()
    raw: dict[str, Any] = field(default_factory=dict)
