"""Single-source config loader (YAML + env override).

Uses `env:VAR_NAME` markers in string fields to pull values from environment
at load time. Anything not marked is treated as literal.

Pydantic v2 validates the resulting dict — missing required fields fail loudly
(see acceptance criteria for P0).
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Annotated, Any, Literal

import yaml
from pydantic import BaseModel, Field, ValidationError, model_validator


_ENV_REF = re.compile(r"^env:([A-Z_][A-Z0-9_]*)$")


def _resolve_env_refs(value: Any) -> Any:
    if isinstance(value, str):
        m = _ENV_REF.match(value)
        if m:
            return os.environ.get(m.group(1), "")
        return value
    if isinstance(value, dict):
        return {k: _resolve_env_refs(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_env_refs(v) for v in value]
    return value


class TelegramTransport(BaseModel):
    name: str
    kind: Literal["telegram"]
    bot_token: Annotated[str, Field(min_length=10)]
    mode: Literal["poll", "webhook"] = "poll"
    drop_pending_updates: bool = True
    # Where to save inbound photo / document downloads. Defaults to
    # ${TMPDIR}/waggle-attachments if omitted.
    attachments_dir: str | None = None


# Discriminated union when more transports are added (Matrix, Discord, …).
TransportConfig = TelegramTransport


class AccessGroup(BaseModel):
    users: list[int] = Field(default_factory=list)
    # If true, the bot only accepts messages that @-mention it or reply
    # to a prior bot message. Useful for noisy groups where the bot
    # should stay silent unless explicitly addressed.
    require_mention: bool = False


class RateLimit(BaseModel):
    """P8 rate-limit budgets. Both dimensions independent; either can be
    `0` to disable. Sliding window over `window_seconds`."""

    chat_per_minute: int = Field(default=0, ge=0)
    user_per_minute: int = Field(default=0, ge=0)
    window_seconds: float = Field(default=60.0, gt=0.0)


class Access(BaseModel):
    users: list[int] = Field(default_factory=list)
    groups: dict[int, AccessGroup] = Field(default_factory=dict)
    rate_limit: RateLimit = Field(default_factory=RateLimit)


class Owner(BaseModel):
    user_id: int


class Agent(BaseModel):
    """Per-bot policy that affects how waggle drives claude.

    `permission_mode`:
      • `bypass` (default) — pass --dangerously-skip-permissions to claude;
        no Telegram prompts. Use when the container boundary is the trust
        line.
      • `claude_files` — pass --permission-prompt-tool; the tool auto-allows
        every tool call EXCEPT Edit/Write/MultiEdit/NotebookEdit on a path
        containing `claude` (case-insensitive). Owner gets a Telegram prompt
        for those edits.
      • `strict` — same plumbing as `claude_files` but the tool asks for
        every tool_use. Slow; for admin bots.
    """

    permission_mode: Literal["bypass", "claude_files", "strict"] = "bypass"


class EventSinkConfig(BaseModel):
    """Structured sink config (P6). `kind` selects the adapter; the rest are
    adapter-specific fields. Unknown kinds fail at `build_sink` time so a
    typo surfaces during deploy, not silently in a swallowed warning."""

    kind: Literal["stdout", "http"] = "stdout"
    url: str = ""
    secret: str = ""
    timeout_seconds: float = 5.0


class Events(BaseModel):
    """Where waggle pushes accept + reject events.

    Two forms supported:

      • `reject_sink: stdout` (P1 legacy — kept for back-compat). When this
        is the only field set, both accept and reject go to stdout.
      • `sink: {kind: http, url: …, secret: env:…, timeout_seconds: 5.0}`
        (P6+). Preferred for production.

    If both are provided, the structured `sink` wins.
    """

    reject_sink: str = "stdout"
    sink: EventSinkConfig | None = None

    @model_validator(mode="after")
    def _http_sink_requires_url_and_secret(self) -> "Events":
        if self.sink is not None and self.sink.kind == "http":
            if not self.sink.url:
                raise ValueError("events.sink.kind=http requires events.sink.url")
            if not self.sink.secret or len(self.sink.secret) < 16:
                raise ValueError(
                    "events.sink.kind=http requires events.sink.secret of at least 16 chars"
                )
        return self


class Inject(BaseModel):
    """External-trigger HTTP endpoint (§1.4 / Phase 3).

    Disabled by default. When enabled, exposes POST /inject on `bind`. Every
    request must carry `Authorization: Bearer <shared_secret>` — without it
    the request is dropped at 401 and never reaches the agent.
    """

    enabled: bool = False
    bind: str = "0.0.0.0:8080"
    # `env:VAR` ref for the shared bearer token. Required when enabled.
    shared_secret: str = ""
    # Fallback chat_id when the request omits it. Required when enabled.
    default_chat_id: int | None = None


class Config(BaseModel):
    """Top-level config for the waggle MCP server.

    Note: there is no `agent` block — in the MCP architecture, the agent
    (claude-code) runs in its own process and loads waggle as a tool layer.
    The agent's own config (model, system prompt, etc.) belongs to claude-code,
    not to waggle.
    """

    transports: list[TransportConfig]
    access: Access
    owner: Owner
    agent: Agent = Field(default_factory=Agent)
    events: Events = Field(default_factory=Events)
    inject: Inject = Field(default_factory=Inject)

    @model_validator(mode="after")
    def _at_least_one_transport(self) -> "Config":
        if not self.transports:
            raise ValueError("at least one transport must be configured")
        return self

    @model_validator(mode="after")
    def _inject_requires_secret_and_default_chat(self) -> "Config":
        if self.inject.enabled:
            if not self.inject.shared_secret or len(self.inject.shared_secret) < 16:
                raise ValueError(
                    "inject.enabled requires inject.shared_secret of at least 16 chars"
                )
            if self.inject.default_chat_id is None:
                raise ValueError(
                    "inject.enabled requires inject.default_chat_id (fallback target)"
                )
        return self

    @model_validator(mode="after")
    def _owner_matches_allowlist(self) -> "Config":
        if self.owner.user_id not in self.access.users:
            raise ValueError(
                "owner.user_id must be present in access.users so the owner "
                "can actually message the bot"
            )
        return self


def load(path: str | Path) -> Config:
    """Load and validate config from `path`. Raises `ValidationError` on
    invalid input — caller should let it propagate so deployment fails loudly.
    """
    p = Path(path)
    with open(p, "rt") as f:
        raw = yaml.safe_load(f) or {}
    resolved = _resolve_env_refs(raw)
    return Config.model_validate(resolved)


__all__ = ["Config", "load", "ValidationError"]
