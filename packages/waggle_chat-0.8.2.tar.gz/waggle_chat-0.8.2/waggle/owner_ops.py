"""Owner-only privileged operations (§1.7) and proactive notifications (§1.8).

Owner is identified by `config.owner.user_id`. Every command in `OWNER_COMMANDS`
runs ONLY for that user; any other sender's `/foo` reaches claude as a normal
prompt (the model can decide what to do with it).

Commands:

  • /status   — agent liveness + last-activity summary
  • /pause    — stop dispatching new inbound to claude (queue is dropped)
  • /resume   — resume dispatch
  • /restart  — restart the claude subprocess (5s cancel window)
  • /new      — drop context and start a fresh claude session (5s cancel)
  • /abort    — cancel the in-flight turn (no cancel window)
  • /compact  — trigger claude's conversation-compact slash command

External triggers (P3 /inject) MUST NOT reach this dispatcher — that's
already the case because `submit_external` doesn't pass through the
slash-command parser. The endpoint's bearer check is the access gate
for inject; owner ops live on a different code path.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Awaitable, Callable

if TYPE_CHECKING:
    from .orchestrator import WaggleOrchestrator

log = logging.getLogger(__name__)


CANCEL_WINDOW_SECONDS = 5.0


@dataclass
class OwnerState:
    """Mutable state the orchestrator threads through the owner-ops dispatcher."""

    paused: bool = False
    last_inbound_ts: float = 0.0
    last_inbound_chat: int | None = None
    last_inbound_preview: str = ""
    turn_count: int = 0
    # Currently-running destructive op task, if any. Owner can `cancel` it
    # within CANCEL_WINDOW_SECONDS by sending the literal text "cancel".
    pending_destructive: "PendingDestructive | None" = None


@dataclass
class PendingDestructive:
    label: str  # "restart" | "new"
    deadline: float
    task: asyncio.Task

    def remaining(self) -> float:
        return max(0.0, self.deadline - time.time())


# A handler returns `True` if it consumed the inbound (so the orchestrator
# does NOT forward to claude). `False` means it ignored the inbound and the
# orchestrator should continue normally.
Handler = Callable[["WaggleOrchestrator", int, str], Awaitable[bool]]


def _is_owner(orch: "WaggleOrchestrator", user_id: int) -> bool:
    return user_id == orch.config.owner.user_id


def _slash_command(text: str) -> tuple[str, str] | None:
    """Split a leading-slash command into (cmd, remainder). `None` means
    not a command. Trims to lower-case so /STATUS works the same as /status."""
    if not text or not text.startswith("/"):
        return None
    head, _, rest = text.partition(" ")
    return head.lower(), rest.strip()


# ---------- Handlers ----------


async def _cmd_status(orch, chat_id, _arg) -> bool:
    s = orch.owner_state
    activity = "paused" if s.paused else "running"
    if s.pending_destructive is not None:
        activity = f"{s.pending_destructive.label} pending ({s.pending_destructive.remaining():.0f}s)"
    elif s.last_inbound_ts == 0:
        activity = "idle (no traffic yet)"
    parts = [
        f"🐝 status: {activity}",
        f"turns processed: {s.turn_count}",
    ]
    if s.last_inbound_ts:
        ago = int(time.time() - s.last_inbound_ts)
        parts.append(f"last inbound: {ago}s ago in chat {s.last_inbound_chat}")
        if s.last_inbound_preview:
            parts.append(f"  → {s.last_inbound_preview}")
    await orch.telegram.reply(chat_id=str(chat_id), text="\n".join(parts))
    return True


async def _cmd_pause(orch, chat_id, _arg) -> bool:
    if orch.owner_state.paused:
        await orch.telegram.reply(chat_id=str(chat_id), text="Already paused.")
        return True
    orch.owner_state.paused = True
    log.info("paused by owner")
    await orch.telegram.reply(
        chat_id=str(chat_id),
        text="⏸ Paused. New inbound is dropped until /resume.",
    )
    return True


async def _cmd_resume(orch, chat_id, _arg) -> bool:
    if not orch.owner_state.paused:
        await orch.telegram.reply(chat_id=str(chat_id), text="Already running.")
        return True
    orch.owner_state.paused = False
    log.info("resumed by owner")
    await orch.telegram.reply(chat_id=str(chat_id), text="▶ Resumed.")
    return True


async def _cmd_abort(orch, chat_id, _arg) -> bool:
    if orch.claude is None:
        await orch.telegram.reply(chat_id=str(chat_id), text="No agent attached.")
        return True
    log.info("abort requested by owner")
    # Killing the subprocess is the bluntest signal claude understands. The
    # orchestrator's run loop respawns it on next inbound (or owner /restart).
    await orch.claude.stop()
    await orch.claude.start()
    await orch.telegram.reply(chat_id=str(chat_id), text="✋ Aborted in-flight turn.")
    return True


async def _cmd_restart(orch, chat_id, _arg) -> bool:
    return await _start_destructive(orch, chat_id, label="restart")


async def _cmd_new(orch, chat_id, _arg) -> bool:
    return await _start_destructive(orch, chat_id, label="new")


async def _cmd_compact(orch, chat_id, _arg) -> bool:
    """Send the literal `/compact` slash command to claude over its stream-json
    stdin so the CLI runs its own conversation-compact action.

    Uses the same claim/fold/wait machinery as user inbound — the reader
    task drains the resulting `result` event, fires _turn_done, and we
    return after the compaction completes. Holding the active-chat slot
    means a concurrent user message from another chat waits politely.
    """
    if orch.claude is None:
        await orch.telegram.reply(chat_id=str(chat_id), text="No agent attached.")
        return True
    await orch._claim_and_push(chat_id=chat_id, message_id=None,
                                wrapped="/compact")
    await orch.telegram.reply(chat_id=str(chat_id), text="🗜 Sent /compact to agent.")
    return True


COMMANDS: dict[str, Handler] = {
    "/status":  _cmd_status,
    "/pause":   _cmd_pause,
    "/resume":  _cmd_resume,
    "/abort":   _cmd_abort,
    "/restart": _cmd_restart,
    "/new":     _cmd_new,
    "/compact": _cmd_compact,
}


# ---------- Cancel window for destructive ops ----------


async def _start_destructive(orch, chat_id, *, label: str) -> bool:
    s = orch.owner_state
    if s.pending_destructive is not None:
        await orch.telegram.reply(
            chat_id=str(chat_id),
            text=f"{s.pending_destructive.label!s} already pending — reply 'cancel' to abort.",
        )
        return True

    async def _delayed():
        try:
            await asyncio.sleep(CANCEL_WINDOW_SECONDS)
        except asyncio.CancelledError:
            return
        # Window elapsed — execute the destructive op.
        log.info("destructive %s firing", label)
        try:
            if label == "restart":
                await orch.claude.stop()
                await orch.claude.start()
                await orch.telegram.reply(chat_id=str(chat_id), text="🔁 Agent restarted.")
            elif label == "new":
                # Fresh session: stop + restart with a brand-new --session-id.
                # We pass session_id explicitly so --continue is bypassed.
                import uuid as _uuid
                await orch.claude.stop()
                orch.claude.session_id = str(_uuid.uuid4())
                orch.claude.continue_session = False
                await orch.claude.start()
                await orch.telegram.reply(
                    chat_id=str(chat_id),
                    text="🆕 New session started — prior context dropped.",
                )
        finally:
            orch.owner_state.pending_destructive = None

    task = asyncio.create_task(_delayed(), name=f"destructive-{label}")
    s.pending_destructive = PendingDestructive(
        label=label,
        deadline=time.time() + CANCEL_WINDOW_SECONDS,
        task=task,
    )
    await orch.telegram.reply(
        chat_id=str(chat_id),
        text=f"⚠ {label.capitalize()} in {int(CANCEL_WINDOW_SECONDS)}s. Reply 'cancel' to abort.",
    )
    return True


async def _maybe_cancel_destructive(orch, chat_id, text: str) -> bool:
    """If owner sends literal 'cancel' while a destructive op is pending,
    cancel it. Returns True iff handled."""
    s = orch.owner_state
    if s.pending_destructive is None:
        return False
    if text.strip().lower() != "cancel":
        return False
    pending = s.pending_destructive
    pending.task.cancel()
    s.pending_destructive = None
    await orch.telegram.reply(
        chat_id=str(chat_id),
        text=f"✋ Cancelled the pending {pending.label}.",
    )
    return True


# ---------- Public entry point ----------


async def maybe_handle_owner(
    orch: "WaggleOrchestrator", *, chat_id: int, user_id: int, text: str,
) -> bool:
    """Returns True iff the inbound was consumed by an owner op (so the
    orchestrator MUST NOT forward it to claude). Never raises.

    Owner ops are scoped to **DM only** — sending /status / /pause / etc.
    in a group does NOT trigger them. Reasons:
      • Other group members shouldn't see operational state (status leaks
        last-inbound preview, turn count)
      • Slash commands in groups are often addressed at OTHER bots
        (`/status@some_other_bot`) and we don't want false positives
      • Owner ops are operator surface — DM is the right channel"""
    if not _is_owner(orch, user_id):
        return False
    if chat_id < 0:
        # Group / supergroup — fall through; do not consume.
        return False

    # Cancel-window check first — `cancel` is plain text, not a slash command.
    if await _maybe_cancel_destructive(orch, chat_id, text):
        return True

    parsed = _slash_command(text)
    if parsed is None:
        return False  # owner is just chatting normally

    cmd, arg = parsed
    handler = COMMANDS.get(cmd)
    if handler is None:
        # Unknown command — let it fall through to claude. Avoids hijacking
        # things like `/explain` that the model can handle.
        return False
    try:
        return await handler(orch, chat_id, arg)
    except Exception:
        log.exception("owner command %s crashed", cmd)
        try:
            await orch.telegram.reply(
                chat_id=str(chat_id),
                text=f"⚠ Owner command {cmd} crashed — see logs.",
            )
        except Exception:
            pass
        return True  # consumed even though it failed; don't double-process


# ---------- §1.8 Owner notifications ----------


@dataclass
class NotifyContext:
    """Where to post owner-only notifications. Best-effort — losing one is
    acceptable, never blocks the orchestrator."""

    telegram: object  # TelegramClient — duck-typed so tests can stub
    owner_chat: int


async def notify_owner(ctx: NotifyContext, what: str, *, why: str | None = None,
                       todo: str | None = None) -> None:
    parts = [f"🔔 {what}"]
    if why:
        parts.append(f"why: {why}")
    if todo:
        parts.append(f"what to do: {todo}")
    text = "\n".join(parts)
    try:
        await ctx.telegram.reply(chat_id=str(ctx.owner_chat), text=text)
    except Exception as e:
        log.warning("notify_owner failed (%s): %r", what, e)
