"""Working-status indicator (§1.9 / Phase 2.5).

While claude is processing one turn, surface the live state in the source
chat as a single rolling status message:

    🤔 Thinking…           (assistant chunk arrived, no tool yet)
    🔧 Tool: <name>        (claude called a tool — args are NOT shown)
    📝 Writing reply…      (assistant chunk after a tool result)

The indicator carries two inline-keyboard buttons:
  • "🧠 Show thinking" — posts a NEW reply with claude's accumulated
    extended-thinking content (the model's internal reasoning, not the
    tool calls or pre-reply text). Subsequent taps refresh the same
    message; the button label flips to "🔄 Refresh thinking".
  • "✅ Show tasks" — posts a NEW reply rendering the latest TodoWrite
    snapshot. Same Show/Refresh lifecycle.

Why a separate message per surface:
  • The rolling indicator keeps showing live state without being
    clobbered by the user's expanded view.
  • Each post-mortem surface has its own lifetime (persists past turn
    end so anh can scroll back later).
  • State machine stays simple — surfaces are independent.

Edits are debounced to stay under Telegram's 20-edits/min/message limit.
The implementation pins the latest desired state and re-applies it after
the debounce window — burst-y state changes coalesce into one edit.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .clients.telegram import TelegramClient

log = logging.getLogger(__name__)


# Debounce window — Telegram caps edit_message at ~20 ops/min/message, so
# anything below ~3s is safe even for bursty bot pipelines.
DEBOUNCE_SECONDS = 1.5

# Telegram caps message text at 4096 chars. Reserve some headroom for
# truncation marker.
THINKING_MAX_CHARS = 3900

# Callback data shapes used by the thinking & tasklist buttons. Kept
# short so they fit Telegram's 64-byte callback_data cap.
CB_SHOW_THINKING = "t:show"
CB_REFRESH_THINKING = "t:refresh"
CB_SHOW_TASKLIST = "tk:show"
CB_REFRESH_TASKLIST = "tk:refresh"


@dataclass
class _StatusState:
    chat_id: int
    message_id: str  # the rolling indicator message
    label: str
    in_flight: bool = False
    pending: str | None = None
    # Per-turn thinking buffer — non-empty extended-thinking blocks from
    # claude's stream-json output, append-only. Rendered into a separate
    # message when the user taps Show thinking.
    thinking: list[str] = field(default_factory=list)
    # The thinking message_id. None until the user first taps Show.
    thinking_message_id: str | None = None
    # Latest tasklist snapshot (list of {content, status}) — overwritten
    # on every TodoWrite tool_use the agent emits during the turn.
    tasklist: list[dict] = field(default_factory=list)
    # The tasklist message_id. None until the user first taps Show.
    tasklist_message_id: str | None = None
    # The user-message_id we should reply-to for the post-mortem
    # surfaces (= the original inbound). Captured at attach() time.
    reply_to_message_id: str | None = None


def _indicator_keyboard():
    """The indicator's inline keyboard: one row with Show-thinking and
    Show-tasks. The buttons NEVER swap — taps are idempotent (first tap
    posts the dedicated message, subsequent taps refresh that same
    message). The post-tap "Refresh" button lives on the surface
    message itself, not on the indicator."""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="🧠 Show thinking", callback_data=CB_SHOW_THINKING),
        InlineKeyboardButton(
            text="✅ Show tasks", callback_data=CB_SHOW_TASKLIST),
    ]])


def _surface_keyboard(callback_data: str, label: str = "🔄 Refresh"):
    """Inline keyboard attached to a thinking/tasklist message itself —
    a single Refresh button so the user can force a re-render from the
    same message they're reading."""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=label, callback_data=callback_data),
    ]])


def _render_thinking(entries: list[str]) -> str:
    """Format the buffered thinking blocks into one chat-friendly body
    with a `🧠 Thinking` header.

    Returns a placeholder when empty — claude only emits non-empty
    thinking when the model decides extended reasoning is worth it AND
    the auth path supports it (some 3rd-party Anthropic-compatible
    gateways strip the thinking blocks; native Anthropic auth keeps
    them, but Opus redacts content even with native auth).
    """
    header = "🧠 Thinking"
    if not entries:
        return (header + "\n\n"
                "(no thinking content yet — either the agent is still "
                "spinning up, the model didn't emit reasoning for this "
                "turn, or your model redacts thinking output, e.g. Opus)")
    body = "\n\n".join(entries).strip()
    # Reserve space for the header so the joined body fits Telegram's cap.
    cap = THINKING_MAX_CHARS - len(header) - 2
    if len(body) > cap:
        body = "…(older thoughts truncated)…\n\n" + body[-cap:]
    return header + "\n\n" + body


_STATUS_TO_EMOJI = {
    "completed": "✅",
    "in_progress": "🔄",
    "pending": "⏳",
}


def _render_tasklist(todos: list[dict]) -> str:
    """Format a TodoWrite snapshot into a chat-friendly body. Header
    counts completed / total; each entry is `<emoji> <content>`."""
    if not todos:
        return "(no tasks yet — agent hasn't called TodoWrite this turn)"
    completed = sum(1 for t in todos
                    if isinstance(t, dict) and t.get("status") == "completed")
    total = len(todos)
    lines = [f"📋 Tasks {completed}/{total}", ""]
    for t in todos:
        if not isinstance(t, dict):
            continue
        emoji = _STATUS_TO_EMOJI.get(t.get("status"), "•")
        content = str(t.get("content") or "(unnamed)").strip()
        lines.append(f"{emoji} {content}")
    body = "\n".join(lines)
    if len(body) > THINKING_MAX_CHARS:
        body = body[:THINKING_MAX_CHARS] + "\n…(truncated)…"
    return body


class StatusIndicator:
    """One indicator per chat-id during a single turn.

    Construct fresh per turn (via `attach(chat_id)`), edit through state
    changes via `set_state(...)`, and tear down with `success()` or
    `error(msg)` exactly once.
    """

    LABEL_THINKING = "🤔 Thinking…"
    LABEL_WRITING = "📝 Writing reply…"

    def __init__(self, telegram: "TelegramClient"):
        self._telegram = telegram
        self._set: dict[int, _StatusState] = {}

    # ---- Lifecycle ----

    async def attach(self, chat_id: int, reply_to: str | None = None) -> None:
        """First call per turn for `chat_id`. Posts the initial Thinking
        message with two inline-keyboard buttons (Show thinking, Show
        tasks) and remembers its id."""
        if chat_id in self._set:
            return
        try:
            mid = await self._telegram.reply(
                chat_id=str(chat_id),
                text=self.LABEL_THINKING,
                reply_to=reply_to,
                reply_markup=_indicator_keyboard(),
            )
        except Exception as e:
            log.warning("status attach skipped chat=%s: %r", chat_id, e)
            return
        self._set[chat_id] = _StatusState(
            chat_id=chat_id, message_id=mid, label=self.LABEL_THINKING,
            reply_to_message_id=reply_to,
        )

    async def set_state(self, label: str) -> None:
        """Update the label on every status message in the working-set.
        Debounced — bursty calls coalesce into the latest label."""
        for chat_id, state in list(self._set.items()):
            if state.label == label:
                continue
            state.pending = label
            if state.in_flight:
                continue  # debouncer will pick up the latest
            state.in_flight = True
            asyncio.create_task(self._debounced_edit(state))

    def append_thinking(self, chat_id: int, text: str) -> None:
        """Buffer a non-empty extended-thinking block from claude's
        stream-json output. Append-only; rendered on user request via
        show_thinking().

        Empty thinking blocks (some auth gateways emit thinking blocks
        with empty content) are filtered upstream — anh only wants the
        actual reasoning text in this view, no placeholder noise.
        """
        state = self._set.get(chat_id)
        if state is None or not text:
            return
        state.thinking.append(text)

    async def show_thinking(self, chat_id: int) -> None:
        """User tapped the Show / Refresh thinking button. On first
        tap, post a NEW reply message with the buffered thinking. On
        subsequent taps, edit that message with the latest buffer."""
        await self._show_or_refresh(
            chat_id=chat_id, surface="thinking",
            render_body=lambda s: _render_thinking(s.thinking),
        )

    async def show_tasklist(self, chat_id: int) -> None:
        """User tapped the Show / Refresh tasks button. Same lifecycle
        as the thinking view, just rendering the latest TodoWrite
        snapshot instead of the reasoning log."""
        await self._show_or_refresh(
            chat_id=chat_id, surface="tasklist",
            render_body=lambda s: _render_tasklist(s.tasklist),
        )

    def update_tasklist(self, chat_id: int, todos: list[dict]) -> None:
        """Reader saw a TodoWrite tool_use — overwrite the snapshot.
        The view is pull-based (only renders when the user taps Show),
        so the latest snapshot is enough; older versions don't matter.
        """
        state = self._set.get(chat_id)
        if state is None:
            return
        state.tasklist = list(todos)

    async def _show_or_refresh(
        self,
        *,
        chat_id: int,
        surface: str,  # "thinking" | "tasklist"
        render_body,
    ) -> None:
        """Common machinery for the Show/Refresh-X buttons. First tap
        posts a new reply (with a self-contained Refresh button on it);
        subsequent taps edit that same message in place."""
        state = self._set.get(chat_id)
        if state is None:
            return
        body = render_body(state)
        attr = f"{surface}_message_id"
        target_mid = getattr(state, attr)
        # The Refresh button on the surface message points at the same
        # surface (thinking → t:refresh, tasklist → tk:refresh).
        refresh_cb = (CB_REFRESH_THINKING if surface == "thinking"
                      else CB_REFRESH_TASKLIST)
        kb = _surface_keyboard(refresh_cb)
        if target_mid is None:
            try:
                new_mid = await self._telegram.reply(
                    chat_id=str(state.chat_id),
                    text=body,
                    reply_to=state.reply_to_message_id,
                    reply_markup=kb,
                )
            except Exception as e:
                log.warning("show_%s post skipped chat=%s: %r",
                            surface, state.chat_id, e)
                return
            setattr(state, attr, new_mid)
        else:
            try:
                await self._telegram.edit_text(
                    chat_id=str(state.chat_id),
                    message_id=target_mid,
                    text=body,
                    reply_markup=kb,
                )
            except Exception as e:
                msg = str(e)
                if "message is not modified" not in msg:
                    log.warning("show_%s refresh skipped chat=%s: %r",
                                surface, state.chat_id, e)

    async def success(self) -> None:
        """Turn finished cleanly. Delete the rolling indicator (the
        agent already replied via the `reply` tool). Thinking and
        tasklist messages, if posted, persist for post-mortem."""
        for chat_id, state in list(self._set.items()):
            try:
                await self._telegram.delete_message(
                    chat_id=str(chat_id),
                    message_id=state.message_id,
                )
            except Exception as e:
                log.warning("status teardown skipped chat=%s: %r", chat_id, e)
            # If the user opened thinking / tasklist, do one final
            # refresh so the persistent messages reflect the full final
            # buffer.
            await self._final_refresh(state)
        self._set.clear()

    async def error(self, msg: str) -> None:
        """Turn errored — delete the rolling indicator AND post a new
        error reply. Thinking / tasklist messages, if any, stay."""
        text = f"❌ Error: {msg[:200]}" if msg else "❌ Error"
        for chat_id, state in list(self._set.items()):
            try:
                await self._telegram.delete_message(
                    chat_id=str(chat_id),
                    message_id=state.message_id,
                )
            except Exception as e:
                log.warning("status delete skipped chat=%s: %r", chat_id, e)
            try:
                await self._telegram.reply(chat_id=str(chat_id), text=text)
            except Exception as e:
                log.warning("error reply skipped chat=%s: %r", chat_id, e)
            await self._final_refresh(state)
        self._set.clear()

    # ---- Internals ----

    async def _final_refresh(self, state: _StatusState) -> None:
        """Push the latest thinking / tasklist body into their
        respective post-mortem messages, if the user opened them. Called
        from success() and error() so the persistent surfaces reflect
        the full final state."""
        if state.thinking_message_id is not None:
            try:
                await self._telegram.edit_text(
                    chat_id=str(state.chat_id),
                    message_id=state.thinking_message_id,
                    text=_render_thinking(state.thinking),
                    reply_markup=None,
                )
            except Exception as e:
                msg = str(e)
                if "message is not modified" not in msg:
                    log.debug("thinking final refresh skipped chat=%s: %r",
                              state.chat_id, e)
        if state.tasklist_message_id is not None:
            try:
                await self._telegram.edit_text(
                    chat_id=str(state.chat_id),
                    message_id=state.tasklist_message_id,
                    text=_render_tasklist(state.tasklist),
                    reply_markup=None,
                )
            except Exception as e:
                msg = str(e)
                if "message is not modified" not in msg:
                    log.debug("tasklist final refresh skipped chat=%s: %r",
                              state.chat_id, e)

    async def _debounced_edit(self, state: _StatusState) -> None:
        try:
            while state.pending is not None and state.pending != state.label:
                await asyncio.sleep(DEBOUNCE_SECONDS)
                target = state.pending
                state.pending = None
                if target == state.label:
                    continue
                # Indicator's button row stays the same the whole turn —
                # taps are idempotent. Refresh lives on the surface
                # message itself, not on the indicator.
                kb = _indicator_keyboard()
                try:
                    await self._telegram.edit_text(
                        chat_id=str(state.chat_id),
                        message_id=state.message_id,
                        text=target,
                        reply_markup=kb,
                    )
                    state.label = target
                except Exception as e:
                    log.warning("status edit skipped chat=%s: %r", state.chat_id, e)
                    return
        finally:
            state.in_flight = False
