"""waggle — communication channel for AI agents (MCP-server architecture).

waggle runs as an MCP server claude-code loads on startup. Each platform
client (Telegram day 1, Matrix later) bridges its inbound message stream
to MCP `notifications/claude/channel` notifications, and exposes outbound
primitives (reply, react, edit, attachment download) as tools the model
can call.
"""

__version__ = "0.2.0"

from .channel_tag import ChannelTag
from .protocol import Attachment, InboundMessage

__all__ = ["Attachment", "ChannelTag", "InboundMessage", "__version__"]
