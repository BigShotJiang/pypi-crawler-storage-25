"""External-trigger HTTP endpoint (§1.4 / Phase 3).

A small aiohttp server that lets alerting tools / CI / cron systems push a
prompt into the agent's active chat through an authenticated POST. Every
request becomes a synthetic inbound submission with `source="external"` so
the model can tell it apart from a user-typed message.

Wire (request body):

    POST /inject
    Authorization: Bearer <shared_secret>
    Content-Type: application/json

    {
      "prompt":   "the text to inject as a user message",
      "chat_id":  -1001234567890   (optional; falls back to default_chat_id)
    }

Responses:

    200 — accepted; body: {"submitted": true, "chat_id": "..."}
    400 — malformed JSON / missing fields
    401 — wrong or missing bearer
    503 — orchestrator not ready (e.g. claude subprocess down)

Owner-only operations are NEVER reachable through this endpoint — the
runtime gate in `WaggleOrchestrator.submit_inbound` doesn't enforce
that itself yet, so the endpoint deliberately doesn't pretend to (P4
will add caller-is-owner checks where they belong).
"""

from __future__ import annotations

import asyncio
import logging
import secrets
from typing import TYPE_CHECKING

from aiohttp import web

if TYPE_CHECKING:
    from .orchestrator import WaggleOrchestrator

log = logging.getLogger(__name__)


# Synthetic ids used in the channel tag for an external-trigger inbound.
# Negative chat_id tells access.py we're in "group" branch — but we bypass
# that gate entirely in submit_inbound_external(), since the bearer check
# IS the access gate for this endpoint.
EXTERNAL_USER_ID = "external"


class InjectServer:
    def __init__(
        self,
        *,
        bind: str,
        shared_secret: str,
        default_chat_id: int,
        orchestrator: "WaggleOrchestrator",
    ):
        self._bind = bind
        self._secret = shared_secret
        self._default_chat = default_chat_id
        self._orch = orchestrator
        self._runner: web.AppRunner | None = None

    async def start(self) -> None:
        app = web.Application()
        app.router.add_post("/inject", self._handle_inject)
        app.router.add_get("/healthz", self._handle_healthz)
        self._runner = web.AppRunner(app, access_log=None)
        await self._runner.setup()
        host, _, port = self._bind.partition(":")
        site = web.TCPSite(self._runner, host or "0.0.0.0", int(port or "8080"))
        await site.start()
        log.info("inject endpoint listening on %s", self._bind)

    async def stop(self) -> None:
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None

    # ---- Handlers ----

    async def _handle_healthz(self, _: web.Request) -> web.Response:
        return web.json_response({"ok": True})

    async def _handle_inject(self, request: web.Request) -> web.Response:
        # 1. Auth — constant-time compare against the configured secret.
        provided = _bearer(request)
        if provided is None or not secrets.compare_digest(provided, self._secret):
            return web.json_response({"error": "unauthorized"}, status=401)

        # 2. Parse body.
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "malformed-json"}, status=400)
        if not isinstance(body, dict):
            return web.json_response({"error": "body must be a json object"}, status=400)

        prompt = body.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            return web.json_response(
                {"error": "missing or empty 'prompt'"},
                status=400,
            )

        # 3. Resolve chat target.
        raw_chat = body.get("chat_id")
        try:
            chat_id = int(raw_chat) if raw_chat is not None else self._default_chat
        except (TypeError, ValueError):
            return web.json_response({"error": "invalid 'chat_id'"}, status=400)

        # 4. Hand to the orchestrator. Fire-and-forget — the HTTP caller
        #    (alertmanager, CI, scheduler, …) wants to know the message was
        #    accepted, NOT wait for claude to finish the turn (which can be
        #    minutes). The agent's reply lands via the MCP `reply` tool
        #    back on Telegram independently.
        #
        #    The endpoint's bearer check IS the access gate for external
        #    triggers — bypass the user-allow-list by using a dedicated
        #    entry point.
        async def _do_submit():
            try:
                await self._orch.submit_external(
                    chat_id=chat_id,
                    prompt=prompt,
                    source_label=str(body.get("source", "external"))[:32],
                )
            except Exception as e:
                log.warning("inject submit_external failed: %r", e)

        asyncio.create_task(_do_submit(), name=f"inject-{chat_id}")
        return web.json_response({"submitted": True, "chat_id": str(chat_id)})


def _bearer(request: web.Request) -> str | None:
    auth = request.headers.get("Authorization", "")
    if not auth.lower().startswith("bearer "):
        return None
    return auth[len("Bearer "):].strip() or None
