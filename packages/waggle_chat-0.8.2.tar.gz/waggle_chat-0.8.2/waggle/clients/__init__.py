"""Platform clients used by the MCP server. One subpackage per platform."""
