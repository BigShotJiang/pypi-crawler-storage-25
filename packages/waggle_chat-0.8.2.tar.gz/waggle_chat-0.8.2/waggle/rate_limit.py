"""Per-chat and per-user rate limiter (P8).

Sliding-window token counter with two independent dimensions: a per-chat
budget (defends a single noisy room from bursting through) and a per-user
budget (defends the agent's overall throughput from one chatty user
spread across rooms).

The window is pure in-memory (deque of timestamps). Pod restart resets
the budgets — that's fine: rate limits are a noisy-neighbour defence,
not a billing primitive. Budgets that survive restart belong in a
purpose-built quota service, not in waggle.

Returns `RateDecision(allow=False, reason=…, …)` so the orchestrator
can emit a structured RejectEvent and the operator can grep
`reason: rate-limited` in the dashboard.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from threading import Lock
from typing import Deque, Literal


@dataclass(frozen=True, slots=True)
class RateLimitConfig:
    """Configuration for the rate limiter. Both per-chat and per-user
    budgets are independent — both must allow for the inbound to pass.

    `chat_per_minute = 0` disables that dimension; same for `user_per_minute`.
    A config of `(0, 0)` is the no-op limiter (everything allowed).
    """

    chat_per_minute: int = 0  # 0 = disabled
    user_per_minute: int = 0  # 0 = disabled
    window_seconds: float = 60.0


@dataclass(frozen=True, slots=True)
class RateDecision:
    allow: bool
    scope: Literal["chat", "user", "ok"]
    used: int        # how many in window so far (post-this-call)
    limit: int       # configured budget for this scope (0 if scope=='ok')
    retry_after: float = 0.0  # seconds until the oldest sample falls out


class RateLimiter:
    """Sliding-window counter. Thread-safe (asyncio runs single-threaded
    but we hold a Lock anyway in case operators mount this in a worker
    pool later — cheap insurance)."""

    def __init__(self, config: RateLimitConfig | None = None):
        self._config = config or RateLimitConfig()
        self._chat_hits: dict[int, Deque[float]] = {}
        self._user_hits: dict[int, Deque[float]] = {}
        self._lock = Lock()

    def update_config(self, config: RateLimitConfig) -> None:
        """Hot-reload entry point. Existing window samples are kept — the
        next call evaluates against the new budget but doesn't retroactively
        reject samples that were below the old limit and over the new one."""
        with self._lock:
            self._config = config

    @property
    def config(self) -> RateLimitConfig:
        return self._config

    def check(self, *, chat_id: int, user_id: int, now: float | None = None) -> RateDecision:
        """Evaluate the inbound against both budgets and record a hit ONLY
        when allowed. Denied hits do not count toward future budget — that
        way a sender hammering at the limit waits out one window and can
        try again, instead of being locked out longer than the window.
        """
        ts = now if now is not None else time.monotonic()
        cfg = self._config
        with self._lock:
            chat_q = self._chat_hits.setdefault(chat_id, deque())
            user_q = self._user_hits.setdefault(user_id, deque())
            self._evict(chat_q, ts, cfg.window_seconds)
            self._evict(user_q, ts, cfg.window_seconds)

            # Per-chat dimension
            if cfg.chat_per_minute > 0 and len(chat_q) >= cfg.chat_per_minute:
                retry = max(0.0, chat_q[0] + cfg.window_seconds - ts)
                return RateDecision(
                    allow=False, scope="chat",
                    used=len(chat_q) + 1, limit=cfg.chat_per_minute,
                    retry_after=retry,
                )
            # Per-user dimension
            if cfg.user_per_minute > 0 and len(user_q) >= cfg.user_per_minute:
                retry = max(0.0, user_q[0] + cfg.window_seconds - ts)
                return RateDecision(
                    allow=False, scope="user",
                    used=len(user_q) + 1, limit=cfg.user_per_minute,
                    retry_after=retry,
                )
            chat_q.append(ts)
            user_q.append(ts)
            return RateDecision(allow=True, scope="ok", used=len(user_q),
                                limit=cfg.user_per_minute or cfg.chat_per_minute)

    @staticmethod
    def _evict(q: Deque[float], now: float, window: float) -> None:
        cutoff = now - window
        while q and q[0] < cutoff:
            q.popleft()
