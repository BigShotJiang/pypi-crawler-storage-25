"""Telegram 'is typing…' indicator (P8).

Telegram's `sendChatAction` paints "bot is typing…" in the chat header
for ~5 seconds. For a long turn we must re-send periodically. This
helper wraps that as a context-manager style start/stop pair driven by
the orchestrator: `attach(chat_id)` kicks off a background poll task
that fires every `interval_seconds` until `detach(chat_id)`.

Why a separate component (vs just calling send_chat_action inline):

  • The orchestrator's turn loop is event-driven (it `read_events()`
    over claude's stdout). It can't sleep-and-poke without blocking.
  • Multiple chats may be in-flight if/when concurrent turns are
    allowed (today they're serialised, but the design future-proofs).
  • Best-effort: a kicked/deleted chat must not crash the runtime —
    every send is wrapped in try/except.

Complements the existing P2.5 `StatusIndicator` (which posts a rolling
"🤔 Thinking…" REPLY message). The two surfaces are independent: the
chat header shows "typing…" while the message thread shows the rolling
state. Operators can disable either without affecting the other.
"""

from __future__ import annotations

import asyncio
import logging

log = logging.getLogger(__name__)


class TypingIndicator:
    """Per-chat typing-action poller. `attach()` and `detach()` are safe
    to call repeatedly; nesting is reference-counted so two concurrent
    turns on the same chat don't fight each other. (Today turn-lock
    serialises, so this is forward compat.)"""

    def __init__(self, transport, *, interval_seconds: float = 4.0):
        self._transport = transport
        self._interval = interval_seconds
        self._tasks: dict[int, asyncio.Task] = {}
        self._refs: dict[int, int] = {}

    async def attach(self, chat_id: int) -> None:
        n = self._refs.get(chat_id, 0) + 1
        self._refs[chat_id] = n
        if n == 1:
            # First use for this chat — kick off the poll task.
            task = asyncio.create_task(
                self._poll(chat_id), name=f"typing-{chat_id}",
            )
            self._tasks[chat_id] = task

    async def detach(self, chat_id: int) -> None:
        n = self._refs.get(chat_id, 0)
        if n <= 1:
            self._refs.pop(chat_id, None)
            task = self._tasks.pop(chat_id, None)
            if task is not None:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    log.debug("typing task exited with: %r", e)
        else:
            self._refs[chat_id] = n - 1

    async def _poll(self, chat_id: int) -> None:
        try:
            while True:
                try:
                    await self._transport.send_chat_action(
                        chat_id=str(chat_id), action="typing",
                    )
                except Exception as e:
                    log.debug("typing send failed for %s: %r", chat_id, e)
                await asyncio.sleep(self._interval)
        except asyncio.CancelledError:
            pass
