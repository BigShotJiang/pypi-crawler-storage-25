# This file was generated automatically. Do not edit it directly.
from typing import Literal, NotRequired, TypedDict, Union, Unpack, cast

from fountain_life_service_clients._base_client import (
    AlphaConfig,
    AlphaResponse,
    BaseClient,
)


class ChangeMemberAppEmailApiRequest(TypedDict):
    patientId: str
    newEmail: str


class ChangeMemberAppEmailApiResponse(TypedDict):
    ok: NotRequired[bool]


class ChangeMemberAppPhoneApiRequest(TypedDict):
    patientId: str
    newPhoneNumber: NotRequired[str]
    removePhone: NotRequired[bool]


class ChangeMemberAppPhoneApiResponse(TypedDict):
    ok: NotRequired[bool]


class OnboardMemberToAppRequest(TypedDict):
    patientId: str
    preferredContactMethod: NotRequired[Literal["email", "sms", "phone", "none"]]
    scheduleSurveyReminders: NotRequired[bool]
    skipOnboardingSurveys: NotRequired[bool]
    skipSecondaryConsents: NotRequired[bool]
    username: NotRequired[str]


class OnboardMemberToAppResponse(TypedDict):
    pass


class BaseMemberOnboardingApiRequest(TypedDict):
    patientId: str


class BaseMemberOnboardingApiResponse1(TypedDict):
    status: Literal["completed"]
    memberId: str
    pipelineStage: Literal["MEMBER_ONBOARDING_REQUESTED"]


class BaseMemberOnboardingApiResponse2(TypedDict):
    status: Literal["skipped"]


BaseMemberOnboardingApiResponse = Union[
    BaseMemberOnboardingApiResponse1, BaseMemberOnboardingApiResponse2
]


class MemberOperationsServiceMembersClient(BaseClient):
    def __init__(self, **cfg: Unpack[AlphaConfig]):
        kwargs = {
            "target": "lambda://member-operations-service:deployed",
            **(cfg or {}),
        }
        super().__init__(**kwargs)

    async def change_member_app_email_api(self, body: ChangeMemberAppEmailApiRequest):
        res = await self.client.request(
            path="/v1/member-operations/members/change-email",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[ChangeMemberAppEmailApiResponse], res)

    async def change_member_app_phone_api(self, body: ChangeMemberAppPhoneApiRequest):
        res = await self.client.request(
            path="/v1/member-operations/members/change-phone",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[ChangeMemberAppPhoneApiResponse], res)

    async def onboard_member_to_app(self, body: OnboardMemberToAppRequest):
        res = await self.client.request(
            path="/v1/member-operations/members/onboard",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[OnboardMemberToAppResponse], res)

    async def base_member_onboarding_api(self, body: BaseMemberOnboardingApiRequest):
        res = await self.client.request(
            path="/v1/member-operations/members/base-onboarding",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[BaseMemberOnboardingApiResponse], res)
