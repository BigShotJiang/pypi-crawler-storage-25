# This file was generated automatically. Do not edit it directly.
from typing import (
    Any,
    Dict,
    List,
    Literal,
    NotRequired,
    Optional,
    TypedDict,
    Union,
    Unpack,
    cast,
)
from urllib.parse import quote

from fountain_life_service_clients._base_client import (
    AlphaConfig,
    AlphaResponse,
    BaseClient,
)


class PageSize(TypedDict):
    pass


class GetResultsV3Params(TypedDict):
    pageSize: NotRequired[PageSize]
    nextPageToken: NotRequired[str]
    project: str
    resultCount: float
    cohort: NotRequired[str]
    includeClinicOnly: NotRequired[bool]
    includeAiGeneratedMappings: NotRequired[bool]
    source: NotRequired[Literal["mappedLabs", "unmappedLabs", "memberUpload"]]


class Coding(TypedDict):
    code: str
    system: str
    display: str


class System(TypedDict):
    code: str
    system: str
    display: NotRequired[str]


class SubSystem(TypedDict):
    code: str
    system: str
    display: NotRequired[str]


class Annotation(TypedDict):
    topicName: str
    priority: Literal["monitor", "deprioritized"]
    notes: NotRequired[List[str]]
    startDate: NotRequired[str]


class Results(TypedDict):
    type: Literal["withoutRange"]
    status: Literal["default"]
    resource: Dict[str, Any]
    annotation: NotRequired[Annotation]


class InRange(TypedDict):
    lower: NotRequired[float]
    upper: NotRequired[float]
    label: str
    status: Literal["in-range"]


class Optimal(TypedDict):
    """
    Currently this is always undefined. It may be used in the future.
    """

    lower: NotRequired[float]
    upper: NotRequired[float]
    label: str
    status: Literal["optimal"]


"""
Populated from reference ranges on the observation.
"""
Ranges = TypedDict(
    "Ranges",
    {
        "in-range": InRange,
        "optimal": NotRequired[Optimal],
    },
)


class PersonalizedRange(TypedDict):
    """
    Numeric target band from the Goal’s detailRange when present.
    """

    low: NotRequired[float]
    high: NotRequired[float]
    unit: NotRequired[str]


class Attention(TypedDict):
    lower: NotRequired[float]
    upper: NotRequired[float]
    label: str
    status: Literal["attention"]


class optimal(TypedDict):
    lower: NotRequired[float]
    upper: NotRequired[float]
    label: str
    status: Literal["optimal"]


"""
Band from the Goal’s personalized range: the interval the care team treats as on-target. The `in-range` slot reuses the same shape as row-level `ranges` for charting; its label names the goal band, not the patient. Whether the observation value hits that band is `result.status` below.
"""
ranges = TypedDict(
    "ranges",
    {
        "in-range": InRange,
        "attention": NotRequired[Attention],
        "optimal": NotRequired[optimal],
    },
)


class Result(TypedDict):
    """
    Interpretation vs the **personalized** band only. `status` is authoritative; `interpretationText` is reused from static code-mapping strings and may not literally match “standard” vs “goal” wording in edge cases.
    """

    status: Literal["in-range", "attention", "optimal"]
    text: str
    interpretationText: str


class annotation(TypedDict):
    """
    Result-annotation Goal: provider-specific context (topic, notes, optional numeric target). When `ranges`, `result`, and `statusMatchesStandardRange` are present, they describe the observation vs the **Goal band**; row-level `ranges` / `result` (history) or `ranges` / `status` (v3) remain **standard** bands from code mappings in this service. If Goal and mapping disagree, treat personalized fields as care-team intent and standard fields as population/lab interpretation.
    """

    topicName: str
    priority: Literal["monitor", "deprioritized"]
    notes: NotRequired[List[str]]
    startDate: NotRequired[str]
    personalizedRange: NotRequired[PersonalizedRange]
    ranges: NotRequired[ranges]
    result: NotRequired[Result]
    statusMatchesStandardRange: NotRequired[bool]


class results(TypedDict):
    type: Literal["withRange"]
    status: Literal["in-range", "attention", "optimal"]
    resource: Dict[str, Any]
    ranges: Ranges
    annotation: NotRequired[annotation]


class Annotation2(TypedDict):
    topicName: str
    priority: Literal["monitor", "deprioritized"]
    notes: NotRequired[List[str]]
    startDate: NotRequired[str]


class Results2(TypedDict):
    type: Literal["pending"]
    status: Literal["pending"]
    resource: Dict[str, Any]
    annotation: NotRequired[Annotation2]


class Item(TypedDict):
    coding: Coding
    systems: List[System]
    subSystems: List[SubSystem]
    results: List[Union[Union[Results, results], Results2]]


class Links(TypedDict):
    self: str
    next: NotRequired[Optional[Union[Any, str]]]


class GetResultsV3Response(TypedDict):
    items: List[Item]
    links: Links


class GetHistoryParams(TypedDict):
    pageSize: NotRequired[PageSize]
    nextPageToken: NotRequired[str]
    project: str
    code: str
    system: str
    cohort: NotRequired[str]
    includeClinicOnly: NotRequired[bool]
    includeAiGeneratedMappings: NotRequired[bool]
    source: NotRequired[Literal["mappedLabs", "memberUpload", "unmappedLabs"]]


Ranges2 = TypedDict(
    "Ranges2",
    {
        "in-range": InRange,
        "attention": NotRequired[Attention],
        "optimal": NotRequired[optimal],
    },
)


class result(TypedDict):
    status: Literal["in-range", "attention", "optimal"]
    text: str
    interpretationText: str


"""
Band from the Goal’s personalized range: the interval the care team treats as on-target. The `in-range` slot reuses the same shape as row-level `ranges` for charting; its label names the goal band, not the patient. Whether the observation value hits that band is `result.status` below.
"""
Ranges3 = TypedDict(
    "Ranges3",
    {
        "in-range": InRange,
        "attention": NotRequired[Attention],
        "optimal": NotRequired[optimal],
    },
)


class Result2(TypedDict):
    """
    Interpretation vs the **personalized** band only. `status` is authoritative; `interpretationText` is reused from static code-mapping strings and may not literally match “standard” vs “goal” wording in edge cases.
    """

    status: Literal["in-range", "attention", "optimal"]
    text: str
    interpretationText: str


class Annotation3(TypedDict):
    """
    Result-annotation Goal: provider-specific context (topic, notes, optional numeric target). When `ranges`, `result`, and `statusMatchesStandardRange` are present, they describe the observation vs the **Goal band**; row-level `ranges` / `result` (history) or `ranges` / `status` (v3) remain **standard** bands from code mappings in this service. If Goal and mapping disagree, treat personalized fields as care-team intent and standard fields as population/lab interpretation.
    """

    topicName: str
    priority: Literal["monitor", "deprioritized"]
    notes: NotRequired[List[str]]
    startDate: NotRequired[str]
    personalizedRange: NotRequired[PersonalizedRange]
    ranges: NotRequired[Ranges3]
    result: NotRequired[Result2]
    statusMatchesStandardRange: NotRequired[bool]


class Items(TypedDict):
    type: Literal["withRange"]
    ranges: Ranges2
    result: result
    coding: Coding
    resource: Dict[str, Any]
    systems: List[System]
    subSystems: List[SubSystem]
    aboutText: str
    aiGenerated: bool
    annotation: NotRequired[Annotation3]


class Result3(TypedDict):
    status: Literal["default"]
    text: str
    interpretationText: str


class Annotation4(TypedDict):
    topicName: str
    priority: Literal["monitor", "deprioritized"]
    notes: NotRequired[List[str]]
    startDate: NotRequired[str]


class items(TypedDict):
    type: Literal["withoutRange"]
    result: Result3
    coding: Coding
    resource: Dict[str, Any]
    systems: List[System]
    subSystems: List[SubSystem]
    aboutText: str
    aiGenerated: bool
    annotation: NotRequired[Annotation4]


class Result4(TypedDict):
    status: Literal["pending"]


class Items2(TypedDict):
    type: Literal["pending"]
    result: Result4
    coding: Coding
    resource: Dict[str, Any]
    systems: List[System]
    subSystems: List[SubSystem]
    aboutText: str
    aiGenerated: bool
    annotation: NotRequired[Annotation4]


class GetHistoryResponse(TypedDict):
    items: List[Union[Union[Items, items], Items2]]
    links: Links


class GetFeaturedResultsParams(TypedDict):
    resultCount: NotRequired[float]
    cohort: NotRequired[str]
    includeClinicOnly: NotRequired[bool]
    includeAiGeneratedMappings: NotRequired[bool]


class Results3(TypedDict):
    type: Literal["withoutRange"]
    status: Literal["default"]
    resource: Dict[str, Any]
    annotation: NotRequired[Annotation4]


class Optimal4(TypedDict):
    """
    Currently this is always undefined. It may be used in the future.
    """

    lower: NotRequired[float]
    upper: NotRequired[float]
    label: str
    status: Literal["optimal"]


"""
Populated from reference ranges on the observation.
"""
Ranges4 = TypedDict(
    "Ranges4",
    {
        "in-range": InRange,
        "optimal": NotRequired[Optimal4],
    },
)


class Optimal5(TypedDict):
    lower: NotRequired[float]
    upper: NotRequired[float]
    label: str
    status: Literal["optimal"]


"""
Band from the Goal’s personalized range: the interval the care team treats as on-target. The `in-range` slot reuses the same shape as row-level `ranges` for charting; its label names the goal band, not the patient. Whether the observation value hits that band is `result.status` below.
"""
Ranges5 = TypedDict(
    "Ranges5",
    {
        "in-range": InRange,
        "attention": NotRequired[Attention],
        "optimal": NotRequired[Optimal5],
    },
)


class Result5(TypedDict):
    """
    Interpretation vs the **personalized** band only. `status` is authoritative; `interpretationText` is reused from static code-mapping strings and may not literally match “standard” vs “goal” wording in edge cases.
    """

    status: Literal["in-range", "attention", "optimal"]
    text: str
    interpretationText: str


class Annotation7(TypedDict):
    """
    Result-annotation Goal: provider-specific context (topic, notes, optional numeric target). When `ranges`, `result`, and `statusMatchesStandardRange` are present, they describe the observation vs the **Goal band**; row-level `ranges` / `result` (history) or `ranges` / `status` (v3) remain **standard** bands from code mappings in this service. If Goal and mapping disagree, treat personalized fields as care-team intent and standard fields as population/lab interpretation.
    """

    topicName: str
    priority: Literal["monitor", "deprioritized"]
    notes: NotRequired[List[str]]
    startDate: NotRequired[str]
    personalizedRange: NotRequired[PersonalizedRange]
    ranges: NotRequired[Ranges5]
    result: NotRequired[Result5]
    statusMatchesStandardRange: NotRequired[bool]


class Results4(TypedDict):
    type: Literal["withRange"]
    status: Literal["in-range", "attention", "optimal"]
    resource: Dict[str, Any]
    ranges: Ranges4
    annotation: NotRequired[Annotation7]


class Annotation8(TypedDict):
    topicName: str
    priority: Literal["monitor", "deprioritized"]
    notes: NotRequired[List[str]]
    startDate: NotRequired[str]


class Results5(TypedDict):
    type: Literal["pending"]
    status: Literal["pending"]
    resource: Dict[str, Any]
    annotation: NotRequired[Annotation8]


class item(TypedDict):
    coding: Coding
    systems: List[System]
    subSystems: List[SubSystem]
    results: List[Union[Union[Results3, Results4], Results5]]


class GetFeaturedResultsResponse(TypedDict):
    items: List[item]


class MedicalResultsServiceResultsClient(BaseClient):
    def __init__(self, **cfg: Unpack[AlphaConfig]):
        kwargs = {"target": "lambda://medical-results-service:deployed", **(cfg or {})}
        super().__init__(**kwargs)

    async def get_results_v3(self, patient_id: str, params: GetResultsV3Params):
        res = await self.client.request(
            path=f"/v1/medical-results/v3/patient/{quote(patient_id)}/results",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetResultsV3Response], res)

    async def get_history(self, patient_id: str, params: GetHistoryParams):
        res = await self.client.request(
            path=f"/v1/medical-results/patient/{quote(patient_id)}/history",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetHistoryResponse], res)

    async def get_featured_results(
        self, project_id: str, patient_id: str, params: GetFeaturedResultsParams
    ):
        res = await self.client.request(
            path=f"/v1/medical-results/v1/project/{quote(project_id)}/patient/{quote(patient_id)}/results/featured",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetFeaturedResultsResponse], res)
