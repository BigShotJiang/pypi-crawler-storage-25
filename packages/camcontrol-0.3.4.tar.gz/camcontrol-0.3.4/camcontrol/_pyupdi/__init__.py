"""
Vendored subset of mraardvark/pyupdi (MIT).

Internal implementation detail used by `camcontrol reflash`.
"""

