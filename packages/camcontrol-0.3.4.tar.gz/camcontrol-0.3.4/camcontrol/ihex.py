from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple


class IHexError(ValueError):
    pass


@dataclass(frozen=True)
class IHexImage:
    start_address: int
    data: List[int]


def _from_hex_byte(s: str) -> int:
    try:
        return int(s, 16)
    except Exception as exc:
        raise IHexError(f"Invalid hex byte: {s!r}") from exc


def load_ihex(filename: str) -> IHexImage:
    """
    Minimal Intel HEX loader.

    Supports record types:
    - 00: data
    - 01: EOF
    - 04: extended linear address
    Ignores:
    - 02, 03, 05 (not expected for these images)
    """
    memory: Dict[int, int] = {}
    ext_linear = 0
    saw_eof = False

    with open(filename, "r", encoding="utf-8", errors="replace") as f:
        for lineno, raw_line in enumerate(f, start=1):
            line = raw_line.strip()
            if not line:
                continue
            if not line.startswith(":"):
                raise IHexError(f"{filename}:{lineno}: Line does not start with ':'")

            # :LLAAAATT[DD...]CC
            if len(line) < 11:
                raise IHexError(f"{filename}:{lineno}: Line too short")

            ll = _from_hex_byte(line[1:3])
            addr = int(line[3:7], 16)
            rectype = _from_hex_byte(line[7:9])
            data_hex = line[9 : 9 + ll * 2]
            checksum = _from_hex_byte(line[9 + ll * 2 : 9 + ll * 2 + 2])

            # Basic checksum validation (2's complement of sum of bytes)
            bytes_for_sum: List[int] = [ll, (addr >> 8) & 0xFF, addr & 0xFF, rectype]
            bytes_for_sum.extend(_from_hex_byte(data_hex[i : i + 2]) for i in range(0, len(data_hex), 2))
            calc = ((-sum(bytes_for_sum)) & 0xFF)
            if calc != checksum:
                raise IHexError(f"{filename}:{lineno}: Bad checksum (got 0x{checksum:02X}, expected 0x{calc:02X})")

            if rectype == 0x00:
                base = (ext_linear << 16) + addr
                for i in range(ll):
                    b = _from_hex_byte(data_hex[i * 2 : i * 2 + 2])
                    memory[base + i] = b
            elif rectype == 0x01:
                saw_eof = True
                break
            elif rectype == 0x04:
                if ll != 2:
                    raise IHexError(f"{filename}:{lineno}: Bad ELA record length: {ll}")
                ext_linear = int(data_hex, 16)
            else:
                # Ignore other records (start segment/linear, extended segment)
                continue

    if not memory:
        return IHexImage(start_address=0, data=[])
    if not saw_eof:
        # Not fatal in practice, but helps catch truncated files.
        raise IHexError(f"{filename}: Missing EOF record")

    min_addr = min(memory.keys())
    max_addr = max(memory.keys())
    data = [0xFF] * (max_addr - min_addr + 1)
    for a, b in memory.items():
        data[a - min_addr] = b
    return IHexImage(start_address=min_addr, data=data)

