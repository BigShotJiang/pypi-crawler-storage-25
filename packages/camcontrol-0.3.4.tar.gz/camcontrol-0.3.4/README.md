# camcontrol

Windows-first Python CLI + library for communicating with Camlock USB serial devices (CH340), including PICO Hub-style line commands.

## Install

```powershell
pip install camcontrol
```

## CLI usage

```powershell
camcontrol list
camcontrol connect
camcontrol send STATE
camcontrol send UNLOCK
camcontrol send TEMP
camcontrol temp
camcontrol interactive
camcontrol --com COM15 reflash firmware.hex
camcontrol --com COM15 acs200 send state
camcontrol --com COM15 acs200 send unlock,3
```

## ACS-200 (CAMCONTROL hub) quickstart

ACS-200 uses different serial settings and command syntax than the 115200-baud lock devices:

- Serial settings: **9600 8N1**, newline terminator **CR** (`\r`).
- Commands are typically lowercase and comma-separated (examples below).

Examples:

```powershell
camcontrol --com COM15 acs200 state
camcontrol --com COM15 acs200 locks
camcontrol --com COM15 acs200 unlock 3
camcontrol --com COM15 acs200 hold on
camcontrol --com COM15 acs200 unlock all
camcontrol --com COM15 acs200 output 1 on
camcontrol --com COM15 acs200 outputs off
camcontrol --com COM15 acs200 temp 10
camcontrol --com COM15 acs200 interactive
```

Raw passthrough is still available if you want to send exactly what the firmware expects:

```powershell
camcontrol --com COM15 acs200 send get_state
camcontrol --com COM15 acs200 send set_relock_duration,10
```

Optional multi-channel flag (reserved for ACS200-style devices):

```powershell
camcontrol send STATE --port 3
```

## Python usage

```python
from camcontrol import SerialManager
from camcontrol.serial_manager import SerialConfig

with SerialManager(SerialConfig(port="COM15")) as mgr:
    print(mgr.send_and_read_response("STATE"))
```

## Example app

Run the included example script:

```powershell
python examples\basic_demo.py
python examples\basic_demo.py --com COM15
```

## Notes

- Commands are sent as complete lines terminated by `\n` (never character-by-character).
- Responses are read as line-based text; multi-line responses are collected until a blank line or timeout.
- Serial speed is fixed at **115200 baud**.
- Package name on PyPI and the import/package name are both `camcontrol`.
- For development installs from source, you can use `pip install -e .` from the project folder.
- `reflash` is standalone (no extra Python deps beyond `pyserial`) and targets the Camlock UPDI setup used by the reference flashing app.
- `reflash` vendors a subset of the `pyupdi` project (MIT); see `camcontrol/_pyupdi/LICENSE` in the source distribution.

## Linux quickstart

- Install: `pip install camcontrol`
- List ports: `camcontrol list`
- If you get `PermissionError` opening `/dev/ttyUSB0`, add your user to the `dialout` group and re-login:
  - `sudo usermod -a -G dialout $USER`
