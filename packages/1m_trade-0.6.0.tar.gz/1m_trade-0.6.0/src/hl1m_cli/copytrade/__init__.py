"""
copytrade module package (Hyperliquid copy-trading).

Future feature modules can live under `hl1m_cli.copytrade`.
"""

__all__: list[str] = []

