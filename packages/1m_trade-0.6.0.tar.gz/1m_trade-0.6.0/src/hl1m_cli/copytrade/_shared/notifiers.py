from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class StdoutNotifier:
    def send(self, message: str, *, data: Any | None = None) -> None:
        if data is None:
            print(message, flush=True)
            return
        print(json.dumps({"message": message, "data": data}, ensure_ascii=False), flush=True)


def send_openclaw_message(target: str, message: str) -> None:
    """
    Send notification via:
      openclaw message send --target xxxx --message "..."

    This is a best-effort helper: any failure is swallowed (no stdout/stderr spam).
    """
    cmd = ["openclaw", "message", "send", "--target", str(target), "--message", str(message)]
    try:
        print(f"Sending openclaw message: {cmd}")
        subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

