from __future__ import annotations

from typing import Final


DEFAULT_HTTP_BASE_URL: Final[str] = "https://api.hyperliquid.xyz"
DEFAULT_WS_URL: Final[str] = "wss://api.hyperliquid.xyz/ws"

# Hyperliquid constraint: minimum notional per order (USD)
MIN_ORDER_NOTIONAL_USD: Final[float] = 15.0

