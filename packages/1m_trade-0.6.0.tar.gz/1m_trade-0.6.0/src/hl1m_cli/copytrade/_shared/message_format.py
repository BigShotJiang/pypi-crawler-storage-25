from __future__ import annotations

import json
from typing import Any


def normalize_language(language: str | None) -> str:
    if not language:
        return "zh"
    s = str(language).strip().lower()
    if s in ("en", "english"):
        return "en"
    return "zh"


def _json_compact(v: Any) -> str:
    try:
        return json.dumps(v, ensure_ascii=False, separators=(",", ":"), default=str)
    except Exception:
        return str(v)


def _block(title: str, lines: list[str]) -> str:
    return "\n".join([title, *lines])


def format_copy_plan_message(
    *,
    language: str,
    leader: str,
    coin: str,
    side: str,
    px: Any,
    sz: Any,
    notional_usd: float,
    leader_leverage: float | None = None,
    max_leverage_applied: float | None = None,
) -> str:
    if language == "en":
        title = "[copy][EXEC][ORDER]"
        return _block(
            title,
            [
                f"leader: {leader}",
                f"coin: {coin}",
                f"side: {side}",
                f"px: {px}",
                f"sz: {sz}",
                f"notional_usd: {notional_usd:.2f} USDC",
                *(
                    [f"leader_leverage: {leader_leverage}", f"max_leverage_applied: {max_leverage_applied}"]
                    if leader_leverage is not None and max_leverage_applied is not None
                    else ([f"leader_leverage: {leader_leverage}"] if leader_leverage is not None else [])
                ),
            ],
        )

    # zh
    title = "[copy][执行][订单]"
    lines: list[str] = [
        f"跟随者: {leader}",
        f"币种: {coin}",
        f"方向: {side}",
        f"价格: {px}",
        f"数量: {sz}",
        f"名义价值(USDC): {notional_usd:.2f}",
    ]
    if leader_leverage is not None:
        lines.append(f"leader杠杆: {leader_leverage}")
    if max_leverage_applied is not None:
        lines.append(f"最大杠杆(已应用): {max_leverage_applied}")
    return _block(title, lines)


def format_copy_exec_open_message(*, language: str, coin: str, is_buy: bool, sz: Any, res: Any) -> str:
    if language == "en":
        title = "[copy][EXEC][OPEN]"
        return _block(
            title,
            [
                f"coin: {coin}",
                f"is_buy: {is_buy}",
                f"sz: {sz}",
                f"res: {_json_compact(res)}",
            ],
        )
    return _block(
        "[copy][执行][开仓]",
        [
            f"币种: {coin}",
            f"是否买入: {is_buy}",
            f"数量: {sz}",
            f"结果: {_json_compact(res)}",
        ],
    )


def format_copy_exec_close_message(*, language: str, coin: str, sz: Any, res: Any) -> str:
    if language == "en":
        title = "[copy][EXEC][CLOSE]"
        return _block(title, [f"coin: {coin}", f"sz: {sz}", f"res: {_json_compact(res)}"])
    return _block(
        "[copy][执行][平仓]",
        [f"币种: {coin}", f"数量: {sz}", f"结果: {_json_compact(res)}"],
    )


def format_copy_exec_error_message(*, language: str, coin: str, leader: str, err: Any) -> str:
    if language == "en":
        title = "[copy][EXEC][ERROR]"
        return _block(title, [f"coin: {coin}", f"leader: {leader}", f"err: {err}"])
    return _block("[copy][执行][错误]", [f"币种: {coin}", f"跟随者: {leader}", f"错误: {err}"])


def format_monitor_fill_message(
    *,
    language: str,
    user: str,
    coin: str,
    side: str,
    px: Any,
    sz: Any,
    notional_usd: float,
    time_ms: int,
) -> str:
    if language == "en":
        title = "[monitor][FILL]"
        return _block(
            title,
            [
                f"user: {user}",
                f"coin: {coin}",
                f"side: {side}",
                f"px: {px}",
                f"sz: {sz}",
                f"notional_usd: {notional_usd:.2f} USDC",
                f"time_ms: {time_ms}",
            ],
        )
    return _block(
        "[monitor][成交]",
        [
            f"用户: {user}",
            f"币种: {coin}",
            f"方向: {side}",
            f"价格: {px}",
            f"数量: {sz}",
            f"名义价值(USDC): {notional_usd:.2f}",
            f"时间(ms): {time_ms}",
        ],
    )


def format_monitor_user_event_message(*, language: str, user: str, kind: str) -> str:
    if language == "en":
        return _block("[monitor][USER_EVENT]", [f"user: {user}", f"kind: {kind}"])
    return _block("[monitor][用户事件]", [f"用户: {user}", f"类型: {kind}"])


def format_monitor_ledger_message(
    *,
    language: str,
    action: str,
    amount_usdc: float,
    type_name: str,
    src_user: str,
    destination: str,
    time_ms: Any,
) -> str:
    if language == "en":
        return _block(
            "[monitor][LEDGER]",
            [
                f"action: {action}",
                f"amount_usdc: {amount_usdc:.6f} USDC",
                f"type: {type_name}",
                f"src_user: {src_user}",
                f"destination: {destination}",
                f"time_ms: {time_ms}",
            ],
        )

    zh_action = {"deposit": "入金", "withdraw": "出金"}.get(action, action)
    return _block(
        "[monitor][资金流水]",
        [
            f"动作: {zh_action}",
            f"金额(USDC): {amount_usdc:.6f}",
            f"类型: {type_name}",
            f"来源用户: {src_user}",
            f"目标用户: {destination}",
            f"时间(ms): {time_ms}",
        ],
    )


def format_common_status(language: str, msg: str) -> str:
    if language == "en":
        return f"[status] {msg}"
    return f"[状态] {msg}"

