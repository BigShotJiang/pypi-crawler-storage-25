"""
BlockBeats Pro news & market-data module.

Commands are exposed via `hl1m news ...`.
"""

__all__: list[str] = []

