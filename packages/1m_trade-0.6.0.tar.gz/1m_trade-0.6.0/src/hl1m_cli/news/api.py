from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Any

from .client import api_get


NEWSFLASH_TYPES = [
    "all",
    "important",
    "original",
    "first",
    "onchain",
    "financing",
    "prediction",
    "meme",
    "ai",
]

ARTICLE_TYPES = [
    "all",
    "important",
    "original",
]

DATASETS = [
    "btc_etf",
    "daily_tx",
    "ibit_fbtc",
    "stablecoin_marketcap",
    "compliant_total",
    "us10y",
    "dxy",
    "m2_supply",
    "bitfinex_long",
    "contract",
    "bottom_top_indicator",
    "top10_netflow",
    "exchanges",
]


def get_newsflash(*, kind: str = "all", page: int = 1, size: int = 10, lang: str = "cn") -> Any:
    k = (kind or "all").strip().lower()
    path = "/v1/newsflash" if k in ("all", "") else f"/v1/newsflash/{k}"
    return api_get(path, params={"page": page, "size": size, "lang": lang})


def get_article(*, kind: str = "all", page: int = 1, size: int = 10, lang: str = "cn") -> Any:
    k = (kind or "all").strip().lower()
    path = "/v1/article" if k in ("all", "") else f"/v1/article/{k}"
    return api_get(path, params={"page": page, "size": size, "lang": lang})


def search(*, keyword: str, size: int = 10, lang: str = "cn") -> Any:
    return api_get("/v1/search", params={"name": keyword, "size": size, "lang": lang})


def get_data(dataset: str, *, params: dict[str, Any] | None = None) -> Any:
    name = str(dataset or "").strip()
    if not name:
        raise ValueError("dataset is empty")
    return api_get(f"/v1/data/{name}", params=params or {})


def market_snapshot(*, lang: str = "cn") -> dict[str, Any]:
    """
    Scenario 1: bottom_top_indicator + important newsflash(size=5) + btc_etf + daily_tx
    """

    with ThreadPoolExecutor(max_workers=4) as ex:
        f1 = ex.submit(get_data, "bottom_top_indicator")
        f2 = ex.submit(get_newsflash, kind="important", size=5, lang=lang)
        f3 = ex.submit(get_data, "btc_etf")
        f4 = ex.submit(get_data, "daily_tx")
        return {
            "bottom_top_indicator": f1.result(),
            "important_newsflash": f2.result(),
            "btc_etf": f3.result(),
            "daily_tx": f4.result(),
        }


def fund_flow_analysis(*, network: str = "solana") -> dict[str, Any]:
    """
    Scenario 2: top10_netflow(network) + stablecoin_marketcap + btc_etf
    """

    with ThreadPoolExecutor(max_workers=3) as ex:
        f1 = ex.submit(get_data, "top10_netflow", params={"network": network})
        f2 = ex.submit(get_data, "stablecoin_marketcap")
        f3 = ex.submit(get_data, "btc_etf")
        return {"top10_netflow": f1.result(), "stablecoin_marketcap": f2.result(), "btc_etf": f3.result()}


def macro_environment(*, timeframe: str = "1M") -> dict[str, Any]:
    """
    Scenario 3: us10y(type) + dxy(type) + compliant_total
    """

    with ThreadPoolExecutor(max_workers=3) as ex:
        f1 = ex.submit(get_data, "us10y", params={"type": timeframe})
        f2 = ex.submit(get_data, "dxy", params={"type": timeframe})
        f3 = ex.submit(get_data, "compliant_total")
        return {"us10y": f1.result(), "dxy": f2.result(), "compliant_total": f3.result()}


def derivatives_market(*, data_type: str = "1D", exchanges_size: int = 10) -> dict[str, Any]:
    """
    Scenario 4: contract(dataType) + exchanges(size) + bitfinex_long(symbol=btc,type=1D)
    """

    with ThreadPoolExecutor(max_workers=3) as ex:
        f1 = ex.submit(get_data, "contract", params={"dataType": data_type})
        f2 = ex.submit(get_data, "exchanges", params={"size": exchanges_size})
        f3 = ex.submit(get_data, "bitfinex_long", params={"symbol": "btc", "type": "1D"})
        return {"contract": f1.result(), "exchanges": f2.result(), "bitfinex_long": f3.result()}


__all__ = [
    "ARTICLE_TYPES",
    "DATASETS",
    "NEWSFLASH_TYPES",
    "derivatives_market",
    "fund_flow_analysis",
    "get_article",
    "get_data",
    "get_newsflash",
    "macro_environment",
    "market_snapshot",
    "search",
]

