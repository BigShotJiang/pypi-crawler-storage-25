"""
Hyperliquid trading / query / wallet module (`trade`).

Put trading/query/wallet implementation here; `hl1m_cli.cli` is the unified CLI entry.
"""

__all__: list[str] = []

