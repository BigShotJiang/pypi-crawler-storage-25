"""
trade: package-wide static configuration.

Note: keep values inside this package so they are versioned and included when publishing to PyPI.
"""

# Hyperliquid referrer code
REFERRER_CODE = "HYPERCLAW"

#
# Note: OpenClaw state path + encryption env var names are defined in `hl1m_cli.shared.secrets`.
# Keep `trade.constants` focused on trade-specific config only.

