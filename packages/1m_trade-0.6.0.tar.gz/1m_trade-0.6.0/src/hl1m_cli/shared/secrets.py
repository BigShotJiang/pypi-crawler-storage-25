import base64
import os
import secrets as py_secrets
from pathlib import Path
from typing import Dict

# OpenClaw state (shared)
OPENCLAW_STATE_SUBDIR = ".1m-trade"
OPENCLAW_ENV_FILENAME = ".env"

# Encrypted private key env var names (at-rest encryption)
PRIVATE_KEY_ENC_KEY = "HYPERLIQUID_PRIVATE_KEY_ENC"
PRIVATE_KEY_ENC_PASSWORD_KEY = "HYPERLIQUID_PK_ENC_PASSWORD"


def get_openclaw_state_dir() -> Path:
    """
    State directory: always under ".1m-trade"
    - If OPENCLAW_STATE_DIR is set: $OPENCLAW_STATE_DIR/.1m-trade
    - Otherwise: ~/.openclaw/.1m-trade
    """

    base_state_dir = os.environ.get("OPENCLAW_STATE_DIR")
    if base_state_dir:
        return (Path(base_state_dir).expanduser().resolve() / OPENCLAW_STATE_SUBDIR).resolve()

    return (Path(os.path.expanduser("~")) / ".openclaw" / OPENCLAW_STATE_SUBDIR).resolve()


def get_env_path() -> Path:
    return get_openclaw_state_dir() / OPENCLAW_ENV_FILENAME


def init_env_file() -> Dict[str, str]:
    """
    Ensure state directory exists and ".env" exists, then parse it as key=value lines.
    """

    env_path = get_env_path()
    env_path.parent.mkdir(parents=True, exist_ok=True)
    if not env_path.exists():
        env_path.write_text("", encoding="utf-8")

    env: Dict[str, str] = {}
    content = env_path.read_text(encoding="utf-8")
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        idx = line.find("=")
        if idx == -1:
            continue
        key = line[:idx].strip()
        value = line[idx + 1 :].strip()
        env[key] = value
    return env


def set_env_file(env: Dict[str, str]) -> None:
    env_path = get_env_path()
    lines = [f"{k}={v}" for k, v in env.items()]
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def encrypt_private_key(plain_pk: str, password: str) -> str:
    """
    AES-256-GCM + scrypt:
    - scrypt: N=16384, r=8, p=1, length=32
    - GCM iv length: 12 bytes
    Payload format:
      v1:<saltB64>:<ivB64>:<ciphertextB64>:<tagB64>
    """

    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # type: ignore
        from cryptography.hazmat.primitives.kdf.scrypt import Scrypt  # type: ignore
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "missing dependency: cryptography (required for encrypt/decrypt private key). "
            "Install it via your project dependencies."
        ) from e

    salt = py_secrets.token_bytes(16)
    kdf = Scrypt(salt=salt, length=32, n=16384, r=8, p=1)
    key = kdf.derive(password.encode("utf-8"))

    iv = py_secrets.token_bytes(12)
    aesgcm = AESGCM(key)
    ct_and_tag = aesgcm.encrypt(iv, plain_pk.encode("utf-8"), None)
    ciphertext, tag = ct_and_tag[:-16], ct_and_tag[-16:]

    return (
        "v1:"
        + base64.b64encode(salt).decode("ascii")
        + ":"
        + base64.b64encode(iv).decode("ascii")
        + ":"
        + base64.b64encode(ciphertext).decode("ascii")
        + ":"
        + base64.b64encode(tag).decode("ascii")
    )


def decrypt_private_key(enc_payload: str, password: str) -> str:
    """
    Inverse of encrypt_private_key, matching the v1 payload format.
    """

    if not enc_payload:
        raise ValueError("Encrypted private key payload is missing.")
    if not password:
        raise ValueError("Encrypted private key password is missing.")

    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # type: ignore
        from cryptography.hazmat.primitives.kdf.scrypt import Scrypt  # type: ignore
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "missing dependency: cryptography (required for encrypt/decrypt private key). "
            "Install it via your project dependencies."
        ) from e

    parts = str(enc_payload).split(":")
    if len(parts) != 5 or parts[0] != "v1":
        raise ValueError("Unsupported encrypted private key format.")

    _, salt_b64, iv_b64, ct_b64, tag_b64 = parts
    salt = base64.b64decode(salt_b64)
    iv = base64.b64decode(iv_b64)
    ciphertext = base64.b64decode(ct_b64)
    tag = base64.b64decode(tag_b64)

    kdf = Scrypt(salt=salt, length=32, n=16384, r=8, p=1)
    key = kdf.derive(password.encode("utf-8"))
    aesgcm = AESGCM(key)
    pt_bytes = aesgcm.decrypt(iv, ciphertext + tag, None)
    return pt_bytes.decode("utf-8")


def resolve_private_key_from_env() -> str:
    """
    Resolve private key from encrypted process environment only:
    - HYPERLIQUID_PRIVATE_KEY_ENC + HYPERLIQUID_PK_ENC_PASSWORD
    """

    enc = (os.environ.get(PRIVATE_KEY_ENC_KEY) or "").strip()
    password = (os.environ.get(PRIVATE_KEY_ENC_PASSWORD_KEY) or "").strip()
    if not enc:
        raise ValueError(f"Missing {PRIVATE_KEY_ENC_KEY}.")
    if not password:
        raise ValueError(f"Missing {PRIVATE_KEY_ENC_PASSWORD_KEY}.")
    return decrypt_private_key(enc, password)


def resolve_plain_private_key_from_env_file(env: Dict[str, str]) -> str:
    enc_payload = (env.get(PRIVATE_KEY_ENC_KEY) or "").strip()
    enc_password = (env.get(PRIVATE_KEY_ENC_PASSWORD_KEY) or "").strip()
    if not enc_payload:
        raise ValueError(f"{PRIVATE_KEY_ENC_KEY} not found")
    if not enc_password:
        raise ValueError(f"{PRIVATE_KEY_ENC_PASSWORD_KEY} not found")
    return decrypt_private_key(enc_payload, enc_password)


def resolve_plain_private_key_from_state_file() -> str:
    """
    Convenience: read OpenClaw state `.env` and decrypt v1 payload.
    """

    env = init_env_file()
    return resolve_plain_private_key_from_env_file(env)


__all__ = [
    "OPENCLAW_STATE_SUBDIR",
    "OPENCLAW_ENV_FILENAME",
    "PRIVATE_KEY_ENC_KEY",
    "PRIVATE_KEY_ENC_PASSWORD_KEY",
    "get_openclaw_state_dir",
    "get_env_path",
    "init_env_file",
    "set_env_file",
    "encrypt_private_key",
    "decrypt_private_key",
    "resolve_private_key_from_env",
    "resolve_plain_private_key_from_env_file",
    "resolve_plain_private_key_from_state_file",
]

