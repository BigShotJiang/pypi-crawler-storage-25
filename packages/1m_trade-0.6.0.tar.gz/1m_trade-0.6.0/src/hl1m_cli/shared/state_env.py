from __future__ import annotations

from pathlib import Path

from .secrets import get_env_path, init_env_file


def load_state_env(*, override: bool = False, verbose: bool = True) -> bool:
    """
    Load the OpenClaw state `.env` file into process environment.

    Path comes from `shared.secrets.get_env_path()`.
    """

    init_env_file()
    env_path: Path = get_env_path()
    try:
        from dotenv import load_dotenv
    except ModuleNotFoundError as e:
        raise ModuleNotFoundError(
            "missing dependency: python-dotenv (required to load state .env). "
            "Install it via your project dependencies."
        ) from e
    success = load_dotenv(env_path, override=override)

    if verbose:
        if success:
            print(f"Loaded OpenClaw env: {env_path}")
        else:
            print(f"Failed to load or empty: {env_path}")

    return bool(success)


__all__ = ["load_state_env"]

