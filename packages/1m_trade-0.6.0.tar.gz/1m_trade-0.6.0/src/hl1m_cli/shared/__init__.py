"""
Shared utilities across feature modules (`trade`, `copytrade`, ...).
"""

__all__: list[str] = []

