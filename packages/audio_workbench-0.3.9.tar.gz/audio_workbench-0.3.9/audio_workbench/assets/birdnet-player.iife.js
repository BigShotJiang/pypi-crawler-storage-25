var BirdNETPlayerModule = (function(exports) {
	Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
	//#region \0rolldown/runtime.js
	var __defProp = Object.defineProperty;
	var __esmMin = (fn, res) => () => (fn && (res = fn(fn = 0)), res);
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	//#endregion
	//#region src/template.js
	/**
	* Default options for the player UI.
	* Every key corresponds to a visible section that can be toggled off.
	*/
	var DEFAULT_OPTIONS = {
		showFileOpen: true,
		showTransport: true,
		showTime: true,
		showVolume: true,
		showViewToggles: true,
		showZoom: true,
		showFFTControls: true,
		showDisplayGain: true,
		showStatusbar: true,
		showOverview: true,
		viewMode: "both",
		transportStyle: "default",
		transportOverlay: false,
		showWaveformTimeline: true,
		compactToolbar: "auto",
		followGuardLeftRatio: .35,
		followGuardRightRatio: .65,
		followTargetRatio: .5,
		followCatchupDurationMs: 240,
		followCatchupSeekDurationMs: 360,
		smoothLerp: .18,
		smoothSeekLerp: .08,
		smoothMinStepRatio: .03,
		smoothSeekMinStepRatio: .008,
		smoothSeekFocusMs: 1400
	};
	/**
	* @param {Partial<typeof DEFAULT_OPTIONS>} opts
	*/
	function createPlayerHTML(opts = {}) {
		const o = {
			...DEFAULT_OPTIONS,
			...opts
		};
		const hide = (flag) => flag ? "" : " style=\"display:none\"";
		const viewMode = [
			"both",
			"waveform",
			"spectrogram"
		].includes(o.viewMode) ? o.viewMode : "both";
		const transportStyle = o.transportStyle === "hero" ? "hero" : "default";
		const compactToolbar = [
			"auto",
			"on",
			"off"
		].includes(o.compactToolbar) ? o.compactToolbar : "auto";
		return `<div class="${[
			"daw-shell",
			`view-mode-${viewMode}`,
			`transport-style-${transportStyle}`,
			`compact-toolbar-${compactToolbar}`,
			o.transportOverlay ? "transport-overlay" : ""
		].join(" ")}">

    <!-- ═══ Top Toolbar ═══ -->
    <div class="toolbar" data-aw="toolbarRoot">
      <div class="toolbar-primary">
        <button class="toolbar-btn file-btn" data-aw="openFileBtn" title="Load audio file"${hide(o.showFileOpen)}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 15v4a2 2 0 002 2h14a2 2 0 002-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            Open
        </button>
        <input type="file" data-aw="audioFile" accept="audio/*" hidden>

        <div class="toolbar-sep"${hide(o.showFileOpen)}></div>

        <!-- Transport -->
        <div class="transport"${hide(o.showTransport)}>
            <button class="transport-btn" data-aw="jumpStartBtn" disabled title="Jump to start (Home)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="5" width="3" height="14"/><polygon points="20 5 10 12 20 19"/></svg>
            </button>
            <button class="transport-btn" data-aw="backwardBtn" disabled title="-5s (J)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="19 5 9 12 19 19"/><polygon points="12 5 2 12 12 19"/></svg>
            </button>
            <button class="transport-btn play-btn" data-aw="playPauseBtn" disabled title="Play / Pause (Space)">
                <svg class="icon-play" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 3 20 12 6 21"/></svg>
            </button>
            <button class="transport-btn" data-aw="stopBtn" disabled title="Stop">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16" rx="2"/></svg>
            </button>
            <button class="transport-btn" data-aw="forwardBtn" disabled title="+5s (L)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 5 15 12 5 19"/><polygon points="12 5 22 12 12 19"/></svg>
            </button>
            <button class="transport-btn" data-aw="jumpEndBtn" disabled title="Jump to end (End)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="4 5 14 12 4 19"/><rect x="18" y="5" width="3" height="14"/></svg>
            </button>
        </div>

        <!-- Time -->
        <div class="time-display" data-aw="timeDisplay" role="status" aria-live="polite"${hide(o.showTime)}>
            <span data-aw="currentTime">00:00.0</span><span class="time-sep">/</span><span data-aw="totalTime">00:00.0</span>
        </div>
        <button class="toolbar-btn compact-more-btn" data-aw="compactMoreBtn" aria-expanded="false" title="Show more controls">More</button>
      </div>

      <div class="toolbar-secondary" data-aw="toolbarSecondary">

        <div class="toolbar-sep"${hide(o.showVolume)}></div>

        <!-- Volume -->
        <button class="toolbar-btn icon-btn" data-aw="volumeToggleBtn" title="Mute / Unmute"${hide(o.showVolume)}>
            <svg data-aw="volumeIcon" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <polygon points="6 9 2 9 2 15 6 15 11 19 11 5"/>
                <path data-aw="volumeWaves" d="M15 8.5a4 4 0 010 7M18 5a9 9 0 010 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
        </button>
        <input type="range" data-aw="volumeSlider" class="toolbar-range toolbar-range-sm" min="0" max="100" value="80" title="Volume"${hide(o.showVolume)}>

        <div class="toolbar-sep"${hide(o.showViewToggles)}></div>

        <!-- Toggle tools -->
        <span${hide(o.showViewToggles)}>
            <button class="toolbar-btn toggle-btn active" data-aw="followToggleBtn" disabled title="Toggle Free / Follow / Smooth">Follow</button>
            <button class="toolbar-btn toggle-btn" data-aw="loopToggleBtn" disabled title="Loop">Loop</button>
            <button class="toolbar-btn toggle-btn" data-aw="crosshairToggleBtn" disabled title="Toggle crosshair">Crosshair</button>
            <button class="toolbar-btn" data-aw="fitViewBtn" disabled title="Fit to view">Fit</button>
            <button class="toolbar-btn" data-aw="resetViewBtn" disabled title="Reset zoom">Reset</button>
        </span>

        <div class="toolbar-sep"${hide(o.showZoom)}></div>

        <!-- Zoom -->
        <span${hide(o.showZoom)} class="zoom-controls-row">
            <label class="toolbar-label">H</label>
            <input type="range" data-aw="zoomSlider" class="toolbar-range toolbar-range-zoom" min="20" max="450" value="100" step="5">
            <span class="toolbar-value toolbar-value-sm" data-aw="zoomValue">100 px/s</span>
            <label class="toolbar-label freq-zoom-label">V</label>
            <input type="range" data-aw="freqZoomSlider" class="toolbar-range toolbar-range-zoom" min="0" max="100" value="0" step="1" title="Vertical frequency zoom">
        </span>

        <div class="toolbar-sep"${hide(o.showFFTControls)}></div>

        <!-- Settings toggle (opens side panel) -->
        <button class="toolbar-btn settings-toggle-btn" data-aw="settingsToggleBtn" title="Open settings panel"${hide(o.showFFTControls)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
            Settings
        </button>
      </div>
    </div>

    <!-- ═══ Settings Side-Panel ═══ -->
    <div class="settings-panel" data-aw="settingsPanel">
        <div class="settings-panel-header">
            <span class="settings-panel-title">Settings</span>
            <button class="settings-panel-close" data-aw="settingsPanelClose" title="Close">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>

        <div class="settings-section preset-section">
            <div class="settings-row">
                <label class="settings-label">Preset</label>
                <select data-aw="presetSelect" class="settings-select">
                </select>
                <button class="toolbar-btn mini-btn" data-aw="presetFavBtn" title="Set as default preset" disabled>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </button>
                <button class="toolbar-btn mini-btn" data-aw="presetSaveBtn" title="Save current settings as preset">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.2 3a2 2 0 011.4.6l3.8 3.8a2 2 0 01.6 1.4V19a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2z"/><path d="M17 21v-7a1 1 0 00-1-1H8a1 1 0 00-1 1v7"/><path d="M7 3v4a1 1 0 001 1h7"/></svg>
                </button>
                <button class="toolbar-btn mini-btn" data-aw="presetManageBtn" title="Manage presets">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h18"/><path d="M3 18h18"/><path d="M3 6h18"/></svg>
                </button>
            </div>
            <div class="preset-save-row" data-aw="presetSaveRow" hidden>
                <input type="text" data-aw="presetSaveInput" class="settings-input" placeholder="Preset name…" maxlength="40">
                <button class="toolbar-btn mini-btn pm-confirm" data-aw="presetSaveConfirm" title="Save">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </button>
                <button class="toolbar-btn mini-btn" data-aw="presetSaveCancel" title="Cancel">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            <div class="preset-manager-inline" data-aw="presetManagerPanel" hidden>
                <div class="preset-manager-list" data-aw="presetManagerList"></div>
                <div class="pm-actions">
                    <button class="pm-action-btn" data-aw="presetImportBtn" title="Import presets from JSON">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        Import
                    </button>
                    <button class="pm-action-btn" data-aw="presetExportBtn" title="Export user presets as JSON">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        Export
                    </button>
                    <span class="pm-status" data-aw="presetStatus"></span>
                </div>
            </div>
        </div>

        <div class="settings-section quality-slider-section">
            <h3 class="settings-section-title">Quality</h3>
            <div class="settings-row quality-slider-row">
                <span class="quality-end-label">⚡</span>
                <input type="range" data-aw="qualitySlider" class="settings-range quality-range" min="0" max="4" value="2" step="1" list="qualityStops">
                <span class="quality-end-label">🔬</span>
                <datalist id="qualityStops">
                    <option value="0"></option><option value="1"></option><option value="2"></option><option value="3"></option><option value="4"></option>
                </datalist>
            </div>
            <div class="quality-label-bar">
                <span>Performance</span><span>Balanced</span><span>Quality</span><span>High</span><span>Ultra</span>
            </div>
            <div class="quality-level-display" data-aw="qualityLevelDisplay">Quality</div>
        </div>

        <div class="settings-section">
            <h3 class="settings-section-title">Gain</h3>
            <div class="settings-row">
                <label class="settings-label">Mode</label>
                <select data-aw="gainModeSelect" class="settings-select" title="Auto: percentile-based contrast on each file. Fixed: use saved floor/ceil values.">
                    <option value="auto" selected>Auto</option>
                    <option value="fixed">Fixed</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label">Floor</label>
                <input type="range" data-aw="floorSlider" class="settings-range" min="0" max="100" value="0" title="Spectrogram floor">
            </div>
            <div class="settings-row">
                <label class="settings-label">Ceiling</label>
                <input type="range" data-aw="ceilSlider" class="settings-range" min="0" max="100" value="100" title="Spectrogram ceiling">
            </div>
            <div class="settings-row">
                <button class="toolbar-btn mini-btn" data-aw="autoContrastBtn" disabled title="Auto optimize contrast">Auto Contrast</button>
            </div>
        </div>

        <div class="settings-section">
            <h3 class="settings-section-title">Display</h3>
            <div class="settings-row">
                <label class="settings-label">Max Freq</label>
                <select data-aw="maxFreqModeSelect" class="settings-select" title="Auto: detect from content. Nyquist: full bandwidth. Fixed: use selected value.">
                    <option value="auto" selected>Auto</option>
                    <option value="nyquist">Nyquist</option>
                    <option value="fixed">Fixed</option>
                </select>
                <select data-aw="maxFreqSelect" class="settings-select">
                    <option value="10000" selected>10 kHz</option>
                </select>
                <button class="toolbar-btn mini-btn" data-aw="autoFreqBtn" disabled title="Auto-detect frequency range">AF</button>
            </div>
            <div class="settings-row">
                <label class="settings-label">Color</label>
                <select data-aw="colorSchemeSelect" class="settings-select">
                    <option value="grayscale" selected>B/W</option>
                    <option value="xenocanto">XC</option>
                    <option value="fire">Fire</option>
                    <option value="inferno">Inferno</option>
                    <option value="viridis">Viridis</option>
                    <option value="magma">Magma</option>
                    <option value="plasma">Plasma</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label" title="Median-based spectral noise floor subtraction">
                    <input type="checkbox" data-aw="noiseReductionCheck"> Noise Reduction
                </label>
            </div>
            <div class="settings-row">
                <label class="settings-label" title="Contrast Limited Adaptive Histogram Equalization — enhances local detail">
                    <input type="checkbox" data-aw="claheCheck"> Adaptive Contrast
                </label>
            </div>
        </div>

        <div class="settings-section">
            <h3 class="settings-section-title">DSP</h3>
            <div class="settings-row">
                <label class="settings-label">Frequency</label>
                <select data-aw="scaleSelect" class="settings-select">
                    <option value="mel" selected>Mel</option>
                    <option value="linear">Linear</option>
                    <option value="cqt">CQT</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label">Colour Scale</label>
                <select data-aw="colourScaleSelect" class="settings-select">
                    <option value="dbSquared" selected>dB²</option>
                    <option value="db">dB</option>
                    <option value="linear">Linear</option>
                    <option value="meter">Meter</option>
                    <option value="phase">Phase</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label">Window</label>
                <select data-aw="windowSize" class="settings-select" title="Window Size (samples)">
                    <option value="256">256</option>
                    <option value="512">512</option>
                    <option value="1024" selected>1024</option>
                    <option value="2048">2048</option>
                    <option value="4096">4096</option>
                    <option value="8192">8192</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label">Window Fn</label>
                <select data-aw="windowFunction" class="settings-select" title="Window Function">
                    <option value="hann" selected>Hann</option>
                    <option value="hamming">Hamming</option>
                    <option value="blackman">Blackman</option>
                    <option value="blackmanHarris">Blackman-Harris</option>
                    <option value="kaiser">Kaiser (β=6)</option>
                    <option value="flatTop">Flat Top</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label" title="Time-frequency reassignment sharpens spectral peaks">
                    <input type="checkbox" data-aw="reassignedCheck"> Reassigned
                </label>
            </div>
            <div class="settings-row">
                <label class="settings-label">Overlap</label>
                <select data-aw="overlapSelect" class="settings-select" title="Window Overlap — higher = smoother time axis">
                    <option value="0">None</option>
                    <option value="1">25 %</option>
                    <option value="2" selected>50 %</option>
                    <option value="3">75 %</option>
                    <option value="4">87.5 %</option>
                    <option value="5">93.75 %</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label">Oversampling</label>
                <select data-aw="oversamplingSelect" class="settings-select" title="Zero-pad FFT — higher = finer frequency resolution">
                    <option value="0" selected>1×</option>
                    <option value="1">2×</option>
                    <option value="2">4×</option>
                    <option value="3">8×</option>
                </select>
            </div>
            <div class="settings-row">
                <label class="settings-label">Mel Bins</label>
                <input type="number" data-aw="nMelsInput" class="settings-number" value="160" min="16" max="512" step="16" title="Number of mel bands">
            </div>
        </div>

        <div class="settings-section" data-aw="pcenSection">
            <h3 class="settings-section-title">
                <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
                    <input type="checkbox" data-aw="pcenEnabledCheck" checked>
                    PCEN
                </label>
            </h3>
            <div class="settings-row">
                <label class="settings-label">Gain</label>
                <input type="number" data-aw="pcenGainInput" class="settings-number" value="0.8" min="0" max="2" step="0.05">
            </div>
            <div class="settings-row">
                <label class="settings-label">Bias</label>
                <input type="number" data-aw="pcenBiasInput" class="settings-number" value="0.01" min="0" max="1" step="0.005">
            </div>
            <div class="settings-row">
                <label class="settings-label">Root</label>
                <input type="number" data-aw="pcenRootInput" class="settings-number" value="4.0" min="1" max="10" step="0.5">
            </div>
            <div class="settings-row">
                <label class="settings-label">Smoothing</label>
                <input type="number" data-aw="pcenSmoothingInput" class="settings-number" value="0.025" min="0" max="0.5" step="0.005">
            </div>
        </div>
    </div>

    <!-- ═══ Main Content ═══ -->
    <div class="views-panel">
        <!-- Waveform -->
        <div class="waveform-container" data-aw="waveformContainer">
            <div class="time-aligned-row">
                <div class="axis-spacer">
                    <div class="amplitude-labels" data-aw="amplitudeLabels"></div>
                </div>
                <div class="time-pane">
                    <div class="waveform-wrapper" data-aw="waveformWrapper">
                        <div class="waveform-content" data-aw="waveformContent">
                            <canvas data-aw="amplitudeCanvas"></canvas>
                            <canvas data-aw="waveformTimelineCanvas"></canvas>
                        </div>
                        <div class="playhead playhead-secondary" data-aw="waveformPlayhead"></div>
                    </div>
                </div>
            </div>
            <div data-aw="audioEngineHost" style="position:absolute;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none;"></div>
        </div>

        <!-- Split handle -->
        <div class="view-split-handle" data-aw="viewSplitHandle" title="Adjust amplitude/spectrogram ratio"></div>

        <!-- Spectrogram -->
        <div class="spectrogram-container" data-aw="spectrogramContainer">
            <div class="time-aligned-row">
                <div class="axis-spacer freq-axis-spacer" data-aw="freqAxisSpacer">
                    <div class="frequency-labels" data-aw="freqLabels"></div>
                    <button class="freq-zoom-reset-btn" data-aw="freqZoomResetBtn" hidden title="Reset vertical zoom (Shift+DblClick)">⟷</button>
                </div>
                <div class="time-pane">
                    <div class="freq-scrollbar" data-aw="freqScrollbar" hidden>
                        <div class="freq-scrollbar-thumb" data-aw="freqScrollbarThumb"></div>
                    </div>
                    <div class="canvas-wrapper" data-aw="canvasWrapper"
                         role="slider"
                         aria-label="Playback position"
                         aria-valuemin="0"
                         aria-valuemax="0"
                         aria-valuenow="0"
                         aria-valuetext="00:00.0 of 00:00.0"
                         tabindex="0">
                        <canvas data-aw="spectrogramCanvas"></canvas>
                        <canvas class="crosshair-overlay" data-aw="crosshairCanvas"></canvas>
                        <div class="crosshair-readout" data-aw="crosshairReadout"></div>
                        <div class="playhead" data-aw="playhead"></div>
                        <div class="recomputing-overlay" data-aw="recomputingOverlay" aria-live="polite" hidden>
                            <span class="recomputing-spinner"></span>
                            <span>Computing…</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="spectrogram-resize-handle" data-aw="spectrogramResizeHandle" title="Adjust spectrogram height"></div>
        </div>

        <!-- Overview -->
        <div class="overview-container" data-aw="overviewContainer"${hide(o.showOverview)}>
            <canvas data-aw="overviewCanvas"></canvas>
            <div class="overview-window" data-aw="overviewWindow">
                <div class="handle left" data-aw="overviewHandleLeft"></div>
                <div class="handle right" data-aw="overviewHandleRight"></div>
            </div>
        </div>
        <div class="overview-label-tracks" data-aw="overviewLabelTracks"${hide(o.showOverview)}></div>
    </div>

    <!-- ═══ Status Bar ═══ -->
    <div class="statusbar"${hide(o.showStatusbar)}>
        <div class="statusbar-section" data-aw="fileInfo">
            <span class="statusbar-label">No file</span>
        </div>
        <div class="statusbar-section">
            <span class="statusbar-label" data-aw="sampleRateInfo"></span>
        </div>
        <div class="statusbar-spacer"></div>
        <div class="statusbar-section">
            <span data-aw="viewRange"></span>
        </div>
        <div class="statusbar-section">
            <span data-aw="playState">Idle</span>
        </div>
    </div>
</div>`;
	}
	//#endregion
	//#region src/constants.js
	var DEFAULT_SAMPLE_RATE = 32e3;
	var SEEK_FINE_SEC = .5;
	var MAX_BASE_SPECTROGRAM_WIDTH = 24e3;
	var MIN_WINDOW_NORM = .02;
	var PERCH_PCEN_GAIN = .8;
	var PERCH_PCEN_BIAS = .01;
	var PERCH_PCEN_SMOOTHING = .025;
	function windowHopFromOverlap(windowSize, overlapLevel) {
		if (overlapLevel <= 0) return windowSize;
		if (overlapLevel === 1) return windowSize * 3 >> 2;
		return windowSize >> overlapLevel - 1;
	}
	function fftSizeFromOversampling(windowSize, oversamplingLevel) {
		return windowSize << oversamplingLevel;
	}
	var DSP_PROFILES = {
		perch: {
			scale: "mel",
			windowSize: 1024,
			overlapLevel: 2,
			oversamplingLevel: 1,
			nMels: 160,
			frameRate: 100,
			usePcen: true,
			pcenGain: PERCH_PCEN_GAIN,
			pcenBias: PERCH_PCEN_BIAS,
			pcenRoot: 4,
			pcenSmoothing: PERCH_PCEN_SMOOTHING,
			windowFunction: "hann",
			colorScheme: "grayscale",
			reassigned: false,
			maxFreqMode: "nyquist"
		},
		classic: {
			scale: "linear",
			windowSize: 2048,
			overlapLevel: 2,
			oversamplingLevel: 0,
			nMels: 160,
			frameRate: 100,
			usePcen: false,
			pcenGain: 0,
			pcenBias: 0,
			pcenRoot: 1,
			pcenSmoothing: 0,
			windowFunction: "hann",
			colorScheme: "xenocanto",
			reassigned: false,
			maxFreqMode: "nyquist"
		},
		birder: {
			scale: "linear",
			colourScale: "dbSquared",
			windowSize: 2048,
			overlapLevel: 4,
			oversamplingLevel: 0,
			nMels: 200,
			usePcen: true,
			pcenGain: .8,
			pcenBias: .01,
			pcenRoot: 4,
			pcenSmoothing: .025,
			windowFunction: "blackmanHarris",
			colorScheme: "inferno",
			reassigned: false,
			noiseReduction: false,
			clahe: true,
			gainMode: "fixed",
			gainFloor: 49,
			gainCeil: 100,
			maxFreqMode: "nyquist"
		}
	};
	var CQT_FMIN = 32.7;
	var QUALITY_LEVELS = [
		{
			label: "Performance",
			windowSize: 256,
			overlapLevel: 1,
			oversamplingLevel: 0,
			nMels: 80
		},
		{
			label: "Balanced",
			windowSize: 512,
			overlapLevel: 2,
			oversamplingLevel: 0,
			nMels: 128
		},
		{
			label: "Quality",
			windowSize: 1024,
			overlapLevel: 2,
			oversamplingLevel: 1,
			nMels: 160
		},
		{
			label: "High",
			windowSize: 2048,
			overlapLevel: 3,
			oversamplingLevel: 1,
			nMels: 200
		},
		{
			label: "Ultra",
			windowSize: 4096,
			overlapLevel: 3,
			oversamplingLevel: 2,
			nMels: 256
		}
	];
	//#endregion
	//#region src/utils.js
	/**
	* Clamp `value` to the range [min, max].
	* @param {number} value
	* @param {number} min
	* @param {number} max
	* @returns {number}
	*/
	function clamp(value, min, max) {
		return Math.max(min, Math.min(max, value));
	}
	/**
	* Parse `value` as a finite number, clamp to [min, max], or return `fallback`.
	* @param {*} value
	* @param {number} min
	* @param {number} max
	* @param {number} fallback
	* @returns {number}
	*/
	function clampNumber(value, min, max, fallback) {
		const n = Number(value);
		if (!Number.isFinite(n)) return fallback;
		return Math.max(min, Math.min(max, n));
	}
	function formatTime(seconds) {
		const mins = Math.floor(seconds / 60);
		const secs = (seconds % 60).toFixed(1);
		return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(4, "0")}`;
	}
	function formatSecondsShort(seconds) {
		return `${seconds.toFixed(2)}s`;
	}
	function isTypingContext(target) {
		if (!target || !target.tagName) return false;
		return target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable;
	}
	function getTimeGridSteps(pixelsPerSecond) {
		const majorStep = pixelsPerSecond >= 320 ? .5 : pixelsPerSecond >= 180 ? 1 : pixelsPerSecond >= 90 ? 2 : pixelsPerSecond >= 45 ? 5 : 10;
		return {
			majorStep,
			minorStep: majorStep / 2
		};
	}
	function escapeHtml(value) {
		return String(value ?? "").split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;").split("\"").join("&quot;").split("'").join("&#39;");
	}
	//#endregion
	//#region src/gestures.js
	function distance(a, b) {
		const dx = a.clientX - b.clientX;
		const dy = a.clientY - b.clientY;
		return Math.hypot(dx, dy);
	}
	function midpoint(a, b) {
		return {
			x: (a.clientX + b.clientX) * .5,
			y: (a.clientY + b.clientY) * .5
		};
	}
	var GestureRecognizer = class {
		constructor(element) {
			this.element = element;
			this.handlers = /* @__PURE__ */ new Map();
			this.cleanups = [];
			this.lastTapTime = 0;
			this.lastTapX = 0;
			this.lastTapY = 0;
			this.touchMode = null;
			this.swipeStartX = 0;
			this.swipeStartY = 0;
			this.swipeLastX = 0;
			this.swipeLastY = 0;
			this.lastPinchDistance = 0;
			this.lastPinchCenter = null;
			this._bind();
		}
		on(event, callback) {
			const arr = this.handlers.get(event) || [];
			arr.push(callback);
			this.handlers.set(event, arr);
			return () => this.off(event, callback);
		}
		off(event, callback) {
			const arr = this.handlers.get(event);
			if (!arr) return;
			this.handlers.set(event, arr.filter((cb) => cb !== callback));
		}
		emit(event, detail) {
			const arr = this.handlers.get(event);
			if (!arr) return;
			for (const cb of arr) cb(detail);
		}
		dispose() {
			for (const cleanup of this.cleanups) cleanup();
			this.cleanups.length = 0;
			this.handlers.clear();
		}
		_bind() {
			const on = (name, fn, options = { passive: false }) => {
				this.element.addEventListener(name, fn, options);
				this.cleanups.push(() => this.element.removeEventListener(name, fn, options));
			};
			on("touchstart", (e) => this._onTouchStart(e));
			on("touchmove", (e) => this._onTouchMove(e));
			on("touchend", (e) => this._onTouchEnd(e));
			on("touchcancel", () => this._reset());
		}
		_onTouchStart(e) {
			if (e.touches.length === 1) {
				const t = e.touches[0];
				this.touchMode = "swipe";
				this.swipeStartX = t.clientX;
				this.swipeStartY = t.clientY;
				this.swipeLastX = t.clientX;
				this.swipeLastY = t.clientY;
				return;
			}
			if (e.touches.length >= 2) {
				const a = e.touches[0];
				const b = e.touches[1];
				this.touchMode = "pinch";
				this.lastPinchDistance = distance(a, b);
				this.lastPinchCenter = midpoint(a, b);
				e.preventDefault();
			}
		}
		_onTouchMove(e) {
			if (this.touchMode === "pinch" && e.touches.length >= 2) {
				const a = e.touches[0];
				const b = e.touches[1];
				const d = Math.max(1, distance(a, b));
				const center = midpoint(a, b);
				const scale = d / Math.max(1, this.lastPinchDistance);
				this.lastPinchDistance = d;
				this.lastPinchCenter = center;
				this.emit("pinch", {
					scale,
					centerX: center.x,
					centerY: center.y
				});
				e.preventDefault();
				return;
			}
			if (this.touchMode === "swipe" && e.touches.length === 1) {
				this.swipeLastX = e.touches[0].clientX;
				this.swipeLastY = e.touches[0].clientY;
			}
		}
		_onTouchEnd(e) {
			if (this.touchMode === "pinch") {
				if (e.touches.length < 2) this._reset();
				return;
			}
			if (this.touchMode === "swipe" && e.touches.length === 0) {
				const dx = this.swipeLastX - this.swipeStartX;
				const dy = Math.abs(this.swipeLastY - this.swipeStartY);
				if (Math.abs(dx) > 24 && dy < 48) this.emit("swipe", { dx });
				else {
					const now = performance.now();
					const withinTime = now - this.lastTapTime < 280;
					const nearLast = Math.hypot(this.swipeStartX - this.lastTapX, this.swipeStartY - this.lastTapY) < 24;
					if (withinTime && nearLast) {
						this.emit("doubletap", {
							x: this.swipeStartX,
							y: this.swipeStartY
						});
						this.lastTapTime = 0;
					} else {
						this.lastTapTime = now;
						this.lastTapX = this.swipeStartX;
						this.lastTapY = this.swipeStartY;
					}
				}
			}
			this._reset();
		}
		_reset() {
			this.touchMode = null;
			this.swipeStartX = 0;
			this.swipeStartY = 0;
			this.swipeLastX = 0;
			this.swipeLastY = 0;
			this.lastPinchDistance = 0;
			this.lastPinchCenter = null;
		}
	};
	//#endregion
	//#region src/transportState.js
	var TRANSPORT_STATE_LABELS = {
		idle: "Idle",
		loading: "Loading",
		ready: "Ready",
		rendering: "Rendering...",
		playing: "Playing",
		playing_loop: "Playing (Loop)",
		playing_segment: "Playing (Segment)",
		paused: "Paused",
		paused_segment: "Paused (Segment)",
		stopped: "Stopped",
		error: "Error"
	};
	var ALLOWED_TRANSITIONS$1 = {
		"": new Set([
			"idle",
			"loading",
			"ready",
			"error"
		]),
		idle: new Set([
			"loading",
			"ready",
			"error"
		]),
		loading: new Set([
			"ready",
			"error",
			"idle"
		]),
		ready: new Set([
			"rendering",
			"playing",
			"playing_loop",
			"playing_segment",
			"paused",
			"stopped",
			"loading",
			"error"
		]),
		rendering: new Set([
			"ready",
			"error",
			"loading"
		]),
		playing: new Set([
			"paused",
			"stopped",
			"playing_loop",
			"playing_segment",
			"ready"
		]),
		playing_loop: new Set([
			"paused",
			"stopped",
			"playing",
			"ready"
		]),
		playing_segment: new Set([
			"paused_segment",
			"stopped",
			"ready"
		]),
		paused: new Set([
			"playing",
			"playing_loop",
			"stopped",
			"ready",
			"loading"
		]),
		paused_segment: new Set([
			"playing_segment",
			"stopped",
			"ready",
			"paused"
		]),
		stopped: new Set([
			"playing",
			"playing_loop",
			"playing_segment",
			"ready",
			"loading"
		]),
		error: new Set([
			"loading",
			"idle",
			"ready"
		])
	};
	function canTransitionTransportState(fromState, toState) {
		if (!toState) return false;
		if (fromState === toState) return true;
		return (ALLOWED_TRANSITIONS$1[fromState] || ALLOWED_TRANSITIONS$1[""]).has(toState);
	}
	//#endregion
	//#region src/interactionState.js
	/**
	* All possible interaction modes.
	* Only 'idle' allows starting a new interaction.
	*
	* @typedef {'idle'
	*   | 'playhead-drag'
	*   | 'viewport-pan'
	*   | 'overview-move'
	*   | 'overview-resize-left'
	*   | 'overview-resize-right'
	*   | 'view-resize-split'
	*   | 'view-resize-spectrogram'
	* } InteractionMode
	*/
	/**
	* Per-mode context data, only valid while the corresponding mode is active.
	*
	* @typedef {Object} InteractionContext
	* @property {string | undefined} playheadSource       - 'waveform' | 'spectrogram' | 'overview' (playhead-drag)
	* @property {number}         panStartX               - clientX at pan start (viewport-pan)
	* @property {number}         panStartY               - clientY at pan start (viewport-pan)
	* @property {number}         panStartScroll           - scrollLeft at pan start (viewport-pan)
	* @property {boolean}        panSuppressClick         - true once drag exceeds 3px (viewport-pan)
	* @property {boolean}        panIsMiddle              - true if middle mouse button started the pan
	* @property {string | undefined} panSource            - 'waveform' | 'spectrogram' (viewport-pan)
	* @property {number | null}  panStartFreqViewMin      - freq viewport min at pan start (viewport-pan)
	* @property {number | null}  panStartFreqViewMax      - freq viewport max at pan start (viewport-pan)
	* @property {number}         overviewStartX           - clientX at overview drag start
	* @property {number}         overviewStartNorm        - windowStartNorm at drag start
	* @property {number}         overviewEndNorm          - windowEndNorm at drag start
	* @property {boolean}        overviewMoved            - true once drag exceeds 2px threshold
	* @property {number}         resizeStartY             - clientY at resize start (view-resize)
	* @property {number}         resizeStartWaveformH     - waveformDisplayHeight at resize start
	* @property {number}         resizeStartSpectrogramH  - spectrogramDisplayHeight at resize start
	*/
	/** @type {ReadonlySet<InteractionMode>} */
	var OVERVIEW_MODES = new Set([
		"overview-move",
		"overview-resize-left",
		"overview-resize-right"
	]);
	/** @type {ReadonlySet<InteractionMode>} */
	var VIEW_RESIZE_MODES = new Set(["view-resize-split", "view-resize-spectrogram"]);
	/**
	* Allowed transitions.  Every mode can return to 'idle'.
	* Only 'idle' can transition to a specific mode.
	*
	* @type {Record<InteractionMode, ReadonlySet<InteractionMode>>}
	*/
	var ALLOWED_TRANSITIONS = {
		"idle": new Set([
			"playhead-drag",
			"viewport-pan",
			"overview-move",
			"overview-resize-left",
			"overview-resize-right",
			"view-resize-split",
			"view-resize-spectrogram"
		]),
		"playhead-drag": new Set(["idle"]),
		"viewport-pan": new Set(["idle"]),
		"overview-move": new Set(["idle"]),
		"overview-resize-left": new Set(["idle"]),
		"overview-resize-right": new Set(["idle"]),
		"view-resize-split": new Set(["idle"]),
		"view-resize-spectrogram": new Set(["idle"])
	};
	/**
	* Check whether a transition from `from` to `to` is allowed.
	*
	* @param {InteractionMode} from
	* @param {InteractionMode} to
	* @returns {boolean}
	*/
	function canTransitionInteraction(from, to) {
		return ALLOWED_TRANSITIONS[from]?.has(to) === true;
	}
	/**
	* Create a fresh default context (all fields at neutral/zero values).
	*
	* @returns {InteractionContext}
	*/
	function defaultContext() {
		return {
			playheadSource: void 0,
			panStartX: 0,
			panStartScroll: 0,
			panSuppressClick: false,
			panStartY: 0,
			panIsMiddle: false,
			panSource: void 0,
			panStartFreqViewMin: null,
			panStartFreqViewMax: null,
			overviewStartX: 0,
			overviewStartNorm: 0,
			overviewEndNorm: 1,
			overviewMoved: false,
			resizeStartY: 0,
			resizeStartWaveformH: 0,
			resizeStartSpectrogramH: 0
		};
	}
	/**
	* Interaction state container.
	* Holds the current mode and mode-specific context.
	*/
	var InteractionState = class {
		constructor() {
			/** @type {InteractionMode} */
			this.mode = "idle";
			/** @type {InteractionContext} */
			this.ctx = defaultContext();
			/** @type {number} Timestamp-based click suppression for seek */
			this._blockSeekClickUntil = 0;
			/** @type {number} Timestamp-based click suppression for overview */
			this._overviewSuppressClickUntil = 0;
		}
		/** @returns {boolean} */
		get isIdle() {
			return this.mode === "idle";
		}
		/** @returns {boolean} */
		get isDraggingPlayhead() {
			return this.mode === "playhead-drag";
		}
		/** @returns {boolean} */
		get isDraggingViewport() {
			return this.mode === "viewport-pan";
		}
		/** @returns {boolean} */
		get isOverviewDrag() {
			return OVERVIEW_MODES.has(this.mode);
		}
		/** @returns {boolean} */
		get isViewResize() {
			return VIEW_RESIZE_MODES.has(this.mode);
		}
		/**
		* The overview sub-mode: 'move' | 'left' | 'right' | null.
		* @returns {string | null}
		*/
		get overviewSubMode() {
			switch (this.mode) {
				case "overview-move": return "move";
				case "overview-resize-left": return "left";
				case "overview-resize-right": return "right";
				default: return null;
			}
		}
		/**
		* The view-resize sub-mode: 'split' | 'spectrogram' | null.
		* @returns {string | null}
		*/
		get viewResizeSubMode() {
			switch (this.mode) {
				case "view-resize-split": return "split";
				case "view-resize-spectrogram": return "spectrogram";
				default: return null;
			}
		}
		/**
		* Transition to a new mode.  Returns false if the transition is invalid.
		*
		* @param {InteractionMode} nextMode
		* @returns {boolean}
		*/
		enter(nextMode) {
			if (!canTransitionInteraction(this.mode, nextMode)) return false;
			this.mode = nextMode;
			if (nextMode === "idle") this.ctx = defaultContext();
			return true;
		}
		/**
		* Return to idle, resetting all context.
		*/
		release() {
			this.mode = "idle";
			this.ctx = defaultContext();
		}
		/**
		* Block seek-clicks for `ms` milliseconds (e.g. after a drag).
		* @param {number} [ms=220]
		*/
		blockSeekClicks(ms = 220) {
			this._blockSeekClickUntil = Math.max(this._blockSeekClickUntil, performance.now() + ms);
		}
		/**
		* Returns true if seek-clicks are currently suppressed.
		* Covers both timestamp-based blocking and viewport-pan drag threshold.
		* @returns {boolean}
		*/
		isSeekBlocked() {
			if (performance.now() < this._blockSeekClickUntil) return true;
			if (this.ctx.panSuppressClick) return true;
			return false;
		}
		/**
		* Clear the pan-based seek suppression (called once after a blocked click is consumed).
		*/
		consumeSeekBlock() {
			this.ctx.panSuppressClick = false;
		}
		/**
		* Block overview clicks for `ms` milliseconds.
		* @param {number} [ms=260]
		*/
		blockOverviewClicks(ms = 260) {
			this._overviewSuppressClickUntil = Math.max(this._overviewSuppressClickUntil, performance.now() + ms);
		}
		/**
		* Returns true if overview clicks are currently suppressed.
		* @returns {boolean}
		*/
		isOverviewClickBlocked() {
			return performance.now() < this._overviewSuppressClickUntil;
		}
	};
	//#endregion
	//#region src/dsp.js
	function hzToMel(hz) {
		return 2595 * Math.log10(1 + hz / 700);
	}
	function melToHz(mel) {
		return 700 * (Math.pow(10, mel / 2595) - 1);
	}
	/**
	* Return an array of `nMels` frequencies (Hz) evenly spaced in mel scale
	* from 0 Hz to sampleRate/2.
	*/
	function buildMelFrequencies(sampleRate, nMels) {
		const melMin = hzToMel(0);
		const melMax = hzToMel(sampleRate / 2);
		const freqs = new Float32Array(nMels);
		for (let i = 0; i < nMels; i++) freqs[i] = melToHz(melMin + i / Math.max(1, nMels - 1) * (melMax - melMin));
		return freqs;
	}
	function createMelFilterbank(sampleRate, fftSize, nMels, fMin, fMax) {
		const nFftBins = Math.floor(fftSize / 2);
		const melMin = hzToMel(fMin);
		const melMax = hzToMel(fMax);
		const melPoints = [];
		for (let i = 0; i < nMels + 2; i++) melPoints.push(melMin + i / (nMels + 1) * (melMax - melMin));
		const binPoints = melPoints.map(melToHz).map((hz) => Math.floor((fftSize + 1) * hz / sampleRate));
		const filterbank = [];
		for (let m = 1; m <= nMels; m++) {
			const filter = new Float32Array(nFftBins);
			const left = Math.max(0, Math.min(nFftBins - 1, binPoints[m - 1]));
			const center = Math.max(0, Math.min(nFftBins - 1, binPoints[m]));
			const right = Math.max(0, Math.min(nFftBins - 1, binPoints[m + 1]));
			for (let k = left; k < center; k++) filter[k] = (k - left) / (center - left || 1);
			for (let k = center; k < right; k++) filter[k] = (right - k) / (right - center || 1);
			let filterSum = 0;
			for (let k = 0; k < nFftBins; k++) filterSum += filter[k];
			if (filterSum === 0) {
				filter[center] = 1;
				filterSum = 1;
			}
			for (let k = 0; k < nFftBins; k++) filter[k] /= filterSum;
			filterbank.push(filter);
		}
		return filterbank;
	}
	/**
	* Build a sparse mel filterbank for fast application.
	* Instead of iterating all nFftBins per filter, stores only
	* the non-zero (startBin, weights[]) ranges.
	*/
	function createSparseMelFilterbank(sampleRate, fftSize, nMels, fMin, fMax) {
		const dense = createMelFilterbank(sampleRate, fftSize, nMels, fMin, fMax);
		const sparse = new Array(nMels);
		for (let m = 0; m < nMels; m++) {
			const f = dense[m];
			let start = -1, end = 0;
			for (let k = 0; k < f.length; k++) if (f[k] !== 0) {
				if (start < 0) start = k;
				end = k + 1;
			}
			if (start < 0) start = 0;
			const weights = f.subarray(start, end);
			sparse[m] = {
				start,
				weights
			};
		}
		return sparse;
	}
	var _twiddleCache = /* @__PURE__ */ new Map();
	function getTwiddleFactors(n) {
		if (_twiddleCache.has(n)) return _twiddleCache.get(n);
		const table = {};
		for (let len = 2; len <= n; len <<= 1) {
			const halfLen = len >> 1;
			const angleStep = -2 * Math.PI / len;
			const cos = new Float64Array(halfLen);
			const sin = new Float64Array(halfLen);
			for (let k = 0; k < halfLen; k++) {
				const angle = angleStep * k;
				cos[k] = Math.cos(angle);
				sin[k] = Math.sin(angle);
			}
			table[len] = {
				cos,
				sin
			};
		}
		_twiddleCache.set(n, table);
		return table;
	}
	function iterativeFFT(real, imag) {
		const n = real.length;
		const twiddle = getTwiddleFactors(n);
		let j = 0;
		for (let i = 1; i < n; i++) {
			let bit = n >> 1;
			while (j & bit) {
				j ^= bit;
				bit >>= 1;
			}
			j ^= bit;
			if (i < j) {
				let tmp = real[i];
				real[i] = real[j];
				real[j] = tmp;
				tmp = imag[i];
				imag[i] = imag[j];
				imag[j] = tmp;
			}
		}
		for (let len = 2; len <= n; len <<= 1) {
			const halfLen = len >> 1;
			const { cos, sin } = twiddle[len];
			for (let i = 0; i < n; i += len) for (let k = 0; k < halfLen; k++) {
				const evenIndex = i + k;
				const oddIndex = evenIndex + halfLen;
				const tr = cos[k] * real[oddIndex] - sin[k] * imag[oddIndex];
				const ti = sin[k] * real[oddIndex] + cos[k] * imag[oddIndex];
				real[oddIndex] = real[evenIndex] - tr;
				imag[oddIndex] = imag[evenIndex] - ti;
				real[evenIndex] += tr;
				imag[evenIndex] += ti;
			}
		}
	}
	/** @param {number} i @param {number} N */
	function hannWindow(i, N) {
		return .5 * (1 - Math.cos(2 * Math.PI * i / Math.max(1, N - 1)));
	}
	/** @param {number} i @param {number} N */
	function hammingWindow(i, N) {
		return .54 - .46 * Math.cos(2 * Math.PI * i / Math.max(1, N - 1));
	}
	/** @param {number} i @param {number} N */
	function blackmanWindow(i, N) {
		return .42 - .5 * Math.cos(2 * Math.PI * i / Math.max(1, N - 1)) + .08 * Math.cos(4 * Math.PI * i / Math.max(1, N - 1));
	}
	/** Blackman-Harris 4-term — excellent sidelobe suppression (−92 dB). */
	function blackmanHarrisWindow(i, N) {
		const a0 = .35875, a1 = .48829, a2 = .14128, a3 = .01168;
		const t = 2 * Math.PI * i / Math.max(1, N - 1);
		return a0 - a1 * Math.cos(t) + a2 * Math.cos(2 * t) - a3 * Math.cos(3 * t);
	}
	/** Flat-top — near-unity amplitude accuracy at the cost of wider main lobe. */
	function flatTopWindow(i, N) {
		const a0 = .21557895, a1 = .41663158, a2 = .277263158;
		const a3 = .083578947, a4 = .006947368;
		const t = 2 * Math.PI * i / Math.max(1, N - 1);
		return a0 - a1 * Math.cos(t) + a2 * Math.cos(2 * t) - a3 * Math.cos(3 * t) + a4 * Math.cos(4 * t);
	}
	/**
	* Kaiser window — adjustable via β parameter.
	* Higher β → narrower main lobe, lower sidelobes.
	* β≈5: similar to Hamming, β≈8.6: similar to Blackman-Harris.
	* Uses rational Bessel I₀ approximation (no factorial overflow).
	*/
	function kaiserWindow(i, N, beta = 6) {
		const alpha = Math.max(1, N - 1) / 2;
		return _besselI0(beta * Math.sqrt(1 - ((i - alpha) / alpha) ** 2)) / _besselI0(beta);
	}
	/** Modified Bessel function I₀(x) — polynomial approximation (Abramowitz & Stegun). */
	function _besselI0(x) {
		const ax = Math.abs(x);
		if (ax < 3.75) {
			const t = (ax / 3.75) ** 2;
			return 1 + t * (3.5156229 + t * (3.0899424 + t * (1.2067492 + t * (.2659732 + t * (.0360768 + t * .0045813)))));
		}
		const t = 3.75 / ax;
		return Math.exp(ax) / Math.sqrt(ax) * (.39894228 + t * (.01328592 + t * (.00225319 + t * (-.00157565 + t * (.00916281 + t * (-.02057706 + t * (.02635537 + t * (-.01647633 + t * .00392377))))))));
	}
	/** @type {Record<string, (i: number, N: number) => number>} */
	var WINDOW_FUNCTIONS = {
		hann: hannWindow,
		hamming: hammingWindow,
		blackman: blackmanWindow,
		blackmanHarris: blackmanHarrisWindow,
		flatTop: flatTopWindow,
		kaiser: kaiserWindow
	};
	/**
	* IEC 60268-18 fader law: map dB → meter deflection percentage.
	* Used by the "Meter" colour scale to produce perceptually-even brightness.
	*/
	function iecDbToFader(db) {
		if (db < -70) return 0;
		if (db < -60) return (db + 70) * .25;
		if (db < -50) return (db + 60) * .5 + 2.5;
		if (db < -40) return (db + 50) * .75 + 7.5;
		if (db < -30) return (db + 40) * 1.5 + 15;
		if (db < -20) return (db + 30) * 2 + 30;
		return (db + 20) * 2.5 + 50;
	}
	iecDbToFader(0);
	/**
	* Compute a full spectrogram from raw audio samples.
	*
	* @param {Object} params
	* @param {ArrayBuffer|Float32Array} params.channelData - mono audio samples
	* @param {number} params.fftSize
	* @param {number} params.sampleRate
	* @param {number} params.frameRate      - frames per second
	* @param {number} params.nMels          - number of mel bins (mel scale)
	* @param {number} params.pcenGain
	* @param {number} params.pcenBias
	* @param {number} params.pcenRoot
	* @param {number} params.pcenSmoothing
	* @param {boolean} [params.usePcen=true] - apply PCEN normalisation (false → dB even in mel mode)
	* @param {string} [params.scale='mel'] - 'mel' or 'linear'
	* @param {string} [params.colourScale='dbSquared'] - 'linear'|'meter'|'dbSquared'|'db'|'phase'
	* @param {Float32Array} [params.initialSmooth] - carry-over PCEN smooth state from previous chunk
	* @param {number} [params.windowSize] - window length in samples (0 or omit = auto: 4×hopSize)
	* @param {number} [params.hopSize] - hop size in samples (0 or omit = auto: sampleRate/frameRate)
	* @param {string} [params.windowFunction='hann'] - 'hann' | 'hamming' | 'blackman'
	*
	* @returns {{ data: Float32Array, nFrames: number, nMels: number, hopSize: number, winLength: number, colourScale: string, smoothState?: Float32Array }}
	*/
	function computeSpectrogram(params) {
		const { channelData, fftSize, sampleRate, frameRate, nMels, pcenGain, pcenBias, pcenRoot, pcenSmoothing, usePcen = true, scale = "mel", initialSmooth, colourScale = "dbSquared", windowSize: userWindowSize, hopSize: userHopSize, windowFunction = "hann" } = params;
		const audio = channelData instanceof Float32Array ? channelData : new Float32Array(channelData);
		const autoHop = Math.max(1, Math.floor(sampleRate / frameRate));
		const hopSize = userHopSize && userHopSize > 0 ? userHopSize : autoHop;
		const winLength = userWindowSize && userWindowSize > 0 ? userWindowSize : 4 * hopSize;
		const numFrames = Math.max(1, Math.floor((audio.length - winLength) / hopSize) + 1);
		const nBins = Math.floor(fftSize / 2);
		const useLinear = scale === "linear";
		const useCQT = scale === "cqt";
		const isPhase = colourScale === "phase";
		const outBins = useLinear ? nBins : nMels;
		const output = new Float32Array(numFrames * outBins);
		const wfn = WINDOW_FUNCTIONS[windowFunction] || hannWindow;
		const maxCopy = Math.min(winLength, fftSize);
		const windowLUT = new Float32Array(maxCopy);
		for (let i = 0; i < maxCopy; i++) windowLUT[i] = wfn(i, winLength);
		const real = new Float32Array(fftSize);
		const imag = new Float32Array(fftSize);
		const sparseFB = useLinear ? null : useCQT ? createCQTFilterbank(sampleRate, fftSize, nMels) : createSparseMelFilterbank(sampleRate, fftSize, nMels, 0, sampleRate / 2);
		const denseFB = isPhase && !useLinear ? createMelFilterbank(sampleRate, fftSize, nMels, 0, sampleRate / 2) : null;
		const powerBuf = !useLinear && !isPhase ? new Float32Array(nBins) : null;
		/** Apply windowed frame into reusable buffers and run FFT in-place. */
		function runFFT(offset) {
			real.fill(0);
			imag.fill(0);
			for (let i = 0; i < maxCopy; i++) real[i] = (audio[offset + i] || 0) * windowLUT[i];
			iterativeFFT(real, imag);
		}
		let smooth = null;
		if (isPhase) for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {
			runFFT(frameIdx * hopSize);
			const base = frameIdx * outBins;
			if (useLinear) for (let k = 0; k < nBins; k++) output[base + k] = Math.atan2(imag[k], real[k]);
			else for (let m = 0; m < nMels; m++) {
				const f = denseFB[m];
				let sumSin = 0, sumCos = 0;
				for (let k = 0; k < f.length; k++) if (f[k] > 0) {
					const ph = Math.atan2(imag[k], real[k]);
					sumSin += f[k] * Math.sin(ph);
					sumCos += f[k] * Math.cos(ph);
				}
				output[base + m] = Math.atan2(sumSin, sumCos);
			}
		}
		else if (useLinear) {
			const wantRaw = colourScale === "linear" || colourScale === "meter";
			for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {
				runFFT(frameIdx * hopSize);
				const base = frameIdx * nBins;
				if (wantRaw) for (let k = 0; k < nBins; k++) output[base + k] = Math.sqrt(real[k] * real[k] + imag[k] * imag[k]);
				else for (let k = 0; k < nBins; k++) {
					const p = real[k] * real[k] + imag[k] * imag[k];
					output[base + k] = 10 * Math.log10(Math.max(1e-20, p));
				}
			}
		} else if (!usePcen) {
			const wantRaw = colourScale === "linear" || colourScale === "meter";
			for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {
				runFFT(frameIdx * hopSize);
				for (let k = 0; k < nBins; k++)
 /** @type {!Float32Array} */ powerBuf[k] = real[k] * real[k] + imag[k] * imag[k];
				const base = frameIdx * nMels;
				for (let m = 0; m < nMels; m++) {
					const { start, weights } = sparseFB[m];
					let sum = 0;
					for (let k = 0; k < weights.length; k++) sum += powerBuf[start + k] * weights[k];
					if (wantRaw) output[base + m] = Math.sqrt(Math.max(0, sum));
					else output[base + m] = 10 * Math.log10(Math.max(1e-10, sum));
				}
			}
		} else {
			smooth = new Float32Array(nMels);
			if (initialSmooth && initialSmooth.length === nMels) smooth.set(initialSmooth);
			const pcenPower = 1 / pcenRoot;
			const pcenBiasOffset = Math.pow(pcenBias, pcenPower);
			for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {
				runFFT(frameIdx * hopSize);
				for (let k = 0; k < nBins; k++)
 /** @type {!Float32Array} */ powerBuf[k] = real[k] * real[k] + imag[k] * imag[k];
				const base = frameIdx * nMels;
				for (let m = 0; m < nMels; m++) {
					const { start, weights } = sparseFB[m];
					let e = 0;
					for (let k = 0; k < weights.length; k++) e += powerBuf[start + k] * weights[k];
					smooth[m] = (1 - pcenSmoothing) * smooth[m] + pcenSmoothing * e;
					const denom = Math.pow(1e-10 + smooth[m], pcenGain);
					const norm = e / denom;
					output[base + m] = Math.pow(norm + pcenBias, pcenPower) - pcenBiasOffset;
				}
			}
		}
		const result = {
			data: output,
			nFrames: numFrames,
			nMels: outBins,
			hopSize,
			winLength,
			colourScale
		};
		if (smooth) result.smoothState = smooth;
		return result;
	}
	/**
	* Build a CQT (Constant-Q) filterbank that maps STFT bins to
	* log-spaced frequency bins with constant Q factor.
	* Returns a sparse filterbank compatible with applySparseMelFilterbank.
	*
	* @param {number} sampleRate
	* @param {number} fftSize
	* @param {number} nBinsOut        - desired number of output bins
	* @param {number} [fMin=32.7]     - lowest frequency (Hz), default C1
	* @param {number} [binsPerOctave=24]
	*/
	function createCQTFilterbank(sampleRate, fftSize, nBinsOut, fMin = 32.7, binsPerOctave = 24) {
		const nFftBins = Math.floor(fftSize / 2);
		const nyquist = sampleRate / 2;
		const Q = 1 / (Math.pow(2, 1 / binsPerOctave) - 1);
		const sparse = new Array(nBinsOut);
		for (let k = 0; k < nBinsOut; k++) {
			const fCenter = fMin * Math.pow(2, k / binsPerOctave);
			if (fCenter >= nyquist) {
				sparse[k] = {
					start: nFftBins - 1,
					weights: new Float32Array([1])
				};
				continue;
			}
			const bw = fCenter / Q;
			const fLo = Math.max(0, fCenter - bw / 2);
			const fHi = Math.min(nyquist, fCenter + bw / 2);
			const binLo = Math.max(0, Math.floor(fLo * fftSize / sampleRate));
			const len = Math.min(nFftBins - 1, Math.ceil(fHi * fftSize / sampleRate)) - binLo + 1;
			const weights = new Float32Array(len);
			let sum = 0;
			for (let b = 0; b < len; b++) {
				const fBin = (binLo + b) * sampleRate / fftSize;
				const dist = Math.abs(fBin - fCenter) / (bw / 2 + 1e-12);
				weights[b] = Math.max(0, 1 - dist);
				sum += weights[b];
			}
			if (sum > 0) for (let b = 0; b < len; b++) weights[b] /= sum;
			else if (len > 0) weights[0] = 1;
			sparse[k] = {
				start: binLo,
				weights
			};
		}
		return sparse;
	}
	/**
	* Build CQT frequency array (Hz) for each output bin.
	* @param {number} nBins
	* @param {number} [fMin=32.7]
	* @param {number} [binsPerOctave=24]
	* @returns {Float32Array}
	*/
	function buildCQTFrequencies(nBins, fMin = 32.7, binsPerOctave = 24) {
		const freqs = new Float32Array(nBins);
		for (let k = 0; k < nBins; k++) freqs[k] = fMin * Math.pow(2, k / binsPerOctave);
		return freqs;
	}
	/**
	* Compute a reassigned spectrogram for sharper time-frequency localization.
	* Uses three parallel STFTs with:
	*   1. h(n) — standard window
	*   2. (n - N/2) · h(n) — time-ramped window (for time correction)
	*   3. h'(n) — derivative window (for frequency correction)
	*
	* The corrected coordinates allow energy to be placed at its "true"
	* center of gravity in time-frequency space.
	*
	* @param {Object} params  - Same as computeSpectrogram plus:
	* @param {ArrayBuffer|Float32Array} params.channelData
	* @param {number} params.fftSize
	* @param {number} params.sampleRate
	* @param {number} params.frameRate
	* @param {number} params.nMels
	* @param {string} [params.scale='mel']
	* @param {string} [params.colourScale='dbSquared']
	* @param {number} [params.windowSize]
	* @param {number} [params.hopSize]
	* @param {string} [params.windowFunction='hann']
	* @returns {{ data: Float32Array, nFrames: number, nMels: number, hopSize: number, winLength: number, colourScale: string }}
	*/
	function computeReassignedSpectrogram(params) {
		const { channelData, fftSize, sampleRate, frameRate, nMels, scale = "mel", colourScale = "dbSquared", windowSize: userWindowSize, hopSize: userHopSize, windowFunction = "hann" } = params;
		const audio = channelData instanceof Float32Array ? channelData : new Float32Array(channelData);
		const autoHop = Math.max(1, Math.floor(sampleRate / frameRate));
		const hopSize = userHopSize && userHopSize > 0 ? userHopSize : autoHop;
		const winLength = userWindowSize && userWindowSize > 0 ? userWindowSize : 4 * hopSize;
		const numFrames = Math.max(1, Math.floor((audio.length - winLength) / hopSize) + 1);
		const nBins = Math.floor(fftSize / 2);
		const useLinear = scale === "linear";
		const useCQT = scale === "cqt";
		const outBins = useLinear ? nBins : nMels;
		const output = new Float32Array(numFrames * outBins);
		const wfn = WINDOW_FUNCTIONS[windowFunction] || hannWindow;
		const maxCopy = Math.min(winLength, fftSize);
		const winH = new Float32Array(maxCopy);
		const winTH = new Float32Array(maxCopy);
		const winDH = new Float32Array(maxCopy);
		for (let i = 0; i < maxCopy; i++) winH[i] = wfn(i, winLength);
		for (let i = 0; i < maxCopy; i++) winTH[i] = (i - winLength / 2) * winH[i];
		for (let i = 1; i < maxCopy - 1; i++) winDH[i] = .5 * (winH[i + 1] - winH[i - 1]);
		winDH[0] = winH[1] - winH[0];
		if (maxCopy > 1) winDH[maxCopy - 1] = winH[maxCopy - 1] - winH[maxCopy - 2];
		const realH = new Float32Array(fftSize), imagH = new Float32Array(fftSize);
		const realTH = new Float32Array(fftSize), imagTH = new Float32Array(fftSize);
		const realDH = new Float32Array(fftSize), imagDH = new Float32Array(fftSize);
		const sparseFB = useLinear ? null : useCQT ? createCQTFilterbank(sampleRate, fftSize, nMels) : createSparseMelFilterbank(sampleRate, fftSize, nMels, 0, sampleRate / 2);
		const counts = new Float32Array(numFrames * outBins);
		for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {
			const offset = frameIdx * hopSize;
			realH.fill(0);
			imagH.fill(0);
			realTH.fill(0);
			imagTH.fill(0);
			realDH.fill(0);
			imagDH.fill(0);
			for (let i = 0; i < maxCopy; i++) {
				const s = audio[offset + i] || 0;
				realH[i] = s * winH[i];
				realTH[i] = s * winTH[i];
				realDH[i] = s * winDH[i];
			}
			iterativeFFT(realH, imagH);
			iterativeFFT(realTH, imagTH);
			iterativeFFT(realDH, imagDH);
			if (useLinear) for (let k = 0; k < nBins; k++) {
				const magSq = realH[k] * realH[k] + imagH[k] * imagH[k];
				if (magSq < 1e-30) continue;
				const dtSamples = (realTH[k] * realH[k] + imagTH[k] * imagH[k]) / magSq;
				const dOmega = -(imagDH[k] * realH[k] - realDH[k] * imagH[k]) / magSq;
				const correctedBin = k + dOmega * fftSize / (2 * Math.PI);
				const correctedFrame = frameIdx + dtSamples / hopSize;
				const cBin = Math.max(0, Math.min(nBins - 1, Math.round(correctedBin)));
				const idx = Math.max(0, Math.min(numFrames - 1, Math.round(correctedFrame))) * nBins + cBin;
				const value = colourScale === "linear" || colourScale === "meter" ? Math.sqrt(magSq) : 10 * Math.log10(Math.max(1e-20, magSq));
				output[idx] += value;
				counts[idx] += 1;
			}
			else for (let k = 0; k < nBins; k++) {
				const magSq = realH[k] * realH[k] + imagH[k] * imagH[k];
				if (magSq < 1e-30) continue;
				const dtSamples = (realTH[k] * realH[k] + imagTH[k] * imagH[k]) / magSq;
				const dOmega = -(imagDH[k] * realH[k] - realDH[k] * imagH[k]) / magSq;
				const correctedBin = k + dOmega * fftSize / (2 * Math.PI);
				const correctedFrame = frameIdx + dtSamples / hopSize;
				const cFrame = Math.max(0, Math.min(numFrames - 1, Math.round(correctedFrame)));
				const cBinInt = Math.max(0, Math.min(nBins - 1, Math.round(correctedBin)));
				for (let m = 0; m < nMels; m++) {
					const { start, weights } = sparseFB[m];
					if (cBinInt < start || cBinInt >= start + weights.length) continue;
					const w = weights[cBinInt - start];
					if (w <= 0) continue;
					const value = colourScale === "linear" || colourScale === "meter" ? Math.sqrt(magSq) * w : 10 * Math.log10(Math.max(1e-20, magSq)) * w;
					const idx = cFrame * nMels + m;
					output[idx] += value;
					counts[idx] += w;
				}
			}
		}
		for (let i = 0; i < output.length; i++) if (counts[i] > 0) output[i] /= counts[i];
		return {
			data: output,
			nFrames: numFrames,
			nMels: outBins,
			hopSize,
			winLength,
			colourScale
		};
	}
	//#endregion
	//#region src/coordinateSystem.js
	/**
	* Compute the highest visible bin index for a given frequency ceiling.
	* Shared by CoordinateSystem and spectrogram rendering.
	*
	* @param {{ isLinear: boolean, nyquist: number, spectrogramMels: number, boundedMaxFreq: number, melFreqs: Float32Array | null }} p
	* @returns {number}
	*/
	function computeMaxBin({ isLinear, nyquist, spectrogramMels, boundedMaxFreq, melFreqs }) {
		if (isLinear) {
			const binHz = nyquist / spectrogramMels;
			return Math.max(1, Math.min(spectrogramMels - 1, Math.floor(boundedMaxFreq / binHz)));
		}
		let maxBin = spectrogramMels - 1;
		const freqs = melFreqs;
		for (let i = 0; i < freqs.length; i++) if (freqs[i] > boundedMaxFreq) {
			maxBin = Math.max(1, i - 1);
			break;
		}
		return maxBin;
	}
	/**
	* Centralises every coordinate‐space conversion so that all consumers
	* (spectrogram rendering, crosshair, annotations, frequency labels,
	* overview, playhead, etc.) share one coherent set of parameters.
	*
	* Instances are lightweight and designed to be recreated whenever any
	* underlying parameter changes (zoom, mode switch, maxFreq, resize).
	*/
	var CoordinateSystem = class {
		/**
		* @param {object} [params]
		* @param {number} [params.duration]           Audio duration in seconds
		* @param {number} [params.sampleRate]         Audio sample rate in Hz
		* @param {number} [params.pixelsPerSecond]    Current zoom level
		* @param {number} [params.canvasWidth]        Spectrogram canvas width in px
		* @param {number} [params.canvasHeight]       Spectrogram canvas height in px (display size)
		* @param {number} [params.maxFreq]            User-selected max frequency in Hz
		* @param {number} [params.spectrogramMels]    Number of mel bins (nMels)
		* @param {string} [params.scale]               'mel' | 'linear' | 'cqt'
		* @param {number} [params.frameRate]          Spectrogram frame rate (default: PERCH_FRAME_RATE)
		* @param {number} [params.hopSize]            Actual hop size in samples (0 = auto from frameRate)
		* @param {number[] | null} [params.freqRange]  [fMin, fMax] in Hz — explicit frequency range (for external images)
		* @param {string | null} [params.freqScale]    Frequency axis mapping: 'mel' | 'linear' | 'log' (for external images)
		* @param {number | null} [params.freqViewMin]  Frequency viewport bottom (Hz) for vertical zoom (null = 0)
		* @param {number | null} [params.freqViewMax]  Frequency viewport top (Hz) for vertical zoom (null = boundedMaxFreq)
		*/
		constructor({ duration = 0, sampleRate = DEFAULT_SAMPLE_RATE, pixelsPerSecond = 100, canvasWidth = 0, canvasHeight = 0, maxFreq = 1e4, spectrogramMels = 128, scale = "mel", frameRate = 100, hopSize = 0, freqRange = null, freqScale = null, freqViewMin = null, freqViewMax = null } = {}) {
			this.duration = Math.max(0, duration);
			this.sampleRate = Math.max(1, sampleRate);
			this.pixelsPerSecond = Math.max(.01, pixelsPerSecond);
			this.canvasWidth = Math.max(0, canvasWidth);
			this.canvasHeight = Math.max(1, canvasHeight);
			this.maxFreq = Math.max(1, maxFreq);
			this.spectrogramMels = Math.max(1, spectrogramMels);
			this.scale = scale;
			this.frameRate = Math.max(1, frameRate);
			/** @type {number[] | null} */
			this.freqRange = freqRange;
			/** @type {string | null} */
			this.freqScale = freqScale;
			this.nyquist = this.sampleRate / 2;
			this.boundedMaxFreq = this.freqRange ? Math.max(1, this.freqRange[1]) : Math.min(this.maxFreq, this.nyquist);
			this.isLinear = this.freqScale ? this.freqScale === "linear" : this.scale === "linear";
			this.hopSize = hopSize && hopSize > 0 ? hopSize : Math.max(1, Math.floor(this.sampleRate / this.frameRate));
			/** @type {Float32Array | null} */
			this._melFreqs = null;
			this._maxBin = this._computeMaxBin();
			const hasView = freqViewMin != null && freqViewMax != null && (freqViewMin > 0 || freqViewMax < this.boundedMaxFreq);
			this.freqViewMin = hasView ? Math.max(0, freqViewMin) : null;
			this.freqViewMax = hasView ? Math.min(this.boundedMaxFreq, freqViewMax) : null;
			this._hasFreqView = hasView;
			if (hasView) {
				this._viewMinBin = this._freqToBinFractional(this.freqViewMin);
				this._viewMaxBin = this._freqToBinFractional(this.freqViewMax);
				this._viewBinRange = this._viewMaxBin - this._viewMinBin;
			} else {
				this._viewMinBin = 0;
				this._viewMaxBin = this._maxBin;
				this._viewBinRange = this._maxBin;
			}
		}
		/** @returns {Float32Array} */
		get melFreqs() {
			if (!this._melFreqs) this._melFreqs = this.scale === "cqt" ? buildCQTFrequencies(this.spectrogramMels, CQT_FMIN, 24) : buildMelFrequencies(this.sampleRate, this.spectrogramMels);
			return this._melFreqs;
		}
		get maxBin() {
			return this._maxBin;
		}
		/** Compute maxBin for the current bounded max frequency. */
		_computeMaxBin() {
			return computeMaxBin({
				isLinear: this.isLinear,
				nyquist: this.nyquist,
				spectrogramMels: this.spectrogramMels,
				boundedMaxFreq: this.boundedMaxFreq,
				melFreqs: this.melFreqs
			});
		}
		/** Seconds → canvas pixel X. */
		timeToPixelX(timeSec) {
			if (this.duration <= 0 || this.canvasWidth <= 0) return 0;
			return timeSec / this.duration * this.canvasWidth;
		}
		/** Canvas pixel X → seconds. */
		pixelXToTime(pixelX) {
			if (this.canvasWidth <= 0 || this.duration <= 0) return 0;
			const t = pixelX / this.canvasWidth * this.duration;
			return Math.max(0, Math.min(this.duration, t));
		}
		/** Seconds → scroll‐aware pixel X (accounts for pixelsPerSecond). */
		timeToScrollX(timeSec) {
			return timeSec * this.pixelsPerSecond;
		}
		/** Scroll pixel → seconds. */
		scrollXToTime(scrollX) {
			return scrollX / this.pixelsPerSecond;
		}
		/**
		* Frequency → fractional bin index [0 .. maxBin].
		* Shared helper for both full-range and viewport-aware mappings.
		* @private
		*/
		_freqToBinFractional(freq) {
			const cf = Math.max(0, Math.min(this.boundedMaxFreq, freq));
			if (this.isLinear) {
				const binHz = this.nyquist / this.spectrogramMels;
				return Math.max(0, Math.min(this._maxBin, cf / binHz));
			}
			const freqs = this.melFreqs;
			if (cf >= freqs[this._maxBin]) return this._maxBin;
			for (let i = 0; i < this._maxBin; i++) if (freqs[i + 1] >= cf) {
				const range = freqs[i + 1] - freqs[i];
				return range > 0 ? i + (cf - freqs[i]) / range : i;
			}
			return 0;
		}
		/**
		* Frequency (Hz) → display pixel Y (0 = top).
		* Correctly handles mel, linear, and log modes.
		* When freqRange is set (external image), uses direct mapping over that range.
		* When freqViewMin/freqViewMax are set (vertical zoom), maps within that viewport.
		*/
		frequencyToPixelY(freq) {
			if (this.freqRange) return this._freqToPixelY_external(freq);
			const bin = this._freqToBinFractional(freq);
			if (this._hasFreqView) return (1 - (this._viewBinRange > 0 ? (bin - this._viewMinBin) / this._viewBinRange : 0)) * this.canvasHeight;
			const clampedBin = Math.max(0, Math.min(this._maxBin, bin));
			const h = this.spectrogramMels;
			return (h - 1 - clampedBin / this._maxBin * (h - 1)) / h * this.canvasHeight;
		}
		/**
		* Display pixel Y (0 = top) → frequency (Hz).
		*/
		pixelYToFrequency(displayY) {
			if (this.freqRange) return this._pixelYToFreq_external(displayY);
			if (this._hasFreqView) {
				const fraction = 1 - Math.max(0, Math.min(1, displayY / this.canvasHeight));
				const bin = this._viewMinBin + fraction * this._viewBinRange;
				const clampedBin = Math.max(0, Math.min(this._maxBin, Math.round(bin)));
				if (this.isLinear) return clampedBin * (this.nyquist / this.spectrogramMels);
				return this.melFreqs[clampedBin] || 0;
			}
			const h = this.spectrogramMels;
			const internalY = displayY / this.canvasHeight * h;
			const bin = Math.round((h - 1 - internalY) / (h - 1) * this._maxBin);
			const clampedBin = Math.max(0, Math.min(this._maxBin, bin));
			if (this.isLinear) return clampedBin * (this.nyquist / this.spectrogramMels);
			return this.melFreqs[clampedBin] || 0;
		}
		/** @private Map frequency → pixel Y for an external image with known freqRange + freqScale. */
		_freqToPixelY_external(freq) {
			const [fMin, fMax] = this.freqRange;
			const cf = Math.max(fMin, Math.min(fMax, freq));
			const scale = this.freqScale || "linear";
			let fraction;
			if (scale === "log") {
				const safeMin = Math.max(1, fMin);
				fraction = Math.log(cf / safeMin) / Math.log(fMax / safeMin);
			} else if (scale === "mel") {
				const melMin = hzToMel(fMin);
				const melMax = hzToMel(fMax);
				const melF = hzToMel(cf);
				fraction = melMax > melMin ? (melF - melMin) / (melMax - melMin) : 0;
			} else fraction = fMax > fMin ? (cf - fMin) / (fMax - fMin) : 0;
			fraction = Math.max(0, Math.min(1, fraction));
			return (1 - fraction) * this.canvasHeight;
		}
		/** @private Map pixel Y → frequency for an external image with known freqRange + freqScale. */
		_pixelYToFreq_external(displayY) {
			const [fMin, fMax] = this.freqRange;
			const fraction = 1 - Math.max(0, Math.min(1, displayY / this.canvasHeight));
			const scale = this.freqScale || "linear";
			if (scale === "log") {
				const safeMin = Math.max(1, fMin);
				return safeMin * Math.pow(fMax / safeMin, fraction);
			} else if (scale === "mel") {
				const melMin = hzToMel(fMin);
				return melToHz(melMin + fraction * (hzToMel(fMax) - melMin));
			} else return fMin + fraction * (fMax - fMin);
		}
		/**
		* Frequency → normalized Y fraction (0 = top, 1 = bottom).
		* Useful for CSS positioning (e.g. frequency axis labels).
		*/
		frequencyToYFraction(freq) {
			if (this.canvasHeight <= 0) return 0;
			return this.frequencyToPixelY(freq) / this.canvasHeight;
		}
		/**
		* Frequency → Y fraction in the base spectrogram image (full range, viewport-independent).
		* 0 = top (highest freq), 1 = bottom (0 Hz).
		* Used for computing source crop when rendering with vertical zoom.
		*/
		frequencyToBaseYFraction(freq) {
			if (this.freqRange) return this._freqToPixelY_external(freq) / Math.max(1, this.canvasHeight);
			const bin = this._freqToBinFractional(freq);
			const h = this.spectrogramMels;
			return (h - 1 - bin / this._maxBin * (h - 1)) / h;
		}
		/** Frequency (Hz) → nearest bin index. */
		frequencyToBin(freq) {
			if (this.isLinear) {
				const binHz = this.nyquist / this.spectrogramMels;
				return Math.max(0, Math.min(this.spectrogramMels - 1, Math.round(freq / binHz)));
			}
			const freqs = this.melFreqs;
			let best = 0, bestDist = Math.abs(freqs[0] - freq);
			for (let i = 1; i < freqs.length; i++) {
				const d = Math.abs(freqs[i] - freq);
				if (d < bestDist) {
					bestDist = d;
					best = i;
				}
				if (freqs[i] > freq) break;
			}
			return best;
		}
		/** Bin index → frequency (Hz). */
		binToFrequency(bin) {
			const clamped = Math.max(0, Math.min(this.spectrogramMels - 1, bin));
			if (this.isLinear) return clamped * (this.nyquist / this.spectrogramMels);
			return this.melFreqs[clamped] || 0;
		}
		/** Time (seconds) → spectrogram frame index. */
		timeToFrame(timeSec, nFrames) {
			const frameCenterSec = 2 * this.hopSize / this.sampleRate;
			return Math.max(0, Math.min(nFrames - 1, Math.round((timeSec - frameCenterSec) * this.frameRate)));
		}
		/** Frame index → time (seconds). */
		frameToTime(frame) {
			const frameCenterSec = 2 * this.hopSize / this.sampleRate;
			return frame / this.frameRate + frameCenterSec;
		}
		/** Display pixel Y → bin index (clamped to maxBin). */
		pixelYToBin(displayY) {
			if (this._hasFreqView) {
				const fraction = 1 - Math.max(0, Math.min(1, displayY / this.canvasHeight));
				const bin = this._viewMinBin + fraction * this._viewBinRange;
				return Math.max(0, Math.min(this._maxBin, Math.round(bin)));
			}
			const h = this.spectrogramMels;
			const internalY = displayY / this.canvasHeight * h;
			const bin = Math.round((h - 1 - internalY) / (h - 1) * this._maxBin);
			return Math.max(0, Math.min(this._maxBin, bin));
		}
		/**
		* Convert browser clientX/clientY relative to a wrapper rect
		* into canvas-local pixel coordinates.
		* @param {number} clientX
		* @param {number} clientY
		* @param {DOMRect} wrapperRect
		* @param {number} scrollLeft
		* @returns {{ canvasX: number, canvasY: number, localX: number, localY: number }}
		*/
		clientToCanvas(clientX, clientY, wrapperRect, scrollLeft) {
			const localX = clientX - wrapperRect.left;
			const localY = clientY - wrapperRect.top;
			return {
				canvasX: scrollLeft + localX,
				canvasY: localY / Math.max(1, wrapperRect.height) * this.canvasHeight,
				localX,
				localY
			};
		}
		/**
		* Convert browser clientX/clientY to time and frequency.
		* @param {number} clientX
		* @param {number} clientY
		* @param {DOMRect} wrapperRect
		* @param {number} scrollLeft
		* @returns {{ time: number, freq: number, canvasX: number, canvasY: number, localX: number, localY: number }}
		*/
		clientToTimeFreq(clientX, clientY, wrapperRect, scrollLeft) {
			const { canvasX, canvasY, localX, localY } = this.clientToCanvas(clientX, clientY, wrapperRect, scrollLeft);
			return {
				time: this.pixelXToTime(canvasX),
				freq: this.pixelYToFrequency(canvasY),
				canvasX,
				canvasY,
				localX,
				localY
			};
		}
	};
	//#endregion
	//#region src/spectrogram.worker.js?worker&inline
	var spectrogram_worker_exports = /* @__PURE__ */ __exportAll({ default: () => WorkerWrapper });
	function WorkerWrapper(options) {
		let objURL;
		try {
			objURL = blob && (self.URL || self.webkitURL).createObjectURL(blob);
			if (!objURL) throw "";
			const worker = new Worker(objURL, { name: options?.name });
			worker.addEventListener("error", () => {
				(self.URL || self.webkitURL).revokeObjectURL(objURL);
			});
			return worker;
		} catch (e) {
			return new Worker("data:text/javascript;charset=utf-8," + encodeURIComponent(jsContent), { name: options?.name });
		}
	}
	var jsContent, blob;
	var init_spectrogram_worker = __esmMin((() => {
		jsContent = "(function() {\n	//#region src/dsp.js\n	function hzToMel(hz) {\n		return 2595 * Math.log10(1 + hz / 700);\n	}\n	function melToHz(mel) {\n		return 700 * (Math.pow(10, mel / 2595) - 1);\n	}\n	function createMelFilterbank(sampleRate, fftSize, nMels, fMin, fMax) {\n		const nFftBins = Math.floor(fftSize / 2);\n		const melMin = hzToMel(fMin);\n		const melMax = hzToMel(fMax);\n		const melPoints = [];\n		for (let i = 0; i < nMels + 2; i++) melPoints.push(melMin + i / (nMels + 1) * (melMax - melMin));\n		const binPoints = melPoints.map(melToHz).map((hz) => Math.floor((fftSize + 1) * hz / sampleRate));\n		const filterbank = [];\n		for (let m = 1; m <= nMels; m++) {\n			const filter = new Float32Array(nFftBins);\n			const left = Math.max(0, Math.min(nFftBins - 1, binPoints[m - 1]));\n			const center = Math.max(0, Math.min(nFftBins - 1, binPoints[m]));\n			const right = Math.max(0, Math.min(nFftBins - 1, binPoints[m + 1]));\n			for (let k = left; k < center; k++) filter[k] = (k - left) / (center - left || 1);\n			for (let k = center; k < right; k++) filter[k] = (right - k) / (right - center || 1);\n			let filterSum = 0;\n			for (let k = 0; k < nFftBins; k++) filterSum += filter[k];\n			if (filterSum === 0) {\n				filter[center] = 1;\n				filterSum = 1;\n			}\n			for (let k = 0; k < nFftBins; k++) filter[k] /= filterSum;\n			filterbank.push(filter);\n		}\n		return filterbank;\n	}\n	/**\n	* Build a sparse mel filterbank for fast application.\n	* Instead of iterating all nFftBins per filter, stores only\n	* the non-zero (startBin, weights[]) ranges.\n	*/\n	function createSparseMelFilterbank(sampleRate, fftSize, nMels, fMin, fMax) {\n		const dense = createMelFilterbank(sampleRate, fftSize, nMels, fMin, fMax);\n		const sparse = new Array(nMels);\n		for (let m = 0; m < nMels; m++) {\n			const f = dense[m];\n			let start = -1, end = 0;\n			for (let k = 0; k < f.length; k++) if (f[k] !== 0) {\n				if (start < 0) start = k;\n				end = k + 1;\n			}\n			if (start < 0) start = 0;\n			const weights = f.subarray(start, end);\n			sparse[m] = {\n				start,\n				weights\n			};\n		}\n		return sparse;\n	}\n	const _twiddleCache = /* @__PURE__ */ new Map();\n	function getTwiddleFactors(n) {\n		if (_twiddleCache.has(n)) return _twiddleCache.get(n);\n		const table = {};\n		for (let len = 2; len <= n; len <<= 1) {\n			const halfLen = len >> 1;\n			const angleStep = -2 * Math.PI / len;\n			const cos = new Float64Array(halfLen);\n			const sin = new Float64Array(halfLen);\n			for (let k = 0; k < halfLen; k++) {\n				const angle = angleStep * k;\n				cos[k] = Math.cos(angle);\n				sin[k] = Math.sin(angle);\n			}\n			table[len] = {\n				cos,\n				sin\n			};\n		}\n		_twiddleCache.set(n, table);\n		return table;\n	}\n	function iterativeFFT(real, imag) {\n		const n = real.length;\n		const twiddle = getTwiddleFactors(n);\n		let j = 0;\n		for (let i = 1; i < n; i++) {\n			let bit = n >> 1;\n			while (j & bit) {\n				j ^= bit;\n				bit >>= 1;\n			}\n			j ^= bit;\n			if (i < j) {\n				let tmp = real[i];\n				real[i] = real[j];\n				real[j] = tmp;\n				tmp = imag[i];\n				imag[i] = imag[j];\n				imag[j] = tmp;\n			}\n		}\n		for (let len = 2; len <= n; len <<= 1) {\n			const halfLen = len >> 1;\n			const { cos, sin } = twiddle[len];\n			for (let i = 0; i < n; i += len) for (let k = 0; k < halfLen; k++) {\n				const evenIndex = i + k;\n				const oddIndex = evenIndex + halfLen;\n				const tr = cos[k] * real[oddIndex] - sin[k] * imag[oddIndex];\n				const ti = sin[k] * real[oddIndex] + cos[k] * imag[oddIndex];\n				real[oddIndex] = real[evenIndex] - tr;\n				imag[oddIndex] = imag[evenIndex] - ti;\n				real[evenIndex] += tr;\n				imag[evenIndex] += ti;\n			}\n		}\n	}\n	/** @param {number} i @param {number} N */\n	function hannWindow(i, N) {\n		return .5 * (1 - Math.cos(2 * Math.PI * i / Math.max(1, N - 1)));\n	}\n	/** @param {number} i @param {number} N */\n	function hammingWindow(i, N) {\n		return .54 - .46 * Math.cos(2 * Math.PI * i / Math.max(1, N - 1));\n	}\n	/** @param {number} i @param {number} N */\n	function blackmanWindow(i, N) {\n		return .42 - .5 * Math.cos(2 * Math.PI * i / Math.max(1, N - 1)) + .08 * Math.cos(4 * Math.PI * i / Math.max(1, N - 1));\n	}\n	/** Blackman-Harris 4-term — excellent sidelobe suppression (−92 dB). */\n	function blackmanHarrisWindow(i, N) {\n		const a0 = .35875, a1 = .48829, a2 = .14128, a3 = .01168;\n		const t = 2 * Math.PI * i / Math.max(1, N - 1);\n		return a0 - a1 * Math.cos(t) + a2 * Math.cos(2 * t) - a3 * Math.cos(3 * t);\n	}\n	/** Flat-top — near-unity amplitude accuracy at the cost of wider main lobe. */\n	function flatTopWindow(i, N) {\n		const a0 = .21557895, a1 = .41663158, a2 = .277263158;\n		const a3 = .083578947, a4 = .006947368;\n		const t = 2 * Math.PI * i / Math.max(1, N - 1);\n		return a0 - a1 * Math.cos(t) + a2 * Math.cos(2 * t) - a3 * Math.cos(3 * t) + a4 * Math.cos(4 * t);\n	}\n	/**\n	* Kaiser window — adjustable via β parameter.\n	* Higher β → narrower main lobe, lower sidelobes.\n	* β≈5: similar to Hamming, β≈8.6: similar to Blackman-Harris.\n	* Uses rational Bessel I₀ approximation (no factorial overflow).\n	*/\n	function kaiserWindow(i, N, beta = 6) {\n		const alpha = Math.max(1, N - 1) / 2;\n		return _besselI0(beta * Math.sqrt(1 - ((i - alpha) / alpha) ** 2)) / _besselI0(beta);\n	}\n	/** Modified Bessel function I₀(x) — polynomial approximation (Abramowitz & Stegun). */\n	function _besselI0(x) {\n		const ax = Math.abs(x);\n		if (ax < 3.75) {\n			const t = (ax / 3.75) ** 2;\n			return 1 + t * (3.5156229 + t * (3.0899424 + t * (1.2067492 + t * (.2659732 + t * (.0360768 + t * .0045813)))));\n		}\n		const t = 3.75 / ax;\n		return Math.exp(ax) / Math.sqrt(ax) * (.39894228 + t * (.01328592 + t * (.00225319 + t * (-.00157565 + t * (.00916281 + t * (-.02057706 + t * (.02635537 + t * (-.01647633 + t * .00392377))))))));\n	}\n	/** @type {Record<string, (i: number, N: number) => number>} */\n	const WINDOW_FUNCTIONS = {\n		hann: hannWindow,\n		hamming: hammingWindow,\n		blackman: blackmanWindow,\n		blackmanHarris: blackmanHarrisWindow,\n		flatTop: flatTopWindow,\n		kaiser: kaiserWindow\n	};\n	/**\n	* IEC 60268-18 fader law: map dB → meter deflection percentage.\n	* Used by the \"Meter\" colour scale to produce perceptually-even brightness.\n	*/\n	function iecDbToFader(db) {\n		if (db < -70) return 0;\n		if (db < -60) return (db + 70) * .25;\n		if (db < -50) return (db + 60) * .5 + 2.5;\n		if (db < -40) return (db + 50) * .75 + 7.5;\n		if (db < -30) return (db + 40) * 1.5 + 15;\n		if (db < -20) return (db + 30) * 2 + 30;\n		return (db + 20) * 2.5 + 50;\n	}\n	iecDbToFader(0);\n	/**\n	* Compute a full spectrogram from raw audio samples.\n	*\n	* @param {Object} params\n	* @param {ArrayBuffer|Float32Array} params.channelData - mono audio samples\n	* @param {number} params.fftSize\n	* @param {number} params.sampleRate\n	* @param {number} params.frameRate      - frames per second\n	* @param {number} params.nMels          - number of mel bins (mel scale)\n	* @param {number} params.pcenGain\n	* @param {number} params.pcenBias\n	* @param {number} params.pcenRoot\n	* @param {number} params.pcenSmoothing\n	* @param {boolean} [params.usePcen=true] - apply PCEN normalisation (false → dB even in mel mode)\n	* @param {string} [params.scale='mel'] - 'mel' or 'linear'\n	* @param {string} [params.colourScale='dbSquared'] - 'linear'|'meter'|'dbSquared'|'db'|'phase'\n	* @param {Float32Array} [params.initialSmooth] - carry-over PCEN smooth state from previous chunk\n	* @param {number} [params.windowSize] - window length in samples (0 or omit = auto: 4×hopSize)\n	* @param {number} [params.hopSize] - hop size in samples (0 or omit = auto: sampleRate/frameRate)\n	* @param {string} [params.windowFunction='hann'] - 'hann' | 'hamming' | 'blackman'\n	*\n	* @returns {{ data: Float32Array, nFrames: number, nMels: number, hopSize: number, winLength: number, colourScale: string, smoothState?: Float32Array }}\n	*/\n	function computeSpectrogram(params) {\n		const { channelData, fftSize, sampleRate, frameRate, nMels, pcenGain, pcenBias, pcenRoot, pcenSmoothing, usePcen = true, scale = \"mel\", initialSmooth, colourScale = \"dbSquared\", windowSize: userWindowSize, hopSize: userHopSize, windowFunction = \"hann\" } = params;\n		const audio = channelData instanceof Float32Array ? channelData : new Float32Array(channelData);\n		const autoHop = Math.max(1, Math.floor(sampleRate / frameRate));\n		const hopSize = userHopSize && userHopSize > 0 ? userHopSize : autoHop;\n		const winLength = userWindowSize && userWindowSize > 0 ? userWindowSize : 4 * hopSize;\n		const numFrames = Math.max(1, Math.floor((audio.length - winLength) / hopSize) + 1);\n		const nBins = Math.floor(fftSize / 2);\n		const useLinear = scale === \"linear\";\n		const useCQT = scale === \"cqt\";\n		const isPhase = colourScale === \"phase\";\n		const outBins = useLinear ? nBins : nMels;\n		const output = new Float32Array(numFrames * outBins);\n		const wfn = WINDOW_FUNCTIONS[windowFunction] || hannWindow;\n		const maxCopy = Math.min(winLength, fftSize);\n		const windowLUT = new Float32Array(maxCopy);\n		for (let i = 0; i < maxCopy; i++) windowLUT[i] = wfn(i, winLength);\n		const real = new Float32Array(fftSize);\n		const imag = new Float32Array(fftSize);\n		const sparseFB = useLinear ? null : useCQT ? createCQTFilterbank(sampleRate, fftSize, nMels) : createSparseMelFilterbank(sampleRate, fftSize, nMels, 0, sampleRate / 2);\n		const denseFB = isPhase && !useLinear ? createMelFilterbank(sampleRate, fftSize, nMels, 0, sampleRate / 2) : null;\n		const powerBuf = !useLinear && !isPhase ? new Float32Array(nBins) : null;\n		/** Apply windowed frame into reusable buffers and run FFT in-place. */\n		function runFFT(offset) {\n			real.fill(0);\n			imag.fill(0);\n			for (let i = 0; i < maxCopy; i++) real[i] = (audio[offset + i] || 0) * windowLUT[i];\n			iterativeFFT(real, imag);\n		}\n		let smooth = null;\n		if (isPhase) for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {\n			runFFT(frameIdx * hopSize);\n			const base = frameIdx * outBins;\n			if (useLinear) for (let k = 0; k < nBins; k++) output[base + k] = Math.atan2(imag[k], real[k]);\n			else for (let m = 0; m < nMels; m++) {\n				const f = denseFB[m];\n				let sumSin = 0, sumCos = 0;\n				for (let k = 0; k < f.length; k++) if (f[k] > 0) {\n					const ph = Math.atan2(imag[k], real[k]);\n					sumSin += f[k] * Math.sin(ph);\n					sumCos += f[k] * Math.cos(ph);\n				}\n				output[base + m] = Math.atan2(sumSin, sumCos);\n			}\n		}\n		else if (useLinear) {\n			const wantRaw = colourScale === \"linear\" || colourScale === \"meter\";\n			for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {\n				runFFT(frameIdx * hopSize);\n				const base = frameIdx * nBins;\n				if (wantRaw) for (let k = 0; k < nBins; k++) output[base + k] = Math.sqrt(real[k] * real[k] + imag[k] * imag[k]);\n				else for (let k = 0; k < nBins; k++) {\n					const p = real[k] * real[k] + imag[k] * imag[k];\n					output[base + k] = 10 * Math.log10(Math.max(1e-20, p));\n				}\n			}\n		} else if (!usePcen) {\n			const wantRaw = colourScale === \"linear\" || colourScale === \"meter\";\n			for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {\n				runFFT(frameIdx * hopSize);\n				for (let k = 0; k < nBins; k++)\n /** @type {!Float32Array} */ powerBuf[k] = real[k] * real[k] + imag[k] * imag[k];\n				const base = frameIdx * nMels;\n				for (let m = 0; m < nMels; m++) {\n					const { start, weights } = sparseFB[m];\n					let sum = 0;\n					for (let k = 0; k < weights.length; k++) sum += powerBuf[start + k] * weights[k];\n					if (wantRaw) output[base + m] = Math.sqrt(Math.max(0, sum));\n					else output[base + m] = 10 * Math.log10(Math.max(1e-10, sum));\n				}\n			}\n		} else {\n			smooth = new Float32Array(nMels);\n			if (initialSmooth && initialSmooth.length === nMels) smooth.set(initialSmooth);\n			const pcenPower = 1 / pcenRoot;\n			const pcenBiasOffset = Math.pow(pcenBias, pcenPower);\n			for (let frameIdx = 0; frameIdx < numFrames; frameIdx++) {\n				runFFT(frameIdx * hopSize);\n				for (let k = 0; k < nBins; k++)\n /** @type {!Float32Array} */ powerBuf[k] = real[k] * real[k] + imag[k] * imag[k];\n				const base = frameIdx * nMels;\n				for (let m = 0; m < nMels; m++) {\n					const { start, weights } = sparseFB[m];\n					let e = 0;\n					for (let k = 0; k < weights.length; k++) e += powerBuf[start + k] * weights[k];\n					smooth[m] = (1 - pcenSmoothing) * smooth[m] + pcenSmoothing * e;\n					const denom = Math.pow(1e-10 + smooth[m], pcenGain);\n					const norm = e / denom;\n					output[base + m] = Math.pow(norm + pcenBias, pcenPower) - pcenBiasOffset;\n				}\n			}\n		}\n		const result = {\n			data: output,\n			nFrames: numFrames,\n			nMels: outBins,\n			hopSize,\n			winLength,\n			colourScale\n		};\n		if (smooth) result.smoothState = smooth;\n		return result;\n	}\n	/**\n	* Build a CQT (Constant-Q) filterbank that maps STFT bins to\n	* log-spaced frequency bins with constant Q factor.\n	* Returns a sparse filterbank compatible with applySparseMelFilterbank.\n	*\n	* @param {number} sampleRate\n	* @param {number} fftSize\n	* @param {number} nBinsOut        - desired number of output bins\n	* @param {number} [fMin=32.7]     - lowest frequency (Hz), default C1\n	* @param {number} [binsPerOctave=24]\n	*/\n	function createCQTFilterbank(sampleRate, fftSize, nBinsOut, fMin = 32.7, binsPerOctave = 24) {\n		const nFftBins = Math.floor(fftSize / 2);\n		const nyquist = sampleRate / 2;\n		const Q = 1 / (Math.pow(2, 1 / binsPerOctave) - 1);\n		const sparse = new Array(nBinsOut);\n		for (let k = 0; k < nBinsOut; k++) {\n			const fCenter = fMin * Math.pow(2, k / binsPerOctave);\n			if (fCenter >= nyquist) {\n				sparse[k] = {\n					start: nFftBins - 1,\n					weights: new Float32Array([1])\n				};\n				continue;\n			}\n			const bw = fCenter / Q;\n			const fLo = Math.max(0, fCenter - bw / 2);\n			const fHi = Math.min(nyquist, fCenter + bw / 2);\n			const binLo = Math.max(0, Math.floor(fLo * fftSize / sampleRate));\n			const len = Math.min(nFftBins - 1, Math.ceil(fHi * fftSize / sampleRate)) - binLo + 1;\n			const weights = new Float32Array(len);\n			let sum = 0;\n			for (let b = 0; b < len; b++) {\n				const fBin = (binLo + b) * sampleRate / fftSize;\n				const dist = Math.abs(fBin - fCenter) / (bw / 2 + 1e-12);\n				weights[b] = Math.max(0, 1 - dist);\n				sum += weights[b];\n			}\n			if (sum > 0) for (let b = 0; b < len; b++) weights[b] /= sum;\n			else if (len > 0) weights[0] = 1;\n			sparse[k] = {\n				start: binLo,\n				weights\n			};\n		}\n		return sparse;\n	}\n	//#endregion\n	//#region src/spectrogram.worker.js\n	self.onmessage = (event) => {\n		const { requestId, channelData, ...options } = event.data;\n		const result = computeSpectrogram({\n			channelData: new Float32Array(channelData),\n			...options\n		});\n		const msg = {\n			requestId,\n			data: result.data.buffer,\n			nFrames: result.nFrames,\n			nMels: result.nMels,\n			hopSize: result.hopSize,\n			winLength: result.winLength,\n			colourScale: result.colourScale\n		};\n		const transfer = [result.data.buffer];\n		if (result.smoothState) {\n			msg.smoothState = result.smoothState.buffer;\n			transfer.push(result.smoothState.buffer);\n		}\n		self.postMessage(msg, { transfer });\n	};\n	//#endregion\n})();\n\n//# sourceMappingURL=spectrogram.worker-BNIh35yw.js.map";
		blob = typeof self !== "undefined" && self.Blob && new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);", jsContent], { type: "text/javascript;charset=utf-8" });
	}));
	//#endregion
	//#region src/spectrogram.js
	var _WorkerCtor = null;
	var _workerCtorResolved = false;
	async function getWorkerCtor() {
		if (_workerCtorResolved) return _WorkerCtor;
		_workerCtorResolved = true;
		try {
			_WorkerCtor = (await Promise.resolve().then(() => (init_spectrogram_worker(), spectrogram_worker_exports))).default;
		} catch {
			_WorkerCtor = null;
		}
		return _WorkerCtor;
	}
	function computeAmplitudePeak(channelData) {
		let peak = 0;
		for (let i = 0; i < channelData.length; i++) {
			const abs = Math.abs(channelData[i]);
			if (abs > peak) peak = abs;
		}
		return Math.max(1e-6, peak);
	}
	var COLOR_MAPS = {
		inferno: [
			[
				0,
				0,
				4
			],
			[
				31,
				12,
				72
			],
			[
				85,
				15,
				109
			],
			[
				136,
				34,
				106
			],
			[
				186,
				54,
				85
			],
			[
				227,
				89,
				51
			],
			[
				249,
				140,
				10
			],
			[
				252,
				201,
				40
			],
			[
				252,
				255,
				164
			]
		],
		viridis: [
			[
				68,
				1,
				84
			],
			[
				68,
				2,
				86
			],
			[
				69,
				4,
				87
			],
			[
				69,
				5,
				89
			],
			[
				70,
				7,
				90
			],
			[
				70,
				8,
				92
			],
			[
				70,
				10,
				93
			],
			[
				70,
				11,
				94
			],
			[
				71,
				13,
				96
			],
			[
				71,
				14,
				97
			],
			[
				71,
				16,
				99
			],
			[
				71,
				17,
				100
			],
			[
				71,
				19,
				101
			],
			[
				72,
				20,
				103
			],
			[
				72,
				22,
				104
			],
			[
				72,
				23,
				105
			],
			[
				72,
				24,
				106
			],
			[
				72,
				26,
				108
			],
			[
				72,
				27,
				109
			],
			[
				72,
				28,
				110
			],
			[
				72,
				29,
				111
			],
			[
				72,
				31,
				112
			],
			[
				72,
				32,
				113
			],
			[
				72,
				33,
				115
			],
			[
				72,
				35,
				116
			],
			[
				72,
				36,
				117
			],
			[
				72,
				37,
				118
			],
			[
				72,
				38,
				119
			],
			[
				72,
				40,
				120
			],
			[
				72,
				41,
				121
			],
			[
				71,
				42,
				122
			],
			[
				71,
				44,
				122
			],
			[
				71,
				45,
				123
			],
			[
				71,
				46,
				124
			],
			[
				71,
				47,
				125
			],
			[
				70,
				48,
				126
			],
			[
				70,
				50,
				126
			],
			[
				70,
				51,
				127
			],
			[
				69,
				52,
				128
			],
			[
				69,
				53,
				129
			],
			[
				69,
				55,
				129
			],
			[
				68,
				56,
				130
			],
			[
				68,
				57,
				131
			],
			[
				68,
				58,
				131
			],
			[
				67,
				60,
				132
			],
			[
				67,
				61,
				132
			],
			[
				66,
				62,
				133
			],
			[
				66,
				63,
				133
			],
			[
				66,
				64,
				134
			],
			[
				65,
				66,
				134
			],
			[
				65,
				67,
				135
			],
			[
				64,
				68,
				135
			],
			[
				64,
				69,
				136
			],
			[
				63,
				71,
				136
			],
			[
				63,
				72,
				137
			],
			[
				62,
				73,
				137
			],
			[
				62,
				74,
				137
			],
			[
				62,
				76,
				138
			],
			[
				61,
				77,
				138
			],
			[
				61,
				78,
				138
			],
			[
				60,
				79,
				139
			],
			[
				60,
				80,
				139
			],
			[
				59,
				82,
				139
			],
			[
				59,
				83,
				140
			],
			[
				58,
				84,
				140
			],
			[
				58,
				85,
				140
			],
			[
				57,
				86,
				141
			],
			[
				57,
				88,
				141
			],
			[
				56,
				89,
				141
			],
			[
				56,
				90,
				141
			],
			[
				55,
				91,
				142
			],
			[
				55,
				92,
				142
			],
			[
				54,
				94,
				142
			],
			[
				54,
				95,
				142
			],
			[
				53,
				96,
				142
			],
			[
				53,
				97,
				143
			],
			[
				52,
				98,
				143
			],
			[
				52,
				99,
				143
			],
			[
				51,
				101,
				143
			],
			[
				51,
				102,
				143
			],
			[
				50,
				103,
				144
			],
			[
				50,
				104,
				144
			],
			[
				49,
				105,
				144
			],
			[
				49,
				106,
				144
			],
			[
				49,
				108,
				144
			],
			[
				48,
				109,
				144
			],
			[
				48,
				110,
				144
			],
			[
				47,
				111,
				145
			],
			[
				47,
				112,
				145
			],
			[
				46,
				113,
				145
			],
			[
				46,
				114,
				145
			],
			[
				45,
				116,
				145
			],
			[
				45,
				117,
				145
			],
			[
				44,
				118,
				145
			],
			[
				44,
				119,
				145
			],
			[
				44,
				120,
				146
			],
			[
				43,
				121,
				146
			],
			[
				43,
				122,
				146
			],
			[
				42,
				123,
				146
			],
			[
				42,
				125,
				146
			],
			[
				42,
				126,
				146
			],
			[
				41,
				127,
				146
			],
			[
				41,
				128,
				146
			],
			[
				40,
				129,
				146
			],
			[
				40,
				130,
				146
			],
			[
				40,
				131,
				146
			],
			[
				39,
				132,
				146
			],
			[
				39,
				133,
				146
			],
			[
				38,
				134,
				146
			],
			[
				38,
				136,
				146
			],
			[
				38,
				137,
				146
			],
			[
				37,
				138,
				146
			],
			[
				37,
				139,
				146
			],
			[
				36,
				140,
				146
			],
			[
				36,
				141,
				146
			],
			[
				36,
				142,
				146
			],
			[
				35,
				143,
				146
			],
			[
				35,
				144,
				146
			],
			[
				35,
				145,
				146
			],
			[
				34,
				146,
				146
			],
			[
				34,
				147,
				146
			],
			[
				33,
				148,
				146
			],
			[
				33,
				149,
				146
			],
			[
				33,
				150,
				146
			],
			[
				32,
				151,
				145
			],
			[
				32,
				152,
				145
			],
			[
				32,
				153,
				145
			],
			[
				31,
				154,
				145
			],
			[
				31,
				155,
				145
			],
			[
				31,
				156,
				145
			],
			[
				30,
				157,
				144
			],
			[
				30,
				158,
				144
			],
			[
				30,
				159,
				144
			],
			[
				30,
				160,
				144
			],
			[
				29,
				161,
				143
			],
			[
				29,
				162,
				143
			],
			[
				29,
				163,
				143
			],
			[
				29,
				164,
				142
			],
			[
				28,
				165,
				142
			],
			[
				28,
				166,
				142
			],
			[
				28,
				167,
				141
			],
			[
				28,
				168,
				141
			],
			[
				28,
				169,
				141
			],
			[
				27,
				170,
				140
			],
			[
				27,
				171,
				140
			],
			[
				27,
				172,
				139
			],
			[
				27,
				173,
				139
			],
			[
				27,
				174,
				138
			],
			[
				27,
				175,
				138
			],
			[
				27,
				176,
				137
			],
			[
				27,
				177,
				137
			],
			[
				27,
				178,
				136
			],
			[
				27,
				179,
				136
			],
			[
				27,
				180,
				135
			],
			[
				27,
				181,
				135
			],
			[
				27,
				182,
				134
			],
			[
				27,
				183,
				133
			],
			[
				28,
				184,
				133
			],
			[
				28,
				185,
				132
			],
			[
				28,
				186,
				131
			],
			[
				29,
				187,
				131
			],
			[
				29,
				188,
				130
			],
			[
				29,
				189,
				129
			],
			[
				30,
				190,
				129
			],
			[
				30,
				190,
				128
			],
			[
				31,
				191,
				127
			],
			[
				31,
				192,
				126
			],
			[
				32,
				193,
				126
			],
			[
				33,
				194,
				125
			],
			[
				33,
				195,
				124
			],
			[
				34,
				196,
				123
			],
			[
				35,
				197,
				123
			],
			[
				36,
				198,
				122
			],
			[
				37,
				198,
				121
			],
			[
				37,
				199,
				120
			],
			[
				38,
				200,
				119
			],
			[
				39,
				201,
				118
			],
			[
				40,
				202,
				118
			],
			[
				41,
				203,
				117
			],
			[
				42,
				203,
				116
			],
			[
				44,
				204,
				115
			],
			[
				45,
				205,
				114
			],
			[
				46,
				206,
				113
			],
			[
				47,
				207,
				112
			],
			[
				49,
				207,
				111
			],
			[
				50,
				208,
				110
			],
			[
				51,
				209,
				109
			],
			[
				53,
				210,
				108
			],
			[
				54,
				210,
				107
			],
			[
				56,
				211,
				106
			],
			[
				57,
				212,
				105
			],
			[
				59,
				213,
				104
			],
			[
				60,
				213,
				103
			],
			[
				62,
				214,
				102
			],
			[
				64,
				215,
				101
			],
			[
				65,
				215,
				100
			],
			[
				67,
				216,
				98
			],
			[
				69,
				217,
				97
			],
			[
				70,
				217,
				96
			],
			[
				72,
				218,
				95
			],
			[
				74,
				219,
				94
			],
			[
				76,
				219,
				93
			],
			[
				78,
				220,
				91
			],
			[
				80,
				221,
				90
			],
			[
				82,
				221,
				89
			],
			[
				83,
				222,
				88
			],
			[
				85,
				222,
				86
			],
			[
				87,
				223,
				85
			],
			[
				89,
				224,
				84
			],
			[
				91,
				224,
				83
			],
			[
				94,
				225,
				81
			],
			[
				96,
				225,
				80
			],
			[
				98,
				226,
				79
			],
			[
				100,
				226,
				77
			],
			[
				102,
				227,
				76
			],
			[
				104,
				227,
				75
			],
			[
				106,
				228,
				73
			],
			[
				109,
				228,
				72
			],
			[
				111,
				229,
				71
			],
			[
				113,
				229,
				69
			],
			[
				115,
				230,
				68
			],
			[
				118,
				230,
				66
			],
			[
				120,
				231,
				65
			],
			[
				122,
				231,
				64
			],
			[
				125,
				232,
				62
			],
			[
				127,
				232,
				61
			],
			[
				129,
				232,
				59
			],
			[
				132,
				233,
				58
			],
			[
				134,
				233,
				56
			],
			[
				137,
				234,
				55
			],
			[
				139,
				234,
				53
			],
			[
				141,
				235,
				52
			],
			[
				144,
				235,
				50
			],
			[
				146,
				235,
				49
			],
			[
				149,
				236,
				47
			],
			[
				151,
				236,
				46
			],
			[
				154,
				236,
				45
			],
			[
				156,
				237,
				43
			],
			[
				159,
				237,
				42
			],
			[
				161,
				237,
				40
			],
			[
				163,
				238,
				39
			],
			[
				166,
				238,
				38
			],
			[
				168,
				238,
				36
			],
			[
				171,
				239,
				35
			],
			[
				173,
				239,
				34
			],
			[
				176,
				239,
				32
			],
			[
				178,
				239,
				31
			],
			[
				181,
				240,
				30
			],
			[
				183,
				240,
				29
			],
			[
				186,
				240,
				28
			],
			[
				188,
				240,
				27
			],
			[
				191,
				241,
				26
			],
			[
				193,
				241,
				25
			],
			[
				195,
				241,
				24
			],
			[
				198,
				241,
				23
			],
			[
				200,
				241,
				23
			],
			[
				203,
				241,
				22
			],
			[
				205,
				242,
				22
			],
			[
				207,
				242,
				21
			],
			[
				210,
				242,
				21
			],
			[
				212,
				242,
				21
			],
			[
				214,
				242,
				21
			],
			[
				217,
				242,
				20
			],
			[
				219,
				242,
				20
			],
			[
				221,
				243,
				20
			],
			[
				224,
				243,
				21
			],
			[
				226,
				243,
				21
			],
			[
				228,
				243,
				21
			],
			[
				230,
				243,
				22
			],
			[
				232,
				243,
				22
			],
			[
				235,
				243,
				23
			],
			[
				237,
				244,
				24
			],
			[
				239,
				244,
				25
			],
			[
				241,
				244,
				26
			],
			[
				243,
				244,
				27
			],
			[
				245,
				244,
				28
			],
			[
				247,
				244,
				30
			],
			[
				249,
				244,
				31
			],
			[
				251,
				245,
				33
			],
			[
				253,
				245,
				35
			]
		],
		magma: [
			[
				0,
				0,
				4
			],
			[
				28,
				16,
				68
			],
			[
				79,
				18,
				123
			],
			[
				129,
				37,
				129
			],
			[
				181,
				54,
				122
			],
			[
				229,
				80,
				100
			],
			[
				251,
				135,
				97
			],
			[
				254,
				194,
				135
			],
			[
				252,
				253,
				191
			]
		],
		plasma: [
			[
				13,
				8,
				135
			],
			[
				75,
				3,
				161
			],
			[
				125,
				3,
				168
			],
			[
				168,
				34,
				150
			],
			[
				203,
				70,
				121
			],
			[
				229,
				107,
				93
			],
			[
				248,
				148,
				65
			],
			[
				253,
				195,
				40
			],
			[
				240,
				249,
				33
			]
		],
		xenocanto: [
			[
				0,
				0,
				0
			],
			[
				30,
				10,
				5
			],
			[
				65,
				20,
				10
			],
			[
				110,
				35,
				15
			],
			[
				160,
				55,
				15
			],
			[
				200,
				85,
				20
			],
			[
				230,
				130,
				30
			],
			[
				245,
				180,
				60
			],
			[
				255,
				220,
				110
			],
			[
				255,
				245,
				180
			],
			[
				255,
				255,
				255
			]
		]
	};
	function sampleColorMap(stops, t) {
		if (!stops || stops.length === 0) return {
			r: 0,
			g: 0,
			b: 0
		};
		if (stops.length === 1) return {
			r: stops[0][0],
			g: stops[0][1],
			b: stops[0][2]
		};
		const pos = Math.max(0, Math.min(1, t)) * (stops.length - 1);
		const idx = Math.floor(pos);
		const frac = pos - idx;
		const a = stops[idx];
		const b = stops[Math.min(stops.length - 1, idx + 1)];
		return {
			r: Math.round(a[0] + (b[0] - a[0]) * frac),
			g: Math.round(a[1] + (b[1] - a[1]) * frac),
			b: Math.round(a[2] + (b[2] - a[2]) * frac)
		};
	}
	function getSpectrogramColor(value, colorScheme) {
		const x = Math.max(0, Math.min(1, value));
		if (colorScheme === "grayscale") {
			const v = Math.round((1 - x) * 255);
			return {
				r: v,
				g: v,
				b: v
			};
		}
		if (colorScheme === "viridis") {
			const palette = COLOR_MAPS.viridis;
			const color = palette[Math.min(palette.length - 1, Math.floor(x * (palette.length - 1)))];
			return {
				r: color[0],
				g: color[1],
				b: color[2]
			};
		}
		if (colorScheme === "fire") return {
			r: Math.round(255 * Math.pow(x, .7)),
			g: Math.round(255 * Math.max(0, Math.min(1, (x - .15) / .85))),
			b: Math.round(255 * Math.max(0, Math.min(1, (x - .45) / .55)))
		};
		return sampleColorMap(COLOR_MAPS[colorScheme] || COLOR_MAPS.inferno, x);
	}
	var _VS = `#version 300 es
in vec2 a_pos;
out vec2 v_uv;
void main() {
    v_uv = vec2(a_pos.x * 0.5 + 0.5, 0.5 - a_pos.y * 0.5);
    gl_Position = vec4(a_pos, 0.0, 1.0);
}`;
	var _FS = `#version 300 es
precision mediump float;
uniform sampler2D u_gray;
uniform sampler2D u_lut;
uniform float u_floor;
uniform float u_rcpRange;
in vec2 v_uv;
out vec4 fragColor;
void main() {
    float g = texture(u_gray, v_uv).r;
    float t = clamp((g - u_floor) * u_rcpRange, 0.0, 1.0);
    fragColor = texture(u_lut, vec2(t, 0.5));
}`;
	var GpuColorizer = class {
		constructor() {
			this._canvas = document.createElement("canvas");
			const gl = this._canvas.getContext("webgl2", {
				premultipliedAlpha: false,
				preserveDrawingBuffer: true,
				antialias: false
			});
			if (!gl) {
				this._gl = null;
				return;
			}
			this._gl = gl;
			this._maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE);
			const vs = this._sh(gl.VERTEX_SHADER, _VS);
			const fs = this._sh(gl.FRAGMENT_SHADER, _FS);
			if (!vs || !fs) {
				this._gl = null;
				return;
			}
			const p = gl.createProgram();
			gl.attachShader(p, vs);
			gl.attachShader(p, fs);
			gl.linkProgram(p);
			gl.deleteShader(vs);
			gl.deleteShader(fs);
			if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
				this._gl = null;
				return;
			}
			/** @type {WebGLProgram | null} */
			this._prog = p;
			/** @type {WebGLUniformLocation | null} */
			this._uFloor = gl.getUniformLocation(p, "u_floor");
			/** @type {WebGLUniformLocation | null} */
			this._uRcpRange = gl.getUniformLocation(p, "u_rcpRange");
			/** @type {WebGLUniformLocation | null} */
			this._uGray = gl.getUniformLocation(p, "u_gray");
			/** @type {WebGLUniformLocation | null} */
			this._uLut = gl.getUniformLocation(p, "u_lut");
			/** @type {WebGLVertexArrayObject | null} */
			const vao = gl.createVertexArray();
			gl.bindVertexArray(vao);
			const buf = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, buf);
			gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
				-1,
				-1,
				1,
				-1,
				-1,
				1,
				1,
				1
			]), gl.STATIC_DRAW);
			const loc = gl.getAttribLocation(p, "a_pos");
			gl.enableVertexAttribArray(loc);
			gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
			this._vao = vao;
			/** @type {WebGLTexture | null} */
			this._grayTex = gl.createTexture();
			/** @type {WebGLTexture | null} */
			this._lutTex = gl.createTexture();
			/** @type {number} */
			this._w = 0;
			/** @type {number} */
			this._h = 0;
			this._lutScheme = null;
		}
		/** @private */ _sh(type, src) {
			const gl = this._gl;
			if (!gl) return null;
			const s = gl.createShader(type);
			if (!s) return null;
			gl.shaderSource(s, src);
			gl.compileShader(s);
			if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
				gl.deleteShader(s);
				return null;
			}
			return s;
		}
		get ok() {
			return !!this._gl;
		}
		get canvas() {
			return this._canvas;
		}
		/** Upload Float32 grayscale map (values 0-1) as a R32F texture. Returns success. */
		uploadGrayscale(gray, width, height) {
			const gl = this._gl;
			if (!gl || width > this._maxTex || height > this._maxTex) return false;
			this._w = width;
			this._h = height;
			this._canvas.width = width;
			this._canvas.height = height;
			gl.bindTexture(gl.TEXTURE_2D, this._grayTex);
			gl.texImage2D(gl.TEXTURE_2D, 0, gl.R32F, width, height, 0, gl.RED, gl.FLOAT, gray);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
			return true;
		}
		/** Build 256-entry RGBA color look-up texture from a color scheme. */
		uploadColorLut(scheme) {
			if (scheme === this._lutScheme) return;
			const gl = this._gl;
			if (!gl) return;
			this._lutScheme = scheme;
			const d = new Uint8Array(256 * 4);
			for (let i = 0; i < 256; i++) {
				const c = getSpectrogramColor(i / 255, scheme);
				const o = i * 4;
				d[o] = c.r;
				d[o + 1] = c.g;
				d[o + 2] = c.b;
				d[o + 3] = 255;
			}
			gl.bindTexture(gl.TEXTURE_2D, this._lutTex);
			gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 256, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, d);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		}
		/** Render colorized spectrogram. floor01/ceil01 ∈ [0,1]. ~0.1 ms. */
		render(floor01, ceil01) {
			const gl = this._gl;
			if (!gl || !this._w || !this._prog || !this._vao) return;
			gl.viewport(0, 0, this._w, this._h);
			gl.useProgram(this._prog);
			gl.bindVertexArray(this._vao);
			gl.activeTexture(gl.TEXTURE0);
			gl.bindTexture(gl.TEXTURE_2D, this._grayTex);
			gl.uniform1i(this._uGray, 0);
			gl.activeTexture(gl.TEXTURE1);
			gl.bindTexture(gl.TEXTURE_2D, this._lutTex);
			gl.uniform1i(this._uLut, 1);
			gl.uniform1f(this._uFloor, floor01);
			gl.uniform1f(this._uRcpRange, 1 / Math.max(1e-4, ceil01 - floor01));
			gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
		}
		dispose() {
			const gl = this._gl;
			if (!gl) return;
			if (this._grayTex) gl.deleteTexture(this._grayTex);
			if (this._lutTex) gl.deleteTexture(this._lutTex);
			if (this._prog) gl.deleteProgram(this._prog);
			if (this._vao) gl.deleteVertexArray(this._vao);
			this._gl = null;
		}
	};
	function updateSpectrogramStats(spectrogramData) {
		if (!spectrogramData || spectrogramData.length === 0) return {
			logMin: 0,
			logMax: 1
		};
		let minLog = Number.POSITIVE_INFINITY;
		let maxLog = Number.NEGATIVE_INFINITY;
		const stride = Math.max(1, Math.floor(spectrogramData.length / 12e4));
		for (let i = 0; i < spectrogramData.length; i += stride) {
			const mapped = spectrogramData[i] || 0;
			if (mapped < minLog) minLog = mapped;
			if (mapped > maxLog) maxLog = mapped;
		}
		if (!Number.isFinite(minLog) || !Number.isFinite(maxLog) || maxLog - minLog < 1e-6) return {
			logMin: 0,
			logMax: 1
		};
		return {
			logMin: minLog,
			logMax: maxLog
		};
	}
	/**
	* Computes tighter logMin/logMax from the PCEN data using percentiles,
	* cutting away noise-floor and rare hot-spots for better visual contrast.
	* @param {Float32Array} spectrogramData  - flat PCEN output (nFrames × nMels)
	* @param {number} [loPercentile=2]       - lower percentile (black point)
	* @param {number} [hiPercentile=98]      - upper percentile (white point)
	*/
	function autoContrastStats(spectrogramData, loPercentile = 2, hiPercentile = 98) {
		if (!spectrogramData || spectrogramData.length === 0) return {
			logMin: 0,
			logMax: 1
		};
		const stride = Math.max(1, Math.floor(spectrogramData.length / 2e5));
		const mapped = [];
		for (let i = 0; i < spectrogramData.length; i += stride) mapped.push(spectrogramData[i] || 0);
		mapped.sort((a, b) => a - b);
		const loIdx = Math.floor(mapped.length * loPercentile / 100);
		const hiIdx = Math.min(mapped.length - 1, Math.floor(mapped.length * hiPercentile / 100));
		const logMin = mapped[loIdx];
		const logMax = mapped[hiIdx];
		if (!Number.isFinite(logMin) || !Number.isFinite(logMax) || logMax - logMin < 1e-6) return {
			logMin: 0,
			logMax: 1
		};
		return {
			logMin,
			logMax
		};
	}
	/**
	* Detects the effective upper frequency boundary by finding the highest
	* bin that carries meaningful energy above the noise floor.
	* Returns a frequency in Hz suitable as maxFreq.
	* @param {Float32Array} spectrogramData
	* @param {number} nFrames
	* @param {number} nMels
	* @param {number} sampleRate
	* @param {string} [scale='mel'] - 'mel' or 'linear'
	* @param {number} [energyThreshold=0.08] - fraction of peak-bin energy
	*/
	function detectMaxFrequency(spectrogramData, nFrames, nMels, sampleRate, scale = "mel", energyThreshold = .08) {
		if (!spectrogramData || nFrames <= 0 || nMels <= 0) return sampleRate / 2;
		const binEnergy = new Float64Array(nMels);
		const stride = Math.max(1, Math.floor(nFrames / 2e3));
		let sampledFrames = 0;
		for (let f = 0; f < nFrames; f += stride) {
			const base = f * nMels;
			for (let m = 0; m < nMels; m++) binEnergy[m] += spectrogramData[base + m] || 0;
			sampledFrames++;
		}
		for (let m = 0; m < nMels; m++) binEnergy[m] /= sampledFrames;
		let peakEnergy = -Infinity;
		for (let m = 0; m < nMels; m++) if (binEnergy[m] > peakEnergy) peakEnergy = binEnergy[m];
		if (!isFinite(peakEnergy)) return sampleRate / 2;
		if (peakEnergy >= 0 && peakEnergy < 1e-12) return sampleRate / 2;
		const threshold = peakEnergy < 0 ? peakEnergy + 10 * Math.log10(Math.max(1e-10, energyThreshold)) : peakEnergy * energyThreshold;
		const activeBins = [];
		for (let m = 0; m < nMels; m++) if (binEnergy[m] > threshold) activeBins.push(m);
		if (activeBins.length === 0) return sampleRate / 2;
		const upperBin = activeBins[Math.min(activeBins.length - 1, Math.ceil(activeBins.length * .95) - 1)];
		let detectedHz;
		if (scale === "linear") {
			const binHz = sampleRate / 2 / nMels;
			detectedHz = Math.min(nMels - 1, upperBin) * binHz;
		} else detectedHz = buildMelFrequencies(sampleRate, nMels)[Math.min(nMels - 1, upperBin)] || sampleRate / 2;
		const withMargin = detectedHz * 1.1;
		const steps = [
			2e3,
			3e3,
			4e3,
			5e3,
			6e3,
			8e3,
			1e4,
			12e3,
			16e3,
			2e4,
			22050
		];
		const nyquist = sampleRate / 2;
		let best = nyquist;
		for (const s of steps) if (s >= withMargin && s <= nyquist) {
			best = s;
			break;
		}
		return best;
	}
	function drawTimeGrid({ ctx, width, height, duration, pixelsPerSecond }) {
		if (width <= 0) return;
		const majorColor = getComputedStyle(document.documentElement).getPropertyValue("--color-text-secondary").trim() || "#cbd5e1";
		const { majorStep, minorStep } = getTimeGridSteps(pixelsPerSecond);
		ctx.save();
		ctx.font = "11px monospace";
		ctx.textBaseline = "top";
		for (let t = 0; t <= duration; t += minorStep) {
			const x = Math.round(t * pixelsPerSecond) + .5;
			if (x < 0 || x > width) continue;
			const isMajor = Math.abs(t / majorStep - Math.round(t / majorStep)) < 1e-4;
			ctx.strokeStyle = isMajor ? "rgba(148,163,184,0.35)" : "rgba(148,163,184,0.18)";
			ctx.beginPath();
			ctx.moveTo(x, 0);
			ctx.lineTo(x, height);
			ctx.stroke();
			if (isMajor) {
				ctx.fillStyle = majorColor;
				ctx.fillText(`${t.toFixed(1)}s`, x + 3, 4);
			}
		}
		ctx.restore();
	}
	/**
	* Stage 1 - Expensive, done ONCE per audio / fftSize / maxFreq change.
	* Converts spectrogram data → 8-bit grayscale image (Uint8Array).
	* Frame-averaging and mel→y mapping happens here.
	* The `colourScale` parameter controls how raw values map to pixel brightness:
	*   - 'dbSquared' / 'db' / PCEN: linear range mapping (existing behavior)
	*   - 'linear': proportional magnitude mapping
	*   - 'meter': IEC 60268-18 perceptual meter curve
	*   - 'phase': −π…+π → 0…255
	*/
	function buildSpectrogramGrayscale({ spectrogramData, spectrogramFrames, spectrogramMels, sampleRateHz, maxFreq, spectrogramAbsLogMin, spectrogramAbsLogMax, scale = "mel", colourScale = "dbSquared", noiseReduction = false, clahe = false }) {
		if (!spectrogramData || spectrogramFrames <= 0 || spectrogramMels <= 0) return null;
		const width = Math.max(1, Math.min(spectrogramFrames, MAX_BASE_SPECTROGRAM_WIDTH));
		const height = spectrogramMels;
		const framesPerPixel = spectrogramFrames / width;
		const isLinear = scale === "linear";
		const boundedMaxFreq = Math.min(maxFreq, sampleRateHz / 2);
		const melFreqs = isLinear ? null : buildMelFrequencies(sampleRateHz, spectrogramMels);
		const maxBin = computeMaxBin({
			isLinear,
			nyquist: sampleRateHz / 2,
			spectrogramMels,
			boundedMaxFreq,
			melFreqs
		});
		const yBinLo = new Int16Array(height);
		const yBinHi = new Int16Array(height);
		const yBinFrac = new Float32Array(height);
		for (let y = 0; y < height; y++) {
			const fracBin = (height - 1 - y) / (height - 1) * maxBin;
			const lo = Math.max(0, Math.min(maxBin, Math.floor(fracBin)));
			const hi = Math.min(maxBin, lo + 1);
			yBinLo[y] = lo;
			yBinHi[y] = hi;
			yBinFrac[y] = fracBin - lo;
		}
		let cleanData = spectrogramData;
		if (noiseReduction && colourScale !== "phase") cleanData = spectralSubtract(spectrogramData, spectrogramFrames, spectrogramMels);
		const dataRange = Math.max(1e-6, spectrogramAbsLogMax - spectrogramAbsLogMin);
		const gray = new Float32Array(width * height);
		const IEC_MAX = colourScale === "meter" ? iecDbToFader(0) : 0;
		for (let x = 0; x < width; x++) {
			const frameStart = Math.round(x * framesPerPixel);
			const frameEnd = Math.max(frameStart + 1, Math.round((x + 1) * framesPerPixel));
			for (let y = 0; y < height; y++) {
				const binLo = yBinLo[y];
				const binHi = yBinHi[y];
				const frac = yBinFrac[y];
				let sumLo = 0, sumHi = 0, count = 0;
				for (let frame = frameStart; frame < frameEnd; frame++) {
					const base = frame * spectrogramMels;
					sumLo += cleanData[base + binLo] || 0;
					sumHi += cleanData[base + binHi] || 0;
					count++;
				}
				const value = (sumLo + (sumHi - sumLo) * frac) / Math.max(1, count);
				let pixel;
				if (colourScale === "phase") pixel = (value + Math.PI) / (2 * Math.PI);
				else if (colourScale === "meter") {
					const normalized = (value - spectrogramAbsLogMin) / dataRange;
					const raw = Math.max(0, Math.min(1, normalized));
					const db = raw <= 0 ? -80 : 20 * Math.log10(raw);
					pixel = iecDbToFader(Math.max(-70, db)) / IEC_MAX;
				} else pixel = (value - spectrogramAbsLogMin) / dataRange;
				gray[y * width + x] = Math.max(0, Math.min(1, pixel));
			}
		}
		if (clahe && colourScale !== "phase") applyCLAHE(gray, width, height);
		return {
			gray,
			width,
			height
		};
	}
	/**
	* Estimate per-bin noise floor via median across all frames,
	* then subtract it so stationary noise is suppressed.
	* Returns a new Float32Array with the same layout.
	*/
	function spectralSubtract(spectrogramData, nFrames, nMels) {
		const result = new Float32Array(spectrogramData.length);
		for (let m = 0; m < nMels; m++) {
			const stride = Math.max(1, Math.floor(nFrames / 2e3));
			const vals = [];
			for (let f = 0; f < nFrames; f += stride) vals.push(spectrogramData[f * nMels + m]);
			vals.sort((a, b) => a - b);
			const median = vals[Math.floor(vals.length / 2)] || 0;
			for (let f = 0; f < nFrames; f++) {
				const idx = f * nMels + m;
				result[idx] = Math.max(0, spectrogramData[idx] - median);
			}
		}
		return result;
	}
	/**
	* Apply CLAHE in-place on a Float32Array grayscale image (values 0-1).
	* Divides the image into tiles, computes clipped histograms per tile,
	* and bilinearly interpolates between tile mappings for smooth results.
	*
	* @param {Float32Array} gray   - image data [0,1], modified in place
	* @param {number} width
	* @param {number} height
	* @param {number} [nTilesX=8]  - number of horizontal tiles
	* @param {number} [nTilesY=4]  - number of vertical tiles
	* @param {number} [clipLimit=2.5] - contrast limit (higher = more contrast, 1 = no enhancement)
	*/
	function applyCLAHE(gray, width, height, nTilesX = 8, nTilesY = 4, clipLimit = 2.5) {
		const nBins = 256;
		const tilesX = Math.min(nTilesX, width);
		const tilesY = Math.min(nTilesY, height);
		if (tilesX < 1 || tilesY < 1) return;
		const tileW = width / tilesX;
		const tileH = height / tilesY;
		const cdfs = new Array(tilesY * tilesX);
		for (let ty = 0; ty < tilesY; ty++) for (let tx = 0; tx < tilesX; tx++) {
			const x0 = Math.floor(tx * tileW);
			const x1 = Math.min(width, Math.floor((tx + 1) * tileW));
			const y0 = Math.floor(ty * tileH);
			const y1 = Math.min(height, Math.floor((ty + 1) * tileH));
			const nPixels = (x1 - x0) * (y1 - y0);
			if (nPixels === 0) {
				cdfs[ty * tilesX + tx] = new Float32Array(nBins);
				continue;
			}
			const hist = new Float64Array(nBins);
			for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
				const bin = Math.min(nBins - 1, Math.floor(gray[yy * width + xx] * (nBins - 1)));
				hist[bin]++;
			}
			const limit = Math.max(1, Math.floor(clipLimit * nPixels / nBins));
			let excess = 0;
			for (let i = 0; i < nBins; i++) if (hist[i] > limit) {
				excess += hist[i] - limit;
				hist[i] = limit;
			}
			const perBin = excess / nBins;
			for (let i = 0; i < nBins; i++) hist[i] += perBin;
			const cdf = new Float32Array(nBins);
			cdf[0] = hist[0];
			for (let i = 1; i < nBins; i++) cdf[i] = cdf[i - 1] + hist[i];
			const cdfMin = cdf[0];
			const cdfRange = Math.max(1, cdf[nBins - 1] - cdfMin);
			for (let i = 0; i < nBins; i++) cdf[i] = (cdf[i] - cdfMin) / cdfRange;
			cdfs[ty * tilesX + tx] = cdf;
		}
		for (let y = 0; y < height; y++) {
			const tyF = (y + .5) / tileH - .5;
			const ty0 = Math.max(0, Math.min(tilesY - 1, Math.floor(tyF)));
			const ty1 = Math.min(tilesY - 1, ty0 + 1);
			const fy = tyF - ty0;
			for (let x = 0; x < width; x++) {
				const txF = (x + .5) / tileW - .5;
				const tx0 = Math.max(0, Math.min(tilesX - 1, Math.floor(txF)));
				const tx1 = Math.min(tilesX - 1, tx0 + 1);
				const fx = txF - tx0;
				const val = gray[y * width + x];
				const bin = Math.min(nBins - 1, Math.max(0, Math.floor(val * (nBins - 1))));
				const c00 = cdfs[ty0 * tilesX + tx0][bin];
				const c10 = cdfs[ty0 * tilesX + tx1][bin];
				const c01 = cdfs[ty1 * tilesX + tx0][bin];
				const c11 = cdfs[ty1 * tilesX + tx1][bin];
				const top = c00 + (c10 - c00) * fx;
				const bot = c01 + (c11 - c01) * fx;
				gray[y * width + x] = Math.max(0, Math.min(1, top + (bot - top) * fy));
			}
		}
	}
	/**
	* Stage 2 - Cheap JS fallback, called on every floor/ceil/colorScheme change.
	* Builds a 256-entry RGBA look-up table, then paints the Float32 grayscale map.
	*/
	function colorizeSpectrogram(grayInfo, floor01, ceil01, colorScheme) {
		if (!grayInfo) return null;
		const { gray, width, height } = grayInfo;
		const lut = new Uint32Array(256);
		const range = Math.max(1e-6, ceil01 - floor01);
		const view = new DataView(lut.buffer);
		for (let i = 0; i < 256; i++) {
			const raw = i / 255;
			const c = getSpectrogramColor(Math.max(0, Math.min(1, (raw - floor01) / range)), colorScheme);
			view.setUint32(i * 4, 255 << 24 | c.b << 16 | c.g << 8 | c.r, true);
		}
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const ctx = canvas.getContext("2d");
		if (!ctx) return null;
		const imageData = ctx.createImageData(width, height);
		const pixels = new Uint32Array(imageData.data.buffer);
		const len = width * height;
		for (let i = 0; i < len; i++) pixels[i] = lut[Math.min(255, Math.max(0, Math.round(gray[i] * 255)))];
		ctx.putImageData(imageData, 0, 0);
		return canvas;
	}
	function renderSpectrogram({ duration, spectrogramCanvas, pixelsPerSecond, canvasHeight, baseCanvas, sampleRate, frameRate, spectrogramFrames, hopSize: userHopSize, freqViewSrcCrop }) {
		if (!baseCanvas) return;
		const ctx = spectrogramCanvas.getContext("2d");
		if (!ctx) return;
		const width = Math.max(1, Math.floor(duration * pixelsPerSecond));
		const height = Math.max(140, Math.floor(canvasHeight));
		spectrogramCanvas.width = width;
		spectrogramCanvas.height = height;
		ctx.clearRect(0, 0, width, height);
		const hopSize = userHopSize && userHopSize > 0 ? userHopSize : Math.floor(sampleRate / frameRate);
		const frameCenterSec = 2 * hopSize / sampleRate;
		const x0 = Math.round(frameCenterSec * pixelsPerSecond);
		const drawWidth = Math.round(spectrogramFrames * hopSize / sampleRate * pixelsPerSecond);
		const srcY = freqViewSrcCrop?.srcY ?? 0;
		const srcH = freqViewSrcCrop?.srcH ?? baseCanvas.height;
		const wantCrispH = drawWidth >= baseCanvas.width;
		if (wantCrispH && height !== srcH) {
			const oc = typeof OffscreenCanvas !== "undefined" ? new OffscreenCanvas(baseCanvas.width, height) : (() => {
				const c = document.createElement("canvas");
				c.width = baseCanvas.width;
				c.height = height;
				return c;
			})();
			const octx = oc.getContext("2d");
			if (!octx) return;
			octx.imageSmoothingEnabled = true;
			octx.imageSmoothingQuality = "high";
			octx.drawImage(baseCanvas, 0, srcY, baseCanvas.width, srcH, 0, 0, baseCanvas.width, height);
			ctx.imageSmoothingEnabled = false;
			ctx.drawImage(oc, 0, 0, baseCanvas.width, height, x0, 0, drawWidth, height);
		} else {
			ctx.imageSmoothingEnabled = !wantCrispH;
			ctx.drawImage(baseCanvas, 0, srcY, baseCanvas.width, srcH, x0, 0, drawWidth, height);
		}
		drawTimeGrid({
			ctx,
			width,
			height,
			duration,
			pixelsPerSecond
		});
	}
	function createSpectrogramProcessor() {
		let worker = null;
		let workerFailed = false;
		let requestCounter = 0;
		const pendingRequests = /* @__PURE__ */ new Map();
		const computeMainThread = (channelData, options) => {
			return computeSpectrogram({
				channelData,
				...options
			});
		};
		const ensureWorker = async () => {
			if (worker || workerFailed) return;
			try {
				const Ctor = await getWorkerCtor();
				if (!Ctor) throw new Error("Worker constructor unavailable");
				worker = new Ctor();
				worker.onmessage = (event) => {
					const { requestId, data, nFrames, nMels, smoothState, hopSize, winLength, colourScale } = event.data;
					const pending = pendingRequests.get(requestId);
					if (!pending) return;
					pendingRequests.delete(requestId);
					const result = {
						data: new Float32Array(data),
						nFrames,
						nMels,
						hopSize,
						winLength,
						colourScale
					};
					if (smoothState) result.smoothState = new Float32Array(smoothState);
					pending.resolve(result);
				};
				worker.onerror = (error) => {
					console.warn("Spectrogram Worker failed, using main-thread fallback:", error);
					workerFailed = true;
					worker?.terminate();
					worker = null;
					pendingRequests.forEach(({ reject }) => reject(error));
					pendingRequests.clear();
				};
			} catch (e) {
				console.warn("Cannot create Worker, using main-thread fallback:", e);
				workerFailed = true;
				worker = null;
			}
		};
		const compute = async (channelData, options) => {
			if (workerFailed) return computeMainThread(channelData, options);
			await ensureWorker();
			if (workerFailed) return computeMainThread(channelData, options);
			const requestId = ++requestCounter;
			const audioCopy = new Float32Array(channelData);
			const workerPromise = new Promise((resolve, reject) => {
				pendingRequests.set(requestId, {
					resolve,
					reject
				});
			});
			worker.postMessage({
				requestId,
				channelData: audioCopy.buffer,
				...options
			}, [audioCopy.buffer]);
			const durationSec = channelData.length / Math.max(1, options.sampleRate || 44100);
			const timeoutMs = Math.max(3e3, 3e3 + Math.ceil(durationSec / 30) * 1e3);
			try {
				return await Promise.race([workerPromise, new Promise((_, reject) => setTimeout(() => reject(/* @__PURE__ */ new Error("Worker timeout")), timeoutMs))]);
			} catch (e) {
				console.warn("Worker failed/timed out, computing on main thread:", e.message);
				pendingRequests.delete(requestId);
				workerFailed = true;
				worker?.terminate();
				worker = null;
				return computeMainThread(channelData, options);
			}
		};
		const computeProgressive = async function* (channelData, options) {
			const sampleRate = Math.max(1, options.sampleRate || 0);
			const chunkSeconds = Math.max(1, options.chunkSeconds || 10);
			const samplesPerChunk = Math.max(1, Math.floor(chunkSeconds * sampleRate));
			const totalChunks = Math.max(1, Math.ceil(channelData.length / samplesPerChunk));
			const overlapSamples = options.windowSize || options.fftSize || 2048;
			let smoothState = null;
			for (let chunk = 0; chunk < totalChunks; chunk++) {
				const startSample = chunk * samplesPerChunk;
				const endSample = Math.min(channelData.length, startSample + samplesPerChunk);
				const actualStart = chunk === 0 ? startSample : Math.max(0, startSample - overlapSamples);
				const prependedSamples = startSample - actualStart;
				const result = await compute(channelData.subarray(actualStart, endSample), smoothState ? {
					...options,
					initialSmooth: smoothState
				} : options);
				if (result.smoothState) smoothState = result.smoothState;
				let trimmedResult = result;
				if (prependedSamples > 0 && result.nFrames > 0) {
					const hop = result.hopSize || 1;
					const overlapFrames = Math.min(result.nFrames - 1, Math.ceil(prependedSamples / hop));
					if (overlapFrames > 0) {
						const nMels = result.nMels;
						trimmedResult = {
							...result,
							data: result.data.slice(overlapFrames * nMels),
							nFrames: result.nFrames - overlapFrames
						};
					}
				}
				yield {
					chunk,
					totalChunks,
					percent: (chunk + 1) / totalChunks * 100,
					result: trimmedResult
				};
			}
		};
		const dispose = () => {
			if (worker) {
				worker.terminate();
				worker = null;
			}
			pendingRequests.clear();
		};
		return {
			compute,
			computeProgressive,
			dispose
		};
	}
	//#endregion
	//#region src/waveform.js
	function getCssVar(name, fallback = "") {
		try {
			return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
		} catch (e) {
			return fallback;
		}
	}
	function hexToRgb(hex) {
		if (!hex) return null;
		let h = String(hex).replace("#", "").trim();
		if (h.length === 3) h = h.split("").map((c) => c + c).join("");
		if (h.length !== 6) return null;
		return [
			parseInt(h.slice(0, 2), 16),
			parseInt(h.slice(2, 4), 16),
			parseInt(h.slice(4, 6), 16)
		];
	}
	function colorWithAlpha(color, alpha = 1) {
		if (!color) return color;
		const c = color.trim();
		if (c.startsWith("rgba")) {
			const inner = c.slice(5, -1).split(",").map((s) => s.trim());
			return `rgba(${inner[0]}, ${inner[1]}, ${inner[2]}, ${alpha})`;
		}
		if (c.startsWith("rgb(")) {
			const inner = c.slice(4, -1).split(",").map((s) => s.trim());
			return `rgba(${inner[0]}, ${inner[1]}, ${inner[2]}, ${alpha})`;
		}
		if (c[0] === "#") {
			const rgb = hexToRgb(c);
			if (rgb) return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
		}
		return c;
	}
	function drawWaveformTimeline({ ctx, width, height, duration, pixelsPerSecond }) {
		if (width <= 0) return;
		getComputedStyle(document.documentElement);
		const textColor = getCssVar("--color-text-secondary", "#cbd5e1");
		const { majorStep, minorStep } = getTimeGridSteps(pixelsPerSecond);
		ctx.clearRect(0, 0, width, height);
		ctx.fillStyle = getCssVar("--color-bg-secondary", "#1e293b");
		ctx.fillRect(0, 0, width, height);
		ctx.font = "11px monospace";
		ctx.textBaseline = "middle";
		ctx.fillStyle = textColor;
		ctx.strokeStyle = colorWithAlpha(getCssVar("--color-text-secondary", "#cbd5e1"), .25);
		for (let t = 0; t <= duration; t += minorStep) {
			const x = Math.round(t * pixelsPerSecond) + .5;
			if (x < 0 || x > width) continue;
			const isMajor = Math.abs(t / majorStep - Math.round(t / majorStep)) < 1e-4;
			const lineHeight = isMajor ? 14 : 8;
			ctx.beginPath();
			ctx.moveTo(x, 0);
			ctx.lineTo(x, lineHeight);
			ctx.stroke();
			if (isMajor) ctx.fillText(`${t.toFixed(1)}s`, x + 3, height / 2);
		}
	}
	function renderMainWaveform({ audioBuffer, amplitudeCanvas, waveformTimelineCanvas, waveformContent, pixelsPerSecond, waveformHeight = 100, amplitudePeakAbs, showTimeline = true }) {
		if (!audioBuffer) return;
		const ampCtx = amplitudeCanvas.getContext("2d");
		const timelineCtx = waveformTimelineCanvas.getContext("2d");
		if (!ampCtx || !timelineCtx) return;
		try {
			amplitudeCanvas._aw_lastRender = {
				audioBuffer,
				amplitudeCanvas,
				waveformTimelineCanvas,
				waveformContent,
				pixelsPerSecond,
				waveformHeight,
				amplitudePeakAbs,
				showTimeline
			};
		} catch (e) {}
		const width = Math.max(1, Math.floor(audioBuffer.duration * pixelsPerSecond));
		const clampedWaveformHeight = Math.max(64, Math.floor(waveformHeight));
		const timelineHeight = showTimeline ? Math.max(18, Math.min(32, Math.round(clampedWaveformHeight * .22))) : 0;
		const ampHeight = Math.max(32, clampedWaveformHeight - timelineHeight);
		amplitudeCanvas.width = width;
		amplitudeCanvas.height = ampHeight;
		waveformTimelineCanvas.width = width;
		waveformTimelineCanvas.height = timelineHeight;
		waveformTimelineCanvas.style.display = showTimeline ? "block" : "none";
		waveformContent.style.width = `${width}px`;
		const channelData = audioBuffer.getChannelData(0);
		const totalSamples = channelData.length;
		const midY = ampHeight / 2;
		const ampScale = 1 / Math.max(1e-6, amplitudePeakAbs);
		const { majorStep, minorStep } = getTimeGridSteps(pixelsPerSecond);
		ampCtx.clearRect(0, 0, width, ampHeight);
		ampCtx.fillStyle = getCssVar("--color-bg-tertiary", "#0f3460");
		ampCtx.fillRect(0, 0, width, ampHeight);
		for (let t = 0; t <= audioBuffer.duration; t += minorStep) {
			const x = Math.round(t * pixelsPerSecond) + .5;
			ampCtx.strokeStyle = Math.abs(t / majorStep - Math.round(t / majorStep)) < 1e-4 ? colorWithAlpha(getCssVar("--color-text-secondary", "#94a3b8"), .22) : colorWithAlpha(getCssVar("--color-text-secondary", "#94a3b8"), .12);
			ampCtx.beginPath();
			ampCtx.moveTo(x, 0);
			ampCtx.lineTo(x, ampHeight);
			ampCtx.stroke();
		}
		ampCtx.strokeStyle = colorWithAlpha(getCssVar("--color-text-secondary", "#94a3b8"), .35);
		ampCtx.beginPath();
		ampCtx.moveTo(0, midY + .5);
		ampCtx.lineTo(width, midY + .5);
		ampCtx.stroke();
		ampCtx.strokeStyle = getCssVar("--color-accent", "#60a5fa");
		ampCtx.lineWidth = 1;
		for (let x = 0; x < width; x++) {
			const start = Math.floor(x * totalSamples / width);
			const end = Math.min(totalSamples, Math.floor((x + 1) * totalSamples / width));
			let min = 1;
			let max = -1;
			for (let i = start; i < end; i++) {
				const v = Math.max(-1, Math.min(1, channelData[i] * ampScale));
				if (v < min) min = v;
				if (v > max) max = v;
			}
			ampCtx.beginPath();
			ampCtx.moveTo(x + .5, (1 + min) * midY);
			ampCtx.lineTo(x + .5, (1 + max) * midY);
			ampCtx.stroke();
		}
		if (showTimeline && timelineHeight > 0) drawWaveformTimeline({
			ctx: timelineCtx,
			width,
			height: timelineHeight,
			duration: audioBuffer.duration,
			pixelsPerSecond
		});
		try {
			if (!amplitudeCanvas.dataset.awThemeObserverInstalled) {
				amplitudeCanvas.dataset.awThemeObserverInstalled = "1";
				const redraw = () => {
					const s = amplitudeCanvas._aw_lastRender;
					if (s) requestAnimationFrame(() => {
						try {
							renderMainWaveform(s);
						} catch (e) {}
					});
				};
				const mo = new MutationObserver((mutations) => {
					for (const m of mutations) if (m.attributeName === "data-theme") {
						redraw();
						break;
					}
				});
				mo.observe(document.documentElement, {
					attributes: true,
					attributeFilter: ["data-theme"]
				});
				try {
					const mm = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)");
					if (mm) {
						if (mm.addEventListener) mm.addEventListener("change", redraw);
						else if (mm.addListener) mm.addListener(redraw);
					}
				} catch (e) {}
				amplitudeCanvas._aw_themeObserver = mo;
				amplitudeCanvas._aw_themeRedraw = redraw;
			}
		} catch (e) {}
	}
	function renderOverviewWaveform({ audioBuffer, overviewCanvas, overviewContainer, amplitudePeakAbs }) {
		if (!audioBuffer) return;
		const ctx = overviewCanvas.getContext("2d");
		if (!ctx) return;
		try {
			overviewCanvas._aw_lastRender = {
				audioBuffer,
				overviewCanvas,
				overviewContainer,
				amplitudePeakAbs
			};
		} catch (e) {}
		const rect = overviewContainer.getBoundingClientRect();
		overviewCanvas.width = Math.max(1, Math.floor(rect.width));
		overviewCanvas.height = Math.max(1, Math.floor(rect.height));
		ctx.clearRect(0, 0, overviewCanvas.width, overviewCanvas.height);
		ctx.fillStyle = getCssVar("--color-bg-tertiary", "#0f3460");
		ctx.fillRect(0, 0, overviewCanvas.width, overviewCanvas.height);
		const channelData = audioBuffer.getChannelData(0);
		const totalSamples = channelData.length;
		const amp = overviewCanvas.height / 2;
		const ampScale = 1 / Math.max(1e-6, amplitudePeakAbs);
		ctx.strokeStyle = getCssVar("--color-accent", "#60a5fa");
		ctx.lineWidth = 1;
		for (let x = 0; x < overviewCanvas.width; x++) {
			const start = Math.floor(x * totalSamples / overviewCanvas.width);
			const end = Math.min(totalSamples, Math.floor((x + 1) * totalSamples / overviewCanvas.width));
			let min = 1;
			let max = -1;
			for (let i = start; i < end; i++) {
				const v = Math.max(-1, Math.min(1, channelData[i] * ampScale));
				if (v < min) min = v;
				if (v > max) max = v;
			}
			ctx.beginPath();
			ctx.moveTo(x, (1 + min) * amp);
			ctx.lineTo(x, (1 + max) * amp);
			ctx.stroke();
		}
		try {
			if (!overviewCanvas.dataset.awThemeObserverInstalled) {
				overviewCanvas.dataset.awThemeObserverInstalled = "1";
				const redraw = () => {
					const s = overviewCanvas._aw_lastRender;
					if (s) requestAnimationFrame(() => {
						try {
							renderOverviewWaveform(s);
						} catch (e) {}
					});
				};
				const mo = new MutationObserver((mutations) => {
					for (const m of mutations) if (m.attributeName === "data-theme") {
						redraw();
						break;
					}
				});
				mo.observe(document.documentElement, {
					attributes: true,
					attributeFilter: ["data-theme"]
				});
				try {
					const mm = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)");
					if (mm) {
						if (mm.addEventListener) mm.addEventListener("change", redraw);
						else if (mm.addListener) mm.addListener(redraw);
					}
				} catch (e) {}
				overviewCanvas._aw_themeObserver = mo;
				overviewCanvas._aw_themeRedraw = redraw;
			}
		} catch (e) {}
	}
	function renderFrequencyLabels({ labelsElement, coords }) {
		labelsElement.innerHTML = "";
		const boundedMaxFreq = coords.freqViewMax ?? Math.min(coords.maxFreq, coords.sampleRate / 2);
		const minFreq = coords.freqViewMin ?? (coords.freqRange && coords.freqRange[0] || 0);
		const range = boundedMaxFreq - minFreq;
		const niceSteps = [
			100,
			200,
			500,
			1e3,
			2e3,
			2500,
			5e3,
			1e4,
			2e4
		];
		const rawStep = range / 6;
		const step = niceSteps.reduce((best, s) => Math.abs(s - rawStep) < Math.abs(best - rawStep) ? s : best);
		const frequencies = [];
		const startFreq = Math.ceil(minFreq / step) * step;
		for (let f = startFreq; f <= boundedMaxFreq + 1; f += step) frequencies.push(f);
		if (minFreq === 0 && (frequencies.length === 0 || frequencies[0] !== 0)) frequencies.unshift(0);
		frequencies.forEach((freq) => {
			const span = document.createElement("span");
			span.textContent = freq >= 1e3 ? `${(freq / 1e3).toFixed(freq % 1e3 === 0 ? 0 : 1)} kHz` : `${Math.round(freq)} Hz`;
			const yFrac = coords.frequencyToYFraction(freq);
			span.style.position = "absolute";
			span.style.top = `${yFrac * 100}%`;
			span.style.transform = `translateY(${-yFrac * 100}%)`;
			span.style.setProperty("--tick-pos", `${yFrac * 100}%`);
			labelsElement.appendChild(span);
		});
	}
	//#endregion
	//#region src/PlayerState.js
	var LS_USER_PRESETS = "aw-user-presets";
	var LS_FAV_PRESET = "aw-favourite-preset";
	var LS_LAST_SETTINGS = "aw-last-settings";
	/**
	* @typedef {Object} PlayerOptions
	* @property {string}  [viewMode]
	* @property {boolean} [showOverview]
	* @property {boolean} [transportOverlay]
	* @property {string}  [compactToolbar]
	* @property {boolean} [showWaveformTimeline]
	* @property {boolean} [enableTouchGestures]
	* @property {boolean} [enablePerfOverlay]
	* @property {number}  [followGuardLeftRatio]
	* @property {number}  [followGuardRightRatio]
	* @property {number}  [followTargetRatio]
	* @property {number}  [followCatchupDurationMs]
	* @property {number}  [followCatchupSeekDurationMs]
	* @property {number}  [smoothLerp]
	* @property {number}  [smoothSeekLerp]
	* @property {number}  [smoothMinStepRatio]
	* @property {number}  [smoothSeekMinStepRatio]
	* @property {number}  [smoothSeekFocusMs]
	* @property {boolean} [enableProgressiveSpectrogram]
	*/
	/**
	* Parse the native sample rate from an audio file header (WAV, FLAC, OGG Vorbis/Opus).
	* Returns 0 if the format is unrecognised.
	* @param {ArrayBuffer} buf
	* @returns {number}
	*/
	function parseNativeSampleRate(buf) {
		if (buf.byteLength < 44) return 0;
		const view = new DataView(buf);
		if (view.getUint32(0) === 1380533830 && view.getUint32(8) === 1463899717) return view.getUint32(24, true);
		if (view.getUint32(0) === 1716281667) return view.getUint8(18) << 12 | view.getUint8(19) << 4 | view.getUint8(20) >> 4;
		if (view.getUint32(0) === 1332176723 && buf.byteLength >= 64) {
			const dataOffset = 27 + view.getUint8(26);
			if (buf.byteLength >= dataOffset + 16) {
				if (view.getUint8(dataOffset) === 1 && view.getUint32(dataOffset + 1) === 1987015266) return view.getUint32(dataOffset + 12, true);
				if (view.getUint32(dataOffset) === 1332770163 && view.getUint32(dataOffset + 4) === 1214603620) return view.getUint32(dataOffset + 12, true);
			}
		}
		return 0;
	}
	/**
	* Decode an ArrayBuffer into an AudioBuffer, preserving the file's native
	* sample rate when possible (instead of resampling to AudioContext default).
	* @param {ArrayBuffer} arrayBuffer
	* @returns {Promise<AudioBuffer>}
	*/
	async function decodeArrayBuffer(arrayBuffer) {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) throw new Error("AudioContext is not supported by this browser.");
		const nativeSr = parseNativeSampleRate(arrayBuffer);
		const ctx = new Ctor(nativeSr > 0 ? { sampleRate: nativeSr } : void 0);
		try {
			return await ctx.decodeAudioData(arrayBuffer);
		} finally {
			ctx.close?.().catch(() => {});
		}
	}
	var PlayerState = class {
		/**
		* @param {HTMLElement} container
		* @param {any} WaveSurfer
		* @param {((event: string, detail: any) => void) | null} [emitHostEvent]
		* @param {PlayerOptions} [options]
		*/
		constructor(container, WaveSurfer, emitHostEvent = null, options = {}) {
			if (!container) throw new Error("PlayerState: container element required");
			if (!WaveSurfer) throw new Error("PlayerState: WaveSurfer reference required");
			this.container = container;
			this.d = this._queryDom(container);
			this._populatePresetDropdown();
			this._applyFavouritePresetControls();
			this.WaveSurfer = WaveSurfer;
			this._emitHostEvent = typeof emitHostEvent === "function" ? emitHostEvent : null;
			this.options = options || {};
			this._viewMode = this.options.viewMode === "waveform" || this.options.viewMode === "spectrogram" ? this.options.viewMode : "both";
			this._showWaveform = this._viewMode !== "spectrogram";
			this._showSpectrogram = this._viewMode !== "waveform";
			this._showOverview = this.options.showOverview !== false;
			this._transportOverlay = this.options.transportOverlay === true;
			this._compactToolbarMode = this.options.compactToolbar && [
				"auto",
				"on",
				"off"
			].includes(this.options.compactToolbar) ? this.options.compactToolbar : "auto";
			this._compactToolbarOpen = false;
			this._settingsPanelOpen = false;
			this._compactToolbarLayoutRaf = 0;
			this._showWaveformTimeline = this.options.showWaveformTimeline !== false && !(this.options.transportOverlay && this._viewMode === "waveform");
			this._playbackViewportConfig = this._sanitizePlaybackViewportConfig(this.options || {});
			this.processor = createSpectrogramProcessor();
			this.colorizer = new GpuColorizer();
			this.audioBuffer = null;
			this.wavesurfer = null;
			this.spectrogramData = null;
			this.spectrogramFrames = 0;
			this.spectrogramMels = 0;
			this.spectrogramBaseCanvas = null;
			this.spectrogramGrayInfo = null;
			this._gpuReady = false;
			this.spectrogramAbsLogMin = 0;
			this.spectrogramAbsLogMax = 1;
			this.sampleRateHz = DEFAULT_SAMPLE_RATE;
			this._externalSpectrogram = false;
			this._externalImageConfig = null;
			this.amplitudePeakAbs = 1;
			this.currentColorScheme = this.d.colorSchemeSelect.value || "grayscale";
			this.volume = .8;
			this.muted = false;
			this.preMuteVolume = .8;
			this.pixelsPerSecond = 100;
			this._zoomRedrawRafId = 0;
			this.scrollSyncLock = false;
			this.windowStartNorm = 0;
			this.windowEndNorm = 1;
			/** @type {number | null} */
			this._freqViewMin = null;
			/** @type {number | null} */
			this._freqViewMax = null;
			this.followMode = "follow";
			this.followPlayback = true;
			this.loopPlayback = false;
			this.playbackMode = "normal";
			this.transportState = "";
			this._activeSegmentLabelId = null;
			this._activeSegmentFilter = null;
			this._activeSegmentStart = null;
			this._activeSegmentEnd = null;
			this._suppressNextPauseHandler = false;
			this._segmentPlayToken = 0;
			this._customSegmentPlayback = null;
			this._smoothSeekFocusUntil = 0;
			this._lastTimeupdateEmitAt = 0;
			this._lastSelectionEmitAt = 0;
			this._lastSelectionStart = NaN;
			this._lastSelectionEnd = NaN;
			this._lastViewRangeTextStart = NaN;
			this._lastViewRangeTextEnd = NaN;
			this._lastTimeReadoutText = "";
			this._uiFrameId = 0;
			this._uiPending = null;
			this._followCatchupRafId = 0;
			this._followCatchupAnim = null;
			this._perf = {
				enabled: false,
				panel: null,
				intervalId: 0,
				frames: 0,
				fps: 0,
				lastFrameTs: 0,
				longFrames: 0,
				maxFrameMs: 0,
				uiFlushes: 0,
				timeupdateEvents: 0,
				selectionEvents: 0,
				seekEvents: 0,
				transitionEvents: 0,
				blockedTransitions: 0,
				lastTransition: ""
			};
			this.interaction = new InteractionState();
			this._overviewViewportRafId = 0;
			this._overviewNeedsFinalRedraw = false;
			this.coords = new CoordinateSystem();
			this._crosshairEnabled = false;
			this._crosshairRafId = 0;
			this.waveformDisplayHeight = 100;
			this.spectrogramDisplayHeight = 200;
			this._viewResizeFrameId = 0;
			this._viewResizeNeedsWaveformRedraw = false;
			this._viewResizeNeedsSpectrogramRedraw = false;
			this._applyLocalViewHeights();
			this._updateAmplitudeLabels();
			this._setInitialPlayheadPositions();
			this._updateToggleButtons();
			this._updateAriaPlaybackPosition(0);
			this._setCompactToolbarOpen(false);
			this._setTransportState("idle", "init");
			this._initPerfOverlay();
			this._cleanups = [];
			this._bindEvents();
			if (this.options.enableTouchGestures !== false) this._bindTouchGestures();
			this._refreshCompactToolbarLayout();
			this._updatePcenSectionDimming();
			requestAnimationFrame(() => this._refreshCompactToolbarLayout());
		}
		_emit(event, detail = {}) {
			if (!this._emitHostEvent) return;
			this._emitHostEvent(event, detail);
		}
		_sanitizePlaybackViewportConfig(partial = {}) {
			const cfg = this._playbackViewportConfig || {};
			return {
				followGuardLeftRatio: clampNumber(partial.followGuardLeftRatio, .05, .95, cfg.followGuardLeftRatio ?? .35),
				followGuardRightRatio: clampNumber(partial.followGuardRightRatio, .05, .95, cfg.followGuardRightRatio ?? .65),
				followTargetRatio: clampNumber(partial.followTargetRatio, .1, .9, cfg.followTargetRatio ?? .5),
				followCatchupDurationMs: clampNumber(partial.followCatchupDurationMs, 80, 2500, cfg.followCatchupDurationMs ?? 240),
				followCatchupSeekDurationMs: clampNumber(partial.followCatchupSeekDurationMs, 100, 3e3, cfg.followCatchupSeekDurationMs ?? 360),
				smoothLerp: clampNumber(partial.smoothLerp, .02, .95, cfg.smoothLerp ?? .18),
				smoothSeekLerp: clampNumber(partial.smoothSeekLerp, .01, .9, cfg.smoothSeekLerp ?? .08),
				smoothMinStepRatio: clampNumber(partial.smoothMinStepRatio, .001, .25, cfg.smoothMinStepRatio ?? .03),
				smoothSeekMinStepRatio: clampNumber(partial.smoothSeekMinStepRatio, .001, .2, cfg.smoothSeekMinStepRatio ?? .008),
				smoothSeekFocusMs: clampNumber(partial.smoothSeekFocusMs, 150, 5e3, cfg.smoothSeekFocusMs ?? 1400)
			};
		}
		updatePlaybackViewportConfig(partial = {}) {
			this._playbackViewportConfig = this._sanitizePlaybackViewportConfig(partial);
			if (this._playbackViewportConfig.followGuardLeftRatio >= this._playbackViewportConfig.followGuardRightRatio) {
				this._playbackViewportConfig.followGuardLeftRatio = .35;
				this._playbackViewportConfig.followGuardRightRatio = .65;
			}
			this._emit("followconfigchange", { ...this._playbackViewportConfig });
			return { ...this._playbackViewportConfig };
		}
		getPlaybackViewportConfig() {
			return { ...this._playbackViewportConfig };
		}
		_initPerfOverlay() {
			const byOption = this.options?.enablePerfOverlay === true;
			let byQuery = false;
			try {
				byQuery = new URLSearchParams(window.location.search || "").get("perf") === "1";
			} catch {
				byQuery = false;
			}
			if (!byOption && !byQuery) return;
			this._perf.enabled = true;
			const panel = document.createElement("div");
			panel.className = "abp-perf-overlay";
			panel.style.position = "absolute";
			panel.style.top = "8px";
			panel.style.right = "8px";
			panel.style.left = "auto";
			panel.style.bottom = "auto";
			panel.style.transform = "none";
			panel.style.zIndex = "60";
			panel.innerHTML = `
            <div class="abp-perf-title">PERF</div>
            <div class="abp-perf-body">Initializing...</div>
        `;
			this.container.appendChild(panel);
			this._perf.panel = panel;
			this._perf.intervalId = window.setInterval(() => {
				this._renderPerfOverlay();
			}, 500);
		}
		_perfOnFrame(ts) {
			if (!this._perf.enabled) return;
			this._perf.frames += 1;
			if (this._perf.lastFrameTs > 0) {
				const frameMs = ts - this._perf.lastFrameTs;
				if (frameMs > 0) {
					const fps = 1e3 / frameMs;
					this._perf.fps = this._perf.fps <= 0 ? fps : this._perf.fps * .85 + fps * .15;
				}
				this._perf.maxFrameMs = Math.max(this._perf.maxFrameMs, frameMs);
				if (frameMs > 32) this._perf.longFrames += 1;
			}
			this._perf.lastFrameTs = ts;
		}
		_renderPerfOverlay() {
			if (!this._perf.enabled || !this._perf.panel) return;
			const body = this._perf.panel.querySelector(".abp-perf-body");
			if (!body) return;
			body.innerHTML = [
				`state: ${this.transportState || "n/a"}`,
				`fps: ${this._perf.fps.toFixed(1)} | long>32ms: ${this._perf.longFrames}`,
				`max frame: ${this._perf.maxFrameMs.toFixed(1)}ms | ui flushes: ${this._perf.uiFlushes}`,
				`timeupdate: ${this._perf.timeupdateEvents} | selection: ${this._perf.selectionEvents} | seek: ${this._perf.seekEvents}`,
				`transitions: ${this._perf.transitionEvents} | blocked: ${this._perf.blockedTransitions}`,
				`last: ${this._perf.lastTransition || "-"}`
			].join("<br>");
			this._perf.uiFlushes = 0;
			this._perf.timeupdateEvents = 0;
			this._perf.selectionEvents = 0;
			this._perf.seekEvents = 0;
			this._perf.maxFrameMs = 0;
		}
		_setTransportState(nextState, reason = "") {
			if (!nextState || this.transportState === nextState) return;
			const fromState = this.transportState || "";
			if (!canTransitionTransportState(fromState, nextState)) {
				this._perf.blockedTransitions += 1;
				this._emit("transporttransitionblocked", {
					from: fromState,
					to: nextState,
					reason
				});
			}
			this.transportState = nextState;
			this._perf.transitionEvents += 1;
			this._perf.lastTransition = `${fromState || "∅"} → ${nextState}${reason ? ` (${reason})` : ""}`;
			this._setPlayState(TRANSPORT_STATE_LABELS[nextState] || nextState);
			this._emit("transportstatechange", {
				state: nextState,
				reason
			});
		}
		_scheduleUiUpdate({ time = this._getCurrentTime(), fromPlayback = false, centerView = false, emitSeek = false, immediate = false } = {}) {
			this._uiPending = this._uiPending || {
				time: 0,
				fromPlayback: false,
				centerView: false,
				emitSeek: false
			};
			this._uiPending.time = time;
			this._uiPending.fromPlayback = fromPlayback;
			this._uiPending.centerView = this._uiPending.centerView || centerView;
			this._uiPending.emitSeek = this._uiPending.emitSeek || emitSeek;
			if (immediate) {
				if (this._uiFrameId) {
					cancelAnimationFrame(this._uiFrameId);
					this._uiFrameId = 0;
				}
				this._flushUiUpdate(performance.now());
				return;
			}
			if (this._uiFrameId) return;
			this._uiFrameId = requestAnimationFrame((ts) => this._flushUiUpdate(ts));
		}
		_flushUiUpdate(_ts) {
			this._uiFrameId = 0;
			const pending = this._uiPending;
			this._uiPending = null;
			if (!pending || !this.audioBuffer) return;
			this._perfOnFrame(_ts);
			this._perf.uiFlushes += 1;
			const duration = Math.max(0, this.audioBuffer.duration || 0);
			const t = Math.max(0, Math.min(pending.time || 0, duration || pending.time || 0));
			this._updateTimeReadout(t);
			this._updatePlayhead(t, pending.fromPlayback);
			if (pending.centerView) this._centerViewportAtTime(t);
			if (pending.emitSeek) {
				this._perf.seekEvents += 1;
				this._emit("seek", {
					currentTime: t,
					duration: this.audioBuffer?.duration || 0
				});
			}
		}
		_queryDom(root) {
			const q = (id) => root.querySelector(`[data-aw="${id}"]`);
			return {
				openFileBtn: q("openFileBtn"),
				toolbarRoot: q("toolbarRoot"),
				compactMoreBtn: q("compactMoreBtn"),
				toolbarSecondary: q("toolbarSecondary"),
				audioFile: q("audioFile"),
				playPauseBtn: q("playPauseBtn"),
				stopBtn: q("stopBtn"),
				jumpStartBtn: q("jumpStartBtn"),
				jumpEndBtn: q("jumpEndBtn"),
				backwardBtn: q("backwardBtn"),
				forwardBtn: q("forwardBtn"),
				followToggleBtn: q("followToggleBtn"),
				loopToggleBtn: q("loopToggleBtn"),
				fitViewBtn: q("fitViewBtn"),
				resetViewBtn: q("resetViewBtn"),
				currentTimeDisplay: q("currentTime"),
				totalTimeDisplay: q("totalTime"),
				playStateDisplay: q("playState"),
				viewRangeDisplay: q("viewRange"),
				spectrogramCanvas: q("spectrogramCanvas"),
				spectrogramContainer: q("spectrogramContainer"),
				waveformContainer: q("waveformContainer"),
				waveformWrapper: q("waveformWrapper"),
				waveformContent: q("waveformContent"),
				amplitudeLabels: q("amplitudeLabels"),
				amplitudeCanvas: q("amplitudeCanvas"),
				waveformTimelineCanvas: q("waveformTimelineCanvas"),
				waveformPlayhead: q("waveformPlayhead"),
				audioEngineHost: q("audioEngineHost"),
				playhead: q("playhead"),
				canvasWrapper: q("canvasWrapper"),
				viewSplitHandle: q("viewSplitHandle"),
				spectrogramResizeHandle: q("spectrogramResizeHandle"),
				overviewCanvas: q("overviewCanvas"),
				overviewContainer: q("overviewContainer"),
				overviewWindow: q("overviewWindow"),
				overviewHandleLeft: q("overviewHandleLeft"),
				overviewHandleRight: q("overviewHandleRight"),
				overviewLabelTracks: q("overviewLabelTracks"),
				fileInfo: q("fileInfo"),
				sampleRateInfo: q("sampleRateInfo"),
				scaleSelect: q("scaleSelect"),
				colourScaleSelect: q("colourScaleSelect"),
				presetSelect: q("presetSelect"),
				presetSaveBtn: q("presetSaveBtn"),
				presetFavBtn: q("presetFavBtn"),
				presetManageBtn: q("presetManageBtn"),
				presetSaveRow: q("presetSaveRow"),
				presetSaveInput: q("presetSaveInput"),
				presetSaveConfirm: q("presetSaveConfirm"),
				presetSaveCancel: q("presetSaveCancel"),
				presetManagerPanel: q("presetManagerPanel"),
				presetManagerList: q("presetManagerList"),
				presetImportBtn: q("presetImportBtn"),
				presetExportBtn: q("presetExportBtn"),
				presetStatus: q("presetStatus"),
				nMelsInput: q("nMelsInput"),
				pcenGainInput: q("pcenGainInput"),
				pcenBiasInput: q("pcenBiasInput"),
				pcenRootInput: q("pcenRootInput"),
				pcenSmoothingInput: q("pcenSmoothingInput"),
				pcenEnabledCheck: q("pcenEnabledCheck"),
				pcenSection: q("pcenSection"),
				windowSizeSelect: q("windowSize"),
				windowFunctionSelect: q("windowFunction"),
				overlapSelect: q("overlapSelect"),
				oversamplingSelect: q("oversamplingSelect"),
				reassignedCheck: q("reassignedCheck"),
				noiseReductionCheck: q("noiseReductionCheck"),
				claheCheck: q("claheCheck"),
				qualitySlider: q("qualitySlider"),
				qualityLevelDisplay: q("qualityLevelDisplay"),
				zoomSlider: q("zoomSlider"),
				zoomValue: q("zoomValue"),
				maxFreqModeSelect: q("maxFreqModeSelect"),
				maxFreqSelect: q("maxFreqSelect"),
				colorSchemeSelect: q("colorSchemeSelect"),
				freqLabels: q("freqLabels"),
				freqZoomResetBtn: q("freqZoomResetBtn"),
				freqAxisSpacer: q("freqAxisSpacer"),
				freqZoomSlider: q("freqZoomSlider"),
				freqScrollbar: q("freqScrollbar"),
				freqScrollbarThumb: q("freqScrollbarThumb"),
				volumeToggleBtn: q("volumeToggleBtn"),
				volumeIcon: q("volumeIcon"),
				volumeWaves: q("volumeWaves"),
				volumeSlider: q("volumeSlider"),
				gainModeSelect: q("gainModeSelect"),
				floorSlider: q("floorSlider"),
				ceilSlider: q("ceilSlider"),
				autoContrastBtn: q("autoContrastBtn"),
				autoFreqBtn: q("autoFreqBtn"),
				crosshairToggleBtn: q("crosshairToggleBtn"),
				crosshairCanvas: q("crosshairCanvas"),
				crosshairReadout: q("crosshairReadout"),
				recomputingOverlay: q("recomputingOverlay"),
				settingsToggleBtn: q("settingsToggleBtn"),
				settingsPanel: q("settingsPanel"),
				settingsPanelClose: q("settingsPanelClose")
			};
		}
		_populatePresetDropdown() {
			const sel = this.d.presetSelect;
			if (!sel) return;
			sel.innerHTML = "";
			const empty = document.createElement("option");
			empty.value = "";
			empty.textContent = "— Custom —";
			sel.appendChild(empty);
			for (const name of Object.keys(DSP_PROFILES)) {
				const opt = document.createElement("option");
				opt.value = name;
				opt.textContent = name.charAt(0).toUpperCase() + name.slice(1);
				sel.appendChild(opt);
			}
			const userPresets = this._loadUserPresets();
			const userNames = Object.keys(userPresets);
			if (userNames.length) {
				const sep = document.createElement("option");
				sep.disabled = true;
				sep.textContent = "──────────";
				sel.appendChild(sep);
				const fav = this._getFavouritePreset();
				for (const name of userNames) {
					const opt = document.createElement("option");
					opt.value = `user:${name}`;
					opt.textContent = (fav === `user:${name}` ? "⭐ " : "") + name;
					sel.appendChild(opt);
				}
			}
			const fav = this._getFavouritePreset();
			if (fav && Array.from(sel.options).some((o) => o.value === fav)) sel.value = fav;
			else sel.value = "birder";
		}
		dispose() {
			this._stopCustomSegmentPlayback("stopped", this._getCurrentTime());
			this._cancelFollowCatchupAnimation();
			this._hideCrosshair();
			if (this._viewResizeFrameId) {
				cancelAnimationFrame(this._viewResizeFrameId);
				this._viewResizeFrameId = 0;
			}
			if (this._uiFrameId) {
				cancelAnimationFrame(this._uiFrameId);
				this._uiFrameId = 0;
			}
			if (this._zoomRedrawRafId) {
				cancelAnimationFrame(this._zoomRedrawRafId);
				this._zoomRedrawRafId = 0;
			}
			if (this._overviewViewportRafId) {
				cancelAnimationFrame(this._overviewViewportRafId);
				this._overviewViewportRafId = 0;
			}
			if (this._compactToolbarLayoutRaf) {
				cancelAnimationFrame(this._compactToolbarLayoutRaf);
				this._compactToolbarLayoutRaf = 0;
			}
			if (this._perf.intervalId) {
				clearInterval(this._perf.intervalId);
				this._perf.intervalId = 0;
			}
			if (this._perf.panel?.parentNode) {
				this._perf.panel.parentNode.removeChild(this._perf.panel);
				this._perf.panel = null;
			}
			for (let i = this._cleanups.length - 1; i >= 0; i--) this._cleanups[i]();
			this._cleanups.length = 0;
			this.processor.dispose();
			this.colorizer.dispose();
		}
		async _handleFileSelect(e) {
			const file = e?.target?.files?.[0];
			if (!file) return;
			this.d.fileInfo.innerHTML = `<span class="statusbar-label">${escapeHtml(file.name)}</span>`;
			this.d.fileInfo.classList.add("loading");
			this._setTransportState("loading", "file-load");
			try {
				const audioBuffer = await decodeArrayBuffer(await file.arrayBuffer());
				this.audioBuffer = audioBuffer;
				this.sampleRateHz = audioBuffer.sampleRate;
				this.amplitudePeakAbs = computeAmplitudePeak(audioBuffer.getChannelData(0));
				this._updateAmplitudeLabels();
				this._updateMaxFreqOptions();
				this.d.fileInfo.innerHTML = `<span class="statusbar-label">${escapeHtml(file.name)}</span> <span>${formatTime(audioBuffer.duration)}</span>`;
				this.d.sampleRateInfo.textContent = `${audioBuffer.sampleRate} Hz`;
				this.d.totalTimeDisplay.textContent = formatTime(audioBuffer.duration);
				this.d.currentTimeDisplay.textContent = formatTime(0);
				this._setPixelsPerSecond(100, false);
				this._setTransportEnabled(true);
				this._updateToggleButtons();
				this._setTransportState("ready", "file-loaded");
				this.d.fileInfo.classList.remove("loading");
				this._setupWaveSurfer(file);
				await this._generateSpectrogram({ autoAdjust: true });
				this._drawMainWaveform();
				this._drawOverviewWaveform();
				this._createFrequencyLabels();
				this._seekToTime(0, true);
			} catch (error) {
				console.error("Error loading file:", error);
				this._setTransportState("error", "file-load-failed");
				this.d.fileInfo.classList.remove("loading");
				this._emit("error", {
					message: error?.message || String(error),
					source: "file"
				});
				alert("Error loading audio file");
			}
		}
		async loadUrl(url) {
			this.d.fileInfo.innerHTML = `<span class="statusbar-label">Loading…</span>`;
			this.d.fileInfo.classList.add("loading");
			this._setTransportState("loading", "url-load");
			try {
				const response = await fetch(url);
				if (!response.ok) throw new Error(`HTTP ${response.status}`);
				const audioBuffer = await decodeArrayBuffer(await response.arrayBuffer());
				this.audioBuffer = audioBuffer;
				this.sampleRateHz = audioBuffer.sampleRate;
				this.amplitudePeakAbs = computeAmplitudePeak(audioBuffer.getChannelData(0));
				this._updateAmplitudeLabels();
				this._updateMaxFreqOptions();
				const name = decodeURIComponent(new URL(url, location.href).pathname.split("/").pop() || "audio");
				this.d.fileInfo.innerHTML = `<span class="statusbar-label">${escapeHtml(name)}</span> <span>${formatTime(audioBuffer.duration)}</span>`;
				this.d.sampleRateInfo.textContent = `${audioBuffer.sampleRate} Hz`;
				this.d.totalTimeDisplay.textContent = formatTime(audioBuffer.duration);
				this.d.currentTimeDisplay.textContent = formatTime(0);
				this._setPixelsPerSecond(100, false);
				this._setTransportEnabled(true);
				this._updateToggleButtons();
				this._setTransportState("ready", "url-loaded");
				this.d.fileInfo.classList.remove("loading");
				this._setupWaveSurfer(url);
				await this._generateSpectrogram({ autoAdjust: true });
				this._drawMainWaveform();
				this._drawOverviewWaveform();
				this._createFrequencyLabels();
				this._seekToTime(0, true);
			} catch (error) {
				console.error("Error loading audio URL:", error);
				this._setTransportState("error", "url-load-failed");
				this.d.fileInfo.classList.remove("loading");
				this._emit("error", {
					message: error?.message || String(error),
					source: "url"
				});
			}
		}
		_setupWaveSurfer(source) {
			if (this.wavesurfer) this.wavesurfer.destroy();
			const ws = this.WaveSurfer.create({
				container: this.d.audioEngineHost,
				height: 1,
				waveColor: "#38bdf8",
				progressColor: "#0ea5e9",
				cursorColor: "#ef4444",
				normalize: true,
				minPxPerSec: this.pixelsPerSecond,
				autoScroll: false,
				autoCenter: false
			});
			if (typeof source === "string") ws.load(source);
			else ws.loadBlob(source);
			ws.on("ready", () => {
				ws.zoom(this.pixelsPerSecond);
				ws.setVolume(this.volume);
				this._seekToTime(0, true);
				this._lastTimeupdateEmitAt = 0;
				this._lastSelectionEmitAt = 0;
				this._lastSelectionStart = NaN;
				this._lastSelectionEnd = NaN;
			});
			ws.on("timeupdate", (t) => {
				this._perf.timeupdateEvents += 1;
				this._scheduleUiUpdate({
					time: t,
					fromPlayback: true
				});
				const now = performance.now();
				if (now - this._lastTimeupdateEmitAt >= 66) {
					this._lastTimeupdateEmitAt = now;
					this._emit("timeupdate", {
						currentTime: t,
						duration: this.audioBuffer?.duration || 0
					});
				}
			});
			ws.on("play", () => {
				this.d.playPauseBtn.classList.add("playing");
				if (this.playbackMode === "segment") {
					this._setTransportState("playing_segment", "engine-play");
					return;
				}
				this._setTransportState(this.loopPlayback ? "playing_loop" : "playing", "engine-play");
			});
			ws.on("pause", () => {
				if (this._suppressNextPauseHandler) {
					this._suppressNextPauseHandler = false;
					return;
				}
				this.d.playPauseBtn.classList.remove("playing");
				if (this.playbackMode === "segment" && this._activeSegmentEnd != null) this._setTransportState("paused_segment", "engine-pause");
				else if (this.audioBuffer) {
					const atEnd = ws.getCurrentTime() >= this.audioBuffer.duration - .01;
					this._setTransportState(atEnd ? "stopped" : "paused", "engine-pause");
				} else this._setTransportState("paused", "engine-pause");
			});
			ws.on("finish", () => {
				if (this.playbackMode === "segment") {
					this.playbackMode = "normal";
					this._activeSegmentLabelId = null;
					this._activeSegmentFilter = null;
					this._activeSegmentStart = null;
					this._activeSegmentEnd = null;
					this._segmentPlayToken++;
				}
				if (this.loopPlayback) {
					this._seekToTime(0, this.followPlayback);
					ws.play();
					return;
				}
				this.d.playPauseBtn.classList.remove("playing");
				this._setTransportState("stopped", "engine-finish");
				if (this.audioBuffer) this._scheduleUiUpdate({
					time: this.audioBuffer.duration,
					fromPlayback: false,
					immediate: true
				});
			});
			this.wavesurfer = ws;
		}
		_togglePlayPause() {
			if (this._customSegmentPlayback) {
				this._stopCustomSegmentPlayback("paused", this._customSegmentPlayback.currentTimeSec);
				return;
			}
			this.playbackMode = "normal";
			this._activeSegmentLabelId = null;
			this._activeSegmentFilter = null;
			this._activeSegmentStart = null;
			this._activeSegmentEnd = null;
			this._segmentPlayToken++;
			if (this.wavesurfer && this.audioBuffer) this.wavesurfer.playPause();
		}
		_stopPlayback() {
			if (this._customSegmentPlayback) this._stopCustomSegmentPlayback("stopped", 0);
			if (!this.wavesurfer) return;
			this.playbackMode = "normal";
			this._activeSegmentLabelId = null;
			this._activeSegmentFilter = null;
			this._activeSegmentStart = null;
			this._activeSegmentEnd = null;
			this._segmentPlayToken++;
			this.wavesurfer.pause();
			this._seekToTime(0, true);
			this._setTransportState("stopped", "stop-control");
			this.d.playPauseBtn.classList.remove("playing");
		}
		playSegment(startSec, endSec, options = {}) {
			if (!this.audioBuffer || !this.wavesurfer) return;
			this._clearPlaybackFilter();
			const dur = this.audioBuffer.duration;
			const start = Math.max(0, Math.min(startSec, dur));
			const end = Math.max(0, Math.min(endSec, dur));
			if (end - start < .01) return;
			const token = ++this._segmentPlayToken;
			this.playbackMode = "segment";
			this._activeSegmentLabelId = options?.labelId || null;
			this._activeSegmentFilter = null;
			this._activeSegmentStart = start;
			this._activeSegmentEnd = end;
			if (this.wavesurfer.isPlaying()) {
				this._suppressNextPauseHandler = true;
				this.wavesurfer.pause();
			}
			this._seekToTime(start, false);
			if (token !== this._segmentPlayToken) return;
			const runPlay = () => {
				if (token !== this._segmentPlayToken) return;
				try {
					if (this.loopPlayback) {
						this._seekToTime(start, false, { allowCustomPlayback: true });
						this.wavesurfer.play();
						this._emit("segmentplaystart", {
							start,
							end,
							loop: true
						});
						return;
					}
					const maybePromise = this.wavesurfer.play(start, end);
					this._emit("segmentplaystart", {
						start,
						end
					});
					if (maybePromise && typeof maybePromise.then === "function") maybePromise.catch(() => {
						if (token !== this._segmentPlayToken) return;
						this._seekToTime(start, false);
						this.wavesurfer?.play();
					});
				} catch {
					if (token !== this._segmentPlayToken) return;
					this._seekToTime(start, false);
					this.wavesurfer?.play();
					this._emit("segmentplaystart", {
						start,
						end
					});
				}
			};
			try {
				window.requestAnimationFrame(runPlay);
			} catch {
				runPlay();
			}
		}
		playBandpassedSegment(startSec, endSec, freqMinHz, freqMaxHz, options = {}) {
			if (!this.audioBuffer) return;
			const dur = this.audioBuffer.duration;
			const start = Math.max(0, Math.min(startSec, dur));
			const end = Math.max(0, Math.min(endSec, dur));
			if (end - start < .01) return;
			const nyquist = Math.max(100, this.audioBuffer.sampleRate * .5 - 10);
			const fLo = Math.max(20, Math.min(freqMinHz, freqMaxHz, nyquist - 5));
			const fHi = Math.max(fLo + 5, Math.min(Math.max(freqMinHz, freqMaxHz), nyquist));
			const center = Math.sqrt(fLo * fHi);
			const bandwidth = Math.max(10, fHi - fLo);
			const q = Math.max(.25, Math.min(40, center / bandwidth));
			this._stopCustomSegmentPlayback("stopped", start);
			this._clearPlaybackFilter();
			if (this.wavesurfer?.isPlaying()) {
				this._suppressNextPauseHandler = true;
				this.wavesurfer.pause();
			}
			this._seekToTime(start, false, { allowCustomPlayback: true });
			const Ctor = window.AudioContext || window.webkitAudioContext;
			if (!Ctor) {
				this.playSegment(start, end, { labelId: options?.labelId });
				return;
			}
			const token = ++this._segmentPlayToken;
			this.playbackMode = "segment";
			this._activeSegmentLabelId = options?.labelId || null;
			this._activeSegmentStart = start;
			this._activeSegmentEnd = end;
			this._activeSegmentFilter = {
				type: "bandpass",
				freqMinHz: fLo,
				freqMaxHz: fHi
			};
			const ctx = new Ctor();
			const bandpass = ctx.createBiquadFilter();
			bandpass.type = "bandpass";
			bandpass.frequency.value = center;
			bandpass.Q.value = q;
			const gain = ctx.createGain();
			gain.gain.value = this.muted ? 0 : this.volume;
			bandpass.connect(gain);
			gain.connect(ctx.destination);
			const playback = {
				token,
				ctx,
				source: null,
				bandpass,
				gain,
				startSec: start,
				endSec: end,
				startAtCtx: 0,
				runStartSec: start,
				sourceGeneration: 0,
				rafId: 0,
				currentTimeSec: start
			};
			this._customSegmentPlayback = playback;
			this._startCustomSegmentSource(playback);
			this._setTransportState("playing_segment", "bandpass-segment-start");
			this._emit("segmentplaystart", {
				start,
				end,
				filter: {
					type: "bandpass",
					freqMinHz: fLo,
					freqMaxHz: fHi
				}
			});
			const onFrame = () => {
				if (!this._customSegmentPlayback || this._customSegmentPlayback.token !== token) return;
				const elapsed = Math.max(0, ctx.currentTime - playback.startAtCtx);
				const t = Math.min(playback.endSec, playback.runStartSec + elapsed);
				playback.currentTimeSec = t;
				this._scheduleUiUpdate({
					time: t,
					fromPlayback: true
				});
				if (t >= playback.endSec - .002) {
					if (this.loopPlayback) {
						this._loopCustomSegmentPlayback(playback);
						playback.rafId = requestAnimationFrame(onFrame);
						return;
					}
					this._stopCustomSegmentPlayback("stopped", playback.endSec, { emitEnd: true });
					return;
				}
				playback.rafId = requestAnimationFrame(onFrame);
			};
			playback.rafId = requestAnimationFrame(onFrame);
		}
		_startCustomSegmentSource(playback, source = null, startAtSec = null) {
			if (!playback || !this._customSegmentPlayback || this._customSegmentPlayback.token !== playback.token) return;
			playback.sourceGeneration = (playback.sourceGeneration || 0) + 1;
			const generation = playback.sourceGeneration;
			const nextSource = source || playback.ctx.createBufferSource();
			nextSource.buffer = this.audioBuffer;
			nextSource.connect(playback.bandpass);
			nextSource.onended = () => {
				if (!this._customSegmentPlayback || this._customSegmentPlayback.token !== playback.token) return;
				if (playback.sourceGeneration !== generation) return;
				if (this.loopPlayback) {
					this._loopCustomSegmentPlayback(playback);
					return;
				}
				this._stopCustomSegmentPlayback("stopped", playback.endSec, { emitEnd: true });
			};
			playback.source = nextSource;
			playback.runStartSec = startAtSec == null ? playback.startSec : Math.max(playback.startSec, Math.min(startAtSec, playback.endSec - .001));
			playback.startAtCtx = playback.ctx.currentTime + .005;
			nextSource.start(playback.startAtCtx, playback.runStartSec, playback.endSec - playback.runStartSec);
		}
		_loopCustomSegmentPlayback(playback) {
			if (!playback || !this._customSegmentPlayback || this._customSegmentPlayback.token !== playback.token) return;
			playback.currentTimeSec = playback.startSec;
			this._scheduleUiUpdate({
				time: playback.startSec,
				fromPlayback: false,
				immediate: true
			});
			this._emit("segmentloop", {
				start: playback.startSec,
				end: playback.endSec,
				filter: "bandpass"
			});
			this._startCustomSegmentSource(playback);
		}
		updateActiveSegmentFromLabel(label) {
			if (!label || this.playbackMode !== "segment") return;
			const labelId = label.id || null;
			if (this._activeSegmentLabelId && labelId && this._activeSegmentLabelId !== labelId) return;
			const dur = this.audioBuffer?.duration || 0;
			if (dur <= 0) return;
			const start = Math.max(0, Math.min(Number(label.start ?? 0), dur));
			const end = Math.max(start + .01, Math.min(Number(label.end ?? start + .01), dur));
			this._activeSegmentStart = start;
			this._activeSegmentEnd = end;
			if (this._customSegmentPlayback) {
				this._retargetCustomSegmentPlayback({
					start,
					end,
					freqMinHz: Number(label.freqMin),
					freqMaxHz: Number(label.freqMax)
				});
				return;
			}
			const now = this._getCurrentTime();
			if (now < start || now > end) {
				this._seekToTime(start, false, { allowCustomPlayback: true });
				if (this.loopPlayback && !this.wavesurfer?.isPlaying()) this.wavesurfer?.play();
			}
		}
		_retargetCustomSegmentPlayback({ start, end, freqMinHz, freqMaxHz }) {
			const playback = this._customSegmentPlayback;
			if (!playback || !this.audioBuffer) return;
			playback.startSec = start;
			playback.endSec = end;
			if (Number.isFinite(freqMinHz) && Number.isFinite(freqMaxHz)) {
				const nyquist = Math.max(100, this.audioBuffer.sampleRate * .5 - 10);
				const fLo = Math.max(20, Math.min(freqMinHz, freqMaxHz, nyquist - 5));
				const fHi = Math.max(fLo + 5, Math.min(Math.max(freqMinHz, freqMaxHz), nyquist));
				const center = Math.sqrt(fLo * fHi);
				const bandwidth = Math.max(10, fHi - fLo);
				const q = Math.max(.25, Math.min(40, center / bandwidth));
				playback.bandpass.frequency.value = center;
				playback.bandpass.Q.value = q;
				this._activeSegmentFilter = {
					type: "bandpass",
					freqMinHz: fLo,
					freqMaxHz: fHi
				};
			}
			const desiredStart = Math.max(start, Math.min(playback.currentTimeSec || start, end - .001));
			this._restartCustomSegmentSource(playback, desiredStart);
		}
		_restartCustomSegmentSource(playback, atSec) {
			if (!playback || !this._customSegmentPlayback || this._customSegmentPlayback.token !== playback.token) return;
			playback.sourceGeneration = (playback.sourceGeneration || 0) + 1;
			if (playback.source) {
				playback.source.onended = null;
				try {
					playback.source.stop();
				} catch {}
				try {
					playback.source.disconnect();
				} catch {}
				playback.source = null;
			}
			playback.currentTimeSec = atSec;
			this._scheduleUiUpdate({
				time: atSec,
				fromPlayback: false,
				immediate: true
			});
			this._startCustomSegmentSource(playback, null, atSec);
		}
		/**
		* @param {string} [reason]
		* @param {number | null} [targetTimeSec]
		* @param {Object} [options]
		*/
		_stopCustomSegmentPlayback(reason = "stopped", targetTimeSec = null, options = {}) {
			const active = this._customSegmentPlayback;
			if (!active) return;
			if (active.rafId) cancelAnimationFrame(active.rafId);
			active.rafId = 0;
			if (active.source) {
				active.source.onended = null;
				try {
					active.source.stop();
				} catch {}
				try {
					active.source.disconnect();
				} catch {}
			}
			try {
				active.bandpass?.disconnect();
			} catch {}
			try {
				active.gain.disconnect();
			} catch {}
			try {
				active.ctx.close();
			} catch {}
			this._customSegmentPlayback = null;
			this._activeSegmentLabelId = null;
			this._activeSegmentFilter = null;
			this._activeSegmentStart = null;
			this._activeSegmentEnd = null;
			this.playbackMode = "normal";
			this._segmentPlayToken++;
			if (Number.isFinite(targetTimeSec)) this._scheduleUiUpdate({
				time: targetTimeSec,
				fromPlayback: false,
				immediate: true
			});
			this.d.playPauseBtn.classList.remove("playing");
			this._setTransportState(reason === "paused" ? "paused_segment" : "stopped", "bandpass-segment-stop");
			if (options.emitEnd) this._emit("segmentplayend", { end: targetTimeSec ?? 0 });
		}
		_clearPlaybackFilter() {
			if (!this.wavesurfer) return;
			if (typeof this.wavesurfer.setFilter === "function") try {
				this.wavesurfer.setFilter(null);
			} catch {}
		}
		_seekToTime(timeSec, centerView = false, options = {}) {
			if (!this.audioBuffer) return;
			if (options.userInitiated) this._smoothSeekFocusUntil = performance.now() + this._playbackViewportConfig.smoothSeekFocusMs;
			if (this._customSegmentPlayback && options.allowCustomPlayback !== true) this._stopCustomSegmentPlayback("paused", this._customSegmentPlayback.currentTimeSec);
			const t = Math.max(0, Math.min(timeSec, this.audioBuffer.duration));
			if (this.wavesurfer) this.wavesurfer.setTime(t);
			this._scheduleUiUpdate({
				time: t,
				fromPlayback: false,
				centerView,
				emitSeek: true,
				immediate: true
			});
		}
		_seekByDelta(deltaSec) {
			if (!this.audioBuffer) return;
			this._seekToTime(this._getCurrentTime() + deltaSec, false);
		}
		_seekRelative(deltaSec) {
			this._seekByDelta(deltaSec);
		}
		_getCurrentTime() {
			if (this._customSegmentPlayback) return this._customSegmentPlayback.currentTimeSec;
			return this.wavesurfer ? this.wavesurfer.getCurrentTime() : 0;
		}
		_updateTimeReadout(t) {
			const nextText = formatTime(t);
			if (nextText !== this._lastTimeReadoutText) {
				this._lastTimeReadoutText = nextText;
				this.d.currentTimeDisplay.textContent = nextText;
			}
			this._updateAriaPlaybackPosition(t);
		}
		_updateAriaPlaybackPosition(currentTimeSec) {
			const slider = this.d.canvasWrapper;
			if (!slider) return;
			const duration = this.audioBuffer?.duration || 0;
			const now = Math.max(0, Math.min(currentTimeSec || 0, duration || currentTimeSec || 0));
			slider.setAttribute("aria-valuemin", "0");
			slider.setAttribute("aria-valuemax", String(duration.toFixed(3)));
			slider.setAttribute("aria-valuenow", String(now.toFixed(3)));
			slider.setAttribute("aria-valuetext", `${formatTime(now)} of ${formatTime(duration)}`);
		}
		_updatePlayhead(currentTime, fromPlayback) {
			if (!this.audioBuffer) return;
			const position = this.coords.timeToScrollX(currentTime);
			this.d.playhead.style.transform = `translateX(${position}px)`;
			this.d.waveformPlayhead.style.transform = `translateX(${position}px)`;
			if (fromPlayback && this.followPlayback && this.wavesurfer?.isPlaying()) {
				const vw = this._getViewportWidth();
				if (this.followMode === "smooth") this._applySmoothFollow(position, vw);
				else {
					const scrollLeft = this._getPrimaryScrollLeft();
					const guardLeft = scrollLeft + vw * this._playbackViewportConfig.followGuardLeftRatio;
					const guardRight = scrollLeft + vw * this._playbackViewportConfig.followGuardRightRatio;
					if (position < guardLeft || position > guardRight) this._animateFollowCatchupTo(Math.max(0, position - vw * this._playbackViewportConfig.followTargetRatio));
				}
			}
			this._syncOverviewWindowToViewport();
			if (!this._customSegmentPlayback && this._activeSegmentEnd != null && currentTime >= this._activeSegmentEnd - .005) {
				const start = this._activeSegmentStart ?? 0;
				const end = this._activeSegmentEnd;
				if (this.loopPlayback && this.wavesurfer?.isPlaying()) {
					this._seekToTime(start, false, { allowCustomPlayback: true });
					this._emit("segmentloop", {
						start,
						end,
						filter: "none"
					});
					return;
				}
				this._activeSegmentStart = null;
				this._activeSegmentLabelId = null;
				this._activeSegmentFilter = null;
				this._activeSegmentEnd = null;
				this.playbackMode = "normal";
				this._segmentPlayToken++;
				this._suppressNextPauseHandler = true;
				this.wavesurfer?.pause();
				this._seekToTime(end, false);
				this.d.playPauseBtn.classList.remove("playing");
				this._setTransportState("stopped", "segment-end");
				this._emit("segmentplayend", { end });
			}
		}
		async _generateSpectrogram({ autoAdjust = false } = {}) {
			if (!this.audioBuffer) return;
			if (this._externalSpectrogram) return;
			if (this.d.recomputingOverlay) this.d.recomputingOverlay.hidden = false;
			this._setTransportState("rendering", "spectrogram-generate");
			await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));
			const scale = this.d.scaleSelect?.value || "mel";
			const colourScale = this.d.colourScaleSelect?.value || "dbSquared";
			const windowSize = parseInt(this.d.windowSizeSelect?.value || "1024", 10);
			const overlapLevel = parseInt(this.d.overlapSelect?.value || "2", 10);
			const oversamplingLevel = parseInt(this.d.oversamplingSelect?.value || "0", 10);
			const hopSize = windowHopFromOverlap(windowSize, overlapLevel);
			const fftSize = fftSizeFromOversampling(windowSize, oversamplingLevel);
			const windowFunction = this.d.windowFunctionSelect?.value || "hann";
			const nMels = parseInt(this.d.nMelsInput?.value || "160", 10) || 160;
			const useReassigned = this.d.reassignedCheck?.checked ?? false;
			const effectiveNMels = scale === "cqt" ? Math.ceil(Math.log2(this.audioBuffer.sampleRate / 2 / CQT_FMIN) * 24) : nMels;
			const options = {
				scale,
				colourScale,
				sampleRate: this.audioBuffer.sampleRate,
				fftSize,
				windowFunction,
				nMels: effectiveNMels,
				frameRate: 100,
				usePcen: this.d.pcenEnabledCheck?.checked ?? true,
				pcenGain: parseFloat(this.d.pcenGainInput?.value || "0.8"),
				pcenBias: parseFloat(this.d.pcenBiasInput?.value || "0.01"),
				pcenRoot: parseFloat(this.d.pcenRootInput?.value || "4.0"),
				pcenSmoothing: parseFloat(this.d.pcenSmoothingInput?.value || "0.025"),
				windowSize,
				hopSize
			};
			this._activeScale = scale;
			const t0 = performance.now();
			try {
				const channelData = this.audioBuffer.getChannelData(0);
				let result;
				if (useReassigned) result = computeReassignedSpectrogram({
					channelData,
					...options
				});
				else if (this.options.enableProgressiveSpectrogram === true && this.audioBuffer.duration >= 60 && typeof this.processor.computeProgressive === "function") {
					const chunkResults = [];
					for await (const progress of this.processor.computeProgressive(channelData, {
						...options,
						chunkSeconds: 10
					})) {
						chunkResults.push(progress.result);
						this._emit("progress", {
							chunk: progress.chunk,
							totalChunks: progress.totalChunks,
							percent: progress.percent
						});
					}
					result = this._mergeProgressiveResults(chunkResults, options.nMels);
				} else result = await this.processor.compute(channelData, options);
				this.spectrogramData = result.data;
				this.spectrogramFrames = result.nFrames;
				this.spectrogramMels = result.nMels;
				this.spectrogramHopSize = result.hopSize || Math.max(1, Math.floor(this.sampleRateHz / 100));
				this.spectrogramWinLength = result.winLength || 4 * this.spectrogramHopSize;
				this._colourScale = result.colourScale || colourScale;
				this._updateSpectrogramStats();
				if (autoAdjust) {
					if ((this.d.gainModeSelect?.value || "auto") === "auto") this._autoContrast();
					const freqMode = this.d.maxFreqModeSelect?.value || "auto";
					if (freqMode === "auto") this._autoFrequency();
					else if (freqMode === "nyquist") this._setMaxFreqToNyquist();
				}
				this._updateCoords();
				this._createFrequencyLabels();
				this._buildSpectrogramGrayscale();
				this._buildSpectrogramBaseImage();
				this._drawSpectrogram();
				this._syncOverviewWindowToViewport();
				if (this.d.recomputingOverlay) this.d.recomputingOverlay.hidden = true;
				this._setTransportState("ready", "spectrogram-ready");
				const computeMs = performance.now() - t0;
				this._emit("computeTime", { durationMs: Math.round(computeMs) });
				this._emit("ready", {
					duration: this.audioBuffer.duration,
					sampleRate: this.audioBuffer.sampleRate,
					nFrames: this.spectrogramFrames,
					nMels: this.spectrogramMels
				});
			} catch (error) {
				if (this.d.recomputingOverlay) this.d.recomputingOverlay.hidden = true;
				this._setTransportState("error", "spectrogram-error");
				this._emit("error", {
					message: error?.message || String(error),
					source: "spectrogram"
				});
				throw error;
			}
		}
		/**
		* Mode 1: Raw data — enter pipeline at Stage 1 (grayscale → colorize → render).
		* Contrast sliders, color map selection, and frequency controls all remain functional.
		*/
		_setExternalSpectrogram(data, nFrames, nMels, options = {}) {
			let floats;
			if (typeof data === "string") {
				const binary = atob(data);
				const bytes = new Uint8Array(binary.length);
				for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
				floats = new Float32Array(bytes.buffer);
			} else if (data instanceof ArrayBuffer) floats = new Float32Array(data);
			else if (data instanceof Float32Array) floats = data;
			else throw new Error("setSpectrogramData: data must be Float32Array, ArrayBuffer, or base64 string");
			if (floats.length !== nFrames * nMels) throw new Error(`setSpectrogramData: data.length (${floats.length}) !== nFrames*nMels (${nFrames}*${nMels}=${nFrames * nMels})`);
			this._externalSpectrogram = true;
			this.spectrogramData = floats;
			this.spectrogramFrames = nFrames;
			this.spectrogramMels = nMels;
			if (options.sampleRate) {
				this.sampleRateHz = options.sampleRate;
				this._updateMaxFreqOptions();
			}
			if (options.scale && this.d.scaleSelect) this.d.scaleSelect.value = options.scale;
			this._updateSpectrogramStats();
			this._autoContrast();
			this._autoFrequency();
			this._buildSpectrogramGrayscale();
			this._buildSpectrogramBaseImage();
			this._drawSpectrogram();
			this._syncOverviewWindowToViewport();
			this._setTransportState("ready", "spectrogram-external-data");
			this._emit("ready", {
				duration: this.audioBuffer?.duration || 0,
				sampleRate: this.sampleRateHz,
				nFrames: this.spectrogramFrames,
				nMels: this.spectrogramMels,
				external: true
			});
		}
		/**
		* Mode 2: Pre-rendered image — bypasses entire DSP + colorization pipeline.
		* Contrast/color controls have no effect; the image is drawn as-is.
		*/
		_setExternalSpectrogramImage(image, options = {}) {
			return new Promise((resolve, reject) => {
				const apply = (img) => {
					const canvas = document.createElement("canvas");
					canvas.width = img.naturalWidth || img.width;
					canvas.height = img.naturalHeight || img.height;
					const ctx = canvas.getContext("2d");
					if (!ctx) {
						reject(/* @__PURE__ */ new Error("Could not get 2d context"));
						return;
					}
					ctx.drawImage(img, 0, 0);
					this._externalSpectrogram = true;
					this.spectrogramBaseCanvas = canvas;
					this.spectrogramData = new Float32Array(0);
					this.spectrogramFrames = canvas.width;
					this.spectrogramMels = canvas.height;
					this.spectrogramGrayInfo = null;
					if (options.freqRange || options.freqScale) this._externalImageConfig = {
						freqRange: options.freqRange || null,
						freqScale: options.freqScale || null
					};
					else this._externalImageConfig = null;
					if (options.sampleRate) {
						this.sampleRateHz = options.sampleRate;
						this._updateMaxFreqOptions();
					}
					this._setDspControlsEnabled(false);
					this._drawSpectrogram();
					this._syncOverviewWindowToViewport();
					this._setTransportState("ready", "spectrogram-external-image");
					this._emit("ready", {
						duration: this.audioBuffer?.duration || 0,
						sampleRate: this.sampleRateHz,
						nFrames: this.spectrogramFrames,
						nMels: this.spectrogramMels,
						external: true,
						externalImage: true,
						freqRange: options.freqRange || null,
						freqScale: options.freqScale || null
					});
					resolve();
				};
				if (image instanceof HTMLCanvasElement || image instanceof HTMLImageElement && image.complete) apply(image);
				else if (image instanceof HTMLImageElement) {
					image.onload = () => apply(image);
					image.onerror = reject;
				} else if (typeof image === "string") {
					const img = new Image();
					img.onload = () => apply(img);
					img.onerror = reject;
					img.src = image;
				} else reject(/* @__PURE__ */ new Error("setSpectrogramImage: unsupported image type"));
			});
		}
		/**
		* Enable or disable DSP/display controls that have no effect on
		* pre-rendered spectrogram images.
		* @param {boolean} enabled
		*/
		_setDspControlsEnabled(enabled) {
			const settingsRows = [
				this.d.scaleSelect,
				this.d.windowSizeSelect,
				this.d.windowFunctionSelect,
				this.d.overlapSelect,
				this.d.oversamplingSelect,
				this.d.nMelsInput,
				this.d.floorSlider,
				this.d.ceilSlider,
				this.d.colorSchemeSelect,
				this.d.maxFreqSelect
			];
			for (const el of settingsRows) {
				if (!el) continue;
				el.disabled = !enabled;
				const row = el.closest(".settings-row");
				if (row) row.style.opacity = enabled ? "" : "0.35";
			}
			for (const btn of [this.d.autoContrastBtn, this.d.autoFreqBtn]) if (btn) btn.disabled = !enabled;
			const pcen = this.d.pcenSection || this.container.querySelector("[data-aw=\"pcenSection\"]");
			if (pcen) pcen.style.display = enabled ? "" : "none";
			if (this.d.presetSelect) this.d.presetSelect.disabled = !enabled;
		}
		_mergeProgressiveResults(chunkResults, nMels) {
			let totalFrames = 0;
			for (const chunk of chunkResults) totalFrames += chunk.nFrames;
			const data = new Float32Array(totalFrames * nMels);
			let frameOffset = 0;
			for (const chunk of chunkResults) {
				data.set(chunk.data, frameOffset * nMels);
				frameOffset += chunk.nFrames;
			}
			const first = chunkResults[0] || {};
			return {
				data,
				nFrames: totalFrames,
				nMels,
				hopSize: first.hopSize,
				winLength: first.winLength
			};
		}
		_updateSpectrogramStats() {
			const stats = updateSpectrogramStats(this.spectrogramData);
			this.spectrogramAbsLogMin = stats.logMin;
			this.spectrogramAbsLogMax = stats.logMax;
		}
		/** Compute optimal floor/ceil from percentiles.
		*  Pass redraw=true when called from a button click. */
		_autoContrast(redraw = false) {
			if (!this.spectrogramData) return;
			const stats = autoContrastStats(this.spectrogramData, 2, 98);
			const range = this.spectrogramAbsLogMax - this.spectrogramAbsLogMin;
			if (range < 1e-8) return;
			const floorPct = Math.max(0, Math.min(100, (stats.logMin - this.spectrogramAbsLogMin) / range * 100));
			const ceilPct = Math.max(0, Math.min(100, (stats.logMax - this.spectrogramAbsLogMin) / range * 100));
			this.d.floorSlider.value = Math.round(floorPct);
			this.d.ceilSlider.value = Math.round(ceilPct);
			if (redraw) {
				this._buildSpectrogramBaseImage();
				this._drawSpectrogram();
			}
		}
		/**
		* Rebuild the max-frequency <select> options so they cover the full
		* Nyquist range of the currently loaded audio.
		*/
		_updateMaxFreqOptions() {
			const nyquist = this.sampleRateHz / 2;
			const select = this.d.maxFreqSelect;
			if (!select) return;
			const candidates = [
				1e3,
				2e3,
				4e3,
				6e3,
				8e3,
				1e4,
				12e3,
				16e3,
				2e4,
				24e3,
				32e3,
				44100,
				48e3
			];
			const prev = parseFloat(select.value) || 1e4;
			const kept = candidates.filter((f) => f <= nyquist);
			if (!kept.length || kept[kept.length - 1] < nyquist) kept.push(nyquist);
			select.innerHTML = "";
			for (const hz of kept) {
				const opt = document.createElement("option");
				opt.value = String(hz);
				if (hz === nyquist) opt.textContent = `${hz >= 1e3 ? `${(hz / 1e3).toFixed(hz % 1e3 ? 1 : 0)} kHz` : `${hz} Hz`} (Nyquist)`;
				else opt.textContent = hz >= 1e3 ? `${(hz / 1e3).toFixed(hz % 1e3 ? 1 : 0)} kHz` : `${hz} Hz`;
				select.appendChild(opt);
			}
			const values = kept;
			if (values.includes(prev)) select.value = String(prev);
			else {
				let best = values[values.length - 1];
				for (const v of values) if (v >= prev) {
					best = v;
					break;
				}
				select.value = String(best);
			}
		}
		/** Detect best maxFreq. Pass redraw=true when called from button click. */
		_autoFrequency(redraw = false) {
			if (!this.spectrogramData) return;
			const hzValue = detectMaxFrequency(this.spectrogramData, this.spectrogramFrames, this.spectrogramMels, this.sampleRateHz, this.d.scaleSelect?.value || "mel");
			const options = Array.from(this.d.maxFreqSelect.options);
			let best = options[options.length - 1];
			for (const opt of options) if (parseFloat(opt.value) >= hzValue) {
				best = opt;
				break;
			}
			this.d.maxFreqSelect.value = best.value;
			this._emit("spectrogramscalechange", { maxFreq: parseFloat(this.d.maxFreqSelect.value) });
			this._updateCoords();
			this._createFrequencyLabels();
			if (redraw) {
				this._buildSpectrogramGrayscale();
				this._buildSpectrogramBaseImage();
				this._drawSpectrogram();
			}
		}
		/** Set maxFreq dropdown to the Nyquist frequency. */
		_setMaxFreqToNyquist() {
			const nyquist = this.sampleRateHz / 2;
			const options = Array.from(this.d.maxFreqSelect.options);
			const last = options[options.length - 1];
			if (last) this.d.maxFreqSelect.value = last.value;
			this._emit("spectrogramscalechange", { maxFreq: nyquist });
			this._updateCoords();
			this._createFrequencyLabels();
		}
		_setVolume(val) {
			this.volume = Math.max(0, Math.min(1, val));
			if (this.wavesurfer) this.wavesurfer.setVolume(this.volume);
			if (this._customSegmentPlayback?.gain) this._customSegmentPlayback.gain.gain.value = this.muted ? 0 : this.volume;
			this._updateVolumeIcon();
		}
		_toggleMute() {
			if (this.muted) {
				this.muted = false;
				this._setVolume(this.preMuteVolume);
				this.d.volumeSlider.value = Math.round(this.preMuteVolume * 100);
			} else {
				this.preMuteVolume = this.volume;
				this.muted = true;
				if (this.wavesurfer) this.wavesurfer.setVolume(0);
				if (this._customSegmentPlayback?.gain) this._customSegmentPlayback.gain.gain.value = 0;
				this._updateVolumeIcon();
			}
		}
		_updateVolumeIcon() {
			const waves = this.d.volumeWaves;
			const btn = this.d.volumeToggleBtn;
			if (!waves || !btn) return;
			const vol = this.muted ? 0 : this.volume;
			waves.style.display = vol < .01 ? "none" : "";
			waves.setAttribute("d", vol < .4 ? "M15 8.5a4 4 0 010 7" : "M15 8.5a4 4 0 010 7M18 5a9 9 0 010 14");
			btn.classList.toggle("muted", vol < .01);
		}
		/** Stage 1 — expensive: spectrogram data → float32 grayscale. Run once per audio/fft/freq change. */
		_buildSpectrogramGrayscale() {
			this.spectrogramGrayInfo = buildSpectrogramGrayscale({
				spectrogramData: this.spectrogramData,
				spectrogramFrames: this.spectrogramFrames,
				spectrogramMels: this.spectrogramMels,
				sampleRateHz: this.sampleRateHz,
				maxFreq: parseFloat(this.d.maxFreqSelect.value),
				spectrogramAbsLogMin: this.spectrogramAbsLogMin,
				spectrogramAbsLogMax: this.spectrogramAbsLogMax,
				scale: this._activeScale || this.d.scaleSelect?.value || "mel",
				colourScale: this._colourScale || this.d.colourScaleSelect?.value || "dbSquared",
				noiseReduction: this.d.noiseReductionCheck?.checked ?? false,
				clahe: this.d.claheCheck?.checked ?? false
			});
			if (this.spectrogramGrayInfo && this.colorizer.ok) {
				const { gray, width, height } = this.spectrogramGrayInfo;
				this._gpuReady = this.colorizer.uploadGrayscale(gray, width, height);
			} else this._gpuReady = false;
		}
		/** Stage 2 — fast: grayscale → colored canvas.
		*  GPU path: ~0.1 ms.  JS fallback: ~20-80 ms. */
		_buildSpectrogramBaseImage() {
			if (!this.spectrogramGrayInfo) this._buildSpectrogramGrayscale();
			const floor01 = parseFloat(this.d.floorSlider.value) / 100;
			const ceil01 = parseFloat(this.d.ceilSlider.value) / 100;
			if (this._gpuReady && this.spectrogramGrayInfo) {
				this.colorizer.uploadColorLut(this.currentColorScheme);
				this.colorizer.render(floor01, ceil01);
				this.spectrogramBaseCanvas = this.colorizer.canvas;
			} else this.spectrogramBaseCanvas = colorizeSpectrogram(this.spectrogramGrayInfo, floor01, ceil01, this.currentColorScheme);
			return this.spectrogramBaseCanvas;
		}
		_drawSpectrogram() {
			if (!this._showSpectrogram) return;
			if (!this.audioBuffer || !this.spectrogramData || this.spectrogramFrames <= 0) return;
			if (!this.spectrogramBaseCanvas) this._buildSpectrogramBaseImage();
			if (!this.spectrogramBaseCanvas) return;
			const effectiveSpectrogramHeight = this._getEffectiveSpectrogramHeight();
			let freqViewSrcCrop = null;
			if (this._freqViewMin != null && this._freqViewMax != null) {
				const baseH = this.spectrogramBaseCanvas.height;
				const srcYTop = this.coords.frequencyToBaseYFraction(this._freqViewMax) * baseH;
				const srcYBottom = this.coords.frequencyToBaseYFraction(this._freqViewMin) * baseH;
				freqViewSrcCrop = {
					srcY: srcYTop,
					srcH: Math.max(1, srcYBottom - srcYTop)
				};
			}
			renderSpectrogram({
				duration: this.audioBuffer.duration,
				spectrogramCanvas: this.d.spectrogramCanvas,
				pixelsPerSecond: this.pixelsPerSecond,
				canvasHeight: effectiveSpectrogramHeight,
				baseCanvas: this.spectrogramBaseCanvas,
				sampleRate: this.audioBuffer.sampleRate,
				frameRate: 100,
				spectrogramFrames: this.spectrogramFrames,
				hopSize: this.spectrogramHopSize,
				freqViewSrcCrop
			});
			this._updateCoords();
			this._scheduleUiUpdate({
				time: this._getCurrentTime(),
				fromPlayback: false,
				immediate: true
			});
		}
		_requestSpectrogramRedraw() {
			if (this._zoomRedrawRafId) return;
			this._zoomRedrawRafId = requestAnimationFrame(() => {
				this._zoomRedrawRafId = 0;
				if (!this.audioBuffer) return;
				if (this.spectrogramData && this.spectrogramFrames > 0) this._drawSpectrogram();
				this._drawMainWaveform();
				this._emit("zoomchange", { pixelsPerSecond: this.pixelsPerSecond });
			});
		}
		_drawMainWaveform() {
			if (!this._showWaveform) return;
			const effectiveWaveformHeight = this._getEffectiveWaveformHeight();
			renderMainWaveform({
				audioBuffer: this.audioBuffer,
				amplitudeCanvas: this.d.amplitudeCanvas,
				waveformTimelineCanvas: this.d.waveformTimelineCanvas,
				waveformContent: this.d.waveformContent,
				pixelsPerSecond: this.pixelsPerSecond,
				waveformHeight: effectiveWaveformHeight,
				amplitudePeakAbs: this.amplitudePeakAbs,
				showTimeline: this._showWaveformTimeline
			});
			this._scheduleUiUpdate({
				time: this._getCurrentTime(),
				fromPlayback: false,
				immediate: true
			});
		}
		_drawOverviewWaveform() {
			if (!this._showOverview) return;
			renderOverviewWaveform({
				audioBuffer: this.audioBuffer,
				overviewCanvas: this.d.overviewCanvas,
				overviewContainer: this.d.overviewContainer,
				amplitudePeakAbs: this.amplitudePeakAbs
			});
			this._scheduleUiUpdate({
				time: this._getCurrentTime(),
				fromPlayback: false,
				immediate: true
			});
		}
		_createFrequencyLabels() {
			renderFrequencyLabels({
				labelsElement: this.d.freqLabels,
				coords: this.coords
			});
		}
		_updateAmplitudeLabels() {
			const el = this.d.amplitudeLabels;
			if (!el) return;
			el.innerHTML = "";
			const peak = Math.max(1e-6, this.amplitudePeakAbs || 1);
			const clampedH = this._getEffectiveWaveformHeight();
			const timelineH = this._showWaveformTimeline ? Math.max(18, Math.min(32, Math.round(clampedH * .22))) : 0;
			const ampH = Math.max(32, clampedH - timelineH);
			const fmt = (v) => {
				const a = Math.abs(v);
				return a >= 1 ? v.toFixed(1) : a >= .01 ? v.toFixed(2) : v.toFixed(3);
			};
			const values = [
				peak,
				peak / 2,
				0,
				-peak / 2,
				-peak
			];
			values.forEach((value, i) => {
				const frac = i / (values.length - 1);
				const span = document.createElement("span");
				span.textContent = value === 0 ? "0" : `${value > 0 ? "+" : "−"}${fmt(Math.abs(value))}`;
				span.style.top = `${frac * ampH}px`;
				span.style.transform = `translateY(${-frac * 100}%)`;
				span.style.setProperty("--tick-pos", `${frac * 100}%`);
				el.appendChild(span);
			});
		}
		_getPrimaryScrollWrapper() {
			if (!this._showSpectrogram && this._showWaveform) return this.d.waveformWrapper;
			return this.d.canvasWrapper || this.d.waveformWrapper;
		}
		_getSecondaryScrollWrapper() {
			const primary = this._getPrimaryScrollWrapper();
			if (primary === this.d.canvasWrapper) return this.d.waveformWrapper;
			if (primary === this.d.waveformWrapper) return this.d.canvasWrapper;
			return null;
		}
		_getPrimaryScrollLeft() {
			return this._getPrimaryScrollWrapper()?.scrollLeft || 0;
		}
		_getViewportWidth() {
			const primary = this._getPrimaryScrollWrapper();
			const secondary = this._getSecondaryScrollWrapper();
			return Math.max(1, primary?.clientWidth || secondary?.clientWidth || 0);
		}
		_setLinkedScrollLeft(nextLeft) {
			if (this.scrollSyncLock) return;
			this.scrollSyncLock = true;
			const vw = this._getViewportWidth();
			const tw = this.audioBuffer ? Math.max(1, Math.floor(this.coords.timeToScrollX(this.audioBuffer.duration))) : 0;
			const maxScroll = Math.max(0, tw - vw);
			const bounded = Math.max(0, Math.min(nextLeft, maxScroll));
			const primary = this._getPrimaryScrollWrapper();
			const secondary = this._getSecondaryScrollWrapper();
			if (primary) primary.scrollLeft = bounded;
			if (secondary) secondary.scrollLeft = primary?.scrollLeft ?? bounded;
			this.scrollSyncLock = false;
			this._scheduleUiUpdate({
				time: this._getCurrentTime(),
				fromPlayback: false
			});
		}
		_setPixelsPerSecond(nextPps, redraw, anchorTime, anchorPixel) {
			const minPps = Number(this.d.zoomSlider.min);
			const maxPps = Number(this.d.zoomSlider.max);
			const sliderStep = Number(this.d.zoomSlider.step || 1);
			const vw = this._getViewportWidth();
			const duration = this.audioBuffer?.duration || 0;
			const clamped = Math.max(minPps, Math.min(maxPps, nextPps));
			const changed = Math.abs(clamped - this.pixelsPerSecond) >= .01;
			const fallbackTime = this.coords.scrollXToTime(this._getPrimaryScrollLeft() + vw / 2);
			const aTime = anchorTime ?? fallbackTime;
			const aPixel = anchorPixel ?? vw / 2;
			const effectivePps = changed ? clamped : this.pixelsPerSecond;
			const estWidth = duration ? Math.max(1, Math.floor(duration * effectivePps)) : 0;
			const maxScroll = Math.max(0, estWidth - vw);
			const nextScroll = duration ? aTime * effectivePps - aPixel : 0;
			const bounded = Math.max(0, Math.min(maxScroll, nextScroll));
			if (changed) {
				this.pixelsPerSecond = effectivePps;
				this.d.zoomSlider.value = String(Math.round(effectivePps / sliderStep) * sliderStep);
				this.d.zoomValue.textContent = `${Math.round(effectivePps)} px/s`;
				if (this.wavesurfer) this.wavesurfer.zoom(effectivePps);
				if (this.audioBuffer && redraw) {
					if (this.spectrogramData && this.spectrogramFrames > 0) this._drawSpectrogram();
					this._drawMainWaveform();
					this._emit("zoomchange", { pixelsPerSecond: this.pixelsPerSecond });
				} else this._updateCoords();
			}
			this._setLinkedScrollLeft(bounded);
		}
		_fitEntireTrackInView() {
			if (!this.audioBuffer) return;
			const fitPps = this._getViewportWidth() / Math.max(.05, this.audioBuffer.duration);
			this._setPixelsPerSecond(fitPps, true, 0, 0);
		}
		_zoomByScale(scale, centerClientX, source = "spectrogram") {
			if (!this.audioBuffer) return;
			const wrapper = source === "waveform" ? this.d.waveformWrapper : this.d.canvasWrapper;
			const rect = wrapper.getBoundingClientRect();
			const localX = Math.max(0, Math.min(rect.width, centerClientX - rect.left));
			const anchorTime = this.coords.scrollXToTime(wrapper.scrollLeft + localX);
			this._setPixelsPerSecond(this.pixelsPerSecond * scale, true, anchorTime, localX);
		}
		_centerViewportAtTime(timeSec) {
			if (!this.audioBuffer) return;
			const vw = this._getViewportWidth();
			const viewDur = this.coords.scrollXToTime(vw);
			let start = timeSec - viewDur / 2;
			start = Math.max(0, Math.min(start, Math.max(0, this.audioBuffer.duration - viewDur)));
			this._setLinkedScrollLeft(this.coords.timeToScrollX(start));
		}
		_clientXToTime(clientX, source = "spectrogram") {
			const wrapper = source === "waveform" ? this.d.waveformWrapper : this.d.canvasWrapper;
			const scrollX = clientX - wrapper.getBoundingClientRect().left + wrapper.scrollLeft;
			const dur = this.audioBuffer?.duration || 0;
			const t = this.coords.scrollXToTime(scrollX);
			return Math.max(0, Math.min(t, dur));
		}
		_syncOverviewWindowToViewport() {
			if (!this._showOverview || !this.audioBuffer) return;
			if (this.interaction.isOverviewDrag) return;
			if (Math.max(this.d.spectrogramCanvas.width || 0, this.d.amplitudeCanvas.width || 0, Math.floor(this.coords.timeToScrollX(this.audioBuffer.duration))) <= 0) return;
			const vw = this._getViewportWidth();
			const viewTime = this.coords.scrollXToTime(vw);
			const startTime = this.coords.scrollXToTime(this._getPrimaryScrollLeft());
			const endTime = Math.min(this.audioBuffer.duration, startTime + viewTime);
			const nextStartNorm = startTime / this.audioBuffer.duration;
			const nextEndNorm = endTime / this.audioBuffer.duration;
			const moved = Math.abs(nextStartNorm - this.windowStartNorm) > 1e-5 || Math.abs(nextEndNorm - this.windowEndNorm) > 1e-5;
			this.windowStartNorm = nextStartNorm;
			this.windowEndNorm = nextEndNorm;
			if (moved) this._updateOverviewWindowElement();
			if (Math.abs(startTime - this._lastViewRangeTextStart) > .05 || Math.abs(endTime - this._lastViewRangeTextEnd) > .05) {
				this._lastViewRangeTextStart = startTime;
				this._lastViewRangeTextEnd = endTime;
				this.d.viewRangeDisplay.textContent = `${formatSecondsShort(startTime)} – ${formatSecondsShort(endTime)}`;
			}
			const now = performance.now();
			if ((!Number.isFinite(this._lastSelectionStart) || Math.abs(startTime - this._lastSelectionStart) > .03 || Math.abs(endTime - this._lastSelectionEnd) > .03) && now - this._lastSelectionEmitAt >= 80) {
				this._lastSelectionEmitAt = now;
				this._lastSelectionStart = startTime;
				this._lastSelectionEnd = endTime;
				this._perf.selectionEvents += 1;
				this._emit("selection", {
					start: startTime,
					end: endTime
				});
			}
		}
		_updateOverviewWindowElement() {
			if (!this._showOverview) return;
			const cw = this.d.overviewContainer.clientWidth;
			if (cw <= 0) return;
			const minW = 8;
			let left = this.windowStartNorm * cw;
			let width = Math.max(minW, this.windowEndNorm * cw - left);
			if (left + width > cw) left = Math.max(0, cw - width);
			this.d.overviewWindow.style.left = `${left}px`;
			this.d.overviewWindow.style.width = `${width}px`;
		}
		_getOverviewSpanConstraints() {
			const duration = Math.max(.001, this.audioBuffer?.duration || .001);
			const vw = Math.max(1, this._getViewportWidth());
			const minPps = Math.max(1, Number(this.d.zoomSlider?.min || 20));
			const maxPps = Math.max(minPps, Number(this.d.zoomSlider?.max || 450));
			const minSpanNorm = Math.max(MIN_WINDOW_NORM, vw / maxPps / duration);
			const maxSpanNorm = Math.min(1, vw / minPps / duration);
			return {
				minSpanNorm: Math.min(minSpanNorm, 1),
				maxSpanNorm: Math.max(minSpanNorm, maxSpanNorm)
			};
		}
		_startOverviewDrag(mode, clientX) {
			if (!this.interaction.enter({
				move: "overview-move",
				left: "overview-resize-left",
				right: "overview-resize-right"
			}[mode])) return;
			this.interaction.ctx.overviewStartX = clientX;
			this.interaction.ctx.overviewStartNorm = this.windowStartNorm;
			this.interaction.ctx.overviewEndNorm = this.windowEndNorm;
		}
		_updateOverviewDrag(clientX) {
			const sub = this.interaction.overviewSubMode;
			if (!this._showOverview || !this.audioBuffer || !sub) return;
			const ctx = this.interaction.ctx;
			if (Math.abs(clientX - ctx.overviewStartX) > 2) ctx.overviewMoved = true;
			const cw = this.d.overviewContainer.clientWidth;
			const deltaNorm = (clientX - ctx.overviewStartX) / cw;
			const { minSpanNorm, maxSpanNorm } = this._getOverviewSpanConstraints();
			const fixedStart = ctx.overviewStartNorm;
			const fixedEnd = ctx.overviewEndNorm;
			if (sub === "move") {
				let s = fixedStart + deltaNorm;
				let e = fixedEnd + deltaNorm;
				const span = e - s;
				if (s < 0) {
					s = 0;
					e = span;
				}
				if (e > 1) {
					e = 1;
					s = 1 - span;
				}
				this.windowStartNorm = s;
				this.windowEndNorm = e;
			} else if (sub === "left") {
				const nextStart = fixedStart + deltaNorm;
				const right = fixedEnd;
				const minStart = Math.max(0, right - maxSpanNorm);
				const maxStart = Math.max(minStart, right - minSpanNorm);
				this.windowStartNorm = Math.max(minStart, Math.min(maxStart, nextStart));
				this.windowEndNorm = right;
			} else if (sub === "right") {
				const nextEnd = fixedEnd + deltaNorm;
				const left = fixedStart;
				const minEnd = Math.min(1, left + minSpanNorm);
				const maxEnd = Math.min(1, left + maxSpanNorm);
				this.windowEndNorm = Math.max(minEnd, Math.min(maxEnd, nextEnd));
				this.windowStartNorm = left;
			}
			this._updateOverviewWindowElement();
			this._queueOverviewViewportApply(false);
		}
		_queueOverviewViewportApply(redrawFinal = false) {
			this._overviewNeedsFinalRedraw = this._overviewNeedsFinalRedraw || redrawFinal;
			if (this._overviewViewportRafId) return;
			this._overviewViewportRafId = requestAnimationFrame(() => {
				this._overviewViewportRafId = 0;
				const redraw = this._overviewNeedsFinalRedraw;
				this._overviewNeedsFinalRedraw = false;
				this._applyOverviewWindowToViewport(redraw);
				if (!redraw) this._requestSpectrogramRedraw();
			});
		}
		_applyOverviewWindowToViewport(redraw = true) {
			if (!this._showOverview || !this.audioBuffer) return;
			const dur = this.audioBuffer.duration;
			const viewDur = Math.max(.01, (this.windowEndNorm - this.windowStartNorm) * dur);
			const targetPps = this._getViewportWidth() / viewDur;
			this._setPixelsPerSecond(targetPps, redraw, this.windowStartNorm * dur, 0);
		}
		_handleCanvasClick(e) {
			if (this.interaction.isSeekBlocked()) return;
			if (!this.audioBuffer) return;
			this._cancelFollowCatchupAnimation();
			this._seekToTime(this._clientXToTime(e.clientX, "spectrogram"), false, { userInitiated: true });
		}
		_handleWaveformClick(e) {
			if (this.interaction.isSeekBlocked()) return;
			if (!this.audioBuffer) return;
			this._cancelFollowCatchupAnimation();
			this._seekToTime(this._clientXToTime(e.clientX, "waveform"), false, { userInitiated: true });
		}
		_blockSeekClicks(ms = 220) {
			this.interaction.blockSeekClicks(ms);
		}
		_startPlayheadDrag(event, source) {
			if (!this.audioBuffer) return;
			event.preventDefault();
			if (!this.interaction.enter("playhead-drag")) return;
			this.interaction.ctx.playheadSource = source;
			this._seekFromClientX(event.clientX, source);
		}
		_seekFromClientX(clientX, source = "spectrogram") {
			if (!this.audioBuffer) return;
			this._seekToTime(this._clientXToTime(clientX, source), false);
		}
		_startViewportPan(event, source) {
			if (!this.audioBuffer) return;
			this._cancelFollowCatchupAnimation();
			if (event.target === this.d.playhead || event.target === this.d.waveformPlayhead) return;
			if (event.button !== 0 && event.button !== 1) return;
			if (event.button === 1) event.preventDefault();
			if (!this.interaction.enter("viewport-pan")) return;
			this.interaction.ctx.panStartX = event.clientX;
			this.interaction.ctx.panStartY = event.clientY;
			this.interaction.ctx.panStartScroll = source === "waveform" ? this.d.waveformWrapper.scrollLeft : this.d.canvasWrapper.scrollLeft;
			this.interaction.ctx.panStartFreqViewMin = this._freqViewMin;
			this.interaction.ctx.panStartFreqViewMax = this._freqViewMax;
			this.interaction.ctx.panIsMiddle = event.button === 1;
			this.interaction.ctx.panSource = source;
			document.body.style.cursor = "grabbing";
		}
		_updateViewportPan(clientX, clientY) {
			const dx = clientX - this.interaction.ctx.panStartX;
			const dy = clientY - (this.interaction.ctx.panStartY || 0);
			this.interaction.ctx.panSuppressClick = Math.abs(dx) > 3 || Math.abs(dy) > 3;
			this._setLinkedScrollLeft(this.interaction.ctx.panStartScroll - dx);
			if (this.interaction.ctx.panIsMiddle && this.interaction.ctx.panSource !== "waveform" && this._showSpectrogram && (this._freqViewMin != null || this._freqViewMax != null)) {
				const height = this.d.canvasWrapper?.getBoundingClientRect().height || 1;
				const boundedMax = this.coords.boundedMaxFreq;
				const startMin = this.interaction.ctx.panStartFreqViewMin ?? 0;
				const startMax = this.interaction.ctx.panStartFreqViewMax ?? boundedMax;
				const range = startMax - startMin;
				const deltaHz = dy / height * range;
				let newMin = startMin + deltaHz;
				let newMax = startMax + deltaHz;
				if (newMin < 0) {
					newMin = 0;
					newMax = range;
				}
				if (newMax > boundedMax) {
					newMax = boundedMax;
					newMin = boundedMax - range;
				}
				this._freqViewMin = Math.max(0, newMin);
				this._freqViewMax = Math.min(boundedMax, newMax);
				this._applyFreqViewChange();
			}
		}
		_handleWheel(event, source) {
			if (!this.audioBuffer) return;
			this._cancelFollowCatchupAnimation();
			const wrapper = source === "waveform" ? this.d.waveformWrapper : this.d.canvasWrapper;
			const rect = wrapper.getBoundingClientRect();
			const localX = event.clientX - rect.left;
			const timeAtCursor = this.coords.scrollXToTime(wrapper.scrollLeft + localX);
			if (event.ctrlKey || event.metaKey) {
				event.preventDefault();
				const factor = event.deltaY < 0 ? 1.12 : 1 / 1.12;
				this._setPixelsPerSecond(this.pixelsPerSecond * factor, true, timeAtCursor, localX);
				return;
			}
			if (event.shiftKey && source !== "waveform" && this._showSpectrogram) {
				event.preventDefault();
				const canvasY = (event.clientY - rect.top) / Math.max(1, rect.height) * (this.d.spectrogramCanvas?.height || rect.height);
				const freqAtCursor = this.coords.pixelYToFrequency(canvasY);
				const zoomIn = event.deltaY < 0;
				this._verticalFreqZoom(zoomIn ? 1.15 : 1 / 1.15, freqAtCursor);
				return;
			}
			if (Math.abs(event.deltaY) > Math.abs(event.deltaX)) {
				event.preventDefault();
				this._setLinkedScrollLeft(Math.max(0, wrapper.scrollLeft + event.deltaY));
			}
		}
		_verticalFreqZoom(factor, anchorFreq) {
			const boundedMax = this.coords.boundedMaxFreq;
			const currentMin = this._freqViewMin ?? 0;
			const currentMax = this._freqViewMax ?? boundedMax;
			const anchor = Math.max(currentMin, Math.min(currentMax, anchorFreq));
			let newMin = anchor - (anchor - currentMin) / factor;
			let newMax = anchor + (currentMax - anchor) / factor;
			const minRange = Math.max(100, boundedMax * .05);
			if (newMax - newMin < minRange) {
				const mid = (newMin + newMax) / 2;
				newMin = mid - minRange / 2;
				newMax = mid + minRange / 2;
			}
			newMin = Math.max(0, newMin);
			newMax = Math.min(boundedMax, newMax);
			if (newMin <= 1 && newMax >= boundedMax - 1) {
				this._freqViewMin = null;
				this._freqViewMax = null;
			} else {
				this._freqViewMin = newMin;
				this._freqViewMax = newMax;
			}
			this._applyFreqViewChange();
		}
		_resetFreqView() {
			if (this._freqViewMin == null && this._freqViewMax == null) return;
			this._freqViewMin = null;
			this._freqViewMax = null;
			this._applyFreqViewChange();
		}
		/** Shift the frequency viewport up/down by deltaHz (positive = up). */
		_verticalFreqPan(deltaHz) {
			const boundedMax = this.coords.boundedMaxFreq;
			const currentMin = this._freqViewMin ?? 0;
			const currentMax = this._freqViewMax ?? boundedMax;
			if (currentMin <= 0 && currentMax >= boundedMax) return;
			let newMin = currentMin + deltaHz;
			let newMax = currentMax + deltaHz;
			const range = currentMax - currentMin;
			if (newMin < 0) {
				newMin = 0;
				newMax = range;
			}
			if (newMax > boundedMax) {
				newMax = boundedMax;
				newMin = boundedMax - range;
			}
			this._freqViewMin = Math.max(0, newMin);
			this._freqViewMax = Math.min(boundedMax, newMax);
			this._applyFreqViewChange();
		}
		/** Set Y-zoom to a specific level (0 = full range, 100 = max zoom). */
		_setFreqZoomFromSlider(sliderValue) {
			const boundedMax = this.coords.boundedMaxFreq;
			if (sliderValue <= 0) {
				this._resetFreqView();
				return;
			}
			const range = boundedMax * Math.max(.05, 1 - sliderValue / 100 * .95);
			const currentMid = this._freqViewMin != null && this._freqViewMax != null ? (this._freqViewMin + this._freqViewMax) / 2 : boundedMax / 2;
			let newMin = currentMid - range / 2;
			let newMax = currentMid + range / 2;
			if (newMin < 0) {
				newMin = 0;
				newMax = range;
			}
			if (newMax > boundedMax) {
				newMax = boundedMax;
				newMin = boundedMax - range;
			}
			this._freqViewMin = newMin;
			this._freqViewMax = newMax;
			this._applyFreqViewChange();
		}
		_applyFreqViewChange() {
			this._updateCoords();
			this._drawSpectrogram();
			this._createFrequencyLabels();
			this._scheduleUiUpdate({
				time: this._getCurrentTime(),
				fromPlayback: false,
				immediate: true
			});
			const btn = this.d.freqZoomResetBtn;
			if (btn) btn.hidden = this._freqViewMin == null;
			this._updateFreqScrollbar();
			this._syncFreqZoomSlider();
			this._emit("zoomchange", { pixelsPerSecond: this.pixelsPerSecond });
		}
		_updateFreqScrollbar() {
			const bar = this.d.freqScrollbar;
			const thumb = this.d.freqScrollbarThumb;
			if (!bar || !thumb) return;
			if (this._freqViewMin == null || this._freqViewMax == null) {
				bar.hidden = true;
				return;
			}
			bar.hidden = false;
			const boundedMax = this.coords.boundedMaxFreq;
			const viewRange = this._freqViewMax - this._freqViewMin;
			const thumbFrac = Math.min(1, viewRange / boundedMax);
			const topFrac = 1 - this._freqViewMax / boundedMax;
			thumb.style.height = `${Math.max(8, thumbFrac * 100)}%`;
			thumb.style.top = `${topFrac * 100}%`;
		}
		_syncFreqZoomSlider() {
			const slider = this.d.freqZoomSlider;
			if (!slider) return;
			if (this._freqViewMin == null || this._freqViewMax == null) {
				slider.value = "0";
				return;
			}
			const boundedMax = this.coords.boundedMaxFreq;
			const val = (1 - (this._freqViewMax - this._freqViewMin) / boundedMax) / .95 * 100;
			slider.value = String(Math.round(Math.max(0, Math.min(100, val))));
		}
		_applyLocalViewHeights() {
			const overlaySingleWaveform = this._transportOverlay && this._showWaveform && !this._showSpectrogram;
			const overlaySingleSpectrogram = this._transportOverlay && this._showSpectrogram && !this._showWaveform;
			const waveformFlexes = this._showWaveform && !this._showSpectrogram;
			if (this._showWaveform) {
				if (overlaySingleWaveform || waveformFlexes) {
					if (this.d.waveformContainer) {
						this.d.waveformContainer.style.height = "";
						this.d.waveformContainer.style.minHeight = waveformFlexes ? `${Math.round(this.waveformDisplayHeight)}px` : "0";
					}
				} else if (this.d.waveformContainer) {
					this.d.waveformContainer.style.minHeight = "";
					this.d.waveformContainer.style.height = `${Math.round(this.waveformDisplayHeight)}px`;
				}
			}
			if (this._showSpectrogram) {
				if (overlaySingleSpectrogram) {
					if (this.d.spectrogramContainer) {
						this.d.spectrogramContainer.style.height = "";
						this.d.spectrogramContainer.style.minHeight = "0";
					}
				} else if (this.d.spectrogramContainer) {
					this.d.spectrogramContainer.style.height = "";
					this.d.spectrogramContainer.style.minHeight = `${Math.round(this.spectrogramDisplayHeight)}px`;
				}
			}
		}
		_getEffectiveWaveformHeight() {
			if (this._showWaveform && !this._showSpectrogram) {
				const h = this.d.waveformContainer?.clientHeight;
				if (h > 0) return Math.max(64, h);
			}
			return Math.max(64, Math.floor(this.waveformDisplayHeight));
		}
		_getEffectiveSpectrogramHeight() {
			const h = this.d.spectrogramContainer?.clientHeight;
			if (h > 0) return Math.max(140, h);
			return Math.max(140, Math.floor(this.spectrogramDisplayHeight));
		}
		/** Rebuild the shared CoordinateSystem whenever any mapping parameter changes. */
		_updateCoords() {
			const extCfg = this._externalImageConfig;
			this.coords = new CoordinateSystem({
				duration: this.audioBuffer?.duration || 0,
				sampleRate: this.sampleRateHz,
				pixelsPerSecond: this.pixelsPerSecond,
				canvasWidth: this.d.spectrogramCanvas?.width || 0,
				canvasHeight: this.d.spectrogramCanvas?.height || 0,
				maxFreq: parseFloat(this.d.maxFreqSelect?.value || "10000"),
				spectrogramMels: this.spectrogramMels,
				scale: this.d.scaleSelect?.value || "mel",
				frameRate: 100,
				hopSize: this.spectrogramHopSize || 0,
				freqRange: extCfg?.freqRange || null,
				freqScale: extCfg?.freqScale || null,
				freqViewMin: this._freqViewMin,
				freqViewMax: this._freqViewMax
			});
		}
		_startViewResize(mode, clientY) {
			if (!this.interaction.enter({
				split: "view-resize-split",
				spectrogram: "view-resize-spectrogram"
			}[mode])) return;
			this.interaction.ctx.resizeStartY = clientY;
			this.interaction.ctx.resizeStartWaveformH = this.waveformDisplayHeight;
			this.interaction.ctx.resizeStartSpectrogramH = this.spectrogramDisplayHeight;
			document.body.style.cursor = "row-resize";
		}
		_updateViewResize(clientY) {
			const sub = this.interaction.viewResizeSubMode;
			if (!sub) return;
			if (sub === "split" && (!this._showWaveform || !this._showSpectrogram) || sub === "spectrogram" && !this._showSpectrogram) return;
			const ctx = this.interaction.ctx;
			const dy = clientY - ctx.resizeStartY;
			let redrawWav = false;
			if (sub === "split") {
				const total = ctx.resizeStartWaveformH + ctx.resizeStartSpectrogramH;
				let nextWav = ctx.resizeStartWaveformH + dy;
				nextWav = Math.max(64, Math.min(total - 140, nextWav));
				this.waveformDisplayHeight = nextWav;
				this.spectrogramDisplayHeight = total - nextWav;
				redrawWav = true;
			} else this.spectrogramDisplayHeight = Math.max(140, ctx.resizeStartSpectrogramH + dy);
			this._applyLocalViewHeights();
			if (redrawWav) this._updateAmplitudeLabels();
			if (!this.audioBuffer) return;
			this._queueResizeRedraw({
				redrawWaveform: redrawWav,
				redrawSpectrogram: this.spectrogramData && this.spectrogramFrames > 0
			});
		}
		_stopViewResize() {
			if (!this.interaction.isViewResize) return;
			this._flushResizeRedraw(true);
			this.interaction.release();
			document.body.style.cursor = "";
		}
		_queueResizeRedraw({ redrawWaveform = false, redrawSpectrogram = false } = {}) {
			this._viewResizeNeedsWaveformRedraw = this._viewResizeNeedsWaveformRedraw || redrawWaveform;
			this._viewResizeNeedsSpectrogramRedraw = this._viewResizeNeedsSpectrogramRedraw || redrawSpectrogram;
			if (this._viewResizeFrameId) return;
			this._viewResizeFrameId = requestAnimationFrame(() => this._flushResizeRedraw(false));
		}
		_flushResizeRedraw(force) {
			if (!this.audioBuffer) return;
			if (this._viewResizeFrameId) {
				cancelAnimationFrame(this._viewResizeFrameId);
				this._viewResizeFrameId = 0;
			}
			const redrawWaveform = force || this._viewResizeNeedsWaveformRedraw;
			const redrawSpectrogram = force || this._viewResizeNeedsSpectrogramRedraw;
			this._viewResizeNeedsWaveformRedraw = false;
			this._viewResizeNeedsSpectrogramRedraw = false;
			const savedScroll = this._getPrimaryScrollLeft();
			if (redrawWaveform) this._drawMainWaveform();
			if (redrawSpectrogram) this._drawSpectrogram();
			this._setLinkedScrollLeft(savedScroll);
			this._emit("viewresize", {
				waveformHeight: this.waveformDisplayHeight,
				spectrogramHeight: this.spectrogramDisplayHeight
			});
		}
		_setPlayState(text) {
			this.d.playStateDisplay.textContent = text;
		}
		_shouldCompactToolbarBeActive() {
			if (this._transportOverlay) return false;
			if (this._compactToolbarMode === "off") return false;
			if (this._compactToolbarMode === "on") return true;
			const root = this.d.toolbarRoot;
			if (!root) return false;
			const hadActive = this.container.classList.contains("compact-toolbar-active");
			const hadOpen = this.container.classList.contains("compact-toolbar-open");
			if (hadActive) this.container.classList.remove("compact-toolbar-active");
			if (hadOpen) this.container.classList.remove("compact-toolbar-open");
			const needsCompact = root.scrollWidth > root.clientWidth + 4;
			if (hadActive) this.container.classList.add("compact-toolbar-active");
			if (hadOpen) this.container.classList.add("compact-toolbar-open");
			return needsCompact;
		}
		_isCompactToolbarActive() {
			return this.container.classList.contains("compact-toolbar-active");
		}
		_queueCompactToolbarLayoutRefresh() {
			if (this._compactToolbarLayoutRaf) return;
			this._compactToolbarLayoutRaf = requestAnimationFrame(() => {
				this._compactToolbarLayoutRaf = 0;
				this._refreshCompactToolbarLayout();
			});
		}
		_refreshCompactToolbarLayout() {
			const active = this._shouldCompactToolbarBeActive();
			this.container.classList.toggle("compact-toolbar-active", active);
			if (!active && this._compactToolbarOpen) this._setCompactToolbarOpen(false);
			if (this.d.compactMoreBtn) {
				this.d.compactMoreBtn.disabled = !active;
				this.d.compactMoreBtn.setAttribute("aria-hidden", active ? "false" : "true");
			}
		}
		_setCompactToolbarOpen(nextOpen) {
			const open = this._isCompactToolbarActive() && !!nextOpen;
			this._compactToolbarOpen = open;
			this.container.classList.toggle("compact-toolbar-open", open);
			if (this.d.compactMoreBtn) this.d.compactMoreBtn.setAttribute("aria-expanded", open ? "true" : "false");
		}
		_toggleSettingsPanel() {
			this._setSettingsPanelOpen(!this._settingsPanelOpen);
		}
		_setSettingsPanelOpen(open) {
			this._settingsPanelOpen = !!open;
			this.container.classList.toggle("settings-panel-open", this._settingsPanelOpen);
			if (this.d.settingsToggleBtn) {
				this.d.settingsToggleBtn.classList.toggle("active", this._settingsPanelOpen);
				this.d.settingsToggleBtn.setAttribute("aria-expanded", this._settingsPanelOpen ? "true" : "false");
			}
		}
		/** Apply a DSP preset (fills all controls, triggers regeneration). */
		_applyPreset(name) {
			let p;
			if (name.startsWith("user:")) p = this._loadUserPresets()[name.slice(5)];
			else p = DSP_PROFILES[name];
			if (!p) return;
			if (this.d.scaleSelect) this.d.scaleSelect.value = p.scale || "mel";
			if (this.d.windowSizeSelect && p.windowSize != null) this.d.windowSizeSelect.value = String(p.windowSize);
			if (this.d.overlapSelect && p.overlapLevel != null) this.d.overlapSelect.value = String(p.overlapLevel);
			if (this.d.oversamplingSelect && p.oversamplingLevel != null) this.d.oversamplingSelect.value = String(p.oversamplingLevel);
			if (this.d.windowFunctionSelect) this.d.windowFunctionSelect.value = p.windowFunction;
			if (this.d.nMelsInput) this.d.nMelsInput.value = String(p.nMels);
			if (this.d.pcenEnabledCheck) this.d.pcenEnabledCheck.checked = !!p.usePcen;
			if (this.d.pcenGainInput) this.d.pcenGainInput.value = String(p.pcenGain);
			if (this.d.pcenBiasInput) this.d.pcenBiasInput.value = String(p.pcenBias);
			if (this.d.pcenRootInput) this.d.pcenRootInput.value = String(p.pcenRoot);
			if (this.d.pcenSmoothingInput) this.d.pcenSmoothingInput.value = String(p.pcenSmoothing);
			if (p.colorScheme && this.d.colorSchemeSelect) {
				this.d.colorSchemeSelect.value = p.colorScheme;
				this.currentColorScheme = p.colorScheme;
			}
			if (this.d.reassignedCheck) this.d.reassignedCheck.checked = !!p.reassigned;
			if (p.colourScale != null && this.d.colourScaleSelect) this.d.colourScaleSelect.value = p.colourScale;
			if (p.noiseReduction != null && this.d.noiseReductionCheck) this.d.noiseReductionCheck.checked = !!p.noiseReduction;
			if (p.clahe != null && this.d.claheCheck) this.d.claheCheck.checked = !!p.clahe;
			const gainMode = p.gainMode || "auto";
			if (this.d.gainModeSelect) this.d.gainModeSelect.value = gainMode;
			if (gainMode === "fixed" && p.gainFloor != null && p.gainCeil != null) {
				if (this.d.floorSlider) this.d.floorSlider.value = String(p.gainFloor);
				if (this.d.ceilSlider) this.d.ceilSlider.value = String(p.gainCeil);
			}
			const maxFreqMode = p.maxFreqMode || "auto";
			if (this.d.maxFreqModeSelect) this.d.maxFreqModeSelect.value = maxFreqMode;
			if (maxFreqMode === "fixed" && p.maxFreqHz != null && this.d.maxFreqSelect) this.d.maxFreqSelect.value = String(p.maxFreqHz);
			if (this.d.presetSelect) this.d.presetSelect.value = name;
			this._updatePresetButtons();
			this._syncQualitySlider();
			this._updatePcenSectionDimming();
			if (this.audioBuffer) this._generateSpectrogram({ autoAdjust: true });
		}
		_clearPresetHighlight() {
			if (this.d.presetSelect) this.d.presetSelect.value = "";
			this._updatePresetButtons();
			this._persistCurrentSettings();
		}
		_loadUserPresets() {
			try {
				const raw = localStorage.getItem(LS_USER_PRESETS);
				if (raw) {
					const parsed = JSON.parse(raw);
					if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
				}
			} catch {}
			return {};
		}
		_saveUserPresetsToStorage(presets) {
			try {
				localStorage.setItem(LS_USER_PRESETS, JSON.stringify(presets));
			} catch {}
		}
		/** Persist current control state so it survives page reload / new file load. */
		_persistCurrentSettings() {
			try {
				const s = this._getCurrentPresetSettings();
				localStorage.setItem(LS_LAST_SETTINGS, JSON.stringify(s));
			} catch {}
		}
		/** Load last-used settings from localStorage (returns null if none). */
		_loadLastSettings() {
			try {
				const raw = localStorage.getItem(LS_LAST_SETTINGS);
				if (raw) {
					const parsed = JSON.parse(raw);
					if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
				}
			} catch {}
			return null;
		}
		_getFavouritePreset() {
			try {
				return localStorage.getItem(LS_FAV_PRESET) || "";
			} catch {
				return "";
			}
		}
		_setFavouritePreset(key) {
			try {
				localStorage.setItem(LS_FAV_PRESET, key);
			} catch {}
		}
		/** Snapshot current DSP controls into a preset object. */
		_getCurrentPresetSettings() {
			const gainMode = this.d.gainModeSelect?.value || "auto";
			const preset = {
				scale: this.d.scaleSelect?.value || "mel",
				colourScale: this.d.colourScaleSelect?.value || "dbSquared",
				windowSize: parseInt(this.d.windowSizeSelect?.value || "1024", 10),
				overlapLevel: parseInt(this.d.overlapSelect?.value || "2", 10),
				oversamplingLevel: parseInt(this.d.oversamplingSelect?.value || "0", 10),
				windowFunction: this.d.windowFunctionSelect?.value || "hann",
				nMels: parseInt(this.d.nMelsInput?.value || "160", 10),
				usePcen: this.d.pcenEnabledCheck?.checked ?? true,
				pcenGain: parseFloat(this.d.pcenGainInput?.value || "0.8"),
				pcenBias: parseFloat(this.d.pcenBiasInput?.value || "0.01"),
				pcenRoot: parseFloat(this.d.pcenRootInput?.value || "4.0"),
				pcenSmoothing: parseFloat(this.d.pcenSmoothingInput?.value || "0.025"),
				colorScheme: this.d.colorSchemeSelect?.value || "grayscale",
				reassigned: this.d.reassignedCheck?.checked ?? false,
				noiseReduction: this.d.noiseReductionCheck?.checked ?? false,
				clahe: this.d.claheCheck?.checked ?? false,
				gainMode,
				maxFreqMode: this.d.maxFreqModeSelect?.value || "auto"
			};
			if (gainMode === "fixed") {
				preset.gainFloor = parseInt(this.d.floorSlider?.value || "0", 10);
				preset.gainCeil = parseInt(this.d.ceilSlider?.value || "100", 10);
			}
			if (preset.maxFreqMode === "fixed") preset.maxFreqHz = parseFloat(this.d.maxFreqSelect?.value || "10000");
			return preset;
		}
		_promptSaveUserPreset() {
			if (!this.d.presetSaveRow) return;
			const isOpen = !this.d.presetSaveRow.hidden;
			this.d.presetSaveRow.hidden = isOpen;
			if (!isOpen) {
				const inp = this.d.presetSaveInput;
				if (inp) {
					inp.value = "";
					inp.focus();
				}
			}
		}
		_confirmSaveUserPreset() {
			const inp = this.d.presetSaveInput;
			if (!inp) return;
			const clean = (inp.value || "").trim();
			if (!clean) return;
			if (DSP_PROFILES[clean.toLowerCase()]) {
				this._showPresetStatus("Built-in name — choose another", true);
				return;
			}
			const presets = this._loadUserPresets();
			presets[clean] = this._getCurrentPresetSettings();
			this._saveUserPresetsToStorage(presets);
			this._populatePresetDropdown();
			if (this.d.presetSelect) this.d.presetSelect.value = `user:${clean}`;
			this._updatePresetButtons();
			this.d.presetSaveRow.hidden = true;
			this._renderPresetManagerList();
			this._showPresetStatus(`Saved "${clean}"`);
		}
		_cancelSaveUserPreset() {
			if (this.d.presetSaveRow) this.d.presetSaveRow.hidden = true;
		}
		_toggleFavouritePreset() {
			const val = this.d.presetSelect?.value || "";
			if (!val) return;
			if (this._getFavouritePreset() === val) this._setFavouritePreset("");
			else this._setFavouritePreset(val);
			this._populatePresetDropdown();
			if (this.d.presetSelect) this.d.presetSelect.value = val;
			this._updatePresetButtons();
			this._renderPresetManagerList();
		}
		_updatePresetButtons() {
			const val = this.d.presetSelect?.value || "";
			const isAny = val !== "";
			if (this.d.presetFavBtn) {
				this.d.presetFavBtn.disabled = !isAny;
				const isFav = isAny && this._getFavouritePreset() === val;
				this.d.presetFavBtn.classList.toggle("active", isFav);
				this.d.presetFavBtn.title = isFav ? "Remove as default preset" : "Set as default preset";
			}
		}
		/** Show a transient status message in the preset manager panel. */
		_showPresetStatus(msg, isError = false) {
			const el = this.d.presetStatus;
			if (!el) return;
			el.textContent = msg;
			el.classList.toggle("pm-status-error", isError);
			el.classList.remove("pm-status-visible");
			el.offsetWidth;
			el.classList.add("pm-status-visible");
			clearTimeout(this._pmStatusTimer);
			this._pmStatusTimer = setTimeout(() => el.classList.remove("pm-status-visible"), 2500);
		}
		_openPresetManager() {
			if (!this.d.presetManagerPanel) return;
			const isOpen = !this.d.presetManagerPanel.hidden;
			this.d.presetManagerPanel.hidden = isOpen;
			this.d.presetManageBtn?.classList.toggle("active", !isOpen);
			if (!isOpen) this._renderPresetManagerList();
		}
		_closePresetManager() {
			if (this.d.presetManagerPanel) this.d.presetManagerPanel.hidden = true;
			this.d.presetManageBtn?.classList.remove("active");
		}
		_renderPresetManagerList() {
			const list = this.d.presetManagerList;
			if (!list) return;
			list.innerHTML = "";
			const fav = this._getFavouritePreset();
			const starSvg = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;
			const starFilledSvg = `<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;
			const trashSvg = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>`;
			const pencilSvg = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.174 6.812a1 1 0 00-3.986-3.987L3.842 16.174a2 2 0 00-.5.83l-1.321 4.352a.5.5 0 00.62.62l4.352-1.321a2 2 0 00.83-.497z"/></svg>`;
			for (const name of Object.keys(DSP_PROFILES)) {
				const key = name;
				const isFav = fav === key;
				const row = document.createElement("div");
				row.className = "pm-item";
				row.innerHTML = `
                <button class="pm-fav-btn${isFav ? " active" : ""}" title="Set as default">${isFav ? starFilledSvg : starSvg}</button>
                <span class="pm-name" title="Click to apply">${name.charAt(0).toUpperCase() + name.slice(1)}</span>
                <span class="pm-badge">built-in</span>`;
				/** @type {HTMLElement} */ row.querySelector(".pm-fav-btn").onclick = () => {
					this._setFavouritePreset(isFav ? "" : key);
					this._populatePresetDropdown();
					this._updatePresetButtons();
					this._renderPresetManagerList();
				};
				/** @type {HTMLElement} */ row.querySelector(".pm-name").onclick = () => {
					this._applyPreset(key);
					this._persistCurrentSettings();
				};
				list.appendChild(row);
			}
			const userPresets = this._loadUserPresets();
			for (const name of Object.keys(userPresets)) {
				const key = `user:${name}`;
				const isFav = fav === key;
				const row = document.createElement("div");
				row.className = "pm-item";
				row.innerHTML = `
                <button class="pm-fav-btn${isFav ? " active" : ""}" title="Set as default">${isFav ? starFilledSvg : starSvg}</button>
                <span class="pm-name" title="Click to apply"></span>
                <button class="pm-icon-btn pm-rename-btn" title="Rename">${pencilSvg}</button>
                <button class="pm-icon-btn pm-delete-btn" title="Delete">${trashSvg}</button>`;
				/** @type {HTMLElement} */ row.querySelector(".pm-name").textContent = name;
				/** @type {HTMLElement} */ row.querySelector(".pm-fav-btn").onclick = () => {
					this._setFavouritePreset(isFav ? "" : key);
					this._populatePresetDropdown();
					this._updatePresetButtons();
					this._renderPresetManagerList();
				};
				/** @type {HTMLElement} */ row.querySelector(".pm-name").onclick = () => {
					this._applyPreset(key);
					this._persistCurrentSettings();
				};
				/** @type {HTMLElement} */ row.querySelector(".pm-rename-btn").onclick = () => this._inlineRenamePreset(name, row);
				const delBtn = row.querySelector(".pm-delete-btn");
				delBtn.onclick = () => {
					if (delBtn.classList.contains("pm-confirm-delete")) this._deleteUserPresetDirect(name);
					else {
						delBtn.classList.add("pm-confirm-delete");
						delBtn.title = "Click again to confirm";
						setTimeout(() => {
							delBtn.classList.remove("pm-confirm-delete");
							delBtn.title = "Delete";
						}, 2e3);
					}
				};
				list.appendChild(row);
			}
			if (!Object.keys(DSP_PROFILES).length && !Object.keys(userPresets).length) {
				const empty = document.createElement("div");
				empty.className = "pm-empty";
				empty.textContent = "No presets yet.";
				list.appendChild(empty);
			}
		}
		/** Replace the name span with an inline input for renaming. */
		_inlineRenamePreset(oldName, row) {
			const nameSpan = row.querySelector(".pm-name");
			if (!nameSpan || row.querySelector(".pm-rename-input")) return;
			const input = document.createElement("input");
			input.type = "text";
			input.className = "pm-rename-input";
			input.value = oldName;
			input.maxLength = 40;
			nameSpan.replaceWith(input);
			input.focus();
			input.select();
			const commit = () => {
				const clean = (input.value || "").trim();
				if (!clean || clean === oldName) {
					this._renderPresetManagerList();
					return;
				}
				if (DSP_PROFILES[clean.toLowerCase()]) {
					this._showPresetStatus("Built-in name — choose another", true);
					this._renderPresetManagerList();
					return;
				}
				const presets = this._loadUserPresets();
				if (presets[clean]) {
					this._showPresetStatus(`"${clean}" already exists`, true);
					this._renderPresetManagerList();
					return;
				}
				presets[clean] = presets[oldName];
				delete presets[oldName];
				this._saveUserPresetsToStorage(presets);
				const oldKey = `user:${oldName}`;
				const newKey = `user:${clean}`;
				if (this._getFavouritePreset() === oldKey) this._setFavouritePreset(newKey);
				this._populatePresetDropdown();
				this._updatePresetButtons();
				this._renderPresetManagerList();
			};
			input.addEventListener("keydown", (e) => {
				if (e.key === "Enter") commit();
				if (e.key === "Escape") this._renderPresetManagerList();
			});
			input.addEventListener("blur", commit);
		}
		_deleteUserPresetDirect(name) {
			const presets = this._loadUserPresets();
			delete presets[name];
			this._saveUserPresetsToStorage(presets);
			const key = `user:${name}`;
			if (this._getFavouritePreset() === key) this._setFavouritePreset("");
			this._populatePresetDropdown();
			this._updatePresetButtons();
			this._renderPresetManagerList();
		}
		_exportPresets() {
			const userPresets = this._loadUserPresets();
			const data = {
				version: 1,
				favourite: this._getFavouritePreset(),
				presets: userPresets
			};
			const json = JSON.stringify(data, null, 2);
			const blob = new Blob([json], { type: "application/json" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "audio-workbench-presets.json";
			a.click();
			URL.revokeObjectURL(url);
			this._showPresetStatus("Exported");
		}
		_importPresets() {
			const input = document.createElement("input");
			input.type = "file";
			input.accept = ".json,application/json";
			input.onchange = () => {
				const file = input.files?.[0];
				if (!file) return;
				const reader = new FileReader();
				reader.onload = () => {
					try {
						const data = JSON.parse(reader.result);
						if (!data || typeof data !== "object" || typeof data.presets !== "object" || Array.isArray(data.presets)) {
							this._showPresetStatus("Invalid preset file", true);
							return;
						}
						for (const [k, v] of Object.entries(data.presets)) if (!v || typeof v !== "object" || Array.isArray(v)) {
							this._showPresetStatus(`Invalid entry: "${k}"`, true);
							return;
						}
						const existing = this._loadUserPresets();
						let imported = 0;
						for (const [k, v] of Object.entries(data.presets)) {
							if (DSP_PROFILES[k.toLowerCase()]) continue;
							existing[k] = v;
							imported++;
						}
						this._saveUserPresetsToStorage(existing);
						if (data.favourite && typeof data.favourite === "string" && data.favourite.startsWith("user:")) {
							if (existing[data.favourite.slice(5)]) this._setFavouritePreset(data.favourite);
						}
						this._populatePresetDropdown();
						this._updatePresetButtons();
						this._renderPresetManagerList();
						this._showPresetStatus(`Imported ${imported} preset(s)`);
					} catch {
						this._showPresetStatus("Failed to parse file", true);
					}
				};
				reader.readAsText(file);
			};
			input.click();
		}
		/** Apply favourite preset or last-used settings on init (no spectrogram yet). */
		_applyFavouritePresetControls() {
			const fav = this._getFavouritePreset();
			let p;
			if (fav) if (fav.startsWith("user:")) p = this._loadUserPresets()[fav.slice(5)];
			else p = DSP_PROFILES[fav];
			if (!p) {
				p = this._loadLastSettings();
				if (p && this.d.presetSelect) this.d.presetSelect.value = "";
			}
			if (!p) p = DSP_PROFILES[this.d.presetSelect?.value || "birder"];
			if (!p) return;
			if (this.d.scaleSelect) this.d.scaleSelect.value = p.scale || "mel";
			if (this.d.windowSizeSelect && p.windowSize != null) this.d.windowSizeSelect.value = String(p.windowSize);
			if (this.d.overlapSelect && p.overlapLevel != null) this.d.overlapSelect.value = String(p.overlapLevel);
			if (this.d.oversamplingSelect && p.oversamplingLevel != null) this.d.oversamplingSelect.value = String(p.oversamplingLevel);
			if (this.d.windowFunctionSelect) this.d.windowFunctionSelect.value = p.windowFunction || "hann";
			if (this.d.nMelsInput) this.d.nMelsInput.value = String(p.nMels || 160);
			if (this.d.pcenEnabledCheck) this.d.pcenEnabledCheck.checked = !!p.usePcen;
			if (this.d.pcenGainInput) this.d.pcenGainInput.value = String(p.pcenGain ?? .8);
			if (this.d.pcenBiasInput) this.d.pcenBiasInput.value = String(p.pcenBias ?? .01);
			if (this.d.pcenRootInput) this.d.pcenRootInput.value = String(p.pcenRoot ?? 4);
			if (this.d.pcenSmoothingInput) this.d.pcenSmoothingInput.value = String(p.pcenSmoothing ?? .025);
			if (p.colorScheme && this.d.colorSchemeSelect) {
				this.d.colorSchemeSelect.value = p.colorScheme;
				this.currentColorScheme = p.colorScheme;
			}
			if (this.d.reassignedCheck) this.d.reassignedCheck.checked = !!p.reassigned;
			if (p.colourScale != null && this.d.colourScaleSelect) this.d.colourScaleSelect.value = p.colourScale;
			if (p.noiseReduction != null && this.d.noiseReductionCheck) this.d.noiseReductionCheck.checked = !!p.noiseReduction;
			if (p.clahe != null && this.d.claheCheck) this.d.claheCheck.checked = !!p.clahe;
			const gainMode = p.gainMode || "auto";
			if (this.d.gainModeSelect) this.d.gainModeSelect.value = gainMode;
			if (gainMode === "fixed" && p.gainFloor != null && p.gainCeil != null) {
				if (this.d.floorSlider) this.d.floorSlider.value = String(p.gainFloor);
				if (this.d.ceilSlider) this.d.ceilSlider.value = String(p.gainCeil);
			}
			const maxFreqMode = p.maxFreqMode || "auto";
			if (this.d.maxFreqModeSelect) this.d.maxFreqModeSelect.value = maxFreqMode;
			if (maxFreqMode === "fixed" && p.maxFreqHz != null && this.d.maxFreqSelect) this.d.maxFreqSelect.value = String(p.maxFreqHz);
			this._updatePresetButtons();
		}
		_applyQualityLevel(index) {
			const level = QUALITY_LEVELS[index];
			if (!level) return;
			if (this.d.windowSizeSelect) this.d.windowSizeSelect.value = String(level.windowSize);
			if (this.d.overlapSelect) this.d.overlapSelect.value = String(level.overlapLevel);
			if (this.d.oversamplingSelect) this.d.oversamplingSelect.value = String(level.oversamplingLevel);
			if (this.d.nMelsInput) this.d.nMelsInput.value = String(level.nMels);
			if (this.d.qualityLevelDisplay) this.d.qualityLevelDisplay.textContent = level.label;
			this._clearPresetHighlight();
			if (this.audioBuffer) this._generateSpectrogram();
		}
		/** Match current controls back to a quality level (or show "Custom"). */
		_syncQualitySlider() {
			if (!this.d.qualitySlider) return;
			const ws = parseInt(this.d.windowSizeSelect?.value || "0", 10);
			const ol = parseInt(this.d.overlapSelect?.value || "-1", 10);
			const os = parseInt(this.d.oversamplingSelect?.value || "-1", 10);
			const nm = parseInt(this.d.nMelsInput?.value || "0", 10);
			const idx = QUALITY_LEVELS.findIndex((l) => l.windowSize === ws && l.overlapLevel === ol && l.oversamplingLevel === os && l.nMels === nm);
			if (idx >= 0) {
				this.d.qualitySlider.value = String(idx);
				if (this.d.qualityLevelDisplay) this.d.qualityLevelDisplay.textContent = QUALITY_LEVELS[idx].label;
			} else if (this.d.qualityLevelDisplay) this.d.qualityLevelDisplay.textContent = "Custom";
		}
		_updatePcenSectionDimming() {
			if (this.d.pcenSection) {
				const enabled = this.d.pcenEnabledCheck?.checked ?? true;
				this.d.pcenSection.style.opacity = enabled ? "" : "0.45";
				for (const el of [
					this.d.pcenGainInput,
					this.d.pcenBiasInput,
					this.d.pcenRootInput,
					this.d.pcenSmoothingInput
				]) if (el) el.disabled = !enabled;
			}
		}
		_updateColourScaleConstraints() {
			const cs = this.d.colourScaleSelect?.value || "dbSquared";
			if (this.d.pcenEnabledCheck) {
				if (cs === "phase") {
					this.d.pcenEnabledCheck.checked = false;
					this.d.pcenEnabledCheck.disabled = true;
				} else this.d.pcenEnabledCheck.disabled = false;
				this._updatePcenSectionDimming();
			}
		}
		_setTransportEnabled(enabled) {
			[
				this.d.playPauseBtn,
				this.d.stopBtn,
				this.d.jumpStartBtn,
				this.d.jumpEndBtn,
				this.d.backwardBtn,
				this.d.forwardBtn,
				this.d.followToggleBtn,
				this.d.loopToggleBtn,
				this.d.crosshairToggleBtn,
				this.d.fitViewBtn,
				this.d.resetViewBtn,
				this.d.autoContrastBtn,
				this.d.autoFreqBtn
			].forEach((btn) => {
				btn.disabled = !enabled;
			});
			this._queueCompactToolbarLayoutRefresh();
		}
		_updateToggleButtons() {
			this.followPlayback = this.followMode !== "free";
			if (this.d.followToggleBtn) {
				this.d.followToggleBtn.classList.toggle("active", this.followPlayback);
				this.d.followToggleBtn.textContent = this.followMode === "smooth" ? "Smooth" : this.followPlayback ? "Follow" : "Free";
				this.d.followToggleBtn.title = this.followMode === "smooth" ? "Smooth follow (continuous)" : this.followPlayback ? "Follow playhead" : "Free navigation";
			}
			if (this.d.loopToggleBtn) {
				this.d.loopToggleBtn.classList.toggle("active", this.loopPlayback);
				this.d.loopToggleBtn.textContent = this.loopPlayback ? "Loop On" : "Loop";
			}
			this._queueCompactToolbarLayoutRefresh();
		}
		_cycleFollowMode() {
			this.followMode = this.followMode === "free" ? "follow" : this.followMode === "follow" ? "smooth" : "free";
			if (this.followMode !== "follow") this._cancelFollowCatchupAnimation();
			this._updateToggleButtons();
			this._emit("followmodechange", { mode: this.followMode });
		}
		_toggleCrosshair() {
			this._crosshairEnabled = !this._crosshairEnabled;
			if (this.d.crosshairToggleBtn) this.d.crosshairToggleBtn.classList.toggle("active", this._crosshairEnabled);
			if (!this._crosshairEnabled) this._hideCrosshair();
		}
		/** @param {MouseEvent} e */
		_updateCrosshair(e) {
			if (!this._crosshairEnabled || !this.audioBuffer || !this.spectrogramData) return;
			const wrapper = this.d.canvasWrapper;
			const overlay = this.d.crosshairCanvas;
			const readout = this.d.crosshairReadout;
			if (!wrapper || !overlay || !readout) return;
			const rect = wrapper.getBoundingClientRect();
			const c = this.coords;
			const { time, freq, canvasX, canvasY, localX, localY } = c.clientToTimeFreq(e.clientX, e.clientY, rect, wrapper.scrollLeft);
			if (localX < 0 || localX > rect.width || localY < 0 || localY > rect.height) {
				this._hideCrosshair();
				return;
			}
			const frame = c.timeToFrame(time, this.spectrogramFrames);
			const bin = c.pixelYToBin(canvasY);
			const amplitude = this.spectrogramData[frame * this.spectrogramMels + bin] || 0;
			if (this._crosshairRafId) cancelAnimationFrame(this._crosshairRafId);
			this._crosshairRafId = requestAnimationFrame(() => {
				this._crosshairRafId = 0;
				this._drawCrosshairLines(overlay, canvasX, canvasY, c.canvasWidth, c.canvasHeight);
			});
			readout.textContent = `${time.toFixed(3) + " s"}  |  ${freq >= 1e3 ? (freq / 1e3).toFixed(2) + " kHz" : Math.round(freq) + " Hz"}  |  ${(this.d.scaleSelect?.value || "mel") === "linear" ? amplitude.toFixed(1) + " dB" : amplitude.toFixed(4)}`;
			readout.classList.add("visible");
			const rw = readout.offsetWidth || 160;
			const rh = readout.offsetHeight || 20;
			let rx = localX + 14;
			let ry = localY - rh - 8;
			if (rx + rw > rect.width) rx = localX - rw - 10;
			if (ry < 0) ry = localY + 18;
			readout.style.left = wrapper.scrollLeft + rx + "px";
			readout.style.top = ry + "px";
		}
		/**
		* @param {HTMLCanvasElement} overlay
		* @param {number} cx - x in canvas coords
		* @param {number} cy - y in canvas coords
		* @param {number} w
		* @param {number} h
		*/
		_drawCrosshairLines(overlay, cx, cy, w, h) {
			if (overlay.width !== w || overlay.height !== h) {
				overlay.width = w;
				overlay.height = h;
			}
			const ctx = overlay.getContext("2d");
			if (!ctx) return;
			ctx.clearRect(0, 0, w, h);
			ctx.strokeStyle = "rgba(255, 255, 255, 0.55)";
			ctx.lineWidth = 1;
			ctx.setLineDash([4, 4]);
			const x = Math.round(cx) + .5;
			ctx.beginPath();
			ctx.moveTo(x, 0);
			ctx.lineTo(x, h);
			ctx.stroke();
			const y = Math.round(cy) + .5;
			ctx.beginPath();
			ctx.moveTo(0, y);
			ctx.lineTo(w, y);
			ctx.stroke();
			ctx.setLineDash([]);
		}
		_hideCrosshair() {
			const overlay = this.d.crosshairCanvas;
			const readout = this.d.crosshairReadout;
			if (overlay) {
				const ctx = overlay.getContext("2d");
				if (ctx) ctx.clearRect(0, 0, overlay.width, overlay.height);
			}
			if (readout) readout.classList.remove("visible");
			if (this._crosshairRafId) {
				cancelAnimationFrame(this._crosshairRafId);
				this._crosshairRafId = 0;
			}
		}
		_cancelFollowCatchupAnimation() {
			if (this._followCatchupRafId) {
				cancelAnimationFrame(this._followCatchupRafId);
				this._followCatchupRafId = 0;
			}
			this._followCatchupAnim = null;
		}
		_animateFollowCatchupTo(targetScrollLeft) {
			if (!this.audioBuffer) return;
			const vw = this._getViewportWidth();
			const tw = Math.max(1, Math.floor(this.coords.timeToScrollX(this.audioBuffer.duration)));
			const maxScroll = Math.max(0, tw - vw);
			const target = Math.max(0, Math.min(maxScroll, targetScrollLeft));
			const start = this._getPrimaryScrollLeft();
			const delta = target - start;
			if (Math.abs(delta) < 1) return;
			const now = performance.now();
			const duration = now < this._smoothSeekFocusUntil ? this._playbackViewportConfig.followCatchupSeekDurationMs : this._playbackViewportConfig.followCatchupDurationMs;
			if (this._followCatchupAnim) {
				const pending = this._followCatchupAnim.target;
				if (Math.abs(pending - target) < 6) return;
			}
			this._cancelFollowCatchupAnimation();
			this._followCatchupAnim = {
				start,
				target,
				startedAt: now,
				duration
			};
			const easeOutCubic = (t) => 1 - (1 - t) ** 3;
			const tick = (ts) => {
				const anim = this._followCatchupAnim;
				if (!anim) return;
				const t = Math.max(0, Math.min(1, (ts - anim.startedAt) / Math.max(1, anim.duration)));
				const eased = easeOutCubic(t);
				const next = anim.start + (anim.target - anim.start) * eased;
				this._setLinkedScrollLeft(next);
				if (t >= 1) {
					this._cancelFollowCatchupAnimation();
					return;
				}
				this._followCatchupRafId = requestAnimationFrame(tick);
			};
			this._followCatchupRafId = requestAnimationFrame(tick);
		}
		_applySmoothFollow(position, viewportWidth) {
			const vw = Math.max(1, viewportWidth || this._getViewportWidth());
			const totalWidth = this.audioBuffer ? Math.max(1, Math.floor(this.coords.timeToScrollX(this.audioBuffer.duration))) : 0;
			const maxScroll = Math.max(0, totalWidth - vw);
			const target = Math.max(0, Math.min(maxScroll, position - vw * this._playbackViewportConfig.followTargetRatio));
			const current = this._getPrimaryScrollLeft();
			const delta = target - current;
			if (Math.abs(delta) < .6) return;
			const inSeekFocus = performance.now() < this._smoothSeekFocusUntil;
			const lerp = inSeekFocus ? this._playbackViewportConfig.smoothSeekLerp : this._playbackViewportConfig.smoothLerp;
			const minStep = inSeekFocus ? vw * this._playbackViewportConfig.smoothSeekMinStepRatio : vw * this._playbackViewportConfig.smoothMinStepRatio;
			const step = Math.sign(delta) * Math.min(Math.abs(delta), Math.max(minStep, Math.abs(delta) * lerp, 1));
			this._setLinkedScrollLeft(current + step);
		}
		_setInitialPlayheadPositions() {
			if (this.d.playhead) {
				this.d.playhead.style.left = "0px";
				this.d.playhead.style.transform = "translateX(0px)";
			}
			if (this.d.waveformPlayhead) {
				this.d.waveformPlayhead.style.left = "0px";
				this.d.waveformPlayhead.style.transform = "translateX(0px)";
			}
		}
		_handleKeyboardShortcuts(event) {
			if (!this.audioBuffer || isTypingContext(event.target)) return;
			switch (event.code) {
				case "Space":
					event.preventDefault();
					this._togglePlayPause();
					break;
				case "Home":
					event.preventDefault();
					this._seekToTime(0, true);
					break;
				case "End":
					event.preventDefault();
					this._seekToTime(this.audioBuffer.duration, true);
					break;
				case "KeyJ":
					event.preventDefault();
					this._seekByDelta(-5);
					break;
				case "KeyL":
					event.preventDefault();
					this._seekByDelta(5);
					break;
				case "ArrowLeft":
					event.preventDefault();
					this._seekByDelta(-SEEK_FINE_SEC);
					break;
				case "ArrowRight":
					event.preventDefault();
					this._seekByDelta(SEEK_FINE_SEC);
					break;
			}
		}
		_bindEvents() {
			const on = (target, type, fn, opts) => {
				target.addEventListener(type, fn, opts);
				this._cleanups.push(() => target.removeEventListener(type, fn, opts));
			};
			on(this.d.openFileBtn, "click", () => this.d.audioFile.click());
			on(this.d.compactMoreBtn, "click", (e) => {
				e.preventDefault();
				e.stopPropagation();
				this._setCompactToolbarOpen(!this._compactToolbarOpen);
			});
			on(this.d.settingsToggleBtn, "click", () => this._toggleSettingsPanel());
			on(this.d.settingsPanelClose, "click", () => this._setSettingsPanelOpen(false));
			on(this.d.audioFile, "change", (e) => this._handleFileSelect(e));
			on(this.d.playPauseBtn, "click", () => this._togglePlayPause());
			on(this.d.stopBtn, "click", () => this._stopPlayback());
			on(this.d.jumpStartBtn, "click", () => this._seekToTime(0, true));
			on(this.d.jumpEndBtn, "click", () => this._seekToTime(this.audioBuffer?.duration ?? 0, true));
			on(this.d.backwardBtn, "click", () => this._seekByDelta(-5));
			on(this.d.forwardBtn, "click", () => this._seekByDelta(5));
			on(this.d.followToggleBtn, "click", () => this._cycleFollowMode());
			on(this.d.loopToggleBtn, "click", () => {
				this.loopPlayback = !this.loopPlayback;
				this._updateToggleButtons();
			});
			on(this.d.crosshairToggleBtn, "click", () => this._toggleCrosshair());
			on(this.d.freqZoomResetBtn, "click", () => this._resetFreqView());
			on(this.d.fitViewBtn, "click", () => this._fitEntireTrackInView());
			on(this.d.resetViewBtn, "click", () => {
				this._setPixelsPerSecond(100, true);
				this._setLinkedScrollLeft(0);
				this._resetFreqView();
				this._syncOverviewWindowToViewport();
			});
			{
				let dragging = false;
				let startY = 0;
				let startMin = 0;
				let startMax = 0;
				const onMove = (e) => {
					if (!dragging) return;
					const spacerH = this.d.freqAxisSpacer.getBoundingClientRect().height;
					const dy = e.clientY - startY;
					const boundedMax = this.coords.boundedMaxFreq;
					const range = startMax - startMin;
					const deltaHz = dy / spacerH * range;
					let newMin = startMin + deltaHz;
					let newMax = startMax + deltaHz;
					if (newMin < 0) {
						newMin = 0;
						newMax = range;
					}
					if (newMax > boundedMax) {
						newMax = boundedMax;
						newMin = boundedMax - range;
					}
					this._freqViewMin = Math.max(0, newMin);
					this._freqViewMax = Math.min(boundedMax, newMax);
					this._applyFreqViewChange();
				};
				const onUp = () => {
					if (!dragging) return;
					dragging = false;
					document.body.style.cursor = "";
					document.removeEventListener("pointermove", onMove);
					document.removeEventListener("pointerup", onUp);
				};
				on(this.d.freqAxisSpacer, "pointerdown", (e) => {
					if (e.button !== 0 || !this._showSpectrogram) return;
					if (this._freqViewMin == null && this._freqViewMax == null) return;
					e.preventDefault();
					dragging = true;
					startY = e.clientY;
					startMin = this._freqViewMin ?? 0;
					startMax = this._freqViewMax ?? this.coords.boundedMaxFreq;
					document.body.style.cursor = "ns-resize";
					document.addEventListener("pointermove", onMove);
					document.addEventListener("pointerup", onUp);
				});
			}
			on(this.d.freqAxisSpacer, "wheel", (e) => {
				if (!this.audioBuffer || !this._showSpectrogram) return;
				e.preventDefault();
				const rect = this.d.freqAxisSpacer.getBoundingClientRect();
				const localY = e.clientY - rect.top;
				const canvasH = this.d.spectrogramCanvas?.height || rect.height;
				const canvasY = localY / Math.max(1, rect.height) * canvasH;
				const freqAtCursor = this.coords.pixelYToFrequency(canvasY);
				const zoomIn = e.deltaY < 0;
				this._verticalFreqZoom(zoomIn ? 1.15 : 1 / 1.15, freqAtCursor);
			}, { passive: false });
			on(this.d.freqZoomSlider, "input", (e) => {
				this._setFreqZoomFromSlider(parseInt(e.target.value, 10));
			});
			{
				let dragging = false;
				let startY = 0;
				let startMin = 0;
				let startMax = 0;
				const onMove = (e) => {
					if (!dragging) return;
					const barH = this.d.freqScrollbar.getBoundingClientRect().height;
					const dy = e.clientY - startY;
					const boundedMax = this.coords.boundedMaxFreq;
					const range = startMax - startMin;
					const deltaHz = dy / barH * boundedMax;
					let newMin = startMin - deltaHz;
					let newMax = startMax - deltaHz;
					if (newMin < 0) {
						newMin = 0;
						newMax = range;
					}
					if (newMax > boundedMax) {
						newMax = boundedMax;
						newMin = boundedMax - range;
					}
					this._freqViewMin = Math.max(0, newMin);
					this._freqViewMax = Math.min(boundedMax, newMax);
					this._applyFreqViewChange();
				};
				const onUp = () => {
					if (!dragging) return;
					dragging = false;
					this.d.freqScrollbar?.classList.remove("active");
					document.removeEventListener("pointermove", onMove);
					document.removeEventListener("pointerup", onUp);
				};
				on(this.d.freqScrollbarThumb, "pointerdown", (e) => {
					if (this._freqViewMin == null) return;
					e.preventDefault();
					e.stopPropagation();
					dragging = true;
					startY = e.clientY;
					startMin = this._freqViewMin ?? 0;
					startMax = this._freqViewMax ?? this.coords.boundedMaxFreq;
					this.d.freqScrollbar?.classList.add("active");
					document.addEventListener("pointermove", onMove);
					document.addEventListener("pointerup", onUp);
				});
			}
			on(this.d.scaleSelect, "change", () => {
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram({ autoAdjust: true });
			});
			on(this.d.colourScaleSelect, "change", () => {
				this._clearPresetHighlight();
				this._updateColourScaleConstraints();
				if (this.audioBuffer) this._generateSpectrogram({ autoAdjust: true });
			});
			on(this.d.presetSelect, "change", () => {
				const val = this.d.presetSelect?.value;
				if (val) this._applyPreset(val);
				this._updatePresetButtons();
				this._persistCurrentSettings();
			});
			on(this.d.presetSaveBtn, "click", () => this._promptSaveUserPreset());
			on(this.d.presetFavBtn, "click", () => this._toggleFavouritePreset());
			on(this.d.presetManageBtn, "click", () => this._openPresetManager());
			on(this.d.presetSaveConfirm, "click", () => this._confirmSaveUserPreset());
			on(this.d.presetSaveCancel, "click", () => this._cancelSaveUserPreset());
			on(this.d.presetSaveInput, "keydown", (e) => {
				if (e.key === "Enter") this._confirmSaveUserPreset();
				if (e.key === "Escape") this._cancelSaveUserPreset();
			});
			on(this.d.presetImportBtn, "click", () => this._importPresets());
			on(this.d.presetExportBtn, "click", () => this._exportPresets());
			on(this.d.qualitySlider, "input", () => {
				this._applyQualityLevel(parseInt(this.d.qualitySlider.value, 10));
			});
			on(this.d.nMelsInput, "change", () => {
				this._clearPresetHighlight();
				this._syncQualitySlider();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.pcenEnabledCheck, "change", () => {
				this._updatePcenSectionDimming();
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.pcenGainInput, "change", () => {
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.pcenBiasInput, "change", () => {
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.pcenRootInput, "change", () => {
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.pcenSmoothingInput, "change", () => {
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.windowSizeSelect, "change", () => {
				this._clearPresetHighlight();
				this._syncQualitySlider();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.overlapSelect, "change", () => {
				this._clearPresetHighlight();
				this._syncQualitySlider();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.oversamplingSelect, "change", () => {
				this._clearPresetHighlight();
				this._syncQualitySlider();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.windowFunctionSelect, "change", () => {
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.reassignedCheck, "change", () => {
				this._clearPresetHighlight();
				if (this.audioBuffer) this._generateSpectrogram();
			});
			on(this.d.noiseReductionCheck, "change", () => {
				this._persistCurrentSettings();
				if (this.spectrogramData) {
					this._buildSpectrogramGrayscale();
					this._buildSpectrogramBaseImage();
					this._drawSpectrogram();
				}
			});
			on(this.d.claheCheck, "change", () => {
				this._persistCurrentSettings();
				if (this.spectrogramData) {
					this._buildSpectrogramGrayscale();
					this._buildSpectrogramBaseImage();
					this._drawSpectrogram();
				}
			});
			on(this.d.maxFreqSelect, "change", () => {
				if (this.audioBuffer && this.spectrogramData && this.spectrogramFrames > 0) {
					this._freqViewMin = null;
					this._freqViewMax = null;
					this._emit("spectrogramscalechange", { maxFreq: parseFloat(this.d.maxFreqSelect.value) });
					this._updateCoords();
					this._createFrequencyLabels();
					this._buildSpectrogramGrayscale();
					this._buildSpectrogramBaseImage();
					this._drawSpectrogram();
					if (this.d.freqZoomResetBtn) this.d.freqZoomResetBtn.hidden = true;
				}
			});
			on(this.d.colorSchemeSelect, "change", () => {
				this.currentColorScheme = this.d.colorSchemeSelect.value;
				this._persistCurrentSettings();
				if (this.audioBuffer && this.spectrogramData && this.spectrogramFrames > 0) {
					this._buildSpectrogramBaseImage();
					this._drawSpectrogram();
				}
			});
			on(this.d.zoomSlider, "input", (e) => {
				this._setPixelsPerSecond(parseFloat(e.target.value), false);
				this._requestSpectrogramRedraw();
			});
			on(this.d.zoomSlider, "change", () => {
				if (this.spectrogramData && this.spectrogramFrames > 0) this._drawSpectrogram();
			});
			on(this.d.volumeSlider, "input", (e) => {
				this.muted = false;
				this._setVolume(parseFloat(e.target.value) / 100);
			});
			on(this.d.volumeToggleBtn, "click", () => this._toggleMute());
			const rebuildDisplay = () => {
				if (!this.spectrogramData || this.spectrogramFrames <= 0) return;
				this._buildSpectrogramBaseImage();
				this._drawSpectrogram();
			};
			on(this.d.gainModeSelect, "change", () => {
				this._persistCurrentSettings();
				if (this.d.gainModeSelect.value === "auto" && this.spectrogramData) this._autoContrast(true);
			});
			on(this.d.maxFreqModeSelect, "change", () => {
				this._persistCurrentSettings();
				if (!this.audioBuffer) return;
				const mode = this.d.maxFreqModeSelect.value;
				if (mode === "auto") this._autoFrequency(true);
				else if (mode === "nyquist") {
					this._setMaxFreqToNyquist();
					this._generateSpectrogram();
				}
			});
			on(this.d.floorSlider, "input", () => {
				this._persistCurrentSettings();
				rebuildDisplay();
			});
			on(this.d.ceilSlider, "input", () => {
				this._persistCurrentSettings();
				rebuildDisplay();
			});
			on(this.d.autoContrastBtn, "click", () => this._autoContrast(true));
			on(this.d.autoFreqBtn, "click", () => this._autoFrequency(true));
			on(this.d.canvasWrapper, "click", (e) => this._handleCanvasClick(e));
			on(this.d.canvasWrapper, "dblclick", (e) => {
				if (e.shiftKey) {
					e.preventDefault();
					this._resetFreqView();
				}
			});
			on(this.d.canvasWrapper, "mousemove", (e) => this._updateCrosshair(e));
			on(this.d.canvasWrapper, "mouseleave", () => this._hideCrosshair());
			on(this.d.waveformWrapper, "click", (e) => this._handleWaveformClick(e));
			on(this.d.canvasWrapper, "scroll", () => {
				if (this.scrollSyncLock) return;
				if (this._getPrimaryScrollWrapper() !== this.d.canvasWrapper) return;
				this._setLinkedScrollLeft(this.d.canvasWrapper.scrollLeft);
			});
			on(this.d.waveformWrapper, "scroll", () => {
				if (this.scrollSyncLock) return;
				if (this._getPrimaryScrollWrapper() !== this.d.waveformWrapper) return;
				this._setLinkedScrollLeft(this.d.waveformWrapper.scrollLeft);
			});
			on(this.d.canvasWrapper, "wheel", (e) => this._handleWheel(e, "spectrogram"), { passive: false });
			on(this.d.waveformWrapper, "wheel", (e) => this._handleWheel(e, "waveform"), { passive: false });
			on(this.d.canvasWrapper, "keydown", (e) => {
				if (!this.audioBuffer) return;
				if (isTypingContext(e.target)) return;
				switch (e.key) {
					case "ArrowLeft":
						e.preventDefault();
						this._seekByDelta(-SEEK_FINE_SEC);
						break;
					case "ArrowRight":
						e.preventDefault();
						this._seekByDelta(SEEK_FINE_SEC);
						break;
					case "Home":
						e.preventDefault();
						this._seekToTime(0, true);
						break;
					case "End":
						e.preventDefault();
						this._seekToTime(this.audioBuffer.duration, true);
						break;
					default: break;
				}
			});
			on(this.d.canvasWrapper, "pointerdown", (e) => this._startViewportPan(e, "spectrogram"));
			on(this.d.waveformWrapper, "pointerdown", (e) => this._startViewportPan(e, "waveform"));
			on(this.d.playhead, "pointerdown", (e) => this._startPlayheadDrag(e, "spectrogram"));
			on(this.d.waveformPlayhead, "pointerdown", (e) => this._startPlayheadDrag(e, "waveform"));
			on(this.d.viewSplitHandle, "pointerdown", (e) => {
				if (!this._showWaveform || !this._showSpectrogram) return;
				e.preventDefault();
				this._startViewResize("split", e.clientY);
			});
			on(this.d.spectrogramResizeHandle, "pointerdown", (e) => {
				if (!this._showSpectrogram) return;
				e.preventDefault();
				this._startViewResize("spectrogram", e.clientY);
			});
			on(document, "pointermove", (e) => {
				if (this.interaction.isViewResize) {
					this._updateViewResize(e.clientY);
					return;
				}
				if (this.interaction.isDraggingViewport) this._updateViewportPan(e.clientX, e.clientY);
				if (this.interaction.isDraggingPlayhead) this._seekFromClientX(e.clientX, this.interaction.ctx.playheadSource);
				if (this.interaction.isOverviewDrag) this._updateOverviewDrag(e.clientX);
			});
			const releaseAll = () => {
				this._stopViewResize();
				if (this.interaction.isDraggingViewport) {
					if (this.interaction.ctx.panSuppressClick) this.interaction.blockSeekClicks(50);
					document.body.style.cursor = "";
				}
				if (this.interaction.isOverviewDrag) {
					this._queueOverviewViewportApply(true);
					if (this.interaction.ctx.overviewMoved) this.interaction.blockOverviewClicks(260);
				}
				this.interaction.release();
			};
			on(document, "pointerup", releaseAll);
			on(document, "pointercancel", releaseAll);
			on(document, "keydown", (e) => this._handleKeyboardShortcuts(e));
			on(document, "keydown", (e) => {
				if (e.key === "Escape" && this._compactToolbarOpen) this._setCompactToolbarOpen(false);
			});
			on(document, "pointerdown", (e) => {
				if (!this._compactToolbarOpen) return;
				if (this.d.toolbarRoot?.contains(e.target)) return;
				this._setCompactToolbarOpen(false);
			});
			on(this.d.overviewHandleLeft, "pointerdown", (e) => {
				if (!this._showOverview) return;
				e.preventDefault();
				this._startOverviewDrag("left", e.clientX);
			});
			on(this.d.overviewHandleRight, "pointerdown", (e) => {
				if (!this._showOverview) return;
				e.preventDefault();
				this._startOverviewDrag("right", e.clientX);
			});
			on(this.d.overviewWindow, "pointerdown", (e) => {
				if (!this._showOverview) return;
				if (e.target === this.d.overviewHandleLeft || e.target === this.d.overviewHandleRight) return;
				e.preventDefault();
				this._startOverviewDrag("move", e.clientX);
			});
			on(this.d.overviewCanvas, "click", (e) => {
				if (this.interaction.isOverviewClickBlocked()) return;
				if (!this._showOverview) return;
				if (!this.audioBuffer) return;
				const rect = this.d.overviewCanvas.getBoundingClientRect();
				const xNorm = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
				this._seekToTime(xNorm * this.audioBuffer.duration, true);
			});
			on(window, "resize", () => {
				this._queueCompactToolbarLayoutRefresh();
				if (!this._shouldCompactToolbarBeActive()) this._setCompactToolbarOpen(false);
				if (!this.audioBuffer) return;
				this._drawSpectrogram();
				this._drawMainWaveform();
				this._drawOverviewWaveform();
				this._syncOverviewWindowToViewport();
				this._emit("viewresize", {
					waveformHeight: this.waveformDisplayHeight,
					spectrogramHeight: this.spectrogramDisplayHeight
				});
			});
			on(window, "beforeunload", () => this.dispose());
		}
		_bindTouchGestures() {
			const bindRecognizer = (element, source) => {
				if (!element) return;
				const rec = new GestureRecognizer(element);
				const offSwipe = rec.on("swipe", ({ dx }) => {
					if (!this.audioBuffer) return;
					this._seekRelative(dx / Math.max(1, this.pixelsPerSecond));
				});
				const offPinch = rec.on("pinch", ({ scale, centerX }) => {
					if (!this.audioBuffer) return;
					const clampedScale = Math.max(.85, Math.min(1.15, scale));
					this._zoomByScale(clampedScale, centerX, source);
				});
				const offDoubleTap = rec.on("doubletap", () => {
					if (!this.audioBuffer) return;
					this._fitEntireTrackInView();
				});
				this._cleanups.push(() => {
					offSwipe();
					offPinch();
					offDoubleTap();
					rec.dispose();
				});
			};
			bindRecognizer(this.d.waveformWrapper, "waveform");
			bindRecognizer(this.d.canvasWrapper, "spectrogram");
		}
	};
	//#endregion
	//#region src/annotations.js
	var _colorCtx = (() => {
		try {
			return document.createElement("canvas").getContext("2d");
		} catch {
			return null;
		}
	})();
	function _parseColorToRgb(color) {
		const raw = String(color || "").trim();
		if (!raw || !_colorCtx) return null;
		try {
			_colorCtx.fillStyle = "#000000";
			_colorCtx.fillStyle = raw;
			const normalized = _colorCtx.fillStyle;
			if (!normalized) return null;
			if (normalized.startsWith("#")) {
				const hex = normalized.slice(1);
				if (hex.length === 3) return {
					r: parseInt(hex[0] + hex[0], 16),
					g: parseInt(hex[1] + hex[1], 16),
					b: parseInt(hex[2] + hex[2], 16)
				};
				if (hex.length === 6) return {
					r: parseInt(hex.slice(0, 2), 16),
					g: parseInt(hex.slice(2, 4), 16),
					b: parseInt(hex.slice(4, 6), 16)
				};
			}
			const m = normalized.match(/rgba?\(([^)]+)\)/i);
			if (!m) return null;
			const parts = m[1].split(",").map((x) => Number(x.trim()));
			if (parts.length < 3 || parts.some((n, i) => i < 3 && !Number.isFinite(n))) return null;
			return {
				r: parts[0],
				g: parts[1],
				b: parts[2]
			};
		} catch {
			return null;
		}
	}
	function _rgbToHex({ r, g, b }) {
		const toHex = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
		return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
	}
	function getOverlayColorStyle(color) {
		const rgb = _parseColorToRgb(color);
		if (!rgb) return null;
		return {
			fill: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.22)`,
			edge: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.95)`,
			soft: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.55)`,
			hex: _rgbToHex(rgb)
		};
	}
	/**
	* Deterministic color for a label name — same name always produces the same
	* color.  Uses a simple string hash mapped onto a golden-angle hue wheel.
	* @param {string} name
	* @returns {string} hex color
	*/
	function colorForName(name) {
		const key = String(name || "").trim().toLowerCase();
		if (!key) return _hslToHex(0, 0, 55);
		let h = 0;
		for (let i = 0; i < key.length; i++) h = (h << 5) - h + key.charCodeAt(i) | 0;
		return _hslToHex((h % 360 + 360) % 360, 65, 58);
	}
	/**
	* Generate a perceptually distinct color using golden-angle hue rotation.
	* Avoids hues already used by existing labels (min distance in hue space).
	* @param {Array<{color?:string}>} existingLabels
	* @returns {string} hex color
	*/
	function _autoAssignColor(existingLabels) {
		const usedHues = [];
		for (const lbl of existingLabels) {
			const rgb = _parseColorToRgb(lbl.color);
			if (!rgb) continue;
			const r = rgb.r / 255, g = rgb.g / 255, b = rgb.b / 255;
			const max = Math.max(r, g, b), min = Math.min(r, g, b);
			if (max === min) continue;
			let h;
			const d = max - min;
			if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
			else if (max === g) h = ((b - r) / d + 2) / 6;
			else h = ((r - g) / d + 4) / 6;
			usedHues.push(h * 360);
		}
		const GOLDEN_ANGLE = 137.508;
		const S = 65, L = 58;
		const n = existingLabels.length;
		if (usedHues.length === 0) return _hslToHex(n * GOLDEN_ANGLE % 360, S, L);
		let bestHue = 0, bestDist = -1;
		for (let i = 0; i < 32; i++) {
			const candidateHue = (n + i) * GOLDEN_ANGLE % 360;
			let minDist = 360;
			for (const used of usedHues) {
				const diff = Math.abs(candidateHue - used);
				minDist = Math.min(minDist, diff, 360 - diff);
			}
			if (minDist > bestDist) {
				bestDist = minDist;
				bestHue = candidateHue;
			}
		}
		return _hslToHex(bestHue, S, L);
	}
	function _hslToHex(h, s, l) {
		s /= 100;
		l /= 100;
		const a = s * Math.min(l, 1 - l);
		const f = (n) => {
			const k = (n + h / 30) % 12;
			const color = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
			return Math.round(255 * Math.max(0, Math.min(1, color)));
		};
		return _rgbToHex({
			r: f(0),
			g: f(8),
			b: f(4)
		});
	}
	/**
	* @param {Object} opts
	* @param {*} opts.player
	* @param {Element|null} [opts.anchorEl]
	* @param {string} opts.initialValue
	* @param {string|null} opts.initialColor
	* @param {Record<string,string>|null} [opts.initialTags]
	* @param {(string|{name:string, color?:string, scientificName?:string, tags?:Record<string,string>})[]|null} [opts.existingLabels]
	* @param {string|null} [opts.title]
	* @param {function({name:string, color:string, scientificName?:string, tags?:Record<string,string>}):void} opts.onSubmit
	* @param {(function():void)|null} [opts.onDelete]
	*/
	function openLabelNameEditor({ player, anchorEl = null, initialValue, initialColor, initialTags = null, existingLabels = null, title = null, onSubmit, onDelete = null }) {
		const host = player?.root || player?.container || document.body;
		if (!host || typeof onSubmit !== "function") return;
		const backdrop = document.createElement("div");
		backdrop.className = "label-editor-backdrop";
		const panel = document.createElement("div");
		panel.className = "label-name-editor";
		const searchRow = document.createElement("div");
		searchRow.className = "label-search-row";
		const input = document.createElement("input");
		input.type = "text";
		input.maxLength = 96;
		input.className = "label-search-input";
		input.placeholder = title || "Search species or label…";
		input.value = String(initialValue || "").trim();
		const colorInput = document.createElement("input");
		colorInput.type = "color";
		colorInput.className = "label-search-color";
		colorInput.value = getOverlayColorStyle(initialColor)?.hex || "#0ea5e9";
		searchRow.append(input, colorInput);
		const tagPresets = player?.getTagPresets?.() || [
			{
				key: "sex",
				label: "Sex",
				options: [
					"male",
					"female",
					"unknown"
				]
			},
			{
				key: "lifeStage",
				label: "Life stage",
				options: [
					"adult",
					"juvenile",
					"immature",
					"subadult"
				]
			},
			{
				key: "soundType",
				label: "Sound type",
				options: [
					"song",
					"call",
					"alarm call",
					"flight call",
					"begging call",
					"drumming",
					"nocturnal flight call"
				]
			}
		];
		const currentTags = { ...initialTags || {} };
		const tagsRow = document.createElement("div");
		tagsRow.className = "label-tags-row";
		/** Creates a combobox-style select: options list + free-text input */
		const makeTagCombobox = (preset) => {
			const wrap = document.createElement("div");
			wrap.className = "label-tag-combo";
			const sel = document.createElement("select");
			sel.className = "label-tag-select";
			sel.title = preset.label;
			const rebuildOptions = () => {
				sel.innerHTML = "";
				const emptyOpt = document.createElement("option");
				emptyOpt.value = "";
				emptyOpt.textContent = preset.label;
				sel.appendChild(emptyOpt);
				for (const opt of preset.options) {
					const optEl = document.createElement("option");
					optEl.value = opt;
					optEl.textContent = opt;
					sel.appendChild(optEl);
				}
				const customOpt = document.createElement("option");
				customOpt.value = "__custom__";
				customOpt.textContent = "+ custom…";
				sel.appendChild(customOpt);
				const curVal = currentTags[preset.key] || "";
				if (curVal && !preset.options.includes(curVal)) {
					const tempOpt = document.createElement("option");
					tempOpt.value = curVal;
					tempOpt.textContent = curVal;
					sel.insertBefore(tempOpt, customOpt);
				}
				sel.value = curVal;
			};
			rebuildOptions();
			sel.addEventListener("change", () => {
				if (sel.value === "__custom__") {
					sel.style.display = "none";
					const inp = document.createElement("input");
					inp.type = "text";
					inp.className = "label-tag-custom-input";
					inp.placeholder = `New ${preset.label.toLowerCase()}…`;
					inp.addEventListener("keydown", (e) => {
						if (e.key === "Enter") {
							e.preventDefault();
							const val = inp.value.trim();
							if (val) {
								currentTags[preset.key] = val;
								if (!preset.options.includes(val)) player?._emit?.("tagcustomadd", {
									key: preset.key,
									value: val
								});
							}
							inp.remove();
							sel.style.display = "";
							rebuildOptions();
						} else if (e.key === "Escape") {
							e.preventDefault();
							inp.remove();
							sel.style.display = "";
							sel.value = currentTags[preset.key] || "";
						}
					});
					inp.addEventListener("blur", () => {
						const val = inp.value.trim();
						if (val) {
							currentTags[preset.key] = val;
							if (!preset.options.includes(val)) player?._emit?.("tagcustomadd", {
								key: preset.key,
								value: val
							});
						}
						inp.remove();
						sel.style.display = "";
						rebuildOptions();
					});
					wrap.appendChild(inp);
					inp.focus();
				} else if (sel.value) currentTags[preset.key] = sel.value;
				else delete currentTags[preset.key];
			});
			wrap.appendChild(sel);
			return wrap;
		};
		/** renders preset selects and the custom tag input */
		const renderTags = () => {
			tagsRow.innerHTML = "";
			for (const preset of tagPresets) tagsRow.appendChild(makeTagCombobox(preset));
			const customKeys = Object.keys(currentTags).filter((k) => !tagPresets.some((p) => p.key === k));
			for (const key of customKeys) {
				const badge = document.createElement("span");
				badge.className = "label-tag-badge";
				badge.textContent = `${key}: ${currentTags[key]}`;
				const delBtn = document.createElement("span");
				delBtn.className = "label-tag-badge-del";
				delBtn.textContent = "×";
				delBtn.addEventListener("click", () => {
					delete currentTags[key];
					renderTags();
				});
				badge.appendChild(delBtn);
				tagsRow.appendChild(badge);
			}
			const addBtn = document.createElement("button");
			addBtn.type = "button";
			addBtn.className = "label-tag-add";
			addBtn.textContent = "+ Tag";
			addBtn.addEventListener("click", () => {
				const key = prompt("Tag name (e.g. territoryStatus):");
				if (!key?.trim()) return;
				const val = prompt(`Value for "${key.trim()}":`);
				if (val == null) return;
				currentTags[key.trim()] = val.trim();
				renderTags();
			});
			tagsRow.appendChild(addBtn);
		};
		renderTags();
		const results = document.createElement("div");
		results.className = "label-search-results";
		const footer = document.createElement("div");
		footer.className = "label-search-footer";
		const hints = document.createElement("span");
		hints.className = "label-search-hints";
		hints.textContent = "↑↓ navigate · click select · dblclick confirm · esc close";
		footer.appendChild(hints);
		if (onDelete) {
			const delBtn = document.createElement("button");
			delBtn.type = "button";
			delBtn.className = "label-search-delete";
			delBtn.textContent = "Delete";
			delBtn.addEventListener("click", () => {
				close();
				onDelete();
			});
			footer.appendChild(delBtn);
		}
		const confirmBtn = document.createElement("button");
		confirmBtn.type = "button";
		confirmBtn.className = "label-search-confirm";
		confirmBtn.textContent = "Save";
		confirmBtn.addEventListener("click", () => {
			submit(input.value);
		});
		footer.appendChild(confirmBtn);
		panel.append(searchRow, tagsRow, results, footer);
		backdrop.appendChild(panel);
		host.appendChild(backdrop);
		let activeIndex = -1;
		let resultItems = [];
		let selectedScientificName = "";
		const close = () => {
			if (backdrop.parentNode) backdrop.parentNode.removeChild(backdrop);
		};
		backdrop.addEventListener("pointerdown", (e) => {
			if (e.target === backdrop) close();
		});
		const submit = (value, opts = {}) => {
			const trimmed = String(value || "").trim();
			if (!trimmed) return;
			const scientificName = String(opts?.scientificName || selectedScientificName || "").trim();
			const tags = {
				...currentTags,
				...opts?.tags || {}
			};
			for (const k of Object.keys(tags)) if (!tags[k]) delete tags[k];
			onSubmit({
				name: trimmed,
				color: colorInput.value,
				scientificName,
				tags
			});
			close();
		};
		const updateHighlight = () => {
			for (let i = 0; i < resultItems.length; i++) resultItems[i].classList.toggle("active", i === activeIndex);
			if (activeIndex >= 0 && resultItems[activeIndex]) resultItems[activeIndex].scrollIntoView({ block: "nearest" });
		};
		const renderResults = () => {
			const customOnly = (player?.getLabelEditorSuggestionMode?.() || "merge") === "custom-only";
			const taxonomy = player?.getLabelTaxonomy?.() || [];
			const recent = player?.getLabelSuggestions?.("", 8) || [];
			const filtered = player?.getLabelSuggestions?.(input.value, 8) || [];
			const custom = player?.getLabelEditorSuggestions?.(input.value, 14) || [];
			const seen = /* @__PURE__ */ new Set();
			results.innerHTML = "";
			resultItems = [];
			activeIndex = -1;
			const addResult = ({ name, scientificName = "", color = "", detail = "", tags = {} }) => {
				const label = String(name || "").trim();
				if (!label) return;
				const key = label.toLowerCase();
				if (seen.has(key)) return;
				seen.add(key);
				const row = document.createElement("button");
				row.type = "button";
				row.className = "label-search-item";
				if (color) {
					const dot = document.createElement("span");
					dot.className = "label-search-dot";
					const dotHex = getOverlayColorStyle(color)?.hex || color;
					dot.style.background = dotHex;
					row.appendChild(dot);
				}
				const nameSpan = document.createElement("span");
				nameSpan.className = "label-search-name";
				nameSpan.textContent = label;
				row.appendChild(nameSpan);
				if (scientificName) {
					const sub = document.createElement("span");
					sub.className = "label-search-sci";
					sub.textContent = scientificName;
					row.appendChild(sub);
				}
				if (detail) {
					const detailSpan = document.createElement("span");
					detailSpan.className = "label-search-detail";
					detailSpan.textContent = detail;
					row.appendChild(detailSpan);
				}
				row.addEventListener("click", () => {
					input.value = label;
					if (color) colorInput.value = getOverlayColorStyle(color)?.hex || colorInput.value;
					selectedScientificName = String(scientificName || "").trim();
					if (tags && typeof tags === "object") {
						for (const [k, v] of Object.entries(tags)) if (v) currentTags[k] = v;
						renderTags();
					}
					for (const item of resultItems) item.classList.remove("selected");
					row.classList.add("selected");
					confirmBtn.disabled = false;
				});
				row.addEventListener("dblclick", () => {
					input.value = label;
					if (color) colorInput.value = getOverlayColorStyle(color)?.hex || colorInput.value;
					selectedScientificName = String(scientificName || "").trim();
					if (tags && typeof tags === "object") {
						for (const [k, v] of Object.entries(tags)) if (v) currentTags[k] = v;
					}
					submit(label);
				});
				row.addEventListener("pointerenter", () => {
					activeIndex = resultItems.indexOf(row);
					updateHighlight();
				});
				results.appendChild(row);
				resultItems.push(row);
			};
			if (existingLabels?.length) for (const item of existingLabels) if (typeof item === "string") addResult({ name: item });
			else addResult({
				name: item.name,
				color: item.color || "",
				scientificName: item.scientificName || "",
				tags: item.tags || {}
			});
			for (const item of custom) addResult({
				name: item?.name,
				scientificName: item?.scientificName || "",
				color: item?.color || "",
				detail: item?.detail || ""
			});
			if (!customOnly) {
				for (const item of taxonomy) addResult({
					name: item?.shortcut ? `${item.shortcut}: ${item.name}` : item?.name,
					color: item?.color || ""
				});
				for (const name of recent) addResult({ name });
				for (const name of filtered) addResult({ name });
			}
		};
		input.addEventListener("input", () => {
			selectedScientificName = "";
			renderResults();
		});
		input.addEventListener("keydown", (e) => {
			const key = e.key;
			if (key === "ArrowDown") {
				e.preventDefault();
				if (resultItems.length) {
					activeIndex = (activeIndex + 1) % resultItems.length;
					updateHighlight();
				}
			} else if (key === "ArrowUp") {
				e.preventDefault();
				if (resultItems.length) {
					activeIndex = activeIndex <= 0 ? resultItems.length - 1 : activeIndex - 1;
					updateHighlight();
				}
			} else if (key === "Enter") {
				e.preventDefault();
				if (activeIndex >= 0 && resultItems[activeIndex] && !resultItems[activeIndex].classList.contains("selected")) resultItems[activeIndex].click();
				else submit(input.value);
			} else if (key === "Escape") {
				e.preventDefault();
				close();
			}
		});
		setTimeout(() => input.focus(), 0);
		input.select();
		renderResults();
	}
	/**
	* @typedef {Object} AnnotationRegion
	* @property {string} [id]
	* @property {number} start
	* @property {number} end
	* @property {string} [species]
	* @property {number} [confidence]
	* @property {string} [color]
	*/
	var AnnotationLayer = class {
		constructor() {
			this.player = null;
			this.overlay = null;
			this.annotations = [];
			this._liveLinkedId = null;
			this._unsubs = [];
			this._domCleanups = [];
			/**
			* @type {{id:string,mode?:string,startX?:number,startRegion?:object,element?:HTMLElement,pending?:boolean,moved?:boolean,forceSuppressClick?:boolean}|null}
			*/
			this._editing = null;
			this._suppressClickUntil = 0;
		}
		attach(player) {
			this.detach();
			this.player = player;
			const root = this.player?._state?.d?.waveformContent || this.player?.root?.querySelector(".waveform-content");
			if (!root) return;
			this.overlay = document.createElement("div");
			this.overlay.className = "annotation-layer";
			root.appendChild(this.overlay);
			this._unsubs.push(this.player.on("ready", () => this.render()));
			this._unsubs.push(this.player.on("zoomchange", () => this.render()));
			this._unsubs.push(this.player.on("viewresize", () => this.render()));
			this._unsubs.push(this.player.on("seek", (e) => this.highlightActiveRegion(e.detail.currentTime)));
			this._unsubs.push(this.player.on("timeupdate", (e) => this.highlightActiveRegion(e.detail.currentTime)));
			this._bindEditingInteractions(root);
			this.render();
		}
		detach() {
			for (const unsub of this._unsubs) unsub();
			this._unsubs = [];
			for (const cleanup of this._domCleanups) cleanup();
			this._domCleanups = [];
			if (this.overlay?.parentNode) this.overlay.parentNode.removeChild(this.overlay);
			this.overlay = null;
			this.player = null;
			this._editing = null;
		}
		add(annotation) {
			const region = this._normalize(annotation);
			this.annotations.push(region);
			this.render();
			this.player?._emit?.("annotationcreate", { annotation: { ...region } });
			return region.id;
		}
		set(regions = []) {
			this.annotations = regions.map((r) => this._normalize(r));
			this.render();
		}
		clear() {
			this.annotations = [];
			this.render();
		}
		remove(id) {
			this.annotations = this.annotations.filter((a) => a.id !== id);
			this.render();
		}
		getAll() {
			return [...this.annotations];
		}
		setLiveLinkedId(id = null) {
			this._liveLinkedId = id || null;
		}
		highlightActiveRegion(currentTime) {
			if (!this.overlay) return;
			for (const el of this.overlay.querySelectorAll(".annotation-region")) {
				const h = el;
				const start = parseFloat(h.dataset.start || "0");
				const end = parseFloat(h.dataset.end || "0");
				el.classList.toggle("active", currentTime >= start && currentTime <= end);
			}
		}
		exportRavenFormat(regions = this.annotations) {
			return regions.map((r) => `${r.start}\t${r.end}\t${r.species || ""}\t${r.confidence ?? ""}`).join("\n");
		}
		render() {
			if (!this.overlay || !this.player) return;
			if (this._editing) return;
			const coords = this.player._state?.coords;
			const pps = this.player._state?.pixelsPerSecond || 100;
			const duration = this.player.duration || this.player._state?.audioBuffer?.duration || 0;
			const width = Math.max(1, Math.floor(coords ? coords.timeToScrollX(duration) : duration * pps));
			this.overlay.style.width = `${width}px`;
			this.overlay.innerHTML = "";
			const sorted = [...this.annotations].sort((a, b) => a.start - b.start || a.end - b.end);
			const rowEnds = [];
			const rowMap = /* @__PURE__ */ new Map();
			for (const region of sorted) {
				let row = -1;
				for (let r = 0; r < rowEnds.length; r++) if (region.start >= rowEnds[r]) {
					row = r;
					rowEnds[r] = region.end;
					break;
				}
				if (row < 0) {
					row = rowEnds.length;
					rowEnds.push(region.end);
				}
				rowMap.set(region.id, row);
			}
			const totalRows = Math.max(1, rowEnds.length);
			/** @type {Map<string, {depth: number, localRow: number}>} */
			const localLayout = /* @__PURE__ */ new Map();
			if (totalRows > 1) {
				/** @type {Map<string, string>} */
				const par = /* @__PURE__ */ new Map();
				/** @param {string} x */
				const find = (x) => {
					while (par.get(x) !== x) {
						par.set(x, par.get(
							/** @type {string} */
							par.get(x) || x
						) || x);
						x = par.get(x);
					}
					return x;
				};
				for (const r of sorted) par.set(r.id, r.id);
				for (let i = 0; i < sorted.length; i++) for (let j = i + 1; j < sorted.length; j++) {
					if (sorted[j].start >= sorted[i].end) break;
					const ra = find(sorted[i].id), rb = find(sorted[j].id);
					if (ra !== rb) par.set(ra, rb);
				}
				/** @type {Map<string, Array<{id: string, row: number}>>} */
				const clusters = /* @__PURE__ */ new Map();
				for (const r of sorted) {
					const root = find(r.id);
					if (!clusters.has(root)) clusters.set(root, []);
					/** @type {Array<{id: string, row: number}>} */ clusters.get(root).push({
						id: r.id,
						row: rowMap.get(r.id) ?? 0
					});
				}
				for (const [, members] of clusters) {
					if (members.length < 2) continue;
					const rowsSorted = [...new Set(members.map((m) => m.row))].sort((a, b) => a - b);
					const depth = rowsSorted.length;
					if (depth < 2) continue;
					for (const m of members) localLayout.set(m.id, {
						depth,
						localRow: rowsSorted.indexOf(m.row)
					});
				}
			}
			for (const region of this.annotations) {
				const el = this._createRegionElement(region, pps);
				const layout = localLayout.get(region.id);
				if (layout && layout.depth > 1) {
					const pct = 100 / layout.depth;
					el.style.top = `${layout.localRow * pct}%`;
					el.style.height = `${pct}%`;
					el.style.bottom = "auto";
				}
				this.overlay.appendChild(el);
			}
			if (this._editing) {
				const editing = this._editing;
				const freshEl = this.overlay.querySelector(`.annotation-region[data-id="${editing.id}"]`);
				if (freshEl) {
					editing.element = freshEl;
					freshEl.classList.add("editing");
				}
			}
		}
		_createRegionElement(region, pixelsPerSecond) {
			const coords = this.player?._state?.coords;
			const el = document.createElement("div");
			el.className = "annotation-region";
			if (this._liveLinkedId && region.id === this._liveLinkedId) el.classList.add("linked-live");
			el.setAttribute("role", "button");
			el.setAttribute("tabindex", "0");
			const left = coords ? coords.timeToScrollX(region.start) : region.start * pixelsPerSecond;
			const right = coords ? coords.timeToScrollX(region.end) : region.end * pixelsPerSecond;
			el.style.left = `${Math.max(0, left)}px`;
			el.style.width = `${Math.max(1, right - left)}px`;
			const colorStyle = getOverlayColorStyle(region.color);
			if (colorStyle) {
				el.style.setProperty("--annotation-color-fill", colorStyle.fill);
				el.style.setProperty("--annotation-color-edge", colorStyle.edge);
				el.style.setProperty("--annotation-color-soft", colorStyle.soft);
			}
			el.dataset.id = region.id;
			el.dataset.start = String(region.start);
			el.dataset.end = String(region.end);
			el.title = `${region.species || "Annotation"} (${region.start.toFixed(2)}s–${region.end.toFixed(2)}s)`;
			el.innerHTML = `
            <span class="annotation-label">${escapeHtml(region.species || "Annotation")}</span>
            <span class="annotation-confidence">${region.confidence != null ? `${Math.round(region.confidence * 100)}%` : ""}</span>
            <span class="annotation-handle handle-l" data-mode="resize-l"></span>
            <span class="annotation-handle handle-r" data-mode="resize-r"></span>
        `;
			el.addEventListener("click", (event) => {
				if (performance.now() < this._suppressClickUntil) return;
				event.preventDefault();
				event.stopPropagation();
				this.player?._emit?.("labelfocus", {
					id: region.id,
					source: "waveform",
					interaction: "click"
				});
				this.player?._state?._blockSeekClicks?.(260);
				this.player?.playSegment?.(region.start, region.end, { labelId: region.id });
			});
			el.addEventListener("dblclick", (event) => {
				event.preventDefault();
				event.stopPropagation();
				this._suppressClickUntil = performance.now() + 250;
				this._renameRegionPrompt(region.id);
			});
			el.addEventListener("pointerdown", (event) => {
				if (event.button !== 0) return;
				const mode = (event.target?.closest?.(".annotation-handle"))?.dataset?.mode || "move";
				this._startEditInteraction(region.id, mode, event.clientX, el);
				event.preventDefault();
				event.stopPropagation();
				this.player?._emit?.("labelfocus", {
					id: region.id,
					source: "waveform",
					interaction: "click"
				});
			});
			el.addEventListener("pointerenter", (event) => {
				this._lastPointerX = event.clientX;
				this.player?._emit?.("labelfocus", {
					id: region.id,
					source: "waveform",
					interaction: "hover"
				});
			});
			el.addEventListener("pointerleave", () => {
				if (!this._grabbing && !this._editing) this.player?._emit?.("labelfocus", {
					id: null,
					source: "waveform",
					interaction: "hover"
				});
			});
			el.addEventListener("pointermove", (event) => {
				this._lastPointerX = event.clientX;
			});
			return el;
		}
		_bindEditingInteractions(root) {
			const onPointerMove = (e) => {
				if (!this._editing) return;
				this._updateEditInteraction(e.clientX);
				e.preventDefault();
				e.stopPropagation();
			};
			const onPointerUp = (e) => {
				if (!this._editing) return;
				this._finishEditInteraction();
				e.preventDefault();
				e.stopPropagation();
			};
			root.addEventListener("pointermove", onPointerMove, true);
			document.addEventListener("pointerup", onPointerUp, true);
			document.addEventListener("pointercancel", onPointerUp, true);
			this._domCleanups.push(() => root.removeEventListener("pointermove", onPointerMove, true));
			this._domCleanups.push(() => document.removeEventListener("pointerup", onPointerUp, true));
			this._domCleanups.push(() => document.removeEventListener("pointercancel", onPointerUp, true));
		}
		_startEditInteraction(id, mode, clientX, element) {
			const region = this.annotations.find((a) => a.id === id);
			if (!region) return;
			this._editing = {
				id,
				mode,
				startX: clientX,
				startRegion: { ...region },
				element,
				pending: mode === "move",
				moved: mode !== "move",
				forceSuppressClick: mode !== "move"
			};
			if (mode !== "move") element.classList.add("editing");
		}
		_updateEditInteraction(clientX) {
			if (!this._editing) return;
			const editing = this._editing;
			const region = this.annotations.find((a) => a.id === editing.id);
			if (!region) return;
			const pps = this.player?._state?.pixelsPerSecond || 100;
			const duration = Math.max(.001, this.player?.duration || this.player?._state?.audioBuffer?.duration || .001);
			const dt = (clientX - editing.startX) / Math.max(1, pps);
			const src = editing.startRegion;
			let next = { ...region };
			if (editing.pending) {
				if (Math.abs(clientX - editing.startX) < 4) return;
				editing.pending = false;
				editing.moved = true;
				editing.element?.classList?.add("editing");
			}
			if (editing.mode === "move") {
				const span = src.end - src.start;
				next.start = clamp(src.start + dt, 0, Math.max(0, duration - span));
				next.end = next.start + span;
			} else if (editing.mode === "resize-l") next.start = clamp(src.start + dt, 0, src.end - .01);
			else if (editing.mode === "resize-r") next.end = clamp(src.end + dt, src.start + .01, duration);
			Object.assign(region, this._normalize({
				...src,
				...next,
				id: src.id
			}));
			this.player?._state?.updateActiveSegmentFromLabel?.(region);
			this.player?._emit?.("annotationpreview", { annotation: { ...region } });
			const el = editing.element;
			if (el) {
				el.dataset.start = String(region.start);
				el.dataset.end = String(region.end);
				const coords = this.player?._state?.coords;
				const left = coords ? coords.timeToScrollX(region.start) : region.start * pps;
				const right = coords ? coords.timeToScrollX(region.end) : region.end * pps;
				el.style.left = `${Math.max(0, left)}px`;
				el.style.width = `${Math.max(1, right - left)}px`;
			}
		}
		_finishEditInteraction() {
			if (!this._editing) return;
			const editing = this._editing;
			const shouldSuppressClick = editing.forceSuppressClick || editing.moved;
			editing.element?.classList?.remove("editing");
			const region = this.annotations.find((a) => a.id === editing.id);
			if (region && editing.moved) this.player?._emit?.("annotationupdate", { annotation: { ...region } });
			this._editing = null;
			if (shouldSuppressClick) {
				this._suppressClickUntil = performance.now() + 250;
				this.render();
			}
		}
		/**
		* Blender-style grab for waveform annotations (horizontal only).
		*/
		startGrab(annotationId) {
			const region = this.annotations.find((a) => a.id === annotationId);
			if (!region || this._grabbing) return;
			const el = this.overlay?.querySelector?.(`.annotation-region[data-id="${region.id}"]`);
			if (!el) return;
			const snapshot = { ...region };
			el.classList.add("editing");
			this._editing = {
				id: annotationId,
				mode: "move",
				startX: this._lastPointerX ?? 0,
				startRegion: snapshot,
				element: el,
				pending: false,
				moved: true,
				forceSuppressClick: true
			};
			this._grabbing = true;
			const onMove = (e) => {
				this._updateEditInteraction(e.clientX);
			};
			const confirm = (e) => {
				e?.preventDefault?.();
				e?.stopPropagation?.();
				cleanup();
				this._finishEditInteraction();
			};
			const cancel = (e) => {
				e?.preventDefault?.();
				e?.stopPropagation?.();
				cleanup();
				Object.assign(region, snapshot);
				el.classList.remove("editing");
				this._editing = null;
				this._suppressClickUntil = performance.now() + 250;
				this.render();
			};
			const onKey = (e) => {
				if (e.key === "Escape") cancel(e);
				if (e.key === "g") confirm(e);
			};
			const cleanup = () => {
				this._grabbing = false;
				document.removeEventListener("pointermove", onMove, true);
				document.removeEventListener("pointerdown", confirm, true);
				document.removeEventListener("keydown", onKey, true);
			};
			document.addEventListener("pointermove", onMove, true);
			document.addEventListener("pointerdown", confirm, true);
			document.addEventListener("keydown", onKey, true);
		}
		_renameRegionPrompt(id) {
			const region = this.annotations.find((a) => a.id === id);
			if (!region) return;
			const current = region.species || "Annotation";
			const el = this.overlay?.querySelector?.(`.annotation-region[data-id="${region.id}"]`);
			openLabelNameEditor({
				player: this.player,
				anchorEl: el || this.overlay,
				initialValue: current,
				initialColor: region.color,
				onSubmit: ({ name, color }) => {
					const currentHex = getOverlayColorStyle(region.color)?.hex || "";
					if (name === current && color === currentHex) return;
					region.species = name;
					region.color = color;
					this.player?._emit?.("annotationupdate", { annotation: { ...region } });
					this.render();
				}
			});
		}
		_normalize(annotation) {
			const start = Number(annotation?.start ?? 0);
			const end = Number(annotation?.end ?? start);
			if (!Number.isFinite(start) || !Number.isFinite(end)) throw new Error("AnnotationLayer: start/end must be finite numbers");
			const s = Math.max(0, Math.min(start, end));
			const e = Math.max(0, Math.max(start, end));
			return {
				id: annotation?.id || `ann_${Math.random().toString(36).slice(2, 10)}`,
				start: s,
				end: Math.max(s + .01, e),
				species: annotation?.species || "",
				confidence: annotation?.confidence,
				color: String(annotation?.color || "").trim()
			};
		}
	};
	/**
	* @typedef {Object} SpectrogramLabel
	* @property {string} [id]
	* @property {number} start
	* @property {number} end
	* @property {number} freqMin
	* @property {number} freqMax
	* @property {string} [label]
	* @property {string} [color]
	*/
	var SpectrogramLabelLayer = class {
		constructor() {
			this.player = null;
			this.overlay = null;
			this.labels = [];
			this.drawMode = true;
			this.stampMode = false;
			this._stampGhostEl = null;
			this._stampAxisLock = false;
			this._stampRefLabelId = null;
			this._axisConstraint = null;
			this._liveLinkedId = null;
			this._unsubs = [];
			this._domCleanups = [];
			this._draftEl = null;
			this._drawing = null;
			/**
			* @type {{id:string,mode?:string,startX?:number,startY?:number,startTime?:number,startFreq?:number,startCanvasY?:number,startLabel?:object,element?:HTMLElement,pending?:boolean,moved?:boolean,forceSuppressClick?:boolean}|null}
			*/
			this._editing = null;
			this._counter = 1;
			this._suppressClickUntil = 0;
			this._suppressContextMenuUntil = 0;
			this._focusedLabelId = null;
			this._clipboard = null;
		}
		attach(player) {
			this.detach();
			this.player = player;
			const root = this.player?._state?.d?.canvasWrapper || this.player?.root?.querySelector(".canvas-wrapper");
			if (!root) return;
			this.overlay = document.createElement("div");
			this.overlay.className = "spectrogram-label-layer";
			root.appendChild(this.overlay);
			this._unsubs.push(this.player.on("ready", () => this.render()));
			this._unsubs.push(this.player.on("zoomchange", () => this.render()));
			this._unsubs.push(this.player.on("viewresize", () => this.render()));
			this._unsubs.push(this.player.on("spectrogramscalechange", () => this.render()));
			this._unsubs.push(this.player.on("timeupdate", (e) => this.highlightActiveLabel(e.detail.currentTime)));
			this._unsubs.push(this.player.on("labelfocus", (e) => {
				this._focusedLabelId = e?.detail?.id || null;
				this._updateFocusedVisual();
			}));
			this._bindDrawingInteractions(root);
			this.render();
		}
		detach() {
			for (const unsub of this._unsubs) unsub();
			this._unsubs = [];
			for (const cleanup of this._domCleanups) cleanup();
			this._domCleanups = [];
			if (this.overlay?.parentNode) this.overlay.parentNode.removeChild(this.overlay);
			this.overlay = null;
			this.player = null;
			this._draftEl = null;
			this._drawing = null;
			this._editing = null;
			this._stampGhostEl = null;
			this._stampAxisLock = false;
		}
		add(label) {
			const region = this._normalize(label);
			this.labels.push(region);
			this.render();
			this.player?._emit?.("spectrogramlabelcreate", { label: { ...region } });
			return region.id;
		}
		set(labels = []) {
			this.labels = labels.map((l) => this._normalize(l));
			this.render();
		}
		clear() {
			this.labels = [];
			this.render();
		}
		remove(id) {
			this.labels = this.labels.filter((l) => l.id !== id);
			this.render();
		}
		/** Accept a suggestion label — change its origin to 'manual'. */
		_acceptSuggestion(id) {
			const label = this.labels.find((l) => l.id === id);
			if (!label) return;
			label.origin = "manual";
			this.render();
			this.player?._emit?.("spectrogramlabelupdate", { label: { ...label } });
		}
		getAll() {
			return [...this.labels];
		}
		setLiveLinkedId(id = null) {
			this._liveLinkedId = id || null;
		}
		copyLabel(id) {
			const label = this.labels.find((l) => l.id === id);
			if (!label) return;
			this._clipboard = { ...label };
		}
		pasteLabel(atTime = null) {
			if (!this._clipboard) return null;
			const src = this._clipboard;
			const duration = src.end - src.start;
			const t = atTime ?? this.player?.currentTime ?? src.start;
			const region = this._normalize({
				start: t,
				end: t + duration,
				freqMin: src.freqMin,
				freqMax: src.freqMax,
				label: src.label,
				color: src.color,
				scientificName: src.scientificName,
				commonName: src.commonName,
				origin: src.origin,
				author: src.author,
				tags: src.tags ? { ...src.tags } : {}
			});
			this.add(region);
			return region;
		}
		/**
		* Returns the reference label for stamp/paste defaults.
		* Priority: 1) explicit stamp ref  2) click-focused  3) last label
		*/
		_getReferenceLabelForDefaults() {
			if (this._stampRefLabelId) {
				const ref = this.labels.find((l) => l.id === this._stampRefLabelId);
				if (ref) return ref;
			}
			if (this._focusedLabelId) {
				const focused = this.labels.find((l) => l.id === this._focusedLabelId);
				if (focused) return focused;
			}
			return this.labels.length ? this.labels[this.labels.length - 1] : null;
		}
		highlightActiveLabel(currentTime) {
			if (!this.overlay) return;
			for (const el of this.overlay.querySelectorAll(".spectrogram-label-region")) {
				const h = el;
				const start = parseFloat(h.dataset.start || "0");
				const end = parseFloat(h.dataset.end || "0");
				el.classList.toggle("active", currentTime >= start && currentTime <= end);
			}
		}
		/** Set .focused class on only the single focused label element. */
		_updateFocusedVisual() {
			if (!this.overlay) return;
			for (const el of this.overlay.querySelectorAll(".spectrogram-label-region")) {
				const h = el;
				h.classList.toggle("focused", h.dataset?.id === this._focusedLabelId);
			}
		}
		render() {
			if (!this.overlay || !this.player) return;
			if (this._editing) return;
			const state = this.player._state;
			const c = state?.coords;
			const duration = this.player.duration || state?.audioBuffer?.duration || 0;
			const pps = state?.pixelsPerSecond || 100;
			const width = Math.max(1, Math.floor(c ? c.timeToScrollX(duration) : duration * pps));
			const height = Math.max(1, state?.d?.spectrogramCanvas?.height || 1);
			this.overlay.style.width = `${width}px`;
			this.overlay.style.height = `${height}px`;
			this.overlay.innerHTML = "";
			const elements = [];
			const geometries = [];
			for (const label of this.labels) {
				const el = this._createLabelElement(label, width, height);
				const geo = this._toGeometry(label, width, height);
				this.overlay.appendChild(el);
				elements.push(el);
				geometries.push(geo);
			}
			this._resolveTextCollisions(elements, geometries);
			if (this._editing) {
				const editing = this._editing;
				const freshEl = this.overlay.querySelector(`.spectrogram-label-region[data-id="${editing.id}"]`);
				if (freshEl) {
					editing.element = freshEl;
					freshEl.classList.add("editing");
				}
			}
			this._updateFocusedVisual();
			if (this._stampGhostEl && this.stampMode) this.overlay.appendChild(this._stampGhostEl);
		}
		/**
		* Detect overlapping text badges and nudge colliding ones to bottom-left.
		* Uses a simple greedy approach: first label keeps top-left, subsequent
		* labels that would collide get moved to bottom-left of their box.
		* @param {HTMLElement[]} elements
		* @param {Array<{left: number, top: number, width: number, height: number}>} geometries
		*/
		_resolveTextCollisions(elements, geometries) {
			const TEXT_H = 16;
			const occupiedRects = [];
			for (let i = 0; i < elements.length; i++) {
				const geo = geometries[i];
				const textEl = elements[i].querySelector(".spectrogram-label-text");
				if (!textEl) continue;
				const textWidth = Math.min(Math.max(geo.width * .7, 100), 200);
				let rect = {
					left: geo.left,
					top: geo.top,
					right: geo.left + textWidth,
					bottom: geo.top + TEXT_H
				};
				if (occupiedRects.some((r) => rect.left < r.right && rect.right > r.left && rect.top < r.bottom && rect.bottom > r.top)) {
					textEl.classList.add("label-text-bottom");
					rect = {
						left: geo.left,
						top: geo.top + geo.height - TEXT_H,
						right: geo.left + textWidth,
						bottom: geo.top + geo.height
					};
				}
				occupiedRects.push(rect);
			}
		}
		_createLabelElement(label, canvasWidth, canvasHeight) {
			const el = document.createElement("div");
			el.className = "spectrogram-label-region";
			const isSuggestion = label.origin && label.origin !== "manual" && label.origin !== "xeno-canto";
			if (isSuggestion) el.classList.add("suggestion");
			if (this._liveLinkedId && label.id === this._liveLinkedId) el.classList.add("linked-live");
			el.setAttribute("role", "button");
			el.setAttribute("tabindex", "0");
			this._applyGeometryToElement(el, this._toGeometry(label, canvasWidth, canvasHeight));
			const colorStyle = getOverlayColorStyle(label.color);
			if (colorStyle) {
				el.style.setProperty("--spectrogram-label-color", colorStyle.fill);
				el.style.setProperty("--spectrogram-label-edge", colorStyle.edge);
				el.style.setProperty("--spectrogram-label-soft", colorStyle.soft);
			}
			el.dataset.id = label.id;
			el.dataset.start = String(label.start);
			el.dataset.end = String(label.end);
			el.title = `${label.label || "Label"} ${label.start.toFixed(2)}s–${label.end.toFixed(2)}s / ${Math.round(label.freqMin)}-${Math.round(label.freqMax)} Hz`;
			el.innerHTML = `
            <span class="spectrogram-label-text">${escapeHtml(label.label || "Label")}</span>
            <span class="spectrogram-label-meta">${Math.round(label.freqMin)}-${Math.round(label.freqMax)} Hz</span>
            <button class="label-edit-btn" type="button" title="Edit label">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
                </svg>
            </button>
            <button class="label-delete-btn" type="button" title="Delete label">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
                </svg>
            </button>
            <span class="label-handle handle-tl" data-mode="resize-tl"></span>
            <span class="label-handle handle-tr" data-mode="resize-tr"></span>
            <span class="label-handle handle-bl" data-mode="resize-bl"></span>
            <span class="label-handle handle-br" data-mode="resize-br"></span>
            <span class="label-handle handle-l" data-mode="resize-l"></span>
            <span class="label-handle handle-r" data-mode="resize-r"></span>
            <span class="label-handle handle-t" data-mode="resize-t"></span>
            <span class="label-handle handle-b" data-mode="resize-b"></span>
            ${isSuggestion ? `
            <button class="label-accept-btn" type="button" title="Accept label">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="20 6 9 17 4 12"/>
                </svg>
            </button>
            <button class="label-discard-btn" type="button" title="Discard label">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
            ` : ""}
        `;
			const editBtn = el.querySelector(".label-edit-btn");
			if (editBtn) {
				editBtn.addEventListener("click", (event) => {
					event.preventDefault();
					event.stopPropagation();
					this._suppressClickUntil = performance.now() + 250;
					this._renameSpectrogramLabelPrompt(label.id);
				});
				editBtn.addEventListener("pointerdown", (event) => {
					event.stopPropagation();
				});
			}
			const deleteBtn = el.querySelector(".label-delete-btn");
			if (deleteBtn) {
				deleteBtn.addEventListener("click", (event) => {
					event.preventDefault();
					event.stopPropagation();
					this._suppressClickUntil = performance.now() + 250;
					this.remove(label.id);
					this.player?._emit?.("spectrogramlabelremove", { label: { ...label } });
				});
				deleteBtn.addEventListener("pointerdown", (event) => {
					event.stopPropagation();
				});
			}
			const acceptBtn = el.querySelector(".label-accept-btn");
			if (acceptBtn) {
				acceptBtn.addEventListener("click", (event) => {
					event.preventDefault();
					event.stopPropagation();
					this._suppressClickUntil = performance.now() + 250;
					this._acceptSuggestion(label.id);
				});
				acceptBtn.addEventListener("pointerdown", (event) => {
					event.stopPropagation();
				});
			}
			const discardBtn = el.querySelector(".label-discard-btn");
			if (discardBtn) {
				discardBtn.addEventListener("click", (event) => {
					event.preventDefault();
					event.stopPropagation();
					this._suppressClickUntil = performance.now() + 250;
					this.remove(label.id);
					this.player?._emit?.("spectrogramlabelremove", { label: { ...label } });
				});
				discardBtn.addEventListener("pointerdown", (event) => {
					event.stopPropagation();
				});
			}
			el.addEventListener("click", (event) => {
				if (performance.now() < this._suppressClickUntil) return;
				event.stopPropagation();
				event.preventDefault();
				this.player?._emit?.("labelfocus", {
					id: label.id,
					source: "spectrogram",
					interaction: "click"
				});
				this.player?._state?._blockSeekClicks?.(260);
				this.player?.playBandpassedSegment?.(label.start, label.end, label.freqMin, label.freqMax, { labelId: label.id });
			});
			el.addEventListener("dblclick", (event) => {
				event.preventDefault();
				event.stopPropagation();
				this._suppressClickUntil = performance.now() + 250;
				this._renameSpectrogramLabelPrompt(label.id);
			});
			el.addEventListener("pointerdown", (event) => {
				if (event.button !== 0) return;
				if (this.stampMode) {
					this._stampRefLabelId = label.id;
					event.preventDefault();
					event.stopPropagation();
					return;
				}
				const mode = (event.target?.closest?.(".label-handle"))?.dataset?.mode || "move";
				this._startEditInteraction(label.id, mode, event.clientX, event.clientY, el);
				event.preventDefault();
				event.stopPropagation();
				this.player?._emit?.("labelfocus", {
					id: label.id,
					source: "spectrogram",
					interaction: "click"
				});
			});
			el.addEventListener("pointerenter", (event) => {
				this._lastPointerX = event.clientX;
				this._lastPointerY = event.clientY;
				this.player?._emit?.("labelfocus", {
					id: label.id,
					source: "spectrogram",
					interaction: "hover"
				});
			});
			el.addEventListener("pointerleave", () => {
				if (!this._grabbing && !this._editing) this.player?._emit?.("labelfocus", {
					id: null,
					source: "spectrogram",
					interaction: "hover"
				});
			});
			el.addEventListener("pointermove", (event) => {
				this._lastPointerX = event.clientX;
				this._lastPointerY = event.clientY;
			});
			return el;
		}
		_applyGeometryToElement(el, geometry) {
			el.style.left = `${geometry.left}px`;
			el.style.top = `${geometry.top}px`;
			el.style.width = `${geometry.width}px`;
			el.style.height = `${geometry.height}px`;
		}
		_toGeometry(label, canvasWidth, canvasHeight) {
			const c = this.player?._state?.coords;
			const duration = c?.duration || Math.max(.001, this.player?.duration || this.player?._state?.audioBuffer?.duration || .001);
			const x1 = c ? clamp(c.timeToPixelX(label.start), 0, canvasWidth) : clamp(label.start / duration * canvasWidth, 0, canvasWidth);
			const x2 = c ? clamp(c.timeToPixelX(label.end), 0, canvasWidth) : clamp(label.end / duration * canvasWidth, 0, canvasWidth);
			const yHigh = c ? clamp(c.frequencyToPixelY(label.freqMax), 0, canvasHeight) : 0;
			const yLow = c ? clamp(c.frequencyToPixelY(label.freqMin), 0, canvasHeight) : canvasHeight;
			return {
				left: Math.min(x1, x2),
				top: Math.min(yHigh, yLow),
				width: Math.max(1, Math.abs(x2 - x1)),
				height: Math.max(1, Math.abs(yLow - yHigh))
			};
		}
		_ensureStampGhost() {
			if (this._stampGhostEl || !this.overlay) return;
			this._stampGhostEl = document.createElement("div");
			this._stampGhostEl.className = "spectrogram-label-ghost";
			this.overlay.appendChild(this._stampGhostEl);
		}
		_removeStampGhost() {
			if (this._stampGhostEl?.parentNode) this._stampGhostEl.parentNode.removeChild(this._stampGhostEl);
			this._stampGhostEl = null;
		}
		_updateStampGhost(clientX, clientY) {
			if (!this.stampMode || !this.overlay) {
				this._removeStampGhost();
				return;
			}
			const ref = this._getReferenceLabelForDefaults();
			if (!ref) {
				this._removeStampGhost();
				return;
			}
			this._ensureStampGhost();
			const t = this._clientXToTime(clientX);
			const duration = Math.max(.01, ref.end - ref.start || .01);
			const freq = this._stampAxisLock ? null : this._clientYToFreq(clientY);
			const freqSpan = ref.freqMax - ref.freqMin;
			const freqMin = freq != null ? freq - freqSpan / 2 : ref.freqMin;
			const freqMax = freq != null ? freq + freqSpan / 2 : ref.freqMax;
			const width = parseFloat(this.overlay.style.width) || 1;
			const height = parseFloat(this.overlay.style.height) || 1;
			const ghost = {
				start: t,
				end: t + duration,
				freqMin,
				freqMax,
				label: ref.label
			};
			const geo = this._toGeometry(ghost, width, height);
			if (!this._stampGhostEl) return;
			const el = this._stampGhostEl;
			el.style.left = `${geo.left}px`;
			el.style.top = `${geo.top}px`;
			el.style.width = `${geo.width}px`;
			el.style.height = `${geo.height}px`;
			const colorStyle = getOverlayColorStyle(ref.color);
			if (colorStyle) {
				el.style.setProperty("--ghost-color", colorStyle.edge);
				el.style.setProperty("--ghost-fill", colorStyle.fill);
			}
			el.textContent = ref.label || "Label";
			el.classList.toggle("axis-locked", this._stampAxisLock);
		}
		/** Exit stamp mode and clean up ghost. */
		exitStampMode() {
			this.stampMode = false;
			this._stampAxisLock = false;
			this._stampRefLabelId = null;
			this._removeStampGhost();
			this.player?.root?.classList.remove("stamp-mode-active");
			this.player?._emit?.("stampmodechange", { active: false });
		}
		_bindDrawingInteractions(wrapper) {
			const onPointerDown = (e) => {
				if (this.stampMode) {
					if (e.button === 2) {
						e.preventDefault();
						e.stopPropagation();
						this._suppressContextMenuUntil = performance.now() + 400;
						this.exitStampMode();
						return;
					}
					if (e.button === 0) {
						if (!this.player?._state?.audioBuffer) return;
						const ref = this._getReferenceLabelForDefaults();
						if (!ref) return;
						const t = this._clientXToTime(e.clientX);
						const duration = Math.max(.01, ref.end - ref.start || .01);
						const freq = this._stampAxisLock ? null : this._clientYToFreq(e.clientY);
						const freqSpan = ref.freqMax - ref.freqMin;
						const isXc = ref.origin === "xeno-canto";
						this.add({
							start: t,
							end: t + duration,
							freqMin: freq != null ? freq - freqSpan / 2 : ref.freqMin,
							freqMax: freq != null ? freq + freqSpan / 2 : ref.freqMax,
							label: ref.label,
							color: ref.color,
							scientificName: ref.scientificName,
							commonName: ref.commonName,
							origin: "manual",
							author: isXc ? "" : ref.author,
							tags: isXc ? {} : ref.tags ? { ...ref.tags } : {}
						});
						e.preventDefault();
						e.stopPropagation();
						return;
					}
				}
				if (e.target?.closest?.(".spectrogram-label-region")) return;
				if (!e.shiftKey && !this.drawMode || e.button !== 0) return;
				if (!this.player?._state?.audioBuffer) return;
				const start = this._clientXToTime(e.clientX);
				const freq = this._clientYToFreq(e.clientY);
				this._drawing = {
					startTime: start,
					startFreq: freq,
					endTime: start,
					endFreq: freq
				};
				this._ensureDraft();
				this._updateDraft();
				e.preventDefault();
				e.stopPropagation();
			};
			const onPointerMove = (e) => {
				if (this.stampMode) this._updateStampGhost(e.clientX, e.clientY);
				if (this._editing) {
					this._updateEditInteraction(e.clientX, e.clientY);
					e.preventDefault();
					e.stopPropagation();
					return;
				}
				if (this._drawing) {
					this._drawing.endTime = this._clientXToTime(e.clientX);
					this._drawing.endFreq = this._clientYToFreq(e.clientY);
					this._updateDraft();
					e.preventDefault();
					e.stopPropagation();
				}
			};
			const onPointerUp = (e) => {
				if (this._editing) {
					this._finishEditInteraction();
					e.preventDefault();
					e.stopPropagation();
					return;
				}
				if (this._drawing) {
					const region = this._finalizeDraft();
					this._clearDraft();
					if (region) this._openNewLabelPicker(region);
					e.preventDefault();
					e.stopPropagation();
				}
			};
			const onContextMenu = (e) => {
				if (this.stampMode || this._suppressContextMenuUntil > performance.now()) {
					e.preventDefault();
					e.stopPropagation();
				}
			};
			const onKeyDown = (e) => {
				const tag = e?.target?.tagName?.toLowerCase?.() || "";
				if (tag === "input" || tag === "textarea" || e?.target?.isContentEditable) return;
				if (this.stampMode && e.key === "Escape") {
					e.preventDefault();
					this.exitStampMode();
					return;
				}
				if (this.stampMode) {
					if (e.key === "x" || e.key === "X") {
						e.preventDefault();
						this._stampAxisLock = !this._stampAxisLock;
						if (this._stampGhostEl) this._stampGhostEl.classList.toggle("axis-locked", this._stampAxisLock);
						return;
					}
				}
				if (this._editing && !this._grabbing) {
					if (e.key === "x" || e.key === "X") {
						e.preventDefault();
						this._axisConstraint = this._axisConstraint === "x" ? null : "x";
						return;
					}
					if (e.key === "y" || e.key === "Y") {
						e.preventDefault();
						this._axisConstraint = this._axisConstraint === "y" ? null : "y";
						return;
					}
				}
			};
			wrapper.addEventListener("pointerdown", onPointerDown, true);
			document.addEventListener("pointermove", onPointerMove, true);
			document.addEventListener("pointerup", onPointerUp, true);
			document.addEventListener("pointercancel", onPointerUp, true);
			wrapper.addEventListener("contextmenu", onContextMenu, true);
			document.addEventListener("keydown", onKeyDown, true);
			this._domCleanups.push(() => wrapper.removeEventListener("pointerdown", onPointerDown, true));
			this._domCleanups.push(() => document.removeEventListener("pointermove", onPointerMove, true));
			this._domCleanups.push(() => document.removeEventListener("pointerup", onPointerUp, true));
			this._domCleanups.push(() => document.removeEventListener("pointercancel", onPointerUp, true));
			this._domCleanups.push(() => wrapper.removeEventListener("contextmenu", onContextMenu, true));
			this._domCleanups.push(() => document.removeEventListener("keydown", onKeyDown, true));
		}
		_ensureDraft() {
			if (!this.overlay || this._draftEl) return;
			this._draftEl = document.createElement("div");
			this._draftEl.className = "spectrogram-label-draft";
			this.overlay.appendChild(this._draftEl);
		}
		_updateDraft() {
			if (!this._drawing || !this._draftEl || !this.overlay) return;
			const width = parseFloat(this.overlay.style.width) || 1;
			const height = parseFloat(this.overlay.style.height) || 1;
			const preview = this._normalize({
				start: this._drawing.startTime,
				end: this._drawing.endTime,
				freqMin: Math.min(this._drawing.startFreq, this._drawing.endFreq),
				freqMax: Math.max(this._drawing.startFreq, this._drawing.endFreq),
				label: "New label"
			});
			const g = this._toGeometry(preview, width, height);
			this._draftEl.style.left = `${g.left}px`;
			this._draftEl.style.top = `${g.top}px`;
			this._draftEl.style.width = `${g.width}px`;
			this._draftEl.style.height = `${g.height}px`;
		}
		_finalizeDraft() {
			if (!this._drawing) return null;
			const region = this._normalize({
				start: this._drawing.startTime,
				end: this._drawing.endTime,
				freqMin: Math.min(this._drawing.startFreq, this._drawing.endFreq),
				freqMax: Math.max(this._drawing.startFreq, this._drawing.endFreq),
				label: `Label ${this._counter++}`
			});
			const duration = Math.abs(region.end - region.start);
			const freqSpan = Math.abs(region.freqMax - region.freqMin);
			if (duration < .02 || freqSpan < 20) return null;
			return region;
		}
		_clearDraft() {
			this._drawing = null;
			if (this._draftEl?.parentNode) this._draftEl.parentNode.removeChild(this._draftEl);
			this._draftEl = null;
		}
		_openNewLabelPicker(region) {
			const barSel = this.player?.getSpeciesBarSelection?.();
			if (barSel && barSel.name) {
				region.label = barSel.name;
				region.color = barSel.color || colorForName(barSel.name);
				region.scientificName = barSel.scientificName || "";
				region.tags = {};
				this.add(region);
				return;
			}
			const seen = /* @__PURE__ */ new Set();
			const existingLabels = [];
			for (const l of this.labels) {
				const name = (l.label || "").trim();
				if (!name) continue;
				const key = name.toLowerCase();
				if (seen.has(key)) continue;
				seen.add(key);
				existingLabels.push({
					name,
					color: l.color || "",
					scientificName: l.scientificName || "",
					tags: l.tags || {}
				});
			}
			const ref = this._getReferenceLabelForDefaults();
			const isXcRef = ref?.origin === "xeno-canto";
			const initialColor = ref?.color || _autoAssignColor(this.labels);
			const refName = (ref?.label || "").trim().toLowerCase();
			const initialHex = (getOverlayColorStyle(initialColor)?.hex || "").toLowerCase();
			openLabelNameEditor({
				player: this.player,
				initialValue: ref?.label || "",
				initialColor,
				initialTags: isXcRef ? null : ref?.tags || null,
				existingLabels,
				title: "New Label",
				onSubmit: ({ name, color, scientificName = "", tags = {} }) => {
					const nameChanged = name.trim().toLowerCase() !== refName;
					const colorUntouched = (color || "").toLowerCase() === initialHex;
					region.label = name;
					region.color = nameChanged && colorUntouched ? colorForName(name) : color;
					region.scientificName = String(scientificName || "").trim();
					region.tags = tags;
					this.add(region);
				}
			});
		}
		_startEditInteraction(labelId, mode, clientX, clientY, element) {
			const label = this.labels.find((l) => l.id === labelId);
			if (!label) return;
			this._editing = {
				id: labelId,
				mode,
				startX: clientX,
				startY: clientY,
				startTime: this._clientXToTime(clientX),
				startFreq: this._clientYToFreq(clientY),
				startCanvasY: this._clientYToCanvasY(clientY),
				startLabel: { ...label },
				element,
				pending: mode === "move",
				moved: mode !== "move",
				forceSuppressClick: mode !== "move"
			};
			if (mode !== "move") element.classList.add("editing");
		}
		_updateEditInteraction(clientX, clientY) {
			if (!this._editing) return;
			const editing = this._editing;
			const label = this.labels.find((l) => l.id === editing.id);
			if (!label) return;
			const duration = Math.max(.001, this.player?.duration || this.player?._state?.audioBuffer?.duration || .001);
			const maxFreq = this._getMaxFreq();
			const width = Math.max(1, this.player?._state?.d?.spectrogramCanvas?.width || 1);
			const height = Math.max(1, this.player?._state?.d?.spectrogramCanvas?.height || 1);
			const c = this.player?._state?.coords;
			const dt = this._clientXToTime(clientX) - editing.startTime;
			const deltaCanvasY = this._clientYToCanvasY(clientY) - editing.startCanvasY;
			const src = editing.startLabel;
			const srcMaxPy = c ? c.frequencyToPixelY(src.freqMax) : 0;
			const srcMinPy = c ? c.frequencyToPixelY(src.freqMin) : height;
			/** Shift a frequency edge by deltaCanvasY in pixel space, then convert back to Hz. */
			const shiftedFreq = (origFreq) => {
				if (!c) return origFreq;
				const origPy = c.frequencyToPixelY(origFreq);
				return c.pixelYToFrequency(origPy + deltaCanvasY);
			};
			if (editing.pending) {
				if (Math.abs(clientX - editing.startX) < 4 && Math.abs(clientY - editing.startY) < 4) return;
				editing.pending = false;
				editing.moved = true;
				editing.element?.classList?.add("editing");
			}
			let next = { ...label };
			const ax = this._axisConstraint;
			switch (editing.mode) {
				case "move":
					if (ax !== "y") {
						next.start = src.start + dt;
						next.end = src.end + dt;
					}
					if (ax !== "x") {
						next.freqMin = shiftedFreq(src.freqMin);
						next.freqMax = shiftedFreq(src.freqMax);
					}
					break;
				case "resize-l":
					next.start = src.start + dt;
					break;
				case "resize-r":
					next.end = src.end + dt;
					break;
				case "resize-t":
					next.freqMax = shiftedFreq(src.freqMax);
					break;
				case "resize-b":
					next.freqMin = shiftedFreq(src.freqMin);
					break;
				case "resize-tl":
					next.start = src.start + dt;
					next.freqMax = shiftedFreq(src.freqMax);
					break;
				case "resize-tr":
					next.end = src.end + dt;
					next.freqMax = shiftedFreq(src.freqMax);
					break;
				case "resize-bl":
					next.start = src.start + dt;
					next.freqMin = shiftedFreq(src.freqMin);
					break;
				case "resize-br":
					next.end = src.end + dt;
					next.freqMin = shiftedFreq(src.freqMin);
					break;
				default: break;
			}
			next = this._normalize({
				...src,
				...next,
				id: src.id,
				label: src.label,
				color: src.color
			});
			if (editing.mode === "move") {
				const timeSpan = Math.max(.01, src.end - src.start);
				next.end = next.start + timeSpan;
				const origPixelSpan = Math.abs(srcMinPy - srcMaxPy);
				const newMaxPy = (c ? c.frequencyToPixelY(next.freqMin) : height) - origPixelSpan;
				next.freqMax = c ? c.pixelYToFrequency(Math.max(0, newMaxPy)) : next.freqMax;
				if (next.end > duration) {
					const shift = next.end - duration;
					next.start = Math.max(0, next.start - shift);
					next.end = duration;
				}
				if (next.freqMax > maxFreq) {
					const shift = next.freqMax - maxFreq;
					next.freqMin = Math.max(0, next.freqMin - shift);
					next.freqMax = maxFreq;
				}
			}
			Object.assign(label, next);
			this.player?._state?.updateActiveSegmentFromLabel?.(label);
			this.player?._emit?.("spectrogramlabelpreview", { label: { ...label } });
			if (editing.element) {
				editing.element.dataset.start = String(label.start);
				editing.element.dataset.end = String(label.end);
				editing.element.title = `${label.label || "Label"} ${label.start.toFixed(2)}s–${label.end.toFixed(2)}s / ${Math.round(label.freqMin)}-${Math.round(label.freqMax)} Hz`;
				const geometry = this._toGeometry(label, width, height);
				this._applyGeometryToElement(editing.element, geometry);
				const meta = editing.element.querySelector(".spectrogram-label-meta");
				if (meta) meta.textContent = `${Math.round(label.freqMin)}-${Math.round(label.freqMax)} Hz`;
			}
		}
		_finishEditInteraction() {
			if (!this._editing) return;
			const editing = this._editing;
			const shouldSuppressClick = editing.forceSuppressClick || editing.moved;
			editing.element?.classList?.remove("editing");
			const label = this.labels.find((l) => l.id === editing.id);
			if (label && editing.moved) this.player?._emit?.("spectrogramlabelupdate", { label: { ...label } });
			this._editing = null;
			if (shouldSuppressClick) {
				this._suppressClickUntil = performance.now() + 250;
				this.render();
			}
		}
		/**
		* Blender-style grab: label follows the mouse until click (confirm) or Escape (cancel).
		*/
		startGrab(labelId) {
			const label = this.labels.find((l) => l.id === labelId);
			if (!label || this._grabbing) return;
			const el = this.overlay?.querySelector?.(`.spectrogram-label-region[data-id="${label.id}"]`);
			if (!el) return;
			const snapshot = { ...label };
			el.classList.add("editing");
			const startX = this._lastPointerX ?? 0;
			const startY = this._lastPointerY ?? 0;
			this._editing = {
				id: labelId,
				mode: "move",
				startX,
				startY,
				startTime: this._clientXToTime(startX),
				startFreq: this._clientYToFreq(startY),
				startCanvasY: this._clientYToCanvasY(startY),
				startLabel: snapshot,
				element: el,
				pending: false,
				moved: true,
				forceSuppressClick: true
			};
			this._grabbing = true;
			this._axisConstraint = null;
			const onMove = (e) => {
				this._updateEditInteraction(e.clientX, e.clientY);
			};
			const confirm = (e) => {
				e?.preventDefault?.();
				e?.stopPropagation?.();
				cleanup();
				this._finishEditInteraction();
			};
			const cancel = (e) => {
				e?.preventDefault?.();
				e?.stopPropagation?.();
				cleanup();
				Object.assign(label, snapshot);
				el.classList.remove("editing");
				this._editing = null;
				this._suppressClickUntil = performance.now() + 250;
				this.render();
			};
			const onKey = (e) => {
				if (e.key === "Escape") cancel(e);
				if (e.key === "g") confirm(e);
				if (e.key === "x" || e.key === "X") {
					e.preventDefault();
					this._axisConstraint = this._axisConstraint === "x" ? null : "x";
				}
				if (e.key === "y" || e.key === "Y") {
					e.preventDefault();
					this._axisConstraint = this._axisConstraint === "y" ? null : "y";
				}
			};
			const cleanup = () => {
				this._grabbing = false;
				this._axisConstraint = null;
				document.removeEventListener("pointermove", onMove, true);
				document.removeEventListener("pointerdown", confirm, true);
				document.removeEventListener("keydown", onKey, true);
			};
			document.addEventListener("pointermove", onMove, true);
			document.addEventListener("pointerdown", confirm, true);
			document.addEventListener("keydown", onKey, true);
		}
		_renameSpectrogramLabelPrompt(id) {
			const label = this.labels.find((l) => l.id === id);
			if (!label) return;
			const current = label.label || "Label";
			const el = this.overlay?.querySelector?.(`.spectrogram-label-region[data-id="${label.id}"]`);
			openLabelNameEditor({
				player: this.player,
				anchorEl: el || this.overlay,
				initialValue: current,
				initialColor: label.color,
				initialTags: label.tags || {},
				onSubmit: ({ name, color, scientificName = "", tags = {} }) => {
					const currentHex = getOverlayColorStyle(label.color)?.hex || "";
					const nextSci = String(scientificName || "").trim();
					const prevSci = String(label.scientificName || "").trim();
					if (name === current && color === currentHex && nextSci === prevSci && JSON.stringify(tags) === JSON.stringify(label.tags || {})) return;
					label.label = name;
					label.color = color;
					label.tags = tags;
					if (nextSci) label.scientificName = nextSci;
					const labelKey = name.toLowerCase();
					for (const other of this.labels) if (other.id !== label.id && (other.label || "").toLowerCase() === labelKey) {
						other.color = color;
						this.player?._emit?.("spectrogramlabelupdate", { label: { ...other } });
					}
					this.player?._emit?.("spectrogramlabelupdate", { label: { ...label } });
					this.render();
				},
				onDelete: () => {
					this.remove(id);
					this.player?._emit?.("spectrogramlabelremove", { label: { ...label } });
				}
			});
		}
		_clientXToTime(clientX) {
			return this.player?._state?._clientXToTime?.(clientX, "spectrogram") || 0;
		}
		_clientYToCanvasY(clientY) {
			const state = this.player?._state;
			const c = state?.coords;
			const wrapper = state?.d?.canvasWrapper;
			if (!wrapper || !c) return 0;
			const rect = wrapper.getBoundingClientRect();
			return clamp(clientY - rect.top, 0, rect.height) / Math.max(1, rect.height) * c.canvasHeight;
		}
		_clientYToFreq(clientY) {
			const state = this.player?._state;
			const c = state?.coords;
			const wrapper = state?.d?.canvasWrapper;
			if (!wrapper || !c) return 0;
			const rect = wrapper.getBoundingClientRect();
			const canvasY = clamp(clientY - rect.top, 0, rect.height) / Math.max(1, rect.height) * c.canvasHeight;
			return c.pixelYToFrequency(canvasY);
		}
		_getMaxFreq() {
			const state = this.player?._state;
			const selected = parseFloat(state?.d?.maxFreqSelect?.value || "10000");
			const nyquist = (state?.sampleRateHz || 32e3) / 2;
			return Math.max(1, Math.min(selected, nyquist));
		}
		_normalize(label) {
			const start = Number(label?.start ?? 0);
			const end = Number(label?.end ?? start);
			const freqMin = Number(label?.freqMin ?? 0);
			const freqMax = Number(label?.freqMax ?? freqMin);
			if (![
				start,
				end,
				freqMin,
				freqMax
			].every(Number.isFinite)) throw new Error("SpectrogramLabelLayer: numeric start/end/freqMin/freqMax required");
			const maxFreq = this._getMaxFreq();
			const s = Math.max(0, Math.min(start, end));
			const duration = Math.max(.001, this.player?.duration || this.player?._state?.audioBuffer?.duration || Math.max(start, end, .001));
			const e = Math.min(duration, Math.max(0, Math.max(start, end)));
			const f0 = clamp(Math.min(freqMin, freqMax), 0, maxFreq);
			const f1 = clamp(Math.max(freqMin, freqMax), 0, maxFreq);
			const labelName = label?.label || "";
			const explicitColor = String(label?.color || "").trim();
			return {
				id: label?.id || `slabel_${Math.random().toString(36).slice(2, 10)}`,
				start: s,
				end: Math.max(s + .01, e),
				freqMin: f0,
				freqMax: Math.max(f0 + 1, f1),
				label: labelName,
				color: explicitColor || colorForName(labelName),
				scientificName: String(label?.scientificName || "").trim(),
				commonName: String(label?.commonName || "").trim(),
				origin: String(label?.origin || "").trim(),
				author: String(label?.author || "").trim(),
				tags: label?.tags && typeof label.tags === "object" ? { ...label.tags } : {}
			};
		}
	};
	//#endregion
	//#region src/undoStack.js
	var UndoStack = class {
		/**
		* @param {number} [maxSize=100] - maximum number of undo snapshots
		*/
		constructor(maxSize = 100) {
			/** @type {Array<any>} */
			this._stack = [];
			this._index = -1;
			this._maxSize = maxSize;
		}
		/** Push a new snapshot. Discards any redo history. */
		push(snapshot) {
			this._stack.length = this._index + 1;
			this._stack.push(snapshot);
			if (this._stack.length > this._maxSize) this._stack.splice(0, this._stack.length - this._maxSize);
			this._index = this._stack.length - 1;
		}
		/** Return previous snapshot or null if at beginning. */
		undo() {
			if (this._index <= 0) return null;
			this._index--;
			return this._stack[this._index];
		}
		/** Return next snapshot or null if at end. */
		redo() {
			if (this._index >= this._stack.length - 1) return null;
			this._index++;
			return this._stack[this._index];
		}
		get canUndo() {
			return this._index > 0;
		}
		get canRedo() {
			return this._index < this._stack.length - 1;
		}
		get size() {
			return this._stack.length;
		}
		clear() {
			this._stack.length = 0;
			this._index = -1;
		}
	};
	//#endregion
	//#region src/xcHelpers.js
	function sleep(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	function safeArray(value) {
		return Array.isArray(value) ? value : [];
	}
	function safeString(value) {
		if (value === 0 || value === false) return String(value);
		return value == null ? "" : String(value).trim();
	}
	function safeField(value) {
		return value === 0 || value === false ? value : value != null && value !== "" ? value : "";
	}
	function firstNonEmpty(values) {
		for (const v of values) {
			const s = String(v ?? "").trim();
			if (s) return s;
		}
		return "";
	}
	function toFiniteNumber(value) {
		if (value == null) return NaN;
		const n = Number(String(value).replace(",", ".").trim());
		return Number.isFinite(n) ? n : NaN;
	}
	function parseJsonSafe(text) {
		if (!text) return null;
		try {
			return JSON.parse(text);
		} catch {
			return null;
		}
	}
	function normalizeXcId(raw) {
		const digits = String(raw || "").replace(/\D+/g, "");
		return digits ? String(Number(digits)) : "";
	}
	function resolveFetch(fetchImpl) {
		if (typeof fetchImpl === "function") return fetchImpl;
		if (typeof globalThis.fetch === "function") return globalThis.fetch.bind(globalThis);
		return null;
	}
	//#endregion
	//#region src/xenoCantoApi.js
	var DEFAULT_XC_ENDPOINT = "https://xeno-canto.org/api/3/upload/annotation-set";
	/**
	* @typedef {Object} XenoCantoClientOptions
	* @property {string} [apiKey]
	* @property {string} [endpoint]
	* @property {number} [timeoutMs]
	* @property {number} [retries]
	* @property {number} [retryDelayMs]
	* @property {string} [keyHeaderName]
	* @property {string} [basicAuthCredential]
	* @property {boolean} [sendBasicAuth]
	* @property {typeof fetch} [fetchImpl]
	*/
	/**
	* @typedef {Object} XenoCantoUploadResult
	* @property {boolean} ok
	* @property {number} status
	* @property {string} message
	* @property {string[]} warnings
	* @property {string[]} errors
	* @property {any} response
	* @property {string} rawText
	*/
	/**
	* @typedef {Object} BuildAnnotationSetParams
	* @property {Object} [metadata]
	* @property {Object[]} [annotations]
	* @property {string} [apiVersion]
	*/
	/**
	* @typedef {Object} BuildAnnotationSetResult
	* @property {boolean} ok
	* @property {Object|null} payload
	* @property {string[]} warnings
	* @property {string[]} errors
	*/
	function isRetryableStatus(status) {
		return status === 408 || status === 425 || status === 429 || status >= 500 && status <= 599;
	}
	function encodeBasicAuth(credential) {
		const raw = String(credential || "");
		if (typeof btoa === "function") return btoa(raw);
		throw new Error("No base64 encoder available for Basic auth header.");
	}
	function extractMessage(body, fallback = "") {
		if (!body || typeof body !== "object") return fallback;
		if (typeof body.message === "string" && body.message) return body.message;
		if (typeof body.status === "string" && body.status) return body.status;
		return fallback;
	}
	function collectWarnings(body) {
		return safeArray(body?.warnings).map((v) => safeString(v)).filter(Boolean);
	}
	function collectErrors(body) {
		return safeArray(body?.errors).map((v) => safeString(v)).filter(Boolean);
	}
	function normalizeMetadata(metadata) {
		const m = metadata || {};
		return {
			xcFileNo: safeString(m.xcfileno ?? m["Xeno-canto file no"] ?? m["Xeno-canto file no:"] ?? m["meta-xcfileno"]),
			projectName: safeString(m.project ?? m.Project ?? m["meta-project"] ?? m.project_name),
			annotatorName: safeString(m.annname ?? m["Name of the Annotator"] ?? m["meta-annname"] ?? m.annotator),
			taxonCoverage: safeString(m.taxon_coverage ?? m.taxonCoverage),
			completeness: safeString(m.completeness ?? m.set_completeness),
			setName: safeString(m.setname),
			setCreator: safeString(m.setcreator),
			setLicense: safeString(m.set_license)
		};
	}
	function mapAnnotationRow(row, normalizedMeta) {
		const r = row || {};
		return {
			annotation_source_id: safeField(r.Selection ?? r.selection ?? r["Selection"]),
			sound_file: "",
			xc_nr: safeField(normalizedMeta.xcFileNo),
			annotator: safeField(normalizedMeta.annotatorName),
			annotator_xc_id: "",
			frequency_high: safeField(r.highFreq ?? r.highfreq ?? r["High Freq (Hz)"]),
			frequency_low: safeField(r.lowFreq ?? r.lowfreq ?? r["Low Freq (Hz)"]),
			start_time: (r.beginTime ?? r["Begin Time (s)"]) === 0 ? 0 : safeField(r.beginTime ?? r["Begin Time (s)"]),
			end_time: (r.endTime ?? r["End Time (s)"]) === 0 ? 0 : safeField(r.endTime ?? r["End Time (s)"]),
			scientific_name: safeField(r.scientificName ?? r["Scientific Name"]),
			sound_type: safeField(r.soundType ?? r["Sound type(s)"]),
			date_identified: "",
			sex: safeField(r.sex ?? r["Sex"]),
			life_stage: safeField(r.lifeStage ?? r["Life stage"]),
			animal_seen: "",
			playback_used: "",
			collection_date: "",
			collection_specimen: "",
			temperature: "",
			annotation_remarks: safeField(r.notes ?? r["Notes"]),
			overlap: ""
		};
	}
	var XenoCantoApiError = class extends Error {
		/**
		* @param {string} message
		* @param {Object} [details]
		*/
		constructor(message, details = {}) {
			super(message);
			this.name = "XenoCantoApiError";
			this.status = Number.isFinite(details.status) ? details.status : 0;
			this.retryable = details.retryable === true;
			this.response = details.response ?? null;
			this.rawText = details.rawText ?? "";
			this.warnings = safeArray(details.warnings);
			this.errors = safeArray(details.errors);
			this.cause = details.cause;
		}
	};
	var XenoCantoApiClient = class {
		/**
		* @param {XenoCantoClientOptions} [options]
		*/
		constructor(options = {}) {
			this._apiKey = safeString(options.apiKey);
			this._endpoint = safeString(options.endpoint) || "https://xeno-canto.org/api/3/upload/annotation-set";
			this._timeoutMs = Math.max(1e3, Number(options.timeoutMs) || 2e4);
			this._retries = Math.max(0, Number(options.retries) || 2);
			this._retryDelayMs = Math.max(0, Number(options.retryDelayMs) || 500);
			this._keyHeaderName = safeString(options.keyHeaderName) || "key";
			this._basicAuthCredential = safeString(options.basicAuthCredential) || "xc:xc";
			this._sendBasicAuth = options.sendBasicAuth !== false;
			this._fetch = resolveFetch(options.fetchImpl);
			if (!this._fetch) throw new XenoCantoApiError("No fetch implementation available.");
		}
		get endpoint() {
			return this._endpoint;
		}
		get timeoutMs() {
			return this._timeoutMs;
		}
		get retries() {
			return this._retries;
		}
		/**
		* @param {string} apiKey
		*/
		setApiKey(apiKey) {
			this._apiKey = safeString(apiKey);
		}
		/**
		* @param {string} endpoint
		*/
		setEndpoint(endpoint) {
			this._endpoint = safeString(endpoint) || "https://xeno-canto.org/api/3/upload/annotation-set";
		}
		/**
		* @param {number} timeoutMs
		*/
		setTimeout(timeoutMs) {
			this._timeoutMs = Math.max(1e3, Number(timeoutMs) || this._timeoutMs);
		}
		/**
		* @param {number} retries
		* @param {number} [retryDelayMs]
		*/
		setRetryPolicy(retries, retryDelayMs = this._retryDelayMs) {
			this._retries = Math.max(0, Number(retries) || 0);
			this._retryDelayMs = Math.max(0, Number(retryDelayMs) || 0);
		}
		/**
		* @param {Object} payload
		* @param {{ signal?: AbortSignal }} [options]
		* @returns {Promise<XenoCantoUploadResult>}
		*/
		async uploadAnnotationSet(payload, options = {}) {
			if (!this._apiKey) throw new XenoCantoApiError("Xeno-canto API key is required.");
			if (!payload || typeof payload !== "object") throw new XenoCantoApiError("Annotation set payload must be an object.");
			const body = JSON.stringify(payload);
			const maxAttempts = this._retries + 1;
			let lastError = null;
			for (let attempt = 1; attempt <= maxAttempts; attempt++) try {
				return await this._uploadOnce(body, options.signal);
			} catch (error) {
				lastError = error;
				const isLastAttempt = attempt >= maxAttempts;
				if (!(error instanceof XenoCantoApiError) || !error.retryable || isLastAttempt) throw error;
				await sleep(this._retryDelayMs * Math.pow(2, attempt - 1));
			}
			throw lastError || new XenoCantoApiError("Xeno-canto upload failed.");
		}
		/**
		* @param {Object} payload
		* @param {{ signal?: AbortSignal }} [options]
		*/
		async uploadAnnotationSetSafe(payload, options = {}) {
			try {
				return {
					ok: true,
					result: await this.uploadAnnotationSet(payload, options),
					error: null
				};
			} catch (error) {
				return {
					ok: false,
					result: null,
					error
				};
			}
		}
		async _uploadOnce(body, externalSignal) {
			const controller = new AbortController();
			const timeoutId = setTimeout(() => controller.abort("timeout"), this._timeoutMs);
			const signal = controller.signal;
			const abortExternal = () => controller.abort("aborted");
			if (externalSignal) if (externalSignal.aborted) controller.abort("aborted");
			else externalSignal.addEventListener("abort", abortExternal, { once: true });
			try {
				const headers = {
					"Content-Type": "application/json",
					Accept: "application/json",
					[this._keyHeaderName]: this._apiKey
				};
				if (this._sendBasicAuth) headers.Authorization = `Basic ${encodeBasicAuth(this._basicAuthCredential)}`;
				const response = await this._fetch(this._endpoint, {
					method: "POST",
					headers,
					body,
					signal
				});
				const rawText = await response.text();
				const responseJson = parseJsonSafe(rawText);
				const warnings = collectWarnings(responseJson);
				const errors = collectErrors(responseJson);
				const message = extractMessage(responseJson, response.statusText || "");
				if (!response.ok || errors.length) throw new XenoCantoApiError(message || `Xeno-canto upload failed with status ${response.status}.`, {
					status: response.status,
					retryable: isRetryableStatus(response.status),
					response: responseJson,
					rawText,
					warnings,
					errors: errors.length ? errors : [message || response.statusText || "Upload failed"]
				});
				return {
					ok: true,
					status: response.status,
					message,
					warnings,
					errors: [],
					response: responseJson,
					rawText
				};
			} catch (error) {
				if (error instanceof XenoCantoApiError) throw error;
				throw new XenoCantoApiError(signal.aborted && signal.reason === "timeout" ? "Xeno-canto upload timed out." : "Network error while uploading to Xeno-canto.", {
					status: 0,
					retryable: true,
					errors: [error?.message || String(error)],
					cause: error
				});
			} finally {
				clearTimeout(timeoutId);
				if (externalSignal) externalSignal.removeEventListener("abort", abortExternal);
			}
		}
	};
	/**
	* Build and validate a Xeno-canto annotation-set payload.
	* @param {BuildAnnotationSetParams} params
	* @returns {BuildAnnotationSetResult}
	*/
	function buildXenoCantoAnnotationSet(params = {}) {
		const metadata = params.metadata || {};
		const annotations = safeArray(params.annotations);
		const warnings = [];
		const errors = [];
		const meta = normalizeMetadata(metadata);
		if (!meta.xcFileNo) errors.push("Missing metadata field 'xcfileno' (Xeno-canto file number).");
		if (!annotations.length) errors.push("No annotations provided.");
		if (errors.length) return {
			ok: false,
			payload: null,
			warnings,
			errors
		};
		const mappedAnnotations = annotations.map((row) => mapAnnotationRow(row, meta));
		const missingTimeRows = mappedAnnotations.filter((a) => a.start_time === "" || a.end_time === "");
		if (missingTimeRows.length) warnings.push(`${missingTimeRows.length} annotation(s) have missing start/end times.`);
		return {
			ok: true,
			payload: {
				set_source: "",
				set_uri: "",
				set_name: meta.setName,
				annotation_software_name_and_version: params.apiVersion || "Audio Workbench",
				set_creator: meta.setCreator,
				set_creator_id: "",
				set_owner: "",
				set_license: meta.setLicense,
				project_uri: "",
				project_name: meta.projectName,
				funding: "",
				scope: [{
					taxon_coverage: meta.taxonCoverage,
					completeness: meta.completeness
				}],
				annotations: mappedAnnotations
			},
			warnings,
			errors: []
		};
	}
	//#endregion
	//#region src/xenoCantoRecordingsApi.js
	var DEFAULT_XC_RECORDINGS_ENDPOINT = "https://xeno-canto.org/api/3/recordings";
	function getRecordingScientificName(rec) {
		if (!rec || typeof rec !== "object") return "";
		const sci = firstNonEmpty([
			rec.scientific_name,
			rec.scientificName,
			rec.sci,
			rec.species
		]);
		if (sci) return sci;
		const gen = firstNonEmpty([rec.gen, rec.genus]);
		const sp = firstNonEmpty([rec.sp, rec.species_epithet]);
		return gen && sp ? `${gen} ${sp}` : "";
	}
	async function fetchXenoCantoRecording(xcId, options = {}) {
		const clean = normalizeXcId(xcId);
		if (!clean) throw new Error("Invalid Xeno-canto ID.");
		const fetchFn = resolveFetch(options.fetchImpl);
		if (!fetchFn) throw new Error("No fetch implementation available.");
		const url = `${String(options.endpoint || "https://xeno-canto.org/api/3/recordings").trim()}?query=nr:${clean}`;
		const apiKey = String(options.apiKey || "").trim();
		if (!apiKey) throw new Error("XC API key missing. Open \"XC API\" and paste your key.");
		const res = await fetchFn(`${url}&key=${encodeURIComponent(apiKey)}`);
		if (!res.ok) {
			let msg = "";
			try {
				const body = await res.json();
				msg = firstNonEmpty([body?.message, body?.error]);
			} catch {}
			const status = Number(res.status) || 0;
			if (status === 401 || status === 403) throw new Error(msg || "Invalid or expired API key. Please check your XC API key.");
			throw new Error(msg || `XC API HTTP ${status}`);
		}
		const data = await res.json();
		const recording = (Array.isArray(data?.recordings) ? data.recordings[0] : null) || (Array.isArray(data?.results) ? data.results[0] : null) || (Array.isArray(data) ? data[0] : null) || null;
		if (!recording) throw new Error(`No XC recording found for ${clean}.`);
		return {
			xcId: clean,
			recording,
			raw: data
		};
	}
	function extractXenoCantoRawLabels(recording) {
		if (!recording || typeof recording !== "object") return [];
		const annotationSet = recording["annotation-set"] ?? recording.annotationSet ?? null;
		if (annotationSet && Array.isArray(annotationSet.annotations)) return annotationSet.annotations;
		const candidate = recording.labels ?? recording.label_annotations ?? recording.labelAnnotations ?? recording.annotations ?? recording.annotation ?? recording.sound_labels ?? recording.soundLabels ?? null;
		if (Array.isArray(candidate)) return candidate;
		if (candidate && typeof candidate === "object") {
			if (Array.isArray(candidate.items)) return candidate.items;
			if (Array.isArray(candidate.labels)) return candidate.labels;
			if (Array.isArray(candidate.annotations)) return candidate.annotations;
		}
		return [];
	}
	function mapXenoCantoLabelsToSpectrogram(rawLabels, options = {}) {
		const arr = Array.isArray(rawLabels) ? rawLabels : [];
		const xcId = normalizeXcId(options.xcId || "");
		const scientificName = getRecordingScientificName(options.recording || {});
		const recordingCommonName = firstNonEmpty([
			options?.recording?.en,
			options?.recording?.common_name,
			options?.recording?.commonName
		]);
		const recordist = firstNonEmpty([
			options?.recording?.rec,
			options?.recording?.recorder,
			options?.recording?.recordist
		]);
		const sampleRate = Number(options.sampleRate);
		const nyquist = Math.max(1e3, Math.floor((Number.isFinite(sampleRate) ? sampleRate : DEFAULT_SAMPLE_RATE) / 2));
		const idPrefix = String(options.idPrefix || "xc").trim() || "xc";
		const rec = options.recording || {};
		const recSex = firstNonEmpty([rec.sex, rec.Sex]) || "";
		const recType = firstNonEmpty([
			rec.type,
			rec.sound_type,
			rec.soundType
		]) || "";
		const recStage = firstNonEmpty([
			rec.stage,
			rec.life_stage,
			rec.lifeStage,
			rec.age
		]) || "";
		const recCountry = firstNonEmpty([rec.cnt, rec.country]) || "";
		const recLocality = firstNonEmpty([
			rec.loc,
			rec.locality,
			rec.location
		]) || "";
		const recDate = firstNonEmpty([rec.date, rec.recording_date]) || "";
		const recTime = firstNonEmpty([rec.time, rec.recording_time]) || "";
		const recQuality = firstNonEmpty([rec.q, rec.quality]) || "";
		const recLicense = firstNonEmpty([rec.lic, rec.license]) || "";
		const recMethod = firstNonEmpty([rec.method]) || "";
		const recRemarks = firstNonEmpty([rec.rmk, rec.remarks]) || "";
		const recLat = firstNonEmpty([rec.lat, rec.latitude]) || "";
		const recLng = firstNonEmpty([
			rec.lon,
			rec.lng,
			rec.longitude
		]) || "";
		const recAlt = firstNonEmpty([rec.alt, rec.altitude]) || "";
		const recAnimalSeen = firstNonEmpty([
			rec["animal-seen"],
			rec.animal_seen,
			rec.animalSeen
		]) || "";
		const recPlaybackUsed = firstNonEmpty([
			rec["playback-used"],
			rec.playback_used,
			rec.playbackUsed
		]) || "";
		const recAlso = Array.isArray(rec.also) ? rec.also.filter(Boolean).join(", ") : "";
		const labels = [];
		for (let i = 0; i < arr.length; i += 1) {
			const src = arr[i] || {};
			const start = toFiniteNumber(src.start ?? src.begin ?? src.from ?? src.t0 ?? src.start_time ?? src.startTime);
			const end = toFiniteNumber(src.end ?? src.stop ?? src.to ?? src.t1 ?? src.end_time ?? src.endTime);
			if (!(Number.isFinite(start) && Number.isFinite(end) && end > start)) continue;
			const freqMinRaw = toFiniteNumber(src.freq_min ?? src.low_freq ?? src.f_low ?? src.min_freq ?? src.frequency_low);
			const freqMaxRaw = toFiniteNumber(src.freq_max ?? src.high_freq ?? src.f_high ?? src.max_freq ?? src.frequency_high);
			const freqMin = Number.isFinite(freqMinRaw) ? Math.max(0, freqMinRaw) : 0;
			const freqMax = Number.isFinite(freqMaxRaw) ? Math.min(nyquist, freqMaxRaw) : nyquist;
			if (!(freqMax > freqMin)) continue;
			const label = firstNonEmpty([
				src.sound_type,
				src.soundType,
				recordingCommonName,
				src.scientific_name,
				src.scientificName,
				src.label,
				src.name,
				src.value,
				src.type,
				src.event,
				src.comment,
				src.description,
				"XC label"
			]);
			const annotationId = firstNonEmpty([
				src.annotation_xc_id,
				src.id,
				i + 1
			]);
			const tags = {};
			const sex = firstNonEmpty([
				src.sex,
				src.Sex,
				recSex
			]);
			const soundType = firstNonEmpty([
				src.sound_type,
				src.soundType,
				src.type,
				recType
			]);
			const lifeStage = firstNonEmpty([
				src.stage,
				src.life_stage,
				src.lifeStage,
				src.age,
				recStage
			]);
			if (sex) tags.sex = sex;
			if (soundType) tags.soundType = soundType;
			if (lifeStage) tags.lifeStage = lifeStage;
			const annSciName = firstNonEmpty([src.scientific_name, src.scientificName]) || "";
			const annotator = firstNonEmpty([src.annotator, src.annotator_name]) || "";
			const animalSeen = firstNonEmpty([
				src.animal_seen,
				src.animalSeen,
				recAnimalSeen
			]) || "";
			const playbackUsed = firstNonEmpty([
				src.playback_used,
				src.playbackUsed,
				recPlaybackUsed
			]) || "";
			const remarks = firstNonEmpty([
				src.annotation_remarks,
				src.remarks,
				src.notes
			]) || "";
			if (annotator) tags.annotator = annotator;
			if (animalSeen) tags.animalSeen = animalSeen;
			if (playbackUsed) tags.playbackUsed = playbackUsed;
			if (remarks) tags.remarks = remarks;
			const setMeta = src.original_set_metadata || {};
			const setLicense = firstNonEmpty([setMeta.set_license, setMeta.license]) || "";
			const setName = firstNonEmpty([setMeta.set_name, setMeta.name]) || "";
			const setCreator = firstNonEmpty([setMeta.set_creator, setMeta.creator]) || "";
			if (setLicense) tags.setLicense = setLicense;
			if (setName) tags.setName = setName;
			if (setCreator) tags.setCreator = setCreator;
			labels.push({
				id: `${idPrefix}${xcId}_lbl_${annotationId}`,
				start,
				end,
				freqMin,
				freqMax,
				label,
				scientificName: annSciName || scientificName,
				commonName: recordingCommonName,
				origin: "xeno-canto",
				author: annotator || recordist || "",
				tags
			});
		}
		const recordingMeta = {};
		if (recCountry) recordingMeta.country = recCountry;
		if (recLocality) recordingMeta.locality = recLocality;
		if (recDate) recordingMeta.date = recDate;
		if (recTime) recordingMeta.time = recTime;
		if (recQuality) recordingMeta.quality = recQuality;
		if (recLicense) recordingMeta.license = recLicense;
		if (recMethod) recordingMeta.method = recMethod;
		if (recRemarks) recordingMeta.remarks = recRemarks;
		if (recLat) recordingMeta.lat = recLat;
		if (recLng) recordingMeta.lng = recLng;
		if (recAlt) recordingMeta.alt = recAlt;
		if (recAnimalSeen) recordingMeta.animalSeen = recAnimalSeen;
		if (recPlaybackUsed) recordingMeta.playbackUsed = recPlaybackUsed;
		if (recAlso) recordingMeta.backgroundSpecies = recAlso;
		if (recordist) recordingMeta.recordist = recordist;
		return {
			labels,
			recordingMeta
		};
	}
	async function importXenoCantoSpectrogramLabels(xcId, options = {}) {
		const { recording, xcId: clean } = await fetchXenoCantoRecording(xcId, options);
		const rawLabels = extractXenoCantoRawLabels(recording);
		const { labels, recordingMeta } = mapXenoCantoLabelsToSpectrogram(rawLabels, {
			xcId: clean,
			recording,
			sampleRate: options.sampleRate,
			idPrefix: options.idPrefix
		});
		return {
			xcId: clean,
			recording,
			rawLabels,
			labels,
			recordingMeta
		};
	}
	//#endregion
	//#region src/taxonomyResolver.js
	function normalizeScientificName(raw) {
		const s = String(raw || "").trim().toLowerCase().replace(/[()]/g, " ").replace(/[^a-z\s-]/g, " ").replace(/\s+/g, " ").trim();
		if (!s) return "";
		const parts = s.split(" ");
		return parts.length >= 2 ? `${parts[0]} ${parts[1]}` : parts[0];
	}
	function getGenusAndEpithet(raw) {
		const n = normalizeScientificName(raw);
		if (!n) return {
			genus: "",
			epithet: ""
		};
		const parts = n.split(" ");
		return {
			genus: parts[0] || "",
			epithet: parts[1] || ""
		};
	}
	function levenshtein(a, b) {
		const s = String(a || "");
		const t = String(b || "");
		if (s === t) return 0;
		if (!s) return t.length;
		if (!t) return s.length;
		const m = s.length;
		const n = t.length;
		const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
		for (let i = 0; i <= m; i += 1) dp[i][0] = i;
		for (let j = 0; j <= n; j += 1) dp[0][j] = j;
		for (let i = 1; i <= m; i += 1) for (let j = 1; j <= n; j += 1) {
			const cost = s[i - 1] === t[j - 1] ? 0 : 1;
			dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
		}
		return dp[m][n];
	}
	var TaxonomyResolver = class {
		constructor() {
			this._data = null;
			this._byScientific = /* @__PURE__ */ new Map();
			this._byScientificNorm = /* @__PURE__ */ new Map();
			this._byGenus = /* @__PURE__ */ new Map();
			this._cache = /* @__PURE__ */ new Map();
		}
		get data() {
			return this._data;
		}
		get languages() {
			return this._data?.languages ?? [];
		}
		get speciesCount() {
			return this._data?.speciesCount ?? 0;
		}
		get modelVersion() {
			return this._data?.modelVersion ?? "";
		}
		get records() {
			return this._data?.records ?? [];
		}
		load(data) {
			if (!data || !Array.isArray(data.records) || !Array.isArray(data.languages)) throw new Error("Invalid taxonomy format.");
			this._data = data;
			this._byScientific = new Map(data.records.map((r) => [r.s, r]));
			this._byScientificNorm = /* @__PURE__ */ new Map();
			this._byGenus = /* @__PURE__ */ new Map();
			this._cache = /* @__PURE__ */ new Map();
			for (const rec of data.records) {
				const norm = normalizeScientificName(rec?.s || "");
				if (norm && !this._byScientificNorm.has(norm)) this._byScientificNorm.set(norm, rec);
				const { genus } = getGenusAndEpithet(rec?.s || "");
				if (!genus) continue;
				if (!this._byGenus.has(genus)) this._byGenus.set(genus, []);
				this._byGenus.get(genus).push(rec);
			}
		}
		clear() {
			this._data = null;
			this._byScientific = /* @__PURE__ */ new Map();
			this._byScientificNorm = /* @__PURE__ */ new Map();
			this._byGenus = /* @__PURE__ */ new Map();
			this._cache = /* @__PURE__ */ new Map();
		}
		resolveCommonName(record, lang) {
			if (!record || !record.n) return "";
			return record.n[lang] || record.n.en_uk || Object.values(record.n)[0] || "";
		}
		resolve(scientificName) {
			const raw = String(scientificName || "").trim();
			if (!raw) return null;
			if (this._cache.has(raw)) return this._cache.get(raw);
			let rec = this._byScientific.get(raw) || null;
			if (!rec) {
				const norm = normalizeScientificName(raw);
				if (norm) rec = this._byScientificNorm.get(norm) || null;
			}
			if (!rec) {
				const { genus, epithet } = getGenusAndEpithet(raw);
				const genusCandidates = this._byGenus.get(genus) || [];
				if (epithet && genusCandidates.length) {
					let best = null;
					let bestDist = Number.POSITIVE_INFINITY;
					for (const c of genusCandidates) {
						const { epithet: candidateEpithet } = getGenusAndEpithet(c?.s || "");
						if (!candidateEpithet) continue;
						const d = levenshtein(epithet, candidateEpithet);
						if (d < bestDist) {
							bestDist = d;
							best = c;
						}
					}
					const threshold = Math.max(1, Math.floor(epithet.length * .34));
					if (best && bestDist <= threshold) rec = best;
				}
			}
			this._cache.set(raw, rec || null);
			return rec || null;
		}
	};
	//#endregion
	//#region \0@oxc-project+runtime@0.124.0/helpers/checkPrivateRedeclaration.js
	function _checkPrivateRedeclaration(e, t) {
		if (t.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object");
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.124.0/helpers/classPrivateMethodInitSpec.js
	function _classPrivateMethodInitSpec(e, a) {
		_checkPrivateRedeclaration(e, a), a.add(e);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.124.0/helpers/classPrivateFieldInitSpec.js
	function _classPrivateFieldInitSpec(e, t, a) {
		_checkPrivateRedeclaration(e, t), t.set(e, a);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.124.0/helpers/assertClassBrand.js
	function _assertClassBrand(e, t, n) {
		if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
		throw new TypeError("Private element is not present on this object");
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.124.0/helpers/classPrivateFieldGet2.js
	function _classPrivateFieldGet2(s, a) {
		return s.get(_assertClassBrand(s, a));
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.124.0/helpers/classPrivateFieldSet2.js
	function _classPrivateFieldSet2(s, a, r) {
		return s.set(_assertClassBrand(s, a), r), r;
	}
	//#endregion
	//#region src/birdnetInference.js
	/**
	* BirdNET browser inference via TensorFlow.js Web Worker.
	*
	* - TF.js is loaded from CDN at runtime (not bundled).
	* - The BirdNET model (TF.js Layers format) is fetched from a user-supplied URL
	*   or from the bundled model shipped with the GitHub Pages demo.
	* - Audio is resampled to 48 kHz and split into 3-second chunks for prediction.
	*/
	var TFJS_CDN = "https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4";
	var TARGET_SR = 48e3;
	var CHUNK_SECONDS = 3;
	var CHUNK_SAMPLES = TARGET_SR * CHUNK_SECONDS;
	/**
	* Default model URL pointing to the bundled BirdNET v2.4 TF.js model
	* on the GitHub Pages demo site.  npm users can use this as a convenient
	* fallback or host the model themselves.
	*/
	var BIRDNET_MODEL_URL = "https://limitlessgreen.github.io/Audio-Workbench/models/birdnet-v2.4/";
	var WORKER_SOURCE = `
importScripts('${TFJS_CDN}');

/* ── MelSpecLayerSimple — custom Keras layer expected by BirdNET v2.4 ── */
class MelSpecLayerSimple extends tf.layers.Layer {
  constructor(config) {
    super(config);
    this.sampleRate  = config.sampleRate;
    this.specShape   = config.specShape;
    this.frameStep   = config.frameStep;
    this.frameLength = config.frameLength;
    this.fmin        = config.fmin;
    this.fmax        = config.fmax;
    this.melFilterbank = tf.tensor2d(config.melFilterbank);
  }

  build(inputShape) {
    this.magScale = this.addWeight(
      'magnitude_scaling', [], 'float32',
      tf.initializers.constant({ value: 1.23 })
    );
    super.build(inputShape);
  }

  computeOutputShape(inputShape) {
    return [inputShape[0], this.specShape[0], this.specShape[1], 1];
  }

  call(inputs) {
    return tf.tidy(() => {
      let input = inputs[0];
      if (input.shape.length === 1) input = input.expandDims(0);
      return tf.stack(tf.split(input, input.shape[0]).map(t => {
        let spec = t.squeeze();
        spec = tf.sub(spec, tf.min(spec, -1, true));
        spec = tf.div(spec, tf.max(spec, -1, true).add(1e-6));
        spec = tf.sub(spec, 0.5);
        spec = tf.mul(spec, 2.0);
        spec = tf.signal.stft(
          spec, this.frameLength, this.frameStep,
          this.frameLength, tf.signal.hannWindow
        );
        spec = tf.cast(spec, 'float32');
        spec = tf.matMul(spec, this.melFilterbank);
        spec = spec.pow(2.0);
        spec = spec.pow(
          tf.div(1.0, tf.add(1.0, tf.exp(this.magScale.read())))
        );
        spec = tf.reverse(spec, -1);
        spec = tf.transpose(spec);
        spec = spec.expandDims(-1);
        return spec;
      }));
    });
  }

  static get className() { return 'MelSpecLayerSimple'; }
}
tf.serialization.registerClass(MelSpecLayerSimple);

/* ── Worker message handler ── */
let model  = null;
let labels = [];

self.onmessage = async (e) => {
  var type = e.data.type;
  var id   = e.data.id;

  if (type === 'load') {
    try {
      await tf.setBackend('webgl');
      self.postMessage({ id: id, type: 'progress', message: 'Loading model\\u2026', percent: 10 });

      var base = e.data.modelUrl;
      if (!base.endsWith('/')) base += '/';

      model = await tf.loadLayersModel(base + 'model.json');

      self.postMessage({ id: id, type: 'progress', message: 'Warming up\\u2026', percent: 50 });
      model.predict(tf.zeros([1, ${CHUNK_SAMPLES}])).dispose();

      self.postMessage({ id: id, type: 'progress', message: 'Loading labels\\u2026', percent: 80 });
      var raw = await fetch(base + 'labels.json').then(function (r) { return r.json(); });
      labels = raw.map(function (l) {
        var s = String(l);
        var idx = s.indexOf('_');
        return idx >= 0
          ? { scientific: s.slice(0, idx), common: s.slice(idx + 1) }
          : { scientific: s, common: '' };
      });

      self.postMessage({ id: id, type: 'loaded', labelCount: labels.length });
    } catch (err) {
      self.postMessage({ id: id, type: 'error', message: String(err && err.message || err) });
    }
  }

  if (type === 'predict') {
    try {
      var pcm  = tf.tensor(e.data.samples, [1, ${CHUNK_SAMPLES}]);
      var res  = model.predict(pcm);
      var probs = await res.data();
      pcm.dispose();
      res.dispose();

      var predictions = [];
      for (var i = 0; i < probs.length; i++) {
        if (probs[i] > 0.01 && i < labels.length) {
          predictions.push({
            scientific: labels[i].scientific,
            common:     labels[i].common,
            confidence: probs[i],
          });
        }
      }
      self.postMessage({ id: id, type: 'predictions', predictions: predictions });
    } catch (err) {
      self.postMessage({ id: id, type: 'error', message: String(err && err.message || err) });
    }
  }
};
`;
	async function resampleTo48k(channelData, sourceSampleRate) {
		if (sourceSampleRate === TARGET_SR) return channelData;
		const duration = channelData.length / sourceSampleRate;
		const targetLength = Math.ceil(duration * TARGET_SR);
		const offCtx = new OfflineAudioContext(1, targetLength, TARGET_SR);
		const buf = offCtx.createBuffer(1, channelData.length, sourceSampleRate);
		buf.getChannelData(0).set(channelData);
		const src = offCtx.createBufferSource();
		src.buffer = buf;
		src.connect(offCtx.destination);
		src.start();
		return (await offCtx.startRendering()).getChannelData(0);
	}
	var _worker = /* @__PURE__ */ new WeakMap();
	var _pending = /* @__PURE__ */ new WeakMap();
	var _nextId = /* @__PURE__ */ new WeakMap();
	var _loaded = /* @__PURE__ */ new WeakMap();
	var _onLoadProgress = /* @__PURE__ */ new WeakMap();
	var _BirdNETInference_brand = /* @__PURE__ */ new WeakSet();
	var BirdNETInference = class {
		constructor() {
			_classPrivateMethodInitSpec(this, _BirdNETInference_brand);
			_classPrivateFieldInitSpec(this, _worker, null);
			_classPrivateFieldInitSpec(this, _pending, /* @__PURE__ */ new Map());
			_classPrivateFieldInitSpec(this, _nextId, 0);
			_classPrivateFieldInitSpec(this, _loaded, false);
			_classPrivateFieldInitSpec(this, _onLoadProgress, null);
		}
		/** Whether the model has been loaded successfully. */
		get loaded() {
			return _classPrivateFieldGet2(_loaded, this);
		}
		/**
		* Load the BirdNET model into a Web Worker.
		*
		* @param {object}   opts
		* @param {string}   opts.modelUrl    Base URL of the TF.js model directory
		*                                    (must contain model.json + shards + labels.json).
		* @param {function} [opts.onProgress] Called with (message, percent) during loading.
		* @returns {Promise<{ labelCount: number }>}
		*/
		async load({ modelUrl, onProgress }) {
			if (!modelUrl) throw new Error("modelUrl is required");
			const absoluteModelUrl = new URL(modelUrl, globalThis.location?.href).href;
			this.dispose();
			const blob = new Blob([WORKER_SOURCE], { type: "text/javascript" });
			const blobUrl = URL.createObjectURL(blob);
			_classPrivateFieldSet2(_worker, this, new Worker(blobUrl));
			URL.revokeObjectURL(blobUrl);
			_classPrivateFieldSet2(_onLoadProgress, this, onProgress || null);
			_classPrivateFieldGet2(_worker, this).onmessage = (e) => {
				const { id, type } = e.data;
				if (type === "progress") {
					if (_classPrivateFieldGet2(_onLoadProgress, this)) _classPrivateFieldGet2(_onLoadProgress, this).call(this, e.data.message, e.data.percent);
					return;
				}
				const resolve = _classPrivateFieldGet2(_pending, this).get(id);
				if (resolve) {
					_classPrivateFieldGet2(_pending, this).delete(id);
					resolve(e.data);
				}
			};
			const result = await _assertClassBrand(_BirdNETInference_brand, this, _send).call(this, "load", { modelUrl: absoluteModelUrl });
			_classPrivateFieldSet2(_onLoadProgress, this, null);
			if (result.type === "error") throw new Error(result.message);
			_classPrivateFieldSet2(_loaded, this, true);
			return { labelCount: result.labelCount };
		}
		/**
		* Run BirdNET inference on the given mono PCM audio.
		*
		* @param {Float32Array} channelData   Mono PCM samples.
		* @param {object}       [opts]
		* @param {number}       [opts.sampleRate]     Source sample rate in Hz.
		* @param {number}       [opts.overlap]        Overlap between chunks in seconds (0–2.5).
		* @param {number}       [opts.minConfidence]  Minimum confidence to keep a detection.
		* @param {function}     [opts.onProgress]     Called with a number 0–100 representing %.
		* @returns {Promise<Array<{ start: number, end: number, scientific: string, common: string, confidence: number }>>}
		*/
		async analyze(channelData, opts = {}) {
			const { overlap = 0, minConfidence = .25, onProgress } = opts;
			const sampleRate = opts.sampleRate || TARGET_SR;
			if (!_classPrivateFieldGet2(_loaded, this)) throw new Error("Model not loaded — call load() first.");
			const pcm = await resampleTo48k(channelData, sampleRate);
			const step = CHUNK_SAMPLES - Math.round(overlap * TARGET_SR);
			const totalChunks = Math.max(1, Math.ceil((pcm.length - CHUNK_SAMPLES) / step) + 1);
			const detections = [];
			for (let i = 0; i < totalChunks; i++) {
				const offset = i * step;
				let chunk;
				if (offset + CHUNK_SAMPLES <= pcm.length) chunk = pcm.slice(offset, offset + CHUNK_SAMPLES);
				else {
					chunk = new Float32Array(CHUNK_SAMPLES);
					chunk.set(pcm.subarray(offset));
				}
				if (onProgress) onProgress(Math.round(i / totalChunks * 100));
				const result = await _assertClassBrand(_BirdNETInference_brand, this, _send).call(this, "predict", { samples: chunk }, [chunk.buffer]);
				if (result.type === "error") throw new Error(result.message);
				const startSec = offset / TARGET_SR;
				const endSec = startSec + CHUNK_SECONDS;
				for (const pred of result.predictions) if (pred.confidence >= minConfidence) detections.push({
					start: startSec,
					end: Math.min(endSec, pcm.length / TARGET_SR),
					scientific: pred.scientific,
					common: pred.common,
					confidence: pred.confidence
				});
			}
			if (onProgress) onProgress(100);
			return detections;
		}
		/** Terminate the worker and release resources. */
		dispose() {
			if (_classPrivateFieldGet2(_worker, this)) {
				_classPrivateFieldGet2(_worker, this).terminate();
				_classPrivateFieldSet2(_worker, this, null);
			}
			_classPrivateFieldGet2(_pending, this).clear();
			_classPrivateFieldSet2(_loaded, this, false);
			_classPrivateFieldSet2(_onLoadProgress, this, null);
		}
	};
	function _send(type, data = {}, transferables = []) {
		return new Promise((resolve) => {
			var _this$nextId, _this$nextId2;
			const id = (_classPrivateFieldSet2(_nextId, this, (_this$nextId = _classPrivateFieldGet2(_nextId, this), _this$nextId2 = _this$nextId++, _this$nextId)), _this$nextId2);
			_classPrivateFieldGet2(_pending, this).set(id, resolve);
			if (_classPrivateFieldGet2(_worker, this)) _classPrivateFieldGet2(_worker, this).postMessage({
				type,
				id,
				...data
			}, transferables);
		});
	}
	//#endregion
	//#region src/BirdNETPlayer.js
	var WAVESURFER_CDN = "https://unpkg.com/wavesurfer.js@7/dist/wavesurfer.esm.js";
	var DEFAULT_LABEL_TAXONOMY = [
		{
			name: "Bird Call",
			color: "#0ea5e9",
			shortcut: "1"
		},
		{
			name: "Song",
			color: "#22c55e",
			shortcut: "2"
		},
		{
			name: "Chirp",
			color: "#f59e0b",
			shortcut: "3"
		},
		{
			name: "Noise",
			color: "#ef4444",
			shortcut: "4"
		}
	];
	var BirdNETPlayer = class {
		/**
		* @param {HTMLElement} container - the DOM element to mount the player into
		* @param {Object}      [options]
		* @param {Object}      [options.WaveSurfer]     - pre-loaded WaveSurfer constructor
		* @param {boolean}     [options.showFileOpen]    - show Open button (default: true)
		* @param {boolean}     [options.showTransport]   - show transport controls (default: true)
		* @param {boolean}     [options.showTime]        - show time display (default: true)
		* @param {boolean}     [options.showVolume]      - show volume controls (default: true)
		* @param {boolean}     [options.showViewToggles] - show Follow/Loop/Fit/Reset (default: true)
		* @param {boolean}     [options.showZoom]        - show zoom slider (default: true)
		* @param {boolean}     [options.showFFTControls] - show FFT/Freq/Color selects (default: true)
		* @param {boolean}     [options.showDisplayGain] - show Floor/Ceil sliders (default: true)
		* @param {boolean}     [options.showStatusbar]   - show bottom status bar (default: true)
		* @param {boolean}     [options.showOverview]    - show overview navigator (default: true)
		* @param {'both'|'waveform'|'spectrogram'} [options.viewMode] - visible analysis view(s) (default: both)
		* @param {'default'|'hero'} [options.transportStyle] - transport button style (default: default)
		* @param {boolean}     [options.transportOverlay] - centered play overlay without toolbar height (default: false)
		* @param {boolean}     [options.showWaveformTimeline] - show bottom waveform timeline (default: true)
		* @param {'auto'|'on'|'off'} [options.compactToolbar] - responsive toolbar compaction mode (default: auto)
		* @param {number}      [options.followGuardLeftRatio] - left follow guard ratio (default: 0.35)
		* @param {number}      [options.followGuardRightRatio] - right follow guard ratio (default: 0.65)
		* @param {number}      [options.followTargetRatio] - target ratio for viewport centering (default: 0.5)
		* @param {number}      [options.followCatchupDurationMs] - follow catchup tween duration (default: 240)
		* @param {number}      [options.followCatchupSeekDurationMs] - slower follow tween after manual seek (default: 360)
		* @param {number}      [options.smoothLerp] - smooth mode lerp factor (default: 0.18)
		* @param {number}      [options.smoothSeekLerp] - smooth mode lerp after manual seek (default: 0.08)
		* @param {number}      [options.smoothMinStepRatio] - smooth min step ratio (default: 0.03)
		* @param {number}      [options.smoothSeekMinStepRatio] - smooth min step ratio after seek (default: 0.008)
		* @param {number}      [options.smoothSeekFocusMs] - slow-follow window after manual seek (default: 1400)
		* @param {Array<{name: string, color?: string, shortcut?: string}>} [options.labelTaxonomy] - label taxonomy
		*/
		constructor(container, options = {}) {
			if (!container) throw new Error("BirdNETPlayer: container element required");
			this.container = container;
			this.options = options;
			/** @type {PlayerState | null} */
			this._state = null;
			this._events = new EventTarget();
			this.annotations = new AnnotationLayer();
			this.spectrogramLabels = new SpectrogramLabelLayer();
			this._linkedLabels = /* @__PURE__ */ new Map();
			this._isSyncingLabels = false;
			this._undoStack = new UndoStack(100);
			this._isRestoring = false;
			this._labelLibrary = /* @__PURE__ */ new Map();
			this._labelSuggestionProvider = null;
			this._labelEditorSuggestionMode = "merge";
			this._labelTaxonomy = this._normalizeTaxonomy(options.labelTaxonomy || DEFAULT_LABEL_TAXONOMY);
			this._activeLabelId = null;
			this._globalKeyHandler = null;
			/** @type {Array<{ name: string, scientificName?: string }>} */
			this._backgroundSpecies = [];
			/** @type {{ name: string, color: string, scientificName: string } | null} */
			this._speciesBarSelection = null;
			this.on = (event, callback, options) => {
				this._events.addEventListener(event, callback, options);
				return () => this.off(event, callback, options);
			};
			this.off = (event, callback, options) => {
				this._events.removeEventListener(event, callback, options);
			};
			this.ready = this._init();
		}
		async _init() {
			this.container.innerHTML = createPlayerHTML(this.options);
			this.root = this.container.querySelector(".daw-shell");
			const WaveSurfer = this.options.WaveSurfer || window.WaveSurfer || (await import(
				/* @vite-ignore */
				WAVESURFER_CDN
)).default;
			this._state = new PlayerState(this.root, WaveSurfer, (event, detail) => this._emit(event, detail), this.options);
			this.annotations.attach(this);
			this.spectrogramLabels.attach(this);
			this._bindLinkedLabelSync();
			this._bindGlobalHotkeys();
			this._injectAnnotationToolbar();
			this.on("stampmodechange", (e) => {
				const on = e?.detail?.active ?? false;
				if (this._stampBtn) this._stampBtn.classList.toggle("active", on);
				this.root?.classList.toggle("stamp-mode-active", on);
				if (!on) this.spectrogramLabels._stampAxisLock = false;
			});
			this._emit("ready", { phase: "init" });
			return this;
		}
		_emit(event, detail = {}) {
			this._events.dispatchEvent(new CustomEvent(event, { detail }));
		}
		/** Load audio from a URL (http, blob:, data: URLs all supported) */
		async loadUrl(url) {
			await this.ready;
			return this._state?.loadUrl(url);
		}
		/** Load audio from a File object (e.g. from an <input type="file">) */
		async loadFile(file) {
			await this.ready;
			return this._state?._handleFileSelect({ target: { files: [file] } });
		}
		/** Current playback time in seconds */
		get currentTime() {
			return this._state?._getCurrentTime() || 0;
		}
		/** Duration of loaded audio in seconds */
		get duration() {
			return this._state?.audioBuffer?.duration || 0;
		}
		play() {
			this._state?.wavesurfer?.play();
		}
		pause() {
			this._state?.wavesurfer?.pause();
		}
		stop() {
			this._state?._stopPlayback();
		}
		togglePlayPause() {
			this._state?._togglePlayPause();
		}
		playSegment(startSec, endSec, options) {
			this._state?.playSegment(startSec, endSec, options);
		}
		playBandpassedSegment(startSec, endSec, freqMinHz, freqMaxHz, options) {
			this._state?.playBandpassedSegment(startSec, endSec, freqMinHz, freqMaxHz, options);
		}
		addAnnotation(annotation) {
			const id = annotation?.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
			const existing = this._linkedLabels.get(id);
			const merged = this._normalizeLinkedLabel({
				...existing,
				...annotation,
				id,
				label: annotation?.label ?? annotation?.species ?? existing?.label ?? "Label"
			});
			this._linkedLabels.set(id, merged);
			this._syncLinkedLabelsToLayers();
			return id;
		}
		setAnnotations(annotations) {
			const next = /* @__PURE__ */ new Map();
			for (const ann of annotations || []) {
				const id = ann?.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
				const existing = this._linkedLabels.get(id);
				next.set(id, this._normalizeLinkedLabel({
					...existing,
					...ann,
					id,
					label: ann?.label ?? ann?.species ?? existing?.label ?? "Label"
				}));
			}
			this._linkedLabels = next;
			this._syncLinkedLabelsToLayers();
		}
		clearAnnotations() {
			this._linkedLabels.clear();
			this._syncLinkedLabelsToLayers();
		}
		exportAnnotationsRaven() {
			return this.annotations.exportRavenFormat(this._toAnnotationList());
		}
		addSpectrogramLabel(label) {
			const id = label?.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
			const existing = this._linkedLabels.get(id);
			const merged = this._normalizeLinkedLabel({
				...existing,
				...label,
				id,
				species: label?.species ?? label?.label ?? existing?.species ?? "",
				label: label?.label ?? existing?.label ?? label?.species ?? "Label"
			});
			this._linkedLabels.set(id, merged);
			this._syncLinkedLabelsToLayers();
			return id;
		}
		setSpectrogramLabels(labels) {
			const next = /* @__PURE__ */ new Map();
			for (const lbl of labels || []) {
				const id = lbl?.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
				const existing = this._linkedLabels.get(id);
				next.set(id, this._normalizeLinkedLabel({
					...existing,
					...lbl,
					id,
					species: lbl?.species ?? lbl?.label ?? existing?.species ?? "",
					label: lbl?.label ?? existing?.label ?? lbl?.species ?? "Label"
				}));
			}
			this._linkedLabels = next;
			this._syncLinkedLabelsToLayers();
		}
		clearSpectrogramLabels() {
			this._linkedLabels.clear();
			this._backgroundSpecies = [];
			this.setSpeciesBar("");
			this._syncLinkedLabelsToLayers();
		}
		renameLabel(id, name) {
			const key = String(id || "").trim();
			const value = String(name || "").trim();
			if (!key || !value) return false;
			const current = this._linkedLabels.get(key);
			if (!current) return false;
			this._linkedLabels.set(key, this._normalizeLinkedLabel({
				...current,
				id: key,
				label: value,
				species: value
			}));
			this._syncLinkedLabelsToLayers();
			return true;
		}
		getLabelSuggestions(prefix = "", limit = 10) {
			const q = String(prefix || "").trim().toLowerCase();
			return Array.from(this._labelLibrary.entries()).filter(([name]) => !q || name.toLowerCase().includes(q)).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, Math.max(1, limit)).map(([name]) => name);
		}
		setLabelSuggestionProvider(provider = null) {
			this._labelSuggestionProvider = typeof provider === "function" ? provider : null;
		}
		setLabelEditorSuggestionMode(mode = "merge") {
			this._labelEditorSuggestionMode = String(mode || "").trim().toLowerCase() === "custom-only" ? "custom-only" : "merge";
		}
		getLabelEditorSuggestionMode() {
			return this._labelEditorSuggestionMode || "merge";
		}
		getLabelEditorSuggestions(query = "", limit = 12) {
			if (!this._labelSuggestionProvider) return [];
			try {
				const out = this._labelSuggestionProvider(String(query || ""), Math.max(1, Number(limit) || 12));
				if (!Array.isArray(out)) return [];
				return out.map((item) => {
					if (typeof item === "string") {
						const name = item.trim();
						return name ? { name } : null;
					}
					const name = String(item?.name || "").trim();
					if (!name) return null;
					const color = String(item?.color || "").trim();
					const scientificName = String(item?.scientificName || "").trim();
					const detail = String(item?.detail || "").trim();
					return {
						name,
						color: color || "",
						scientificName: scientificName || "",
						detail: detail || ""
					};
				}).filter(Boolean);
			} catch {
				return [];
			}
		}
		getLabelTaxonomy() {
			return this._labelTaxonomy.map((item) => ({ ...item }));
		}
		setLabelTaxonomy(taxonomy = []) {
			this._labelTaxonomy = this._normalizeTaxonomy(taxonomy);
			this._syncLinkedLabelsToLayers();
		}
		/**
		* Override or extend the tag presets shown in the label editor dialog.
		* Each entry: { key, label, options: string[] }
		* @param {Array<{ key: string, label?: string, options: string[] }>} presets
		*/
		setTagPresets(presets) {
			this._tagPresets = (presets || []).map((p) => ({
				key: String(p.key || ""),
				label: String(p.label || p.key || ""),
				options: Array.isArray(p.options) ? p.options.map(String) : []
			})).filter((p) => p.key);
		}
		getTagPresets() {
			return this._tagPresets ? this._tagPresets.map((p) => ({
				...p,
				options: p.options.slice()
			})) : null;
		}
		applyTaxonomyToLabel(id, shortcutOrIndex) {
			const key = String(id || "").trim();
			const current = this._linkedLabels.get(key);
			if (!current) return false;
			const index = typeof shortcutOrIndex === "number" ? shortcutOrIndex : this._labelTaxonomy.findIndex((t) => t.shortcut === String(shortcutOrIndex));
			if (index < 0 || index >= this._labelTaxonomy.length) return false;
			const tax = this._labelTaxonomy[index];
			const next = this._normalizeLinkedLabel({
				...current,
				id: key,
				label: tax.name,
				species: tax.name,
				color: tax.color || current.color
			});
			this._linkedLabels.set(key, next);
			this._activeLabelId = key;
			this._syncLinkedLabelsToLayers();
			this._emit("labeltaxonomyapply", {
				id: key,
				taxonomy: { ...tax }
			});
			return true;
		}
		/**
		* Inject a pre-computed spectrogram as raw data (Float32Array or base64-encoded).
		* The player applies its own colorization pipeline (contrast, color map).
		*
		* @param {Float32Array|ArrayBuffer|string} data - spectrogram values.
		*   If string, decoded as base64 → Float32 (little-endian).
		* @param {number} nFrames - number of time frames
		* @param {number} nMels   - number of frequency bins
		* @param {Object} [options]
		* @param {string} [options.mode='mel'] - 'mel'|'linear' (affects freq axis labels)
		* @param {number} [options.sampleRate]   - sample rate for freq labels (default: from audio)
		*/
		async setSpectrogramData(data, nFrames, nMels, options = {}) {
			await this.ready;
			return this._state?._setExternalSpectrogram(data, nFrames, nMels, options);
		}
		/**
		* Inject a pre-rendered spectrogram image (bypasses all DSP + colorization).
		*
		* @param {string|HTMLImageElement|HTMLCanvasElement} image - base64 data-URL,
		*   regular URL, or an already-loaded Image/Canvas element.
		* @param {Object} [options]
		* @param {number}   [options.sampleRate]  - sample rate for frequency axis labels
		* @param {number[]} [options.freqRange]   - [fMin, fMax] in Hz the image covers
		* @param {string}   [options.freqScale]   - frequency axis mapping: 'linear' | 'mel' | 'log'
		*/
		async setSpectrogramImage(image, options = {}) {
			await this.ready;
			return this._state?._setExternalSpectrogramImage(image, options);
		}
		/**
		* Clear any externally-injected spectrogram and re-enable auto-compute.
		*/
		async clearExternalSpectrogram() {
			await this.ready;
			if (!this._state) return;
			this._state._externalSpectrogram = false;
			this._state._externalImageConfig = null;
			this._state._setDspControlsEnabled(true);
			if (this._state.audioBuffer) this._state._generateSpectrogram();
		}
		setPlaybackViewportConfig(config = {}) {
			return this._state?.updatePlaybackViewportConfig?.(config) || null;
		}
		getPlaybackViewportConfig() {
			return this._state?.getPlaybackViewportConfig?.() || null;
		}
		/** Notify the player that its container was resized externally. */
		resize() {
			const s = this._state;
			if (!s) return;
			s._queueCompactToolbarLayoutRefresh?.();
			if (!s.audioBuffer) return;
			s._drawMainWaveform();
			s._drawOverviewWaveform();
			s._syncOverviewWindowToViewport();
			if (s.spectrogramData && s.spectrogramFrames > 0) s._drawSpectrogram();
			s._emit("viewresize", {
				waveformHeight: s.waveformDisplayHeight,
				spectrogramHeight: s.spectrogramDisplayHeight
			});
		}
		/** Tear down the player and free resources */
		destroy() {
			if (this._globalKeyHandler) {
				document.removeEventListener("keydown", this._globalKeyHandler, true);
				this._globalKeyHandler = null;
			}
			this.annotations.detach();
			this.spectrogramLabels.detach();
			this._state?.dispose();
			this._state = null;
			this.container.innerHTML = "";
		}
		_bindLinkedLabelSync() {
			this.on("labelfocus", (e) => {
				this._activeLabelId = String(e?.detail?.id || "").trim() || null;
			});
			this.on("annotationpreview", (e) => this._previewFromAnnotationEvent(e.detail.annotation));
			this.on("spectrogramlabelpreview", (e) => this._previewFromSpectrogramEvent(e.detail.label));
			this.on("annotationcreate", (e) => this._upsertFromAnnotationEvent(e.detail.annotation));
			this.on("annotationupdate", (e) => this._upsertFromAnnotationEvent(e.detail.annotation));
			this.on("spectrogramlabelcreate", (e) => this._upsertFromSpectrogramEvent(e.detail.label));
			this.on("spectrogramlabelupdate", (e) => this._upsertFromSpectrogramEvent(e.detail.label));
			this.on("spectrogramlabelremove", (e) => this._removeFromLinkedLabels(e.detail.label));
			this.on("annotationremove", (e) => this._removeFromLinkedLabels(e.detail.annotation));
		}
		_bindGlobalHotkeys() {
			this._globalKeyHandler = (event) => {
				const tag = event?.target?.tagName?.toLowerCase?.() || "";
				if (tag === "input" || tag === "textarea" || event?.target?.isContentEditable) return;
				const key = String(event.key || "");
				const ctrl = event.ctrlKey || event.metaKey;
				if (ctrl && key === "c" && this._activeLabelId) {
					event.preventDefault();
					this.spectrogramLabels?.copyLabel(this._activeLabelId);
					return;
				}
				if (ctrl && key === "z") {
					event.preventDefault();
					this.undo();
					return;
				}
				if (ctrl && (key === "y" || key === "Z" && event.shiftKey)) {
					event.preventDefault();
					this.redo();
					return;
				}
				if (ctrl && key === "v") {
					event.preventDefault();
					const pasted = this.spectrogramLabels?.pasteLabel();
					if (pasted) this._emit?.("spectrogramlabelcreate", { label: { ...pasted } });
					return;
				}
				if (ctrl && key === "d") {
					event.preventDefault();
					if (this.spectrogramLabels?.stampMode) this.spectrogramLabels.exitStampMode();
					else {
						if (this.spectrogramLabels) {
							this.spectrogramLabels.stampMode = true;
							if (this._activeLabelId) this.spectrogramLabels._stampRefLabelId = this._activeLabelId;
							this.spectrogramLabels.drawMode = false;
							this.root?.classList.remove("draw-mode-active");
							if (this._drawBtn) this._drawBtn.classList.remove("active");
						}
						this.root?.classList.add("stamp-mode-active");
						if (this._stampBtn) this._stampBtn.classList.add("active");
					}
					return;
				}
				if (!this._activeLabelId) return;
				const inAxisMode = this.spectrogramLabels?.stampMode || this.spectrogramLabels?._grabbing || this.spectrogramLabels?._editing;
				if (key === "Delete" || key === "Backspace" || key === "x" && !inAxisMode) {
					event.preventDefault();
					const id = this._activeLabelId;
					const sLabel = this.spectrogramLabels?.labels?.find((l) => l.id === id);
					if (sLabel) {
						this.spectrogramLabels.remove(id);
						this._emit?.("spectrogramlabelremove", { label: { ...sLabel } });
					} else {
						const ann = this.annotations?.annotations?.find((a) => a.id === id);
						if (ann) {
							this.annotations.remove(id);
							this._emit?.("annotationremove", { annotation: { ...ann } });
						}
					}
					this._activeLabelId = null;
					return;
				}
				if (key === "g") {
					event.preventDefault();
					if (this.spectrogramLabels?.labels?.find((l) => l.id === this._activeLabelId)) this.spectrogramLabels.startGrab(this._activeLabelId);
					else this.annotations?.startGrab(this._activeLabelId);
					return;
				}
				if (!/^[1-9]$/.test(key)) return;
				const idx = Number(key) - 1;
				if (idx >= this._labelTaxonomy.length) return;
				event.preventDefault();
				this.applyTaxonomyToLabel(this._activeLabelId, idx);
			};
			document.addEventListener("keydown", this._globalKeyHandler, true);
		}
		_injectAnnotationToolbar() {
			const secondary = this.root?.querySelector("[data-aw=\"toolbarSecondary\"]");
			if (!secondary) return;
			const sep = document.createElement("div");
			sep.className = "toolbar-sep";
			secondary.appendChild(sep);
			const drawBtn = document.createElement("button");
			drawBtn.className = "toolbar-btn toggle-btn active";
			drawBtn.title = "Draw label (Shift+Drag)";
			drawBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.375 2.625a1 1 0 013 3l-9.013 9.014a2 2 0 01-.853.505l-2.873.84a.5.5 0 01-.62-.62l.84-2.873a2 2 0 01.506-.852z"/></svg> Draw`;
			this._drawBtn = drawBtn;
			this.root?.classList.add("draw-mode-active");
			drawBtn.addEventListener("click", () => {
				const on = !this.spectrogramLabels.drawMode;
				this.spectrogramLabels.drawMode = on;
				if (on && this.spectrogramLabels) this.spectrogramLabels.exitStampMode();
				drawBtn.classList.toggle("active", on);
				this.root?.classList.toggle("draw-mode-active", on);
			});
			secondary.appendChild(drawBtn);
			const stampBtn = document.createElement("button");
			stampBtn.className = "toolbar-btn toggle-btn";
			stampBtn.title = "Stamp mode (Ctrl+D)";
			stampBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="13" width="8" height="8" rx="1"/></svg> Stamp`;
			this._stampBtn = stampBtn;
			stampBtn.addEventListener("click", () => {
				if (this.spectrogramLabels.stampMode) this.spectrogramLabels.exitStampMode();
				else {
					this.spectrogramLabels.stampMode = true;
					if (this._activeLabelId) this.spectrogramLabels._stampRefLabelId = this._activeLabelId;
					this.spectrogramLabels.drawMode = false;
					if (this._drawBtn) this._drawBtn.classList.remove("active");
					this.root?.classList.remove("draw-mode-active");
					stampBtn.classList.add("active");
					this.root?.classList.add("stamp-mode-active");
				}
			});
			secondary.appendChild(stampBtn);
		}
		/** Public getter for current species bar selection. */
		getSpeciesBarSelection() {
			return this._speciesBarSelection ? { ...this._speciesBarSelection } : null;
		}
		/**
		* Programmatically set the species search bar (e.g. after loading XC recording).
		* @param {string} name
		* @param {{ color?: string, scientificName?: string }} [opts]
		*/
		setSpeciesBar(name, opts = {}) {
			const trimmed = (name || "").trim();
			this._speciesBarSelection = trimmed ? {
				name: trimmed,
				color: opts.color || colorForName(trimmed),
				scientificName: opts.scientificName || ""
			} : null;
			this._emit("speciesbarchange", { selection: this._speciesBarSelection ? { ...this._speciesBarSelection } : null });
		}
		/**
		* Set background species (XC "also" field) to appear in search suggestions.
		* @param {Array<string | { name: string, scientificName?: string }>} species
		*/
		setBackgroundSpecies(species) {
			this._backgroundSpecies = (species || []).map((s) => typeof s === "string" ? { name: s } : {
				name: s.name || "",
				scientificName: s.scientificName || ""
			}).filter((s) => s.name);
		}
		_previewFromAnnotationEvent(annotation) {
			if (this._isSyncingLabels || !annotation) return;
			const id = annotation.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
			const existing = this._linkedLabels.get(id);
			const next = this._normalizeLinkedLabel({
				...existing,
				...annotation,
				id,
				label: annotation?.species ?? existing?.label ?? "Label"
			});
			this._linkedLabels.set(id, next);
			this._state?.updateActiveSegmentFromLabel?.(next);
			this.spectrogramLabels.setLiveLinkedId(id);
			this.spectrogramLabels.set(this._toSpectrogramLabelList());
		}
		_previewFromSpectrogramEvent(label) {
			if (this._isSyncingLabels || !label) return;
			const id = label.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
			const existing = this._linkedLabels.get(id);
			const nextName = String(label?.label || label?.species || existing?.label || existing?.species || "Label").trim();
			const next = this._normalizeLinkedLabel({
				...existing,
				...label,
				id,
				species: nextName,
				label: nextName
			});
			this._linkedLabels.set(id, next);
			this._state?.updateActiveSegmentFromLabel?.(next);
			this.annotations.setLiveLinkedId(id);
			this.annotations.set(this._toAnnotationList());
		}
		_upsertFromAnnotationEvent(annotation) {
			if (this._isSyncingLabels || !annotation) return;
			const id = annotation.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
			const existing = this._linkedLabels.get(id);
			const next = this._normalizeLinkedLabel({
				...existing,
				...annotation,
				id,
				label: annotation?.species ?? existing?.label ?? "Label"
			});
			this._linkedLabels.set(id, next);
			this._state?.updateActiveSegmentFromLabel?.(next);
			this.annotations.setLiveLinkedId(null);
			this.spectrogramLabels.setLiveLinkedId(null);
			this._syncLinkedLabelsToLayers();
		}
		_removeFromLinkedLabels(label) {
			if (this._isSyncingLabels || !label?.id) return;
			this._linkedLabels.delete(label.id);
			this.annotations.setLiveLinkedId(null);
			this.spectrogramLabels.setLiveLinkedId(null);
			this._syncLinkedLabelsToLayers();
		}
		_upsertFromSpectrogramEvent(label) {
			if (this._isSyncingLabels || !label) return;
			const id = label.id || `lbl_${Math.random().toString(36).slice(2, 10)}`;
			const existing = this._linkedLabels.get(id);
			const nextName = String(label?.label || label?.species || existing?.label || existing?.species || "Label").trim();
			const next = this._normalizeLinkedLabel({
				...existing,
				...label,
				id,
				species: nextName,
				label: nextName
			});
			this._linkedLabels.set(id, next);
			this._state?.updateActiveSegmentFromLabel?.(next);
			this.annotations.setLiveLinkedId(null);
			this.spectrogramLabels.setLiveLinkedId(null);
			this._syncLinkedLabelsToLayers();
		}
		_syncLinkedLabelsToLayers() {
			if (!this._isRestoring) this._undoStack.push(this._snapshotLabels());
			this._isSyncingLabels = true;
			try {
				this.annotations.set(this._toAnnotationList());
				this.spectrogramLabels.set(this._toSpectrogramLabelList());
				this._rebuildLabelLibrary();
				this._renderOverviewLabelTracks();
			} finally {
				this._isSyncingLabels = false;
			}
			this._emit("labelsync", {});
		}
		/** Create a deep snapshot of the current _linkedLabels for undo. */
		_snapshotLabels() {
			return Array.from(this._linkedLabels.values()).map((l) => ({
				...l,
				tags: { ...l.tags }
			}));
		}
		/** Restore a snapshot from the undo stack. */
		_restoreSnapshot(snapshot) {
			if (!snapshot) return;
			this._isRestoring = true;
			this._linkedLabels.clear();
			for (const label of snapshot) this._linkedLabels.set(label.id, {
				...label,
				tags: { ...label.tags }
			});
			this._syncLinkedLabelsToLayers();
			this._isRestoring = false;
			this._emit?.("undochange", {
				canUndo: this._undoStack.canUndo,
				canRedo: this._undoStack.canRedo
			});
		}
		/** Undo the last label mutation. */
		undo() {
			const snapshot = this._undoStack.undo();
			if (snapshot) this._restoreSnapshot(snapshot);
			return !!snapshot;
		}
		/** Redo the last undone label mutation. */
		redo() {
			const snapshot = this._undoStack.redo();
			if (snapshot) this._restoreSnapshot(snapshot);
			return !!snapshot;
		}
		_rebuildLabelLibrary() {
			const next = /* @__PURE__ */ new Map();
			for (const item of this._linkedLabels.values()) {
				const label = String(item?.label || item?.species || "").trim();
				if (!label) continue;
				next.set(label, (next.get(label) || 0) + 1);
			}
			this._labelLibrary = next;
		}
		/**
		* Render one row per origin group below the overview bar,
		* each showing colored segments where labels from that origin occur.
		*/
		/**
		* Render one row per unique label name below the overview bar,
		* grouped under compact origin headers (manual, BirdNET, xeno-canto).
		*/
		_renderOverviewLabelTracks() {
			const container = this._state?.d?.overviewLabelTracks;
			if (!container) return;
			const duration = this._state?.audioBuffer?.duration || 0;
			const prevRowCount = container.childElementCount;
			if (duration <= 0) {
				container.innerHTML = "";
				this._afterOverviewRowChange(prevRowCount, 0);
				return;
			}
			/** @type {Map<string, Map<string, {color: string, segments: {id: string, start: number, end: number}[]}>>} */
			const originGroups = /* @__PURE__ */ new Map();
			for (const item of this._linkedLabels.values()) {
				const origin = String(item?.origin || "manual").trim() || "manual";
				const name = String(item?.label || item?.species || "").trim();
				if (!name) continue;
				if (!originGroups.has(origin)) originGroups.set(origin, /* @__PURE__ */ new Map());
				const nameMap = originGroups.get(origin);
				if (!nameMap.has(name)) nameMap.set(name, {
					color: item.color || "",
					segments: []
				});
				const g = nameMap.get(name);
				if (!g.color && item.color) g.color = item.color;
				g.segments.push({
					id: item.id || "",
					start: item.start,
					end: item.end
				});
			}
			if (originGroups.size === 0) {
				container.innerHTML = "";
				this._afterOverviewRowChange(prevRowCount, 0);
				return;
			}
			const ORDER = {
				manual: 0,
				BirdNET: 1,
				"xeno-canto": 2
			};
			const sortedOrigins = [...originGroups.entries()].sort((a, b) => (ORDER[a[0]] ?? 99) - (ORDER[b[0]] ?? 99) || a[0].localeCompare(b[0]));
			container.innerHTML = "";
			for (const [origin, nameMap] of sortedOrigins) {
				const header = document.createElement("div");
				header.className = "overview-label-group-header";
				header.textContent = origin;
				container.appendChild(header);
				const sortedNames = [...nameMap.entries()].sort((a, b) => a[0].localeCompare(b[0]));
				for (const [name, { color, segments }] of sortedNames) {
					const row = document.createElement("div");
					row.className = "overview-label-row";
					row.title = name;
					if (color) {
						const rgb = this._parseLabelColorRgb(color);
						if (rgb) row.style.setProperty("--label-tint", `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.35)`);
					}
					const nameEl = document.createElement("span");
					nameEl.className = "overview-label-row-name";
					nameEl.textContent = name;
					row.appendChild(nameEl);
					const track = document.createElement("div");
					track.className = "overview-label-row-track";
					for (const seg of segments) {
						const s = document.createElement("span");
						s.className = "overview-label-segment";
						s.dataset.start = String(seg.start);
						s.dataset.end = String(seg.end);
						s.dataset.id = seg.id || "";
						const leftPct = seg.start / duration * 100;
						const widthPct = (seg.end - seg.start) / duration * 100;
						s.style.left = `${leftPct}%`;
						s.style.width = `${Math.max(.3, widthPct)}%`;
						s.addEventListener("pointerenter", () => {
							if (seg.id) this._activeLabelId = seg.id;
							this._emit?.("labelfocus", {
								id: seg.id || null,
								source: "overview",
								interaction: "hover"
							});
						});
						s.addEventListener("pointerleave", () => {
							this._emit?.("labelfocus", {
								id: null,
								source: "overview",
								interaction: "hover"
							});
						});
						s.addEventListener("click", (e) => {
							e.stopPropagation();
							const midTime = (seg.start + seg.end) / 2;
							this._state?._seekToTime(midTime, true);
							this._emit?.("labelfocus", {
								id: seg.id || null,
								source: "overview",
								interaction: "click"
							});
						});
						track.appendChild(s);
					}
					row.appendChild(track);
					container.appendChild(row);
				}
			}
			this._afterOverviewRowChange(prevRowCount, container.childElementCount);
		}
		/**
		* When the overview label track row count changes, the spectrogram container
		* shrinks/grows (flexbox). Schedule a resize-aware redraw so canvas, coords,
		* AND label overlay layers all stay in sync.
		*/
		_afterOverviewRowChange(prevCount, nextCount) {
			if (prevCount !== nextCount) this._state?._queueResizeRedraw({ redrawSpectrogram: true });
		}
		/** @param {string} color @returns {{r:number,g:number,b:number}|null} */
		_parseLabelColorRgb(color) {
			if (!color) return null;
			const s = String(color).trim();
			const hexMatch = s.match(/^#?([0-9a-f]{3,6})$/i);
			if (hexMatch) {
				let h = hexMatch[1];
				if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
				return {
					r: parseInt(h.slice(0, 2), 16),
					g: parseInt(h.slice(2, 4), 16),
					b: parseInt(h.slice(4, 6), 16)
				};
			}
			const rgbMatch = s.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
			if (rgbMatch) return {
				r: +rgbMatch[1],
				g: +rgbMatch[2],
				b: +rgbMatch[3]
			};
			return null;
		}
		_normalizeTaxonomy(taxonomy) {
			const used = /* @__PURE__ */ new Set();
			const list = [];
			for (const item of taxonomy || []) {
				const name = String(item?.name || "").trim();
				if (!name) continue;
				const shortcut = String(item?.shortcut || "").trim();
				const normalizedShortcut = /^[1-9]$/.test(shortcut) && !used.has(shortcut) ? shortcut : "";
				if (normalizedShortcut) used.add(normalizedShortcut);
				list.push({
					name,
					color: item?.color ? String(item.color) : "",
					shortcut: normalizedShortcut
				});
				if (list.length >= 9) break;
			}
			return list;
		}
		_toAnnotationList() {
			return Array.from(this._linkedLabels.values()).map((l) => ({
				id: l.id,
				start: l.start,
				end: l.end,
				species: l.species || l.label || "",
				confidence: l.confidence,
				color: l.color,
				scientificName: l.scientificName || "",
				commonName: l.commonName || "",
				origin: l.origin || "",
				author: l.author || "",
				tags: l.tags || {}
			}));
		}
		_toSpectrogramLabelList() {
			return Array.from(this._linkedLabels.values()).map((l) => ({
				id: l.id,
				start: l.start,
				end: l.end,
				freqMin: l.freqMin,
				freqMax: l.freqMax,
				label: l.label || l.species || "",
				color: l.color,
				scientificName: l.scientificName || "",
				commonName: l.commonName || "",
				origin: l.origin || "",
				author: l.author || "",
				tags: l.tags || {}
			}));
		}
		_normalizeLinkedLabel(label) {
			const duration = Math.max(.001, this.duration || this._state?.audioBuffer?.duration || .001);
			const nyquist = (this._state?.sampleRateHz || 32e3) / 2;
			const selected = parseFloat(this._state?.d?.maxFreqSelect?.value || `${nyquist}`);
			const maxFreq = Math.max(1, Math.min(selected, nyquist));
			const start = Math.max(0, Math.min(Number(label?.start ?? 0), duration));
			const end = Math.max(start + .01, Math.min(duration, Number(label?.end ?? start + .01)));
			const freqMinRaw = Number(label?.freqMin ?? 0);
			const freqMaxRaw = Number(label?.freqMax ?? maxFreq);
			const freqMin = Math.max(0, Math.min(freqMinRaw, maxFreq));
			const freqMax = Math.max(freqMin + 1, Math.min(maxFreq, freqMaxRaw));
			const labelName = String(label?.label || label?.species || "").trim();
			const tax = labelName ? this._labelTaxonomy.find((t) => t.name.toLowerCase() === labelName.toLowerCase()) : null;
			const explicitColor = String(label?.color || "").trim();
			return {
				id: label?.id || `lbl_${Math.random().toString(36).slice(2, 10)}`,
				start,
				end,
				freqMin,
				freqMax,
				species: label?.species || "",
				label: label?.label || label?.species || "",
				confidence: label?.confidence,
				color: explicitColor || tax?.color || colorForName(labelName),
				scientificName: label?.scientificName || "",
				commonName: label?.commonName || "",
				origin: label?.origin || "",
				author: label?.author || "",
				tags: label?.tags && typeof label.tags === "object" ? { ...label.tags } : {}
			};
		}
	};
	//#endregion
	exports.BIRDNET_MODEL_URL = BIRDNET_MODEL_URL;
	exports.BirdNETInference = BirdNETInference;
	exports.BirdNETPlayer = BirdNETPlayer;
	exports.DEFAULT_OPTIONS = DEFAULT_OPTIONS;
	exports.DEFAULT_XC_ENDPOINT = DEFAULT_XC_ENDPOINT;
	exports.DEFAULT_XC_RECORDINGS_ENDPOINT = DEFAULT_XC_RECORDINGS_ENDPOINT;
	exports.TaxonomyResolver = TaxonomyResolver;
	exports.XenoCantoApiClient = XenoCantoApiClient;
	exports.XenoCantoApiError = XenoCantoApiError;
	exports.buildXenoCantoAnnotationSet = buildXenoCantoAnnotationSet;
	exports.extractXenoCantoRawLabels = extractXenoCantoRawLabels;
	exports.fetchXenoCantoRecording = fetchXenoCantoRecording;
	exports.getRecordingScientificName = getRecordingScientificName;
	exports.importXenoCantoSpectrogramLabels = importXenoCantoSpectrogramLabels;
	exports.mapXenoCantoLabelsToSpectrogram = mapXenoCantoLabelsToSpectrogram;
	exports.normalizeXcId = normalizeXcId;
	return exports;
})({});

//# sourceMappingURL=birdnet-player.iife.js.map