# Rewindex

![python](https://img.shields.io/badge/python-3.10%2B-blue)
![license](https://img.shields.io/badge/license-proprietary-red)

**Rewindex — Auto-snapshot tool for AI agents**

Reduce the risk of AI breaking your code. Records what your AI changed before you realize something broke. Audit and recover from your AI chat or the built-in dashboard. Free, runs locally.

- **Versioning**: snap, rewind, and track every change your AI makes
- **Change visibility**: view diffs, session logs, and full file history
- **Changelog**: flag milestones and export as CHANGELOG.md

Works with any AI agent via MCP. Works with Git. Rewind the code that you didn't commit.

**[rewindex.org](https://rewindex.org)** | [GitHub](https://github.com/crsxmd/rewindex)

---

## How it works

1. **Every save is recorded**

   Every time you or your AI saves a file, Rewindex captures a snapshot automatically.

2. **Sessions group your work**

   When your AI finishes a task, all the changes are grouped into one session. Easy to find, easy to rewind.

3. **AI notes it automatically**

   When your AI finishes working, it writes a note on the session. No manual logging needed.

4. **Rewind without guessing**

   When something breaks, the full log is right there. Your AI knows exactly where to go back to.

### Try it! Then ask your AI if it likes it.

---

## Getting Started

See [GitHub](https://github.com/crsxmd/rewindex) for install instructions, setup guide, and documentation.

---

## Pricing

Free forever. No account required.

Want to upgrade? Check [rewindex.org](https://rewindex.org)

---

## License

Proprietary. See [LICENSE](https://github.com/crsxmd/rewindex/blob/main/LICENSE) for details.
