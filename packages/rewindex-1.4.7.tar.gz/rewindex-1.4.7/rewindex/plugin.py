# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""Plugin loader — discovers platform and hooks plugins via entry points.

Usage in core:
    from rewindex.plugin import get_platform, fire

    platform = get_platform()               # singleton DefaultPlatform or injected plugin
    fire("on_snap", session_id=..., ...)    # broadcast to all hooks plugins
"""

from __future__ import annotations

import logging
from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rewindex.platform import PlatformInterface
    from rewindex.hooks import HooksInterface

logger = logging.getLogger("rewindex.plugin")


@lru_cache(maxsize=1)
def get_platform() -> "PlatformInterface":
    """Return the active platform implementation based on OS."""
    import platform as _sys_platform
    if _sys_platform.system() == "Windows":
        from rewindex.platform import WindowsPlatform
        return WindowsPlatform()
    from rewindex.platform import DefaultPlatform
    return DefaultPlatform()


@lru_cache(maxsize=1)
def _get_hooks() -> "list[HooksInterface]":
    """Return all registered hooks plugins."""
    hooks: list[HooksInterface] = []
    try:
        from importlib.metadata import entry_points
        for ep in entry_points(group="rewindex.hooks"):
            try:
                hooks.append(ep.load()())
                logger.debug("Hooks plugin loaded: %s", ep.name)
            except Exception as exc:
                logger.debug("Hooks plugin %s failed to load: %s", ep.name, exc)
    except Exception as exc:
        logger.debug("Hooks discovery failed: %s", exc)
    return hooks


def fire(event: str, **kwargs: object) -> None:
    """Broadcast an event to all registered hooks plugins. Never raises."""
    for hook in _get_hooks():
        try:
            getattr(hook, event)(**kwargs)
        except Exception as exc:
            logger.debug("Hook %s.%s raised: %s", type(hook).__name__, event, exc)
