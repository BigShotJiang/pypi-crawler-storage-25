# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""Platform abstraction layer.

Core defines PlatformInterface with implementations for Linux/macOS and Windows.
The correct platform is selected automatically based on the OS.
"""

from __future__ import annotations

import os
import platform as _sys_platform
import signal
import subprocess
from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class PlatformInterface(Protocol):
    def start_daemon(self, cmd: list[str], log_path: Path) -> int: ...
    def stop_daemon(self, pid: int) -> None: ...
    def is_running(self, pid: int) -> bool: ...
    def install_autostart(self, cmd: str) -> None: ...
    def uninstall_autostart(self) -> None: ...


class DefaultPlatform:
    """Linux / macOS implementation — wraps existing autostart modules."""

    def start_daemon(self, cmd: list[str], log_path: Path) -> int:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        return proc.pid

    def stop_daemon(self, pid: int) -> None:
        os.kill(pid, signal.SIGTERM)

    def is_running(self, pid: int) -> bool:
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False

    def install_autostart(self, cmd: str) -> None:
        if _sys_platform.system() == "Darwin":
            from rewindex.autostart.macos import install
        else:
            from rewindex.autostart.linux import install
        install()

    def uninstall_autostart(self) -> None:
        if _sys_platform.system() == "Darwin":
            from rewindex.autostart.macos import uninstall
        else:
            from rewindex.autostart.linux import uninstall
        uninstall()


class WindowsPlatform:
    """Windows implementation using native process and task APIs."""

    def start_daemon(self, cmd: list[str], log_path: Path) -> int:
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        log_file = open(log_path, "a", encoding="utf-8")
        proc = subprocess.Popen(
            cmd,
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            stdout=log_file,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            close_fds=True,
        )
        return proc.pid

    def stop_daemon(self, pid: int) -> None:
        subprocess.run(
            ["taskkill", "/F", "/PID", str(pid)],
            check=True,
            capture_output=True,
        )

    def is_running(self, pid: int) -> bool:
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
            capture_output=True,
            text=True,
        )
        return str(pid) in result.stdout

    def install_autostart(self, cmd: str) -> None:
        subprocess.run([
            "schtasks", "/Create", "/F",
            "/TN", "Rewindex",
            "/TR", cmd,
            "/SC", "ONLOGON",
            "/RL", "HIGHEST",
        ], check=True)

    def uninstall_autostart(self) -> None:
        subprocess.run(
            ["schtasks", "/Delete", "/F", "/TN", "Rewindex"],
            check=True,
        )
