# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import re

MAX_FILEPATH_LEN = 1024
MAX_STRING_LEN = 256
_WORKSPACE_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$")


def same_folder(path_a: str, path_b: str) -> bool:
    """
    Return True if two paths refer to the same directory on disk.
    Handles: symlinks, `.`/`..`, double slashes, trailing slashes, tilde (caller
    must expanduser first), AND bind mounts (via device+inode comparison).
    Falls back to realpath-only if stat fails (e.g. path doesn't exist yet).
    """
    real_a = os.path.realpath(path_a)
    real_b = os.path.realpath(path_b)
    if real_a == real_b:
        return True
    # Bind-mount check: same inode + device = same directory regardless of path
    try:
        st_a = os.stat(real_a)
        st_b = os.stat(real_b)
        return (st_a.st_ino, st_a.st_dev) == (st_b.st_ino, st_b.st_dev)
    except OSError:
        return False


def validate_filepath(filepath: str) -> None:
    """Raise ValueError if filepath contains null bytes or is too long."""
    if "\x00" in filepath:
        raise ValueError(f"Invalid filepath — null byte detected: {filepath!r}")
    if len(filepath) > MAX_FILEPATH_LEN:
        raise ValueError(f"Filepath too long ({len(filepath)} chars, max {MAX_FILEPATH_LEN})")


def validate_string(value: str, name: str = "value") -> None:
    """Raise ValueError if string contains null bytes or is too long."""
    if "\x00" in value:
        raise ValueError(f"Invalid {name} — null byte detected: {value!r}")
    if len(value) > MAX_STRING_LEN:
        raise ValueError(f"{name} too long ({len(value)} chars, max {MAX_STRING_LEN})")


def validate_workspace_name(name: str) -> None:
    """Raise ValueError if workspace name contains invalid characters.
    Allowed: a-z A-Z 0-9 . _ - (must start with alphanumeric, max 64 chars)."""
    if not name:
        raise ValueError("Workspace name cannot be empty")
    if "\x00" in name:
        raise ValueError(f"Invalid workspace name — null byte detected: {name!r}")
    if len(name) > 64:
        raise ValueError(f"Workspace name too long ({len(name)} chars, max 64)")
    if not _WORKSPACE_NAME_RE.match(name):
        raise ValueError(
            f"Invalid workspace name '{name}' — only letters, digits, dots, hyphens, and underscores allowed"
        )
