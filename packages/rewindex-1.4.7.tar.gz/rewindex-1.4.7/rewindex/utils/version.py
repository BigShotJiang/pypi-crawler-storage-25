# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Version parsing, bumping, and formatting helpers for the flag system.

Supported formats (controlled by flag.version_segments):
  1 segment  →  v1, v2, v3
  2 segments →  v1.0, v1.1, v2.0
  3 segments →  v1.0.0, v1.0.1 (semver, default)

Bump kinds:
  "patch"  — last segment +1  (only valid for segments=3)
  "minor"  — second segment +1, last segment reset to 0  (valid for segments=2 and 3)
  "major"  — first segment +1, remaining segments reset to 0  (valid for all)
"""

import re
from typing import Optional


_VERSION_PATTERN_1 = re.compile(r'^v?(\d+)$')
_VERSION_PATTERN_2 = re.compile(r'^v?(\d+)\.(\d+)$')
_VERSION_PATTERN_3 = re.compile(r'^v?(\d+)\.(\d+)\.(\d+)$')


def parse_version(version_str: str) -> tuple[int, ...]:
    """Parse a version string to a tuple of ints.

    Returns (major,) or (major, minor) or (major, minor, patch).
    Raises ValueError on invalid format.
    """
    s = version_str.strip()
    m3 = _VERSION_PATTERN_3.match(s)
    if m3:
        return (int(m3.group(1)), int(m3.group(2)), int(m3.group(3)))
    m2 = _VERSION_PATTERN_2.match(s)
    if m2:
        return (int(m2.group(1)), int(m2.group(2)))
    m1 = _VERSION_PATTERN_1.match(s)
    if m1:
        return (int(m1.group(1)),)
    raise ValueError(f'Invalid version string "{version_str}". Expected formats: v1 / v1.0 / v1.0.0')


def format_version(parts: tuple[int, ...], segments: int) -> str:
    """Format a version tuple into a canonical string with 'v' prefix.

    segments controls how many parts appear in the output.
    The parts tuple must have at least `segments` elements.
    """
    if segments == 1:
        return f"v{parts[0]}"
    if segments == 2:
        return f"v{parts[0]}.{parts[1]}"
    return f"v{parts[0]}.{parts[1]}.{parts[2]}"


def bump_version(
    current: Optional[str],
    kind: str,
    segments: int,
) -> str:
    """Compute the next version string given the current latest and a bump kind.

    Args:
        current: The latest version string, or None if no flags exist yet.
        kind:    "patch" | "minor" | "major"
        segments: 1 | 2 | 3

    Returns:
        New version string (e.g. "v1.0.1").

    Raises:
        ValueError: if bump kind is incompatible with segments count.
    """
    _validate_bump_kind(kind, segments)

    if current is None:
        # First flag ever — start at the baseline
        if segments == 1:
            base = (0,)
        elif segments == 2:
            base = (0, 0)
        else:
            base = (0, 0, 0)
    else:
        try:
            base = parse_version(current)
        except ValueError:
            # Fallback to zero-start if stored version is unparseable
            if segments == 1:
                base = (0,)
            elif segments == 2:
                base = (0, 0)
            else:
                base = (0, 0, 0)

    # Pad to required segments
    padded = _pad(base, segments)

    if kind == "major":
        new_parts = (padded[0] + 1,) + (0,) * (segments - 1)
    elif kind == "minor":
        new_parts = (padded[0], padded[1] + 1) + (0,) * (segments - 2)
    else:  # patch (only reaches here when segments == 3)
        new_parts = (padded[0], padded[1], padded[2] + 1)

    return format_version(new_parts, segments)


def validate_explicit_version(version_str: str, segments: int) -> str:
    """Validate and normalise an explicit version string provided via --ver.

    The version must match the configured segments count.
    Returns the canonical "vX[.Y[.Z]]" string.

    Raises ValueError on mismatch or invalid format.
    """
    try:
        parts = parse_version(version_str)
    except ValueError as e:
        raise ValueError(str(e)) from e

    if len(parts) != segments:
        seg_example = {1: "v1", 2: "v1.0", 3: "v1.0.0"}[segments]
        raise ValueError(
            f'Version "{version_str}" has {len(parts)} segment(s), '
            f"but workspace is configured for {segments} segments (e.g. {seg_example})."
        )
    return format_version(parts, segments)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _validate_bump_kind(kind: str, segments: int) -> None:
    """Raise ValueError if kind is incompatible with segments."""
    valid = {1: {"major"}, 2: {"major", "minor"}, 3: {"major", "minor", "patch"}}
    allowed = valid.get(segments, set())
    if kind not in allowed:
        names = {1: "v1 (segments=1)", 2: "v1.0 (segments=2)", 3: "v1.0.0 (segments=3)"}
        raise ValueError(
            f'Bump kind "{kind}" is not valid for {names.get(segments, f"segments={segments}")}. '
            f"Allowed: {', '.join(sorted(allowed))}."
        )


def _pad(parts: tuple[int, ...], length: int) -> tuple[int, ...]:
    """Extend a parts tuple with zeros to reach the required length."""
    return parts + (0,) * max(0, length - len(parts))
