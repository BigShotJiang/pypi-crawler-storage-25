# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
License management via LemonSqueezy API + encrypted local file.

Validates license keys directly with LemonSqueezy public API.
Stores license data in ~/.rewindex/.license, encrypted with a key
derived from the machine's MAC address.
"""

import hashlib
import hmac
import json
import os
import socket
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from rewindex.config.defaults import REWINDEX_DIR
from rewindex.config.urls import ACTIVATE_URL, DEACTIVATE_URL, VALIDATE_URL


@dataclass
class LicenseResult:
    valid: bool
    plan: str
    expires_at: str

_LICENSE_FILE = os.path.join(REWINDEX_DIR, ".license")
_SALT = b"rewindex-license-v2"


def _get_machine_key() -> bytes:
    mac = uuid.getnode().to_bytes(6, "big")
    return hashlib.sha256(_SALT + mac).digest()


def _encrypt(data: bytes) -> bytes:
    key = _get_machine_key()
    # XOR stream cipher with HMAC-SHA256 keystream
    stream = b""
    block = 0
    while len(stream) < len(data):
        stream += hashlib.sha256(key + block.to_bytes(4, "big")).digest()
        block += 1
    encrypted = bytes(a ^ b for a, b in zip(data, stream))
    tag = hmac.new(key, encrypted, hashlib.sha256).digest()[:16]
    return tag + encrypted


def _decrypt(blob: bytes) -> bytes | None:
    if len(blob) < 17:
        return None
    key = _get_machine_key()
    tag = blob[:16]
    encrypted = blob[16:]
    expected_tag = hmac.new(key, encrypted, hashlib.sha256).digest()[:16]
    if not hmac.compare_digest(tag, expected_tag):
        return None
    stream = b""
    block = 0
    while len(stream) < len(encrypted):
        stream += hashlib.sha256(key + block.to_bytes(4, "big")).digest()
        block += 1
    return bytes(a ^ b for a, b in zip(encrypted, stream))


def _read_license_data() -> dict:
    try:
        with open(_LICENSE_FILE, "rb") as f:
            blob = f.read()
        data = _decrypt(blob)
        if data is None:
            return {}
        return json.loads(data.decode("utf-8"))
    except (OSError, json.JSONDecodeError, ValueError):
        return {}


def _write_license_data(data: dict) -> None:
    os.makedirs(REWINDEX_DIR, exist_ok=True)
    raw = json.dumps(data).encode("utf-8")
    blob = _encrypt(raw)
    fd = os.open(_LICENSE_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, blob)
    finally:
        os.close(fd)


def get_membership() -> dict:
    data = _read_license_data()
    plan = data.get("plan", "Free")
    expires = data.get("expires_at", "")
    status = "active"

    if plan == "Pro" and expires:
        try:
            exp_dt = datetime.fromisoformat(expires)
            if exp_dt < datetime.now(timezone.utc):
                status = "expired"
                plan = "Free"
        except ValueError:
            pass

    return {
        "plan": plan,
        "status": status,
        "expires_at": expires,
    }


def is_pro() -> bool:
    m = get_membership()
    return m["plan"] == "Pro" and m["status"] == "active"


def _post_api(url: str, payload: dict) -> dict:
    import urllib.error
    import urllib.request
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode("utf-8"))
        except (json.JSONDecodeError, ValueError):
            raise ConnectionError(f"License server returned HTTP {e.code}")
    except (urllib.error.URLError, OSError) as e:
        raise ConnectionError(f"Cannot reach license server: {e}")


def _validate_with_server(license_key: str, instance_id: str = "") -> dict:
    payload = {"license_key": license_key}
    if instance_id:
        payload["instance_id"] = instance_id
    resp = _post_api(VALIDATE_URL, payload)

    valid = resp.get("valid", False)
    if not valid:
        status = resp.get("license_key", {}).get("status", "unknown")
        if status == "expired":
            raise ValueError("License key has expired.")
        elif status in ("inactive", "disabled"):
            raise ValueError("License key is inactive or disabled.")
        raise ValueError("License key is not valid.")

    return resp


def _activate_with_server(license_key: str) -> dict:
    hostname = socket.gethostname()
    resp = _post_api(ACTIVATE_URL, {
        "license_key": license_key,
        "instance_name": hostname,
    })

    if not resp.get("activated", False):
        error = resp.get("error", "Activation failed.")
        if "activation limit" in error.lower():
            raise ValueError("ACTIVATION_LIMIT_REACHED")
        raise ValueError(error)

    return resp


def _deactivate_with_server(license_key: str, instance_id: str) -> dict:
    resp = _post_api(DEACTIVATE_URL, {
        "license_key": license_key,
        "instance_id": instance_id,
    })

    if not resp.get("deactivated", False):
        error = resp.get("error", "Deactivation failed.")
        raise ValueError(error)

    return resp


def activate_license(license_key: str) -> LicenseResult:
    """Activate a license key on this machine. Raises ConnectionError or ValueError."""
    resp = _activate_with_server(license_key)

    lk = resp.get("license_key", {})
    instance = resp.get("instance", {})
    expires_at = lk.get("expires_at") or ""

    _write_license_data({
        "license_key": license_key,
        "plan": "Pro",
        "expires_at": expires_at,
        "instance_id": instance.get("id", ""),
        "activated_at": datetime.now(timezone.utc).isoformat(),
    })

    return LicenseResult(valid=True, plan="Pro", expires_at=expires_at)


def deactivate_license() -> bool:
    """Deactivate the license on this machine. Returns True if successful."""
    data = _read_license_data()
    license_key = data.get("license_key", "")
    instance_id = data.get("instance_id", "")

    if not license_key or not instance_id:
        raise ValueError("No active license found on this machine.")

    _deactivate_with_server(license_key, instance_id)
    clear_license()
    return True



def validate_license() -> LicenseResult:
    """Validate the current license with LemonSqueezy. Updates local file."""
    data = _read_license_data()
    license_key = data.get("license_key", "")
    instance_id = data.get("instance_id", "")

    if not license_key:
        return LicenseResult(valid=False, plan="Free", expires_at="")

    try:
        resp = _validate_with_server(license_key, instance_id)
    except (ConnectionError, ValueError):
        return LicenseResult(valid=False, plan="Free", expires_at="")

    lk = resp.get("license_key", {})
    status = lk.get("status", "unknown")
    expires_at = lk.get("expires_at") or ""

    if status != "active":
        return LicenseResult(valid=False, plan="Free", expires_at=expires_at)

    data["expires_at"] = expires_at
    data["validated_at"] = datetime.now(timezone.utc).isoformat()
    _write_license_data(data)

    return LicenseResult(valid=True, plan="Pro", expires_at=expires_at)


def clear_license() -> None:
    try:
        os.remove(_LICENSE_FILE)
    except FileNotFoundError:
        pass
