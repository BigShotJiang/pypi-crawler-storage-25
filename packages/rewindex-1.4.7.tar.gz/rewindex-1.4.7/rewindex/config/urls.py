# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

LINK_PRICING = "https://rewindex.org"
LINK_SUBSCRIPTION = "https://rewindex.org"
LINK_DOCS = "https://rewindex.org"
VALIDATE_URL = "https://api.lemonsqueezy.com/v1/licenses/validate"
ACTIVATE_URL = "https://api.lemonsqueezy.com/v1/licenses/activate"
DEACTIVATE_URL = "https://api.lemonsqueezy.com/v1/licenses/deactivate"
