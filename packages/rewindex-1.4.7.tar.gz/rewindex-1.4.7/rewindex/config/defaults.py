# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

REWINDEX_DIR = os.path.expanduser("~/.rewindex")
CONFIG_PATH = os.path.join(REWINDEX_DIR, ".rewindex.config.yaml")
CONFIG_BACKUP_PATH = os.path.join(REWINDEX_DIR, ".rewindex.config.backup.yaml")
SNAPSHOTS_DIR = os.path.join(REWINDEX_DIR, "snapshots")
TRASH_DIR = os.path.join(REWINDEX_DIR, "trash")
PID_FILE = os.path.join(REWINDEX_DIR, "daemon.pid")
DISK_WARNING_FILE = os.path.join(REWINDEX_DIR, "disk_warning")

DISK_WARN_BYTES = 500 * 1024 * 1024   # 500 MB free → warn
DISK_WARN_RATIO = 0.10                 # 10% free → warn (whichever threshold is larger)
DISK_FULL_BYTES = 1 * 1024 * 1024     # < 1 MB free → skip snapshot

MAX_TEXT_FILE_BYTES = 10 * 1024 * 1024   # 10 MB — skip text files larger than this
MAX_DIFF_CHAIN = 1000                     # hard safety cap for reconstruct (should never hit in practice)
MAX_CONFIG_FILE_BYTES = 1 * 1024 * 1024  # 1 MB — reject config file larger than this (YAML bomb)
MAX_GZIP_READ_BYTES = 50 * 1024 * 1024   # 50 MB — reject decompressed content larger than this (gzip bomb)
MAX_PENDING_EVENTS = 1000                 # max queued file events before dropping oldest (event flood)
MAX_LOG_BYTES = 5 * 1024 * 1024           # 5 MB per log file
LOG_BACKUP_COUNT = 3                       # keep 3 rotated backups (20 MB total max)
DIFF_COMPRESS_THRESHOLD = 5 * 1024        # 5 KB — compress diffs larger than this

# Trim defaults
DEFAULT_SESSION_SAFE = 500
DEFAULT_SESSION_MAX = 600

# Tier limits
FREE_MAX_WORKSPACES = 1
FREE_MAX_FOLDERS = 1
PRO_MAX_FOLDERS = 999999

# Security exclude — hardcoded, not user-configurable.
# Applied before user exclude list. Prevents credential harvesting and secret leakage.
SECURITY_EXCLUDE = [
    # Generic secrets
    "*.secret",
    "credentials",
    "credentials.*",
    # SSH keys
    "id_rsa",
    "id_rsa.*",
    "id_ed25519",
    "id_ed25519.*",
    "id_dsa",
    "id_ecdsa",
    "authorized_keys",
    # Certificates & keystores
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "*.cer",
    "*.crt",
    # Package manager auth tokens
    ".npmrc",
    ".pypirc",
    ".netrc",
    # Password / token files
    "*.password",
    "*.passwd",
    "*.token",
    # Cloud credentials
    "*.kubeconfig",
]

# Default exclude — user-configurable via config.yaml.
# Environment files, build artifacts, dependencies, generated files.
DEFAULT_EXCLUDE = [
    ".env",
    ".env.*",
    "node_modules/",
    ".git/",
    "__pycache__/",
    "venv/",
    ".venv/",
    "*.log",
    "*.tmp",
    "*.tmp.*",
]

SESSION_GAP_SECONDS = 20  # snapshots > 20s apart or different agent = new session

FLAG_DEFAULTS = {
    "version_segments": 3,
    "auto_bump": "patch",
    "promote_to_fullbase": False,
    "keep_orphaned_record": True,
    "max_description_bytes": 8192,
}

DEFAULT_CONFIG = {
    "workspaces": [],
    "global_exclude": DEFAULT_EXCLUDE,
    "session_gap_seconds": SESSION_GAP_SECONDS,
    "session_safe": DEFAULT_SESSION_SAFE,
    "session_max": DEFAULT_SESSION_MAX,
    "flag": FLAG_DEFAULTS,
}
