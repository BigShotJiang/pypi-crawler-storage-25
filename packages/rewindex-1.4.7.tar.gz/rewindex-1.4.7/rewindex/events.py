# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""Minimal event log — append-only JSONL file at ~/.rewindex/events.jsonl.

Each line is a small JSON object: {"event": "snap", "ts": 1234, ...}
Consumers (dashboard, etc.) poll this file and query SQLite for details.
"""

import json
import time
from pathlib import Path

EVENTS_FILE = Path.home() / ".rewindex" / "events.jsonl"


def emit(event: str, **kwargs: object) -> None:
    """Append one event line. Never raises — fire and forget."""
    try:
        EVENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        entry = {"event": event, "ts": time.time(), **kwargs}
        with open(EVENTS_FILE, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass
