# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""Hooks interface for rewindex plugins.

Plugins register themselves via the "rewindex.hooks" entry-points group.
Core fires events after snap, rewind, and workspace changes.
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class HooksInterface(Protocol):
    def on_snap(self, session_id: str, files: list[dict], note: str) -> None: ...
    def on_rewind(self, target: str, files_restored: list[str]) -> None: ...
    def on_workspace_change(self, event: str, workspace: dict) -> None: ...
