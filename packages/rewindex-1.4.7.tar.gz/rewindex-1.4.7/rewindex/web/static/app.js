// ── Skeleton ──
function skeleton(page) {
    const r = (w) => `<div class="sk sk-line" style="width:${w}%"></div>`;
    const card = (lines) => `<div class="sk-card">${lines}</div>`;
    const stat = `<div class="sk-stat"><div class="sk" style="width:40px;height:28px"></div><div class="sk sk-line-sm" style="width:50px"></div></div>`;

    const header = `<div class="sk sk-heading"></div>`;

    if (page === 'overview') return header +
        `<div class="sk-grid-4">${stat}${stat}${stat}${stat}</div>` +
        `<div class="sk sk-line" style="width:100px;margin-bottom:16px"></div>` +
        `<div class="sk-grid-3">${card(r(60)+r(40)+r(30))}${card(r(60)+r(40)+r(30))}${card(r(60)+r(40)+r(30))}</div>`;

    if (page === 'timeline') return header +
        card(`<div class="sk-row">${r(50)}${r(20)}</div>` + r(80)) +
        card(`<div class="sk-row">${r(50)}${r(20)}</div>` + r(80)) +
        card(`<div class="sk-row">${r(50)}${r(20)}</div>` + r(80)) +
        card(`<div class="sk-row">${r(50)}${r(20)}</div>` + r(80));

    if (page === 'files') return header +
        `<div class="sk sk-input" style="width:100%"></div>` +
        card(r(70) + r(50)) + card(r(60) + r(45)) + card(r(55) + r(40)) + card(r(65) + r(35));

    if (page === 'flags') return header +
        card(r(30) + r(70) + r(50)) + card(r(30) + r(70) + r(50)) + card(r(30) + r(70) + r(50));

    if (page === 'workspaces') return header +
        `<div class="sk sk-input" style="width:100%"></div>` +
        card(`<div class="sk-row">${r(40)}${r(20)}${r(20)}</div>`) +
        card(`<div class="sk-row">${r(40)}${r(20)}${r(20)}</div>`) +
        card(`<div class="sk-row">${r(40)}${r(20)}${r(20)}</div>`);

    if (page === 'settings') return header +
        card(r(40) + r(60) + r(30)) + card(r(40) + r(60) + r(30));

    if (page === 'license') return header + card(r(50) + r(70) + r(40));

    return header + card(r(60) + r(40));
}

// ── Utilities ──
function debounce(fn, ms) {
    let t;
    return function(...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms); };
}

function highlightMatch(text, query) {
    if (!query) return esc(text);
    const escaped = esc(text);
    const re = new RegExp('(' + query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
    return escaped.replace(re, '<mark>$1</mark>');
}

// ── State ──
let state = { workspace: null, workspaces: [], page: 'overview' };
let eventSource = null;
let _fileSearchQuery = '';
const _debouncedFilterFiles = debounce(filterFiles, 200);

// ── API ──
const api = {
    async get(url) {
        try {
            const r = await fetch(url);
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            return await r.json();
        } catch (e) {
            console.error('API:', e);
            return null;
        }
    },
    async post(url, body) {
        try {
            const r = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            return await r.json();
        } catch (e) {
            console.error('API:', e);
            showToast(e.message, 'error');
            return null;
        }
    },
    async del(url, body) {
        try {
            const r = await fetch(url, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            return await r.json();
        } catch (e) {
            console.error('API:', e);
            showToast(e.message, 'error');
            return null;
        }
    },
};

// ── Helpers ──
const _UTC_OFFSET_MAP = {
    'UTC-12': 'Etc/GMT+12', 'UTC-11': 'Etc/GMT+11', 'UTC-10': 'Etc/GMT+10',
    'UTC-9':  'Etc/GMT+9',  'UTC-8':  'Etc/GMT+8',  'UTC-7':  'Etc/GMT+7',
    'UTC-6':  'Etc/GMT+6',  'UTC-5':  'Etc/GMT+5',  'UTC-4':  'Etc/GMT+4',
    'UTC-3':  'Etc/GMT+3',  'UTC-2':  'Etc/GMT+2',  'UTC-1':  'Etc/GMT+1',
    'UTC+0':  'Etc/GMT',    'UTC+1':  'Etc/GMT-1',  'UTC+2':  'Etc/GMT-2',
    'UTC+3':  'Etc/GMT-3',  'UTC+4':  'Etc/GMT-4',  'UTC+5':  'Etc/GMT-5',
    'UTC+5:30': 'Asia/Kolkata', 'UTC+6': 'Etc/GMT-6', 'UTC+7': 'Etc/GMT-7',
    'UTC+8':  'Etc/GMT-8',  'UTC+9':  'Etc/GMT-9',  'UTC+10': 'Etc/GMT-10',
    'UTC+11': 'Etc/GMT-11', 'UTC+12': 'Etc/GMT-12',
};

function getTimezone() {
    const saved = localStorage.getItem('rewindex-tz');
    if (!saved || saved === 'auto') return Intl.DateTimeFormat().resolvedOptions().timeZone;
    return _UTC_OFFSET_MAP[saved] || Intl.DateTimeFormat().resolvedOptions().timeZone;
}

function setTimezone(tz) {
    localStorage.setItem('rewindex-tz', tz);
    router();
}

function timeAgo(iso) {
    if (!iso) return '—';
    const ms = Date.now() - new Date(iso).getTime();
    const sec = Math.floor(ms / 1000);
    if (sec < 60)   return 'just now';
    const min = Math.floor(sec / 60);
    if (min < 60)   return min + 'm ago';
    const hr = Math.floor(min / 60);
    if (hr < 24)    return hr + 'h ago';
    const day = Math.floor(hr / 24);
    if (day < 30)   return day + 'd ago';
    return new Date(iso).toLocaleDateString(undefined, { timeZone: getTimezone() });
}

function fmtTime(iso) {
    if (!iso) return '—';
    return timeAgo(iso);
}

function fmtSize(b) {
    if (b == null) return '—';
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
    return (b / 1048576).toFixed(1) + ' MB';
}

function esc(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
}

function statusBadge(s) {
    const m = { CREATE: 'success', CHANGE: 'info', DELETE: 'danger', MOVE: 'warning', RENAME: 'warning', CORRUPT: 'danger' };
    return `<span class="badge badge-${m[s] || 'default'}">${s || '—'}</span>`;
}

function fmtDiff(text) {
    if (!text) return '';
    return text.split('\n').map(l => {
        const e = esc(l);
        if (l.startsWith('+'))  return `<span class="diff-add">${e}</span>`;
        if (l.startsWith('-'))  return `<span class="diff-del">${e}</span>`;
        if (l.startsWith('@') || l.startsWith('─')) return `<span class="diff-header">${e}</span>`;
        return e;
    }).join('\n');
}

function parseSymbols(s) {
    if (!s) return [];
    if (Array.isArray(s)) return s;
    try { return JSON.parse(s); } catch { return []; }
}

function renderSymbolTags(symbols) {
    const list = parseSymbols(symbols);
    if (list.length === 0) return '';
    const tags = list.map(s => `<span class="symbol-tag">${esc(s)}</span>`).join('');
    return `<span class="symbol-tags">${tags}</span>`;
}

function renderLineStats(added, removed) {
    if (added == null && removed == null) return '';
    const parts = [];
    if (added != null && added > 0) parts.push(`<span class="line-stat-add">+${added}</span>`);
    if (removed != null && removed > 0) parts.push(`<span class="line-stat-del">-${removed}</span>`);
    if (parts.length === 0) return '';
    return `<span class="line-stats">${parts.join('')}</span>`;
}

// ── Toast ──
function showToast(msg, type) {
    type = type || 'info';
    const c = document.getElementById('toast-container');
    const t = document.createElement('div');
    t.className = 'toast toast-' + type;
    t.textContent = msg;
    c.appendChild(t);
    setTimeout(() => {
        t.style.opacity = '0';
        t.style.transform = 'translateY(10px)';
        t.style.transition = '0.3s ease';
        setTimeout(() => t.remove(), 300);
    }, 3000);
}

// ── Modal ──
function openModal(title, body, footer) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = body;
    document.getElementById('modal-footer').innerHTML = footer;
    document.getElementById('modal-overlay').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('modal-overlay').classList.add('hidden');
}

// ── Sidebar ──
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const btn = document.getElementById('menu-toggle');
    sidebar.classList.toggle('open');
    btn.classList.toggle('hidden', sidebar.classList.contains('open'));
}

document.addEventListener('click', function(e) {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar.classList.contains('open')) return;
    if (sidebar.contains(e.target)) return;
    if (e.target.id === 'menu-toggle' || e.target.closest('#menu-toggle')) return;
    sidebar.classList.remove('open');
    document.getElementById('menu-toggle').classList.remove('hidden');
});

// ── Daemon status ──
async function refreshDaemon() {
    const d = await api.get('/api/status');
    const dot = document.querySelector('.daemon-dot');
    const txt = document.getElementById('daemon-text');
    if (d && d.running) {
        dot.classList.remove('offline');
        txt.textContent = 'Running (PID ' + d.pid + ')';
    } else {
        dot.classList.add('offline');
        txt.textContent = 'Stopped';
    }
}

// ── Router ──
async function router() {
    const raw = window.location.hash.slice(1) || 'overview';
    const [page, sub] = raw.split('/');
    state.page = page;
    document.querySelectorAll('.nav-item').forEach(el => {
        el.classList.toggle('active', el.dataset.page === page);
    });
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('menu-toggle').classList.remove('hidden');
    const ub = document.getElementById('update-bar');
    if (ub) ub.remove();

    const pages = {
        overview:   renderOverview,
        files:      () => renderFiles(sub),
        timeline:   () => renderTimeline(sub),
        flags:      renderFlags,
        workspaces: renderWorkspaces,
        settings:   renderSettings,
        license:    renderLicense,
        update:     renderUpdate,
    };
    await (pages[page] || renderOverview)();
}

// ── Init ──
async function init() {
    const workspaces = await api.get('/api/workspaces');
    if (!workspaces || workspaces.length === 0) {
        renderNoWorkspaces();
        return;
    }
    state.workspaces = workspaces;
    const saved = localStorage.getItem('rewindex-workspace');
    state.workspace = workspaces.find(p => p.name === saved) ? saved : workspaces[0].name;

    const sel = document.getElementById('project-select');
    sel.innerHTML = workspaces.map(p =>
        `<option value="${esc(p.name)}">${esc(p.name)}</option>`
    ).join('');
    sel.value = state.workspace;
    sel.addEventListener('change', () => {
        state.workspace = sel.value;
        localStorage.setItem('rewindex-workspace', sel.value);
        router();
    });

    refreshDaemon();
    setInterval(refreshDaemon, 15000);

    updateScrollLockUI();
    startSSE();

    router();

    api.get('/api/version-check').then(d => {
        if (!d || !d.online) return;
        const hasUpdates = Object.values(d.packages).some(p => !p.up_to_date && p.latest !== null);
        const badge = document.getElementById('update-badge');
        if (badge) badge.classList.toggle('hidden', !hasUpdates);
    });
}

function renderNoWorkspaces() {
    document.getElementById('page-content').innerHTML = `
        <div class="empty-state">
            <h2>No workspaces found</h2>
            <p class="text-muted" style="margin-top:8px">Set up Rewindex in your project folder:</p>
            <div class="code-block" style="display:inline-block;margin:16px 0;text-align:left">
<span style="color:var(--text-muted)"># 1. Go to your project</span>
cd /your/project

<span style="color:var(--text-muted)"># 2. Initialize</span>
rewindex init

<span style="color:var(--text-muted)"># 3. Start the daemon</span>
rewindex start</div>
            <p class="text-muted">Then <a class="link" href="javascript:location.reload()">refresh this page</a>.</p>
        </div>`;
}

// ═══════════════════════════════════════
//  Page: Overview
// ═══════════════════════════════════════
async function renderOverview() {
    const el = document.getElementById('page-content');
    el.innerHTML = skeleton('overview');
    if (!state.workspace) { renderNoWorkspaces(); return; }

    const [sessData, flagData] = await Promise.all([
        api.get('/api/sessions/' + state.workspace + '?limit=10'),
        api.get('/api/flags/' + state.workspace),
    ]);
    const ws = state.workspaces.find(p => p.name === state.workspace) || {};
    const sessions = sessData ? sessData.sessions : [];
    const flags = flagData || [];

    el.innerHTML = `
        <div class="page-header">
            <h1>Overview</h1>
        </div>
        <div class="stat-grid">
            <div class="stat-card"><div class="stat-value">${ws.total_files || 0}</div><div class="stat-label">Files</div></div>
            <div class="stat-card"><div class="stat-value">${ws.total_snapshots || 0}</div><div class="stat-label">Snapshots</div></div>
            <div class="stat-card"><div class="stat-value">${ws.total_sessions || 0}</div><div class="stat-label">Sessions</div></div>
            <div class="stat-card"><div class="stat-value">${flags.length}</div><div class="stat-label">Flags</div></div>
        </div>
        <div class="section-header">
            <h2>Workspaces</h2>
            ${state.workspaces.length > 9 ? '<a href="#workspaces" class="link">View all (' + state.workspaces.length + ')</a>' : ''}
        </div>
        <div class="ws-overview-grid">
            ${state.workspaces.slice(0, 9).map(w => {
                const active = w.name === state.workspace;
                return `<div class="ws-overview-card${active ? ' ws-active' : ''}" onclick="selectWorkspace('${esc(w.name)}')">
                    <div class="ws-overview-header">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" stroke="currentColor" stroke-width="1.5"/></svg>
                        <span class="ws-overview-name">${esc(w.name)}</span>
                        ${active ? '<span class="badge badge-success">Selected</span>' : ''}
                    </div>
                    <div class="ws-overview-stats">
                        <span>${w.total_files || 0} files</span>
                        <span>${w.total_snapshots || 0} snaps</span>
                        <span>${w.total_sessions || 0} sessions</span>
                    </div>
                    <div class="ws-overview-time">${w.last_session ? 'Last: ' + timeAgo(w.last_session) : 'No sessions'}</div>
                </div>`;
            }).join('')}
        </div>`;
}

// ═══════════════════════════════════════
//  Page: Files
// ═══════════════════════════════════════
let _filesCache = null;

function getFileView() {
    return localStorage.getItem('rewindex-file-view') || 'folder';
}

function setFileView(mode) {
    localStorage.setItem('rewindex-file-view', mode);
    if (_filesCache) renderFilesBody(_filesCache);
}

async function renderFiles(focusFileId) {
    const el = document.getElementById('page-content');
    el.innerHTML = skeleton('files');
    if (!state.workspace) { renderNoWorkspaces(); return; }

    const [filesData, sessData] = await Promise.all([
        api.get('/api/files/' + state.workspace),
        api.get('/api/sessions/' + state.workspace + '?limit=1'),
    ]);
    const files = filesData && filesData.files ? filesData.files : (Array.isArray(filesData) ? filesData : []);
    if (!files) { el.innerHTML = '<div class="empty-state"><p>Failed to load</p></div>'; return; }
    _filesCache = files;
    const latestSess = sessData && sessData.sessions && sessData.sessions[0];
    const view = getFileView();

    el.innerHTML = `
        <div class="page-header">
            <div class="page-header-left">
                <h1>Files</h1>
                ${latestSess ? '<span class="badge badge-session">Session ' + latestSess.uid + ' <span class="mono">SS' + latestSess.uid + '</span></span>' : ''}
            </div>
            <div class="view-toggle">
                <button class="view-btn ${view === 'folder' ? 'active' : ''}" onclick="setFileView('folder')">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/></svg>
                    Folder
                </button>
                <button class="view-btn ${view === 'flat' ? 'active' : ''}" onclick="setFileView('flat')">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
                    Flat
                </button>
            </div>
        </div>
        <input type="text" class="form-input search-input" placeholder="Search files..." id="file-search" oninput="_debouncedFilterFiles()">
        <div id="files-body"></div>`;
    renderFilesBody(files);

    if (focusFileId) {
        if (view === 'folder') {
            const row = document.querySelector('.file-row[data-fid="' + focusFileId + '"]');
            if (row) {
                let parent = row.parentElement;
                while (parent) {
                    if (parent.classList && parent.classList.contains('folder-children')) {
                        parent.style.display = '';
                        const icon = document.getElementById('fic-' + parent.id);
                        if (icon) icon.classList.add('folder-open');
                    }
                    parent = parent.parentElement;
                }
            }
        } else {
            const detEl = document.getElementById('fdet-' + focusFileId);
            if (!detEl) {
                const tbody = document.getElementById('file-tbody');
                if (tbody) {
                    const f = files.find(x => x.file_id === focusFileId);
                    if (f) tbody.insertAdjacentHTML('afterbegin', _fileRowHtmlFlat(f));
                }
            }
        }
        await toggleFile(focusFileId);
        const row = document.querySelector('.file-row[data-fid="' + focusFileId + '"]');
        if (row) {
            row.scrollIntoView({ behavior: 'smooth', block: 'center' });
            row.classList.add('highlight-flash');
            row.addEventListener('animationend', () => row.classList.remove('highlight-flash'), { once: true });
        }
    }
}

function renderFilesBody(files) {
    const el = document.getElementById('files-body');
    if (!el) return;
    const view = getFileView();
    if (view === 'folder') {
        renderFolderView(el, files);
    } else {
        renderFlatView(el, files);
    }
    document.querySelectorAll('.view-btn').forEach(b => {
        b.classList.toggle('active', b.textContent.trim().toLowerCase() === view);
    });
}

let _fileSort = { col: null, dir: null };

function _sortArrow(col) {
    if (_fileSort.col !== col) return '';
    return _fileSort.dir === 'desc' ? ' &#9660;' : ' &#9650;';
}

function sortFiles(col) {
    if (_fileSort.col === col) {
        if (_fileSort.dir === 'desc') _fileSort.dir = 'asc';
        else if (_fileSort.dir === 'asc') { _fileSort.col = null; _fileSort.dir = null; }
    } else {
        _fileSort.col = col;
        _fileSort.dir = 'desc';
    }
    if (_filesCache) renderFilesBody(_filesCache);
}

function _sortedFiles(files) {
    const sorted = [...files];
    if (!_fileSort.col) return sorted;
    const dir = _fileSort.dir === 'desc' ? -1 : 1;
    sorted.sort((a, b) => {
        let va, vb;
        switch (_fileSort.col) {
            case 'path': va = (a.filepath || a.filename || '').toLowerCase(); vb = (b.filepath || b.filename || '').toLowerCase(); return va < vb ? -dir : va > vb ? dir : 0;
            case 'versions': va = a.version_count || 0; vb = b.version_count || 0; return (va - vb) * dir;
            case 'update': va = a.last_update || ''; vb = b.last_update || ''; return va < vb ? -dir : va > vb ? dir : 0;
            case 'status': va = a.last_status || ''; vb = b.last_status || ''; return va < vb ? -dir : va > vb ? dir : 0;
            default: return 0;
        }
    });
    return sorted;
}

const FL_BATCH = 50;
let _fl = { rendered: 0, sorted: [], observer: null };

function _fileRowHtmlFlat(f) {
    return `<tr class="clickable file-row" data-fid="${f.file_id}" onclick="toggleFile('${f.file_id}')">
        <td><span class="mono" style="color:var(--accent);font-weight:700">${f.file_id}</span></td>
        <td>${highlightMatch(f.filepath || f.filename, _fileSearchQuery)}</td>
        <td>${f.version_count || 0}</td>
        <td class="text-secondary">${timeAgo(f.last_update)}</td>
        <td>${statusBadge(f.last_status)}</td>
    </tr>
    <tr class="file-detail-tr" id="fdet-${f.file_id}" style="display:none">
        <td colspan="5" style="padding:0">
            <div class="file-detail" id="fdet-c-${f.file_id}">
                <div class="loading-state">Loading versions...</div>
            </div>
        </td>
    </tr>`;
}

function _loadMoreFiles() {
    const tbody = document.getElementById('file-tbody');
    if (!tbody) return;
    const end = Math.min(_fl.rendered + FL_BATCH, _fl.sorted.length);
    let html = '';
    for (let i = _fl.rendered; i < end; i++) {
        html += _fileRowHtmlFlat(_fl.sorted[i]);
    }
    const sentinel = document.getElementById('files-sentinel');
    if (sentinel) sentinel.remove();
    tbody.insertAdjacentHTML('beforeend', html);
    _fl.rendered = end;
    if (_fl.rendered < _fl.sorted.length) {
        tbody.insertAdjacentHTML('beforeend', '<tr id="files-sentinel"><td colspan="5"><div class="loading-state">Loading more...</div></td></tr>');
        if (_fl.observer) _fl.observer.observe(document.getElementById('files-sentinel'));
    }
}

function renderFlatView(el, files) {
    _fl.sorted = _sortedFiles(files);
    _fl.rendered = 0;
    if (_fl.observer) _fl.observer.disconnect();

    const firstBatch = _fl.sorted.slice(0, FL_BATCH);
    _fl.rendered = firstBatch.length;
    const hasMore = _fl.rendered < _fl.sorted.length;

    el.innerHTML = `
        <div class="card">
            <div class="card-body-flush">
                <div class="table-wrap">
                    <table>
                        <thead><tr>
                            <th>ID</th>
                            <th class="sortable-th" onclick="sortFiles('path')">Path${_sortArrow('path')}</th>
                            <th class="sortable-th" onclick="sortFiles('versions')">Versions${_sortArrow('versions')}</th>
                            <th class="sortable-th" onclick="sortFiles('update')">Last Update${_sortArrow('update')}</th>
                            <th class="sortable-th" onclick="sortFiles('status')">Status${_sortArrow('status')}</th>
                        </tr></thead>
                        <tbody id="file-tbody">
                            ${firstBatch.length === 0 ? '<tr><td colspan="5"><div class="empty-state"><p>No tracked files</p></div></td></tr>' : firstBatch.map(f => _fileRowHtmlFlat(f)).join('')}
                            ${hasMore ? '<tr id="files-sentinel"><td colspan="5"><div class="loading-state">Loading more...</div></td></tr>' : ''}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>`;

    if (hasMore) {
        _fl.observer = new IntersectionObserver(entries => {
            if (entries[0].isIntersecting) _loadMoreFiles();
        }, { rootMargin: '200px' });
        _fl.observer.observe(document.getElementById('files-sentinel'));
    }
}

function buildFolderTree(files) {
    const root = { _files: [], _subs: {} };
    files.forEach(f => {
        const fp = f.filepath || f.filename || '';
        const parts = fp.split('/');
        const fileName = parts.pop();
        let node = root;
        parts.forEach(p => {
            if (!p) return;
            if (!node._subs[p]) node._subs[p] = { _files: [], _subs: {} };
            node = node._subs[p];
        });
        node._files.push(f);
    });
    return root;
}

function renderFolderNode(name, node, depth, prefix) {
    const fullPath = prefix ? prefix + '/' + name : name;
    const id = 'fld-' + fullPath.replace(/[^a-zA-Z0-9]/g, '_');
    const fileCount = countFilesRecursive(node);
    const indent = depth * 16;

    let html = '';
    if (name) {
        html += `<div class="folder-row clickable" style="padding-left:${20 + indent}px" onclick="toggleFolder('${id}')">
            <svg class="folder-icon" id="fic-${id}" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/></svg>
            <span class="folder-name">${esc(name)}</span>
            <span class="folder-count">${fileCount}</span>
        </div>
        <div id="${id}" class="folder-children" style="display:none">`;
    }

    const subNames = Object.keys(node._subs).sort();
    subNames.forEach(sub => {
        html += renderFolderNode(sub, node._subs[sub], depth + (name ? 1 : 0), fullPath);
    });

    node._files.forEach(f => {
        const fIndent = (depth + (name ? 1 : 0)) * 16;
        html += `<div class="folder-file-row clickable file-row" data-fid="${f.file_id}" style="padding-left:${20 + fIndent}px" onclick="toggleFile('${f.file_id}')">
            <span class="mono" style="color:var(--accent-hover);font-weight:600;min-width:40px">${f.file_id}</span>
            <span class="folder-file-name">${esc(f.filename || f.filepath)}</span>
            <span class="text-secondary" style="font-size:12px">v${f.latest_version || f.version_count || 0}</span>
            ${statusBadge(f.last_status)}
            <span class="text-secondary" style="font-size:12px;margin-left:auto">${timeAgo(f.last_update)}</span>
        </div>
        <div class="file-detail-tr" id="fdet-${f.file_id}" style="display:none">
            <div class="file-detail" id="fdet-c-${f.file_id}">
                <div class="loading-state">Loading versions...</div>
            </div>
        </div>`;
    });

    if (name) html += '</div>';
    return html;
}

function countFilesRecursive(node) {
    let count = node._files.length;
    Object.values(node._subs).forEach(sub => { count += countFilesRecursive(sub); });
    return count;
}

function toggleFolder(id) {
    const el = document.getElementById(id);
    const icon = document.getElementById('fic-' + id);
    if (!el) return;
    const open = el.style.display === 'none';
    el.style.display = open ? '' : 'none';
    if (icon) icon.classList.toggle('folder-open', open);
}

function renderFolderView(el, files) {
    if (files.length === 0) {
        el.innerHTML = '<div class="card"><div class="empty-state"><p>No tracked files</p></div></div>';
        return;
    }
    const tree = buildFolderTree(files);
    el.innerHTML = '<div class="card"><div class="card-body-flush">' + renderFolderNode('', tree, 0, '') + '</div></div>';
}

function filterFiles() {
    const q = document.getElementById('file-search').value.toLowerCase();
    _fileSearchQuery = q;
    const view = getFileView();
    if (view === 'folder') {
        document.querySelectorAll('.folder-file-row').forEach(r => {
            const match = r.textContent.toLowerCase().includes(q);
            r.style.display = match ? '' : 'none';
            const det = document.getElementById('fdet-' + r.dataset.fid);
            if (det && !match) det.style.display = 'none';
        });
        document.querySelectorAll('.folder-row').forEach(r => {
            if (!q) { r.style.display = ''; return; }
            const id = r.getAttribute('onclick').match(/'([^']+)'/)[1];
            const children = document.getElementById(id);
            if (children) {
                const hasVisible = children.querySelector('.folder-file-row:not([style*="display: none"])');
                r.style.display = hasVisible ? '' : 'none';
                if (hasVisible) children.style.display = '';
            }
        });
    } else {
        if (!_filesCache) return;
        const filtered = q ? _filesCache.filter(f => (f.filepath || f.filename || '').toLowerCase().includes(q) || (f.file_id || '').toLowerCase().includes(q)) : _filesCache;
        const el = document.getElementById('files-body');
        if (el) renderFlatView(el, filtered);
    }
}

async function toggleFile(fid) {
    const tr = document.getElementById('fdet-' + fid);
    const box = document.getElementById('fdet-c-' + fid);
    const row = document.querySelector('.file-row[data-fid="' + fid + '"]');
    if (tr.style.display !== 'none') { tr.style.display = 'none'; if (row) row.classList.remove('active'); return; }
    tr.style.display = '';
    if (row) row.classList.add('active');
    box.innerHTML = '<div class="loading-state">Loading...</div>';

    const [d, related] = await Promise.all([
        api.get('/api/files/' + state.workspace + '/' + fid),
        api.get('/api/related/' + state.workspace + '/' + fid),
    ]);
    if (!d) { box.innerHTML = '<div class="empty-state"><p>Failed</p></div>'; return; }

    const versions = d.versions || [];
    const latest = versions.length > 0 ? versions[0].file_version : 0;
    const relatedFiles = related || [];

    box.innerHTML = `
        <div class="file-detail-header">
            <span style="font-weight:600">${esc(d.file.filepath)}</span>
            <span class="text-muted">${versions.length} version${versions.length !== 1 ? 's' : ''}</span>
        </div>
        <div class="version-list">
            ${versions.map(v => `
                <div class="file-version-block clickable" onclick="toggleDiff('${fid}',${v.file_version},${v.uid})">
                    <div class="version-row">
                        <span class="version-v-tag">v${v.file_version}</span>
                        <span class="version-id">SS${v.session_uid}</span>
                        <span class="version-time">${timeAgo(v.created_at)}</span>
                        ${statusBadge(v.status)}
                        ${renderLineStats(v.lines_added, v.lines_removed)}
                        ${v.note ? '<span class="version-note">' + esc(v.note) + '</span>' : ''}
                        <div class="version-actions">
                            ${v.file_version < latest
                                ? `<button class="btn btn-primary btn-sm" onclick="event.stopPropagation();confirmRewind('${fid} v${v.file_version}',null,null,${latest})">Rewind</button>`
                                : '<span class="badge badge-current">Current</span>'}
                        </div>
                    </div>
                    ${renderSymbolTags(v.symbols) ? '<div class="version-symbols">' + renderSymbolTags(v.symbols) + '</div>' : ''}
                    <div id="diff-${v.uid}" data-note="${esc(v.note || '')}" style="display:none"></div>
                </div>`).join('')}
        </div>
        ${relatedFiles.length > 0 ? `
        <div class="related-section">
            <h3 class="related-title">Related Files</h3>
            <div class="related-list">
                ${relatedFiles.map(r => `
                    <div class="related-item" onclick="toggleFile('${r.file_id}')">
                        <span class="related-fid">${r.file_id}</span>
                        <span class="related-path">${esc(r.filepath || r.filename)}</span>
                        <span class="related-count">${r.co_sessions} shared session${r.co_sessions !== 1 ? 's' : ''}</span>
                    </div>`).join('')}
            </div>
        </div>` : ''}`;
}

async function toggleDiff(fileId, version, uid) {
    const el = document.getElementById('diff-' + uid);
    if (!el) return;
    if (el.style.display !== 'none') { el.style.display = 'none'; return; }
    el.style.display = '';
    el.innerHTML = '<div class="loading-state" style="padding:10px">Loading diff...</div>';

    const note = el.getAttribute('data-note') || '';
    const noteHtml = note ? '<div class="expand-note"><span class="expand-note-label"># Note</span>' + esc(note) + '</div>' : '';

    const d = await api.get('/api/richdiff/' + state.workspace + '/' + fileId + '/' + version);
    if (d && d.lines && d.lines.length > 0) {
        el.innerHTML = noteHtml + renderDiffView(d);
    } else {
        el.innerHTML = noteHtml + '<div class="text-muted" style="padding:10px;font-size:12px">' + esc(d && d.error ? d.error : 'No changes') + '</div>';
    }
}

function renderDiffView(d) {
    const from = d.v_from || '';
    const to = d.v_to || '';
    const hdr = '<div class="diff-header-bar">' +
        '<span class="diff-versions">' + esc(from) + ' → ' + esc(to) + '</span>' +
        '<span class="diff-stats-inline"><span class="diff-stat-add">+' + d.total_add + '</span> <span class="diff-stat-del">-' + d.total_del + '</span></span>' +
        '</div>';

    const lines = d.lines.map(l => {
        if (l.t === 'sep') return '<div class="diff-line diff-sep">···</div>';
        const prefix = l.t === 'add' ? '+' : l.t === 'del' ? '-' : ' ';
        const ln = l.ln != null ? String(l.ln).padStart(4) : '    ';
        return '<div class="diff-line diff-' + l.t + '"><span class="diff-ln">' + ln + '</span><span class="diff-text">' + esc(prefix + ' ' + l.s) + '</span></div>';
    }).join('');
    return hdr + '<div class="diff-block">' + lines + '</div>';
}

// ═══════════════════════════════════════
//  Page: Timeline
// ═══════════════════════════════════════
const TL_BATCH = 20;
const FILE_BATCH = 10;
let _tl = { offset: 0, total: 0, loading: false, observer: null, flagMap: {} };

function _sessionCardHtml(s) {
    const flag = _tl.flagMap[s.uid];
    const hasStats = s.lines_added || s.lines_removed;
    return `<div class="card session-card${flag ? ' session-flagged' : ''}" id="scard-${s.uid}">
        ${flag ? `<div class="session-flag-bar" onclick="window.location.hash='flags'"><svg class="flag-icon" width="14" height="14" viewBox="0 0 24 24"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" fill="currentColor"/><line x1="4" y1="22" x2="4" y2="15" stroke="currentColor" stroke-width="2"/></svg> ${esc(flag.version)}${flag.title ? ' - ' + esc(flag.title) : ''}</div>` : ''}
        <div class="session-item" id="sitem-${s.uid}" onclick="toggleSession(${s.uid})">
            <span class="session-id">SS${s.uid}</span>
            <span class="session-time">${fmtTime(s.created_at)}</span>
            <span class="session-files">${s.file_count} file${s.file_count !== 1 ? 's' : ''}</span>
            ${hasStats ? '<span class="line-stats"><span class="line-stat-add">+' + s.lines_added + '</span><span class="line-stat-del">-' + s.lines_removed + '</span></span>' : ''}
            ${s.is_forced ? '<span class="badge badge-warning">manual</span>' : ''}
            <span class="session-note">${esc(s.note || '')}</span>
            <button class="btn btn-primary btn-sm" style="margin-left:auto;flex-shrink:0" onclick="event.stopPropagation();confirmRewind('SS${s.uid}','Session SS${s.uid}','${esc(s.note || timeAgo(s.created_at))}')">Rewind</button>
        </div>
        <div id="sess-${s.uid}" style="display:none"></div>
    </div>`;
}

function _fileRowHtml(f) {
    const symbols = renderSymbolTags(f.symbols);
    return `<div class="file-block clickable" onclick="toggleSessionDiff('${f.file_id}',${f.file_version},${f.uid})">
        <div class="version-row">
            <span class="version-id">${f.file_id}</span>
            <span class="session-filepath">${esc(f.filepath || f.filename)}</span>
            <span class="version-v version-link" onclick="event.stopPropagation();window.location.hash='files/${f.file_id}'">v${f.file_version}</span>
            ${f.created_at ? '<span class="version-time">' + fmtTime(f.created_at) + '</span>' : ''}
            ${statusBadge(f.status)}
            ${renderLineStats(f.lines_added, f.lines_removed)}
            ${f.note ? '<span class="version-note">' + esc(f.note) + '</span>' : ''}
        </div>
        ${symbols ? '<div class="version-symbols">' + symbols + '</div>' : ''}
        <div id="sdiff-${f.uid}" data-note="${esc(f.note || '')}" class="file-diff-area" style="display:none"></div>
    </div>`;
}

function _setupTlObserver() {
    if (_tl.observer) _tl.observer.disconnect();
    const sentinel = document.getElementById('tl-sentinel');
    if (!sentinel) return;
    _tl.observer = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && !_tl.loading && _tl.offset < _tl.total) _loadMoreSessions();
    }, { rootMargin: '300px' });
    _tl.observer.observe(sentinel);
}

async function _loadMoreSessions() {
    _tl.loading = true;
    const d = await api.get('/api/sessions/' + state.workspace + '?limit=' + TL_BATCH + '&offset=' + _tl.offset);
    _tl.loading = false;
    if (!d) return;
    const sessions = d.sessions || [];
    _tl.offset += sessions.length;
    const list = document.getElementById('tl-list');
    if (list) list.insertAdjacentHTML('beforeend', sessions.map(s => _sessionCardHtml(s)).join(''));
    if (_tl.offset >= _tl.total || sessions.length === 0) {
        const sentinel = document.getElementById('tl-sentinel');
        if (sentinel) sentinel.remove();
        if (_tl.observer) { _tl.observer.disconnect(); _tl.observer = null; }
    }
}

async function renderTimeline(target) {
    const el = document.getElementById('page-content');
    el.innerHTML = skeleton('timeline');
    if (!state.workspace) { renderNoWorkspaces(); return; }
    if (_tl.observer) { _tl.observer.disconnect(); _tl.observer = null; }

    let targetUid = null;
    if (target) {
        const m = target.match(/^SS(\d+)$/i);
        if (m) targetUid = parseInt(m[1]);
    }

    const [d, flags] = await Promise.all([
        api.get('/api/sessions/' + state.workspace + '?limit=' + TL_BATCH),
        api.get('/api/flags/' + state.workspace),
    ]);
    if (!d) { el.innerHTML = '<div class="empty-state"><p>Failed to load</p></div>'; return; }

    _tl.flagMap = {};
    if (flags) flags.forEach(f => { _tl.flagMap[f.session_uid] = f; });
    _tl.total = d.total;
    _tl.offset = (d.sessions || []).length;
    _tl.loading = false;

    const sessions = d.sessions || [];
    const hasMore = _tl.offset < _tl.total;
    el.innerHTML = `
        <div class="page-header">
            <h1>Timeline</h1>
            <div style="display:flex;align-items:center;gap:12px">
                <span class="text-muted">${d.total} session${d.total !== 1 ? 's' : ''}</span>
            </div>
        </div>
        ${sessions.length === 0
            ? '<div class="empty-state"><p>No sessions yet</p></div>'
            : `<div id="tl-list">${sessions.map(s => _sessionCardHtml(s)).join('')}</div>
               ${hasMore ? '<div id="tl-sentinel" class="loading-state" style="padding:24px">Loading more...</div>' : ''}`}`;

    if (hasMore) _setupTlObserver();

    if (targetUid) {
        let card = document.getElementById('scard-' + targetUid);
        if (!card) {
            // target not in first batch, load remaining to find it
            if (_tl.observer) { _tl.observer.disconnect(); _tl.observer = null; }
            const rest = await api.get('/api/sessions/' + state.workspace + '?limit=9999&offset=' + _tl.offset);
            if (rest) {
                const more = rest.sessions || [];
                _tl.offset += more.length;
                const list = document.getElementById('tl-list');
                if (list) list.insertAdjacentHTML('beforeend', more.map(s => _sessionCardHtml(s)).join(''));
                const sentinel = document.getElementById('tl-sentinel');
                if (sentinel) sentinel.remove();
            }
            card = document.getElementById('scard-' + targetUid);
        }
        if (card) {
            await toggleSession(targetUid);
            card.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
}

async function toggleSession(uid) {
    const el = document.getElementById('sess-' + uid);
    const item = document.getElementById('sitem-' + uid);
    if (!el) return;
    if (el.style.display !== 'none') {
        el.style.display = 'none';
        if (item) item.classList.remove('active');
        history.replaceState(null, '', '#timeline');
        return;
    }
    el.style.display = '';
    if (item) item.classList.add('active');
    history.replaceState(null, '', '#timeline/SS' + uid);
    el.innerHTML = '<div class="loading-state" style="padding:14px">Loading...</div>';

    const d = await api.get('/api/sessions/' + state.workspace + '/' + uid);
    if (!d) { el.innerHTML = '<div class="text-muted" style="padding:14px">Failed</div>'; return; }

    const files = d.files || [];
    const sessNote = d.session && d.session.note ? d.session.note : '';
    const visible = files.slice(0, FILE_BATCH);
    const hidden = files.slice(FILE_BATCH);

    el.innerHTML = `
        <div style="padding:4px 20px 16px">
            ${sessNote ? '<div class="expand-note"><span class="expand-note-label"># Note</span>' + esc(sessNote) + '</div>' : ''}
            <div class="version-list" id="flist-${uid}">
                ${visible.map(f => _fileRowHtml(f)).join('')}
            </div>
            ${hidden.length > 0 ? `<button class="btn btn-secondary btn-sm mt-8" id="fmore-${uid}" onclick="expandSessionFiles(${uid})" style="width:100%">Show ${hidden.length} more file${hidden.length !== 1 ? 's' : ''}...</button>` : ''}
        </div>`;

    if (hidden.length > 0) {
        el._hiddenFiles = hidden;
    }
}

function expandSessionFiles(uid) {
    const el = document.getElementById('sess-' + uid);
    const list = document.getElementById('flist-' + uid);
    const btn = document.getElementById('fmore-' + uid);
    if (!el || !list || !el._hiddenFiles) return;
    list.insertAdjacentHTML('beforeend', el._hiddenFiles.map(f => _fileRowHtml(f)).join(''));
    if (btn) btn.remove();
    delete el._hiddenFiles;
}

async function toggleSessionDiff(fileId, version, uid) {
    const el = document.getElementById('sdiff-' + uid);
    if (!el) return;
    if (el.style.display !== 'none') { el.style.display = 'none'; return; }
    el.style.display = '';
    el.innerHTML = '<div class="loading-state" style="padding:10px">Loading diff...</div>';

    const note = el.getAttribute('data-note') || '';
    const noteHtml = note ? '<div class="expand-note"><span class="expand-note-label"># Note</span>' + esc(note) + '</div>' : '';

    const d = await api.get('/api/richdiff/' + state.workspace + '/' + fileId + '/' + version);
    if (d && d.lines && d.lines.length > 0) {
        el.innerHTML = '<div style="padding:4px 0 12px">' + noteHtml + renderDiffView(d) + '</div>';
    } else {
        el.innerHTML = '<div style="padding:4px 0 12px">' + noteHtml + '<div class="text-muted" style="padding:10px 0;font-size:12px">' + esc(d && d.error ? d.error : 'No changes') + '</div></div>';
    }
}

// ═══════════════════════════════════════
//  Page: Flags
// ═══════════════════════════════════════
async function renderFlags() {
    const el = document.getElementById('page-content');
    el.innerHTML = skeleton('flags');
    if (!state.workspace) { renderNoWorkspaces(); return; }

    const flags = await api.get('/api/flags/' + state.workspace);
    if (!flags) { el.innerHTML = '<div class="empty-state"><p>Failed to load flags</p></div>'; return; }

    el.innerHTML = `
        <div class="page-header">
            <h1>Flags</h1>
            <div class="page-header-actions">
                <button class="btn btn-ghost btn-sm" onclick="exportChangelog()" ${flags.length === 0 ? 'disabled' : ''}>Export Changelog</button>
                <button class="btn btn-secondary btn-sm" onclick="openCreateFlagModal()">+ Create Flag</button>
            </div>
        </div>
        ${flags.length === 0
            ? `<div class="empty-state">
                <h2>No flags yet</h2>
                <p class="text-muted" style="margin-top:8px">Flags mark important snapshots with version labels.</p>
                <p class="text-muted" style="margin-top:4px">Use <code>rewindex flag create</code> or click the button above.</p>
            </div>`
            : `<div class="flag-grid">${flags.map(f => renderFlagCard(f)).join('')}</div>`}`;
}

function renderFlagCard(f) {
    const version = f.version || '';
    const title = f.title || '';
    const desc = f.description || '';
    const hasDesc = desc.length > 0;
    const descHtml = `<div class="flag-desc-wrap" id="flag-desc-${f.uid}">
           ${hasDesc
               ? '<div class="flag-desc">' + (typeof marked !== 'undefined' ? marked.parse(desc) : esc(desc)) + '</div>'
               : '<div class="flag-desc flag-desc-empty">No description</div>'}
       </div>`;
    return `
        <div class="flag-card has-desc" id="flag-${f.uid}">
            <div class="flag-card-header" onclick="toggleFlagDesc(event, ${f.uid})">
                <span class="flag-version">${esc(version)}</span>
                <span class="flag-title">${esc(title)}</span>
                <svg class="flag-chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                <span class="flag-session-badge" onclick="event.stopPropagation(); viewFlagSession(${f.session_uid})" title="View Session SS${f.session_uid}">SS${f.session_uid}</span>
            </div>
            ${descHtml}
            <div class="flag-card-footer">
                <span class="text-muted" style="font-size:12px">${fmtTime(f.created_at)}</span>
                <div class="flag-actions">
                    <button class="btn btn-ghost btn-sm flag-collapse-btn" onclick="toggleFlagDesc(event, ${f.uid})"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="18 15 12 9 6 15"/></svg> Collapse</button>
                    <button class="btn btn-outline btn-sm" onclick="viewFlagSession(${f.session_uid})">View Session</button>
                    <button class="btn btn-danger btn-sm" onclick="confirmDeleteFlag(${f.uid},'${esc(version)}')">Delete</button>
                </div>
            </div>
        </div>`;
}

function toggleFlagDesc(e, uid) {
    if (e.target.closest('.flag-session-badge')) return;
    const card = document.getElementById('flag-' + uid);
    if (!card) return;
    const wasExpanded = card.classList.contains('expanded');
    card.classList.toggle('expanded');
    if (wasExpanded) {
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

function exportChangelog() {
    if (!state.workspace) return;
    const branding = localStorage.getItem('changelog_branding') !== '0';
    const a = document.createElement('a');
    a.href = '/api/flags/export/' + encodeURIComponent(state.workspace) + (branding ? '' : '?branding=0');
    a.download = 'CHANGELOG.md';
    a.click();
}

function openCreateFlagModal() {
    openModal(
        'Create Flag',
        `<div class="form-group">
            <label class="form-label">Session ID (number)</label>
            <input type="number" id="flag-session" class="form-input" placeholder="e.g. 5">
        </div>
        <div class="form-group">
            <label class="form-label">Version</label>
            <input type="text" id="flag-version" class="form-input" placeholder="e.g. 1.0.0">
        </div>
        <div class="form-group">
            <label class="form-label">Title</label>
            <input type="text" id="flag-title" class="form-input" placeholder="Release title">
        </div>
        <div class="form-group">
            <label class="form-label">Description (optional)</label>
            <textarea id="flag-description" class="form-input" rows="3" placeholder="What changed..."></textarea>
        </div>`,
        '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button>' +
        '<button class="btn btn-primary" onclick="createFlag()">Create</button>'
    );
}

async function createFlag() {
    const sessionUid = document.getElementById('flag-session').value.trim();
    const version = document.getElementById('flag-version').value.trim();
    const title = document.getElementById('flag-title').value.trim();
    const description = document.getElementById('flag-description').value.trim();

    if (!sessionUid || !version || !title) {
        showToast('Session, version, and title are required', 'error');
        return;
    }

    const r = await api.post('/api/flags', {
        workspace: state.workspace,
        session_uid: parseInt(sessionUid),
        version: version,
        title: title,
        description: description,
    });

    if (r && r.code === 0) {
        closeModal();
        showToast('Flag created', 'success');
        renderFlags();
    } else {
        showToast(r ? (r.error || r.output || 'Failed') : 'Failed', 'error');
    }
}

function confirmDeleteFlag(uid, version) {
    openModal(
        'Delete Flag',
        '<p>Delete flag <strong>' + esc(version) + '</strong>?</p>' +
        '<p class="text-muted mt-8" style="font-size:12px">This removes the version label. Snapshots are not affected.</p>',
        '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button>' +
        '<button class="btn btn-danger" onclick="deleteFlag(\'' + esc(version) + '\')">Delete</button>'
    );
}

async function deleteFlag(version) {
    const r = await api.del('/api/flags/' + encodeURIComponent(version), { workspace: state.workspace });
    if (r && r.code === 0) {
        closeModal();
        showToast('Flag deleted', 'success');
        renderFlags();
    } else {
        showToast(r ? (r.error || r.output || 'Failed') : 'Failed', 'error');
    }
}

function viewFlagSession(sessionUid) {
    window.location.hash = 'timeline/SS' + sessionUid;
}

// ═══════════════════════════════════════
//  Page: Workspaces
// ═══════════════════════════════════════
async function renderWorkspaces() {
    const el = document.getElementById('page-content');
    el.innerHTML = skeleton('workspaces');

    const [workspaces, config] = await Promise.all([
        api.get('/api/workspaces'),
        api.get('/api/config'),
    ]);
    if (!workspaces) { el.innerHTML = '<div class="empty-state"><p>Failed</p></div>'; return; }

    _wsCache = workspaces;
    const wsSort = localStorage.getItem('rewindex-ws-sort') || 'last_edit';
    const wsDir = localStorage.getItem('rewindex-ws-dir') || 'desc';
    el.innerHTML = `
        <div class="page-header">
            <h1>Workspaces</h1>
            <div class="page-header-actions">
                <select id="ws-sort" class="project-select" onchange="sortWorkspaces(this.value)">
                    <option value="last_edit"${wsSort === 'last_edit' ? ' selected' : ''}>Last edited</option>
                    <option value="created"${wsSort === 'created' ? ' selected' : ''}>Date added</option>
                    <option value="name"${wsSort === 'name' ? ' selected' : ''}>Name</option>
                </select>
                <button id="ws-dir-btn" class="sort-dir-btn" onclick="toggleWsDir()" title="${wsDir === 'desc' ? 'Newest first' : 'Oldest first'}">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        ${wsDir === 'desc' ? '<polyline points="6 9 12 3 18 9"/><line x1="12" y1="3" x2="12" y2="21"/>' : '<polyline points="6 15 12 21 18 15"/><line x1="12" y1="21" x2="12" y2="3"/>'}
                    </svg>
                </button>
                <button class="btn btn-success btn-sm" onclick="openAddWorkspaceModal()">+ Add Workspace</button>
            </div>
        </div>
        <input type="text" class="form-input search-input" placeholder="Search workspaces..." id="ws-search" oninput="filterWorkspaces()">
        <div id="ws-list"></div>`;
    filterWorkspaces();
}

let _wsCache = [];

function sortWorkspaces(val) {
    localStorage.setItem('rewindex-ws-sort', val);
    filterWorkspaces();
}

function toggleWsDir() {
    const cur = localStorage.getItem('rewindex-ws-dir') || 'desc';
    const next = cur === 'desc' ? 'asc' : 'desc';
    localStorage.setItem('rewindex-ws-dir', next);
    const btn = document.getElementById('ws-dir-btn');
    if (btn) {
        btn.innerHTML = next === 'desc'
            ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 3 18 9"/><line x1="12" y1="3" x2="12" y2="21"/></svg>'
            : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 15 12 21 18 15"/><line x1="12" y1="21" x2="12" y2="3"/></svg>';
        btn.title = next === 'desc' ? 'Newest first' : 'Oldest first';
    }
    filterWorkspaces();
}

function _sortedWorkspaces(list) {
    const mode = localStorage.getItem('rewindex-ws-sort') || 'last_edit';
    const dir = localStorage.getItem('rewindex-ws-dir') || 'desc';
    const mul = dir === 'desc' ? 1 : -1;
    const sorted = [...list];
    sorted.sort((a, b) => {
        if (mode === 'name') return a.name.localeCompare(b.name) * mul;
        if (mode === 'created') return (b.created_at || '').localeCompare(a.created_at || '') * mul;
        return (b.last_session || '').localeCompare(a.last_session || '') * mul;
    });
    return sorted;
}

function filterWorkspaces() {
    const el = document.getElementById('ws-list');
    if (!el || !_wsCache) return;
    const q = (document.getElementById('ws-search')?.value || '').toLowerCase();
    const filtered = _sortedWorkspaces(q ? _wsCache.filter(p => p.name.toLowerCase().includes(q) || (p.folders || []).some(f => f.toLowerCase().includes(q))) : _wsCache);
    el.innerHTML = filtered.length === 0
        ? '<div class="empty-state"><p>No workspaces found</p></div>'
        : filtered.map(p => {
            const active = p.name === state.workspace;
            const wsId = 'ws-det-' + p.name.replace(/[^a-zA-Z0-9]/g, '_');
            return `
            <div class="card ws-card${active ? ' ws-active' : ''}" style="margin-bottom:14px">
                <div class="ws-row">
                    <div class="ws-summary clickable" onclick="selectWorkspace('${esc(p.name)}')">
                        <div class="ws-summary-left">
                            <h2 class="ws-name">${esc(p.name)}</h2>
                            ${active ? '<span class="badge badge-success">Selected</span>' : ''}
                        </div>
                        <div class="ws-stats">
                            <span class="ws-stat">${p.total_files} files</span>
                            <span class="ws-stat">${p.total_snapshots} snaps</span>
                            <span class="ws-stat">${p.last_session ? timeAgo(p.last_session) : 'no activity'}</span>
                        </div>
                    </div>
                    <div class="ws-expand-strip clickable" onclick="toggleWsDetail('${wsId}')" title="Details">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </div>
                </div>
                <div class="ws-detail" id="${wsId}" style="display:none">
                    <div class="info-grid">
                        <span class="info-label">Folders</span>
                        <span class="info-value">${p.folders.map(f => '<code>' + esc(f) + '</code>').join('<br>') || '—'}</span>
                        <span class="info-label">Excludes</span>
                        <span class="info-value">${p.exclude && p.exclude.length ? p.exclude.map(e => '<code>' + esc(e) + '</code>').join(', ') : '—'}</span>
                        <span class="info-label">DB Size</span>
                        <span class="info-value">${p.db_size || '—'}</span>
                        <span class="info-label">Added</span>
                        <span class="info-value">${p.created_at ? timeAgo(p.created_at) : '—'}</span>
                    </div>
                </div>
            </div>`;
        }).join('');
}

function openAddWorkspaceModal() {
    openModal(
        'Add Workspace',
        `<div class="form-group">
            <label class="form-label">Workspace Name</label>
            <input type="text" id="ws-name" class="form-input" placeholder="e.g. my-project">
        </div>
        <div class="form-group">
            <label class="form-label">Folder Path</label>
            <input type="text" id="ws-folder" class="form-input" placeholder="e.g. /home/user/my-project">
        </div>`,
        '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button>' +
        '<button class="btn btn-primary" onclick="createWorkspace()">Create</button>'
    );
}

async function createWorkspace() {
    const name = document.getElementById('ws-name').value.trim();
    const folder = document.getElementById('ws-folder').value.trim();
    if (!name || !folder) { showToast('Name and folder are required', 'error'); return; }
    const r = await api.post('/api/workspace/setup', { name, folder });
    if (r && r.code === 0) {
        closeModal();
        showToast('Workspace created', 'success');
        await loadWorkspaces();
        renderWorkspaces();
    } else {
        showToast(r?.error || 'Failed to create workspace', 'error');
    }
}

function toggleWsDetail(id) {
    const el = document.getElementById(id);
    if (!el) return;
    const open = el.style.display === 'none';
    el.style.display = open ? '' : 'none';
    const card = el.closest('.ws-card');
    if (card) card.classList.toggle('ws-expanded', open);
}

function selectWorkspace(name) {
    if (state.workspace === name) return;
    state.workspace = name;
    localStorage.setItem('rewindex-workspace', name);
    const sel = document.getElementById('project-select');
    if (sel) sel.value = name;
    router();
}

// ═══════════════════════════════════════
//  Page: Settings
// ═══════════════════════════════════════
async function renderSettings() {
    const el = document.getElementById('page-content');
    el.innerHTML = skeleton('settings');

    const [config, status, license] = await Promise.all([
        api.get('/api/config'),
        api.get('/api/status'),
        api.get('/api/license'),
    ]);
    if (!config) { el.innerHTML = '<div class="empty-state"><p>Failed</p></div>'; return; }
    const isPro = license && license.output && /pro|active/i.test(license.output);

    el.innerHTML = `
        <div class="page-header"><h1>Settings</h1></div>
        <div class="card mb-16">
            <div class="card-header"><h2>Daemon</h2></div>
            <div class="card-body">
                <div class="info-grid mb-16">
                    <span class="info-label">Status</span>
                    <span class="info-value">
                        <span class="daemon-dot ${status && status.running ? '' : 'offline'}" style="display:inline-block;vertical-align:middle;margin-right:6px"></span>
                        ${status && status.running ? 'Running (PID ' + status.pid + ')' : 'Stopped'}
                    </span>
                </div>
                <div class="flex gap-8">
                    <button class="btn btn-secondary btn-sm" onclick="daemonAction('start')">Start</button>
                    <button class="btn btn-secondary btn-sm" onclick="daemonAction('stop')">Stop</button>
                    <button class="btn btn-secondary btn-sm" onclick="daemonAction('restart')">Restart</button>
                </div>
            </div>
        </div>
        <div class="card mb-16">
            <div class="card-header"><h2>Session</h2></div>
            <div class="card-body">
                <div class="info-grid">
                    <span class="info-label">Gap (seconds)</span>
                    <span class="info-value">${config.session_gap_seconds != null ? config.session_gap_seconds : 20}</span>
                    <span class="info-label">Safe limit</span>
                    <span class="info-value">${config.session_safe != null ? config.session_safe : 500}</span>
                    <span class="info-label">Max limit</span>
                    <span class="info-value">${config.session_max != null ? config.session_max : 600}</span>
                </div>
            </div>
        </div>
        ${config.global_exclude && config.global_exclude.length ? `
        <div class="card mb-16">
            <div class="card-header"><h2>Global Excludes</h2></div>
            <div class="card-body">
                <div style="display:flex;flex-wrap:wrap;gap:8px">
                    ${config.global_exclude.map(e => '<code class="badge badge-default">' + esc(e) + '</code>').join('')}
                </div>
            </div>
        </div>` : ''}
        <div class="card mb-16">
            <div class="card-header"><h2>Export</h2></div>
            <div class="card-body">
                <div class="setting-row">
                    <div>
                        <span class="info-label">Changelog branding</span>
                        <p class="text-muted" style="font-size:12px;margin-top:2px">Show "Powered by Rewindex" footer in exported changelog.${isPro ? '' : ' Upgrade to Pro to disable.'}</p>
                    </div>
                    <label class="toggle-switch">
                        <input type="checkbox" id="branding-toggle" ${isPro && localStorage.getItem('changelog_branding') === '0' ? '' : 'checked'} ${isPro ? '' : 'disabled'} onchange="localStorage.setItem('changelog_branding', this.checked ? '1' : '0')">
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h2>Config File</h2></div>
            <div class="card-body">
                <pre class="code-block">${esc(JSON.stringify(config, null, 2))}</pre>
                <p class="text-muted mt-8" style="font-size:12px">~/.rewindex/.rewindex.config.yaml</p>
            </div>
        </div>`;
}

// ═══════════════════════════════════════
//  Page: License
// ═══════════════════════════════════════
async function renderLicense() {
    const el = document.getElementById('page-content');
    el.innerHTML = skeleton('license');

    const d = await api.get('/api/license');

    el.innerHTML = `
        <div class="page-header"><h1>License</h1></div>
        <div class="card mb-16">
            <div class="card-header"><h2>Current Plan</h2></div>
            <div class="card-body">
                ${d && d.output ? '<pre class="code-block">' + esc(d.output) + '</pre>' : '<p class="text-muted">Could not retrieve license info</p>'}
                ${d && d.error ? '<p class="text-muted mt-8" style="font-size:12px">' + esc(d.error) + '</p>' : ''}
            </div>
        </div>
        <div class="card mb-16">
            <div class="card-header"><h2>Activate License</h2></div>
            <div class="card-body">
                <div class="form-group">
                    <label class="form-label">License Key</label>
                    <input type="text" class="form-input" id="license-key" placeholder="Enter your license key...">
                </div>
                <button class="btn btn-primary" onclick="activateLicense()">Activate</button>
                <div id="license-result" class="mt-8"></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h2>Plans</h2></div>
            <div class="card-body">
                <p class="text-muted" style="font-size:13px">See all features and pricing at the official website.</p>
                <a href="https://rewindex.web.app" target="_blank" rel="noopener" class="btn btn-secondary mt-8" style="display:inline-flex;align-items:center;gap:6px">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M15 3h6v6M10 14L21 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    rewindex.web.app
                </a>
            </div>
        </div>`;
}

// ═══════════════════════════════════════
//  Actions
// ═══════════════════════════════════════
async function confirmRewind(target, label, detail, latestFileVer) {
    const sessData = await api.get('/api/sessions/' + state.workspace + '?limit=1');
    const nextSS = sessData && sessData.sessions[0] ? sessData.sessions[0].uid + 1 : '?';
    const isFile = latestFileVer != null;
    const saveLabel = isFile ? 'v' + (latestFileVer + 1) + ' (SS' + nextSS + ')' : 'SS' + nextSS;
    openModal(
        'Confirm Rewind',
        '<div class="rewind-warning">' +
            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' +
            '<span>This action will modify your files. A backup snapshot will be created automatically.</span>' +
        '</div>' +
        '<p style="margin:12px 0">Rewind back to <strong>' + esc(target) + '</strong></p>' +
        '<p class="text-muted" style="font-size:13px">Will be saved as <strong>' + saveLabel + '</strong></p>' +
        '<input type="text" id="rewind-note" class="form-input mt-8" placeholder="Note to SS' + nextSS + ' (optional)" style="width:100%">',
        '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button>' +
        '<button class="btn btn-danger" id="rewind-go" onclick="execRewind(\'' + target.replace(/'/g, "\\'") + '\')">Rewind</button>'
    );
}

async function execRewind(target) {
    const footer = document.getElementById('modal-footer');
    const noteEl = document.getElementById('rewind-note');
    const note = noteEl ? noteEl.value.trim() : '';
    footer.innerHTML = '<span class="text-muted">Rewinding...</span>';

    const r = await api.post('/api/rewind', { workspace: state.workspace, target: target });

    if (r && r.code === 0) {
        if (note) {
            const sessData = await api.get('/api/sessions/' + state.workspace + '?limit=1');
            const latestUid = sessData && sessData.sessions[0] ? sessData.sessions[0].uid : null;
            if (latestUid) await api.post('/api/note', { workspace: state.workspace, target: 'SS' + latestUid, message: note });
        }

        const flash = document.createElement('div');
        flash.className = 'rewind-flash';
        document.body.appendChild(flash);
        setTimeout(() => flash.remove(), 500);

        closeModal();
        showToast('Rewind successful', 'success');

        const fresh = await api.get('/api/workspaces');
        if (fresh) state.workspaces = fresh;
        router();
    } else {
        document.getElementById('modal-body').innerHTML +=
            '<div class="mt-8" style="color:var(--danger);font-size:13px">' +
            esc(r ? (r.error || r.output || 'Failed') : 'Failed') + '</div>';
        footer.innerHTML = '<button class="btn btn-secondary" onclick="closeModal()">Close</button>';
    }
}

async function doSnap() {
    const r = await api.post('/api/snap', { workspace: state.workspace });
    if (r && r.code === 0) {
        showToast('Snapshot created', 'success');
        const fresh = await api.get('/api/workspaces');
        if (fresh) state.workspaces = fresh;
        router();
    } else {
        showToast(r ? (r.error || r.output || 'Failed') : 'Failed', 'error');
    }
}

async function activateLicense() {
    const key = document.getElementById('license-key').value.trim();
    if (!key) { showToast('Enter a license key', 'error'); return; }

    const el = document.getElementById('license-result');
    el.innerHTML = '<span class="text-muted">Activating...</span>';

    const r = await api.post('/api/license/activate', { key: key });
    if (r && r.code === 0) {
        el.innerHTML = '<span style="color:var(--success)">' + esc(r.output) + '</span>';
        showToast('License activated', 'success');
    } else {
        el.innerHTML = '<span style="color:var(--danger)">' + esc(r ? (r.error || r.output || 'Failed') : 'Failed') + '</span>';
    }
}

// ═══════════════════════════════════════
//  Page: Updates
// ═══════════════════════════════════════
const PKG_LABELS  = { 'rewindex': 'rewindex' };
const PKG_GITHUB  = { 'rewindex': 'https://github.com/crsxmd/rewindex' };
const GH_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.477 2 2 6.477 2 12c0 4.418 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.009-.868-.014-1.703-2.782.604-3.369-1.341-3.369-1.341-.454-1.155-1.11-1.463-1.11-1.463-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.564 9.564 0 0112 6.844a9.59 9.59 0 012.504.337c1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.579.688.481C19.138 20.163 22 16.418 22 12c0-5.523-4.477-10-10-10z"/></svg>`;

async function renderUpdate() {
    const el = document.getElementById('page-content');
    el.innerHTML = `
        <div class="page-header"><h1>Updates</h1></div>
        <div class="update-grid" id="update-cards">
            ${['rewindex'].map(pkg => `
            <div class="update-card" id="ucard-${pkg.replace('-','_')}">
                <div class="update-card-header">
                    <a href="${PKG_GITHUB[pkg]}" target="_blank" rel="noopener" class="gh-link" title="View on GitHub">${GH_ICON}</a>
                    <span class="update-pkg-name">${PKG_LABELS[pkg]}</span>
                    <span class="update-status-badge badge-check">Checking...</span>
                </div>
                <div class="update-versions">
                    <div><div class="update-ver-label">Installed</div><div class="update-ver-value">—</div></div>
                    <div><div class="update-ver-label">Latest</div><div class="update-ver-value">—</div></div>
                </div>
                <button class="btn btn-secondary btn-sm" disabled>Update</button>
            </div>`).join('')}
        </div>
        <pre id="update-log" class="code-block" style="display:none;max-height:200px;overflow-y:auto;margin-top:0"></pre>`;

    const data = await api.get('/api/version-check');

    if (!data) {
        document.getElementById('update-cards').innerHTML = `
            <div class="update-offline-msg">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0119 12.55M5 12.55a10.94 10.94 0 015.17-2.39M10.71 5.05A16 16 0 0122.56 9M1.42 9a15.91 15.91 0 014.7-2.88M8.53 16.11a6 6 0 016.95 0M12 20h.01" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                Could not connect to check for updates.
            </div>`;
        return;
    }

    if (!data.online) {
        const offlineMsg = `
            <div class="update-offline-msg">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0119 12.55M5 12.55a10.94 10.94 0 015.17-2.39M10.71 5.05A16 16 0 0122.56 9M1.42 9a15.91 15.91 0 014.7-2.88M8.53 16.11a6 6 0 016.95 0M12 20h.01" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                Connect to internet to check for new versions
            </div>`;
        document.getElementById('update-cards').insertAdjacentHTML('beforebegin', offlineMsg);
    }

    let hasUpdates = false;
    for (const [pkg, info] of Object.entries(data.packages)) {
        const cardId = 'ucard-' + pkg.replace('-', '_');
        const card = document.getElementById(cardId);
        if (!card) continue;

        const latestAvailable = info.latest !== null;
        const upToDate = info.up_to_date;
        if (!upToDate && latestAvailable) hasUpdates = true;

        const badge = upToDate
            ? '<span class="update-status-badge badge-ok">Up to date</span>'
            : (latestAvailable
                ? `<span class="update-status-badge badge-new">Update available</span>`
                : '<span class="update-status-badge badge-check">Unknown</span>');

        const latestClass = (!upToDate && latestAvailable) ? ' is-new' : '';

        card.innerHTML = `
            <div class="update-card-header">
                <a href="${PKG_GITHUB[pkg]}" target="_blank" rel="noopener" class="gh-link" title="View on GitHub">${GH_ICON}</a>
                <span class="update-pkg-name">${PKG_LABELS[pkg]}</span>
                ${badge}
            </div>
            <div class="update-versions">
                <div>
                    <div class="update-ver-label">Installed</div>
                    <div class="update-ver-value">${esc(info.installed)}</div>
                </div>
                <div>
                    <div class="update-ver-label">Latest</div>
                    <div class="update-ver-value${latestClass}">${info.latest ? esc(info.latest) : '—'}</div>
                </div>
            </div>
            <button class="btn btn-primary btn-sm" ${upToDate || !latestAvailable ? 'disabled' : ''}
                onclick="runUpdate('${pkg}')">
                ${upToDate ? 'Up to date' : 'Update'}
            </button>`;
    }

    const badge = document.getElementById('update-badge');
    if (badge) badge.classList.toggle('hidden', !hasUpdates);
}

async function runUpdate(pkg) {
    const log = document.getElementById('update-log');
    log.style.display = 'block';
    log.textContent = 'Updating ' + pkg + '...\n';
    const r = await api.post('/api/update', { package: pkg });
    log.textContent = r ? (r.output || r.error || 'Done') : 'Failed';
    if (r && r.code === 0) {
        showToast(pkg + ' updated', 'success');
        renderUpdate();
    }
}

async function daemonAction(action) {
    const r = await api.post('/api/daemon/' + action);
    if (r && r.code === 0) {
        showToast('Daemon ' + action + ' OK', 'success');
        setTimeout(refreshDaemon, 1000);
        setTimeout(renderSettings, 1500);
    } else {
        showToast(r ? (r.error || r.output || 'Failed') : 'Failed', 'error');
    }
}

// ── SSE Live updates ──
let _sseRetryDelay = 1000;
let _sseRetryTimer = null;

function startSSE() {
    if (eventSource) { eventSource.close(); eventSource = null; }
    if (_sseRetryTimer) { clearTimeout(_sseRetryTimer); _sseRetryTimer = null; }
    eventSource = new EventSource('/api/stream');
    eventSource.onmessage = async (e) => {
        _sseRetryDelay = 1000;
        try {
            const ev = JSON.parse(e.data);
            if (ev.event === 'snap' || ev.event === 'rewind' || ev.event === 'workspace_change' || ev.event === 'note') {
                const workspaces = await api.get('/api/workspaces');
                if (workspaces) state.workspaces = workspaces;
                silentRefresh();
            }
        } catch {}
    };
    eventSource.onopen = () => { _sseRetryDelay = 1000; };
    eventSource.onerror = () => {
        if (eventSource) { eventSource.close(); eventSource = null; }
        _sseRetryTimer = setTimeout(() => {
            _sseRetryDelay = Math.min(_sseRetryDelay * 2, 30000);
            startSSE();
        }, _sseRetryDelay);
    };
}

function showUpdateBar() {
    if (document.getElementById('update-bar')) return;
    const bar = document.createElement('div');
    bar.id = 'update-bar';
    bar.className = 'update-bar';
    bar.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg> New update';
    bar.onclick = async () => {
        bar.remove();
        const main = document.getElementById('main');
        main.scrollTo({ top: 0, behavior: 'smooth' });
        await new Promise(r => {
            const fb = setTimeout(r, 400);
            main.addEventListener('scrollend', () => { clearTimeout(fb); r(); }, { once: true });
        });
        await router();
        main.scrollTop = 0;
        highlightNewest();
    };
    document.body.appendChild(bar);
}

function highlightNewest() {
    const card = document.querySelector('.session-card');
    if (!card) return;
    card.classList.add('highlight-flash');
    card.addEventListener('animationend', () => card.classList.remove('highlight-flash'), { once: true });
}

function isScrollLocked() {
    return localStorage.getItem('rewindex-scroll-lock') === 'on';
}

function toggleScrollLock() {
    const locked = !isScrollLocked();
    localStorage.setItem('rewindex-scroll-lock', locked ? 'on' : 'off');
    updateScrollLockUI();
    if (!locked) {
        const bar = document.getElementById('update-bar');
        if (bar) { bar.remove(); router(); }
    }
}

function updateScrollLockUI() {
    const btn = document.getElementById('scroll-lock-btn');
    if (!btn) return;
    const locked = isScrollLocked();
    btn.classList.toggle('unlocked', !locked);
    document.getElementById('scroll-lock-icon').innerHTML = locked
        ? '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/>'
        : '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 015-5 5 5 0 015 5"/>';
    btn.title = locked ? 'Locked: click to update manually' : 'Unlocked: auto-refresh';
}

function silentRefresh() {
    refreshDaemon();
    const skip = ['settings', 'license', 'update'];
    if (skip.includes(state.page)) return;
    const lockPages = ['files', 'flags', 'workspaces'];
    if (lockPages.includes(state.page) && isScrollLocked()) {
        showUpdateBar();
    } else {
        router().then(() => {
            if (state.page === 'timeline' || state.page === 'overview') {
                document.getElementById('main').scrollTop = 0;
                highlightNewest();
            }
        });
    }
}

// ── Theme ──
function toggleTheme() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const next = isDark ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('rewindex-theme', next);
    document.getElementById('theme-label').textContent = next === 'dark' ? 'Light mode' : 'Dark mode';
}

function loadTheme() {
    const saved = localStorage.getItem('rewindex-theme');
    const theme = saved || 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    const label = document.getElementById('theme-label');
    if (label) label.textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
}

// ── Timezone ──
function loadTimezone() {
    const sel = document.getElementById('tz-select');
    if (!sel) return;
    const offsets = [
        { label: 'Auto (machine)', value: 'auto' },
        { label: 'UTC-12', value: 'UTC-12' },
        { label: 'UTC-11', value: 'UTC-11' },
        { label: 'UTC-10', value: 'UTC-10' },
        { label: 'UTC-9',  value: 'UTC-9'  },
        { label: 'UTC-8',  value: 'UTC-8'  },
        { label: 'UTC-7',  value: 'UTC-7'  },
        { label: 'UTC-6',  value: 'UTC-6'  },
        { label: 'UTC-5',  value: 'UTC-5'  },
        { label: 'UTC-4',  value: 'UTC-4'  },
        { label: 'UTC-3',  value: 'UTC-3'  },
        { label: 'UTC-2',  value: 'UTC-2'  },
        { label: 'UTC-1',  value: 'UTC-1'  },
        { label: 'UTC+0',  value: 'UTC+0'  },
        { label: 'UTC+1',  value: 'UTC+1'  },
        { label: 'UTC+2',  value: 'UTC+2'  },
        { label: 'UTC+3',  value: 'UTC+3'  },
        { label: 'UTC+4',  value: 'UTC+4'  },
        { label: 'UTC+5',  value: 'UTC+5'  },
        { label: 'UTC+5:30', value: 'UTC+5:30' },
        { label: 'UTC+6',  value: 'UTC+6'  },
        { label: 'UTC+7',  value: 'UTC+7'  },
        { label: 'UTC+8',  value: 'UTC+8'  },
        { label: 'UTC+9',  value: 'UTC+9'  },
        { label: 'UTC+10', value: 'UTC+10' },
        { label: 'UTC+11', value: 'UTC+11' },
        { label: 'UTC+12', value: 'UTC+12' },
    ];
    const current = localStorage.getItem('rewindex-tz') || 'auto';
    sel.innerHTML = offsets.map(o =>
        `<option value="${o.value}"${o.value === current ? ' selected' : ''}>${o.label}</option>`
    ).join('');
}

// ── Boot ──
loadTheme();
window.addEventListener('hashchange', router);
window.addEventListener('DOMContentLoaded', () => { loadTimezone(); init(); });
