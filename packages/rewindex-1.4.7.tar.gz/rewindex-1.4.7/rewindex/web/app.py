#!/usr/bin/env python3
"""Rewindex Dashboard — lightweight local web UI.

HTTP routing only. All data access goes through data.py.
No sqlite3 import here — ever.
"""

import os
import time
import socket
from pathlib import Path
from flask import Flask, render_template, jsonify, request, Response, stream_with_context
from rewindex.web import data

PORT = int(os.getenv("REWINDEX_WEB_PORT", 9009))

EVENTS_FILE = Path.home() / ".rewindex" / "events.jsonl"

app = Flask(__name__, template_folder="templates", static_folder="static")


@app.route("/")
def index():
    return render_template("index.html")


# ── Read endpoints ──

@app.route("/api/projects")
@app.route("/api/workspaces")
def api_workspaces():
    return jsonify(data.discover_workspaces())


@app.route("/api/sessions/<workspace>")
def api_sessions(workspace):
    limit = request.args.get("limit", 50, type=int)
    offset = request.args.get("offset", 0, type=int)
    return jsonify(data.get_sessions(workspace, limit, offset))


@app.route("/api/sessions/<workspace>/<int:uid>")
def api_session_detail(workspace, uid):
    result = data.get_session_detail(workspace, uid)
    if not result:
        return jsonify({"error": "Session not found"}), 404
    return jsonify(result)


@app.route("/api/files/<workspace>")
def api_files(workspace):
    limit = request.args.get("limit", 0, type=int)
    offset = request.args.get("offset", 0, type=int)
    return jsonify(data.get_files(workspace, limit, offset))


@app.route("/api/files/<workspace>/<file_id>")
def api_file_detail(workspace, file_id):
    result = data.get_file_detail(workspace, file_id)
    if not result:
        return jsonify({"error": "File not found"}), 404
    return jsonify(result)


@app.route("/api/diff/<workspace>/<file_id>")
def api_diff(workspace, file_id):
    v_from = request.args.get("vfrom")
    v_to = request.args.get("vto")
    return jsonify(data.get_diff(workspace, file_id, v_from, v_to))


@app.route("/api/richdiff/<workspace>/<file_id>/<int:version>")
def api_rich_diff(workspace, file_id, version):
    result = data.get_rich_diff(workspace, file_id, version)
    if not result:
        return jsonify({"error": "Could not generate diff"}), 404
    return jsonify(result)


@app.route("/api/status")
def api_status():
    return jsonify(data.get_daemon_status())


@app.route("/api/config")
def api_config():
    return jsonify(data.get_config())


@app.route("/api/config", methods=["PUT"])
def api_config_update():
    body = request.json or {}
    allowed = {"session_gap_seconds", "session_safe", "session_max",
               "precompute_enabled", "flag"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        return jsonify({"error": "No valid fields"}), 400
    result = data.update_config(updates)
    if result.get("error"):
        return jsonify(result), 400
    return jsonify(result)


@app.route("/api/license")
def api_license():
    return jsonify(data.get_license_info())


# ── Flag endpoints ──

@app.route("/api/flags/<workspace>")
def api_flags(workspace):
    return jsonify(data.get_flags(workspace))


@app.route("/api/flags/<workspace>/<int:uid>")
def api_flag_detail(workspace, uid):
    result = data.get_flag_detail(workspace, uid)
    if not result:
        return jsonify({"error": "Flag not found"}), 404
    return jsonify(result)


@app.route("/api/flags/export/<workspace>")
def api_export_flags(workspace):
    branding = request.args.get("branding", "1") != "0"
    md = data.export_flags_md(workspace, branding=branding)
    return Response(md, mimetype="text/markdown",
                    headers={"Content-Disposition": f"attachment; filename=CHANGELOG.md"})


@app.route("/api/flags", methods=["POST"])
def api_create_flag():
    body = request.json or {}
    workspace = body.get("workspace")
    session_uid = body.get("session_uid")
    version = body.get("version", "")
    title = body.get("title", "")
    description = body.get("description", "")
    if not workspace or not session_uid:
        return jsonify({"error": "Missing workspace or session_uid"}), 400
    return jsonify(data.create_flag_api(workspace, session_uid, version, title, description))


@app.route("/api/flags/<path:version>", methods=["DELETE"])
def api_delete_flag(version):
    body = request.json or {}
    workspace = body.get("workspace")
    if not workspace:
        return jsonify({"error": "Missing workspace"}), 400
    return jsonify(data.delete_flag_api(workspace, version))


# ── Related files ──

@app.route("/api/related/<workspace>/<file_id>")
def api_related(workspace, file_id):
    return jsonify(data.get_related_files(workspace, file_id))


# ── Write / action endpoints ──

@app.route("/api/rewind", methods=["POST"])
def api_rewind():
    body = request.json or {}
    workspace = body.get("workspace")
    target = body.get("target")
    if not workspace or not target:
        return jsonify({"error": "Missing workspace or target"}), 400
    return jsonify(data.execute_rewind(workspace, target))


@app.route("/api/workspace/setup", methods=["POST"])
def api_setup_workspace():
    body = request.json or {}
    name = body.get("name", "")
    folder = body.get("folder", "")
    if not name or not folder:
        return jsonify({"error": "Missing name or folder"}), 400
    return jsonify(data.setup_workspace(name, folder))


@app.route("/api/snap", methods=["POST"])
def api_snap():
    body = request.json or {}
    workspace = body.get("workspace")
    message = body.get("message", "")
    if not workspace:
        return jsonify({"error": "Missing workspace"}), 400
    return jsonify(data.execute_snap(workspace, message))


@app.route("/api/note", methods=["POST"])
def api_note():
    body = request.json or {}
    workspace = body.get("workspace")
    target = body.get("target")
    message = body.get("message", "")
    if not workspace or not target:
        return jsonify({"error": "Missing workspace or target"}), 400
    return jsonify(data.execute_note(workspace, target, message))


@app.route("/api/license/activate", methods=["POST"])
def api_activate():
    body = request.json or {}
    key = body.get("key", "")
    if not key:
        return jsonify({"error": "Missing license key"}), 400
    return jsonify(data.activate_license(key))


@app.route("/api/daemon/<action>", methods=["POST"])
def api_daemon(action):
    return jsonify(data.daemon_control(action))


@app.route("/api/version-check")
def api_version_check():
    return jsonify(data.check_versions())


@app.route("/api/update", methods=["POST"])
def api_update():
    body = request.json or {}
    pkg = body.get("package", "")
    return jsonify(data.run_pip_upgrade(pkg))


@app.route("/api/events")
def api_events():
    since = request.args.get("since", 0, type=float)
    return jsonify(data.get_events(since))


@app.route("/api/stream")
def api_stream():
    def generate():
        pos = EVENTS_FILE.stat().st_size if EVENTS_FILE.exists() else 0
        yield "data: {\"event\": \"connected\"}\n\n"
        while True:
            try:
                if EVENTS_FILE.exists():
                    with open(EVENTS_FILE) as f:
                        f.seek(pos)
                        lines = f.readlines()
                        pos = f.tell()
                    for line in lines:
                        line = line.strip()
                        if line:
                            yield f"data: {line}\n\n"
            except Exception:
                pass
            time.sleep(0.5)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def _get_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "localhost"


def main():
    ip = _get_ip()
    print("\n  Rewindex Dashboard")
    print(f"  http://{ip}:{PORT}\n")
    app.run(host="0.0.0.0", port=PORT, debug=False)


if __name__ == "__main__":
    main()
