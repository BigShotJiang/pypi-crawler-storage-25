from rewindex.web.app import main

__all__ = ["main"]
