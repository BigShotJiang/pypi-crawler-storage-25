# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import hashlib
import io
import os
import re
import shutil
import sqlite3
from datetime import datetime, timezone

from .opcodes import generate
from .storage import read_full, write_diff, write_full
from rewindex.config.defaults import (
    DISK_FULL_BYTES,
    DISK_WARN_BYTES,
    DISK_WARN_RATIO,
    DISK_WARNING_FILE,
    MAX_TEXT_FILE_BYTES,
    REWINDEX_DIR,
)
from rewindex.db.queries import (
    finalize_file_version,
    get_latest_file_version,
    get_or_create_file_registry,
    get_or_create_session,
    insert_file_version,
    update_file_symbols,
)

_O_NOATIME = getattr(os, "O_NOATIME", 0)


def extract_symbols(diff_text: str, filepath: str) -> list[str]:
    added = [l[1:] for l in diff_text.splitlines()
             if l.startswith('+') and not l.startswith('+++')]
    removed = [l[1:] for l in diff_text.splitlines()
               if l.startswith('-') and not l.startswith('---')]
    text = '\n'.join(added + removed)
    ext = filepath.rsplit('.', 1)[-1].lower() if '.' in filepath else ''

    if ext in ('html', 'htm', 'css', 'scss', 'less'):
        classes = re.findall(r'\.([\w-]+)\s*[{,]', text)
        ids = re.findall(r'id=["\']?([\w-]+)', text)
        tags = re.findall(r'<([\w-]+)[\s>]', text)
        return list(dict.fromkeys(classes + ids + tags))[:10]

    elif ext == 'py':
        funcs = re.findall(r'def ([\w_]+)\(', text)
        classes = re.findall(r'class ([\w_]+)[:(]', text)
        return list(dict.fromkeys(funcs + classes))[:10]

    elif ext in ('js', 'ts', 'tsx', 'jsx', 'mjs'):
        funcs = re.findall(r'(?:function|const|let|var)\s+([\w_]+)', text)
        classes = re.findall(r'class ([\w_]+)', text)
        return list(dict.fromkeys(funcs + classes))[:10]

    else:
        tokens = re.findall(r'\b([a-zA-Z_][\w_-]{4,})\b', text)
        freq: dict[str, int] = {}
        for t in tokens:
            freq[t] = freq.get(t, 0) + 1
        return sorted(freq, key=freq.__getitem__, reverse=True)[:10]


def _count_diff_lines(diff_text: str) -> tuple[int, int]:
    added = sum(1 for l in diff_text.splitlines()
                if l.startswith('+') and not l.startswith('+++'))
    removed = sum(1 for l in diff_text.splitlines()
                  if l.startswith('-') and not l.startswith('---'))
    return added, removed


def _check_disk() -> str | None:
    try:
        usage = shutil.disk_usage(REWINDEX_DIR)
        free = usage.free
        total = usage.total
        warn_threshold = max(DISK_WARN_BYTES, int(total * DISK_WARN_RATIO))

        if free < DISK_FULL_BYTES:
            _write_disk_warning(f"Disk full: {free // 1024}KB free")
            return "full"
        elif free < warn_threshold:
            _write_disk_warning(f"Low disk space: {free // (1024 * 1024)}MB free")
            return "warn"
        else:
            _clear_disk_warning()
            return None
    except OSError:
        return None


def _write_disk_warning(message: str) -> None:
    os.makedirs(REWINDEX_DIR, exist_ok=True)
    fd = os.open(DISK_WARNING_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, (message + "\n").encode())
    finally:
        os.close(fd)


def _clear_disk_warning() -> None:
    try:
        os.remove(DISK_WARNING_FILE)
    except FileNotFoundError:
        pass


def read_disk_warning() -> str | None:
    try:
        with open(DISK_WARNING_FILE) as f:
            return f.read().strip()
    except FileNotFoundError:
        return None


def _open_rb_noatime(filepath: str):
    if _O_NOATIME:
        try:
            fd = os.open(filepath, os.O_RDONLY | _O_NOATIME)
            return io.open(fd, "rb")
        except OSError:
            pass
    return open(filepath, "rb")


def _open_text_noatime(filepath: str):
    if _O_NOATIME:
        try:
            fd = os.open(filepath, os.O_RDONLY | _O_NOATIME)
            return io.open(fd, "r", encoding="utf-8", errors="replace")
        except OSError:
            pass
    return open(filepath, "r", encoding="utf-8", errors="replace")


def hash_file(filepath: str) -> str:
    h = hashlib.sha256()
    with _open_rb_noatime(filepath) as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def is_binary(filepath: str) -> bool:
    try:
        with _open_rb_noatime(filepath) as f:
            return b"\x00" in f.read(8192)
    except OSError:
        return False


def record_deletion(
    conn: sqlite3.Connection,
    workspace: str,
    workspace_folder: str,
    abs_filepath: str,
    session_uid: int | None = None,
    gap_seconds: float = 20.0,
) -> int | None:
    """Record a deletion event for a tracked file. Returns file version uid or None."""
    filepath = os.path.relpath(abs_filepath, workspace_folder)
    registry_uid, file_id, next_ver = get_or_create_file_registry(conn, workspace, workspace_folder, filepath)

    latest = get_latest_file_version(conn, registry_uid)
    if latest is None or latest["is_deleted"]:
        return None

    created_at = datetime.now(timezone.utc).isoformat()

    if session_uid is None:
        session_uid = get_or_create_session(conn, workspace, created_at, gap_seconds)

    file_uid = insert_file_version(
        conn,
        file_registry_uid=registry_uid,
        file_version=next_ver,
        created_at=created_at,
        hash="__deleted__",
        is_full=True,
        is_deleted=True,
        session_uid=session_uid,
        status="DELETE",
    )

    path, file_size = write_full(workspace, file_uid, filepath, [])
    finalize_file_version(conn, file_uid, path, file_size)
    return file_uid


def record_move(
    conn: sqlite3.Connection,
    workspace: str,
    workspace_folder: str,
    abs_filepath: str,
    old_filepath: str,
    session_uid: int | None = None,
    gap_seconds: float = 20.0,
) -> int | None:
    """Record a MOVE or RENAME event: new version pointing to same content."""
    filepath = os.path.relpath(abs_filepath, workspace_folder)
    registry_uid, file_id, next_ver = get_or_create_file_registry(conn, workspace, workspace_folder, filepath)

    latest = get_latest_file_version(conn, registry_uid)
    if latest is None:
        return None

    old_dir = os.path.dirname(old_filepath)
    new_dir = os.path.dirname(filepath)
    is_rename = old_dir == new_dir

    if is_rename:
        old_name = os.path.basename(old_filepath)
        status = "RENAME"
        note = f"renamed from {old_name}"
    else:
        status = "MOVE"
        note = f"moved from {old_filepath}"

    created_at = datetime.now(timezone.utc).isoformat()

    if session_uid is None:
        session_uid = get_or_create_session(conn, workspace, created_at, gap_seconds)

    file_uid = insert_file_version(
        conn,
        file_registry_uid=registry_uid,
        file_version=next_ver,
        created_at=created_at,
        hash=latest["hash"],
        is_full=latest["is_full"],
        is_compressed=latest["is_compressed"],
        session_uid=session_uid,
        status=status,
    )

    finalize_file_version(conn, file_uid, latest["storage_path"], latest["file_size"])

    from rewindex.db.queries import update_file_note
    update_file_note(conn, file_uid, note)

    return file_uid


def snapshot_file(
    conn: sqlite3.Connection,
    workspace: str,
    workspace_folder: str,
    abs_filepath: str,
    session_uid: int | None = None,
    gap_seconds: float = 20.0,
) -> int | None:
    """
    Hash → compare → write full or diff → insert DB.
    Returns new file version uid, or None if unchanged/binary/skipped.
    """
    if not os.path.isfile(abs_filepath):
        return record_deletion(conn, workspace, workspace_folder, abs_filepath, session_uid, gap_seconds)

    if is_binary(abs_filepath):
        return None

    from rewindex.utils.validation import validate_filepath, validate_workspace_name
    try:
        validate_filepath(abs_filepath)
        validate_workspace_name(workspace)
    except ValueError:
        return None

    if os.path.getsize(abs_filepath) > MAX_TEXT_FILE_BYTES:
        return None

    disk_status = _check_disk()
    if disk_status == "full":
        return None

    current_hash = hash_file(abs_filepath)
    filepath = os.path.relpath(abs_filepath, workspace_folder)

    registry_uid, file_id, next_ver = get_or_create_file_registry(conn, workspace, workspace_folder, filepath)
    latest = get_latest_file_version(conn, registry_uid)

    if latest and latest["hash"] == current_hash:
        return None

    with _open_text_noatime(abs_filepath) as f:
        new_lines = f.readlines()

    created_at = datetime.now(timezone.utc).isoformat()
    is_full = latest is None or bool(latest["is_deleted"])

    if session_uid is None:
        session_uid = get_or_create_session(conn, workspace, created_at, gap_seconds)

    status = "CREATE" if is_full else "CHANGE"

    file_uid = insert_file_version(
        conn,
        file_registry_uid=registry_uid,
        file_version=next_ver,
        created_at=created_at,
        hash=current_hash,
        is_full=is_full,
        session_uid=session_uid,
        status=status,
    )

    try:
        if is_full:
            storage_path, file_size = write_full(workspace, file_uid, filepath, new_lines)
            finalize_file_version(conn, file_uid, storage_path, file_size)
        else:
            from .reconstruct import reconstruct
            try:
                old_lines = reconstruct(conn, registry_uid, latest["uid"])
            except ValueError:
                conn.execute("DELETE FROM file WHERE uid = ?", (file_uid,))
                conn.commit()
                # Corrupt chain — write as new fullbase
                file_uid = insert_file_version(
                    conn,
                    file_registry_uid=registry_uid,
                    file_version=next_ver,
                    created_at=created_at,
                    hash=current_hash,
                    is_full=True,
                    session_uid=session_uid,
                    status="CREATE",
                )
                storage_path, file_size = write_full(workspace, file_uid, filepath, new_lines)
                finalize_file_version(conn, file_uid, storage_path, file_size)
                return file_uid

            ops = generate(old_lines, new_lines)
            storage_path, file_size, is_compressed = write_diff(workspace, file_uid, filepath, ops)
            if is_compressed:
                conn.execute("UPDATE file SET is_compressed = 1 WHERE uid = ?", (file_uid,))
                conn.commit()
            finalize_file_version(conn, file_uid, storage_path, file_size)
    except Exception:
        conn.execute("DELETE FROM file WHERE uid = ?", (file_uid,))
        conn.commit()
        raise

    try:
        if is_full:
            la, lr = len(new_lines), 0
            diff_text = ''.join('+' + l for l in new_lines)
        else:
            import difflib
            diff_text = ''.join(difflib.unified_diff(old_lines, new_lines, lineterm=''))
            la, lr = _count_diff_lines(diff_text)
        symbols = extract_symbols(diff_text, filepath)
        update_file_symbols(conn, file_uid, symbols, la, lr)
    except Exception:
        pass

    from .precompute import maybe_precompute
    maybe_precompute(conn, workspace, session_uid)

    from .trim import maybe_trim
    maybe_trim(conn, workspace)

    return file_uid
