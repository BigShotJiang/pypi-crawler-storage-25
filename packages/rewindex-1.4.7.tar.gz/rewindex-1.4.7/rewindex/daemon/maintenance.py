# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Periodic maintenance tasks run by the daemon:
- License re-validation every 24h
- Trash auto-purge (items > 30 days old)
- Orphan sweep — delete snapshot files with no DB record (every 24h)
"""

import logging
import os
import shutil
import threading
import time
from datetime import datetime, timezone

from rewindex.config.defaults import SNAPSHOTS_DIR, TRASH_DIR

logger = logging.getLogger("rewindex.daemon")

_REVALIDATE_INTERVAL = 86400  # 24 hours
_RETRY_INTERVAL = 900          # 15 minutes (retry when offline and overdue)
_TRASH_MAX_AGE = 30 * 86400   # 30 days
_MAINTENANCE_CHECK = 3600      # check every hour

_pending_revalidation = False


def run_maintenance(config: dict) -> None:
    t = threading.Thread(target=_maintenance_loop, args=(config,), daemon=True)
    t.start()


def _maintenance_loop(config: dict) -> None:
    global _pending_revalidation
    while True:
        try:
            _revalidate_license()
            _purge_old_trash()
            _orphan_sweep(config)
        except Exception:
            logger.exception("Maintenance loop error")
        interval = _RETRY_INTERVAL if _pending_revalidation else _MAINTENANCE_CHECK
        time.sleep(interval)


def _revalidate_license() -> None:
    """
    Periodic license check against LemonSqueezy validate API.

    Status handling:
      active   → Pro stays, update validated_at
      expired  → subscription ended, clear license → Free
      inactive → deactivated remotely (e.g. from another machine), clear license → Free
      disabled → admin/support disabled the key, clear license → Free
      invalid  → key no longer exists, clear license → Free
      offline  → keep current plan, retry in 15 min
    """
    global _pending_revalidation
    from rewindex.license import (
        _read_license_data, _write_license_data, _post_api,
        clear_license, is_pro,
    )
    from rewindex.config.urls import VALIDATE_URL

    if not is_pro():
        _pending_revalidation = False
        return

    data = _read_license_data()
    validated_at = data.get("validated_at")
    if validated_at:
        try:
            last = datetime.fromisoformat(validated_at)
            elapsed = (datetime.now(timezone.utc) - last).total_seconds()
            if elapsed < _REVALIDATE_INTERVAL:
                _pending_revalidation = False
                return
        except ValueError:
            pass

    license_key = data.get("license_key")
    instance_id = data.get("instance_id", "")
    if not license_key:
        _pending_revalidation = False
        return

    try:
        payload = {"license_key": license_key}
        if instance_id:
            payload["instance_id"] = instance_id
        resp = _post_api(VALIDATE_URL, payload)
    except ConnectionError:
        _pending_revalidation = True
        logger.info("License revalidation: offline, retry later")
        return

    lk = resp.get("license_key", {})
    status = lk.get("status", "unknown")
    valid = resp.get("valid", False)

    if valid and status == "active":
        data["expires_at"] = lk.get("expires_at") or ""
        data["validated_at"] = datetime.now(timezone.utc).isoformat()
        _write_license_data(data)
        _pending_revalidation = False
        logger.info("License revalidation: active")
    elif status == "expired":
        clear_license()
        _pending_revalidation = False
        logger.warning("License expired, downgraded to Free")
    elif status == "inactive":
        clear_license()
        _pending_revalidation = False
        logger.warning("License deactivated remotely, downgraded to Free")
    elif status == "disabled":
        clear_license()
        _pending_revalidation = False
        logger.warning("License disabled by admin, downgraded to Free")
    else:
        clear_license()
        _pending_revalidation = False
        logger.warning("License invalid (status: %s), downgraded to Free", status)


_ORPHAN_INTERVAL = 86400  # 24 hours
_last_orphan_sweep = 0.0


def _orphan_sweep(config: dict) -> None:
    global _last_orphan_sweep
    now = time.time()
    if now - _last_orphan_sweep < _ORPHAN_INTERVAL:
        return

    from rewindex.db.connection import get_connection

    workspaces = config.get("workspaces", [])
    for ws in workspaces:
        name = ws["name"]
        snapshots_dir = os.path.join(SNAPSHOTS_DIR, name, "snapshots")
        if not os.path.isdir(snapshots_dir):
            continue

        conn = get_connection(name)
        try:
            known_paths = set()
            rows = conn.execute("SELECT storage_path FROM file WHERE storage_path != ''").fetchall()
            for r in rows:
                known_paths.add(os.path.realpath(r["storage_path"]))

            for root, dirs, files in os.walk(snapshots_dir):
                for f in files:
                    full_path = os.path.realpath(os.path.join(root, f))
                    if full_path.endswith(".db") or full_path.endswith(".db-wal") or full_path.endswith(".db-shm"):
                        continue
                    if full_path not in known_paths:
                        try:
                            os.remove(full_path)
                        except OSError:
                            pass

            # remove empty directories
            for root, dirs, files in os.walk(snapshots_dir, topdown=False):
                if root == snapshots_dir:
                    continue
                if not os.listdir(root):
                    try:
                        os.rmdir(root)
                    except OSError:
                        pass
        finally:
            conn.close()

    _last_orphan_sweep = now


def _purge_old_trash() -> None:
    if not os.path.isdir(TRASH_DIR):
        return

    now = time.time()
    for name in os.listdir(TRASH_DIR):
        path = os.path.join(TRASH_DIR, name)
        if not os.path.isdir(path):
            continue
        mtime = os.path.getmtime(path)
        if now - mtime > _TRASH_MAX_AGE:
            shutil.rmtree(path, ignore_errors=True)
