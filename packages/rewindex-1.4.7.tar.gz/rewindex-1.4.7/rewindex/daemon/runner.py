# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import logging
import os
import signal
import subprocess
import sys

from rewindex.config.defaults import LOG_BACKUP_COUNT, MAX_LOG_BYTES, PID_FILE


def write_pid() -> None:
    os.makedirs(os.path.dirname(PID_FILE), exist_ok=True)
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))


def read_pid() -> int | None:
    if not os.path.exists(PID_FILE):
        return None
    try:
        with open(PID_FILE) as f:
            return int(f.read().strip())
    except (ValueError, OSError):
        return None


def remove_pid() -> None:
    if os.path.exists(PID_FILE):
        os.remove(PID_FILE)


def is_running() -> bool:
    pid = read_pid()
    if pid is None:
        return False
    try:
        os.kill(pid, 0)  # signal 0 = check only, no actual signal
        return True
    except (ProcessLookupError, PermissionError):
        return False


def start_daemon(config: dict, _start_label: str = "started", quiet: bool = False) -> None:
    """
    Spawn daemon as a detached background process and return immediately.
    The child process runs `rewindex _run` which blocks on the file watcher.

    Only one daemon instance is allowed system-wide — it already watches
    all configured workspaces. Re-running `rewindex start` while one is alive
    prints an info message and exits without spawning a duplicate.
    """
    log_dir = os.path.dirname(PID_FILE)
    try:
        os.makedirs(log_dir, exist_ok=True)
    except PermissionError:
        print(
            f"Error: no write permission to {log_dir}\n"
            "Check folder permissions and try again."
        )
        return

    # Atomic single-instance lock: try to create PID file exclusively.
    # If it exists and the owning process is alive, refuse to start another.
    # If it exists but the process is dead (stale), clean up and retry once.
    for _ in range(2):
        try:
            fd = os.open(PID_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
            # Lock acquired — spawn daemon and write its PID.
            break
        except FileExistsError:
            if is_running():
                pid = read_pid()
                print(
                    f"Error: daemon is already running (PID {pid}).\n"
                    f"Use `rewindex restart` to restart it."
                )
                return
            # Stale PID file — remove and retry exclusive create.
            remove_pid()
    else:
        print("Error: could not acquire daemon lock. Try 'rewindex stop' and retry.")
        return

    rewindex_cmd = _find_bin()

    from rewindex.plugin import get_platform
    from pathlib import Path
    log_path = Path(os.path.dirname(PID_FILE)) / "daemon.log"
    child_pid = get_platform().start_daemon(rewindex_cmd + ["_run"], log_path)

    # Write the child PID into the lock file we just created.
    with os.fdopen(fd, "w") as f:
        f.write(str(child_pid))

    if not quiet:
        print(f"\nRewindex {_start_label}.")
        _print_workspace_list(config)


def run_daemon_process() -> None:
    """
    Internal: called by `rewindex _run` inside the background process.
    Blocks until killed.
    """
    from rewindex.config.loader import load_config
    from rewindex.daemon.reconcile import startup_reconcile
    from rewindex.daemon.watcher import start_watching

    log_dir = os.path.dirname(PID_FILE)
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "daemon.log")

    logging.getLogger().handlers.clear()
    logger = _setup_logger(log_path)
    sys.stdout = _LogStream(logger, logging.INFO)
    sys.stderr = _LogStream(logger, logging.ERROR)

    config = load_config()
    startup_reconcile(config)

    from rewindex.daemon.maintenance import run_maintenance
    run_maintenance(config)

    try:
        start_watching(config)
    except KeyboardInterrupt:
        pass
    finally:
        remove_pid()


def _setup_logger(log_path: str) -> logging.Logger:
    from logging.handlers import RotatingFileHandler

    logger = logging.getLogger("rewindex.daemon")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = RotatingFileHandler(
        log_path, maxBytes=MAX_LOG_BYTES, backupCount=LOG_BACKUP_COUNT,
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)

    os.chmod(log_path, 0o600)
    return logger


class _LogStream:
    """File-like wrapper that routes print()/sys.stdout writes to a logger."""

    def __init__(self, logger: logging.Logger, level: int):
        self._logger = logger
        self._level = level

    def write(self, msg: str) -> None:
        msg = msg.rstrip()
        if msg:
            self._logger.log(self._level, msg)

    def flush(self) -> None:
        for h in self._logger.handlers:
            h.flush()


def stop_daemon() -> None:
    pid = read_pid()
    if pid is None or not is_running():
        print("Rewindex is not running.")
        remove_pid()
        return
    try:
        import psutil
        proc = psutil.Process(pid)
        cmdline = " ".join(proc.cmdline())
        if "rewindex" not in cmdline:
            print(f"PID {pid} does not appear to be a rewindex process — refusing to stop.")
            return
    except Exception:
        pass  # psutil unavailable or process already gone — proceed
    try:
        from rewindex.plugin import get_platform
        get_platform().stop_daemon(pid)
        remove_pid()
        print("\nDaemon stopped.\n")
    except ProcessLookupError:
        remove_pid()
        print("Rewindex process not found — cleaned up.")


def restart_daemon(config: dict, quiet: bool = False) -> None:
    """Stop daemon if running, then start fresh with updated config."""
    if is_running():
        pid = read_pid()
        if pid:
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            remove_pid()
        start_daemon(config, _start_label="restarted", quiet=quiet)
    else:
        start_daemon(config, quiet=quiet)



def _print_workspace_list(config: dict) -> None:
    from rewindex.license import is_pro
    workspaces = config.get("workspaces", [])
    if not workspaces:
        print("No workspaces configured. Run `rewindex workspace add` to get started.")
        return
    pro = is_pro()
    workspace_limit = 0 if pro else 1
    print("─" * 40)
    for i, p in enumerate(workspaces, 1):
        folders = p.get("folders", [])
        primary = folders[0] if folders else "(none)"
        name_col = p['name'] + "  (paused)" if workspace_limit and i > workspace_limit else p['name']
        print(f"  WS{i}   {name_col:<24} {primary}")
        for f in folders[1:]:
            print(f"{'':>20} {f}")
        print()



def _find_bin() -> list[str]:
    import shutil
    path = shutil.which("rewindex")
    if path:
        return [path]
    # Fallback: run via same Python interpreter
    return [sys.executable, "-m", "rewindex.cli"]
