# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click

from rewindex.config.loader import load_config
from rewindex.db.connection import get_connection
from rewindex.commands._workspace import resolve_workspace


@click.command()
@click.argument("target", default="")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
@click.option("--detail", "-d", is_flag=True, default=False, help="Session list with all versions per session.")
@click.option("--full", "-f", is_flag=True, default=False, help="Session list with full workspace state.")
@click.option("--limit", "-l", "-n", default=15, show_default=True, help="Max sessions to show.")
@click.option("--since", "-s", default=None, help="Since date (DD/MM/YY).")
@click.option("--folder", default=None, help="Filter by folder path.")
@click.option("--reverse", "-r", is_flag=True, help="Show oldest first.")
@click.option("--from", "from_id", default=None, help="Start from SN or SS ID.")
@click.option("--to", "to_id", default=None, help="End at SN or SS ID.")
def log_cmd(
    target: str,
    workspace: str | None,
    detail: bool,
    full: bool,
    limit: int,
    since: str | None,
    folder: str | None,
    reverse: bool,
    from_id: str | None,
    to_id: str | None,
) -> None:
    """List sessions or show file version history.

    \b
    rewindex log                     session list — latest version per file
    rewindex log --detail            session list — all versions per session
    rewindex log --full              session list — full workspace state
    rewindex log sn                  flat list — all snapshots
    rewindex log <SS>                full workspace state at a session
    rewindex log <FileID>            file version history
    rewindex log <SN>                resolve snap → file version history
    rewindex log --limit 20          show last N sessions/snaps
    rewindex log --reverse           oldest first
    rewindex log --since DD/MM/YY    from date onward
    rewindex log --folder <path>     filter by folder
    rewindex log --from SN5 --to SN20   range by snap ID
    rewindex log --from SS2 --to SS8    range by session ID
    """
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import (
        fmt_session, fmt_snap, is_file_id, is_session_target,
        is_snap_target, parse_file_id_version, parse_session_id,
        parse_snap_id,
    )
    from rewindex.db.queries import (
        get_all_snapshots,
        get_file_registry_by_id,
        get_file_version,
        get_file_version_range,
        get_file_versions_for_registry,
        get_files_in_session,
        get_session_by_uid,
        get_sessions,
    )

    config = load_config()
    all_workspaces = config.get("workspaces", [])

    if not all_workspaces:
        click.echo("No workspaces configured.")
        return

    resolved = resolve_workspace(all_workspaces, workspace or None)
    if resolved is None:
        return

    conn = get_connection(resolved)
    try:
        # Resolve --from / --to to uid ranges
        if from_id or to_id:
            snap_from, snap_to, ss_from, ss_to = _resolve_range(
                conn, resolved, from_id, to_id,
                is_session_target, parse_session_id,
                is_snap_target, parse_snap_id,
            )
            if snap_from is None and snap_to is None and ss_from is None and ss_to is None and (from_id or to_id):
                return
        else:
            snap_from = snap_to = ss_from = ss_to = None

        # Single session: rewindex log SS12 [--detail] [--full]
        if target and is_session_target(target):
            try:
                ss_uid = parse_session_id(target)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
            mode = "full" if full else ("detail" if detail else "summary")
            _print_single_session(conn, resolved, ss_uid, mode)
            return

        # Snap → resolve to file history: rewindex log SN5
        if target and is_snap_target(target) and target.upper() != "SN":
            try:
                snap_uid = parse_snap_id(target)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
            ver = get_file_version(conn, snap_uid)
            if not ver:
                click.echo(f"\nError: {target.upper()} not found — may have been trimmed.")
                _show_available_range(conn, resolved)
                return
            reg = conn.execute(
                "SELECT file_id FROM file_registry WHERE uid = ?",
                (ver["file_registry_uid"],),
            ).fetchone()
            if not reg:
                click.echo(f"\nError: file registry not found for {target.upper()}.")
                return
            _print_file_history(conn, resolved, reg["file_id"])
            return

        # File version history: rewindex log XULK
        if target and is_file_id(target):
            _print_file_history(conn, resolved, target)
            return

        # Flat list: rewindex log sn
        if target and target.lower() == "sn":
            _print_flat_list(conn, resolved, limit, since, folder, reverse,
                             from_uid=snap_from, to_uid=snap_to)
            return

        # Unknown target
        if target:
            click.echo(f"Error: unknown target '{target}'. Use SN for snapshots, SS for sessions, or a FileID.")
            return

        # Session list with mode: default (summary), --detail (all versions), --full (full state)
        mode = "full" if full else ("detail" if detail else "summary")
        _print_session_list(conn, resolved, limit, since, folder, reverse,
                            from_uid=ss_from, to_uid=ss_to, mode=mode)
    finally:
        conn.close()


def _show_available_range(conn, workspace: str) -> None:
    """Show available SN and SS range after a 'not found' error."""
    from rewindex.utils.id_parse import fmt_snap, fmt_session
    from rewindex.db.queries import get_oldest_session, get_latest_session

    oldest_ss = get_oldest_session(conn, workspace)
    latest_ss = get_latest_session(conn, workspace)

    oldest_sn = conn.execute(
        """SELECT MIN(f.uid) as min_uid, MAX(f.uid) as max_uid
           FROM file f JOIN file_registry r ON f.file_registry_uid = r.uid
           WHERE r.workspace = ?""", (workspace,)
    ).fetchone()

    lines = []
    if oldest_sn and oldest_sn["min_uid"]:
        lines.append(f"  Snapshots: {fmt_snap(oldest_sn['min_uid'])} → {fmt_snap(oldest_sn['max_uid'])}")
    if oldest_ss and latest_ss:
        lines.append(f"  Sessions:  {fmt_session(oldest_ss['uid'])} → {fmt_session(latest_ss['uid'])}")

    if lines:
        click.echo("Available range:")
        for line in lines:
            click.echo(line)
    else:
        click.echo("No snapshots or sessions found.")


def _resolve_range(conn, workspace, from_id, to_id, is_session_target, parse_session_id, is_snap_target, parse_snap_id):
    """Resolve --from/--to IDs into (snap_from, snap_to, ss_from, ss_to) uid ranges.

    SN IDs map to snap range directly and resolve to session range via query.
    SS IDs map to session range directly and resolve to snap range via query.
    Returns None tuple on error (after printing message).
    """
    snap_from = snap_to = ss_from = ss_to = None

    for id_val, is_from in [(from_id, True), (to_id, False)]:
        if id_val is None:
            continue

        flag = "--from" if is_from else "--to"

        if is_snap_target(id_val):
            try:
                uid = parse_snap_id(id_val)
            except ValueError:
                click.echo(f"Error: invalid {flag} value '{id_val}'.")
                click.echo("Usage: --from SN5 --to SN20  or  --from SS2 --to SS8")
                return None, None, None, None
            row = conn.execute("SELECT uid FROM file WHERE uid = ?", (uid,)).fetchone()
            if not row:
                click.echo(f"Error: {id_val.upper()} not found — may have been trimmed.")
                _show_available_range(conn, workspace)
                return None, None, None, None
            if is_from:
                snap_from = uid
            else:
                snap_to = uid
            ss_row = conn.execute(
                "SELECT session_uid FROM file WHERE uid = ?", (uid,)
            ).fetchone()
            if ss_row and ss_row["session_uid"]:
                if is_from:
                    ss_from = ss_row["session_uid"]
                else:
                    ss_to = ss_row["session_uid"]

        elif is_session_target(id_val):
            try:
                uid = parse_session_id(id_val)
            except ValueError:
                click.echo(f"Error: invalid {flag} value '{id_val}'.")
                click.echo("Usage: --from SS2 --to SS8  or  --from SN5 --to SN20")
                return None, None, None, None
            row = conn.execute("SELECT uid FROM sessions WHERE uid = ?", (uid,)).fetchone()
            if not row:
                click.echo(f"Error: {id_val.upper()} not found — may have been trimmed.")
                _show_available_range(conn, workspace)
                return None, None, None, None
            if is_from:
                ss_from = uid
            else:
                ss_to = uid
            agg = "MIN" if is_from else "MAX"
            snap_row = conn.execute(
                f"SELECT {agg}(uid) as snap_uid FROM file WHERE session_uid = ?", (uid,)
            ).fetchone()
            if snap_row and snap_row["snap_uid"]:
                if is_from:
                    snap_from = snap_row["snap_uid"]
                else:
                    snap_to = snap_row["snap_uid"]
        else:
            click.echo(f"Error: invalid {flag} value '{id_val}'. Expected SN or SS ID.")
            click.echo("Usage: --from SN5 --to SN20  or  --from SS2 --to SS8")
            return None, None, None, None

    if snap_from and snap_to and snap_from > snap_to:
        click.echo(f"Error: --from (SN{snap_from}) is newer than --to (SN{snap_to}).")
        click.echo("Hint: --from should be the older (smaller) ID, --to the newer (larger).")
        return None, None, None, None

    if ss_from and ss_to and ss_from > ss_to:
        click.echo(f"Error: --from (SS{ss_from}) is newer than --to (SS{ss_to}).")
        click.echo("Hint: --from should be the older (smaller) ID, --to the newer (larger).")
        return None, None, None, None

    return snap_from, snap_to, ss_from, ss_to


def _print_flat_list(conn, workspace: str, limit: int, since: str | None, folder: str | None, reverse: bool,
                     from_uid: int | None = None, to_uid: int | None = None) -> None:
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import fmt_snap
    from rewindex.db.queries import get_all_snapshots

    snaps = get_all_snapshots(conn, workspace, limit=limit, since=since, folder=folder, reverse=reverse,
                              from_uid=from_uid, to_uid=to_uid)
    if not snaps:
        click.echo("No snapshots found.")
        return

    header = fmt_date_header()
    click.echo(f"\nSnapshots  {header}")
    click.echo("─" * 64)

    for s in snaps:
        snap_id = fmt_snap(s["uid"])
        file_id = s["file_id"]
        time_str = fmt_date(s["created_at"])
        version = f"v{s['file_version']}"
        filepath = s["filepath"]
        status = s["status"] if s["status"] else "CHANGE"
        note_str = f"  # {s['note']}" if s["note"] else ""
        click.echo(f"  {snap_id}  {file_id}   {time_str}   {version}   {filepath}   [{status}]{note_str}")

    click.echo()


def _print_file_history(conn, workspace: str, file_id_str: str) -> None:
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import fmt_session
    from rewindex.db.queries import (
        get_file_registry_by_id,
        get_file_version_range,
        get_file_versions_for_registry,
    )

    reg = get_file_registry_by_id(conn, workspace, file_id_str)
    if not reg:
        click.echo(f'\nError: unknown FileID "{file_id_str}" — may have been trimmed.')
        _show_available_range(conn, workspace)
        click.echo()
        return

    versions = get_file_versions_for_registry(conn, reg["uid"])
    if not versions:
        click.echo(f'\nNo versions found for {file_id_str}.')
        click.echo()
        return

    min_v, max_v = versions[0]["file_version"], versions[-1]["file_version"]
    header = fmt_date_header()
    click.echo(f"\n{reg['file_id']}   {reg['filepath']}  |  Oldest v{min_v} — Latest v{max_v}  {header}")
    click.echo("─" * 56)

    for v in versions:
        ss_str = fmt_session(v["session_uid"]) if v["session_uid"] else "    "
        time_str = fmt_date(v["created_at"])

        action = v["status"] if v["status"] else "CHANGE"

        labels = []
        if v["file_version"] == 1 and not v["is_deleted"]:
            labels.append("[Original]")
        if v["is_full"] and v["file_version"] > 1 and not v["is_deleted"]:
            promoted = v["promoted_by"] if "promoted_by" in v.keys() else None
            if promoted == "trim":
                labels.append("[Trim base]")
            elif promoted == "precompute":
                labels.append("[Pre-compute]")
            else:
                labels.append("[Fullbase]")

        label_str = f"  {'  '.join(labels)}" if labels else ""
        note_str = f"  # {v['note']}" if v["note"] else ""

        click.echo(f"  v{v['file_version']}   {ss_str}   {time_str:<14}  {action}{label_str}{note_str}")
    click.echo()


def _print_single_session(conn, workspace: str, session_uid: int, mode: str = "summary") -> None:
    """Print a single session. mode: summary (latest per file), detail (all versions), full (all tracked files)."""
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import fmt_session
    from rewindex.db.queries import (
        get_session_by_uid,
        get_files_in_session,
        get_all_tracked_files,
        get_latest_version_at_session,
    )

    session = get_session_by_uid(conn, session_uid)
    if not session:
        click.echo(f"\nError: {fmt_session(session_uid)} not found — may have been trimmed.")
        _show_available_range(conn, workspace)
        click.echo()
        return

    header = fmt_date_header()

    if mode == "full":
        click.echo(f"\n{fmt_session(session_uid)} | {fmt_date(session['created_at'])}   Full workspace state  {header}")
        click.echo("─" * 64)
        tracked = get_all_tracked_files(conn, workspace)
        for reg in tracked:
            ver = get_latest_version_at_session(conn, reg["uid"], session_uid)
            if ver is None:
                continue
            if ver["is_deleted"]:
                continue
            note_str = f"  # {ver['note']}" if ver["note"] else ""
            snap_time = fmt_date(ver["created_at"])
            click.echo(f"  {reg['file_id']}   {snap_time}   v{ver['file_version']}   {reg['filepath']}{note_str}")
    else:
        files = get_files_in_session(conn, session_uid)
        unique_files = len(set(f["file_id"] for f in files))
        snap_count = len(files)
        file_word = "file" if unique_files == 1 else "files"
        count_str = f"{unique_files} {file_word}"
        if snap_count > unique_files:
            count_str += f"  {snap_count} snaps"

        click.echo(f"\n{fmt_session(session_uid)} | {fmt_date(session['created_at'])}   {count_str}  {header}")
        click.echo("─" * 64)
        _print_session_files(files, mode)

    if session["note"]:
        click.echo(f"\n  # {session['note']}")
    click.echo()


def _print_session_files(files, mode: str) -> None:
    """Print files within a session. mode: summary (latest per file) or detail (all versions)."""
    from rewindex.utils.formatting import fmt_date

    if mode == "detail":
        from rewindex.utils.id_parse import fmt_snap
        for f in files:
            snap_time = fmt_date(f["created_at"])
            status = f["status"] if f["status"] else "CHANGE"
            note_str = f"  # {f['note']}" if f["note"] else ""
            click.echo(f"  {fmt_snap(f['uid'])}  {f['file_id']}   {snap_time}   v{f['file_version']}   {f['filepath']}   [{status}]{note_str}")
    else:
        seen = {}
        for f in files:
            seen[f["file_id"]] = f
        for f in seen.values():
            snap_time = fmt_date(f["created_at"])
            status = f["status"] if f["status"] else "CHANGE"
            note_str = f"  # {f['note']}" if f["note"] else ""
            click.echo(f"  {f['file_id']}   {snap_time}   v{f['file_version']}   {f['filepath']}   [{status}]{note_str}")


def _print_session_list(conn, workspace: str, limit: int, since: str | None, folder: str | None, reverse: bool,
                        from_uid: int | None = None, to_uid: int | None = None, mode: str = "summary") -> None:
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import fmt_session
    from rewindex.db.queries import get_sessions, get_files_in_session, get_flags_by_sessions

    sessions = get_sessions(conn, workspace, limit=limit, since=since, reverse=reverse,
                            from_uid=from_uid, to_uid=to_uid)
    if not sessions:
        click.echo(f"No sessions found for workspace '{workspace}'.")
        return

    if mode == "full":
        from rewindex.db.queries import get_all_tracked_files, get_latest_version_at_session

    # Fetch flags for all sessions in this view
    session_uids = [s["uid"] for s in sessions]
    flag_map = get_flags_by_sessions(conn, workspace, session_uids)

    header = fmt_date_header()
    click.echo(f"\nSessions  {header}")

    for s in sessions:
        if mode == "full":
            click.echo(f"\n{fmt_session(s['uid'])} | {fmt_date(s['created_at'])}   Full workspace state")
            click.echo("─" * 64)
            tracked = get_all_tracked_files(conn, workspace)
            for reg in tracked:
                ver = get_latest_version_at_session(conn, reg["uid"], s["uid"])
                if ver is None:
                    continue
                if ver["is_deleted"]:
                    continue
                filepath = reg["filepath"]
                if folder and not filepath.startswith(folder):
                    continue
                note_str = f"  # {ver['note']}" if ver["note"] else ""
                snap_time = fmt_date(ver["created_at"])
                click.echo(f"  {reg['file_id']}   {snap_time}   v{ver['file_version']}   {filepath}{note_str}")
        else:
            files = get_files_in_session(conn, s["uid"])
            if folder:
                files = [f for f in files if f["filepath"].startswith(folder)]
                if not files:
                    continue

            unique_files = len(set(f["file_id"] for f in files))
            snap_count = len(files)
            file_word = "file" if unique_files == 1 else "files"
            count_str = f"{unique_files} {file_word}"
            if snap_count > unique_files:
                count_str += f"  {snap_count} snaps"

            click.echo(f"{fmt_session(s['uid'])} | {fmt_date(s['created_at'])}   {count_str}")
            click.echo("─" * 64)
            _print_session_files(files, mode)

        if s["note"]:
            click.echo(f"\n  # {s['note']}")

        click.echo()

        # Print flag bar AFTER this session, if a flag exists for it
        flag = flag_map.get(s["uid"])
        if flag:
            _print_flag_bar(flag["version"], flag["title"], flag["session_uid"])


def _print_flag_bar(version: str, title: str, session_uid: int) -> None:
    """Print a visual flag bar between sessions: ━━━━  v1.0.5  ·  Title  (SS55)  ━━━━"""
    bar_char = "━"
    label = f"  {version}  ·  SS{session_uid}  ·  {title}  "
    bar_width = max(0, (64 - len(label)) // 2)
    bar = bar_char * bar_width
    click.echo(f"{bar}{label}{bar}")
    click.echo()
