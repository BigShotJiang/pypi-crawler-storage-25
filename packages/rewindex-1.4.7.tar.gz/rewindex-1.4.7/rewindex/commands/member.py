# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import click

from rewindex.config.urls import LINK_PRICING, LINK_SUBSCRIPTION


@click.command()
@click.option("--license", "license_key", default=None, help="Activate a Pro license key.")
@click.option("--deactivate", is_flag=True, default=False, help="Deactivate the license on this machine.")
def member_cmd(license_key: str | None, deactivate: bool) -> None:
    """Show current plan, activate, or deactivate a Pro license key.

    \b
    rewindex member                      show membership info
    rewindex member --license <key>      activate a Pro license key
    rewindex member --deactivate         deactivate license on this machine
    """
    if deactivate:
        _deactivate()
        return

    if license_key:
        _activate(license_key)
        return

    from rewindex.license import get_membership
    membership = get_membership()
    _show_membership(membership)


def _activate(license_key: str) -> None:
    from rewindex.license import activate_license, get_membership

    try:
        result = activate_license(license_key)
    except ConnectionError:
        click.echo("\nError: could not reach license server.")
        click.echo("Check your connection and try again.")
        click.echo()
        return
    except ValueError as e:
        err = str(e)
        if err == "ACTIVATION_LIMIT_REACHED":
            click.echo("\nError: license key has reached the activation limit.")
            click.echo("Deactivate from the other machine first:")
            click.echo("  rewindex member --deactivate")
            click.echo(f"Or manage at {LINK_SUBSCRIPTION}")
        elif "expired" in err.lower():
            click.echo("\nError: license key has expired.")
            click.echo(f"Renew at {LINK_SUBSCRIPTION}")
        elif "inactive" in err.lower() or "disabled" in err.lower():
            click.echo("\nError: license key is inactive or disabled.")
            click.echo(f"Contact support or visit {LINK_SUBSCRIPTION}")
        else:
            click.echo(f"\nError: {err}")
            click.echo(f"Check the key and try again, or visit {LINK_SUBSCRIPTION}")
        click.echo()
        return

    click.echo("\nLicense activated successfully.")
    click.echo("─" * 54)
    membership = get_membership()
    _show_membership(membership)
    _prompt_precompute()

    from rewindex.config.loader import load_config
    from rewindex.daemon.runner import restart_daemon
    config = load_config()
    restart_daemon(config)


def _deactivate() -> None:
    from rewindex.license import deactivate_license, get_membership

    try:
        deactivate_license()
    except ConnectionError:
        click.echo("\nError: could not reach license server.")
        click.echo("Check your connection and try again.")
        click.echo()
        return
    except ValueError as e:
        click.echo(f"\nError: {e}")
        click.echo()
        return

    click.echo("\nLicense deactivated successfully.")
    click.echo("This machine is now on the Free plan.")
    click.echo("─" * 54)
    membership = get_membership()
    _show_membership(membership)

    from rewindex.config.loader import load_config
    from rewindex.daemon.runner import restart_daemon
    config = load_config()
    restart_daemon(config)


def _show_membership(membership: dict) -> None:
    from rewindex.config.loader import load_config
    from rewindex.config.defaults import DEFAULT_SESSION_MAX
    from rewindex.utils.formatting import fmt_date
    from rewindex.license import _read_license_data

    plan = membership.get("plan", "Free")
    is_pro = plan == "Pro"

    config = load_config()
    current_max = config.get("session_max", DEFAULT_SESSION_MAX)

    click.echo("\nMembership")
    click.echo("─" * 54)
    click.echo(f"Plan      : {plan}")

    workspaces = config.get("workspaces", [])
    workspace_count = len(workspaces)

    if is_pro:
        status = membership.get("status", "active")
        expires_raw = membership.get("expires_at", "")
        expires = fmt_date(expires_raw) if expires_raw else "No expiry"
        click.echo(f"Status    : {status}")
        click.echo(f"Expires   : {expires}")

        license_data = _read_license_data()
        if license_data.get("instance_id"):
            click.echo(f"Device    : activated")

        click.echo()
        click.echo(f"Workspaces: Unlimited ({workspace_count}/Unlimited)")
    else:
        click.echo()
        click.echo(f"Workspaces: 1 max ({workspace_count}/1)")

    click.echo(f"History   : Unlimited sessions (currently keeping {current_max})")

    if is_pro:
        click.echo()
        click.echo(f"Deactivate: rewindex member --deactivate")
        click.echo(f"Manage    : {LINK_SUBSCRIPTION}")
    else:
        click.echo()
        click.echo(f"License   : rewindex member --license [key]")
        click.echo(f"Upgrade   : {LINK_PRICING}")
    click.echo()


def _prompt_precompute() -> None:
    from rewindex.config.loader import load_config, save_config

    config = load_config()
    if config.get("precompute_enabled", False):
        return

    click.echo()
    click.echo("Pro feature: Pre-compute fullbase")
    click.echo("Speeds up rewind by pre-computing full snapshots periodically.")

    if not os.isatty(0):
        click.echo("Enable with: rewindex setting precompute on")
        return

    import questionary
    enable = questionary.confirm("Enable pre-compute fullbase?", default=True).ask()

    if enable:
        config["precompute_enabled"] = True
        save_config(config)
        click.echo("Pre-compute fullbase enabled.")
    else:
        click.echo("You can enable it later with: rewindex setting precompute on")
