# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import sys

import click


def _is_case_sensitive_fs() -> bool:
    return sys.platform != "win32" and sys.platform != "darwin"


def _normalize(path: str) -> str:
    return path if _is_case_sensitive_fs() else os.path.normcase(path)


def _detect_workspace_from_cwd(workspaces: list) -> str | None:
    """Return workspace name whose watched folder best matches CWD (longest prefix = most specific)."""
    cwd = _normalize(os.path.realpath(os.getcwd()))
    best_name: str | None = None
    best_len: int = -1
    for p in workspaces:
        for folder in p.get("folders", []):
            folder_real = _normalize(os.path.realpath(os.path.expanduser(folder)))
            if cwd == folder_real or cwd.startswith(folder_real + os.sep):
                if len(folder_real) > best_len:
                    best_len = len(folder_real)
                    best_name = p["name"]
    return best_name


def _print_no_workspace_hint(workspaces: list) -> None:
    click.echo("Not inside any watched workspace folder.")
    click.echo("Available workspaces:")
    for i, p in enumerate(workspaces):
        click.echo(f"  WS{i+1}  {p['name']}")
    click.echo("")
    click.echo("Use -p to specify:  rewindex log -p WS1")


def _print_workspace_header(name: str, workspaces: list) -> None:
    ws_id = next((f"WS{i+1}" for i, p in enumerate(workspaces) if p["name"] == name), "")
    click.echo(f"\nCurrent Workspace : {ws_id} | {name}")


def _warn_if_over_limit(resolved_name: str, workspaces: list) -> None:
    from rewindex.license import is_pro
    from rewindex.config.defaults import FREE_MAX_WORKSPACES
    if is_pro():
        return
    for i, p in enumerate(workspaces):
        if p["name"] == resolved_name and i >= FREE_MAX_WORKSPACES:
            from rewindex.config.urls import LINK_SUBSCRIPTION
            allowed = [workspaces[j]["name"] for j in range(min(FREE_MAX_WORKSPACES, len(workspaces)))]
            ws_ids = ", ".join(f"WS{j+1}" for j in range(min(FREE_MAX_WORKSPACES, len(workspaces))))
            click.echo(f"\nFree plan: only {ws_ids} ({', '.join(allowed)}) is being watched.")
            click.echo(f"Upgrade to Pro (unlimited workspaces): {LINK_SUBSCRIPTION}\n")
            return


def is_workspace_paused(workspace_name: str, workspaces: list) -> bool:
    from rewindex.license import is_pro
    from rewindex.config.defaults import FREE_MAX_WORKSPACES
    if is_pro():
        return False
    for i, p in enumerate(workspaces):
        if p["name"] == workspace_name and i >= FREE_MAX_WORKSPACES:
            return True
    return False


def check_workspace_paused(workspace_name: str, workspaces: list) -> bool:
    """Return True if workspace is paused (over free limit). False if OK."""
    return is_workspace_paused(workspace_name, workspaces)


def resolve_workspace(workspaces: list, name: str | None, interactive: bool = True, show_header: bool = True) -> str | None:
    """
    Resolve workspace name from CLI input.
    - name provided   -> find matching workspace or print error
    - name is None    -> detect from CWD (longest match); if no match, print hint and return None
    Returns workspace name, or None if caller should exit.
    """
    if name is not None:
        from rewindex.utils.id_parse import parse_workspace_ref
        resolved_name = parse_workspace_ref(name, workspaces)
        if resolved_name is None:
            click.echo(f"Workspace '{name}' not found.")
            click.echo("Available: " + ", ".join(f"WS{i+1} {p['name']}" for i, p in enumerate(workspaces)))
            return None
        for p in workspaces:
            if p["name"] == resolved_name:
                if show_header:
                    _print_workspace_header(resolved_name, workspaces)
                _warn_if_over_limit(resolved_name, workspaces)
                return resolved_name
        click.echo(f"Workspace '{name}' not found.")
        click.echo("Available: " + ", ".join(f"WS{i+1} {p['name']}" for i, p in enumerate(workspaces)))
        return None

    detected = _detect_workspace_from_cwd(workspaces)
    if detected:
        if show_header:
            _print_workspace_header(detected, workspaces)
        _warn_if_over_limit(detected, workspaces)
        return detected

    if len(workspaces) == 1:
        resolved_name = workspaces[0]["name"]
        if show_header:
            _print_workspace_header(resolved_name, workspaces)
        return resolved_name

    _print_no_workspace_hint(workspaces)
    return None
