# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import time

import click

from rewindex.config.loader import load_config
from rewindex.daemon.runner import is_running, restart_daemon


@click.command()
def restart_cmd() -> None:
    """Restart the daemon."""
    from rewindex.daemon.runner import _print_workspace_list

    config = load_config()
    click.echo("Restarting…")

    try:
        restart_daemon(config, quiet=True)
    except Exception as e:
        click.echo(f"\nError: failed to restart daemon — {e}")
        click.echo("Try `rewindex stop` then `rewindex start`.")
        return

    time.sleep(2)

    if is_running():
        click.echo("\nRewindex restarted.")
        _print_workspace_list(config)
        click.echo("Daemon is ready.")
    else:
        click.echo("\nError: daemon did not start.")
        click.echo("Check logs or try `rewindex start`.")
