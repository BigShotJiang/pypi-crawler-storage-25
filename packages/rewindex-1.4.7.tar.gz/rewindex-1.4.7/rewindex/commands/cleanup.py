# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import shutil

import click

from rewindex.config.loader import load_config, save_config
from rewindex.config.defaults import SNAPSHOTS_DIR, TRASH_DIR
from rewindex.daemon.runner import restart_daemon


@click.command()
@click.option("--trash", is_flag=True, help="Show or manage trashed workspaces.")
@click.option("--excluded", is_flag=True, help="Remove snapshots of files matching current exclude patterns.")
@click.option("--dry-run", is_flag=True, help="Show what would be deleted without deleting.")
@click.option("--yes", is_flag=True, help="Skip confirmation prompt.")
@click.argument("action", default=None, required=False)
@click.argument("target", default=None, required=False)
def cleanup_cmd(trash: bool, excluded: bool, dry_run: bool, yes: bool, action: str | None, target: str | None) -> None:
    """Clean up snapshot data.

    \b
    rewindex cleanup --trash                         show trashed workspaces
    rewindex cleanup --trash --yes                   permanently delete all
    rewindex cleanup --trash restore <name|WSID>     restore a trashed workspace
    rewindex cleanup --excluded                      show files matching exclude patterns
    rewindex cleanup --excluded --yes                delete their snapshots
    rewindex cleanup --excluded --dry-run            preview without deleting
    """
    if excluded:
        _cleanup_excluded(dry_run=dry_run, yes=yes)
        return

    if not trash:
        click.echo("Usage: rewindex cleanup [--trash | --excluded]")
        click.echo("  --trash              show trashed workspaces")
        click.echo("  --trash --yes        permanently delete all")
        click.echo("  --trash restore <name>  restore a workspace")
        click.echo("  --excluded           show files matching exclude patterns")
        click.echo("  --excluded --yes     delete their snapshots")
        click.echo("  --excluded --dry-run preview without deleting")
        return

    if action and action.lower() == "restore":
        if not target:
            click.echo("Error: specify a workspace name to restore.")
            return
        _restore_workspace(target)
        return

    trashed = _list_trash()
    if not trashed:
        click.echo("\nTrash is empty.")
        click.echo()
        return

    if yes:
        _delete_all_trash(trashed)
        return

    click.echo("\nTrash contents")
    click.echo("─" * 54)
    for name, snap_count, trashed_at in trashed:
        click.echo(f"  {name:<20} {snap_count} snaps   trashed {trashed_at}")
    click.echo()
    click.echo("To restore: rewindex cleanup --trash restore <name>")
    click.echo("To delete permanently: rewindex cleanup --trash --yes")
    click.echo()


def _list_trash() -> list[tuple[str, int, str]]:
    if not os.path.isdir(TRASH_DIR):
        return []
    result = []
    for name in sorted(os.listdir(TRASH_DIR)):
        path = os.path.join(TRASH_DIR, name)
        if not os.path.isdir(path):
            continue
        snap_count = sum(1 for _ in _iter_files(path))
        mtime = os.path.getmtime(path)
        from rewindex.utils.formatting import fmt_date
        from datetime import datetime, timezone
        trashed_at = fmt_date(datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat())
        result.append((name, snap_count, trashed_at))
    return result


def _iter_files(path: str):
    for root, dirs, files in os.walk(path):
        for f in files:
            yield os.path.join(root, f)


def _delete_all_trash(trashed: list) -> None:
    click.echo()
    for name, snap_count, _ in trashed:
        path = os.path.join(TRASH_DIR, name)
        shutil.rmtree(path, ignore_errors=True)
        click.echo(f"Deleted: {name} ({snap_count} snaps)")
    click.echo("\nTrash cleared.")
    click.echo()


def _restore_workspace(name: str) -> None:
    if not os.path.isdir(TRASH_DIR):
        click.echo(f'\nError: "{name}" not found in trash.')
        click.echo()
        return

    trash_path = os.path.join(TRASH_DIR, name)
    if not os.path.isdir(trash_path):
        click.echo(f'\nError: "{name}" not found in trash.')
        click.echo()
        return

    dest = os.path.join(SNAPSHOTS_DIR, name)
    shutil.move(trash_path, dest)

    config = load_config()
    existing_names = [p["name"] for p in config.get("workspaces", [])]
    if name not in existing_names:
        config["workspaces"].append({"name": name, "folders": []})
        save_config(config)

    ws = next((p for p in config["workspaces"] if p["name"] == name), None)
    folders = ws.get("folders", []) if ws else []

    click.echo(f'\nWorkspace "{name}" restored.')
    if folders:
        click.echo("Daemon now watching:")
        for f in folders:
            click.echo(f"  {f}")
    else:
        click.echo("Note: you may need to re-add watched folders with `rewindex workspace add-folder`.")
    click.echo()
    restart_daemon(config)


def _cleanup_excluded(dry_run: bool = False, yes: bool = False) -> None:
    """Remove snapshots of files that match current exclusion patterns."""
    import fnmatch
    import sqlite3

    from rewindex.config.defaults import SECURITY_EXCLUDE, SNAPSHOTS_DIR

    config = load_config()
    workspaces = config.get("workspaces", [])
    global_exclude = config.get("global_exclude", [])

    if not workspaces:
        click.echo("\nNo workspaces configured.")
        click.echo()
        return

    total_matched = 0
    total_snaps = 0
    matches_by_ws: list[tuple[str, list[dict]]] = []

    for ws in workspaces:
        ws_name = ws["name"]
        ws_exclude = ws.get("workspace_exclude", [])
        all_patterns = SECURITY_EXCLUDE + global_exclude + ws_exclude

        db_path = os.path.join(SNAPSHOTS_DIR, ws_name, "rewindex.db")
        if not os.path.exists(db_path):
            continue

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT uid, file_id, filepath, filename FROM file_registry WHERE workspace = ?",
            (ws_name,),
        ).fetchall()

        matched = []
        for row in rows:
            filepath = row["filepath"]
            filename = row["filename"]
            for pat in all_patterns:
                if fnmatch.fnmatch(filename, pat):
                    snap_count = conn.execute(
                        "SELECT COUNT(*) as cnt FROM file WHERE file_registry_uid = ?",
                        (row["uid"],),
                    ).fetchone()["cnt"]
                    matched.append({
                        "reg_uid": row["uid"],
                        "file_id": row["file_id"],
                        "filepath": filepath,
                        "pattern": pat,
                        "snap_count": snap_count,
                    })
                    total_snaps += snap_count
                    break
                if pat.endswith("/") and (pat[:-1] in filepath.split(os.sep)):
                    snap_count = conn.execute(
                        "SELECT COUNT(*) as cnt FROM file WHERE file_registry_uid = ?",
                        (row["uid"],),
                    ).fetchone()["cnt"]
                    matched.append({
                        "reg_uid": row["uid"],
                        "file_id": row["file_id"],
                        "filepath": filepath,
                        "pattern": pat,
                        "snap_count": snap_count,
                    })
                    total_snaps += snap_count
                    break

        conn.close()
        if matched:
            matches_by_ws.append((ws_name, matched))
            total_matched += len(matched)

    if total_matched == 0:
        click.echo("\nNo tracked files match current exclusion patterns.")
        click.echo()
        return

    click.echo(f"\nFound {total_matched} file(s) matching exclusion patterns ({total_snaps} snapshots total):")
    click.echo()
    for ws_name, matched in matches_by_ws:
        click.echo(f"  [{ws_name}]")
        for m in matched:
            click.echo(f"    {m['file_id']}  {m['filepath']:<40}  {m['snap_count']} snaps  (pattern: {m['pattern']})")
    click.echo()

    total_all = sum(
        sqlite3.connect(os.path.join(SNAPSHOTS_DIR, ws["name"], "rewindex.db")).execute(
            "SELECT COUNT(*) FROM file"
        ).fetchone()[0]
        for ws in workspaces
        if os.path.exists(os.path.join(SNAPSHOTS_DIR, ws["name"], "rewindex.db"))
    )

    if total_all > 0 and total_snaps / total_all > 0.2:
        click.echo(f"  Warning: this would delete {total_snaps}/{total_all} snapshots ({total_snaps*100//total_all}% of total).")
        click.echo()

    if dry_run:
        click.echo("Dry run: no changes made.")
        click.echo()
        return

    if not yes:
        click.echo("Run with --yes to delete, or --dry-run to preview.")
        click.echo()
        return

    for ws_name, matched in matches_by_ws:
        db_path = os.path.join(SNAPSHOTS_DIR, ws_name, "rewindex.db")
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        deleted_snaps = 0
        deleted_files = 0

        for m in matched:
            snap_dir = os.path.join(SNAPSHOTS_DIR, ws_name, "snapshots")
            snaps = conn.execute(
                "SELECT uid FROM file WHERE file_registry_uid = ?",
                (m["reg_uid"],),
            ).fetchall()

            for snap in snaps:
                snap_id = snap["uid"]
                for ext in (".full.gz", ".diff.gz", ".full", ".diff"):
                    snap_file = os.path.join(snap_dir, f"{snap_id:04d}", m["filepath"] + ext)
                    if os.path.exists(snap_file):
                        os.remove(snap_file)

            conn.execute("DELETE FROM file WHERE file_registry_uid = ?", (m["reg_uid"],))
            conn.execute("DELETE FROM file_registry WHERE uid = ?", (m["reg_uid"],))
            deleted_snaps += m["snap_count"]
            deleted_files += 1

        conn.commit()
        conn.close()
        click.echo(f"  [{ws_name}] Deleted {deleted_files} file(s), {deleted_snaps} snapshot(s).")

    click.echo(f"\nDone. Removed {total_snaps} snapshot(s) from {total_matched} excluded file(s).")
    click.echo()
