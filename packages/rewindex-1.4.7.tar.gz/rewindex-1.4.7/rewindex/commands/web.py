# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click


@click.command("web")
@click.option("-p", "--port", default=None, type=int, help="Port number (default: 9009)")
def web_cmd(port):
    """Start the Rewindex dashboard."""
    import os
    if port:
        os.environ["REWINDEX_WEB_PORT"] = str(port)

    from importlib.metadata import version as pkg_version
    current = pkg_version("rewindex")
    try:
        import urllib.request, json
        resp = urllib.request.urlopen("https://pypi.org/pypi/rewindex/json", timeout=3)
        latest = json.loads(resp.read())["info"]["version"]
        if latest != current:
            click.echo(f"  Update available: {current} -> {latest}")
            click.echo(f"  Run: pipx upgrade rewindex\n")
    except Exception:
        pass

    from rewindex.web import main
    main()
