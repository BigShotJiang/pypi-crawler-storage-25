# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import click

from rewindex.config.loader import load_config
from rewindex.db.connection import get_connection
from rewindex.commands._workspace import resolve_workspace, check_workspace_paused


def _safe_confirm(prompt: str) -> bool:
    try:
        import questionary
        result = questionary.confirm(prompt, default=False).ask()
        return bool(result)
    except (UnicodeDecodeError, EOFError, KeyboardInterrupt):
        return False


@click.command()
@click.argument("target", required=False, default=None, type=str)
@click.argument("version", required=False, default=None, type=str)
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
@click.option("--yes", "-y", is_flag=True, help="Confirm the operation (required).")
def rewind_cmd(target: str | None, version: str | None, workspace: str | None, yes: bool) -> None:
    """Restore to a previous state.

    \b
    rewindex rewind <SS> --yes              restore entire workspace to session state
    rewindex rewind <FileID> <v> --yes      restore one file to a specific version
    rewindex rewind SN -<n> --yes           undo last N snapshots (all affected files)
    """
    if not target:
        click.echo("\nMissing target. Usage:")
        click.echo("  rewindex rewind <SS> --yes              restore entire workspace to session state")
        click.echo("  rewindex rewind <FileID> <v> --yes      restore one file to a specific version")
        click.echo("  rewindex rewind SN -<n> --yes           undo last N snapshots (all affected files)")
        click.echo()
        return

    from rewindex.utils.id_parse import (
        is_session_target, is_snap_target, is_file_id,
        parse_session_id, parse_snap_id, parse_relative_snap,
        fmt_session, fmt_snap,
    )
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.db.queries import (
        get_session_by_uid,
        get_oldest_session,
        get_latest_session,
        get_all_tracked_files,
        get_latest_version_at_session,
        get_file_registry_by_id,
        get_file_version_range,
        resolve_file_version,
        get_file_version,
        get_latest_file_version,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file

    config = load_config()
    all_workspaces = config.get("workspaces", [])
    if not all_workspaces:
        click.echo("No workspaces configured.")
        return

    resolved = resolve_workspace(all_workspaces, workspace or None)
    if resolved is None:
        return
    if check_workspace_paused(resolved, all_workspaces):
        return

    proj = next(p for p in all_workspaces if p["name"] == resolved)
    folders = proj.get("folders", [])

    conn = get_connection(resolved)
    try:
        # Relative snap: SN -1, SN -5
        try:
            rel = parse_relative_snap(target + (" " + version if version else ""))
        except ValueError as e:
            click.echo(f"Error: {e}")
            return
        if rel is not None:
            _rewind_relative(conn, resolved, proj, rel, yes)
            return

        # Session rewind: SS3
        if is_session_target(target):
            try:
                ss_uid = parse_session_id(target)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
            _rewind_session(conn, resolved, proj, ss_uid, yes)
            return

        # Snap rewind: SN42 — currently disabled
        if is_snap_target(target):
            click.echo(f'\nError: "rewind {target}" is not supported.')
            click.echo("Use one of:")
            click.echo("  rewindex rewind SN -<n> --yes     rewind back N snapshots")
            click.echo("  rewindex rewind <SS> --yes        restore workspace to session state")
            click.echo("  rewindex rewind <FileID> <v> --yes  restore one file to a version")
            click.echo()
            return

        # File rewind: D1VS v4
        if is_file_id(target):
            _rewind_file(conn, resolved, proj, target, version, yes)
            return

        click.echo(f'Error: unrecognized target "{target}".')
        click.echo("Usage: rewindex rewind <SS|SN|FileID> [version] --yes")
    finally:
        conn.close()


def _rewind_session(conn, workspace: str, proj: dict, session_uid: int, yes: bool) -> None:
    from rewindex.utils.id_parse import fmt_session
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.db.queries import (
        get_session_by_uid, get_oldest_session, get_latest_session,
        get_all_tracked_files, get_latest_version_at_session,
        get_files_in_session, create_forced_session, close_session,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file
    from datetime import datetime, timezone

    session = get_session_by_uid(conn, session_uid)
    if not session:
        oldest = get_oldest_session(conn, workspace)
        latest = get_latest_session(conn, workspace)
        if oldest and latest:
            click.echo(f"\nError: {fmt_session(session_uid)} not found — may have been trimmed.")
            click.echo(f"Available: {fmt_session(oldest['uid'])} (oldest) → {fmt_session(latest['uid'])} (latest)")
            click.echo("To keep more history: rewindex setting --safe N --max M")
        else:
            click.echo(f"\nError: {fmt_session(session_uid)} not found.")
        click.echo()
        return

    from rewindex.snapshot.engine import hash_file

    folders = proj.get("folders", [])
    tracked = get_all_tracked_files(conn, workspace)
    latest_session = get_latest_session(conn, workspace)

    preview = []
    for reg in tracked:
        ver = get_latest_version_at_session(conn, reg["uid"], session_uid)
        latest_ver = conn.execute(
            "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 ORDER BY uid DESC LIMIT 1",
            (reg["uid"],)
        ).fetchone()

        if ver is None and latest_ver is None:
            continue

        filepath = reg["filepath"]
        target_filepath = ver["filepath"] if ver and ver["filepath"] else filepath
        abs_path = _resolve_abs_path(reg, folders)

        if ver is None or ver["is_deleted"]:
            if latest_ver and not latest_ver["is_deleted"]:
                if abs_path and os.path.exists(abs_path):
                    preview.append((reg, filepath, "remove", None, latest_ver, target_filepath))
                else:
                    preview.append((reg, filepath, "unchanged", None, latest_ver, target_filepath))
            else:
                preview.append((reg, filepath, "unchanged", None, latest_ver, target_filepath))
        else:
            disk_hash = None
            if abs_path and os.path.exists(abs_path):
                try:
                    disk_hash = hash_file(abs_path)
                except OSError:
                    pass
            path_changed = target_filepath != filepath
            if disk_hash == ver["hash"] and not path_changed:
                preview.append((reg, filepath, "unchanged", ver, latest_ver, target_filepath))
            else:
                preview.append((reg, filepath, "revert", ver, latest_ver, target_filepath))

    header = fmt_date_header()
    click.echo(f"\nRewind preview — {fmt_session(session_uid)}   {fmt_date(session['created_at'])}  {header}")
    click.echo("─" * 56)
    for reg, filepath, action, ver, cur, target_fp in preview:
        if action == "unchanged":
            click.echo(f"  {reg['file_id']}   {filepath:<30} unchanged")
        elif action == "remove":
            cur_v = f"v{cur['file_version']}" if cur else ""
            click.echo(f"  {reg['file_id']}   {filepath:<30} will be removed ({cur_v})")
        elif action == "revert":
            cur_v = f"v{cur['file_version']}" if cur else ""
            move_str = f"  (move → {target_fp})" if target_fp != filepath else ""
            click.echo(f"  {reg['file_id']}   {filepath:<30} will revert {cur_v} to v{ver['file_version']}{move_str}")

    has_changes = any(a in ("remove", "revert") for _, _, a, _, _, _ in preview)
    if not has_changes:
        click.echo()
        click.echo("Files are the same. Nothing to change.")
        click.echo("Try another Session, SnapID, or FileID.")
        click.echo()
        return

    current_ss = fmt_session(latest_session['uid']) if latest_session else "—"
    next_uid = conn.execute("SELECT MAX(uid) + 1 as next FROM sessions").fetchone()["next"] or 1

    if not yes:
        click.echo()
        click.echo(f"Currently at {current_ss}. Rewind to {fmt_session(session_uid)} (will be saved as {fmt_session(next_uid)}).")
        click.echo()
        if not _safe_confirm("Continue?"):
            click.echo()
            click.echo("Cancelled.")
            click.echo()
            return

    created_at = datetime.now(timezone.utc).isoformat()
    new_session_uid = create_forced_session(conn, workspace, created_at)

    from rewindex.db.queries import update_file_note, update_session_note

    for reg, filepath, action, ver, _cur, target_fp in preview:
        if action == "remove":
            abs_path = _resolve_abs_path(reg, folders)
            if abs_path and os.path.exists(abs_path):
                os.remove(abs_path)
                new_uid = snapshot_file(conn, workspace, reg["folder_path"], abs_path,
                              session_uid=new_session_uid)
                if new_uid:
                    cur_v = _cur["file_version"] if _cur else "?"
                    update_file_note(conn, new_uid,
                        f"rewind from {fmt_session(latest_session['uid'])} to {fmt_session(session_uid)}, removed v{cur_v}")
        elif action == "revert":
            abs_path, moved_from = _move_file_if_needed(conn, reg, target_fp, folders)
            lines = reconstruct(conn, reg["uid"], ver["uid"])
            if abs_path:
                os.makedirs(os.path.dirname(abs_path), exist_ok=True)
                with open(abs_path, "w", encoding="utf-8") as f:
                    f.writelines(lines)
                new_uid = snapshot_file(conn, workspace, reg["folder_path"], abs_path,
                                        session_uid=new_session_uid)
                if not new_uid and moved_from:
                    from rewindex.snapshot.engine import record_move as _record_move
                    new_uid = _record_move(conn, workspace, reg["folder_path"], abs_path,
                                 moved_from, session_uid=new_session_uid)
                if new_uid:
                    saved_row = conn.execute("SELECT file_version FROM file WHERE uid = ?", (new_uid,)).fetchone()
                    saved_v = saved_row["file_version"] if saved_row else "?"
                    cur_v = _cur["file_version"] if _cur else "?"
                    note = f"rewind from v{cur_v} to v{ver['file_version']}, saved as v{saved_v}"
                    if moved_from:
                        note += f" | moved from {moved_from}"
                    update_file_note(conn, new_uid, note)

    files_in_new = get_files_in_session(conn, new_session_uid)
    if not files_in_new:
        conn.execute("DELETE FROM sessions WHERE uid = ?", (new_session_uid,))
        conn.commit()
        click.echo(f"\nWorkspace already at {fmt_session(session_uid)} state — nothing changed.")
    else:
        close_session(conn, new_session_uid)
        update_session_note(conn, new_session_uid,
            f"rewind from {fmt_session(latest_session['uid'])} to {fmt_session(session_uid)}, saved as {fmt_session(new_session_uid)}")
        click.echo(f"\nReverting to {fmt_session(session_uid)} state...  (saved as {fmt_session(new_session_uid)})")
        click.echo()
        click.echo("Revert complete.")
    from rewindex.plugin import fire
    fire("on_rewind",
         target=fmt_session(session_uid),
         files_restored=[fp for _, fp, action, _, _, _ in preview if action in ("remove", "revert")])
    click.echo()


def _rewind_snap(conn, workspace: str, proj: dict, snap_uid: int, yes: bool) -> None:
    from rewindex.utils.id_parse import fmt_snap, fmt_session
    from rewindex.db.queries import get_file_version, get_latest_session, create_forced_session
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file
    from datetime import datetime, timezone

    snap = get_file_version(conn, snap_uid)
    if not snap:
        click.echo(f"Error: {fmt_snap(snap_uid)} not found.")
        return

    reg = conn.execute("SELECT * FROM file_registry WHERE uid = ?", (snap["file_registry_uid"],)).fetchone()
    filepath = reg["filepath"]
    target_filepath = snap["filepath"] if snap["filepath"] else filepath
    folders = proj.get("folders", [])
    abs_path = _resolve_abs_path(reg, folders)

    if not abs_path:
        click.echo(f"Error: cannot locate file {filepath} in workspace folders.")
        return

    from rewindex.db.queries import get_latest_file_version
    latest = get_latest_file_version(conn, reg["uid"])
    if latest and latest["hash"] == snap["hash"] and target_filepath == filepath:
        click.echo(f"\n{reg['file_id']} is already at {fmt_snap(snap_uid)} (v{snap['file_version']}) — nothing to change.")
        click.echo()
        return

    move_str = f"  (move → {target_filepath})" if target_filepath != filepath else ""
    click.echo(f"\nRewind preview")
    click.echo("─" * 54)
    click.echo(f"  {reg['file_id']}   {filepath}   will revert to {fmt_snap(snap_uid)} (v{snap['file_version']}){move_str}")

    if not yes:
        latest_session = get_latest_session(conn, workspace)
        current_ss = fmt_session(latest_session['uid']) if latest_session else "—"
        click.echo()
        click.echo(f"Currently at {current_ss}. Rewind {reg['file_id']} to {fmt_snap(snap_uid)}.")
        if not _safe_confirm("Continue?"):
            click.echo()
            click.echo("Cancelled.")
            click.echo()
            return

    abs_path, moved_from = _move_file_if_needed(conn, reg, target_filepath, folders)
    lines = reconstruct(conn, reg["uid"], snap["uid"])

    created_at = datetime.now(timezone.utc).isoformat()
    new_session_uid = create_forced_session(conn, workspace, created_at)

    if abs_path:
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        with open(abs_path, "w", encoding="utf-8") as f:
            f.writelines(lines)

    new_uid = snapshot_file(conn, workspace, reg["folder_path"], abs_path,
                            session_uid=new_session_uid)

    if not new_uid and moved_from:
        from rewindex.snapshot.engine import record_move as _record_move
        new_uid = _record_move(conn, workspace, reg["folder_path"], abs_path,
                               moved_from, session_uid=new_session_uid)
    elif new_uid and moved_from:
        from rewindex.db.queries import update_file_note
        update_file_note(conn, new_uid, f"moved from {moved_from}")

    if not new_uid:
        conn.execute("DELETE FROM sessions WHERE uid = ?", (new_session_uid,))
        conn.commit()

    display_fp = target_filepath if target_filepath != filepath else filepath
    saved_str = f"(saved as {fmt_snap(new_uid)})" if new_uid else ""
    click.echo(f"\n  {reg['file_id']}   {display_fp}   reverted to {fmt_snap(snap_uid)}   {saved_str}")
    click.echo("\nRevert complete.")
    click.echo()


def _rewind_file(conn, workspace: str, proj: dict, file_id_str: str, version_str: str | None, yes: bool) -> None:
    from rewindex.utils.id_parse import fmt_session
    from rewindex.db.queries import (
        get_file_registry_by_id, get_file_version_range,
        resolve_file_version, get_latest_file_version,
        get_latest_session, create_forced_session,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file
    from datetime import datetime, timezone
    import re

    reg = get_file_registry_by_id(conn, workspace, file_id_str)
    if not reg:
        click.echo(f'Error: unknown FileID "{file_id_str}".')
        return

    min_v, max_v = get_file_version_range(conn, reg["uid"])
    if min_v is None:
        click.echo(f"No versions found for {file_id_str}.")
        return

    if version_str is None or version_str.strip().lower() == "latest":
        target_ver = max_v
    else:
        m = re.match(r'^v?(\d+)$', version_str.strip())
        if m:
            target_ver = int(m.group(1))
        else:
            click.echo(f'Error: invalid version "{version_str}". Use vN or "latest".')
            return

    latest = get_latest_file_version(conn, reg["uid"])
    if latest and latest["file_version"] == target_ver:
        click.echo(f"\nError: {file_id_str} is already at v{target_ver} — nothing to restore.")
        click.echo()
        return

    target_row = resolve_file_version(conn, workspace, file_id_str, target_ver)
    if not target_row:
        click.echo(f"\nError: {file_id_str} v{target_ver} not found — version may have been trimmed.")
        click.echo(f"Available: v{min_v} (oldest) → v{max_v} (latest)")
        click.echo("To keep more history: rewindex setting --safe N --max M")
        click.echo()
        return

    filepath = reg["filepath"]
    target_filepath = target_row["filepath"] if target_row["filepath"] else filepath
    folders = proj.get("folders", [])
    abs_path = _resolve_abs_path(reg, folders)

    if not abs_path:
        click.echo(f"Error: cannot locate file {filepath} in workspace folders.")
        return

    if latest["hash"] == target_row["hash"] and target_filepath == filepath:
        click.echo(f"\n{file_id_str} v{latest['file_version']} and v{target_ver} are identical — nothing to change.")
        click.echo()
        return

    move_str = f"  (move → {target_filepath})" if target_filepath != filepath else ""
    click.echo(f"\nRewind preview")
    click.echo("─" * 54)
    click.echo(f"  {reg['file_id']}   {filepath}   v{latest['file_version']} → v{target_ver}{move_str}")

    if not yes:
        latest_session = get_latest_session(conn, workspace)
        current_ss = fmt_session(latest_session['uid']) if latest_session else "—"
        click.echo()
        click.echo(f"Currently at {current_ss}. Rewind {reg['file_id']} from v{latest['file_version']} to v{target_ver} (will be saved as v{max_v + 1}).")
        if not _safe_confirm("Continue?"):
            click.echo()
            click.echo("Cancelled.")
            click.echo()
            return

    abs_path, moved_from = _move_file_if_needed(conn, reg, target_filepath, folders)
    lines = reconstruct(conn, reg["uid"], target_row["uid"])

    created_at = datetime.now(timezone.utc).isoformat()
    new_session_uid = create_forced_session(conn, workspace, created_at)

    if abs_path:
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        with open(abs_path, "w", encoding="utf-8") as f:
            f.writelines(lines)

    new_uid = snapshot_file(conn, workspace, reg["folder_path"], abs_path,
                            session_uid=new_session_uid)

    if not new_uid and moved_from:
        from rewindex.snapshot.engine import record_move
        new_uid = record_move(conn, workspace, reg["folder_path"], abs_path,
                              moved_from, session_uid=new_session_uid)

    if not new_uid:
        conn.execute("DELETE FROM sessions WHERE uid = ?", (new_session_uid,))
        conn.commit()

    if new_uid:
        from rewindex.db.queries import update_file_note
        saved_row = conn.execute("SELECT file_version FROM file WHERE uid = ?", (new_uid,)).fetchone()
        new_ver = saved_row["file_version"] if saved_row else target_ver
        note = f"rewind from v{latest['file_version']} to v{target_ver}, saved as v{new_ver}"
        if moved_from:
            note += f" | moved from {moved_from}"
        update_file_note(conn, new_uid, note)
    else:
        new_ver = target_ver
    display_fp = target_filepath if target_filepath != filepath else filepath

    click.echo(f"\n  {reg['file_id']}   {display_fp}   reverted to v{target_ver}   (saved as v{new_ver})")
    click.echo("\nRevert complete.")
    from rewindex.plugin import fire
    fire("on_rewind",
         target=f"{file_id_str} v{target_ver}",
         files_restored=[display_fp])
    click.echo()


def _rewind_relative(conn, workspace: str, proj: dict, n: int, yes: bool) -> None:
    """Undo the last N snapshots. All affected files are reverted to their
    state just before those N snapshots happened."""
    from rewindex.utils.id_parse import fmt_snap, fmt_session
    from rewindex.db.queries import get_latest_session, create_forced_session, get_files_in_session, close_session
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file, hash_file
    from datetime import datetime, timezone

    total = conn.execute("SELECT COUNT(*) as c FROM file WHERE is_corrupted = 0").fetchone()["c"]
    if n >= total:
        click.echo(f"Error: cannot rewind SN -{n} — only {total} snapshots exist.")
        return

    undone_rows = conn.execute(
        "SELECT * FROM file WHERE is_corrupted = 0 ORDER BY uid DESC LIMIT ?",
        (n,)
    ).fetchall()

    target_row = conn.execute(
        "SELECT * FROM file WHERE is_corrupted = 0 ORDER BY uid DESC LIMIT 1 OFFSET ?",
        (n,)
    ).fetchone()

    reg_uids = set()
    for r in undone_rows:
        reg_uids.add(r["file_registry_uid"])

    folders = proj.get("folders", [])
    preview = []

    for reg_uid in reg_uids:
        reg = conn.execute("SELECT * FROM file_registry WHERE uid = ?", (reg_uid,)).fetchone()
        filepath = reg["filepath"]

        prior = conn.execute(
            "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 AND uid <= ? ORDER BY uid DESC LIMIT 1",
            (reg_uid, target_row["uid"]),
        ).fetchone()

        latest = conn.execute(
            "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 ORDER BY uid DESC LIMIT 1",
            (reg_uid,),
        ).fetchone()

        if prior is None:
            abs_path = _resolve_abs_path(reg, folders)
            if abs_path and os.path.exists(abs_path):
                preview.append((reg, filepath, "remove", None, latest, filepath))
        else:
            target_fp = prior["filepath"] if prior["filepath"] else filepath
            disk_hash = None
            abs_path = _resolve_abs_path(reg, folders)
            if abs_path and os.path.exists(abs_path):
                try:
                    disk_hash = hash_file(abs_path)
                except OSError:
                    pass
            path_changed = target_fp != filepath
            if disk_hash == prior["hash"] and not path_changed:
                continue
            preview.append((reg, filepath, "revert", prior, latest, target_fp))

    if not preview:
        click.echo(f"\nNothing to change — last {n} snapshots have no effect on current files.")
        click.echo()
        return

    click.echo(f"\nRewind preview — undo last {n} snapshots (back to {fmt_snap(target_row['uid'])})")
    click.echo("─" * 56)
    for reg, filepath, action, ver, cur, target_fp in preview:
        if action == "remove":
            cur_v = f"v{cur['file_version']}" if cur else ""
            click.echo(f"  {reg['file_id']}   {filepath:<30} will be removed ({cur_v})")
        elif action == "revert":
            cur_v = f"v{cur['file_version']}" if cur else ""
            max_v = conn.execute(
                "SELECT MAX(file_version) as mv FROM file WHERE file_registry_uid = ?",
                (reg["uid"],)
            ).fetchone()["mv"] or 0
            save_v = f"v{max_v + 1}"
            move_str = f"  (move → {target_fp})" if target_fp != filepath else ""
            click.echo(f"  {reg['file_id']}   {filepath:<30} {cur_v} → {save_v} (revert to v{ver['file_version']}){move_str}")

    if not yes:
        latest_session = get_latest_session(conn, workspace)
        current_ss = fmt_session(latest_session['uid']) if latest_session else "—"
        click.echo()
        click.echo(f"Currently at {current_ss}. Undo {n} snapshots back to {fmt_snap(target_row['uid'])}.")
        if not _safe_confirm("Continue?"):
            click.echo()
            click.echo("Cancelled.")
            click.echo()
            return

    created_at = datetime.now(timezone.utc).isoformat()
    new_session_uid = create_forced_session(conn, workspace, created_at)

    for reg, filepath, action, ver, _cur, target_fp in preview:
        if action == "remove":
            abs_path = _resolve_abs_path(reg, folders)
            if abs_path and os.path.exists(abs_path):
                os.remove(abs_path)
                snapshot_file(conn, workspace, reg["folder_path"], abs_path,
                              session_uid=new_session_uid)
        elif action == "revert":
            abs_path, moved_from = _move_file_if_needed(conn, reg, target_fp, folders)
            lines = reconstruct(conn, reg["uid"], ver["uid"])
            if abs_path:
                os.makedirs(os.path.dirname(abs_path), exist_ok=True)
                with open(abs_path, "w", encoding="utf-8") as f:
                    f.writelines(lines)
                new_uid = snapshot_file(conn, workspace, reg["folder_path"], abs_path,
                                        session_uid=new_session_uid)
                if not new_uid and moved_from:
                    from rewindex.snapshot.engine import record_move as _record_move
                    new_uid = _record_move(conn, workspace, reg["folder_path"], abs_path,
                                 moved_from, session_uid=new_session_uid)
                if new_uid:
                    from rewindex.db.queries import update_file_note
                    saved_row = conn.execute("SELECT file_version FROM file WHERE uid = ?", (new_uid,)).fetchone()
                    saved_v = saved_row["file_version"] if saved_row else "?"
                    cur_v = _cur["file_version"] if _cur else "?"
                    note = f"rewind from v{cur_v} to v{ver['file_version']}, saved as v{saved_v}"
                    if moved_from:
                        note += f" | moved from {moved_from}"
                    update_file_note(conn, new_uid, note)

    files_in_new = get_files_in_session(conn, new_session_uid)
    if not files_in_new:
        conn.execute("DELETE FROM sessions WHERE uid = ?", (new_session_uid,))
        conn.commit()
        click.echo(f"\nAlready at {fmt_snap(target_row['uid'])} state — nothing changed.")
    else:
        close_session(conn, new_session_uid)
        click.echo()
        for reg, filepath, action, ver, _cur, target_fp in preview:
            display_fp = target_fp if target_fp != filepath else filepath
            if action == "remove":
                click.echo(f"  {reg['file_id']}   {display_fp}   removed")
            elif action == "revert":
                saved_v = conn.execute(
                    "SELECT file_version FROM file WHERE file_registry_uid = ? AND session_uid = ?",
                    (reg["uid"], new_session_uid)
                ).fetchone()
                sv = f"v{saved_v['file_version']}" if saved_v else ""
                click.echo(f"  {reg['file_id']}   {display_fp}   reverted to v{ver['file_version']}  (saved as {sv})")
        click.echo(f"\n  {len(files_in_new)} file(s) rewound.  (saved as {fmt_session(new_session_uid)})")
    click.echo("\nRevert complete.")
    click.echo()

    from rewindex.events import emit
    emit("rewind", target=target or "", workspace=workspace)
    from rewindex.plugin import fire
    fire("on_rewind",
         target=f"SN -{n}",
         files_restored=[fp for _, fp, action, _, _, _ in preview if action in ("remove", "revert")])


def _move_file_if_needed(conn, reg, target_filepath: str | None, folders: list[str]) -> tuple[str | None, str | None]:
    """If target version had a different filepath, move file back and update registry.
    Returns (abs_path, moved_from_filepath). moved_from is None if no move happened."""
    if not target_filepath or target_filepath == reg["filepath"]:
        return _resolve_abs_path(reg, folders), None

    old_filepath = reg["filepath"]
    current_abs = _resolve_abs_path(reg, folders)
    new_filename = target_filepath.rsplit("/", 1)[-1] if "/" in target_filepath else target_filepath

    conn.execute(
        "UPDATE file_registry SET filepath = ?, filename = ? WHERE uid = ?",
        (target_filepath, new_filename, reg["uid"]),
    )
    conn.commit()

    target_abs = os.path.join(reg["folder_path"], target_filepath) if reg["folder_path"] else None
    if not target_abs and folders:
        target_abs = os.path.join(os.path.realpath(os.path.expanduser(folders[0])), target_filepath)

    if current_abs and target_abs and os.path.exists(current_abs):
        os.makedirs(os.path.dirname(target_abs), exist_ok=True)
        os.rename(current_abs, target_abs)

    return target_abs, old_filepath


def _resolve_abs_path(reg: dict, folders: list[str] | None = None) -> str | None:
    if reg["folder_path"]:
        return os.path.join(reg["folder_path"], reg["filepath"])
    if folders:
        for folder in folders:
            folder = os.path.realpath(os.path.expanduser(folder))
            candidate = os.path.join(folder, reg["filepath"])
            if os.path.exists(candidate) or os.path.exists(os.path.dirname(candidate)):
                return candidate
        return os.path.join(os.path.realpath(os.path.expanduser(folders[0])), reg["filepath"])
    return None
