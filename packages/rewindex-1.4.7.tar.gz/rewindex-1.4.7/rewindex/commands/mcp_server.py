# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Rewindex MCP server — exposes Rewindex as structured tools for AI agents.

Transport: stdio (FastMCP default)
Start:     rewindex mcp
"""

import difflib
import json
import os
import re
from datetime import datetime, timezone
from typing import Optional

import click

# ---------------------------------------------------------------------------
# FastMCP setup
# ---------------------------------------------------------------------------

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "rewindex",
    instructions="""Rewindex — reduce the risk of AI breaking your code. Records every file change before you realize something broke. Audit and recover from your AI chat or the built-in dashboard.

## Core workflow (follow this order)

1. START OF TASK: call get_log to understand recent changes before touching any file.
2. AFTER EDITING: call create_snap with a descriptive note — every time, without being asked.
3. TO UNDO: call get_log → find the session → call rewind_session. Default to session-level undo.
4. WHEN WRONG: rewind immediately — never edit over a mistake.
5. AFTER A WORKING MILESTONE: call create_flag to mark the session as a named version (e.g. v1.0.0).
   Flag only when the work is substantial AND has been verified to work — not for minor edits.
   Rule of thumb: if the system was tested and the user could ship or demo this version, flag it.
   Do not flag every session — flag is a quality gate, not a quantity marker.

## Rewind hierarchy

rewind_session  ← DEFAULT. Reverts all files in a session atomically. Use this first.
rewind_file     ← SURGICAL ONLY. Single file, only when independent of other changed files.
rewind_relative ← When you know how many snapshots to undo but not the session.

## Flag system (version milestones)

Flags mark specific sessions as named versions for long-term reference.
Use flags to answer: "what was in v1.0?", "go back to the last release", "generate a changelog".
Description should be written in Markdown format (rendered in the dashboard).

Workflow to rewind to a flagged version:
  list_flags → find version → get session_id → rewind_session

Workflow to move a flag to a different session:
  move_flag — changes only the session link, preserves title/description/version.
  To also update description: show_flag → read old text → edit_flag with new text.

Workflow to generate changelog:
  export_flags → write to CHANGELOG.md

## Notes

add_note attaches a short description to a session, snap, or file version.
create_snap already accepts a note, so add_note is for updating or adding notes after the fact.

## Trash management

When a workspace is removed, its data moves to trash.
  list_trash → see trashed workspaces
  restore_trash → bring one back
  delete_trash → permanently remove all trashed data

## Code audit and debug workflow

Use these tools to trace when a bug was introduced or audit changes to a file:

  search_sessions_by_file("login.py") → all sessions that touched this file + their notes
  get_session_diff("SS42")            → full diff of every file changed in that session
  find_pattern_introduced("ORDER BY uid ASC", filepath_filter=".py") → which session first wrote this

Audit workflow:
  1. search_sessions_by_file → find sessions that touched the suspicious file
  2. get_session_diff → inspect the full change set of a session
  3. find_pattern_introduced → pinpoint exactly when a pattern entered the codebase
  4. find_version_by_pattern → narrow to a single file if you already know which one

These tools let you answer: "when was this bug introduced?", "what changed in this session?",
"which file first had this pattern?" — without reading diffs manually.

## Key principle

Sessions are the unit of work. Files that change together belong together.
Rewinding at session level prevents partial-state bugs automatically.
""",
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_workspaces():
    from rewindex.config.loader import load_config
    config = load_config()
    return config.get("workspaces", []), config


def _resolve(workspace: Optional[str]) -> Optional[dict]:
    """Resolve workspace name → workspace dict. Returns None with error dict if not found."""
    from rewindex.config.loader import load_config
    from rewindex.commands._workspace import resolve_workspace

    config = load_config()
    workspaces = config.get("workspaces", [])

    if not workspaces:
        return None, {"error": "No workspaces configured."}

    name = resolve_workspace(workspaces, workspace or None, interactive=False, show_header=False)
    if name is None:
        names = ", ".join(f"WS{i+1} {p['name']}" for i, p in enumerate(workspaces))
        return None, {"error": f"Workspace not found. Available: {names}"}

    proj = next((p for p in workspaces if p["name"] == name), None)
    if proj is None:
        return None, {"error": f"Workspace '{name}' not found."}

    return proj, None


def _get_conn(workspace_name: str):
    from rewindex.db.connection import get_connection
    return get_connection(workspace_name)


def _fmt_session(uid: int) -> str:
    return f"SS{uid}"


def _fmt_snap(uid: int) -> str:
    return f"SN{uid}"


def _row_to_dict(row) -> dict:
    """Convert sqlite3.Row to plain dict."""
    if row is None:
        return {}
    return dict(row)


def _rows_to_list(rows) -> list[dict]:
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Setup tool
# ---------------------------------------------------------------------------

@mcp.tool()
def setup_workspace(name: str, folder: str, license_key: Optional[str] = None) -> dict:
    """Add a new workspace to Rewindex and start the daemon.

    Args:
        name: Workspace name (no spaces recommended).
        folder: Absolute path to the folder to watch.
        license_key: Optional Pro license key to activate.

    Returns:
        dict with workspace_name, status, and any error.
    """
    import subprocess, sys

    result = {}

    # Optionally activate license
    if license_key:
        try:
            r = subprocess.run(
                [sys.executable, "-m", "rewindex", "member", "--activate", license_key],
                capture_output=True, text=True, timeout=30,
            )
            result["license"] = "activated" if r.returncode == 0 else r.stderr.strip()
        except Exception as e:
            result["license_error"] = str(e)

    # Add workspace
    try:
        r = subprocess.run(
            ["rewindex", "workspace", "add", name, folder],
            capture_output=True, text=True, timeout=30,
        )
        if r.returncode != 0:
            return {"error": r.stderr.strip() or r.stdout.strip(), "workspace_name": name}
        result["workspace_name"] = name
        result["folder"] = folder
        result["added"] = True
    except FileNotFoundError:
        return {"error": "rewindex CLI not found. Is it installed and in PATH?"}
    except Exception as e:
        return {"error": str(e)}

    # Start daemon
    try:
        r = subprocess.run(
            ["rewindex", "start"],
            capture_output=True, text=True, timeout=30,
        )
        result["daemon"] = "started" if r.returncode == 0 else "already_running"
    except Exception as e:
        result["daemon"] = f"error: {e}"

    result["status"] = "ok"
    return result


@mcp.tool()
def remove_workspace(name: str) -> dict:
    """Remove a workspace — snapshots moved to trash, not permanently deleted.

    Use list_trash to see trashed workspaces. Use restore_trash to recover.
    Use delete_trash to permanently delete.

    Args:
        name: Workspace name or WS ID (e.g. "MyProject" or "WS2").

    Returns:
        dict with success and workspace name, or error.
    """
    import subprocess
    r = subprocess.run(
        ["rewindex", "workspace", "remove", name, "--yes"],
        capture_output=True, text=True, timeout=30,
    )
    if r.returncode != 0:
        return {"error": r.stderr.strip() or r.stdout.strip()}
    return {"success": True, "workspace": name, "message": r.stdout.strip()}


@mcp.tool()
def rename_workspace(name: str, new_name: str) -> dict:
    """Rename a workspace.

    Args:
        name: Current workspace name or WS ID.
        new_name: New name for the workspace (no spaces recommended).

    Returns:
        dict with success, old name, and new name, or error.
    """
    import subprocess
    r = subprocess.run(
        ["rewindex", "workspace", "rename", name, new_name, "--yes"],
        capture_output=True, text=True, timeout=30,
    )
    if r.returncode != 0:
        return {"error": r.stderr.strip() or r.stdout.strip()}
    return {"success": True, "old_name": name, "new_name": new_name}


@mcp.tool()
def add_folder(name: str, folder: str) -> dict:
    """Add a watched folder to an existing workspace.

    Args:
        name: Workspace name or WS ID.
        folder: Absolute path to the folder to watch.

    Returns:
        dict with success and folder path, or error.
    """
    import subprocess
    r = subprocess.run(
        ["rewindex", "workspace", "add-folder", name, folder],
        capture_output=True, text=True, timeout=30,
    )
    if r.returncode != 0:
        return {"error": r.stderr.strip() or r.stdout.strip()}
    return {"success": True, "workspace": name, "folder": folder}


@mcp.tool()
def remove_folder(name: str, folder: str) -> dict:
    """Remove a watched folder from a workspace.

    Args:
        name: Workspace name or WS ID.
        folder: Absolute path to the folder to stop watching.

    Returns:
        dict with success and folder path, or error.
    """
    import subprocess
    r = subprocess.run(
        ["rewindex", "workspace", "remove-folder", name, folder, "--yes"],
        capture_output=True, text=True, timeout=30,
    )
    if r.returncode != 0:
        return {"error": r.stderr.strip() or r.stdout.strip()}
    return {"success": True, "workspace": name, "folder": folder}


@mcp.tool()
def add_exclude(pattern: str, workspace: Optional[str] = None) -> dict:
    """Add a file exclusion pattern — files matching this pattern will not be snapshotted.

    Patterns are gitignore-style (e.g. "*.log", "dist/", ".env").
    Omit workspace to apply globally across all workspaces.

    Args:
        pattern: Pattern to exclude (e.g. "*.log", "node_modules/", ".env").
        workspace: Workspace name or WS ID to apply per-workspace. Omit for global.

    Returns:
        dict with success and pattern, or error.
    """
    import subprocess
    cmd = ["rewindex", "workspace", "exclude", "add", pattern]
    if workspace:
        cmd += ["-p", workspace]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        return {"error": r.stderr.strip() or r.stdout.strip()}
    return {"success": True, "pattern": pattern, "workspace": workspace or "global"}


@mcp.tool()
def remove_exclude(pattern: str, workspace: Optional[str] = None) -> dict:
    """Remove a file exclusion pattern.

    Omit workspace to remove from global exclude list.

    Args:
        pattern: Pattern to remove (must match exactly as added).
        workspace: Workspace name or WS ID to remove per-workspace pattern. Omit for global.

    Returns:
        dict with success and pattern, or error.
    """
    import subprocess
    cmd = ["rewindex", "workspace", "exclude", "remove", pattern]
    if workspace:
        cmd += ["-p", workspace]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        return {"error": r.stderr.strip() or r.stdout.strip()}
    return {"success": True, "pattern": pattern, "workspace": workspace or "global"}


# ---------------------------------------------------------------------------
# Read tools
# ---------------------------------------------------------------------------

@mcp.tool()
def get_status() -> dict:
    """Get daemon status and list of all configured workspaces.

    Call at the start of a session to verify the snapshot daemon is running
    and to discover workspace names before calling other tools.
    If daemon_running is false, snapshots are not being saved — the user should
    run `rewindex start` to resume automatic snapshotting.

    Returns:
        dict with daemon_running (bool), pid (int or None), and workspaces list
        (name, folders, snap_count, session_count).
    """
    from rewindex.daemon.runner import is_running, read_pid
    from rewindex.db.queries import (
        get_oldest_session, get_latest_session, get_session_count,
    )

    workspaces_out, config = _load_workspaces()
    workspaces = workspaces_out

    daemon_running = is_running()
    pid = read_pid() if daemon_running else None

    workspace_list = []
    for i, proj in enumerate(workspaces):
        name = proj["name"]
        folders = proj.get("folders", [])
        entry = {
            "id": f"WS{i+1}",
            "name": name,
            "folders": folders,
        }
        try:
            conn = _get_conn(name)
            try:
                oldest = get_oldest_session(conn, name)
                latest = get_latest_session(conn, name)
                total_snaps = conn.execute(
                    "SELECT COUNT(*) as cnt FROM file WHERE file_registry_uid IN "
                    "(SELECT uid FROM file_registry WHERE workspace = ?)", (name,)
                ).fetchone()["cnt"]
                entry["oldest_session"] = _fmt_session(oldest["uid"]) if oldest else None
                entry["latest_session"] = _fmt_session(latest["uid"]) if latest else None
                entry["total_snaps"] = total_snaps
            finally:
                conn.close()
        except Exception as e:
            entry["db_error"] = str(e)
        workspace_list.append(entry)

    return {
        "daemon_running": daemon_running,
        "pid": pid,
        "workspaces": workspace_list,
    }


@mcp.tool()
def get_log(
    workspace: Optional[str] = None,
    limit: int = 15,
    since: Optional[str] = None,
    folder: Optional[str] = None,
    reverse: bool = False,
) -> dict:
    """PRIMARY entry point for all rewind and history workflows.

    Call this FIRST — before any rewind, before searching for what changed,
    and at the start of any task to understand recent context.
    Returns sessions with files changed per session.

    Workflow: get_log → find target session by note/files → rewind_session (2 calls total).

    Also use when the user asks "what changed?", "show me history", or "what did you do?".

    Args:
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).
        limit: Max number of sessions to return (default 15).
        since: ISO date string to filter from (e.g. "2026-01-01").
        folder: Filter by folder path prefix.
        reverse: If True, show oldest first.

    Returns:
        dict with workspace name and sessions list.
    """
    from rewindex.db.queries import get_sessions, get_files_in_session, get_flags_by_sessions

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    if limit < 1:
        return {"error": "limit must be at least 1."}

    conn = _get_conn(workspace_name)
    try:
        sessions = get_sessions(conn, workspace_name, limit=limit, since=since, reverse=reverse)
        if not sessions:
            return {"workspace": workspace_name, "sessions": []}

        session_uids = [s["uid"] for s in sessions]
        flag_map = get_flags_by_sessions(conn, workspace_name, session_uids)

        result_sessions = []
        for s in sessions:
            files = get_files_in_session(conn, s["uid"])
            if folder:
                files = [f for f in files if f["filepath"].startswith(folder)]
                if not files:
                    continue

            unique_files = list({f["file_id"]: f for f in files}.values())
            snap_count = len(files)

            sess_dict = {
                "session_id": _fmt_session(s["uid"]),
                "uid": s["uid"],
                "created_at": s["created_at"],
                "updated_at": s["updated_at"],
                "is_forced": bool(s["is_forced"]),
                "note": s["note"],
                "file_count": len(unique_files),
                "snap_count": snap_count,
                "files": [
                    {
                        "file_id": f["file_id"],
                        "filepath": f["filepath"],
                        "version": f["file_version"],
                        "status": f["status"] or "CHANGE",
                        "note": f["note"],
                        **({"lines_added": f["lines_added"], "lines_removed": f["lines_removed"]}
                           if f["lines_added"] is not None else {}),
                        **({"symbols": json.loads(f["symbols"])}
                           if f["symbols"] else {}),
                    }
                    for f in unique_files
                ],
            }

            flag = flag_map.get(s["uid"])
            if flag:
                sess_dict["flag"] = {
                    "version": flag["version"],
                    "title": flag["title"],
                    "session_id": _fmt_session(flag["session_uid"]),
                }

            result_sessions.append(sess_dict)

        return {"workspace": workspace_name, "sessions": result_sessions}
    finally:
        conn.close()


@mcp.tool()
def get_log_detail(
    workspace: Optional[str] = None,
    limit: int = 15,
) -> dict:
    """Deep history view — all file versions per session in one call.

    Use when you need to inspect what changed across multiple sessions at file level,
    without making separate get_diff calls. More verbose than get_log but complete.

    Prefer get_log for quick session discovery.
    Use get_log_detail when get_log note/file list isn't enough to identify the target session.

    Args:
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).
        limit: Max number of sessions to return (default 15).

    Returns:
        dict with workspace name and sessions list, each with all snaps.
    """
    from rewindex.db.queries import get_sessions, get_files_in_session, get_flags_by_sessions

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        sessions = get_sessions(conn, workspace_name, limit=limit)
        if not sessions:
            return {"workspace": workspace_name, "sessions": []}

        session_uids = [s["uid"] for s in sessions]
        flag_map = get_flags_by_sessions(conn, workspace_name, session_uids)

        result_sessions = []
        for s in sessions:
            files = get_files_in_session(conn, s["uid"])
            snaps = [
                {
                    "snap_id": _fmt_snap(f["uid"]),
                    "file_id": f["file_id"],
                    "filepath": f["filepath"],
                    "version": f["file_version"],
                    "status": f["status"] or "CHANGE",
                    "created_at": f["created_at"],
                    "note": f["note"],
                    "is_deleted": bool(f["is_deleted"]),
                    **({"lines_added": f["lines_added"], "lines_removed": f["lines_removed"]}
                       if f["lines_added"] is not None else {}),
                    **({"symbols": json.loads(f["symbols"])}
                       if f["symbols"] else {}),
                }
                for f in files
            ]

            sess_dict = {
                "session_id": _fmt_session(s["uid"]),
                "uid": s["uid"],
                "created_at": s["created_at"],
                "is_forced": bool(s["is_forced"]),
                "note": s["note"],
                "snaps": snaps,
            }

            flag = flag_map.get(s["uid"])
            if flag:
                sess_dict["flag"] = {
                    "version": flag["version"],
                    "title": flag["title"],
                }

            result_sessions.append(sess_dict)

        return {"workspace": workspace_name, "sessions": result_sessions}
    finally:
        conn.close()


@mcp.tool()
def get_session_state(
    session_id: str,
    workspace: Optional[str] = None,
) -> dict:
    """Get the complete file state of the workspace at a specific session.

    Returns every tracked file's version as it existed at that point in time.
    Use before rewind_session to preview exactly what the workspace will look like
    after rewinding. Also useful for comparing past state against the current working tree.

    Args:
        session_id: Session ID like "SS5". Use get_log to find the right session.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with session info and files list showing each file's version at that session.
    """
    from rewindex.db.queries import (
        get_session_by_uid,
        get_all_tracked_files,
        get_latest_version_at_session,
    )

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]

    # Parse session ID
    m = re.match(r'^[Ss]{2}(\d+)$', session_id.strip())
    if not m:
        return {"error": f"Invalid session ID '{session_id}'. Expected format: SS5"}
    ss_uid = int(m.group(1))

    conn = _get_conn(workspace_name)
    try:
        session = get_session_by_uid(conn, ss_uid)
        if not session:
            return {"error": f"{session_id.upper()} not found — may have been trimmed."}

        tracked = get_all_tracked_files(conn, workspace_name)
        files = []
        for reg in tracked:
            ver = get_latest_version_at_session(conn, reg["uid"], ss_uid)
            if ver is None or ver["is_deleted"]:
                continue
            files.append({
                "file_id": reg["file_id"],
                "filepath": reg["filepath"],
                "version": ver["file_version"],
                "snap_id": _fmt_snap(ver["uid"]),
                "created_at": ver["created_at"],
                "status": ver["status"] or "CHANGE",
                "note": ver["note"],
            })

        return {
            "workspace": workspace_name,
            "session_id": _fmt_session(ss_uid),
            "created_at": session["created_at"],
            "note": session["note"],
            "files": files,
        }
    finally:
        conn.close()


@mcp.tool()
def get_file_log(
    file_id: str,
    workspace: Optional[str] = None,
) -> dict:
    """Get full version history of a specific file.

    Use for deep per-file inspection when you already know which file to examine.
    For session-level discovery across multiple files, use get_log first.
    Avoid calling get_diff in a loop after this — use get_log to find the target session,
    then rewind_session directly.

    Tip: for rewind workflows, load related tools together:
    select:mcp__rewindex__get_file_log,mcp__rewindex__get_diff,mcp__rewindex__rewind_file,mcp__rewindex__find_version_by_pattern,mcp__rewindex__preview_version

    Args:
        file_id: 4-char FileID (e.g. "D1VS"). Find it from get_log output.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with file info and versions list.
    """
    from rewindex.db.queries import (
        get_file_registry_by_id,
        get_file_versions_for_registry,
        get_file_version_range,
    )

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        reg = get_file_registry_by_id(conn, workspace_name, file_id)
        if not reg:
            return {"error": f"Unknown FileID '{file_id}'."}

        versions = get_file_versions_for_registry(conn, reg["uid"])
        if not versions:
            return {"error": f"No versions found for {file_id}."}

        min_v, max_v = get_file_version_range(conn, reg["uid"])

        version_list = []
        for v in versions:
            labels = []
            if v["file_version"] == 1 and not v["is_deleted"]:
                labels.append("Original")
            if v["is_full"] and v["file_version"] > 1 and not v["is_deleted"]:
                promoted = v["promoted_by"] if "promoted_by" in v.keys() else None
                if promoted == "trim":
                    labels.append("Trim base")
                elif promoted == "precompute":
                    labels.append("Pre-compute")
                else:
                    labels.append("Fullbase")

            entry = {
                "snap_id": _fmt_snap(v["uid"]),
                "version": v["file_version"],
                "session_id": _fmt_session(v["session_uid"]) if v["session_uid"] else None,
                "created_at": v["created_at"],
                "status": v["status"] or "CHANGE",
                "is_deleted": bool(v["is_deleted"]),
                "is_full": bool(v["is_full"]),
                "labels": labels,
                "note": v["note"],
            }
            if v["lines_added"] is not None:
                entry["lines_added"] = v["lines_added"]
                entry["lines_removed"] = v["lines_removed"]
            if v["symbols"]:
                entry["symbols"] = json.loads(v["symbols"])
            version_list.append(entry)

        return {
            "workspace": workspace_name,
            "file_id": reg["file_id"],
            "filepath": reg["filepath"],
            "filename": reg["filename"],
            "oldest_version": min_v,
            "latest_version": max_v,
            "versions": version_list,
        }
    finally:
        conn.close()


@mcp.tool()
def find_version_by_pattern(
    file_id: str,
    pattern: str,
    event: str = "first_added",
    workspace: Optional[str] = None,
) -> dict:
    """Find which version first added or removed a keyword/pattern in a file.

    Returns the version number and the "before" version to use as rewind target.
    Use this instead of looping get_diff to search for changes.

    After finding the target version, ALWAYS check get_log to see if other files
    changed in the same session. If yes, prefer rewind_session over rewind_file.

    Args:
        file_id: 4-char FileID (e.g. "D1VS").
        pattern: Keyword or regex to search for (e.g. "clip-card", "def login").
        event: "first_added" (default) or "first_removed".
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with version_found, before_version, and matched_lines.
    """
    from rewindex.db.queries import (
        get_file_registry_by_id,
        get_file_versions_for_registry,
    )
    from rewindex.snapshot.reconstruct import reconstruct

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        reg = get_file_registry_by_id(conn, workspace_name, file_id)
        if not reg:
            return {"error": f"Unknown FileID '{file_id}'."}

        versions = get_file_versions_for_registry(conn, reg["uid"])
        if not versions:
            return {"error": f"No versions found for {file_id}."}

        try:
            pat = re.compile(pattern, re.IGNORECASE)
        except re.error:
            pat = re.compile(re.escape(pattern), re.IGNORECASE)

        if versions[0]["symbols"]:
            for v in versions:
                if not v["symbols"]:
                    continue
                syms = json.loads(v["symbols"])
                if any(pat.search(s) for s in syms):
                    ver = v["file_version"]
                    if event == "first_added":
                        return {
                            "version_found": ver,
                            "before_version": ver - 1 if ver > 1 else None,
                            "matched_symbols": [s for s in syms if pat.search(s)][:3],
                            "session_id": _fmt_session(v["session_uid"]) if v["session_uid"] else None,
                        }

        prev_content = None
        for v in versions:
            try:
                content = reconstruct(conn, reg["uid"], v["uid"])
                content_text = ''.join(content)
            except (ValueError, Exception):
                prev_content = None
                continue

            has_match = bool(pat.search(content_text))

            if event == "first_added" and has_match and (prev_content is None or not pat.search(prev_content)):
                matched = [l.strip() for l in content if pat.search(l)][:3]
                return {
                    "version_found": v["file_version"],
                    "before_version": v["file_version"] - 1 if v["file_version"] > 1 else None,
                    "matched_lines": matched,
                    "session_id": _fmt_session(v["session_uid"]) if v["session_uid"] else None,
                }
            elif event == "first_removed" and not has_match and prev_content and pat.search(prev_content):
                return {
                    "version_found": v["file_version"],
                    "before_version": v["file_version"] - 1,
                    "session_id": _fmt_session(v["session_uid"]) if v["session_uid"] else None,
                }

            prev_content = content_text

        return {"error": f"Pattern '{pattern}' not found in any version of {file_id}."}
    finally:
        conn.close()


@mcp.tool()
def preview_version(
    file_id: str,
    version: int,
    workspace: Optional[str] = None,
) -> dict:
    """Read file content at any version without modifying the working directory.

    100% read-only. Use to verify a version before committing to rewind.
    Reconstructs the file content at the specified version from snapshot history.

    Args:
        file_id: 4-char FileID (e.g. "D1VS").
        version: Version number to preview.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with filepath, version, content (full file text), and size_bytes.
    """
    from rewindex.db.queries import (
        get_file_registry_by_id,
        resolve_file_version,
    )
    from rewindex.snapshot.reconstruct import reconstruct

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        reg = get_file_registry_by_id(conn, workspace_name, file_id)
        if not reg:
            return {"error": f"Unknown FileID '{file_id}'."}

        target = resolve_file_version(conn, workspace_name, file_id, version)
        if not target:
            return {"error": f"Version {version} not found for {file_id}."}

        lines = reconstruct(conn, reg["uid"], target["uid"])
        content = ''.join(lines)

        return {
            "filepath": reg["filepath"],
            "version": version,
            "content": content,
            "size_bytes": len(content.encode('utf-8')),
        }
    except ValueError as e:
        return {"error": str(e)}
    finally:
        conn.close()


@mcp.tool()
def get_diff(
    file_id: str,
    from_version: Optional[int] = None,
    to_version: Optional[int] = None,
    workspace: Optional[str] = None,
) -> dict:
    """Get unified diff between two versions of a file.

    Use for line-level detail only — when get_log session view is not enough.
    Do NOT call this in a loop to search for a version. Instead: use get_log to
    identify the target session by note/files, then call rewind_session directly.

    Use when the user asks "what changed in this file?", "show me the diff",
    or "what exactly was modified?".

    Tip: load rewind tools together:
    select:mcp__rewindex__get_diff,mcp__rewindex__rewind_file,mcp__rewindex__rewind_session

    Args:
        file_id: 4-char FileID (e.g. "D1VS"). Find it via get_log.
        from_version: Source version number. Defaults to (latest - 1).
        to_version: Target version number. Defaults to latest.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with diff text (unified format) and summary stats.
    """
    from rewindex.db.queries import (
        get_file_registry_by_id,
        get_file_version_range,
        resolve_file_version,
    )
    from rewindex.snapshot.reconstruct import reconstruct

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        reg = get_file_registry_by_id(conn, workspace_name, file_id)
        if not reg:
            return {"error": f"Unknown FileID '{file_id}'."}

        min_v, max_v = get_file_version_range(conn, reg["uid"])
        if min_v is None:
            return {"error": f"No versions found for {file_id}."}

        to_ver = to_version if to_version is not None else max_v
        from_ver = from_version if from_version is not None else (to_ver - 1 if to_ver > min_v else min_v)

        if from_version is not None and to_version is not None and from_ver > to_ver:
            return {"error": f"from_version (v{from_ver}) must be less than to_version (v{to_ver})."}

        if from_ver < min_v:
            return {"error": f"from_version v{from_ver} not available. Oldest: v{min_v}"}

        from_row = resolve_file_version(conn, workspace_name, file_id, from_ver)
        to_row = resolve_file_version(conn, workspace_name, file_id, to_ver)

        if from_row is None:
            return {"error": f"{file_id} v{from_ver} not found — version may have been trimmed."}
        if to_row is None:
            return {"error": f"{file_id} v{to_ver} not found — version may have been trimmed."}

        old_lines = reconstruct(conn, reg["uid"], from_row["uid"])
        new_lines = reconstruct(conn, reg["uid"], to_row["uid"])

        old = [l.rstrip("\n") for l in old_lines]
        new = [l.rstrip("\n") for l in new_lines]
        diff_lines = list(difflib.unified_diff(
            old, new,
            fromfile=f"{file_id} v{from_ver}",
            tofile=f"{file_id} v{to_ver}",
            lineterm="",
            n=3,
        ))

        added = sum(1 for l in diff_lines if l.startswith("+") and not l.startswith("+++"))
        removed = sum(1 for l in diff_lines if l.startswith("-") and not l.startswith("---"))

        return {
            "workspace": workspace_name,
            "file_id": reg["file_id"],
            "filepath": reg["filepath"],
            "from_version": from_ver,
            "to_version": to_ver,
            "lines_added": added,
            "lines_removed": removed,
            "diff": "\n".join(diff_lines),
            "no_changes": len(diff_lines) == 0,
        }
    finally:
        conn.close()


@mcp.tool()
def get_snaps(
    workspace: Optional[str] = None,
    limit: int = 20,
) -> dict:
    """Get a flat list of recent individual file snapshots.

    Each snapshot (SN ID) is a single file saved automatically at a point in time.
    Sessions (SS IDs from get_log) group multiple snapshots together.

    Use get_log for session-level history (the usual entry point).
    Use get_snaps when you need low-level per-file snapshot IDs —
    for example as input to rewind_relative or to inspect granular save history.

    Args:
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).
        limit: Max number of snapshots to return (default 20).

    Returns:
        dict with workspace name and snaps list (snap_id, filepath, created_at).
    """
    from rewindex.db.queries import get_all_snapshots

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        snaps = get_all_snapshots(conn, workspace_name, limit=limit)
        snap_list = [
            {
                "snap_id": _fmt_snap(s["uid"]),
                "file_id": s["file_id"],
                "filepath": s["filepath"],
                "version": s["file_version"],
                "session_id": _fmt_session(s["session_uid"]) if s["session_uid"] else None,
                "created_at": s["created_at"],
                "status": s["status"] or "CHANGE",
                "is_deleted": bool(s["is_deleted"]),
                "note": s["note"],
            }
            for s in snaps
        ]
        return {"workspace": workspace_name, "snaps": snap_list}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Write tools
# ---------------------------------------------------------------------------

@mcp.tool()
def create_snap(
    note: Optional[str] = None,
    workspace: Optional[str] = None,
    minimal: bool = True,
) -> dict:
    """Save a checkpoint of all changed files. ALWAYS call this after completing any coding task — do not wait for the user to ask. Use a descriptive note summarising what you did and why (e.g. "feat: add login page — needed for auth flow" or "fix: null check on user.email — caused crash when user had no email"). Call before starting risky changes too.

    Args:
        note: Description of what you did and why. Include both the change and the reason (e.g. "refactor: split auth into separate module — was getting too large to maintain"). Required for meaningful history.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).
        minimal: If True (default), returns only session_id and files_snapped count.
                 Set to False to receive the full files list in the response.

    Returns:
        dict with session_id, files_snapped, and note. If minimal=False, includes files list.
    """
    from rewindex.snapshot.engine import snapshot_file, read_disk_warning
    from rewindex.daemon.watcher import safe_walk, _matches_exclude
    from rewindex.config.defaults import DEFAULT_EXCLUDE, SECURITY_EXCLUDE
    from rewindex.db.queries import (
        close_session,
        create_forced_session,
        get_files_in_session,
        get_latest_session,
        update_session_note,
    )

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    folders = proj.get("folders", [])

    from rewindex.config.loader import load_config
    config = load_config()
    global_exclude = config.get("global_exclude", DEFAULT_EXCLUDE)
    exclude = global_exclude + proj.get("workspace_exclude", [])

    conn = _get_conn(workspace_name)
    try:
        created_at = datetime.now(timezone.utc).isoformat()
        session_uid = create_forced_session(conn, workspace_name, created_at)

        new_snap_ids = []
        for folder in folders:
            folder = os.path.realpath(os.path.expanduser(folder))
            if not os.path.isdir(folder):
                continue
            for filepath in safe_walk(folder):
                if _matches_exclude(filepath, SECURITY_EXCLUDE) or _matches_exclude(filepath, exclude):
                    continue
                result = snapshot_file(
                    conn=conn,
                    workspace=workspace_name,
                    workspace_folder=folder,
                    abs_filepath=filepath,
                    session_uid=session_uid,
                )
                if result is not None:
                    new_snap_ids.append(result)

        total = len(new_snap_ids)

        if total == 0:
            conn.execute("DELETE FROM sessions WHERE uid = ?", (session_uid,))
            conn.commit()
            latest = get_latest_session(conn, workspace_name)
            if latest:
                if note:
                    update_session_note(conn, latest["uid"], note)
                    close_session(conn, latest["uid"])
                files = get_files_in_session(conn, latest["uid"])
                unique = list({f["file_id"]: f for f in files}.values())
                result = {
                    "workspace": workspace_name,
                    "session_id": _fmt_session(latest["uid"]),
                    "files_snapped": 0,
                    "note": note,
                    "message": "No changes detected — note attached to latest session.",
                }
                if not minimal:
                    result["files"] = [{"file_id": f["file_id"], "filepath": f["filepath"], "version": f["file_version"]} for f in unique]
                return result
            return {
                "workspace": workspace_name,
                "session_id": None,
                "files_snapped": 0,
                "message": "No changes detected.",
            }

        if note:
            update_session_note(conn, session_uid, note)
        close_session(conn, session_uid)

        result = {
            "workspace": workspace_name,
            "session_id": _fmt_session(session_uid),
            "files_snapped": total,
            "note": note,
        }
        if not minimal:
            files = get_files_in_session(conn, session_uid)
            result["files"] = [
                {
                    "snap_id": _fmt_snap(f["uid"]),
                    "file_id": f["file_id"],
                    "filepath": f["filepath"],
                    "version": f["file_version"],
                }
                for f in files
            ]
        return result
    finally:
        conn.close()


@mcp.tool()
def rewind_session(
    session_id: str,
    workspace: Optional[str] = None,
) -> dict:
    """PRIMARY rewind tool — restores ALL files in a session atomically.

    Use this by default for ANY undo or revert request.
    Reverting at session level prevents partial-state bugs — files that changed
    together are always restored together.

    Workflow: call get_log first → identify target session by note and files → call this.

    Use when: "undo", "revert", "go back", "it was working before",
    "undo everything you just did", or any time changes need to be rolled back.
    Prefer this over rewind_file in almost all cases.
    No confirmation needed — executes immediately.

    Args:
        session_id: Session ID string like "SS5". Use get_log to find the right one.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with new_session_id and list of files restored.
    """
    from rewindex.db.queries import (
        get_session_by_uid, get_oldest_session, get_latest_session,
        get_all_tracked_files, get_latest_version_at_session,
        get_files_in_session, create_forced_session, close_session,
        update_file_note, update_session_note,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file, hash_file
    from rewindex.commands.rewind import _resolve_abs_path, _move_file_if_needed

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    folders = proj.get("folders", [])

    m = re.match(r'^[Ss]{2}(\d+)$', session_id.strip())
    if not m:
        return {"error": f"Invalid session ID '{session_id}'. Expected format: SS5"}
    ss_uid = int(m.group(1))

    conn = _get_conn(workspace_name)
    try:
        session = get_session_by_uid(conn, ss_uid)
        if not session:
            oldest = get_oldest_session(conn, workspace_name)
            latest = get_latest_session(conn, workspace_name)
            if oldest and latest:
                return {
                    "error": f"{session_id.upper()} not found — may have been trimmed.",
                    "available": f"{_fmt_session(oldest['uid'])} (oldest) to {_fmt_session(latest['uid'])} (latest)",
                }
            return {"error": f"{session_id.upper()} not found."}

        tracked = get_all_tracked_files(conn, workspace_name)
        latest_session = get_latest_session(conn, workspace_name)

        preview = []
        for reg in tracked:
            ver = get_latest_version_at_session(conn, reg["uid"], ss_uid)
            latest_ver = conn.execute(
                "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 ORDER BY uid DESC LIMIT 1",
                (reg["uid"],)
            ).fetchone()

            if ver is None and latest_ver is None:
                continue

            filepath = reg["filepath"]
            target_filepath = ver["filepath"] if ver and ver["filepath"] else filepath
            abs_path = _resolve_abs_path(reg, folders)

            if ver is None or ver["is_deleted"]:
                if latest_ver and not latest_ver["is_deleted"]:
                    if abs_path and os.path.exists(abs_path):
                        preview.append((reg, filepath, "remove", None, latest_ver, target_filepath))
                    else:
                        preview.append((reg, filepath, "unchanged", None, latest_ver, target_filepath))
                else:
                    preview.append((reg, filepath, "unchanged", None, latest_ver, target_filepath))
            else:
                disk_hash = None
                if abs_path and os.path.exists(abs_path):
                    try:
                        disk_hash = hash_file(abs_path)
                    except OSError:
                        pass
                path_changed = target_filepath != filepath
                if disk_hash == ver["hash"] and not path_changed:
                    preview.append((reg, filepath, "unchanged", ver, latest_ver, target_filepath))
                else:
                    preview.append((reg, filepath, "revert", ver, latest_ver, target_filepath))

        has_changes = any(a in ("remove", "revert") for _, _, a, _, _, _ in preview)
        if not has_changes:
            return {
                "workspace": workspace_name,
                "session_id": session_id.upper(),
                "message": "Files are already at that state. Nothing to change.",
                "files_restored": [],
            }

        created_at = datetime.now(timezone.utc).isoformat()
        new_session_uid = create_forced_session(conn, workspace_name, created_at)

        restored = []
        for reg, filepath, action, ver, cur, target_fp in preview:
            if action == "remove":
                abs_path = _resolve_abs_path(reg, folders)
                if abs_path and os.path.exists(abs_path):
                    os.remove(abs_path)
                    new_uid = snapshot_file(conn, workspace_name, reg["folder_path"], abs_path,
                                           session_uid=new_session_uid)
                    if new_uid:
                        cur_v = cur["file_version"] if cur else "?"
                        update_file_note(conn, new_uid,
                            f"rewind from {_fmt_session(latest_session['uid'])} to {_fmt_session(ss_uid)}, removed v{cur_v}")
                    restored.append({"file_id": reg["file_id"], "filepath": filepath, "action": "removed"})
            elif action == "revert":
                abs_path, moved_from = _move_file_if_needed(conn, reg, target_fp, folders)
                lines = reconstruct(conn, reg["uid"], ver["uid"])
                if abs_path:
                    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
                    with open(abs_path, "w", encoding="utf-8") as f:
                        f.writelines(lines)
                    new_uid = snapshot_file(conn, workspace_name, reg["folder_path"], abs_path,
                                            session_uid=new_session_uid)
                    if not new_uid and moved_from:
                        from rewindex.snapshot.engine import record_move as _record_move
                        new_uid = _record_move(conn, workspace_name, reg["folder_path"], abs_path,
                                               moved_from, session_uid=new_session_uid)
                    if new_uid:
                        saved_row = conn.execute("SELECT file_version FROM file WHERE uid = ?", (new_uid,)).fetchone()
                        saved_v = saved_row["file_version"] if saved_row else "?"
                        cur_v = cur["file_version"] if cur else "?"
                        note = f"rewind from v{cur_v} to v{ver['file_version']}, saved as v{saved_v}"
                        if moved_from:
                            note += f" | moved from {moved_from}"
                        update_file_note(conn, new_uid, note)
                    restored.append({
                        "file_id": reg["file_id"],
                        "filepath": target_fp,
                        "action": "reverted",
                        "from_version": cur["file_version"] if cur else None,
                        "to_version": ver["file_version"],
                    })

        files_in_new = get_files_in_session(conn, new_session_uid)
        if not files_in_new:
            conn.execute("DELETE FROM sessions WHERE uid = ?", (new_session_uid,))
            conn.commit()
            return {
                "workspace": workspace_name,
                "session_id": session_id.upper(),
                "message": "Workspace already at that state — nothing changed.",
                "files_restored": [],
            }
        else:
            close_session(conn, new_session_uid)
            update_session_note(conn, new_session_uid,
                f"rewind from {_fmt_session(latest_session['uid'])} to {_fmt_session(ss_uid)}, saved as {_fmt_session(new_session_uid)}")

        return {
            "workspace": workspace_name,
            "rewound_to": session_id.upper(),
            "new_session_id": _fmt_session(new_session_uid),
            "files_restored": restored,
        }
    finally:
        conn.close()


@mcp.tool()
def rewind_file(
    file_id: str,
    version: int,
    workspace: Optional[str] = None,
) -> dict:
    """Surgical single-file restore. Use ONLY when you need to restore one file independently of other files changed in the same session.

    Default to rewind_session unless you have a specific reason to isolate one file.

    WARNING: Before calling this, ALWAYS check:
    1. Call get_log to see what session this version belongs to
    2. If multiple files changed in that session, use rewind_session instead
    3. Rewinding one file while others remain changed causes partial/broken state

    Args:
        file_id: The file's short ID (e.g. "D1VS").
        version: Target version number to restore to.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with file_id, filepath, reverted_to_version, saved_as_version, new_session_id.
    """
    from rewindex.db.queries import (
        get_file_registry_by_id, get_file_version_range,
        resolve_file_version, get_latest_file_version,
        get_latest_session, create_forced_session,
        update_file_note,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file
    from rewindex.db.queries import close_session
    from rewindex.commands.rewind import _resolve_abs_path, _move_file_if_needed

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    folders = proj.get("folders", [])

    conn = _get_conn(workspace_name)
    try:
        reg = get_file_registry_by_id(conn, workspace_name, file_id)
        if not reg:
            return {"error": f"Unknown FileID '{file_id}'."}

        min_v, max_v = get_file_version_range(conn, reg["uid"])
        if min_v is None:
            return {"error": f"No versions found for {file_id}."}

        target_ver = version

        latest = get_latest_file_version(conn, reg["uid"])
        if latest and latest["file_version"] == target_ver:
            return {"error": f"{file_id} is already at v{target_ver} — nothing to restore."}

        target_row = resolve_file_version(conn, workspace_name, file_id, target_ver)
        if not target_row:
            return {
                "error": f"{file_id} v{target_ver} not found — version may have been trimmed.",
                "available": f"v{min_v} (oldest) to v{max_v} (latest)",
            }

        filepath = reg["filepath"]
        target_filepath = target_row["filepath"] if target_row["filepath"] else filepath
        abs_path = _resolve_abs_path(reg, folders)

        if not abs_path:
            return {"error": f"Cannot locate file {filepath} in workspace folders."}

        if latest["hash"] == target_row["hash"] and target_filepath == filepath:
            return {"error": f"{file_id} v{latest['file_version']} and v{target_ver} are identical — nothing to change."}

        abs_path, moved_from = _move_file_if_needed(conn, reg, target_filepath, folders)
        lines = reconstruct(conn, reg["uid"], target_row["uid"])

        created_at = datetime.now(timezone.utc).isoformat()
        new_session_uid = create_forced_session(conn, workspace_name, created_at)

        if abs_path:
            os.makedirs(os.path.dirname(abs_path), exist_ok=True)
            with open(abs_path, "w", encoding="utf-8") as f:
                f.writelines(lines)

        new_uid = snapshot_file(conn, workspace_name, reg["folder_path"], abs_path,
                                session_uid=new_session_uid)

        if not new_uid and moved_from:
            from rewindex.snapshot.engine import record_move
            new_uid = record_move(conn, workspace_name, reg["folder_path"], abs_path,
                                  moved_from, session_uid=new_session_uid)

        if not new_uid:
            conn.execute("DELETE FROM sessions WHERE uid = ?", (new_session_uid,))
            conn.commit()

        if new_uid:
            saved_row = conn.execute("SELECT file_version FROM file WHERE uid = ?", (new_uid,)).fetchone()
            new_ver = saved_row["file_version"] if saved_row else target_ver
            note = f"rewind from v{latest['file_version']} to v{target_ver}, saved as v{new_ver}"
            if moved_from:
                note += f" | moved from {moved_from}"
            update_file_note(conn, new_uid, note)
            close_session(conn, new_session_uid)
        else:
            new_ver = target_ver

        display_fp = target_filepath if target_filepath != filepath else filepath

        return {
            "workspace": workspace_name,
            "file_id": reg["file_id"],
            "filepath": display_fp,
            "reverted_to_version": target_ver,
            "saved_as_version": new_ver,
            "new_session_id": _fmt_session(new_session_uid) if new_uid else None,
        }
    finally:
        conn.close()


@mcp.tool()
def rewind_relative(
    n: int,
    workspace: Optional[str] = None,
) -> dict:
    """Undo the last N auto-snapshots across all affected files. Use when the user says "undo the last change" or "undo last N saves". Prefer rewind_session when you know the exact session to go back to.

    Args:
        n: Number of snapshots to undo (positive integer, e.g. 1 to undo the last save).
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with new_session_id and files restored.
    """
    from rewindex.db.queries import (
        get_latest_session, create_forced_session, get_files_in_session, close_session,
        update_file_note,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.engine import snapshot_file, hash_file
    from rewindex.commands.rewind import _resolve_abs_path, _move_file_if_needed

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    folders = proj.get("folders", [])

    # Accept negative or positive — use absolute value
    n = abs(n)
    if n == 0:
        return {"error": "n must be at least 1."}

    conn = _get_conn(workspace_name)
    try:
        total = conn.execute("SELECT COUNT(*) as c FROM file WHERE is_corrupted = 0").fetchone()["c"]
        if n >= total:
            return {"error": f"Cannot rewind {n} snapshots — only {total} snapshots exist."}

        undone_rows = conn.execute(
            "SELECT * FROM file WHERE is_corrupted = 0 ORDER BY uid DESC LIMIT ?",
            (n,)
        ).fetchall()

        target_row = conn.execute(
            "SELECT * FROM file WHERE is_corrupted = 0 ORDER BY uid DESC LIMIT 1 OFFSET ?",
            (n,)
        ).fetchone()

        reg_uids = set(r["file_registry_uid"] for r in undone_rows)

        preview = []
        for reg_uid in reg_uids:
            reg = conn.execute("SELECT * FROM file_registry WHERE uid = ?", (reg_uid,)).fetchone()
            filepath = reg["filepath"]

            prior = conn.execute(
                "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 AND uid <= ? ORDER BY uid DESC LIMIT 1",
                (reg_uid, target_row["uid"]),
            ).fetchone()

            latest = conn.execute(
                "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 ORDER BY uid DESC LIMIT 1",
                (reg_uid,),
            ).fetchone()

            if prior is None:
                abs_path = _resolve_abs_path(reg, folders)
                if abs_path and os.path.exists(abs_path):
                    preview.append((reg, filepath, "remove", None, latest, filepath))
            else:
                target_fp = prior["filepath"] if prior["filepath"] else filepath
                disk_hash = None
                abs_path = _resolve_abs_path(reg, folders)
                if abs_path and os.path.exists(abs_path):
                    try:
                        disk_hash = hash_file(abs_path)
                    except OSError:
                        pass
                path_changed = target_fp != filepath
                if disk_hash == prior["hash"] and not path_changed:
                    continue
                preview.append((reg, filepath, "revert", prior, latest, target_fp))

        if not preview:
            return {
                "workspace": workspace_name,
                "message": f"Nothing to change — last {n} snapshots have no effect on current files.",
                "files_restored": [],
            }

        created_at = datetime.now(timezone.utc).isoformat()
        new_session_uid = create_forced_session(conn, workspace_name, created_at)

        restored = []
        for reg, filepath, action, ver, cur, target_fp in preview:
            if action == "remove":
                abs_path = _resolve_abs_path(reg, folders)
                if abs_path and os.path.exists(abs_path):
                    os.remove(abs_path)
                    snapshot_file(conn, workspace_name, reg["folder_path"], abs_path,
                                  session_uid=new_session_uid)
                restored.append({"file_id": reg["file_id"], "filepath": filepath, "action": "removed"})
            elif action == "revert":
                abs_path, moved_from = _move_file_if_needed(conn, reg, target_fp, folders)
                lines = reconstruct(conn, reg["uid"], ver["uid"])
                if abs_path:
                    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
                    with open(abs_path, "w", encoding="utf-8") as f:
                        f.writelines(lines)
                    new_uid = snapshot_file(conn, workspace_name, reg["folder_path"], abs_path,
                                            session_uid=new_session_uid)
                    if not new_uid and moved_from:
                        from rewindex.snapshot.engine import record_move as _record_move
                        new_uid = _record_move(conn, workspace_name, reg["folder_path"], abs_path,
                                               moved_from, session_uid=new_session_uid)
                    if new_uid:
                        saved_row = conn.execute("SELECT file_version FROM file WHERE uid = ?", (new_uid,)).fetchone()
                        saved_v = saved_row["file_version"] if saved_row else "?"
                        cur_v = cur["file_version"] if cur else "?"
                        note = f"rewind from v{cur_v} to v{ver['file_version']}, saved as v{saved_v}"
                        if moved_from:
                            note += f" | moved from {moved_from}"
                        update_file_note(conn, new_uid, note)
                restored.append({
                    "file_id": reg["file_id"],
                    "filepath": target_fp,
                    "action": "reverted",
                    "to_version": ver["file_version"],
                })

        files_in_new = get_files_in_session(conn, new_session_uid)
        if not files_in_new:
            conn.execute("DELETE FROM sessions WHERE uid = ?", (new_session_uid,))
            conn.commit()
            return {
                "workspace": workspace_name,
                "message": "Already at that state — nothing changed.",
                "files_restored": [],
            }
        else:
            close_session(conn, new_session_uid)

        return {
            "workspace": workspace_name,
            "snaps_undone": n,
            "new_session_id": _fmt_session(new_session_uid),
            "files_restored": restored,
        }
    finally:
        conn.close()


@mcp.tool()
def add_note(
    target: str,
    note: str,
    version: Optional[int] = None,
    workspace: Optional[str] = None,
) -> dict:
    """Annotate a session, file version, or snap with a note.

    Args:
        target: One of:
            - Session ID "SS5" — annotate that session
            - FileID "D1VS" — annotate a file version (use version= to pick which)
            - Snap ID "SN42" — annotate that specific snap
        note: The note text to attach. Include what changed and why (e.g. "fix: removed unused import — caused linter errors on CI").
        version: For FileID target, which version to annotate (latest if omitted).
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with success and the annotated target info.
    """
    from rewindex.db.queries import (
        get_session_by_uid, get_latest_session,
        get_file_registry_by_id, get_file_version_range,
        resolve_file_version, get_latest_file_version, get_file_version,
        update_session_note, update_file_note,
    )

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    if len(note) > 256:
        return {"error": f"Note too long ({len(note)} chars). Max 256 characters."}

    conn = _get_conn(workspace_name)
    try:
        target = target.strip()

        # Session: SS5
        m_ss = re.match(r'^[Ss]{2}(\d+)$', target)
        if m_ss:
            ss_uid = int(m_ss.group(1))
            session = get_session_by_uid(conn, ss_uid)
            if not session:
                return {"error": f"{target.upper()} not found."}
            update_session_note(conn, ss_uid, note)
            from rewindex.events import emit
            emit("note", target_type="session", session_uid=ss_uid)
            return {
                "success": True,
                "target_type": "session",
                "session_id": _fmt_session(ss_uid),
                "note": note,
            }

        # Snap: SN42
        m_sn = re.match(r'^[Ss][Nn](\d+)$', target)
        if m_sn:
            sn_uid = int(m_sn.group(1))
            snap = get_file_version(conn, sn_uid)
            if not snap:
                return {"error": f"{target.upper()} not found."}
            update_file_note(conn, sn_uid, note)
            from rewindex.events import emit
            emit("note", target_type="snap", snap_uid=sn_uid)
            reg = conn.execute("SELECT * FROM file_registry WHERE uid = ?", (snap["file_registry_uid"],)).fetchone()
            return {
                "success": True,
                "target_type": "snap",
                "snap_id": _fmt_snap(sn_uid),
                "file_id": reg["file_id"] if reg else None,
                "version": snap["file_version"],
                "note": note,
            }

        # FileID: D1VS
        if re.match(r'^[A-Z0-9]{4}$', target.upper()):
            reg = get_file_registry_by_id(conn, workspace_name, target)
            if not reg:
                return {"error": f"Unknown FileID '{target}'."}

            min_v, max_v = get_file_version_range(conn, reg["uid"])
            if min_v is None:
                return {"error": f"No versions found for {target}."}

            target_ver = version if version is not None else max_v
            row = resolve_file_version(conn, workspace_name, target, target_ver)
            if not row:
                return {
                    "error": f"{target} v{target_ver} not found.",
                    "available": f"v{min_v} (oldest) to v{max_v} (latest)",
                }

            update_file_note(conn, row["uid"], note)
            from rewindex.events import emit
            emit("note", target_type="file_version", snap_uid=row["uid"])
            return {
                "success": True,
                "target_type": "file_version",
                "file_id": reg["file_id"],
                "filepath": reg["filepath"],
                "version": target_ver,
                "note": note,
            }

        return {"error": f"Unrecognized target '{target}'. Use SS5 (session), SN42 (snap), or D1VS (FileID)."}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Flag tools
# ---------------------------------------------------------------------------

@mcp.tool()
def create_flag(
    session_id: str,
    title: str,
    description: Optional[str] = None,
    version: Optional[str] = None,
    bump: Optional[str] = None,
    workspace: Optional[str] = None,
) -> dict:
    """Mark a session as a named version milestone (e.g. v1.0.5).

    Flag only when: (1) the changes are substantial, AND (2) the system has been tested
    and confirmed to work. Minor edits → snap only. Big changes not yet tested → snap and wait.
    Big changes + tested + working → flag.

    A flag means "this version is good enough to come back to by name."
    Do not flag every session — flag is a quality gate, not a quantity marker.

    Version auto-increments (patch) from the last flag.
    Pass bump="minor" or bump="major" for bigger jumps, or version="1.2.0" to set explicitly.

    Use when: "mark this as a release", "tag this version", "this is v1.0",
    "milestone reached", or after completing a significant feature.

    Args:
        session_id: Session ID like "SS5" or "latest". Use get_log to find the right session.
        title: Short label for this milestone (e.g. "Initial release", "Add auth").
        description: Optional longer release notes in Markdown. Max 8 KB. Rendered in the dashboard; headers are auto-bumped +1 level in changelog export. Header guide: # main section, ## subsection, ### detail. These become ##/###/#### in the exported changelog (where the version title is ##). How to write: use conversation context first; if unclear, read session notes via list_flags + get_log; ask user before reading diffs.
        version: Explicit version string like "1.2.3" (skips auto-bump).
        bump: "patch" (default), "minor", or "major".
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with version created, session_id, and title.
    """
    from rewindex.db.queries import (
        create_flag as db_create_flag,
        get_flag_by_session,
        get_flag_by_version,
        get_latest_flag,
        get_latest_session,
        get_session_by_uid,
    )
    from rewindex.utils.version import bump_version, validate_explicit_version
    from rewindex.config.loader import load_config

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    config = load_config()
    flag_cfg = config.get("flag", {})

    conn = _get_conn(workspace_name)
    try:
        # Resolve target session
        if session_id.lower() == "latest":
            sess = get_latest_session(conn, workspace_name)
            if sess is None:
                return {"error": "No sessions found for this workspace."}
            ss_uid = sess["uid"]
        else:
            m = re.match(r'^[Ss]{2}(\d+)$', session_id.strip())
            if not m:
                return {"error": f"Invalid session_id '{session_id}'. Use SS5 or 'latest'."}
            ss_uid = int(m.group(1))
            sess = get_session_by_uid(conn, ss_uid)
            if sess is None:
                return {"error": f"{session_id.upper()} not found."}

        # Validate title
        title = title.strip()
        if not title:
            return {"error": "title is required and must not be empty."}
        if len(title) > 128:
            return {"error": f"title too long ({len(title)} chars). Max 128 characters."}

        # Check not already flagged
        existing = get_flag_by_session(conn, workspace_name, ss_uid)
        if existing:
            return {
                "error": f"{_fmt_session(ss_uid)} already has flag {existing['version']} — \"{existing['title']}\"."
            }

        # Determine version
        segments = flag_cfg.get("version_segments", 3)
        auto_bump = flag_cfg.get("auto_bump", "patch")
        max_desc_bytes = flag_cfg.get("max_description_bytes", 8192)

        # Validate mutually exclusive options
        bump_flags = sum([bool(version), bool(bump)])
        if bump_flags > 1:
            return {"error": "version and bump are mutually exclusive."}

        latest_flag = get_latest_flag(conn, workspace_name)
        current_version = latest_flag["version"] if latest_flag else None

        if version:
            try:
                new_version = validate_explicit_version(version, segments)
            except ValueError as e:
                return {"error": str(e)}
        elif bump:
            if bump not in ("patch", "minor", "major"):
                return {"error": "bump must be 'patch', 'minor', or 'major'."}
            try:
                new_version = bump_version(current_version, bump, segments)
            except ValueError as e:
                return {"error": str(e)}
        else:
            try:
                new_version = bump_version(current_version, auto_bump, segments)
            except ValueError as e:
                return {"error": str(e)}

        # Uniqueness check
        collision = get_flag_by_version(conn, workspace_name, new_version)
        if collision:
            return {
                "error": f"Version {new_version} already exists — \"{collision['title']}\" on {_fmt_session(collision['session_uid'])}."
            }

        if description and len(description.encode("utf-8")) > max_desc_bytes:
            return {"error": f"description exceeds {max_desc_bytes} bytes limit."}

        created_at = datetime.now(timezone.utc).isoformat()
        promote_fb = flag_cfg.get("promote_to_fullbase", False)

        db_create_flag(
            conn=conn,
            session_uid=ss_uid,
            workspace=workspace_name,
            version=new_version,
            title=title.strip(),
            created_at=created_at,
            description=description,
            promoted_to_fullbase=promote_fb,
        )

        if promote_fb:
            from rewindex.commands.flag import _promote_session_fullbase
            _promote_session_fullbase(conn, workspace_name, ss_uid)

        return {
            "success": True,
            "version": new_version,
            "session_id": _fmt_session(ss_uid),
            "title": title.strip(),
            "description": description,
            "promoted_to_fullbase": promote_fb,
        }
    finally:
        conn.close()


@mcp.tool()
def list_flags(
    workspace: Optional[str] = None,
    since_session: Optional[str] = None,
) -> dict:
    """List all version milestones (flags) for the workspace.

    Use this as the entry point when the user wants to rewind to a named version.
    Workflow: list_flags → find version → get session_id → rewind_session.

    Also use when: "what versions do we have?", "show milestones", "what releases are there?",
    or before generating a changelog.

    Each flag includes has_description (bool). Use show_flag to read the full Markdown description.

    Args:
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).
        since_session: Show flags since this session ID (e.g. "SS50").

    Returns:
        dict with workspace name and flags list.
    """
    from rewindex.db.queries import list_flags as db_list_flags

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]

    since_uid = None
    if since_session:
        m = re.match(r'^[Ss]{2}(\d+)$', since_session.strip())
        if not m:
            return {"error": f"Invalid since_session '{since_session}'. Use SS50."}
        since_uid = int(m.group(1))

    conn = _get_conn(workspace_name)
    try:
        flags = db_list_flags(conn, workspace_name, since_session_uid=since_uid)
        flag_list = [
            {
                "version": f["version"],
                "title": f["title"],
                "session_id": _fmt_session(f["session_uid"]),
                "created_at": f["created_at"],
                "is_orphaned": bool(f["is_orphaned"]),
                "has_description": bool(f["description"]),
            }
            for f in flags
        ]
        return {"workspace": workspace_name, "flags": flag_list}
    finally:
        conn.close()


@mcp.tool()
def show_flag(
    version: str,
    workspace: Optional[str] = None,
) -> dict:
    """Show full detail for a version milestone including description (Markdown).

    Use when the user asks about a specific version (e.g. "what's in v1.0.5?", "show release notes for 1.2").
    The description field is Markdown-formatted text.

    Args:
        version: Version string like "1.0.5" or "v1.0.5".
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with full flag detail including Markdown description.
    """
    from rewindex.db.queries import get_flag_by_version

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    ver_str = version if version.startswith("v") else f"v{version}"

    conn = _get_conn(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
        if flag is None:
            return {"error": f"Flag '{ver_str}' not found."}

        return {
            "version": flag["version"],
            "title": flag["title"],
            "description": flag["description"],
            "session_id": _fmt_session(flag["session_uid"]),
            "created_at": flag["created_at"],
            "is_orphaned": bool(flag["is_orphaned"]),
            "promoted_to_fullbase": bool(flag["promoted_to_fullbase"]),
        }
    finally:
        conn.close()


@mcp.tool()
def edit_flag(
    version: str,
    title: Optional[str] = None,
    description: Optional[str] = None,
    workspace: Optional[str] = None,
) -> dict:
    """Update a version milestone's title or description. Use when the user wants to fix a typo in a release name or add/update release notes for an existing version.

    Args:
        version: Version string like "1.0.5" or "v1.0.5".
        title: New title (keeps existing if omitted or empty).
        description: New description in Markdown format (keeps existing if omitted).
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with success status.
    """
    from rewindex.db.queries import get_flag_by_version, update_flag
    from rewindex.config.loader import load_config

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    config = load_config()
    flag_cfg = config.get("flag", {})
    max_desc_bytes = flag_cfg.get("max_description_bytes", 8192)

    ver_str = version if version.startswith("v") else f"v{version}"

    conn = _get_conn(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
        if flag is None:
            return {"error": f"Flag '{ver_str}' not found."}

        new_title = title.strip() if title else flag["title"]
        new_des = description if description is not None else flag["description"]

        if not new_title:
            return {"error": "title must not be empty."}

        if new_des and len(new_des.encode("utf-8")) > max_desc_bytes:
            return {"error": f"description exceeds {max_desc_bytes} bytes limit."}

        update_flag(conn, workspace_name, ver_str, new_title, new_des)

        return {
            "success": True,
            "version": ver_str,
            "title": new_title,
            "description": new_des,
        }
    finally:
        conn.close()


@mcp.tool()
def move_flag(
    version: str,
    session_id: str,
    workspace: Optional[str] = None,
) -> dict:
    """Move a flag to a different session without deleting and recreating it. Preserves title, description, and all metadata. Only the session link changes.

    Use when: "move v1.0 to SS10", "relocate flag to latest session", "shift the flag forward".

    Args:
        version: Version string like "1.0.5" or "v1.0.5".
        session_id: Target session ID like "SS10" or "latest".
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with success status, version, old and new session IDs.
    """
    from rewindex.db.queries import (
        get_flag_by_version,
        get_flag_by_session,
        get_session_by_uid,
        get_latest_session,
        move_flag as db_move_flag,
    )

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    ver_str = version if version.startswith("v") else f"v{version}"

    conn = _get_conn(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
        if flag is None:
            return {"error": f"Flag '{ver_str}' not found."}

        old_ss = flag["session_uid"]

        if session_id.lower() == "latest":
            sess = get_latest_session(conn, workspace_name)
            if sess is None:
                return {"error": "No sessions found for this workspace."}
            new_ss = sess["uid"]
        else:
            m = re.match(r'^[Ss]{2}(\d+)$', session_id.strip())
            if not m:
                return {"error": f"Invalid session_id '{session_id}'. Use SS10 or 'latest'."}
            new_ss = int(m.group(1))
            sess = get_session_by_uid(conn, new_ss)
            if sess is None:
                return {"error": f"{session_id.upper()} not found."}

        if new_ss == old_ss:
            return {"error": f"Flag {ver_str} is already on {_fmt_session(old_ss)}."}

        existing = get_flag_by_session(conn, workspace_name, new_ss)
        if existing:
            return {
                "error": f"{_fmt_session(new_ss)} already has flag {existing['version']} — \"{existing['title']}\"."
            }

        db_move_flag(conn, workspace_name, ver_str, new_ss)

        return {
            "success": True,
            "version": ver_str,
            "title": flag["title"],
            "from_session": _fmt_session(old_ss),
            "to_session": _fmt_session(new_ss),
            "message": f"Flag {ver_str} moved from {_fmt_session(old_ss)} to {_fmt_session(new_ss)}.",
        }
    finally:
        conn.close()


@mcp.tool()
def delete_flag(
    version: str,
    workspace: Optional[str] = None,
) -> dict:
    """Delete a version milestone marker. Use when the user wants to remove an incorrectly placed flag or clean up test versions. Does not affect snapshots or file history — only removes the label. If the goal is to move a flag to a different session, use move_flag instead.

    Args:
        version: Version string like "1.0.5" or "v1.0.5".
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with success status.
    """
    from rewindex.db.queries import delete_flag as db_delete_flag, get_flag_by_version

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    ver_str = version if version.startswith("v") else f"v{version}"

    conn = _get_conn(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
        if flag is None:
            return {"error": f"Flag '{ver_str}' not found."}

        deleted = db_delete_flag(conn, workspace_name, ver_str)
        if deleted:
            return {"success": True, "version": ver_str, "message": f"Flag {ver_str} deleted."}
        return {"error": f"Flag {ver_str} could not be deleted."}
    finally:
        conn.close()


@mcp.tool()
def export_flags(
    format: str = "md",
    since_session: Optional[str] = None,
    workspace: Optional[str] = None,
) -> dict:
    """Export all version milestones as a changelog.

    Returns markdown or JSON. Write the result to CHANGELOG.md if the user wants to save it.
    Use since_session to limit scope (e.g. only changes since the last release).

    Use when: "generate a changelog", "export release notes", "what's new since v1.0?",
    or when preparing a release.

    Args:
        format: "md" (markdown, default) or "json".
        since_session: Include only flags from this session onward (e.g. "SS50").
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with content (string) and format.
    """
    from rewindex.db.queries import list_flags as db_list_flags

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]

    if format.lower() not in ("md", "json"):
        return {"error": "format must be 'md' or 'json'."}

    since_uid = None
    if since_session:
        m = re.match(r'^[Ss]{2}(\d+)$', since_session.strip())
        if not m:
            return {"error": f"Invalid since_session '{since_session}'. Use SS50."}
        since_uid = int(m.group(1))

    conn = _get_conn(workspace_name)
    try:
        if since_uid is not None:
            row = conn.execute(
                "SELECT uid FROM sessions WHERE uid = ? AND workspace = ?",
                (since_uid, workspace_name),
            ).fetchone()
            if row is None:
                return {"error": f"Session {since_session.upper()} not found."}

        flags = db_list_flags(conn, workspace_name, since_session_uid=since_uid)

        if format.lower() == "json":
            data = [
                {
                    "version": f["version"],
                    "title": f["title"],
                    "description": f["description"],
                    "session_uid": f["session_uid"],
                    "created_at": f["created_at"],
                    "is_orphaned": bool(f["is_orphaned"]),
                }
                for f in flags
            ]
            content = json.dumps(data, ensure_ascii=False, indent=2)
        else:
            lines = [f"# {workspace_name} — Changelog\n"]
            for f in reversed(list(flags)):
                orphan = " *(orphaned)*" if f["is_orphaned"] else ""
                lines.append(f"## {f['version']} — {f['title']}{orphan}\n")
                lines.append(f"**Session:** SS{f['session_uid']}  ")
                lines.append(f"**Date:** {f['created_at'][:10]}\n")
                if f["description"]:
                    lines.append("")
                    lines.append(f["description"])
                    lines.append("")
                lines.append("---\n")
            content = "\n".join(lines)

        return {
            "workspace": workspace_name,
            "format": format.lower(),
            "flag_count": len(list(flags)),
            "content": content,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Smart File: Co-change Graph
# ---------------------------------------------------------------------------


@mcp.tool()
def get_related_files(
    file_id: str,
    workspace: Optional[str] = None,
    min_sessions: int = 2,
    limit: int = 10,
) -> dict:
    """Find files that frequently change together with a given file (co-change analysis).

    Uses session history to identify files that are often modified in the same session.
    Useful before rewind_file to check if other files should also be reverted.

    Args:
        file_id: 4-char FileID (e.g. "D1VS").
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).
        min_sessions: Minimum co-change count to include (default 2).
        limit: Max number of related files to return (default 10).

    Returns:
        dict with the target file info and a list of related files sorted by co-change frequency.
    """
    from rewindex.db.queries import get_file_registry_by_id

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)

    try:
        reg = get_file_registry_by_id(conn, workspace_name, file_id)
        if not reg:
            return {"error": f"File '{file_id}' not found."}

        target_reg_uid = reg["uid"]

        sessions_with_target = conn.execute(
            "SELECT DISTINCT session_uid FROM file WHERE file_registry_uid = ? AND session_uid IS NOT NULL",
            (target_reg_uid,),
        ).fetchall()

        if not sessions_with_target:
            return {
                "file_id": file_id,
                "filepath": reg["filepath"],
                "total_sessions": 0,
                "related_files": [],
            }

        session_uids = [r["session_uid"] for r in sessions_with_target]
        total_sessions = len(session_uids)

        placeholders = ",".join("?" * len(session_uids))
        co_files = conn.execute(
            f"""
            SELECT fr.file_id, fr.filepath, COUNT(DISTINCT f.session_uid) as co_count
            FROM file f
            JOIN file_registry fr ON f.file_registry_uid = fr.uid
            WHERE f.session_uid IN ({placeholders})
              AND f.file_registry_uid != ?
              AND fr.workspace = ?
            GROUP BY fr.uid
            HAVING co_count >= ?
            ORDER BY co_count DESC
            LIMIT ?
            """,
            (*session_uids, target_reg_uid, workspace_name, min_sessions, limit),
        ).fetchall()

        related = []
        for row in co_files:
            related.append({
                "file_id": row["file_id"],
                "filepath": row["filepath"],
                "co_change_sessions": row["co_count"],
                "co_change_ratio": round(row["co_count"] / total_sessions, 2),
            })

        return {
            "file_id": file_id,
            "filepath": reg["filepath"],
            "total_sessions": total_sessions,
            "related_files": related,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Cleanup / Trash tools
# ---------------------------------------------------------------------------


@mcp.tool()
def list_trash() -> dict:
    """List all trashed (removed) workspaces.

    Trashed workspaces still have their snapshot data but are no longer active.
    Use restore_trash to bring one back or delete_trash to permanently remove all.

    Returns:
        dict with trashed list (name, snap_count, trashed_at).
    """
    from rewindex.commands.cleanup import _list_trash

    trashed = _list_trash()
    return {
        "trashed": [
            {"name": name, "snap_count": snap_count, "trashed_at": trashed_at}
            for name, snap_count, trashed_at in trashed
        ],
    }


@mcp.tool()
def restore_trash(name: str) -> dict:
    """Restore a trashed workspace back to active state.

    Args:
        name: Workspace name to restore (from list_trash output).

    Returns:
        dict with success status and restored workspace name.
    """
    from rewindex.config.defaults import TRASH_DIR, SNAPSHOTS_DIR
    from rewindex.config.loader import load_config, save_config
    from rewindex.daemon.runner import restart_daemon

    trash_path = os.path.join(TRASH_DIR, name)
    if not os.path.isdir(trash_path):
        return {"error": f'"{name}" not found in trash.'}

    dest = os.path.join(SNAPSHOTS_DIR, name)
    import shutil
    shutil.move(trash_path, dest)

    config = load_config()
    existing_names = [p["name"] for p in config.get("workspaces", [])]
    if name not in existing_names:
        config["workspaces"].append({"name": name, "folders": []})
        save_config(config)

    ws = next((p for p in config["workspaces"] if p["name"] == name), None)
    folders = ws.get("folders", []) if ws else []

    restart_daemon(config)

    return {
        "success": True,
        "name": name,
        "folders": folders,
        "message": f'Workspace "{name}" restored.' + (" You may need to re-add watched folders." if not folders else ""),
    }


@mcp.tool()
def delete_trash() -> dict:
    """Permanently delete all trashed workspaces. This cannot be undone.

    Returns:
        dict with success status and list of deleted workspace names.
    """
    from rewindex.commands.cleanup import _list_trash
    from rewindex.config.defaults import TRASH_DIR
    import shutil

    trashed = _list_trash()
    if not trashed:
        return {"message": "Trash is empty. Nothing to delete."}

    deleted = []
    for name, snap_count, _ in trashed:
        path = os.path.join(TRASH_DIR, name)
        shutil.rmtree(path, ignore_errors=True)
        deleted.append({"name": name, "snap_count": snap_count})

    return {
        "success": True,
        "deleted": deleted,
        "message": f"Permanently deleted {len(deleted)} workspace(s) from trash.",
    }


# ---------------------------------------------------------------------------
# Code audit / debug tools
# ---------------------------------------------------------------------------

@mcp.tool()
def search_sessions_by_file(
    filepath: str,
    workspace: Optional[str] = None,
) -> dict:
    """Find all sessions that modified a specific file.

    Use this to audit who changed a file and when — returns sessions with their
    notes so you can understand what work touched the file over time.

    Tip: combine with get_diff to see exactly what changed in each session.

    Args:
        filepath: Partial or full filepath to search (e.g. "app.py", "src/auth/login.py").
                  Matched with LIKE so "login" matches any path containing "login".
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with matches: [{file_id, filepath, session_id, session_note, version, created_at}]
    """
    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        rows = conn.execute(
            """SELECT DISTINCT s.uid as session_uid, s.note as session_note, s.created_at as session_at,
                      f.file_version, f.created_at as snap_at, f.status,
                      f.lines_added, f.lines_removed,
                      r.file_id, r.filepath, r.filename
               FROM sessions s
               JOIN file f ON f.session_uid = s.uid
               JOIN file_registry r ON f.file_registry_uid = r.uid
               WHERE r.workspace = ? AND (r.filepath LIKE ? OR r.filename LIKE ?)
               ORDER BY s.uid DESC
               LIMIT 100""",
            (workspace_name, f"%{filepath}%", f"%{filepath}%"),
        ).fetchall()

        if not rows:
            return {"error": f"No sessions found touching '{filepath}'."}

        matches = []
        for r in rows:
            entry = {
                "session_id": _fmt_session(r["session_uid"]),
                "session_note": r["session_note"] or "",
                "session_at": r["session_at"],
                "file_id": r["file_id"],
                "filepath": r["filepath"],
                "version": r["file_version"],
                "status": r["status"] or "CHANGE",
            }
            if r["lines_added"] is not None:
                entry["lines_added"] = r["lines_added"]
                entry["lines_removed"] = r["lines_removed"]
            matches.append(entry)

        return {
            "workspace": workspace_name,
            "query": filepath,
            "total": len(matches),
            "matches": matches,
        }
    finally:
        conn.close()


@mcp.tool()
def get_session_diff(
    session_id: str,
    workspace: Optional[str] = None,
) -> dict:
    """Get a combined diff of all files changed in a session.

    Shows the full impact of a task in one call — what changed across every file.
    Use this for code auditing, understanding a session's scope, or reviewing AI changes.

    Args:
        session_id: Session ID like "SS5". Use get_log to find the right session.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with session info and per-file diffs (added/removed lines).
    """
    import difflib
    from rewindex.db.queries import get_files_in_session, get_file_versions_for_registry
    from rewindex.snapshot.reconstruct import reconstruct

    proj, err = _resolve(workspace)
    if err:
        return err

    m = re.match(r"(?:SS)?(\d+)$", str(session_id), re.IGNORECASE)
    if not m:
        return {"error": f"Invalid session ID '{session_id}'. Use format 'SS5'."}

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        uid = int(m.group(1))
        sess_row = conn.execute(
            "SELECT uid, note, created_at FROM sessions WHERE uid = ? AND workspace = ?",
            (uid, workspace_name),
        ).fetchone()
        if not sess_row:
            return {"error": f"Session {session_id} not found."}

        files = get_files_in_session(conn, uid)
        if not files:
            return {"error": f"No files in session {session_id}."}

        file_diffs = []
        total_add = 0
        total_del = 0

        for f in files:
            reg_uid = f["file_registry_uid"]
            file_uid = f["uid"]
            file_version = f["file_version"]

            try:
                after = reconstruct(conn, reg_uid, file_uid)
            except Exception:
                after = None

            prev_uid = None
            if file_version > 1:
                prev_row = conn.execute(
                    "SELECT uid FROM file WHERE file_registry_uid = ? AND file_version = ?",
                    (reg_uid, file_version - 1),
                ).fetchone()
                if prev_row:
                    prev_uid = prev_row["uid"]

            try:
                before = reconstruct(conn, reg_uid, prev_uid) if prev_uid else []
            except Exception:
                before = []

            if after is None:
                continue

            before_lines = [l.rstrip("\n") for l in before]
            after_lines = [l.rstrip("\n") for l in after]

            diff = list(difflib.unified_diff(
                before_lines, after_lines,
                fromfile=f"v{file_version - 1}" if file_version > 1 else "(new)",
                tofile=f"v{file_version}",
                lineterm="",
            ))

            added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
            removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
            total_add += added
            total_del += removed

            file_diffs.append({
                "file_id": f["file_id"],
                "filepath": f["filepath"],
                "version": file_version,
                "status": f["status"] or "CHANGE",
                "lines_added": added,
                "lines_removed": removed,
                "diff": diff[:200],
                "truncated": len(diff) > 200,
            })

        return {
            "workspace": workspace_name,
            "session_id": _fmt_session(uid),
            "session_note": sess_row["note"] or "",
            "created_at": sess_row["created_at"],
            "files_changed": len(file_diffs),
            "total_lines_added": total_add,
            "total_lines_removed": total_del,
            "files": file_diffs,
        }
    finally:
        conn.close()


@mcp.tool()
def find_pattern_introduced(
    pattern: str,
    filepath_filter: Optional[str] = None,
    workspace: Optional[str] = None,
) -> dict:
    """Search all files to find when a pattern first appeared in the workspace.

    Different from find_version_by_pattern (single file). This searches EVERY file
    matching an optional filepath filter — useful for tracing when a bug, function,
    or concept was first written anywhere in the project.

    Use filepath_filter to limit scope and avoid slow searches on large workspaces.

    Args:
        pattern: Keyword or regex to search for (e.g. "ORDER BY uid ASC", "def login").
        filepath_filter: Optional partial path to limit search (e.g. ".py", "src/auth").
                         If omitted, searches all tracked files.
        workspace: Workspace name or WS ID (auto-detected from CWD if omitted).

    Returns:
        dict with matches: [{file_id, filepath, version_found, session_id, matched_lines}]
        Sorted by session_id ascending (earliest first).
    """
    from rewindex.snapshot.reconstruct import reconstruct

    proj, err = _resolve(workspace)
    if err:
        return err

    workspace_name = proj["name"]
    conn = _get_conn(workspace_name)
    try:
        try:
            pat = re.compile(pattern, re.IGNORECASE)
        except re.error:
            pat = re.compile(re.escape(pattern), re.IGNORECASE)

        query = """SELECT r.uid as reg_uid, r.file_id, r.filepath, r.filename
                   FROM file_registry r
                   WHERE r.workspace = ?"""
        params: list = [workspace_name]
        if filepath_filter:
            query += " AND (r.filepath LIKE ? OR r.filename LIKE ?)"
            params += [f"%{filepath_filter}%", f"%{filepath_filter}%"]
        query += " ORDER BY r.uid ASC"

        registries = conn.execute(query, params).fetchall()
        if not registries:
            return {"error": "No files found matching the filter."}

        results = []
        for reg in registries:
            versions = conn.execute(
                "SELECT uid, file_version, session_uid FROM file "
                "WHERE file_registry_uid = ? ORDER BY file_version ASC",
                (reg["reg_uid"],),
            ).fetchall()

            prev_has = False
            for v in versions:
                try:
                    content = "".join(reconstruct(conn, reg["reg_uid"], v["uid"]))
                except Exception:
                    continue

                has_match = bool(pat.search(content))
                if has_match and not prev_has:
                    matched_lines = [l.strip() for l in content.splitlines() if pat.search(l)][:3]
                    results.append({
                        "file_id": reg["file_id"],
                        "filepath": reg["filepath"],
                        "version_found": v["file_version"],
                        "session_id": _fmt_session(v["session_uid"]) if v["session_uid"] else None,
                        "matched_lines": matched_lines,
                    })
                    break
                prev_has = has_match

        if not results:
            return {"error": f"Pattern '{pattern}' not found in any file history."}

        results.sort(key=lambda x: int(x["session_id"][2:]) if x["session_id"] else 0)
        return {
            "workspace": workspace_name,
            "pattern": pattern,
            "filepath_filter": filepath_filter or "(all files)",
            "files_searched": len(registries),
            "matches": results,
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Dashboard tool
# ---------------------------------------------------------------------------

@mcp.tool()
def open_dashboard(port: int = 9009) -> dict:
    """Open the Rewindex dashboard (rewindex web) in the browser. Starts the web server in the background if not already running.

    Checks if the dashboard is already running first. If not, starts it via
    `rewindex web` as a background process. Then opens the browser.

    Args:
        port: Port to run the dashboard on (default: 9009).

    Returns:
        dict with url, status ("already_running" | "started"), and any error.
    """
    import socket
    import subprocess
    import sys
    import webbrowser

    url = f"http://localhost:{port}"

    # Check if already running
    already = False
    try:
        with socket.create_connection(("localhost", port), timeout=1):
            already = True
    except OSError:
        pass

    if not already:
        try:
            subprocess.Popen(
                ["rewindex", "web", "-p", str(port)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except FileNotFoundError:
            return {"error": "rewindex CLI not found. Is it installed and in PATH?", "url": url}
        except Exception as e:
            return {"error": str(e), "url": url}

    try:
        webbrowser.open(url)
    except Exception:
        pass

    return {
        "url": url,
        "status": "already_running" if already else "started",
        "message": f"Dashboard is {'running' if already else 'starting'} at {url}",
    }


# ---------------------------------------------------------------------------
# Click command to start MCP server
# ---------------------------------------------------------------------------

@click.command(name="mcp")
def mcp_cmd():
    """Start the Rewindex MCP server (stdio transport).

    \b
    This exposes Rewindex as structured tools for AI agents via MCP.
    Configure in ~/.claude/settings.json:

    \b
    {
      "mcpServers": {
        "rewindex": {
          "command": "rewindex",
          "args": ["mcp"],
          "type": "stdio"
        }
      }
    }
    """
    mcp.run(transport="stdio")
