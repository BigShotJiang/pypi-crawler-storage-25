# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import click

from rewindex.config.loader import load_config
from rewindex.db.connection import get_connection
from rewindex.snapshot.engine import snapshot_file, read_disk_warning
from rewindex.commands._workspace import resolve_workspace, check_workspace_paused


@click.command()
@click.argument("message", default="")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def snap_cmd(message: str, workspace: str | None) -> None:
    """Snap all changed files into a session.

    \b
    rewindex snap                    snap all changed files
    rewindex snap "message"          snap with a session note
    """
    from rewindex.utils.validation import validate_string
    from rewindex.daemon.watcher import safe_walk, _matches_exclude
    from rewindex.config.defaults import DEFAULT_EXCLUDE, SECURITY_EXCLUDE
    from rewindex.db.queries import (
        close_session,
        create_forced_session,
        get_files_in_session,
        get_latest_session,
        update_session_note,
    )
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import fmt_session
    from datetime import datetime, timezone

    config = load_config()
    workspaces = config.get("workspaces", [])

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return
    if check_workspace_paused(workspace_name, workspaces):
        return

    proj = next(p for p in workspaces if p["name"] == workspace_name)

    disk_warn = read_disk_warning()
    if disk_warn:
        click.echo(f"WARNING: {disk_warn} — snapshots may be skipped")

    if message:
        try:
            validate_string(message, "message")
        except ValueError as e:
            click.echo(f"Error: {e}")
            return

    global_exclude = config.get("global_exclude", DEFAULT_EXCLUDE)
    exclude = global_exclude + proj.get("workspace_exclude", [])
    folders = proj.get("folders", [])

    conn = get_connection(workspace_name)
    try:
        created_at = datetime.now(timezone.utc).isoformat()
        session_uid = create_forced_session(conn, workspace_name, created_at)

        new_snap_ids = []
        for folder in folders:
            folder = os.path.realpath(os.path.expanduser(folder))
            if not os.path.isdir(folder):
                continue
            for filepath in safe_walk(folder):
                if _matches_exclude(filepath, SECURITY_EXCLUDE) or _matches_exclude(filepath, exclude):
                    continue
                result = snapshot_file(
                    conn=conn,
                    workspace=workspace_name,
                    workspace_folder=folder,
                    abs_filepath=filepath,
                    session_uid=session_uid,
                )
                if result is not None:
                    new_snap_ids.append(result)

        total = len(new_snap_ids)

        if total == 0:
            conn.execute("DELETE FROM sessions WHERE uid = ?", (session_uid,))
            conn.commit()
            latest = get_latest_session(conn, workspace_name)
            if latest:
                display_time = fmt_date(latest["created_at"])
                if message:
                    update_session_note(conn, latest["uid"], message)
                close_session(conn, latest["uid"])

                files = get_files_in_session(conn, latest["uid"])
                unique = {}
                for f in files:
                    unique[f["file_id"]] = f
                file_count = len(unique)
                file_word = "file" if file_count == 1 else "files"

                click.echo(f"\nSaved successfully — {fmt_session(latest['uid'])} | {display_time}   {file_count} {file_word}")
                click.echo("─" * 56)
                for f in unique.values():
                    click.echo(f"  {f['file_id']}   {f['filepath']:<30} v{f['file_version']}")
                if message:
                    click.echo(f"\n# Note: \"{message}\"")
                click.echo(f"\nSnap session successfully. This session: {fmt_session(latest['uid'])}")

                from rewindex.events import emit
                emit("snap", session_id=fmt_session(latest["uid"]), workspace=workspace_name)
                from rewindex.plugin import fire
                fire("on_snap",
                     session_id=fmt_session(latest["uid"]),
                     files=[{"file_id": f["file_id"], "filepath": f["filepath"], "version": f["file_version"]} for f in unique.values()],
                     note=message or "")
            else:
                click.echo("\nSaved successfully — no changes detected")
            click.echo()
            return

        if message:
            update_session_note(conn, session_uid, message)

        close_session(conn, session_uid)

        files = get_files_in_session(conn, session_uid)
        file_word = "file" if total == 1 else "files"
        header = fmt_date_header()

        click.echo(f"\n{fmt_session(session_uid)} | {fmt_date(created_at)}   {total} {file_word}  {header}")
        click.echo("─" * 56)
        for f in files:
            click.echo(f"  {f['file_id']}   {f['filepath']:<30} v{f['file_version']}")

        if message:
            click.echo(f"\n# Note: \"{message}\"")

        click.echo(f"\nSnap session successfully. This session: {fmt_session(session_uid)}")
        click.echo()

        from rewindex.events import emit
        emit("snap", session_id=fmt_session(session_uid), workspace=workspace_name)
        from rewindex.plugin import fire
        fire("on_snap",
             session_id=fmt_session(session_uid),
             files=[{"file_id": f["file_id"], "filepath": f["filepath"], "version": f["file_version"]} for f in files],
             note=message or "")
    finally:
        conn.close()
