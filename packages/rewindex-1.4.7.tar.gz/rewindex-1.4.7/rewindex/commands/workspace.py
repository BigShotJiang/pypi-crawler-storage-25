# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import click

from rewindex.config.loader import load_config, save_config
from rewindex.config.defaults import SNAPSHOTS_DIR
from rewindex.config.urls import LINK_SUBSCRIPTION
from rewindex.daemon.runner import restart_daemon


@click.group(invoke_without_command=True)
@click.pass_context
def workspace_cmd(ctx: click.Context) -> None:
    """Manage workspaces and their watched folders and exclusion patterns.

    \b
    rewindex workspace                                            list all workspaces
    rewindex workspace add <name> <folder>                        add a new workspace
    rewindex workspace add --name <name> --folder <folder>        add (flag syntax)
    rewindex workspace remove <name|WSID>                         remove a workspace
    rewindex workspace rename <name|WSID> <new-name>              rename a workspace
    rewindex workspace folder add <name|WSID> <path>               add a watched folder
    rewindex workspace folder remove <name|WSID> <path>           remove a watched folder
    rewindex workspace exclude add <pattern>                      add global exclusion
    rewindex workspace exclude add <pattern> -p <name|WSID>       add per-workspace exclusion
    rewindex workspace exclude remove <pattern>                   remove global exclusion
    rewindex workspace exclude remove <pattern> -p <name|WSID>    remove per-workspace exclusion
    """
    if ctx.invoked_subcommand is None:
        from rewindex.utils.id_parse import fmt_workspace, fmt_session
        from rewindex.db.connection import get_connection
        from rewindex.db.queries import get_latest_session
        from rewindex.license import is_pro
        config = load_config()
        workspaces = config.get("workspaces", [])
        if not workspaces:
            click.echo("No workspaces configured.")
            return
        pro = is_pro()
        workspace_limit = 0 if pro else 1
        click.echo(f"\nWorkspaces ({len(workspaces)})")
        click.echo("─" * 56)
        for i, p in enumerate(workspaces, 1):
            folders = p.get("folders", [])
            pid = fmt_workspace(i)
            conn = get_connection(p["name"])
            try:
                latest = get_latest_session(conn, p["name"])
                latest_str = f"{fmt_session(latest['uid'])} latest" if latest else ""
            finally:
                conn.close()
            primary = folders[0] if folders else "(none)"
            name_col = p['name'] + "  (paused)" if workspace_limit and i > workspace_limit else p['name']
            click.echo(f"  {pid}   {name_col:<28} {primary:<30} {latest_str}")
        click.echo()


@workspace_cmd.command("add")
@click.argument("pos_name", required=False, default=None)
@click.argument("pos_folder", required=False, default=None)
@click.option("--name", "flag_name", default=None, help="Workspace name.")
@click.option("--folder", "flag_folder", default=None, help="Folder to watch.")
def workspace_add(pos_name: str | None, pos_folder: str | None, flag_name: str | None, flag_folder: str | None) -> None:
    """Add a new workspace.

    \b
    rewindex workspace add <name> <folder>
    rewindex workspace add --name <name> --folder <folder>
    """
    name = flag_name or pos_name
    folder = flag_folder or pos_folder

    if not name or not folder:
        click.echo("Error: missing required arguments.")
        click.echo("Usage:")
        click.echo("  rewindex workspace add <name> <folder>")
        click.echo("  rewindex workspace add --name <name> --folder <folder>")
        return

    from rewindex.utils.validation import same_folder, validate_workspace_name

    try:
        validate_workspace_name(name)
    except ValueError as e:
        click.echo(f"Error: {e}")
        return

    folder = os.path.expanduser(folder)
    if not os.path.isdir(folder):
        click.echo(f"Error: folder does not exist: {folder}")
        return

    config = load_config()

    for p in config["workspaces"]:
        if p["name"] == name:
            click.echo(f"Workspace '{name}' already exists.")
            return
        for existing in p.get("folders", []):
            existing = os.path.expanduser(existing)
            if same_folder(folder, existing):
                click.echo(
                    f"Error: folder '{folder}' is already in use by workspace '{p['name']}'. "
                    f"Each folder can only belong to one workspace."
                )
                return

    from rewindex.license import is_pro
    from rewindex.config.defaults import FREE_MAX_WORKSPACES, FREE_MAX_FOLDERS
    from rewindex.config.urls import LINK_PRICING

    if not is_pro() and len(config["workspaces"]) >= FREE_MAX_WORKSPACES:
        click.echo(f"\nError: Free tier supports {FREE_MAX_WORKSPACES} workspace.")
        click.echo(f"Upgrade to Pro to add unlimited workspaces: {LINK_SUBSCRIPTION}")
        click.echo()
        return

    from datetime import datetime, timezone
    config["workspaces"].append({"name": name, "folders": [folder], "created_at": datetime.now(timezone.utc).isoformat()})
    os.makedirs(os.path.join(SNAPSHOTS_DIR, name), exist_ok=True)
    save_config(config)
    click.echo(f'\nWorkspace "{name}" added.')
    click.echo(f"Watching: {folder}")
    click.echo()
    restart_daemon(config)

    from rewindex.events import emit
    emit("workspace_change", action="add", workspace=name)



@workspace_cmd.command("remove")
@click.argument("name")
@click.option("--yes", is_flag=True, help="Skip confirmation")
def workspace_remove(name: str, yes: bool) -> None:
    """Remove a workspace (snapshots moved to trash).

    \b
    rewindex workspace remove <name|WSID>
    rewindex workspace remove <name|WSID> --yes
    """
    import shutil
    from rewindex.config.defaults import TRASH_DIR
    from rewindex.utils.id_parse import fmt_workspace, fmt_session
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import get_oldest_session, get_latest_session

    config = load_config()
    target = _find_workspace(config, name)
    if target is None:
        click.echo(f"Workspace '{name}' not found.")
        return

    actual_name = target["name"]
    idx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == actual_name)
    pid = fmt_workspace(idx)
    folders = target.get("folders", [])

    if not yes:
        conn = get_connection(actual_name)
        try:
            oldest = get_oldest_session(conn, actual_name)
            latest = get_latest_session(conn, actual_name)
            total_snaps = conn.execute(
                "SELECT COUNT(*) as cnt FROM file WHERE file_registry_uid IN "
                "(SELECT uid FROM file_registry WHERE workspace = ?)", (actual_name,)
            ).fetchone()["cnt"]
            total_files = conn.execute(
                "SELECT COUNT(*) as cnt FROM file_registry WHERE workspace = ?", (actual_name,)
            ).fetchone()["cnt"]
        finally:
            conn.close()

        click.echo(f"\nRemove workspace: {actual_name} ({pid})")
        click.echo("─" * 54)
        if folders:
            click.echo(f"  Folders   {folders[0]}")
            for f in folders[1:]:
                click.echo(f"            {f}")
        click.echo(f"  Snaps     {total_snaps} snapshots across {total_files} files")
        if oldest and latest:
            click.echo(f"  Sessions  {fmt_session(oldest['uid'])} (oldest) → {fmt_session(latest['uid'])} (latest)")
        click.echo()
        click.echo("Snapshots will be moved to trash. Run `rewindex cleanup --trash` to delete permanently.")

        import questionary
        confirm = questionary.confirm("Confirm?", default=False).ask()
        if not confirm:
            click.echo("Cancelled.")
            return

    config["workspaces"] = [p for p in config["workspaces"] if p["name"] != actual_name]

    # Move snapshots to trash
    src = os.path.join(SNAPSHOTS_DIR, actual_name)
    if os.path.isdir(src):
        os.makedirs(TRASH_DIR, exist_ok=True)
        dst = os.path.join(TRASH_DIR, actual_name)
        if os.path.exists(dst):
            suffix = 1
            while os.path.exists(f"{dst}_{suffix}"):
                suffix += 1
            dst = f"{dst}_{suffix}"
        shutil.move(src, dst)

    save_config(config)
    click.echo(f'\nWorkspace "{actual_name}" removed.')
    click.echo(f"Snapshots moved to trash: ~/.rewindex/trash/{actual_name}/")
    click.echo("To delete permanently: rewindex cleanup --trash")
    click.echo()
    restart_daemon(config)


@workspace_cmd.command("add-folder")
@click.argument("name")
@click.argument("folder")
def workspace_add_folder(name: str, folder: str) -> None:
    """Add a watched folder to a workspace.

    \b
    rewindex workspace add-folder <name|WSID> <path>
    """
    _do_add_folder(name, folder)


@workspace_cmd.command("rename")
@click.argument("old_name")
@click.argument("new_name")
@click.option("--yes", is_flag=True, help="Skip confirmation")
def workspace_rename(old_name: str, new_name: str, yes: bool) -> None:
    """Rename a workspace.

    \b
    rewindex workspace rename <name|WSID> <new-name>
    """
    import shutil
    from rewindex.utils.validation import validate_workspace_name
    from rewindex.db.connection import get_db_path
    from rewindex.config.defaults import SNAPSHOTS_DIR

    try:
        validate_workspace_name(new_name)
    except ValueError as e:
        click.echo(f"Error: {e}")
        return

    config = load_config()
    for p in config["workspaces"]:
        if p["name"] == new_name:
            click.echo(f"Error: workspace '{new_name}' already exists.")
            return

    target = _find_workspace(config, old_name)
    if target is None:
        click.echo(f"Workspace '{old_name}' not found.")
        return

    if not yes:
        import questionary
        confirm = questionary.confirm(
            f"Rename '{old_name}' → '{new_name}'?"
        ).ask()
        if not confirm:
            click.echo("Cancelled.")
            return

    # 1. Rename snapshots directory
    old_dir = os.path.join(SNAPSHOTS_DIR, old_name)
    new_dir = os.path.join(SNAPSHOTS_DIR, new_name)
    if os.path.isdir(old_dir):
        shutil.move(old_dir, new_dir)

    # 2. Update workspace column in DB
    db_path = get_db_path(new_name)
    if os.path.isfile(db_path):
        import sqlite3
        conn = sqlite3.connect(db_path)
        conn.execute("UPDATE file_registry SET workspace = ? WHERE workspace = ?", (new_name, old_name))
        conn.execute("UPDATE sessions SET workspace = ? WHERE workspace = ?", (new_name, old_name))
        conn.commit()
        conn.close()

    # 3. Update config
    target["name"] = new_name
    save_config(config)
    from rewindex.utils.id_parse import fmt_workspace
    idx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == new_name)
    click.echo(f"\nWorkspace {fmt_workspace(idx)} renamed: {old_name} → {new_name}\n")
    restart_daemon(config)


@workspace_cmd.command("remove-folder")
@click.argument("name")
@click.argument("folder")
@click.option("--yes", is_flag=True, help="Skip confirmation")
def workspace_remove_folder(name: str, folder: str, yes: bool) -> None:
    """Remove a watched folder from a workspace.

    \b
    rewindex workspace remove-folder <name|WSID> <path>
    rewindex workspace remove-folder <name|WSID> <path> --yes
    """
    _do_remove_folder(name, folder, yes=yes)


# -- workspace folder ---------------------------------------------------------

@workspace_cmd.group("folder")
def workspace_folder() -> None:
    """Add or remove watched folders.

    \b
    rewindex workspace folder add <name|WSID> <path>
    rewindex workspace folder remove <name|WSID> <path>
    """


@workspace_folder.command("add")
@click.argument("name")
@click.argument("path")
def folder_add(name: str, path: str) -> None:
    """Add a watched folder to a workspace.

    \b
    rewindex workspace folder add <name|WSID> <path>
    """
    _do_add_folder(name, path)


@workspace_folder.command("remove")
@click.argument("name")
@click.argument("path")
@click.option("--yes", is_flag=True, help="Skip confirmation")
def folder_remove(name: str, path: str, yes: bool) -> None:
    """Remove a watched folder from a workspace.

    \b
    rewindex workspace folder remove <name|WSID> <path>
    rewindex workspace folder remove <name|WSID> <path> --yes
    """
    _do_remove_folder(name, path, yes=yes)


# -- workspace exclude --------------------------------------------------------

@workspace_cmd.group("exclude")
def workspace_exclude() -> None:
    """Manage exclusion patterns.

    \b
    rewindex workspace exclude add <pattern>                  global
    rewindex workspace exclude add <pattern> -p <name|WSID>   per-workspace
    rewindex workspace exclude remove <pattern>               global
    rewindex workspace exclude remove <pattern> -p <name|WSID> per-workspace
    """


@workspace_exclude.command("add")
@click.argument("pattern")
@click.option("--workspace", "-p", default=None, help="Add to this workspace's exclude only (not global).")
def exclude_add(pattern: str, workspace: str | None) -> None:
    """Add an exclude pattern (global or per-workspace)."""
    from rewindex.config.defaults import DEFAULT_EXCLUDE
    from rewindex.utils.id_parse import fmt_workspace
    config = load_config()

    if workspace is None:
        lst = config.setdefault("global_exclude", list(DEFAULT_EXCLUDE))
        if pattern in lst:
            click.echo(f"\n'{pattern}' is already in global_exclude.")
            click.echo()
            return
        lst.append(pattern)
        save_config(config)
        click.echo(f"\nExclusion pattern added (global): {pattern}")
        click.echo()
    else:
        target = _find_workspace(config, workspace)
        if target is None:
            click.echo(f"Workspace '{workspace}' not found.")
            return
        lst = target.setdefault("workspace_exclude", [])
        if pattern in lst:
            idx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == target["name"])
            click.echo(f"\n'{pattern}' is already in workspace_exclude for '{target['name']}' ({fmt_workspace(idx)}).")
            click.echo()
            return
        lst.append(pattern)
        save_config(config)
        idx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == target["name"])
        click.echo(f'\nExclusion pattern added to "{target["name"]}" ({fmt_workspace(idx)}): {pattern}')
        click.echo()

    restart_daemon(config)


@workspace_exclude.command("remove")
@click.argument("pattern")
@click.option("--workspace", "-p", default=None, help="Remove from this workspace's exclude only (not global).")
def exclude_remove(pattern: str, workspace: str | None) -> None:
    """Remove an exclude pattern (global or per-workspace)."""
    from rewindex.config.defaults import DEFAULT_EXCLUDE
    from rewindex.utils.id_parse import fmt_workspace
    config = load_config()

    if workspace is None:
        lst = config.get("global_exclude", list(DEFAULT_EXCLUDE))
        if pattern not in lst:
            click.echo(f"\n'{pattern}' not found in global_exclude.")
            click.echo()
            return
        lst.remove(pattern)
        config["global_exclude"] = lst
        save_config(config)
        click.echo(f"\nExclusion pattern removed (global): {pattern}")
        click.echo()
    else:
        target = _find_workspace(config, workspace)
        if target is None:
            click.echo(f"Workspace '{workspace}' not found.")
            return
        lst = target.get("workspace_exclude", [])
        if pattern not in lst:
            idx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == target["name"])
            click.echo(f"\n'{pattern}' not found in workspace_exclude for '{target['name']}' ({fmt_workspace(idx)}).")
            click.echo()
            return
        lst.remove(pattern)
        target["workspace_exclude"] = lst
        save_config(config)
        idx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == target["name"])
        click.echo(f'\nExclusion pattern removed from "{target["name"]}" ({fmt_workspace(idx)}): {pattern}')
        click.echo()

    restart_daemon(config)


# -- helpers -------------------------------------------------------------------

def _find_workspace(config: dict, name_or_id: str) -> dict | None:
    """Find a workspace by name or WS ID (e.g. WS1)."""
    workspaces = config.get("workspaces", [])
    v = name_or_id.strip().upper()
    if v.startswith("WS"):
        try:
            idx = int(v[2:]) - 1
            if 0 <= idx < len(workspaces):
                return workspaces[idx]
        except ValueError:
            pass
    for p in workspaces:
        if p["name"] == name_or_id:
            return p
    return None


def _do_add_folder(name_or_id: str, folder: str) -> None:
    from rewindex.utils.validation import same_folder
    from rewindex.license import is_pro
    from rewindex.config.defaults import FREE_MAX_FOLDERS, PRO_MAX_FOLDERS
    from rewindex.config.urls import LINK_PRICING, LINK_SUBSCRIPTION

    folder = os.path.expanduser(folder)
    if not os.path.isdir(folder):
        click.echo(f"Error: folder does not exist: {folder}")
        return

    config = load_config()
    target = _find_workspace(config, name_or_id)

    for p in config["workspaces"]:
        for existing in p.get("folders", []):
            if same_folder(folder, os.path.expanduser(existing)):
                click.echo(f"Error: folder '{folder}' is already watched by workspace '{p['name']}'.")
                return

    if target is None:
        click.echo(f"Workspace '{name_or_id}' not found.")
        return

    current_folders = len(target.get("folders", []))
    pro = is_pro()
    max_folders = PRO_MAX_FOLDERS if pro else FREE_MAX_FOLDERS

    if current_folders >= max_folders:
        if pro:
            click.echo(f"\nError: Pro plan allows up to {PRO_MAX_FOLDERS} folders per workspace.")
        else:
            click.echo(f"\nError: Free tier supports {FREE_MAX_FOLDERS} watched folder per workspace.")
            click.echo(f"Upgrade to Pro to add up to {PRO_MAX_FOLDERS} folders per workspace: {LINK_SUBSCRIPTION}")
        click.echo()
        return

    target.setdefault("folders", []).append(folder)
    save_config(config)
    from rewindex.utils.id_parse import fmt_workspace
    idx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == target["name"])
    click.echo(f'\nFolder added to "{target["name"]}" ({fmt_workspace(idx)})')
    click.echo(f"Now watching: {folder}\n")
    restart_daemon(config)


def _do_remove_folder(name_or_id: str, folder: str, yes: bool = False) -> None:
    from rewindex.utils.id_parse import fmt_workspace

    folder = os.path.expanduser(folder)
    config = load_config()
    target = _find_workspace(config, name_or_id)

    if target is None:
        click.echo(f"Workspace '{name_or_id}' not found.")
        return

    folders = target.get("folders", [])
    normalized = [os.path.expanduser(f) for f in folders]

    if folder not in normalized:
        click.echo(f"Folder '{folder}' is not in workspace '{target['name']}'.")
        return

    if len(folders) == 1:
        click.echo(f"Error: cannot remove the last folder. Use 'rewindex workspace remove {target['name']}' instead.")
        return

    pidx = next(i for i, p in enumerate(config["workspaces"], 1) if p["name"] == target["name"])

    if not yes:
        click.echo(f"\nStop watching: {folder} ({target['name']} {fmt_workspace(pidx)})")
        import questionary
        confirm = questionary.confirm("Confirm?", default=False).ask()
        if not confirm:
            click.echo("Cancelled.")
            return

    idx = normalized.index(folder)
    folders.pop(idx)
    save_config(config)
    click.echo(f'\nFolder removed from "{target["name"]}" ({fmt_workspace(pidx)})')
    click.echo(f"Stopped watching: {folder}")
    click.echo()
    restart_daemon(config)
