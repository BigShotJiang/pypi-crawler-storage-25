# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import click

from rewindex.config.loader import load_config
from rewindex.config.defaults import SNAPSHOTS_DIR
from rewindex.daemon.runner import is_running, read_pid


@click.command()
def status_cmd() -> None:
    """Show daemon status and active workspaces.

    \b
    rewindex status
    """
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import fmt_session, fmt_workspace
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_oldest_session, get_latest_session, get_session_count,
    )

    config = load_config()
    workspaces = config.get("workspaces", [])
    header = fmt_date_header()

    if is_running():
        pid = read_pid()
        click.echo(f"\nDaemon   running (PID {pid})  {header}")
    else:
        click.echo("\nDaemon   stopped")
        click.echo("Run `rewindex start` to start it.")
        click.echo()
        return

    click.echo("─" * 56)

    for i, ws in enumerate(workspaces):
        name = ws["name"]
        folders = ws.get("folders", [])
        ws_id = fmt_workspace(i + 1)

        click.echo(f"{ws_id}   {name}")

        click.echo(f"      Folders   {folders[0] if folders else '(none)'}")
        for f in folders[1:]:
            click.echo(f"                {f}")

        conn = get_connection(name)
        try:
            oldest = get_oldest_session(conn, name)
            latest = get_latest_session(conn, name)
            total_snaps = conn.execute(
                "SELECT COUNT(*) as cnt FROM file WHERE file_registry_uid IN "
                "(SELECT uid FROM file_registry WHERE workspace = ?)", (name,)
            ).fetchone()["cnt"]

            if oldest and latest:
                click.echo(f"      Sessions  {fmt_session(oldest['uid'])} (oldest) → {fmt_session(latest['uid'])} (latest)")
                click.echo(f"      Snaps     {total_snaps} total")
                click.echo(f"      Last      {fmt_date(latest['updated_at'])}")
            else:
                click.echo(f"      Sessions  (none)")

            disk = _get_workspace_disk_usage(name)
            if disk:
                click.echo(f"      Disk      {disk}")
        finally:
            conn.close()

        click.echo()


def _get_workspace_disk_usage(workspace_name: str) -> str | None:
    workspace_dir = os.path.join(SNAPSHOTS_DIR, workspace_name)
    if not os.path.isdir(workspace_dir):
        return None
    total = 0
    for root, dirs, files in os.walk(workspace_dir):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    if total < 1024:
        return f"{total} B"
    elif total < 1024 * 1024:
        return f"{total / 1024:.1f} KB"
    elif total < 1024 * 1024 * 1024:
        return f"{total / (1024 * 1024):.1f} MB"
    return f"{total / (1024 * 1024 * 1024):.1f} GB"
