# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
rewindex flag — version flag management commands.

Subcommands:
  rewindex flag <SS55|latest> [--ver "1.0.5"] [--minor|--major] --title "x" [--des "y"]
  rewindex flag list [--since SS50]
  rewindex flag show <ver>
  rewindex flag edit <ver> [--title "x"] [--des "y"]
  rewindex flag move <ver> <SS55|latest>
  rewindex flag delete <ver> --yes
  rewindex flag export --format md|json [--since SS50] [--output FILE]
"""

import json
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from typing import Optional

import click

from rewindex.commands._workspace import resolve_workspace
from rewindex.config.loader import load_config
from rewindex.db.connection import get_connection


# ---------------------------------------------------------------------------
# Routing helpers
# ---------------------------------------------------------------------------

_CREATE_ROUTE_KEY = "_flag_create_args"


def _is_create_target(arg: str) -> bool:
    """Return True if arg looks like a session target (SSN or 'latest')."""
    return bool(re.match(r'^ss\d+$', arg.strip().lower())) or arg.strip().lower() == "latest"


class _FlagGroup(click.Group):
    """Custom Click Group that routes SSN/latest to the implicit 'create' action.

    Click cannot simultaneously have:
    - An optional positional [TARGET] argument at the group level
    - Subcommands with their own options (e.g. ``flag list --since SS5``)

    Because Click's Group.parse_args has allow_interspersed_args=False, any
    positional token after group-level options stops option parsing and is placed
    in protected_args as the subcommand name. If [TARGET] is declared at the group
    level, it greedily consumes 'list', 'show', etc., breaking subcommand routing.

    This class resolves the conflict by inspecting the first positional token
    before Click's normal parse_args runs:
    - If it looks like a session target (SS\\d+ or 'latest'), bypass group-level
      parsing and route all args to the hidden 'create' subcommand directly.
    - Otherwise, let Click's normal Group.parse_args handle routing (subcommands
      receive their own args and options correctly).
    """

    def parse_args(self, ctx: click.Context, args: list) -> list:
        # Find the first non-option argument
        first_pos: Optional[str] = None
        for arg in args:
            if not arg.startswith("-"):
                first_pos = arg
                break

        if first_pos and _is_create_target(first_pos):
            # Route all tokens to the 'create' subcommand without consuming any
            # at the group level. We store args in ctx.obj for use in invoke().
            ctx.ensure_object(dict)
            ctx.obj[_CREATE_ROUTE_KEY] = list(args)
            return []  # nothing consumed at group level

        # Normal routing: subcommands receive their args correctly
        return super().parse_args(ctx, args)

    def invoke(self, ctx: click.Context):
        obj = ctx.obj or {}
        if _CREATE_ROUTE_KEY in obj:
            args = obj.pop(_CREATE_ROUTE_KEY)
            cmd = self.get_command(ctx, "create")
            if cmd is not None:
                sub_ctx = cmd.make_context("create", list(args), parent=ctx)
                with sub_ctx:
                    return cmd.invoke(sub_ctx)
        return super().invoke(ctx)


# ---------------------------------------------------------------------------
# Group
# ---------------------------------------------------------------------------

@click.group(name="flag", invoke_without_command=True, cls=_FlagGroup)
@click.pass_context
def flag_cmd(ctx: click.Context) -> None:
    """Manage version flags (milestones).

    \b
    rewindex flag <SS55|latest> --title "x"      create flag on session
    rewindex flag list                            list all flags
    rewindex flag show <ver>                      show flag detail
    rewindex flag edit <ver> --title "x"          edit flag (non-interactive)
    rewindex flag edit <ver>                      edit flag in $EDITOR
    rewindex flag delete <ver> --yes              delete flag
    rewindex flag export --format md|json         export changelog
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None and _CREATE_ROUTE_KEY not in (ctx.obj or {}):
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Create (default action)
# ---------------------------------------------------------------------------

@flag_cmd.command(name="create", hidden=True)
@click.argument("target")
@click.option("--ver", default=None, help='Explicit version string (e.g. "1.0.5").')
@click.option("--minor", "bump_minor", is_flag=True, default=False, help="Bump minor version.")
@click.option("--major", "bump_major", is_flag=True, default=False, help="Bump major version.")
@click.option("--title", required=True, prompt="Flag title", help="Short flag title.")
@click.option("--des", default=None, help="Long description (markdown, max 8 KB).")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def _create(
    target: str,
    ver: Optional[str],
    bump_minor: bool,
    bump_major: bool,
    title: str,
    des: Optional[str],
    workspace: Optional[str],
) -> None:
    """Create a new version flag on a session."""
    from rewindex.utils.id_parse import fmt_session, is_session_target, parse_session_id
    from rewindex.utils.formatting import fmt_date_full
    from rewindex.utils.version import (
        bump_version, validate_explicit_version,
    )
    from rewindex.db.queries import (
        create_flag,
        get_flag_by_session,
        get_flag_by_version,
        get_latest_flag,
        get_latest_session,
        get_session_by_uid,
    )

    config = load_config()
    workspaces = config.get("workspaces", [])
    flag_cfg = config.get("flag", {})

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return

    conn = get_connection(workspace_name)
    try:
        # Resolve target session
        if target.lower() == "latest":
            sess = get_latest_session(conn, workspace_name)
            if sess is None:
                click.echo("No sessions found for this workspace.")
                return
            session_uid = sess["uid"]
        elif is_session_target(target):
            try:
                session_uid = parse_session_id(target)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
            sess = get_session_by_uid(conn, session_uid)
            if sess is None:
                click.echo(f"Error: {fmt_session(session_uid)} not found.")
                return
        else:
            click.echo(f"Error: invalid target '{target}'. Use SSN or 'latest'.")
            return

        # Check session not already flagged
        existing = get_flag_by_session(conn, workspace_name, session_uid)
        if existing:
            click.echo(
                f"Error: {fmt_session(session_uid)} already has flag {existing['version']} "
                f"— \"{existing['title']}\"."
            )
            return

        # Determine version
        segments = flag_cfg.get("version_segments", 3)
        auto_bump = flag_cfg.get("auto_bump", "patch")
        max_desc_bytes = flag_cfg.get("max_description_bytes", 8192)
        promote_fb = flag_cfg.get("promote_to_fullbase", False)

        # Exclusive check: at most one of --ver / --minor / --major
        bump_flags = sum([bool(ver), bump_minor, bump_major])
        if bump_flags > 1:
            click.echo("Error: --ver, --minor, and --major are mutually exclusive.")
            return

        latest_flag = get_latest_flag(conn, workspace_name)
        current_version = latest_flag["version"] if latest_flag else None

        if ver:
            try:
                new_version = validate_explicit_version(ver, segments)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
        elif bump_minor:
            try:
                new_version = bump_version(current_version, "minor", segments)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
        elif bump_major:
            try:
                new_version = bump_version(current_version, "major", segments)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
        else:
            try:
                new_version = bump_version(current_version, auto_bump, segments)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return

        # Uniqueness check
        collision = get_flag_by_version(conn, workspace_name, new_version)
        if collision:
            click.echo(
                f"Error: version {new_version} already exists — "
                f"\"{collision['title']}\" on {fmt_session(collision['session_uid'])}."
            )
            return

        # Validate title
        if not title or not title.strip():
            click.echo("Error: --title is required and must not be empty.")
            return

        # Validate description size
        if des and len(des.encode("utf-8")) > max_desc_bytes:
            click.echo(
                f"Error: description exceeds {max_desc_bytes} bytes limit "
                f"({len(des.encode('utf-8'))} bytes)."
            )
            return

        created_at = datetime.now(timezone.utc).isoformat()

        flag_uid = create_flag(
            conn=conn,
            session_uid=session_uid,
            workspace=workspace_name,
            version=new_version,
            title=title.strip(),
            created_at=created_at,
            description=des,
            promoted_to_fullbase=promote_fb,
        )

        # M9: Fullbase promotion
        if promote_fb:
            _promote_session_fullbase(conn, workspace_name, session_uid)

        click.echo(f"Flag created: {new_version} — \"{title.strip()}\" on {fmt_session(session_uid)}")
        if des:
            click.echo(f"  Description: {des[:80]}{'...' if len(des) > 80 else ''}")
        if promote_fb:
            click.echo("  Session promoted to fullbase.")

    finally:
        conn.close()


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------

@flag_cmd.command(name="list")
@click.option("--since", default=None, help="Show flags since session (e.g. SS50).")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def _list(since: Optional[str], workspace: Optional[str]) -> None:
    """List all version flags for the workspace."""
    from rewindex.utils.id_parse import fmt_session, is_session_target, parse_session_id
    from rewindex.utils.formatting import fmt_date_full
    from rewindex.db.queries import list_flags

    config = load_config()
    workspaces = config.get("workspaces", [])

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return

    since_uid: Optional[int] = None
    if since:
        if is_session_target(since):
            try:
                since_uid = parse_session_id(since)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
        else:
            click.echo(f"Error: invalid --since value '{since}'. Use session ID like SS50.")
            return

    conn = get_connection(workspace_name)
    try:
        flags = list_flags(conn, workspace_name, since_session_uid=since_uid)
    finally:
        conn.close()

    if not flags:
        click.echo("No flags found.")
        return

    click.echo(f"\n{'Date':<17}  {'Session':<8}  {'Version':<12}  Title")
    click.echo("─" * 64)
    for f in flags:
        date_str = fmt_date_full(f["created_at"])
        sess_str = fmt_session(f["session_uid"])
        orphan_tag = "  [orphaned]" if f["is_orphaned"] else ""
        click.echo(f"{date_str:<17}  {sess_str:<8}  {f['version']:<12}  {f['title']}{orphan_tag}")
        if f["description"]:
            for line in f["description"].splitlines()[:4]:
                click.echo(f"                                            {line}")
    click.echo()


# ---------------------------------------------------------------------------
# Show
# ---------------------------------------------------------------------------

@flag_cmd.command(name="show")
@click.argument("version")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def _show(version: str, workspace: Optional[str]) -> None:
    """Show full detail for a version flag."""
    from rewindex.utils.id_parse import fmt_session
    from rewindex.utils.formatting import fmt_date_full
    from rewindex.db.queries import get_flag_by_version

    config = load_config()
    workspaces = config.get("workspaces", [])

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return

    # Normalise version: prepend 'v' if missing
    ver_str = version if version.startswith("v") else f"v{version}"

    conn = get_connection(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
    finally:
        conn.close()

    if flag is None:
        click.echo(f"Flag '{ver_str}' not found.")
        return

    orphan_note = "  [orphaned — session was trimmed]" if flag["is_orphaned"] else ""
    click.echo(f"\n{flag['version']}  ·  {flag['title']}{orphan_note}")
    click.echo(f"  Session:    {fmt_session(flag['session_uid'])}")
    click.echo(f"  Created:    {fmt_date_full(flag['created_at'])}")
    if flag["promoted_to_fullbase"]:
        click.echo("  Fullbase:   yes")
    if flag["description"]:
        click.echo("\n  Description:")
        for line in flag["description"].splitlines():
            click.echo(f"    {line}")
    click.echo()


# ---------------------------------------------------------------------------
# Edit
# ---------------------------------------------------------------------------

@flag_cmd.command(name="edit")
@click.argument("version")
@click.option("--title", default=None, help="New title (non-interactive mode).")
@click.option("--des", default=None, help="New description (non-interactive mode).")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def _edit(version: str, title: Optional[str], des: Optional[str], workspace: Optional[str]) -> None:
    """Edit a flag's title and description.

    \b
    rewindex flag edit v1.0.5               open $EDITOR (interactive)
    rewindex flag edit v1.0.5 --title "x"  update without editor (AI-friendly)
    """
    from rewindex.db.queries import get_flag_by_version, update_flag

    config = load_config()
    workspaces = config.get("workspaces", [])
    flag_cfg = config.get("flag", {})
    max_desc_bytes = flag_cfg.get("max_description_bytes", 8192)

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return

    ver_str = version if version.startswith("v") else f"v{version}"

    conn = get_connection(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
        if flag is None:
            click.echo(f"Flag '{ver_str}' not found.")
            return

        if title is not None or des is not None:
            # Non-interactive mode
            new_title = title.strip() if title else flag["title"]
            new_des = des if des is not None else flag["description"]

            if not new_title:
                click.echo("Error: title must not be empty.")
                return

            if new_des and len(new_des.encode("utf-8")) > max_desc_bytes:
                click.echo(
                    f"Error: description exceeds {max_desc_bytes} bytes limit."
                )
                return

            update_flag(conn, workspace_name, ver_str, new_title, new_des)
            click.echo(f"Flag {ver_str} updated.")
        else:
            # Interactive: open $EDITOR
            new_title, new_des = _edit_in_editor(flag["title"], flag["description"] or "")
            if new_title is None:
                click.echo("Edit aborted — no changes saved.")
                return

            if not new_title.strip():
                click.echo("Error: title must not be empty. Edit aborted.")
                return

            if new_des and len(new_des.encode("utf-8")) > max_desc_bytes:
                click.echo(f"Error: description exceeds {max_desc_bytes} bytes limit.")
                return

            update_flag(conn, workspace_name, ver_str, new_title.strip(), new_des or None)
            click.echo(f"Flag {ver_str} updated.")
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Move
# ---------------------------------------------------------------------------

@flag_cmd.command(name="move")
@click.argument("version")
@click.argument("target")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def _move(version: str, target: str, workspace: Optional[str]) -> None:
    """Move a flag to a different session.

    \b
    rewindex flag move v1.0.5 SS10
    rewindex flag move v1.0.5 latest
    """
    from rewindex.db.queries import (
        get_flag_by_version,
        get_flag_by_session,
        get_session_by_uid,
        get_latest_session,
        move_flag,
    )

    config = load_config()
    workspaces = config.get("workspaces", [])

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return

    ver_str = version if version.startswith("v") else f"v{version}"

    conn = get_connection(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
        if flag is None:
            click.echo(f"Flag '{ver_str}' not found.")
            return

        old_ss = flag["session_uid"]

        if target.lower() == "latest":
            sess = get_latest_session(conn, workspace_name)
            if sess is None:
                click.echo("No sessions found.")
                return
            new_ss = sess["uid"]
        else:
            m = re.match(r'^[Ss]{2}(\d+)$', target.strip())
            if not m:
                click.echo(f"Invalid target '{target}'. Use SS10 or 'latest'.")
                return
            new_ss = int(m.group(1))
            sess = get_session_by_uid(conn, new_ss)
            if sess is None:
                click.echo(f"SS{new_ss} not found.")
                return

        if new_ss == old_ss:
            click.echo(f"Flag {ver_str} is already on SS{old_ss}.")
            return

        existing = get_flag_by_session(conn, workspace_name, new_ss)
        if existing:
            click.echo(f"SS{new_ss} already has flag {existing['version']}.")
            return

        move_flag(conn, workspace_name, ver_str, new_ss)
        click.echo(f"Flag {ver_str} moved: SS{old_ss} -> SS{new_ss}.")
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------

@flag_cmd.command(name="delete")
@click.argument("version")
@click.option("--yes", is_flag=True, default=False, help="Confirm deletion without prompt.")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def _delete(version: str, yes: bool, workspace: Optional[str]) -> None:
    """Delete a version flag."""
    from rewindex.db.queries import delete_flag, get_flag_by_version

    config = load_config()
    workspaces = config.get("workspaces", [])

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return

    ver_str = version if version.startswith("v") else f"v{version}"

    conn = get_connection(workspace_name)
    try:
        flag = get_flag_by_version(conn, workspace_name, ver_str)
        if flag is None:
            click.echo(f"Flag '{ver_str}' not found.")
            return

        if not yes:
            click.echo(f"Delete flag {ver_str} — \"{flag['title']}\"?  Pass --yes to confirm.")
            return

        deleted = delete_flag(conn, workspace_name, ver_str)
        if deleted:
            click.echo(f"Flag {ver_str} deleted.")
        else:
            click.echo(f"Flag {ver_str} not found.")
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

@flag_cmd.command(name="export")
@click.option("--format", "fmt", type=click.Choice(["md", "json"], case_sensitive=False),
              required=True, help="Output format: md or json.")
@click.option("--since", default=None, help="Include flags since session (e.g. SS50).")
@click.option("--output", default=None, help="Write output to FILE instead of stdout.")
@click.option("--workspace", "-w", default=None, help="Workspace name or WS ID.")
def _export(fmt: str, since: Optional[str], output: Optional[str], workspace: Optional[str]) -> None:
    """Export flags as a changelog (markdown or JSON)."""
    from rewindex.utils.id_parse import fmt_session, is_session_target, parse_session_id
    from rewindex.utils.formatting import fmt_date_full
    from rewindex.db.queries import list_flags

    config = load_config()
    workspaces = config.get("workspaces", [])

    if not workspaces:
        click.echo("No workspaces configured.")
        return

    workspace_name = resolve_workspace(workspaces, workspace, interactive=False)
    if workspace_name is None:
        return

    since_uid: Optional[int] = None
    if since:
        if is_session_target(since):
            try:
                since_uid = parse_session_id(since)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
        else:
            click.echo(f"Error: invalid --since value '{since}'. Use session ID like SS50.")
            return

    conn = get_connection(workspace_name)
    try:
        flags = list_flags(conn, workspace_name, since_session_uid=since_uid)
    finally:
        conn.close()

    if fmt.lower() == "json":
        content = _export_json(flags)
    else:
        content = _export_md(flags, workspace_name)

    if output:
        try:
            with open(output, "w", encoding="utf-8") as fh:
                fh.write(content)
            click.echo(f"Exported {len(flags)} flag(s) to {output}")
        except OSError as e:
            click.echo(f"Error writing to {output}: {e}")
    else:
        click.echo(content)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _bump_headers(text: str, levels: int = 1) -> str:
    """Shift markdown headers down by N levels (# → ###)."""
    def _replace(m):
        return "#" * (len(m.group(1)) + levels) + m.group(2)
    return re.sub(r'^(#{1,6})([ \t])', _replace, text, flags=re.MULTILINE)


def _export_md(flags, workspace_name: str) -> str:
    lines = [f"# {workspace_name} — Changelog\n"]
    for f in reversed(list(flags)):  # newest first
        orphan = " *(orphaned)*" if f["is_orphaned"] else ""
        lines.append(f"## {f['version']} — {f['title']}{orphan}\n")
        lines.append(f"**Session:** {_fmt_ss(f['session_uid'])}  ")
        lines.append(f"**Date:** {f['created_at'][:10]}\n")
        if f["description"]:
            lines.append("")
            lines.append(_bump_headers(f["description"]))
            lines.append("")
        lines.append("---\n")
    lines.append("\n*Powered by [Rewindex](https://rewindex.org)*\n")
    return "\n".join(lines)


def _export_json(flags) -> str:
    data = [
        {
            "version": f["version"],
            "title": f["title"],
            "description": f["description"],
            "session_uid": f["session_uid"],
            "created_at": f["created_at"],
            "is_orphaned": bool(f["is_orphaned"]),
        }
        for f in flags
    ]
    return json.dumps(data, ensure_ascii=False, indent=2)


def _fmt_ss(uid: int) -> str:
    return f"SS{uid}"


def _edit_in_editor(
    current_title: str, current_description: str
) -> tuple[Optional[str], Optional[str]]:
    """Open $EDITOR with title + description template.

    Returns (title, description) on successful save,
    or (None, None) if user saves an empty/unchanged buffer.
    """
    template = (
        f"{current_title}\n"
        "\n"
        f"{current_description}"
    )

    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vi"

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", encoding="utf-8", delete=False
    ) as tmp:
        tmp.write(template)
        tmp_path = tmp.name

    try:
        result = subprocess.run([editor, tmp_path])
        if result.returncode != 0:
            return None, None

        with open(tmp_path, "r", encoding="utf-8") as fh:
            edited = fh.read()
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass

    if not edited.strip() or edited.strip() == template.strip():
        return None, None

    lines = edited.split("\n", 2)
    new_title = lines[0].strip() if lines else ""
    new_des = lines[2].strip() if len(lines) > 2 else ""
    return new_title or None, new_des or None


def _promote_session_fullbase(conn, workspace_name: str, session_uid: int) -> None:
    """Promote all file versions in a session to fullbase."""
    import hashlib
    from rewindex.db.queries import get_files_in_session, promote_to_full_base
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.storage import write_full

    files = get_files_in_session(conn, session_uid)
    for f in files:
        if f["is_full"]:
            continue
        try:
            lines = reconstruct(conn, f["file_registry_uid"], f["uid"])
        except (ValueError, OSError):
            continue
        try:
            storage_path, file_size = write_full(
                workspace_name, f["uid"], f["filepath"], lines
            )
            promote_to_full_base(conn, f["uid"], storage_path, file_size, promoted_by="flag")
        except OSError:
            continue
