# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import json
import random
import sqlite3
import string
from typing import Optional


# --- File Registry ---

def get_or_create_file_registry(
    conn: sqlite3.Connection, workspace: str, folder_path: str, filepath: str
) -> tuple[int, str, int]:
    """Return (registry_uid, file_id, next_version) for a filepath.
    Creates a new registry entry with a 4-char FileID if first time."""
    row = conn.execute(
        "SELECT uid, file_id FROM file_registry WHERE workspace = ? AND folder_path = ? AND filepath = ?",
        (workspace, folder_path, filepath),
    ).fetchone()

    if row:
        registry_uid = row["uid"]
        file_id = row["file_id"]
        ver_row = conn.execute(
            "SELECT MAX(file_version) as max_ver FROM file WHERE file_registry_uid = ?",
            (registry_uid,),
        ).fetchone()
        next_ver = (ver_row["max_ver"] or 0) + 1
        return registry_uid, file_id, next_ver

    file_id = _generate_file_id(conn, workspace)
    filename = filepath.rsplit("/", 1)[-1] if "/" in filepath else filepath
    cur = conn.execute(
        "INSERT INTO file_registry (file_id, workspace, folder_path, filepath, filename) VALUES (?, ?, ?, ?, ?)",
        (file_id, workspace, folder_path, filepath, filename),
    )
    conn.commit()
    return cur.lastrowid, file_id, 1


def _generate_file_id(conn: sqlite3.Connection, workspace: str) -> str:
    """Generate a unique 4-char alphanumeric FileID for a workspace."""
    chars = string.ascii_uppercase + string.digits
    for _ in range(1000):
        code = "".join(random.choices(chars, k=4))
        existing = conn.execute(
            "SELECT 1 FROM file_registry WHERE workspace = ? AND file_id = ?",
            (workspace, code),
        ).fetchone()
        if not existing:
            return code
    raise RuntimeError("failed to generate unique FileID after 1000 attempts")


def get_file_registry_by_id(
    conn: sqlite3.Connection, workspace: str, file_id: str
) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM file_registry WHERE workspace = ? AND file_id = ?",
        (workspace, file_id.upper()),
    ).fetchone()


def get_all_tracked_files(conn: sqlite3.Connection, workspace: str) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM file_registry WHERE workspace = ?", (workspace,)
    ).fetchall()


def rename_tracked_file(
    conn: sqlite3.Connection, workspace: str, folder_path: str,
    old_filepath: str, new_filepath: str, new_filename: str,
) -> bool:
    """Update filepath and filename for a tracked file after move/rename.
    Returns True if a registry row was updated."""
    row = conn.execute(
        "SELECT uid FROM file_registry WHERE workspace = ? AND folder_path = ? AND filepath = ?",
        (workspace, folder_path, old_filepath),
    ).fetchone()
    if not row:
        return False
    conn.execute(
        "UPDATE file_registry SET filepath = ?, filename = ? WHERE uid = ?",
        (new_filepath, new_filename, row["uid"]),
    )
    conn.commit()
    return True


# --- Sessions ---

def get_or_create_session(
    conn: sqlite3.Connection, workspace: str, created_at: str, gap_seconds: float = 20.0
) -> int:
    """Find the current open session or create a new one.
    A session is 'open' if its updated_at is within gap_seconds of created_at."""
    row = conn.execute(
        """SELECT uid, updated_at FROM sessions
           WHERE workspace = ? ORDER BY uid DESC LIMIT 1""",
        (workspace,),
    ).fetchone()

    if row:
        from datetime import datetime, timezone
        last_updated = datetime.fromisoformat(row["updated_at"].replace("Z", "+00:00"))
        now = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        delta = (now - last_updated).total_seconds()
        if delta <= gap_seconds:
            conn.execute(
                "UPDATE sessions SET updated_at = ? WHERE uid = ?",
                (created_at, row["uid"]),
            )
            conn.commit()
            return row["uid"]

    cur = conn.execute(
        "INSERT INTO sessions (workspace, created_at, updated_at, is_forced) VALUES (?, ?, ?, 0)",
        (workspace, created_at, created_at),
    )
    conn.commit()
    return cur.lastrowid


def create_forced_session(conn: sqlite3.Connection, workspace: str, created_at: str) -> int:
    """Create a new forced session (from `snap` command)."""
    cur = conn.execute(
        "INSERT INTO sessions (workspace, created_at, updated_at, is_forced) VALUES (?, ?, ?, 1)",
        (workspace, created_at, created_at),
    )
    conn.commit()
    return cur.lastrowid


def get_session_by_uid(conn: sqlite3.Connection, uid: int) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM sessions WHERE uid = ?", (uid,)
    ).fetchone()


def get_sessions(
    conn: sqlite3.Connection,
    workspace: str,
    limit: int = 15,
    since: Optional[str] = None,
    reverse: bool = False,
    from_uid: Optional[int] = None,
    to_uid: Optional[int] = None,
) -> list[sqlite3.Row]:
    query = "SELECT * FROM sessions WHERE workspace = ?"
    params: list = [workspace]

    if since:
        query += " AND created_at >= ?"
        params.append(since)

    if from_uid is not None:
        query += " AND uid >= ?"
        params.append(from_uid)

    if to_uid is not None:
        query += " AND uid <= ?"
        params.append(to_uid)

    if from_uid is not None:
        inner_order = "ASC"
    elif reverse:
        inner_order = "ASC"
    else:
        inner_order = "DESC"
    inner = f"SELECT * FROM ({query} ORDER BY uid {inner_order} LIMIT ?) ORDER BY uid ASC"
    params.append(limit)
    return conn.execute(inner, params).fetchall()


def get_session_count(conn: sqlite3.Connection, workspace: str) -> int:
    row = conn.execute(
        "SELECT COUNT(*) as cnt FROM sessions WHERE workspace = ?", (workspace,)
    ).fetchone()
    return row["cnt"]


def get_oldest_session(conn: sqlite3.Connection, workspace: str) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM sessions WHERE workspace = ? ORDER BY uid ASC LIMIT 1", (workspace,)
    ).fetchone()


def get_latest_session(conn: sqlite3.Connection, workspace: str) -> Optional[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM sessions WHERE workspace = ? ORDER BY uid DESC LIMIT 1", (workspace,)
    ).fetchone()


def update_session_note(conn: sqlite3.Connection, session_uid: int, note: str) -> bool:
    cur = conn.execute(
        "UPDATE sessions SET note = ? WHERE uid = ?", (note, session_uid)
    )
    conn.commit()
    return cur.rowcount > 0


def close_session(conn: sqlite3.Connection, session_uid: int) -> None:
    """Mark a session as closed so the next change starts a new session.
    Sets updated_at far enough in the past to exceed the gap threshold."""
    conn.execute(
        "UPDATE sessions SET updated_at = '2000-01-01T00:00:00+00:00' WHERE uid = ?",
        (session_uid,),
    )
    conn.commit()


# --- File (versions / snapshots) ---

def insert_file_version(
    conn: sqlite3.Connection,
    file_registry_uid: int,
    file_version: int,
    created_at: str,
    hash: str,
    is_full: bool,
    is_deleted: bool = False,
    is_compressed: bool = False,
    session_uid: Optional[int] = None,
    status: str = "CHANGE",
    filepath: Optional[str] = None,
) -> int:
    """Insert a placeholder file version row. Call finalize_file_version after writing."""
    if filepath is None:
        row = conn.execute(
            "SELECT filepath FROM file_registry WHERE uid = ?",
            (file_registry_uid,),
        ).fetchone()
        filepath = row["filepath"] if row else ""
    cur = conn.execute(
        """INSERT INTO file (
            file_registry_uid, file_version, created_at, hash,
            is_full, is_deleted, is_compressed, session_uid,
            status, storage_path, file_size, filepath
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '', 0, ?)""",
        (
            file_registry_uid, file_version, created_at, hash,
            int(is_full), int(is_deleted), int(is_compressed), session_uid,
            status, filepath,
        ),
    )
    conn.commit()
    return cur.lastrowid


def finalize_file_version(
    conn: sqlite3.Connection, uid: int, storage_path: str, file_size: int
) -> None:
    conn.execute(
        "UPDATE file SET storage_path = ?, file_size = ? WHERE uid = ?",
        (storage_path, file_size, uid),
    )
    conn.commit()


def get_file_version(conn: sqlite3.Connection, uid: int) -> Optional[sqlite3.Row]:
    return conn.execute("SELECT * FROM file WHERE uid = ?", (uid,)).fetchone()


def update_file_symbols(
    conn: sqlite3.Connection,
    uid: int,
    symbols: list[str],
    lines_added: int,
    lines_removed: int,
) -> None:
    conn.execute(
        "UPDATE file SET symbols = ?, lines_added = ?, lines_removed = ? WHERE uid = ?",
        (json.dumps(symbols), lines_added, lines_removed, uid),
    )
    conn.commit()


def get_file_versions_for_registry(
    conn: sqlite3.Connection, registry_uid: int
) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 ORDER BY uid ASC",
        (registry_uid,),
    ).fetchall()


def get_latest_file_version(
    conn: sqlite3.Connection, registry_uid: int
) -> Optional[sqlite3.Row]:
    return conn.execute(
        """SELECT * FROM file
           WHERE file_registry_uid = ? AND is_corrupted = 0
           ORDER BY uid DESC LIMIT 1""",
        (registry_uid,),
    ).fetchone()


def get_full_base_for_file(
    conn: sqlite3.Connection, registry_uid: int
) -> Optional[sqlite3.Row]:
    """Get the oldest fullbase for a file (fullbase 1)."""
    return conn.execute(
        """SELECT * FROM file
           WHERE file_registry_uid = ? AND is_full = 1 AND is_corrupted = 0
           ORDER BY uid ASC LIMIT 1""",
        (registry_uid,),
    ).fetchone()


def get_file_versions_since(
    conn: sqlite3.Connection, registry_uid: int, since_uid: int, limit: int = 1001
) -> list[sqlite3.Row]:
    return conn.execute(
        """SELECT * FROM file
           WHERE file_registry_uid = ? AND uid >= ? AND is_corrupted = 0
           ORDER BY uid ASC LIMIT ?""",
        (registry_uid, since_uid, limit),
    ).fetchall()


def get_files_in_session(conn: sqlite3.Connection, session_uid: int) -> list[sqlite3.Row]:
    """Get all file versions created in a specific session, joined with registry."""
    return conn.execute(
        """SELECT f.uid, f.file_registry_uid, f.file_version, f.created_at,
                  f.hash, f.status, f.is_full, f.storage_path, f.file_size,
                  f.is_corrupted, f.is_compressed, f.note, f.is_deleted,
                  f.session_uid, f.promoted_by, f.filepath AS snap_filepath,
                  f.symbols, f.lines_added, f.lines_removed,
                  r.file_id, r.filepath, r.filename
           FROM file f
           JOIN file_registry r ON f.file_registry_uid = r.uid
           WHERE f.session_uid = ?
           ORDER BY f.uid ASC""",
        (session_uid,),
    ).fetchall()


def get_all_snapshots(
    conn: sqlite3.Connection,
    workspace: str,
    limit: int = 50,
    since: Optional[str] = None,
    folder: Optional[str] = None,
    reverse: bool = False,
    from_uid: Optional[int] = None,
    to_uid: Optional[int] = None,
) -> list[sqlite3.Row]:
    """Get all file versions (flat list) for a workspace, joined with registry."""
    query = """SELECT f.uid, f.file_registry_uid, f.file_version, f.created_at,
                      f.hash, f.status, f.is_full, f.storage_path, f.file_size,
                      f.is_corrupted, f.is_compressed, f.note, f.is_deleted,
                      f.session_uid, f.promoted_by, f.filepath AS snap_filepath,
                      r.file_id, r.filepath, r.filename
               FROM file f
               JOIN file_registry r ON f.file_registry_uid = r.uid
               WHERE r.workspace = ?"""
    params: list = [workspace]

    if since:
        query += " AND f.created_at >= ?"
        params.append(since)

    if folder:
        query += " AND r.filepath LIKE ?"
        params.append(folder + "%")

    if from_uid is not None:
        query += " AND f.uid >= ?"
        params.append(from_uid)

    if to_uid is not None:
        query += " AND f.uid <= ?"
        params.append(to_uid)

    if from_uid is not None:
        inner_order = "ASC"
    elif reverse:
        inner_order = "ASC"
    else:
        inner_order = "DESC"
    inner = f"SELECT * FROM ({query} ORDER BY f.uid {inner_order} LIMIT ?) ORDER BY uid ASC"
    params.append(limit)
    return conn.execute(inner, params).fetchall()


def get_latest_version_at_session(
    conn: sqlite3.Connection, registry_uid: int, session_uid: int
) -> Optional[sqlite3.Row]:
    """Get the latest version of a file at or before a given session."""
    return conn.execute(
        """SELECT * FROM file
           WHERE file_registry_uid = ? AND session_uid <= ? AND is_corrupted = 0
           ORDER BY uid DESC LIMIT 1""",
        (registry_uid, session_uid),
    ).fetchone()


def resolve_file_version(
    conn: sqlite3.Connection, workspace: str, file_id: str, version: int
) -> Optional[sqlite3.Row]:
    """Look up a file version by FileID + version number."""
    reg = get_file_registry_by_id(conn, workspace, file_id)
    if not reg:
        return None
    return conn.execute(
        """SELECT * FROM file
           WHERE file_registry_uid = ? AND file_version = ? AND is_corrupted = 0
           LIMIT 1""",
        (reg["uid"], version),
    ).fetchone()


def get_file_version_range(
    conn: sqlite3.Connection, registry_uid: int
) -> tuple[Optional[int], Optional[int]]:
    """Return (oldest_version, latest_version) for a file."""
    row = conn.execute(
        """SELECT MIN(file_version) as min_v, MAX(file_version) as max_v
           FROM file WHERE file_registry_uid = ? AND is_corrupted = 0""",
        (registry_uid,),
    ).fetchone()
    if row and row["min_v"] is not None:
        return row["min_v"], row["max_v"]
    return None, None


# --- Notes ---

def update_file_note(conn: sqlite3.Connection, file_uid: int, note: str) -> bool:
    cur = conn.execute("UPDATE file SET note = ? WHERE uid = ?", (note, file_uid))
    conn.commit()
    return cur.rowcount > 0


# --- Trim ---

def get_sessions_to_trim(
    conn: sqlite3.Connection, workspace: str, cut: int
) -> list[sqlite3.Row]:
    """Get the oldest `cut` sessions for a workspace (candidates for trim)."""
    return conn.execute(
        "SELECT * FROM sessions WHERE workspace = ? ORDER BY uid ASC LIMIT ?",
        (workspace, cut),
    ).fetchall()


def delete_file_versions_before(
    conn: sqlite3.Connection, registry_uid: int, before_uid: int
) -> list[str]:
    """Delete all file versions with uid < before_uid. Returns storage_paths for disk cleanup."""
    rows = conn.execute(
        "SELECT storage_path FROM file WHERE file_registry_uid = ? AND uid < ?",
        (registry_uid, before_uid),
    ).fetchall()
    paths = [r["storage_path"] for r in rows if r["storage_path"]]
    conn.execute(
        "DELETE FROM file WHERE file_registry_uid = ? AND uid < ?",
        (registry_uid, before_uid),
    )
    conn.commit()
    return paths


def delete_sessions_before(conn: sqlite3.Connection, workspace: str, before_uid: int) -> None:
    conn.execute(
        "DELETE FROM sessions WHERE workspace = ? AND uid < ?",
        (workspace, before_uid),
    )
    conn.commit()


def mark_corrupted(conn: sqlite3.Connection, file_uid: int) -> None:
    conn.execute("UPDATE file SET is_corrupted = 1, status = 'CORRUPT' WHERE uid = ?", (file_uid,))
    conn.commit()


def promote_to_full_base(
    conn: sqlite3.Connection, file_uid: int, storage_path: str, file_size: int,
    promoted_by: str | None = None,
) -> None:
    conn.execute(
        "UPDATE file SET is_full = 1, storage_path = ?, file_size = ?, promoted_by = ? WHERE uid = ?",
        (storage_path, file_size, promoted_by, file_uid),
    )
    conn.commit()



# --- Flags ---

def create_flag(
    conn: sqlite3.Connection,
    session_uid: int,
    workspace: str,
    version: str,
    title: str,
    created_at: str,
    description: Optional[str] = None,
    promoted_to_fullbase: bool = False,
) -> int:
    """Insert a new flag row. Returns the new flag uid."""
    cur = conn.execute(
        """INSERT INTO flags
           (session_uid, workspace, version, title, description, created_at,
            promoted_to_fullbase, is_orphaned)
           VALUES (?, ?, ?, ?, ?, ?, ?, 0)""",
        (session_uid, workspace, version, title, description, created_at,
         int(promoted_to_fullbase)),
    )
    conn.commit()
    return cur.lastrowid


def get_flag_by_version(
    conn: sqlite3.Connection, workspace: str, version: str
) -> Optional[sqlite3.Row]:
    """Fetch a single flag by its version string."""
    return conn.execute(
        "SELECT * FROM flags WHERE workspace = ? AND version = ?",
        (workspace, version),
    ).fetchone()


def get_flag_by_session(
    conn: sqlite3.Connection, workspace: str, session_uid: int
) -> Optional[sqlite3.Row]:
    """Fetch the flag attached to a session, if any."""
    return conn.execute(
        "SELECT * FROM flags WHERE workspace = ? AND session_uid = ?",
        (workspace, session_uid),
    ).fetchone()


def get_flags_by_sessions(
    conn: sqlite3.Connection, workspace: str, session_uids: list[int]
) -> dict[int, sqlite3.Row]:
    """Return a dict mapping session_uid -> flag row for the given session uids."""
    if not session_uids:
        return {}
    placeholders = ",".join("?" * len(session_uids))
    rows = conn.execute(
        f"SELECT * FROM flags WHERE workspace = ? AND session_uid IN ({placeholders})",
        [workspace] + list(session_uids),
    ).fetchall()
    return {r["session_uid"]: r for r in rows}


def list_flags(
    conn: sqlite3.Connection,
    workspace: str,
    since_session_uid: Optional[int] = None,
) -> list[sqlite3.Row]:
    """List all flags for a workspace, ordered by session_uid ASC."""
    query = "SELECT * FROM flags WHERE workspace = ?"
    params: list = [workspace]
    if since_session_uid is not None:
        query += " AND session_uid >= ?"
        params.append(since_session_uid)
    query += " ORDER BY session_uid ASC"
    return conn.execute(query, params).fetchall()


def get_latest_flag(
    conn: sqlite3.Connection, workspace: str
) -> Optional[sqlite3.Row]:
    """Get the most recently created flag for a workspace."""
    return conn.execute(
        "SELECT * FROM flags WHERE workspace = ? ORDER BY session_uid DESC LIMIT 1",
        (workspace,),
    ).fetchone()


def update_flag(
    conn: sqlite3.Connection,
    workspace: str,
    version: str,
    title: str,
    description: Optional[str],
) -> bool:
    """Update the title and description of a flag. Returns True if updated."""
    cur = conn.execute(
        "UPDATE flags SET title = ?, description = ? WHERE workspace = ? AND version = ?",
        (title, description, workspace, version),
    )
    conn.commit()
    return cur.rowcount > 0


def delete_flag(
    conn: sqlite3.Connection, workspace: str, version: str
) -> bool:
    """Delete a flag by version. Returns True if deleted."""
    cur = conn.execute(
        "DELETE FROM flags WHERE workspace = ? AND version = ?",
        (workspace, version),
    )
    conn.commit()
    return cur.rowcount > 0


def move_flag(
    conn: sqlite3.Connection,
    workspace: str,
    version: str,
    new_session_uid: int,
) -> bool:
    """Move a flag to a different session. Returns True if updated."""
    cur = conn.execute(
        "UPDATE flags SET session_uid = ?, is_orphaned = 0 WHERE workspace = ? AND version = ?",
        (new_session_uid, workspace, version),
    )
    conn.commit()
    return cur.rowcount > 0


def mark_orphaned_flags(
    conn: sqlite3.Connection, workspace: str, deleted_session_uids: list[int]
) -> None:
    """Mark flags as orphaned when their sessions have been trimmed.
    If keep_orphaned_record is false the caller should call delete_orphaned_flags instead."""
    if not deleted_session_uids:
        return
    placeholders = ",".join("?" * len(deleted_session_uids))
    conn.execute(
        f"UPDATE flags SET is_orphaned = 1 WHERE workspace = ? AND session_uid IN ({placeholders})",
        [workspace] + list(deleted_session_uids),
    )
    conn.commit()


def delete_orphaned_flags(
    conn: sqlite3.Connection, workspace: str, deleted_session_uids: list[int]
) -> None:
    """Delete flag records whose sessions were trimmed (when keep_orphaned_record=false)."""
    if not deleted_session_uids:
        return
    placeholders = ",".join("?" * len(deleted_session_uids))
    conn.execute(
        f"DELETE FROM flags WHERE workspace = ? AND session_uid IN ({placeholders})",
        [workspace] + list(deleted_session_uids),
    )
    conn.commit()


# --- Meta ---

def get_meta(conn: sqlite3.Connection, key: str) -> Optional[str]:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)", (key, value)
    )
    conn.commit()
