# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

SCHEMA_VERSION = 7

CREATE_FILE_REGISTRY = """
CREATE TABLE IF NOT EXISTS file_registry (
    uid         INTEGER PRIMARY KEY,
    file_id     TEXT    NOT NULL,
    workspace   TEXT    NOT NULL,
    folder_path TEXT    NOT NULL,
    filepath    TEXT    NOT NULL,
    filename    TEXT    NOT NULL,
    UNIQUE(workspace, folder_path, filepath),
    UNIQUE(workspace, file_id)
);

CREATE INDEX IF NOT EXISTS idx_registry_workspace ON file_registry(workspace, file_id);
"""

CREATE_FILE = """
CREATE TABLE IF NOT EXISTS file (
    uid               INTEGER PRIMARY KEY,
    file_registry_uid INTEGER NOT NULL REFERENCES file_registry(uid),
    file_version      INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT    NOT NULL,
    hash              TEXT    NOT NULL,
    status            TEXT    NOT NULL DEFAULT 'CHANGE',
    is_full           INTEGER NOT NULL DEFAULT 0,
    storage_path      TEXT    NOT NULL DEFAULT '',
    file_size         INTEGER NOT NULL DEFAULT 0,
    is_corrupted      INTEGER NOT NULL DEFAULT 0,
    is_compressed     INTEGER NOT NULL DEFAULT 0,
    note              TEXT    DEFAULT '',
    is_deleted        INTEGER NOT NULL DEFAULT 0,
    session_uid       INTEGER REFERENCES sessions(uid),
    promoted_by       TEXT    DEFAULT NULL,
    filepath          TEXT    DEFAULT NULL,
    symbols           TEXT    DEFAULT NULL,
    lines_added       INTEGER DEFAULT NULL,
    lines_removed     INTEGER DEFAULT NULL
);

CREATE INDEX IF NOT EXISTS idx_file_registry ON file(file_registry_uid, uid);
CREATE INDEX IF NOT EXISTS idx_file_session ON file(session_uid, uid);
"""

CREATE_SESSIONS = """
CREATE TABLE IF NOT EXISTS sessions (
    uid        INTEGER PRIMARY KEY,
    workspace  TEXT    NOT NULL,
    created_at TEXT    NOT NULL,
    updated_at TEXT    NOT NULL,
    note       TEXT    DEFAULT '',
    is_forced  INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_session_workspace ON sessions(workspace, uid);
"""


CREATE_META = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

CREATE_FLAGS = """
CREATE TABLE IF NOT EXISTS flags (
    uid                  INTEGER PRIMARY KEY AUTOINCREMENT,
    session_uid          INTEGER NOT NULL,
    workspace            TEXT    NOT NULL,
    version              TEXT    NOT NULL,
    title                TEXT    NOT NULL,
    description          TEXT,
    created_at           TEXT    NOT NULL,
    promoted_to_fullbase BOOLEAN NOT NULL DEFAULT 0,
    is_orphaned          BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY (session_uid) REFERENCES sessions(uid),
    UNIQUE(workspace, version)
);

CREATE INDEX IF NOT EXISTS idx_flags_workspace   ON flags(workspace);
CREATE INDEX IF NOT EXISTS idx_flags_session_uid ON flags(session_uid);
"""
