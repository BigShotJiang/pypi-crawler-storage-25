"""Perplexity AI adapter for PULSE Protocol.

Translates PULSE semantic messages to Perplexity Sonar API calls.
Returns answers with real-time web citations — unique capability
not available in standard LLM adapters.

Supported actions:
    ACT.SEARCH.WEB      — web search with cited answer (main use case)
    ACT.QUERY.DATA      — general question answering
    ACT.ANALYZE.PATTERN — deep research synthesis
    ACT.RESEARCH.TOPIC  — long-form research report (sonar-deep-research)

Available models:
    sonar               — fast, cost-effective search (default)
    sonar-pro           — deeper context, 2× more sources
    sonar-reasoning-pro — chain-of-thought reasoning
    sonar-deep-research — hundreds of sources, long-form synthesis

Credentials:
    Set PERPLEXITY_API_KEY environment variable.
    Get key at: https://www.perplexity.ai/settings/api

Example:
    >>> import os
    >>> from pulse_perplexity import PerplexityAdapter
    >>> from pulse.message import PulseMessage

    >>> adapter = PerplexityAdapter(api_key=os.environ["PERPLEXITY_API_KEY"])
    >>> adapter.connect()

    >>> msg = PulseMessage(
    ...     action="ACT.SEARCH.WEB",
    ...     parameters={"query": "Latest PULSE Protocol news 2026"},
    ... )
    >>> response = adapter.send(msg)
    >>> print(response.content["parameters"]["answer"])
    >>> print(response.content["parameters"]["citations"])
"""

import os
from typing import Any, Dict, List, Optional

import requests

from pulse.message import PulseMessage
from pulse.adapter import PulseAdapter, AdapterError, AdapterConnectionError


_API_BASE = "https://api.perplexity.ai"
_CHAT_ENDPOINT = "/chat/completions"

# Map PULSE actions to Sonar models and system prompts
_ACTION_CONFIG: Dict[str, Dict[str, str]] = {
    "ACT.SEARCH.WEB": {
        "model": "sonar",
        "system": (
            "You are a precise web search assistant. "
            "Answer concisely with key facts. Always cite your sources."
        ),
    },
    "ACT.QUERY.DATA": {
        "model": "sonar-pro",
        "system": (
            "You are an expert analyst. "
            "Provide a thorough, well-structured answer with citations."
        ),
    },
    "ACT.ANALYZE.PATTERN": {
        "model": "sonar-reasoning-pro",
        "system": (
            "You are a deep research analyst. Identify patterns, trends, and insights. "
            "Use chain-of-thought reasoning. Cite all sources."
        ),
    },
    "ACT.RESEARCH.TOPIC": {
        "model": "sonar-deep-research",
        "system": (
            "You are a comprehensive research assistant. "
            "Synthesize information from many sources into a detailed report."
        ),
    },
}


class PerplexityAdapter(PulseAdapter):
    """PULSE adapter for Perplexity AI Sonar API.

    Unique capability: every response includes real-time web citations.
    Agents in your system get not just answers but verifiable sources.

    Args:
        api_key: Perplexity API key. Prefer ``os.environ["PERPLEXITY_API_KEY"]``.
        model: Default Sonar model (overridable per message via ``parameters.model``).
        search_recency: Filter results by time — "day", "week", "month", "year".
        search_domain_filter: List of domains to restrict search to.
        config: Extra adapter config.

    Example:
        >>> adapter = PerplexityAdapter(api_key=os.environ["PERPLEXITY_API_KEY"])
        >>> adapter.connect()
        >>> msg = PulseMessage(
        ...     action="ACT.SEARCH.WEB",
        ...     parameters={"query": "What is PULSE Protocol?"},
        ... )
        >>> response = adapter.send(msg)
        >>> print(response.content["parameters"]["citations"])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "sonar",
        search_recency: Optional[str] = None,
        search_domain_filter: Optional[List[str]] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            name="perplexity",
            base_url=_API_BASE,
            config=config or {},
        )
        self._api_key = api_key or os.environ.get("PERPLEXITY_API_KEY", "")
        self._default_model = model
        self._search_recency = search_recency
        self._search_domain_filter = search_domain_filter or []
        self._session: Optional[requests.Session] = None

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def connect(self) -> None:
        """Initialize HTTP session with auth headers.

        Raises:
            AdapterConnectionError: If API key is missing.
        """
        if not self._api_key:
            raise AdapterConnectionError(
                "Perplexity API key required. "
                "Set PERPLEXITY_API_KEY env var or pass api_key=. "
                "Get key at https://www.perplexity.ai/settings/api"
            )
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        self.connected = True

    def disconnect(self) -> None:
        """Close HTTP session."""
        if self._session:
            self._session.close()
            self._session = None
        self.connected = False

    # ── PULSE Protocol Interface ───────────────────────────────────────────

    def to_native(self, message: PulseMessage) -> Dict[str, Any]:
        """Convert PULSE message to Perplexity API request.

        Args:
            message: PULSE message with action and parameters.

        Returns:
            Dict ready for Perplexity /chat/completions endpoint.

        Raises:
            AdapterError: If action unsupported or query missing.
        """
        action = message.content["action"]
        params = message.content.get("parameters", {})

        action_cfg = _ACTION_CONFIG.get(action)
        if not action_cfg:
            raise AdapterError(
                f"Unsupported action '{action}'. "
                f"Supported: {sorted(_ACTION_CONFIG.keys())}"
            )

        query = params.get("query") or params.get("text") or params.get("topic")
        if not query:
            raise AdapterError(
                f"Parameter 'query' is required for {action}"
            )

        model = params.get("model", action_cfg["model"])
        system_prompt = params.get("system_prompt", action_cfg["system"])

        body: Dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query},
            ],
            "stream": False,
        }

        # Optional search filters
        recency = params.get("search_recency", self._search_recency)
        if recency:
            body["search_recency_filter"] = recency

        domain_filter = params.get("search_domain_filter", self._search_domain_filter)
        if domain_filter:
            body["search_domain_filter"] = domain_filter

        if "max_tokens" in params:
            body["max_tokens"] = params["max_tokens"]

        if "temperature" in params:
            body["temperature"] = params["temperature"]

        return body

    def call_api(self, native_request: Dict[str, Any]) -> Dict[str, Any]:
        """Call Perplexity /chat/completions endpoint.

        Args:
            native_request: Request dict from to_native().

        Returns:
            Parsed response dict with answer, citations, usage.

        Raises:
            AdapterConnectionError: If Perplexity is unreachable.
            AdapterError: On API error.
        """
        if not self._session:
            self.connect()

        try:
            resp = self._session.post(
                f"{self.base_url}{_CHAT_ENDPOINT}",
                json=native_request,
                timeout=120,
            )
        except requests.ConnectionError as e:
            raise AdapterConnectionError(f"Cannot reach Perplexity API: {e}") from e
        except requests.Timeout as e:
            raise AdapterConnectionError("Perplexity API request timed out") from e

        if resp.status_code == 401:
            raise AdapterError("Invalid Perplexity API key. Check PERPLEXITY_API_KEY.")
        if resp.status_code == 429:
            raise AdapterError("Perplexity rate limit exceeded. Retry later.")
        if resp.status_code >= 400:
            raise AdapterError(
                f"Perplexity API error {resp.status_code}: {resp.text[:200]}"
            )

        data = resp.json()
        choice = data["choices"][0]

        return {
            "answer": choice["message"]["content"],
            "model": data.get("model", native_request["model"]),
            "citations": data.get("citations", []),
            "finish_reason": choice.get("finish_reason", "stop"),
            "usage": data.get("usage", {}),
        }

    def from_native(self, native_response: Dict[str, Any]) -> PulseMessage:
        """Wrap Perplexity response in a PULSE message.

        Args:
            native_response: Dict from call_api().

        Returns:
            PULSE response message with answer, citations, model, usage.
        """
        return PulseMessage(
            action="ACT.RESPOND",
            parameters={
                "status": "META.STATUS.SUCCESS",
                "answer": native_response["answer"],
                "citations": native_response["citations"],
                "model": native_response["model"],
                "finish_reason": native_response["finish_reason"],
                "usage": native_response["usage"],
            },
            validate=False,
        )

    @property
    def supported_actions(self) -> List[str]:
        """PULSE actions this adapter handles."""
        return sorted(_ACTION_CONFIG.keys())

    def __repr__(self) -> str:
        return (
            f"PerplexityAdapter(model='{self._default_model}', "
            f"connected={self.connected})"
        )
