"""
PULSE-Perplexity Adapter.

Web search with real-time citations via Perplexity Sonar API.

Setup:
    export PERPLEXITY_API_KEY="pplx-..."
    Get key at: https://www.perplexity.ai/settings/api

Example:
    >>> import os
    >>> from pulse_perplexity import PerplexityAdapter
    >>> from pulse.message import PulseMessage

    >>> adapter = PerplexityAdapter(api_key=os.environ["PERPLEXITY_API_KEY"])
    >>> adapter.connect()
    >>> response = adapter.send(PulseMessage(
    ...     action="ACT.SEARCH.WEB",
    ...     parameters={"query": "PULSE Protocol AI standard 2026"},
    ... ))
    >>> print(response.content["parameters"]["answer"])
    >>> print(response.content["parameters"]["citations"])
"""

from pulse_perplexity.adapter import PerplexityAdapter
from pulse_perplexity.version import __version__

__all__ = ["PerplexityAdapter", "__version__"]
