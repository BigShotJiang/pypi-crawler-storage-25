"""Tests for PerplexityAdapter — all HTTP calls mocked."""

import pytest
import responses as rsps_lib
from unittest.mock import MagicMock, patch

from pulse.message import PulseMessage
from pulse.adapter import AdapterError, AdapterConnectionError

from pulse_perplexity import PerplexityAdapter


API_URL = "https://api.perplexity.ai/chat/completions"


def make_api_response(answer="Paris", model="sonar", citations=None):
    return {
        "id": "req-123",
        "model": model,
        "choices": [{"message": {"role": "assistant", "content": answer}, "finish_reason": "stop"}],
        "citations": citations or ["https://example.com/1", "https://example.com/2"],
        "usage": {"input_tokens": 10, "output_tokens": 50, "total_tokens": 60},
    }


@pytest.fixture
def adapter():
    a = PerplexityAdapter(api_key="pplx-test-key")
    a.connect()
    return a


# ── connect() ─────────────────────────────────────────────────────────────

def test_connect_raises_without_api_key():
    a = PerplexityAdapter(api_key="")
    with pytest.raises(AdapterConnectionError, match="PERPLEXITY_API_KEY"):
        a.connect()


def test_connect_sets_auth_header(adapter):
    assert "Authorization" in adapter._session.headers
    assert adapter._session.headers["Authorization"] == "Bearer pplx-test-key"


def test_connect_sets_connected_flag(adapter):
    assert adapter.connected is True


def test_disconnect_clears_session(adapter):
    adapter.disconnect()
    assert adapter._session is None
    assert adapter.connected is False


# ── to_native() ───────────────────────────────────────────────────────────

def test_to_native_search_web(adapter):
    msg = PulseMessage(
        action="ACT.SEARCH.WEB",
        parameters={"query": "What is PULSE Protocol?"},
        validate=False,
    )
    native = adapter.to_native(msg)
    assert native["model"] == "sonar"
    assert native["messages"][-1]["content"] == "What is PULSE Protocol?"
    assert native["stream"] is False


def test_to_native_research_uses_deep_model(adapter):
    msg = PulseMessage(
        action="ACT.RESEARCH.TOPIC",
        parameters={"topic": "AI semantic protocols"},
        validate=False,
    )
    native = adapter.to_native(msg)
    assert native["model"] == "sonar-deep-research"


def test_to_native_model_override(adapter):
    msg = PulseMessage(
        action="ACT.SEARCH.WEB",
        parameters={"query": "test", "model": "sonar-pro"},
        validate=False,
    )
    native = adapter.to_native(msg)
    assert native["model"] == "sonar-pro"


def test_to_native_search_recency_filter(adapter):
    msg = PulseMessage(
        action="ACT.SEARCH.WEB",
        parameters={"query": "latest AI news", "search_recency": "day"},
        validate=False,
    )
    native = adapter.to_native(msg)
    assert native["search_recency_filter"] == "day"


def test_to_native_domain_filter(adapter):
    msg = PulseMessage(
        action="ACT.SEARCH.WEB",
        parameters={"query": "q", "search_domain_filter": ["arxiv.org"]},
        validate=False,
    )
    native = adapter.to_native(msg)
    assert native["search_domain_filter"] == ["arxiv.org"]


def test_to_native_raises_without_query(adapter):
    msg = PulseMessage(
        action="ACT.SEARCH.WEB", parameters={}, validate=False
    )
    with pytest.raises(AdapterError, match="'query'"):
        adapter.to_native(msg)


def test_to_native_raises_unsupported_action(adapter):
    msg = PulseMessage(
        action="ACT.STORE.SECRET", parameters={}, validate=False
    )
    with pytest.raises(AdapterError, match="Unsupported action"):
        adapter.to_native(msg)


def test_to_native_accepts_text_param(adapter):
    msg = PulseMessage(
        action="ACT.QUERY.DATA",
        parameters={"text": "Explain quantum computing"},
        validate=False,
    )
    native = adapter.to_native(msg)
    assert native["messages"][-1]["content"] == "Explain quantum computing"


# ── call_api() ────────────────────────────────────────────────────────────

@rsps_lib.activate
def test_call_api_success(adapter):
    rsps_lib.add(rsps_lib.POST, API_URL, json=make_api_response("Paris is the capital"), status=200)
    result = adapter.call_api({
        "model": "sonar",
        "messages": [{"role": "user", "content": "Capital of France?"}],
        "stream": False,
    })
    assert result["answer"] == "Paris is the capital"
    assert result["model"] == "sonar"
    assert len(result["citations"]) == 2


@rsps_lib.activate
def test_call_api_returns_citations(adapter):
    rsps_lib.add(rsps_lib.POST, API_URL, json=make_api_response(
        citations=["https://wiki.org/France", "https://britannica.com/paris"]
    ), status=200)
    result = adapter.call_api({"model": "sonar", "messages": [], "stream": False})
    assert "https://wiki.org/France" in result["citations"]


@rsps_lib.activate
def test_call_api_401_raises_auth_error(adapter):
    rsps_lib.add(rsps_lib.POST, API_URL, json={"error": "unauthorized"}, status=401)
    with pytest.raises(AdapterError, match="Invalid Perplexity API key"):
        adapter.call_api({"model": "sonar", "messages": [], "stream": False})


@rsps_lib.activate
def test_call_api_429_raises_rate_limit(adapter):
    rsps_lib.add(rsps_lib.POST, API_URL, json={"error": "rate limit"}, status=429)
    with pytest.raises(AdapterError, match="rate limit"):
        adapter.call_api({"model": "sonar", "messages": [], "stream": False})


@rsps_lib.activate
def test_call_api_500_raises_error(adapter):
    rsps_lib.add(rsps_lib.POST, API_URL, json={"error": "server error"}, status=500)
    with pytest.raises(AdapterError, match="500"):
        adapter.call_api({"model": "sonar", "messages": [], "stream": False})


def test_call_api_connection_error(adapter):
    with patch.object(adapter._session, "post", side_effect=Exception("connection refused")):
        with pytest.raises(Exception):
            adapter.call_api({"model": "sonar", "messages": [], "stream": False})


# ── from_native() ─────────────────────────────────────────────────────────

def test_from_native_wraps_in_pulse(adapter):
    response = adapter.from_native({
        "answer": "42",
        "model": "sonar",
        "citations": ["https://example.com"],
        "finish_reason": "stop",
        "usage": {"total_tokens": 60},
    })
    assert isinstance(response, PulseMessage)
    p = response.content["parameters"]
    assert p["answer"] == "42"
    assert p["citations"] == ["https://example.com"]
    assert p["status"] == "META.STATUS.SUCCESS"


# ── Full send() flow ──────────────────────────────────────────────────────

@rsps_lib.activate
def test_send_search_web(adapter):
    rsps_lib.add(rsps_lib.POST, API_URL, json=make_api_response(
        answer="PULSE Protocol is a semantic AI standard",
        citations=["https://pulse-protocol.netlify.app"]
    ), status=200)
    msg = PulseMessage(
        action="ACT.SEARCH.WEB",
        parameters={"query": "What is PULSE Protocol?"},
        validate=False,
    )
    response = adapter.send(msg)
    p = response.content["parameters"]
    assert "PULSE Protocol" in p["answer"]
    assert "https://pulse-protocol.netlify.app" in p["citations"]
    assert p["status"] == "META.STATUS.SUCCESS"


@rsps_lib.activate
def test_send_with_recency_filter(adapter):
    rsps_lib.add(rsps_lib.POST, API_URL, json=make_api_response(), status=200)
    msg = PulseMessage(
        action="ACT.SEARCH.WEB",
        parameters={"query": "AI news", "search_recency": "week"},
        validate=False,
    )
    adapter.send(msg)
    sent_body = rsps_lib.calls[0].request.body.decode()
    assert "search_recency_filter" in sent_body
    assert "week" in sent_body


# ── supported_actions & repr ──────────────────────────────────────────────

def test_supported_actions(adapter):
    actions = adapter.supported_actions
    assert "ACT.SEARCH.WEB" in actions
    assert "ACT.QUERY.DATA" in actions
    assert "ACT.ANALYZE.PATTERN" in actions
    assert "ACT.RESEARCH.TOPIC" in actions
    assert len(actions) == 4


def test_repr(adapter):
    r = repr(adapter)
    assert "PerplexityAdapter" in r
    assert "sonar" in r


# ── Global search_recency on adapter level ────────────────────────────────

@rsps_lib.activate
def test_adapter_level_recency_filter():
    a = PerplexityAdapter(api_key="pplx-test", search_recency="month")
    a.connect()
    rsps_lib.add(rsps_lib.POST, API_URL, json=make_api_response(), status=200)
    msg = PulseMessage(
        action="ACT.SEARCH.WEB",
        parameters={"query": "test"},
        validate=False,
    )
    a.send(msg)
    sent_body = rsps_lib.calls[0].request.body.decode()
    assert "month" in sent_body
