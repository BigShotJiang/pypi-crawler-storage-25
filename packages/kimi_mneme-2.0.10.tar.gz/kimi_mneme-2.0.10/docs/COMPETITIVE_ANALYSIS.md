# Сравнительный анализ: kimi-mneme vs claude-mem

> **Дата анализа**: 2026-05-04
> **claude-mem версия**: 12.6.0 (TypeScript/Bun)
> **kimi-mneme версия**: <!-- VERSION -->2.0.10<!-- /VERSION --> (Python)

---

## 1. Общая архитектура

| Аспект | claude-mem | kimi-mneme | Комментарий |
|--------|-----------|------------|-------------|
| **Язык** | TypeScript (ES2022 modules) | Python 3.10+ | Оба современные, но разные экосистемы |
| **Runtime** | Bun (primary) + Node.js fallback | CPython + uv | Bun быстрее для I/O, Python проще для ML-интеграций |
| **База данных** | SQLite (`bun:sqlite`) | SQLite (`sqlite3`) | Оба SQLite — хорошо для переносимости |
| **Миграции** | SQL-файлы (`schema.sql`) | Python-список (`MIGRATIONS[]`) | У claude-mem чище, у нас гибче (conditional) |
| **Веб-сервер** | Express.js (worker HTTP API) | FastAPI (async) | FastAPI современнее, Express проще |
| **UI** | React 19 (viewer) | Vanilla JS + CSS | React тяжелее, но компонентный. Vanilla — проще, меньше deps |
| **AI SDK** | `@anthropic-ai/claude-agent-sdk` | Собственный (Kimi API) | Оба используют нативный API своего IDE |

### Вывод по архитектуре
- **claude-mem** более "enterprise" — React UI, Bun, Express, сложная сборка
- **kimi-mneme** проще и легче — FastAPI, vanilla JS, меньше зависимостей
- Оба правильно выбрали SQLite для переносимости

---

## 2. Хранение и структура данных

### claude-mem
```typescript
// observations — основная таблица (структурированная)
interface Observation {
  type: string;           // decision, bugfix, feature, refactor, discovery, change
  title: string | null;
  subtitle: string | null;
  facts: string[];
  narrative: string | null;
  concepts: string[];
  files_read: string[];
  files_modified: string[];
  agent_type?: string;
  agent_id?: string;
  discovery_tokens?: number;
}
```

### kimi-mneme
```python
# structured_observations — основная таблица
# type: bugfix, feature, refactor, change, discovery, decision
# title, subtitle, facts (JSON), narrative, concepts (JSON)
# files_read (JSON), files_modified (JSON)
# content_hash, discovery_tokens, raw_observation_id, source, model
```

### Сравнение

| Фича | claude-mem | kimi-mneme | Кто лучше |
|------|-----------|------------|-----------|
| **Типы observation** | 6 типов | 6 типов | ➖ Параитет |
| **Deduplication** | SHA-256(content), `ON CONFLICT DO NOTHING` | SHA-256(session_id + title + narrative), soft dedup links | ✅ **kimi-mneme** — soft links сохраняют связи |
| **Raw observations** | Нет отдельной таблицы | Есть `observations` (legacy) + `structured_observations` | ✅ **kimi-mneme** — backward compatibility |
| **Session summaries** | `session_summaries` (title, request, investigated, learned, completed, next_steps) | `session_summaries` (аналогично) | ➖ Параитет |
| **Pending queue** | SQLite-based с claim/processed/failed | SQLite-based с claim/processed/failed | ➖ Параитет |
| **Checkpoints** | Нет явных | `session_checkpoints` (resume context) | ✅ **kimi-mneme** — checkpoints для compaction |
| **Patterns** | Нет явных | `patterns` (error/fix/decision cross-session) | ✅ **kimi-mneme** — pattern detection |
| **Wire events** | Нет | `wire_events`, `thinking`, `assistant_messages` | ✅ **kimi-mneme** — полная трассировка |
| **User prompts** | `user_prompts` | `user_prompts` | ➖ Параитет |
| **Compaction tracking** | Нет явного | `compaction_events` (tokens_before/after) | ✅ **kimi-mneme** — token economics |

---

## 3. Vector Search (семантический поиск)

### claude-mem
- **Primary**: ChromaDB через `chroma-mcp` (MCP stdio transport)
- **Sync**: `ChromaSync.ts` — watermark-based, batch processing
- **Search strategies**: ChromaSearchStrategy, SQLiteSearchStrategy, HybridSearchStrategy
- **SearchOrchestrator** — роутит запросы к нужной стратегии
- **Deduplication**: на уровне Chroma + UI

### kimi-mneme
- **Primary**: sqlite-vec (SQLite extension, pure C)
- **Fallback**: ChromaDB (disabled on Windows ≥1.0)
- **Sync**: `vec_sync_state` watermark table
- **Field-level embeddings**: title, narrative, каждый fact отдельно
- **Project partitioning**: через `partition_key`

### Сравнение

| Аспект | claude-mem | kimi-mneme | Кто лучше |
|--------|-----------|------------|-----------|
| **Vector DB** | ChromaDB (external process) | sqlite-vec (in-process) | ✅ **kimi-mneme** — нет segfault, нет отдельного процесса |
| **Cross-platform** | Chroma может segfault на Windows | sqlite-vec работает везде | ✅ **kimi-mneme** |
| **Search strategies** | 3 стратегии + orchestrator | 1 подход (sqlite-vec) | ✅ **claude-mem** — гибче |
| **Field-level search** | Нет явного | title/narrative/facts отдельно | ✅ **kimi-mneme** |
| **Hybrid search** | Да (metadata filter + Chroma ranking) | Нет (только semantic или FTS) | ✅ **claude-mem** |
| **Smart file search** | tree-sitter AST parsing (smart_search, smart_unfold, smart_outline) | Нет | ✅ **claude-mem** — мощная фича |

### Ключевой инсайт
claude-mem использует **tree-sitter** для AST-парсинга кода — это даёт `smart_search`, `smart_unfold`, `smart_outline`. Это серьёзное преимущество для codebase navigation. У нас этого нет.

---

## 4. Context Injection (инжекция контекста)

### claude-mem
**ContextBuilder.ts** → `generateContext()`
1. `ContextConfigLoader` — загружает настройки
2. `ObservationCompiler` — запрашивает observations + summaries
3. `TokenCalculator` — считает token economics
4. **Renderers**: HeaderRenderer, TimelineRenderer, SummaryRenderer, FooterRenderer
5. Инжекция через `<claude-mem-context>` tags

**Точки инжекции**:
- Claude Code: `additionalContext` в hook output
- Cursor: `.cursor/rules/claude-mem-context.mdc`
- Windsurf: `.windsurf/rules/claude-mem-context.md`
- Другие IDE: через MCP + context file writes

### kimi-mneme
**Injector.get_context()**
1. Patterns (cross-session error/fix/decision)
2. Recent sessions (ranked by relevance score)
3. Structured observations (compact format)
4. Semantic search (sqlite-vec, optional)
5. Resume context (checkpoints)

**Точки инжекции**:
- SessionStart hook → JSON `hookSpecificOutput.context`

### Сравнение

| Аспект | claude-mem | kimi-mneme | Кто лучше |
|--------|-----------|------------|-----------|
| **Формат инжекции** | Markdown с `<claude-mem-context>` tags | Markdown + JSON | ➖ Разные подходы |
| **IDE coverage** | Claude, Cursor, Windsurf, OpenCode, Gemini, Copilot, Goose, Roo, Warp | Kimi CLI only | ✅ **claude-mem** — гораздо шире |
| **Token economics** | Per-observation (discovery_tokens) | Per-compaction (tokens_before/after) | ✅ **claude-mem** — детальнее |
| **Timeline в контексте** | Да (buildTimeline) | Нет | ✅ **claude-mem** |
| **Summary fields** | Да (request, investigated, learned, completed, next_steps) | Да | ➖ Параитет |
| **Previously section** | Да (getPriorSessionMessages) | Нет | ✅ **claude-mem** |
| **Config-driven** | Да (`settings.json`) | Да (`config.json`) | ➖ Параитет |
| **Semantic injection** | Через Chroma | Через sqlite-vec | ✅ **kimi-mneme** — надёжнее на Windows |

---

## 5. MCP Server

### claude-mem
**12 tools** в `mcp-server.ts`:
1. `__IMPORTANT` — workflow documentation (3-layer pattern)
2. `search` — FTS/Chroma search
3. `timeline` — chronological context
4. `get_observations` — batch fetch by IDs
5. `smart_search` — tree-sitter AST search
6. `smart_unfold` — expand symbol
7. `smart_outline` — file outline
8. `build_corpus` — knowledge corpus
9. `list_corpora` — list corpora
10. `prime_corpus` — prime corpus for Q&A
11. `query_corpus` — ask corpus
12. `rebuild_corpus`, `reprime_corpus`

**Особенности**:
- Auto-start worker через HTTP API
- Parent heartbeat (orphan prevention)
- Console output interception (MCP protocol protection)
- Marketplace marker check

### kimi-mneme
**7 tools** в `mcp_server.py`:
1. `memory_search` — FTS5 search
2. `memory_recall` — get by ID
3. `memory_timeline` — chronological context
4. `memory_stats` — statistics
5. `memory_by_concept` — search by concept
6. `memory_by_file` — search by file
7. `memory_semantic_search` — sqlite-vec semantic search

**Особенности**:
- FastMCP 3.2.4 (современный)
- Auto-start в FastAPI lifespan (B.7)

### Сравнение

| Аспект | claude-mem | kimi-mneme | Кто лучше |
|--------|-----------|------------|-----------|
| **Количество tools** | 12 | 7 | ✅ **claude-mem** — больше возможностей |
| **Knowledge corpora** | Да (build/prime/query/rebuild) | Нет | ✅ **claude-mem** — мощная фича |
| **Smart code search** | Да (tree-sitter) | Нет | ✅ **claude-mem** |
| **3-layer workflow** | Да (`__IMPORTANT` tool) | Нет | ✅ **claude-mem** — UX |
| **Auto-start** | Да (worker HTTP API) | Да (FastAPI lifespan) | ➖ Параитет |
| **Protocol protection** | Console interception | Нет | ✅ **claude-mem** |
| **Framework** | `@modelcontextprotocol/sdk` | FastMCP 3.2.4 | ➖ Оба стандартные |

---

## 6. Privacy & Sanitization

### claude-mem
```typescript
// tag-stripping.ts
const TAG_NAMES = [
  'private',
  'claude-mem-context',
  'system_instruction',
  'system-instruction',
  'persisted-output',
  'system-reminder',
];

// stripTags() — regex-based, max 100 tags
// PrivacyCheckValidator — skip если prompt entirely <private>
// isInternalProtocolPayload — reject task-notification
```

### kimi-mneme
```python
# sanitize.py
DEFAULT_SYSTEM_TAGS = [
    "system_instruction", "system-reminder", 
    "system", "system_instruction_full"
]

SENSITIVE_PATTERNS = [
    # API keys, AWS keys, bearer tokens, 
    # private keys, URL passwords, GitHub tokens
]

# 3 уровня:
# 1. strip_system_content() — полное удаление
# 2. redact_sensitive_patterns() — замена на [PRIVATE]
# 3. sanitize_content() — <private>, <secret> → [PRIVATE]
```

### Сравнение

| Аспект | claude-mem | kimi-mneme | Кто лучше |
|--------|-----------|------------|-----------|
| **System tags** | 6 tag names | 4 tag names + patterns | ✅ **kimi-mneme** — больше покрытие |
| **Sensitive patterns** | Нет (только tags) | API keys, AWS, bearer, private keys, URLs, GitHub tokens | ✅ **kimi-mneme** — гораздо глубже |
| **Max tag limit** | 100 (warn) | Нет limit | ✅ **claude-mem** — защита от abuse |
| **Protocol filtering** | task-notification rejection | Нет | ✅ **claude-mem** |
| **Privacy validator** | Skip entirely-private prompts | Нет | ✅ **claude-mem** |
| **Per-project exclusion** | `CLAUDE_MEM_EXCLUDED_PROJECTS` | Нет | ✅ **claude-mem** |

---

## 7. UI / Web Interface

### claude-mem (React 19)
- Components: Header, Feed, ObservationCard, SummaryCard, PromptCard
- Modals: ContextSettingsModal, LogsModal, WelcomeCard
- Hooks: useSSE, useSettings, useStats, usePagination, useTheme, useGitHubStars
- Theme: dark/light toggle
- Real-time: SSE streaming
- Context preview modal

### kimi-mneme (Vanilla JS)
- Glassmorphism design (ocean-deep theme)
- Components: session cards, observation cards, structured cards
- Sidebar: stats orbs, heatmap, token economics
- Rightbar: system log, economics panel
- Real-time: SSE + WebSocket
- Settings modal (B.3) — toggle фич
- Timeline view

### Сравнение

| Аспект | claude-mem | kimi-mneme | Кто лучше |
|--------|-----------|------------|-----------|
| **Framework** | React 19 | Vanilla JS | ✅ **kimi-mneme** — меньше deps, проще |
| **Design** | Стандартный | Glassmorphism (уникальный) | ✅ **kimi-mneme** — оригинальный дизайн |
| **Theme toggle** | Dark/light | Нет (только dark) | ✅ **claude-mem** |
| **Context preview** | Да (modal) | Нет | ✅ **claude-mem** |
| **Logs drawer** | Да | Да (rightbar) | ➖ Параитет |
| **Heatmap** | Нет | Да (activity grid) | ✅ **kimi-mneme** |
| **Token economics** | В контексте | В sidebar + rightbar | ✅ **kimi-mneme** — виднее |
| **GitHub stars** | Да (useGitHubStars) | Нет | ✅ **claude-mem** — маркетинг |
| **Settings** | Context settings | Feature toggles + privacy | ✅ **kimi-mneme** — больше контроля |

---

## 8. Plugin / Hook System

### claude-mem
**5 hooks**:
1. `session-init` (SessionStart)
2. `beforeSubmitPrompt` (UserPromptSubmit)
3. `afterMCPExecution` (PostToolUse)
4. `afterFileEdit` (PostToolUse)
5. `stop` (SessionEnd)

**IDE coverage**:
- Claude Code (`.claude-plugin/`)
- Codex (`.codex-plugin/`)
- Cursor (`cursor-hooks/`)
- Windsurf (`.windsurf/`)
- OpenCode, Gemini CLI, Copilot CLI, Goose, Roo Code, Warp, Antigravity

### kimi-mneme
**6 hooks**:
1. `session_start.py` (SessionStart)
2. `session_end.py` (SessionEnd)
3. `post_tool_use.py` (PostToolUse)
4. `post_tool_use_failure.py` (PostToolUseFailure)
5. `pre_compact.py` (PreCompact)
6. `post_compact.py` (PostCompact)
7. `user_prompt_submit.py` (UserPromptSubmit)

**IDE coverage**:
- Kimi CLI only

### Сравнение

| Аспект | claude-mem | kimi-mneme | Кто лучше |
|--------|-----------|------------|-----------|
| **Hook count** | 5 | 7 | ✅ **kimi-mneme** — больше точек |
| **Pre/Post compact** | Нет | Да | ✅ **kimi-mneme** — compaction tracking |
| **IDE coverage** | 10+ IDE | 1 IDE | ✅ **claude-mem** — гораздо шире |
| **Plugin format** | Rich (marketplace, skills) | Simple (JSON + scripts) | ✅ **claude-mem** — экосистема |
| **Auto-install** | Smart install scripts | Basic install.py | ✅ **claude-mem** |

---

## 9. Что у claude-mem лучше (нам стоит позаимствовать)

### 9.1 Tree-sitter интеграция ⭐ ВАЖНО
```
smart_search — AST-based codebase search
smart_unfold — expand specific symbol
smart_outline — structural file outline
```
**Почему важно**: Это даёт реальную ценность для разработчиков — поиск по структуре кода, а не просто тексту. У нас нет ничего подобного.

### 9.2 Knowledge Corpora ⭐ ВАЖНО
```
build_corpus → prime_corpus → query_corpus → rebuild_corpus
```
**Почему важно**: Позволяет создавать тематические knowledge bases из observations и задавать им вопросы. Это "long-term memory" на steroids.

### 9.3 Multi-IDE поддержка
Поддержка Cursor, Windsurf, VS Code, Vim и т.д. через разные hook форматы.

### 9.4 3-Layer MCP Workflow
`__IMPORTANT` tool учит LLM экономить токены: search → timeline → get_observations.

### 9.5 Context Preview Modal
В UI можно посмотреть, что именно будет инжектировано в контекст.

### 9.6 Parent Heartbeat + Orphan Prevention
MCP server следит за parent process и самоуничтожается если parent умер.

### 9.7 Per-project Privacy Settings
`CLAUDE_MEM_EXCLUDED_PROJECTS` — исключение проектов из памяти.

---

## 10. Что у kimi-mneme лучше (наши сильные стороны)

### 10.1 sqlite-vec вместо Chroma ⭐ ВАЖНО
- Нет segfault на Windows
- Нет отдельного процесса
- Pure SQLite extension
- Field-level embeddings

### 10.2 Privacy v2 — Deep Sanitization ⭐ ВАЖНО
- 3 уровня фильтрации
- Redaction API keys, tokens, private keys, URL passwords
- System content strip
- У claude-mem только tag stripping

### 10.3 Soft Dedup Links (B.2)
При совпадении hash создаётся link, а не silent drop. Сохраняет связи между raw observations.

### 10.4 Checkpoints + Resume Context
`session_checkpoints` с key_decisions, open_tasks, token_count. Позволяет восстанавливать сессию после compaction.

### 10.5 Pattern Detection
Cross-session pattern detection (error/fix/decision/architecture) с occurrence counting.

### 10.6 Wire Event Tracing
Полная трассировка Kimi CLI через wire.jsonl: wire_events, thinking, assistant_messages, session_stats, session_todos.

### 10.7 Compaction Tracking
`compaction_events` с tokens_before/after. Реальная статистика сжатия.

### 10.8 AGENTS.md Generation
Генерация kimi-cli native формата (B.8). claude-mem генерирует только PROJECT.md.

### 10.9 Settings Modal в UI
Интерактивное управление фичами: toggle structuring, injection, vector, privacy filters.

### 10.10 Простота и лёгкость
- Меньше зависимостей (нет React, Express, Bun)
- Проще установка (pip/uv)
- Меньше точек отказа

---

## 11. Рекомендации: что внедрить из claude-mem

### Приоритет: High (недели)
1. **Tree-sitter интеграция** — `smart_search`, `smart_outline` для codebase navigation
2. **Knowledge Corpora** — build/prime/query для тематических knowledge bases
3. **3-Layer MCP Workflow** — `__IMPORTANT` tool для экономии токенов

### Приоритет: Medium (месяцы)
4. **Context Preview Modal** — показывать что будет инжектировано
5. **Per-project exclusion** — исключать проекты из памяти
6. **Theme toggle** — dark/light в UI
7. **Parent heartbeat** — orphan prevention для MCP

### Приоритет: Low (по желанию)
8. **Multi-IDE hooks** — Cursor, Windsurf support
9. **React UI** (если нужно масштабирование)
10. **GitHub stars badge** — маркетинг

---

## 12. Итоговая таблица

| Категория | Победитель | Разрыв |
|-----------|-----------|--------|
| Архитектура | ➖ | Разные подходы, оба валидны |
| Хранение данных | ✅ kimi-mneme | Checkpoints, patterns, wire tracing |
| Vector search | ✅ kimi-mneme | sqlite-vec > Chroma (стабильность) |
| Search гибкость | ✅ claude-mem | Hybrid + tree-sitter |
| Context injection | ✅ claude-mem | Multi-IDE, timeline, previously |
| MCP tools | ✅ claude-mem | 12 vs 7, corpora, smart search |
| Privacy | ✅ kimi-mneme | Deep sanitization > tag stripping |
| UI дизайн | ✅ kimi-mneme | Уникальный glassmorphism |
| UI функционал | ✅ claude-mem | Context preview, theme toggle |
| Plugin coverage | ✅ claude-mem | 10+ IDE vs 1 |
| Простота | ✅ kimi-mneme | Меньше deps, проще код |
| **Всего** | **6-5** | **kimi-mneme** |

### Заключение
- **claude-mem** — более зрелый продукт с широкой IDE-экосистемой, knowledge corpora, tree-sitter интеграцией
- **kimi-mneme** — более надёжный фундамент (sqlite-vec, deep privacy, checkpoints, wire tracing), проще в поддержке
- **Главное отставание**: tree-sitter, knowledge corpora, multi-IDE support
- **Главное преимущество**: стабильность (sqlite-vec), privacy (deep sanitization), полнота трассировки (wire events)
