"""Data models for the Biotailor SDK, mirroring backend types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union

# ---------------------------------------------------------------------------
# Job Status
# ---------------------------------------------------------------------------

class JobStatus(str, Enum):
    BUILDING = "BUILDING"
    UPLOADING = "UPLOADING"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    FAILED = "FAILED"
    SUCCEEDED = "SUCCEEDED"
    CANCELLED = "CANCELLED"

    @classmethod
    def terminal_statuses(cls) -> set[JobStatus]:
        return {cls.SUCCEEDED, cls.FAILED, cls.CANCELLED}


# ---------------------------------------------------------------------------
# Tool Config models
# ---------------------------------------------------------------------------

@dataclass
class Option:
    display_name: str
    value: Union[str, int, bool]
    description: Optional[str] = None


@dataclass
class Validation:
    required: Optional[bool] = None
    maximum: Optional[float] = None
    minimum: Optional[float] = None
    options: Optional[List[Option]] = None
    accepted_input_types: Optional[List[str]] = None
    accepted_compression_method: Optional[List[str]] = None


@dataclass
class ToolParameter:
    id: str
    display_name: str
    type: str  # 'string' | 'number' | 'boolean' | 'file' | 'string[]' | 'number[]'
    description: Optional[str] = None
    default_value: Optional[Any] = None
    is_pair_end_only: Optional[bool] = None
    is_single_end_only: Optional[bool] = None
    validation: Optional[Validation] = None
    alias: Optional[List[str]] = None


@dataclass
class Output:
    id: str
    display_name: str
    description: Optional[str] = None
    is_pair_end_only: Optional[bool] = None
    is_single_end_only: Optional[bool] = None
    file_type: Optional[str] = None
    file_name: Optional[str] = None
    compression_method: Optional[str] = None
    alias: Optional[List[str]] = None


@dataclass
class DefaultHardware:
    cpu: int
    ram_in_gb: int


@dataclass
class ToolConfig:
    toolid: str
    display_name: str
    category: str
    has_sepe: bool
    default_hardware: DefaultHardware
    parameters: List[ToolParameter] = field(default_factory=list)
    outputs: List[Output] = field(default_factory=list)
    description: Optional[str] = None

    def tool_guide(self) -> str:
        """Return a human-readable help text describing this tool and its parameters.

        Includes tool info, parameter listing with types/defaults/validation,
        outputs, and a sample Pipeline code snippet.
        """
        lines: List[str] = []
        sep = "=" * 64

        # ── Header ───────────────────────────────────────────────────
        lines.append(sep)
        lines.append(f"  {self.display_name}  (toolid: {self.toolid})")
        lines.append(sep)
        if self.description:
            lines.append("")
            lines.append(self.description)
        lines.append("")
        lines.append(f"  Category:         {self.category}")
        lines.append(f"  Paired-end mode:  {'supported' if self.has_sepe else 'not supported'}")
        hw = self.default_hardware
        lines.append(f"  Default hardware: {hw.cpu} CPUs, {hw.ram_in_gb} GB RAM")

        # ── Parameters ───────────────────────────────────────────────
        lines.append("")
        lines.append("-" * 64)
        lines.append("  PARAMETERS")
        lines.append("-" * 64)

        if not self.parameters:
            lines.append("  (none)")
        else:
            for p in self.parameters:
                lines.append("")
                mode_tag = ""
                if p.is_pair_end_only:
                    mode_tag = "  [paired-end only]"
                elif p.is_single_end_only:
                    mode_tag = "  [single-end only]"

                aliases = ""
                if p.alias:
                    aliases = f"  (alias: {', '.join(p.alias)})"

                lines.append(f"  {p.id}  —  {p.display_name}{mode_tag}{aliases}")
                lines.append(f"    Type: {p.type}")
                if p.description:
                    lines.append(f"    {p.description}")
                if p.default_value is not None:
                    lines.append(f"    Default: {p.default_value}")

                if p.validation:
                    v = p.validation
                    if v.required:
                        lines.append("    Required: yes")
                    if v.minimum is not None:
                        lines.append(f"    Min: {v.minimum}")
                    if v.maximum is not None:
                        lines.append(f"    Max: {v.maximum}")
                    if v.accepted_input_types:
                        lines.append(f"    Accepted types: {', '.join(v.accepted_input_types)}")
                    if v.accepted_compression_method:
                        lines.append(
                            f"    Accepted compression: "
                            f"{', '.join(v.accepted_compression_method)}"
                        )
                    if v.options:
                        lines.append("    Options:")
                        for o in v.options:
                            desc = f" — {o.description}" if o.description else ""
                            lines.append(f"      • {o.value!r} ({o.display_name}){desc}")

        # ── Outputs ──────────────────────────────────────────────────
        lines.append("")
        lines.append("-" * 64)
        lines.append("  OUTPUTS")
        lines.append("-" * 64)

        if not self.outputs:
            lines.append("  (none)")
        else:
            for o in self.outputs:
                mode_tag = ""
                if o.is_pair_end_only:
                    mode_tag = "  [paired-end only]"
                elif o.is_single_end_only:
                    mode_tag = "  [single-end only]"
                desc = f" — {o.description}" if o.description else ""
                fname = f"  (file: {o.file_name})" if o.file_name else ""
                lines.append(f"  {o.id}: {o.display_name}{mode_tag}{desc}{fname}")

        # ── Sample code ──────────────────────────────────────────────
        lines.append("")
        lines.append("-" * 64)
        lines.append("  SAMPLE CODE")
        lines.append("-" * 64)
        lines.append("")
        lines.append(self._build_sample_snippet())

        lines.append(sep)
        return "\n".join(lines)

    def _build_sample_snippet(self) -> str:
        """Generate a sample Pipeline code snippet for this tool."""
        use_pair_end = self.has_sepe
        var_name = self.toolid.replace("-", "_")

        # Separate params into file inputs and value params.
        # Skip single-end-only params when pair-end mode is used.
        file_params: List[ToolParameter] = []
        value_params: List[ToolParameter] = []
        for p in self.parameters:
            if use_pair_end and p.is_single_end_only:
                continue
            if not use_pair_end and p.is_pair_end_only:
                continue
            if p.type == "file":
                file_params.append(p)
            else:
                value_params.append(p)

        # Build file variable declarations
        snippet_lines: List[str] = []
        file_var_map: Dict[str, str] = {}
        for i, fp in enumerate(file_params, 1):
            safe_id = fp.id.lstrip("-").replace("-", "_").upper()
            var = f"INPUT_{safe_id}" if len(file_params) > 1 else "INPUT_FILE"
            file_var_map[fp.id] = var
            ext = "fastq"
            if fp.validation and fp.validation.accepted_input_types:
                ext = fp.validation.accepted_input_types[0]
            snippet_lines.append(f'{var} = "path/to/input.{ext}"')

        snippet_lines.append("")
        snippet_lines.append("pipeline = (")
        snippet_lines.append(
            f'    Pipeline(name="sdk-{self.toolid}-example", tool={var_name})'
        )

        if use_pair_end:
            snippet_lines.append("    .set_pair_end(True)")

        # File inputs
        for fp in file_params:
            snippet_lines.append(f'    .set_input("{fp.id}", {file_var_map[fp.id]})')

        # Value params
        for p in value_params:
            sample_val = self._sample_value(p)
            snippet_lines.append(f'    .set_param("{p.id}", {sample_val})')

        snippet_lines.append(")")
        return "\n".join(snippet_lines)

    @staticmethod
    def _sample_value(param: ToolParameter) -> str:
        """Return a representative sample value as a Python literal string."""
        # If options exist, pick the default or the first option
        if param.validation and param.validation.options:
            if param.default_value is not None:
                for o in param.validation.options:
                    if o.value == param.default_value:
                        return repr(param.default_value)
            return repr(param.validation.options[0].value)

        if param.type == "boolean":
            val = param.default_value if param.default_value is not None else False
            return repr(bool(val))

        if param.type in ("number", "number[]"):
            if param.default_value is not None:
                return repr(param.default_value)
            if param.validation:
                if param.validation.minimum is not None:
                    return repr(int(param.validation.minimum))
                if param.validation.maximum is not None:
                    return repr(int(param.validation.maximum))
            return "1"

        if param.type in ("string", "string[]"):
            if param.default_value is not None:
                return repr(param.default_value)
            return repr("")

        # Fallback
        if param.default_value is not None:
            return repr(param.default_value)
        return repr("")


# ---------------------------------------------------------------------------
# Job model
# ---------------------------------------------------------------------------

@dataclass
class Job:
    jobid: str
    job_name: str
    job_status: JobStatus
    userid: Optional[str] = None
    orgid: Optional[str] = None
    start_timestamp: Optional[int] = None
    end_timestamp: Optional[int] = None
    workflow: Optional[Dict[str, Any]] = None
    raw: Optional[Dict[str, Any]] = None  # full API response


# ---------------------------------------------------------------------------
# Dataset model
# ---------------------------------------------------------------------------

@dataclass
class Dataset:
    dataset_id: str
    display_name: Optional[str] = None
    description: Optional[str] = None
    dataset_type: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Workflow JSON types (used internally by Pipeline builder)
# ---------------------------------------------------------------------------

@dataclass
class Hardware:
    cpu: int
    ramInGB: int  # noqa: N815  — matches backend JSON key
    vmType: Optional[str] = None  # noqa: N815
    moreThan30GBStorage: Optional[bool] = True  # noqa: N815


@dataclass
class WorkflowOutput:
    outputId: str  # noqa: N815


@dataclass
class WorkflowInputFile:
    fileName: str  # noqa: N815
    fileSizeInByte: int  # noqa: N815


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def _parse_option(data: dict) -> Option:
    return Option(
        display_name=data.get("displayName", ""),
        value=data.get("value", ""),
        description=data.get("description"),
    )


def _parse_validation(data: Optional[dict]) -> Optional[Validation]:
    if data is None:
        return None
    return Validation(
        required=data.get("required"),
        maximum=data.get("maximum"),
        minimum=data.get("minimum"),
        options=[_parse_option(o) for o in data["options"]] if data.get("options") else None,
        accepted_input_types=data.get("acceptedInputTypes"),
        accepted_compression_method=data.get("acceptedCompressionMethod"),
    )


def _parse_tool_parameter(data: dict) -> ToolParameter:
    return ToolParameter(
        id=data["id"],
        display_name=data.get("displayName", ""),
        type=data.get("type", "string"),
        description=data.get("description"),
        default_value=data.get("defaultValue"),
        is_pair_end_only=data.get("isPairEndOnly"),
        is_single_end_only=data.get("isSingleEndOnly"),
        validation=_parse_validation(data.get("validation")),
        alias=data.get("alias"),
    )


def _parse_output(data: dict) -> Output:
    return Output(
        id=data["id"],
        display_name=data.get("displayName", ""),
        description=data.get("description"),
        is_pair_end_only=data.get("isPairEndOnly"),
        is_single_end_only=data.get("isSingleEndOnly"),
        file_type=data.get("fileType"),
        file_name=data.get("fileName"),
        compression_method=data.get("compressionMethod"),
        alias=data.get("alias"),
    )


def parse_tool_config(data: dict) -> ToolConfig:
    hw = data.get("defaultHardware", {})
    return ToolConfig(
        toolid=data["toolid"],
        display_name=data.get("displayName", ""),
        category=data.get("category", ""),
        has_sepe=data.get("hasSEPE", False),
        default_hardware=DefaultHardware(cpu=hw.get("cpu", 2), ram_in_gb=hw.get("ramInGB", 4)),
        parameters=[_parse_tool_parameter(p) for p in data.get("parameters", [])],
        outputs=[_parse_output(o) for o in data.get("outputs", [])],
        description=data.get("description"),
    )


def parse_job(data: dict) -> Job:
    status_str = data.get("jobStatus", data.get("job_status", "BUILDING"))
    try:
        status = JobStatus(status_str)
    except ValueError:
        status = JobStatus.BUILDING
    return Job(
        jobid=data.get("jobid", ""),
        job_name=data.get("jobName", data.get("job_name", "")),
        job_status=status,
        userid=data.get("userid"),
        orgid=data.get("orgid"),
        start_timestamp=data.get("startTimestamp"),
        end_timestamp=data.get("endTimestamp"),
        workflow=data.get("workflow"),
        raw=data,
    )


def parse_dataset(data: dict) -> Dataset:
    return Dataset(
        dataset_id=data.get("datasetid", data.get("datasetId", "")),
        display_name=data.get("displayName"),
        description=data.get("description"),
        dataset_type=data.get("datasetType"),
        raw=data,
    )
