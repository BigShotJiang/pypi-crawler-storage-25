"""File upload logic for S3 presigned URLs."""

from __future__ import annotations

import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

import requests
from tqdm.auto import tqdm

from biotailor.exceptions import BiotailorUploadError

logger = logging.getLogger(__name__)

_MAX_RETRIES = 3
_RETRY_DELAYS = [1, 2, 4]  # seconds


def upload_files(
    upload_urls: List[Dict[str, Any]],
    upload_headers: Dict[str, str],
    file_map: Dict[str, str],
    show_progress: bool = True,
    max_workers: int = 5,
) -> List[Dict[str, Any]]:
    """Upload files to S3 using presigned URLs returned by the run endpoint.

    Args:
        upload_urls: List of upload URL descriptors from the API.
        upload_headers: Headers to include on every upload PUT (e.g. x-amz-tagging).
        file_map: Mapping of fileName -> local file path.
        show_progress: Whether to show tqdm progress.
        max_workers: Max concurrent upload threads.

    Returns:
        List of multipart completion dicts (for confirm-uploaded), empty if all single.
    """
    multipart_results: List[Dict[str, Any]] = []
    futures = {}

    # Count total upload parts (single = 1, multipart = number of part URLs)
    total_parts = 0
    for url_info in upload_urls:
        upload_type = url_info.get("type", "single")
        if upload_type == "single":
            total_parts += 1
        else:
            total_parts += len(url_info.get("urls", []))

    pbar = None
    if show_progress and total_parts > 0:
        pbar = tqdm(total=total_parts, unit="part", desc="Uploading")

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        for url_info in upload_urls:
            file_id = url_info["id"]
            local_path = file_map.get(file_id)
            if local_path is None:
                raise BiotailorUploadError(f"No local file mapped for upload id '{file_id}'")

            upload_type = url_info.get("type", "single")

            if upload_type == "single":
                fut = executor.submit(
                    _upload_single,
                    url=url_info["url"],
                    file_path=local_path,
                    headers=upload_headers,
                    show_progress=show_progress,
                    pbar=pbar,
                )
                futures[fut] = ("single", file_id)
            else:
                fut = executor.submit(
                    _upload_multipart,
                    url_info=url_info,
                    file_path=local_path,
                    headers={},
                    show_progress=show_progress,
                    pbar=pbar,
                )
                futures[fut] = ("multipart", file_id)

        for fut in as_completed(futures):
            kind, file_id = futures[fut]
            result = fut.result()  # raises on failure
            if kind == "multipart" and result is not None:
                multipart_results.append(result)

    if pbar is not None:
        pbar.close()

    return multipart_results


def _upload_single(
    url: str,
    file_path: str,
    headers: Dict[str, str],
    show_progress: bool = True,
    pbar: Any = None,
) -> None:
    """Upload a file in a single PUT request."""
    with open(file_path, "rb") as f:
        data = f.read()

    _put_with_retry(url, data=data, headers=headers, desc=file_path, show_progress=show_progress)
    if pbar is not None:
        pbar.update(1)


def _upload_multipart(
    url_info: Dict[str, Any],
    file_path: str,
    headers: Dict[str, str],
    show_progress: bool = True,
    pbar: Any = None,
) -> Optional[Dict[str, Any]]:
    """Upload a file in multiple parts, collecting ETags for completion.

    Returns:
        Dict with ``id`` and ``parts`` for the confirm-uploaded body.
    """
    chunk_size: int = url_info["chunkSizeInByte"]
    parts_urls: List[Dict[str, Any]] = url_info["urls"]
    file_id: str = url_info["id"]

    parts: List[Dict[str, Any]] = []

    with open(file_path, "rb") as f:
        for part_info in parts_urls:
            chunk = f.read(chunk_size)
            if not chunk:
                break

            etag = _put_with_retry(
                url=part_info["url"],
                data=chunk,
                headers=headers,
                desc=f"{file_path} part {part_info['partNumber']}",
                show_progress=show_progress,
                return_etag=True,
            )
            parts.append({"PartNumber": part_info["partNumber"], "ETag": etag})
            if pbar is not None:
                pbar.update(1)

    return {"id": file_id, "parts": parts}


class _ProgressReader:
    """File-like wrapper that reports bytes read to a tqdm progress bar."""

    def __init__(self, data: bytes, pbar: Any) -> None:
        self._data = data
        self._pbar = pbar
        self._offset = 0

    def read(self, size: int = -1) -> bytes:
        if size == -1:
            chunk = self._data[self._offset:]
            self._offset = len(self._data)
        else:
            chunk = self._data[self._offset:self._offset + size]
            self._offset += len(chunk)
        if chunk:
            self._pbar.update(len(chunk))
        return chunk

    def __len__(self) -> int:
        return len(self._data)


def _put_with_retry(
    url: str,
    data: bytes,
    headers: Dict[str, str],
    desc: str = "",
    show_progress: bool = True,
    return_etag: bool = False,
) -> Optional[str]:
    """PUT data with exponential backoff retry.

    Returns:
        ETag string if *return_etag* is True, else None.
    """
    last_exc: Optional[Exception] = None

    for attempt in range(_MAX_RETRIES):
        try:
            logger.debug(
                "PUT %s | headers=%s | body_size=%d bytes",
                url,
                headers,
                len(data),
            )
            if show_progress:
                pbar = tqdm(
                    total=len(data),
                    unit="B",
                    unit_scale=True,
                    desc=os.path.basename(desc),
                    leave=False,
                )
                body: Any = _ProgressReader(data, pbar)
            else:
                pbar = None
                body = data

            try:
                resp = requests.put(url, data=body, headers=headers, timeout=300)
                resp.raise_for_status()
            finally:
                if pbar is not None:
                    pbar.close()

            if return_etag:
                return resp.headers.get("ETag", "").strip('"')
            return None
        except (requests.RequestException, IOError) as exc:
            last_exc = exc
            if attempt < _MAX_RETRIES - 1:
                time.sleep(_RETRY_DELAYS[attempt])

    raise BiotailorUploadError(
        f"Upload failed after {_MAX_RETRIES} attempts for {desc}: {last_exc}"
    )
