"""redact() Annotated marker tests."""

from __future__ import annotations

import typing
from typing import Annotated, get_type_hints

import pytest
from pydantic import BaseModel

from herald import redact
from herald._redaction import RedactMarker


def test_redact_returns_marker() -> None:
    m = redact("last4")
    assert isinstance(m, RedactMarker)
    assert m.strategy == "last4"


def test_marker_repr() -> None:
    assert repr(redact("hash")) == "redact('hash')"


def test_markers_compare_by_strategy() -> None:
    assert redact("mask") == redact("mask")
    assert redact("mask") != redact("drop")
    assert hash(redact("mask")) == hash(redact("mask"))


def test_marker_attaches_to_pydantic_field() -> None:
    class Payment(BaseModel):
        card_number: Annotated[str, redact("last4")]
        ssn: Annotated[str, redact("hash")]
        cardholder_name: str

    hints = get_type_hints(Payment, include_extras=True)
    card_meta = typing.get_args(hints["card_number"])
    assert any(isinstance(arg, RedactMarker) and arg.strategy == "last4" for arg in card_meta)

    ssn_meta = typing.get_args(hints["ssn"])
    assert any(isinstance(arg, RedactMarker) and arg.strategy == "hash" for arg in ssn_meta)

    name_meta = typing.get_args(hints["cardholder_name"])
    assert not any(isinstance(arg, RedactMarker) for arg in name_meta)


def test_pydantic_model_with_marker_validates_normally() -> None:
    class Payment(BaseModel):
        card_number: Annotated[str, redact("last4")]
        amount: float

    p = Payment(card_number="4111111111111234", amount=49.99)
    assert p.card_number == "4111111111111234"
    assert p.amount == 49.99


def test_unknown_strategy_rejected_by_typing() -> None:
    # Pydantic doesn't enforce the Literal at runtime here (it's a marker
    # arg, not a field type), but mypy / pyright will. Smoke-check that the
    # builder still constructs without error so misuse doesn't crash.
    with pytest.raises(TypeError):
        redact()  # type: ignore[call-arg]
