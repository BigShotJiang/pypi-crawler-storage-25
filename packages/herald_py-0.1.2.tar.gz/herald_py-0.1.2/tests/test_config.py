"""Pydantic-driven config validation tests."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

import herald
from herald._config import HeraldConfig, active


def test_default_config_is_valid() -> None:
    cfg = HeraldConfig()
    assert cfg.environment == "development"
    assert cfg.durability == "memory"
    assert cfg.wire == "otlp"
    assert cfg.sample_rate == 1.0


def test_unknown_durability_mode_rejected() -> None:
    with pytest.raises(ValidationError):
        HeraldConfig(durability="not-a-mode")  # type: ignore[arg-type]


def test_unknown_wire_format_rejected() -> None:
    with pytest.raises(ValidationError):
        HeraldConfig(wire="raw-bytes")  # type: ignore[arg-type]


def test_negative_buffer_size_rejected() -> None:
    with pytest.raises(ValidationError):
        HeraldConfig(durability_max_bytes=-1)


def test_sample_rate_outside_range_rejected() -> None:
    with pytest.raises(ValidationError):
        HeraldConfig(sample_rate=2.0)
    with pytest.raises(ValidationError):
        HeraldConfig(sample_rate=-0.1)


def test_extra_fields_forbidden() -> None:
    with pytest.raises(ValidationError):
        HeraldConfig(unexpected_field="oops")  # type: ignore[call-arg]


def test_config_is_frozen() -> None:
    cfg = HeraldConfig()
    with pytest.raises(ValidationError):
        cfg.environment = "production"  # type: ignore[misc]


def test_configure_replaces_active_config() -> None:
    herald.configure(service="alpha", environment="staging")
    assert active().service == "alpha"
    assert active().environment == "staging"

    herald.configure(service="beta", environment="production")
    assert active().service == "beta"
    assert active().environment == "production"
