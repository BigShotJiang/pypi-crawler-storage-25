"""Pydantic event-model validation tests."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from herald._models import AuditChainEntry, HeraldEvent

GOOD_TRACE = bytes.fromhex("4bf92f3577b34da6a3ce929d0e0e4736")
GOOD_SPAN = bytes.fromhex("00f067aa0ba902b7")
GOOD_HASH = bytes(32)


def test_event_minimum_construction() -> None:
    event = HeraldEvent(
        event_id="evt_001",
        trace_id=GOOD_TRACE,
        span_id=GOOD_SPAN,
        run_id="run_001",
        kind="agent.start",
        name="sample-agent",
        timestamp_ns=1_700_000_000_000_000_000,
    )
    assert event.severity == "INFO"
    assert event.chain_kind == "telemetry"
    assert event.attributes == {}


def test_trace_id_must_be_16_bytes() -> None:
    with pytest.raises(ValidationError):
        HeraldEvent(
            event_id="evt_002",
            trace_id=b"too-short",
            span_id=GOOD_SPAN,
            run_id="run_002",
            kind="agent.start",
            name="x",
            timestamp_ns=0,
        )


def test_span_id_must_be_8_bytes() -> None:
    with pytest.raises(ValidationError):
        HeraldEvent(
            event_id="evt_003",
            trace_id=GOOD_TRACE,
            span_id=b"too-short",
            run_id="run_003",
            kind="agent.start",
            name="x",
            timestamp_ns=0,
        )


def test_unknown_severity_rejected() -> None:
    with pytest.raises(ValidationError):
        HeraldEvent(
            event_id="evt_004",
            trace_id=GOOD_TRACE,
            span_id=GOOD_SPAN,
            run_id="run_004",
            kind="agent.start",
            name="x",
            timestamp_ns=0,
            severity="LOUD",  # type: ignore[arg-type]
        )


def test_audit_chain_seq_must_be_positive() -> None:
    with pytest.raises(ValidationError):
        AuditChainEntry(seq=0, prev_hash=GOOD_HASH, payload_hash=GOOD_HASH)


def test_audit_chain_hashes_must_be_32_bytes() -> None:
    with pytest.raises(ValidationError):
        AuditChainEntry(seq=1, prev_hash=b"\x00" * 16, payload_hash=GOOD_HASH)


def test_event_round_trips_through_json() -> None:
    original = HeraldEvent(
        event_id="evt_005",
        trace_id=GOOD_TRACE,
        span_id=GOOD_SPAN,
        run_id="run_005",
        kind="audit.event",
        name="refund_decision",
        timestamp_ns=1_700_000_000_000_000_000,
        attributes={"audit.decision": "approve"},
        chain_kind="audit",
        audit_chain=AuditChainEntry(seq=1, prev_hash=GOOD_HASH, payload_hash=GOOD_HASH),
    )
    serialized = original.model_dump_json()
    restored = HeraldEvent.model_validate_json(serialized)
    assert restored == original
