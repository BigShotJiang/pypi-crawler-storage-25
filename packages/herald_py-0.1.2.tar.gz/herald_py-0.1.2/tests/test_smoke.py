"""Import + public-surface smoke tests."""

from __future__ import annotations

import asyncio

import herald


def test_version_string_present() -> None:
    assert isinstance(herald.__version__, str)
    assert len(herald.__version__) > 0


def test_public_surface_callable() -> None:
    for name in (
        "configure",
        "agent",
        "tool",
        "llm_call",
        "record",
        "audit",
        "span",
        "aspan",
        "auto_instrument",
        "redact",
    ):
        assert callable(getattr(herald, name)), f"{name} should be callable"


def test_configure_accepts_full_signature() -> None:
    herald.configure(
        backend="https://localhost:4317",
        api_key="test-key",
        service="smoke-test",
        environment="test",
        durability="memory",
        redact={"card_number": "last4"},
    )


def test_decorator_passthrough_sync() -> None:
    @herald.tool(name="sample_tool")
    def add(a: int, b: int) -> int:
        return a + b

    assert add(2, 3) == 5


def test_decorator_passthrough_async() -> None:
    @herald.agent(name="sample_agent", version="0.0.1")
    async def echo(value: str) -> str:
        return value

    assert asyncio.run(echo("ok")) == "ok"


def test_record_and_audit_do_not_raise() -> None:
    herald.record(event="smoke_event", level="info", k="v")
    herald.audit(event="smoke_audit", decision="approve")


def test_span_context_manager_sync() -> None:
    with herald.span("smoke_span", x=1) as s:
        s.attach(y=2)


def test_aspan_context_manager_async() -> None:
    async def driver() -> None:
        async with herald.aspan("smoke_aspan", x=1) as s:
            s.attach(y=2)

    asyncio.run(driver())
