"""Per-framework integration modules.

Each submodule exposes an `instrument()` function that monkey-patches its
target library to emit Herald events. The auto_instrument() entry point in
herald._instrumentation discovers and calls these.
"""
