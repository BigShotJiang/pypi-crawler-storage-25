"""Redaction marker for Pydantic-typed fields.

Use as a typing.Annotated marker on Pydantic model fields so the SDK
applies the configured strategy when the field is captured.

Example:
    from typing import Annotated
    from pydantic import BaseModel
    from herald import redact

    class PaymentInfo(BaseModel):
        card_number: Annotated[str, redact("last4")]
        ssn: Annotated[str, redact("hash")]
        cardholder_name: str  # not redacted
"""

from __future__ import annotations

from typing import Literal

RedactionStrategy = Literal[
    "drop",
    "mask",
    "hash",
    "last4",
    "domain_only",
    "tokenize",
]


class RedactMarker:
    """Annotation marker carrying the redaction strategy."""

    __slots__ = ("strategy",)

    def __init__(self, strategy: RedactionStrategy) -> None:
        self.strategy: RedactionStrategy = strategy

    def __repr__(self) -> str:
        return f"redact({self.strategy!r})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, RedactMarker) and self.strategy == other.strategy

    def __hash__(self) -> int:
        return hash(("RedactMarker", self.strategy))


def redact(strategy: RedactionStrategy) -> RedactMarker:
    """Build a RedactMarker for use inside typing.Annotated[...]."""
    return RedactMarker(strategy)
