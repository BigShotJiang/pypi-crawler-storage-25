"""span() context manager for arbitrary capture boundaries."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from contextlib import asynccontextmanager, contextmanager
from typing import Any


class _SpanHandle:
    def attach(self, **attributes: Any) -> None:
        # TODO(phase-1): merge attributes into the active span.
        _ = attributes


@contextmanager
def span(name: str, **attributes: Any) -> Iterator[_SpanHandle]:
    """Open a synchronous span as a child of the current run."""
    # TODO(phase-1): open span, push to context, capture timing.
    _ = (name, attributes)
    yield _SpanHandle()


@asynccontextmanager
async def aspan(name: str, **attributes: Any) -> AsyncIterator[_SpanHandle]:
    """Open an async span as a child of the current run."""
    _ = (name, attributes)
    yield _SpanHandle()
