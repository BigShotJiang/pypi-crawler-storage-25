"""Herald — audit-grade agent observability for Python."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError as _PackageNotFoundError
from importlib.metadata import version as _pkg_version

from ._config import configure
from ._decorators import agent, llm_call, tool
from ._events import audit, record
from ._instrumentation import auto_instrument
from ._redaction import redact
from ._spans import aspan, span

# WHY read __version__ from package metadata instead of hardcoding it: the
# pyproject.toml [project] version field is the single source of truth for
# the release number. Hardcoding it here means any release where someone
# bumps pyproject but forgets to bump this literal ships with mismatched
# version reporting. importlib.metadata reads what pip actually installed,
# so the two can never drift.
#
# WHY the fallback: editable installs from a source checkout sometimes
# do not register package metadata. Returning a sentinel keeps imports
# from breaking in that case.
try:
    __version__ = _pkg_version("herald-py")
except _PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__ = [
    "__version__",
    "agent",
    "aspan",
    "audit",
    "auto_instrument",
    "configure",
    "llm_call",
    "record",
    "redact",
    "span",
    "tool",
]
