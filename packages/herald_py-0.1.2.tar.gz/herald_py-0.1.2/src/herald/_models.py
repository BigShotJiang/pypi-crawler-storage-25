"""Pydantic event-shape models matching the technical-doc walkthrough.

Internal models — not part of the public surface. Customers do not construct
these directly; the SDK builds them on every captured event.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

ChainKind = Literal["telemetry", "audit"]
Severity = Literal["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL", "AUDIT"]


class AuditChainEntry(BaseModel):
    """One position in a tamper-evident audit chain for a given run_id."""

    model_config = ConfigDict(frozen=True, ser_json_bytes="base64", val_json_bytes="base64")

    seq: int = Field(ge=1)
    prev_hash: bytes = Field(min_length=32, max_length=32)
    payload_hash: bytes = Field(min_length=32, max_length=32)


class HeraldEvent(BaseModel):
    """Captured event flowing from SDK -> local buffer -> wire -> server."""

    model_config = ConfigDict(
        frozen=True,
        arbitrary_types_allowed=False,
        ser_json_bytes="base64",
        val_json_bytes="base64",
    )

    event_id: str
    trace_id: bytes = Field(min_length=16, max_length=16)
    span_id: bytes = Field(min_length=8, max_length=8)
    parent_span_id: bytes | None = Field(default=None, min_length=8, max_length=8)
    run_id: str

    kind: str
    name: str
    timestamp_ns: int = Field(ge=0)
    duration_ns: int | None = Field(default=None, ge=0)

    attributes: dict[str, Any] = Field(default_factory=dict)
    resource: dict[str, Any] = Field(default_factory=dict)

    severity: Severity = "INFO"
    chain_kind: ChainKind = "telemetry"
    audit_chain: AuditChainEntry | None = None
