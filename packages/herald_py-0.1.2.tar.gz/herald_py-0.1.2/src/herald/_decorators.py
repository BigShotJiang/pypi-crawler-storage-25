"""Public decorators: @agent, @tool, @llm_call.

Stub implementations for v0.0.1. Real capture wiring lands in phase 1.
"""

from __future__ import annotations

import asyncio
import functools
from collections.abc import Awaitable, Callable
from typing import Any, ParamSpec, TypeVar, overload

P = ParamSpec("P")
R = TypeVar("R")


def agent(
    *,
    name: str,
    version: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Mark a function as the top-level boundary of an agent run."""
    return _make_decorator(kind="agent", name=name, extra={"agent.version": version})


def tool(
    *,
    name: str,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Mark a function as a tool the agent can invoke."""
    return _make_decorator(kind="tool", name=name)


def llm_call(
    *,
    model: str,
    provider: str | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Mark a function as a manual LLM invocation outside auto-instrumented SDKs."""
    return _make_decorator(
        kind="llm_call",
        name=model,
        extra={"gen_ai.request.model": model, "gen_ai.system": provider},
    )


def _make_decorator(
    *,
    kind: str,
    name: str,
    extra: dict[str, Any] | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    @overload
    def decorator(fn: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]: ...
    @overload
    def decorator(fn: Callable[P, R]) -> Callable[P, R]: ...

    def decorator(fn: Callable[P, Any]) -> Callable[P, Any]:
        if asyncio.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> Any:
                # TODO(phase-1): open span, capture inputs, write to buffer.
                _ = (kind, name, extra, args, kwargs)
                return await fn(*args, **kwargs)
            return async_wrapper

        @functools.wraps(fn)
        def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> Any:
            # TODO(phase-1): open span, capture inputs, write to buffer.
            _ = (kind, name, extra, args, kwargs)
            return fn(*args, **kwargs)
        return sync_wrapper

    return decorator
