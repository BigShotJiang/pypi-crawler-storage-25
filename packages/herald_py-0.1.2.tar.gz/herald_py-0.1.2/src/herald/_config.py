"""Process-wide SDK configuration.

Sync-callable; safe to invoke from async code. configure() runs once at
process start before any async work begins, so it does not block an event loop.
"""

from __future__ import annotations

import os
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

DurabilityMode = Literal["memory", "sqlite"]
WireFormat = Literal["otlp", "herald"]
DropPolicy = Literal["oldest_telemetry_first", "oldest_any_first", "halt_on_audit_loss"]


class HeraldConfig(BaseModel):
    """Immutable, validated SDK configuration.

    Pydantic does Literal validation, range checks, and round-trip JSON
    for free; replaces ad-hoc coerce helpers and gives precise error
    messages on bad config.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    backend: str | None = None
    api_key: str | None = None
    service: str | None = None
    environment: str = "development"

    durability: DurabilityMode = "memory"
    durability_path: str | None = None
    durability_max_bytes: int = Field(default=512 * 1024 * 1024, gt=0)
    durability_drop_policy: DropPolicy = "oldest_telemetry_first"

    redact: dict[str, str] = Field(default_factory=dict)

    wire: WireFormat = "otlp"
    sample_rate: float = Field(default=1.0, ge=0.0, le=1.0)


_active: HeraldConfig = HeraldConfig()


def configure(
    *,
    backend: str | None = None,
    api_key: str | None = None,
    service: str | None = None,
    environment: str | None = None,
    durability: DurabilityMode | None = None,
    durability_path: str | None = None,
    durability_max_bytes: int | None = None,
    durability_drop_policy: DropPolicy | None = None,
    redact: dict[str, str] | None = None,
    wire: WireFormat | None = None,
    sample_rate: float | None = None,
) -> None:
    """Set process-wide SDK configuration. Falls back to env vars for unset args.

    Pydantic raises ValidationError on invalid combinations (unknown durability
    mode, sample_rate outside [0, 1], non-positive durability_max_bytes, etc.).
    """
    global _active
    _active = HeraldConfig(
        backend=backend or os.environ.get("HERALD_BACKEND"),
        api_key=api_key or os.environ.get("HERALD_API_KEY"),
        service=service or os.environ.get("HERALD_SERVICE"),
        environment=environment
            or os.environ.get("HERALD_ENVIRONMENT", "development"),
        durability=durability
            or os.environ.get("HERALD_DURABILITY", "memory"),  # type: ignore[arg-type]
        durability_path=durability_path or os.environ.get("HERALD_DURABILITY_PATH"),
        durability_max_bytes=durability_max_bytes
            or int(os.environ.get("HERALD_DURABILITY_MAX_BYTES", 512 * 1024 * 1024)),
        durability_drop_policy=durability_drop_policy
            or os.environ.get("HERALD_DURABILITY_DROP_POLICY", "oldest_telemetry_first"),  # type: ignore[arg-type]
        redact=redact or {},
        wire=wire or os.environ.get("HERALD_WIRE", "otlp"),  # type: ignore[arg-type]
        sample_rate=sample_rate
            if sample_rate is not None
            else float(os.environ.get("HERALD_SAMPLE_RATE", "1.0")),
    )


def active() -> HeraldConfig:
    return _active
