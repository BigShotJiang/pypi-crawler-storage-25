"""Public event APIs: record(), audit().

Both functions are sync-callable but designed to be safe from async code.
Phase 1 wiring will offload the durable write to a worker thread when called
from inside a running event loop, so the loop is never blocked on fsync.
"""

from __future__ import annotations

from typing import Any


def record(
    *,
    event: str,
    level: str = "info",
    **attributes: Any,
) -> None:
    """Emit an arbitrary structured telemetry event.

    Sync-callable. Safe from async code (phase 1 will offload the buffer
    write to a worker thread when invoked from a running event loop).
    """
    # TODO(phase-1): build HeraldEvent, run pipeline, write to buffer.
    _ = (event, level, attributes)


def audit(
    *,
    event: str,
    **attributes: Any,
) -> None:
    """Emit an audit-channel event with synchronous durability and chain-of-custody.

    Bypasses sampling. Returns after the event is on disk. Tamper-evident
    SHA-256 chain per run_id.

    Sync-callable. Safe from async code (phase 1 will offload the fsync to
    a worker thread when invoked from a running event loop, so the loop is
    not blocked on the sync write).
    """
    # TODO(phase-1): build audit event, compute chain hash, fsync to SQLite.
    _ = (event, attributes)


def hash_inputs(*values: Any) -> str:
    """Compute a stable SHA-256 over canonical JSON of the given values."""
    # TODO(phase-1): canonical JSON + SHA-256 hex digest.
    _ = values
    return ""
