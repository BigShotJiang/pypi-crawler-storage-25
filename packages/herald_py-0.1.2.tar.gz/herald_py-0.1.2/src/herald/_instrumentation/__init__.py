"""Auto-instrumentation entry point."""

from __future__ import annotations


def auto_instrument() -> None:
    """Detect installed integrations and patch each one for capture."""
    # TODO(phase-1): probe sys.modules / importlib for known packages,
    # call .instrument() on each matching submodule under herald.integrations.
