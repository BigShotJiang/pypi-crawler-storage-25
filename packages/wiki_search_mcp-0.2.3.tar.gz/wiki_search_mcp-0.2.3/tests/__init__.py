"""Wiki Search MCP Tests"""
