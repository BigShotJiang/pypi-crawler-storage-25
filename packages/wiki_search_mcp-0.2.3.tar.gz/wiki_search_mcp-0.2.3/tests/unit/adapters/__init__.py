"""Adapter layer unit tests."""
