"""Core layer unit tests."""
