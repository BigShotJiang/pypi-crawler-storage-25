"""SLSQP Solver implementation using Optimistix.

This module contains the main SLSQP solver class that extends
optimistix.AbstractMinimiser to provide Sequential Quadratic Programming
optimization with support for equality and inequality constraints.

The QP subproblem always uses a frozen L-BFGS Hessian approximation,
which is O(kn) in both memory and per-product cost. When the user
supplies exact HVPs (obj_hvp_fn), these are probed once per main
iteration along the step direction to produce high-quality secant
pairs for the L-BFGS update, but the HVP is never called inside
the QP inner loop.

Gradients and Jacobians can be user-supplied or computed
automatically via jax.grad (reverse-mode) and jax.jacrev.
"""

from collections.abc import Callable
from typing import Any, Optional, cast

import equinox as eqx
import jax
import jax.numpy as jnp
import numpy as np
import optimistix as optx
import optimistix._misc as optx_misc
from jaxtyping import Array, Bool, Float, Int

from slsqp_jax.hessian import (
    LBFGSHistory,
    compute_lagrangian_gradient,
    compute_partial_lagrangian_gradient,
    estimate_hessian_diagonal,
    lbfgs_append,
    lbfgs_curvature_diagnostics,
    lbfgs_hvp,
    lbfgs_identity_reset,
    lbfgs_init,
    lbfgs_inverse_hvp,
    lbfgs_soft_reset,
)
from slsqp_jax.inner_solver import (
    AbstractInnerSolver,
    InnerSolveResult,
    ProjectedCGCholesky,
)
from slsqp_jax.lpeca import compute_lpeca_active_set
from slsqp_jax.merit import (
    backtracking_line_search,
    compute_merit,
    update_penalty_parameter,
)
from slsqp_jax.qp_solver import solve_qp
from slsqp_jax.results import RESULTS
from slsqp_jax.types import (
    ConstraintFn,
    ConstraintHVPFn,
    GradFn,
    HVPFn,
    JacobianFn,
    Scalar,
    Vector,
)
from slsqp_jax.utils import args_closure, to_scalar

STAGNATION_MESSAGE = (
    "The solver stagnated: the L1 merit function did not improve over "
    "the patience window (max_steps / 10 consecutive iterations). This "
    "may indicate cycling in the QP subproblem or an infeasible/degenerate "
    "problem."
)


def _slsqp_verbose(**kwargs: tuple) -> None:
    """Default verbose callback with per-field format specifiers.

    Each kwarg value is either ``(label, value)`` or
    ``(label, value, fmt_spec)``.  The *fmt_spec* string (e.g. ``".3e"``)
    is inserted into the ``jax.debug.print`` format placeholder.
    """
    string_pieces: list[str] = []
    arg_pieces: list[Any] = []
    for entry in kwargs.values():
        if len(entry) == 3:
            name, value, fmt = entry
            string_pieces.append(f"{name}: {{:{fmt}}}")
        else:
            name, value = entry
            string_pieces.append(f"{name}: {{}}")
        arg_pieces.append(value)
    if string_pieces:
        jax.debug.print(", ".join(string_pieces), *arg_pieces)


def _no_verbose(**kwargs: tuple) -> None:
    pass


class SLSQPDiagnostics(eqx.Module):
    """Diagnostic counters and statistics accumulated during an SLSQP run.

    These fields are populated inside ``step()`` without Python-side
    branching, and can be inspected by the user after a solve to decide
    whether the ``optimistix`` result code is meaningful (e.g. to detect
    a ``RESULTS.successful`` that actually came from chronic line-search
    failure rather than real convergence).

    Attributes:
        n_qp_inner_failures: Number of iterations where the QP solver
            reported ``converged=False``.
        n_ls_failures: Number of iterations where the line search
            reported ``success=False``.
        n_lbfgs_skips: Number of iterations where the L-BFGS append
            skipped the new curvature pair.
        n_nan_directions: Number of iterations where the QP returned
            a non-finite search direction.
        max_gamma: Maximum L-BFGS ``gamma`` observed across iterations.
        min_diag: Minimum L-BFGS per-variable diagonal entry observed.
        max_diag: Maximum L-BFGS per-variable diagonal entry observed.
        eq_jac_min_sv_est: A lower bound on the smallest singular value
            of ``J_eq`` estimated from the Cholesky factor of
            ``J_eq J_eq^T``.  Small values indicate near rank-deficiency.
        ls_alpha_min: Smallest line-search step accepted across the run.
        tail_ls_failures: Consecutive line-search failure count at
            termination.  Non-zero values suggest stagnation.
        n_bound_fix_solves: Total number of non-trivial bound-fixing inner
            solves that actually ran (no-op passes are skipped via
            ``jax.lax.cond`` and do not count).  Growing unboundedly is a
            sign that the bound active set never stabilises.
        max_bound_fixed: Largest number of variables pinned to their box
            bounds across all iterations (from the final per-iteration
            ``free_mask``).
        max_active_ineq: Largest number of active general inequalities
            observed across iterations.
        n_merit_regressions: Number of iterations where the L1 merit
            function value *increased* despite the line search reporting
            success.  A non-zero count points to merit-function
            mis-calibration (too-small ``rho``) or line-search slippage.
        n_qp_budget_exhausted: Number of SQP steps where the QP
            active-set loop hit ``qp_max_iter`` (i.e. exited because
            the budget ran out, not because of clean convergence or a
            ping-pong short-circuit).  A non-zero count usually
            indicates degeneracy, multiplier-noise cycling, or an
            LPEC-A over-prediction that was not caught by the trust
            gate; consider raising ``mult_drop_floor`` or tightening
            ``lpeca_trust_threshold``.
        n_qp_ping_pong: Number of SQP steps where the QP loop's
            anti-cycling ping-pong detector fired.  These are *good*
            short-circuits (the loop avoided wasting its full budget)
            but a chronic non-zero value still points to a degenerate
            constraint pair worth investigating.
        max_qp_iterations: Peak active-set iteration count observed
            across all SQP steps.  Useful for sizing
            ``qp_max_iter``: if this is consistently equal to
            ``qp_max_iter`` the budget is too tight.
        max_qp_active_size: Peak ``|active_set|`` (general
            inequalities only) observed across all SQP steps.
        n_lpeca_bypassed: Number of SQP steps where the LPEC-A
            prediction was skipped, either because of the warm-up
            window (``step_count < lpeca_warmup_steps``) or because
            the trust gate vetoed it (``rho_bar > lpeca_trust_threshold``).
            Always 0 when ``active_set_method == "expand"``.
        n_lpeca_capped: Number of SQP steps where the LPEC-A
            rank-aware size cap truncated the prediction.
        n_lpeca_bounds_prefixed: Cumulative count of box-bound
            pre-fixes contributed by LPEC-A across all SQP steps
            (summed over the bound predictions that survived the
            trust / warm-up gates and were installed as the initial
            ``free_mask`` for the bound-fixing loop).  Always 0 when
            ``active_set_method == "expand"`` or when
            ``lpeca_predict_bounds=False``.
        n_proj_refinements: Cumulative number of M-metric projection
            refinement rounds taken across all inner solves performed
            by ``MinresQLPSolver`` over the run.  Always 0 for
            null-space CG / CRAIG.  Useful as an indicator of how
            often the inner self-correction had to step in.
        max_proj_residual: High-water mark of the post-refinement
            constraint residual ``||A d - b||`` reported by
            ``MinresQLPSolver`` on the *accepted* QP direction across
            all SQP steps.  A persistent non-zero value (relative to
            ``atol``) flags ill-conditioned QPs whose feasibility
            floor is being limited by the Schur regularisation rather
            than the Krylov tolerance.  Always 0 for null-space
            solvers.
        n_divergence_blowups: Total number of merit blowup events
            observed across the run, whether or not the patience
            threshold was eventually reached.  This is the *raw*
            blowup count (sum of every step where the merit exceeded
            ``best_merit + divergence_factor * max(|best_merit|, 1)``
            or returned NaN/Inf), not just the trigger events.
        divergence_triggered: True when the best-iterate divergence
            rollback fired at least once during the run.  When the
            ``slsqp_jax.RESULTS`` result code is ``iterate_blowup``
            and this flag is set, the returned iterate is the
            best-merit iterate seen so far rather than the most
            recent (divergent) one.
    """

    n_qp_inner_failures: Int[Array, ""]
    n_ls_failures: Int[Array, ""]
    n_lbfgs_skips: Int[Array, ""]
    n_nan_directions: Int[Array, ""]
    max_gamma: Scalar
    min_diag: Scalar
    max_diag: Scalar
    eq_jac_min_sv_est: Scalar
    ls_alpha_min: Scalar
    tail_ls_failures: Int[Array, ""]
    n_bound_fix_solves: Int[Array, ""]
    max_bound_fixed: Int[Array, ""]
    max_active_ineq: Int[Array, ""]
    n_merit_regressions: Int[Array, ""]
    n_qp_budget_exhausted: Int[Array, ""]
    n_qp_ping_pong: Int[Array, ""]
    max_qp_iterations: Int[Array, ""]
    max_qp_active_size: Int[Array, ""]
    n_lpeca_bypassed: Int[Array, ""]
    n_lpeca_capped: Int[Array, ""]
    n_lpeca_bounds_prefixed: Int[Array, ""]
    n_proj_refinements: Int[Array, ""]
    max_proj_residual: Scalar
    n_divergence_blowups: Int[Array, ""]
    divergence_triggered: Bool[Array, ""]
    # Low-water mark of the inner solver's projected-gradient norm
    # ``||W̃_k g_k||`` across the run.  Always ``inf`` for inner
    # solvers other than ``HRInexactSTCG`` (the default value
    # populated through ``InnerSolveResult.projected_grad_norm`` when
    # the solver does not produce this quantity).  Surfaced for
    # post-hoc inspection of how close the run actually got to KKT in
    # the inexact-projection sense, regardless of whether
    # ``use_inexact_stationarity`` was on.
    min_projected_grad_norm: Scalar
    # Number of iterations where the inner solver's projected-gradient
    # norm ``||W̃_k g_k||`` was strictly smaller than the classical
    # Lagrangian gradient norm ``||\u2207L||``.  A high count is the
    # post-hoc indicator that multiplier-recovery noise is the limiting
    # factor (i.e. the inexact-stationarity disjunct could rescue the
    # run from a stationarity stall) and the user might benefit from
    # ``use_inexact_stationarity=True`` paired with ``HRInexactSTCG``.
    # Always ``0`` for inner solvers that do not populate
    # ``projected_grad_norm`` because the field is initialised to
    # ``+inf`` and never compares less than the finite classical norm.
    n_steps_inexact_below_classical: Int[Array, ""]


def _init_diagnostics() -> SLSQPDiagnostics:
    """Construct a zero-initialized ``SLSQPDiagnostics`` container."""
    return SLSQPDiagnostics(  # ty: ignore[invalid-return-type]
        n_qp_inner_failures=jnp.array(0),
        n_ls_failures=jnp.array(0),
        n_lbfgs_skips=jnp.array(0),
        n_nan_directions=jnp.array(0),
        max_gamma=jnp.array(0.0),
        min_diag=jnp.array(jnp.inf),
        max_diag=jnp.array(0.0),
        eq_jac_min_sv_est=jnp.array(jnp.inf),
        ls_alpha_min=jnp.array(1.0),
        tail_ls_failures=jnp.array(0),
        n_bound_fix_solves=jnp.array(0),
        max_bound_fixed=jnp.array(0),
        max_active_ineq=jnp.array(0),
        n_merit_regressions=jnp.array(0),
        n_qp_budget_exhausted=jnp.array(0),
        n_qp_ping_pong=jnp.array(0),
        max_qp_iterations=jnp.array(0),
        max_qp_active_size=jnp.array(0),
        n_lpeca_bypassed=jnp.array(0),
        n_lpeca_capped=jnp.array(0),
        n_lpeca_bounds_prefixed=jnp.array(0),
        n_proj_refinements=jnp.array(0),
        max_proj_residual=jnp.array(0.0),
        n_divergence_blowups=jnp.array(0),
        divergence_triggered=jnp.array(False),
        min_projected_grad_norm=jnp.asarray(jnp.inf),
        n_steps_inexact_below_classical=jnp.array(0),
    )


def get_diagnostics(state: "SLSQPState") -> SLSQPDiagnostics:
    """Return the ``SLSQPDiagnostics`` accumulator from a final state.

    Use this after ``optimistix.minimise`` (or a manual ``solve / step``
    loop) to inspect solver health indicators that the Optimistix result
    code alone does not expose.  See :class:`SLSQPDiagnostics` for field
    meanings.
    """
    return state.diagnostics


class SLSQPState(eqx.Module):
    """State for the SLSQP solver.

    This is a JAX PyTree (via eqx.Module) that holds all mutable state
    needed across SLSQP iterations.

    Attributes:
        step_count: Current iteration number.
        f_val: Current objective function value f(x_k).
        grad: Gradient of objective at current point.
        eq_val: Equality constraint values c_eq(x_k).
        ineq_val: Inequality constraint values c_ineq(x_k).
        eq_jac: Jacobian of equality constraints at x_k.
        ineq_jac: Jacobian of inequality constraints at x_k.
        lbfgs_history: L-BFGS history for matrix-free Hessian approximation.
        multipliers_eq: Lagrange multipliers for equality constraints.
        multipliers_ineq: Lagrange multipliers for inequality constraints.
        prev_grad_lagrangian: Previous Lagrangian gradient (for L-BFGS update).
        grad_lagrangian: Current gradient of the Lagrangian evaluated at
            the accepted iterate using the *blended* multipliers
            consistent with the line-search step size.  Reused by
            ``terminate`` so the stationarity check does not fall out
            of sync with the L-BFGS secant pair.
        merit_penalty: Current penalty parameter for L1 merit function.
        bound_jac: Constant Jacobian for bound constraints (computed once in init).
        qp_iterations: Total accumulated QP active-set iterations across all steps.
        qp_converged: Whether the most recent QP solve converged.
        prev_active_set: Active inequality constraint set from the previous QP solve,
            used for warm-starting the next QP subproblem.
        termination_code: Granular ``slsqp_jax.RESULTS`` classification
            (``successful`` / ``merit_stagnation`` / ``line_search_failure``
            / ``iterate_blowup`` / ``infeasible`` / ``qp_subproblem_failure``
            / ``nonlinear_max_steps_reached`` / ``nonfinite``). Surfaced
            via ``Solution.stats["slsqp_result"]``; ``Solution.result``
            itself remains the coarse ``optx.RESULTS`` code accepted by
            optimistix's driver.
    """

    # Iteration tracking
    step_count: Int[Array, ""]

    # Current function values and gradients
    f_val: Scalar
    grad: Vector

    # Constraint information
    eq_val: Float[Array, " m_eq"]
    ineq_val: Float[Array, " m_ineq"]
    eq_jac: Float[Array, "m_eq n"]
    ineq_jac: Float[Array, "m_ineq n"]

    # L-BFGS history for matrix-free Hessian approximation (O(kn) storage)
    lbfgs_history: LBFGSHistory

    # Lagrange multipliers from QP solution
    multipliers_eq: Float[Array, " m_eq"]
    multipliers_ineq: Float[Array, " m_ineq"]

    # Previous Lagrangian gradient for L-BFGS y = grad_L_new - grad_L_old
    prev_grad_lagrangian: Vector

    # Current Lagrangian gradient at the accepted iterate, computed with
    # the *blended* multipliers (matching the L-BFGS secant pair).  Reused
    # by ``terminate`` for stationarity so the check is consistent with
    # what ``step`` saw.
    grad_lagrangian: Vector

    # Merit function penalty parameter
    merit_penalty: Scalar

    # Bound constraint Jacobian (constant, computed once in init)
    bound_jac: Float[Array, "m_bounds n"]

    # QP solver statistics
    qp_iterations: Int[Array, ""]
    qp_converged: Bool[Array, ""]

    # Active-set warm-starting: carry the QP active set across iterations
    # to promote multiplier stability (Wright, SIAM J. Optim., 2002, Sec. 8)
    prev_active_set: Bool[Array, " m_ineq"]

    # Consecutive QP failure tracking for escalating L-BFGS recovery
    consecutive_qp_failures: Int[Array, ""]

    # Consecutive line search failure tracking for escalating L-BFGS recovery
    consecutive_ls_failures: Int[Array, ""]

    # Zero-step convergence detection: consecutive iterations where the QP
    # converged but returned ||d|| < atol, indicating the current point
    # satisfies the QP's KKT conditions.
    consecutive_zero_steps: Int[Array, ""]
    qp_optimal: Bool[Array, ""]

    # Merit-based stagnation detection
    best_merit: Scalar
    steps_without_improvement: Int[Array, ""]
    stagnation: Bool[Array, ""]
    last_alpha: Scalar

    # Norm of the projected gradient ``||W̃_k g_k||`` from the most
    # recent inner solve, surfaced through ``QPResult.projected_grad_norm``.
    # Always ``inf`` for inner solvers that do not produce this value
    # (everything other than ``HRInexactSTCG``).  Used by
    # ``terminate()`` when ``use_inexact_stationarity=True`` so that
    # the run can declare convergence at the inner solver's noise
    # floor instead of waiting for the exact Lagrangian gradient.
    last_projected_grad_norm: Scalar

    # Whether the most recent line search reported success (Armijo satisfied
    # or at least a strictly decreasing merit).  Used by ``terminate`` to
    # distinguish genuine convergence from tiny-alpha stagnation.
    ls_success: Bool[Array, ""]

    # Whether the most recent line search failed AND the escalated
    # identity reset also failed (``consecutive_ls_failures`` exceeded
    # ``2 * ls_failure_patience``).  Triggers early termination with
    # ``RESULTS.line_search_failure`` to surface chronic LS failure.
    ls_fatal: Bool[Array, ""]

    # Whether the QP subproblem has failed for ``2 * qp_failure_patience``
    # consecutive iterations.  Mirrors ``ls_fatal``: the L-BFGS soft- /
    # identity-reset escalation could not produce a usable QP direction,
    # and we should terminate with ``RESULTS.qp_subproblem_failure``.
    qp_fatal: Bool[Array, ""]

    # Best-iterate divergence rollback (see :attr:`SLSQP.divergence_factor`).
    # ``best_x`` is the iterate that achieved ``best_merit``.  When the
    # merit blows up by ``divergence_factor`` or returns NaN/Inf for
    # ``divergence_patience`` consecutive steps, ``step()`` overwrites
    # the returned iterate with ``best_x`` and sets ``diverging=True``,
    # which routes ``terminate()`` to ``RESULTS.iterate_blowup``.
    best_x: Vector
    blowup_count: Int[Array, ""]
    diverging: Bool[Array, ""]

    # Granular termination classification using ``slsqp_jax.RESULTS``
    # (see :mod:`slsqp_jax.results`).  Optimistix's ``iterative_solve``
    # driver only accepts members of ``optx.RESULTS`` from
    # ``terminate()``, so the public ``Solution.result`` is the coarse
    # base-class code.  This field carries the finer
    # ``slsqp_jax.RESULTS`` classification (e.g. ``merit_stagnation``,
    # ``line_search_failure``, ``iterate_blowup``,
    # ``qp_subproblem_failure``, ``infeasible``) and is surfaced via
    # ``Solution.stats["slsqp_result"]`` in :meth:`SLSQP.postprocess`.
    # Pre-termination its value is ``RESULTS.successful`` (i.e. the
    # loop is still running, no failure latched).
    termination_code: Any

    # Diagnostic accumulators (see :class:`SLSQPDiagnostics`).
    diagnostics: SLSQPDiagnostics


class QPResult(eqx.Module):
    """Result from solving the QP subproblem.

    Attributes:
        direction: The search direction d from the QP solution.
        multipliers_eq: Lagrange multipliers for equality constraints.
        multipliers_ineq: Lagrange multipliers for inequality constraints.
        active_set: Boolean mask of active inequality constraints at the solution.
        converged: Whether the QP solver converged successfully.
        iterations: Number of active-set iterations taken.
        bound_fix_solves: Number of non-trivial bound-fixing passes that
            actually ran the reduced-space inner solve (passes where the
            free mask did not change are short-circuited).  Useful for
            debugging bound-handling overhead; 0 when the problem has no
            bound constraints.
        n_bound_fixed: Number of variables pinned to a box bound in the
            final QP direction (counts both lower- and upper-bound
            activations).
        ping_ponged: True when the QP active-set loop short-circuited
            on a detected add/drop ping-pong cycle.
        reached_max_iter: True when the QP active-set loop exhausted
            its iteration budget (``qp_max_iter``).
        lpeca_bypassed: True when the LPEC-A prediction was skipped
            for this step (warm-up window or trust gate fired).
        lpeca_capped: True when the LPEC-A prediction was truncated
            by the rank-aware size cap.
        n_lpeca_bounds_prefixed: Number of box-bound variables
            pre-fixed by LPEC-A before entering the bound-fixing
            loop.  Always 0 when ``active_set_method == "expand"``,
            when ``lpeca_predict_bounds=False``, or when LPEC-A was
            bypassed by the warm-up / trust gates.
        proj_residual: Post-refinement constraint residual ``||A d -
            b||`` from the inner solver producing the final QP
            direction (after bound-fixing).  Always 0 for null-space
            CG / CRAIG; relevant for ``MinresQLPSolver`` where it
            reflects the M-metric range-space projection floor and
            feeds the outer divergence detector via
            ``SLSQPDiagnostics.max_proj_residual``.
        n_proj_refinements: Cumulative number of M-metric projection
            refinement rounds across all inner solves performed for
            this QP step (active-set loop + bound-fixing loop).  Always
            0 for null-space solvers.
    """

    direction: Vector
    multipliers_eq: Float[Array, " m_eq"]
    multipliers_ineq: Float[Array, " m_ineq"]
    active_set: Bool[Array, " m_ineq"]
    converged: Bool[Array, ""]
    iterations: Int[Array, ""]
    bound_fix_solves: Int[Array, ""]
    n_bound_fixed: Int[Array, ""]
    ping_ponged: Bool[Array, ""]
    reached_max_iter: Bool[Array, ""]
    lpeca_bypassed: Bool[Array, ""]
    lpeca_capped: Bool[Array, ""]
    n_lpeca_bounds_prefixed: Int[Array, ""]
    proj_residual: Scalar
    n_proj_refinements: Int[Array, ""]
    projected_grad_norm: Scalar


class SLSQP(optx.AbstractMinimiser):
    """SLSQP minimizer using Sequential Quadratic Programming.

    This solver implements the SLSQP algorithm for constrained nonlinear
    optimization, designed to scale to large dimensions (n > 5000).

    At each iteration, it:

    1. Constructs a QP subproblem using a frozen L-BFGS Hessian
       approximation and linearized constraints.
    2. Solves the QP using projected conjugate gradient with an active-set
       method for inequality constraints.
    3. Performs a line search using an L1 merit function.
    4. Updates the L-BFGS history with a secant pair: either an exact
       HVP probe (if obj_hvp_fn is provided) or gradient differences.

    The Hessian is never formed as a dense matrix. The QP subproblem
    always uses a frozen L-BFGS approximation accessed through O(kn)
    Hessian-vector products, where k is the L-BFGS memory (typically 10).
    When exact HVPs are available, they are called once per main iteration
    (not inside the QP inner loop) to produce high-quality secant pairs.

    Users can optionally supply their own derivative functions:
    - obj_grad_fn: Gradient of objective (else jax.grad).
    - eq_jac_fn / ineq_jac_fn: Jacobians of constraints (else jax.jacrev).
    - obj_hvp_fn: HVP of objective (probed once per iteration for L-BFGS).
    - eq_hvp_fn / ineq_hvp_fn: HVPs of constraints (else forward-over-reverse AD).

    Box constraints (bounds) play a dual role.  Inside the QP
    subproblem they act as ordinary inequality constraints so that
    the search direction is aware of the feasible box.  After the
    line search, the accepted iterate is *projected* (clipped) onto
    the box, following the projected-SQP methodology
    (Heinkenschloss & Ridzal, *SIAM J. Optim.*, 1996).  This
    guarantees that the objective and constraint functions are never
    evaluated outside the bounds -- essential when those functions
    are undefined or ill-conditioned outside the box (e.g. a log
    likelihood with positivity constraints on its parameters).

    **Convergence criteria.**  The solver checks two conditions each
    iteration (both must be satisfied, and at least ``min_steps``
    iterations must have elapsed):

    1. *Stationarity* -- the Lagrangian gradient norm is small
       relative to the Lagrangian value:

       ``‖∇_x L‖ ≤ rtol · max(|L|, 1)``

       where ``L = f − λ_eqᵀ c_eq − μ_ineqᵀ c_ineq`` is the
       Lagrangian.  The ``max(|L|, 1)`` safeguard prevents the
       criterion from becoming vacuous when ``L ≈ 0`` and degrades
       gracefully to an absolute tolerance when ``|L| < 1``.  The
       relative form is motivated by floating-point arithmetic: when
       the gradient is negligible relative to ``|L|``, a step of
       that magnitude cannot change ``L`` in finite precision.

    2. *Primal feasibility* -- constraint violations are within
       absolute tolerance:

       ``max|c_eq(x)| ≤ atol``  and  ``max(0, −c_ineq(x)) ≤ atol``

    Attributes:
        rtol: Relative tolerance for the stationarity convergence
            check.  The Lagrangian gradient norm is compared against
            ``rtol · max(|L|, 1)``.  Default ``1e-6``.
        atol: Absolute tolerance for primal feasibility.  Used as
            the threshold for constraint violation checks and for
            internal heuristics (steepest-descent fallback, adaptive
            CG tolerance floor, proximal mu floor).  Default ``1e-6``.
        max_steps: Maximum number of iterations.
        eq_constraint_fn: Function computing equality constraints c_eq(x) = 0.
        ineq_constraint_fn: Function computing inequality constraints c_ineq(x) >= 0.
        n_eq_constraints: Number of equality constraints (static).
        n_ineq_constraints: Number of inequality constraints (static).
        bounds: Optional box constraints with shape (n, 2).  Iterates are
            always projected onto this box so functions are never evaluated
            outside the bounds.
        obj_grad_fn: Optional gradient of objective.
        eq_jac_fn: Optional Jacobian of equality constraints.
        ineq_jac_fn: Optional Jacobian of inequality constraints.
        obj_hvp_fn: Optional HVP of objective (probed once per iteration).
        eq_hvp_fn: Optional per-constraint HVP of equality constraints.
        ineq_hvp_fn: Optional per-constraint HVP of inequality constraints.
        min_steps: Minimum iterations before convergence is allowed (default 1).
        lbfgs_memory: Number of (s, y) pairs to store for L-BFGS (default 10).
        proximal_tau: Exponent for the adaptive proximal parameter mu in the
            sSQP formulation (Wright, 2002, eq 6.6).  The proximal parameter
            is computed as ``mu = clip(kkt_residual^tau, mu_min, mu_max)``
            at each iteration.  Capped at ``mu_max`` (default 0.1) so the
            proximal weight ``1/mu >= 1/mu_max``, ensuring adequate equality
            even far from the solution.  Must be in the half-open interval
            ``[0, 1)`` for the superlinear convergence guarantee.
            Default 0.5.  Set to 0 to disable sSQP proximal stabilization
            entirely: equality constraints are then enforced via direct
            null-space projection instead of the augmented Lagrangian
            penalty, avoiding the ill-conditioning introduced by the
            proximal term.
        proximal_mu_min: Floor on the adaptive proximal parameter mu.
            Prevents ``1/mu`` from exploding and creating a convergence floor
            on the Lagrangian gradient norm.  Default ``None`` resolves to
            ``atol`` in ``__check_init__``, so the proximal perturbation near
            convergence is ``O(atol)`` — consistent with the convergence
            tolerance.
        proximal_mu_max: Ceiling on the adaptive proximal parameter mu.
            Prevents ``1/mu`` from becoming too small far from the solution,
            which would weaken equality-constraint enforcement and sabotage
            the L1 merit function descent.  Wright's local convergence
            theory assumes ``kkt_residual < 1``; this cap handles the
            regime where ``kkt_residual >> 1``.  Default 0.1.
        use_preconditioner: When True (default), a preconditioner is used
            for the inner CG solver, dramatically improving convergence on
            ill-conditioned QP subproblems.
        preconditioner_type: Which preconditioner to use.  ``"lbfgs"``
            (default) uses the L-BFGS inverse Hessian (two-loop recursion).
            ``"diagonal"`` uses a stochastic estimate of the true Hessian
            diagonal (Bekas et al., 2007), requiring an exact HVP (set
            ``use_exact_hvp_in_qp=True`` or provide ``obj_hvp_fn``).
        diagonal_n_probes: Number of Rademacher probes for the stochastic
            diagonal estimator.  Each probe costs one HVP evaluation.  Only
            used when ``preconditioner_type="diagonal"``.  Default 20.
        adaptive_cg_tol: When True, the CG convergence tolerance is adapted
            based on the outer KKT residual (Eisenstat-Walker style).
            Default False preserves baseline behavior.
        cg_regularization: Minimum eigenvalue threshold ``delta^2`` for the
            CG curvature guard.  CG declares "bad curvature" when the
            effective eigenvalue ``p^T B p / ||p||^2`` falls below this
            value.  Prevents CG from terminating prematurely when the
            Hessian has small but positive eigenvalues (e.g. after an
            L-BFGS diagonal reset).  Based on SNOPT Section 4.5
            (Gill, Murray & Saunders, 2005).  Default ``1e-6``
            (delta ~ 1e-3).  Set to ``0.0`` to disable.
        active_set_method: Controls how the QP active set is initialized
            and whether the EXPAND anti-cycling tolerance grows.  One of
            ``"expand"`` (default EXPAND procedure), ``"lpeca_init"``
            (LPEC-A warm-start with EXPAND fallback), or ``"lpeca"``
            (LPEC-A with fixed tolerance, no EXPAND).  See Oberlin &
            Wright (2005).
        lpeca_sigma: Threshold exponent for LPEC-A (``sigma_bar`` in
            the paper).  Must be in (0, 1).  Default 0.9.
        lpeca_beta: Threshold scaling factor for LPEC-A.  Default
            ``None`` uses ``1 / (m_ineq + n + m_eq)``.
        lpeca_use_lp: When True, solve the LPEC-A LP to obtain tighter
            multiplier estimates before the threshold test.  Requires
            the ``mpax`` package.  Default False.
        lpeca_predict_bounds: When True (default) and
            ``active_set_method`` is ``"lpeca_init"`` or ``"lpeca"``,
            the LPEC-A prediction is also applied to box (bound)
            constraints -- the bound portion of the predicted active
            set seeds the initial ``free_mask`` of the bound-fixing
            loop, warm-starting the active bound set on
            bound-dominated problems.  Set to False to restrict
            LPEC-A to general inequality constraints only.
        inner_solver: Optional pluggable inner QP solver strategy.  When
            ``None`` (default), the solver constructs a
            ``ProjectedCGCholesky`` with parameters derived from other
            SLSQP settings.  Pass a ``ProjectedCGCraig`` or
            ``MinresQLPSolver`` instance to use an alternative strategy
            for the equality-constrained subproblem inside the QP
            active-set loop.  See ``inner_solver.py`` for the
            ``AbstractInnerSolver`` interface.

    Example:
        >>> import jax.numpy as jnp
        >>> from slsqp_jax import SLSQP
        >>>
        >>> def objective(x, args):
        ...     return jnp.sum(x**2), None
        >>>
        >>> def eq_constraint(x, args):
        ...     return jnp.array([x[0] + x[1] - 1.0])
        >>>
        >>> solver = SLSQP(eq_constraint_fn=eq_constraint, n_eq_constraints=1)
    """

    # Relative tolerance for the stationarity convergence check.
    rtol: float = 1e-6

    # Absolute tolerance for primal feasibility and internal heuristics.
    atol: float = 1e-6

    # Norm function for convergence checking (required by AbstractMinimiser)
    norm: Callable = eqx.field(static=True, default=optx_misc.max_norm)

    # Maximum iterations
    max_steps: int = 100

    # Minimum iterations before convergence is allowed.
    # Prevents premature termination when multipliers are not yet meaningful
    # (e.g. initial point satisfies constraints with zero-initialized multipliers).
    min_steps: int = 1

    # Constraint functions (static - not differentiated by optimistix)
    eq_constraint_fn: Optional[ConstraintFn] = eqx.field(static=True, default=None)
    ineq_constraint_fn: Optional[ConstraintFn] = eqx.field(static=True, default=None)

    # Number of constraints (must be static for JAX compilation)
    n_eq_constraints: int = eqx.field(static=True, default=0)
    n_ineq_constraints: int = eqx.field(static=True, default=0)

    # Box constraints (bounds) on decision variables.
    # Shape (n, 2) where bounds[i, 0] = lower, bounds[i, 1] = upper.
    # Use -jnp.inf / jnp.inf for unbounded dimensions.
    #
    # Bounds serve a dual role: (1) they enter the QP subproblem as
    # inequality constraints so the search direction respects them,
    # and (2) iterates are projected (clipped) onto the feasible box
    # after every line search step, following the projected-SQP
    # approach (Heinkenschloss & Ridzal, SIAM J. Optim., 1996).
    # This guarantees that the objective and constraint functions are
    # never evaluated outside the bounds, which is critical when those
    # functions are undefined or ill-conditioned outside the box.
    bounds: Optional[Float[Array, "n 2"]] = None

    # Masks indicating which bounds are finite (static for compilation)
    # These are computed from bounds at construction time and stored as tuples
    _lower_bound_mask: Optional[tuple[bool, ...]] = eqx.field(static=True, default=None)
    _upper_bound_mask: Optional[tuple[bool, ...]] = eqx.field(static=True, default=None)
    _n_lower_bounds: int = eqx.field(static=True, default=0)
    _n_upper_bounds: int = eqx.field(static=True, default=0)
    _lower_indices: Optional[tuple[int, ...]] = eqx.field(static=True, default=None)
    _upper_indices: Optional[tuple[int, ...]] = eqx.field(static=True, default=None)

    # Optional user-supplied derivative functions
    obj_grad_fn: Optional[GradFn] = eqx.field(static=True, default=None)
    eq_jac_fn: Optional[JacobianFn] = eqx.field(static=True, default=None)
    ineq_jac_fn: Optional[JacobianFn] = eqx.field(static=True, default=None)
    obj_hvp_fn: Optional[HVPFn] = eqx.field(static=True, default=None)
    eq_hvp_fn: Optional[ConstraintHVPFn] = eqx.field(static=True, default=None)
    ineq_hvp_fn: Optional[ConstraintHVPFn] = eqx.field(static=True, default=None)

    # Precomputed derivative callables (always set in __check_init__)
    _grad_impl: Callable = eqx.field(static=True, default=None)
    _eq_jac_impl: Callable = eqx.field(static=True, default=None)
    _ineq_jac_impl: Callable = eqx.field(static=True, default=None)
    _eq_hvp_contrib_impl: Callable = eqx.field(static=True, default=None)
    _ineq_hvp_contrib_impl: Callable = eqx.field(static=True, default=None)
    _obj_hvp_impl: Optional[Callable] = eqx.field(static=True, default=None)

    # L-BFGS parameters
    lbfgs_memory: int = eqx.field(static=True, default=10)

    # Powell damping threshold for L-BFGS curvature pairs.  Damping
    # ensures s^T y_damped >= threshold * s^T B s, which is needed for
    # positive definiteness in constrained optimization.  For
    # well-conditioned PD objectives where s^T y > 0 naturally holds,
    # setting this to 0.0 avoids corrupting curvature information.
    damping_threshold: float = 0.2

    # L-BFGS per-variable diagonal clip bounds for B_0 = diag(d).  The
    # inverse Hessian H_0 = diag(1/d) drives the initial CG search
    # direction magnitude.  The default floor 1e-4 bounds ||H_0||_inf
    # at 1e4; lowering this to 1e-6 (the old hardcoded value) let H_0
    # balloon to 1e6, which was the most likely cause of non-descent
    # directions that exhausted the backtracking line search.
    lbfgs_diag_floor: float = 1e-4
    lbfgs_diag_ceil: float = 1e6

    # Line search parameters
    line_search_max_steps: int = eqx.field(static=True, default=20)
    armijo_c1: float = 1e-4

    # QP solver parameters
    qp_max_iter: int = eqx.field(static=True, default=100)
    qp_max_cg_iter: int = eqx.field(static=True, default=50)

    # Pluggable inner QP solver strategy.  When None (default), the solver
    # constructs a ProjectedCGCholesky with parameters derived from the
    # other SLSQP settings (qp_max_cg_iter, atol, cg_regularization, etc.).
    # To use an alternative strategy (ProjectedCGCraig or MinresQLPSolver),
    # pass a fully-configured instance here.  The inner solver is forwarded
    # to solve_qp and the bound-fixing loop unchanged.
    inner_solver: Optional[AbstractInnerSolver] = eqx.field(static=True, default=None)

    # Newton-CG mode: use exact Lagrangian HVP (via AD) in the QP inner
    # loop instead of the L-BFGS approximation.  This costs one
    # forward-over-reverse HVP evaluation per CG step but can
    # dramatically improve convergence on ill-conditioned problems.
    # L-BFGS is still updated for preconditioning and as a fallback.
    use_exact_hvp_in_qp: bool = eqx.field(static=True, default=False)

    # Adaptive proximal multiplier stabilization (sSQP).
    # Active for equality-constrained problems when tau > 0.  The proximal
    # parameter mu = clip(kkt_residual^tau, mu_min, mu_max) is computed
    # per iteration (Wright, 2002, eq 6.6).  Must be in [0, 1).
    # Set to 0 to disable sSQP and use direct null-space projection.
    proximal_tau: float = 0.5

    # Floor on adaptive proximal mu.  None defaults to atol in
    # __check_init__ so that the proximal perturbation near convergence
    # is O(atol), consistent with the convergence tolerance.
    proximal_mu_min: Optional[float] = None

    # Ceiling on adaptive proximal mu.  Prevents weak enforcement of
    # equality constraints when the KKT residual is large (far from
    # solution).  With mu_max = 0.1, the proximal weight 1/mu >= 10.
    proximal_mu_max: float = eqx.field(static=True, default=0.1)

    # Resolved proximal_mu_min (always set in __check_init__)
    _proximal_mu_min: float = eqx.field(static=True, default=1e-6)

    # Resolved proximal_mu_max (always set in __check_init__)
    _proximal_mu_max: float = eqx.field(static=True, default=0.1)

    # Preconditioned CG: use L-BFGS inverse Hessian (two-loop recursion)
    # as preconditioner for the inner CG solver.  Dramatically improves
    # convergence on ill-conditioned QP subproblems, especially when
    # the proximal term is active.  Default True; set False to disable.
    use_preconditioner: bool = eqx.field(static=True, default=True)

    # Preconditioner type.  Controls which preconditioner is used for
    # the inner CG solver when ``use_preconditioner=True``.
    #   "lbfgs"    — L-BFGS inverse Hessian (two-loop recursion).
    #                Default; works without an exact HVP.
    #   "diagonal" — stochastic Hessian diagonal estimate (Bekas et al.,
    #                2007).  Requires an exact HVP (``use_exact_hvp_in_qp
    #                =True`` or ``obj_hvp_fn`` provided).  Probes the
    #                true Hessian at the current iterate, immune to the
    #                L-BFGS reset death spiral on ill-conditioned problems.
    #                Uses ``diagonal_n_probes`` Rademacher probes per step.
    preconditioner_type: str = eqx.field(static=True, default="lbfgs")

    # Number of Rademacher probes for the stochastic diagonal estimator.
    # Each probe costs one forward-over-reverse AD pass (same as one
    # gradient evaluation).  More probes reduce variance.  Only used
    # when ``preconditioner_type="diagonal"``.  Default 20.
    diagonal_n_probes: int = eqx.field(static=True, default=20)

    # Adaptive CG tolerance (Eisenstat-Walker-inspired).  Instead of
    # a fixed CG tolerance of atol, the tolerance is set to
    # min(0.1, max(atol, ||grad_L||)) so early QPs are solved loosely
    # and accuracy increases as the outer solver converges.  Default
    # False preserves baseline behavior; enable for large-scale problems
    # where early QP over-solving is wasteful.
    adaptive_cg_tol: bool = eqx.field(static=True, default=False)

    # Use the inner solver's projected-gradient norm
    # ``||W̃_k g_k||`` as an additional stationarity criterion in
    # ``terminate()``.  When True, the run can declare convergence
    # once ``state.last_projected_grad_norm <= rtol * max(|L|, 1)``,
    # which is the right test on ill-conditioned problems where the
    # null-space projector hits its noise floor and the exact
    # Lagrangian gradient cannot be driven below ``rtol``
    # (Heinkenschloss & Ridzal, 2014, Theorem 3.5).  The classical
    # ``||∇_x L||`` criterion is still checked in parallel; the
    # inexact path is purely *additive* (logical OR), so a run that
    # satisfies the classical test still converges classically
    # regardless of this flag.  Only meaningful when paired with the
    # ``HRInexactSTCG`` inner solver, which is the only solver that
    # populates ``InnerSolveResult.projected_grad_norm`` with
    # something other than ``inf``; with any other inner solver the
    # criterion silently degrades to "never converges this way".
    # Default False to preserve baseline semantics.
    use_inexact_stationarity: bool = eqx.field(static=True, default=False)

    # CG regularization: minimum eigenvalue threshold for the CG curvature
    # guard.  CG stops when the effective eigenvalue p^T B p / ||p||^2
    # falls below this value.  Prevents premature termination when Hessian
    # eigenvalues are small but positive (e.g. after a diagonal reset).
    # Based on SNOPT Section 4.5 (Gill, Murray & Saunders, 2005).
    # Default 1e-6 (delta ~ 1e-3). Set to 0.0 to disable.
    cg_regularization: float = 1e-6

    # QP failure patience: after this many consecutive QP failures, the
    # L-BFGS history is hard-reset to identity (B_0 = I) instead of the
    # SNOPT-style diagonal reset, breaking ill-conditioning cycles.
    qp_failure_patience: int = 3

    # Line search failure patience: after this many consecutive line search
    # failures, the L-BFGS history is hard-reset to identity.  On each
    # individual failure a SNOPT diagonal reset is applied first; the
    # identity escalation fires only after the patience threshold.
    ls_failure_patience: int = 3

    # Zero-step convergence: after this many consecutive iterations where
    # the QP converges with ||d|| < atol, declare convergence.  The QP's
    # KKT conditions are satisfied within cg_tol, so repeated d=0 steps
    # mean the current point is a constrained optimum to QP precision.
    zero_step_patience: int = 3

    # Stagnation detection: merit-based patience counter.
    # If the L1 merit function does not improve by at least
    # stagnation_tol * max(|best_merit|, 1) for W = max_steps // 10
    # consecutive steps, the solver declares stagnation.
    stagnation_tol: float = 1e-12

    # Stagnation patience (computed in __check_init__)
    _stagnation_window: int = eqx.field(static=True, default=10)

    # Best-iterate divergence rollback.  After ``divergence_patience``
    # consecutive steps where the L1 merit exceeds the best-seen merit
    # by more than ``divergence_factor * max(|best_merit|, 1)`` (or any
    # NaN/Inf merit at all), the solver rolls back to ``best_x`` and
    # terminates with ``RESULTS.iterate_blowup``.  This is a
    # belt-and-braces guardrail for cases where the inner self-correction
    # in ``MinresQLPSolver`` is not enough — typically badly
    # ill-conditioned QPs that occasionally let the SQP iterate drift
    # off the linearised feasible region.  The default ``divergence_factor =
    # 10`` is generous enough to ride out moderate penalty inflation
    # (which can scale the merit by O(rho)) and only fires on genuine
    # runaway growth.
    divergence_factor: float = 10.0
    divergence_patience: int = 3

    # LPEC-A active set identification (Oberlin & Wright, 2005).
    # Controls how the QP active set is initialized and whether the
    # EXPAND anti-cycling tolerance grows during the active-set loop.
    #   "expand"     — standard EXPAND procedure (default)
    #   "lpeca_init" — LPEC-A predicted set for warm-start, EXPAND fallback
    #   "lpeca"      — LPEC-A predicted set, fixed tolerance (no EXPAND)
    active_set_method: str = eqx.field(static=True, default="expand")

    # Threshold exponent for LPEC-A (sigma_bar in the paper).
    # Must be in (0, 1).  Default 0.9 per paper recommendation.
    lpeca_sigma: float = eqx.field(static=True, default=0.9)

    # Threshold scaling factor for LPEC-A.  None uses the paper's
    # recommendation 1 / (m_ineq + n + m_eq).
    lpeca_beta: Optional[float] = eqx.field(static=True, default=None)

    # When True, solve the LPEC-A LP (via mpax.r2HPDHG) for tighter
    # multiplier estimates before the threshold test.  Requires mpax.
    lpeca_use_lp: bool = eqx.field(static=True, default=False)

    # Trust threshold on rho_bar for LPEC-A.  When ``rho_bar`` exceeds
    # this value, the predicted active set is considered unreliable
    # (Oberlin & Wright Theorem 5 only guarantees correctness near the
    # solution) and is replaced by an empty prediction so the QP
    # active-set loop falls back to the warm-start path.  Default 1.0.
    lpeca_trust_threshold: float = eqx.field(static=True, default=1.0)

    # LPEC-A warm-up: the first ``lpeca_warmup_steps`` outer SLSQP
    # iterations bypass the LPEC-A prediction entirely.  Rationale:
    # asymptotic correctness of LPEC-A requires proximity to ``x*``;
    # the very first SQP steps are typically transient and the
    # multiplier estimates carried over from the previous QP are
    # noisy.  Default 3 (matches the ping-pong threshold).  Set to 0
    # to disable the warm-up and apply LPEC-A from step 0.  Only
    # affects ``active_set_method`` in ``("lpeca_init", "lpeca")``.
    lpeca_warmup_steps: int = eqx.field(static=True, default=3)

    # Whether to extend LPEC-A's prediction to box (bound) constraints.
    # When True (default), the bound portion of the LPEC-A-predicted
    # active set is scattered onto variable indices and installed as
    # the initial ``free_mask`` / ``d_fixed`` of the bound-fixing
    # loop, warm-starting the active bound set for problems that are
    # dominated by box constraints (e.g. L-BFGS-B style objectives,
    # portfolio problems with ``0 <= x <= 1``).  When LPEC-A's
    # prediction is accurate the bound-fixing loop typically drops
    # from 5 passes to 1--2 in total.  When the prediction is
    # bypassed by the warm-up or trust gates the warm-start is skipped
    # and the loop runs from its default empty initial state, so
    # accuracy is unaffected.  Set to False to disable and fall back
    # to pure post-QP bound resolution.  Only affects
    # ``active_set_method`` in ``("lpeca_init", "lpeca")``.
    lpeca_predict_bounds: bool = eqx.field(static=True, default=True)

    # Floor for the negative-multiplier drop test inside the QP
    # active-set loop.  An active inequality is only dropped when its
    # recovered multiplier is more negative than
    # ``-max(working_tol, mult_drop_floor)``.  This suppresses
    # add/drop ping-pong driven by O(eps · cond(AAᵀ)) noise in the
    # Cholesky-based multiplier recovery.  Default 1e-6.
    mult_drop_floor: float = eqx.field(static=True, default=1e-6)

    # Number of consecutive add/drop reversals on the same constraint
    # index that triggers an explicit ping-pong short-circuit in the
    # QP active-set loop.  When the threshold is hit, the QP returns
    # its current direction with ``ping_ponged=True`` and
    # ``converged=True`` instead of exhausting ``qp_max_iter``.
    #
    # Default is effectively disabled (``2**31 - 1``): historical
    # production paths relied on the v0.9.2 behaviour where a stalled
    # add/drop pair kept iterating until ``qp_max_iter`` was hit, which
    # allowed truncated QP directions to still make SQP progress.  The
    # short-circuit mechanism stays in place for opt-in use (e.g.
    # setting this to 3--8 helps on problems with confirmed degenerate
    # vertices where ``qp_max_iter`` was being exhausted regularly).
    qp_ping_pong_threshold: int = eqx.field(static=True, default=2**31 - 1)

    # Verbose output (resolved to Callable[..., None] in __check_init__)
    verbose: Callable = eqx.field(static=True, default=False)

    def __check_init__(self):
        """Post-initialization to precompute bound info and derivative callables.

        Called by equinox after __init__. Precomputes:
        - Stagnation window size and proximal mu floor.
        - Bound masks and indices for box constraints.
        - Gradient, Jacobian, and HVP contribution callables that dispatch
          once here rather than branching on every call.
        """
        # --- Stagnation window ---
        object.__setattr__(self, "_stagnation_window", max(1, self.max_steps // 10))

        # --- Proximal mu floor ---
        if self.proximal_mu_min is not None:
            object.__setattr__(self, "_proximal_mu_min", self.proximal_mu_min)
        else:
            object.__setattr__(self, "_proximal_mu_min", self.atol)

        # --- Proximal mu ceiling ---
        object.__setattr__(self, "_proximal_mu_max", self.proximal_mu_max)

        if not (0 <= self.proximal_tau < 1):
            raise ValueError(
                f"proximal_tau must be in the half-open interval [0, 1), "
                f"got {self.proximal_tau}"
            )

        # --- Preconditioner type validation ---
        if self.preconditioner_type not in ("lbfgs", "diagonal"):
            raise ValueError(
                f"preconditioner_type must be 'lbfgs' or 'diagonal', "
                f"got {self.preconditioner_type!r}"
            )
        if self.preconditioner_type == "diagonal" and not (
            self.obj_hvp_fn is not None or self.use_exact_hvp_in_qp
        ):
            raise ValueError(
                "preconditioner_type='diagonal' requires an exact HVP: "
                "set use_exact_hvp_in_qp=True or provide obj_hvp_fn"
            )

        # --- LPEC-A validation ---
        if self.active_set_method not in ("expand", "lpeca_init", "lpeca"):
            raise ValueError(
                f"active_set_method must be 'expand', 'lpeca_init', or 'lpeca', "
                f"got {self.active_set_method!r}"
            )
        if not (0 < self.lpeca_sigma < 1):
            raise ValueError(
                f"lpeca_sigma must be in the open interval (0, 1), "
                f"got {self.lpeca_sigma}"
            )

        # --- Verbose callable ---
        if self.verbose is True:
            object.__setattr__(self, "verbose", _slsqp_verbose)
        elif self.verbose is False:
            object.__setattr__(self, "verbose", _no_verbose)
        elif callable(self.verbose):  # pragma: no cover
            user_fn = self.verbose

            def _strip_fmt(**kwargs: tuple) -> None:
                user_fn(**{k: v[:2] for k, v in kwargs.items()})

            object.__setattr__(self, "verbose", _strip_fmt)
        else:  # pragma: no cover
            raise ValueError(
                f"Unrecognized `verbose` of type {type(self.verbose)}. "
                "Expected True, False, or a callable."
            )

        # --- Bound constraint info ---
        if self.bounds is not None:
            bounds_np = np.asarray(self.bounds)

            if np.any(np.isnan(bounds_np)):
                raise ValueError(
                    "bounds must not contain NaN values"
                )  # pragma: no cover

            if np.any(bounds_np[:, 0] > bounds_np[:, 1]):
                raise ValueError(  # pragma: no cover
                    "Lower bounds must be strictly less or equal to upper bounds."
                )
            if np.any(np.isinf(bounds_np[:, 0]) & (bounds_np[:, 0] > 0)) or np.any(
                np.isinf(bounds_np[:, 1]) & (bounds_np[:, 1] < 0)
            ):
                raise ValueError(  # pragma: no cover
                    "Lower bounds cannot be set to +inf and upper bounds cannot be "
                    "set to -inf."
                )

            lower_mask = np.isfinite(bounds_np[:, 0])
            upper_mask = np.isfinite(bounds_np[:, 1])

            object.__setattr__(self, "_lower_bound_mask", tuple(lower_mask.tolist()))
            object.__setattr__(self, "_upper_bound_mask", tuple(upper_mask.tolist()))
            object.__setattr__(self, "_n_lower_bounds", int(np.sum(lower_mask)))
            object.__setattr__(self, "_n_upper_bounds", int(np.sum(upper_mask)))
            object.__setattr__(
                self,
                "_lower_indices",
                tuple(int(i) for i in np.where(lower_mask)[0]),
            )
            object.__setattr__(
                self,
                "_upper_indices",
                tuple(int(i) for i in np.where(upper_mask)[0]),
            )

        # --- Gradient callable ---
        if self.obj_grad_fn is not None:
            user_grad_fn = self.obj_grad_fn

            def grad_impl(fn, y, args):
                return user_grad_fn(y, args)
        else:

            def grad_impl(fn, y, args):
                return jax.grad(lambda x: fn(x, args)[0])(y)

        object.__setattr__(self, "_grad_impl", grad_impl)

        # --- Equality Jacobian callable ---
        m_eq = self.n_eq_constraints
        if self.eq_constraint_fn is not None and m_eq > 0:
            if self.eq_jac_fn is not None:
                user_eq_jac = self.eq_jac_fn

                def eq_jac_impl(y, args):
                    return user_eq_jac(y, args)
            else:
                eq_fn = self.eq_constraint_fn

                def eq_jac_impl(y, args):
                    return jax.jacrev(args_closure(eq_fn, args))(y)
        else:

            def eq_jac_impl(y, args):
                return jnp.zeros((m_eq, y.shape[0]))

        object.__setattr__(self, "_eq_jac_impl", eq_jac_impl)

        # --- Inequality Jacobian callable ---
        m_ineq = self.n_ineq_constraints
        if self.ineq_constraint_fn is not None and m_ineq > 0:
            if self.ineq_jac_fn is not None:
                user_ineq_jac = self.ineq_jac_fn

                def ineq_jac_impl(y, args):
                    return user_ineq_jac(y, args)
            else:
                ineq_fn = self.ineq_constraint_fn

                def ineq_jac_impl(y, args):
                    return jax.jacrev(args_closure(ineq_fn, args))(y)
        else:

            def ineq_jac_impl(y, args):
                return jnp.zeros((m_ineq, y.shape[0]))

        object.__setattr__(self, "_ineq_jac_impl", ineq_jac_impl)

        # --- Equality HVP contribution callable ---
        if self.eq_constraint_fn is not None and m_eq > 0:
            if self.eq_hvp_fn is not None:
                eq_hvp_fn = self.eq_hvp_fn

                def eq_hvp_contrib(y, v, args, multipliers):
                    return multipliers @ eq_hvp_fn(y, v, args)
            else:
                eq_con_fn = self.eq_constraint_fn

                def eq_hvp_contrib(y, v, args, multipliers):
                    def weighted(x):
                        return jnp.dot(multipliers, eq_con_fn(x, args))

                    _, contrib = jax.jvp(jax.grad(weighted), (y,), (v,))
                    return contrib
        else:

            def eq_hvp_contrib(y, v, args, multipliers):
                return jnp.zeros_like(v)

        object.__setattr__(self, "_eq_hvp_contrib_impl", eq_hvp_contrib)

        # --- Inequality HVP contribution callable ---
        if self.ineq_constraint_fn is not None and m_ineq > 0:
            if self.ineq_hvp_fn is not None:
                ineq_hvp_fn = self.ineq_hvp_fn

                def ineq_hvp_contrib(y, v, args, multipliers):
                    return multipliers @ ineq_hvp_fn(y, v, args)
            else:
                ineq_con_fn = self.ineq_constraint_fn

                def ineq_hvp_contrib(y, v, args, multipliers):
                    def weighted(x):
                        return jnp.dot(multipliers, ineq_con_fn(x, args))

                    _, contrib = jax.jvp(jax.grad(weighted), (y,), (v,))
                    return contrib
        else:

            def ineq_hvp_contrib(y, v, args, multipliers):
                return jnp.zeros_like(v)

        object.__setattr__(self, "_ineq_hvp_contrib_impl", ineq_hvp_contrib)

        # --- Objective HVP callable (for Newton-CG and secant probes) ---
        if self.obj_hvp_fn is not None:
            user_obj_hvp = self.obj_hvp_fn

            def obj_hvp_impl(fn, y, v, args):
                return user_obj_hvp(y, v, args)

        elif self.use_exact_hvp_in_qp:

            def obj_hvp_impl(fn, y, v, args):
                _, hvp_val = jax.jvp(jax.grad(lambda x: fn(x, args)[0]), (y,), (v,))
                return hvp_val

        else:
            obj_hvp_impl = None

        object.__setattr__(self, "_obj_hvp_impl", obj_hvp_impl)

    def _clip_to_bounds(self, y: Vector) -> Vector:
        """Project ``y`` onto the box defined by ``self.bounds``.

        Returns ``y`` unchanged when no finite bounds exist.
        """
        if self.bounds is None:
            return y
        return jnp.clip(y, self.bounds[:, 0], self.bounds[:, 1])

    def _compute_bound_constraint_values(
        self,
        y: Vector,
    ) -> Float[Array, " m_bounds"]:
        """Compute bound constraint values c(x) where c(x) >= 0 means feasible.

        Uses precomputed ``_lower_indices`` / ``_upper_indices`` from
        ``__check_init__`` to avoid recomputing index arrays on every call.
        """
        if self.bounds is None or (
            self._n_lower_bounds == 0 and self._n_upper_bounds == 0
        ):
            return jnp.zeros((0,))

        lower_idx = np.array(self._lower_indices)
        upper_idx = np.array(self._upper_indices)

        lower_vals = (
            y[lower_idx] - self.bounds[lower_idx, 0]
            if len(lower_idx) > 0
            else jnp.zeros((0,))
        )
        upper_vals = (
            self.bounds[upper_idx, 1] - y[upper_idx]
            if len(upper_idx) > 0
            else jnp.zeros((0,))
        )

        return jnp.concatenate([lower_vals, upper_vals])

    def _build_bound_jacobian(
        self,
        n: int,
    ) -> Float[Array, "m_bounds n"]:
        """Build the constant Jacobian matrix for bound constraints.

        Uses precomputed ``_lower_indices`` / ``_upper_indices``.
        Only called once during ``init``; the result is stored in state.
        """
        if self.bounds is None or (
            self._n_lower_bounds == 0 and self._n_upper_bounds == 0
        ):
            return jnp.zeros((0, n))

        lower_idx = np.array(self._lower_indices)
        upper_idx = np.array(self._upper_indices)
        identity = jnp.eye(n)

        J_lower = identity[lower_idx] if len(lower_idx) > 0 else jnp.zeros((0, n))
        J_upper = -identity[upper_idx] if len(upper_idx) > 0 else jnp.zeros((0, n))

        return jnp.concatenate([J_lower, J_upper], axis=0)

    def _recover_bound_multipliers(
        self,
        y_new: Vector,
        grad_new: Vector,
        eq_jac_new: Float[Array, "m_eq n"],
        ineq_jac_new: Float[Array, "m_ineq n"],
        mult_eq: Float[Array, " m_eq"],
        mult_ineq_general: Float[Array, " m_general"],
    ) -> tuple[Float[Array, " n_lower"], Float[Array, " n_upper"]]:
        """Recover bound multipliers from the NLP reduced gradient at x_{k+1}.

        Reads off the bound multiplier as the residual of the *partial*
        Lagrangian gradient (no bound contribution) at the post-line-search
        iterate, restricted to the variables that are at a bound at
        ``y_new``.  By construction, splicing these multipliers back into
        the full Lagrangian gradient zeros the bound-active components of
        ``∇L`` exactly.

        See ``compute_partial_lagrangian_gradient`` for the partial
        Lagrangian gradient definition.  The sign convention follows
        ``_build_bound_jacobian`` (``+I`` rows for lower bounds, ``−I``
        rows for upper bounds), so:

            μ_lower[i] = +partial_grad_L[lower_idx[i]]
            μ_upper[j] = −partial_grad_L[upper_idx[j]]

        clamped to ``≥ 0`` to enforce dual feasibility.  A small negative
        recovered value at an "active" bound means our active-set guess
        at ``y_new`` is off by one variable; clamping folds the
        discrepancy back into ``||∇L||`` instead of injecting a bogus
        negative multiplier.

        The active-bound test uses an absolute tolerance of ``1e-12``
        plus a per-variable relative safety term ``eps · (1 + |y_new|)``.
        Variables clipped to a bound by ``_clip_to_bounds`` satisfy the
        test exactly; the relative term only matters for variables the
        line search drove to within floating-point precision of a bound
        without explicit clipping.

        Args:
            y_new: Post-line-search iterate (already clipped to bounds).
            grad_new: Objective gradient at ``y_new``.
            eq_jac_new: Equality-constraint Jacobian at ``y_new``.
            ineq_jac_new: Full inequality Jacobian at ``y_new``,
                with bound rows.  Only the general portion (first
                ``self.n_ineq_constraints`` rows) is used.
            mult_eq: Equality multipliers (typically the blended
                multipliers from the current step).
            mult_ineq_general: General-inequality multipliers (no
                bound block); typically ``blended_mult_ineq[:m_general]``.

        Returns:
            ``(mu_lower_corr, mu_upper_corr)`` of shapes
            ``(n_lower,)`` and ``(n_upper,)`` respectively.  Empty
            arrays when the corresponding bound side has no finite
            entries (or when ``self.bounds is None``).
        """
        n_lower = self._n_lower_bounds
        n_upper = self._n_upper_bounds
        m_general = self.n_ineq_constraints

        if self.bounds is None or (n_lower == 0 and n_upper == 0):
            return jnp.zeros((0,), dtype=y_new.dtype), jnp.zeros(
                (0,), dtype=y_new.dtype
            )

        gen_jac_new = (
            ineq_jac_new[:m_general]
            if m_general > 0
            else jnp.zeros((0, y_new.shape[0]), dtype=y_new.dtype)
        )
        partial_grad_L = compute_partial_lagrangian_gradient(
            grad_new,
            eq_jac_new,
            mult_eq,
            gen_jac_new,
            mult_ineq_general,
        )

        # Per-variable active-bound tolerance: absolute floor of 1e-12
        # (matches ``bound_fix_tol`` in the QP bound-fixing loop) plus a
        # relative ``eps * (1 + |y_new|)`` safety term so the test still
        # fires for variables whose magnitude pushes the absolute floor
        # below the local floating-point spacing.  Variables clipped to
        # a bound by ``_clip_to_bounds`` satisfy the test by exact
        # equality and the relative term is irrelevant for them.
        eps = jnp.asarray(jnp.finfo(y_new.dtype).eps, dtype=y_new.dtype)
        bound_tol = jnp.asarray(1e-12, dtype=y_new.dtype) + eps * (1.0 + jnp.abs(y_new))

        if n_lower > 0:
            lower_idx = jnp.asarray(self._lower_indices, dtype=jnp.int32)
            lb_at_idx = self.bounds[lower_idx, 0]
            at_lower = (y_new[lower_idx] - lb_at_idx) <= bound_tol[lower_idx]
            mu_lower_corr = jnp.maximum(
                jnp.where(at_lower, partial_grad_L[lower_idx], 0.0),
                0.0,
            )
        else:
            mu_lower_corr = jnp.zeros((0,), dtype=y_new.dtype)

        if n_upper > 0:
            upper_idx = jnp.asarray(self._upper_indices, dtype=jnp.int32)
            ub_at_idx = self.bounds[upper_idx, 1]
            at_upper = (ub_at_idx - y_new[upper_idx]) <= bound_tol[upper_idx]
            mu_upper_corr = jnp.maximum(
                jnp.where(at_upper, -partial_grad_L[upper_idx], 0.0),
                0.0,
            )
        else:
            mu_upper_corr = jnp.zeros((0,), dtype=y_new.dtype)

        return mu_lower_corr, mu_upper_corr

    def _build_lagrangian_hvp(
        self,
        fn: Callable,
        y: Vector,
        args: Any,
        state: "SLSQPState",
    ) -> Callable[[Vector], Vector]:
        """Build the Lagrangian HVP for the QP subproblem.

        In default mode, returns a closure v -> B_k @ v using the L-BFGS
        compact representation (frozen, constant Hessian approximation).

        In Newton-CG mode (``use_exact_hvp_in_qp=True``), returns the
        exact Lagrangian HVP at the current iterate, computed via AD.
        This costs one forward-over-reverse pass per CG step but can
        dramatically improve convergence on ill-conditioned problems.
        """
        if self.use_exact_hvp_in_qp and self._obj_hvp_impl is not None:
            return self._build_exact_lagrangian_hvp(
                fn,
                y,
                args,
                state.multipliers_eq,
                state.multipliers_ineq,
            )

        lbfgs_history = state.lbfgs_history

        def lbfgs_lagrangian_hvp(v: Vector) -> Vector:
            return lbfgs_hvp(lbfgs_history, v)

        return lbfgs_lagrangian_hvp

    def _build_preconditioner(
        self,
        state: "SLSQPState",
        proximal_mu: Scalar | float = 0.0,
        lagrangian_hvp_fn: Callable[[Vector], Vector] | None = None,
    ) -> Callable[[Vector], Vector] | None:
        """Build the preconditioner for the PCG inner solver.

        Two preconditioner types are supported:

        **L-BFGS** (``preconditioner_type="lbfgs"``, default):
        Uses the L-BFGS inverse Hessian (two-loop recursion).

        **Diagonal** (``preconditioner_type="diagonal"``):
        Estimates diag(H_L) via stochastic Rademacher probing of the
        exact Lagrangian HVP, then uses M^{-1} = diag(1/d_hat).  This
        is independent of L-BFGS history quality and immune to the
        reset death spiral on ill-conditioned problems.  Requires
        ``lagrangian_hvp_fn`` (the exact Lagrangian HVP at the current
        iterate).

        For both types, when equality constraints are present *and*
        sSQP proximal stabilization is active (``proximal_tau > 0``),
        the QP system matrix is ``B_tilde = B + (1/mu) A_eq^T A_eq``.
        The Woodbury identity is used to build ``B_tilde^{-1}``::

            (B + (1/mu) A^T A)^{-1}
              = B^{-1} - B^{-1} A^T (mu I + A B^{-1} A^T)^{-1} A B^{-1}

        The inner matrix ``(mu I + A B^{-1} A^T)`` is only m_eq x m_eq
        and is factored once per QP solve.

        Args:
            state: Current solver state.
            proximal_mu: Adaptive proximal parameter (mu).
            lagrangian_hvp_fn: Exact Lagrangian HVP at the current
                iterate.  Required when ``preconditioner_type="diagonal"``.

        Returns ``None`` when preconditioning is disabled.
        """
        if not self.use_preconditioner:
            return None

        if self.preconditioner_type == "diagonal":
            return self._build_diagonal_preconditioner(
                state, proximal_mu, lagrangian_hvp_fn
            )

        return self._build_lbfgs_preconditioner(state, proximal_mu)

    def _build_lbfgs_preconditioner(
        self,
        state: "SLSQPState",
        proximal_mu: Scalar | float = 0.0,
    ) -> Callable[[Vector], Vector]:
        """L-BFGS inverse Hessian preconditioner (two-loop recursion)."""
        lbfgs_history = state.lbfgs_history

        if self.n_eq_constraints > 0 and self.proximal_tau > 0:
            A_eq = state.eq_jac
            mu = proximal_mu
            m_eq = A_eq.shape[0]

            Hinv_AT = jax.vmap(
                lambda a: lbfgs_inverse_hvp(lbfgs_history, a),
            )(A_eq)  # (m_eq, n): rows are B^{-1} @ a_i

            gram = Hinv_AT @ A_eq.T  # (m_eq, m_eq): A B^{-1} A^T
            inner = mu * jnp.eye(m_eq) + gram
            inner_factor = jnp.linalg.cholesky(inner + 1e-10 * jnp.eye(m_eq))

            def preconditioner(v: Vector) -> Vector:
                Hinv_v = lbfgs_inverse_hvp(lbfgs_history, v)
                A_Hinv_v = A_eq @ Hinv_v  # (m_eq,)
                w = jax.scipy.linalg.cho_solve((inner_factor, True), A_Hinv_v)
                correction = Hinv_AT.T @ w  # (n,): B^{-1} A^T w
                return Hinv_v - correction

            return preconditioner
        else:

            def preconditioner(v: Vector) -> Vector:
                return lbfgs_inverse_hvp(lbfgs_history, v)

            return preconditioner

    def _build_diagonal_preconditioner(
        self,
        state: "SLSQPState",
        proximal_mu: Scalar | float = 0.0,
        lagrangian_hvp_fn: Callable[[Vector], Vector] | None = None,
    ) -> Callable[[Vector], Vector]:
        """Stochastic diagonal Hessian preconditioner (Bekas et al., 2007).

        Estimates diag(H_L) by probing the exact Lagrangian HVP with
        Rademacher random vectors, then uses M^{-1} = diag(1/d_hat).
        The estimate is recomputed each SLSQP step using a deterministic
        PRNG key derived from the step count.
        """
        assert lagrangian_hvp_fn is not None, (
            "diagonal preconditioner requires an exact Lagrangian HVP"
        )
        n = state.grad.shape[0]
        key = jax.random.fold_in(jax.random.PRNGKey(42), state.step_count)
        diag_est = estimate_hessian_diagonal(
            lagrangian_hvp_fn, n, key, n_probes=self.diagonal_n_probes
        )
        # Safeguard: clamp small/negative entries to a positive floor so
        # the preconditioner is always positive definite.  Use the median
        # absolute value as the scale reference.
        abs_diag = jnp.abs(diag_est)
        floor = jnp.maximum(1e-8, 1e-6 * jnp.median(abs_diag))
        diag_safe = jnp.maximum(abs_diag, floor)
        inv_diag = 1.0 / diag_safe

        if self.n_eq_constraints > 0 and self.proximal_tau > 0:
            A_eq = state.eq_jac
            mu = proximal_mu
            m_eq = A_eq.shape[0]

            # Woodbury: (D + (1/mu) A^T A)^{-1}
            #   = D^{-1} - D^{-1} A^T (mu I + A D^{-1} A^T)^{-1} A D^{-1}
            Dinv_AT = (A_eq * inv_diag[None, :]).T  # (n, m_eq)
            gram = A_eq @ Dinv_AT  # (m_eq, m_eq): A D^{-1} A^T
            inner = mu * jnp.eye(m_eq) + gram
            inner_factor = jnp.linalg.cholesky(inner + 1e-10 * jnp.eye(m_eq))

            def preconditioner(v: Vector) -> Vector:
                Dinv_v = inv_diag * v
                A_Dinv_v = A_eq @ Dinv_v  # (m_eq,)
                w = jax.scipy.linalg.cho_solve((inner_factor, True), A_Dinv_v)
                correction = Dinv_AT @ w  # (n,)
                return Dinv_v - correction

            return preconditioner
        else:

            def preconditioner(v: Vector) -> Vector:
                return inv_diag * v

            return preconditioner

    def _build_exact_lagrangian_hvp(
        self,
        fn: Callable,
        y: Vector,
        args: Any,
        multipliers_eq: Float[Array, " m_eq"],
        multipliers_ineq: Float[Array, " m_ineq"],
    ) -> Callable[[Vector], Vector]:
        """Build exact Lagrangian HVP using precomputed contribution callables.

        Composes H_L v = H_f v - sum lambda_eq_i H_{c_eq_i} v
                                - sum lambda_ineq_j H_{c_ineq_j} v.

        Called once per main iteration to probe the exact Hessian along the
        step direction, producing a high-quality secant pair for L-BFGS.
        Also used in Newton-CG mode for the QP inner loop.  The dispatch
        to user-supplied vs AD-computed HVPs is resolved at construction
        time in ``__check_init__``.
        """
        m_ineq = self.n_ineq_constraints
        obj_hvp_impl = cast(Callable, self._obj_hvp_impl)
        eq_hvp_contrib = self._eq_hvp_contrib_impl
        ineq_hvp_contrib = self._ineq_hvp_contrib_impl

        def lagrangian_hvp(v: Vector) -> Vector:
            obj_val = obj_hvp_impl(fn, y, v, args)
            eq_val = eq_hvp_contrib(y, v, args, multipliers_eq)
            ineq_val = ineq_hvp_contrib(y, v, args, multipliers_ineq[:m_ineq])
            return obj_val - eq_val - ineq_val

        return lagrangian_hvp

    def init(
        self,
        fn: Callable,
        y: Vector,
        args: Any,
        options: dict[str, Any],
        f_struct: Any,
        aux_struct: Any,
        tags: frozenset[object],
    ) -> SLSQPState:
        """Initialize the SLSQP solver state.

        Computes initial function value, gradient, constraint values,
        and constraint Jacobians. Initializes the L-BFGS history buffer.

        Args:
            fn: Objective function with signature fn(y, args) -> (f_val, aux).
            y: Initial parameter values.
            args: Additional arguments passed to fn.
            options: Runtime options dictionary.
            f_struct: Structure of function output (for type inference).
            aux_struct: Structure of auxiliary output.
            tags: Lineax tags for the problem.

        Returns:
            Initial SLSQPState with all fields populated.
        """
        n = y.shape[0]
        y = self._clip_to_bounds(y)
        m_eq = self.n_eq_constraints
        m_ineq_general = self.n_ineq_constraints
        m_bounds = self._n_lower_bounds + self._n_upper_bounds
        m_ineq_total = m_ineq_general + m_bounds

        # Evaluate objective.  Coerce to a true 0-d scalar in case the user
        # function returns e.g. shape (1,); otherwise the non-scalar shape
        # propagates into ``terminate`` and trips the ``jax.lax.cond``
        # scalar-predicate check there.
        f_val, _aux = fn(y, args)
        f_val = to_scalar(f_val)

        # Compute gradient (precomputed callable)
        grad = self._grad_impl(fn, y, args)

        # Evaluate equality constraint values
        if self.eq_constraint_fn is not None and m_eq > 0:
            eq_val = self.eq_constraint_fn(y, args)
        else:
            eq_val = jnp.zeros((m_eq,))

        # Evaluate general inequality constraint values
        if self.ineq_constraint_fn is not None and m_ineq_general > 0:
            ineq_val_general = self.ineq_constraint_fn(y, args)
        else:
            ineq_val_general = jnp.zeros((m_ineq_general,))

        # Evaluate bound constraint values
        bound_vals = self._compute_bound_constraint_values(y)

        # Concatenate general inequality and bound constraints
        ineq_val = jnp.concatenate([ineq_val_general, bound_vals])

        # Compute constraint Jacobians (precomputed callables)
        eq_jac = self._eq_jac_impl(y, args)
        ineq_jac_general = self._ineq_jac_impl(y, args)

        # Build bound Jacobian (constant, computed once here and stored in state)
        bound_jac = self._build_bound_jacobian(n)
        ineq_jac = jnp.concatenate([ineq_jac_general, bound_jac], axis=0)

        # Initialize L-BFGS history (empty, gamma=1 -> B_0 = I)
        lbfgs_history = lbfgs_init(n, self.lbfgs_memory)

        # Initialize equality multipliers via least-squares:
        #   min_lambda ||grad_f - J_eq^T lambda||^2
        # This avoids the pathological case where zero multipliers cause
        # premature termination when the initial point satisfies constraints.
        if m_eq > 0:
            multipliers_eq, _, _, _ = jnp.linalg.lstsq(eq_jac.T, grad)
        else:
            multipliers_eq = jnp.zeros((m_eq,))

        # Inequality multipliers start at zero (we don't know the active set yet)
        multipliers_ineq = jnp.zeros((m_ineq_total,))

        # Compute initial Lagrangian gradient with the estimated multipliers
        prev_grad_lagrangian = compute_lagrangian_gradient(
            grad,
            eq_jac,
            ineq_jac,
            multipliers_eq,
            multipliers_ineq,
        )

        # Initial merit penalty
        merit_penalty = jnp.array(1.0)

        # Initial merit for stagnation tracking
        initial_merit = compute_merit(f_val, eq_val, ineq_val, merit_penalty)

        return SLSQPState(  # ty: ignore[invalid-return-type]  # equinox @dataclass_transform
            step_count=jnp.array(0),
            f_val=f_val,
            grad=grad,
            eq_val=eq_val,
            ineq_val=ineq_val,
            eq_jac=eq_jac,
            ineq_jac=ineq_jac,
            lbfgs_history=lbfgs_history,
            multipliers_eq=multipliers_eq,
            multipliers_ineq=multipliers_ineq,
            prev_grad_lagrangian=prev_grad_lagrangian,
            grad_lagrangian=prev_grad_lagrangian,
            merit_penalty=merit_penalty,
            bound_jac=bound_jac,
            qp_iterations=jnp.array(0),
            qp_converged=jnp.array(True),
            prev_active_set=jnp.zeros((m_ineq_total,), dtype=bool),
            consecutive_qp_failures=jnp.array(0),
            consecutive_ls_failures=jnp.array(0),
            consecutive_zero_steps=jnp.array(0),
            qp_optimal=jnp.array(False),
            best_merit=initial_merit,
            steps_without_improvement=jnp.array(0),
            stagnation=jnp.array(False),
            last_alpha=jnp.array(1.0),
            last_projected_grad_norm=jnp.asarray(jnp.inf),
            ls_success=jnp.array(True),
            ls_fatal=jnp.array(False),
            qp_fatal=jnp.array(False),
            termination_code=RESULTS.successful,
            best_x=y,
            blowup_count=jnp.array(0),
            diverging=jnp.array(False),
            diagnostics=_init_diagnostics(),
        )

    def step(
        self,
        fn: Callable,
        y: Vector,
        args: Any,
        options: dict[str, Any],
        state: SLSQPState,
        tags: frozenset[object],
    ) -> tuple[Vector, SLSQPState, Any]:
        """Perform one SLSQP iteration.

        This method:
        1. Builds the Lagrangian HVP for the QP subproblem (L-BFGS or
           exact AD in Newton-CG mode).
        2. Solves the QP subproblem via projected CG to find direction d.
        3. Performs line search with L1 merit function to find step size.
        4. Updates x_{k+1} = x_k + alpha * d.
        5. Re-evaluates objective, gradient, constraints, and Jacobians.
        6. Updates L-BFGS history with secant pair (exact HVP probe or
           gradient differences).

        Args:
            fn: Objective function.
            y: Current parameter values.
            args: Additional arguments.
            options: Runtime options.
            state: Current solver state.
            tags: Lineax tags.

        Returns:
            Tuple of (new_y, new_state, aux).
        """
        # Ensure y is within bounds (matters for the first iteration when
        # the user-supplied y0 may violate bounds).
        y = self._clip_to_bounds(y)

        # Step 1: Build the Lagrangian HVP for the QP subproblem
        hvp_fn = self._build_lagrangian_hvp(fn, y, args, state)

        # Step 2: Solve QP subproblem for search direction
        qp_result = self._solve_qp_subproblem(state, hvp_fn, y)

        # Projected steepest descent fallback: project -grad_f onto
        # null(J_eq) so that the fallback direction does not violate
        # equality constraints.  Without projection, sum(d) can be O(n)
        # for a simplex constraint, making the L1 merit DD massively
        # positive and preventing the line search from finding a step.
        neg_grad = -state.grad
        if self.n_eq_constraints > 0:
            J = state.eq_jac  # (m_eq, n)
            JJT = J @ J.T
            m_eq = self.n_eq_constraints
            JJT_reg = JJT + 1e-10 * jnp.eye(m_eq)
            Jv = J @ neg_grad
            w = jnp.linalg.solve(JJT_reg, Jv)
            fallback_direction = neg_grad - J.T @ w
        else:
            fallback_direction = neg_grad

        direction = jnp.where(
            qp_result.converged, qp_result.direction, fallback_direction
        )
        zero_direction = jnp.linalg.norm(direction) < 1e-30
        grad_nonzero = jnp.linalg.norm(state.grad) > self.atol
        # Only fall back to steepest descent when the QP failed to converge.
        # When the QP converges but returns a zero direction (e.g. because
        # bound clipping zeroed it out), the zero direction is correct —
        # the iterate is at a bound-constrained optimum and the convergence
        # check will detect it via the bound multipliers.
        direction = jnp.where(
            zero_direction & grad_nonzero & ~qp_result.converged,
            fallback_direction,
            direction,
        )

        # Track whether the QP direction contained any non-finite values.
        # We replaced it with the steepest-descent fallback above only when
        # ``qp_result.converged`` is False, so a NaN while ``converged=True``
        # should still be logged as a diagnostic failure.
        direction_nonfinite = ~jnp.isfinite(qp_result.direction).all()

        # Defensively pin ``direction`` to its declared shape (n,).  If a
        # rank-mismatch leak slipped past the QP / bound-fix machinery
        # (e.g. broadcasting from a (1,)-shaped predicate into
        # ``jnp.where(use_new, d_new, direction)``), ``direction`` could
        # arrive here with a phantom leading axis, which would propagate
        # into ``d_norm``, ``is_zero_step``, the line-search call (where
        # ``x + alpha * direction`` would explode the user's objective
        # with a (1, n) input), and ultimately into the
        # ``consecutive_zero_steps`` / ``qp_optimal`` state fields,
        # causing the next while_loop iteration to fail the tree-shape
        # check.  Reshaping here surfaces any such leak as a clear
        # shape error at this call site instead.
        n_vars = state.grad.shape[0]
        direction = jnp.reshape(direction, (n_vars,))

        # Zero-step convergence detection (pre–line-search):
        # catches inner solvers like CG that return d ≈ 0.
        d_norm = jnp.reshape(jnp.linalg.norm(direction), ())
        is_zero_step_pre = jnp.reshape((d_norm < self.atol) & qp_result.converged, ())

        # Step 3: Update penalty parameter — only trust multipliers
        # from a converged QP to avoid permanently inflating rho.
        new_penalty = update_penalty_parameter(
            state.merit_penalty,
            qp_result.multipliers_eq,
            qp_result.multipliers_ineq,
        )
        merit_penalty = jnp.where(qp_result.converged, new_penalty, state.merit_penalty)

        # Step 4: Line search with merit function
        ls_result = backtracking_line_search(
            fn=fn,
            eq_constraint_fn=self.eq_constraint_fn,
            ineq_constraint_fn=self.ineq_constraint_fn,
            x=y,
            direction=direction,
            args=args,
            f_val=state.f_val,
            eq_val=state.eq_val,
            ineq_val=state.ineq_val,
            penalty=merit_penalty,
            grad=state.grad,
            c1=self.armijo_c1,
            max_iter=self.line_search_max_steps,
            bounds=self.bounds,
            lower_bound_mask=self._lower_bound_mask,
            upper_bound_mask=self._upper_bound_mask,
            eq_jac=state.eq_jac if self.n_eq_constraints > 0 else None,
            ineq_jac=state.ineq_jac[: self.n_ineq_constraints]
            if self.n_ineq_constraints > 0
            else None,
        )

        alpha = ls_result.alpha
        y_new = self._clip_to_bounds(y + alpha * direction)
        f_val_new = ls_result.f_val
        eq_val_new = ls_result.eq_val
        ineq_val_new = ls_result.ineq_val  # Includes bounds from line search

        # Get auxiliary output from function evaluation
        _, aux = fn(y_new, args)

        # Step 5: Compute gradient and Jacobians at new point
        grad_new = self._grad_impl(fn, y_new, args)
        eq_jac_new = self._eq_jac_impl(y_new, args)

        # General inequality Jacobian + constant bound Jacobian from state
        ineq_jac_general_new = self._ineq_jac_impl(y_new, args)
        ineq_jac_new = jnp.concatenate([ineq_jac_general_new, state.bound_jac], axis=0)

        # Alpha-scale multipliers: QP multipliers are for the full step;
        # blend with previous multipliers proportional to the accepted step.
        blended_mult_eq = state.multipliers_eq + alpha * (
            qp_result.multipliers_eq - state.multipliers_eq
        )
        blended_mult_ineq = state.multipliers_ineq + alpha * (
            qp_result.multipliers_ineq - state.multipliers_ineq
        )

        # NLP-level bound multiplier recovery at x_{k+1}.  The QP-level
        # bound multipliers in ``blended_mult_ineq[m_general:]`` were
        # recovered from ``B d + g − A^T λ`` at ``x_k`` using the L-BFGS
        # HVP and the bound-fixing loop's ``direction``-based active set;
        # they inherit the L-BFGS / iterate / regularised-projection
        # error budget which can pin ``||∇L|| / |L|`` above ``rtol`` on
        # bound-heavy problems.  Recompute them from the *partial*
        # Lagrangian gradient at ``x_{k+1}`` (computed with the same
        # blended ``μ_eq`` / ``μ_gen`` we are about to use) and splice
        # back into ``blended_mult_ineq`` in place.  By construction
        # ``∇L`` at the active bound indices then cancels exactly.
        #
        # The bound block of the L-BFGS secant pair
        #     y_k = ∇L(x_{k+1}, λ) − ∇L(x_k, λ)
        # is invariant under this splice because the bound Jacobian
        # ``state.bound_jac`` is constant: ``[J_b − J_b]^T μ_b ≡ 0``
        # regardless of ``μ_b``, as long as the same multiplier vector
        # is applied at both endpoints — which it is below (a single
        # ``blended_mult_ineq`` feeds both ``grad_lagrangian_new`` and
        # ``grad_lagrangian_old``).  This is consistent with L-BFGS-B's
        # use of ``y_k = ∇f(x_{k+1}) − ∇f(x_k)`` (i.e. ``μ_b = 0`` at
        # both endpoints; Byrd, Lu, Nocedal, Zhu, SIAM J. Sci. Comput.
        # 16(5), 1995).
        m_ineq_general_static = self.n_ineq_constraints
        m_bounds_static = self._n_lower_bounds + self._n_upper_bounds
        n_lower_static = self._n_lower_bounds
        if m_bounds_static > 0:
            mult_ineq_general_blended = (
                blended_mult_ineq[:m_ineq_general_static]
                if m_ineq_general_static > 0
                else jnp.zeros((0,), dtype=blended_mult_ineq.dtype)
            )
            mu_lower_corr, mu_upper_corr = self._recover_bound_multipliers(
                y_new=y_new,
                grad_new=grad_new,
                eq_jac_new=eq_jac_new,
                ineq_jac_new=ineq_jac_new,
                mult_eq=blended_mult_eq,
                mult_ineq_general=mult_ineq_general_blended,
            )
            if n_lower_static > 0:
                blended_mult_ineq = blended_mult_ineq.at[
                    m_ineq_general_static : m_ineq_general_static + n_lower_static
                ].set(mu_lower_corr)
            if self._n_upper_bounds > 0:
                blended_mult_ineq = blended_mult_ineq.at[
                    m_ineq_general_static + n_lower_static :
                ].set(mu_upper_corr)
        else:
            mu_lower_corr = jnp.zeros((0,), dtype=blended_mult_ineq.dtype)
            mu_upper_corr = jnp.zeros((0,), dtype=blended_mult_ineq.dtype)

        # Step 6: Update L-BFGS history
        s = y_new - y  # Step taken

        # Compute gradient of Lagrangian at new point using blended multipliers
        # (with the NLP-recovered bound block spliced in above).
        grad_lagrangian_new = compute_lagrangian_gradient(
            grad_new,
            eq_jac_new,
            ineq_jac_new,
            blended_mult_eq,
            blended_mult_ineq,
        )

        if self._obj_hvp_impl is not None:
            exact_hvp_fn = self._build_exact_lagrangian_hvp(
                fn,
                y,
                args,
                blended_mult_eq,
                blended_mult_ineq,
            )
            y_for_lbfgs = exact_hvp_fn(s)
        else:
            # Recompute grad_L at old point x_k with NEW blended multipliers.
            # The secant condition (Nocedal & Wright §18.3) requires both
            # Lagrangian gradients to use the same multipliers:
            #   y_k = grad_L(x_{k+1}, lambda_{k+1}) - grad_L(x_k, lambda_{k+1})
            grad_lagrangian_old = compute_lagrangian_gradient(
                state.grad,
                state.eq_jac,
                state.ineq_jac,
                blended_mult_eq,
                blended_mult_ineq,
            )
            y_for_lbfgs = grad_lagrangian_new - grad_lagrangian_old

        new_lbfgs_history = lbfgs_append(
            state.lbfgs_history,
            s,
            y_for_lbfgs,
            damping_threshold=self.damping_threshold,
            diag_floor=self.lbfgs_diag_floor,
            diag_ceil=self.lbfgs_diag_ceil,
        )

        # VARCHEN-style conditioning control: soft reset (keep most recent
        # pair) when the inverse Hessian condition number exceeds kappa_max.
        # This is less aggressive than the old diagonal/identity resets.
        kappa_est = new_lbfgs_history.eig_upper / jnp.maximum(
            new_lbfgs_history.eig_lower, 1e-30
        )
        new_lbfgs_history = jax.lax.cond(
            (new_lbfgs_history.count > 1) & (kappa_est > 1e6),
            lbfgs_soft_reset,
            lambda h: h,
            new_lbfgs_history,
        )

        # QP-failure recovery (5a + 5b).
        #
        # 5a: distinguish "real" QP failure (non-finite direction —
        # ``qp_result.converged=False`` *not* caused by hitting
        # ``qp_max_iter``) from a benign budget exhaustion (finite
        # direction returned, but the active-set loop hit
        # ``qp_max_iter``).  ``qp_solver._solve_qp_*`` forces
        # ``converged=False`` whenever ``reached_max_iter`` is true so
        # the outer driver does not silently trust the EXPAND-relaxed
        # tolerance, but for the L-BFGS reset chain we want to treat
        # budget exhaustion as a *successful* outcome: the inner solver
        # spent its budget, returned a usable Newton direction, and the
        # merit/line search has already vetted it.  Counting this as a
        # failure burns through history we want to keep.
        #
        # 5b: even on a *real* failure, only soft-reset on the *first*
        # failure of a streak.  The previous chain soft-reset on every
        # increment of the counter and then identity-reset at the
        # patience threshold, which double-discards the buffer (3x soft
        # reset + 1x identity reset by the time the patience fires).
        qp_real_failure = ~qp_result.converged & ~qp_result.reached_max_iter
        new_consecutive_qp_failures = jnp.where(
            qp_real_failure,
            state.consecutive_qp_failures + 1,
            jnp.array(0),
        )
        new_lbfgs_history = jax.lax.cond(
            qp_real_failure & (new_consecutive_qp_failures == 1),
            lbfgs_soft_reset,
            lambda h: h,
            new_lbfgs_history,
        )
        new_lbfgs_history = jax.lax.cond(
            new_consecutive_qp_failures >= self.qp_failure_patience,
            lbfgs_identity_reset,
            lambda h: h,
            new_lbfgs_history,
        )

        # Line-search failure recovery (5b symmetric): soft reset only
        # on the *first* failure of a streak; identity escalation at
        # patience threshold.
        ls_failed = ~ls_result.success
        new_consecutive_ls_failures = jnp.where(
            ls_failed,
            state.consecutive_ls_failures + 1,
            jnp.array(0),
        )
        new_lbfgs_history = jax.lax.cond(
            ls_failed & (new_consecutive_ls_failures == 1),
            lbfgs_soft_reset,
            lambda h: h,
            new_lbfgs_history,
        )
        new_lbfgs_history = jax.lax.cond(
            new_consecutive_ls_failures >= self.ls_failure_patience,
            lbfgs_identity_reset,
            lambda h: h,
            new_lbfgs_history,
        )

        # Zero-step convergence detection (post–line-search):
        # Full KKT solvers (MINRES-QLP) return ||d|| > 0 even when the
        # projected gradient is negligible, because the coupled (d, λ)
        # system always has a non-trivial solution.  The line search then
        # accepts only a tiny α, so the effective step α·||d|| is
        # negligible.  Detect this as a zero step so that MINRES-QLP
        # benefits from zero_step_patience just like null-space CG.
        #
        # Critically, this must be gated on ``ls_result.success``: a
        # line search that exhausted its budget without satisfying the
        # Armijo / merit-descent condition also returns a tiny alpha,
        # but that is a *failure* rather than the KKT-optimal d ≈ 0
        # signal we want to accept as convergence.
        is_zero_step_post = jnp.reshape(
            (alpha * d_norm < self.atol) & qp_result.converged & ls_result.success,
            (),
        )
        is_zero_step = jnp.reshape(is_zero_step_pre | is_zero_step_post, ())
        new_consecutive_zero_steps = jnp.reshape(
            jnp.where(is_zero_step, state.consecutive_zero_steps + 1, jnp.array(0)),
            (),
        )
        new_qp_optimal = jnp.reshape(
            new_consecutive_zero_steps >= self.zero_step_patience, ()
        )

        # Fatal line-search failure: even the identity-reset escalation
        # (triggered at ls_failure_patience) could not produce a descent
        # direction.  After 2 * ls_failure_patience consecutive LS
        # failures we conclude that the problem is either infeasible or
        # catastrophically ill-conditioned and terminate with
        # ``RESULTS.line_search_failure`` rather than silently converging.
        ls_fatal = new_consecutive_ls_failures >= 2 * self.ls_failure_patience

        # Fatal QP-subproblem failure: mirror of ``ls_fatal`` for the
        # QP solver.  The first ``qp_failure_patience`` failures soft-
        # then-identity-reset the L-BFGS history; if the QP still
        # cannot produce a usable direction after a further
        # ``qp_failure_patience`` failures, terminate with
        # ``RESULTS.qp_subproblem_failure``.
        qp_fatal = new_consecutive_qp_failures >= 2 * self.qp_failure_patience

        # Merit-based stagnation detection: track consecutive steps
        # without sufficient improvement in the L1 merit function.
        merit_new = compute_merit(f_val_new, eq_val_new, ineq_val_new, merit_penalty)
        merit_threshold = self.stagnation_tol * jnp.maximum(
            jnp.abs(state.best_merit), 1.0
        )
        improved = merit_new < state.best_merit - merit_threshold
        new_best_merit = jnp.where(improved, merit_new, state.best_merit)
        new_best_x = jnp.where(improved, y_new, state.best_x)
        new_steps_without = jnp.where(
            improved, jnp.array(0), state.steps_without_improvement + 1
        )
        patience = self._stagnation_window
        merit_stagnation = (state.step_count >= patience) & (
            new_steps_without >= patience
        )

        # Best-iterate divergence rollback (HR-style outer guardrail).
        # Trigger when the merit grows by more than ``divergence_factor``
        # times the best-seen merit (or returns NaN/Inf) for
        # ``divergence_patience`` steps in a row.  We use the *new* best
        # merit as the comparison baseline so the trigger does not fire
        # on the same step that just set a new best.  The
        # ``~jnp.isfinite`` clause folds NaN/Inf merit (which would
        # otherwise pass through ``jnp.where`` silently) into the
        # blowup count.  When the patience runs out, the returned
        # iterate is replaced with ``best_x`` and ``diverging`` is
        # latched so ``terminate()`` routes to ``nonlinear_divergence``.
        blowup_threshold = self.divergence_factor * jnp.maximum(
            jnp.abs(new_best_merit), 1.0
        )
        merit_finite = jnp.isfinite(merit_new)
        blowup_now = ((merit_new - new_best_merit) > blowup_threshold) | ~merit_finite
        new_blowup_count = jnp.where(blowup_now, state.blowup_count + 1, jnp.array(0))
        diverging_now = jnp.reshape(new_blowup_count >= self.divergence_patience, ())
        # Roll back to the best iterate when divergence trips.  The
        # remainder of ``new_state`` still reflects the *attempted* step
        # (L-BFGS history, multipliers, gradients), which is fine
        # because the driver loop terminates immediately after; nothing
        # else consumes that state.
        y_returned = jnp.where(diverging_now, new_best_x, y_new)

        # Update diagnostic accumulators.  All updates are branch-free so
        # the tracing inside jit/while_loop stays constant-shape.
        #
        # ``lbfgs_skipped`` intentionally mirrors the ``should_skip``
        # decision inside ``lbfgs_append`` rather than comparing counts
        # before and after.  Once the circular buffer saturates,
        # ``count`` stays pinned at ``memory`` across every subsequent
        # append, which made the old ``new.count == state.count`` check
        # report a "skip" on every iteration after memory is full and
        # saturate ``n_lbfgs_skips`` to (max_steps - memory).
        prev_diag = state.diagnostics
        # Pull (s.y, |s.y|/(||s||*||y||), skipped) all at once so the
        # verbose callback can surface the L-BFGS skip diagnostic.  The
        # ``skipped`` flag is identical to ``lbfgs_should_skip(s, y)``
        # so the diagnostic accumulator below is unchanged.
        lbfgs_sty, lbfgs_relcurv, lbfgs_skipped = lbfgs_curvature_diagnostics(
            s, y_for_lbfgs
        )
        # Estimate of the smallest singular value of J_eq from the
        # Cholesky factor of J_eq J_eq^T (when equality constraints are
        # present).  This is ``sqrt(min_i diag(L)^2)`` which is a lower
        # bound on sigma_min(J_eq).  Tiny values flag near rank deficiency.
        if self.n_eq_constraints > 0:
            JJT_reg = state.eq_jac @ state.eq_jac.T + 1e-12 * jnp.eye(
                self.n_eq_constraints
            )
            # cholesky may produce nan on indefinite matrices; fall back
            # to +inf (i.e. "no finite estimate") in that case.
            L_eq = jnp.linalg.cholesky(JJT_reg)
            diag_L = jnp.abs(jnp.diag(L_eq))
            eq_sv_est = jnp.where(
                jnp.all(jnp.isfinite(diag_L)),
                jnp.min(diag_L),
                jnp.inf,
            )
        else:
            eq_sv_est = jnp.inf

        # A line search that reports ``success=True`` but produces a
        # merit *increase* is a red flag: either ``rho`` is too small
        # (descent direction of merit no longer dominated) or the
        # approximate HVP is badly out of date.  Count such regressions.
        merit_regression = ls_result.success & (merit_new > state.best_merit)

        n_active_ineq_now = jnp.sum(qp_result.active_set.astype(jnp.int32))

        new_diagnostics = SLSQPDiagnostics(
            n_qp_inner_failures=prev_diag.n_qp_inner_failures
            + jnp.where(~qp_result.converged, 1, 0),
            n_ls_failures=prev_diag.n_ls_failures + jnp.where(ls_failed, 1, 0),
            n_lbfgs_skips=prev_diag.n_lbfgs_skips + jnp.where(lbfgs_skipped, 1, 0),
            n_nan_directions=prev_diag.n_nan_directions
            + jnp.where(direction_nonfinite, 1, 0),
            max_gamma=jnp.maximum(prev_diag.max_gamma, new_lbfgs_history.gamma),
            min_diag=jnp.minimum(
                prev_diag.min_diag, jnp.min(new_lbfgs_history.diagonal)
            ),
            max_diag=jnp.maximum(
                prev_diag.max_diag, jnp.max(new_lbfgs_history.diagonal)
            ),
            eq_jac_min_sv_est=jnp.minimum(prev_diag.eq_jac_min_sv_est, eq_sv_est),
            ls_alpha_min=jnp.minimum(prev_diag.ls_alpha_min, alpha),
            tail_ls_failures=new_consecutive_ls_failures,
            n_bound_fix_solves=prev_diag.n_bound_fix_solves
            + qp_result.bound_fix_solves,
            max_bound_fixed=jnp.maximum(
                prev_diag.max_bound_fixed, qp_result.n_bound_fixed
            ),
            max_active_ineq=jnp.maximum(prev_diag.max_active_ineq, n_active_ineq_now),
            n_merit_regressions=prev_diag.n_merit_regressions
            + jnp.where(merit_regression, 1, 0),
            n_qp_budget_exhausted=prev_diag.n_qp_budget_exhausted
            + jnp.where(qp_result.reached_max_iter, 1, 0),
            n_qp_ping_pong=prev_diag.n_qp_ping_pong
            + jnp.where(qp_result.ping_ponged, 1, 0),
            max_qp_iterations=jnp.maximum(
                prev_diag.max_qp_iterations, qp_result.iterations
            ),
            max_qp_active_size=jnp.maximum(
                prev_diag.max_qp_active_size, n_active_ineq_now
            ),
            n_lpeca_bypassed=prev_diag.n_lpeca_bypassed
            + jnp.where(qp_result.lpeca_bypassed, 1, 0),
            n_lpeca_capped=prev_diag.n_lpeca_capped
            + jnp.where(qp_result.lpeca_capped, 1, 0),
            n_lpeca_bounds_prefixed=prev_diag.n_lpeca_bounds_prefixed
            + qp_result.n_lpeca_bounds_prefixed,
            n_proj_refinements=prev_diag.n_proj_refinements
            + qp_result.n_proj_refinements,
            max_proj_residual=jnp.maximum(
                prev_diag.max_proj_residual,
                qp_result.proj_residual.astype(prev_diag.max_proj_residual.dtype),
            ),
            n_divergence_blowups=prev_diag.n_divergence_blowups
            + jnp.where(blowup_now, 1, 0),
            divergence_triggered=prev_diag.divergence_triggered | diverging_now,
            min_projected_grad_norm=jnp.minimum(
                prev_diag.min_projected_grad_norm,
                qp_result.projected_grad_norm.astype(
                    prev_diag.min_projected_grad_norm.dtype
                ),
            ),
            # Branch-free counter: ``+1`` whenever the inner solver's
            # projected-gradient norm is strictly smaller than the
            # classical Lagrangian gradient norm at the new iterate.
            # ``grad_lagrangian_new`` is finalised earlier in ``step()``
            # (line ~1949) so it is safe to read here.  We cast both
            # sides to the same dtype before comparing to avoid the
            # ``ComplexWarning`` that ``jnp.where`` would otherwise emit
            # on dtype mismatches between ``float64`` (counter target
            # arithmetic) and ``float32`` (potential dtype of the QP
            # quantities under JAX 32-bit mode).
            n_steps_inexact_below_classical=prev_diag.n_steps_inexact_below_classical
            + jnp.where(
                qp_result.projected_grad_norm.astype(jnp.float64)
                < jnp.linalg.norm(grad_lagrangian_new).astype(jnp.float64),
                1,
                0,
            ),
        )

        # Propagate the NLP-recovered bound multipliers into the next
        # state so that LPEC-A's active-set predictor, the verbose
        # diagnostics, and any consumer of ``state.multipliers_ineq``
        # see the corrected (sharper) bound block.  The general portion
        # is taken from ``qp_result.multipliers_ineq`` (raw QP output,
        # unblended) for symmetry with ``multipliers_eq=`` below.  The
        # mild blended-vs-unblended inconsistency in the recovery (the
        # corrected bound mults were derived from blended ``μ_eq`` /
        # ``μ_gen``) is acceptable: ``μ_b`` for warm-start only needs
        # to be a non-negative dual estimate that approximately zeros
        # the partial Lagrangian gradient on active bounds at
        # ``x_{k+1}``.
        if m_bounds_static > 0:
            multipliers_ineq_for_state = qp_result.multipliers_ineq
            if n_lower_static > 0:
                multipliers_ineq_for_state = multipliers_ineq_for_state.at[
                    m_ineq_general_static : m_ineq_general_static + n_lower_static
                ].set(mu_lower_corr)
            if self._n_upper_bounds > 0:
                multipliers_ineq_for_state = multipliers_ineq_for_state.at[
                    m_ineq_general_static + n_lower_static :
                ].set(mu_upper_corr)
        else:
            multipliers_ineq_for_state = qp_result.multipliers_ineq

        # ------------------------------------------------------------------
        # Granular termination-code classification.
        #
        # ``terminate()`` only returns coarse ``optx.RESULTS`` codes
        # because optimistix's ``iterative_solve`` driver post-processes
        # our return value with ``optx.RESULTS.where(...)``, which
        # rejects subclass instances.  We therefore mirror the same
        # classification logic here using the ``slsqp_jax.RESULTS``
        # subclass and stash it on the state so ``postprocess()`` can
        # surface it via ``Solution.stats["slsqp_result"]``.
        #
        # The flags below match those checked in ``terminate()``: they
        # share the same semantics but are computed at the *new* iterate
        # (after the line search and bound-multiplier recovery), so the
        # resulting code is consistent with the value optimistix
        # eventually settles on.
        # ------------------------------------------------------------------
        m_eq_static = self.n_eq_constraints
        m_ineq_total_static = (
            self.n_ineq_constraints + self._n_lower_bounds + self._n_upper_bounds
        )
        eq_feasible_new = (
            jnp.max(jnp.abs(eq_val_new)) <= self.atol
            if m_eq_static > 0
            else jnp.array(True)
        )
        ineq_feasible_new = (
            jnp.max(jnp.maximum(0.0, -ineq_val_new)) <= self.atol
            if m_ineq_total_static > 0
            else jnp.array(True)
        )
        primal_feasible_new = jnp.reshape(eq_feasible_new & ineq_feasible_new, ())
        lagrangian_val_new = f_val_new
        if m_eq_static > 0:
            lagrangian_val_new = lagrangian_val_new - jnp.dot(
                qp_result.multipliers_eq, eq_val_new
            )
        if m_ineq_total_static > 0:
            lagrangian_val_new = lagrangian_val_new - jnp.dot(
                multipliers_ineq_for_state, ineq_val_new
            )
        grad_norm_new = jnp.linalg.norm(grad_lagrangian_new)
        rtol_target_new = self.rtol * jnp.maximum(jnp.abs(lagrangian_val_new), 1.0)
        classical_stationarity_new = grad_norm_new <= rtol_target_new
        # Mirror of ``terminate()``: inexact-stationarity disjunct
        # using the *just-computed* QP projected-gradient norm so the
        # early-exit path agrees with ``terminate()`` on the same step.
        inexact_stationarity_new = qp_result.projected_grad_norm <= rtol_target_new
        stationarity_new = classical_stationarity_new | (
            jnp.asarray(self.use_inexact_stationarity) & inexact_stationarity_new
        )
        new_step_count = state.step_count + 1
        has_min_steps_new = new_step_count >= self.min_steps
        max_iters_reached_new = new_step_count >= self.max_steps
        classical_converged_new = (
            stationarity_new & primal_feasible_new & has_min_steps_new
        )
        qp_kkt_success_new = (
            new_qp_optimal
            & primal_feasible_new
            & ls_result.success
            & (alpha >= 1.0 - 1e-6)
            & has_min_steps_new
        )
        converged_new = jnp.reshape(classical_converged_new | qp_kkt_success_new, ())
        # See the matching comment in ``terminate()``: the best-iterate
        # rollback intentionally leaves ``f_val_new`` non-finite while
        # restoring ``y_returned`` to ``best_x``.  Checking the
        # objective here would re-route legitimate ``iterate_blowup``
        # cases to ``nonfinite``.
        nonfinite_new = ~jnp.all(jnp.isfinite(y_returned))
        non_success_done_new = (
            max_iters_reached_new
            | merit_stagnation
            | qp_fatal
            | ls_fatal
            | diverging_now
        )
        # Layered classification using ``slsqp_jax.RESULTS.where``.
        # Mirrors the priority order documented in ``terminate()``.
        termination_code = RESULTS.successful
        termination_code = RESULTS.where(
            jnp.reshape(max_iters_reached_new, ()),
            RESULTS.nonlinear_max_steps_reached,
            termination_code,
        )
        termination_code = RESULTS.where(
            jnp.reshape(merit_stagnation, ()),
            RESULTS.merit_stagnation,
            termination_code,
        )
        termination_code = RESULTS.where(
            jnp.reshape(qp_fatal, ()),
            RESULTS.qp_subproblem_failure,
            termination_code,
        )
        termination_code = RESULTS.where(
            jnp.reshape(ls_fatal, ()),
            RESULTS.line_search_failure,
            termination_code,
        )
        termination_code = RESULTS.where(
            jnp.reshape(diverging_now, ()),
            RESULTS.iterate_blowup,
            termination_code,
        )
        # Infeasibility override: any non-success termination at an
        # infeasible iterate is reclassified as ``infeasible`` so the
        # user immediately knows to inspect the constraints rather
        # than tune ``max_steps`` / ``rtol``.
        termination_code = RESULTS.where(
            jnp.reshape(non_success_done_new & ~primal_feasible_new, ()),
            RESULTS.infeasible,
            termination_code,
        )
        # Nonfinite supersedes algorithmic classifications: a NaN
        # iterate is the *cause* of every other latched failure flag.
        termination_code = RESULTS.where(
            jnp.reshape(nonfinite_new, ()),
            RESULTS.nonfinite,
            termination_code,
        )
        # Success wins over every failure classification above.
        termination_code = RESULTS.where(
            converged_new, RESULTS.successful, termination_code
        )

        new_state = SLSQPState(
            step_count=state.step_count + 1,
            f_val=f_val_new,
            grad=grad_new,
            eq_val=eq_val_new,
            ineq_val=ineq_val_new,
            eq_jac=eq_jac_new,
            ineq_jac=ineq_jac_new,
            lbfgs_history=new_lbfgs_history,
            multipliers_eq=qp_result.multipliers_eq,
            multipliers_ineq=multipliers_ineq_for_state,
            prev_grad_lagrangian=grad_lagrangian_new,
            grad_lagrangian=grad_lagrangian_new,
            merit_penalty=merit_penalty,
            bound_jac=state.bound_jac,
            qp_iterations=state.qp_iterations + qp_result.iterations,
            qp_converged=qp_result.converged,
            prev_active_set=qp_result.active_set,
            consecutive_qp_failures=new_consecutive_qp_failures,
            consecutive_ls_failures=new_consecutive_ls_failures,
            consecutive_zero_steps=new_consecutive_zero_steps,
            qp_optimal=new_qp_optimal,
            best_merit=new_best_merit,
            steps_without_improvement=new_steps_without,
            stagnation=merit_stagnation,
            last_alpha=alpha,
            last_projected_grad_norm=qp_result.projected_grad_norm,
            ls_success=ls_result.success,
            ls_fatal=ls_fatal,
            qp_fatal=qp_fatal,
            termination_code=termination_code,
            best_x=new_best_x,
            blowup_count=new_blowup_count,
            diverging=diverging_now,
            diagnostics=new_diagnostics,
        )

        # Verbose output
        m_eq = self.n_eq_constraints
        m_ineq_total = (
            self.n_ineq_constraints + self._n_lower_bounds + self._n_upper_bounds
        )
        eq_viol = jnp.max(jnp.abs(eq_val_new)) if m_eq > 0 else jnp.array(0.0)
        ineq_viol = (
            jnp.max(jnp.maximum(0.0, -ineq_val_new))
            if m_ineq_total > 0
            else jnp.array(0.0)
        )
        c_viol = jnp.maximum(eq_viol, ineq_viol)
        kkt = jnp.linalg.norm(grad_lagrangian_new)
        # Relative stationarity: the actual termination criterion uses
        # ``||∇L|| <= rtol * max(|L|, 1)``.  Exposing the ratio tells
        # the user how close we are.
        lagrangian_val_est = (
            f_val_new
            - jnp.dot(qp_result.multipliers_eq, eq_val_new)
            - jnp.dot(qp_result.multipliers_ineq, ineq_val_new)
        )
        rel_kkt = kkt / jnp.maximum(jnp.abs(lagrangian_val_est), 1.0)
        dir_norm = jnp.linalg.norm(direction)
        grad_norm = jnp.linalg.norm(grad_new)
        n_active = jnp.sum(qp_result.active_set.astype(jnp.int32))
        diag_cond = jnp.max(new_lbfgs_history.diagonal) / jnp.maximum(
            jnp.min(new_lbfgs_history.diagonal), 1e-30
        )
        merit_delta = merit_new - state.best_merit
        # ``QPcyc`` packs the QP exit reason as a 2-bit code:
        #   bit 0 — ping-pong detector fired (sticky cycle short-circuit)
        #   bit 1 — active-set loop reached ``qp_max_iter``
        # 0 = clean convergence; 1 = ping-pong; 2 = budget exhausted.
        qp_cyc = (qp_result.ping_ponged.astype(jnp.int32)) | (
            qp_result.reached_max_iter.astype(jnp.int32) << 1
        )
        self.verbose(
            num_steps=("Step", new_state.step_count),  # ty: ignore[unresolved-attribute]  # equinox @dataclass_transform
            objective=("f", f_val_new, ".6e"),
            constraint_violation=("|c|", c_viol, ".3e"),
            kkt_residual=("|∇L|", kkt, ".3e"),
            kkt_relative=("|∇L|/|L|", rel_kkt, ".3e"),
            proj_grad_norm=("|W̃g|", qp_result.projected_grad_norm, ".3e"),
            grad_norm=("|∇f|", grad_norm, ".3e"),
            step_size=("α", alpha, ".3e"),
            direction_norm=("|d|", dir_norm, ".3e"),
            merit=("merit", merit_new, ".6e"),
            merit_delta=("Δmerit", merit_delta, "+.2e"),
            stag_count=("stag#", new_steps_without),
            stagnation=("stag", merit_stagnation),
            penalty=("ρ", merit_penalty, ".3e"),
            lbfgs_gamma=("γ", new_lbfgs_history.gamma, ".3e"),
            lbfgs_diag_cond=("κ_B", diag_cond, ".1e"),
            lbfgs_skipped=("skip", lbfgs_skipped),
            lbfgs_sty=("s·y", lbfgs_sty, ".3e"),
            lbfgs_relcurv=("rel_curv", lbfgs_relcurv, ".3e"),
            qp_iters=("QPiter", qp_result.iterations),
            qp_cyc=("QPcyc", qp_cyc),
            qp_converged=("QP ok", qp_result.converged),
            n_active=("#act", n_active),
            n_bound_fixed=("#fix", qp_result.n_bound_fixed),
            bound_fix_solves=("fix#", qp_result.bound_fix_solves),
            ls_steps=("LS it", ls_result.n_evals),
            ls_success=("LS ok", ls_result.success),
            ls_tail=("LS tail", new_consecutive_ls_failures),
            blowup_count=("blowup#", new_blowup_count),
        )

        return y_returned, new_state, aux  # ty: ignore[invalid-return-type]  # equinox @dataclass_transform

    def terminate(
        self,
        fn: Callable,
        y: Vector,
        args: Any,
        options: dict[str, Any],
        state: SLSQPState,
        tags: frozenset[object],
    ) -> tuple[Bool[Array, ""], Any]:
        """Check if the solver should terminate.

        Checks the KKT conditions for convergence:
        1. Gradient of Lagrangian is small (stationarity).
        2. Constraints are satisfied (primal feasibility).

        Args:
            fn: Objective function.
            y: Current parameter values.
            args: Additional arguments.
            options: Runtime options.
            state: Current solver state.
            tags: Lineax tags.

        Returns:
            Tuple of (done, result) where done is a bool indicating
            termination and result is the termination status code.
        """
        m_eq = self.n_eq_constraints
        m_ineq_total = (
            self.n_ineq_constraints + self._n_lower_bounds + self._n_upper_bounds
        )

        # Reuse the Lagrangian gradient computed in ``step`` with the
        # blended multipliers — these are the ones consistent with the
        # accepted iterate (the raw QP multipliers can be out of sync
        # when the line search accepts only a partial step).  On the
        # first call (before any ``step``) ``grad_lagrangian`` is
        # initialized to ``prev_grad_lagrangian`` from ``init``.
        grad_lagrangian = state.grad_lagrangian

        # Lagrangian value: L = f - lambda_eq^T c_eq - mu_ineq^T c_ineq
        lagrangian_val = state.f_val
        if m_eq > 0:
            lagrangian_val = lagrangian_val - state.multipliers_eq @ state.eq_val
        if m_ineq_total > 0:
            lagrangian_val = lagrangian_val - state.multipliers_ineq @ state.ineq_val

        # Relative stationarity: ||nabla L|| <= rtol * max(|L|, 1)
        grad_norm = jnp.linalg.norm(grad_lagrangian)
        rtol_target = self.rtol * jnp.maximum(jnp.abs(lagrangian_val), 1.0)
        classical_stationarity = grad_norm <= rtol_target
        # Inexact-stationarity disjunct (HR 2014, Theorem 3.5): the
        # inner solver's projected-gradient norm ``||W̃_k g_k||`` is
        # the noise-aware stationarity proxy.  Active only when
        # ``use_inexact_stationarity=True``; otherwise the default
        # ``inf`` value of ``last_projected_grad_norm`` ensures this
        # branch never fires.
        inexact_stationarity = state.last_projected_grad_norm <= rtol_target
        stationarity = classical_stationarity | (
            jnp.asarray(self.use_inexact_stationarity) & inexact_stationarity
        )

        # Check primal feasibility
        eq_feasible = jnp.array(True)
        if m_eq > 0:
            eq_violation = jnp.max(jnp.abs(state.eq_val))
            eq_feasible = eq_violation <= self.atol

        ineq_feasible = jnp.array(True)
        if m_ineq_total > 0:
            ineq_violation = jnp.max(jnp.maximum(0.0, -state.ineq_val))
            ineq_feasible = ineq_violation <= self.atol

        primal_feasible = eq_feasible & ineq_feasible

        # Check max iterations
        max_iters_reached = state.step_count >= self.max_steps

        # Check merit-based stagnation
        stagnation_detected = state.stagnation

        # Check chronic line-search failure (see step()).
        ls_stagnation = state.ls_fatal

        # Check chronic QP-subproblem failure (see step()).
        qp_stagnation = state.qp_fatal

        # Best-iterate divergence rollback (see step()).  Latches once
        # the merit-blowup patience runs out and the iterate has been
        # rolled back to ``state.best_x``.
        diverging = state.diverging

        # NaN/Inf in the iterate.  Routed to ``RESULTS.nonfinite``.
        # We deliberately *do not* check ``state.f_val`` here: the
        # best-iterate divergence rollback (see ``step()``) leaves
        # ``state.f_val`` reflecting the *attempted* step (which can
        # legitimately be NaN -- that is what tripped the rollback in
        # the first place) while ``y`` is restored to ``state.best_x``
        # which is finite by construction.  Including ``state.f_val``
        # in the nonfinite check would steal the routing away from
        # ``iterate_blowup`` for the exact pathology the rollback is
        # designed to handle.  ``state.grad`` is excluded for the same
        # reason -- the actual stationarity signal goes through
        # ``grad_lagrangian`` above.
        nonfinite_iter = ~jnp.all(jnp.isfinite(y))

        # Converged if stationary, feasible, and past minimum iterations.
        # The min_steps guard prevents false convergence when multipliers
        # are zero-initialized and haven't been updated by a QP solve yet.
        #
        # An older revision declared success via the unguarded form
        #     state.qp_optimal & primal_feasible
        # without any stationarity check.  That let repeated tiny-alpha
        # line searches masquerade as convergence because ``qp_optimal``
        # is latched once ``zero_step_patience`` consecutive "zero
        # steps" (pre- *or* post-line-search) are seen, and a collapsing
        # line search produces exactly that pattern.
        #
        # We re-introduce the disjunct here in a *guarded* form:
        #
        #     qp_kkt_success = qp_optimal & primal_feasible
        #                      & ls_success & (last_alpha >= 1 - eps)
        #
        # The ``ls_success`` flag rules out a line search that exhausted
        # its budget without satisfying the Armijo / merit-descent
        # condition.  The ``last_alpha >= 1 - eps`` guard rules out the
        # tiny-alpha collapse that motivated the original removal: when
        # ``d`` truly vanishes (the QP is at its KKT point and the
        # current iterate is feasible), the line search trivially
        # accepts ``alpha = 1`` because ``x + 1.0 * 0 = x``.  Any
        # ``alpha < 1`` therefore signals that ``d != 0`` and the LS
        # had to backtrack -- exactly the chronic-collapse symptom we
        # want to keep classified as a failure.
        #
        # This catches the legitimate case where the L-BFGS multiplier-
        # recovery noise leaves ``||grad L|| / |L|`` just above ``rtol``
        # but the QP is already at its model-KKT point and no further
        # progress is mathematically possible.
        has_min_steps = state.step_count >= self.min_steps
        classical_converged = stationarity & primal_feasible & has_min_steps
        qp_kkt_success = (
            state.qp_optimal
            & primal_feasible
            & state.ls_success
            & (state.last_alpha >= 1.0 - 1e-6)
            & has_min_steps
        )
        converged = classical_converged | qp_kkt_success

        # Defensive scalarization: ``stationarity`` inherits its shape from
        # ``lagrangian_val`` which in turn inherits from ``state.f_val`` and
        # the constraint values.  A user function that returns shape ``(1,)``
        # instead of a true 0-d scalar would otherwise produce a shape-(1,)
        # boolean here and trip the scalar-predicate check in
        # ``jax.lax.cond`` deep inside JAX with a cryptic error.  The source
        # is also scalarized in ``init`` / ``evaluate_at_alpha``; this is a
        # belt-and-braces guarantee so future leaks from constraint shapes
        # surface as a clear shape error at this call site.
        converged = jnp.reshape(converged, ())
        max_iters_reached = jnp.reshape(max_iters_reached, ())
        stagnation_detected = jnp.reshape(stagnation_detected, ())
        ls_stagnation = jnp.reshape(ls_stagnation, ())
        qp_stagnation = jnp.reshape(qp_stagnation, ())
        diverging = jnp.reshape(diverging, ())
        nonfinite_iter = jnp.reshape(nonfinite_iter, ())

        done = (
            converged
            | max_iters_reached
            | stagnation_detected
            | ls_stagnation
            | qp_stagnation
            | diverging
            | nonfinite_iter
        )

        # ``terminate`` must return a member of ``optx.RESULTS``: the
        # optimistix ``_iterate`` driver post-processes our return
        # value with ``optx.RESULTS.where(tree_allfinite(_y), ...,
        # optx.RESULTS.nonfinite)`` and uses ``result == optx.RESULTS.
        # successful`` as the loop predicate.  Equinox's enumeration
        # ``where`` requires both branches to share the *exact* same
        # ``_enumeration`` class, so a subclass instance would crash
        # the driver.  We therefore use the coarse ``optx.RESULTS``
        # codes here and surface the granular ``slsqp_jax.RESULTS``
        # classification through ``state.termination_code`` (set in
        # ``step()``) and ``Solution.stats["slsqp_result"]`` (set in
        # ``postprocess()``).
        # ``max_iters_reached`` is intentionally *excluded* from the
        # ``non_success_done`` disjunction.  The cond ladder below routes
        # ``non_success_done -> nonlinear_divergence`` and only the
        # remaining ``max_iters_reached`` branch maps to
        # ``nonlinear_max_steps_reached``.  Including ``max_iters_reached``
        # here would mis-classify a run that simply ran out of iterations
        # (no genuine failure flags latched) as ``nonlinear_divergence``.
        # This mirrors the priority order already implemented in
        # ``step()`` via ``RESULTS.where`` (see lines 2320-2367), where
        # ``nonlinear_max_steps_reached`` is the lowest-priority non-
        # success classification and any genuine failure flag overrides
        # it.
        non_success_done = (
            stagnation_detected | ls_stagnation | qp_stagnation | diverging
        )
        result = jax.lax.cond(
            converged,
            lambda: optx.RESULTS.successful,
            lambda: jax.lax.cond(
                nonfinite_iter,
                lambda: optx.RESULTS.nonfinite,
                lambda: jax.lax.cond(
                    non_success_done,
                    lambda: optx.RESULTS.nonlinear_divergence,
                    lambda: jax.lax.cond(
                        max_iters_reached,
                        lambda: optx.RESULTS.nonlinear_max_steps_reached,
                        lambda: optx.RESULTS.successful,  # Still running
                    ),
                ),
            ),
        )

        return done, result

    def postprocess(
        self,
        fn: Callable,
        y: Vector,
        aux: Any,
        args: Any,
        options: dict[str, Any],
        state: SLSQPState,
        tags: frozenset[object],
        result: Any,
    ) -> tuple[Vector, Any, dict[str, Any]]:
        """Post-process the optimization result.

        Args:
            fn: Objective function.
            y: Final parameter values.
            aux: Auxiliary output from last function evaluation.
            args: Additional arguments.
            options: Runtime options.
            state: Final solver state.
            tags: Lineax tags.
            result: Termination result code.

        Returns:
            Tuple of (y, aux, stats) where stats is a dictionary
            containing solver statistics.
        """
        y = self._clip_to_bounds(y)
        stats = {
            "num_steps": state.step_count,
            "final_objective": state.f_val,
            "final_grad_norm": jnp.linalg.norm(state.grad),
            "merit_penalty": state.merit_penalty,
            "total_qp_iterations": state.qp_iterations,
            "last_qp_converged": state.qp_converged,
            "qp_tolerance": 1e-8,
            "multipliers_eq": state.multipliers_eq,
            "multipliers_ineq": state.multipliers_ineq,
            "stagnation": state.stagnation,
            "ls_fatal": state.ls_fatal,
            "qp_fatal": state.qp_fatal,
            "diverging": state.diverging,
            "last_step_size": state.last_alpha,
            "consecutive_ls_failures": state.consecutive_ls_failures,
            "consecutive_qp_failures": state.consecutive_qp_failures,
            # Granular ``slsqp_jax.RESULTS`` classification of why the
            # run terminated.  ``Solution.result`` is the coarse
            # ``optx.RESULTS`` code (forced on us by optimistix's
            # ``iterative_solve``); this surfaces the finer code so
            # users can do
            # ``sol.stats["slsqp_result"] == slsqp_jax.RESULTS.merit_stagnation``.
            "slsqp_result": state.termination_code,
        }

        return y, aux, stats

    def _solve_qp_subproblem(
        self,
        state: SLSQPState,
        hvp_fn: Callable[[Vector], Vector],
        y: Vector,
    ) -> QPResult:
        """Solve the QP subproblem for the search direction.

        Solves:
            minimize    (1/2) d^T B d + g^T d
            subject to  A_eq d = -c_eq
                        A_ineq d >= -c_ineq
                        bounds[:, 0] - y <= d <= bounds[:, 1] - y

        using the HVP function v -> B @ v for the Hessian.

        **Bound handling.**  Box constraints are *not* passed to the QP
        solver as general inequality constraints.  Only the
        ``n_ineq_constraints`` general rows enter the QP's constraint
        matrix ``A``.  After the QP solve, the direction is clipped to
        ``[bounds[:, 0] - y, bounds[:, 1] - y]``.  Bound multipliers
        are recovered from the reduced gradient ``Bd + g - A^T lambda``
        at the clipped point.  This avoids forming a large projection
        matrix when many bounds are present: the CG projection cost
        drops from ``O((m_eq + m_gen + m_bounds)^3)`` to
        ``O((m_eq + m_gen)^3)`` per CG step.

        The previous iteration's QP active set is passed as a warm-start
        hint, and the outer KKT residual norm is used for adaptive EXPAND
        tolerance scaling.  For equality-constrained problems, the
        adaptive proximal parameter ``mu = max(kkt^tau, mu_min)`` is
        computed and the equality constraints are absorbed into the
        objective via sSQP (Wright, 2002, eq 6.6).

        When ``active_set_method`` is ``"lpeca_init"`` or ``"lpeca"``,
        the LPEC-A predicted active set (Oberlin & Wright, 2005) is
        computed from the current NLP iterate and multiplier estimates,
        and passed to the QP solver for initialization.

        When ``use_preconditioner`` is True, the L-BFGS inverse Hessian
        (with Woodbury correction for the proximal term) is passed to
        the QP solver as a CG preconditioner.

        When ``adaptive_cg_tol`` is True, the CG tolerance is adapted
        based on the outer KKT residual (Eisenstat-Walker style).

        Args:
            state: Current solver state.
            hvp_fn: Hessian-vector product function for the Lagrangian.
            y: Current iterate (used for computing box constraints on d).

        Returns:
            QPResult containing the search direction, multipliers, and
            active set.
        """
        g = state.grad

        A_eq = state.eq_jac
        b_eq = -state.eq_val

        m_ineq_general = self.n_ineq_constraints
        m_bounds = self._n_lower_bounds + self._n_upper_bounds

        # Only pass general inequality constraints to QP (not bounds).
        # This keeps the projection matrix small: O((m_eq + m_gen_active)^3)
        # instead of O((m_eq + m_gen_active + m_bounds_active)^3) per CG step.
        A_ineq = state.ineq_jac[:m_ineq_general]
        b_ineq = -state.ineq_val[:m_ineq_general]

        kkt_residual = jnp.linalg.norm(state.prev_grad_lagrangian)

        initial_active_set = (
            state.prev_active_set[:m_ineq_general] if m_ineq_general > 0 else None
        )

        # LPEC-A: compute predicted active set from NLP-level data.
        # Uses full ineq data (including bounds) for the prediction,
        # then slices to the general-ineq portion for the QP.
        #
        # Two-stage gating:
        #   1. Warm-up gate (Python-static): bypass LPEC-A for the
        #      first ``lpeca_warmup_steps`` outer iterations so the
        #      predictor is not run on the noisy initial multipliers.
        #   2. Trust gate (JAX-runtime, inside ``identify_active_set
        #      _lpeca``): empty prediction when ``rho_bar`` exceeds
        #      ``lpeca_trust_threshold``.
        # An additional rank-aware size cap inside the LPEC-A routine
        # truncates the prediction to ``n - m_eq - 1`` constraints to
        # preserve LICQ-like rank in the working-set Jacobian.
        predicted_active_set = None
        lpeca_bypassed = jnp.array(False)
        lpeca_capped = jnp.array(False)
        # LPEC-A bound warm-start outputs.  ``lpeca_bound_lower`` /
        # ``lpeca_bound_upper`` are length-``n_vars`` boolean masks
        # marking variables predicted active at their lower / upper
        # bound.  ``lpeca_bounds_prefixed_count`` is the total count
        # (= popcount(lower) + popcount(upper)) used as a diagnostic.
        # All three default to "no warm-start" (all-False / 0).
        n_vars_static = g.shape[0]
        lpeca_bound_lower = jnp.zeros(n_vars_static, dtype=bool)
        lpeca_bound_upper = jnp.zeros(n_vars_static, dtype=bool)
        lpeca_bounds_prefixed_count = jnp.array(0)
        if self.active_set_method in ("lpeca_init", "lpeca"):
            m_ineq_total = m_ineq_general + m_bounds
            if m_ineq_total > 0:
                # Warm-up gate (Python-static across step_count): run
                # the LPEC-A computation unconditionally for jit
                # compatibility but mask the result to all-False for
                # the first ``lpeca_warmup_steps`` outer iterations.
                lpeca_result = compute_lpeca_active_set(
                    c_ineq=state.ineq_val,
                    c_eq=state.eq_val,
                    grad=state.grad,
                    A_ineq=state.ineq_jac,
                    A_eq=state.eq_jac,
                    lambda_ineq=state.multipliers_ineq,
                    mu_eq=state.multipliers_eq,
                    sigma=self.lpeca_sigma,
                    beta=self.lpeca_beta,
                    trust_threshold=self.lpeca_trust_threshold,
                    use_lp=self.lpeca_use_lp,
                )
                in_warmup = state.step_count < self.lpeca_warmup_steps
                # Bypass = warm-up firing OR trust gate vetoing.
                bypassed = in_warmup | ~lpeca_result.valid
                full_predicted = jnp.where(
                    bypassed,
                    jnp.zeros_like(lpeca_result.predicted),
                    lpeca_result.predicted,
                )
                lpeca_bypassed = bypassed
                lpeca_capped = lpeca_result.capped & ~bypassed
                if m_ineq_general > 0:
                    predicted_active_set = full_predicted[:m_ineq_general]
                else:
                    predicted_active_set = None

                # --- Bound extension -------------------------------
                # LPEC-A operates on the full inequality vector, which
                # is laid out as ``[general; lower_bound; upper_bound]``.
                # Slice out the bound portion, then scatter back to
                # the variable-indexed space using the precomputed
                # ``_lower_indices`` / ``_upper_indices`` tuples.
                # The result is two length-``n`` boolean masks
                # indicating which variables LPEC-A predicts to be
                # at their lower / upper bound.
                if (
                    self.lpeca_predict_bounds
                    and m_bounds > 0
                    and m_ineq_general <= full_predicted.shape[0]
                ):
                    n_lower = self._n_lower_bounds
                    n_upper = self._n_upper_bounds
                    if n_lower > 0:
                        pred_lower = full_predicted[
                            m_ineq_general : m_ineq_general + n_lower
                        ]
                        lower_idx = jnp.asarray(self._lower_indices, dtype=jnp.int32)
                        lpeca_bound_lower = lpeca_bound_lower.at[lower_idx].set(
                            pred_lower
                        )
                    if n_upper > 0:
                        pred_upper = full_predicted[m_ineq_general + n_lower :]
                        upper_idx = jnp.asarray(self._upper_indices, dtype=jnp.int32)
                        lpeca_bound_upper_raw = jnp.zeros(n_vars_static, dtype=bool)
                        lpeca_bound_upper_raw = lpeca_bound_upper_raw.at[upper_idx].set(
                            pred_upper
                        )
                        # Lower-bound predictions take precedence when
                        # the same variable is predicted at both
                        # bounds (rare; can only happen for ~fixed
                        # variables with ``lb ≈ ub``).
                        lpeca_bound_upper = lpeca_bound_upper_raw & ~lpeca_bound_lower
                    lpeca_bounds_prefixed_count = jnp.sum(
                        lpeca_bound_lower.astype(jnp.int32)
                    ) + jnp.sum(lpeca_bound_upper.astype(jnp.int32))

        use_proximal = self.proximal_tau > 0
        if use_proximal:
            # Adaptive proximal mu (Wright, 2002, eq 6.6):
            # mu = clip(kkt_residual^tau, mu_min, mu_max)
            # Capped at mu_max so the proximal weight 1/mu >= 1/mu_max,
            # ensuring adequate equality enforcement even far from the solution.
            # Wright's local convergence analysis assumes eta < 1; when the
            # KKT residual is large the cap keeps the penalty tight.
            #
            # ``mu`` is reshaped to a true 0-d scalar.  ``solve_qp`` /
            # ``build_lagrangian_hvp`` declare ``proximal_mu: Scalar | float``
            # which jaxtyping enforces as ``Float[Array, '']``.  If any of the
            # clip operands carries a phantom leading axis (e.g.
            # ``self._proximal_mu_min = self.atol`` when the user passed
            # ``atol=jnp.array([1e-6])``, or ``proximal_tau`` arriving as a
            # (1,)-shape array), ``mu`` would inherit that shape and trip
            # the type check at ``solve_qp`` with a confusing
            # ``Actual value: f64[1] | Expected: Float[Array, ''] | float``.
            # Reshape here so any such leak surfaces as a clear shape error
            # at this call site instead.
            mu = jnp.reshape(
                jnp.clip(
                    kkt_residual**self.proximal_tau,
                    self._proximal_mu_min,
                    self._proximal_mu_max,
                ),
                (),
            )
        else:
            mu = 0.0

        precond_fn = self._build_preconditioner(
            state,
            proximal_mu=mu,
            lagrangian_hvp_fn=(
                hvp_fn if self.preconditioner_type == "diagonal" else None
            ),
        )

        # Eisenstat-Walker adaptive CG tolerance: solve loosely far from
        # optimum (fast), tightly near the solution (accurate).
        # Kept separate from `tol` so feasibility checking stays tight.
        if self.adaptive_cg_tol:
            adaptive_tol = jnp.minimum(0.1, jnp.maximum(self.atol, kkt_residual))
        else:
            adaptive_tol = None

        inner_cg_tol = adaptive_tol if adaptive_tol is not None else self.atol
        if self.inner_solver is not None:
            inner_solver = cast(AbstractInnerSolver, self.inner_solver)
        else:
            inner_solver = cast(
                AbstractInnerSolver,
                ProjectedCGCholesky(
                    max_cg_iter=self.qp_max_cg_iter,
                    cg_tol=inner_cg_tol,
                    cg_regularization=self.cg_regularization,
                    use_constraint_preconditioner=self.use_exact_hvp_in_qp,
                ),
            )

        qp_result = solve_qp(
            hvp_fn=hvp_fn,
            g=g,
            A_eq=A_eq,
            b_eq=b_eq,
            A_ineq=A_ineq,
            b_ineq=b_ineq,
            max_iter=self.qp_max_iter,
            max_cg_iter=self.qp_max_cg_iter,
            initial_active_set=initial_active_set,
            kkt_residual=kkt_residual,
            proximal_mu=mu,
            prev_multipliers_eq=state.multipliers_eq,
            precond_fn=precond_fn,
            cg_tol=adaptive_tol,
            cg_regularization=self.cg_regularization,
            use_proximal=use_proximal,
            predicted_active_set=predicted_active_set,
            active_set_method=self.active_set_method,
            use_constraint_preconditioner=self.use_exact_hvp_in_qp,
            inner_solver=inner_solver,
            mult_drop_floor=self.mult_drop_floor,
            ping_pong_threshold=self.qp_ping_pong_threshold,
        )

        direction = qp_result.d

        # --- Bound post-processing (iterative Phase 2) ---
        # Iterative bound-fixing active set: fix variables at bounds,
        # re-solve CG in the free subspace, check for new violations
        # and wrong-sign multipliers, repeat.  Each CG re-solve uses
        # only (m_eq + m_gen_active) rows in the projection matrix,
        # keeping cost at O((m_eq + m_gen)^3) instead of
        # O((m_eq + m_gen + m_bounds)^3).
        #
        # The loop terminates when no variables are added to or
        # dropped from the bound-active set.  Typically 2-5 passes.
        if m_bounds > 0:
            assert self.bounds is not None
            n_vars = g.shape[0]
            d_lower = self.bounds[:, 0] - y
            d_upper = self.bounds[:, 1] - y
            finite_lower = jnp.isfinite(d_lower)
            finite_upper = jnp.isfinite(d_upper)

            # Combined constraint matrix: equality + active gen ineq
            A_combined = jnp.concatenate([A_eq, A_ineq], axis=0)
            b_combined = jnp.concatenate([b_eq, b_ineq], axis=0)
            m_eq_static = self.n_eq_constraints
            eq_active = jnp.ones(m_eq_static, dtype=bool)
            combined_active = jnp.concatenate([eq_active, qp_result.active_set])

            inner_cg_tol = adaptive_tol if adaptive_tol is not None else 1e-8

            # LPEC-A bound warm-start: seed ``free_mask`` / ``d_fixed``
            # from the LPEC-A predicted active bound set (both
            # ``lpeca_bound_lower`` / ``lpeca_bound_upper`` are
            # all-False when LPEC-A is disabled, bypassed by the
            # warm-up / trust gates, or ``lpeca_predict_bounds=False``
            # -- in which case this falls back to the original
            # all-free initialization).  The initial ``d_fixed`` is
            # set to ``d_lower`` / ``d_upper`` for the pre-fixed
            # variables so the reduced-space inner solve is consistent
            # with the active bounds.
            has_lpeca_bound_prefix = jnp.any(lpeca_bound_lower | lpeca_bound_upper)
            free_mask = ~(lpeca_bound_lower | lpeca_bound_upper)
            d_fixed = jnp.where(
                lpeca_bound_lower,
                d_lower,
                jnp.where(lpeca_bound_upper, d_upper, jnp.zeros(n_vars)),
            )
            mult_combined = jnp.zeros(A_combined.shape[0])

            # Counter for "non-trivial" bound-fixing passes: incremented
            # only when the pass performs a reduced-space inner solve
            # (``any_change & any_fixed``).  Passes where ``free_mask``
            # did not move are short-circuited below, avoiding an
            # unnecessary ``inner_solver.solve`` call that would be
            # discarded anyway.  This matters a lot on large problems
            # (e.g. Portfolio(n=5000) with MINRES-QLP) where each
            # inner solve is O((n+m) * t_minres): with no bounds ever
            # active we were paying for ``5 * max_steps`` MINRES solves
            # whose results were masked out by ``use_new=False``.
            bound_fix_solves = jnp.array(0)
            # Track projection diagnostics across the bound-fix loop.
            # ``proj_residual_accum`` carries the residual of whichever
            # inner solve ultimately produced ``direction``; we update
            # it only when the new solve is accepted (``use_new``) so
            # the final value matches the iterate exposed to the line
            # search.  ``n_proj_refinements_accum`` is a strict sum
            # across every inner solve performed (accepted or not),
            # mirroring how ``bound_fix_solves`` itself is counted.
            proj_residual_accum = qp_result.proj_residual
            n_proj_refinements_accum = qp_result.n_proj_refinements
            # Latest-not-accumulated semantics: track the projected-
            # gradient norm of whichever inner solve ultimately produced
            # ``direction``.  Updated only when ``use_new`` is true so
            # the value matches the iterate exposed to the line search.
            projected_grad_norm_accum = qp_result.projected_grad_norm

            bound_fix_tol = 1e-12
            for _bound_pass in range(5):
                # --- Add step: fix free variables that violate bounds ---
                add_lower = (
                    (direction <= d_lower + bound_fix_tol) & finite_lower & free_mask
                )
                add_upper = (
                    (direction >= d_upper - bound_fix_tol) & finite_upper & free_mask
                )
                add_set = add_lower | add_upper

                # --- Drop step: release fixed variables with wrong-sign
                # bound multipliers.  A lower-bound multiplier should be
                # >= 0 (pushing the variable up); if negative, the variable
                # wants to move away from the bound and should be freed.
                # Similarly for upper bounds. ---
                Bd_cur = hvp_fn(direction)
                grad_qp_cur = Bd_cur + g
                cf = jnp.zeros_like(g)
                if m_eq_static > 0:
                    cf = cf + A_eq.T @ mult_combined[:m_eq_static]
                if m_ineq_general > 0:
                    cf = cf + A_ineq.T @ mult_combined[m_eq_static:]
                reduced_grad_cur = grad_qp_cur - cf

                at_lower_cur = ~free_mask & (d_fixed <= d_lower + bound_fix_tol)
                at_upper_cur = ~free_mask & (d_fixed >= d_upper - bound_fix_tol)
                drop_lower = at_lower_cur & (reduced_grad_cur < -bound_fix_tol)
                drop_upper = at_upper_cur & (-reduced_grad_cur < -bound_fix_tol)
                drop_set = drop_lower | drop_upper

                any_change = jnp.any(add_set | drop_set)

                # On the first pass, if LPEC-A pre-fixed any bounds the
                # loop has not yet solved a reduced-space problem for
                # the warm-started ``free_mask``.  Force that solve so
                # ``direction`` / ``mult_combined`` become consistent
                # with the LPEC-A-predicted active set; subsequent add
                # / drop checks then operate on the warm-started
                # reduced solution instead of the raw QP direction.
                force_initial_solve = (
                    jnp.array(_bound_pass == 0) & has_lpeca_bound_prefix
                )

                new_free_mask = (free_mask & ~add_set) | drop_set
                new_d_fixed = jnp.where(
                    add_lower,
                    d_lower,
                    jnp.where(add_upper, d_upper, d_fixed),
                )
                new_d_fixed = jnp.where(drop_set, 0.0, new_d_fixed)

                free_mask = jnp.where(any_change, new_free_mask, free_mask)
                d_fixed = jnp.where(any_change, new_d_fixed, d_fixed)

                any_fixed = ~jnp.all(free_mask)
                needs_solve = (any_change | force_initial_solve) & any_fixed

                def _do_solve(_=None):
                    return inner_solver.solve(
                        hvp_fn,
                        g,
                        A_combined,
                        b_combined,
                        combined_active,
                        precond_fn=precond_fn,
                        free_mask=free_mask,
                        d_fixed=d_fixed,
                        adaptive_tol=adaptive_tol,
                    )

                def _skip_solve(_=None):
                    # Branches of jax.lax.cond must produce identical
                    # PyTree structure / shapes / dtypes; mirror the
                    # InnerSolveResult fields populated by the inner
                    # solver in ``_do_solve`` (especially the projection
                    # diagnostics).  Skip-solves never refine, so they
                    # contribute zero refinements and zero residual.
                    return InnerSolveResult(
                        d=direction,
                        multipliers=mult_combined,
                        converged=jnp.array(True),
                        proj_residual=jnp.asarray(0.0, dtype=direction.dtype),
                        n_proj_refinements=jnp.asarray(0),
                        # Skip-solve preserves the previous direction
                        # without producing a fresh projected-gradient
                        # norm.  Returning ``inf`` is the right default
                        # because anything other than ``HRInexactSTCG``
                        # also returns ``inf``; the active-set loop's
                        # last *real* solve still feeds the
                        # ``projected_grad_norm_accum`` we surface.
                        projected_grad_norm=jnp.asarray(jnp.inf, dtype=direction.dtype),
                    )

                bound_result = jax.lax.cond(
                    needs_solve, _do_solve, _skip_solve, operand=None
                )
                d_new = bound_result.d
                mult_new = bound_result.multipliers

                bound_fix_solves = bound_fix_solves + jnp.where(needs_solve, 1, 0)

                use_new = needs_solve
                direction = jnp.where(use_new, d_new, direction)
                mult_combined = jnp.where(use_new, mult_new, mult_combined)

                # Surface the projection diagnostics from the
                # MinresQLPSolver result.  ``proj_residual_accum``
                # tracks the residual on whichever direction we end
                # up returning, so we update it only when the new
                # solve is actually accepted.  ``n_proj_refinements_accum``
                # sums every refinement round taken whether the solve
                # was accepted or skipped.
                proj_residual_accum = jnp.where(
                    use_new,
                    bound_result.proj_residual.astype(proj_residual_accum.dtype),
                    proj_residual_accum,
                )
                n_proj_refinements_accum = (
                    n_proj_refinements_accum + bound_result.n_proj_refinements
                )
                projected_grad_norm_accum = jnp.where(
                    use_new,
                    bound_result.projected_grad_norm.astype(
                        projected_grad_norm_accum.dtype
                    ),
                    projected_grad_norm_accum,
                )

            # Final bound-active identification from the converged direction
            at_lower_full = (direction <= d_lower + bound_fix_tol) & finite_lower
            at_upper_full = (direction >= d_upper - bound_fix_tol) & finite_upper
            any_bound_active = jnp.any(at_lower_full | at_upper_full)

            mult_eq_final = jnp.where(
                any_bound_active,
                mult_combined[:m_eq_static],
                qp_result.multipliers_eq,
            )
            mult_gen_final = (
                jnp.where(
                    any_bound_active,
                    mult_combined[m_eq_static:],
                    qp_result.multipliers_ineq,
                )
                if m_ineq_general > 0
                else qp_result.multipliers_ineq
            )

            # Recover bound multipliers from the reduced gradient
            lower_idx = np.array(self._lower_indices)
            upper_idx = np.array(self._upper_indices)

            Bd = hvp_fn(direction)
            grad_qp = Bd + g
            constraint_force = jnp.zeros_like(g)
            if self.n_eq_constraints > 0:
                constraint_force = constraint_force + A_eq.T @ mult_eq_final
            if m_ineq_general > 0:
                constraint_force = constraint_force + A_ineq.T @ mult_gen_final
            reduced_grad = grad_qp - constraint_force

            at_lower = (
                at_lower_full[lower_idx]
                if len(lower_idx) > 0
                else jnp.zeros((0,), dtype=bool)
            )
            at_upper = (
                at_upper_full[upper_idx]
                if len(upper_idx) > 0
                else jnp.zeros((0,), dtype=bool)
            )

            bound_mult_lower = (
                jnp.where(at_lower, reduced_grad[lower_idx], 0.0)
                if len(lower_idx) > 0
                else jnp.zeros((0,))
            )
            bound_mult_upper = (
                jnp.where(at_upper, -reduced_grad[upper_idx], 0.0)
                if len(upper_idx) > 0
                else jnp.zeros((0,))
            )

            multipliers_eq = mult_eq_final
            multipliers_ineq = jnp.concatenate(
                [mult_gen_final, bound_mult_lower, bound_mult_upper]
            )
            active_set = jnp.concatenate([qp_result.active_set, at_lower, at_upper])
            n_bound_fixed = jnp.sum((at_lower_full | at_upper_full).astype(jnp.int32))
        else:
            multipliers_eq = qp_result.multipliers_eq
            multipliers_ineq = qp_result.multipliers_ineq
            active_set = qp_result.active_set
            bound_fix_solves = jnp.array(0)
            n_bound_fixed = jnp.array(0)
            proj_residual_accum = qp_result.proj_residual
            n_proj_refinements_accum = qp_result.n_proj_refinements
            projected_grad_norm_accum = qp_result.projected_grad_norm

        return QPResult(  # ty: ignore[invalid-return-type]  # equinox @dataclass_transform
            direction=direction,
            multipliers_eq=multipliers_eq,
            multipliers_ineq=multipliers_ineq,
            active_set=active_set,
            converged=qp_result.converged,
            iterations=qp_result.iterations,
            bound_fix_solves=bound_fix_solves,
            n_bound_fixed=n_bound_fixed,
            ping_ponged=qp_result.ping_ponged,
            reached_max_iter=qp_result.reached_max_iter,
            lpeca_bypassed=lpeca_bypassed,
            lpeca_capped=lpeca_capped,
            n_lpeca_bounds_prefixed=lpeca_bounds_prefixed_count,
            proj_residual=proj_residual_accum,
            n_proj_refinements=n_proj_refinements_accum,
            projected_grad_norm=projected_grad_norm_accum,
        )
