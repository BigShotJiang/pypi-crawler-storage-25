from setuptools import setup

setup(
    name="dlocal-cli",
    version="99.0.3",
    description="This package is reserved by dLocal. Do not install.",
    author="dLocal Security",
    author_email="",
    py_modules=["dlocal_cli"],
)
