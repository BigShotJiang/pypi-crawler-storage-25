raise RuntimeError("Reserved by dLocal. Install from internal registry.")
