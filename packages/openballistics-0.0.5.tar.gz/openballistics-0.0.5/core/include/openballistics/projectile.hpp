#ifndef OPENBALLISTICS_PROJECTILE_HPP
#define OPENBALLISTICS_PROJECTILE_HPP

#include "./projectile/realistic.hpp"

#endif // OPENBALLISTICS_PROJECTILE_HPP
