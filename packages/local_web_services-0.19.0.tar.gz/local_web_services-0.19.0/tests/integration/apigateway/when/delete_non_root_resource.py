"""When: a non-root "api gateway" "resource" is deleted along with its methods and integrations"""

from __future__ import annotations

from pytest_bdd import when
from starlette.testclient import TestClient


@when('a non-root "api gateway" "resource" is deleted along with its methods and integrations')
def delete_non_root_resource(client: TestClient, world):
    list_r = client.get("/restapis")
    items = list_r.json().get("item", [])
    if not items:
        world["error"] = {"message": "No REST API found"}
        return
    api_id = items[0]["id"]
    resources_r = client.get(f"/restapis/{api_id}/resources")
    resource_items = resources_r.json().get("item", [])
    non_root = next((res for res in resource_items if res.get("path") != "/"), None)
    if non_root is None:
        world["error"] = {"message": "No non-root resource found"}
        return
    r = client.delete(f"/restapis/{api_id}/resources/{non_root['id']}")
    if r.status_code < 300:
        world["result"] = {}
    else:
        world["error"] = r.json()
