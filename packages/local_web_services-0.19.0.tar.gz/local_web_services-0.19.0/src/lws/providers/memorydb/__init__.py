"""MemoryDB provider package."""
