"""RDS HTTP routes.

Implements the RDS control-plane wire protocol that AWS SDKs and Terraform use,
using JSON request/response format with X-Amz-Target header dispatch.
Also implements the RDS Data API (POST /execute) — see ``_rds_data_api`` module.
"""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Request, Response

from lws.logging.logger import get_logger
from lws.logging.middleware import RequestLoggingMiddleware
from lws.providers._shared.aws_cloudtrail_middleware import apply_cloudtrail_middleware
from lws.providers._shared.aws_lifecycle import (
    ResourceLifecycleConfig,
    ResourceStateTracker,
    TrackerRegistry,
    apply_delete_lifecycle,
    register_tracker,
)
from lws.providers._shared.cluster_db_service import (
    check_db_resource_read_lifecycle,
)
from lws.providers._shared.provider_context import ProviderContext
from lws.providers._shared.request_helpers import parse_json_body, resolve_api_action
from lws.providers._shared.resource_container import ResourceContainerManager
from lws.providers._shared.response_helpers import (
    creating_guard as _creating_guard,
)
from lws.providers._shared.response_helpers import (
    error_response as _error_response,
)
from lws.providers._shared.response_helpers import (
    json_response as _json_response,
)
from lws.providers.rds._rds_data_api import handle_execute_statement as _handle_execute_statement
from lws.providers.rds._rds_lifecycle import (
    overlay_instance_tracker_state as _overlay_instance_tracker_state,
)
from lws.providers.rds._rds_lifecycle import (
    rds_lifecycle_modify_instance as _rds_lifecycle_modify_instance,
)
from lws.providers.rds._rds_state import (
    _ENGINE_VERSIONS,
    _DBCluster,
    _DBInstance,
    _find_resource_tags,
    _format_db_cluster,
    _format_db_instance,
    _RdsState,
)

_logger = get_logger("ldk.rds")


# ------------------------------------------------------------------
# Action handlers
# ------------------------------------------------------------------


async def _handle_create_db_instance(state: _RdsState, body: dict) -> Response:
    """Handle CreateDBInstance."""
    db_instance_id = body.get("DBInstanceIdentifier", "")
    if not db_instance_id:
        return _error_response(
            "InvalidParameterValue",
            "DBInstanceIdentifier is required.",
        )

    if db_instance_id in state.instances:
        return _error_response(
            "DBInstanceAlreadyExistsFault",
            f"DB instance already exists: {db_instance_id}",
        )

    engine = body.get("Engine", "postgres")
    cluster_id = body.get("DBClusterIdentifier")
    endpoint = None
    if cluster_id and cluster_id in state.clusters:
        cluster = state.clusters[cluster_id]
        endpoint = f"{cluster.endpoint}:{cluster.port}"
    else:
        if engine == "postgres":
            cm = state.postgres_container_manager
        else:
            cm = state.mysql_container_manager
        if cm:
            endpoint = await cm.start_container(db_instance_id)
    instance = _DBInstance(
        db_instance_identifier=db_instance_id,
        db_instance_class=body.get("DBInstanceClass", "db.t3.micro"),
        engine=engine,
        master_username=body.get("MasterUsername", "admin"),
        allocated_storage=body.get("AllocatedStorage", 20),
        db_cluster_identifier=cluster_id,
        data_plane_endpoint=endpoint,
    )
    state.instances[db_instance_id] = instance

    return _json_response({"DBInstance": _format_db_instance(instance)})


async def _handle_describe_db_instances(state: _RdsState, body: dict) -> Response:
    """Handle DescribeDBInstances."""
    db_instance_id = body.get("DBInstanceIdentifier")

    if db_instance_id:
        instance = state.instances.get(db_instance_id)
        if instance is None:
            return _error_response(
                "DBInstanceNotFoundFault",
                f"DB instance not found: {db_instance_id}",
                status_code=404,
            )
        return _json_response({"DBInstances": [_format_db_instance(instance)]})

    instances = [_format_db_instance(i) for i in state.instances.values()]
    return _json_response({"DBInstances": instances})


async def _handle_delete_db_instance(state: _RdsState, body: dict) -> Response:
    """Handle DeleteDBInstance."""
    db_instance_id = body.get("DBInstanceIdentifier", "")

    instance = state.instances.get(db_instance_id)
    if instance is None:
        return _error_response(
            "DBInstanceNotFoundFault",
            f"DB instance not found: {db_instance_id}",
            status_code=404,
        )

    del state.instances[db_instance_id]
    if not instance.db_cluster_identifier:
        if instance.engine == "postgres":
            cm = state.postgres_container_manager
        else:
            cm = state.mysql_container_manager
        if cm:
            await cm.stop_container(db_instance_id)
    instance.status = "deleting"
    return _json_response({"DBInstance": _format_db_instance(instance)})


async def _handle_modify_db_instance(state: _RdsState, body: dict) -> Response:
    """Handle ModifyDBInstance."""
    db_instance_id = body.get("DBInstanceIdentifier", "")

    instance = state.instances.get(db_instance_id)
    if instance is None:
        return _error_response(
            "DBInstanceNotFoundFault",
            f"DB instance not found: {db_instance_id}",
            status_code=404,
        )

    if "DBInstanceClass" in body:
        instance.db_instance_class = body["DBInstanceClass"]
    if "AllocatedStorage" in body:
        instance.allocated_storage = body["AllocatedStorage"]
    if "MasterUserPassword" in body:
        pass  # Password change acknowledged but not stored in plain text
    if "Engine" in body:
        instance.engine = body["Engine"]
        instance.endpoint["Port"] = 5432 if body["Engine"] == "postgres" else 3306

    return _json_response({"DBInstance": _format_db_instance(instance)})


async def _handle_create_db_cluster(state: _RdsState, body: dict) -> Response:
    """Handle CreateDBCluster."""
    db_cluster_id = body.get("DBClusterIdentifier", "")
    if not db_cluster_id:
        return _error_response(
            "InvalidParameterValue",
            "DBClusterIdentifier is required.",
        )

    if db_cluster_id in state.clusters:
        return _error_response(
            "DBClusterAlreadyExistsFault",
            f"DB cluster already exists: {db_cluster_id}",
        )

    engine = body.get("Engine", "postgres")
    cm = state.postgres_container_manager if engine == "postgres" else state.mysql_container_manager
    endpoint = None
    if cm:
        endpoint = await cm.start_container(db_cluster_id)
    cluster = _DBCluster(
        db_cluster_identifier=db_cluster_id,
        engine=engine,
        master_username=body.get("MasterUsername", "admin"),
        data_plane_endpoint=endpoint,
    )
    state.clusters[db_cluster_id] = cluster

    # Eagerly open a SQLite connection so the Data API is available immediately
    await state.get_or_create_cluster_db(cluster.arn)

    return _json_response({"DBCluster": _format_db_cluster(cluster)})


async def _handle_describe_db_clusters(state: _RdsState, body: dict) -> Response:
    """Handle DescribeDBClusters."""
    db_cluster_id = body.get("DBClusterIdentifier")

    if db_cluster_id:
        cluster = state.clusters.get(db_cluster_id)
        if cluster is None:
            return _error_response(
                "DBClusterNotFoundFault",
                f"DB cluster not found: {db_cluster_id}",
                status_code=404,
            )
        return _json_response({"DBClusters": [_format_db_cluster(cluster)]})

    clusters = [_format_db_cluster(c) for c in state.clusters.values()]
    return _json_response({"DBClusters": clusters})


async def _handle_delete_db_cluster(state: _RdsState, body: dict) -> Response:
    """Handle DeleteDBCluster."""
    db_cluster_id = body.get("DBClusterIdentifier", "")

    cluster = state.clusters.get(db_cluster_id)
    if cluster is None:
        return _error_response(
            "DBClusterNotFoundFault",
            f"DB cluster not found: {db_cluster_id}",
            status_code=404,
        )

    del state.clusters[db_cluster_id]
    if cluster.engine == "postgres":
        cm = state.postgres_container_manager
    else:
        cm = state.mysql_container_manager
    if cm:
        await cm.stop_container(db_cluster_id)
    cluster.status = "deleting"
    return _json_response({"DBCluster": _format_db_cluster(cluster)})


async def _handle_list_tags_for_resource(state: _RdsState, body: dict) -> Response:
    """Handle ListTagsForResource."""
    resource_arn = body.get("ResourceName", "")

    tags = _find_resource_tags(state, resource_arn)
    if tags is None:
        return _error_response(
            "DBInstanceNotFoundFault",
            f"Resource not found: {resource_arn}",
            status_code=404,
        )

    tag_list = [{"Key": k, "Value": v} for k, v in tags.items()]
    return _json_response({"TagList": tag_list})


async def _handle_add_tags_to_resource(state: _RdsState, body: dict) -> Response:
    """Handle AddTagsToResource."""
    resource_arn = body.get("ResourceName", "")
    new_tags = body.get("Tags", [])

    tags = _find_resource_tags(state, resource_arn)
    if tags is None:
        return _error_response(
            "DBInstanceNotFoundFault",
            f"Resource not found: {resource_arn}",
            status_code=404,
        )

    for tag in new_tags:
        tags[tag["Key"]] = tag["Value"]

    return _json_response({})


async def _handle_remove_tags_from_resource(state: _RdsState, body: dict) -> Response:
    """Handle RemoveTagsFromResource."""
    resource_arn = body.get("ResourceName", "")
    tag_keys = body.get("TagKeys", [])

    tags = _find_resource_tags(state, resource_arn)
    if tags is None:
        return _error_response(
            "DBInstanceNotFoundFault",
            f"Resource not found: {resource_arn}",
            status_code=404,
        )

    for key in tag_keys:
        tags.pop(key, None)

    return _json_response({})


async def _handle_describe_db_engine_versions(_state: _RdsState, body: dict) -> Response:
    """Handle DescribeDBEngineVersions."""
    engine = body.get("Engine")

    if engine:
        versions = _ENGINE_VERSIONS.get(engine, [])
    else:
        versions = []
        for engine_versions in _ENGINE_VERSIONS.values():
            versions.extend(engine_versions)

    return _json_response({"DBEngineVersions": versions})


# ------------------------------------------------------------------
# Action dispatch table
# ------------------------------------------------------------------


_ACTION_HANDLERS: dict[str, Any] = {
    "CreateDBInstance": _handle_create_db_instance,
    "DescribeDBInstances": _handle_describe_db_instances,
    "DeleteDBInstance": _handle_delete_db_instance,
    "ModifyDBInstance": _handle_modify_db_instance,
    "CreateDBCluster": _handle_create_db_cluster,
    "DescribeDBClusters": _handle_describe_db_clusters,
    "DeleteDBCluster": _handle_delete_db_cluster,
    "ListTagsForResource": _handle_list_tags_for_resource,
    "AddTagsToResource": _handle_add_tags_to_resource,
    "RemoveTagsFromResource": _handle_remove_tags_from_resource,
    "DescribeDBEngineVersions": _handle_describe_db_engine_versions,
}

_RDS_INSTANCE_READ_ACTIONS = {"DescribeDBInstances", "ModifyDBInstance"}
_RDS_CLUSTER_READ_ACTIONS = {"DescribeDBClusters"}


def _check_rds_instance_lifecycle(
    action: str,
    body: dict,
    lc: ResourceLifecycleConfig,
    tracker: ResourceStateTracker,
) -> Response | None:
    """Check lifecycle state for instance read operations."""
    key, fault, rtype = "DBInstanceIdentifier", "InvalidDBInstanceStateFault", "DB instance"
    return check_db_resource_read_lifecycle(
        action, body, key, fault, rtype, lc, tracker, _RDS_INSTANCE_READ_ACTIONS
    )


def _check_rds_cluster_lifecycle(
    action: str,
    body: dict,
    lc: ResourceLifecycleConfig,
    tracker: ResourceStateTracker,
) -> Response | None:
    """Check lifecycle state for cluster read operations."""
    key, fault, rtype = "DBClusterIdentifier", "InvalidDBClusterStateFault", "DB cluster"
    return check_db_resource_read_lifecycle(
        action, body, key, fault, rtype, lc, tracker, _RDS_CLUSTER_READ_ACTIONS
    )


async def _rds_lifecycle_instance(
    action: str,
    handler: Any,
    state: _RdsState,
    body: dict,
    lc: ResourceLifecycleConfig,
    tracker: ResourceStateTracker,
) -> Response | None:
    """Handle lifecycle-aware instance create/delete. Returns None to fall through."""
    if action == "CreateDBInstance" and lc.enabled:
        resp = await handler(state, body)
        if resp.status_code == 200:
            iid = body.get("DBInstanceIdentifier", "")
            tracker.set_state(iid, "CREATING")
            tracker.schedule_transition(iid, "ACTIVE", lc.create_dwell_ms)
        return resp
    if action == "ModifyDBInstance" and lc.enabled:
        return await _rds_lifecycle_modify_instance(handler, state, body, lc, tracker)
    if action == "DeleteDBInstance" and lc.enabled:
        iid = body.get("DBInstanceIdentifier", "")
        guard = _creating_guard(
            iid, "InvalidDBInstanceStateFault", "DB instance", tracker.get_state(iid)
        )
        if guard is not None:
            return guard
        resp = await handler(state, body)
        return apply_delete_lifecycle(resp, iid, lc, tracker)
    return None


async def _rds_lifecycle_cluster(
    action: str,
    handler: Any,
    state: _RdsState,
    body: dict,
    lc: ResourceLifecycleConfig,
    tracker: ResourceStateTracker,
) -> Response | None:
    """Handle lifecycle-aware cluster create/delete. Returns None to fall through."""
    if action == "CreateDBCluster" and lc.enabled:
        resp = await handler(state, body)
        if resp.status_code == 200:
            cid = body.get("DBClusterIdentifier", "")
            tracker.set_state(cid, "CREATING")
            tracker.schedule_transition(cid, "ACTIVE", lc.create_dwell_ms)
        return resp
    if action == "DeleteDBCluster" and lc.enabled:
        cid = body.get("DBClusterIdentifier", "")
        guard = _creating_guard(
            cid, "InvalidDBClusterStateFault", "DB cluster", tracker.get_state(cid)
        )
        if guard is not None:
            return guard
        resp = await handler(state, body)
        return apply_delete_lifecycle(resp, cid, lc, tracker)
    return None


async def _rds_dispatch(
    request: Request,
    state: _RdsState,
    lc: ResourceLifecycleConfig,
    instance_tracker: ResourceStateTracker,
    cluster_tracker: ResourceStateTracker,
) -> Response:
    """Route a single RDS request."""
    target = request.headers.get("x-amz-target", "")
    body = await parse_json_body(request)
    action = resolve_api_action(target, body)

    err = _check_rds_instance_lifecycle(action, body, lc, instance_tracker)
    if err is not None:
        return err

    err = _check_rds_cluster_lifecycle(action, body, lc, cluster_tracker)
    if err is not None:
        return err

    handler = _ACTION_HANDLERS.get(action)
    if handler is None:
        _logger.warning("Unknown RDS action: %s", action)
        return _error_response(
            "InvalidAction",
            f"lws: RDS operation '{action}' is not yet implemented",
        )

    result = await _rds_lifecycle_instance(action, handler, state, body, lc, instance_tracker)
    if result is not None:
        return result

    result = await _rds_lifecycle_cluster(action, handler, state, body, lc, cluster_tracker)
    if result is not None:
        return result

    resp = await handler(state, body)
    if action == "DescribeDBInstances" and lc.enabled:
        return _overlay_instance_tracker_state(resp, instance_tracker)
    return resp


def create_rds_app(
    *,
    postgres_container_manager: ResourceContainerManager | None = None,
    mysql_container_manager: ResourceContainerManager | None = None,
    lifecycle: ResourceLifecycleConfig | None = None,
    registry: TrackerRegistry | None = None,
    context: ProviderContext | None = None,
) -> FastAPI:
    """Create a FastAPI application that speaks the RDS wire protocol."""
    _lc = lifecycle or ResourceLifecycleConfig()
    _instance_tracker = ResourceStateTracker(_lc)
    _cluster_tracker = ResourceStateTracker(_lc)
    _snapshot_tracker = ResourceStateTracker(_lc)
    if registry is not None:
        register_tracker(registry, "rds", "instance", _instance_tracker)
        register_tracker(registry, "rds", "cluster", _cluster_tracker)
        register_tracker(registry, "rds", "snapshot", _snapshot_tracker)

    app = FastAPI(title="LDK RDS")
    app.add_middleware(RequestLoggingMiddleware, logger=_logger, service_name="rds")
    state = _RdsState(
        postgres_container_manager=postgres_container_manager,
        mysql_container_manager=mysql_container_manager,
    )

    @app.post("/")
    async def dispatch(request: Request) -> Response:
        return await _rds_dispatch(request, state, _lc, _instance_tracker, _cluster_tracker)

    @app.post("/execute")
    async def execute_statement(request: Request) -> Response:
        body = await parse_json_body(request)
        return await _handle_execute_statement(state, body)

    apply_cloudtrail_middleware(app, context.cloudtrail if context else None, "rds")
    return app
