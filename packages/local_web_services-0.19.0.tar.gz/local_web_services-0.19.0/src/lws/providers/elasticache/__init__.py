"""ElastiCache provider package."""
