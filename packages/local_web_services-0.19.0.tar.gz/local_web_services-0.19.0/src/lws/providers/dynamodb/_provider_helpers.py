"""Helper functions for the DynamoDB provider.

Contains: key extraction, GSI projection, item scanning, batch validation,
stream event key building, and async SQLite/stream ops.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from lws.interfaces import (
    GsiDefinition,
    KeyAttribute,
    TableConfig,
)

if TYPE_CHECKING:
    import aiosqlite

    from lws.providers.dynamodb.streams import StreamDispatcher

# Maximum number of items in a single batch operation (DynamoDB limit)
_MAX_BATCH_SIZE = 25


# ---------------------------------------------------------------------------
# Key extraction helpers
# ---------------------------------------------------------------------------


def _extract_key_value(item: dict, key_attr: KeyAttribute) -> str:
    """Extract and stringify a key value from a DynamoDB-format or plain item.

    Handles both DynamoDB wire format ``{"pk": {"S": "val"}}`` and plain
    ``{"pk": "val"}``.
    """
    raw = item.get(key_attr.name)
    if raw is None:
        return ""
    # DynamoDB-typed value like {"S": "abc"}
    if isinstance(raw, dict) and len(raw) == 1:
        type_key = next(iter(raw))
        if type_key in ("S", "N", "B"):
            return str(raw[type_key])
    return str(raw)


def _extract_key_names(config: TableConfig) -> list[str]:
    """Get all key attribute names for the main table."""
    names = [config.key_schema.partition_key.name]
    if config.key_schema.sort_key:
        names.append(config.key_schema.sort_key.name)
    return names


def _extract_sk(item: dict, config: TableConfig) -> str:
    """Extract the sort key value from an item, or empty string if no SK."""
    if config.key_schema.sort_key:
        return _extract_key_value(item, config.key_schema.sort_key)
    return ""


# ---------------------------------------------------------------------------
# GSI helpers
# ---------------------------------------------------------------------------


async def _create_gsi_tables(conn, gsi_definitions: list) -> None:
    """Create GSI SQLite tables for *gsi_definitions* on *conn* and commit."""
    for gsi in gsi_definitions:
        await conn.execute(
            f"CREATE TABLE IF NOT EXISTS {_gsi_table_name(gsi.index_name)} "
            "(pk TEXT, sk TEXT, table_pk TEXT, table_sk TEXT, item_json TEXT,"
            " PRIMARY KEY (table_pk, table_sk))"
        )
    await conn.commit()


def _gsi_table_name(index_name: str) -> str:
    """Return a double-quoted SQLite identifier for a GSI table.

    Index names may contain hyphens (e.g. 'by-status'), which are invalid in
    unquoted SQLite identifiers.  Wrapping in double-quotes makes them safe.
    """
    return f'"gsi_{index_name}"'


def _project_item_for_gsi(item: dict, gsi: GsiDefinition, table_config: TableConfig) -> str:
    """Project an item according to the GSI projection type.

    Returns the item_json string to store in the GSI table.
    """
    projection = gsi.projection_type.upper()
    if projection == "ALL":
        return json.dumps(item)

    # Always include table keys and GSI keys
    key_attrs = set(_extract_key_names(table_config))
    key_attrs.add(gsi.key_schema.partition_key.name)
    if gsi.key_schema.sort_key:
        key_attrs.add(gsi.key_schema.sort_key.name)

    if projection == "KEYS_ONLY":
        projected = {k: v for k, v in item.items() if k in key_attrs}
        return json.dumps(projected)

    if projection == "INCLUDE":
        # Include specified non-key attributes plus all keys
        # The included attributes are stored as a comma-separated string in the
        # projection_type field as "INCLUDE:attr1,attr2" or we infer from the
        # GsiDefinition. For simplicity, we store the full item but filter on read.
        return json.dumps(item)

    # Default to ALL for unknown projection types
    return json.dumps(item)


def _find_gsi(config: TableConfig, index_name: str) -> GsiDefinition | None:
    """Find a GSI definition by name."""
    for gsi in config.gsi_definitions:
        if gsi.index_name == index_name:
            return gsi
    return None


# ---------------------------------------------------------------------------
# Stream event helpers
# ---------------------------------------------------------------------------


def _build_keys_dict(item: dict, config: TableConfig) -> dict[str, Any]:
    """Build a keys-only dict from an item for stream events."""
    keys: dict[str, Any] = {}
    pk_name = config.key_schema.partition_key.name
    if pk_name in item:
        keys[pk_name] = item[pk_name]
    if config.key_schema.sort_key:
        sk_name = config.key_schema.sort_key.name
        if sk_name in item:
            keys[sk_name] = item[sk_name]
    return keys


# ---------------------------------------------------------------------------
# Batch validation helpers
# ---------------------------------------------------------------------------


def _validate_batch_size(items: list, operation: str) -> None:
    """Validate that a batch doesn't exceed the DynamoDB 25-item limit."""
    if len(items) > _MAX_BATCH_SIZE:
        raise ValueError(
            f"{operation}: batch size {len(items)} exceeds maximum of {_MAX_BATCH_SIZE}"
        )


def _validate_batch_size_count(count: int, operation: str) -> None:
    """Validate that a batch total doesn't exceed the DynamoDB 25-item limit."""
    if count > _MAX_BATCH_SIZE:
        raise ValueError(f"{operation}: batch size {count} exceeds maximum of {_MAX_BATCH_SIZE}")


# ---------------------------------------------------------------------------
# Table description builder
# ---------------------------------------------------------------------------


def build_table_description(config: TableConfig) -> dict:
    """Build an AWS-compatible TableDescription dict."""
    import time  # pylint: disable=import-outside-toplevel

    key_schema = [
        {
            "AttributeName": config.key_schema.partition_key.name,
            "KeyType": "HASH",
        }
    ]
    attr_defs = [
        {
            "AttributeName": config.key_schema.partition_key.name,
            "AttributeType": config.key_schema.partition_key.type,
        }
    ]
    if config.key_schema.sort_key:
        key_schema.append(
            {
                "AttributeName": config.key_schema.sort_key.name,
                "KeyType": "RANGE",
            }
        )
        attr_defs.append(
            {
                "AttributeName": config.key_schema.sort_key.name,
                "AttributeType": config.key_schema.sort_key.type,
            }
        )

    description: dict = {
        "TableName": config.table_name,
        "TableStatus": "ACTIVE",
        "KeySchema": key_schema,
        "AttributeDefinitions": attr_defs,
        "TableArn": f"arn:aws:dynamodb:us-east-1:000000000000:table/{config.table_name}",
        "ItemCount": 0,
        "TableSizeBytes": 0,
        "CreationDateTime": time.time(),
        "ProvisionedThroughput": {
            "ReadCapacityUnits": 0,
            "WriteCapacityUnits": 0,
        },
    }

    if config.gsi_definitions:
        gsis = []
        for gsi in config.gsi_definitions:
            gsi_key_schema = [
                {
                    "AttributeName": gsi.key_schema.partition_key.name,
                    "KeyType": "HASH",
                }
            ]
            gsi_attr = {
                "AttributeName": gsi.key_schema.partition_key.name,
                "AttributeType": gsi.key_schema.partition_key.type,
            }
            if gsi_attr not in attr_defs:
                attr_defs.append(gsi_attr)
            if gsi.key_schema.sort_key:
                gsi_key_schema.append(
                    {
                        "AttributeName": gsi.key_schema.sort_key.name,
                        "KeyType": "RANGE",
                    }
                )
                gsi_sk_attr = {
                    "AttributeName": gsi.key_schema.sort_key.name,
                    "AttributeType": gsi.key_schema.sort_key.type,
                }
                if gsi_sk_attr not in attr_defs:
                    attr_defs.append(gsi_sk_attr)
            gsis.append(
                {
                    "IndexName": gsi.index_name,
                    "KeySchema": gsi_key_schema,
                    "Projection": {"ProjectionType": gsi.projection_type},
                    "IndexStatus": "ACTIVE",
                    "ProvisionedThroughput": {
                        "ReadCapacityUnits": 0,
                        "WriteCapacityUnits": 0,
                    },
                }
            )
        description["GlobalSecondaryIndexes"] = gsis

    if config.stream_enabled:
        stream_arn = (
            f"arn:aws:dynamodb:us-east-1:000000000000:table/{config.table_name}"
            f"/stream/2024-01-01T00:00:00.000"
        )
        description["StreamSpecification"] = {
            "StreamEnabled": True,
            "StreamViewType": config.stream_view_type,
        }
        description["LatestStreamArn"] = stream_arn
        description["LatestStreamLabel"] = "2024-01-01T00:00:00.000"

    return description


# ---------------------------------------------------------------------------
# SQLite connection setup
# ---------------------------------------------------------------------------


async def _setup_table_connection(
    config: TableConfig,
    connections: dict,
    recycled_connections: set,
    data_dir: object,
) -> object:
    """Set up (or reuse) a SQLite connection for a DynamoDB table.

    If the table name exists in ``recycled_connections`` the existing
    connection is reused (fast path used after reset()).  Otherwise a new
    SQLite database file is created and opened.

    Returns the aiosqlite connection object.
    """
    from pathlib import Path  # pylint: disable=import-outside-toplevel

    import aiosqlite  # pylint: disable=import-outside-toplevel

    table_name = config.table_name

    if table_name in recycled_connections:
        # Reuse the connection kept open by reset() – avoids the expensive
        # aiosqlite thread start/stop cycle on every per-test reset.
        recycled_connections.discard(table_name)
        conn = connections[table_name]
        await _create_gsi_tables(conn, config.gsi_definitions)
        return conn

    db_dir = Path(data_dir) / "dynamodb"
    db_dir.mkdir(parents=True, exist_ok=True)
    db_path = db_dir / f"{table_name}.db"
    conn = await aiosqlite.connect(str(db_path))

    await conn.execute("PRAGMA journal_mode=WAL")
    await conn.execute(
        "CREATE TABLE IF NOT EXISTS items "
        "(pk TEXT, sk TEXT, item_json TEXT, PRIMARY KEY (pk, sk))"
    )
    await _create_gsi_tables(conn, config.gsi_definitions)
    return conn


# ---------------------------------------------------------------------------
# Async SQLite and stream ops (used by SqliteDynamoProvider private methods)
# ---------------------------------------------------------------------------


async def fetch_item_json(conn: aiosqlite.Connection, pk: str, sk: str) -> str | None:
    """Fetch raw item JSON from the items table."""
    cursor = await conn.execute(
        "SELECT item_json FROM items WHERE pk = ? AND sk = ?",
        (pk, sk),
    )
    row = await cursor.fetchone()
    return row[0] if row else None


async def update_gsi_entry(
    conn: aiosqlite.Connection,
    gsi: GsiDefinition,
    item: dict,
    table_config: TableConfig,
) -> None:
    """Insert or replace an item in a GSI table with projection support.

    Primary key is (table_pk, table_sk) so that:
    - Multiple items with the same GSI key each get their own row.
    - Re-putting the same table item (even with a changed GSI key) automatically
      replaces the old GSI row via INSERT OR REPLACE.
    """
    gsi_pk = _extract_key_value(item, gsi.key_schema.partition_key)
    if not gsi_pk:
        return  # Item doesn't project into this GSI (sparse index)
    gsi_sk = _extract_key_value(item, gsi.key_schema.sort_key) if gsi.key_schema.sort_key else ""
    table_pk = _extract_key_value(item, table_config.key_schema.partition_key)
    table_sk = _extract_sk(item, table_config)
    projected_json = _project_item_for_gsi(item, gsi, table_config)
    await conn.execute(
        f"INSERT OR REPLACE INTO {_gsi_table_name(gsi.index_name)}"
        " (pk, sk, table_pk, table_sk, item_json) VALUES (?, ?, ?, ?, ?)",
        (gsi_pk, gsi_sk, table_pk, table_sk, projected_json),
    )


async def delete_gsi_entry(
    conn: aiosqlite.Connection,
    gsi: GsiDefinition,
    item: dict,
    table_config: TableConfig,
) -> None:
    """Delete an item from a GSI table by its table primary key."""
    table_pk = _extract_key_value(item, table_config.key_schema.partition_key)
    table_sk = _extract_sk(item, table_config)
    await conn.execute(
        f"DELETE FROM {_gsi_table_name(gsi.index_name)} WHERE table_pk = ? AND table_sk = ?",
        (table_pk, table_sk),
    )


def apply_gsi_projection(config: TableConfig, index_name: str, items: list[dict]) -> list[dict]:
    """Apply GSI projection filtering to query results."""
    gsi = _find_gsi(config, index_name)
    if gsi is None or gsi.projection_type.upper() == "ALL":
        return items

    key_attrs = set(_extract_key_names(config))
    key_attrs.add(gsi.key_schema.partition_key.name)
    if gsi.key_schema.sort_key:
        key_attrs.add(gsi.key_schema.sort_key.name)

    if gsi.projection_type.upper() == "KEYS_ONLY":
        return [{k: v for k, v in item.items() if k in key_attrs} for item in items]

    return items


async def emit_stream_event(
    stream_dispatcher: StreamDispatcher,
    table_name: str,
    new_item: dict,
    old_item_json: str | None,
    config: TableConfig,
) -> None:
    """Emit a stream event for put/update operations."""
    from lws.providers.dynamodb.streams import EventName  # pylint: disable=import-outside-toplevel

    keys = _build_keys_dict(new_item, config)
    old_item = json.loads(old_item_json) if old_item_json else None
    event_name = EventName.MODIFY if old_item else EventName.INSERT
    await stream_dispatcher.emit(
        event_name=event_name,
        table_name=table_name,
        keys=keys,
        new_image=new_item,
        old_image=old_item,
    )


async def emit_delete_stream_event(
    stream_dispatcher: StreamDispatcher,
    table_name: str,
    old_item: dict,
    config: TableConfig,
) -> None:
    """Emit a REMOVE stream event."""
    from lws.providers.dynamodb.streams import EventName  # pylint: disable=import-outside-toplevel

    keys = _build_keys_dict(old_item, config)
    await stream_dispatcher.emit(
        event_name=EventName.REMOVE,
        table_name=table_name,
        keys=keys,
        new_image=None,
        old_image=old_item,
    )
