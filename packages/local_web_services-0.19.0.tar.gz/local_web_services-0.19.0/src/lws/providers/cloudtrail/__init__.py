"""CloudTrail provider package."""
