#!/usr/bin/env python3
"""Benchmark: LLM accuracy WITH vs WITHOUT matrix execution trace.
Proves the matrix renderer eliminates math hallucinations.
Uses claude -p via Max 20x plan (no API key needed).
"""

import subprocess
import json
import os
import sys
import time

# 10 test cases with known ground truth
TEST_CASES = [
    {
        "id": 1,
        "name": "Simple mutations",
        "code": "x = 7\ny = x * 3\nx = y - 5\nz = x + y",
        "question": "What is the value of z?",
        "answer": "37",
    },
    {
        "id": 2,
        "name": "Swap trick",
        "code": "a = 10\nb = 20\na, b = b, a\nc = a - b",
        "question": "What is the value of c?",
        "answer": "10",
    },
    {
        "id": 3,
        "name": "Accumulator loop",
        "code": "total = 0\nfor i in range(5):\n    total += i * i",
        "question": "What is total after the loop?",
        "answer": "30",
    },
    {
        "id": 4,
        "name": "Conditional append",
        "code": "result = []\nfor i in range(7):\n    if i % 3 == 0:\n        result.append(i * 2)\n    else:\n        result.append(i)",
        "question": "What is the final value of result?",
        "answer": "[0, 1, 2, 6, 4, 5, 12]",
    },
    {
        "id": 5,
        "name": "Nested reassignment",
        "code": "x = 1\nfor i in range(4):\n    x = x * 2 + 1",
        "question": "What is x after the loop?",
        "answer": "31",
    },
    {
        "id": 6,
        "name": "Dict counter",
        "code": 'counts = {}\nfor ch in "abracadabra":\n    counts[ch] = counts.get(ch, 0) + 1',
        "question": "What is counts['a']?",
        "answer": "5",
    },
    {
        "id": 7,
        "name": "Stack operations",
        "code": "s = []\ns.append(1)\ns.append(2)\ns.append(3)\ns.pop()\ns.append(4)\ns.pop()\ns.pop()",
        "question": "What is s after all operations?",
        "answer": "[1]",
    },
    {
        "id": 8,
        "name": "Fibonacci manual",
        "code": "a, b = 0, 1\nfor _ in range(8):\n    a, b = b, a + b",
        "question": "What is a after the loop?",
        "answer": "21",
    },
    {
        "id": 9,
        "name": "While with mutation",
        "code": "n = 100\nsteps = 0\nwhile n > 1:\n    if n % 2 == 0:\n        n = n // 2\n    else:\n        n = n * 3 + 1\n    steps += 1",
        "question": "How many steps does it take (value of steps)?",
        "answer": "25",
    },
    {
        "id": 10,
        "name": "List comprehension chain",
        "code": "a = [1, 2, 3, 4, 5]\nb = [x * 2 for x in a]\nc = [x for x in b if x > 4]\nd = sum(c)",
        "question": "What is d?",
        "answer": "24",
    },
]

def get_matrix(code: str) -> str:
    """Generate matrix trace using our engine."""
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from laeka_rational.domains.matrix.engine import trace_execution, trace_loop

    if "for " in code or "while " in code:
        return trace_loop(code)
    return trace_execution(code)

def ask_claude(prompt: str, timeout: int = 30) -> str:
    """Ask Claude via CLI, returns response text."""
    env = {k: v for k, v in os.environ.items() if k != "ANTHROPIC_API_KEY"}
    env["CLAUDE_CODE_DISABLE_HOOKS"] = "1"
    try:
        result = subprocess.run(
            ["claude", "-p", "--no-session-persistence", "--model", "sonnet",
             "--effort", "low", prompt],
            capture_output=True, text=True, timeout=timeout, env=env,
        )
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "(timeout)"
    except Exception as e:
        return f"(error: {e})"

def check_answer(response: str, expected: str) -> bool:
    """Check if the expected answer appears in the response."""
    # Normalize
    expected_clean = expected.strip().replace(" ", "")
    response_clean = response.replace(" ", "").replace("'", "").replace('"', '')
    return expected_clean in response_clean

def run_benchmark():
    print("=" * 70)
    print("  LAEKA MATRIX RENDERER — BENCHMARK")
    print("  LLM accuracy: raw code vs. matrix trace")
    print("=" * 70)
    print()

    results = {"raw": [], "matrix": []}

    for tc in TEST_CASES:
        print(f"  Test {tc['id']}/10: {tc['name']}...")

        # Generate matrix
        matrix = get_matrix(tc["code"])

        # Prompt WITHOUT matrix
        raw_prompt = (
            f"Answer with ONLY the value, nothing else.\n\n"
            f"```python\n{tc['code']}\n```\n\n"
            f"Question: {tc['question']}"
        )

        # Prompt WITH matrix
        matrix_prompt = (
            f"Answer with ONLY the value, nothing else.\n\n"
            f"```python\n{tc['code']}\n```\n\n"
            f"Execution trace:\n```\n{matrix}\n```\n\n"
            f"Question: {tc['question']}"
        )

        # Ask both
        raw_response = ask_claude(raw_prompt)
        matrix_response = ask_claude(matrix_prompt)

        raw_correct = check_answer(raw_response, tc["answer"])
        matrix_correct = check_answer(matrix_response, tc["answer"])

        results["raw"].append(raw_correct)
        results["matrix"].append(matrix_correct)

        raw_icon = "✓" if raw_correct else "✗"
        matrix_icon = "✓" if matrix_correct else "✗"

        print(f"    Raw: {raw_icon} ({raw_response[:50]})")
        print(f"    Matrix: {matrix_icon} ({matrix_response[:50]})")
        print()

    # Summary
    raw_score = sum(results["raw"])
    matrix_score = sum(results["matrix"])

    print("=" * 70)
    print("  RESULTS")
    print("=" * 70)
    print()
    print(f"  {'Test':<30} {'Raw':>8} {'Matrix':>8}")
    print(f"  {'─' * 46}")
    for i, tc in enumerate(TEST_CASES):
        raw_icon = "✓" if results["raw"][i] else "✗"
        matrix_icon = "✓" if results["matrix"][i] else "✗"
        print(f"  {tc['name']:<30} {raw_icon:>8} {matrix_icon:>8}")
    print(f"  {'─' * 46}")
    print(f"  {'TOTAL':.<30} {raw_score:>7}/10 {matrix_score:>7}/10")
    print(f"  {'ACCURACY':.<30} {raw_score*10:>7}% {matrix_score*10:>7}%")
    print()

    if matrix_score > raw_score:
        delta = matrix_score - raw_score
        print(f"  Matrix renderer improved accuracy by +{delta*10}%")
    elif matrix_score == raw_score == 10:
        print(f"  Both perfect — try harder test cases!")

    print()
    print("=" * 70)

    # Save results
    with open(os.path.join(os.path.dirname(__file__), "results.json"), "w") as f:
        json.dump({
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "model": "claude-sonnet-4-6",
            "test_cases": len(TEST_CASES),
            "raw_score": raw_score,
            "matrix_score": matrix_score,
            "raw_accuracy": f"{raw_score*10}%",
            "matrix_accuracy": f"{matrix_score*10}%",
            "delta": f"+{(matrix_score - raw_score)*10}%",
            "details": [
                {
                    "name": tc["name"],
                    "expected": tc["answer"],
                    "raw_correct": results["raw"][i],
                    "matrix_correct": results["matrix"][i],
                }
                for i, tc in enumerate(TEST_CASES)
            ]
        }, f, indent=2)

    print(f"  Results saved to benchmark/results.json")

if __name__ == "__main__":
    run_benchmark()
