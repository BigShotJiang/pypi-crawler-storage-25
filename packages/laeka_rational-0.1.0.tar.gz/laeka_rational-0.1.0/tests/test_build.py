"""Tests for Build config domain — resolve and diagnose."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.build.engine import build_resolve, build_diagnose


# ── build_resolve ───────────────────────────────────────────────

def test_tsconfig_paths_no_baseurl():
    config = '{ "compilerOptions": { "paths": { "@/*": ["./src/*"] } } }'
    result = build_resolve(config, "tsconfig")
    assert result["issues_found"] > 0
    assert any("baseUrl" in i["message"] for i in result["issues"])

def test_tsconfig_no_strict():
    config = '{ "compilerOptions": { "target": "ES2020" } }'
    result = build_resolve(config, "tsconfig")
    assert any("strict" in s for s in result["suggestions"])

def test_tsconfig_old_target():
    config = '{ "compilerOptions": { "target": "es5", "strict": true } }'
    result = build_resolve(config, "tsconfig")
    assert any("ES5" in s or "es5" in s.lower() for s in result["suggestions"])

def test_tailwind_no_content():
    config = 'module.exports = { theme: { extend: {} } }'
    result = build_resolve(config, "tailwind")
    assert result["issues_found"] > 0
    assert any("content" in i["message"].lower() for i in result["issues"])

def test_tailwind_with_content():
    config = "module.exports = { content: ['./src/**/*.tsx'], theme: {} }"
    result = build_resolve(config, "tailwind")
    # No content error
    assert not any("content" in i.get("message", "").lower() for i in result["issues"]
                    if "not configured" in i.get("message", "").lower())

def test_package_json_no_type():
    config = '{ "name": "my-app", "version": "1.0.0" }'
    result = build_resolve(config, "package.json")
    assert any("type" in s.lower() for s in result["suggestions"])

def test_relevant_gotchas_returned():
    config = '{ "compilerOptions": {} }'
    result = build_resolve(config, "tsconfig")
    assert len(result["relevant_gotchas"]) > 0

def test_config_type_alias():
    config = '{ "compilerOptions": {} }'
    result = build_resolve(config, "tsconfig.json")
    assert result["config_type"] == "tsconfig"


# ── build_diagnose ──────────────────────────────────────────────

def test_diagnose_path_alias():
    result = build_diagnose("Cannot find module '@/components/Button'")
    assert result["matches_found"] > 0
    assert any("alias" in d["title"].lower() for d in result["diagnosis"])

def test_diagnose_esm_cjs():
    result = build_diagnose("Cannot use import statement outside a module")
    assert result["matches_found"] > 0
    assert any("esm" in d["title"].lower() or "cjs" in d["title"].lower() for d in result["diagnosis"])

def test_diagnose_require_esm():
    result = build_diagnose("ERR_REQUIRE_ESM")
    assert result["matches_found"] > 0

def test_diagnose_window_not_defined():
    result = build_diagnose("ReferenceError: window is not defined")
    assert result["matches_found"] > 0
    assert any("server" in d["title"].lower() or "browser" in d["title"].lower() for d in result["diagnosis"])

def test_diagnose_hydration():
    result = build_diagnose("Hydration failed because text content does not match server-rendered HTML")
    assert result["matches_found"] > 0
    assert any("hydration" in d["title"].lower() for d in result["diagnosis"])

def test_diagnose_chunk_error():
    result = build_diagnose("ChunkLoadError: Loading chunk vendors failed")
    assert result["matches_found"] > 0

def test_diagnose_oom():
    result = build_diagnose("FATAL ERROR: Reached heap limit Allocation failed - JavaScript heap out of memory")
    assert result["matches_found"] > 0

def test_diagnose_peer_deps():
    result = build_diagnose("ERESOLVE could not resolve dependency peer dep conflict")
    assert result["matches_found"] > 0

def test_diagnose_next_image():
    result = build_diagnose("Error: Invalid src prop on next/image, hostname not configured")
    assert result["matches_found"] > 0

def test_diagnose_no_match():
    result = build_diagnose("completely unknown error xyz123abc")
    assert result["matches_found"] == 0
    assert "debug_steps" in result


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
