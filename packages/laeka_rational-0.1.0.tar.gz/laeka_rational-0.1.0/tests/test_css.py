"""Tests for CSS domain — specificity calculator and diagnostic engine."""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.css.specificity import calculate_specificity, Specificity, compare_specificity
from laeka_rational.domains.css.diagnose import diagnose, get_gotchas_for_property


# ── Specificity Calculator ──────────────────────────────────────

def test_element_selector():
    assert calculate_specificity("div").as_tuple() == (0, 0, 0, 1)

def test_class_selector():
    assert calculate_specificity(".nav").as_tuple() == (0, 0, 1, 0)

def test_id_selector():
    assert calculate_specificity("#header").as_tuple() == (0, 1, 0, 0)

def test_combined():
    # div#header .nav a.link:hover
    spec = calculate_specificity("div#header .nav a.link:hover")
    assert spec.ids == 1
    assert spec.classes == 3  # .nav, .link, :hover
    assert spec.elements == 2  # div, a

def test_pseudo_element():
    spec = calculate_specificity("p::before")
    assert spec.as_tuple() == (0, 0, 0, 2)  # p + ::before

def test_attribute_selector():
    spec = calculate_specificity("input[type='text']")
    assert spec.classes == 1  # [type='text']
    assert spec.elements == 1  # input

def test_where_zero():
    spec = calculate_specificity(":where(.foo, #bar)")
    assert spec.as_tuple() == (0, 0, 0, 0)

def test_not_takes_argument():
    spec = calculate_specificity(":not(#foo)")
    assert spec.ids == 1

def test_is_takes_argument():
    spec = calculate_specificity(":is(.foo, #bar)")
    # :is takes the most specific argument → #bar = 1 id
    assert spec.ids == 1

def test_has_takes_argument():
    spec = calculate_specificity("div:has(.active)")
    assert spec.elements == 1  # div
    assert spec.classes == 1  # .active from :has

def test_universal_zero():
    spec = calculate_specificity("*")
    assert spec.as_tuple() == (0, 0, 0, 0)

def test_complex_real_world():
    # Real-world Tailwind-like: .container > .flex > .item
    spec = calculate_specificity(".container > .flex > .item")
    assert spec.as_tuple() == (0, 0, 3, 0)

def test_comparison():
    assert calculate_specificity("#nav .item") > calculate_specificity(".nav .item")
    assert calculate_specificity("div") < calculate_specificity(".class")


# ── Compare Specificity ─────────────────────────────────────────

def test_compare():
    result = compare_specificity("#nav a", ".nav a")
    assert result["winner"] == "#nav a"

def test_compare_equal():
    result = compare_specificity(".a", ".b")
    assert "equal" in result["winner"]


# ── Diagnose ────────────────────────────────────────────────────

def test_diagnose_margin_collapse():
    result = diagnose(None, "margin disappears between parent and child")
    assert result["matches_found"] > 0
    assert any("margin-collapse" in g["id"] for g in result["diagnosis"])

def test_diagnose_sticky():
    result = diagnose(None, "sticky header not sticking")
    assert result["matches_found"] > 0
    assert any("sticky" in g["id"] for g in result["diagnosis"])

def test_diagnose_z_index():
    result = diagnose(".modal", "z-index not working, modal is behind overlay")
    assert result["matches_found"] > 0
    assert "specificity" in result

def test_diagnose_flex_overflow():
    result = diagnose(None, "flex item won't shrink, text overflow")
    assert result["matches_found"] > 0

def test_diagnose_tailwind():
    result = diagnose(None, "tailwind class not applying, color override not working")
    assert result["matches_found"] > 0
    assert any("tailwind" in g["id"] for g in result["diagnosis"])

def test_diagnose_ellipsis():
    result = diagnose(None, "text-overflow ellipsis not showing")
    assert result["matches_found"] > 0

def test_diagnose_100vh():
    result = diagnose(None, "100vh too tall on mobile")
    assert result["matches_found"] > 0

def test_diagnose_no_match():
    result = diagnose(None, "completely unrelated gibberish xyz123")
    assert result["matches_found"] == 0
    assert "debug_steps" in result


# ── Gotchas by Property ─────────────────────────────────────────

def test_gotchas_margin():
    result = get_gotchas_for_property("margin")
    assert result["gotchas_found"] > 0

def test_gotchas_z_index():
    result = get_gotchas_for_property("z-index")
    assert result["gotchas_found"] > 0

def test_gotchas_position():
    result = get_gotchas_for_property("position")
    assert result["gotchas_found"] > 0

def test_gotchas_grid():
    result = get_gotchas_for_property("grid")
    assert result["gotchas_found"] > 0


if __name__ == "__main__":
    # Run all tests manually
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
