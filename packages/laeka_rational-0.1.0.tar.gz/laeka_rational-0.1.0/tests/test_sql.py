"""Tests for SQL domain — explain, migration check, index suggestion."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.sql.engine import sql_explain, sql_migration_check, sql_suggest_index


# ── sql_explain ─────────────────────────────────────────────────

def test_detect_select():
    result = sql_explain("SELECT id, name FROM users WHERE active = true")
    assert result["operation"] == "SELECT"
    assert "users" in result["tables"]

def test_warn_select_star():
    result = sql_explain("SELECT * FROM users")
    assert any("SELECT *" in w for w in result["warnings"])

def test_warn_null_comparison():
    result = sql_explain("SELECT * FROM users WHERE email = NULL")
    assert any("NULL" in w for w in result["warnings"])

def test_warn_offset():
    result = sql_explain("SELECT id FROM posts ORDER BY created_at OFFSET 10000 LIMIT 20")
    assert any("OFFSET" in w for w in result["warnings"])

def test_warn_leading_wildcard():
    result = sql_explain("SELECT * FROM products WHERE name LIKE '%widget%'")
    assert any("LIKE" in w or "%" in w for w in result["warnings"])

def test_detect_join():
    result = sql_explain("SELECT u.name, o.total FROM users u JOIN orders o ON u.id = o.user_id")
    assert "users" in result["tables"]
    assert "orders" in result["tables"]

def test_multiple_joins_warning():
    query = """
    SELECT * FROM a
    JOIN b ON a.id = b.a_id
    JOIN c ON b.id = c.b_id
    JOIN d ON c.id = d.c_id
    JOIN e ON d.id = e.d_id
    """
    result = sql_explain(query)
    assert any("JOIN" in w for w in result["warnings"])

def test_not_in_warning():
    result = sql_explain("SELECT id FROM users WHERE id NOT IN (SELECT user_id FROM blocked)")
    assert any("NOT IN" in w for w in result["warnings"])


# ── sql_migration_check ─────────────────────────────────────────

def test_migration_not_null_no_default():
    result = sql_migration_check("ALTER TABLE users ADD COLUMN status varchar(20) NOT NULL")
    assert result["risks_found"] > 0
    assert any("NOT NULL" in r["title"] for r in result["risks"])

def test_migration_create_index_no_concurrent():
    result = sql_migration_check("CREATE INDEX idx_users_email ON users (email)")
    assert result["risks_found"] > 0
    assert any("index" in r["title"].lower() for r in result["risks"])

def test_migration_create_index_concurrent_safe():
    result = sql_migration_check("CREATE INDEX CONCURRENTLY idx_users_email ON users (email)")
    # Should not flag concurrent index
    assert not any("index" in r["title"].lower() for r in result["risks"])

def test_migration_drop_table():
    result = sql_migration_check("DROP TABLE old_logs")
    assert any(r["risk"] == "critical" for r in result["risks"])

def test_migration_rename_column():
    result = sql_migration_check("ALTER TABLE users RENAME COLUMN name TO full_name")
    assert any("rename" in r["title"].lower() for r in result["risks"])

def test_migration_safe():
    result = sql_migration_check("ALTER TABLE users ADD COLUMN bio text")
    # Adding a nullable column is safe
    assert result["safe"]

def test_migration_fk():
    result = sql_migration_check("ALTER TABLE orders ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id)")
    assert any("foreign key" in r["title"].lower() for r in result["risks"])

def test_migration_truncate():
    result = sql_migration_check("TRUNCATE TABLE sessions")
    assert any(r["risk"] == "critical" for r in result["risks"])


# ── sql_suggest_index ───────────────────────────────────────────

def test_index_where():
    result = sql_suggest_index("SELECT * FROM users WHERE email = 'test@test.com' AND active = true")
    assert result["suggestions_found"] > 0
    assert any(s["type"] == "WHERE clause" for s in result["suggestions"])

def test_index_join():
    result = sql_suggest_index("SELECT * FROM users u JOIN orders o ON u.id = o.user_id WHERE u.active = true")
    assert any(s["type"] == "JOIN" for s in result["suggestions"])

def test_index_order_by():
    result = sql_suggest_index("SELECT * FROM posts WHERE user_id = 1 ORDER BY created_at DESC")
    assert any(s["type"] == "ORDER BY" for s in result["suggestions"])

def test_index_composite():
    result = sql_suggest_index("SELECT * FROM posts WHERE user_id = 1 ORDER BY created_at DESC")
    assert any(s["type"] == "Composite" for s in result["suggestions"])

def test_index_like_wildcard():
    result = sql_suggest_index("SELECT * FROM products WHERE name LIKE '%widget%'")
    assert any("trigram" in s["type"].lower() or "trgm" in s.get("suggestion", "").lower()
               for s in result["suggestions"])


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
