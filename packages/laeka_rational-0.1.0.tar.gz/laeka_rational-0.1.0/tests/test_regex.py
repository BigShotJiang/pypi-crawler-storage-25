"""Tests for Regex domain — test, explain, and build engines."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.regex.engine import regex_test, regex_explain, regex_build


# ── regex_test ──────────────────────────────────────────────────

def test_simple_match():
    result = regex_test(r"\d+", ["abc 123 def", "no digits"])
    assert result["valid"]
    assert result["results"][0]["matched"]
    assert result["results"][0]["matches"][0]["match"] == "123"
    assert not result["results"][1]["matched"]

def test_captures():
    result = regex_test(r"(\d{4})-(\d{2})-(\d{2})", ["2024-01-15"])
    assert result["valid"]
    groups = result["results"][0]["matches"][0]["groups"]
    assert groups == ["2024", "01", "15"]

def test_named_groups():
    result = regex_test(r"(?P<year>\d{4})-(?P<month>\d{2})", ["2024-01"])
    assert result["valid"]
    named = result["results"][0]["matches"][0]["named_groups"]
    assert named["year"] == "2024"
    assert named["month"] == "01"

def test_invalid_pattern():
    result = regex_test(r"(unclosed", ["test"])
    assert not result["valid"]
    assert "error" in result
    assert "suggestion" in result

def test_flags():
    result = regex_test(r"hello", ["HELLO world"], flags="i")
    assert result["results"][0]["matched"]

def test_multiple_matches():
    result = regex_test(r"\b\w+\b", ["one two three"])
    assert result["results"][0]["match_count"] == 3

def test_no_match():
    result = regex_test(r"\d+", ["no digits here"])
    assert result["results"][0]["match_count"] == 0
    assert not result["results"][0]["matched"]

def test_span_positions():
    result = regex_test(r"world", ["hello world"])
    span = result["results"][0]["matches"][0]["span"]
    assert span == [6, 11]


# ── regex_explain ───────────────────────────────────────────────

def test_explain_simple():
    result = regex_explain(r"\d+")
    assert result["valid"]
    assert len(result["breakdown"]) >= 2  # \d and +

def test_explain_groups():
    result = regex_explain(r"(?P<name>\w+)")
    assert result["valid"]
    tokens = result["breakdown"]
    # Should contain a named group token
    assert any("named group" in t["meaning"] for t in tokens)

def test_explain_character_class():
    result = regex_explain(r"[a-zA-Z]")
    assert result["valid"]
    assert any("one of" in t["meaning"] for t in result["breakdown"])

def test_explain_invalid():
    result = regex_explain(r"(unclosed")
    assert not result["valid"]

def test_explain_lookahead():
    result = regex_explain(r"foo(?=bar)")
    assert result["valid"]
    assert any("lookahead" in t["meaning"] for t in result["breakdown"])

def test_explain_anchors():
    result = regex_explain(r"^\d+$")
    tokens = result["breakdown"]
    meanings = [t["meaning"] for t in tokens]
    assert any("start" in m for m in meanings)
    assert any("end" in m for m in meanings)

def test_explain_warns_greedy():
    result = regex_explain(r"<.*>")
    assert result["valid"]
    # Should warn about greedy matching
    if "warnings" in result:
        assert any("greedy" in w.get("id", "").lower() or "greedy" in w.get("trigger", "").lower()
                    for w in result["warnings"])


# ── regex_build ─────────────────────────────────────────────────

def test_build_email():
    result = regex_build("email address")
    assert result["suggestions_found"] > 0
    assert any(s["name"] == "email" for s in result["suggestions"])

def test_build_url():
    result = regex_build("match a URL")
    assert result["suggestions_found"] > 0
    assert any(s["name"] == "url" for s in result["suggestions"])

def test_build_date():
    result = regex_build("ISO date format")
    assert result["suggestions_found"] > 0

def test_build_with_test():
    result = regex_build("email", test_strings=["user@example.com", "not-an-email"])
    suggestions = result["suggestions"]
    assert len(suggestions) > 0
    # First test string should match
    email_sug = [s for s in suggestions if s["name"] == "email"][0]
    assert email_sug["test_results"][0]["matched"]

def test_build_no_match():
    result = regex_build("completely unknown pattern type xyz123")
    assert result["suggestions_found"] == 0
    assert "tip" in result

def test_build_uuid():
    result = regex_build("uuid", test_strings=["550e8400-e29b-41d4-a716-446655440000"])
    assert result["suggestions_found"] > 0
    uuid_sug = [s for s in result["suggestions"] if s["name"] == "uuid"][0]
    assert uuid_sug["test_results"][0]["matched"]

def test_build_phone():
    result = regex_build("phone number")
    assert result["suggestions_found"] > 0


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
