"""Tests for Refactoring domain — impact analysis and rename planning."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.refactor.engine import refactor_impact, refactor_rename_plan


# ── Sample source code ──────────────────────────────────────────

SAMPLE_FILES = {
    "src/components/Button.tsx": """import React from 'react';
import { ButtonProps } from '../types';

export function Button({ label, onClick }: ButtonProps) {
  return <button onClick={onClick}>{label}</button>;
}

export default Button;
""",
    "src/components/index.ts": """export { Button } from './Button';
export { Input } from './Input';
""",
    "src/pages/Home.tsx": """import { Button } from '../components';
import type { ButtonProps } from '../types';

export function Home() {
  return <Button label="Click me" onClick={() => {}} />;
}
""",
    "src/types/index.ts": """export interface ButtonProps {
  label: string;
  onClick: () => void;
}
""",
    "tests/Button.test.tsx": """import { Button } from '../src/components/Button';

describe('Button', () => {
  it('renders label', () => {
    const { getByText } = render(<Button label="Test" onClick={() => {}} />);
    expect(getByText('Test')).toBeInTheDocument();
  });
});
""",
    "src/api/routes.ts": """const routes = {
  'Button': '/api/button',
};
""",
}


# ── refactor_impact ─────────────────────────────────────────────

def test_impact_without_source():
    result = refactor_impact("Button")
    assert "import_patterns" in result
    assert "usage_patterns" in result
    assert "grep_command" in result
    assert len(result["import_patterns"]) > 0

def test_impact_with_source():
    result = refactor_impact("Button", SAMPLE_FILES)
    assert result["files_impacted"] > 0
    assert result["total_references"] > 0
    # Should find Button in multiple files
    impacted_files = [i["file"] for i in result["impacts"]]
    assert "src/components/Button.tsx" in impacted_files
    assert "src/components/index.ts" in impacted_files
    assert "src/pages/Home.tsx" in impacted_files

def test_impact_finds_jsx():
    result = refactor_impact("Button", SAMPLE_FILES)
    # Should find JSX usage <Button
    home_impact = [i for i in result["impacts"] if i["file"] == "src/pages/Home.tsx"][0]
    jsx_refs = [r for r in home_impact["references"] if r["type"] == "jsx_component"]
    assert len(jsx_refs) > 0

def test_impact_finds_type_import():
    result = refactor_impact("ButtonProps", SAMPLE_FILES)
    assert result["files_impacted"] > 0
    # Should find in Home.tsx (import type)
    home_impact = [i for i in result["impacts"] if i["file"] == "src/pages/Home.tsx"]
    assert len(home_impact) > 0

def test_impact_finds_string_reference():
    result = refactor_impact("Button", SAMPLE_FILES)
    route_impact = [i for i in result["impacts"] if i["file"] == "src/api/routes.ts"]
    assert len(route_impact) > 0
    # Should detect string reference
    string_refs = [r for r in route_impact[0]["references"] if r["type"] == "string_reference"]
    assert len(string_refs) > 0

def test_impact_returns_gotchas():
    result = refactor_impact("Button")
    assert "gotchas" in result
    assert len(result["gotchas"]) > 0


# ── refactor_rename_plan ────────────────────────────────────────

def test_rename_without_source():
    result = refactor_rename_plan("Button", "PrimaryButton")
    assert "grep_command" in result
    assert "replacement_rules" in result
    assert len(result["warnings"]) > 0

def test_rename_with_source():
    result = refactor_rename_plan("Button", "PrimaryButton", SAMPLE_FILES)
    assert result["files_to_modify"] > 0
    assert result["total_changes"] > 0
    # Check that changes show before/after
    first_file = result["plan"][0]
    first_change = first_file["changes"][0]
    assert "before" in first_change
    assert "after" in first_change
    assert "Button" in first_change["before"]
    assert "PrimaryButton" in first_change["after"]

def test_rename_covers_all_files():
    result = refactor_rename_plan("Button", "PrimaryButton", SAMPLE_FILES)
    modified_files = [c["file"] for c in result["plan"]]
    assert "src/components/Button.tsx" in modified_files
    assert "src/components/index.ts" in modified_files
    assert "src/pages/Home.tsx" in modified_files
    assert "tests/Button.test.tsx" in modified_files

def test_rename_warns_uppercase():
    result = refactor_rename_plan("Button", "PrimaryButton")
    assert any("JSX" in w or "component" in w for w in result["warnings"])

def test_rename_warns_strings():
    result = refactor_rename_plan("myFunction", "myBetterFunction")
    assert any("string" in w.lower() for w in result["warnings"])

def test_rename_warns_barrel():
    result = refactor_rename_plan("Button", "PrimaryButton")
    assert any("barrel" in w.lower() for w in result["warnings"])

def test_rename_preserves_context():
    # Renaming should not introduce false positives
    files = {
        "a.ts": "const ButtonGroup = 'test';\nconst Button = 'hello';",
    }
    result = refactor_rename_plan("Button", "Btn", files)
    # Should match both Button and ButtonGroup (word boundary handles this)
    changes = result["plan"][0]["changes"]
    # "Button" standalone should be renamed, "ButtonGroup" should not
    for c in changes:
        if "ButtonGroup" in c["before"]:
            assert "BtnGroup" not in c["after"]  # Word boundary prevents partial match


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
