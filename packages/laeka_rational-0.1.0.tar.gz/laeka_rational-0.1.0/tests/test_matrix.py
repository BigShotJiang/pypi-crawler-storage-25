"""Tests for Matrix execution tracer domain."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.matrix.engine import trace_execution, trace_loop, trace_function


# ── trace_execution ────────────────────────────────────────────

def test_simple_assignments():
    """5 variables, 8 mutations — the bread and butter."""
    code = """
x = 1
y = 2
z = x + y
x = 10
y = x * 2
z = x + y
w = z - x
x = w
    """
    result = trace_execution(code)
    assert "*1*" in result  # x starts at 1
    assert "*10*" in result  # x changes to 10
    assert "*20*" in result  # y = 10 * 2
    assert "*30*" in result  # z = 10 + 20
    assert "x" in result
    assert "y" in result
    assert "z" in result
    assert "w" in result


def test_change_markers():
    """Changed values get *asterisks*, unchanged don't."""
    code = """
x = 5
y = x + 3
x = y * 2
    """
    result = trace_execution(code)
    # x=5 should be marked as changed on first appearance
    assert "*5*" in result
    # After x=5, when y is assigned, x should NOT be re-marked
    lines = result.strip().split("\n")
    # Find the line where y=8 appears — x should be plain 5 there
    for line in lines:
        if "*8*" in line and "y = x + 3" in line:
            # x should be unmarked (just "5", not "*5*")
            # This is checked implicitly by the matrix format
            break


def test_loop_for_with_condition():
    """For loop with if/else inside."""
    code = """
result = []
for i in range(5):
    if i % 2 == 0:
        result.append(i * 2)
    else:
        result.append(i)
    """
    result = trace_execution(code)
    assert "result" in result
    assert "i" in result


def test_loop_while_mutation():
    """While loop where the condition variable mutates."""
    code = """
n = 10
total = 0
while n > 0:
    total = total + n
    n = n - 1
    """
    result = trace_loop(code)
    assert "iter" in result.lower() or "0" in result
    # Should see n decreasing
    assert "n" in result
    assert "total" in result


def test_list_append_pop():
    """List with append and pop."""
    code = """
items = []
items.append('a')
items.append('b')
items.append('c')
items.pop()
items.append('d')
    """
    result = trace_execution(code)
    assert "items" in result
    assert "'a'" in result or '"a"' in result


def test_dict_operations():
    """Dict with add and delete keys."""
    code = """
d = {}
d['x'] = 1
d['y'] = 2
d['z'] = 3
del d['y']
d['x'] = 99
    """
    result = trace_execution(code)
    assert "d" in result
    assert "99" in result


def test_function_return():
    """Function with return value traced."""
    code = """
def add(a, b):
    result = a + b
    return result
    """
    result = trace_function(code, "add", "3, 4")
    assert "a" in result
    assert "b" in result
    assert "7" in result


def test_variable_reassigned_5_times():
    """Variable reassigned 5 times — each change should show."""
    code = """
x = 1
x = x + 1
x = x * 2
x = x - 1
x = x ** 2
    """
    result = trace_execution(code)
    assert "*1*" in result
    assert "*2*" in result
    assert "*4*" in result
    assert "*3*" in result
    assert "*9*" in result


# ── trace_loop ─────────────────────────────────────────────────

def test_loop_cap():
    """Should cap at max_iterations."""
    code = """
i = 0
while True:
    i += 1
    """
    result = trace_loop(code, max_iterations=5)
    assert "Capped" in result or "cap" in result.lower()


def test_loop_for_simple():
    """Simple for loop traced."""
    code = """
total = 0
for i in range(5):
    total += i
    """
    result = trace_loop(code)
    assert "total" in result
    assert "i" in result


def test_no_loop_error():
    """Code without a loop should return helpful message."""
    code = """
x = 1
y = 2
    """
    result = trace_loop(code)
    assert "No loop" in result


# ── trace_function ─────────────────────────────────────────────

def test_function_recursion():
    """Recursive function should show depth."""
    code = """
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)
    """
    result = trace_function(code, "factorial", "4")
    assert "n" in result
    assert "depth" in result.lower() or "1" in result


def test_function_not_found():
    """Missing function name should error clearly."""
    code = """
def foo():
    return 1
    """
    result = trace_function(code, "bar", "")
    assert "not found" in result.lower()


def test_security_no_open():
    """Blocked builtins should not be accessible."""
    code = """
f = open('/etc/passwd')
    """
    result = trace_execution(code)
    # Should fail — open is blocked
    assert "Error" in result or "error" in result.lower() or "NameError" in result


def test_security_no_import():
    """__import__ should be blocked."""
    code = """
os = __import__('os')
    """
    result = trace_execution(code)
    assert "Error" in result or "error" in result.lower() or "NameError" in result


def test_timeout_infinite_loop():
    """Infinite loop without trace_loop should timeout."""
    code = """
while True:
    pass
    """
    result = trace_execution(code)
    assert "timed out" in result.lower() or "timeout" in result.lower()


def test_syntax_error():
    """Bad syntax should return clear error."""
    result = trace_execution("def f(:\n  pass")
    assert "SyntaxError" in result


def test_non_python_language():
    """Non-python language should return clear error."""
    result = trace_execution("console.log('hi')", language="javascript")
    assert "only Python" in result


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
