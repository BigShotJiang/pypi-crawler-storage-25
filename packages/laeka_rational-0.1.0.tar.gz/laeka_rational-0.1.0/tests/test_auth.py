"""Tests for Auth domain — validate flows and diagnose issues."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.auth.engine import auth_validate_flow, auth_diagnose


# ── auth_validate_flow ──────────────────────────────────────────

def test_validate_oauth_complete():
    flow = """
    User clicks Google login. We redirect to Google authorization endpoint with
    client_id, redirect_uri, response_type=code, scope=openid email, and a random
    state parameter. Google redirects back with authorization code. Our server
    exchanges the code for tokens at the token endpoint using client_secret.
    We validate and store tokens in httpOnly cookies.
    """
    result = auth_validate_flow(flow)
    assert result["flow_type"] == "oauth-authorization-code"
    assert result["completeness"] >= 60
    assert len(result["steps_present"]) > 0

def test_validate_oauth_incomplete():
    flow = "User clicks login, we get a token from Google"
    result = auth_validate_flow(flow)
    assert result["completeness"] < 80
    assert len(result["steps_missing"]) > 0

def test_validate_jwt():
    flow = """
    User submits email/password. We validate credentials, generate a JWT with
    sub, iat, exp claims, sign with RS256, set 15 minute expiration.
    JWT is returned in httpOnly cookie. On each request, we validate signature,
    expiration, issuer.
    """
    result = auth_validate_flow(flow)
    assert result["flow_type"] == "jwt-auth"
    assert result["completeness"] >= 60

def test_validate_pkce():
    flow = """
    SPA generates code_verifier and code_challenge with SHA256. Redirect to
    OAuth provider with code_challenge and state parameter. Receive code at
    callback, exchange with code_verifier for tokens.
    """
    result = auth_validate_flow(flow)
    assert result["flow_type"] == "oauth-pkce"
    assert result["completeness"] >= 40

def test_validate_session():
    flow = """
    Authenticate user with password comparison. Create session in Redis.
    Set session ID in httpOnly Secure SameSite cookie. Validate session on
    each request. Regenerate session ID after login.
    """
    result = auth_validate_flow(flow)
    assert result["flow_type"] == "session-auth"
    assert result["completeness"] >= 60

def test_validate_returns_gotchas():
    flow = "JWT auth with token"
    result = auth_validate_flow(flow)
    assert len(result["security_gotchas"]) > 0

def test_validate_verdict():
    # Minimal flow should get "minimal" or "incomplete" verdict
    result = auth_validate_flow("login")
    assert result["verdict"] in ("minimal", "incomplete")


# ── auth_diagnose ───────────────────────────────────────────────

def test_diagnose_401():
    result = auth_diagnose("Getting 401 Unauthorized on API call")
    assert result["matches_found"] > 0
    assert any("401" in d["id"] or "jwt" in d["id"] for d in result["diagnosis"])

def test_diagnose_cors():
    result = auth_diagnose("CORS error when sending credentials cross-origin")
    assert result["matches_found"] > 0
    assert any("cors" in d["id"] for d in result["diagnosis"])

def test_diagnose_cookie_not_set():
    result = auth_diagnose("Cookie not being set on cross-site request")
    assert result["matches_found"] > 0
    assert any("cookie" in d["id"] or "samesite" in d["id"] for d in result["diagnosis"])

def test_diagnose_xss():
    result = auth_diagnose("worried about XSS stealing our JWT from localStorage")
    assert result["matches_found"] > 0
    assert any("localstorage" in d["id"] or "httponly" in d["id"] for d in result["diagnosis"])

def test_diagnose_csrf():
    result = auth_diagnose("CSRF attack on our OAuth flow")
    assert result["matches_found"] > 0
    assert any("csrf" in d["id"] or "state" in d["id"] for d in result["diagnosis"])

def test_diagnose_refresh():
    result = auth_diagnose("refresh token stolen, attacker has persistent access")
    assert result["matches_found"] > 0
    assert any("refresh" in d["id"] or "rotation" in d["id"] for d in result["diagnosis"])

def test_diagnose_redirect():
    result = auth_diagnose("open redirect vulnerability in OAuth callback")
    assert result["matches_found"] > 0
    assert any("redirect" in d["id"] for d in result["diagnosis"])

def test_diagnose_no_match():
    result = auth_diagnose("completely unrelated gibberish xyz123")
    assert result["matches_found"] == 0
    assert "debug_steps" in result

def test_diagnose_timing():
    result = auth_diagnose("timing attack on token comparison")
    assert result["matches_found"] > 0
    assert any("timing" in d["id"] for d in result["diagnosis"])


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
