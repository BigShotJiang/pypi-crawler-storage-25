"""Tests for the matrix_engine plugin system, hub, and CSS layout plugin."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.matrix_engine.core import MatrixData, render_matrix, render_side_by_side
from laeka_rational.matrix_engine.plugin import MatrixPlugin
from laeka_rational.matrix_engine.hub import Hub


# ── Core renderer ─────────────────────────────────────────────

def test_core_render_basic():
    """Basic table rendering with headers and rows."""
    data = MatrixData(
        headers=["name", "value"],
        rows=[["x", "1"], ["y", "2"]],
    )
    result = render_matrix(data)
    assert "name" in result
    assert "value" in result
    assert "x" in result
    assert "─" in result  # separator


def test_core_render_empty():
    """Empty rows should return a no-data message."""
    data = MatrixData(headers=["a"], rows=[])
    result = render_matrix(data)
    assert "no data" in result.lower()


def test_core_render_footer():
    """Footer should be appended after the table."""
    data = MatrixData(
        headers=["col"],
        rows=[["val"]],
        footer="\nNote: this is a test",
    )
    result = render_matrix(data)
    assert "Note: this is a test" in result


def test_core_render_column_alignment():
    """Columns should be padded to max width."""
    data = MatrixData(
        headers=["short", "a_very_long_header"],
        rows=[["x", "y"], ["longer_value", "z"]],
    )
    result = render_matrix(data)
    lines = result.strip().split("\n")
    # All content lines should have consistent spacing
    assert len(lines) >= 3  # header + separator + 2 rows


def test_side_by_side_basic():
    """Two renders placed side by side."""
    left = "A  B\n1  2"
    right = "X  Y\n3  4"
    result = render_side_by_side([left, right])
    lines = result.split("\n")
    assert len(lines) == 2
    assert "A" in lines[0] and "X" in lines[0]
    assert "1" in lines[1] and "3" in lines[1]


def test_side_by_side_single():
    """Single render returned as-is."""
    text = "hello\nworld"
    assert render_side_by_side([text]) == text


def test_side_by_side_empty():
    """Empty list returns empty string."""
    assert render_side_by_side([]) == ""


# ── Plugin system ─────────────────────────────────────────────

class DummyPlugin(MatrixPlugin):
    name = "dummy"
    description = "A test plugin"

    def parse(self, input_data, **kwargs):
        return MatrixData(
            headers=["input"],
            rows=[[str(input_data)]],
        )


def test_hub_list_plugins():
    """Hub should list built-in plugins."""
    hub = Hub()
    plugins = hub.list_plugins()
    names = [p["name"] for p in plugins]
    assert "code_execution" in names
    assert "css_layout" in names


def test_hub_register_external():
    """External plugins can be registered."""
    hub = Hub()
    hub.register_plugin(DummyPlugin())
    plugins = hub.list_plugins()
    names = [p["name"] for p in plugins]
    assert "dummy" in names


def test_hub_render_dummy():
    """Hub render pipeline works for custom plugins."""
    hub = Hub()
    hub.register_plugin(DummyPlugin())
    result = hub.render("dummy", "hello")
    assert "hello" in result


def test_hub_unknown_plugin():
    """Requesting unknown plugin raises KeyError."""
    hub = Hub()
    try:
        hub.render("nonexistent", "data")
        assert False, "Should have raised KeyError"
    except KeyError as e:
        assert "nonexistent" in str(e)


def test_hub_duplicate_register():
    """Registering same name twice raises ValueError."""
    hub = Hub()
    try:
        hub.register_plugin(DummyPlugin())
        hub.register_plugin(DummyPlugin())
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "dummy" in str(e)


# ── Code execution via hub ────────────────────────────────────

def test_hub_code_execution():
    """Code execution plugin works through the hub."""
    hub = Hub()
    result = hub.render("code_execution", "x = 1\ny = 2\nz = x + y", mode="execution")
    assert "x" in result
    assert "y" in result
    assert "z" in result
    assert "*1*" in result


def test_hub_code_loop():
    """Loop tracing works through the hub."""
    hub = Hub()
    code = "total = 0\nfor i in range(3):\n    total += i"
    result = hub.render("code_execution", code, mode="loop")
    assert "total" in result
    assert "i" in result


def test_hub_code_function():
    """Function tracing works through the hub."""
    hub = Hub()
    code = "def add(a, b):\n    return a + b"
    result = hub.render("code_execution", code, mode="function", function_name="add", args="3, 4")
    assert "7" in result


def test_hub_code_function_missing_name():
    """Function mode without function_name returns error in MatrixData."""
    hub = Hub()
    result = hub.render("code_execution", "def f(): pass", mode="function")
    assert "function_name" in result.lower() or "required" in result.lower()


# ── CSS Layout plugin ────────────────────────────────────────

def test_css_layout_basic():
    """Basic box rendering produces ASCII output with box chars."""
    hub = Hub()
    boxes = [
        {"tag": "container", "x": 0, "y": 0, "w": 80, "h": 40, "margin": 0, "padding": 8},
    ]
    result = hub.render("css_layout", boxes, scale=4)
    assert "container" in result
    assert "┌" in result  # box border
    assert "┐" in result


def test_css_layout_nested():
    """Nested boxes render with both visible."""
    hub = Hub()
    boxes = [
        {"tag": "outer", "x": 0, "y": 0, "w": 120, "h": 80, "margin": 0, "padding": 16},
        {"tag": "inner", "x": 16, "y": 16, "w": 80, "h": 40, "margin": 0, "padding": 0},
    ]
    result = hub.render("css_layout", boxes, scale=4)
    assert "outer" in result
    assert "inner" in result


def test_css_layout_with_margin():
    """Box with margin shows margin fill character."""
    hub = Hub()
    boxes = [
        {"tag": "box", "x": 0, "y": 0, "w": 40, "h": 20, "margin": 8, "padding": 0},
    ]
    result = hub.render("css_layout", boxes, scale=4)
    assert "·" in result  # margin fill


def test_css_layout_with_padding():
    """Box with padding shows padding fill character."""
    hub = Hub()
    boxes = [
        {"tag": "box", "x": 0, "y": 0, "w": 40, "h": 20, "margin": 0, "padding": 8},
    ]
    result = hub.render("css_layout", boxes, scale=4)
    assert "░" in result  # padding fill


def test_css_layout_empty():
    """Empty box list returns no-boxes message."""
    hub = Hub()
    result = hub.render("css_layout", [])
    assert "no boxes" in result.lower()


def test_css_layout_invalid_input():
    """Non-list input returns error."""
    hub = Hub()
    result = hub.render("css_layout", "not a list")
    assert "error" in result.lower() or "must be a list" in result.lower()


def test_css_layout_example_from_spec():
    """The exact example from the spec should render without errors."""
    hub = Hub()
    boxes = [
        {"tag": "container", "x": 0, "y": 0, "w": 320, "h": 200, "margin": 16, "padding": 24},
        {"tag": "header", "x": 40, "y": 40, "w": 240, "h": 60},
    ]
    result = hub.render("css_layout", boxes, scale=4)
    assert "container" in result
    assert "header" in result
    # Should have box drawing characters
    assert "┌" in result
    assert "└" in result


# ── Side by side via hub ──────────────────────────────────────

def test_hub_side_by_side():
    """Hub.render_side_by_side works."""
    hub = Hub()
    r1 = hub.render("code_execution", "x = 1", mode="execution")
    r2 = hub.render("code_execution", "y = 2", mode="execution")
    combined = hub.render_side_by_side([r1, r2])
    assert "x" in combined
    assert "y" in combined


# ── Plugin with compute step ─────────────────────────────────

class ComputePlugin(MatrixPlugin):
    name = "compute_test"
    description = "Plugin that uses the compute step"

    def parse(self, input_data, **kwargs):
        return MatrixData(
            headers=["raw"],
            rows=[[str(v)] for v in input_data],
        )

    def compute(self, data):
        """Double each value."""
        new_rows = []
        for row in data.rows:
            try:
                val = int(row[0])
                new_rows.append([str(val * 2)])
            except ValueError:
                new_rows.append(row)
        return MatrixData(headers=["doubled"], rows=new_rows)


def test_compute_step():
    """Plugin compute step transforms data before rendering."""
    hub = Hub()
    hub.register_plugin(ComputePlugin())
    result = hub.render("compute_test", [1, 2, 3])
    assert "2" in result
    assert "4" in result
    assert "6" in result
    assert "doubled" in result


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
