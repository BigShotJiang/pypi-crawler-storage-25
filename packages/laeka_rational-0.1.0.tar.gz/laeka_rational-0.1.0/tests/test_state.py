"""Tests for State management domain — detect issues and suggest patterns."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from laeka_rational.domains.state.engine import state_detect_issues, state_suggest_pattern


# ── state_detect_issues ─────────────────────────────────────────

def test_detect_stale_closure():
    code = """
    function Counter() {
      const [count, setCount] = useState(0);
      const handleClick = () => {
        setTimeout(() => {
          setCount(count + 1);
        }, 1000);
      };
    }
    """
    result = state_detect_issues(code)
    assert result["issues_found"] > 0
    assert any("stale" in i["title"].lower() for i in result["issues"])

def test_detect_inline_object_prop():
    code = """
    function App() {
      return <Child style={{ color: 'red' }} />;
    }
    """
    result = state_detect_issues(code)
    assert any("inline object" in i["title"].lower() for i in result["issues"])

def test_detect_inline_function_prop():
    code = """
    function App() {
      return <Child onClick={() => console.log('click')} />;
    }
    """
    result = state_detect_issues(code)
    assert any("inline" in i["title"].lower() and "function" in i["title"].lower()
               for i in result["issues"])

def test_detect_expensive_init():
    code = """
    function App() {
      const [data, setData] = useState(computeExpensive());
    }
    """
    result = state_detect_issues(code)
    assert any("expensive" in i["title"].lower() or "lazy" in i.get("fix", "").lower()
               for i in result["issues"])

def test_detect_hook_in_conditional():
    code = """
    function App({ showExtra }) {
      if (showExtra) {
        const [extra, setExtra] = useState(null);
      }
    }
    """
    result = state_detect_issues(code)
    assert any("conditional" in i["title"].lower() for i in result["issues"])

def test_detect_clean_code():
    code = """
    function Counter() {
      const [count, setCount] = useState(0);
      return <button onClick={() => setCount(prev => prev + 1)}>{count}</button>;
    }
    """
    result = state_detect_issues(code)
    # Should not flag stale closure since we use functional updater in JSX
    # (the inline function prop is expected)
    errors = [i for i in result["issues"] if i["severity"] == "error"]
    assert len(errors) == 0

def test_issues_sorted_by_severity():
    code = """
    function App({ showExtra }) {
      if (showExtra) {
        const [extra, setExtra] = useState(null);
      }
      return <Child style={{ color: 'red' }} />;
    }
    """
    result = state_detect_issues(code)
    if len(result["issues"]) >= 2:
        severities = [i["severity"] for i in result["issues"]]
        severity_order = {"error": 0, "warning": 1, "info": 2}
        assert all(severity_order[severities[i]] <= severity_order[severities[i+1]]
                    for i in range(len(severities)-1))


# ── state_suggest_pattern ───────────────────────────────────────

def test_suggest_form():
    result = state_suggest_pattern("complex form with multiple fields and validation")
    assert result["suggestions_found"] > 0
    assert any("form" in s["pattern"].lower() for s in result["suggestions"])

def test_suggest_server_state():
    result = state_suggest_pattern("fetching data from API with caching and loading states")
    assert result["suggestions_found"] > 0
    assert any("query" in s["pattern"].lower() or "swr" in s["pattern"].lower()
               for s in result["suggestions"])

def test_suggest_global_state():
    result = state_suggest_pattern("global auth state shared across many components")
    assert result["suggestions_found"] > 0

def test_suggest_list():
    result = state_suggest_pattern("managing a list of items with add, remove, and reorder")
    assert result["suggestions_found"] > 0

def test_suggest_toggle():
    result = state_suggest_pattern("toggle modal open/close")
    assert result["suggestions_found"] > 0
    assert any("toggle" in s["pattern"].lower() for s in result["suggestions"])

def test_suggest_debounce():
    result = state_suggest_pattern("search autocomplete with debounce")
    assert result["suggestions_found"] > 0
    assert any("debounce" in s["pattern"].lower() or "deferred" in s["pattern"].lower()
               for s in result["suggestions"])

def test_suggest_undo():
    result = state_suggest_pattern("undo redo functionality in editor")
    assert result["suggestions_found"] > 0
    assert any("undo" in s["pattern"].lower() or "history" in s["pattern"].lower()
               for s in result["suggestions"])

def test_suggest_no_match():
    result = state_suggest_pattern("completely unrelated xyz123")
    assert result["suggestions_found"] == 0


if __name__ == "__main__":
    import traceback
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
            print(f"  PASS  {test.__name__}")
        except Exception as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed, {passed + failed} total")
    if failed:
        sys.exit(1)
