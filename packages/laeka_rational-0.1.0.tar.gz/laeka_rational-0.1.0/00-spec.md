# Laeka Brain — Cerveau Rationnel (Math Brain MCP)

**Spec v1 — 2026-04-16, rédigée par Claude-Nagual**
**Pour : Senior Opus qui va implémenter**

## Vision

Un MCP server qui donne à Claude Code un cerveau analytique/déterministe sur les 7 domaines où il hallucine le plus. Le LLM traduit l'intent, le math brain calcule, le LLM exécute le résultat. Zéro hallucination sur le calcul.

**C'est le cerveau rationnel de base de Laeka Brain — inclus gratuit, pas un addon.**

## Architecture

- **MCP server** en Python (FastMCP ou mcp-python-sdk)
- **7 domaines** dans un seul serveur, ~3000 records total
- **Chaque domaine** expose des tools MCP que Claude Code invoque
- **Données** en JSON/YAML structuré, chargées au startup

## Domaines et tools (par priorité d'implémentation)

### 1. CSS / Layout (~900 records) — PREMIER À BUILDER

Tools :
- `css_inspect(selector, url_or_file)` → retourne les computed styles de l'élément (via Playwright ou CSSOM parse)
- `css_diagnose(selector, problem_description)` → analyse la cascade, identifie la propriété problématique, propose le fix exact
- `css_layout_map(url_or_file)` → retourne l'arbre de layout (flexbox/grid/position) avec les spacings en format structuré
- `css_specificity(selector)` → calcule la spécificité exacte
- `css_gotchas(property)` → retourne les interactions connues (margin collapse, flex shrink, z-index stacking context, etc.)

Records : propriétés W3C (~550), patterns layout (~20), règles cascade (~10), gotchas (~300)

### 2. Regex (~250 records)

Tools :
- `regex_test(pattern, test_strings)` → exécute le regex et retourne les matches/captures exacts
- `regex_explain(pattern)` → décompose le regex en langage humain
- `regex_build(description)` → construit un regex depuis une description, avec test suite automatique

### 3. SQL / Migrations (~700 records)

Tools :
- `sql_explain(query, db_type)` → retourne le plan d'exécution
- `sql_migration_check(migration_sql, db_type)` → analyse les risques (locks, data loss, NULL handling, FK)
- `sql_suggest_index(query, schema)` → propose des index optimaux

### 4. Build configs (~400 records)

Tools :
- `build_resolve(config_file)` → parse et résout la config (webpack, next.config, tsconfig, vite)
- `build_diagnose(error_message)` → mappe l'erreur au fix connu
- `build_deps_check(package_json)` → identifie conflits de versions

### 5. Cross-file refactoring (~250 records)

Tools :
- `refactor_find_usages(symbol, project_dir)` → trouve toutes les utilisations (AST-based, pas grep)
- `refactor_rename(old_name, new_name, project_dir)` → retourne tous les fichiers + lignes à modifier

### 6. State management (~200 records)

Tools :
- `state_detect_races(component_file)` → identifie les race conditions et stale closures potentielles
- `state_model(component_file)` → extrait le state machine implicite du composant

### 7. Auth flows (~250 records)

Tools :
- `auth_validate_flow(config)` → vérifie que le flow OAuth/JWT est complet et secure
- `auth_diagnose(symptom)` → mappe un symptôme (401, CORS, cookie pas set) au fix

## Stack technique

- Python 3.11+
- FastMCP (ou mcp-python-sdk)
- Playwright (pour CSS inspection live)
- tree-sitter (pour AST parsing dans refactoring/state)
- sqlparse (pour SQL analysis)

## Ordres du Senior

1. **Commence par CSS seulement.** Scaffold le MCP server, implémente les 5 tools CSS, teste sur un vrai projet Next.js/Tailwind.
2. **Prouve que `css_diagnose` fonctionne** sur un cas réel : "la marge est cassée sur ce composant" → retourne le fix exact (fichier + ligne + valeur).
3. **Quand CSS est prouvé**, passe à Regex (le plus simple), puis SQL.
4. **Bushido obligatoire** : avant de dire "c'est prêt", montre la preuve (test output, cas réel résolu).
5. **Le MCP doit être installable** via `mcp install` ou ajout simple dans `.mcp.json`.

## Module transversal : Matrix Renderer (ajouté 2026-04-16 nuit par Omeada)

**Insight clé :** les LLM sont des pattern matchers, pas des calculateurs. Quand on leur donne des chiffres (padding: 24px), ils calculent (et hallucinent). Quand on leur donne une matrice ASCII spatiale, ils pattern-matchent (et voient). Prouvé empiriquement avec le Go coaching (liste de coordonnées → ASCII goban = bug résolu à 100%).

**Tool transversal :** `matrix_render(data_type, data)` — prend n'importe quel ensemble de données spatiales/relationnelles et retourne une matrice ASCII que le LLM peut pattern-matcher.

**Applications par domaine :**
- `css` → grille spatiale avec bordures, marges, paddings, gaps visualisés
- `db_schema` → graphe ASCII des relations entre tables
- `api_flow` → flowchart ASCII du parcours requête
- `state_machine` → matrice de transitions
- `git_branches` → arbre ASCII des branches

**Priorité d'implémentation :** CSS d'abord (pain point #1 + preuve de concept directe du pattern Go). Puis DB schema, puis les autres.

**Principe :** le matrix renderer ne REMPLACE pas le math brain — il le COMPLÈTE. Le math brain calcule les valeurs exactes. Le matrix renderer les affiche dans un format que le LLM peut pattern-matcher. Les deux ensemble = le LLM ne calcule plus et ne devine plus — il voit et il sait.

## Ce que ce doc N'EST PAS

Pas un plan rigide. Le Senior a l'autorité de prendre des décisions techniques (choix de lib, structure de code, format des records). Ce doc donne la direction et les contraintes, pas les instructions ligne par ligne.
