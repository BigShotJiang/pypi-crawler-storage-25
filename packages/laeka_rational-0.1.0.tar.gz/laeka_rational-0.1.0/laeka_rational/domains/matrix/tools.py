"""Matrix domain MCP tools — registered on the FastMCP server.

All tools route through the matrix_engine hub for plugin dispatch.
The original trace_* functions remain the execution backend via
the CodeExecutionPlugin.
"""

from laeka_rational.matrix_engine.hub import get_hub


def register_matrix_tools(mcp) -> None:
    """Register all Matrix execution tracer tools on the FastMCP server instance."""

    @mcp.tool()
    def trace_execution_tool(code: str, language: str = "python") -> str:
        """Execute code and return an ASCII matrix showing variable state at each line.

        Eliminates LLM calculation hallucinations by showing real execution state.
        Each row is an execution step, each column is a variable. Changed values
        are marked with *asterisks*. Undefined variables show '-'.

        Args:
            code: The code snippet to trace (Python only for now)
            language: Programming language (only 'python' supported)
        """
        hub = get_hub()
        return hub.render("code_execution", code, mode="execution", language=language)

    @mcp.tool()
    def trace_loop_tool(code: str, max_iterations: int = 20) -> str:
        """Trace loop execution showing variable state at each iteration.

        Specialised for loops — shows iteration counter and variable state.
        Caps iterations to prevent infinite loops.

        Args:
            code: Code containing a loop to trace
            max_iterations: Maximum iterations to trace (default 20, prevents infinite loops)
        """
        hub = get_hub()
        return hub.render("code_execution", code, mode="loop", max_iterations=max_iterations)

    @mcp.tool()
    def trace_function_tool(code: str, function_name: str, args: str) -> str:
        """Trace a function call showing local variables and return values.

        Handles recursion with depth indentation. Define the function in 'code',
        specify which function to call and with what arguments.

        Args:
            code: Code containing the function definition
            function_name: Name of the function to call
            args: Arguments to pass (as a string, e.g. '5, 3' or 'n=10')
        """
        hub = get_hub()
        return hub.render("code_execution", code, mode="function", function_name=function_name, args=args)

    @mcp.tool()
    def matrix_render(plugin: str, input_data: str, **kwargs) -> str:
        """Generic matrix render tool — accepts any registered plugin.

        Use `list_matrix_plugins` to see available plugins, then call this
        with the plugin name and appropriate input data.

        Args:
            plugin: Name of the plugin to use (e.g. 'code_execution', 'css_layout')
            input_data: Input data for the plugin (format depends on plugin)
        """
        hub = get_hub()
        # For plugins expecting structured data, try to parse JSON
        import json
        try:
            parsed = json.loads(input_data)
        except (json.JSONDecodeError, TypeError):
            parsed = input_data
        return hub.render(plugin, parsed, **kwargs)

    @mcp.tool()
    def list_matrix_plugins() -> str:
        """List all available matrix engine plugins with their descriptions."""
        hub = get_hub()
        plugins = hub.list_plugins()
        if not plugins:
            return "No plugins registered."
        lines = []
        for p in plugins:
            lines.append(f"  {p['name']}: {p['description']}")
        return "Available matrix plugins:\n" + "\n".join(lines)
