"""Matrix execution tracer — execute code and render variable state as ASCII matrices.

Eliminates LLM hallucinations by showing real execution state instead of
requiring mental simulation. The LLM reads instead of calculating.
"""

import ast
import copy
import signal
import sys
import textwrap
from typing import Any

# ── Safety: restricted builtins ────────────────────────────────

_BLOCKED_BUILTINS = {
    "open", "exec", "eval", "__import__", "compile",
    "breakpoint", "exit", "quit", "input",
    "globals", "locals", "vars",
    "getattr", "setattr", "delattr",
}

_SAFE_BUILTINS = {
    k: v for k, v in __builtins__.items() if k not in _BLOCKED_BUILTINS
} if isinstance(__builtins__, dict) else {
    k: getattr(__builtins__, k) for k in dir(__builtins__)
    if k not in _BLOCKED_BUILTINS and not k.startswith("_")
}

# Re-add safe dunders
_SAFE_BUILTINS["__name__"] = "__main__"
_SAFE_BUILTINS["__build_class__"] = __builtins__.__build_class__ if hasattr(__builtins__, "__build_class__") else __build_class__

_TIMEOUT_SECONDS = 5
_MAX_REPR_LEN = 30


# ── Timeout context manager ───────────────────────────────────

class _Timeout:
    """Context manager for execution timeout. Uses SIGALRM on Unix."""

    def __init__(self, seconds: int):
        self.seconds = seconds
        self._has_signal = hasattr(signal, "SIGALRM")

    def __enter__(self):
        if self._has_signal:
            signal.signal(signal.SIGALRM, self._handler)
            signal.alarm(self.seconds)
        return self

    def __exit__(self, *args):
        if self._has_signal:
            signal.alarm(0)

    @staticmethod
    def _handler(signum, frame):
        raise TimeoutError("Execution timed out (5s limit)")


# ── Helpers ────────────────────────────────────────────────────

def _short_repr(value: Any) -> str:
    """Short repr of a value, truncated if needed."""
    r = repr(value)
    if len(r) > _MAX_REPR_LEN:
        return r[:_MAX_REPR_LEN - 3] + "..."
    return r


def _render_matrix(headers: list[str], rows: list[list[str]]) -> str:
    """Render an ASCII table with dynamic column widths."""
    if not rows:
        return "(no execution steps recorded)"

    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(cell))

    # Build format string
    def fmt_row(cells: list[str]) -> str:
        parts = []
        for i, cell in enumerate(cells):
            w = widths[i] if i < len(widths) else len(cell)
            parts.append(cell.ljust(w))
        return "  ".join(parts)

    lines = [fmt_row(headers)]
    lines.append("─" * (sum(widths) + 2 * (len(widths) - 1)))
    for row in rows:
        lines.append(fmt_row(row))

    return "\n".join(lines)


def _make_namespace() -> dict:
    """Create a sandboxed namespace for execution."""
    return {"__builtins__": _SAFE_BUILTINS}


# ── Tool 1: trace_execution ───────────────────────────────────

def trace_execution(code: str, language: str = "python") -> str:
    """Execute code line by line and return an ASCII matrix of variable states.

    Each row = one execution step. Each column = a variable.
    Changed values are marked with *value*.
    """
    if language != "python":
        return f"Error: only Python is supported (got '{language}')"

    code = textwrap.dedent(code).strip()

    # Parse to get source lines
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"SyntaxError: {e}"

    # Map line numbers to source text
    source_lines = code.split("\n")

    # Execute with tracing
    namespace = _make_namespace()
    steps: list[dict[str, Any]] = []  # {line: int, code: str, vars: dict}
    all_var_names: list[str] = []  # ordered by first appearance

    prev_vars: dict[str, Any] = {}
    exec_error: str | None = None

    def trace_func(frame, event, arg):
        if event != "line":
            return trace_func
        # Only trace our code (not builtins)
        if frame.f_code.co_filename != "<trace>":
            return trace_func

        lineno = frame.f_lineno
        if lineno < 1 or lineno > len(source_lines):
            return trace_func

        # Snapshot variables AFTER previous line executed
        current_vars = {
            k: copy.deepcopy(v)
            for k, v in frame.f_locals.items()
            if not k.startswith("_") and k != "__builtins__"
        }

        # Track variable order
        for name in current_vars:
            if name not in all_var_names:
                all_var_names.append(name)

        steps.append({
            "line": lineno,
            "code": source_lines[lineno - 1].strip(),
            "vars": current_vars,
        })

        return trace_func

    try:
        with _Timeout(_TIMEOUT_SECONDS):
            compiled = compile(code, "<trace>", "exec")
            sys.settrace(trace_func)
            try:
                exec(compiled, namespace)
            finally:
                sys.settrace(None)

            # Capture final state
            final_vars = {
                k: v for k, v in namespace.items()
                if not k.startswith("_") and k != "__builtins__"
            }
            for name in final_vars:
                if name not in all_var_names:
                    all_var_names.append(name)

            # Add final state as last step (for the last line)
            if source_lines:
                last_line = len(source_lines)
                steps.append({
                    "line": last_line,
                    "code": source_lines[last_line - 1].strip(),
                    "vars": {k: copy.deepcopy(v) for k, v in final_vars.items()
                             if not k.startswith("_")},
                })

    except TimeoutError:
        return "Error: execution timed out (5s limit)"
    except Exception as e:
        exec_error = f"\nError during execution: {type(e).__name__}: {e}"
        if not steps:
            return exec_error.strip()

    # Deduplicate consecutive steps on same line with same vars
    deduped: list[dict[str, Any]] = []
    for step in steps:
        if deduped and deduped[-1]["line"] == step["line"] and deduped[-1]["vars"] == step["vars"]:
            continue
        deduped.append(step)
    steps = deduped

    # Build matrix
    headers = ["line", "code"] + all_var_names
    rows: list[list[str]] = []
    prev_state: dict[str, str] = {}

    for step in steps:
        row = [str(step["line"]), step["code"]]
        for var_name in all_var_names:
            if var_name in step["vars"]:
                val = _short_repr(step["vars"][var_name])
                if var_name in prev_state and prev_state[var_name] == val:
                    row.append(val)
                else:
                    row.append(f"*{val}*")
                prev_state[var_name] = val
            else:
                row.append("-")
        rows.append(row)

    result = _render_matrix(headers, rows)
    if exec_error:
        result += exec_error
    return result


# ── Tool 2: trace_loop ────────────────────────────────────────

def trace_loop(code: str, max_iterations: int = 20) -> str:
    """Trace loop execution showing state at each iteration.

    Specialised for loops — shows iteration counter, condition evaluation,
    and variable state per iteration. Caps at max_iterations.
    """
    code = textwrap.dedent(code).strip()

    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"SyntaxError: {e}"

    source_lines = code.split("\n")
    namespace = _make_namespace()

    # Find loop lines
    loop_lines: set[int] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.For, ast.While)):
            loop_lines.add(node.lineno)

    if not loop_lines:
        return "No loop found in the provided code. Use trace_execution instead."

    iterations: list[dict[str, Any]] = []
    all_var_names: list[str] = []
    iteration_count = 0
    last_loop_line_seen = 0
    capped = False

    def trace_func(frame, event, arg):
        nonlocal iteration_count, last_loop_line_seen, capped
        if event != "line" or frame.f_code.co_filename != "<trace>":
            return trace_func

        lineno = frame.f_lineno

        # Detect new loop iteration (re-entering loop header)
        if lineno in loop_lines:
            if last_loop_line_seen > 0:
                iteration_count += 1
            last_loop_line_seen = lineno

            if iteration_count >= max_iterations:
                capped = True
                sys.settrace(None)
                return None

            # Capture state at start of iteration
            current_vars = {
                k: copy.deepcopy(v)
                for k, v in frame.f_locals.items()
                if not k.startswith("_") and k != "__builtins__"
            }
            for name in current_vars:
                if name not in all_var_names:
                    all_var_names.append(name)

            line_code = source_lines[lineno - 1].strip() if lineno <= len(source_lines) else ""
            iterations.append({
                "iter": iteration_count,
                "line": lineno,
                "code": line_code,
                "vars": current_vars,
            })

        return trace_func

    try:
        with _Timeout(_TIMEOUT_SECONDS):
            compiled = compile(code, "<trace>", "exec")
            sys.settrace(trace_func)
            try:
                exec(compiled, namespace)
            finally:
                sys.settrace(None)
    except TimeoutError:
        if not iterations:
            return "Error: execution timed out (5s limit)"
    except Exception:
        if not iterations:
            return "Error during execution"

    # Build matrix
    headers = ["iter", "line", "code"] + all_var_names
    rows: list[list[str]] = []
    prev_state: dict[str, str] = {}

    for it in iterations:
        row = [str(it["iter"]), str(it["line"]), it["code"]]
        for var_name in all_var_names:
            if var_name in it["vars"]:
                val = _short_repr(it["vars"][var_name])
                if var_name in prev_state and prev_state[var_name] == val:
                    row.append(val)
                else:
                    row.append(f"*{val}*")
                prev_state[var_name] = val
            else:
                row.append("-")
        rows.append(row)

    result = _render_matrix(headers, rows)
    if capped:
        result += f"\n\n⚠ Capped at {max_iterations} iterations."
    return result


# ── Tool 3: trace_function ────────────────────────────────────

def trace_function(code: str, function_name: str, args: str) -> str:
    """Trace a function call showing local variables and return value.

    Handles recursion with indentation by call depth.
    """
    code = textwrap.dedent(code).strip()

    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"SyntaxError: {e}"

    source_lines = code.split("\n")
    namespace = _make_namespace()

    # First, define the function
    try:
        with _Timeout(_TIMEOUT_SECONDS):
            compiled = compile(code, "<trace>", "exec")
            exec(compiled, namespace)
    except TimeoutError:
        return "Error: function definition timed out"
    except Exception as e:
        return f"Error defining function: {type(e).__name__}: {e}"

    if function_name not in namespace:
        return f"Error: function '{function_name}' not found after executing code"

    # Now trace the call
    steps: list[dict[str, Any]] = []
    all_var_names: list[str] = []
    call_depth = 0
    max_depth = 0

    def trace_func(frame, event, arg):
        nonlocal call_depth, max_depth
        if frame.f_code.co_filename != "<trace>":
            return trace_func

        if event == "call" and frame.f_code.co_name == function_name:
            call_depth += 1
            max_depth = max(max_depth, call_depth)
            return trace_func

        if event == "return" and frame.f_code.co_name == function_name:
            steps.append({
                "line": frame.f_lineno,
                "code": f"{'  ' * (call_depth - 1)}↩ return {_short_repr(arg)}",
                "vars": {},
                "depth": call_depth,
                "event": "return",
                "return_value": arg,
            })
            call_depth -= 1
            return trace_func

        if event == "line" and frame.f_code.co_name == function_name:
            lineno = frame.f_lineno
            if lineno < 1 or lineno > len(source_lines):
                return trace_func

            current_vars = {
                k: copy.deepcopy(v)
                for k, v in frame.f_locals.items()
                if not k.startswith("_") and k != "__builtins__"
            }
            for name in current_vars:
                if name not in all_var_names:
                    all_var_names.append(name)

            indent = "  " * (call_depth - 1) if call_depth > 0 else ""
            steps.append({
                "line": lineno,
                "code": indent + source_lines[lineno - 1].strip(),
                "vars": current_vars,
                "depth": call_depth,
                "event": "line",
            })

        return trace_func

    # Build the call expression and execute it
    call_code = f"{function_name}({args})"
    try:
        with _Timeout(_TIMEOUT_SECONDS):
            call_compiled = compile(call_code, "<trace>", "eval")
            sys.settrace(trace_func)
            try:
                result_value = eval(call_compiled, namespace)
            finally:
                sys.settrace(None)
    except TimeoutError:
        if not steps:
            return "Error: function execution timed out (5s limit)"
    except Exception as e:
        if not steps:
            return f"Error during function execution: {type(e).__name__}: {e}"

    # Build matrix
    headers = ["line", "depth", "code"] + all_var_names
    rows: list[list[str]] = []
    prev_state: dict[str, str] = {}

    for step in steps:
        row = [str(step["line"]), str(step.get("depth", 0)), step["code"]]
        for var_name in all_var_names:
            if var_name in step["vars"]:
                val = _short_repr(step["vars"][var_name])
                if var_name in prev_state and prev_state[var_name] == val:
                    row.append(val)
                else:
                    row.append(f"*{val}*")
                prev_state[var_name] = val
            else:
                row.append("-")
        rows.append(row)

    result = _render_matrix(headers, rows)

    # Append final return value
    if "result_value" in dir():
        pass  # Already shown in return steps

    if max_depth > 1:
        result += f"\n\nMax recursion depth reached: {max_depth}"

    return result
