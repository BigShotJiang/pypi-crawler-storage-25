"""CSS domain MCP tools — registered on the FastMCP server."""

from typing import Any

from .specificity import calculate_specificity, compare_specificity
from .diagnose import diagnose, get_gotchas_for_property


def register_css_tools(mcp) -> None:
    """Register all CSS tools on the FastMCP server instance."""

    @mcp.tool()
    def css_specificity(selector: str) -> dict[str, Any]:
        """Calculate the exact CSS specificity of a selector.

        Returns the specificity tuple (inline, ids, classes, elements) with
        human-readable breakdown. Handles complex selectors including :not(),
        :is(), :has(), :where(), pseudo-elements, and combinators.

        Args:
            selector: A CSS selector string (e.g. "#nav .item:hover > a::before")
        """
        spec = calculate_specificity(selector)
        return {
            "selector": selector,
            "specificity": str(spec),
            "tuple": list(spec.as_tuple()),
            "breakdown": spec.human(),
        }

    @mcp.tool()
    def css_compare_specificity(selector_a: str, selector_b: str) -> dict[str, Any]:
        """Compare the specificity of two CSS selectors to determine which wins.

        Use when you need to understand why one rule overrides another.

        Args:
            selector_a: First CSS selector
            selector_b: Second CSS selector
        """
        return compare_specificity(selector_a, selector_b)

    @mcp.tool()
    def css_diagnose(
        problem_description: str,
        selector: str | None = None,
    ) -> dict[str, Any]:
        """Diagnose a CSS problem using a database of known gotchas and fixes.

        Matches the problem description against ~300 known CSS gotchas covering
        margin collapse, flex/grid issues, z-index stacking, position sticky,
        Tailwind specificity, mobile viewport, and more. Returns deterministic
        fix strategies — no guessing.

        Args:
            problem_description: Describe the visual problem (e.g. "margin disappears
                between parent and child", "sticky header not sticking",
                "z-index not working on modal", "text won't truncate with ellipsis")
            selector: Optional CSS selector involved — will also compute its specificity
        """
        return diagnose(selector, problem_description)

    @mcp.tool()
    def css_gotchas(property: str) -> dict[str, Any]:
        """Return all known gotchas and interactions for a CSS property.

        Use BEFORE writing CSS to avoid known pitfalls. Covers margin collapse,
        flex shrink/min-width, z-index stacking contexts, position sticky traps,
        grid blowout, transform breaking fixed position, and more.

        Args:
            property: CSS property name (e.g. "margin", "z-index", "position",
                "flex-shrink", "overflow", "grid")
        """
        return get_gotchas_for_property(property)
