"""CSS specificity calculator — deterministic, no LLM needed."""

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Specificity:
    inline: int = 0
    ids: int = 0
    classes: int = 0
    elements: int = 0

    def __gt__(self, other: "Specificity") -> bool:
        return self.as_tuple() > other.as_tuple()

    def __lt__(self, other: "Specificity") -> bool:
        return self.as_tuple() < other.as_tuple()

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Specificity):
            return NotImplemented
        return self.as_tuple() == other.as_tuple()

    def as_tuple(self) -> tuple[int, int, int, int]:
        return (self.inline, self.ids, self.classes, self.elements)

    def __str__(self) -> str:
        return f"({self.inline},{self.ids},{self.classes},{self.elements})"

    def human(self) -> str:
        parts = []
        if self.inline:
            parts.append(f"{self.inline} inline")
        if self.ids:
            parts.append(f"{self.ids} id{'s' if self.ids > 1 else ''}")
        if self.classes:
            parts.append(f"{self.classes} class{'es' if self.classes > 1 else ''}")
        if self.elements:
            parts.append(f"{self.elements} element{'s' if self.elements > 1 else ''}")
        return ", ".join(parts) if parts else "zero specificity (universal)"


# Pseudo-classes that contribute zero specificity
ZERO_SPECIFICITY_PSEUDOS = {":where"}
# Pseudo-classes whose specificity = their most specific argument
ARGUMENT_SPECIFICITY_PSEUDOS = {":not", ":is", ":has", ":matches"}
# Pseudo-elements (double colon or legacy single colon)
PSEUDO_ELEMENTS = {
    "::before", "::after", "::first-line", "::first-letter",
    "::placeholder", "::marker", "::selection", "::backdrop",
    "::file-selector-button", "::cue", "::part",
    # Legacy single-colon forms
    ":before", ":after", ":first-line", ":first-letter",
}
# Pseudo-classes (single colon, NOT pseudo-elements)
PSEUDO_CLASSES = {
    ":hover", ":focus", ":active", ":visited", ":link",
    ":focus-within", ":focus-visible", ":checked", ":disabled",
    ":enabled", ":first-child", ":last-child", ":nth-child",
    ":nth-last-child", ":nth-of-type", ":nth-last-of-type",
    ":first-of-type", ":last-of-type", ":only-child",
    ":only-of-type", ":empty", ":root", ":target",
    ":required", ":optional", ":valid", ":invalid",
    ":in-range", ":out-of-range", ":read-only", ":read-write",
    ":placeholder-shown", ":default", ":indeterminate",
    ":lang", ":dir", ":any-link", ":local-link",
    ":autofill", ":popover-open",
}


def calculate_specificity(selector: str) -> Specificity:
    """Calculate CSS specificity for a selector string.

    Returns a Specificity(inline, ids, classes, elements) tuple.
    Inline is always 0 for stylesheet selectors (1 only for style attribute).
    """
    ids = 0
    classes = 0
    elements = 0

    # Work on a clean copy
    s = selector.strip()

    # Handle :where() — zero specificity for contents
    s = _strip_functional_pseudo(s, ":where")

    # Handle :not(), :is(), :has() — use most specific argument
    for pseudo in (":not", ":is", ":has", ":matches"):
        s, extra = _extract_functional_pseudo_specificity(s, pseudo)
        ids += extra.ids
        classes += extra.classes
        elements += extra.elements

    # Remove pseudo-elements (count as element)
    for pe in sorted(PSEUDO_ELEMENTS, key=len, reverse=True):
        while pe in s:
            s = s.replace(pe, "", 1)
            elements += 1

    # Count IDs: #something
    id_matches = re.findall(r"#[\w-]+", s)
    ids += len(id_matches)
    for m in id_matches:
        s = s.replace(m, "", 1)

    # Count attribute selectors: [attr], [attr=val], etc.
    attr_matches = re.findall(r"\[[^\]]*\]", s)
    classes += len(attr_matches)
    for m in attr_matches:
        s = s.replace(m, "", 1)

    # Count remaining pseudo-classes (single colon, not pseudo-elements)
    pseudo_class_matches = re.findall(r":[\w-]+(?:\([^)]*\))?", s)
    for pc in pseudo_class_matches:
        base = re.match(r":([\w-]+)", pc)
        if base:
            classes += 1
    for m in pseudo_class_matches:
        s = s.replace(m, "", 1)

    # Count classes: .something
    class_matches = re.findall(r"\.[\w-]+", s)
    classes += len(class_matches)
    for m in class_matches:
        s = s.replace(m, "", 1)

    # Remove combinators and whitespace
    s = re.sub(r"[>+~\s]+", " ", s).strip()

    # Count remaining element selectors (not * which is zero)
    elem_parts = s.split()
    for part in elem_parts:
        part = part.strip()
        if part and part != "*":
            elements += 1

    return Specificity(inline=0, ids=ids, classes=classes, elements=elements)


def _strip_functional_pseudo(selector: str, pseudo: str) -> str:
    """Remove a functional pseudo-class and its contents entirely (for :where)."""
    result = selector
    while True:
        idx = result.find(pseudo + "(")
        if idx == -1:
            break
        # Find matching closing paren
        depth = 0
        start = idx + len(pseudo)
        for i in range(start, len(result)):
            if result[i] == "(":
                depth += 1
            elif result[i] == ")":
                depth -= 1
                if depth == 0:
                    result = result[:idx] + result[i + 1:]
                    break
        else:
            break  # malformed, bail
    return result


def _extract_functional_pseudo_specificity(
    selector: str, pseudo: str
) -> tuple[str, Specificity]:
    """Extract functional pseudo, calculate specificity of its most specific argument."""
    max_spec = Specificity()
    result = selector

    while True:
        idx = result.find(pseudo + "(")
        if idx == -1:
            break
        start = idx + len(pseudo)
        depth = 0
        end = -1
        for i in range(start, len(result)):
            if result[i] == "(":
                depth += 1
            elif result[i] == ")":
                depth -= 1
                if depth == 0:
                    end = i
                    break
        if end == -1:
            break

        inner = result[start + 1: end]
        # Split by comma for selector list
        args = [a.strip() for a in inner.split(",")]
        for arg in args:
            if arg:
                spec = calculate_specificity(arg)
                if spec > max_spec:
                    max_spec = spec

        result = result[:idx] + result[end + 1:]

    return result, max_spec


def compare_specificity(sel_a: str, sel_b: str) -> dict:
    """Compare two selectors' specificity, return structured result."""
    spec_a = calculate_specificity(sel_a)
    spec_b = calculate_specificity(sel_b)

    if spec_a > spec_b:
        winner = sel_a
        reason = f"{sel_a} {spec_a} beats {sel_b} {spec_b}"
    elif spec_b > spec_a:
        winner = sel_b
        reason = f"{sel_b} {spec_b} beats {sel_a} {spec_a}"
    else:
        winner = "equal (source order wins)"
        reason = f"Both have specificity {spec_a} — last one in stylesheet wins"

    return {
        "selector_a": {"selector": sel_a, "specificity": str(spec_a), "breakdown": spec_a.human()},
        "selector_b": {"selector": sel_b, "specificity": str(spec_b), "breakdown": spec_b.human()},
        "winner": winner,
        "reason": reason,
    }
