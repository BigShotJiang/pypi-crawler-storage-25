"""CSS diagnostic engine — matches problems to known gotchas and computes fixes."""

import json
import re
from pathlib import Path
from typing import Any

from .specificity import calculate_specificity, compare_specificity


_DATA_DIR = Path(__file__).parent / "data"
_gotchas: dict[str, Any] | None = None


def _load_gotchas() -> dict[str, Any]:
    global _gotchas
    if _gotchas is None:
        with open(_DATA_DIR / "gotchas.json") as f:
            _gotchas = json.load(f)
    return _gotchas


# Keyword-to-gotcha mapping for fast lookup
_SYMPTOM_KEYWORDS: dict[str, list[str]] = {
    "margin": ["margin-collapse"],
    "margin collapse": ["margin-collapse"],
    "margin disappear": ["margin-collapse"],
    "margin bleed": ["margin-collapse"],
    "spacing": ["margin-collapse", "gap-vs-margin"],
    "flex shrink": ["flex-shrink-text", "flex-min-width"],
    "flex overflow": ["flex-min-width", "flex-shrink-text"],
    "text overflow": ["flex-min-width", "text-overflow-ellipsis"],
    "ellipsis": ["text-overflow-ellipsis"],
    "truncat": ["text-overflow-ellipsis"],
    "z-index": ["z-index-stacking-context"],
    "stacking": ["z-index-stacking-context"],
    "behind": ["z-index-stacking-context"],
    "modal": ["z-index-stacking-context", "transform-position-fixed"],
    "sticky": ["position-sticky-not-working", "overflow-clip-vs-hidden"],
    "not sticking": ["position-sticky-not-working"],
    "grid overflow": ["grid-blowout"],
    "grid break": ["grid-blowout"],
    "fixed": ["transform-position-fixed"],
    "fixed scroll": ["transform-position-fixed"],
    "position fixed": ["transform-position-fixed"],
    "tailwind": ["tailwind-specificity"],
    "class not apply": ["tailwind-specificity"],
    "override": ["tailwind-specificity"],
    "100vh": ["100vh-mobile"],
    "mobile height": ["100vh-mobile"],
    "viewport": ["100vh-mobile"],
    "gap": ["gap-vs-margin"],
    "aspect": ["aspect-ratio-image"],
    "stretch": ["aspect-ratio-image"],
    "squish": ["aspect-ratio-image"],
    "box-sizing": ["border-box-gotcha"],
    "padding break": ["border-box-gotcha"],
    "width padding": ["border-box-gotcha"],
    "backdrop": ["backdrop-filter-safari"],
    "blur": ["backdrop-filter-safari"],
    "safari": ["backdrop-filter-safari"],
    "overflow hidden": ["overflow-clip-vs-hidden", "position-sticky-not-working"],
    "overflow clip": ["overflow-clip-vs-hidden"],
    "specificity": ["tailwind-specificity"],
    "not working": [
        "position-sticky-not-working",
        "text-overflow-ellipsis",
        "z-index-stacking-context",
        "tailwind-specificity",
    ],
    "won't shrink": ["flex-min-width", "flex-shrink-text"],
    "min-width": ["flex-min-width"],
}


def diagnose(selector: str | None, problem_description: str) -> dict[str, Any]:
    """Diagnose a CSS problem. Returns matched gotchas + computed specificity if selector given.

    This is the core diagnostic tool — matches symptoms to known CSS gotchas
    and returns deterministic fix strategies.
    """
    gotchas = _load_gotchas()
    problem_lower = problem_description.lower()

    # 1. Find matching gotchas by symptom keywords
    matched_gotcha_keys: set[str] = set()

    for keyword, gotcha_keys in _SYMPTOM_KEYWORDS.items():
        if keyword in problem_lower:
            matched_gotcha_keys.update(gotcha_keys)

    # 2. Also match by checking each gotcha's common_symptoms
    for key, gotcha in gotchas.items():
        for symptom in gotcha.get("common_symptoms", []):
            if symptom.lower() in problem_lower or problem_lower in symptom.lower():
                matched_gotcha_keys.add(key)

    # 3. Match by property name mentioned in problem
    for key, gotcha in gotchas.items():
        prop = gotcha.get("property", "")
        if prop and prop in problem_lower:
            matched_gotcha_keys.add(key)

    # 4. Build results
    matched_gotchas = []
    for key in matched_gotcha_keys:
        if key in gotchas:
            entry = gotchas[key].copy()
            entry["id"] = key
            matched_gotchas.append(entry)

    # 5. Specificity analysis if selector provided
    specificity_info = None
    if selector:
        spec = calculate_specificity(selector)
        specificity_info = {
            "selector": selector,
            "specificity": str(spec),
            "breakdown": spec.human(),
        }

    # 6. Build response
    result: dict[str, Any] = {
        "problem": problem_description,
        "matches_found": len(matched_gotchas),
    }

    if selector:
        result["selector"] = selector
        result["specificity"] = specificity_info

    if matched_gotchas:
        result["diagnosis"] = matched_gotchas
        # Extract top fix strategies
        all_fixes = []
        for g in matched_gotchas:
            all_fixes.extend(g.get("fix_strategies", []))
        result["recommended_fixes"] = all_fixes[:5]  # Top 5
    else:
        result["diagnosis"] = "No known gotcha matched. Problem may be project-specific."
        result["debug_steps"] = [
            "Inspect the element's computed styles in DevTools",
            "Check the cascade: are other rules overriding?",
            "Check if a parent creates a new formatting context (BFC, flex, grid)",
            "Check if a parent creates a new stacking context",
            "Verify the selector actually matches the target element",
        ]

    return result


def get_gotchas_for_property(css_property: str) -> dict[str, Any]:
    """Return all known gotchas for a given CSS property."""
    gotchas = _load_gotchas()
    matches = {}
    prop_lower = css_property.lower().strip()

    for key, gotcha in gotchas.items():
        if gotcha.get("property", "").lower() == prop_lower:
            matches[key] = gotcha

    # Also partial match on key name
    for key, gotcha in gotchas.items():
        if prop_lower in key.lower() and key not in matches:
            matches[key] = gotcha

    return {
        "property": css_property,
        "gotchas_found": len(matches),
        "gotchas": matches,
    }
