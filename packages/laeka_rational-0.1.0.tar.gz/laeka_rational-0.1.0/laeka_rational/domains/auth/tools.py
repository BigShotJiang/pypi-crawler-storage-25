"""Auth domain MCP tools — registered on the FastMCP server."""

from typing import Any

from .engine import auth_validate_flow, auth_diagnose


def register_auth_tools(mcp) -> None:
    """Register all Auth tools on the FastMCP server instance."""

    @mcp.tool()
    def auth_validate_flow_tool(flow_description: str) -> dict[str, Any]:
        """Validate the completeness of an authentication flow.

        Checks OAuth Authorization Code, PKCE, JWT, and session-based flows
        against required and recommended steps. Returns what's missing,
        security gotchas, and a completeness score.

        Args:
            flow_description: Describe your auth flow in detail (e.g.
                "User clicks Google login, we redirect to Google OAuth with PKCE,
                receive code at callback, exchange for tokens, store in httpOnly cookie")
        """
        return auth_validate_flow(flow_description)

    @mcp.tool()
    def auth_diagnose_tool(symptom: str) -> dict[str, Any]:
        """Diagnose an authentication/authorization problem from a symptom.

        Maps symptoms (401 errors, CORS issues, cookies not set, token problems,
        XSS/CSRF vulnerabilities) to specific fixes. Covers JWT, OAuth, CORS,
        cookies, sessions, and common security issues.

        Args:
            symptom: The auth problem symptom (e.g. "401 on API call",
                "cookie not being sent cross-origin", "CORS error with credentials",
                "JWT token expired but refresh not working", "session lost after deploy")
        """
        return auth_diagnose(symptom)
