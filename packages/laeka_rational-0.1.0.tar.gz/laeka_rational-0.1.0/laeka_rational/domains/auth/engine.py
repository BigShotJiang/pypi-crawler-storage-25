"""Auth domain engine — validate flows and diagnose auth issues."""

import json
import re
from pathlib import Path
from typing import Any


_DATA_DIR = Path(__file__).parent / "data"
_gotchas: dict[str, Any] | None = None


def _load_gotchas() -> dict[str, Any]:
    global _gotchas
    if _gotchas is None:
        with open(_DATA_DIR / "gotchas.json") as f:
            _gotchas = json.load(f)
    return _gotchas


# ── auth_validate_flow ──────────────────────────────────────────

# Required steps per flow type
_FLOW_REQUIREMENTS: dict[str, dict[str, Any]] = {
    "oauth-authorization-code": {
        "description": "OAuth 2.0 Authorization Code Flow (for server-side apps)",
        "required_steps": [
            "redirect to authorization endpoint with client_id, redirect_uri, response_type=code, scope",
            "include state parameter for CSRF protection",
            "receive authorization code at callback URL",
            "exchange code for tokens at token endpoint (server-side, with client_secret)",
            "validate and store tokens securely",
        ],
        "recommended": [
            "use PKCE even for confidential clients",
            "validate state parameter matches on callback",
            "store tokens in httpOnly cookies, not localStorage",
            "implement token refresh with rotation",
        ],
        "gotcha_keys": ["oauth-state-csrf", "oauth-pkce-required", "redirect-uri-validation"],
    },
    "oauth-pkce": {
        "description": "OAuth 2.0 Authorization Code Flow with PKCE (for SPAs/mobile)",
        "required_steps": [
            "generate code_verifier (random 43-128 chars)",
            "compute code_challenge = base64url(SHA256(code_verifier))",
            "redirect to authorization endpoint with code_challenge and code_challenge_method=S256",
            "include state parameter for CSRF protection",
            "receive authorization code at callback",
            "exchange code + code_verifier for tokens",
            "store tokens securely (httpOnly cookie preferred)",
        ],
        "recommended": [
            "use refresh token rotation",
            "keep access token lifetime short (5-15 min)",
            "validate state on callback",
        ],
        "gotcha_keys": ["oauth-pkce-required", "oauth-state-csrf", "jwt-in-localstorage"],
    },
    "jwt-auth": {
        "description": "JWT-based authentication",
        "required_steps": [
            "authenticate user (credentials check with constant-time comparison for passwords)",
            "generate JWT with claims: sub, iat, exp, iss",
            "set short expiration on access token (15 min recommended)",
            "sign with strong algorithm (RS256 or ES256, not HS256 for multi-service)",
            "validate JWT on each request: signature, expiration, issuer, audience",
        ],
        "recommended": [
            "implement refresh token flow for session persistence",
            "store JWT in httpOnly cookie, not localStorage",
            "never put sensitive data in JWT payload (it's base64, not encrypted)",
            "implement token revocation (blocklist or short-lived + refresh)",
        ],
        "gotcha_keys": ["jwt-in-localstorage", "jwt-no-expiration", "jwt-algorithm-none", "timing-attack-comparison"],
    },
    "session-auth": {
        "description": "Server-side session authentication",
        "required_steps": [
            "authenticate user (constant-time password comparison)",
            "create session on server (database or Redis)",
            "set session ID in httpOnly, Secure, SameSite cookie",
            "validate session on each request",
            "regenerate session ID after login (prevent fixation)",
        ],
        "recommended": [
            "set session expiration (absolute and idle timeout)",
            "implement CSRF protection (SameSite cookie or CSRF token)",
            "invalidate session on logout (server-side deletion)",
        ],
        "gotcha_keys": ["session-fixation", "cookie-httponly-missing", "cookie-samesite-none"],
    },
}

# Keywords to detect flow type from description
_FLOW_KEYWORDS: dict[str, list[str]] = {
    "oauth-authorization-code": ["oauth", "authorization code", "auth code", "provider", "google", "github"],
    "oauth-pkce": ["pkce", "spa oauth", "mobile oauth", "public client", "code_verifier", "code_challenge", "oauth"],
    "jwt-auth": ["jwt", "token", "bearer", "json web token", "access token"],
    "session-auth": ["session", "cookie auth", "server session", "session-based"],
}


def auth_validate_flow(flow_description: str) -> dict[str, Any]:
    """Validate completeness of an authentication flow description."""
    desc_lower = flow_description.lower()

    # Detect flow type
    detected_flows: list[tuple[int, str]] = []
    for flow_type, keywords in _FLOW_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in desc_lower)
        if score > 0:
            detected_flows.append((score, flow_type))

    detected_flows.sort(key=lambda x: x[0], reverse=True)

    if not detected_flows:
        # Default to JWT if no clear match
        detected_flows = [(0, "jwt-auth")]

    flow_type = detected_flows[0][1]
    flow_spec = _FLOW_REQUIREMENTS[flow_type]

    # Check which required steps are mentioned
    missing_steps = []
    present_steps = []
    for step in flow_spec["required_steps"]:
        # Extract key terms from the step
        key_terms = _extract_key_terms(step)
        if any(term in desc_lower for term in key_terms):
            present_steps.append(step)
        else:
            missing_steps.append(step)

    # Check recommended steps
    missing_recommended = []
    for rec in flow_spec.get("recommended", []):
        key_terms = _extract_key_terms(rec)
        if not any(term in desc_lower for term in key_terms):
            missing_recommended.append(rec)

    # Load relevant gotchas
    gotchas = _load_gotchas()
    relevant_gotchas = []
    for key in flow_spec.get("gotcha_keys", []):
        if key in gotchas:
            relevant_gotchas.append({"id": key, **gotchas[key]})

    completeness = len(present_steps) / len(flow_spec["required_steps"]) if flow_spec["required_steps"] else 0

    return {
        "flow_type": flow_type,
        "flow_description": flow_spec["description"],
        "completeness": round(completeness * 100),
        "steps_present": present_steps,
        "steps_missing": missing_steps,
        "recommended_additions": missing_recommended,
        "security_gotchas": relevant_gotchas,
        "verdict": "complete" if completeness >= 0.8 else "incomplete" if completeness >= 0.4 else "minimal",
    }


def _extract_key_terms(step: str) -> list[str]:
    """Extract searchable key terms from a step description."""
    terms = []
    # Extract technical terms (hyphenated or camelCase fragments)
    for word in re.findall(r"[a-z_]+(?:-[a-z_]+)*", step.lower()):
        if len(word) > 3 and word not in {"with", "from", "each", "that", "this", "than", "them", "your", "have", "been"}:
            terms.append(word)
    return terms


# ── auth_diagnose ───────────────────────────────────────────────

# Symptom-to-gotcha mapping
_SYMPTOM_MAP: dict[str, list[str]] = {
    "401": ["401-vs-403", "jwt-no-expiration", "jwt-algorithm-none"],
    "403": ["401-vs-403"],
    "unauthorized": ["401-vs-403", "jwt-no-expiration"],
    "forbidden": ["401-vs-403"],
    "cors": ["cors-wildcard-credentials", "cors-preflight-cache"],
    "cross-origin": ["cors-wildcard-credentials"],
    "preflight": ["cors-preflight-cache"],
    "options request": ["cors-preflight-cache"],
    "cookie not set": ["cookie-samesite-none", "cookie-httponly-missing", "cors-wildcard-credentials"],
    "cookie not sent": ["cookie-samesite-none", "cors-wildcard-credentials"],
    "cookie not being": ["cookie-samesite-none", "cookie-httponly-missing", "cors-wildcard-credentials"],
    "cookie blocked": ["cookie-samesite-none"],
    "cross-site": ["cookie-samesite-none", "cors-wildcard-credentials"],
    "token expired": ["jwt-no-expiration", "refresh-token-rotation"],
    "token invalid": ["jwt-algorithm-none", "jwt-no-expiration"],
    "token stolen": ["jwt-in-localstorage", "refresh-token-rotation"],
    "xss": ["jwt-in-localstorage", "cookie-httponly-missing"],
    "csrf": ["oauth-state-csrf", "cookie-samesite-none"],
    "session fixation": ["session-fixation"],
    "session hijack": ["session-fixation", "cookie-httponly-missing"],
    "redirect": ["redirect-uri-validation"],
    "open redirect": ["redirect-uri-validation"],
    "localstorage": ["jwt-in-localstorage"],
    "refresh token": ["refresh-token-rotation", "jwt-no-expiration"],
    "timing": ["timing-attack-comparison"],
    "state parameter": ["oauth-state-csrf"],
    "pkce": ["oauth-pkce-required"],
    "algorithm": ["jwt-algorithm-none"],
}


def auth_diagnose(symptom: str) -> dict[str, Any]:
    """Diagnose an authentication/authorization issue from a symptom."""
    symptom_lower = symptom.lower()
    gotchas = _load_gotchas()

    matched_keys: set[str] = set()

    # Keyword matching
    for keyword, gotcha_keys in _SYMPTOM_MAP.items():
        if keyword in symptom_lower:
            matched_keys.update(gotcha_keys)

    # Also check each gotcha's common_symptoms
    for key, gotcha in gotchas.items():
        for gs in gotcha.get("common_symptoms", []):
            if gs.lower() in symptom_lower or symptom_lower in gs.lower():
                matched_keys.add(key)

    matched_gotchas = []
    for key in matched_keys:
        if key in gotchas:
            matched_gotchas.append({"id": key, **gotchas[key]})

    result: dict[str, Any] = {
        "symptom": symptom,
        "matches_found": len(matched_gotchas),
    }

    if matched_gotchas:
        result["diagnosis"] = matched_gotchas
        all_fixes = []
        for g in matched_gotchas:
            all_fixes.extend(g.get("fix_strategies", []))
        result["recommended_fixes"] = all_fixes[:5]
    else:
        result["diagnosis"] = "No known auth issue matched."
        result["debug_steps"] = [
            "Check browser DevTools Network tab — look at response headers and status codes",
            "Verify the token/cookie is being sent in the request (Authorization header or Cookie)",
            "Check server logs for the exact rejection reason",
            "Test with curl to isolate browser vs server issue",
            "Verify token hasn't expired: decode JWT at jwt.io (don't paste production tokens)",
        ]

    return result
