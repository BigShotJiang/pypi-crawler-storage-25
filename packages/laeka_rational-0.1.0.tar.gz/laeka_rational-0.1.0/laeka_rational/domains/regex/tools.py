"""Regex domain MCP tools — registered on the FastMCP server."""

from typing import Any

from .engine import regex_test, regex_explain, regex_build


def register_regex_tools(mcp) -> None:
    """Register all Regex tools on the FastMCP server instance."""

    @mcp.tool()
    def regex_test_tool(pattern: str, test_strings: list[str], flags: str = "") -> dict[str, Any]:
        """Execute a regex pattern against test strings and return exact matches/captures.

        Returns match positions, captured groups (numbered and named), and validates
        the pattern syntax. Use this to verify a regex behaves correctly before deploying.

        Args:
            pattern: The regex pattern to test (e.g. r'(\\d{4})-(\\d{2})-(\\d{2})')
            test_strings: List of strings to test the pattern against
            flags: Optional flags string: 'i'=ignorecase, 'm'=multiline, 's'=dotall, 'x'=verbose
        """
        return regex_test(pattern, test_strings, flags)

    @mcp.tool()
    def regex_explain_tool(pattern: str) -> dict[str, Any]:
        """Decompose a regex pattern into human-readable tokens with explanations.

        Breaks down each component of the regex and explains what it does.
        Also warns about known gotchas (greedy quantifiers, catastrophic backtracking,
        unicode issues, etc.) when detected in the pattern.

        Args:
            pattern: The regex pattern to explain (e.g. r'^(?P<name>[a-zA-Z]+)\\s+(?P<age>\\d+)$')
        """
        return regex_explain(pattern)

    @mcp.tool()
    def regex_build_tool(description: str, test_strings: list[str] | None = None) -> dict[str, Any]:
        """Build a regex from a natural language description.

        Matches against ~15 battle-tested pattern templates (email, URL, phone, date,
        UUID, hex color, etc.) and validates against optional test strings.
        Returns the pattern, explanation, and test results.

        Args:
            description: What you want to match (e.g. "email address", "ISO date",
                "URL", "phone number", "content between quotes")
            test_strings: Optional strings to validate the suggested pattern against
        """
        return regex_build(description, test_strings)
