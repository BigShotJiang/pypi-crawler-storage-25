"""Regex domain engine — test, explain, and build regular expressions."""

import json
import re
from pathlib import Path
from typing import Any


_DATA_DIR = Path(__file__).parent / "data"
_gotchas: dict[str, Any] | None = None


def _load_gotchas() -> dict[str, Any]:
    global _gotchas
    if _gotchas is None:
        with open(_DATA_DIR / "gotchas.json") as f:
            _gotchas = json.load(f)
    return _gotchas


# ── regex_test ──────────────────────────────────────────────────

def regex_test(pattern: str, test_strings: list[str], flags: str = "") -> dict[str, Any]:
    """Execute a regex pattern against test strings, return exact matches and captures."""
    flag_value = _parse_flags(flags)

    try:
        compiled = re.compile(pattern, flag_value)
    except re.error as e:
        return {
            "pattern": pattern,
            "valid": False,
            "error": str(e),
            "suggestion": _suggest_fix_for_error(str(e)),
        }

    results = []
    for s in test_strings:
        matches = []
        for m in compiled.finditer(s):
            match_info: dict[str, Any] = {
                "match": m.group(),
                "span": list(m.span()),
            }
            if m.groups():
                match_info["groups"] = list(m.groups())
            if m.groupdict():
                named = {k: v for k, v in m.groupdict().items() if v is not None}
                if named:
                    match_info["named_groups"] = named
            matches.append(match_info)

        results.append({
            "input": s,
            "matched": len(matches) > 0,
            "match_count": len(matches),
            "matches": matches,
        })

    return {
        "pattern": pattern,
        "valid": True,
        "flags": flags or "none",
        "results": results,
    }


# ── regex_explain ───────────────────────────────────────────────

# Token patterns for decomposition (order matters — longest first)
_TOKEN_PATTERNS: list[tuple[str, str]] = [
    (r"\(\?P<(\w+)>", "named_group_start"),
    (r"\(\?<(\w+)>", "named_group_start"),
    (r"\(\?:", "non_capturing_group_start"),
    (r"\(\?=", "lookahead_start"),
    (r"\(\?!", "neg_lookahead_start"),
    (r"\(\?<=", "lookbehind_start"),
    (r"\(\?<!", "neg_lookbehind_start"),
    (r"\(\?[imslux]+:", "flag_group_start"),
    (r"\(\?[imslux]+\)", "inline_flag"),
    (r"\(", "group_start"),
    (r"\)", "group_end"),
    (r"\[(\^?)((?:\\.|[^\]])*)\]", "character_class"),
    (r"\\d", "digit"),
    (r"\\D", "non_digit"),
    (r"\\w", "word_char"),
    (r"\\W", "non_word_char"),
    (r"\\s", "whitespace"),
    (r"\\S", "non_whitespace"),
    (r"\\b", "word_boundary"),
    (r"\\B", "non_word_boundary"),
    (r"\\A", "string_start"),
    (r"\\Z", "string_end"),
    (r"\\(\d+)", "backreference"),
    (r"\\.", "escaped_char"),
    (r"\.", "any_char"),
    (r"\^", "start_anchor"),
    (r"\$", "end_anchor"),
    (r"\|", "alternation"),
    (r"\{(\d+),(\d+)\}", "range_quantifier"),
    (r"\{(\d+),\}", "min_quantifier"),
    (r"\{(\d+)\}", "exact_quantifier"),
    (r"\*\?", "lazy_zero_or_more"),
    (r"\+\?", "lazy_one_or_more"),
    (r"\?\?", "lazy_optional"),
    (r"\*", "zero_or_more"),
    (r"\+", "one_or_more"),
    (r"\?", "optional"),
]

_EXPLANATIONS: dict[str, str] = {
    "digit": "any digit (0-9)",
    "non_digit": "any non-digit",
    "word_char": "any word character (letter, digit, underscore)",
    "non_word_char": "any non-word character",
    "whitespace": "any whitespace (space, tab, newline)",
    "non_whitespace": "any non-whitespace",
    "word_boundary": "word boundary (between word and non-word char)",
    "non_word_boundary": "NOT at a word boundary",
    "string_start": "absolute start of string",
    "string_end": "absolute end of string",
    "any_char": "any character (except newline by default)",
    "start_anchor": "start of string/line",
    "end_anchor": "end of string/line",
    "alternation": "OR",
    "zero_or_more": "zero or more (greedy)",
    "one_or_more": "one or more (greedy)",
    "optional": "optional (0 or 1)",
    "lazy_zero_or_more": "zero or more (lazy — match as few as possible)",
    "lazy_one_or_more": "one or more (lazy — match as few as possible)",
    "lazy_optional": "optional (lazy)",
    "group_start": "start of capturing group",
    "group_end": "end of group",
    "non_capturing_group_start": "start of non-capturing group",
    "lookahead_start": "start of positive lookahead (must be followed by...)",
    "neg_lookahead_start": "start of negative lookahead (must NOT be followed by...)",
    "lookbehind_start": "start of positive lookbehind (must be preceded by...)",
    "neg_lookbehind_start": "start of negative lookbehind (must NOT be preceded by...)",
}


def regex_explain(pattern: str) -> dict[str, Any]:
    """Decompose a regex pattern into human-readable tokens."""
    try:
        re.compile(pattern)
    except re.error as e:
        return {"pattern": pattern, "valid": False, "error": str(e)}

    tokens = _tokenize(pattern)

    # Check for relevant gotchas
    gotchas = _load_gotchas()
    relevant = _find_relevant_gotchas(pattern, gotchas)

    result: dict[str, Any] = {
        "pattern": pattern,
        "valid": True,
        "breakdown": tokens,
    }
    if relevant:
        result["warnings"] = relevant

    return result


def _tokenize(pattern: str) -> list[dict[str, str]]:
    """Tokenize a regex pattern into annotated components."""
    tokens = []
    i = 0
    while i < len(pattern):
        matched = False
        for tok_pattern, tok_type in _TOKEN_PATTERNS:
            m = re.match(tok_pattern, pattern[i:])
            if m:
                token_str = m.group()
                explanation = _explain_token(tok_type, m)
                tokens.append({"token": token_str, "meaning": explanation})
                i += len(token_str)
                matched = True
                break
        if not matched:
            # Literal character
            tokens.append({"token": pattern[i], "meaning": f"literal '{pattern[i]}'"})
            i += 1
    return tokens


def _explain_token(tok_type: str, match: re.Match) -> str:
    """Return human explanation for a token type."""
    if tok_type in _EXPLANATIONS:
        return _EXPLANATIONS[tok_type]
    if tok_type == "escaped_char":
        return f"literal '{match.group()[1]}'"
    if tok_type == "character_class":
        negated = match.group(1) == "^"
        inner = match.group(2)
        prefix = "NOT " if negated else ""
        return f"{prefix}one of: {inner}"
    if tok_type == "named_group_start":
        name = match.group(1)
        return f"start of named group '{name}'"
    if tok_type == "range_quantifier":
        return f"between {match.group(1)} and {match.group(2)} times"
    if tok_type == "min_quantifier":
        return f"at least {match.group(1)} times"
    if tok_type == "exact_quantifier":
        return f"exactly {match.group(1)} times"
    if tok_type == "backreference":
        return f"backreference to group {match.group(1)}"
    if tok_type == "flag_group_start":
        return f"group with flags: {match.group()}"
    if tok_type == "inline_flag":
        return f"set inline flags: {match.group()}"
    return tok_type


# ── regex_build ─────────────────────────────────────────────────

# Common pattern templates
_PATTERN_TEMPLATES: dict[str, dict[str, str]] = {
    "email": {
        "pattern": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
        "description": "Basic email validation",
    },
    "url": {
        "pattern": r"https?://[^\s<>\"']+",
        "description": "HTTP/HTTPS URL",
    },
    "ipv4": {
        "pattern": r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
        "description": "IPv4 address with validation",
    },
    "phone": {
        "pattern": r"\+?\d{1,3}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}",
        "description": "International phone number (flexible format)",
    },
    "date_iso": {
        "pattern": r"\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])",
        "description": "ISO 8601 date (YYYY-MM-DD)",
    },
    "hex_color": {
        "pattern": r"#(?:[0-9a-fA-F]{3}){1,2}\b",
        "description": "CSS hex color (#RGB or #RRGGBB)",
    },
    "uuid": {
        "pattern": r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
        "description": "UUID v4 format",
    },
    "slug": {
        "pattern": r"[a-z0-9]+(?:-[a-z0-9]+)*",
        "description": "URL slug (lowercase, hyphen-separated)",
    },
    "number": {
        "pattern": r"-?\d+(?:\.\d+)?",
        "description": "Integer or decimal number (optional negative)",
    },
    "whitespace_trim": {
        "pattern": r"^\s+|\s+$",
        "description": "Leading/trailing whitespace (for stripping)",
    },
    "html_tag": {
        "pattern": r"</?([a-zA-Z][\w-]*)\b[^>]*>",
        "description": "HTML tag (opening or closing)",
    },
    "quoted_string": {
        "pattern": r"\"([^\"\\]*(?:\\.[^\"\\]*)*)\"",
        "description": "Double-quoted string with escaped chars",
    },
    "word": {
        "pattern": r"\b\w+\b",
        "description": "Whole word",
    },
    "between": {
        "pattern": "(?<=START).*?(?=END)",
        "description": "Content between START and END markers (replace START/END)",
    },
}

# Keywords mapped to template keys
_KEYWORD_MAP: dict[str, list[str]] = {
    "email": ["email"],
    "mail": ["email"],
    "url": ["url"],
    "link": ["url"],
    "http": ["url"],
    "ip": ["ipv4"],
    "ipv4": ["ipv4"],
    "ip address": ["ipv4"],
    "phone": ["phone"],
    "telephone": ["phone"],
    "date": ["date_iso"],
    "iso date": ["date_iso"],
    "color": ["hex_color"],
    "hex": ["hex_color"],
    "uuid": ["uuid"],
    "guid": ["uuid"],
    "slug": ["slug"],
    "number": ["number"],
    "integer": ["number"],
    "decimal": ["number"],
    "float": ["number"],
    "trim": ["whitespace_trim"],
    "whitespace": ["whitespace_trim"],
    "strip": ["whitespace_trim"],
    "html": ["html_tag"],
    "tag": ["html_tag"],
    "quoted": ["quoted_string"],
    "string": ["quoted_string"],
    "word": ["word"],
    "between": ["between"],
    "extract": ["between", "quoted_string"],
}


def regex_build(description: str, test_strings: list[str] | None = None) -> dict[str, Any]:
    """Build a regex pattern from a natural language description.

    Matches against known pattern templates and validates against
    provided test strings.
    """
    desc_lower = description.lower()

    # Find matching templates
    matched_keys: set[str] = set()
    for keyword, template_keys in _KEYWORD_MAP.items():
        if keyword in desc_lower:
            matched_keys.update(template_keys)

    suggestions = []
    for key in matched_keys:
        template = _PATTERN_TEMPLATES[key]
        entry: dict[str, Any] = {
            "name": key,
            "pattern": template["pattern"],
            "description": template["description"],
        }

        # Validate against test strings if provided
        if test_strings:
            try:
                compiled = re.compile(template["pattern"])
                test_results = []
                for s in test_strings:
                    matches = compiled.findall(s)
                    test_results.append({
                        "input": s,
                        "matched": len(matches) > 0,
                        "matches": matches[:5],
                    })
                entry["test_results"] = test_results
            except re.error:
                entry["test_results"] = "pattern compilation failed"

        suggestions.append(entry)

    # Also check gotchas relevant to the description
    gotchas = _load_gotchas()
    relevant = _find_relevant_gotchas(desc_lower, gotchas)

    result: dict[str, Any] = {
        "description": description,
        "suggestions_found": len(suggestions),
        "suggestions": suggestions,
    }

    if not suggestions:
        result["tip"] = (
            "No template matched. Try describing with keywords like: "
            "email, url, phone, date, number, uuid, slug, html, quoted, between, word"
        )

    if relevant:
        result["relevant_gotchas"] = relevant

    return result


# ── Helpers ─────────────────────────────────────────────────────

def _parse_flags(flags_str: str) -> int:
    """Parse flag string like 'im' into re flags."""
    flag_map = {
        "i": re.IGNORECASE,
        "m": re.MULTILINE,
        "s": re.DOTALL,
        "x": re.VERBOSE,
        "u": re.UNICODE,
        "a": re.ASCII,
    }
    result = 0
    for char in flags_str.lower():
        if char in flag_map:
            result |= flag_map[char]
    return result


def _suggest_fix_for_error(error: str) -> str:
    """Suggest a fix for common regex compilation errors."""
    if "unterminated" in error:
        return "Check for unclosed parentheses, brackets, or quotes"
    if "unbalanced" in error:
        return "Count your opening and closing parentheses/brackets"
    if "nothing to repeat" in error:
        return "A quantifier (+, *, ?) has no preceding element to repeat"
    if "bad escape" in error:
        return "Invalid escape sequence — use raw strings r'...' or double-escape"
    if "bad character range" in error:
        return "Invalid range in character class — check hyphen placement"
    return "Check the pattern syntax"


def _find_relevant_gotchas(pattern_or_desc: str, gotchas: dict) -> list[dict[str, Any]]:
    """Find gotchas relevant to a pattern or description."""
    text = pattern_or_desc.lower()
    relevant = []

    # Direct symptom matching
    for key, gotcha in gotchas.items():
        for symptom in gotcha.get("common_symptoms", []):
            if symptom.lower() in text or text in symptom.lower():
                relevant.append({"id": key, **gotcha})
                break

    # Pattern-based detection
    if ".*" in text or ".+" in text:
        if "greedy-vs-lazy" not in [r["id"] for r in relevant]:
            g = gotchas.get("greedy-vs-lazy")
            if g:
                relevant.append({"id": "greedy-vs-lazy", **g})

    if re.search(r"\(.+\)[*+]", text):
        if "catastrophic-backtracking" not in [r["id"] for r in relevant]:
            g = gotchas.get("catastrophic-backtracking")
            if g:
                relevant.append({"id": "catastrophic-backtracking", **g})

    return relevant
