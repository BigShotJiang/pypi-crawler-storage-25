"""Refactoring domain MCP tools — registered on the FastMCP server."""

from typing import Any

from .engine import refactor_impact, refactor_rename_plan


def register_refactor_tools(mcp) -> None:
    """Register all Refactor tools on the FastMCP server instance."""

    @mcp.tool()
    def refactor_impact_tool(
        symbol_name: str,
        source_code_map: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Analyze the blast radius of renaming a symbol across a codebase.

        Lists all files and lines that reference the symbol via imports (ES named,
        default, type, re-export, CJS require), usage (type annotations, JSX,
        extends/implements), and string references. Pattern-based, not AST.

        When called without source_code_map, returns grep patterns you can run
        yourself. When called with source_code_map ({filepath: content}), returns
        exact file/line impacts.

        Args:
            symbol_name: The symbol to search for (function, class, type, variable)
            source_code_map: Optional dict of {filepath: file_content} to analyze
        """
        return refactor_impact(symbol_name, source_code_map)

    @mcp.tool()
    def refactor_rename_plan_tool(
        old_name: str,
        new_name: str,
        source_code_map: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Generate a complete rename plan showing every change needed.

        Returns per-file, per-line before/after diffs. Warns about gotchas:
        barrel re-exports, default exports, dynamic imports, string references,
        CSS class names, type imports, test files.

        Without source_code_map, returns grep/sed commands to execute manually.

        Args:
            old_name: Current name of the symbol
            new_name: New name for the symbol
            source_code_map: Optional dict of {filepath: file_content} to analyze
        """
        return refactor_rename_plan(old_name, new_name, source_code_map)
