"""Refactoring domain engine — symbol impact analysis and rename planning."""

import json
import re
from pathlib import Path
from typing import Any


_DATA_DIR = Path(__file__).parent / "data"
_gotchas: dict[str, Any] | None = None


def _load_gotchas() -> dict[str, Any]:
    global _gotchas
    if _gotchas is None:
        with open(_DATA_DIR / "gotchas.json") as f:
            _gotchas = json.load(f)
    return _gotchas


# ── Import patterns ─────────────────────────────────────────────

def _build_import_patterns(symbol: str) -> list[dict[str, str]]:
    """Build regex patterns to find all import forms of a symbol."""
    # Escape for regex
    sym = re.escape(symbol)

    return [
        # ES named import: import { Symbol } from '...'
        {"pattern": rf"\bimport\s+\{{[^}}]*\b{sym}\b[^}}]*\}}\s+from\s+", "type": "es_named_import"},
        # ES default import: import Symbol from '...'
        {"pattern": rf"\bimport\s+{sym}\s+from\s+", "type": "es_default_import"},
        # ES type import: import type { Symbol } from '...'
        {"pattern": rf"\bimport\s+type\s+\{{[^}}]*\b{sym}\b[^}}]*\}}\s+from\s+", "type": "es_type_import"},
        # ES re-export: export { Symbol } from '...'
        {"pattern": rf"\bexport\s+\{{[^}}]*\b{sym}\b[^}}]*\}}\s+from\s+", "type": "es_re_export"},
        # ES export: export { Symbol }
        {"pattern": rf"\bexport\s+\{{[^}}]*\b{sym}\b[^}}]*\}}", "type": "es_export"},
        # CJS require destructuring: const { Symbol } = require('...')
        {"pattern": rf"\b(?:const|let|var)\s+\{{[^}}]*\b{sym}\b[^}}]*\}}\s*=\s*require\s*\(", "type": "cjs_require"},
        # CJS module.exports: module.exports = { Symbol }
        {"pattern": rf"module\.exports\s*=\s*\{{[^}}]*\b{sym}\b", "type": "cjs_export"},
        # Dynamic import
        {"pattern": rf"\bimport\s*\(\s*.*{sym}", "type": "dynamic_import"},
    ]


def _build_usage_patterns(symbol: str) -> list[dict[str, str]]:
    """Build regex patterns to find usages of a symbol (not just imports)."""
    sym = re.escape(symbol)

    return [
        # Direct usage as identifier
        {"pattern": rf"\b{sym}\b", "type": "reference"},
        # Property access: X.symbol or X?.symbol
        {"pattern": rf"\.\s*{sym}\b", "type": "property_access"},
        # Type annotation: : Symbol, extends Symbol, implements Symbol
        {"pattern": rf":\s*{sym}\b", "type": "type_annotation"},
        {"pattern": rf"\bextends\s+{sym}\b", "type": "extends"},
        {"pattern": rf"\bimplements\s+{sym}\b", "type": "implements"},
        # JSX component: <Symbol or </Symbol
        {"pattern": rf"</?{sym}[\s>]", "type": "jsx_component"},
        # String reference (in quotes)
        {"pattern": rf"['\"`]{sym}['\"`]", "type": "string_reference"},
    ]


# ── refactor_impact ─────────────────────────────────────────────

def refactor_impact(symbol_name: str, source_code_map: dict[str, str] | None = None) -> dict[str, Any]:
    """Analyze the impact of renaming a symbol across files.

    Args:
        symbol_name: The symbol to search for (function, class, variable, type name)
        source_code_map: Dict of {filepath: content} to analyze. If None, returns
                        the patterns to search for (caller can use grep).
    """
    import_patterns = _build_import_patterns(symbol_name)
    usage_patterns = _build_usage_patterns(symbol_name)

    result: dict[str, Any] = {
        "symbol": symbol_name,
        "import_patterns": [
            {"regex": p["pattern"], "type": p["type"]} for p in import_patterns
        ],
        "usage_patterns": [
            {"regex": p["pattern"], "type": p["type"]} for p in usage_patterns
        ],
    }

    if source_code_map:
        # Analyze provided source code
        impacts = []
        for filepath, content in source_code_map.items():
            file_hits = []
            lines = content.split("\n")

            for line_num, line in enumerate(lines, 1):
                matched_type = None

                # Check imports first
                for p in import_patterns:
                    if re.search(p["pattern"], line):
                        matched_type = p["type"]
                        break

                if not matched_type:
                    # Check usages — try all patterns, prefer most specific
                    for p in usage_patterns:
                        if re.search(p["pattern"], line):
                            matched_type = p["type"]
                            # Don't break on generic "reference" — try for more specific
                            if matched_type != "reference":
                                break

                if matched_type:
                    file_hits.append({
                        "line": line_num,
                        "type": matched_type,
                        "content": line.strip(),
                    })

            if file_hits:
                impacts.append({
                    "file": filepath,
                    "hits": len(file_hits),
                    "references": file_hits,
                })

        result["files_impacted"] = len(impacts)
        result["total_references"] = sum(i["hits"] for i in impacts)
        result["impacts"] = impacts
    else:
        result["note"] = (
            "No source_code_map provided. Use the import_patterns and usage_patterns "
            "with grep/ripgrep to find all references across your codebase."
        )
        # Provide a ready-to-use grep command
        result["grep_command"] = f"rg -n '\\b{re.escape(symbol_name)}\\b' --type ts --type tsx --type js --type jsx"

    # Relevant gotchas
    gotchas = _load_gotchas()
    result["gotchas"] = list(gotchas.values())[:3]  # Top 3 general gotchas

    return result


# ── refactor_rename_plan ────────────────────────────────────────

def refactor_rename_plan(
    old_name: str,
    new_name: str,
    source_code_map: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Generate a complete rename plan for a symbol.

    Args:
        old_name: Current symbol name
        new_name: Desired new name
        source_code_map: Dict of {filepath: content}. If None, returns patterns only.
    """
    old_escaped = re.escape(old_name)

    # Build replacement rules
    replacements = [
        {
            "description": f"Named import/export: {old_name} → {new_name}",
            "search": rf"\b{old_escaped}\b",
            "replace": new_name,
            "context": "import/export statements",
        },
        {
            "description": f"String references: '{old_name}' → '{new_name}'",
            "search": rf"(['\"`]){old_escaped}(['\"`])",
            "replace": rf"\g<1>{new_name}\g<2>",
            "context": "string literals (API routes, config keys, etc.)",
        },
    ]

    result: dict[str, Any] = {
        "old_name": old_name,
        "new_name": new_name,
        "replacement_rules": replacements,
    }

    if source_code_map:
        changes = []
        for filepath, content in source_code_map.items():
            lines = content.split("\n")
            file_changes = []

            for line_num, line in enumerate(lines, 1):
                if re.search(rf"\b{old_escaped}\b", line):
                    new_line = re.sub(rf"\b{old_escaped}\b", new_name, line)
                    file_changes.append({
                        "line": line_num,
                        "before": line.strip(),
                        "after": new_line.strip(),
                    })

            if file_changes:
                changes.append({
                    "file": filepath,
                    "changes_count": len(file_changes),
                    "changes": file_changes,
                })

        result["files_to_modify"] = len(changes)
        result["total_changes"] = sum(c["changes_count"] for c in changes)
        result["plan"] = changes
    else:
        result["grep_command"] = f"rg -n '\\b{old_escaped}\\b' --type ts --type js"
        result["sed_command"] = f"sed -i '' 's/\\b{old_escaped}\\b/{new_name}/g'"
        result["note"] = "Provide source_code_map for a detailed per-file rename plan."

    # Warnings
    warnings = []
    gotchas = _load_gotchas()

    # Check if it looks like a default export
    if old_name[0].isupper():
        warnings.append("Uppercase name suggests a component/class — check JSX usage: <" + old_name + ">")

    # Always warn about string references
    warnings.append(f"Search for '{old_name}' in string literals — API routes, config, tests")

    # Check for common gotcha relevance
    for key, gotcha in gotchas.items():
        if "rename" in key or "export" in key or "barrel" in key:
            warnings.append(f"[{key}] {gotcha['trigger']}")

    result["warnings"] = warnings

    return result
