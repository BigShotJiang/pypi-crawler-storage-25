"""SQL domain MCP tools — registered on the FastMCP server."""

from typing import Any

from .engine import sql_explain, sql_migration_check, sql_suggest_index


def register_sql_tools(mcp) -> None:
    """Register all SQL tools on the FastMCP server instance."""

    @mcp.tool()
    def sql_explain_tool(query: str, db_type: str = "postgres") -> dict[str, Any]:
        """Analyze a SQL query for anti-patterns, performance issues, and semantic errors.

        Returns detected operation, tables involved, warnings (NULL comparisons,
        SELECT *, OFFSET pagination, correlated subqueries), and relevant gotchas.
        Does NOT execute the query — pure static analysis.

        Args:
            query: The SQL query to analyze
            db_type: Database type: 'postgres', 'mysql', or 'sqlite'
        """
        return sql_explain(query, db_type)

    @mcp.tool()
    def sql_migration_check_tool(migration_sql: str, db_type: str = "postgres") -> dict[str, Any]:
        """Check a database migration for risks — locks, data loss, downtime.

        Scans for dangerous patterns: NOT NULL without DEFAULT, non-concurrent
        index creation, column renames/drops, FK additions, table drops.
        Returns risk level (critical/high/medium) and safe alternatives.

        Args:
            migration_sql: The migration SQL to analyze
            db_type: Database type: 'postgres', 'mysql', or 'sqlite'
        """
        return sql_migration_check(migration_sql, db_type)

    @mcp.tool()
    def sql_suggest_index_tool(query: str, schema: str | None = None) -> dict[str, Any]:
        """Suggest optimal indexes for a SQL query.

        Analyzes WHERE, JOIN, and ORDER BY clauses to recommend B-tree indexes,
        composite indexes, and special indexes (GIN for LIKE, trigram).
        Returns specific index suggestions with rationale.

        Args:
            query: The SQL query to optimize
            schema: Optional table schema (CREATE TABLE statement) for additional context
        """
        return sql_suggest_index(query, schema)
