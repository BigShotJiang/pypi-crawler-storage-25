"""SQL domain engine — explain queries, check migrations, suggest indexes."""

import json
import re
from pathlib import Path
from typing import Any


_DATA_DIR = Path(__file__).parent / "data"
_gotchas: dict[str, Any] | None = None


def _load_gotchas() -> dict[str, Any]:
    global _gotchas
    if _gotchas is None:
        with open(_DATA_DIR / "gotchas.json") as f:
            _gotchas = json.load(f)
    return _gotchas


# ── sql_explain ─────────────────────────────────────────────────

def sql_explain(query: str, db_type: str = "postgres") -> dict[str, Any]:
    """Analyze a SQL query and return a simulated execution plan with warnings."""
    query_upper = query.strip().upper()
    query_lower = query.strip().lower()
    db = db_type.lower()

    analysis: dict[str, Any] = {
        "query": query,
        "db_type": db,
        "operation": _detect_operation(query_upper),
        "tables": _extract_tables(query_lower),
        "warnings": [],
        "suggestions": [],
    }

    # Detect common anti-patterns
    if "SELECT *" in query_upper:
        analysis["warnings"].append("SELECT * fetches all columns — specify only needed columns")

    if "OFFSET" in query_upper:
        analysis["warnings"].append("OFFSET pagination degrades with high values — consider keyset pagination")

    if re.search(r"WHERE\s+.*\s*=\s*NULL", query_upper):
        analysis["warnings"].append("= NULL always returns NULL — use IS NULL instead")

    if re.search(r"WHERE\s+.*\s*!=\s*NULL", query_upper) or re.search(r"WHERE\s+.*\s*<>\s*NULL", query_upper):
        analysis["warnings"].append("<> NULL always returns NULL — use IS NOT NULL instead")

    if "NOT IN" in query_upper and "NULL" not in query_upper:
        analysis["warnings"].append("NOT IN with a subquery that may return NULLs yields empty results — use NOT EXISTS instead")

    if re.search(r"LIKE\s+'%", query_upper):
        analysis["warnings"].append("LIKE with leading % prevents index usage — consider full-text search or trigram index")

    if "DISTINCT" in query_upper and "GROUP BY" not in query_upper:
        analysis["suggestions"].append("DISTINCT on large results is expensive — consider if GROUP BY or EXISTS would be more efficient")

    if re.search(r"ORDER BY\s+\w+\s+(ASC|DESC)\s*,\s*\w+\s+(ASC|DESC)", query_upper):
        analysis["suggestions"].append("Multi-column ORDER BY benefits from a composite index matching the sort order")

    # Subquery detection
    subquery_count = query_upper.count("SELECT") - 1
    if subquery_count > 0:
        analysis["suggestions"].append(f"Query contains {subquery_count} subquery(ies) — consider rewriting with JOINs or CTEs for clarity")

    # JOIN analysis
    join_count = len(re.findall(r"\bJOIN\b", query_upper))
    if join_count > 3:
        analysis["warnings"].append(f"{join_count} JOINs detected — verify indexes on all join columns")

    # Correlated subquery detection
    if re.search(r"WHERE\s+.*\(\s*SELECT\s+.*WHERE\s+.*\.\w+\s*=\s*\w+\.\w+", query_upper):
        analysis["warnings"].append("Possible correlated subquery — executes once per outer row, consider JOIN or lateral")

    # Relevant gotchas
    gotchas = _load_gotchas()
    relevant = _find_relevant_gotchas(query_lower, db, gotchas)
    if relevant:
        analysis["relevant_gotchas"] = relevant

    return analysis


# ── sql_migration_check ─────────────────────────────────────────

_MIGRATION_RISKS: list[dict[str, Any]] = [
    {
        "pattern": r"ADD\s+COLUMN\s+\w+\s+\w+.*NOT\s+NULL(?!\s+DEFAULT)",
        "risk": "high",
        "title": "NOT NULL column without DEFAULT",
        "detail": "Adds NOT NULL column without default — requires table rewrite and full lock on large tables",
        "fix": "Add as NULL first, backfill, then set NOT NULL. Or add with DEFAULT (instant in PG11+).",
    },
    {
        "pattern": r"CREATE\s+INDEX(?!\s+CONCURRENTLY)",
        "risk": "high",
        "title": "Non-concurrent index creation",
        "detail": "CREATE INDEX locks the table for writes — can block for minutes on large tables",
        "fix": "Use CREATE INDEX CONCURRENTLY (PostgreSQL) or ALGORITHM=INPLACE (MySQL).",
    },
    {
        "pattern": r"ALTER\s+TABLE\s+\w+\s+DROP\s+COLUMN",
        "risk": "medium",
        "title": "Column drop",
        "detail": "Dropping a column — ensure no code references it before migration runs",
        "fix": "Deploy code removal first, then drop column in a subsequent migration.",
    },
    {
        "pattern": r"ALTER\s+TABLE\s+\w+\s+RENAME\s+COLUMN",
        "risk": "high",
        "title": "Column rename",
        "detail": "Renaming a column breaks all queries using the old name",
        "fix": "Use add-new, dual-write, migrate-reads, drop-old strategy.",
    },
    {
        "pattern": r"ALTER\s+TABLE\s+\w+\s+ALTER\s+COLUMN\s+\w+\s+TYPE",
        "risk": "high",
        "title": "Column type change",
        "detail": "Changing column type may require table rewrite and full lock",
        "fix": "Check if the cast is safe (e.g., varchar→text is instant in PG, int→bigint is not).",
    },
    {
        "pattern": r"ADD\s+(?:CONSTRAINT\s+\w+\s+)?FOREIGN\s+KEY",
        "risk": "medium",
        "title": "Foreign key addition",
        "detail": "Adding FK requires SHARE ROW EXCLUSIVE lock on both tables (PostgreSQL)",
        "fix": "Add as NOT VALID first, then VALIDATE CONSTRAINT separately.",
    },
    {
        "pattern": r"DROP\s+TABLE",
        "risk": "critical",
        "title": "Table drop",
        "detail": "Dropping a table is irreversible data loss",
        "fix": "Ensure backups exist. Consider renaming first, dropping after verification period.",
    },
    {
        "pattern": r"TRUNCATE",
        "risk": "critical",
        "title": "Table truncate",
        "detail": "TRUNCATE removes all data and is not easily reversible",
        "fix": "Use DELETE with WHERE clause for selective removal. Ensure backups.",
    },
    {
        "pattern": r"ALTER\s+TYPE\s+\w+\s+ADD\s+VALUE",
        "risk": "medium",
        "title": "Enum value addition",
        "detail": "Adding values to ENUM types has transaction restrictions (pre-PG12)",
        "fix": "In PG12+: works in transactions. Pre-12: run outside transaction. Consider reference tables instead.",
    },
    {
        "pattern": r"UPDATE\s+\w+\s+SET\s+.*(?:WHERE\s+|$)",
        "risk": "medium",
        "title": "Data migration in DDL",
        "detail": "Large UPDATE in migration — locks rows and may timeout",
        "fix": "Batch the update: process N rows at a time with a loop or background job.",
    },
]


def sql_migration_check(migration_sql: str, db_type: str = "postgres") -> dict[str, Any]:
    """Check a migration SQL for risks — locks, data loss, performance issues."""
    migration_upper = migration_sql.strip().upper()
    db = db_type.lower()

    risks = []
    for check in _MIGRATION_RISKS:
        if re.search(check["pattern"], migration_upper):
            risks.append({
                "risk": check["risk"],
                "title": check["title"],
                "detail": check["detail"],
                "fix": check["fix"],
            })

    # Check for transaction wrapping
    has_transaction = "BEGIN" in migration_upper or "START TRANSACTION" in migration_upper

    # Relevant gotchas
    gotchas = _load_gotchas()
    migration_gotchas = [g for k, g in gotchas.items()
                         if g.get("category") == "migration" and db in g.get("db", [])]

    return {
        "migration_sql": migration_sql[:500],  # Truncate for readability
        "db_type": db,
        "risks_found": len(risks),
        "risks": sorted(risks, key=lambda r: {"critical": 0, "high": 1, "medium": 2, "low": 3}[r["risk"]]),
        "has_transaction_wrapper": has_transaction,
        "safe": len(risks) == 0,
        "migration_best_practices": migration_gotchas[:3] if migration_gotchas else [],
    }


# ── sql_suggest_index ───────────────────────────────────────────

def sql_suggest_index(query: str, schema: str | None = None) -> dict[str, Any]:
    """Suggest optimal indexes for a SQL query based on WHERE, JOIN, and ORDER BY clauses."""
    query_upper = query.strip().upper()
    query_lower = query.strip().lower()

    suggestions = []

    # Extract WHERE columns
    where_cols = _extract_where_columns(query_lower)
    if where_cols:
        suggestions.append({
            "type": "WHERE clause",
            "columns": where_cols,
            "suggestion": f"Index on ({', '.join(where_cols)})",
            "reason": "Columns used in WHERE filters benefit from B-tree index",
        })

    # Extract JOIN columns
    join_cols = _extract_join_columns(query_lower)
    for pair in join_cols:
        suggestions.append({
            "type": "JOIN",
            "columns": pair,
            "suggestion": f"Ensure indexes on both sides: {pair[0]} and {pair[1]}",
            "reason": "JOIN performance depends on indexed join columns",
        })

    # Extract ORDER BY columns
    order_cols = _extract_order_columns(query_lower)
    if order_cols:
        suggestions.append({
            "type": "ORDER BY",
            "columns": order_cols,
            "suggestion": f"Index matching sort order: ({', '.join(order_cols)})",
            "reason": "Index-ordered scan avoids sort step",
        })

    # Composite index suggestion
    if where_cols and order_cols:
        composite = where_cols + [c for c in order_cols if c not in where_cols]
        suggestions.append({
            "type": "Composite",
            "columns": composite,
            "suggestion": f"Composite index: ({', '.join(composite)})",
            "reason": "WHERE columns first, then ORDER BY columns — covers both filter and sort",
        })

    # LIKE pattern check
    if re.search(r"LIKE\s+'%", query_upper):
        suggestions.append({
            "type": "Full-text / Trigram",
            "columns": [],
            "suggestion": "Consider pg_trgm GIN index for LIKE '%pattern%' queries",
            "reason": "Leading wildcard prevents B-tree index usage",
        })

    return {
        "query": query,
        "suggestions_found": len(suggestions),
        "suggestions": suggestions,
    }


# ── Helpers ─────────────────────────────────────────────────────

def _detect_operation(query_upper: str) -> str:
    """Detect the primary SQL operation."""
    for op in ("SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "ALTER", "DROP", "TRUNCATE"):
        if query_upper.strip().startswith(op):
            return op
    return "UNKNOWN"


def _extract_tables(query_lower: str) -> list[str]:
    """Extract table names from FROM and JOIN clauses."""
    tables = []
    # FROM table
    for m in re.finditer(r"\bfrom\s+(\w+)", query_lower):
        tables.append(m.group(1))
    # JOIN table
    for m in re.finditer(r"\bjoin\s+(\w+)", query_lower):
        tables.append(m.group(1))
    # UPDATE table
    for m in re.finditer(r"\bupdate\s+(\w+)", query_lower):
        tables.append(m.group(1))
    # INTO table
    for m in re.finditer(r"\binto\s+(\w+)", query_lower):
        tables.append(m.group(1))
    return list(dict.fromkeys(tables))  # Dedupe preserving order


def _extract_where_columns(query_lower: str) -> list[str]:
    """Extract column names from WHERE clause."""
    # Match: column = ?, column > ?, column IN (...), etc.
    where_match = re.search(r"\bwhere\b(.+?)(?:\border\b|\bgroup\b|\blimit\b|\bhaving\b|$)", query_lower, re.DOTALL)
    if not where_match:
        return []
    where_clause = where_match.group(1)
    cols = re.findall(r"(\w+)\s*(?:=|!=|<>|>=?|<=?|LIKE|IN|IS|BETWEEN)\s*", where_clause, re.IGNORECASE)
    # Filter out SQL keywords and values
    keywords = {"and", "or", "not", "null", "true", "false", "in", "is", "like", "between", "exists"}
    return [c for c in cols if c.lower() not in keywords]


def _extract_join_columns(query_lower: str) -> list[list[str]]:
    """Extract column pairs from ON clauses."""
    pairs = []
    for m in re.finditer(r"\bon\s+(\w+(?:\.\w+)?)\s*=\s*(\w+(?:\.\w+)?)", query_lower):
        pairs.append([m.group(1), m.group(2)])
    return pairs


def _extract_order_columns(query_lower: str) -> list[str]:
    """Extract columns from ORDER BY."""
    order_match = re.search(r"\border\s+by\s+(.+?)(?:\blimit\b|\boffset\b|$)", query_lower, re.DOTALL)
    if not order_match:
        return []
    order_clause = order_match.group(1)
    cols = re.findall(r"(\w+)(?:\s+(?:ASC|DESC))?", order_clause, re.IGNORECASE)
    keywords = {"asc", "desc", "nulls", "first", "last"}
    return [c for c in cols if c.lower() not in keywords]


def _find_relevant_gotchas(query_lower: str, db: str, gotchas: dict) -> list[dict[str, Any]]:
    """Find gotchas relevant to a query."""
    relevant = []
    for key, gotcha in gotchas.items():
        # Filter by DB
        if db not in gotcha.get("db", [db]):
            continue
        for symptom in gotcha.get("common_symptoms", []):
            if symptom.lower() in query_lower:
                relevant.append({"id": key, **gotcha})
                break
    return relevant
