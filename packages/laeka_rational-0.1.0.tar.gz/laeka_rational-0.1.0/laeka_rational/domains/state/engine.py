"""State management domain engine — detect issues and suggest patterns."""

import json
import re
from pathlib import Path
from typing import Any


_DATA_DIR = Path(__file__).parent / "data"
_gotchas: dict[str, Any] | None = None


def _load_gotchas() -> dict[str, Any]:
    global _gotchas
    if _gotchas is None:
        with open(_DATA_DIR / "gotchas.json") as f:
            _gotchas = json.load(f)
    return _gotchas


# ── Code pattern detectors ──────────────────────────────────────

_CODE_CHECKS: list[dict[str, Any]] = [
    {
        "id": "stale-closure-setstate",
        "pattern": r"set\w+\s*\(\s*\w+\s*[+\-*/]",
        "severity": "warning",
        "title": "Possible stale closure in setState",
        "detail": "Direct state reference in setState may be stale in callbacks/effects",
        "fix": "Use functional updater: setState(prev => prev + 1)",
        "gotcha_key": "stale-closure",
    },
    {
        "id": "useeffect-empty-deps-with-state",
        "pattern": r"useEffect\s*\(\s*\(\)\s*=>\s*\{[^}]*\b(?:set\w+|dispatch)\b[^}]*\}\s*,\s*\[\s*\]\s*\)",
        "severity": "info",
        "title": "useEffect with empty deps modifies state",
        "detail": "Effect runs only on mount but sets state — ensure this is intentional",
        "fix": "If the effect needs to react to prop/state changes, add them to deps",
        "gotcha_key": "useeffect-missing-deps",
    },
    {
        "id": "inline-object-prop",
        "pattern": r"<\w+[^>]*\w+=\{\s*\{[^}]+\}\s*\}",
        "severity": "warning",
        "title": "Inline object literal as prop",
        "detail": "New object created every render — breaks React.memo and causes unnecessary re-renders",
        "fix": "Extract to useMemo or a constant outside the component",
        "gotcha_key": "object-reference-identity",
    },
    {
        "id": "inline-function-prop",
        "pattern": r"<\w+[^>]*\w+=\{\s*\(\)\s*=>",
        "severity": "info",
        "title": "Inline arrow function as prop",
        "detail": "New function created every render — may cause unnecessary re-renders if child uses React.memo",
        "fix": "Use useCallback if the child component is memoized",
        "gotcha_key": "object-reference-identity",
    },
    {
        "id": "useeffect-no-cleanup-interval",
        "pattern": r"useEffect\s*\(\s*\(\)\s*=>\s*\{[^}]*setInterval[^}]*(?!\breturn\b)[^}]*\}",
        "severity": "error",
        "title": "setInterval in useEffect without cleanup",
        "detail": "Missing cleanup will cause interval to keep running after unmount — memory leak",
        "fix": "Return a cleanup function: return () => clearInterval(id)",
        "gotcha_key": None,
    },
    {
        "id": "useeffect-no-cleanup-listener",
        "pattern": r"useEffect\s*\(\s*\(\)\s*=>\s*\{[^}]*addEventListener[^}]*(?!\bremoveEventListener\b)[^}]*\}",
        "severity": "error",
        "title": "addEventListener in useEffect without removeEventListener",
        "detail": "Missing cleanup will cause listener to accumulate on re-renders — memory leak",
        "fix": "Return cleanup: return () => element.removeEventListener(...)",
        "gotcha_key": None,
    },
    {
        "id": "useState-expensive-init",
        "pattern": r"useState\s*\(\s*\w+\s*\([^)]*\)\s*\)",
        "severity": "warning",
        "title": "Expensive computation in useState initial value",
        "detail": "Function call in useState() runs on EVERY render, not just initial",
        "fix": "Use lazy initializer: useState(() => expensiveComputation())",
        "gotcha_key": "usestate-lazy-init",
    },
    {
        "id": "fetch-no-abort",
        "pattern": r"useEffect\s*\(\s*\(\)\s*=>\s*\{[^}]*fetch\s*\([^}]*\}",
        "severity": "warning",
        "title": "fetch in useEffect without AbortController",
        "detail": "Rapid re-renders can cause race conditions — old responses overwrite new ones",
        "fix": "Use AbortController or a library like React Query/SWR",
        "gotcha_key": "race-condition-fetch",
    },
    {
        "id": "derived-state-useeffect",
        "pattern": r"useEffect\s*\(\s*\(\)\s*=>\s*\{[^}]*set\w+\s*\([^}]*\}\s*,\s*\[\s*\w+",
        "severity": "warning",
        "title": "Derived state via useEffect",
        "detail": "Setting state in useEffect to derive from other state causes an extra re-render",
        "fix": "Compute during render: const derived = compute(state); or use useMemo",
        "gotcha_key": "derived-state-anti-pattern",
    },
]


def state_detect_issues(code_snippet: str) -> dict[str, Any]:
    """Detect common state management issues in a React code snippet."""
    issues = []

    for check in _CODE_CHECKS:
        if re.search(check["pattern"], code_snippet, re.DOTALL):
            issue = {
                "id": check["id"],
                "severity": check["severity"],
                "title": check["title"],
                "detail": check["detail"],
                "fix": check["fix"],
            }
            # Attach gotcha if relevant
            if check["gotcha_key"]:
                gotchas = _load_gotchas()
                gotcha = gotchas.get(check["gotcha_key"])
                if gotcha:
                    issue["related_gotcha"] = {"id": check["gotcha_key"], **gotcha}
            issues.append(issue)

    # Additional heuristic checks
    _check_hooks_rules(code_snippet, issues)

    return {
        "code_length": len(code_snippet),
        "issues_found": len(issues),
        "issues": sorted(issues, key=lambda i: {"error": 0, "warning": 1, "info": 2}[i["severity"]]),
    }


def _check_hooks_rules(code: str, issues: list) -> None:
    """Check for hooks-rules violations."""
    # Hook inside conditional
    if re.search(r"\bif\s*\([^)]*\)\s*\{[^}]*\buse\w+\s*\(", code, re.DOTALL):
        issues.append({
            "id": "hook-in-conditional",
            "severity": "error",
            "title": "Hook called inside conditional",
            "detail": "Hooks must be called at the top level — never inside conditions, loops, or nested functions",
            "fix": "Move the hook to the top level of the component. Use the condition inside the hook's callback instead.",
        })

    # Hook inside loop
    if re.search(r"\bfor\s*\([^)]*\)\s*\{[^}]*\buse\w+\s*\(", code, re.DOTALL):
        issues.append({
            "id": "hook-in-loop",
            "severity": "error",
            "title": "Hook called inside loop",
            "detail": "Hooks must be called in the same order on every render — loops break this guarantee",
            "fix": "Extract the loop body into a separate component that calls the hook.",
        })


# ── state_suggest_pattern ───────────────────────────────────────

_PATTERN_SUGGESTIONS: list[dict[str, Any]] = [
    {
        "keywords": ["form", "input", "controlled", "field", "validation"],
        "pattern": "Controlled form with useReducer",
        "description": "Use useReducer for complex form state with multiple fields and validation rules",
        "example": "const [form, dispatch] = useReducer(formReducer, initialState);",
        "when_to_use": "3+ form fields, complex validation, interdependent fields",
        "alternative": "react-hook-form for large forms (handles performance and validation)",
    },
    {
        "keywords": ["global", "theme", "auth", "user", "session", "shared"],
        "pattern": "Context + useReducer",
        "description": "React Context for low-frequency global state (theme, auth, locale)",
        "example": "const AuthContext = createContext(); // + useReducer for state transitions",
        "when_to_use": "State that changes infrequently and is needed by many components",
        "alternative": "Zustand for simpler API, Jotai for atomic state",
    },
    {
        "keywords": ["server", "fetch", "api", "cache", "loading", "error", "data"],
        "pattern": "React Query / SWR",
        "description": "Dedicated server state manager — handles caching, race conditions, refetching, optimistic updates",
        "example": "const { data, isLoading, error } = useQuery({ queryKey: ['todos'], queryFn: fetchTodos });",
        "when_to_use": "Any server state (API calls, data fetching). Don't roll your own.",
        "alternative": "useSWR for simpler cache needs, RTK Query for Redux ecosystems",
    },
    {
        "keywords": ["list", "array", "add", "remove", "reorder", "filter", "sort"],
        "pattern": "useReducer with immutable updates",
        "description": "useReducer for complex list operations — centralizes add/remove/update/sort logic",
        "example": "dispatch({ type: 'ADD_ITEM', payload: newItem });",
        "when_to_use": "Lists with multiple operations (CRUD, reorder, filter)",
        "alternative": "Immer + useReducer for easier immutable updates",
    },
    {
        "keywords": ["toggle", "boolean", "open", "close", "modal", "sidebar", "visible"],
        "pattern": "Custom useToggle hook",
        "description": "Simple useState wrapper for boolean toggles",
        "example": "const [isOpen, toggle, setOpen] = useToggle(false);",
        "when_to_use": "Any boolean on/off state (modals, menus, accordions)",
        "alternative": "useState(false) with inline toggle is fine for one-offs",
    },
    {
        "keywords": ["debounce", "throttle", "search", "autocomplete", "typeahead"],
        "pattern": "useDeferredValue or custom useDebounce",
        "description": "Debounce state updates for search/autocomplete to avoid excessive re-renders",
        "example": "const deferredQuery = useDeferredValue(query); // React 18+",
        "when_to_use": "User input that triggers expensive operations (search, filtering)",
        "alternative": "lodash debounce in useCallback, or use-debounce package",
    },
    {
        "keywords": ["undo", "redo", "history", "previous", "snapshot"],
        "pattern": "useReducer with history stack",
        "description": "Maintain a history stack for undo/redo functionality",
        "example": "const [state, dispatch] = useReducer(historyReducer, { past: [], present: init, future: [] });",
        "when_to_use": "Editors, drawing apps, any feature needing undo/redo",
        "alternative": "zustand middleware for undo, or dedicated state history libraries",
    },
    {
        "keywords": ["persist", "storage", "localstorage", "sessionstorage", "save"],
        "pattern": "useState + localStorage sync",
        "description": "Persist state to localStorage with hydration handling",
        "example": "const [value, setValue] = useLocalStorage('key', defaultValue);",
        "when_to_use": "User preferences, draft content, form progress",
        "alternative": "zustand persist middleware, or use-local-storage-state package",
    },
    {
        "keywords": ["websocket", "realtime", "streaming", "live", "subscription", "event"],
        "pattern": "useRef + useEffect for subscriptions",
        "description": "Use useRef for the connection, useEffect for lifecycle, useState for displayed data",
        "example": "const wsRef = useRef(null); useEffect(() => { wsRef.current = new WebSocket(url); ... }, [url]);",
        "when_to_use": "WebSockets, SSE, any long-lived connection",
        "alternative": "React Query subscriptions, Socket.IO React hooks",
    },
    {
        "keywords": ["complex", "nested", "deep", "multiple", "reducer"],
        "pattern": "Zustand (external store)",
        "description": "Lightweight external store — no boilerplate, no context provider, selector-based re-renders",
        "example": "const useStore = create((set) => ({ count: 0, inc: () => set(s => ({ count: s.count + 1 })) }));",
        "when_to_use": "Medium-to-complex client state shared across components",
        "alternative": "Jotai for atomic model, Redux Toolkit for large teams/codebases",
    },
]


def state_suggest_pattern(problem_description: str) -> dict[str, Any]:
    """Suggest the appropriate state management pattern for a problem."""
    desc_lower = problem_description.lower()

    scored: list[tuple[int, dict]] = []
    for suggestion in _PATTERN_SUGGESTIONS:
        score = sum(1 for kw in suggestion["keywords"] if kw in desc_lower)
        if score > 0:
            scored.append((score, suggestion))

    scored.sort(key=lambda x: x[0], reverse=True)
    suggestions = [s for _, s in scored]

    # Find relevant gotchas
    gotchas = _load_gotchas()
    relevant = _find_relevant_gotchas(desc_lower, gotchas)

    return {
        "problem": problem_description,
        "suggestions_found": len(suggestions),
        "suggestions": suggestions[:5],
        "relevant_gotchas": relevant[:3],
    }


def _find_relevant_gotchas(text: str, gotchas: dict) -> list[dict[str, Any]]:
    """Find gotchas matching a description."""
    relevant = []
    for key, gotcha in gotchas.items():
        for symptom in gotcha.get("common_symptoms", []):
            if symptom.lower() in text or text in symptom.lower():
                relevant.append({"id": key, **gotcha})
                break
    return relevant
