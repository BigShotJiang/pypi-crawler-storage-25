"""State management domain MCP tools — registered on the FastMCP server."""

from typing import Any

from .engine import state_detect_issues, state_suggest_pattern


def register_state_tools(mcp) -> None:
    """Register all State management tools on the FastMCP server instance."""

    @mcp.tool()
    def state_detect_issues_tool(code_snippet: str) -> dict[str, Any]:
        """Detect common React state management issues in a code snippet.

        Scans for: stale closures in setState, missing useEffect deps,
        inline object/function props breaking memo, missing cleanup in effects
        (intervals, event listeners), expensive useState init, fetch race conditions,
        derived state anti-patterns, and hooks-rules violations (conditional/loop hooks).

        Args:
            code_snippet: React component code to analyze
        """
        return state_detect_issues(code_snippet)

    @mcp.tool()
    def state_suggest_pattern_tool(problem_description: str) -> dict[str, Any]:
        """Recommend the right React state management pattern for a problem.

        Covers: forms (useReducer/react-hook-form), global state (Context/Zustand),
        server state (React Query/SWR), lists (useReducer), toggles, debounce,
        undo/redo, persistence (localStorage), WebSockets, and complex state (Zustand/Jotai).

        Args:
            problem_description: Describe the state management challenge (e.g.
                "form with validation", "global auth state", "fetch with caching",
                "undo/redo in editor", "real-time chat messages")
        """
        return state_suggest_pattern(problem_description)
