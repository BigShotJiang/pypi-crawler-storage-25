"""Laeka Rational — Deterministic analytical brain MCP server."""
