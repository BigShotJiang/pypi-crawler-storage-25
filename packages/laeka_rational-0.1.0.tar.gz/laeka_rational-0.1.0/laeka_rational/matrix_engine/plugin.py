"""Matrix plugin interface — base class for all domain plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .core import MatrixData


class MatrixPlugin(ABC):
    """Base class for matrix engine plugins.

    Each plugin converts domain-specific input into MatrixData,
    optionally computes on it, then lets the core renderer do its job.
    """

    name: str
    description: str

    @abstractmethod
    def parse(self, input_data: Any, **kwargs) -> MatrixData:
        """Domain-specific input -> structured matrix data."""
        ...

    def compute(self, data: MatrixData) -> MatrixData:
        """Optional: run deterministic computation on the data.

        Default is pass-through. Override to transform rows/headers.
        """
        return data
