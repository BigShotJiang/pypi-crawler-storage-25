"""Matrix engine hub — central dispatch for plugin-based rendering.

The hub owns the registry, auto-registers built-in plugins,
and provides the public API: list, render, render_side_by_side.
"""

from __future__ import annotations

from typing import Any

from .core import MatrixData, render_matrix, render_side_by_side
from .registry import Registry
from .plugins.code_execution import CodeExecutionPlugin
from .plugins.css_layout import CSSLayoutPlugin


class Hub:
    """Central hub for matrix engine plugins."""

    def __init__(self) -> None:
        self._registry = Registry()
        self._register_builtins()

    def _register_builtins(self) -> None:
        """Auto-register all built-in plugins."""
        self._registry.register(CodeExecutionPlugin())
        self._registry.register(CSSLayoutPlugin())

    def register_plugin(self, plugin) -> None:
        """Register an external plugin."""
        self._registry.register(plugin)

    def list_plugins(self) -> list[dict[str, str]]:
        """Return all available plugins with name and description."""
        return self._registry.list_plugins()

    def render(self, plugin_name: str, input_data: Any, **kwargs) -> str:
        """Full pipeline: parse → compute → render.

        For plugins that return pre-rendered content (headers == ["__pre_rendered__"]),
        the core renderer is bypassed and the raw string is returned directly.
        """
        plugin = self._registry.get(plugin_name)
        data = plugin.parse(input_data, **kwargs)
        data = plugin.compute(data)

        # Pre-rendered content bypass
        if data.headers == ["__pre_rendered__"] and len(data.rows) == 1:
            result = data.rows[0][0]
            if data.footer:
                result += "\n" + data.footer
            return result

        return render_matrix(data)

    def render_side_by_side(self, renders: list[str], gap: int = 4) -> str:
        """Place multiple rendered matrices side by side."""
        return render_side_by_side(renders, gap=gap)


# Module-level singleton for convenience
_hub: Hub | None = None


def get_hub() -> Hub:
    """Get or create the global hub singleton."""
    global _hub
    if _hub is None:
        _hub = Hub()
    return _hub
