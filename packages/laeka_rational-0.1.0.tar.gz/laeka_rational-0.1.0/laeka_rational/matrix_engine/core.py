"""Core ASCII matrix renderer — domain-agnostic.

Takes structured MatrixData and produces formatted ASCII tables.
Knows nothing about code execution, CSS, or any domain.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class MatrixData:
    """Structured matrix data ready for rendering.

    headers: column names
    rows: list of rows, each row is a list of cell strings
    footer: optional text appended after the table
    """
    headers: list[str]
    rows: list[list[str]]
    footer: str = ""


def render_matrix(data: MatrixData) -> str:
    """Render MatrixData as an ASCII table with dynamic column widths.

    - Columns auto-size to content
    - Header row followed by ─── separator
    - Cells left-aligned, separated by 2 spaces
    - Optional footer appended after the table
    """
    if not data.rows:
        return "(no data to render)"

    headers = data.headers
    rows = data.rows

    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(cell))

    # Build format string
    def fmt_row(cells: list[str]) -> str:
        parts = []
        for i, cell in enumerate(cells):
            w = widths[i] if i < len(widths) else len(cell)
            parts.append(cell.ljust(w))
        return "  ".join(parts)

    lines = [fmt_row(headers)]
    lines.append("─" * (sum(widths) + 2 * (len(widths) - 1)))
    for row in rows:
        lines.append(fmt_row(row))

    result = "\n".join(lines)
    if data.footer:
        result += "\n" + data.footer
    return result


def render_side_by_side(renders: list[str], gap: int = 4) -> str:
    """Place multiple rendered matrices side by side.

    Args:
        renders: list of already-rendered ASCII strings
        gap: number of spaces between matrices
    """
    if not renders:
        return ""
    if len(renders) == 1:
        return renders[0]

    # Split each render into lines
    blocks = [r.split("\n") for r in renders]

    # Normalize heights
    max_height = max(len(b) for b in blocks)
    for block in blocks:
        while len(block) < max_height:
            block.append("")

    # Find widths per block
    block_widths = [max((len(line) for line in block), default=0) for block in blocks]

    separator = " " * gap
    lines = []
    for row_idx in range(max_height):
        parts = []
        for block_idx, block in enumerate(blocks):
            line = block[row_idx]
            parts.append(line.ljust(block_widths[block_idx]))
        lines.append(separator.join(parts).rstrip())

    return "\n".join(lines)
