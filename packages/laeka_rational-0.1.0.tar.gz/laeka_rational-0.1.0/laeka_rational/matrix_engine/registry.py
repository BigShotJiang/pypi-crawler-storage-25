"""Plugin registry — singleton that holds all registered plugins."""

from __future__ import annotations

from .plugin import MatrixPlugin


class Registry:
    """Thread-safe plugin registry (single process, no locking needed)."""

    def __init__(self) -> None:
        self._plugins: dict[str, MatrixPlugin] = {}

    def register(self, plugin: MatrixPlugin) -> None:
        """Register a plugin. Raises if name already taken."""
        if plugin.name in self._plugins:
            raise ValueError(f"Plugin '{plugin.name}' already registered")
        self._plugins[plugin.name] = plugin

    def get(self, name: str) -> MatrixPlugin:
        """Get a plugin by name. Raises KeyError if not found."""
        if name not in self._plugins:
            raise KeyError(f"Plugin '{name}' not found. Available: {list(self._plugins.keys())}")
        return self._plugins[name]

    def list_plugins(self) -> list[dict[str, str]]:
        """Return list of {name, description} for all registered plugins."""
        return [
            {"name": p.name, "description": p.description}
            for p in self._plugins.values()
        ]

    def __contains__(self, name: str) -> bool:
        return name in self._plugins


# Module-level singleton
_registry = Registry()


def get_registry() -> Registry:
    """Get the global plugin registry."""
    return _registry
