"""Code execution plugin — wraps trace_execution, trace_loop, trace_function.

This plugin re-uses the existing engine logic but routes through the plugin
interface. The existing engine functions remain the source of truth for
execution + tracing; this plugin just adapts their output into MatrixData
for the core renderer.

Design note: the existing engine functions already render to ASCII internally.
Rather than breaking that tight coupling right now (which would change behavior
and risk the 18 tests), this plugin delegates to them directly and returns
the pre-rendered output. The core renderer is bypassed for backward compat.
Future refactor: have the engine return MatrixData natively.
"""

from __future__ import annotations

from typing import Any

from ..core import MatrixData
from ..plugin import MatrixPlugin


class CodeExecutionPlugin(MatrixPlugin):
    """Plugin for tracing Python code execution as ASCII matrices."""

    name = "code_execution"
    description = (
        "Execute Python code and render variable state as ASCII matrices. "
        "Supports line-by-line tracing, loop tracing, and function call tracing."
    )

    # Lazy import to avoid circular deps at module level
    @staticmethod
    def _engine():
        from laeka_rational.domains.matrix.engine import (
            trace_execution,
            trace_loop,
            trace_function,
        )
        return trace_execution, trace_loop, trace_function

    def parse(self, input_data: Any, **kwargs) -> MatrixData:
        """Parse code input into MatrixData.

        kwargs:
            mode: "execution" | "loop" | "function" (default "execution")
            language: str (default "python")
            max_iterations: int (for loop mode, default 20)
            function_name: str (for function mode)
            args: str (for function mode)
        """
        mode = kwargs.get("mode", "execution")
        code = input_data if isinstance(input_data, str) else str(input_data)

        trace_execution, trace_loop, trace_function = self._engine()

        if mode == "loop":
            max_iterations = kwargs.get("max_iterations", 20)
            result = trace_loop(code, max_iterations=max_iterations)
        elif mode == "function":
            function_name = kwargs.get("function_name", "")
            args = kwargs.get("args", "")
            if not function_name:
                return MatrixData(
                    headers=["error"],
                    rows=[["function_name is required for function mode"]],
                )
            result = trace_function(code, function_name, args)
        else:
            language = kwargs.get("language", "python")
            result = trace_execution(code, language)

        # The engine already renders ASCII. We wrap it as a single-cell
        # MatrixData with pre-rendered content. The hub will detect this
        # and return the pre-rendered string directly.
        return MatrixData(
            headers=["__pre_rendered__"],
            rows=[[result]],
        )

    def compute(self, data: MatrixData) -> MatrixData:
        """No-op — computation already done in parse via the engine."""
        return data
