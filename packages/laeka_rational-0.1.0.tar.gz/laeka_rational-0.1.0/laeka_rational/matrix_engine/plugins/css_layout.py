"""CSS Layout plugin — render box model as ASCII spatial grid.

Takes computed styles (boxes with x, y, w, h, margin, padding) and renders
a 2D ASCII spatial grid showing nested boxes with margins and paddings.

No Playwright needed — works with manually-provided box data.
"""

from __future__ import annotations

from typing import Any

from ..core import MatrixData
from ..plugin import MatrixPlugin


# ── ASCII drawing characters ─────────────────────────────────

_CORNER_TL = "┌"
_CORNER_TR = "┐"
_CORNER_BL = "└"
_CORNER_BR = "┘"
_HORIZ = "─"
_VERT = "│"
_MARGIN_FILL = "·"
_PADDING_FILL = "░"
_EMPTY = " "


class CSSLayoutPlugin(MatrixPlugin):
    """Plugin for rendering CSS box model as ASCII spatial grids."""

    name = "css_layout"
    description = (
        "Render CSS box model (boxes with position, size, margin, padding) "
        "as ASCII spatial grids showing nesting and spacing."
    )

    def parse(self, input_data: Any, **kwargs) -> MatrixData:
        """Parse box data into MatrixData.

        input_data: list of box dicts, each with:
            - tag: str (label)
            - x, y: int (position in px)
            - w, h: int (content width/height in px)
            - margin: int (optional, default 0)
            - padding: int (optional, default 0)

        kwargs:
            scale: int (pixels per char, default 4)
        """
        if not isinstance(input_data, list):
            return MatrixData(
                headers=["error"],
                rows=[["input_data must be a list of box dicts"]],
            )

        scale = kwargs.get("scale", 4)
        boxes = self._normalize_boxes(input_data)
        grid = self._render_grid(boxes, scale)

        # Return as pre-rendered content
        return MatrixData(
            headers=["__pre_rendered__"],
            rows=[[grid]],
        )

    def compute(self, data: MatrixData) -> MatrixData:
        """No-op — rendering done in parse."""
        return data

    @staticmethod
    def _normalize_boxes(raw_boxes: list[dict]) -> list[dict]:
        """Normalize box dicts with defaults."""
        boxes = []
        for b in raw_boxes:
            boxes.append({
                "tag": b.get("tag", "box"),
                "x": int(b.get("x", 0)),
                "y": int(b.get("y", 0)),
                "w": int(b.get("w", 0)),
                "h": int(b.get("h", 0)),
                "margin": int(b.get("margin", 0)),
                "padding": int(b.get("padding", 0)),
            })
        return boxes

    @staticmethod
    def _render_grid(boxes: list[dict], scale: int) -> str:
        """Render boxes onto a 2D character grid."""
        if not boxes:
            return "(no boxes to render)"

        # Calculate grid dimensions from outermost extents
        max_x = 0
        max_y = 0
        for b in boxes:
            outer_right = b["x"] + b["w"] + 2 * b["margin"] + 2 * b["padding"]
            outer_bottom = b["y"] + b["h"] + 2 * b["margin"] + 2 * b["padding"]
            max_x = max(max_x, outer_right)
            max_y = max(max_y, outer_bottom)

        # Scale down to char grid
        cols = max_x // scale + 1
        rows = max_y // scale + 1

        # Cap grid size for sanity
        cols = min(cols, 120)
        rows = min(rows, 60)

        # Initialize grid
        grid = [[_EMPTY] * cols for _ in range(rows)]

        # Draw boxes (back to front — first box is outermost)
        # Collect label positions for a second pass (avoid overwrite by later boxes)
        labels: list[tuple[int, int, str]] = []

        for b in boxes:
            m = b["margin"]
            p = b["padding"]

            # Outer box (margin edge)
            ox = b["x"] // scale
            oy = b["y"] // scale
            ow = (b["w"] + 2 * m + 2 * p) // scale
            oh = (b["h"] + 2 * m + 2 * p) // scale

            # Padding box
            px = (b["x"] + m) // scale
            py = (b["y"] + m) // scale
            pw = (b["w"] + 2 * p) // scale
            ph = (b["h"] + 2 * p) // scale

            # Content box
            cx = (b["x"] + m + p) // scale
            cy = (b["y"] + m + p) // scale
            cw = b["w"] // scale
            ch = b["h"] // scale

            # Fill margin area with dots
            if m > 0:
                _fill_rect(grid, oy, ox, oh, ow, _MARGIN_FILL, rows, cols)

            # Draw padding box border
            _draw_box(grid, py, px, ph, pw, rows, cols)

            # Fill padding area
            if p > 0:
                _fill_rect(grid, py + 1, px + 1, ph - 2, pw - 2, _PADDING_FILL, rows, cols)

            # Draw content box border
            _draw_box(grid, cy, cx, ch, cw, rows, cols)

            # Clear content interior
            _fill_rect(grid, cy + 1, cx + 1, ch - 2, cw - 2, _EMPTY, rows, cols)

            # Record label for second pass
            # Place label on the outermost border of the box (padding border
            # if padding > 0, else content border), right after the corner char
            if p > 0:
                labels.append((py, px + 1, b["tag"]))
            else:
                labels.append((cy, cx + 1, b["tag"]))

        # Second pass: place all labels on top borders (last drawn = on top)
        for label_y, label_x, tag in labels:
            if 0 <= label_y < rows:
                for i, ch_char in enumerate(tag):
                    if label_x + i < cols:
                        grid[label_y][label_x + i] = ch_char

        # Convert grid to string
        lines = ["".join(row).rstrip() for row in grid]
        # Remove trailing empty lines
        while lines and not lines[-1]:
            lines.pop()
        return "\n".join(lines)


def _fill_rect(
    grid: list[list[str]],
    y: int, x: int, h: int, w: int,
    char: str,
    max_rows: int, max_cols: int,
) -> None:
    """Fill a rectangle on the grid with a character."""
    for row in range(y, min(y + h, max_rows)):
        for col in range(x, min(x + w, max_cols)):
            if 0 <= row < max_rows and 0 <= col < max_cols:
                grid[row][col] = char


def _draw_box(
    grid: list[list[str]],
    y: int, x: int, h: int, w: int,
    max_rows: int, max_cols: int,
) -> None:
    """Draw a box outline on the grid."""
    if h < 2 or w < 2:
        return

    # Corners
    if 0 <= y < max_rows and 0 <= x < max_cols:
        grid[y][x] = _CORNER_TL
    if 0 <= y < max_rows and 0 <= x + w - 1 < max_cols:
        grid[y][x + w - 1] = _CORNER_TR
    if 0 <= y + h - 1 < max_rows and 0 <= x < max_cols:
        grid[y + h - 1][x] = _CORNER_BL
    if 0 <= y + h - 1 < max_rows and 0 <= x + w - 1 < max_cols:
        grid[y + h - 1][x + w - 1] = _CORNER_BR

    # Horizontal edges
    for col in range(x + 1, min(x + w - 1, max_cols)):
        if 0 <= col < max_cols:
            if 0 <= y < max_rows:
                grid[y][col] = _HORIZ
            if 0 <= y + h - 1 < max_rows:
                grid[y + h - 1][col] = _HORIZ

    # Vertical edges
    for row in range(y + 1, min(y + h - 1, max_rows)):
        if 0 <= row < max_rows:
            if 0 <= x < max_cols:
                grid[row][x] = _VERT
            if 0 <= x + w - 1 < max_cols:
                grid[row][x + w - 1] = _VERT
