"""Matrix Engine — plugin-based ASCII matrix renderer."""

from .core import MatrixData, render_matrix
from .plugin import MatrixPlugin
from .hub import Hub

__all__ = ["MatrixData", "render_matrix", "MatrixPlugin", "Hub"]
