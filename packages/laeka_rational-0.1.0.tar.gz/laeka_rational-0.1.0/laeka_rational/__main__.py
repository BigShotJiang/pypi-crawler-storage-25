"""Allow running as: python -m laeka_rational"""

from .server import main

main()
