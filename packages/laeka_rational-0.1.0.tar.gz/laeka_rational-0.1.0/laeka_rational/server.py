"""Laeka Rational — MCP server entry point.

Deterministic analytical brain for Claude Code.
8 domains: CSS, Regex, SQL, Build, Refactoring, State, Auth, Matrix.
"""

from fastmcp import FastMCP

from .domains.css.tools import register_css_tools
from .domains.regex.tools import register_regex_tools
from .domains.sql.tools import register_sql_tools
from .domains.build.tools import register_build_tools
from .domains.refactor.tools import register_refactor_tools
from .domains.state.tools import register_state_tools
from .domains.auth.tools import register_auth_tools
from .domains.matrix.tools import register_matrix_tools


mcp = FastMCP(
    "laeka-rational",
    instructions=(
        "Laeka Rational is a deterministic analytical brain with 8 domains. "
        "The tools compute — they don't guess. "
        "CSS: specificity calculator, layout gotcha diagnosis. "
        "Regex: test patterns, explain syntax, build from description. "
        "SQL: query analysis, migration risk checker, index suggestions. "
        "Build: config analysis (tsconfig/next/vite/tailwind), error diagnosis. "
        "Refactoring: symbol impact analysis, rename planning across files. "
        "State: React hooks issue detection, pattern recommendation. "
        "Auth: flow completeness validation, auth symptom diagnosis. "
        "Matrix: execute code and render variable state as ASCII matrices — "
        "eliminates LLM hallucinations by showing real execution state."
    ),
)

# Register domain tools
register_css_tools(mcp)
register_regex_tools(mcp)
register_sql_tools(mcp)
register_build_tools(mcp)
register_refactor_tools(mcp)
register_state_tools(mcp)
register_auth_tools(mcp)
register_matrix_tools(mcp)


def main():
    """Run the MCP server (stdio transport)."""
    mcp.run()


if __name__ == "__main__":
    main()
