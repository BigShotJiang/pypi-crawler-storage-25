"""Local-mode audit chain (v2.1.5, Day-1 #8).

Sidecar mode signs every audit record with Ed25519 + Merkle (M5/M9/M15).
Local mode (Solo Free, in-process plugin) ships without that
cryptographic stack to keep the install footprint minimal — but the
audit log was previously plain-text JSONL with no integrity proof.

This module adds a deterministic SHA3-256 hash chain. Each appended
record carries:

* ``prev_hash``  — the ``this_hash`` of the previous line (or
                   :data:`GENESIS_HASH` for the first line).
* ``this_hash``  — SHA3-256 over the canonical-JSON of the record
                   *minus* ``this_hash`` itself.

Tampering with any historical line breaks every subsequent
``this_hash``. :func:`verify_chain` walks the file and reports the
first break it finds, returning ``(ok, broken_index, total)``.

Why not Ed25519? — local mode is single-developer, no key management.
The chain alone proves the log hasn't been mutated post-write; the
threat model is "did a process modify lines after the hook wrote
them" not "did an authenticated principal sign these". Sidecar mode
remains the path for cryptographic non-repudiation.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
from pathlib import Path
from typing import Any

# fcntl is POSIX-only. Personal MVP supports macOS + Linux today
# (see docs/launch/FAQ.md "Windows support"). On non-POSIX hosts the
# import fails silently and append() falls back to the unlocked path
# — single-process correctness is preserved by the threading.Lock in
# JsonlStore; the file lock here exists only to guard against
# *cross-process* races (multiple Claude Code sessions writing to the
# same ~/.aegis/audit.jsonl simultaneously).
try:
    import fcntl as _fcntl
    _FCNTL_AVAILABLE = True
except ImportError:  # pragma: no cover — Windows path
    _fcntl = None  # type: ignore[assignment]
    _FCNTL_AVAILABLE = False

GENESIS_HASH = "0" * 64


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode(
        "utf-8"
    )


_HASH_EXCLUDED_FIELDS: frozenset[str] = frozenset({
    "this_hash",
    # Signature fields are added AFTER the hash is computed (the
    # signature is OVER the hash). Including them in the hash payload
    # would create a circular dependency. Verification re-hashes with
    # the same exclusion list.
    "signature",
    "pubkey_fingerprint",
})


def _hash_record(prev_hash: str, record: dict[str, Any]) -> str:
    payload = {
        "prev_hash": prev_hash,
        **{k: v for k, v in record.items() if k not in _HASH_EXCLUDED_FIELDS},
    }
    return hashlib.sha3_256(_canonical_json(payload)).hexdigest()


def _last_hash_in_file(path: Path) -> str | None:
    """Read one file and return its last ``this_hash``, or None.

    For plain (uncompressed) files: tail-reads the last 4 KB so the
    cost is constant regardless of file size.

    For gzip-compressed rotation files: there's no random access, so
    we decompress the whole file and walk it. Compressed rotations are
    typically <10 MB after gzip (50 MB plain → ~6 MB gz), so this is
    still cheap. The slow path only fires when the *active* file is
    empty or missing (just-rotated state) and we need the most-recent
    rotation's last hash; in steady state ``_last_hash`` returns from
    the active file's tail and never touches a .gz.

    Returns ``None`` (not GENESIS_HASH) when the file is missing,
    empty, or has no parseable trailing record — :func:`_last_hash`
    uses None to fall through to the next-most-recent rotation.
    """
    if not path.exists() or path.stat().st_size == 0:
        return None

    from aegis.audit.rotation import is_compressed, open_rotation_text

    if is_compressed(path):
        # Walk the whole decompressed stream; remember the last
        # parseable this_hash we saw.
        last: str | None = None
        for raw in open_rotation_text(path):
            line = raw.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            h = rec.get("this_hash")
            if isinstance(h, str) and h:
                last = h
        return last

    # Plain text file — fast tail read.
    try:
        with path.open("rb") as fh:
            try:
                fh.seek(-4096, 2)
            except OSError:
                fh.seek(0)
            tail = fh.read().decode("utf-8", errors="replace")
        for raw in reversed(tail.splitlines()):
            line = raw.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            h = rec.get("this_hash")
            if isinstance(h, str) and h:
                return h
    except OSError:
        pass
    return None


def _last_hash(path: Path) -> str:
    """Return the ``this_hash`` of the last record, with rotation fallback.

    The chain crosses file boundaries: if the active file is empty (we
    just rotated, or this is the first call ever), we fall back to
    the most-recent rotation slot (``.1.gz`` or legacy ``.1``) so the
    new file's first record carries a ``prev_hash`` matching the
    rotated file's last record. Without this, every rotation would
    inject a GENESIS_HASH break and ``aegis verify-audit`` would fail
    at the file boundary.
    """
    h = _last_hash_in_file(path)
    if h is not None:
        return h

    # Active file is empty / missing → look at the most-recent
    # rotation slot (.1.gz preferred, .1 legacy fallback).
    from aegis.audit.rotation import slot_path

    fallback = slot_path(path, 1)
    if fallback is None:
        return GENESIS_HASH
    h = _last_hash_in_file(fallback)
    return h if h is not None else GENESIS_HASH


def append(path: Path, record: dict[str, Any]) -> dict[str, Any]:
    """Append ``record`` with a chained ``prev_hash`` + ``this_hash``.

    Opportunistic size-based rotation: if the file exceeds the
    configured threshold we rotate it (``audit.jsonl`` →
    ``audit.jsonl.1``) before appending. The new file's first record
    inherits ``prev_hash`` from the just-rotated file, so the chain
    stays unbroken across the file boundary.

    Optional Ed25519 signing: if a signing key is loadable
    (``~/.aegis/keys/audit.ed25519`` or ``AEGIS_AUDIT_SIGNING_KEY``),
    every appended record gets a ``signature`` field (hex over the
    UTF-8 bytes of ``this_hash``) plus a ``pubkey_fingerprint`` (16-char
    SHA3 of the public key). Records without a signing key configured
    proceed unchanged — backwards compatible.

    Concurrency: the read-prev-hash → compute → write sequence is
    protected by an exclusive ``fcntl.flock`` on the audit file across
    POSIX hosts. This serialises *cross-process* writers (multiple
    Claude Code sessions on the same ``~/.aegis/audit.jsonl``) so two
    concurrent appends cannot read the same ``prev_hash`` and fork the
    chain. Within a single process, JsonlStore's threading.Lock
    handles intra-process concurrency. On non-POSIX hosts (Windows,
    not yet supported) the lock degrades to no-op and single-process
    correctness only.

    Returns the augmented record (caller can inspect it). Audit
    failures raise ``OSError`` — callers in the hot path should wrap
    this in try/except so a write error never blocks the tool call.
    Rotation failures are swallowed (best-effort) — better to keep
    appending to a too-large file than to drop the audit record.
    """
    # Rotate if file is over threshold. maybe_rotate() is a no-op
    # when AEGIS_AUDIT_MAX_BYTES=0 or the file is below threshold.
    try:
        from aegis.audit.rotation import maybe_rotate
        maybe_rotate(path)
    except Exception:  # noqa: BLE001 — rotation is best-effort
        pass

    path.parent.mkdir(parents=True, exist_ok=True)

    # Open + flock + read-prev → compute → write → fsync, all under
    # one exclusive lock. Without this, two writers can both observe
    # the same prev_hash, both compute their this_hash from it, and
    # both append — forking the chain at that point.
    with path.open("a+", encoding="utf-8") as fh:
        if _FCNTL_AVAILABLE:
            _fcntl.flock(fh.fileno(), _fcntl.LOCK_EX)
        try:
            prev_hash = _last_hash(path)
            chained = {**record, "prev_hash": prev_hash}
            chained["this_hash"] = _hash_record(prev_hash, chained)

            # Optional Ed25519 signing — silent when no key is configured.
            try:
                from aegis.audit.signing import (
                    load_private_key_or_none,
                    sign_hash,
                )
                keypair = load_private_key_or_none()
                if keypair is not None:
                    chained["signature"] = sign_hash(
                        chained["this_hash"], keypair,
                    )
                    chained["pubkey_fingerprint"] = keypair.fingerprint
            except Exception:  # noqa: BLE001 — signing is best-effort
                # Never fail an audit append because of signing trouble.
                pass

            fh.write(json.dumps(chained, default=str) + "\n")
            fh.flush()
            # fsync can fail on some filesystems (e.g. tmpfs in tests);
            # the chain stays consistent even without it since the
            # write itself is held under flock.
            with contextlib.suppress(OSError):
                os.fsync(fh.fileno())
        finally:
            if _FCNTL_AVAILABLE:
                _fcntl.flock(fh.fileno(), _fcntl.LOCK_UN)
    return chained


def verify_chain(path: Path) -> tuple[bool, int, int]:
    """Walk the full audit chain end-to-end. ``(ok, broken_at_index, total)``.

    Walks rotated files first (oldest → newest) then the active file,
    so the chain is verified across rotation boundaries. The hash
    handoff is implicit: the last record of ``audit.jsonl.K`` provides
    ``prev_hash`` for the first record of ``audit.jsonl.{K-1}``, since
    rotation preserves the hash chain via :func:`_last_hash`.

    Retention-eviction handling
    ---------------------------
    When ``AEGIS_AUDIT_MAX_ROTATIONS`` policy has dropped the oldest
    file(s), the oldest *retained* record's ``prev_hash`` won't equal
    ``GENESIS_HASH`` — it points at a record that's been evicted. We
    treat the first retained record's ``prev_hash`` as a **trust
    anchor** and verify chain integrity forward from there. The
    function still reports total records walked, but the verification
    proves "the retained portion has not been mutated" rather than
    "the chain extends back to genesis".

    * ``ok`` is True iff every line's ``this_hash`` matches the recompute
      AND every ``prev_hash`` chains to the prior line's ``this_hash``
      across all retained rotation files.
    * ``broken_at_index`` is the global 0-indexed position of the first
      broken line (counting across rotations), or -1 if ok.
    * ``total`` counts non-blank, non-malformed lines walked across
      the retained rotation set.
    """
    from aegis.audit.rotation import list_rotation_chain

    files = list_rotation_chain(path)
    if not files:
        return True, -1, 0

    # Anchor at the first retained record's prev_hash. If retention
    # has dropped earlier files, this is just our trust point; if no
    # eviction has happened it'll be GENESIS_HASH automatically.
    anchor = _first_record_prev_hash(files[0]) or GENESIS_HASH

    expected_prev = anchor
    total = 0
    for f in files:
        ok, broken, n_in_file = _verify_file_chain(f, expected_prev, total)
        total += n_in_file
        if not ok:
            return False, broken, total
        # The last record's this_hash becomes the next file's expected prev.
        last = _last_hash_in_file(f)
        if last is not None:
            expected_prev = last
    return True, -1, total


def _first_record_prev_hash(path: Path) -> str | None:
    """Read the very first record's ``prev_hash`` (cheap — one line).

    Transparently handles gzip-compressed rotation files via
    :func:`open_rotation_text`.
    """
    if not path.exists() or path.stat().st_size == 0:
        return None
    from aegis.audit.rotation import open_rotation_text

    for raw in open_rotation_text(path):
        line = raw.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            return None
        p = rec.get("prev_hash")
        return p if isinstance(p, str) else None
    return None


def _verify_file_chain(
    path: Path, expected_prev: str, base_index: int,
) -> tuple[bool, int, int]:
    """Walk one file's chain. Returns (ok, broken_global_index, n_in_file).

    Transparently handles gzip-compressed rotation files (post-Gap-B
    compression PR) and legacy plain-text rotations via
    :func:`open_rotation_text`.

    Signature handling: if a public key is loadable, every record
    that carries a ``signature`` field is verified against it. A
    BAD signature (present but doesn't verify) breaks the chain at
    that record. A MISSING signature (no field at all) is accepted —
    backwards-compat for records appended before signing was enabled
    or on a host without a key.
    """
    if not path.exists():
        return True, -1, 0

    # Lazy public-key load — only fetch once per file.
    public_key = None
    try:
        from aegis.audit.signing import load_public_key_or_none
        loaded = load_public_key_or_none()
        if loaded is not None:
            public_key, _fp = loaded
    except Exception:  # noqa: BLE001 — verifier is best-effort
        public_key = None

    from aegis.audit.rotation import open_rotation_text

    n_in_file = 0
    for raw in open_rotation_text(path):
        line = raw.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            return False, base_index + n_in_file, n_in_file
        if rec.get("prev_hash") != expected_prev:
            return False, base_index + n_in_file, n_in_file
        recomputed = _hash_record(rec["prev_hash"], rec)
        if recomputed != rec.get("this_hash"):
            return False, base_index + n_in_file, n_in_file

        # Signature check — only when both a key is configured AND
        # the record carries a signature. Missing signature is
        # tolerated; bad signature breaks the chain.
        sig = rec.get("signature")
        if public_key is not None and isinstance(sig, str) and sig:
            from aegis.audit.signing import verify_hash_signature

            if not verify_hash_signature(
                rec["this_hash"], sig, public_key,
            ):
                return False, base_index + n_in_file, n_in_file

        expected_prev = rec["this_hash"]
        n_in_file += 1
    return True, -1, n_in_file
