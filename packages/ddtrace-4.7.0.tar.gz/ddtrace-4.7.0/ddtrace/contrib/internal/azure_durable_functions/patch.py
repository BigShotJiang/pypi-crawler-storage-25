import azure.durable_functions as durable_functions
from wrapt import wrap_function_wrapper as _w

from ddtrace.contrib.internal.azure_functions.shared import patched_get_functions
from ddtrace.contrib.internal.trace_utils import unwrap as _u


def get_version() -> str:
    from importlib.metadata import version

    return version("azure-functions-durable")


def _supported_versions() -> dict[str, str]:
    return {"azure.durable_functions": ">=1.2.1"}


def patch():
    """
    Patch `azure.durable_functions` module for tracing.
    """
    if getattr(durable_functions, "_datadog_patch", False):
        return
    durable_functions._datadog_patch = True

    try:
        from azure.durable_functions.decorators import durable_app  # noqa: F401
    except Exception:
        return

    _w("azure.durable_functions", "DFApp.get_functions", patched_get_functions)


def unpatch():
    if not getattr(durable_functions, "_datadog_patch", False):
        return
    durable_functions._datadog_patch = False

    try:
        from azure.durable_functions.decorators import durable_app
    except Exception:
        durable_app = None
    if durable_app is not None:
        _u(durable_app.DFApp, "get_functions")
