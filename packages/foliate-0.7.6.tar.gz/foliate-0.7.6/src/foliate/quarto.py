"""Quarto preprocessing for foliate.

Converts .qmd files to .md using quarto-prerender before the main build.
"""

from pathlib import Path

from .config import Config
from .logging import debug


def is_quarto_preprocessing_available() -> bool:
    """Return whether Quarto preprocessing can run in this environment."""
    try:
        from quarto_prerender import is_quarto_available
    except ImportError:
        return False

    return bool(is_quarto_available())


def get_buildable_content_suffixes(config: Config) -> set[str]:
    """Return the content suffixes buildable in the current environment."""
    suffixes = {".md"}
    if config.advanced.quarto_enabled and is_quarto_preprocessing_available():
        suffixes.add(".qmd")
    return suffixes


def preprocess_quarto(
    config: Config,
    force: bool = False,
    single_file: Path | None = None,
) -> dict[str, str]:
    """Preprocess .qmd files to .md using quarto-prerender.

    Args:
        config: Foliate configuration
        force: Force re-render all .qmd files
        single_file: Only process this specific .qmd file (Path object)

    Returns:
        dict mapping .qmd paths to generated .md paths,
        or empty dict if disabled/unavailable
    """
    if not config.advanced.quarto_enabled:
        return {}

    try:
        from quarto_prerender import is_quarto_available, render_qmd
    except ImportError:
        debug("quarto-prerender not installed, skipping .qmd preprocessing")
        return {}

    if not is_quarto_available():
        debug("Quarto CLI not found, skipping .qmd preprocessing")
        return {}

    vault_path = config.vault_path
    if not vault_path:
        return {}

    pages_path = vault_path.resolve()
    cache_dir = config.get_cache_dir() / "quarto"
    assets_dir = pages_path / "assets" / "quarto"

    # quarto_python is already expanded by config loading
    quarto_python = config.advanced.quarto_python or None

    def _render_source(qmd_file: Path) -> str | None:
        md_file = qmd_file.with_suffix(".md")

        # Check if render needed: md doesn't exist or qmd is newer
        needs_render = not md_file.exists() or (
            qmd_file.stat().st_mtime > md_file.stat().st_mtime
        )

        if not force and not needs_render:
            return str(md_file)

        result = render_qmd(
            qmd_file=qmd_file,
            pages_dir=pages_path,
            cache_dir=cache_dir,
            assets_dir=assets_dir,
            python=quarto_python,
            verbose=False,
        )
        if result:
            return str(result)
        return None

    if single_file:
        # Process single file
        qmd_file = Path(single_file).resolve()
        if not qmd_file.exists():
            debug(f"Quarto source missing, skipping: {qmd_file}")
            return {}

        result = _render_source(qmd_file)
        if result:
            return {str(qmd_file): result}
        return {}

    from .build import select_content_sources

    results: dict[str, str] = {}
    selected_sources = select_content_sources(
        pages_path,
        config,
        {".qmd"},
        duplicate_label="Quarto sources",
    )
    for source in selected_sources:
        result = _render_source(source.source_file)
        if result:
            results[str(source.source_file)] = result

    return results
