# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.7.0] - 2026-05-13

### Changed
- Pin CORE_VERSION to 2.7.0

### Fixed
- Download timeout and checksum fail-closed (#17)
- Add `CAPISCIO_REQUIRE_CHECKSUM` fail-closed mode
- Binary SHA-256 checksum verification after download

## [2.6.0] - 2026-03-27

### Changed
- **CORE VERSION**: Now downloads `capiscio-core` v2.6.0

## [2.5.0] - 2026-03-16

### Changed
- **CORE VERSION**: Now downloads `capiscio-core` v2.5.0

### Fixed
- `CORE_VERSION` was stuck at v2.2.0 since the v2.2.0 release, meaning v2.3.0–v2.4.0 all downloaded `capiscio-core` v2.2.0 despite their changelog entries stating otherwise. This release correctly aligns the downloaded binary version.

## [2.4.0] - 2026-01-18

### Changed
- Bump package version to 2.4.0
- **Note:** `CORE_VERSION` was incorrectly left at v2.2.0 (fixed in v2.5.0)

## [2.3.1] - 2025-01-14

### Fixed
- Aligned all version references across package metadata
- **Note:** `CORE_VERSION` was incorrectly left at v2.2.0 (fixed in v2.5.0)

## [2.3.0] - 2025-01-13

### Added
- **E2E Test Suite**: Comprehensive end-to-end test coverage for CLI wrapper workflows

### Fixed
- **CLI Command Syntax**: Fixed incorrect command syntax in documentation

### Changed
- Bump package version to 2.3.0
- **Note:** `CORE_VERSION` was incorrectly left at v2.2.0 (fixed in v2.5.0)

## [2.2.0] - 2025-12-10

### Changed
- **VERSION ALIGNMENT**: All CapiscIO packages now share the same version number.
  - `capiscio-core`, `capiscio` (npm), and `capiscio` (PyPI) are all v2.2.0.
  - Simplifies compatibility - no version matrix needed.
- **CORE VERSION**: Now downloads `capiscio-core` v2.2.0.

### Added
- **Test Suite**: Added comprehensive test coverage (96%) for CLI wrapper and binary manager.

## [2.1.3] - 2025-11-21

### Fixed
- **Core Version Sync**: Fixed an issue where the wrapper attempted to download a non-existent `v2.1.2` of `capiscio-core`. It now correctly downloads `v1.0.2`.
- **Package Versioning**: Bumped package version to `2.1.3` to resolve PyPI conflicts while pointing to the stable `v1.0.2` core binary.

## [2.1.2] - 2025-11-21

### Added
- **CLI Wrapper**: Initial release of the new Python CLI wrapper.
- **Architecture**: Replaced the legacy Python library with a lightweight wrapper that downloads and executes the high-performance Go binary (`capiscio-core`).
- **Platform Support**: Automatic detection and download for Linux, macOS, and Windows (AMD64/ARM64).
- **Zero Dependencies**: The wrapper itself has minimal dependencies (`rich`, `platformdirs`, `requests`) and delegates all logic to the standalone binary.

### Removed
- **Legacy Library**: Removed the old Python implementation of the validation logic in favor of the unified Go core.
