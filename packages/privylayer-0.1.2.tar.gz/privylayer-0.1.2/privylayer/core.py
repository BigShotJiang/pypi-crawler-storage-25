
import uuid

import re

pattern_num = re.compile(r"\b[5-9]\d{9}\b")
pattern_email = re.compile(r"[a-zA-Z0-9.%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]+")
pattern_aadhaar = re.compile(r"\b[1-9]\d{11}\b")
pattern_pan = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")
pattern_ifsc = re.compile(r"\b[A-Z]{4}0\d{6}\b")

uu_id = str(uuid.uuid1())

detect_patterns = {"Phone" : pattern_num , "email": pattern_email , "Aadhaar" : pattern_aadhaar , "PAN" : pattern_pan , "IFSC" : pattern_ifsc}





def mask(prompt):
    
    context = {}
    seen = {}
    counter = 1
    value = ""
    masked_txt = prompt
    for i , k in detect_patterns.items():
        matches = k.finditer(masked_txt)

        for j in matches:
            value = j.group()

            if value in seen:
                token = seen[value]

            else:
                token_id = f"x_{counter}"
                token = f"⟦PII_{i}_{token_id}⟧"

                context[token] = value
                seen[value] = token
                counter+=1
            masked_txt = masked_txt.replace(value , token)


    return masked_txt , context , seen

def unmask(masked_txt, context):
    for token, value in context.items():
        masked_txt = masked_txt.replace(token, value)

    unmask_txt = masked_txt

    return unmask_txt

