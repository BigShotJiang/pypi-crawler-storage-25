import re

pattern_num = re.compile(r"\b[5-9]\d{9}\b")
pattern_email = re.compile(r"[a-zA-Z0-9.%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]+")
pattern_aadhaar = re.compile(r"\b[1-9]\d{11}\b")
pattern_pan = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")
pattern_ifsc = re.compile(r"\b[A-Z]{4}0\d{6}\b")