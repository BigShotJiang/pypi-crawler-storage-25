# Created on 26/07/2025
# Author: Frank Vega

import itertools
from . import utils

import networkx as nx
from hallelujah.algorithm import find_vertex_cover as linear_find_vertex_cover

def find_vertex_cover(graph):
    """
    Compute a near-optimal vertex cover for an undirected graph with an approximation ratio under 2.
    
    A vertex cover is a set of vertices such that every edge in the graph is incident 
    to at least one vertex in the set. This function finds an approximate solution
    using a polynomial-time reduction approach.
    
    Args:
        graph (nx.Graph): Input undirected graph.
    
    Returns:
       set: A set of vertex indices representing the approximate vertex cover set.
             Returns an empty set if the graph is empty or has no edges.
             
    Raises:
        ValueError: If input is not a NetworkX Graph object.
        RuntimeError: If the polynomial-time reduction fails (max degree > 1 after transformation).
    """
    def is_valid(graph, vertex_cover):
        """
        Verifies if a given set of vertices is a valid vertex cover for the graph.

        Args:
            graph (nx.Graph): The input graph.
            vertex_cover (set): A set of vertices to check.

        Returns:
            bool: True if the set is a valid vertex cover, False otherwise.
        """
        for u, v in graph.edges():
            # A vertex cover must touch every edge; finding one uncovered edge is enough to fail
            if u not in vertex_cover and v not in vertex_cover:
                return False
        return True
    
    def vc_to_vc_reduction(G, t=3):
        """
        Transform graph G into a larger auxiliary graph whose vertex cover
        encodes, via a majority vote over t independent copies, a vertex cover
        of the original graph with a provably better approximation ratio.

        Each original vertex v is replaced by t "copy gadgets". Each copy gadget
        consists of a star with a 3-leaf triangle: three leaf nodes
        (copy{i}_0, copy{i}_1, copy{i}_2) all connected to a shared hub node
        (copy{i}_3). Any minimum vertex cover of this star must include either
        the hub alone or all three leaves — the structure forces a binary choice
        that encodes whether v should be in the cover.

        Each original edge (u, v) is replicated across the t copies by connecting
        the corresponding leaf nodes, so the cover obligations of the original
        graph are faithfully preserved in each copy.

        The majority vote in extract_original_vc then picks vertex v for the
        recovered cover only when more than half of its copies voted for it
        (i.e., all three leaves were chosen), which statistically suppresses
        errors introduced by the approximation algorithm applied to the
        transformed graph and drives the effective ratio below 2.

        Args:
            G (nx.Graph): The input graph to reduce.
            t (int): Number of independent copies per vertex (default 3).
                     Higher t increases the graph size but tightens the majority vote.

        Returns:
            nx.Graph: The transformed graph Gp ready for vertex cover approximation.
        """
        Gp = nx.Graph()

        def star(node):
            # Build a 3-leaf star rooted at hub z: leaves u, v, w each connect
            # to z but not to each other. Any VC must include z (covers all three
            # edges cheaply) or all three leaves (the only other valid option),
            # creating the forced binary encoding used by the majority vote.
            nodes = [f"{node}_0", f"{node}_1", f"{node}_2", f"{node}_3"]
            u, v, w, z = nodes[0], nodes[1], nodes[2], nodes[3]
            Gp.add_edge(u, z)
            Gp.add_edge(v, z)
            Gp.add_edge(w, z)
            return nodes  # [leaf0, leaf1, leaf2, hub]

        # Build t independent copy gadgets for every original vertex.
        # node_map[v][i] gives the four nodes of the i-th star gadget for v,
        # ordered as [leaf0, leaf1, leaf2, hub].
        node_map = {}
        for v in G.nodes():
            copies = []
            for i in range(t):
                # Each copy is an independent star gadget; naming includes the
                # copy index so node names stay unique across all gadgets
                tri = star(f"{v}_copy{i}")
                copies.append(tri)
            node_map[v] = copies

        # Replicate every original edge across all t copy layers by connecting
        # the corresponding leaves (indices 0–2) of u's and v's gadgets.
        # The hub (index 3) is intentionally excluded: inter-vertex edges must
        # run through the leaves so that the VC decision for each vertex is
        # readable from whether the leaves or the hub was chosen.
        for u, v in G.edges():
            for i in range(t):
                for k in range(3):  # connect leaf k of u's copy i to leaf k of v's copy i
                    Gp.add_edge(
                        node_map[u][i][k],
                        node_map[v][i][k]
                    )

        return Gp
        
    def extract_original_vc(vertex_cover, G, t=3):
        """
        Recover a vertex cover of the original graph G from a vertex cover of
        the transformed graph produced by vc_to_vc_reduction.

        For each original vertex v, the function counts how many of its t copy
        gadgets had all three leaves selected in the transformed cover. A gadget
        whose three leaves are all covered indicates that the approximation
        algorithm "voted" to include v in the cover for that copy. The hub-only
        choice (the cheaper option in an exact solution) corresponds to v NOT
        being in the cover.

        Including v in the recovered cover only when a strict majority of copies
        voted for it suppresses random errors in the approximation, yielding a
        cover of the original graph whose size is provably closer to optimal
        than the direct cover from hvala_find_vertex_cover alone.

        Args:
            vertex_cover (set): Vertex cover of the transformed graph.
            G (nx.Graph): The original graph (used to iterate over original vertices).
            t (int): Number of independent copies used during reduction (must match
                     the value passed to vc_to_vc_reduction, default 3).

        Returns:
            set: A vertex cover of the original graph G.
        """
        original_vc = set()

        for v in G.nodes():
            # Count how many of the t gadgets cast a "yes" vote for v.
            # A "yes" vote means all three leaf nodes of that gadget were included
            # in the transformed cover (leaf-only choice = v belongs in original VC).
            selected = 0

            for i in range(t):
                tri_nodes = [
                    f"{v}_copy{i}_0",
                    f"{v}_copy{i}_1",
                    f"{v}_copy{i}_2"
                ]
                # All three leaves chosen <=> this copy voted to include v
                count = sum(1 for n in tri_nodes if n in vertex_cover)
                if count == 3:
                    selected += 1

            # Majority rule: include v only when more than half the copies agree,
            # which filters out gadgets where the hub was chosen instead of the
            # leaves (a "no" vote). This is the key step that tightens the ratio.
            if selected > t // 2:
                original_vc.add(v)

        return original_vc

    # Reject non-graph inputs early to avoid misleading errors downstream
    if not isinstance(graph, nx.Graph):
        raise ValueError("Input must be an undirected NetworkX Graph.")
    
    # An empty graph or one with no edges has a trivially empty vertex cover
    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        return set()
    
    # Work on a copy so the caller's graph is never mutated
    working_graph = graph.copy()

    # Self-loops are irrelevant to vertex cover (a single vertex already covers them)
    working_graph.remove_edges_from(list(nx.selfloop_edges(working_graph)))

    # Isolated vertices cannot belong to any edge, so they never need to be in the cover
    working_graph.remove_nodes_from(list(nx.isolates(working_graph)))
    
    # After stripping self-loops and isolates the graph may now be empty
    if working_graph.number_of_nodes() == 0:
        return set()
    
    approximate_vertex_cover = set()

    # Process each connected component independently; a vertex cover of the whole
    # graph is the union of vertex covers of its components
    for component in nx.connected_components(working_graph):
        component_subgraph = working_graph.subgraph(component).copy()

        # Candidate 1: direct cover on the original component — the baseline
        solutions = [linear_find_vertex_cover(component_subgraph)]

        # Candidate 2: apply the VC-to-VC reduction, solve on the transformed
        # graph, then map back via majority vote. The reduction amplifies the
        # signal of which vertices truly belong in the optimal cover, so the
        # recovered cover tends to be smaller than the direct one.
        reduced_graph = vc_to_vc_reduction(component_subgraph)
        reduced_cover = linear_find_vertex_cover(reduced_graph)
        # Map the cover found in the reduced graph back to vertices of the original component
        solutions.append(extract_original_vc(reduced_cover, component_subgraph))

        # Taking the smaller of the two candidates is what pushes the effective
        # approximation ratio below 2: one candidate always rescues the
        # cases where the other overshoots
        solution = min(solutions, key=len)
        approximate_vertex_cover.update(solution)

    # Verify the result is a genuine vertex cover before returning it;
    # a failure here indicates a bug in the reduction or extraction logic
    if not is_valid(graph, approximate_vertex_cover):
        raise RuntimeError(
            f"Polynomial-time reduction failed: the set {approximate_vertex_cover} "
            f"is not a vertex cover for the original graph."
        )

    return approximate_vertex_cover

def find_vertex_cover_brute_force(graph):
    """
    Computes an exact minimum vertex cover in exponential time.

    Args:
        graph: A NetworkX Graph.

    Returns:
        A set of vertex indices representing the exact vertex cover, or None if the graph is empty.
    """

    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        return None

    working_graph = graph.copy()
    working_graph.remove_edges_from(list(nx.selfloop_edges(working_graph)))
    working_graph.remove_nodes_from(list(nx.isolates(working_graph)))
    
    if working_graph.number_of_nodes() == 0:
        return set()

    n_vertices = len(working_graph.nodes())

    for k in range(1, n_vertices + 1): # Iterate through all possible sizes of the cover
        for candidate in itertools.combinations(working_graph.nodes(), k):
            cover_candidate = set(candidate)
            if utils.is_vertex_cover(working_graph, cover_candidate):
                return cover_candidate
                
    return None



def find_vertex_cover_approximation(graph):
    """
    Computes an approximate vertex cover in polynomial time with an approximation ratio of at most 2 for undirected graphs.

    Args:
        graph: A NetworkX Graph.

    Returns:
        A set of vertex indices representing the approximate vertex cover, or None if the graph is empty.
    """

    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        return None

    #networkx doesn't have a guaranteed minimum vertex cover function, so we use approximation
    vertex_cover = nx.approximation.vertex_cover.min_weighted_vertex_cover(graph)
    return vertex_cover