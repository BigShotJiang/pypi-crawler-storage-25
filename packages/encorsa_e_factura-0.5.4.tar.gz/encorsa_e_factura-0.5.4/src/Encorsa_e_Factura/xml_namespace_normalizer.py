"""
Modul pentru normalizarea prefixelor de namespace din XML-uri UBL 2.1 (e-Factura CIUS-RO).

Clientii pot trimite XML-uri valide cu prefixe non-standard (ex: n1, n2, ns0)
in loc de prefixele standard UBL (cbc, cac, etc.). Acest modul normalizeaza
prefixele la cele standard inainte de procesarea ulterioara.

Utilizeaza transformare XSLT (via lxml) pentru reatribuirea prefixelor.
Daca toate prefixele sunt deja standard, XML-ul este returnat neschimbat.
"""

from lxml import etree


# Maparea standard URI → prefix dorit
# None = namespace implicit (fara prefix, adica default namespace)
STANDARD_URI_TO_PREFIX = {
    "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2": None,
    "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2": None,
    "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2": "cbc",
    "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2": "cac",
    "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDataTypes-2": "qdt",
    "urn:oasis:names:specification:ubl:schema:xsd:UnqualifiedDataTypes-2": "udt",
    "urn:un:unece:uncefact:documentation:2": "ccts",
    "http://www.w3.org/2001/XMLSchema-instance": "xsi",
    "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2": "cec",
}

# Variante de URI gresite (intalnite la clienti) → URI-ul canonic corect
# Unii clienti genereaza URI-uri cu sufixul "21" (probabil confuzie cu versiunea UBL 2.1)
# in loc de sufixul corect "2" (versiunea schemei XSD)
# Aceasta mapa este EXPLICITA si INCHISA — se adauga doar variante confirmate
KNOWN_URI_VARIANTS = {
    "urn:oasis:names:specification:ubl:schema:xsd:Invoice-21": "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
    "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-21": "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2",
    "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-21": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
    "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-21": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
    "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDataTypes-21": "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDataTypes-2",
    "urn:oasis:names:specification:ubl:schema:xsd:UnqualifiedDataTypes-21": "urn:oasis:names:specification:ubl:schema:xsd:UnqualifiedDataTypes-2",
    "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-21": "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2",
    "urn:un:unece:uncefact:documentation:21": "urn:un:unece:uncefact:documentation:2",
    "http://www.w3.org/2001/XMLSchema-instance1": "http://www.w3.org/2001/XMLSchema-instance",
}


def _resolve_uri_variant(uri):
    """
    Verifica daca un URI este o varianta gresita cunoscuta si returneaza URI-ul canonic.

    Returns:
        tuple: (canonical_uri, is_variant)
            - canonical_uri: URI-ul canonic daca este varianta cunoscuta, altfel URI-ul original
            - is_variant: True daca URI-ul a fost recunoscut ca varianta gresita
    """
    if uri in KNOWN_URI_VARIANTS:
        return KNOWN_URI_VARIANTS[uri], True
    return uri, False


def _collect_namespace_mappings(root):
    """
    Colecteaza toate perechile URI → prefix din intreg arborele XML.
    Se pastreaza prima aparitie a fiecarui URI.

    Returns:
        dict: URI → prefix gasit in document (prefix=None pentru default namespace)
    """
    uri_to_prefix = {}
    for elem in root.iter():
        if hasattr(elem, 'nsmap'):
            for prefix, uri in elem.nsmap.items():
                if uri not in uri_to_prefix:
                    uri_to_prefix[uri] = prefix
    return uri_to_prefix


def _build_normalization_xslt(uris_to_remap, all_uri_to_prefix):
    """
    Construieste un stylesheet XSLT care normalizeaza prefixele de namespace.

    Stylesheet-ul contine:
    1. Un identity transform (copiaza tot documentul implicit, inclusiv namespace-uri necunoscute)
    2. Template-uri specifice pentru fiecare namespace care necesita reatribuire de prefix

    Args:
        uris_to_remap: dict {found_uri: (desired_prefix, canonical_uri)} - namespace-urile care necesita reatribuire
        all_uri_to_prefix: dict {uri: found_prefix} - toate namespace-urile gasite in document

    Returns:
        str: Stylesheet XSLT ca string
    """
    ns_decl_parts = []
    declared_prefixes = set()

    for found_uri, (desired_prefix, canonical_uri) in uris_to_remap.items():
        if desired_prefix is not None and desired_prefix not in declared_prefixes:
            ns_decl_parts.append(f'xmlns:{desired_prefix}="{canonical_uri}"')
            declared_prefixes.add(desired_prefix)

    for uri, found_prefix in all_uri_to_prefix.items():
        if uri not in uris_to_remap and found_prefix is not None:
            if found_prefix not in declared_prefixes and found_prefix != "xsl":
                ns_decl_parts.append(f'xmlns:{found_prefix}="{uri}"')
                declared_prefixes.add(found_prefix)

    ns_decls_str = "\n    ".join(ns_decl_parts)
    if ns_decls_str:
        ns_decls_str = "\n    " + ns_decls_str

    templates = []
    for found_uri, (desired_prefix, canonical_uri) in uris_to_remap.items():
        if desired_prefix is None:
            name_expr = "{local-name()}"
        else:
            name_expr = f"{desired_prefix}:{{local-name()}}"

        templates.append(
            f'  <xsl:template match="*[namespace-uri()=\'{found_uri}\']">\n'
            f'    <xsl:element name="{name_expr}" namespace="{canonical_uri}">\n'
            f'      <xsl:apply-templates select="@*|node()"/>\n'
            f'    </xsl:element>\n'
            f'  </xsl:template>'
        )

    templates_str = "\n\n".join(templates)

    xslt = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<xsl:stylesheet version="1.0"\n'
        '    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"'
        f'{ns_decls_str}>\n'
        '\n'
        '  <xsl:output method="xml" encoding="UTF-8" indent="no"/>\n'
        '\n'
        '  <!-- Identity transform: copiaza totul implicit -->\n'
        '  <xsl:template match="@*|node()">\n'
        '    <xsl:copy>\n'
        '      <xsl:apply-templates select="@*|node()"/>\n'
        '    </xsl:copy>\n'
        '  </xsl:template>\n'
        '\n'
        f'{templates_str}\n'
        '\n'
        '</xsl:stylesheet>'
    )

    return xslt


def _rebuild_with_consolidated_nsmap(root, desired_nsmap):
    """
    Reconstruieste arborele XML cu toate declaratiile de namespace consolidate pe elementul root.
    Asigura un output curat unde toate namespace-urile sunt declarate o singura data pe root.

    Args:
        root: elementul root lxml dupa transformarea XSLT
        desired_nsmap: dict {prefix: uri} - maparea dorita de namespace-uri

    Returns:
        elementul root lxml reconstruit
    """
    def _copy_element(source, parent=None, is_root=False):
        # lxml represents comment and processing-instruction nodes with a callable
        # .tag (etree.Comment / etree.ProcessingInstruction) instead of a string.
        # These cannot be passed to SubElement/Element as a tag name.
        if not is_root and callable(source.tag):
            if source.tag is etree.Comment:
                new_node = etree.Comment(source.text)
            elif source.tag is etree.ProcessingInstruction:
                new_node = etree.ProcessingInstruction(source.target, source.text)
            else:
                # Unknown special node — skip it safely
                return None
            new_node.tail = source.tail
            parent.append(new_node)
            return new_node

        if is_root:
            new_elem = etree.Element(source.tag, attrib=dict(source.attrib), nsmap=desired_nsmap)
        else:
            new_elem = etree.SubElement(parent, source.tag, attrib=dict(source.attrib))
        new_elem.text = source.text
        new_elem.tail = source.tail
        for child in source:
            _copy_element(child, parent=new_elem)
        return new_elem

    return _copy_element(root, is_root=True)


def normalize_xml_namespaces(xml_string, source_id=""):
    """
    Normalizeaza prefixele de namespace dintr-un sir XML la prefixele standard UBL 2.1.

    Pasi:
    1. Parseaza XML-ul si inspecteza declaratiile de namespace (prefix → URI)
    2. Compara prefixele gasite cu maparea standard UBL
    3. Daca toate corespund → returneaza XML-ul neschimbat (fara overhead)
    4. Daca exista diferente → aplica transformare XSLT care reatribuie prefixele
    5. URI-uri necunoscute (care nu sunt in maparea standard) → arunca eroare

    Args:
        xml_string: Sirul XML de normalizat (str sau bytes)
        source_id: Identificator sursa (ex: ANAF_ID) pentru log/trasabilitate

    Returns:
        str: Sirul XML normalizat cu prefixe standard UBL

    Raises:
        Exception: Daca parsarea sau transformarea esueaza
        Exception: Daca sunt gasite namespace-uri cu URI necunoscut
    """
    if not xml_string or (isinstance(xml_string, str) and not xml_string.strip()):
        return xml_string

    try:
        xml_bytes = xml_string.encode('utf-8') if isinstance(xml_string, str) else xml_string

        # Eliminam BOM daca exista
        if xml_bytes.startswith(b'\xef\xbb\xbf'):
            xml_bytes = xml_bytes[3:]

        parser = etree.XMLParser(recover=False, remove_blank_text=False)
        root = etree.fromstring(xml_bytes, parser)

        # Colectam toate mapele URI → prefix din document
        uri_to_found_prefix = _collect_namespace_mappings(root)

        # Determinam care URI-uri necesita reatribuire de prefix
        uris_to_remap = {}
        unknown_uris = []
        remap_log = []
        variant_log = []

        for uri, found_prefix in uri_to_found_prefix.items():
            # xmlns="" este o "undeclarare" valida a namespace-ului implicit — se ignora
            if uri == "":
                continue

            # Verificam daca URI-ul este o varianta gresita cunoscuta (ex: -21 in loc de -2)
            canonical_uri, is_variant = _resolve_uri_variant(uri)
            if is_variant:
                variant_log.append(f"'{uri}' -> '{canonical_uri}'")

            if canonical_uri in STANDARD_URI_TO_PREFIX:
                desired_prefix = STANDARD_URI_TO_PREFIX[canonical_uri]
                # Trebuie reatribuire daca: prefixul difera SAU URI-ul este varianta gresita
                if found_prefix != desired_prefix or is_variant:
                    uris_to_remap[uri] = (desired_prefix, canonical_uri)
                    desired_display = desired_prefix if desired_prefix is not None else "(implicit)"
                    found_display = found_prefix if found_prefix is not None else "(implicit)"
                    remap_log.append(
                        f"'{found_display}' -> '{desired_display}' ({uri})"
                    )
            elif any(uri.startswith(known_uri) for known_uri in STANDARD_URI_TO_PREFIX):
                # URI-ul incepe cu un URI standard cunoscut dar are un sufix extra
                # (ex: schemaLocation concatenat, cale relativa XSD etc.) — se ignora cu avertisment
                print(
                    f"[xml_namespace_normalizer.normalize_xml_namespaces] "
                    f"ATENTIE: URI malformat ignorat in documentul '{source_id}': "
                    f"prefix='{found_prefix}', URI='{uri}' "
                    f"(probabil schemaLocation sau cale XSD concatenata)"
                )
            else:
                unknown_uris.append((found_prefix, uri))

        # Logam variante de URI gresite gasite
        if variant_log:
            variant_desc = "; ".join(variant_log)
            print(
                f"[xml_namespace_normalizer.normalize_xml_namespaces] "
                f"ATENTIE: URI-uri variante gresite gasite in documentul '{source_id}', "
                f"se corecteaza automat: {variant_desc}"
            )

        # URI-uri necunoscute → eroare
        if unknown_uris:
            unknown_desc = "; ".join(
                f"prefix='{p if p is not None else '(implicit)'}', URI='{u}'"
                for p, u in unknown_uris
            )
            error_message = (
                f"[xml_namespace_normalizer.normalize_xml_namespaces] "
                f"Eroare: Namespace-uri cu URI necunoscut gasite in documentul '{source_id}': {unknown_desc}. "
                f"Toate URI-urile de namespace trebuie sa fie din standardul UBL 2.1."
            )
            print(error_message)
            raise Exception(error_message)

        # Daca nu e nevoie de reatribuire → returnam XML-ul neschimbat
        if not uris_to_remap:
            return xml_string

        # Logam reatribuirile aplicate
        remap_desc = "; ".join(remap_log)
        print(
            f"[xml_namespace_normalizer.normalize_xml_namespaces] "
            f"Normalizare prefixe namespace pentru '{source_id}': {remap_desc}"
        )

        # Construim si aplicam transformarea XSLT
        xslt_string = _build_normalization_xslt(uris_to_remap, uri_to_found_prefix)
        xslt_doc = etree.fromstring(xslt_string.encode('utf-8'))
        transform = etree.XSLT(xslt_doc)
        result_tree = transform(root)
        result_root = result_tree.getroot()

        # Construim nsmap-ul dorit pentru consolidare pe root
        desired_nsmap = {}
        for uri, found_prefix in uri_to_found_prefix.items():
            if uri in uris_to_remap:
                desired_prefix, canonical_uri = uris_to_remap[uri]
                desired_nsmap[desired_prefix] = canonical_uri
            elif uri in STANDARD_URI_TO_PREFIX:
                desired_nsmap[STANDARD_URI_TO_PREFIX[uri]] = uri
            else:
                desired_nsmap[found_prefix] = uri

        # Reconstruim arborele cu namespace-urile consolidate pe root
        clean_root = _rebuild_with_consolidated_nsmap(result_root, desired_nsmap)
        etree.cleanup_namespaces(clean_root)

        # Serializare
        output_bytes = etree.tostring(
            clean_root, xml_declaration=True, encoding='UTF-8'
        )
        return output_bytes.decode('utf-8')

    except Exception as e:
        # Daca eroarea este deja formatata cu sursa, o propagam direct
        if "[xml_namespace_normalizer" in str(e):
            raise
        error_message = (
            f"[xml_namespace_normalizer.normalize_xml_namespaces] "
            f"Eroare la normalizarea namespace-urilor XML pentru '{source_id}': {str(e)}"
        )
        print(error_message)
        raise Exception(error_message)
