#!/usr/bin/env python3
import requests
import json
import zipfile
import io
from typing import Dict, Any, Tuple


def download_invoice_response_anaf(
    id_descarcare: str,
    extras_json_str: str,
) -> Tuple[int, Dict[str, Any]]:
    """
    Download the response from ANAF for a processed invoice.
    
    Parameters:
        id_descarcare: Download ID obtained from stareMesaj or lista mesaje response
        extras_json_str: JSON string containing:
            {
              "env": "test" | "prod",                         # default: "test"
              "oauth": {
                  "client_id": "...",
                  "client_secret": "...",
                  "refresh_token": "...",
                  "parameters": {
                      "proxi_pt_anaf_https": "",              # optional proxy for HTTPS
                      "proxi_pt_anaf_http": ""                # optional proxy for HTTP
                  }
              },
              "timeout_seconds": 60                           # optional: default 60
            }
    
    Returns:
        Tuple of (status_code, response_dict)
        
        On success (200 with ZIP):
        {
            "xml_content": "<?xml ...",
            "upload_id": "5028442192",
            "size_bytes": 1234
        }
        
        On error (200 with JSON or other status):
        {
            "error": "error message",
            "title": "Descarcare mesaj"
        }
    
    Raises:
        ValueError: If required parameters are missing or invalid
        RuntimeError: If OAuth token cannot be obtained
    """
    try:
        from AnafUtils import get_token_with_refresh
    except:
        from .AnafUtils import get_token_with_refresh
    
    # 1) Validate id_descarcare
    if not id_descarcare:
        raise ValueError("[descarcaRaspuns.download_invoice_response_anaf] id_descarcare este obligatoriu")
    
    id_str = str(id_descarcare).strip()
    
    # 2) Parse extras
    try:
        extras: Dict[str, Any] = json.loads(extras_json_str)
    except Exception as exc:
        raise ValueError(f"[descarcaRaspuns.download_invoice_response_anaf] extras_json_str invalid: {exc}")
    
    env = (extras.get("env") or "test").lower()
    timeout_seconds = int(extras.get("timeout_seconds", 60))
    
    # 3) OAuth2: obtain access token
    oauth = extras.get("oauth") or {}
    client_id = oauth.get("client_id")
    client_secret = oauth.get("client_secret")
    refresh_token = oauth.get("refresh_token")
    token_params = oauth.get("parameters") or {}
    
    if not (client_id and client_secret and refresh_token):
        raise ValueError("[descarcaRaspuns.download_invoice_response_anaf] extras_json_str.oauth trebuie sa contina client_id, client_secret si refresh_token")
    
    access_token = get_token_with_refresh(refresh_token, client_id, client_secret, token_params)
    if not access_token:
        raise RuntimeError("[descarcaRaspuns.download_invoice_response_anaf] Nu s-a putut obtine access_token de la get_token_with_refresh, token-ul este GOL!")
    
    # Configure proxy if provided
    proxies = {}
    if token_params.get("proxi_pt_anaf_https"):
        proxies["https"] = token_params["proxi_pt_anaf_https"]
    if token_params.get("proxi_pt_anaf_http"):
        proxies["http"] = token_params["proxi_pt_anaf_http"]
    
    # 4) Build URL
    base = f"https://api.anaf.ro/{'test' if env == 'test' else 'prod'}/FCTEL/rest/descarcare"
    url = f"{base}?id={id_str}"
    
    # 5) Prepare headers
    headers = {
        "Authorization": f"Bearer {access_token}",
    }
    
    # 6) Send GET request
    try:
        resp = requests.get(
            url,
            headers=headers,
            timeout=timeout_seconds,
            proxies=proxies or None,
            stream=True
        )
        
        if resp.status_code != 200:
            # Try to parse JSON error response
            try:
                error_data = resp.json()
                return resp.status_code, {
                    "error": error_data.get("eroare", resp.text),
                    "title": error_data.get("titlu", "Eroare")
                }
            except Exception:
                return resp.status_code, {
                    "error": resp.text or f"HTTP {resp.status_code}",
                    "title": "[descarcaRaspuns.download_invoice_response_anaf] Eroare la cerere"
                }
        
        # Status code is 200 - check content type
        content_type = resp.headers.get('Content-Type', '').lower()
        
        # Try to determine if it's JSON or ZIP
        content = resp.content
        
        # First, try to parse as JSON (error response)
        if 'application/json' in content_type or content.startswith(b'{'):
            try:
                error_data = json.loads(content)
                return 200, {
                    "error": error_data.get("eroare", "Eroare necunoscuta"),
                    "title": error_data.get("titlu", "Descarcare mesaj")
                }
            except Exception:
                pass  # Not JSON, continue to ZIP handling
        
        # Try to handle as ZIP file
        try:
            zip_buffer = io.BytesIO(content)
            with zipfile.ZipFile(zip_buffer, 'r') as zip_file:
                # List all files in the ZIP
                file_list = zip_file.namelist()
                
                # Find the XML file without "semnatura_" prefix
                xml_file = None
                upload_id = None
                
                for filename in file_list:
                    if filename.endswith('.xml') and not filename.startswith('semnatura_'):
                        xml_file = filename
                        # Extract upload ID from filename (e.g., "5028442192.xml" -> "5028442192")
                        upload_id = filename.replace('.xml', '')
                        break
                
                if not xml_file:
                    return 200, {
                        "error": "[descarcaRaspuns.download_invoice_response_anaf] Nu s-a gasit niciun fisier XML valid in arhiva ZIP",
                        "title": "Arhiva invalida"
                    }
                
                # Extract and read the XML content
                xml_content = zip_file.read(xml_file).decode('utf-8')
                
                return 200, {
                    "xml_content": xml_content,
                    "upload_id": upload_id,
                    "size_bytes": len(xml_content)
                }
        
        except zipfile.BadZipFile:
            # Not a valid ZIP file
            # Try one more time to parse as JSON in case content-type was wrong
            try:
                error_data = json.loads(content)
                return 200, {
                    "error": error_data.get("eroare", "Eroare necunoscuta"),
                    "title": error_data.get("titlu", "Descarcare mesaj")
                }
            except Exception:
                return 200, {
                    "error": "[descarcaRaspuns.download_invoice_response_anaf] Format de raspuns invalid (nici ZIP, nici JSON)",
                    "title": "Raspuns invalid"
                }
    
    except requests.RequestException as exc:
        return 0, {
            "error": f"[descarcaRaspuns.download_invoice_response_anaf] Eroare la cererea HTTP: {str(exc)}",
            "title": "Exceptie la cerere"
        }