#!/usr/bin/env python3
import requests
from typing import Dict, Any, Tuple, Optional
import json
import xml.etree.ElementTree as ET

try:
    from AnafUtils import get_token_with_refresh
except:
    from .AnafUtils import get_token_with_refresh


def check_invoice_status_anaf(
    id_incarcare: str,
    extras_json_str: str,
) -> Tuple[int, Dict[str, Any]]:
    """
    Check the status of a previously uploaded invoice to ANAF.

    According to ANAF documentation, the 'stare' field can have these values:
    - "ok": File validated and processed successfully. Invoice is available to buyer.
    - "nok": Errors identified, file not processed. Invoice does NOT reach buyer.
    - "XML cu erori nepreluat de sistem": File rejected during upload.
    - "in prelucrare": Processing not yet completed.

    Parameters:
        id_incarcare: Upload index (numeric string) received from upload operation
        extras_json_str: JSON string containing:
            {
              "env": "test" | "prod",                         # default: "test"
              "oauth": {
                  "client_id": "...",
                  "client_secret": "...",
                  "refresh_token": "...",
                  "parameters": {
                      "proxi_pt_anaf_https": "",              # optional proxy for HTTPS
                      "proxi_pt_anaf_http": ""                # optional proxy for HTTP
                  }
              },
              "timeout_seconds": 60                           # optional: default 60
            }

    Returns:
        Tuple of (status_code, response_dict)

        Response structure on success (200):
        - XML format with header containing:
          - xmlns: namespace
          - xmlns:mfp: namespace for MFP
          - stareMesaj: root element
          - ExecutionStatus: status indicator
          - stare: "ok" | "nok" | "in prelucrare" | "XML cu erori nepreluat de sistem"
          - id_descarcare: download ID (present when stare is "ok" or "nok")

        Response structure on error (400):
        - JSON format:
          {
            "timestamp": "2019-08-2021 11:01:56",
            "status": "400",
            "errors": "Bad Request",
            "message": "Parametrul id_incarcare este obligatoriu"
          }

    Raises:
        ValueError: If required parameters are missing or invalid
        RuntimeError: If OAuth token cannot be obtained
    """

    # 1) Validate id_incarcare
    if not id_incarcare:
        raise ValueError("[verificareStatus.check_invoice_status_anaf] id_incarcare este obligatoriu")

    id_str = str(id_incarcare).strip()
    if not id_str.isdigit():
        raise ValueError(
            f"[verificareStatus.check_invoice_status_anaf] id_incarcare trebuie sa fie numeric (ex: '18'), s-a primit: {id_incarcare}"
        )

    # 2) Parse extras
    try:
        extras: Dict[str, Any] = json.loads(extras_json_str)
    except Exception as exc:
        raise ValueError(f"[verificareStatus.check_invoice_status_anaf] extras_json_str invalid: {exc}")

    env = (extras.get("env") or "test").lower()
    timeout_seconds = int(extras.get("timeout_seconds", 60))

    # 3) OAuth2: obtain access token
    oauth = extras.get("oauth") or {}
    client_id = oauth.get("client_id")
    client_secret = oauth.get("client_secret")
    refresh_token = oauth.get("refresh_token")
    token_params = oauth.get("parameters") or {}

    if not (client_id and client_secret and refresh_token):
        raise ValueError(
            "[verificareStatus.check_invoice_status_anaf] extras_json_str.oauth trebuie sa contina client_id, client_secret si refresh_token"
        )

    access_token = get_token_with_refresh(
        refresh_token, client_id, client_secret, token_params
    )
    if not access_token:
        raise RuntimeError(
            "[verificareStatus.check_invoice_status_anaf] Nu s-a putut obtine access_token de la get_token_with_refresh, token-ul este GOL!"
        )

    # Configure proxy if provided
    proxies = {}
    if token_params.get("proxi_pt_anaf_https"):
        proxies["https"] = token_params["proxi_pt_anaf_https"]
    if token_params.get("proxi_pt_anaf_http"):
        proxies["http"] = token_params["proxi_pt_anaf_http"]

    # 4) Build URL
    base = f"https://api.anaf.ro/{'test' if env == 'test' else 'prod'}/FCTEL/rest/stareMesaj"
    url = f"{base}?id_incarcare={id_str}"

    # 5) Prepare headers
    headers = {
        "Authorization": f"Bearer {access_token}",
    }

    # 6) Send GET request
    try:
        resp = requests.get(
            url, headers=headers, timeout=timeout_seconds, proxies=proxies or None
        )

        # Try parse as JSON first (for error responses)
        try:
            return resp.status_code, resp.json()
        except Exception:
            # Success responses are XML format
            return resp.status_code, {
                "xml": resp.text,
                "content_type": resp.headers.get("Content-Type", ""),
            }

    except requests.RequestException as exc:
        return 0, {"error": str(exc), "url": url}



def parse_anaf_status_response(status_code, response):
    """
    Parse ANAF invoice status XML response and return comprehensive JSON result
    """
    result = {
        "http_status_code": status_code,
        "success": False,
        "state": None,
        "download_id": None,
        "in_processing": False,
        "errors": [],
        "raw_response": response.get("xml", "") if isinstance(response, dict) else str(response)
    }
    
    try:
        # Extract XML from response
        xml_text = response.get("xml", "") if isinstance(response, dict) else str(response)
        
        # Parse XML
        root = ET.fromstring(xml_text)
        
        # Define namespace
        ns = {'ns': 'mfp:anaf:dgti:efactura:stareMesajFactura:v1'}
        
        # Get header attributes
        stare = root.get('stare')
        download_id = root.get('id_descarcare')
        
        result["state"] = stare
        result["download_id"] = download_id
        
        # Determine success based on state
        if stare == "ok":
            result["success"] = True
            if not download_id:
                result["errors"].append({
                    "message": "[verificareStatus.parse_anaf_status_response] Starea este 'ok' dar nu s-a furnizat ID de descarcare",
                    "type": "missing_data"
                })
        elif stare == "in prelucrare":
            result["in_processing"] = True
            result["errors"].append({
                "message": "[verificareStatus.parse_anaf_status_response] Factura este inca in curs de procesare",
                "type": "processing"
            })
        elif stare:
            result["errors"].append({
                "message": f"[verificareStatus.parse_anaf_status_response] Procesarea facturii a esuat: {stare}",
                "type": "processing_error"
            })
        
        # Check for Errors element
        errors = root.findall('ns:Errors', ns)
        if not errors:
            # Fallback: search without namespace prefix
            for child in root:
                if child.tag.endswith('Errors'):
                    errors.append(child)
        
        for error in errors:
            error_msg = error.get('errorMessage', '')
            if error_msg:
                result["errors"].append({
                    "message": error_msg,
                    "type": "validation_error"
                })
        
        if not stare and not result["errors"]:
            result["errors"].append({
                "message": "[verificareStatus.parse_anaf_status_response] Format de raspuns necunoscut",
                "type": "unknown_error"
            })
    
    except ET.ParseError as e:
        result["errors"].append({
            "message": f"[verificareStatus.parse_anaf_status_response] Eroare la parsarea XML-ului: {str(e)}",
            "type": "parse_error"
        })
    except Exception as e:
        result["errors"].append({
            "message": f"[verificareStatus.parse_anaf_status_response] Eroare neasteptata: {str(e)}",
            "type": "system_error"
        })
    
    return result