# Nexus — Future Scope

> This file tracks what's been shipped and what's still to build, ordered by priority.

---

## 🔴 High Priority — Next Sprint

*(Shipped work lives only under **Recently Shipped** below — nothing listed here is done yet.)*

### 1. Rollback Checkpoints
**Current state:** Zero rollback capability. A half-executed plan that fails mid-way can leave the system in a broken state.
**What to build:**
- `RollbackManager` class in `src/jarvis/core/rollback_manager.py`
- Before any `FILE_WRITE` step: `cp -a {file} ~/.nexus/rollback/{timestamp}/`
- Before any `SERVICE_MGT` step: record current `systemctl status` output
- Before destructive `TERMINAL` commands: snapshot installed package list
- Add `/undo` command in TUI that runs the most recent rollback manifest
- Store rollback manifests in `~/.nexus/rollback/` (last 5 plans)

### 2. Dynamic Slash Command Registry
**Current state:** Hardcoded `if/elif` handlers in `console_app.py`. Adding a new command requires editing the chain.
**What to build:**
- Dynamic command registry with decorator-based registration.
- Autocomplete support via `prompt_toolkit` completions.
- Plugin-style command loading so new commands don't touch core TUI code.

### 3. FILE_APPEND / FILE_PATCH Action
**Current state:** Nexus only has `FILE_WRITE` which overwrites the entire file. To append to a file (e.g., add a line to `.bashrc`, append config to `nginx.conf`), the LLM must use a `TERMINAL` action with `echo "..." >> file`, which is fragile and prone to shell injection.
**What to build:**
- New `FILE_APPEND` action type that opens the file in append mode (`"a"`) with the same path traversal protection as `FILE_READ`.
- Optional `FILE_PATCH` variant that inserts content at a specific line or after a pattern match.
- Safer than piping through shell — content is written directly via Python `open()`, no injection possible.

### 4. LLM Rate Limiting & Budget Tracking
**Current state:** No throttling — a user in rapid-fire mode can burn through API credits in minutes. No visibility into how many tokens or dollars a session has consumed.
**What to build:**
- Per-minute rate limiter in `LLMClient.generate_response()`.
- Optional token budget tracker with configurable daily limits.
- **Live cost estimates**: Show approximate token usage and dollar cost per request in the TUI (e.g. `[dim]~1.2k tokens · $0.003[/dim]`).
- `/usage` command to show session and daily totals.

### 5. LLM_PROCESS Hardening
**Current state:** `LLM_PROCESS` is newly shipped and untested against edge cases in production (huge files, binary content, multi-step chains where context accumulates).
**What to build:**
- Graceful handling of binary/non-UTF-8 files detected mid-pipeline (currently errors).
- Chain-aware context: when multiple `LLM_PROCESS` steps run in sequence, accumulate a rolling summary instead of only passing the last step's output.
- Timeout protection: cap LLM processing time so a stuck API call doesn't block the plan indefinitely.
- Integration tests with real file types (.py, .json, .log, .conf, binary).

### 6. Distribution & Self-Update
**Current state:** No auto-update mechanism. Config schema changes between versions can silently break settings. No way for the user to check if they're on the latest version.
**What to build:**
- `/version` command that checks PyPI for the latest `nexus-linux-assistant` release and shows upgrade instructions if behind.
- Config migration: `ConfigManager` reads a `schema_version` field and runs upgrade hooks when the schema changes (e.g. new fields with defaults, renamed keys).
- Optional update notification on startup (non-blocking, dismissible).

---

## 🟡 Medium Priority

### 1. ~~Context Window Management for Long Plans~~ → **Shipped as Context Condenser**
**Status: SHIPPED (March 2026)**
- `ContextCondenser` in `src/jarvis/ai/context_condenser.py` uses a fast LLM (Groq preferred) to summarize large context instead of blind character truncation.
- Integrated at 4 key points: `enrich_prompt` (memory), planner `_build_prompt` (context), `FILE_READ` (large files), `LLM_PROCESS` (input data).
- Visual feedback: `⚡ Condensing file content: 48,230 → 11,847 chars`.
- Falls back to truncation when no LLM client is available.

### 2. Parallel Execution for Independent Steps
**Current state:** All plan steps are strictly sequential even when they have no dependencies.
**What to build:**
- Add optional `"parallel": true` and `"depends_on": [step_id]` fields to `TaskStep`.
- Planner prompt rule: *"Steps with no data dependency on previous steps MAY be marked parallel: true"*.
- Orchestrator runs parallel-flagged steps with `asyncio.gather()`.

### 3. Session File Security
**Current state:** `~/.nexus/session.json` stores conversation history (which may include sensitive command outputs) but has no file permissions set.
**What to build:**
- `os.chmod(session_file, 0o600)` after every write in `PersistentSessionManager`.

### 4. Model Discovery & Search
**Current state:** `/settings model` only shows hardcoded models from `model_catalog.py`. Users can't browse what's available on OpenRouter/Groq or search for new models.
**What to build:**
- `/models search <query>` that queries the OpenRouter API (`/api/v1/models`) and Groq model list to find matching models.
- Show context window size, pricing, and speed tier for each result.
- Allow users to set any discovered model as their chat/router/browser model (with a warning if untested).

### 5. Structured Observability & Metrics
**Current state:** Audit log exists but is unstructured text. No metrics on LLM latency, token usage, plan success rates, or self-heal frequency.
**What to build:**
- `MetricsCollector` class that records per-request: provider, model, latency_ms, tokens_in, tokens_out, success/fail.
- `/stats` command showing session summary: total requests, avg latency, tokens used, self-heal triggers, cache hit rate.
- Optional export to JSON for external dashboards.

### 6. Condensation Progress UX
**Current state:** Context Condenser shows a one-line message after completion but no progress indicator while the LLM is compressing (can take 2-5s for large files).
**What to build:**
- Show a Rich spinner (`Condensing large context...`) during the condenser LLM call.
- For FILE_READ of very large files, show a two-phase indicator: `Reading file...` → `Condensing 48K chars...` → result.

---

## 🔵 Strategic (Long-term)

### 1. Git Assistant
- Natural language git: squash commits, branch, diff since date, rebase.
- `GIT` action type with pre/post diff summary as Markdown.

### 2. Docker Management Mode
- `DOCKER_MGT` action: `ps`, `logs`, `restart`, `stats`, `prune`.
- Ergonomic chat: *"tail logs for nginx"*, *"stop all exited containers"*.

### 3. Cron Job Manager
- Named cron jobs stored in `~/.nexus/crontab.json`.
- Natural language → cron expression (LLM-validated).
- `/crons` TUI command to list/delete.

### 4. MCP Integration
- Expose `nexus.execute`, `nexus.plan`, `nexus.read_file` as MCP tool endpoints.
- Let Cursor/Claude Desktop/Windsurf delegate shell tasks to Nexus.

### 5. Natural Language Code Review
- `git diff` or `git show HEAD` → LLM security/bug/style review.
- *"audit my last commit for injection risks"*.

### 6. Interactive Desktop Avatar
- A small Electron-based or WebView companion that renders `nexusbot.svg`.
- Reacts to agent state (Thinking, Success, Failure) via WebSockets.
- Face animations synced with LLM output.

---

## ✅ Recently Shipped

### LLM_PROCESS, Context Condenser & Router Expansion (March 2026)
- **LLM_PROCESS action**: New orchestrator action type that passes data from a previous step (FILE_READ, TERMINAL output) to the LLM for analysis, summarization, or explanation. Enables natural requests like "summarize this config file", "explain what's in main.py", "find my bashrc and tell me what aliases are defined".
- **Context Condenser** (`src/jarvis/ai/context_condenser.py`): Smart LLM-based compression replaces blind character truncation at 4 key points (memory enrichment, planner context, FILE_READ, LLM_PROCESS input). Uses Groq-first ordering for speed. Visual feedback shows compression ratio. Falls back to truncation when no client available.
- **Expanded router model catalog**: Router/Decision Engine now supports models from all 5 providers (Groq, OpenRouter, Google, Anthropic, GroqGPT) instead of only Groq. Users can select any provider they have keys for via `/settings model router`.
- **Enhanced file analysis heuristics**: Decision engine now catches 9+ additional regex patterns for file read/analysis requests ("summarize this file", "what's in X.json", "explain this config", "read me ~/path") and routes them directly to PLAN at confidence 1.0 instead of falling through to the slow LLM router.

### Azure `AZURE_RUN` command transport
- **All** user commands are passed with **base64 → `bash`**, not `eval` + `shlex.quote` inside a single-quoted `bash -c '…'` (which broke quoting and could truncate any command to the first token). Preflight refuses obviously incomplete lines (empty, bare `git`/`curl`/`wget`/`bash`/`sh -c`/etc.). Planner rule **#8** requires complete one-liners for sketchy/sandbox-eligible steps.

### FTP safety (`security.py`)
- **Strict validation** flags: passwords inside `ftp://user:pass@…` URLs, `wget --ftp-password=…`, `lftp -u user,password`, and **anonymous** FTP (`-u anonymous`, `--ftp-user=anonymous`, `ftp://anonymous@…`). These surface as warnings and **block** under `SafetyCheck.check_command` (strict), matching other high-risk patterns.

### Closed — were High Priority (tracking only)

These used to sit in *High Priority*; they are **done** and described in detail in the dated sections below.

| Old backlog label | Where it shipped |
|-------------------|------------------|
| Small-task direct execution | **DIRECT_EXECUTE** intent — *System Operations Overhaul* |
| APP_INSTALL / local packages | Planner **`SYSTEM OPERATIONS REFERENCE`** + self-healer (`.deb`, AppImage, `.rpm`, archives, Snap, Flatpak) — *System Operations Overhaul*; no separate `APP_INSTALL` action |

### Reliability & safety pass (March 2026)
- **`rm -rf /` heuristics**: Root-delete detection no longer false-positives on `/tmp/...`, `/var/tmp/...`, or a **newline** between `/` and the rest of the path (wrapped shell lines). Stricter lookahead uses horizontal whitespace only where needed.
- **Command generator retries**: Same-provider backoff on 429/timeouts/5xx, then fallback clients; empty LLM output retries instead of raising immediately.
- **Orchestrator bugfix**: Removed inner `import os` inside `execute_plan` that shadowed the module and caused `UnboundLocalError` on `FILE_WRITE` self-heal when no `BROWSER` step had run.
- **Test suite**: **192** `pytest` tests (security regressions for `rm` heuristics, path allowlists, FTP CLI exposure, command-generator fallback/retry cases).

### System Operations Overhaul (March 2026)
- **DIRECT_EXECUTE Intent**: New `DIRECT_EXECUTE` action in the Decision Engine for simple, single-command operations (chmod, mkdir, cp, mv, tar, ls, df, free, etc.). Bypasses the full PLAN pipeline — no plan table, no confirmation, just generates and runs the command immediately. Heuristic regex patterns + LLM router awareness.
- **Planner System Operations Knowledge**: Planner prompt now includes a `SYSTEM OPERATIONS REFERENCE` section with correct procedures for AppImage (chmod + extract + desktop entry), .deb (dpkg -i), .rpm, .tar.gz, .zip, Snap, Flatpak, XDG standards, and desktop entries.
- **Isolated Shell Clarity**: Planner RULES section now includes explicit RIGHT/WRONG examples about shell isolation (cd has no effect between steps, always use absolute paths, chain with &&).
- **TaskStep cwd Field**: New optional `cwd` field on `TaskStep` allows TERMINAL steps to specify a working directory. Passed through to `executor.run()` and `executor.run_interactive()`.
- **Self-Healer Filesystem Fixes**: `reflect_and_fix()` now catches common filesystem errors without LLM calls: "Unable to locate package" on .deb/.AppImage/.rpm files (rewrites to dpkg/chmod/rpm), "No such file or directory" (creates parent dir), "Permission denied" (prepends sudo), "Is a directory" on cp (adds -r flag).
- **Planner Examples Expanded**: New examples for AppImage setup (with desktop entry extraction), .deb installation, and archive extraction.

### Audit Round (March 2026)
- **FILE_SEARCH Intelligent Filtering**: Smart noise filter excludes `site-packages`, `.venv`, `node_modules`, `__pycache__` from results. Prefers `fd`/`rg` over `find`/`grep`. Two-tier search with meaningful-result threshold.
- **TUI Slash Commands Fixed**: `/find`, `/read`, `/do` registered as first-class TUI commands. `/search` gracefully handles non-Google providers.
- **Azure Log Noise Eliminated**: Output marker (`===NEXUS_OUTPUT_START===`) separates bootstrap noise from command results. Only meaningful output shown to user.
- **Test Suite Expanded**: 192+ automated tests across 10+ test files covering executor, planner, security, decision engine, audit logger, config manager, session manager, command generator, LLM client, package manager, and orchestrator.
- **Security Hardened**: Shell injection fixed in FILE_SEARCH, `find` command, and AZURE_RUN. LLM-generated commands validated through SafetyCheck. Path traversal protection on `read`. Package name injection prevented. Config file permissions set to 0o600. Browser `disable_security` set to False.
- **Crash Bugs Fixed**: `ImportError` on `nexus read`, `AttributeError` on session save, `NameError` in PLAN fallback, `asyncio` nested loop in browser manager.
- **CI/CD Improved**: Dependency sync between `pyproject.toml` and `requirements.txt`. CI matrix for `[all]` extras. Ruff linting + `pip-audit` security scanning added.
- **API Key Wiring**: `APIKeyRotator` connected to LLM clients. Dummy `api_key="dummy"` replaced with real keys. Graceful browser error messages with setup instructions.

### Earlier Releases
- **Global Search Fallback**: High-performance global filesystem search using `locate` or `find /` when local matches are missing.
- **Ambiguity Handling (CLARIFY)**: Decision Engine detects low-confidence contexts (<0.7) and returns explicit multi-choice clarification options.
- **Interactive Program Handoff**: `run_interactive` cleanly suspends Rich live dashboard for TUI programs (Vim, Nano).
- **Terminal UX Update**: Migration to `prompt_toolkit` with history tracking and streaming.
- **Persistent Sessions**: Context-aware responses that survive restarts; last 24h of history restored on launch.
- **Audit Logging**: Tamper-evident `~/.nexus/audit.log` with `chmod 600`.
- **Self-Healing Execution**: Dual-stage (local heuristic + LLM) auto-fix with 3-attempt retry.
- **Exponential Backoff**: `2^n + jitter` delay between LLM fallback attempts.

---

*Updated: March 2026*
