# asctl - Android Screen Control Tool

中文 | [English](README_EN.md)

黑屏而不锁屏的 Android 屏幕控制工具，基于 scrcpy 实现。

## 功能特性

- ✅ 黑屏而不锁屏：关闭屏幕但保持设备唤醒
- ✅ 保持唤醒：修改系统设置防止设备休眠
- ✅ 简洁高效：只建立控制连接，不处理视频流
- ✅ Termux 友好：纯 Python 实现，适合 Termux 环境
- ✅ 自动化友好：提供 CLI 和 Python API

## 安装

```bash
pip install asctl
```

或从源码安装：

```bash
cd asctl
pip install .
```

## 使用方法

### 命令行使用

```bash
# 关闭屏幕（保持设备唤醒）
asctl --off

# 打开屏幕
asctl --on

# 启用保持唤醒
asctl --stay-awake

# 禁用保持唤醒
asctl --no-stay-awake

# 指定设备（如果有多个设备）
asctl --device <device_id> --off
```

### Python API 使用

```python
from asctl import AndroidScreenControl

# 创建控制器
controller = AndroidScreenControl()

# 关闭屏幕
controller.turn_screen_off()

# 打开屏幕
controller.turn_screen_on()

# 设置保持唤醒
controller.set_stay_awake(True)
```

## 工作原理

asctl 基于 scrcpy 的实现，通过以下步骤实现黑屏而不锁屏：

1. 推送 scrcpy server 到设备
2. 启动 server（只启用控制，关闭视频流）
3. 建立控制 socket 连接
4. 发送 `TYPE_SET_DISPLAY_POWER` 控制消息
5. Server 通过反射调用 `SurfaceControl.setDisplayPowerMode()` 实现屏幕控制

## 快速开始

### 1. 连接设备

**USB 连接：**
```bash
adb devices
```

**网络连接：**
```bash
adb connect <设备IP>:5555
```

### 2. 安装工具
```bash
pip install asctl
```

### 3. 使用
```bash
asctl --off  # 关闭屏幕
asctl --on   # 打开屏幕
```

## 系统要求

- Python 3.6+
- Android 设备（需要 USB 调试）
- ADB 工具

## 注意事项

- 需要设备开启 USB 调试
- 需要设备连接到电脑（USB 或网络）
- 保持唤醒功能会修改系统设置

## 故障排除

### ADB 命令执行失败
- 确认设备已连接：`adb devices`
- 确认 USB 调试已开启
- 尝试重新连接 ADB

### Server 启动失败
- 检查设备存储空间
- 尝试手动推送 server：`adb push asctl/data/scrcpy-server.jar /data/local/tmp/`

### 屏幕控制无效
- 确认设备未锁屏
- 检查设备权限设置
- 查看详细日志：在代码中设置 `log_level=debug`

## 许可证

MIT License

## 参考

- [scrcpy](https://github.com/Genymobile/scrcpy)

