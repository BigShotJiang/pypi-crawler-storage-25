"""
asctl setup.py
"""

from setuptools import setup, find_packages

setup(
    name="asctl",
    version="0.1.0",
    description="Android Screen Control Tool - 黑屏而不锁屏的 Android 屏幕控制工具",
    long_description="基于 scrcpy 的实现，通过控制消息实现黑屏而不锁屏功能，适用于 Termux 环境和自动化脚本",
    author="mofanx",
    author_email="yanwuning@live.cn",
    url="https://github.com/mofanx/asctl",
    packages=find_packages(),
    package_data={
        "asctl": ["data/*"],
    },
    install_requires=[
        # 不需要外部依赖
    ],
    entry_points={
        "console_scripts": [
            "asctl=asctl.cli:main",
        ],
    },
    python_requires=">=3.6",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
