"""
asctl 命令行接口
"""

import argparse
import sys
from asctl.core import AndroidScreenControl


def main():
    """命令行主函数"""
    parser = argparse.ArgumentParser(
        description="asctl - Android Screen Control Tool\n黑屏而不锁屏的 Android 屏幕控制工具",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        "--device", "-d",
        help="设备 ID（如果有多个设备）"
    )
    
    parser.add_argument(
        "--server", "-s",
        help="自定义 scrcpy server 文件路径"
    )
    
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--off",
        action="store_true",
        help="关闭屏幕（保持设备唤醒）"
    )
    group.add_argument(
        "--on",
        action="store_true",
        help="打开屏幕"
    )
    group.add_argument(
        "--stay-awake",
        action="store_true",
        help="启用保持唤醒"
    )
    group.add_argument(
        "--no-stay-awake",
        action="store_true",
        help="禁用保持唤醒"
    )
    
    args = parser.parse_args()
    
    # 如果没有指定操作，显示帮助
    if not any([args.off, args.on, args.stay_awake, args.no_stay_awake]):
        parser.print_help()
        sys.exit(1)
    
    # 创建控制器
    controller = AndroidScreenControl(device_id=args.device, server_path=args.server)
    
    # 执行操作
    if args.off:
        success = controller.turn_screen_off()
        sys.exit(0 if success else 1)
    elif args.on:
        success = controller.turn_screen_on()
        sys.exit(0 if success else 1)
    elif args.stay_awake:
        success = controller.set_stay_awake(True)
        sys.exit(0 if success else 1)
    elif args.no_stay_awake:
        success = controller.set_stay_awake(False)
        sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
