"""
asctl - Android Screen Control Tool
黑屏而不锁屏的 Android 屏幕控制工具
"""

from asctl.core import AndroidScreenControl

__version__ = "0.1.0"
__all__ = ["AndroidScreenControl"]
