"""
asctl 核心功能模块
"""

import os
import struct
import socket
import subprocess
import time
import random
import select
from typing import Optional


# 控制消息类型
TYPE_SET_DISPLAY_POWER = 10  # SC_CONTROL_MSG_TYPE_SET_DISPLAY_POWER

# 屏幕电源模式
POWER_MODE_OFF = 0
POWER_MODE_NORMAL = 1


class AndroidScreenControl:
    """Android 屏幕控制类"""

    def __init__(self, device_id: Optional[str] = None, server_path: Optional[str] = None):
        """
        初始化屏幕控制器

        Args:
            device_id: 设备 ID（如果有多个设备）
            server_path: scrcpy server 文件路径（默认使用包内置的）
        """
        self.device_id = device_id
        if server_path is None:
            # 使用包内置的 scrcpy server (JAR文件)
            self.server_path = os.path.join(os.path.dirname(__file__), "data", "scrcpy-server.jar")
        else:
            self.server_path = server_path
        
        self.device_server_path = "/data/local/tmp/scrcpy-server.jar"
        self.control_socket = None
        self.server_stream = None
        
        # 生成 scid（客户端 ID）
        self.scid = random.randint(0, 0x7FFFFFFF)  # 只使用 31 位

    def _run_adb_command(self, command: str) -> str:
        """
        执行 adb 命令

        Args:
            command: adb 命令

        Returns:
            命令输出
        """
        adb_cmd = f"adb {command}"
        if self.device_id:
            adb_cmd = f"adb -s {self.device_id} {command}"
        
        result = subprocess.run(adb_cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"ADB 命令执行失败: {result.stderr}")
        return result.stdout

    def _start_scrcpy_server(self):
        """启动 scrcpy server（启用视频和控制）"""
        try:
            # 先清理旧的 server 进程
            try:
                self._run_adb_command("shell pkill -f scrcpy")
                time.sleep(0.5)
            except:
                pass
            
            # 推送 server 到设备
            push_output = self._run_adb_command(f"push {self.server_path} {self.device_server_path}")
            print(f"Server 推送输出: {push_output}")
            
            # 设置 server 可执行权限
            chmod_output = self._run_adb_command(f"shell chmod 755 {self.device_server_path}")
            print(f"Server 权限设置: {chmod_output}")
            
            # 验证 server 文件是否存在
            try:
                ls_output = self._run_adb_command(f"shell ls -l {self.device_server_path}")
                print(f"Server 文件验证: {ls_output}")
            except Exception as e:
                print(f"Server 文件验证失败: {e}")
            
            # 启动 server，传递参数（模仿官方scrcpy的完整参数）
            commands = [
                f"CLASSPATH={self.device_server_path}",
                "app_process",
                "/",
                "com.genymobile.scrcpy.Server",
                "3.3.4",  # Scrcpy server version
                f"scid={self.scid:08x}",  # 客户端 ID
                "log_level=debug",  # 使用 debug 级别查看详细日志
                "tunnel_forward=true",  # 启用隧道转发
                "video=false",  # 禁用视频
                "audio=false",  # 禁用音频
                "control=true",  # 启用控制
                "show_touches=false",
                "stay_awake=false",
                "power_off_on_close=false",
                "clipboard_autosync=false",
                "downsize_on_error=true",  # 默认值
                "cleanup=false",  # 不在 server 退出时恢复显示电源
                "power_on=true"  # 默认值
            ]
            shell_command = " ".join(commands)
            adb_cmd = ["adb"] + (["-s", self.device_id] if self.device_id else []) + ["shell", shell_command]
            self.server_stream = subprocess.Popen(
                adb_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # 等待 server 创建 localabstract socket
            time.sleep(1)

            # 检查 server 是否已经异常退出
            if self.server_stream.poll() is not None:
                stdout, stderr = self.server_stream.communicate()
                print(f"Server stdout: {stdout}")
                print(f"Server stderr: {stderr}")
                raise RuntimeError(f"Server 启动失败并退出: {stderr}")
            
            print("Server 启动成功")
        except Exception as e:
            raise RuntimeError(f"启动 scrcpy server 失败: {e}")

    def _init_server_connection(self):
        """初始化 server 连接（遵循 scrcpy 客户端流程）"""
        try:
            # 使用 adb forward 转发端口
            socket_name = f"scrcpy_{self.scid:08x}"
            self._run_adb_command(f"forward tcp:27183 localabstract:{socket_name}")
            print(f"ADB forward 设置成功: {socket_name}")
            
            # 当video=false且audio=false且control=true时，第一个socket就是control_socket
            # 建立第一个 socket 连接
            first_socket = None
            for attempt in range(100):  # 最多尝试 100 次
                try:
                    first_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    first_socket.connect(("127.0.0.1", 27183))
                    
                    # 连接成功后，读取1个字节检测连接（不检查内容）
                    dummy_byte = first_socket.recv(1)
                    if not len(dummy_byte):
                        first_socket.close()
                        print(f"连接检测失败 (尝试 {attempt + 1}/100)")
                        time.sleep(0.1)
                        continue
                    
                    print(f"第一个 socket 连接成功 (尝试 {attempt + 1}/100)")
                    break
                except Exception as e:
                    if first_socket:
                        try:
                            first_socket.close()
                        except:
                            pass
                    print(f"连接失败 (尝试 {attempt + 1}/100): {e}")
                    time.sleep(0.1)
            else:
                raise RuntimeError("无法连接到 scrcpy-server")
            
            # 读取设备名称（64 字节）
            device_name_bytes = first_socket.recv(64)
            if not len(device_name_bytes):
                raise RuntimeError("未接收到设备名称")
            device_name = device_name_bytes.decode("utf-8").rstrip("\x00")
            print(f"设备名称: {device_name}")
            
            # 当video=false且audio=false且control=true时，第一个socket就是control_socket
            # 不需要建立第二个socket，直接使用第一个socket作为控制socket
            self.control_socket = first_socket
            self.control_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            
            print("控制 socket 连接成功")
        except Exception as e:
            raise RuntimeError(f"初始化 server 连接失败: {e}")

    def _send_control_message(self, mode: int) -> bool:
        """发送屏幕控制消息"""
        try:
            # 消息格式: TYPE_SET_DISPLAY_POWER (1 byte) + on (1 byte)
            # on = True 表示打开屏幕，on = False 表示关闭屏幕
            on = (mode == POWER_MODE_NORMAL)
            message = struct.pack(">BB", TYPE_SET_DISPLAY_POWER, int(on))
            
            print(f"发送控制消息: type={TYPE_SET_DISPLAY_POWER}, on={int(on)}, message={message.hex()}")
            
            # 通过 control socket 发送消息
            self.control_socket.sendall(message)
            self._wait_server_log("Device display turned", timeout=2.0)
            
            print("控制消息已发送")
            return True
        except Exception as e:
            print(f"发送控制消息失败: {e}")
            return False

    def _wait_server_log(self, expected: str, timeout: float = 2.0):
        """等待 server 输出指定日志"""
        if not self.server_stream or not self.server_stream.stdout:
            time.sleep(timeout)
            return

        deadline = time.time() + timeout
        while time.time() < deadline:
            ready, _, _ = select.select([self.server_stream.stdout], [], [], 0.1)
            if not ready:
                continue
            line = self.server_stream.stdout.readline()
            if not line:
                continue
            line = line.rstrip()
            print(f"Server 日志: {line}")
            if expected in line:
                return

    def _cleanup(self):
        """清理资源"""
        if self.control_socket:
            try:
                self.control_socket.close()
            except:
                pass
        if self.server_stream:
            try:
                self.server_stream.terminate()
            except:
                pass
        try:
            self._run_adb_command("forward --remove tcp:27183")
        except:
            pass

    def turn_screen_off(self) -> bool:
        """
        关闭屏幕（保持设备唤醒）

        Returns:
            是否成功
        """
        try:
            print("启动 scrcpy server...")
            self._start_scrcpy_server()
            
            print("建立控制连接...")
            self._init_server_connection()
            
            print("发送关闭屏幕消息...")
            result = self._send_control_message(POWER_MODE_OFF)
            
            if result:
                print("屏幕关闭成功")
            
            self._cleanup()
            return result
        except Exception as e:
            print(f"关闭屏幕失败: {e}")
            self._cleanup()
            return False

    def turn_screen_on(self) -> bool:
        """
        打开屏幕

        Returns:
            是否成功
        """
        try:
            print("启动 scrcpy server...")
            self._start_scrcpy_server()
            
            print("建立控制连接...")
            self._init_server_connection()
            
            print("发送打开屏幕消息...")
            result = self._send_control_message(POWER_MODE_NORMAL)
            
            if result:
                print("屏幕打开成功")
            
            self._cleanup()
            return result
        except Exception as e:
            print(f"打开屏幕失败: {e}")
            self._cleanup()
            return False

    def set_stay_awake(self, enable: bool) -> bool:
        """
        设置保持唤醒

        Args:
            enable: 是否启用保持唤醒

        Returns:
            是否成功
        """
        try:
            if enable:
                # 设置为充电时保持唤醒
                value = "7"  # AC + USB + Wireless
            else:
                # 恢复默认值
                value = "0"
            
            self._run_adb_command(f"shell settings put global stay_on_while_plugged_in {value}")
            print(f"保持唤醒设置: {'启用' if enable else '禁用'}")
            return True
        except Exception as e:
            print(f"设置保持唤醒失败: {e}")
            return False
