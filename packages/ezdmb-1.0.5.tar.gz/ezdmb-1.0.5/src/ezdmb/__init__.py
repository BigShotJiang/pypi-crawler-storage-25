__version__ = "1.0.5"

STYLESHEET = """
* {
    border-color: #2b2b2b;
    font-size: 13px;
    alternate-background-color: #3c3f41;
}

QPushButton::pressed {
    background: #303F9F;
    color: #448AFF;
}

QToolButton {
    color: #FFFFFF;
}

QLineEdit[accessibleName="selectedFileEdit"] {
    color: #757575;
}

QScrollArea {
    background: #ffffff;
}

QToolButton {
    background: #303F9F;
    border: 0;
}

QFrame[accessibleName="navHeaderFrame"] {
    background: #303F9F;
}

QLabel[accessibleName="titleBar"] {
    background: #3F51B5;
    color: #FFFFFF;
}

QFrame {
    border: none;
}

QScrollArea {
    color: #bbbbbb;
    background-color: #3c3f41;
    border: none;
    border-top: 1px solid #2b2b2b;
    selection-background-color: #2f65ca;
    selection-color: #bbbbbb;
}

QDialog QScrollArea {
    border-top: none;
    border: none;
}

QPlainTextEdit {
    background-color: #2b2b2b;
    border: none;
    color: #bbbbbb;
    selection-background-color: #2f65ca;
}

QGraphicsView {
    background-color: #3c3f41;
    border-color: #2b2b2b;
    color: #bbbbbb;
}
"""
