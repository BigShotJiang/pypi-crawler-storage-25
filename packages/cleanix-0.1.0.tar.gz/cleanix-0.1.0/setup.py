# setup.py
# --------
# All project metadata is defined in pyproject.toml (PEP 517/518).
# This file exists only for backward compatibility with older tools
# that do not yet support pyproject.toml directly.
#
# Author  : Santhosh M
# Email   : msanthoshme123@gmail.com
# Package : cleanix
# Version : 0.1.0
#
# To install:
#   pip install .
#
# To build for PyPI:
#   python -m build
#   twine upload dist/*

from setuptools import setup

setup()
