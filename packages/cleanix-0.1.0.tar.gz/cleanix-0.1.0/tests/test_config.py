"""
test_config.py
--------------
Tests for CleaningConfig.
"""
from __future__ import annotations

import pytest

from cleanix.config import CleaningConfig


class TestCleaningConfig:
    def test_default_config(self):
        config = CleaningConfig()
        assert config.missing_drop_threshold == 0.50
        assert config.numeric_conversion_threshold == 0.80
        assert config.outlier_iqr_factor == 1.5
        assert config.enable_duplicates is True

    def test_custom_config(self):
        config = CleaningConfig(
            missing_drop_threshold=0.3,
            numeric_conversion_threshold=0.9,
            outlier_iqr_factor=2.0,
            enable_outliers=False,
        )
        assert config.missing_drop_threshold == 0.3
        assert config.numeric_conversion_threshold == 0.9
        assert config.outlier_iqr_factor == 2.0
        assert config.enable_outliers is False

    def test_invalid_missing_threshold(self):
        with pytest.raises(ValueError, match="missing_drop_threshold"):
            CleaningConfig(missing_drop_threshold=1.5)
        with pytest.raises(ValueError, match="missing_drop_threshold"):
            CleaningConfig(missing_drop_threshold=-0.1)

    def test_invalid_numeric_threshold(self):
        with pytest.raises(ValueError, match="numeric_conversion_threshold"):
            CleaningConfig(numeric_conversion_threshold=1.5)

    def test_invalid_outlier_factor(self):
        with pytest.raises(ValueError, match="outlier_iqr_factor"):
            CleaningConfig(outlier_iqr_factor=0)
        with pytest.raises(ValueError, match="outlier_iqr_factor"):
            CleaningConfig(outlier_iqr_factor=-1.5)

    def test_invalid_min_rows(self):
        with pytest.raises(ValueError, match="outlier_min_rows"):
            CleaningConfig(outlier_min_rows=0)
        with pytest.raises(ValueError, match="category_min_rows"):
            CleaningConfig(category_min_rows=0)
