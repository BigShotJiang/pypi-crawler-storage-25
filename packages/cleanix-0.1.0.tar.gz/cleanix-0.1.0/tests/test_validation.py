"""
test_validation.py
------------------
Tests for Cleanix validation utilities.
"""
from __future__ import annotations

import pandas as pd
import pytest

from cleanix.exceptions import MemoryLimitError, ValidationError
from cleanix.validation import (
    check_memory_usage,
    get_dataframe_info,
    validate_column_names,
    validate_dataframe,
)


class TestValidateDataFrame:
    def test_valid_dataframe(self):
        df = pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
        validate_dataframe(df)  # should not raise

    def test_invalid_input_type(self):
        with pytest.raises(ValidationError, match="Expected a pandas DataFrame"):
            validate_dataframe([1, 2, 3])

    def test_empty_columns(self):
        with pytest.raises(ValidationError, match="no columns"):
            validate_dataframe(pd.DataFrame(), allow_empty=False)

    def test_empty_rows(self):
        with pytest.raises(ValidationError, match="no rows"):
            validate_dataframe(pd.DataFrame(columns=["a", "b"]), allow_empty=False)

    def test_allow_empty(self):
        validate_dataframe(pd.DataFrame(), allow_empty=True)  # should not raise


class TestValidateColumnNames:
    def test_valid_column_names(self):
        df = pd.DataFrame({"name": ["Alice"], "age": [25]})
        validate_column_names(df)  # should not raise

    def test_duplicate_column_names(self):
        df = pd.DataFrame([[1, 2, 3]], columns=["a", "b", "a"])
        with pytest.raises(ValidationError, match="duplicate column names"):
            validate_column_names(df)

    def test_empty_column_names(self):
        df = pd.DataFrame([[1, 2]], columns=["a", ""])
        with pytest.raises(ValidationError, match="empty column names"):
            validate_column_names(df)


class TestCheckMemoryUsage:
    def test_no_limit(self):
        df = pd.DataFrame({"a": range(1000)})
        check_memory_usage(df, max_memory_mb=None)  # should not raise

    def test_under_limit(self):
        df = pd.DataFrame({"a": [1, 2, 3]})
        check_memory_usage(df, max_memory_mb=100)  # should not raise

    def test_over_limit(self):
        df = pd.DataFrame({"a": range(10000), "b": range(10000)})
        with pytest.raises(MemoryLimitError, match="memory usage"):
            check_memory_usage(df, max_memory_mb=0.001)


class TestGetDataFrameInfo:
    def test_basic_info(self):
        df = pd.DataFrame({"a": [1, 2, None], "b": ["x", "y", "z"]})
        info = get_dataframe_info(df)
        assert info["shape"] == (3, 2)
        assert "memory_mb" in info
        assert info["missing_cells"] == 1

    def test_empty_dataframe_info(self):
        df = pd.DataFrame()
        info = get_dataframe_info(df)
        assert info["shape"] == (0, 0)
        assert info["missing_cells"] == 0
