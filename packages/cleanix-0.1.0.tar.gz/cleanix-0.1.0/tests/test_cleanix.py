"""
test_cleanix.py
---------------
Comprehensive test suite for the Cleanix library.

Run with:
    pytest tests/ -v
"""
from __future__ import annotations

import json
import math

import pandas as pd
import pytest

from cleanix import (
    CleaningConfig,
    Report,
    clean,
    profile_data,
    suggest_cleaning,
)
from cleanix.datatypes import fix_datatypes
from cleanix.duplicates import remove_duplicates
from cleanix.exceptions import CleaningError, ValidationError
from cleanix.missing import handle_missing
from cleanix.outliers import handle_outliers


# ═══════════════════════════════════════════════════════════════════════════════
# Report
# ═══════════════════════════════════════════════════════════════════════════════

class TestReport:
    def test_empty_summary(self):
        r = Report()
        assert "No cleaning actions" in r.summary()

    def test_add_and_summary(self):
        r = Report()
        r.add("duplicates", None, "remove_duplicates", "Removed 5 duplicate rows", 5)
        summary = r.summary()
        assert "5" in summary
        assert "Duplicates" in summary

    def test_summary_contains_cleanix(self):
        r = Report()
        r.add("missing", "age", "fill_median", "Filled with median 30", 3)
        assert "Cleanix" in r.summary()

    def test_to_dict_structure(self):
        r = Report()
        r.add("missing", "age", "fill_median", "Filled with median 30", 3)
        d = r.to_dict()
        assert d["total_actions"] == 1
        assert d["actions"][0]["column"] == "age"

    def test_to_json_valid(self):
        r = Report()
        r.add("outliers", "salary", "clip_outliers", "Capped 2 outliers", 2)
        parsed = json.loads(r.to_json())
        assert parsed["total_actions"] == 1


# ═══════════════════════════════════════════════════════════════════════════════
# remove_duplicates
# ═══════════════════════════════════════════════════════════════════════════════

class TestRemoveDuplicates:
    def test_removes_exact_duplicates(self, fresh_report, default_config):
        df = pd.DataFrame({"a": [1, 1, 2], "b": ["x", "x", "y"]})
        result = remove_duplicates(df, fresh_report, default_config)
        assert len(result) == 2
        assert fresh_report.actions[0]["rows_affected"] == 1

    def test_no_duplicates(self, fresh_report, default_config):
        df = pd.DataFrame({"a": [1, 2, 3]})
        result = remove_duplicates(df, fresh_report, default_config)
        assert len(result) == 3
        assert len(fresh_report.actions) == 0

    def test_original_not_mutated(self, fresh_report, default_config):
        df = pd.DataFrame({"a": [1, 1, 2]})
        remove_duplicates(df, fresh_report, default_config)
        assert len(df) == 3  # original intact

    def test_index_reset(self, fresh_report, default_config):
        df = pd.DataFrame({"a": [1, 1, 2]}, index=[5, 6, 7])
        result = remove_duplicates(df, fresh_report, default_config)
        assert list(result.index) == [0, 1]

    def test_empty_dataframe(self, fresh_report, default_config):
        result = remove_duplicates(pd.DataFrame(), fresh_report, default_config)
        assert result.empty


# ═══════════════════════════════════════════════════════════════════════════════
# handle_missing
# ═══════════════════════════════════════════════════════════════════════════════

class TestHandleMissing:
    def test_numeric_filled_with_median(self, fresh_report, default_config):
        df = pd.DataFrame({"x": [1.0, 2.0, None, 4.0]})
        result = handle_missing(df, fresh_report, default_config)
        assert result["x"].isna().sum() == 0
        assert result["x"].iloc[2] == 2.0

    def test_categorical_filled_with_mode(self, fresh_report, default_config):
        df = pd.DataFrame({"cat": ["a", "a", "b", None]})
        result = handle_missing(df, fresh_report, default_config)
        assert result["cat"].isna().sum() == 0
        assert result["cat"].iloc[3] == "a"

    def test_column_dropped_over_threshold(self, fresh_report, default_config):
        df = pd.DataFrame({"a": [1, 2, 3, 4], "b": [None, None, None, 1]})
        result = handle_missing(df, fresh_report, default_config)
        assert "b" not in result.columns

    def test_custom_threshold(self, fresh_report):
        config = CleaningConfig(missing_drop_threshold=0.3)
        df = pd.DataFrame({"a": [1, 2, 3], "b": [None, 1, 2]})  # 33% missing
        result = handle_missing(df, fresh_report, config)
        assert "b" not in result.columns

    def test_all_nan_column_dropped(self, fresh_report, default_config):
        df = pd.DataFrame({"x": [None, None, None]})
        result = handle_missing(df, fresh_report, default_config)
        assert "x" not in result.columns

    def test_original_not_mutated(self, fresh_report, default_config):
        # handle_missing operates on the df passed to it (copy is made in cleaner.py).
        # Verify the full pipeline does not mutate the caller's DataFrame.
        df = pd.DataFrame({"x": [1.0, None, 3.0]})
        from cleanix import clean
        original_missing = df["x"].isna().sum()
        clean(df)
        assert df["x"].isna().sum() == original_missing

    def test_no_missing(self, fresh_report, default_config):
        df = pd.DataFrame({"x": [1, 2, 3]})
        result = handle_missing(df, fresh_report, default_config)
        assert len(fresh_report.actions) == 0
        pd.testing.assert_frame_equal(result, df)


# ═══════════════════════════════════════════════════════════════════════════════
# fix_datatypes
# ═══════════════════════════════════════════════════════════════════════════════

class TestFixDatatypes:
    def test_object_to_numeric(self, fresh_report, default_config):
        df = pd.DataFrame({"salary": ["100", "200", "300", "400", "500"]})
        result = fix_datatypes(df, fresh_report, default_config)
        assert pd.api.types.is_numeric_dtype(result["salary"])

    def test_object_to_datetime(self, fresh_report, default_config):
        df = pd.DataFrame({
            "dt": ["2021-01-01", "2021-06-15", "2022-03-10", "2020-11-30", "2019-08-19"]
        })
        result = fix_datatypes(df, fresh_report, default_config)
        assert pd.api.types.is_datetime64_any_dtype(result["dt"])

    def test_low_cardinality_to_category(self, fresh_report, default_config):
        df = pd.DataFrame({"status": ["active", "inactive"] * 50})
        result = fix_datatypes(df, fresh_report, default_config)
        assert result["status"].dtype.name == "category"

    def test_skip_non_object_columns(self, fresh_report, default_config):
        df = pd.DataFrame({"x": [1, 2, 3], "y": [1.0, 2.0, 3.0]})
        fix_datatypes(df, fresh_report, default_config)
        assert len(fresh_report.actions) == 0

    def test_original_not_mutated(self, fresh_report, default_config):
        # fix_datatypes operates on the df passed to it (copy is made in cleaner.py).
        # Verify the full pipeline does not mutate the caller's DataFrame.
        df = pd.DataFrame({"salary": ["100", "200", "300", "400", "500"]})
        from cleanix import clean
        original_dtype = df["salary"].dtype
        clean(df)
        assert df["salary"].dtype == original_dtype


# ═══════════════════════════════════════════════════════════════════════════════
# handle_outliers
# ═══════════════════════════════════════════════════════════════════════════════

class TestHandleOutliers:
    def _df_with_outlier(self):
        return pd.DataFrame({"x": list(range(1, 15)) + [1000]})

    def test_outlier_capped(self, fresh_report, default_config):
        df = self._df_with_outlier()
        result = handle_outliers(df, fresh_report, default_config)
        assert result["x"].max() < 1000
        assert fresh_report.actions[0]["rows_affected"] >= 1

    def test_skipped_on_small_dataset(self, fresh_report, default_config):
        df = pd.DataFrame({"x": [1, 2, 1000, 3, 4]})  # 5 rows < 10
        result = handle_outliers(df, fresh_report, default_config)
        assert result["x"].max() == 1000
        assert len(fresh_report.actions) == 0

    def test_no_outliers(self, fresh_report, default_config):
        df = pd.DataFrame({"x": list(range(20))})
        handle_outliers(df, fresh_report, default_config)
        assert len(fresh_report.actions) == 0

    def test_original_not_mutated(self, fresh_report, default_config):
        # handle_outliers operates on the df passed to it (copy is made in cleaner.py).
        # Verify the full pipeline does not mutate the caller's DataFrame.
        df = self._df_with_outlier()
        from cleanix import clean
        original_max = df["x"].max()
        clean(df)
        assert df["x"].max() == original_max

    def test_zero_iqr_skipped(self, fresh_report, default_config):
        df = pd.DataFrame({"x": [5] * 20})
        handle_outliers(df, fresh_report, default_config)
        assert len(fresh_report.actions) == 0


# ═══════════════════════════════════════════════════════════════════════════════
# profile_data
# ═══════════════════════════════════════════════════════════════════════════════

class TestProfileData:
    def test_basic_profile(self):
        df = pd.DataFrame({"a": [1, 2, None], "b": ["x", "y", "x"]})
        profile = profile_data(df)
        assert set(profile.keys()) == {"a", "b"}
        assert profile["a"]["missing_count"] == 1
        assert math.isclose(profile["a"]["missing_pct"], 1 / 3, rel_tol=1e-3)
        assert profile["b"]["unique_count"] == 2

    def test_sample_values_limit(self):
        df = pd.DataFrame({"x": list(range(100))})
        assert len(profile_data(df)["x"]["sample_values"]) <= 5

    def test_empty_dataframe(self):
        assert profile_data(pd.DataFrame()) == {}


# ═══════════════════════════════════════════════════════════════════════════════
# suggest_cleaning
# ═══════════════════════════════════════════════════════════════════════════════

class TestSuggestCleaning:
    def test_detects_duplicates(self):
        df = pd.DataFrame({"a": [1, 1, 2], "b": ["x", "x", "y"]})
        issues = [s["issue"] for s in suggest_cleaning(df)]
        assert "duplicates" in issues

    def test_detects_missing(self):
        df = pd.DataFrame({"a": [1, None, 3, 4, 5]})
        issues = [s["issue"] for s in suggest_cleaning(df)]
        assert "fill_missing" in issues

    def test_detects_drop_column(self):
        df = pd.DataFrame({"a": [1, 2, 3], "b": [None, None, 1]})
        issues = [s["issue"] for s in suggest_cleaning(df)]
        assert "drop_column" in issues

    def test_detects_numeric_conversion(self):
        df = pd.DataFrame({"salary": ["100", "200", "300", "400", "500"]})
        issues = [s["issue"] for s in suggest_cleaning(df)]
        assert "convert_numeric" in issues

    def test_priority_ordering(self):
        df = pd.DataFrame({"a": [1, 1, 2], "b": [None, None, 1]})
        priorities = [s["priority"] for s in suggest_cleaning(df)]
        order = {"high": 0, "medium": 1, "low": 2}
        assert priorities == sorted(priorities, key=lambda p: order[p])

    def test_empty_dataframe(self):
        suggestions = suggest_cleaning(pd.DataFrame())
        assert suggestions[0]["issue"] == "empty_dataframe"

    def test_custom_config(self):
        config = CleaningConfig(missing_drop_threshold=0.3)
        df = pd.DataFrame({"a": [1, 2, 3], "b": [None, 1, 2]})
        issues = [s["issue"] for s in suggest_cleaning(df, config)]
        assert "drop_column" in issues


# ═══════════════════════════════════════════════════════════════════════════════
# clean() — Integration Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestClean:
    def test_returns_tuple(self, sample_messy_df):
        result = clean(sample_messy_df)
        assert isinstance(result, tuple) and len(result) == 2

    def test_returns_dataframe_and_report(self, sample_messy_df):
        cleaned, report = clean(sample_messy_df)
        assert isinstance(cleaned, pd.DataFrame)
        assert isinstance(report, Report)

    def test_original_not_mutated(self, sample_messy_df):
        original_shape = sample_messy_df.shape
        clean(sample_messy_df)
        assert sample_messy_df.shape == original_shape

    def test_all_nan_column_removed(self, sample_messy_df):
        cleaned, _ = clean(sample_messy_df)
        assert "notes" not in cleaned.columns

    def test_no_missing_values_remain(self, sample_messy_df):
        cleaned, _ = clean(sample_messy_df)
        assert cleaned.isna().sum().sum() == 0

    def test_salary_converted_to_numeric(self, sample_messy_df):
        cleaned, _ = clean(sample_messy_df)
        assert pd.api.types.is_numeric_dtype(cleaned["salary"])

    def test_join_date_converted_to_datetime(self, sample_messy_df):
        cleaned, _ = clean(sample_messy_df)
        assert pd.api.types.is_datetime64_any_dtype(cleaned["join_date"])

    def test_report_has_actions(self, sample_messy_df):
        _, report = clean(sample_messy_df)
        assert len(report.actions) > 0

    def test_report_to_json_valid(self, sample_messy_df):
        _, report = clean(sample_messy_df)
        parsed = json.loads(report.to_json())
        assert "actions" in parsed

    def test_custom_config(self, sample_messy_df, custom_config):
        cleaned, report = clean(sample_messy_df, custom_config)
        assert isinstance(cleaned, pd.DataFrame)

    def test_disabled_stages(self, sample_messy_df):
        config = CleaningConfig(enable_duplicates=False, enable_outliers=False)
        cleaned, report = clean(sample_messy_df, config)
        assert len(cleaned) == len(sample_messy_df)
        stages = [a["stage"] for a in report.actions]
        assert "duplicates" not in stages
        assert "outliers" not in stages

    def test_validation_error_on_non_dataframe(self):
        with pytest.raises(ValidationError):
            clean([1, 2, 3])

    def test_validation_error_on_empty_dataframe(self):
        with pytest.raises(ValidationError):
            clean(pd.DataFrame())

    def test_already_clean_dataframe(self, clean_df):
        cleaned, report = clean(clean_df)
        assert cleaned.shape == clean_df.shape

    def test_memory_limit_raises(self, sample_messy_df):
        config = CleaningConfig(max_memory_mb=0.001)
        with pytest.raises(Exception):
            clean(sample_messy_df, config)


# ═══════════════════════════════════════════════════════════════════════════════
# Edge Cases
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeCases:
    def test_single_row(self):
        df = pd.DataFrame({"a": [1], "b": ["x"]})
        cleaned, _ = clean(df)
        assert cleaned.shape == (1, 2)

    def test_single_column(self):
        df = pd.DataFrame({"a": [1, 2, 3, 4, 5]})
        cleaned, _ = clean(df)
        assert cleaned.shape[1] == 1

    def test_all_missing_columns_dropped(self):
        df = pd.DataFrame({"a": [None, None], "b": [None, None]})
        cleaned, _ = clean(df)
        assert cleaned.shape[1] == 0

    def test_unicode_column_names(self):
        df = pd.DataFrame({"名前": ["Alice", "Bob"], "年齢": [25, 30]})
        cleaned, _ = clean(df)
        assert "名前" in cleaned.columns
        assert "年齢" in cleaned.columns

    def test_large_numbers(self):
        df = pd.DataFrame({"big": [1e10, 2e10, 3e10, 1e15, 4e10] * 3})
        cleaned, _ = clean(df)
        assert "big" in cleaned.columns
