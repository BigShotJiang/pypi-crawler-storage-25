"""
profiler.py
-----------
Lightweight per-column profiling for Cleanix — no side effects, no mutations.
"""
from __future__ import annotations

from typing import Any

import pandas as pd

def profile_data(df: pd.DataFrame) -> dict[str, dict[str, Any]]:
    """
    Compute a concise profile for every column in *df*.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to profile.

    Returns
    -------
    dict[str, dict[str, Any]]
        A dict keyed by column name. Each value contains:

        {
            "dtype"         : str,       # pandas dtype string
            "missing_count" : int,       # absolute count of NaN/NaT
            "missing_pct"   : float,     # 0.0 – 1.0
            "unique_count"  : int,       # number of distinct non-null values
            "sample_values" : list[Any], # up to 5 representative values
        }

    Examples
    --------
    >>> import pandas as pd
    >>> from cleanix import profile_data
    >>> df = pd.DataFrame({"age": [25, 30, None], "name": ["Alice", "Bob", "Charlie"]})
    >>> for col, info in profile_data(df).items():
    ...     print(col, info["missing_pct"])
    """
    if df.empty:
        return {}

    n_rows = len(df)
    profile: dict[str, dict[str, Any]] = {}

    for col in df.columns:
        series = df[col]
        missing_count = int(series.isna().sum())
        non_null = series.dropna()

        profile[col] = {
            "dtype": str(series.dtype),
            "missing_count": missing_count,
            "missing_pct": (missing_count / n_rows) if n_rows else 0.0,
            "unique_count": int(non_null.nunique()),
            "sample_values": non_null.head(5).tolist(),
        }

    return profile
