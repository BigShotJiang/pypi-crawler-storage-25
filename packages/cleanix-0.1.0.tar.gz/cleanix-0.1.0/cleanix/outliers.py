"""
outliers.py
-----------
IQR-based outlier capping for numeric columns in Cleanix.

Strategy:
  - Compute Q1, Q3, IQR per column.
  - Lower fence = Q1 − outlier_iqr_factor × IQR
  - Upper fence = Q3 + outlier_iqr_factor × IQR
  - Values outside fences are CLIPPED (capped), not dropped.
  - Skipped when:
      • DataFrame has fewer than outlier_min_rows rows.
      • Column has no variance (IQR == 0).
"""
from __future__ import annotations

import logging

import pandas as pd

from .config import CleaningConfig
from .report import Report

logger = logging.getLogger(__name__)


def handle_outliers(
    df: pd.DataFrame, report: Report, config: CleaningConfig
) -> pd.DataFrame:
    """
    Cap outliers in all numeric columns using the IQR method.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame (will NOT be mutated in-place).
    report : Report
        Report instance — actions are appended.
    config : CleaningConfig
        Configuration with outlier_iqr_factor and outlier_min_rows.

    Returns
    -------
    pd.DataFrame
        DataFrame with outliers capped.
    """
    if df.empty:
        logger.warning("handle_outliers received an empty DataFrame; skipping.")
        return df

    if len(df) < config.outlier_min_rows:
        logger.debug(
            "handle_outliers: dataset has %d rows (< %d); skipping.",
            len(df), config.outlier_min_rows,
        )
        return df

    numeric_cols = df.select_dtypes(include="number").columns.tolist()

    for col in numeric_cols:
        series = df[col].dropna()

        if series.empty:
            continue

        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr = q3 - q1

        if iqr == 0:
            logger.debug("Column '%s': IQR == 0, skipping outlier handling.", col)
            continue

        lower = q1 - config.outlier_iqr_factor * iqr
        upper = q3 + config.outlier_iqr_factor * iqr

        # Count outliers on the non-null series to avoid NaN comparison issues
        n_outliers = int(((series < lower) | (series > upper)).sum())

        if n_outliers == 0:
            continue

        df[col] = df[col].clip(lower=lower, upper=upper)

        report.add(
            stage="outliers",
            column=col,
            action="clip_outliers",
            detail=(
                f"Capped {n_outliers:,} outlier(s) to "
                f"[{lower:.4g}, {upper:.4g}] (IQR method)"
            ),
            rows_affected=n_outliers,
        )
        logger.debug(
            "Column '%s': capped %d outlier(s) to [%.4g, %.4g].",
            col, n_outliers, lower, upper,
        )

    return df
