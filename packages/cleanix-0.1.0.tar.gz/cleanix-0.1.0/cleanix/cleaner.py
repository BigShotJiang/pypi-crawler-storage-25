"""
cleaner.py
----------
Orchestrates the full Cleanix cleaning pipeline.

Usage
-----
    from cleanix import clean

    cleaned_df, report = clean(df)
    print(report.summary())
"""
from __future__ import annotations

import logging
from typing import Optional, Tuple

import pandas as pd

from .config import CleaningConfig, DEFAULT_CONFIG
from .datatypes import fix_datatypes
from .duplicates import remove_duplicates
from .exceptions import CleaningError
from .missing import handle_missing
from .outliers import handle_outliers
from .report import Report
from .validation import (
    check_memory_usage,
    get_dataframe_info,
    validate_column_names,
    validate_dataframe,
)

logger = logging.getLogger(__name__)


def clean(
    df: pd.DataFrame,
    config: Optional[CleaningConfig] = None,
) -> Tuple[pd.DataFrame, Report]:
    """
    Run the full Cleanix pipeline on *df*.

    Pipeline order
    --------------
    1. remove_duplicates  — exact row deduplication
    2. handle_missing     — impute or drop columns with NaNs
    3. fix_datatypes      — coerce object columns to better dtypes
    4. handle_outliers    — IQR-based capping on numeric columns

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to clean. The original is **never** mutated;
        a clean copy is returned alongside the Report.
    config : Optional[CleaningConfig]
        Configuration object to customize cleaning behavior.
        If None, uses DEFAULT_CONFIG.

    Returns
    -------
    cleaned_df : pd.DataFrame
        The fully cleaned DataFrame.
    report : Report
        A Report object exposing `summary()`, `to_dict()`, `to_json()`.

    Raises
    ------
    ValidationError
        If input validation fails.
    CleaningError
        If a cleaning stage fails.
    MemoryLimitError
        If memory limits are exceeded.

    Examples
    --------
    >>> import pandas as pd
    >>> from cleanix import clean
    >>> df = pd.DataFrame({"age": [25, None, 30], "name": ["Alice", "Bob", "Charlie"]})
    >>> cleaned_df, report = clean(df)
    >>> print(report.summary())
    """
    if config is None:
        config = DEFAULT_CONFIG

    # Validate input
    validate_dataframe(df, allow_empty=False)
    validate_column_names(df)
    check_memory_usage(df, config.max_memory_mb)

    report = Report()
    original_shape = df.shape
    df_info = get_dataframe_info(df)

    if config.verbose:
        logger.info(
            "Cleanix starting — input shape: %d rows × %d cols, %.2f MB.",
            *original_shape,
            df_info["memory_mb"],
        )
    else:
        logger.info(
            "Cleanix starting — input shape: %d rows × %d cols.",
            *original_shape,
        )

    # Single copy at the start — no redundant copies inside each stage
    df = df.copy()

    try:
        # ── Stage 1 — Duplicates ───────────────────────────────────────────
        if config.enable_duplicates:
            df = remove_duplicates(df, report, config)
            logger.debug("After dedup: %d rows.", len(df))

        # ── Stage 2 — Missing values ───────────────────────────────────────
        if config.enable_missing:
            df = handle_missing(df, report, config)
            logger.debug("After missing-value handling: shape %s.", df.shape)

        # ── Stage 3 — Data types ───────────────────────────────────────────
        if config.enable_datatypes:
            df = fix_datatypes(df, report, config)
            logger.debug("After dtype coercion: dtypes updated.")

        # ── Stage 4 — Outliers ─────────────────────────────────────────────
        if config.enable_outliers:
            df = handle_outliers(df, report, config)
            logger.debug("After outlier capping: pipeline complete.")

    except Exception as e:
        logger.error("Cleanix pipeline failed: %s", e)
        raise CleaningError(f"Cleaning pipeline failed: {e}") from e

    logger.info(
        "Cleanix done — output shape: %d rows × %d cols. Actions taken: %d.",
        *df.shape,
        len(report.actions),
    )

    return df, report
