"""
duplicates.py
-------------
Remove exact duplicate rows and report the count removed.
"""
from __future__ import annotations

import logging

import pandas as pd

from .config import CleaningConfig
from .report import Report

logger = logging.getLogger(__name__)


def remove_duplicates(
    df: pd.DataFrame, report: Report, config: CleaningConfig
) -> pd.DataFrame:
    """
    Drop fully duplicate rows, keeping the first occurrence.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame (will NOT be mutated in-place).
    report : Report
        Report instance — action is appended if duplicates exist.
    config : CleaningConfig
        Configuration object.

    Returns
    -------
    pd.DataFrame
        DataFrame with duplicate rows removed and index reset.
    """
    if df.empty:
        logger.warning("remove_duplicates received an empty DataFrame; skipping.")
        return df

    n_before = len(df)
    df = df.drop_duplicates(keep="first").reset_index(drop=True)
    n_removed = n_before - len(df)

    if n_removed > 0:
        report.add(
            stage="duplicates",
            column=None,
            action="remove_duplicates",
            detail=f"Removed {n_removed:,} duplicate row(s) (kept first occurrence)",
            rows_affected=n_removed,
        )
        logger.debug("Removed %d duplicate row(s).", n_removed)
    else:
        logger.debug("No duplicate rows found.")

    return df
