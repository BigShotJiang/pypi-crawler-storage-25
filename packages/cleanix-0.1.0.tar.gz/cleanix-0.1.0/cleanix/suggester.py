"""
suggester.py
------------
Inspects a DataFrame and returns human-readable suggestions
*before* any cleaning is applied.
"""
from __future__ import annotations

import warnings
from typing import Any, Optional

import pandas as pd

from .config import CleaningConfig, DEFAULT_CONFIG
from .profiler import profile_data


def suggest_cleaning(
    df: pd.DataFrame,
    config: Optional[CleaningConfig] = None,
) -> list[dict[str, Any]]:
    """
    Analyse *df* and return a list of suggested cleaning actions.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to analyze.
    config : Optional[CleaningConfig]
        Configuration object with thresholds. If None, uses DEFAULT_CONFIG.

    Returns
    -------
    list[dict[str, Any]]
        Each suggestion is a dict with keys:
            column   : str | None
            issue    : str          — short machine-readable tag
            message  : str          — human-readable explanation
            priority : "high" | "medium" | "low"

        Sorted high → medium → low priority.

    Examples
    --------
    >>> import pandas as pd
    >>> from cleanix import suggest_cleaning
    >>> df = pd.DataFrame({"age": [25, None, 30], "salary": ["50k", "60k", "55k"]})
    >>> for s in suggest_cleaning(df):
    ...     print(f"[{s['priority']}] {s['message']}")
    """
    if config is None:
        config = DEFAULT_CONFIG

    if df.empty:
        return [
            {
                "column": None,
                "issue": "empty_dataframe",
                "message": "The DataFrame is empty — nothing to clean.",
                "priority": "high",
            }
        ]

    suggestions: list[dict[str, Any]] = []
    profile = profile_data(df)
    n_rows = len(df)

    n_dupes = int(df.duplicated().sum())
    if n_dupes > 0:
        suggestions.append(
            {
                "column": None,
                "issue": "duplicates",
                "message": (
                    f"Found {n_dupes:,} duplicate row(s). "
                    "Suggest removing them (keep first occurrence)."
                ),
                "priority": "high",
            }
        )

    for col, info in profile.items():
        dtype = info["dtype"]
        missing_pct = info["missing_pct"]
        unique_count = info["unique_count"]

        if missing_pct >= config.missing_drop_threshold:
            suggestions.append(
                {
                    "column": col,
                    "issue": "drop_column",
                    "message": (
                        f"'{col}' has {missing_pct:.0%} missing values — recommend dropping."
                    ),
                    "priority": "high",
                }
            )
        elif missing_pct > 0:
            strategy = "median" if pd.api.types.is_numeric_dtype(df[col]) else "mode"
            suggestions.append(
                {
                    "column": col,
                    "issue": "fill_missing",
                    "message": (
                        f"'{col}' has {missing_pct:.1%} missing values — "
                        f"recommend filling with {strategy}."
                    ),
                    "priority": "medium",
                }
            )

        if dtype in ("object", "str") or dtype.startswith("string"):
            non_null = df[col].dropna()
            if not non_null.empty:
                numeric_ratio = (
                    pd.to_numeric(non_null, errors="coerce").notna().sum()
                    / len(non_null)
                )
                if numeric_ratio >= config.numeric_conversion_threshold:
                    suggestions.append(
                        {
                            "column": col,
                            "issue": "convert_numeric",
                            "message": (
                                f"'{col}' appears numeric ({numeric_ratio:.0%} parseable) "
                                "but is stored as object — recommend converting."
                            ),
                            "priority": "high",
                        }
                    )
                    continue

                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", UserWarning)
                        dt_ratio = (
                            pd.to_datetime(non_null, errors="coerce")
                            .notna()
                            .sum()
                            / len(non_null)
                        )
                except (ValueError, TypeError, OverflowError):
                    dt_ratio = 0.0

                if dt_ratio >= config.datetime_conversion_threshold:
                    suggestions.append(
                        {
                            "column": col,
                            "issue": "convert_datetime",
                            "message": (
                                f"'{col}' appears to contain dates ({dt_ratio:.0%} parseable) "
                                "— recommend converting to datetime."
                            ),
                            "priority": "medium",
                        }
                    )
                    continue

                if (
                    n_rows >= config.category_min_rows
                    and unique_count >= 2
                    and (unique_count / n_rows) <= config.category_unique_ratio
                ):
                    suggestions.append(
                        {
                            "column": col,
                            "issue": "convert_category",
                            "message": (
                                f"'{col}' has only {unique_count} unique values "
                                f"({unique_count / n_rows:.1%} cardinality) "
                                "— recommend converting to category dtype."
                            ),
                            "priority": "low",
                        }
                    )

      
        if (
            pd.api.types.is_numeric_dtype(df[col])
            and n_rows >= config.outlier_min_rows
        ):
            series = df[col].dropna()
            if not series.empty:
                q1 = series.quantile(0.25)
                q3 = series.quantile(0.75)
                iqr = q3 - q1
                if iqr > 0:
                    lower = q1 - config.outlier_iqr_factor * iqr
                    upper = q3 + config.outlier_iqr_factor * iqr
                    n_out = int(((series < lower) | (series > upper)).sum())
                    if n_out > 0:
                        suggestions.append(
                            {
                                "column": col,
                                "issue": "handle_outliers",
                                "message": (
                                    f"'{col}' has {n_out:,} outlier(s) outside "
                                    f"[{lower:.4g}, {upper:.4g}] (IQR fences) "
                                    "— recommend capping."
                                ),
                                "priority": "medium",
                            }
                        )

    priority_order = {"high": 0, "medium": 1, "low": 2}
    suggestions.sort(key=lambda s: priority_order.get(s["priority"], 9))
    return suggestions
