"""
exceptions.py
-------------
Custom exceptions for the Cleanix library.
"""
from __future__ import annotations


class CleanixError(Exception):
    """Base exception for all Cleanix errors."""
    pass


class ValidationError(CleanixError):
    """Raised when input validation fails."""
    pass


class ConfigurationError(CleanixError):
    """Raised when configuration is invalid."""
    pass


class CleaningError(CleanixError):
    """Raised when a cleaning operation fails."""
    pass


class MemoryLimitError(CleanixError):
    """Raised when memory limits are exceeded."""
    pass
