"""
datatypes.py
------------
Intelligent dtype coercion for object columns in Cleanix.

Strategy (applied in order per column):
  1. Numeric   — if >= numeric_conversion_threshold of non-null values parse as numbers
  2. Datetime  — if >= datetime_conversion_threshold of non-null values parse as dates
  3. Category  — if unique ratio <= category_unique_ratio (and at least 2 unique values)
"""
from __future__ import annotations
import logging
import warnings

import pandas as pd
from .config import CleaningConfig
from .report import Report

logger = logging.getLogger(__name__)


def fix_datatypes(
    df: pd.DataFrame, report: Report, config: CleaningConfig
) -> pd.DataFrame:
    """
    Attempt smart dtype coercions on object/string columns.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame (will NOT be mutated in-place).
    report : Report
        Report instance — actions are appended.
    config : CleaningConfig
        Configuration with conversion thresholds.

    Returns
    -------
    pd.DataFrame
        DataFrame with improved dtypes.
    """
    if df.empty:
        logger.warning("fix_datatypes received an empty DataFrame; skipping.")
        return df

    for col in df.columns:
        col_dtype = df[col].dtype
        is_string_like = col_dtype == object or isinstance(col_dtype, pd.StringDtype)
        if not is_string_like:
            continue  

        original_dtype = str(col_dtype)
        non_null = df[col].dropna()

        if non_null.empty:
            continue  

        numeric_converted = pd.to_numeric(non_null, errors="coerce")
        numeric_ratio = numeric_converted.notna().sum() / len(non_null)

        if numeric_ratio >= config.numeric_conversion_threshold:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            report.add(
                stage="datatypes",
                column=col,
                action="convert_numeric",
                detail=(
                    f"Converted '{original_dtype}' → numeric "
                    f"({numeric_ratio:.0%} values parseable)"
                ),
            )
            logger.debug(
                "Column '%s': converted to numeric (%.0f%%).", col, numeric_ratio * 100
            )
            continue

        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                dt_converted = pd.to_datetime(non_null, errors="coerce")
            dt_ratio = dt_converted.notna().sum() / len(non_null)
        except (ValueError, TypeError, OverflowError) as e:
            logger.debug("Column '%s': datetime conversion probe failed: %s", col, e)
            dt_ratio = 0.0

        if dt_ratio >= config.datetime_conversion_threshold:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                df[col] = pd.to_datetime(df[col], errors="coerce")
            report.add(
                stage="datatypes",
                column=col,
                action="convert_datetime",
                detail=(
                    f"Converted '{original_dtype}' → datetime "
                    f"({dt_ratio:.0%} values parseable)"
                ),
            )
            logger.debug(
                "Column '%s': converted to datetime (%.0f%%).", col, dt_ratio * 100
            )
            continue

        n_unique = df[col].nunique(dropna=True)
        n_total = len(df)

        if (
            n_total >= config.category_min_rows
            and n_unique >= 2
            and (n_unique / n_total) <= config.category_unique_ratio
        ):
            df[col] = df[col].astype("category")
            report.add(
                stage="datatypes",
                column=col,
                action="convert_category",
                detail=(
                    f"Converted '{original_dtype}' → category "
                    f"({n_unique} unique values, {n_unique / n_total:.1%} cardinality)"
                ),
            )
            logger.debug(
                "Column '%s': converted to category (%d unique / %d rows).",
                col, n_unique, n_total,
            )

    return df
