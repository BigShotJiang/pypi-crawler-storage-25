"""
report.py
---------
Human-readable, serializable cleaning report for Cleanix.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Report:
    """Collects and presents all cleaning actions taken on a DataFrame."""

    actions: list[dict[str, Any]] = field(default_factory=list)



    def add(
        self,
        stage: str,
        column: str | None,
        action: str,
        detail: str,
        rows_affected: int = 0,
    ) -> None:
        """Append a single cleaning action to the log."""
        self.actions.append(
            {
                "stage": stage,
                "column": column,
                "action": action,
                "detail": detail,
                "rows_affected": rows_affected,
            }
        )


    def summary(self) -> str:
        """Return a human-readable summary of all cleaning actions."""
        if not self.actions:
            return "✔ No cleaning actions were necessary."

        lines: list[str] = [
            "=" * 58,
            "  Cleanix — Cleaning Report",
            "=" * 58,
        ]

        stage_order = ["duplicates", "missing", "datatypes", "outliers"]
        stage_labels = {
            "duplicates": "🗑  Duplicates",
            "missing":    "🩹  Missing Values",
            "datatypes":  "🔄  Data Types",
            "outliers":   "📊  Outliers",
        }

        # Group by stage, preserving logical order
        grouped: dict[str, list[dict]] = {s: [] for s in stage_order}
        for entry in self.actions:
            grouped.setdefault(entry["stage"], []).append(entry)

        for stage in stage_order:
            entries = grouped.get(stage, [])
            if not entries:
                continue
            lines.append(f"\n{stage_labels.get(stage, stage.upper())}")
            lines.append("-" * 40)
            for e in entries:
                col_tag = f"[{e['column']}] " if e["column"] else ""
                row_tag = (
                    f"  ({e['rows_affected']:,} rows)" if e["rows_affected"] else ""
                )
                lines.append(f"  ✔ {col_tag}{e['detail']}{row_tag}")

        lines.append("\n" + "=" * 58)
        lines.append(f"  Total actions: {len(self.actions)}")
        lines.append("=" * 58)
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Return the full report as a plain Python dictionary."""
        return {
            "total_actions": len(self.actions),
            "actions": self.actions,
        }

    def to_json(self, indent: int = 2) -> str:
        """Return the full report serialised as a JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=str)

    def __repr__(self) -> str:  # pragma: no cover
        return f"Report(actions={len(self.actions)})"
