"""
config.py
---------
Centralized configuration for Cleanix cleaning thresholds and parameters.

Users can override these defaults by passing a CleaningConfig object to clean().
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class CleaningConfig:
    """
    Configuration for the Cleanix data cleaning pipeline.

    Attributes
    ----------
    missing_drop_threshold : float
        Drop columns with missing ratio at or above this threshold (default: 0.50).
    numeric_conversion_threshold : float
        Convert to numeric if this fraction of values parse successfully (default: 0.80).
    datetime_conversion_threshold : float
        Convert to datetime if this fraction of values parse successfully (default: 0.80).
    category_unique_ratio : float
        Convert to category if unique/total ratio is below this (default: 0.05).
    category_min_rows : int
        Minimum rows required to consider category conversion (default: 10).
    outlier_iqr_factor : float
        IQR multiplier for outlier detection (default: 1.5).
    outlier_min_rows : int
        Minimum rows required for outlier detection (default: 10).
    enable_duplicates : bool
        Enable duplicate row removal (default: True).
    enable_missing : bool
        Enable missing value handling (default: True).
    enable_datatypes : bool
        Enable datatype coercion (default: True).
    enable_outliers : bool
        Enable outlier detection and capping (default: True).
    max_memory_mb : Optional[int]
        Maximum memory usage in MB (None = no limit).
    verbose : bool
        Enable verbose logging (default: False).

    Examples
    --------
    >>> config = CleaningConfig(missing_drop_threshold=0.3, outlier_iqr_factor=2.0)
    >>> cleaned_df, report = clean(df, config)
    """

    # Missing value thresholds
    missing_drop_threshold: float = 0.50

    # Datatype conversion thresholds
    numeric_conversion_threshold: float = 0.80
    datetime_conversion_threshold: float = 0.80
    category_unique_ratio: float = 0.05
    category_min_rows: int = 10

    # Outlier detection parameters
    outlier_iqr_factor: float = 1.5
    outlier_min_rows: int = 10

    # Pipeline stage toggles
    enable_duplicates: bool = True
    enable_missing: bool = True
    enable_datatypes: bool = True
    enable_outliers: bool = True

    # Performance and safety
    max_memory_mb: Optional[int] = None
    verbose: bool = False

    def __post_init__(self) -> None:
        """Validate all configuration values on creation."""
        if not 0.0 <= self.missing_drop_threshold <= 1.0:
            raise ValueError(
                f"missing_drop_threshold must be between 0 and 1, "
                f"got {self.missing_drop_threshold}"
            )
        if not 0.0 <= self.numeric_conversion_threshold <= 1.0:
            raise ValueError(
                f"numeric_conversion_threshold must be between 0 and 1, "
                f"got {self.numeric_conversion_threshold}"
            )
        if not 0.0 <= self.datetime_conversion_threshold <= 1.0:
            raise ValueError(
                f"datetime_conversion_threshold must be between 0 and 1, "
                f"got {self.datetime_conversion_threshold}"
            )
        if not 0.0 <= self.category_unique_ratio <= 1.0:
            raise ValueError(
                f"category_unique_ratio must be between 0 and 1, "
                f"got {self.category_unique_ratio}"
            )
        if self.outlier_iqr_factor <= 0:
            raise ValueError(
                f"outlier_iqr_factor must be positive, got {self.outlier_iqr_factor}"
            )
        if self.outlier_min_rows < 1:
            raise ValueError(
                f"outlier_min_rows must be at least 1, got {self.outlier_min_rows}"
            )
        if self.category_min_rows < 1:
            raise ValueError(
                f"category_min_rows must be at least 1, got {self.category_min_rows}"
            )


# Default configuration instance — used when no config is passed to clean()
DEFAULT_CONFIG = CleaningConfig()
