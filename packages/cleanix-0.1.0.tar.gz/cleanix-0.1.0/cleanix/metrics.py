"""
metrics.py
----------
Data quality metrics to measure Cleanix cleaning effectiveness.
"""
from __future__ import annotations

from typing import Any, Dict

import pandas as pd


def calculate_quality_metrics(
    original_df: pd.DataFrame,
    cleaned_df: pd.DataFrame,
) -> Dict[str, Any]:
    """
    Calculate data quality metrics comparing original vs cleaned DataFrame.

    Parameters
    ----------
    original_df : pd.DataFrame
        The original DataFrame before cleaning.
    cleaned_df : pd.DataFrame
        The cleaned DataFrame after processing.

    Returns
    -------
    Dict[str, Any]
        Dictionary containing:
        - shape_change    : rows/columns removed
        - completeness    : missing value reduction
        - uniqueness      : duplicate removal
        - consistency     : data type improvements
        - memory_change   : memory usage comparison
    """
    orig_shape = original_df.shape
    clean_shape = cleaned_df.shape

    shape_change = {
        "original": orig_shape,
        "cleaned": clean_shape,
        "rows_removed": orig_shape[0] - clean_shape[0],
        "columns_removed": orig_shape[1] - clean_shape[1],
        "rows_removed_pct": round(
            (orig_shape[0] - clean_shape[0]) / orig_shape[0] * 100, 2
        ) if orig_shape[0] > 0 else 0,
        "columns_removed_pct": round(
            (orig_shape[1] - clean_shape[1]) / orig_shape[1] * 100, 2
        ) if orig_shape[1] > 0 else 0,
    }

    orig_cells = orig_shape[0] * orig_shape[1]
    clean_cells = clean_shape[0] * clean_shape[1]

    orig_missing_pct = (
        original_df.isna().sum().sum() / orig_cells * 100 if orig_cells > 0 else 0
    )
    clean_missing_pct = (
        cleaned_df.isna().sum().sum() / clean_cells * 100 if clean_cells > 0 else 0
    )

    completeness = {
        "original_missing_pct": round(orig_missing_pct, 2),
        "cleaned_missing_pct": round(clean_missing_pct, 2),
        "improvement": round(orig_missing_pct - clean_missing_pct, 2),
    }

    orig_dupes = int(original_df.duplicated().sum()) if not original_df.empty else 0
    clean_dupes = int(cleaned_df.duplicated().sum()) if not cleaned_df.empty else 0

    orig_unique_pct = (
        (1 - orig_dupes / len(original_df)) * 100 if len(original_df) > 0 else 100
    )
    clean_unique_pct = (
        (1 - clean_dupes / len(cleaned_df)) * 100 if len(cleaned_df) > 0 else 100
    )

    uniqueness = {
        "original_unique_pct": round(orig_unique_pct, 2),
        "cleaned_unique_pct": round(clean_unique_pct, 2),
        "duplicates_removed": orig_dupes - clean_dupes,
    }

    common_cols = set(original_df.columns) & set(cleaned_df.columns)
    type_improvements = sum(
        1
        for col in common_cols
        if str(original_df[col].dtype) == "object"
        and str(cleaned_df[col].dtype) in ("int64", "float64", "datetime64[ns]", "category")
    )

    consistency = {
        "common_columns": len(common_cols),
        "type_improvements": type_improvements,
        "type_improvement_pct": round(
            type_improvements / len(common_cols) * 100, 2
        ) if common_cols else 0,
    }

    orig_mb = original_df.memory_usage(deep=True).sum() / (1024 * 1024)
    clean_mb = cleaned_df.memory_usage(deep=True).sum() / (1024 * 1024)

    memory_change = {
        "original_mb": round(orig_mb, 2),
        "cleaned_mb": round(clean_mb, 2),
        "reduction_mb": round(orig_mb - clean_mb, 2),
        "reduction_pct": round(
            (orig_mb - clean_mb) / orig_mb * 100, 2
        ) if orig_mb > 0 else 0,
    }

    return {
        "shape_change": shape_change,
        "completeness": completeness,
        "uniqueness": uniqueness,
        "consistency": consistency,
        "memory_change": memory_change,
    }


def format_quality_report(metrics: Dict[str, Any]) -> str:
    """
    Format quality metrics into a human-readable report.

    Parameters
    ----------
    metrics : Dict[str, Any]
        Quality metrics from calculate_quality_metrics().

    Returns
    -------
    str
        Formatted quality report string.
    """
    lines = ["=" * 50, "  Cleanix — Data Quality Report", "=" * 50]

    shape = metrics["shape_change"]
    lines += [
        "\n📊 Dataset Shape", "-" * 20,
        f"  Original : {shape['original'][0]:,} rows × {shape['original'][1]} cols",
        f"  Cleaned  : {shape['cleaned'][0]:,} rows × {shape['cleaned'][1]} cols",
    ]
    if shape["rows_removed"] > 0:
        lines.append(f"  Removed  : {shape['rows_removed']:,} rows ({shape['rows_removed_pct']:.1f}%) ✓")
    if shape["columns_removed"] > 0:
        lines.append(f"  Removed  : {shape['columns_removed']} columns ({shape['columns_removed_pct']:.1f}%) ✓")

    comp = metrics["completeness"]
    lines += [
        "\n🩹 Completeness (Missing Data)", "-" * 20,
        f"  Before : {comp['original_missing_pct']:.1f}% missing",
        f"  After  : {comp['cleaned_missing_pct']:.1f}% missing",
    ]
    if comp["improvement"] > 0:
        lines.append(f"  Improved by {comp['improvement']:.1f}% ✓")

    uniq = metrics["uniqueness"]
    lines += [
        "\n🗑️  Uniqueness (Duplicates)", "-" * 20,
        f"  Before : {uniq['original_unique_pct']:.1f}% unique rows",
        f"  After  : {uniq['cleaned_unique_pct']:.1f}% unique rows",
    ]
    if uniq["duplicates_removed"] > 0:
        lines.append(f"  Removed {uniq['duplicates_removed']:,} duplicate(s) ✓")

    cons = metrics["consistency"]
    lines += [
        "\n🔄 Type Consistency", "-" * 20,
        f"  Columns analyzed  : {cons['common_columns']}",
        f"  Type improvements : {cons['type_improvements']} ({cons['type_improvement_pct']:.1f}%)",
    ]

    mem = metrics["memory_change"]
    lines += [
        "\n💾 Memory Usage", "-" * 20,
        f"  Original : {mem['original_mb']:.2f} MB",
        f"  Cleaned  : {mem['cleaned_mb']:.2f} MB",
    ]
    if mem["reduction_mb"] > 0:
        lines.append(f"  Saved    : {mem['reduction_mb']:.2f} MB ({mem['reduction_pct']:.1f}%) ✓")

    lines.append("\n" + "=" * 50)
    return "\n".join(lines)
