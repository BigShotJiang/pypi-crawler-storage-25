"""
validation.py
-------------
Input validation utilities for Cleanix.
"""
from __future__ import annotations

from typing import Optional

import pandas as pd

from .exceptions import MemoryLimitError, ValidationError


def validate_dataframe(df: pd.DataFrame, allow_empty: bool = False) -> None:
    """
    Validate that input is a proper pandas DataFrame.

    Parameters
    ----------
    df : Any
        Object to validate.
    allow_empty : bool
        Whether to allow empty DataFrames (default: False).

    Raises
    ------
    ValidationError
        If validation fails.
    """
    if not isinstance(df, pd.DataFrame):
        raise ValidationError(
            f"Expected a pandas DataFrame, got {type(df).__name__!r}. "
            "Please convert your data to a DataFrame first.\n"
            "  Example: df = pd.DataFrame(your_data)"
        )

    if not allow_empty and df.shape[1] == 0:
        raise ValidationError(
            "DataFrame has no columns. Cannot clean an empty structure."
        )

    if not allow_empty and df.shape[0] == 0:
        raise ValidationError(
            "DataFrame has no rows. Cannot clean empty data."
        )


def validate_column_names(df: pd.DataFrame) -> None:
    """
    Validate that column names are safe and well-formed.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to validate.

    Raises
    ------
    ValidationError
        If column names contain problematic patterns.
    """
    if df.columns.duplicated().any():
        duplicates = df.columns[df.columns.duplicated()].tolist()
        raise ValidationError(
            f"DataFrame contains duplicate column names: {duplicates}. "
            "All column names must be unique."
        )

    empty_cols = [i for i, col in enumerate(df.columns) if not str(col).strip()]
    if empty_cols:
        raise ValidationError(
            f"DataFrame contains empty column names at positions: {empty_cols}. "
            "Please provide meaningful column names."
        )


def check_memory_usage(df: pd.DataFrame, max_memory_mb: Optional[int] = None) -> None:
    """
    Check if DataFrame memory usage exceeds the configured limit.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to check.
    max_memory_mb : Optional[int]
        Maximum allowed memory in MB. If None, no check is performed.

    Raises
    ------
    MemoryLimitError
        If memory usage exceeds the limit.
    """
    if max_memory_mb is None:
        return

    memory_bytes = df.memory_usage(deep=True).sum()
    memory_mb = memory_bytes / (1024 * 1024)

    if memory_mb > max_memory_mb:
        raise MemoryLimitError(
            f"DataFrame memory usage ({memory_mb:.2f} MB) exceeds the configured "
            f"limit ({max_memory_mb} MB). Consider processing in chunks or "
            "increasing max_memory_mb in your CleaningConfig."
        )


def get_dataframe_info(df: pd.DataFrame) -> dict:
    """
    Get basic information about a DataFrame for logging/debugging.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to inspect.

    Returns
    -------
    dict
        Dictionary with shape, memory usage, and dtype information.
    """
    memory_bytes = df.memory_usage(deep=True).sum()
    memory_mb = memory_bytes / (1024 * 1024)
    total_cells = df.shape[0] * df.shape[1]

    return {
        "shape": df.shape,
        "memory_mb": round(memory_mb, 2),
        "dtypes": df.dtypes.value_counts().to_dict(),
        "missing_cells": int(df.isna().sum().sum()),
        "missing_pct": round(df.isna().sum().sum() / total_cells * 100, 2)
        if total_cells > 0
        else 0,
    }
