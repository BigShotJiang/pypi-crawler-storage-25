"""
missing.py
----------
Intelligent missing-value handling for Cleanix.

Strategy:
  - >= missing_drop_threshold missing  → drop column entirely
  - numeric column                     → fill with median
  - categorical / object column        → fill with mode (most-frequent value)
  - 100% missing                       → drop (edge-case guard)
"""
from __future__ import annotations

import logging

import pandas as pd

from .config import CleaningConfig
from .report import Report

logger = logging.getLogger(__name__)


def handle_missing(
    df: pd.DataFrame, report: Report, config: CleaningConfig
) -> pd.DataFrame:
    """
    Impute or drop columns based on their missing-value ratio.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame (will NOT be mutated in-place).
    report : Report
        Report instance — actions are appended directly.
    config : CleaningConfig
        Configuration with missing_drop_threshold.

    Returns
    -------
    pd.DataFrame
        DataFrame with missing values handled.
    """
    if df.empty:
        logger.warning("handle_missing received an empty DataFrame; skipping.")
        return df

    n_rows = len(df)
    cols_to_drop: list[str] = []

    for col in df.columns:
        missing_count = int(df[col].isna().sum())

        if missing_count == 0:
            continue  # nothing to do

        missing_ratio = missing_count / n_rows

        # ── 1. Drop column when missing ratio meets or exceeds threshold ───
        if missing_ratio >= config.missing_drop_threshold:
            cols_to_drop.append(col)
            report.add(
                stage="missing",
                column=col,
                action="drop_column",
                detail=(
                    f"Dropped column — {missing_ratio:.0%} values were missing "
                    f"({missing_count:,}/{n_rows:,})"
                ),
                rows_affected=missing_count,
            )
            logger.debug(
                "Dropping column '%s': %.0f%% missing.", col, missing_ratio * 100
            )
            continue

        # ── 2. Numeric: fill with median ────────────────────────────────────
        if pd.api.types.is_numeric_dtype(df[col]) and not isinstance(
            df[col].dtype, pd.StringDtype
        ):
            fill_value = df[col].median()

            if pd.isna(fill_value):
                cols_to_drop.append(col)
                report.add(
                    stage="missing",
                    column=col,
                    action="drop_column",
                    detail="Dropped column — all values are missing (no median available)",
                    rows_affected=missing_count,
                )
                logger.warning("Column '%s': all values are NaN, dropping.", col)
                continue

            df[col] = df[col].fillna(fill_value)
            report.add(
                stage="missing",
                column=col,
                action="fill_median",
                detail=f"Filled {missing_count:,} missing value(s) with median ({fill_value:.4g})",
                rows_affected=missing_count,
            )
            logger.debug(
                "Column '%s': filled %d missing with median %.4g.",
                col, missing_count, fill_value,
            )

        # ── 3. Categorical / object: fill with mode ─────────────────────────
        else:
            mode_series = df[col].mode()

            if mode_series.empty:
                cols_to_drop.append(col)
                report.add(
                    stage="missing",
                    column=col,
                    action="drop_column",
                    detail="Dropped column — all values are missing (no mode available)",
                    rows_affected=missing_count,
                )
                logger.warning("Column '%s': all values are NaN, dropping.", col)
                continue

            fill_value = mode_series.iloc[0]

            if len(mode_series) > 1:
                logger.debug(
                    "Column '%s': multiple modes %s — using first: '%s'.",
                    col, mode_series.tolist(), fill_value,
                )

            df[col] = df[col].fillna(fill_value)
            report.add(
                stage="missing",
                column=col,
                action="fill_mode",
                detail=f"Filled {missing_count:,} missing value(s) with mode ('{fill_value}')",
                rows_affected=missing_count,
            )
            logger.debug(
                "Column '%s': filled %d missing with mode '%s'.",
                col, missing_count, fill_value,
            )

    if cols_to_drop:
        df = df.drop(columns=cols_to_drop)

    return df
