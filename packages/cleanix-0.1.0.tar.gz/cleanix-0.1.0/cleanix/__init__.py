"""
cleanix
=======
Intelligent, explainable data cleaning built on pandas.

Public API
----------
    clean(df, config=None)            → (cleaned_df, Report)
    suggest_cleaning(df, config=None) → list[dict]
    profile_data(df)                  → dict[str, dict]
    Report                            → .summary() / .to_dict() / .to_json()
    CleaningConfig                    → Configuration class for customizing behavior

Examples
--------
Basic usage:
    >>> import pandas as pd
    >>> from cleanix import clean
    >>> df = pd.DataFrame({"age": [25, None, 30], "name": ["Alice", "Bob", "Charlie"]})
    >>> cleaned_df, report = clean(df)
    >>> print(report.summary())

Custom configuration:
    >>> from cleanix import clean, CleaningConfig
    >>> config = CleaningConfig(missing_drop_threshold=0.3, verbose=True)
    >>> cleaned_df, report = clean(df, config)

Preview suggestions:
    >>> from cleanix import suggest_cleaning
    >>> suggestions = suggest_cleaning(df)
    >>> for s in suggestions:
    ...     print(f"{s['priority']}: {s['message']}")
"""
from __future__ import annotations
import logging
from .cleaner import clean
from .config import CleaningConfig, DEFAULT_CONFIG
from .exceptions import (
    CleanixError,
    CleaningError,
    ConfigurationError,
    ValidationError,
)
from .metrics import calculate_quality_metrics, format_quality_report
from .profiler import profile_data
from .report import Report
from .suggester import suggest_cleaning

__all__ = [
    "clean",
    "profile_data",
    "suggest_cleaning",
    "Report",
    "CleaningConfig",
    "DEFAULT_CONFIG",
    # Exceptions
    "CleanixError",
    "ValidationError",
    "ConfigurationError",
    "CleaningError",
    # Quality metrics
    "calculate_quality_metrics",
    "format_quality_report",
]

__version__ = "0.1.0"
__author__ = "Santhosh M"

# Library-level logger — consumers configure handlers themselves.
logging.getLogger(__name__).addHandler(logging.NullHandler())
