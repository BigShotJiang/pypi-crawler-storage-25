# nft-egress-routing

`nft-egress-routing` is a CLI tool that implements **policy-based egress routing** on Linux by
combining [nftables](https://nftables.org/) packet marking with
[iproute2](https://wiki.linuxfoundation.org/networking/iproute2) routing rules and tables.

Packets destined for addresses in a named nftables set are stamped with an fwmark; a matching
`ip rule` then forwards those packets through a dedicated routing table that points to a specific
gateway — independently of the default route.

The **recommended way to deploy this tool** is via the included Ansible role
[`nft_egress_routing`](#using-with-ansible), which handles everything end-to-end. The manual
sections below are provided for reference and troubleshooting.

---

## How it works

```
┌──────────────────────────────────────────────────────────────┐
│  nftables (inet table)                                       │
│                                                              │
│  set cloudfront_ipv4 { type ipv4_addr; flags interval }      │
│  set cloudfront_ipv6 { type ipv6_addr; flags interval }      │
│                                                              │
│  chain output {                                              │
│    type route hook output priority mangle;                   │
│    ip  daddr @cloudfront_ipv4 meta mark set 0xe8             │
│    ip6 daddr @cloudfront_ipv6 meta mark set 0xe8             │
│  }                                                           │
└──────────────────────────────────────────────────────────────┘
              │  locally-generated packets are marked before
              │  the routing decision is made
              ▼
┌──────────────────────────────────────────────────────────────┐
│  iproute2                                                    │
│                                                              │
│  ip rule:   fwmark 0xe8  →  lookup nft_egress_routing        │
│  ip route:  default via 10.0.0.1  table nft_egress_routing   │
└──────────────────────────────────────────────────────────────┘
```

The chain type `route` in the `output` hook is nftables' mechanism for affecting the routing
decision of **locally-generated packets**. Marks set here are evaluated before the kernel selects
the outbound interface, so traffic matching the set destinations is routed through a dedicated
gateway instead of the default route.

`nft-egress-routing` automates two orthogonal concerns:

| Command group                  | What it does                                                                              |
| ------------------------------ | ----------------------------------------------------------------------------------------- |
| `sets update` / `sets clean`   | Fetches IP ranges from providers and atomically refreshes the nftables sets.              |
| `rule setup` / `rule teardown` | Writes `rt_tables.d` entries and installs `ip rule` + `ip route` for every routing group. |

The nftables table, chain, and set **skeleton** is rendered by the Ansible role at deploy time and
reloaded by `nftables.service`. The set **contents** are kept fresh by a systemd timer that calls
`sets update` on a configurable schedule.

---

## Installation

`httpx` and `jmespath` are required for the `remote_text` and `remote_json` provider types.
Install the package with the `nft-egress-routing` extra to pull them in:

```bash
pip install "opscat[nft-egress-routing]"
# or, inside this project's development environment:
just sync   # equivalent to: uv sync --group dev --all-extras
```

The bare `opscat` install (without the extra) still works if you use only `inline_list` and `dns`
providers.

---

## Configuration

The tool reads a single TOML file, defaulting to `/etc/opscat/nft-egress-routing.toml`. Pass a
different path with `--config`.

### `[nftables]`

| Key     | Type   | Default                | Description                                     |
| ------- | ------ | ---------------------- | ----------------------------------------------- |
| `table` | string | `"nft_egress_routing"` | Name of the nftables table that holds the sets. |

### `[global]`

| Key                         | Type    | Default                | Description                                                                      |
| --------------------------- | ------- | ---------------------- | -------------------------------------------------------------------------------- |
| `address_family`            | string  | `"any"`                | Default address family filter for all providers: `"ipv4"`, `"ipv6"`, or `"any"`. |
| `gateway`                   | string  | `""`                   | Default IPv4 next-hop (e.g. `"192.168.1.1"`).                                    |
| `gateway6`                  | string  | `""`                   | Default IPv6 next-hop (e.g. `"2001:db8::1"`).                                    |
| `gateway_dev`               | string  | `""`                   | Default egress device (e.g. `"eth0"`). Used alongside or instead of `gateway`.   |
| `routing_table_name_prefix` | string  | `"nft_egress_routing"` | Prefix for the iproute2 routing table name of the default group.                 |
| `routing_table_id_start`    | integer | `232`                  | Numeric ID assigned to the default routing table.                                |
| `fwmark_start`              | string  | `"0xe8"`               | fwmark value for the default routing group.                                      |

### `[providers.<name>]`

Each provider defines one source of IP ranges. Common keys:

| Key                  | Type    | Required | Description                                                                                                                          |
| -------------------- | ------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| `enabled`            | bool    | yes      | Set to `true` to activate the provider.                                                                                              |
| `type`               | string  | yes      | One of `inline_list`, `dns`, `remote_text`, `remote_json`.                                                                           |
| `address_family`     | string  | no       | Overrides `global.address_family` for this provider.                                                                                 |
| `nexthop`            | string  | no       | Provider-specific IPv4 gateway; overrides `global.gateway`.                                                                          |
| `nexthop6`           | string  | no       | Provider-specific IPv6 gateway; overrides `global.gateway6`.                                                                         |
| `nexthop_dev`        | string  | no       | Provider-specific device; overrides `global.gateway_dev`.                                                                            |
| `fwmark`             | string  | no       | fwmark for this provider's routing group. **Required** when `nexthop` / `nexthop6` / `nexthop_dev` differs from the global defaults. |
| `routing_table_id`   | integer | no       | Override the auto-assigned routing table ID for this group.                                                                          |
| `routing_table_name` | string  | no       | Override the routing table name for this group.                                                                                      |

---

## Provider types

### `inline_list`

A static list of CIDRs embedded directly in the configuration file. Useful for RFC 1918 ranges,
fixed peering prefixes, or anything that does not change frequently.

```toml
[providers.rfc1918]
enabled = true
type    = "inline_list"
cidrs   = [
  "10.0.0.0/8",
  "172.16.0.0/12",
  "192.168.0.0/16",
]
```

CIDRs are classified automatically: IPv4 entries go into the `<name>_ipv4` set and IPv6 entries
into `<name>_ipv6`. Host-bits are silently masked (`strict=False`).

### `dns`

Resolves a list of hostnames via `socket.getaddrinfo` at update time. A records become `/32`
entries; AAAA records become `/128` entries. Resolution failures for individual hostnames are
logged as warnings and skipped; the remaining hostnames are still processed. Results are cached
for the lifetime of the process.

```toml
[providers.my_service]
enabled   = true
type      = "dns"
hostnames = ["api.example.com", "cdn.example.com"]
```

### `remote_text`

Fetches a plain-text file over HTTP(S) where each non-blank, non-comment line is a CIDR. Lines
starting with `#` or `;` are treated as comments and ignored. Invalid lines are logged as warnings
and skipped.

```toml
[providers.blocklist]
enabled = true
type    = "remote_text"
url     = "https://example.com/iplist.txt"
```

### `remote_json`

Fetches a JSON document and extracts CIDRs using [JMESPath](https://jmespath.org/) expressions.
This covers APIs that return structured IP range data, such as AWS, GCP, or Cloudflare.

```toml
[providers.aws]
enabled        = true
type           = "remote_json"
url            = "https://ip-ranges.amazonaws.com/ip-ranges.json"
ipv4_jmespath  = "prefixes"
ipv4_field     = "ip_prefix"
ipv6_jmespath  = "ipv6_prefixes"
ipv6_field     = "ipv6_prefix"
# Optional: keep only items whose `service` field matches this regex
filter_field   = "service"
filter_regex   = "^CLOUDFRONT$"
```

| Key             | Type   | Required | Description                                                      |
| --------------- | ------ | -------- | ---------------------------------------------------------------- |
| `url`           | string | yes      | HTTP(S) URL that returns the JSON document.                      |
| `ipv4_jmespath` | string | yes      | JMESPath expression selecting the list of IPv4 prefix objects.   |
| `ipv4_field`    | string | yes      | Key inside each IPv4 item that holds the prefix string.          |
| `ipv6_jmespath` | string | yes      | JMESPath expression selecting the list of IPv6 prefix objects.   |
| `ipv6_field`    | string | yes      | Key inside each IPv6 item that holds the prefix string.          |
| `filter_field`  | string | no       | Item key whose value is matched against `filter_regex`.          |
| `filter_regex`  | string | no       | Python `re.search` pattern; items that do not match are skipped. |

Items missing the target prefix field are silently skipped, which lets a single JMESPath expression
cover objects that carry only an IPv4 _or_ only an IPv6 prefix (as in the GCP prefix list).

---

## Routing groups

Providers that share identical `(nexthop, nexthop6, nexthop_dev)` values are **collapsed into a
single routing group**, so that `ip rule` and `ip route` commands are issued only once per unique
gateway combination.

- Providers that use the global gateway all belong to the **default group**, which is assigned
  `routing_table_id_start` and `fwmark_start`.
- Providers with a **per-provider nexthop** must set an explicit `fwmark` (because the nftables
  template also needs it at Ansible render time); their table ID is auto-incremented from
  `routing_table_id_start + 1`, `+ 2`, etc., or can be set explicitly.

If no providers are enabled, a single default routing group is still installed so that the rule and
route are always present.

---

## CLI reference

### Global option

```
nft-egress-routing [--log-level LEVEL] <subcommand>
```

`--log-level` (env: `NFT_EGRESS_ROUTING_LOG_LEVEL`) accepts `TRACE`, `DEBUG`, `INFO`, `WARNING`,
`ERROR`, or `CRITICAL` (default: `INFO`).

### `sets update`

```
nft-egress-routing sets update [--config PATH]
```

For each enabled provider:

1. Calls `fetch_ipv4()` and `fetch_ipv6()` to obtain CIDR lists.
2. Collapses overlapping or adjacent CIDRs via `ipaddress.collapse_addresses()`.
3. Batches `flush set` + `add element` commands into a single `nft -f /dev/stdin` transaction.

After all providers are updated, any nftables sets that exist in the table but are no longer
referenced by an enabled provider are flushed (stale-set cleanup).

### `sets clean`

```
nft-egress-routing sets clean [--config PATH]
```

Flushes every set in the configured table without fetching new data. Equivalent to a graceful
disable of all IP-based routing decisions.

### `rule setup`

```
nft-egress-routing rule setup [--config PATH]
```

For each routing group derived from the config:

1. Writes `/etc/iproute2/rt_tables.d/nft-egress-routing-<table_name>.conf`.
2. Deletes any pre-existing `ip rule fwmark … lookup …` entry (idempotent).
3. Deletes any pre-existing default route in the routing table.
4. Adds the `ip -4 rule` and `ip -4 route`.
5. If `nexthop6` or `nexthop_dev` is set, also adds the `ip -6 rule` and `ip -6 route`.

### `rule teardown`

```
nft-egress-routing rule teardown [--config PATH]
```

Reverses `rule setup`: removes routes and rules (IPv6 first), then deletes the `rt_tables.d` file
for each group. All removals use `check=False` so teardown is safe even if rules or routes are
already absent.

---

## Example: full configuration

```toml
[nftables]
table = "nft_egress_routing"

[global]
address_family            = "any"
gateway                   = "192.168.1.1"
gateway6                  = ""
gateway_dev               = ""
routing_table_name_prefix = "nft_egress_routing"
routing_table_id_start    = 232
fwmark_start              = "0xe8"

# ── Static RFC 1918 ranges (always through the default gateway) ──────────────

[providers.rfc1918]
enabled = true
type    = "inline_list"
cidrs   = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]

# ── AWS CloudFront IP ranges (remote JSON) ───────────────────────────────────

[providers.cloudfront]
enabled        = true
type           = "remote_json"
url            = "https://ip-ranges.amazonaws.com/ip-ranges.json"
ipv4_jmespath  = "prefixes"
ipv4_field     = "ip_prefix"
ipv6_jmespath  = "ipv6_prefixes"
ipv6_field     = "ipv6_prefix"
filter_field   = "service"
filter_regex   = "^CLOUDFRONT$"

# ── A provider that routes through a different gateway ───────────────────────

[providers.partner_cdn]
enabled    = true
type       = "remote_text"
url        = "https://partner.example.com/ip-list.txt"
nexthop    = "10.10.0.1"
fwmark     = "0xe9"

# ── Resolve a SaaS API hostname ──────────────────────────────────────────────

[providers.saas_api]
enabled        = false
type           = "dns"
address_family = "ipv4"
hostnames      = ["api.saas-example.com"]
```

---

## nftables table skeleton

`nft-egress-routing` manages only the **set contents**, not the table structure. When deployed via
Ansible, the `nft_egress_routing` role renders and maintains this skeleton automatically (see
[Using with Ansible](#using-with-ansible)).

For reference, the generated file looks like:

```nft
# /etc/nftables.d/nft-egress-routing.nft
# Generated by Ansible — do not edit manually

table inet nft_egress_routing {

    set rfc1918_ipv4 {
        type ipv4_addr
        flags interval
    }

    set cloudfront_ipv4 {
        type ipv4_addr
        flags interval
    }

    set cloudfront_ipv6 {
        type ipv6_addr
        flags interval
    }

    # partner_cdn routes through a different gateway and uses its own fwmark
    set partner_cdn_ipv4 {
        type ipv4_addr
        flags interval
    }

    chain output {
        # 'type route' in the output hook lets nftables change the routing
        # decision for locally-generated packets before the kernel commits to
        # an outbound interface.
        type route hook output priority mangle; policy accept;

        ip  daddr @rfc1918_ipv4     meta mark set 0xe8
        ip  daddr @cloudfront_ipv4  meta mark set 0xe8
        ip6 daddr @cloudfront_ipv6  meta mark set 0xe8
        ip  daddr @partner_cdn_ipv4 meta mark set 0xe9
    }
}
```

!!! tip
The fwmark values in the nftables file are rendered from the same Ansible variables that
populate the TOML config, so the two files always stay in sync.

---

## Using with Ansible

The recommended deployment path is the `nft_egress_routing` Ansible role, located at
`roles/nft_egress_routing/` in this repository. It handles every step:

1. Installing system packages (`nftables`, `python3-venv`).
2. Creating and populating a dedicated Python venv with `opscat[nft-egress-routing]`.
3. Rendering the TOML config, the nftables skeleton, and all systemd unit files from templates.
4. Enabling and starting the `nft-egress-routing-rule.service` (ip rule / ip route) and the
   `nft-egress-routing.timer` (periodic `sets update`).

### Quick start

```yaml
# playbooks/nft-egress-routing.yaml
- name: nftables-based policy routing
  hosts: my_servers
  become: true
  tasks:
    - ansible.builtin.import_role:
        name: nft_egress_routing
```

```bash
ansible-playbook playbooks/nft-egress-routing.yaml \
  -i inventory/hosts \
  -e @host_vars/my_server.yaml
```

### Role variables

All variables have documented defaults in `roles/nft_egress_routing/defaults/main.yaml`. The
table below lists the most important ones.

#### Deployment state

| Variable                   | Default     | Description                                                      |
| -------------------------- | ----------- | ---------------------------------------------------------------- |
| `nft_egress_routing_state` | `"present"` | Set to `"absent"` to stop services and remove all managed files. |

#### Install source

| Variable                                | Default   | Description                                                                                                                                                       |
| --------------------------------------- | --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `nft_egress_routing_pip_install_source` | `"local"` | How to install `opscat`: `"local"` builds and transfers a wheel from the control node; `"pypi"` installs from the public PyPI index; `"testpypi"` uses Test PyPI. |

#### Global routing

| Variable                                       | Default                | Description                                                                                          |
| ---------------------------------------------- | ---------------------- | ---------------------------------------------------------------------------------------------------- |
| `nft_egress_routing_address_family`            | `"ipv4"`               | Default address family for all providers (`"ipv4"`, `"ipv6"`, or `"any"`).                           |
| `nft_egress_routing_gateway`                   | `""`                   | IPv4 next-hop for the default routing group. At least one of `gateway` or `gateway_dev` must be set. |
| `nft_egress_routing_gateway6`                  | `""`                   | IPv6 next-hop (optional). When set, IPv6 rules and routes are also installed.                        |
| `nft_egress_routing_gateway_dev`               | `""`                   | Egress device for on-link routes (optional).                                                         |
| `nft_egress_routing_fwmark_start`              | `"0xe8"`               | fwmark for the default routing group.                                                                |
| `nft_egress_routing_routing_table_id_start`    | `232`                  | Routing table numeric ID for the default group.                                                      |
| `nft_egress_routing_routing_table_name_prefix` | `"nft_egress_routing"` | Prefix for the iproute2 routing table name.                                                          |

#### Timer

| Variable                              | Default | Description                                            |
| ------------------------------------- | ------- | ------------------------------------------------------ |
| `nft_egress_routing_timer_enabled`    | `true`  | Whether to enable and start the periodic update timer. |
| `nft_egress_routing_timer_boot_delay` | `"1m"`  | Delay after boot before the first `sets update` run.   |
| `nft_egress_routing_timer_interval`   | `"6h"`  | Interval between successive `sets update` runs.        |

#### Providers

`nft_egress_routing_providers` is a dict whose keys become nftables set name prefixes. Every
provider supports the [common provider keys](#providersname) described above; the dict structure
mirrors the TOML `[providers.<name>]` sections exactly.

```yaml
nft_egress_routing_providers:
  rfc1918:
    type: inline_list
    enabled: true
    cidrs:
      - 10.0.0.0/8
      - 172.16.0.0/12
      - 192.168.0.0/16
```

### Full host_vars example

A complete variable file for a host that routes CloudFront and GCP Asia traffic through a dedicated
upstream, while sending RFC 1918 traffic through the standard gateway:

```yaml
# host_vars/gw01.yaml

# ── Install source ────────────────────────────────────────────────────────────
# Use the local wheel built from this repository (default for development).
# Switch to "pypi" for production deployments against a published release.
nft_egress_routing_pip_install_source: local

# ── Default (global) gateway ──────────────────────────────────────────────────
nft_egress_routing_address_family: ipv4
nft_egress_routing_gateway: "10.0.0.1"
nft_egress_routing_fwmark_start: "0xe8"
nft_egress_routing_routing_table_id_start: 232
nft_egress_routing_routing_table_name_prefix: nft_egress_routing

# ── Timer ─────────────────────────────────────────────────────────────────────
nft_egress_routing_timer_enabled: true
nft_egress_routing_timer_boot_delay: 2m
nft_egress_routing_timer_interval: 6h

# ── Providers ─────────────────────────────────────────────────────────────────
nft_egress_routing_providers:
  # Static RFC 1918 subnets — inline, never needs an update run.
  rfc1918:
    type: inline_list
    enabled: true
    address_family: ipv4
    cidrs:
      - 10.0.0.0/8
      - 172.16.0.0/12
      - 192.168.0.0/16

  # AWS CloudFront edge nodes — routes through the same default gateway.
  cloudfront:
    type: remote_json
    enabled: true
    url: https://ip-ranges.amazonaws.com/ip-ranges.json
    ipv4_jmespath: prefixes
    ipv4_field: ip_prefix
    ipv6_jmespath: ipv6_prefixes
    ipv6_field: ipv6_prefix
    filter_field: service
    filter_regex: "^CLOUDFRONT$"

  # GCP Asia-Southeast1 — different upstream gateway; requires explicit fwmark.
  gcloud_apse1:
    type: remote_json
    enabled: true
    url: https://www.gstatic.com/ipranges/cloud.json
    ipv4_jmespath: prefixes
    ipv4_field: ipv4Prefix
    ipv6_jmespath: prefixes
    ipv6_field: ipv6Prefix
    filter_field: scope
    filter_regex: "^asia-southeast1"
    nexthop: "10.1.0.1" # different upstream
    fwmark: "0xe9" # must match the nftables mark above
    routing_table_id: 233

  # A partner CDN distributed as a plain CIDR list.
  partner_cdn:
    type: remote_text
    enabled: false
    url: https://partner.example.com/ip-list.txt
    address_family: ipv4
```

### What the role deploys

```
/etc/opscat/
└── nft-egress-routing.toml          ← TOML config (mode 0640)

/etc/nftables.d/
└── nft-egress-routing.nft           ← nftables table + sets + output chain

/etc/systemd/system/
├── nft-egress-routing-rule.service  ← oneshot: rule setup (ExecStart) /
│                                       rule teardown (ExecStop)
├── nft-egress-routing.service       ← oneshot: sets update
└── nft-egress-routing.timer         ← periodic trigger for the above

/var/lib/opscat/venvs/
└── nft-egress-routing/              ← isolated Python venv
    └── bin/
        └── nft-egress-routing       ← CLI entry-point
```

`/etc/nftables.conf` is patched with `include "/etc/nftables.d/*.nft"` so the generated table is
loaded automatically on `nftables.service` (re)start.

### Removing the deployment

Set `nft_egress_routing_state: absent` and re-run the playbook. The role will:

1. Stop and disable both systemd services and the timer.
2. Remove all systemd unit files and trigger a `daemon-reload`.
3. Remove the nftables rules file and reload nftables (clearing the table from the kernel).
4. Remove `rt_tables.d` entries created by the rule service.
5. Remove the TOML config file and the Python venv.

### The `pyproject_install` dependency role

`nft_egress_routing` delegates the Python installation step to the generic
`pyproject_install` role (`roles/pyproject_install/`), which supports three install
sources controlled by `nft_egress_routing_pip_install_source`:

| Source     | Behaviour                                                                                                                                                                             |
| ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `local`    | Runs `uv build --wheel` on the control node, copies the wheel to the target, and installs it with `pip install "opscat[nft-egress-routing] @ file://…"`. Use this during development. |
| `pypi`     | Installs `opscat[nft-egress-routing]` directly from PyPI. Use this for production once the package is published.                                                                      |
| `testpypi` | Same as `pypi` but uses the Test PyPI index. Useful for validating a release candidate.                                                                                               |

---

## Ansible testing with Molecule

The role ships Molecule scenarios for automated integration testing. Each scenario spins up a
Docker container, applies the role, and runs a set of assertions.

### Prerequisites

```bash
# Install Docker on the control node (platform-specific).
# Then install the Ansible testing dependencies:
uv sync --group ansible

# Or install them manually:
pip install "ansible-core>=2.17" "molecule>=24.0" "molecule-plugins[docker]>=23.5" "ansible-lint>=24.9"
```

### Running the tests

```bash
# Lint all roles and playbooks:
just ansible-lint

# Full molecule cycle for a role (create → prepare → converge → verify → destroy):
just molecule-test nft_egress_routing
just molecule-test pyproject_install

# Iterate without destroying the container:
just molecule-converge nft_egress_routing   # apply the role
just molecule-verify  nft_egress_routing    # re-run assertions
just molecule-destroy nft_egress_routing    # clean up
```

### What the `nft_egress_routing` scenario tests

The default scenario (`roles/nft_egress_routing/molecule/default/`) runs inside a
**systemd-capable Debian 12 container** (`ghcr.io/geerlingguy/docker-debian12-ansible`).

`prepare.yml` installs system packages and then installs two binary stubs:

- `/usr/sbin/nft` — replaced with a shell script that returns valid empty JSON for `nft -j list
table` queries and exits 0 for all write operations. This prevents the scenario from requiring a
  host kernel with the `nf_tables` module loaded.
- `/usr/local/bin/ip` — a wrapper that stubs `add`/`del` write operations (so the test does not
  modify the host's routing tables) while forwarding read-only subcommands (`ip rule show`, etc.)
  to the real binary for the preflight conflict checks.

`verify.yml` then asserts:

- The Python venv exists and `nft-egress-routing --help` exits 0.
- `httpx` and `jmespath` are importable (extras were installed correctly).
- The TOML config file is present, has mode `0640`, and contains the expected gateway, fwmark,
  provider section, and CIDRs.
- The nftables file declares the correct set name and uses `type route` in the `output` chain.
- `/etc/nftables.conf` contains the wildcard include line.
- All three systemd unit files are present with the correct `ExecStart` paths.
- `nft-egress-routing-rule.service` is **enabled** and **active**.
- `nft-egress-routing.timer` is **disabled** (because `nft_egress_routing_timer_enabled: false` is
  set in `converge.yml` to prevent the timer from firing during the short test window).

### What the `pyproject_install` scenario tests

The default scenario (`roles/pyproject_install/molecule/default/`) uses a plain
**`debian:12-slim`** container (no systemd).

`converge.yml` installs `opscat[nft-egress-routing]` from PyPI into an isolated venv.

`verify.yml` asserts:

- The venv Python interpreter exists and is executable.
- The `nft-egress-routing` entry-point binary is present and executable.
- `nft-egress-routing --help` exits 0 and mentions both `sets` and `rule`.
- `httpx` and `jmespath` are importable (confirming the PEP 508 extras syntax in
  `tasks/from_pypi.yaml` is correct).

!!! note
Both scenarios require `opscat` to be published on PyPI (or Test PyPI). For testing against
an unpublished local build, change `nft_egress_routing_pip_install_source` to `"local"` in
`converge.yml` and set `pyproject_install_local_project_root` to the absolute path of the
repository root on your control node.
