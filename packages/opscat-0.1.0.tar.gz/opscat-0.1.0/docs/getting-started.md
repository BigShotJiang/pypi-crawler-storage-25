# Getting Started

## Prerequisites

- [uv](https://docs.astral.sh/uv/) — used for all dependency management and command execution
- Python 3.11 or later (uv manages this automatically)
- For Ansible role testing: Docker — see [Ansible testing](#ansible-role-testing)

## Clone and sync

```bash
git clone https://github.com/ak1ra-lab/ansible-collection-opscat.git
cd ansible-collection-opscat
just sync
```

`just sync` runs:

```bash
uv sync --group dev --all-extras
```

That single command installs three independent things:

| What                                                   | Flag           | Why                                                                         |
| ------------------------------------------------------ | -------------- | --------------------------------------------------------------------------- |
| Dev toolchain (pytest, ruff, ty, zensical, pre-commit) | `--group dev`  | Tests, linting, type-checking, docs                                         |
| Optional runtime extras (httpx, jmespath)              | `--all-extras` | Required to import the `remote_json` and `remote_text` providers            |
| _(nothing else)_                                       | —              | The `ansible` group is **not** included; see [below](#ansible-role-testing) |

### Why not `--locked`?

`--locked` tells uv to treat the lockfile as read-only and fail if it would need
updating. That is the right behaviour for CI (it catches a forgotten `git add
uv.lock`), but the wrong behaviour for day-to-day development — it would prevent
you from adding a new dependency without an extra step.

Use `--locked` only in automated pipelines. Locally, omit it and let uv keep
`uv.lock` current automatically.

### Why not `--all-groups`?

`--all-groups` would also install the `ansible` group, which pulls in
`ansible-core`, `molecule`, and the Docker SDK. These are heavy dependencies
that are only needed when running Ansible role tests. They are intentionally
kept out of the standard developer environment.

---

## Common tasks

```bash
just lint        # ruff check --fix + ruff format
just typecheck   # ty check src/
just test        # pytest -v tests/
just coverage    # pytest --cov with terminal report
just docs-serve  # live-reload docs at http://localhost:8000
just docs-build  # build static docs site into site/
just build       # build wheel + sdist into dist/
just clean       # remove dist/, site/, .pytest_cache/, htmlcov/, .coverage
```

---

## Dependency groups at a glance

```
[project.dependencies]            loguru, typer
                                  installed by every uv sync

[project.optional-dependencies]
  nft-egress-routing              httpx, jmespath
                                  installed with --all-extras
                                  needed to import remote_json / remote_text providers

[dependency-groups]
  tests                           pytest, pytest-cov
  lint                            ruff, ty
  docs                            zensical, mkdocstrings-python
  dev      = tests+lint+docs      + pre-commit  ← standard dev toolchain
  ansible                         ansible-core, ansible-lint, molecule,
                                  molecule-plugins[docker]
                                  ← only for Ansible role testing
```

### `just sync` vs each scenario

| Scenario             | Command                                     | `--locked`? |
| -------------------- | ------------------------------------------- | ----------- |
| Local development    | `uv sync --group dev --all-extras`          | No          |
| CI — test & publish  | `uv sync --locked --group dev --all-extras` | **Yes**     |
| CI — docs build only | `uv sync --locked --group docs`             | **Yes**     |
| Local docs preview   | `uv sync --group docs`                      | No          |
| Ansible role testing | `uv sync --group ansible`                   | No          |

---

## Ansible role testing

The Ansible roles ship [Molecule](https://ansible.readthedocs.io/projects/molecule/)
scenarios for integration testing. They require Docker and a separate dependency
group that is not installed by `just sync`.

```bash
# Install Docker (platform-specific, one-time)

# Install the Ansible testing toolchain into the uv environment:
uv sync --group ansible

# Run the full molecule cycle for a role:
just molecule-test nft_egress_routing
just molecule-test pyproject_install

# Iterate without destroying the container:
just molecule-converge nft_egress_routing   # apply role
just molecule-verify  nft_egress_routing    # re-run assertions
just molecule-destroy nft_egress_routing    # clean up

# Static analysis for all roles and playbooks:
just ansible-lint
```

You can also run one-off Ansible commands without permanently adding the group to
your environment:

```bash
uv run --group ansible ansible-lint
uv run --group ansible molecule test   # from inside a role directory
```

---

## uv.lock and reproducibility

`uv.lock` is committed to the repository. It pins every transitive dependency
to an exact version, making builds fully reproducible.

- **Adding a dependency**: edit `pyproject.toml`, then run `just sync`.
  uv updates `uv.lock` automatically. Commit both files together.
- **CI pipelines** use `--locked` to verify that `uv.lock` reflects the current
  `pyproject.toml`. If the lockfile is stale the pipeline fails early with a
  clear error rather than silently using unexpected package versions.
- **`uv.lock` is not for end users**: people who install `opscat` from PyPI get
  their own dependency resolution. The lockfile only affects this repository's
  own test and build environment.
