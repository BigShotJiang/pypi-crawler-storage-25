# opscat

Ansible collection for DevOps

## Highlights

- Built with `uv`, `ruff`, `ty`, `pytest`, `zensical`, and `Typer`.
- Packaged from `src/opscat`.
- Published documentation lives at <https://ak1ra-lab.github.io/ansible-collection-opscat/>.

## Quick start

```bash
just sync
uv run opscat
```
