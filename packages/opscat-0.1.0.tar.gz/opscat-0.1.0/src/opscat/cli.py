import typer

app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)


@app.command()
def info() -> None:
    typer.echo("opscat is ready.")
