from __future__ import annotations

import tomllib
from pathlib import Path


def load_config(path: Path) -> dict:
    """Load and return the TOML configuration file."""
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with path.open("rb") as fh:
        return tomllib.load(fh)
