from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

RT_TABLES_DIR = Path("/etc/iproute2/rt_tables.d")


# ---------------------------------------------------------------------------
# Routing group
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RoutingGroup:
    """One unique (fwmark, routing-table) pair that receives egress traffic."""

    fwmark: str
    routing_table_id: int
    routing_table_name: str
    nexthop: str
    nexthop6: str
    nexthop_dev: str


def _resolve_groups(config: dict) -> list[RoutingGroup]:
    """
    Derive the ordered list of unique RoutingGroups from the provider config.

    Providers that share the same (nexthop, nexthop6, nexthop_dev) tuple are
    collapsed into one RoutingGroup so that ip rule/route commands are issued
    only once per unique nexthop combination.
    """
    global_cfg = config.get("global", {})
    prefix = global_cfg.get("routing_table_name_prefix", "nft_egress_routing")
    id_start = int(global_cfg.get("routing_table_id_start", 232))
    fwmark_start = global_cfg.get("fwmark_start", "0xe8")

    global_nexthop_key = (
        global_cfg.get("gateway", ""),
        global_cfg.get("gateway6", ""),
        global_cfg.get("gateway_dev", ""),
    )

    # nexthop_key → RoutingGroup; preserves encounter order via dict insertion.
    nexthop_to_group: dict[tuple[str, str, str], RoutingGroup] = {}
    extra_group_count = 0  # number of distinct non-default nexthop groups seen

    for name, cfg in config.get("providers", {}).items():
        if not cfg.get("enabled", False):
            continue

        nexthop = cfg.get("nexthop", global_cfg.get("gateway", ""))
        nexthop6 = cfg.get("nexthop6", global_cfg.get("gateway6", ""))
        nexthop_dev = cfg.get("nexthop_dev", global_cfg.get("gateway_dev", ""))
        nexthop_key = (nexthop, nexthop6, nexthop_dev)

        if nexthop_key in nexthop_to_group:
            continue  # already have a RoutingGroup for this nexthop combination

        if nexthop_key == global_nexthop_key:
            group = RoutingGroup(
                fwmark=cfg.get("fwmark", fwmark_start),
                routing_table_id=int(cfg.get("routing_table_id", id_start)),
                routing_table_name=cfg.get("routing_table_name", prefix),
                nexthop=nexthop,
                nexthop6=nexthop6,
                nexthop_dev=nexthop_dev,
            )
        else:
            # Per-provider nexthop: fwmark must be explicit because the
            # nftables template also needs it at Ansible render time.
            if "fwmark" not in cfg:
                logger.error(
                    "Provider {!r} has a per-provider nexthop ({}) but no explicit "
                    "'fwmark'. Providers with a unique nexthop must set 'fwmark' "
                    "in their config block so the nftables template can reference it.",
                    name,
                    nexthop or nexthop6 or nexthop_dev,
                )
                sys.exit(1)
            extra_group_count += 1
            group = RoutingGroup(
                fwmark=cfg["fwmark"],
                routing_table_id=int(
                    cfg.get("routing_table_id", id_start + extra_group_count)
                ),
                routing_table_name=cfg.get("routing_table_name", f"{prefix}_{name}"),
                nexthop=nexthop,
                nexthop6=nexthop6,
                nexthop_dev=nexthop_dev,
            )

        nexthop_to_group[nexthop_key] = group

    groups = list(nexthop_to_group.values())

    # No enabled providers: still install the basic rule/route for the default group.
    if not groups:
        groups.append(
            RoutingGroup(
                fwmark=fwmark_start,
                routing_table_id=id_start,
                routing_table_name=prefix,
                nexthop=global_cfg.get("gateway", ""),
                nexthop6=global_cfg.get("gateway6", ""),
                nexthop_dev=global_cfg.get("gateway_dev", ""),
            )
        )

    return groups


# ---------------------------------------------------------------------------
# iproute2 helpers
# ---------------------------------------------------------------------------


def _run(args: list[str], *, check: bool = True) -> int:
    """Run an ip(8) command; return the exit code."""
    logger.debug("Running: {}", " ".join(args))
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode != 0:
        if check:
            logger.error(
                "Command failed (exit {}): {}\n{}",
                result.returncode,
                " ".join(args),
                result.stderr.strip(),
            )
            sys.exit(1)
        else:
            logger.debug(
                "Ignored non-zero exit {}: {}", result.returncode, result.stderr.strip()
            )
    return result.returncode


def _ipv4_route_args(group: RoutingGroup) -> list[str]:
    args = ["default"]
    if group.nexthop:
        args += ["via", group.nexthop]
    if group.nexthop_dev:
        args += ["dev", group.nexthop_dev]
    args += ["table", group.routing_table_name]
    return args


def _ipv6_route_args(group: RoutingGroup) -> list[str]:
    args = ["default"]
    if group.nexthop6:
        args += ["via", group.nexthop6]
    if group.nexthop_dev:
        args += ["dev", group.nexthop_dev]
    args += ["table", group.routing_table_name]
    return args


def _rt_tables_path(group: RoutingGroup) -> Path:
    return RT_TABLES_DIR / f"nft-egress-routing-{group.routing_table_name}.conf"


# ---------------------------------------------------------------------------
# Setup / teardown
# ---------------------------------------------------------------------------


def setup(groups: list[RoutingGroup]) -> None:
    """Install ip rules and ip routes for each routing group."""
    RT_TABLES_DIR.mkdir(parents=True, exist_ok=True)

    for group in groups:
        logger.info(
            "Setting up routing group: fwmark={} table={} ({})",
            group.fwmark,
            group.routing_table_name,
            group.routing_table_id,
        )

        # Register routing table name.
        path = _rt_tables_path(group)
        path.write_text(f"{group.routing_table_id} {group.routing_table_name}\n")
        logger.debug("Wrote {}", path)

        # IPv4 — always required (gateway or dev must be set).
        _run(
            [
                "ip",
                "-4",
                "rule",
                "del",
                "fwmark",
                group.fwmark,
                "lookup",
                group.routing_table_name,
            ],
            check=False,
        )
        _run(
            ["ip", "-4", "route", "del", "default", "table", group.routing_table_name],
            check=False,
        )
        _run(
            [
                "ip",
                "-4",
                "rule",
                "add",
                "fwmark",
                group.fwmark,
                "lookup",
                group.routing_table_name,
            ],
        )
        _run(
            ["ip", "-4", "route", "add"] + _ipv4_route_args(group),
        )

        # IPv6 — only if a nexthop6 or dev is provided.
        if group.nexthop6 or group.nexthop_dev:
            _run(
                [
                    "ip",
                    "-6",
                    "rule",
                    "del",
                    "fwmark",
                    group.fwmark,
                    "lookup",
                    group.routing_table_name,
                ],
                check=False,
            )
            _run(
                [
                    "ip",
                    "-6",
                    "route",
                    "del",
                    "default",
                    "table",
                    group.routing_table_name,
                ],
                check=False,
            )
            _run(
                [
                    "ip",
                    "-6",
                    "rule",
                    "add",
                    "fwmark",
                    group.fwmark,
                    "lookup",
                    group.routing_table_name,
                ],
            )
            _run(
                ["ip", "-6", "route", "add"] + _ipv6_route_args(group),
            )
        else:
            logger.debug(
                "Skipping IPv6 routing for group {} (no nexthop6 or nexthop_dev).",
                group.routing_table_name,
            )

    logger.info("Routing setup complete.")


def teardown(groups: list[RoutingGroup]) -> None:
    """Remove ip routes, ip rules, and rt_tables.d entries for each group."""
    for group in groups:
        logger.info(
            "Tearing down routing group: fwmark={} table={} ({})",
            group.fwmark,
            group.routing_table_name,
            group.routing_table_id,
        )

        # IPv6 first (routes before rules).
        if group.nexthop6 or group.nexthop_dev:
            _run(
                [
                    "ip",
                    "-6",
                    "route",
                    "del",
                    "default",
                    "table",
                    group.routing_table_name,
                ],
                check=False,
            )
            _run(
                [
                    "ip",
                    "-6",
                    "rule",
                    "del",
                    "fwmark",
                    group.fwmark,
                    "lookup",
                    group.routing_table_name,
                ],
                check=False,
            )

        # IPv4.
        _run(
            ["ip", "-4", "route", "del", "default", "table", group.routing_table_name],
            check=False,
        )
        _run(
            [
                "ip",
                "-4",
                "rule",
                "del",
                "fwmark",
                group.fwmark,
                "lookup",
                group.routing_table_name,
            ],
            check=False,
        )

        # Remove rt_tables.d entry.
        path = _rt_tables_path(group)
        if path.exists():
            path.unlink()
            logger.debug("Removed {}", path)

    logger.info("Routing teardown complete.")
