from __future__ import annotations

from loguru import logger

from .base import Provider
from .dns import DNSProvider
from .inline import InlineListProvider
from .remote_json import RemoteJsonProvider
from .remote_text import RemoteTextProvider

__all__ = [
    "Provider",
    "DNSProvider",
    "InlineListProvider",
    "RemoteJsonProvider",
    "RemoteTextProvider",
    "_build_providers",
]

_PROVIDER_TYPES = ("remote_json", "remote_text", "inline_list", "dns")


def _build_providers(config: dict) -> dict[str, Provider]:
    global_family = config.get("global", {}).get("address_family", "any")
    raw_providers = config.get("providers", {})
    providers: dict[str, Provider] = {}

    for name, cfg in raw_providers.items():
        if not cfg.get("enabled", False):
            continue

        family = cfg.get("address_family", global_family)
        provider_type = cfg.get("type", "")

        if provider_type == "remote_json":
            providers[name] = RemoteJsonProvider(
                url=cfg["url"],
                ipv4_jmespath=cfg["ipv4_jmespath"],
                ipv4_field=cfg["ipv4_field"],
                ipv6_jmespath=cfg["ipv6_jmespath"],
                ipv6_field=cfg["ipv6_field"],
                filter_field=cfg.get("filter_field", ""),
                filter_regex=cfg.get("filter_regex", ""),
                family=family,
            )
        elif provider_type == "remote_text":
            providers[name] = RemoteTextProvider(url=cfg["url"], family=family)
        elif provider_type == "inline_list":
            providers[name] = InlineListProvider(cidrs=cfg["cidrs"], family=family)
        elif provider_type == "dns":
            providers[name] = DNSProvider(
                hostnames=cfg["hostnames"],
                family=family,
            )
        else:
            logger.warning(
                "Provider {!r} has unknown type {!r} (expected one of: {}); skipping.",
                name,
                provider_type,
                ", ".join(_PROVIDER_TYPES),
            )

    return providers
