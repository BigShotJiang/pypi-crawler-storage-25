from __future__ import annotations

import ipaddress

from .base import Provider


class InlineListProvider(Provider):
    """
    Use a static list of CIDRs embedded directly in the config file.

    The 'address_family' setting controls which families are returned:
      - 'ipv4': IPv4 CIDRs only
      - 'ipv6': IPv6 CIDRs only
      - 'any':  both (default)

    CIDRs are classified by parsing with ipaddress.ip_network(); mixed
    IPv4/IPv6 lists are handled transparently.
    """

    def __init__(self, cidrs: list[str], family: str = "any") -> None:
        self._family = family
        self._ipv4: list[str] = []
        self._ipv6: list[str] = []
        for cidr in cidrs:
            net = ipaddress.ip_network(cidr, strict=False)
            if isinstance(net, ipaddress.IPv4Network):
                self._ipv4.append(str(net))
            else:
                self._ipv6.append(str(net))

    def fetch_ipv4(self) -> list[str]:
        return [] if self._family == "ipv6" else list(self._ipv4)

    def fetch_ipv6(self) -> list[str]:
        return [] if self._family == "ipv4" else list(self._ipv6)
