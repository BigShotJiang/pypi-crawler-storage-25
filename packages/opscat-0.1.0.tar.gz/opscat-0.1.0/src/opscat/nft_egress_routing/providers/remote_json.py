from __future__ import annotations

import re

import httpx
import jmespath

from .base import Provider


class RemoteJsonProvider(Provider):
    """
    Fetch a JSON document and extract CIDRs using jmespath expressions.

    Config keys:
      url            — HTTP(S) URL to fetch
      ipv4_jmespath  — jmespath expression selecting the IPv4 item list
      ipv4_field     — key within each item holding the IPv4 prefix string
      ipv6_jmespath  — jmespath expression selecting the IPv6 item list
                       (may differ from ipv4_jmespath, e.g. AWS uses separate arrays)
      ipv6_field     — key within each item holding the IPv6 prefix string
      filter_field   — (optional) item key to match against filter_regex
      filter_regex   — (optional) Python regex; items not matching are skipped

    Items missing the target field are silently skipped (e.g. the GCloud
    prefix list mixes ipv4Prefix-only and ipv6Prefix-only objects).

    The 'address_family' setting controls which families are returned:
      - 'ipv4': IPv4 only
      - 'ipv6': IPv6 only
      - 'any':  both (default)
    """

    def __init__(
        self,
        url: str,
        ipv4_jmespath: str,
        ipv4_field: str,
        ipv6_jmespath: str,
        ipv6_field: str,
        filter_field: str = "",
        filter_regex: str = "",
        family: str = "any",
    ) -> None:
        self._url = url
        self._ipv4_jmespath = ipv4_jmespath
        self._ipv4_field = ipv4_field
        self._ipv6_jmespath = ipv6_jmespath
        self._ipv6_field = ipv6_field
        self._filter_field = filter_field
        self._filter_re = re.compile(filter_regex) if filter_regex else None
        self._family = family
        self._data: dict | None = None

    def _fetch(self) -> dict:
        if self._data is None:
            resp = httpx.get(self._url, timeout=30, follow_redirects=True)
            resp.raise_for_status()
            self._data = resp.json()
        return self._data

    def _extract(self, jmespath_expr: str, field: str) -> list[str]:
        items = jmespath.search(jmespath_expr, self._fetch()) or []
        result = []
        for item in items:
            if self._filter_re and not self._filter_re.search(
                item.get(self._filter_field, "")
            ):
                continue
            value = item.get(field)
            if value is not None:
                result.append(value)
        return result

    def fetch_ipv4(self) -> list[str]:
        if self._family == "ipv6":
            return []
        return self._extract(self._ipv4_jmespath, self._ipv4_field)

    def fetch_ipv6(self) -> list[str]:
        if self._family == "ipv4":
            return []
        return self._extract(self._ipv6_jmespath, self._ipv6_field)
