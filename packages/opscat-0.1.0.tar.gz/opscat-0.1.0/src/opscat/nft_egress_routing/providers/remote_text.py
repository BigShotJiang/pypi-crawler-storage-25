from __future__ import annotations

import ipaddress

import httpx
from loguru import logger

from .base import Provider


class RemoteTextProvider(Provider):
    """
    Fetch a plaintext file where each non-blank, non-comment line is a CIDR.

    Lines beginning with '#' or ';' are treated as comments and skipped.
    CIDRs are classified by ipaddress.ip_network(); mixed IPv4/IPv6 files
    are handled transparently.

    The 'address_family' setting controls which families are returned:
      - 'ipv4': IPv4 CIDRs only
      - 'ipv6': IPv6 CIDRs only
      - 'any':  both (default)
    """

    def __init__(self, url: str, family: str = "any") -> None:
        self._url = url
        self._family = family
        self._cache: tuple[list[str], list[str]] | None = None

    def _fetch(self) -> tuple[list[str], list[str]]:
        if self._cache is None:
            resp = httpx.get(self._url, timeout=30, follow_redirects=True)
            resp.raise_for_status()
            ipv4: list[str] = []
            ipv6: list[str] = []
            for raw in resp.text.splitlines():
                line = raw.strip()
                if not line or line.startswith(("#", ";")):
                    continue
                try:
                    net = ipaddress.ip_network(line, strict=False)
                except ValueError:
                    logger.warning(
                        "Skipping invalid CIDR {!r} from {}", line, self._url
                    )
                    continue
                if isinstance(net, ipaddress.IPv4Network):
                    ipv4.append(str(net))
                else:
                    ipv6.append(str(net))
            self._cache = (ipv4, ipv6)
        return self._cache

    def fetch_ipv4(self) -> list[str]:
        if self._family == "ipv6":
            return []
        ipv4, _ = self._fetch()
        return ipv4

    def fetch_ipv6(self) -> list[str]:
        if self._family == "ipv4":
            return []
        _, ipv6 = self._fetch()
        return ipv6
