from __future__ import annotations

from abc import ABC, abstractmethod


class Provider(ABC):
    """Return IPv4 and IPv6 CIDR lists for a named nftables set pair."""

    @abstractmethod
    def fetch_ipv4(self) -> list[str]:
        """Return a list of IPv4 CIDR strings, e.g. '1.2.3.0/24'."""

    @abstractmethod
    def fetch_ipv6(self) -> list[str]:
        """Return a list of IPv6 CIDR strings, e.g. '2001:db8::/32'."""
