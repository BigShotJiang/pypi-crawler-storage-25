from __future__ import annotations

import socket

from loguru import logger

from .base import Provider


class DNSProvider(Provider):
    """
    Resolve hostnames to IP addresses; A records become /32, AAAA -> /128.

    The 'address_family' setting controls which address families are returned:
      - 'ipv4': A records only
      - 'ipv6': AAAA records only
      - 'any':  both (default)

    Resolution failures are logged as warnings; the hostname is skipped.
    """

    def __init__(self, hostnames: list[str], family: str = "any") -> None:
        self._hostnames = hostnames
        self._family = family
        self._cache: dict[str, tuple[list[str], list[str]]] = {}

    def _resolve(self, hostname: str) -> tuple[list[str], list[str]]:
        if hostname not in self._cache:
            try:
                results = socket.getaddrinfo(hostname, None)
            except socket.gaierror as exc:
                logger.warning("DNS resolution failed for {!r}: {}", hostname, exc)
                self._cache[hostname] = ([], [])
            else:
                ipv4 = sorted(
                    {
                        str(addr[0])
                        for family, *_, addr in results
                        if family == socket.AF_INET
                    }
                )
                ipv6 = sorted(
                    {
                        str(addr[0])
                        for family, *_, addr in results
                        if family == socket.AF_INET6
                    }
                )
                self._cache[hostname] = (ipv4, ipv6)
        return self._cache[hostname]

    def fetch_ipv4(self) -> list[str]:
        if self._family == "ipv6":
            return []
        result = []
        for hostname in self._hostnames:
            ipv4, _ = self._resolve(hostname)
            result.extend(f"{ip}/32" for ip in ipv4)
        return result

    def fetch_ipv6(self) -> list[str]:
        if self._family == "ipv4":
            return []
        result = []
        for hostname in self._hostnames:
            _, ipv6 = self._resolve(hostname)
            result.extend(f"{ip}/128" for ip in ipv6)
        return result
