from __future__ import annotations

import sys
from pathlib import Path

import typer
from loguru import logger

from .config import load_config
from .nftables import NftablesUpdater, _get_existing_sets
from .providers import _build_providers
from .routing import _resolve_groups, setup, teardown

DEFAULT_CONFIG = Path("/etc/opscat/nft-egress-routing.toml")

app = typer.Typer(
    name="nft-egress-routing",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)

sets_app = typer.Typer(help="Manage nftables sets for policy-based routing")
rule_app = typer.Typer(help="Manage ip rule / ip route for policy-based routing")

app.add_typer(sets_app, name="sets")
app.add_typer(rule_app, name="rule")


@app.callback()
def main_callback(
    log_level: str = typer.Option(
        "INFO",
        "--log-level",
        "-l",
        help="Log level: TRACE, DEBUG, INFO, WARNING, ERROR, CRITICAL",
        envvar="NFT_EGRESS_ROUTING_LOG_LEVEL",
    ),
) -> None:
    """nft-egress-routing — Policy-based routing management via nftables."""
    logger.remove()
    try:
        logger.add(
            sys.stderr,
            level=log_level.upper(),
            colorize=sys.stderr.isatty(),
            format="{level}: {message}",
        )
    except ValueError as exc:
        typer.echo(f"Invalid --log-level {log_level!r}: {exc}", err=True)
        raise typer.Exit(code=1)


@sets_app.command("update")
def sets_update(
    config: Path = typer.Option(DEFAULT_CONFIG, help="Path to TOML config file"),
) -> None:
    """Fetch IP ranges from providers and atomically refresh nftables sets."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)

    table = cfg.get("nftables", {}).get("table", "nft_egress_routing")
    updater = NftablesUpdater(table)
    providers = _build_providers(cfg)

    if not providers:
        logger.warning("No providers enabled in {}; nothing to do.", config)
        return

    global_family = cfg.get("global", {}).get("address_family", "any")
    enabled_sets: set[str] = set()

    for name, provider in providers.items():
        logger.info("Fetching IP ranges from provider: {}", name)
        try:
            ipv4 = provider.fetch_ipv4()
            ipv6 = provider.fetch_ipv6()
        except Exception as exc:
            logger.error("Provider {!r} failed: {}", name, exc)
            raise typer.Exit(code=1)

        logger.info("  IPv4 CIDRs: {}, IPv6 CIDRs: {}", len(ipv4), len(ipv6))

        family = cfg["providers"][name].get("address_family", global_family)
        if family != "ipv6":
            updater.update_set(f"{name}_ipv4", ipv4)
            enabled_sets.add(f"{name}_ipv4")
        if family != "ipv4":
            updater.update_set(f"{name}_ipv6", ipv6)
            enabled_sets.add(f"{name}_ipv6")

    existing = _get_existing_sets(table)
    stale = existing - enabled_sets
    if stale:
        for set_name in sorted(stale):
            logger.info("Flushing stale set: {}", set_name)
            updater.flush_set(set_name)

    updater.apply()


@sets_app.command("clean")
def sets_clean(
    config: Path = typer.Option(DEFAULT_CONFIG, help="Path to TOML config file"),
) -> None:
    """Flush all provider sets without fetching new IPs."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)

    table = cfg.get("nftables", {}).get("table", "nft_egress_routing")
    updater = NftablesUpdater(table)

    logger.info("Clean mode: flushing all existing sets in table {!r}.", table)
    for set_name in _get_existing_sets(table):
        logger.info("  Flushing set: {}", set_name)
        updater.flush_set(set_name)
    updater.apply()


@rule_app.command("setup")
def rule_setup(
    config: Path = typer.Option(DEFAULT_CONFIG, help="Path to TOML config file"),
) -> None:
    """Install ip rules and ip routes for each routing group."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    groups = _resolve_groups(cfg)
    setup(groups)


@rule_app.command("teardown")
def rule_teardown(
    config: Path = typer.Option(DEFAULT_CONFIG, help="Path to TOML config file"),
) -> None:
    """Remove ip routes, ip rules, and rt_tables.d entries."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1)
    groups = _resolve_groups(cfg)
    teardown(groups)
