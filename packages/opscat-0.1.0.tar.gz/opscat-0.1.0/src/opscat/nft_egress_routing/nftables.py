from __future__ import annotations

import ipaddress
import json
import subprocess
import sys

from loguru import logger


class NftablesUpdater:
    """
    Build and apply a nft transaction to refresh named sets.

    All updates are batched into a single `nft -f /dev/stdin` call so that
    flush+populate is as close to atomic as nft supports.
    """

    def __init__(self, table: str) -> None:
        self._table = table
        self._lines: list[str] = []

    def update_set(self, set_name: str, cidrs: list[str]) -> None:
        """
        Flush *set_name* and repopulate it with *cidrs*.

        Overlapping or adjacent CIDRs are collapsed via
        ``ipaddress.collapse_addresses()`` so that nftables never receives
        conflicting interval entries (nftables < 1.2.0 has no auto-merge).
        """
        networks = [ipaddress.ip_network(c, strict=False) for c in cidrs]
        merged = [str(net) for net in ipaddress.collapse_addresses(networks)]
        self._lines.append(f"flush set inet {self._table} {set_name}")
        if merged:
            elements = ", ".join(merged)
            self._lines.append(
                f"add element inet {self._table} {set_name} {{ {elements} }}"
            )

    def flush_set(self, set_name: str) -> None:
        """Flush *set_name* without repopulating it (leaves the set empty)."""
        self._lines.append(f"flush set inet {self._table} {set_name}")

    def apply(self) -> None:
        """Send the accumulated nft commands to the kernel."""
        if not self._lines:
            logger.info("No sets to update.")
            return

        script = "\n".join(self._lines) + "\n"
        logger.debug("nft script:\n{}", script)

        result = subprocess.run(
            ["nft", "-f", "/dev/stdin"],
            input=script,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            logger.error(
                "nft failed (exit {}): {}", result.returncode, result.stderr.strip()
            )
            sys.exit(1)

        logger.info("nftables sets updated successfully.")


def _get_existing_sets(table: str) -> set[str]:
    """
    Return the names of sets that exist in *table* (inet family).

    Uses ``nft -j list table`` to query the kernel.  Returns an empty set
    if the table does not exist or nft fails for any reason.
    """
    result = subprocess.run(
        ["nft", "-j", "list", "table", "inet", table],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return set()
    try:
        data = json.loads(result.stdout)
        return {obj["set"]["name"] for obj in data.get("nftables", []) if "set" in obj}
    except (json.JSONDecodeError, KeyError):
        return set()
