# opscat

[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/ak1ra-lab/ansible-collection-opscat/.github%2Fworkflows%2Fpublish-to-pypi.yaml)](https://github.com/ak1ra-lab/ansible-collection-opscat/actions/workflows/publish-to-pypi.yaml)
[![PyPI - Version](https://img.shields.io/pypi/v/opscat)](https://pypi.org/project/opscat/)
[![PyPI - Version](https://img.shields.io/pypi/v/opscat?label=test-pypi&pypiBaseUrl=https%3A%2F%2Ftest.pypi.org)](https://test.pypi.org/project/opscat/)
[![Docs](https://img.shields.io/badge/docs-online-0a7ea4)](https://ak1ra-lab.github.io/ansible-collection-opscat/)

Ansible collection for DevOps

## Installation

```bash
uv sync --group dev --all-extras
```

## Usage

```bash
uv run opscat
```

## Development

```bash
just lint
just typecheck
just test
just docs-build
```

## Documentation

The published documentation site lives at <https://ak1ra-lab.github.io/ansible-collection-opscat/>, and local docs configuration is stored in `zensical.toml`.
