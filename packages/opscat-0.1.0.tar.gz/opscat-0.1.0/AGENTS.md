# AGENTS.md

## What This Project Does

This repository is a Python project with some Ansible roles together. It uses an Astral-centered toolchain for packaging, linting, type checking, testing, CLI work, and documentation. See `README.md` for user-facing setup and publishing details.

## Environment & Tooling — CRITICAL

- ALWAYS use `uv` for dependency management and command execution.
- Sync dependencies with `just sync` or `uv sync --group dev --all-extras`.
  - `--group dev` installs the dev toolchain (pytest, ruff, ty, zensical, pre-commit).
  - `--all-extras` installs optional runtime extras (httpx, jmespath for `nft-egress-routing`);
    these are now top-level imports and are required for the test suite to run.
  - Do NOT use `--all-groups` — that would also install the heavy `ansible` group.
  - Do NOT use `--locked` locally — that flag is for CI pipelines only; it prevents uv
    from updating `uv.lock` when you add a new dependency.
- Run tests with `just test` or `uv run pytest -v tests/`.
- Lint and format with `just lint`; run static typing with `just typecheck`.
- Build docs with `just docs-build` and preview them with `just docs-serve`.
- DO NOT use ad hoc `pip install` commands instead of updating `pyproject.toml`.
- DO NOT edit generated output under `site/`; rebuild it from source.

## Conventions

- Application code lives under `src/opscat`.
- Tests live under `tests/` and should track public behavior, especially the CLI.
- Documentation source lives under `docs/`, and docs configuration lives in `zensical.toml`.
- Project metadata and dependency groups are defined in `pyproject.toml`; treat that file as the source of truth for tooling changes.
- YAML files must use the `.yaml` extension (not `.yml`). If you create or rename a YAML file, always use `.yaml`.

## Testing Guidelines

- Update tests when CLI behavior, public APIs, or package layout changes.
- Prefer smoke tests for the Typer CLI plus focused unit tests for non-trivial logic.
- Keep docs commands working when changing docs pages, API docs wiring, or navigation structure.

## Common Operations

```sh
just sync                              # uv sync --group dev --all-extras (may update uv.lock)
just lint                              # ruff check --fix + ruff format
just typecheck                         # ty check src/
just test                              # pytest -v tests/
just coverage                          # pytest --cov with terminal report
just build                             # build wheel + sdist into dist/
just docs-serve                        # live-reload docs at http://localhost:8000
just docs-build                        # build static docs site into site/
just clean                             # remove dist/, site/, .pytest_cache/, htmlcov/, .coverage

# Ansible role testing (requires Docker + uv sync --group ansible first):
just ansible-lint                      # ansible-lint against roles/ and playbooks/
just molecule-test nft_egress_routing  # full molecule cycle (create→prepare→converge→verify→destroy)
just molecule-converge nft_egress_routing  # apply role without tearing down container
just molecule-verify  nft_egress_routing  # re-run assertions against existing container
just molecule-destroy nft_egress_routing  # destroy the molecule container
```
