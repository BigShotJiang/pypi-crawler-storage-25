from typer.testing import CliRunner

from opscat.cli import app

runner = CliRunner()


def test_info_command() -> None:
    result = runner.invoke(app)

    assert result.exit_code == 0
    assert "opscat is ready." in result.stdout
