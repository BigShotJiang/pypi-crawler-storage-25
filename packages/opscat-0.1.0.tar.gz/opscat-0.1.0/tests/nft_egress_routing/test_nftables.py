"""Tests for opscat.nft_egress_routing.nftables — NftablesUpdater and _get_existing_sets."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from opscat.nft_egress_routing.nftables import NftablesUpdater, _get_existing_sets

# ---------------------------------------------------------------------------
# NftablesUpdater.flush_set()
# ---------------------------------------------------------------------------


def test_flush_set_appends_correct_nft_command() -> None:
    """flush_set() appends a 'flush set inet <table> <name>' line."""
    updater = NftablesUpdater("my_table")
    updater.flush_set("test_set")

    assert updater._lines == ["flush set inet my_table test_set"]


def test_flush_set_multiple_calls_append_multiple_lines() -> None:
    """Calling flush_set() multiple times appends one line per call."""
    updater = NftablesUpdater("my_table")
    updater.flush_set("set_a")
    updater.flush_set("set_b")

    assert len(updater._lines) == 2
    assert "flush set inet my_table set_a" in updater._lines
    assert "flush set inet my_table set_b" in updater._lines


# ---------------------------------------------------------------------------
# NftablesUpdater.update_set()
# ---------------------------------------------------------------------------


def test_update_set_appends_flush_and_add_element_commands() -> None:
    """update_set() appends both a flush and an add element line."""
    updater = NftablesUpdater("my_table")
    updater.update_set("my_set", ["10.0.0.0/8"])

    assert len(updater._lines) == 2
    assert updater._lines[0] == "flush set inet my_table my_set"
    assert "add element inet my_table my_set" in updater._lines[1]
    assert "10.0.0.0/8" in updater._lines[1]


def test_update_set_collapses_adjacent_cidrs() -> None:
    """update_set() merges adjacent CIDRs via collapse_addresses()."""
    updater = NftablesUpdater("my_table")
    # 10.0.0.0/25 and 10.0.0.128/25 are adjacent and collapse to 10.0.0.0/24
    updater.update_set("my_set", ["10.0.0.0/25", "10.0.0.128/25"])

    assert len(updater._lines) == 2
    assert "10.0.0.0/24" in updater._lines[1]
    # The two individual /25 nets should NOT appear after collapsing
    assert "10.0.0.0/25" not in updater._lines[1]
    assert "10.0.0.128/25" not in updater._lines[1]


def test_update_set_collapses_overlapping_cidrs() -> None:
    """update_set() removes a subnet that is fully covered by a supernet."""
    updater = NftablesUpdater("my_table")
    # 10.0.0.0/24 is fully contained in 10.0.0.0/8
    updater.update_set("my_set", ["10.0.0.0/8", "10.0.0.0/24"])

    assert len(updater._lines) == 2
    add_line = updater._lines[1]
    assert "10.0.0.0/8" in add_line
    # The more-specific /24 should be collapsed into the /8
    assert "10.0.0.0/24" not in add_line


def test_update_set_normalises_non_strict_cidr() -> None:
    """update_set() normalises a host-bit CIDR to its network address."""
    updater = NftablesUpdater("my_table")
    # 192.168.1.1/24 has host bits set; strict=False normalises to 192.168.1.0/24
    updater.update_set("my_set", ["192.168.1.1/24"])

    assert len(updater._lines) == 2
    assert "192.168.1.0/24" in updater._lines[1]
    assert "192.168.1.1" not in updater._lines[1]


def test_update_set_with_empty_list_only_flushes() -> None:
    """update_set() with an empty CIDR list only emits a flush command."""
    updater = NftablesUpdater("my_table")
    updater.update_set("my_set", [])

    assert len(updater._lines) == 1
    assert updater._lines[0] == "flush set inet my_table my_set"


def test_update_set_with_multiple_cidrs_puts_all_in_braces() -> None:
    """update_set() includes all merged CIDRs in the add element braces."""
    updater = NftablesUpdater("my_table")
    cidrs = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]
    updater.update_set("my_set", cidrs)

    add_line = updater._lines[1]
    assert "10.0.0.0/8" in add_line
    assert "172.16.0.0/12" in add_line
    assert "192.168.0.0/16" in add_line
    # Verify the nftables set-literal syntax
    assert "{" in add_line
    assert "}" in add_line


def test_update_set_with_ipv6_cidrs() -> None:
    """update_set() handles IPv6 CIDRs correctly."""
    updater = NftablesUpdater("my_table")
    updater.update_set("ipv6_set", ["2001:db8::/32", "2001:db8:1::/48"])

    add_line = updater._lines[1]
    # 2001:db8:1::/48 is contained in 2001:db8::/32 and should be collapsed
    assert "2001:db8::/32" in add_line


# ---------------------------------------------------------------------------
# NftablesUpdater.apply()
# ---------------------------------------------------------------------------


def test_apply_does_not_call_subprocess_when_no_lines() -> None:
    """apply() does not invoke subprocess.run when _lines is empty."""
    updater = NftablesUpdater("my_table")

    with patch("subprocess.run") as mock_run:
        updater.apply()

    mock_run.assert_not_called()


def test_apply_calls_nft_with_correct_args() -> None:
    """apply() passes the accumulated script to 'nft -f /dev/stdin'."""
    updater = NftablesUpdater("my_table")
    updater.flush_set("some_set")

    mock_result = MagicMock(returncode=0, stdout="", stderr="")
    with patch("subprocess.run", return_value=mock_result) as mock_run:
        updater.apply()

    mock_run.assert_called_once()
    call_args = mock_run.call_args
    cmd = call_args[0][0]
    assert cmd == ["nft", "-f", "/dev/stdin"]


def test_apply_sends_all_lines_joined_by_newline() -> None:
    """apply() joins _lines with newlines and passes the script as stdin input."""
    updater = NftablesUpdater("my_table")
    updater.flush_set("set_a")
    updater.flush_set("set_b")

    mock_result = MagicMock(returncode=0, stdout="", stderr="")
    with patch("subprocess.run", return_value=mock_result) as mock_run:
        updater.apply()

    call_kwargs = mock_run.call_args[1]
    script: str = call_kwargs["input"]
    assert "flush set inet my_table set_a" in script
    assert "flush set inet my_table set_b" in script
    # Lines must be separated by newlines
    lines_in_script = script.strip().splitlines()
    assert len(lines_in_script) == 2


def test_apply_uses_capture_output_and_text_mode() -> None:
    """apply() calls subprocess.run with capture_output=True, text=True."""
    updater = NftablesUpdater("my_table")
    updater.flush_set("some_set")

    mock_result = MagicMock(returncode=0, stdout="", stderr="")
    with patch("subprocess.run", return_value=mock_result) as mock_run:
        updater.apply()

    call_kwargs = mock_run.call_args[1]
    assert call_kwargs.get("capture_output") is True
    assert call_kwargs.get("text") is True


def test_apply_calls_sys_exit_on_nonzero_returncode() -> None:
    """apply() calls sys.exit(1) when nft returns a non-zero exit code."""
    updater = NftablesUpdater("my_table")
    updater.flush_set("some_set")

    mock_result = MagicMock(returncode=1, stdout="", stderr="Error: table not found")
    with patch("subprocess.run", return_value=mock_result):
        with pytest.raises(SystemExit) as exc_info:
            updater.apply()

    assert exc_info.value.code == 1


def test_apply_does_not_exit_on_zero_returncode() -> None:
    """apply() does not raise SystemExit when nft returns 0."""
    updater = NftablesUpdater("my_table")
    updater.flush_set("some_set")

    mock_result = MagicMock(returncode=0, stdout="", stderr="")
    with patch("subprocess.run", return_value=mock_result):
        # Should complete without raising
        updater.apply()


# ---------------------------------------------------------------------------
# _get_existing_sets()
# ---------------------------------------------------------------------------


def test_get_existing_sets_returns_empty_set_on_nft_failure() -> None:
    """_get_existing_sets() returns an empty set when nft exits with non-zero."""
    mock_result = MagicMock(returncode=1, stdout="", stderr="Error: No such file")
    with patch("subprocess.run", return_value=mock_result):
        result = _get_existing_sets("my_table")

    assert result == set()


def test_get_existing_sets_calls_nft_json_list_table() -> None:
    """_get_existing_sets() invokes 'nft -j list table inet <table>'."""
    mock_result = MagicMock(returncode=1, stdout="", stderr="")
    with patch("subprocess.run", return_value=mock_result) as mock_run:
        _get_existing_sets("my_table")

    mock_run.assert_called_once()
    cmd = mock_run.call_args[0][0]
    assert cmd == ["nft", "-j", "list", "table", "inet", "my_table"]


def test_get_existing_sets_extracts_set_names_from_json() -> None:
    """_get_existing_sets() returns set names parsed from nft JSON output."""
    nft_json = json.dumps(
        {
            "nftables": [
                {"metainfo": {"version": "1.0.9"}},
                {"set": {"name": "provider_a_ipv4", "table": "nft_egress_routing"}},
                {"set": {"name": "provider_a_ipv6", "table": "nft_egress_routing"}},
                {"set": {"name": "provider_b_ipv4", "table": "nft_egress_routing"}},
            ]
        }
    )
    mock_result = MagicMock(returncode=0, stdout=nft_json, stderr="")
    with patch("subprocess.run", return_value=mock_result):
        result = _get_existing_sets("nft_egress_routing")

    assert result == {"provider_a_ipv4", "provider_a_ipv6", "provider_b_ipv4"}


def test_get_existing_sets_ignores_non_set_objects_in_json() -> None:
    """_get_existing_sets() only returns names of 'set' objects in the JSON."""
    nft_json = json.dumps(
        {
            "nftables": [
                {"metainfo": {"version": "1.0.9"}},
                {"table": {"name": "nft_egress_routing", "family": "inet"}},
                {"chain": {"name": "my_chain"}},
                {"set": {"name": "my_set"}},
            ]
        }
    )
    mock_result = MagicMock(returncode=0, stdout=nft_json, stderr="")
    with patch("subprocess.run", return_value=mock_result):
        result = _get_existing_sets("nft_egress_routing")

    assert result == {"my_set"}


def test_get_existing_sets_returns_empty_set_when_no_sets_in_table() -> None:
    """_get_existing_sets() returns empty set when JSON contains no 'set' objects."""
    nft_json = json.dumps(
        {
            "nftables": [
                {"metainfo": {"version": "1.0.9"}},
                {"table": {"name": "nft_egress_routing", "family": "inet"}},
            ]
        }
    )
    mock_result = MagicMock(returncode=0, stdout=nft_json, stderr="")
    with patch("subprocess.run", return_value=mock_result):
        result = _get_existing_sets("nft_egress_routing")

    assert result == set()


def test_get_existing_sets_returns_empty_set_on_json_decode_error() -> None:
    """_get_existing_sets() returns empty set when stdout is not valid JSON."""
    mock_result = MagicMock(returncode=0, stdout="not valid json {{{", stderr="")
    with patch("subprocess.run", return_value=mock_result):
        result = _get_existing_sets("my_table")

    assert result == set()


def test_get_existing_sets_returns_empty_set_on_empty_stdout() -> None:
    """_get_existing_sets() returns empty set when stdout is empty."""
    mock_result = MagicMock(returncode=0, stdout="", stderr="")
    with patch("subprocess.run", return_value=mock_result):
        result = _get_existing_sets("my_table")

    assert result == set()


def test_get_existing_sets_returns_empty_set_on_malformed_json_structure() -> None:
    """_get_existing_sets() returns empty set when JSON structure is unexpected."""
    # Valid JSON but missing the expected 'nftables' key
    mock_result = MagicMock(returncode=0, stdout='{"unexpected": []}', stderr="")
    with patch("subprocess.run", return_value=mock_result):
        result = _get_existing_sets("my_table")

    # get("nftables", []) returns [] so iteration yields nothing
    assert result == set()
