"""Tests for opscat.nft_egress_routing.config — load_config()."""

from __future__ import annotations

from pathlib import Path

import pytest

from opscat.nft_egress_routing.config import load_config

# ---------------------------------------------------------------------------
# load_config()
# ---------------------------------------------------------------------------


def test_load_config_returns_dict_for_valid_toml(tmp_path: Path) -> None:
    """load_config() returns a dict when given a valid TOML file."""
    toml_file = tmp_path / "config.toml"
    toml_file.write_text('[nftables]\ntable = "test_table"\n', encoding="utf-8")

    result = load_config(toml_file)

    assert isinstance(result, dict)
    assert result["nftables"]["table"] == "test_table"


def test_load_config_raises_file_not_found_when_missing(tmp_path: Path) -> None:
    """load_config() raises FileNotFoundError when the path does not exist."""
    missing = tmp_path / "nonexistent.toml"

    with pytest.raises(FileNotFoundError, match="Config file not found"):
        load_config(missing)


def test_load_config_returns_empty_dict_for_empty_file(tmp_path: Path) -> None:
    """load_config() returns an empty dict for a valid but empty TOML file."""
    empty_file = tmp_path / "empty.toml"
    empty_file.write_text("", encoding="utf-8")

    result = load_config(empty_file)

    assert result == {}


def test_load_config_parses_nftables_section(tmp_path: Path) -> None:
    """load_config() correctly parses the [nftables] section."""
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        '[nftables]\ntable = "nft_egress_routing"\n',
        encoding="utf-8",
    )

    result = load_config(toml_file)

    assert result["nftables"]["table"] == "nft_egress_routing"


def test_load_config_parses_global_section(tmp_path: Path) -> None:
    """load_config() correctly parses the [global] section."""
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        "[global]\n"
        'address_family = "any"\n'
        'gateway = "192.168.1.1"\n'
        'gateway6 = ""\n'
        'gateway_dev = ""\n'
        'routing_table_name_prefix = "nft_egress_routing"\n'
        "routing_table_id_start = 232\n"
        'fwmark_start = "0xe8"\n',
        encoding="utf-8",
    )

    result = load_config(toml_file)

    global_cfg = result["global"]
    assert global_cfg["address_family"] == "any"
    assert global_cfg["gateway"] == "192.168.1.1"
    assert global_cfg["routing_table_id_start"] == 232
    assert global_cfg["fwmark_start"] == "0xe8"


def test_load_config_parses_providers_section(tmp_path: Path) -> None:
    """load_config() correctly parses the [providers] section with inline_list type."""
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        "[providers.my_provider]\n"
        "enabled = true\n"
        'type = "inline_list"\n'
        'address_family = "ipv4"\n'
        'cidrs = ["10.0.0.0/8", "192.168.0.0/16"]\n',
        encoding="utf-8",
    )

    result = load_config(toml_file)

    provider = result["providers"]["my_provider"]
    assert provider["enabled"] is True
    assert provider["type"] == "inline_list"
    assert provider["address_family"] == "ipv4"
    assert "10.0.0.0/8" in provider["cidrs"]
    assert "192.168.0.0/16" in provider["cidrs"]


def test_load_config_parses_full_config(tmp_path: Path) -> None:
    """load_config() correctly parses a full config with all sections."""
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        '[nftables]\ntable = "nft_egress_routing"\n'
        "\n"
        "[global]\n"
        'address_family = "any"\n'
        'gateway = "10.0.0.1"\n'
        "\n"
        "[providers.rfc1918]\n"
        "enabled = true\n"
        'type = "inline_list"\n'
        'cidrs = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]\n'
        "\n"
        "[providers.my_dns]\n"
        "enabled = false\n"
        'type = "dns"\n'
        'hostnames = ["example.com"]\n',
        encoding="utf-8",
    )

    result = load_config(toml_file)

    assert result["nftables"]["table"] == "nft_egress_routing"
    assert result["global"]["gateway"] == "10.0.0.1"
    assert result["providers"]["rfc1918"]["enabled"] is True
    assert result["providers"]["rfc1918"]["type"] == "inline_list"
    assert len(result["providers"]["rfc1918"]["cidrs"]) == 3
    assert result["providers"]["my_dns"]["enabled"] is False
    assert result["providers"]["my_dns"]["hostnames"] == ["example.com"]


def test_load_config_error_message_contains_path(tmp_path: Path) -> None:
    """FileNotFoundError raised by load_config() includes the missing path."""
    missing = tmp_path / "does_not_exist.toml"

    with pytest.raises(FileNotFoundError) as exc_info:
        load_config(missing)

    assert str(missing) in str(exc_info.value)


def test_load_config_accepts_path_object(tmp_path: Path) -> None:
    """load_config() works correctly when given a pathlib.Path argument."""
    toml_file = tmp_path / "config.toml"
    toml_file.write_text('key = "value"\n', encoding="utf-8")

    result = load_config(Path(toml_file))

    assert result["key"] == "value"
