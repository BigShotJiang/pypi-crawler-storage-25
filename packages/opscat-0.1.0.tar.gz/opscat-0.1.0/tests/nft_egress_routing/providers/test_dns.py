"""Tests for opscat.nft_egress_routing.providers.dns — DNSProvider."""

from __future__ import annotations

import socket
from unittest.mock import patch

from opscat.nft_egress_routing.providers.dns import DNSProvider

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_a_result(ip: str) -> tuple:
    """Return a getaddrinfo result tuple for an IPv4 address."""
    return (socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, 0))


def _make_aaaa_result(ip: str) -> tuple:
    """Return a getaddrinfo result tuple for an IPv6 address."""
    return (socket.AF_INET6, socket.SOCK_STREAM, 6, "", (ip, 0, 0, 0))


# ---------------------------------------------------------------------------
# A record → /32, AAAA record → /128
# ---------------------------------------------------------------------------


def test_a_record_resolves_to_slash32() -> None:
    """IPv4 addresses from A records are returned as /32 CIDRs."""
    fake_results = [_make_a_result("1.2.3.4")]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="any")
        result = provider.fetch_ipv4()

    assert result == ["1.2.3.4/32"]


def test_aaaa_record_resolves_to_slash128() -> None:
    """IPv6 addresses from AAAA records are returned as /128 CIDRs."""
    fake_results = [_make_aaaa_result("2001:db8::1")]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="any")
        result = provider.fetch_ipv6()

    assert result == ["2001:db8::1/128"]


def test_mixed_a_and_aaaa_records_are_split_by_family() -> None:
    """A and AAAA records from the same hostname are split into IPv4 and IPv6 results."""
    fake_results = [
        _make_a_result("1.2.3.4"),
        _make_aaaa_result("2001:db8::1"),
    ]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="any")
        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    assert "1.2.3.4/32" in ipv4
    assert "2001:db8::1/128" in ipv6


def test_multiple_a_records_for_same_hostname_all_returned() -> None:
    """All distinct IPv4 addresses for a hostname are included."""
    fake_results = [
        _make_a_result("1.2.3.4"),
        _make_a_result("1.2.3.5"),
        _make_a_result("1.2.3.6"),
    ]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="any")
        result = provider.fetch_ipv4()

    assert "1.2.3.4/32" in result
    assert "1.2.3.5/32" in result
    assert "1.2.3.6/32" in result


def test_multiple_hostnames_results_are_concatenated() -> None:
    """Addresses from multiple hostnames are all included in the output."""

    def fake_getaddrinfo(hostname, port, **kwargs):
        if hostname == "example.com":
            return [_make_a_result("1.2.3.4")]
        if hostname == "example.org":
            return [_make_a_result("5.6.7.8")]
        return []

    with patch("socket.getaddrinfo", side_effect=fake_getaddrinfo):
        provider = DNSProvider(hostnames=["example.com", "example.org"], family="any")
        result = provider.fetch_ipv4()

    assert "1.2.3.4/32" in result
    assert "5.6.7.8/32" in result


def test_duplicate_ip_addresses_are_deduplicated() -> None:
    """Duplicate IP addresses from getaddrinfo are de-duplicated per hostname."""
    # getaddrinfo can return the same address multiple times with different socket types
    fake_results = [
        _make_a_result("1.2.3.4"),
        (socket.AF_INET, socket.SOCK_DGRAM, 17, "", ("1.2.3.4", 0)),
    ]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="any")
        result = provider.fetch_ipv4()

    assert result.count("1.2.3.4/32") == 1


# ---------------------------------------------------------------------------
# Resolution failure handling
# ---------------------------------------------------------------------------


def test_gaierror_is_caught_and_hostname_skipped() -> None:
    """socket.gaierror causes the hostname to be skipped; no exception is raised."""
    with patch(
        "socket.getaddrinfo", side_effect=socket.gaierror("Name or service not known")
    ):
        provider = DNSProvider(hostnames=["nonexistent.invalid"], family="any")
        result = provider.fetch_ipv4()

    assert result == []


def test_gaierror_for_one_hostname_does_not_prevent_others() -> None:
    """A resolution failure for one hostname does not block the others."""

    def fake_getaddrinfo(hostname, port, **kwargs):
        if hostname == "bad.invalid":
            raise socket.gaierror("Name or service not known")
        return [_make_a_result("1.2.3.4")]

    with patch("socket.getaddrinfo", side_effect=fake_getaddrinfo):
        provider = DNSProvider(hostnames=["bad.invalid", "example.com"], family="any")
        result = provider.fetch_ipv4()

    assert "1.2.3.4/32" in result


def test_gaierror_is_logged_as_warning(caplog) -> None:
    """A socket.gaierror is recorded at WARNING level."""
    import logging

    with patch("socket.getaddrinfo", side_effect=socket.gaierror("resolution failed")):
        with caplog.at_level(logging.WARNING):
            provider = DNSProvider(hostnames=["bad.invalid"], family="any")
            provider.fetch_ipv4()

    # loguru may not propagate to caplog by default; just check no exception raised
    # and result is empty; warning behaviour is verified via the empty-result check above.


def test_empty_hostnames_list_returns_empty_results() -> None:
    """An empty hostnames list produces empty lists for both families."""
    provider = DNSProvider(hostnames=[], family="any")

    with patch("socket.getaddrinfo") as mock_gai:
        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    mock_gai.assert_not_called()
    assert ipv4 == []
    assert ipv6 == []


# ---------------------------------------------------------------------------
# Caching behaviour
# ---------------------------------------------------------------------------


def test_fetch_ipv4_caches_results_second_call_does_not_call_getaddrinfo() -> None:
    """The second call to fetch_ipv4() uses the cache; getaddrinfo is called only once."""
    fake_results = [_make_a_result("1.2.3.4")]

    with patch("socket.getaddrinfo", return_value=fake_results) as mock_gai:
        provider = DNSProvider(hostnames=["example.com"], family="any")
        _ = provider.fetch_ipv4()
        _ = provider.fetch_ipv4()

    mock_gai.assert_called_once()


def test_fetch_ipv6_caches_results_second_call_does_not_call_getaddrinfo() -> None:
    """The second call to fetch_ipv6() uses the cache; getaddrinfo is called only once."""
    fake_results = [_make_aaaa_result("2001:db8::1")]

    with patch("socket.getaddrinfo", return_value=fake_results) as mock_gai:
        provider = DNSProvider(hostnames=["example.com"], family="any")
        _ = provider.fetch_ipv6()
        _ = provider.fetch_ipv6()

    mock_gai.assert_called_once()


def test_cache_is_shared_between_fetch_ipv4_and_fetch_ipv6() -> None:
    """fetch_ipv4() and fetch_ipv6() share the same resolution cache per hostname."""
    fake_results = [
        _make_a_result("1.2.3.4"),
        _make_aaaa_result("2001:db8::1"),
    ]

    with patch("socket.getaddrinfo", return_value=fake_results) as mock_gai:
        provider = DNSProvider(hostnames=["example.com"], family="any")
        _ = provider.fetch_ipv4()  # populates cache
        _ = provider.fetch_ipv6()  # should hit the same cache entry

    # getaddrinfo should be called exactly once even though both methods were called
    mock_gai.assert_called_once()


def test_gaierror_result_is_cached_so_getaddrinfo_not_retried() -> None:
    """After a failed resolution, subsequent calls do not retry getaddrinfo."""
    with patch("socket.getaddrinfo", side_effect=socket.gaierror("fail")) as mock_gai:
        provider = DNSProvider(hostnames=["bad.invalid"], family="any")
        _ = provider.fetch_ipv4()
        _ = provider.fetch_ipv4()

    mock_gai.assert_called_once()


def test_cache_stores_per_hostname_independently() -> None:
    """Each hostname has its own cache entry; they do not interfere."""
    call_count = {"n": 0}

    def fake_getaddrinfo(hostname, port, **kwargs):
        call_count["n"] += 1
        if hostname == "a.example.com":
            return [_make_a_result("1.1.1.1")]
        return [_make_a_result("2.2.2.2")]

    with patch("socket.getaddrinfo", side_effect=fake_getaddrinfo):
        provider = DNSProvider(
            hostnames=["a.example.com", "b.example.com"], family="any"
        )
        _ = provider.fetch_ipv4()
        _ = provider.fetch_ipv4()

    # Two hostnames, each resolved once = 2 calls total
    assert call_count["n"] == 2


# ---------------------------------------------------------------------------
# address_family filtering
# ---------------------------------------------------------------------------


def test_family_ipv4_fetch_ipv6_returns_empty_without_calling_resolve() -> None:
    """When family='ipv4', fetch_ipv6() returns [] without network activity."""
    with patch("socket.getaddrinfo") as mock_gai:
        provider = DNSProvider(hostnames=["example.com"], family="ipv4")
        result = provider.fetch_ipv6()

    assert result == []
    mock_gai.assert_not_called()


def test_family_ipv4_fetch_ipv4_returns_ipv4_results() -> None:
    """When family='ipv4', fetch_ipv4() returns A-record /32 CIDRs."""
    fake_results = [_make_a_result("1.2.3.4")]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="ipv4")
        result = provider.fetch_ipv4()

    assert "1.2.3.4/32" in result


def test_family_ipv6_fetch_ipv4_returns_empty_without_calling_resolve() -> None:
    """When family='ipv6', fetch_ipv4() returns [] without network activity."""
    with patch("socket.getaddrinfo") as mock_gai:
        provider = DNSProvider(hostnames=["example.com"], family="ipv6")
        result = provider.fetch_ipv4()

    assert result == []
    mock_gai.assert_not_called()


def test_family_ipv6_fetch_ipv6_returns_ipv6_results() -> None:
    """When family='ipv6', fetch_ipv6() returns AAAA-record /128 CIDRs."""
    fake_results = [_make_aaaa_result("2001:db8::1")]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="ipv6")
        result = provider.fetch_ipv6()

    assert "2001:db8::1/128" in result


def test_family_any_returns_both_ipv4_and_ipv6() -> None:
    """When family='any', both fetch_ipv4() and fetch_ipv6() return results."""
    fake_results = [
        _make_a_result("1.2.3.4"),
        _make_aaaa_result("2001:db8::1"),
    ]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"], family="any")

        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    assert "1.2.3.4/32" in ipv4
    assert "2001:db8::1/128" in ipv6


def test_default_family_is_any() -> None:
    """Omitting family= defaults to 'any'; both fetch methods return results."""
    fake_results = [
        _make_a_result("1.2.3.4"),
        _make_aaaa_result("2001:db8::1"),
    ]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["example.com"])

        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    assert ipv4 != []
    assert ipv6 != []


# ---------------------------------------------------------------------------
# Hostname returns only one family
# ---------------------------------------------------------------------------


def test_hostname_with_only_aaaa_returns_empty_ipv4_list() -> None:
    """A hostname with only AAAA records returns nothing from fetch_ipv4()."""
    fake_results = [_make_aaaa_result("2001:db8::1")]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["ipv6only.example.com"], family="any")

        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    assert ipv4 == []
    assert "2001:db8::1/128" in ipv6


def test_hostname_with_only_a_returns_empty_ipv6_list() -> None:
    """A hostname with only A records returns nothing from fetch_ipv6()."""
    fake_results = [_make_a_result("1.2.3.4")]

    with patch("socket.getaddrinfo", return_value=fake_results):
        provider = DNSProvider(hostnames=["ipv4only.example.com"], family="any")

        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    assert "1.2.3.4/32" in ipv4
    assert ipv6 == []
