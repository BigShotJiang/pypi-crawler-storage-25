"""Tests for opscat.nft_egress_routing.providers.remote_json — RemoteJsonProvider."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from opscat.nft_egress_routing.providers.remote_json import RemoteJsonProvider

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_provider(
    *,
    url: str = "http://example.com/data.json",
    ipv4_jmespath: str = "prefixes",
    ipv4_field: str = "ip_prefix",
    ipv6_jmespath: str = "ipv6_prefixes",
    ipv6_field: str = "ipv6_prefix",
    filter_field: str = "",
    filter_regex: str = "",
    family: str = "any",
) -> RemoteJsonProvider:
    """Construct a RemoteJsonProvider with sensible defaults."""
    return RemoteJsonProvider(
        url=url,
        ipv4_jmespath=ipv4_jmespath,
        ipv4_field=ipv4_field,
        ipv6_jmespath=ipv6_jmespath,
        ipv6_field=ipv6_field,
        filter_field=filter_field,
        filter_regex=filter_regex,
        family=family,
    )


def _mock_http_response(json_data: object) -> MagicMock:
    """Return a mock httpx response that returns *json_data* from .json()."""
    mock_resp = MagicMock()
    mock_resp.json.return_value = json_data
    mock_resp.raise_for_status = MagicMock()
    return mock_resp


def _patch_http_and_jmespath(json_data: object, jmespath_side_effect=None):
    """
    Context-manager factory that patches both httpx.get and jmespath.search.

    If *jmespath_side_effect* is None, jmespath.search delegates to the real
    jmespath library behaviour via a simple dict-key lookup simulation; callers
    that need precise control should pass a callable or return value instead.
    """
    raise NotImplementedError("use individual patches in each test")


# ---------------------------------------------------------------------------
# Basic extraction
# ---------------------------------------------------------------------------


def test_fetch_ipv4_extracts_field_from_jmespath_items() -> None:
    """fetch_ipv4() returns the value of ipv4_field from each item in the jmespath result."""
    json_data = {"prefixes": [{"ip_prefix": "1.2.3.0/24"}, {"ip_prefix": "5.6.0.0/16"}]}
    items = json_data["prefixes"]

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider()
            result = provider.fetch_ipv4()

    assert "1.2.3.0/24" in result
    assert "5.6.0.0/16" in result
    assert len(result) == 2


def test_fetch_ipv6_extracts_field_from_jmespath_items() -> None:
    """fetch_ipv6() returns the value of ipv6_field from each item in the jmespath result."""
    json_data = {
        "ipv6_prefixes": [
            {"ipv6_prefix": "2001:db8::/32"},
            {"ipv6_prefix": "fc00::/7"},
        ]
    }
    items = json_data["ipv6_prefixes"]

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider()
            result = provider.fetch_ipv6()

    assert "2001:db8::/32" in result
    assert "fc00::/7" in result


def test_empty_jmespath_result_returns_empty_list() -> None:
    """When jmespath.search returns an empty list, fetch_ipv4() returns []."""
    json_data: dict = {}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=[]):
            provider = _make_provider()
            result = provider.fetch_ipv4()

    assert result == []


def test_none_jmespath_result_returns_empty_list() -> None:
    """When jmespath.search returns None (expression matched nothing), result is []."""
    json_data: dict = {}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=None):
            provider = _make_provider()
            result = provider.fetch_ipv4()

    assert result == []


def test_jmespath_search_called_with_correct_ipv4_expression() -> None:
    """fetch_ipv4() passes ipv4_jmespath to jmespath.search."""
    json_data = {"my_list": [{"cidr": "10.0.0.0/8"}]}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=[]) as mock_search:
            provider = _make_provider(
                ipv4_jmespath="my_list",
                ipv4_field="cidr",
            )
            provider.fetch_ipv4()

    mock_search.assert_called_once_with("my_list", json_data)


def test_jmespath_search_called_with_correct_ipv6_expression() -> None:
    """fetch_ipv6() passes ipv6_jmespath to jmespath.search."""
    json_data = {"my_v6_list": [{"v6cidr": "2001:db8::/32"}]}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=[]) as mock_search:
            provider = _make_provider(
                ipv6_jmespath="my_v6_list",
                ipv6_field="v6cidr",
            )
            provider.fetch_ipv6()

    mock_search.assert_called_once_with("my_v6_list", json_data)


# ---------------------------------------------------------------------------
# filter_regex
# ---------------------------------------------------------------------------


def test_items_matching_filter_regex_are_included() -> None:
    """Items whose filter_field value matches filter_regex are kept."""
    items = [
        {"ip_prefix": "10.0.0.0/8", "region": "us-east-1"},
        {"ip_prefix": "172.16.0.0/12", "region": "eu-west-1"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider(
                filter_field="region",
                filter_regex="us-east",
            )
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" not in result


def test_items_not_matching_filter_regex_are_excluded() -> None:
    """Items whose filter_field value does not match filter_regex are skipped."""
    items = [
        {"ip_prefix": "10.0.0.0/8", "service": "AMAZON"},
        {"ip_prefix": "172.16.0.0/12", "service": "EC2"},
        {"ip_prefix": "192.168.0.0/16", "service": "AMAZON"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider(
                filter_field="service",
                filter_regex="^AMAZON$",
            )
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "192.168.0.0/16" in result
    assert "172.16.0.0/12" not in result


def test_filter_regex_uses_search_not_fullmatch() -> None:
    """filter_regex is matched with re.search(), so a partial match is sufficient."""
    items = [
        {"ip_prefix": "10.0.0.0/8", "tag": "prod-us-east"},
        {"ip_prefix": "172.16.0.0/12", "tag": "staging"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            # "us" appears inside "prod-us-east" — re.search should match
            provider = _make_provider(
                filter_field="tag",
                filter_regex="us",
            )
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" not in result


def test_all_items_excluded_by_filter_regex_returns_empty_list() -> None:
    """When no item matches the filter, fetch_ipv4() returns []."""
    items = [
        {"ip_prefix": "10.0.0.0/8", "service": "EC2"},
        {"ip_prefix": "172.16.0.0/12", "service": "S3"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider(
                filter_field="service",
                filter_regex="NONEXISTENT",
            )
            result = provider.fetch_ipv4()

    assert result == []


def test_no_filter_regex_includes_all_items() -> None:
    """When filter_regex is empty, all items pass the filter."""
    items = [
        {"ip_prefix": "10.0.0.0/8", "service": "EC2"},
        {"ip_prefix": "172.16.0.0/12", "service": "S3"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider(filter_field="service", filter_regex="")
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" in result


def test_filter_field_missing_from_item_uses_empty_string_for_match() -> None:
    """If filter_field key is absent, item.get() returns '' and regex is matched against ''."""
    items = [
        {"ip_prefix": "10.0.0.0/8"},  # no filter_field key
        {"ip_prefix": "172.16.0.0/12", "region": "us-east-1"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            # Regex matches "us"; item without region field gets "" which won't match
            provider = _make_provider(filter_field="region", filter_regex="us")
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" not in result
    assert "172.16.0.0/12" in result


# ---------------------------------------------------------------------------
# Missing target field handling
# ---------------------------------------------------------------------------


def test_items_missing_target_field_are_silently_skipped() -> None:
    """Items that lack the ipv4_field key are skipped without error."""
    items = [
        {"ip_prefix": "10.0.0.0/8"},
        {"ipv6_prefix": "2001:db8::/32"},  # missing ip_prefix
        {"ip_prefix": "172.16.0.0/12"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider()
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" in result
    assert len(result) == 2


def test_item_with_none_value_for_target_field_is_skipped() -> None:
    """An item where the target field's value is None is excluded from the result."""
    items = [
        {"ip_prefix": "10.0.0.0/8"},
        {"ip_prefix": None},  # explicit None value
        {"ip_prefix": "172.16.0.0/12"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider()
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" in result
    assert len(result) == 2


def test_all_items_missing_target_field_returns_empty_list() -> None:
    """When no item has the target field, fetch_ipv4() returns []."""
    items = [
        {"other_field": "foo"},
        {"another_field": "bar"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider()
            result = provider.fetch_ipv4()

    assert result == []


# ---------------------------------------------------------------------------
# address_family filtering
# ---------------------------------------------------------------------------


def test_family_ipv6_fetch_ipv4_returns_empty_without_http_request() -> None:
    """When family='ipv6', fetch_ipv4() returns [] immediately without any I/O."""
    with patch("httpx.get") as mock_get:
        with patch("jmespath.search") as mock_search:
            provider = _make_provider(family="ipv6")
            result = provider.fetch_ipv4()

    assert result == []
    mock_get.assert_not_called()
    mock_search.assert_not_called()


def test_family_ipv4_fetch_ipv6_returns_empty_without_http_request() -> None:
    """When family='ipv4', fetch_ipv6() returns [] immediately without any I/O."""
    with patch("httpx.get") as mock_get:
        with patch("jmespath.search") as mock_search:
            provider = _make_provider(family="ipv4")
            result = provider.fetch_ipv6()

    assert result == []
    mock_get.assert_not_called()
    mock_search.assert_not_called()


def test_family_ipv4_fetch_ipv4_returns_results() -> None:
    """When family='ipv4', fetch_ipv4() returns extracted IPv4 prefixes normally."""
    items = [{"ip_prefix": "10.0.0.0/8"}]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider(family="ipv4")
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result


def test_family_ipv6_fetch_ipv6_returns_results() -> None:
    """When family='ipv6', fetch_ipv6() returns extracted IPv6 prefixes normally."""
    items = [{"ipv6_prefix": "2001:db8::/32"}]
    json_data = {"ipv6_prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider(family="ipv6")
            result = provider.fetch_ipv6()

    assert "2001:db8::/32" in result


def test_family_any_both_fetch_methods_return_results() -> None:
    """When family='any', both fetch_ipv4() and fetch_ipv6() can return results."""
    v4_items = [{"ip_prefix": "10.0.0.0/8"}]
    v6_items = [{"ipv6_prefix": "2001:db8::/32"}]
    json_data = {"prefixes": v4_items, "ipv6_prefixes": v6_items}

    def fake_jmespath(expr, data):
        if expr == "prefixes":
            return v4_items
        if expr == "ipv6_prefixes":
            return v6_items
        return []

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", side_effect=fake_jmespath):
            provider = _make_provider(family="any")
            ipv4 = provider.fetch_ipv4()
            ipv6 = provider.fetch_ipv6()

    assert "10.0.0.0/8" in ipv4
    assert "2001:db8::/32" in ipv6


def test_default_family_is_any() -> None:
    """Omitting family= defaults to 'any'; both fetch methods are active."""
    v4_items = [{"ip_prefix": "10.0.0.0/8"}]
    json_data = {"prefixes": v4_items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=v4_items):
            provider = RemoteJsonProvider(
                url="http://example.com/data.json",
                ipv4_jmespath="prefixes",
                ipv4_field="ip_prefix",
                ipv6_jmespath="ipv6_prefixes",
                ipv6_field="ipv6_prefix",
            )
            # fetch_ipv4 should work (family defaults to "any")
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result


# ---------------------------------------------------------------------------
# Caching behaviour
# ---------------------------------------------------------------------------


def test_second_fetch_ipv4_call_does_not_invoke_httpx_get_again() -> None:
    """The second call to fetch_ipv4() reuses cached JSON; httpx.get called once."""
    items = [{"ip_prefix": "10.0.0.0/8"}]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)) as mock_get:
        with patch("jmespath.search", return_value=items):
            provider = _make_provider()
            _ = provider.fetch_ipv4()
            _ = provider.fetch_ipv4()

    mock_get.assert_called_once()


def test_fetch_ipv6_reuses_json_fetched_by_fetch_ipv4() -> None:
    """Calling fetch_ipv4() then fetch_ipv6() triggers only one HTTP request."""
    v4_items = [{"ip_prefix": "10.0.0.0/8"}]
    v6_items = [{"ipv6_prefix": "2001:db8::/32"}]
    json_data = {"prefixes": v4_items, "ipv6_prefixes": v6_items}

    def fake_jmespath(expr, data):
        if expr == "prefixes":
            return v4_items
        return v6_items

    with patch("httpx.get", return_value=_mock_http_response(json_data)) as mock_get:
        with patch("jmespath.search", side_effect=fake_jmespath):
            provider = _make_provider()
            _ = provider.fetch_ipv4()
            _ = provider.fetch_ipv6()

    mock_get.assert_called_once()


def test_cached_json_data_is_passed_to_jmespath_on_second_call() -> None:
    """jmespath.search receives the same data object on repeated calls."""
    items = [{"ip_prefix": "10.0.0.0/8"}]
    json_data = {"prefixes": items}
    received_data: list[object] = []

    def capturing_search(expr, data):
        received_data.append(data)
        return items

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", side_effect=capturing_search):
            provider = _make_provider()
            _ = provider.fetch_ipv4()
            _ = provider.fetch_ipv4()

    # Both jmespath calls should receive the identical data object
    assert len(received_data) == 2
    assert received_data[0] is received_data[1]


# ---------------------------------------------------------------------------
# HTTP call details
# ---------------------------------------------------------------------------


def test_httpx_get_called_with_correct_url() -> None:
    """httpx.get is invoked with the URL given at construction time."""
    target_url = "https://ip-ranges.example.com/ip-ranges.json"

    with patch("httpx.get", return_value=_mock_http_response({})) as mock_get:
        with patch("jmespath.search", return_value=[]):
            provider = _make_provider(url=target_url)
            _ = provider.fetch_ipv4()

    assert mock_get.call_args[0][0] == target_url


def test_httpx_get_called_with_follow_redirects() -> None:
    """httpx.get is called with follow_redirects=True."""
    with patch("httpx.get", return_value=_mock_http_response({})) as mock_get:
        with patch("jmespath.search", return_value=[]):
            provider = _make_provider()
            _ = provider.fetch_ipv4()

    assert mock_get.call_args[1].get("follow_redirects") is True


def test_httpx_get_called_with_timeout() -> None:
    """httpx.get is called with an explicit timeout kwarg."""
    with patch("httpx.get", return_value=_mock_http_response({})) as mock_get:
        with patch("jmespath.search", return_value=[]):
            provider = _make_provider()
            _ = provider.fetch_ipv4()

    assert "timeout" in mock_get.call_args[1]


def test_raise_for_status_is_called_on_response() -> None:
    """raise_for_status() is called on the httpx response object."""
    mock_resp = _mock_http_response({})

    with patch("httpx.get", return_value=mock_resp):
        with patch("jmespath.search", return_value=[]):
            provider = _make_provider()
            _ = provider.fetch_ipv4()

    mock_resp.raise_for_status.assert_called_once()


def test_response_json_method_is_called_to_parse_body() -> None:
    """The JSON body is obtained via resp.json(), not resp.text."""
    mock_resp = _mock_http_response({})

    with patch("httpx.get", return_value=mock_resp):
        with patch("jmespath.search", return_value=[]):
            provider = _make_provider()
            _ = provider.fetch_ipv4()

    mock_resp.json.assert_called_once()


# ---------------------------------------------------------------------------
# filter_regex with filter_field combination edge cases
# ---------------------------------------------------------------------------


def test_filter_regex_applied_independently_to_each_item() -> None:
    """filter_regex evaluation is per-item, not per-list."""
    items = [
        {"ip_prefix": "10.0.0.0/8", "svc": "AMAZON"},
        {"ip_prefix": "172.16.0.0/12", "svc": "EC2"},
        {"ip_prefix": "192.168.0.0/16", "svc": "AMAZON"},
        {"ip_prefix": "100.64.0.0/10", "svc": "EC2"},
    ]
    json_data = {"prefixes": items}

    with patch("httpx.get", return_value=_mock_http_response(json_data)):
        with patch("jmespath.search", return_value=items):
            provider = _make_provider(filter_field="svc", filter_regex="AMAZON")
            result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "192.168.0.0/16" in result
    assert "172.16.0.0/12" not in result
    assert "100.64.0.0/10" not in result
    assert len(result) == 2
