"""Tests for opscat.nft_egress_routing.providers — _build_providers()."""

from __future__ import annotations

import logging
from unittest.mock import patch

import pytest

from opscat.nft_egress_routing.providers import _build_providers
from opscat.nft_egress_routing.providers.dns import DNSProvider
from opscat.nft_egress_routing.providers.inline import InlineListProvider
from opscat.nft_egress_routing.providers.remote_json import RemoteJsonProvider
from opscat.nft_egress_routing.providers.remote_text import RemoteTextProvider

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _base_config(providers: dict) -> dict:
    """Return a minimal config dict wrapping the given providers block."""
    return {
        "global": {"address_family": "any"},
        "providers": providers,
    }


# ---------------------------------------------------------------------------
# enabled=false filtering
# ---------------------------------------------------------------------------


def test_disabled_provider_is_excluded_from_result() -> None:
    """A provider with enabled=false must not appear in the returned dict."""
    config = _base_config(
        {
            "my_inline": {
                "enabled": False,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            }
        }
    )

    result = _build_providers(config)

    assert "my_inline" not in result


def test_disabled_provider_alongside_enabled_one_only_enabled_is_returned() -> None:
    """Only enabled providers appear in the result; disabled ones are skipped."""
    config = _base_config(
        {
            "active": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            },
            "inactive": {
                "enabled": False,
                "type": "inline_list",
                "cidrs": ["172.16.0.0/12"],
            },
        }
    )

    result = _build_providers(config)

    assert "active" in result
    assert "inactive" not in result


def test_provider_without_enabled_key_is_excluded() -> None:
    """A provider whose config block omits 'enabled' is treated as disabled."""
    config = _base_config(
        {
            "no_flag": {
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            }
        }
    )

    result = _build_providers(config)

    assert "no_flag" not in result


def test_empty_providers_returns_empty_dict() -> None:
    """When there are no providers at all, _build_providers() returns {}."""
    config = _base_config({})

    result = _build_providers(config)

    assert result == {}


def test_all_disabled_providers_returns_empty_dict() -> None:
    """When every provider is disabled, the result is an empty dict."""
    config = _base_config(
        {
            "a": {"enabled": False, "type": "inline_list", "cidrs": ["10.0.0.0/8"]},
            "b": {"enabled": False, "type": "dns", "hostnames": ["example.com"]},
        }
    )

    result = _build_providers(config)

    assert result == {}


# ---------------------------------------------------------------------------
# inline_list provider construction
# ---------------------------------------------------------------------------


def test_inline_list_provider_is_constructed_correctly() -> None:
    """An enabled inline_list provider produces an InlineListProvider instance."""
    config = _base_config(
        {
            "my_inline": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8", "2001:db8::/32"],
            }
        }
    )

    result = _build_providers(config)

    assert "my_inline" in result
    assert isinstance(result["my_inline"], InlineListProvider)


def test_inline_list_provider_inherits_global_address_family() -> None:
    """When no per-provider address_family, the global value is used."""
    config = {
        "global": {"address_family": "ipv4"},
        "providers": {
            "my_inline": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8", "2001:db8::/32"],
            }
        },
    }

    result = _build_providers(config)

    provider = result["my_inline"]
    # With family="ipv4", fetch_ipv6() must return []
    assert provider.fetch_ipv6() == []


def test_inline_list_provider_per_provider_address_family_overrides_global() -> None:
    """A per-provider address_family takes precedence over the global setting."""
    config = {
        "global": {"address_family": "any"},
        "providers": {
            "my_inline": {
                "enabled": True,
                "type": "inline_list",
                "address_family": "ipv6",
                "cidrs": ["10.0.0.0/8", "2001:db8::/32"],
            }
        },
    }

    result = _build_providers(config)

    provider = result["my_inline"]
    # With family="ipv6", fetch_ipv4() must return []
    assert provider.fetch_ipv4() == []


def test_inline_list_provider_cidrs_are_accessible() -> None:
    """The inline_list provider can fetch the CIDRs supplied in the config."""
    config = _base_config(
        {
            "rfc1918": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"],
            }
        }
    )

    result = _build_providers(config)
    ipv4 = result["rfc1918"].fetch_ipv4()

    assert "10.0.0.0/8" in ipv4
    assert "172.16.0.0/12" in ipv4
    assert "192.168.0.0/16" in ipv4


# ---------------------------------------------------------------------------
# dns provider construction
# ---------------------------------------------------------------------------


def test_dns_provider_is_constructed_correctly() -> None:
    """An enabled dns provider produces a DNSProvider instance."""
    config = _base_config(
        {
            "my_dns": {
                "enabled": True,
                "type": "dns",
                "hostnames": ["example.com", "example.org"],
            }
        }
    )

    result = _build_providers(config)

    assert "my_dns" in result
    assert isinstance(result["my_dns"], DNSProvider)


def test_dns_provider_inherits_global_address_family() -> None:
    """When no per-provider address_family, the global value is passed to DNSProvider."""
    config = {
        "global": {"address_family": "ipv6"},
        "providers": {
            "my_dns": {
                "enabled": True,
                "type": "dns",
                "hostnames": ["example.com"],
            }
        },
    }

    result = _build_providers(config)

    provider = result["my_dns"]
    # With family="ipv6", fetch_ipv4() must return []
    assert provider.fetch_ipv4() == []


def test_dns_provider_hostnames_are_passed_through() -> None:
    """The hostnames list is forwarded to DNSProvider intact."""
    import socket

    fake_result = [
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("1.2.3.4", 0)),
    ]
    config = _base_config(
        {
            "my_dns": {
                "enabled": True,
                "type": "dns",
                "hostnames": ["example.com"],
            }
        }
    )

    result = _build_providers(config)

    with patch("socket.getaddrinfo", return_value=fake_result):
        ipv4 = result["my_dns"].fetch_ipv4()

    assert "1.2.3.4/32" in ipv4


# ---------------------------------------------------------------------------
# remote_text provider construction
# ---------------------------------------------------------------------------


def test_remote_text_provider_is_constructed_correctly() -> None:
    """An enabled remote_text provider produces a RemoteTextProvider instance."""
    config = _base_config(
        {
            "my_txt": {
                "enabled": True,
                "type": "remote_text",
                "url": "http://example.com/list.txt",
            }
        }
    )

    result = _build_providers(config)

    assert "my_txt" in result
    assert isinstance(result["my_txt"], RemoteTextProvider)


def test_remote_text_provider_url_is_passed_through() -> None:
    """The URL supplied in the config is forwarded to RemoteTextProvider."""
    from unittest.mock import MagicMock

    target_url = "http://example.com/my-list.txt"
    config = _base_config(
        {
            "my_txt": {
                "enabled": True,
                "type": "remote_text",
                "url": target_url,
            }
        }
    )

    result = _build_providers(config)

    mock_resp = MagicMock()
    mock_resp.text = "10.0.0.0/8\n"
    mock_resp.raise_for_status = MagicMock()

    with patch("httpx.get", return_value=mock_resp) as mock_get:
        result["my_txt"].fetch_ipv4()

    assert mock_get.call_args[0][0] == target_url


def test_remote_text_provider_inherits_global_address_family() -> None:
    """The global address_family is forwarded when the provider has none."""

    config = {
        "global": {"address_family": "ipv4"},
        "providers": {
            "my_txt": {
                "enabled": True,
                "type": "remote_text",
                "url": "http://example.com/list.txt",
            }
        },
    }

    result = _build_providers(config)
    provider = result["my_txt"]

    # family="ipv4" → fetch_ipv6() must return [] without HTTP
    with patch("httpx.get") as mock_get:
        ipv6 = provider.fetch_ipv6()

    assert ipv6 == []
    mock_get.assert_not_called()


def test_remote_text_provider_missing_url_raises_key_error() -> None:
    """Omitting 'url' for a remote_text provider raises KeyError at build time."""
    config = _base_config(
        {
            "bad_txt": {
                "enabled": True,
                "type": "remote_text",
                # 'url' is intentionally missing
            }
        }
    )

    with pytest.raises(KeyError):
        _build_providers(config)


# ---------------------------------------------------------------------------
# remote_json provider construction
# ---------------------------------------------------------------------------


def test_remote_json_provider_is_constructed_correctly() -> None:
    """An enabled remote_json provider produces a RemoteJsonProvider instance."""
    config = _base_config(
        {
            "my_json": {
                "enabled": True,
                "type": "remote_json",
                "url": "http://example.com/data.json",
                "ipv4_jmespath": "prefixes",
                "ipv4_field": "ip_prefix",
                "ipv6_jmespath": "ipv6_prefixes",
                "ipv6_field": "ipv6_prefix",
            }
        }
    )

    result = _build_providers(config)

    assert "my_json" in result
    assert isinstance(result["my_json"], RemoteJsonProvider)


def test_remote_json_provider_optional_filter_fields_default_to_empty() -> None:
    """Omitting filter_field / filter_regex does not raise; they default to ''."""
    config = _base_config(
        {
            "my_json": {
                "enabled": True,
                "type": "remote_json",
                "url": "http://example.com/data.json",
                "ipv4_jmespath": "prefixes",
                "ipv4_field": "ip_prefix",
                "ipv6_jmespath": "ipv6_prefixes",
                "ipv6_field": "ipv6_prefix",
                # filter_field and filter_regex intentionally omitted
            }
        }
    )

    # Should not raise
    result = _build_providers(config)
    assert "my_json" in result


def test_remote_json_provider_inherits_global_address_family() -> None:
    """The global address_family is forwarded to RemoteJsonProvider when not overridden."""
    config = {
        "global": {"address_family": "ipv6"},
        "providers": {
            "my_json": {
                "enabled": True,
                "type": "remote_json",
                "url": "http://example.com/data.json",
                "ipv4_jmespath": "prefixes",
                "ipv4_field": "ip_prefix",
                "ipv6_jmespath": "ipv6_prefixes",
                "ipv6_field": "ipv6_prefix",
            }
        },
    }

    result = _build_providers(config)
    provider = result["my_json"]

    # family="ipv6" → fetch_ipv4() must return [] without any I/O
    with patch("httpx.get") as mock_get:
        with patch("jmespath.search") as mock_search:
            ipv4 = provider.fetch_ipv4()

    assert ipv4 == []
    mock_get.assert_not_called()
    mock_search.assert_not_called()


def test_remote_json_provider_missing_url_raises_key_error() -> None:
    """Omitting 'url' for a remote_json provider raises KeyError at build time."""
    config = _base_config(
        {
            "bad_json": {
                "enabled": True,
                "type": "remote_json",
                # 'url' intentionally missing
                "ipv4_jmespath": "prefixes",
                "ipv4_field": "ip_prefix",
                "ipv6_jmespath": "ipv6_prefixes",
                "ipv6_field": "ipv6_prefix",
            }
        }
    )

    with pytest.raises(KeyError):
        _build_providers(config)


def test_remote_json_provider_missing_ipv4_jmespath_raises_key_error() -> None:
    """Omitting 'ipv4_jmespath' for a remote_json provider raises KeyError."""
    config = _base_config(
        {
            "bad_json": {
                "enabled": True,
                "type": "remote_json",
                "url": "http://example.com/data.json",
                # ipv4_jmespath missing
                "ipv4_field": "ip_prefix",
                "ipv6_jmespath": "ipv6_prefixes",
                "ipv6_field": "ipv6_prefix",
            }
        }
    )

    with pytest.raises(KeyError):
        _build_providers(config)


def test_remote_json_provider_missing_ipv4_field_raises_key_error() -> None:
    """Omitting 'ipv4_field' for a remote_json provider raises KeyError."""
    config = _base_config(
        {
            "bad_json": {
                "enabled": True,
                "type": "remote_json",
                "url": "http://example.com/data.json",
                "ipv4_jmespath": "prefixes",
                # ipv4_field missing
                "ipv6_jmespath": "ipv6_prefixes",
                "ipv6_field": "ipv6_prefix",
            }
        }
    )

    with pytest.raises(KeyError):
        _build_providers(config)


# ---------------------------------------------------------------------------
# Unknown provider type
# ---------------------------------------------------------------------------


def test_unknown_provider_type_is_skipped_and_not_in_result() -> None:
    """An unknown type causes the provider to be skipped; no exception is raised."""
    config = _base_config(
        {
            "mystery_provider": {
                "enabled": True,
                "type": "unknown_type_xyz",
            }
        }
    )

    # Must not raise
    result = _build_providers(config)

    assert "mystery_provider" not in result


def test_unknown_type_does_not_prevent_other_providers_from_being_built() -> None:
    """A bad type for one provider does not stop valid providers from being built."""
    config = _base_config(
        {
            "bad": {
                "enabled": True,
                "type": "this_does_not_exist",
            },
            "good": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            },
        }
    )

    result = _build_providers(config)

    assert "bad" not in result
    assert "good" in result
    assert isinstance(result["good"], InlineListProvider)


def test_unknown_type_logs_warning(caplog) -> None:
    """An unknown provider type causes a WARNING-level log message."""
    config = _base_config(
        {
            "mystery": {
                "enabled": True,
                "type": "not_a_real_type",
            }
        }
    )

    with caplog.at_level(logging.WARNING):
        _build_providers(config)

    # loguru may not propagate to caplog in all setups; just verify no crash
    # The primary assertion is test_unknown_provider_type_is_skipped_and_not_in_result


def test_provider_type_empty_string_is_treated_as_unknown() -> None:
    """An empty string for 'type' is treated as an unknown type and skipped."""
    config = _base_config(
        {
            "no_type": {
                "enabled": True,
                "type": "",
                "cidrs": ["10.0.0.0/8"],
            }
        }
    )

    result = _build_providers(config)

    assert "no_type" not in result


def test_provider_missing_type_key_is_treated_as_unknown() -> None:
    """A provider config without a 'type' key defaults to '' and is skipped."""
    config = _base_config(
        {
            "typeless": {
                "enabled": True,
                # 'type' key is absent; cfg.get("type", "") returns ""
                "cidrs": ["10.0.0.0/8"],
            }
        }
    )

    result = _build_providers(config)

    assert "typeless" not in result


# ---------------------------------------------------------------------------
# Multiple providers of different types
# ---------------------------------------------------------------------------


def test_multiple_enabled_providers_of_different_types_all_built() -> None:
    """All enabled providers across different types are included in the result."""
    config = _base_config(
        {
            "inline_one": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            },
            "dns_one": {
                "enabled": True,
                "type": "dns",
                "hostnames": ["example.com"],
            },
            "txt_one": {
                "enabled": True,
                "type": "remote_text",
                "url": "http://example.com/list.txt",
            },
            "json_one": {
                "enabled": True,
                "type": "remote_json",
                "url": "http://example.com/data.json",
                "ipv4_jmespath": "prefixes",
                "ipv4_field": "ip_prefix",
                "ipv6_jmespath": "ipv6_prefixes",
                "ipv6_field": "ipv6_prefix",
            },
        }
    )

    result = _build_providers(config)

    assert isinstance(result["inline_one"], InlineListProvider)
    assert isinstance(result["dns_one"], DNSProvider)
    assert isinstance(result["txt_one"], RemoteTextProvider)
    assert isinstance(result["json_one"], RemoteJsonProvider)
    assert len(result) == 4


def test_result_preserves_provider_names_as_keys() -> None:
    """The dict keys in the result match the provider names from the config."""
    config = _base_config(
        {
            "alpha": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            },
            "beta": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["172.16.0.0/12"],
            },
        }
    )

    result = _build_providers(config)

    assert set(result.keys()) == {"alpha", "beta"}


# ---------------------------------------------------------------------------
# Missing global address_family falls back to "any"
# ---------------------------------------------------------------------------


def test_missing_global_address_family_defaults_to_any() -> None:
    """When global.address_family is absent, providers receive 'any' as family."""
    config = {
        "global": {},  # no address_family
        "providers": {
            "my_inline": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8", "2001:db8::/32"],
            }
        },
    }

    result = _build_providers(config)
    provider = result["my_inline"]

    # family "any" → both fetch methods return results
    assert provider.fetch_ipv4() != []
    assert provider.fetch_ipv6() != []


def test_missing_global_section_defaults_to_any() -> None:
    """When the 'global' section is entirely absent, providers receive 'any'."""
    config = {
        "providers": {
            "my_inline": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8", "2001:db8::/32"],
            }
        }
    }

    result = _build_providers(config)
    provider = result["my_inline"]

    assert provider.fetch_ipv4() != []
    assert provider.fetch_ipv6() != []
