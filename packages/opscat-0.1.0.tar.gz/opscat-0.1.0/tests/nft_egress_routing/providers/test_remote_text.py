"""Tests for opscat.nft_egress_routing.providers.remote_text — RemoteTextProvider."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from opscat.nft_egress_routing.providers.remote_text import RemoteTextProvider

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_response(text: str) -> MagicMock:
    """Build a mock httpx response whose .text attribute is *text*."""
    mock_resp = MagicMock()
    mock_resp.text = text
    mock_resp.raise_for_status = MagicMock()  # no-op
    return mock_resp


# ---------------------------------------------------------------------------
# Basic CIDR parsing
# ---------------------------------------------------------------------------


def test_single_ipv4_cidr_is_parsed() -> None:
    """A single IPv4 CIDR line is returned by fetch_ipv4()."""
    with patch("httpx.get", return_value=_mock_response("1.2.3.0/24\n")):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert result == ["1.2.3.0/24"]


def test_single_ipv6_cidr_is_parsed() -> None:
    """A single IPv6 CIDR line is returned by fetch_ipv6()."""
    with patch("httpx.get", return_value=_mock_response("2001:db8::/32\n")):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv6()

    assert result == ["2001:db8::/32"]


def test_mixed_ipv4_and_ipv6_cidrs_are_split_by_family() -> None:
    """IPv4 and IPv6 CIDRs in the same file are split into their respective lists."""
    text = "10.0.0.0/8\n2001:db8::/32\n192.168.0.0/16\nfc00::/7\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    assert "10.0.0.0/8" in ipv4
    assert "192.168.0.0/16" in ipv4
    assert "2001:db8::/32" in ipv6
    assert "fc00::/7" in ipv6


def test_multiple_ipv4_cidrs_all_returned() -> None:
    """All valid IPv4 CIDRs in the file are returned."""
    text = "10.0.0.0/8\n172.16.0.0/12\n192.168.0.0/16\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert len(result) == 3
    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" in result
    assert "192.168.0.0/16" in result


# ---------------------------------------------------------------------------
# Comment and blank-line handling
# ---------------------------------------------------------------------------


def test_lines_starting_with_hash_are_skipped() -> None:
    """Lines beginning with '#' are treated as comments and excluded."""
    text = "# This is a comment\n10.0.0.0/8\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert result == ["10.0.0.0/8"]
    assert any("comment" in r for r in result) is False


def test_lines_starting_with_semicolon_are_skipped() -> None:
    """Lines beginning with ';' are treated as comments and excluded."""
    text = "; This is a comment\n10.0.0.0/8\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert result == ["10.0.0.0/8"]


def test_blank_lines_are_skipped() -> None:
    """Empty and whitespace-only lines are excluded."""
    text = "\n   \n10.0.0.0/8\n\n172.16.0.0/12\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert len(result) == 2
    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" in result


def test_mixed_comments_blanks_and_cidrs_parsed_correctly() -> None:
    """A realistic file with comments, blanks, and CIDRs is handled correctly."""
    text = (
        "# IPv4 block list\n"
        "; generated automatically\n"
        "\n"
        "10.0.0.0/8\n"
        "\n"
        "# another section\n"
        "172.16.0.0/12\n"
        "192.168.0.0/16\n"
    )
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert len(result) == 3
    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" in result
    assert "192.168.0.0/16" in result


def test_file_with_only_comments_returns_empty_lists() -> None:
    """A file containing only comments produces empty lists."""
    text = "# comment 1\n; comment 2\n# comment 3\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")

        assert provider.fetch_ipv4() == []
        assert provider.fetch_ipv6() == []


def test_empty_file_returns_empty_lists() -> None:
    """An empty response body produces empty lists for both families."""
    with patch("httpx.get", return_value=_mock_response("")):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")

        assert provider.fetch_ipv4() == []
        assert provider.fetch_ipv6() == []


# ---------------------------------------------------------------------------
# Invalid CIDR handling
# ---------------------------------------------------------------------------


def test_invalid_cidr_line_is_skipped() -> None:
    """An invalid CIDR string is skipped; valid CIDRs on other lines are returned."""
    text = "10.0.0.0/8\nnot-a-cidr\n172.16.0.0/12\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result
    assert "172.16.0.0/12" in result
    assert "not-a-cidr" not in result


def test_multiple_invalid_cidrs_are_all_skipped() -> None:
    """Multiple invalid CIDR lines are all skipped; valid ones are retained."""
    text = "bad-line\n10.0.0.0/8\nalso-bad\n192.168.0.0/16\n???\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert len(result) == 2
    assert "10.0.0.0/8" in result
    assert "192.168.0.0/16" in result


def test_all_invalid_cidrs_returns_empty_lists() -> None:
    """A file with only invalid lines produces empty lists."""
    text = "not-valid\nalso-not\n256.256.256.256/99\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")

        assert provider.fetch_ipv4() == []
        assert provider.fetch_ipv6() == []


# ---------------------------------------------------------------------------
# CIDR normalisation (strict=False)
# ---------------------------------------------------------------------------


def test_non_strict_ipv4_cidr_is_normalised() -> None:
    """192.168.1.1/24 (host bits set) is normalised to 192.168.1.0/24."""
    with patch("httpx.get", return_value=_mock_response("192.168.1.1/24\n")):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        result = provider.fetch_ipv4()

    assert result == ["192.168.1.0/24"]


# ---------------------------------------------------------------------------
# Caching behaviour
# ---------------------------------------------------------------------------


def test_second_fetch_ipv4_call_does_not_invoke_httpx_get_again() -> None:
    """fetch_ipv4() uses the cached response; httpx.get is called only once."""
    with patch("httpx.get", return_value=_mock_response("10.0.0.0/8\n")) as mock_get:
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        _ = provider.fetch_ipv4()
        _ = provider.fetch_ipv4()

    mock_get.assert_called_once()


def test_second_fetch_ipv6_call_does_not_invoke_httpx_get_again() -> None:
    """fetch_ipv6() uses the cached response; httpx.get is called only once."""
    with patch("httpx.get", return_value=_mock_response("2001:db8::/32\n")) as mock_get:
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        _ = provider.fetch_ipv6()
        _ = provider.fetch_ipv6()

    mock_get.assert_called_once()


def test_fetch_ipv4_and_fetch_ipv6_share_cache_single_http_request() -> None:
    """Calling fetch_ipv4() then fetch_ipv6() triggers only one HTTP request."""
    text = "10.0.0.0/8\n2001:db8::/32\n"
    with patch("httpx.get", return_value=_mock_response(text)) as mock_get:
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        _ = provider.fetch_ipv4()
        _ = provider.fetch_ipv6()

    mock_get.assert_called_once()


def test_cached_results_are_identical_across_calls() -> None:
    """Repeated calls to fetch_ipv4() return the same CIDRs each time."""
    with patch("httpx.get", return_value=_mock_response("10.0.0.0/8\n")):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        first = provider.fetch_ipv4()
        second = provider.fetch_ipv4()

    assert first == second


# ---------------------------------------------------------------------------
# address_family filtering
# ---------------------------------------------------------------------------


def test_family_ipv4_fetch_ipv6_returns_empty_without_http_request() -> None:
    """When family='ipv4', fetch_ipv6() returns [] immediately without fetching."""
    with patch("httpx.get") as mock_get:
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="ipv4")
        result = provider.fetch_ipv6()

    assert result == []
    mock_get.assert_not_called()


def test_family_ipv4_fetch_ipv4_returns_ipv4_cidrs() -> None:
    """When family='ipv4', fetch_ipv4() returns the IPv4 CIDRs from the response."""
    text = "10.0.0.0/8\n2001:db8::/32\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="ipv4")
        result = provider.fetch_ipv4()

    assert "10.0.0.0/8" in result


def test_family_ipv6_fetch_ipv4_returns_empty_without_http_request() -> None:
    """When family='ipv6', fetch_ipv4() returns [] immediately without fetching."""
    with patch("httpx.get") as mock_get:
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="ipv6")
        result = provider.fetch_ipv4()

    assert result == []
    mock_get.assert_not_called()


def test_family_ipv6_fetch_ipv6_returns_ipv6_cidrs() -> None:
    """When family='ipv6', fetch_ipv6() returns the IPv6 CIDRs from the response."""
    text = "10.0.0.0/8\n2001:db8::/32\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="ipv6")
        result = provider.fetch_ipv6()

    assert "2001:db8::/32" in result


def test_family_any_both_fetch_methods_return_results() -> None:
    """When family='any', both fetch_ipv4() and fetch_ipv6() return non-empty lists."""
    text = "10.0.0.0/8\n2001:db8::/32\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")

        assert provider.fetch_ipv4() != []
        assert provider.fetch_ipv6() != []


def test_default_family_is_any() -> None:
    """Omitting family= defaults to 'any'; both fetch methods return results."""
    text = "10.0.0.0/8\n2001:db8::/32\n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt")

        assert provider.fetch_ipv4() != []
        assert provider.fetch_ipv6() != []


# ---------------------------------------------------------------------------
# HTTP call details
# ---------------------------------------------------------------------------


def test_httpx_get_called_with_correct_url() -> None:
    """httpx.get is invoked with the URL supplied at construction time."""
    target_url = "http://example.com/my-list.txt"
    with patch("httpx.get", return_value=_mock_response("10.0.0.0/8\n")) as mock_get:
        provider = RemoteTextProvider(url=target_url, family="any")
        _ = provider.fetch_ipv4()

    called_url = mock_get.call_args[0][0]
    assert called_url == target_url


def test_httpx_get_called_with_follow_redirects() -> None:
    """httpx.get is called with follow_redirects=True."""
    with patch("httpx.get", return_value=_mock_response("10.0.0.0/8\n")) as mock_get:
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        _ = provider.fetch_ipv4()

    call_kwargs = mock_get.call_args[1]
    assert call_kwargs.get("follow_redirects") is True


def test_httpx_get_called_with_timeout() -> None:
    """httpx.get is called with an explicit timeout value."""
    with patch("httpx.get", return_value=_mock_response("10.0.0.0/8\n")) as mock_get:
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        _ = provider.fetch_ipv4()

    call_kwargs = mock_get.call_args[1]
    assert "timeout" in call_kwargs


def test_raise_for_status_is_called_on_response() -> None:
    """raise_for_status() is called on the response object."""
    mock_resp = _mock_response("10.0.0.0/8\n")
    with patch("httpx.get", return_value=mock_resp):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        _ = provider.fetch_ipv4()

    mock_resp.raise_for_status.assert_called_once()


# ---------------------------------------------------------------------------
# Line stripping
# ---------------------------------------------------------------------------


def test_lines_with_leading_and_trailing_whitespace_are_stripped() -> None:
    """Whitespace around a CIDR on a line is stripped before parsing."""
    text = "  10.0.0.0/8  \n  2001:db8::/32  \n"
    with patch("httpx.get", return_value=_mock_response(text)):
        provider = RemoteTextProvider(url="http://example.com/list.txt", family="any")
        ipv4 = provider.fetch_ipv4()
        ipv6 = provider.fetch_ipv6()

    assert "10.0.0.0/8" in ipv4
    assert "2001:db8::/32" in ipv6
