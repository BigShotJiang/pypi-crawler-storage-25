"""Tests for opscat.nft_egress_routing.providers.inline — InlineListProvider."""

from __future__ import annotations

import pytest

from opscat.nft_egress_routing.providers.inline import InlineListProvider

# ---------------------------------------------------------------------------
# Classification of mixed IPv4/IPv6 lists
# ---------------------------------------------------------------------------


def test_mixed_cidrs_are_classified_into_ipv4_and_ipv6() -> None:
    """IPv4 and IPv6 CIDRs in the same list are split into separate buckets."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "2001:db8::/32", "192.168.0.0/16", "fc00::/7"],
        family="any",
    )

    ipv4 = provider.fetch_ipv4()
    ipv6 = provider.fetch_ipv6()

    assert "10.0.0.0/8" in ipv4
    assert "192.168.0.0/16" in ipv4
    assert "2001:db8::/32" in ipv6
    assert "fc00::/7" in ipv6


def test_ipv4_only_cidrs_all_end_up_in_fetch_ipv4() -> None:
    """A list of pure IPv4 CIDRs produces nothing from fetch_ipv6()."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"],
        family="any",
    )

    assert len(provider.fetch_ipv4()) == 3
    assert provider.fetch_ipv6() == []


def test_ipv6_only_cidrs_all_end_up_in_fetch_ipv6() -> None:
    """A list of pure IPv6 CIDRs produces nothing from fetch_ipv4()."""
    provider = InlineListProvider(
        cidrs=["2001:db8::/32", "fc00::/7", "::1/128"],
        family="any",
    )

    assert provider.fetch_ipv4() == []
    assert len(provider.fetch_ipv6()) == 3


def test_empty_cidr_list_returns_empty_for_both_families() -> None:
    """An empty CIDR list returns empty lists for both fetch_ipv4() and fetch_ipv6()."""
    provider = InlineListProvider(cidrs=[], family="any")

    assert provider.fetch_ipv4() == []
    assert provider.fetch_ipv6() == []


# ---------------------------------------------------------------------------
# address_family filtering
# ---------------------------------------------------------------------------


def test_family_ipv4_fetch_ipv6_returns_empty_list() -> None:
    """When family='ipv4', fetch_ipv6() always returns an empty list."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "2001:db8::/32"],
        family="ipv4",
    )

    assert provider.fetch_ipv6() == []


def test_family_ipv4_fetch_ipv4_returns_ipv4_cidrs() -> None:
    """When family='ipv4', fetch_ipv4() still returns the IPv4 CIDRs."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "2001:db8::/32"],
        family="ipv4",
    )

    result = provider.fetch_ipv4()
    assert "10.0.0.0/8" in result
    assert "2001:db8::/32" not in result


def test_family_ipv6_fetch_ipv4_returns_empty_list() -> None:
    """When family='ipv6', fetch_ipv4() always returns an empty list."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "2001:db8::/32"],
        family="ipv6",
    )

    assert provider.fetch_ipv4() == []


def test_family_ipv6_fetch_ipv6_returns_ipv6_cidrs() -> None:
    """When family='ipv6', fetch_ipv6() still returns the IPv6 CIDRs."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "2001:db8::/32"],
        family="ipv6",
    )

    result = provider.fetch_ipv6()
    assert "2001:db8::/32" in result
    assert "10.0.0.0/8" not in result


def test_family_any_fetch_ipv4_returns_ipv4_cidrs() -> None:
    """When family='any', fetch_ipv4() returns IPv4 CIDRs."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "2001:db8::/32"],
        family="any",
    )

    result = provider.fetch_ipv4()
    assert "10.0.0.0/8" in result


def test_family_any_fetch_ipv6_returns_ipv6_cidrs() -> None:
    """When family='any', fetch_ipv6() returns IPv6 CIDRs."""
    provider = InlineListProvider(
        cidrs=["10.0.0.0/8", "2001:db8::/32"],
        family="any",
    )

    result = provider.fetch_ipv6()
    assert "2001:db8::/32" in result


def test_family_any_both_methods_return_their_respective_cidrs() -> None:
    """When family='any', both fetch_ipv4() and fetch_ipv6() return non-empty results."""
    provider = InlineListProvider(
        cidrs=["172.16.0.0/12", "fc00::/7"],
        family="any",
    )

    assert provider.fetch_ipv4() != []
    assert provider.fetch_ipv6() != []


# ---------------------------------------------------------------------------
# CIDR normalisation (strict=False)
# ---------------------------------------------------------------------------


def test_non_strict_ipv4_cidr_is_normalised_to_network_address() -> None:
    """192.168.1.1/24 (host bits set) is normalised to 192.168.1.0/24."""
    provider = InlineListProvider(cidrs=["192.168.1.1/24"], family="any")

    result = provider.fetch_ipv4()

    assert result == ["192.168.1.0/24"]
    assert "192.168.1.1/24" not in result


def test_non_strict_ipv6_cidr_is_normalised_to_network_address() -> None:
    """2001:db8::1/32 (host bits set) is normalised to 2001:db8::/32."""
    provider = InlineListProvider(cidrs=["2001:db8::1/32"], family="any")

    result = provider.fetch_ipv6()

    assert result == ["2001:db8::/32"]
    assert "2001:db8::1/32" not in result


def test_already_normalised_cidr_is_unchanged() -> None:
    """A CIDR with no host bits set passes through normalisation unchanged."""
    provider = InlineListProvider(cidrs=["10.0.0.0/8"], family="any")

    result = provider.fetch_ipv4()

    assert result == ["10.0.0.0/8"]


def test_host_route_slash32_is_preserved() -> None:
    """A /32 host route is valid and kept as-is."""
    provider = InlineListProvider(cidrs=["192.168.1.100/32"], family="any")

    result = provider.fetch_ipv4()

    assert result == ["192.168.1.100/32"]


def test_host_route_slash128_is_preserved() -> None:
    """A /128 host route is valid and kept as-is."""
    provider = InlineListProvider(cidrs=["2001:db8::1/128"], family="any")

    result = provider.fetch_ipv6()

    assert result == ["2001:db8::1/128"]


# ---------------------------------------------------------------------------
# Returned lists are independent copies
# ---------------------------------------------------------------------------


def test_fetch_ipv4_returns_a_copy_not_the_internal_list() -> None:
    """Mutating the list returned by fetch_ipv4() does not affect the provider."""
    provider = InlineListProvider(cidrs=["10.0.0.0/8"], family="any")

    first_call = provider.fetch_ipv4()
    first_call.append("1.2.3.4/32")  # mutate the returned list

    second_call = provider.fetch_ipv4()
    assert "1.2.3.4/32" not in second_call


def test_fetch_ipv6_returns_a_copy_not_the_internal_list() -> None:
    """Mutating the list returned by fetch_ipv6() does not affect the provider."""
    provider = InlineListProvider(cidrs=["2001:db8::/32"], family="any")

    first_call = provider.fetch_ipv6()
    first_call.append("::1/128")

    second_call = provider.fetch_ipv6()
    assert "::1/128" not in second_call


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


def test_default_family_is_any() -> None:
    """Omitting family defaults to 'any', so both fetch methods return results."""
    provider = InlineListProvider(cidrs=["10.0.0.0/8", "2001:db8::/32"])

    assert provider.fetch_ipv4() != []
    assert provider.fetch_ipv6() != []


def test_single_ipv4_cidr_classified_correctly() -> None:
    """A single IPv4 CIDR ends up only in fetch_ipv4()."""
    provider = InlineListProvider(cidrs=["10.0.0.0/8"])

    assert provider.fetch_ipv4() == ["10.0.0.0/8"]
    assert provider.fetch_ipv6() == []


def test_single_ipv6_cidr_classified_correctly() -> None:
    """A single IPv6 CIDR ends up only in fetch_ipv6()."""
    provider = InlineListProvider(cidrs=["2001:db8::/32"])

    assert provider.fetch_ipv4() == []
    assert provider.fetch_ipv6() == ["2001:db8::/32"]


def test_invalid_cidr_raises_value_error_at_construction() -> None:
    """Passing a non-CIDR string raises ValueError during __init__."""
    with pytest.raises(ValueError):
        InlineListProvider(cidrs=["not-a-cidr"])
