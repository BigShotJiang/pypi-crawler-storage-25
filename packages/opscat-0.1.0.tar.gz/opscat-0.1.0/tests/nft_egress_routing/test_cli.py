"""CLI integration tests for opscat.nft_egress_routing.

Tests use typer.testing.CliRunner (mix_stderr=False) so that stdout and
stderr are captured independently.  subprocess.run is mocked wherever
the CLI would shell out to nft(8) or ip(8).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from opscat.nft_egress_routing.cli import app

# ---------------------------------------------------------------------------
# Shared runner instance
# ---------------------------------------------------------------------------

runner = CliRunner()

# ---------------------------------------------------------------------------
# TOML helpers
# ---------------------------------------------------------------------------

_MINIMAL_TOML = """\
[nftables]
table = "nft_egress_routing"

[global]
address_family = "any"
gateway = "192.168.1.1"
gateway6 = ""
gateway_dev = ""
routing_table_name_prefix = "nft_egress_routing"
routing_table_id_start = 232
fwmark_start = "0xe8"

[providers]
"""

_INLINE_PROVIDER_TOML = """\
[nftables]
table = "nft_egress_routing"

[global]
address_family = "any"
gateway = "192.168.1.1"
gateway6 = ""
gateway_dev = ""
routing_table_name_prefix = "nft_egress_routing"
routing_table_id_start = 232
fwmark_start = "0xe8"

[providers.rfc1918]
enabled = true
type = "inline_list"
address_family = "any"
cidrs = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]
"""


def _write_config(tmp_path: Path, content: str) -> Path:
    """Write *content* to a temporary TOML file and return its Path."""
    p = tmp_path / "nft-egress-routing.toml"
    p.write_text(content, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# subprocess mock helpers
# ---------------------------------------------------------------------------


def _nft_success_run(args, **kwargs) -> MagicMock:
    """
    Side-effect for subprocess.run that simulates a working nft installation.

    - `nft -j list table ...`  → returncode=1 (table not found; empty set returned)
    - `nft -f /dev/stdin`      → returncode=0
    - anything else            → returncode=0
    """
    if len(args) >= 2 and args[0] == "nft" and "-j" in args:
        return MagicMock(returncode=1, stdout="", stderr="Error: No such file")
    return MagicMock(returncode=0, stdout="", stderr="")


def _ip_success_run(args, **kwargs) -> MagicMock:
    """Side-effect for subprocess.run that succeeds for all ip(8) commands."""
    return MagicMock(returncode=0, stdout="", stderr="")


def _any_success_run(args, **kwargs) -> MagicMock:
    """Side-effect that always returns success regardless of the command."""
    return MagicMock(returncode=0, stdout="", stderr="")


# ---------------------------------------------------------------------------
# --help
# ---------------------------------------------------------------------------


def test_app_help_exits_0() -> None:
    """nft-egress-routing --help prints usage and exits with code 0."""
    result = runner.invoke(app, ["--help"])

    assert result.exit_code == 0
    assert (
        "usage" in result.stdout.lower()
        or "nft-egress-routing" in result.stdout.lower()
    )


def test_sets_subcommand_help_exits_0() -> None:
    """nft-egress-routing sets --help shows the sets subcommand help."""
    result = runner.invoke(app, ["sets", "--help"])

    assert result.exit_code == 0
    assert "sets" in result.stdout.lower() or "update" in result.stdout.lower()


def test_rule_subcommand_help_exits_0() -> None:
    """nft-egress-routing rule --help shows the rule subcommand help."""
    result = runner.invoke(app, ["rule", "--help"])

    assert result.exit_code == 0
    assert "rule" in result.stdout.lower() or "setup" in result.stdout.lower()


def test_sets_update_help_exits_0() -> None:
    """nft-egress-routing sets update --help exits with code 0."""
    result = runner.invoke(app, ["sets", "update", "--help"])

    assert result.exit_code == 0


def test_sets_clean_help_exits_0() -> None:
    """nft-egress-routing sets clean --help exits with code 0."""
    result = runner.invoke(app, ["sets", "clean", "--help"])

    assert result.exit_code == 0


def test_rule_setup_help_exits_0() -> None:
    """nft-egress-routing rule setup --help exits with code 0."""
    result = runner.invoke(app, ["rule", "setup", "--help"])

    assert result.exit_code == 0


def test_rule_teardown_help_exits_0() -> None:
    """nft-egress-routing rule teardown --help exits with code 0."""
    result = runner.invoke(app, ["rule", "teardown", "--help"])

    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Nonexistent config → exit code 1
# ---------------------------------------------------------------------------


def test_sets_update_with_missing_config_exits_1(tmp_path: Path) -> None:
    """sets update with a nonexistent config path exits with code 1."""
    missing = str(tmp_path / "does_not_exist.toml")
    result = runner.invoke(app, ["sets", "update", "--config", missing])

    assert result.exit_code == 1


def test_sets_update_with_missing_config_prints_error(tmp_path: Path) -> None:
    """sets update with a missing config path prints an error message."""
    missing = str(tmp_path / "does_not_exist.toml")
    result = runner.invoke(app, ["sets", "update", "--config", missing])

    combined = (result.stdout or "") + (result.stderr or "")
    assert "not found" in combined.lower() or "does_not_exist" in combined


def test_sets_clean_with_missing_config_exits_1(tmp_path: Path) -> None:
    """sets clean with a nonexistent config path exits with code 1."""
    missing = str(tmp_path / "no_such_config.toml")
    result = runner.invoke(app, ["sets", "clean", "--config", missing])

    assert result.exit_code == 1


def test_rule_setup_with_missing_config_exits_1(tmp_path: Path) -> None:
    """rule setup with a nonexistent config path exits with code 1."""
    missing = str(tmp_path / "missing.toml")
    result = runner.invoke(app, ["rule", "setup", "--config", missing])

    assert result.exit_code == 1


def test_rule_teardown_with_missing_config_exits_1(tmp_path: Path) -> None:
    """rule teardown with a nonexistent config path exits with code 1."""
    missing = str(tmp_path / "missing.toml")
    result = runner.invoke(app, ["rule", "teardown", "--config", missing])

    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# Invalid --log-level
# ---------------------------------------------------------------------------


def test_invalid_log_level_exits_1() -> None:
    """Passing an unknown --log-level value exits with code 1."""
    result = runner.invoke(app, ["--log-level", "INVALID_LEVEL", "sets", "--help"])

    assert result.exit_code == 1


def test_invalid_log_level_produces_error_message() -> None:
    """Passing an unknown --log-level prints an error mentioning the bad value."""
    result = runner.invoke(app, ["--log-level", "BOGUS", "sets", "--help"])

    combined = (result.stdout or "") + (result.stderr or "")
    assert "BOGUS" in combined or "log" in combined.lower() or result.exit_code == 1


def test_valid_log_level_debug_does_not_exit_1(tmp_path: Path) -> None:
    """--log-level DEBUG is accepted; the command proceeds normally."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)
    # sets clean with an empty providers dict → nft is called to list sets
    with patch("subprocess.run", side_effect=_nft_success_run):
        result = runner.invoke(
            app,
            ["--log-level", "DEBUG", "sets", "clean", "--config", str(config_file)],
        )

    assert result.exit_code == 0


def test_valid_log_level_warning_does_not_exit_1(tmp_path: Path) -> None:
    """--log-level WARNING is accepted; the command proceeds normally."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)
    with patch("subprocess.run", side_effect=_nft_success_run):
        result = runner.invoke(
            app,
            ["--log-level", "WARNING", "sets", "clean", "--config", str(config_file)],
        )

    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# sets update — valid config with inline_list provider
# ---------------------------------------------------------------------------


def test_sets_update_with_inline_provider_exits_0(tmp_path: Path) -> None:
    """sets update with an inline_list provider and mocked nft exits with code 0."""
    config_file = _write_config(tmp_path, _INLINE_PROVIDER_TOML)

    with patch("subprocess.run", side_effect=_nft_success_run):
        result = runner.invoke(app, ["sets", "update", "--config", str(config_file)])

    assert result.exit_code == 0


def test_sets_update_calls_nft_f_dev_stdin(tmp_path: Path) -> None:
    """sets update invokes 'nft -f /dev/stdin' exactly once."""
    config_file = _write_config(tmp_path, _INLINE_PROVIDER_TOML)
    nft_apply_calls: list[list[str]] = []

    def capturing_run(args, **kwargs):
        if args[0] == "nft" and "-j" in args:
            return MagicMock(returncode=1, stdout="", stderr="")
        if args[0] == "nft" and "-f" in args:
            nft_apply_calls.append(list(args))
            return MagicMock(returncode=0, stdout="", stderr="")
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=capturing_run):
        result = runner.invoke(app, ["sets", "update", "--config", str(config_file)])

    assert result.exit_code == 0
    assert len(nft_apply_calls) == 1
    assert nft_apply_calls[0] == ["nft", "-f", "/dev/stdin"]


def test_sets_update_with_empty_providers_exits_0(tmp_path: Path) -> None:
    """sets update with no enabled providers exits 0 (warning, early return)."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)

    # No subprocess calls expected (no providers → early return before nft apply)
    with patch("subprocess.run") as mock_run:
        result = runner.invoke(app, ["sets", "update", "--config", str(config_file)])

    assert result.exit_code == 0
    # nft should not have been called because there are no providers
    mock_run.assert_not_called()


def test_sets_update_nft_failure_exits_1(tmp_path: Path) -> None:
    """sets update exits 1 when nft -f /dev/stdin returns a non-zero code."""
    config_file = _write_config(tmp_path, _INLINE_PROVIDER_TOML)

    def failing_nft_run(args, **kwargs):
        if args[0] == "nft" and "-j" in args:
            return MagicMock(returncode=1, stdout="", stderr="")
        # nft -f /dev/stdin → failure
        return MagicMock(returncode=1, stdout="", stderr="nft: error")

    with patch("subprocess.run", side_effect=failing_nft_run):
        result = runner.invoke(app, ["sets", "update", "--config", str(config_file)])

    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# sets clean — valid config
# ---------------------------------------------------------------------------


def test_sets_clean_with_valid_config_exits_0(tmp_path: Path) -> None:
    """sets clean with a valid config and no existing sets exits 0."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)

    # nft -j list table fails → empty existing sets → apply() has nothing to do
    with patch("subprocess.run", side_effect=_nft_success_run):
        result = runner.invoke(app, ["sets", "clean", "--config", str(config_file)])

    assert result.exit_code == 0


def test_sets_clean_with_existing_sets_flushes_them(tmp_path: Path) -> None:
    """sets clean flushes existing sets discovered via nft -j list table."""
    import json

    config_file = _write_config(tmp_path, _MINIMAL_TOML)

    nft_json = json.dumps(
        {
            "nftables": [
                {"set": {"name": "old_provider_ipv4"}},
                {"set": {"name": "old_provider_ipv6"}},
            ]
        }
    )
    nft_apply_calls: list[list[str]] = []

    def fake_run(args, **kwargs):
        if args[0] == "nft" and "-j" in args:
            return MagicMock(returncode=0, stdout=nft_json, stderr="")
        if args[0] == "nft" and "-f" in args:
            nft_apply_calls.append(list(args))
            return MagicMock(returncode=0, stdout="", stderr="")
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=fake_run):
        result = runner.invoke(app, ["sets", "clean", "--config", str(config_file)])

    assert result.exit_code == 0
    # apply() should have been called because there were sets to flush
    assert len(nft_apply_calls) == 1


# ---------------------------------------------------------------------------
# rule setup — valid config
# ---------------------------------------------------------------------------


def test_rule_setup_with_valid_config_exits_0(tmp_path: Path) -> None:
    """rule setup with a valid config exits 0 when ip commands succeed."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_any_success_run):
            result = runner.invoke(app, ["rule", "setup", "--config", str(config_file)])

    assert result.exit_code == 0


def test_rule_setup_writes_rt_tables_d_file(tmp_path: Path) -> None:
    """rule setup creates a routing table registration file under RT_TABLES_DIR."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)

    rt_dir = tmp_path / "rt_tables.d"
    rt_dir.mkdir()

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", rt_dir):
        with patch("subprocess.run", side_effect=_any_success_run):
            result = runner.invoke(app, ["rule", "setup", "--config", str(config_file)])

    assert result.exit_code == 0
    conf_files = list(rt_dir.glob("nft-egress-routing-*.conf"))
    assert len(conf_files) == 1


def test_rule_setup_calls_ip_rule_add(tmp_path: Path) -> None:
    """rule setup calls 'ip -4 rule add fwmark ...' for the resolved group."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)
    ip_rule_adds: list[list[str]] = []

    def capturing_run(args, **kwargs):
        if "rule" in args and "add" in args:
            ip_rule_adds.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capturing_run):
            result = runner.invoke(app, ["rule", "setup", "--config", str(config_file)])

    assert result.exit_code == 0
    assert len(ip_rule_adds) >= 1
    combined = " ".join(ip_rule_adds[0])
    assert "fwmark" in combined


def test_rule_setup_calls_ip_route_add(tmp_path: Path) -> None:
    """rule setup calls 'ip -4 route add default ...' for the resolved group."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)
    ip_route_adds: list[list[str]] = []

    def capturing_run(args, **kwargs):
        if "route" in args and "add" in args:
            ip_route_adds.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capturing_run):
            result = runner.invoke(app, ["rule", "setup", "--config", str(config_file)])

    assert result.exit_code == 0
    assert len(ip_route_adds) >= 1
    combined = " ".join(ip_route_adds[0])
    assert "default" in combined


# ---------------------------------------------------------------------------
# rule teardown — valid config
# ---------------------------------------------------------------------------


def test_rule_teardown_with_valid_config_exits_0(tmp_path: Path) -> None:
    """rule teardown with a valid config exits 0 when ip commands succeed."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_any_success_run):
            result = runner.invoke(
                app, ["rule", "teardown", "--config", str(config_file)]
            )

    assert result.exit_code == 0


def test_rule_teardown_calls_ip_rule_del(tmp_path: Path) -> None:
    """rule teardown calls 'ip -4 rule del' for the resolved group."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)
    ip_rule_dels: list[list[str]] = []

    def capturing_run(args, **kwargs):
        if "rule" in args and "del" in args:
            ip_rule_dels.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capturing_run):
            result = runner.invoke(
                app, ["rule", "teardown", "--config", str(config_file)]
            )

    assert result.exit_code == 0
    assert len(ip_rule_dels) >= 1


def test_rule_teardown_calls_ip_route_del(tmp_path: Path) -> None:
    """rule teardown calls 'ip -4 route del' for the resolved group."""
    config_file = _write_config(tmp_path, _MINIMAL_TOML)
    ip_route_dels: list[list[str]] = []

    def capturing_run(args, **kwargs):
        if "route" in args and "del" in args:
            ip_route_dels.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capturing_run):
            result = runner.invoke(
                app, ["rule", "teardown", "--config", str(config_file)]
            )

    assert result.exit_code == 0
    assert len(ip_route_dels) >= 1


# ---------------------------------------------------------------------------
# Config file with inline_list + rule setup
# ---------------------------------------------------------------------------


def test_rule_setup_with_inline_provider_config_exits_0(tmp_path: Path) -> None:
    """rule setup works correctly when the config also defines an inline_list provider."""
    config_file = _write_config(tmp_path, _INLINE_PROVIDER_TOML)

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_any_success_run):
            result = runner.invoke(app, ["rule", "setup", "--config", str(config_file)])

    assert result.exit_code == 0


def test_sets_update_with_inline_provider_stale_sets_are_flushed(
    tmp_path: Path,
) -> None:
    """sets update flushes any stale sets that are present but not in current config."""
    import json

    config_file = _write_config(tmp_path, _INLINE_PROVIDER_TOML)

    # Simulate an existing set that is NOT in the current provider list
    nft_json = json.dumps(
        {
            "nftables": [
                {"set": {"name": "old_stale_ipv4"}},
            ]
        }
    )
    nft_inputs: list[str] = []

    def capturing_run(args, **kwargs):
        if args[0] == "nft" and "-j" in args:
            return MagicMock(returncode=0, stdout=nft_json, stderr="")
        if args[0] == "nft" and "-f" in args:
            nft_inputs.append(kwargs.get("input", ""))
            return MagicMock(returncode=0, stdout="", stderr="")
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=capturing_run):
        result = runner.invoke(app, ["sets", "update", "--config", str(config_file)])

    assert result.exit_code == 0
    # The nft script should contain a flush for the stale set
    assert len(nft_inputs) == 1
    assert "old_stale_ipv4" in nft_inputs[0]


# ---------------------------------------------------------------------------
# Subcommand name display in help
# ---------------------------------------------------------------------------


def test_sets_update_mentioned_in_sets_help() -> None:
    """'update' subcommand name appears in the sets --help output."""
    result = runner.invoke(app, ["sets", "--help"])

    assert "update" in result.stdout


def test_rule_setup_mentioned_in_rule_help() -> None:
    """'setup' subcommand name appears in the rule --help output."""
    result = runner.invoke(app, ["rule", "--help"])

    assert "setup" in result.stdout


def test_rule_teardown_mentioned_in_rule_help() -> None:
    """'teardown' subcommand name appears in the rule --help output."""
    result = runner.invoke(app, ["rule", "--help"])

    assert "teardown" in result.stdout
