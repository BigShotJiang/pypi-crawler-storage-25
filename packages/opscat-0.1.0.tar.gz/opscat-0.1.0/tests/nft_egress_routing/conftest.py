"""Shared pytest fixtures for nft_egress_routing test suite."""

from __future__ import annotations

from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Config dict fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def minimal_config() -> dict:
    """Return a minimal config dict with nftables, global, and empty providers."""
    return {
        "nftables": {
            "table": "nft_egress_routing",
        },
        "global": {
            "address_family": "any",
            "gateway": "192.168.1.1",
            "gateway6": "",
            "gateway_dev": "",
            "routing_table_name_prefix": "nft_egress_routing",
            "routing_table_id_start": 232,
            "fwmark_start": "0xe8",
        },
        "providers": {},
    }


@pytest.fixture
def config_with_providers() -> dict:
    """Return a config dict containing inline_list and dns type providers."""
    return {
        "nftables": {
            "table": "nft_egress_routing",
        },
        "global": {
            "address_family": "any",
            "gateway": "192.168.1.1",
            "gateway6": "",
            "gateway_dev": "",
            "routing_table_name_prefix": "nft_egress_routing",
            "routing_table_id_start": 232,
            "fwmark_start": "0xe8",
        },
        "providers": {
            "my_inline": {
                "enabled": True,
                "type": "inline_list",
                "address_family": "any",
                "cidrs": [
                    "10.0.0.0/8",
                    "172.16.0.0/12",
                    "2001:db8::/32",
                ],
            },
            "my_dns": {
                "enabled": True,
                "type": "dns",
                "address_family": "any",
                "hostnames": [
                    "example.com",
                    "example.org",
                ],
            },
        },
    }


# ---------------------------------------------------------------------------
# TOML file fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config_toml_file(tmp_path: Path, minimal_config: dict) -> Path:
    """Write minimal_config to a temporary TOML file and return its Path."""
    toml_content = _dict_to_toml(minimal_config)
    path = tmp_path / "nft-egress-routing.toml"
    path.write_text(toml_content, encoding="utf-8")
    return path


@pytest.fixture
def provider_config_toml_file(tmp_path: Path, config_with_providers: dict) -> Path:
    """Write config_with_providers to a temporary TOML file and return its Path."""
    toml_content = _dict_to_toml(config_with_providers)
    path = tmp_path / "nft-egress-routing-providers.toml"
    path.write_text(toml_content, encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _dict_to_toml(config: dict) -> str:
    """
    Produce a minimal TOML representation of *config*.

    Only handles the structure used in nft_egress_routing configs (nested
    dicts and flat value types); does not need to be a general-purpose
    serialiser.
    """
    lines: list[str] = []

    for section, value in config.items():
        if section == "providers":
            for provider_name, provider_cfg in value.items():
                lines.append(f"\n[providers.{provider_name}]")
                for k, v in provider_cfg.items():
                    lines.append(_toml_kv(k, v))
        elif isinstance(value, dict):
            lines.append(f"\n[{section}]")
            for k, v in value.items():
                lines.append(_toml_kv(k, v))
        else:
            lines.append(_toml_kv(section, value))

    return "\n".join(lines) + "\n"


def _toml_kv(key: str, value: object) -> str:
    """Format a single TOML key = value line."""
    if isinstance(value, bool):
        return f"{key} = {str(value).lower()}"
    if isinstance(value, int):
        return f"{key} = {value}"
    if isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'{key} = "{escaped}"'
    if isinstance(value, list):
        items = ", ".join(_toml_inline_value(item) for item in value)
        return f"{key} = [{items}]"
    # Fallback
    return f'{key} = "{value}"'


def _toml_inline_value(value: object) -> str:
    """Format a scalar for use inside a TOML inline array."""
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, int):
        return str(value)
    if isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    return f'"{value}"'
