"""Tests for opscat.nft_egress_routing.routing — _resolve_groups(), setup(), teardown()."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from opscat.nft_egress_routing.routing import (
    RoutingGroup,
    _resolve_groups,
    setup,
    teardown,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_config(
    *,
    gateway: str = "192.168.1.1",
    gateway6: str = "",
    gateway_dev: str = "",
    prefix: str = "nft_egress_routing",
    id_start: int = 232,
    fwmark_start: str = "0xe8",
    providers: dict | None = None,
) -> dict:
    """Build a minimal routing config dict."""
    return {
        "global": {
            "gateway": gateway,
            "gateway6": gateway6,
            "gateway_dev": gateway_dev,
            "routing_table_name_prefix": prefix,
            "routing_table_id_start": id_start,
            "fwmark_start": fwmark_start,
        },
        "providers": providers or {},
    }


def _make_group(
    *,
    fwmark: str = "0xe8",
    routing_table_id: int = 232,
    routing_table_name: str = "nft_egress_routing",
    nexthop: str = "192.168.1.1",
    nexthop6: str = "",
    nexthop_dev: str = "",
) -> RoutingGroup:
    """Build a RoutingGroup with convenient defaults."""
    return RoutingGroup(
        fwmark=fwmark,
        routing_table_id=routing_table_id,
        routing_table_name=routing_table_name,
        nexthop=nexthop,
        nexthop6=nexthop6,
        nexthop_dev=nexthop_dev,
    )


def _success_run(args, **kwargs) -> MagicMock:
    """Side-effect helper: always returns a successful subprocess result."""
    return MagicMock(returncode=0, stdout="", stderr="")


# ---------------------------------------------------------------------------
# _resolve_groups() — no enabled providers
# ---------------------------------------------------------------------------


def test_resolve_groups_empty_providers_returns_default_group() -> None:
    """With an empty providers dict, _resolve_groups() returns one default group."""
    config = _make_config()

    groups = _resolve_groups(config)

    assert len(groups) == 1
    group = groups[0]
    assert group.fwmark == "0xe8"
    assert group.routing_table_id == 232
    assert group.routing_table_name == "nft_egress_routing"
    assert group.nexthop == "192.168.1.1"


def test_resolve_groups_all_disabled_providers_returns_default_group() -> None:
    """With every provider disabled, _resolve_groups() returns one default group."""
    config = _make_config(
        providers={
            "disabled": {
                "enabled": False,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            }
        }
    )

    groups = _resolve_groups(config)

    assert len(groups) == 1
    assert groups[0].routing_table_name == "nft_egress_routing"


def test_resolve_groups_default_group_inherits_global_gateway() -> None:
    """Default group's nexthop comes from global.gateway."""
    config = _make_config(gateway="10.0.0.1")

    groups = _resolve_groups(config)

    assert groups[0].nexthop == "10.0.0.1"


def test_resolve_groups_default_group_inherits_global_gateway6() -> None:
    """Default group's nexthop6 comes from global.gateway6."""
    config = _make_config(gateway6="2001:db8::1")

    groups = _resolve_groups(config)

    assert groups[0].nexthop6 == "2001:db8::1"


# ---------------------------------------------------------------------------
# _resolve_groups() — same nexthop merging
# ---------------------------------------------------------------------------


def test_resolve_groups_two_providers_with_global_nexthop_produce_one_group() -> None:
    """Providers sharing the global nexthop are collapsed into a single group."""
    config = _make_config(
        providers={
            "provider_a": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
            },
            "provider_b": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["172.16.0.0/12"],
            },
        }
    )

    groups = _resolve_groups(config)

    assert len(groups) == 1


def test_resolve_groups_two_providers_with_same_custom_nexthop_produce_one_group() -> (
    None
):
    """Two providers sharing the same custom nexthop get exactly one RoutingGroup."""
    config = _make_config(
        providers={
            "prov_a": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
                "nexthop": "10.10.10.1",
                "fwmark": "0xea",
            },
            "prov_b": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["172.16.0.0/12"],
                "nexthop": "10.10.10.1",
                "fwmark": "0xea",
            },
        }
    )

    groups = _resolve_groups(config)

    assert len(groups) == 1
    assert groups[0].nexthop == "10.10.10.1"


# ---------------------------------------------------------------------------
# _resolve_groups() — different nexthops produce separate groups
# ---------------------------------------------------------------------------


def test_resolve_groups_different_nexthops_produce_separate_groups() -> None:
    """Providers with distinct nexthops each get their own RoutingGroup."""
    config = _make_config(
        providers={
            "provider_default": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
                # uses global gateway 192.168.1.1
            },
            "provider_custom": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["172.16.0.0/12"],
                "nexthop": "10.10.10.1",
                "fwmark": "0xe9",
            },
        }
    )

    groups = _resolve_groups(config)

    assert len(groups) == 2
    nexthops = {g.nexthop for g in groups}
    assert "192.168.1.1" in nexthops
    assert "10.10.10.1" in nexthops


def test_resolve_groups_per_provider_nexthop_with_fwmark_creates_extra_group() -> None:
    """A provider with a unique nexthop and explicit fwmark creates its own group."""
    config = _make_config(
        providers={
            "provider_custom": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["172.16.0.0/12"],
                "nexthop": "10.10.10.1",
                "fwmark": "0xea",
            },
        }
    )

    groups = _resolve_groups(config)

    assert len(groups) == 1
    assert groups[0].fwmark == "0xea"
    assert groups[0].nexthop == "10.10.10.1"


def test_resolve_groups_custom_table_name_and_id_from_provider() -> None:
    """Provider with routing_table_name / routing_table_id overrides uses those values."""
    config = _make_config(
        providers={
            "prov": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
                "nexthop": "10.10.10.1",
                "fwmark": "0xea",
                "routing_table_name": "my_custom_table",
                "routing_table_id": 300,
            },
        }
    )

    groups = _resolve_groups(config)

    assert groups[0].routing_table_name == "my_custom_table"
    assert groups[0].routing_table_id == 300


# ---------------------------------------------------------------------------
# _resolve_groups() — missing fwmark causes sys.exit(1)
# ---------------------------------------------------------------------------


def test_resolve_groups_per_provider_nexthop_without_fwmark_exits_with_1() -> None:
    """Provider with a unique nexthop but no 'fwmark' causes sys.exit(1)."""
    config = _make_config(
        providers={
            "bad_provider": {
                "enabled": True,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
                "nexthop": "10.10.10.1",  # unique nexthop, fwmark omitted
            },
        }
    )

    with pytest.raises(SystemExit) as exc_info:
        _resolve_groups(config)

    assert exc_info.value.code == 1


def test_resolve_groups_disabled_provider_with_unique_nexthop_does_not_exit() -> None:
    """A disabled provider with a unique nexthop does NOT trigger the fwmark check."""
    config = _make_config(
        providers={
            "disabled_bad": {
                "enabled": False,
                "type": "inline_list",
                "cidrs": ["10.0.0.0/8"],
                "nexthop": "10.10.10.1",  # unique nexthop, no fwmark — but disabled
            },
        }
    )

    # Should not raise
    groups = _resolve_groups(config)
    assert len(groups) == 1  # falls back to default group


# ---------------------------------------------------------------------------
# setup() — file system
# ---------------------------------------------------------------------------


def test_setup_writes_rt_tables_d_file(tmp_path: Path) -> None:
    """setup() creates a routing table registration file under RT_TABLES_DIR."""
    group = _make_group()

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_success_run):
            setup([group])

    expected = tmp_path / "nft-egress-routing-nft_egress_routing.conf"
    assert expected.exists()


def test_setup_rt_tables_file_has_correct_content(tmp_path: Path) -> None:
    """setup() writes '<id> <name>' as the content of the rt_tables.d file."""
    group = _make_group(routing_table_id=300, routing_table_name="custom_table")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_success_run):
            setup([group])

    content = (tmp_path / "nft-egress-routing-custom_table.conf").read_text()
    assert content.strip() == "300 custom_table"


def test_setup_multiple_groups_writes_separate_files(tmp_path: Path) -> None:
    """setup() with multiple groups creates one rt_tables.d file per group."""
    group1 = _make_group(
        routing_table_id=232,
        routing_table_name="table_a",
        nexthop_dev="eth0",
    )
    group2 = _make_group(
        fwmark="0xe9",
        routing_table_id=233,
        routing_table_name="table_b",
        nexthop="10.10.10.1",
        nexthop_dev="eth0",
    )

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_success_run):
            setup([group1, group2])

    assert (tmp_path / "nft-egress-routing-table_a.conf").exists()
    assert (tmp_path / "nft-egress-routing-table_b.conf").exists()


# ---------------------------------------------------------------------------
# setup() — IPv4 ip rule / ip route commands
# ---------------------------------------------------------------------------


def test_setup_calls_ip4_rule_add_with_correct_args(tmp_path: Path) -> None:
    """setup() calls 'ip -4 rule add fwmark <fwmark> lookup <table>'."""
    group = _make_group(fwmark="0xe8", routing_table_name="nft_egress_routing")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            setup([group])

    rule_adds = [c for c in called if "rule" in c and "add" in c and "-4" in c]
    assert len(rule_adds) == 1
    cmd = rule_adds[0]
    assert "fwmark" in cmd
    assert "0xe8" in cmd
    assert "lookup" in cmd
    assert "nft_egress_routing" in cmd


def test_setup_calls_ip4_route_add_with_correct_args(tmp_path: Path) -> None:
    """setup() calls 'ip -4 route add default via <nexthop> table <table>'."""
    group = _make_group(nexthop="192.168.1.1", routing_table_name="nft_egress_routing")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            setup([group])

    route_adds = [c for c in called if "route" in c and "add" in c and "-4" in c]
    assert len(route_adds) == 1
    cmd = route_adds[0]
    assert "default" in cmd
    assert "via" in cmd
    assert "192.168.1.1" in cmd
    assert "table" in cmd
    assert "nft_egress_routing" in cmd


def test_setup_deletes_existing_ipv4_rule_before_adding(tmp_path: Path) -> None:
    """setup() issues an ip -4 rule del before ip -4 rule add."""
    group = _make_group()
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            setup([group])

    ipv4_rule_dels = [c for c in called if "rule" in c and "del" in c and "-4" in c]
    ipv4_rule_adds = [c for c in called if "rule" in c and "add" in c and "-4" in c]
    assert len(ipv4_rule_dels) == 1
    assert len(ipv4_rule_adds) == 1

    del_idx = called.index(ipv4_rule_dels[0])
    add_idx = called.index(ipv4_rule_adds[0])
    assert del_idx < add_idx


def test_setup_deletes_existing_ipv4_route_before_adding(tmp_path: Path) -> None:
    """setup() issues an ip -4 route del before ip -4 route add."""
    group = _make_group()
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            setup([group])

    ipv4_route_dels = [c for c in called if "route" in c and "del" in c and "-4" in c]
    ipv4_route_adds = [c for c in called if "route" in c and "add" in c and "-4" in c]
    assert len(ipv4_route_dels) == 1
    assert len(ipv4_route_adds) == 1

    del_idx = called.index(ipv4_route_dels[0])
    add_idx = called.index(ipv4_route_adds[0])
    assert del_idx < add_idx


# ---------------------------------------------------------------------------
# setup() — IPv6 commands
# ---------------------------------------------------------------------------


def test_setup_with_nexthop6_executes_ipv6_rule_and_route_add(tmp_path: Path) -> None:
    """setup() issues IPv6 rule add and route add when nexthop6 is set."""
    group = _make_group(nexthop6="2001:db8::1", routing_table_name="nft_egress_routing")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            setup([group])

    ipv6_rule_adds = [c for c in called if "-6" in c and "rule" in c and "add" in c]
    ipv6_route_adds = [c for c in called if "-6" in c and "route" in c and "add" in c]
    assert len(ipv6_rule_adds) == 1
    assert len(ipv6_route_adds) == 1
    assert "2001:db8::1" in ipv6_route_adds[0]


def test_setup_with_nexthop_dev_only_executes_ipv6_commands(tmp_path: Path) -> None:
    """setup() issues IPv6 commands when only nexthop_dev is set (no nexthop6)."""
    group = _make_group(nexthop6="", nexthop_dev="eth0")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            setup([group])

    ipv6_cmds = [c for c in called if "-6" in c]
    assert len(ipv6_cmds) >= 2


def test_setup_without_nexthop6_or_nexthop_dev_skips_ipv6(tmp_path: Path) -> None:
    """setup() emits no IPv6 commands when both nexthop6 and nexthop_dev are empty."""
    group = _make_group(nexthop6="", nexthop_dev="")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            setup([group])

    ipv6_cmds = [c for c in called if "-6" in c]
    assert len(ipv6_cmds) == 0


# ---------------------------------------------------------------------------
# teardown() — file system
# ---------------------------------------------------------------------------


def test_teardown_removes_rt_tables_d_file_when_present(tmp_path: Path) -> None:
    """teardown() deletes the rt_tables.d file if it exists."""
    group = _make_group()
    conf_file = tmp_path / "nft-egress-routing-nft_egress_routing.conf"
    conf_file.write_text("232 nft_egress_routing\n")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_success_run):
            teardown([group])

    assert not conf_file.exists()


def test_teardown_does_not_raise_when_file_absent(tmp_path: Path) -> None:
    """teardown() completes without error even if the rt_tables.d file is missing."""
    group = _make_group()

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=_success_run):
            teardown([group])  # must not raise


# ---------------------------------------------------------------------------
# teardown() — IPv4 ip rule / ip route commands
# ---------------------------------------------------------------------------


def test_teardown_calls_ip4_route_del(tmp_path: Path) -> None:
    """teardown() calls 'ip -4 route del default table <table>'."""
    group = _make_group(routing_table_name="nft_egress_routing")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            teardown([group])

    route_dels = [c for c in called if "route" in c and "del" in c and "-4" in c]
    assert len(route_dels) == 1
    cmd = route_dels[0]
    assert "default" in cmd
    assert "table" in cmd
    assert "nft_egress_routing" in cmd


def test_teardown_calls_ip4_rule_del(tmp_path: Path) -> None:
    """teardown() calls 'ip -4 rule del fwmark <fwmark> lookup <table>'."""
    group = _make_group(fwmark="0xe8", routing_table_name="nft_egress_routing")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            teardown([group])

    rule_dels = [c for c in called if "rule" in c and "del" in c and "-4" in c]
    assert len(rule_dels) == 1
    cmd = rule_dels[0]
    assert "fwmark" in cmd
    assert "0xe8" in cmd
    assert "lookup" in cmd
    assert "nft_egress_routing" in cmd


def test_teardown_ipv4_route_del_before_rule_del(tmp_path: Path) -> None:
    """teardown() issues ip -4 route del before ip -4 rule del within a group."""
    group = _make_group()
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            teardown([group])

    ipv4_route_del = next(
        c for c in called if "route" in c and "del" in c and "-4" in c
    )
    ipv4_rule_del = next(c for c in called if "rule" in c and "del" in c and "-4" in c)
    assert called.index(ipv4_route_del) < called.index(ipv4_rule_del)


# ---------------------------------------------------------------------------
# teardown() — IPv6 commands
# ---------------------------------------------------------------------------


def test_teardown_with_nexthop6_calls_ipv6_del_commands(tmp_path: Path) -> None:
    """teardown() issues IPv6 route del and rule del when nexthop6 is set."""
    group = _make_group(nexthop6="2001:db8::1", routing_table_name="nft_egress_routing")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            teardown([group])

    ipv6_route_dels = [c for c in called if "-6" in c and "route" in c and "del" in c]
    ipv6_rule_dels = [c for c in called if "-6" in c and "rule" in c and "del" in c]
    assert len(ipv6_route_dels) == 1
    assert len(ipv6_rule_dels) == 1


def test_teardown_ipv6_route_del_before_rule_del(tmp_path: Path) -> None:
    """teardown() issues IPv6 route del before IPv6 rule del (routes before rules)."""
    group = _make_group(nexthop6="2001:db8::1")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            teardown([group])

    ipv6_route_del = next(
        c for c in called if "-6" in c and "route" in c and "del" in c
    )
    ipv6_rule_del = next(c for c in called if "-6" in c and "rule" in c and "del" in c)
    assert called.index(ipv6_route_del) < called.index(ipv6_rule_del)


def test_teardown_without_nexthop6_or_nexthop_dev_skips_ipv6_del(
    tmp_path: Path,
) -> None:
    """teardown() emits no IPv6 del commands when both nexthop6 and nexthop_dev are empty."""
    group = _make_group(nexthop6="", nexthop_dev="")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            teardown([group])

    ipv6_cmds = [c for c in called if "-6" in c]
    assert len(ipv6_cmds) == 0


def test_teardown_with_nexthop_dev_only_calls_ipv6_del_commands(tmp_path: Path) -> None:
    """teardown() issues IPv6 del commands when only nexthop_dev is set."""
    group = _make_group(nexthop6="", nexthop_dev="eth0")
    called: list[list[str]] = []

    def capture(args, **kwargs):
        called.append(list(args))
        return MagicMock(returncode=0, stdout="", stderr="")

    with patch("opscat.nft_egress_routing.routing.RT_TABLES_DIR", tmp_path):
        with patch("subprocess.run", side_effect=capture):
            teardown([group])

    ipv6_cmds = [c for c in called if "-6" in c]
    assert len(ipv6_cmds) >= 2
