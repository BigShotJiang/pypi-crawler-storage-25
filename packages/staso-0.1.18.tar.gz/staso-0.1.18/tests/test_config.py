"""Tests for staso.config."""
from __future__ import annotations

import pytest

from staso.config import Config


class TestConfig:
    def test_required_fields(self):
        cfg = Config(api_key="ak_test", agent_id="my-agent")
        assert cfg.api_key == "ak_test"
        assert cfg.agent_id == "my-agent"

    def test_defaults(self):
        cfg = Config(api_key="ak_test", agent_id="my-agent")
        assert cfg.base_url == "https://api.staso.ai"
        assert cfg.batch_size == 100
        assert cfg.flush_interval == 5.0
        assert cfg.max_queue_size == 10_000
        assert cfg.enabled is True
        assert cfg.debug is False
        assert cfg.environment == "default"
        assert cfg.workspace_slug == "default"

    def test_custom_values(self):
        cfg = Config(
            api_key="ak_test",
            agent_id="my-agent",
            base_url="https://api.staso.ai",
            batch_size=50,
            flush_interval=2.0,
            max_queue_size=5_000,
            enabled=False,
            debug=True,
            environment="production",
            workspace_slug="ws-1",
        )
        assert cfg.base_url == "https://api.staso.ai"
        assert cfg.batch_size == 50
        assert cfg.flush_interval == 2.0
        assert cfg.max_queue_size == 5_000
        assert cfg.enabled is False
        assert cfg.debug is True
        assert cfg.environment == "production"
        assert cfg.workspace_slug == "ws-1"

    def test_frozen(self):
        cfg = Config(api_key="ak_test", agent_id="my-agent")
        with pytest.raises(AttributeError):
            cfg.api_key = "changed"  # type: ignore[misc]
