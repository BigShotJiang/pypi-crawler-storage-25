---
title: Conversations
description: Group related traces into conversations and workflows.
---

# Conversations

Group related traces together -- conversations, workflows, whatever makes sense for your use case.

## Usage

```python
with st.conversation("conversation-42"):
    run_agent("What's my balance?")
    run_agent("Transfer $50")
```

Both runs and all their child spans get tagged with `conversation-42`.

## Auto-Generated IDs

If you don't have a conversation ID, omit it -- the SDK generates a UUID:

```python
with st.conversation():
    run_agent("Hello!")
```

## User Tracking

Associate a conversation with a user:

```python
with st.conversation("conv-42", user_id="user-alice"):
    run_agent("What's my balance?")
```

All spans created within this context carry both the conversation ID and the user ID.

## Common Patterns

```python
# Multi-turn conversations
with st.conversation(f"conv-{conversation_id}"):
    for message in messages:
        run_agent(message)

# Conversations with user tracking
with st.conversation(f"conv-{conversation_id}", user_id=current_user.id):
    run_agent(message)

# Workflows
with st.conversation(f"workflow-{job_id}"):
    step_1()
    step_2()

# Per-request
with st.conversation(request_id):
    handle_request(payload)
```

## Propagation

Conversation IDs flow automatically through your entire call stack, including async code:

```python
with st.conversation("my-conversation"):
    run_agent("hello")
    # every @tool, @trace, and LLM call inside
    # is automatically tagged with "my-conversation"
```

## Optional

Conversations are optional. Without them, traces still work -- they just aren't grouped on the dashboard.

## Nesting

Innermost conversation wins:

```python
with st.conversation("outer"):
    run_agent("A")           # conversation = "outer"
    with st.conversation("inner"):
        run_agent("B")       # conversation = "inner"
    run_agent("C")           # conversation = "outer"
```

## Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `conversation_id` | `str \| None` | `None` | Conversation identifier. Auto-generated UUID if omitted. |
| `user_id` | `str \| None` | `None` | User identifier. Attached to all spans in this context. |
