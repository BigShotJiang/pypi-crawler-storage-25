---
title: LLM Integrations
description: Auto-instrument LLM provider calls with one line of code.
---

# LLM Integrations

One line of code to auto-trace LLM calls. No wrappers, no changes to your existing code.

## Available

| Provider | Install | Enable |
|----------|---------|--------|
| [Anthropic](/docs/integrations/anthropic) | `pip install "staso[anthropic]"` | `st.integrations.patch_anthropic()` |
| [OpenAI](/docs/integrations/openai) | `pip install "staso[openai]"` | `st.integrations.patch_openai()` |
| [Claude Code](/docs/integrations/claude-code) | `pip install staso` | `staso setup` (interactive) or `staso setup --target claude-code --api-key ak_...` |
| [Codex](/docs/integrations/codex) | `pip install staso` | `staso setup` (interactive) or `staso setup --target codex --api-key ak_...` |

## How It Works

Call the patch function **before** creating your client. Every call to that provider automatically emits an LLM span -- model, tokens, latency, errors. Both sync and async clients are covered. Streaming is fully supported.

```python
st.integrations.patch_anthropic()
st.integrations.patch_openai()

# use your LLM clients normally -- traces happen automatically
```

## Other Providers

For providers without a built-in integration, use `@st.trace(kind="llm")`:

```python
@st.trace(name="cohere_call", kind="llm")
def call_cohere(prompt: str) -> str:
    response = cohere.chat(...)
    return response.text
```

You get timing and error tracking, but not automatic token extraction.
