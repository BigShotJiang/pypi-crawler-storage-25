# Staso Python SDK

See what your AI agents actually do. Every tool call, LLM interaction, token count, latency, and error -- on your [Staso dashboard](https://staso.ai).

```bash
pip install staso
```

```python
import staso as st

st.init(api_key="ak_...", agent_id="my-agent")

@st.agent(name="support-agent")
def handle_request(message: str) -> str:
    context = search_kb(message)
    return call_llm(context, message)

@st.tool(name="search_kb")
def search_kb(query: str) -> str:
    return db.search(query)

with st.conversation("conversation-123"):
    handle_request("How do I reset my password?")

st.shutdown()
```

Open your dashboard. Full execution tree -- agents, tools, LLM calls, tokens, timing, errors.

## Auto-Instrument LLM Calls

```bash
pip install "staso[anthropic]"  # or "staso[openai]" or "staso[all]"
```

```python
st.integrations.patch_anthropic()
# every Anthropic SDK call is now traced automatically -- tokens, model, latency, errors

st.integrations.patch_openai()
# every OpenAI SDK call is now traced automatically
```

Both sync and async clients. Streaming fully supported.

## CLI Agent Integrations

Trace Claude Code and Codex sessions automatically. Run the interactive wizard:

```bash
staso setup
```

Or pass flags directly:

```bash
staso setup --target claude-code --api-key ak_... --workspace my-workspace
staso setup --target codex --api-key ak_... --workspace my-workspace
```

## CLI Commands

```bash
staso setup                                              # interactive setup wizard
staso setup     --target claude-code --api-key ak_...    # scripted setup
staso status                                             # show what's configured
staso sync                                               # sync hooks after upgrade
staso update                                             # upgrade package + sync
staso uninstall --target codex                           # remove hooks, clean up
staso version                                            # show version info
```

## Docs

- [Quickstart](https://staso.ai/docs/getting-started/quickstart) -- 5 minutes to first trace
- [Tracing](https://staso.ai/docs/guides/tracing) -- `@agent`, `@tool`, `@trace`, `st.span()`
- [Conversations](https://staso.ai/docs/guides/conversations) -- group traces by conversation
- [Integrations](https://staso.ai/docs/integrations/overview) -- Anthropic, OpenAI, Claude Code, Codex
- [Configuration](https://staso.ai/docs/configuration/options) -- all options and env vars
- [Troubleshooting](https://staso.ai/docs/troubleshooting) -- common issues

Python 3.11+ &middot; [Apache 2.0](LICENSE)
