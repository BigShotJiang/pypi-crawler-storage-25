"""Codex tracing integration for Staso."""
