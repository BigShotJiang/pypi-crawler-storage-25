"""Entry point for `python3 -m staso.codex`."""
from .hook import main

main()
