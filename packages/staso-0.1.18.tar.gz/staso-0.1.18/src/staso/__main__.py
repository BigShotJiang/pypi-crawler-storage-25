"""Allow running `python -m staso` as a CLI entry point."""

from staso.cli import main

main()
