"""Claude Code tracing integration for Staso."""
