"""Entry point for `python3 -m staso.claude_code`."""
from .hook import main

main()
