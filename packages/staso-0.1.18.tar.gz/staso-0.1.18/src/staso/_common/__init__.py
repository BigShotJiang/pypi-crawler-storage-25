"""Shared utilities for CLI agent hook integrations."""
