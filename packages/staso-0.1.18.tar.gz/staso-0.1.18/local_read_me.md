# Staso Python SDK

Python SDK for the Staso platform. Decorator-based tracing and automatic data ingestion for AI agent observability.

## Installation

```bash
pip install staso
pip install -e .

```

# Full Flow 

### 1. Develop on feature branch
git checkout -b feat/new-endpoint

### 2. Merge to main via PR
do chagnes & update docs
git checkout main && git merge feat/new-endpoint

### Bump version (auto-creates git tag)
pipx install bump2version
- Patch release: 0.1.0 → 0.1.1
    - bump2version patch
- Minor release: 0.1.1 → 0.2.0
  - bump2version minor
- Major release: 0.2.0 → 1.0.0
  - bump2version major

### Push tag → triggers GitHub Actions → publishes to PyPI
git push origin main --tags