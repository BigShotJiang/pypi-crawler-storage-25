
from setuptools import setup

setup(
    name="randomnonexistingpackageveryrandom",
    version="0.0.0.1",
    author="",
    author_email="",
    description="",
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent"
    ]
)
