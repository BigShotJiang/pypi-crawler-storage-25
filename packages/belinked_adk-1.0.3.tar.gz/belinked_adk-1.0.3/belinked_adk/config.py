BASE_BELINK_API = "https://belink-api-dev.betaskthai.tech/"
BASE_SHOP_API = "https://shop-api-dev.betaskthai.tech/"

DEFAULT_HEADERS = {
    "Content-Type": "application/json"
}