# belinked_adk/utils/date_parser.py

from datetime import datetime, timedelta
import re


THAI_DAYS = {
    "จันทร์": 0,
    "อังคาร": 1,
    "พุธ": 2,
    "พฤหัส": 3,
    "ศุกร์": 4,
    "เสาร์": 5,
    "อาทิตย์": 6,
}

ENG_DAYS = {
    "monday": 0,
    "tuesday": 1,
    "wednesday": 2,
    "thursday": 3,
    "friday": 4,
    "saturday": 5,
    "sunday": 6,
}


def _next_weekday(today, target_day, offset_week=0):
    days_ahead = target_day - today.weekday()

    if days_ahead <= 0:
        days_ahead += 7

    days_ahead += offset_week * 7
    return today + timedelta(days=days_ahead)


def parse_human_date(text: str) -> str:
    """
    แปลงข้อความวันที่เป็น YYYY-MM-DD

    Args:
        text (str): เช่น "วันนี้", "พรุ่งนี้", "วันจันทร์หน้า", "tomorrow"

    Returns:
        str: วันที่ format YYYY-MM-DD
    """

    text = text.lower().strip()
    today = datetime.today()

    # ===== ไทย =====
    if text in ["วันนี้"]:
        return today.strftime("%Y-%m-%d")

    if text in ["พรุ่งนี้"]:
        return (today + timedelta(days=1)).strftime("%Y-%m-%d")

    if text in ["มะรืน"]:
        return (today + timedelta(days=2)).strftime("%Y-%m-%d")

    # วันจันทร์ / วันจันทร์หน้า
    for th_day, idx in THAI_DAYS.items():
        if th_day in text:
            offset_week = 1 if "หน้า" in text else 0
            target = _next_weekday(today, idx, offset_week)
            return target.strftime("%Y-%m-%d")

    # ===== English =====
    if text in ["today"]:
        return today.strftime("%Y-%m-%d")

    if text in ["tomorrow"]:
        return (today + timedelta(days=1)).strftime("%Y-%m-%d")

    if text in ["day after tomorrow"]:
        return (today + timedelta(days=2)).strftime("%Y-%m-%d")

    for en_day, idx in ENG_DAYS.items():
        if en_day in text:
            offset_week = 1 if "next" in text else 0
            target = _next_weekday(today, idx, offset_week)
            return target.strftime("%Y-%m-%d")

    # ===== fallback (already YYYY-MM-DD) =====
    try:
        parsed = datetime.fromisoformat(text)
        return parsed.strftime("%Y-%m-%d")
    except:
        raise ValueError(f"Cannot parse date: {text}")