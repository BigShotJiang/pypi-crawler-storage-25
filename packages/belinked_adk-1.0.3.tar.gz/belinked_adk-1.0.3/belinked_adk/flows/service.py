def get_services(client, shop_id, branch_id):
    url = f"{client.belink_api}v1/flow-lists/get-with-preload-by-filter"
    params = {
        "shopId": shop_id,
        "branchId": branch_id
    }

    res = client.get(url, params)
    return res["data"]