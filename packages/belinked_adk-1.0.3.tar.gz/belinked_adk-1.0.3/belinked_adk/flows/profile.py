def get_profiles(client, member_id):
    url = f"{client.belink_api}v1/profiles/get-by-filter-by-memberId/{member_id}"
    res = client.get(url)
    return res["data"]


def get_custom_fields(client, shop_id):
    url = f"{client.belink_api}v1/custom-field-profiles/get-by-filter"
    params = {"shopId": shop_id}
    res = client.get(url, params)
    return res["data"]


def create_profile(client, payload):
    url = f"{client.belink_api}v1/profile-composite/create"
    res = client.post(url, payload)
    return res["data"]