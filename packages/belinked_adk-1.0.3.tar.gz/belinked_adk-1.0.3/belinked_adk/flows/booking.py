def create_booking(client, payload):
    url = f"{client.belink_api}v1/booking-composite/create"
    res = client.post(url, payload)
    return res["data"]