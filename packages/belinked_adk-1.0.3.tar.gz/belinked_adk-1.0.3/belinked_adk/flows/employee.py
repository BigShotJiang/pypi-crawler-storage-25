def get_employees(client, shop_id, branch_id, flow_list_ids):
    url = f"{client.belink_api}v1/employees/get-by-filter-flowListId-branchId"

    payload = {
        "shopId": shop_id,
        "branchId": branch_id,
        "flowListIds": flow_list_ids,
        "isActive": True
    }

    res = client.post(url, payload)
    return res["data"]