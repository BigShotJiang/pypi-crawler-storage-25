def get_slots(client, shop_id, branch_id, flow_list_id, employee_id, date):
    url = f"{client.belink_api}v1/manage-queue/get-queue-day"

    payload = {
        "shopId": shop_id,
        "branchId": branch_id,
        "flowsListId": [flow_list_id],
        "employeeId": employee_id,
        "date": date
    }

    res = client.post(url, payload)
    return res["data"]