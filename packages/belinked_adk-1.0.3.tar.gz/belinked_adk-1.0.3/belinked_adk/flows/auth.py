from ..client import BetaskClient


def authenticate(client: BetaskClient, payload: dict):
    """
    Get access_token + memberId
    """

    url = f"{client.belink_api}aut/service-authen-user-line-id"
    res = client.post(url, payload)

    return res["data"]