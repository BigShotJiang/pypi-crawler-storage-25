def get_branches(client, shop_id):
    url = f"{client.shop_api}v1/branchs"
    params = {"shopId": shop_id}

    res = client.get(url, params)
    return res["data"]