# belinked_adk/tools/get_branches.py
from belinked_adk.client import BetaskClient
from belinked_adk.flows.branch import get_branches
from belinked_adk.utils.client import init_authenticated_client

# -------------------------
# Public API
# -------------------------
def get_branches_tool(
    line_user_id: str,
    line_display_name: str,
    shop_id: str,
):
    client, member_id = init_authenticated_client(line_user_id, line_display_name)

    branches = _get_branches(client, shop_id)

    return {
        "status": "SUCCESS",
        "branches": branches,
    }


def _get_branches(client, shop_id):
    raw_branches = get_branches(client, shop_id)

    if not raw_branches:
        return []

    return [_map_branch(b) for b in raw_branches]


def _map_branch(branch):
    return {
        "branchId": branch.get("id"),
        "branchName": branch.get("nameTh"),
    }