# belinked_adk/tools/browse_services.py
from belinked_adk.client import BetaskClient
from belinked_adk.flows.service import get_services
from belinked_adk.utils.client import init_authenticated_client


# -------------------------
# Public API
# -------------------------
def browse_services_tool(
    line_user_id: str,
    line_display_name: str,
    shop_id: str,
    branch_id: str,
):
    client, member_id = init_authenticated_client(line_user_id, line_display_name)

    services = _get_services(client, shop_id, branch_id)

    return {
        "status": "SUCCESS",
        "branchId": branch_id,
        "services": services,
    }

def _get_services(client, shop_id, branch_id):
    raw_services = get_services(client, shop_id, branch_id)

    if not raw_services:
        return []

    return [_map_service(s) for s in raw_services]


def _map_service(service):
    flow = service.get("flow", {})

    return {
        "flowListId": service.get("flowListId"),
        "name": flow.get("flowNameAll", {}).get("th"),
        "price": flow.get("serviceFee"),
        "duration": flow.get("durationMinutes"),
    }