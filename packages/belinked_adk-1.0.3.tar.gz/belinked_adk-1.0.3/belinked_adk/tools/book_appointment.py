# belinked_adk/tools/book_appointment.py
from belinked_adk.client import BetaskClient
from belinked_adk.flows.branch import get_branches
from belinked_adk.flows.service import get_services
from belinked_adk.flows.employee import get_employees
from belinked_adk.flows.availability import get_slots
from belinked_adk.flows.profile import get_profiles, create_profile
from belinked_adk.flows.booking import create_booking
from belinked_adk.utils.client import init_authenticated_client

# -------------------------
# Public API
# -------------------------
def book_appointment_tool(
    line_user_id: str,
    line_display_name: str,
    shop_id: str,
    service_keyword: str,
    date: str,
    time: str,
    remark: str = "",
):
    client, member_id = init_authenticated_client(line_user_id, line_display_name)

    branch_id = _get_default_branch(client, shop_id)

    service = _select_service(client, shop_id, branch_id, service_keyword)
    flow_list_id = service["flowListId"]
    flow_id = service["flow"]["flowId"]

    employee_id = _get_default_employee(
        client, shop_id, branch_id, flow_list_id
    )

    slot_result = _get_valid_slot(
        client, shop_id, branch_id, flow_list_id, employee_id, date, time
    )
    if slot_result["status"] == "NO_SLOT":
        return slot_result

    profile_id = _get_or_create_profile(client, member_id, shop_id)

    booking = _create_booking(
        client,
        profile_id,
        member_id,
        shop_id,
        branch_id,
        flow_list_id,
        flow_id,
        employee_id,
        date,
        slot_result["time"],
        remark,
    )

    return {
        "status": "SUCCESS",
        "message": "จองสำเร็จ",
        "booking": booking,
    }


def _get_default_branch(client, shop_id):
    branches = get_branches(client, shop_id)
    if not branches:
        raise ValueError("No branches found")
    return branches[0]["id"]


def _select_service(client, shop_id, branch_id, keyword):
    services = get_services(client, shop_id, branch_id)

    if not services:
        raise ValueError("No services found")

    return next(
        (
            s for s in services
            if keyword in s["flow"]["flowNameAll"]["th"]
        ),
        services[0],
    )


def _get_default_employee(client, shop_id, branch_id, flow_list_id):
    employees = get_employees(client, shop_id, branch_id, [flow_list_id])

    if not employees:
        raise ValueError("No employees available")

    return employees[0]["employeeId"]


def _get_valid_slot(
    client,
    shop_id,
    branch_id,
    flow_list_id,
    employee_id,
    date,
    requested_time,
):
    slots = get_slots(
        client, shop_id, branch_id, flow_list_id, employee_id, date
    )

    available = slots[0]["availableSlots"]

    matched = next(
        (
            s for s in available
            if s["startTime"] == requested_time
            and s["status"] == "available"
        ),
        None,
    )

    if not matched:
        return {
            "status": "NO_SLOT",
            "message": "ไม่มีเวลาที่คุณเลือก",
            "availableSlots": [
                s["startTime"]
                for s in available
                if s["status"] == "available"
            ],
        }

    return {
        "status": "OK",
        "time": matched["startTime"],
    }


def _get_or_create_profile(client, member_id, shop_id):
    profiles = get_profiles(client, member_id)

    if profiles:
        return profiles[0]["profileId"]

    profile = create_profile(
        client,
        {
            "profile": {
                "memberId": member_id,
                "shopId": shop_id,
            },
            "dataFields": [],
        },
    )

    return profile["profileId"]


def _create_booking(
    client,
    profile_id,
    member_id,
    shop_id,
    branch_id,
    flow_list_id,
    flow_id,
    employee_id,
    date,
    time,
    remark,
):
    payload = {
        "profileId": profile_id,
        "startDate": date,
        "startTime": time,
        "shopId": shop_id,
        "branchId": branch_id,
        "createdUserId": member_id,
        "userType": "USER",
        "remark": remark,
        "flowLists": [
            {
                "flowListId": flow_list_id,
                "flows": [
                    {
                        "flowId": flow_id,
                        "employeeId": employee_id,
                        "quantity": 1,
                        "options": [],
                    }
                ],
            }
        ],
    }

    return create_booking(client, payload)