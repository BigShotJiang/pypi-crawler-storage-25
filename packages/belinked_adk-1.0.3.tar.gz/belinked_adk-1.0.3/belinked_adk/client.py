import requests
from .config import DEFAULT_HEADERS


class BetaskClient:

    def __init__(self, belink_api, shop_api, access_token=None):
        self.belink_api = belink_api
        self.shop_api = shop_api
        self.access_token = access_token

    def _headers(self):
        headers = DEFAULT_HEADERS.copy()
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def get(self, url, params=None):
        return requests.get(url, headers=self._headers(), params=params).json()

    def post(self, url, json=None):
        return requests.post(url, headers=self._headers(), json=json).json()