<p align="center">
  <img src="https://raw.githubusercontent.com/javipd/swipic/main/demo.gif" alt="swipic demo" width="700">
</p>

<h1 align="center">swipic</h1>

<p align="center">
  <em>Stop hoarding photos you'll never look at.</em>
</p>

<p align="center">
  <a href="https://pypi.org/project/swipic/"><img src="https://img.shields.io/pypi/v/swipic?color=%23FF6B6B&label=PyPI" alt="PyPI"></a>
  <img src="https://img.shields.io/badge/macOS-black?logo=apple&logoColor=white" alt="macOS">
  <img src="https://img.shields.io/badge/python-3.10%2B-blue?logo=python&logoColor=white" alt="Python 3.10+">
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-green" alt="MIT License"></a>
  <a href="https://github.com/javipd/swipic/stargazers"><img src="https://img.shields.io/github/stars/javipd/swipic?style=social" alt="GitHub stars"></a>
</p>

---

- 📸 **Tinder-style swiping** for your macOS Photos.app library
- ⌨️ **Keyboard-driven** — `→` keep, `←` reject, `U` undo
- 📅 **Filter by date** — year, month, or specific day
- 🗑️ **Safe deletes** — one confirmation for the whole batch, 30-day recovery
- 🍎 **Native macOS** — reads Photos.app directly, no export needed

## Install

```bash
pipx install swipic
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uvx swipic
```

## Usage

```bash
swipic              # all photos
swipic 2023         # only 2023
swipic 2023-06      # only June 2023
swipic 2023-06-15   # only that day
```

<details>
<summary>⌨️ Keyboard controls</summary>

| Key | Action |
|-----|--------|
| `→` | Keep photo |
| `←` | Reject photo |
| `U` | Undo last decision |
| `Q` / `Esc` | End session |

</details>

## How it works

1. swipic reads your Photos.app library directly
2. Photos appear one by one — press `→` to keep or `←` to reject
3. When you're done, macOS asks for confirmation once for all rejected photos
4. Confirmed deletions go to **Recently Deleted** (recoverable for 30 days)

## Setup

swipic needs access to your Photos library. Grant it in:

**System Settings → Privacy & Security → Photos** → set **Terminal** (or iTerm2) to **Full Access**

If Terminal doesn't appear in the list, click `+` and add it from `/Applications/Utilities/Terminal.app`.

## License

MIT
