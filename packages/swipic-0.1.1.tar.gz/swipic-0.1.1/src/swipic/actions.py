from __future__ import annotations

import sys

import objc
import Photos

PHAccessLevelReadWrite = 2


def _request_authorization() -> bool:
    status = Photos.PHPhotoLibrary.authorizationStatusForAccessLevel_(
        PHAccessLevelReadWrite
    )
    if status == Photos.PHAuthorizationStatusAuthorized:
        return True

    for _ in range(2):
        Photos.PHPhotoLibrary.requestAuthorizationForAccessLevel_handler_(
            PHAccessLevelReadWrite, lambda _: None
        )
        status = Photos.PHPhotoLibrary.authorizationStatusForAccessLevel_(
            PHAccessLevelReadWrite
        )
        if status == Photos.PHAuthorizationStatusAuthorized:
            return True

    return False


def _fetch_assets(uuids: list[str]) -> list:
    clean = [u.split("/")[0] for u in uuids]
    with objc.autorelease_pool():
        options = Photos.PHFetchOptions.alloc().init()
        result = Photos.PHAsset.fetchAssetsWithLocalIdentifiers_options_(clean, options)
        if not result or result.count() == 0:
            return []
        return [result.objectAtIndex_(i) for i in range(result.count())]


def delete_rejected_photos(uuids: list[str]) -> bool:
    if not uuids:
        return True

    if not _request_authorization():
        print("  ⚠️  Photos access denied.")
        print("     Grant access: System Settings → Privacy & Security → Photos")
        return False

    assets = _fetch_assets(uuids)
    if not assets:
        print(f"  ⚠️  None of the {len(uuids)} photos were found in Photos library.")
        return False

    not_found = len(uuids) - len(assets)
    if not_found:
        print(f"  ({not_found} photo(s) not found — already deleted or wrong library)")

    print(f"  Deleting {len(assets)} photo(s) — confirm in the system dialog…")

    with objc.autorelease_pool():
        success, error = Photos.PHPhotoLibrary.sharedPhotoLibrary(
        ).performChangesAndWait_error_(
            lambda: Photos.PHAssetChangeRequest.deleteAssets_(assets),
            None,
        )

    if error:
        print(f"  ⚠️  Delete failed: {error}", file=sys.stderr)
        return False

    print(f"  ✓ {len(assets)} photo(s) moved to Recently Deleted.")
    return True
