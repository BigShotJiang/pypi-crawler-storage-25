from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path


if sys.platform != "darwin":
    raise RuntimeError("swipic only works on macOS.")


@dataclass
class Photo:
    uuid: str
    path: Path
    filename: str
    date: datetime | None


def parse_period(arg: str) -> tuple[date, date]:
    if re.fullmatch(r"\d{4}", arg):
        y = int(arg)
        return date(y, 1, 1), date(y, 12, 31)

    if re.fullmatch(r"\d{4}-\d{2}", arg):
        y, m = int(arg[:4]), int(arg[5:7])
        if m == 12:
            end = date(y + 1, 1, 1)
        else:
            end = date(y, m + 1, 1)
        return date(y, m, 1), end

    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", arg):
        d = date.fromisoformat(arg)
        return d, d

    print(f"Invalid period: {arg}")
    print("Expected: YYYY, YYYY-MM, or YYYY-MM-DD")
    sys.exit(1)


def load_photos(period: tuple[date, date] | None = None) -> list[Photo]:
    import osxphotos

    try:
        db = osxphotos.PhotosDB()
    except OSError as e:
        if "Operation not permitted" in str(e) or "Error copying" in str(e):
            print(
                "\n⚠️  No access to Photos library."
                "\n   Go to: System Settings → Privacy & Security → Photos"
                "\n   and enable Full Access for Terminal (or iTerm2)."
            )
            sys.exit(1)
        raise

    result: list[Photo] = []

    seen_uuids: set[str] = set()

    for p in db.photos():
        if p.ismissing or p.path is None or p.ismovie:
            continue
        if p.uuid in seen_uuids:
            continue
        seen_uuids.add(p.uuid)
        if period is not None:
            if p.date is None:
                continue
            photo_date = p.date.date()
            if photo_date < period[0] or photo_date > period[1]:
                continue
        edited = p.path_edited if p.hasadjustments and p.path_edited else None
        path = Path(edited) if edited else Path(p.path)
        if not path.exists():
            path = Path(p.path)
            if not path.exists():
                continue
        result.append(
            Photo(
                uuid=p.uuid,
                path=path,
                filename=p.original_filename or p.filename,
                date=p.date,
            )
        )

    return result
