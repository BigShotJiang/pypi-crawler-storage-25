from __future__ import annotations

from typing import Literal

import objc
import AppKit
import Quartz
from AppKit import NSApp, NSApplication
from Foundation import NSMakeRect, NSURL
from PyObjCTools import AppHelper

from swipic.photos import Photo

Decision = Literal["keep", "reject"]

KEY_LEFT = 123
KEY_RIGHT = 124
KEY_ESC = 53
KEY_Q = 12
KEY_U = 32
KEY_Z = 6

KEEP_COLOR = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.18, 0.82, 0.45, 1.0)
REJECT_COLOR = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.92, 0.25, 0.25, 1.0)
DIM = AppKit.NSColor.colorWithWhite_alpha_(1.0, 0.55)
FAINT = AppKit.NSColor.colorWithWhite_alpha_(1.0, 0.35)


class PhotoWindow(AppKit.NSWindow):
    def canBecomeKeyWindow(self):
        return True

    def canBecomeMainWindow(self):
        return True

    def keyDown_(self, event):
        self.delegate().handleKey_(event.keyCode())


def _pill(frame, corner_radius=None, tint=None):
    x, y, w, h = frame
    v = AppKit.NSVisualEffectView.alloc().initWithFrame_(NSMakeRect(x, y, w, h))
    v.setMaterial_(10)
    v.setBlendingMode_(1)
    v.setState_(1)
    v.setWantsLayer_(True)
    r = corner_radius if corner_radius is not None else h / 2.0
    v.layer().setCornerRadius_(r)
    v.layer().setMasksToBounds_(True)
    if tint:
        v.layer().setBackgroundColor_(tint.CGColor())
    return v


def _label(frame, text="", size=13.0, color=None, bold=False, align=1):
    x, y, w, h = frame
    tf = AppKit.NSTextField.alloc().initWithFrame_(NSMakeRect(x, y, w, h))
    tf.setStringValue_(text)
    tf.setEditable_(False)
    tf.setSelectable_(False)
    tf.setBezeled_(False)
    tf.setDrawsBackground_(False)
    tf.setTextColor_(color or AppKit.NSColor.whiteColor())
    if bold:
        tf.setFont_(AppKit.NSFont.boldSystemFontOfSize_(size))
    else:
        tf.setFont_(AppKit.NSFont.systemFontOfSize_(size))
    tf.setAlignment_(align)
    return tf


def _add(parent, *views):
    for v in views:
        parent.addSubview_(v)


def _shadow_label(frame, text="", size=11.0, color=None, bold=False, align=0):
    tf = _label(frame, text, size, color, bold, align)
    tf.setWantsLayer_(True)
    shadow = AppKit.NSShadow.alloc().init()
    shadow.setShadowColor_(AppKit.NSColor.colorWithWhite_alpha_(0.0, 0.8))
    shadow.setShadowOffset_((0, -1))
    shadow.setShadowBlurRadius_(3.0)
    tf.setShadow_(shadow)
    return tf


def _build_hud(d):
    d._counter_bg = _pill((0, 0, 74, 22))
    d._counter = _label((0, 0, 74, 22), size=11, bold=True)
    _add(d._root, d._counter_bg, d._counter)

    d._fname = _shadow_label((0, 0, 300, 16), size=10, color=DIM)
    d._root.addSubview_(d._fname)

    tint_red = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.85, 0.15, 0.15, 0.45)
    d._reject_bg = _pill((0, 0, 96, 30), tint=tint_red)
    d._reject_lbl = _label((0, 0, 96, 30), text="← Reject", size=12, bold=True, color=REJECT_COLOR)
    d._reject_bg.setAlphaValue_(0.88)
    d._reject_lbl.setAlphaValue_(0.88)
    _add(d._root, d._reject_bg, d._reject_lbl)

    tint_green = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.1, 0.7, 0.3, 0.45)
    d._keep_bg = _pill((0, 0, 86, 30), tint=tint_green)
    d._keep_lbl = _label((0, 0, 86, 30), text="Keep →", size=12, bold=True, color=KEEP_COLOR)
    d._keep_bg.setAlphaValue_(0.88)
    d._keep_lbl.setAlphaValue_(0.88)
    _add(d._root, d._keep_bg, d._keep_lbl)

    d._hint = _shadow_label((0, 0, 140, 16), text="U undo  ·  Q quit", size=10, color=AppKit.NSColor.colorWithWhite_alpha_(1.0, 0.75), bold=True, align=1)
    d._root.addSubview_(d._hint)

    tint_badge_keep = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.1, 0.7, 0.3, 0.35)
    d._badge_bg = _pill((0, 0, 90, 24), tint=tint_badge_keep)
    d._badge = _label((0, 0, 90, 24), size=10, bold=True)
    d._badge_bg.setAlphaValue_(0.0)
    d._badge.setAlphaValue_(0.0)
    _add(d._root, d._badge_bg, d._badge)


def _layout_hud(d):
    W, H = d._W, d._H
    m = 12

    cw, ch = 74, 22
    d._counter_bg.setFrame_(NSMakeRect(m, H - ch - m, cw, ch))
    d._counter.setFrame_(NSMakeRect(m, H - ch - m, cw, ch))

    d._fname.setFrame_(NSMakeRect(m + 2, H - ch - m - 18, 300, 16))

    rw, rh = 96, 30
    d._reject_bg.setFrame_(NSMakeRect(m, m, rw, rh))
    d._reject_lbl.setFrame_(NSMakeRect(m, m - 7, rw, rh))

    kw, kh = 86, 30
    d._keep_bg.setFrame_(NSMakeRect(W - kw - m, m, kw, kh))
    d._keep_lbl.setFrame_(NSMakeRect(W - kw - m, m - 7, kw, kh))

    hw = 140
    hx = (W - hw) / 2
    d._hint.setFrame_(NSMakeRect(hx, H - 22 - m, hw, 16))

    bw, bh = 90, 24
    bx = W - bw - m
    by = H - bh - m
    d._badge_bg.setFrame_(NSMakeRect(bx, by, bw, bh))
    d._badge.setFrame_(NSMakeRect(bx, by, bw, bh))


def _layout_summary(d):
    if not getattr(d, "_summary_panel", None):
        return

    W, H = d._W, d._H
    pw, ph = 360, 280
    px = (W - pw) / 2
    py = (H - ph) / 2

    d._summary_panel.setFrame_(NSMakeRect(px, py, pw, ph))
    d._summary_title.setFrame_(NSMakeRect(px, py + ph - 52, pw, 30))
    d._summary_keep.setFrame_(NSMakeRect(px + 32, py + ph - 92, pw - 64, 24))
    d._summary_reject.setFrame_(NSMakeRect(px + 32, py + ph - 122, pw - 64, 24))
    d._summary_skipped.setFrame_(NSMakeRect(px + 32, py + ph - 150, pw - 64, 22))

    if d._summary_recent is not None:
        d._summary_recent.setFrame_(NSMakeRect(px + 32, py + ph - 180, pw - 64, 18))

    d._summary_hint.setFrame_(NSMakeRect(px, py + 16, pw, 18))


def _layout_views(d):
    bounds = d._root.bounds()
    d._W = bounds.size.width
    d._H = bounds.size.height
    d._iv.setFrame_(bounds)
    d._flash.setFrame_(bounds)
    _layout_hud(d)
    _layout_summary(d)


_RAW_EXTS = {"arw", "cr2", "nef", "dng", "raf", "rw2", "orf", "srw", "pef"}


def _load_image(path_str):
    ext = path_str.rsplit(".", 1)[-1].lower() if "." in path_str else ""
    if ext not in _RAW_EXTS:
        img = AppKit.NSImage.alloc().initWithContentsOfFile_(path_str)
        if img and img.size().width > 0:
            return img
    with objc.autorelease_pool():
        url = NSURL.fileURLWithPath_(path_str)
        ci_filter = Quartz.CIFilter.filterWithImageURL_options_(url, None)
        if not ci_filter:
            return None
        ci_image = ci_filter.outputImage()
        if not ci_image:
            return None
        extent = ci_image.extent()
        ctx = Quartz.CIContext.context()
        cg_image = ctx.createCGImage_fromRect_(ci_image, extent)
        if not cg_image:
            return None
        bmp = AppKit.NSBitmapImageRep.alloc().initWithCGImage_(cg_image)
        img = AppKit.NSImage.alloc().initWithSize_((bmp.pixelsWide(), bmp.pixelsHigh()))
        img.addRepresentation_(bmp)
        return img


def _load_current(d):
    if not d._photos:
        return
    photo = d._photos[d._index]
    img = _load_image(str(photo.path))
    d._iv.setImage_(img)
    _refresh_hud(d)


def _crossfade(d):
    photo = d._photos[d._index]
    img = _load_image(str(photo.path))

    def fade_out(ctx):
        ctx.setDuration_(0.08)
        d._iv.animator().setAlphaValue_(0.3)

    def swap():
        d._iv.setImage_(img)
        _refresh_hud(d)
        AppKit.NSAnimationContext.beginGrouping()
        AppKit.NSAnimationContext.currentContext().setDuration_(0.12)
        d._iv.animator().setAlphaValue_(1.0)
        AppKit.NSAnimationContext.endGrouping()

    AppKit.NSAnimationContext.runAnimationGroup_completionHandler_(fade_out, swap)


def _refresh_hud(d):
    photo = d._photos[d._index]
    d._counter.setStringValue_(f"{d._index + 1} / {len(d._photos)}")
    d._fname.setStringValue_(photo.filename)

    dec = d._decisions.get(photo.uuid)
    if dec == "keep":
        d._badge.setStringValue_("✓ Keep")
        d._badge.setTextColor_(KEEP_COLOR)
        t = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.1, 0.7, 0.3, 0.35)
        d._badge_bg.layer().setBackgroundColor_(t.CGColor())
        _fade_badge(d, 1.0)
    elif dec == "reject":
        d._badge.setStringValue_("✗ Reject")
        d._badge.setTextColor_(REJECT_COLOR)
        t = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.85, 0.15, 0.15, 0.35)
        d._badge_bg.layer().setBackgroundColor_(t.CGColor())
        _fade_badge(d, 1.0)
    else:
        d._badge_bg.setAlphaValue_(0.0)
        d._badge.setAlphaValue_(0.0)


def _fade_badge(d, alpha):
    AppKit.NSAnimationContext.beginGrouping()
    AppKit.NSAnimationContext.currentContext().setDuration_(0.15)
    d._badge_bg.animator().setAlphaValue_(alpha)
    d._badge.animator().setAlphaValue_(alpha)
    AppKit.NSAnimationContext.endGrouping()


def _do_flash(d, color):
    return None


def _pulse_decision_pill(d, decision):
    bg = d._keep_bg if decision == "keep" else d._reject_bg
    lbl = d._keep_lbl if decision == "keep" else d._reject_lbl

    if decision == "keep":
        hot = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.1, 0.85, 0.4, 0.75)
        rest = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.1, 0.7, 0.3, 0.45)
    else:
        hot = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.92, 0.15, 0.15, 0.75)
        rest = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.85, 0.15, 0.15, 0.45)

    bg.layer().setBackgroundColor_(hot.CGColor())
    lbl.setTextColor_(AppKit.NSColor.whiteColor())
    bg.setAlphaValue_(1.0)
    lbl.setAlphaValue_(1.0)

    def settle(ctx):
        ctx.setDuration_(0.3)
        bg.animator().setAlphaValue_(0.88)
        lbl.animator().setAlphaValue_(0.88)

    def restore():
        bg.layer().setBackgroundColor_(rest.CGColor())
        lbl.setTextColor_(KEEP_COLOR if decision == "keep" else REJECT_COLOR)

    AppKit.NSAnimationContext.runAnimationGroup_completionHandler_(settle, restore)


def _decide(d, decision):
    photo = d._photos[d._index]
    d._decisions[photo.uuid] = decision
    _pulse_decision_pill(d, decision)

    if d._index < len(d._photos) - 1:
        d._history.append(d._index)
        d._index += 1
        _crossfade(d)
    else:
        _finish(d)


def _undo(d):
    if d._history:
        d._index = d._history.pop()
        _crossfade(d)


def _finish(d):
    d._summary = True
    for v in [
        d._counter_bg, d._counter, d._fname,
        d._reject_bg, d._reject_lbl, d._keep_bg, d._keep_lbl,
        d._hint, d._badge_bg, d._badge, d._flash,
    ]:
        v.setAlphaValue_(0.0)
    d._iv.setAlphaValue_(0.15)
    _show_summary(d)


def _show_summary(d):
    kept = sum(1 for v in d._decisions.values() if v == "keep")
    rejected = sum(1 for v in d._decisions.values() if v == "reject")
    skipped = len(d._photos) - kept - rejected

    d._summary_panel = _pill((0, 0, 360, 280), corner_radius=16)
    d._summary_title = _label((0, 0, 360, 30), text="Session complete", size=22, bold=True)
    d._summary_keep = _label(
        (0, 0, 280, 24),
        text=f"✓  Keep:      {kept}", size=16, bold=True, color=KEEP_COLOR, align=0,
    )
    d._summary_reject = _label(
        (0, 0, 280, 24),
        text=f"✗  Reject:    {rejected}", size=16, bold=True, color=REJECT_COLOR, align=0,
    )
    d._summary_skipped = _label(
        (0, 0, 280, 22),
        text=f"–  Skipped:   {skipped}", size=13, color=DIM, align=0,
    )

    d._summary_recent = None
    if rejected > 0:
        d._summary_recent = _label(
            (0, 0, 280, 18),
            text=f"{rejected} photo(s) → Recently Deleted", size=11, color=DIM, align=0,
        )

    d._summary_hint = _label(
        (0, 0, 360, 18),
        text="Press any key to finish", size=11, color=FAINT,
    )

    views = [
        d._summary_panel,
        d._summary_title,
        d._summary_keep,
        d._summary_reject,
        d._summary_skipped,
        d._summary_hint,
    ]
    if d._summary_recent is not None:
        views.append(d._summary_recent)
    _add(d._root, *views)
    _layout_summary(d)


class AppDelegate(AppKit.NSObject):

    def init(self):
        self = objc.super(AppDelegate, self).init()
        if self is None:
            return None
        self._photos = []
        self._index = 0
        self._decisions = {}
        self._history = []
        self._summary = False
        self._summary_panel = None
        self._summary_title = None
        self._summary_keep = None
        self._summary_reject = None
        self._summary_skipped = None
        self._summary_recent = None
        self._summary_hint = None
        return self

    def applicationDidFinishLaunching_(self, _):
        screen = AppKit.NSScreen.mainScreen()
        r = screen.frame()
        self._W = r.size.width * 0.8
        self._H = r.size.height * 0.8

        rect = NSMakeRect(0, 0, self._W, self._H)
        style = (
            AppKit.NSWindowStyleMaskTitled
            | AppKit.NSWindowStyleMaskClosable
            | AppKit.NSWindowStyleMaskMiniaturizable
            | AppKit.NSWindowStyleMaskResizable
        )

        self._win = PhotoWindow.alloc().initWithContentRect_styleMask_backing_defer_(
            rect, style, AppKit.NSBackingStoreBuffered, False,
        )
        bg = AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(20 / 255.0, 20 / 255.0, 20 / 255.0, 1.0)
        self._win.setBackgroundColor_(bg)
        self._win.setTitle_("swipic")
        self._win.setTitlebarAppearsTransparent_(True)
        self._win.setTitleVisibility_(1)
        self._win.setAppearance_(AppKit.NSAppearance.appearanceNamed_("NSAppearanceNameVibrantDark"))
        self._win.setDelegate_(self)
        self._win.center()

        root = AppKit.NSView.alloc().initWithFrame_(rect)
        root.setWantsLayer_(True)
        root.layer().setBackgroundColor_(bg.CGColor())
        self._win.setContentView_(root)
        self._root = root

        self._iv = AppKit.NSImageView.alloc().initWithFrame_(rect)
        self._iv.setImageScaling_(AppKit.NSImageScaleProportionallyUpOrDown)
        self._iv.setImageAlignment_(AppKit.NSImageAlignCenter)
        self._iv.setWantsLayer_(True)
        self._iv.layer().setBackgroundColor_(bg.CGColor())
        self._iv.setAutoresizingMask_(AppKit.NSViewWidthSizable | AppKit.NSViewHeightSizable)
        root.addSubview_(self._iv)

        self._flash = AppKit.NSView.alloc().initWithFrame_(self._iv.bounds())
        self._flash.setWantsLayer_(True)
        self._flash.setAlphaValue_(1.0)
        self._flash.layer().setOpacity_(0.0)
        self._flash.setAutoresizingMask_(AppKit.NSViewWidthSizable | AppKit.NSViewHeightSizable)
        self._iv.addSubview_(self._flash)

        _build_hud(self)
        _layout_views(self)
        _load_current(self)

        self._win.makeKeyAndOrderFront_(None)
        NSApp.activateIgnoringOtherApps_(True)

    def handleKey_(self, kc):
        if self._summary:
            self._win.orderOut_(None)
            NSApp.stop_(None)
            return

        if kc == KEY_RIGHT:
            _decide(self, "keep")
        elif kc == KEY_LEFT:
            _decide(self, "reject")
        elif kc in (KEY_U, KEY_Z):
            _undo(self)
        elif kc in (KEY_ESC, KEY_Q):
            _finish(self)

    def applicationShouldTerminateAfterLastWindowClosed_(self, _):
        return True

    def windowDidResize_(self, _):
        _layout_views(self)

    def windowShouldClose_(self, _):
        if self._summary:
            self._win.orderOut_(None)
            NSApp.stop_(None)
            return False
        _finish(self)
        return False


def _set_app_icon():
    size = 1024
    img = AppKit.NSImage.alloc().initWithSize_((size, size))
    img.lockFocus()

    bg = AppKit.NSColor.colorWithRed_green_blue_alpha_(0.15, 0.15, 0.15, 1.0)
    path = AppKit.NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(
        ((0, 0), (size, size)), 224, 224
    )
    bg.set()
    path.fill()

    attrs = {
        AppKit.NSFontAttributeName: AppKit.NSFont.systemFontOfSize_weight_(480, AppKit.NSFontWeightBold),
        AppKit.NSForegroundColorAttributeName: AppKit.NSColor.whiteColor(),
    }
    s = AppKit.NSAttributedString.alloc().initWithString_attributes_("S", attrs)
    sw, sh = s.size().width, s.size().height
    s.drawAtPoint_((((size - sw) / 2), (size - sh) / 2 - 1))

    img.unlockFocus()
    NSApp.setApplicationIconImage_(img)


def run_app(photos: list[Photo]) -> dict[str, Decision]:
    with objc.autorelease_pool():
        objc.lookUpClass("NSProcessInfo").processInfo().setProcessName_("swipic")
        NSApplication.sharedApplication()
        NSApp.setActivationPolicy_(AppKit.NSApplicationActivationPolicyRegular)

        _set_app_icon()

        menubar = AppKit.NSMenu.alloc().init()
        app_menu_item = AppKit.NSMenuItem.alloc().init()
        menubar.addItem_(app_menu_item)
        NSApp.setMainMenu_(menubar)
        app_menu = AppKit.NSMenu.alloc().initWithTitle_("swipic")
        app_menu.addItemWithTitle_action_keyEquivalent_("Quit swipic", "terminate:", "q")
        app_menu_item.setSubmenu_(app_menu)

        delegate = AppDelegate.alloc().init()
        delegate._photos = photos

        NSApp.setDelegate_(delegate)
        NSApp.activateIgnoringOtherApps_(True)
        AppHelper.runEventLoop(installInterrupt=True)

        return dict(delegate._decisions)
