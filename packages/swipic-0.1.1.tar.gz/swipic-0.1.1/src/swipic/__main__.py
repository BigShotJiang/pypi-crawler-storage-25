from __future__ import annotations

import sys


def main() -> None:
    if sys.platform != "darwin":
        print("swipic only works on macOS.")
        sys.exit(1)

    from swipic.photos import load_photos, parse_period

    period = None
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if args:
        period = parse_period(args[0])

    if period:
        print(f"swipic – Loading photos from {args[0]}…")
    else:
        print("swipic – Loading your Photos library…")

    photos = load_photos(period=period)

    if not photos:
        print("No photos found.")
        sys.exit(0)

    print(f"{len(photos)} photos found. Starting session…")

    from swipic.app import run_app
    decisions = run_app(photos)

    rejected = [uuid for uuid, d in decisions.items() if d == "reject"]
    if rejected:
        print(f"\nDeleting {len(rejected)} rejected photo(s)…")
        from swipic.actions import delete_rejected_photos
        delete_rejected_photos(rejected)


if __name__ == "__main__":
    main()
