import cv2
import mediapipe as mp
from typing import Optional, Callable, List, Tuple
from dataclasses import dataclass


@dataclass
class HandDetectionResult:
    """手部检测结果数据类"""
    hand_index: int
    xmin: int
    ymin: int
    xmax: int
    ymax: int
    confidence: float
    landmarks: List[Tuple[int, int]]


@dataclass
class HandDetectorConfig:
    """手部检测器配置"""
    max_num_hands: int = 2
    min_detection_confidence: float = 0.5
    min_tracking_confidence: float = 0.1
    box_padding: int = 20
    mirror_frame: bool = True
    show_landmarks: bool = False


class HandDetector:
    """手部检测器类
    
    功能：
    - 实时检测手部位置
    - 计算手部边界框
    - 支持自定义回调处理检测结果
    - 支持配置化参数
    
    使用示例：
        detector = HandDetector()
        
        def on_hand_detected(results):
            for hand in results:
                print(f"手部{hand.hand_index}位置: {hand.xmin},{hand.ymin}")
        
        detector.start_detection(callback=on_hand_detected)
    """
    
    def __init__(self, config: Optional[HandDetectorConfig] = None):
        """初始化手部检测器
        
        Args:
            config: 检测器配置，如果为None则使用默认配置
        """
        self.config = config or HandDetectorConfig()
        
        # 初始化MediaPipe组件
        self._init_mediapipe()
        
        # 摄像头相关
        self.cap = None
        self.frame_width = 0
        self.frame_height = 0
        
        # 回调函数
        self.callback: Optional[Callable[[List[HandDetectionResult]], None]] = None
        
        # 运行状态
        self.is_running = False
    
    def _init_mediapipe(self):
        """初始化MediaPipe组件"""
        self.mp_hands = mp.solutions.hands
        self.mp_drawing = mp.solutions.drawing_utils
        
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=self.config.max_num_hands,
            min_detection_confidence=self.config.min_detection_confidence,
            min_tracking_confidence=self.config.min_tracking_confidence
        )
    
    def _process_frame(self, frame) -> List[HandDetectionResult]:
        """处理单帧画面，返回检测结果
        
        Args:
            frame: 输入画面帧
            
        Returns:
            手部检测结果列表
        """
        # 镜像翻转
        # if self.config.mirror_frame:
        #     frame = cv2.flip(frame, 1)
        
        # BGR转RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb_frame.flags.writeable = False
        
        # 执行检测
        results = self.hands.process(rgb_frame)
        
        rgb_frame.flags.writeable = True
        frame = cv2.cvtColor(rgb_frame, cv2.COLOR_RGB2BGR)
        
        # 解析检测结果
        detection_results = []
        if results.multi_hand_landmarks:
            for hand_idx, hand_landmarks in enumerate(results.multi_hand_landmarks):
                # 收集关键点坐标
                landmark_coords = []
                for landmark in hand_landmarks.landmark:
                    x = int(landmark.x * self.frame_width)
                    y = int(landmark.y * self.frame_height)
                    landmark_coords.append((x, y))
                
                # 计算边界框
                x_coords = [coord[0] for coord in landmark_coords]
                y_coords = [coord[1] for coord in landmark_coords]
                
                padding = self.config.box_padding
                xmin = max(0, min(x_coords) - padding)
                ymin = max(0, min(y_coords) - padding)
                xmax = min(self.frame_width, max(x_coords) + padding)
                ymax = min(self.frame_height, max(y_coords) + padding)
                
                # 创建检测结果对象
                result = HandDetectionResult(
                    hand_index=hand_idx,
                    xmin=xmin,
                    ymin=ymin,
                    xmax=xmax,
                    ymax=ymax,
                    confidence=0.0,  # MediaPipe基础版本不提供置信度
                    landmarks=landmark_coords
                )
                detection_results.append(result)
                
                # 可选：绘制关键点
                if self.config.show_landmarks:
                    self.mp_drawing.draw_landmarks(
                        frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS
                    )
                
                # 绘制边界框
                cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 0, 255), 2)
                
                # 绘制标签
                coord_text = f"Hand {hand_idx+1}"
                cv2.putText(
                    frame, coord_text, (xmin, ymin-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1
                )
        
        return detection_results, frame
    
    def set_callback(self, callback: Callable[[List[HandDetectionResult]], None]):
        """设置检测结果回调函数
        
        Args:
            callback: 回调函数，接收手部检测结果列表
        """
        self.callback = callback
    
    def start_detection(
        self, 
        camera_id: int = 0,
        show_window: bool = True,
        window_name: str = 'Hand Detection',
        callback: Optional[Callable[[List[HandDetectionResult]], None]] = None
    ):
        """启动手部检测
        
        Args:
            camera_id: 摄像头ID，默认为0
            show_window: 是否显示检测窗口
            window_name: 窗口名称
            callback: 检测结果回调函数
        """
        if callback:
            self.callback = callback
        
        # 打开摄像头
        self.cap = cv2.VideoCapture(camera_id)
        if not self.cap.isOpened():
            raise RuntimeError(f"无法打开摄像头 {camera_id}")
        
        # 获取画面尺寸
        self.frame_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.frame_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        self.is_running = True
        print(f"手部检测已启动，按 'q' 退出程序 (摄像头: {camera_id})")
        
        try:
            while self.is_running:
                success, frame = self.cap.read()
                if not success:
                    print("无法读取摄像头画面")
                    break
                
                # 处理画面
                results, frame = self._process_frame(frame)
                
                # 调用回调函数
                if self.callback and results:
                    self.callback(results)
                
                # 显示窗口
                if show_window:
                    cv2.imshow(window_name, frame)
                    if cv2.waitKey(5) & 0xFF == ord('q'):
                        break
        finally:
            self.stop_detection()
    
    def detect_single_frame(self, frame) -> Tuple[List[HandDetectionResult], any]:
        """检测单帧画面（不启动摄像头）
        
        Args:
            frame: 输入画面帧
            
        Returns:
            (检测结果列表, 处理后的画面)
        """
        if self.frame_width == 0:
            self.frame_width = frame.shape[1]
            self.frame_height = frame.shape[0]
        
        return self._process_frame(frame)
    
    def stop_detection(self):
        """停止检测并释放资源"""
        self.is_running = False
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()
        print("手部检测已停止")
    
    def close(self):
        """关闭检测器，释放所有资源"""
        self.stop_detection()
        if hasattr(self, 'hands'):
            self.hands.close()
        print("检测器已关闭")


# 便捷函数：快速启动检测
def quick_detect(
    callback: Callable[[List[HandDetectionResult]], None],
    camera_id: int = 0,
    max_num_hands: int = 2,
    min_confidence: float = 0.5
):
    """快速启动手部检测（简化版）
    
    Args:
        callback: 检测结果回调函数
        camera_id: 摄像头ID
        max_num_hands: 最多检测手数
        min_confidence: 最小置信度
        
    使用示例：
        def on_detect(results):
            for hand in results:
                print(f"手部{hand.hand_index}: ({hand.xmin},{hand.ymin})")
        
        quick_detect(on_detect)
    """
    config = HandDetectorConfig(
        max_num_hands=max_num_hands,
        min_detection_confidence=min_confidence
    )
    detector = HandDetector(config)
    detector.start_detection(camera_id=camera_id, callback=callback)


# 定义公开接口
__all__ = [
    'HandDetector',
    'HandDetectorConfig', 
    'HandDetectionResult',
    'quick_detect',
]

__version__ = '0.1.0'

