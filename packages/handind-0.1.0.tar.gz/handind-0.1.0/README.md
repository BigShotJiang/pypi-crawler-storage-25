# HandInd

基于 MediaPipe 和 OpenCV 的手部检测库

## 功能特性

- 实时检测手部位置
- 计算手部边界框
- 支持自定义回调处理检测结果
- 支持配置化参数

## 安装

```bash
pip install handind
```

## 快速开始

### 基本使用

```python
from handind import HandDetector, HandDetectionResult

def on_hand_detected(results):
    for hand in results:
        print(f"手部{hand.hand_index}位置: ({hand.xmin},{hand.ymin})")

detector = HandDetector()
detector.start_detection(callback=on_hand_detected)
```

### 使用快速函数

```python
from handind import quick_detect, HandDetectionResult

def on_detect(results):
    for hand in results:
        print(f"手部{hand.hand_index}: ({hand.xmin},{hand.ymin})")

quick_detect(on_detect)
```

### 自定义配置

```python
from handind import HandDetector, HandDetectorConfig

config = HandDetectorConfig(
    max_num_hands=1,
    min_detection_confidence=0.7,
    box_padding=30,
    show_landmarks=True
)
detector = HandDetector(config)
detector.start_detection()
```

## API 文档

### HandDetector

手部检测器主类

#### 初始化参数

- `config`: `HandDetectorConfig` 配置对象，可选

#### 方法

- `start_detection(camera_id=0, show_window=True, window_name='Hand Detection', callback=None)`: 启动检测
- `detect_single_frame(frame)`: 检测单帧画面
- `stop_detection()`: 停止检测
- `close()`: 关闭检测器
- `set_callback(callback)`: 设置回调函数

### HandDetectorConfig

配置类

- `max_num_hands`: 最大检测手数，默认 2
- `min_detection_confidence`: 最小检测置信度，默认 0.5
- `min_tracking_confidence`: 最小跟踪置信度，默认 0.1
- `box_padding`: 边界框内边距，默认 20
- `mirror_frame`: 是否镜像画面，默认 True
- `show_landmarks`: 是否显示关键点，默认 False

### HandDetectionResult

检测结果数据类

- `hand_index`: 手部索引
- `xmin`, `ymin`, `xmax`, `ymax`: 边界框坐标
- `confidence`: 置信度
- `landmarks`: 关键点坐标列表

## 依赖

- opencv-python >= 4.5.0
- mediapipe >= 0.10.0

## 许可证

MIT License
