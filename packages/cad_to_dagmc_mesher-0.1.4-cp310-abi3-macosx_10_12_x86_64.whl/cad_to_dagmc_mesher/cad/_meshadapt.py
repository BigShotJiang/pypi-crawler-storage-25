"""MeshAdapt surface meshing for faces with degenerate edges (sphere poles)."""

import math

from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.gp import gp_Pnt, gp_Vec

from cad_to_dagmc_mesher import fill_boundary_holes as _fill_holes_rust

from ._size_field import compute_size_field
from ._utils import _merge_vertices_with_remap


def _mesh_face_meshadapt(occ_face, tolerance=0.01, angular_tolerance=0.2,
                         target_edge_length=None, boundary_edges=None,
                         wire_boundary=None, holes=None,
                         canonical_boundary_3d=None,
                         gradient_edges=None):
    """Mesh a face using the MeshAdapt algorithm instead of BRepMesh/CDT.

    Works in UV parametric space with the metric tensor for
    curvature-adaptive sizing.  For degenerate edges (sphere poles),
    uses a multi-ring pole fan triangulation with surface projection
    between MeshAdapt iterations for improved accuracy.

    Parameters
    ----------
    boundary_edges : list of EdgeInput or None
        If provided, use these pre-computed UV boundary edges (from the
        shared edge parameter cache) instead of building a rectangular
        UV boundary. This ensures adjacent faces have identical boundary
        discretization, preventing non-manifold edges after vertex merge.
    wire_boundary : tuple of (boundary_uv, boundary_3d) or None
        If provided, use these boundary points (extracted from BRepMesh
        triangulation via ``_extract_brepmesh_boundary``) instead of
        building a rectangular UV boundary.  The 3D positions are the
        canonical BRepMesh vertex positions; after meshing, boundary
        vertices are snapped to these exact values so that the
        MeshAdapt mesh connects to adjacent BRepMesh faces.
    holes : list of list of EdgeInput or None
        Inner wire boundaries (holes) for faces with cut-outs. Each hole
        is a list of EdgeInput objects. The hole boundary is merged into
        the outer polygon using a bridge technique.
    canonical_boundary_3d : list of [x,y,z] or None
        If provided, canonical 3D positions for the boundary polygon
        vertices. After MeshAdapt evaluates UV→3D, boundary vertices
        are snapped to these positions for exact cross-face matching.

    Returns (vertices_3d, triangles) or None if MeshAdapt fails.
    """
    from cad_to_dagmc_mesher import meshadapt_face_init, meshadapt_face_step_py
    from OCP.BRepLProp import BRepLProp_SLProps
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib
    from OCP.ShapeAnalysis import ShapeAnalysis_Surface
    from OCP.BRep import BRep_Tool
    from OCP.Geom import Geom_Surface

    surface = BRepAdaptor_Surface(occ_face)
    u0 = surface.FirstUParameter()
    u1 = surface.LastUParameter()
    v0 = surface.FirstVParameter()
    v1 = surface.LastVParameter()

    # 1. Compute max_h from bounding box or target_edge_length
    bbox = Bnd_Box()
    BRepBndLib.Add_s(occ_face, bbox)
    xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
    diag = ((xmax-xmin)**2 + (ymax-ymin)**2 + (zmax-zmin)**2) ** 0.5

    if target_edge_length is not None:
        # Uniform sizing capped at target_edge_length, with strict
        # chordal tolerance for DAGMC tracking on curved surfaces.
        max_h = target_edge_length
        epp = 15
        # Chordal tolerance of 0.1mm ensures flat triangles stay within
        # 0.1mm of the actual surface — critical for DAGMC ray tracing.
        meshadapt_chordal = 0.1
    else:
        max_h = max(diag * 0.15, 0.1)
        # Scale from defaults: tighter tolerance → more elements
        _tol_scale = 0.03 / max(tolerance, 1e-10)
        _ang_scale = 0.4 / max(angular_tolerance, 1e-10)
        _scale = max(_tol_scale, _ang_scale)
        epp = max(8, round(15 * _scale))
        meshadapt_chordal = max(tolerance, diag * 0.0013 / _scale)
        # When gradient_edges is provided (even empty), this face is in a
        # solid with tet mesh. Use a coarser base sizing.
        if gradient_edges is not None:
            max_h = diag
            epp = max(8, round(epp * 0.3))

    # 2. Compute curvature-adaptive size field
    sf = compute_size_field(occ_face, nu=30, nv=30, elements_per_2pi=epp,
                            max_h=max_h, chordal_tolerance=meshadapt_chordal)

    # 2b. Apply distance-based gradient from fine (shared) edges.
    # gradient_edges: list of (uv_points, fine_h) — edges with fine mesh.
    # Near shared edges: target_h = fine_h (matching tet boundary).
    # Far from shared edges: target_h = coarse_h (large, few triangles).
    if gradient_edges and target_edge_length is None:
        nu_sf, nv_sf = sf["nu"], sf["nv"]
        u_range = sf["u_max"] - sf["u_min"]
        v_range = sf["v_max"] - sf["v_min"]
        # Collect all fine edge UV segments
        fine_segs = []  # list of (u0, v0, u1, v1)
        fine_h = float('inf')
        for edge_uvs, eh in gradient_edges:
            fine_h = min(fine_h, eh)  # use tet edge length as fine end
            for k in range(len(edge_uvs) - 1):
                fine_segs.append((edge_uvs[k][0], edge_uvs[k][1],
                                  edge_uvs[k+1][0], edge_uvs[k+1][1]))
        if fine_segs:
            # Coarse end: use face diagonal (few large triangles far from shared edges)
            coarse_h = diag
            # Override max_h so boundary subdivision + MeshAdapt use the gradient
            max_h = coarse_h
            _old_h = list(sf["target_h"])
            max_uv_dist = (u_range**2 + v_range**2) ** 0.5
            blend_dist = max_uv_dist * 0.8
            for iv in range(nv_sf):
                for iu in range(nu_sf):
                    idx = iv * nu_sf + iu
                    u = sf["u_min"] + iu * u_range / max(nu_sf - 1, 1)
                    v = sf["v_min"] + iv * v_range / max(nv_sf - 1, 1)
                    # Distance to nearest fine edge segment in UV space
                    min_d = float('inf')
                    for su0, sv0, su1, sv1 in fine_segs:
                        du, dv = su1 - su0, sv1 - sv0
                        seg_len_sq = du*du + dv*dv
                        if seg_len_sq < 1e-20:
                            d = ((u-su0)**2 + (v-sv0)**2) ** 0.5
                        else:
                            t = max(0, min(1, ((u-su0)*du + (v-sv0)*dv) / seg_len_sq))
                            px, py = su0 + t*du, sv0 + t*dv
                            d = ((u-px)**2 + (v-py)**2) ** 0.5
                        if d < min_d:
                            min_d = d
                    # Blend: fine_h near shared edge, coarse_h far away
                    alpha = min(min_d / blend_dist, 1.0)
                    blended_h = fine_h + alpha * (coarse_h - fine_h)
                    sf["target_h"][idx] = blended_h
            del _old_h

    # Fix degenerate metric tensor entries at poles
    nu_sf, nv_sf = sf["nu"], sf["nv"]
    for iv in range(nv_sf):
        for iu in range(nu_sf):
            idx = iv * nu_sf + iu
            E = sf["metric_e"][idx]
            G = sf["metric_g"][idx]
            if E < 1e-6 or G < 1e-6:
                for dv in range(1, nv_sf):
                    for direction in [1, -1]:
                        niv = iv + dv * direction
                        if 0 <= niv < nv_sf:
                            nidx = niv * nu_sf + iu
                            nE = sf["metric_e"][nidx]
                            nG = sf["metric_g"][nidx]
                            if nE >= 1e-6 and nG >= 1e-6:
                                sf["metric_e"][idx] = nE
                                sf["metric_f"][idx] = sf["metric_f"][nidx]
                                sf["metric_g"][idx] = nG
                                break
                    else:
                        continue
                    break

    # 3. Estimate boundary subdivision by measuring actual 3D arc lengths
    #    along each UV boundary edge. A single center-point metric estimate
    #    is wildly wrong for surfaces with non-uniform parameterization
    #    (e.g., BSpline coils where the UV domain spans the full coil length).
    valid_h = sorted(h for h in sf["target_h"] if h < max_h * 0.99)
    repr_h = valid_h[len(valid_h) // 2] if valid_h else max_h

    def _arc_len_uv(u_start, v_start, u_end, v_end, n_sample=20):
        """Measure 3D arc length along a UV line segment."""
        total = 0.0
        for k in range(n_sample):
            t0 = k / n_sample
            t1 = (k + 1) / n_sample
            p0 = surface.Value(u_start + t0*(u_end-u_start),
                               v_start + t0*(v_end-v_start))
            p1 = surface.Value(u_start + t1*(u_end-u_start),
                               v_start + t1*(v_end-v_start))
            total += ((p1.X()-p0.X())**2 + (p1.Y()-p0.Y())**2 +
                       (p1.Z()-p0.Z())**2) ** 0.5
        return total

    # Measure all 4 boundary edges and take the max for each direction
    vm = (v0 + v1) * 0.5
    um = (u0 + u1) * 0.5
    arc_u = max(_arc_len_uv(u0, v0, u1, v0),  # bottom edge
                _arc_len_uv(u0, v1, u1, v1),  # top edge
                _arc_len_uv(u0, vm, u1, vm))   # mid edge
    arc_v = max(_arc_len_uv(u0, v0, u0, v1),  # left edge
                _arc_len_uv(u1, v0, u1, v1),  # right edge
                _arc_len_uv(um, v0, um, v1))   # mid edge

    # Cap boundary density: too many boundary points (e.g. 735) create
    # pathological CDT triangulations that MeshAdapt can't fix.  A coarse
    # boundary (~30 pts per direction) works well — MeshAdapt's internal
    # edge-split operation refines to target_edge_length during adaptation.
    _max_bdy = max(30, int(math.ceil(min(arc_u, arc_v) / repr_h)))
    n_u = min(max(8, int(math.ceil(arc_u / repr_h))), _max_bdy)
    n_v = min(max(8, int(math.ceil(arc_v / repr_h))), _max_bdy)
    p, du_vec, dv_vec = gp_Pnt(), gp_Vec(), gp_Vec()
    surface.D1(um, vm, p, du_vec, dv_vec)
    sqrt_E = du_vec.Magnitude()
    sqrt_G = dv_vec.Magnitude()

    # 4. Detect degenerate edges (poles)
    _p_test = gp_Pnt()
    _du_test = gp_Vec()
    _dv_test = gp_Vec()

    surface.D1((u0+u1)/2, v0, _p_test, _du_test, _dv_test)
    bottom_degenerate = _du_test.Magnitude() < 1e-6
    surface.D1((u0+u1)/2, v1, _p_test, _du_test, _dv_test)
    top_degenerate = _du_test.Magnitude() < 1e-6

    _canonical_3d = None

    # Try to use boundary_edges from FaceInput (from edge_params_cache).
    # This ensures identical boundary discretization with adjacent faces.
    # For faces with degenerate edges (poles), we still use boundary_edges
    # for the non-degenerate edges, replacing degenerate edge UV points
    # with inset values to avoid zero-area triangles near the pole.
    if boundary_edges is not None and len(boundary_edges) > 0:
        # Compute pole inset parameters (same as rectangular fallback)
        v_range = v1 - v0
        pole_inset_frac = repr_h / (sqrt_G * v_range + 1e-30)
        pole_inset_frac = max(0.02, min(pole_inset_frac, 0.10))
        pole_inset = v_range * pole_inset_frac
        v0_eff = v0 + pole_inset if bottom_degenerate else v0
        v1_eff = v1 - pole_inset if top_degenerate else v1

        boundary_uv = []
        for edge in boundary_edges:
            pts = edge.uv_points
            if edge.reversed:
                pts = list(reversed(pts))
            # Check if this edge is degenerate (collapses to a single 3D point,
            # e.g., a pole edge). Closed curves like equator circles have the
            # same 3D start/end but the UV path traverses real distance — those
            # are NOT degenerate. Distinguish by checking a midpoint 3D position.
            _is_degen = False
            if (bottom_degenerate or top_degenerate) and len(pts) >= 3:
                _p0 = surface.Value(pts[0][0], pts[0][1])
                _p_mid = surface.Value(pts[len(pts) // 2][0],
                                        pts[len(pts) // 2][1])
                _p1 = surface.Value(pts[-1][0], pts[-1][1])
                _d_end = ((_p1.X()-_p0.X())**2 + (_p1.Y()-_p0.Y())**2 +
                          (_p1.Z()-_p0.Z())**2) ** 0.5
                _d_mid = ((_p_mid.X()-_p0.X())**2 + (_p_mid.Y()-_p0.Y())**2 +
                          (_p_mid.Z()-_p0.Z())**2) ** 0.5
                # Truly degenerate: start, midpoint, and end all coincide
                if _d_end < 1e-6 and _d_mid < 1e-6:
                    _is_degen = True
            if _is_degen:
                # Replace degenerate edge with inset points
                for pt in pts:
                    # Clamp v to the inset range
                    u_val = pt[0]
                    v_val = max(v0_eff, min(v1_eff, pt[1]))
                    inset_pt = [u_val, v_val]
                    if not boundary_uv or (abs(inset_pt[0] - boundary_uv[-1][0]) > 1e-12 or
                                            abs(inset_pt[1] - boundary_uv[-1][1]) > 1e-12):
                        boundary_uv.append(inset_pt)
            else:
                # Skip first point of subsequent edges to avoid duplicating corners
                start = 1 if boundary_uv else 0
                for pt in pts[start:]:
                    boundary_uv.append(list(pt))
        # Close: remove duplicate last point if it matches first
        if len(boundary_uv) >= 3:
            du = abs(boundary_uv[0][0] - boundary_uv[-1][0])
            dv = abs(boundary_uv[0][1] - boundary_uv[-1][1])
            if du < 1e-10 and dv < 1e-10:
                boundary_uv.pop()
        if len(boundary_uv) >= 3:
            _canonical_3d = True  # flag to skip rectangular fallback

        # Merge hole boundaries into the outer polygon using bridge edges,
        # then post-process to fix thin bridge triangles.
        _bridge_pairs = []  # list of (poly_idx, hole_start_idx) for post-processing
        if _canonical_3d and holes:
            for hole_edges in holes:
                if not hole_edges:
                    continue
                hole_uv = []
                for edge in hole_edges:
                    pts = edge.uv_points
                    if edge.reversed:
                        pts = list(reversed(pts))
                    start = 1 if hole_uv else 0
                    for pt in pts[start:]:
                        hole_uv.append(list(pt))
                if len(hole_uv) >= 3:
                    du = abs(hole_uv[0][0] - hole_uv[-1][0])
                    dv = abs(hole_uv[0][1] - hole_uv[-1][1])
                    if du < 1e-10 and dv < 1e-10:
                        hole_uv.pop()
                if len(hole_uv) < 3:
                    continue
                hole_uv.reverse()  # CW for hole
                # Find closest pair
                min_dist_sq = float('inf')
                poly_idx, hole_idx = 0, 0
                for pi, pp in enumerate(boundary_uv):
                    for hi, hp in enumerate(hole_uv):
                        d = (pp[0]-hp[0])**2 + (pp[1]-hp[1])**2
                        if d < min_dist_sq:
                            min_dist_sq = d
                            poly_idx = pi
                            hole_idx = hi
                reordered = hole_uv[hole_idx:] + hole_uv[:hole_idx]
                # Track bridge vertices for post-processing
                bridge_outer = poly_idx
                bridge_hole = len(boundary_uv[:poly_idx + 1])  # index of first hole vertex
                _bridge_pairs.append((bridge_outer, bridge_hole, len(reordered)))
                boundary_uv = (
                    boundary_uv[:poly_idx + 1] +
                    reordered +
                    [reordered[0]] +
                    boundary_uv[poly_idx:]
                )

    if _canonical_3d is None and False and wire_boundary is not None and not bottom_degenerate and not top_degenerate:
        # Build UV boundary from PCurves evaluated at BRepMesh's edge
        # parameter values.  BRepMesh stores both a polygon-on-triangulation
        # (3D node positions) and edge parameters.  By evaluating the face's
        # PCurve at those exact parameters we get UV points whose 3D
        # evaluation matches BRepMesh exactly.
        from OCP.BRep import BRep_Tool as _BRT
        from OCP.BRepTools import BRepTools as _BRT2
        from OCP.TopAbs import TopAbs_REVERSED as _REVERSED
        from OCP.TopLoc import TopLoc_Location as _TLoc

        _canonical_3d = wire_boundary[1]
        outer_wire = _BRT2.OuterWire_s(occ_face)
        if outer_wire is not None:
            from OCP.TopExp import TopExp_Explorer as _TE
            from OCP.TopAbs import TopAbs_EDGE as _EDGE
            _loc = _TLoc()
            _tri = _BRT.Triangulation_s(occ_face, _loc)

            from OCP.TopoDS import TopoDS as _TopoDS
            boundary_uv = []
            _exp = _TE(outer_wire, _EDGE)
            while _exp.More():
                edge = _TopoDS.Edge_s(_exp.Current())
                # Get PCurve (2D curve on this face)
                try:
                    pcurve = _BRT.CurveOnSurface_s(edge, occ_face, 0.0, 0.0)
                except Exception:
                    _exp.Next()
                    continue
                if pcurve is None:
                    _exp.Next()
                    continue
                is_rev = edge.Orientation() == _REVERSED

                # Get BRepMesh edge parameter values and evaluate PCurve
                _edge_uv = []
                _got_params = False
                if _tri is not None:
                    try:
                        poly = _BRT.PolygonOnTriangulation_s(edge, _tri, _loc)
                    except Exception:
                        poly = None
                    if poly is not None and poly.HasParameters():
                        params = poly.Parameters()
                        for k in range(1, params.Length() + 1):
                            t = params(k)
                            pt2d = pcurve.Value(t)
                            _edge_uv.append([pt2d.X(), pt2d.Y()])
                        _got_params = True

                if not _got_params:
                    # Fallback: uniform parameter sampling
                    p_first, p_last = _BRT.Range_s(edge)
                    if is_rev:
                        p_first, p_last = p_last, p_first
                    _n_pts = max(2, int(abs(p_last-p_first) * max(n_u, n_v) / max(abs(u1-u0), abs(v1-v0), 1e-30) + 0.5))
                    _n_pts = min(_n_pts, 200)
                    for k in range(_n_pts):
                        t = p_first + k * (p_last - p_first) / max(_n_pts - 1, 1)
                        pt2d = pcurve.Value(t)
                        _edge_uv.append([pt2d.X(), pt2d.Y()])

                if is_rev:
                    _edge_uv.reverse()
                start = 1 if boundary_uv else 0
                boundary_uv.extend(_edge_uv[start:])
                _exp.Next()
            # Close: remove duplicate last point
            if len(boundary_uv) >= 3:
                du = abs(boundary_uv[0][0] - boundary_uv[-1][0])
                dv = abs(boundary_uv[0][1] - boundary_uv[-1][1])
                if du < 1e-10 and dv < 1e-10:
                    boundary_uv.pop()
            if len(boundary_uv) < 3:
                _canonical_3d = None  # fall back to rectangular
    if _canonical_3d is None:
        # Rectangular UV boundary (handles degenerate edges / poles)
        v_range = v1 - v0
        pole_inset_frac = repr_h / (sqrt_G * v_range + 1e-30)
        pole_inset_frac = max(0.02, min(pole_inset_frac, 0.10))
        pole_inset = v_range * pole_inset_frac
        v0_eff = v0 + pole_inset if bottom_degenerate else v0
        v1_eff = v1 - pole_inset if top_degenerate else v1

        n_v_seam = n_v * 2

        def _arc_subdiv(p0_u, p0_v, p1_u, p1_v, n_seg):
            """Subdivide a UV line proportional to 3D arc length."""
            if n_seg < 2:
                return [p0_u if abs(p1_u - p0_u) > abs(p1_v - p0_v)
                        else p0_v]  # won't be used
            # Sample many points and compute cumulative 3D arc length
            _ns = max(n_seg * 4, 100)
            _cum = [0.0]
            for k in range(1, _ns + 1):
                t0 = (k - 1) / _ns
                t1 = k / _ns
                _p0 = surface.Value(p0_u + t0*(p1_u-p0_u), p0_v + t0*(p1_v-p0_v))
                _p1 = surface.Value(p0_u + t1*(p1_u-p0_u), p0_v + t1*(p1_v-p0_v))
                d = ((_p1.X()-_p0.X())**2 + (_p1.Y()-_p0.Y())**2 +
                     (_p1.Z()-_p0.Z())**2) ** 0.5
                _cum.append(_cum[-1] + d)
            _total = _cum[-1]
            if _total < 1e-12:
                # Degenerate: fall back to uniform
                varying = abs(p1_u - p0_u) > abs(p1_v - p0_v)
                if varying:
                    return [p0_u + i * (p1_u - p0_u) / n_seg for i in range(n_seg + 1)]
                else:
                    return [p0_v + i * (p1_v - p0_v) / n_seg for i in range(n_seg + 1)]
            # Invert cumulative arc length → UV parameter
            varying = abs(p1_u - p0_u) > abs(p1_v - p0_v)
            result = []
            for i in range(n_seg + 1):
                target = i * _total / n_seg
                # Binary search for the sample index
                lo, hi = 0, _ns
                while lo < hi:
                    mid = (lo + hi) // 2
                    if _cum[mid] < target:
                        lo = mid + 1
                    else:
                        hi = mid
                # Interpolate
                if lo == 0:
                    t = 0.0
                else:
                    seg_len = _cum[lo] - _cum[lo-1]
                    frac = (target - _cum[lo-1]) / seg_len if seg_len > 1e-15 else 0.0
                    t = ((lo - 1) + frac) / _ns
                if varying:
                    result.append(p0_u + t * (p1_u - p0_u))
                else:
                    result.append(p0_v + t * (p1_v - p0_v))
            return result

        u_pts = [u0 + i * (u1 - u0) / n_u for i in range(n_u + 1)]
        v_pts_seam = [v0_eff + i * (v1_eff - v0_eff) / n_v_seam
                      for i in range(n_v_seam + 1)]

        boundary_uv = [[u, v0_eff] for u in u_pts]
        for v in v_pts_seam[1:]:
            boundary_uv.append([u1, v])
        for u in reversed(u_pts[:-1]):
            boundary_uv.append([u, v1_eff])
        for v in reversed(v_pts_seam[1:-1]):
            boundary_uv.append([u0, v])

    if len(boundary_uv) < 3:
        return None

    # Note: per-face boundary pre-subdivision removed — the Rust MeshAdapt
    # no longer splits boundary edges, so pre-subdivision is unnecessary.
    # All boundary subdivision is done at the assembly level where
    # harmonization ensures matching discretization between faces.

    # 6. Call MeshAdapt — full loop runs in Rust (much lower memory than
    # the incremental Python API which rebuilds BDSMesh each iteration).
    from cad_to_dagmc_mesher import meshadapt_face as _meshadapt_face

    geom_surface = BRep_Tool.Surface_s(occ_face)
    sa_surface = ShapeAnalysis_Surface(geom_surface)

    try:
        verts_uv, tris = _meshadapt_face(boundary_uv, sf, 20)
    except Exception:
        return None

    if not verts_uv or not tris:
        return None

    verts_uv = [list(v) for v in verts_uv]
    tris = [list(t) for t in tris]

    # 7. Add multi-ring pole fan triangles (Rust)
    from cad_to_dagmc_mesher import add_multi_ring_pole_fan as _pole_fan_rust
    eps_bdy = abs(v1 - v0) * 1e-6
    if bottom_degenerate:
        bdy_row = sorted([(uv[0], i) for i, uv in enumerate(verts_uv)
                          if abs(uv[1] - v0_eff) < eps_bdy])
        verts_uv, tris = _pole_fan_rust(
            verts_uv, tris, bdy_row, u0, u1, v0, v0_eff, False)
        verts_uv = [list(v) for v in verts_uv]
        tris = [list(t) for t in tris]

    if top_degenerate:
        bdy_row = sorted([(uv[0], i) for i, uv in enumerate(verts_uv)
                          if abs(uv[1] - v1_eff) < eps_bdy])
        verts_uv, tris = _pole_fan_rust(
            verts_uv, tris, bdy_row, u0, u1, v1, v1_eff, True)
        verts_uv = [list(v) for v in verts_uv]
        tris = [list(t) for t in tris]

    # 7b. Bridge triangles: the per-face 3D merge (step 9) will merge
    # duplicate bridge vertices, turning bridge edges into interior edges.
    # The _cleanup_non_manifold call in the assembly then fixes remaining
    # quality issues.

    # 8. Evaluate UV vertices to 3D with chordal offset.
    # Flat triangles inscribe inside curved surfaces, causing volume deficit.
    # Offset each vertex outward along the surface normal by half the local
    # chordal error to compensate.
    from OCP.BRepLProp import BRepLProp_SLProps

    # Compute median curvature for adaptive offset factor
    _kappas = []
    for uv in verts_uv:
        props = BRepLProp_SLProps(surface, uv[0], uv[1], 2, 1e-7)
        if props.IsCurvatureDefined():
            k = max(abs(props.MaxCurvature()), abs(props.MinCurvature()))
            if k > 1e-12:
                _kappas.append(k)
    _kappas.sort()
    _median_kappa = _kappas[len(_kappas) // 2] if _kappas else 0.0

    verts_3d_raw = []
    vert_normals = []
    vert_offsets = []
    for uv in verts_uv:
        u_val, v_val = uv[0], uv[1]
        pt = surface.Value(u_val, v_val)
        x, y, z = pt.X(), pt.Y(), pt.Z()
        verts_3d_raw.append([x, y, z])

        props = BRepLProp_SLProps(surface, u_val, v_val, 2, 1e-7)
        if props.IsCurvatureDefined() and props.IsNormalDefined():
            kappa = max(abs(props.MaxCurvature()), abs(props.MinCurvature()))
            normal = props.Normal()
            vert_normals.append((normal.X(), normal.Y(), normal.Z()))

            if kappa > 1e-12:
                nu_sf, nv_sf = sf["nu"], sf["nv"]
                u_range_sf = sf["u_max"] - sf["u_min"]
                v_range_sf = sf["v_max"] - sf["v_min"]
                fu = max(0.0, min(1.0, (u_val - sf["u_min"]) / u_range_sf)) if u_range_sf > 0 else 0.5
                fv = max(0.0, min(1.0, (v_val - sf["v_min"]) / v_range_sf)) if v_range_sf > 0 else 0.5
                idx = min(int(fv * (nv_sf-1)), nv_sf-1) * nu_sf + min(int(fu * (nu_sf-1)), nu_sf-1)
                h_local = sf["target_h"][idx]

                chordal_err = h_local * h_local * kappa / 8.0
                # Adaptive factor: 0.75 for uniform curvature (sphere),
                # smoothly reducing for vertices where curvature exceeds
                # the median (ellipsoid poles). This prevents overcorrection
                # on non-uniform surfaces.
                _kappa_ratio = kappa / _median_kappa if _median_kappa > 1e-12 else 1.0
                _factor = 0.75 / max(1.0, _kappa_ratio ** 0.5)
                offset = min(chordal_err * _factor, meshadapt_chordal)
                vert_offsets.append(offset)
            else:
                vert_offsets.append(0.0)
        else:
            vert_normals.append((0.0, 0.0, 0.0))
            vert_offsets.append(0.0)
    # Per-vertex measurement overcorrects due to circular dependency.

    _canonical_vi = {}  # unused — wire boundary disabled

    # 9. Chord error refinement: split edges where the flat triangle
    # deviates from the curved surface by more than the tolerance.
    # This adds tris only where curvature demands it, keeping flat
    # regions at target_edge_length.
    #
    # Edge adjacency + triangle splitting runs in Rust; only surface
    # evaluation (OCP) stays in Python.
    if target_edge_length is not None:
        from cad_to_dagmc_mesher import chord_refine_edges, chord_refine_split

        _chord_tol = min(tolerance, target_edge_length * 0.01)
        _n_bdy = len(boundary_uv)  # boundary vertex count for edge filtering
        for _refine_pass in range(8):
            # Rust: find unique edge midpoint UVs, skipping boundary edges
            tris_arr = [[t[0], t[1], t[2]] for t in tris]
            edge_keys, mid_uvs = chord_refine_edges(verts_uv, tris_arr, _n_bdy)

            if not edge_keys:
                break

            # Python: evaluate surface at midpoints (OCP)
            mid_xyz = []
            for uv in mid_uvs:
                pt = surface.Value(uv[0], uv[1])
                mid_xyz.append([pt.X(), pt.Y(), pt.Z()])

            # Rust: compute distances, split triangles
            verts_3d_arr = [[v[0], v[1], v[2]] for v in verts_3d_raw]
            new_uv, new_3d, new_tris = chord_refine_split(
                verts_uv, verts_3d_arr, tris_arr, edge_keys, mid_xyz, _chord_tol)

            if len(new_tris) == len(tris):
                break  # no splits happened

            verts_uv = [list(v) for v in new_uv]
            verts_3d_raw = [list(v) for v in new_3d]
            tris = [list(t) for t in new_tris]

    # Chordal offsets disabled — they move boundary vertices along surface
    # normals, breaking watertight stitching between adjacent faces (each
    # face applies a different offset at the shared edge).  The offset is
    # a minor volume correction (<0.1 mm) that isn't worth the watertightness
    # cost.  Can be re-enabled for interior vertices only once chord
    # refinement properly extends the offset/normal arrays.

    # 9. Merge coincident 3D vertices (seam + pole stitching)
    merged_verts, merge_map = _merge_vertices_with_remap(verts_3d_raw)

    # Remap + deduplicate triangles
    seen = set()
    merged_tris = []
    for t in tris:
        a, b, c = merge_map[t[0]], merge_map[t[1]], merge_map[t[2]]
        if a == b or b == c or a == c:
            continue
        key = tuple(sorted([a, b, c]))
        if key not in seen:
            seen.add(key)
            merged_tris.append([a, b, c])

    if not merged_tris:
        return None

    # 10. Skip fill_boundary_holes — it closes the face's open boundary
    # with fan triangles, which creates non-manifold edges when the
    # global merge stitches adjacent face boundaries.

    return merged_verts, merged_tris


    # _add_multi_ring_pole_fan moved to Rust (cad_to_dagmc_mesher.add_multi_ring_pole_fan)
