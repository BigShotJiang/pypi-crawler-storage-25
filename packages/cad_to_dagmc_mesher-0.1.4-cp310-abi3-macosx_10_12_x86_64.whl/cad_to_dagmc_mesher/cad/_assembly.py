"""Multi-volume (imprinted assembly) meshing pipeline."""

from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE, TopAbs_REVERSED
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS

from cad_to_dagmc_mesher import mesh_faces_parallel

from ._classify import (
    _count_degenerate_edges,
    _face_has_seam_edges,
    _face_is_effectively_doubly_periodic,
    _face_normal_outward,
)
from ._evaluate import _cleanup_non_manifold, _evaluate_face_3d, _stitch_periodic_uv_mesh
from ._extract import _extract_brep_mesh_face, _extract_face
from ._meshadapt import _mesh_face_meshadapt
from ._optimize import _collapse_periodic_mesh_3d, _optimize_3d_mesh
from ._utils import (
    _fix_normals_bfs,
    _log_memory,
    _merge_vertices_between_faces,
    _merge_vertices_with_remap,
    _remap_tris,
)


def _dedup_tris(tris: list[list[int]]) -> list[list[int]]:
    """Remove duplicate triangles (same sorted vertex triple)."""
    seen = set()
    result = []
    for t in tris:
        key = tuple(sorted(t))
        if key not in seen:
            seen.add(key)
            result.append(t)
    return result


def _imprint_assembly(assembly):
    """Imprint a CadQuery assembly using BOPAlgo_MakeConnected."""
    import cadquery as cq
    return cq.occ_impl.assembly.imprint(assembly)


def _get_solids(occ_shape):
    """Extract all solids from an OCC shape."""
    from OCP.TopAbs import TopAbs_SOLID
    solids = []
    exp = TopExp_Explorer(occ_shape, TopAbs_SOLID)
    while exp.More():
        solids.append(TopoDS.Solid_s(exp.Current()))
        exp.Next()
    return solids


def extract_assembly(
    assembly,
    tolerance: float = 0.01,
    angular_tolerance: float = 0.2,
    imprint: bool = True,
) -> dict:
    """Imprint a CadQuery assembly and extract face inputs with shared-face tracking.

    Parameters
    ----------
    assembly : cadquery.Assembly
        The CadQuery assembly to imprint and extract.
    tolerance : float
        Linear deflection tolerance for edge discretization.
    angular_tolerance : float
        Angular deflection tolerance for edge discretization.

    Returns
    -------
    dict
        Keys: ``face_inputs``, ``occ_faces``, ``solid_face_ids``,
        ``face_solid_ids``, ``face_reversed``, ``solid_names``,
        ``imprinted_compound``, ``_occ_faces_map``, ``_global_edge_map``.
    """
    if imprint:
        imprinted_compound, solids_with_ids = _imprint_assembly(assembly)
    else:
        # Skip imprinting — build an OCC compound from the assembly's solids
        from OCP.BRep import BRep_Builder
        from OCP.TopoDS import TopoDS_Compound
        from OCP.TopAbs import TopAbs_SOLID
        builder = BRep_Builder()
        compound = TopoDS_Compound()
        builder.MakeCompound(compound)
        solids_with_ids = {}
        for name, child in assembly.objects.items():
            obj = child.obj if hasattr(child, "obj") else child
            if obj is None:
                continue
            occ_obj = getattr(obj, "wrapped", obj)
            solid_exp = TopExp_Explorer(occ_obj, TopAbs_SOLID)
            while solid_exp.More():
                solid = TopoDS.Solid_s(solid_exp.Current())
                builder.Add(compound, solid)
                solids_with_ids[solid] = [name]
                solid_exp.Next()
        imprinted_compound = compound
    occ_compound = getattr(imprinted_compound, "wrapped", imprinted_compound)

    solids = _get_solids(occ_compound)
    solid_names = {}
    for i, solid in enumerate(solids):
        solid_id = i + 1
        for shape, names in solids_with_ids.items():
            occ_s = getattr(shape, "wrapped", shape)
            if occ_s.IsEqual(solid):
                solid_names[solid_id] = names[0] if names else f"solid_{solid_id}"
                break
        else:
            solid_names[solid_id] = f"solid_{solid_id}"

    seen_faces = {}
    face_inputs = []
    occ_faces_map = {}
    solid_face_ids = {}
    face_solid_ids = {}
    face_reversed = {}
    next_face_id = 1
    # Build global edge index so shared edges get identical discretization
    from OCP.TopTools import TopTools_IndexedMapOfShape
    from OCP.TopExp import TopExp
    global_edge_map = TopTools_IndexedMapOfShape()
    TopExp.MapShapes_s(occ_compound, TopAbs_EDGE, global_edge_map)
    edge_params_cache = {"_edge_map": global_edge_map}

    for i, solid in enumerate(solids):
        solid_id = i + 1
        solid_face_ids[solid_id] = []

        face_exp = TopExp_Explorer(solid, TopAbs_FACE)
        while face_exp.More():
            occ_face = TopoDS.Face_s(face_exp.Current())
            face_hash = hash(occ_face)
            reversed = occ_face.Orientation() == TopAbs_REVERSED

            if face_hash in seen_faces:
                fid = seen_faces[face_hash]
            else:
                fid = next_face_id
                next_face_id += 1
                seen_faces[face_hash] = fid

                result = _extract_face(occ_face, fid, tolerance, angular_tolerance,
                                       edge_params_cache=edge_params_cache)
                if result is not None:
                    fi, occ_edge_list = result
                    if fi is not None:
                        face_inputs.append(fi)
                        occ_faces_map[fid] = occ_face
                        # Stash OCC edges for shared-edge harmonization
                        occ_faces_map[("occ_edges", fid)] = occ_edge_list

            solid_face_ids[solid_id].append(fid)
            face_reversed[(solid_id, fid)] = reversed

            if fid not in face_solid_ids:
                face_solid_ids[fid] = []
            if solid_id not in face_solid_ids[fid]:
                face_solid_ids[fid].append(solid_id)

            face_exp.Next()

    occ_faces = [occ_faces_map[fi.face_id] for fi in face_inputs]

    return {
        "face_inputs": face_inputs,
        "occ_faces": occ_faces,
        "solid_face_ids": solid_face_ids,
        "face_solid_ids": face_solid_ids,
        "face_reversed": face_reversed,
        "solid_names": solid_names,
        "imprinted_compound": occ_compound,
        "_occ_faces_map": occ_faces_map,
        "_global_edge_map": global_edge_map,
    }


def _point_on_edge_3d(p, a, b, tol_frac=0.3):
    """Test if point p lies on segment a-b within tolerance.

    tol_frac: max perpendicular distance as fraction of edge length.
    Returns True if p is between a and b and close to the line.
    """
    ab = [b[0]-a[0], b[1]-a[1], b[2]-a[2]]
    ap = [p[0]-a[0], p[1]-a[1], p[2]-a[2]]
    ab_len_sq = ab[0]**2 + ab[1]**2 + ab[2]**2
    if ab_len_sq < 1e-20:
        return False
    # Project p onto line a-b
    t = (ap[0]*ab[0] + ap[1]*ab[1] + ap[2]*ab[2]) / ab_len_sq
    if t < 0.05 or t > 0.95:  # must be between endpoints (not at corners)
        return False
    # Perpendicular distance
    proj = [a[0] + t*ab[0], a[1] + t*ab[1], a[2] + t*ab[2]]
    d_sq = (p[0]-proj[0])**2 + (p[1]-proj[1])**2 + (p[2]-proj[2])**2
    return d_sq < tol_frac**2 * ab_len_sq


def _point_in_tri_3d(p, a, b, c, max_plane_dist=5.0):
    """Test if point p is inside triangle (a,b,c) in 3D.

    Uses barycentric coords + plane distance check.
    max_plane_dist: maximum allowed distance from the triangle plane.
    """
    # Check plane distance first
    ab = [b[0]-a[0], b[1]-a[1], b[2]-a[2]]
    ac = [c[0]-a[0], c[1]-a[1], c[2]-a[2]]
    n = [ab[1]*ac[2]-ab[2]*ac[1], ab[2]*ac[0]-ab[0]*ac[2], ab[0]*ac[1]-ab[1]*ac[0]]
    n_len = (n[0]**2 + n[1]**2 + n[2]**2)**0.5
    if n_len < 1e-30:
        return False
    ap = [p[0]-a[0], p[1]-a[1], p[2]-a[2]]
    plane_dist = abs(n[0]*ap[0] + n[1]*ap[1] + n[2]*ap[2]) / n_len
    if plane_dist > max_plane_dist:
        return False

    # Barycentric coordinates
    v0 = ac
    v1 = ab
    v2 = ap
    d00 = v0[0]*v0[0] + v0[1]*v0[1] + v0[2]*v0[2]
    d01 = v0[0]*v1[0] + v0[1]*v1[1] + v0[2]*v1[2]
    d02 = v0[0]*v2[0] + v0[1]*v2[1] + v0[2]*v2[2]
    d11 = v1[0]*v1[0] + v1[1]*v1[1] + v1[2]*v1[2]
    d12 = v1[0]*v2[0] + v1[1]*v2[1] + v1[2]*v2[2]
    denom = d00 * d11 - d01 * d01
    if abs(denom) < 1e-30:
        return False
    inv = 1.0 / denom
    u = (d11 * d02 - d01 * d12) * inv
    v = (d00 * d12 - d01 * d02) * inv
    # Strict: point must be inside (not on edge), with small tolerance
    eps = 0.001
    return u > eps and v > eps and (u + v) < 1.0 - eps


def _snap_meshadapt_boundary(verts, occ_face, global_edge_map, edge_cache, tolerance):
    """Snap MeshAdapt boundary vertices to canonical shared-edge positions.

    For each boundary vertex (on an edge shared by only 1 triangle), find the
    nearest OCC edge, project the vertex onto it, and either store the position
    as canonical (first face to see this edge) or snap to the nearest canonical
    point (subsequent faces).

    This prevents non-manifold edges at face boundaries after vertex merging.
    """
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_EDGE
    from OCP.BRepAdaptor import BRepAdaptor_Curve
    from OCP.ShapeAnalysis import ShapeAnalysis_Curve
    from OCP.gp import gp_Pnt

    if global_edge_map is None or not verts:
        return

    # 1. Collect OCC edges of this face with their global IDs
    face_edges = []
    exp = TopExp_Explorer(occ_face, TopAbs_EDGE)
    while exp.More():
        occ_edge = exp.Current()
        gid = global_edge_map.FindIndex(occ_edge)
        if gid > 0:
            face_edges.append((gid, occ_edge))
        exp.Next()

    if not face_edges:
        return

    # 2. For each vertex, find if it's near an OCC edge (boundary vertex)
    sac = ShapeAnalysis_Curve()
    tol_sq = (tolerance * 3.0) ** 2  # generous matching tolerance

    for vi in range(len(verts)):
        v = verts[vi]
        gp = gp_Pnt(v[0], v[1], v[2])

        best_gid = None
        best_dist_sq = tol_sq
        best_proj = None

        for gid, occ_edge in face_edges:
            try:
                curve = BRepAdaptor_Curve(occ_edge)
            except Exception:
                continue
            proj_pt = gp_Pnt()
            param = sac.Project(curve, gp, tolerance * 10, proj_pt)
            if param < -1e30:
                continue
            dx = proj_pt.X() - v[0]
            dy = proj_pt.Y() - v[1]
            dz = proj_pt.Z() - v[2]
            d_sq = dx*dx + dy*dy + dz*dz
            if d_sq < best_dist_sq:
                best_dist_sq = d_sq
                best_gid = gid
                best_proj = [proj_pt.X(), proj_pt.Y(), proj_pt.Z()]

        if best_gid is None:
            continue  # interior vertex, skip

        # 3. Check if this edge has canonical points already
        if best_gid in edge_cache:
            # Snap to nearest canonical point
            canonical = edge_cache[best_gid]
            snap_dist_sq = float('inf')
            snap_pt = None
            for cp in canonical:
                dx = v[0] - cp[0]
                dy = v[1] - cp[1]
                dz = v[2] - cp[2]
                d = dx*dx + dy*dy + dz*dz
                if d < snap_dist_sq:
                    snap_dist_sq = d
                    snap_pt = cp
            if snap_pt is not None and snap_dist_sq < tol_sq:
                verts[vi] = list(snap_pt)
        else:
            # First face to see this edge — store projected point as canonical
            edge_cache.setdefault(best_gid, []).append(
                best_proj if best_proj else list(v)
            )


def _extract_brepmesh_boundary(occ_face):
    """Extract outer wire boundary from a face's BRepMesh triangulation.

    After ``BRepMesh_IncrementalMesh`` has been run on the compound, each
    face has a ``Poly_Triangulation`` with UV nodes.  Walk the face's
    outer wire and collect the polygon-on-triangulation for each edge to
    build a boundary polygon whose 3D positions are **identical** to those
    in the BRepMesh triangulation.

    Returns ``(boundary_uv, boundary_3d)`` or ``None`` if unavailable.
    """
    from OCP.BRep import BRep_Tool
    from OCP.BRepTools import BRepTools as _BRepTools
    from OCP.TopLoc import TopLoc_Location

    loc = TopLoc_Location()
    tri = BRep_Tool.Triangulation_s(occ_face, loc)
    if tri is None or not tri.HasUVNodes():
        return None

    transform = loc.Transformation() if not loc.IsIdentity() else None

    outer_wire = _BRepTools.OuterWire_s(occ_face)
    if outer_wire is None:
        return None

    boundary_uv = []
    boundary_3d = []

    exp = TopExp_Explorer(outer_wire, TopAbs_EDGE)
    while exp.More():
        edge = TopoDS.Edge_s(exp.Current())

        poly = BRep_Tool.PolygonOnTriangulation_s(edge, tri, loc)
        if poly is None:
            exp.Next()
            continue

        nodes = poly.Nodes()
        is_reversed = edge.Orientation() == TopAbs_REVERSED

        edge_uv = []
        edge_3d = []
        for i in range(1, nodes.Length() + 1):
            node_idx = nodes(i)
            uv = tri.UVNode(node_idx)
            edge_uv.append([uv.X(), uv.Y()])
            p3d = tri.Node(node_idx)
            if transform is not None:
                p3d = p3d.Transformed(transform)
            edge_3d.append([p3d.X(), p3d.Y(), p3d.Z()])

        if is_reversed:
            edge_uv.reverse()
            edge_3d.reverse()

        # Skip first point of subsequent edges (shared with previous edge)
        start = 1 if boundary_uv else 0
        boundary_uv.extend(edge_uv[start:])
        boundary_3d.extend(edge_3d[start:])

        exp.Next()

    # Close loop: remove last point if it duplicates the first
    if len(boundary_uv) >= 3:
        d = sum((boundary_3d[0][k] - boundary_3d[-1][k]) ** 2 for k in range(3))
        if d < 1e-12:
            boundary_uv.pop()
            boundary_3d.pop()

    if len(boundary_uv) < 3:
        return None

    return boundary_uv, boundary_3d


def _harmonize_shared_edges(face_inputs, occ_faces, occ_faces_map=None):
    """Ensure shared OCC edges have identical discretization across faces.

    Uses OCC `IsSame()` to find shared edges. Picks the densest
    discretization and projects 3D points to the sparser face's UV.
    """
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.BRep import BRep_Tool
    from OCP.ShapeAnalysis import ShapeAnalysis_Surface
    from OCP.gp import gp_Pnt

    if occ_faces_map is None:
        return

    # Collect all (face_idx, wire_type, edge_idx, occ_edge, n_points) tuples.
    # wire_type: "boundary" or ("hole", hole_idx)
    all_edges = []
    for fi_idx, fi in enumerate(face_inputs):
        fid = fi.face_id
        occ_edge_list = occ_faces_map.get(("occ_edges", fid), [])
        edges = fi.boundary_edges
        for ei_idx in range(min(len(edges), len(occ_edge_list))):
            all_edges.append((fi_idx, "boundary", ei_idx,
                              occ_edge_list[ei_idx], len(edges[ei_idx].uv_points)))
        # Also collect hole edges
        if fi.holes:
            occ_bdy_count = len(edges) if edges else 0
            for hi, hole in enumerate(fi.holes):
                for hei, _he in enumerate(hole):
                    occ_ei = occ_bdy_count + sum(len(fi.holes[k]) for k in range(hi)) + hei
                    if occ_ei < len(occ_edge_list):
                        all_edges.append((fi_idx, ("hole", hi), hei,
                                          occ_edge_list[occ_ei],
                                          len(_he.uv_points)))

    def _get_edge_obj(fi_idx, wire_type, ei_idx):
        """Get the EdgeInput object for a given face/wire/edge index."""
        fi = face_inputs[fi_idx]
        if wire_type == "boundary":
            return fi.boundary_edges[ei_idx]
        else:
            _, hi = wire_type
            return fi.holes[hi][ei_idx]

    def _set_edge_uv(fi_idx, wire_type, ei_idx, new_uv):
        """Set UV points on the EdgeInput object."""
        fi = face_inputs[fi_idx]
        if wire_type == "boundary":
            edges = fi.boundary_edges
            edges[ei_idx].uv_points = new_uv
            fi.boundary_edges = edges
        else:
            _, hi = wire_type
            holes = fi.holes
            holes[hi][ei_idx].uv_points = new_uv
            fi.holes = holes

    # Group by shared identity (IsSame)
    groups = []
    used = set()
    for i, (fi_i, wt_i, ei_i, occ_i, n_i) in enumerate(all_edges):
        if i in used:
            continue
        group = [(fi_i, wt_i, ei_i, n_i)]
        used.add(i)
        for j, (fi_j, wt_j, ei_j, occ_j, n_j) in enumerate(all_edges):
            if j in used:
                continue
            if occ_i.IsSame(occ_j):
                group.append((fi_j, wt_j, ei_j, n_j))
                used.add(j)
        if len(group) > 1:
            groups.append(group)

    # For each group with mismatched point counts, harmonize
    for group in groups:
        counts = [g[3] for g in group]

        # Pick the densest edge as the canonical reference
        dense_idx = max(range(len(group)), key=lambda k: group[k][3])
        dense_fi, dense_wt, dense_ei, _ = group[dense_idx]

        # Get canonical 3D points from the dense edge
        dense_of = occ_faces[dense_fi]
        dense_surf = BRepAdaptor_Surface(dense_of)
        dense_edge_obj = _get_edge_obj(dense_fi, dense_wt, dense_ei)
        pts_3d = []
        for uv in dense_edge_obj.uv_points:
            p = dense_surf.Value(uv[0], uv[1])
            pts_3d.append((p.X(), p.Y(), p.Z()))

        # Project to each other face in the group (only when count differs)
        for k, (sparse_fi, sparse_wt, sparse_ei, sparse_n) in enumerate(group):
            if k == dense_idx:
                continue
            if sparse_n == len(pts_3d):
                continue  # already matching count
            sparse_of = occ_faces[sparse_fi]
            geom_surf = BRep_Tool.Surface_s(sparse_of)
            sa_surf = ShapeAnalysis_Surface(geom_surf)
            sp_ad = BRepAdaptor_Surface(sparse_of)
            _u_per = sp_ad.IsUPeriodic()
            _v_per = sp_ad.IsVPeriodic()
            _up = sp_ad.UPeriod() if _u_per else 0.0
            _vp = sp_ad.VPeriod() if _v_per else 0.0
            new_uv = []
            for p3d in pts_3d:
                uv = sa_surf.ValueOfUV(gp_Pnt(*p3d), 1e-10)
                new_uv.append([uv.X(), uv.Y()])
            # Unwrap periodic UV to keep the path continuous
            if (_u_per or _v_per) and len(new_uv) > 1:
                for j in range(1, len(new_uv)):
                    if _u_per:
                        while new_uv[j][0] - new_uv[j-1][0] > _up / 2:
                            new_uv[j][0] -= _up
                        while new_uv[j-1][0] - new_uv[j][0] > _up / 2:
                            new_uv[j][0] += _up
                    if _v_per:
                        while new_uv[j][1] - new_uv[j-1][1] > _vp / 2:
                            new_uv[j][1] -= _vp
                        while new_uv[j-1][1] - new_uv[j][1] > _vp / 2:
                            new_uv[j][1] += _vp
            _set_edge_uv(sparse_fi, sparse_wt, sparse_ei, new_uv)


def _subdivide_long_edges(face_input, occ_face, target_edge_length):
    """Subdivide boundary edges of a FaceInput so no edge exceeds target_edge_length.

    Evaluates the OCC surface at intermediate UV parameters to place new
    points on the actual curved surface. Modifies face_input in place.
    """
    from OCP.BRepAdaptor import BRepAdaptor_Surface

    surface = BRepAdaptor_Surface(occ_face)

    def _subdivide_edge(edge):
        pts = edge.uv_points
        if len(pts) < 2:
            return
        new_pts = [pts[0]]
        for i in range(len(pts) - 1):
            uv_a, uv_b = pts[i], pts[i + 1]
            # Compute 3D distance
            p_a = surface.Value(uv_a[0], uv_a[1])
            p_b = surface.Value(uv_b[0], uv_b[1])
            d = ((p_b.X() - p_a.X()) ** 2 + (p_b.Y() - p_a.Y()) ** 2
                 + (p_b.Z() - p_a.Z()) ** 2) ** 0.5
            if d <= target_edge_length:
                new_pts.append(pts[i + 1])
            else:
                # Subdivide uniformly in UV
                n_seg = max(2, int(d / target_edge_length + 0.5))
                for k in range(1, n_seg):
                    t = k / n_seg
                    u = uv_a[0] + t * (uv_b[0] - uv_a[0])
                    v = uv_a[1] + t * (uv_b[1] - uv_a[1])
                    new_pts.append([u, v])
                new_pts.append(pts[i + 1])
        edge.uv_points = new_pts

    # boundary_edges getter returns a copy, so modify + set back
    edges = face_input.boundary_edges
    for edge in edges:
        _subdivide_edge(edge)
    face_input.boundary_edges = edges

    holes = face_input.holes
    for hole in holes:
        for edge in hole:
            _subdivide_edge(edge)
    face_input.holes = holes


def _subdivide_shared_edges_only(face_input, occ_face, target_edge_length, fine_edge_ids):
    """Subdivide only the edges shared with fine faces (conformal boundary).

    Non-fine faces keep their coarse interior but need matching boundary
    points on edges shared with tet-meshed faces.
    """
    from OCP.BRepAdaptor import BRepAdaptor_Surface

    surface = BRepAdaptor_Surface(occ_face)

    def _maybe_subdivide(edge):
        if edge.edge_id not in fine_edge_ids:
            return
        pts = edge.uv_points
        if len(pts) < 2:
            return
        new_pts = [pts[0]]
        for i in range(len(pts) - 1):
            uv_a, uv_b = pts[i], pts[i + 1]
            p_a = surface.Value(uv_a[0], uv_a[1])
            p_b = surface.Value(uv_b[0], uv_b[1])
            d = ((p_b.X() - p_a.X()) ** 2 + (p_b.Y() - p_a.Y()) ** 2
                 + (p_b.Z() - p_a.Z()) ** 2) ** 0.5
            if d <= target_edge_length:
                new_pts.append(pts[i + 1])
            else:
                n_seg = max(2, int(d / target_edge_length + 0.5))
                for k in range(1, n_seg):
                    t = k / n_seg
                    u = uv_a[0] + t * (uv_b[0] - uv_a[0])
                    v = uv_a[1] + t * (uv_b[1] - uv_a[1])
                    new_pts.append([u, v])
                new_pts.append(pts[i + 1])
        edge.uv_points = new_pts

    edges = face_input.boundary_edges
    for edge in edges:
        _maybe_subdivide(edge)
    face_input.boundary_edges = edges

    holes = face_input.holes
    for hole in holes:
        for edge in hole:
            _maybe_subdivide(edge)
    face_input.holes = holes


from dataclasses import dataclass


@dataclass
class SolidConfig:
    """Per-solid meshing configuration for :func:`mesh_assembly`.

    Parameters
    ----------
    name : str
        Solid name — must match an object name in the CadQuery assembly.
        Also used as the DAGMC material tag.
    tolerance : float
        Linear deflection tolerance for surface meshing (mm).
        Ignored when ``target_edge_length`` is set.
    angular_tolerance : float
        Angular deflection tolerance for surface meshing (rad).
        Ignored when ``target_edge_length`` is set.
    target_edge_length : float or None
        If set, the solid is volume-meshed with tetrahedra.  The surface
        is first re-meshed with near-equilateral triangles at this edge
        length, then the interior is filled with tets.  The equilateral
        surface becomes both the DAGMC tracking surface and the tet
        boundary.  ``tolerance`` and ``angular_tolerance`` are ignored.
    """
    name: str
    tolerance: float = 1.0
    angular_tolerance: float = 0.1
    target_edge_length: float | None = None


def _remesh_to_edge_length(vertices, triangles, target_h, occ_face=None):
    """Remesh a surface to near-equilateral triangles at ``target_h``.

    Uses QEM decimation to coarsen, then refine + swap + smooth to reach
    the target edge length with good triangle quality.
    """
    from cad_to_dagmc_mesher import optimize_mesh_3d, refine_surface_to_edge_length
    from cad_to_dagmc_mesher.cad_to_dagmc_mesher import decimate_qem

    if len(triangles) < 4:
        return vertices, triangles

    verts = [list(v) for v in vertices]
    tris = [list(t) for t in triangles]

    # Step 1: QEM decimation — coarsen to near target_h (fast, handles
    # large ratios like 100K→1K tris)
    verts, tris = decimate_qem(verts, tris, target_h, 0)
    verts = [list(v) for v in verts]
    tris = [list(t) for t in tris]

    # Step 2: Refine — split edges longer than target_h
    verts, tris = refine_surface_to_edge_length(verts, tris, target_h)
    verts = [list(v) for v in verts]
    tris = [list(t) for t in tris]

    # Step 3: Swap + smooth to improve quality (no further collapse —
    # QEM already reached the target sizing)
    for _pass in range(3):
        th = [target_h] * len(verts)
        # collapse_ratio=0 disables collapse; only swap + smooth run
        verts, tris = optimize_mesh_3d(verts, tris, th, 0, 1, 0.0)
        verts = [list(v) for v in verts]
        tris = [list(t) for t in tris]

    return verts, tris


def _refine_surface_to_edge_length(
    vertices: list[list[float]],
    triangles: list[list[int]],
    target_edge_length: float,
) -> tuple[list[list[float]], list[list[int]]]:
    """Refine a surface mesh so no edge exceeds ``target_edge_length``.

    Iteratively splits long edges by inserting midpoints.
    Delegates to the Rust implementation for performance.
    """
    from cad_to_dagmc_mesher import refine_surface_to_edge_length as _refine_rust
    new_verts, new_tris = _refine_rust(vertices, triangles, target_edge_length)
    return [list(v) for v in new_verts], [list(t) for t in new_tris]


def mesh_assembly(
    assembly,
    material_tags: list[str] | None = None,
    tolerance: float = 0.03,
    angular_tolerance: float = 0.4,
    mesher: str = "auto",
    tet_volumes: list[str] | None = None,
    target_edge_length: float | None = None,
    imprint: bool = True,
    solid_config: list[SolidConfig] | None = None,
) -> dict:
    """Imprint, mesh, and produce output compatible with ``vertices_to_h5m``.

    This is the main entry point for meshing a CadQuery assembly. It produces
    a watertight, conformal surface mesh suitable for DAGMC particle transport,
    and optionally fills selected volumes with tetrahedral elements for
    OpenMC unstructured mesh tallies.

    Parameters
    ----------
    assembly : cadquery.Assembly
        The CadQuery assembly to mesh. Must contain at least one solid.
    solid_config : list[SolidConfig] or None
        Per-solid meshing configuration. Each entry names a solid in the
        assembly and specifies its mesh tolerances. When set, ``material_tags``,
        ``tolerance``, ``angular_tolerance``, ``tet_volumes`` and
        ``target_edge_length`` are ignored.
    material_tags : list[str] or None
        One material tag per solid in the assembly (order matches solid order).
        Deprecated — use ``solid_config`` instead.
    tolerance : float
        Linear deflection tolerance for surface meshing (smaller = more triangles).
        Deprecated — use ``solid_config`` instead.
    angular_tolerance : float
        Angular deflection tolerance for surface meshing (smaller = more triangles).
        Deprecated — use ``solid_config`` instead.
    mesher : str
        Surface meshing backend: ``"auto"`` (default), ``"meshadapt"``, or
        ``"brepmesh"``.
    tet_volumes : list[str] or None
        Material tags of volumes to fill with tetrahedra.
        Deprecated — use ``SolidConfig.target_edge_length`` instead.
    target_edge_length : float or None
        Target edge length for tet meshing.
        Deprecated — use ``SolidConfig.target_edge_length`` instead.
    imprint : bool
        If ``True`` (default), imprint the assembly using BOPAlgo to create
        shared faces between touching solids. Set to ``False`` if the geometry
        is already imprinted.

    Returns
    -------
    dict
        Always contains:

        - ``"vertices"`` — list of ``[x, y, z]`` coordinates
        - ``"triangles_by_solid_by_face"`` — ``{solid_id: {face_id: [[v0,v1,v2], ...]}}``
        - ``"material_tags"`` — list of material tag strings

        When any solid has ``target_edge_length`` set, also contains:

        - ``"tet_data"`` — ``{solid_id: {"vertices": [...], "tetrahedra": [...],
          "boundary_vertices": [...], "boundary_triangles": [...]}}``

    Examples
    --------
    Using ``solid_config``::

        result = mesh_assembly(assembly, solid_config=[
            SolidConfig("steel_shell", tolerance=1.0, angular_tolerance=0.1),
            SolidConfig("coil", target_edge_length=50.0),
        ])

    Legacy API (deprecated)::

        result = mesh_assembly(assembly, ["steel", "water"],
                               tolerance=1.0, angular_tolerance=0.1)
    """

    # --- Dispatch: solid_config vs legacy API ---
    if solid_config is not None and material_tags is not None:
        raise ValueError("Cannot specify both solid_config and material_tags")

    if solid_config is not None:
        # Use the finest tolerance for the shared extraction pass.
        # Tet-meshed solids use target_edge_length instead, so exclude them.
        surface_configs = [c for c in solid_config if c.target_edge_length is None]
        if surface_configs:
            tolerance = min(c.tolerance for c in surface_configs)
            angular_tolerance = min(c.angular_tolerance for c in surface_configs)
        else:
            # All solids are tet-meshed; use a reasonable default for extraction
            tolerance = 1.0
            angular_tolerance = 0.1

    elif material_tags is not None:
        pass  # legacy path — use tolerance/angular_tolerance as given
    else:
        raise ValueError("Either solid_config or material_tags must be provided")

    if material_tags is None and solid_config is None:
        raise ValueError("Either solid_config or material_tags must be provided")

    if material_tags is not None and tet_volumes and target_edge_length is None:
        raise ValueError("target_edge_length is required when tet_volumes is specified")

    # --- Extract assembly ---
    n_solids_hint = len(solid_config) if solid_config else len(material_tags)
    print(f"Extracting {n_solids_hint} solids (imprint={imprint})...")
    info = extract_assembly(assembly, tolerance, angular_tolerance, imprint=imprint)

    # --- Resolve solid_config names → solid IDs ---
    if solid_config is not None:
        solid_names = info.get("solid_names", {})

        # Build name→sid mapping with flexible matching: try exact match
        # first, then match by leaf name (after last '/').
        def _match_name(cfg_name, solid_names_dict):
            name_to_sid = {}
            for sid, full_name in solid_names_dict.items():
                if full_name == cfg_name:
                    name_to_sid[cfg_name] = sid
                    break
                leaf = full_name.rsplit("/", 1)[-1]
                if leaf == cfg_name:
                    name_to_sid[cfg_name] = sid
                    break
            return name_to_sid.get(cfg_name)

        # Validate names
        for cfg in solid_config:
            sid = _match_name(cfg.name, solid_names)
            if sid is None:
                leaves = sorted(n.rsplit("/", 1)[-1] for n in solid_names.values())
                raise ValueError(
                    f"SolidConfig name {cfg.name!r} not found in assembly. "
                    f"Available: {leaves}"
                )

        # Warn about unconfigured solids and add defaults
        configured_sids = set()
        configs_by_name = {}
        for cfg in solid_config:
            sid = _match_name(cfg.name, solid_names)
            configured_sids.add(sid)
            configs_by_name[solid_names[sid]] = cfg

        for sid, name in sorted(solid_names.items()):
            if sid not in configured_sids:
                leaf = name.rsplit("/", 1)[-1]
                print(f"  Warning: solid {leaf!r} not in solid_config, using defaults")
                configs_by_name[name] = SolidConfig(name=leaf)

        # Build ordered material_tags and config-by-sid mapping
        material_tags = []
        _configs_by_sid = {}
        for sid in sorted(solid_names.keys()):
            name = solid_names[sid]
            cfg = configs_by_name[name]
            material_tags.append(cfg.name)
            _configs_by_sid[sid] = cfg

        # Derive tet_volumes and target_edge_length from configs
        tet_volumes = []
        for sid, cfg in sorted(_configs_by_sid.items()):
            if cfg.target_edge_length is not None:
                tet_volumes.append(cfg.name)
        if not tet_volumes:
            tet_volumes = None

    face_inputs = info["face_inputs"]
    occ_faces = info["occ_faces"]
    solid_face_ids = info["solid_face_ids"]
    face_solid_ids = info["face_solid_ids"]
    n_faces = len(face_inputs)
    n_solids = len(material_tags) if material_tags else n_solids_hint
    print(f"Extracted {n_faces} surfaces from {n_solids} solids")
    _log_memory(f"after extract ({n_faces} faces)")

    # Harmonize shared edge discretization across faces
    _harmonize_shared_edges(face_inputs, occ_faces, info.get("_occ_faces_map"))

    # Identify tet-meshed solids and which faces need fine meshing.
    # "Fine faces" = faces on tet-meshed solids (including shared faces).
    # Shared faces between tet and non-tet solids get fine mesh for conformality.
    _tet_solid_ids = set()
    _fine_face_ids = set()  # faces that need uniform triangles
    # Determine which solids need tet meshing and their edge lengths.
    # With solid_config, each solid has its own target_edge_length.
    # With legacy API, all tet solids share the global target_edge_length.
    _any_tet = False
    if solid_config is not None:
        for idx, tag in enumerate(material_tags):
            sid = idx + 1
            cfg = _configs_by_sid.get(sid)
            if cfg and cfg.target_edge_length is not None:
                _tet_solid_ids.add(sid)
                _any_tet = True
    elif tet_volumes and target_edge_length:
        for idx, tag in enumerate(material_tags):
            if tag in tet_volumes:
                _tet_solid_ids.add(idx + 1)
                _any_tet = True
    if _any_tet:
        for sid in _tet_solid_ids:
            for fid in solid_face_ids.get(sid, []):
                _fine_face_ids.add(fid)

    # Re-extract periodic fine faces with actual wire edges so they can be
    # harmonized with adjacent non-periodic faces. The initial extraction
    # builds synthetic rectangular UV boundaries for periodic faces which
    # can't be matched by OCC IsSame().
    if _fine_face_ids:
        _occ_faces_map = info.get("_occ_faces_map", {})
        _edge_params_cache = info.get("_edge_params_cache", {})
        for i, fi in enumerate(face_inputs):
            if fi.face_id not in _fine_face_ids:
                continue
            of = occ_faces[i]
            surf = BRepAdaptor_Surface(of)
            dp = surf.IsUPeriodic() and surf.IsVPeriodic()
            sp = (surf.IsUPeriodic() or surf.IsVPeriodic()) and not dp
            if not (dp or sp):
                continue
            # Check if face has seam edges (needs re-extraction)
            if not _face_has_seam_edges(of):
                continue
            # Re-extract using actual wire edges (bypass rectangular UV)
            result = _extract_face(of, fi.face_id, tolerance, angular_tolerance,
                                   edge_params_cache=_edge_params_cache,
                                   force_wire_edges=True)
            if result is None:
                continue
            new_fi, occ_edge_list = result
            if new_fi is None or not new_fi.boundary_edges:
                continue
            # Replace boundary edges and OCC edge list
            fi.boundary_edges = new_fi.boundary_edges
            fi.holes = new_fi.holes
            _occ_faces_map[("occ_edges", fi.face_id)] = occ_edge_list
        # Re-harmonize after re-extraction
        _harmonize_shared_edges(face_inputs, occ_faces, _occ_faces_map)

    brep_face_set = set()
    meshadapt_face_set = set()
    periodic_face_ids = set()
    doubly_periodic_face_ids = set()

    # Faces that CAN'T use MeshAdapt (degenerate or doubly-periodic seam).
    # Single-seam faces are fine — MeshAdapt handles seam stitching.
    _meshadapt_blocked = set()
    for i, of in enumerate(occ_faces):
        surf = BRepAdaptor_Surface(of)
        doubly_periodic = surf.IsUPeriodic() and surf.IsVPeriodic()
        eff_doubly_periodic = _face_is_effectively_doubly_periodic(of)
        has_seam = _face_has_seam_edges(of)
        n_degen = _count_degenerate_edges(of)
        if n_degen > 0:
            _meshadapt_blocked.add(i)
        elif (doubly_periodic or eff_doubly_periodic) and has_seam:
            _meshadapt_blocked.add(i)

    # Propagate MeshAdapt from tet faces outward through shared edges.
    # This avoids MeshAdapt/BRepMesh boundaries where vertex positions
    # can't merge, causing geometric gaps for DAGMC ray tracing.
    _edge_to_face_idx = {}
    for i, fi in enumerate(face_inputs):
        for e in fi.boundary_edges:
            _edge_to_face_idx.setdefault(e.edge_id, []).append(i)
        for hole in fi.holes:
            for e in hole:
                _edge_to_face_idx.setdefault(e.edge_id, []).append(i)

    # Detect all-primitive tet solids: route every face to BRepMesh.
    # MeshAdapt's BDS roundtrip loses boundary vertices on highly-constrained
    # polygons and at sphere-pole+plane junctions, breaking watertightness
    # at face junctions. BRepMesh uses the harmonized OCC edge discretization
    # so adjacent faces share the same boundary vertices. Routing applies
    # when every face is a primitive OCC surface (plane, sphere, cylinder,
    # cone, torus); mixed with bezier/bspline/etc. stay on MeshAdapt to
    # preserve target_edge_length compliance for the tet mesher.
    from OCP.GeomAbs import (
        GeomAbs_Plane as _GeomAbs_Plane,
        GeomAbs_Sphere as _GeomAbs_Sphere,
        GeomAbs_Cylinder as _GeomAbs_Cylinder,
        GeomAbs_Cone as _GeomAbs_Cone,
        GeomAbs_Torus as _GeomAbs_Torus,
    )
    _PRIMITIVE_TYPES = {_GeomAbs_Plane, _GeomAbs_Sphere, _GeomAbs_Cylinder,
                        _GeomAbs_Cone, _GeomAbs_Torus}
    _solid_all_planar = {}  # actually "all primitive" — name kept for diff size
    for sid, fids in solid_face_ids.items():
        if sid not in _tet_solid_ids:
            continue
        _all = True
        _has_non_planar = False
        for fid in fids:
            for i, fi in enumerate(face_inputs):
                if fi.face_id == fid:
                    stype = BRepAdaptor_Surface(occ_faces[i]).GetType()
                    if stype not in _PRIMITIVE_TYPES:
                        _all = False
                    if stype != _GeomAbs_Plane:
                        _has_non_planar = True
                    break
            if not _all:
                break
        # Only route all-primitive solids that contain at least one curved
        # face — pure polyhedra benefit (planar+planar) and curved+planar
        # mixes benefit (sphere+plane in Ogive), but skip if the solid is
        # all planar (already handled correctly by earlier all-planar branch).
        _solid_all_planar[sid] = _all

    # Detect tet solids with ANY MeshAdapt-blocked face (degenerate
    # poles, doubly-periodic seams). To keep boundary discretization
    # consistent at face junctions, route ALL faces of such solids to
    # BRepMesh — mixing MeshAdapt + BRepMesh produces mismatched
    # boundaries (268 open edges typical for paraboloid+disc).
    _solid_has_blocked = {}
    for sid, fids in solid_face_ids.items():
        if sid not in _tet_solid_ids:
            continue
        _has_blocked = False
        for fid in fids:
            for i, fi in enumerate(face_inputs):
                if fi.face_id == fid and i in _meshadapt_blocked:
                    _has_blocked = True
                    break
            if _has_blocked:
                break
        _solid_has_blocked[sid] = _has_blocked

    # Seed: tet faces that aren't blocked. Faces belonging to all-primitive
    # tet solids or solids with any blocked face go to BRepMesh.
    _ma_queue = []
    for i, fi in enumerate(face_inputs):
        if fi.face_id not in _fine_face_ids:
            continue
        if i in _meshadapt_blocked:
            continue
        # Route to BRepMesh if the solid is all-primitive or contains a
        # blocked face (consistent boundary discretization).
        _routed_brep = False
        for sid in face_solid_ids.get(fi.face_id, []):
            if _solid_all_planar.get(sid, False) or _solid_has_blocked.get(sid, False):
                brep_face_set.add(i)
                _routed_brep = True
                break
        if _routed_brep:
            continue
        meshadapt_face_set.add(i)
        _ma_queue.append(i)

    # BFS propagation: spread MeshAdapt to adjacent faces through shared edges.
    # This avoids MeshAdapt/BRepMesh boundaries within the same solid.
    # Stop at faces blocked for MeshAdapt (degenerate, doubly-periodic).
    while _ma_queue:
        idx = _ma_queue.pop()
        fi = face_inputs[idx]
        for e in fi.boundary_edges:
            for adj_idx in _edge_to_face_idx.get(e.edge_id, []):
                if adj_idx in meshadapt_face_set or adj_idx in _meshadapt_blocked:
                    continue
                meshadapt_face_set.add(adj_idx)
                _ma_queue.append(adj_idx)

    # Remaining faces: classify normally
    for i, of in enumerate(occ_faces):
        if i in meshadapt_face_set or i in brep_face_set:
            continue
        surf = BRepAdaptor_Surface(of)
        doubly_periodic = surf.IsUPeriodic() and surf.IsVPeriodic()
        eff_doubly_periodic = _face_is_effectively_doubly_periodic(of)
        has_seam = _face_has_seam_edges(of)
        fid = face_inputs[i].face_id
        is_fine = fid in _fine_face_ids
        n_degen = _count_degenerate_edges(of)
        if is_fine:
            # Same routing as the seed loop: all-primitive solids or any
            # blocked face → BRepMesh for consistent boundaries.
            _routed_brep = False
            for sid in face_solid_ids.get(fid, []):
                if (_solid_all_planar.get(sid, False)
                        or _solid_has_blocked.get(sid, False)):
                    _routed_brep = True
                    break
            if _routed_brep:
                brep_face_set.add(i)
            else:
                meshadapt_face_set.add(i)
        elif n_degen > 0:
            brep_face_set.add(i)
        elif doubly_periodic and has_seam:
            brep_face_set.add(i)
        elif eff_doubly_periodic and has_seam:
            periodic_face_ids.add(fid)
            doubly_periodic_face_ids.add(fid)
        elif has_seam and len(occ_faces) > 1:
            brep_face_set.add(i)

    cdt_face_indices = [i for i in range(len(occ_faces))
                        if i not in brep_face_set and i not in meshadapt_face_set]

    # For fine faces: set adaptive size field + subdivide edges.
    # Also subdivide edges on NON-fine faces that share an edge with a fine
    # face (conformal boundary), but leave their interior coarse.
    # Compute effective target_edge_length for fine faces
    _effective_tel = target_edge_length
    if _effective_tel is None and solid_config is not None:
        tels = [c.target_edge_length for c in solid_config
                if c.target_edge_length is not None]
        if tels:
            _effective_tel = min(tels)

    fine_edge_ids = set()
    _fine_global_eids = set()
    _occ_faces_map = info.get("_occ_faces_map", {})
    _global_edge_map = info.get("_global_edge_map")
    if _fine_face_ids and _effective_tel:
        from ._size_field import compute_size_field

        # Build edge_id → face indices map to find shared edges
        edge_to_faces = {}
        for i, fi in enumerate(face_inputs):
            for e in fi.boundary_edges:
                edge_to_faces.setdefault(e.edge_id, []).append(i)
            for hole in fi.holes:
                for e in hole:
                    edge_to_faces.setdefault(e.edge_id, []).append(i)

        # Collect edge_ids that border any fine face
        fine_edge_ids = set()
        for i, fi in enumerate(face_inputs):
            if fi.face_id in _fine_face_ids:
                for e in fi.boundary_edges:
                    fine_edge_ids.add(e.edge_id)
                for hole in fi.holes:
                    for e in hole:
                        fine_edge_ids.add(e.edge_id)

        # Also build set of GLOBAL OCC edge IDs for fine faces (for gradient)
        if _global_edge_map is not None:
            for i, fi in enumerate(face_inputs):
                if fi.face_id in _fine_face_ids:
                    occ_el = _occ_faces_map.get(("occ_edges", fi.face_id), [])
                    for occ_e in occ_el:
                        gid = _global_edge_map.FindIndex(occ_e)
                        if gid > 0:
                            _fine_global_eids.add(gid)

        # Pass 1: Compute 3D subdivision points for each GLOBAL edge.
        # Subdivide once in 3D so shared edges get identical points.
        from OCP.BRepAdaptor import BRepAdaptor_Surface as _BAS
        from OCP.ShapeAnalysis import ShapeAnalysis_Surface as _SAS
        from OCP.BRep import BRep_Tool as _BRT
        from OCP.gp import gp_Pnt as _gp_Pnt

        # Get OCC edge lists per face for global edge ID lookup
        _occ_faces_map = info.get("_occ_faces_map", {})
        global_edge_map = info.get("_global_edge_map")

        edge_3d_points = {}  # global_edge_id → list of [x,y,z]
        for i, fi in enumerate(face_inputs):
            if fi.face_id not in _fine_face_ids:
                continue
            surface = _BAS(occ_faces[i])
            edges = fi.boundary_edges
            occ_edge_list = _occ_faces_map.get(("occ_edges", fi.face_id), [])
            for ei_idx, edge in enumerate(edges):
                # Get global edge ID
                gid = None
                if ei_idx < len(occ_edge_list):
                    gid = global_edge_map.FindIndex(occ_edge_list[ei_idx])
                if gid is None or gid <= 0:
                    gid = (fi.face_id, edge.edge_id)  # fallback: face-local
                if gid in edge_3d_points:
                    continue  # already subdivided by another face
                pts = edge.uv_points
                if len(pts) < 2:
                    continue
                pts_3d = []
                for uv in pts:
                    p = surface.Value(uv[0], uv[1])
                    pts_3d.append([p.X(), p.Y(), p.Z()])
                # Subdivide long segments (upsample only — keep dense points
                # since downsampling can break boundary-vertex matching across
                # adjacent faces meshed by MeshAdapt + BDS).
                new_3d = [pts_3d[0]]
                for j in range(len(pts_3d) - 1):
                    a, b = pts_3d[j], pts_3d[j + 1]
                    d = sum((a[k] - b[k]) ** 2 for k in range(3)) ** 0.5
                    if d <= _effective_tel:
                        new_3d.append(pts_3d[j + 1])
                    else:
                        n_seg = max(2, int(d / _effective_tel + 0.5))
                        for k in range(1, n_seg):
                            t = k / n_seg
                            new_3d.append([
                                a[0] + t * (b[0] - a[0]),
                                a[1] + t * (b[1] - a[1]),
                                a[2] + t * (b[2] - a[2]),
                            ])
                        new_3d.append(pts_3d[j + 1])
                edge_3d_points[gid] = new_3d

        # Pass 2: For each face, subdivide edges using the SAME proportional
        # positions as the 3D subdivision. This avoids 3D→UV projection errors.
        # We store the subdivision ratios (not 3D points) per edge_id.
        edge_subdiv_ratios = {}  # edge_id → list of (segment_idx, list_of_t_values)
        for eid, pts_3d in edge_3d_points.items():
            # Compute cumulative arc length of original segments
            # (the new_3d list has original endpoints + inserted midpoints)
            # The ratios tell us where each new point falls relative to
            # the original segment endpoints.
            ratios = []  # (original_segment_index, fractional_position)
            # Rebuild: walk through the 3D points and figure out which
            # original segment each belongs to. Actually, the subdivision
            # inserts points proportionally within each segment, so we
            # just need the count per segment. Store as flat list of
            # (orig_seg_idx, t) pairs.
            pass  # Complex — use simpler approach below

        # Simpler approach: for each face, subdivide its edges in UV space
        # using the same 3D distances. This ensures all faces sharing an
        # edge get the SAME number of points at proportionally matching
        # positions along the 3D curve.
        for i, fi in enumerate(face_inputs):
            is_fine = fi.face_id in _fine_face_ids
            has_shared = any(e.edge_id in fine_edge_ids for e in fi.boundary_edges)

            if is_fine:
                # Per-solid target_edge_length for the size field
                _face_tel = _effective_tel
                if solid_config is not None:
                    for sid in face_solid_ids.get(fi.face_id, []):
                        cfg = _configs_by_sid.get(sid)
                        if cfg and cfg.target_edge_length is not None:
                            _face_tel = cfg.target_edge_length
                            break
                sf = compute_size_field(
                    occ_faces[i], nu=20, nv=20,
                    max_h=_face_tel,
                )
                fi.mode = ("adaptive", sf)

            if is_fine or has_shared:
                surface = _BAS(occ_faces[i])
                edges = fi.boundary_edges
                occ_edge_list = _occ_faces_map.get(("occ_edges", fi.face_id), [])
                for ei_idx, edge in enumerate(edges):
                    gid = None
                    if ei_idx < len(occ_edge_list):
                        gid = global_edge_map.FindIndex(occ_edge_list[ei_idx])
                    if gid is None or gid <= 0:
                        gid = (fi.face_id, edge.edge_id)
                    should_subdivide = is_fine or (edge.edge_id in fine_edge_ids)
                    if not should_subdivide:
                        continue
                    if gid not in edge_3d_points:
                        continue
                    n_target = len(edge_3d_points[gid])
                    pts = edge.uv_points
                    if len(pts) < 2 or n_target <= len(pts):
                        continue
                    # Subdivide by distributing n_target points uniformly
                    # along the 3D arc length, interpolating in UV space.
                    # This avoids ValueOfUV seam issues on periodic surfaces.
                    seg_lengths = []
                    for j in range(len(pts) - 1):
                        p0 = surface.Value(pts[j][0], pts[j][1])
                        p1 = surface.Value(pts[j + 1][0], pts[j + 1][1])
                        d = ((p1.X()-p0.X())**2 + (p1.Y()-p0.Y())**2 + (p1.Z()-p0.Z())**2)**0.5
                        seg_lengths.append(d)
                    total_len = sum(seg_lengths)
                    if total_len < 1e-12:
                        continue
                    target_spacing = total_len / (n_target - 1)
                    new_uv = [pts[0]]
                    cum = 0.0
                    next_target = target_spacing
                    for j in range(len(pts) - 1):
                        seg_len = seg_lengths[j]
                        seg_start = cum
                        cum += seg_len
                        while next_target < cum - 1e-12 and len(new_uv) < n_target - 1:
                            frac = (next_target - seg_start) / seg_len if seg_len > 1e-12 else 0.5
                            u = pts[j][0] + frac * (pts[j+1][0] - pts[j][0])
                            v = pts[j][1] + frac * (pts[j+1][1] - pts[j][1])
                            new_uv.append([u, v])
                            next_target += target_spacing
                    new_uv.append(pts[-1])
                    edge.uv_points = new_uv
                fi.boundary_edges = edges

        # Re-harmonize after subdivision (subdivision may have changed point counts)
        _harmonize_shared_edges(face_inputs, occ_faces, info.get("_occ_faces_map"))
        _log_memory("after edge subdivision (Pass 1+2)")

    # Subdivide shared edges between non-tet MeshAdapt faces.
    # MeshAdapt splits coarse boundary edges internally, creating
    # unmatched vertices across faces. Pre-subdivide to prevent this.
    if meshadapt_face_set:
        from OCP.BRepAdaptor import BRepAdaptor_Surface as _BAS2
        _edge_to_fi = {}
        for i, fi in enumerate(face_inputs):
            for e in fi.boundary_edges:
                _edge_to_fi.setdefault(e.edge_id, []).append(i)
            if fi.holes:
                for hole in fi.holes:
                    for e in hole:
                        _edge_to_fi.setdefault(e.edge_id, []).append(i)
        # Only process edges shared by 2+ MeshAdapt faces
        shared_ma_eids = {eid for eid, fis in _edge_to_fi.items()
                          if len(fis) >= 2 and
                          any(fi in meshadapt_face_set for fi in fis)}
        if shared_ma_eids:
            def _subdivide_edge_tel(edge, occ_face, tel):
                """Subdivide an edge so no segment exceeds tel in 3D."""
                s = _BAS2(occ_face)
                pts = edge.uv_points
                if len(pts) < 2:
                    return False
                new_pts = [pts[0]]
                changed = False
                for j in range(len(pts) - 1):
                    a, b = pts[j], pts[j + 1]
                    p_a = s.Value(a[0], a[1])
                    p_b = s.Value(b[0], b[1])
                    d = ((p_b.X()-p_a.X())**2 + (p_b.Y()-p_a.Y())**2 +
                         (p_b.Z()-p_a.Z())**2) ** 0.5
                    if d > tel * 1.5:
                        n_seg = max(2, int(d / tel + 0.5))
                        for k in range(1, n_seg):
                            t = k / n_seg
                            new_pts.append([a[0]+t*(b[0]-a[0]), a[1]+t*(b[1]-a[1])])
                        changed = True
                    new_pts.append(pts[j + 1])
                if changed:
                    edge.uv_points = new_pts
                return changed
            # Estimate target element size per face from tolerance settings
            for i, fi in enumerate(face_inputs):
                if i not in meshadapt_face_set:
                    continue
                of = occ_faces[i]
                # Get per-solid target_edge_length if available
                _tel = None
                if solid_config:
                    for sid in face_solid_ids.get(fi.face_id, []):
                        cfg = _configs_by_sid.get(sid)
                        if cfg and cfg.target_edge_length:
                            _tel = cfg.target_edge_length
                            break
                if _tel is None:
                    # Estimate from tolerance: representative edge length
                    from OCP.Bnd import Bnd_Box as _BB2
                    from OCP.BRepBndLib import BRepBndLib as _BBL2
                    _box = _BB2()
                    _BBL2.Add_s(of, _box)
                    _xn, _yn, _zn, _xx, _yx, _zx = _box.Get()
                    _diag = ((_xx-_xn)**2+(_yx-_yn)**2+(_zx-_zn)**2)**0.5
                    _tel = max(_diag * 0.15, 0.1)
                # For gradient-eligible faces (non-tet, adjacent to tet),
                # use coarse subdivision on non-tet-shared edges.
                _occ_el = _occ_faces_map.get(("occ_edges", fi.face_id), [])
                _coarse_tel = max(_tel * 4, _effective_tel * 2) if _effective_tel else _tel
                did_change = False
                edges = fi.boundary_edges
                for ei, e in enumerate(edges):
                    if e.edge_id in shared_ma_eids:
                        # Check if this edge is shared with a tet face
                        _is_fine_edge = False
                        if ei < len(_occ_el) and _global_edge_map:
                            gid = _global_edge_map.FindIndex(_occ_el[ei])
                            _is_fine_edge = gid > 0 and gid in _fine_global_eids
                        _edge_tel = _tel if _is_fine_edge else _coarse_tel
                        if _subdivide_edge_tel(e, of, _edge_tel):
                            did_change = True
                if did_change:
                    fi.boundary_edges = edges
                if fi.holes:
                    _bdy_count = len(fi.boundary_edges) if fi.boundary_edges else 0
                    holes = fi.holes
                    for hi, hole in enumerate(holes):
                        for hei, e in enumerate(hole):
                            if e.edge_id in shared_ma_eids:
                                occ_ei = _bdy_count + sum(len(fi.holes[k]) for k in range(hi)) + hei
                                _is_fine_edge = False
                                if occ_ei < len(_occ_el) and _global_edge_map:
                                    gid = _global_edge_map.FindIndex(_occ_el[occ_ei])
                                    _is_fine_edge = gid > 0 and gid in _fine_global_eids
                                _edge_tel = _tel if _is_fine_edge else _coarse_tel
                                if _subdivide_edge_tel(e, of, _edge_tel):
                                    did_change = True
                    if did_change:
                        fi.holes = holes
            # Re-harmonize to ensure shared edges match after subdivision
            _harmonize_shared_edges(face_inputs, occ_faces, info.get("_occ_faces_map"))

    all_vertices = []
    face_tris_global_raw = {}
    _faces_done = 0

    # --- Early volume meshing: launch tet meshing as soon as a solid's
    # surfaces are all done, overlapping with remaining surface meshing. ---
    from concurrent.futures import ThreadPoolExecutor
    from cad_to_dagmc_mesher import compact_mesh as _compact_mesh

    _vol_executor = ThreadPoolExecutor(max_workers=2) if _any_tet else None
    _vol_futures = {}  # sid → Future
    _tet_face_verts = {}  # sid → {fid: (verts, tris)} — local per-face data
    _tet_faces_needed = {}  # sid → set of face_ids needed
    _tet_faces_done = {}  # sid → set of face_ids completed

    if _any_tet:
        from cad_to_dagmc_mesher import VolumeInput, mesh_volume

        # Determine edge lengths per tet solid
        _tet_edge_lengths = {}
        for sid in _tet_solid_ids:
            if solid_config is not None and sid in _configs_by_sid:
                _tet_edge_lengths[sid] = _configs_by_sid[sid].target_edge_length
            else:
                _tet_edge_lengths[sid] = target_edge_length

        for sid in _tet_solid_ids:
            _tet_faces_needed[sid] = set(solid_face_ids.get(sid, []))
            _tet_faces_done[sid] = set()
            _tet_face_verts[sid] = {}

    def _check_launch_volume(fid, verts, tris):
        """If this face completes a tet-solid's surface, launch volume meshing."""
        if not _any_tet:
            return
        for sid in face_solid_ids.get(fid, []):
            if sid not in _tet_solid_ids:
                continue
            if sid in _vol_futures:
                continue  # already launched
            _tet_face_verts[sid][fid] = (verts, tris)
            _tet_faces_done[sid].add(fid)
            if _tet_faces_done[sid] >= _tet_faces_needed[sid]:
                # All faces for this solid are done — launch volume meshing
                solid_tris_flat = []
                solid_verts_flat = []
                for _fid in sorted(_tet_face_verts[sid]):
                    _fv, _ft = _tet_face_verts[sid][_fid]
                    offset_v = len(solid_verts_flat)
                    solid_verts_flat.extend(_fv)
                    solid_tris_flat.extend(
                        [t[0] + offset_v, t[1] + offset_v, t[2] + offset_v]
                        for t in _ft
                    )
                local_verts, local_tris = _compact_mesh(solid_verts_flat, solid_tris_flat)
                edge_len = _tet_edge_lengths[sid]
                inp = VolumeInput(
                    boundary_vertices=local_verts,
                    boundary_triangles=local_tris,
                    target_edge_length=edge_len,
                )
                print(f"  Launching volume meshing for solid {sid} "
                      f"({len(local_verts)} boundary verts, "
                      f"{len(local_tris)} boundary tris)...")
                _log_memory(f"before volume meshing solid {sid}")
                # mesh_volume releases the GIL, so this truly runs in parallel
                future = _vol_executor.submit(mesh_volume, inp)
                _vol_futures[sid] = (future, local_verts, local_tris)

    # Pre-mesh compound with BRepMesh for edge discretization.
    # When MeshAdapt faces share edges with BRepMesh faces, MeshAdapt needs
    # BRepMesh's edge polygon to build a matching boundary so that both
    # meshes connect at shared edges after vertex merging.
    _brepmesh_ran = False
    scaled_tol = tolerance
    scaled_ang = angular_tolerance
    if meshadapt_face_set and brep_face_set:
        _bm_compound = info.get("imprinted_compound")
        if _bm_compound is not None:
            _bm_compound = getattr(_bm_compound, "wrapped", _bm_compound)
            BRepTools.Clean_s(_bm_compound)
            BRepMesh_IncrementalMesh(_bm_compound, scaled_tol, False, scaled_ang)
            _brepmesh_ran = True

    # MeshAdapt path — process tet-solid faces first so volume meshing
    # can start in the background while remaining surfaces are still meshing.
    _meshadapt_edge_cache = {}

    if meshadapt_face_set:
        _meshadapt_order = sorted(meshadapt_face_set,
                                   key=lambda i: (0 if face_inputs[i].face_id in _fine_face_ids else 1, i))
        for idx in _meshadapt_order:
            fi, of = face_inputs[idx], occ_faces[idx]
            # For tet-meshed faces, pass the per-solid target_edge_length
            tel = None
            if fi.face_id in _fine_face_ids:
                if solid_config is not None:
                    for sid in face_solid_ids.get(fi.face_id, []):
                        cfg = _configs_by_sid.get(sid)
                        if cfg and cfg.target_edge_length is not None:
                            tel = cfg.target_edge_length
                            break
                elif _effective_tel:
                    tel = _effective_tel
            # Extract BRepMesh wire boundary for shared-edge matching
            wire_boundary = None
            if _brepmesh_ran:
                wire_boundary = _extract_brepmesh_boundary(of)

            # Build gradient_edges for non-tet faces in solids that have tet faces.
            # This makes the mesh fine near shared edges and coarse away.
            # Even faces without tet-shared edges get an empty gradient to
            # trigger coarser max_h.
            _gradient = None
            _face_in_tet_solid = False
            if tel is None and _effective_tel and _fine_face_ids:
                for sid in face_solid_ids.get(fi.face_id, []):
                    if any(fid in _fine_face_ids for fid in solid_face_ids.get(sid, [])):
                        _face_in_tet_solid = True
                        break
            if _face_in_tet_solid and fi.boundary_edges and _fine_global_eids:
                _occ_el = _occ_faces_map.get(("occ_edges", fi.face_id), [])
                _grad_list = []
                for ei, e in enumerate(fi.boundary_edges):
                    if ei < len(_occ_el):
                        gid = _global_edge_map.FindIndex(_occ_el[ei])
                        if gid > 0 and gid in _fine_global_eids:
                            _grad_list.append((e.uv_points, _effective_tel))
                if fi.holes:
                    _bdy_count = len(fi.boundary_edges) if fi.boundary_edges else 0
                    for hi, hole in enumerate(fi.holes):
                        for hei, e in enumerate(hole):
                            occ_ei = _bdy_count + sum(len(fi.holes[k]) for k in range(hi)) + hei
                            if occ_ei < len(_occ_el):
                                gid = _global_edge_map.FindIndex(_occ_el[occ_ei])
                                if gid > 0 and gid in _fine_global_eids:
                                    _grad_list.append((e.uv_points, _effective_tel))
                # Pass gradient even if empty — triggers coarser max_h
                _gradient = _grad_list if _grad_list else []

            result = _mesh_face_meshadapt(of, tolerance, angular_tolerance,
                                          target_edge_length=tel,
                                          boundary_edges=fi.boundary_edges if fi.boundary_edges else None,
                                          wire_boundary=wire_boundary,
                                          holes=fi.holes if fi.holes else None,
                                          gradient_edges=_gradient)
            _faces_done += 1
            if result is not None:
                verts, tris = result
                # Stitch seam edges on periodic faces: merge boundary
                # vertices that map to the same 3D point across the seam.
                if _face_has_seam_edges(of):
                    from cad_to_dagmc_mesher import merge_boundary_only_3d as _merge_bdy
                    # Compute actual boundary polygon size (edges skip first
                    # dup + remove closing dup, matching _mesh_face_meshadapt).
                    n_bdy = 0
                    if fi.boundary_edges:
                        for ei_b, eb in enumerate(fi.boundary_edges):
                            n_bdy += len(eb.uv_points) - (1 if ei_b > 0 else 0)
                        n_bdy -= 1  # closing point removed
                    if n_bdy > 0 and n_bdy <= len(verts):
                        merged_v, remap_list = _merge_bdy(verts, n_bdy)
                        remap_map = {i: r for i, r in enumerate(remap_list)}
                        seen = set()
                        new_tris = []
                        for t in tris:
                            a, b, c = remap_map.get(t[0], t[0]), remap_map.get(t[1], t[1]), remap_map.get(t[2], t[2])
                            if a == b or b == c or a == c:
                                continue
                            key = tuple(sorted([a, b, c]))
                            if key not in seen:
                                seen.add(key)
                                new_tris.append([a, b, c])
                        verts = [list(v) for v in merged_v]
                        tris = new_tris
                verts, tris = _cleanup_non_manifold(verts, tris)

                _method = "meshadapt+equilateral" if tel else "meshadapt"
                print(f"  Surface {_faces_done}/{n_faces} meshed ({len(tris)} triangles, {_method})")
                offset = len(all_vertices)
                all_vertices.extend(verts)
                global_tris = [
                    [t[0] + offset, t[1] + offset, t[2] + offset] for t in tris
                ]
                # Ensure consistent outward-pointing normals (required by DAGMC)
                if not _face_normal_outward(of):
                    for t in global_tris:
                        t[0], t[1], t[2] = t[0], t[2], t[1]
                face_tris_global_raw[fi.face_id] = global_tris
                _check_launch_volume(fi.face_id, verts, tris)
            elif mesher == "auto":
                brep_face_set.add(idx)
            else:
                raise RuntimeError(
                    f"MeshAdapt failed on face {fi.face_id} and mesher='meshadapt' "
                    f"(no fallback)"
                )

    # BRepMesh path
    if brep_face_set:
        if not _brepmesh_ran:
            occ_compound = info.get("imprinted_compound")
            if occ_compound is not None:
                occ_compound = getattr(occ_compound, "wrapped", occ_compound)
                BRepTools.Clean_s(occ_compound)
                BRepMesh_IncrementalMesh(occ_compound, scaled_tol, False, scaled_ang)

        for idx in list(cdt_face_indices):
            fid = face_inputs[idx].face_id
            if fid not in periodic_face_ids:
                brep_face_set.add(idx)
                cdt_face_indices.remove(idx)

        _brep_order = sorted(brep_face_set,
                             key=lambda i: (0 if face_inputs[i].face_id in _fine_face_ids else 1, i))
        for idx in _brep_order:
            fi, of = face_inputs[idx], occ_faces[idx]
            brep = _extract_brep_mesh_face(of)
            _faces_done += 1
            if brep is None:
                print(f"  Surface {_faces_done}/{n_faces} skipped (no triangulation)")
                continue
            if len(brep) == 3:
                verts, tris, face_uvs = brep
            else:
                verts, tris = brep
                face_uvs = None
            if len(tris) <= 5000:
                # Run optimization on small faces (fast) but skip on large
                # BSpline faces where ValueOfUV is prohibitively slow.
                verts, tris = _optimize_3d_mesh(verts, tris, of, passes=3,
                                                tolerance=scaled_tol,
                                                uvs=face_uvs)
            verts, tris = _cleanup_non_manifold(verts, tris)
            _method = "brep"
            if fi.face_id in _fine_face_ids:
                _method = "brep+tet"
            print(f"  Surface {_faces_done}/{n_faces} meshed ({len(tris)} triangles, {_method})")
            offset = len(all_vertices)
            all_vertices.extend(verts)
            face_tris_global_raw[fi.face_id] = [
                [t[0] + offset, t[1] + offset, t[2] + offset] for t in tris
            ]
            _check_launch_volume(fi.face_id, verts, tris)

    # CDT path
    if cdt_face_indices:
        cdt_inputs = [face_inputs[i] for i in cdt_face_indices]
        cdt_occ = [occ_faces[i] for i in cdt_face_indices]
        from cad_to_dagmc_mesher import mesh_faces_dag
        face_outputs = mesh_faces_dag(cdt_inputs)
        for fi, fo, of in zip(cdt_inputs, face_outputs, cdt_occ):
            offset = len(all_vertices)
            if fi.face_id in periodic_face_ids:
                truly_periodic = fi.face_id in doubly_periodic_face_ids
                verts, tris = _stitch_periodic_uv_mesh(
                    fi, fo, of, fill_holes=truly_periodic)
                is_tet_face = fi.face_id in _fine_face_ids
                if not is_tet_face:
                    # Non-tet faces: collapse for minimal triangulation
                    cr = 0.48 if truly_periodic else 0.35
                    verts, tris = _collapse_periodic_mesh_3d(
                        verts, tris, of, passes=3, collapse_ratio=cr,
                        tolerance=tolerance)
                # else: tet faces keep the CDT's equilateral triangles
                verts, tris = _cleanup_non_manifold(verts, tris)
            else:
                verts, tris = _evaluate_face_3d(fi, fo, of)
            _faces_done += 1
            _method = "cdt"
            if fi.face_id in _fine_face_ids:
                _method = "cdt+equilateral"
            elif fi.face_id in periodic_face_ids:
                _method = "cdt+periodic"
            print(f"  Surface {_faces_done}/{n_faces} meshed ({len(tris)} triangles, {_method})")
            all_vertices.extend(verts)
            global_tris = [[t[0] + offset, t[1] + offset, t[2] + offset] for t in tris]
            if not _face_normal_outward(of):
                for t in global_tris:
                    t[0], t[1], t[2] = t[0], t[2], t[1]
            face_tris_global_raw[fi.face_id] = global_tris
            _check_launch_volume(fi.face_id, verts, tris)

    all_vertices, remap = _merge_vertices_with_remap(all_vertices, tol=None)

    face_ref_count = {}
    for fids in solid_face_ids.values():
        for fid in fids:
            face_ref_count[fid] = face_ref_count.get(fid, 0) + 1

    complete = {}
    for solid_id, fids in solid_face_ids.items():
        solid_tris = {}
        for fid in fids:
            if fid not in face_tris_global_raw:
                continue
            solid_tris[fid] = _dedup_tris(_remap_tris(face_tris_global_raw[fid], remap))
        complete[solid_id] = solid_tris
    _fix_normals_bfs(all_vertices, complete)


    if True:
        shared_face_emitted = set()
        triangles_by_solid_by_face = {}
        for solid_id, fids in solid_face_ids.items():
            solid_tris = {}
            for fid in fids:
                if fid not in complete.get(solid_id, {}):
                    continue
                is_shared = face_ref_count.get(fid, 1) > 1
                if is_shared and fid in shared_face_emitted:
                    solid_tris[fid] = []
                else:
                    if is_shared:
                        shared_face_emitted.add(fid)
                    solid_tris[fid] = complete[solid_id][fid]
            triangles_by_solid_by_face[solid_id] = solid_tris

    # NOTE: global fill_boundary_holes disabled — it dumped all fill
    # triangles into the first face of the first solid, creating
    # non-manifold edges and cross-face vertex contamination.

    print(f"Surface meshing complete ({len(all_vertices)} vertices)")
    _log_memory("after surface meshing")

    # Collect volume meshing results from early-launched futures
    tet_data = {}
    if _vol_futures:
        n_tet_vols = len(_vol_futures)
        print(f"Waiting for {n_tet_vols} volume mesh(es) to complete...")
        for vi, (sid, (future, local_verts, local_tris)) in enumerate(
                sorted(_vol_futures.items()), 1):
            vol_out = future.result()
            tet_verts = list(local_verts) + list(vol_out.interior_vertices)
            n_tets = len(vol_out.tetrahedra)
            print(f"  Volume {vi}/{n_tet_vols} meshed ({n_tets} tetrahedra)")
            _log_memory(f"after volume {vi} ({n_tets} tets)")
            tet_data[sid] = {
                "vertices": tet_verts,
                "tetrahedra": vol_out.tetrahedra,
                "boundary_vertices": local_verts,
                "boundary_triangles": local_tris,
            }
    if _vol_executor is not None:
        _vol_executor.shutdown(wait=False)

    result = {
        "vertices": all_vertices,
        "triangles_by_solid_by_face": triangles_by_solid_by_face,
        "material_tags": list(material_tags),
    }
    if tet_data:
        result["tet_data"] = tet_data
    return result
