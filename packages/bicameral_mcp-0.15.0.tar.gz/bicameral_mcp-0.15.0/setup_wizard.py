"""Interactive setup wizard for bicameral-mcp.

Guides the user through selecting a repo and coding agent, then installs
the MCP server config + skills.

Supports: Claude Code, Cursor, Codex

Usage: bicameral-mcp setup
       bicameral-mcp setup /path/to/repo
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


def _bundled_manifest_paths() -> tuple[Path, Path, Path] | None:
    """Locate bundled ``hooks-manifest.json`` + ``.sig`` + ``.crt``.

    Returns ``None`` when no artifacts are bundled (dev install from
    source checkout — no production wheel context, so no LLM-11 threat
    surface). Returns the triple only when ALL THREE artifacts are
    found alongside the installed package via hatch ``shared-data``.

    The all-or-nothing check guards against the interim packaging
    state where the wheel ships the manifest but the release-side
    sigstore-python signing step has not yet been wired up — without
    this guard the verifier hits a missing-signature path that the
    docstring of ``release.manifest_verify._sigstore_verify`` claims
    is unreachable. Restoring the check is a no-op once the release
    pipeline starts emitting ``.sig``/``.crt`` alongside the manifest.
    """
    candidates = [
        Path(sys.prefix) / "share" / "bicameral-mcp" / "hooks-manifest.json",
        Path(__file__).parent.parent / "share" / "bicameral-mcp" / "hooks-manifest.json",
    ]
    for c in candidates:
        sig = Path(str(c) + ".sig")
        crt = Path(str(c) + ".crt")
        if c.exists() and sig.exists() and crt.exists():
            return c, sig, crt
    return None


def _verify_intended_writes(*event_types: str) -> None:
    """Verify the signed manifest carries the SHA-256s of the commands the
    caller is about to write. No-op when no bundled manifest exists
    (dev install). Honors ``BICAMERAL_HOOKS_VERIFY_DISABLE=1`` bypass.
    """
    paths = _bundled_manifest_paths()
    if paths is None:
        return
    from release import hooks_source, manifest_verify

    by_event = {h["event_type"]: h["command"] for h in hooks_source.BICAMERAL_HOOKS}
    expected = {et: hashlib.sha256(by_event[et].encode("utf-8")).hexdigest() for et in event_types}
    manifest_verify.verify_hooks_or_bypass(*paths, expected)


def _bundled_skills_manifest_paths() -> tuple[Path, Path, Path] | None:
    """Locate bundled ``skills-manifest.toml`` + ``.sig`` + ``.crt`` (#218 LLM-06).

    Returns ``None`` when no artifacts are bundled (dev install from
    source checkout — no production wheel context, so the LLM-06
    design-constraint gate is N/A). Returns the triple only when ALL
    THREE artifacts are found alongside the installed package via
    hatch ``shared-data``.

    Mirrors ``_bundled_manifest_paths`` for the skills-content surface,
    including the all-or-nothing guard against the interim packaging
    state where the wheel ships the manifest but no sigstore signature
    yet.
    """
    candidates = [
        Path(sys.prefix) / "share" / "bicameral-mcp" / "skills-manifest.toml",
        Path(__file__).parent.parent / "share" / "bicameral-mcp" / "skills-manifest.toml",
    ]
    for c in candidates:
        sig = Path(str(c) + ".sig")
        crt = Path(str(c) + ".crt")
        if c.exists() and sig.exists() and crt.exists():
            return c, sig, crt
    return None


def _verify_intended_skills_writes() -> None:
    """Verify the signed skills-manifest carries the SHA-256s of the
    SKILL.md + *.yaml files the installer is about to copy (#218 LLM-06).

    No-op when no bundled manifest exists (dev install). Honors
    ``BICAMERAL_SKILLS_VERIFY_DISABLE=1`` bypass with severity-3
    ``verification_bypassed`` ledger event (manifest_kind="skills").
    """
    paths = _bundled_skills_manifest_paths()
    if paths is None:
        return
    from release import skills_source, skills_verify

    expected: dict[str, dict[str, str]] = {}
    for skill_name, filename, file_bytes in skills_source.walk_skills():
        expected.setdefault(skill_name, {})[filename] = hashlib.sha256(file_bytes).hexdigest()
    skills_verify.verify_skills_or_bypass(*paths, expected)


def _ensure_utf8_stdout(platform: str | None = None) -> None:
    """Reconfigure stdout/stderr to UTF-8 on Windows so banner box-drawing
    chars (┌─┐│└┘) printed by run_setup / run_config_wizard / run_reset_wizard
    don't crash under cp1252. No-op on POSIX. Silent on environments where
    `.reconfigure` is missing or fails. ``platform`` arg is for test isolation;
    production callers pass None and the helper reads ``sys.platform``. (#199)
    """
    target = platform if platform is not None else sys.platform
    if target != "win32":
        return
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            pass


AGENTS = {
    "claude": {
        "name": "Claude Code",
        "config_format": "json",
        "config_path": lambda repo: repo / ".mcp.json",
        "skills": True,
    },
    "cursor": {
        "name": "Cursor",
        "config_format": "json",
        "config_path": lambda repo: repo / ".cursor" / "mcp.json",
        "skills": False,
    },
    "codex": {
        "name": "Codex",
        "config_format": "toml",
        "config_path": lambda repo: repo / ".codex" / "config.toml",
        "skills": False,
    },
}


def _detect_history_path(repo_path: Path, hint: str | None = None) -> Path:
    """Optionally select a separate directory for Bicameral history storage.

    Returns repo_path if the user skips (default).  The separate path is
    useful when the code repo is public but history should live in a private
    parent repo.
    """
    if hint:
        p = Path(hint).resolve()
        if p.is_dir():
            return p
        print(f"  History path not found: {p}")

    if not _is_interactive():
        return repo_path

    raw = input(
        "\n  History storage path (default: same as repo — press Enter to skip):\n  > "
    ).strip()
    if not raw:
        return repo_path

    p = Path(raw).expanduser().resolve()
    if p.is_dir():
        return p
    print(f"  Not a directory: {p} — falling back to repo path")
    return repo_path


def _detect_repo(hint: str | None = None) -> Path:
    """Detect or prompt for the repo path."""
    if hint:
        p = Path(hint).resolve()
        if p.is_dir():
            return p
        print(f"  Path not found: {p}")

    cwd = Path.cwd()
    git_root = _find_git_root(cwd)

    # Non-interactive: use detected git root or cwd
    if not _is_interactive():
        if git_root:
            return git_root
        return cwd

    if git_root:
        answer = input(f"\n  Detected git repo: {git_root}\n  Use this? [Y/n] ").strip().lower()
        if answer in ("", "y", "yes"):
            return git_root

    while True:
        raw = input("\n  Enter the path to your repo: ").strip()
        if not raw:
            continue
        p = Path(raw).expanduser().resolve()
        if p.is_dir():
            return p
        print(f"  Not a directory: {p}")


def _find_git_root(start: Path) -> Path | None:
    """Walk up from start to find .git directory."""
    current = start
    for _ in range(20):
        if (current / ".git").exists():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _resolve_git_hooks_dir(repo_path: Path) -> Path | None:
    """Return the actual git hooks directory for ``repo_path``.

    For a normal repo this is ``<root>/.git/hooks``. For a submodule or
    linked worktree, ``.git`` is a *file* containing a ``gitdir:`` pointer
    to the real git directory (e.g. ``<super>/.git/modules/<name>``); the
    hooks live there, not under the submodule's working tree. The previous
    implementation built ``<root>/.git/hooks`` unconditionally and crashed
    with ``NotADirectoryError`` on submodule installs.
    """
    gitdir = _resolve_git_pointer(repo_path)
    if gitdir is None:
        return None
    return gitdir / "hooks"


def _resolve_git_pointer(repo_path: Path) -> Path | None:
    """Return the real gitdir for ``repo_path`` regardless of layout.

    For a normal repo this is ``<root>/.git``. For a linked worktree or
    submodule, ``.git`` is a *file* containing a ``gitdir:`` pointer; we
    parse the pointer and return the resolved target. Shared between
    ``_resolve_git_hooks_dir`` and the worktree-detection notice in
    ``run_setup`` so the two paths stay in lockstep.
    """
    git_root = _find_git_root(repo_path)
    if git_root is None:
        return None
    git_marker = git_root / ".git"
    if git_marker.is_dir():
        return git_marker
    if git_marker.is_file():
        try:
            content = git_marker.read_text()
        except OSError:
            return None
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("gitdir:"):
                gitdir_str = stripped.split(":", 1)[1].strip()
                gitdir = Path(gitdir_str)
                if not gitdir.is_absolute():
                    gitdir = (git_root / gitdir).resolve()
                return gitdir
    return None


def _detect_linked_worktree(repo_path: Path) -> Path | None:
    """Return the real gitdir if ``repo_path`` is a linked worktree (or
    submodule, same shape), else None.

    Used in ``run_setup`` to print a one-line heads-up so a user surveying
    the wizard output understands that hooks land under the real gitdir,
    not the working-tree-local ``.git`` (which is a pointer file, not a
    directory). The per-worktree setup model is intentional under v0.14.x —
    each worktree gets its own hooks; the v0.15.0 Ledger Locator (#368)
    will share the ledger across worktrees while keeping hooks per-worktree.
    """
    git_root = _find_git_root(repo_path)
    if git_root is None:
        return None
    git_marker = git_root / ".git"
    if not git_marker.is_file():
        return None
    return _resolve_git_pointer(repo_path)


def _probe_origin_head(repo_path: Path) -> str | None:
    """Probe ``git symbolic-ref refs/remotes/origin/HEAD`` for the remote
    default branch name.

    Returns the bare branch name (e.g. ``"main"``, ``"master"``, ``"trunk"``)
    or None if the ref isn't set (fresh clones, self-hosted remotes, repos
    without an ``origin`` remote). The ledger's runtime detector
    (``code_locator_runtime.detect_authoritative_ref``) silently falls back
    to ``"main"`` when this ref is missing, which is wrong for any project
    whose default branch is something else. The setup wizard surfaces this
    so the user can pin ``BICAMERAL_AUTHORITATIVE_REF`` once.
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "symbolic-ref", "refs/remotes/origin/HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    out = (result.stdout or "").strip()
    if "/" not in out:
        return None
    branch = out.rsplit("/", 1)[-1]
    return branch or None


def _resolve_authoritative_ref(repo_path: Path) -> tuple[str, bool]:
    """Return ``(branch, needs_env_override)`` for the project's default branch.

    Resolution order:
      1. ``BICAMERAL_AUTHORITATIVE_REF`` env (caller already pinned it):
         honour it; no env override needed in the written config.
      2. Probe ``origin/HEAD``; if it resolves, use that and skip override.
      3. Interactive prompt (default ``main``); only write the env override
         when the answer is non-default.
      4. Non-interactive fallback: ``main``, no override.

    The override is only load-bearing when probe (2) fails *and* the
    project's default branch is not ``main`` — otherwise the runtime
    detector already falls back to ``main``.
    """
    explicit = os.environ.get("BICAMERAL_AUTHORITATIVE_REF", "").strip()
    if explicit:
        return explicit, False

    probed = _probe_origin_head(repo_path)
    if probed:
        return probed, False

    if not _is_interactive():
        return "main", False

    print()
    print("  Couldn't auto-detect authoritative branch (no `origin/HEAD` ref).")
    raw = input("  What's your default branch? [main]: ").strip()
    branch = raw or "main"
    needs_override = branch != "main"
    return branch, needs_override


def _detect_agents() -> list[str]:
    """Auto-detect which coding agents are available."""
    found = []
    if shutil.which("claude"):
        found.append("claude")
    if shutil.which("cursor"):
        found.append("cursor")
    if shutil.which("codex"):
        found.append("codex")
    return found


def _is_interactive() -> bool:
    """Check if stdin is a terminal (not piped)."""
    import sys

    return sys.stdin.isatty()


def _select_agents() -> list[str]:
    """Prompt user to select coding agents."""
    import questionary

    detected = _detect_agents()

    # Non-interactive: auto-install for all detected (or claude as default)
    if not _is_interactive():
        if detected:
            names = ", ".join(AGENTS[a]["name"] for a in detected)
            print(f"  Auto-detected: {names}")
            return detected
        return ["claude"]

    all_keys = list(AGENTS.keys())
    choices = [
        questionary.Choice(
            title=f"{AGENTS[k]['name']}{' (detected)' if k in detected else ''}",
            value=k,
            checked=k in detected or (not detected and k == "claude"),
        )
        for k in all_keys
    ]

    selected = questionary.checkbox(
        "Select coding agents to configure:",
        choices=choices,
    ).ask()

    if not selected:
        return detected or ["claude"]
    return selected


class RunnerNotFoundError(RuntimeError):
    """Raised when no viable runner for bicameral-mcp is on PATH.

    There is no `bicameral_mcp` package — the entry point is `server:cli_main` —
    so `python -m bicameral_mcp` is not a valid fallback.
    """


def _detect_runner() -> tuple[str, list[str]]:
    """Detect the best available runner for bicameral-mcp.

    Only one runner is supported: the `bicameral-mcp` script installed by
    `pip install bicameral-mcp` (or an editable install in a venv). pipx run
    is intentionally NOT used: it downloads a fresh ephemeral copy from PyPI
    on every server start, missing local-only modules and risking version skew.

    The previous `python -m bicameral_mcp` fallback was removed because there
    is no `bicameral_mcp` package; the resulting MCP config was non-functional.
    """
    if shutil.which("bicameral-mcp"):
        return ("bicameral-mcp", [])
    raise RunnerNotFoundError(
        "No runner found for bicameral-mcp. Install with: pip install bicameral-mcp"
    )


def _build_config(
    repo_path: Path,
    data_path: Path | None = None,
    mode: str = "solo",
    telemetry: bool = False,
    authoritative_ref: str | None = None,
) -> dict:
    """Build the MCP server config object.

    data_path: where .bicameral/ history lives.  Defaults to repo_path.
    Keeping data_path separate lets history live in a private parent repo
    while REPO_PATH points to the public code repo.

    In team mode, local DBs go under .bicameral/local/ (gitignored)
    so they don't leak into the tracked events directory.

    authoritative_ref: when set, written into the config env as
    ``BICAMERAL_AUTHORITATIVE_REF`` so the runtime detector pins the
    project's default branch even when ``origin/HEAD`` isn't available.
    Pass None to let runtime auto-detection handle it (the common case
    when origin/HEAD resolves cleanly).
    """
    command, args = _detect_runner()
    data_root = (data_path or repo_path) / ".bicameral"
    data_root.mkdir(parents=True, exist_ok=True)

    if mode == "team":
        local_dir = data_root / "local"
        local_dir.mkdir(parents=True, exist_ok=True)
    else:
        local_dir = data_root

    env: dict[str, str] = {
        "REPO_PATH": str(repo_path),
        "SURREAL_URL": f"surrealkv://{local_dir / 'ledger.db'}",
        "CODE_LOCATOR_SQLITE_DB": str(local_dir / "code-graph.db"),
        "BICAMERAL_TELEMETRY": "1" if telemetry else "0",
    }
    if data_path is not None and data_path.resolve() != repo_path.resolve():
        # History lives in a separate private repo — tell the adapter where
        # to read/write events and config.
        env["BICAMERAL_DATA_PATH"] = str(data_path)
    if authoritative_ref:
        env["BICAMERAL_AUTHORITATIVE_REF"] = authoritative_ref

    return {"command": command, "args": args, "env": env}


def _write_json_config(
    repo_path: Path,
    config_path: Path,
    data_path: Path | None = None,
    mode: str = "solo",
    telemetry: bool = False,
    authoritative_ref: str | None = None,
) -> None:
    """Write MCP server config to a JSON file (Claude Code / Cursor)."""
    config = _build_config(
        repo_path,
        data_path=data_path,
        mode=mode,
        telemetry=telemetry,
        authoritative_ref=authoritative_ref,
    )
    config_path.parent.mkdir(parents=True, exist_ok=True)

    existing = {}
    if config_path.exists():
        try:
            existing = json.loads(config_path.read_text())
        except (json.JSONDecodeError, OSError):
            existing = {}

    existing.setdefault("mcpServers", {})["bicameral"] = config
    config_path.write_text(json.dumps(existing, indent=2) + "\n")


def _write_toml_config(
    repo_path: Path,
    config_path: Path,
    data_path: Path | None = None,
    mode: str = "solo",
    telemetry: bool = False,
    authoritative_ref: str | None = None,
) -> None:
    """Write MCP server config to a TOML file (Codex)."""
    config = _build_config(
        repo_path,
        data_path=data_path,
        mode=mode,
        telemetry=telemetry,
        authoritative_ref=authoritative_ref,
    )
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Build the [mcp_servers.bicameral] TOML section
    lines = []

    # Read existing content, strip old bicameral section if present
    if config_path.exists():
        existing = config_path.read_text()
        in_bicameral = False
        for line in existing.splitlines():
            if line.strip() == "[mcp_servers.bicameral]":
                in_bicameral = True
                continue
            if in_bicameral and line.startswith("["):
                in_bicameral = False
            if not in_bicameral:
                lines.append(line)
    # Remove trailing blank lines
    while lines and not lines[-1].strip():
        lines.pop()

    # Append the bicameral section
    if lines:
        lines.append("")
    lines.append("[mcp_servers.bicameral]")
    lines.append(f'command = "{config["command"]}"')

    args_str = ", ".join(f'"{a}"' for a in config["args"])
    lines.append(f"args = [{args_str}]")

    env_parts = ", ".join(f'"{k}" = "{v}"' for k, v in config["env"].items())
    lines.append(f"env = {{ {env_parts} }}")
    lines.append("")

    config_path.write_text("\n".join(lines) + "\n")


def _install_for_agent(
    agent_key: str,
    repo_path: Path,
    data_path: Path | None = None,
    mode: str = "solo",
    telemetry: bool = False,
    authoritative_ref: str | None = None,
) -> bool:
    """Install MCP config for a specific coding agent."""
    agent = AGENTS[agent_key]
    config_path = agent["config_path"](repo_path)

    # For Claude Code, try CLI first
    if agent_key == "claude" and shutil.which("claude"):
        config = _build_config(
            repo_path,
            data_path=data_path,
            mode=mode,
            telemetry=telemetry,
            authoritative_ref=authoritative_ref,
        )
        config_json = json.dumps(config)
        subprocess.run(
            ["claude", "mcp", "remove", "bicameral", "--scope", "project"],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=str(repo_path),
        )
        result = subprocess.run(
            ["claude", "mcp", "add-json", "bicameral", "--scope", "project", config_json],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=str(repo_path),
        )
        if result.returncode == 0:
            print(f"  {agent['name']}: installed via CLI")
            return True

    # For Codex, try CLI first
    if agent_key == "codex" and shutil.which("codex"):
        config = _build_config(
            repo_path,
            data_path=data_path,
            mode=mode,
            telemetry=telemetry,
            authoritative_ref=authoritative_ref,
        )
        env_args = []
        for k, v in config["env"].items():
            env_args.extend(["--env", f"{k}={v}"])
        result = subprocess.run(
            ["codex", "mcp", "add", "bicameral"]
            + env_args
            + ["--"]
            + [config["command"]]
            + config["args"],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=str(repo_path),
        )
        if result.returncode == 0:
            print(f"  {agent['name']}: installed via CLI")
            return True

    # Fallback: write config file directly
    if agent.get("config_format") == "toml":
        _write_toml_config(
            repo_path,
            config_path,
            data_path=data_path,
            mode=mode,
            telemetry=telemetry,
            authoritative_ref=authoritative_ref,
        )
    else:
        _write_json_config(
            repo_path,
            config_path,
            data_path=data_path,
            mode=mode,
            telemetry=telemetry,
            authoritative_ref=authoritative_ref,
        )

    print(f"  {agent['name']}: wrote {config_path}")
    return True


def _session_end_command_for_platform(platform: str) -> str:
    """Return the SessionEnd hook command rendered for the target platform.

    POSIX shape (linux, darwin, anything not win32) uses bash conditional
    chaining with the ``[ -d ]`` / ``[ -z ]`` test idiom, the
    ``BICAMERAL_SESSION_END_RUNNING`` re-entrancy guard, and the
    ``python3`` interpreter (Ubuntu/Debian/RHEL/Fedora install
    ``python3`` by default; ``python`` is NOT a default symlink and
    requires ``python-is-python3`` or equivalent — so ``python3`` is
    the only reliable cross-distro choice).

    Windows shape uses cmd.exe ``if exist`` / ``if not defined``
    conditional and the ``python`` interpreter (Windows installers
    expose ``python`` and ``py`` but not ``python3``).
    """
    if platform == "win32":
        return (
            "if exist .bicameral if not defined BICAMERAL_SESSION_END_RUNNING "
            "(set BICAMERAL_SESSION_END_RUNNING=1 && "
            "python scripts\\hooks\\session_end_queue_writer.py)"
        )
    return (
        '[ -d .bicameral ] && [ -z "$BICAMERAL_SESSION_END_RUNNING" ] && '
        "BICAMERAL_SESSION_END_RUNNING=1 "
        "python3 scripts/hooks/session_end_queue_writer.py || true"
    )


def _session_start_command_for_platform(platform: str) -> str:
    """Return the SessionStart hook command for the target platform (#279
    Phase 1).

    The hook invokes ``bicameral-mcp sync-and-brief`` so the synthesized
    brief is injected into Claude's context BEFORE the first user prompt.
    Stderr is appended to ``~/.bicameral/hook-errors.log`` so failures
    surface in the operator's log without polluting the agent's context.

    The trailing ``exit 0`` (POSIX) / ``& exit 0`` (Windows) is mandatory:
    SessionStart MUST NEVER block session start. If the CLI fails for any
    reason — missing config, missing API key, network error — the
    operator's session still proceeds.
    """
    if platform == "win32":
        return (
            "if exist .bicameral "
            'bicameral-mcp sync-and-brief 2>>"%USERPROFILE%\\.bicameral\\hook-errors.log" & '
            "exit 0"
        )
    return (
        "[ -d .bicameral ] && "
        'bicameral-mcp sync-and-brief 2>>"${HOME}/.bicameral/hook-errors.log" || true; '
        "exit 0"
    )


def _build_session_start_command(platform: str | None = None) -> str:
    """Canonical SessionStart hook command (#279 Phase 1).

    Pinned by tests/test_sessionstart_hook_install.py. Cross-platform via
    sys.platform; explicit override exists for test rendering.
    """
    target = platform if platform is not None else sys.platform
    return _session_start_command_for_platform(target)


def _build_session_end_command(
    mcp_config_path: str | None = None,
    platform: str | None = None,
) -> str:
    """Canonical SessionEnd hook command (#156 pivot, #200 Phase 1 OS-aware).

    Replaces the prior ``claude -p '/bicameral-capture-corrections
    --auto-ingest'`` invocation, which spawned an empty subprocess that
    couldn't access the parent session's transcript — corrections
    silently failed to surface.

    The new shape pipes Claude Code's stdin envelope into a Python
    script that extracts ``transcript_path`` and copies it to the
    pending-transcripts queue at
    ``<repo>/.bicameral/pending-transcripts/<session_id>.jsonl``. The
    next session's preflight Step 3.5 (or capture-corrections Step 0)
    drains the queue and surfaces corrections with full ledger context.

    ``mcp_config_path`` is retained for signature stability with
    consumers that pass it through; the new hook doesn't use it (no
    claude subprocess to configure).

    ``platform`` defaults to ``sys.platform`` and selects between POSIX
    bash shape (linux/darwin) and cmd.exe shape (win32). Explicit
    ``platform`` arg is for test isolation and cross-platform install
    rendering when the wizard runs on a different host than the target.
    """
    target = platform if platform is not None else sys.platform
    return _session_end_command_for_platform(target)


# Canonical no-args form — what `_install_claude_hooks` writes to a fresh
# end-user's ``.claude/settings.json``. Re-derived from the helper so the
# function is the single source of truth.
_BICAMERAL_SESSION_END_COMMAND = _build_session_end_command()

# #279 Phase 1 — SessionStart hook command. Opt-in via the setup wizard.
# Stdout from the CLI becomes Claude's pre-session context envelope.
_BICAMERAL_SESSION_START_COMMAND = _build_session_start_command()

# Fires after every Bash tool use. When the command is a git write-op
# (commit / merge / pull / rebase --continue), emits a hookSpecificOutput
# envelope whose additionalContext nudges the agent to invoke
# /bicameral-sync — running the full link_commit → compliance check
# flow so status is authoritative immediately.
#
# Was a plain-stdout python -c one-liner. Per Claude Code 2.x hook docs
# (https://code.claude.com/docs/en/hooks), plain stdout from PostToolUse
# is dropped to the debug log — only UserPromptSubmit / UserPromptExpansion
# / SessionStart treat raw stdout as agent-visible context. Symptom: the
# agent committed but never followed through with link_commit because
# the reminder never reached the model. Console script writes the proper
# envelope; source: scripts/hooks/post_commit_sync_reminder.py.
_BICAMERAL_POST_COMMIT_COMMAND = "bicameral-mcp-post-commit-sync-reminder"

# UserPromptSubmit hook: deterministic regex over a verb list elevates
# bicameral.preflight above the agent's default tool-selection priority
# whenever a prompt indicates code-implementation intent. Console script
# is exposed via pyproject.toml [project.scripts] so it resolves on PATH
# regardless of cwd. Closes #146 for end-user installs (the dogfood path
# in the bicameral repo's own .claude/settings.json invokes the source
# file directly via python3).
_BICAMERAL_PREFLIGHT_REMINDER_COMMAND = "bicameral-mcp-preflight-reminder"

# PostToolUse hook scoped to the bicameral.preflight tool: when preflight
# surfaces ≥1 decision, prints a system-reminder templating the
# correction-capture loop (Step 5.6 of bicameral-preflight) so the agent
# reliably calls bicameral.ingest(source=agent_session) +
# bicameral.resolve_collision when the user's prompt contradicts a
# surfaced decision. Closes #154 for end-user installs (the dogfood path
# invokes the source file directly via python3).
_BICAMERAL_COLLISION_CAPTURE_REMINDER_COMMAND = "bicameral-mcp-collision-capture-reminder"
_BICAMERAL_PREFLIGHT_TOOL_NAME = "mcp__bicameral__bicameral_preflight"


def _install_claude_hooks(repo_path: Path) -> bool:
    """Merge bicameral hooks into the project-level .claude/settings.json.

    Installs four hooks:
    - PostToolUse/Bash: reminds the agent to call link_commit immediately
      after git write-ops (commit / merge / pull / rebase --continue).
    - PostToolUse/bicameral_preflight: reminds the agent to capture
      refinements via ingest(agent_session) + resolve_collision when
      preflight surfaces decisions that the user's prompt contradicts.
    - SessionEnd: writes the parent session's transcript to
      .bicameral/pending-transcripts/<session_id>.jsonl; the next session's
      preflight Step 3.5 / capture-corrections Step 0 drains the queue and
      surfaces uningested corrections (#156). Only fires when .bicameral/
      exists.
    - UserPromptSubmit: deterministic verb-list classifier injects a
      <system-reminder> elevating bicameral.preflight above the agent's
      default tool-selection priority on code-implementation prompts.

    Idempotent — safe to call on every setup run. Returns True if any new
    entry was written, False if all four were already present.
    """
    _verify_intended_writes(
        "claude:PostToolUse:Bash",
        "claude:PostToolUse:bicameral_preflight",
        "claude:SessionEnd",
        "claude:SessionStart",
        "claude:UserPromptSubmit",
    )
    settings_path = repo_path / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            existing = {}

    hooks = existing.setdefault("hooks", {})
    wrote_anything = False

    # ── PostToolUse / Bash — git write-op reminder ───────────────────
    post_tool_use: list = hooks.setdefault("PostToolUse", [])
    bash_entry = next((e for e in post_tool_use if e.get("matcher") == "Bash"), None)
    if bash_entry is None:
        bash_entry = {"matcher": "Bash", "hooks": []}
        post_tool_use.append(bash_entry)
    # Remove any stale bicameral hooks, then write the current command.
    old_hooks = bash_entry.get("hooks", [])
    non_bic = [h for h in old_hooks if "bicameral" not in h.get("command", "")]
    new_post_hook = {"type": "command", "command": _BICAMERAL_POST_COMMIT_COMMAND}
    if non_bic != old_hooks or new_post_hook not in old_hooks:
        bash_entry["hooks"] = non_bic + [new_post_hook]
        wrote_anything = True

    # ── PostToolUse / bicameral_preflight — collision capture reminder ─
    preflight_entry = next(
        (e for e in post_tool_use if e.get("matcher") == _BICAMERAL_PREFLIGHT_TOOL_NAME),
        None,
    )
    if preflight_entry is None:
        preflight_entry = {"matcher": _BICAMERAL_PREFLIGHT_TOOL_NAME, "hooks": []}
        post_tool_use.append(preflight_entry)
    old_pre_hooks = preflight_entry.get("hooks", [])
    non_bic_pre = [
        h
        for h in old_pre_hooks
        if "bicameral" not in h.get("command", "")
        and "post_preflight_capture_reminder" not in h.get("command", "")
    ]
    new_pre_hook = {
        "type": "command",
        "command": _BICAMERAL_COLLISION_CAPTURE_REMINDER_COMMAND,
    }
    if non_bic_pre != old_pre_hooks or new_pre_hook not in old_pre_hooks:
        preflight_entry["hooks"] = non_bic_pre + [new_pre_hook]
        wrote_anything = True

    # ── SessionEnd — capture uningested corrections ──────────────────
    session_end: list = hooks.setdefault("SessionEnd", [])
    # Remove any stale bicameral SessionEnd entries, then write current.
    non_bic_se = [
        e
        for e in session_end
        if not any("bicameral" in h.get("command", "") for h in e.get("hooks", []))
    ]
    new_se_entry = {"hooks": [{"type": "command", "command": _BICAMERAL_SESSION_END_COMMAND}]}
    if non_bic_se != session_end or new_se_entry not in session_end:
        hooks["SessionEnd"] = non_bic_se + [new_se_entry]
        wrote_anything = True

    # ── SessionStart — pull-based meeting ingestion brief (#279) ────────
    # Auto-runs `bicameral-mcp sync-and-brief` and injects the resulting
    # markdown brief into Claude's pre-session context.
    # MUST NEVER block session start — the command ends with `exit 0`.
    session_start: list = hooks.setdefault("SessionStart", [])
    non_bic_ss = [
        e
        for e in session_start
        if not any(
            "bicameral" in h.get("command", "") or "sync-and-brief" in h.get("command", "")
            for h in e.get("hooks", [])
        )
    ]
    new_ss_entry = {"hooks": [{"type": "command", "command": _BICAMERAL_SESSION_START_COMMAND}]}
    if non_bic_ss != session_start or new_ss_entry not in session_start:
        hooks["SessionStart"] = non_bic_ss + [new_ss_entry]
        wrote_anything = True

    # ── UserPromptSubmit — preflight auto-fire reinforcement ─────────
    user_prompt_submit: list = hooks.setdefault("UserPromptSubmit", [])
    non_bic_ups = [
        e
        for e in user_prompt_submit
        if not any(
            "bicameral" in h.get("command", "") or "preflight_reminder" in h.get("command", "")
            for h in e.get("hooks", [])
        )
    ]
    new_ups_entry = {
        "hooks": [{"type": "command", "command": _BICAMERAL_PREFLIGHT_REMINDER_COMMAND}]
    }
    if non_bic_ups != user_prompt_submit or new_ups_entry not in user_prompt_submit:
        hooks["UserPromptSubmit"] = non_bic_ups + [new_ups_entry]
        wrote_anything = True

    if wrote_anything:
        settings_path.write_text(json.dumps(existing, indent=2) + "\n")
    return wrote_anything


_GIT_POST_COMMIT_HOOK = """\
#!/bin/sh
# Bicameral MCP — post-commit hook (installed by bicameral-mcp setup, Guided mode)
# Syncs the decision ledger after every commit so drift status is current immediately.
# Loud-but-non-blocking failure: any stderr from link_commit is captured to
# ${HOME}/.bicameral/hook-errors.log and surfaced on stderr in the same commit.
# The `>` redirection truncates the log file each run, so successful commits
# auto-clear stale errors from prior failed runs. Always exits 0 — the commit
# itself never blocks on a sync hook failure (#124).
[ -d .bicameral ] && bicameral-mcp link_commit HEAD >/dev/null 2>"${HOME}/.bicameral/hook-errors.log"
[ -s "${HOME}/.bicameral/hook-errors.log" ] && echo "Bicameral post-commit hook failed; see ${HOME}/.bicameral/hook-errors.log" >&2
exit 0
"""


def _install_git_post_commit_hook(repo_path: Path) -> bool:
    """Install a git post-commit hook that calls bicameral-mcp link_commit HEAD.

    Only installed for Guided mode. Idempotent — if a hook already exists and
    already contains a bicameral call, leaves it untouched. If an existing hook
    lacks a bicameral call, appends one rather than overwriting.

    Returns True if anything was written.
    """
    _verify_intended_writes("git:post-commit")
    hooks_dir = _resolve_git_hooks_dir(repo_path)
    if hooks_dir is None:
        return False

    hook_path = hooks_dir / "post-commit"
    hook_path.parent.mkdir(parents=True, exist_ok=True)

    if hook_path.exists():
        existing = hook_path.read_text()
        if "bicameral" in existing:
            return False  # already present
        # Append to existing hook
        hook_path.write_text(existing.rstrip("\n") + "\n" + _GIT_POST_COMMIT_HOOK)
    else:
        hook_path.write_text(_GIT_POST_COMMIT_HOOK)

    hook_path.chmod(0o755)
    return True


_GIT_PRE_PUSH_HOOK = """\
#!/bin/sh
# Bicameral MCP — pre-push hook (installed by bicameral-mcp setup --with-push-hook, #48)
# Surfaces drift warnings before git push completes.
# Skips when no .bicameral/ ledger configured. Non-blocking by default;
# BICAMERAL_PUSH_HOOK_BLOCK=1 forces hard-block on drift.
[ -d .bicameral ] || exit 0
bicameral-mcp branch-scan
status=$?
if [ "$status" = "0" ]; then exit 0; fi
if [ -t 0 ]; then
    printf "Push anyway? [y/N] " >&2
    read -r answer </dev/tty
    case "$answer" in
        [yY]|[yY][eE][sS]) exit 0 ;;
        *) exit 1 ;;
    esac
fi
exit "$status"
"""


def _install_git_pre_push_hook(repo_path: Path) -> bool:
    """Install a git pre-push hook that calls bicameral-mcp branch-scan (#48).

    Opt-in via ``bicameral-mcp setup --with-push-hook``. Idempotent — if
    a hook already exists and already contains a bicameral call, leaves it
    untouched. If an existing hook lacks a bicameral call, appends one
    rather than overwriting.

    Returns True if anything was written.
    """
    _verify_intended_writes("git:pre-push")
    hooks_dir = _resolve_git_hooks_dir(repo_path)
    if hooks_dir is None:
        return False

    hook_path = hooks_dir / "pre-push"
    hook_path.parent.mkdir(parents=True, exist_ok=True)

    if hook_path.exists():
        existing = hook_path.read_text()
        if "bicameral" in existing:
            return False  # already present
        hook_path.write_text(existing.rstrip("\n") + "\n" + _GIT_PRE_PUSH_HOOK)
    else:
        hook_path.write_text(_GIT_PRE_PUSH_HOOK)

    hook_path.chmod(0o755)
    return True


# Authoritative list of bicameral MCP tools the wizard offers to
# pre-approve at install time. Excludes bicameral_reset (destructive —
# always prompts) and extract_symbols (no longer exposed as an MCP tool).
_BICAMERAL_ALLOW_TOOLS: list[str] = sorted(
    [
        "mcp__bicameral__bicameral_bind",
        "mcp__bicameral__bicameral_dashboard",
        "mcp__bicameral__bicameral_feedback",
        "mcp__bicameral__bicameral_history",
        "mcp__bicameral__bicameral_ingest",
        "mcp__bicameral__bicameral_judge_gaps",
        "mcp__bicameral__bicameral_link_commit",
        "mcp__bicameral__bicameral_preflight",
        "mcp__bicameral__bicameral_ratify",
        "mcp__bicameral__bicameral_resolve_collision",
        "mcp__bicameral__bicameral_resolve_compliance",
        "mcp__bicameral__bicameral_skill_begin",
        "mcp__bicameral__bicameral_skill_end",
        "mcp__bicameral__bicameral_update",
        "mcp__bicameral__bicameral_usage_summary",
        "mcp__bicameral__get_neighbors",
        "mcp__bicameral__validate_symbols",
    ]
)
_BICAMERAL_DENY_TOOLS: list[str] = ["mcp__bicameral__bicameral_reset"]


def _confirm_permissions_diff(
    settings_path: Path, new_allow: list[str], new_deny: list[str]
) -> bool:
    """Show the diff that would be written and ask y/N.

    Non-interactive runs (CI, scripted setup) auto-approve. Interactive
    runs default to "no" — explicit consent is required to write the
    allowlist, since it persists across every Claude Code session on the
    machine.
    """
    print()
    print("  Pre-approve bicameral MCP tools — about to write:")
    print(f"    {settings_path}")
    print()
    print("    permissions.allow += [")
    for t in new_allow:
        print(f'        "{t}",')
    print("    ]")
    if new_deny:
        print("    permissions.deny += [")
        for t in new_deny:
            print(f'        "{t}",')
        print("    ]")
    print()
    print("  Only the bicameral MCP tools above are pre-approved.")
    print("  Bash, Edit, Write, and every non-bicameral tool still prompt")
    print("  for permission every time — this wizard does not auto-approve")
    print("  any shell call or file write.")
    print()
    print("  This writes to your *user-level* ~/.claude/settings.json —")
    print("  the project .claude/settings.json is never touched, and you")
    print("  can revoke any line by editing the file above.")
    print()

    if not _is_interactive():
        return True

    raw = input("  Pre-approve these bicameral MCP tools? [y/N] ").strip().lower()
    return raw in ("y", "yes")


def _install_user_permissions_allowlist() -> bool:
    """Pre-approve bicameral MCP tools in ~/.claude/settings.json.

    Implements §1 of the v0 productization plan — moves the permission
    friction to install time so catch-up flows (pure-read ledger queries
    fired from a SessionStart brief) don't pop a prompt for every tool
    call. The user explicitly consents once; after that, only writes
    (Bash, Edit, Write) prompt.

    Scope discipline:
      - User-level only. Never writes to project .claude/settings.json —
        that file gets committed and dragging permission state into the
        repo pollutes every clone.
      - Bicameral MCP tools only. No Bash, no Read/Grep/Glob, no
        non-bicameral tools. Shell calls keep their per-invocation
        permission prompt.
      - bicameral_reset is deny-listed, not allow-listed. It wipes the
        ledger and must always prompt.

    Idempotent — re-running adds only entries the user is missing.
    Returns True if anything was written.
    """
    settings_path = Path.home() / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            existing = {}

    permissions = existing.setdefault("permissions", {})
    allow_list = permissions.get("allow")
    if not isinstance(allow_list, list):
        allow_list = []
        permissions["allow"] = allow_list
    deny_list = permissions.get("deny")
    if not isinstance(deny_list, list):
        deny_list = []
        permissions["deny"] = deny_list

    new_allow = [t for t in _BICAMERAL_ALLOW_TOOLS if t not in allow_list]
    new_deny = [t for t in _BICAMERAL_DENY_TOOLS if t not in deny_list]
    if not new_allow and not new_deny:
        print("  Permissions: bicameral MCP tools already pre-approved — no change")
        return False

    if not _confirm_permissions_diff(settings_path, new_allow, new_deny):
        print("  Permissions: skipped — settings.json untouched")
        return False

    allow_list.extend(new_allow)
    deny_list.extend(new_deny)
    settings_path.write_text(json.dumps(existing, indent=2) + "\n")
    print(f"  Permissions: pre-approved {len(new_allow)} bicameral MCP tool(s) in {settings_path}")
    if new_deny:
        print(
            f"               deny-listed {len(new_deny)} destructive tool(s) "
            "(reset will always prompt)"
        )
    return True


def _install_skills(repo_path: Path) -> int:
    """Copy skill definitions into .claude/skills/ in the target repo."""
    _verify_intended_skills_writes()
    skills_src = Path(__file__).parent / "skills"
    if not skills_src.exists():
        print(f"  WARNING: skill source not found at {skills_src}")
        print("  Skills were not installed. The wheel may have been built without skills/.")
        print("  Re-install bicameral-mcp from a recent release, or report this bug.")
        return 0

    skills_dst = repo_path / ".claude" / "skills"
    installed = 0

    for skill_dir in sorted(skills_src.iterdir()):
        if not skill_dir.is_dir():
            continue
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            continue

        dst_dir = skills_dst / skill_dir.name
        dst_dir.mkdir(parents=True, exist_ok=True)
        (dst_dir / "SKILL.md").write_text(skill_md.read_text())
        installed += 1

    return installed


def _select_collaboration_mode() -> str:
    """Prompt user for solo or team collaboration mode."""
    import questionary

    if not _is_interactive():
        return "team"

    result = questionary.select(
        "Collaboration mode:",
        choices=[
            questionary.Choice(
                "Team  — decisions shared via git (append-only event files)", value="team"
            ),
            questionary.Choice("Solo  — decisions stored locally", value="solo"),
        ],
        default="team",
    ).ask()

    return result if result is not None else "team"


# ── Team-mode backend wizard (#277) ─────────────────────────────────────


def _prompt_text_or_exit(message: str) -> str:
    """Prompt for free text; exit cleanly if the user aborts (Ctrl-C)."""
    import questionary

    answer = questionary.text(message).ask()
    if answer is None:
        sys.exit("Setup aborted.")
    return answer.strip()


def _prompt_yes_no(message: str, default: bool = False) -> bool:
    """Yes/no confirmation with explicit default. Default-No when in doubt."""
    import questionary

    answer = questionary.confirm(message, default=default).ask()
    return bool(answer) if answer is not None else default


def _extract_folder_id(raw: str) -> str:
    """Accept either a raw folder ID or a Drive folder URL."""
    raw = raw.strip()
    marker = "/folders/"
    if marker in raw:
        tail = raw.split(marker, 1)[1]
        return tail.split("?", 1)[0].split("/", 1)[0]
    return raw


def _resolved_signer(repo_path: Path) -> str:
    """The signer string the team will see in the JSONL substrate.

    Defaults to the privacy-positive `local-part-only` policy (see
    events/writer.py::_resolve_signer_email) — operator can override in
    config.yaml after setup.
    """
    from events.writer import _get_git_email, _resolve_signer_email

    return _resolve_signer_email(_get_git_email(str(repo_path)), mode="local-part-only")


# ── Colored security disclosure (#277, user request) ────────────────────
# Stays explicit about what Bicameral can and cannot see BEFORE we open the
# OAuth consent browser. Color rendered only when stdout is a TTY; falls
# back to plain text in pipes / CI / non-interactive contexts.

_ANSI_BOLD = "\033[1m"
_ANSI_GREEN = "\033[32m"
_ANSI_YELLOW = "\033[33m"
_ANSI_CYAN = "\033[36m"
_ANSI_RESET = "\033[0m"


def _color(s: str, code: str) -> str:
    """Wrap with ANSI color code only when stdout is a TTY."""
    if not sys.stdout.isatty():
        return s
    return f"{code}{s}{_ANSI_RESET}"


def _print_drive_security_disclosure() -> None:
    """Show the security model BEFORE the browser redirects to Google.

    Operator gets one last chance to read what Bicameral can and cannot see
    before granting Drive access. Required by team-mode setup UX (#277).
    """
    border = _color("─" * 72, _ANSI_CYAN)
    bold = _ANSI_BOLD if sys.stdout.isatty() else ""
    reset = _ANSI_RESET if sys.stdout.isatty() else ""

    print()
    print(border)
    print(_color("  About to open Google sign-in. Read this first:", _ANSI_BOLD))
    print(border)
    print()
    print(f"  {bold}What flows where{reset}")
    print(
        f"    {_color('•', _ANSI_GREEN)} Decision data (transcripts, payloads) flows your-CLI ↔ Google directly."
    )
    print("      Bicameral the company does NOT receive copies. No Bicameral server in the loop.")
    print(
        f"    {_color('•', _ANSI_GREEN)} Your OAuth token stays on your machine ({_color('~/.bicameral/google-drive-token.json', _ANSI_CYAN)}, mode 0600)."
    )
    print()
    print(f"  {bold}What the `drive.file` scope means for the rest of your Drive{reset}")
    print(
        f"    {_color('•', _ANSI_GREEN)} The Bicameral CLI on your machine can only touch files it creates"
    )
    print("      in the team folder. Your other Drive content (other folders, Google Docs,")
    print("      shared files) is invisible to the CLI — Google enforces this.")
    print()
    print(f"  {bold}What Bicameral the company CAN see (as the OAuth app publisher){reset}")
    print(
        f"    {_color('•', _ANSI_YELLOW)} Aggregate API request counts. {_color('Not contents.', _ANSI_BOLD)}"
    )
    print(
        f"    {_color('•', _ANSI_YELLOW)} OAuth consent records: which Google accounts authenticated, when."
    )
    print()
    print(f"  {bold}The trust dependency you're accepting{reset}")
    print("    Same as any OAuth tool (gh, gcloud, Notion, Slack desktop): you trust")
    print(
        "    that the open-source CLI behaves as advertised. Source: github.com/BicameralAI/bicameral-mcp"
    )
    print()
    print("  Full security model: docs/team-mode-setup.md")
    print(border)
    print()


def _select_team_backend(repo_path: Path) -> dict:
    """Top-level Create vs Join vs LocalFolder dispatch. Returns team config dict."""
    import questionary

    if not _is_interactive():
        return {}

    intent = questionary.select(
        "How do you want to set up the shared ledger?",
        choices=[
            questionary.Choice(
                "Create a new shared ledger (you become the founding member)",
                value="create",
            ),
            questionary.Choice(
                "Join an existing shared ledger (paste a folder ID from a teammate)",
                value="join",
            ),
            questionary.Choice(
                "Use a shared filesystem instead (NFS, Dropbox, syncthing) — advanced",
                value="local_folder",
            ),
        ],
        default="create",
    ).ask()
    if intent is None or intent == "create":
        return _create_shared_ledger_drive(repo_path)
    if intent == "join":
        return _join_shared_ledger_drive(repo_path)
    return _select_local_folder_backend()


def _create_shared_ledger_drive(repo_path: Path) -> dict:
    """Create branch — operator becomes the founding member."""
    from events.backends.google_drive import GoogleDriveAdapter

    _print_drive_security_disclosure()
    if not _prompt_yes_no("Open browser to grant Drive access?", default=True):
        sys.exit("Aborted. Re-run setup when you're ready to grant access.")
    adapter = GoogleDriveAdapter(folder_id=None, author=_resolved_signer(repo_path))
    adapter._credentials()  # runs OAuth, caches token
    repo_name = Path(repo_path).resolve().name
    folder_id = adapter.create_folder(name=f"bicameral-{repo_name}-ledger")
    print()
    print(f"  Created shared ledger folder: bicameral-{repo_name}-ledger")
    print(f"  Folder ID: {folder_id}")
    print(f"  URL: https://drive.google.com/drive/folders/{folder_id}")
    print()
    print("  Send this to your teammates so they can Join:")
    print(
        f'    "Share this folder with my teammate as Editor, then run `bicameral setup` '
        f'and paste this folder ID: {folder_id}"'
    )
    print()
    return {"backend": "google_drive", "folder_id": folder_id, "role": "founding_member"}


def _join_shared_ledger_drive(repo_path: Path) -> dict:
    """Join branch — verify access, confirm identity, then persist."""
    raw = _prompt_text_or_exit(
        "Paste the shared ledger folder ID (or full Drive URL) from your teammate:"
    )
    folder_id = _extract_folder_id(raw)

    from events.backends.google_drive import GoogleDriveAdapter

    _print_drive_security_disclosure()
    if not _prompt_yes_no("Open browser to grant Drive access?", default=True):
        sys.exit("Aborted. Re-run setup when you're ready to grant access.")

    adapter = GoogleDriveAdapter(folder_id=folder_id, author=_resolved_signer(repo_path))
    adapter._credentials()
    try:
        adapter.verify_access()
    except Exception as exc:
        sys.exit(f"\n  Cannot join shared ledger: {exc}")

    signer = _resolved_signer(repo_path)
    confirmed = _prompt_yes_no(
        f"You'll appear in the team ledger as `{signer}`. Continue?",
        default=False,
    )
    if not confirmed:
        sys.exit(
            "Aborted. Adjust signer_email_fallback in your config.yaml "
            "(redact | local-part-only | full) and re-run setup."
        )
    return {"backend": "google_drive", "folder_id": folder_id, "role": "member"}


def _select_local_folder_backend() -> dict:
    """Advanced branch — shared filesystem (NFS, Dropbox, syncthing)."""
    raw = _prompt_text_or_exit(
        "Path to the shared folder (must exist on every teammate's machine):"
    )
    p = Path(raw).expanduser().resolve()
    if not p.exists() or not os.access(p, os.W_OK):
        sys.exit(f"\n  Path not writable: {p}")
    return {"backend": "local_folder", "remote_root": str(p), "role": "member"}


def _select_guided_mode() -> bool:
    """Prompt user for guided-mode intensity."""
    import questionary

    if not _is_interactive():
        return True

    result = questionary.select(
        "Interaction intensity:",
        choices=[
            questionary.Choice(
                "Guided  — blocking hints + git post-commit hook (status updates after every commit)",
                value=True,
            ),
            questionary.Choice("Normal  — advisory hints only", value=False),
        ],
        default=True,
    ).ask()

    return result if result is not None else True


def _select_telemetry() -> bool:
    """Prompt user for anonymous telemetry consent and persist the choice.

    Shows the exact event schema before asking. On any answer (including
    non-interactive auto-yes), writes ``~/.bicameral/consent.json`` via
    consent.write_consent() so the in-server first-boot notice does not
    fire on next start.

    Hard-fails (raises) if the consent marker cannot be written — a "no"
    answer must never silently leave telemetry on.
    """
    import questionary

    from consent import write_consent

    print()
    print("  Anonymous telemetry — exact payload that would be sent:")
    print()
    print('    {"skill": "bicameral-ingest", "session_id": "<uuid>", "version": "0.5.3",')
    print('     "duration_ms": 4120, "errored": false,')
    print('     "diagnostic": {"decisions_ingested": 3}}')
    print()
    print("    No code. No decision text. No file paths. No personal data.")
    print("    Change anytime: BICAMERAL_TELEMETRY=0  (turns off all telemetry)")
    print("    Per-source control (#192): BICAMERAL_TELEMETRY=relay,preflight,raw")
    print()

    if not _is_interactive():
        write_consent(telemetry=True, via="wizard")
        return True

    result = questionary.select(
        "Enable anonymous telemetry?",
        choices=[
            questionary.Choice(
                "Yes  — share anonymous usage stats to improve Bicameral", value=True
            ),
            questionary.Choice("No   — keep telemetry off", value=False),
        ],
        default=True,
    ).ask()

    choice = result if result is not None else True
    write_consent(telemetry=choice, via="wizard")
    return choice


def _detect_install_channel() -> str:
    """Return ``"nightly"`` when the running package is a PEP 440 dev release.

    Why: a user who runs ``pipx install --pip-args=--pre bicameral-mcp`` (or
    ``uv tool install bicameral-mcp --prerelease=allow``) lands on a CalVer
    ``.devN`` build. Without this detection the wizard would hardcode
    ``channel: stable`` into ``.bicameral/config.yaml``, and
    ``bicameral.update`` would then compare that install against PyPI's stable
    ``info.version`` — which hides ``.devN`` by design — and silently never
    offer an upgrade, stranding nightly users on whatever build they happened
    to ``--pre`` install. See ``handlers/update.py:_fetch_latest_stable_from_pypi``.

    How to apply: called by ``_write_collaboration_config`` when its caller
    doesn't pin ``channel`` explicitly. Tests/internal callers can still pass
    a literal to override.
    """
    version = ""
    try:
        from importlib.metadata import version as _pkg_version

        version = _pkg_version("bicameral-mcp")
    except Exception:
        # Source-checkout install (no distribution metadata) — fall back to
        # reading pyproject.toml so a `python -m setup_wizard` from a dev
        # tree still detects the channel correctly.
        import re

        for candidate in (Path(__file__).parent, Path(__file__).parent.parent):
            toml = candidate / "pyproject.toml"
            if not toml.exists():
                continue
            m = re.search(r'^version\s*=\s*"([^"]+)"', toml.read_text(), re.MULTILINE)
            if m:
                version = m.group(1)
                break
    return "nightly" if ".dev" in version else "stable"


def _write_collaboration_config(
    data_path: Path,
    mode: str,
    guided: bool = False,
    telemetry: bool = False,
    team_backend: dict | None = None,
    channel: str | None = None,
) -> None:
    """Write .bicameral/config.yaml with collaboration mode, guided-mode, telemetry,
    signer-email fallback, and (optionally) the team-backend block.

    `signer_email_fallback` (#200 Phase 2) defaults to `local-part-only` —
    privacy-positive: preserves attribution prefix on session-originated
    ingests without leaking the full git user.email to the ledger / team-
    mode JSONL substrate. Modes: `redact` (strongest, no attribution),
    `local-part-only` (default), `full` (legacy verbatim email).

    `team_backend` (#277): when present, persists `team:` block with
    `backend`, `role`, and either `folder_id` (Drive) or `remote_root`
    (LocalFolder).

    `channel`: release channel for ``bicameral.update``. Defaults to
    auto-detect via ``_detect_install_channel()`` — a ``.devN`` install
    writes ``channel: nightly``, anything else writes ``channel: stable``.
    Tests pass an explicit value to lock behavior.
    """
    resolved_channel = channel if channel is not None else _detect_install_channel()
    config_path = data_path / ".bicameral" / "config.yaml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    base = (
        "# Bicameral configuration\n"
        f"mode: {mode}\n"
        f"guided: {'true' if guided else 'false'}\n"
        f"telemetry: {'true' if telemetry else 'false'}\n"
        f"channel: {resolved_channel}\n"
        "signer_email_fallback: local-part-only\n"
        "render_source_attribution: redacted\n"  # #209: privacy-positive default
    )
    if team_backend:
        team_lines = ["team:"]
        for key in ("backend", "folder_id", "remote_root", "role"):
            if key in team_backend:
                value = team_backend[key]
                team_lines.append(f"  {key}: {value}")
        base += "\n".join(team_lines) + "\n"
    config_path.write_text(base, encoding="utf-8")
    print(f"  Collaboration: {mode} mode")
    print(f"  Guided mode: {'on — blocking hints' if guided else 'off — advisory hints'}")
    print(f"  Telemetry: {'on — anonymous usage stats' if telemetry else 'off'}")
    if resolved_channel == "nightly":
        print(
            "  Release channel: nightly (auto-detected from .dev version — "
            "bicameral.update will track RECOMMENDED_NIGHTLY_VERSION on dev)"
        )
    else:
        print("  Release channel: stable")
    print("  Signer-email fallback: local-part-only (privacy-positive default)")
    print(
        "  Source-attribution rendering: redacted (privacy-positive default — "
        "names + dates replaced with placeholders; flip to `full` or `hidden` "
        "in config.yaml to change)"
    )
    print("  Preflight bypass tracking: enabled (writes ~/.bicameral/preflight_events.jsonl)")


def _patch_gitignore(path: Path, entries: list[str], comment: str) -> None:
    """Idempotently write bicameral entries into a .gitignore file.

    Removes any pre-existing bicameral block first to avoid stale entries
    when upgrading from solo→team or when data_path changes.
    """
    if path.exists():
        content = path.read_text()
        lines = content.splitlines()
        cleaned: list[str] = []
        skip_next_blank = False
        for line in lines:
            stripped = line.strip()
            if stripped in (".bicameral/", ".bicameral/local/"):
                skip_next_blank = True
                continue
            if stripped.startswith("# Bicameral MCP"):
                skip_next_blank = True
                continue
            if skip_next_blank and stripped == "":
                skip_next_blank = False
                continue
            skip_next_blank = False
            cleaned.append(line)
        while cleaned and not cleaned[-1].strip():
            cleaned.pop()
        content = "\n".join(cleaned)
        if content and not content.endswith("\n"):
            content += "\n"
        content += f"\n{comment}\n"
        for entry in entries:
            content += f"{entry}\n"
        path.write_text(content)
    else:
        path.write_text(f"{comment}\n" + "".join(f"{e}\n" for e in entries))


def _ensure_gitignore(
    data_path: Path,
    mode: str = "solo",
    repo_path: Path | None = None,
) -> None:
    """Configure .gitignore entries for the selected collaboration mode.

    data_path: where .bicameral/ history lives (events + local state).
    repo_path: the code repo being analyzed.  When it differs from data_path
               (history stored in a private parent), the public repo's
               .gitignore gets a blanket `.bicameral/` rule so stale local
               state from a prior setup can never slip into the public repo.

    Modes applied to data_path/.gitignore:
      team: `.bicameral/local/`  (events/ committed, local/ ignored)
      solo: `.bicameral/`        (whole dir ignored)
    """
    if mode == "team":
        data_entries = [".bicameral/local/"]
        data_comment = "# Bicameral MCP local data (team mode — events/ is committed)"
    else:
        data_entries = [".bicameral/"]
        data_comment = "# Bicameral MCP local data"

    _patch_gitignore(data_path / ".gitignore", data_entries, data_comment)
    print(f"  Updated {data_path}/.gitignore for {mode} mode")

    # When history lives in a separate repo, also guard the public code repo.
    if repo_path is not None and repo_path.resolve() != data_path.resolve():
        _patch_gitignore(
            repo_path / ".gitignore",
            [".bicameral/"],
            "# Bicameral MCP local data (history stored in parent repo)",
        )
        print(f"  Updated {repo_path}/.gitignore — .bicameral/ fully ignored (history in parent)")


def run_setup(
    repo_hint: str | None = None,
    history_hint: str | None = None,
    *,
    with_push_hook: bool = False,
) -> int:
    """Run the interactive setup wizard.

    ``with_push_hook`` (#48): when True, additionally install a
    ``.git/hooks/pre-push`` that surfaces drift warnings via
    ``bicameral-mcp branch-scan`` before push completes. Idempotent.
    """
    _ensure_utf8_stdout()
    print()
    print("  ┌─────────────────────────────────────────┐")
    print("  │  Bicameral MCP — Setup                   │")
    print("  │  Decision ledger for your codebase        │")
    print("  └─────────────────────────────────────────┘")
    print()

    # Step 1: Select repo
    repo_path = _detect_repo(repo_hint)
    print(f"\n  Repo: {repo_path}")

    # Step 1a: Linked-worktree / submodule heads-up (#368 stopgap). When
    # `.git` is a pointer file (worktree or submodule layout), hooks land
    # under the resolved gitdir, NOT under the working tree. The v0.14.6
    # fix made this work; v0.14.7 makes it visible. The v0.15.0 Ledger
    # Locator will share the ledger across worktrees; for now each
    # worktree needs its own setup run for its hooks.
    linked_gitdir = _detect_linked_worktree(repo_path)
    if linked_gitdir is not None:
        print(f"  Note: linked worktree / submodule detected → hooks → {linked_gitdir}/hooks/")
        print("        Re-run `bicameral-mcp setup` from each worktree to install its hooks.")

    # Step 1b: Optionally separate history storage (e.g. private parent repo)
    data_path = _detect_history_path(repo_path, history_hint)
    if data_path != repo_path:
        print(f"  History: {data_path}")

    # Step 1c: Pin authoritative branch when origin/HEAD isn't auto-detectable.
    # The runtime detector silently falls back to "main" — wrong for any
    # project whose default is master/trunk/develop. We surface the ambiguity
    # and write BICAMERAL_AUTHORITATIVE_REF into the config only when needed.
    auth_ref, auth_ref_needs_override = _resolve_authoritative_ref(repo_path)
    config_auth_ref: str | None = auth_ref if auth_ref_needs_override else None
    if auth_ref_needs_override:
        print(f"  Authoritative branch pinned: {auth_ref}")

    # Step 2: Select coding agents
    print()
    agents = _select_agents()

    # Step 3: Runner check
    try:
        _detect_runner()
    except RunnerNotFoundError as e:
        print(f"\n  ERROR: {e}")
        return 1

    # Step 4: Collaboration mode + guided intensity + telemetry + gitignore
    collab_mode = _select_collaboration_mode()
    guided = _select_guided_mode()
    telemetry = _select_telemetry()

    team_backend: dict | None = None
    if collab_mode == "team":
        # #277: Create vs Join vs LocalFolder dispatch for the shared ledger.
        team_backend = _select_team_backend(repo_path)

    _write_collaboration_config(
        data_path,
        collab_mode,
        guided=guided,
        telemetry=telemetry,
        team_backend=team_backend,
    )
    _ensure_gitignore(data_path, mode=collab_mode, repo_path=repo_path)

    if collab_mode == "team":
        events_dir = data_path / ".bicameral" / "events"
        events_dir.mkdir(parents=True, exist_ok=True)

    # Step 5: Install MCP config for each agent
    print()
    for agent_key in agents:
        _install_for_agent(
            agent_key,
            repo_path,
            data_path=data_path,
            mode=collab_mode,
            telemetry=telemetry,
            authoritative_ref=config_auth_ref,
        )

    # Step 6: Install skills + hooks (Claude Code only)
    if "claude" in agents:
        num_skills = _install_skills(repo_path)
        print(f"  Claude Code: installed {num_skills} skill(s) at {repo_path}/.claude/skills/")
        if _install_claude_hooks(repo_path):
            print(
                "  Claude Code: installed hooks → link_commit on commit · capture-corrections on session end"
            )
        # Step 6b — pre-approve bicameral MCP tools at user-level so
        # catch-up flows do not spam the user with permission prompts.
        # Only bicameral MCP tools; shell calls remain prompted.
        _install_user_permissions_allowlist()

    # Step 7: Git post-commit hook (Guided mode only)
    if guided:
        if _install_git_post_commit_hook(repo_path):
            print(
                "  Git: installed post-commit hook → bicameral-mcp link_commit HEAD after every commit"
            )
        else:
            print("  Git: post-commit hook already present — skipped")

    # Step 7b: Git pre-push hook (#48 — opt-in via --with-push-hook flag)
    if with_push_hook:
        if _install_git_pre_push_hook(repo_path):
            print("  Git: installed pre-push hook → bicameral-mcp branch-scan before every push")
        else:
            print("  Git: pre-push hook already present — skipped")

    # Summary
    agent_names = ", ".join(AGENTS[a]["name"] for a in agents)
    print(f"\n  Done! Bicameral MCP configured for: {agent_names}")
    print(f"  Repo: {repo_path}")
    if data_path != repo_path:
        print(f"  History: {data_path}")
    print()

    if "claude" in agents:
        print("  Claude Code slash commands:")
        print("    /bicameral-ingest     — ingest a transcript, Slack thread, or PRD")
        print("    /bicameral-preflight  — pre-flight: surface decisions before coding")
        print("    /bicameral-history    — list all tracked decisions by feature area")
        print("    /bicameral-dashboard  — open live decision dashboard in browser")
        print("    /bicameral-reset      — nuke and replay the ledger (emergency)")
        print()

    print("  Or just ask naturally:")
    print('    "What decisions have been made about authentication?"')
    print('    "Check this file for drifted decisions"')
    print()

    return 0


def run_config_wizard() -> int:
    """Interactive CLI wizard for editing bicameral config.yaml.

    Reads the current config, prompts for each setting via questionary,
    writes updated config.yaml, and reinstalls skills/hooks so changes
    take effect immediately.
    """
    import subprocess
    import sys

    try:
        import yaml
    except ImportError:
        import json as yaml  # fallback: won't write yaml but will read

    _ensure_utf8_stdout()
    print()
    print("  ┌─────────────────────────────────────────┐")
    print("  │  Bicameral MCP — Config                  │")
    print("  └─────────────────────────────────────────┘")
    print()

    repo_path = _detect_repo()
    config_path = repo_path / ".bicameral" / "config.yaml"

    # Read current values
    if config_path.exists():
        try:
            cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        except Exception:
            cfg = {}
    else:
        cfg = {}

    cur_mode = cfg.get("mode", "team")
    cur_guided = cfg.get("guided", True)
    cur_telemetry = cfg.get("telemetry", True)
    # Preserve the channel field across the config-wizard rewrite. Without
    # this, re-running `bicameral-mcp config` after the user opted into
    # nightly would silently drop `channel: nightly` and the rewrite would
    # default to stable — re-stranding nightly installs (the exact bug the
    # auto-detect in `_write_collaboration_config` fixed for fresh setups).
    cur_channel = cfg.get("channel") or _detect_install_channel()

    print(f"  Current config ({config_path}):")
    print(f"    mode:      {cur_mode}")
    print(f"    guided:    {cur_guided}")
    print(f"    telemetry: {cur_telemetry}")
    print(f"    channel:   {cur_channel}")
    print()

    new_mode = _select_collaboration_mode_with_default(cur_mode)
    new_guided = _select_guided_mode_with_default(cur_guided)
    new_telemetry = _select_telemetry_with_default(cur_telemetry)

    # Write updated config
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        "# Bicameral configuration\n"
        f"mode: {new_mode}\n"
        f"guided: {'true' if new_guided else 'false'}\n"
        f"telemetry: {'true' if new_telemetry else 'false'}\n"
        f"channel: {cur_channel}\n",
        encoding="utf-8",
    )

    # Reinstall skills and hooks via subprocess (avoids stale sys.modules)
    script = (
        "from setup_wizard import _install_skills, _install_claude_hooks"
        + (", _install_git_post_commit_hook" if new_guided else "")
        + "; from pathlib import Path; "
        f"rp = Path(r'{repo_path}'); "
        "n = _install_skills(rp); _install_claude_hooks(rp); "
        + ("_install_git_post_commit_hook(rp); " if new_guided else "")
        + "print(n)"
    )
    result = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True,
        text=True,
        timeout=30,
    )
    skills_n = int(result.stdout.strip() or "0") if result.returncode == 0 else 0

    print()
    print("  Config updated:")
    _print_change("mode", cur_mode, new_mode)
    _print_change("guided", cur_guided, new_guided)
    _print_change("telemetry", cur_telemetry, new_telemetry)
    print(f"  Skills reinstalled: {skills_n}")
    print(f"  Git post-commit hook: {'installed' if new_guided else 'not installed (Normal mode)'}")
    print()
    return 0


def _print_change(label: str, old, new) -> None:
    if old == new:
        print(f"    {label}: {new}  (unchanged)")
    else:
        print(f"    {label}: {old} → {new}")


def _select_collaboration_mode_with_default(current: str) -> str:
    import questionary

    if not _is_interactive():
        return current
    choices = [
        questionary.Choice(
            "Team  — decisions shared via git (append-only event files)", value="team"
        ),
        questionary.Choice("Solo  — decisions stored locally", value="solo"),
    ]
    result = questionary.select(
        "Collaboration mode:",
        choices=choices,
        default=next((c for c in choices if c.value == current), choices[0]),
    ).ask()
    return result if result is not None else current


def _select_guided_mode_with_default(current: bool) -> bool:
    import questionary

    if not _is_interactive():
        return current
    choices = [
        questionary.Choice("Guided  — blocking hints + git post-commit hook", value=True),
        questionary.Choice("Normal  — advisory hints only", value=False),
    ]
    result = questionary.select(
        "Interaction intensity:",
        choices=choices,
        default=next((c for c in choices if c.value == current), choices[0]),
    ).ask()
    return result if result is not None else current


def _select_telemetry_with_default(current: bool) -> bool:
    import questionary

    if not _is_interactive():
        return current
    choices = [
        questionary.Choice("Yes  — share anonymous usage stats to improve Bicameral", value=True),
        questionary.Choice("No   — keep telemetry off", value=False),
    ]
    result = questionary.select(
        "Anonymous telemetry:",
        choices=choices,
        default=next((c for c in choices if c.value == current), choices[0]),
    ).ask()
    return result if result is not None else current


def run_reset_wizard() -> int:
    """Interactive CLI wizard for bicameral.reset.

    Asks the user which wipe mode they want, shows a dry-run summary,
    then asks for explicit confirmation before wiping.
    """
    import asyncio

    import questionary

    _ensure_utf8_stdout()
    print()
    print("  ┌─────────────────────────────────────────┐")
    print("  │  Bicameral MCP — Reset                   │")
    print("  └─────────────────────────────────────────┘")
    print()

    # Step 1: choose mode
    wipe_mode = questionary.select(
        "What do you want to reset?",
        choices=[
            questionary.Choice(
                "Ledger only  — wipe materialized DB rows, keep config and event files (safe default)",
                value="ledger",
            ),
            questionary.Choice(
                "Full reset   — delete the entire .bicameral/ directory including config and event history (nuclear)",
                value="full",
            ),
        ],
    ).ask()

    if wipe_mode is None:
        print("  Cancelled.")
        return 0

    # Step 2: dry-run
    import os

    from context import BicameralContext
    from handlers.reset import handle_reset

    repo_path = os.environ.get("REPO_PATH", ".")
    os.environ["REPO_PATH"] = repo_path
    ctx = BicameralContext.from_env()

    print()
    print("  Running dry-run…")
    dry = asyncio.run(handle_reset(ctx, confirm=False, wipe_mode=wipe_mode))

    print()
    print(f"  Wipe mode    : {dry.wipe_mode}")
    print(f"  Cursors      : {dry.cursors_before} source_cursor row(s) would be wiped")
    if dry.wipe_mode == "full" and dry.bicameral_dir:
        print(f"  Directory    : {dry.bicameral_dir}")
        print()
        print("  ⚠️  WARNING: this will delete the entire .bicameral/ directory,")
        print("     including config.yaml and all team event history. There is no undo.")

    if dry.replay_plan:
        print()
        print("  Replay plan (re-ingest these after reset):")
        for entry in dry.replay_plan:
            print(f"    {entry.source_type}  {entry.source_scope}  →  {entry.last_source_ref}")
    else:
        print("  Replay plan  : empty — nothing to re-ingest")

    # Step 3: confirm
    print()
    confirm_label = "yes, full reset" if wipe_mode == "full" else "yes, reset"
    confirmed = questionary.confirm(
        f"Proceed? (type '{confirm_label}' to confirm)",
        default=False,
    ).ask()

    if not confirmed:
        print()
        print("  Cancelled — nothing was wiped.")
        return 0

    # Step 4: wipe
    print()
    print("  Wiping…")
    result = asyncio.run(handle_reset(ctx, confirm=True, wipe_mode=wipe_mode))

    if result.wiped:
        print(f"  Done. {result.cursors_before} cursor(s) wiped.")
        if result.replay_plan:
            print("  Re-ingest the sources listed above to restore the ledger.")
    else:
        print("  Wipe did not complete — check the error above.")

    print()
    return 0
