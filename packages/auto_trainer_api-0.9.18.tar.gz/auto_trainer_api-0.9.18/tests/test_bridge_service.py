import asyncio
import threading

from autotrainer.api.bridge import bridge_service
from autotrainer.api.bridge.bridge_service import BridgeService
from autotrainer.api.command import ApiCommandRequest, ApiCommandRequestResult
from autotrainer.api.command.api_command import ApiCommand


def create_uninitialized_bridge() -> BridgeService:
    bridge = BridgeService.__new__(BridgeService)
    bridge._command_timeout = 0.01
    bridge._pending_commands = {}
    bridge._answered_nonces = {}
    bridge._pending_lock = threading.Lock()
    bridge._client_sid = None
    bridge._sio = object()
    bridge._loop = object()
    return bridge


class TestBridgeServiceClientTracking:
    def test_command_request_without_socketio_client_returns_unavailable(self):
        bridge = create_uninitialized_bridge()
        request = ApiCommandRequest(command=ApiCommand.GET_STATUS, nonce=1)

        response = bridge._respond_to_command_request(request)

        assert response.result == ApiCommandRequestResult.UNAVAILABLE
        assert response.error_message == "No Socket.IO client connected."

    def test_latest_client_wins_and_only_disconnects_active_client(self):
        bridge = create_uninitialized_bridge()

        assert asyncio.run(bridge.handle_connect("first"))

        event = threading.Event()
        response_holder = []
        bridge._pending_commands[1] = (event, response_holder)

        assert asyncio.run(bridge.handle_connect("second"))
        assert event.is_set()
        assert response_holder[0].result == ApiCommandRequestResult.FAILED
        assert response_holder[0].error_message == "Socket.IO client replaced."

        event = threading.Event()
        response_holder = []
        bridge._pending_commands[2] = (event, response_holder)

        asyncio.run(bridge.handle_disconnect("first"))
        assert not event.is_set()

        asyncio.run(bridge.handle_disconnect("second"))
        assert event.is_set()
        assert response_holder[0].result == ApiCommandRequestResult.FAILED
        assert response_holder[0].error_message == "Socket.IO client disconnected."

    def test_late_response_for_replaced_client_is_discarded(self):
        bridge = create_uninitialized_bridge()
        asyncio.run(bridge.handle_connect("first"))

        event = threading.Event()
        response_holder = []
        bridge._pending_commands[1] = (event, response_holder)

        asyncio.run(bridge.handle_connect("second"))
        asyncio.run(
            bridge.handle_command_result(
                "first",
                {"nonce": 1, "result": ApiCommandRequestResult.SUCCESS},
            )
        )

        assert len(response_holder) == 1
        assert response_holder[0].result == ApiCommandRequestResult.FAILED


class TestBridgeServiceCommandResult:
    def test_malformed_command_value_still_releases_pending_command(self):
        bridge = create_uninitialized_bridge()
        event = threading.Event()
        response_holder = []
        bridge._pending_commands[1] = (event, response_holder)

        asyncio.run(
            bridge.handle_command_result(
                "client",
                {"nonce": 1, "result": ApiCommandRequestResult.SUCCESS, "command": []},
            )
        )

        assert event.is_set()
        assert response_holder[0].result == ApiCommandRequestResult.SUCCESS
        assert response_holder[0].command == ApiCommand.NONE

    def test_command_response_timeout_returns_failed_and_discards_late_result(self, monkeypatch):
        class Future:
            def result(self, timeout):
                return None

        class SocketIo:
            async def emit(self, *args, **kwargs):
                return None

        def run_coroutine_threadsafe(coro, loop):
            coro.close()
            return Future()

        monkeypatch.setattr(bridge_service.asyncio, "run_coroutine_threadsafe", run_coroutine_threadsafe)

        bridge = create_uninitialized_bridge()
        bridge._sio = SocketIo()
        bridge._loop = object()
        bridge._client_sid = "client"

        response = bridge._respond_to_command_request(ApiCommandRequest(command=ApiCommand.GET_STATUS, nonce=7))

        assert response.result == ApiCommandRequestResult.FAILED
        assert response.error_message == "Timeout waiting for Socket.IO client response."
        assert bridge._pending_commands == {}
        assert 7 in bridge._answered_nonces

        asyncio.run(
            bridge.handle_command_result(
                "client",
                {"nonce": 7, "result": ApiCommandRequestResult.SUCCESS},
            )
        )

        assert bridge._pending_commands == {}
        assert 7 not in bridge._answered_nonces

    def test_expired_answered_nonce_does_not_suppress_late_result(self, monkeypatch):
        bridge = create_uninitialized_bridge()
        event = threading.Event()
        response_holder = []
        bridge._pending_commands[8] = (event, response_holder)
        bridge._answered_nonces[8] = 0.0

        monkeypatch.setattr(bridge_service.time, "monotonic", lambda: bridge_service.ANSWERED_NONCE_TTL_SECONDS + 1)

        asyncio.run(
            bridge.handle_command_result(
                "client",
                {"nonce": 8, "result": ApiCommandRequestResult.SUCCESS},
            )
        )

        assert event.is_set()
        assert response_holder[0].result == ApiCommandRequestResult.SUCCESS
        assert 8 not in bridge._answered_nonces
