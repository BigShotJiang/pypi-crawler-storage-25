from datetime import datetime

from autotrainer.api.api_event import ApiEvent
from autotrainer.api.api_event_kind import ApiEventKind


class TestApiEventIsSame:
    """Verify ApiEvent.is_same() compares kind and context, ignoring when/index/repeat."""

    def test_same_kind_and_context(self):
        a = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 1, 1), index=100, context={"reason": "user"})
        b = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 6, 15), index=999, context={"reason": "user"})
        assert a.is_same(b)

    def test_same_kind_no_context(self):
        a = ApiEvent(kind=ApiEventKind.applicationLaunched, when=datetime(2024, 1, 1), index=1)
        b = ApiEvent(kind=ApiEventKind.applicationLaunched, when=datetime(2024, 2, 2), index=2)
        assert a.is_same(b)

    def test_different_kind(self):
        a = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 1, 1), index=1, context={"reason": "user"})
        b = ApiEvent(kind=ApiEventKind.emergencyResume, when=datetime(2024, 1, 1), index=1, context={"reason": "user"})
        assert not a.is_same(b)

    def test_different_context(self):
        a = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 1, 1), index=1, context={"reason": "user"})
        b = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 1, 1), index=1, context={"reason": "system"})
        assert not a.is_same(b)

    def test_none_vs_present_context(self):
        a = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 1, 1), index=1, context=None)
        b = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 1, 1), index=1, context={"reason": "user"})
        assert not a.is_same(b)

    def test_none_argument_returns_false(self):
        a = ApiEvent(kind=ApiEventKind.emergencyStop, when=datetime(2024, 1, 1), index=1)
        assert not a.is_same(None)

    def test_different_repeat_still_same(self):
        a = ApiEvent(kind=ApiEventKind.trialStarted, when=datetime(2024, 1, 1), index=1, repeat=0)
        b = ApiEvent(kind=ApiEventKind.trialStarted, when=datetime(2024, 1, 1), index=1, repeat=5)
        assert a.is_same(b)
