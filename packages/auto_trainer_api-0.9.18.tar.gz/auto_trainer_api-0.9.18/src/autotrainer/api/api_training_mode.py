from enum import IntEnum


class ApiTrainingMode(IntEnum):
    UNDEFINED = 0
    MANUAL = 100
    MANUAL_WITH_PROTOCOL = 200
    AUTOMATIC = 300
