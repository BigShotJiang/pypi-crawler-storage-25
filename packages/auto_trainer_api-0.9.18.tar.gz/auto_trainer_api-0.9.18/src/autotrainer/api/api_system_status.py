from dataclasses import dataclass
from typing import List, Optional

from .api_application_mode import ApiApplicationMode
from .api_alarm_kind import ApiAlarmKind
from .api_detector_kind import ApiDetectorKind
from .api_training_mode import ApiTrainingMode


@dataclass(frozen=True)
class ApiProjectStatus:
    day_path: str  # Absolute path to the current day's directory (currently `location` out of get_day_path())
    session_index: int  # Current session index


@dataclass(frozen=True)
class ApiDetectorStatus:
    detector_id: ApiDetectorKind
    is_active: bool
    is_enabled: bool


@dataclass(frozen=True)
class ApiAlarmStatus:
    alarm_id: ApiAlarmKind
    is_active: bool
    is_enabled: bool
    is_auto_resume_enabled: bool = False
    is_stop_condition: bool = False


@dataclass(frozen=True)
class ApiTunnelDeviceStatus:
    magnet_intensity: float
    gate_open: bool = False


@dataclass(frozen=True)
class ApiPelletDeviceStatus:
    dcs_send_x: float
    dcs_send_y: float
    dcs_send_z: float

    dcs_x: float = 0.0
    dcs_y: float = 0.0
    dcs_z: float = 0.0

    load_arm: float = 0.0
    barrier_arm: float = 0.0

@dataclass(frozen=True)
class ApiReachStatus:
    pellets_presented: int = 0.0
    pellets_consumed: int = 0.0
    reaches: int = 0.0
    successful_reaches: int = 0.0

@dataclass(frozen=True)
class ApiBehaviorStatus:
    baseline_magnet_intensity: float
    reaches: ApiReachStatus


@dataclass(frozen=True)
class ApiSystemStatus:
    application_mode: ApiApplicationMode
    training_mode: ApiTrainingMode

    animal_id: Optional[str]

    project: ApiProjectStatus

    alarms: List[ApiAlarmStatus]
    detectors: List[ApiDetectorStatus]

    pellet_device: ApiPelletDeviceStatus
    tunnel_device: ApiTunnelDeviceStatus

    behavior: ApiBehaviorStatus
