import argparse
import logging

import uvicorn

from autotrainer.api.bridge import create_bridge_app

parser = argparse.ArgumentParser(description="Auto-Trainer Socket.IO Bridge")
parser.add_argument("--port", type=int, default=8000, help="Port to listen on (default: 8000)")
parser.add_argument("--host", default="0.0.0.0", help="Host to bind to (default: 0.0.0.0)")
args = parser.parse_args()

logging.basicConfig(level=logging.INFO)

app = create_bridge_app()
uvicorn.run(app, host=args.host, port=args.port)
