import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Optional

import socketio
from fastapi import FastAPI

from ..api_options import ApiOptions
from .bridge_service import BridgeService, COMMAND_RESPONSE_TIMEOUT_SECONDS

logger = logging.getLogger(__name__)


def create_bridge_app(
    options: Optional[ApiOptions] = None,
    command_timeout: float = COMMAND_RESPONSE_TIMEOUT_SECONDS,
    cors_allowed_origins=None,
):
    bridge = BridgeService(options=options, command_timeout=command_timeout)

    if cors_allowed_origins is None:
        cors_allowed_origins = "*"

    sio = socketio.AsyncServer(async_mode="asgi", cors_allowed_origins=cors_allowed_origins)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        bridge.initialize(sio, asyncio.get_running_loop())
        bridge.start()
        logger.info("Bridge service started.")
        yield
        bridge.stop()
        logger.info("Bridge service stopped.")

    fastapi_app = FastAPI(lifespan=lifespan)

    @fastapi_app.get("/health")
    async def health():
        return {"status": "ok"}

    @sio.event
    async def connect(sid, environ):
        if not await bridge.handle_connect(sid):
            return False

        logger.info("Socket.IO client connected: %s", sid)

    @sio.event
    async def disconnect(sid):
        logger.info("Socket.IO client disconnected: %s", sid)
        await bridge.handle_disconnect(sid)

    @sio.on("commandResult")
    async def command_result(sid, data):
        await bridge.handle_command_result(sid, data)

    @sio.on("sendApiEvent")
    async def send_api_event(sid, payload):
        await bridge.handle_send_api_event(sid, payload)

    return socketio.ASGIApp(sio, other_app=fastapi_app)
