import asyncio
import logging
import threading
import time
from dataclasses import asdict
from typing import Dict, Optional, Tuple

import humps

from .. import create_api_service

from ..api_options import ApiOptions, create_default_api_options
from ..command import ApiCommand, ApiCommandRequest, ApiCommandRequestResult, ApiCommandRequestResponse
from ..rpc_service import RpcService
from ..util import prepare_for_serialization

logger = logging.getLogger(__name__)

COMMAND_RESPONSE_TIMEOUT_SECONDS = 1.0
ANSWERED_NONCE_TTL_SECONDS = 5 * 60


class BridgeService:
    def __init__(
            self,
            options: Optional[ApiOptions] = None,
            command_timeout: float = COMMAND_RESPONSE_TIMEOUT_SECONDS,
    ):
        if options is None:
            options = create_default_api_options()

        service = create_api_service(options)

        if service is None:
            raise RuntimeError("RPC is disabled in the provided ApiOptions; bridge requires an active RPC service.")

        self._service: RpcService = service

        self._command_timeout = command_timeout
        self._pending_commands: Dict[int, Tuple[threading.Event, list]] = {}
        self._answered_nonces: Dict[int, float] = {}
        self._pending_lock = threading.Lock()
        self._client_sid: Optional[str] = None
        self._sio = None
        self._loop = None

    @property
    def service(self) -> RpcService:
        return self._service

    def initialize(self, sio, loop):
        self._sio = sio
        self._loop = loop

    def start(self):
        self._service.command_request_delegate = self._respond_to_command_request
        self._service.start()

    def stop(self):
        self._service.stop()

    # -- Command delegate (called on RPC thread) --

    def _respond_to_command_request(self, request: ApiCommandRequest) -> ApiCommandRequestResponse:
        sio = self._sio
        loop = self._loop

        if sio is None or loop is None:
            return ApiCommandRequestResponse(
                result=ApiCommandRequestResult.UNAVAILABLE,
                error_message="Bridge not fully initialized.",
            )

        # Serialize request to camelCase dict
        data = humps.camelize(prepare_for_serialization(asdict(request)))

        event = threading.Event()
        response_holder: list = []
        with self._pending_lock:
            client_sid = self._client_sid
            if client_sid is None:
                return ApiCommandRequestResponse(
                    result=ApiCommandRequestResult.UNAVAILABLE,
                    error_message="No Socket.IO client connected.",
                )
            self._pending_commands[request.nonce] = (event, response_holder)

        try:
            future = asyncio.run_coroutine_threadsafe(sio.emit("commandRequest", data, to=client_sid), loop)
            future.result(timeout=5.0)
        except Exception as ex:
            with self._pending_lock:
                self._pending_commands.pop(request.nonce, None)
            logger.error("Failed to emit commandRequest: %s", ex)
            return ApiCommandRequestResponse(
                result=ApiCommandRequestResult.FAILED,
                error_message="Failed to emit commandRequest to Socket.IO clients.",
            )

        if not event.wait(timeout=self._command_timeout):
            with self._pending_lock:
                if self._pending_commands.pop(request.nonce, None) is not None:
                    self._remember_answered_nonce(request.nonce)
            return ApiCommandRequestResponse(
                result=ApiCommandRequestResult.FAILED,
                error_message="Timeout waiting for Socket.IO client response.",
            )

        with self._pending_lock:
            self._pending_commands.pop(request.nonce, None)

        if not response_holder:
            return ApiCommandRequestResponse(
                result=ApiCommandRequestResult.FAILED,
                error_message="No response received from Socket.IO client.",
            )

        return response_holder[0]

    # -- Socket.IO event handlers (called on asyncio loop) --

    def _remember_answered_nonce(self, nonce: int):
        self._expire_answered_nonces()
        self._answered_nonces[nonce] = time.monotonic()

    def _expire_answered_nonces(self):
        cutoff = time.monotonic() - ANSWERED_NONCE_TTL_SECONDS
        expired = [nonce for nonce, answered_at in self._answered_nonces.items() if answered_at < cutoff]
        for nonce in expired:
            del self._answered_nonces[nonce]

    async def handle_connect(self, sid) -> bool:
        with self._pending_lock:
            previous_sid = self._client_sid
            if previous_sid is not None and previous_sid != sid:
                logger.info("Replacing Socket.IO client %s with %s.", previous_sid, sid)
                pending_items = list(self._pending_commands.items())
                self._pending_commands.clear()
                for nonce, _ in pending_items:
                    self._remember_answered_nonce(nonce)
            else:
                pending_items = []

            self._client_sid = sid

        for nonce, (event, response_holder) in pending_items:
            if not event.is_set():
                response_holder.append(
                    ApiCommandRequestResponse(
                        result=ApiCommandRequestResult.FAILED,
                        error_message="Socket.IO client replaced.",
                    )
                )
                event.set()

        return True

    async def handle_command_result(self, sid, data):
        try:
            obj = humps.decamelize(data)
            nonce = obj.get("nonce")
            if nonce is None:
                logger.warning("commandResult from %s missing nonce, discarding.", sid)
                return

            with self._pending_lock:
                self._expire_answered_nonces()
                if nonce in self._answered_nonces:
                    del self._answered_nonces[nonce]
                    logger.debug("commandResult for already answered nonce %d from %s, discarding.", nonce, sid)
                    return
                pending = self._pending_commands.get(nonce)
            if pending is None:
                logger.debug("commandResult for unknown/expired nonce %d from %s, discarding.", nonce, sid)
                return

            event, response_holder = pending

            result_val = obj.get("result", ApiCommandRequestResult.UNRECOGNIZED)
            try:
                result_val = ApiCommandRequestResult(result_val)
            except (TypeError, ValueError):
                result_val = ApiCommandRequestResult.UNRECOGNIZED

            command_val = obj.get("command", ApiCommand.NONE)
            try:
                if ApiCommand.is_member(command_val):
                    command_val = ApiCommand(command_val)
                else:
                    command_val = ApiCommand.NONE
            except TypeError:
                command_val = ApiCommand.NONE

            response = ApiCommandRequestResponse(
                result=result_val,
                data=obj.get("data"),
                error_code=obj.get("error_code", 0),
                error_message=obj.get("error_message"),
                command=command_val,
                nonce=nonce,
            )

            response_holder.append(response)
            event.set()
        except Exception:
            logger.exception("Error handling commandResult from %s", sid)

    async def handle_send_api_event(self, sid, payload):
        try:
            decamelized = humps.decamelize(payload)
            self._service.send_event_dict(decamelized)
        except Exception:
            logger.exception("Error handling sendApiEvent from %s", sid)

    async def handle_disconnect(self, sid):
        with self._pending_lock:
            if self._client_sid != sid:
                return

            self._client_sid = None
            pending_items = list(self._pending_commands.items())
            self._pending_commands.clear()
            for nonce, _ in pending_items:
                self._remember_answered_nonce(nonce)
        for nonce, (event, response_holder) in pending_items:
            if not event.is_set():
                response_holder.append(
                    ApiCommandRequestResponse(
                        result=ApiCommandRequestResult.FAILED,
                        error_message="Socket.IO client disconnected.",
                    )
                )
                event.set()
