from enum import IntEnum


class ApiApplicationMode(IntEnum):
    IDLE = 0
    RUNNING = 100
    IN_DEVICE = 200
    IN_TRAINING = 300
    CALIBRATION_DCS = 1000
    CALIBRATION_3D = 1100
