from enum import IntEnum


class ApiCommandRequestResult(IntEnum):
    """
    Result of a command request.
    """
    UNRECOGNIZED = 0
    """The client does not support this operation."""
    SUCCESS = 100
    """the command executed successfully."""
    PENDING = 200
    """The command was initiated but may not be complete."""
    PENDING_WITH_NOTIFICATION = 201
    """Command was initiated.  A specific event will post when the command completes."""
    FAILED = 400
    """The command was attempted, but could not be completed."""
    EXCEPTION = 500
    """The command was attempted and generated an exception."""
    UNAVAILABLE = 9999
    """The command is recognized, but not supported at this time."""
