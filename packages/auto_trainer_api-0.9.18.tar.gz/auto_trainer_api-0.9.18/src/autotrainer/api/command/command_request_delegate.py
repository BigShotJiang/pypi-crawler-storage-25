from typing import Protocol

from .api_command_request import ApiCommandRequest
from .api_command_request_response import ApiCommandRequestResponse


class CommandRequestDelegate(Protocol):
    """
    This callback is expected to be fast.  It is intended to initiate a command, not necessarily complete it.  Any
    non-trivial action is expected to accept the command request and return, perform the action on a non-calling thread
    or process, and use the message publishing API to report changes, results, etc.
    """

    def __call__(self, request: ApiCommandRequest) -> ApiCommandRequestResponse: ...
