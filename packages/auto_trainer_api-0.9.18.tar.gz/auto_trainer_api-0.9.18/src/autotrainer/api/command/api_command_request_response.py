from dataclasses import dataclass
from typing import Optional, Any

from .api_command import ApiCommand

from .api_command_request_result import ApiCommandRequestResult


@dataclass(frozen=True)
class ApiCommandRequestResponse:
    result: ApiCommandRequestResult

    data: Optional[Any] = None

    error_code: int = 0
    error_message: Optional[str] = None

    command: ApiCommand = ApiCommand.NONE
    """For synchronous command handling, this does not need to be set."""
    nonce: int = -1
    """For synchronous command handling, this does not need to be set."""
