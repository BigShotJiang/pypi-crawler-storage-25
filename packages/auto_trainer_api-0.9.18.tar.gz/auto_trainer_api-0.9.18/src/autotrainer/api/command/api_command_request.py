import json
from dataclasses import dataclass
from typing import Optional, Any

import humps
from typing_extensions import Self

from .api_command import ApiCommand


@dataclass(frozen=True)
class ApiCommandRequest:
    """
    A command request contains the command and any associated data.
    """
    command: ApiCommand
    custom_command: int = -1
    nonce: int = -1
    data: Optional[dict] = None

    @classmethod
    def parse_bytes(cls, message: bytes) -> Optional[Self]:
        obj = json.loads(humps.decamelize(message.decode("utf8")))

        return cls.parse_object(obj)

    @classmethod
    def parse_object(cls, obj: Any) -> Optional[Self]:
        if "command" in obj:
            command = obj["command"]

            if ApiCommand.is_member(command):
                command = ApiCommand(command)
            else:
                command = ApiCommand.USER_DEFINED

            custom_command = obj.get("custom_command", -1)

            if "data" in obj:
                data = obj["data"]
            else:
                data = None
            if "nonce" in obj:
                nonce = obj["nonce"]
            else:
                nonce = 0

            return cls(command=command, custom_command=custom_command, nonce=nonce, data=data)

        return None
