from enum import IntEnum


class ApiAlarmKind(IntEnum):
    # Environmental
    externalDoors = 101

    # Animal
    animalMissing = 201
    animalImmobile = 210

    # Behavior
    thrashing = 301

    # Device hardware
    deviceCommunication = 401

    # Jetson/Computer
    systemFault = 501

    # System maintenance
    systemMaintenance = 601
