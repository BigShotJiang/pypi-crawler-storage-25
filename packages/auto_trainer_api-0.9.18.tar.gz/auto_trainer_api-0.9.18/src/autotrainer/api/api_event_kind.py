from enum import IntEnum


class ApiPelletShiftSource(IntEnum):
    REACH_FAILURES = 1
    TONGUE_EATEN = 2


class ApiEventKind(IntEnum):
    """
    0000-0999 Core/System
    1000-1999 Behavior
    2000-2999 Device
    3000-3999 Inference
    4000-4999 Analysis
    5000-5999 Training
    6000-6999 Detectors & Alarms
    7000-7999 Animal
    9000-9999 Application
    """

    # Core/System
    emergencyStop = 101
    """
    Payload {"reason": <string>, "active_alarms": [ApiAlarmKind]}
    
    active_alarms is populated with the list of active and enabled alarms.  This can include alarms that may not be the
    initial cause of the stop, so long as they are active and enabled (must be enabled).  This list is may be empty when
    the source of the stop is the user button, rpc service, etc.
    """
    emergencyResume = 102
    """Payload {"reason": <string>}"""

    applicationLaunched = 201
    """Payload {"version": <string>}"""
    applicationTerminating = 202
    """Payload {"reason": <string>}"""

    applicationModeChanged = 301
    """Payload {"mode": ApiApplicationMode}"""
    calibrationDcsCompleted = 311
    calibrationDcsFailed = 312
    """Payload {"reason": <string>}"""
    calibration3dCompleted = 321
    calibration3dFailed = 322
    """Payload {"reason": <string>}"""

    propertyChanged = 501
    """
    Payload {"target": <int>, "name": <string>, "new_value": any, "old_value": any}
    Unlike all the others, this not expected to be used by default.  Any expected use of it will be called out
    specifically.
    """

    systemStatus = 601
    """Payload <ApiSystemStatus>"""

    projectChanged = 701
    """
    Payload {"root": <string>, "device_id": <string>, "day": <string>, "session": <int>}
    Sent if the project is set for the first time or if the ProjectInfo root, day, or device properties change. 
    `session` should be the current session number after the root/day/device is set.
    """

    projectSessionChanged = 702
    """
    Payload {"root": <string>, "session": <int>}
    Sent if the project session is changed (via calculate_next_session_index or equivalent).  Does not need to be sent
    if it is part of the root changing and a projectChanged event is sent.
    """

    # Behavior
    algorithmPause = 1001
    """Payload None"""
    algorithmResume = 1002
    """Payload None"""

    tunnelEnter = 1101
    tunnelExit = 1102

    # For all pellet, magnet, gate, and fan events that involve sending a command to hardware, the `context` field of
    # the payload is the uuid/context value returned from the auto-trainer-device command (and received back in the ack).

    ## Hardware actions taken during behavior.
    pelletLoadBegin = 1202
    """Payload {"context": <string>}"""
    pelletLoadEnd = 1203
    """Payload {"context": <string>}"""

    pelletSendBegin = 1205
    """Payload {"context": <string>}"""
    pelletSendEnd = 1206
    """Payload {"context": <string>}"""

    pelletCoverBegin = 1208
    """Payload {"context": <string>}"""
    pelletCoverEnd = 1209
    """Payload {"context": <string>}"""

    pelletReleaseBegin = 1211
    """Payload {"context": <string>}"""
    pelletReleaseEnd = 1212
    """Payload {"context": <string>}"""

    pelletHomeBegin = 1214
    """Payload {"context": <string>}"""
    pelletHomeEnd = 1215
    """Payload {"context": <string>}"""

    pelletRetractBegin = 1220
    """Payload {"context": <string>}"""
    pelletRetractEnd = 1221
    """Payload {"context": <string>}"""

    pelletHomeReset = 1222
    """
    Payload {"cycles": <int>}}
    Home reset that is performed every N cycles to handle small accumulations of drift.
    """

    pelletDriftReset = 1223
    """
    Payload {"drift": {x: <float>, y: <float>, z: <float>}}
    Home reset that is due to drift compensation being exceeded.
    """

    tunnelGateOpenBegin = 1230
    """Payload {"context": <string>}"""
    tunnelGateOpenEnd = 1231
    """Payload {"context": <string>}"""
    tunnelGateCloseBegin = 1232
    """Payload {"context": <string>}"""
    tunnelGateCloseEnd = 1233
    """Payload {"context": <string>}"""

    tunnelFanOnBegin = 1235
    """Payload {"context": <string>}"""
    tunnelFanOnEnd = 1236
    """Payload {"context": <string>}"""
    tunnelFanOffBegin = 1237
    """Payload {"context": <string>}"""
    tunnelFanOffEnd = 1238
    """Payload {"context": <string>}"""

    ## Trial and batch state changes.
    trialStarted = 1301
    trialCaptureEnded = 1305
    """Payload {"reason": <string>}"""
    trialEnded = 1311
    """Payload {"result": <string>}"""

    batchAnalysisStarted = 1321
    """Payload {"count": <int>}"""
    batchAnalysisEnded = 1322
    """Payload {"failed_count": <int>}"""

    ## Hardware (load-cell, force) changes during behavior.
    headfixLoadCellEnabledChanged = 1401
    """
    Payload {"is_enabled": <bool>}
    This is when and as-seen in the behavior state-machines/algorithm, rather than the low-level change in sensor
    analysis itself.
    """
    headfixLoadCellChangedInIntersession = 1405
    """Payload {"is_enabled": <bool>}"""
    headfixLoadCellChangedWrongState = 1406
    """Payload {"is_enabled": <bool>}"""
    headfixAutoTare = 1411
    """Payload <none>"""

    headFixationForceDetectorChanged = 1421
    """
    Payload {"is_enabled": <bool>}
    This is when and as-seen in the behavior state-machines/algorithm, rather than the low-level change in sensor
    analysis itself.
    """

    ## Pose identification during trials.
    trialAnimalSeen = 1501
    """First time the animal is seen by inference after a trial starts."""
    trialRightHandSeen = 1502
    """First time the right_hand is seen by inference after a trial starts."""

    trialPelletSeen = 1503
    """First time the pellet is seen by inference after a trial starts."""

    ## Auto-clamp and baseline behavior.
    headfixBaselineChanged = 1601
    """
    Payload {baseline: <float>}
    This is the "make baseline" button in the UI, not the hardware command to change the magnet.
    """

    autoClampEnabledChanged = 1611  # Was headFixationEnabled
    """Payload {"is_enabled": <bool>}"""
    autoClampIntensityChanged = 1612
    """Payload {"intensity": <float>}"""
    autoClampReleaseToneFreqChanged = 1613
    """Payload {"frequency": <float>}"""
    autoClampReleaseDelayChanged = 1614
    """Payload {"delay": <float>}"""

    autoClampEngaged = 1621
    """
    Payload {"intensity": <float>}
    intensity: magnet intensity used for clamp engagement
    """
    autoClampPreDisengage = 1622
    """
    Payload {"intensity": <float>}
    intensity: magnet intensity used for clamp pre-disengagement
    """
    autoClampPlayReleaseTone = 1623
    """
    Payload {"frequency": <float>, "duration": <float>}
    intensity: magnet intensity used for clamp pre-disengagement
    """
    autoClampDisengaged = 1624
    """
    Payload {"intensity": <float>}
    intensity: magnet intensity used for full clamp disengagement
    """

    ## Intertrial analysis
    intertrialSegmentationBegin = 1701
    intertrialSegmentationEnd = 1702
    intertrialSegmentationError = 1703
    """
    Payload {"error": <string>}
    If sent, is assumed to indicate intertrialSegmentationEnd as well.  intertrialSegmentationEnd does not need to be
    sent separately.
    """
    intertrialSegmentationSave = 1704
    """Payload {"location": <string>}"""
    intertrialSegmentationSaveError = 1705
    """
    Payload {"error": <string>}
    If sent, is assumed to indicate intertrialSegmentationSave as well.  intertrialSegmentationSave does not need to be
    sent separately.
    """
    intertrialDetectionBegin = 1711
    intertrialDetectionEnd = 1712
    intertrialDetectionError = 1713
    """
    Payload {"error": <string>}
    If sent, is assumed to indicate intertrialDetectionError as well.  intertrialDetectionError does not need to be
    sent separately.
    """
    intertrialDetectionSave = 1714
    """Payload {"location": <string>}"""
    intertrialDetectionSaveError = 1715
    """
    Payload {"error": <string>}
    If sent, is assumed to indicate intertrialDetectionSaveError as well.  intertrialDetectionSaveError does not need to be
    sent separately.
    """

    ## Pellet/reach counts.
    pelletPresentedCountChanged = 1800
    """
    Payload {"change": <int>, "count": <int>}
    """

    pelletConsumedCountChanged = 1802
    """
    Payload {"change": <int>, "count": <int>}
    """

    reachCountChanged = 1803
    """
    Payload {"change": <int>, "count": <int>}
    """

    successfulReachesCountChanged = 1804
    """
    Payload {"change": <int>, "count": <int>}
    """

    dayStarted = 1811
    """
    Payload {"date": <float>}
    Value is the number of seconds since the epoch, (e.g. datetime.now(timezone.utc).timestamp()).
    """

    dayPelletPresentedCountChanged = 1812
    """
    Payload {"change": <int>, "count": <int>}
    """

    dayPelletConsumedCountChanged = 1813
    """
    Payload {"change": <int>, "count": <int>}
    """

    dayReachCountChanged = 1814
    """
    Payload {"change": <int>, "count": <int>}
    """

    daySuccessfulReachesCountChanged = 1815
    """
    Payload {"change": <int>, "count": <int>}
    """

    ## Reach analysis.
    trialPelletPresented = 1901
    """Sent when the pellet is considered "presented" in the definition of how long until the reach occurred, etc."""

    trialReachEvents = 1911
    """
    Payload {"trial_reach_events": [<autotrainer.core.ReachEvent>]}
    Payload is the same content as trial_reaches property on BehaviorAlgorithm.
    """

    intertrialPelletShift = 1921
    """
    Payload {"source": <ApiPelletShiftSource>, "shift": {"x": <float>, "y": <float>, "z": <float>}, "deferred": <bool>}
    Sent for any calculated pellet shift, even if not applied (e.g. during batch processing).  `deferred` is True if
    the shift is discarded/replaced.
    """

    # Device
    # These are independent of higher-level events that may share some content such as pelletLoadBegin.
    deviceCommandSend = 2001
    """Payload {"context": <string>}"""
    deviceCommandAcknowledge = 2002
    """Payload {"context": <string>}"""

    # Analysis
    loadCellEngagedChanged = 4001
    """Payload {"is_engaged": <bool>}"""
    headbarPressureEngagedChanged = 4011
    """Payload {"is_engaged": <bool>}"""

    # Training
    trainingModeChanged = 5001
    """Payload {"training_mode": ApiTrainingMode}"""

    trainingPlanLoad = 5101
    """Payload {training_plan_id: <uuid of plan>}"""

    trainingPhaseEnter = 5201
    """Payload {"training_phase_id": <uuid of phase>}"""
    trainingPhaseExit = 5202
    """Payload {"training_phase_id": <uuid of phase>}"""

    trainingProgressUpdate = 5501
    """Payload {"training_phase_id": <uuid of phase for update>}"""

    # Detector/alarm
    detectorChanged = 6001
    """
    Payload <ApiAlarmStatus>
    
    Sent when either of is_active or is_enabled changes.
    """

    alarmChanged = 6501
    """
    Payload <ApiAlarmStatus>
    
    Sent when either of is_active or is_enabled changes.
    """

    # Animal
    animalCreated = 7001
    """
    Payload {"animal_id": <uuid>, "properties": <dict>}
    When a new animal is entered in the Subject field/list and saved.
    """
    animalUpdated = 7002
    """
    Payload {"animal_id": <uuid>, "properties": <dict>}
    Animal json file is updated and saved for any property.  If it is convenient to detect just the changed properties,
    can populate the properties field.  If not, passing None or an empty dict is acceptable.
    """
    animalSelected = 7003
    """Payload {"animal_id": <uuid>, "properties": <dict>}"""
