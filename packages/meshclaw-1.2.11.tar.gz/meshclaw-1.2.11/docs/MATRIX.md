# Matrix Bridge

Matrix is allowed, but only as an operations surface.

It should be used for:

- shared incident rooms
- notifications
- approval prompts
- evidence summaries
- narrow MeshClaw MCP/CLI command calls

It should not become:

- the assistant brain
- a general personal assistant
- a separate policy system
- a replacement for Codex, Claude, ChatGPT, or local LLM frontends

## Flow

```text
human / Codex / Claude / local LLM
  -> Matrix ops room
  -> Matrix bridge
  -> MeshClaw MCP / CLI
  -> policy_check
  -> vssh / fleet scan / evidence
  -> concise Matrix result + evidence link
```

## Command Surface

Safe defaults:

- `workers`
- `server_list`
- `capability_list`
- `monitor_check`
- `fleet_scan`
- `evidence_list`
- `policy_check`
- `policy_show`
- `analyze_logs`
- `security_check`
- `hygiene_scan_host`

Approval-gated:

- `run_command`
- `autoheal_apply_safe`
- `service_remove`
- `provision_server`
- `deprovision_server`
- `rotate_secret`

Use:

```sh
meshclaw matrix-plan
meshclaw workers
```

The Matrix command should map `!workers` to `meshclaw.workers`. That command
does not resurrect the old personal-assistant worker runtime; it lists the
active operator surfaces and execution workers:

- Codex
- Claude
- local LLM / Open WebUI
- Matrix ops room
- MeshClaw MCP
- vssh daemon

Workspace commands should also be exposed in Matrix:

- `!workspaces` -> `meshclaw.workspace_list`
- `!workspace add ...` -> `meshclaw.workspace_add`
- `!activity ...` -> `meshclaw.workspace_activity`

These commands answer the operational question: which model or human is working
on which server, folder, branch, and task.

Before wiring the real Matrix bridge, use the local conversation harness:

```sh
meshclaw ops-chat
meshclaw ops-chat workers
meshclaw ops-chat "서버 상태 보여줘"
meshclaw ops-dispatch matrix "!workers"
```
