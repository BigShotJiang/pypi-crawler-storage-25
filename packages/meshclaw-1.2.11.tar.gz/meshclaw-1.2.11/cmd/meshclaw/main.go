package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"github.com/meshclaw/meshclaw/internal/capability"
	"github.com/meshclaw/meshclaw/internal/doctor"
	"github.com/meshclaw/meshclaw/internal/evidence"
	"github.com/meshclaw/meshclaw/internal/fleet"
	"github.com/meshclaw/meshclaw/internal/hygiene"
	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/monitor"
	"github.com/meshclaw/meshclaw/internal/policy"
	"github.com/meshclaw/meshclaw/internal/provision"
	"github.com/meshclaw/meshclaw/internal/runtime"
	"github.com/meshclaw/meshclaw/internal/workers"
	"github.com/meshclaw/meshclaw/internal/workflow"
	"github.com/meshclaw/meshclaw/internal/workspace"
)

func main() {
	if len(os.Args) < 2 {
		usage()
		return
	}

	var err error
	switch os.Args[1] {
	case "list":
		err = list(os.Args[2:])
	case "capabilities":
		err = capabilities(os.Args[2:])
	case "status":
		err = status()
	case "monitor-check":
		err = monitorCheck(os.Args[2:])
	case "monitor-agent":
		err = monitorAgent(os.Args[2:])
	case "fleet-scan":
		err = fleetScan(os.Args[2:])
	case "autoheal-plan":
		err = autohealPlan(os.Args[2:])
	case "autoheal-apply-safe":
		err = autohealApplySafe()
	case "disk-investigate":
		err = diskInvestigate(os.Args[2:])
	case "data-clean-plan":
		err = dataCleanPlan(os.Args[2:])
	case "data-clean-apply":
		err = dataCleanApply(os.Args[2:])
	case "evidence-list":
		err = evidenceList(os.Args[2:])
	case "policy-check":
		err = policyCheck(os.Args[2:])
	case "policy-show":
		err = policyShow(os.Args[2:])
	case "policy-init":
		err = policyInit(os.Args[2:])
	case "policy-presets":
		err = policyPresets(os.Args[2:])
	case "matrix-plan":
		err = matrixBridgePlan(os.Args[2:])
	case "workers":
		err = workersList(os.Args[2:])
	case "workspace-list":
		err = workspaceList(os.Args[2:])
	case "workspace-add":
		err = workspaceAdd(os.Args[2:])
	case "workspace-activity":
		err = workspaceActivity(os.Args[2:])
	case "ops-chat":
		err = opsChat(os.Args[2:])
	case "ops-dispatch":
		err = opsDispatch(os.Args[2:])
	case "provision-plan":
		err = provisionPlan(os.Args[2:])
	case "run":
		err = run(os.Args[2:])
	case "run-evidence":
		err = runEvidence(os.Args[2:])
	case "job-start":
		err = jobStart(os.Args[2:])
	case "job-status":
		err = jobStatus(os.Args[2:])
	case "job-logs":
		err = jobLogs(os.Args[2:])
	case "job-cancel":
		err = jobCancel(os.Args[2:])
	case "artifact-collect":
		err = artifactCollect(os.Args[2:])
	case "doctor":
		err = runDoctor(os.Args[2:])
	case "analyze-logs":
		err = analyzeLogs(os.Args[2:])
	case "service-check":
		err = serviceCheck(os.Args[2:])
	case "service-quarantine":
		err = serviceQuarantine(os.Args[2:])
	case "service-remove":
		err = serviceRemove(os.Args[2:])
	case "security-check":
		err = securityCheck(os.Args[2:])
	case "hygiene-plan":
		err = hygienePlan(os.Args[2:])
	case "hygiene-scan-host":
		err = hygieneScanHost(os.Args[2:])
	case "hygiene-scan-text":
		err = hygieneScanText(os.Args[2:])
	case "mcp":
		err = mcp()
	default:
		err = fmt.Errorf("unknown command: %s", os.Args[1])
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "meshclaw:", err)
		os.Exit(1)
	}
}

func usage() {
	fmt.Println(`meshclaw - AI-native server operations control plane

Usage:
  meshclaw list
  meshclaw capabilities
  meshclaw status
  meshclaw monitor-check
  meshclaw monitor-agent [interval] [--hygiene]
  meshclaw fleet-scan [--hosts a,b] [--security] [--hygiene] [--logs] [--parallel n] [--json]
  meshclaw autoheal-plan
  meshclaw autoheal-apply-safe
  meshclaw disk-investigate <host> [path]
  meshclaw data-clean-plan <host> <path>
  meshclaw data-clean-apply <host> <manifest>
  meshclaw evidence-list [limit]
  meshclaw policy-check <subject> <action> <resource> [context]
  meshclaw policy-show
  meshclaw policy-init [--preset devops|strict] [--force]
  meshclaw policy-presets
  meshclaw matrix-plan
  meshclaw workers [--json]
  meshclaw workspace-list [--json]
  meshclaw workspace-add <id> <host> <path> [owner] [purpose]
  meshclaw workspace-activity <id> <actor> <action> <summary>
  meshclaw ops-chat [message]
  meshclaw ops-dispatch <matrix|openwebui|codex|claude> <message>
  meshclaw provision-plan <purpose> [budget-usd]
  meshclaw run <host> <command>
  meshclaw run-evidence <host> <command>
  meshclaw job-start <host> <command>
  meshclaw job-status <host> <id>
  meshclaw job-logs <host> <id> [tail-bytes]
  meshclaw job-cancel <host> <id>
  meshclaw artifact-collect <host> <path> [max-bytes]
  meshclaw doctor <host>
  meshclaw analyze-logs <host> <source>
  meshclaw service-check <host> <service>
  meshclaw service-quarantine <host> <service>
  meshclaw service-remove <host> <service> [working-directory]
  meshclaw security-check <host>
  meshclaw hygiene-plan <host>
  meshclaw hygiene-scan-host <host>
  meshclaw hygiene-scan-text <target> <text>
  meshclaw mcp`)
}

func monitorAgent(args []string) error {
	interval := 5 * time.Minute
	hygieneEnabled := false
	filteredArgs := make([]string, 0, len(args))
	for _, arg := range args {
		if arg == "--hygiene" {
			hygieneEnabled = true
			continue
		}
		filteredArgs = append(filteredArgs, arg)
	}
	if len(filteredArgs) > 1 {
		return fmt.Errorf("usage: meshclaw monitor-agent [interval] [--hygiene]")
	}
	if len(filteredArgs) == 1 {
		parsed, err := time.ParseDuration(filteredArgs[0])
		if err != nil {
			return fmt.Errorf("invalid interval: %s", filteredArgs[0])
		}
		if parsed < 10*time.Second {
			return fmt.Errorf("interval must be at least 10s")
		}
		interval = parsed
	}

	cfg := monitor.DefaultConfig()
	cfg.CheckInterval = interval
	m, err := monitor.New(cfg)
	if err != nil {
		return err
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	fmt.Printf("meshclaw monitor-agent interval=%s hygiene=%t\n", interval, hygieneEnabled)

	runOnce := func() {
		states := m.CheckAll()
		alerts := m.DetectAlerts()
		var hygieneReports []hygiene.Report
		if hygieneEnabled {
			for name, state := range states {
				if state == nil || !state.Online {
					continue
				}
				report := hygiene.ScanHost(name)
				if report.Status == "findings" || report.Status == "failed" {
					hygieneReports = append(hygieneReports, report)
				}
			}
		}
		record, storeErr := evidence.Store("monitor-agent", "fleet", fmt.Sprintf("alerts=%d hygiene_findings=%d", len(alerts), len(hygieneReports)), monitorAgentOutput{States: states, Alerts: alerts, Hygiene: hygieneReports})
		fmt.Printf("monitor-agent check nodes=%d alerts=%d", len(states), len(alerts))
		if hygieneEnabled {
			fmt.Printf(" hygiene_findings=%d", len(hygieneReports))
		}
		if storeErr != nil {
			fmt.Printf(" evidence_error=%v", storeErr)
		} else {
			fmt.Printf(" evidence=%s", record.StoredAt)
		}
		fmt.Println()
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}

	runOnce()
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			runOnce()
		case <-stop:
			fmt.Println("meshclaw monitor-agent stopped")
			return nil
		}
	}
}

func list(args []string) error {
	if wantsJSON(args) {
		return printJSON(inventory.DefaultNodes())
	}
	fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", "NODE", "ROLE", "LOCATION", "TAILSCALE", "WIRE", "USER")
	for _, node := range inventory.DefaultNodes() {
		fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", node.Name, node.Role, node.Location, node.Tailscale, node.WireIP, node.User)
	}
	return nil
}

func fleetScan(args []string) error {
	jsonOut := wantsJSON(args)
	opts, err := parseFleetScanOptions(withoutJSONFlag(args))
	if err != nil {
		return err
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "fleet_scan", Resource: "server"})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	report, err := fleet.Scan(opts)
	if err != nil {
		return err
	}
	record, storeErr := evidence.Store("fleet-scan", "fleet", fleetScanSummary(report), report)
	if jsonOut {
		return printJSON(map[string]interface{}{"policy": decision, "report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("fleet-scan hosts=%d alerts=%d security=%t hygiene=%t logs=%t\n", len(report.Hosts), len(report.Alerts), report.Options.Security, report.Options.Hygiene, report.Options.Logs)
	for _, host := range report.Hosts {
		status := "offline"
		if host.Online {
			status = "online"
		}
		fmt.Printf("- %s %s", host.Host, status)
		if host.Error != "" {
			fmt.Printf(" error=%s", truncate(host.Error, 80))
		}
		if host.Security != nil {
			fmt.Printf(" security=%s", host.Security.Status)
		}
		if host.Logs != nil {
			fmt.Printf(" logs=%s", host.Logs.Status)
		}
		if host.Hygiene != nil {
			fmt.Printf(" hygiene=%s", host.Hygiene.Status)
		}
		fmt.Println()
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func parseFleetScanOptions(args []string) (fleet.Options, error) {
	var opts fleet.Options
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--security":
			opts.Security = true
		case "--hygiene":
			opts.Hygiene = true
		case "--logs":
			opts.Logs = true
		case "--hosts":
			i++
			if i >= len(args) {
				return opts, fmt.Errorf("--hosts requires a comma-separated value")
			}
			opts.Hosts = splitCSV(args[i])
		case "--parallel":
			i++
			if i >= len(args) {
				return opts, fmt.Errorf("--parallel requires a number")
			}
			if _, err := fmt.Sscanf(args[i], "%d", &opts.MaxParallel); err != nil {
				return opts, fmt.Errorf("invalid --parallel value: %s", args[i])
			}
		default:
			return opts, fmt.Errorf("unknown fleet-scan option: %s", args[i])
		}
	}
	return opts, nil
}

func splitCSV(value string) []string {
	parts := strings.Split(value, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part != "" {
			out = append(out, part)
		}
	}
	return out
}

func fleetScanSummary(report fleet.Report) string {
	offline := 0
	findings := 0
	for _, host := range report.Hosts {
		if !host.Online {
			offline++
		}
		if host.Security != nil && host.Security.Status == "findings" {
			findings++
		}
		if host.Logs != nil && host.Logs.Status == "findings" {
			findings++
		}
		if host.Hygiene != nil && host.Hygiene.Status == "findings" {
			findings++
		}
	}
	return fmt.Sprintf("hosts=%d alerts=%d offline=%d findings=%d", len(report.Hosts), len(report.Alerts), offline, findings)
}

func capabilities(args []string) error {
	if wantsJSON(args) {
		return printJSON(capability.DefaultCapabilities())
	}
	fmt.Printf("%-18s %-13s %-14s %-18s %s\n", "ID", "KIND", "PROVIDER", "STATUS", "POLICY")
	for _, cap := range capability.DefaultCapabilities() {
		fmt.Printf("%-18s %-13s %-14s %-18s %s\n", cap.ID, cap.Kind, cap.Provider, cap.Status, cap.Policy)
	}
	return nil
}

func status() error {
	out, err := runtime.NewRunner().Status()
	fmt.Print(out)
	return err
}

type monitorCheckOutput struct {
	States map[string]*monitor.NodeState `json:"states"`
	Alerts []monitor.Alert               `json:"alerts"`
}

type monitorAgentOutput struct {
	States  map[string]*monitor.NodeState `json:"states"`
	Alerts  []monitor.Alert               `json:"alerts"`
	Hygiene []hygiene.Report              `json:"hygiene,omitempty"`
}

func monitorCheck(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	states := m.CheckAll()
	alerts := m.DetectAlerts()
	record, storeErr := evidence.Store("monitor-check", "fleet", fmt.Sprintf("alerts=%d", len(alerts)), monitorCheckOutput{States: states, Alerts: alerts})
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"states": states, "alerts": alerts, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("%-10s %-7s %-15s %6s %6s %s\n", "NODE", "ONLINE", "IP", "DISK", "MEM", "ERROR")
	for _, node := range inventory.DefaultNodes() {
		state := states[node.Name]
		if state == nil {
			continue
		}
		fmt.Printf("%-10s %-7t %-15s %5.1f%% %5.1f%% %s\n", state.Name, state.Online, state.IP, state.Disk, state.Memory, state.Error)
	}
	if len(alerts) > 0 {
		fmt.Println("alerts:")
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func autohealPlan(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	healer := monitor.NewAutoHealer(m)
	actions := healer.Plan()
	record, storeErr := evidence.Store("autoheal-plan", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"actions": actions, "evidence": record, "store_error": errString(storeErr)})
	}
	if len(actions) == 0 {
		fmt.Println("autoheal status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal status=actions")
	for _, action := range actions {
		fmt.Printf("- [%s/%s] %s %s=%.1f mode=%s\n  command: %s\n  reason: %s\n  verify: %s\n",
			action.Severity, action.Type, action.Node, action.Metric, action.Value, action.Mode, action.Command, action.Reason, action.Verify)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func autohealApplySafe() error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	healer := monitor.NewAutoHealer(m)
	actions := healer.CheckAndHeal()
	record, storeErr := evidence.Store("autoheal-apply-safe", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
	if len(actions) == 0 {
		fmt.Println("autoheal apply status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal apply status=done")
	for _, action := range actions {
		fmt.Printf("- [%t] %s %s\n  command: %s\n  result: %s\n", action.Success, action.Node, action.Type, action.Command, action.Result)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func diskInvestigate(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw disk-investigate <host> [path]")
	}
	host := args[0]
	path := "/"
	if len(args) == 2 {
		path = args[1]
	}
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if !strings.HasPrefix(path, "/") {
		return fmt.Errorf("path must be absolute: %s", path)
	}
	quoted := shellQuote(path)
	command := fmt.Sprintf("df -h %s && sudo du -xhd1 %s 2>/dev/null | sort -h | tail -40", quoted, quoted)
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("disk-investigate", host, path, result)
	fmt.Printf("disk-investigate host=%s path=%s success=%t transport=%s\n", host, path, result.Success, result.Transport)
	if result.Stdout != "" {
		fmt.Print(result.Stdout)
	}
	if result.Stderr != "" {
		fmt.Fprint(os.Stderr, result.Stderr)
	}
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("disk investigation failed on %s", host)
	}
	return nil
}

func dataCleanPlan(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-plan <host> <path>")
	}
	report := workflow.DataCleanPlan(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-plan", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func dataCleanApply(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-apply <host> <manifest>")
	}
	report := workflow.DataCleanApply(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-apply", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func shellQuote(value string) string {
	return "'" + strings.ReplaceAll(value, "'", "'\\''") + "'"
}

func evidenceList(args []string) error {
	limit := 20
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw evidence-list [limit]")
	}
	if len(args) == 1 {
		if _, err := fmt.Sscanf(args[0], "%d", &limit); err != nil {
			return fmt.Errorf("invalid limit: %s", args[0])
		}
	}
	records, err := evidence.List(limit)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(records)
	}
	if len(records) == 0 {
		fmt.Println("evidence records=0")
		return nil
	}
	fmt.Printf("%-20s %-18s %-10s %-22s %s\n", "TIME", "KIND", "HOST", "SUMMARY", "PATH")
	for _, record := range records {
		fmt.Printf("%-20s %-18s %-10s %-22s %s\n",
			record.Time.Local().Format("2006-01-02 15:04:05"),
			record.Kind,
			record.Host,
			truncate(record.Summary, 22),
			record.StoredAt,
		)
	}
	return nil
}

func truncate(value string, max int) string {
	if len(value) <= max {
		return value
	}
	if max <= 3 {
		return value[:max]
	}
	return value[:max-3] + "..."
}

func policyCheck(args []string) error {
	if len(args) < 3 {
		return fmt.Errorf("usage: meshclaw policy-check <subject> <action> <resource> [context]")
	}
	request := policy.Request{
		Subject:  args[0],
		Action:   args[1],
		Resource: args[2],
	}
	if len(args) > 3 {
		request.Context = strings.Join(args[3:], " ")
	}
	result := policy.Evaluate(request)
	return printJSON(result)
}

func policyShow(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw policy-show")
	}
	cfg, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"path": path, "policy": cfg})
}

func policyInit(args []string) error {
	force := false
	preset := "devops"
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--force" {
			force = true
			continue
		}
		if arg == "--preset" {
			i++
			if i >= len(args) {
				return fmt.Errorf("--preset requires a value")
			}
			preset = args[i]
			continue
		}
		return fmt.Errorf("usage: meshclaw policy-init [--preset devops|strict] [--force]")
	}
	_, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	if !force {
		if _, err := os.Stat(path); err == nil {
			return fmt.Errorf("policy file already exists: %s", path)
		} else if !os.IsNotExist(err) {
			return err
		}
	}
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	data, err := json.MarshalIndent(policy.PresetConfig(preset), "", "  ")
	if err != nil {
		return err
	}
	if err := os.WriteFile(path, append(data, '\n'), 0600); err != nil {
		return err
	}
	fmt.Printf("policy=%s preset=%s\n", path, preset)
	return nil
}

func policyPresets(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw policy-presets")
	}
	return printJSON(policy.PresetNames())
}

func matrixBridgePlan(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw matrix-plan")
	}
	return printJSON(map[string]interface{}{
		"role": "Matrix is an operations room, approval channel, notification channel, and optional MCP command surface. It is not the assistant brain.",
		"flow": []string{
			"human or AI operator posts an ops request in Matrix",
			"Matrix bridge normalizes the request into a MeshClaw MCP/CLI tool call",
			"MeshClaw policy decides allow, require_approval, or deny",
			"MeshClaw executes only allowed tools through vssh/runtime",
			"Matrix bridge posts concise results and evidence links back to the room",
		},
		"allowed_by_default": []string{
			"server_list",
			"capability_list",
			"monitor_check",
			"fleet_scan",
			"evidence_list",
			"policy_check",
			"policy_show",
			"analyze_logs",
			"security_check",
			"hygiene_scan_host",
		},
		"approval_gated": []string{
			"run_command",
			"autoheal_apply_safe",
			"service_remove",
			"provision_server",
			"deprovision_server",
			"rotate_secret",
		},
	})
}

func workersList(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw workers [--json]")
	}
	list := workers.DefaultWorkers()
	if jsonOut {
		return printJSON(list)
	}
	fmt.Printf("%-16s %-18s %-14s %-13s %s\n", "ID", "KIND", "SUBJECT", "STATUS", "SURFACE")
	for _, worker := range list {
		fmt.Printf("%-16s %-18s %-14s %-13s %s\n", worker.ID, worker.Kind, worker.Subject, worker.Status, worker.Surface)
	}
	return nil
}

func workspaceList(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw workspace-list [--json]")
	}
	list, path, err := workspace.List()
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"path": path, "workspaces": list})
	}
	if len(list) == 0 {
		fmt.Printf("workspaces=0 path=%s\n", path)
		return nil
	}
	fmt.Printf("%-18s %-10s %-32s %-12s %-14s %s\n", "ID", "HOST", "PATH", "OWNER", "BRANCH", "PURPOSE")
	for _, ws := range list {
		fmt.Printf("%-18s %-10s %-32s %-12s %-14s %s\n", ws.ID, ws.Host, truncate(ws.Path, 32), ws.Owner, ws.Branch, ws.Purpose)
	}
	return nil
}

func workspaceAdd(args []string) error {
	if len(args) < 3 || len(args) > 5 {
		return fmt.Errorf("usage: meshclaw workspace-add <id> <host> <path> [owner] [purpose]")
	}
	ws := workspace.Workspace{ID: args[0], Host: args[1], Path: args[2]}
	if len(args) >= 4 {
		ws.Owner = args[3]
	}
	if len(args) >= 5 {
		ws.Purpose = args[4]
	}
	saved, path, err := workspace.Upsert(ws)
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"path": path, "workspace": saved})
}

func workspaceActivity(args []string) error {
	if len(args) < 4 {
		return fmt.Errorf("usage: meshclaw workspace-activity <id> <actor> <action> <summary>")
	}
	activity := workspace.Activity{
		WorkspaceID: args[0],
		Actor:       args[1],
		Action:      args[2],
		Summary:     strings.Join(args[3:], " "),
	}
	record, err := workspace.RecordActivity(activity)
	if err != nil {
		return err
	}
	return printJSON(record)
}

func opsChat(args []string) error {
	if len(args) > 0 {
		return handleOpsChatMessage(strings.Join(args, " "))
	}
	fmt.Println("meshclaw ops-chat")
	fmt.Println("Try: workers, workspaces, fleet, evidence, policy, matrix, help, quit")
	scanner := bufio.NewScanner(os.Stdin)
	for {
		fmt.Print("you> ")
		if !scanner.Scan() {
			break
		}
		message := strings.TrimSpace(scanner.Text())
		if message == "" {
			continue
		}
		if message == "quit" || message == "exit" || message == "종료" {
			break
		}
		if err := handleOpsChatMessage(message); err != nil {
			fmt.Fprintf(os.Stderr, "meshclaw: %v\n", err)
		}
	}
	return scanner.Err()
}

func opsDispatch(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw ops-dispatch <matrix|openwebui|codex|claude> <message>")
	}
	result, err := dispatchOpsMessage(args[0], strings.Join(args[1:], " "))
	if err != nil {
		return err
	}
	return printJSON(result)
}

func dispatchOpsMessage(source, message string) (map[string]interface{}, error) {
	source = strings.ToLower(strings.TrimSpace(source))
	if source == "" {
		source = "unknown"
	}
	lower := strings.ToLower(strings.TrimSpace(message))
	result := map[string]interface{}{
		"source":  source,
		"message": message,
	}
	switch {
	case containsAny(lower, "workers", "worker", "!workers", "작업자", "워커"):
		result["route"] = "workers"
		result["result"] = workers.DefaultWorkers()
	case containsAny(lower, "add current workspace", "현재 워크스페이스 등록", "현재 작업공간 등록"):
		ws, path, err := workspace.Upsert(workspace.Workspace{ID: "meshclaw-local", Host: "local", Path: "/Users/dragon/meshclaw", Owner: source, Purpose: "serverops", Source: source})
		if err != nil {
			return nil, err
		}
		result["route"] = "workspace_add"
		result["result"] = map[string]interface{}{"path": path, "workspace": ws}
	case containsAny(lower, "workspaces", "workspace", "!workspaces", "워크스페이스", "작업공간"):
		list, path, err := workspace.List()
		if err != nil {
			return nil, err
		}
		result["route"] = "workspace_list"
		result["result"] = map[string]interface{}{"path": path, "workspaces": list}
	case containsAny(lower, "fleet", "monitor", "!fleet", "서버 상태", "상태", "모니터"):
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		states := m.CheckAll()
		result["route"] = "monitor_check"
		result["result"] = monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	case containsAny(lower, "evidence", "!evidence", "기록", "증거"):
		records, err := evidence.List(10)
		if err != nil {
			return nil, err
		}
		result["route"] = "evidence_list"
		result["result"] = records
	case containsAny(lower, "policy", "!policy", "권한", "정책"):
		cfg, path, err := policy.LoadConfig()
		if err != nil {
			return nil, err
		}
		result["route"] = "policy_summary"
		result["result"] = policySummary(path, cfg)
	case containsAny(lower, "matrix", "매트릭스"):
		result["route"] = "matrix_plan"
		result["result"] = integrationDifference("matrix")
	case containsAny(lower, "openwebui", "open webui", "웹유아이"):
		result["route"] = "openwebui_plan"
		result["result"] = integrationDifference("openwebui")
	default:
		result["route"] = "help"
		result["result"] = map[string]interface{}{
			"try": []string{"workers", "workspaces", "현재 워크스페이스 등록", "서버 상태 보여줘", "기록 보여줘", "정책 보여줘", "matrix", "openwebui"},
		}
	}
	return result, nil
}

func handleOpsChatMessage(message string) error {
	lower := strings.ToLower(strings.TrimSpace(message))
	fmt.Println("meshclaw>")
	switch {
	case containsAny(lower, "help", "도움", "?"):
		fmt.Println(`Available conversation checks:
- workers / 작업자: show model/operator workers
- workspaces / 워크스페이스: show server/folder ownership
- fleet / 서버 상태: run monitor-check
- evidence / 기록: show recent evidence
- policy / 권한: show current policy
- matrix / 매트릭스: show Matrix ops-room plan
- add current workspace / 현재 워크스페이스 등록: register /Users/dragon/meshclaw`)
		return nil
	case containsAny(lower, "workers", "worker", "작업자", "워커"):
		return workersList(nil)
	case containsAny(lower, "add current workspace", "현재 워크스페이스 등록", "현재 작업공간 등록"):
		return workspaceAdd([]string{"meshclaw-local", "local", "/Users/dragon/meshclaw", "human", "serverops"})
	case containsAny(lower, "workspaces", "workspace", "워크스페이스", "작업공간"):
		return workspaceList(nil)
	case containsAny(lower, "fleet", "monitor", "서버 상태", "상태", "모니터"):
		return monitorCheck(nil)
	case containsAny(lower, "evidence", "기록", "증거"):
		return evidenceList([]string{"10"})
	case containsAny(lower, "policy", "권한", "정책"):
		return opsPolicySummary()
	case containsAny(lower, "matrix", "매트릭스"):
		return matrixBridgePlan(nil)
	default:
		fmt.Println("I can route ops-room phrases to MeshClaw tools. Type help for examples.")
		return nil
	}
}

func opsPolicySummary() error {
	cfg, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	summary := policySummary(path, cfg)
	fmt.Printf("policy path=%s rules=%d allow=%d require_approval=%d deny=%d\n", summary["path"], summary["rules"], summary["allow"], summary["require_approval"], summary["deny"])
	fmt.Println("Use `meshclaw policy-show` for the full policy JSON.")
	return nil
}

func policySummary(path string, cfg policy.Config) map[string]interface{} {
	allow, gate, deny := 0, 0, 0
	for _, rule := range cfg.Rules {
		switch rule.Decision {
		case policy.Allow:
			allow++
		case policy.RequireApproval:
			gate++
		case policy.Deny:
			deny++
		}
	}
	return map[string]interface{}{"path": path, "rules": len(cfg.Rules), "allow": allow, "require_approval": gate, "deny": deny}
}

func integrationDifference(name string) map[string]interface{} {
	switch name {
	case "openwebui":
		return map[string]interface{}{
			"role":        "Open WebUI is a local/private model chat frontend. It should call MeshClaw through MCP/tool bridge for server facts, workspace state, and evidence.",
			"best_for":    []string{"local model chat", "private log analysis", "single-user model experiments", "redacted summaries"},
			"not_for":     []string{"shared approvals", "team timeline", "persistent operations room"},
			"entrypoints": []string{"meshclaw mcp", "meshclaw ops-dispatch openwebui <message>", "meshclaw workspace_* tools"},
		}
	default:
		return map[string]interface{}{
			"role":        "Matrix is a shared operations room for humans, friends, Codex, Claude, local LLMs, approvals, notifications, screenshots, and evidence links.",
			"best_for":    []string{"shared timeline", "approval workflow", "multi-model handoff", "screenshots and evidence posting"},
			"not_for":     []string{"replacing Codex/Claude apps", "being the assistant brain"},
			"entrypoints": []string{"!workers", "!workspaces", "!fleet", "meshclaw ops-dispatch matrix <message>"},
		}
	}
}

func containsAny(value string, needles ...string) bool {
	for _, needle := range needles {
		if strings.Contains(value, strings.ToLower(needle)) {
			return true
		}
	}
	return false
}

func wantsJSON(args []string) bool {
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			return true
		}
	}
	return false
}

func withoutJSONFlag(args []string) []string {
	filtered := make([]string, 0, len(args))
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			continue
		}
		filtered = append(filtered, arg)
	}
	return filtered
}

func printJSON(value interface{}) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	return nil
}

func printEvidenceStoreStatus(record evidence.Record, err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", err)
		return
	}
	fmt.Printf("evidence=%s\n", record.StoredAt)
}

func provisionPlan(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw provision-plan <purpose> [budget-usd]")
	}
	req := provision.Request{Purpose: args[0], TTLHours: 6, RequiredClass: "small-vps"}
	if len(args) == 2 {
		if _, err := fmt.Sscanf(args[1], "%f", &req.BudgetUSD); err != nil {
			return fmt.Errorf("invalid budget-usd: %s", args[1])
		}
	}
	plan := provision.NewPlan(req)
	record, storeErr := evidence.Store("provision-plan", "provider", req.Purpose, plan)
	if err := printJSON(map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(storeErr)}); err != nil {
		return err
	}
	return nil
}

func run(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	out, err := runtime.NewRunner().Run(host, command)
	fmt.Print(out)
	return err
}

func runEvidence(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run-evidence <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("run-evidence", host, command, result)
	data, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("execution failed on %s", host)
	}
	return nil
}

func jobStart(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw job-start <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	result, err := runtime.NewRunner().VSSHJSON("job-start", host, command)
	record, storeErr := evidence.Store("job-start", host, command, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobStatus(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw job-status <host> <id>")
	}
	return jobRead(args[0], args[1], "job-status")
}

func jobLogs(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw job-logs <host> <id> [tail-bytes]")
	}
	params := []string{"job-logs", args[0], args[1]}
	if len(args) == 3 {
		params = append(params, args[2])
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_logs", Resource: "server", Context: args[1]})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON(params...)
	record, storeErr := evidence.Store("job-logs", args[0], args[1], result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobCancel(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw job-cancel <host> <id>")
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_cancel", Resource: "server", Context: args[1]})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON("job-cancel", args[0], args[1])
	record, storeErr := evidence.Store("job-cancel", args[0], args[1], result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobRead(host, id, command string) error {
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_status", Resource: "server", Context: id})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON(command, host, id)
	record, storeErr := evidence.Store(command, host, id, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func artifactCollect(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw artifact-collect <host> <path> [max-bytes]")
	}
	host, path := args[0], args[1]
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "artifact_collect", Resource: "server", Context: path})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	params := []string{"artifact-collect", host, path}
	if len(args) == 3 {
		params = append(params, args[2])
	}
	result, err := runtime.NewRunner().VSSHJSON(params...)
	record, storeErr := evidence.Store("artifact-collect", host, path, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func printResultWithEvidence(result interface{}, record evidence.Record, storeErr error, err error) error {
	if printErr := printJSON(map[string]interface{}{"result": result, "evidence": record, "store_error": errString(storeErr)}); printErr != nil {
		return printErr
	}
	return err
}

func runDoctor(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw doctor <host>")
	}
	fmt.Print(doctor.Check(args[0]))
	return nil
}

func analyzeLogs(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw analyze-logs <host> <source>")
	}
	report := workflow.AnalyzeLogs(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("analyze-logs", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceCheck(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-check <host> <service>")
	}
	report := workflow.ServiceCheck(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-check", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceQuarantine(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-quarantine <host> <service>")
	}
	report := workflow.ServiceQuarantine(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-quarantine", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceRemove(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw service-remove <host> <service> [working-directory]")
	}
	path := ""
	if len(args) == 3 {
		path = args[2]
	}
	report := workflow.ServiceRemove(args[0], args[1], path)
	printReport(report)
	record, storeErr := evidence.Store("service-remove", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func securityCheck(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw security-check <host>")
	}
	report := workflow.SecurityCheck(args[0])
	printReport(report)
	record, storeErr := evidence.Store("security-check", args[0], "read-only snapshot", report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func hygienePlan(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw hygiene-plan <host>")
	}
	printHygieneReport(hygiene.Plan(args[0]))
	return nil
}

func hygieneScanHost(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw hygiene-scan-host <host>")
	}
	report := hygiene.ScanHost(args[0])
	record, storeErr := evidence.Store("hygiene-scan-host", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printHygieneReport(report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func hygieneScanText(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw hygiene-scan-text <target> <text>")
	}
	printHygieneReport(hygiene.ScanText(args[0], strings.Join(args[1:], " ")))
	return nil
}

func printReport(report workflow.Report) {
	fmt.Printf("%s host=%s status=%s\n", report.Name, report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- [%s] %s\n  evidence: %s\n  next: %s\n", finding.Severity, finding.Title, finding.Evidence, finding.Next)
	}
}

func printHygieneReport(report hygiene.Report) {
	fmt.Printf("hygiene host=%s status=%s\n", report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- finding [%s] %s target=%s evidence=%s\n", finding.Severity, finding.Type, finding.Target, finding.Evidence)
	}
	for _, action := range report.Actions {
		fmt.Printf("- action [%s] %s target=%s\n  command: %s\n  reason: %s\n  verify: %s\n", action.Mode, action.ID, action.Target, action.Command, action.Reason, action.Verify)
	}
}

func mcp() error {
	return cmdMCP()
}
