# Scopebound Python SDK

Zero-trust identity and enforcement for AI agents.

## Installation
```bash
pip install scopebound
```

## Quickstart — LangChain
```python
from scopebound import ScopeboundSDK, enforce
from langchain_core.tools import BaseTool

sb = ScopeboundSDK(base_url="http://localhost:8080")

@enforce(sb, role="invoice-processor")
class ReadInvoicesTool(BaseTool):
    name = "read_invoices"
    description = "Read invoices from the database"

    def _run(self, query: str) -> str:
        return "invoice data"
```

## License

Apache-2.0
