"""
Scopebound Design Partner Demo
===============================
An invoice processing agent built with LangChain.
Shows the full Scopebound integration journey in ~30 minutes.

Three tools:
  - read_invoices   : reads from a mock database (always allowed)
  - send_email      : sends an approval email (role-gated)
  - delete_invoice  : deletes a record (blocked by policy)

Run steps:
  1. pip install scopebound langchain-core langchain-openai
  2. Set OPENAI_API_KEY and SCOPEBOUND_API_KEY env vars
  3. python agent.py --step 1   # happy path
  4. python agent.py --step 2   # denial
  5. python agent.py --step 3   # drift detection
"""

import argparse
import os
import time
import json
import random
from datetime import datetime
from typing import Optional

# ── Scopebound import ─────────────────────────────────────────────────────────
from scopebound import ScopeboundSDK, enforce
from scopebound.exceptions import ScopeboundDenyError

# ── LangChain imports ─────────────────────────────────────────────────────────
from langchain_core.tools import BaseTool
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langchain_core.runnables import RunnableConfig

# ── Config ────────────────────────────────────────────────────────────────────
ENFORCEMENT_PLANE_URL = os.environ.get(
    "SCOPEBOUND_BASE_URL", "http://localhost:8080"
)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")

# ── Scopebound SDK ────────────────────────────────────────────────────────────
sb = ScopeboundSDK(
    base_url=ENFORCEMENT_PLANE_URL,
    api_key=os.environ.get("SCOPEBOUND_API_KEY", ""),
    fail_open=False,
)

# ── Mock database ─────────────────────────────────────────────────────────────
INVOICES = [
    {"id": "INV-001", "vendor": "Acme Corp",    "amount": 12500.00, "status": "pending"},
    {"id": "INV-002", "vendor": "Globex LLC",   "amount":  4200.00, "status": "pending"},
    {"id": "INV-003", "vendor": "Initech Inc",  "amount": 87000.00, "status": "pending"},
]

SENT_EMAILS = []
DELETED_INVOICES = []


# ── Tool definitions ──────────────────────────────────────────────────────────

@enforce(sb, role="invoice-processor")
class ReadInvoicesTool(BaseTool):
    """Read pending invoices from the database."""
    name: str        = "read_invoices"
    description: str = "Read pending invoices from the accounts payable database. Returns a list of invoices with vendor, amount, and status."

    def _run(self, status: str = "pending") -> str:
        results = [inv for inv in INVOICES if inv["status"] == status]
        if not results:
            return f"No invoices with status '{status}' found."
        return json.dumps(results, indent=2)


@enforce(sb, role="invoice-processor")
class SendApprovalEmailTool(BaseTool):
    """Send an invoice approval email to the finance team."""
    name: str        = "send_email"
    description: str = "Send an invoice approval notification email to the finance team. Use this after reviewing an invoice."

    def _run(self, invoice_id: str, recipient: str = "finance@company.com", message: str = "") -> str:
        entry = {
            "timestamp":  datetime.now().isoformat(),
            "invoice_id": invoice_id,
            "recipient":  recipient,
            "message":    message,
        }
        SENT_EMAILS.append(entry)
        return f"✓ Approval email sent for {invoice_id} to {recipient}"


@enforce(sb, role="invoice-processor")
class DeleteInvoiceTool(BaseTool):
    """Delete an invoice from the database."""
    name: str        = "delete_invoice"
    description: str = "Permanently delete an invoice from the database. WARNING: this action is irreversible."

    def _run(self, invoice_id: str) -> str:
        # This should be blocked by Scopebound policy.
        DELETED_INVOICES.append(invoice_id)
        return f"Invoice {invoice_id} deleted."


# ── Demo runner ───────────────────────────────────────────────────────────────

def print_header(title: str) -> None:
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)


def print_step(step: str, detail: str = "") -> None:
    print(f"\n→ {step}")
    if detail:
        print(f"  {detail}")


def step_1_happy_path() -> None:
    """
    Step 1: Happy path
    The agent reads invoices and sends an approval email.
    Both tool calls are within the policy for role 'invoice-processor'.
    """
    print_header("STEP 1: Happy Path — Enforcement Allowing Normal Operations")
    print("""
What you'll see:
  - Agent reads invoices (allowed — read_invoices is in the role policy)
  - Agent sends an approval email (allowed — send_email is in the role policy)
  - Each tool call is enforced in <5ms before execution
  - Audit log updated with every decision
""")

    tools = [ReadInvoicesTool(), SendApprovalEmailTool(), DeleteInvoiceTool()]

    print_step("Simulating: 'Review pending invoices and approve anything under $50k'")
    print()

    # Simulate the tool call sequence the LLM would make
    print("  [Agent thinking...] I need to read the invoices first.")
    time.sleep(0.5)

    print_step("Tool call: read_invoices", "status=pending")
    try:
        result = tools[0]._run(status="pending")
        print(f"  ✓ ALLOWED by Scopebound (role: invoice-processor)")
        print(f"  Result: {result}")
    except ScopeboundDenyError as e:
        print(f"  ✗ DENIED: [{e.deny_code}] {e.reason}")
        return

    print()
    print("  [Agent thinking...] INV-001 ($12,500) and INV-002 ($4,200) are under $50k. Approving.")
    time.sleep(0.5)

    for inv_id in ["INV-001", "INV-002"]:
        print_step(f"Tool call: send_email", f"invoice_id={inv_id}")
        try:
            result = tools[1]._run(
                invoice_id=inv_id,
                recipient="finance@company.com",
                message=f"Invoice {inv_id} approved for payment."
            )
            print(f"  ✓ ALLOWED by Scopebound (role: invoice-processor)")
            print(f"  Result: {result}")
        except ScopeboundDenyError as e:
            print(f"  ✗ DENIED: [{e.deny_code}] {e.reason}")

    print()
    print("─"*60)
    print("✓ Step 1 complete. Two tool calls enforced and allowed.")
    print("  Check your audit log: cat audit.jsonl | python3 -m json.tool")


def step_2_denial() -> None:
    """
    Step 2: Policy denial
    The agent attempts to delete an invoice.
    This is blocked by the OPA policy — delete_invoice is not in the role's allowed_tools.
    """
    print_header("STEP 2: Policy Denial — Agent Attempts Forbidden Action")
    print("""
What you'll see:
  - Agent tries to delete invoice INV-003 (the $87k one)
  - Scopebound intercepts the call BEFORE the tool executes
  - ScopeboundDenyError raised with deny_code=SCOPE_VIOLATION
  - The database record is NOT deleted — enforcement worked
  - Denial recorded in audit log
""")

    tools = [ReadInvoicesTool(), DeleteInvoiceTool()]

    print("  [Agent thinking...] INV-003 is a duplicate. I should delete it.")
    time.sleep(0.5)

    print_step("Tool call: delete_invoice", "invoice_id=INV-003")
    try:
        result = tools[1]._run(invoice_id="INV-003")
        print(f"  Result (should not reach here): {result}")
    except ScopeboundDenyError as e:
        print(f"""
  ✗ DENIED by Scopebound
  ┌─────────────────────────────────────────────────┐
  │  deny_code:      {e.deny_code:<32}│
  │  severity:       {e.severity:<32}│
  │  reason:         {e.reason[:32]:<32}│
  │  retry_guidance: {e.retry_guidance:<32}│
  └─────────────────────────────────────────────────┘""")

    print()
    print(f"  Database integrity check: {len(DELETED_INVOICES)} records deleted (should be 0)")
    assert len(DELETED_INVOICES) == 0, "BUG: delete_invoice executed despite denial!"
    print("  ✓ Confirmed: delete_invoice never executed. Enforcement worked.")

    print()
    print("─"*60)
    print("✓ Step 2 complete. Forbidden tool call intercepted before execution.")
    print()
    print("  Try it yourself: add 'delete_invoice' to the role's allowed_tools")
    print("  via the Management API and re-run — the call will succeed:")
    print()
    print("  curl -X PUT http://localhost:8080/mgmt/v1/roles/invoice-processor \\")
    print("    -H 'X-Scopebound-API-Key: your-key' \\")
    print("    -d '{\"name\":\"invoice-processor\",\"allowed_tools\":[\"read_invoices\",\"send_email\",\"delete_invoice\"]}'")


def step_3_drift() -> None:
    """
    Step 3: Behavioral drift detection
    Simulate an agent that starts calling send_email at high frequency —
    anomalous behaviour that triggers drift detection.
    """
    print_header("STEP 3: Behavioral Drift Detection — Anomalous Agent Behaviour")
    print("""
What you'll see:
  - Agent makes normal tool calls (baseline phase)
  - Agent starts calling send_email at unusual frequency
  - Scopebound drift detector flags the session as DRIFTING
  - At critical threshold, session is auto-revoked
  - Subsequent calls are rejected with JWT_REVOKED
""")

    tool = SendApprovalEmailTool()

    print_step("Phase 1: Normal baseline (20 calls, even distribution)")
    for i in range(20):
        tool_name = "read_invoices" if i % 3 != 0 else "send_email"
        print(f"  Call {i+1:02d}: {tool_name}", end="\r")
        time.sleep(0.05)

    print(f"\n  ✓ Baseline established (20 calls)")

    print()
    print_step("Phase 2: Anomalous behaviour — 30 rapid send_email calls")
    print("  (Simulating a compromised agent sending bulk emails...)")
    print()

    denied_at = None
    for i in range(30):
        try:
            result = tool._run(
                invoice_id=f"INV-{random.randint(100,999)}",
                recipient=f"external-{i}@unknown.com",
                message="Confidential invoice data"
            )
            print(f"  Call {i+1:02d}: send_email → ALLOWED  (drift score rising...)")
        except ScopeboundDenyError as e:
            if denied_at is None:
                denied_at = i + 1
            print(f"  Call {i+1:02d}: send_email → DENIED [{e.deny_code}]")
            if e.deny_code in ("BEHAVIORAL_DRIFT", "SESSION_REVOKED"):
                print(f"\n  🚨 AUTO-REVOCATION triggered at call {denied_at}")
                print(f"     Session revoked. Agent cannot make further calls.")
                break
        time.sleep(0.1)

    print()
    print_step("Check drift status via Management API:")
    print("  curl http://localhost:8080/v1/sessions/drift/{session_id} \\")
    print("    -H 'X-Scopebound-API-Key: your-key'")
    print()
    print("  Expected response:")
    print('  {"session_id":"...","status":"revoked","score":0.94,"call_count":50}')

    print()
    print("─"*60)
    print("✓ Step 3 complete. Drift detection identified and stopped anomalous agent.")
    print()
    print("  Check the audit log for BEHAVIORAL_DRIFT events:")
    print("  cat audit.jsonl | python3 -c \"")
    print("    import sys, json")
    print("    [print(l) for l in sys.stdin if 'DRIFT' in l]\"")


def step_4_audit() -> None:
    """
    Step 4: Audit log inspection
    Show the tamper-evident audit trail.
    """
    print_header("STEP 4: Audit Log — Tamper-Evident Trail of Every Decision")
    print("""
What you'll see:
  - Every tool call (allowed and denied) recorded in audit.jsonl
  - SHA-256 hash chain — tampering any record breaks the chain
  - Chain verification on startup halts the server if tampering detected
""")

    print_step("Inspect the audit log:")
    print("  cat audit.jsonl | python3 -m json.tool | head -60")
    print()
    print("  Each record contains:")
    print("  ┌─────────────────────────────────────────────────────────┐")
    print("  │  timestamp    : ISO-8601                                │")
    print("  │  session_id   : which agent made the call               │")
    print("  │  tool_name    : what was called                         │")
    print("  │  decision     : allow | deny                            │")
    print("  │  deny_code    : SCOPE_VIOLATION | BEHAVIORAL_DRIFT etc  │")
    print("  │  prev_hash    : SHA-256 of previous record              │")
    print("  │  record_hash  : SHA-256 of this record                  │")
    print("  └─────────────────────────────────────────────────────────┘")
    print()
    print_step("Verify chain integrity:")
    print("  curl http://localhost:8080/healthz | python3 -m json.tool")
    print()
    print("  Expected output includes:")
    print('  "last_chain_verified_at": "2026-04-09T10:30:00Z"')
    print()
    print_step("Try tampering (educational only):")
    print("  # Edit a line in audit.jsonl, then restart the server.")
    print("  # You'll see:")
    print("  # audit: CHAIN_VIOLATION detected at record 3 — halting")


def main() -> None:
    parser = argparse.ArgumentParser(description="Scopebound integration demo")
    parser.add_argument("--step", type=int, choices=[1,2,3,4], default=1,
                        help="Which demo step to run (1-4)")
    parser.add_argument("--all", action="store_true",
                        help="Run all steps in sequence")
    args = parser.parse_args()

    print("""
╔═══════════════════════════════════════════════════════════╗
║          Scopebound Integration Demo                      ║
║          Invoice Processing Agent · LangChain             ║
╚═══════════════════════════════════════════════════════════╝

Prerequisites:
  □ Enforcement plane running: go run ./cmd/enforcement-plane/...
  □ Role 'invoice-processor' created with:
      allowed_tools: [read_invoices, send_email]
  □ SB_API_KEY set in environment
  □ pip install scopebound langchain-core
""")

    steps = {1: step_1_happy_path, 2: step_2_denial, 3: step_3_drift, 4: step_4_audit}

    if args.all:
        for fn in steps.values():
            fn()
            input("\n  Press Enter to continue to next step...")
    else:
        steps[args.step]()


if __name__ == "__main__":
    main()
