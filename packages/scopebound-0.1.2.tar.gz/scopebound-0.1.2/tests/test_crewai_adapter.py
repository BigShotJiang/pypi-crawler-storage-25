"""Tests for the CrewAI adapter — SB-15."""
import pytest
import httpx
import respx
from unittest.mock import MagicMock
from langchain_core.tools import BaseTool

from scopebound import ScopeboundSDK
from scopebound.adapters.crewai import CrewEnforcer
from scopebound.exceptions import ScopeboundDenyError

BASE_URL = "http://localhost:8080"

PROVISION_RESPONSE = {
    "jwt":        "header.payload.signature",
    "session_id": "sess-crew-001",
    "expires_at": "2099-01-01T00:00:00Z",
}
ALLOW_RESPONSE = {"decision": "allow", "call_id": "", "latency_ms": 1.0}
DENY_SCOPE     = {
    "decision": "deny", "call_id": "", "deny_code": "SCOPE_VIOLATION",
    "severity": "medium", "reason": "tool not in allowed_tools",
    "retry_guidance": "none", "latency_ms": 1.0,
}

ROLES = {
    "researcher": "read-only-analyst",
    "writer":     "email-sender",
}


# ── AC1: tool _run is intercepted and enforced ────────────────────────────────

@respx.mock
def test_tool_run_enforced():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    enforce_route = respx.post(f"{BASE_URL}/v1/enforce").mock(
        return_value=httpx.Response(200, json=ALLOW_RESPONSE)
    )

    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles=ROLES)

    @enforcer.enforce_tool(agent_role="researcher")
    class SearchTool(BaseTool):
        name: str        = "search"
        description: str = "Search the web"
        def _run(self, query: str = "") -> str:
            return "search results"

    result = SearchTool()._run("AI security")
    assert result == "search results"
    assert enforce_route.called


# ── AC2: allow decision — _run result returned unchanged ─────────────────────

@respx.mock
def test_allow_returns_result():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles=ROLES)

    @enforcer.enforce_tool(agent_role="researcher")
    class DataTool(BaseTool):
        name: str        = "fetch_data"
        description: str = "Fetch data"
        def _run(self, query: str = "") -> str:
            return "fetched: " + query

    result = DataTool()._run("invoices")
    assert result == "fetched: invoices"


# ── AC3: deny raises ScopeboundDenyError (or ToolException if crewai present) ─

@respx.mock
def test_deny_raises_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_SCOPE))

    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles=ROLES)

    @enforcer.enforce_tool(agent_role="researcher")
    class ForbiddenTool(BaseTool):
        name: str        = "delete_records"
        description: str = "Delete records"
        def _run(self, query: str = "") -> str:
            return "should not reach"

    with pytest.raises(Exception) as exc_info:
        ForbiddenTool()._run()

    # Either ScopeboundDenyError or ToolException wrapping it.
    err = exc_info.value
    assert "SCOPE_VIOLATION" in str(err)


# ── AC4: unknown agent_role raises ValueError at decoration time ──────────────

def test_unknown_agent_role_raises():
    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles=ROLES)

    with pytest.raises(ValueError, match="not found in roles dict"):
        @enforcer.enforce_tool(agent_role="unknown_agent")
        class SomeTool(BaseTool):
            name: str        = "some_tool"
            description: str = "Some tool"
            def _run(self, q: str = "") -> str:
                return "ok"


# ── AC5: crew_session provisions all roles at start ──────────────────────────

@respx.mock
def test_crew_session_provisions_all_roles():
    provision_calls = []

    def capture_provision(request):
        import json
        body = json.loads(request.content)
        provision_calls.append(body["role_id"])
        return httpx.Response(200, json=PROVISION_RESPONSE)

    respx.post(f"{BASE_URL}/v1/provision").mock(side_effect=capture_provision)
    respx.delete(f"{BASE_URL}/v1/sessions/sess-crew-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles=ROLES)

    with enforcer.crew_session():
        pass

    assert set(provision_calls) == {"read-only-analyst", "email-sender"}


# ── AC6: crew_session revokes all sessions at exit ───────────────────────────

@respx.mock
def test_crew_session_revokes_on_exit():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    revoke_route = respx.delete(f"{BASE_URL}/v1/sessions/sess-crew-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles=ROLES)

    with enforcer.crew_session():
        pass

    assert revoke_route.called


# ── AC7: crew_session revokes on exception ────────────────────────────────────

@respx.mock
def test_crew_session_revokes_on_exception():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    revoke_route = respx.delete(f"{BASE_URL}/v1/sessions/sess-crew-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles=ROLES)

    with pytest.raises(RuntimeError):
        with enforcer.crew_session():
            raise RuntimeError("crew failed")

    assert revoke_route.called, "sessions must be revoked even when crew raises"


# ── AC8: correct scopebound role sent per agent_role ─────────────────────────

@respx.mock
def test_correct_role_sent_per_agent():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    sent_role_ids = []

    def capture_enforce(request):
        import json
        # Role is in the JWT provisioning step — we check the provision call
        return httpx.Response(200, json=ALLOW_RESPONSE)

    def capture_provision(request):
        import json
        body = json.loads(request.content)
        sent_role_ids.append(body.get("role_id"))
        return httpx.Response(200, json=PROVISION_RESPONSE)

    respx.post(f"{BASE_URL}/v1/provision").mock(side_effect=capture_provision)
    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=capture_enforce)

    sdk      = ScopeboundSDK(base_url=BASE_URL)
    enforcer = CrewEnforcer(sdk, roles={"researcher": "read-only-analyst"})

    @enforcer.enforce_tool(agent_role="researcher")
    class ResearchTool(BaseTool):
        name: str        = "research"
        description: str = "Research tool"
        def _run(self, q: str = "") -> str:
            return "data"

    ResearchTool()._run("test")
    assert "read-only-analyst" in sent_role_ids