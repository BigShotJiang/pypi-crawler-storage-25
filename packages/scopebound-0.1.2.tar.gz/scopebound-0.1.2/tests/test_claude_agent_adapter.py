"""Tests for the Claude Agent SDK adapter."""
import json
import pytest
import httpx
import respx

from scopebound import ScopeboundSDK
from scopebound.adapters.claude_agent import ScopeboundHook, enforce_claude
from scopebound.exceptions import ScopeboundDenyError

BASE_URL = "http://localhost:8080"

PROVISION_RESPONSE = {
    "jwt":        "header.payload.signature",
    "session_id": "sess-claude-001",
    "expires_at": "2099-01-01T00:00:00Z",
}
ALLOW_RESPONSE = {"decision": "allow", "call_id": "", "latency_ms": 1.0}
DENY_RESPONSE  = {
    "decision": "deny", "call_id": "", "deny_code": "SCOPE_VIOLATION",
    "severity": "medium", "reason": "tool not in allowed_tools",
    "retry_guidance": "none", "latency_ms": 1.0,
}


# ── AC1: Hook enforces before tool executes ───────────────────────────────────

@respx.mock
def test_hook_enforces_before_tool():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    enforce_route = respx.post(f"{BASE_URL}/v1/enforce").mock(
        return_value=httpx.Response(200, json=ALLOW_RESPONSE)
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)
    hook = ScopeboundHook(sdk, role="invoice-processor")

    hook.pre_tool_use("read_invoices", {"status": "pending"})
    assert enforce_route.called


# ── AC2: Allow — hook returns None, tool proceeds ─────────────────────────────

@respx.mock
def test_allow_returns_none():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    hook = ScopeboundHook(sdk, role="invoice-processor")

    result = hook.pre_tool_use("read_invoices", {})
    assert result is None


# ── AC3: Deny — raises PermissionError ───────────────────────────────────────

@respx.mock
def test_deny_raises_permission_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    hook = ScopeboundHook(sdk, role="invoice-processor")

    with pytest.raises(PermissionError) as exc_info:
        hook.pre_tool_use("delete_records", {})

    assert "SCOPE_VIOLATION" in str(exc_info.value)


# ── AC4: PermissionError message includes deny_code and reason ────────────────

@respx.mock
def test_permission_error_message():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    hook = ScopeboundHook(sdk, role="invoice-processor")

    with pytest.raises(PermissionError) as exc_info:
        hook.pre_tool_use("delete_records", {})

    msg = str(exc_info.value)
    assert "SCOPE_VIOLATION" in msg
    assert "tool not in allowed_tools" in msg


# ── AC5: Hook callable directly (not just via pre_tool_use) ──────────────────

@respx.mock
def test_hook_callable_directly():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    enforce_route = respx.post(f"{BASE_URL}/v1/enforce").mock(
        return_value=httpx.Response(200, json=ALLOW_RESPONSE)
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)
    hook = ScopeboundHook(sdk, role="invoice-processor")

    hook("read_invoices", {"limit": 10})
    assert enforce_route.called


# ── AC6: enforce_claude returns correct hooks dict ────────────────────────────

def test_enforce_claude_returns_hooks_dict():
    sdk = ScopeboundSDK(base_url=BASE_URL)
    hooks = enforce_claude(sdk, role="invoice-processor")

    assert "PreToolUse" in hooks
    assert callable(hooks["PreToolUse"])


# ── AC7: Tool name sent correctly to enforce ─────────────────────────────────

@respx.mock
def test_tool_name_sent_correctly():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    sent_tool_name = None
    def capture(request):
        nonlocal sent_tool_name
        body = json.loads(request.content)
        sent_tool_name = body.get("tool_name")
        return httpx.Response(200, json=ALLOW_RESPONSE)

    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=capture)
    sdk = ScopeboundSDK(base_url=BASE_URL)
    hook = ScopeboundHook(sdk, role="invoice-processor")

    hook.pre_tool_use("send_approval_email", {"invoice_id": "INV-001"})
    assert sent_tool_name == "send_approval_email"


# ── AC8: enforce_claude hooks dict deny raises PermissionError ───────────────

@respx.mock
def test_enforce_claude_deny_raises():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    hooks = enforce_claude(sdk, role="invoice-processor")

    with pytest.raises(PermissionError):
        hooks["PreToolUse"]("forbidden_tool", {})
