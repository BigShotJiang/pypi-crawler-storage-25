"""Tests for the Semantic Kernel adapter — SB-26."""
import asyncio
import json
import pytest
import httpx
import respx

from scopebound import ScopeboundSDK
from scopebound.adapters.semantic_kernel import enforce_sk
from scopebound.exceptions import ScopeboundDenyError

BASE_URL = "http://localhost:8080"

PROVISION_RESPONSE = {
    "jwt":        "header.payload.signature",
    "session_id": "sess-sk-001",
    "expires_at": "2099-01-01T00:00:00Z",
}
ALLOW_RESPONSE = {"decision": "allow", "call_id": "", "latency_ms": 1.0}
DENY_SCOPE = {
    "decision": "deny", "call_id": "", "deny_code": "SCOPE_VIOLATION",
    "severity": "medium", "reason": "tool not in allowed_tools",
    "retry_guidance": "none", "latency_ms": 1.0,
}


# ── AC1: Sync function enforced before execution ─────────────────────────────

@respx.mock
def test_sync_function_enforced():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    enforce_route = respx.post(f"{BASE_URL}/v1/enforce").mock(
        return_value=httpx.Response(200, json=ALLOW_RESPONSE)
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_sk(sdk, role="invoice-processor")
    def read_invoices(limit: int = 10) -> str:
        return f"found {limit} invoices"

    result = read_invoices(limit=5)
    assert result == "found 5 invoices"
    assert enforce_route.called


# ── AC2: Async function enforced before execution ────────────────────────────

@respx.mock
def test_async_function_enforced():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    enforce_route = respx.post(f"{BASE_URL}/v1/enforce").mock(
        return_value=httpx.Response(200, json=ALLOW_RESPONSE)
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_sk(sdk, role="invoice-processor")
    async def async_read_invoices(limit: int = 10) -> str:
        return f"found {limit} invoices async"

    result = asyncio.run(async_read_invoices(limit=3))
    assert result == "found 3 invoices async"
    assert enforce_route.called


# ── AC3: Deny raises ScopeboundDenyError ─────────────────────────────────────

@respx.mock
def test_deny_raises_deny_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_SCOPE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_sk(sdk, role="invoice-processor")
    def forbidden_tool() -> str:
        return "should not reach"

    with pytest.raises(ScopeboundDenyError) as exc_info:
        forbidden_tool()

    assert exc_info.value.deny_code == "SCOPE_VIOLATION"


# ── AC4: Async deny raises ScopeboundDenyError ───────────────────────────────

@respx.mock
def test_async_deny_raises_deny_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_SCOPE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_sk(sdk, role="invoice-processor")
    async def async_forbidden() -> str:
        return "should not reach"

    with pytest.raises(ScopeboundDenyError):
        asyncio.run(async_forbidden())


# ── AC5: Function name and docstring preserved ───────────────────────────────

def test_metadata_preserved():
    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_sk(sdk, role="invoice-processor")
    def my_sk_tool(query: str = "") -> str:
        """My Semantic Kernel tool description."""
        return "ok"

    assert my_sk_tool.__name__ == "my_sk_tool"
    assert "Semantic Kernel" in my_sk_tool.__doc__


# ── AC6: Tool name sent correctly to enforce ─────────────────────────────────

@respx.mock
def test_tool_name_sent_correctly():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    sent_tool_name = None
    def capture(request):
        nonlocal sent_tool_name
        body = json.loads(request.content)
        sent_tool_name = body.get("tool_name")
        return httpx.Response(200, json=ALLOW_RESPONSE)

    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=capture)
    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_sk(sdk, role="invoice-processor")
    def search_knowledge_base(query: str = "") -> str:
        return "results"

    search_knowledge_base("test")
    assert sent_tool_name == "search_knowledge_base"


# ── AC7: Works as method on plugin class ────────────────────────────────────

@respx.mock
def test_works_as_class_method():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    class InvoicePlugin:
        @enforce_sk(sdk, role="invoice-processor")
        def read_invoices(self, limit: int = 10) -> str:
            return f"found {limit} invoices"

    plugin = InvoicePlugin()
    result = plugin.read_invoices(limit=7)
    assert result == "found 7 invoices"


# ── AC8: Pipeline with two plugins — allowed succeeds, denied raises ──────────

@respx.mock
def test_pipeline_allow_and_deny():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    call_count = 0
    def enforce_handler(request):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(200, json=ALLOW_RESPONSE)
        return httpx.Response(200, json=DENY_SCOPE)

    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=enforce_handler)
    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_sk(sdk, role="invoice-processor")
    def allowed_tool() -> str:
        return "allowed result"

    @enforce_sk(sdk, role="invoice-processor")
    def denied_tool() -> str:
        return "should not reach"

    assert allowed_tool() == "allowed result"

    with pytest.raises(ScopeboundDenyError):
        denied_tool()
