"""Tests for ScopeboundSDK — SB-13 AC1-AC9."""
import pytest
import httpx
from unittest.mock import patch
import respx

from scopebound import ScopeboundSDK
from scopebound.exceptions import ScopeboundDenyError, ScopeboundTimeoutError, ScopeboundUnavailableError

BASE_URL = "http://localhost:8080"

PROVISION_RESPONSE = {
    "jwt":        "header.payload.signature",
    "session_id": "sess-test-001",
    "expires_at": "2099-01-01T00:00:00Z",
}

ALLOW_RESPONSE = {"decision": "allow", "call_id": "call-001", "latency_ms": 1.2}

DENY_SCOPE = {
    "decision":       "deny",
    "call_id":        "call-001",
    "deny_code":      "SCOPE_VIOLATION",
    "severity":       "medium",
    "reason":         "tool not in allowed_tools",
    "retry_guidance": "none",
    "latency_ms":     1.1,
}

DENY_EXPIRED = {
    "decision":       "deny",
    "call_id":        "call-001",
    "deny_code":      "JWT_EXPIRED",
    "severity":       "low",
    "reason":         "token has expired",
    "retry_guidance": "re-provision",
    "latency_ms":     0.9,
}


# ── AC1: provision returns JWT and stores session ─────────────────────────────

@respx.mock
def test_provision_returns_jwt():
    respx.post(f"{BASE_URL}/v1/provision").mock(
        return_value=httpx.Response(200, json=PROVISION_RESPONSE)
    )
    sdk = ScopeboundSDK(base_url=BASE_URL)
    jwt = sdk.provision(role_id="invoice-processor")

    assert jwt == "header.payload.signature"
    assert sdk._session_id == "sess-test-001"


# ── AC2: enforce allow — _run() is called ─────────────────────────────────────

@respx.mock
def test_enforce_allow_does_not_raise():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    # Should not raise
    sdk.enforce(role_id="invoice-processor", tool_name="read_db", call_args={"limit": 10})


# ── AC3: enforce deny raises ScopeboundDenyError ─────────────────────────────

@respx.mock
def test_enforce_deny_raises_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_SCOPE))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    with pytest.raises(ScopeboundDenyError) as exc_info:
        sdk.enforce(role_id="invoice-processor", tool_name="forbidden_tool")

    err = exc_info.value
    assert err.deny_code == "SCOPE_VIOLATION"
    assert err.severity == "medium"
    assert err.retry_guidance == "none"
    assert "tool not in allowed_tools" in err.reason


# ── AC4: JWT_EXPIRED triggers re-provision and retry ─────────────────────────

@respx.mock
def test_jwt_expired_reprovisions_and_retries():
    provision_calls = 0

    def provision_handler(request):
        nonlocal provision_calls
        provision_calls += 1
        return httpx.Response(200, json=PROVISION_RESPONSE)

    enforce_calls = 0

    def enforce_handler(request):
        nonlocal enforce_calls
        enforce_calls += 1
        if enforce_calls == 1:
            return httpx.Response(200, json=DENY_EXPIRED)
        return httpx.Response(200, json=ALLOW_RESPONSE)

    respx.post(f"{BASE_URL}/v1/provision").mock(side_effect=provision_handler)
    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=enforce_handler)

    sdk = ScopeboundSDK(base_url=BASE_URL)
    sdk.enforce(role_id="invoice-processor", tool_name="read_db")

    assert provision_calls == 2, "should re-provision once on JWT_EXPIRED"
    assert enforce_calls == 2,   "should retry enforce after re-provision"


# ── AC5: session is lazily provisioned on first enforce call ──────────────────

@respx.mock
def test_session_provisioned_lazily():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    assert sdk._jwt is None, "JWT must be None before first enforce call"

    sdk.enforce(role_id="invoice-processor", tool_name="read_db")
    assert sdk._jwt is not None, "JWT must be set after first enforce call"


# ── AC6: revoke sends DELETE /v1/sessions/{id} ────────────────────────────────

@respx.mock
def test_revoke_sends_delete():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    revoke_route = respx.delete(f"{BASE_URL}/v1/sessions/sess-test-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)
    sdk.provision(role_id="invoice-processor")
    sdk.revoke()

    assert revoke_route.called
    assert sdk._jwt is None
    assert sdk._session_id is None


# ── AC7: context manager revokes on exit ─────────────────────────────────────

@respx.mock
def test_context_manager_revokes():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))
    revoke_route = respx.delete(f"{BASE_URL}/v1/sessions/sess-test-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    with ScopeboundSDK(base_url=BASE_URL) as sdk:
        sdk.enforce(role_id="invoice-processor", tool_name="read_db")

    assert revoke_route.called


# ── AC8: timeout raises ScopeboundTimeoutError ────────────────────────────────

@respx.mock
def test_timeout_raises_timeout_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(side_effect=httpx.TimeoutException("timeout"))

    sdk = ScopeboundSDK(base_url=BASE_URL)
    with pytest.raises(ScopeboundTimeoutError):
        sdk.provision(role_id="invoice-processor")


# ── AC9: fail_open=True allows tool calls when enforcement plane is down ──────

@respx.mock
def test_fail_open_allows_when_unreachable():
    respx.post(f"{BASE_URL}/v1/provision").mock(side_effect=httpx.ConnectError("refused"))

    sdk = ScopeboundSDK(base_url=BASE_URL, fail_open=True)
    # Should not raise even though provision fails
    sdk.enforce(role_id="invoice-processor", tool_name="read_db")


# ── fail_closed=True raises when unreachable (default) ───────────────────────

@respx.mock
def test_fail_closed_raises_when_unreachable():
    respx.post(f"{BASE_URL}/v1/provision").mock(side_effect=httpx.ConnectError("refused"))

    sdk = ScopeboundSDK(base_url=BASE_URL, fail_open=False)
    with pytest.raises(ScopeboundUnavailableError):
        sdk.enforce(role_id="invoice-processor", tool_name="read_db")