"""Tests for the AutoGen adapter — SB-25."""
import json
import pytest
import httpx
import respx

from scopebound import ScopeboundSDK
from scopebound.adapters.autogen import enforce_autogen, AutoGenSession
from scopebound.exceptions import ScopeboundDenyError

BASE_URL = "http://localhost:8080"

PROVISION_RESPONSE = {
    "jwt":        "header.payload.signature",
    "session_id": "sess-ag-001",
    "expires_at": "2099-01-01T00:00:00Z",
}
ALLOW_RESPONSE = {"decision": "allow", "call_id": "", "latency_ms": 1.0}
DENY_SCOPE = {
    "decision": "deny", "call_id": "", "deny_code": "SCOPE_VIOLATION",
    "severity": "medium", "reason": "tool not in allowed_tools",
    "retry_guidance": "none", "latency_ms": 1.0,
}
ROLES = {"researcher": "read-only-analyst", "writer": "email-sender"}


# ── AC1: Decorated function is enforced before execution ─────────────────────

@respx.mock
def test_enforce_autogen_called_before_function():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    enforce_route = respx.post(f"{BASE_URL}/v1/enforce").mock(
        return_value=httpx.Response(200, json=ALLOW_RESPONSE)
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_autogen(sdk, role="read-only-analyst")
    def search_web(query: str = "") -> str:
        return "search results"

    result = search_web("AI security")
    assert result == "search results"
    assert enforce_route.called


# ── AC2: Allow decision — function result returned unchanged ─────────────────

@respx.mock
def test_allow_returns_result():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_autogen(sdk, role="read-only-analyst")
    def fetch_data(limit: int = 10) -> str:
        return f"fetched {limit} items"

    assert fetch_data(limit=5) == "fetched 5 items"


# ── AC3: Deny returns structured error dict ───────────────────────────────────

@respx.mock
def test_deny_returns_error_dict():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_SCOPE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_autogen(sdk, role="read-only-analyst")
    def delete_records() -> str:
        return "should not reach"

    result = delete_records()
    assert isinstance(result, dict)
    assert result["error"] == "SCOPE_VIOLATION"
    assert "reason" in result
    assert "retry_guidance" in result


# ── AC4: Function name preserved after decoration ────────────────────────────

@respx.mock
def test_function_name_preserved():
    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_autogen(sdk, role="read-only-analyst")
    def my_special_tool(query: str = "") -> str:
        """My special tool docstring."""
        return "ok"

    assert my_special_tool.__name__ == "my_special_tool"
    assert "My special tool" in my_special_tool.__doc__


# ── AC5: Tool name sent correctly to enforce ─────────────────────────────────

@respx.mock
def test_tool_name_sent_correctly():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    sent_tool_name = None
    def capture(request):
        nonlocal sent_tool_name
        body = json.loads(request.content)
        sent_tool_name = body.get("tool_name")
        return httpx.Response(200, json=ALLOW_RESPONSE)

    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=capture)
    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce_autogen(sdk, role="read-only-analyst")
    def read_database(query: str = "") -> str:
        return "data"

    read_database("test")
    assert sent_tool_name == "read_database"


# ── AC6: AutoGenSession provisions all roles at entry ────────────────────────

@respx.mock
def test_autogen_session_provisions_all_roles():
    provision_calls = []
    def capture_provision(request):
        body = json.loads(request.content)
        provision_calls.append(body["role_id"])
        return httpx.Response(200, json=PROVISION_RESPONSE)

    respx.post(f"{BASE_URL}/v1/provision").mock(side_effect=capture_provision)
    respx.delete(f"{BASE_URL}/v1/sessions/sess-ag-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)
    with AutoGenSession(sdk, roles=ROLES):
        pass

    assert set(provision_calls) == {"read-only-analyst", "email-sender"}


# ── AC7: AutoGenSession revokes on exit ──────────────────────────────────────

@respx.mock
def test_autogen_session_revokes_on_exit():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    revoke_route = respx.delete(f"{BASE_URL}/v1/sessions/sess-ag-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)
    with AutoGenSession(sdk, roles=ROLES):
        pass

    assert revoke_route.called


# ── AC8: AutoGenSession revokes on exception ─────────────────────────────────

@respx.mock
def test_autogen_session_revokes_on_exception():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    revoke_route = respx.delete(f"{BASE_URL}/v1/sessions/sess-ag-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)
    with pytest.raises(RuntimeError):
        with AutoGenSession(sdk, roles=ROLES):
            raise RuntimeError("conversation failed")

    assert revoke_route.called


# ── AC9: Unknown agent role raises ValueError ────────────────────────────────

def test_unknown_agent_role_raises():
    sdk = ScopeboundSDK(base_url=BASE_URL)
    session = AutoGenSession(sdk, roles=ROLES)

    with pytest.raises(ValueError, match="not found in roles dict"):
        @session.enforce_tool("unknown_agent")
        def some_tool() -> str:
            return "ok"
