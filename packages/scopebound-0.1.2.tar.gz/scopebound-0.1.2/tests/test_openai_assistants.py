"""Tests for the OpenAI Assistants adapter — SB-14."""
import json
import pytest
import httpx
import respx
from unittest.mock import MagicMock

from scopebound import ScopeboundSDK
from scopebound.adapters.openai_assistants import ScopeboundSession
from scopebound.exceptions import ScopeboundDenyError

BASE_URL = "http://localhost:8080"

PROVISION_RESPONSE = {
    "jwt":        "header.payload.signature",
    "session_id": "sess-oai-001",
    "expires_at": "2099-01-01T00:00:00Z",
}
ALLOW_RESPONSE = {"decision": "allow", "call_id": "", "latency_ms": 1.0}
DENY_SCOPE     = {
    "decision": "deny", "call_id": "", "deny_code": "SCOPE_VIOLATION",
    "severity": "medium", "reason": "tool not in allowed_tools",
    "retry_guidance": "none", "latency_ms": 1.0,
}


def make_tool_call(tool_call_id: str, name: str, arguments: dict) -> MagicMock:
    """Build a mock ToolCall matching the OpenAI SDK structure."""
    tc = MagicMock()
    tc.id = tool_call_id
    tc.function.name = name
    tc.function.arguments = json.dumps(arguments)
    return tc


# ── AC1: allowed call — handler is dispatched and output returned ─────────────

@respx.mock
def test_allowed_call_dispatches_handler():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk     = ScopeboundSDK(base_url=BASE_URL)
    session = ScopeboundSession(sdk, role="invoice-processor")

    tool_call = make_tool_call("call_abc123", "read_invoices", {"limit": 10})

    def read_invoices_handler(tool_name, args):
        limit = args['limit']
        return f"found {limit} invoices"

    outputs = session.execute_tool_calls(
        tool_calls=[tool_call],
        handlers={"read_invoices": read_invoices_handler},
    )

    assert len(outputs) == 1
    assert outputs[0]["tool_call_id"] == "call_abc123"
    assert outputs[0]["output"] == "found 10 invoices"


# ── AC2: denied call — error JSON submitted, run continues ───────────────────

@respx.mock
def test_denied_call_submits_error_json():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_SCOPE))

    sdk     = ScopeboundSDK(base_url=BASE_URL)
    session = ScopeboundSession(sdk, role="invoice-processor")

    tool_call = make_tool_call("call_denied", "forbidden_tool", {})
    handler_called = False

    def forbidden_handler(tool_name, args):
        nonlocal handler_called
        handler_called = True
        return "should not reach"

    outputs = session.execute_tool_calls(
        tool_calls=[tool_call],
        handlers={"forbidden_tool": forbidden_handler},
    )

    assert len(outputs) == 1
    assert outputs[0]["tool_call_id"] == "call_denied"

    output = json.loads(outputs[0]["output"])
    assert output["error"] == "SCOPE_VIOLATION"
    assert "reason" in output
    assert "retry_guidance" in output
    assert not handler_called, "handler must NOT be called on deny"


# ── AC3: tool_call.id used as call_id for audit correlation ──────────────────

@respx.mock
def test_tool_call_id_sent_as_call_id():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    sent_call_id = None
    def capture(request):
        nonlocal sent_call_id
        body = json.loads(request.content)
        sent_call_id = body.get("call_id")
        return httpx.Response(200, json=ALLOW_RESPONSE)

    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=capture)

    sdk     = ScopeboundSDK(base_url=BASE_URL)
    session = ScopeboundSession(sdk, role="invoice-processor")

    tool_call = make_tool_call("call_unique_id_xyz", "read_invoices", {})
    session.execute_tool_calls(
        tool_calls=[tool_call],
        handlers={"read_invoices": lambda n, a: "ok"},
    )

    assert sent_call_id == "call_unique_id_xyz"


# ── AC4: multiple tool calls in one batch ────────────────────────────────────

@respx.mock
def test_multiple_tool_calls_in_batch():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    enforce_responses = [
        httpx.Response(200, json=ALLOW_RESPONSE),
        httpx.Response(200, json=DENY_SCOPE),
    ]
    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=enforce_responses)

    sdk     = ScopeboundSDK(base_url=BASE_URL)
    session = ScopeboundSession(sdk, role="invoice-processor")

    tool_calls = [
        make_tool_call("call_001", "read_invoices", {"limit": 5}),
        make_tool_call("call_002", "forbidden_tool", {}),
    ]

    outputs = session.execute_tool_calls(
        tool_calls=tool_calls,
        handlers={
            "read_invoices":  lambda n, a: "invoice data",
            "forbidden_tool": lambda n, a: "should not reach",
        },
    )

    assert len(outputs) == 2
    assert outputs[0]["tool_call_id"] == "call_001"
    assert outputs[0]["output"] == "invoice data"

    assert outputs[1]["tool_call_id"] == "call_002"
    denied = json.loads(outputs[1]["output"])
    assert denied["error"] == "SCOPE_VIOLATION"


# ── AC5: missing handler returns error JSON ───────────────────────────────────

@respx.mock
def test_missing_handler_returns_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk     = ScopeboundSDK(base_url=BASE_URL)
    session = ScopeboundSession(sdk, role="invoice-processor")

    tool_call = make_tool_call("call_no_handler", "unregistered_tool", {})
    outputs = session.execute_tool_calls(
        tool_calls=[tool_call],
        handlers={},  # no handlers registered
    )

    output = json.loads(outputs[0]["output"])
    assert output["error"] == "HANDLER_NOT_FOUND"
    assert "unregistered_tool" in output["reason"]


# ── AC6: context manager revokes session on exit ─────────────────────────────

@respx.mock
def test_context_manager_revokes():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))
    revoke_route = respx.delete(f"{BASE_URL}/v1/sessions/sess-oai-001").mock(
        return_value=httpx.Response(200, json={"status": "revoked"})
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)
    with ScopeboundSession(sdk, role="invoice-processor") as session:
        tool_call = make_tool_call("call_cm", "read_invoices", {})
        session.execute_tool_calls(
            tool_calls=[tool_call],
            handlers={"read_invoices": lambda n, a: "ok"},
        )

    assert revoke_route.called


# ── AC7: sync and async client both supported (sync verified here) ────────────

@respx.mock
def test_sync_client_supported():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk     = ScopeboundSDK(base_url=BASE_URL)
    session = ScopeboundSession(sdk, role="invoice-processor")

    tool_call = make_tool_call("call_sync", "read_invoices", {"limit": 1})
    outputs = session.execute_tool_calls(
        tool_calls=[tool_call],
        handlers={"read_invoices": lambda n, a: "sync result"},
    )
    assert outputs[0]["output"] == "sync result"