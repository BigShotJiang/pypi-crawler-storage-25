"""Tests for the LangChain @enforce decorator — SB-13."""
import pytest
import httpx
import respx

from langchain_core.tools import BaseTool
from scopebound import ScopeboundSDK, enforce
from scopebound.exceptions import ScopeboundDenyError

BASE_URL = "http://localhost:8080"

PROVISION_RESPONSE = {
    "jwt":        "header.payload.signature",
    "session_id": "sess-lc-001",
    "expires_at": "2099-01-01T00:00:00Z",
}

ALLOW_RESPONSE = {"decision": "allow", "call_id": "", "latency_ms": 1.0}
DENY_SCOPE     = {
    "decision": "deny", "call_id": "", "deny_code": "SCOPE_VIOLATION",
    "severity": "medium", "reason": "tool not allowed", "retry_guidance": "none",
}


# ── AC1: decorated tool calls enforce before _run ────────────────────────────

@respx.mock
def test_enforce_called_before_run():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    enforce_route = respx.post(f"{BASE_URL}/v1/enforce").mock(
        return_value=httpx.Response(200, json=ALLOW_RESPONSE)
    )

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce(sdk, role="invoice-processor")
    class TestTool(BaseTool):
        name: str        = "test_tool"
        description: str = "A test tool"
        def _run(self, query: str = "") -> str:
            return "result"

    tool = TestTool()
    result = tool._run("hello")

    assert result == "result"
    assert enforce_route.called


# ── AC2: allow decision — _run result returned unchanged ─────────────────────

@respx.mock
def test_allow_returns_result_unchanged():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce(sdk, role="invoice-processor")
    class CalculatorTool(BaseTool):
        name: str        = "calculator"
        description: str = "Does math"
        def _run(self, x: int = 0, y: int = 0) -> int:
            return x + y

    tool   = CalculatorTool()
    result = tool._run(x=2, y=3)
    assert result == 5


# ── AC3: deny decision raises ScopeboundDenyError ────────────────────────────

@respx.mock
def test_deny_raises_scopebound_deny_error():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=DENY_SCOPE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce(sdk, role="invoice-processor")
    class ForbiddenTool(BaseTool):
        name: str        = "forbidden_tool"
        description: str = "Not allowed"
        def _run(self, query: str = "") -> str:
            return "should not reach here"

    tool = ForbiddenTool()
    with pytest.raises(ScopeboundDenyError) as exc_info:
        tool._run("test")

    assert exc_info.value.deny_code == "SCOPE_VIOLATION"


# ── AC4: tool_name in enforce request matches BaseTool.name ──────────────────

@respx.mock
def test_tool_name_sent_correctly():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))

    sent_tool_name = None
    def capture_enforce(request):
        nonlocal sent_tool_name
        import json
        body = json.loads(request.content)
        sent_tool_name = body.get("tool_name")
        return httpx.Response(200, json=ALLOW_RESPONSE)

    respx.post(f"{BASE_URL}/v1/enforce").mock(side_effect=capture_enforce)

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce(sdk, role="invoice-processor")
    class MySpecialTool(BaseTool):
        name: str        = "my_special_tool"
        description: str = "Special tool"
        def _run(self, query: str = "") -> str:
            return "ok"

    MySpecialTool()._run("test")
    assert sent_tool_name == "my_special_tool"


# ── AC5: multiple tools use the same SDK instance ────────────────────────────

@respx.mock
def test_multiple_tools_same_sdk():
    respx.post(f"{BASE_URL}/v1/provision").mock(return_value=httpx.Response(200, json=PROVISION_RESPONSE))
    respx.post(f"{BASE_URL}/v1/enforce").mock(return_value=httpx.Response(200, json=ALLOW_RESPONSE))

    sdk = ScopeboundSDK(base_url=BASE_URL)

    @enforce(sdk, role="invoice-processor")
    class ToolA(BaseTool):
        name: str = "tool_a"; description: str = "A"
        def _run(self, q: str = "") -> str: return "a"

    @enforce(sdk, role="invoice-processor")
    class ToolB(BaseTool):
        name: str = "tool_b"; description: str = "B"
        def _run(self, q: str = "") -> str: return "b"

    assert ToolA()._run() == "a"
    assert ToolB()._run() == "b"