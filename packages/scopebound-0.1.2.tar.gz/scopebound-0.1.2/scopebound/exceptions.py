class ScopeboundError(Exception):
    """Base exception for all Scopebound errors."""

class ScopeboundDenyError(ScopeboundError):
    def __init__(self, deny_code, severity, reason, retry_guidance, call_id=""):
        self.deny_code = deny_code
        self.severity = severity
        self.reason = reason
        self.retry_guidance = retry_guidance
        self.call_id = call_id
        super().__init__(f"[{deny_code}] {reason} (retry: {retry_guidance})")

class ScopeboundTimeoutError(ScopeboundError):
    """Raised when the enforcement plane does not respond within the timeout."""

class ScopeboundUnavailableError(ScopeboundError):
    """Raised when the enforcement plane is unreachable and fail_open=False."""
