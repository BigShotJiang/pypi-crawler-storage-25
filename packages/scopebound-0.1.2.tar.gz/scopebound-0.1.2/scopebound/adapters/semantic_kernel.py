from __future__ import annotations

import atexit
import functools
import uuid
from typing import Any, Callable

from ..client import ScopeboundSDK
from ..exceptions import ScopeboundDenyError


def enforce_sk(sdk: ScopeboundSDK, role: str) -> Callable:
    """
    Decorator that wraps a Semantic Kernel plugin function with Scopebound
    enforcement. Intercepts invocation before the function executes.

    Works with both sync and async kernel functions. Compatible with
    @kernel_function decorated functions.

    Usage:
        sb = ScopeboundSDK(base_url="http://localhost:8080")

        class InvoicePlugin:
            @enforce_sk(sb, role="invoice-processor")
            @kernel_function(description="Read invoices from the database")
            def read_invoices(self, limit: int = 10) -> str:
                return f"found {limit} invoices"

        kernel.add_plugin(InvoicePlugin(), plugin_name="invoice")

    On deny, raises ScopeboundDenyError which propagates through the
    Semantic Kernel invocation chain.

    Args:
        sdk:  A ScopeboundSDK instance.
        role: The Scopebound role ID to enforce against.
    """
    def decorator(func: Callable) -> Callable:
        if _is_async(func):
            @functools.wraps(func)
            async def async_wrapped(*args: Any, **kwargs: Any) -> Any:
                call_id = str(uuid.uuid4())[:8]
                sdk.enforce(
                    role_id=role,
                    tool_name=func.__name__,
                    call_args=_extract_args(args, kwargs),
                    call_id=call_id,
                )
                return await func(*args, **kwargs)
            atexit.register(sdk.revoke)
            return async_wrapped
        else:
            @functools.wraps(func)
            def sync_wrapped(*args: Any, **kwargs: Any) -> Any:
                call_id = str(uuid.uuid4())[:8]
                sdk.enforce(
                    role_id=role,
                    tool_name=func.__name__,
                    call_args=_extract_args(args, kwargs),
                    call_id=call_id,
                )
                return func(*args, **kwargs)
            atexit.register(sdk.revoke)
            return sync_wrapped

    return decorator


def _is_async(func: Callable) -> bool:
    """Returns True if func is a coroutine function."""
    import asyncio
    return asyncio.iscoroutinefunction(func)


def _extract_args(args: tuple, kwargs: dict) -> dict[str, Any]:
    result: dict[str, Any] = {}
    # Skip self/cls for method calls.
    positional = [a for a in args if not _is_instance_arg(a)]
    if positional:
        result["args"] = positional
    result.update(kwargs)
    return result


def _is_instance_arg(arg: Any) -> bool:
    """Heuristic: skip the first arg if it looks like a plugin instance."""
    return hasattr(arg, "__dict__") and not isinstance(arg, (str, int, float, list, dict))
