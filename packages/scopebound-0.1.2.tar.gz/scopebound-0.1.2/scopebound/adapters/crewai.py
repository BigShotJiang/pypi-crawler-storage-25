import atexit
import functools
import uuid
from contextlib import contextmanager
from typing import Any, Generator

from ..client import ScopeboundSDK
from ..exceptions import ScopeboundDenyError


class CrewEnforcer:
    """
    Wraps CrewAI BaseTool subclasses with Scopebound enforcement and manages
    session lifecycle around crew.kickoff() runs.

    Usage:
        sb = ScopeboundSDK(base_url="http://localhost:8080")

        enforcer = CrewEnforcer(sb, roles={
            "researcher": "read-only-analyst",
            "writer":     "email-sender",
        })

        # Wrap individual tools:
        @enforcer.enforce_tool(agent_role="researcher")
        class SearchTool(BaseTool):
            name: str        = "search"
            description: str = "Search the web"
            def _run(self, query: str = "") -> str:
                return "results"

        # Run the crew with automatic session lifecycle:
        with enforcer.crew_session():
            result = crew.kickoff()
    """

    def __init__(self, sdk: ScopeboundSDK, roles: dict[str, str]):
        """
        Args:
            sdk:   A ScopeboundSDK instance shared across the crew run.
            roles: Dict mapping CrewAI agent role names to Scopebound role IDs.
                   Example: {"researcher": "read-only-analyst", "writer": "email-sender"}
        """
        self.sdk   = sdk
        self.roles = roles
        self._active_sessions: list[str] = []

    def enforce_tool(self, agent_role: str):
        """
        Class decorator that wraps a CrewAI BaseTool with Scopebound enforcement.

        Args:
            agent_role: The CrewAI agent role name (key in the roles dict).

        Raises:
            ValueError: If agent_role is not in the roles dict.
        """
        if agent_role not in self.roles:
            raise ValueError(
                f"Agent role {agent_role!r} not found in roles dict. "
                f"Available roles: {list(self.roles.keys())}"
            )
        scopebound_role = self.roles[agent_role]

        def decorator(cls):
            original_run  = cls._run
            original_arun = getattr(cls, "_arun", None)

            @functools.wraps(original_run)
            def wrapped_run(self_tool, *args, **kwargs):
                call_id = str(uuid.uuid4())[:8]
                call_args = _extract_args(args, kwargs)
                try:
                    self.sdk.enforce(
                        role_id   = scopebound_role,
                        tool_name = self_tool.name,
                        call_args = call_args,
                        call_id   = call_id,
                    )
                except ScopeboundDenyError as e:
                    # CrewAI expects ToolException on tool failure.
                    # Import lazily so crewai is not a hard dependency.
                    raise _make_tool_exception(e) from e
                return original_run(self_tool, *args, **kwargs)

            cls._run = wrapped_run

            if original_arun is not None:
                @functools.wraps(original_arun)
                async def wrapped_arun(self_tool, *args, **kwargs):
                    call_id = str(uuid.uuid4())[:8]
                    call_args = _extract_args(args, kwargs)
                    try:
                        self.sdk.enforce(
                            role_id   = scopebound_role,
                            tool_name = self_tool.name,
                            call_args = call_args,
                            call_id   = call_id,
                        )
                    except ScopeboundDenyError as e:
                        raise _make_tool_exception(e) from e
                    return await original_arun(self_tool, *args, **kwargs)

                cls._arun = wrapped_arun

            return cls

        return decorator

    @contextmanager
    def crew_session(self) -> Generator[None, None, None]:
        """
        Context manager that provisions sessions for all roles at entry
        and revokes them at exit.

        Usage:
            with enforcer.crew_session():
                crew.kickoff()
        """
        # Provision a session for each role at kickoff start.
        for scopebound_role in self.roles.values():
            self.sdk.provision(role_id=scopebound_role)

        try:
            yield
        finally:
            # Revoke all sessions at kickoff end.
            self.sdk.revoke()
            self._active_sessions.clear()

    def revoke_all(self) -> None:
        """Revoke all active sessions. Called by atexit handler."""
        self.sdk.revoke()


def _extract_args(args: tuple, kwargs: dict) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if args:
        result["args"] = list(args)
    result.update(kwargs)
    return result


def _make_tool_exception(deny_error: ScopeboundDenyError) -> Exception:
    """
    Wrap ScopeboundDenyError in a CrewAI ToolException if crewai is installed,
    otherwise re-raise the original error. This allows CrewAI error handling
    to work correctly while keeping crewai as an optional dependency.
    """
    try:
        from crewai.tools.tool_usage import ToolException
        return ToolException(str(deny_error))
    except ImportError:
        return deny_error