from __future__ import annotations
import atexit
import functools
import uuid
from typing import Any, Callable, Type, TypeVar
from langchain_core.tools import BaseTool
from ..client import ScopeboundSDK
from ..exceptions import ScopeboundDenyError

T = TypeVar("T", bound=BaseTool)


def enforce(sdk: ScopeboundSDK, role: str) -> Callable:
    """Class decorator that wraps a LangChain BaseTool with Scopebound enforcement."""
    def decorator(cls):
        original_run = cls._run
        original_arun = getattr(cls, "_arun", None)

        @functools.wraps(original_run)
        def wrapped_run(self, *args, **kwargs):
            call_id = str(uuid.uuid4())[:8]
            sdk.enforce(
                role_id=role,
                tool_name=self.name,
                call_args=_extract_args(args, kwargs),
                call_id=call_id,
            )
            return original_run(self, *args, **kwargs)

        cls._run = wrapped_run

        if original_arun is not None:
            @functools.wraps(original_arun)
            async def wrapped_arun(self, *args, **kwargs):
                call_id = str(uuid.uuid4())[:8]
                sdk.enforce(
                    role_id=role,
                    tool_name=self.name,
                    call_args=_extract_args(args, kwargs),
                    call_id=call_id,
                )
                return await original_arun(self, *args, **kwargs)
            cls._arun = wrapped_arun

        atexit.register(sdk.revoke)
        return cls

    return decorator


def _extract_args(args, kwargs):
    result = {}
    if args:
        result["args"] = list(args)
    result.update(kwargs)
    return result
