import json
from typing import Any, Callable

from ..client import ScopeboundSDK
from ..exceptions import ScopeboundDenyError


# Type aliases matching the OpenAI SDK structures we interact with.
# We use duck typing rather than importing openai directly so the adapter
# works without openai as a hard dependency.
ToolCall = Any   # openai.types.beta.threads.required_action_submit_tool_outputs.ToolCall
Handler  = Callable[[str, dict], str]  # handler(tool_name, arguments) -> output


class ScopeboundSession:
    """
    Wraps the OpenAI Assistants API run polling loop with Scopebound enforcement.

    Usage:
        sb  = ScopeboundSDK(base_url="http://localhost:8080")
        session = ScopeboundSession(sb, role="invoice-processor")

        # In your run polling loop:
        tool_outputs = session.execute_tool_calls(
            tool_calls=run.required_action.submit_tool_outputs.tool_calls,
            handlers={
                "read_invoices": read_invoices_handler,
                "send_email":    send_email_handler,
            }
        )
        client.beta.threads.runs.submit_tool_outputs(
            thread_id=thread.id,
            run_id=run.id,
            tool_outputs=tool_outputs,
        )

    Denied tool calls are submitted as structured error JSON so the LLM
    can handle them gracefully rather than causing the run to fail.
    """

    def __init__(self, sdk: ScopeboundSDK, role: str):
        """
        Args:
            sdk:  A ScopeboundSDK instance. The session JWT is provisioned
                  lazily on the first execute_tool_calls() call and reused.
            role: The agent role to enforce against.
        """
        self.sdk  = sdk
        self.role = role

    def execute_tool_calls(
        self,
        tool_calls: list[ToolCall],
        handlers: dict[str, Handler],
    ) -> list[dict[str, str]]:
        """
        Enforce and execute a list of tool calls from an Assistants API run.

        For each tool_call:
        - Sends /v1/enforce with the tool name and arguments.
        - If allowed: calls the corresponding handler and collects its output.
        - If denied:  submits a structured error JSON as the tool output so
                      the LLM can handle the denial gracefully.

        Args:
            tool_calls: The list of tool calls from
                        run.required_action.submit_tool_outputs.tool_calls.
            handlers:   Dict mapping tool function names to callables.
                        Each callable receives (tool_name, arguments: dict) -> str.

        Returns:
            A list of tool output dicts ready for submit_tool_outputs:
            [{"tool_call_id": "...", "output": "..."}, ...]
        """
        outputs = []
        for tool_call in tool_calls:
            output = self._handle_single(tool_call, handlers)
            outputs.append({
                "tool_call_id": tool_call.id,
                "output":       output,
            })
        return outputs

    def _handle_single(self, tool_call: ToolCall, handlers: dict[str, Handler]) -> str:
        """Enforce and execute a single tool call. Returns the output string."""
        func      = tool_call.function
        tool_name = func.name
        call_id   = tool_call.id  # use Assistants API ID for audit correlation

        # Parse arguments — Assistants API returns them as a JSON string.
        try:
            arguments = json.loads(func.arguments or "{}")
        except json.JSONDecodeError:
            arguments = {}

        # Enforce the call.
        try:
            self.sdk.enforce(
                role_id   = self.role,
                tool_name = tool_name,
                call_args = arguments,
                call_id   = call_id[:128],  # enforce 128-char limit
            )
        except ScopeboundDenyError as e:
            # Submit denial as structured JSON — LLM handles it gracefully.
            return json.dumps({
                "error":          e.deny_code,
                "reason":         e.reason,
                "retry_guidance": e.retry_guidance,
            })
        except Exception as e:
            # Unexpected error from enforcement plane.
            return json.dumps({"error": "ENFORCEMENT_ERROR", "reason": str(e)})

        # Call the handler.
        handler = handlers.get(tool_name)
        if handler is None:
            return json.dumps({
                "error":  "HANDLER_NOT_FOUND",
                "reason": f"No handler registered for tool '{tool_name}'",
            })

        try:
            result = handler(tool_name, arguments)
            # Handlers must return a string — coerce if needed.
            return result if isinstance(result, str) else json.dumps(result)
        except Exception as e:
            return json.dumps({"error": "HANDLER_ERROR", "reason": str(e)})

    def revoke(self) -> None:
        """Revoke the underlying session. Call when the assistant run is complete."""
        self.sdk.revoke()

    def __enter__(self) -> "ScopeboundSession":
        return self

    def __exit__(self, *_: Any) -> None:
        self.revoke()