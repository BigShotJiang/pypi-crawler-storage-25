"""
Scopebound adapter for the Claude Agent SDK.

Integrates via the PreToolUse hook — enforced before every tool call
in the agent loop. Works with both query() and ClaudeSDKClient.

Usage:
    from claude_agent_sdk import ClaudeAgentOptions, query
    from scopebound import ScopeboundSDK
    from scopebound.adapters.claude_agent import ScopeboundHook

    sb = ScopeboundSDK()
    hook = ScopeboundHook(sb, role="invoice-processor")

    options = ClaudeAgentOptions(
        hooks={"PreToolUse": hook.pre_tool_use}
    )

    async for message in query("Process pending invoices", options=options):
        print(message)
"""
from __future__ import annotations

import atexit
from typing import Any

from ..client import ScopeboundSDK
from ..exceptions import ScopeboundDenyError


class ScopeboundHook:
    """
    PreToolUse hook that enforces Scopebound policy before every
    tool call in the Claude Agent SDK loop.

    On deny, raises PermissionError — the SDK surfaces this to the
    agent as a tool error, allowing the agent to handle it gracefully.

    Args:
        sdk:  A ScopeboundSDK instance.
        role: The Scopebound role ID or name to enforce against.
    """

    def __init__(self, sdk: ScopeboundSDK, role: str) -> None:
        self.sdk = sdk
        self.role = role
        atexit.register(sdk.revoke)

    def pre_tool_use(self, tool_name: str, tool_input: dict[str, Any]) -> None:
        """
        Called by the Claude Agent SDK before every tool execution.

        Args:
            tool_name:  Name of the tool being called.
            tool_input: Arguments passed to the tool.

        Raises:
            PermissionError: If Scopebound denies the tool call.
        """
        try:
            self.sdk.enforce(
                role_id=self.role,
                tool_name=tool_name,
                call_args=tool_input,
            )
        except ScopeboundDenyError as e:
            raise PermissionError(
                f"[Scopebound] {e.deny_code}: {e.reason}"
            ) from e

    def __call__(self, tool_name: str, tool_input: dict[str, Any]) -> None:
        """Allow the hook to be passed directly as a callable."""
        self.pre_tool_use(tool_name, tool_input)


def enforce_claude(sdk: ScopeboundSDK, role: str) -> dict[str, Any]:
    """
    Returns a hooks dict ready to pass to ClaudeAgentOptions.

    Usage:
        from scopebound.adapters.claude_agent import enforce_claude

        options = ClaudeAgentOptions(
            hooks=enforce_claude(sb, role="invoice-processor")
        )

    Returns:
        Dict with PreToolUse key mapping to the enforcement hook.
    """
    hook = ScopeboundHook(sdk, role)
    return {"PreToolUse": hook.pre_tool_use}
