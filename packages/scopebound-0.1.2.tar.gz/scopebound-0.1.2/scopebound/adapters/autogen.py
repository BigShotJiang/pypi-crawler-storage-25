from __future__ import annotations

import atexit
import functools
import uuid
from contextlib import contextmanager
from typing import Any, Callable, Generator

from ..client import ScopeboundSDK
from ..exceptions import ScopeboundDenyError


def enforce_autogen(sdk: ScopeboundSDK, role: str) -> Callable:
    """
    Decorator that wraps an AutoGen tool function with Scopebound enforcement.

    Works with both plain functions and AutoGen FunctionTool callables.
    The decorated function is intercepted before execution — enforcement
    happens before the tool runs.

    Usage:
        sb = ScopeboundSDK(base_url="http://localhost:8080")

        @enforce_autogen(sb, role="invoice-processor")
        def read_invoices(limit: int = 10) -> str:
            return f"found {limit} invoices"

        # Register with AutoGen agent:
        agent = AssistantAgent(
            name="agent",
            tools=[read_invoices],
        )

    On deny, the function returns a structured error dict so the AutoGen
    conversation can handle it gracefully without crashing the run.
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapped(*args: Any, **kwargs: Any) -> Any:
            call_id = str(uuid.uuid4())[:8]
            call_args = _extract_args(args, kwargs)
            try:
                sdk.enforce(
                    role_id=role,
                    tool_name=func.__name__,
                    call_args=call_args,
                    call_id=call_id,
                )
            except ScopeboundDenyError as e:
                # Return structured error dict — AutoGen conversation handles it.
                return {
                    "error":          e.deny_code,
                    "reason":         e.reason,
                    "retry_guidance": e.retry_guidance,
                }
            return func(*args, **kwargs)

        # Preserve AutoGen metadata — name and description must be accessible.
        wrapped.__name__ = func.__name__
        wrapped.__doc__  = func.__doc__

        atexit.register(sdk.revoke)
        return wrapped

    return decorator


class AutoGenSession:
    """
    Manages Scopebound session lifecycle around an AutoGen conversation run.

    Provisions sessions for all agent roles at the start of a conversation
    and revokes them when the conversation ends.

    Usage:
        sb = ScopeboundSDK(base_url="http://localhost:8080")

        with AutoGenSession(sb, roles={"researcher": "read-only-analyst"}) as session:
            await Console(agent.run_stream(...))
    """

    def __init__(self, sdk: ScopeboundSDK, roles: dict[str, str]):
        """
        Args:
            sdk:   A ScopeboundSDK instance shared across the conversation.
            roles: Dict mapping AutoGen agent names to Scopebound role IDs.
                   Example: {"researcher": "read-only-analyst"}
        """
        self.sdk   = sdk
        self.roles = roles

    @contextmanager
    def conversation(self) -> Generator[None, None, None]:
        """
        Context manager that provisions all role sessions at entry
        and revokes them at exit (including on exception).

        Usage:
            with session.conversation():
                result = await agent.run(task="...")
        """
        for role_id in self.roles.values():
            self.sdk.provision(role_id=role_id)
        try:
            yield
        finally:
            self.sdk.revoke()

    def __enter__(self) -> "AutoGenSession":
        for role_id in self.roles.values():
            self.sdk.provision(role_id=role_id)
        return self

    def __exit__(self, *_: Any) -> None:
        self.sdk.revoke()

    def enforce_tool(self, agent_name: str) -> Callable:
        """
        Returns an @enforce_autogen decorator bound to the given agent's role.

        Usage:
            session = AutoGenSession(sb, roles={"researcher": "read-only-analyst"})

            @session.enforce_tool("researcher")
            def search_web(query: str) -> str:
                return "results"
        """
        role_id = self.roles.get(agent_name)
        if role_id is None:
            raise ValueError(
                f"Agent {agent_name!r} not found in roles dict. "
                f"Available: {list(self.roles.keys())}"
            )
        return enforce_autogen(self.sdk, role_id)


def _extract_args(args: tuple, kwargs: dict) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if args:
        result["args"] = list(args)
    result.update(kwargs)
    return result
