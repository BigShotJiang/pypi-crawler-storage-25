"""
Scopebound Python SDK — zero-trust identity and enforcement for AI agents.
"""
from .client import ScopeboundSDK
from .exceptions import ScopeboundDenyError, ScopeboundTimeoutError, ScopeboundUnavailableError

__all__ = [
    "ScopeboundSDK",
    "ScopeboundDenyError",
    "ScopeboundTimeoutError",
    "ScopeboundUnavailableError",
    "enforce",
    "ScopeboundSession",
    "CrewEnforcer",
    "enforce_autogen",
    "AutoGenSession",
    "enforce_sk",
    "ScopeboundHook",
    "enforce_claude",
]

__version__ = "0.1.2"

def __getattr__(name):
    if name == "enforce":
        from .adapters.langchain import enforce
        return enforce
    if name == "ScopeboundSession":
        from .adapters.openai_assistants import ScopeboundSession
        return ScopeboundSession
    if name == "CrewEnforcer":
        from .adapters.crewai import CrewEnforcer
        return CrewEnforcer
    if name == "enforce_autogen":
        from .adapters.autogen import enforce_autogen
        return enforce_autogen
    if name == "AutoGenSession":
        from .adapters.autogen import AutoGenSession
        return AutoGenSession
    if name == "enforce_sk":
        from .adapters.semantic_kernel import enforce_sk
        return enforce_sk
    if name == "ScopeboundHook":
        from .adapters.claude_agent import ScopeboundHook
        return ScopeboundHook
    if name == "enforce_claude":
        from .adapters.claude_agent import enforce_claude
        return enforce_claude
    raise AttributeError(f"module scopebound has no attribute {name!r}")
