from __future__ import annotations
import os
import threading
import time
from typing import Any, Optional
import httpx
from .exceptions import ScopeboundDenyError, ScopeboundTimeoutError, ScopeboundUnavailableError


class ScopeboundSDK:
    """HTTP client for the Scopebound enforcement plane."""

    def __init__(self, base_url=None, timeout=2.0, fail_open=False, api_key=None):
        self.base_url = (base_url or os.environ.get("SCOPEBOUND_BASE_URL", "http://localhost:8080")).rstrip("/")
        self.timeout = timeout
        self.fail_open = fail_open
        resolved_key = api_key or os.environ.get('SCOPEBOUND_API_KEY','')
        headers = {}
        if resolved_key:
            headers['X-Scopebound-API-Key'] = resolved_key
        self._client = httpx.Client(timeout=self.timeout, base_url=self.base_url, headers=headers)
        self._lock = threading.Lock()
        self._jwt = None
        self._session_id = None
        self._expires_at = None
        self._role_cache: dict = {}  # name -> UUID cache

    def _resolve_role(self, role_id: str) -> str:
        """Resolve a role name to its UUID. Returns role_id unchanged if it looks like a UUID.
        Caches the result for the lifetime of the SDK instance.
        """
        import re
        # UUID pattern — if it matches, return as-is
        if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', role_id, re.I):
            return role_id
        # Check cache
        if role_id in self._role_cache:
            return self._role_cache[role_id]
        # Look up by name
        try:
            resp = self._client.get("/mgmt/v1/roles", params={"name": role_id})
            resp.raise_for_status()
            uuid = resp.json()["id"]
            self._role_cache[role_id] = uuid
            return uuid
        except Exception:
            # Fall back to using role_id as-is (e.g. in tests or if mgmt endpoint unavailable)
            return role_id

    def provision(self, role_id, requested_ttl=0, task_type="", framework="python"):
        try:
            resp = self._client.post("/v1/provision", json={
                "role_id": role_id,
                "task_type": task_type,
                "framework": framework,
                "requested_ttl": requested_ttl,
            })
            resp.raise_for_status()
        except httpx.TimeoutException as e:
            raise ScopeboundTimeoutError(f"provision timed out: {e}") from e
        except httpx.HTTPError as e:
            raise ScopeboundUnavailableError(f"provision failed: {e}") from e

        data = resp.json()
        with self._lock:
            self._jwt = data["jwt"]
            self._session_id = data["session_id"]
            self._expires_at = _parse_expiry(data.get("expires_at", ""))
        return self._jwt

    def _jwt_valid(self):
        with self._lock:
            if not self._jwt or not self._expires_at:
                return False
            return time.time() < self._expires_at - 30

    def _get_or_provision(self, role_id):
        role_id = self._resolve_role(role_id)
        if not self._jwt_valid():
            return self.provision(role_id)
        with self._lock:
            return self._jwt

    def enforce(self, role_id, tool_name, call_args=None, call_id="", action="tool_call"):
        try:
            jwt = self._get_or_provision(role_id)
            decision = self._do_enforce(jwt, tool_name, call_args or {}, call_id, action)
        except (ScopeboundTimeoutError, ScopeboundUnavailableError):
            if self.fail_open:
                return
            raise

        if decision.get("decision") == "deny" and decision.get("deny_code") == "JWT_EXPIRED":
            jwt = self.provision(role_id)
            decision = self._do_enforce(jwt, tool_name, call_args or {}, call_id, action)

        if decision.get("decision") == "deny":
            raise ScopeboundDenyError(
                deny_code=decision.get("deny_code", "UNKNOWN"),
                severity=decision.get("severity", "medium"),
                reason=decision.get("reason", ""),
                retry_guidance=decision.get("retry_guidance", "none"),
                call_id=call_id,
            )

    def _do_enforce(self, jwt, tool_name, call_args, call_id, action):
        try:
            resp = self._client.post("/v1/enforce", json={
                "jwt": jwt,
                "tool_name": tool_name,
                "call_args": call_args,
                "call_id": call_id,
                "action": action,
            })
            resp.raise_for_status()
            return resp.json()
        except httpx.TimeoutException as e:
            raise ScopeboundTimeoutError(f"enforce timed out: {e}") from e
        except httpx.HTTPError as e:
            raise ScopeboundUnavailableError(f"enforce failed: {e}") from e

    def revoke(self, reason="MANUAL"):
        with self._lock:
            session_id = self._session_id
            self._jwt = None
            self._session_id = None
            self._expires_at = None
        if not session_id:
            return
        try:
            self._client.delete(f"/v1/sessions/{session_id}?reason={reason}")
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.revoke()

    def close(self):
        self.revoke()
        self._client.close()


def _parse_expiry(expires_at):
    if not expires_at:
        return 0.0
    try:
        from datetime import datetime
        s = expires_at.replace("Z", "+00:00")
        return datetime.fromisoformat(s).timestamp()
    except Exception:
        return 0.0
