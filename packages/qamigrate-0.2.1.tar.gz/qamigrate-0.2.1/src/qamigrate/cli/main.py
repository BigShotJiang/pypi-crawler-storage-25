"""
QAMigrate CLI Application.

Main entry point for all QAMigrate commands.
"""

import io
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from qamigrate import __version__
from qamigrate.core.config import get_config


def _ensure_utf8_stdout() -> None:
    """
    Force stdout/stderr to UTF-8 on legacy Windows terminals.

    Python on Windows defaults stdout to cp1252, which can't encode the
    box-drawing and symbol characters Rich emits. This reconfigures the
    streams to UTF-8 before any output happens.
    """
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        # TextIOWrapper.reconfigure is available on Python 3.7+
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:  # pragma: no cover -- best effort
                pass


_ensure_utf8_stdout()


# Initialize Typer app
app = typer.Typer(
    name="qamigrate",
    help="QAMigrate - AI-powered test framework migration.",
    add_completion=False,
    rich_markup_mode="rich",
)

# Console: Rich handles its own fallback when the terminal can't render
# some glyphs, but we still want a clean UTF-8 stream underneath.
console = Console()


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        console.print(f"[bold blue]QAMigrate[/] version [green]{__version__}[/]")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit.",
            callback=version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """QAMigrate - AI-powered test framework migration."""
    pass


@app.command()
def init(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    config_file: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            help="Path to configuration file.",
        ),
    ] = None,
) -> None:
    """
    Initialize QAMigrate in a Selenium project.

    Analyzes project structure and creates initial configuration.
    """
    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Initializing project...",
            border_style="blue",
        )
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Scanning project structure...", total=None)

        # Check for build files
        pom_xml = project / "pom.xml"
        build_gradle = project / "build.gradle"

        if pom_xml.exists():
            build_tool = "maven"
            progress.update(task, description="Found pom.xml (Maven project)")
        elif build_gradle.exists():
            build_tool = "gradle"
            progress.update(task, description="Found build.gradle (Gradle project)")
        else:
            console.print(
                "[yellow][!]  No pom.xml or build.gradle found. "
                "Please specify build tool in config.[/]"
            )
            build_tool = "unknown"

        # Count Java files
        progress.update(task, description="Counting Java files...")
        java_files = list(project.rglob("*.java"))
        test_files = [f for f in java_files if "test" in str(f).lower()]

        progress.update(task, description="Creating configuration...")

        # Create qamigrate.yaml if it doesn't exist
        config_path = project / "qamigrate.yaml"
        if not config_path.exists():
            default_config = f"""# QAMigrate Configuration
# Generated for: {project.name}

compiler:
  build_tool: "{build_tool}"
  java_version: "17"

scanner:
  include_patterns:
    - "**/*.java"
  exclude_patterns:
    - "**/target/**"
    - "**/build/**"
"""
            config_path.write_text(default_config)
            console.print(f"[green][OK][/] Created configuration: {config_path}")

    # Display summary
    table = Table(title="Project Summary", show_header=False)
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Project Path", str(project))
    table.add_row("Build Tool", build_tool.capitalize())
    table.add_row("Total Java Files", str(len(java_files)))
    table.add_row("Test Files", str(len(test_files)))


    console.print(table)
    console.print("\n[bold green][OK] Project initialized![/]")
    console.print("\nNext steps:")
    console.print("  1. Run [cyan]qamigrate scan[/] to analyze your codebase")
    console.print("  2. Run [cyan]qamigrate migrate --all[/] to convert to Playwright")


@app.command()
def scan(
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    output: Annotated[
        Optional[Path],
        typer.Option(
            "--output",
            "-o",
            help="Output file for scan results (JSON).",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-V",
            help="Show detailed scan output.",
        ),
    ] = False,
) -> None:
    """
    Scan and analyze a Selenium codebase.

    Extracts AST, detects patterns, and calculates complexity scores.
    """
    from qamigrate.agents.scanner import ScannerAgent

    console.print(
        Panel.fit(
            "[bold blue]QAMigrate[/] - Scanning project...",
            border_style="blue",
        )
    )

    config = get_config(project / "qamigrate.yaml")
    scanner = ScannerAgent(config.scanner)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Analyzing source files...", total=None)

        try:
            result = scanner.scan_project(project)
        except Exception as e:
            console.print(f"[red][FAIL] Scan failed: {e}[/]")
            raise typer.Exit(1)

        progress.update(task, description="Generating report...")

    # Display results
    console.print("\n[bold]Scan Results[/]\n")

    # File summary
    table = Table(title="File Analysis")
    table.add_column("Metric", style="cyan")
    table.add_column("Count", style="green", justify="right")
    table.add_row("Total Files Scanned", str(result.file_count))
    table.add_row("Page Objects", str(result.page_object_count))
    table.add_row("Test Classes", str(result.test_class_count))
    console.print(table)

    # Pattern summary
    if result.pattern_summary:
        console.print()
        pattern_table = Table(title="Detected Selenium Patterns")
        pattern_table.add_column("Pattern", style="cyan")
        pattern_table.add_column("Count", style="yellow", justify="right")
        pattern_table.add_column("Complexity", style="magenta", justify="right")

        for pattern_name, count in sorted(
            result.pattern_summary.items(), key=lambda x: x[1], reverse=True
        ):
            pattern_table.add_row(pattern_name, str(count), "*" * min(count // 10 + 1, 5))

        console.print(pattern_table)

    # Complexity distribution
    console.print()
    complexity_table = Table(title="Complexity Distribution")
    complexity_table.add_column("Level", style="cyan")
    complexity_table.add_column("Files", style="green", justify="right")
    complexity_table.add_row("Low (1-3)", str(result.complexity_distribution.get("low", 0)))
    complexity_table.add_row("Medium (4-6)", str(result.complexity_distribution.get("medium", 0)))
    complexity_table.add_row("High (7-10)", str(result.complexity_distribution.get("high", 0)))
    console.print(complexity_table)

    # Save output if requested
    if output:
        import json

        output.write_text(json.dumps(result.to_dict(), indent=2))
        console.print(f"\n[green][OK][/] Results saved to: {output}")

    console.print("\n[bold green][OK] Scan complete![/]")
    console.print(f"\nRun [cyan]qamigrate migrate --all[/] to start migration")


@app.command()
def migrate(
    file: Annotated[
        Optional[Path],
        typer.Argument(
            help="Specific Java file to migrate.",
        ),
    ] = None,
    all_files: Annotated[
        bool,
        typer.Option(
            "--all",
            "-a",
            help="Migrate all files in the project.",
        ),
    ] = False,
    project: Annotated[
        Path,
        typer.Option(
            "--project",
            "-p",
            help="Path to Selenium project root.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ] = Path("."),
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Analyze files and preview what would happen without calling the LLM or writing output.",
        ),
    ] = False,
    report: Annotated[
        Optional[Path],
        typer.Option(
            "--report",
            "-r",
            help="Write migration report to this directory (HTML, JSON, and Markdown).",
        ),
    ] = None,
) -> None:
    """
    Migrate Selenium test files to Playwright.

    Specify a single file or use --all to migrate the entire project.
    Use --dry-run to preview what would change without calling the LLM.
    Use --report <dir> to write a migration report with per-file diffs.
    """
    if not file and not all_files:
        console.print("[red]X Please specify a file or use --all[/]")
        raise typer.Exit(1)

    from qamigrate.agents.pipeline import run_migration
    from qamigrate.agents.scanner import ScannerAgent
    from qamigrate.core.report import MigrationRecord, MigrationReport, PatternSummary
    import time

    config = get_config(project / "qamigrate.yaml")

    # Collect files
    if all_files:
        # Walk every .java file under the project, then filter out anything
        # inside build output, generated output, or dependency folders.
        exclusions = (
            "target",          # Maven output
            "build",           # Gradle output
            "node_modules",
            "playwright",      # QAMigrate's own output dir
            "qamigrate-output",
            ".git",
            ".venv",
            ".idea",
        )
        java_files = sorted(
            {
                f.resolve()
                for f in project.rglob("*.java")
                if not any(part in exclusions for part in f.parts)
            }
        )
        # Sort for deterministic ordering: page objects / base classes first,
        # helpers in the middle, actual @Test classes last. This matters
        # because later files can reference earlier ones.
        def _sort_key(p: Path) -> tuple[int, str]:
            s = str(p).lower()
            if "basepage" in s or "basetest" in s:
                rank = 0
            elif "/pages/" in s.replace("\\", "/"):
                rank = 1
            elif "/core/" in s.replace("\\", "/") or "/utils/" in s.replace("\\", "/"):
                rank = 2
            elif "/test/" in s.replace("\\", "/") or s.endswith("test.java") or s.endswith("tests.java"):
                rank = 3
            else:
                rank = 2
            return (rank, s)

        java_files = sorted(java_files, key=_sort_key)

        if not java_files:
            console.print("[red][FAIL] No .java files found under this project.[/]")
            raise typer.Exit(1)
    else:
        java_files = [file] if file else []

    banner = "[bold blue]QAMigrate[/] - " + ("Dry run" if dry_run else "Migrating") + f" {len(java_files)} file(s)"
    console.print(Panel.fit(banner, border_style="blue"))

    migration_report = MigrationReport()
    start_time = time.time()

    if dry_run:
        # Dry run: scan-only, show what WOULD happen per file
        scanner = ScannerAgent(config.scanner)
        for java_file in java_files:
            file_start = time.time()
            try:
                analysis = scanner.scan_file(java_file)
                pattern_counts: dict[str, tuple[int, str]] = {}
                for p in analysis.patterns:
                    if p.pattern_type in pattern_counts:
                        pattern_counts[p.pattern_type] = (
                            pattern_counts[p.pattern_type][0] + 1,
                            p.migration_strategy,
                        )
                    else:
                        pattern_counts[p.pattern_type] = (1, p.migration_strategy)

                patterns = [
                    PatternSummary(pattern_type=ptype, count=count, migration_strategy=strategy)
                    for ptype, (count, strategy) in pattern_counts.items()
                ]
                record = MigrationRecord(
                    source_path=str(java_file),
                    output_path=None,
                    success=True,
                    duration_seconds=round(time.time() - file_start, 2),
                    patterns=patterns,
                    compilation_attempts=0,
                    compiled=None,
                    original_lines=len(java_file.read_text(encoding="utf-8").splitlines()),
                )
                migration_report.add(record)

                total_patterns = sum(p.count for p in patterns)
                console.print(
                    f"[cyan]?[/] [bold]{java_file.name}[/] "
                    f"[dim]({total_patterns} patterns, complexity {analysis.complexity_score}/10)[/]"
                )
                for ptype, (count, _) in list(pattern_counts.items())[:5]:
                    console.print(f"    [dim]* {ptype} x {count}[/]")
                if len(pattern_counts) > 5:
                    console.print(f"    [dim]... and {len(pattern_counts) - 5} more[/]")
            except Exception as e:
                console.print(f"  [red]X[/] {java_file.name}: {e}")
    else:
        # Real migration. Collect generated signatures so later files (tests)
        # call real methods on already-migrated siblings (page objects).
        sibling_signatures: dict[str, list[str]] = {}
        for i, java_file in enumerate(java_files, start=1):
            console.print(f"[cyan]->[/] [{i}/{len(java_files)}] {java_file.name}")
            try:
                result = run_migration(
                    file_path=java_file,
                    project_path=project,
                    config=config,
                    sibling_signatures=sibling_signatures or None,
                )
                if result.record:
                    migration_report.add(result.record)
                # Remember signatures of this file's generated class so later
                # imports of it are accurate. We accept even failed-to-compile
                # outputs here because the signatures themselves are still
                # useful -- the LLM at least said what methods exist.
                if result.class_name and result.generated_signatures:
                    sibling_signatures[result.class_name] = result.generated_signatures

                if result.success:
                    console.print(
                        f"   [green]OK[/] {result.output_path} "
                        f"[dim]({result.record.duration_seconds:.1f}s, {result.record.confidence}% confidence)[/]"
                        if result.record
                        else f"   [green]OK[/] {result.output_path}"
                    )
                else:
                    console.print(f"   [red]FAIL[/] {result.error}")
            except Exception as e:
                console.print(f"   [red]ERROR[/] {e}")

    migration_report.finish()
    total_time = time.time() - start_time

    # Summary
    console.print()
    summary = Table(show_header=False, box=None, pad_edge=False)
    summary.add_column(style="cyan")
    summary.add_column(style="green" if migration_report.failed_count == 0 else "white")
    summary.add_row("Files", f"{migration_report.success_count} / {migration_report.total_files}")
    summary.add_row("Patterns handled", str(migration_report.total_patterns))
    if not dry_run:
        summary.add_row("Avg confidence", f"{migration_report.average_confidence}%")
    summary.add_row("Time", f"{total_time:.1f}s")
    summary.add_row("Est. hours saved", f"~{migration_report.estimated_hours_saved}")
    console.print(summary)

    # Write report if requested
    if report:
        report.mkdir(parents=True, exist_ok=True)
        html_path = migration_report.write_html(report / "report.html")
        json_path = migration_report.write_json(report / "report.json")
        md_path = migration_report.write_markdown(report / "report.md")
        console.print()
        console.print("[bold]Report written:[/]")
        console.print(f"  [dim]HTML:[/]     {html_path}")
        console.print(f"  [dim]JSON:[/]     {json_path}")
        console.print(f"  [dim]Markdown:[/] {md_path}")

    if migration_report.failed_count > 0:
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
