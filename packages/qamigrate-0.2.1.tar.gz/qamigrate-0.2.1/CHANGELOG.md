# Changelog

All notable changes to QAMigrate are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2026-04-15

**Theme: Fix what v0.2.0 broke in real projects.** A user tested on a real
Selenium project and found the compile-fix loop was destructive and `--all`
missed most files. All six reported bugs are fixed.

### Fixed
- **Windows Unicode crash.** `qamigrate init` on Windows crashed with
  `UnicodeEncodeError: '\u2713'` because Rich emits box-drawing characters
  to a `cp1252` stdout. CLI now reconfigures stdout/stderr to UTF-8 on
  startup, and all Unicode glyphs in the CLI output have been replaced
  with ASCII-safe equivalents (`OK`, `FAIL`, `->`, etc.).
- **`--all` only finding `@Test` files.** The file-discovery loop stopped at
  the first directory under `src/` that had Java files, so it would pick
  `src/test/` and miss everything under `src/main/`. Fixed to walk the
  entire project (excluding `target`, `build`, `node_modules`, `playwright`,
  `.git`, `.venv`, `.idea`). Files are now also sorted so base classes and
  page objects are migrated before tests that depend on them.
- **Destructive compile-fix loop.** This was the headline defect: the
  fixer was splicing LLM prose like "Add this import at the top" into
  `.java` files, creating invalid output from valid first-draft code. Two
  changes:
  1. **Fixer rewrite.** The LLM fixer now uses Anthropic tool use
     (`emit_fixed_java` tool) to return the whole corrected file as a
     structured field. It cannot emit free-form text any more. The output
     is validated with tree-sitter before being accepted -- if it contains
     ERROR nodes, no top-level `class_declaration`, or is implausibly
     short, the fix is rejected.
  2. **Non-regressing pipeline.** The pipeline now tracks the best version
     seen so far (fewest errors). If a fix attempt produces more errors
     than the previous best, the pipeline rolls back to the best version.
     After two consecutive non-improvements, the loop stops early and
     keeps the best output. You no longer get degraded garbage after
     starting with working code.
- **Cross-file context.** When migrating a test class that imports a
  sibling page object, the Coder now receives the signatures of the
  already-migrated Playwright version of that sibling. The test class
  calls `new LoginPage(page)` (the real Playwright constructor) instead
  of inventing method names.
- **Confidence scoring.** The old scale gave 0 or 100 with almost no
  middle ground. Rewritten to 0-100 with honest tiers: 100 (first-try
  compile), 90 (1-2 fixes), 80 (many fixes), 70 (skipped compile),
  50 (didn't compile but output exists for review), 0 (no output).
- **Hours-saved metric.** Was counting every detected pattern, including
  from failed migrations. Now only counts patterns from files with
  confidence >= 70 -- if we didn't actually migrate the file, we don't
  claim credit for saving you time on it.
- **Escaped newlines in generated constructors.** LLM tool_use output
  occasionally contained literal `\n` (backslash-n, two chars) instead of
  real newlines, collapsing the constructor onto a single unreadable
  line. The reindenter now detects and unescapes this.

### Changed
- `FixerAgent` now returns the ORIGINAL code unchanged when no strategy
  worked, instead of returning half-applied partial fixes.
- Pipeline always fixes from the best version seen so far, not from
  whatever drifted version is currently on disk.
- CLI prints `[OK]`/`[FAIL]` tags instead of `OK`/`FAIL` for consistency.
- README has accurate output examples and honest confidence language.

### Removed
- `cli/main.py`: Unicode glyphs (check, cross, warning, rocket, chart,
  star, magnifying glass) replaced with ASCII.
- `reports.py` constants that referenced removed modules.

### Added
- `MigrationResult.class_name` and `MigrationResult.generated_signatures`
  so callers can thread context between files.
- `CoderAgent.extract_signatures()` helper.
- `CoderAgent.generate_from_class_info(..., sibling_signatures=...)`
  parameter.
- `run_migration(..., sibling_signatures=...)` parameter.
- `tests/test_fixer.py` with 8 new tests covering validation, markdown
  stripping, and escaped-newline handling.
- 8 more tests total (26 -> 34). All pass.

### Developer experience
- Removed stale dependency chain that referenced deleted modules.
- Fixed XML-element truthiness warning in scanner.
- `qamigrate --version` reports 0.2.1.

---

## [0.2.0] - 2026-04-15

**Theme: Trust & Evidence.** You no longer just get migrated code — you get proof of what changed, how confident we are, and how much time you saved.

### Added
- **Migration Report** in three formats: HTML, JSON, and Markdown
  - Per-file records with detected patterns, confidence score, compilation status, and before/after diff
  - Batch-level metrics: files succeeded/failed, patterns handled, average confidence, estimated hours saved
  - HTML report includes side-by-side diff viewer (stdlib `difflib`) with dark theme
- **`--dry-run` flag** on `qamigrate migrate`: scan all target files and preview patterns without calling the LLM or writing output
- **`--report <dir>` flag** on `qamigrate migrate`: writes `report.html`, `report.json`, `report.md` to the specified directory
- **`compiler.skip`** config option: skip compilation validation when Playwright JARs aren't available locally
- **Confidence scoring** per file (0-100) derived from success + compilation attempts
- **Time-saved estimate** based on ~15 min of manual effort per pattern

### Changed
- Simplified pipeline: `SupervisorConfig` renamed to `PipelineConfig`
- `QAMigrateConfig` now uses `pipeline.max_retries` instead of `supervisor.max_retries`
- `run_migration()` now returns a `MigrationResult` with an attached `MigrationRecord`
- CLI `migrate` command output: per-file status with confidence score, summary table with batch metrics

### Removed
- Dead modules: `supervisor.py`, `visual.py`, `utom.py`, `test_cleanup.py`, `languages.py`, `pdf_reports.py`, `dependencies.py`, `parallel.py`, `security.py`, `reports.py`, `database.py`, `integrations/jira_client.py`, `cli/interactive.py`
- Old web server (`server/`) and React dashboard (`dashboard/`) — will return in v0.3.0 once backed by the new report format
- CLI commands: `verify` (visual agent was mocked), `export` (superseded by `migrate --report`), `dashboard` (temporarily removed)
- Unused config sections: `visual`, `docker`, `server`, `quality_gates`
- Unused dependencies: `httpx`, `email-validator`, `fastapi`, `uvicorn`, `websockets`, `docker`, `opencv-python`, `pillow`, `imagehash`, `numpy`, `openai`

### Fixed
- `datetime.utcnow()` deprecation warnings on Python 3.12+ (now using `datetime.now(timezone.utc)`)
- Maven `pom.xml` element truthiness deprecation warnings in scanner
- CLI `--all` no longer requires the optional `DependencyAnalyzer` — walks `src/test` then `src/` directly

### Developer experience
- Added `tests/test_report.py` (13 new tests covering report rendering and confidence scoring)
- All 25 tests pass with no warnings

---

## [0.1.0] - 2026-04-14

### Added
- Initial release.
- Selenium Java -> Playwright Java migration pipeline:
  - **Scanner** (Tree-sitter, 70+ pattern queries)
  - **Coder** (Claude tool use for structured output)
  - **Compiler** (javac validation)
  - **Fixer** (rule-based + LLM error remediation with up to 3 retries)
- CLI commands: `init`, `scan`, `migrate`
- Validated end-to-end on real Selenium files covering `@FindBy`, `PageFactory`, `WebDriverWait`, `Actions`, `Select`, alerts, iframes, `JavascriptExecutor`, file uploads, TestNG inheritance, and `@DataProvider`.
