import json
import os
import random
from typing import Any, Dict, Optional

import numpy as np

from shrinking_algorithms.algorithms import Algorithm
from shrinking_algorithms.embedding import (
    uml_dict_to_graph,
    embed_graph,
    find_embedding,
)


class EvolAlgorithm(Algorithm):
    """
    Genetic Algorithm for diagram shrinking.
    Implements ShrinkingAlgorithm interface.

    Each individual is a vector where each position represents a diagram element.
    Values 0-0.5: element excluded
    Values 0.6-1: element included
    """
    def __init__(self):
        self.population_size: Optional[int] = None
        self.generations: Optional[int] = None
        self.mutation_rate: Optional[float] = None
        self.crossover_rate: Optional[float] = None
        self.exclusion_threshold: Optional[float] = None
        self.inclusion_threshold: Optional[float] = None
        self.elements = None
        self.element_types = None
        self.population = None
        self.best_individual = None
        self.best_fitness = None
        self.original_embedding = None
        self.G_full = None
        self.scores = None
        self.fitness_coefficients = None

    def compute(self, parsed_puml: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run the genetic algorithm on parsed PUML data and return the reduced PUML data.

        Args:
            parsed_puml: Dictionary with 'classes' and 'edges' keys

        Returns:
            Reduced PUML dictionary with same structure
        """
        self.PUML = parsed_puml
        self._extract_elements()
        self.G_full, self.G_full_stats = uml_dict_to_graph(self.PUML)
        self.original_embedding, self.original_model = embed_graph(self.G_full)

        best_individual = self.solve()
        reduced_diagram = self.extract_solution(best_individual)

        return reduced_diagram

    def load_config(self, config_path):
        """Load docker configuration from JSON file."""

        base_path = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_path, config_path)


        try:
            with open(full_path, "r") as file:
                return json.load(file)
        except Exception as e:
            print(f"Error loading config file: {e}")
            return {}

    def _extract_elements(self):
        """
        Extract all diagram elements (classes, edges, attributes, methods).
        Each element gets an index in the individual vector.
        """
        self.elements = []
        self.element_types = []

        for class_name in self.PUML["classes"].keys():
            self.elements.append(("class", class_name, None))
            self.element_types.append("class")

            for attr in self.PUML["classes"][class_name].get("attributes", []):
                self.elements.append(("attribute", class_name, attr))
                self.element_types.append("attribute")

            for method in self.PUML["classes"][class_name].get("methods", []):
                self.elements.append(("method", class_name, method))
                self.element_types.append("method")

        for edge in self.PUML["edges"]:
            self.elements.append(("edge", edge, None))
            self.element_types.append("edge")

    def initialize_population(self):
        """Generate initial random population."""
        self.population = []
        for _ in range(self.population_size):
            individual = [random.random() for _ in range(len(self.elements))]
            self.population.append(individual)

    def fitness_function(self, individual):
        """
        Evaluate fitness of an individual. 

        Fitness value is calculated from:
            - cosine similarity factor
            - edge preservation factor
            - shrink factor

        These factors can be further scaled by the fitness coefficients defined in ga_config.json.

        Edge preservation can be further specified by weights defined in ga_config.json.
        Different edge types can be made more important and thus more likely to be preserved.
        """

        a = self.fitness_coefficients["similarity"]
        b = self.fitness_coefficients["edges"]
        c = self.fitness_coefficients["shrink"]

        assert self.G_full is not None, "Graph not initialized"
        assert a + b + c > 0, "Fitness scaling factors must sum to a positive value"
        assert a >= 0 and b >= 0 and c >= 0, "Fitness scaling factors must be positive"

        G_shrunk, G_shrunk_stats = uml_dict_to_graph(self.decode_individual(individual))

        edges_score = 0

        # preservation of edges
        # rewards edges that are preserved 
        # can scale which edges are more important to be preserved
        for key, weight in self.scores.items():
            full_val = self.G_full_stats.get(key, 0)
            shrunk_val = G_shrunk_stats.get(key, 0)

            # avoid division by zero
            if full_val > 0:
                edges_score += weight * (shrunk_val / full_val)

        emb_orig = self.original_embedding
        emb_shrunk = find_embedding(self.original_model, G_shrunk)

        # cosine similarity of embeddings
        # should be close for similar embeddings 
        # similar embeddings should represent structural similarity
        similarity = self._cosine_sim(emb_orig, emb_shrunk)
        similarity = (similarity + 1 ) / 2 # normalize to [0,1]

        # compression ratio 
        # should reward compression fo the graph - edge decode_individual
        # TODO: 
        # i am not too sure about this and must come back to this
        # right now it counts artificial edges too (connectors, attrs, methods)
        full_edges = self.G_full_stats["total_edges"]
        shrunk_edges = G_shrunk_stats["total_edges"]

        edge_shrink = (full_edges - shrunk_edges) / max(full_edges, 1)
        node_shrink = (len(self.G_full) - len(G_shrunk)) / max(len(self.G_full), 1)
        alpha = 0.5
        shrink_ratio = alpha * edge_shrink + (1 - alpha) * node_shrink

        fitness = a * similarity + b * edges_score + c * shrink_ratio

        return fitness / (a + b + c)

    def selection(self):
        """
        Tournament selection: pick random individuals and select the best.
        Returns selected parents for reproduction.
        """
        tournament_size = min(self.population_size, 3)
        selected = []

        for _ in range(self.population_size):
            tournament = random.sample(self.population, tournament_size)
            tournament_fitness = [
                (ind, self.fitness_function(ind)) for ind in tournament
            ]
            winner = max(tournament_fitness, key=lambda x: x[1])
            selected.append(winner[0])

        return selected

    def crossover(self, parent1, parent2):
        """
        Single-point crossover: create two offspring from two parents.
        """
        if random.random() > self.crossover_rate:
            return parent1[:], parent2[:]

        crossover_point = random.randint(1, len(parent1) - 1)

        offspring1 = parent1[:crossover_point] + parent2[crossover_point:]
        offspring2 = parent2[:crossover_point] + parent1[crossover_point:]

        return offspring1, offspring2

    def mutate(self, individual):
        """
        Mutation: randomly change some genes (float values in [0,1]).
        """
        mutated = individual[:]

        for i in range(len(mutated)):
            if random.random() < self.mutation_rate:
                mutated[i] = random.random()

        return mutated

    def solve(self, elite_size: int = 1):
        """
        Run the genetic algorithm for specified number of generations.
        Returns the best individual found.

        elite_size: number of top individuals preserved each generation
        """
        self.initialize_population()

        for generation in range(self.generations):
            print(f"Generation {generation + 1}")

            fitness_values = [
                (ind, self.fitness_function(ind)) for ind in self.population
            ]

            fitness_values.sort(key=lambda x: x[1], reverse=True)

            current_best = fitness_values[0]
            if current_best[1] > self.best_fitness:
                self.best_fitness = current_best[1]
                self.best_individual = current_best[0][:]

            # always keep up to elite_size elites for the next gen
            elites = [ind[:] for ind, _ in fitness_values[:elite_size]]

            selected = self.selection()

            new_population = elites[:]  # start with elites

            for i in range(0, len(selected), 2):
                parent1 = selected[i]
                parent2 = selected[i + 1] if i + 1 < len(selected) else selected[0]

                offspring1, offspring2 = self.crossover(parent1, parent2)

                offspring1 = self.mutate(offspring1)
                offspring2 = self.mutate(offspring2)

                new_population.extend([offspring1, offspring2])

            # Trim to population size
            self.population = new_population[: self.population_size]

        return self.best_individual

    def decode_individual(self, individual):
        """
        Convert individual vector to diagram structure.
        Elements with value > inclusion_threshold are included.
        """
        included_classes = {}
        included_edges = []

        for i, value in enumerate(individual):
            if value >= self.inclusion_threshold:
                element_type, key, data = self.elements[i]

                if element_type == "class":
                    if key not in included_classes:
                        included_classes[key] = {
                            "id": self.PUML["classes"][key]["id"],
                            "attributes": [],
                            "methods": [],
                        }

                elif element_type == "attribute":
                    class_name = key
                    if class_name not in included_classes:
                        included_classes[class_name] = {
                            "id": self.PUML["classes"][class_name]["id"],
                            "attributes": [],
                            "methods": [],
                        }
                    included_classes[class_name]["attributes"].append(data)

                elif element_type == "method":
                    class_name = key
                    if class_name not in included_classes:
                        included_classes[class_name] = {
                            "id": self.PUML["classes"][class_name]["id"],
                            "attributes": [],
                            "methods": [],
                        }
                    included_classes[class_name]["methods"].append(data)

                elif element_type == "edge":
                    edge = key
                    source = edge["source"]
                    target = edge["target"]

                    if (
                        source in self.PUML["classes"]
                        and target in self.PUML["classes"]
                    ):
                        if source not in included_classes:
                            included_classes[source] = {
                                "id": self.PUML["classes"][source]["id"],
                                "attributes": [],
                                "methods": [],
                            }
                        if target not in included_classes:
                            included_classes[target] = {
                                "id": self.PUML["classes"][target]["id"],
                                "attributes": [],
                                "methods": [],
                            }
                        included_edges.append(edge)

        return {"classes": included_classes, "edges": included_edges}

    def extract_solution(self, individual):
        """
        Convert the best individual to a reduced PUML diagram structure.
        Compatible with PUMLParser.reparse_file() method.
        """
        return self.decode_individual(individual)

    def _cosine_sim(self, a, b):
        a = a.ravel()
        b = b.ravel()
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
