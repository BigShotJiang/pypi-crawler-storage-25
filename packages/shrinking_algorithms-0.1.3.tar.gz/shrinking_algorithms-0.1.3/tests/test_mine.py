from shrinking_algorithms.algorithms import EvolFactory
from shrinking_algorithms.parsers import PUMLParser
from pathlib import Path
import os


if __name__ == "__main__":
    current_dir = Path(__file__).parent
    puml_file_path = os.path.join(current_dir, "puml_files", "file5.puml")
    
    file = open(file=puml_file_path, encoding="UTF-8")

    print(file.read())
    parser = PUMLParser("src/shrinking_algorithms/parsers/parser_config.json")
    parsed = parser.parse_file(puml_file_path)

    print("PARSED")
    print(parsed)

    factory = EvolFactory()
    alg = factory.get_algorithm()
    alg.initialize(population=2, generations=1)
    reduced = alg.compute(parsed)

    print(reduced)





