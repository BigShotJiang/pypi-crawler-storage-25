"""Tests for worker management and task claiming."""

import asyncio

import pytest

from aaiclick.backend import is_sqlite
from sqlalchemy import text
from sqlmodel import select

from ..snowflake_id import get_snowflake_id
from .claiming import claim_next_task, update_task_status
from .orch_context import commit_tasks, get_sql_session
from .execution import execute_task
from .factories import create_job, create_task
from .models import Group, Job, JobStatus, Task, TaskStatus, WorkerStatus
from .worker import (
    deregister_worker,
    get_worker,
    list_workers,
    register_worker,
    worker_heartbeat,
    worker_main_loop,
)


async def test_register_worker(orch_ctx):
    """Test worker registration."""
    worker = await register_worker()

    assert worker.id is not None
    assert worker.status == WorkerStatus.ACTIVE
    assert worker.hostname is not None
    assert worker.pid is not None
    assert worker.tasks_completed == 0
    assert worker.tasks_failed == 0

    # Verify in database
    db_worker = await get_worker(worker.id)
    assert db_worker is not None
    assert db_worker.status == WorkerStatus.ACTIVE


async def test_register_worker_custom_values(orch_ctx):
    """Test worker registration with custom hostname and pid."""
    worker = await register_worker(hostname="test-host", pid=12345)

    assert worker.hostname == "test-host"
    assert worker.pid == 12345


async def test_worker_heartbeat(orch_ctx):
    """Test worker heartbeat updates."""
    worker = await register_worker()
    original_heartbeat = worker.last_heartbeat

    # Wait a bit and send heartbeat
    await asyncio.sleep(0.1)
    result = await worker_heartbeat(worker.id)

    assert result is True

    # Verify heartbeat was updated
    db_worker = await get_worker(worker.id)
    assert db_worker.last_heartbeat > original_heartbeat


async def test_worker_heartbeat_nonexistent(orch_ctx):
    """Test heartbeat for non-existent worker returns False."""
    result = await worker_heartbeat(999999999)
    assert result is False


async def test_deregister_worker(orch_ctx):
    """Test worker deregistration."""
    worker = await register_worker()

    result = await deregister_worker(worker.id)
    assert result is True

    # Verify status changed
    db_worker = await get_worker(worker.id)
    assert db_worker.status == WorkerStatus.STOPPED


async def test_deregister_worker_nonexistent(orch_ctx):
    """Test deregistering non-existent worker returns False."""
    result = await deregister_worker(999999999)
    assert result is False


async def test_list_workers(orch_ctx):
    """Test listing workers."""
    # Register multiple workers
    worker1 = await register_worker(hostname="host1", pid=1001)
    worker2 = await register_worker(hostname="host2", pid=1002)

    # Deregister one
    await deregister_worker(worker1.id)

    # List all workers
    all_workers = await list_workers()
    assert len(all_workers) >= 2

    # List only active workers
    active_workers = await list_workers(status=WorkerStatus.ACTIVE)
    active_ids = [w.id for w in active_workers]
    assert worker2.id in active_ids

    # List only stopped workers
    stopped_workers = await list_workers(status=WorkerStatus.STOPPED)
    stopped_ids = [w.id for w in stopped_workers]
    assert worker1.id in stopped_ids


async def test_worker_main_loop_executes_tasks(orch_ctx, monkeypatch, tmpdir):
    """Test that worker main loop executes tasks."""
    monkeypatch.setenv("AAICLICK_LOG_DIR", str(tmpdir))

    # Clear any pending tasks from previous tests first
    cleanup_worker = await register_worker()
    while True:
        old_task = await claim_next_task(cleanup_worker.id)
        if old_task is None:
            break
    await deregister_worker(cleanup_worker.id)

    # Create a job
    job = await create_job(
        "test_main_loop_job",
        "aaiclick.orchestration.fixtures.sample_tasks.simple_task",
    )

    # Run worker with max_tasks=1 (disable signal handlers, limit empty polls for test)
    tasks_executed = await worker_main_loop(
        max_tasks=1,
        install_signal_handlers=False,
        max_empty_polls=5,
    )

    assert tasks_executed == 1

    # Verify task was completed
    async with get_sql_session() as session:
        result = await session.execute(
            select(Task).where(Task.job_id == job.id)
        )
        task = result.scalar_one()
        assert task.status == TaskStatus.COMPLETED


async def test_worker_main_loop_handles_failures(orch_ctx, monkeypatch, tmpdir):
    """Test that worker main loop handles task failures."""
    monkeypatch.setenv("AAICLICK_LOG_DIR", str(tmpdir))

    # Clear any pending tasks from previous tests first
    cleanup_worker = await register_worker()
    while True:
        old_task = await claim_next_task(cleanup_worker.id)
        if old_task is None:
            break
    await deregister_worker(cleanup_worker.id)

    # Create a job with a failing task
    job = await create_job(
        "test_failing_job",
        "aaiclick.orchestration.fixtures.sample_tasks.failing_task",
    )

    # Run worker with max_tasks=1 (disable signal handlers, limit empty polls for test)
    tasks_executed = await worker_main_loop(
        max_tasks=1,
        install_signal_handlers=False,
        max_empty_polls=5,
    )

    # Task was attempted but failed
    assert tasks_executed == 0  # Failed tasks don't count as executed

    # Verify task was marked as failed
    async with get_sql_session() as session:
        result = await session.execute(
            select(Task).where(Task.job_id == job.id)
        )
        task = result.scalar_one()
        assert task.status == TaskStatus.FAILED
        assert task.error is not None


# =============================================================================
# Task Claiming Tests
# =============================================================================


async def test_claim_next_task_no_tasks(orch_ctx):
    """Test claiming when no tasks are available for the worker."""
    worker = await register_worker()

    # Claim all available tasks first to get to empty state
    while True:
        task = await claim_next_task(worker.id)
        if task is None:
            break

    # Now verify no more tasks are available
    task = await claim_next_task(worker.id)
    assert task is None


async def test_claim_next_task_basic(orch_ctx):
    """Test basic task claiming."""
    # Register worker
    worker = await register_worker()

    # Clear any pending tasks from previous tests
    while True:
        old_task = await claim_next_task(worker.id)
        if old_task is None:
            break

    # Create a job with a task
    job = await create_job(
        "test_claim_job",
        "aaiclick.orchestration.fixtures.sample_tasks.simple_task",
    )

    # Claim the task we just created
    task = await claim_next_task(worker.id)

    assert task is not None
    assert task.job_id == job.id
    assert task.status == TaskStatus.RUNNING
    assert task.worker_id == worker.id
    assert task.claimed_at is not None

    # Verify job status changed to RUNNING
    async with get_sql_session() as session:
        result = await session.execute(select(Job).where(Job.id == job.id))
        db_job = result.scalar_one()
        assert db_job.status == JobStatus.RUNNING
        assert db_job.started_at is not None


@pytest.mark.skipif(
    is_sqlite(),
    reason="FOR UPDATE SKIP LOCKED requires PostgreSQL",
)
async def test_claim_next_task_skip_locked(orch_ctx):
    """Test that concurrent workers don't claim the same task."""
    # Register workers first
    worker1 = await register_worker(hostname="worker1", pid=1001)
    worker2 = await register_worker(hostname="worker2", pid=1002)

    # Clear any pending tasks from previous tests
    while True:
        old_task = await claim_next_task(worker1.id)
        if old_task is None:
            break

    # Create multiple jobs with tasks
    job1 = await create_job(
        "test_claim_job1",
        "aaiclick.orchestration.fixtures.sample_tasks.simple_task",
    )
    job2 = await create_job(
        "test_claim_job2",
        "aaiclick.orchestration.fixtures.sample_tasks.async_task",
    )

    # Both workers claim tasks concurrently
    task1, task2 = await asyncio.gather(
        claim_next_task(worker1.id),
        claim_next_task(worker2.id),
    )

    # Each worker should get a different task
    assert task1 is not None
    assert task2 is not None
    assert task1.id != task2.id
    assert task1.worker_id == worker1.id
    assert task2.worker_id == worker2.id


async def test_claim_next_task_prioritizes_oldest_job(orch_ctx, monkeypatch, tmpdir):
    """Test that older running jobs are prioritized."""
    monkeypatch.setenv("AAICLICK_LOG_DIR", str(tmpdir))

    # Create worker first
    worker = await register_worker()

    # Clear any pending tasks from previous tests
    while True:
        old_task = await claim_next_task(worker.id)
        if old_task is None:
            break

    # Create first job and start it
    job1 = await create_job(
        "test_job_old",
        "aaiclick.orchestration.fixtures.sample_tasks.simple_task",
    )

    # Claim the first task to start job1
    task1 = await claim_next_task(worker.id)
    assert task1 is not None
    assert task1.job_id == job1.id

    # Execute and complete the task
    await execute_task(task1)

    # Mark task as completed
    await update_task_status(task1.id, TaskStatus.COMPLETED)

    # Now create a second job (newer)
    job2 = await create_job(
        "test_job_new",
        "aaiclick.orchestration.fixtures.sample_tasks.async_task",
    )

    # Add another task to job1 (which is already running)
    # Using standalone apply function
    extra_task = create_task(
        "aaiclick.orchestration.fixtures.sample_tasks.simple_task"
    )
    await commit_tasks(extra_task, job_id=job1.id)

    # Claim next task - should prioritize job1 (older running job)
    next_task = await claim_next_task(worker.id)
    assert next_task is not None
    assert next_task.job_id == job1.id


async def test_claim_respects_task_dependency(orch_ctx):
    """Test that claim_next_task respects task -> task dependencies."""
    # Register worker
    worker = await register_worker()

    # Clear any pending tasks from previous tests
    while True:
        old_task = await claim_next_task(worker.id)
        if old_task is None:
            break

    # Create job with two dependent tasks
    job = await create_job(
        "test_deps_claim_job",
        "aaiclick.orchestration.fixtures.sample_tasks.simple_task",
    )

    # Get the initial task created by create_job
    async with get_sql_session() as session:
        result = await session.execute(
            select(Task).where(Task.job_id == job.id)
        )
        initial_task = result.scalar_one()

    # Create a second task that depends on the first
    # Using standalone apply function
    task2 = create_task("aaiclick.orchestration.fixtures.sample_tasks.async_task")
    initial_task >> task2  # task2 depends on initial_task
    await commit_tasks(task2, job_id=job.id)

    # First claim should get initial_task (no dependencies)
    claimed1 = await claim_next_task(worker.id)
    assert claimed1 is not None
    assert claimed1.id == initial_task.id

    # Second claim should return None (task2 depends on uncompleted initial_task)
    claimed2 = await claim_next_task(worker.id)
    assert claimed2 is None

    # Mark initial_task as completed
    await update_task_status(initial_task.id, TaskStatus.COMPLETED)

    # Now task2 should be claimable
    claimed3 = await claim_next_task(worker.id)
    assert claimed3 is not None
    assert claimed3.id == task2.id


async def test_claim_respects_group_dependency(orch_ctx, monkeypatch, tmpdir):
    """Test that claim_next_task respects group -> task dependencies."""
    monkeypatch.setenv("AAICLICK_LOG_DIR", str(tmpdir))

    # Register worker
    worker = await register_worker()

    # Clear any pending tasks from previous tests
    while True:
        old_task = await claim_next_task(worker.id)
        if old_task is None:
            break

    # Create job
    job = await create_job(
        "test_group_deps_job",
        "aaiclick.orchestration.fixtures.sample_tasks.simple_task",
    )

    # Using standalone apply function

    # Get initial task
    async with get_sql_session() as session:
        result = await session.execute(
            select(Task).where(Task.job_id == job.id)
        )
        initial_task = result.scalar_one()

    # Create a group and add initial_task to it
    group1 = Group(id=get_snowflake_id(), name="group1")
    await commit_tasks(group1, job_id=job.id)

    # Update initial_task to be in group1
    async with get_sql_session() as session:
        await session.execute(
            text("UPDATE tasks SET group_id = :group_id WHERE id = :task_id"),
            {"group_id": group1.id, "task_id": initial_task.id},
        )
        await session.commit()

    # Create a task that depends on group1
    task2 = create_task("aaiclick.orchestration.fixtures.sample_tasks.async_task")
    group1 >> task2
    await commit_tasks(task2, job_id=job.id)

    # Claim initial_task (in group1)
    claimed1 = await claim_next_task(worker.id)
    assert claimed1 is not None
    assert claimed1.id == initial_task.id

    # task2 should not be claimable (depends on group1 which has uncompleted task)
    claimed2 = await claim_next_task(worker.id)
    assert claimed2 is None

    # Complete initial_task
    await update_task_status(initial_task.id, TaskStatus.COMPLETED)

    # Now task2 should be claimable (group1 is complete)
    claimed3 = await claim_next_task(worker.id)
    assert claimed3 is not None
    assert claimed3.id == task2.id
