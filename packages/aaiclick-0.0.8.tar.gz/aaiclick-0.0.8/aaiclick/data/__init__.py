"""
aaiclick.data - Data context and object management for ClickHouse operations.

This module provides the core data management capabilities for aaiclick,
including context management, object creation, and database operations.
"""

from .data_context import ChClient
from .data_context import (
    create_object,
    create_object_from_value,
    data_context,
    decref,
    delete_object,
    delete_persistent_object,
    delete_persistent_objects,
    get_ch_client,
    get_data_lifecycle,
    get_engine,
    incref,
    list_persistent_objects,
    open_object,
    register_object,
)
from .object import create_object_from_url
from .data_context import LifecycleHandler, LocalLifecycleHandler
from .models import (
    ENGINE_AGGREGATING_MERGE_TREE,
    ENGINE_DEFAULT,
    ENGINE_MEMORY,
    ENGINE_MERGE_TREE,
    ENGINES,
    EngineType,
    FIELDTYPE_ARRAY,
    FIELDTYPE_DICT,
    FIELDTYPE_SCALAR,
    GB_ANY,
    GB_COUNT,
    GB_GROUP_ARRAY_DISTINCT,
    GB_MAX,
    GB_MEAN,
    GB_MIN,
    GB_STD,
    GB_SUM,
    GB_VAR,
    GroupByOpType,
    ORIENT_DICT,
    ORIENT_RECORDS,
    ColumnInfo,
    ColumnMeta,
    Computed,
    ColumnType,
    DATE_TYPES,
    GroupByInfo,
    ViewSchema,
    QueryInfo,
    Schema,
    parse_ch_type,
    ValueListType,
    ValueScalarType,
    ValueType,
)
from .object import DataResult, GroupByQuery, Object, View
from .object import cast, split_by_char
