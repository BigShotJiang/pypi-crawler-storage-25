"""agentfirewall — a dotfile-driven firewall for LLM agent tool calls."""

__version__ = "0.2.0"
