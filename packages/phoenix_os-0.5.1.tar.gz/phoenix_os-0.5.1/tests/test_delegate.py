"""Tests for phoenix.core.delegate.

Focus: the timeout path. A runaway sub-agent must not stall the brain
indefinitely (see issue #9 follow-up).
"""

import asyncio

import pytest

from phoenix.core import delegate as delegate_mod


class _FakeResult:
    def __init__(self, output: str):
        self.output = output


class _FakeAgent:
    def __init__(
        self, *, delay: float = 0.0, output: str = "done", raise_exc: Exception | None = None
    ):
        self._delay = delay
        self._output = output
        self._raise = raise_exc

    async def run(self, task: str):
        if self._delay:
            await asyncio.sleep(self._delay)
        if self._raise:
            raise self._raise
        return _FakeResult(self._output)


class _FakeRegistry:
    def __init__(self, agents: list[str]):
        self._agents = agents

    def list_agents(self) -> list[str]:
        return self._agents


@pytest.fixture
def patch_registry_and_agent(monkeypatch):
    def _apply(agents: list[str], fake_agent: _FakeAgent):
        monkeypatch.setattr(delegate_mod, "get_registry", lambda: _FakeRegistry(agents))
        monkeypatch.setattr(delegate_mod, "build_agent", lambda **kwargs: fake_agent)

    return _apply


class TestDelegate:
    async def test_success_returns_output(self, patch_registry_and_agent):
        patch_registry_and_agent(["worker", "brain"], _FakeAgent(output="hello"))
        out = await delegate_mod.delegate(ctx=None, task="do the thing", agent="worker")
        assert out == "hello"

    async def test_unknown_agent_returns_error(self, patch_registry_and_agent):
        patch_registry_and_agent(["worker"], _FakeAgent())
        out = await delegate_mod.delegate(ctx=None, task="x", agent="nope")
        assert "Unknown agent" in out
        assert "worker" in out

    async def test_brain_cannot_delegate_to_self(self, patch_registry_and_agent):
        patch_registry_and_agent(["brain", "worker"], _FakeAgent())
        out = await delegate_mod.delegate(ctx=None, task="x", agent="brain")
        assert "Cannot delegate to self" in out

    async def test_exception_becomes_error_string(self, patch_registry_and_agent):
        patch_registry_and_agent(["worker"], _FakeAgent(raise_exc=RuntimeError("boom")))
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert "failed" in out
        assert "boom" in out

    async def test_timeout_returns_actionable_message(self, patch_registry_and_agent, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "0.05")
        patch_registry_and_agent(["worker"], _FakeAgent(delay=5.0))
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert "timed out" in out
        assert "PHOENIX_DELEGATE_TIMEOUT" in out

    async def test_timeout_env_override_respected(self, patch_registry_and_agent, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "10")
        patch_registry_and_agent(["worker"], _FakeAgent(delay=0.01, output="ok"))
        out = await delegate_mod.delegate(ctx=None, task="x", agent="worker")
        assert out == "ok"

    def test_invalid_timeout_env_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "not-a-number")
        assert delegate_mod._get_timeout() == delegate_mod.DEFAULT_DELEGATE_TIMEOUT_SEC

    def test_zero_or_negative_timeout_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "0")
        assert delegate_mod._get_timeout() == delegate_mod.DEFAULT_DELEGATE_TIMEOUT_SEC
        monkeypatch.setenv("PHOENIX_DELEGATE_TIMEOUT", "-5")
        assert delegate_mod._get_timeout() == delegate_mod.DEFAULT_DELEGATE_TIMEOUT_SEC

    def test_default_timeout_is_300s(self, monkeypatch):
        monkeypatch.delenv("PHOENIX_DELEGATE_TIMEOUT", raising=False)
        assert delegate_mod._get_timeout() == 300.0
