"""Phoenix -- modular AI agent operating system."""

__version__ = "0.5.1"
