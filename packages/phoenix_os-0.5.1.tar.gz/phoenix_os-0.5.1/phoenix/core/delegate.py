"""Delegate -- the brain's tool for routing tasks to specialized agents.

Sequential only: runs the sub-agent to completion, returns the result.
No background processing, no retry loops.
"""

import asyncio
import logging
import os

from pydantic_ai import RunContext

from phoenix.core.factory import build_agent
from phoenix.core.registry import get_registry

log = logging.getLogger(__name__)

DEFAULT_DELEGATE_TIMEOUT_SEC = 300.0


def _get_timeout() -> float:
    raw = os.environ.get("PHOENIX_DELEGATE_TIMEOUT")
    if not raw:
        return DEFAULT_DELEGATE_TIMEOUT_SEC
    try:
        value = float(raw)
    except ValueError:
        log.warning("PHOENIX_DELEGATE_TIMEOUT=%r is not a number; using default", raw)
        return DEFAULT_DELEGATE_TIMEOUT_SEC
    return value if value > 0 else DEFAULT_DELEGATE_TIMEOUT_SEC


async def delegate(
    ctx: RunContext,
    task: str,
    agent: str = "worker",
) -> str:
    """Delegate a task to a specialized agent and return its result.

    Aborts with a timeout message if the sub-agent doesn't finish within
    PHOENIX_DELEGATE_TIMEOUT seconds (default 300). Prevents the brain
    from stalling indefinitely on a run-away sub-agent (see issue #9).

    Args:
        task: Description of what needs to be done.
        agent: Agent name (worker, explorer, planner, etc.).
    """
    registry = get_registry()

    if agent not in registry.list_agents():
        available = ", ".join(registry.list_agents())
        return f"Unknown agent '{agent}'. Available agents: {available}"

    if agent == "brain":
        return "Cannot delegate to self. Choose a specialized agent."

    timeout = _get_timeout()
    log.info("Delegating to '%s' (timeout=%.0fs): %s", agent, timeout, task[:80])

    try:
        subagent = build_agent(
            agent_name=agent,
            registry=registry,
            project_context="",
        )
        result = await asyncio.wait_for(subagent.run(task), timeout=timeout)
        output = str(result.output)
        log.info("Delegate '%s' returned %d chars", agent, len(output))
        return output
    except TimeoutError:
        log.warning("Delegate '%s' timed out after %.0fs", agent, timeout)
        return (
            f"Delegation to '{agent}' timed out after {timeout:.0f}s. "
            f"The sub-agent may be stuck in a loop or waiting on a slow tool. "
            f"Consider narrowing the task, or raise PHOENIX_DELEGATE_TIMEOUT."
        )
    except Exception as e:
        log.error("Delegation to '%s' failed: %s", agent, e)
        return f"Delegation to '{agent}' failed: {e}"
