#!/usr/bin/env python3
"""测试MiniMax API URL问题"""

import anthropic

def test_minimax_urls():
    """测试不同的URL配置"""
    
    test_cases = [
        {
            "name": "URL带/v1后缀",
            "base_url": "https://api.minimax.chat/v1",
            "expected_issue": "可能重复/v1"
        },
        {
            "name": "URL不带/v1后缀",
            "base_url": "https://api.minimax.chat",
            "expected_issue": "可能需要/v1"
        },
        {
            "name": "URL带/anthropic后缀",
            "base_url": "https://api.minimax.chat/v1/anthropic",
            "expected_issue": "MiniMax特殊格式"
        },
    ]
    
    for test in test_cases:
        print(f"\n🔍 测试: {test['name']}")
        print(f"   URL: {test['base_url']}")
        print(f"   预期问题: {test['expected_issue']}")
        
        try:
            # 创建客户端
            client = anthropic.Anthropic(
                api_key="test_key",
                base_url=test["base_url"],
            )
            
            print(f"   ✅ 客户端创建成功")
            
            # 检查客户端配置
            print(f"   客户端base_url: {client.base_url}")
            
            # 尝试构建请求URL（不实际发送）
            try:
                # 查看Anthropic SDK内部如何构建URL
                import inspect
                print(f"   客户端类: {type(client).__name__}")
                
                # 检查是否有_build_request方法
                if hasattr(client, '_request'):
                    print(f"   有_request方法")
                
            except Exception as e:
                print(f"   ⚠️  检查客户端时出错: {e}")
                
        except Exception as e:
            print(f"   ❌ 客户端创建失败: {type(e).__name__}: {e}")

def test_anthropic_sdk_url_construction():
    """测试Anthropic SDK如何构建URL"""
    print("\n🔧 测试Anthropic SDK URL构建")
    
    # 创建客户端
    client = anthropic.Anthropic(
        api_key="test_key",
        base_url="https://api.minimax.chat",
    )
    
    # 查看客户端属性
    print(f"客户端base_url: {client.base_url}")
    print(f"客户端类型: {type(client)}")
    
    # 尝试查看内部属性
    try:
        # Anthropic SDK可能使用httpx客户端
        if hasattr(client, '_client'):
            print(f"有_client属性: {type(client._client)}")
            
            # 查看httpx客户端的base_url
            if hasattr(client._client, 'base_url'):
                print(f"httpx客户端base_url: {client._client.base_url}")
    except:
        pass
    
    # 测试messages端点
    print(f"\n测试messages端点:")
    print(f"  client.messages: {client.messages}")
    
    # 查看messages的资源路径
    try:
        # Anthropic SDK使用资源类
        messages_resource = client.messages
        print(f"  messages资源类型: {type(messages_resource)}")
        
        # 查看是否有_path属性
        if hasattr(messages_resource, '_path'):
            print(f"  messages路径: {messages_resource._path}")
    except Exception as e:
        print(f"  检查messages资源时出错: {e}")

def test_minimax_documentation():
    """查看MiniMax文档中的URL格式"""
    print("\n📚 MiniMax API文档参考:")
    print("="*50)
    print("根据MiniMax文档，Anthropic兼容端点可能是:")
    print("1. https://api.minimax.chat/v1 (标准)")
    print("2. https://api.minimax.chat/v1/anthropic (特殊)")
    print("3. https://api.minimaxi.com/v1 (旧域名)")
    print("\n💡 建议测试不同的URL格式")

if __name__ == "__main__":
    print("🚀 测试MiniMax API URL问题")
    print("="*60)
    
    test_minimax_urls()
    test_anthropic_sdk_url_construction()
    test_minimax_documentation()
    
    print("\n" + "="*60)
    print("建议:")
    print("1. 尝试 base_url = 'https://api.minimax.chat' (不带/v1)")
    print("2. 如果失败，尝试 base_url = 'https://api.minimax.chat/v1/anthropic'")
    print("3. 检查MiniMax官方文档获取最新信息")