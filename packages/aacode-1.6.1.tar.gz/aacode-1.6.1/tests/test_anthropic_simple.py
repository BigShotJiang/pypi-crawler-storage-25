#!/usr/bin/env python3
"""简单测试Anthropic客户端"""

import anthropic

def test_anthropic_client():
    """测试Anthropic客户端"""
    print("🧪 测试Anthropic客户端...")
    
    # 创建客户端
    client = anthropic.Anthropic(
        api_key="test_key",
        base_url="https://api.minimax.chat/v1",
    )
    
    print("✅ Anthropic客户端创建成功")
    
    # 测试消息格式
    messages = [
        {"role": "user", "content": "Hello, please reply with 'test success'."}
    ]
    
    print("📝 测试消息格式...")
    print(f"消息: {messages}")
    
    # 检查客户端方法
    print("🔍 检查客户端方法...")
    print(f"Messages方法: {dir(client.messages)}")
    
    # 尝试创建消息（会失败，因为使用测试密钥）
    try:
        print("🤖 尝试调用API...")
        response = client.messages.create(
            model="MiniMax-M2.5",
            max_tokens=10,
            messages=messages
        )
        print(f"✅ API调用成功: {response}")
    except Exception as e:
        print(f"⚠️  API调用失败（预期中）: {type(e).__name__}: {e}")
        print("ℹ️  这证明Anthropic客户端已正确配置，只是API密钥无效")
    
    # 测试流式API
    try:
        print("🌊 测试流式API...")
        with client.messages.stream(
            model="MiniMax-M2.5",
            max_tokens=10,
            messages=messages
        ) as stream:
            print("✅ 流式API连接成功")
            # 不尝试读取，因为会因认证失败而异常
    except Exception as e:
        print(f"⚠️  流式API测试失败（预期中）: {type(e).__name__}: {e}")
    
    print("✅ Anthropic客户端测试完成")

if __name__ == "__main__":
    test_anthropic_client()