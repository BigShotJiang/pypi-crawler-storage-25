#!/usr/bin/env python3
"""测试Anthropic网关功能"""

import asyncio
import os
from pathlib import Path
from core.main_agent import MainAgent

async def test_anthropic_gateway():
    """测试Anthropic网关"""
    print("🧪 测试Anthropic网关功能...")
    
    # 设置环境变量
    os.environ["LLM_API_KEY"] = "test_key"  # 使用测试密钥
    os.environ["LLM_GATEWAY"] = "anthropic"
    os.environ["LLM_MODEL_NAME"] = "MiniMax-M2.5"
    os.environ["LLM_API_URL"] = "https://api.minimax.chat/v1"
    
    project_path = Path.cwd()
    
    # 创建模拟的上下文管理器和安全守卫
    class MockContextManager:
        async def add_context(self, *args, **kwargs):
            pass
        
        async def get_context(self, *args, **kwargs):
            return ""
    
    class MockSafetyGuard:
        def check_command(self, *args, **kwargs):
            return True
        
        def check_file_access(self, *args, **kwargs):
            return True
    
    context_manager = MockContextManager()
    safety_guard = MockSafetyGuard()
    
    model_config = {
        "name": "MiniMax-M2.5",
        "gateway": "anthropic",
        "api_key": "test_key",
        "base_url": "https://api.minimax.chat/v1",
        "temperature": 0.1,
        "max_tokens": 100,
    }
    
    try:
        # 创建主Agent
        agent = MainAgent(
            project_path=project_path,
            context_manager=context_manager,
            safety_guard=safety_guard,
            model_config=model_config,
        )
        
        print("✅ Anthropic网关初始化成功")
        
        # 测试模型调用器
        test_messages = [
            {"role": "system", "content": "你是一个测试助手。"},
            {"role": "user", "content": "你好，请回复'测试成功'。"}
        ]
        
        print("🤖 测试模型调用...")
        try:
            response = await agent.model_caller(test_messages)
            print(f"📝 响应: {response}")
            print("✅ Anthropic网关调用测试完成")
        except Exception as e:
            print(f"⚠️  模型调用测试失败（预期中，因为使用测试密钥）: {e}")
            print("ℹ️  这可能是正常的，因为使用了测试API密钥")
        
        return True
        
    except Exception as e:
        print(f"❌ Anthropic网关测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    asyncio.run(test_anthropic_gateway())