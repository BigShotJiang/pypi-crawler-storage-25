import sys
import os
import json
import asyncio
from pathlib import Path

# 模拟Tauri传递的路径
project_path = "/path/to/project2"

sys.path.insert(0, '/aacode')
os.environ['AACODE_WORK_DIR'] = os.path.expanduser('~/.aacode')

async def run():
    try:
        from aacode.core.main_agent import MainAgent
        from aacode.utils.context_manager import ContextManager
        from aacode.utils.safety import SafetyGuard
        from aacode.config import settings

        work_dir = Path(project_path)
        print(f"work_dir type: {type(work_dir)}, value: {work_dir}")
        
        safety = SafetyGuard(work_dir)
        print(f"SafetyGuard created")
        
        ctx = ContextManager(os.path.expanduser('~/.aacode'))
        print(f"ContextManager created")
        
        agent = MainAgent(
            project_path=work_dir,
            context_manager=ctx,
            safety_guard=safety,
            model_config=settings.DEFAULT_MODEL,
        )
        print(f"MainAgent created")
        
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"ERROR: {str(e)}")
        print(f"Traceback: {tb}")

asyncio.run(run())