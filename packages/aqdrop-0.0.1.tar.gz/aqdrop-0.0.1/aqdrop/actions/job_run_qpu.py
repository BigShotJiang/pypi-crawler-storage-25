#!/usr/bin/env python3

import argparse
import pprint
import tabulate
import httpx
import tempfile
import base64

from aqdrop import AQDrop, defs
import creds

from qiskit import QuantumCircuit, qpy
from qiskit_aer import AerSimulator
from qiskit_ibm_runtime.fake_provider import FakeFez


def add_args(parser: argparse.ArgumentParser):
    parser.add_argument("--id")


def main(args):

    try:
        job_id = int(args.id)
    except TypeError:
        print("--id must be an integer.")
        exit()

    c = AQDrop(creds.network, operator=True)
    c.login(creds.username, creds.password)

    try:
        c.run_job(args.id)
    except httpx.HTTPStatusError as e:
        print(f"Job submission failed.")
        print(f"Error {e.response.status_code}: {e.response.json()['detail']}.")
    else:
        print(f"Job dispatch successful.")  # TODO: print some info about job output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    add_args(parser)
    args = parser.parse_args()

    main(args)
