#!/usr/bin/env python3

import argparse
import pprint
import tabulate
import httpx
import tempfile
import base64

from aqdrop import AQDrop, defs
import creds

from qiskit import QuantumCircuit, qpy
from qiskit_aer import AerSimulator
from qiskit_ibm_runtime.fake_provider import FakeFez


def add_args(parser: argparse.ArgumentParser):
    parser.add_argument("--id")


def main(args):

    try:
        job_id = int(args.id)
    except TypeError:
        print("--id must be an integer.")
        exit()

    c = AQDrop(creds.network)
    c.login(creds.username, creds.password)

    try:
        job = c.get_job(args.id)

        status = defs.JobStatus.SUCCESS
        output_dd = {}

        with tempfile.NamedTemporaryFile(delete_on_close=False) as tf:
            print(job["input"]["qpy"])
            b = base64.b64decode(job["input"]["qpy"])
            tf.write(b)
            tf.close()
            with open(tf.name, 'rb') as tfr:
                qc = qpy.load(tfr)[0]

        try:
            nshots: int = int(job["input"]["shots"])
        except ValueError:
            status = defs.JobStatus.FAILED
            output_dd["message"] = f"misformatted field 'shots'; must be int, got {job['input']['shots']}"
            c.dispatch_job(job_id, status, output_dd)
            exit()

        if job["queue_name"] == "noisy":
            sim = FakeFez()
        else:
            sim = AerSimulator()

        qcr = sim.run(qc, shots=nshots).result()
        output_dd["counts"] = qcr.get_counts()

        c.dispatch_job(job_id, status, output_dd)
    except httpx.HTTPStatusError as e:
        print(f"Job submission failed.")
        print(f"Error {e.response.status_code}: {e.response.json()['detail']}.")
    else:
        print(f"Job dispatch successful.")  # TODO: print some info about job output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    add_args(parser)
    args = parser.parse_args()

    main(args)
