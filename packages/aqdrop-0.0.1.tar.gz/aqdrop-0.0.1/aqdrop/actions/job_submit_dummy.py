#!/usr/bin/env python3

import argparse
import pprint
import tabulate
import httpx

from aqdrop import AQDrop
import creds



def add_args(parser: argparse.ArgumentParser):
    parser.add_argument("--queue")
    parser.add_argument("--task")


def main(args):

    c = AQDrop(f"http://{creds.network}:8000")
    c.login(creds.username, creds.password)
    try:
        submitted = c.submit_job(args.queue, args.task)
    except httpx.HTTPStatusError as e:
        print(f"Job submission failed.")
        print(f"Error {e.response.status_code}: {e.response.json()['detail']}.")
    else:
        print(f"Job submission successful; assigned job ID {submitted['id']}.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    add_args(parser)
    args = parser.parse_args()

    main(args)
