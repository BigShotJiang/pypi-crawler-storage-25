#!/usr/bin/env python3

import argparse
import tabulate
import httpx

from aqdrop import AQDrop, defs
import creds


def add_args(parser: argparse.ArgumentParser):
    parser.add_argument("--queue")
    parser.add_argument("--default", default="true")
    parser.add_argument("--limit", default="5")
    parser.add_argument("--description", default="")


def main(args):
    default = True if args.default.lower() == "true" else False

    #if args.state == "open":
    #    state = defs.QueueState.OPEN
    #elif args.state == "down":
    #    state = defs.QueueState.DOWN
    #else:
    #    print(f"Unrecognized queue state \"{args.state}.\"\nOptions are {', '.join(s.value for s in defs.QueueState)}.")
    #    exit()

    try:
        limit = int(args.limit)
    except:
        print("--limit must be an integer.")
        exit()

    c = AQDrop(creds.network)
    c.login(creds.username, creds.password)

    try:
        submitted = c.add_queue(args.queue, default, limit, description=args.description)
    except httpx.HTTPStatusError as e:
        print(f"Could not add queue.")
        print(f"Error {e.response.status_code}: {e.response.json()['detail']}.")
    else:
        print(tabulate.tabulate([submitted.values()], headers=submitted.keys()))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    add_args(parser)
    args = parser.parse_args()

    main(args)
