#/usr/bin/env python3

import importlib
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", help="The action to be performed.")
    pre_args, remaining = parser.parse_known_args()

    my_module = importlib.import_module(f"actions.{pre_args.action}")
    my_module.add_args(parser)

    args = parser.parse_args()

    my_module.main(args)


if __name__ == "__main__":
    main()
