"""
Shared HTTP utilities used by both the sync and async clients.

Responsibilities:
  - Map API JSON responses → SDK model objects
  - Map non-2xx responses → typed SDK exceptions
  - Isolate httpx from the rest of the SDK
"""
from __future__ import annotations

import httpx

from rakshak._exceptions import (
    RakshakAPIError,
    RakshakAuthError,
    RakshakConnectionError,
    RakshakRateLimitError,
)
from rakshak._models import ConversationResult, OutputResult, Redaction, ScanResult

# ---------------------------------------------------------------------------
# Default settings
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://rakshak-backend-3e2m.onrender.com"
DEFAULT_TIMEOUT  = 30.0   # seconds


# ---------------------------------------------------------------------------
# Response parsers  (raw dict → SDK models)
# ---------------------------------------------------------------------------

def parse_scan(data: dict) -> ScanResult:
    return ScanResult(
        verdict=data["verdict"],
        threats=list(data.get("threats") or []),
        confidence=float(data.get("confidence") or 0.0),
        layer=data.get("triggered_layer"),
        language=data.get("language_detected") or "en",
        request_id=data.get("request_id"),
    )


def parse_output(data: dict) -> OutputResult:
    redactions = [
        Redaction(
            type=r.get("type", ""),
            original=r.get("original", ""),
            replacement=r.get("replacement", ""),
        )
        for r in (data.get("redactions") or [])
    ]
    return OutputResult(
        verdict=data["verdict"],
        threats=list(data.get("threats") or []),
        confidence=float(data.get("confidence") or 0.0),
        sanitized=data.get("sanitized_response"),
        redactions=redactions,
        layer=data.get("triggered_layer"),
        language=data.get("language_detected") or "en",
        request_id=data.get("request_id"),
    )


def parse_conversation(data: dict, session_id: str) -> ConversationResult:
    return ConversationResult(
        session_id=session_id,
        verdict=data["verdict"],
        threats=list(data.get("threats") or []),
        conversation_threats=list(data.get("conversation_threats") or []),
        confidence=float(data.get("confidence") or 0.0),
        risk_score=float(data.get("conversation_risk_score") or 0.0),
        layer=data.get("triggered_layer"),
        turn_index=int(data.get("turn_index") or 0),
        language=data.get("language_detected") or "en",
        request_id=data.get("request_id"),
    )


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

def raise_for_status(response: httpx.Response) -> None:
    """Parse the error body and raise the most specific exception available."""
    if response.is_success:
        return

    code = "UNKNOWN"
    message = response.text or f"HTTP {response.status_code}"
    request_id: str | None = None

    try:
        data = response.json()
        err = data.get("error", {})
        code = err.get("code") or code
        message = err.get("message") or message
        request_id = err.get("request_id")
    except Exception:
        pass

    if response.status_code == 401:
        raise RakshakAuthError(code, message, response.status_code, request_id)
    if response.status_code == 429:
        raise RakshakRateLimitError(code, message, response.status_code, request_id)
    raise RakshakAPIError(code, message, response.status_code, request_id)


def wrap_connect_error(exc: Exception) -> RakshakConnectionError:
    """Convert an httpx transport-level error into RakshakConnectionError."""
    if isinstance(exc, httpx.TimeoutException):
        return RakshakConnectionError(
            f"Request timed out ({type(exc).__name__})", original=exc
        )
    return RakshakConnectionError(
        f"Cannot reach Rakshak server ({type(exc).__name__}: {exc})", original=exc
    )


# ---------------------------------------------------------------------------
# Header builder
# ---------------------------------------------------------------------------

def auth_headers(api_key: str) -> dict[str, str]:
    return {
        "X-API-Key": api_key,
        "User-Agent": "rakshak-python/0.1.1",
    }
