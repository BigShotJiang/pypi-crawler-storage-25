"""
Synchronous Rakshak client.

    import rakshak

    client = rakshak.Client(api_key="rsk_...")

    # ── Input guard ────────────────────────────────────────────────────────
    result = client.guard(user_input)
    if result.blocked:
        return "I can't help with that."

    # ── Output sanitization ────────────────────────────────────────────────
    result = client.sanitize(llm_response)
    safe_reply = result.safe_text or "[Response blocked]"

    # ── Conversation guard ─────────────────────────────────────────────────
    session = client.conversation("user-session-id")
    result = session.send(user_message)
    if result.blocked:
        session.reset()

Use as a context manager to ensure the connection pool is closed::

    with rakshak.Client(api_key="rsk_...") as client:
        result = client.guard("hello")
"""
from __future__ import annotations

import secrets
from typing import TYPE_CHECKING

import httpx

from rakshak._exceptions import RakshakBlockedError, RakshakConnectionError
from rakshak._http import (
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    auth_headers,
    parse_conversation,
    parse_output,
    parse_scan,
    raise_for_status,
    wrap_connect_error,
)
from rakshak._models import ConversationResult, OutputResult, ScanResult

if TYPE_CHECKING:
    from types import TracebackType


class Client:
    """
    Synchronous Rakshak guard client.

    Parameters
    ----------
    api_key:
        Your ``rsk_...`` key, obtained from the admin dashboard.
    timeout:
        HTTP request timeout in seconds (default: 30).
    """

    def __init__(
        self,
        api_key: str,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._base_url = DEFAULT_BASE_URL
        self._http = httpx.Client(
            base_url=self._base_url,
            headers=auth_headers(api_key),
            timeout=timeout,
        )

    # ── Input guard ───────────────────────────────────────────────────────

    def guard(self, text: str, *, raise_on_block: bool = False) -> ScanResult:
        """
        Scan *text* through the full input guard pipeline.

        Parameters
        ----------
        text:
            The raw user input to evaluate.
        raise_on_block:
            When ``True``, raises :exc:`RakshakBlockedError` instead of
            returning a result with ``verdict="block"``.

        Returns
        -------
        ScanResult
            Contains verdict, threats, confidence, layer, language, request_id.

        Raises
        ------
        RakshakBlockedError
            If *raise_on_block* is ``True`` and the input is blocked.
        RakshakAuthError
            Invalid or missing API key.
        RakshakRateLimitError
            Rate limit exceeded.
        RakshakConnectionError
            Server unreachable or request timed out.
        """
        result = self._post_scan("/v1/scan", {"prompt": text})
        if raise_on_block and result.blocked:
            raise RakshakBlockedError(result)
        return result

    # ── Output guard ──────────────────────────────────────────────────────

    def sanitize(
        self,
        text: str,
        *,
        allowed_emails: list[str] | None = None,
        allowed_domains: list[str] | None = None,
        raise_on_block: bool = False,
    ) -> OutputResult:
        """
        Scan an LLM *response* for PII, system leaks, and policy violations.

        Parameters
        ----------
        text:
            The raw LLM response to evaluate.
        allowed_emails:
            Email addresses that must never be redacted
            (e.g. ``["support@yourapp.com"]``).
        allowed_domains:
            Domains whose email addresses must never be redacted
            (e.g. ``["yourapp.com"]``).
        raise_on_block:
            When ``True``, raises :exc:`RakshakBlockedError` on a block verdict.

        Returns
        -------
        OutputResult
            Contains verdict, sanitized text, redactions, threats, language.
        """
        body: dict = {"response": text}
        if allowed_emails:
            body["allowed_emails"] = allowed_emails
        if allowed_domains:
            body["allowed_domains"] = allowed_domains

        result = self._post_output("/v1/scan/output", body)
        if raise_on_block and result.blocked:
            raise RakshakBlockedError(result)
        return result

    # ── Conversation guard ────────────────────────────────────────────────

    def conversation(self, session_id: str | None = None) -> "ConversationSession":
        """
        Return a :class:`ConversationSession` for stateful multi-turn scanning.

        Parameters
        ----------
        session_id:
            Reuse an existing session by ID, or omit to auto-generate one.
            Sessions are scoped to your Rakshak server; use a stable
            identifier that maps to one logical user conversation
            (e.g. a chat thread ID).
        """
        sid = session_id or ("sess_" + secrets.token_hex(8))
        return ConversationSession(self, sid)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: "TracebackType | None",
    ) -> None:
        self.close()

    # ── Internal helpers ──────────────────────────────────────────────────

    def _post(self, path: str, body: dict) -> dict:
        try:
            r = self._http.post(path, json=body)
        except (httpx.ConnectError, httpx.TimeoutException, httpx.TransportError) as exc:
            raise wrap_connect_error(exc) from exc
        raise_for_status(r)
        return r.json()

    def _delete(self, path: str) -> None:
        try:
            r = self._http.delete(path)
        except (httpx.ConnectError, httpx.TimeoutException, httpx.TransportError) as exc:
            raise wrap_connect_error(exc) from exc
        raise_for_status(r)

    def _post_scan(self, path: str, body: dict) -> ScanResult:
        return parse_scan(self._post(path, body))

    def _post_output(self, path: str, body: dict) -> OutputResult:
        return parse_output(self._post(path, body))

    def _post_conversation(self, path: str, body: dict, session_id: str) -> ConversationResult:
        return parse_conversation(self._post(path, body), session_id)


# ---------------------------------------------------------------------------
# ConversationSession
# ---------------------------------------------------------------------------

class ConversationSession:
    """
    Stateful handle for a multi-turn conversation guard session.

    Obtain via :meth:`Client.conversation`; do not instantiate directly.

    The session ID is bound at creation and remains constant.  The server
    maintains conversation state (risk score, topic history) across calls.
    Sessions expire after idle time configured on the server (default 30 min).

    Example
    -------
    ::

        session = client.conversation("chat-thread-abc123")

        for user_msg in chat_messages:
            result = session.send(user_msg)
            if result.blocked:
                reply = "I can't help with that."
                session.reset()   # clear poisoned context
            elif result.flagged:
                log.warning("Rising risk score: %.2f", result.risk_score)
    """

    def __init__(self, client: Client, session_id: str) -> None:
        self._client = client
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        """The session identifier used on the server."""
        return self._session_id

    def send(
        self,
        content: str,
        *,
        role: str = "user",
        raise_on_block: bool = False,
    ) -> ConversationResult:
        """
        Submit one conversation turn and get a guard result.

        Parameters
        ----------
        content:
            The message text for this turn.
        role:
            Message role: ``"user"`` (default), ``"assistant"``, or
            ``"system"``.  Only ``"user"`` turns are scanned; others are
            tracked for context only.
        raise_on_block:
            Raise :exc:`RakshakBlockedError` when verdict is ``"block"``.

        Returns
        -------
        ConversationResult
            Includes per-turn verdict **and** cumulative ``risk_score``.
        """
        path = f"/v1/conversation/{self._session_id}/turn"
        result = self._client._post_conversation(
            path, {"role": role, "content": content}, self._session_id
        )
        if raise_on_block and result.blocked:
            raise RakshakBlockedError(result)
        return result

    def reset(self) -> None:
        """
        Clear all conversation history for this session on the server.

        Use after a block to prevent poisoned context from persisting.
        """
        self._client._delete(f"/v1/conversation/{self._session_id}")
