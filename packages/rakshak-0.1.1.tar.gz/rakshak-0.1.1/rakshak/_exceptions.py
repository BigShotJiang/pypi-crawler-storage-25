"""
Rakshak SDK exception hierarchy.

    RakshakError                 ← base; catch this to handle everything
    ├── RakshakBlockedError      ← guard/sanitize/send returned "block"
    ├── RakshakConnectionError   ← network unreachable or timed out
    └── RakshakAPIError          ← non-2xx HTTP response
        ├── RakshakAuthError     ← 401: invalid/missing API key
        └── RakshakRateLimitError← 429: rate limit exceeded
"""
from __future__ import annotations


class RakshakError(Exception):
    """Base class for all Rakshak SDK errors."""


# ---------------------------------------------------------------------------
# Guard verdict
# ---------------------------------------------------------------------------

class RakshakBlockedError(RakshakError):
    """
    Raised when a guard call returns ``verdict="block"`` and
    ``raise_on_block=True`` is set.

    The full result object is available on ``.result`` for inspection::

        try:
            client.guard(text, raise_on_block=True)
        except rakshak.RakshakBlockedError as e:
            print(e.result.threats)   # ["injection", ...]
            print(e.result.layer)     # 1 | 2 | 3
    """

    def __init__(self, result: object) -> None:
        self.result = result
        threats = getattr(result, "threats", [])
        super().__init__(
            f"Content blocked by Rakshak guard. "
            f"Threats: {threats or 'unspecified'}"
        )


# ---------------------------------------------------------------------------
# Network
# ---------------------------------------------------------------------------

class RakshakConnectionError(RakshakError):
    """
    Network-level failure: server unreachable, DNS failure, or request timed out.

    Attributes
    ----------
    original:
        The underlying ``httpx`` exception, if available.
    """

    def __init__(self, message: str, original: Exception | None = None) -> None:
        self.original = original
        super().__init__(message)


# ---------------------------------------------------------------------------
# API errors (non-2xx responses)
# ---------------------------------------------------------------------------

class RakshakAPIError(RakshakError):
    """
    The Rakshak API returned a non-2xx response.

    Attributes
    ----------
    code:
        Machine-readable error code from the API
        (e.g. ``"VALIDATION_ERROR"``, ``"INTERNAL_ERROR"``).
    message:
        Human-readable description.
    status_code:
        HTTP status code (400, 404, 500, …).
    request_id:
        The ``X-Request-Id`` value for log correlation, if present.
    """

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int,
        request_id: str | None = None,
    ) -> None:
        self.code = code
        self.message = message
        self.status_code = status_code
        self.request_id = request_id
        super().__init__(f"[{code}] {message}  (HTTP {status_code})")


class RakshakAuthError(RakshakAPIError):
    """HTTP 401: API key is missing, invalid, or has been revoked."""


class RakshakRateLimitError(RakshakAPIError):
    """HTTP 429: rate limit for this API key exceeded. Retry after 60 s."""
