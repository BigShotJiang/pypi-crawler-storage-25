"""
Rakshak SDK — Python client for the Rakshak LLM security guard API.

Quick start
-----------
::

    pip install rakshak

::

    import rakshak

    client = rakshak.Client(api_key="rsk_...")

    # Block malicious user input
    result = client.guard(user_input)
    if result.blocked:
        return "I can't help with that."

    # Sanitize LLM output (redact PII, block policy violations)
    result = client.sanitize(llm_response)
    reply = result.safe_text or "[Response blocked by policy]"

    # Multi-turn conversation guard
    session = client.conversation("thread-id")
    result = session.send(user_message)
    if result.flagged:
        logger.warning("Rising risk: %.2f", result.risk_score)

Async::

    async_client = rakshak.AsyncClient(api_key="rsk_...")
    result = await async_client.guard(user_input)
    result = await async_client.sanitize(llm_response)

    session = async_client.conversation("thread-id")
    result = await session.send(user_message)

Error handling::

    try:
        result = client.guard(text, raise_on_block=True)
    except rakshak.RakshakBlockedError as e:
        print("Blocked:", e.result.threats)
    except rakshak.RakshakRateLimitError:
        time.sleep(60)
    except rakshak.RakshakAuthError:
        print("Check your API key")
    except rakshak.RakshakConnectionError:
        print("Is the Rakshak server running?")
"""
from __future__ import annotations

from rakshak._exceptions import (
    RakshakAPIError,
    RakshakAuthError,
    RakshakBlockedError,
    RakshakConnectionError,
    RakshakError,
    RakshakRateLimitError,
)
from rakshak._models import (
    ConversationResult,
    OutputResult,
    Redaction,
    ScanResult,
)
from rakshak.async_client import AsyncClient, AsyncConversationSession
from rakshak.client import Client, ConversationSession

__version__ = "0.1.1"

__all__ = [
    # Clients
    "Client",
    "AsyncClient",
    # Session handles
    "ConversationSession",
    "AsyncConversationSession",
    # Result models
    "ScanResult",
    "OutputResult",
    "ConversationResult",
    "Redaction",
    # Exceptions
    "RakshakError",
    "RakshakBlockedError",
    "RakshakAPIError",
    "RakshakAuthError",
    "RakshakRateLimitError",
    "RakshakConnectionError",
]
