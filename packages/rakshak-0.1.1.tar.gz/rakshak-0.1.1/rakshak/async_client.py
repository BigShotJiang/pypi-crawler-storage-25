"""
Async Rakshak client for use in async frameworks (FastAPI, aiohttp, etc.).

    import rakshak

    async_client = rakshak.AsyncClient(api_key="rsk_...")

    # ── Input guard ────────────────────────────────────────────────────────
    result = await async_client.guard(user_input)
    if result.blocked:
        return "Blocked."

    # ── Output sanitization ────────────────────────────────────────────────
    result = await async_client.sanitize(llm_response)
    safe_reply = result.safe_text or "[Response blocked]"

    # ── Conversation guard ─────────────────────────────────────────────────
    session = async_client.conversation("user-session-id")
    result = await session.send(user_message)

Use as an async context manager::

    async with rakshak.AsyncClient(api_key="rsk_...") as client:
        result = await client.guard("hello")
"""
from __future__ import annotations

import secrets
from typing import TYPE_CHECKING

import httpx

from rakshak._exceptions import RakshakBlockedError
from rakshak._http import (
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    auth_headers,
    parse_conversation,
    parse_output,
    parse_scan,
    raise_for_status,
    wrap_connect_error,
)
from rakshak._models import ConversationResult, OutputResult, ScanResult

if TYPE_CHECKING:
    from types import TracebackType


class AsyncClient:
    """
    Async Rakshak guard client.

    Drop-in async counterpart to :class:`Client`.  All guard methods are
    coroutines; use ``await`` on each call.

    Parameters
    ----------
    api_key:
        Your ``rsk_...`` key, obtained from the admin dashboard.
    timeout:
        HTTP request timeout in seconds (default: 30).
    """

    def __init__(
        self,
        api_key: str,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._base_url = DEFAULT_BASE_URL
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            headers=auth_headers(api_key),
            timeout=timeout,
        )

    # ── Input guard ───────────────────────────────────────────────────────

    async def guard(self, text: str, *, raise_on_block: bool = False) -> ScanResult:
        """
        Async version of :meth:`Client.guard`.

        Scan *text* through the full input guard pipeline.

        Parameters
        ----------
        text:
            The raw user input to evaluate.
        raise_on_block:
            Raises :exc:`RakshakBlockedError` instead of returning a blocked result.
        """
        result = parse_scan(await self._post("/v1/scan", {"prompt": text}))
        if raise_on_block and result.blocked:
            raise RakshakBlockedError(result)
        return result

    # ── Output guard ──────────────────────────────────────────────────────

    async def sanitize(
        self,
        text: str,
        *,
        allowed_emails: list[str] | None = None,
        allowed_domains: list[str] | None = None,
        raise_on_block: bool = False,
    ) -> OutputResult:
        """
        Async version of :meth:`Client.sanitize`.

        Scan an LLM *response* for PII, leaks, and policy violations.
        """
        body: dict = {"response": text}
        if allowed_emails:
            body["allowed_emails"] = allowed_emails
        if allowed_domains:
            body["allowed_domains"] = allowed_domains

        result = parse_output(await self._post("/v1/scan/output", body))
        if raise_on_block and result.blocked:
            raise RakshakBlockedError(result)
        return result

    # ── Conversation guard ────────────────────────────────────────────────

    def conversation(self, session_id: str | None = None) -> "AsyncConversationSession":
        """
        Return an :class:`AsyncConversationSession` for multi-turn scanning.

        Parameters
        ----------
        session_id:
            Reuse an existing session by ID, or omit to auto-generate.
        """
        sid = session_id or ("sess_" + secrets.token_hex(8))
        return AsyncConversationSession(self, sid)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def close(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: "TracebackType | None",
    ) -> None:
        await self.close()

    # ── Internal helpers ──────────────────────────────────────────────────

    async def _post(self, path: str, body: dict) -> dict:
        try:
            r = await self._http.post(path, json=body)
        except (httpx.ConnectError, httpx.TimeoutException, httpx.TransportError) as exc:
            raise wrap_connect_error(exc) from exc
        raise_for_status(r)
        return r.json()

    async def _delete(self, path: str) -> None:
        try:
            r = await self._http.delete(path)
        except (httpx.ConnectError, httpx.TimeoutException, httpx.TransportError) as exc:
            raise wrap_connect_error(exc) from exc
        raise_for_status(r)


# ---------------------------------------------------------------------------
# AsyncConversationSession
# ---------------------------------------------------------------------------

class AsyncConversationSession:
    """
    Async stateful handle for a multi-turn conversation guard session.

    Obtain via :meth:`AsyncClient.conversation`; do not instantiate directly.

    Example
    -------
    ::

        session = async_client.conversation("chat-thread-abc123")

        async for user_msg in incoming_messages():
            result = await session.send(user_msg)
            if result.blocked:
                await reply("I can't help with that.")
                await session.reset()
            elif result.flagged:
                logger.warning("Risk score: %.2f", result.risk_score)
    """

    def __init__(self, client: AsyncClient, session_id: str) -> None:
        self._client = client
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        return self._session_id

    async def send(
        self,
        content: str,
        *,
        role: str = "user",
        raise_on_block: bool = False,
    ) -> ConversationResult:
        """
        Submit one conversation turn and get a guard result.

        Parameters
        ----------
        content:
            The message text.
        role:
            ``"user"`` (default), ``"assistant"``, or ``"system"``.
        raise_on_block:
            Raise :exc:`RakshakBlockedError` on a block verdict.
        """
        path = f"/v1/conversation/{self._session_id}/turn"
        data = await self._client._post(path, {"role": role, "content": content})
        result = parse_conversation(data, self._session_id)
        if raise_on_block and result.blocked:
            raise RakshakBlockedError(result)
        return result

    async def reset(self) -> None:
        """Clear all conversation history for this session on the server."""
        await self._client._delete(f"/v1/conversation/{self._session_id}")
