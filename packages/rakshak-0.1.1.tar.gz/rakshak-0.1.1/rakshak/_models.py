"""
Immutable result objects returned by every SDK call.

All fields are read-only dataclasses.  Convenience properties are added
so callers rarely need to check ``verdict`` as a raw string::

    result = client.guard(text)
    if result.blocked:          # instead of result.verdict == "block"
        ...
    if result:                  # bool(result) is True when SAFE
        forward_to_llm(text)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


# ---------------------------------------------------------------------------
# Shared sub-types
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Redaction:
    """
    One PII replacement made during output sanitization.

    Attributes
    ----------
    type:
        Threat code, e.g. ``"pii_aadhaar"``, ``"pii_email"``.
    original:
        The raw value that was found in the response.
    replacement:
        The masked token that replaced it, e.g. ``"[AADHAAR REDACTED]"``.
    """
    type: str
    original: str
    replacement: str


# ---------------------------------------------------------------------------
# Input guard result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ScanResult:
    """
    Result from :meth:`Client.guard` or :meth:`AsyncClient.guard`.

    Attributes
    ----------
    verdict:
        ``"pass"``  — safe to forward to the LLM.
        ``"block"`` — reject immediately; do not forward.
    threats:
        List of threat codes that triggered the block, e.g.
        ``["injection"]``, ``["jailbreak", "encoding"]``.
    confidence:
        Classifier certainty, 0.0–1.0.
    layer:
        Which pipeline layer fired: 1 = regex, 2 = embedding, 3 = LLM.
        ``None`` when ``verdict == "pass"``.
    language:
        ISO 639-1 code of the detected script (``"en"`` for Latin/unknown,
        ``"hi"`` for Devanagari, ``"ta"`` for Tamil, etc.).
    request_id:
        Server-side request ID for log correlation.
    """
    verdict: Literal["pass", "block"]
    threats: list[str]
    confidence: float
    layer: int | None
    language: str
    request_id: str | None

    # --- Convenience ----------------------------------------------------------

    @property
    def blocked(self) -> bool:
        """``True`` when the input was blocked."""
        return self.verdict == "block"

    def __bool__(self) -> bool:
        """
        ``True`` when the input is **safe** (verdict == "pass").

        This lets you write::

            if client.guard(user_input):
                forward_to_llm(user_input)
        """
        return not self.blocked


# ---------------------------------------------------------------------------
# Output guard result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class OutputResult:
    """
    Result from :meth:`Client.sanitize` or :meth:`AsyncClient.sanitize`.

    Attributes
    ----------
    verdict:
        ``"pass"``   — response is clean, use as-is.
        ``"redact"`` — PII was found and replaced; use :attr:`sanitized`.
        ``"block"``  — response contains policy-violating content; suppress it.
    sanitized:
        The (possibly redacted) response text.  Always a string for
        ``"pass"`` and ``"redact"``; ``None`` only when ``verdict == "block"``.
    redactions:
        Non-empty when ``verdict == "redact"``.  Each entry describes one
        PII replacement.
    threats:
        Threat codes that triggered the verdict.
    confidence:
        Classifier certainty, 0.0–1.0.
    layer:
        Pipeline layer that fired: 1, 2, or 3. ``None`` for clean pass.
    language:
        Detected script of the response text.
    request_id:
        Server-side request ID.
    """
    verdict: Literal["pass", "redact", "block"]
    threats: list[str]
    confidence: float
    sanitized: str | None
    redactions: list[Redaction]
    layer: int | None
    language: str
    request_id: str | None

    # --- Convenience ----------------------------------------------------------

    @property
    def blocked(self) -> bool:
        return self.verdict == "block"

    @property
    def redacted(self) -> bool:
        return self.verdict == "redact"

    @property
    def safe_text(self) -> str | None:
        """
        Returns the text that is safe to show the user.

        - ``"pass"``   → ``sanitized`` (original text, unchanged)
        - ``"redact"`` → ``sanitized`` (PII replaced)
        - ``"block"``  → ``None`` (suppress entirely)
        """
        return self.sanitized

    def __bool__(self) -> bool:
        """``True`` when the response may be shown (pass or redact)."""
        return not self.blocked


# ---------------------------------------------------------------------------
# Conversation guard result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ConversationResult:
    """
    Result from :meth:`ConversationSession.send` or
    :meth:`AsyncConversationSession.send`.

    Attributes
    ----------
    session_id:
        The session this turn belongs to.
    verdict:
        ``"pass"``  — turn is safe.
        ``"flag"``  — conversation risk is building up (warn, but not blocked yet).
        ``"block"`` — turn is rejected.
    threats:
        Single-turn threat codes.
    conversation_threats:
        Multi-turn threat codes, e.g. ``["chemistry_probe"]``,
        ``["payload_splitting"]``, ``["crescendo_escalation"]``.
    risk_score:
        Cumulative conversation risk (0.0–1.0).  Persists across turns.
        Exceeding ~0.5 triggers "flag", ~0.8 triggers "block".
    confidence:
        Max of single-turn confidence and risk score.
    layer:
        4 for conversation-level detector; 1/2/3 for standard pipeline.
    turn_index:
        Zero-based index of this turn within the current session window.
    language:
        Detected script of this turn.
    request_id:
        Server-side request ID.
    """
    session_id: str
    verdict: Literal["pass", "flag", "block"]
    threats: list[str]
    conversation_threats: list[str]
    confidence: float
    risk_score: float
    layer: int | None
    turn_index: int
    language: str
    request_id: str | None

    # --- Convenience ----------------------------------------------------------

    @property
    def blocked(self) -> bool:
        return self.verdict == "block"

    @property
    def flagged(self) -> bool:
        """``True`` when risk is building but not yet at block threshold."""
        return self.verdict == "flag"

    def __bool__(self) -> bool:
        """``True`` when the turn passed (not blocked or flagged)."""
        return self.verdict == "pass"
