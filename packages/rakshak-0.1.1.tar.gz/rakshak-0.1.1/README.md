# rakshak

Python SDK for the [Rakshak](https://rakshak-backend-3e2m.onrender.com) LLM security guard API.

## Install

```bash
pip install rakshak
```

## Quick start

```python
import rakshak

client = rakshak.Client(api_key="rsk_...")

# Block malicious input
result = client.guard(user_input)
if result.blocked:
    return "I can't help with that."

# Sanitize LLM output (redacts PII, blocks policy violations)
result = client.sanitize(llm_response)
reply = result.safe_text or "[Response blocked]"

# Multi-turn conversation guard
session = client.conversation("user-session-id")
result = session.send(user_message)
if result.flagged:
    print("Rising risk score:", result.risk_score)
```

## Async

```python
async_client = rakshak.AsyncClient(api_key="rsk_...")
result = await async_client.guard(user_input)
```
