"""Ring-level operations: map composition and closed-orbit finding."""

import numpy as np
from daceypy import DA


def compose(map1, map2):
    """Compose two maps: apply map1 first, then map2.

    Parameters
    ----------
    map1, map2 : list of DA
        Map components [x', px'].

    Returns
    -------
    list of DA
        Composed map components.
    """
    return [map2[i].eval(map1) for i in range(len(map1))]


def compose_sequence(maps):
    """Compose a sequence of maps in order (first element applied first).

    Parameters
    ----------
    maps : list of list-of-DA
        Each entry is [x', px'] for one element.

    Returns
    -------
    list of DA
        Full composed map.
    """
    result = maps[0]
    for m in maps[1:]:
        result = compose(result, m)
    return result


def compose_n(cell_map, n):
    """Compose a cell map with itself n times (n-turn or n-cell map).

    Parameters
    ----------
    cell_map : list of DA
        One-cell map components.
    n : int
        Number of repetitions.

    Returns
    -------
    list of DA
        n-fold composed map.
    """
    result = cell_map
    for _ in range(n - 1):
        result = compose(result, cell_map)
    return result


def find_closed_orbit(ring_builder, x_guess=0.0, px_guess=0.0,
                      tol=1e-12, max_iter=20):
    """Find the closed orbit of a ring using Newton's method with DA.

    At each iteration, the ring map is evaluated with DA to simultaneously
    obtain the map value and Jacobian, enabling a Newton update.

    Parameters
    ----------
    ring_builder : callable
        A function that takes no arguments, constructs the full ring DA map
        (at the current DA.init settings), and returns [x_out, px_out].
        The map should be built with DA(1) and DA(2) as initial conditions
        offset from the current guess — the caller handles this by building
        the map fresh each iteration.
    x_guess, px_guess : float
        Initial guess for the closed orbit position and angle.
    tol : float
        Convergence tolerance on |x_final - x_initial|.
    max_iter : int
        Maximum Newton iterations.

    Returns
    -------
    x_co, px_co : float
        Closed orbit position [m] and angle [rad].
    converged : bool
        Whether the iteration converged within tolerance.
    """
    x_co, px_co = x_guess, px_guess

    for iteration in range(max_iter):
        # Build and evaluate the ring map around current guess
        ring_map = ring_builder()

        # Extract the fixed-point residual: M(x_co) - x_co
        # DA(1) and DA(2) represent deviations from origin, but the
        # ring_builder should construct the map with initial conditions
        # at the guess.  The constant part of the output is the image
        # of (x_co, px_co), and we need it to equal (x_co, px_co).
        x_out_0 = ring_map[0].getCoefficient([0, 0])
        px_out_0 = ring_map[1].getCoefficient([0, 0])

        res_x = x_out_0 - x_co
        res_px = px_out_0 - px_co

        if abs(res_x) < tol and abs(res_px) < tol:
            return x_co, px_co, True

        # Jacobian from linear DA terms
        J11 = ring_map[0].getCoefficient([1, 0])
        J12 = ring_map[0].getCoefficient([0, 1])
        J21 = ring_map[1].getCoefficient([1, 0])
        J22 = ring_map[1].getCoefficient([0, 1])

        # Newton: (I - J) dx = residual
        A = np.array([[1 - J11, -J12], [-J21, 1 - J22]])
        b = np.array([res_x, res_px])
        dx = np.linalg.solve(A, b)

        x_co -= dx[0]
        px_co -= dx[1]

    return x_co, px_co, False


def find_closed_orbit_simple(ring_func, x_guess=0.0, tol=1e-12, max_iter=20):
    """Find closed orbit for a ring function that takes (x0, px0) floats.

    Simpler interface: the ring function evaluates a scalar one-turn map
    using DA internally and returns (x_final, px_final, J11, J12, J21, J22).

    For most cases, use the pattern below instead::

        DA.init(order, 2)
        ring_map = build_ring_map(x_co_guess)  # shifts DA origin
        # extract residual and Jacobian from ring_map

    Parameters
    ----------
    ring_func : callable
        Takes (x0: float, px0: float) and returns a dict with keys
        'x', 'px' (floats, final coords) and 'J' (2x2 ndarray, Jacobian).
    x_guess : float
        Initial guess for closed orbit radius deviation.
    tol : float
        Convergence tolerance.
    max_iter : int
        Maximum iterations.

    Returns
    -------
    x_co : float
        Closed orbit position.
    converged : bool
        Whether converged.
    """
    x_co = x_guess
    px_co = 0.0

    for _ in range(max_iter):
        result = ring_func(x_co, px_co)
        res = np.array([result['x'] - x_co, result['px'] - px_co])
        if np.max(np.abs(res)) < tol:
            return x_co, True
        A = np.eye(2) - result['J']
        dx = np.linalg.solve(A, res)
        x_co -= dx[0]
        px_co -= dx[1]

    return x_co, False
