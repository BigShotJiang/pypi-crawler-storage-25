"""4D DA tracking through FFAG sector magnets (horizontal + vertical).

Extends sector.py to 4 phase-space variables (x, px, y, py) with
Maxwell-consistent off-midplane field expansion derived from the
midplane profile By(x, y=0).
"""

import numpy as np
from daceypy import DA, array, integrator
from daceypy.RK import RK78


def _build_field_4d(x, y, h, B_coeffs, max_y_order):
    """Build By(x,y) and Bx(x,y) from midplane coefficients."""
    ohx = 1.0 + h * x

    # b_0(x) = midplane field: By(x, 0)
    b = DA(B_coeffs[0])
    xpow = DA(1.0)
    for k in range(1, len(B_coeffs)):
        xpow = xpow * x
        b = b + B_coeffs[k] * xpow

    # Spatial derivative db_0/dx from known polynomial coefficients.
    # NOTE: DA.deriv(1) gives d/d(x_0), the derivative w.r.t. the
    # initial-condition DA variable, NOT the spatial gradient d/dx.
    # They differ by the chain rule factor dx/dx_0 during integration.
    db_dx = DA(0.0)
    xpow = DA(1.0)
    for k in range(1, len(B_coeffs)):
        db_dx = db_dx + k * B_coeffs[k] * xpow
        xpow = xpow * x

    # Correction factor for spatial derivatives of derived quantities:
    # for any f(x), df/dx = f.deriv(1) / x.deriv(1)  [chain rule]
    dx_dx0 = x.deriv(1)

    # Accumulate By = sum b_n(x) * y^(2n)
    # and       Bx = sum db_n/dx * y^(2n+1) / (2n+1)
    By = b
    Bx = db_dx * y  # n=0 term: db_0/dx * y

    y2 = y * y
    y2n = DA(1.0)  # tracks y^(2n), starts at y^0

    for n in range(1, max_y_order // 2 + 1):
        order = 2 * n
        f = ohx * db_dx
        df_dx = f.deriv(1) / dx_dx0  # spatial derivative via chain rule
        b = -df_dx / (ohx * order * (order - 1))
        db_dx = b.deriv(1) / dx_dx0  # spatial derivative of b_n

        y2n = y2n * y2  # y^(2n)
        By = By + b * y2n
        Bx = Bx + db_dx * y2n * y / (order + 1)

    return By, Bx


class _Sector4DIntegrator(integrator):
    """RK7(8) integrator for a 4D sector magnet."""

    _h = 0.0
    _B_coeffs = []
    _inv_Brho = 0.0
    _max_y_order = 4

    @staticmethod
    def f(z, s):
        x, px, y, py = z[0], z[1], z[2], z[3]
        h = _Sector4DIntegrator._h
        inv_Brho = _Sector4DIntegrator._inv_Brho

        By, Bx = _build_field_4d(
            x, y, h,
            _Sector4DIntegrator._B_coeffs,
            _Sector4DIntegrator._max_y_order,
        )

        ohx = 1.0 + h * x
        ps = DA.sqrt(1.0 - px * px - py * py)

        dxds = ohx * px / ps
        dpxds = h * ps - ohx * By * inv_Brho
        dyds = ohx * py / ps
        dpyds = ohx * Bx * inv_Brho

        return array([dxds, dpxds, dyds, dpyds])


def sector_map_4d(B_coeffs, Brho, angle, rho=None, max_y_order=4,
                  rtol=1e-14, atol=1e-14):
    """Compute the 4D DA transfer map through a magnetic sector magnet.

    Integrates the 4D Hamiltonian with off-midplane field expansion
    derived from the midplane polynomial.

    Parameters
    ----------
    B_coeffs : list of float
        Midplane field polynomial coefficients.
        By(x, y=0) = B_coeffs[0] + B_coeffs[1]*x + B_coeffs[2]*x^2 + ...
    Brho : float
        Magnetic rigidity [T*m].
    angle : float
        Bending angle [rad].
    rho : float, optional
        Reference bending radius [m]. Default: |Brho / B_coeffs[0]|.
    max_y_order : int
        Maximum order of y in the field expansion (2 or 4).
    rtol, atol : float
        Integration tolerances.

    Returns
    -------
    list of DA
        [x_out, px_out, y_out, py_out] -- the 4D DA transfer map.
    """
    B0 = B_coeffs[0]
    if rho is None:
        rho = abs(Brho / B0)
    arc_length = rho * abs(angle)

    _Sector4DIntegrator._h = 1.0 / rho * np.sign(B0)
    _Sector4DIntegrator._B_coeffs = B_coeffs
    _Sector4DIntegrator._inv_Brho = 1.0 / Brho
    _Sector4DIntegrator._max_y_order = max_y_order

    prop = _Sector4DIntegrator(RKcoeff=RK78(), stateType=array)
    prop.loadTime(0.0, arc_length)
    prop.loadTol(rtol, atol)
    prop.loadStepSize()

    z0 = array([DA(1), DA(2), DA(3), DA(4)])
    zf = prop.propagate(z0, 0.0, arc_length)

    return [zf[0], zf[1], zf[2], zf[3]]
