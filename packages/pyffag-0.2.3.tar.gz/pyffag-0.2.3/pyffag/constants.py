"""Physical constants for accelerator physics (SI + natural units)."""

# Speed of light [m/s]
C_LIGHT = 299792458.0

# Proton mass [MeV/c^2]
M_PROTON = 938.27208816

# Electron mass [MeV/c^2]
M_ELECTRON = 0.51099895069

# Muon mass [MeV/c^2]
M_MUON = 105.6583755

# Elementary charge [C]
E_CHARGE = 1.602176634e-19

# Conversion: momentum [MeV/c] to magnetic rigidity [T·m]
# Brho = p / (q * c) = p [eV/c] / (e * c) = p [MeV/c] * 1e6 / (c)
# In convenient units: Brho [T·m] = p [MeV/c] / 299.792458
BRHO_FACTOR = 1e6 / C_LIGHT  # multiply by p [MeV/c] to get Brho [T·m]


def kinetic_to_momentum(T, mass):
    """Convert kinetic energy to momentum.

    Parameters
    ----------
    T : float
        Kinetic energy [MeV].
    mass : float
        Rest mass [MeV/c^2].

    Returns
    -------
    float
        Momentum [MeV/c].
    """
    return (T * (T + 2 * mass)) ** 0.5


def momentum_to_brho(p):
    """Convert momentum to magnetic rigidity.

    Parameters
    ----------
    p : float
        Momentum [MeV/c].

    Returns
    -------
    float
        Magnetic rigidity Bρ [T·m].
    """
    return p * BRHO_FACTOR


def kinetic_to_brho(T, mass):
    """Convert kinetic energy to magnetic rigidity.

    Parameters
    ----------
    T : float
        Kinetic energy [MeV].
    mass : float
        Rest mass [MeV/c^2].

    Returns
    -------
    float
        Magnetic rigidity Bρ [T·m].
    """
    return momentum_to_brho(kinetic_to_momentum(T, mass))
