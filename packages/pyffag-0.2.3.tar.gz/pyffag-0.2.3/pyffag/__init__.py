"""pyffag — DA-based FFAG accelerator tracking.

Built on daceypy for arbitrary-order differential algebra arithmetic,
pyffag provides transfer map computation through FFAG sector magnets
via integration of the exact midplane Hamiltonian.

Example
-------
>>> from daceypy import DA
>>> from pyffag import sector_map, compose_n, tune
>>> from pyffag.constants import kinetic_to_brho, M_PROTON
>>>
>>> DA.init(5, 2)
>>> Brho = kinetic_to_brho(250.0, M_PROTON)
>>> cell = sector_map([0.9], Brho, angle=0.4363)  # 25-degree uniform dipole
>>> ring = compose_n(cell, 8)
>>> print(f"Tune: {tune(ring):.4f}")
"""

from pyffag.sector import sector_map
from pyffag.sector_4d import sector_map_4d
from pyffag.elements import (
    drift_map,
    drift_map_paraxial,
    edge_kick,
    thin_quad,
    thin_sext,
    thin_oct,
)
from pyffag.ring import compose, compose_sequence, compose_n, find_closed_orbit
from pyffag.optics import transfer_matrix, tune, is_stable, twiss, symplecticity_error

__version__ = "0.2.2"

__all__ = [
    "sector_map",
    "sector_map_4d",
    "drift_map",
    "drift_map_paraxial",
    "edge_kick",
    "thin_quad",
    "thin_sext",
    "thin_oct",
    "compose",
    "compose_sequence",
    "compose_n",
    "find_closed_orbit",
    "transfer_matrix",
    "tune",
    "is_stable",
    "twiss",
    "symplecticity_error",
]
