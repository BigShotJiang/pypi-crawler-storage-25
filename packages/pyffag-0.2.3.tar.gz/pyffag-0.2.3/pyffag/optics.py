"""Linear optics extraction from DA transfer maps."""

import numpy as np


def transfer_matrix(da_map):
    """Extract the 2x2 transfer matrix from a DA map.

    Parameters
    ----------
    da_map : list of DA
        [x', px'] map components.

    Returns
    -------
    ndarray, shape (2, 2)
        Transfer matrix M.
    """
    M = np.zeros((2, 2))
    M[0, 0] = da_map[0].getCoefficient([1, 0])
    M[0, 1] = da_map[0].getCoefficient([0, 1])
    M[1, 0] = da_map[1].getCoefficient([1, 0])
    M[1, 1] = da_map[1].getCoefficient([0, 1])
    return M


def tune(da_map):
    """Extract the fractional tune from a DA map.

    Parameters
    ----------
    da_map : list of DA
        One-turn (or one-cell) [x', px'] map.

    Returns
    -------
    float
        Fractional tune nu in [0, 0.5].
    """
    M = transfer_matrix(da_map)
    cos_mu = (M[0, 0] + M[1, 1]) / 2.0
    cos_mu = np.clip(cos_mu, -1.0, 1.0)
    return np.arccos(cos_mu) / (2.0 * np.pi)


def is_stable(da_map):
    """Check if the linear map is stable (|Tr M| < 2).

    Parameters
    ----------
    da_map : list of DA
        [x', px'] map.

    Returns
    -------
    bool
    """
    M = transfer_matrix(da_map)
    return abs(M[0, 0] + M[1, 1]) < 2.0


def twiss(da_map):
    """Extract Courant-Snyder (Twiss) parameters from a periodic map.

    Assumes the map is one full period (cell or ring) and is stable.

    Parameters
    ----------
    da_map : list of DA
        One-period [x', px'] map.

    Returns
    -------
    dict
        {'beta': float, 'alpha': float, 'gamma': float, 'tune': float}
        beta in [m], alpha dimensionless, gamma in [1/m].
    """
    M = transfer_matrix(da_map)
    cos_mu = (M[0, 0] + M[1, 1]) / 2.0

    if abs(cos_mu) >= 1.0:
        raise ValueError(f"Unstable map: Tr/2 = {cos_mu:.6f}")

    mu = np.arccos(np.clip(cos_mu, -1.0, 1.0))
    sin_mu = np.sin(mu)

    # Sign of sin(mu): from M12
    if M[0, 1] < 0:
        sin_mu = -sin_mu
        mu = 2 * np.pi - mu

    beta = M[0, 1] / sin_mu
    alpha = (M[0, 0] - M[1, 1]) / (2.0 * sin_mu)
    gamma = -M[1, 0] / sin_mu

    return {
        'beta': beta,
        'alpha': alpha,
        'gamma': gamma,
        'tune': mu / (2.0 * np.pi),
    }


def symplecticity_error(da_map):
    """Check how far the linear map is from symplectic (det M - 1).

    Parameters
    ----------
    da_map : list of DA
        [x', px'] map.

    Returns
    -------
    float
        |det(M) - 1|.
    """
    M = transfer_matrix(da_map)
    return abs(np.linalg.det(M) - 1.0)
