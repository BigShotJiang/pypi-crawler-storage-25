"""DA tracking through FFAG sector magnets.

Integrates the exact midplane Hamiltonian in Frenet-Serret (curvilinear)
coordinates with arc length s as the independent variable.  The equations
of motion are derived from the generating Hamiltonian

    K = -(1+hx) sqrt(p^2 - px^2) + h(1+hx/2)x * p

where h = 1/rho is the reference curvature and p = |p|/p0 is the scaled
total momentum (1 for on-momentum).  For a pure magnetic sector with
By(x) = B0 + B1*x + B2*x^2 + ..., the resulting ODEs are:

    dx/ds  = (1 + hx) * px / sqrt(1 - px^2)
    dpx/ds = h * sqrt(1 - px^2) - (1 + hx) * By(x) / Brho

For sector magnets, the edge faces are radial — no edge focusing.
"""

import numpy as np
from daceypy import DA, array, integrator
from daceypy.RK import RK78


class _SectorIntegrator(integrator):
    """RK7(8) integrator for a sector magnet with polynomial field."""

    # Set by sector_map() before propagation
    _h = 0.0         # curvature 1/rho [1/m]
    _B_coeffs = []    # [B0, B1, B2, ...] where By(x) = sum(Bn * x^n)
    _inv_Brho = 0.0   # 1/(Brho) [1/(T·m)]

    @staticmethod
    def f(z, s):
        x, px = z[0], z[1]
        h = _SectorIntegrator._h
        inv_Brho = _SectorIntegrator._inv_Brho
        B_coeffs = _SectorIntegrator._B_coeffs

        # By(x) = B0 + B1*x + B2*x^2 + ...
        By = DA(B_coeffs[0]) if isinstance(B_coeffs[0], (int, float)) else B_coeffs[0]
        xn = DA(1.0)  # x^0 = 1
        for n in range(1, len(B_coeffs)):
            xn = xn * x
            By = By + B_coeffs[n] * xn

        ohx = 1.0 + h * x  # (1 + h*x)
        ps = DA.sqrt(1.0 - px * px)  # sqrt(1 - px^2)

        dxds = ohx * px / ps
        dpxds = h * ps - ohx * By * inv_Brho

        return array([dxds, dpxds])


def sector_map(B_coeffs, Brho, angle, rho=None, rtol=1e-14, atol=1e-14):
    """Compute the DA transfer map through a magnetic sector magnet.

    Integrates the exact midplane Hamiltonian (no paraxial approximation)
    through a sector magnet with radial edge faces.

    Parameters
    ----------
    B_coeffs : list of float
        Midplane field polynomial coefficients.
        By(x) = B_coeffs[0] + B_coeffs[1]*x + B_coeffs[2]*x^2 + ...
        Units: B_coeffs[0] in [T], B_coeffs[1] in [T/m], etc.
    Brho : float
        Magnetic rigidity p/q [T·m].
    angle : float
        Bending angle of the sector [rad].  The sign of angle should match
        the sign of B_coeffs[0]: positive angle for positive B0.
    rho : float, optional
        Reference bending radius [m].  Default: |Brho / B_coeffs[0]|.
    rtol, atol : float
        Relative and absolute tolerance for the RK7(8) integrator.

    Returns
    -------
    list of DA
        [x_out, px_out] — the DA transfer map components.
    """
    B0 = B_coeffs[0]
    if rho is None:
        rho = abs(Brho / B0)
    arc_length = rho * abs(angle)

    _SectorIntegrator._h = 1.0 / rho * np.sign(B0)
    _SectorIntegrator._B_coeffs = B_coeffs
    _SectorIntegrator._inv_Brho = 1.0 / Brho

    prop = _SectorIntegrator(RKcoeff=RK78(), stateType=array)
    prop.loadTime(0.0, arc_length)
    prop.loadTol(rtol, atol)
    prop.loadStepSize()

    z0 = array([DA(1), DA(2)])
    zf = prop.propagate(z0, 0.0, arc_length)

    return [zf[0], zf[1]]
