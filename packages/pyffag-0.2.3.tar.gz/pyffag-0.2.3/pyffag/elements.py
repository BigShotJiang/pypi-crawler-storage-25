"""Standard beam-line elements as DA maps (midplane, 1 DOF)."""

import numpy as np
from daceypy import DA


def drift_map(length):
    """Exact drift-space map (no paraxial approximation).

    Uses the exact expression x' = x + L * px / sqrt(1 - px^2).

    Parameters
    ----------
    length : float
        Drift length [m].

    Returns
    -------
    list of DA
        [x_out, px_out].
    """
    x, px = DA(1), DA(2)
    ps = DA.sqrt(1.0 - px * px)
    return [x + length * px / ps, px]


def drift_map_paraxial(length):
    """Paraxial drift-space map: x' = x + L*px.

    Parameters
    ----------
    length : float
        Drift length [m].

    Returns
    -------
    list of DA
        [x_out, px_out].
    """
    x, px = DA(1), DA(2)
    return [x + length * px, px]


def edge_kick(h, e1):
    """Thin edge-focusing kick for a rectangular (non-sector) magnet.

    At an edge tilted by angle e1 from the radial direction, the
    horizontal kick is dpx = +h * tan(e1) * x.

    For a sector magnet (radial edges), e1 = 0 and there is no kick.

    Parameters
    ----------
    h : float
        Reference curvature 1/rho [1/m].
    e1 : float
        Edge angle [rad].  Positive = edge rotated toward the magnet body.

    Returns
    -------
    list of DA
        [x_out, px_out].
    """
    x, px = DA(1), DA(2)
    return [x, px + h * np.tan(e1) * x]


def thin_quad(k1L):
    """Thin quadrupole kick: dpx = -k1L * x.

    Parameters
    ----------
    k1L : float
        Integrated quadrupole strength [1/m].

    Returns
    -------
    list of DA
        [x_out, px_out].
    """
    x, px = DA(1), DA(2)
    return [x, px - k1L * x]


def thin_sext(k2L):
    """Thin sextupole kick: dpx = -(k2L/2) * x^2.

    Parameters
    ----------
    k2L : float
        Integrated sextupole strength [1/m^2].

    Returns
    -------
    list of DA
        [x_out, px_out].
    """
    x, px = DA(1), DA(2)
    return [x, px - (k2L / 2) * x ** 2]


def thin_oct(k3L):
    """Thin octupole kick: dpx = -(k3L/6) * x^3.

    Parameters
    ----------
    k3L : float
        Integrated octupole strength [1/m^3].

    Returns
    -------
    list of DA
        [x_out, px_out].
    """
    x, px = DA(1), DA(2)
    return [x, px - (k3L / 6) * x ** 3]
