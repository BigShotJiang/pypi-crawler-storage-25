"""End-to-end test: compute ADTS of an FFAG ring using pyffag + danf.

This is the core use case for the Everglades task: build an FDF triplet
FFAG ring, compose the one-turn map, and extract the amplitude-dependent
tune shift via normal form analysis.
"""

import numpy as np
from daceypy import DA
import pyffag
from pyffag.constants import kinetic_to_brho, M_PROTON
from danf import NormalForm


def compute_ffag_adts():
    """Compute ADTS for a 12-cell FDF triplet proton FFAG."""

    # ---- Physics parameters ----
    T = 150.0  # MeV kinetic energy
    Brho = kinetic_to_brho(T, M_PROTON)
    N_cells = 12

    # F magnet: focusing (B1 > 0), with sextupole component
    B_F = [1.2, 3.0, 4.0]   # B0 [T], B1 [T/m], B2 [T/m^2]
    angle_F = np.radians(12.0)

    # D magnet: defocusing (B1 < 0), with sextupole component
    B_D = [1.2, -5.0, -5.0]
    angle_D = np.radians(6.0)

    # ---- Build ring map at DA order 7 ----
    DA.init(7, 2)

    F = pyffag.sector_map(B_F, Brho, angle=angle_F)
    D = pyffag.sector_map(B_D, Brho, angle=angle_D)
    cell = pyffag.compose_sequence([F, D, F])

    print(f"Brho = {Brho:.6f} T·m")
    print(f"Cell Tr/2 = {(pyffag.transfer_matrix(cell)[0,0] + pyffag.transfer_matrix(cell)[1,1])/2:.8f}")

    tw = pyffag.twiss(cell)
    print(f"Cell tune = {tw['tune']:.6f}")
    print(f"Cell beta = {tw['beta']:.4f} m")

    ring = pyffag.compose_n(cell, N_cells)

    # Stability check
    assert pyffag.is_stable(ring), "Ring is not stable!"
    nu_ring = pyffag.tune(ring)
    print(f"Ring tune = {nu_ring:.6f}")
    print(f"Ring symplecticity = {pyffag.symplecticity_error(ring):.2e}")

    # ---- Normal form → ADTS ----
    nf = NormalForm(ring)
    nf.compute()

    dnu_dJ = nf.detuning['dnux_dJx']
    dnu_deps = dnu_dJ / 2.0  # ε = 2J

    print(f"\ndν/dJ = {dnu_dJ:.6f}")
    print(f"α = dν/dε = {dnu_deps:.6f}")
    print(f"c21 = {nf.detuning['c21']}")

    return dnu_deps


def compute_adts_no_sextupole():
    """ADTS with B2=0: should come purely from curvature-gradient coupling."""

    T = 150.0
    Brho = kinetic_to_brho(T, M_PROTON)
    N_cells = 12

    # No sextupole component (B2 = 0)
    B_F = [1.2, 3.0, 0.0]
    angle_F = np.radians(12.0)
    B_D = [1.2, -5.0, 0.0]
    angle_D = np.radians(6.0)

    DA.init(7, 2)

    F = pyffag.sector_map(B_F, Brho, angle=angle_F)
    D = pyffag.sector_map(B_D, Brho, angle=angle_D)
    cell = pyffag.compose_sequence([F, D, F])
    ring = pyffag.compose_n(cell, N_cells)

    assert pyffag.is_stable(ring)

    nf = NormalForm(ring)
    nf.compute()

    dnu_deps = nf.detuning['dnux_dJx'] / 2.0

    print(f"\n=== No sextupole (B2=0) ===")
    print(f"Ring tune = {pyffag.tune(ring):.6f}")
    print(f"α = dν/dε = {dnu_deps:.6f}")
    print("(This ADTS comes from curvature-gradient coupling and kinematic terms)")

    return dnu_deps


def compute_adts_order_convergence():
    """Check that ADTS converges as DA order increases."""

    T = 150.0
    Brho = kinetic_to_brho(T, M_PROTON)
    N_cells = 12

    B_F = [1.2, 3.0, 4.0]
    angle_F = np.radians(12.0)
    B_D = [1.2, -5.0, -5.0]
    angle_D = np.radians(6.0)

    print("\n=== DA order convergence ===")
    results = []
    for order in [3, 5, 7]:
        DA.init(order, 2)
        F = pyffag.sector_map(B_F, Brho, angle=angle_F)
        D = pyffag.sector_map(B_D, Brho, angle=angle_D)
        cell = pyffag.compose_sequence([F, D, F])
        ring = pyffag.compose_n(cell, N_cells)

        nf = NormalForm(ring)
        nf.compute()
        alpha = nf.detuning['dnux_dJx'] / 2.0
        results.append(alpha)
        print(f"  Order {order}: α = {alpha:.8f}")

    # Orders 5 and 7 should agree well (first-order ADTS converges by order 5)
    rel_diff = abs(results[1] - results[2]) / max(abs(results[2]), 1e-15)
    print(f"  Relative diff (order 5 vs 7): {rel_diff:.2e}")
    assert rel_diff < 0.01, f"ADTS not converged: {rel_diff}"
    print("PASS")


if __name__ == "__main__":
    print("=== FFAG Ring ADTS (full) ===")
    alpha_full = compute_ffag_adts()

    alpha_nosext = compute_adts_no_sextupole()

    compute_adts_order_convergence()

    print(f"\n=== Summary ===")
    print(f"ADTS with sextupole:    α = {alpha_full:.6f} [1/m]")
    print(f"ADTS without sextupole: α = {alpha_nosext:.6f} [1/m]")
    print(f"Sextupole contribution: {alpha_full - alpha_nosext:.6f}")
