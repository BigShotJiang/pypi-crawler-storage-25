"""Basic validation tests for pyffag.

Test cases:
1. Uniform-field sector magnet → known analytical transfer matrix
2. Sector magnet with gradient → ν² = 1+k for scaling FFAG
3. Drift map → identity when length=0
4. Symplecticity check
5. Ring composition and tune extraction
"""

import numpy as np
from daceypy import DA
import pyffag
from pyffag.constants import kinetic_to_brho, M_PROTON


def test_uniform_sector():
    """Uniform-field sector: M should match the analytical sector matrix.

    For a sector magnet with uniform field B0, curvature h = B0/Brho,
    bending angle theta, the transfer matrix is:

        M = [[cos(theta),       rho*sin(theta)],
             [-sin(theta)/rho,  cos(theta)     ]]

    where rho = Brho / B0.
    """
    DA.init(5, 2)

    Brho = 2.0  # T·m
    B0 = 1.0    # T
    rho = Brho / B0  # 2.0 m
    theta = np.pi / 6  # 30 degrees

    m = pyffag.sector_map([B0], Brho, angle=theta)
    M = pyffag.transfer_matrix(m)

    M_exact = np.array([
        [np.cos(theta), rho * np.sin(theta)],
        [-np.sin(theta) / rho, np.cos(theta)],
    ])

    print("=== Test: Uniform sector magnet ===")
    print(f"M (pyffag):\n{M}")
    print(f"M (exact):\n{M_exact}")
    print(f"Max error: {np.max(np.abs(M - M_exact)):.2e}")
    assert np.allclose(M, M_exact, atol=1e-10), f"Transfer matrix mismatch: {M - M_exact}"

    # Symplecticity
    det = np.linalg.det(M)
    print(f"det(M) = {det:.15f}")
    assert abs(det - 1.0) < 1e-10, f"Non-symplectic: det = {det}"
    print("PASS\n")


def test_gradient_sector_scaling_ffag():
    """Sector with linear gradient: tune should satisfy ν² = 1 + k.

    For a scaling FFAG single-sector ring (one magnet = full 2π), the
    horizontal tune is ν = sqrt(1 + k) where k = (r/B)(dB/dr).

    We approximate this with a single sector spanning angle 2π/N for N cells,
    then compose N cells and check the ring tune.

    For By(x) = B0 * (1 + k*x/rho) (linearised scaling field at r=rho):
        B_coeffs = [B0, B0*k/rho]
    """
    DA.init(5, 2)

    Brho = 2.0    # T·m
    B0 = 1.0      # T
    rho = Brho / B0  # 2.0 m
    N = 12         # number of identical cells
    theta = 2 * np.pi / N  # sector angle per cell
    k = 5.0        # field index

    B1 = B0 * k / rho  # dBy/dx at reference orbit
    m_cell = pyffag.sector_map([B0, B1], Brho, angle=theta)

    # Compose N cells
    m_ring = pyffag.compose_n(m_cell, N)

    nu_ring = pyffag.tune(m_ring)
    nu_expected = np.sqrt(1 + k) / (2 * np.pi) * (2 * np.pi)  # nu for full ring
    # Actually: for a scaling FFAG, the tune per revolution is sqrt(1+k).
    # Each cell contributes theta * sqrt(1+k) / (2*pi) to the fractional tune.
    # For N cells of angle theta = 2pi/N: nu_ring = sqrt(1+k).
    # But arccos gives fractional part in [0, 0.5], so:
    nu_full = np.sqrt(1 + k)  # = 2.449...
    nu_frac = nu_full - int(nu_full)  # fractional part

    M_ring = pyffag.transfer_matrix(m_ring)
    cos_mu_ring = (M_ring[0, 0] + M_ring[1, 1]) / 2.0
    nu_from_trace = np.arccos(np.clip(cos_mu_ring, -1, 1)) / (2 * np.pi)

    print("=== Test: Scaling FFAG ν² = 1+k ===")
    print(f"k = {k}, expected ν = sqrt(1+k) = {nu_full:.6f}")
    print(f"Fractional ν (expected): {nu_frac:.6f}")
    print(f"ν from ring trace: {nu_from_trace:.6f}")
    print(f"Tr/2 = {cos_mu_ring:.10f}")
    print(f"cos(2π·ν_expected) = {np.cos(2*np.pi*nu_full):.10f}")

    # The ring trace should match cos(2π·ν_full)
    assert abs(cos_mu_ring - np.cos(2 * np.pi * nu_full)) < 1e-6, \
        f"Tune mismatch: Tr/2={cos_mu_ring}, expected cos(2π·{nu_full})={np.cos(2*np.pi*nu_full)}"
    print("PASS\n")


def test_drift():
    """Drift: x' = x + L*px/sqrt(1-px^2), px' = px."""
    DA.init(3, 2)

    L = 1.5  # m
    m = pyffag.drift_map(L)
    M = pyffag.transfer_matrix(m)

    # Linear part of exact drift is same as paraxial: [[1, L], [0, 1]]
    M_exact = np.array([[1.0, L], [0.0, 1.0]])

    print("=== Test: Drift map ===")
    print(f"M (pyffag): {M}")
    print(f"Max linear error: {np.max(np.abs(M - M_exact)):.2e}")
    assert np.allclose(M, M_exact, atol=1e-14)

    # Check nonlinear terms: x' should have a cubic term from 1/sqrt(1-px^2)
    # x' = x + L*px*(1 + px^2/2 + ...) so coefficient of px^3 is L/2
    c_px3 = m[0].getCoefficient([0, 3])
    print(f"(x|px^3) = {c_px3:.6f}, expected {L/2:.6f}")
    assert abs(c_px3 - L / 2) < 1e-10
    print("PASS\n")


def test_symplecticity_sector():
    """Sector map should be symplectic (det M = 1)."""
    DA.init(5, 2)

    Brho = 1.839
    B_coeffs = [1.2, -2.5, 4.0]
    angle = np.radians(12.0)

    m = pyffag.sector_map(B_coeffs, Brho, angle=angle)
    err = pyffag.symplecticity_error(m)

    print("=== Test: Symplecticity ===")
    print(f"B_coeffs = {B_coeffs}, angle = {np.degrees(angle):.1f}°")
    print(f"|det(M) - 1| = {err:.2e}")
    assert err < 1e-12, f"Non-symplectic: error = {err}"
    print("PASS\n")


def test_fdf_ring_stability():
    """Build an FDF-triplet FFAG ring and check stability.

    In an FFAG, B1 > 0 (field increasing outward) is horizontally focusing
    because outward-displaced particles see more field → stronger bending
    back toward reference orbit.  B1 < 0 is defocusing.
    """
    DA.init(7, 2)

    Brho = kinetic_to_brho(150.0, M_PROTON)
    print(f"=== Test: FDF triplet ring (T=150 MeV, Brho={Brho:.4f} T·m) ===")

    # F magnet: horizontally focusing (B1 > 0, field increases outward)
    F = pyffag.sector_map([1.2, 3.0, 4.0], Brho, angle=np.radians(12.0))
    # D magnet: horizontally defocusing (B1 < 0, field decreases outward)
    D = pyffag.sector_map([1.2, -5.0, -5.0], Brho, angle=np.radians(6.0))

    cell = pyffag.compose_sequence([F, D, F])
    M_cell = pyffag.transfer_matrix(cell)
    print(f"Cell transfer matrix:\n{M_cell}")
    print(f"Tr/2 = {(M_cell[0,0]+M_cell[1,1])/2:.6f}")

    stable = pyffag.is_stable(cell)
    print(f"Cell stable: {stable}")
    assert stable, "FDF cell is not stable — adjust gradients"

    tw = pyffag.twiss(cell)
    print(f"Cell tune: {tw['tune']:.6f}")
    print(f"Beta: {tw['beta']:.4f} m, Alpha: {tw['alpha']:.4f}")

    ring = pyffag.compose_n(cell, 12)
    ring_stable = pyffag.is_stable(ring)
    print(f"Ring (12 cells) stable: {ring_stable}")
    assert ring_stable, "12-cell ring is not stable"

    nu = pyffag.tune(ring)
    print(f"Ring tune: {nu:.6f}")

    err = pyffag.symplecticity_error(cell)
    print(f"|det(M_cell) - 1| = {err:.2e}")
    assert err < 1e-10
    print("PASS\n")


def test_negative_bending():
    """Sector with negative B0 (reverse bend)."""
    DA.init(5, 2)

    Brho = 2.0
    B0 = -1.0  # reverse bend
    theta = -np.pi / 6  # negative angle to match

    m = pyffag.sector_map([B0], Brho, angle=theta)
    M = pyffag.transfer_matrix(m)

    rho = abs(Brho / B0)
    angle = abs(theta)
    M_exact = np.array([
        [np.cos(angle), rho * np.sin(angle)],
        [-np.sin(angle) / rho, np.cos(angle)],
    ])

    print("=== Test: Negative bending ===")
    print(f"M (pyffag):\n{M}")
    print(f"M (expected):\n{M_exact}")
    # For a reverse-bend sector, the focusing is the same
    # (curvature magnitude is the same)
    err = np.max(np.abs(M - M_exact))
    print(f"Max error: {err:.2e}")
    assert err < 1e-8, f"Reverse bend matrix error: {err}"
    print("PASS\n")


if __name__ == "__main__":
    test_uniform_sector()
    test_gradient_sector_scaling_ffag()
    test_drift()
    test_symplecticity_sector()
    test_fdf_ring_stability()
    test_negative_bending()
    print("All tests passed.")
