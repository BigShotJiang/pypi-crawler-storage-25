"""Cross-validation of pyffag sector map against analytical thick-element matrices.

For a combined-function sector magnet (dipole + quadrupole, no sextupole),
the linearised transfer matrix has the known analytical form involving
sin/cos (focusing) or sinh/cosh (defocusing).
"""

import numpy as np
from daceypy import DA
import pyffag
from pyffag.constants import kinetic_to_brho, M_PROTON


def analytical_sector_matrix(B0, B1, Brho, angle):
    """Analytical transfer matrix for a thick combined-function sector.

    For B(x) = B0 + B1*x:
      h = B0/Brho (curvature)
      k1 = B1/Brho (normalised gradient)
      K = h^2 + k1 (net focusing strength)

    M = [[cos/cosh,  sin/sinh / sqrt|K|],
         [-sqrt|K| sin/sinh,  cos/cosh]]
    """
    h = B0 / Brho
    k1 = B1 / Brho
    K = h ** 2 + k1
    rho = abs(Brho / B0)
    L = rho * abs(angle)

    if K > 0:
        sqK = np.sqrt(K)
        c = np.cos(sqK * L)
        s = np.sin(sqK * L)
        return np.array([[c, s / sqK], [-sqK * s, c]])
    elif K < 0:
        sqK = np.sqrt(-K)
        c = np.cosh(sqK * L)
        s = np.sinh(sqK * L)
        return np.array([[c, s / sqK], [sqK * s, c]])
    else:
        return np.array([[1.0, L], [0.0, 1.0]])


def test_combined_function_focusing():
    """Combined-function focusing sector (K > 0)."""
    DA.init(5, 2)
    Brho = 2.0
    B0 = 1.0
    B1 = 2.0  # strong focusing
    angle = np.radians(20.0)

    m = pyffag.sector_map([B0, B1], Brho, angle=angle)
    M_pyffag = pyffag.transfer_matrix(m)
    M_exact = analytical_sector_matrix(B0, B1, Brho, angle)

    err = np.max(np.abs(M_pyffag - M_exact))
    print("=== Focusing combined-function sector ===")
    print(f"B0={B0}, B1={B1}, angle={np.degrees(angle):.1f}°")
    print(f"h={B0/Brho:.4f}, k1={B1/Brho:.4f}, K={((B0/Brho)**2 + B1/Brho):.4f}")
    print(f"M_pyffag:\n{M_pyffag}")
    print(f"M_exact:\n{M_exact}")
    print(f"Max error: {err:.2e}")
    # Paraxial analytical vs exact Hamiltonian: small difference
    assert err < 1e-4, f"Too large: {err}"
    print("PASS\n")


def test_combined_function_defocusing():
    """Combined-function defocusing sector (K < 0)."""
    DA.init(5, 2)
    Brho = 2.0
    B0 = 1.0
    B1 = -3.0  # strong defocusing
    angle = np.radians(15.0)

    m = pyffag.sector_map([B0, B1], Brho, angle=angle)
    M_pyffag = pyffag.transfer_matrix(m)
    M_exact = analytical_sector_matrix(B0, B1, Brho, angle)

    err = np.max(np.abs(M_pyffag - M_exact))
    print("=== Defocusing combined-function sector ===")
    print(f"B0={B0}, B1={B1}, angle={np.degrees(angle):.1f}°")
    print(f"h={B0/Brho:.4f}, k1={B1/Brho:.4f}, K={((B0/Brho)**2 + B1/Brho):.4f}")
    print(f"M_pyffag:\n{M_pyffag}")
    print(f"M_exact:\n{M_exact}")
    print(f"Max error: {err:.2e}")
    assert err < 1e-4
    print("PASS\n")


def test_thin_limit():
    """In the thin-lens limit (small angle), sector_map should approach
    the thin quadrupole kick: dpx = -(h^2 + k1)*L*x."""
    DA.init(5, 2)
    Brho = 2.0
    B0 = 1.0
    B1 = 5.0
    angle = np.radians(0.1)  # very small angle
    h = B0 / Brho
    k1 = B1 / Brho
    K = h**2 + k1
    rho = Brho / B0
    L = rho * angle

    m = pyffag.sector_map([B0, B1], Brho, angle=angle)
    M = pyffag.transfer_matrix(m)

    # Thin-lens: M ≈ [[1, 0], [-K*L, 1]]
    # (plus drift contribution [[1, L], [0, 1]])
    # Combined: [[1, L], [-K*L, 1-K*L^2]]
    M_thin = np.array([[1.0, L], [-K * L, 1.0]])

    err = np.max(np.abs(M - M_thin))
    print("=== Thin-lens limit ===")
    print(f"angle = {np.degrees(angle):.3f}°, L = {L:.6f} m")
    print(f"M_pyffag:\n{M}")
    print(f"M_thin:\n{M_thin}")
    print(f"Max error: {err:.2e}")
    assert err < 1e-4
    print("PASS\n")


def test_proton_ffag_matrix():
    """Full validation: proton FFAG F-magnet sector.

    Compare pyffag vs analytical for realistic proton therapy parameters.
    """
    DA.init(7, 2)
    T = 150.0  # MeV
    Brho = kinetic_to_brho(T, M_PROTON)
    B0 = 1.2
    B1 = 3.0
    angle = np.radians(12.0)

    m = pyffag.sector_map([B0, B1], Brho, angle=angle)
    M_pyffag = pyffag.transfer_matrix(m)
    M_exact = analytical_sector_matrix(B0, B1, Brho, angle)

    err = np.max(np.abs(M_pyffag - M_exact))
    print("=== Proton FFAG F-magnet (T=150 MeV) ===")
    print(f"Brho = {Brho:.6f} T·m")
    print(f"B0={B0}, B1={B1}, angle={np.degrees(angle):.1f}°")
    h = B0 / Brho
    k1 = B1 / Brho
    print(f"h={h:.4f} m^-1, k1={k1:.4f} m^-2, K={h**2+k1:.4f} m^-2")
    print(f"M_pyffag:\n{M_pyffag}")
    print(f"M_exact:\n{M_exact}")
    print(f"Max error: {err:.2e}")
    # The paraxial vs exact difference should be O(h^2 * angle^2) ~ 10^-3
    assert err < 5e-3, f"Too large: {err}"
    print(f"det(M_pyffag) = {np.linalg.det(M_pyffag):.12f}")
    print("PASS\n")


if __name__ == "__main__":
    test_combined_function_focusing()
    test_combined_function_defocusing()
    test_thin_limit()
    test_proton_ffag_matrix()
    print("All cross-validation tests passed.")
