"""arc_avs_sdk.router.web3_router — web3.py-backed PrivacyTaskManager submitter.

Calls ``createTaskForApp(AppTaskContext, inputHash, preStateHash, postStateHash,
delta, sigEcdsa, sigMlDsa)`` on the deployed PrivacyTaskManager. Polls for the
``TaskCreated`` and ``TaskAttested`` events; populates the proof's attestation
trail when the K-of-N quorum lands.

``web3`` is a runtime extra (``pip install arc-avs-sdk[chain]``).
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any

from ..encryption import hex_to_bytes
from ..proof import PrivacyProof
from ..types import OP


def _build_signed_web3(rpc_url: str, private_key: str) -> tuple[Any, Any]:
    """Build a Web3 client wired to sign + send raw txs from ``private_key``.

    Handles both web3.py v7 (``SignAndSendRawMiddlewareBuilder``) and
    legacy v6 (``construct_sign_and_send_raw_middleware``). The v6 path
    is kept so older app stacks that haven't migrated to v7 still work,
    but the canonical install pulls v7 and uses the new builder.
    """
    try:
        from web3 import Web3  # type: ignore[import-not-found]
    except ImportError as e:
        raise RuntimeError(
            "arc/router: 'web3' not installed. Run: pip install 'arc-avs-sdk[chain]'"
        ) from e

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    acct = w3.eth.account.from_key(private_key)

    # web3.py v7 → SignAndSendRawMiddlewareBuilder.build(account)
    try:
        from web3.middleware import SignAndSendRawMiddlewareBuilder  # type: ignore[import-not-found]
        w3.middleware_onion.inject(SignAndSendRawMiddlewareBuilder.build(acct), layer=0)
        return w3, acct
    except ImportError:
        pass

    # web3.py v6 → construct_sign_and_send_raw_middleware(account)
    try:
        from web3.middleware import construct_sign_and_send_raw_middleware  # type: ignore[import-not-found]
        w3.middleware_onion.add(construct_sign_and_send_raw_middleware(acct))
        return w3, acct
    except ImportError as e:
        raise RuntimeError(
            "arc/router: web3.py is installed but neither "
            "SignAndSendRawMiddlewareBuilder (v7+) nor "
            "construct_sign_and_send_raw_middleware (v6) is available. "
            "Reinstall with: pip install --upgrade 'arc-avs-sdk[chain]'"
        ) from e


# Minimal ABI fragment — only what the router needs. Matches the deployed
# PrivacyTaskManager V1.8 byte-for-byte (signatures verified against
# `forge inspect PrivacyTaskManager methodIdentifiers`).
_TASK_MANAGER_ABI: list[dict[str, Any]] = [
    {
        "name": "createTaskForApp",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "inputHash",      "type": "bytes32"},
            {"name": "preStateHash",   "type": "bytes32"},
            {"name": "zkurtStateHash", "type": "bytes32"},
            {
                "name": "ctx",
                "type": "tuple",
                "components": [
                    {"name": "appId",       "type": "bytes32"},
                    {"name": "op",          "type": "uint32"},
                    {"name": "classId",     "type": "uint32"},
                    {"name": "processorId", "type": "uint32"},
                    {"name": "nonceSeq",    "type": "uint64"},
                    {"name": "deltaHash",   "type": "bytes32"},
                ],
            },
        ],
        "outputs": [{"name": "taskIndex", "type": "uint32"}],
    },
    # Polled to confirm the validator quorum has co-signed.
    {
        "name": "TaskAttested",
        "type": "event",
        "anonymous": False,
        "inputs": [
            {"name": "taskIndex", "type": "uint32",  "indexed": True},
            {"name": "operator",  "type": "address", "indexed": True},
            {
                "name": "attestation",
                "type": "tuple",
                "indexed": False,
                "components": [
                    {"name": "inputHash",     "type": "bytes32"},
                    {"name": "outputHash",    "type": "bytes32"},
                    {"name": "postStateHash", "type": "bytes32"},
                    {"name": "timestamp",     "type": "uint64"},
                    {"name": "dataRetained",  "type": "bool"},
                ],
            },
        ],
    },
]


_APP_REGISTRY_ABI: list[dict[str, Any]] = [
    {
        "name": "registerApp",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "domain",             "type": "string"},
            {"name": "schemaHash",         "type": "bytes32"},
            {"name": "ownerPqHash",        "type": "bytes32"},
            {"name": "ownerPqPublicKey",   "type": "bytes"},
            {"name": "complianceFlags",    "type": "uint32"},
            {"name": "declaredAdapters",   "type": "uint32"},
            {"name": "declaredProcessors", "type": "uint32"},
        ],
        "outputs": [{"name": "appId", "type": "bytes32"}],
    },
    {
        "name": "rotatePqKey",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "appId",          "type": "bytes32"},
            {"name": "newPqPublicKey", "type": "bytes"},
        ],
        "outputs": [],
    },
    {
        "name": "commitManifest",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "appId",        "type": "bytes32"},
            {"name": "manifestHash", "type": "bytes32"},
            {"name": "bundleHash",   "type": "bytes32"},
        ],
        "outputs": [],
    },
    {
        "name": "AppRegistered",
        "type": "event",
        "anonymous": False,
        "inputs": [
            {"name": "appId",              "type": "bytes32", "indexed": True},
            {"name": "domain",             "type": "string",  "indexed": False},
            {"name": "ownerEcdsa",         "type": "address", "indexed": True},
            {"name": "schemaHash",         "type": "bytes32"},
            {"name": "ownerPqHash",        "type": "bytes32"},
            {"name": "ownerPqPublicKey",   "type": "bytes"},
            {"name": "complianceFlags",    "type": "uint32"},
            {"name": "declaredAdapters",   "type": "uint32"},
            {"name": "declaredProcessors", "type": "uint32"},
        ],
    },
    {
        "name": "PqKeyRotated",
        "type": "event",
        "anonymous": False,
        "inputs": [
            {"name": "appId",          "type": "bytes32", "indexed": True},
            {"name": "oldPqHash",      "type": "bytes32", "indexed": True},
            {"name": "newPqHash",      "type": "bytes32", "indexed": True},
            {"name": "newPqPublicKey", "type": "bytes"},
        ],
    },
]


@dataclass(slots=True)
class Web3ValidatorRouter:
    """Submits proofs + ArcAppRegistry txs via web3.py.

    The submitter EOA pays gas. PrivacyTaskManager attestations and
    ArcAppRegistry registrations both flow through this single object.
    `app_registry` is required for `register_app` / `commit_manifest`;
    leave unset if you only need `submit`.
    """

    rpc_url: str
    private_key: str
    task_manager: str
    app_registry: str | None = None
    poll_interval: float = 4.0
    poll_timeout:  float = 120.0

    async def submit(self, proof: PrivacyProof) -> PrivacyProof:
        w3, acct = _build_signed_web3(self.rpc_url, self.private_key)
        contract = w3.eth.contract(
            address=w3.to_checksum_address(self.task_manager),
            abi=_TASK_MANAGER_ABI,
        )

        # AppTaskContext — matches the deployed PrivacyTaskManager V1.8
        # struct exactly: 6 fields ending with deltaHash.
        ctx = (
            hex_to_bytes(proof.app_id),
            OP[proof.op],
            proof.class_id,
            proof.processor_id,
            proof.nonce_seq,
            hex_to_bytes(proof.delta_hash),
        )

        # web3.py is sync; run the blocking calls in a thread.
        loop = asyncio.get_running_loop()

        def _send() -> str:
            # Live signature: createTaskForApp(inputHash, preStateHash,
            # zkurtStateHash, ctx). The contract derives `outputHash` and
            # `dataRetained` from the validator's later submitAttestation
            # call; the create path commits ctx + the three state hashes.
            # User signatures live inside the envelope (sigEcdsa/sigMlDsa
            # in the cipher tuple), not as separate arguments.
            tx_hash = contract.functions.createTaskForApp(
                hex_to_bytes(proof.input_hash),
                hex_to_bytes(proof.pre_state_hash),
                hex_to_bytes(proof.post_state_hash),       # zkurtStateHash slot
                ctx,
            ).transact({"from": acct.address})
            return tx_hash.hex()

        tx_hash = await loop.run_in_executor(None, _send)
        proof.attestation_tx_hash = "0x" + tx_hash if not tx_hash.startswith("0x") else tx_hash

        # Poll for TaskAttested matching this proof's input_hash.
        deadline = time.time() + self.poll_timeout
        validators: list[str] = []

        def _scan_attestations() -> tuple[list[str], int | None]:
            event = contract.events.TaskAttested
            from_block = max(w3.eth.block_number - 64, 0)
            logs = event().get_logs(fromBlock=from_block)
            ops: list[str] = []
            attested_at: int | None = None
            for log in logs:
                att = log["args"]["attestation"]
                if att[0].hex().lower().lstrip("0x") == proof.input_hash.lower().lstrip("0x"):
                    ops.append(log["args"]["operator"])
                    attested_at = int(att[3])
            return ops, attested_at

        while time.time() < deadline:
            validators, attested_at = await loop.run_in_executor(None, _scan_attestations)
            if validators:
                proof.validators = validators
                proof.attested_at = attested_at
                break
            await asyncio.sleep(self.poll_interval)

        return proof

    # ── ArcAppRegistry — register_app / commit_manifest ────────────

    def _build_app_registry(self) -> tuple[Any, Any, Any]:
        if not self.app_registry:
            raise RuntimeError(
                "arc/router: app_registry address required. Pass it to "
                "Web3ValidatorRouter(app_registry=...) — the live address "
                "is published in /sdk.md (V1.8: 0xD27a4903…ea13)."
            )
        w3, acct = _build_signed_web3(self.rpc_url, self.private_key)
        contract = w3.eth.contract(
            address=w3.to_checksum_address(self.app_registry),
            abi=_APP_REGISTRY_ABI,
        )
        return w3, acct, contract

    async def register_app(
        self,
        *,
        domain: str,
        schema_hash: bytes,
        owner_pq_hash: bytes,
        owner_pq_public_key: bytes,
        compliance_flags: int,
        declared_adapters: int,
        declared_processors: int,
    ) -> dict[str, object]:
        """Register the app on ArcAppRegistry. Reverts if already registered.

        `owner_pq_public_key` is the full ML-DSA-65 pubkey bytes (1952 bytes
        for FIPS 204). The contract requires
        `keccak256(owner_pq_public_key) == owner_pq_hash` and emits the
        bytes in `AppRegistered` so event-tailing validators (e.g.
        `app-relay-rs` `RegistryKeyStore`) can build a keystore from log
        history. Closes SDK-V1-GAPS §12-contract.
        """
        w3, acct, registry = self._build_app_registry()
        loop = asyncio.get_running_loop()

        def _send() -> dict[str, object]:
            tx_hash = registry.functions.registerApp(
                domain,
                schema_hash,
                owner_pq_hash,
                owner_pq_public_key,
                compliance_flags,
                declared_adapters,
                declared_processors,
            ).transact({"from": acct.address})
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
            # appId is the return value of the function (not in events directly
            # without a parser). Compute it deterministically — this matches
            # the contract's `keccak256(lowercased(domain))`.
            from eth_hash.auto import keccak
            app_id = "0x" + keccak(domain.lower().encode("utf-8")).hex()
            return {
                "app_id":       app_id,
                "tx_hash":      tx_hash.hex() if not tx_hash.hex().startswith("0x") else "0x" + tx_hash.hex().lstrip("0x"),
                "block_number": int(receipt.blockNumber),
            }

        return await loop.run_in_executor(None, _send)

    async def commit_manifest(
        self,
        *,
        app_id: bytes,
        manifest_hash: bytes,
        bundle_hash: bytes,
    ) -> dict[str, object]:
        """Commit a new manifest version. `onlyAppOwner` — caller's EOA must
        match the address that originally called `registerApp`."""
        w3, acct, registry = self._build_app_registry()
        loop = asyncio.get_running_loop()

        def _send() -> dict[str, object]:
            tx_hash = registry.functions.commitManifest(
                app_id,
                manifest_hash,
                bundle_hash,
            ).transact({"from": acct.address})
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
            return {
                "tx_hash":      "0x" + tx_hash.hex().lstrip("0x"),
                "block_number": int(receipt.blockNumber),
            }

        return await loop.run_in_executor(None, _send)
