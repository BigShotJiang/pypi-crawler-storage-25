"""arc_avs_sdk.router.base — ValidatorRouter Protocol + Noop default.

The router is the runtime's gateway to every on-chain interaction:

  * `submit(proof)`      — PrivacyTaskManager.createTaskForApp(...)
  * `register_app(...)`  — ArcAppRegistry.registerApp(...)
  * `commit_manifest(..)`— ArcAppRegistry.commitManifest(...)

Implementations: :class:`NoopValidatorRouter` (in-memory, for tests),
:class:`Web3ValidatorRouter` (production, web3.py-backed).
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from ..proof import PrivacyProof


@runtime_checkable
class ValidatorRouter(Protocol):
    """Submit a :class:`PrivacyProof` and manage app-registry on-chain state."""

    async def submit(self, proof: PrivacyProof) -> PrivacyProof:
        """Submit a privacy proof to PrivacyTaskManager.

        Returns the proof with ``attestation_tx_hash`` / ``validators`` /
        ``attested_at`` populated once the validator quorum lands.
        """
        ...

    async def register_app(
        self,
        *,
        domain: str,
        schema_hash: bytes,
        owner_pq_hash: bytes,
        owner_pq_public_key: bytes,
        compliance_flags: int,
        declared_adapters: int,
        declared_processors: int,
    ) -> dict[str, object]:
        """Register the app on ArcAppRegistry.

        ``owner_pq_public_key`` is the full ML-DSA-65 pubkey bytes (1952
        bytes); the contract enforces ``keccak256(...) == owner_pq_hash``
        and emits the bytes in ``AppRegistered``. Closes SDK-V1-GAPS
        §12-contract — event-tailing validators get the pubkey from
        log history without a side channel.

        Returns ``{"app_id": "0x...", "tx_hash": "0x...", "block_number": int}``.
        Reverts on chain if the domain is already registered.
        """
        ...

    async def commit_manifest(
        self,
        *,
        app_id: bytes,
        manifest_hash: bytes,
        bundle_hash: bytes,
    ) -> dict[str, object]:
        """Commit a new manifest version (`onlyAppOwner`).

        Returns ``{"tx_hash": "0x...", "block_number": int}``.
        """
        ...


class NoopValidatorRouter:
    """No-op router. In-memory only — useful for tests and dry-runs.

    Each non-submit method returns a deterministic stub so test code can
    assert against a stable shape without standing up a chain.
    """

    async def submit(self, proof: PrivacyProof) -> PrivacyProof:
        return proof

    async def register_app(
        self,
        *,
        domain: str,
        schema_hash: bytes,
        owner_pq_hash: bytes,
        owner_pq_public_key: bytes,
        compliance_flags: int,
        declared_adapters: int,
        declared_processors: int,
    ) -> dict[str, object]:
        # Stub the appId as keccak256(domain.lower()) so tests can pin it.
        from eth_hash.auto import keccak

        app_id = keccak(domain.lower().encode("utf-8"))
        _ = (
            schema_hash, owner_pq_hash, owner_pq_public_key,
            compliance_flags, declared_adapters, declared_processors,
        )
        return {
            "app_id": "0x" + app_id.hex(),
            "tx_hash": "0x" + ("00" * 32),
            "block_number": 0,
        }

    async def commit_manifest(
        self,
        *,
        app_id: bytes,
        manifest_hash: bytes,
        bundle_hash: bytes,
    ) -> dict[str, object]:
        _ = app_id, manifest_hash, bundle_hash
        return {"tx_hash": "0x" + ("00" * 32), "block_number": 0}
