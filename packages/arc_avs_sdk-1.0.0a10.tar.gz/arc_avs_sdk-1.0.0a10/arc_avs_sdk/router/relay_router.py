"""arc_avs_sdk.router.relay_router — V1.9 relay-based ValidatorRouter.

Pushes :class:`PrivacyProof` objects to one or more app-relay WebSocket
endpoints. The relay batches proofs into a per-app merkle tree and lands
them on chain via ``ArcAppEpochRegistry.submitAppEpochRoot`` (one tx
settles up to ~230k attestations).

Drop-in replacement for :class:`Web3ValidatorRouter`. Apps switch by
changing one line at ``init`` — same ``ValidatorRouter`` Protocol.

Layered defenses (matches the design in ``app/public/sdk.md`` §
"Layered defense for app-side survivability"):

* **Fan-out** — submit to N relays in parallel; first to ack counts.
  ``min_acks`` controls how many must ack before the call returns
  successful (default: 1; raise to ``len(relays)`` for full quorum).
* **Signed receipts** — each relay returns a receipt naming
  ``(app_id, leaf_index, epoch_index)``. Caller can hold receipts as
  forensic proof of submission.
* **L1 fallback** — if every relay errors / times out and
  ``fallback_router`` is set, the call falls through to that router
  (typically ``Web3ValidatorRouter`` for direct ``createTaskForApp``).
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import Any

from ..proof import PrivacyProof
from .base import NoopValidatorRouter, ValidatorRouter


@dataclass(slots=True)
class RelayReceipt:
    """The signed-ish receipt one relay returns after WAL-fsync of a proof.

    The relay isn't a trust anchor — its receipt is a *forensic claim*
    of submission, not a chain commitment. Once the epoch lands on
    ``ArcAppEpochRegistry``, the proof's inclusion is independently
    verifiable via ``verifyInclusion(appId, epochIndex, leaf, proof, leafIndex)``.
    """

    relay_url:    str
    app_id:       str
    leaf_index:   int
    epoch_index:  int
    valid:        bool
    ack_ms:       float


@dataclass(slots=True)
class Web3RelayRouter:
    """V1.9 — push proofs to N app-relay endpoints over WebSocket.

    The class name keeps the ``Web3*`` prefix for symmetry with
    :class:`Web3ValidatorRouter`; both implement the :class:`ValidatorRouter`
    Protocol and can be swapped via the ``router=`` kwarg of ``init``.

    Args:
        relays:           One or more ``ws://`` / ``wss://`` URLs of running
                          ``arc-app-relay`` instances.
        min_acks:         Minimum relays that must ack before ``submit``
                          returns successful. Default 1 (any one relay).
                          Raise to ``len(relays)`` for full fan-out quorum.
        ack_timeout:      Seconds to wait for each relay to ack. Default 5.
        fallback_router:  Optional fallback if every relay fails. Typically
                          :class:`Web3ValidatorRouter` for direct
                          ``createTaskForApp``. Default ``None``.
        api_key:          Optional ``Bearer`` token added to the WS auth
                          frame. The relay's auth handler accepts it; not
                          enforced by V1.9 alpha.
    """

    relays: tuple[str, ...] = ()
    min_acks: int = 1
    ack_timeout: float = 5.0
    fallback_router: ValidatorRouter | None = None
    api_key: str | None = None

    # State carried across calls
    _last_receipts: list[RelayReceipt] = field(default_factory=list)

    async def submit(self, proof: PrivacyProof) -> PrivacyProof:
        """Push the proof to all configured relays in parallel.

        Returns the original proof object (unchanged on the field side).
        Per-relay receipts accumulate on ``self.last_receipts`` so the
        caller can audit which relays acked.
        """
        if not self.relays:
            if self.fallback_router is not None:
                return await self.fallback_router.submit(proof)
            return proof  # No-op (matches NoopValidatorRouter for tests)

        try:
            import websockets  # type: ignore[import-not-found]
        except ImportError as e:
            raise RuntimeError(
                "arc/relay: 'websockets' not installed. Run: "
                "pip install 'arc-avs-sdk[chain]' (or websockets directly)"
            ) from e

        msg = json.dumps(_proof_to_relay_message(proof))

        async def _push(relay_url: str) -> RelayReceipt | Exception:
            started = time.perf_counter()
            try:
                async with await asyncio.wait_for(
                    websockets.connect(relay_url),                      # type: ignore[attr-defined]
                    timeout=self.ack_timeout,
                ) as ws:
                    if self.api_key:
                        await ws.send(json.dumps({"type": "auth", "apiKey": self.api_key}))
                        _ = await asyncio.wait_for(ws.recv(), timeout=self.ack_timeout)
                    await ws.send(msg)
                    raw = await asyncio.wait_for(ws.recv(), timeout=self.ack_timeout)
                    payload = json.loads(raw)
                    if payload.get("type") != "app_proof_ack":
                        return RuntimeError(
                            f"relay {relay_url} returned {payload.get('type')!r}: "
                            f"{payload.get('error')}"
                        )
                    rec = payload["receipt"]
                    return RelayReceipt(
                        relay_url=relay_url,
                        app_id=rec["appId"],
                        leaf_index=int(rec["leafIndex"]),
                        epoch_index=int(rec["epochIndex"]),
                        valid=bool(rec["valid"]),
                        ack_ms=float(rec.get("ackMs", (time.perf_counter() - started) * 1000)),
                    )
            except Exception as exc:  # noqa: BLE001 — relay errors are first-class
                return exc

        results = await asyncio.gather(*(_push(u) for u in self.relays))

        receipts = [r for r in results if isinstance(r, RelayReceipt) and r.valid]
        errors   = [r for r in results if not isinstance(r, RelayReceipt) or not getattr(r, "valid", False)]
        self._last_receipts = receipts

        if len(receipts) >= self.min_acks:
            # Stamp the proof with the first relay's epoch for caller-side
            # convenience. Auto-inclusion verification (post-epoch) lives
            # on the consumer side via ``verifyInclusion`` reads.
            first = receipts[0]
            proof.attestation_tx_hash = None  # set by relay on chain submit, not here
            proof.attested_at = int(time.time())
            return proof

        # Not enough relays acked — fall through to the per-tx fallback if set.
        if self.fallback_router is not None:
            return await self.fallback_router.submit(proof)
        # Otherwise raise — the caller has to know none of their relays were healthy.
        raise RuntimeError(
            f"arc/relay: only {len(receipts)} of {len(self.relays)} relays acked "
            f"(min_acks={self.min_acks}); errors={errors}"
        )

    @property
    def last_receipts(self) -> list[RelayReceipt]:
        """Receipts from the most recent ``submit`` call (forensic / debug)."""
        return list(self._last_receipts)

    # ── ArcAppRegistry path is delegated to fallback_router (or Noop). ──
    # The relay router's job is proof submission; app registration is a
    # one-time setup tx that doesn't go through the relay.

    async def register_app(self, **kwargs: Any) -> dict[str, object]:
        if self.fallback_router is not None and hasattr(self.fallback_router, "register_app"):
            return await self.fallback_router.register_app(**kwargs)  # type: ignore[no-any-return]
        return await NoopValidatorRouter().register_app(**kwargs)

    async def commit_manifest(self, **kwargs: Any) -> dict[str, object]:
        if self.fallback_router is not None and hasattr(self.fallback_router, "commit_manifest"):
            return await self.fallback_router.commit_manifest(**kwargs)  # type: ignore[no-any-return]
        return await NoopValidatorRouter().commit_manifest(**kwargs)


# Alias for symmetry with the runtime / docs nomenclature.
RelayValidatorRouter = Web3RelayRouter


def _proof_to_relay_message(proof: PrivacyProof) -> dict[str, object]:
    """Serialize a :class:`PrivacyProof` to the relay's WS frame.

    Field names match the relay's ``AppProofIn`` Rust struct verbatim.
    """
    return {
        "type":          "app_proof",
        "appId":         proof.app_id,
        "op":            proof.op,
        "className":     proof.class_name,
        "classId":       proof.class_id,
        "processorId":   proof.processor_id,
        "nonceSeq":      proof.nonce_seq,
        "timestamp":     proof.timestamp,
        "inputHash":     proof.input_hash,
        "preStateHash":  proof.pre_state_hash,
        "postStateHash": proof.post_state_hash,
        "deltaHash":     proof.delta_hash,
        "sigEcdsa":      proof.sig_ecdsa,
        "sigMlDsa":      proof.sig_ml_dsa,
        "id":            proof.input_hash,  # default dedup id
    }
