"""arc_avs_sdk.encryption — PQ-hybrid encryption + signing.

Algorithms (NIST PQC standardized):
  - ML-KEM-768  (FIPS 203, Kyber)        → wraps the per-record AES key
  - ML-DSA-65   (FIPS 204, Dilithium-3)  → signs alongside ECDSA
  - AES-256-GCM (FIPS 197 / SP 800-38D)  → record-level encryption
  - secp256k1 ECDSA                      → chain-native signature path

Mirrors `@arc-avs/sdk/src/encryption.ts` byte-for-byte. The
`bind_aad`, `bind_digest`, and envelope layout MUST match the TS
implementation so envelopes round-trip cross-language.
"""

from __future__ import annotations

import os
import struct
from dataclasses import dataclass
from typing import Final, Literal

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from eth_hash.auto import keccak

# secp256k1 — coincurve is fast and matches the @noble/curves output bit-for-bit
import coincurve

# Post-quantum primitives — pure-Python FIPS 203 / FIPS 204 implementations.
# Wire format must agree with @noble/post-quantum.
from kyber_py.ml_kem import ML_KEM_768  # type: ignore[import-untyped]
from dilithium_py.ml_dsa import ML_DSA_65  # type: ignore[import-untyped]


# ── Random ───────────────────────────────────────────────────────────


def random_bytes(n: int) -> bytes:
    """OS-provided random. Always use os.urandom — not random.random."""
    return os.urandom(n)


# ── ML-KEM-768 ───────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class KemKeypair:
    """ML-KEM-768 keypair. Public key is 1184 bytes, secret key 2400 bytes."""

    public_key: bytes
    secret_key: bytes


def kem_keygen(seed: bytes | None = None) -> KemKeypair:
    """Generate a fresh ML-KEM-768 keypair. Pass `seed` (64 bytes) for determinism."""
    if seed is not None:
        if len(seed) != 64:
            raise ValueError("arc/kem: seed must be 64 bytes")
        # ML_KEM_768 accepts a deterministic seed split as (d, z) where each is 32 bytes.
        pk, sk = ML_KEM_768.key_derive(seed[:32], seed[32:])
    else:
        pk, sk = ML_KEM_768.keygen()
    return KemKeypair(public_key=bytes(pk), secret_key=bytes(sk))


def kem_encapsulate(public_key: bytes) -> tuple[bytes, bytes]:
    """Return ``(ciphertext, shared_secret)``. ``ciphertext`` is 1088 bytes,
    ``shared_secret`` 32 bytes. The shared secret is used as the AES-256 key.
    """
    shared_secret, ciphertext = ML_KEM_768.encaps(public_key)
    return bytes(ciphertext), bytes(shared_secret)


def kem_decapsulate(secret_key: bytes, ciphertext: bytes) -> bytes:
    """Recover the 32-byte shared secret from a KEM ciphertext."""
    return bytes(ML_KEM_768.decaps(secret_key, ciphertext))


# ── AES-256-GCM ──────────────────────────────────────────────────────


def aes_encrypt(key: bytes, nonce: bytes, plaintext: bytes, aad: bytes) -> bytes:
    """AES-256-GCM. ``key`` must be 32 bytes, ``nonce`` 12 bytes."""
    if len(key) != 32:
        raise ValueError("arc/aes: 32-byte key required")
    if len(nonce) != 12:
        raise ValueError("arc/aes: 12-byte nonce required")
    return AESGCM(key).encrypt(nonce, plaintext, aad)


def aes_decrypt(key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
    """Inverse of :func:`aes_encrypt`. Raises ``InvalidTag`` on AAD/key mismatch."""
    return AESGCM(key).decrypt(nonce, ciphertext, aad)


def wipe(b: bytearray) -> None:
    """Best-effort zeroization. Python doesn't guarantee buffer overwrite the way
    Rust / C can — but mutating a bytearray in place reduces the exposure window.
    """
    for i in range(len(b)):
        b[i] = 0


# ── Bind AAD + digest (must match TS byte layout) ────────────────────


def bind_aad(app_id: str, class_name: str, nonce_seq: int) -> bytes:
    """AAD woven into AES-GCM — binds the ciphertext to ``(appId, className, seq)``.

    Layout (matches TS):
        [0..32]      app_id        (32 bytes from hex)
        [32..32+L]   class_name    (UTF-8)
        [32+L..+8]   nonce_seq     (big-endian uint64)
    """
    cls = class_name.encode("utf-8")
    return _hex_to_bytes(app_id) + cls + nonce_seq.to_bytes(8, "big")


def bind_digest(
    app_id: str,
    class_name: str,
    nonce_seq: int,
    wrapped_key: bytes,
    nonce: bytes,
    ciphertext: bytes,
    aad: bytes,
) -> bytes:
    """32-byte commitment that the app signs to attest the envelope.

    Layout (matches TS):
        app_id (32) | class_name (UTF-8) | nonce_seq (BE u64) |
        wrapped_key | nonce | ciphertext | aad
    Then keccak256.
    """
    cls = class_name.encode("utf-8")
    payload = b"".join(
        [
            _hex_to_bytes(app_id),
            cls,
            nonce_seq.to_bytes(8, "big"),
            wrapped_key,
            nonce,
            ciphertext,
            aad,
        ]
    )
    return keccak(payload)


# ── Envelope ─────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class CipherEnvelope:
    """On-disk shape of any encrypted field. Written by every adapter as opaque bytes."""

    v: Literal[1] = 1
    cipher: Literal["ml-kem-768+aes-256-gcm"] = "ml-kem-768+aes-256-gcm"
    wrapped_key: bytes = b""
    nonce: bytes = b""
    ciphertext: bytes = b""
    aad: bytes = b""
    sig_ecdsa: bytes = b""
    sig_ml_dsa: bytes = b""
    nonce_seq: int = 0


def seal_envelope(
    *,
    plaintext: bytes,
    user_kem_public_key: bytes,
    app_ecdsa_private_key: bytes,
    app_ml_dsa_private_key: bytes,
    app_id: str,
    class_name: str,
    nonce_seq: int,
) -> CipherEnvelope:
    """Seal a plaintext into a :class:`CipherEnvelope`.

    The user's KEM public key wraps a freshly-generated AES key; AES-GCM encrypts
    the plaintext; ECDSA + ML-DSA-65 sign over the canonical bind digest.
    """
    wrapped_key, shared_secret = kem_encapsulate(user_kem_public_key)
    nonce = random_bytes(12)
    aad = bind_aad(app_id, class_name, nonce_seq)
    try:
        ct = aes_encrypt(shared_secret, nonce, plaintext, aad)
    finally:
        # We can't actually wipe `shared_secret` because Python returned an
        # immutable bytes object. We rely on GC. A future revision could route
        # through a bytearray buffer.
        pass

    digest = bind_digest(app_id, class_name, nonce_seq, wrapped_key, nonce, ct, aad)
    sig_ecdsa = ecdsa_sign(app_ecdsa_private_key, digest)
    sig_ml_dsa = dsa_sign(app_ml_dsa_private_key, digest)

    return CipherEnvelope(
        wrapped_key=wrapped_key,
        nonce=nonce,
        ciphertext=ct,
        aad=aad,
        sig_ecdsa=sig_ecdsa,
        sig_ml_dsa=sig_ml_dsa,
        nonce_seq=nonce_seq,
    )


def seal_envelope_as_user(
    *,
    plaintext: bytes,
    user_kem_public_key: bytes,
    user_ecdsa_private_key: bytes,
    user_ml_dsa_private_key: bytes,
    app_id: str,
    class_name: str,
    nonce_seq: int,
) -> CipherEnvelope:
    """Seal an envelope using **user-derived** signing keys (non-custodial mode).

    Identical wire output to :func:`seal_envelope`, but the parameter names
    make the semantics unambiguous: in client-custody flows, the envelope's
    internal ECDSA + ML-DSA-65 signatures are produced by the *user* (typically
    via HKDF from a wallet PRF seed), **not** by the application's registered
    signing keys.

    Two-layer signing model in non-custodial mode:

    * Envelope sigs (this function) — prove the user authored this exact
      ciphertext blob. Computed client-side. Stored in the envelope tuple.
    * Proof sigs (built by the backend's runtime in ``_proof_and_attest``) —
      prove the registered app committed this envelope to the validator
      network. Computed server-side. Submitted on-chain via
      ``createTaskForApp``. **This is what validators verify against
      ArcAppRegistry's ownerEcdsa.**

    Validators do **not** verify the envelope sigs against the AppRegistry
    owner — they verify the proof sigs. The envelope sigs are for the
    user-app trust boundary, not the validator-app boundary.

    Recommended user-key derivation (matches the canonical pattern used by
    the @arc-avs/sdk JS browser-side helpers)::

        seed = wallet_prf_or_signature_seed
        user_kem      = HKDF(seed, salt='arc-avs-user-kem-v1', info='ml-kem-768-keypair:<userId>')
        user_ecdsa    = HKDF(seed, salt='arc-avs-user-sig-v1', info='ecdsa-secp256k1:<userId>')
        user_ml_dsa   = HKDF(seed, salt='arc-avs-user-sig-v1', info='ml-dsa-65:<userId>')

    The seed never leaves the client. The three keypairs are deterministic
    derivations so the same user can re-derive on a fresh device with no
    server round-trip.
    """
    return seal_envelope(
        plaintext=plaintext,
        user_kem_public_key=user_kem_public_key,
        app_ecdsa_private_key=user_ecdsa_private_key,
        app_ml_dsa_private_key=user_ml_dsa_private_key,
        app_id=app_id,
        class_name=class_name,
        nonce_seq=nonce_seq,
    )


def open_envelope(*, envelope: CipherEnvelope, user_kem_secret_key: bytes) -> bytes:
    """Open an envelope. Raises ``InvalidTag`` if the secret key doesn't match."""
    shared_secret = kem_decapsulate(user_kem_secret_key, envelope.wrapped_key)
    return aes_decrypt(shared_secret, envelope.nonce, envelope.ciphertext, envelope.aad)


# ── ECDSA (secp256k1, compact 65-byte ‖ r ‖ s ‖ v) ──────────────────


def ecdsa_sign(private_key: bytes, digest: bytes) -> bytes:
    """65-byte signature: ``r || s || v`` where ``v ∈ {27, 28}``."""
    if len(private_key) != 32:
        raise ValueError("arc/ecdsa: 32-byte key required")
    if len(digest) != 32:
        raise ValueError("arc/ecdsa: 32-byte digest required")
    pk = coincurve.PrivateKey(private_key)
    sig = pk.sign_recoverable(digest, hasher=None)  # 65 bytes: r || s || recovery_id (0/1)
    out = bytearray(sig)
    out[64] = out[64] + 27
    return bytes(out)


def ecdsa_verify(public_key: bytes, digest: bytes, signature: bytes) -> bool:
    """Verify a 65-byte signature ``(r ‖ s ‖ v)``.

    Accepts both compressed (33 bytes) and uncompressed (65 bytes) public keys.
    Implementation: recover the public key from the recoverable signature and
    compare against the provided one — matches what the on-chain ecrecover
    opcode does, which is what we need anyway for chain compatibility.
    """
    if len(signature) != 65:
        return False
    try:
        # Bring v ∈ {27, 28} back to recovery_id ∈ {0, 1}
        sig_recover = signature[:64] + bytes([(signature[64] - 27) & 1])
        recovered = coincurve.PublicKey.from_signature_and_message(
            sig_recover, digest, hasher=None
        )
        return (
            recovered.format(compressed=False) == public_key
            or recovered.format(compressed=True) == public_key
        )
    except Exception:
        return False


def ecdsa_public_key(private_key: bytes, compressed: bool = False) -> bytes:
    """Derive the secp256k1 public key from a 32-byte private key."""
    pk = coincurve.PrivateKey(private_key).public_key
    return pk.format(compressed=compressed)


# ── ML-DSA-65 (Dilithium-3) ──────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class DsaKeypair:
    """ML-DSA-65 keypair. Public key 1952 bytes, secret key 4032 bytes."""

    public_key: bytes
    secret_key: bytes


def dsa_keygen(seed: bytes | None = None) -> DsaKeypair:
    """Generate a fresh ML-DSA-65 keypair. Pass ``seed`` (32 bytes) for determinism."""
    if seed is not None:
        if len(seed) != 32:
            raise ValueError("arc/dsa: seed must be 32 bytes")
        pk, sk = ML_DSA_65.key_derive(seed)
    else:
        pk, sk = ML_DSA_65.keygen()
    return DsaKeypair(public_key=bytes(pk), secret_key=bytes(sk))


def dsa_sign(secret_key: bytes, digest: bytes) -> bytes:
    """Sign a 32-byte digest with ML-DSA-65."""
    return bytes(ML_DSA_65.sign(secret_key, digest))


def dsa_verify(public_key: bytes, digest: bytes, signature: bytes) -> bool:
    """Verify an ML-DSA-65 signature."""
    try:
        return bool(ML_DSA_65.verify(public_key, digest, signature))
    except Exception:
        return False


# ── Hex helpers ──────────────────────────────────────────────────────


def hex_to_bytes(hex_str: str) -> bytes:
    """Decode ``"0x..."`` or bare hex into bytes. Wrapper kept stable for callers."""
    return _hex_to_bytes(hex_str)


def _hex_to_bytes(hex_str: str) -> bytes:
    s = hex_str[2:] if hex_str.startswith("0x") else hex_str
    if len(s) % 2 != 0:
        raise ValueError("arc/hex: odd length")
    return bytes.fromhex(s)


def bytes_to_hex(b: bytes) -> str:
    """Encode bytes as ``"0x..."``."""
    return "0x" + b.hex()


# Make struct unused-import linter happy — kept for future binary helpers.
_ = struct
_FOUR_BE: Final = "!I"
