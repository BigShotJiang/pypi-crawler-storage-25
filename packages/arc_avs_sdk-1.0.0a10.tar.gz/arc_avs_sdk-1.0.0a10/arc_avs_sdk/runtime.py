"""arc_avs_sdk.runtime — Live state of an initialized SDK.

Holds the schema, adapter, processors, registered keys, and the per-user nonce
sequence. The runtime is the dispatcher for every operation primitive
(create_user, put_record, read, list, process, purge_user, export_user, etc).

Apps acquire a runtime via :func:`init` and then talk to it through async
methods that mirror the TS SDK surface 1:1, in Python idiom (snake_case).

Two key-custody modes:

* ``key_custody="server"`` (default) — runtime generates and holds each user's
  ML-KEM-768 keypair. Backend can decrypt records on demand. Simpler for
  prototyping and for apps where the server is already trusted with plaintext
  (e.g. a managed account model). The keypair is in-memory only; production
  servers will want to wrap a KMS or write durable storage.

* ``key_custody="client"`` — non-custodial. The user's KEM secret key never
  reaches the backend. The frontend (e.g. a browser SDK derived from a wallet
  PRF) seals envelopes locally and ships *envelope bytes* to the backend; the
  backend persists them, commits proofs to the validator network, and serves
  them back as ciphertext on read. Decryption only happens client-side. The
  Python SDK exposes ``register_user`` / ``persist_envelope`` / ``fetch_envelope``
  for this mode and refuses ``read`` / ``process`` / ``export_user`` (which
  would require the secret key the server doesn't have).
"""

from __future__ import annotations

import json
import secrets
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Generic, Literal, TypeVar

from eth_hash.auto import keccak

from .adapter.base import AdapterRecord, IndexedQuery, PointQuery, StorageAdapter
from .encryption import (
    CipherEnvelope,
    DsaKeypair,
    KemKeypair,
    bytes_to_hex,
    dsa_keygen,
    ecdsa_public_key,
    hex_to_bytes,
    kem_keygen,
    open_envelope,
    random_bytes,
    seal_envelope,
)
from .processor.base import Processor, ProcessorInput
from .proof import (
    BuildProofInput,
    PQVerification,
    PrivacyProof,
    build_proof,
    verify_pq_attestation as _verify_pq,
)
from .router.base import NoopValidatorRouter, ValidatorRouter
from .schema import SchemaDescriptor, canonicalize_schema
from .types import AppId, ReadContext, RecordRef, UserHandle, cipher_suite_id_of


# Cipher suite the runtime currently seals under. Bound into every proof's
# ``cipher_suite`` field so the writer's signature commits to it. If the
# runtime grows multi-suite support, derive this per-envelope from the
# actual ``envelope.cipher`` tag instead of the constant.
_DEFAULT_CIPHER_SUITE_ID = cipher_suite_id_of("ml-kem-768+aes-256-gcm")


KeyCustody = Literal["server", "client"]


class ClientCustodyError(RuntimeError):
    """Raised when a server-decrypting method is called in client-custody mode.

    In ``key_custody="client"`` mode the runtime never receives the user's KEM
    secret key, so methods that require decryption (``read``, ``process``,
    ``export_user``) cannot run server-side. Callers should fetch envelope
    bytes via ``fetch_envelope`` and decrypt on the client (TS SDK
    ``openEnvelope`` is the canonical decoder).
    """


T = TypeVar("T")


@dataclass(slots=True)
class HoldOnce(Generic[T]):
    """Plaintext valid for a single ``await use(fn)`` call. Buffer wiped on exit.

    The plaintext cannot be extracted as a raw value; callers pass an async
    callback that the runtime invokes once. After ``use`` returns, the
    underlying ``bytearray`` is overwritten in place.
    """

    context_id: ReadContext
    _plaintext: bytearray | None
    _decoder: Callable[[bytes], T]

    async def use(self, fn: Callable[[T], Awaitable[Any] | Any]) -> Any:
        if self._plaintext is None:
            raise RuntimeError("arc/holdonce: already used or wiped")
        try:
            decoded = self._decoder(bytes(self._plaintext))
            res = fn(decoded)
            if hasattr(res, "__await__"):
                res = await res
            return res
        finally:
            for i in range(len(self._plaintext)):
                self._plaintext[i] = 0
            self._plaintext = None


@dataclass(slots=True)
class _UserKey:
    """Per-user KEM keypair material held by the runtime."""

    handle: UserHandle
    kem: KemKeypair


@dataclass(slots=True)
class _UserPubkey:
    """Just the public side — used in client-custody mode where the runtime
    never sees the user's secret key."""

    handle: UserHandle
    kem_public_key: bytes


@dataclass(slots=True)
class ArcRuntime:
    """The dispatcher every user-data op routes through."""

    app_id: AppId
    schema: SchemaDescriptor
    schema_hash: str
    adapter: StorageAdapter
    router: ValidatorRouter
    processors: dict[str, Processor]
    app_ecdsa_private_key: bytes
    app_ml_dsa_keypair: DsaKeypair
    key_custody: KeyCustody = "server"
    _users: dict[str, _UserKey] = field(default_factory=dict)
    _user_pubkeys: dict[str, _UserPubkey] = field(default_factory=dict)
    _nonce_seqs: dict[str, int] = field(default_factory=dict)

    # ── Custody guards ─────────────────────────────────────────────

    def _require_server_custody(self, op: str) -> None:
        if self.key_custody != "server":
            raise ClientCustodyError(
                f"arc/{op}: not available in client-custody mode. "
                f"In client-custody the user's KEM secret key never reaches "
                f"the backend. Fetch the envelope via fetch_envelope() and "
                f"decrypt client-side (TS SDK openEnvelope)."
            )

    def _require_client_custody(self, op: str) -> None:
        if self.key_custody != "client":
            raise RuntimeError(
                f"arc/{op}: only available in client-custody mode. "
                f"Pass key_custody='client' to init() to use the "
                f"non-custodial flow."
            )

    # ── User lifecycle ──────────────────────────────────────────────

    async def create_user(
        self,
        class_name: str,
        profile: dict[str, Any],
    ) -> tuple[UserHandle, PrivacyProof]:
        """Provision a fresh ML-KEM-768 keypair for a new user. Returns the
        opaque handle + the privacy proof for the create operation.

        Server-custody only — the runtime generates and holds the keypair.
        For non-custodial flows, derive the keypair on the client and call
        :meth:`register_user` instead.
        """
        self._require_server_custody("create_user")
        kp = kem_keygen()
        handle = UserHandle(id="ar_" + secrets.token_hex(8))
        self._users[handle.id] = _UserKey(handle=handle, kem=kp)
        self._nonce_seqs[handle.id] = 0

        # Seal the profile so the create op has a canonical post-state.
        seq = self._next_nonce(handle)
        env = seal_envelope(
            plaintext=_canonical_bytes(profile),
            user_kem_public_key=kp.public_key,
            app_ecdsa_private_key=self.app_ecdsa_private_key,
            app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            app_id=self.app_id,
            class_name=class_name,
            nonce_seq=seq,
        )
        rid = "u:" + handle.id
        await self.adapter.put(
            AdapterRecord(
                id=rid,
                user_handle_id=handle.id,
                class_name=class_name,
                index_fields={},
                public_fields={"created_at": int(time.time())},
                envelope=env,
            )
        )
        proof = await self._proof_and_attest(
            "CREATE",
            class_name=class_name,
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(env.ciphertext)),
            delta=env.aad,
        )
        return handle, proof

    # ── Client-custody surface (non-custodial mode) ────────────────

    def register_user(
        self,
        handle: UserHandle | str,
        user_kem_public_key: bytes,
    ) -> UserHandle:
        """Register a client-derived user identity with the runtime.

        Client-custody only. The handle is whatever opaque ID the client
        chose (typically derived deterministically from a wallet PRF). The
        public key wraps per-record AES keys that only the client's secret
        can unwrap. The runtime uses the public key on subsequent
        ``persist_envelope`` and ``fetch_envelope`` calls but never sees
        the secret.
        """
        self._require_client_custody("register_user")
        h = handle if isinstance(handle, UserHandle) else UserHandle(id=handle)
        self._user_pubkeys[h.id] = _UserPubkey(handle=h, kem_public_key=user_kem_public_key)
        self._nonce_seqs.setdefault(h.id, 0)
        return h

    async def persist_envelope(
        self,
        user: UserHandle,
        class_name: str,
        record_kind: str,
        envelope: CipherEnvelope,
        index_fields: dict[str, bytes] | None = None,
    ) -> tuple[RecordRef, PrivacyProof]:
        """Store a pre-sealed envelope from the client + commit a privacy proof.

        Client-custody only. The frontend produced the envelope (TS SDK
        ``sealEnvelope`` or equivalent) using the user's KEM public key; the
        backend never sees the plaintext. ``index_fields`` are
        deterministic-encrypted bytes the client computed (already in the
        wire format the adapter expects — no re-encoding here).

        The privacy proof is signed by the *app*, not the user — the user's
        signature lives inside the envelope (sigEcdsa + sigMlDsa) and is
        independently checkable.
        """
        self._require_client_custody("persist_envelope")
        if user.id not in self._user_pubkeys:
            raise KeyError(
                f"arc/persist_envelope: user {user.id} not registered. "
                f"Call register_user() with their KEM public key first."
            )

        seq = self._next_nonce(user)
        # The client's envelope already encodes a nonce_seq inside; we use
        # that for proof continuity. If the client is a stateless function
        # (no nonce monotonicity), fall back to the runtime counter.
        proof_seq = envelope.nonce_seq if envelope.nonce_seq > 0 else seq

        rid = "r:" + secrets.token_hex(8)
        await self.adapter.put(
            AdapterRecord(
                id=rid,
                user_handle_id=user.id,
                class_name=class_name,
                index_fields=index_fields or {},
                public_fields={"created_at": int(time.time()), "kind": record_kind},
                envelope=envelope,
            )
        )
        proof = await self._proof_and_attest(
            "CREATE",
            class_name=f"{class_name}.{record_kind}",
            nonce_seq=proof_seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(envelope.ciphertext)),
            delta=envelope.aad,
        )
        return RecordRef(kind=record_kind, id=rid), proof

    async def fetch_envelope(
        self,
        user: UserHandle,
        ref: RecordRef,
    ) -> CipherEnvelope:
        """Return the raw :class:`CipherEnvelope` for client-side decryption.

        Client-custody only. Pair with the TS SDK's ``openEnvelope`` (or
        the Python ``open_envelope`` if you hold the secret key in a
        trusted-client process). The wire format produced by
        ``encode_envelope`` is byte-identical across language SDKs.
        """
        self._require_client_custody("fetch_envelope")
        record = await self._find(user.id, ref.id)
        if record is None:
            raise KeyError(f"arc/fetch_envelope: no record {ref.id}")
        return record.envelope

    # ── CRUD (server-custody) ──────────────────────────────────────

    async def put_record(
        self,
        user: UserHandle,
        class_name: str,
        record_kind: str,
        value: dict[str, Any],
        index_fields: dict[str, Any] | None = None,
    ) -> tuple[RecordRef, PrivacyProof]:
        """Encrypt + persist a record. Returns the opaque ref + privacy proof.

        Server-custody only — the runtime seals the envelope using its
        in-memory copy of the user's KEM keypair. In non-custodial flows
        use :meth:`persist_envelope` (the client seals locally and sends
        bytes).
        """
        self._require_server_custody("put_record")
        u = self._users[user.id]
        seq = self._next_nonce(user)
        env = seal_envelope(
            plaintext=_canonical_bytes(value),
            user_kem_public_key=u.kem.public_key,
            app_ecdsa_private_key=self.app_ecdsa_private_key,
            app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            app_id=self.app_id,
            class_name=f"{class_name}.{record_kind}",
            nonce_seq=seq,
        )
        rid = "r:" + secrets.token_hex(8)
        idx_enc = {k: _det_enc(str(v).encode("utf-8")) for k, v in (index_fields or {}).items()}

        await self.adapter.put(
            AdapterRecord(
                id=rid,
                user_handle_id=user.id,
                class_name=class_name,
                index_fields=idx_enc,
                public_fields={"created_at": int(time.time()), "kind": record_kind},
                envelope=env,
            )
        )
        proof = await self._proof_and_attest(
            "CREATE",
            class_name=f"{class_name}.{record_kind}",
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(env.ciphertext)),
            delta=env.aad,
        )
        return RecordRef(kind=record_kind, id=rid), proof

    async def update_record(
        self,
        user: UserHandle,
        ref: RecordRef,
        value: dict[str, Any],
        index_fields: dict[str, Any] | None = None,
    ) -> tuple[RecordRef, PrivacyProof]:
        """Mutate an existing record in place.

        Server-custody only. Preserves the original ``RecordRef`` and
        emits an ``OP.UPDATE`` proof binding the prior envelope's
        ciphertext hash (``preStateHash``) to the new one — so the audit
        chain stays continuous across edits, redactions, and revokes.

        Closes SDK-V1-GAPS §3 (Python parity, mirrors TS alpha.7).
        """
        self._require_server_custody("update_record")
        u = self._users[user.id]
        old = await self._find(user.id, ref.id)
        if old is None:
            raise KeyError(f"arc/update_record: record {ref.id} not found")

        seq = self._next_nonce(user)
        env = seal_envelope(
            plaintext=_canonical_bytes(value),
            user_kem_public_key=u.kem.public_key,
            app_ecdsa_private_key=self.app_ecdsa_private_key,
            app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            app_id=self.app_id,
            class_name=old.class_name,
            nonce_seq=seq,
        )
        idx_enc = (
            {k: _det_enc(str(v).encode("utf-8")) for k, v in index_fields.items()}
            if index_fields else dict(old.index_fields)
        )

        await self.adapter.put(
            AdapterRecord(
                id=ref.id,                     # SAME id — adapter.put is upsert
                user_handle_id=user.id,
                class_name=old.class_name,
                index_fields=idx_enc,
                public_fields=old.public_fields,
                envelope=env,
            )
        )
        proof = await self._proof_and_attest(
            "UPDATE",
            class_name=old.class_name,
            nonce_seq=seq,
            pre_state_hash=bytes_to_hex(keccak(old.envelope.ciphertext)),
            post_state_hash=bytes_to_hex(keccak(env.ciphertext)),
            delta=env.aad,
        )
        return ref, proof

    async def read_field(
        self,
        user: UserHandle,
        field_path: str,
        context_name: str,
    ) -> HoldOnce[Any]:
        """Read one leaf of an identity-level encrypted struct.

        ``field_path`` is dotted: ``'profile.email'`` reads the ``email``
        key inside the ``profile`` struct. Returns a :class:`HoldOnce`
        bound to ``context_name`` — the value is plaintext for one frame
        only.

        Server-custody only. Closes SDK-V1-GAPS §4 (Python parity,
        mirrors TS alpha.7).
        """
        self._require_server_custody("read_field")
        u = self._users[user.id]
        parts = field_path.split(".")
        if not parts or not parts[0]:
            raise ValueError("arc/read_field: empty field_path")

        # Identity-level struct envelopes are stored at id = "u:" + user.id
        # by create_user. The class_name is the struct's name; in the
        # current schema shape that's exactly the schema's identity class
        # passed to create_user.
        rid = "u:" + user.id
        record = await self._find(user.id, rid)
        if record is None:
            raise KeyError(f"arc/read_field: '{field_path}' — no identity record at {rid}")

        plaintext = open_envelope(envelope=record.envelope, user_kem_secret_key=u.kem.secret_key)
        try:
            obj: Any = json.loads(plaintext.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            obj = plaintext.decode("utf-8", errors="replace")

        # Walk the keys after the struct name. ``'profile'`` returns the
        # whole struct; ``'profile.email'`` returns the leaf.
        cursor: Any = obj
        for k in parts[1:]:
            cursor = cursor.get(k) if isinstance(cursor, dict) else None
            if cursor is None:
                break

        # Encode the value into a HoldOnce so the closure boundary still
        # holds for the caller. We re-encode + decode through JSON so
        # HoldOnce.use receives the same shape `read` would yield.
        buf = bytearray(json.dumps(cursor).encode("utf-8"))
        return HoldOnce(
            context_id=ReadContext(context_name),
            _plaintext=buf,
            _decoder=lambda b: json.loads(b.decode("utf-8")),
        )

    async def update_field(
        self,
        user: UserHandle,
        field_path: str,
        value: Any,
    ) -> PrivacyProof:
        """Write one leaf of an identity-level encrypted struct.

        Reads the struct, mutates the keyed leaf, re-seals the whole
        struct, and emits an ``OP.UPDATE`` proof. Companion to
        :meth:`read_field`.

        Server-custody only. Closes SDK-V1-GAPS §4 (Python parity,
        mirrors TS alpha.7).
        """
        self._require_server_custody("update_field")
        u = self._users[user.id]
        parts = field_path.split(".")
        if not parts or not parts[0]:
            raise ValueError("arc/update_field: empty field_path")

        rid = "u:" + user.id
        record = await self._find(user.id, rid)
        if record is None:
            raise KeyError(f"arc/update_field: '{field_path}' — no identity record at {rid}")

        plaintext = open_envelope(envelope=record.envelope, user_kem_secret_key=u.kem.secret_key)
        try:
            obj = json.loads(plaintext.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            obj = {}
        if not isinstance(obj, dict):
            obj = {}

        if len(parts) == 1:
            # Replace the entire struct
            obj.clear()
            if isinstance(value, dict):
                obj.update(value)
        else:
            cursor = obj
            for k in parts[1:-1]:
                if not isinstance(cursor.get(k), dict):
                    cursor[k] = {}
                cursor = cursor[k]
            cursor[parts[-1]] = value

        seq = self._next_nonce(user)
        env = seal_envelope(
            plaintext=_canonical_bytes(obj),
            user_kem_public_key=u.kem.public_key,
            app_ecdsa_private_key=self.app_ecdsa_private_key,
            app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            app_id=self.app_id,
            class_name=record.class_name,
            nonce_seq=seq,
        )
        await self.adapter.put(
            AdapterRecord(
                id=rid,
                user_handle_id=user.id,
                class_name=record.class_name,
                index_fields=record.index_fields,
                public_fields=record.public_fields,
                envelope=env,
            )
        )
        return await self._proof_and_attest(
            "UPDATE",
            class_name=record.class_name,
            nonce_seq=seq,
            pre_state_hash=bytes_to_hex(keccak(record.envelope.ciphertext)),
            post_state_hash=bytes_to_hex(keccak(env.ciphertext)),
            delta=json.dumps({"field": field_path}).encode("utf-8"),
        )

    async def rotate_user_key(
        self,
        user: UserHandle,
    ) -> tuple[bytes, int, PrivacyProof]:
        """Rotate a user's KEM keypair (server-custody).

        Generates a fresh keypair, decrypts every record under the old
        secret, re-seals each one under the new public key, and emits a
        single ``OP.UPDATE`` proof on the ``User`` class with delta
        ``{"kind": "key-rotation", "records_rotated": N}``.

        Returns ``(new_public_key, records_rotated, proof)``.

        Closes SDK-V1-GAPS §6 server-custody MVP (Python parity,
        mirrors TS alpha.7).
        """
        self._require_server_custody("rotate_user_key")
        old = self._users[user.id]
        new_kp = kem_keygen()

        records = await self.adapter.export_user(user.id)
        for r in records:
            plain = open_envelope(envelope=r.envelope, user_kem_secret_key=old.kem.secret_key)
            seq = self._next_nonce(user)
            new_env = seal_envelope(
                plaintext=plain,
                user_kem_public_key=new_kp.public_key,
                app_ecdsa_private_key=self.app_ecdsa_private_key,
                app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
                app_id=self.app_id,
                class_name=r.class_name,
                nonce_seq=seq,
            )
            await self.adapter.put(
                AdapterRecord(
                    id=r.id,
                    user_handle_id=r.user_handle_id,
                    class_name=r.class_name,
                    index_fields=r.index_fields,
                    public_fields=r.public_fields,
                    envelope=new_env,
                )
            )

        # Swap the in-memory keypair to the new one — subsequent reads use it.
        self._users[user.id] = _UserKey(handle=old.handle, kem=new_kp)

        seq = self._next_nonce(user)
        proof = await self._proof_and_attest(
            "UPDATE",
            class_name="User",
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(new_kp.public_key)),
            delta=json.dumps({
                "kind": "key-rotation",
                "records_rotated": len(records),
            }).encode("utf-8"),
        )
        return new_kp.public_key, len(records), proof

    async def replace_user_envelopes(
        self,
        *,
        user: UserHandle,
        new_kem_public_key: bytes,
        re_sealed_records: list[AdapterRecord],
    ) -> tuple[int, PrivacyProof]:
        """Client-custody key rotation.

        The runtime never holds the user's KEM secret in this mode, so
        the caller decrypts + re-seals each envelope on the client (using
        ``fetch_envelope`` + ``open_envelope``), then hands the rebuilt
        envelopes back here. The runtime swaps the user's pinned public
        key, upserts every record at its existing id, and emits one
        ``OP.UPDATE`` proof.

        Closes SDK-V1-GAPS §6c (Python parity, mirrors TS alpha.8).
        """
        self._require_client_custody("replace_user_envelopes")
        if user.id not in self._user_pubkeys:
            raise KeyError(
                f"arc/replace_user_envelopes: user {user.id} not registered. "
                f"Call register_user() first."
            )

        for r in re_sealed_records:
            if len(r.envelope.ciphertext) == 0:
                raise ValueError(f"arc/replace_user_envelopes: empty envelope for {r.id}")
            if r.envelope.cipher != "ml-kem-768+aes-256-gcm":
                raise ValueError(
                    f"arc/replace_user_envelopes: unsupported cipher "
                    f"'{r.envelope.cipher}' for record {r.id}"
                )
            await self.adapter.put(r)

        # Pin the new public key; subsequent persist_envelope calls will
        # come from the client sealing under it.
        old = self._user_pubkeys[user.id]
        self._user_pubkeys[user.id] = _UserPubkey(handle=old.handle, kem_public_key=new_kem_public_key)

        seq = self._next_nonce(user)
        proof = await self._proof_and_attest(
            "UPDATE",
            class_name="User",
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(new_kem_public_key)),
            delta=json.dumps({
                "kind": "client-key-rotation",
                "records_rotated": len(re_sealed_records),
            }).encode("utf-8"),
        )
        return len(re_sealed_records), proof

    def verify_pq_attestation(self, proof: PrivacyProof) -> PQVerification:
        """Verify a proof's claim about which cipher suite was used.

        Returns the cipher-suite spec from ``CIPHER_SUITES`` and a ``pq``
        boolean. Public — anyone can call. Mirrors the standalone
        :func:`arc_avs_sdk.proof.verify_pq_attestation` for callers
        holding a runtime instance.
        """
        return _verify_pq(proof)

    async def read(
        self,
        user: UserHandle,
        ref: RecordRef,
        context_name: str,
    ) -> HoldOnce[dict[str, Any]]:
        """Decrypt one record into a :class:`HoldOnce` closure scoped to ``context_name``.

        Server-custody only — the runtime needs the user's KEM secret key to
        decrypt. In client-custody mode the secret never reaches the backend;
        call :meth:`fetch_envelope` and decrypt with the TS SDK
        ``openEnvelope`` instead.

        The plaintext lives only inside the closure passed to ``HoldOnce.use``.
        After the closure exits, the underlying buffer is overwritten.
        """
        self._require_server_custody("read")
        u = self._users[user.id]
        record = await self._find(user.id, ref.id)
        if record is None:
            raise KeyError(f"arc/read: no record {ref.id} for user {user.id}")
        plaintext = open_envelope(envelope=record.envelope, user_kem_secret_key=u.kem.secret_key)
        buf = bytearray(plaintext)
        return HoldOnce(
            context_id=ReadContext(context_name),
            _plaintext=buf,
            _decoder=lambda b: json.loads(b.decode("utf-8")),
        )

    async def list(
        self,
        user: UserHandle,
        class_name: str,
        where: dict[str, Any] | None = None,
        limit: int | None = None,
    ) -> list[RecordRef]:
        """List records matching ``where``. Returns refs (not plaintext)."""
        idx_enc = {k: _det_enc(str(v).encode("utf-8")) for k, v in (where or {}).items()}
        records = await self.adapter.list(
            class_name,
            user.id,
            IndexedQuery(where=idx_enc, limit=limit) if where else IndexedQuery(limit=limit),
        )
        return [
            RecordRef(kind=str(r.public_fields.get("kind", "")), id=r.id) for r in records
        ]

    async def process(
        self,
        user: UserHandle,
        ref: RecordRef,
        processor_name: str,
    ) -> tuple[Any, PrivacyProof]:
        """Pass a record through a registered processor. Out-of-scope fields
        are stripped before the processor's ``invoke`` is called.

        Server-custody only — the runtime needs to decrypt the record
        before sending the in-scope fields to the processor. In
        non-custodial flows the client decrypts locally and either calls
        the processor itself or sends scoped plaintext to a separate
        relay endpoint.
        """
        self._require_server_custody("process")
        proc = self.processors.get(processor_name)
        if proc is None:
            raise KeyError(f"arc/process: processor '{processor_name}' not registered")

        u = self._users[user.id]
        record = await self._find(user.id, ref.id)
        if record is None:
            raise KeyError(f"arc/process: no record {ref.id}")
        plaintext = open_envelope(envelope=record.envelope, user_kem_secret_key=u.kem.secret_key)
        all_fields = json.loads(plaintext.decode("utf-8"))
        # Filter to declared scope only — defence in depth on top of the
        # compile-time scope guard.
        allowed = set(proc.scope) if proc.scope else set(all_fields.keys())
        scoped = {k: v for k, v in all_fields.items() if k in allowed}

        out = await proc.invoke(ProcessorInput(user_handle_id=user.id, fields=scoped))

        seq = self._next_nonce(user)
        proof = await self._proof_and_attest(
            "PROCESS",
            class_name=ref.kind,
            nonce_seq=seq,
            pre_state_hash=bytes_to_hex(keccak(record.envelope.ciphertext)),
            post_state_hash=bytes_to_hex(keccak(json.dumps(out.result, sort_keys=True).encode("utf-8"))),
            delta=str(out.id).encode("utf-8"),
            processor_id=_processor_id(processor_name),
        )
        return out.result, proof

    # ── Compliance ─────────────────────────────────────────────────

    async def purge_user(self, user: UserHandle) -> tuple[dict[str, int], PrivacyProof]:
        """GDPR Art. 17 — crypto-shred the user's records and revoke their keys.

        Available in both custody modes — purge only needs to overwrite
        the wrapped key on each record (the adapter's ``purge_user`` does
        that; no plaintext access required).
        """
        result = await self.adapter.purge_user(user.id)
        # Drop any in-memory key material we might have for this user.
        self._users.pop(user.id, None)
        self._user_pubkeys.pop(user.id, None)

        seq = self._nonce_seqs.get(user.id, 0) + 1
        self._nonce_seqs[user.id] = seq
        proof = await self._proof_and_attest(
            "PURGE",
            class_name="User",
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=_zero_hash(),
            delta=str(result["records_affected"]).encode("utf-8"),
        )
        return result, proof

    async def export_user(
        self, user: UserHandle, context_name: str
    ) -> tuple[list[dict[str, Any]], PrivacyProof]:
        """GDPR Art. 20 — return all records for the user, decrypted.

        Server-custody only — needs the secret key. In non-custodial flows
        export the *envelopes* (call ``adapter.export_user`` and stream
        their bytes to the client) and let the client decrypt with its
        own secret key.
        """
        self._require_server_custody("export_user")
        u = self._users[user.id]
        records = await self.adapter.export_user(user.id)
        decrypted: list[dict[str, Any]] = []
        for r in records:
            plain = open_envelope(envelope=r.envelope, user_kem_secret_key=u.kem.secret_key)
            decrypted.append(json.loads(plain.decode("utf-8")))

        seq = self._next_nonce(user)
        proof = await self._proof_and_attest(
            "EXPORT",
            class_name=context_name,
            nonce_seq=seq,
            pre_state_hash=_zero_hash(),
            post_state_hash=bytes_to_hex(keccak(json.dumps(decrypted, sort_keys=True).encode("utf-8"))),
            delta=str(len(decrypted)).encode("utf-8"),
        )
        return decrypted, proof

    # ── ArcAppRegistry — register_app / commit_manifest ────────────

    async def register_app(self) -> dict[str, object]:
        """Register this runtime's app on ArcAppRegistry on-chain.

        Equivalent to ``arc deploy`` in the JS CLI. All inputs are derived
        from the schema and the runtime's app keypair:

          * ``domain``             ← ``schema.app_id``
          * ``schemaHash``         ← ``keccak256(canonicalize_schema(schema))``
          * ``ownerPqHash``        ← ``keccak256(app_ml_dsa_keypair.public_key)``
          * ``complianceFlags``    ← ``compliance_bitfield(schema.compliance)``
          * ``declaredAdapters``   ← ``adapter_bitfield(schema.adapters or [])``
          * ``declaredProcessors`` ← ``processor_bitfield(schema.processors or [])``

        Returns ``{"app_id", "tx_hash", "block_number"}``. Reverts on chain
        if the domain is already registered (one-shot per domain).

        Requires the router to know the AppRegistry address. With
        :class:`Web3ValidatorRouter`, pass ``app_registry`` at construction.
        """
        from .schema import (
            adapter_bitfield as _adapter_bf,
            compliance_bitfield as _compliance_bf,
            processor_bitfield as _processor_bf,
        )

        domain = self.schema.app_id
        if domain.startswith("0x") and len(domain) == 66:
            raise ValueError(
                "arc/register_app: schema.app_id is already a hex appId. "
                "Use a domain string (e.g. 'arc-terminal.app') for "
                "on-chain registration."
            )

        schema_hash  = keccak(canonicalize_schema(self.schema).encode("utf-8"))
        owner_pq_hash = keccak(self.app_ml_dsa_keypair.public_key)
        compliance_flags    = _compliance_bf(list(self.schema.compliance))
        declared_adapters   = _adapter_bf(list(self.schema.adapters or []))
        declared_processors = _processor_bf(list(self.schema.processors or []))

        return await self.router.register_app(
            domain=domain,
            schema_hash=schema_hash,
            owner_pq_hash=owner_pq_hash,
            # §12-contract: emit the full ML-DSA-65 pubkey on chain so
            # event-tailing validators (e.g. the relay's RegistryKeyStore)
            # can build their keystore from log history. Storage stays
            # cheap — only the hash lands in the App slot.
            owner_pq_public_key=self.app_ml_dsa_keypair.public_key,
            compliance_flags=compliance_flags,
            declared_adapters=declared_adapters,
            declared_processors=declared_processors,
        )

    async def commit_manifest(
        self,
        *,
        manifest_hash: bytes,
        bundle_hash: bytes,
    ) -> dict[str, object]:
        """Commit a new manifest version against this runtime's app_id.

        ``manifest_hash`` and ``bundle_hash`` are caller-computed
        (typically: ``keccak256`` of the deployed compliance manifest +
        ``keccak256`` of the deployed JS/native bundle, respectively).

        Requires that ``register_app()`` was called previously from the
        same EOA — the contract enforces ``onlyAppOwner``.
        """
        return await self.router.commit_manifest(
            app_id=hex_to_bytes(self.app_id),
            manifest_hash=manifest_hash,
            bundle_hash=bundle_hash,
        )

    # ── Internal helpers ───────────────────────────────────────────

    def _next_nonce(self, user: UserHandle) -> int:
        n = self._nonce_seqs.get(user.id, 0) + 1
        self._nonce_seqs[user.id] = n
        return n

    async def _find(self, user_id: str, record_id: str) -> AdapterRecord | None:
        # Without the class name we have to scan exports — only used on the
        # rare branch where the caller didn't include it. In v2 we'll require
        # it explicitly for a fast adapter.get path.
        records = await self.adapter.export_user(user_id)
        for r in records:
            if r.id == record_id:
                return r
        return None

    async def _proof_and_attest(
        self,
        op: str,
        *,
        class_name: str,
        nonce_seq: int,
        pre_state_hash: str,
        post_state_hash: str,
        delta: bytes,
        processor_id: int = 0,
    ) -> PrivacyProof:
        proof = build_proof(
            BuildProofInput(
                app_id=self.app_id,
                op=op,                      # type: ignore[arg-type]
                class_name=class_name,
                processor_id=processor_id,
                cipher_suite=_DEFAULT_CIPHER_SUITE_ID,
                nonce_seq=nonce_seq,
                pre_state_hash=pre_state_hash,
                post_state_hash=post_state_hash,
                delta=delta,
                app_ecdsa_private_key=self.app_ecdsa_private_key,
                app_ml_dsa_private_key=self.app_ml_dsa_keypair.secret_key,
            )
        )
        return await self.router.submit(proof)


# ── init() — the canonical entry point ────────────────────────────


async def init(
    schema: SchemaDescriptor,
    *,
    adapter: StorageAdapter,
    router: ValidatorRouter | None = None,
    processors: list[Processor] | None = None,
    app_ecdsa_private_key: bytes | None = None,
    app_ml_dsa_keypair: DsaKeypair | None = None,
    app_id_override: AppId | None = None,
    key_custody: KeyCustody = "server",
) -> ArcRuntime:
    """Construct an :class:`ArcRuntime`. Mirrors the TS ``init(schema, opts)``.

    ``key_custody="server"`` (default) — runtime generates and holds each
    user's KEM keypair; backend can decrypt records on demand. Convenient
    for prototyping.

    ``key_custody="client"`` — non-custodial: the user's KEM secret stays
    on the client (typically derived from a wallet PRF). The backend
    accepts pre-sealed envelopes via ``persist_envelope`` and serves them
    back as ciphertext via ``fetch_envelope``. ``read`` / ``process`` /
    ``export_user`` raise ``ClientCustodyError`` because they need the
    secret the server doesn't have.
    """
    # Hash the schema for on-chain commitment.
    canonical = canonicalize_schema(schema)
    schema_hash = bytes_to_hex(keccak(canonical.encode("utf-8")))

    # Derive appId from the schema's domain field unless overridden.
    if app_id_override is not None:
        app_id: AppId = app_id_override
    elif schema.app_id.startswith("0x") and len(schema.app_id) == 66:
        app_id = AppId(schema.app_id)
    else:
        app_id = AppId(bytes_to_hex(keccak(schema.app_id.lower().encode("utf-8"))))

    # Initialise the adapter for the declared classes.
    await adapter.init(app_id=app_id, classes=list(schema.classes.keys()))

    # Generate app keypairs if none were supplied.
    ecdsa_sk = app_ecdsa_private_key or random_bytes(32)
    _ = ecdsa_public_key(ecdsa_sk)  # validate
    dsa_kp = app_ml_dsa_keypair or dsa_keygen()

    proc_map = {p.name: p for p in (processors or [])}

    return ArcRuntime(
        app_id=app_id,
        schema=schema,
        schema_hash=schema_hash,
        adapter=adapter,
        router=router or NoopValidatorRouter(),
        processors=proc_map,
        app_ecdsa_private_key=ecdsa_sk,
        app_ml_dsa_keypair=dsa_kp,
        key_custody=key_custody,
    )


# ── private helpers ───────────────────────────────────────────────


def _zero_hash() -> str:
    return "0x" + ("00" * 32)


def _canonical_bytes(value: dict[str, Any]) -> bytes:
    """Compact JSON bytes with sorted keys — same canonicalization as the TS SDK
    uses inside ``seal_envelope``."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _det_enc(plaintext: bytes) -> bytes:
    """Deterministic encryption stub for index columns. v1 returns
    ``keccak256(plaintext)`` truncated to 16 bytes — sufficient for equality
    lookups, not collision-free in adversarial inputs. v2 will use AES-SIV with
    a per-app key."""
    return keccak(plaintext)[:16]


def _processor_id(name: str) -> int:
    from .types import PROCESSOR_FLAGS
    return PROCESSOR_FLAGS.get(name, 0)
