"""arc_avs_sdk.he — Client-side helpers for HE-mode tasks.

Mirrors ``@arc-avs/sdk/he`` (TypeScript). For HE-mode tasks the postStateHash
is derived from the validator-side ciphertext output. The client predicts it
by running the same homomorphic-EMA locally (single-party CKKS — see e.g.
TenSEAL or OpenFHE) and signs over that prediction. Validators arriving at a
different ``post_state_hash`` will not sign matching attestations.

Cipher suite IDs:
  * 11 = ``ckks-fhe+ml-kem-768`` — client-keyed CKKS
  * 12 = ``threshold-ckks-fhe+ml-kem-768`` — network-keyed (K-of-N) threshold CKKS

For threshold mode the client encrypts to the collective public key fetched
from ``ArcDkgRegistry.dkgRoot(epoch)``; decryption requires K validators to
contribute partial decrypts through Lattigo's ``Combiner``. The full
multiparty protocol lives in the Go ``arc-fhe`` sidecar.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from eth_hash.auto import keccak

from .encryption import bytes_to_hex, dsa_sign, ecdsa_sign, hex_to_bytes
from .proof import PrivacyProof, class_id_of, proof_bind_digest
from .types import AppId, OpKind


CKKS_FHE_CIPHER_SUITE_ID: int = 11
THRESHOLD_CKKS_FHE_CIPHER_SUITE_ID: int = 12


def keccak256_hex(data: bytes) -> str:
    """``"0x"`` + keccak256(data) — matches operator/src/he-validator.ts."""
    return bytes_to_hex(keccak(data))


def compute_post_state_hash_he(
    ciphertext_output_hash: str,
    epsilon_spent: float,
    update_count: int,
) -> str:
    """Interim HE-mode post-state hash:

    keccak256(ciphertextOutputHash ‖ epsilonSpent_q24 ‖ updateCount_u32)

    Bytes are big-endian; ``epsilonSpent_q24`` is the Q.24 fixed-point integer
    representation of ``epsilon_spent``. Matches the operator's Solidity
    layout byte-for-byte.
    """
    eps_q24 = round(epsilon_spent * (1 << 24))
    buf = bytearray()
    buf.extend(hex_to_bytes(ciphertext_output_hash))
    buf.extend(eps_q24.to_bytes(8, "big"))
    buf.extend(update_count.to_bytes(4, "big"))
    return bytes_to_hex(keccak(bytes(buf)))


@dataclass(frozen=True, slots=True)
class BuildHEProofInput:
    """Inputs to :func:`build_he_proof`. Mirrors TS ``BuildHEProofInput``."""

    app_id: AppId
    op: OpKind
    class_name: str
    nonce_seq: int
    # sha256/keccak256 of the encrypted preState ciphertext bytes
    pre_state_cipher_hash: str
    # sha256/keccak256 of the encrypted (1−α)·update ciphertext bytes
    update_cipher_hash: str
    # Predicted postStateHash from running the validator-equivalent eval locally
    predicted_post_state_hash: str
    app_ecdsa_private_key: bytes
    app_ml_dsa_private_key: bytes
    processor_id: int = 0


def build_he_proof(input_: BuildHEProofInput) -> PrivacyProof:
    """Build a PrivacyProof for an HE-mode task (cipher suite ID 11).

    The validator's attestation will commit to the same ``post_state_hash``
    if and only if it ran the same homomorphic op on the same input
    ciphertexts — providing tamper-evidence end-to-end without ever exposing
    plaintext to the validator.

    Bypasses the standard delta-hashing path because all three hashes are
    precomputed by the client over cipher bytes (not plaintext bytes).
    """
    timestamp = int(time.time())
    cls_id = class_id_of(input_.class_name)
    cipher_suite = CKKS_FHE_CIPHER_SUITE_ID

    input_hash = proof_bind_digest(
        app_id=input_.app_id,
        op=input_.op,
        class_name=input_.class_name,
        processor_id=input_.processor_id,
        nonce_seq=input_.nonce_seq,
        pre_state_hash=input_.pre_state_cipher_hash,
        post_state_hash=input_.predicted_post_state_hash,
        delta_hash=input_.update_cipher_hash,
        timestamp=timestamp,
        cipher_suite=cipher_suite,
    )
    digest = hex_to_bytes(input_hash)
    sig_ecdsa = ecdsa_sign(input_.app_ecdsa_private_key, digest)
    sig_ml_dsa = dsa_sign(input_.app_ml_dsa_private_key, digest)

    return PrivacyProof(
        app_id=input_.app_id,
        op=input_.op,
        class_name=input_.class_name,
        class_id=cls_id,
        processor_id=input_.processor_id,
        cipher_suite=cipher_suite,
        nonce_seq=input_.nonce_seq,
        timestamp=timestamp,
        input_hash=input_hash,
        pre_state_hash=input_.pre_state_cipher_hash,
        post_state_hash=input_.predicted_post_state_hash,
        delta_hash=input_.update_cipher_hash,
        sig_ecdsa=bytes_to_hex(sig_ecdsa),
        sig_ml_dsa=bytes_to_hex(sig_ml_dsa),
    )
