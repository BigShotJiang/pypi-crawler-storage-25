"""arc-avs-sdk — ARC privacy framework for Python.

PQ-encrypted, attested, validator-anchored data layer for any application.
Mirrors the ``@arc-avs/sdk`` TypeScript package; envelopes and proof digests
are byte-compatible across language stacks.

Quick start::

    import asyncio
    from arc_avs_sdk import arc, init
    from arc_avs_sdk.adapter.memory import MemoryAdapter

    schema = arc.schema(
        app_id     = "your-app.com",
        compliance = ["GDPR"],
        classes    = {
            "User": arc.identity({
                "profile": arc.encrypted.struct({
                    "email": arc.encrypted.email(),
                }),
            }),
        },
    )

    async def main() -> None:
        runtime = await init(schema, adapter=MemoryAdapter())
        user, _ = await runtime.create_user("User", {"email": "a@b.c"})

    asyncio.run(main())
"""

from .encryption import (
    CipherEnvelope,
    DsaKeypair,
    KemKeypair,
    aes_decrypt,
    aes_encrypt,
    bind_aad,
    bind_digest,
    bytes_to_hex,
    dsa_keygen,
    dsa_sign,
    dsa_verify,
    ecdsa_public_key,
    ecdsa_sign,
    ecdsa_verify,
    hex_to_bytes,
    kem_decapsulate,
    kem_encapsulate,
    kem_keygen,
    open_envelope,
    random_bytes,
    seal_envelope,
    seal_envelope_as_user,
    wipe,
)
from .adapter._shared import (
    decode_envelope,
    encode_envelope,
    index_fields_from_json,
    index_fields_to_json,
)
from .he import (
    BuildHEProofInput,
    CKKS_FHE_CIPHER_SUITE_ID,
    THRESHOLD_CKKS_FHE_CIPHER_SUITE_ID,
    build_he_proof,
    compute_post_state_hash_he,
    keccak256_hex,
)
from .proof import (
    BuildProofInput,
    PQVerification,
    PrivacyProof,
    build_proof,
    class_id_of,
    proof_bind_digest,
    verify_pq_attestation,
)
from .runtime import ArcRuntime, ClientCustodyError, HoldOnce, KeyCustody, init
from .schema import (
    CollectionDescriptor,
    FieldDescriptor,
    IdentityDescriptor,
    SchemaDescriptor,
    StructDescriptor,
    adapter_bitfield,
    arc,
    canonicalize_schema,
    compliance_bitfield,
    processor_bitfield,
)
from .types import (
    ADAPTER_FLAGS,
    CIPHER_SUITES,
    COMPLIANCE,
    OP,
    PROCESSOR_FLAGS,
    AdapterName,
    AppId,
    CipherSuiteName,
    CipherSuiteSpec,
    ComplianceName,
    OpKind,
    ProcessorName,
    ReadContext,
    RecordRef,
    UserHandle,
    cipher_suite_by_id,
    cipher_suite_id_of,
    read_context,
)

__version__ = "1.0.0a8"

__all__ = [
    # DSL + runtime
    "arc", "init", "ArcRuntime", "HoldOnce", "KeyCustody", "ClientCustodyError",
    # Schema
    "SchemaDescriptor", "FieldDescriptor", "StructDescriptor",
    "CollectionDescriptor", "IdentityDescriptor",
    "canonicalize_schema",
    "compliance_bitfield", "adapter_bitfield", "processor_bitfield",
    # Crypto
    "CipherEnvelope", "KemKeypair", "DsaKeypair",
    "kem_keygen", "kem_encapsulate", "kem_decapsulate",
    "dsa_keygen", "dsa_sign", "dsa_verify",
    "ecdsa_sign", "ecdsa_verify", "ecdsa_public_key",
    "aes_encrypt", "aes_decrypt",
    "seal_envelope", "seal_envelope_as_user", "open_envelope",
    "bind_aad", "bind_digest",
    "random_bytes", "wipe",
    "hex_to_bytes", "bytes_to_hex",
    # Wire format (cross-language envelope handoff)
    "encode_envelope", "decode_envelope",
    "index_fields_to_json", "index_fields_from_json",
    # Proof
    "PrivacyProof", "BuildProofInput", "build_proof",
    "class_id_of", "proof_bind_digest",
    "verify_pq_attestation", "PQVerification",
    # Types
    "AppId", "UserHandle", "RecordRef", "ReadContext", "read_context",
    "OP", "OpKind",
    "COMPLIANCE", "ComplianceName",
    "ADAPTER_FLAGS", "AdapterName",
    "PROCESSOR_FLAGS", "ProcessorName",
    # Cipher-suite registry (1.0.0a8)
    "CIPHER_SUITES", "CipherSuiteName", "CipherSuiteSpec",
    "cipher_suite_id_of", "cipher_suite_by_id",
]
