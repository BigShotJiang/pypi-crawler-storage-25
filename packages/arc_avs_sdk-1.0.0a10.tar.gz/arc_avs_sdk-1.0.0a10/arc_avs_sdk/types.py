"""arc_avs_sdk.types — Branded types, opaque handles, and registry constants.

The TS SDK uses phantom branded types to make plaintext extraction structurally
impossible. Python's type system is nominally weaker, but ``NewType`` + dataclass
``frozen=True`` get us most of the same compile-time safety.

Numeric flags (``COMPLIANCE``, ``ADAPTER_FLAGS``, ``PROCESSOR_FLAGS``, ``OP``)
mirror the TS source byte-for-byte so the on-chain bitfield representation is
identical between language stacks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Literal, NewType, TypeAlias


# ── Opaque user / record handles ─────────────────────────────────────


@dataclass(frozen=True, slots=True)
class UserHandle:
    """Opaque handle for a user. Contains no PII — safe to log, store, pass."""

    id: str


@dataclass(frozen=True, slots=True)
class RecordRef:
    """Reference to a record in a collection. Opaque; no PII."""

    kind: str
    id: str


@dataclass(frozen=True, slots=True)
class ProcessRef:
    """Reference to a processed result (e.g. an LLM reply, Stripe charge)."""

    kind: str
    id: str
    attestation_tx: str | None = None


# AppId is the keccak256 of the canonicalized lowercased domain — represented
# as a 0x-prefixed 32-byte hex string.
AppId = NewType("AppId", str)

# A scoped name a HoldOnce closure is bound to (e.g. 'render-only', 'audit').
ReadContext = NewType("ReadContext", str)


def read_context(name: str) -> ReadContext:
    """Build a :class:`ReadContext` brand from a string."""
    return ReadContext(name)


# ── Compliance flags (mirrors TS COMPLIANCE) ─────────────────────────


COMPLIANCE: Final[dict[str, int]] = {
    "GDPR":      1 << 0,
    "CCPA":      1 << 1,
    "HIPAA":     1 << 2,
    "PCI_DSS":   1 << 3,
    "KYC":       1 << 4,
    "SOC2":      1 << 5,
    "COPPA":     1 << 6,
    "GLBA":      1 << 7,
    "ISO_27001": 1 << 8,
}
ComplianceName: TypeAlias = Literal[
    "GDPR", "CCPA", "HIPAA", "PCI_DSS", "KYC", "SOC2", "COPPA", "GLBA", "ISO_27001"
]


# ── Adapter / processor flags (mirrors TS ADAPTER_FLAGS / PROCESSOR_FLAGS) ─


ADAPTER_FLAGS: Final[dict[str, int]] = {
    "indexeddb":    1 << 0,
    "opfs":         1 << 1,
    "sqlite":       1 << 2,
    "sqlcipher":    1 << 3,
    "postgres":     1 << 4,
    "mysql":        1 << 5,
    "cloudflareD1": 1 << 6,
    "redis":        1 << 7,
    "timescale":    1 << 8,
    "clickhouse":   1 << 9,
    "mongo":        1 << 10,
    "dynamodb":     1 << 11,
    "firestore":    1 << 12,
    "pgvector":     1 << 13,
    "pinecone":     1 << 14,
    "weaviate":     1 << 15,
    "s3":           1 << 16,
    "r2":           1 << 17,
    "gcs":          1 << 18,
    "azureblob":    1 << 19,
    "bigquery":     1 << 20,
    "snowflake":    1 << 21,
    "neo4j":        1 << 22,
    "custom":       1 << 23,
}
AdapterName: TypeAlias = Literal[
    "indexeddb", "opfs", "sqlite", "sqlcipher", "postgres", "mysql", "cloudflareD1",
    "redis", "timescale", "clickhouse", "mongo", "dynamodb", "firestore",
    "pgvector", "pinecone", "weaviate", "s3", "r2", "gcs", "azureblob",
    "bigquery", "snowflake", "neo4j", "custom",
]


PROCESSOR_FLAGS: Final[dict[str, int]] = {
    "openai":    1 << 0,
    "anthropic": 1 << 1,
    "ollama":    1 << 2,
    "stripe":    1 << 3,
    "paypal":    1 << 4,
    "plaid":     1 << 5,
    "sendgrid":  1 << 6,
    "postmark":  1 << 7,
    "twilio":    1 << 8,
    "s3":        1 << 9,
    "gcs":       1 << 10,
    "algolia":   1 << 11,
    "posthog":   1 << 12,
    "segment":   1 << 13,
    "persona":   1 << 14,
    "onfido":    1 << 15,
    "gemini":    1 << 16,
    "kimi":      1 << 17,
    "nous":      1 << 18,
    "mistral":   1 << 19,
    "custom":    1 << 20,
}
ProcessorName: TypeAlias = Literal[
    "openai", "anthropic", "ollama", "stripe", "paypal", "plaid",
    "sendgrid", "postmark", "twilio", "s3", "gcs", "algolia", "posthog",
    "segment", "persona", "onfido", "gemini", "kimi", "nous", "mistral", "custom",
]


# ── Operation kinds (mirrors PrivacyTaskManager.AppTaskContext.op) ──


OP: Final[dict[str, int]] = {
    "CREATE":  1,
    "READ":    2,
    "UPDATE":  3,
    "LIST":    4,
    "PROCESS": 5,
    "SHARE":   6,
    "EXPORT":  7,
    "PURGE":   8,
    "AUDIT":   9,
}
OpKind: TypeAlias = Literal[
    "CREATE", "READ", "UPDATE", "LIST", "PROCESS", "SHARE", "EXPORT", "PURGE", "AUDIT"
]


# ── Cipher-suite registry — Proof of PQ Encryption (1.0.0a8) ────────
#
# Every PrivacyProof carries a numeric ``cipher_suite`` ID committed via
# the bind digest. That binds the writer's signatures to "this op was
# sealed under cipher X" — anyone with the proof can verify the cipher
# claim cryptographically, not just trust the envelope's tag.
#
# IDs are stable on-chain; new entries append. Suites with ``pq=True``
# are post-quantum-secure on the KEM side. Mirrors the TS
# ``CIPHER_SUITES`` registry byte-for-byte.


@dataclass(frozen=True, slots=True)
class CipherSuiteSpec:
    """One row of the cipher-suite registry."""

    id: int
    name: str
    pq: bool
    label: str


CIPHER_SUITES: Final[dict[str, CipherSuiteSpec]] = {
    "ml-kem-768+aes-256-gcm":  CipherSuiteSpec(id=1,   name="ml-kem-768+aes-256-gcm",  pq=True,  label="ML-KEM-768 · AES-256-GCM"),
    "ml-kem-1024+aes-256-gcm": CipherSuiteSpec(id=2,   name="ml-kem-1024+aes-256-gcm", pq=True,  label="ML-KEM-1024 · AES-256-GCM"),
    # CKKS Fully-Homomorphic Encryption — task input is computed-on while encrypted.
    # Validators run cipher-cipher EMA without ever holding the secret key.
    # CKKS hardness rests on Ring-LWE — same lattice family as ML-KEM, so PQ.
    "ckks-fhe+ml-kem-768":     CipherSuiteSpec(id=11,  name="ckks-fhe+ml-kem-768",     pq=True,  label="CKKS-FHE · ML-KEM-768 transport"),
    # Threshold CKKS — client encrypts to a group public key derived from a
    # Pedersen-DKG across the validator set. Decryption requires K-of-N
    # partial decrypts (Lattigo Thresholdizer + Combiner). No single party
    # — including the client — can decrypt unilaterally.
    "threshold-ckks-fhe+ml-kem-768": CipherSuiteSpec(id=12, name="threshold-ckks-fhe+ml-kem-768", pq=True, label="Threshold CKKS-FHE · ML-KEM-768 transport · K-of-N keyholder"),
    "classical-aes-256-gcm":   CipherSuiteSpec(id=254, name="classical-aes-256-gcm",   pq=False, label="AES-256-GCM (classical)"),
}

CipherSuiteName: TypeAlias = Literal[
    "ml-kem-768+aes-256-gcm",
    "ml-kem-1024+aes-256-gcm",
    "ckks-fhe+ml-kem-768",
    "threshold-ckks-fhe+ml-kem-768",
    "classical-aes-256-gcm",
]


def cipher_suite_id_of(name: str) -> int:
    """Resolve a cipher suite name to its registered numeric ID."""
    spec = CIPHER_SUITES.get(name)
    if spec is None:
        raise ValueError(f"arc/types: unknown cipher suite '{name}'")
    return spec.id


def cipher_suite_by_id(suite_id: int) -> CipherSuiteSpec | None:
    """Look up a cipher suite by its numeric ID, or ``None`` if not registered."""
    for spec in CIPHER_SUITES.values():
        if spec.id == suite_id:
            return spec
    return None
