"""runtime.register_app() / runtime.commit_manifest() — covered against
the NoopValidatorRouter (which stubs the on-chain side deterministically)."""

from __future__ import annotations

import pytest
from eth_hash.auto import keccak

from arc_avs_sdk import (
    arc,
    canonicalize_schema,
    compliance_bitfield,
    init,
)
from arc_avs_sdk.adapter.memory import MemoryAdapter
from arc_avs_sdk.router.base import NoopValidatorRouter


@pytest.fixture
def schema():  # noqa: ANN201
    return arc.schema(
        app_id="arc-terminal.app",
        compliance=["GDPR", "CCPA"],
        classes={
            "User": arc.identity({
                "events": arc.collection(
                    item_kind="event",
                    query="indexed",
                    index_fields=["kind"],
                    retention="permanent",
                ),
            }),
        },
        adapters=["neo4j", "postgres"],
        processors=["openai", "kimi", "nous", "mistral"],
    )


async def test_register_app_derives_inputs_from_schema(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter(), router=NoopValidatorRouter())
    out = await runtime.register_app()
    # NoopValidatorRouter stubs appId = keccak256(domain.lower())
    expected = "0x" + keccak(b"arc-terminal.app").hex()
    assert out["app_id"] == expected
    assert "tx_hash" in out
    assert "block_number" in out


async def test_register_app_uses_canonical_schema_hash(schema) -> None:  # noqa: ANN001
    """Sanity: schema_hash sent to the router matches keccak(canonical_json)."""
    captured: dict[str, object] = {}

    class CapturingRouter(NoopValidatorRouter):
        async def register_app(self, **kwargs: object) -> dict[str, object]:  # type: ignore[override]
            captured.update(kwargs)
            return await super().register_app(**kwargs)  # type: ignore[arg-type]

    runtime = await init(schema, adapter=MemoryAdapter(), router=CapturingRouter())
    await runtime.register_app()

    assert captured["schema_hash"] == keccak(canonicalize_schema(schema).encode("utf-8"))
    assert captured["compliance_flags"] == compliance_bitfield(["GDPR", "CCPA"])
    # Adapters/processors flags are positional in the schema declaration.
    assert isinstance(captured["declared_adapters"], int)
    assert isinstance(captured["declared_processors"], int)


async def test_register_app_rejects_hex_appid(schema) -> None:  # noqa: ANN001
    """Schemas pre-resolved to a hex appId can't be registered (no domain)."""
    s = arc.schema(
        app_id="0x" + ("aa" * 32),    # already-hex
        compliance=["GDPR"],
        classes={"User": arc.identity({})},
    )
    runtime = await init(s, adapter=MemoryAdapter(), router=NoopValidatorRouter())
    with pytest.raises(ValueError, match="schema.app_id is already a hex appId"):
        await runtime.register_app()


async def test_commit_manifest_round_trip(schema) -> None:  # noqa: ANN001
    runtime = await init(schema, adapter=MemoryAdapter(), router=NoopValidatorRouter())
    out = await runtime.commit_manifest(
        manifest_hash=keccak(b"manifest-v1"),
        bundle_hash=keccak(b"bundle-v1"),
    )
    assert "tx_hash" in out
    assert "block_number" in out
