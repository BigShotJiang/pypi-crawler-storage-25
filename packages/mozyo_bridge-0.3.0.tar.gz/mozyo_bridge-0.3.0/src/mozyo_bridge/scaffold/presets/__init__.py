"""Packaged scaffold rule presets."""

