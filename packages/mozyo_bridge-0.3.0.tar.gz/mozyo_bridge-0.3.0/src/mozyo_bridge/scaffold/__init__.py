"""Scaffold rules support."""

