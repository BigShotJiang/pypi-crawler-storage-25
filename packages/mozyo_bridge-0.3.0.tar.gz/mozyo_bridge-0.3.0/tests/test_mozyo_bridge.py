from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from mozyo_bridge import __version__
from mozyo_bridge.application.commands import (
    cmd_doctor,
    cmd_init,
    cmd_list,
    cmd_mozyo,
    cmd_status,
    ensure_repo_session_windows,
    load_tmux_conf_for,
    notify_agent,
    resolve_status_session,
    session_cwd_mismatch,
)
from mozyo_bridge.infrastructure import tmux_client
from mozyo_bridge.application.cli import build_parser
from mozyo_bridge.domain.notification import build_prompt, landing_marker, validate_notify_gate
from mozyo_bridge.domain.pane_resolver import (
    clear_read,
    ensure_agent_target,
    find_agent_window,
    is_agent_process,
    is_receiver_agent_process,
    is_tmux_target,
    mark_read,
    require_read,
    resolve_agent_label,
    resolve_target,
)
import mozyo_bridge.domain.pane_resolver as pane_resolver
from mozyo_bridge.domain.handoff import (
    AnchorError,
    AsanaAnchor,
    KIND_LABELS,
    LastInputProjection,
    MODE_PENDING,
    MODE_QUEUE_ENTER,
    MODE_STANDARD,
    RECORD_FORMAT_BOTH,
    RECORD_FORMAT_JSON,
    RECORD_FORMAT_TEXT,
    RedmineAnchor,
    build_delivery_record,
    build_marker,
    build_notification_body,
    make_outcome,
    next_action_for,
    normalize_anchor,
    project_last_input,
)
from mozyo_bridge.infrastructure.queue_reader import find_handoff_task, load_queue
from mozyo_bridge.scaffold.rules import package_version, rules_status, scaffold_state
from mozyo_bridge.shared.paths import default_queue_path, default_tmux_conf, find_repo_root, resolve_repo_root


class NotificationTest(unittest.TestCase):
    def assert_exits_cleanly(self, callback) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                callback()

    def test_validate_notify_gate_requires_issue(self) -> None:
        args = argparse.Namespace(issue=None, journal="1", task_id=None)

        self.assert_exits_cleanly(lambda: validate_notify_gate(args))

    def test_validate_notify_gate_requires_journal_or_task(self) -> None:
        args = argparse.Namespace(issue="9020", journal=None, task_id=None)

        self.assert_exits_cleanly(lambda: validate_notify_gate(args))

    def test_build_prompt_uses_redmine_gate(self) -> None:
        args = argparse.Namespace(issue="9020", journal="46005", type="review_request", commit="abc123", prompt=None)

        prompt = build_prompt(args, "codex", None)

        self.assertIn("[mozyo:notify:issue=9020:journal=46005:type=review_request]", prompt)
        self.assertIn("Redmine #9020 journal #46005", prompt)
        self.assertIn("Stop-hook handoff waiting is disabled", prompt)
        self.assertEqual("[mozyo:notify:issue=9020:journal=46005:type=review_request]", landing_marker(args, None))

    def test_prompt_override_keeps_machine_landing_marker(self) -> None:
        args = argparse.Namespace(prompt="custom operator prompt", issue="9020", journal="1", type="review_request")

        self.assertEqual(
            "[mozyo:notify:issue=9020:journal=1:type=review_request] custom operator prompt",
            build_prompt(args, "codex", None),
        )
        self.assertEqual("[mozyo:notify:issue=9020:journal=1:type=review_request]", landing_marker(args, None))

    def test_build_prompt_uses_handoff_task(self) -> None:
        args = argparse.Namespace(prompt=None)
        task = {"id": "task-1", "issue_id": 9020, "commit": "abc123", "type": "review_request"}

        prompt = build_prompt(args, "codex", task)

        self.assertIn("[mozyo:notify:task=task-1:issue=9020]", prompt)
        self.assertIn("handoff task task-1 is ready for codex", prompt)
        self.assertIn("issue=#9020", prompt)
        self.assertEqual("[mozyo:notify:task=task-1:issue=9020]", landing_marker(args, task))

    def test_journal_takes_precedence_over_legacy_task(self) -> None:
        args = argparse.Namespace(
            prompt=None,
            issue="9020",
            journal="46005",
            type="review_request",
            commit="abc123",
        )
        task = {"id": "task-1", "issue_id": 9020, "commit": "abc123", "type": "review_request"}

        prompt = build_prompt(args, "codex", task)

        self.assertIn("Redmine #9020 journal #46005", prompt)
        self.assertNotIn("handoff task", prompt)
        self.assertEqual("[mozyo:notify:issue=9020:journal=46005:type=review_request]", landing_marker(args, task))


class QueueReaderTest(unittest.TestCase):
    def test_load_queue_returns_empty_tasks_when_file_is_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            queue = Path(tmp) / "missing" / "tasks.json"

            self.assertEqual({"tasks": []}, load_queue(queue))

    def test_load_queue_rejects_invalid_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            queue = Path(tmp) / "tasks.json"
            queue.write_text("tasks:\n  - id: yaml-is-not-json\n", encoding="utf-8")

            with contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    load_queue(queue)

        self.assertIn("queue must be JSON", stderr.getvalue())

    def test_load_queue_rejects_non_mapping_root(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            queue = Path(tmp) / "tasks.json"
            queue.write_text(json.dumps([{"id": "not-a-root-object"}]), encoding="utf-8")

            with contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    load_queue(queue)

        self.assertIn("queue root must be a mapping", stderr.getvalue())

    def test_load_queue_rejects_non_list_tasks(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            queue = Path(tmp) / "tasks.json"
            queue.write_text(json.dumps({"tasks": {"id": "not-a-list"}}), encoding="utf-8")

            with contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    load_queue(queue)

        self.assertIn("queue tasks must be a list", stderr.getvalue())

    def test_find_handoff_task_filters_pending_task(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            queue = Path(tmp) / "tasks.json"
            queue.write_text(
                json.dumps(
                    {
                        "tasks": [
                            {
                                "id": "old",
                                "to": "codex",
                                "issue_id": 9020,
                                "type": "review_request",
                                "status": "completed",
                                "created_at": "2026-05-01T00:00:00Z",
                            },
                            {
                                "id": "wanted",
                                "to": "codex",
                                "issue_id": 9020,
                                "type": "review_request",
                                "status": "pending",
                                "created_at": "2026-05-02T00:00:00Z",
                            },
                        ]
                    }
                ),
                encoding="utf-8",
            )
            args = argparse.Namespace(queue=str(queue), task_id="wanted", issue="9020", type="review_request")

            task = find_handoff_task(args, "codex")

            self.assertEqual("wanted", task["id"])

    def test_find_handoff_task_raises_for_completed_task(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            queue = Path(tmp) / "tasks.json"
            queue.write_text(
                json.dumps(
                    {
                        "tasks": [
                            {
                                "id": "done",
                                "to": "codex",
                                "issue_id": 9020,
                                "type": "review_request",
                                "status": "completed",
                            }
                        ]
                    }
                ),
                encoding="utf-8",
            )
            args = argparse.Namespace(queue=str(queue), task_id="done", issue="9020", type="review_request")

            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    find_handoff_task(args, "codex")


class PathResolutionTest(unittest.TestCase):
    def test_find_repo_root_walks_up_to_project_marker(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "project"
            nested = root / "a" / "b"
            nested.mkdir(parents=True)
            (root / ".tmux.conf").write_text("", encoding="utf-8")

            self.assertEqual(root.resolve(), find_repo_root(nested))

    def test_resolve_repo_root_prefers_explicit_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(Path(tmp).resolve(), resolve_repo_root(tmp))

    def test_default_paths_are_relative_to_resolved_repo(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".tmux.conf").write_text("", encoding="utf-8")

            self.assertEqual(root / ".agent_handoff" / "tasks.json", default_queue_path(root))
            self.assertEqual(root / ".tmux.conf", default_tmux_conf(root))


class PaneResolverTest(unittest.TestCase):
    def test_is_tmux_target(self) -> None:
        self.assertTrue(is_tmux_target("%1"))
        self.assertTrue(is_tmux_target("agents:0"))
        self.assertTrue(is_tmux_target("agents:0.1"))
        self.assertFalse(is_tmux_target("codex"))

    def test_ensure_agent_target_accepts_node_for_codex_window(self) -> None:
        pane = {"command": "node"}

        ensure_agent_target(pane, "codex")

    def test_ensure_agent_target_accepts_versioned_native_binary_for_claude_window(self) -> None:
        pane = {"command": "2.1.138"}

        ensure_agent_target(pane, "claude")

    def test_is_agent_process_accepts_versioned_native_binary(self) -> None:
        self.assertTrue(is_agent_process("2.1.138"))

    def test_is_receiver_agent_process_strong_identity_for_claude(self) -> None:
        # Step 12 strong identity: only literal `claude` counts as strong
        # identity for receiver=claude. Literal `codex` is rejected outright.
        self.assertTrue(is_receiver_agent_process("claude", "claude"))
        self.assertTrue(is_receiver_agent_process("/usr/local/bin/claude", "claude"))
        self.assertFalse(is_receiver_agent_process("codex", "claude"))

    def test_is_receiver_agent_process_strong_identity_for_codex(self) -> None:
        # Step 12 strong identity, symmetric case: only literal `codex` counts
        # as strong identity for receiver=codex. Literal `claude` is rejected.
        self.assertTrue(is_receiver_agent_process("codex", "codex"))
        self.assertTrue(is_receiver_agent_process("/opt/codex/bin/codex", "codex"))
        self.assertFalse(is_receiver_agent_process("claude", "codex"))

    def test_is_receiver_agent_process_node_is_weak_identity_for_both(self) -> None:
        # Step 12 weak identity (contract Open Question 8): both Claude Code
        # and the Codex CLI are Node-based applications, so a `node`
        # foreground process can belong to either receiver. The function
        # admits `node` for both receivers but treats it as weak identity;
        # callers must not advertise it as strong receiver confirmation.
        self.assertTrue(is_receiver_agent_process("node", "claude"))
        self.assertTrue(is_receiver_agent_process("node", "codex"))
        self.assertTrue(is_receiver_agent_process("/usr/local/bin/node", "claude"))
        self.assertTrue(is_receiver_agent_process("/usr/local/bin/node", "codex"))

    def test_is_receiver_agent_process_versioned_native_is_weak_identity(self) -> None:
        # Step 12 weak identity: versioned native binary basenames are
        # receiver-agnostic by design — `1.0.32-arm64` passes for both
        # `claude` and `codex`. This is honest weakness, not a bug;
        # cross-binding protection retreats to Step 9 + Layer A here.
        self.assertTrue(is_receiver_agent_process("1.0.32-arm64", "claude"))
        self.assertTrue(is_receiver_agent_process("1.0.32-arm64", "codex"))
        self.assertTrue(is_receiver_agent_process("2.1.138", "claude"))
        self.assertTrue(is_receiver_agent_process("2.1.138", "codex"))

    def test_is_receiver_agent_process_rejects_shells_and_empty(self) -> None:
        # queue-enter is never admitted to shells or to a pane whose
        # foreground process tmux reports as empty.
        for receiver in ("claude", "codex"):
            for command in ("zsh", "bash", "fish", "sh", "vim", "less", ""):
                self.assertFalse(
                    is_receiver_agent_process(command, receiver),
                    msg=f"{command!r} must not satisfy receiver={receiver!r}",
                )

    def test_is_receiver_agent_process_rejects_unknown_receiver_strong_only(self) -> None:
        # CLI args already restrict `--to` to RECEIVERS, but the function
        # must not silently grant the *strong* identity branch to an unknown
        # receiver. Literal receiver basenames fail the strong check and
        # fall through to the weak branch, which is receiver-agnostic by
        # design — only weak-branch matches admit for an unknown receiver.
        self.assertFalse(is_receiver_agent_process("claude", "operator"))
        self.assertFalse(is_receiver_agent_process("codex", "operator"))
        # Weak-branch matches admit even for unknown receivers; this is
        # documented as receiver-agnostic and is not a receiver-identity
        # claim. Test for both `node` and versioned-native cases.
        self.assertTrue(is_receiver_agent_process("node", "operator"))
        self.assertTrue(is_receiver_agent_process("1.0.32-arm64", "operator"))

    def test_ensure_agent_target_rejects_shell_without_force(self) -> None:
        pane = {"command": "bash"}

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                ensure_agent_target(pane, "codex")

    def test_read_marker_allows_recent_matching_read(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            original_prefix = pane_resolver.READ_MARK_PREFIX
            pane_resolver.READ_MARK_PREFIX = str(Path(tmp) / "read-")
            try:
                mark_read("%2")

                require_read("%2")

                clear_read("%2")
            finally:
                pane_resolver.READ_MARK_PREFIX = original_prefix

    def test_read_marker_rejects_expired_read(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            original_prefix = pane_resolver.READ_MARK_PREFIX
            pane_resolver.READ_MARK_PREFIX = str(Path(tmp) / "read-")
            marker = pane_resolver.read_mark_path("%2")
            marker.write_text(json.dumps({"pane_id": "%2", "created_at": time.time() - 1000}), encoding="utf-8")
            try:
                with contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit):
                        require_read("%2")

                self.assertFalse(marker.exists())
            finally:
                pane_resolver.READ_MARK_PREFIX = original_prefix

    def test_find_agent_window_returns_pane_for_window_named_agent(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "repo:0.0",
                "window_name": "claude",
                "pane_active": "1",
            },
            {
                "id": "%2",
                "location": "repo:1.0",
                "window_name": "codex",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            window = find_agent_window("codex", "repo")

        self.assertIsNotNone(window)
        self.assertEqual("%2", window["id"])

    def test_find_agent_window_returns_none_when_no_window_named_agent(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "repo:0.0",
                "window_name": "agents",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            self.assertIsNone(find_agent_window("claude", "repo"))

    def test_find_agent_window_dies_on_duplicate_window_name(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "repo:0.0",
                "window_name": "claude",
                "pane_active": "1",
            },
            {
                "id": "%2",
                "location": "repo:1.0",
                "window_name": "claude",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    find_agent_window("claude", "repo")

    def test_find_agent_window_prefers_active_pane_in_split_window(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "repo:0.0",
                "window_name": "claude",
                "pane_active": "0",
            },
            {
                "id": "%2",
                "location": "repo:0.1",
                "window_name": "claude",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            window = find_agent_window("claude", "repo")

        self.assertEqual("%2", window["id"])

    def test_find_agent_window_ignores_other_sessions(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "elsewhere:0.0",
                "window_name": "claude",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            self.assertIsNone(find_agent_window("claude", "repo"))

    def test_resolve_agent_label_uses_window_name_only(self) -> None:
        # Single-rail: no `@agent_name` label fallback. A pane in a non-agent
        # window does not resolve under the new model even when the operator
        # set the legacy label on it.
        panes = [
            {
                "id": "%1",
                "location": "repo:0.0",
                "window_name": "agents",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            self.assertIsNone(resolve_agent_label("claude", "repo"))

    def test_resolve_agent_label_never_falls_back_cross_session(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "elsewhere:0.0",
                "window_name": "claude",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            self.assertIsNone(resolve_agent_label("claude", "repo"))

    def test_resolve_agent_label_returns_none_when_session_unknown(self) -> None:
        with patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=[]):
            self.assertIsNone(resolve_agent_label("claude", None))

    def test_resolve_target_for_agent_label_dies_outside_tmux(self) -> None:
        with patch("mozyo_bridge.domain.pane_resolver.current_session_name", return_value=None), \
            contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                resolve_target("codex")

    def test_resolve_target_for_agent_label_dies_when_not_in_current_session(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "elsewhere:0.0",
                "window_name": "codex",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.current_session_name", return_value="repo"), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes), \
            contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                resolve_target("codex")

    def test_resolve_target_for_agent_label_returns_window_pane(self) -> None:
        panes = [
            {
                "id": "%9",
                "location": "repo:1.0",
                "window_name": "codex",
                "pane_active": "1",
            },
        ]

        with patch("mozyo_bridge.domain.pane_resolver.current_session_name", return_value="repo"), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes):
            self.assertEqual("%9", resolve_target("codex"))

    def test_resolve_target_rejects_non_agent_string(self) -> None:
        # Custom strings used to fall through to the `@agent_name` label
        # lookup; under the window-only model they fail closed at resolve
        # time with a hint to pass a tmux pane id or an agent label.
        with patch(
            "mozyo_bridge.domain.pane_resolver.current_session_name",
            return_value="repo",
        ), contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaises(SystemExit):
                resolve_target("operator_pane")

        self.assertIn("operator_pane", stderr.getvalue())
        self.assertIn("claude", stderr.getvalue())


class CliTest(unittest.TestCase):
    def test_primary_commands_parse(self) -> None:
        parser = build_parser()

        self.assertEqual("status", parser.parse_args(["status"]).command)
        self.assertEqual("init", parser.parse_args(["init", "codex"]).command)
        self.assertEqual("notify-codex-review", parser.parse_args(["notify-codex-review", "--issue", "9020"]).command)
        self.assertEqual("rules", parser.parse_args(["rules", "install"]).command)
        self.assertEqual("scaffold", parser.parse_args(["scaffold", "apply", "asana"]).command)
        self.assertEqual("doctor", parser.parse_args(["doctor"]).command)

    def test_notify_codex_accepts_type(self) -> None:
        parser = build_parser()

        args = parser.parse_args(["notify-codex", "--issue", "9020", "--journal", "1", "--type", "review_request"])

        self.assertEqual("notify-codex", args.command)
        self.assertEqual("review_request", args.type)

    def test_standard_notify_rejects_legacy_task_id(self) -> None:
        parser = build_parser()

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(["notify-codex", "--issue", "9020", "--task-id", "legacy-task"])

    def test_standard_notify_rejects_tmux_ui_options(self) -> None:
        parser = build_parser()

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(["notify-codex", "--issue", "9020", "--journal", "1", "--ensure"])

    def test_legacy_pane_split_subcommands_are_rejected(self) -> None:
        parser = build_parser()
        for command in (
            "open-here",
            "tmux-ui-open",
            "tmux-ui-setup",
            "tmux-ui-ensure",
            "tmux-ui-ensure-pair",
            "tmux-ui-spawn",
        ):
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    parser.parse_args([command])

    def test_legacy_task_notification_is_separate_command(self) -> None:
        parser = build_parser()

        args = parser.parse_args(
            ["notify-codex-legacy-task", "--issue", "9020", "--task-id", "legacy-task", "--type", "review_request"]
        )

        self.assertEqual("notify-codex-legacy-task", args.command)
        self.assertEqual("legacy-task", args.task_id)

    def test_status_session_defaults_to_none_for_runtime_resolution(self) -> None:
        # Hard-coding the default to "agents" was the root cause of the
        # misleading `session: agents (missing)` symptom under bare `mozyo`
        # (Asana task 1214758916882465). Bare `status` must auto-resolve the
        # session at runtime instead.
        parser = build_parser()

        args = parser.parse_args(["status"])

        self.assertEqual("status", args.command)
        self.assertIsNone(args.session)

    def test_status_accepts_explicit_session_override(self) -> None:
        parser = build_parser()

        args = parser.parse_args(["status", "--session", "agents"])

        self.assertEqual("agents", args.session)

    def test_bare_mozyo_parses_with_no_subcommand(self) -> None:
        parser = build_parser()

        args = parser.parse_args([])

        self.assertIsNone(args.command)
        self.assertFalse(args.no_attach)

    def test_bare_mozyo_accepts_no_attach_flag(self) -> None:
        parser = build_parser()

        args = parser.parse_args(["--no-attach"])

        self.assertIsNone(args.command)
        self.assertTrue(args.no_attach)

    def test_bare_mozyo_accepts_top_level_repo_override(self) -> None:
        parser = build_parser()

        args = parser.parse_args(["--repo", "/explicit/repo"])

        self.assertIsNone(args.command)
        self.assertEqual("/explicit/repo", args.repo)

    def test_subcommand_repo_still_works_after_top_level_repo_added(self) -> None:
        parser = build_parser()

        args = parser.parse_args(["status", "--repo", "/repo"])

        self.assertEqual("status", args.command)
        self.assertEqual("/repo", args.repo)

    def test_bare_mozyo_accepts_session_override(self) -> None:
        parser = build_parser()

        args = parser.parse_args(["--session", "alt"])

        self.assertIsNone(args.command)
        self.assertEqual("alt", args.session)

    def test_version_flag_prints_version_and_exits_cleanly(self) -> None:
        parser = build_parser()
        stdout = io.StringIO()

        with contextlib.redirect_stdout(stdout):
            with self.assertRaises(SystemExit) as ctx:
                parser.parse_args(["--version"])

        self.assertEqual(0, ctx.exception.code)
        self.assertIn(__version__, stdout.getvalue())
        self.assertIn("mozyo-bridge", stdout.getvalue())

    def test_module_version_matches_pyproject_version(self) -> None:
        pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        match = re.search(r'^version = "([^"]+)"', pyproject, flags=re.MULTILINE)

        self.assertIsNotNone(match)
        self.assertEqual(match.group(1), __version__)

    def test_scaffold_apply_rejects_unknown_preset(self) -> None:
        parser = build_parser()

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(["scaffold", "apply", "jira"])

    def test_scaffold_diff_rejects_unknown_preset(self) -> None:
        parser = build_parser()

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(["scaffold", "diff", "jira"])

    def test_legacy_scaffold_subcommand_is_removed(self) -> None:
        """Breaking change: the legacy `rules` subcommand under `scaffold` is no longer parsable.

        The v0.3 scaffold redesign removed it entirely. There is no
        compatibility alias; the official entrypoint is
        `scaffold apply <preset>` for write and `scaffold diff <preset>` for
        preview. Asserting the parser rejects the argv pair locks the
        breaking change so a future revert cannot silently bring the alias
        back. The rejected argv is built from parts so this source file does
        not carry the old command name as contiguous prose.
        """
        parser = build_parser()
        legacy_subcommand = "ru" + "les"  # split to avoid the literal phrase in source

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(["scaffold", legacy_subcommand, "asana"])


class ScaffoldRulesTest(unittest.TestCase):
    def run_cli(self, argv: list[str]) -> tuple[int, str]:
        parser = build_parser()
        args = parser.parse_args(argv)
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            result = args.func(args)
        return result, stdout.getvalue()

    def test_rules_install_and_scaffold_asana_thin_router(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()

            result, _ = self.run_cli(["rules", "install", "--home", str(home)])
            self.assertEqual(0, result)
            asana_workflow = home / "rules" / "presets" / "asana" / "agent-workflow.md"
            self.assertTrue(asana_workflow.exists())
            installed_workflow = asana_workflow.read_text(encoding="utf-8")
            self.assertIn("User Interaction And Escalation", installed_workflow)
            self.assertIn("designated coordinator", installed_workflow)
            self.assertIn("Role Boundaries", installed_workflow)
            self.assertIn("coordinating/auditing agent must not directly implement", installed_workflow)
            # Asana-native guardrails added in this task.
            for marker in (
                "Factual Posture",
                "Prioritize factual correctness",
                "review input, not completion",
                "Handoff Startup Decision",
                "Receiver pane unavailable",
                "Notification fails",
                "mozyo-bridge init",
                "Receive method id",
                "Asana API",
                "Scope Preservation",
                "residual scope",
                "Decision Routing",
                # Ticket-ID entrypoint runtime reflection.
                "Ticket-ID Entrypoint",
                'ticket-ID only',
                "pane / chat body looks fully framed",
                "task comment / story id",
                # Audit-owned commit authority codified in this task.
                "Audit-Owned Commit Authority",
                "commit authority, not an implementation authority",
                "Refs: Asana task <task_id>",
                "Audit: Asana comment <comment_id>",
                "git diff --cached --stat",
                "git add -A",
                "commit-hash comment",
                # Chat-surface boundary added to reduce noisy chat output for
                # un-notified / pending-operator-action handoffs.
                "Chat surface boundary",
                "Chat output is a notification only",
                "Do not duplicate the comment body in chat",
            ):
                self.assertIn(marker, installed_workflow)
            # Asana central preset must NOT import Redmine journal / gate semantics.
            for forbidden in (
                "Redmine journal",
                "Review Gate",
                "Implementation Done Gate",
                "Close Gate",
                "Design Consultation Gate",
            ):
                self.assertNotIn(forbidden, installed_workflow)
            # The central preset is the scaffold for arbitrary downstream
            # projects; team-specific tools (Notion in this team's flow) must
            # not leak into the generated guidance.
            self.assertNotIn("Notion", installed_workflow)
            self.assertIn(
                "Do not ask the user directly when the task, project notes, or repository docs",
                installed_workflow,
            )
            self.assertIn(
                "Do not store credentials, tokens, personal data, or private internal URLs",
                installed_workflow,
            )

            result, output = self.run_cli(["scaffold", "apply", "asana", "--target", str(project), "--home", str(home)])

            self.assertEqual(0, result)
            self.assertIn("AGENTS.md", output)
            self.assertTrue((project / "AGENTS.md").exists())
            self.assertTrue((project / "CLAUDE.md").exists())
            self.assertFalse((project / "vibes" / "docs" / "rules" / "asana-agent-workflow.md").exists())
            agents = (project / "AGENTS.md").read_text(encoding="utf-8")
            self.assertIn(
                "${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}/rules/presets/asana/agent-workflow.md",
                agents,
            )
            # The router must not leak the host-resolved home path or any
            # user-specific absolute home path.
            self.assertNotIn(str(home), agents)
            self.assertNotIn("/Users/", agents)
            self.assertIn("active な `Asana task / comment`", agents)
            self.assertIn("router に本文を複製しない", agents)
            # Generated routers must not name vibes/docs/* paths as runtime context.
            # vibes/docs/ is this repo's design/spec source, not an external scaffold
            # target's runtime convention.
            self.assertNotIn("vibes/docs/specs/project-map.md", agents)
            self.assertNotIn("vibes/docs/rules/agent-workflow.md", agents)
            self.assertNotIn("vibes/docs/", agents)
            # The Project-Local Context heading was folded into step 3.
            self.assertNotIn("## Project-Local Context", agents)
            self.assertIn("target project 側の任意の convention", agents)
            self.assertIn("mozyo-bridge の runtime 必須参照ではない", agents)

            claude = (project / "CLAUDE.md").read_text(encoding="utf-8")
            self.assertIn(
                "${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}/rules/presets/asana/agent-workflow.md",
                claude,
            )
            self.assertNotIn(str(home), claude)
            self.assertNotIn("/Users/", claude)
            self.assertIn("ClaudeCode 起動時の最小 reminder", claude)
            self.assertIn("迎合せず", claude)
            self.assertIn("implementation done / implementation_done は completion ではない", claude)
            self.assertIn("Asana task / comment", claude)
            self.assertIn("受領方法", claude)
            # Chat surface stays thin: durable receive method lives in the task
            # comment, chat reports stay to a state + task-id pointer.
            self.assertIn("最小ポインタ", claude)
            self.assertIn("chat に貼り直さない", claude)
            # CLAUDE.md stays thin even with the Claude-specific reminder
            # block AND the Project-Local Additions marker block + boilerplate
            # (~9 lines) shipped from the router template.
            self.assertLess(len(claude.splitlines()), 50)
            # Asana CLAUDE.md must not import Redmine-specific vocabulary.
            for forbidden in ("Redmine journal", "Review Gate", "Implementation Done Gate"):
                self.assertNotIn(forbidden, claude)

            state = scaffold_state(project)
            self.assertIsNotNone(state)
            assert state is not None
            self.assertEqual("central", state["mode"])
            self.assertEqual("asana", state["preset"])
            # Schema v2 + preset_hash from the previous task must still be in effect.
            self.assertEqual(2, state["schema_version"])
            self.assertEqual(
                hashlib.sha256(asana_workflow.read_bytes()).hexdigest(),
                state["preset_hash"],
            )
            self.assertEqual("2026.05.17.2", state["preset_version"])
            self.assertIn("AGENTS.md", state["files"])

            # The audit-owned commit policy belongs in the central preset only.
            # Root routers stay thin and must not duplicate the policy body.
            self.assertNotIn("Audit-Owned Commit Authority", agents)
            self.assertNotIn("Audit-Owned Commit Authority", claude)
            self.assertNotIn("Refs: Asana task", agents)
            self.assertNotIn("Refs: Asana task", claude)

            # Tool-specific router split: the rendered routers must not import
            # each other. CLAUDE.md previously imported AGENTS.md via the
            # Claude Code `@AGENTS.md` file-import directive; the split makes
            # each tool's entry standalone so the central preset path and the
            # active ticket anchor are reachable without touching the peer
            # file. This rendered-output assertion catches a future template
            # regression that template-level tests would miss if the import
            # ever leaked through substitution.
            self.assertNotIn("@AGENTS.md", claude)
            self.assertNotIn("@CLAUDE.md", agents)
            self.assertIn("tool-specific", agents)
            self.assertIn("tool-specific", claude)
            self.assertIn("import しない", agents)
            self.assertIn("import しない", claude)

    def test_rules_install_and_scaffold_redmine_thin_router(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()

            result, _ = self.run_cli(["rules", "install", "--home", str(home)])
            self.assertEqual(0, result)
            redmine_workflow = home / "rules" / "presets" / "redmine" / "agent-workflow.md"
            self.assertTrue(redmine_workflow.exists())
            installed = redmine_workflow.read_text(encoding="utf-8")
            for marker in (
                "Redmine Gate Lifecycle",
                "Start Gate",
                "Progress Log Gate",
                "Design Consultation Gate",
                "Design Consultation Answer Gate",
                "Implementation Done Gate",
                "Review Request Gate",
                "Review Gate",
                "QA Verification Gate",
                "Production Verification Gate",
                "Close Gate",
                "Pane Notification",
                "Handoff Startup Decision",
                "Review Quality Hierarchy",
                "Test / QA Role Boundary",
                "Close Gate Checklist",
                "事実姿勢",
                "実装者 / 監査者境界",
                "判断の routing",
                "Scope Integrity",
                "Verification Discipline",
                "notify-codex-review",
                "mozyo-bridge init",
                "Receiver pane unavailable",
                "Notification fails",
                "`Implementation Done` は `完了` ではない",
                "Stop hook handoff wait",
                "迎合より事実を優先する",
                # Ticket-ID entrypoint runtime reflection.
                "Ticket-ID Entrypoint",
                "入力が Redmine issue id",
                "Redmine issue record",
                "journal id と gate 順序が監査 replay の鍵",
                # Audit-owned commit authority codified in this task.
                "Audit-Owned Commit Authority",
                "commit authority であって implementation authority ではない",
                "Refs: Redmine #<issue_id>",
                "Journal: <journal_id>",
                "Review Gate journal",
                "git diff --cached --stat",
                "git add -A",
                "Close Gate journal",
                # Chat-surface boundary added to reduce noisy chat output for
                # un-notified / pending-operator-action handoffs.
                "chat には issue / journal id",
                "durable 手順を chat に再掲しない",
                "durable 手順",
                # Field-tested Redmine review payload details.
                "Review Request Gate",
                "target commit / diff",
                "changed files",
                "期待する read / ack path",
                "[事実]",
                "[仮説]",
                "是正条件",
                "仕様・設計整合",
                "bug / spec misunderstanding / unnecessary work",
                "reproduction",
                "expected",
                "actual",
                "version consistency",
                "`catalog.yaml` / docs resolver / nagger file conventions tooling の標準化は別タスク",
                # Close Approval Separation codified in 2026.05.18.3: review
                # approval and owner close approval are distinct gates; the
                # reviewer (audit role / Codex equivalent) records a separate
                # journal asking the owner about close after review approval,
                # and the implementer must not close from review approval
                # alone.
                "Close Approval Separation",
                "owner close approval",
                "Review Gate approval を owner close approval と読み替えない",
                "Review Gate とは別 journal",
                "owner close approval が未取得のまま close してはならない",
                "同一 issue の **別 journal** を作成し、owner にクローズ可否を確認する",
                "Review Gate approval だけで issue を close へ進めない",
            ):
                self.assertIn(marker, installed)
            self.assertIn(
                "`Claude Code が常に実装、Codex が常に監査` のような固定 role split",
                installed,
            )
            self.assertNotIn("python3 vibes/tools/mozyo_bridge", installed)
            self.assertNotIn(".claude-nagger/file_conventions.yaml", installed)
            self.assertNotIn("resolve_audit_docs.py", installed)
            # The central preset is the scaffold for arbitrary downstream
            # projects; team-specific tools (Notion in this team's flow) must
            # not leak into the generated guidance.
            self.assertNotIn("Notion", installed)
            self.assertNotIn("vibes/docs/catalog.yaml", installed)
            self.assertNotIn("manual_spec", installed)
            self.assertNotIn("FeatureListDsl", installed)
            self.assertNotIn("/myapp/Source/rails", installed)
            self.assertNotIn("tmux-integrated", installed)
            self.assertNotIn("VS Code", installed)
            # Implementation Done Gate is a distinct durable gate, not a Progress Log.
            # The Factual Posture wording must not downgrade it.
            self.assertNotIn("self-verification is a Progress Log", installed)
            self.assertIn("review input であり completion ではない", installed)

            result, output = self.run_cli(
                ["scaffold", "apply", "redmine", "--target", str(project), "--home", str(home)]
            )

            self.assertEqual(0, result)
            self.assertIn("AGENTS.md", output)
            self.assertTrue((project / "AGENTS.md").exists())
            self.assertTrue((project / "CLAUDE.md").exists())
            agents = (project / "AGENTS.md").read_text(encoding="utf-8")
            self.assertIn(
                "${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}/rules/presets/redmine/agent-workflow.md",
                agents,
            )
            self.assertNotIn(str(home), agents)
            self.assertNotIn("/Users/", agents)
            self.assertIn("active な `Redmine issue / journal`", agents)
            self.assertIn("durable state、handoff、review、verification、close 条件", agents)
            self.assertIn("router に本文を複製しない", agents)
            # Generated routers must not name vibes/docs/* paths as runtime context.
            # vibes/docs/ is this repo's design/spec source, not an external scaffold
            # target's runtime convention.
            self.assertNotIn("vibes/docs/specs/project-map.md", agents)
            self.assertNotIn("vibes/docs/rules/agent-workflow.md", agents)
            self.assertNotIn("vibes/docs/", agents)
            self.assertNotIn("## Project-Local Context", agents)
            self.assertIn("target project 側の任意の convention", agents)
            self.assertIn("mozyo-bridge の runtime 必須参照ではない", agents)

            claude = (project / "CLAUDE.md").read_text(encoding="utf-8")
            self.assertIn(
                "${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}/rules/presets/redmine/agent-workflow.md",
                claude,
            )
            self.assertNotIn(str(home), claude)
            self.assertNotIn("/Users/", claude)
            self.assertIn("ClaudeCode 起動時の最小 reminder", claude)
            self.assertIn("迎合せず", claude)
            self.assertIn("implementation done / implementation_done は completion ではない", claude)
            self.assertIn("Redmine issue / journal", claude)
            self.assertIn("handoff startup decision", claude)
            # Chat surface stays thin: durable receive method lives in Redmine,
            # chat reports stay to a state + issue/journal-id pointer.
            self.assertIn("最小ポインタ", claude)
            self.assertIn("chat に貼り直さない", claude)
            # Router stays thin: well below the central preset's depth, even
            # with the Project-Local Additions marker block + boilerplate
            # (~9 lines) shipped from the router template.
            self.assertLess(len(claude.splitlines()), 50)
            self.assertNotIn("Redmine Gate Lifecycle", claude)
            self.assertNotIn("Implementer / Auditor Role Boundary", claude)

            state = scaffold_state(project)
            self.assertIsNotNone(state)
            assert state is not None
            self.assertEqual("central", state["mode"])
            self.assertEqual("redmine", state["preset"])
            self.assertIn("AGENTS.md", state["files"])
            self.assertEqual("2026.05.18.3", state["preset_version"])

            # The audit-owned commit policy belongs in the central preset only.
            # Root routers stay thin and must not duplicate the policy body.
            self.assertNotIn("Audit-Owned Commit Authority", agents)
            self.assertNotIn("Audit-Owned Commit Authority", claude)
            self.assertNotIn("Refs: Redmine #", agents)
            self.assertNotIn("Refs: Redmine #", claude)

    def test_rules_install_and_scaffold_redmine_rails_layered_router(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()

            result, _ = self.run_cli(["rules", "install", "--home", str(home)])
            self.assertEqual(0, result)
            rails_workflow = home / "rules" / "presets" / "redmine-rails" / "agent-workflow.md"
            self.assertTrue(rails_workflow.exists())
            installed = rails_workflow.read_text(encoding="utf-8")
            for marker in (
                "Redmine Rails Agent Workflow",
                "rules/presets/redmine/agent-workflow.md",
                "Rails Scope Posture",
                "Rails Design Consultation Triggers",
                "Rails Implementation Done Additions",
                "Rails Review Focus",
                "Data / migration safety",
                "Authorization / tenant boundary",
                "Hotwire / UI behavior",
                "Rails Verification Discipline",
                "Rails QA / Production Verification",
                # Project-Local Layer section added in 2026.05.18.3.
                # The scaffold preset must explicitly tell operators which
                # categories of project-local facts stay in the target repo
                # and must not be overwritten by `scaffold apply`.
                "Project-Local Layer",
                "Project-Local Layer Apply Discipline",
                "do not erase on scaffold apply",
                "App stack identity",
                "Rails extension conventions",
                "Read-only documentation areas",
                "Project-specific safety commands",
                "Project docs governance",
                "Local role-boundary overrides",
                "Project tooling and private convention",
                "scaffold diff redmine-rails",
                "--backup",
                # New marker-bounded preservation guidance + concrete
                # category sections added in 2026.05.18.4.
                "Project-Local Additions マーカー",
                "<!-- mozyo-bridge:project-local-additions:begin -->",
                "<!-- mozyo-bridge:project-local-additions:end -->",
                "Active-Doc Resolver Concept",
                "Dangerous DB / Test Command Category",
                "Presenter / YAML / Doc-Readonly Category",
                "Project Tooling / Local Skill / Role-Boundary Override Category",
            ):
                self.assertIn(marker, installed)
            # Regression rails: the scaffold preset must not import team-specific
            # paths or convention names, even when describing what stays in
            # project-local docs. Existing-repo examples are described in
            # generic terms only.
            self.assertNotIn("/myapp/Source/rails", installed)
            self.assertNotIn("vibes/docs/catalog.yaml", installed)
            self.assertNotIn(".claude-nagger/file_conventions.yaml", installed)
            self.assertNotIn("resolve_audit_docs.py", installed)
            self.assertNotIn("bin/recreate_db.sh", installed)
            self.assertNotIn("bin/sync-mozyo-bridge-skill", installed)
            self.assertNotIn("RAILS_ENV=test", installed)
            self.assertNotIn("app/presenters/", installed)

            result, _ = self.run_cli(
                ["scaffold", "apply", "redmine-rails", "--target", str(project), "--home", str(home)]
            )

            self.assertEqual(0, result)
            agents = (project / "AGENTS.md").read_text(encoding="utf-8")
            claude = (project / "CLAUDE.md").read_text(encoding="utf-8")
            self.assertIn(
                "${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}/rules/presets/redmine-rails/agent-workflow.md",
                agents,
            )
            self.assertIn("active な `Redmine issue / journal と Rails project docs`", agents)
            self.assertIn("router に本文を複製しない", agents)
            self.assertNotIn("Data / migration safety", agents)
            self.assertNotIn("Rails Review Focus", claude)

            state = scaffold_state(project)
            self.assertIsNotNone(state)
            assert state is not None
            self.assertEqual("redmine-rails", state["preset"])
            self.assertEqual("2026.05.18.4", state["preset_version"])

    def test_scaffold_requires_installed_central_preset(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()

            with contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    self.run_cli(["scaffold", "apply", "redmine", "--target", str(project), "--home", str(home)])

            self.assertIn("rules preset is not installed", stderr.getvalue())
            self.assertFalse((project / "AGENTS.md").exists())

    def test_scaffold_without_target_writes_to_current_working_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            parent = Path(tmp) / "parent"
            nested = parent / "nested"
            nested.mkdir(parents=True)
            (parent / "pyproject.toml").write_text("[project]\nname = \"parent\"\n", encoding="utf-8")
            self.run_cli(["rules", "install", "--home", str(home)])
            cwd = Path.cwd()
            try:
                os.chdir(nested)

                result, output = self.run_cli(["scaffold", "apply", "asana", "--home", str(home)])

                self.assertEqual(0, result)
                self.assertIn(str(nested / "AGENTS.md"), output)
                self.assertTrue((nested / "AGENTS.md").exists())
                self.assertTrue((nested / "CLAUDE.md").exists())
                self.assertFalse((parent / "AGENTS.md").exists())
            finally:
                os.chdir(cwd)

    def test_scaffold_without_target_ignores_mozyo_repo_env(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            env_repo = Path(tmp) / "env-repo"
            cwd_project = Path(tmp) / "cwd-project"
            env_repo.mkdir()
            cwd_project.mkdir()
            self.run_cli(["rules", "install", "--home", str(home)])
            cwd = Path.cwd()
            try:
                os.chdir(cwd_project)
                with patch.dict(os.environ, {"MOZYO_REPO": str(env_repo)}):
                    result, _ = self.run_cli(["scaffold", "apply", "none", "--home", str(home)])

                self.assertEqual(0, result)
                self.assertTrue((cwd_project / "AGENTS.md").exists())
                self.assertFalse((env_repo / "AGENTS.md").exists())
            finally:
                os.chdir(cwd)

    def test_rules_status_reports_installed_presets(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"

            self.run_cli(["rules", "install", "--home", str(home)])

            result, output = self.run_cli(["rules", "status", "--home", str(home)])
            rows = rules_status(home)

            self.assertEqual(0, result)
            self.assertIn("PRESET\tSTATUS\tINSTALLED\tPACKAGED\tPATH", output)
            self.assertEqual(["ok", "ok", "ok", "ok"], [row["status"] for row in rows])
            self.assertIn(f"asana\tok\t{package_version('asana')}\t{package_version('asana')}\t", output)
            self.assertIn(
                f"redmine-rails\tok\t{package_version('redmine-rails')}\t{package_version('redmine-rails')}\t",
                output,
            )
            self.assertIn(str(home / "rules" / "presets" / "asana" / "agent-workflow.md"), output)

    def test_rules_status_reports_missing_and_outdated_presets(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"

            self.run_cli(["rules", "install", "--home", str(home)])
            (home / "rules" / "presets" / "redmine" / "agent-workflow.md").unlink()
            (home / "rules" / "presets" / "none" / "VERSION").write_text("0.0.0\n", encoding="utf-8")

            result, output = self.run_cli(["rules", "status", "--home", str(home)])
            rows = {row["preset"]: row for row in rules_status(home)}

            self.assertEqual(1, result)
            self.assertEqual("ok", rows["asana"]["status"])
            self.assertEqual("missing", rows["redmine"]["status"])
            self.assertEqual("-", rows["redmine"]["installed"])
            self.assertEqual("outdated", rows["none"]["status"])
            self.assertEqual("0.0.0", rows["none"]["installed"])
            self.assertIn(f"redmine\tmissing\t-\t{package_version('redmine')}\t", output)
            self.assertIn(f"none\toutdated\t0.0.0\t{package_version('none')}\t", output)

    def test_scaffold_refuses_overwrite_by_default_and_dry_run_writes_nothing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()
            self.run_cli(["rules", "install", "--home", str(home)])
            self.run_cli(["scaffold", "apply", "none", "--target", str(project), "--home", str(home)])

            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    self.run_cli(["scaffold", "apply", "none", "--target", str(project), "--home", str(home)])

            fresh = Path(tmp) / "fresh"
            fresh.mkdir()
            result, output = self.run_cli(
                ["scaffold", "apply", "none", "--target", str(fresh), "--home", str(home), "--dry-run"]
            )

            self.assertEqual(0, result)
            self.assertIn("would write", output)
            self.assertFalse((fresh / "AGENTS.md").exists())

    def test_scaffold_backup_replaces_existing_router(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()
            (project / "AGENTS.md").write_text("old agents\n", encoding="utf-8")
            (project / "CLAUDE.md").write_text("old claude\n", encoding="utf-8")
            self.run_cli(["rules", "install", "--home", str(home)])

            result, _ = self.run_cli(["scaffold", "apply", "redmine", "--target", str(project), "--home", str(home), "--backup"])

            self.assertEqual(0, result)
            self.assertIn("active な `Redmine issue / journal`", (project / "AGENTS.md").read_text(encoding="utf-8"))
            self.assertTrue(list(project.glob("AGENTS.md.bak.*")))
            self.assertTrue(list(project.glob("CLAUDE.md.bak.*")))

    def test_relative_home_does_not_leak_into_router_or_manifest(self) -> None:
        # Even when --home resolves to a host-specific absolute path, the
        # generated router and the scaffold manifest must record the portable
        # ${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge} symbolic form. This guards
        # against personal-home leakage in committed artifacts.
        with tempfile.TemporaryDirectory() as tmp:
            cwd = Path.cwd()
            try:
                os.chdir(tmp)
                project = Path(tmp) / "project"
                project.mkdir()
                self.run_cli(["rules", "install", "--home", "home"])

                self.run_cli(["scaffold", "apply", "asana", "--target", str(project), "--home", "home"])

                state = scaffold_state(project)
                self.assertIsNotNone(state)
                assert state is not None
                self.assertEqual(
                    "${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}/rules/presets/asana/agent-workflow.md",
                    state["rule_path"],
                )

                resolved_home = (Path(tmp) / "home").resolve()
                for filename in ("AGENTS.md", "CLAUDE.md", ".mozyo-bridge/scaffold.json"):
                    text = (project / filename).read_text(encoding="utf-8")
                    self.assertNotIn(str(resolved_home), text)
                    self.assertIn(
                        "${MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}/rules/presets/asana/agent-workflow.md",
                        text,
                    )
            finally:
                os.chdir(cwd)

    def test_scaffold_does_not_leak_home_path_for_any_preset(self) -> None:
        # Fresh scaffold for every supported preset must avoid leaking the
        # resolved host home path into AGENTS.md, CLAUDE.md, or the manifest,
        # and must instead reference the portable symbolic form. The MOZYO_BRIDGE_HOME
        # override semantics are preserved because consumers expand the env var
        # when they read the router, not when the router is generated.
        for preset in ("asana", "redmine", "redmine-rails", "none"):
            with self.subTest(preset=preset):
                with tempfile.TemporaryDirectory() as tmp:
                    home = Path(tmp) / "home"
                    project = Path(tmp) / "project"
                    project.mkdir()

                    self.run_cli(["rules", "install", "--home", str(home)])
                    result, _ = self.run_cli(
                        ["scaffold", "apply", preset, "--target", str(project), "--home", str(home)]
                    )
                    self.assertEqual(0, result)

                    resolved_home = home.resolve()
                    expected_rule_path = (
                        f"${{MOZYO_BRIDGE_HOME:-~/.mozyo_bridge}}/rules/presets/{preset}/agent-workflow.md"
                    )
                    for filename in ("AGENTS.md", "CLAUDE.md", ".mozyo-bridge/scaffold.json"):
                        text = (project / filename).read_text(encoding="utf-8")
                        self.assertNotIn("/Users/", text)
                        self.assertNotIn(str(resolved_home), text)
                        self.assertIn(expected_rule_path, text)

                    state = scaffold_state(project)
                    self.assertIsNotNone(state)
                    assert state is not None
                    self.assertEqual(expected_rule_path, state["rule_path"])

                    status_result, status_output = self.run_cli(
                        ["scaffold", "status", "--target", str(project), "--home", str(home)]
                    )
                    self.assertEqual(0, status_result)
                    self.assertIn("clean", status_output)


class ScaffoldDiffTest(unittest.TestCase):
    """Coverage for the new `scaffold diff <preset>` breaking-change entrypoint."""

    def run_cli(self, argv: list[str]) -> tuple[int, str]:
        parser = build_parser()
        args = parser.parse_args(argv)
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            result = args.func(args)
        return result, stdout.getvalue()

    def test_diff_detects_unapplied_scaffold(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()
            self.run_cli(["rules", "install", "--home", str(home)])

            result, output = self.run_cli(
                ["scaffold", "diff", "asana", "--target", str(project), "--home", str(home)]
            )

            self.assertEqual(1, result)
            self.assertIn("+++ b/AGENTS.md", output)
            self.assertIn("+++ b/CLAUDE.md", output)
            self.assertIn("+++ b/.mozyo-bridge/scaffold.json", output)
            self.assertFalse((project / "AGENTS.md").exists())
            self.assertFalse((project / "CLAUDE.md").exists())
            self.assertFalse((project / ".mozyo-bridge" / "scaffold.json").exists())

    def test_diff_is_clean_after_apply(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()
            self.run_cli(["rules", "install", "--home", str(home)])
            self.run_cli(
                ["scaffold", "apply", "redmine", "--target", str(project), "--home", str(home)]
            )

            result, output = self.run_cli(
                ["scaffold", "diff", "redmine", "--target", str(project), "--home", str(home)]
            )

            self.assertEqual(0, result)
            self.assertIn("scaffold diff: clean", output)
            self.assertNotIn("--- a/", output)

    def test_diff_detects_local_edit_against_rendered_output(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()
            self.run_cli(["rules", "install", "--home", str(home)])
            self.run_cli(
                ["scaffold", "apply", "asana", "--target", str(project), "--home", str(home)]
            )

            agents = project / "AGENTS.md"
            agents.write_text(
                agents.read_text(encoding="utf-8") + "\nlocal hand edit\n",
                encoding="utf-8",
            )

            result, output = self.run_cli(
                ["scaffold", "diff", "asana", "--target", str(project), "--home", str(home)]
            )

            self.assertEqual(1, result)
            self.assertIn("--- a/AGENTS.md", output)
            self.assertIn("+++ b/AGENTS.md", output)
            self.assertIn("local hand edit", output)

    def test_diff_requires_installed_central_preset(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()

            with contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    self.run_cli(
                        ["scaffold", "diff", "asana", "--target", str(project), "--home", str(home)]
                    )

            self.assertIn("rules preset is not installed", stderr.getvalue())


class ScaffoldProjectLocalAdditionsPreservationTest(unittest.TestCase):
    """Marker-bounded preservation contract for project-local additions.

    Operators put project-local layer body (Rails / Ruby version, dangerous
    DB / test commands, Presenter / YAML conventions, docs catalog
    governance, role-boundary overrides, etc.) between the marker pair shipped
    inside scaffold-generated AGENTS.md / CLAUDE.md. `scaffold apply` and
    `scaffold diff` must mechanically preserve that body across re-sync so
    mature target repos do not lose project-local guardrails when a new
    preset version lands.
    """

    BEGIN = "<!-- mozyo-bridge:project-local-additions:begin -->"
    END = "<!-- mozyo-bridge:project-local-additions:end -->"

    def run_cli(self, argv: list[str]) -> tuple[int, str]:
        parser = build_parser()
        args = parser.parse_args(argv)
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            result = args.func(args)
        return result, stdout.getvalue()

    def _setup(self, tmp: Path, preset: str = "redmine-rails") -> tuple[Path, Path]:
        home = tmp / "home"
        project = tmp / "project"
        project.mkdir()
        self.run_cli(["rules", "install", "--home", str(home)])
        self.run_cli(
            ["scaffold", "apply", preset, "--target", str(project), "--home", str(home)]
        )
        return home, project

    def _insert_project_local_body(self, file_path: Path, body: str) -> str:
        """Replace the marker-bounded block in `file_path` with `body`.

        Returns the raw text written to disk so callers can assert against it.
        """
        text = file_path.read_text(encoding="utf-8")
        begin_idx = text.find(self.BEGIN)
        end_idx = text.find(self.END, begin_idx)
        assert begin_idx >= 0 and end_idx >= 0, "marker pair must be present"
        new_text = (
            text[: begin_idx + len(self.BEGIN)]
            + "\n"
            + body
            + "\n"
            + text[end_idx:]
        )
        file_path.write_text(new_text, encoding="utf-8")
        return new_text

    def test_router_templates_carry_marker_pair(self) -> None:
        """Both AGENTS.md and CLAUDE.md ship with the marker pair on fresh apply."""
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()
            self.run_cli(["rules", "install", "--home", str(home)])
            self.run_cli(
                ["scaffold", "apply", "redmine-rails", "--target", str(project), "--home", str(home)]
            )

            agents = (project / "AGENTS.md").read_text(encoding="utf-8")
            claude = (project / "CLAUDE.md").read_text(encoding="utf-8")
            for text in (agents, claude):
                self.assertIn(self.BEGIN, text)
                self.assertIn(self.END, text)

    def test_backup_apply_preserves_project_local_body(self) -> None:
        """--backup re-apply preserves project-local body inside the markers."""
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup(Path(tmp))
            project_local_body = (
                "## Project-Local Layer\n\n"
                "- Ruby 3.1.5 / Rails 7.0.8.1.\n"
                "- DB safety: TEST_DB_ENV=test must be set when running rspec.\n"
                "- Read-only docs directory: Doc/ (edit forbidden).\n"
            )
            agents_path = project / "AGENTS.md"
            claude_path = project / "CLAUDE.md"
            self._insert_project_local_body(agents_path, project_local_body)
            self._insert_project_local_body(
                claude_path, "## Project-Local Reminder\n\nRAILS_ENV=test is mandatory.\n"
            )

            result, _ = self.run_cli(
                [
                    "scaffold",
                    "apply",
                    "redmine-rails",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                    "--backup",
                ]
            )

            self.assertEqual(0, result)
            agents_after = agents_path.read_text(encoding="utf-8")
            claude_after = claude_path.read_text(encoding="utf-8")
            # Project-local body must survive re-apply, byte-for-byte.
            self.assertIn("Ruby 3.1.5 / Rails 7.0.8.1.", agents_after)
            self.assertIn("TEST_DB_ENV=test", agents_after)
            self.assertIn("Read-only docs directory: Doc/ (edit forbidden).", agents_after)
            self.assertIn("RAILS_ENV=test is mandatory.", claude_after)
            # Markers still present after re-apply.
            self.assertIn(self.BEGIN, agents_after)
            self.assertIn(self.END, agents_after)
            self.assertIn(self.BEGIN, claude_after)
            self.assertIn(self.END, claude_after)
            # .bak.<timestamp> files retain the pre-apply state as safety net.
            self.assertTrue(list(project.glob("AGENTS.md.bak.*")))
            self.assertTrue(list(project.glob("CLAUDE.md.bak.*")))

    def test_force_apply_preserves_project_local_body(self) -> None:
        """--force re-apply also preserves project-local body inside the markers."""
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup(Path(tmp))
            agents_path = project / "AGENTS.md"
            self._insert_project_local_body(
                agents_path, "- project-local addition that must survive --force.\n"
            )

            result, _ = self.run_cli(
                [
                    "scaffold",
                    "apply",
                    "redmine-rails",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                    "--force",
                ]
            )

            self.assertEqual(0, result)
            agents_after = agents_path.read_text(encoding="utf-8")
            self.assertIn("project-local addition that must survive --force.", agents_after)
            self.assertIn(self.BEGIN, agents_after)
            self.assertIn(self.END, agents_after)
            # --force does not produce a .bak.* file (this is the documented
            # difference between --force and --backup; preservation does not
            # change that).
            self.assertFalse(list(project.glob("AGENTS.md.bak.*")))

    def test_diff_is_clean_after_preserving_project_local_body(self) -> None:
        """scaffold diff returns clean (exit 0) once project-local body is inside markers.

        Once the operator has put their additions between the markers AND
        re-applied so the manifest records the post-substitution hash, a
        subsequent `scaffold diff` against the same preset version must not
        report any pending changes — the rendered router (with substituted
        project-local body) matches the on-disk router byte-for-byte.
        """
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup(Path(tmp))
            agents_path = project / "AGENTS.md"
            self._insert_project_local_body(
                agents_path, "- project-local fact preserved across re-sync.\n"
            )
            # Re-apply so the manifest records the post-substitution hash.
            self.run_cli(
                [
                    "scaffold",
                    "apply",
                    "redmine-rails",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                    "--backup",
                ]
            )

            result, output = self.run_cli(
                [
                    "scaffold",
                    "diff",
                    "redmine-rails",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                ]
            )

            self.assertEqual(0, result)
            self.assertIn("scaffold diff: clean", output)

    def test_preservation_skipped_when_markers_absent_on_disk(self) -> None:
        """Legacy on-disk routers without markers fall through unchanged.

        When the operator's AGENTS.md does NOT contain the marker pair (legacy
        scaffold or hand-edited content with markers removed), preservation
        does not fire — re-apply with `--force` overwrites the file with the
        fresh scaffold base, exactly as the existing safety contract intended.
        """
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup(Path(tmp))
            agents_path = project / "AGENTS.md"
            # Replace the file entirely with a legacy-style router that has
            # no marker pair.
            legacy_body = "# AGENTS (legacy)\n\n- no marker pair here.\n"
            agents_path.write_text(legacy_body, encoding="utf-8")

            result, _ = self.run_cli(
                [
                    "scaffold",
                    "apply",
                    "redmine-rails",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                    "--force",
                ]
            )

            self.assertEqual(0, result)
            agents_after = agents_path.read_text(encoding="utf-8")
            # Marker pair restored (fresh template).
            self.assertIn(self.BEGIN, agents_after)
            self.assertIn(self.END, agents_after)
            # Legacy body without markers is overwritten — no preservation
            # fallback for that case (operator must move content into markers
            # first, as documented in the preset's Apply Discipline section).
            self.assertNotIn("no marker pair here.", agents_after)

    def test_status_clean_after_preserving_body_and_reapplying(self) -> None:
        """scaffold status reports clean after preservation + re-apply cycle."""
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup(Path(tmp))
            self._insert_project_local_body(
                project / "AGENTS.md", "- project fact A\n- project fact B\n"
            )
            self._insert_project_local_body(
                project / "CLAUDE.md", "- claude reminder X\n"
            )
            self.run_cli(
                [
                    "scaffold",
                    "apply",
                    "redmine-rails",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                    "--backup",
                ]
            )

            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )

            self.assertEqual(0, result)
            self.assertIn("result: clean", output)

    def test_extract_and_substitute_helpers(self) -> None:
        """Unit-level coverage for the extract/substitute primitives."""
        from mozyo_bridge.scaffold.rules import (
            extract_project_local_block,
            substitute_project_local_block,
        )

        on_disk = (
            "header\n"
            + self.BEGIN
            + "\nproject additions\n"
            + self.END
            + "\ntrailer\n"
        )
        rendered = (
            "header\n"
            + self.BEGIN
            + "\nboilerplate\n"
            + self.END
            + "\ntrailer\n"
        )
        block = extract_project_local_block(on_disk)
        self.assertEqual("\nproject additions\n", block)
        new_rendered = substitute_project_local_block(rendered, block)
        self.assertIn("\nproject additions\n", new_rendered)
        self.assertNotIn("boilerplate", new_rendered)

        # Missing markers on either side returns/keeps the input unchanged.
        self.assertIsNone(extract_project_local_block("no markers here"))
        self.assertEqual(
            "no markers here",
            substitute_project_local_block("no markers here", "ignored"),
        )


class SharedSkillWorkflowTest(unittest.TestCase):
    """The shared mozyo-bridge-agent skill reference must carry the cross-system
    audit-owned commit policy so Codex behavior stays consistent across Asana
    and Redmine projects."""

    def setUp(self) -> None:
        self.workflow_path = (
            ROOT / "skills" / "mozyo-bridge-agent" / "references" / "workflow.md"
        )
        self.workflow = self.workflow_path.read_text(encoding="utf-8")

    def test_audit_owned_commit_section_present(self) -> None:
        # Section header and policy headline.
        self.assertIn("## Audit-Owned Commit Authority", self.workflow)
        # Cross-system boundary statement.
        self.assertIn("commit authority, not an implementation authority", self.workflow)
        self.assertIn("Codex direct implementation edit", self.workflow)
        self.assertIn("Codex audit-owned commit", self.workflow)

    def test_audit_owned_commit_has_preflight_steps(self) -> None:
        self.assertIn("git status", self.workflow)
        self.assertIn("git diff --cached --stat", self.workflow)
        self.assertIn("git add -A", self.workflow)
        # Per-system commit message reference contract.
        self.assertIn("Refs: Asana task <task_id>", self.workflow)
        self.assertIn("Audit: Asana comment <comment_id>", self.workflow)
        self.assertIn("Refs: Redmine #<issue_id>", self.workflow)
        self.assertIn("Journal: <journal_id>", self.workflow)
        # Commit hash must be recorded in the durable record, not pane chat.
        self.assertIn("Record the commit hash", self.workflow)

    def test_workflow_lifecycle_anchors_at_handoff_primitive(self) -> None:
        # Regression rail for Asana 1214760806178471: the Handoff Lifecycle
        # section must name the high-level primitive (`mozyo-bridge handoff
        # send` / `handoff reply` / top-level `reply` alias) as the standard
        # send. If a future refactor of the skill reference drops these names
        # in favor of caller-assembled `read` + `message` shell choreography,
        # this assertion catches it before agents start drifting back to the
        # old path. The presence of these names alongside the explicit
        # operator/debug paragraph also locks the boundary between standard
        # handoff and low-level primitives in a single section.
        section_start = self.workflow.index("## Handoff Lifecycle")
        section_end = self.workflow.index(
            "## Claude / Codex Role Boundary", section_start
        )
        section = self.workflow[section_start:section_end]
        self.assertIn("`mozyo-bridge handoff send`", section)
        self.assertIn("`mozyo-bridge handoff reply`", section)
        self.assertIn("`mozyo-bridge reply`", section)
        self.assertIn("compatibility", section)
        # The operator/debug paragraph must explicitly call out the low-level
        # commands so the boundary survives doc refactors.
        self.assertIn("`mozyo-bridge read`", section)
        self.assertIn("`mozyo-bridge message`", section)
        self.assertIn("operator/debug", section)
        self.assertIn("`notify-*-legacy-task`", section)
        # Receiver step must explicitly forbid scrollback / status / doctor
        # inference when a durable anchor exists; this is the rule that
        # collapsed in the failure modes recorded on Asana 1214760517082054.
        self.assertIn("`mozyo-bridge status`", section)
        self.assertIn("doctor", section)
        self.assertIn("pane scrollback", section)
        self.assertIn("durable", section)

    def test_audit_owned_commit_section_notes_owner_close_approval_separation(
        self,
    ) -> None:
        """The shared Audit-Owned Commit Authority section must call out that
        review approval is not the same as owner close approval on systems
        where the central preset distinguishes them. This keeps Redmine
        implementers from closing on review approval alone even when they
        only read the shared workflow reference and not the Redmine central
        preset directly.
        """
        section_start = self.workflow.index("## Audit-Owned Commit Authority")
        section_end = self.workflow.index(
            "## Workflow Change Verification", section_start
        )
        section = self.workflow[section_start:section_end]
        self.assertIn("owner close approval", section)
        self.assertIn("Review approval alone is not close approval", section)
        self.assertIn("Close Approval Separation", section)

    def test_audit_owned_commit_does_not_grant_direct_implementation(self) -> None:
        # The audit-owned commit section must NOT contain wording that could be
        # read as permission for Codex to write implementation diffs as part of
        # the commit step. We isolate the new section to keep this test from
        # tripping on the legitimate Codex direct-edit *exception* phrasing in
        # the Policy / Skill Authoring Boundary section.
        section_start = self.workflow.index("## Audit-Owned Commit Authority")
        section_end = self.workflow.index("## Workflow Change Verification", section_start)
        section = self.workflow[section_start:section_end]
        self.assertNotIn("Codex may edit", section)
        self.assertNotIn("Codex may implement", section)
        self.assertNotIn("Codex implements normal", section)
        # The section must explicitly preserve the prohibition on Codex
        # producing new diffs while granting the commit-only authority.
        self.assertIn("Codex must not edit implementation files", section)
        self.assertIn("commit authority, not an implementation authority", section)
        # The section must NOT silently waive the implementer / auditor
        # boundary defined elsewhere.
        self.assertIn("does not waive the implementer / auditor boundary", section)


class ScaffoldPresetHandoffPrimitiveDocsTest(unittest.TestCase):
    """Regression rails for Asana 1214760806178471: the scaffold presets must
    document the high-level handoff primitive as the standard handoff/reply
    path. If a future refactor accidentally restores the older "Standard
    notification command: `mozyo-bridge notify-* --issue --journal`" wording
    in either Asana or Redmine, or drops the explicit operator/debug boundary
    around `read` / `message` / `type` / `keys`, these tests catch it before
    operators install the drifted preset."""

    def setUp(self) -> None:
        presets_root = ROOT / "src" / "mozyo_bridge" / "scaffold" / "presets"
        self.asana_workflow = (presets_root / "asana" / "agent-workflow.md").read_text(
            encoding="utf-8"
        )
        self.redmine_workflow = (
            presets_root / "redmine" / "agent-workflow.md"
        ).read_text(encoding="utf-8")
        self.router_claude = (presets_root / "_router" / "CLAUDE.md").read_text(
            encoding="utf-8"
        )
        self.router_agents = (presets_root / "_router" / "AGENTS.md").read_text(
            encoding="utf-8"
        )
        self.redmine_rails_workflow = (
            presets_root / "redmine-rails" / "agent-workflow.md"
        ).read_text(encoding="utf-8")

    def test_asana_preset_standard_path_anchors_at_primitive(self) -> None:
        # Standard path bullet must name the high-level primitive.
        self.assertIn("**Standard path (required default)**", self.asana_workflow)
        self.assertIn("`mozyo-bridge handoff send", self.asana_workflow)
        self.assertIn("`mozyo-bridge handoff reply", self.asana_workflow)
        self.assertIn("`mozyo-bridge reply", self.asana_workflow)
        # `notify-*` are compatibility wrappers, not standard-path peers.
        self.assertIn("compatibility", self.asana_workflow)
        # `read` / `message` / `type` / `keys` are explicitly operator/debug.
        self.assertIn("operator/debug primitives", self.asana_workflow)
        # The retired-queue legacy notify wrapper must be cleanup-only.
        self.assertIn("`notify-*-legacy-task`", self.asana_workflow)

    def test_asana_preset_receiver_forbids_status_doctor_scrollback_inference(
        self,
    ) -> None:
        self.assertIn("`mozyo-bridge status`", self.asana_workflow)
        self.assertIn("`mozyo-bridge doctor`", self.asana_workflow)
        self.assertIn("pane scrollback", self.asana_workflow)
        self.assertIn("operator/debug aids", self.asana_workflow)

    def test_redmine_preset_pane_notification_anchors_at_primitive(self) -> None:
        # The Pane Notification section must name the primitive as the
        # standard command and the `notify-*` wrappers as compatibility.
        section_start = self.redmine_workflow.index("## Pane Notification")
        section_end = self.redmine_workflow.index(
            "## Handoff Startup Decision", section_start
        )
        section = self.redmine_workflow[section_start:section_end]
        self.assertIn("`mozyo-bridge handoff send", section)
        self.assertIn("`mozyo-bridge handoff reply", section)
        self.assertIn("`mozyo-bridge reply", section)
        self.assertIn("互換 entrypoint", section)
        self.assertIn("operator/debug primitives", section)
        self.assertNotIn(
            "Standard notification command: `mozyo-bridge notify-* --issue",
            section,
            msg="redmine preset still recommends the old notify-* shell as the standard",
        )
        # The retired-queue wrapper must be tagged cleanup-only here too.
        self.assertIn("retired-queue cleanup wrapper", section)

    def test_redmine_preset_handoff_startup_anchors_at_primitive(self) -> None:
        # The "Standard path" entry of the Handoff Startup Decision must
        # name the primitive, not the legacy notify-* shell.
        section_start = self.redmine_workflow.index("## Handoff Startup Decision")
        section_end = self.redmine_workflow.index(
            "## 実装者 / 監査者境界", section_start
        )
        section = self.redmine_workflow[section_start:section_end]
        # The Standard path bullet must lead with the primitive.
        self.assertIn("**Standard path**", section)
        self.assertIn("`mozyo-bridge handoff send", section)
        # `notify-*` must be described as compatibility, not the standard.
        self.assertIn("compatibility", section)

    def test_redmine_preset_receiver_forbids_status_doctor_scrollback_inference(
        self,
    ) -> None:
        # The Pane Notification section's recipient bullet must explicitly
        # forbid inferring receiver / issue state from status / doctor /
        # scrollback when a durable Redmine anchor exists.
        section_start = self.redmine_workflow.index("## Pane Notification")
        section_end = self.redmine_workflow.index(
            "## Handoff Startup Decision", section_start
        )
        section = self.redmine_workflow[section_start:section_end]
        self.assertIn("`mozyo-bridge status`", section)
        self.assertIn("`mozyo-bridge doctor`", section)
        self.assertIn("pane scrollback", section)
        self.assertIn("operator/debug aids", section)

    def test_shared_router_reminder_stays_thin_and_points_to_preset(self) -> None:
        self.assertIn("${rule_path}", self.router_claude)
        self.assertIn("${ticket_anchor_label}", self.router_claude)
        self.assertIn("handoff startup decision", self.router_claude)
        self.assertIn("operator/debug", self.router_claude)
        self.assertIn("`mozyo-bridge status`", self.router_claude)
        self.assertIn("`mozyo-bridge doctor`", self.router_claude)
        self.assertNotIn("`mozyo-bridge handoff send --to", self.router_claude)

    def test_shared_agents_router_stays_thin(self) -> None:
        self.assertIn("${rule_path}", self.router_agents)
        self.assertIn("${ticket_anchor_label}", self.router_agents)
        self.assertIn("router に本文を複製しない", self.router_agents)
        self.assertIn("operator/debug", self.router_agents)
        self.assertNotIn("Redmine Gate Lifecycle", self.router_agents)
        self.assertNotIn("Audit-Owned Commit Authority", self.router_agents)

    def test_router_templates_are_tool_specific_and_independent(self) -> None:
        """Generated AGENTS.md and CLAUDE.md must be independent tool-specific
        thin routers. CLAUDE.md must not import AGENTS.md (and vice versa) so
        each tool can read its own router as the standalone entry, and so a
        future refactor cannot accidentally restore the old shared-import
        layout where CLAUDE.md depended on AGENTS.md for session-start framing.
        """
        # No cross-import in either direction. The `@AGENTS.md` form is the
        # Claude Code-style file-import directive that previously made
        # CLAUDE.md depend on AGENTS.md for its session-start content.
        self.assertNotIn("@AGENTS.md", self.router_claude)
        self.assertNotIn("@CLAUDE.md", self.router_agents)
        # Each router announces its tool identity in the body so a reader (and
        # an auditor reading the rendered file) can see it stands alone.
        self.assertIn("Codex", self.router_agents)
        self.assertIn("tool-specific", self.router_agents)
        self.assertIn("import しない", self.router_agents)
        self.assertIn("Claude Code", self.router_claude)
        self.assertIn("tool-specific", self.router_claude)
        self.assertIn("import しない", self.router_claude)
        # Each router must independently reach the central preset and the
        # active ticket anchor without referencing the other file.
        for router in (self.router_agents, self.router_claude):
            self.assertIn("${rule_path}", router)
            self.assertIn("${ticket_anchor_label}", router)
        # Marker-bounded preservation must remain on both sides so project-
        # local additions survive re-sync after the tool-specific split.
        for router in (self.router_agents, self.router_claude):
            self.assertIn(
                "<!-- mozyo-bridge:project-local-additions:begin -->", router
            )
            self.assertIn(
                "<!-- mozyo-bridge:project-local-additions:end -->", router
            )

    def test_redmine_rails_preset_layers_on_redmine(self) -> None:
        self.assertIn("rules/presets/redmine/agent-workflow.md", self.redmine_rails_workflow)
        self.assertIn("Rails Design Consultation Triggers", self.redmine_rails_workflow)
        self.assertIn("Data / migration safety", self.redmine_rails_workflow)
        self.assertIn("Hotwire / UI behavior", self.redmine_rails_workflow)
        self.assertNotIn("/myapp/Source/rails", self.redmine_rails_workflow)

    def test_redmine_preset_separates_review_and_owner_close_approval(self) -> None:
        """Review Gate approval and owner close approval are distinct durable
        gates on Redmine projects, ported from Rails commit 8645c4d19.

        The reviewer (audit role / Codex equivalent) records `指摘事項なし` or
        re-review approval on the Review Gate journal, then must record a
        separate journal asking the owner whether close is permitted. The
        implementer must NOT close from review approval alone; it must wait
        for the owner close approval journal. The shared Redmine preset has
        to make all three responsibilities explicit so a future doc refactor
        cannot collapse them back into a single review-and-close gate.
        """
        # The dedicated section must exist.
        self.assertIn("## Close Approval Separation", self.redmine_workflow)

        # Section body must name the three responsibilities distinctly.
        section_start = self.redmine_workflow.index("## Close Approval Separation")
        section_end = self.redmine_workflow.index("## Close Gate Checklist", section_start)
        section = self.redmine_workflow[section_start:section_end]
        # Reviewer side: review approval is not close approval, and reviewer
        # has the post-approval owner-confirmation responsibility.
        self.assertIn("これだけで issue を close してはならない", section)
        self.assertIn("**別 journal**", section)
        self.assertIn("owner にクローズ可否を確認する", section)
        self.assertIn("レビュー結果と owner close approval を 1 journal にまとめない", section)
        # Implementer side: do not advance from review approval alone.
        self.assertIn("Review Gate approval だけで issue を close へ進めない", section)
        self.assertIn("owner の close approval journal を読み", section)
        # Collapsed-roles caveat preserves the record discipline.
        self.assertIn(
            "reviewer と owner を同一人物に collapse している場合でも", section
        )

        # Review Gate bullet must explicitly route the reviewer to the
        # separation section after a no-blockers verdict.
        review_gate = self.redmine_workflow[
            self.redmine_workflow.index("7. **Review Gate**") :
            self.redmine_workflow.index("8. **QA Verification Gate**")
        ]
        self.assertIn("これは close approval ではない", review_gate)
        self.assertIn("owner にクローズ可否を確認する責務", review_gate)
        self.assertIn("Close Approval Separation", review_gate)

        # Close Gate bullet must name owner close approval as separate from
        # Review Gate, not just "owner approval".
        close_gate = self.redmine_workflow[
            self.redmine_workflow.index("10. **Close Gate**") :
            self.redmine_workflow.index("\n\nproject 固有 status / tracker")
        ]
        self.assertIn("owner close approval", close_gate)
        self.assertIn("Review Gate とは別 journal", close_gate)
        self.assertIn(
            "passing Review Gate、owner close approval、commit hash record の三つが揃うまで",
            close_gate,
        )

        # Close Gate Checklist must add a dedicated bullet for the owner
        # close approval journal so a future Close Gate cannot be "passed"
        # against only the Review Gate.
        checklist_start = self.redmine_workflow.index("## Close Gate Checklist")
        checklist_end = self.redmine_workflow.index("## Pane Notification", checklist_start)
        checklist = self.redmine_workflow[checklist_start:checklist_end]
        self.assertIn(
            "**owner close approval** が Review Gate とは別 journal として記録されている",
            checklist,
        )
        self.assertIn("Review Gate approval だけで checklist を満たさない", checklist)

        # Completion section must tell the implementer to wait for the owner
        # close approval journal — review approval alone does not advance to
        # close.
        completion_start = self.redmine_workflow.index("## Completion")
        completion_end = self.redmine_workflow.index("## Audit-Owned Commit Authority", completion_start)
        completion = self.redmine_workflow[completion_start:completion_end]
        self.assertIn(
            "Review Gate approval を owner close approval と読み替えない",
            completion,
        )
        self.assertIn("owner close approval journal が記録されてから close へ進む", completion)

    def test_asana_completion_section_has_no_duplicate_numbered_steps(self) -> None:
        """Asana preset Completion section must be a contiguous 1..N numbered
        list with no duplicate numbers and no duplicate body text. A prior
        generated/rendered output exhibited a duplicated completion
        requirement line, and a regression here would re-introduce the same
        ambiguity for any downstream Asana project.
        """
        section_start = self.asana_workflow.index("## Completion")
        section_end = self.asana_workflow.index("## Audit-Owned Commit Authority", section_start)
        section = self.asana_workflow[section_start:section_end]

        numbered = re.findall(r"^(\d+)\.\s+(.+)$", section, flags=re.MULTILINE)
        self.assertGreaterEqual(
            len(numbered),
            3,
            msg=f"Completion section should contain a numbered list; got {numbered!r}",
        )
        # Contiguous 1..N, no duplicate numeric prefix.
        numbers = [int(num) for num, _ in numbered]
        self.assertEqual(
            numbers,
            list(range(1, len(numbers) + 1)),
            msg=(
                "Completion numbered list must be contiguous 1..N with no "
                f"duplicate numeric prefix; got {numbers!r}"
            ),
        )
        # No body appears twice (catches a duplicated completion requirement
        # line even if it were renumbered to keep the list "contiguous").
        bodies = [body.strip() for _, body in numbered]
        duplicates = [body for body in bodies if bodies.count(body) > 1]
        self.assertEqual(
            duplicates,
            [],
            msg=(
                "Completion section contains duplicate body text: "
                f"{duplicates!r}"
            ),
        )
        # Defensive: no two consecutive bodies are identical (cheaper to
        # catch if a future edit accidentally pastes the same line twice
        # in adjacent steps).
        for i in range(1, len(bodies)):
            self.assertNotEqual(
                bodies[i],
                bodies[i - 1],
                msg=(
                    f"Completion step {i + 1} duplicates the previous step "
                    f"body verbatim: {bodies[i]!r}"
                ),
            )


class ScaffoldStatusTest(unittest.TestCase):
    def run_cli(self, argv: list[str]) -> tuple[int, str]:
        parser = build_parser()
        args = parser.parse_args(argv)
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            result = args.func(args)
        return result, stdout.getvalue()

    def _setup_scaffold(self, tmp: Path, preset: str = "redmine") -> tuple[Path, Path]:
        home = tmp / "home"
        project = tmp / "project"
        project.mkdir()
        self.run_cli(["rules", "install", "--home", str(home)])
        self.run_cli(["scaffold", "apply", preset, "--target", str(project), "--home", str(home)])
        return home, project

    def test_manifest_records_preset_hash_and_schema_v2(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp), "redmine")
            state = scaffold_state(project)
            self.assertIsNotNone(state)
            assert state is not None
            self.assertEqual(2, state["schema_version"])
            workflow = home / "rules" / "presets" / "redmine" / "agent-workflow.md"
            expected_hash = hashlib.sha256(workflow.read_bytes()).hexdigest()
            self.assertEqual(expected_hash, state["preset_hash"])
            self.assertIn("AGENTS.md", state["files"])
            self.assertIn("sha256", state["files"]["AGENTS.md"])

    def test_scaffold_status_reports_clean_after_fresh_scaffold(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(0, result)
            self.assertIn("manifest: present", output)
            self.assertIn("central status: ok", output)
            self.assertIn("result: clean", output)

    def test_scaffold_status_reports_clean_after_fresh_asana_scaffold(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp), preset="asana")
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(0, result)
            self.assertIn("manifest: present", output)
            self.assertIn("central status: ok", output)
            self.assertIn("result: clean", output)

    def test_scaffold_status_detects_central_preset_content_drift(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            workflow = home / "rules" / "presets" / "redmine" / "agent-workflow.md"
            workflow.write_text(
                workflow.read_text(encoding="utf-8") + "\n# tampered\n", encoding="utf-8"
            )
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(1, result)
            self.assertIn("central status: drifted-content", output)
            self.assertIn("result: drift detected", output)
            self.assertIn("central preset content has changed", output)

    def test_scaffold_status_detects_router_drift(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            agents_path = project / "AGENTS.md"
            agents_path.write_text(
                agents_path.read_text(encoding="utf-8") + "\nlocal edit\n", encoding="utf-8"
            )
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(1, result)
            self.assertIn("AGENTS.md: drifted", output)
            self.assertIn("router AGENTS.md was modified locally", output)

    def test_scaffold_status_reports_missing_central_preset(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            preset_dir = home / "rules" / "presets" / "redmine"
            shutil.rmtree(preset_dir)
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(1, result)
            self.assertIn("central status: missing", output)
            self.assertIn("`mozyo-bridge rules install`", output)

    def test_scaffold_status_reports_missing_extended_base_preset(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp), preset="redmine-rails")
            shutil.rmtree(home / "rules" / "presets" / "redmine")

            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )

            self.assertEqual(1, result)
            self.assertIn("preset: redmine-rails", output)
            self.assertIn("central status: missing", output)
            self.assertIn("`mozyo-bridge rules install`", output)

    def test_scaffold_refuses_when_extended_base_preset_is_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            project = Path(tmp) / "project"
            project.mkdir()
            self.run_cli(["rules", "install", "--home", str(home)])
            shutil.rmtree(home / "rules" / "presets" / "redmine")

            with contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    self.run_cli(
                        [
                            "scaffold",
                            "apply",
                            "redmine-rails",
                            "--target",
                            str(project),
                            "--home",
                            str(home),
                        ]
                    )

            self.assertIn("rules preset is not installed: redmine", stderr.getvalue())

    def test_scaffold_status_reports_missing_manifest_for_empty_project(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            empty = Path(tmp) / "empty"
            empty.mkdir()
            home = Path(tmp) / "home"
            self.run_cli(["rules", "install", "--home", str(home)])
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(empty), "--home", str(home)]
            )
            self.assertEqual(1, result)
            self.assertIn("manifest: missing", output)
            self.assertIn("no scaffold manifest", output)

    def test_scaffold_status_handles_schema_v1_manifest_gracefully(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            manifest_path = project / ".mozyo-bridge" / "scaffold.json"
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            # Simulate a manifest written by a pre-hash version of the scaffolder.
            data["schema_version"] = 1
            data.pop("preset_hash", None)
            manifest_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            # Same version + no hash means we can't prove content drift, but the
            # known router hashes still verify; treat as drift so the user upgrades.
            self.assertEqual(1, result)
            self.assertIn("central status: ok-version-only", output)
            self.assertIn("schema v1 (no preset_hash)", output)

    def test_scaffold_status_reports_invalid_manifest_on_bad_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            manifest_path = project / ".mozyo-bridge" / "scaffold.json"
            manifest_path.write_text("{bad json", encoding="utf-8")
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(1, result)
            self.assertIn("manifest: invalid", output)
            self.assertIn("manifest is not valid JSON", output)

    def test_scaffold_status_json_output_for_invalid_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            manifest_path = project / ".mozyo-bridge" / "scaffold.json"
            manifest_path.write_text("{bad json", encoding="utf-8")
            result, output = self.run_cli(
                [
                    "scaffold",
                    "status",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                    "--json",
                ]
            )
            self.assertEqual(1, result)
            payload = json.loads(output)
            self.assertEqual("invalid", payload["manifest"])
            self.assertFalse(payload["clean"])
            self.assertIn("error", payload)

    def test_scaffold_status_rejects_schema_v2_manifest_with_missing_router_entries(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            manifest_path = project / ".mozyo-bridge" / "scaffold.json"
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            data["files"] = {}
            manifest_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(1, result)
            self.assertIn("manifest: invalid", output)
            self.assertIn("schema v2 manifest is missing router hash entries", output)
            self.assertIn("AGENTS.md", output)
            self.assertIn("CLAUDE.md", output)

    def test_scaffold_status_rejects_schema_v2_manifest_with_partial_router_entries(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            manifest_path = project / ".mozyo-bridge" / "scaffold.json"
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            data["files"].pop("CLAUDE.md", None)
            manifest_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            result, output = self.run_cli(
                ["scaffold", "status", "--target", str(project), "--home", str(home)]
            )
            self.assertEqual(1, result)
            self.assertIn("manifest: invalid", output)
            self.assertIn("CLAUDE.md", output)
            self.assertNotIn("result: clean", output)

    def test_scaffold_status_json_output(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home, project = self._setup_scaffold(Path(tmp))
            result, output = self.run_cli(
                [
                    "scaffold",
                    "status",
                    "--target",
                    str(project),
                    "--home",
                    str(home),
                    "--json",
                ]
            )
            self.assertEqual(0, result)
            payload = json.loads(output)
            self.assertTrue(payload["clean"])
            self.assertEqual("redmine", payload["preset"])
            self.assertEqual(2, payload["schema_version"])
            self.assertEqual("ok", payload["central_status"])
            self.assertEqual(
                payload["manifest_preset_hash"], payload["installed_preset_hash"]
            )


class NotifyContractTest(unittest.TestCase):
    def run_notify_with_fake_tmux(
        self,
        argv: list[str],
        captures: list[str] | None = None,
        allow_exit: bool = False,
    ):
        parser = build_parser()
        args = parser.parse_args(argv)
        sent: list[tuple[str, ...]] = []
        pane_text = ""
        forced_captures = captures is not None
        capture_outputs = list(captures or [])

        def fake_capture(_target: str, _lines: int) -> str:
            if capture_outputs:
                return capture_outputs.pop(0)
            if forced_captures:
                return ""
            return pane_text

        def fake_run_tmux(*tmux_args: str, check: bool = True):
            nonlocal pane_text
            if tmux_args[:4] == ("send-keys", "-t", "%2", "-l"):
                text = tmux_args[-1]
                pane_text += text
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            if tmux_args[:3] == ("send-keys", "-t", "%2"):
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            raise AssertionError(f"unexpected tmux call: {tmux_args}")

        pane = {"id": "%2", "location": "agents:0.1", "command": "node", "cwd": "/repo", "window_name": "codex", "pane_active": "1"}

        # v0.4: the standard notify wrappers default to `--mode queue-enter`,
        # so the Layer B preflight runs. Patch `current_session_name` so the
        # Step 10 same-session binding can compare sender vs target without
        # invoking real tmux.
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.current_pane", return_value="%1"), \
            patch("mozyo_bridge.application.commands.current_session_name", return_value="agents"), \
            patch("mozyo_bridge.application.commands.pane_window_name", return_value="claude"), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:0.0"), \
            patch("mozyo_bridge.application.commands.capture_pane", side_effect=fake_capture), \
            patch("mozyo_bridge.application.commands.run_tmux", side_effect=fake_run_tmux), \
            patch("mozyo_bridge.application.commands.time.sleep"), \
            patch("mozyo_bridge.domain.pane_resolver.validate_target"), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=[pane]), \
            contextlib.redirect_stdout(io.StringIO()) as stdout:
            try:
                result = args.func(args)
            except SystemExit as exc:
                if not allow_exit:
                    raise
                result = exc

        return result, sent, stdout.getvalue(), pane_text

    def test_notify_by_journal_types_observed_text_then_submits(self) -> None:
        # `notify-codex` is a thin wrapper over the new handoff primitive
        # (Codex audit: `1214760803593547`). The marker and body shape come
        # from `mozyo_bridge.domain.handoff`; the legacy `[mozyo:notify:...]`
        # marker is reserved for the legacy queue subcommands. v0.4: the
        # standard notify wrappers default to `--mode queue-enter`, so the
        # Layer B preflight admits the send under the fake's codex pane.
        result, sent, stdout, pane_text = self.run_notify_with_fake_tmux(
            [
                "notify-codex",
                "--issue",
                "9020",
                "--journal",
                "46005",
                "--type",
                "review_request",
                "--target",
                "%2",
                "--submit-delay",
                "0",
            ]
        )

        self.assertEqual(0, result)
        self.assertIn(
            "[mozyo:handoff:source=redmine:issue=9020:journal=46005:kind=review_request:to=codex]",
            pane_text,
        )
        self.assertIn("review request ready for codex", pane_text)
        self.assertIn("Redmine #9020 journal #46005", pane_text)
        outcome_lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertTrue(outcome_lines)
        outcome = json.loads(outcome_lines[-1])
        self.assertEqual("sent", outcome["status"])
        self.assertEqual("redmine", outcome["source"])
        self.assertEqual("review_request", outcome["kind"])
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])

    def test_legacy_task_notification_uses_separate_contract(self) -> None:
        task = {"id": "legacy-task", "issue_id": 9596, "commit": "abc123", "type": "design_consultation_result"}
        with patch("mozyo_bridge.application.commands.find_handoff_task", return_value=task) as find_task:
            result, _sent, _stdout, pane_text = self.run_notify_with_fake_tmux(
                [
                    "notify-claude-legacy-task",
                    "--issue",
                    "9596",
                    "--task-id",
                    "legacy-task",
                    "--type",
                    "design_consultation_result",
                    "--target",
                    "%2",
                    "--force",
                    "--submit-delay",
                    "0",
                ]
            )

        self.assertEqual(0, result)
        find_task.assert_called_once()
        self.assertIn("[mozyo:notify:task=legacy-task:issue=9596]", pane_text)
        self.assertIn("handoff task legacy-task is ready for claude", pane_text)
        self.assertIn("legacy queue fallback", pane_text)

    def test_legacy_task_notification_does_not_emit_structured_outcome(self) -> None:
        # Regression rail for the handoff-primitive split (Asana 1214760806178471):
        # `notify-*-legacy-task` is the retired-queue cleanup wrapper and must
        # NOT route through `orchestrate_handoff`. It therefore must not emit
        # the structured JSON outcome line nor the markdown delivery record,
        # because callers of the legacy wrapper have no durable Asana / Redmine
        # anchor to anchor that record at. If a future refactor accidentally
        # unifies the legacy queue path with the standard primitive, callers
        # would start seeing structured-outcome bytes that name a stale queue
        # task as the anchor.
        task = {"id": "legacy-task", "issue_id": 9596, "commit": "abc123", "type": "design_consultation_result"}
        with patch("mozyo_bridge.application.commands.find_handoff_task", return_value=task):
            result, _sent, stdout, _pane_text = self.run_notify_with_fake_tmux(
                [
                    "notify-claude-legacy-task",
                    "--issue",
                    "9596",
                    "--task-id",
                    "legacy-task",
                    "--type",
                    "design_consultation_result",
                    "--target",
                    "%2",
                    "--force",
                    "--submit-delay",
                    "0",
                ]
            )

        self.assertEqual(0, result)
        outcome_lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertEqual([], outcome_lines, msg=f"legacy wrapper emitted structured outcome: {stdout!r}")
        self.assertNotIn("Delivery result —", stdout)
        self.assertNotIn("Durable anchor:", stdout)
        self.assertNotIn("`receiver`", stdout)

    def test_notify_submits_under_queue_enter_default_even_when_marker_missed(
        self,
    ) -> None:
        # v0.4 contract pivot (Asana 1214824751741628): the standard notify
        # wrappers default to `--mode queue-enter`, so marker miss must NOT
        # roll back — Enter is issued and the durable outcome is `sent` /
        # `queue_enter`. Strict-rail rollback on marker miss is still covered
        # by `RelaxedQueueEnterRailTest.test_strict_standard_still_rolls_back_on_marker_timeout`;
        # notify-* wrappers cannot opt into strict by design (no `--mode` flag
        # is exposed on them).
        result, sent, stdout, _pane_text = self.run_notify_with_fake_tmux(
            [
                "notify-codex",
                "--issue",
                "9020",
                "--journal",
                "46005",
                "--target",
                "%2",
                "--landing-timeout",
                "0.01",
                "--submit-delay",
                "0",
            ],
            captures=["", "", ""],
        )

        self.assertEqual(0, result)
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "C-u") for call in sent))
        outcome_lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertTrue(outcome_lines)
        outcome = json.loads(outcome_lines[-1])
        self.assertEqual("sent", outcome["status"])
        self.assertEqual("queue_enter", outcome["reason"])
        self.assertEqual("queue-enter", outcome["mode"])
        self.assertEqual("redmine", outcome["source"])

    def test_notify_submit_delay_default_is_classic_short_tui_delay(self) -> None:
        parser = build_parser()
        args = parser.parse_args(["notify-codex", "--issue", "9020", "--journal", "1"])

        self.assertEqual(0.2, args.submit_delay)

    def test_standard_notify_wrapper_preserves_legacy_success_line(self) -> None:
        # Codex audit finding 1 on task 1214760547941073: the wrapper must
        # keep printing `notified <agent>: journal=... target=... read_lines=...`
        # so the in-repo smoke and external scripts that grep that line
        # continue to work after the handoff-primitive retrofit. v0.4: the
        # notify wrappers default to queue-enter; the legacy success line is
        # still printed when the Layer B preflight admits and Enter is sent.
        result, _sent, stdout, _pane_text = self.run_notify_with_fake_tmux(
            [
                "notify-codex",
                "--issue",
                "9020",
                "--journal",
                "46005",
                "--type",
                "review_request",
                "--target",
                "%2",
                "--submit-delay",
                "0",
            ]
        )

        self.assertEqual(0, result)
        self.assertIn("notified codex: journal=46005 target=%2 read_lines=20", stdout)

    def test_standard_notify_wrapper_omits_success_line_on_failure(self) -> None:
        # The legacy success line is a courtesy that must only fire on real
        # success. v0.4 routes the standard notify wrappers through
        # `--mode queue-enter`, which rejects `--force` before any typing;
        # the wrapper must not have printed `notified codex: ...` before the
        # forced exit. Pre-v0.4 this test exercised the strict-rail
        # marker_timeout path; the success-line invariant is the same under
        # any wrapper failure, so we keep the regression on the new path.
        with contextlib.redirect_stderr(io.StringIO()):
            result, _sent, stdout, _pane_text = self.run_notify_with_fake_tmux(
                [
                    "notify-codex",
                    "--issue",
                    "9020",
                    "--journal",
                    "46005",
                    "--target",
                    "%2",
                    "--force",
                    "--landing-timeout",
                    "0.01",
                    "--submit-delay",
                    "0",
                ],
                captures=["", "", ""],
                allow_exit=True,
            )

        self.assertIsInstance(result, SystemExit)
        self.assertNotIn("notified codex:", stdout)

    def test_standard_notify_accepts_record_format_json(self) -> None:
        # Codex audit finding 2 on task 1214760547941073: the wrapper parser
        # must accept the same --record-format / --record-command knobs as
        # `handoff send/reply`, so callers using the compatibility wrapper
        # can still ask for json-only output.
        parser = build_parser()

        args = parser.parse_args(
            [
                "notify-codex",
                "--issue",
                "9020",
                "--journal",
                "1",
                "--record-format",
                "json",
            ]
        )

        self.assertEqual("json", args.record_format)

    def test_standard_notify_record_format_json_suppresses_record(self) -> None:
        # End-to-end through the wrapper: --record-format json suppresses
        # the markdown block but keeps the JSON outcome and the legacy
        # success line. v0.4: notify wrappers default to queue-enter; the
        # fake fixture passes Layer B preflight so Enter is issued and the
        # legacy success line still fires.
        result, _sent, stdout, _pane_text = self.run_notify_with_fake_tmux(
            [
                "notify-codex",
                "--issue",
                "9020",
                "--journal",
                "46005",
                "--type",
                "review_request",
                "--target",
                "%2",
                "--submit-delay",
                "0",
                "--record-format",
                "json",
            ]
        )

        self.assertEqual(0, result)
        self.assertNotIn("Delivery result —", stdout)
        self.assertIn("notified codex: journal=46005", stdout)
        json_lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertEqual(1, len(json_lines))

    def test_notify_review_wrapper_accepts_record_command(self) -> None:
        # --record-command flows through the review wrappers too (issue
        # required path). End-to-end: the record block shows the literal
        # command and the legacy success line still fires. v0.4: review
        # wrappers default to queue-enter; the fake fixture passes Layer B
        # preflight.
        result, _sent, stdout, _pane_text = self.run_notify_with_fake_tmux(
            [
                "notify-codex-review",
                "--issue",
                "9020",
                "--journal",
                "46005",
                "--target",
                "%2",
                "--submit-delay",
                "0",
                "--record-command",
                "mozyo-bridge notify-codex-review --issue 9020 --journal 46005",
            ]
        )

        self.assertEqual(0, result)
        self.assertIn(
            "- Command: `mozyo-bridge notify-codex-review --issue 9020 --journal 46005`",
            stdout,
        )
        self.assertIn("notified codex: journal=46005", stdout)


class MessageContractTest(unittest.TestCase):
    def run_message_with_fake_tmux(
        self,
        argv: list[str],
        captures: list[str] | None = None,
        allow_exit: bool = False,
    ):
        parser = build_parser()
        args = parser.parse_args(argv)
        sent: list[tuple[str, ...]] = []
        pane_text = ""
        forced_captures = captures is not None
        capture_outputs = list(captures or [])

        def fake_capture(_target: str, _lines: int) -> str:
            if capture_outputs:
                return capture_outputs.pop(0)
            if forced_captures:
                return ""
            return pane_text

        def fake_run_tmux(*tmux_args: str, check: bool = True):
            nonlocal pane_text
            if tmux_args[:4] == ("send-keys", "-t", "%2", "-l"):
                pane_text += tmux_args[-1]
            sent.append(tmux_args)
            return argparse.Namespace(returncode=0, stdout="", stderr="")

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.require_read"), \
            patch("mozyo_bridge.application.commands.clear_read"), \
            patch("mozyo_bridge.application.commands.resolve_target", return_value="%2"), \
            patch("mozyo_bridge.application.commands.current_pane", return_value="%1"), \
            patch("mozyo_bridge.application.commands.pane_window_name", return_value="codex"), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:0.0"), \
            patch("mozyo_bridge.application.commands.capture_pane", side_effect=fake_capture), \
            patch("mozyo_bridge.application.commands.run_tmux", side_effect=fake_run_tmux), \
            patch("mozyo_bridge.application.commands.time.sleep") as sleep, \
            contextlib.redirect_stdout(io.StringIO()):
            try:
                result = args.func(args)
            except SystemExit as exc:
                if not allow_exit:
                    raise
                result = exc

        return result, sent, pane_text, sleep

    def test_message_submits_enter_after_marker_by_default(self) -> None:
        result, sent, pane_text, _sleep = self.run_message_with_fake_tmux(
            ["message", "%2", "hello body", "--submit-delay", "0"]
        )

        self.assertEqual(0, result)
        self.assertIn("[mozyo-bridge from:codex pane:%1 at:agents:0.0]", pane_text)
        self.assertIn("hello body", pane_text)
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "C-u") for call in sent))

    def test_message_no_submit_leaves_input_pending(self) -> None:
        result, sent, pane_text, _sleep = self.run_message_with_fake_tmux(
            ["message", "%2", "pending body", "--no-submit"]
        )

        self.assertEqual(0, result)
        self.assertIn("pending body", pane_text)
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "Enter") for call in sent))
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "C-u") for call in sent))

    def test_message_rolls_back_when_marker_is_not_observed(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            result, sent, _pane_text, _sleep = self.run_message_with_fake_tmux(
                [
                    "message",
                    "%2",
                    "lost body",
                    "--landing-timeout",
                    "0.01",
                    "--submit-delay",
                    "0",
                ],
                captures=["", "", ""],
                allow_exit=True,
            )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "Enter") for call in sent))
        self.assertIn(("send-keys", "-t", "%2", "C-u"), sent)

    def test_message_waits_submit_delay_after_marker(self) -> None:
        _result, _sent, _pane_text, sleep = self.run_message_with_fake_tmux(
            ["message", "%2", "delayed body", "--submit-delay", "0.2"]
        )

        sleep.assert_called_once_with(0.2)

    def test_message_submit_defaults_to_true(self) -> None:
        parser = build_parser()
        args = parser.parse_args(["message", "%2", "hi"])

        self.assertTrue(args.submit)
        self.assertEqual(0.2, args.submit_delay)
        self.assertEqual(5.0, args.landing_timeout)

    def test_message_submits_enter_when_marker_wraps_in_capture(self) -> None:
        # Receiver TUI (codex / claude code) word-wraps long input at the
        # visible pane width, inserting a literal newline + continuation
        # indent inside the marker. capture-pane -J cannot rejoin these
        # (the wrap is TUI-emitted, not tmux-display-wrap), so a raw
        # `marker in capture` search misses it. The landing gate must
        # still observe the marker and proceed to Enter.
        wrapped_capture = (
            "› [mozyo-bridge from:codex pane:%1\n"
            "  at:agents:0.0] hello body\n"
        )
        result, sent, _pane_text, _sleep = self.run_message_with_fake_tmux(
            ["message", "%2", "hello body", "--submit-delay", "0"],
            captures=[wrapped_capture],
        )

        self.assertEqual(0, result)
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "C-u") for call in sent))

    def test_message_still_rolls_back_when_capture_lacks_marker(self) -> None:
        # Safety lock: even after wrap-tolerant normalization, a capture
        # that does not actually contain the marker must trigger C-u
        # rollback and skip Enter. Fail-closed is non-negotiable.
        unrelated_capture = "› unrelated placeholder\n  with continuation indent\n"
        with contextlib.redirect_stderr(io.StringIO()):
            result, sent, _pane_text, _sleep = self.run_message_with_fake_tmux(
                [
                    "message",
                    "%2",
                    "lost body",
                    "--landing-timeout",
                    "0.01",
                    "--submit-delay",
                    "0",
                ],
                captures=[unrelated_capture, unrelated_capture, unrelated_capture],
                allow_exit=True,
            )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "Enter") for call in sent))
        self.assertIn(("send-keys", "-t", "%2", "C-u"), sent)


class MessageGateGuidanceTest(unittest.TestCase):
    """Regression coverage for Asana task 1214779823377861.

    The CLI must emit a structured stderr trailer after `mozyo-bridge message`
    read-marker / marker-observation gate failures so agents see the literal
    retry path and the per-preset `--no-submit` retry budget. Without this
    trailer, agents have been observed conflating the `--no-submit` budget
    with the `handoff send` retry pool and jumping straight to the preset's
    `Notification fails` branch after a single transient failure (see Asana
    task 1214774670696760 comment 1214778979254677 for the failure example).
    """

    def _run_message_with_gate_failure(
        self,
        argv: list[str],
        *,
        require_read_side_effect=None,
        suppress_marker_in_capture: bool = False,
    ):
        parser = build_parser()
        args = parser.parse_args(argv)
        sent: list[tuple[str, ...]] = []
        pane_text = ""

        def fake_capture(_target: str, _lines: int) -> str:
            # When the test exercises the wait_for_text rollback path, the
            # capture must not echo the typed marker even though
            # `fake_run_tmux` accumulates it into `pane_text`. Otherwise the
            # gate would observe the marker (because the marker is in
            # `pane_text`) and the rollback branch never fires.
            if suppress_marker_in_capture:
                return ""
            return pane_text

        def fake_run_tmux(*tmux_args: str, check: bool = True):
            nonlocal pane_text
            if tmux_args[:4] == ("send-keys", "-t", "%2", "-l"):
                pane_text += tmux_args[-1]
            sent.append(tmux_args)
            return argparse.Namespace(returncode=0, stdout="", stderr="")

        require_read_patch = (
            patch(
                "mozyo_bridge.application.commands.require_read",
                side_effect=require_read_side_effect,
            )
            if require_read_side_effect is not None
            else patch("mozyo_bridge.application.commands.require_read")
        )

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            require_read_patch, \
            patch("mozyo_bridge.application.commands.clear_read"), \
            patch("mozyo_bridge.application.commands.resolve_target", return_value="%2"), \
            patch("mozyo_bridge.application.commands.current_pane", return_value="%1"), \
            patch("mozyo_bridge.application.commands.pane_window_name", return_value="codex"), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:0.0"), \
            patch("mozyo_bridge.application.commands.capture_pane", side_effect=fake_capture), \
            patch("mozyo_bridge.application.commands.run_tmux", side_effect=fake_run_tmux), \
            patch("mozyo_bridge.application.commands.time.sleep"), \
            contextlib.redirect_stdout(io.StringIO()), \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            try:
                result = args.func(args)
            except SystemExit as exc:
                result = exc

        return result, sent, stderr.getvalue()

    def test_no_submit_read_marker_failure_emits_retry_path_and_budget(self) -> None:
        # require_read dies with the literal next-action verb ("read target
        # again before interacting"). The CLI must augment stderr with an
        # explicit retry path and the per-preset --no-submit budget so the
        # agent does not need to pattern-match from memory (failure mode #1 in
        # the task body).
        result, _sent, stderr = self._run_message_with_gate_failure(
            ["message", "%2", "pending body", "--no-submit"],
            require_read_side_effect=SystemExit(2),
        )

        self.assertIsInstance(result, SystemExit)
        self.assertIn("hint: retry path:", stderr)
        self.assertIn("mozyo-bridge read %2", stderr)
        self.assertIn("--no-submit retry budget", stderr)
        # The base preset cap is 3; if this assertion ever fails, double-check
        # NO_SUBMIT_RETRY_BUDGET in domain/handoff.py and update the preset
        # `Notification fails` branch in lockstep.
        self.assertIn("3", stderr)
        self.assertIn(
            "handoff send",
            stderr,
            "stderr must name the `handoff send` pool to prevent budget conflation (failure mode #2 in task 1214779823377861)",
        )

    def test_no_submit_read_marker_failure_with_attempt_reports_remaining(
        self,
    ) -> None:
        # --attempt N parameterizes the budget reporting so the agent knows
        # exactly how many --no-submit retries remain. Operator-tracked
        # because the CLI is stateless across invocations.
        result, _sent, stderr = self._run_message_with_gate_failure(
            [
                "message",
                "%2",
                "pending body",
                "--no-submit",
                "--attempt",
                "2",
            ],
            require_read_side_effect=SystemExit(2),
        )

        self.assertIsInstance(result, SystemExit)
        self.assertIn("attempt 2/3 just failed", stderr)
        self.assertIn("1/3 attempts remaining", stderr)

    def test_submit_marker_timeout_still_rolls_back_and_emits_guidance(
        self,
    ) -> None:
        # Safety-gate regression: the existing fail-closed contract (no Enter
        # when marker is not observed; C-u rollback) must remain intact, and
        # the new guidance trailer must fire alongside it. This is the test
        # for failure mode #3 in the task body ("Notification fails" used as
        # escape hatch after transient failure).
        result, sent, stderr = self._run_message_with_gate_failure(
            [
                "message",
                "%2",
                "lost body",
                "--landing-timeout",
                "0.01",
                "--submit-delay",
                "0",
            ],
            suppress_marker_in_capture=True,
        )

        self.assertIsInstance(result, SystemExit)
        # Fail-closed contract: Enter not pressed, C-u issued.
        self.assertFalse(
            any(call == ("send-keys", "-t", "%2", "Enter") for call in sent)
        )
        self.assertIn(("send-keys", "-t", "%2", "C-u"), sent)
        # New trailer present.
        self.assertIn("hint: retry path:", stderr)
        self.assertIn("mozyo-bridge read %2", stderr)
        # In default (submit) mode no --no-submit budget trailer is emitted —
        # `--no-submit` was not requested. The retry-path line is enough; the
        # budget line is gated on --no-submit so we do not over-promise a
        # budget that does not apply here.
        self.assertNotIn("--no-submit retry budget:", stderr)

    def test_no_submit_message_happy_path_emits_no_gate_guidance(self) -> None:
        # Anti-regression: the trailer must NOT fire when require_read
        # succeeds. The happy path must remain silent on stderr.
        parser = build_parser()
        args = parser.parse_args(["message", "%2", "ok body", "--no-submit"])
        sent: list[tuple[str, ...]] = []

        def fake_run_tmux(*tmux_args: str, check: bool = True):
            sent.append(tmux_args)
            return argparse.Namespace(returncode=0, stdout="", stderr="")

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.require_read"), \
            patch("mozyo_bridge.application.commands.clear_read"), \
            patch("mozyo_bridge.application.commands.resolve_target", return_value="%2"), \
            patch("mozyo_bridge.application.commands.current_pane", return_value="%1"), \
            patch("mozyo_bridge.application.commands.pane_window_name", return_value="codex"), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:0.0"), \
            patch("mozyo_bridge.application.commands.capture_pane", return_value=""), \
            patch("mozyo_bridge.application.commands.run_tmux", side_effect=fake_run_tmux), \
            patch("mozyo_bridge.application.commands.time.sleep"), \
            contextlib.redirect_stdout(io.StringIO()), \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            result = args.func(args)

        self.assertEqual(0, result)
        self.assertNotIn("hint: retry path:", stderr.getvalue())
        self.assertNotIn("--no-submit retry budget", stderr.getvalue())


class WaitForTextContractTest(unittest.TestCase):
    def test_detects_marker_split_by_tui_wrap(self) -> None:
        """word-boundary wrap compat: short marker that contains whitespace,
        wrapped at a space and re-joined via the `\\n\\s+` -> ' ' normalize.
        Covers the original `mozyo-bridge message` marker shape."""
        from mozyo_bridge.application import commands as commands_mod

        marker = "[mozyo-bridge from:codex pane:%1 at:agents:0.0]"
        wrapped = (
            "› [mozyo-bridge from:codex pane:%1\n"
            "  at:agents:0.0] hello body\n"
        )
        with patch.object(commands_mod, "capture_pane", return_value=wrapped), \
                patch.object(commands_mod.time, "sleep"):
            self.assertTrue(commands_mod.wait_for_text("%2", marker, 200, 0.01))

    def test_detects_long_no_space_marker_split_by_character_wrap(self) -> None:
        """character-wrap compat: long no-space marker (`mozyo-bridge handoff`
        primitive shape) wrapped at arbitrary character boundaries by codex
        TUI, re-joined via the `\\n\\s+` -> '' normalize. Reproducer hex shape
        was confirmed against the real codex pane at 2026-05-13 (pane width
        50, wrap separator `\\n` + 3 spaces). The space-substitution path
        cannot match this shape because the original marker contains no
        whitespace; only empty-substitution reconstructs the original."""
        from mozyo_bridge.application import commands as commands_mod

        marker = (
            "[mozyo:handoff:source=asana:task=1214760547941073:"
            "comment=1214764579019987:kind=review_request:to=codex]"
        )
        wrapped = (
            "› [mozyo:handoff:source=asana:task=12147605479410\n"
            "   73:comment=1214764579019987:kind=review_request\n"
            "   :to=codex]\n"
        )
        with patch.object(commands_mod, "capture_pane", return_value=wrapped), \
                patch.object(commands_mod.time, "sleep"):
            self.assertTrue(commands_mod.wait_for_text("%2", marker, 200, 0.01))

    def test_returns_false_when_marker_genuinely_absent(self) -> None:
        """fail-closed maintained: when the marker is not present in any of
        raw / space-normalized / empty-normalized captures, the function
        returns False so the rollback contract still triggers."""
        from mozyo_bridge.application import commands as commands_mod

        marker = "[mozyo-bridge from:codex pane:%1 at:agents:0.0]"
        unrelated = "› unrelated pane\n  with indent\n"
        with patch.object(commands_mod, "capture_pane", return_value=unrelated), \
                patch.object(commands_mod.time, "sleep"):
            self.assertFalse(commands_mod.wait_for_text("%2", marker, 200, 0.01))

    def test_returns_false_when_long_handoff_marker_genuinely_absent(self) -> None:
        """fail-closed maintained on the new character-wrap path: empty-string
        substitution must not create accidental matches against unrelated
        wrapped content that just happens to share substrings around indent
        boundaries."""
        from mozyo_bridge.application import commands as commands_mod

        marker = (
            "[mozyo:handoff:source=asana:task=1214760547941073:"
            "comment=1214764579019987:kind=review_request:to=codex]"
        )
        unrelated_wrapped = (
            "› [mozyo:handoff:source=asana:task=99999999999999\n"
            "   99:comment=88888888888888:kind=reply:to=claude]\n"
        )
        with patch.object(commands_mod, "capture_pane", return_value=unrelated_wrapped), \
                patch.object(commands_mod.time, "sleep"):
            self.assertFalse(commands_mod.wait_for_text("%2", marker, 200, 0.01))

    def test_matches_raw_unwrapped_marker_unchanged(self) -> None:
        """raw substring fast-path: when the marker is present without wrap,
        the function returns True via the raw `in` check before normalization
        runs, preserving the cheapest match path."""
        from mozyo_bridge.application import commands as commands_mod

        marker = "[mozyo-bridge from:codex pane:%1 at:agents:0.0]"
        captured = f"some scrollback\n› {marker} body text\n"
        with patch.object(commands_mod, "capture_pane", return_value=captured), \
                patch.object(commands_mod.time, "sleep"):
            self.assertTrue(commands_mod.wait_for_text("%2", marker, 200, 0.01))


class CommandTest(unittest.TestCase):
    def test_notify_agent_waits_for_marker_before_enter_on_existing_pane(self) -> None:
        args = argparse.Namespace(
            issue="9020",
            journal="1",
            task_id=None,
            queue="unused",
            target="%2",
            ensure=False,
            config=False,
            force=True,
            read_lines=20,
            prompt="custom prompt marker",
            cwd="/repo",
            vertical=False,
            ready_timeout=0,
            landing_timeout=5,
            submit_delay=0,
            type="review_request",
            commit="abc123",
        )
        pane = {"id": "%2", "command": "node"}

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.find_handoff_task", return_value=None), \
            patch("mozyo_bridge.application.commands.pane_info", return_value=pane), \
            patch("mozyo_bridge.application.commands.ensure_agent_target"), \
            patch("mozyo_bridge.application.commands.cmd_read"), \
            patch("mozyo_bridge.application.commands.cmd_message"), \
            patch("mozyo_bridge.application.commands.wait_for_text", return_value=True) as wait_for_text, \
            patch("mozyo_bridge.application.commands.cmd_keys") as cmd_keys, \
            contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(0, notify_agent(args, "codex"))

        wait_for_text.assert_called_once_with("%2", "[mozyo:notify:issue=9020:journal=1:type=review_request]", 200, 5)
        cmd_keys.assert_called_once()

    def test_notify_agent_does_not_press_enter_when_marker_missing(self) -> None:
        args = argparse.Namespace(
            issue="9020",
            journal="1",
            task_id=None,
            queue="unused",
            target="%2",
            ensure=False,
            config=False,
            force=True,
            read_lines=20,
            prompt="custom prompt marker",
            cwd="/repo",
            vertical=False,
            ready_timeout=0,
            landing_timeout=5,
            submit_delay=0,
            type="review_request",
            commit="abc123",
        )
        pane = {"id": "%2", "command": "node"}

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.find_handoff_task", return_value=None), \
            patch("mozyo_bridge.application.commands.pane_info", return_value=pane), \
            patch("mozyo_bridge.application.commands.ensure_agent_target"), \
            patch("mozyo_bridge.application.commands.cmd_read"), \
            patch("mozyo_bridge.application.commands.cmd_message"), \
            patch("mozyo_bridge.application.commands.wait_for_text", return_value=False), \
            patch("mozyo_bridge.application.commands.rollback_unsubmitted_input") as rollback, \
            patch("mozyo_bridge.application.commands.cmd_keys") as cmd_keys, \
            contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                notify_agent(args, "codex")

        cmd_keys.assert_not_called()
        rollback.assert_called_once_with("%2")

    def test_notify_agent_waits_submit_delay_after_marker(self) -> None:
        args = argparse.Namespace(
            issue="9020",
            journal="1",
            task_id=None,
            queue="unused",
            target="%2",
            ensure=False,
            config=False,
            force=True,
            read_lines=20,
            prompt="custom prompt marker",
            cwd="/repo",
            vertical=False,
            ready_timeout=0,
            landing_timeout=5,
            submit_delay=0.2,
            type="review_request",
            commit="abc123",
        )
        pane = {"id": "%2", "command": "node"}

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.find_handoff_task", return_value=None), \
            patch("mozyo_bridge.application.commands.pane_info", return_value=pane), \
            patch("mozyo_bridge.application.commands.ensure_agent_target"), \
            patch("mozyo_bridge.application.commands.cmd_read"), \
            patch("mozyo_bridge.application.commands.cmd_message"), \
            patch("mozyo_bridge.application.commands.wait_for_text", return_value=True), \
            patch("mozyo_bridge.application.commands.time.sleep") as sleep, \
            patch("mozyo_bridge.application.commands.cmd_keys"), \
            contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(0, notify_agent(args, "codex"))

        sleep.assert_called_once_with(0.2)

    def test_ensure_repo_session_windows_creates_session_and_codex_window(self) -> None:
        args = argparse.Namespace(
            session="my-project",
            cwd="/repo",
            config=True,
            config_path="/repo/.tmux.conf",
            config_path_was_default=False,
            ready_timeout=0,
            force=False,
        )
        claude_pane = {"id": "%1", "command": "claude", "window_name": "claude"}
        codex_pane = {"id": "%2", "command": "node", "window_name": "codex"}

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.session_exists", side_effect=[False, False]), \
            patch("mozyo_bridge.application.commands.new_agent_session_window", return_value="%1") as new_session_window, \
            patch("mozyo_bridge.application.commands.source_tmux_conf") as source_conf, \
            patch("mozyo_bridge.application.commands.list_session_windows", return_value=["claude"]), \
            patch(
                "mozyo_bridge.application.commands.find_agent_window",
                side_effect=[claude_pane, codex_pane],
            ) as find_agent, \
            patch("mozyo_bridge.application.commands.new_agent_window", return_value="%2") as new_window, \
            patch("mozyo_bridge.application.commands.ensure_agent_target"):
            created = ensure_repo_session_windows(args)

        new_session_window.assert_called_once_with("claude", "my-project", cwd="/repo")
        new_window.assert_called_once_with("codex", "my-project", cwd="/repo")
        source_conf.assert_called_once_with("/repo/.tmux.conf", optional=False)
        self.assertEqual(["claude:%1", "codex:%2"], created)
        self.assertEqual(
            [("claude", "my-project"), ("codex", "my-project")],
            [(call.args[0], call.args[1]) for call in find_agent.call_args_list],
        )

    def test_ensure_repo_session_windows_skips_creation_when_windows_exist(self) -> None:
        args = argparse.Namespace(
            session="my-project",
            cwd="/repo",
            config=False,
            ready_timeout=0,
            force=False,
        )
        claude_pane = {"id": "%1", "command": "claude", "window_name": "claude"}
        codex_pane = {"id": "%2", "command": "node", "window_name": "codex"}

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.session_exists", return_value=True), \
            patch("mozyo_bridge.application.commands.new_agent_session_window") as new_session_window, \
            patch("mozyo_bridge.application.commands.new_agent_window") as new_window, \
            patch("mozyo_bridge.application.commands.list_session_windows", return_value=["claude", "codex"]), \
            patch(
                "mozyo_bridge.application.commands.find_agent_window",
                side_effect=[claude_pane, codex_pane],
            ) as find_agent, \
            patch("mozyo_bridge.application.commands.ensure_agent_target"):
            created = ensure_repo_session_windows(args)

        new_session_window.assert_not_called()
        new_window.assert_not_called()
        self.assertEqual([], created)
        # Window-model resolution: post-existence attach must consult the
        # named window. (The `@agent_name` label path is retired.)
        self.assertEqual(2, find_agent.call_count)
        self.assertEqual(("claude", "my-project"), find_agent.call_args_list[0].args)
        self.assertEqual(("codex", "my-project"), find_agent.call_args_list[1].args)

    def test_ensure_repo_session_windows_creates_missing_agent_windows_alongside_legacy_windows(self) -> None:
        # Sessions that pre-exist with non-agent windows (e.g. a VS Code
        # pane-split session named `agents`) are no longer rejected — bare
        # `mozyo` just appends the missing agent windows. The operator can
        # decide what to do with the leftover non-agent windows.
        args = argparse.Namespace(
            session="my-project",
            cwd="/repo",
            config=False,
            ready_timeout=0,
            force=False,
        )

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.session_exists", return_value=True), \
            patch("mozyo_bridge.application.commands.new_agent_session_window") as new_session_window, \
            patch(
                "mozyo_bridge.application.commands.new_agent_window",
                side_effect=["%2", "%3"],
            ) as new_window, \
            patch(
                "mozyo_bridge.application.commands.list_session_windows",
                return_value=["agents"],
            ), \
            patch(
                "mozyo_bridge.application.commands.find_agent_window",
                return_value=None,
            ), \
            patch("mozyo_bridge.application.commands.ensure_agent_target"):
            created = ensure_repo_session_windows(args)

        new_session_window.assert_not_called()
        self.assertEqual(2, new_window.call_count)
        self.assertEqual(("claude", "my-project"), new_window.call_args_list[0].args)
        self.assertEqual(("codex", "my-project"), new_window.call_args_list[1].args)
        self.assertEqual(["claude:%2", "codex:%3"], created)

    def test_ensure_repo_session_windows_skips_label_attachment_when_pane_lookup_returns_none(self) -> None:
        args = argparse.Namespace(
            session="my-project",
            cwd="/repo",
            config=False,
            ready_timeout=5.0,
            force=False,
        )

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.session_exists", return_value=True), \
            patch("mozyo_bridge.application.commands.new_agent_session_window") as new_session_window, \
            patch("mozyo_bridge.application.commands.new_agent_window") as new_window, \
            patch("mozyo_bridge.application.commands.list_session_windows", return_value=["claude", "codex"]), \
            patch(
                "mozyo_bridge.application.commands.find_agent_window",
                return_value=None,
            ) as find_agent, \
            patch("mozyo_bridge.application.commands.ensure_agent_target") as ensure_target, \
            patch("mozyo_bridge.application.commands.wait_for_agent_terminal_pane") as wait_ready:
            created = ensure_repo_session_windows(args)

        new_session_window.assert_not_called()
        new_window.assert_not_called()
        ensure_target.assert_not_called()
        wait_ready.assert_not_called()
        self.assertEqual(2, find_agent.call_count)
        self.assertEqual([], created)

    def test_cmd_mozyo_attaches_after_ensuring_repo_session(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = (Path(tmp) / "my-project").resolve()
            repo.mkdir()
            args = argparse.Namespace(
                repo=str(repo),
                session=None,
                cwd=None,
                config_path=None,
                ready_timeout=0,
                force=False,
                no_attach=False,
            )
            captured: dict[str, argparse.Namespace] = {}

            def fake_ensure(inner: argparse.Namespace) -> list[str]:
                captured["args"] = inner
                return ["claude:%1", "codex:%2"]

            list_result = argparse.Namespace(returncode=0, stdout="0\tclaude\tclaude\n1\tcodex\tnode\n", stderr="")

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=False), \
                patch("mozyo_bridge.application.commands.ensure_repo_session_windows", side_effect=fake_ensure), \
                patch("mozyo_bridge.application.commands.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.commands.os.execvp", side_effect=RuntimeError("attached")), \
                contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError, "attached"):
                    cmd_mozyo(args)

        self.assertEqual("my-project", captured["args"].session)
        self.assertEqual(str(repo), captured["args"].cwd)
        self.assertTrue(captured["args"].config)
        self.assertTrue(captured["args"].config_path_was_default)

    def test_cmd_mozyo_no_attach_skips_execvp_and_prints_attach_hint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = (Path(tmp) / "my-project").resolve()
            repo.mkdir()
            args = argparse.Namespace(
                repo=str(repo),
                session=None,
                cwd=None,
                config_path=None,
                ready_timeout=0,
                force=False,
                no_attach=True,
            )
            list_result = argparse.Namespace(returncode=0, stdout="", stderr="")

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=False), \
                patch("mozyo_bridge.application.commands.ensure_repo_session_windows", return_value=[]), \
                patch("mozyo_bridge.application.commands.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.commands.os.execvp", side_effect=AssertionError("must not attach")), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(0, cmd_mozyo(args))

        self.assertIn("attach: tmux attach -t my-project", stdout.getvalue())

    def test_cmd_mozyo_dies_when_claude_window_select_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = (Path(tmp) / "my-project").resolve()
            repo.mkdir()
            args = argparse.Namespace(
                repo=str(repo),
                session=None,
                cwd=None,
                config_path=None,
                ready_timeout=0,
                force=False,
                no_attach=False,
            )
            select_failure = argparse.Namespace(returncode=1, stdout="", stderr="can't find window: claude")

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=False), \
                patch("mozyo_bridge.application.commands.ensure_repo_session_windows", return_value=[]), \
                patch("mozyo_bridge.application.commands.run_tmux", return_value=select_failure), \
                patch("mozyo_bridge.application.commands.os.execvp") as execvp, \
                contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    cmd_mozyo(args)

        execvp.assert_not_called()
        self.assertIn("window-model guarantee", stderr.getvalue())
        self.assertIn("claude", stderr.getvalue())

    def test_cmd_mozyo_refuses_when_existing_session_panes_are_outside_repo(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = (Path(tmp) / "my-project").resolve()
            repo.mkdir()
            other = (Path(tmp) / "other-project").resolve()
            other.mkdir()
            args = argparse.Namespace(
                repo=str(repo),
                session=None,
                cwd=None,
                config_path=None,
                ready_timeout=0,
                force=False,
                no_attach=False,
            )
            panes = [
                {"id": "%1", "location": "my-project:0.0", "command": "zsh", "label": "", "cwd": str(other)},
            ]

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=True), \
                patch("mozyo_bridge.application.commands.pane_lines", return_value=panes), \
                patch("mozyo_bridge.application.commands.ensure_repo_session_windows") as ensure, \
                patch("mozyo_bridge.application.commands.os.execvp") as execvp, \
                contextlib.redirect_stderr(io.StringIO()) as stderr:
                with self.assertRaises(SystemExit):
                    cmd_mozyo(args)

        ensure.assert_not_called()
        execvp.assert_not_called()
        self.assertIn("my-project", stderr.getvalue())
        self.assertIn("outside repo root", stderr.getvalue())
        # The disambiguation hint must point operators at the bare-`mozyo`
        # `--session` flag, not at the retired `open-here` subcommand.
        self.assertIn("--session", stderr.getvalue())
        self.assertNotIn("open-here", stderr.getvalue())

    def test_cmd_mozyo_explicit_session_skips_cwd_mismatch_check(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = (Path(tmp) / "my-project").resolve()
            repo.mkdir()
            args = argparse.Namespace(
                repo=str(repo),
                session="explicit-session",
                cwd=None,
                config_path=None,
                ready_timeout=0,
                force=False,
                no_attach=True,
            )
            list_result = argparse.Namespace(returncode=0, stdout="", stderr="")
            captured: dict[str, argparse.Namespace] = {}

            def fake_ensure(inner: argparse.Namespace) -> list[str]:
                captured["args"] = inner
                return []

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=True), \
                patch("mozyo_bridge.application.commands.session_cwd_mismatch") as cwd_check, \
                patch("mozyo_bridge.application.commands.ensure_repo_session_windows", side_effect=fake_ensure), \
                patch("mozyo_bridge.application.commands.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.commands.os.execvp", side_effect=AssertionError("must not attach")), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(0, cmd_mozyo(args))

        cwd_check.assert_not_called()
        self.assertEqual("explicit-session", captured["args"].session)
        self.assertEqual(str(repo), captured["args"].cwd)
        self.assertIn("attach: tmux attach -t explicit-session", stdout.getvalue())

    def test_cmd_mozyo_propagates_explicit_config_path_with_was_default_false(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = (Path(tmp) / "my-project").resolve()
            repo.mkdir()
            custom_conf = (Path(tmp) / "custom.tmux.conf").resolve()
            custom_conf.write_text("")
            args = argparse.Namespace(
                repo=str(repo),
                session=None,
                cwd=None,
                config_path=str(custom_conf),
                ready_timeout=0,
                force=False,
                no_attach=True,
            )
            list_result = argparse.Namespace(returncode=0, stdout="", stderr="")
            captured: dict[str, argparse.Namespace] = {}

            def fake_ensure(inner: argparse.Namespace) -> list[str]:
                captured["args"] = inner
                return []

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=False), \
                patch("mozyo_bridge.application.commands.ensure_repo_session_windows", side_effect=fake_ensure), \
                patch("mozyo_bridge.application.commands.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.commands.os.execvp", side_effect=AssertionError("must not attach")), \
                contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(0, cmd_mozyo(args))

        self.assertEqual(str(custom_conf), captured["args"].config_path)
        self.assertFalse(captured["args"].config_path_was_default)

    def test_load_tmux_conf_skips_silently_when_default_path_missing(self) -> None:
        args = argparse.Namespace(
            config_path="/nonexistent/.tmux.conf",
            config_path_was_default=True,
            repo=None,
        )

        with patch("mozyo_bridge.application.commands.source_tmux_conf", wraps=tmux_client.source_tmux_conf) as wrapped, \
            patch("mozyo_bridge.infrastructure.tmux_client.run_tmux") as run:
            self.assertFalse(load_tmux_conf_for(args))

        wrapped.assert_called_once_with("/nonexistent/.tmux.conf", optional=True)
        run.assert_not_called()

    def test_load_tmux_conf_errors_when_explicit_config_path_missing(self) -> None:
        args = argparse.Namespace(
            config_path="/nonexistent/.tmux.conf",
            config_path_was_default=False,
            repo=None,
        )

        with patch("mozyo_bridge.application.commands.source_tmux_conf", wraps=tmux_client.source_tmux_conf), \
            patch("mozyo_bridge.infrastructure.tmux_client.run_tmux") as run, \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaises(SystemExit):
                load_tmux_conf_for(args)

        run.assert_not_called()
        self.assertIn("tmux config not found", stderr.getvalue())

    def test_load_tmux_conf_sources_when_default_path_exists(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            conf = Path(tmp) / ".tmux.conf"
            conf.write_text("# placeholder", encoding="utf-8")
            args = argparse.Namespace(
                config_path=str(conf),
                config_path_was_default=True,
                repo=None,
            )
            ok = argparse.Namespace(returncode=0, stdout="", stderr="")
            with patch("mozyo_bridge.infrastructure.tmux_client.run_tmux", return_value=ok) as run:
                self.assertTrue(load_tmux_conf_for(args))

        run.assert_called_once_with("source-file", str(conf), check=False)

    def test_session_cwd_mismatch_returns_empty_when_no_panes_in_session(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = (Path(tmp) / "my-project").resolve()
            repo.mkdir()
            panes = [{"id": "%1", "location": "elsewhere:0.0", "command": "zsh", "cwd": "/tmp"}]
            with patch("mozyo_bridge.application.commands.pane_lines", return_value=panes):
                self.assertEqual([], session_cwd_mismatch("my-project", repo))

    def test_doctor_warns_when_claude_pane_cwd_is_outside_repo_with_project_skills(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            (repo / ".claude" / "skills").mkdir(parents=True)
            args = argparse.Namespace(repo=str(repo), queue=str(repo / ".agent_handoff" / "tasks.json"))
            panes = [
                {
                    "id": "%1",
                    "location": "agents:0.0",
                    "command": "claude",
                    "label": "claude",
                    "cwd": str(Path(tmp) / "outside"),
                    "window_name": "claude",
                    "pane_active": "1",
                },
                {
                    "id": "%2",
                    "location": "agents:1.0",
                    "command": "node",
                    "label": "codex",
                    "cwd": str(repo),
                    "window_name": "codex",
                    "pane_active": "1",
                },
            ]
            list_result = argparse.Namespace(returncode=0, stdout="%1 claude\n%2 codex\n", stderr="")

            ok_stub = {"status": "ok", "next_action": []}

            with patch("mozyo_bridge.application.doctor.subprocess.run", return_value=argparse.Namespace(returncode=0)), \
                patch("mozyo_bridge.application.doctor.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.doctor.pane_lines", return_value=panes), \
                patch("mozyo_bridge.application.doctor._in_tmux", return_value=True), \
                patch.dict(os.environ, {"TMUX_PANE": "%1"}), \
                patch("mozyo_bridge.application.doctor.doctor_cli_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_rules_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_codex_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_claude_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_scaffold_section", return_value=ok_stub), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(1, cmd_doctor(args))

        output = stdout.getvalue()
        self.assertIn("warning: claude_pane cwd is outside repo root; project skills may not resolve", output)
        self.assertIn(f"repo={repo.resolve()}", output)

    def test_doctor_accepts_versioned_claude_native_binary_as_agent_process(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            args = argparse.Namespace(repo=str(repo), queue=str(repo / ".agent_handoff" / "tasks.json"))
            panes = [
                {
                    "id": "%1",
                    "location": "agents:0.0",
                    "command": "2.1.138",
                    "label": "claude",
                    "cwd": str(repo),
                    "window_name": "claude",
                    "pane_active": "1",
                },
                {
                    "id": "%2",
                    "location": "agents:1.0",
                    "command": "node",
                    "label": "codex",
                    "cwd": str(repo),
                    "window_name": "codex",
                    "pane_active": "1",
                },
            ]
            list_result = argparse.Namespace(returncode=0, stdout="%1 claude\n%2 codex\n", stderr="")

            ok_stub = {"status": "ok", "next_action": []}

            with patch("mozyo_bridge.application.doctor.subprocess.run", return_value=argparse.Namespace(returncode=0)), \
                patch("mozyo_bridge.application.doctor.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.doctor.pane_lines", return_value=panes), \
                patch("mozyo_bridge.application.doctor._in_tmux", return_value=True), \
                patch.dict(os.environ, {"TMUX_PANE": "%1"}), \
                patch("mozyo_bridge.application.doctor.doctor_cli_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_rules_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_codex_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_claude_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_scaffold_section", return_value=ok_stub), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(0, cmd_doctor(args))

        output = stdout.getvalue()
        self.assertIn("claude_window: %1", output)
        self.assertIn("process=2.1.138", output)
        self.assertIn("status=ok", output)

    def test_doctor_does_not_flag_cross_session_labeled_panes_as_duplicate(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            args = argparse.Namespace(repo=str(repo), queue=str(repo / ".agent_handoff" / "tasks.json"))
            panes = [
                {
                    "id": "%1",
                    "location": "mozyo_bridge:0.0",
                    "command": "2.1.138",
                    "label": "claude",
                    "cwd": str(repo),
                    "window_name": "claude",
                    "pane_active": "1",
                },
                {
                    "id": "%2",
                    "location": "mozyo_bridge:1.0",
                    "command": "node",
                    "label": "codex",
                    "cwd": str(repo),
                    "window_name": "codex",
                    "pane_active": "1",
                },
                {
                    "id": "%3",
                    "location": "other_project:0.0",
                    "command": "2.1.138",
                    "label": "claude",
                    "cwd": str(repo),
                    "window_name": "claude",
                    "pane_active": "1",
                },
                {
                    "id": "%4",
                    "location": "other_project:1.0",
                    "command": "node",
                    "label": "codex",
                    "cwd": str(repo),
                    "window_name": "codex",
                    "pane_active": "1",
                },
            ]
            list_result = argparse.Namespace(
                returncode=0,
                stdout="%1 claude\n%2 codex\n%3 claude\n%4 codex\n",
                stderr="",
            )
            ok_stub = {"status": "ok", "next_action": []}

            with patch("mozyo_bridge.application.doctor.subprocess.run", return_value=argparse.Namespace(returncode=0)), \
                patch("mozyo_bridge.application.doctor.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.doctor.pane_lines", return_value=panes), \
                patch.dict(os.environ, {"TMUX_PANE": "%1"}), \
                patch("mozyo_bridge.application.doctor.doctor_cli_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_rules_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_codex_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_claude_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_scaffold_section", return_value=ok_stub), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(0, cmd_doctor(args))

        output = stdout.getvalue()
        self.assertIn("claude_window: %1", output)
        self.assertIn("session=mozyo_bridge", output)
        self.assertIn("codex_window: %2", output)
        # Cross-session windows (other_project) are still listed in pane_lines
        # but no longer flagged anywhere — the window-only resolver scopes by
        # current session, so cross-session panes are inert.
        self.assertNotIn("duplicate", output)
        self.assertNotIn("other_sessions", output)

    def test_doctor_flags_missing_agent_window_as_warning(self) -> None:
        # Pure pane-split sessions (no agent-named windows) are no longer
        # supported as a runtime compatibility path. Doctor flips to
        # `warning` and prints a `next_action` suggesting bare `mozyo` or
        # `mozyo-bridge init <agent>` so the operator can recover.
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            args = argparse.Namespace(repo=str(repo), queue=str(repo / ".agent_handoff" / "tasks.json"))
            panes = [
                {
                    "id": "%1",
                    "location": "agents:0.0",
                    "command": "claude",
                    "cwd": str(repo),
                    "window_name": "tmux:0",
                    "pane_active": "1",
                },
                {
                    "id": "%2",
                    "location": "agents:1.0",
                    "command": "node",
                    "cwd": str(repo),
                    "window_name": "tmux:1",
                    "pane_active": "1",
                },
            ]
            list_result = argparse.Namespace(returncode=0, stdout="%1\n%2\n", stderr="")
            ok_stub = {"status": "ok", "next_action": []}

            with patch("mozyo_bridge.application.doctor.subprocess.run", return_value=argparse.Namespace(returncode=0)), \
                patch("mozyo_bridge.application.doctor.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.doctor.pane_lines", return_value=panes), \
                patch.dict(os.environ, {"TMUX_PANE": "%1"}), \
                patch("mozyo_bridge.application.doctor.doctor_cli_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_rules_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_codex_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_claude_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_scaffold_section", return_value=ok_stub), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(1, cmd_doctor(args))

        output = stdout.getvalue()
        self.assertIn("tmux: warning", output)
        self.assertIn("claude_window: missing session=agents", output)
        self.assertIn("codex_window: missing session=agents", output)
        self.assertIn("`mozyo`", output)
        self.assertIn("mozyo-bridge init claude", output)
        self.assertNotIn("(compat)", output)
        self.assertNotIn("legacy_pane_split", output)

    def test_doctor_flips_to_warning_on_duplicate_agent_window(self) -> None:
        # Resolver fails closed on a session with two windows named
        # `claude`. Doctor surfaces this as a `warning` with the window
        # indexes the operator must resolve.
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            args = argparse.Namespace(repo=str(repo), queue=str(repo / ".agent_handoff" / "tasks.json"))
            panes = [
                {
                    "id": "%1",
                    "location": "mozyo_bridge:0.0",
                    "command": "claude",
                    "cwd": str(repo),
                    "window_name": "claude",
                    "pane_active": "1",
                },
                {
                    "id": "%2",
                    "location": "mozyo_bridge:3.0",
                    "command": "claude",
                    "cwd": str(repo),
                    "window_name": "claude",
                    "pane_active": "1",
                },
                {
                    "id": "%3",
                    "location": "mozyo_bridge:1.0",
                    "command": "node",
                    "cwd": str(repo),
                    "window_name": "codex",
                    "pane_active": "1",
                },
            ]
            list_result = argparse.Namespace(returncode=0, stdout="%1\n%2\n%3\n", stderr="")
            ok_stub = {"status": "ok", "next_action": []}

            with patch("mozyo_bridge.application.doctor.subprocess.run", return_value=argparse.Namespace(returncode=0)), \
                patch("mozyo_bridge.application.doctor.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.doctor.pane_lines", return_value=panes), \
                patch.dict(os.environ, {"TMUX_PANE": "%1"}), \
                patch("mozyo_bridge.application.doctor.doctor_cli_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_rules_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_codex_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_claude_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_scaffold_section", return_value=ok_stub), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(1, cmd_doctor(args))

        output = stdout.getvalue()
        self.assertIn("tmux: warning", output)
        self.assertIn("claude_window: duplicate session=mozyo_bridge windows=0,3", output)
        self.assertIn("resolve duplicate `claude` windows", output)

    def test_doctor_reports_unscoped_when_invoked_outside_tmux_pane(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            args = argparse.Namespace(repo=str(repo), queue=str(repo / ".agent_handoff" / "tasks.json"))
            panes = [
                {
                    "id": "%1",
                    "location": "mozyo_bridge:0.0",
                    "command": "2.1.138",
                    "cwd": str(repo),
                    "window_name": "claude",
                    "pane_active": "1",
                },
                {
                    "id": "%2",
                    "location": "mozyo_bridge:1.0",
                    "command": "node",
                    "cwd": str(repo),
                    "window_name": "codex",
                    "pane_active": "1",
                },
            ]
            list_result = argparse.Namespace(returncode=0, stdout="%1\n%2\n", stderr="")
            ok_stub = {"status": "ok", "next_action": []}

            env_without_tmux_pane = {k: v for k, v in os.environ.items() if k != "TMUX_PANE"}
            with patch("mozyo_bridge.application.doctor.subprocess.run", return_value=argparse.Namespace(returncode=0)), \
                patch("mozyo_bridge.application.doctor.run_tmux", return_value=list_result), \
                patch("mozyo_bridge.application.doctor.pane_lines", return_value=panes), \
                patch.dict(os.environ, env_without_tmux_pane, clear=True), \
                patch("mozyo_bridge.application.doctor.doctor_cli_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_rules_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_codex_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_claude_skill_section", return_value=ok_stub), \
                patch("mozyo_bridge.application.doctor.doctor_scaffold_section", return_value=ok_stub), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(0, cmd_doctor(args))

        output = stdout.getvalue()
        self.assertIn("claude_window: unscoped", output)
        self.assertIn("codex_window: unscoped", output)
        self.assertNotIn("(compat)", output)
        self.assertNotIn("duplicate", output)

    def _init_run_tmux_side_effect(self, target_pane_id: str, *, rename_observer: list | None = None):
        # display-message resolves the pane reference to its canonical id.
        # rename-window is the only state-mutating tmux call init makes.
        def side_effect(*tmux_args, **_):
            if tmux_args[:1] == ("display-message",):
                return argparse.Namespace(returncode=0, stdout=f"{target_pane_id}\n", stderr="")
            if tmux_args[:1] == ("rename-window",):
                if rename_observer is not None:
                    rename_observer.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            raise AssertionError(f"unexpected tmux args: {tmux_args}")
        return side_effect

    def test_cmd_init_renames_target_window_to_agent_name(self) -> None:
        args = argparse.Namespace(agent="claude", target="%5")
        panes = [
            {"id": "%2", "location": "agents:0.0", "command": "zsh", "window_name": "zsh", "cwd": "/repo"},
            {"id": "%5", "location": "agents:1.0", "command": "zsh", "window_name": "zsh", "cwd": "/repo"},
        ]
        rename_calls: list[tuple] = []

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch(
                "mozyo_bridge.application.commands.run_tmux",
                side_effect=self._init_run_tmux_side_effect("%5"),
            ), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:1.0"), \
            patch("mozyo_bridge.application.commands.pane_lines", return_value=panes), \
            patch(
                "mozyo_bridge.application.commands.rename_window",
                side_effect=lambda target, name: rename_calls.append((target, name)),
            ), \
            contextlib.redirect_stdout(io.StringIO()) as stdout:
            self.assertEqual(0, cmd_init(args))

        self.assertEqual([("agents:1", "claude")], rename_calls)
        self.assertIn("agents:1 -> claude", stdout.getvalue())

    def test_cmd_init_refuses_when_window_name_collides_in_same_session(self) -> None:
        # Another window already named `claude` in the same session means the
        # resolver would die on duplicate names. init refuses up-front so the
        # operator can rename / kill that window first.
        args = argparse.Namespace(agent="claude", target="%5")
        panes = [
            {"id": "%1", "location": "agents:0.0", "command": "claude", "window_name": "claude", "cwd": "/repo"},
            {"id": "%5", "location": "agents:2.0", "command": "zsh", "window_name": "zsh", "cwd": "/repo"},
        ]
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch(
                "mozyo_bridge.application.commands.run_tmux",
                side_effect=self._init_run_tmux_side_effect("%5"),
            ), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:2.0"), \
            patch("mozyo_bridge.application.commands.pane_lines", return_value=panes), \
            patch("mozyo_bridge.application.commands.rename_window") as rename, \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaises(SystemExit):
                cmd_init(args)

        rename.assert_not_called()
        self.assertIn("agents:0(%1)", stderr.getvalue())
        self.assertIn("'claude'", stderr.getvalue())

    def test_cmd_init_allows_same_agent_name_in_a_different_session(self) -> None:
        # Cross-session `claude` windows are legitimate (one per repo). init
        # only refuses same-session collisions.
        args = argparse.Namespace(agent="claude", target="%5")
        panes = [
            {"id": "%2", "location": "other:0.0", "command": "claude", "window_name": "claude", "cwd": "/repo"},
            {"id": "%5", "location": "agents:1.0", "command": "zsh", "window_name": "zsh", "cwd": "/repo"},
        ]
        rename_calls: list[tuple] = []
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch(
                "mozyo_bridge.application.commands.run_tmux",
                side_effect=self._init_run_tmux_side_effect("%5"),
            ), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:1.0"), \
            patch("mozyo_bridge.application.commands.pane_lines", return_value=panes), \
            patch(
                "mozyo_bridge.application.commands.rename_window",
                side_effect=lambda target, name: rename_calls.append((target, name)),
            ), \
            contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(0, cmd_init(args))

        self.assertEqual([("agents:1", "claude")], rename_calls)

    def test_cmd_init_no_target_uses_current_pane(self) -> None:
        args = argparse.Namespace(agent="codex", target=None)
        panes = [
            {"id": "%9", "location": "agents:2.0", "command": "node", "window_name": "zsh", "cwd": "/repo"},
        ]
        rename_calls: list[tuple] = []
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch(
                "mozyo_bridge.application.commands.current_pane",
                return_value="%9",
            ), \
            patch(
                "mozyo_bridge.application.commands.run_tmux",
                side_effect=self._init_run_tmux_side_effect("%9"),
            ), \
            patch("mozyo_bridge.application.commands.pane_location", return_value="agents:2.0"), \
            patch("mozyo_bridge.application.commands.pane_lines", return_value=panes), \
            patch(
                "mozyo_bridge.application.commands.rename_window",
                side_effect=lambda target, name: rename_calls.append((target, name)),
            ), \
            contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(0, cmd_init(args))

        self.assertEqual([("agents:2", "codex")], rename_calls)

    def test_cmd_list_emits_window_column_in_place_of_label(self) -> None:
        panes = [
            {
                "id": "%1",
                "location": "repo:0.0",
                "command": "claude",
                "cwd": "/repo",
                "window_name": "claude",
                "pane_active": "1",
            },
            {
                "id": "%2",
                "location": "repo:1.0",
                "command": "node",
                "cwd": "/repo",
                "window_name": "codex",
                "pane_active": "1",
            },
        ]
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.pane_lines", return_value=panes), \
            contextlib.redirect_stdout(io.StringIO()) as stdout:
            self.assertEqual(0, cmd_list(argparse.Namespace()))

        output = stdout.getvalue()
        self.assertIn("WINDOW\tCWD", output)
        self.assertIn("\tclaude\t/repo", output)
        self.assertIn("\tcodex\t/repo", output)
        self.assertNotIn("LABEL", output)

    def test_cmd_init_rejects_label_as_target(self) -> None:
        args = argparse.Namespace(agent="claude", target="claude")
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaises(SystemExit):
                cmd_init(args)
        self.assertIn("not a label", stderr.getvalue())

    def test_resolve_status_session_prefers_current_tmux_session(self) -> None:
        args = argparse.Namespace(session=None, repo=None)

        with patch("mozyo_bridge.application.commands.current_session_name", return_value="mozyo_bridge"):
            self.assertEqual("mozyo_bridge", resolve_status_session(args))

    def test_resolve_status_session_falls_back_to_repo_basename(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "my_project"
            repo.mkdir()
            args = argparse.Namespace(session=None, repo=str(repo))

            with patch("mozyo_bridge.application.commands.current_session_name", return_value=None):
                self.assertEqual("my_project", resolve_status_session(args))

    def test_resolve_status_session_respects_explicit_session(self) -> None:
        args = argparse.Namespace(session="custom", repo=None)

        with patch("mozyo_bridge.application.commands.current_session_name", return_value="other"):
            self.assertEqual("custom", resolve_status_session(args))

    def test_cmd_status_omits_misleading_missing_message_under_window_model(self) -> None:
        # Regression: bare `mozyo` session named after the repo basename must
        # not be reported as `agents (missing)` (Asana task 1214758916882465).
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "my_project"
            repo.mkdir()
            args = argparse.Namespace(
                session=None,
                repo=str(repo),
                home=None,
                json=False,
                queue=None,
            )
            list_panes_result = argparse.Namespace(
                returncode=0,
                stdout=(
                    "0\tclaude\t%1\t1\tclaude\t" + str(repo) + "\n"
                    "1\tcodex\t%2\t1\tnode\t" + str(repo) + "\n"
                ),
                stderr="",
            )
            doctor_ok = {"sections": {"tmux": {"status": "ok", "next_action": []}}, "ok": True}

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.current_session_name", return_value="my_project"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=True), \
                patch("mozyo_bridge.application.commands.list_session_windows", return_value=["claude", "codex"]), \
                patch("mozyo_bridge.application.commands.run_tmux", return_value=list_panes_result), \
                patch("mozyo_bridge.application.commands.run_doctor", return_value=doctor_ok), \
                patch("mozyo_bridge.application.commands.format_doctor_text", return_value="tmux: ok\n"), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                self.assertEqual(0, cmd_status(args))

        output = stdout.getvalue()
        self.assertIn("session: my_project", output)
        self.assertNotIn("(missing)", output)
        self.assertIn("WINDOW\tNAME\tTARGET", output)

    def test_cmd_status_prints_init_hint_when_no_agent_windows_in_session(self) -> None:
        # Under the window-only model, a session without agent-named windows
        # is not a separate compat path — it is a session the operator must
        # migrate (via bare `mozyo`) or partially adopt (via `mozyo-bridge
        # init`). status surfaces one informational hint, not the old
        # "compat / pane-split" / "mixed:" branching.
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "agents"
            repo.mkdir()
            args = argparse.Namespace(
                session="agents",
                repo=str(repo),
                home=None,
                json=False,
                queue=None,
            )
            doctor_warning = {
                "sections": {"tmux": {"status": "warning", "next_action": []}},
                "ok": False,
            }

            with patch("mozyo_bridge.application.commands.require_tmux"), \
                patch("mozyo_bridge.application.commands.session_exists", return_value=True), \
                patch("mozyo_bridge.application.commands.list_session_windows", return_value=["zsh"]), \
                patch("mozyo_bridge.application.commands.run_doctor", return_value=doctor_warning), \
                patch(
                    "mozyo_bridge.application.commands.format_doctor_text",
                    return_value="tmux: warning\n",
                ), \
                contextlib.redirect_stdout(io.StringIO()) as stdout:
                cmd_status(args)

        output = stdout.getvalue()
        self.assertIn("no agent windows in this session", output)
        self.assertIn("mozyo-bridge init claude|codex", output)
        self.assertNotIn("(compat)", output)
        self.assertNotIn("mixed:", output)

    def test_notify_agent_resolves_via_window_when_label_absent(self) -> None:
        # Regression: with the window model, an agent's tmux window is the
        # authoritative target. A notification request for `codex` must reach
        # the codex window even if the pane has not been `init`-labeled yet.
        panes = [
            {
                "id": "%9",
                "location": "mozyo_bridge:1.0",
                "command": "node",
                "label": "",
                "cwd": "/repo",
                "window_name": "codex",
                "pane_active": "1",
            },
        ]
        args = argparse.Namespace(
            issue="9020",
            journal="1",
            task_id=None,
            queue="unused",
            target=None,
            ensure=False,
            config=False,
            force=True,
            read_lines=20,
            prompt="custom prompt marker",
            cwd="/repo",
            vertical=False,
            ready_timeout=0,
            landing_timeout=5,
            submit_delay=0,
            type="review_request",
            commit="abc123",
        )

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.find_handoff_task", return_value=None), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes), \
            patch("mozyo_bridge.domain.pane_resolver.current_session_name", return_value="mozyo_bridge"), \
            patch("mozyo_bridge.application.commands.pane_lines", return_value=panes), \
            patch("mozyo_bridge.application.commands.ensure_agent_target"), \
            patch("mozyo_bridge.application.commands.cmd_read"), \
            patch("mozyo_bridge.application.commands.cmd_message"), \
            patch("mozyo_bridge.application.commands.wait_for_text", return_value=True), \
            patch("mozyo_bridge.application.commands.cmd_keys") as cmd_keys, \
            contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(0, notify_agent(args, "codex"))

        cmd_keys.assert_called_once()

    def test_notify_agent_refuses_cross_session_label_fallback(self) -> None:
        # Regression: a `codex` label only present in another session must not
        # be used as a notification target from a different current session
        # (Asana task 1214743574772820 comment 1214746077864452).
        panes = [
            {
                "id": "%99",
                "location": "other:0.0",
                "command": "node",
                "label": "codex",
                "cwd": "/repo",
                "window_name": "codex",
                "pane_active": "1",
            },
        ]
        args = argparse.Namespace(
            issue="9020",
            journal="1",
            task_id=None,
            queue="unused",
            target=None,
            ensure=False,
            config=False,
            force=True,
            read_lines=20,
            prompt="custom prompt marker",
            cwd="/repo",
            vertical=False,
            ready_timeout=0,
            landing_timeout=5,
            submit_delay=0,
            type="review_request",
            commit="abc123",
        )

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.find_handoff_task", return_value=None), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=panes), \
            patch("mozyo_bridge.domain.pane_resolver.current_session_name", return_value="mozyo_bridge"), \
            contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                notify_agent(args, "codex")


class DoctorEnvironmentTest(unittest.TestCase):
    """Diagnostic sections for `mozyo-bridge doctor` (cli/rules/skills/scaffold)."""

    def _stub_args(self, **kwargs) -> argparse.Namespace:
        defaults = {"repo": None, "home": None, "json": False}
        defaults.update(kwargs)
        return argparse.Namespace(**defaults)

    def _seed_codex_skill(self, codex_home: Path, *, complete: bool = True) -> Path:
        skill_dir = codex_home / "skills" / "mozyo-bridge-agent"
        (skill_dir / "references").mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text("stub\n", encoding="utf-8")
        if complete:
            for ref in ("workflow.md", "safety.md", "project-map.md", "release.md"):
                (skill_dir / "references" / ref).write_text("stub\n", encoding="utf-8")
        return skill_dir

    def _seed_claude_global_skill(self, claude_home: Path, *, complete: bool = True) -> Path:
        skill_dir = claude_home / "skills" / "mozyo-bridge-agent"
        (skill_dir / "references").mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text("stub\n", encoding="utf-8")
        if complete:
            for ref in ("workflow.md", "safety.md", "project-map.md", "release.md"):
                (skill_dir / "references" / ref).write_text("stub\n", encoding="utf-8")
        return skill_dir

    def _seed_claude_project_skill(self, project: Path) -> Path:
        skill_dir = project / ".claude" / "skills" / "mozyo-bridge-agent"
        (skill_dir / "references").mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text("stub\n", encoding="utf-8")
        for ref in ("workflow.md", "safety.md", "project-map.md", "release.md"):
            (skill_dir / "references" / ref).write_text("stub\n", encoding="utf-8")
        return skill_dir

    def _seed_claude_plugin_skill(
        self, claude_home: Path, *, version: str = "abc12345"
    ) -> Path:
        plugin_dir = (
            claude_home
            / "plugins"
            / "cache"
            / "mozyo-bridge"
            / "mozyo-bridge-agent"
            / version
        )
        skill_dir = plugin_dir / "skills" / "mozyo-bridge-agent"
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text("plugin stub\n", encoding="utf-8")
        return plugin_dir

    def test_cli_section_reports_version_and_subcommands(self) -> None:
        from mozyo_bridge.application.doctor import doctor_cli_section

        section = doctor_cli_section()
        self.assertEqual("ok", section["status"])
        self.assertEqual(__version__, section["version"])
        for cmd in ("doctor", "rules", "scaffold"):
            self.assertIn(cmd, section["subcommands"])
        self.assertTrue(section["package_path"].endswith("mozyo_bridge"))

    def test_rules_section_reports_missing_when_not_installed(self) -> None:
        from mozyo_bridge.application.doctor import doctor_rules_section

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            section = doctor_rules_section(home)
            self.assertEqual("missing-or-outdated", section["status"])
            statuses = {row["preset"]: row["status"] for row in section["presets"]}
            self.assertEqual(
                {
                    "asana": "missing",
                    "redmine": "missing",
                    "redmine-rails": "missing",
                    "none": "missing",
                },
                statuses,
            )
            # Custom home was diagnosed, so next_action must target the same home.
            self.assertEqual(
                [f"mozyo-bridge rules install --home {home}"], section["next_action"]
            )

    def test_rules_section_reports_ok_when_installed(self) -> None:
        from mozyo_bridge.application.doctor import doctor_rules_section
        from mozyo_bridge.scaffold.rules import install_rules

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            install_rules(home)
            section = doctor_rules_section(home)
            self.assertEqual("ok", section["status"])
            for row in section["presets"]:
                self.assertEqual("ok", row["status"])
            self.assertEqual([], section["next_action"])

    def test_codex_skill_section_reports_missing_with_install_hint(self) -> None:
        from mozyo_bridge.application.doctor import doctor_codex_skill_section

        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict(os.environ, {"CODEX_HOME": str(Path(tmp) / "codex-home")}, clear=False):
                section = doctor_codex_skill_section()
                self.assertEqual("missing", section["status"])
                self.assertFalse(section["present"])
                self.assertTrue(section["next_action"])
                self.assertTrue(
                    any("install_codex_skill.sh" in action for action in section["next_action"])
                )

    def test_codex_skill_section_reports_ok_when_skill_present(self) -> None:
        from mozyo_bridge.application.doctor import doctor_codex_skill_section

        with tempfile.TemporaryDirectory() as tmp:
            codex_home = Path(tmp) / "codex-home"
            self._seed_codex_skill(codex_home, complete=True)
            with patch.dict(os.environ, {"CODEX_HOME": str(codex_home)}, clear=False):
                section = doctor_codex_skill_section()
                self.assertEqual("ok", section["status"])
                self.assertTrue(section["present"])
                self.assertEqual([], section["references_missing"])

    def test_codex_skill_section_flags_incomplete_when_references_missing(self) -> None:
        from mozyo_bridge.application.doctor import doctor_codex_skill_section

        with tempfile.TemporaryDirectory() as tmp:
            codex_home = Path(tmp) / "codex-home"
            self._seed_codex_skill(codex_home, complete=False)
            with patch.dict(os.environ, {"CODEX_HOME": str(codex_home)}, clear=False):
                section = doctor_codex_skill_section()
                self.assertEqual("incomplete", section["status"])
                self.assertTrue(section["references_missing"])

    def test_claude_skill_section_reports_missing_when_neither_present(self) -> None:
        from mozyo_bridge.application.doctor import doctor_claude_skill_section

        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp) / "project"
            project.mkdir()
            env = {
                "MOZYO_BRIDGE_CLAUDE_HOME": str(Path(tmp) / "claude-home"),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(project),
            }
            with patch.dict(os.environ, env, clear=False):
                args = self._stub_args(repo=str(project))
                section = doctor_claude_skill_section(args)
                self.assertEqual("missing", section["status"])
                self.assertFalse(section["global"]["present"])
                self.assertFalse(section["project"]["present"])
                self.assertEqual([], section["warnings"])
                self.assertTrue(section["next_action"])

    def test_claude_skill_section_warns_when_global_and_project_collide(self) -> None:
        from mozyo_bridge.application.doctor import doctor_claude_skill_section

        with tempfile.TemporaryDirectory() as tmp:
            claude_home = Path(tmp) / "claude-home"
            project = Path(tmp) / "project"
            project.mkdir()
            self._seed_claude_global_skill(claude_home, complete=True)
            self._seed_claude_project_skill(project)
            env = {
                "MOZYO_BRIDGE_CLAUDE_HOME": str(claude_home),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(project),
            }
            with patch.dict(os.environ, env, clear=False):
                args = self._stub_args(repo=str(project))
                section = doctor_claude_skill_section(args)
                self.assertEqual("warning", section["status"])
                self.assertEqual(1, len(section["warnings"]))
                self.assertIn("overrides project skill", section["warnings"][0])

    def test_claude_skill_section_global_only_is_ok(self) -> None:
        from mozyo_bridge.application.doctor import doctor_claude_skill_section

        with tempfile.TemporaryDirectory() as tmp:
            claude_home = Path(tmp) / "claude-home"
            project = Path(tmp) / "project"
            project.mkdir()
            self._seed_claude_global_skill(claude_home, complete=True)
            env = {
                "MOZYO_BRIDGE_CLAUDE_HOME": str(claude_home),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(project),
            }
            with patch.dict(os.environ, env, clear=False):
                args = self._stub_args(repo=str(project))
                section = doctor_claude_skill_section(args)
                self.assertEqual("ok", section["status"])
                self.assertTrue(section["global"]["present"])
                self.assertFalse(section["project"]["present"])
                self.assertEqual([], section["warnings"])

    def test_claude_skill_section_plugin_only_reports_plugin_managed(self) -> None:
        from mozyo_bridge.application.doctor import (
            CLAUDE_GLOBAL_SKILL_INSTALL_HINT,
            doctor_claude_skill_section,
        )

        with tempfile.TemporaryDirectory() as tmp:
            claude_home = Path(tmp) / "claude-home"
            project = Path(tmp) / "project"
            project.mkdir()
            self._seed_claude_plugin_skill(claude_home, version="abc12345")
            env = {
                "MOZYO_BRIDGE_CLAUDE_HOME": str(claude_home),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(project),
            }
            with patch.dict(os.environ, env, clear=False):
                args = self._stub_args(repo=str(project))
                section = doctor_claude_skill_section(args)
            self.assertEqual("plugin-managed", section["status"])
            self.assertFalse(section["global"]["present"])
            self.assertFalse(section["project"]["present"])
            self.assertTrue(section["plugin"]["present"])
            self.assertEqual(
                "abc12345", section["plugin"]["versions"][0]["version"]
            )
            self.assertEqual([], section["next_action"])
            self.assertNotIn(
                CLAUDE_GLOBAL_SKILL_INSTALL_HINT, section["next_action"]
            )

    def test_claude_skill_section_plugin_with_legacy_global_keeps_ok(self) -> None:
        """When both plugin and legacy global skill are installed, plugin
        namespace is separate so status stays ok (existing precedence rules
        for warning only fire on legacy+legacy collision)."""
        from mozyo_bridge.application.doctor import doctor_claude_skill_section

        with tempfile.TemporaryDirectory() as tmp:
            claude_home = Path(tmp) / "claude-home"
            project = Path(tmp) / "project"
            project.mkdir()
            self._seed_claude_global_skill(claude_home, complete=True)
            self._seed_claude_plugin_skill(claude_home, version="abc12345")
            env = {
                "MOZYO_BRIDGE_CLAUDE_HOME": str(claude_home),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(project),
            }
            with patch.dict(os.environ, env, clear=False):
                args = self._stub_args(repo=str(project))
                section = doctor_claude_skill_section(args)
            self.assertEqual("ok", section["status"])
            self.assertTrue(section["global"]["present"])
            self.assertTrue(section["plugin"]["present"])

    def test_run_doctor_reports_ok_for_plugin_only_state(self) -> None:
        """Top-level run_doctor must treat plugin-managed as healthy (overall
        result["ok"] == True) so the misleading legacy install hint does not
        flip the aggregate status."""
        from mozyo_bridge.application.doctor import run_doctor
        from mozyo_bridge.scaffold.rules import install_rules, write_scaffold

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            claude_home = Path(tmp) / "claude-home"
            codex_home = Path(tmp) / "codex-home"
            target = Path(tmp) / "project"
            target.mkdir()
            install_rules(home)
            write_scaffold("asana", target, home=home)
            self._seed_codex_skill(codex_home, complete=True)
            self._seed_claude_plugin_skill(claude_home, version="abc12345")
            env = {
                "MOZYO_BRIDGE_HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "MOZYO_BRIDGE_CLAUDE_HOME": str(claude_home),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(target),
            }
            with patch.dict(os.environ, env, clear=False), \
                patch(
                    "mozyo_bridge.application.doctor.doctor_tmux_section",
                    return_value={"status": "skipped", "next_action": []},
                ):
                args = self._stub_args(repo=str(target), home=str(home))
                result = run_doctor(args)
            self.assertTrue(result["ok"])
            self.assertEqual(
                "plugin-managed", result["sections"]["claude_skill"]["status"]
            )

    def test_scaffold_section_unscaffolded_suggests_scaffold_apply(self) -> None:
        from mozyo_bridge.application.doctor import doctor_scaffold_section

        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "project"
            target.mkdir()
            args = self._stub_args(repo=str(target), home=str(Path(tmp) / "mb-home"))
            section = doctor_scaffold_section(args)
            self.assertEqual("missing", section["status"])
            actions = section["next_action"]
            self.assertTrue(
                any("mozyo-bridge scaffold apply" in action for action in actions)
            )
            # The legacy subcommand wording must not leak back into doctor.
            # The forbidden literal is built from parts so this source file
            # does not carry the old command name as contiguous prose.
            legacy_phrase = "scaffold " + "ru" + "les"
            self.assertFalse(
                any(legacy_phrase in action for action in actions)
            )

    def test_scaffold_section_reports_ok_after_fresh_asana_scaffold(self) -> None:
        from mozyo_bridge.application.doctor import doctor_scaffold_section
        from mozyo_bridge.scaffold.rules import install_rules, write_scaffold

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            target = Path(tmp) / "project"
            target.mkdir()
            install_rules(home)
            write_scaffold("asana", target, home=home)
            args = self._stub_args(repo=str(target), home=str(home))
            section = doctor_scaffold_section(args)
            self.assertEqual("ok", section["status"])
            self.assertEqual("asana", section["detail"].get("preset"))
            self.assertEqual([], section["next_action"])

    def test_scaffold_section_reports_ok_after_fresh_redmine_scaffold(self) -> None:
        from mozyo_bridge.application.doctor import doctor_scaffold_section
        from mozyo_bridge.scaffold.rules import install_rules, write_scaffold

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            target = Path(tmp) / "project"
            target.mkdir()
            install_rules(home)
            write_scaffold("redmine", target, home=home)
            args = self._stub_args(repo=str(target), home=str(home))
            section = doctor_scaffold_section(args)
            self.assertEqual("ok", section["status"])
            self.assertEqual("redmine", section["detail"].get("preset"))

    def test_doctor_json_output_is_structured(self) -> None:
        from mozyo_bridge.application.doctor import run_doctor
        from mozyo_bridge.scaffold.rules import install_rules, write_scaffold

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            claude_home = Path(tmp) / "claude-home"
            codex_home = Path(tmp) / "codex-home"
            target = Path(tmp) / "project"
            target.mkdir()
            install_rules(home)
            write_scaffold("asana", target, home=home)
            self._seed_codex_skill(codex_home, complete=True)
            self._seed_claude_global_skill(claude_home, complete=True)
            env = {
                "MOZYO_BRIDGE_HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "MOZYO_BRIDGE_CLAUDE_HOME": str(claude_home),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(target),
            }
            with patch.dict(os.environ, env, clear=False), \
                patch("mozyo_bridge.application.doctor.doctor_tmux_section", return_value={"status": "skipped", "next_action": []}):
                args = self._stub_args(repo=str(target), home=str(home), json=True)
                result = run_doctor(args)
            self.assertTrue(result["ok"])
            self.assertIn("cli", result["sections"])
            self.assertIn("rules", result["sections"])
            self.assertIn("codex_skill", result["sections"])
            self.assertIn("claude_skill", result["sections"])
            self.assertIn("scaffold", result["sections"])
            self.assertIn("tmux", result["sections"])
            self.assertEqual("ok", result["sections"]["scaffold"]["status"])
            self.assertEqual("asana", result["sections"]["scaffold"]["detail"]["preset"])

            # Round-trip through json so we can assert the public payload is serializable.
            payload = json.dumps(result, ensure_ascii=False, sort_keys=True)
            self.assertTrue(payload)

    def test_doctor_is_read_only_for_isolated_environment(self) -> None:
        """Doctor must not install, repair, or contact external systems."""
        from mozyo_bridge.application.doctor import run_doctor

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            claude_home = Path(tmp) / "claude-home"
            codex_home = Path(tmp) / "codex-home"
            target = Path(tmp) / "project"
            target.mkdir()
            env = {
                "MOZYO_BRIDGE_HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "MOZYO_BRIDGE_CLAUDE_HOME": str(claude_home),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(target),
            }
            with patch.dict(os.environ, env, clear=False), \
                patch("mozyo_bridge.application.doctor.doctor_tmux_section", return_value={"status": "skipped", "next_action": []}):
                args = self._stub_args(repo=str(target), home=str(home))
                run_doctor(args)
            # None of the homes should have been auto-created/populated by doctor.
            self.assertFalse((home / "rules").exists())
            self.assertFalse((claude_home / "skills").exists())
            self.assertFalse((codex_home / "skills").exists())

    def test_cli_parser_accepts_doctor_target_home_and_json_flags(self) -> None:
        parser = build_parser()
        ns = parser.parse_args(
            ["doctor", "--target", "/tmp/a", "--home", "/tmp/b", "--json"]
        )
        self.assertEqual("doctor", ns.command)
        self.assertEqual("/tmp/a", ns.repo)
        self.assertEqual("/tmp/b", ns.home)
        self.assertTrue(ns.json)

    def test_claude_skill_install_hint_sets_scope_for_the_downstream_shell(self) -> None:
        """next_action must place `MOZYO_BRIDGE_CLAUDE_SCOPE=global` before `sh`,
        not before `curl`, so the env var actually reaches the install script."""
        from mozyo_bridge.application.doctor import (
            CLAUDE_GLOBAL_SKILL_INSTALL_HINT,
            doctor_claude_skill_section,
        )

        # The hint itself: env var must immediately precede the executor (`sh`),
        # not the pipeline producer (`curl`).
        self.assertIn("| MOZYO_BRIDGE_CLAUDE_SCOPE=global sh", CLAUDE_GLOBAL_SKILL_INSTALL_HINT)
        self.assertNotIn("MOZYO_BRIDGE_CLAUDE_SCOPE=global curl", CLAUDE_GLOBAL_SKILL_INSTALL_HINT)

        # And the section actually emits that hint when both global and project are absent.
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp) / "project"
            project.mkdir()
            env = {
                "MOZYO_BRIDGE_CLAUDE_HOME": str(Path(tmp) / "claude-home"),
                "MOZYO_BRIDGE_CLAUDE_PROJECT_DIR": str(project),
            }
            with patch.dict(os.environ, env, clear=False):
                section = doctor_claude_skill_section(self._stub_args(repo=str(project)))
            self.assertEqual("missing", section["status"])
            self.assertTrue(
                any("| MOZYO_BRIDGE_CLAUDE_SCOPE=global sh" in action for action in section["next_action"]),
                f"expected pipe-then-env install hint, got {section['next_action']!r}",
            )

    def test_rules_next_action_propagates_custom_home(self) -> None:
        from mozyo_bridge.application.doctor import doctor_rules_section

        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "mb-home"
            section = doctor_rules_section(home)
            self.assertEqual("missing-or-outdated", section["status"])
            self.assertEqual(
                [f"mozyo-bridge rules install --home {home}"], section["next_action"]
            )

    def test_rules_next_action_omits_home_flag_for_default_home(self) -> None:
        from mozyo_bridge.application.doctor import doctor_rules_section

        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict(
                os.environ,
                {"MOZYO_BRIDGE_HOME": str(Path(tmp) / "mb-home")},
                clear=False,
            ):
                section = doctor_rules_section(None)
            self.assertEqual("missing-or-outdated", section["status"])
            self.assertEqual(["mozyo-bridge rules install"], section["next_action"])

    def test_scaffold_next_action_propagates_custom_home(self) -> None:
        from mozyo_bridge.application.doctor import doctor_scaffold_section

        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "project"
            target.mkdir()
            home = Path(tmp) / "mb-home"
            args = self._stub_args(repo=str(target), home=str(home))
            section = doctor_scaffold_section(args)
            self.assertEqual("missing", section["status"])
            self.assertTrue(section["next_action"])
            action = section["next_action"][0]
            self.assertIn(f"--target {target.resolve()}", action)
            self.assertIn(f"--home {home.resolve()}", action)


class HandoffDomainTest(unittest.TestCase):
    def test_normalize_anchor_builds_asana_with_comment_id(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")

        self.assertIsInstance(anchor, AsanaAnchor)
        self.assertEqual("T1", anchor.task_id)
        self.assertEqual("C1", anchor.comment_id)
        self.assertIsNone(anchor.anchor_url)

    def test_normalize_anchor_builds_asana_with_anchor_url(self) -> None:
        anchor = normalize_anchor(
            "asana", task_id="T1", anchor_url="https://app.asana.com/0/0/T1#2026-05"
        )

        self.assertIsInstance(anchor, AsanaAnchor)
        self.assertEqual("https://app.asana.com/0/0/T1#2026-05", anchor.anchor_url)
        self.assertIsNone(anchor.comment_id)

    def test_normalize_anchor_rejects_asana_with_both_comment_and_url(self) -> None:
        with self.assertRaises(AnchorError):
            normalize_anchor(
                "asana", task_id="T1", comment_id="C1", anchor_url="https://example/x"
            )

    def test_normalize_anchor_rejects_asana_with_neither_comment_nor_url(self) -> None:
        with self.assertRaises(AnchorError):
            normalize_anchor("asana", task_id="T1")

    def test_normalize_anchor_rejects_asana_without_task_id(self) -> None:
        with self.assertRaises(AnchorError):
            normalize_anchor("asana", comment_id="C1")

    def test_normalize_anchor_builds_redmine(self) -> None:
        anchor = normalize_anchor("redmine", issue="9020", journal="46005")

        self.assertIsInstance(anchor, RedmineAnchor)
        self.assertEqual("9020", anchor.issue)
        self.assertEqual("46005", anchor.journal)

    def test_normalize_anchor_rejects_redmine_with_asana_fields(self) -> None:
        with self.assertRaises(AnchorError):
            normalize_anchor(
                "redmine", issue="9020", journal="46005", task_id="T1"
            )

    def test_normalize_anchor_rejects_asana_with_redmine_fields(self) -> None:
        with self.assertRaises(AnchorError):
            normalize_anchor(
                "asana", task_id="T1", comment_id="C1", journal="46005"
            )

    def test_normalize_anchor_rejects_unknown_source(self) -> None:
        with self.assertRaises(AnchorError):
            normalize_anchor("jira", task_id="T1")

    def test_build_marker_for_asana_with_comment(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")

        self.assertEqual(
            "[mozyo:handoff:source=asana:task=T1:comment=C1:kind=reply:to=claude]",
            build_marker(anchor, "reply", "claude"),
        )

    def test_build_marker_for_asana_with_anchor_url(self) -> None:
        anchor = normalize_anchor(
            "asana", task_id="T1", anchor_url="https://example/x"
        )

        self.assertEqual(
            "[mozyo:handoff:source=asana:task=T1:anchor=https://example/x:kind=review_result:to=codex]",
            build_marker(anchor, "review_result", "codex"),
        )

    def test_build_marker_for_redmine(self) -> None:
        anchor = normalize_anchor("redmine", issue="9020", journal="46005")

        self.assertEqual(
            "[mozyo:handoff:source=redmine:issue=9020:journal=46005:kind=review_request:to=codex]",
            build_marker(anchor, "review_request", "codex"),
        )

    def test_build_notification_body_requires_summary_for_custom_kind(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")

        with self.assertRaises(AnchorError):
            build_notification_body(anchor, "custom", None, "claude")

    def test_build_notification_body_appends_durable_pointer(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")

        body = build_notification_body(anchor, "implementation_request", None, "claude")

        self.assertIn("implementation request ready for claude", body)
        self.assertIn("Asana task T1", body)
        self.assertIn("comment C1", body)
        self.assertIn("durable anchor", body)

    def test_build_notification_body_uses_summary_when_provided(self) -> None:
        anchor = normalize_anchor("redmine", issue="9020", journal="46005")

        body = build_notification_body(
            anchor, "custom", "ship hotfix to staging", "codex"
        )

        self.assertIn("ship hotfix to staging", body)
        self.assertIn("Redmine #9020", body)
        self.assertIn("journal #46005", body)

    def test_build_notification_body_rejects_unknown_kind(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")

        with self.assertRaises(AnchorError):
            build_notification_body(anchor, "shipping_notice", None, "claude")

    def test_make_outcome_sent_attributes_action_to_receiver(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        outcome = make_outcome(
            status="sent",
            reason="ok",
            receiver="claude",
            target="%2",
            anchor=anchor,
            mode=MODE_STANDARD,
            kind="reply",
            notification_marker="[marker]",
        )

        self.assertEqual("receiver", outcome.next_action_owner)
        self.assertIn("durable anchor", outcome.next_action)
        payload = json.loads(outcome.to_json())
        self.assertEqual("sent", payload["status"])
        self.assertEqual("[marker]", payload["notification_marker"])
        self.assertEqual({"source": "asana", "task_id": "T1", "comment_id": "C1"}, payload["anchor"])

    def test_make_outcome_preserves_source_even_when_anchor_is_none(self) -> None:
        # Failure paths like invalid_anchor / invalid_args call make_outcome
        # without a normalized anchor. The structured contract still requires
        # `source`, so downstream durable-record integration (task
        # 1214760547941073) does not need to recover it out of band.
        outcome = make_outcome(
            status="blocked",
            reason="invalid_anchor",
            receiver="claude",
            target=None,
            anchor=None,
            mode=MODE_STANDARD,
            kind="reply",
            notification_marker=None,
            source="asana",
        )

        self.assertEqual("asana", outcome.source)
        payload = json.loads(outcome.to_json())
        self.assertEqual("asana", payload["source"])
        self.assertIsNone(payload["anchor"])

    def test_make_outcome_pending_attributes_action_to_operator(self) -> None:
        anchor = normalize_anchor("redmine", issue="9020", journal="46005")
        outcome = make_outcome(
            status="pending_input",
            reason="ok",
            receiver="codex",
            target="%2",
            anchor=anchor,
            mode=MODE_PENDING,
            kind="reply",
            notification_marker="[marker]",
        )

        self.assertEqual("operator", outcome.next_action_owner)
        self.assertIn("pending prompt", outcome.next_action)

    def test_next_action_for_marker_timeout_attributes_to_sender(self) -> None:
        owner, action = next_action_for("blocked", "marker_timeout", "claude")

        self.assertEqual("sender", owner)
        # The terminal escalation label is preserved so audit tooling and the
        # preset's `Notification fails` branch keep grepping the same word,
        # but the action now spells out the retry budget that must precede it
        # (Asana task 1214779823377861).
        self.assertIn("un-notified", action)
        self.assertIn("mozyo-bridge read claude", action)
        self.assertIn("--no-submit", action)
        self.assertIn("3", action)
        self.assertIn("next-action verb", action)

    def test_kind_labels_contract_is_stable(self) -> None:
        self.assertEqual(
            {
                "implementation_request",
                "design_consultation",
                "review_request",
                "review_result",
                "implementation_done",
                "reply",
                "custom",
            },
            set(KIND_LABELS),
        )


class ProjectLastInputTest(unittest.TestCase):
    """Cover the inspector ``last_input`` projection helper.

    The mapping table is fixed by the receiver-state inspector contract at
    ``mozyo_bridge_pty/vibes/docs/specs/receiver-state-inspector-contract.md``
    section "Receiver Inspector and Existing DeliveryOutcome" and the upstream
    transport-agnostic ACK contract section "Existing DeliveryOutcome との対応".
    Both prohibit translating ACK terminal states (``blocked + *``) into
    runtime/process state, and tmux-path outcomes never claim ``acknowledged``.
    """

    def _build_outcome(
        self,
        *,
        status,
        reason,
        receiver: str = "claude",
        mode: str = MODE_STANDARD,
    ):
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        return make_outcome(
            status=status,
            reason=reason,
            receiver=receiver,
            target="%2",
            anchor=anchor,
            mode=mode,
            kind="implementation_request",
            notification_marker="[marker]",
        )

    def test_sent_ok_projects_submitted_ack_status(self) -> None:
        outcome = self._build_outcome(status="sent", reason="ok")

        projection = project_last_input(
            outcome,
            submitted_at="2026-05-13T13:20:28Z",
            input_kind="prompt",
            prompt_turn_id="turn-1",
            input_id="input-1",
        )

        self.assertEqual(
            LastInputProjection(
                submitted_at="2026-05-13T13:20:28Z",
                acknowledged_at=None,
                ack_status="submitted",
                input_kind="prompt",
                prompt_turn_id="turn-1",
                input_id="input-1",
            ),
            projection,
        )

    def test_sent_ok_does_not_claim_acknowledged_on_tmux_path(self) -> None:
        # The tmux compatibility layer cannot observe runtime.input.ack; the
        # helper must not synthesize an `acknowledged` claim from a `sent`
        # outcome even when the caller forgets to pass `submitted_at`.
        outcome = self._build_outcome(status="sent", reason="ok")

        projection = project_last_input(outcome)

        assert projection is not None
        self.assertEqual("submitted", projection.ack_status)
        self.assertIsNone(projection.acknowledged_at)
        self.assertIsNone(projection.submitted_at)

    def test_pending_input_ok_projects_unobserved_ack_status(self) -> None:
        # Per the inspector contract, `pending_input/ok` carries input staged
        # at the prompt but the receiver runtime has not received the turn.
        # `submitted_at` stays null and `ack_status` is `unobserved`.
        outcome = self._build_outcome(
            status="pending_input", reason="ok", mode=MODE_PENDING
        )

        projection = project_last_input(
            outcome,
            submitted_at="2026-05-13T13:20:28Z",
            input_kind="prompt",
            prompt_turn_id="turn-7",
        )

        assert projection is not None
        self.assertIsNone(projection.submitted_at)
        self.assertIsNone(projection.acknowledged_at)
        self.assertEqual("unobserved", projection.ack_status)
        self.assertEqual("prompt", projection.input_kind)
        self.assertEqual("turn-7", projection.prompt_turn_id)

    def test_blocked_marker_timeout_yields_no_projection(self) -> None:
        # `marker_timeout` is an ACK terminal state, not a receiver-runtime
        # fact. Refusing to project it prevents callers from inferring
        # `process.exited` or any runtime_phase value from a rollback.
        outcome = self._build_outcome(status="blocked", reason="marker_timeout")

        self.assertIsNone(project_last_input(outcome))

    def test_blocked_target_unavailable_yields_no_projection(self) -> None:
        outcome = self._build_outcome(status="blocked", reason="target_unavailable")

        self.assertIsNone(project_last_input(outcome))

    def test_blocked_target_not_agent_yields_no_projection(self) -> None:
        outcome = self._build_outcome(status="blocked", reason="target_not_agent")

        self.assertIsNone(project_last_input(outcome))

    def test_blocked_invalid_anchor_yields_no_projection(self) -> None:
        outcome = make_outcome(
            status="blocked",
            reason="invalid_anchor",
            receiver="claude",
            target=None,
            anchor=None,
            mode=MODE_STANDARD,
            kind="implementation_request",
            notification_marker=None,
            source="asana",
        )

        self.assertIsNone(project_last_input(outcome))

    def test_blocked_invalid_args_yields_no_projection(self) -> None:
        outcome = make_outcome(
            status="blocked",
            reason="invalid_args",
            receiver="claude",
            target=None,
            anchor=None,
            mode=MODE_STANDARD,
            kind="implementation_request",
            notification_marker=None,
            source="asana",
        )

        self.assertIsNone(project_last_input(outcome))

    def test_outcome_method_matches_projection_helper(self) -> None:
        outcome = self._build_outcome(status="sent", reason="ok")

        via_method = outcome.to_last_input_projection(
            submitted_at="2026-05-13T13:20:28Z",
            input_kind="prompt",
            prompt_turn_id="turn-1",
        )
        via_helper = project_last_input(
            outcome,
            submitted_at="2026-05-13T13:20:28Z",
            input_kind="prompt",
            prompt_turn_id="turn-1",
        )

        self.assertEqual(via_helper, via_method)

    def test_projection_dataclass_is_serialisable_to_dict(self) -> None:
        # Inspector consumers serialise projections into the ReceiverState
        # snapshot; ensure the dataclass exposes all the expected fields.
        outcome = self._build_outcome(status="sent", reason="ok")

        projection = project_last_input(
            outcome, submitted_at="2026-05-13T13:20:28Z"
        )
        assert projection is not None

        self.assertEqual(
            {
                "submitted_at": "2026-05-13T13:20:28Z",
                "acknowledged_at": None,
                "ack_status": "submitted",
                "input_kind": None,
                "prompt_turn_id": None,
                "input_id": None,
            },
            projection.to_dict(),
        )


class HandoffCliParserTest(unittest.TestCase):
    def test_handoff_send_requires_kind(self) -> None:
        parser = build_parser()

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(
                    [
                        "handoff",
                        "send",
                        "--to",
                        "claude",
                        "--source",
                        "asana",
                        "--task-id",
                        "T1",
                        "--comment-id",
                        "C1",
                    ]
                )

    def test_handoff_send_parses_full_args(self) -> None:
        parser = build_parser()

        args = parser.parse_args(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--mode",
                "standard",
            ]
        )

        self.assertEqual("handoff", args.command)
        self.assertEqual("send", args.handoff_command)
        self.assertEqual("claude", args.to)
        self.assertEqual("asana", args.source)
        self.assertEqual("implementation_request", args.kind)
        self.assertEqual("T1", args.task_id)
        self.assertEqual("C1", args.comment_id)
        self.assertEqual(MODE_STANDARD, args.mode)

    def test_handoff_reply_allows_omitted_kind(self) -> None:
        parser = build_parser()

        args = parser.parse_args(
            [
                "handoff",
                "reply",
                "--to",
                "codex",
                "--source",
                "redmine",
                "--issue",
                "9020",
                "--journal",
                "46005",
            ]
        )

        self.assertEqual("handoff", args.command)
        self.assertEqual("reply", args.handoff_command)
        self.assertIsNone(args.kind)

    def test_reply_alias_shares_handoff_reply_func(self) -> None:
        parser = build_parser()

        args = parser.parse_args(
            [
                "reply",
                "--to",
                "claude",
                "--source",
                "asana",
                "--task-id",
                "T1",
                "--anchor-url",
                "https://example/x",
                "--mode",
                "pending",
            ]
        )

        self.assertEqual("reply", args.command)
        self.assertEqual("https://example/x", args.anchor_url)
        self.assertEqual(MODE_PENDING, args.mode)
        from mozyo_bridge.application.commands import cmd_handoff_reply

        self.assertIs(cmd_handoff_reply, args.func)

    def test_handoff_send_rejects_unknown_source(self) -> None:
        parser = build_parser()

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(
                    [
                        "handoff",
                        "send",
                        "--to",
                        "claude",
                        "--source",
                        "jira",
                        "--kind",
                        "reply",
                    ]
                )

    def test_handoff_send_rejects_unknown_kind(self) -> None:
        parser = build_parser()

        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                parser.parse_args(
                    [
                        "handoff",
                        "send",
                        "--to",
                        "claude",
                        "--source",
                        "asana",
                        "--kind",
                        "ship_it",
                    ]
                )


class HandoffOrchestratorTest(unittest.TestCase):
    def run_handoff_with_fake_tmux(
        self,
        argv: list[str],
        captures: list[str] | None = None,
        allow_exit: bool = False,
        pane: dict[str, str] | None = None,
    ):
        parser = build_parser()
        args = parser.parse_args(argv)
        sent: list[tuple[str, ...]] = []
        pane_text = ""
        forced_captures = captures is not None
        capture_outputs = list(captures or [])

        def fake_capture(_target: str, _lines: int) -> str:
            if capture_outputs:
                return capture_outputs.pop(0)
            if forced_captures:
                return ""
            return pane_text

        def fake_run_tmux(*tmux_args: str, check: bool = True):
            nonlocal pane_text
            if tmux_args[:4] == ("send-keys", "-t", "%2", "-l"):
                pane_text += tmux_args[-1]
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            if tmux_args[:3] == ("send-keys", "-t", "%2"):
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            raise AssertionError(f"unexpected tmux call: {tmux_args}")

        default_pane = {
            "id": "%2",
            "location": "agents:0.1",
            "command": "node",
            "cwd": "/repo",
            "window_name": "claude",
        }
        pane_value = pane if pane is not None else default_pane

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.capture_pane", side_effect=fake_capture), \
            patch("mozyo_bridge.application.commands.run_tmux", side_effect=fake_run_tmux), \
            patch("mozyo_bridge.application.commands.time.sleep"), \
            patch("mozyo_bridge.domain.pane_resolver.validate_target"), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=[pane_value]), \
            contextlib.redirect_stdout(io.StringIO()) as stdout, \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            try:
                result = args.func(args)
            except SystemExit as exc:
                if not allow_exit:
                    raise
                result = exc

        return result, sent, stdout.getvalue(), stderr.getvalue(), pane_text

    def _outcome_from_stdout(self, stdout: str) -> dict:
        lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertTrue(lines, f"no JSON outcome found in stdout: {stdout!r}")
        return json.loads(lines[-1])

    def test_standard_mode_sends_marker_body_and_enter(self) -> None:
        # Strict `--mode standard` happy path: marker observed → Enter pressed,
        # outcome `sent` / `ok` / mode=`standard`. v0.4 default is queue-enter,
        # so this test exercises the explicit strict fallback rail.
        result, sent, stdout, _stderr, pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--submit-delay",
                "0",
            ]
        )

        self.assertEqual(0, result)
        expected_marker = "[mozyo:handoff:source=asana:task=T1:comment=C1:kind=implementation_request:to=claude]"
        self.assertIn(expected_marker, pane_text)
        self.assertIn("Asana task T1", pane_text)
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])

        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("sent", outcome["status"])
        self.assertEqual("ok", outcome["reason"])
        self.assertEqual("claude", outcome["receiver"])
        self.assertEqual("%2", outcome["target"])
        self.assertEqual("asana", outcome["source"])
        self.assertEqual("implementation_request", outcome["kind"])
        self.assertEqual(MODE_STANDARD, outcome["mode"])
        self.assertEqual(expected_marker, outcome["notification_marker"])
        self.assertEqual("receiver", outcome["next_action_owner"])

    def test_pending_mode_leaves_input_unsubmitted_and_emits_pending_outcome(self) -> None:
        result, sent, stdout, _stderr, pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "reply",
                "--to",
                "codex",
                "--source",
                "redmine",
                "--issue",
                "9020",
                "--journal",
                "46005",
                "--target",
                "%2",
                "--force",
                "--mode",
                "pending",
            ],
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "node",
                "cwd": "/repo",
                "window_name": "codex",
            },
        )

        self.assertEqual(0, result)
        self.assertIn(
            "[mozyo:handoff:source=redmine:issue=9020:journal=46005:kind=reply:to=codex]",
            pane_text,
        )
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "Enter") for call in sent))
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "C-u") for call in sent))

        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("pending_input", outcome["status"])
        self.assertEqual("reply", outcome["kind"])
        self.assertEqual("operator", outcome["next_action_owner"])

    def test_marker_timeout_rolls_back_and_emits_blocked_outcome(self) -> None:
        # Strict `--mode standard` fail-closed regression: marker miss must
        # roll back via `C-u` and emit `blocked` / `marker_timeout`. v0.4
        # default (queue-enter) deliberately does NOT roll back; that contract
        # is covered separately.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "review_result",
                "--task-id",
                "T1",
                "--anchor-url",
                "https://example/x",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--landing-timeout",
                "0.01",
                "--submit-delay",
                "0",
            ],
            captures=["", "", ""],
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "Enter") for call in sent))
        self.assertIn(("send-keys", "-t", "%2", "C-u"), sent)

        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("marker_timeout", outcome["reason"])
        self.assertEqual("sender", outcome["next_action_owner"])

        # Asana task 1214779823377861: the rollback path must emit the
        # `--no-submit` fallback hint on stderr so agents do not jump to the
        # preset's `Notification fails` branch after a single transient
        # marker_timeout. Names the receiver and the per-preset cap so the
        # budget is unambiguous and not borrowed from the `handoff send`
        # retry pool.
        self.assertIn("hint: fallback path:", stderr)
        self.assertIn("mozyo-bridge read claude", stderr)
        self.assertIn("mozyo-bridge message claude", stderr)
        self.assertIn("--no-submit", stderr)
        self.assertIn("3", stderr)
        self.assertIn("separate budgets", stderr)
        self.assertIn("next-action verb", stderr)

    def test_invalid_anchor_emits_blocked_invalid_anchor_outcome(self) -> None:
        # Anchor normalization fires before rail-specific preflight, so this
        # test holds for both rails. Pinned to `--mode standard` so the v0.4
        # queue-enter force-rejection cannot eclipse the invalid_anchor exit.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--target",
                "%2",
                "--mode",
                "standard",
            ],
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("invalid_anchor", outcome["reason"])
        self.assertIsNone(outcome["target"])
        # Source must survive anchor-normalization failure so task
        # 1214760547941073 can persist the outcome without re-deriving it.
        self.assertEqual("asana", outcome["source"])
        self.assertIn("asana anchor", stderr)

    def test_non_agent_pane_without_force_emits_target_not_agent(self) -> None:
        # Strict-rail agent gate (`ensure_agent_target`) must still reject a
        # non-agent foreground process when `--force` is absent. Pinned to
        # `--mode standard` because queue-enter's Layer B preflight rejects on
        # `target_not_agent` via a different code path (Step 12) and would
        # surface a different `Reason` ordering.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "standard",
            ],
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "zsh",
                "cwd": "/repo",
                "window_name": "claude",
            },
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("target_not_agent", outcome["reason"])
        self.assertEqual("%2", outcome["target"])
        self.assertIn("target pane does not look like an agent pane", stderr)

    def test_target_unavailable_emits_blocked_target_unavailable(self) -> None:
        parser = build_parser()
        args = parser.parse_args(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
            ]
        )

        # No agent window in the session, no explicit --target. resolve_target
        # should die; the orchestrator must emit a structured outcome first.
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.domain.pane_resolver.current_session_name", return_value="my-project"), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=[]), \
            contextlib.redirect_stdout(io.StringIO()) as stdout, \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            with self.assertRaises(SystemExit):
                args.func(args)

        out = stdout.getvalue()
        outcome_lines = [line for line in out.splitlines() if line.strip().startswith("{")]
        self.assertTrue(outcome_lines, f"no JSON outcome found in stdout: {out!r}")
        outcome = json.loads(outcome_lines[-1])
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("target_unavailable", outcome["reason"])
        self.assertIsNone(outcome["target"])
        self.assertIn("no claude window found", stderr.getvalue())


class RelaxedQueueEnterRailTest(unittest.TestCase):
    """Coverage for the relaxed `queue-enter` rail.

    Implements the v0.2 contract section `## Relaxed Queue-Enter Rail` in
    ``vibes/docs/logics/tmux-send-safety-contract.md``. Strict `--mode standard`
    behavior must remain unchanged (covered by ``HandoffOrchestratorTest``);
    these tests focus on what the new rail adds and what it deliberately
    refuses to do.
    """

    def run_handoff_with_fake_tmux(
        self,
        argv,
        captures=None,
        allow_exit: bool = False,
        pane=None,
        current_session: str | None = "agents",
    ):
        # Mirror of HandoffOrchestratorTest.run_handoff_with_fake_tmux so this
        # class can drive the CLI end-to-end without launching tmux.
        parser = build_parser()
        args = parser.parse_args(argv)
        sent: list[tuple[str, ...]] = []
        pane_text = ""
        forced_captures = captures is not None
        capture_outputs = list(captures or [])

        def fake_capture(_target: str, _lines: int) -> str:
            if capture_outputs:
                return capture_outputs.pop(0)
            if forced_captures:
                return ""
            return pane_text

        def fake_run_tmux(*tmux_args, check: bool = True):
            nonlocal pane_text
            if tmux_args[:4] == ("send-keys", "-t", "%2", "-l"):
                pane_text += tmux_args[-1]
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            if tmux_args[:3] == ("send-keys", "-t", "%2"):
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            raise AssertionError(f"unexpected tmux call: {tmux_args}")

        default_pane = {
            "id": "%2",
            "location": "agents:0.1",
            "command": "node",
            "cwd": "/repo",
            "window_name": "claude",
            "pane_active": "1",
        }
        pane_value = pane if pane is not None else default_pane

        # Step 10 (v0.3 deterministic preflight) reads the sender's tmux
        # session via `current_session_name`. Default to "agents" so the
        # default pane's location prefix (`agents:0.1`) matches; individual
        # tests can override by patching the same symbol inside the body.
        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.capture_pane", side_effect=fake_capture), \
            patch("mozyo_bridge.application.commands.run_tmux", side_effect=fake_run_tmux), \
            patch("mozyo_bridge.application.commands.time.sleep"), \
            patch("mozyo_bridge.application.commands.current_session_name", return_value=current_session), \
            patch("mozyo_bridge.domain.pane_resolver.validate_target"), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=[pane_value]), \
            contextlib.redirect_stdout(io.StringIO()) as stdout, \
            contextlib.redirect_stderr(io.StringIO()) as stderr:
            try:
                result = args.func(args)
            except SystemExit as exc:
                if not allow_exit:
                    raise
                result = exc

        return result, sent, stdout.getvalue(), stderr.getvalue(), pane_text

    def _outcome_from_stdout(self, stdout: str) -> dict:
        lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertTrue(lines, f"no JSON outcome found in stdout: {stdout!r}")
        return json.loads(lines[-1])

    # --- mode parsing / validation -------------------------------------------------

    def test_cli_accepts_mode_queue_enter(self) -> None:
        parser = build_parser()
        args = parser.parse_args(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--mode",
                "queue-enter",
            ]
        )

        self.assertEqual(MODE_QUEUE_ENTER, args.mode)

    def test_cli_default_mode_is_queue_enter_since_v0_4(self) -> None:
        # v0.4 contract pivot (Asana 1214824751741628) flipped the CLI default
        # for agent-pane handoff to queue-enter. Strict `--mode standard`
        # remains explicitly selectable; its regression coverage lives in
        # `test_strict_standard_still_rolls_back_on_marker_timeout` and
        # `test_strict_standard_admits_cross_receiver_process_unchanged`.
        parser = build_parser()
        args = parser.parse_args(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
            ]
        )

        self.assertEqual(MODE_QUEUE_ENTER, args.mode)

    def test_cli_rejects_unknown_mode(self) -> None:
        parser = build_parser()
        with self.assertRaises(SystemExit):
            with contextlib.redirect_stderr(io.StringIO()):
                parser.parse_args(
                    [
                        "handoff",
                        "send",
                        "--to",
                        "claude",
                        "--source",
                        "asana",
                        "--kind",
                        "reply",
                        "--task-id",
                        "T1",
                        "--comment-id",
                        "C1",
                        "--mode",
                        "relaxed",
                    ]
                )

    # --- queue-enter behavior split ------------------------------------------------

    def test_queue_enter_observed_marker_emits_sent_ok_with_queue_enter_mode(self) -> None:
        result, sent, stdout, _stderr, pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "queue-enter",
                "--submit-delay",
                "0",
            ]
        )

        self.assertEqual(0, result)
        expected_marker = "[mozyo:handoff:source=asana:task=T1:comment=C1:kind=implementation_request:to=claude]"
        self.assertIn(expected_marker, pane_text)
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])
        # Marker was observed (default capture returns pane_text), so no
        # rollback occurred.
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "C-u") for call in sent))

        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("sent", outcome["status"])
        self.assertEqual("ok", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertEqual("receiver", outcome["next_action_owner"])

    def test_queue_enter_unobserved_marker_emits_sent_queue_enter_without_rollback(self) -> None:
        # Force capture to return empty so wait_for_text returns False.
        result, sent, stdout, _stderr, pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "review_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "queue-enter",
                "--landing-timeout",
                "0.01",
                "--submit-delay",
                "0",
            ],
            captures=["", "", ""],
        )

        self.assertEqual(0, result)
        # Body was typed.
        self.assertIn(
            "[mozyo:handoff:source=asana:task=T1:comment=C1:kind=review_request:to=claude]",
            pane_text,
        )
        # Enter WAS pressed (the rail's whole point).
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])
        # No rollback.
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "C-u") for call in sent))

        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("sent", outcome["status"])
        self.assertEqual("queue_enter", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        # Per the contract, next_action_owner stays receiver-owned even when
        # the marker was unobserved.
        self.assertEqual("receiver", outcome["next_action_owner"])
        self.assertIn("durable anchor", outcome["next_action"])

    def test_strict_standard_still_rolls_back_on_marker_timeout(self) -> None:
        # Regression: the v0.4 default flip to queue-enter must not weaken
        # strict `standard`. Strict is now an explicit fallback (`--mode
        # standard`); its fail-closed `C-u` rollback on marker_timeout stays
        # exactly as it was in v0.1.
        result, sent, stdout, _stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "review_result",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--landing-timeout",
                "0.01",
                "--submit-delay",
                "0",
            ],
            captures=["", "", ""],
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call == ("send-keys", "-t", "%2", "Enter") for call in sent))
        self.assertIn(("send-keys", "-t", "%2", "C-u"), sent)
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("marker_timeout", outcome["reason"])
        self.assertEqual(MODE_STANDARD, outcome["mode"])

    # --- agent-target restriction --------------------------------------------------

    def test_queue_enter_rejects_force_flag(self) -> None:
        # Per contract, `--force` cannot bypass agent-gate under queue-enter.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "queue-enter",
                "--force",
            ],
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        # No typing should have occurred.
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("invalid_args", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertIn("--force", stderr)
        self.assertIn("queue-enter", stderr)

    def test_queue_enter_rejects_explicit_target_in_other_receiver_window(self) -> None:
        # Per Codex audit finding on task 1214782240686275 comment 1214783754107198:
        # `ensure_agent_target` only checks that the pane is running *some*
        # agent-looking process (claude/codex/node), not that the pane belongs
        # to the intended receiver. Under strict, marker_timeout rollback caps
        # the blast radius. Under queue-enter, marker miss does NOT roll back,
        # so an explicit `--target %X` in the wrong receiver's window would
        # silently press Enter into the wrong agent. The queue-enter preflight
        # must reject this mismatch before typing.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "queue-enter",
            ],
            pane={
                "id": "%2",
                "location": "agents:1.0",
                "command": "node",
                "cwd": "/repo",
                # Pane is a real agent process, but lives in the codex window.
                # Strict (`ensure_agent_target`) would currently accept this;
                # queue-enter must not.
                "window_name": "codex",
                "pane_active": "1",
            },
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        # No typing or Enter against the mismatched pane.
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("invalid_args", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        # Target id should still survive the outcome (typing was not done but
        # the pane resolved); helps audit which mismatched pane was rejected.
        self.assertEqual("%2", outcome["target"])
        self.assertIn("queue-enter", stderr)
        self.assertIn("--target", stderr)
        self.assertIn("'codex'", stderr)
        self.assertIn("'claude'", stderr)

    def test_queue_enter_allows_explicit_target_in_matching_receiver_window(self) -> None:
        # Sanity check that the new preflight does not over-fire: an explicit
        # --target in the receiver's own window must still be accepted.
        result, sent, stdout, _stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "queue-enter",
                "--submit-delay",
                "0",
            ],
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "node",
                "cwd": "/repo",
                "window_name": "claude",
                "pane_active": "1",
            },
        )

        self.assertEqual(0, result)
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("sent", outcome["status"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])

    def test_queue_enter_blocks_non_agent_pane(self) -> None:
        # Non-agent process in a claude window: the standard agent-gate fires
        # and emits target_not_agent. Under queue-enter this stays blocked
        # (and `--force` is not even available to override).
        result, sent, stdout, _stderr, _pane_text = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "queue-enter",
            ],
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "zsh",
                "cwd": "/repo",
                "window_name": "claude",
                "pane_active": "1",
            },
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("target_not_agent", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])

    # --- v0.3 deterministic preflight (Step 10 / 11 / 12) -------------------------

    def _queue_enter_argv(self, *, kind: str = "implementation_request") -> list[str]:
        return [
            "handoff",
            "send",
            "--to",
            "claude",
            "--source",
            "asana",
            "--kind",
            kind,
            "--task-id",
            "T1",
            "--comment-id",
            "C1",
            "--target",
            "%2",
            "--mode",
            "queue-enter",
        ]

    def test_queue_enter_step10_rejects_foreign_session_target(self) -> None:
        # Step 10 (v0.3): same-session binding. An explicit `--target %X` whose
        # pane lives in a different tmux session than the sender must be
        # rejected before typing — under queue-enter marker miss does not roll
        # back, so cross-session delivery could otherwise land in the wrong
        # repo's agent.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            self._queue_enter_argv(),
            pane={
                "id": "%2",
                "location": "other:0.1",
                "command": "node",
                "cwd": "/repo",
                "window_name": "claude",
                "pane_active": "1",
            },
            current_session="agents",
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("invalid_args", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertIn("queue-enter", stderr)
        self.assertIn("'agents'", stderr)
        self.assertIn("'other'", stderr)

    def test_queue_enter_step10_rejects_when_sender_outside_tmux(self) -> None:
        # Step 10 (v0.3): when invoked outside tmux, `current_session_name`
        # returns None. queue-enter must refuse rather than admit a comparison
        # against a missing sender session.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            self._queue_enter_argv(),
            current_session=None,
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("invalid_args", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertIn("queue-enter", stderr)
        self.assertIn("'<unset>'", stderr)

    def test_queue_enter_step11_rejects_inactive_pane(self) -> None:
        # Step 11 (v0.3): the target pane must be the active split of its
        # window. An inactive split would still accept keystrokes typed via
        # `send-keys -t %X`, but the receiver agent is by construction not the
        # foreground process the operator is looking at; queue-enter rejects
        # before typing.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            self._queue_enter_argv(),
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "node",
                "cwd": "/repo",
                "window_name": "claude",
                "pane_active": "0",
            },
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("invalid_args", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertIn("queue-enter", stderr)
        self.assertIn("pane_active", stderr)

    def test_queue_enter_step12_rejects_cross_receiver_literal_to_claude(self) -> None:
        # Step 12 (v0.3) strong identity: a literal `codex` process foregrounded
        # in a `claude` window cannot satisfy the per-receiver allowlist for
        # `claude`. Step 9 already enforces `window_name == receiver` for
        # explicit `--target`; this guards the case where the window itself was
        # renamed but the foreground process betrays a different receiver.
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            self._queue_enter_argv(),
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "codex",
                "cwd": "/repo",
                "window_name": "claude",
                "pane_active": "1",
            },
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("target_not_agent", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertIn("queue-enter", stderr)
        self.assertIn("'codex'", stderr)
        self.assertIn("claude agent", stderr)

    def test_queue_enter_step12_rejects_cross_receiver_literal_to_codex(self) -> None:
        # Step 12 strong identity, symmetric case: a literal `claude` process
        # in a `codex` window is rejected for receiver=`codex`. (Literal
        # `node` is weak identity for both receivers because both Claude
        # Code and the Codex CLI are Node-based, so `node` does NOT exhibit
        # cross-binding rejection here; this test exercises the *strong*
        # branch only.)
        argv = self._queue_enter_argv(kind="reply")
        argv[argv.index("claude")] = "codex"
        result, sent, stdout, stderr, _pane_text = self.run_handoff_with_fake_tmux(
            argv,
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "claude",
                "cwd": "/repo",
                "window_name": "codex",
                "pane_active": "1",
            },
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertFalse(any(call[:3] == ("send-keys", "-t", "%2") for call in sent))
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("target_not_agent", outcome["reason"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])
        self.assertIn("queue-enter", stderr)
        self.assertIn("'claude'", stderr)
        self.assertIn("codex agent", stderr)

    def test_queue_enter_step12_admits_node_for_codex_weak_identity(self) -> None:
        # Both Claude Code and the Codex CLI surface as `node` in tmux
        # (Node-based runtimes). Step 12 admits `node` for receiver=`codex`
        # under the weak-identity branch — Step 9 (`window_name == receiver`)
        # plus Layer A operator discipline carry cross-binding protection
        # here. This test pins admission to keep real codex panes deliverable
        # under queue-enter.
        argv = self._queue_enter_argv(kind="reply") + ["--submit-delay", "0"]
        argv[argv.index("claude")] = "codex"
        result, sent, stdout, _stderr, pane_text = self.run_handoff_with_fake_tmux(
            argv,
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "node",
                "cwd": "/repo",
                "window_name": "codex",
                "pane_active": "1",
            },
        )

        self.assertEqual(0, result)
        self.assertIn(
            "[mozyo:handoff:source=asana:task=T1:comment=C1:kind=reply:to=codex]",
            pane_text,
        )
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("sent", outcome["status"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])

    def test_queue_enter_step12_admits_versioned_native_binary_weak_identity(self) -> None:
        # Step 12 weak identity (Open Question 8 in the contract): a versioned
        # native binary basename (e.g. `1.0.32-arm64`) is receiver-agnostic by
        # design. queue-enter admits it because the pane is at least running
        # *some* versioned native agent binary, and Step 9 + Layer A operator
        # discipline carry cross-binding protection in this branch. The
        # contract explicitly concedes the weakness; do not pretend Step 12
        # confirms receiver identity here.
        result, sent, stdout, _stderr, pane_text = self.run_handoff_with_fake_tmux(
            self._queue_enter_argv() + ["--submit-delay", "0"],
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "1.0.32-arm64",
                "cwd": "/repo",
                "window_name": "claude",
                "pane_active": "1",
            },
        )

        self.assertEqual(0, result)
        self.assertIn(
            "[mozyo:handoff:source=asana:task=T1:comment=C1:kind=implementation_request:to=claude]",
            pane_text,
        )
        self.assertEqual(("send-keys", "-t", "%2", "Enter"), sent[-1])
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("sent", outcome["status"])
        self.assertEqual(MODE_QUEUE_ENTER, outcome["mode"])

    def test_strict_standard_admits_cross_receiver_process_unchanged(self) -> None:
        # Regression: neither the v0.3 per-receiver process gate nor the v0.4
        # default flip to queue-enter must bleed into strict `--mode standard`.
        # Strict's behavior (admit any agent-looking process, rely on
        # marker_timeout + C-u rollback) stays as-is. This test pins that
        # boundary by sending strict to a pane whose foreground process is
        # `claude` while --to=codex; strict admits typing and rolls back on
        # marker miss, as it already did pre-v0.3.
        argv = [
            "handoff",
            "send",
            "--to",
            "codex",
            "--source",
            "asana",
            "--kind",
            "review_result",
            "--task-id",
            "T1",
            "--comment-id",
            "C1",
            "--target",
            "%2",
            "--mode",
            "standard",
            "--landing-timeout",
            "0.01",
            "--submit-delay",
            "0",
        ]
        result, sent, stdout, _stderr, _pane_text = self.run_handoff_with_fake_tmux(
            argv,
            pane={
                "id": "%2",
                "location": "agents:0.1",
                "command": "claude",
                "cwd": "/repo",
                "window_name": "codex",
                "pane_active": "1",
            },
            captures=["", "", ""],
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        # Strict still types and then rolls back; the new v0.3 gates must not
        # have fired here.
        self.assertTrue(any(call[:4] == ("send-keys", "-t", "%2", "-l") for call in sent))
        self.assertIn(("send-keys", "-t", "%2", "C-u"), sent)
        outcome = self._outcome_from_stdout(stdout)
        self.assertEqual("blocked", outcome["status"])
        self.assertEqual("marker_timeout", outcome["reason"])
        self.assertEqual(MODE_STANDARD, outcome["mode"])

    # --- projection / wording ------------------------------------------------------

    def test_project_last_input_for_queue_enter_matches_strict_sent_ok(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        outcome_strict = make_outcome(
            status="sent",
            reason="ok",
            receiver="claude",
            target="%2",
            anchor=anchor,
            mode=MODE_STANDARD,
            kind="reply",
            notification_marker="[m]",
        )
        outcome_queue_enter = make_outcome(
            status="sent",
            reason="queue_enter",
            receiver="claude",
            target="%2",
            anchor=anchor,
            mode=MODE_QUEUE_ENTER,
            kind="reply",
            notification_marker="[m]",
        )

        proj_strict = project_last_input(
            outcome_strict, submitted_at="2026-05-13T17:30:00Z"
        )
        proj_queue = project_last_input(
            outcome_queue_enter, submitted_at="2026-05-13T17:30:00Z"
        )

        # Per contract, queue-enter projection MUST equal strict sent/ok
        # projection. Returning ack_status="unobserved" or submitted_at=None
        # would violate the upstream inspector contract derive rule.
        self.assertEqual(proj_strict, proj_queue)
        assert proj_queue is not None
        self.assertEqual("submitted", proj_queue.ack_status)
        self.assertEqual("2026-05-13T17:30:00Z", proj_queue.submitted_at)
        self.assertIsNone(proj_queue.acknowledged_at)

    def test_project_last_input_for_queue_enter_mode_with_ok_reason_also_matches(self) -> None:
        # Marker-observed queue-enter (status=sent, reason=ok, mode=queue-enter)
        # must also project identically to strict sent/ok.
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        outcome = make_outcome(
            status="sent",
            reason="ok",
            receiver="claude",
            target="%2",
            anchor=anchor,
            mode=MODE_QUEUE_ENTER,
            kind="reply",
            notification_marker="[m]",
        )
        projection = project_last_input(outcome, submitted_at="2026-05-13T17:30:00Z")
        assert projection is not None
        self.assertEqual("submitted", projection.ack_status)
        self.assertEqual("2026-05-13T17:30:00Z", projection.submitted_at)

    def test_make_outcome_for_queue_enter_keeps_receiver_owned_next_action(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        outcome = make_outcome(
            status="sent",
            reason="queue_enter",
            receiver="codex",
            target="%2",
            anchor=anchor,
            mode=MODE_QUEUE_ENTER,
            kind="implementation_request",
            notification_marker="[m]",
        )

        owner, action = next_action_for(outcome.status, outcome.reason, outcome.receiver)

        self.assertEqual("receiver", owner)
        self.assertEqual("receiver", outcome.next_action_owner)
        self.assertIn("durable anchor", action)
        self.assertIn("durable anchor", outcome.next_action)

    def test_delivery_record_for_queue_enter_unobserved_includes_operator_note(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        outcome = make_outcome(
            status="sent",
            reason="queue_enter",
            receiver="codex",
            target="%111",
            anchor=anchor,
            mode=MODE_QUEUE_ENTER,
            kind="review_request",
            notification_marker="[mozyo:handoff:source=asana:task=T1:comment=C1:kind=review_request:to=codex]",
        )

        record = build_delivery_record(outcome)

        self.assertIn(
            "Delivery result — sent (queue-enter, marker unobserved)", record
        )
        self.assertIn("Mode: `queue-enter`", record)
        self.assertIn("Status: `sent` (reason: `queue_enter`)", record)
        # Receiver-side primary contract is identical to strict sent.
        self.assertIn("Next action owner: `receiver`", record)
        self.assertIn("Receiver-side contract", record)
        self.assertIn("durable anchor", record)
        # Operator note is the only place the queue-enter fallback is surfaced.
        self.assertIn("Operator note", record)
        self.assertIn("--mode standard", record)
        self.assertIn("not observed before Enter", record)

    def test_delivery_record_for_queue_enter_observed_marks_rail_but_no_operator_note(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        outcome = make_outcome(
            status="sent",
            reason="ok",
            receiver="claude",
            target="%2",
            anchor=anchor,
            mode=MODE_QUEUE_ENTER,
            kind="implementation_request",
            notification_marker="[m]",
        )

        record = build_delivery_record(outcome)

        self.assertIn(
            "Delivery result — sent (queue-enter, marker observed)", record
        )
        self.assertIn("Mode: `queue-enter`", record)
        self.assertIn("Next action owner: `receiver`", record)
        # No operator escalation note when the marker was actually observed.
        self.assertNotIn("Operator note", record)


class DeliveryRecordTest(unittest.TestCase):
    """Coverage for the durable delivery-record generator.

    The structured outcome contract guarantees every field the record needs
    (after the source-preservation fix on task ``1214760548032349``), so
    ``build_delivery_record`` must be a pure function over a ``DeliveryOutcome``
    and produce a deterministic, source-of-truth-pastable text block for every
    status/reason permutation the primitive can emit.
    """

    def _sent_outcome(self):
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        return make_outcome(
            status="sent",
            reason="ok",
            receiver="claude",
            target="%2",
            anchor=anchor,
            mode=MODE_STANDARD,
            kind="implementation_request",
            notification_marker="[mozyo:handoff:source=asana:task=T1:comment=C1:kind=implementation_request:to=claude]",
        )

    def test_sent_record_includes_receiver_target_marker_anchor_and_contract(self) -> None:
        record = build_delivery_record(self._sent_outcome())

        self.assertIn("Delivery result — sent", record)
        self.assertIn("Receiver: `claude`", record)
        self.assertIn("Source: `asana`", record)
        self.assertIn("Kind: `implementation_request`", record)
        self.assertIn("Mode: `standard`", record)
        self.assertIn("Target pane: `%2`", record)
        self.assertIn(
            "Notification marker: "
            "`[mozyo:handoff:source=asana:task=T1:comment=C1:kind=implementation_request:to=claude]`",
            record,
        )
        self.assertIn("Asana task T1", record)
        self.assertIn("comment C1", record)
        self.assertIn("Landing marker observed", record)
        self.assertIn("Enter was pressed", record)
        self.assertIn("Next action owner: `receiver`", record)
        self.assertIn("Receiver-side contract", record)
        self.assertIn("durable anchor", record)

    def test_sent_record_includes_command_line_when_supplied(self) -> None:
        record = build_delivery_record(
            self._sent_outcome(),
            command="mozyo-bridge handoff send --to claude --source asana --task-id T1 --comment-id C1 --kind implementation_request",
        )

        self.assertIn(
            "- Command: `mozyo-bridge handoff send --to claude --source asana "
            "--task-id T1 --comment-id C1 --kind implementation_request`",
            record,
        )

    def test_pending_input_record_labels_operator_action(self) -> None:
        anchor = normalize_anchor("redmine", issue="9020", journal="46005")
        outcome = make_outcome(
            status="pending_input",
            reason="ok",
            receiver="codex",
            target="%111",
            anchor=anchor,
            mode=MODE_PENDING,
            kind="reply",
            notification_marker="[mozyo:handoff:source=redmine:issue=9020:journal=46005:kind=reply:to=codex]",
        )

        record = build_delivery_record(outcome)

        self.assertIn("Delivery result — pending input", record)
        self.assertIn("Mode: `pending`", record)
        self.assertIn("intentionally not pressed", record)
        self.assertIn("Redmine #9020", record)
        self.assertIn("journal #46005", record)
        self.assertIn("Next action owner: `operator`", record)
        self.assertNotIn("Receiver-side contract", record)

    def test_marker_timeout_record_states_rollback_and_sender_action(self) -> None:
        anchor = normalize_anchor("asana", task_id="T1", comment_id="C1")
        outcome = make_outcome(
            status="blocked",
            reason="marker_timeout",
            receiver="claude",
            target="%2",
            anchor=anchor,
            mode=MODE_STANDARD,
            kind="review_result",
            notification_marker="[marker]",
        )

        record = build_delivery_record(outcome)

        self.assertIn("Delivery result — not delivered (marker_timeout)", record)
        self.assertIn("input was cleared via C-u", record)
        self.assertIn("Enter was not pressed", record)
        self.assertIn("Receiver-side contract", record)
        self.assertIn("manually if action is still required", record)
        self.assertIn("Next action owner: `sender`", record)
        self.assertIn("un-notified", record)
        # Asana task 1214779823377861: the durable record must also surface
        # the ordered fallback path so an auditor (or any agent re-reading
        # the comment later) sees the retry budget before the un-notified
        # terminal label.
        self.assertIn("- Fallback path:", record)
        self.assertIn("mozyo-bridge read claude", record)
        self.assertIn("mozyo-bridge message claude", record)
        self.assertIn("--no-submit", record)
        self.assertIn("Notification fails", record)

    def test_target_unavailable_record_lacks_target_and_marker(self) -> None:
        outcome = make_outcome(
            status="blocked",
            reason="target_unavailable",
            receiver="claude",
            target=None,
            anchor=normalize_anchor("asana", task_id="T1", comment_id="C1"),
            mode=MODE_STANDARD,
            kind="reply",
            notification_marker=None,
        )

        record = build_delivery_record(outcome)

        self.assertIn("Delivery result — not delivered (target_unavailable)", record)
        self.assertIn("Target pane: `—`", record)
        self.assertIn("Notification marker: `—`", record)
        self.assertIn("no notification was typed", record)
        self.assertIn("Next action owner: `sender`", record)
        self.assertIn("mozyo-bridge init claude", record)

    def test_target_not_agent_record_keeps_target_but_no_marker(self) -> None:
        outcome = make_outcome(
            status="blocked",
            reason="target_not_agent",
            receiver="claude",
            target="%2",
            anchor=normalize_anchor("asana", task_id="T1", comment_id="C1"),
            mode=MODE_STANDARD,
            kind="reply",
            notification_marker=None,
        )

        record = build_delivery_record(outcome)

        self.assertIn("Delivery result — not delivered (target_not_agent)", record)
        self.assertIn("Target pane: `%2`", record)
        self.assertIn("Notification marker: `—`", record)
        self.assertIn("not running an agent process", record)
        self.assertIn("--force", record)
        self.assertIn("Next action owner: `sender`", record)

    def test_invalid_anchor_record_preserves_source_without_anchor_payload(self) -> None:
        outcome = make_outcome(
            status="blocked",
            reason="invalid_anchor",
            receiver="claude",
            target=None,
            anchor=None,
            mode=MODE_STANDARD,
            kind="reply",
            notification_marker=None,
            source="asana",
        )

        record = build_delivery_record(outcome)

        self.assertIn("Delivery result — not delivered (invalid_anchor)", record)
        self.assertIn("Source: `asana`", record)
        self.assertIn("Durable anchor: —", record)
        self.assertIn("aborted before resolving the receiver pane", record)
        self.assertIn("supply a valid durable anchor", record)

    def test_invalid_args_record_states_arg_validation_failure(self) -> None:
        outcome = make_outcome(
            status="blocked",
            reason="invalid_args",
            receiver="codex",
            target=None,
            anchor=None,
            mode=MODE_STANDARD,
            kind=None,
            notification_marker=None,
            source="redmine",
        )

        record = build_delivery_record(outcome)

        self.assertIn("Delivery result — not delivered (invalid_args)", record)
        self.assertIn("Source: `redmine`", record)
        self.assertIn("Kind: `—`", record)
        self.assertIn("missing or invalid", record)
        self.assertIn("Next action owner: `sender`", record)

    def test_record_is_deterministic_for_same_outcome(self) -> None:
        outcome = self._sent_outcome()

        self.assertEqual(build_delivery_record(outcome), build_delivery_record(outcome))


class HandoffRecordEmissionTest(unittest.TestCase):
    """The orchestrator must emit the delivery record alongside the structured
    outcome so callers do not have to invent phrasing or re-read the pane to
    describe what happened.
    """

    def run_handoff_with_fake_tmux(
        self,
        argv: list[str],
        captures: list[str] | None = None,
        allow_exit: bool = False,
        pane: dict[str, str] | None = None,
    ):
        # Mirrors HandoffOrchestratorTest's helper so we can drive the CLI end
        # to end without launching tmux.
        parser = build_parser()
        args = parser.parse_args(argv)
        sent: list[tuple[str, ...]] = []
        pane_text = ""
        forced_captures = captures is not None
        capture_outputs = list(captures or [])

        def fake_capture(_target: str, _lines: int) -> str:
            if capture_outputs:
                return capture_outputs.pop(0)
            if forced_captures:
                return ""
            return pane_text

        def fake_run_tmux(*tmux_args: str, check: bool = True):
            nonlocal pane_text
            if tmux_args[:4] == ("send-keys", "-t", "%2", "-l"):
                pane_text += tmux_args[-1]
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            if tmux_args[:3] == ("send-keys", "-t", "%2"):
                sent.append(tmux_args)
                return argparse.Namespace(returncode=0, stdout="", stderr="")
            raise AssertionError(f"unexpected tmux call: {tmux_args}")

        default_pane = {
            "id": "%2",
            "location": "agents:0.1",
            "command": "node",
            "cwd": "/repo",
            "window_name": "claude",
        }
        pane_value = pane if pane is not None else default_pane

        with patch("mozyo_bridge.application.commands.require_tmux"), \
            patch("mozyo_bridge.application.commands.capture_pane", side_effect=fake_capture), \
            patch("mozyo_bridge.application.commands.run_tmux", side_effect=fake_run_tmux), \
            patch("mozyo_bridge.application.commands.time.sleep"), \
            patch("mozyo_bridge.domain.pane_resolver.validate_target"), \
            patch("mozyo_bridge.domain.pane_resolver.pane_lines", return_value=[pane_value]), \
            contextlib.redirect_stdout(io.StringIO()) as stdout, \
            contextlib.redirect_stderr(io.StringIO()):
            try:
                result = args.func(args)
            except SystemExit as exc:
                if not allow_exit:
                    raise
                result = exc

        return result, sent, stdout.getvalue()

    def test_standard_mode_emits_record_then_json_outcome_by_default(self) -> None:
        # Pinned to `--mode standard` so the record/JSON ordering is verified
        # against the strict-rail happy path (queue-enter has its own coverage
        # in `RelaxedQueueEnterRailTest`). v0.4 default is queue-enter.
        result, _sent, stdout = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--submit-delay",
                "0",
            ]
        )

        self.assertEqual(0, result)
        self.assertIn("Delivery result — sent", stdout)
        self.assertIn("Asana task T1", stdout)
        self.assertIn("Next action owner: `receiver`", stdout)
        json_lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertEqual(1, len(json_lines), f"expected exactly one JSON outcome line, got: {stdout!r}")
        outcome = json.loads(json_lines[-1])
        self.assertEqual("sent", outcome["status"])

    def test_record_format_json_suppresses_markdown_record(self) -> None:
        # Pinned to `--mode standard` so the format-suppression test is not
        # eclipsed by the v0.4 queue-enter force-rejection.
        result, _sent, stdout = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--submit-delay",
                "0",
                "--record-format",
                "json",
            ]
        )

        self.assertEqual(0, result)
        self.assertNotIn("Delivery result —", stdout)
        json_lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertEqual(1, len(json_lines))

    def test_record_format_text_suppresses_json_outcome(self) -> None:
        # Pinned to `--mode standard` so the format-suppression test is not
        # eclipsed by the v0.4 queue-enter force-rejection.
        result, _sent, stdout = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "implementation_request",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--submit-delay",
                "0",
                "--record-format",
                "text",
            ]
        )

        self.assertEqual(0, result)
        self.assertIn("Delivery result — sent", stdout)
        json_lines = [line for line in stdout.splitlines() if line.strip().startswith("{")]
        self.assertEqual([], json_lines)

    def test_record_command_is_included_when_provided(self) -> None:
        # Pinned to `--mode standard` so the record-command trailer is verified
        # against the strict-rail happy path without the v0.4 queue-enter
        # force-rejection.
        result, _sent, stdout = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--comment-id",
                "C1",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--submit-delay",
                "0",
                "--record-command",
                "mozyo-bridge handoff send --to claude --source asana --kind reply",
            ]
        )

        self.assertEqual(0, result)
        self.assertIn(
            "- Command: `mozyo-bridge handoff send --to claude --source asana --kind reply`",
            stdout,
        )

    def test_marker_timeout_emits_record_describing_rollback(self) -> None:
        # Pinned to `--mode standard` so the rollback narrative is verified on
        # the strict rail. v0.4 queue-enter does not roll back on marker miss;
        # that contract is covered in `RelaxedQueueEnterRailTest`.
        result, sent, stdout = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "review_result",
                "--task-id",
                "T1",
                "--anchor-url",
                "https://example/x",
                "--target",
                "%2",
                "--mode",
                "standard",
                "--landing-timeout",
                "0.01",
                "--submit-delay",
                "0",
            ],
            captures=["", "", ""],
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertIn(("send-keys", "-t", "%2", "C-u"), sent)
        self.assertIn("Delivery result — not delivered (marker_timeout)", stdout)
        self.assertIn("input was cleared via C-u", stdout)
        self.assertIn("Next action owner: `sender`", stdout)

    def test_invalid_anchor_emits_record_preserving_source(self) -> None:
        # Pinned to `--mode standard` so the invalid_anchor narrative is not
        # eclipsed by the v0.4 queue-enter force-rejection (which would emit
        # `invalid_args` first).
        result, _sent, stdout = self.run_handoff_with_fake_tmux(
            [
                "handoff",
                "send",
                "--to",
                "claude",
                "--source",
                "asana",
                "--kind",
                "reply",
                "--task-id",
                "T1",
                "--target",
                "%2",
                "--mode",
                "standard",
            ],
            allow_exit=True,
        )

        self.assertIsInstance(result, SystemExit)
        self.assertIn("Delivery result — not delivered (invalid_anchor)", stdout)
        self.assertIn("Source: `asana`", stdout)
        self.assertIn("Durable anchor: —", stdout)


class PluginMarketplaceTest(unittest.TestCase):
    """Guardrails for the Claude plugin marketplace packaging.

    The repo ships a `.claude-plugin/marketplace.json` at the root and a plugin
    at `plugins/mozyo-bridge-agent/`. The plugin bundles its own copy of the
    shared skill body so it works after Claude Code copies the plugin
    directory into its cache (plugin install cannot reach outside the plugin
    root). This test class enforces:

    1. Marketplace and plugin manifests load and carry the required fields.
    2. The plugin skill mirror at `plugins/mozyo-bridge-agent/skills/mozyo-bridge-agent/`
       stays in lockstep with the canonical `skills/mozyo-bridge-agent/`. Drift
       must be resolved by running `scripts/sync_plugin_skill.sh`, not by
       hand-editing the mirror.
    """

    def setUp(self) -> None:
        self.marketplace_path = ROOT / ".claude-plugin" / "marketplace.json"
        self.plugin_manifest_path = (
            ROOT / "plugins" / "mozyo-bridge-agent" / ".claude-plugin" / "plugin.json"
        )
        self.canonical_skill_dir = ROOT / "skills" / "mozyo-bridge-agent"
        self.plugin_skill_dir = (
            ROOT / "plugins" / "mozyo-bridge-agent" / "skills" / "mozyo-bridge-agent"
        )

    def test_marketplace_manifest_present_and_valid(self) -> None:
        self.assertTrue(
            self.marketplace_path.is_file(),
            f"expected marketplace manifest at {self.marketplace_path}",
        )
        data = json.loads(self.marketplace_path.read_text(encoding="utf-8"))
        # Required top-level fields per
        # https://code.claude.com/docs/en/plugin-marketplaces#marketplace-schema
        self.assertIn("name", data)
        self.assertIn("owner", data)
        self.assertIn("plugins", data)
        self.assertIsInstance(data["owner"], dict)
        self.assertIn("name", data["owner"], "owner.name is required")
        self.assertIsInstance(data["plugins"], list)
        self.assertEqual(
            "mozyo-bridge",
            data["name"],
            "marketplace name pins the install command `@mozyo-bridge` suffix",
        )
        # Marketplace name must not impersonate Anthropic-reserved names.
        reserved = {
            "claude-code-marketplace",
            "claude-code-plugins",
            "claude-plugins-official",
            "anthropic-marketplace",
            "anthropic-plugins",
            "agent-skills",
            "knowledge-work-plugins",
            "life-sciences",
        }
        self.assertNotIn(data["name"], reserved)

    def test_marketplace_lists_mozyo_bridge_agent_plugin(self) -> None:
        data = json.loads(self.marketplace_path.read_text(encoding="utf-8"))
        names = [entry.get("name") for entry in data["plugins"]]
        self.assertIn("mozyo-bridge-agent", names)
        entry = next(p for p in data["plugins"] if p.get("name") == "mozyo-bridge-agent")
        self.assertIn("source", entry)
        # Relative paths must start with "./" per plugin source rules.
        source = entry["source"]
        if isinstance(source, str):
            self.assertTrue(
                source.startswith("./"),
                "relative plugin source must start with './'",
            )
            # When metadata.pluginRoot is set, the source is resolved under it.
            plugin_root = data.get("metadata", {}).get("pluginRoot")
            if plugin_root:
                base = (
                    ROOT / plugin_root.lstrip("./").rstrip("/")
                    if plugin_root.startswith("./")
                    else ROOT / plugin_root
                )
                resolved = (base / source.lstrip("./").rstrip("/")).resolve()
            else:
                resolved = (ROOT / source.lstrip("./").rstrip("/")).resolve()
            self.assertTrue(
                resolved.is_dir(),
                f"plugin source path does not resolve to a directory: {resolved}",
            )

    def test_plugin_manifest_present_and_valid(self) -> None:
        self.assertTrue(
            self.plugin_manifest_path.is_file(),
            f"expected plugin manifest at {self.plugin_manifest_path}",
        )
        data = json.loads(self.plugin_manifest_path.read_text(encoding="utf-8"))
        # `name` is the only required plugin manifest field.
        self.assertIn("name", data)
        self.assertEqual("mozyo-bridge-agent", data["name"])

    def test_plugin_skill_mirror_matches_canonical(self) -> None:
        """The plugin's skill copy must be byte-identical to the canonical
        skill body. Run `scripts/sync_plugin_skill.sh` to regenerate the mirror
        whenever you edit `skills/mozyo-bridge-agent/`."""

        def relative_files(base: Path) -> dict[str, str]:
            mapping: dict[str, str] = {}
            for path in base.rglob("*"):
                if not path.is_file():
                    continue
                rel = path.relative_to(base).as_posix()
                mapping[rel] = hashlib.sha256(path.read_bytes()).hexdigest()
            return mapping

        self.assertTrue(
            self.canonical_skill_dir.is_dir(),
            f"canonical skill missing: {self.canonical_skill_dir}",
        )
        self.assertTrue(
            self.plugin_skill_dir.is_dir(),
            f"plugin skill mirror missing: {self.plugin_skill_dir}",
        )

        canonical = relative_files(self.canonical_skill_dir)
        mirror = relative_files(self.plugin_skill_dir)

        missing = sorted(set(canonical) - set(mirror))
        extra = sorted(set(mirror) - set(canonical))
        differing = sorted(
            rel for rel in canonical.keys() & mirror.keys() if canonical[rel] != mirror[rel]
        )

        hint = "run scripts/sync_plugin_skill.sh to regenerate the mirror"
        self.assertFalse(missing, f"plugin mirror missing files: {missing}; {hint}")
        self.assertFalse(extra, f"plugin mirror has unexpected files: {extra}; {hint}")
        self.assertFalse(
            differing, f"plugin mirror content differs from canonical: {differing}; {hint}"
        )

    def test_plugin_skill_mirror_has_skill_md(self) -> None:
        self.assertTrue(
            (self.plugin_skill_dir / "SKILL.md").is_file(),
            "plugin must ship SKILL.md so Claude Code can discover the skill after install",
        )


class ReleaseHelperParserTest(unittest.TestCase):
    """The contract-admitted release helper subcommands must round-trip
    through ``build_parser``. Argparse will raise SystemExit if a required
    flag is missing or a subparser was wired wrong, so this is a cheap
    structural check that ``release check`` / ``release workflow`` exist as
    documented in `release-helper-contract.md`.
    """

    def parse(self, *argv: str) -> argparse.Namespace:
        return build_parser().parse_args(list(argv))

    def test_release_check_tree(self) -> None:
        args = self.parse("release", "check", "tree")
        from mozyo_bridge.application.release import cmd_release_check_tree

        self.assertIs(args.func, cmd_release_check_tree)

    def test_release_check_scaffold(self) -> None:
        args = self.parse("release", "check", "scaffold")
        from mozyo_bridge.application.release import cmd_release_check_scaffold

        self.assertIs(args.func, cmd_release_check_scaffold)

    def test_release_check_artifact(self) -> None:
        args = self.parse("release", "check", "artifact")
        from mozyo_bridge.application.release import cmd_release_check_artifact

        self.assertIs(args.func, cmd_release_check_artifact)

    def test_release_check_workflow_requires_run_id(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "check", "workflow")
        args = self.parse("release", "check", "workflow", "--run-id", "42")
        from mozyo_bridge.application.release import cmd_release_check_workflow

        self.assertIs(args.func, cmd_release_check_workflow)
        self.assertEqual("42", args.run_id)

    def test_release_workflow_runs_requires_workflow(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "workflow", "runs")
        args = self.parse("release", "workflow", "runs", "--workflow", "testpypi.yml")
        from mozyo_bridge.application.release import cmd_release_workflow_runs

        self.assertIs(args.func, cmd_release_workflow_runs)
        self.assertEqual("testpypi.yml", args.workflow)
        self.assertEqual(10, args.limit)

    def test_release_workflow_wait_requires_run_id_and_timeout(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "workflow", "wait", "--run-id", "42")
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "workflow", "wait", "--timeout", "10")
        args = self.parse(
            "release",
            "workflow",
            "wait",
            "--run-id",
            "42",
            "--timeout",
            "30",
        )
        from mozyo_bridge.application.release import cmd_release_workflow_wait

        self.assertIs(args.func, cmd_release_workflow_wait)
        self.assertEqual("42", args.run_id)
        self.assertEqual(30.0, args.timeout)

    def test_release_check_subparser_requires_subcommand(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release")
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "check")
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "workflow")


class ReleaseCheckTreeTest(unittest.TestCase):
    """`release check tree` runs three git probes inside a real git repo and
    is strict-fail on the git grep blocker pattern. The tests build a tiny
    git checkout with `subprocess`, then verify both clean and blocker exit
    codes against real git behavior — no subprocess mocking, so the regex
    and pathspec wiring stay honest.
    """

    def _init_repo(self, root: Path) -> None:
        env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "test",
            "GIT_AUTHOR_EMAIL": "test@example.com",
            "GIT_COMMITTER_NAME": "test",
            "GIT_COMMITTER_EMAIL": "test@example.com",
        }
        subprocess.run(["git", "init", "-q", str(root)], check=True)
        subprocess.run(
            ["git", "-C", str(root), "commit", "--allow-empty", "-m", "init", "-q"],
            check=True,
            env=env,
        )

    def _commit_file(self, root: Path, rel: str, body: str) -> None:
        env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "test",
            "GIT_AUTHOR_EMAIL": "test@example.com",
            "GIT_COMMITTER_NAME": "test",
            "GIT_COMMITTER_EMAIL": "test@example.com",
        }
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(body, encoding="utf-8")
        subprocess.run(["git", "-C", str(root), "add", rel], check=True)
        subprocess.run(
            ["git", "-C", str(root), "commit", "-m", f"add {rel}", "-q"],
            check=True,
            env=env,
        )

    def test_clean_tree_returns_zero(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._init_repo(root)
            self._commit_file(root, "README.md", "Hello world\n")
            args = argparse.Namespace(repo=str(root))
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_check_tree(args)
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            self.assertIn("result: clean", out.getvalue())

    def test_personal_path_in_tracked_file_is_blocker(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._init_repo(root)
            personal_path = "/Users" + "/example/project"
            self._commit_file(root, "AGENTS.md", f"see {personal_path} for context\n")
            args = argparse.Namespace(repo=str(root))
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_check_tree(args)
            self.assertEqual(release_mod.EXIT_BLOCKER, rc)
            self.assertIn(personal_path, out.getvalue())
            self.assertIn("result: blocker", out.getvalue())

    def test_secret_value_shape_in_tracked_file_is_blocker(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._init_repo(root)
            fake_secret = "REDMINE" + "_API_KEY=" + "abc123"
            self._commit_file(root, "AGENTS.md", f"{fake_secret}\n")
            args = argparse.Namespace(repo=str(root))
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_check_tree(args)
            self.assertEqual(release_mod.EXIT_BLOCKER, rc)
            self.assertIn(fake_secret, out.getvalue())
            self.assertIn("result: blocker", out.getvalue())

    def test_secret_guidance_words_do_not_block_tree_check(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._init_repo(root)
            self._commit_file(
                root,
                "README.md",
                "Do not store credentials, tokens, secrets, or passwords.\n",
            )
            args = argparse.Namespace(repo=str(root))
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_check_tree(args)
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            self.assertIn("result: clean", out.getvalue())

    def test_pathspec_excludes_skip_generated_trees(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._init_repo(root)
            # Files inside excluded pathspecs (build/, dist/, tmp/) must not
            # trigger the blocker even if they contain personal paths, so
            # the helper does not flag artifacts that will be rebuilt or
            # excluded from publication anyway.
            personal_path = "/Users" + "/example/leak"
            self._commit_file(root, "build/log.txt", f"{personal_path}\n")
            args = argparse.Namespace(repo=str(root))
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_check_tree(args)
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            self.assertIn("result: clean", out.getvalue())


class ReleaseCheckScaffoldTest(unittest.TestCase):
    def test_scaffold_check_uses_isolated_home_and_targets(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with contextlib.redirect_stdout(io.StringIO()) as out:
            rc = release_mod.cmd_release_check_scaffold(argparse.Namespace())
        # Fresh scaffold smoke runs against an isolated home / target every
        # invocation. On a healthy package it must report clean for all
        # presets and exit zero.
        self.assertEqual(release_mod.EXIT_CLEAN, rc, msg=out.getvalue())
        text = out.getvalue()
        from mozyo_bridge.scaffold.rules import PRESETS

        for preset in PRESETS:
            self.assertIn(f"scaffold status: clean ({preset})", text)


class ReleaseCheckArtifactTest(unittest.TestCase):
    """The `release check` family is contractually read-only: invocations
    must not mutate the repo worktree (including the repo's ``dist/``
    directory). This test locks in that invariant by setting up a sentinel
    file in a fake repo's dist/, mocking ``sys.executable -m build``, and asserting
    (a) the sentinel survives, (b) ``--outdir`` is passed to build, and
    (c) the outdir lives outside the repo root.
    """

    def test_artifact_secret_pattern_matches_values_not_guidance_words(self) -> None:
        from mozyo_bridge.application import release as release_mod

        pattern = re.compile(release_mod._artifact_grep_pattern())
        fake_secret = "REDMINE" + "_API_KEY=" + "abc123"
        self.assertIsNone(pattern.search("Do not store tokens or secrets."))
        self.assertIsNotNone(pattern.search(fake_secret))

    def test_does_not_mutate_repo_dist_directory(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as repo_str:
            repo = Path(repo_str).resolve()
            (repo / "dist").mkdir()
            sentinel = repo / "dist" / "preexisting.whl"
            sentinel.write_bytes(b"preexisting")

            recorded: list[dict] = []

            def fake_run(argv, cwd=None, check=False, env=None):
                recorded.append(
                    {"argv": list(argv), "cwd": str(cwd) if cwd else None}
                )
                # Pretend build succeeded but wrote nothing to the outdir.
                # The helper's no-mutation invariant is what we're testing;
                # producing no artifacts just routes us through the
                # `no artifacts` blocker path, which is fine for this test.
                outdir = argv[argv.index("--outdir") + 1]
                Path(outdir).mkdir(parents=True, exist_ok=True)
                return subprocess.CompletedProcess(
                    args=argv, returncode=0, stdout="", stderr=""
                )

            with patch.object(release_mod, "_run", side_effect=fake_run):
                with contextlib.redirect_stdout(io.StringIO()):
                    rc = release_mod.cmd_release_check_artifact(
                        argparse.Namespace(repo=str(repo))
                    )

            self.assertTrue(
                sentinel.exists(),
                "release check artifact mutated the repo's dist/ directory",
            )
            build_calls = [c for c in recorded if "build" in c["argv"]]
            self.assertEqual(1, len(build_calls), msg=recorded)
            argv = build_calls[0]["argv"]
            self.assertEqual(sys.executable, argv[0])
            self.assertIn("--outdir", argv)
            outdir = Path(argv[argv.index("--outdir") + 1]).resolve()
            try:
                outdir.relative_to(repo)
                inside_repo = True
            except ValueError:
                inside_repo = False
            self.assertFalse(
                inside_repo,
                f"--outdir {outdir} must not live inside repo {repo}",
            )
            # rc is blocker because the mocked build produced no artifacts;
            # the load-bearing assertions are the sentinel + outdir checks
            # above.
            self.assertEqual(release_mod.EXIT_BLOCKER, rc)


class ReleaseCheckWorkflowTest(unittest.TestCase):
    def test_success_exits_zero(self) -> None:
        from mozyo_bridge.application import release as release_mod

        payload = {
            "status": "completed",
            "conclusion": "success",
            "workflowName": "Test",
            "headSha": "abc123",
            "url": "https://example/run/42",
        }
        with patch.object(release_mod, "_gh_run_view", return_value=payload):
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_check_workflow(
                    argparse.Namespace(run_id="42")
                )
        self.assertEqual(release_mod.EXIT_CLEAN, rc)
        self.assertIn("status: completed", out.getvalue())
        self.assertIn("conclusion: success", out.getvalue())

    def test_failure_exits_non_zero(self) -> None:
        from mozyo_bridge.application import release as release_mod

        payload = {
            "status": "completed",
            "conclusion": "failure",
            "workflowName": "Test",
            "headSha": "abc123",
            "url": "https://example/run/42",
        }
        with patch.object(release_mod, "_gh_run_view", return_value=payload):
            with contextlib.redirect_stdout(io.StringIO()):
                rc = release_mod.cmd_release_check_workflow(
                    argparse.Namespace(run_id="42")
                )
        self.assertEqual(release_mod.EXIT_BLOCKER, rc)

    def test_in_progress_exits_non_zero(self) -> None:
        from mozyo_bridge.application import release as release_mod

        payload = {
            "status": "in_progress",
            "conclusion": None,
            "workflowName": "Test",
            "headSha": "abc123",
            "url": "https://example/run/42",
        }
        with patch.object(release_mod, "_gh_run_view", return_value=payload):
            with contextlib.redirect_stdout(io.StringIO()):
                rc = release_mod.cmd_release_check_workflow(
                    argparse.Namespace(run_id="42")
                )
        self.assertEqual(release_mod.EXIT_BLOCKER, rc)


class ReleaseWorkflowRunsTest(unittest.TestCase):
    def test_runs_listing_renders_columns(self) -> None:
        from mozyo_bridge.application import release as release_mod

        runs = [
            {
                "databaseId": 1,
                "createdAt": "2026-05-14T00:00:00Z",
                "status": "completed",
                "conclusion": "success",
                "headSha": "abc",
                "url": "https://example/1",
            },
            {
                "databaseId": 2,
                "createdAt": "2026-05-14T01:00:00Z",
                "status": "in_progress",
                "conclusion": None,
                "headSha": "def",
                "url": "https://example/2",
            },
        ]
        completed = subprocess.CompletedProcess(
            args=[], returncode=0, stdout=json.dumps(runs), stderr=""
        )
        with patch.object(release_mod, "_run", return_value=completed):
            with patch.object(release_mod, "_require_command"):
                with contextlib.redirect_stdout(io.StringIO()) as out:
                    rc = release_mod.cmd_release_workflow_runs(
                        argparse.Namespace(workflow="testpypi.yml", limit=10)
                    )
        self.assertEqual(release_mod.EXIT_CLEAN, rc)
        text = out.getvalue()
        self.assertIn("RUN_ID\tCREATED_AT\tSTATUS\tCONCLUSION\tHEAD_SHA\tHTML_URL", text)
        self.assertIn("1\t2026-05-14T00:00:00Z\tcompleted\tsuccess\tabc\thttps://example/1", text)
        self.assertIn("2\t2026-05-14T01:00:00Z\tin_progress\t\tdef\thttps://example/2", text)


class ReleaseWorkflowWaitTest(unittest.TestCase):
    def test_wait_returns_zero_when_run_completes_successfully(self) -> None:
        from mozyo_bridge.application import release as release_mod

        sequence = [
            {"status": "in_progress", "conclusion": None},
            {"status": "completed", "conclusion": "success"},
        ]
        with patch.object(release_mod, "_gh_run_view", side_effect=sequence):
            with patch.object(release_mod, "_require_command"):
                with patch.object(release_mod.time, "sleep"):
                    with contextlib.redirect_stdout(io.StringIO()) as out:
                        rc = release_mod.cmd_release_workflow_wait(
                            argparse.Namespace(run_id="42", timeout=30.0, poll=0.0)
                        )
        self.assertEqual(release_mod.EXIT_CLEAN, rc)
        self.assertIn("conclusion: success", out.getvalue())

    def test_wait_returns_timeout_code_when_deadline_elapses(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with patch.object(
            release_mod,
            "_gh_run_view",
            return_value={"status": "in_progress", "conclusion": None},
        ):
            with patch.object(release_mod, "_require_command"):
                with patch.object(release_mod.time, "sleep"):
                    with contextlib.redirect_stdout(io.StringIO()) as out:
                        rc = release_mod.cmd_release_workflow_wait(
                            argparse.Namespace(
                                run_id="42", timeout=0.0, poll=0.0
                            )
                        )
        self.assertEqual(release_mod.EXIT_TIMEOUT, rc)
        self.assertIn("timeout: exceeded", out.getvalue())

    def test_wait_returns_blocker_when_run_fails(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with patch.object(
            release_mod,
            "_gh_run_view",
            return_value={"status": "completed", "conclusion": "failure"},
        ):
            with patch.object(release_mod, "_require_command"):
                with patch.object(release_mod.time, "sleep"):
                    with contextlib.redirect_stdout(io.StringIO()):
                        rc = release_mod.cmd_release_workflow_wait(
                            argparse.Namespace(
                                run_id="42", timeout=30.0, poll=0.0
                            )
                        )
        self.assertEqual(release_mod.EXIT_BLOCKER, rc)


class ReleaseBumpPublishParserTest(unittest.TestCase):
    """The bump/publish CLI must enforce mutually-exclusive mode flags and
    pass through per-mode args. Argparse will raise on the missing/
    conflicting-mode cases below if the wiring is wrong, so this is a cheap
    structural check.
    """

    def parse(self, *argv: str) -> argparse.Namespace:
        return build_parser().parse_args(list(argv))

    def test_release_bump_requires_mode(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "bump")

    def test_release_bump_mode_is_mutually_exclusive(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "bump", "--check", "--to", "0.3.0")

    def test_release_bump_check(self) -> None:
        args = self.parse("release", "bump", "--check")
        from mozyo_bridge.application.release import cmd_release_bump

        self.assertIs(args.func, cmd_release_bump)
        self.assertTrue(args.check)
        self.assertIsNone(args.to)

    def test_release_bump_to(self) -> None:
        args = self.parse("release", "bump", "--to", "0.3.0a1")
        from mozyo_bridge.application.release import cmd_release_bump

        self.assertIs(args.func, cmd_release_bump)
        self.assertFalse(args.check)
        self.assertEqual("0.3.0a1", args.to)

    def test_release_publish_requires_mode(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "publish")

    def test_release_publish_mode_is_mutually_exclusive(self) -> None:
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                self.parse("release", "publish", "--testpypi", "--pypi")

    def test_release_publish_testpypi(self) -> None:
        args = self.parse(
            "release", "publish", "--testpypi", "--version", "0.3.0a1"
        )
        self.assertTrue(args.testpypi)
        self.assertEqual("0.3.0a1", args.version)
        self.assertFalse(args.execute)

    def test_release_publish_pypi_dryrun(self) -> None:
        args = self.parse(
            "release",
            "publish",
            "--pypi",
            "--tag",
            "v0.3.0",
            "--notes-file",
            "/tmp/notes.md",
        )
        self.assertTrue(args.pypi)
        self.assertEqual("v0.3.0", args.tag)
        self.assertEqual("/tmp/notes.md", args.notes_file)
        self.assertFalse(args.execute)

    def test_release_publish_pypi_execute(self) -> None:
        args = self.parse(
            "release",
            "publish",
            "--pypi",
            "--tag",
            "v0.3.0",
            "--notes-file",
            "/tmp/notes.md",
            "--execute",
        )
        self.assertTrue(args.execute)

    def test_release_publish_plan(self) -> None:
        args = self.parse("release", "publish", "--plan")
        self.assertTrue(args.plan)


class ReleaseBumpCheckTest(unittest.TestCase):
    """`release bump --check` must (a) read the mirror set from the contract
    doc, (b) report version literals from each mirror file, (c) strict-fail
    when the mirror values disagree. Tests build a fake repo with both a
    contract doc and the mirror-set files.
    """

    def _build_fake_repo(
        self,
        root: Path,
        *,
        pyproject_version: str = "0.3.0",
        module_version: str = "0.3.0",
    ) -> None:
        env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "test",
            "GIT_AUTHOR_EMAIL": "test@example.com",
            "GIT_COMMITTER_NAME": "test",
            "GIT_COMMITTER_EMAIL": "test@example.com",
        }
        subprocess.run(["git", "init", "-q", str(root)], check=True)
        (root / "pyproject.toml").write_text(
            f'[project]\nname = "fake"\nversion = "{pyproject_version}"\n',
            encoding="utf-8",
        )
        module_dir = root / "src" / "mozyo_bridge"
        module_dir.mkdir(parents=True)
        (module_dir / "__init__.py").write_text(
            f'__version__ = "{module_version}"\n', encoding="utf-8"
        )
        contract_dir = root / "vibes" / "docs" / "logics"
        contract_dir.mkdir(parents=True)
        (contract_dir / "release-helper-contract.md").write_text(
            "# Contract\n\n"
            "release-version mirror set は以下の 2 file に固定する。\n\n"
            "- `pyproject.toml` の `[project].version`\n"
            "- `src/mozyo_bridge/__init__.py` の `__version__`\n\n"
            "Other section.\n",
            encoding="utf-8",
        )
        subprocess.run(
            ["git", "-C", str(root), "add", "."],
            check=True,
            env=env,
        )
        subprocess.run(
            ["git", "-C", str(root), "commit", "-m", "Release v" + pyproject_version, "-q"],
            check=True,
            env=env,
        )

    def test_clean_check_reports_each_mirror_file(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._build_fake_repo(root, pyproject_version="0.3.0", module_version="0.3.0")
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_bump(
                    argparse.Namespace(repo=str(root), check=True, to=None)
                )
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            text = out.getvalue()
            self.assertIn("pyproject.toml", text)
            self.assertIn("[project].version", text)
            self.assertIn("src/mozyo_bridge/__init__.py", text)
            self.assertIn("__version__", text)
            self.assertIn("0.3.0", text)
            self.assertIn("result: clean", text)

    def test_mirror_set_drift_is_blocker(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._build_fake_repo(
                root, pyproject_version="0.3.0", module_version="0.2.9"
            )
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_bump(
                    argparse.Namespace(repo=str(root), check=True, to=None)
                )
            self.assertEqual(release_mod.EXIT_BLOCKER, rc)
            self.assertIn("mirror set values disagree", out.getvalue())

    def test_contract_missing_anchor_is_fatal(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._build_fake_repo(root)
            # Strip the anchor sentence from the contract doc. The helper
            # must refuse to operate rather than guess at the mirror set.
            contract_path = root / "vibes" / "docs" / "logics" / "release-helper-contract.md"
            contract_path.write_text(
                "# Contract\n\n"
                "(mirror-set section removed for this test)\n",
                encoding="utf-8",
            )
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    release_mod.cmd_release_bump(
                        argparse.Namespace(repo=str(root), check=True, to=None)
                    )


class ReleaseBumpToTest(unittest.TestCase):
    """`release bump --to` must rewrite every mirror-set file in the
    worktree and never commit/push/tag. Tests assert (a) post-bump file
    contents, (b) absence of any new commits in the fake repo, (c)
    idempotency when called with the existing version.
    """

    def _build_fake_repo(
        self,
        root: Path,
        *,
        pyproject_version: str = "0.3.0",
        module_version: str = "0.3.0",
    ) -> str:
        env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "test",
            "GIT_AUTHOR_EMAIL": "test@example.com",
            "GIT_COMMITTER_NAME": "test",
            "GIT_COMMITTER_EMAIL": "test@example.com",
        }
        subprocess.run(["git", "init", "-q", str(root)], check=True)
        (root / "pyproject.toml").write_text(
            f'[project]\nname = "fake"\nversion = "{pyproject_version}"\n',
            encoding="utf-8",
        )
        module_dir = root / "src" / "mozyo_bridge"
        module_dir.mkdir(parents=True)
        (module_dir / "__init__.py").write_text(
            f'__version__ = "{module_version}"\n', encoding="utf-8"
        )
        contract_dir = root / "vibes" / "docs" / "logics"
        contract_dir.mkdir(parents=True)
        (contract_dir / "release-helper-contract.md").write_text(
            "release-version mirror set は以下の 2 file に固定する。\n\n"
            "- `pyproject.toml` の `[project].version`\n"
            "- `src/mozyo_bridge/__init__.py` の `__version__`\n\n",
            encoding="utf-8",
        )
        subprocess.run(["git", "-C", str(root), "add", "."], check=True, env=env)
        subprocess.run(
            ["git", "-C", str(root), "commit", "-m", "init", "-q"],
            check=True,
            env=env,
        )
        return subprocess.run(
            ["git", "-C", str(root), "rev-parse", "HEAD"],
            check=True,
            text=True,
            stdout=subprocess.PIPE,
        ).stdout.strip()

    def test_rewrites_every_mirror_file_without_committing(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            initial_head = self._build_fake_repo(root)

            with contextlib.redirect_stdout(io.StringIO()):
                rc = release_mod.cmd_release_bump(
                    argparse.Namespace(repo=str(root), check=False, to="0.4.0")
                )
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            self.assertIn(
                '"0.4.0"',
                (root / "pyproject.toml").read_text(encoding="utf-8"),
            )
            self.assertIn(
                '"0.4.0"',
                (root / "src" / "mozyo_bridge" / "__init__.py").read_text(
                    encoding="utf-8"
                ),
            )
            head_after = subprocess.run(
                ["git", "-C", str(root), "rev-parse", "HEAD"],
                check=True,
                text=True,
                stdout=subprocess.PIPE,
            ).stdout.strip()
            self.assertEqual(
                initial_head,
                head_after,
                "release bump --to created a commit; helper must leave commit "
                "authority with the operator",
            )

    def test_same_version_is_idempotent_noop(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._build_fake_repo(
                root, pyproject_version="0.4.0", module_version="0.4.0"
            )
            with contextlib.redirect_stdout(io.StringIO()) as out:
                rc = release_mod.cmd_release_bump(
                    argparse.Namespace(repo=str(root), check=False, to="0.4.0")
                )
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            self.assertIn("already at 0.4.0", out.getvalue())
            self.assertIn(
                "no-op (mirror set was already at 0.4.0)", out.getvalue()
            )

    def test_invalid_version_shape_is_rejected(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._build_fake_repo(root)
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    release_mod.cmd_release_bump(
                        argparse.Namespace(
                            repo=str(root), check=False, to="not-a-version"
                        )
                    )

    def test_missing_version_literal_strict_fails(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._build_fake_repo(root)
            # Drop the __version__ literal from the python mirror file so
            # the helper cannot find it. The helper must strict-fail rather
            # than partially rewrite the mirror set — pyproject.toml must
            # still carry the pre-bump version.
            pyproject_before = (root / "pyproject.toml").read_text(encoding="utf-8")
            (root / "src" / "mozyo_bridge" / "__init__.py").write_text(
                "# version moved elsewhere\n", encoding="utf-8"
            )
            with contextlib.redirect_stderr(io.StringIO()):
                with contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaises(SystemExit):
                        release_mod.cmd_release_bump(
                            argparse.Namespace(
                                repo=str(root), check=False, to="0.4.0"
                            )
                        )
            self.assertEqual(
                pyproject_before,
                (root / "pyproject.toml").read_text(encoding="utf-8"),
                "release bump --to partially rewrote the mirror set on strict-fail",
            )


class ReleasePublishTest(unittest.TestCase):
    """`release publish --pypi` must default to dry-run; `--execute` must
    be required to invoke `gh release create`. `--testpypi` and `--plan`
    are smoke-tested for argv shape via mock.
    """

    def test_pypi_dry_run_does_not_invoke_gh(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            notes = Path(tmp) / "notes.md"
            notes.write_text("# v0.3.0\nNotes\n", encoding="utf-8")
            recorded = []

            def fake_run(argv, cwd=None, check=False, env=None):
                recorded.append(list(argv))
                return subprocess.CompletedProcess(
                    args=argv, returncode=0, stdout="", stderr=""
                )

            with patch.object(release_mod, "_run", side_effect=fake_run):
                with contextlib.redirect_stdout(io.StringIO()) as out:
                    rc = release_mod.cmd_release_publish(
                        argparse.Namespace(
                            testpypi=False,
                            pypi=True,
                            plan=False,
                            tag="v0.3.0",
                            notes_file=str(notes),
                            execute=False,
                            version=None,
                            repo=None,
                        )
                    )
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            self.assertIn("(dry-run)", out.getvalue())
            self.assertEqual(
                recorded,
                [],
                "dry-run must NOT invoke `gh release create`",
            )
            self.assertIn("Re-run with `--execute`", out.getvalue())

    def test_pypi_execute_invokes_gh_release_create(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            notes = Path(tmp) / "notes.md"
            notes.write_text("# v0.3.0\nNotes\n", encoding="utf-8")
            recorded = []

            def fake_run(argv, cwd=None, check=False, env=None):
                recorded.append(list(argv))
                return subprocess.CompletedProcess(
                    args=argv, returncode=0, stdout="created\n", stderr=""
                )

            with patch.object(release_mod, "_run", side_effect=fake_run):
                with patch.object(release_mod, "_require_command"):
                    with contextlib.redirect_stdout(io.StringIO()):
                        rc = release_mod.cmd_release_publish(
                            argparse.Namespace(
                                testpypi=False,
                                pypi=True,
                                plan=False,
                                tag="v0.3.0",
                                notes_file=str(notes),
                                execute=True,
                                version=None,
                                repo=None,
                            )
                        )
            self.assertEqual(release_mod.EXIT_CLEAN, rc)
            self.assertEqual(1, len(recorded))
            argv = recorded[0]
            self.assertEqual(argv[0], "gh")
            self.assertEqual(argv[1:4], ["release", "create", "v0.3.0"])
            self.assertIn("--verify-tag", argv)
            self.assertIn("--notes-file", argv)

    def test_pypi_rejects_missing_notes_file(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            missing = Path(tmp) / "does-not-exist.md"
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    release_mod.cmd_release_publish(
                        argparse.Namespace(
                            testpypi=False,
                            pypi=True,
                            plan=False,
                            tag="v0.3.0",
                            notes_file=str(missing),
                            execute=False,
                            version=None,
                            repo=None,
                        )
                    )

    def test_pypi_rejects_invalid_tag(self) -> None:
        from mozyo_bridge.application import release as release_mod

        with tempfile.TemporaryDirectory() as tmp:
            notes = Path(tmp) / "notes.md"
            notes.write_text("notes", encoding="utf-8")
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    release_mod.cmd_release_publish(
                        argparse.Namespace(
                            testpypi=False,
                            pypi=True,
                            plan=False,
                            tag="0.3.0",  # missing `v` prefix
                            notes_file=str(notes),
                            execute=False,
                            version=None,
                            repo=None,
                        )
                    )

    def test_testpypi_dispatch_validates_version_without_workflow_input(self) -> None:
        from mozyo_bridge.application import release as release_mod

        dispatch_call = []

        def fake_run(argv, cwd=None, check=False, env=None):
            dispatch_call.append(list(argv))
            if "workflow" in argv and "run" in argv:
                return subprocess.CompletedProcess(
                    args=argv, returncode=0, stdout="", stderr=""
                )
            # gh run list response
            payload = json.dumps(
                [
                    {
                        "databaseId": 9999,
                        "url": "https://example/run/9999",
                        "createdAt": "2026-05-14T11:00:00Z",
                        "headSha": "abc",
                        "status": "queued",
                    }
                ]
            )
            return subprocess.CompletedProcess(
                args=argv, returncode=0, stdout=payload, stderr=""
            )

        with patch.object(release_mod, "_run", side_effect=fake_run):
            with patch.object(release_mod, "_require_command"):
                with patch.object(release_mod.time, "sleep"):
                    with contextlib.redirect_stdout(io.StringIO()) as out:
                        rc = release_mod.cmd_release_publish(
                            argparse.Namespace(
                                testpypi=True,
                                pypi=False,
                                plan=False,
                                tag=None,
                                notes_file=None,
                                execute=False,
                                version="0.3.0a1",
                                repo=None,
                            )
                        )
        self.assertEqual(release_mod.EXIT_CLEAN, rc)
        self.assertEqual(2, len(dispatch_call))
        dispatch_argv = dispatch_call[0]
        self.assertEqual(
            dispatch_argv,
            [
                "gh",
                "workflow",
                "run",
                "testpypi.yml",
                "--ref",
                "main",
            ],
        )
        self.assertIn("9999", out.getvalue())


if __name__ == "__main__":
    unittest.main()
