"""
HyperionAdmin — programmatic management client for the Hyperion Gateway.

This is a separate client from HyperionClient. It is used to interact with
the administrative management plane: organizations, API keys, budgets, members,
analytics, and pricing.

Usage::

    from hyperion import HyperionAdmin

    admin = HyperionAdmin(admin_key="your-admin-key")

    # Create a key with a budget
    key = admin.keys.create(
        name="Production",
        budget_limit_usd=100.0,
        allowed_models=["gpt-5.2-mini", "claude-3-haiku"]
    )

    # Check spend
    spend = admin.analytics.timeseries(period="7d")
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import httpx


class HyperionAdmin:
    """
    Admin client for the Hyperion Gateway management API.

    Args:
        base_url: Gateway URL. Defaults to HYPERION_BASE_URL env var.
        admin_key: Admin API key. Defaults to HYPERION_ADMIN_KEY env var.
        timeout: Request timeout in seconds. Defaults to 30.
    """

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        admin_key: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        _base_url = base_url or os.environ.get("HYPERION_BASE_URL", "http://localhost:8080")
        _admin_key = admin_key or os.environ.get("HYPERION_ADMIN_KEY", "")

        self._client = httpx.Client(
            base_url=f"{_base_url.rstrip('/')}/v1",
            timeout=timeout,
            headers={
                "Content-Type": "application/json",
                "X-Admin-Key": _admin_key,
            },
        )

        self.keys = _KeysResource(self._client)
        self.tenants = _TenantsResource(self._client)
        self.analytics = _AnalyticsResource(self._client)
        self.members = _MembersResource(self._client)
        self.pricing = _PricingResource(self._client)

    def health(self) -> Dict[str, Any]:
        """Get gateway health status."""
        return self._client.get("/admin/health").raise_for_status().json()

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


# ---------------------------------------------------------------------------
# Resource: Keys
# ---------------------------------------------------------------------------

class _KeysResource:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def list(self) -> List[Dict[str, Any]]:
        """List all API keys for the current organization."""
        return self._client.get("/admin/keys").raise_for_status().json()

    def create(
        self,
        *,
        name: str,
        budget_limit_usd: Optional[float] = None,
        allowed_models: Optional[List[str]] = None,
        rate_limit_rpm: Optional[int] = None,
        tags: Optional[List[str]] = None,
        org_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new scoped API key.

        Args:
            name: Human-readable key name.
            budget_limit_usd: Hard monthly spend ceiling in USD.
            allowed_models: Restrict this key to specific model IDs.
            rate_limit_rpm: Max requests per minute for this key.
            tags: Labels for analytics filtering.
            org_id: Org to create the key in (admin override).
        """
        payload: Dict[str, Any] = {"name": name}
        if budget_limit_usd is not None:
            payload["budget_limit_usd"] = budget_limit_usd
        if allowed_models is not None:
            payload["allowed_models"] = allowed_models
        if rate_limit_rpm is not None:
            payload["rate_limit_rpm"] = rate_limit_rpm
        if tags is not None:
            payload["tags"] = tags
        if org_id is not None:
            payload["org_id"] = org_id
        return self._client.post("/admin/tenants/key", json=payload).raise_for_status().json()

    def update(self, key_id: str, **fields: Any) -> Dict[str, Any]:
        """Update an existing API key's configuration."""
        return self._client.put(f"/admin/keys/{key_id}", json=fields).raise_for_status().json()

    def delete(self, key_id: str) -> Dict[str, Any]:
        """Permanently delete an API key."""
        return self._client.delete(f"/admin/keys/{key_id}").raise_for_status().json()

    def rotate(self, key_id: str) -> Dict[str, Any]:
        """Rotate the secret value of an API key, invalidating the old one."""
        return self._client.post(f"/admin/keys/{key_id}/rotate").raise_for_status().json()


# ---------------------------------------------------------------------------
# Resource: Tenants / Organizations
# ---------------------------------------------------------------------------

class _TenantsResource:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def list(self) -> List[Dict[str, Any]]:
        """List all tenants visible to this admin key."""
        return self._client.get("/admin/tenants").raise_for_status().json()

    def set_budget(
        self,
        *,
        org_id: str,
        limit_usd: float,
        period: str = "monthly",
    ) -> Dict[str, Any]:
        """
        Set or update a hard spend budget for a tenant.

        Args:
            org_id: Organization ID.
            limit_usd: Budget ceiling in USD.
            period: "daily" or "monthly".
        """
        return self._client.post(
            "/admin/tenants/budget",
            json={"org_id": org_id, "limit_usd": limit_usd, "period": period},
        ).raise_for_status().json()


# ---------------------------------------------------------------------------
# Resource: Analytics
# ---------------------------------------------------------------------------

class _AnalyticsResource:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def timeseries(self, *, period: Optional[str] = None, org_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Fetch request volume and cost timeseries.

        Args:
            period: Time window, e.g. "24h", "7d", "30d".
            org_id: Filter to a specific organization.
        """
        params: Dict[str, str] = {}
        if period:
            params["period"] = period
        if org_id:
            params["org_id"] = org_id
        return self._client.get("/admin/timeseries", params=params).raise_for_status().json()

    def usage_by_model(self, *, org_id: Optional[str] = None) -> Dict[str, Any]:
        """Fetch token usage and cost broken down by model."""
        params: Dict[str, str] = {}
        if org_id:
            params["org_id"] = org_id
        return self._client.get("/admin/usage-by-model", params=params).raise_for_status().json()


# ---------------------------------------------------------------------------
# Resource: Members
# ---------------------------------------------------------------------------

class _MembersResource:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def list(self) -> List[Dict[str, Any]]:
        """List all members in the organization."""
        return self._client.get("/admin/members").raise_for_status().json()

    def invite(self, *, email: str, role: str = "member") -> Dict[str, Any]:
        """
        Invite a new member to the organization.

        Args:
            email: Member's email address.
            role: One of "admin", "member".
        """
        return self._client.post(
            "/admin/members/invite",
            json={"email": email, "role": role},
        ).raise_for_status().json()


# ---------------------------------------------------------------------------
# Resource: Pricing
# ---------------------------------------------------------------------------

class _PricingResource:
    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def list(self) -> List[Dict[str, Any]]:
        """List all model pricing records."""
        return self._client.get("/admin/pricing/models").raise_for_status().json()

    def upsert(self, *, model_id: str, input_cost: float, output_cost: float) -> Dict[str, Any]:
        """
        Insert or update pricing for a model.

        Args:
            model_id: The model identifier (e.g., "gpt-5.2").
            input_cost: Cost per 1k input tokens in USD.
            output_cost: Cost per 1k output tokens in USD.
        """
        return self._client.post(
            "/admin/pricing/models",
            json={"model_id": model_id, "input_cost": input_cost, "output_cost": output_cost},
        ).raise_for_status().json()
