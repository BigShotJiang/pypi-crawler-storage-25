"""
hyperion.patch — global monkey-patch for the openai module.

Usage::

    import hyperion
    import openai

    hyperion.patch(openai)
    # All new openai.OpenAI() instances now route through Hyperion automatically.
"""

from __future__ import annotations

import os
from typing import Optional


def patch(openai_module, *, base_url: Optional[str] = None, api_key: Optional[str] = None) -> None:
    """
    Monkey-patch the official openai module so that all OpenAI clients
    route through the Hyperion gateway.

    This overrides the default base_url and api_key for both
    `openai.OpenAI` and `openai.AsyncOpenAI`.

    Args:
        openai_module: The `openai` module object (import openai; patch(openai)).
        base_url: The Hyperion gateway base URL. Defaults to HYPERION_BASE_URL
                  env var, or http://localhost:8080/v1.
        api_key: The Hyperion API key. Defaults to HYPERION_API_KEY env var.

    Example::

        import hyperion
        import openai

        hyperion.patch(openai)

        client = openai.OpenAI()
        # This call now goes through Hyperion
        client.chat.completions.create(...)
    """
    _base_url = base_url or os.environ.get("HYPERION_BASE_URL", "http://localhost:8080/v1")
    _api_key = api_key or os.environ.get("HYPERION_API_KEY", "sk-hyperion")

    _patch_class(openai_module.OpenAI, _base_url, _api_key)
    _patch_class(openai_module.AsyncOpenAI, _base_url, _api_key)


def _patch_class(cls, base_url: str, api_key: str) -> None:
    original_init = cls.__init__

    def patched_init(self, *args, **kwargs):
        kwargs.setdefault("base_url", base_url)
        kwargs.setdefault("api_key", kwargs.get("api_key") or api_key)
        original_init(self, *args, **kwargs)

    cls.__init__ = patched_init
