"""
hyperion - The official Python SDK for the Hyperion AI Gateway.

Drop-in replacement for the OpenAI SDK that routes through the Hyperion
inference caching and orchestration layer.

Usage:
    from hyperion import HyperionClient

    client = HyperionClient()
    response = client.chat.completions.create(
        model="openai/gpt-5.2",
        messages=[{"role": "user", "content": "Hello"}],
        hyperion={"bypass_cache": True}
    )
    print(response.hyperion.cache_status)  # "MISS"
"""

from .client import HyperionClient, AsyncHyperionClient
from .admin import HyperionAdmin
from .types import HyperionConfig, HyperionMeta
from .patch import patch

__all__ = [
    "HyperionClient",
    "AsyncHyperionClient",
    "HyperionAdmin",
    "HyperionConfig",
    "HyperionMeta",
    "patch",
]

__version__ = "1.0.0"
