"""
Types for the Hyperion SDK.

HyperionConfig: typed dict for the `hyperion={}` parameter on chat.completions.create().
HyperionMeta: enriched metadata parsed from gateway response headers.
"""

from __future__ import annotations

from typing import List, Optional
from typing_extensions import TypedDict


class HyperionConfig(TypedDict, total=False):
    """
    Hyperion-specific configuration for a single request.

    Pass this as the `hyperion={}` keyword argument on any
    `client.chat.completions.create()` call.

    Example::

        client.chat.completions.create(
            model="openai/gpt-5.2",
            messages=[...],
            hyperion={
                "bypass_cache": True,
                "tags": ["prod", "onboarding"],
            }
        )
    """

    # --- Caching ---
    bypass_cache: bool
    """Skip the cache entirely for this request. Forces a live LLM call."""

    cache_ttl: int
    """Override the cache TTL in seconds for the stored response."""

    similarity_threshold: float
    """Override the semantic similarity threshold (0.0–1.0). Higher = stricter match required."""

    cache_tool_calls: bool
    """Whether to cache the model's tool_call decision response. Defaults to True."""

    # --- Routing ---
    route_intent: str
    """
    Hint to the routing engine. One of: "cheap_fast", "balanced", "high_reasoning",
    or a custom string like "code_generation".
    """

    force_provider: str
    """Force a specific provider for this request (e.g., "anthropic", "openai")."""

    fallbacks: List[str]
    """
    Ordered list of models to try if the primary model fails.
    Example: ["claude-3-5-sonnet", "gpt-5.2-mini"]
    """

    # --- Telemetry ---
    tags: List[str]
    """Arbitrary string tags attached to this request for dashboard filtering."""

    team_id: str
    """Team or downstream tenant ID for usage attribution."""


class HyperionMeta:
    """
    Metadata extracted from Hyperion gateway response headers.

    Attached as `.hyperion` on every response object returned by
    `HyperionClient` and `AsyncHyperionClient`.
    """

    cache_status: str
    """
    Cache result for this request.
    One of: "HIT", "MISS", "BYPASS", "BYPASS-TOOL-RESULT", "BYPASS-TOOL-NOCACHE".
    """

    cache_type: Optional[str]
    """
    Type of cache hit, if applicable. One of: "exact", "semantic". None on MISS.
    """

    similarity_score: Optional[float]
    """Cosine similarity score of the semantic cache match. None on exact hit or miss."""

    def __init__(
        self,
        cache_status: str = "MISS",
        cache_type: Optional[str] = None,
        similarity_score: Optional[float] = None,
    ) -> None:
        self.cache_status = cache_status
        self.cache_type = cache_type
        self.similarity_score = similarity_score

    @property
    def is_hit(self) -> bool:
        """True if this response was served from cache."""
        return self.cache_status == "HIT"

    @property
    def formatted_similarity_score(self) -> str:
        """Similarity score formatted to 4 decimal places, or 'N/A' if not applicable."""
        return f"{self.similarity_score:.4f}" if self.similarity_score is not None else "N/A"

    @classmethod
    def from_headers(cls, headers: dict) -> "HyperionMeta":
        """Parse a HyperionMeta from a response headers dict."""
        score_raw = headers.get("x-similarity-score")
        score = float(score_raw) if score_raw else None
        return cls(
            cache_status=headers.get("x-cache-status", "MISS"),
            cache_type=headers.get("x-cache-type") or None,
            similarity_score=score,
        )

    def __repr__(self) -> str:
        return (
            f"HyperionMeta(cache_status={self.cache_status!r}, "
            f"cache_type={self.cache_type!r}, "
            f"similarity_score={self.similarity_score!r})"
        )
