"""
Core Hyperion client — sync and async.

Both clients extend their openai counterparts, inheriting full type parity,
streaming, tool calls, and all OpenAI SDK features. The only additions are:

1.  The `hyperion={}` kwarg on `chat.completions.create()`, which is extracted
    and mapped to X-* request headers before the underlying OpenAI call.

2.  A `.hyperion` attribute (HyperionMeta) on every returned response object,
    populated from the X-Cache-Status / X-Cache-Type / X-Similarity-Score
    response headers.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Union

import openai
from openai import Stream
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from .types import HyperionConfig, HyperionMeta


def _config_to_headers(config: HyperionConfig) -> Dict[str, str]:
    """Map a HyperionConfig dict to gateway X-* request headers."""
    headers: Dict[str, str] = {}

    if config.get("bypass_cache"):
        headers["X-Cache-Bypass"] = "true"

    if (ttl := config.get("cache_ttl")) is not None:
        headers["X-Cache-TTL"] = str(ttl)

    if (threshold := config.get("similarity_threshold")) is not None:
        headers["X-Similarity-Threshold"] = f"{threshold:.4f}"

    if config.get("cache_tool_calls") is False:
        headers["X-Cache-Tool-Calls"] = "false"

    if route_intent := config.get("route_intent"):
        headers["X-Route-Intent"] = route_intent

    if force_provider := config.get("force_provider"):
        headers["X-Force-Provider"] = force_provider

    if fallbacks := config.get("fallbacks"):
        headers["X-Fallbacks"] = ",".join(fallbacks)

    if tags := config.get("tags"):
        headers["X-Tags"] = ",".join(tags)

    if team_id := config.get("team_id"):
        headers["X-Team-ID"] = team_id

    return headers


def _attach_meta(obj: Any, raw_headers: Dict[str, str]) -> Any:
    """Attach a HyperionMeta parsed from raw headers to any response object."""
    # headers may be a httpx.Headers (case-insensitive) or a plain dict
    # normalise to lowercase plain dict
    normalised = {k.lower(): v for k, v in dict(raw_headers).items()}
    obj.hyperion = HyperionMeta.from_headers(normalised)
    return obj


class HyperionClient(openai.OpenAI):
    """
    Sync Hyperion client. Drop-in replacement for `openai.OpenAI`.

    Example::

        from hyperion import HyperionClient

        client = HyperionClient()
        # or: HyperionClient(api_key="...", base_url="http://your-gateway:8080/v1")
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        # The Gateway's TenantAuthMiddleware reads the API key from the
        # Authorization: Bearer header.  After authenticating the tenant,
        # the provider layer (e.g. OpenAIProvider.ConfigureRequest) REPLACES
        # that header with the real upstream key stored server-side.
        #
        # So we use HYPERION_API_KEY as the api_key here — it serves double
        # duty: (1) satisfies the OpenAI SDK's mandatory api_key check, and
        # (2) authenticates against the Gateway.
        super().__init__(
            api_key=api_key or os.environ.get("HYPERION_API_KEY", "sk-hyperion"),
            base_url=base_url or os.environ.get("HYPERION_BASE_URL", "http://localhost:8080/v1"),
            **kwargs,
        )
        # Wrap chat.completions with our interceptor
        self._openai_chat = self.chat
        self.chat = _SyncChatNamespace(self)  # type: ignore[assignment]


class _SyncCompletions:
    """Interceptor for sync chat.completions — extracts `hyperion` kwarg."""

    def __init__(self, hyperion_client: HyperionClient) -> None:
        self._client = hyperion_client

    def create(
        self,
        *,
        hyperion: Optional[HyperionConfig] = None,
        **kwargs: Any,
    ) -> ChatCompletion:
        extra_headers = dict(kwargs.pop("extra_headers", None) or {})
        if hyperion:
            extra_headers.update(_config_to_headers(hyperion))

        # Access the original OpenAI chat.completions through the saved reference
        raw_response = self._client._openai_chat.completions.with_raw_response.create(
            extra_headers=extra_headers, **kwargs
        )
        response = raw_response.parse()
        _attach_meta(response, dict(raw_response.headers))
        return response

    def stream(self, *, hyperion: Optional[HyperionConfig] = None, **kwargs: Any):
        """
        Streaming wrapper — metadata accessible after the stream ends via
        the returned context manager's `.hyperion` attribute.
        """
        extra_headers = dict(kwargs.pop("extra_headers", None) or {})
        if hyperion:
            extra_headers.update(_config_to_headers(hyperion))

        return _HyperionStream(
            self._client._openai_chat.completions.stream(extra_headers=extra_headers, **kwargs)
        )


class _SyncChatNamespace:
    def __init__(self, client: HyperionClient) -> None:
        self.completions = _SyncCompletions(client)


class _HyperionStream:
    """
    Thin wrapper around OpenAI's streaming context manager that captures
    response headers and exposes them as `.hyperion` after the stream completes.
    """

    def __init__(self, inner) -> None:
        self._inner = inner
        self.hyperion: Optional[HyperionMeta] = None

    def __enter__(self):
        self._stream = self._inner.__enter__()
        return self

    def __exit__(self, *args):
        result = self._inner.__exit__(*args)
        # Attempt to parse headers from the underlying response
        try:
            headers = dict(self._stream.response.headers)
            self.hyperion = HyperionMeta.from_headers({k.lower(): v for k, v in headers.items()})
        except Exception:
            self.hyperion = HyperionMeta()
        return result

    def __iter__(self):
        return iter(self._stream)

    def get_final_completion(self):
        return self._stream.get_final_completion()


# ---------------------------------------------------------------------------
# Async Client
# ---------------------------------------------------------------------------

class AsyncHyperionClient(openai.AsyncOpenAI):
    """
    Async Hyperion client. Drop-in replacement for `openai.AsyncOpenAI`.

    Example::

        from hyperion import AsyncHyperionClient

        client = AsyncHyperionClient()
        response = await client.chat.completions.create(
            model="openai/gpt-5.2",
            messages=[{"role": "user", "content": "Hello"}],
        )
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            api_key=api_key or os.environ.get("HYPERION_API_KEY", "sk-hyperion"),
            base_url=base_url or os.environ.get("HYPERION_BASE_URL", "http://localhost:8080/v1"),
            **kwargs,
        )
        self._openai_chat = self.chat
        self.chat = _AsyncChatNamespace(self)  # type: ignore[assignment]


class _AsyncCompletions:
    def __init__(self, hyperion_client: AsyncHyperionClient) -> None:
        self._client = hyperion_client

    async def create(
        self,
        *,
        hyperion: Optional[HyperionConfig] = None,
        **kwargs: Any,
    ) -> ChatCompletion:
        extra_headers = dict(kwargs.pop("extra_headers", None) or {})
        if hyperion:
            extra_headers.update(_config_to_headers(hyperion))

        raw_response = await self._client._openai_chat.completions.with_raw_response.create(
            extra_headers=extra_headers, **kwargs
        )
        response = raw_response.parse()
        _attach_meta(response, dict(raw_response.headers))
        return response


class _AsyncChatNamespace:
    def __init__(self, client: AsyncHyperionClient) -> None:
        self.completions = _AsyncCompletions(client)
