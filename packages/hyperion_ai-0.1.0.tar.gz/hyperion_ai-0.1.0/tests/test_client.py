"""
Unit tests for the Hyperion Python SDK.

Tests are written with pytest. Run:
    pip install -e ".[dev]"
    pytest tests/
"""

from __future__ import annotations

import pytest
import httpx
import respx

from hyperion.types import HyperionConfig, HyperionMeta
from hyperion.client import _config_to_headers


# ---------------------------------------------------------------------------
# _config_to_headers tests
# ---------------------------------------------------------------------------

class TestConfigToHeaders:
    def test_empty_config_produces_no_headers(self):
        assert _config_to_headers({}) == {}

    def test_bypass_cache(self):
        h = _config_to_headers({"bypass_cache": True})
        assert h["X-Cache-Bypass"] == "true"

    def test_bypass_cache_false_omitted(self):
        h = _config_to_headers({"bypass_cache": False})
        assert "X-Cache-Bypass" not in h

    def test_cache_ttl(self):
        h = _config_to_headers({"cache_ttl": 3600})
        assert h["X-Cache-TTL"] == "3600"

    def test_similarity_threshold(self):
        h = _config_to_headers({"similarity_threshold": 0.92})
        assert h["X-Similarity-Threshold"] == "0.9200"

    def test_cache_tool_calls_false(self):
        h = _config_to_headers({"cache_tool_calls": False})
        assert h["X-Cache-Tool-Calls"] == "false"

    def test_cache_tool_calls_true_omitted(self):
        # Only override when explicitly False
        h = _config_to_headers({"cache_tool_calls": True})
        assert "X-Cache-Tool-Calls" not in h

    def test_route_intent(self):
        h = _config_to_headers({"route_intent": "code_generation"})
        assert h["X-Route-Intent"] == "code_generation"

    def test_force_provider(self):
        h = _config_to_headers({"force_provider": "anthropic"})
        assert h["X-Force-Provider"] == "anthropic"

    def test_fallbacks(self):
        h = _config_to_headers({"fallbacks": ["claude-3-5-sonnet", "gpt-5.2-mini"]})
        assert h["X-Fallbacks"] == "claude-3-5-sonnet,gpt-5.2-mini"

    def test_tags(self):
        h = _config_to_headers({"tags": ["prod", "onboarding"]})
        assert h["X-Tags"] == "prod,onboarding"

    def test_team_id(self):
        h = _config_to_headers({"team_id": "team_abc"})
        assert h["X-Team-ID"] == "team_abc"

    def test_combined(self):
        h = _config_to_headers({
            "bypass_cache": True,
            "tags": ["prod"],
            "force_provider": "anthropic",
        })
        assert h["X-Cache-Bypass"] == "true"
        assert h["X-Tags"] == "prod"
        assert h["X-Force-Provider"] == "anthropic"


# ---------------------------------------------------------------------------
# HyperionMeta tests
# ---------------------------------------------------------------------------

class TestHyperionMeta:
    def test_from_headers_hit(self):
        meta = HyperionMeta.from_headers({
            "x-cache-status": "HIT",
            "x-cache-type": "semantic",
            "x-similarity-score": "0.9823",
        })
        assert meta.cache_status == "HIT"
        assert meta.cache_type == "semantic"
        assert abs(meta.similarity_score - 0.9823) < 1e-4
        assert meta.is_hit is True

    def test_from_headers_miss(self):
        meta = HyperionMeta.from_headers({"x-cache-status": "MISS"})
        assert meta.cache_status == "MISS"
        assert meta.cache_type is None
        assert meta.similarity_score is None
        assert meta.is_hit is False

    def test_from_headers_exact_hit(self):
        meta = HyperionMeta.from_headers({
            "x-cache-status": "HIT",
            "x-cache-type": "exact",
        })
        assert meta.cache_type == "exact"
        assert meta.similarity_score is None

    def test_from_headers_bypass(self):
        meta = HyperionMeta.from_headers({"x-cache-status": "BYPASS"})
        assert meta.cache_status == "BYPASS"
        assert meta.is_hit is False

    def test_defaults_on_empty(self):
        meta = HyperionMeta.from_headers({})
        assert meta.cache_status == "MISS"
        assert meta.is_hit is False

    def test_repr(self):
        meta = HyperionMeta(cache_status="HIT", cache_type="exact")
        assert "HIT" in repr(meta)


# ---------------------------------------------------------------------------
# patch() tests
# ---------------------------------------------------------------------------

class TestPatch:
    def test_patch_overrides_base_url(self):
        import openai as openai_module
        from hyperion.patch import patch

        patch(openai_module, base_url="http://test-gateway:9999/v1", api_key="test-key")

        client = openai_module.OpenAI()
        assert "9999" in str(client.base_url)
