"""
RAG Eval SDK — Standalone LLM evaluation library for RAG systems.

Usage (standalone — no server needed):
    from rageval_sdk import evaluate

    result = evaluate(
        question="What is the capital of France?",
        answer="The capital of France is Paris.",
        contexts=["Paris is the capital and largest city of France."],
        api_key="sk-your-openai-key",
    )
    print(result["overall_score"])

Advanced (custom config):
    from rageval_sdk import evaluate, EvalConfig

    config = EvalConfig(
        api_key="sk-...",
        base_url="https://api.openai.com/v1",
        stage_1_model="gpt-4o",
    )
    result = evaluate(question="...", answer="...", config=config)

Server mode (requires a running RAG Eval API server):
    from rageval_sdk import RagEvalClient, RagEvalCallback
"""

__version__ = "0.1.2"

from rageval_sdk._config import EvalConfig
from rageval_sdk._engine import RagEvaluator
from rageval_sdk._evaluator import evaluate, evaluate_trace
from rageval_sdk.client import RagEvalClient


def __getattr__(name: str):
    """Lazy import for optional dependencies (LangChain callback)."""
    if name == "RagEvalCallback":
        from rageval_sdk.callback import RagEvalCallback

        return RagEvalCallback
    raise AttributeError(f"module 'rageval_sdk' has no attribute {name!r}")


__all__ = [
    "EvalConfig",
    "RagEvaluator",
    "evaluate",
    "evaluate_trace",
    "RagEvalClient",
    "RagEvalCallback",
    "__version__",
]
