"""Payload serialization for the Durable Workflow worker protocol.

The server exposes a language-neutral payload envelope (see issue #164 and
``docs/configuration/worker-protocol.md`` in the docs repo).  Every payload on
the wire carries a ``payload_codec`` tag alongside its opaque blob.

Supported codecs:

- ``"json"`` — the blob is a UTF-8 JSON document. Supported for decoding
  existing data only, not used for new workflows.
- ``"avro"`` — the blob is a base64-encoded Avro generic-wrapper payload
  (see :mod:`durable_workflow._avro`). Default for all new v2 workflows.
  The wrapper carries JSON-native values only. Class-carrying values such as
  dataclasses, attrs classes, pydantic models, pendulum values, datetimes,
  UUIDs, ``Decimal``, and plain ``Enum`` values need an explicit adapter to a
  dictionary or scalar before encode; JSON-subclass values such as ``IntEnum``
  and ``StrEnum`` round-trip as their JSON scalar, not as the original class.
"""
from __future__ import annotations

import json
import logging
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, fields, is_dataclass
from datetime import date, datetime, time
from decimal import Decimal
from enum import Enum
from typing import Any, TypeGuard, cast
from uuid import UUID

from . import _avro
from .external_storage import (
    ExternalPayloadCache,
    ExternalPayloadReference,
    ExternalStorageDriver,
    fetch_external_payload,
    store_external_payload,
)

JSON_CODEC = "json"
AVRO_CODEC = "avro"
SUPPORTED_CODECS = (JSON_CODEC, AVRO_CODEC)
DEFAULT_PAYLOAD_SIZE_BYTES = 2_097_152
DEFAULT_WARNING_THRESHOLD_PERCENT = 80

log = logging.getLogger("durable_workflow.serializer")


@dataclass(frozen=True)
class PayloadSizeWarningConfig:
    """Configuration for pre-flight payload-size warnings."""

    limit_bytes: int = DEFAULT_PAYLOAD_SIZE_BYTES
    threshold_percent: int = DEFAULT_WARNING_THRESHOLD_PERCENT

    @property
    def threshold_bytes(self) -> int:
        return max(1, (self.limit_bytes * self.threshold_percent) // 100)

    def __post_init__(self) -> None:
        if self.limit_bytes < 1:
            raise ValueError("payload size warning limit must be at least 1 byte")
        if self.threshold_percent < 1 or self.threshold_percent > 100:
            raise ValueError("payload size warning threshold percent must be between 1 and 100")


@dataclass(frozen=True)
class PayloadSizeWarningContext:
    """Structured context attached to payload-size warning logs."""

    kind: str
    workflow_id: str | None = None
    workflow_type: str | None = None
    run_id: str | None = None
    activity_name: str | None = None
    signal_name: str | None = None
    update_name: str | None = None
    query_name: str | None = None
    schedule_id: str | None = None
    task_queue: str | None = None
    namespace: str | None = None

    def to_log_context(self) -> dict[str, str]:
        values = {
            "kind": self.kind,
            "workflow_id": self.workflow_id,
            "workflow_type": self.workflow_type,
            "run_id": self.run_id,
            "activity_name": self.activity_name,
            "signal_name": self.signal_name,
            "update_name": self.update_name,
            "query_name": self.query_name,
            "schedule_id": self.schedule_id,
            "task_queue": self.task_queue,
            "namespace": self.namespace,
        }
        return {key: value for key, value in values.items() if value is not None}


DEFAULT_PAYLOAD_SIZE_WARNING = PayloadSizeWarningConfig()
PayloadWarningContext = PayloadSizeWarningContext | Mapping[str, Any] | None
PayloadWarningContexts = PayloadWarningContext | Sequence[PayloadWarningContext]


def to_avro_payload_value(value: Any) -> Any:
    """Convert common rich Python values to JSON-native Avro wrapper values.

    The SDK's default Avro codec is a language-neutral envelope around a JSON
    document. This helper is the explicit boundary for class-carrying values:
    callers opt in before encode and the returned value becomes part of durable
    history.
    """
    if isinstance(value, Enum):
        return to_avro_payload_value(value.value)

    if value is None or isinstance(value, str | int | float | bool):
        return value

    if isinstance(value, datetime):
        return value.isoformat()

    if isinstance(value, date | time):
        return value.isoformat()

    if isinstance(value, UUID | Decimal):
        return str(value)

    if isinstance(value, Mapping):
        converted: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("Avro JSON payload dictionaries must use string keys after adaptation")
            converted[key] = to_avro_payload_value(item)
        return converted

    if is_dataclass(value) and not isinstance(value, type):
        return {
            field.name: to_avro_payload_value(getattr(value, field.name))
            for field in fields(value)
        }

    pydantic_dump = _pydantic_model_dump(value)
    if pydantic_dump is not None:
        return to_avro_payload_value(pydantic_dump)

    attrs_dump = _attrs_payload_dict(value)
    if attrs_dump is not None:
        return attrs_dump

    if isinstance(value, Sequence) and not isinstance(value, str | bytes | bytearray):
        return [to_avro_payload_value(item) for item in value]

    raise TypeError(
        f"Object of type {type(value).__name__} is not Avro JSON payload safe; "
        "adapt it to None, bool, int, float, str, list, or dict[str, value] first."
    )


def to_avro_payload_values(values: Sequence[Any]) -> list[Any]:
    """Convert several values with :func:`to_avro_payload_value`."""
    return [to_avro_payload_value(value) for value in values]


def _pydantic_model_dump(value: Any) -> Any | None:
    if not (
        hasattr(value, "__pydantic_fields__")
        or hasattr(value, "__fields__")
        or value.__class__.__module__.startswith("pydantic.")
    ):
        return None

    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        return model_dump(mode="json")

    dict_dump = getattr(value, "dict", None)
    if callable(dict_dump):
        return dict_dump()

    return None


def _attrs_payload_dict(value: Any) -> dict[str, Any] | None:
    attrs_fields = getattr(value.__class__, "__attrs_attrs__", None)
    if attrs_fields is None:
        return None
    return {
        field.name: to_avro_payload_value(getattr(value, field.name))
        for field in attrs_fields
    }


def encode(
    value: Any,
    codec: str = AVRO_CODEC,
    *,
    size_warning: PayloadSizeWarningConfig | None = DEFAULT_PAYLOAD_SIZE_WARNING,
    warning_context: PayloadSizeWarningContext | Mapping[str, Any] | None = None,
) -> str:
    """Encode a Python value as a payload blob for *codec*.

    Raises ``ValueError`` for unknown codecs and
    :class:`~durable_workflow.errors.AvroNotInstalledError` when the Avro
    runtime dependency is missing from a broken or partial installation.
    """
    if codec == JSON_CODEC:
        blob = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
    elif codec == AVRO_CODEC:
        blob = _avro.encode(value)
    else:
        raise ValueError(
            f"Unsupported payload codec {codec!r}; this SDK supports {SUPPORTED_CODECS!r}."
        )
    warn_if_payload_near_limit(
        blob,
        codec=codec,
        size_warning=size_warning,
        warning_context=warning_context,
    )
    return blob


def encode_many(
    values: Sequence[Any],
    codec: str = AVRO_CODEC,
    *,
    size_warning: PayloadSizeWarningConfig | None = DEFAULT_PAYLOAD_SIZE_WARNING,
    warning_context: PayloadWarningContexts = None,
) -> list[str]:
    """Encode several payload blobs through one codec hook.

    The default implementation intentionally preserves the single-value
    encoder semantics and warning behavior. Codecs that can safely batch or
    parallelize work can specialize behind this boundary without changing
    call sites.
    """
    contexts = _warning_contexts_for_values(values, warning_context)
    if codec == JSON_CODEC:
        blobs = [
            json.dumps(value, separators=(",", ":"), ensure_ascii=False)
            for value in values
        ]
    elif codec == AVRO_CODEC:
        blobs = _avro.encode_many(list(values))
    else:
        raise ValueError(
            f"Unsupported payload codec {codec!r}; this SDK supports {SUPPORTED_CODECS!r}."
        )

    for index, blob in enumerate(blobs):
        warn_if_payload_near_limit(
            blob,
            codec=codec,
            size_warning=size_warning,
            warning_context=contexts[index],
        )
    return blobs


def envelope(
    value: Any,
    codec: str = AVRO_CODEC,
    *,
    size_warning: PayloadSizeWarningConfig | None = DEFAULT_PAYLOAD_SIZE_WARNING,
    warning_context: PayloadSizeWarningContext | Mapping[str, Any] | None = None,
) -> dict[str, str]:
    """Wrap a value in a ``{codec, blob}`` payload envelope."""
    return {
        "codec": codec,
        "blob": encode(
            value,
            codec=codec,
            size_warning=size_warning,
            warning_context=warning_context,
        ),
    }


def external_storage_envelope(
    value: Any,
    *,
    external_storage: ExternalStorageDriver,
    threshold_bytes: int,
    codec: str = AVRO_CODEC,
    size_warning: PayloadSizeWarningConfig | None = DEFAULT_PAYLOAD_SIZE_WARNING,
    warning_context: PayloadSizeWarningContext | Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Wrap a value in a normal envelope or an external-payload reference.

    Payloads whose encoded UTF-8 size is greater than *threshold_bytes* are
    stored through *external_storage* and represented as ``{codec,
    external_storage}`` so workflow history carries a stable reference instead
    of the large payload bytes.
    """
    if threshold_bytes < 1:
        raise ValueError("external storage threshold must be at least 1 byte")

    blob = encode(
        value,
        codec=codec,
        size_warning=size_warning,
        warning_context=warning_context,
    )
    data = blob.encode("utf-8")
    if len(data) <= threshold_bytes:
        return {"codec": codec, "blob": blob}

    reference = store_external_payload(external_storage, data, codec=codec)
    return {
        "codec": codec,
        "external_storage": reference.to_dict(),
    }


def envelope_many(
    values: Sequence[Any],
    codec: str = AVRO_CODEC,
    *,
    size_warning: PayloadSizeWarningConfig | None = DEFAULT_PAYLOAD_SIZE_WARNING,
    warning_context: PayloadWarningContexts = None,
) -> list[dict[str, str]]:
    """Wrap several values in ``{codec, blob}`` payload envelopes."""
    return [
        {"codec": codec, "blob": blob}
        for blob in encode_many(
            values,
            codec=codec,
            size_warning=size_warning,
            warning_context=warning_context,
        )
    ]


def warn_if_json_payload_near_limit(
    value: Any,
    *,
    size_warning: PayloadSizeWarningConfig | None = DEFAULT_PAYLOAD_SIZE_WARNING,
    warning_context: PayloadSizeWarningContext | Mapping[str, Any] | None = None,
) -> None:
    """Warn when a raw JSON request payload approaches the configured limit."""
    blob = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
    warn_if_payload_near_limit(
        blob,
        codec=JSON_CODEC,
        size_warning=size_warning,
        warning_context=warning_context,
    )


def warn_if_payload_near_limit(
    blob: str,
    *,
    codec: str,
    size_warning: PayloadSizeWarningConfig | None = DEFAULT_PAYLOAD_SIZE_WARNING,
    warning_context: PayloadSizeWarningContext | Mapping[str, Any] | None = None,
) -> None:
    """Emit a structured warning when an encoded payload is close to the server limit."""
    if size_warning is None:
        return

    payload_size = len(blob.encode("utf-8"))
    threshold = size_warning.threshold_bytes
    if payload_size < threshold:
        return

    context = _normalize_warning_context(warning_context)
    log.warning(
        "encoded payload size %d bytes is at or above warning threshold %d bytes "
        "(limit %d bytes)",
        payload_size,
        threshold,
        size_warning.limit_bytes,
        extra={
            "durable_workflow_payload": {
                **context,
                "codec": codec,
                "payload_size": payload_size,
                "threshold_bytes": threshold,
                "limit_bytes": size_warning.limit_bytes,
            },
        },
    )


def _normalize_warning_context(
    context: PayloadSizeWarningContext | Mapping[str, Any] | None,
) -> dict[str, str]:
    if context is None:
        return {"kind": "payload"}
    if isinstance(context, PayloadSizeWarningContext):
        return context.to_log_context()
    normalized: dict[str, str] = {}
    for key, value in context.items():
        if value is not None:
            normalized[str(key)] = str(value)
    if "kind" not in normalized:
        normalized["kind"] = "payload"
    return normalized


def _warning_contexts_for_values(
    values: Sequence[Any],
    context: PayloadWarningContexts,
) -> list[PayloadWarningContext]:
    if not _is_context_sequence(context):
        single_context = cast(PayloadWarningContext, context)
        return [single_context] * len(values)
    if len(context) != len(values):
        raise ValueError("payload warning context count must match value count")
    return list(context)


def _is_context_sequence(
    context: PayloadWarningContexts,
) -> TypeGuard[Sequence[PayloadWarningContext]]:
    return isinstance(context, Sequence) and not isinstance(
        context,
        (str, bytes, bytearray, PayloadSizeWarningContext, Mapping),
    )


def decode_envelope(
    value: Any,
    codec: str | None = None,
    *,
    external_storage: ExternalStorageDriver | None = None,
    external_storage_cache: ExternalPayloadCache | None = None,
) -> Any:
    """Decode a value that may be a ``{codec, blob}`` envelope or a raw blob.

    When *value* is an envelope, its inner ``codec`` takes precedence over
    the *codec* argument.  When *value* is a raw blob, *codec* selects the
    decoder (defaulting to JSON).  External payload references require an
    *external_storage* driver and verify size/hash before decode.
    """
    if isinstance(value, dict) and "codec" in value and "blob" in value:
        return decode(value["blob"], codec=value["codec"])
    if isinstance(value, dict) and "external_storage" in value:
        if external_storage is None:
            raise ValueError("external payload reference requires an external storage driver")
        reference = ExternalPayloadReference.from_dict(value["external_storage"])
        envelope_codec = value.get("codec")
        if envelope_codec is not None and envelope_codec != reference.codec:
            raise ValueError("external payload reference codec does not match envelope codec")
        blob = fetch_external_payload(external_storage, reference, cache=external_storage_cache).decode("utf-8")
        return decode(blob, codec=reference.codec)
    return decode(value, codec=codec)


def decode_envelopes(
    values: Sequence[Any],
    codec: str | None = None,
    *,
    external_storage: ExternalStorageDriver | None = None,
    external_storage_cache: ExternalPayloadCache | None = None,
) -> list[Any]:
    """Decode several raw blobs or ``{codec, blob}`` envelopes in order."""
    if external_storage is not None or any(
        isinstance(value, dict) and "external_storage" in value for value in values
    ):
        return [
            decode_envelope(
                value,
                codec=codec,
                external_storage=external_storage,
                external_storage_cache=external_storage_cache,
            )
            for value in values
        ]

    jobs: list[tuple[str | None, str | None]] = []
    passthroughs: dict[int, Any] = {}
    for index, value in enumerate(values):
        if isinstance(value, dict) and "codec" in value and "blob" in value:
            jobs.append((value["blob"], value["codec"]))
        elif value is None or value == "":
            passthroughs[index] = None
            jobs.append((None, None))
        else:
            jobs.append((value, codec))

    results: list[Any] = [None] * len(values)
    grouped: dict[str | None, list[tuple[int, str | None]]] = {}
    for index, (blob, item_codec) in enumerate(jobs):
        if index in passthroughs:
            continue
        grouped.setdefault(item_codec, []).append((index, blob))

    for item_codec, group in grouped.items():
        decoded = decode_many([blob for _, blob in group], codec=item_codec)
        for (index, _), value in zip(group, decoded, strict=True):
            results[index] = value

    return results


def decode_many(blobs: Sequence[str | None], codec: str | None = None) -> list[Any]:
    """Decode several payload blobs with one codec visit when possible."""
    if codec is None or codec == JSON_CODEC:
        return [decode(blob, codec=codec) for blob in blobs]

    if codec == AVRO_CODEC:
        decoded: list[Any] = [None] * len(blobs)
        avro_jobs: list[tuple[int, str]] = []
        for index, blob in enumerate(blobs):
            if blob is None or blob == "":
                continue
            avro_jobs.append((index, blob))
        if not avro_jobs:
            return decoded
        avro_values = _avro.decode_many([blob for _, blob in avro_jobs])
        for (index, _), value in zip(avro_jobs, avro_values, strict=True):
            decoded[index] = value
        return decoded

    raise ValueError(
        f"Cannot decode payload with codec {codec!r}: this SDK supports "
        f"{SUPPORTED_CODECS!r}. Ensure the workflow was started with a "
        f"compatible codec or an explicit {{'codec': '<codec>', 'blob': '...'}} envelope."
    )


def decode(blob: str | None, codec: str | None = None) -> Any:
    """Decode a payload blob into a Python value.

    Raises ``ValueError`` for unknown codecs or malformed blobs, and
    :class:`~durable_workflow.errors.AvroNotInstalledError` when the Avro
    runtime dependency is missing from a broken or partial installation.
    """
    if blob is None or blob == "":
        return None

    if codec is None or codec == JSON_CODEC:
        try:
            return json.loads(blob)
        except (json.JSONDecodeError, TypeError) as exc:
            raise ValueError(f"Payload is not valid JSON: {exc}") from exc

    if codec == AVRO_CODEC:
        return _avro.decode(blob)

    raise ValueError(
        f"Cannot decode payload with codec {codec!r}: this SDK supports "
        f"{SUPPORTED_CODECS!r}. Ensure the workflow was started with a "
        f"compatible codec or an explicit {{'codec': '<codec>', 'blob': '...'}} envelope."
    )
