"""Event logging — streams events to terminal and writes JSONL to ~/.safe-colab/logs/.

Audit logs are stored in the user's home directory (not in work_dir) so they
cannot be tampered with by sandboxed code or overwritten by the remote agent.

Structure:
    ~/.safe-colab/
    ├── .env                              # Credentials
    └── logs/
        └── <date>_<session-id-short>/
            ├── session.meta.json         # Session metadata
            └── session.log.jsonl         # Full audit trail
"""

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger("safe_colab_cli.event_log")


def get_session_log_dir(session_id: str) -> Path:
    """Get the log directory for a session under ~/.safe-colab/logs/."""
    config_home = os.environ.get("SAFE_COLAB_HOME", os.path.join(Path.home(), ".safe-colab"))
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    short_id = session_id[:8]
    log_dir = Path(config_home) / "logs" / f"{date_str}_{short_id}"
    return log_dir


class EventLogger:
    """Logs events to terminal (streaming) and JSONL file (persistent).

    Logs are written to ~/.safe-colab/logs/<date>_<session>/ which is
    outside the work directory and protected from sandboxed code.
    """

    def __init__(self, session_id: str, verbose: int = 1,
                 data_dir: str = "", work_dir: str = "", user_email: str = "",
                 guardian_url: str = "", sandbox_backend: str = ""):
        self.session_id = session_id
        self.verbose = verbose
        self._log_dir = get_session_log_dir(session_id)
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._log_file = self._log_dir / "session.log.jsonl"
        self._session_start = time.time()

        # Write session metadata
        meta = {
            "session_id": session_id,
            "started_at": _now(),
            "data_dir": data_dir,
            "work_dir": work_dir,
            "user_email": user_email,
            "guardian_url": guardian_url,
            "sandbox_backend": sandbox_backend,
            "log_dir": str(self._log_dir),
        }
        meta_file = self._log_dir / "session.meta.json"
        try:
            with open(meta_file, "w") as f:
                json.dump(meta, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to write session metadata: {e}")

    @property
    def log_dir(self) -> Path:
        return self._log_dir

    def _write(self, entry: dict):
        """Append entry to JSONL log file."""
        try:
            with open(self._log_file, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            logger.warning(f"Failed to write audit log: {e}")

    def _print(self, icon: str, msg: str, level: int = 1):
        """Print to terminal if verbose enough."""
        if self.verbose >= level:
            elapsed = time.time() - self._session_start
            ts = f"[{elapsed:7.1f}s]"
            print(f"  {ts} {icon} {msg}", flush=True)

    def session_start(self, **kwargs):
        entry = {"event": "session_start", "ts": _now(), **kwargs}
        self._write(entry)
        self._print(">>", f"Session started", 1)

    def session_end(self):
        entry = {"event": "session_end", "ts": _now(),
                 "duration_s": round(time.time() - self._session_start, 1)}
        self._write(entry)
        self._print("<<", f"Session ended", 1)

    def code_submitted(self, code: str):
        preview = code.strip().split("\n")[0][:80]
        entry = {"event": "code_submitted", "ts": _now(), "code_length": len(code),
                 "preview": preview, "code": code}
        self._write(entry)
        self._print(">>", f"Code: {preview}", 1)

    def code_security_check(self, is_safe: bool, reason: str, duration_s: float):
        entry = {"event": "code_security_check", "ts": _now(), "is_safe": is_safe,
                 "reason": reason, "duration_s": round(duration_s, 2)}
        self._write(entry)
        icon = "OK" if is_safe else "XX"
        self._print(icon, f"Security: {'safe' if is_safe else 'BLOCKED'} ({duration_s:.1f}s) — {reason[:80]}", 1)

    def code_executed(self, stdout_len: int, stderr_len: int, has_error: bool, duration_s: float):
        entry = {"event": "code_executed", "ts": _now(), "stdout_len": stdout_len,
                 "stderr_len": stderr_len, "has_error": has_error,
                 "duration_s": round(duration_s, 2)}
        self._write(entry)
        status = "error" if has_error else "ok"
        self._print("<<", f"Result: {status} (stdout={stdout_len}b, {duration_s:.1f}s)", 1)

    def output_security_check(self, is_safe: bool, reason: str, duration_s: float):
        entry = {"event": "output_security_check", "ts": _now(), "is_safe": is_safe,
                 "reason": reason, "duration_s": round(duration_s, 2)}
        self._write(entry)
        icon = "OK" if is_safe else "XX"
        self._print(icon, f"Output check: {'safe' if is_safe else 'BLOCKED'} ({duration_s:.1f}s)", 1)

    def command_submitted(self, command: str):
        entry = {"event": "command_submitted", "ts": _now(), "command": command[:500]}
        self._write(entry)
        self._print(">>", f"Command: {command[:80]}", 1)

    def command_executed(self, returncode: int, duration_s: float):
        entry = {"event": "command_executed", "ts": _now(), "returncode": returncode,
                 "duration_s": round(duration_s, 2)}
        self._write(entry)
        self._print("<<", f"Command: exit={returncode} ({duration_s:.1f}s)", 1)

    def file_uploaded(self, path: str, url: str):
        entry = {"event": "file_uploaded", "ts": _now(), "path": path, "url": url[:200]}
        self._write(entry)
        self._print("UP", f"Uploaded: {path}", 1)

    def security_blocked(self, event_type: str, reason: str):
        entry = {"event": "security_blocked", "ts": _now(), "type": event_type, "reason": reason}
        self._write(entry)
        self._print("!!", f"BLOCKED ({event_type}): {reason[:80]}", 0)  # Always show blocks


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
