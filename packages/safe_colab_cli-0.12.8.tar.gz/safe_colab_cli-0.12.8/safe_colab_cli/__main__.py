"""Allow running as python -m safe_colab_cli."""
from .cli import main

main()
