"""Guardian agent client — calls the security agent to validate code and output.

The security agent is a FastAPI service (local or remote) that uses LLMs
to check whether code/output is safe before allowing execution.
"""

import time
import logging
import httpx

logger = logging.getLogger("safe_colab_cli.guardian")


class GuardianAgent:
    """Client for the security agent service."""

    def __init__(self, endpoint_url: str, auth_token: str = "", dataset_description: str = ""):
        self.endpoint_url = endpoint_url.rstrip("/")
        self.auth_token = auth_token
        self.dataset_description = dataset_description
        self._headers = {"Content-Type": "application/json"}
        if auth_token:
            self._headers["Authorization"] = f"Bearer {auth_token}"

    async def check_code(self, code: str) -> dict:
        """Check code before execution. Returns {is_safe, reason, summary} or {error}."""
        t0 = time.time()
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(
                    f"{self.endpoint_url}/ensure_code_secure",
                    json={
                        "code": code,
                        "dataset_description": self.dataset_description,
                    },
                    headers=self._headers,
                )
                if resp.status_code != 200:
                    return {"error": f"Security agent returned {resp.status_code}: {resp.text}"}
                result = resp.json()
        except Exception as e:
            return {"error": f"Security agent unreachable: {e}"}

        duration = time.time() - t0
        if result.get("refusal"):
            logger.warning(f"Code check refused ({duration:.1f}s): {result['refusal']}")
            return {"error": result["refusal"]}
        parsed = result.get("parsed", {})
        logger.info(f"Code check ({duration:.1f}s): safe={parsed.get('is_safe')} — {parsed.get('reason', '')[:100]}")
        return parsed

    async def check_output(self, code: str, output: str) -> dict:
        """Check code output for data leakage. Returns {is_safe, reason, summary} or {error}."""
        t0 = time.time()
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(
                    f"{self.endpoint_url}/ensure_output_secure",
                    json={
                        "code": code,
                        "code_output": output,
                        "dataset_description": self.dataset_description,
                    },
                    headers=self._headers,
                )
                if resp.status_code != 200:
                    return {"error": f"Security agent returned {resp.status_code}: {resp.text}"}
                result = resp.json()
        except Exception as e:
            return {"error": f"Security agent unreachable: {e}"}

        duration = time.time() - t0
        if result.get("refusal"):
            logger.warning(f"Output check refused ({duration:.1f}s): {result['refusal']}")
            return {"error": result["refusal"]}
        parsed = result.get("parsed", {})
        logger.info(f"Output check ({duration:.1f}s): safe={parsed.get('is_safe')} — {parsed.get('reason', '')[:100]}")
        return parsed

    async def health(self) -> bool:
        """Check if the security agent is reachable."""
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.endpoint_url}/health")
                return resp.status_code == 200
        except Exception:
            return False
