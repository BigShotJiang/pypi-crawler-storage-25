"""Test nono sandbox security - filesystem isolation and attack simulations.

These tests verify that the sandbox correctly:
1. Allows read access to the data directory
2. Allows read-write access to the work directory
3. Blocks access to files outside allowed directories
4. Blocks modification of read-only data directory
"""

import os
import sys
import pytest
import subprocess
import tempfile
import shutil


def _has_nono():
    """Check if nono_py is available and platform is supported."""
    try:
        from nono_py import is_supported
        return is_supported()
    except ImportError:
        return False


# All sandbox tests require nono
pytestmark = pytest.mark.skipif(not _has_nono(), reason="nono_py not installed or platform unsupported")


@pytest.fixture
def sandbox_dirs(tmp_path):
    """Create test directories with sample data."""
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "secret.csv").write_text("patient_id,name\n1,Alice\n2,Bob\n")
    (data_dir / "config.json").write_text('{"version": 1}')

    work_dir = tmp_path / "workspace"
    work_dir.mkdir()

    return str(data_dir), str(work_dir)


def _run_sandboxed(data_dir: str, work_dir: str, code: str, timeout: int = 30) -> dict:
    """Run Python code inside a nono sandbox in a subprocess.

    Returns dict with stdout, stderr, returncode.
    """
    # Build the sandbox setup + user code as a single script
    script = f'''
import os, sys

# Apply sandbox
from nono_py import CapabilitySet, AccessMode, apply, is_supported

if not is_supported():
    print("SKIP: Platform does not support sandboxing")
    sys.exit(0)

caps = CapabilitySet()

# Data dir: read-only
caps.allow_path("{data_dir}", AccessMode.READ)

# Work dir: read-write
caps.allow_path("{work_dir}", AccessMode.READ_WRITE)

# Python paths (read-only) so imports work
for p in sys.path:
    if p and os.path.isdir(p):
        caps.allow_path(p, AccessMode.READ)

# System paths
for p in [sys.prefix, sys.exec_prefix]:
    if p and os.path.isdir(p):
        caps.allow_path(p, AccessMode.READ)

if hasattr(sys, "base_prefix") and os.path.isdir(sys.base_prefix):
    caps.allow_path(sys.base_prefix, AccessMode.READ)

# /tmp for temp files
if os.path.isdir("/tmp"):
    caps.allow_path("/tmp", AccessMode.READ_WRITE)

apply(caps)
print("SANDBOX_APPLIED")

# ---- User code below ----
{code}
'''

    proc = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True, text=True, timeout=timeout,
        cwd=work_dir,
    )
    return {
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "returncode": proc.returncode,
    }


# ─── Tests: Allowed operations ───

class TestSandboxAllowed:
    """Verify that legitimate operations work inside the sandbox."""

    def test_read_data_dir(self, sandbox_dirs):
        """Reading files from data directory should succeed."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
with open("{data_dir}/secret.csv") as f:
    print(f.read())
''')
        assert "SANDBOX_APPLIED" in result["stdout"]
        assert "Alice" in result["stdout"]
        assert result["returncode"] == 0

    def test_list_data_dir(self, sandbox_dirs):
        """Listing data directory should succeed."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
import os
files = os.listdir("{data_dir}")
print(f"files: {{files}}")
''')
        assert "secret.csv" in result["stdout"]

    def test_write_work_dir(self, sandbox_dirs):
        """Writing to work directory should succeed."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
with open("{work_dir}/output.txt", "w") as f:
    f.write("analysis results")
print("written")
# Verify
with open("{work_dir}/output.txt") as f:
    print(f.read())
''')
        assert "written" in result["stdout"]
        assert "analysis results" in result["stdout"]

    def test_create_subdir_in_work(self, sandbox_dirs):
        """Creating subdirectories in work directory should succeed."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
import os
os.makedirs("{work_dir}/results/plots", exist_ok=True)
with open("{work_dir}/results/plots/fig1.txt", "w") as f:
    f.write("plot data")
print("subdir created")
''')
        assert "subdir created" in result["stdout"]

    def test_python_imports(self, sandbox_dirs):
        """Standard library imports should work."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, '''
import json, csv, os, sys, math, hashlib, datetime
print("imports ok")
''')
        assert "imports ok" in result["stdout"]


# ─── Tests: Blocked operations (attack simulations) ───

class TestSandboxBlocked:
    """Simulate attacks that the sandbox should block."""

    def test_read_etc_passwd(self, sandbox_dirs):
        """Reading /etc/passwd should fail."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, '''
try:
    with open("/etc/passwd") as f:
        print("LEAKED:", f.read()[:100])
    print("FAIL: should have been blocked")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {e}")
''')
        assert "BLOCKED" in result["stdout"]
        assert "LEAKED" not in result["stdout"]

    def test_read_home_ssh(self, sandbox_dirs):
        """Reading ~/.ssh/ should fail."""
        data_dir, work_dir = sandbox_dirs
        ssh_dir = os.path.expanduser("~/.ssh")
        result = _run_sandboxed(data_dir, work_dir, f'''
import os
try:
    files = os.listdir("{ssh_dir}")
    print(f"LEAKED: {{files}}")
    print("FAIL: should have been blocked")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {{e}}")
''')
        assert "BLOCKED" in result["stdout"] or "SANDBOX_APPLIED" in result["stdout"]
        assert "LEAKED" not in result["stdout"]

    def test_write_to_data_dir(self, sandbox_dirs):
        """Writing to data directory (read-only) should fail."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
try:
    with open("{data_dir}/malicious.txt", "w") as f:
        f.write("pwned")
    print("FAIL: write to data dir succeeded")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {{e}}")
''')
        assert "BLOCKED" in result["stdout"]
        assert "FAIL" not in result["stdout"]

    def test_delete_data_file(self, sandbox_dirs):
        """Deleting a file in data directory should fail."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
import os
try:
    os.remove("{data_dir}/secret.csv")
    print("FAIL: delete in data dir succeeded")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {{e}}")
''')
        assert "BLOCKED" in result["stdout"]
        # Verify file still exists
        assert os.path.exists(os.path.join(data_dir, "secret.csv"))

    def test_modify_data_file(self, sandbox_dirs):
        """Modifying a file in data directory should fail."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
try:
    with open("{data_dir}/secret.csv", "a") as f:
        f.write("\\n3,Mallory\\n")
    print("FAIL: append to data file succeeded")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {{e}}")
''')
        assert "BLOCKED" in result["stdout"]

    def test_read_outside_dirs(self, sandbox_dirs):
        """Reading files outside data/work dirs should fail."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, '''
try:
    with open("/var/log/system.log") as f:
        print("LEAKED:", f.read()[:50])
    print("FAIL: read outside dirs succeeded")
except (PermissionError, OSError, FileNotFoundError) as e:
    print(f"BLOCKED: {e}")
''')
        assert "LEAKED" not in result["stdout"]

    def test_symlink_escape(self, sandbox_dirs):
        """Creating a symlink to escape the sandbox should fail."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, f'''
import os
try:
    # Try to create a symlink from work_dir pointing to /etc
    os.symlink("/etc", "{work_dir}/escape_link")
    # Even if symlink creation works, reading through it should fail
    with open("{work_dir}/escape_link/passwd") as f:
        print("LEAKED:", f.read()[:50])
    print("FAIL: symlink escape succeeded")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {{e}}")
''')
        assert "LEAKED" not in result["stdout"]

    def test_subprocess_escape(self, sandbox_dirs):
        """Spawning a subprocess should inherit sandbox restrictions.

        On macOS with Seatbelt, accessing a blocked file from a subprocess
        can cause the process to be killed (SIGKILL), resulting in a hang/timeout.
        This is correct sandbox behavior — the subprocess cannot read the file.
        """
        data_dir, work_dir = sandbox_dirs
        result = None
        try:
            result = _run_sandboxed(data_dir, work_dir, '''
import subprocess
try:
    proc = subprocess.run(["cat", "/etc/passwd"], capture_output=True, text=True, timeout=3)
    if proc.returncode == 0 and proc.stdout:
        print("LEAKED:", proc.stdout[:50])
        print("FAIL: subprocess escaped sandbox")
    else:
        print(f"BLOCKED: returncode={proc.returncode}")
except subprocess.TimeoutExpired:
    print("BLOCKED: subprocess timed out (sandbox killed it)")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {e}")
''', timeout=10)
        except subprocess.TimeoutExpired:
            # Timeout = sandbox killed the subprocess. This is correct behavior.
            pass
        # If we got output, verify no data leaked
        if result:
            assert "LEAKED" not in result["stdout"]

    def test_write_outside_work_dir(self, sandbox_dirs):
        """Writing to a directory outside work_dir should fail."""
        data_dir, work_dir = sandbox_dirs
        result = _run_sandboxed(data_dir, work_dir, '''
try:
    with open("/var/tmp/safe_colab_escape_test.txt", "w") as f:
        f.write("escaped!")
    print("FAIL: write outside work dir succeeded")
except (PermissionError, OSError) as e:
    print(f"BLOCKED: {e}")
''')
        assert "BLOCKED" in result["stdout"]
        assert not os.path.exists("/var/tmp/safe_colab_escape_test.txt")
