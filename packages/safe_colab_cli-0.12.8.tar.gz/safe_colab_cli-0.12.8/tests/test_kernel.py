"""Test the Jupyter kernel manager."""

import pytest
from safe_colab_cli.kernel import SandboxKernel


@pytest.fixture
async def kernel():
    k = SandboxKernel()
    await k.start()
    yield k
    await k.stop()


@pytest.mark.asyncio
async def test_kernel_start_stop():
    """Test kernel can start and stop."""
    k = SandboxKernel()
    await k.start()
    assert k._km is not None
    assert k._kc is not None
    await k.stop()


@pytest.mark.asyncio
async def test_kernel_execute_simple(kernel):
    """Test simple code execution."""
    result = await kernel.execute("print('hello world')")
    assert result["stdout"].strip() == "hello world"
    assert result["error"] is None


@pytest.mark.asyncio
async def test_kernel_execute_result(kernel):
    """Test expression result capture."""
    result = await kernel.execute("2 + 3")
    assert result["result"] == "5"
    assert result["error"] is None


@pytest.mark.asyncio
async def test_kernel_execute_error(kernel):
    """Test error capture."""
    result = await kernel.execute("1/0")
    assert result["error"] is not None
    assert result["error"]["ename"] == "ZeroDivisionError"


@pytest.mark.asyncio
async def test_kernel_execute_multiline(kernel):
    """Test multiline code execution."""
    code = """
import os
cwd = os.getcwd()
print(f"cwd: {cwd}")
"""
    result = await kernel.execute(code)
    assert "cwd:" in result["stdout"]
    assert result["error"] is None


@pytest.mark.asyncio
async def test_kernel_execute_stderr(kernel):
    """Test stderr capture."""
    code = """
import sys
print("error msg", file=sys.stderr)
"""
    result = await kernel.execute(code)
    assert "error msg" in result["stderr"]


@pytest.mark.asyncio
async def test_kernel_state_persistence(kernel):
    """Test that variables persist across executions."""
    await kernel.execute("x = 42")
    result = await kernel.execute("print(x)")
    assert result["stdout"].strip() == "42"
