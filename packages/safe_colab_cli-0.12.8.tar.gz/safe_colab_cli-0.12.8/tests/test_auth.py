"""Test authentication and credential management."""

import os
import json
import base64
import time
import pytest

from safe_colab_cli.auth import (
    save_credentials,
    load_credentials,
    decode_token,
    is_token_expired,
    extract_workspace_from_token,
    extract_email_from_token,
)


def _make_jwt(payload: dict) -> str:
    """Create a fake JWT for testing (not cryptographically valid)."""
    header = base64.urlsafe_b64encode(json.dumps({"alg": "none"}).encode()).rstrip(b"=").decode()
    body = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=").decode()
    return f"{header}.{body}.fake_signature"


class TestTokenDecoding:
    def test_decode_valid_token(self):
        token = _make_jwt({"sub": "user-1", "exp": 9999999999})
        payload = decode_token(token)
        assert payload["sub"] == "user-1"

    def test_decode_invalid_token(self):
        assert decode_token("not-a-jwt") is None
        assert decode_token("") is None

    def test_token_not_expired(self):
        token = _make_jwt({"exp": int(time.time()) + 3600})
        assert not is_token_expired(token)

    def test_token_expired(self):
        token = _make_jwt({"exp": int(time.time()) - 3600})
        assert is_token_expired(token)

    def test_token_no_exp(self):
        token = _make_jwt({"sub": "user-1"})
        assert not is_token_expired(token)

    def test_extract_workspace(self):
        token = _make_jwt({"scope": "ws:my-workspace#rw wid:my-workspace"})
        assert extract_workspace_from_token(token) == "my-workspace"

    def test_extract_workspace_with_pipe(self):
        token = _make_jwt({"scope": "ws:ws-user-github|12345#rw"})
        assert extract_workspace_from_token(token) == "ws-user-github|12345"

    def test_extract_email(self):
        token = _make_jwt({"https://amun.ai/email": "test@example.com"})
        assert extract_email_from_token(token) == "test@example.com"


class TestCredentialStorage:
    def test_save_and_load(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SAFE_COLAB_HOME", str(tmp_path / ".safe-colab"))
        valid_token = _make_jwt({"sub": "u1", "exp": int(time.time()) + 3600})
        save_credentials("https://hypha.test", valid_token, "my-ws")

        creds = load_credentials()
        assert creds["server_url"] == "https://hypha.test"
        assert creds["token"] == valid_token
        assert creds["workspace"] == "my-ws"

    def test_load_filters_expired(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SAFE_COLAB_HOME", str(tmp_path / ".safe-colab"))
        expired_token = _make_jwt({"exp": int(time.time()) - 100})
        save_credentials("https://hypha.test", expired_token, "ws")

        creds = load_credentials()
        assert creds["token"] is None  # Expired tokens are filtered out

    def test_load_missing_file(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SAFE_COLAB_HOME", str(tmp_path / "nonexistent"))
        creds = load_credentials()
        assert creds["token"] is None
        assert creds["server_url"] is None

    def test_file_permissions(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SAFE_COLAB_HOME", str(tmp_path / ".safe-colab"))
        path = save_credentials("https://hypha.test", "secret", "ws")
        # File should be owner-only
        mode = oct(os.stat(path).st_mode)[-3:]
        assert mode == "600"

    def test_overwrite_preserves_format(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SAFE_COLAB_HOME", str(tmp_path / ".safe-colab"))
        t1 = _make_jwt({"sub": "u1", "exp": int(time.time()) + 3600})
        t2 = _make_jwt({"sub": "u2", "exp": int(time.time()) + 3600})
        save_credentials("https://a.com", t1, "ws-1")
        save_credentials("https://b.com", t2, "ws-2")

        creds = load_credentials()
        assert creds["server_url"] == "https://b.com"
        assert creds["token"] == t2
