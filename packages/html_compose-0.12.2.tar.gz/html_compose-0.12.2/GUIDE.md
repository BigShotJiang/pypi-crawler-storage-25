# html-compose Getting Started Guide

## Why html-compose exists

You've written HTML in Python before. Maybe you did this:

```python
html = f"<div class='profile'><p>Welcome, {username}!</p></div>"
```

This works until `username` contains `<script>alert('xss')</script>`. Now you need escaping.

Or you used templates:

```jinja2
<div class="profile">
  <p>Welcome, {{ username }}!</p>
</div>
```

This works until you want to:
- Reuse component logic across pages
- Test your UI components in isolation
- Get autocomplete for HTML attributes
- Compose components programmatically

**html-compose solves this:** Write HTML structure directly in Python with full type safety, automatic XSS protection, and composability.

```python
from html_compose import div, p

profile = div(class_="profile")[
    p[f"Welcome, {username}!"]
]
```

The value `username` is automatically escaped. Your editor autocompletes `class_`. Your components are Python functions.

## Installation

```bash
pip install html-compose
```

For live reload during development:
```bash
pip install html-compose[live-reload]
```

For all features:
```bash
pip install html-compose[full]
```

Requires Python 3.10+.

## The Core Mental Model: () and []

Every HTML element in html-compose follows two rules:

1. **`()` sets attributes**
2. **`[]` adds children**

```python
from html_compose import a

link = a(href="/logout")["Log out"]
print(link.render())
# <a href="/logout">Log out</a>
```

That's it. Once you internalize this pattern, everything else follows naturally.

## Your First Element

```python
from html_compose import p

paragraph = p["Hello, world!"]
print(paragraph.render())
# <p>Hello, world!</p>
```

Notice we skipped `()`. When an element has no attributes, you can skip the constructor and go straight to `[]`.

These are identical:

```python
p()["Hello"]
p["Hello"]
```

Use whichever feels more natural. Most developers skip `()` for text-heavy elements.

## Adding Attributes

Attributes go in the `()` call:

```python
from html_compose import div

container = div(id="main", class_="container")
print(container.render())
# <div id="main" class="container"></div>
```

Note `class_` has an underscore because `class` is a Python keyword. This is the only attribute that requires this workaround.

## Combining Attributes and Children

```python
from html_compose import a

link = a(href="https://google.com", target="_blank")["Search Engine"]
print(link.render())
# <a href="https://google.com" target="_blank">Search Engine</a>
```

## Nesting Elements

Children can be other elements:

```python
from html_compose import div, p, strong

message = div(class_="alert")[
    p["This is ", strong["important"], "!"]
]
print(message.render())
# <div class="alert"><p>This is <strong>important</strong>!</p></div>
```

Multiple children are separated by commas:

```python
from html_compose import div, h1, p

content = div[
    h1["Welcome"],
    p["First paragraph"],
    p["Second paragraph"]
]
```

## Automatic XSS Protection

All text is automatically escaped:

```python
from html_compose import div

user_input = "<script>alert('xss')</script>"
safe = div[user_input]
print(safe.render())
# <div>&lt;script&gt;alert('xss')&lt;/script&gt;</div>
```

The script tag is rendered as text, not executed. This happens automatically for:
- Element children
- Attribute values
- Everything

If you have trusted HTML you need to insert, explicitly mark it:

```python
from html_compose import div, unsafe_text

trusted = "<b>This is safe</b>"
element = div[unsafe_text(trusted)]
print(element.render())
# <div><b>This is safe</b></div>
```

Never use `unsafe_text` with user input.

## Building Lists

Use Python list comprehensions naturally:

```python
from html_compose import ul, li

items = ["apples", "oranges", "bananas"]
shopping_list = ul[
    li[item] for item in items
]
print(shopping_list.render())
# <ul><li>apples</li><li>oranges</li><li>bananas</li></ul>
```

This works because html-compose automatically flattens nested iterables.

## Working with Attributes in Depth

### Boolean Attributes

```python
from html_compose import button, script

# True becomes "true"
btn = button(disabled=True)["Can't click me"]
# <button disabled="true">Can't click me</button>

# False omits the attribute
js = script(defer=False)
# <script></script>

js = script(defer=True)
# <script defer="true"></script>
```

### The `class_` Attribute Special Powers

Strings work as expected:

```python
from html_compose import div

element = div(class_="flex items-center")
# <div class="flex items-center"></div>
```

Lists are joined with spaces:

```python
classes = ["flex", "items-center", "justify-between"]
element = div(class_=classes)
# <div class="flex items-center justify-between"></div>
```

Dictionaries enable conditional classes:

```python
is_active = True
is_hidden = False

element = div(class_={
    "active": is_active,
    "hidden": is_hidden,
    "card": True
})
# <div class="active card"></div>
```

Only truthy values are included. This is incredibly useful for dynamic UIs.

### The `style` Attribute Special Powers

Dictionaries become CSS:

```python
element = div(style={
    "color": "red",
    "background-color": "blue",
    "font-size": "16px"
})
# <div style="color: red; background-color: blue; font-size: 16px"></div>
```

### Custom Attributes (data-*, @click, etc.)

For attributes not in the HTML spec, use the `attrs` parameter:

```python
element = div({"data-id": "123", "@click": "handleClick()"})
# <div data-id="123" @click="handleClick()"></div>
```

You can mix dictionaries and keyword arguments:

```python
element = div(
    {"data-id": "123"},
    id="main",
    class_="container"
)
```

### Type-Safe Attributes with Hints

Every element has a `.hint` system (shorthand: `._`) for type-safe attributes:

```python
from html_compose import img

picture = img([
    img.hint.src("/photo.jpg"),
    img.hint.alt("A beautiful sunset")
])

# Shorthand with ._
picture = img([
    img._.src("/photo.jpg"),
    img._.alt("A beautiful sunset")
])
```

This gives you autocomplete and type checking for all valid attributes.

## Creating Complete Documents

### Quick Documents with HTML5Document

```python
from html_compose import HTML5Document, h1, p

doc = HTML5Document(
    title="My Page",
    lang="en",
    js=['/static/app.js'],
    css=['/static/style.css'],
    body=[
        h1["Welcome!"],
        p["This is my page."]
    ]
)

print(str(doc))
```

This generates:
```html
<!DOCTYPE html>
<html lang="en">
<head><meta content="width=device-width, initial-scale=1.0" name="viewport"/><title>My Page</title><link href="/static/style.css" rel="stylesheet"/><script src="/static/app.js"></script></head>

<body><h1>Welcome!</h1><p>This is my page.</p></body>
</html>
```

### Full Control with document_generator

For complete control over the `<head>` section:

```python
from html_compose import document_generator, generate_head, title, meta, body, p
from html_compose.resource import js_import, css_import

doc = document_generator(
    lang="en",
    head=generate_head(
        title="My App",
        js=[js_import("./static/app.js", name="app", cache_bust=True)],
        css=[css_import("./static/style.css")]
    ),
    body=[
        p["Custom document structure"]
    ]
)
```

## Component Patterns

Components are just Python functions:

```python
from html_compose import div, h2, p, ul, li

def card(title, description, features):
    return div(class_="card")[
        h2[title],
        p[description],
        ul[
            li[feature] for feature in features
        ]
    ]

# Use it
my_card = card(
    "Product Name",
    "A great product",
    ["Fast", "Reliable", "Secure"]
)
```

With type hints:

```python
from html_compose import BaseElement

def card(title: str, description: str, features: list[str]) -> BaseElement:
    return div(class_="card")[
        h2[title],
        p[description],
        ul[
            li[feature] for feature in features
        ]
    ]
```

## Conditional Rendering

`None` children are silently ignored:

```python
from html_compose import div, p

show_message = False
element = div[
    p["Always visible"],
    p["Conditional"] if show_message else None
]
# <div><p>Always visible</p></div>
```

This makes conditional rendering clean:

```python
def user_profile(user, is_admin):
    return div[
        p[f"Welcome, {user.name}"],
        p["Admin controls"] if is_admin else None
    ]
```

## Lazy Evaluation with Callables

Children can be functions, evaluated at render time:

```python
from html_compose import div, p

element = div[
    p["Static content"],
    lambda: f"Generated at {datetime.now()}"
]
```

The lambda runs when you call `.render()`, not when you build the element.

Access the parent element:

```python
element = div(id="parent")[
    lambda parent: f"My parent ID is {parent.attrs.get('id')}"
]
# <div id="parent">My parent ID is parent</div>
```

This is powerful for deferred database queries:

```python
def article_view(article_id):
    return div[
        h1["Article"],
        p(id=article_id)[
            lambda el: database.get_content(el.attrs.get("id"))
        ]
    ]
```

The database query happens at render time, not construction time.

## Rendering to Strings

### Single Element

```python
from html_compose import div

element = div["content"]
html = element.render()
# "<div>content</div>"
```

### Multiple Elements (Lists)

```python
from html_compose import render, li

items = [li[x] for x in range(3)]
html = render(items)
# "<li>0</li><li>1</li><li>2</li>"
```

### Streaming for Large Documents

For large pages, stream chunks instead of building the entire string:

```python
from html_compose import stream

for chunk in stream(large_element):
    response.write(chunk)
```

This reduces memory usage for big documents.

## Advanced: Resource Management

For production apps, you need cache busting, preloading, and subresource integrity.

### JavaScript Imports

```python
from html_compose.resource import js_import

# Local module with cache busting
app_js = js_import(
    "./static/app.js",
    name="app",
    cache_bust=True,
    preload=True
)

# CDN library with integrity check
alpine = js_import(
    "https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js",
    defer=True,
    hash="sha384-abcd1234...",
    crossorigin="anonymous"
)
```

Use these in `HTML5Document`:

```python
doc = HTML5Document(
    "My App",
    js=[app_js, alpine],
    body=[...]
)
```

### CSS Imports

```python
from html_compose.resource import css_import

style = css_import("./static/style.css", preload=True)
bootstrap = css_import(
    "https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css",
    hash="sha384-xyz789...",
    crossorigin="anonymous"
)
```

### Font Imports

Manual font files:

```python
from html_compose.resource import font_import_manual

custom_font = font_import_manual(
    "./static/fonts/CustomFont.woff2",
    family="CustomFont",
    weight="400",
    style="normal"
)
```

Font providers (Google Fonts, etc.):

```python
from html_compose.resource import font_import_provider

google_font = font_import_provider(
    href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap",
    preconnect=["https://fonts.googleapis.com", "https://fonts.gstatic.com"]
)
```

## Advanced: Custom Elements

Create elements not in the HTML spec:

```python
from html_compose import create_element

# Define custom element type
my_widget = create_element("my-widget")

# Use it
widget = my_widget(data_id="123")["Content"]
print(widget.render())
# <my-widget data_id="123">Content</my-widget>
```

Or use the class directly:

```python
from html_compose import CustomElement

my_component = CustomElement.create("my-component")
element = my_component(class_="special")["Hello"]
# <my-component class="special">Hello</my-component>
```

## Advanced: Framework Integration (HTMX, Alpine.js)

Create reusable attribute helpers:

```python
from html_compose.attributes import BaseAttribute
from html_compose import button, div

class htmx:
    @staticmethod
    def get(url: str) -> BaseAttribute:
        return BaseAttribute("hx-get", url)

    @staticmethod
    def target(selector: str) -> BaseAttribute:
        return BaseAttribute("hx-target", selector)

    @staticmethod
    def swap(strategy: str) -> BaseAttribute:
        return BaseAttribute("hx-swap", strategy)

# Use them
load_button = button([
    htmx.get("/api/data"),
    htmx.target("#result"),
    htmx.swap("innerHTML")
])["Load More"]

# <button hx-get="/api/data" hx-target="#result" hx-swap="innerHTML">Load More</button>
```

For Alpine.js:

```python
class alpine:
    @staticmethod
    def data(value: str) -> BaseAttribute:
        return BaseAttribute("x-data", value)

    @staticmethod
    def on(event: str, handler: str) -> BaseAttribute:
        return BaseAttribute(f"@{event}", handler)

counter = div([
    alpine.data("{ count: 0 }"),
    alpine.on("click", "count++")
])[
    button["Increment"],
    p[lambda: "Count: ", "x-text='count'"]
]
```

## Live Reload Development Server

Run your web app with automatic browser refresh:

**Install dependencies:**
```bash
pip install html-compose[live-reload]
```

**Create `livereload.py`:**
```python
import html_compose.live as live

live.server(
    daemon=live.ShellCommand("flask --app ./server.py run"),
    daemon_delay=1,
    conds=[
        # Restart server on Python changes
        live.WatchCond(path_glob="**/*.py", action=None),

        # Compile Sass, don't reload
        live.WatchCond(
            path_glob="./static/sass/**/*.scss",
            action=live.ShellCommand("sass --update static/sass:static/css"),
            reload=False
        ),

        # Reload on CSS changes
        live.WatchCond(path_glob="./static/css/**/*.css", action=None),
    ],
    host="localhost",
    port=51353
)
```

**Run it:**
```bash
python livereload.py
```

Now edit Python files, templates, or styles and see instant browser updates.

**How it works:**
- Watches files matching your globs
- Runs actions when files change (like compiling Sass)
- Injects livereload.js into your pages
- Tells the browser to refresh via WebSocket

## CLI Tool: Convert HTML to Python

Convert existing HTML templates to html-compose code:

```bash
# From file
html-compose convert template.html

# From stdin
echo '<div class="test">Hello</div>' | html-compose convert
```

Example input:
```html
<div class="container">
  <h1>Welcome</h1>
  <p>Hello, world!</p>
</div>
```

Example output:
```python
from html_compose import div, h1, p

div(class_="container")[
    h1["Welcome"],
    p["Hello, world!"]
]
```

Use namespaced imports:
```bash
html-compose convert --noimport el
```

Produces:
```python
el.div(class_="container")[
    el.h1["Welcome"],
    el.p["Hello, world!"]
]
```

## Common Patterns

### Navigation Menu

```python
from html_compose import nav, ul, li, a

def nav_menu(items):
    return nav[
        ul[
            li[
                a(href=item["url"])[item["name"]]
            ]
            for item in items
        ]
    ]

menu = nav_menu([
    {"name": "Home", "url": "/"},
    {"name": "About", "url": "/about"},
    {"name": "Contact", "url": "/contact"}
])
```

### Form with Validation Classes

```python
from html_compose import form, label, input, button

def login_form(errors=None):
    errors = errors or {}

    return form(method="post", action="/login")[
        label["Email"],
        input(
            type="email",
            name="email",
            class_={
                "input": True,
                "error": "email" in errors
            }
        ),

        label["Password"],
        input(
            type="password",
            name="password",
            class_={
                "input": True,
                "error": "password" in errors
            }
        ),

        button(type="submit")["Log In"]
    ]
```

### Table from Data

```python
from html_compose import table, thead, tbody, tr, th, td

def data_table(headers, rows):
    return table[
        thead[
            tr[
                th[header] for header in headers
            ]
        ],
        tbody[
            tr[
                td[cell] for cell in row
            ]
            for row in rows
        ]
    ]

users_table = data_table(
    ["Name", "Email", "Role"],
    [
        ["Alice", "alice@example.com", "Admin"],
        ["Bob", "bob@example.com", "User"]
    ]
)
```

### Layout Components

```python
from html_compose import div, header, main, footer

def page_layout(title, content):
    return div(class_="page")[
        header(class_="header")[
            h1[title]
        ],
        main(class_="main")[
            content
        ],
        footer(class_="footer")[
            p["© 2024 My Company"]
        ]
    ]

page = page_layout(
    "Dashboard",
    div[
        p["Welcome to your dashboard"],
        # ... more content
    ]
)
```

## Common Pitfalls

### Forgetting to Call render()

```python
# Wrong - this is an object
from html_compose import div
element = div["content"]
print(element)  # <html_compose.elements.div object at 0x...>

# Right
print(element.render())  # <div>content</div>
```

### Mutating Elements After Creation

Elements are mutable, but this can cause surprising behavior:

```python
# Be careful
base = div(class_="card")
card1 = base["Card 1"]
card2 = base["Card 2"]  # This ALSO modifies base!

# Both cards now contain both texts
```

Instead, create fresh elements:

```python
def card(content):
    return div(class_="card")[content]

card1 = card("Card 1")
card2 = card("Card 2")
```

### Using class Instead of class_

```python
# Wrong - syntax error
div(class="container")

# Right
div(class_="container")
```

### Forgetting to Escape User Input with unsafe_text

```python
# Safe by default
user_input = "<script>bad()</script>"
div[user_input]  # Automatically escaped

# Unsafe - only use with trusted content
trusted = "<b>Safe HTML</b>"
div[unsafe_text(trusted)]  # Not escaped
```

## Import Patterns

### Individual Elements

```python
from html_compose import div, p, span, a, button
```

### All Elements (Use Sparingly)

```python
from html_compose.elements import *
```

### Namespaced (Recommended for Large Projects)

```python
import html_compose.elements as el

page = el.div(class_="container")[
    el.h1["Title"],
    el.p["Content"]
]
```

### Core Utilities

```python
from html_compose import (
    render,              # Render element(s) to string
    stream,              # Stream element(s) as chunks
    unsafe_text,         # Mark HTML as trusted (dangerous)
    escape_text,         # Manually escape text
    pretty_print,        # Format HTML (development only)
    create_element,      # Create custom elements
    HTML5Document,       # Quick document builder
    document_generator,  # Full document control
)
```

## Quick Reference

### Element Syntax

```python
# Attributes only
div(id="main", class_="container")

# Children only
div["content"]

# Both
div(id="main")["content"]

# Multiple children
div[child1, child2, child3]

# Nested
div[p["paragraph"], ul[li["item"]]]
```

### Attribute Types

```python
# String
div(id="main")

# Integer
div(tabindex=1)

# Boolean
button(disabled=True)

# List (for class)
div(class_=["flex", "items-center"])

# Dictionary (for class and style)
div(class_={"active": True, "hidden": False})
div(style={"color": "red", "background": "blue"})

# Custom attributes
div({"data-id": "123", "@click": "handler()"})
```

### Rendering

```python
# Single element
element.render()

# Multiple elements
from html_compose import render
render([el1, el2, el3])

# Streaming
from html_compose import stream
for chunk in stream(element):
    # process chunk
    pass
```

### Components

```python
# Simple function
def greeting(name):
    return p[f"Hello, {name}!"]

# With types
from html_compose import BaseElement

def card(title: str, content: str) -> BaseElement:
    return div(class_="card")[
        h2[title],
        p[content]
    ]
```

## What's Next?

You now understand the fundamentals of html-compose:

1. `()` for attributes, `[]` for children
2. Automatic XSS protection
3. Components are functions
4. Type-safe attributes with hints
5. Document generation with HTML5Document
6. Live reload for development

For more advanced usage:
- Read the API documentation
- Explore the test suite in `tests/`
- Check out the examples in the repository
- Join the community discussions

Build something great!
