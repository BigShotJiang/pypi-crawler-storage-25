"""Demonstration gallery module for html-compose.

Run `html-compose gallery -m gallerydemo` to explore the showcases.
"""

from typing import NamedTuple

from html_compose import button, div, form, h2, label, li, p, section, span, ul
from html_compose import input as input_el
from html_compose.gallery import declare_environment, showcase
from html_compose.gallery.server import Settings as ServerSettings

ServerSettings.set_static_dir(".")


class TodoListData(NamedTuple):
    """Fixture data for the todo list showcase."""

    title: str
    items: list[str]


class ContactFormData(NamedTuple):
    """Fixture data for the contact form showcase."""

    heading: str
    description: str
    fields: list[tuple[str, str]]  # (label, placeholder)


declare_environment(
    "ibro",
    css=[
        "https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.classless.min.css"
    ],
    js=[],
    fonts=[],
    isolation="iframe",
)


declare_environment(
    "default",
    css=[
        "https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.classless.min.css"
    ],
    js=[],
    fonts=[],
    isolation="shadow-dom",
)

declare_environment("minimal", css=[], js=[], fonts=[], isolation="shadow-dom")


@showcase(
    TodoListData(
        title="Errands for brother",
        items=[
            "Pick up dry cleaning",
            "Restock pantry essentials",
            "Plan hiking trip",
            "Call the bike shop",
        ],
    ),
    name="todo list",
    category="lists",
)
def todo_list(data: TodoListData):
    """Render an unordered list of tasks."""

    list_items = [
        li(class_="todo-item")[
            span(class_="bullet")["•"], span()[item], button()["demo"]
        ]
        for item in data.items
    ]

    return section(class_="todo-demo")[
        h2()[data.title], ul(class_="todo-items")[list_items]
    ]


_ = ContactFormData(
    heading="Cheese in the loop",
    description="Leave your details and we'll send occasional updates.",
    fields=[
        ("Name", "Ada Lovelace"),
        ("Email", "ada@example.com"),
        ("Favorite language", "Python"),
    ],
)


@showcase(_, category="forms", env="ibro")
@showcase(
    kwargs={"data": _},
    name="contact form (minimal)",
    category="forms",
    env="default",
)
def contact_form(data: ContactFormData):
    """Render a simple contact form with labeled inputs."""
    field_blocks = [
        div(class_="field")[
            label()[field_label],
            input_el(
                type="text",
                name=field_label.lower().replace(" ", "-"),
                placeholder=placeholder,
            ),
        ]
        for field_label, placeholder in data.fields
    ]

    return section(class_="contact-form-demo")[
        h2()[data.heading],
        p(class_="lead")[data.description],
        form(method="post", class_="contact-form")[
            div(class_="fields")[field_blocks],
            button(type="submit", class_="primary")["Send"],
        ],
    ]


# @showcase(category="errors", name="broken showcase")
# def stinker():
#     return "<h1>Stinker</h1>"


# stinker = lambda: "<h1>Stinker</h1>"  # type: ignore
# showcase(stinker, name="broken showcase", category="errors")
