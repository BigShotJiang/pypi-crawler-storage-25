# Getting Started with html-compose

## The Problem with Templates

When you build web applications in Python, you face a fundamental split: your logic lives in Python, but your structure lives in HTML templates.

```python
# Your Python code
users = db.query(User).all()
show_admin = current_user.is_admin

# Your template (separate file, different syntax)
{% for user in users %}
  <li>{{ user.name }}</li>
{% endfor %}
{% if show_admin %}
  <button>Admin Panel</button>
{% endif %}
```

This works. But composition becomes awkward. You cannot easily:
- Return a chunk of HTML from a function
- Build UI components that accept other components
- Use Python's full expressiveness (list comprehensions, pattern matching, decorators)

The naive fix—string concatenation—invites disaster:

```python
# Never do this
html = "<div>" + user_input + "</div>"  # XSS vulnerability
```

## The Core Idea

html-compose treats HTML elements as Python objects. Two operators do everything:

- `()` sets attributes
- `[]` adds children

```python
from html_compose import div, p, a, strong

# Element with children
div()["Hello world"]
# <div>Hello world</div>

# Element with attributes and children
a(href="/logout")["Log out"]
# <a href="/logout">Log out</a>

# Nesting
div(class_="container")[
    p["Welcome, ", strong["user"], "!"],
    a(href="/logout")["Log out"]
]
```

That is the entire mental model. Everything else is detail.

## Installation

```bash
pip install html-compose
```

Requires Python 3.10+.

## Your First Element

Import what you need, build what you want:

```python
from html_compose import div, p, h1

# Create an element
heading = h1()["My Page"]

# Render to string
html = heading.render()
print(html)  # <h1>My Page</h1>
```

When an element has no attributes, skip the constructor:

```python
h1["My Page"]       # same as h1()["My Page"]
p["Some text"]      # same as p()["Some text"]
```

This shorthand exists because text elements rarely need attributes.

## Setting Attributes

Keyword arguments are the cleanest approach:

```python
from html_compose import div, a, img

div(id="main", class_="container")
a(href="/about", target="_blank")["About"]
img(src="/logo.png", alt="Company logo")
```

**Why `class_` instead of `class`?** Because `class` is a Python keyword. The trailing underscore is the convention. Same applies to `del_` for the `<del>` element.

### Other Ways to Set Attributes

For custom attributes (data-*, framework-specific, etc.), use a dictionary:

```python
# Custom data attributes
div({"data-user-id": "123", "@click": "handler()"})

# The dict can be the first positional argument
div({"hx-get": "/api/data"}, class_="btn")
```

For maximum type safety, use the hint system:

```python
# Every element has a .hint class with typed methods
a(attrs=[a.hint.href("/path"), a.hint.target("_blank")])

# Shorthand: ._ is an alias for .hint
img(attrs=[img._.src("/img.png"), img._.alt("description")])
```

You rarely need the hint system. It exists for when IDE autocomplete matters more than brevity.

## Adding Children

The `[]` operator accepts almost anything:

```python
from html_compose import ul, li, div, p

# Strings
div()["Hello"]

# Other elements
div()[p["Nested paragraph"]]

# Multiple children (comma-separated)
div()["Text", p["More"], "End"]

# Lists (automatically flattened)
items = ["Apple", "Banana", "Cherry"]
ul()[
    [li[item] for item in items]
]
```

### Conditional Children

`None` is ignored. This enables clean conditionals:

```python
show_admin = current_user.is_admin

div()[
    p["Welcome!"],
    button["Admin Panel"] if show_admin else None
]
```

No special template syntax. Just Python.

### Dynamic Children

Callables are evaluated at render time:

```python
import time

div()[
    lambda: f"Rendered at {time.time()}"
]
```

This matters for streaming responses where you want lazy evaluation.

## Security: Automatic Escaping

All text content is HTML-escaped by default:

```python
from html_compose import div

user_input = "<script>alert('xss')</script>"
div()[user_input]
# <div>&lt;script&gt;alert('xss')&lt;/script&gt;</div>
```

You cannot accidentally create XSS vulnerabilities.

When you genuinely need raw HTML (trusted content only):

```python
from html_compose import div, unsafe_text

trusted_html = "<strong>Bold</strong>"
div()[unsafe_text(trusted_html)]
# <div><strong>Bold</strong></div>
```

The function name is intentional. If you see `unsafe_text` in your code, you should pause and verify the content is actually safe.

## The class_ Attribute

CSS classes are used constantly, so `class_` accepts multiple formats:

```python
from html_compose import div

# String
div(class_="flex items-center")

# List (joined with spaces)
div(class_=["flex", "items-center", "gap-4"])

# Dict (keys included when values are truthy)
is_active = True
is_hidden = False
div(class_={
    "btn": True,
    "btn-active": is_active,
    "hidden": is_hidden
})
# <div class="btn btn-active"></div>
```

The dict form is powerful for conditional classes without string manipulation.

## The style Attribute

Similar flexibility:

```python
div(style={"color": "red", "font-size": "16px"})
# <div style="color: red; font-size: 16px"></div>
```

## Rendering

Single element:

```python
element = div()["Content"]
html = element.render()
```

Multiple elements:

```python
from html_compose import render, p

elements = [p[x] for x in ["One", "Two", "Three"]]
html = render(elements)
# <p>One</p><p>Two</p><p>Three</p>
```

Streaming (for large responses):

```python
from html_compose import stream

for chunk in stream(elements):
    response.write(chunk)
```

## Complete Documents

For full HTML5 documents with proper doctype, head, and body:

```python
from html_compose import HTML5Document, p, h1

doc = HTML5Document(
    title="My Page",
    lang="en",
    css=["/static/style.css"],
    js=["/static/app.js"],
    body=[
        h1["Welcome"],
        p["Content goes here"]
    ]
)

html = str(doc)
```

This generates proper `<!DOCTYPE html>`, viewport meta tags, and correctly ordered resource tags.

## Import Patterns

Choose what fits your style:

```python
# Individual imports (cleanest for small projects)
from html_compose import div, p, a, ul, li

# Namespaced (avoids conflicts, clear provenance)
import html_compose.elements as el
el.div()[el.p["text"]]

# Alias (compact)
import html_compose as h
h.div()[h.p["text"]]
```

## Custom Elements

For web components or non-standard tags:

```python
from html_compose import create_element

# Create a custom element factory
my_widget = create_element("my-widget")

# Use it like any other element
my_widget(data_config="...")["Widget content"]
# <my-widget data-config="...">Widget content</my-widget>
```

## Building Reusable Components

Since elements are Python objects, composition is natural:

```python
from html_compose import div, h2, p

def card(title: str, content):
    """A reusable card component."""
    return div(class_="card")[
        h2(class_="card-title")[title],
        div(class_="card-body")[content]
    ]

# Use it
page = div()[
    card("Welcome", p["Hello!"]),
    card("News", p["Latest updates..."])
]
```

No special component system. Functions that return elements.

## Converting Existing HTML

The CLI tool converts HTML to html-compose syntax:

```bash
# From CLI: Paste and hit enter + ctrl + D
html-compose convert

# From file
html-compose convert template.html

# From stdin
echo '<div class="foo"><p>Hi</p></div>' | html-compose convert
# Output: div(class_="foo")[p["Hi"]]
```

Useful when migrating from templates or adapting HTML snippets.

## What Happens Automatically

The library handles several things without explicit action:

1. **Text escaping** — All strings are HTML-escaped
2. **None filtering** — `None` children are silently ignored
3. **List flattening** — Nested lists become flat children
4. **Float rounding** — Floats render with 3 decimal places
5. **Class merging** — Multiple `class_` sources concatenate correctly
6. **Style merging** — Multiple `style` sources concatenate with semicolons

## Next Steps

You now know enough to build real applications. The remaining features are conveniences:

- **Resource imports** (`js_import`, `css_import`) — manage preloading, cache busting, and import maps
- **Live reload server** — automatic browser refresh during development
- **Type hints** — every attribute from the WhatWG spec has typed parameters

These are documented in the module docstrings. Access them with:

```python
import html_compose
help(html_compose)
```

Or read the source. It is designed to be readable.
