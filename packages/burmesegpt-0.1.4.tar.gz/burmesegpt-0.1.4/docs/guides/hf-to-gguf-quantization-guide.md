# From Hugging Face to GGUF: A Practical Quantization Guide (Padauk Example)

This guide shows a production-style workflow to convert a Hugging Face model into GGUF, quantize it, validate it, and publish it for local inference.

It is written from a real Padauk (`WYNN747`) workflow and includes fixes for the common errors people hit in practice.

## Who This Is For

- You have a model on Hugging Face and want to run it with `llama.cpp`
- You want quantized artifacts (`Q8_0`, `Q5_K_M`, `Q4_K_M`)
- You want a repeatable process before sharing GGUF files publicly

## 1) Prerequisites

- macOS/Linux terminal
- Enough disk space (at least 30 GB free recommended for conversion + quantization)
- Python environment
- `llama.cpp` (latest source build is recommended for new architectures like Gemma4 variants)

### Install tools

```bash
mkdir -p ~/padauk-rebuild && cd ~/padauk-rebuild
git clone --depth 1 https://github.com/ggml-org/llama.cpp.git

python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -r ./llama.cpp/requirements/requirements-convert_hf_to_gguf.txt
python -m pip install -U "huggingface_hub[cli]" safetensors transformers
```

Build latest binaries:

```bash
cd ~/padauk-rebuild/llama.cpp
cmake -B build -DGGML_METAL=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build -j 8
```

Use these binaries for consistency:

- `~/padauk-rebuild/llama.cpp/build/bin/llama-cli`
- `~/padauk-rebuild/llama.cpp/build/bin/llama-server`
- `~/padauk-rebuild/llama.cpp/build/bin/llama-quantize`

## 2) Download Source Weights (Not GGUF)

You should convert from source checkpoint files (`.safetensors`) rather than re-quantizing a previously broken GGUF.

```bash
cd ~/padauk-rebuild
source .venv/bin/activate
hf download WYNN747/Burmese-GPT-Padauk --local-dir ./hf-src --exclude "*.gguf"
```

If your repo is private or gated, set token:

```bash
export HF_TOKEN=hf_xxx
```

## 3) Convert HF Model to GGUF

### Recommended: direct convert to target outtype

Direct convert often avoids an extra large intermediate quantization pass.

```bash
python ./llama.cpp/convert_hf_to_gguf.py ./hf-src --outfile ./padauk-gemma-q8_0.gguf --outtype q8_0
```

### Optional: create F16 master first

```bash
python ./llama.cpp/convert_hf_to_gguf.py ./hf-src --outfile ./padauk-f16.gguf --outtype f16
```

Then quantize from the F16 master:

```bash
./llama.cpp/build/bin/llama-quantize ./padauk-f16.gguf ./padauk-gemma-q8_0.gguf Q8_0
./llama.cpp/build/bin/llama-quantize ./padauk-f16.gguf ./padauk-gemma-q5_k_m.gguf Q5_K_M
./llama.cpp/build/bin/llama-quantize ./padauk-f16.gguf ./padauk-gemma-q4_k_m.gguf Q4_K_M
```

## 4) Validate the GGUF Before Upload

Release gate before upload:

1. Checksum sync check: write `SHA256SUMS.txt` for the GGUF files you plan to publish, confirm the entries match final artifact names, and sync any pinned hashes used by the package release.
2. GGUF magic check: confirm the file header is `GGUF`.
3. Runtime load check: run `llama-cli` against the artifact locally before release.
4. Conditional validation: if `burmesegpt validate` exists in this codebase, run it locally as well. If it does not exist, keep using the manual checks below.

### A. Confirm GGUF magic header

```bash
python3 - <<'PY'
from pathlib import Path
p = Path("./padauk-gemma-q8_0.gguf")
print("size:", p.stat().st_size)
print("magic:", p.open("rb").read(4))
PY
```

Expected magic:

- `b'GGUF'`

If you see `b'\x00\x00\x00\x00'` or invalid magic, the file is incomplete/corrupted.

### B. Quick load test (CPU-only for stability)

```bash
./llama.cpp/build/bin/llama-cli -m ./padauk-gemma-q8_0.gguf -ngl 0 -c 256 -b 64 -p "hello" -n 16
```

If this runs and produces output, artifact is valid.

## 5) Publish Artifacts to Hugging Face

Generate checksums:

```bash
shasum -a 256 padauk-gemma-q8_0.gguf padauk-gemma-q5_k_m.gguf padauk-gemma-q4_k_m.gguf > SHA256SUMS.txt
```

Upload to model repo (web UI or CLI), then confirm public URLs are reachable.

## 6) Test with `burmesegpt`

```bash
burmesegpt download --quant q8_0
burmesegpt serve --quant q8_0 --host 127.0.0.1 --port 8000
```

Check endpoint:

```bash
curl http://127.0.0.1:8000/v1/models
```

## 7) Troubleshooting (Real-World)

### `401 Unauthorized` from Hugging Face

Cause:
- Repo is private/gated, or token is invalid

Fix:
- Make repo truly public, or
- use valid `HF_TOKEN`

### `invalid magic characters: '????', expected 'GGUF'`

Cause:
- Output file is partial/corrupt (conversion/quantization got killed)

Fix:
- Delete broken file and regenerate
- ensure enough free disk/memory

### `zsh: killed` during `llama-quantize`

Cause:
- OS killed process due memory pressure or disk pressure

Fix:
- Free disk (target > 30 GB free)
- close heavy apps
- retry with latest local `llama.cpp/build/bin/llama-quantize`

### `missing tensor 'blk.xx.attn_k.weight'`

Possible causes:
- Runtime too old for model architecture details
- Broken conversion pipeline/bad source files

Fix:
- Use latest `llama.cpp` source build for conversion and inference
- verify source checkpoint integrity
- validate with `llama-cli` before upload

### `zsh: command not found: #`

Cause:
- A comment line (`# ...`) was pasted into shell as a command

Fix:
- Re-run only actual commands (without comment lines)

### Metal / GPU out-of-memory during inference

Fix:
- Run CPU-only first: `-ngl 0`
- Reduce context and batch: `-c 256 -b 64`

## 8) Final Release Gate (Required)

Before upload or release, re-run this short gate and stop on failure:

1. `SHA256SUMS.txt` is synced to final GGUF filenames and any pinned package hashes.
2. GGUF header check returns `GGUF`.
3. `llama-cli` local load check passes.
4. If available, `burmesegpt validate` passes locally.
5. Re-download one uploaded GGUF and repeat header + load checks.
