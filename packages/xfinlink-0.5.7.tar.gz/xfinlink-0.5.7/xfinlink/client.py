"""HTTP client for the xfinlink API.

    import xfinlink as xfl
    df = xfl.prices("AAPL", start="2024-01-01", end="2024-12-31")
    df = xfl.fundamentals("AAPL", period_type="annual")
"""
from __future__ import annotations

import os
from datetime import date, timedelta

import warnings

import httpx

try:
    import pandas as pd
except ImportError:
    raise ImportError(
        "xfinlink: pandas is required but not installed. "
        "Fix: run 'pip install pandas' in your terminal."
    )

API_BASE = "https://api.xfinlink.com"
_TIMEOUT = 30.0
_API_KEY: str | None = None
_MAX_PAGES = 50


def set_api_base(url: str) -> None:
    """Override the API base URL. Useful for local testing."""
    global API_BASE
    API_BASE = url.rstrip("/")


def set_api_key(key: str) -> None:
    """Set the API key for all subsequent requests."""
    global _API_KEY
    _API_KEY = key


def _get_api_key() -> str | None:
    """Return the API key from set_api_key() or XFINLINK_API_KEY env var."""
    return _API_KEY or os.environ.get("XFINLINK_API_KEY") or os.environ.get("XFL_API_KEY")


def _default_start() -> str:
    """Return a date string 1 year ago from today."""
    return (date.today() - timedelta(days=365)).isoformat()


def _validate_ticker(ticker: str | list[str], func_name: str) -> str:
    """Validate ticker input and return a comma-separated string."""
    if not isinstance(ticker, str):
        if isinstance(ticker, (list, tuple)):
            joined = ",".join(str(t) for t in ticker)
            raise ValueError(
                f"xfinlink: ticker must be a comma-separated string, not "
                f"{type(ticker).__name__}. "
                f"Fix: xfl.{func_name}('{joined}')"
            )
        raise ValueError(
            f"xfinlink: ticker must be a string, not "
            f"{type(ticker).__name__}. Fix: xfl.{func_name}('AAPL')"
        )
    if ", " in ticker:
        ticker = ticker.replace(", ", ",")
    return ticker


def _validate_dates(start: str | None, end: str | None) -> None:
    """Validate date format parameters."""
    for param_name, param_val in [("start", start), ("end", end)]:
        if param_val is not None:
            if not isinstance(param_val, str):
                raise ValueError(
                    f"xfinlink: {param_name} must be a string in YYYY-MM-DD "
                    f"format, not {type(param_val).__name__}. "
                    f"Fix: {param_name}='{param_val}'"
                )
            if len(param_val) != 10 or param_val[4] != "-" or param_val[7] != "-":
                raise ValueError(
                    f"xfinlink: {param_name}='{param_val}' is not valid. "
                    f"Fix: use YYYY-MM-DD format, e.g. {param_name}='2025-01-01'"
                )


def _warn_empty(ticker: str, start: str | None, end: str | None) -> None:
    """Emit a warning when no data is returned."""
    msg = f"xfinlink: No data returned for '{ticker}'"
    if start or end:
        msg += f" in range {start or '...'} to {end or '...'}"
    msg += ". Fix: check ticker spelling with xfl.search(q='...'), or widen the date range."
    warnings.warn(msg, UserWarning, stacklevel=3)


def _extract_ticker(resp: httpx.Response) -> str:
    """Try to extract the ticker from the request URL path."""
    try:
        path = resp.request.url.path
        # /v1/prices/AAPL or /v1/fundamentals/AAPL,MSFT
        parts = path.strip("/").split("/")
        if len(parts) >= 3:
            return parts[2]
    except Exception:
        pass
    return "unknown"


def _handle_error(resp: httpx.Response) -> None:
    """Raise LLM-parseable errors for non-2xx responses."""
    if resp.status_code in (401, 403):
        raise ValueError(
            "xfinlink: API key invalid or missing. "
            "Fix: call xfl.set_api_key('your_key') or set "
            "os.environ['XFINLINK_API_KEY'] before importing. "
            "Get a free key at https://xfinlink.com/signup"
        )
    if resp.status_code == 429:
        try:
            body = resp.json()
        except Exception:
            raise ValueError(
                "xfinlink: Rate limit reached. "
                "Fix: wait a few minutes, or reduce request volume "
                "with date filters."
            )
        retry = body.get("retry_after_seconds", "?")
        error_msg = body.get("error", "")
        raise ValueError(
            f"xfinlink: Rate limit reached ({error_msg}). "
            f"Fix: wait {retry}s, or reduce requests by adding "
            "start/end date filters and using max_rows parameter."
        )
    if resp.status_code == 404:
        ticker = _extract_ticker(resp)
        raise ValueError(
            f"xfinlink: Ticker '{ticker}' not found. "
            f"Fix: check spelling, or use xfl.search(q='{ticker}') "
            "to find the correct symbol."
        )
    if 400 <= resp.status_code < 500:
        try:
            body = resp.json()
            detail = body.get("error", body.get("detail", "unknown"))
        except Exception:
            detail = resp.text
        raise ValueError(
            f"xfinlink: API error ({resp.status_code}): {detail}. "
            "Fix: check your parameters and try again."
        )
    if resp.status_code >= 500:
        raise ValueError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )


def _request(endpoint: str, params: dict, max_rows: int | None = None) -> dict:
    """GET with automatic cursor-based pagination."""
    from xfinlink import __version__

    headers: dict[str, str] = {"User-Agent": f"xfinlink-python/{__version__}"}
    key = _get_api_key()
    if key:
        headers["X-API-Key"] = key
    all_data: list = []
    meta: dict = {}
    pages = 0

    while True:
        try:
            resp = httpx.get(
                f"{API_BASE}/v1/{endpoint}",
                params=params,
                headers=headers,
                timeout=_TIMEOUT,
            )
        except httpx.TimeoutException:
            raise ValueError(
                "xfinlink: Request timed out after 30s. "
                "Fix: narrow your query with start/end dates or fewer tickers."
            )
        except httpx.ConnectError:
            raise ValueError(
                "xfinlink: Cannot connect to api.xfinlink.com. "
                "Fix: check your internet connection."
            )
        _handle_error(resp)

        body = resp.json()
        all_data.extend(body["data"])
        meta = body.get("meta", {})
        pages += 1

        if max_rows is not None and len(all_data) >= max_rows:
            all_data = all_data[:max_rows]
            break

        if not meta.get("has_more") or not meta.get("next_cursor"):
            break

        if pages >= _MAX_PAGES:
            break

        params = dict(params)
        params["cursor"] = meta["next_cursor"]

    meta["count"] = len(all_data)
    meta["has_more"] = False
    meta["next_cursor"] = None
    return {"data": all_data, "meta": meta}


def _request_single(endpoint: str, params: dict) -> dict:
    """GET without pagination (for endpoints that don't paginate)."""
    from xfinlink import __version__

    headers: dict[str, str] = {"User-Agent": f"xfinlink-python/{__version__}"}
    key = _get_api_key()
    if key:
        headers["X-API-Key"] = key
    try:
        resp = httpx.get(
            f"{API_BASE}/v1/{endpoint}",
            params=params,
            headers=headers,
            timeout=_TIMEOUT,
        )
    except httpx.TimeoutException:
        raise ValueError(
            "xfinlink: Request timed out after 30s. "
            "Fix: narrow your query with start/end dates or fewer tickers."
        )
    except httpx.ConnectError:
        raise ValueError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    _handle_error(resp)
    return resp.json()


def status() -> dict:
    """Check API health. Returns dict with status, version, and table counts."""
    from xfinlink import __version__

    try:
        resp = httpx.get(
            f"{API_BASE}/v1/status",
            headers={"User-Agent": f"xfinlink-python/{__version__}"},
            timeout=_TIMEOUT,
        )
    except httpx.TimeoutException:
        raise ValueError(
            "xfinlink: Request timed out after 30s. "
            "Fix: try again in a few seconds."
        )
    except httpx.ConnectError:
        raise ValueError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    if resp.status_code >= 400:
        raise ValueError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )
    return resp.json()


def usage() -> dict:
    """Check current API usage and rate limits."""
    from xfinlink import __version__

    key = _get_api_key()
    if not key:
        raise ValueError(
            "xfinlink: No API key set. "
            "Fix: call xfl.set_api_key('your_key') or set "
            "os.environ['XFINLINK_API_KEY'] before importing. "
            "Get a free key at https://xfinlink.com/signup"
        )
    try:
        resp = httpx.get(
            f"{API_BASE}/v1/auth/usage",
            headers={
                "User-Agent": f"xfinlink-python/{__version__}",
                "X-API-Key": key,
            },
            timeout=_TIMEOUT,
        )
    except httpx.TimeoutException:
        raise ValueError(
            "xfinlink: Request timed out after 30s. "
            "Fix: try again in a few seconds."
        )
    except httpx.ConnectError:
        raise ValueError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    if resp.status_code in (401, 403):
        raise ValueError(
            "xfinlink: API key invalid or missing. "
            "Fix: call xfl.set_api_key('your_key') or set "
            "os.environ['XFINLINK_API_KEY'] before importing. "
            "Get a free key at https://xfinlink.com/signup"
        )
    if resp.status_code != 200:
        raise ValueError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )
    return resp.json()


def prices(
    ticker: str | list[str],
    start: str | None = None,
    end: str | None = None,
    fields: list[str] | str | None = None,
    adjust: str = "split",
    limit: int = 5000,
    max_rows: int = 10000,
) -> pd.DataFrame:
    """Get historical price data.

    Args:
        ticker: Single ticker ("AAPL") or list (["AAPL", "MSFT"]).
        start: Start date (YYYY-MM-DD). Defaults to 1 year ago.
        end: End date (YYYY-MM-DD).
        fields: Specific fields to return (default: all).
        adjust: "split" (default) or "none".
        limit: Rows per API page (default/max: 5000).
        max_rows: Maximum total rows to return (default: 10000).

    Returns:
        DataFrame with date, open, high, low, close, volume, etc.

    Examples:
        >>> df = xfl.prices("AAPL", start="2024-01-01", end="2024-12-31")
        >>> df = xfl.prices(["AAPL", "MSFT"], start="2024-01-01")
        >>> df = xfl.prices("GM", start="2008-01-01", end="2012-12-31")
    """
    ticker_str = _validate_ticker(ticker, "prices")
    _validate_dates(start, end)
    if isinstance(fields, str):
        fields = [fields]
    if start is None:
        start = _default_start()
    params: dict = {"limit": limit, "adjust": adjust, "start": start}
    if end:
        params["end"] = end
    if fields:
        params["fields"] = ",".join(fields)

    result = _request(f"prices/{ticker_str}", params, max_rows=max_rows)

    if not result["data"]:
        _warn_empty(ticker_str, start, end)
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["ticker", "date"]).reset_index(drop=True)
    return df


def fundamentals(
    ticker: str | list[str],
    start: str | None = None,
    end: str | None = None,
    period_type: str = "all",
    version: str = "restated",
    fields: list[str] | str | None = None,
    period_only: bool = False,
    limit: int = 5000,
    max_rows: int = 10000,
) -> pd.DataFrame:
    """Get financial statement data.

    Args:
        ticker: Single ticker ("AAPL") or list (["AAPL", "MSFT"]).
        start: Start date for period_end (YYYY-MM-DD). Defaults to 1 year ago.
        end: End date for period_end (YYYY-MM-DD).
        period_type: "quarterly", "annual", or "all" (default).
        version: "restated" (default), "original", or "all".
        fields: Specific fields. E.g. ["revenue", "net_income"].
        period_only: De-cumulate YTD cash flows to single-quarter values.
        limit: Rows per API page (default/max: 5000).
        max_rows: Maximum total rows to return (default: 10000).

    Returns:
        DataFrame with period_end, revenue, net_income, total_assets, etc.

    Examples:
        >>> df = xfl.fundamentals("AAPL", period_type="annual")
        >>> df = xfl.fundamentals("AAPL", fields=["revenue", "net_income"])
        >>> df = xfl.fundamentals(["AAPL", "MSFT"], period_type="annual", start="2020-01-01")
    """
    ticker_str = _validate_ticker(ticker, "fundamentals")
    _validate_dates(start, end)
    valid_periods = ("annual", "quarterly", "all")
    if period_type not in valid_periods:
        raise ValueError(
            f"xfinlink: period_type='{period_type}' is not valid. "
            f"Fix: use one of {valid_periods}"
        )
    if isinstance(fields, str):
        fields = [fields]
    if start is None:
        start = _default_start()
    params: dict = {"limit": limit, "period_type": period_type, "version": version, "start": start}
    if end:
        params["end"] = end
    if fields:
        params["fields"] = ",".join(fields)
    if period_only:
        params["period_only"] = "true"

    result = _request(f"fundamentals/{ticker_str}", params, max_rows=max_rows)

    if not result["data"]:
        _warn_empty(ticker_str, start, end)
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    if "period_end" in df.columns:
        df["period_end"] = pd.to_datetime(df["period_end"])
    if "filing_date" in df.columns:
        df["filing_date"] = pd.to_datetime(df["filing_date"])
    df = df.sort_values(["ticker", "period_end"]).reset_index(drop=True)
    return df


def resolve(
    ticker: str | list[str],
    include: list[str] | None = None,
) -> dict:
    """Get entity resolution and history for a ticker.

    Args:
        ticker: Single ticker ("GM") or list (["GM", "AAPL"]).
        include: Sections to include: ["events", "index", "classifications"].
                 Default: all sections.

    Returns:
        Dict with entity history, corporate events, index membership,
        and classifications grouped by ticker.

    Examples:
        >>> info = xfl.resolve("GM")
        >>> info["data"]["GM"]["entities"]
        >>> info = xfl.resolve("AAPL", include=["classifications"])
    """
    ticker_str = ",".join(ticker) if isinstance(ticker, list) else ticker
    params: dict = {}
    if include:
        params["include"] = ",".join(include)
    result = _request_single(f"resolve/{ticker_str}", params)
    if isinstance(ticker, str) and "," not in ticker:
        data = result.get("data", {})
        if ticker in data and not data[ticker].get("entities"):
            warnings.warn(
                f"xfinlink: Ticker '{ticker}' exists but has no entity data. "
                f"Fix: try xfl.search(q='{ticker}') to find related tickers.",
                UserWarning,
                stacklevel=2,
            )
    return result


def search(
    q: str | None = None,
    gics_sector: str | None = None,
    entity_type: str | None = None,
    sic: str | None = None,
    naics: str | None = None,
    country: str = "US",
    limit: int = 50,
    offset: int = 0,
) -> pd.DataFrame:
    """Search for entities by name, sector, type, etc."""
    params: dict = {}
    if q:
        params["q"] = q
    if gics_sector:
        params["gics_sector"] = gics_sector
    if entity_type:
        params["entity_type"] = entity_type
    if sic:
        params["sic"] = sic
    if naics:
        params["naics"] = naics
    if country:
        params["country"] = country
    params["limit"] = str(limit)
    params["offset"] = str(offset)
    result = _request("search", params)
    return pd.DataFrame(result["data"])


def index(
    index_name: str = "sp500",
    as_of: str | None = None,
    limit: int = 500,
    offset: int = 0,
) -> pd.DataFrame:
    """Get index constituents (current or historical)."""
    params: dict = {"limit": str(limit), "offset": str(offset)}
    if as_of:
        params["as_of"] = as_of
    result = _request(f"index/{index_name}", params)
    return pd.DataFrame(result["data"])


def metrics(
    ticker: str | list[str],
    period_type: str = "annual",
    fields: list[str] | str | None = None,
    start: str | None = None,
    end: str | None = None,
    limit: int = 20,
    max_rows: int = 10000,
) -> pd.DataFrame:
    """Get computed financial metrics (P/E, ROE, margins, per-share, etc.).

    Args:
        ticker: Single ticker ("AAPL") or list (["AAPL", "MSFT"]).
        period_type: "annual" (default) or "quarterly".
        fields: Specific metrics. E.g. ["pe_ratio", "roe", "market_cap"].
        start: Start date (YYYY-MM-DD). Defaults to 1 year ago.
        end: End date (YYYY-MM-DD).
        limit: Rows per API page (default: 20).
        max_rows: Maximum total rows to return (default: 10000).

    Returns:
        DataFrame with period_end, ticker, and requested metrics.
    """
    ticker_str = _validate_ticker(ticker, "metrics")
    _validate_dates(start, end)
    if fields is not None and isinstance(fields, str):
        raise ValueError(
            f"xfinlink: fields must be a list, not a string. "
            f"Fix: fields=['{fields}']"
        )
    if start is None:
        start = _default_start()
    params: dict = {"period_type": period_type, "limit": str(limit), "start": start}
    if fields:
        params["fields"] = ",".join(fields)
    if end:
        params["end"] = end
    result = _request(f"metrics/{ticker_str}", params, max_rows=max_rows)

    if not result["data"]:
        _warn_empty(ticker_str, start, end)
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    if "period_end" in df.columns:
        df["period_end"] = pd.to_datetime(df["period_end"])
    return df


def llm_context() -> str:
    """Print and return the xfinlink LLM context block."""
    try:
        resp = httpx.get(f"{API_BASE}/llms.txt", timeout=10)
    except httpx.TimeoutException:
        raise ValueError(
            "xfinlink: Request timed out after 10s. "
            "Fix: try again in a few seconds."
        )
    except httpx.ConnectError:
        raise ValueError(
            "xfinlink: Cannot connect to api.xfinlink.com. "
            "Fix: check your internet connection."
        )
    if resp.status_code >= 400:
        raise ValueError(
            f"xfinlink: Server error ({resp.status_code}). This is temporary. "
            "Fix: try again in a few seconds. If persistent, "
            "contact hello@xfinlink.com"
        )
    text = resp.text
    print(text)
    try:
        import pyperclip
        pyperclip.copy(text)
    except ImportError:
        pass
    return text
