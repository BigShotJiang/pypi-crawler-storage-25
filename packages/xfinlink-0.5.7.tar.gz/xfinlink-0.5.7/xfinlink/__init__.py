"""xfinlink — Free financial data API client.

    import xfinlink as xfl

    df = xfl.prices("AAPL", start="2024-01-01", end="2024-12-31")
    df = xfl.fundamentals("AAPL", period_type="annual")
    df = xfl.metrics("AAPL", fields=["pe_ratio", "roe"])
    df = xfl.search(q="apple")
    df = xfl.index("sp500")
    info = xfl.resolve("GM")
"""
from __future__ import annotations

__version__ = "0.5.7"

# ── Data API client (always available) ───────────────────────────────────
from xfinlink.client import (
    fundamentals,
    index,
    llm_context,
    metrics,
    prices,
    resolve,
    search,
    set_api_base,
    set_api_key,
    status,
    usage,
)

# Backward-compatible alias
resolve_ticker = resolve

__all__ = [
    "__version__",
    "prices",
    "fundamentals",
    "metrics",
    "resolve",
    "resolve_ticker",
    "search",
    "index",
    "status",
    "set_api_base",
    "set_api_key",
    "usage",
    "llm_context",
]

# ── Local resolver (optional — requires SQLite database + SQLAlchemy) ────
try:
    from xfinlink._db_check import check_db_ready as _check_db_ready
    from xfinlink.db import SessionLocal
    from xfinlink.panel import ValidationReport, fix_dataframe, validate_dataframe
    from xfinlink.resolver import core as _core
    from xfinlink.resolver.core import (
        EntityLineage,
        LineageEvent,
        ResolutionResult,
        ResolvedEntity,
        ResolvedIdentifier,
    )

    from datetime import date, datetime
    from typing import Any

    def _to_date(value: Any) -> date | None:
        if value is None or isinstance(value, date) and not isinstance(value, datetime):
            return value
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, str):
            return datetime.strptime(value, "%Y-%m-%d").date()
        raise TypeError(f"unsupported date type: {type(value).__name__}")

    def resolve_local(
        id_type: str,
        id_value: str,
        as_of_date: str | date | None = None,
    ) -> ResolutionResult:
        """Resolve a single identifier to its entity (local SQLite database)."""
        _check_db_ready()
        as_of = _to_date(as_of_date)
        with SessionLocal() as session:
            return _core.resolve(session, id_type, id_value, as_of)

    def bulk_resolve(requests: list[dict]) -> list[ResolutionResult]:
        """Resolve a batch of identifier requests (local SQLite database)."""
        _check_db_ready()
        normalized: list[dict] = []
        for req in requests:
            r = dict(req)
            if "as_of_date" in r:
                r["as_of_date"] = _to_date(r["as_of_date"])
            normalized.append(r)
        with SessionLocal() as session:
            return _core.bulk_resolve(session, normalized)

    def search_entities(query: str, limit: int = 10) -> list[ResolvedEntity]:
        """Fuzzy-search entities by canonical name (local SQLite database)."""
        _check_db_ready()
        with SessionLocal() as session:
            return _core.search_entities(session, query, limit=limit)

    def get_lineage(
        id_type: str,
        id_value: str,
        as_of_date: str | date | None = None,
    ) -> EntityLineage | None:
        """Return the corporate lineage for the entity matching an identifier."""
        _check_db_ready()
        as_of = _to_date(as_of_date)
        with SessionLocal() as session:
            result = _core.resolve(session, id_type, id_value, as_of)
            if result.not_found:
                return None
            return _core.get_lineage(session, result.matches[0].entity_id)

    __all__.extend([
        "resolve_local",
        "bulk_resolve",
        "search_entities",
        "get_lineage",
        "validate_dataframe",
        "fix_dataframe",
        "ValidationReport",
        "ResolutionResult",
        "ResolvedEntity",
        "ResolvedIdentifier",
        "EntityLineage",
        "LineageEvent",
    ])

except ImportError:
    pass  # Local resolver not available (SQLAlchemy / database not installed)
