__version__ = '2026.4.2' 

from .Lan_CHN import CHN
from .Lan_EN import EN
import locale

local_short = locale.getdefaultlocale()[0].split('_')[0]
if local_short == 'en':
    lan = EN
elif local_short == 'zh':
    lan = CHN
else:
    lan = EN
    
'''

通过改变lan的值，就可以实现语言的切换
例：加入德语的方法
from Lan_GER import GER
lan = GER

'''