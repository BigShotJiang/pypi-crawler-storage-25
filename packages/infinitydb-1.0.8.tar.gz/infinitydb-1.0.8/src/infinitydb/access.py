# Copyright (c) 2019-2025 Roger L. Deran
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated
# documentation files (the "Software"), to deal in the
# Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute,
# sublicense, and/or sell copies of the Software, and to permit
# persons to whom the Software is furnished to do so, subject
# to the following conditions:
#
# The above copyright notice and this permission notice
# shall be included in  all copies or substantial portions
# of the Software.
#  
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
# OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
# ARISING  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
# THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""InfinityDB database access utilities with ItemSpace model

Allow access to an InfinityDB database server via http(s) 
REST requests and JSON encoded data or blobs. See boilerbay.com. 

Requires Python v3.7+

This version was augmented by Claude Opus 4 to add the ItemSpace model
and support for tuples, ordered maps, and other data structures.

"""

import base64
import datetime
import gzip
import json
import re
import ssl
import bisect
from typing import Union, List, Tuple, Optional, Any, Dict, Iterator, Iterable
from collections.abc import Sequence
from functools import total_ordering
from urllib.parse import urlparse
import urllib.request

import dateutil.parser
from requests import Request, Session
from requests.exceptions import ConnectionError


__author__ = 'Roger L Deran'
__version__ = '2.0'
__all__ = [
    'InfinityDBAccessor',
    'InfinityDBError',
    'EntityClass',
    'Attribute',
    'Bytes',
    'ByteString',
    'Chars',
    'Index',
    'Float',
    'String',
    'Boolean',
    'Long',
    'Double',
    'Date',
    'Meta',
    'Primitive',
    'Component',
    'Item',
    'ItemSpace',
    'OrderedMap',
    'Blob',
    'to_component',
    'escape_uri_components',
    'underscore_quote',
    'underscore_quote_key',
    'underscore_unquote',
    'parse_primitive',
    'to_json_extended',
    'flatten_to_tuples',
    'unflatten_from_tuples',
    'flatten_lists_to_indexes',
    'unflatten_lists_from_indexes',
    'compact_tree_tips',
    'uncompact_tree_tips',
    'is_legal_entity_class_name',
    'is_legal_attribute_name',
    'parse_token_string_into_components',
    'item_to_tuples',
    'json_quote_primitives',
    'json_quote_primitive'
]

# Component type ordering constants
class ComponentTypeOrder:
    CLASS = 1
    ATTRIBUTE = 2
    STRING = 3
    BOOLEAN = 4
    FLOAT = 5
    DOUBLE = 6
    LONG = 7
    DATE = 8
    BYTES = 9
    BYTE_STRING = 10
    CHARS = 11
    INDEX = 12

# Regex patterns
_entity_class_attribute_regex = re.compile('^[a-zA-Z][a-zA-Z0-9_.-]*$')
_float_regex = re.compile('[+-]?[0-9]+[.]')
_date_regex = re.compile('[0-9]+[-]')

def is_legal_entity_class_name(s):
    return (_entity_class_attribute_regex.match(s) and 
            s[0] >= 'A' and s[0] <= 'Z')

def is_legal_attribute_name(s):
    return (_entity_class_attribute_regex.match(s) and 
            s[0] >= 'a' and s[0] <= 'z')

# Base Component class
@total_ordering
class Component:
    """Base class for all InfinityDB component types"""
    
    def __init__(self, value):
        if value is None or isinstance(value, Component):
            raise TypeError("Component value cannot be None or another Component")
        self.v = value
    
    def get_type_order(self):
        """Override in subclasses to return proper type order"""
        return ComponentTypeOrder.STRING
    
    @staticmethod
    def is_component(obj):
        """Check if object is a component type"""
        return (obj is not None and 
                (isinstance(obj, (int, float, bool, str, datetime.datetime)) or
                 isinstance(obj, Component)))
    
    def to_primitive(self):
        """Convert value to primitive type,
        preserving the typing safety. This means some
        component types will not be converted if
        they would be ambiguous in be converting back to a
        Component. For example, a String
        will return its string value, but an EntityClass, Attribute,
        Index, or Float component
        will not be converted to its v.
        """

        if isinstance(self, (Float, Index, Meta)):
            return self
        return self.v    

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            # Optionally, raise here too for strictness
            return False
        return self.v == other.v

    def __lt__(self, other):
        if other is None:
            raise TypeError("Cannot compare Component with None")
        if self is other:
            return False
        if isinstance(other, Item):
            return Item(self) < other

        if not isinstance(other, Component):
            raise TypeError(f"Cannot compare Component ({type(self)}) with non-Component ({type(other)})")
        # Get type orders
        self_order = self.get_type_order()
        other_order = other.get_type_order()
        # First compare by type order
        if self_order != other_order:
            return self_order < other_order
        # Then compare values within same type
        return self.v < other.v
    
    def __hash__(self):
        return hash((self.get_type_order(), self.v))
    
    def __repr__(self):
        return f"{self.__class__.__name__}({self.v!r})"

def _get_type_order_for_value(value):
    """Get type order for primitive values"""
    if value is None:
        raise TypeError("Cannot determine type order for None")
    if isinstance(value, Component):
        return value.get_type_order()
    if isinstance(value, str):
        return ComponentTypeOrder.STRING
    if isinstance(value, bool):
        return ComponentTypeOrder.BOOLEAN
    if isinstance(value, int):
        return ComponentTypeOrder.LONG
    if isinstance(value, float):
        return ComponentTypeOrder.DOUBLE
    if isinstance(value, datetime.datetime):
        return ComponentTypeOrder.DATE
    if isinstance(value, (bytes, bytearray)):
        return ComponentTypeOrder.BYTES
    raise TypeError(f"Cannot determine type order for {type(value)}")


def as_primitive(value):
    """Convert value to primitive type"""
    if isinstance(value, Component):
        return value.v
    if isinstance(value, (list, tuple)):
        if len(value) == 1:
            return as_primitive(value[0])
        raise TypeError("Cannot convert list/tuple with more than one element to primitive")
    if isinstance(value, Item):
        if len(value.components) == 1:
            return as_primitive(value.components[0])
        raise TypeError("Cannot convert Item with more than one component to primitive")
    return value

# Meta components
class Meta(Component):
    """Base class for meta components (EntityClass and Attribute)"""
    pass

class EntityClass(Meta):
    """EntityClass component type - typically first in an Item"""
    
    def __init__(self, value):
        if isinstance(value, str):
            if not is_legal_entity_class_name(value):
                raise ValueError(
                    f"EntityClass name must match [A-Z][A-Za-z0-9._-]*: {value}")
            super().__init__(value)
            self.id = -1
        elif isinstance(value, int):
            super().__init__(f'EntityClass({value})')
            self.id = value
        else:
            raise ValueError("EntityClass requires a string or int")
    
    def get_type_order(self):
        return ComponentTypeOrder.CLASS
    
    def __str__(self):
        return self.v if self.id == -1 else f'EntityClass({self.id})'

class Attribute(Meta):
    """Attribute component type - like a column name"""
    
    def __init__(self, value):
        if isinstance(value, str):
            if not is_legal_attribute_name(value):
                raise ValueError(
                    f"Attribute name must match [a-z][A-Za-z0-9._-]*: {value}")
            super().__init__(value)
            self.id = -1
        elif isinstance(value, int):
            super().__init__(f'Attribute({value})')
            self.id = value
        else:
            raise ValueError("Attribute requires a string or int")
    
    def get_type_order(self):
        return ComponentTypeOrder.ATTRIBUTE
    
    def __str__(self):
        return self.v if self.id == -1 else f'Attribute({self.id})'

# Primitive components
class Primitive(Component):
    """Base class for primitive (non-meta) components"""
    pass

class Bytes(Primitive):
    """Bytes component type - limited to 1024 bytes"""
    
    def __init__(self, value):
        if isinstance(value, bytes):
            self.b = value
        elif isinstance(value, str):
            self.b = value.encode('utf-8')
        elif isinstance(value, list):
            self.b = bytes(value)
        else:
            raise ValueError("Bytes requires bytes, string, or list")
        
        if len(self.b) > 1024:
            raise ValueError("Bytes component limited to 1024 bytes")
        
        super().__init__(self.b)
    
    def get_type_order(self):
        return ComponentTypeOrder.BYTES
    
    @staticmethod
    def token_to_bytes(s):
        if not s.startswith('Bytes(') or not s.endswith(')'):
            raise ValueError("Bytes token must be Bytes(...)")
        return Bytes.hex_to_bytes(s[6:-1])
    
    @staticmethod
    def hex_to_bytes(s):
        s = s.replace('_', '')
        if len(s) % 2 != 0:
            raise ValueError("Uneven number of hex digits")
        return bytes.fromhex(s)
    
    @staticmethod
    def bytes_to_hex(b: bytes) -> str:
        """Convert bytes to hex string with underscore separators."""
        s = b.hex().upper()
        return '_'.join(s[i:i+2] for i in range(0, len(s), 2))
    
    def __str__(self):
        return f'Bytes({Bytes.bytes_to_hex(self.b)})'       
    
    def __lt__(self, other):
        if not isinstance(other, Bytes):
            return super().__lt__(other)
        # Bytes compare by length first, then content
        if len(self.b) != len(other.b):
            return len(self.b) < len(other.b)
        return self.b < other.b

class ByteString(Primitive):
    """ByteString component type - sorts like a string"""
    
    def __init__(self, value):
        if isinstance(value, bytes):
            self.b = value
        elif isinstance(value, str):
            self.b = value.encode('utf-8')
        elif isinstance(value, list):
            self.b = bytes(value)
        else:
            raise ValueError("ByteString requires bytes, string, or list")
        
        if len(self.b) > 1024:
            raise ValueError("ByteString component limited to 1024 bytes")
        
        super().__init__(self.b)
    
    def get_type_order(self):
        return ComponentTypeOrder.BYTE_STRING
    
    @staticmethod
    def token_to_bytes(s):
        if not s.startswith('ByteString(') or not s.endswith(')'):
            raise ValueError("ByteString token must be ByteString(...)")
        return Bytes.hex_to_bytes(s[11:-1])
    
    def __str__(self):
        return f'ByteString({Bytes.bytes_to_hex(self.b)})'

class Chars(Primitive):
    """Chars component type - character array, limited to 1024 chars"""
    
    def __init__(self, value):
        if isinstance(value, bytes):
            self.s = value.decode('utf-8')
        elif isinstance(value, str):
            self.s = value
        else:
            raise ValueError("Chars requires bytes or string")
        
        if len(self.s) > 1024:
            raise ValueError("Chars component limited to 1024 characters")
        
        super().__init__(self.s)
    
    def get_type_order(self):
        return ComponentTypeOrder.CHARS
    
    @staticmethod
    def token_to_chars(s):
        if not s.startswith('Chars(') or not s.endswith(')'):
            raise ValueError("Chars token must be Chars(...)")
        after = skip_json_string(s, start=6)
        if after != len(s) - 1:
            raise TypeError(f"Invalid Chars token: {s}")
        return json.loads(s[6:after])
    
    def __str__(self):
        return f'Chars({json.dumps(self.s)})'
    
    def __lt__(self, other):
        if not isinstance(other, Chars):
            return super().__lt__(other)
        # Chars compare by length first, then content
        if len(self.s) != len(other.s):
            return len(self.s) < len(other.s)
        return self.s < other.s

class Index(Primitive):
    """Index component type for array positions"""
    
    def __init__(self, value):
        if not isinstance(value, int):
            raise TypeError(f"Index requires int, not {type(value)}")
        super().__init__(int(value))
    
    def get_type_order(self):
        return ComponentTypeOrder.INDEX
    
    def __str__(self):
        return f'[{self.v}]'
    
    def __repr__(self):
        return f'Index({self.v})'

class Float(Primitive):
    """Float component type (32-bit)"""
    
    def __init__(self, value):
        super().__init__(float(value))
    
    def get_type_order(self):
        return ComponentTypeOrder.FLOAT
    
    def __str__(self):
        v = float(self.v)
        if v.is_integer():
            return f"{int(v)}.0f"
        else:
            return f"{v}f"
        
    def __repr__(self):
        return f'Float({self.v})'

# Additional primitive wrapper classes
class String(Primitive):
    """String component wrapper"""
    
    def __init__(self, value):
        super().__init__(str(value))
    
    def get_type_order(self):
        return ComponentTypeOrder.STRING
    
    def __str__(self):
        return json.dumps(self.v)

class Boolean(Primitive):
    """Boolean component wrapper"""
    
    def __init__(self, value):
        super().__init__(bool(value))
    
    def get_type_order(self):
        return ComponentTypeOrder.BOOLEAN
    
    def __str__(self):
        return 'true' if self.v else 'false'

class Long(Primitive):
    """Long (integer) component wrapper"""
    
    def __init__(self, value):
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError(f"Long requires int, not {type(value)}")
        super().__init__(value)
    
    def get_type_order(self):
        return ComponentTypeOrder.LONG
    
    def __str__(self):
        return str(self.v)

class Double(Primitive):
    """Double (float) component wrapper"""
    
    def __init__(self, value):
        super().__init__(float(value))
    
    def get_type_order(self):
        return ComponentTypeOrder.DOUBLE
    
    def __str__(self):
        return f"{self.v}"

class Date(Primitive):
    """Date component wrapper"""
    
    def __init__(self, value):
        if isinstance(value, datetime.datetime):
            super().__init__(value)
        else:
            super().__init__(dateutil.parser.parse(str(value)))
    
    def get_type_order(self):
        return ComponentTypeOrder.DATE
    
    def __str__(self):
        return self.v.isoformat()

# Helper function to convert values to components
def to_component(value) -> Component:
    """Convert a Python value to appropriate Component type"""
    if value is None:
        raise TypeError("Cannot convert None to component")
    
    if isinstance(value, Component):
        return value
    if isinstance(value, (list, tuple)):
        if len(value) != 1:
            raise TypeError("Cannot convert list/tuple with more than one element to component")
        return to_component(value[0])
    if isinstance(value, Item):
        if len(value.components) != 1:
            raise TypeError("Cannot convert Item with more than one component to component")
        # If Item has only one component, return that component. it is already a Component
        return value.components[0]
     
    # Primitive types
    if isinstance(value, str):
        return String(value)
    elif isinstance(value, bool):  # Must check before int
        return Boolean(value)
    elif isinstance(value, int):
        return Long(value)
    elif isinstance(value, float):
        return Double(value)
    elif isinstance(value, datetime.datetime):
        return Date(value)
    elif isinstance(value, (bytes, bytearray)):
        return Bytes(value)
    else:
        raise TypeError(f"Cannot convert {type(value)} to component")

# Item class
@total_ordering
class Item:
    """Represents a sequence of components that forms a path in the database"""
    
    def __init__(self, *components):
        self.components = []
        for comp in components:
            self.add_component(comp)

    def __len__(self):
        return len(self.components)

    def __hash__(self):
        return hash(tuple(self.components))
    
    def add_component(self, component):
        """Add a component to the item"""
        if component is None:
            raise TypeError("Cannot add None component")
        elif isinstance(component, (Item)):
            # Flatten nested items/tuples
            for comp in component.components:
                self.add_component(comp)
        elif isinstance(component, (list, tuple)):
            # Flatten arrays/tuples
            for comp in component:
                self.add_component(comp)
        else:
            # Convert to component if needed
            self.components.append(to_component(component))
        return self
    
    def get_components(self):
        """Get copy of all components"""
        return self.components.copy()
    
    def get_component(self, index: int):
        """Get component at index"""
        return self.components[index]
    
    def get_at(self, index: int):
        """Get component at index (alias for get_component)"""
        if index < 0 or index >= len(self.components):
            return None
        return self.components[index]
    
    def set_at(self, index: int, value):
        """Set component at index"""
        if not isinstance(index, int):
            raise TypeError("index must be an integer")
        if index < 0 or index >= len(self.components):
            raise IndexError("Index out of bounds")

        value = to_component(value)
        self.components[index] = value
        return self
    
    def get_length(self):
        """Get number of components"""
        return len(self.components)
    
    def __len__(self):
        return len(self.components)
    
    def to_array(self):
        """Convert to array of values (loses type information)"""
        result = []
        for comp in self.components:
            if isinstance(comp, Component):
                result.append(comp.v)
            else:
                result.append(comp)
        return result
    
    def __str__(self):
        """Convert to token string representation"""
        return ' '.join(str(comp) for comp in self.components)
    
    def __repr__(self):
        return f"Item({', '.join(repr(comp) for comp in self.components)})"
    
    def slice(self, start: int, end: Optional[int] = None):
        """Create partial item from start to end (inclusive)"""
        if end is None:
            end = len(self.components) - 1
        
        new_item = Item()
        for i in range(start, min(end + 1, len(self.components))):
            new_item.add_component(self.components[i])
        
        return new_item
    
    def to_uri_path(self):
        """Convert to URI path for REST access"""
        return escape_uri_components(*self.to_array())
    
    def to_idb_object(self):
        """Convert to IDB object format"""
        if len(self.components) == 0:
            return {}
        
        obj = {}
        current = obj
        
        # Build nested structure
        for i in range(len(self.components) - 1):
            comp = self.components[i]
            key = underscore_quote_key(comp)
            if not isinstance(key, str):
                raise TypeError(f"Component {comp} produced non-string key: {key}")
            next = {}
            current[key] = next
            current = next
        
        # Set leaf value
        last_comp = self.components[-1]
        last_key = underscore_quote_key(last_comp)
        current[last_key] = None
        
        return obj
    
    @classmethod
    def from_key_path(cls, obj):
        """Create from nested dict key path"""
        item = cls()
        
        current = obj
        while current is not None and isinstance(current, dict):
            keys = list(current.keys())
            if len(keys) == 0:
                break
            
            key = keys[0]
            item.add_component(underscore_unquote(key))
            current = current[key]
        
        return item
    
    def __eq__(self, other):
        if not isinstance(other, (Item)):
            return False
        return self.components == other.components
    
    def __lt__(self, other):
        if isinstance(other, Component):
            other = Item(other)
        
        # Compare component by component
        for i in range(min(len(self.components), len(other.components))):
            if self.components[i] < other.components[i]:
                return True
            elif self.components[i] > other.components[i]:
                return False
        
        # If all components match, shorter item comes first
        return len(self.components) < len(other.components)

    @staticmethod
    def parse_tokens_to_item(s: str) -> 'Item':
        raw_components = parse_token_string_into_components(s)
        return Item(*raw_components)

    
# OrderedMap using binary search
class OrderedMap:
    """Sorted map using binary search for maintaining order"""
    
    def __init__(self):
        self.entries = []  # List of (key, value) tuples
        self.is_leaf_node = False
        self.item = None  # Complete item if this is a leaf
    
    def _binary_search(self, key):
        """Find index where key should be inserted"""
        keys = [entry[0] for entry in self.entries]
        idx = bisect.bisect_left(keys, key)
        
        if idx < len(self.entries) and self.entries[idx][0] == key:
            return {'found': True, 'index': idx}
        else:
            return {'found': False, 'index': idx}
    
    def set(self, key, value):
        """Set a key-value pair"""
        result = self._binary_search(key)
        if result['found']:
            self.entries[result['index']] = (key, value)
        else:
            self.entries.insert(result['index'], (key, value))
        return self
    
    # Get a submap with the given key
    def get(self, key):
        """Get value for key"""
        result = self._binary_search(key)
        if result['found']:
            return self.entries[result['index']][1]
        return None
    
    def has(self, key):
        """Check if key exists"""
        return self._binary_search(key)['found']
    
    def delete(self, key):
        """Delete a key"""
        result = self._binary_search(key)
        if result['found']:
            del self.entries[result['index']]
            return True
        return False
    
    def is_empty(self):
        """Check if empty"""
        return len(self.entries) == 0
    
    def set_is_leaf(self, is_leaf: bool):
        """Set leaf status"""
        self.is_leaf_node = is_leaf
        if not is_leaf:
            self.item = None
        return self
    
    def is_leaf(self):
        """Check if leaf"""
        return self.is_leaf_node
    
    def size(self):
        """Get number of entries"""
        return len(self.entries)
    
    def keys(self):
        """Get all keys in order"""
        return [entry[0] for entry in self.entries]
    
    def values(self):
        """Get all values in order"""
        return [entry[1] for entry in self.entries]
    
    def items(self):
        """Get all entries as list"""
        return self.entries.copy()
    
    def get_entries(self):
        return self.entries
    
    def __iter__(self):
        for key_comp, sub_map_node in self.entries:
            yield key_comp, sub_map_node

# ItemSpace class
class ItemSpace:
    """Collection of Items with efficient access and traversal"""
    #The ordered map keys are the components, not the raw keys.
    #The ordered map values are ItemSpace objects.
    #The ItemSpace is a tree structure where each node is an OrderedMap.

    def __init__(self, root: Optional[OrderedMap] = None):
        self.root =  OrderedMap() if root == None else root
    
    def add(self, *path):
        """Add an item from path components"""
        return self.add_item(Item(*path))
    
    def add_item(self, item: Item):
        """Add an Item to the space"""
        if not isinstance(item, Item):
            raise TypeError("Can only add Item objects")
        
        if len(item) == 0:
            return self
        
        # Check if already exists
        if self.item_exists(item):
            return self
        
        # Add to map structure
        self._add_to_map_view(item)
        
        return self
    
    def item_exists(self, item: Item) -> bool:
        """Check if item already exists"""
        if len(item) == 0:
            return False
        
        current = self.root
        
        for comp in item.components:
            if not current.has(comp):
                return False
            current = current.get(comp)
        
        return current.is_leaf()
    
    def _add_to_map_view(self, item: Item):
        """Add item to internal map structure"""
        if len(item) == 0:
            return
        
        current = self.root
        
        for comp in item.components:
            if not current.has(comp):
                current.set(comp, ItemSpace())
            current = current.get(comp)
        
        current.set_is_leaf(True)
        current.item = item
    
    def add_items(self, items: Iterable[Item]):
        """Add multiple items"""
        for item in items:
            self.add_item(item)
        return self
    
    def remove_item(self, item: Item):
        """Remove an item"""
        if not isinstance(item, Item) or len(item) == 0:
            return self
        
        # Track path for cleanup
        stack = []
        current = self.root
        
        # Find the item
        for comp in item.components:
            if not current.has(comp):
                return self
            stack.append((current, comp))
            current = current.get(comp)
        
        # Remove if found
        if current.is_leaf():
            current.set_is_leaf(False)
            current.item = None
            
            # Clean up empty nodes
            if current.is_empty():
                for i in range(len(stack) - 1, -1, -1):
                    node, key = stack[i]
                    child = node.get(key)
                    if child.is_empty() and not child.is_leaf():
                        node.delete(key)
                    else:
                        break
        
        return self
    
    def get_items(self, *, limit: Optional[int] = None) -> List[Item]:
        """Get all items with improved limit handling"""
        items: List[Item] = []
        counter = [0]  # Use list to make it mutable in nested function
        self._collect_items(self, items, counter, limit)
        return items
    
    def _collect_items(self, node: 'ItemSpace', items: List[Item], 
                      counter: List[int], limit: Optional[int]) -> bool:
        """Recursively collect items with proper limit handling
        
        Returns True if limit reached, False otherwise
        """
        if limit is not None and counter[0] >= limit:
            return True
            
        if node.is_leaf() and node.item is not None:
            items.append(node.item)
            counter[0] += 1
            if limit is not None and counter[0] >= limit:
                return True
        
        for key, child_node in node.root.entries:
            if self._collect_items(child_node, items, counter, limit):
                return True
        
        return False
        
    def is_leaf(self) -> bool:
        """Check if this ItemSpace is a leaf node"""
        return self.root.is_leaf()
    
    def set_is_leaf(self, is_leaf: bool):
        """Set leaf status for this ItemSpace"""
        self.root.set_is_leaf(is_leaf)
        return self

    def set_item(self, item: Item):
        """Set the item for this ItemSpace"""
        if not isinstance(item, Item):
            raise TypeError("ItemSpace can only hold Item objects")
        self.root.item = item
        self.root.set_is_leaf(True)
        return self
    
    def is_empty(self) -> bool:
        """Check if empty"""
        return self.root.is_empty()
    
    def get_root(self):
        """Get root map node"""
        return self.root
    
    def get(self, key):
        key = to_component(key)
        return self.root.get(key)
    
    def has(self, key) -> bool:
        """Check if key exists at root"""
        key = to_component(key)
        return self.root.has(key)
    
    def delete(self, key):
        """Delete key at root"""
        key = to_component(key)
        return self.root.delete(key)
    
    def get_keys(self, *path) -> List:
        """Get keys at given path"""
        components_flat = Item(*path).get_components()
        current = self
        
        for comp in components_flat:
            if current.is_leaf() or current.is_empty() or not current.has(comp):
                return []
            current = current.get(comp)
        
        return current.keys() if current else []
    
    def get_subspace(self, *path):
        """Get subspace at path"""
        components_flat = Item(*path).get_components()
        current = self
        
        for comp in components_flat:
            if not current.has(comp):
                return ItemSpace()
            current = current.get(comp)
        
        return current if current else ItemSpace()

    def set(self, k, space: 'ItemSpace'):
        """Set a subspace at key"""
        if not isinstance(space, ItemSpace):
            raise TypeError("ItemSpace can only hold ItemSpace objects")
        comp = to_component(k)
        self.root.set(comp, space)
        return self
    
    def get_values(self, *path):
        """Get values at path"""
        components_flat = Item(*path).get_components()
        current = self
        
        for comp in components_flat:
            if not current.has(comp):
                return []
            current = current.get(comp)
        
        return current.values() if current else []
    
    # the the keys at the root level, converted to their
    # primitive representation where applicable
    def keys(self):
        """Get root keys"""
        return [key.to_primitive() for key, _ in self.root.entries]

    def get_entries(self):
        """Get all entries at root level"""
        return [[k.to_primitive(),v] for k, v in self.root.entries]
    
    def __iter__(self):
        """Iterate over root entries as (key.to_primitive(), ItemSpace) pairs"""
        for key, child_node in self.root.entries:
            yield key.to_primitive(), child_node
    
    def count(self) -> int:
        """Count items in the ItemSpace"""
        return self._count(self)
    
    def _count(self, node: 'ItemSpace') -> int:
        """Recursively count items in the node"""
        count = 0
        
        if node.is_leaf():
            count += 1
        
        for _, child_node in node.root.entries:
            count += self._count(child_node)
        
        return count
    
    def to_idb_object(self) -> Dict:
        """Convert to InfinityDB object format"""
        return self._node_to_idb_object(self)
    
    def _node_to_idb_object(self, node:'ItemSpace') -> Optional[Dict]:
        """Convert node to IDB object"""
        if node is None:
            return None
        
        if node.is_empty() and not node.is_leaf():
            return None
        
        if node.is_leaf() and node.is_empty():
            return None
        
        obj = {}
        for key, child_node in node.root.entries:
            key_string = underscore_quote_key(key)
            child_obj = self._node_to_idb_object(child_node)
            obj[key_string] = child_obj
        
        return obj if obj else None
    
    @classmethod
    def from_idb_object(cls, obj: Dict):
        """Create ItemSpace from IDB object"""
        space = cls()
        paths = []
        
        def extract_paths(current, path=[]):
            if current is None:
                paths.append(path.copy())
                return
            if not isinstance(current, dict):
                path.append(current)
                paths.append(path.copy())
                path.pop()
                return
            
            for key, value in current.items():
                path.append(key)
                extract_paths(value, path)
                path.pop()
        
        extract_paths(obj)
        
        # Convert paths to items
        for path in paths:
            # Unquote components
            unquoted_path = [underscore_unquote(comp) for comp in path]
            space.add(*unquoted_path)
        
        return space
    
    def get_tuples(self, *path) -> List[Item]:
        """Get tuples at path (primitive sequences between metas)"""
        components_flat = Item(*path).get_components()
        current = self
        
        # Navigate to path
        for comp in components_flat:
            if not current or not current.has(comp):
                return []
            current = current.get(comp)
        
        if not current or current.is_empty() or current.is_leaf():
            return [Item()]
        
        # Collect tuples
        tuples = []
        self._collect_tuples_at_node(current, tuples, [])
        return tuples
    
    def _collect_tuples_at_node(self, current: 'ItemSpace', tuples: List[Item], path: List):
        """Collect tuples at node"""
        if not current or current.is_empty():
            return
        
        has_meta = False
        
        for key, child_node in current.root.entries:
            if isinstance(key, Meta):
                has_meta = True
            else:
                new_path = path + [key]
                
                if child_node and not child_node.is_empty():
                    self._collect_tuples_at_node(child_node, tuples, new_path)
                else:
                    tuples.append(Item(*new_path))
        
        if has_meta:
            tuples.append(Item(*path))

    def __str__(self):
        """String representation of ItemSpace"""
        item_count = self.count()
        s = f"ItemSpace({item_count} items)\n"
        limit = 100
        for item in self.get_items(limit=limit):
            if limit <= 0:
                s += "..."
                break
            s += f"{item}\n"
            limit -= 1
        if limit > 0:
            s += "No more items\n"
        else:
            s += "Too many items to display\n"
        return s
    

# Utility functions for URI encoding and JSON handling

def escape_uri_components(*k):
    """Escape components for URI path"""
    k_flattened = flatten_to_list(k)
    p = []
    for s in k_flattened:
        if s == None:
            p.append('null')
        elif s is True:
            p.append('true')
        elif s is False:
            p.append('false')
        elif isinstance(s, str):
            p.append(json.dumps(s))
        elif isinstance(s, datetime.datetime):
            p.append(s.isoformat())
        elif isinstance(s, list):
            # A one-element list is just used to represent
            # an index into a JSON array
            if len(s) != 1 or not isinstance(s[0], int):
                raise TypeError("an array index must be a single int")
            p.append('[' + str(s[0]) + ']')
        elif isinstance(s, (EntityClass, Attribute, Bytes, ByteString, Chars, Index, Float)):
            p.append(str(s))
        elif isinstance(s, Component):
            p.append(str(s))
        elif isinstance(s, (float, int)):
            p.append(str(s))
        else:
            raise TypeError(f"InfinityDB key component type not supported: {type(s)}")
    # we let parens and [] through - they are actually safe in practice
    return '/'.join([urllib.request.quote(s, safe='()[]:') for s in p])

def flatten_to_list(x):
    """Flatten nested structures to list"""
    flattened = []
    if isinstance(x, dict):
        for e in x:
            flattened += flatten_to_list(e) + flatten_to_list(x[e]) 
            break
    elif isinstance(x, (tuple, list)):
        for e in x:
            flattened += flatten_to_list(e)
    elif isinstance(x, Item):
        return flatten_to_list(x.get_components())
    elif x is not None:
        flattened += [x]
    return flattened
    
def flatten_to_tuple(x):
    """
    Convert {x:None} to (x,), or {(x,y):None} to (x,y) or [x,y] to (x,y)
    or {(x,y):(m,n)} to (x,y,m,n) or {(x,(y,),z):{m:None}} to (x,y,z,m)
    recursively.
    Assume  dict has only one key! They are not in a particular order
    """
    flattened = ()
    if isinstance(x, dict):
        for e in x:
            flattened += flatten_to_tuple(e) + flatten_to_tuple(x[e]) 
            break
    elif isinstance(x, (tuple,list)):
        for e in x:
            flattened += flatten_to_tuple(e)
    elif isinstance(x, Item):
        return flatten_to_tuple(x.get_components())
    elif x is not None:
        flattened += (x,)
    return flattened

def to_json_extended(o, depth=0, *, is_indented=True):
    """ 
    Return a string encoded in the infinitydb 
    extended JSON format for a structure o, including 
    dates and non-string keys. Tuples become lists.
    """
    is_first = True
    s = ''
    ind = '    ' * depth
    if o == None:
        return 'null'
    elif o is True:
        return 'true'
    elif o is False:
        return 'false'
    elif isinstance(o, dict):
        s = '{'
        for k in o:
            if not is_first:
                s += ','
            if is_indented:
                s += '\r\n   ' + ind
            s += to_json_extended(k, depth + 1, is_indented=is_indented) + ':'
            if is_indented:
                s += ' '
            s += to_json_extended(o[k], depth + 1, is_indented=is_indented)
            is_first = False
        if not is_first and is_indented:
            s += '\r\n' + ind
        s += '}'
    elif isinstance(o, (list, tuple)):
        s = '['
        for v in o:
            if not is_first: 
                s += ','
            if is_indented:
                s += '\r\n   ' + ind
            s += to_json_extended(v, depth + 1, is_indented=is_indented)
            is_first = False
        if not is_first and is_indented: 
            s += '\r\n' + ind
        s += ']'
    elif isinstance(o, str):
        s = json.dumps(o)
    elif isinstance(o, datetime.datetime):
        s = o.isoformat()
    else:
        s = str(o)
    return s


def json_parse_string(s, *, start=0):
    """
    start is offset in s. Return parsed_string, True if found, offset after string
    Using json.loads(s) has no start, after_string, or found boolean result.
    We don't use regexes because they may have ReDOS characteristics
    and we don't want to have to prove that they don't.
    Also, they may not match as much as possible.
    We don't use a concatenation of each char to a string
    because that is slow. The json.loads() is fast.
    """
    # find the end of the string
    after = skip_json_string(s, start=start)
    if after == -1:
        return '', False, start
    return json.loads(s[start:after]), True, after

def skip_json_string(s, *, start=0):
    # Return -1 or after the json string
    # This does no string concatenation, which is slow.
    if len(s) <= start or s[start] != '"':
        return -1
    i = start + 1
    while i < len(s):
        c = s[i]
        if c == '"':
            return i + 1
        elif c == '\\':
            i += 1
            if i >= len(s):
                raise TypeError(f"end of string after backslash in: {s[start:]}")
            if s[i] in '"\\/bfnrt':
                i += 1  # Skip the escaped character
            elif s[i] == 'u':
                i += 5  # Skip the Unicode escape sequence
            else:
                raise ValueError(f'Invalid escape sequence: \\{s[i]}')
        else:
            i += 1
    raise TypeError("ending quote not found in: " + s[start:])


def underscore_quote(o):
    """
    Convert a dict, list, or tuple into one containing only
    string elements recursively. An original string is unchanged, but all
    other component types are converted to tokens preceded by
    an underscore. Dates are converted to quoted ISO strings
    preceded by an underscore. An original string starting with
    an underscore has another underscore stuffed at the front.
    The result is suitable for JSON encoding by json.dumps().
    """
    if isinstance(o, dict):
        return {underscore_quote_key(k): underscore_quote(v)
                for k, v in o.items()}
    elif isinstance(o, list):
        return [underscore_quote(v) for v in o]
    elif isinstance(o, tuple):
        return tuple(underscore_quote(v) for v in o)
    return underscore_quote_value(o)

def underscore_quote_value(v):
    """Quote a value if needed"""
    if v == None or (isinstance(v, (bool, int, float)) and 
                     not isinstance(v, (Float, Index))):
        return v
    return underscore_quote_key(v)
    
def underscore_quote_key(k):
    """ Make any primitive or date into an 'underscore-quoted' 
     string for use as a JSON key when serializing into JSON"""
    if k == None:
        return '_null'
    elif isinstance(k, bool):
        return '_true' if k else '_false'
    elif isinstance(k, (int, float)):
        return '_' + str(k)
    elif isinstance(k, bytes):
        k = k.decode('utf-8')
        # stuff an extra underscore if necessary
        return k if k[:1] != '_' else '_' + k
    elif isinstance(k, str):
        # stuff an extra underscore if necessary
        return k if k[:1] != '_' else '_' + k
    elif isinstance(k, datetime.datetime):
        return '_' + k.isoformat()
    # elif isinstance(k, (EntityClass,Attribute,Bytes,ByteString,Chars,Index,Float)):
    #     return '_' + str(k)
    elif isinstance(k, String):
        # if there is already an underscore, stuff another one
        if k.v[:1] == '_':
            return '__' + k.v
        else:
            return k.v
    elif isinstance(k, Component):
        return '_' + str(k)
    else:
        raise TypeError(f"Cannot underscore quote type: {type(k)}")

def underscore_unquote(o):
    """ Take a limited structure that was read in as
    JSON and convert to a more general Python structure 
    having non-string keys as well as key or value dates.
    
    The non-string keys and dates are encoded as strings 
    with an initial '_', while strings originally starting 
    with '_' have another '_' stuffed at the front. Keys 
    must be primitives, however. e.g.: 
    o = underscore_unquote(json.loads(s))
    """
    # TODO bug: index primitives break in parse_primitive(),
    # but should turn into lists.
    if isinstance(o, dict):
        return {underscore_unquote(k): underscore_unquote(v) 
                for k, v in o.items()}
    elif isinstance(o, list):
        return [underscore_unquote(v) for v in o]
    elif isinstance(o, tuple):
        return tuple(underscore_unquote(v) for v in o)
    elif isinstance(o, str):
        if len(o) == 0:
            return o
        elif o[0:2] == '__':
            # Undo underscore stuffing
            return o[1:]
        elif o[0] == '_':
            # Parse underscore-quoted primitive
            return parse_primitive(o[1:])
        else:
            return o
    elif isinstance(o, Item):
        # If it's an Item, we need to unquote each component
        return [underscore_unquote(comp) for comp in o.components]
    else:
        return o

def parse_primitive(s):
    """Parse a token string to a component"""
    if len(s) == 0:
        raise TypeError("Empty primitive value")
    elif s[0] == '"':
        after = skip_json_string(s)
        if after == -1:
            raise TypeError(f"Invalid string: {s}")
        return json.loads(s[0:after])
    elif s == 'true':
        return True
    elif s == 'false':
        return False
    elif s == 'null':
        return None
    elif s[0].isdigit() or s[0] == '+' or s[0] == '-':
        if _date_regex.match(s):
            return dateutil.parser.parse(s)
        elif '.' in s:
            if s[-1] == 'f':
                return Float(float(s[:-1]))
            return float(s)
        else:
            return int(s)
    elif s[0] == '[':
        if s.find(']') != len(s) - 1:
            raise TypeError(f"Invalid index: {s}")
        try:
            index = int(s[1:-1])
        except ValueError:
            raise TypeError(f"Index must contain int: {s}")
        return Index(index)
    elif s.startswith('Bytes(') and s.endswith(')'):
        return Bytes(Bytes.token_to_bytes(s))
    elif s.startswith('ByteString(') and s.endswith(')'):
        return ByteString(ByteString.token_to_bytes(s))
    elif s.startswith('Chars(') and s.endswith(')'):
        return Chars(Chars.token_to_chars(s))
    elif _entity_class_attribute_regex.match(s):
        c = s[0]
        if 'A' <= c <= 'Z':
            return EntityClass(s)
        elif 'a' <= c <= 'z':
            return Attribute(s)
    raise TypeError(f'Cannot parse primitive: {s}')

def parse_token_string_into_components(s, *, start=0):
    """ 
    Convert a string of tokens into a list of components
    Whitespace between components is spaces, CR, LF
    We especially hate TABs, and InfinityDB does 
    not allow them anywhere, such as in i-code.
    """
    components = []
    i = start
    while True:
        after = skip_component(s, start=i)
        if after == -1:
            break
        component = parse_primitive(s[i:after])
        i = after
        components.append(component)
        # skip white between components
        while i < len(s) and s[i] in ' \r\n':
            i += 1
        if i == len(s):
            break
    if i < len(s):
        raise TypeError(f"Unparsed content at position {i}: {s}")
    return components

def skip_component(s, *, start=0):
    # return -1 or the position after the next component
    if len(s) <= start:
        return -1
    # handle embedded white. Strings and Chars() are special
    if (s[start] == '"'):
        return skip_json_string(s, start=start)
    elif s[start:].startswith('Chars('):
        i = skip_json_string(s, start=start + 6)
        if i == -1:
            raise TypeError("InfinityDB Chars() "
                            "missing string: '" + s + "'")
        if s[i] == ')':
            return i + 1 
        else:
            raise TypeError("InfinityDB Chars()  missing ')': '" + s + "'")
    else:
        # Skip non-white. This prohibits all control chars
        i = start
        while i < len(s) and s[i] > ' ':
            i += 1
        return i

def json_quote_primitives(o):
    """Pre-process structure for JSON encoding"""
    if o == None or isinstance(o, (float, int, bool)):
        return o
    elif isinstance(o, dict):
        return {json_quote_primitive(k): json_quote_primitives(v)
                for k, v in o.items()}
    elif isinstance(o, list):
        return [json_quote_primitives(v) for v in o]
    elif isinstance(o, tuple):
        return tuple(json_quote_primitives(v) for v in o)
    else:
        return json_quote_primitive(o)

def json_quote_primitive(o):
    """Quote a single primitive for JSON"""
    if isinstance(o, bytes):
        o = o.decode('utf-8')
    if isinstance(o, str):
        # doubly-quoted
        return json.dumps(o)
    elif isinstance(o, datetime.datetime):
        return '"' + o.isoformat() + '"'
    return '"' + str(o) + '"'

# Tree manipulation functions

def flatten_to_tuples(o, *, flattened_lists, compact_tips):
    """Convert a nested dict tree into one with tuple keys 
    that represent paths within the original tree. 
     
    This is very  convenient for working with trees that 
    represent sets of Items to  be logically interchanged with 
    InfinityDB, as the models are similar. The tuple keys may 
    have zero or more elements, with mixed lengths. A tuple that
    is a prefix of another cannot, however, be represented
    in the normal non-tuple tree form of nested dicts and will 
    disappear after converted back.
    
    Any EntityClass or Attribute keys found delimit the tuples, 
    so they never occur within the tuple elements. The resulting 
    tree is then an alternation depth-wise between keys that are 
    simple EntityClass and Attribute instances, and tuple keys 
    between them. This allows a high degree of forwards and 
    backwards compatibility, as the tuples can be various 
    lengths and can be extended in future databases without 
    causing incompatibilities with old code. InfinityDB can deal 
    with its Items in the same way.
    
    The InfinityDB accessor does no conversion, and the client code
    must do it, so that there are no tuple keys given to or 
    returned by the accessor. The accessor works logically 
    on JSON, i.e. nested Python lists and dicts with non-tuple
    keys. Also, the accessor assumes the terminals have been 
    compacted with compact_tree_tips(), because a terminal {} 
    will cause the Item to disappear.
    
    Note that the flattening functions sometimes try to share
    references to components and subtrees rather than 
    copying them.
    
    Args:
    flattened_lists: if not, make the resulting tree have lists, or else
        put Indexes in the tuples to represent them. The Index class
        is a simple integer key that represents the position of 
        the child tree within the list. So, for flattened_lists true,
        {x,[{y:0}]} becomes {(x,Index(0),y,0):None}
    compact_tips: if a tip can be represented without 
        nesting, do so. So {k:{}} becomes k, and {(k):None} becomes
        k. The result is some compact {k:v} terminals where k is 
        a non-tuple and v is not a dict or list. For multi-key dicts, 
        {k1:{},k2:{}} becomes {k1:None,k2:None}
        If None, do nothing to the tips.
        
    Returns:
        flattened  tree
    """
    if flattened_lists:
        rslt = flatten_lists_to_indexes(o)
    else:
        rslt = unflatten_lists_from_indexes(o, strict=False)
    rslt = flatten_to_tuples_preserving_lists(rslt)
    if compact_tips == None:
        return rslt
    elif compact_tips:
        return compact_tree_tips(rslt)
    else:
        return uncompact_tree_tips(rslt)

def flatten_to_tuples_preserving_lists(o):
    """ Flatten, preserving lists.
    Any Index keys i.e. components already there 
    become part of the tuples.
    """
    if not o:
        return None
    if isinstance(o, dict):
        rslt = {}
        for k, v in o.items():
            if k == None:
                continue
            nested = flatten_to_tuples_preserving_lists(v)
            if nested == {}:
                return {(k,): None}
            elif isinstance(nested, dict):
                for k2, v2 in nested.items():
                    if k2 == None:
                        continue
                    if isinstance(k, (EntityClass, Attribute)):
                        if k not in rslt:
                            rslt[k] = {}
                        if isinstance(k2, (EntityClass, Attribute)):
                            if () not in rslt[k]:
                                rslt[k] = {(): {}}
                            rslt[k][()][k2] = v2
                        else:
                            rslt[k][k2] = v2
                    else:
                        if isinstance(k2, (EntityClass, Attribute)):
                            rslt[(k,)] = {k2: v2}
                        elif isinstance(k2, tuple):
                            rslt[(k, *k2)] = v2
                        else:
                            rslt[(k, k2)] = v2
            elif isinstance(nested, (EntityClass, Attribute, list)):
                if isinstance(k, (EntityClass, Attribute)):
                    rslt[k] = nested
                else:
                    rslt[(k,)] = nested
            elif v == None:
                rslt[(k,)] = None
            else:
                rslt[(k, v)] = None
        return rslt
    elif isinstance(o, list):
        return [flatten_to_tuples_preserving_lists(e) for e in o]
    return {(o,): None}

def flatten_lists_to_indexes(o):
    """ Convert lists in the dict tree to lists.
    This prepares for flattening_to_tuples().
    """
    if isinstance(o, dict):
        return {k: flatten_lists_to_indexes(v) for k, v in o.items()}
    elif isinstance(o, list):
        return {Index(i): flatten_lists_to_indexes(e)
                for i, e in enumerate(o)}
    else:
        return o

def unflatten_from_tuples(o):
    """ 
    Undo the effects of flatten_to_tuples() except for 
    the conversion of Index components back into lists.
    Also see unflatten_lists_from_indexes().So for {(x,y):z}
    you get {x :{y: {z: None}}}. Use compact_tree_tips() if
    you want, so that {..{x: {y: None}}} becomes {..{x:y}}.
    A simple {x:y} is unchanged.
    The form {x : {y : {}}} is not used, because it 
    can be interpreted as non-existent even though it
    is more appealing and might sometimes be easier to work with.
    Also, x or [y,z] is unchanged but [(x,y),(z)] becomes
    [{x: {y: None}},{z: None}]. A bare (x,y) becomes {x: {y: Nnne}}
    Generally, the server regards x and {x : None} as the same, 
    both representing a singleton x.

    This makes everything convertible into JSON and from JSON
    into Items, for the REST interface to InfinityDB v6 server.
    However, the reverse conversion does not produce the same
    tuple keys, and tuple keys are only created when nested
    inside or outside of metas. The reverse conversion also
    normalizes by combining immediately nested tuple keys 
    into a single tuple key. 
    """
    result = {}
    _unflatten_from_tuples_1(o, (), result)
    return result

    # a placeholder that signals a list is present
INDEX = Index(0)
    
def _unflatten_from_tuples_1(o, item, result):
    if o == None:
        _unflatten_from_tuples_insert(result, item)
    if isinstance(o, tuple):
        _unflatten_from_tuples_insert(result, item + o)
    elif isinstance(o, list):
        for e in o:
            if isinstance(e, tuple):
                _unflatten_from_tuples_insert(result, item + (INDEX,) + e)
            elif isinstance(e, (list, dict)):
                _unflatten_from_tuples_1(e, item + INDEX, result)
            else:
                _unflatten_from_tuples_insert(result, item + (INDEX,) + (e,))
    elif isinstance(o, dict):
        for k in o:
            if isinstance(k, tuple):
                _unflatten_from_tuples_1(o[k], item + k, result)
            elif isinstance(k, (list, dict)):
                raise TypeError("Keys cannot be lists or dicts")
            else:
                _unflatten_from_tuples_1(o[k], item + (k,), result)
    else:
        _unflatten_from_tuples_insert(result, item + (o,))

# insert the item into the result dict
def _unflatten_from_tuples_insert(result, item):
    if result == None or item == ():
        return
    if not isinstance(item, tuple):
        raise TypeError
    elif isinstance(result, list):
        if not (isinstance(item[0], Index) and item[0] == INDEX):
            raise TypeError
        result.append(unflatten_from_tuples(item[1:]))
    elif isinstance(result, dict):
        if item[0] not in result:
            if isinstance(item[0], Index) and item[0] == INDEX:
                raise TypeError
            elif len(item) > 1 and isinstance(item[1], Index) and item[1] == INDEX:
                result[item[0]] = []
            elif len(item) == 1:
                result[item[0]] = None
            else:
                result[item[0]] = {}
        _unflatten_from_tuples_insert(result[item[0]], item[1:])
    else:
        raise TypeError

def remove_empty_tuples(o):
    if isinstance(o, dict):
        if () in o:
            return remove_empty_tuples(o[()])
    return o


def compact_tree_tips(o):
    """ Translate from terminals like {k:{}} to k and from {(k):None} 
    to k, possibly at the ends of the branches of a tree. This means
    that {k1:{k2:{}} becomes {k1:k2}.
    
    But note that, {(k):{}} becomes (k).
    We do not combine {(k):{(k2):{}}} to become {(k,k2):None} though.
    To do that, convert and re-establish the tuples with 
    unflatten_from_tuples() and then flatten_to_tuples().
    Also, multi-key dicts like {k:{},k2:{}} are left intact, 
    but those with tuples like {(k1):None,k2:{}} become {k1:{},k2:{}}
    """
    if isinstance(o, dict):
        if len(o) == 1:
            for k, v in o.items():
                if v == {} or v == None:
                    return k
                elif isinstance(k, tuple) and len(k) == 1:
                    if v == None:
                        return k[0]
                    else:
                        return {k:compact_tree_tips(v)}
                elif isinstance(k, (dict, list)):
                    raise TypeError("impossible dict: "
                                    "keys are dicts or lists")
                break
        return {k:compact_tree_tips(v) for k, v in o.items()}
    elif isinstance(o, list):
        return [compact_tree_tips(e) for e in o]
    else:
        return o


def uncompact_tree_tips(o):
    """ Normalize the tree so {k: v} becomes {k:{v: None}}.
    For every k, there is a value that is a dictionary or None.
    
    This undoes compact_tree_tips(). Note {(k1,k2): None} is 
    not affected. For that, if you want to undo the
    tupleness of the keys, use unflatten_from_tuples()
    """
    if isinstance(o, dict):
        rslt = {}
        for k, v in o.items():
            if isinstance(k, tuple) and v == None:
                if len(k) == 1:
                    rslt[k[0]] = None
                else:
                    # Can't get rid of a long tuple here.
                    # Use unflatten().
                    rslt[k] = None
            elif (not isinstance(k, (tuple, dict, list))
                  and v != None and not isinstance(v, (tuple, dict, list))):
                rslt[k] = {v: None}
            else:
                rslt[k] = uncompact_tree_tips(v)
        return rslt
    elif isinstance(o, list):
        return [uncompact_tree_tips(e) for e in o]
    elif o == None:
        return None
    else:
        return {o: None}


def unflatten_lists_from_indexes(o, *, strict=True,
                             collapse_sparseness=False):
    """ Change a dict that has Index keys into an actual 
    list recursively.
    
    Keys must not be tuples, so first use an 
    unflatten_from_tuples() if necessary. A dict that is to be 
    converted to a list must have only Index keys.
    
    An Index component is an instance of the Index class, and 
    it contains an int that represents the position in a list 
    when it is a dict key. So, dicts may be used in place of 
    lists, by using Index keys. InfinityDB has a corresponding 
    Index component type that can be mixed with any other component 
    type, such as primitive components, in any Item at any position.
    
    InfinityDB can compare components of any of its 12 
    component types according to a strict inter-type ordering 
    that puts Index components last. So, InfinityDB never 
    causes errors in constructing Items or comparing Items, 
    while Python cannot compare, say strings and numbers.
    
    strict: 
        the conversion raises ValueError if a mixture of Index and 
        others are present as keys in a given dict. No mixtures will be 
        present if the tuple keys were created using 
        flatten_to_tuples() when
        it works on actual lists, but if there are Index components 
        already there as as bare keys in a dict, they can end up 
        mixed with non-Index components. InfinityDB can represent 
        any mixture.
    collapse_sparseness: 
        if a dict contains Index component keys alone, it can 
        be converted to  a list, but the Index components do 
        not necessarily ascend monotonically, and if not, we can 
        remove the logical None's between them. 
        flatten_to_tuples() always creates monotonic Indexes,
        but InfinityDB can represent sparse arrays without Nones.
    """
    if isinstance(o, list):
        return [
            unflatten_lists_from_indexes(e,
                strict=strict,
                collapse_sparseness=collapse_sparseness) for e in o]
    if not isinstance(o, dict) or len(o) == 0:
        return o
    # Tf any element is not an index, we can't convert to a
    # real list, so we have to leave the Index components in there.
    # InfinityDB can mix Index components with others.
    contains_index = False
    contains_non_index = False
    for k in o:
        if isinstance(k, Index):
            contains_index = True
        else:
            contains_non_index = True
        if contains_index and contains_non_index and strict:
            raise ValueError
        if contains_non_index:
            break
    if contains_index and contains_non_index and strict:
        raise ValueError
    if contains_index and not contains_non_index:
        # all keys are Index components, so we can convert it to a list
        rslt = []
        i = 0
        # The sort never raises a TypeError because there
        # are no non-Index keys
        for index in sorted(o):
            # handle sparseness if present
            if not collapse_sparseness:
                while i < index.v:
                    rslt.append(None)
                    i += 1
            rslt.append(unflatten_lists_from_indexes(
                o[index], strict=strict,
                collapse_sparseness=collapse_sparseness
                ))
            i += 1
        return rslt
    else:
        # Actually InfinityDB can represent mixtures of
        # any type, under any given prefix, so after this,
        # there may still be some Indexes there as keys.
        return {
            k: unflatten_lists_from_indexes(
                v,
                strict=strict,
                collapse_sparseness=collapse_sparseness
                )
             for k, v in o.items()
             }


def item_to_tuples(item):
    """Split item into tuples delimited by metas"""
    tuple_val = ()
    tuples = []
    for i in range(len(item)):
        if isinstance(item[i], (EntityClass, Attribute)):
            tuples.append(tuple_val)
            tuple_val = ()
            tuples.append(item[i])
        else:
            tuple_val += (item[i],)
    tuples.append(tuple_val)
    return tuples

# REST accessor class and error handling

class InfinityDBError(IOError):
    def __init__(self, *, code, reason=None):
        super().__init__(code, reason)

class InfinityDBAccessor:
    """Main accessor class for InfinityDB REST API"""
    
    def __init__(self, server_url, *, db=None, user=None, password=None,
                 token=None, default_parameters={}, verify=None,
                 compress_requests=False):
        self.server_url = server_url
        self.db = db
        self.user = user
        self.password = password
        self.token = token
        self.token_expires_at = None
        self.context = None
        self.next_buf = None
        self.default_parameters = default_parameters.copy()
        self.session = Session()
        self.verify = verify
        self.compress_requests = compress_requests
    
    def _make_headers(self, content_type=None):
        headers = {}
        # Prefer JWT token over Basic auth if available
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'
        elif self.user is not None:
            b = f'{self.user}:{self.password}'
            b = b.encode()
            b = base64.encodebytes(b)[:-1]
            b = b.decode()
            headers['Authorization'] = f'Basic {b}'
        if content_type is not None:
            headers['Content-Type'] = content_type
        return headers
    
    def get_token(self):
        """Exchange Basic auth credentials for JWT token.
        
        Contacts the /infinitydb/auth/token endpoint using Basic authentication
        to obtain a JWT token. The token and its expiration time are stored
        in the instance for subsequent requests.
        
        Returns:
            dict: Token response containing 'token', 'expires_at', and 'user'
            
        Raises:
            ValueError: If username and password are not set
            InfinityDBError: If token acquisition fails
        """
        if not self.user or not self.password:
            raise ValueError("Username and password required to get token")
        
        # Build URL for token endpoint
        token_url = f'{self.server_url}/infinitydb/auth/token'
        
        # Use Basic auth to get token (temporarily don't use self.token)
        saved_token = self.token
        self.token = None
        headers = self._make_headers()
        self.token = saved_token
        
        try:
            response = self.session.request('POST', token_url,
                                          headers=headers, verify=self.verify)
        except ConnectionError as ce:
            raise InfinityDBError(code=400,
                                reason=f'Cannot connect to {token_url}: {ce}')
        
        if response.status_code != 200:
            raise InfinityDBError(code=response.status_code,
                                reason=f'Failed to get token: {response.reason}')
        
        data = response.json()
        self.token = data['token']
        self.token_expires_at = data['expires_at']
        return data
    
    def refresh_token_if_needed(self):
        """Refresh token if it's close to expiration.
        
        Checks if the token will expire in less than 5 minutes and refreshes
        it if necessary. This enables transparent token refresh for long-running
        clients.
        
        Returns:
            dict: Token response if refresh was performed, None otherwise
        """
        if self.token_expires_at:
            import time
            # Refresh if token expires in less than 5 minutes (300000 ms)
            if self.token_expires_at - (time.time() * 1000) < 300000:
                return self.get_token()
        return None
    
    def _ensure_valid_token(self):
        """Internal method to ensure we have a valid token before making requests.
        
        Automatically refreshes the token if it's about to expire.
        """
        if self.token:
            self.refresh_token_if_needed()

    def login_via_sso(self, hub_url=None, *, timeout=120, port=0):
        """Authenticate via SSO by opening the hub login page in a browser.

        Starts a temporary HTTP server on localhost, opens the hub login
        page in the default browser with a ``redirect_uri`` pointing at
        the local server, and waits for the hub to redirect back with a
        signed JWT token.  The token is stored in ``self.token`` for
        subsequent API requests.

        Args:
            hub_url: Base URL of the SSO hub (e.g. ``https://hub.example.com``).
                     Defaults to ``self.server_url`` (i.e. the hub *is* the
                     server being accessed).
            timeout: Seconds to wait for the browser login (default 120).
            port:    Local port to listen on (0 = random available port).

        Returns:
            str: The username from the JWT token.

        Raises:
            TimeoutError: If the user does not complete login within *timeout*.
            RuntimeError: If the callback carries no valid token.
        """
        import http.server
        import threading
        import webbrowser

        if hub_url is None:
            # Default: the hub is the same server (strip /infinitydb/data
            # or similar data-path suffix if present)
            parsed = urlparse(self.server_url)
            hub_url = f'{parsed.scheme}://{parsed.netloc}'
        # Strip trailing slash
        hub_url = hub_url.rstrip('/')

        # Mutable container for the result from the callback handler
        result = {'token': None, 'error': None}
        event = threading.Event()

        class _CallbackHandler(http.server.BaseHTTPRequestHandler):
            """Handles the redirect from the SSO hub."""

            def do_GET(self):
                from urllib.parse import urlparse as _urlparse, parse_qs
                qs = parse_qs(_urlparse(self.path).query)
                token_list = qs.get('token')
                if token_list:
                    result['token'] = token_list[0]
                    # Show a friendly page then close
                    body = (b'<html><body><h2>Login successful</h2>'
                            b'<p>You may close this tab.</p></body></html>')
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/html')
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                else:
                    result['error'] = 'No token in callback'
                    body = b'<html><body><h2>Login failed</h2></body></html>'
                    self.send_response(400)
                    self.send_header('Content-Type', 'text/html')
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                event.set()

            def log_message(self, fmt, *args):
                pass  # Suppress request logging

        server = http.server.HTTPServer(('127.0.0.1', port), _CallbackHandler)
        actual_port = server.server_address[1]
        callback_url = f'http://127.0.0.1:{actual_port}/callback'

        # Build the hub login URL
        login_url = (
            f'{hub_url}/login.html'
            f'?redirect_uri={urllib.request.quote(callback_url, safe="")}'
        )

        # Start server in a background thread
        server_thread = threading.Thread(target=server.handle_request,
                                         daemon=True)
        server_thread.start()

        # Open browser
        webbrowser.open(login_url)

        # Wait for callback
        if not event.wait(timeout):
            server.server_close()
            raise TimeoutError(
                f'SSO login timed out after {timeout}s. '
                'The browser login was not completed.')

        server.server_close()

        if result['error']:
            raise RuntimeError(f"SSO login failed: {result['error']}")

        self.token = result['token']

        # Decode the JWT payload to extract the username (no verification
        # needed here — the hub signed it and the server will verify it
        # on each request).
        import json as _json
        parts = self.token.split('.')
        if len(parts) >= 2:
            # Add padding for base64
            payload = parts[1] + '=' * (4 - len(parts[1]) % 4)
            claims = _json.loads(base64.urlsafe_b64decode(payload))
            return claims.get('sub', 'unknown')
        return 'unknown'

    def head(self):
        """Verify connectivity"""
        # Ensure token is valid before making request
        self._ensure_valid_token()
        
        full_url = f'{self.server_url}/{self.db}'
        headers = self._make_headers()
        try:
            response = self.session.request('HEAD', full_url,
                                          headers=headers, verify=self.verify)
        except ConnectionError as ce:
            raise InfinityDBError(code=400, 
                                reason=f'Cannot connect to {full_url}: {ce}')
        if response.status_code in (204, 205):
            response.status_code = 200
        return response.status_code, response.reason
    
    def create_params(self, **kwargs):
        params = ''
        kwargs2 = self.default_parameters.copy()
        kwargs2.update(kwargs)
        for kw, value in kwargs2.items():
            params += '&' if params else '?'
            if value is None:
                pass
            elif value is True:
                params += f'{kw}=true'
            elif value is False:
                params += f'{kw}=false'
            elif isinstance(value, str):
                params += f'{kw}={value}'
            elif isinstance(value, int):
                params += f'{kw}={value}'
            elif isinstance(value, dict):
                value_unflattened = unflatten_from_tuples(value)
                value_json = to_json_extended(value_unflattened, is_indented=False)
                value_uri = urllib.request.quote(value_json, safe='')
                params += f'{kw}={value_uri}'
            else:
                raise ValueError(f"Invalid parameter type: {type(value)}")
        return params
    
    def _do_command(self, prefix, *, db, action, content_type=None,
                    method='GET', data=None, no_content=False,
                    always_return_none=False, **kwargs):
        # Ensure token is valid before making request
        self._ensure_valid_token()
        
        prefix = underscore_unquote(prefix)
        if action:
            kwargs['action'] = action
        if self.db is None and db is None:
            raise ValueError('Missing db')
        
        full_url = (f'{self.server_url}/{db if db else self.db}/'
                   f'{escape_uri_components(*prefix)}'
                   f'{self.create_params(**kwargs)}')
        
        headers = self._make_headers(content_type=content_type)
        
        # Gzip compress request body if enabled and large enough
        if (self.compress_requests and data is not None
                and isinstance(data, (str, bytes)) and len(data) >= 256):
            if isinstance(data, str):
                data = gzip.compress(data.encode('utf-8'))
            else:
                data = gzip.compress(data)
            headers['Content-Encoding'] = 'gzip'
        
        try:
            response = self.session.request(method, full_url,
                                          headers=headers, data=data, 
                                          verify=self.verify)
        except ConnectionError as ce:
            raise InfinityDBError(code=400,
                                reason=f'Cannot connect to {full_url}: {ce}')
        
        content = response.content
        if content == None:
            raise InfinityDBError(code=400, reason="Null content")
        
        if response.status_code not in (200, 204, 205):
            raise InfinityDBError(code=response.status_code,
                                reason=f"{response.reason} {prefix}")
        
        if always_return_none:
            return None
        if no_content:
            return response.status_code == 200
        
        response_content_type = response.headers.get('Content-Type', '')
        return response.status_code == 200, content, response_content_type
    
    def get_blob(self, prefix, *, db=None, **kwargs):
        """Get blob data"""
        return self._do_command(prefix, db=db, action='get-blob', **kwargs)
    
    def get_json(self, prefix, *, db=None, **kwargs):
        """Get JSON data"""
        success, content, response_content_type = self._do_command(
            prefix, db=db, action='as-json', **kwargs)
        if not success:
            return False, None, None
        data_quoted = json.loads(content)
        content = underscore_unquote(data_quoted)
        return True, content, response_content_type
    
    def put_blob(self, prefix, data, content_type=None, *, db=None, **kwargs):
        """Put blob data"""
        if not isinstance(data, (bytes, Blob)):
            raise TypeError("Data must be bytes or Blob")
        if isinstance(data, Blob):
            if content_type is None:
                content_type = data.content_type
            data = data.v
        if content_type is None:
            content_type = 'application/octet-stream'
        return self._do_command(prefix, db=db, content_type=content_type,
                              action='put-blob', method='PUT', data=data,
                              always_return_none=True, **kwargs)
    
    def put_json(self, prefix, data, *, db=None, **kwargs):
        """Put JSON data"""
        data_quoted = underscore_quote(data)
        json_data = json.dumps(data_quoted).encode()
        return self._do_command(prefix, db=db, content_type='application/json',
                                action='write',
                                method='PUT', data=json_data,
                                always_return_none=True, **kwargs)
    
    def put_itemspace(self, prefix, space: ItemSpace, *, db=None, **kwargs):
        """Put ItemSpace data"""
        data = space.to_idb_object()
        return self.put_json(prefix, data, db=db, **kwargs)
    
    def post_json(self, prefix, data, *, db=None, **kwargs):
        """Post JSON data"""
        data_quoted = underscore_quote(data)
        json_data = json.dumps(data_quoted).encode()
        success, content, response_content_type = self._do_command(
            prefix, db=db, content_type='application/json',
            method='POST', data=json_data, **kwargs)
        if not success:
            return False, None, None
        components = parse_token_string_into_components(content.decode())
        return True, components, response_content_type
    
    def delete(self, prefix, *, db=None, **kwargs):
        """Delete data at prefix"""
        return self._do_command(prefix, db=db, content_type='application/json',
                                action='write',
                                method='DELETE', always_return_none=True, **kwargs)
    
    def execute_query(self, prefix, *, data=None, db=None, unflatten=False,
                      flatten=True, is_get_blob=False, is_put_blob=False,
                      params_url_parameter=None, compact_tips=False,
                      content_type='application/json', return_item_space = False,
                      **kwargs):
        """Execute a query"""
        if not is_put_blob:
            if unflatten:
                data = unflatten_from_tuples(data)
            data_quoted = underscore_quote(data)
            data = json.dumps(data_quoted).encode()
        
        if params_url_parameter:
            kwargs["params"] = params_url_parameter
        
        action = ('execute-get-blob-query' if is_get_blob else 
                 'execute-put-blob-query' if is_put_blob else 
                 'execute-query')
        
        success, content, response_content_type = self._do_command(
            prefix, db=db, content_type=content_type,
            method='GET' if is_get_blob else 'POST',
            data=data, action=action, **kwargs)
        
        if not success:
            return False, None, None
        
        if content == None:
            raise InfinityDBError(code=400, reason="Null content")
        
        if is_get_blob:
            return True, content, response_content_type
        
        if content == b'':
            data_quoted = {}
        else:
            data_quoted = json.loads(content)

        if return_item_space:
            # This does the unquoting.
            content = ItemSpace.from_idb_object(data_quoted)
            return True, content, response_content_type
        
        if not isinstance(data_quoted, dict):
            raise TypeError(f"Expected dict, got {type(data_quoted)}")
        if unflatten:
            data_quoted = unflatten_from_tuples(data_quoted)
        
        content = underscore_unquote(data_quoted)
        
        if flatten:
            content = flatten_to_tuples(content, flattened_lists=False,
                                      compact_tips=compact_tips)
        elif compact_tips == True:
            content = compact_tree_tips(content)
        elif compact_tips == False:
            content = uncompact_tree_tips(content)
        
        return True, content, response_content_type
    
    def execute_get_blob_query(self, prefix, **kwargs):
        """Execute query returning blob"""
        return self.execute_query(prefix, is_get_blob=True,
                                content_type='application/json', **kwargs)
    
    def execute_put_blob_query(self, prefix, *, content_type, **kwargs):
        """Execute query with blob data"""
        return self.execute_query(prefix, is_put_blob=True,
                                content_type=content_type, **kwargs)
    
    def get_items(self, prefix, db=None, **kwargs):
        """Get items as token strings"""
        return self._do_command(prefix, action='as-items', db=db, **kwargs)
    
    def get_items_batch(self, prefix, db=None, **kwargs):
        """Get batch of items"""
        return self._do_command(prefix, action='as-items-batch', db=db, **kwargs)
    
    def move(self, action, prefix, *, db, **kwargs):
        """Execute a move operation"""
        success, content, response_content_type = self._do_command(
            prefix, db=db, content_type='application/json',
            action=action, **kwargs)
        if not success:
            return False, None, None
        data = content.decode()
        components = parse_token_string_into_components(data)
        return True, components
    
    def first_item(self, prefix, *, db=None, **kwargs):
        """ Move to the nearest greater than or equal Item,
        with the prefix length set to 0. Because the prefix
        length is 0, the entire database can be iterated. """
        return self.move('first-item', prefix, db=db, **kwargs)
    
    def first_component(self, prefix, *, db=None, **kwargs):
        """ Move to the nearest greater than or equal component, 
        with the prefix length set to the beginning of the 
        last component in the key"""
        return self.move('first-component', prefix, db=db, **kwargs)
    
    def first_tuple(self, prefix, *, db=None, **kwargs):
        """Move to first tuple >= prefix"""
        return self.move('first-tuple', prefix, db=db, **kwargs)
    
    def next_item(self, prefix, *, db=None, buffered=False, flush=False, **kwargs):
        """Get next item"""
        if flush and self.next_buf:
            self.next_buf.flush()
        if buffered:
            return self._buffered_next(prefix, Bound.ITEM, db=db or self.db, **kwargs)
        else:
            return self.move('next-item', prefix, db=db, **kwargs)
    
    def next_component(self, prefix, *, db=None, buffered=False, flush=False, **kwargs):
        """Get next component"""
        if flush and self.next_buf:
            self.next_buf.flush()
        if buffered:
            return self._buffered_next(prefix, Bound.COMPONENT, db=db or self.db, **kwargs)
        else:
            return self.move('next-component', prefix, db=db, **kwargs)
    
    def next_tuple(self, prefix, *, db=None, buffered=False, flush=False, **kwargs):
        """Get next tuple"""
        if flush and self.next_buf:
            self.next_buf.flush()
        if buffered:
            return self._buffered_next(prefix, Bound.TUPLE, db=db or self.db, **kwargs)
        else:
            return self.move('next-tuple', prefix, db=db, **kwargs)
    
    def last_item(self, prefix, *, db=None, **kwargs):
        """Move to last item with prefix"""
        return self.move('last-item', prefix, db=db, **kwargs)
    
    def last_component(self, prefix, *, db=None, **kwargs):
        """Move to last component with prefix"""
        return self.move('last-component', prefix, db=db, **kwargs)
    
    def last_tuple(self, prefix, *, db=None, **kwargs):
        """Move to last tuple with prefix"""
        return self.move('last-tuple', prefix, db=db, **kwargs)
    
    def previous_item(self, prefix, *, db=None, **kwargs):
        """Move to previous item"""
        return self.move('previous-item', prefix, db=db, **kwargs)
    
    def previous_component(self, prefix, *, db=None, **kwargs):
        """Move to previous component"""
        return self.move('previous-component', prefix, db=db, **kwargs)
    
    def previous_tuple(self, prefix, *, db=None, **kwargs):
        """Move to previous tuple"""
        return self.move('previous-tuple', prefix, db=db, **kwargs)
    
    def exists(self, item, *, db=None, **kwargs):
        """Check if item exists"""
        return self._do_command(item, db=db, content_type='application/json',
                              no_content=True, action='exists', **kwargs)
    
    def _simple_item_output_command(self, item, action, *, db, **kwargs):
        return self._do_command(item, db=db, content_type='application/json',
                              always_return_none=True, action=action, **kwargs)
    
    def insert_item(self, item, *, db=None, **kwargs):
        """Insert an item"""
        self._simple_item_output_command(item, 'insert-item', db=db, **kwargs)
    
    def delete_item(self, item, *, db=None, **kwargs):
        """Delete an item"""
        self._simple_item_output_command(item, 'delete-item', db=db, **kwargs)
    
    def delete_subspace(self, item, *, db=None, **kwargs):
        """Delete entire subspace"""
        self._simple_item_output_command(item, 'delete-subspace', db=db, **kwargs)
    
    def commit(self, *, db=None, **kwargs):
        """Global commit"""
        self._do_command(None, db=db, content_type='application/infinitydb',
                       action='commit', always_return_none=True,
                       wait_for_durable=True, **kwargs)
    
    def roll_back(self, *, db=None, **kwargs):
        """Global rollback"""
        self._do_command(None, db=db, content_type='application/infinitydb',
                       always_return_none=True, action='rollback', **kwargs)
    
    # Buffer management for efficient iteration
    def set_next_buffer(self, *, flush=True, size=None):
        """Configure next buffer"""
        if not self.next_buf:
            self.next_buf = NextBuf(self._fill_next_buf)
        if flush:
            self.next_buf.flush()
        if size:
            self.next_buf.set_size(size)
    
    def _fill_next_buf(self, prefix, bound_type, *, db, **kwargs):
        """Fill buffer with next items"""
        success, next_item = self.next_bounded(prefix, bound_type, db=db, **kwargs)
        if not success:
            return False, []
        
        success, content, content_type = self.get_items_batch(
            next_item, limit=self.next_buf.size, db=db, **kwargs)
        if not success:
            return False, None
        
        lines = content.decode().splitlines()
        items = [parse_token_string_into_components(line) for line in lines]
        return True, items
    
    def _buffered_next(self, prefix, bound, *, db, **kwargs):
        """Get next using buffer"""
        if not self.next_buf:
            self.next_buf = NextBuf(self._fill_next_buf)
        return self.next_buf.next(prefix, bound, db=db, **kwargs)
    
    def next_bounded(self, prefix, bound_type, *, db=None, **kwargs):
        """Get next with specific bound type"""
        if bound_type == Bound.ITEM:
            return self.move('next-item', prefix, db=db, **kwargs)
        elif bound_type == Bound.TUPLE:
            return self.move('next-tuple', prefix, db=db, **kwargs)
        elif bound_type == Bound.COMPONENT:
            return self.move('next-component', prefix, db=db, **kwargs)
        else:
            raise ValueError(f"Invalid bound type: {bound_type}")

# Buffer support classes
class Bound:
    """ For NextBuf. How to find the prefix length. 
    We go backwards from the end of the Item. The result 
    is the start, the last tuple, or the last component.
    Also, for tuples, truncate before the next EC/Att, and
    for components, truncate after the final component.
     """
    ITEM = 0
    TUPLE = 1
    COMPONENT = 2

class NextBuf:
    """Buffer for efficient iteration"""
    DEFAULT_SIZE = 1000
    
    def __init__(self, buf_filler):
        self.buf = []
        self.db = None
        self.buf_filler = buf_filler
        self.size = NextBuf.DEFAULT_SIZE
    
    def flush(self):
        """Clear buffer"""
        self.buf = []
        self.db = None
    
    def set_size(self, size):
        """Set buffer size"""
        self.size = size
    
    def _get_last_tuple_off(self, item):
        """Find offset of last tuple"""
        off = 0
        for i in range(len(item)):
            if isinstance(item[i], (EntityClass, Attribute)):
                off = i + 1
        return off
    
    def _skip_tuple(self, item, off):
        """Skip to after current tuple"""
        for i in range(off, len(item)):
            if isinstance(item[i], (EntityClass, Attribute)):
                return i
        return len(item)
    
    def _locate_prefix_in_buf(self, prefix):
        """Find prefix in buffer"""
        for i in range(len(self.buf)):
            if prefix == self.buf[i][:len(prefix)]:
                return i
        return -1
    
    def _get_off_of_bound(self, item, bound_type):
        """Get offset for bound type"""
        if bound_type == Bound.ITEM:
            return 0
        elif bound_type == Bound.COMPONENT:
            return len(item) - 1 if len(item) > 0 else 0
        elif bound_type == Bound.TUPLE:
            return self._get_last_tuple_off(item)
        else:
            raise ValueError(f"Invalid bound type: {bound_type}")
    
    def _skip_bound(self, item, bound_type, off):
        """Skip past bound"""
        if bound_type == Bound.ITEM:
            return len(item)
        elif bound_type == Bound.COMPONENT:
            return off + 1 if off < len(item) else len(item)
        elif bound_type == Bound.TUPLE:
            return self._skip_tuple(item, off)
        else:
            raise ValueError(f"Invalid bound type: {bound_type}")
    
    ITEM_NOT_IN_BUF = -1
    FINAL_ITEM = -2
    
    def _get_next_from_buf(self, item, bound_type):
        """Get next from buffer if possible"""
        if not self.buf:
            return NextBuf.ITEM_NOT_IN_BUF
        
        pos = self._locate_prefix_in_buf(item)
        if pos == -1:
            return NextBuf.ITEM_NOT_IN_BUF
        # item or its extension is found in buf at pos.
        # find the last component or last tuple, or end of item
        # according to the bound type
        prefix_len = self._get_off_of_bound(item, bound_type)
        # prefix_len is 0, or at last tuple or component
        prefix = item[:prefix_len]
        
        for i in range(pos, len(self.buf)):
            found_item = self.buf[i]
            if found_item[:prefix_len] != prefix:
                return NextBuf.FINAL_ITEM
            
            after_bound = self._skip_bound(found_item, bound_type, prefix_len)
            truncated_found_item = found_item[:after_bound]
            if truncated_found_item != item:
                return truncated_found_item
        
        return NextBuf.ITEM_NOT_IN_BUF
    
    def next(self, item, bound_type, *, db, **kwargs):
        """Get next item using buffer"""
        if db != self.db:
            self.db = db
            self.buf = []
        
        next_item = self._get_next_from_buf(item, bound_type)
        if next_item == NextBuf.FINAL_ITEM:
            return False, None
        elif next_item != NextBuf.ITEM_NOT_IN_BUF:
            return True, next_item
        
        success, self.buf = self.buf_filler(item, bound_type, db=self.db, **kwargs)
        if not success:
            return False, None
        # First Item in buf is nearest >= given item.
        prefix_length = self._get_off_of_bound(item, bound_type)
        next_item = self.buf[0]
        if next_item == item and len(self.buf) > 1:
            next_item = self.buf[1]
        
        if next_item[:prefix_length] == item[:prefix_length]:
            after_bound = self._skip_bound(next_item, bound_type, prefix_length)
            return True, next_item[:after_bound]
        
        return False, None
    
class Blob:
    BLOB_KEY = "_com.infinitydb.blob"
    MIMETYPE_KEY = "_com.infinitydb.blob.mimeType" 
    BYTES_KEY = "_com.infinitydb.blob.bytes"      

    def __init__(self, data: Optional[Union[bytes, bytearray, str, Dict[str, Any]]] = None, 
                content_type: Optional[str] = None):
        self.v: Any = data 
        self.content_type: Optional[str] = content_type
        if data is not None:
            if not isinstance(content_type, str): raise TypeError(f"Blob contentType must be str, got {type(content_type)}")
            if isinstance(data, str):
                if content_type == 'application/json':
                    try: self.v = json.loads(data)
                    except json.JSONDecodeError as e: raise TypeError(f"Invalid JSON string for app/json blob: {e}")
                elif not content_type.startswith('text/'): raise TypeError(f"String data for Blob: contentType '{content_type}' invalid")
            elif isinstance(data, (bytes, bytearray)): pass 
            elif isinstance(data, dict): 
                if content_type != 'application/json': raise TypeError(f"Dict data for Blob: contentType '{content_type}' invalid")
            else: raise TypeError(f"Blob data incompatible type: {type(data)}")

    def get_as_parsed(self) -> Any:
        if self.content_type != 'application/json': raise TypeError(f"Cannot get as parsed JSON, content type is {self.content_type}")
        if isinstance(self.v, (bytes, bytearray)): return json.loads(self.v.decode('utf-8'))
        elif isinstance(self.v, str): return json.loads(self.v)
        elif isinstance(self.v, dict): return self.v
        else: raise TypeError(f"Cannot parse Blob data of type {type(self.v)} to JSON")

    def parse_from_blob_structure(self, obj_struct: Dict[str, Any]) -> 'Blob':
        if not isinstance(obj_struct, dict) or Blob.BLOB_KEY not in obj_struct: raise TypeError("Expected dict with Blob.BLOB_KEY")
        blob_internals = obj_struct[Blob.BLOB_KEY]
        if not isinstance(blob_internals, dict): raise TypeError(f"Malformed blob: '{Blob.BLOB_KEY}' not dict")
        parsed_content_type = blob_internals.get(Blob.MIMETYPE_KEY)
        if not isinstance(parsed_content_type, str): raise TypeError(f"Blob missing/invalid '{Blob.MIMETYPE_KEY}'")
        byte_chunks_list = blob_internals.get(Blob.BYTES_KEY)
        if not isinstance(byte_chunks_list, list): raise TypeError(f"Blob missing/invalid '{Blob.BYTES_KEY}' list")
        full_data_bytearray = bytearray()
        for chunk_val_quoted in byte_chunks_list:
            unquoted_val = underscore_unquote(chunk_val_quoted)
            bytes_comp_to_add: Optional[Bytes] = None
            if isinstance(unquoted_val, Bytes): bytes_comp_to_add = unquoted_val
            elif isinstance(unquoted_val, str) and unquoted_val.startswith("Bytes("):
                parsed_comp = parse_primitive(unquoted_val)
                if isinstance(parsed_comp, Bytes): bytes_comp_to_add = parsed_comp
            if bytes_comp_to_add is None: raise TypeError(f"Blob chunk not Bytes: {chunk_val_quoted}")
            full_data_bytearray.extend(bytes_comp_to_add.b)
        self.v = bytes(full_data_bytearray); self.content_type = parsed_content_type
        return self

    def to_blob_structure(self) -> Dict[str, Any]:
        data_bytes_to_encode: bytes
        if isinstance(self.v, (bytes, bytearray)): data_bytes_to_encode = bytes(self.v)
        elif isinstance(self.v, (str, dict)): data_bytes_to_encode = self.to_uint8_array()
        else: raise TypeError(f"Cannot create blob structure from data type {type(self.v)}")
        if not isinstance(self.content_type, str): raise TypeError("Blob contentType not set/str")
        quoted_bytes_chunks: List[str] = []
        chunk_size = 1024 
        for i in range(0, len(data_bytes_to_encode), chunk_size):
            chunk_data = data_bytes_to_encode[i : i + chunk_size]
            quoted_bytes_chunks.append(underscore_quote_key(Bytes(chunk_data))) 
        return { Blob.BLOB_KEY: { Blob.MIMETYPE_KEY: self.content_type, Blob.BYTES_KEY: quoted_bytes_chunks } }

    def to_uint8_array(self) -> bytes:
        if isinstance(self.v, (bytes, bytearray)): return bytes(self.v)
        elif isinstance(self.v, str):
            if self.content_type is None: raise TypeError("Cannot convert str blob to bytes w/o contentType")
            if self.content_type.startswith('text/') or self.content_type == 'application/json': return self.v.encode('utf-8')
            else: raise TypeError(f"Cannot convert str blob to bytes with contentType '{self.content_type}'")
        elif isinstance(self.v, dict): 
            if self.content_type == 'application/json': return json.dumps(underscore_quote(self.v)).encode('utf-8') # Ensure internal quoting
            else: raise TypeError(f"Cannot convert dict blob to bytes with contentType '{self.content_type}'")
        else: raise TypeError(f"Cannot convert Blob data type {type(self.v)} to bytes")

    @staticmethod
    def convert_all_contained_blob_structures(obj: Any) -> Any:
        if isinstance(obj, list): return [Blob.convert_all_contained_blob_structures(e) for e in obj]
        elif isinstance(obj, dict):
            blob_internals = obj.get(Blob.BLOB_KEY)
            if isinstance(blob_internals, dict) and \
            Blob.MIMETYPE_KEY in blob_internals and Blob.BYTES_KEY in blob_internals:
                try: return Blob().parse_from_blob_structure(obj)
                except TypeError: pass 
            return {k: Blob.convert_all_contained_blob_structures(v) for k, v in obj.items()}
        return obj
        
    def __repr__(self):
        data_len = 0
        if self.v is not None:
            if isinstance(self.v, (str, bytes, bytearray)): data_len = len(self.v)
            elif isinstance(self.v, dict): data_len = len(json.dumps(self.v))
        return f"Blob(contentType='{self.content_type}', data_len={data_len})"
    
    def __eq__(self, other): # For testing
        if not isinstance(other, Blob): return False
        return self.content_type == other.content_type and self.to_uint8_array() == other.to_uint8_array()

