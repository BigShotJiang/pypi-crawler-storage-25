"""Tests for plugin requires (PluginMeta.requires) version resolution."""
from unittest.mock import MagicMock, patch

import pytest
from django.core.exceptions import ImproperlyConfigured

from gdaps.apps import GdapsConfig


def _make_app(requires: str):
    """Return a mock app config with the given requires string."""
    meta = MagicMock()
    meta.requires = requires
    app = MagicMock()
    app.name = "tests.plugins.fake_plugin"
    app.PluginMeta = meta
    return app


def _run_check(app, installed_versions: dict):
    """
    Run only the requires portion of GdapsConfig.ready() for a single app.
    installed_versions maps package name -> version string.
    """
    import importlib.metadata

    def fake_version(name):
        if name in installed_versions:
            return installed_versions[name]
        raise importlib.metadata.PackageNotFoundError(name)

    with patch("gdaps.apps.PluginManager.plugins", return_value=[app]), \
         patch("gdaps.apps.importlib.metadata.version", side_effect=fake_version), \
         patch("gdaps.apps.PluginManager.find_hooks"), \
         patch("gdaps.apps.importlib.metadata.entry_points", return_value=[]):
        cfg = GdapsConfig.__new__(GdapsConfig)
        cfg.name = "gdaps"
        cfg.ready()


class TestCompatibilityCheck:
    def test_no_specifier_package_present(self):
        """requires = 'mypkg' — package installed, no version constraint."""
        app = _make_app("mypkg")
        _run_check(app, {"mypkg": "1.0.0"})  # must not raise / sys.exit

    def test_version_satisfied(self):
        """requires = 'mypkg>=2.0' — installed version satisfies constraint."""
        app = _make_app("mypkg>=2.0")
        _run_check(app, {"mypkg": "2.3.1"})

    def test_exact_version_satisfied(self):
        """requires = 'mypkg==1.5.0' — exact match."""
        app = _make_app("mypkg==1.5.0")
        _run_check(app, {"mypkg": "1.5.0"})

    def test_version_not_satisfied_exits(self):
        """requires = 'mypkg>=3.0' — installed version too old → ImproperlyConfigured."""
        app = _make_app("mypkg>=3.0")
        with pytest.raises(ImproperlyConfigured):
            _run_check(app, {"mypkg": "2.9.9"})

    def test_package_not_installed_exits(self):
        """requires = 'mypkg>=1.0' — package not installed at all → ImproperlyConfigured."""
        app = _make_app("mypkg>=1.0")
        with pytest.raises(ImproperlyConfigured):
            _run_check(app, {})

    def test_bare_package_not_installed_exits(self):
        """requires = 'mypkg' — package not installed → ImproperlyConfigured."""
        app = _make_app("mypkg")
        with pytest.raises(ImproperlyConfigured):
            _run_check(app, {})

    def test_version_range(self):
        """requires = 'mypkg>=1.0,<3.0' — version within range."""
        app = _make_app("mypkg>=1.0,<3.0")
        _run_check(app, {"mypkg": "2.5.0"})

    def test_version_range_upper_exceeded_exits(self):
        """requires = 'mypkg>=1.0,<3.0' — version above upper bound → ImproperlyConfigured."""
        app = _make_app("mypkg>=1.0,<3.0")
        with pytest.raises(ImproperlyConfigured):
            _run_check(app, {"mypkg": "3.0.0"})

    def test_no_requires_attribute(self):
        """Plugin without requires attribute — check is skipped entirely."""
        app = MagicMock(spec=["name", "PluginMeta"])
        app.name = "tests.plugins.fake_plugin"
        # PluginMeta has no 'requires' attribute
        del app.PluginMeta.requires
        _run_check(app, {})
