"""Tests for ``gdaps.middleware`` helpers and ``PluginManager.alter_middleware``."""

import importlib.metadata
from unittest.mock import MagicMock, patch

import pytest
from django.core.exceptions import ImproperlyConfigured

from gdaps.middleware import insert_after, insert_before
from gdaps.pluginmanager import PluginManager


# --------------------------------------------------------------------------- #
# insert_after / insert_before                                                #
# --------------------------------------------------------------------------- #

ANCHOR = "django.contrib.auth.middleware.AuthenticationMiddleware"
NEW = "myplugin.middleware.MyMiddleware"
NEW2 = "myplugin.middleware.MyOtherMiddleware"


def test_insert_after_happy_path():
    middleware = ["django.middleware.security.SecurityMiddleware", ANCHOR, "last.MW"]
    insert_after(middleware, ANCHOR, NEW)
    assert middleware == [
        "django.middleware.security.SecurityMiddleware",
        ANCHOR,
        NEW,
        "last.MW",
    ]


def test_insert_after_multiple_preserves_order():
    middleware = [ANCHOR, "tail.MW"]
    insert_after(middleware, ANCHOR, NEW, NEW2)
    assert middleware == [ANCHOR, NEW, NEW2, "tail.MW"]


def test_insert_after_missing_anchor_raises():
    middleware = ["a.MW", "b.MW"]
    with pytest.raises(ImproperlyConfigured, match="anchor middleware 'missing.MW'"):
        insert_after(middleware, "missing.MW", NEW)


def test_insert_after_no_op_when_to_insert_empty():
    middleware = ["a.MW", "b.MW"]
    insert_after(middleware, "a.MW")
    assert middleware == ["a.MW", "b.MW"]


def test_insert_before_happy_path():
    middleware = ["a.MW", ANCHOR, "tail.MW"]
    insert_before(middleware, ANCHOR, NEW)
    assert middleware == ["a.MW", NEW, ANCHOR, "tail.MW"]


def test_insert_before_multiple_preserves_order():
    middleware = [ANCHOR]
    insert_before(middleware, ANCHOR, NEW, NEW2)
    assert middleware == [NEW, NEW2, ANCHOR]


def test_insert_before_missing_anchor_raises():
    middleware = ["a.MW", "b.MW"]
    with pytest.raises(ImproperlyConfigured, match="anchor middleware 'missing.MW'"):
        insert_before(middleware, "missing.MW", NEW)


def test_insert_before_no_op_when_to_insert_empty():
    middleware = ["a.MW", "b.MW"]
    insert_before(middleware, "a.MW")
    assert middleware == ["a.MW", "b.MW"]


# --------------------------------------------------------------------------- #
# PluginManager.alter_middleware                                              #
# --------------------------------------------------------------------------- #


def test_alter_middleware_raises_without_alter_installed_apps_first():
    """``cls.group`` must be set first by ``alter_installed_apps``."""
    PluginManager.group = ""
    with pytest.raises(
        ImproperlyConfigured,
        match=r"Call PluginManager\.alter_installed_apps\(\) before alter_middleware\(\)",
    ):
        PluginManager.alter_middleware([])


def test_alter_middleware_calls_plugin_hook_and_preserves_order():
    """Plugin's ``alter_middleware`` is invoked and inserts in the right spot."""
    mock_entry_point = MagicMock(spec=importlib.metadata.EntryPoint)
    mock_entry_point.name = "test_plugin"
    mock_entry_point.value = "test_module:test_config"

    mock_module = MagicMock()

    def plugin_alter(middleware):
        insert_after(middleware, ANCHOR, NEW)

    mock_module.alter_middleware = plugin_alter

    with (
        patch("importlib.metadata.entry_points") as mock_entry_points,
        patch("importlib.import_module") as mock_import_module,
    ):
        mock_entry_points.return_value = [mock_entry_point]
        mock_import_module.return_value = mock_module

        # Seed group via alter_installed_apps first.
        PluginManager.alter_installed_apps([], "mygroup")

        middleware = ["django.middleware.security.SecurityMiddleware", ANCHOR]
        result = PluginManager.alter_middleware(middleware)

    assert result is middleware
    assert middleware == [
        "django.middleware.security.SecurityMiddleware",
        ANCHOR,
        NEW,
    ]


def test_alter_middleware_skips_plugins_without_hook():
    """Plugins that do not define ``alter_middleware`` are silently skipped."""
    mock_entry_point = MagicMock(spec=importlib.metadata.EntryPoint)
    mock_entry_point.name = "test_plugin"
    mock_entry_point.value = "test_module:test_config"

    # spec=[] ensures hasattr(module, "alter_middleware") is False.
    mock_module = MagicMock(spec=[])

    with (
        patch("importlib.metadata.entry_points") as mock_entry_points,
        patch("importlib.import_module") as mock_import_module,
    ):
        mock_entry_points.return_value = [mock_entry_point]
        mock_import_module.return_value = mock_module

        PluginManager.alter_installed_apps([], "mygroup")

        middleware = [ANCHOR]
        result = PluginManager.alter_middleware(middleware)

    assert result == [ANCHOR]


def test_alter_middleware_runs_multiple_plugins_in_entry_point_order():
    """Two plugins each contribute; later plugin sees earlier plugin's insert."""
    ep_a = MagicMock(spec=importlib.metadata.EntryPoint)
    ep_a.name = "plugin_a"
    ep_a.value = "plugin_a:apps"

    ep_b = MagicMock(spec=importlib.metadata.EntryPoint)
    ep_b.name = "plugin_b"
    ep_b.value = "plugin_b:apps"

    module_a = MagicMock()
    module_a.alter_middleware = lambda mw: insert_after(mw, ANCHOR, NEW)

    module_b = MagicMock()
    module_b.alter_middleware = lambda mw: insert_after(mw, NEW, NEW2)

    def import_side_effect(name):
        return {"plugin_a": module_a, "plugin_b": module_b}[name]

    with (
        patch("importlib.metadata.entry_points") as mock_entry_points,
        patch("importlib.import_module", side_effect=import_side_effect),
    ):
        mock_entry_points.return_value = [ep_a, ep_b]

        PluginManager.alter_installed_apps([], "mygroup")
        middleware = [ANCHOR]
        PluginManager.alter_middleware(middleware)

    assert middleware == [ANCHOR, NEW, NEW2]
