

# @pytest.mark.django_db
# def test_version_mismatch(mocker):
#     # with pytest.raises(ImproperlyConfigured):
#     #     call_command("initializeplugins", "plugin2")
#     pass
