"""Verify that built-in abstract interfaces stay abstract.

``IViewExtension`` and ``ITemplatePlugin`` (and ``IFormFieldProvider``)
are documented to be abstract bases — direct subclasses must register
as *new interfaces*, not as *implementations* of the parent. Otherwise
the documented pattern ``class IMyHook(IViewExtension): ...`` silently
breaks: ``IMyHook._implementations`` would always stay empty, and the
plugin classes would all be registered as implementations of
``IViewExtension`` itself.
"""

import pytest

from gdaps.api import InterfaceMeta
from gdaps.api.interfaces import (
    IFormFieldProvider,
    ITemplatePlugin,
    IViewExtension,
)


# ---------------------------------------------------------------------------
# IViewExtension
# ---------------------------------------------------------------------------


class IMyViewHook(IViewExtension):
    """A concrete hook derived from the abstract IViewExtension."""


class MyViewImpl(IMyViewHook):
    def alter_context_data(self, **kwargs) -> dict:
        return {"hello": "world"}


def test_iviewextension_is_abstract():
    assert IViewExtension.__dict__.get("__abstract__") is True
    assert "IViewExtension" not in InterfaceMeta._interfaces


def test_iviewextension_subclass_is_new_interface():
    """A direct subclass of IViewExtension must be a new interface."""
    assert "IMyViewHook" in InterfaceMeta._interfaces
    assert IMyViewHook.__interface__ is True


def test_iviewextension_implementations_register_on_child():
    """Implementations must register on the child interface, not parent."""
    impls = list(IMyViewHook)
    assert len(impls) == 1
    assert isinstance(impls[0], MyViewImpl)


def test_iviewextension_cannot_be_iterated():
    with pytest.raises(TypeError, match="Abstract interfaces cannot be iterated over."):
        list(IViewExtension)


# ---------------------------------------------------------------------------
# ITemplatePlugin
# ---------------------------------------------------------------------------


class IMyTemplateHook(ITemplatePlugin):
    """A concrete template hook derived from the abstract ITemplatePlugin."""


class MyTemplateImpl(IMyTemplateHook):
    template_name = "dummy.html"
    weight = 5


def test_itemplateplugin_is_abstract():
    assert ITemplatePlugin.__dict__.get("__abstract__") is True
    assert "ITemplatePlugin" not in InterfaceMeta._interfaces


def test_itemplateplugin_subclass_is_new_interface():
    assert "IMyTemplateHook" in InterfaceMeta._interfaces
    assert IMyTemplateHook.__interface__ is True


def test_itemplateplugin_implementations_register_on_child():
    impls = list(IMyTemplateHook)
    assert len(impls) == 1
    assert isinstance(impls[0], MyTemplateImpl)


def test_itemplateplugin_cannot_be_iterated():
    with pytest.raises(TypeError, match="Abstract interfaces cannot be iterated over."):
        list(ITemplatePlugin)


# ---------------------------------------------------------------------------
# IFormFieldProvider — sanity check, was already abstract
# ---------------------------------------------------------------------------


class IMyFormHook(IFormFieldProvider):
    pass


class MyFormImpl(IMyFormHook):
    def get_fields(self):
        return {}


def test_iformfieldprovider_is_abstract():
    assert IFormFieldProvider.__dict__.get("__abstract__") is True
    assert "IFormFieldProvider" not in InterfaceMeta._interfaces


def test_iformfieldprovider_subclass_is_new_interface():
    assert "IMyFormHook" in InterfaceMeta._interfaces
    assert IMyFormHook.__interface__ is True


def test_iformfieldprovider_implementations_register_on_child():
    impls = list(IMyFormHook)
    assert len(impls) == 1
    assert isinstance(impls[0], MyFormImpl)
