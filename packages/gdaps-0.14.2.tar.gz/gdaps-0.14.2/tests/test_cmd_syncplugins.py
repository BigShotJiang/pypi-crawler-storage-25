from unittest.mock import MagicMock, patch

import pytest
from django.core.exceptions import ImproperlyConfigured
from django.core.management import call_command

from gdaps.exceptions import PluginError
from gdaps.models import GdapsPlugin


class _FakeMeta:
    pass


class _FakeApp:
    def __init__(self, name, verbose_name, meta):
        self.name = name
        self.verbose_name = verbose_name
        self.PluginMeta = meta


def _make_mock_plugin(
    name="tests.plugins.mockplugin",
    version="1.0.0",
    verbose_name="Mock Plugin",
    **meta_attrs,
):
    """Create a fake AppConfig-like object with a PluginMeta."""
    meta = _FakeMeta()
    meta.version = version
    meta.verbose_name = verbose_name
    for key, value in meta_attrs.items():
        setattr(meta, key, value)
    return _FakeApp(name=name, verbose_name=verbose_name, meta=meta)


@pytest.mark.django_db
def test_syncplugins_creates_new_plugin():
    """A plugin found on disk but missing in the DB is created."""
    assert not GdapsPlugin.objects.filter(name="tests.plugins.plugin1").exists()

    call_command("syncplugins")

    plugin1 = GdapsPlugin.objects.get(name="tests.plugins.plugin1")
    assert plugin1.version == "0.0.1"
    assert plugin1.verbose_name == "Plugin 1"


@pytest.mark.django_db
def test_syncplugins_is_idempotent():
    """Running syncplugins multiple times must not create duplicates."""
    call_command("syncplugins")
    call_command("syncplugins")

    assert GdapsPlugin.objects.filter(name="tests.plugins.plugin1").count() == 1


@pytest.mark.django_db
def test_syncplugins_updates_existing_metadata():
    """Changed metadata (author, description...) on disk is copied to the DB."""
    mock_app = _make_mock_plugin(
        name="tests.plugins.mockplugin",
        version="1.0.0",
        verbose_name="Mock Plugin",
        author="Alice",
        author_email="alice@example.org",
        vendor="ACME",
        category="Core",
        description="first description",
        hidden=False,
    )

    with patch(
        "gdaps.tools.PluginManager.plugins",
        return_value=[mock_app],
    ), patch(
        "gdaps.tools.PluginManager.orphaned_plugins",
        return_value=GdapsPlugin.objects.none(),
    ):
        call_command("syncplugins")

        db_plugin = GdapsPlugin.objects.get(name="tests.plugins.mockplugin")
        assert db_plugin.author == "Alice"
        assert db_plugin.description == "first description"

        # Change metadata and re-sync.
        mock_app.PluginMeta.author = "Bob"
        mock_app.PluginMeta.description = "updated description"
        call_command("syncplugins")

        db_plugin.refresh_from_db()
        assert db_plugin.author == "Bob"
        assert db_plugin.description == "updated description"


@pytest.mark.django_db
def test_syncplugins_removes_orphaned_plugin():
    """Plugins that exist in DB but not on disk are deleted."""
    GdapsPlugin.objects.create(
        name="tests.plugins.gone",
        verbose_name="Gone",
        version="1.0.0",
    )
    assert GdapsPlugin.objects.filter(name="tests.plugins.gone").exists()

    call_command("syncplugins")

    assert not GdapsPlugin.objects.filter(name="tests.plugins.gone").exists()


@pytest.mark.django_db
def test_syncplugins_invalid_version_raises():
    """A non-semver version for a new plugin raises ImproperlyConfigured."""
    mock_app = _make_mock_plugin(
        name="tests.plugins.badversion",
        version="not-a-version",
    )

    with patch(
        "gdaps.tools.PluginManager.plugins",
        return_value=[mock_app],
    ), patch(
        "gdaps.tools.PluginManager.orphaned_plugins",
        return_value=GdapsPlugin.objects.none(),
    ):
        with pytest.raises(ImproperlyConfigured, match="version number is incorrect"):
            call_command("syncplugins")


@pytest.mark.django_db
def test_syncplugins_calls_install_on_new_plugin():
    """PluginMeta.install() is called exactly once when a plugin is first synced."""
    install_mock = MagicMock()
    mock_app = _make_mock_plugin(name="tests.plugins.withinstall")
    mock_app.PluginMeta.install = install_mock

    with patch(
        "gdaps.tools.PluginManager.plugins",
        return_value=[mock_app],
    ), patch(
        "gdaps.tools.PluginManager.orphaned_plugins",
        return_value=GdapsPlugin.objects.none(),
    ):
        call_command("syncplugins")
        assert install_mock.call_count == 1

        # A second sync must NOT call install() again.
        call_command("syncplugins")
        assert install_mock.call_count == 1


@pytest.mark.django_db
def test_syncplugins_install_failure_raises_plugin_error():
    """Exceptions raised by PluginMeta.install() are wrapped in PluginError."""
    mock_app = _make_mock_plugin(name="tests.plugins.failinstall")
    mock_app.PluginMeta.install = MagicMock(side_effect=RuntimeError("boom"))

    with patch(
        "gdaps.tools.PluginManager.plugins",
        return_value=[mock_app],
    ), patch(
        "gdaps.tools.PluginManager.orphaned_plugins",
        return_value=GdapsPlugin.objects.none(),
    ):
        with pytest.raises(PluginError, match="Error calling install"):
            call_command("syncplugins")


@pytest.mark.django_db
def test_syncplugins_newer_disk_version_requires_migrations():
    """When the on-disk version is newer and migrations are pending, a PluginError is raised."""
    GdapsPlugin.objects.create(
        name="tests.plugins.mockplugin",
        verbose_name="Mock Plugin",
        version="1.0.0",
    )
    mock_app = _make_mock_plugin(
        name="tests.plugins.mockplugin",
        version="2.0.0",
    )

    with patch(
        "gdaps.tools.PluginManager.plugins",
        return_value=[mock_app],
    ), patch(
        "gdaps.tools.PluginManager.orphaned_plugins",
        return_value=GdapsPlugin.objects.none(),
    ), patch(
        "gdaps.tools._is_database_synchronized",
        return_value=False,
    ):
        with pytest.raises(PluginError, match="Plugin version upgrade detected"):
            call_command("syncplugins")


@pytest.mark.django_db
def test_syncplugins_newer_disk_version_with_synced_db_updates():
    """When the on-disk version is newer and migrations are applied, the DB version is updated."""
    GdapsPlugin.objects.create(
        name="tests.plugins.mockplugin",
        verbose_name="Mock Plugin",
        version="1.0.0",
    )
    mock_app = _make_mock_plugin(
        name="tests.plugins.mockplugin",
        version="2.0.0",
    )

    with patch(
        "gdaps.tools.PluginManager.plugins",
        return_value=[mock_app],
    ), patch(
        "gdaps.tools.PluginManager.orphaned_plugins",
        return_value=GdapsPlugin.objects.none(),
    ), patch(
        "gdaps.tools._is_database_synchronized",
        return_value=True,
    ):
        call_command("syncplugins")

    db_plugin = GdapsPlugin.objects.get(name="tests.plugins.mockplugin")
    assert db_plugin.version == "2.0.0"


@pytest.mark.django_db
def test_syncplugins_orphans_kept_when_db_out_of_sync():
    """Orphaned plugins are kept when the DB is not in sync (safety guard)."""
    GdapsPlugin.objects.create(
        name="tests.plugins.gone",
        verbose_name="Gone",
        version="1.0.0",
    )
    orphan_qs = GdapsPlugin.objects.filter(name="tests.plugins.gone")

    with patch(
        "gdaps.tools.PluginManager.plugins",
        return_value=[],
    ), patch(
        "gdaps.tools.PluginManager.orphaned_plugins",
        return_value=orphan_qs,
    ), patch(
        "gdaps.tools._is_database_synchronized",
        return_value=False,
    ):
        call_command("syncplugins")

    assert GdapsPlugin.objects.filter(name="tests.plugins.gone").exists()


@pytest.mark.django_db
def test_syncplugins_accepts_database_argument():
    """The --database argument is accepted and does not break the command."""
    call_command("syncplugins", database="default")
    assert GdapsPlugin.objects.filter(name="tests.plugins.plugin1").exists()
