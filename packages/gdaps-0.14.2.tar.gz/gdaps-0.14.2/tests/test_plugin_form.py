"""Tests for gdaps.forms.PluginFormMixin / PluginForm and IFormFieldProvider."""

import pytest
from django import forms
from django.core.exceptions import ImproperlyConfigured

from gdaps.api.interfaces import IFormFieldProvider
from gdaps.forms import PluginForm, PluginFormMixin


# ---------------------------------------------------------------------------
# Module-level extension points (accumulate implementations across tests,
# so only used where that is harmless)
# ---------------------------------------------------------------------------


class ITestFormFields(IFormFieldProvider):
    """Shared test extension point."""


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _make_form(interface, data=None, extra_fields=None):
    """Return a PluginForm subclass bound to *data* (or unbound if None)."""
    attrs = {"interface": interface}
    if extra_fields:
        attrs.update(extra_fields)
    FormCls = type("DynForm", (PluginForm,), attrs)
    return FormCls(data=data)


# ---------------------------------------------------------------------------
# IFormFieldProvider contract
# ---------------------------------------------------------------------------


def test_iformfieldprovider_is_abstract():
    assert IFormFieldProvider.__dict__.get("__abstract__") is True


def test_iformfieldprovider_get_fields_default_returns_empty_dict():
    class IDefaultFields(IFormFieldProvider):
        pass

    impl = IDefaultFields()
    assert impl.get_fields() == {}


def test_iformfieldprovider_clean_default_returns_none():
    class ICleanDefault(IFormFieldProvider):
        pass

    assert ICleanDefault().clean(None) is None


def test_iformfieldprovider_save_default_returns_none():
    class ISaveDefault(IFormFieldProvider):
        pass

    assert ISaveDefault().save(None) is None


def test_iformfieldprovider_weight_default_is_zero():
    class IWeightDefault(IFormFieldProvider):
        pass

    assert IWeightDefault.weight == 0


# ---------------------------------------------------------------------------
# PluginFormMixin / PluginForm – class-level setup
# ---------------------------------------------------------------------------


def test_missing_interface_raises_at_instantiation():
    class NoIfaceForm(PluginForm):
        pass  # interface not set

    with pytest.raises(ImproperlyConfigured, match="interface must be set"):
        NoIfaceForm()


def test_wrong_interface_type_raises_at_class_definition():
    with pytest.raises(TypeError, match="concrete.*subclass of IFormFieldProvider"):

        class BadForm(PluginForm):
            interface = object  # not an IFormFieldProvider subclass


def test_iformfieldprovider_itself_as_interface_raises_at_class_definition():
    with pytest.raises(TypeError, match="concrete.*subclass of IFormFieldProvider"):

        class BadForm(PluginForm):
            interface = IFormFieldProvider  # the abstract base itself


def test_abstract_interface_raises_at_class_definition():
    class AbstractSubIface(IFormFieldProvider):
        __abstract__ = True

    with pytest.raises(TypeError, match="concrete.*subclass of IFormFieldProvider"):

        class BadForm(PluginForm):
            interface = AbstractSubIface


def test_intermediate_form_without_interface_does_not_raise_at_definition():
    """Subclasses that don't set interface yet are fine; only instantiation fails."""

    class IntermediateForm(PluginForm):
        pass  # no interface – OK at definition time


def test_valid_form_instantiates():
    form = _make_form(ITestFormFields)
    assert form is not None


def test_own_fields_are_present():
    class IOwnFields(IFormFieldProvider):
        pass

    class OwnFieldForm(PluginForm):
        interface = IOwnFields
        my_field = forms.CharField()

    form = OwnFieldForm()
    assert "my_field" in form.fields


# ---------------------------------------------------------------------------
# Field gathering
# ---------------------------------------------------------------------------


def test_plugin_fields_added_to_form():
    class IPluginFields(IFormFieldProvider):
        pass

    class FieldProvider(IPluginFields):
        def get_fields(self):
            return {"extra": forms.CharField()}

    form = _make_form(IPluginFields)
    assert "extra" in form.fields


def test_multiple_plugins_all_fields_present():
    class IMultiFields(IFormFieldProvider):
        pass

    class Provider1(IMultiFields):
        def get_fields(self):
            return {"field_a": forms.CharField()}

    class Provider2(IMultiFields):
        def get_fields(self):
            return {"field_b": forms.BooleanField(required=False)}

    form = _make_form(IMultiFields)
    assert "field_a" in form.fields
    assert "field_b" in form.fields


def test_field_order_follows_weight():
    class IWeightedFields(IFormFieldProvider):
        pass

    class HeavyPlugin(IWeightedFields):
        weight = 20

        def get_fields(self):
            return {"heavy": forms.CharField()}

    class LightPlugin(IWeightedFields):
        weight = 5

        def get_fields(self):
            return {"light": forms.CharField()}

    form = _make_form(IWeightedFields)
    keys = list(form.fields.keys())
    assert keys.index("light") < keys.index("heavy")


def test_empty_get_fields_contributes_nothing():
    class INoContrib(IFormFieldProvider):
        pass

    class EmptyProvider(INoContrib):
        pass  # get_fields() returns {} by default

    form = _make_form(INoContrib)
    assert set(form.fields.keys()) == set()


def test_plugin_fields_merged_with_own_fields():
    class IMixedFields(IFormFieldProvider):
        pass

    class ExtraProvider(IMixedFields):
        def get_fields(self):
            return {"plugin_field": forms.CharField(required=False)}

    class MixedForm(PluginForm):
        interface = IMixedFields
        own_field = forms.CharField(required=False)

    form = MixedForm()
    assert "own_field" in form.fields
    assert "plugin_field" in form.fields


# ---------------------------------------------------------------------------
# Validation / clean
# ---------------------------------------------------------------------------


def test_valid_data_passes_is_valid():
    class IValidClean(IFormFieldProvider):
        pass

    class BoolProvider(IValidClean):
        def get_fields(self):
            return {"flag": forms.BooleanField(required=False)}

    form = _make_form(IValidClean, data={"flag": True})
    assert form.is_valid(), form.errors


def test_plugin_clean_is_called_on_is_valid():
    class ICleanCallback(IFormFieldProvider):
        pass

    calls = []

    class CleanProvider(ICleanCallback):
        def get_fields(self):
            return {"hook_field": forms.CharField(required=False)}

        def clean(self, form):
            calls.append("cleaned")

    form = _make_form(ICleanCallback, data={"hook_field": "hello"})
    form.is_valid()
    assert calls == ["cleaned"]


def test_plugin_clean_receives_form_instance():
    class ICleanForm(IFormFieldProvider):
        pass

    received = []

    class CleanReceiver(ICleanForm):
        def clean(self, form):
            received.append(form)

    form = _make_form(ICleanForm, data={})
    form.is_valid()
    assert received[0] is form


def test_plugin_clean_can_add_field_error():
    class ICleanError(IFormFieldProvider):
        pass

    class ErrorProvider(ICleanError):
        def get_fields(self):
            return {"bad_field": forms.CharField(required=False)}

        def clean(self, form):
            form.add_error("bad_field", "always invalid")

    form = _make_form(ICleanError, data={"bad_field": "anything"})
    assert not form.is_valid()
    assert "bad_field" in form.errors


def test_plugin_clean_has_access_to_cleaned_data():
    class ICleanData(IFormFieldProvider):
        pass

    captured = {}

    class DataReader(ICleanData):
        def get_fields(self):
            return {"value": forms.CharField()}

        def clean(self, form):
            captured["value"] = form.cleaned_data.get("value")

    form = _make_form(ICleanData, data={"value": "test"})
    assert form.is_valid(), form.errors
    assert captured["value"] == "test"


# ---------------------------------------------------------------------------
# save / save_plugins
# ---------------------------------------------------------------------------


def test_save_calls_all_plugin_saves():
    class ISaveAll(IFormFieldProvider):
        pass

    saved = []

    class SaveProvider1(ISaveAll):
        def save(self, form):
            saved.append("provider1")

    class SaveProvider2(ISaveAll):
        def save(self, form):
            saved.append("provider2")

    form = _make_form(ISaveAll, data={})
    form.full_clean()
    form.save()
    assert "provider1" in saved
    assert "provider2" in saved


def test_save_receives_form_instance():
    class ISaveInstance(IFormFieldProvider):
        pass

    received = []

    class FormReceiver(ISaveInstance):
        def save(self, form):
            received.append(form)

    form = _make_form(ISaveInstance, data={})
    form.full_clean()
    form.save()
    assert received[0] is form


def test_save_has_access_to_cleaned_data():
    class ISaveData(IFormFieldProvider):
        pass

    captured = {}

    class DataCapture(ISaveData):
        def get_fields(self):
            return {"my_value": forms.CharField()}

        def save(self, form):
            captured["my_value"] = form.cleaned_data.get("my_value")

    form = _make_form(ISaveData, data={"my_value": "hello"})
    assert form.is_valid(), form.errors
    form.save()
    assert captured["my_value"] == "hello"


def test_save_plugins_can_be_called_explicitly():
    class ISaveExplicit(IFormFieldProvider):
        pass

    called = []

    class ExplicitSaveProvider(ISaveExplicit):
        def save(self, form):
            called.append(True)

    class CustomSaveForm(PluginForm):
        interface = ISaveExplicit

        def save(self):
            self.save_plugins()

    form = CustomSaveForm(data={})
    form.full_clean()
    form.save()
    assert called


# ---------------------------------------------------------------------------
# PluginFormMixin with a non-PluginForm base
# ---------------------------------------------------------------------------


def test_mixin_with_plain_form_base():
    class IPlainMixin(IFormFieldProvider):
        pass

    class MyMixedForm(PluginFormMixin, forms.Form):
        interface = IPlainMixin
        own = forms.CharField(required=False)

    form = MyMixedForm(data={"own": "value"})
    assert "own" in form.fields
    assert form.is_valid()


def test_mixin_plugin_fields_work_with_plain_form():
    class IMixinPlugin(IFormFieldProvider):
        pass

    class MixinProvider(IMixinPlugin):
        def get_fields(self):
            return {"extra": forms.CharField(required=False)}

    class MyMixedForm(PluginFormMixin, forms.Form):
        interface = IMixinPlugin

    form = MyMixedForm(data={"extra": "hi"})
    assert "extra" in form.fields
    assert form.is_valid()


# ---------------------------------------------------------------------------
# Plugin field grouping (fields_by_plugin)
# ---------------------------------------------------------------------------


def test_fields_by_plugin_groups_host_and_plugin_fields():
    class IGroupedFields(IFormFieldProvider):
        pass

    class GroupProvider(IGroupedFields):
        weight = 10
        title = "My Plugin Section"

        def get_fields(self):
            return {"plugin_field": forms.CharField()}

    class MyForm(PluginForm):
        interface = IGroupedFields
        host_field = forms.CharField()

    form = MyForm()
    groups = form.fields_by_plugin

    assert len(groups) == 2

    host_plugin, host_fields = groups[0]
    assert host_plugin is None
    assert [f.name for f in host_fields] == ["host_field"]

    plugin, plugin_fields = groups[1]
    assert plugin is not None
    assert plugin.title == "My Plugin Section"
    assert [f.name for f in plugin_fields] == ["plugin_field"]


def test_plugin_field_has_plugin_attribute():
    class IAttrFields(IFormFieldProvider):
        pass

    class AttrProvider(IAttrFields):
        def get_fields(self):
            return {"attr_field": forms.CharField()}

    form = _make_form(IAttrFields)
    field = form.fields["attr_field"]

    assert hasattr(field, "_plugin")
    assert field._plugin is not None
    assert isinstance(field._plugin, AttrProvider)


def test_plugin_field_has_title_attribute():
    class ITitleFields(IFormFieldProvider):
        pass

    class TitleProvider(ITitleFields):
        title = "Custom Title"

        def get_fields(self):
            return {"title_field": forms.CharField()}

    form = _make_form(ITitleFields)
    field = form.fields["title_field"]

    assert hasattr(field, "_plugin_title")
    assert field._plugin_title == "Custom Title"


def test_plugin_field_title_defaults_to_empty_string():
    class INoTitleFields(IFormFieldProvider):
        pass

    class NoTitleProvider(INoTitleFields):
        def get_fields(self):
            return {"no_title_field": forms.CharField()}

    form = _make_form(INoTitleFields)
    field = form.fields["no_title_field"]

    assert field._plugin_title == ""
