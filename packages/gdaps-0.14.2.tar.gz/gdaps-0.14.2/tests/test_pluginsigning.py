import json
import os
import pytest
from unittest.mock import patch


class TestCreatePluginKeys:
    """Tests for the createpluginkeys management command."""

    def test_generate_keys(self, tmp_path):
        """Test that keys are generated correctly."""
        from gdaps.management.commands.createpluginkeys import Command

        cmd = Command()
        cmd.handle(output=str(tmp_path), prefix="testkey")

        private_path = tmp_path / "testkey.key"
        public_path = tmp_path / "testkey.pub"

        assert private_path.exists()
        assert public_path.exists()
        assert os.stat(private_path).st_mode & 0o777 == 0o600

    def test_keys_are_valid_ed25519(self, tmp_path):
        """Test that generated keys are valid Ed25519 keys."""
        from cryptography.hazmat.primitives.asymmetric import ed25519
        from cryptography.hazmat.primitives import serialization

        from gdaps.management.commands.createpluginkeys import Command

        cmd = Command()
        cmd.handle(output=str(tmp_path))

        private_path = tmp_path / "gdaps_plugin.key"

        with open(private_path, "rb") as f:
            key_data = f.read()

        private_key = serialization.load_ssh_private_key(key_data, password=None)
        assert isinstance(private_key, ed25519.Ed25519PrivateKey)

        public_key = private_key.public_key()
        assert isinstance(public_key, ed25519.Ed25519PublicKey)


class TestSignPlugin:
    """Tests for the signplugin management command."""

    def test_sign_plugin_with_valid_key(self, tmp_path):
        """Test signing a plugin directory."""
        from gdaps.management.commands.createpluginkeys import Command as KeyCmd
        from gdaps.management.commands.signplugin import MANIFEST_FILENAME

        key_cmd = KeyCmd()
        key_cmd.handle(output=str(tmp_path), prefix="signing")

        private_key_path = tmp_path / "signing.key"

        plugin_dir = tmp_path / "myplugin"
        plugin_dir.mkdir()
        (plugin_dir / "__init__.py").write_text("# test plugin")
        (plugin_dir / "apps.py").write_text("name = 'test'")
        (plugin_dir / "models.py").write_text("class Model: pass")

        from gdaps.management.commands.signplugin import Command as SignCmd

        sign_cmd = SignCmd()
        sign_cmd.handle(
            plugin_path=str(plugin_dir),
            private_key=str(private_key_path),
        )

        manifest_path = plugin_dir / MANIFEST_FILENAME
        assert manifest_path.exists()

        with open(manifest_path) as f:
            signed_manifest = json.load(f)

        assert "manifest" in signed_manifest
        assert "signature" in signed_manifest
        assert "files" in signed_manifest["manifest"]

    def test_sign_plugin_fails_without_key(self, tmp_path):
        """Test that signing fails without a key."""
        from django.core.management.base import CommandError

        plugin_dir = tmp_path / "myplugin"
        plugin_dir.mkdir()

        from gdaps.management.commands.signplugin import Command

        sign_cmd = Command()

        with pytest.raises(CommandError, match="--private-key or --key-env"):
            sign_cmd.handle(plugin_path=str(plugin_dir))

    def test_sign_plugin_fails_on_existing_manifest(self, tmp_path):
        """Test that signing fails if manifest already exists."""
        from django.core.management.base import CommandError

        from gdaps.management.commands.createpluginkeys import Command as KeyCmd

        key_cmd = KeyCmd()
        key_cmd.handle(output=str(tmp_path))

        plugin_dir = tmp_path / "myplugin"
        plugin_dir.mkdir()
        (plugin_dir / "MANIFEST.SIG").write_text('{"test": true}')

        from gdaps.management.commands.signplugin import Command

        sign_cmd = Command()

        with pytest.raises(CommandError, match="already exists"):
            sign_cmd.handle(
                plugin_path=str(plugin_dir),
                private_key=str(tmp_path / "gdaps_plugin.key"),
            )


class TestSignatureVerification:
    """Tests for signature verification logic."""

    def test_verify_valid_signature(self, tmp_path):
        """Test verification of a valid signed plugin."""
        from gdaps.management.commands.createpluginkeys import Command as KeyCmd
        from gdaps.management.commands.signplugin import Command as SignCmd

        key_cmd = KeyCmd()
        key_cmd.handle(output=str(tmp_path))

        plugin_dir = tmp_path / "testplugin"
        plugin_dir.mkdir()
        (plugin_dir / "__init__.py").write_text("print('hello')")

        sign_cmd = SignCmd()
        sign_cmd.handle(
            plugin_path=str(plugin_dir), private_key=str(tmp_path / "gdaps_plugin.key")
        )

        public_key_path = tmp_path / "gdaps_plugin.pub"
        public_key_pem = public_key_path.read_text()

        with patch("gdaps.signing.gdaps_settings") as mock_settings:
            mock_settings.PLUGIN_SIGNING_PUBKEY = public_key_pem
            mock_settings.REQUIRE_SIGNED_PLUGINS = True

            from gdaps.signing import verify_plugin_signature

            success, error = verify_plugin_signature("testplugin", str(plugin_dir))
            assert success is True
            assert error is None

    def test_verify_tampered_file(self, tmp_path):
        """Test that verification fails if a file was modified."""
        from gdaps.management.commands.createpluginkeys import Command as KeyCmd
        from gdaps.management.commands.signplugin import Command as SignCmd

        key_cmd = KeyCmd()
        key_cmd.handle(output=str(tmp_path))

        plugin_dir = tmp_path / "testplugin"
        plugin_dir.mkdir()
        (plugin_dir / "__init__.py").write_text("original content")

        sign_cmd = SignCmd()
        sign_cmd.handle(
            plugin_path=str(plugin_dir), private_key=str(tmp_path / "gdaps_plugin.key")
        )

        (plugin_dir / "__init__.py").write_text("tampered content")

        public_key_pem = (tmp_path / "gdaps_plugin.pub").read_text()

        with patch("gdaps.signing.gdaps_settings") as mock_settings:
            mock_settings.PLUGIN_SIGNING_PUBKEY = public_key_pem
            mock_settings.REQUIRE_SIGNED_PLUGINS = True

            from gdaps.signing import (
                verify_plugin_signature,
                PluginCodeTamperedError,
            )

            with pytest.raises(PluginCodeTamperedError):
                verify_plugin_signature("testplugin", str(plugin_dir))

    def test_verify_unsigned_plugin_with_strict_mode(self, tmp_path):
        """Test that unsigned plugins raise in strict mode."""
        from gdaps.management.commands.createpluginkeys import Command as KeyCmd

        key_cmd = KeyCmd()
        key_cmd.handle(output=str(tmp_path))

        public_key_pem = (tmp_path / "gdaps_plugin.pub").read_text()

        plugin_dir = tmp_path / "unsignedplugin"
        plugin_dir.mkdir()
        (plugin_dir / "__init__.py").write_text("print('hello')")

        with patch("gdaps.signing.gdaps_settings") as mock_settings:
            mock_settings.PLUGIN_SIGNING_PUBKEY = public_key_pem
            mock_settings.PLUGIN_SIGNING_PUBKEYS = []
            mock_settings.REQUIRE_SIGNED_PLUGINS = True

            from gdaps.signing import verify_plugin_signature, PluginNotSignedError

            with pytest.raises(PluginNotSignedError, match="not signed"):
                verify_plugin_signature("unsignedplugin", str(plugin_dir))

    def test_verify_unsigned_plugin_with_non_strict_mode(self, tmp_path):
        """Test that unsigned plugins are allowed in non-strict mode."""
        from gdaps.management.commands.createpluginkeys import Command as KeyCmd

        key_cmd = KeyCmd()
        key_cmd.handle(output=str(tmp_path))

        public_key_pem = (tmp_path / "gdaps_plugin.pub").read_text()

        plugin_dir = tmp_path / "unsignedplugin"
        plugin_dir.mkdir()
        (plugin_dir / "__init__.py").write_text("print('hello')")

        with patch("gdaps.signing.gdaps_settings") as mock_settings:
            mock_settings.PLUGIN_SIGNING_PUBKEY = public_key_pem
            mock_settings.PLUGIN_SIGNING_PUBKEYS = []
            mock_settings.REQUIRE_SIGNED_PLUGINS = False

            from gdaps.signing import verify_plugin_signature

            success, error = verify_plugin_signature("unsignedplugin", str(plugin_dir))
            assert success is True

    def test_verify_missing_public_key(self, tmp_path):
        """Test behavior when no public key is configured."""
        plugin_dir = tmp_path / "someplugin"
        plugin_dir.mkdir()

        with patch("gdaps.signing.gdaps_settings") as mock_settings:
            mock_settings.PLUGIN_SIGNING_PUBKEY = None
            mock_settings.REQUIRE_SIGNED_PLUGINS = False

            from gdaps.signing import verify_plugin_signature

            success, error = verify_plugin_signature("someplugin", str(plugin_dir))
            assert success is True

    def test_verify_no_public_key_with_manifest(self, tmp_path):
        """Test that a manifest without a configured public key logs warning and returns success."""
        plugin_dir = tmp_path / "someplugin"
        plugin_dir.mkdir()
        (plugin_dir / "__init__.py").write_text("print('hello')")

        manifest = {
            "manifest": {
                "version": "1.0",
                "plugin_name": "someplugin",
                "files": {"__init__.py": "abc123"},
            },
            "signature": "def456",
        }
        (plugin_dir / "MANIFEST.SIG").write_text(json.dumps(manifest))

        with patch("gdaps.signing.gdaps_settings") as mock_settings:
            mock_settings.PLUGIN_SIGNING_PUBKEY = None
            mock_settings.REQUIRE_SIGNED_PLUGINS = False

            from gdaps.signing import verify_plugin_signature

            success, error = verify_plugin_signature("someplugin", str(plugin_dir))
            assert success is True


class TestGetPublicKeys:
    """Tests for public key parsing."""

    def test_parse_pem_public_key(self):
        """Test parsing PEM format public key."""
        from cryptography.hazmat.primitives.asymmetric import ed25519
        from cryptography.hazmat.primitives import serialization

        private_key = ed25519.Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        from gdaps.signing import _parse_public_key

        parsed = _parse_public_key(pem.decode())
        assert isinstance(parsed, ed25519.Ed25519PublicKey)

    def test_parse_openssh_public_key(self):
        """Test parsing OpenSSH format public key."""
        from cryptography.hazmat.primitives.asymmetric import ed25519
        from cryptography.hazmat.primitives import serialization

        private_key = ed25519.Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        openssh = public_key.public_bytes(
            encoding=serialization.Encoding.OpenSSH,
            format=serialization.PublicFormat.OpenSSH,
        )

        from gdaps.signing import _parse_public_key

        parsed = _parse_public_key(openssh.decode())
        assert isinstance(parsed, ed25519.Ed25519PublicKey)
