import importlib.metadata
from unittest.mock import MagicMock, patch
import pytest
from django.apps import AppConfig

from gdaps.exceptions import PluginError
from gdaps.pluginmanager import PluginManager


def test_pluginmanager_alter_installed_apps_with_wrong_entrypoint():
    # try to find plugins from a nonexisting entry point

    INSTALLED_APPS = ["blah_app", "foo_app"]
    PluginManager.alter_installed_apps(
        installed_apps=INSTALLED_APPS, group="gdapstest_foo321.plugins"
    )
    assert INSTALLED_APPS == ["blah_app", "foo_app"]


def test_alter_installed_apps_raises_on_empty_group():
    with pytest.raises(PluginError, match="You have to specify an entry points group"):
        PluginManager.alter_installed_apps([], "")


def test_alter_installed_apps_success():
    # Mock entry points
    mock_entry_point = MagicMock(spec=importlib.metadata.EntryPoint)
    mock_entry_point.name = "test_plugin"
    mock_entry_point.value = "test_module:test_config"

    # Mock the module that will be imported
    mock_module = MagicMock()

    def mock_alter(apps):
        apps.append("plugin_added_app")

    mock_module.alter_installed_apps = mock_alter

    with (
        patch("importlib.metadata.entry_points") as mock_entry_points,
        patch("importlib.import_module") as mock_import_module,
    ):
        mock_entry_points.return_value = [mock_entry_point]
        mock_import_module.return_value = mock_module

        initial_apps = ["django.contrib.admin", "gdaps"]
        updated_apps = PluginManager.alter_installed_apps(initial_apps, "mygroup")

        assert "plugin_added_app" in updated_apps
        assert updated_apps == ["django.contrib.admin", "gdaps", "plugin_added_app"]
        mock_import_module.assert_called_once_with("test_module")


def test_alter_installed_apps_no_callable():
    # Mock entry points
    mock_entry_point = MagicMock(spec=importlib.metadata.EntryPoint)
    mock_entry_point.name = "test_plugin"
    mock_entry_point.value = "test_module:test_config"

    # Mock the module without alter_installed_apps
    mock_module = MagicMock(spec=[])  # No attributes

    with (
        patch("importlib.metadata.entry_points") as mock_entry_points,
        patch("importlib.import_module") as mock_import_module,
    ):
        mock_entry_points.return_value = [mock_entry_point]
        mock_import_module.return_value = mock_module

        initial_apps = ["django.contrib.admin", "gdaps"]
        updated_apps = PluginManager.alter_installed_apps(
            initial_apps.copy(), "mygroup"
        )

        assert updated_apps == ["django.contrib.admin", "gdaps"]


def test_plugins_method():
    # Mock AppConfigs
    mock_app_plugin = MagicMock(spec=AppConfig)
    mock_app_plugin.PluginMeta = MagicMock()
    mock_app_plugin.PluginMeta.enabled = True
    mock_app_plugin.PluginMeta.obligatory = False

    mock_app_disabled = MagicMock(spec=AppConfig)
    mock_app_disabled.PluginMeta = MagicMock()
    mock_app_disabled.PluginMeta.enabled = False
    mock_app_disabled.PluginMeta.obligatory = False

    mock_app_regular = MagicMock(spec=AppConfig)
    del mock_app_regular.PluginMeta  # Ensure it doesn't have PluginMeta

    with patch("django.apps.apps.get_app_configs") as mock_get_app_configs:
        mock_get_app_configs.return_value = [
            mock_app_plugin,
            mock_app_disabled,
            mock_app_regular,
        ]

        # Test including disabled
        plugins = PluginManager.plugins(skip_disabled=False)
        assert mock_app_plugin in plugins
        assert mock_app_disabled in plugins
        assert mock_app_regular not in plugins
        assert len(plugins) == 2

        # Test skipping disabled
        plugins_enabled = PluginManager.plugins(skip_disabled=True)
        assert mock_app_plugin in plugins_enabled
        assert mock_app_disabled not in plugins_enabled
        assert len(plugins_enabled) == 1


def test_obligatory_plugin_cannot_be_disabled():
    """An obligatory plugin is always returned, even if PluginMeta.enabled is False."""
    mock_app = MagicMock(spec=AppConfig)
    mock_app.PluginMeta = MagicMock()
    mock_app.PluginMeta.enabled = False
    mock_app.PluginMeta.obligatory = True

    with patch("django.apps.apps.get_app_configs") as mock_get_app_configs:
        mock_get_app_configs.return_value = [mock_app]
        assert mock_app in PluginManager.plugins(skip_disabled=True)


def test_instantiate_pluginmanager():
    with pytest.raises(PluginError):
        PluginManager()


class TestDrfRouter:
    def setup_method(self):
        # Reset cached router between tests
        PluginManager._default_router = None

    def teardown_method(self):
        PluginManager._default_router = None

    def test_default_returns_simple_router(self):
        """Without DRF_BROWSEABLE_API, SimpleRouter is used."""
        from rest_framework.routers import SimpleRouter

        router = PluginManager.router()
        assert isinstance(router, SimpleRouter)

    def test_browseable_api_returns_default_router(self):
        """With DRF_BROWSEABLE_API=True, DefaultRouter (browsable API) is used."""
        from django.test import override_settings
        from rest_framework.routers import DefaultRouter

        with override_settings(GDAPS={"DRF_BROWSEABLE_API": True}):
            router = PluginManager.router()
        assert isinstance(router, DefaultRouter)

    def test_browseable_api_false_returns_simple_router(self):
        """Explicit DRF_BROWSEABLE_API=False still uses SimpleRouter."""
        from django.test import override_settings
        from rest_framework.routers import DefaultRouter, SimpleRouter

        with override_settings(GDAPS={"DRF_BROWSEABLE_API": False}):
            router = PluginManager.router()
        assert isinstance(router, SimpleRouter)
        assert not isinstance(router, DefaultRouter)
