import pytest

from gdaps.api import InterfaceMeta
from gdaps.conf import PluginSettings
from .plugins.plugin1.api.interfaces import IFirstInterface
from .plugins.plugin1.conf import IMPORT_STRINGS, NAMESPACE, plugin1_settings
from django.conf import settings


def test_simple_default_value():
    """Tests a simple settings default value"""
    assert plugin1_settings.FOO == 33


def test_override_settings():
    """Tests user overriding a default setting"""
    # default = 10, override = 20
    assert plugin1_settings.OVERRIDE == 20


def test_correct_arrayimport():
    """Tests a settings default array value"""
    assert plugin1_settings.ARRAY == [1, 2, 3]


def test_correct_stringimport():
    """Tests a settings string import functionality"""

    assert type(plugin1_settings.INTERFACE) is InterfaceMeta
    assert plugin1_settings.INTERFACE is IFirstInterface


def test_notallowed_stringimport():
    defaults = {"FOO": "tests.plugins.plugin1.api.interfaces.FirstInterface"}
    settings = PluginSettings(
        namespace=NAMESPACE, defaults=defaults, import_strings=IMPORT_STRINGS
    )

    assert type(settings.FOO) is str
    assert settings.FOO == "tests.plugins.plugin1.api.interfaces.FirstInterface"


def test_notexisting_stringimport():
    defaults = {"FOO": "tests.plugins.plugin1.Blah"}
    settings = PluginSettings(
        namespace=NAMESPACE, defaults=defaults, import_strings=("FOO")
    )

    with pytest.raises(ImportError):
        settings.FOO


def test_notexisting_setting_access():
    defaults = {"FOO": 234}
    settings = PluginSettings(
        namespace=NAMESPACE, defaults=defaults, import_strings=IMPORT_STRINGS
    )

    with pytest.raises(AttributeError):
        settings.BLAHFOO


def test_notallowed_removed_setting_access():
    defaults = {"FOO": 234}
    removed_settings = "REMOVED_SETTING"
    settings = PluginSettings(
        namespace=NAMESPACE,
        defaults=defaults,
        import_strings=IMPORT_STRINGS,
        removed_settings=removed_settings,
    )

    with pytest.raises(AttributeError):
        settings.REMOVED_SETTING


def test_gdaps_namespaced_integrated_setting():
    gdaps_settings = PluginSettings(
        namespace="GDAPS",
    )
    assert gdaps_settings.ADMIN is True


def test_PROJECT_TITLE():
    assert settings.PROJECT_NAME == "foo_bar"
    assert settings.PROJECT_TITLE == "Foo Bar"


class TestPluginSettingsReload:
    def test_reload_clears_cached_user_settings(self):
        """reload() must drop _user_settings so the next access re-reads from Django settings."""
        ps = PluginSettings(namespace="GDAPS", defaults={"ADMIN": True})
        _ = ps.user_settings  # populate cache
        assert hasattr(ps, "_user_settings")
        ps.reload(setting="GDAPS", value={"ADMIN": False})
        assert not hasattr(ps, "_user_settings")

    def test_reload_clears_cached_attribute_values(self):
        """reload() must remove values cached via setattr in __getattr__."""
        ps = PluginSettings(namespace="GDAPS", defaults={"ADMIN": True})
        _ = ps.ADMIN  # caches ADMIN on the instance
        assert "ADMIN" in ps.__dict__
        ps.reload(setting="GDAPS", value={})
        assert "ADMIN" not in ps.__dict__

    def test_reload_re_reads_new_value(self):
        """After reload() the updated value from Django settings must be returned."""
        ps = PluginSettings(namespace="GDAPS", defaults={"ADMIN": True})
        assert ps.ADMIN is True
        ps.reload(setting="GDAPS", value={"ADMIN": False})
        # Manually inject the new user settings (simulates what setting_changed provides)
        ps._user_settings = {"ADMIN": False}
        assert ps.ADMIN is False

    def test_reload_ignores_other_namespaces(self):
        """reload() must not clear state when a different namespace changes."""
        ps = PluginSettings(namespace="GDAPS", defaults={"ADMIN": True})
        _ = ps.ADMIN
        assert "ADMIN" in ps.__dict__
        ps.reload(setting="OTHER_NAMESPACE", value={})
        assert "ADMIN" in ps.__dict__

    def test_reload_works_for_plugin_specific_instance(self):
        """reload() must work on non-GDAPS instances, not just gdaps_settings."""
        ps = PluginSettings(namespace="PLUGIN1", defaults={"FOO": 33})
        _ = ps.FOO  # cache FOO
        assert "FOO" in ps.__dict__
        ps.reload(setting="PLUGIN1", value={"FOO": 99})
        assert "FOO" not in ps.__dict__

    def test_setting_changed_signal_triggers_reload(self):
        """The setting_changed signal must invoke reload() on the correct instance."""
        from django.test.signals import setting_changed

        ps = PluginSettings(namespace="GDAPS", defaults={"ADMIN": True})
        _ = ps.ADMIN  # cache
        assert "ADMIN" in ps.__dict__

        setting_changed.send(
            sender=settings.__class__,
            setting="GDAPS",
            value={"ADMIN": False},
            enter=True,
        )
        assert "ADMIN" not in ps.__dict__
