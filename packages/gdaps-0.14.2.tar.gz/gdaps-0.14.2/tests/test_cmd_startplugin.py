"""Tests for the `startplugin` management command, focused on the
overlay-cookiecutter.json -> extra_context merge behaviour.

The command itself shells out to cookiecutter; we mock that boundary and
assert which extra_context dict reaches it.
"""

import json
from pathlib import Path
from unittest import mock

import pytest

from gdaps.management.commands import startplugin


# ---------------------------------------------------------------------------
# Unit tests for the pure helper
# ---------------------------------------------------------------------------


def test_load_overlay_defaults_returns_empty_when_no_overlay(tmp_path: Path):
    """Without a .plugin_template/cookiecutter.json, return {}."""
    assert startplugin._load_overlay_defaults(tmp_path / "missing") == {}


def test_load_overlay_defaults_returns_empty_when_no_json(tmp_path: Path):
    """Overlay dir exists but no cookiecutter.json -> {}."""
    overlay = tmp_path / ".plugin_template"
    overlay.mkdir()
    assert startplugin._load_overlay_defaults(overlay) == {}


def test_load_overlay_defaults_filters_identity_and_private_keys(tmp_path: Path):
    """Identity keys (plugin/app/author) and private keys (`_*`) must be
    stripped so they cannot override the command's own extra_context."""
    overlay = tmp_path / ".plugin_template"
    overlay.mkdir()
    (overlay / "cookiecutter.json").write_text(
        json.dumps(
            {
                "project_title": "MedUX",
                "workspace_siblings": "../medux,../conjunto,../gdaps",
                "main_dependency": "medux>=0.1",
                # identity keys -- must be filtered out
                "plugin_title": "Should Be Ignored",
                "app_name": "should_be_ignored",
                "author": "Should Be Ignored",
                "author_email": "ignore@example.com",
                # private cookiecutter key -- must be filtered out
                "__camel_cased_app_name": "Computed",
                "_internal": "x",
            }
        ),
        encoding="utf-8",
    )

    defaults = startplugin._load_overlay_defaults(overlay)

    assert defaults == {
        "project_title": "MedUX",
        "workspace_siblings": "../medux,../conjunto,../gdaps",
        "main_dependency": "medux>=0.1",
    }


def test_load_overlay_defaults_handles_broken_json(tmp_path: Path, caplog):
    """A malformed cookiecutter.json must not crash startplugin."""
    overlay = tmp_path / ".plugin_template"
    overlay.mkdir()
    (overlay / "cookiecutter.json").write_text("{not json", encoding="utf-8")

    with caplog.at_level("WARNING"):
        result = startplugin._load_overlay_defaults(overlay)

    assert result == {}
    assert any("overlay cookiecutter.json" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Integration: Command.handle merges overlay defaults into extra_context
# ---------------------------------------------------------------------------


@pytest.fixture
def fake_settings(tmp_path, monkeypatch):
    """Re-point Django settings so .plugin_template is discoverable
    relative to a tmp src/-style project layout."""
    project_root = tmp_path / "myproject"
    src_dir = project_root / "src"
    src_dir.mkdir(parents=True)

    monkeypatch.setattr(startplugin.settings, "BASE_DIR", src_dir, raising=False)
    monkeypatch.setattr(
        startplugin.settings, "PROJECT_NAME", "myproject", raising=False
    )
    monkeypatch.setattr(
        startplugin.settings, "PROJECT_TITLE", "MyProject", raising=False
    )
    return project_root


def _patched_cookiecutter():
    """Return a MagicMock that mimics cookiecutter.main.cookiecutter,
    returning a path string (first positional / output_dir based)."""
    return mock.MagicMock(return_value="/tmp/generated_plugin")


def test_handle_with_overlay_merges_defaults_into_extra_context(
    fake_settings, monkeypatch
):
    """When an overlay exists, its non-identity defaults reach the main
    cookiecutter call via extra_context."""
    overlay = fake_settings / ".plugin_template"
    overlay.mkdir()
    (overlay / "cookiecutter.json").write_text(
        json.dumps(
            {
                "project_title": "MedUX",
                "workspace_siblings": "../medux,../conjunto,../gdaps",
                "main_dependency": "medux>=0.1",
                "vendor": "nerdocs",
            }
        ),
        encoding="utf-8",
    )
    # overlay needs at least the cookiecutter root dir so the second call
    # (overlay render) finds something to render -- a minimal stub suffices,
    # since cookiecutter is mocked.
    (overlay / "{{cookiecutter.package_name}}").mkdir()

    fake_cc = _patched_cookiecutter()
    fake_module = mock.MagicMock()
    fake_module.cookiecutter = fake_cc
    monkeypatch.setitem(__import__("sys").modules, "cookiecutter.main", fake_module)
    monkeypatch.setitem(__import__("sys").modules, "cookiecutter", mock.MagicMock())

    cmd = startplugin.Command()
    cmd.handle(name="my_plugin")

    # First call = main cookiecutter run
    main_call = fake_cc.call_args_list[0]
    extra_context = main_call.kwargs["extra_context"]

    # overlay defaults flowed in
    assert extra_context["workspace_siblings"] == "../medux,../conjunto,../gdaps"
    assert extra_context["main_dependency"] == "medux>=0.1"
    assert extra_context["vendor"] == "nerdocs"
    # identity / CLI-derived values still take precedence
    assert extra_context["project_slug"] == "myproject"
    assert extra_context["project_title"] == "MyProject"  # NOT overlay's "MedUX"
    assert extra_context["app_name"] == "my_plugin"


def test_handle_without_overlay_keeps_legacy_extra_context(fake_settings, monkeypatch):
    """No overlay -> only the original extra_context is forwarded
    (gdaps-only path stays intact)."""
    fake_cc = _patched_cookiecutter()
    fake_module = mock.MagicMock()
    fake_module.cookiecutter = fake_cc
    monkeypatch.setitem(__import__("sys").modules, "cookiecutter.main", fake_module)
    monkeypatch.setitem(__import__("sys").modules, "cookiecutter", mock.MagicMock())

    cmd = startplugin.Command()
    cmd.handle(name="my_plugin")

    assert fake_cc.call_count == 1  # no overlay -> only main run
    extra_context = fake_cc.call_args.kwargs["extra_context"]
    assert set(extra_context.keys()) == {
        "project_slug",
        "project_title",
        "plugin_title",
        "app_name",
        "author",
        "author_email",
    }
    assert "workspace_siblings" not in extra_context
    assert "main_dependency" not in extra_context


def test_handle_command_extra_context_wins_over_overlay(fake_settings, monkeypatch):
    """If the overlay tries to override an identity / CLI-derived key
    (e.g. project_title), the command's own value must win."""
    overlay = fake_settings / ".plugin_template"
    overlay.mkdir()
    (overlay / "cookiecutter.json").write_text(
        json.dumps(
            {
                "project_title": "OverlayClaimsThis",
                "main_dependency": "overlay_only>=1.0",
            }
        ),
        encoding="utf-8",
    )
    (overlay / "{{cookiecutter.package_name}}").mkdir()

    fake_cc = _patched_cookiecutter()
    fake_module = mock.MagicMock()
    fake_module.cookiecutter = fake_cc
    monkeypatch.setitem(__import__("sys").modules, "cookiecutter.main", fake_module)
    monkeypatch.setitem(__import__("sys").modules, "cookiecutter", mock.MagicMock())

    cmd = startplugin.Command()
    cmd.handle(name="my_plugin")

    extra_context = fake_cc.call_args_list[0].kwargs["extra_context"]
    # CLI/identity wins
    assert extra_context["project_title"] == "MyProject"
    # overlay-only key still merged
    assert extra_context["main_dependency"] == "overlay_only>=1.0"
