from django.contrib import admin
from django.http import HttpRequest

from gdaps.conf import gdaps_settings
from gdaps.models import GdapsPlugin


class ReadOnlyAdmin(admin.ModelAdmin):
    """This is a ModelAdmin class that sets the whole GDAPS model readonly."""

    def get_readonly_fields(
        self, request: HttpRequest, obj: admin.ModelAdmin | None = None
    ) -> list[str]:
        if obj is None:
            return []
        return [f.name for f in obj._meta.fields]

    def has_delete_permission(
        self, request: HttpRequest, obj: admin.ModelAdmin | None = None
    ) -> bool:
        return False

    def has_add_permission(self, request: HttpRequest) -> bool:
        return False


class GdapsInline(admin.TabularInline):
    pass


class GdapsAdmin(ReadOnlyAdmin):
    """ModelAdmin class for GDAPS plugins."""

    list_display: list[str] = [
        "verbose_name",
        "version",
        "author",
        "hidden",
        "enabled",
        "obligatory",
        "category",
    ]
    sortable_by: list[str] = ["category", "hidden", "enabled", "obligatory"]

    def get_readonly_fields(
        self, request: HttpRequest, obj: admin.ModelAdmin | None = None
    ) -> list[str]:
        editable = {"enabled", "hidden"}
        # obligatory plugins cannot be disabled via admin
        if obj is not None and getattr(obj, "obligatory", False):
            editable.discard("enabled")
        return [
            name
            for name in super().get_readonly_fields(request, obj)
            if name not in editable
        ]


def register_admin():
    """Register admin classes if GDAPS ADMIN setting is enabled.

    Call this from AppConfig.ready() to defer evaluation of settings.
    Disable by setting GDAPS["ADMIN"] = False in settings.py.
    """
    if gdaps_settings.ADMIN:
        admin.site.register(GdapsPlugin, GdapsAdmin)
