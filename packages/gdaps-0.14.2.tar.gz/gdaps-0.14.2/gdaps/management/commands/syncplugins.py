import logging

from django.core.management.base import BaseCommand

from gdaps.tools import sync_plugins

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    """Management command wrapper around :func:`gdaps.tools.sync_plugins`.

    It parses all installed plugins, and creates shadowed meta data in the
    database as ``GdapsPlugin`` objects. If there is an object in the DB
    which was deleted on disk, it removes the DB object too.
    """

    help = "Synchronizes all installed plugins into the database."

    def add_arguments(self, parser):
        parser.add_argument(
            "--database",
            nargs="?",
            type=str,
            help="synchronizes only plugins from specific database",
        )

    def handle(self, *args, **options) -> None:
        sync_plugins(database=options.get("database") or "default")
