import json
import logging

from pathlib import Path
from django.conf import settings
from django.core.management.base import CommandError, BaseCommand


logger = logging.getLogger(__name__)

try:
    # if git is available, make use of git username/email config data
    import git

    reader = git.Repo.init(settings.BASE_DIR).config_reader()
except ImportError:
    reader = None
    logger.info(
        "Could not import git. Please install the 'gitpython' package, and set author/email data in your ~/.gitconfig if you want to determine author/email automatically."
    )
except git.exc.GitCommandNotFound:
    reader = None
    logger.info("git is not installed. Please install it to use git bindings in python")


def get_user_data(key, default=""):
    if reader:
        return reader.get_value("user", key, default)
    else:
        return ""


# Keys that the host project may pin via its overlay cookiecutter.json.
# These are user-non-overridable defaults: they describe the host project
# (e.g. workspace_siblings, main_dependency, project_title) and must be
# merged into the main cookiecutter run so that the generated pyproject.toml
# matches the host project, not the bare gdaps defaults.
# Identity-shaped keys (plugin/app/author) stay under control of the
# command's own extra_context (CLI flags / git config) and are never taken
# from the overlay.
_IDENTITY_KEYS = frozenset(
    {
        "plugin_title",
        "app_name",
        "author",
        "author_email",
        # Internal cookiecutter keys (start with "_") and template-derived
        # slugs are skipped explicitly to avoid leaking computed values.
    }
)


def _load_overlay_defaults(overlay_dir: Path) -> dict:
    """Return non-identity, non-private defaults from an overlay cookiecutter.json.

    Returns an empty dict if the overlay or its cookiecutter.json is missing
    or unreadable. Private keys (leading underscore) and identity keys
    (plugin/app/author) are filtered out so they never override the
    command's own extra_context.
    """
    cc_json = overlay_dir / "cookiecutter.json"
    if not cc_json.is_file():
        return {}
    try:
        data = json.loads(cc_json.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning(f"Could not read overlay cookiecutter.json: {exc}")
        return {}
    return {
        k: v
        for k, v in data.items()
        if not k.startswith("_") and k not in _IDENTITY_KEYS
    }


class Command(BaseCommand):
    """Management command to create a GDAPS plugin from a cookiecutter template."""

    plugin_path = Path.cwd()
    help = (
        "Creates a GDAPS plugin from a cookiecutter template in the current "
        "working directory.\n\n"
        "If a .plugin_template/ directory exists in the project root, its "
        "contents are rendered with the same context and overlaid on top of "
        "the generated plugin (project-specific overrides)."
    )
    missing_args_message = "You must provide a plugin name."

    def add_arguments(self, parser):
        parser.add_argument("name")

    def handle(self, name: str, **options):
        try:
            from cookiecutter.main import cookiecutter
        except ImportError:
            raise CommandError(
                "You have to install cookiecutter to make this command work."
            )

        if not name.isidentifier():
            raise CommandError(
                "The <name> parameter has to be a valid Python identifier."
            )

        logger.debug(f"Using plugin directory: {self.plugin_path}")

        # Identity / CLI-derived context. These values always win over
        # whatever the overlay cookiecutter.json declares.
        extra_context = {
            "project_slug": settings.PROJECT_NAME,
            "project_title": settings.PROJECT_TITLE,
            "plugin_title": name.replace("_", " ").capitalize(),
            "app_name": name,
            "author": get_user_data("name"),
            "author_email": get_user_data("email"),
        }

        # Merge host-project defaults (workspace_siblings, main_dependency,
        # custom project_title, ...) from the overlay's cookiecutter.json
        # into the main cookiecutter run, so the generated plugin matches
        # the host project instead of the bare gdaps defaults.
        # GDAPS assumes a src-based layout where BASE_DIR points to src/
        # and the project root is BASE_DIR.parent.
        overlay_dir = settings.BASE_DIR.parent / ".plugin_template"
        overlay_defaults = _load_overlay_defaults(overlay_dir)
        if overlay_defaults:
            # extra_context (CLI/identity) wins; overlay only fills in keys
            # the command did not already set.
            merged_context = {**overlay_defaults, **extra_context}
        else:
            merged_context = extra_context

        try:
            target_path = Path(
                cookiecutter(
                    "gl:nerdocs/gdaps-plugin-cookiecutter",
                    extra_context=merged_context,
                    output_dir=self.plugin_path,
                    no_input=True,
                )
            )

            # Apply the overlay template files on top of the generated plugin.
            if overlay_dir.is_dir():
                logger.info(f"Applying project overlay from {overlay_dir}")
                cookiecutter(
                    str(overlay_dir),
                    extra_context=merged_context,
                    output_dir=self.plugin_path,
                    no_input=True,
                    overwrite_if_exists=True,
                )

            package_name = f"{settings.PROJECT_NAME}-{name}"
            logger.info(
                f"\nSuccessfully created plugin: {target_path}\n"
                f"* Please edit '{target_path / 'pyproject.toml'}' to your needs.\n"
                f"* Install the plugin locally using 'uv add -e {self.plugin_path / package_name}'\n"
                f"  Or you can add the plugin directly to your INSTALLED_APPS if you want it bundled with your application.\n"
                f"* Don't forget to call 'manage.py syncplugins' after installing a new plugin to keep "
                f"your DB in sync.\n"
            )
        except Exception as e:
            logger.critical(f"There was an error with cookiecutter: \n {e}")
