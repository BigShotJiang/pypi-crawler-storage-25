import base64
import datetime
import fnmatch
import hashlib
import json
import os

from django.core.management.base import BaseCommand, CommandError

from gdaps.signing import EXCLUDE_PATTERNS, MANIFEST_FILENAME


class Command(BaseCommand):
    """Sign a GDAPS plugin with code integrity verification.

    This command scans all files in a plugin directory, generates SHA-256 hashes,
    creates a manifest, and signs it with an Ed25519 private key.
    The resulting MANIFEST.SIG file enables verification at load time.
    """

    help = "Sign a GDAPS plugin with code integrity manifest"

    def add_arguments(self, parser):
        parser.add_argument(
            "plugin_path",
            type=str,
            help="Path to the plugin directory to sign",
        )
        parser.add_argument(
            "--private-key",
            type=str,
            help="Path to the Ed25519 private key file (PEM/SSH format)",
        )
        parser.add_argument(
            "--key-env",
            type=str,
            metavar="ENV_VAR",
            help="Name of environment variable containing the base64-encoded private key (alternative to --private-key)",
        )
        parser.add_argument(
            "--exclude",
            type=str,
            nargs="*",
            help="Additional patterns to exclude",
        )
        parser.add_argument(
            "--passphrase",
            type=str,
            default=None,
            help="Passphrase to decrypt the private key file (if encrypted)",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Overwrite existing MANIFEST.SIG",
        )

    def handle(self, *args, **options):
        plugin_path = os.path.abspath(options["plugin_path"])

        if not os.path.isdir(plugin_path):
            raise CommandError(f"Plugin path does not exist: {plugin_path}")

        if not options.get("private_key") and not options.get("key_env"):
            raise CommandError("Either --private-key or --key-env is required")

        private_key = self._load_private_key(options)

        exclude_patterns = EXCLUDE_PATTERNS.copy()
        if options.get("exclude"):
            exclude_patterns.update(options["exclude"])

        manifest_path = os.path.join(plugin_path, MANIFEST_FILENAME)
        if os.path.exists(manifest_path) and not options.get("force"):
            raise CommandError(
                f"Manifest already exists: {manifest_path}. Use --force to overwrite."
            )

        files = self._collect_files(plugin_path, exclude_patterns)

        self.stdout.write(f"Found {len(files)} files to sign in {plugin_path}")

        hashes = {}
        for file_path in files:
            relative_path = os.path.relpath(file_path, plugin_path)
            with open(file_path, "rb") as f:
                content = f.read()
                hash_value = hashlib.sha256(content).hexdigest()
                hashes[relative_path] = hash_value

        manifest = {
            "version": "1.0",
            "plugin_name": os.path.basename(plugin_path),
            "signed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "files": hashes,
        }

        manifest_json = json.dumps(manifest, sort_keys=True)


        signature = private_key.sign(manifest_json.encode())
        signature_b64 = base64.b64encode(signature).decode("ascii")

        signed_manifest = {
            "manifest": manifest,
            "signature": signature_b64,
        }

        with open(manifest_path, "w") as f:
            json.dump(signed_manifest, f, sort_keys=True, indent=2)

        self.stdout.write(self.style.SUCCESS("Plugin signed successfully!"))
        self.stdout.write(f"  Manifest: {manifest_path}")
        self.stdout.write(f"  Files signed: {len(files)}")

    def _load_private_key(self, options):
        try:
            from cryptography.hazmat.primitives.asymmetric import ed25519
            from cryptography.hazmat.primitives import serialization
        except ImportError:
            raise CommandError(
                "cryptography package not installed. Install with: pip install cryptography"
            )

        if options.get("key_env"):
            env_var = options["key_env"]
            key_b64 = os.environ.get(env_var)
            if not key_b64:
                raise CommandError(
                    f"Environment variable '{env_var}' is not set or empty"
                )
            key_data = base64.b64decode(key_b64)
            passphrase = options.get("passphrase")
            password = passphrase.encode() if passphrase else None
            private_key = serialization.load_pem_private_key(key_data, password=password)
            if not isinstance(private_key, ed25519.Ed25519PrivateKey):
                raise CommandError("Key must be Ed25519")
            return private_key

        key_path = os.path.abspath(options["private_key"])
        if not os.path.exists(key_path):
            raise CommandError(f"Private key file not found: {key_path}")

        with open(key_path, "rb") as f:
            key_data = f.read()

        passphrase = options.get("passphrase")
        password = passphrase.encode() if passphrase else None
        private_key = serialization.load_ssh_private_key(key_data, password=password)
        if not isinstance(private_key, ed25519.Ed25519PrivateKey):
            raise CommandError("Key must be Ed25519")

        return private_key

    def _collect_files(self, root_dir, exclude_patterns):
        files = []

        for dirpath, dirnames, filenames in os.walk(root_dir):
            dirnames[:] = [
                d for d in dirnames if not self._should_exclude(d, exclude_patterns)
            ]

            for filename in filenames:
                file_path = os.path.join(dirpath, filename)
                relative = os.path.relpath(file_path, root_dir)

                if relative == MANIFEST_FILENAME:
                    continue
                if self._should_exclude(filename, exclude_patterns):
                    continue

                files.append(file_path)

        return files

    def _should_exclude(self, name, exclude_patterns=None):
        patterns = exclude_patterns if exclude_patterns is not None else EXCLUDE_PATTERNS
        return any(fnmatch.fnmatch(name, pattern) for pattern in patterns)
