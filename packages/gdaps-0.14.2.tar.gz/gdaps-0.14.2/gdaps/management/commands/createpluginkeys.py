import os

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    """Generate Ed25519 keypair for plugin signing.

    This creates a private and public key that can be used to sign GDAPS plugins.
    The public key should be stored in Django settings as GDAPS["PLUGIN_SIGNING_PUBKEY"].
    The private key must be kept secret and used with the 'signplugin' command.
    """

    help = "Generate Ed25519 keypair for signing GDAPS plugins"

    def add_arguments(self, parser):
        parser.add_argument(
            "--output",
            type=str,
            default=".",
            help="Directory to save the key files (default: current directory)",
        )
        parser.add_argument(
            "--prefix",
            type=str,
            default="gdaps_plugin",
            help="Prefix for key filenames (default: gdaps_plugin)",
        )
        parser.add_argument(
            "--passphrase",
            type=str,
            default=None,
            help="Passphrase to encrypt the private key (recommended for production)",
        )

    def handle(self, *args, **options):
        try:
            from cryptography.hazmat.primitives.asymmetric import ed25519
            from cryptography.hazmat.primitives import serialization
        except ImportError:
            self.stderr.write(
                "Error: cryptography package not installed. Install with: pip install cryptography"
            )
            return

        output_dir = os.path.abspath(options["output"])
        prefix = options.get("prefix", "gdaps_plugin")

        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        private_key = ed25519.Ed25519PrivateKey.generate()

        passphrase = options.get("passphrase")
        if passphrase:
            encryption = serialization.BestAvailableEncryption(passphrase.encode())
        else:
            self.stderr.write(self.style.WARNING(
                "Warning: generating unencrypted private key. "
                "Use --passphrase for production use."
            ))
            encryption = serialization.NoEncryption()

        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.OpenSSH,
            encryption_algorithm=encryption,
        )

        public_key = private_key.public_key()
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.OpenSSH,
            format=serialization.PublicFormat.OpenSSH,
        )

        private_path = os.path.join(output_dir, f"{prefix}.key")
        public_path = os.path.join(output_dir, f"{prefix}.pub")

        with open(private_path, "wb") as f:
            f.write(private_pem)
        os.chmod(private_path, 0o600)

        with open(public_path, "wb") as f:
            f.write(public_pem)

        self.stdout.write(self.style.SUCCESS("Keys generated successfully!"))
        self.stdout.write(f"  Private key: {private_path}")
        self.stdout.write(f"  Public key:  {public_path}")
        self.stdout.write("")
        self.stdout.write("Add this to your Django settings:")
        self.stdout.write('  GDAPS = {')
        self.stdout.write(f'      "PLUGIN_SIGNING_PUBKEY": "{public_pem.decode().strip()}",')
        self.stdout.write('  }')
        self.stdout.write("")
        self.stdout.write(self.style.WARNING("Keep the private key secret!"))
