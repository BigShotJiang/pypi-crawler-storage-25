from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("gdaps", "0009_alter_gdapsplugin_id"),
    ]

    operations = [
        migrations.RenameField(
            model_name="gdapsplugin",
            old_name="compatibility",
            new_name="requires",
        ),
    ]
