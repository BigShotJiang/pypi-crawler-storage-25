"""Reusable helpers for GDAPS.

This module exposes functions that are also wrapped by management
commands, so callers can run the same routines directly from Django
code (e.g. from an ``AppConfig.ready()``, a deployment hook, or a
test) without going through ``call_command``.
"""

import logging

from django.apps import AppConfig
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured, ObjectDoesNotExist
from django.db import connections
from django.db.migrations.executor import MigrationExecutor
from django.utils.translation import gettext_lazy as _
from semantic_version import Version

from gdaps.exceptions import PluginError
from gdaps.models import GdapsPlugin
from gdaps.pluginmanager import PluginManager

logger = logging.getLogger(__name__)


def _is_database_synchronized(database: str) -> bool:
    """Return True if all migrations have been applied on ``database``."""
    connection = connections[database]
    connection.prepare_database()
    executor = MigrationExecutor(connection)
    targets = executor.loader.graph.leaf_nodes()
    return not executor.migration_plan(targets)


def _copy_plugin_to_db(app: AppConfig, db_plugin: GdapsPlugin) -> None:
    meta = app.PluginMeta
    db_plugin.name = app.name
    db_plugin.verbose_name = getattr(
        meta, "verbose_name", app.name.replace("_", " ").capitalize()
    )
    db_plugin.author = getattr(meta, "author", _("unknown"))
    db_plugin.author_email = getattr(meta, "author_email", "")
    db_plugin.vendor = getattr(meta, "vendor", "")
    db_plugin.category = getattr(meta, "category", _("Miscellaneous"))
    db_plugin.description = getattr(meta, "description", "")
    db_plugin.hidden = getattr(meta, "hidden", False)
    if getattr(meta, "obligatory", False):
        # obligatory plugins cannot be disabled
        db_plugin.enabled = True
    db_plugin.version = app.PluginMeta.version
    db_plugin.requires = getattr(meta, "requires", "")

    db_plugin.save()


def sync_plugins(database: str = "default") -> None:
    """Synchronize all installed plugins into the database.

    Parses all plugins found by :class:`PluginManager`, mirrors their
    ``PluginMeta`` into :class:`GdapsPlugin` rows, runs ``install()`` on
    newly discovered plugins, and removes orphaned rows whose code is no
    longer on disk.

    This is the same routine invoked by the ``syncplugins`` management
    command. Call it from Django code when you need to re-sync plugin
    metadata without shelling out to ``call_command``.
    """
    logger.info(" ⌛ Searching for plugins...")
    for app in PluginManager.plugins():
        logger.info(f"   ➤ {app.name} ({app.PluginMeta.version})")

        try:
            db_plugin = GdapsPlugin.objects.get(name=app.name)

            file_version = app.PluginMeta.version
            if Version(file_version) > Version(db_plugin.version):
                # there is a newer version available on disk

                # TODO: check PluginMeta.requires here

                logger.warning(
                    f"     There is a newer version of the '{app.verbose_name}' plugin available."
                )

                for db in settings.DATABASES.keys():
                    if not _is_database_synchronized(db):
                        raise PluginError(
                            "Plugin version upgrade detected. Please run the 'migrate' management "
                            "command first to update plugins."
                        )

            # Copy metadata to DB in any case, as other things as version could have changed too.
            _copy_plugin_to_db(app, db_plugin)

            # TODO: run upgrade procedure of plugin

        except ObjectDoesNotExist:
            logger.info(f"     Plugin '{app.verbose_name}' is new, syncing to DB.")
            db_plugin = GdapsPlugin()
            version = None
            try:
                version = app.PluginMeta.version
                Version(version)
                db_plugin.version = version
            except ValueError:
                raise ImproperlyConfigured(
                    f"Plugin '{app.name}' version number is incorrect: '{version}'"
                )
            _copy_plugin_to_db(app, db_plugin)

            # TODO: add requires check

            if hasattr(app.PluginMeta, "install"):
                try:
                    app.PluginMeta.install()
                except Exception:
                    raise PluginError(
                        f"Error calling install() method of '{app.name}' plugin"
                    )

    logger.info(" ⌛ Searching for orphaned plugins in database...")
    for plugin in PluginManager.orphaned_plugins():
        if _is_database_synchronized(database):
            plugin.delete()
            logger.info(f"   ➤ {plugin.name} removed from database.")
        else:
            logger.info(f"   ➤ {plugin.name}")
