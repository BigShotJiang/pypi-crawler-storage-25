import importlib
import logging
import os
import typing
from types import ModuleType
from typing import List, Union

from django.apps import apps, AppConfig
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.db.models import QuerySet
from django.urls import include, path
from django.utils.module_loading import module_has_submodule
import importlib.metadata

from gdaps.api import PluginConfig
from gdaps.exceptions import PluginError
from gdaps.signing import (
    verify_plugin_signature,
    SignatureVerificationError,
    PluginNotSignedError,
    PluginSignatureInvalidError,
    PluginCodeTamperedError,
)

if typing.TYPE_CHECKING:
    try:
        from rest_framework.routers import DefaultRouter, SimpleRouter
    except ImportError:
        pass

__all__ = ["PluginManager"]

logger = logging.getLogger(__name__)


def _get_module_path_from_entry_point(entry_point) -> str | None:
    """Get the filesystem path of a module from its entry point."""
    try:
        import importlib.util

        spec = importlib.util.find_spec(
            entry_point.value.split(":")[0]
            if ":" in entry_point.value
            else entry_point.value
        )
        if spec and spec.submodule_search_locations:
            return spec.submodule_search_locations[0]
    except Exception:
        pass
    return None


# with Python 3.7 we could use this instead of a plugin_spec dict:
#
# @dataclass
# class PluginSpec:
#     name: str
#     app_name: str
#     verbose_name: str
#     description: str
#     vendor: str
#     version: semver.VersionInfo
#     core_compat_version: semver.VersionInfo
#     author: str
#     author_email: str
#     category: str = "Misc"
#     enabled: bool = True
#     dependencies: list = ['core']


# class Singleton(type):
#     """A Metaclass implementing the Singleton pattern.
#
#     This class is for internal use only
#     """
#
#     _instances = {}
#
#     def __call__(cls, *args, **kwargs):
#         if cls not in cls._instances:
#             cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
#         return cls._instances[cls]


class PluginManager:
    """A Generic Django Plugin Manager that finds Django app plugins in a
    plugins folder or setuptools entry points and loads them dynamically.
    It provides a couple of methods to interact with plugins, load submodules of all available plugins
    dynamically, or get a list of enabled plugins.
    Don't instantiate a ``PluginManager`` directly, just use its static and class methods directly.
    """

    group: str = ""
    _default_router = None
    _searched_for_hooks: bool = False

    def __init__(self):
        raise PluginError(
            "PluginManager is not meant to be instantiated. Please use "
            "the class methods."
        )

    @classmethod
    def plugin_path(cls) -> str:
        """Returns the absolute path where application plugins live.

        This is basically the Django root + the dotted entry point.
        CAVE: this is not callable from within the settings.py file.
        """
        if not cls.group:
            raise ImproperlyConfigured(
                "Plugin path could not be determined. Please run PluginManager.alter_installed_plugins() in your settings.py first."
            )
        return str(os.path.join(settings.BASE_DIR, *cls.group.split(".")))

    @classmethod
    def _iter_plugin_modules(cls, group: str):
        """Yield ``(entry_point, module)`` pairs for the given entry-point group.

        Honours ``ENFORCE_PLUGIN_NAMESPACE`` and runs signature verification
        with the same policy as :meth:`alter_installed_apps`. Plugins that
        fail any of these checks are skipped (or raise, depending on
        ``REQUIRE_SIGNED_PLUGINS``).

        This is the shared building block for ``alter_*`` settings hooks.
        """
        from gdaps.conf import gdaps_settings

        for entry_point in importlib.metadata.entry_points(group=group):
            if gdaps_settings.ENFORCE_PLUGIN_NAMESPACE:
                namespace = group.split(".")[0]
                dist_name = entry_point.dist.name
                normalized = dist_name.replace("-", "_").lower()
                if not normalized.startswith(namespace.lower()):
                    logger.warning(
                        f"Plugin '{dist_name}' skipped: package name does not match "
                        f"expected namespace '{namespace}*' for group '{group}'. "
                        f"Set GDAPS['ENFORCE_PLUGIN_NAMESPACE'] = False to disable this check."
                    )
                    continue

            if ":" in entry_point.value:
                module_name = entry_point.value.split(":", 1)[0]
            else:
                module_name = entry_point.value

            try:
                module_path = _get_module_path_from_entry_point(entry_point)
                if module_path:
                    verify_plugin_signature(module_name, module_path)
            except PluginNotSignedError as e:
                logger.info(f"Plugin '{entry_point.name}' skipped: not signed")
                if gdaps_settings.REQUIRE_SIGNED_PLUGINS:
                    raise PluginError(f"Plugin '{entry_point.name}' rejected: {e}")
                continue
            except PluginSignatureInvalidError as e:
                logger.warning(f"Plugin '{entry_point.name}' signature invalid: {e}")
                if gdaps_settings.REQUIRE_SIGNED_PLUGINS:
                    raise PluginError(f"Plugin '{entry_point.name}' rejected: {e}")
                continue
            except PluginCodeTamperedError as e:
                logger.error(f"Plugin '{entry_point.name}' code tampered: {e}")
                if gdaps_settings.REQUIRE_SIGNED_PLUGINS:
                    raise PluginError(f"Plugin '{entry_point.name}' rejected: {e}")
                continue
            except SignatureVerificationError as e:
                logger.error(f"Plugin '{entry_point.name}' signature error: {e}")
                if gdaps_settings.REQUIRE_SIGNED_PLUGINS:
                    raise PluginError(f"Plugin '{entry_point.name}' rejected: {e}")
                continue

            module = importlib.import_module(module_name)
            yield entry_point, module

    @classmethod
    def alter_installed_apps(cls, installed_apps: list[str], group: str) -> list[str]:
        """Lets plugins update INSTALLED_APPS and add their own apps to it,
        in arbitrary order.

        This uses the Python entry point mechanism.
        Call this method directly after your settings.INSTALLED_APPS declaration.
        """
        if not group:
            raise PluginError(
                "You have to specify an entry points group "
                "where GDAPS can look for plugins."
            )

        cls.group = group

        for entry_point, module in cls._iter_plugin_modules(group):
            if hasattr(module, "alter_installed_apps") and callable(
                module.alter_installed_apps
            ):
                module.alter_installed_apps(installed_apps)
                logger.info(f"Plugin '{entry_point.name}' updated INSTALLED_APPS.")
        return installed_apps

    @classmethod
    def alter_middleware(cls, middleware: list[str]) -> list[str]:
        """Lets plugins update Django's MIDDLEWARE setting.

        Each plugin module may define a top-level
        ``alter_middleware(middleware)`` function that mutates the list in
        place. Plugins control the insertion order themselves, typically via
        the :func:`gdaps.middleware.insert_after` /
        :func:`gdaps.middleware.insert_before` helpers.

        Call this method directly after your settings.MIDDLEWARE declaration,
        and *after* :meth:`alter_installed_apps` (which sets ``cls.group``).

        Args:
            middleware: The MIDDLEWARE list to mutate.

        Returns:
            The same list, after all plugin hooks ran.

        Raises:
            ImproperlyConfigured: If :meth:`alter_installed_apps` has not
                been called yet (no plugin entry-point group is known).
        """
        if not cls.group:
            raise ImproperlyConfigured(
                "Call PluginManager.alter_installed_apps() before "
                "alter_middleware() — the plugin entry-point group must be "
                "known before MIDDLEWARE can be mutated."
            )

        for entry_point, module in cls._iter_plugin_modules(cls.group):
            if hasattr(module, "alter_middleware") and callable(
                module.alter_middleware
            ):
                module.alter_middleware(middleware)
                logger.info(f"Plugin '{entry_point.name}' updated MIDDLEWARE.")
        return middleware

    @staticmethod
    def plugins(skip_disabled: bool = False) -> List[PluginConfig]:
        """Returns a list of AppConfig classes that are GDAPS plugins.

        This method basically checks for the presence of a ``PluginMeta`` attribute
        within the AppConfig of all apps and returns a list of apps containing it.
        :param skip_disabled: If True, skips disabled plugins and only returns enabled ones. Defaults to ``False``.
        """

        plugins_list = []
        for app in apps.get_app_configs():
            if not hasattr(app, "PluginMeta"):
                continue
            if app.PluginMeta is None:
                continue
            if skip_disabled:
                # obligatory plugins are always enabled, regardless of PluginMeta.enabled
                if getattr(app.PluginMeta, "obligatory", False):
                    plugins_list.append(app)
                    continue
                # skip disabled plugins per default
                enabled = getattr(app.PluginMeta, "enabled", True)
                if isinstance(enabled, str):
                    enabled = enabled.lower() not in ("false", "0", "no", "off")
                if not enabled:
                    continue
            plugins_list.append(app)

        return plugins_list

    @staticmethod
    def load_app_submodules(submodule_name: str) -> list[AppConfig]:
        """
        Searches each app (not plugin!) for the given submodule and yields them.

        Args:
            submodule_name: Name of the submodule to search for in each app
        Returns:
            A list of AppConfigs of successfully imported submodules
        """
        configs = []
        for app_config in apps.get_app_configs():
            if module_has_submodule(app_config.module, submodule_name):
                importlib.import_module(f"{app_config.name}.{submodule_name}")
                configs.append(app_config)
        return configs

    @classmethod
    def load_plugin_submodules(
        cls, submodule_name: str, mandatory=False
    ) -> list[ModuleType]:
        """
        Search plugin apps for specific submodules and load them.

        Parameters:
            submodule_name: the dotted name of the Django app's submodule to
                import. This package must be a submodule of the
                plugin's namespace, e.g. "schema" - then
                ["<main>.core.schema", "<main>.laboratory.schema"] etc. will be
                found and imported.
            mandatory: If set to True, each found plugin _must_ contain the given
                submodule. If any installed plugin doesn't have it, a PluginError
                is raised.
        Returns:
            A list of successfully imported submodules
        """
        modules = []
        importlib.invalidate_caches()
        for app in PluginManager.plugins():
            # import all the submodules from all plugin apps
            dotted_name = f"{app.name}.{submodule_name}"
            if module_has_submodule(app.module, submodule_name):
                logger.info(f" ✓ Loading plugin submodule {dotted_name}...")
                try:
                    module = importlib.import_module(dotted_name)
                    modules.append(module)
                except ImportError as e:
                    # the importing has another reason, like syntax errors in that module, etc.
                    logger.error(f" ✘ Error importing submodule '{dotted_name}': {e}")
            elif mandatory:
                raise PluginError(
                    f"The '{app.name}' app does not contain a (mandatory) '"
                    f"{submodule_name}' module."
                )
        return modules

    @classmethod
    def find_hooks(cls):
        if not cls._searched_for_hooks:
            cls.load_app_submodules("gdaps_hooks")
            cls._searched_for_hooks = True

    @classmethod
    def router(cls) -> Union["SimpleRouter", "DefaultRouter"]:
        """Loads all plugins' urls.py and collects their routers into one.

        :returns: a list of routers that can be merged with the global router."""

        try:
            from rest_framework.routers import DefaultRouter, SimpleRouter
        except ImportError:
            return []

        module_list = PluginManager.load_plugin_submodules("urls")

        if not cls._default_router:
            from gdaps.conf import gdaps_settings

            if gdaps_settings.DRF_BROWSEABLE_API:
                cls._default_router = DefaultRouter()
            else:
                cls._default_router = SimpleRouter()

            for module in module_list:
                router: SimpleRouter | None = getattr(module, "router", None)
                if router:
                    logger.info(
                        f" ✓ Extended global router table with router from module '{module.__name__}'."
                    )
                    cls._default_router.registry.extend(router.registry)

        return cls._default_router

    @staticmethod
    def urlpatterns() -> list:
        """Loads all plugins' urls.py and collects their urlpatterns.

        This is maybe not the best approach, but it allows plugins to
        have "global" URLs, and not only namespaced, and it is flexible

        :returns: a list of urlpatterns that can be merged with the global
                  urls.urlpattern."""

        # URL order follows INSTALLED_APPS order, which plugins control via alter_installed_apps().
        # If two plugins share a namespace, the one earlier in INSTALLED_APPS takes precedence
        # and a warning is logged so the developer is aware of the collision.

        modules = PluginManager.load_plugin_submodules("urls")

        urlpatterns = []
        seen_namespaces = {}
        for module in modules:
            if module.__name__.startswith("gdaps"):
                continue

            root_urlpatterns = getattr(module, "root_urlpatterns", None)
            if root_urlpatterns:
                logger.info(
                    f" ✓ Added urlpatterns from module '{module.__name__}' to "
                    f"global list."
                )
                urlpatterns += root_urlpatterns

            namespace = getattr(module, "app_name", None)
            if not namespace:
                raise ImproperlyConfigured(
                    f"'{module.__name__}' does not define an 'app_name'. "
                    f"This is mandatory for GDAPS plugins."
                )
            if namespace in seen_namespaces:
                logger.warning(
                    f"URL namespace '{namespace}' is defined by both "
                    f"'{seen_namespaces[namespace]}' and '{module.__name__}'. "
                    f"'{seen_namespaces[namespace]}' takes precedence (INSTALLED_APPS order). "
                    f"This may be intentional if '{module.__name__}' is overriding it."
                )
                continue
            seen_namespaces[namespace] = module.__name__
            if getattr(module, "urlpatterns", None):
                urlpatterns += [path(namespace + "/", include(module))]

        return urlpatterns

    ###############################################################
    #  The following methods require Django's ORM already setup.  #
    #  Don't call them during the setup process                   #
    ###############################################################

    @staticmethod
    def orphaned_plugins() -> QuerySet:
        """Returns a list of GdapsPlugin models that have no disk representance any more.

        .. note:: This method needs Django's ORM to be running.
        """

        from gdaps.models import GdapsPlugin

        return GdapsPlugin.objects.exclude(
            name__in=[app.name for app in PluginManager.plugins()]
        )
