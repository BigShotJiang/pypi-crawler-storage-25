"""Plugin signature verification module.

This module handles verification of signed plugins using Ed25519 signatures
and SHA-256 file hashes.
"""

import base64
import fnmatch
import hashlib
import json
import logging
import os
from typing import Optional, Tuple

from gdaps.conf import gdaps_settings

logger = logging.getLogger(__name__)

MANIFEST_FILENAME = "MANIFEST.SIG"

# Patterns excluded from both signing and verification (must stay in sync with signplugin.py)
EXCLUDE_PATTERNS = {
    "__pycache__",
    ".pyc",
    ".pyo",
    ".git",
    ".svn",
    ".hg",
    ".DS_Store",
    "*.pyc",
    "*.pyo",
    "*.swp",
    "*.swo",
    "*~",
    ".pytest_cache",
    ".mypy_cache",
    ".coverage",
    "htmlcov",
    "*.egg-info",
    "dist",
    "build",
    ".env",
    "*.env",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
}


class SignatureVerificationError(Exception):
    """Raised when signature verification fails."""

    pass


class PluginNotSignedError(SignatureVerificationError):
    """Raised when a plugin is not signed but signed plugins are required."""

    pass


class PluginSignatureInvalidError(SignatureVerificationError):
    """Raised when a plugin's signature is invalid."""

    pass


class PluginCodeTamperedError(SignatureVerificationError):
    """Raised when plugin files have been modified after signing."""

    pass


def get_public_keys() -> list:
    """Get the configured public keys from settings.

    Reads both PLUGIN_SIGNING_PUBKEY (single string) and PLUGIN_SIGNING_PUBKEYS
    (list of strings) to support key rotation without downtime.

    Returns:
        List of public key objects (Ed25519PublicKey) or empty list if not configured.
    """
    keys = []

    key_pem = getattr(gdaps_settings, "PLUGIN_SIGNING_PUBKEY", None)
    if key_pem:
        keys.append(_parse_public_key(str(key_pem)))

    for key_pem in getattr(gdaps_settings, "PLUGIN_SIGNING_PUBKEYS", None) or []:
        if key_pem:
            keys.append(_parse_public_key(str(key_pem)))

    return keys


def _parse_public_key(key_pem: str):
    """Parse a public key from PEM or OpenSSH format."""
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519
        from cryptography.hazmat.primitives import serialization
    except ImportError:
        raise SignatureVerificationError(
            "cryptography package not installed. Install with: pip install cryptography"
        )

    key_data = key_pem.strip()

    if key_data.startswith("-----BEGIN"):
        public_key = serialization.load_pem_public_key(key_data.encode())
    elif key_data.startswith("ssh-"):
        public_key = serialization.load_ssh_public_key(key_data.encode())
    else:
        try:
            decoded = base64.b64decode(key_data)
            public_key = serialization.load_pem_public_key(decoded)
        except Exception:
            raise SignatureVerificationError(
                "Invalid public key format. Expected PEM or OpenSSH format."
            )

    if not isinstance(public_key, ed25519.Ed25519PublicKey):
        raise SignatureVerificationError("Public key must be Ed25519")

    return public_key


def verify_plugin_signature(
    module_name: str, module_path: str
) -> Tuple[bool, Optional[str]]:
    """Verify the signature of a plugin.

    This function:
    1. Looks for MANIFEST.SIG in the plugin directory
    2. Verifies the Ed25519 signature over the manifest
    3. Verifies all listed files have matching SHA-256 hashes
    4. Checks for any unexpected files in the plugin directory

    Args:
        module_name: The dotted module name of the plugin
        module_path: The absolute path to the plugin module

    Returns:
        Tuple of (success: bool, error_message: str or None)
    """
    require_signed = getattr(gdaps_settings, "REQUIRE_SIGNED_PLUGINS", False)
    public_keys = get_public_keys()

    manifest_path = os.path.join(module_path, MANIFEST_FILENAME)

    if not os.path.exists(manifest_path):
        if require_signed:
            raise PluginNotSignedError(
                f"Plugin '{module_name}' is not signed but signed plugins are required"
            )
        return True, None

    if not public_keys:
        logger.warning(
            f"Plugin '{module_name}' has MANIFEST.SIG but no public key configured. "
            "Skipping signature verification."
        )
        return True, None

    try:
        with open(manifest_path, "r") as f:
            signed_manifest = json.load(f)

        manifest = signed_manifest.get("manifest")
        signature_b64 = signed_manifest.get("signature")

        if not manifest or not signature_b64:
            raise PluginSignatureInvalidError("Manifest missing manifest or signature")

        manifest_json = json.dumps(manifest, sort_keys=True).encode()
        signature = base64.b64decode(signature_b64)

        verified = False
        for public_key in public_keys:
            try:
                public_key.verify(signature, manifest_json)
                verified = True
                break
            except Exception:
                continue

        if not verified:
            raise PluginSignatureInvalidError(
                f"Signature verification failed for plugin '{module_name}'"
            )

        manifest_plugin_name = manifest.get("plugin_name", "")
        if manifest_plugin_name:
            expected_name = module_name.split(".")[-1]
            if manifest_plugin_name != expected_name:
                raise PluginSignatureInvalidError(
                    f"Plugin '{module_name}' manifest plugin_name '{manifest_plugin_name}' "
                    f"does not match expected '{expected_name}'"
                )

        expected_files = manifest.get("files", {})
        signed_files = set(expected_files.keys())

        actual_files = _get_plugin_files(module_path)

        unexpected_files = actual_files - signed_files
        if unexpected_files:
            if require_signed:
                raise PluginCodeTamperedError(
                    f"Plugin '{module_name}' has files not covered by the signature: {unexpected_files}"
                )
            logger.warning(
                f"Plugin '{module_name}' has unsigned files: {unexpected_files}"
            )

        missing_files = signed_files - actual_files
        if missing_files:
            raise PluginCodeTamperedError(
                f"Plugin '{module_name}' is missing signed files: {missing_files}"
            )

        canonical_module_path = os.path.realpath(module_path)
        for relative_path, expected_hash in expected_files.items():
            file_path = os.path.realpath(os.path.join(module_path, relative_path))
            if not file_path.startswith(canonical_module_path + os.sep):
                raise PluginSignatureInvalidError(
                    f"Plugin '{module_name}' manifest contains a path traversal attempt: {relative_path}"
                )
            if not os.path.exists(file_path):
                raise PluginCodeTamperedError(
                    f"Plugin '{module_name}' file not found: {relative_path}"
                )

            with open(file_path, "rb") as f:
                actual_hash = hashlib.sha256(f.read()).hexdigest()

            if actual_hash != expected_hash:
                raise PluginCodeTamperedError(
                    f"Plugin '{module_name}' file has been tampered: {relative_path}"
                )

        logger.info(f"Plugin '{module_name}' signature verified successfully")
        return True, None

    except SignatureVerificationError:
        raise
    except Exception as e:
        raise PluginSignatureInvalidError(
            f"Error verifying plugin '{module_name}': {str(e)}"
        )


def _get_plugin_files(plugin_path: str) -> set:
    """Get all files in the plugin directory, excluding common non-code files."""
    files = set()

    for dirpath, dirnames, filenames in os.walk(plugin_path):
        dirnames[:] = [d for d in dirnames if not _should_exclude(d)]

        for filename in filenames:
            if _should_exclude(filename):
                continue

            file_path = os.path.join(dirpath, filename)
            relative_path = os.path.relpath(file_path, plugin_path)

            if relative_path == MANIFEST_FILENAME:
                continue

            files.add(relative_path)

    return files


def _should_exclude(name: str) -> bool:
    """Return True if a file or directory name matches any exclusion pattern."""
    return any(fnmatch.fnmatch(name, pattern) for pattern in EXCLUDE_PATTERNS)
