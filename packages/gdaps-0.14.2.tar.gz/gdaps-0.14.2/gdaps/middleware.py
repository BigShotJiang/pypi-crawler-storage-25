"""Helpers for plugins to mutate Django's MIDDLEWARE setting.

Plugins can implement a top-level ``alter_middleware(middleware)`` callable
in their main module, which is invoked by
:meth:`gdaps.pluginmanager.PluginManager.alter_middleware`. Inside that
callable, plugins typically use one of the helpers defined here to insert
their own middleware classes at a deterministic position relative to a
known anchor (e.g. Django's ``AuthenticationMiddleware``).

Both helpers fail loudly via :class:`~django.core.exceptions.ImproperlyConfigured`
if the anchor is not present, so a missing anchor surfaces immediately at
startup rather than producing silently mis-ordered middleware.
"""

from __future__ import annotations

from django.core.exceptions import ImproperlyConfigured

__all__ = ["insert_after", "insert_before"]


def insert_after(middleware: list[str], anchor: str, *to_insert: str) -> None:
    """Insert one or more middleware classes immediately after ``anchor``.

    The list is mutated in place. If ``anchor`` is not present in
    ``middleware``, an :class:`~django.core.exceptions.ImproperlyConfigured`
    is raised — fail loudly so plugins do not silently land in the wrong
    order.

    Args:
        middleware: The MIDDLEWARE list to mutate.
        anchor: Dotted path of an existing middleware class. Must already
            be present in ``middleware``.
        *to_insert: One or more dotted paths of middleware classes to
            insert directly after ``anchor``, preserving their relative
            order.

    Raises:
        ImproperlyConfigured: If ``anchor`` is not found in ``middleware``.
    """
    if not to_insert:
        return
    try:
        index = middleware.index(anchor)
    except ValueError as exc:
        raise ImproperlyConfigured(
            f"insert_after: anchor middleware '{anchor}' not found in MIDDLEWARE."
        ) from exc
    middleware[index + 1 : index + 1] = list(to_insert)


def insert_before(middleware: list[str], anchor: str, *to_insert: str) -> None:
    """Insert one or more middleware classes immediately before ``anchor``.

    The list is mutated in place. If ``anchor`` is not present in
    ``middleware``, an :class:`~django.core.exceptions.ImproperlyConfigured`
    is raised — fail loudly so plugins do not silently land in the wrong
    order.

    Args:
        middleware: The MIDDLEWARE list to mutate.
        anchor: Dotted path of an existing middleware class. Must already
            be present in ``middleware``.
        *to_insert: One or more dotted paths of middleware classes to
            insert directly before ``anchor``, preserving their relative
            order.

    Raises:
        ImproperlyConfigured: If ``anchor`` is not found in ``middleware``.
    """
    if not to_insert:
        return
    try:
        index = middleware.index(anchor)
    except ValueError as exc:
        raise ImproperlyConfigured(
            f"insert_before: anchor middleware '{anchor}' not found in MIDDLEWARE."
        ) from exc
    middleware[index:index] = list(to_insert)
