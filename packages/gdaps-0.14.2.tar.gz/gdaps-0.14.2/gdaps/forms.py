from django import forms
from django.core.exceptions import ImproperlyConfigured

from gdaps.api.interfaces import IFormFieldProvider

import typing


class PluginFormMixin:
    """Mixin that turns any Django form into a plugin-aware aggregating form.

    Set the ``interface`` class attribute to a **concrete** subclass of
    :class:`~gdaps.api.interfaces.IFormFieldProvider`.  On instantiation, every
    enabled plugin implementation contributes its fields via
    :meth:`~gdaps.api.interfaces.IFormFieldProvider.get_fields`; those fields are
    appended to the form's own fields in ascending ``weight`` order.  Fields from
    the same plugin are always consecutive, providing natural visual grouping.

    ``clean()`` is extended to call each plugin's
    :meth:`~gdaps.api.interfaces.IFormFieldProvider.clean` hook so plugins can
    perform cross-field validation and attach errors via ``form.add_error()``.

    Call :meth:`save_plugins` from your own ``save()`` to let each plugin persist
    its data::

        class MyForm(PluginFormMixin, forms.Form):
            interface = IMyFormFields
            title = forms.CharField()

            def save(self):
                # handle own fields …
                self.save_plugins()

    For :class:`~django.forms.ModelForm` subclasses, call :meth:`save_plugins`
    after ``super().save()``::

        class MyModelForm(PluginFormMixin, forms.ModelForm):
            interface = IMyModelFormFields

            def save(self, commit=True):
                instance = super().save(commit=commit)
                self.save_plugins()
                return instance
    """

    #: A concrete subclass of :class:`~gdaps.api.interfaces.IFormFieldProvider`.
    #: Must be set on every concrete form class.
    interface: type[IFormFieldProvider] = None

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        iface = cls.__dict__.get("interface")
        if iface is None:
            return  # not set in this class body; checked at instantiation
        if not (
            isinstance(iface, type)
            and issubclass(iface, IFormFieldProvider)
            and iface is not IFormFieldProvider
            and not iface.__dict__.get("__abstract__", False)
        ):
            raise TypeError(
                f"{cls.__name__}.interface must be a concrete (non-abstract) subclass "
                f"of IFormFieldProvider, got {iface!r}."
            )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.interface is None:
            raise ImproperlyConfigured(
                f"{self.__class__.__name__}.interface must be set to a concrete "
                f"subclass of IFormFieldProvider."
            )
        for plugin in self.interface.enabled_plugins():
            for name, field in plugin.get_fields().items():
                field._plugin = plugin
                field._plugin_title = getattr(plugin, "title", "")
                self.fields[name] = field

    @property
    def fields_by_plugin(
        self,
    ) -> list[tuple[typing.Optional[object], list[forms.BoundField]]]:
        """Returns fields grouped by plugin, including host form fields.

        Returns:
            A list of ``(plugin, fields)`` tuples. The first tuple has
            ``None`` as the plugin for fields defined directly on the form
            class. Subsequent tuples contain ``(plugin_instance, fields)``
            for each plugin's contributed fields, in the same order as
            they appear in the form.

        Example template usage::

            {% for plugin, fields in form.fields_by_plugin %}
                {% if plugin %}<h3>{{ plugin.title }}</h3>{% endif %}
                {% for field in fields %}{{ field }}{% endfor %}
            {% endfor %}
        """
        groups: list[tuple[typing.Optional[object], list]] = []
        current_plugin: typing.Optional[object] = None
        current_fields: list = []

        for name, field in self.fields.items():
            plugin = getattr(field, "_plugin", None)
            if plugin != current_plugin:
                if current_fields:
                    groups.append((current_plugin, current_fields))
                current_plugin = plugin
                current_fields = []
            current_fields.append(self[name])

        if current_fields:
            groups.append((current_plugin, current_fields))

        return groups

    def clean(self):
        cleaned_data = super().clean()
        for plugin in self.interface.enabled_plugins():
            plugin.clean(self)
        return cleaned_data

    def save_plugins(self) -> None:
        """Call :meth:`~gdaps.api.interfaces.IFormFieldProvider.save` on every
        enabled plugin implementation.

        Invoke this from your form's ``save()`` method after handling your own
        fields.
        """
        for plugin in self.interface.enabled_plugins():
            plugin.save(self)


class PluginForm(PluginFormMixin, forms.Form):
    """A Django :class:`~django.forms.Form` that aggregates fields from plugins.

    Subclass this and set ``interface`` to a concrete subclass of
    :class:`~gdaps.api.interfaces.IFormFieldProvider`.  Plugin implementations
    registered against that interface will automatically contribute their fields,
    participate in validation, and have their ``save()`` called when the form is
    saved.

    Override ``save()`` to add your own saving logic alongside :meth:`save_plugins`::

        # Define the extension point
        class IProfileFormFields(IFormFieldProvider):
            pass

        # The form
        class ProfileForm(PluginForm):
            interface = IProfileFormFields
            bio = forms.CharField(widget=forms.Textarea, required=False)

            def save(self):
                user.bio = self.cleaned_data["bio"]
                user.save()
                self.save_plugins()   # let plugins persist their own fields

        # A plugin's contribution
        class AvatarFields(IProfileFormFields):
            weight = 10

            def get_fields(self):
                return {"avatar": forms.ImageField(required=False)}

            def save(self, form):
                if form.cleaned_data.get("avatar"):
                    # … store the uploaded avatar
                    pass
    """

    def save(self) -> None:
        """Persist all plugin-contributed fields by delegating to each plugin's
        :meth:`~gdaps.api.interfaces.IFormFieldProvider.save`.

        Override this method if the form itself also needs to save data; call
        ``self.save_plugins()`` at an appropriate point in your override.
        """
        self.save_plugins()
