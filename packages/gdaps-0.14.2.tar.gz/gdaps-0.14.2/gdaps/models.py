from django.db import models


class GdapsPlugin(models.Model):
    """
    The GDAPS plugin model.

    This is internally used for showing synced plugins in the Django admin.
    """

    name = models.CharField(max_length=255)
    verbose_name = models.CharField(max_length=255)
    author = models.CharField(max_length=255, blank=True)
    author_email = models.EmailField(blank=True)
    vendor = models.CharField(max_length=255, blank=True)
    description = models.TextField(null=True, default=None)
    version = models.CharField(max_length=32, default="1.0.0")
    requires = models.CharField(max_length=255, null=True, default=None)
    category = models.CharField(max_length=255, blank=True, default="")
    enabled = models.BooleanField(default=True)
    hidden = models.BooleanField(default=False)

    @property
    def icon(self) -> str:
        """The plugin's icon string, as declared in ``PluginMeta.icon``.

        This is a free-form string that consumers can interpret as they
        wish — e.g. a named icon from a toolkit such as Tabler or Font
        Awesome (``ti ti-plug``, ``fa-solid fa-plug``), or a URL pointing
        to an avatar/image. Returns an empty string if not declared.
        """
        from django.apps import apps

        for app in apps.get_app_configs():
            if app.name == self.name:
                meta = getattr(app, "PluginMeta", None)
                return str(getattr(meta, "icon", "") or "")
        return ""

    @property
    def obligatory(self) -> bool:
        """Whether this plugin is declared obligatory via its PluginMeta.

        Obligatory plugins cannot be disabled; ``enabled`` is forced to True.
        """
        from django.apps import apps

        for app in apps.get_app_configs():
            if app.name == self.name:
                meta = getattr(app, "PluginMeta", None)
                return bool(getattr(meta, "obligatory", False))
        return False

    def save(self, *args, **kwargs):
        if self.obligatory:
            self.enabled = True
        super().save(*args, **kwargs)

    def __str__(self):
        return self.verbose_name

    def __repr__(self):
        return f"<'{self.name}' Plugin>"

    class Meta:
        verbose_name = "GDAPS plugin"
