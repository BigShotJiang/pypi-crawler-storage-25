"""Generic Django Apps Plugin System"""

__version__ = "0.14.2"
