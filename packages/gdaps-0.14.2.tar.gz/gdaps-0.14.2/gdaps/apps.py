import logging

import importlib.metadata
from packaging.requirements import Requirement
from packaging.version import Version

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

from gdaps import __version__
from gdaps import api
from gdaps.exceptions import PluginError
from gdaps.pluginmanager import PluginManager
from gdaps.conf import gdaps_settings
from gdaps.signing import (
    verify_plugin_signature,
    SignatureVerificationError,
)
from django.core.checks import Error, register

logger = logging.getLogger(__name__)


class GdapsConfig(api.PluginConfig):
    name = "gdaps"
    # Pin to BigAutoField so makemigrations stays deterministic regardless
    # of the host project's DEFAULT_AUTO_FIELD — otherwise GdapsPlugin.id
    # toggles between AutoField/BigAutoField on every run, producing the
    # 0002–0012 boomerang migration chain.
    default_auto_field = "django.db.models.BigAutoField"

    class PluginMeta:
        """This is the PluginMeta class of GDAPS itself."""

        version = __version__
        verbose_name = "Generic Django Application Plugin System"
        author = "Christian Gonzalez"
        author_email = "christian.gonzalez@nerdocs.at"
        category = "GDAPS"
        obligatory = True
        # hidden = True

    def ready(self):
        # walk through all installed plugins and check requires constraints
        for app in PluginManager.plugins():
            if hasattr(app.PluginMeta, "requires"):
                requirement = Requirement(app.PluginMeta.requires)
                try:
                    installed = Version(importlib.metadata.version(requirement.name))
                except importlib.metadata.PackageNotFoundError:
                    raise ImproperlyConfigured(
                        f"Plugin {app.name} requires '{requirement}', "
                        f"but package '{requirement.name}' is not installed."
                    )
                if requirement.specifier and installed not in requirement.specifier:
                    raise ImproperlyConfigured(
                        f"Plugin {app.name} requires '{requirement}', "
                        f"but installed version is {installed}."
                    )

        # load all generic gdaps.plugins - they must be implementations of GDAPS Interfaces
        logger.info("Loading gdaps plugins...")

        for entry_point in importlib.metadata.entry_points(group="gdaps.plugins"):
            module_name = (
                entry_point.value.split(":")[0]
                if ":" in entry_point.value
                else entry_point.value
            )

            try:
                from gdaps.pluginmanager import _get_module_path_from_entry_point

                module_path = _get_module_path_from_entry_point(entry_point)
                if module_path:
                    verify_plugin_signature(module_name, module_path)
            except SignatureVerificationError as e:
                logger.error(f"GDAPS plugin '{entry_point.name}' rejected: {e}")
                if getattr(gdaps_settings, "REQUIRE_SIGNED_PLUGINS", False):
                    raise PluginError(f"Cannot load plugin '{entry_point.name}': {e}")
                continue
            except Exception as e:
                logger.error(
                    f"GDAPS plugin '{entry_point.name}' signature check failed unexpectedly: {e}"
                )
                if getattr(gdaps_settings, "REQUIRE_SIGNED_PLUGINS", False):
                    raise PluginError(
                        f"Cannot load plugin '{entry_point.name}': signature verification error: {e}"
                    )
                continue

            # it is enough to have them instantiated, as they are remembered internally in their interface.
            entry_point.load()

        PluginManager.find_hooks()

        from django.apps import apps as django_apps

        if django_apps.is_installed("django.contrib.admin"):
            from gdaps.admin import register_admin

            register_admin()


@register()
def check_for_project_vars(app_configs, **kwargs):
    errors = []
    # ... your check logic here
    try:
        settings.PROJECT_NAME
    except AttributeError:
        errors.append(
            Error(
                "No PROJECT_NAME in your settings defined.",
                hint="GDAPS needs a PROJECT_NAME variable. Please set it to your "
                "(machine readable) project name.",
                obj=settings,
                id="gdaps.E001",
            )
        )
    try:
        settings.PROJECT_TITLE
    except AttributeError:
        errors.append(
            Error(
                "No PROJECT_TITLE in your settings defined.",
                hint="GDAPS needs a PROJECT_TITLE variable. Please set it to your "
                "(human readable) project name.",
                obj=settings,
                id="gdaps.E001",
            )
        )
    return errors
