
urlpatterns = []
