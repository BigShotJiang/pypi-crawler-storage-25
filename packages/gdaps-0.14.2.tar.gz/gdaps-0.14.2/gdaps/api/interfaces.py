from django.template.context import Context

from gdaps.api.base import Interface


class IFormFieldProvider(Interface):
    """Abstract base interface for contributing fields to a :class:`~gdaps.forms.PluginForm`.

    Define a **concrete** interface that inherits from this class to create a form
    extension point, then assign that concrete interface to the ``interface`` attribute
    of a :class:`~gdaps.forms.PluginForm` subclass.  Plugins implement the concrete
    interface to participate in the form.

    Example::

        # your_app/api/interfaces.py
        from gdaps.api.interfaces import IFormFieldProvider

        class IRegistrationFormFields(IFormFieldProvider):
            pass

        # your_app/forms.py
        from gdaps.forms import PluginForm
        from your_app.api.interfaces import IRegistrationFormFields

        class RegistrationForm(PluginForm):
            interface = IRegistrationFormFields
            username = forms.CharField()

            def save(self):
                # handle own fields …
                self.save_plugins()   # delegate to plugins

        # a_plugin/forms.py
        from your_app.api.interfaces import IRegistrationFormFields

        class NewsletterFields(IRegistrationFormFields):
            weight = 10   # controls position relative to other plugins

            def get_fields(self):
                return {"subscribe": forms.BooleanField(required=False, label="Subscribe to newsletter")}

            def clean(self, form):
                # optionally add cross-field validation errors
                pass

            def save(self, form):
                subscribe = form.cleaned_data.get("subscribe", False)
                # … persist the value

    **Ordering / positioning**

    Plugin implementations are iterated in ascending ``weight`` order (lower = earlier).
    All fields returned by a single plugin appear consecutively in the form, so plugins
    are naturally "grouped" in the rendered form.  To control the position of your
    plugin's fields relative to others, set a lower or higher ``weight``.
    """

    __abstract__ = True

    #: Controls the position of this plugin's fields relative to other plugins.
    #: Lower values appear first (default: 0).
    weight: int = 0

    #: Section caption for this plugin's fields in the form
    title: str = ""

    def get_fields(self) -> dict:
        """Return form fields contributed by this plugin.

        Returns:
            A ``{field_name: Field}`` dict.  The fields are added to the host
            form in ``weight`` order; all fields from one plugin appear
            consecutively.  Return an empty dict to contribute no fields.
        """
        return {}

    def clean(self, form) -> None:
        """Validate plugin fields within the host form's ``clean()`` cycle.

        Called automatically by :meth:`~gdaps.forms.PluginFormMixin.clean` after
        Django's own field-level validation.  Use ``form.add_error(field, msg)``
        to attach validation errors to specific fields so they are displayed
        alongside those fields in the template.

        Args:
            form: the :class:`~gdaps.forms.PluginForm` instance whose
                ``cleaned_data`` is already populated.
        """

    def save(self, form) -> None:
        """Persist plugin field data from the validated form.

        Called automatically by :meth:`~gdaps.forms.PluginFormMixin.save_plugins`.
        Access submitted values through ``form.cleaned_data``.

        Args:
            form: the validated :class:`~gdaps.forms.PluginForm` instance.
        """


class ITemplatePlugin(Interface):
    """A mixin that can be inherited from to build renderable plugins.

    Create an **interface** that inherits from ITemplatePlugin. Each
    implementation must have a `template_name` (which points to the template to render).

    You can add fixed `context`, or override `get_plugin_context` which receives
    the context of the view the plugin is rendered in.

    In your template, use
    ```
    {% load gdaps %}
    <ul class="alerts">
    {% render_plugin IMyListItem %}
    </ul>
    ```
    in your template anywhere, and all of your implementations are rendered,
    one after each other, in a line. Each plugin can come from another app.
    You can change the order of the rendering using the `weight` attribute.
    """

    __abstract__ = True

    template_name: str = ""
    context: dict = {}
    weight = 0

    def get_plugin_context(self, context: Context) -> Context:
        """Override this method to add custom context to the plugin.

        :param context: the context where the plugin is rendered in.
            You can update it with own values, and return it.
            The return variable of this function will be the context
            of the rendered plugin. So if you don't update the passed
            context, but just return a new one, the plugin will not get
            access to the global context.

        Per default, it merges the plugin's ``context`` attribute into
        the given global context.
        """
        context.update(self.context)
        return context


class IViewExtension(Interface):
    """Abstract base interface for hooks that extend Django views.

    Subclass this to declare a concrete view-extension hook in your
    project (e.g. ``ILoginViewExtension``); plugins then implement that
    concrete subclass. ``IViewExtension`` itself is abstract and is not
    registered as an interface — direct subclasses become *new
    interfaces* (and must therefore start with a capital ``I``).
    """

    __abstract__ = True

    def alter_context_data(self, **kwargs) -> dict:
        """hook to alter context data of a view.

        Call this hook from get_context_data().
        """
        return {}

    def alter_response(self, request, response, *args, **kwargs) -> None:
        """hook to alter a response during a post/get/delete etc. request.

        Call this hook from get/post/delete().

        Attributes:
            request: the current request
            response: the response, as the post method created it so far.
                Feel free to modify it.
        """

    def form_valid(self, form, response) -> None:
        """hook that should be called by form_valid() to add plugin functionality."""
