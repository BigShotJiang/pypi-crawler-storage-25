# this is the API of GDAPS itself.
from django.apps import AppConfig

from .base import (
    Interface as Interface,
    InterfaceMeta as InterfaceMeta,
    InterfaceNotFound as InterfaceNotFound,
    PluginConfig as PluginConfig,
    PluginMeta as PluginMeta,
    is_enabled as is_enabled,
)

__all__ = [
    "Interface",
    "InterfaceMeta",
    "InterfaceNotFound",
    "PluginConfig",
    "PluginMeta",
    "is_enabled",
]


def require_app(app_config: AppConfig, required_app_name: str) -> None:
    """Helper function for AppConfig.ready() - checks if an app is installed.

    An ``ImproperlyConfigured`` Exception is raised if the required app is not present.

    :param app_config: the AppConfig which requires another app. usually use ``self`` here
            when called from AppConfig.ready()
    :param required_app_name: the required app name.
    """
    from django.apps import apps
    from django.core.exceptions import ImproperlyConfigured

    if app_config.name not in [app.name for app in apps.get_app_configs()]:
        raise ImproperlyConfigured(
            "The '{}' module relies on {}. Please add '{}' to your INSTALLED_APPS.".format(
                app_config.name, app_config.verbose_name, required_app_name
            )
        )
