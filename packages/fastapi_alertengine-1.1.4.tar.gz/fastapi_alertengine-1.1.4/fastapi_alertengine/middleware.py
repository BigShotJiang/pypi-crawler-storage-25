# fastapi_alertengine/middleware.py
import logging
import time

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from .storage import write_metric

logger = logging.getLogger(__name__)


class RequestMetricsMiddleware(BaseHTTPMiddleware):
    """
    Starlette/FastAPI middleware that measures request latency and writes
    one event per request to a Redis Stream for later aggregation.

    Redis failures are swallowed — metrics never affect the request path.

    Args:
        app:          The ASGI application.
        alert_engine: An :class:`~fastapi_alertengine.engine.AlertEngine`
                      instance (provides both the Redis client and config).

    Usage::

        from fastapi_alertengine import RequestMetricsMiddleware, get_alert_engine

        engine = get_alert_engine(redis_client=rdb)
        app.add_middleware(RequestMetricsMiddleware, alert_engine=engine)
    """

    def __init__(self, app, alert_engine) -> None:
        super().__init__(app)
        self._engine = alert_engine

    async def dispatch(self, request: Request, call_next) -> Response:
        t0          = time.perf_counter()
        status_code = 500                  # captured on exception path too

        try:
            response    = await call_next(request)
            status_code = response.status_code
            return response
        except Exception:
            raise
        finally:
            latency_ms = (time.perf_counter() - t0) * 1_000
            write_metric(
                self._engine.redis,
                self._engine.config,
                {
                    "latency_ms":  latency_ms,
                    "type":        "webhook" if "webhook" in request.url.path else "api",
                    "status_code": status_code,
                    "timestamp":   int(time.time()),
                },
            )
