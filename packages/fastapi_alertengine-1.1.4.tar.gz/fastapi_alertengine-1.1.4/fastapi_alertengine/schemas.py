# fastapi_alertengine/schemas.py
from dataclasses import dataclass
from typing import Optional


@dataclass
class RequestMetricEvent:
    """One recorded HTTP request — matches the canonical stream schema."""
    latency_ms:  float
    type:        str    # "api" | "webhook"
    status_code: int
    timestamp:   int    # Unix seconds
