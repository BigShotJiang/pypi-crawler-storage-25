# fastapi_alertengine/engine.py
import logging
import time
from typing import Any, Optional

from .config  import AlertConfig
from .storage import p95 as _p95, read_metrics

logger = logging.getLogger(__name__)

_DEFAULT_CONFIG = AlertConfig()


class AlertEngine:
    """
    Real-time SLO alert engine backed by a Redis Stream.

    Call :meth:`evaluate` from a background job or health endpoint to get
    the current alert status.

    Args:
        redis:  Synchronous ``redis.Redis`` client.
        config: :class:`~fastapi_alertengine.config.AlertConfig` instance.

    Attributes:
        redis:  The Redis client (also used by RequestMetricsMiddleware).
        config: The active AlertConfig (also used by RequestMetricsMiddleware).

    Usage::

        engine = AlertEngine(redis=rdb)
        result = engine.evaluate()          # returns dict
        if result["status"] == "critical":
            ...
    """

    def __init__(self, redis: Any, config: AlertConfig = _DEFAULT_CONFIG) -> None:
        self.redis  = redis
        self.config = config

    def evaluate(self, window_size: Optional[int] = None) -> dict:
        """
        Read the most recent ``window_size`` events from the Redis Stream
        and return a status dict.

        Args:
            window_size: Number of events to evaluate.  Defaults to
                         ``config.window_size`` (200).

        Returns:
            Dict with keys: ``status``, ``reason``, ``metrics``,
            ``thresholds``, ``timestamp``.

        Never raises — returns ``status="ok", reason="no_data"`` when the
        stream is empty or Redis is unavailable.
        """
        c      = self.config
        n      = window_size if window_size is not None else c.window_size
        events = read_metrics(self.redis, c, n)

        if not events:
            return _no_data_result(self._thresholds())

        all_lat     = [e["latency_ms"] for e in events]
        webhook_lat = [e["latency_ms"] for e in events if e["type"] == "webhook"]
        api_lat     = [e["latency_ms"] for e in events if e["type"] == "api"]

        overall_p95 = _p95(all_lat)
        webhook_p95 = _p95(webhook_lat)
        api_p95     = _p95(api_lat)

        baseline   = sum(all_lat) / len(all_lat)
        anomaly    = abs(overall_p95 - baseline) / baseline if baseline else 0.0
        error_rate = sum(1 for e in events if e["status_code"] >= 500) / len(events)

        # ── Status resolution (critical wins over warning) ────────────────────
        status = "ok"
        reason = None

        if overall_p95 > c.p95_critical_ms or anomaly > c.anomaly_critical:
            status = "critical"
            reason = (
                f"p95={overall_p95:.0f}ms > {c.p95_critical_ms:.0f}ms"
                if overall_p95 > c.p95_critical_ms
                else f"anomaly_score={anomaly:.2f} > {c.anomaly_critical}"
            )
        elif overall_p95 > c.p95_warning_ms or anomaly > c.anomaly_warning:
            status = "warning"
            reason = (
                f"p95={overall_p95:.0f}ms > {c.p95_warning_ms:.0f}ms"
                if overall_p95 > c.p95_warning_ms
                else f"anomaly_score={anomaly:.2f} > {c.anomaly_warning}"
            )

        if error_rate > c.error_rate_critical:
            status = "critical"
            reason = f"error_rate={error_rate:.1%} > {c.error_rate_critical:.0%}"
        elif error_rate > c.error_rate_warning and status != "critical":
            status = "warning"
            reason = reason or f"error_rate={error_rate:.1%} > {c.error_rate_warning:.0%}"

        return {
            "status": status,
            "reason": reason,
            "metrics": {
                "overall_p95_ms": round(overall_p95, 3),
                "webhook_p95_ms": round(webhook_p95, 3),
                "api_p95_ms":     round(api_p95, 3),
                "error_rate":     round(error_rate, 4),
                "anomaly_score":  round(anomaly, 4),
                "sample_size":    len(events),
            },
            "thresholds": self._thresholds(),
            "timestamp":  int(time.time()),
        }

    def _thresholds(self) -> dict:
        c = self.config
        return {
            "p95_warning_ms":      c.p95_warning_ms,
            "p95_critical_ms":     c.p95_critical_ms,
            "anomaly_warning":     c.anomaly_warning,
            "anomaly_critical":    c.anomaly_critical,
            "error_rate_warning":  c.error_rate_warning,
            "error_rate_critical": c.error_rate_critical,
        }


class AlertDeduplicator:
    """
    Redis TTL-based deduplication — prevents the same alert type from
    firing more than once per ``cooldown_seconds``.

    Fails open: if Redis is unavailable, alerts are allowed through.

    Args:
        redis:  Synchronous ``redis.Redis`` client.
        config: :class:`~fastapi_alertengine.config.AlertConfig` instance.

    Usage::

        dedup  = AlertDeduplicator(redis=rdb)
        result = engine.evaluate()
        if result["status"] != "ok" and dedup.should_fire(result["status"]):
            send_notification(result)
    """

    def __init__(self, redis: Any, config: AlertConfig = _DEFAULT_CONFIG) -> None:
        self._rdb      = redis
        self._cooldown = config.cooldown_seconds

    def should_fire(self, alert_type: str, severity: str = "warning") -> bool:
        """Return True if the alert should be emitted (not a duplicate)."""
        key = f"alert:dedup:{alert_type}"
        try:
            result = self._rdb.set(
                key,
                f"{severity}:{int(time.time())}",
                nx=True,
                ex=self._cooldown,
            )
            return bool(result)
        except Exception as exc:
            logger.warning("AlertDeduplicator: Redis error — failing open: %s", exc)
            return True

    def reset(self, alert_type: str) -> None:
        """Clear the dedup key so the alert can fire immediately."""
        try:
            self._rdb.delete(f"alert:dedup:{alert_type}")
        except Exception as exc:
            logger.warning("AlertDeduplicator.reset failed: %s", exc)


# ── Internal ──────────────────────────────────────────────────────────────────

def _no_data_result(thresholds: dict) -> dict:
    return {
        "status": "ok",
        "reason": "no_data",
        "metrics": {
            "overall_p95_ms": 0.0,
            "webhook_p95_ms": 0.0,
            "api_p95_ms":     0.0,
            "error_rate":     0.0,
            "anomaly_score":  0.0,
            "sample_size":    0,
        },
        "thresholds": thresholds,
        "timestamp":  int(time.time()),
    }
