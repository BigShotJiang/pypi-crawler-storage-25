# fastapi_alertengine/storage.py
"""
Redis Streams read/write for request metrics.

Canonical stream event schema (all values stored as strings by Redis):
    {
        "latency_ms":  str   # float, 3 decimal places  e.g. "84.312"
        "type":        str   # "api" | "webhook"
        "status_code": str   # int as string            e.g. "200"
        "timestamp":   str   # unix seconds             e.g. "1712345678"
    }

All functions fail silently on Redis errors.
"""

import logging
import time as _time
from typing import Any, Dict, List, Optional

from .config import AlertConfig

logger = logging.getLogger(__name__)


def write_metric(
    redis,
    config: AlertConfig,
    metric: Dict[str, Any],
) -> None:
    """
    Append one request event to the Redis Stream.  Never raises.

    Args:
        redis:  Synchronous ``redis.Redis`` client.
        config: ``AlertConfig`` instance (provides ``stream_key`` and ``stream_maxlen``).
        metric: Dict with keys ``latency_ms``, ``type``, ``status_code``, ``timestamp``.
    """
    try:
        redis.xadd(
            config.stream_key,
            {
                "latency_ms":  f"{float(metric['latency_ms']):.3f}",
                "type":        str(metric.get("type", "api")),
                "status_code": str(int(metric["status_code"])),
                "timestamp":   str(int(metric.get("timestamp", int(_time.time())))),
            },
            maxlen=config.stream_maxlen,
            approximate=True,
        )
    except Exception as exc:
        logger.warning("fastapi_alertengine.write_metric failed: %s", exc)


def read_metrics(
    redis,
    config: AlertConfig,
    count: int,
) -> List[Dict[str, Any]]:
    """
    Read the most recent *count* events from the stream.

    Returns a list of dicts with typed values.  Returns [] on any error.
    """
    try:
        raw = redis.xrevrange(config.stream_key, count=count)
    except Exception as exc:
        logger.warning("fastapi_alertengine.read_metrics failed: %s", exc)
        return []

    events = []
    for _sid, fields in raw:
        try:
            events.append({
                "latency_ms":  float(fields["latency_ms"]),
                "type":        fields.get("type", "api"),
                "status_code": int(fields["status_code"]),
                "timestamp":   int(fields.get("timestamp", 0)),
            })
        except (KeyError, ValueError, TypeError):
            continue
    return events


def aggregate(
    redis,
    config: AlertConfig,
    last_n: int = 500,
) -> dict:
    """
    Read *last_n* events and return p95 latency by traffic type.

    Returns::

        {
            "webhook_latency": {"p95_ms": float | None, "count": int},
            "api_latency":     {"p95_ms": float | None, "count": int},
            "overall_latency": {"p95_ms": float | None, "count": int},
        }
    """
    events = read_metrics(redis, config, last_n)

    webhook_ms = [e["latency_ms"] for e in events if e["type"] == "webhook"]
    api_ms     = [e["latency_ms"] for e in events if e["type"] == "api"]
    all_ms     = webhook_ms + api_ms

    return {
        "webhook_latency": _bucket(webhook_ms),
        "api_latency":     _bucket(api_ms),
        "overall_latency": _bucket(all_ms),
    }


# ── Shared p95 ────────────────────────────────────────────────────────────────

def p95(values: List[float]) -> float:
    """
    95th-percentile of *values*.  Returns 0.0 for empty input.
    Index is clamped to the last element so it never goes out of bounds.
    """
    if not values:
        return 0.0
    s   = sorted(values)
    idx = min(int(len(s) * 0.95), len(s) - 1)
    return round(s[idx], 3)


def _bucket(values: List[float]) -> dict:
    return {"p95_ms": p95(values) if values else None, "count": len(values)}
