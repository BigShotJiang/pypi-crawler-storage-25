# fastapi_alertengine/__init__.py
"""
fastapi_alertengine
===================

Production-grade request metrics middleware and SLO alert engine for
FastAPI services.  Backed by Redis Streams.

Quick start::

    from fastapi import FastAPI
    from fastapi_alertengine import RequestMetricsMiddleware, get_alert_engine
    import redis

    app = FastAPI()
    rdb = redis.Redis.from_url("redis://localhost:6379/0", decode_responses=True)

    engine = get_alert_engine(redis_client=rdb)
    app.add_middleware(RequestMetricsMiddleware, alert_engine=engine)

    @app.get("/health/alerts")
    def alert_status():
        return engine.evaluate()
"""

from .client   import get_alert_engine
from .config   import AlertConfig
from .engine   import AlertDeduplicator, AlertEngine
from .middleware import RequestMetricsMiddleware
from .schemas  import RequestMetricEvent
from .storage  import aggregate, p95, read_metrics, write_metric

try:
    from importlib.metadata import version as _v
    __version__ = _v("fastapi-alertengine")
except Exception:
    __version__ = "unknown"

__all__ = [
    # Primary surface
    "RequestMetricsMiddleware",
    "AlertEngine",
    "AlertDeduplicator",
    "get_alert_engine",
    # Config + schemas
    "AlertConfig",
    "RequestMetricEvent",
    # Storage helpers
    "aggregate",
    "p95",
    "read_metrics",
    "write_metric",
]
