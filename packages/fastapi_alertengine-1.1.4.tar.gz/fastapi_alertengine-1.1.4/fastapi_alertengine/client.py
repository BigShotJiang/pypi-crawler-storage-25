# fastapi_alertengine/client.py
"""
get_alert_engine() — process-level singleton factory.

Lazily constructs one AlertEngine per (redis_url, config) pair and caches it
for the lifetime of the process.  Safe to call from anywhere without worrying
about duplicate Redis connections.

Usage::

    from fastapi_alertengine import get_alert_engine

    engine = get_alert_engine(redis_client=rdb)
    result = engine.evaluate()
"""

import threading
from typing import Optional

import redis as _redis_lib

from .config import AlertConfig
from .engine import AlertEngine

_lock:     threading.Lock = threading.Lock()
_registry: dict           = {}


def get_alert_engine(
    config:       Optional[AlertConfig] = None,
    redis_client                        = None,
) -> AlertEngine:
    """
    Return a cached :class:`~fastapi_alertengine.engine.AlertEngine`.

    Pass an already-constructed ``redis_client`` to reuse an existing
    connection.  If omitted, a new client is created from
    ``config.redis_url``.

    Args:
        config:       :class:`~fastapi_alertengine.config.AlertConfig`.
                      Defaults to ``AlertConfig()`` (all library defaults).
        redis_client: Pre-built ``redis.Redis`` instance (optional).

    Returns:
        A shared :class:`~fastapi_alertengine.engine.AlertEngine` instance.
    """
    cfg = config or AlertConfig()
    key = id(redis_client) if redis_client is not None else cfg.redis_url

    if key not in _registry:
        with _lock:
            if key not in _registry:
                rdb = redis_client or _redis_lib.Redis.from_url(
                    cfg.redis_url,
                    decode_responses=True,
                    socket_timeout=5,
                    socket_connect_timeout=5,
                )
                _registry[key] = AlertEngine(redis=rdb, config=cfg)

    return _registry[key]
