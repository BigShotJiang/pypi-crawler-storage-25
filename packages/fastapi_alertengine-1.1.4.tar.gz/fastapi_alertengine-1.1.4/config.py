# config.py  (root-level shim)
"""
Root-level config shim — re-exports the app.config singleton so that
``from config import settings`` works from any module in the project root.
"""

from app.config import Settings, PaynowSettings, WhatsAppSettings, load_settings, settings  # noqa: F401
