# Configuration Reference

All configuration is loaded from environment variables. Copy `.env.example` to `.env` for local development.

---

## Required Variables

These must be set. The startup health check will log an error and start in degraded mode if any are missing.

| Variable | Example | Description |
|---|---|---|
| `DATABASE_URL` | `postgresql://user:pass@host:5432/db` | PostgreSQL connection string. Use `sqlite:///./local.db` for local dev. |
| `REDIS_URL` | `redis://localhost:6379` | Redis connection string. |
| `TWILIO_ACCOUNT_SID` | `ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` | Twilio account SID. |
| `TWILIO_AUTH_TOKEN` | `your_auth_token` | Twilio auth token. |
| `TWILIO_WHATSAPP_NUMBER` | `whatsapp:+14155238886` | Your Twilio WhatsApp number. |
| `PAYNOW_INTEGRATION_ID` | `12345` | Paynow integration ID from merchant portal. |
| `PAYNOW_INTEGRATION_KEY` | `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` | Paynow integration key. |
| `PAYNOW_MERCHANT_EMAIL` | `merchant@example.com` | Email registered with Paynow. |

---

## Optional Variables

Missing optional variables log a WARNING at startup but do not affect core functionality.

### AI / Claude

| Variable | Description | Default behaviour if absent |
|---|---|---|
| `ANTHROPIC_API_KEY` | Claude AI API key. | Claude calls disabled — keyword-only mode. |

### Mapping

| Variable | Description | Default behaviour if absent |
|---|---|---|
| `GOOGLE_MAPS_API_KEY` | Google Maps Geocoding API key. | Manual distance entry only. |

### Mobile Money Adapters

These activate the respective payment provider adapters. Without them, adapters return `not_configured` responses.

| Variable | Provider | Description |
|---|---|---|
| `ECOCASH_CLIENT_ID` | EcoCash | OAuth2 client ID |
| `ECOCASH_CLIENT_SECRET` | EcoCash | OAuth2 client secret |
| `ECOCASH_BASE_URL` | EcoCash | API base URL (default: `https://api.ecocash.co.zw`) |
| `INNBUCKS_API_KEY` | InnBucks | API key |
| `INNBUCKS_MERCHANT_CODE` | InnBucks | Merchant code |
| `INNBUCKS_BASE_URL` | InnBucks | API base URL |
| `OMARI_API_KEY` | Omari | API key |
| `OMARI_MERCHANT_ID` | Omari | Merchant ID |
| `OMARI_BASE_URL` | Omari | API base URL |

### Paynow Advanced

| Variable | Default | Description |
|---|---|---|
| `PAYNOW_BASE_URL` | `https://www.paynow.co.zw` | Paynow API base URL. Override for staging. |
| `PAYNOW_TIMEOUT_SECONDS` | `30` | HTTP timeout for Paynow API calls. |
| `PAYNOW_MAX_RETRIES` | `3` | Max retries on 5xx / network errors. |

### Escrow Timeout

| Variable | Default | Description |
|---|---|---|
| `ESCROW_TIMEOUT_HOURS` | `2` | Hours before a HELD escrow is marked EXPIRED. |
| `TIMEOUT_JOB_INTERVAL_MINUTES` | `5` | How often the timeout job runs. |

---

## Variable Loading

Variables are loaded via `app/config.py` (`Settings` dataclass with `python-decouple` or `os.environ`). The root-level `config.py` re-exports everything for legacy imports.

```python
from app.config import settings

print(settings.paynow_integration_id)
print(settings.redis_url)
```

---

## Local SQLite (Dev Only)

For local development without PostgreSQL:

```
DATABASE_URL=sqlite:///./local.db
```

Alembic handles both PostgreSQL and SQLite (the startup check passes `check_same_thread=False` for SQLite automatically).
