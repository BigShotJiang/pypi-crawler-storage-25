<img src="assets/tofamba_logo.png" alt="AnchorFlow — Tofamba. Paid. Delivered. Done." width="400"/>

# API Reference

Base URL: `https://your-app.railway.app`

All endpoints return JSON. Error responses follow `{"detail": "message"}` (FastAPI default).

---

## Meta

### GET /health
Lightweight liveness check.

**Response 200:**
```json
{"status": "healthy", "service": "Tofamba API"}
```

---

## WhatsApp Bot

### POST /whatsapp-bot/webhook
Receives WhatsApp messages from Twilio.

**Request:** `application/x-www-form-urlencoded` (Twilio webhook format)

| Field | Type | Description |
|---|---|---|
| `From` | string | Sender WhatsApp number (`whatsapp:+263...`) |
| `Body` | string | Message text |
| `MessageSid` | string | Twilio message ID (used for dedup) |

**Response 200:** `text/xml` — TwiML response with bot reply

### POST /whatsapp-bot/payment-webhook
Receives payment status callbacks from Paynow.

**Request:** `application/x-www-form-urlencoded`

| Field | Type | Description |
|---|---|---|
| `reference` | string | Paynow payment reference |
| `status` | string | `Sent`, `Paid`, `Cancelled`, etc. |
| `hash` | string | HMAC validation hash |

**Response 200:** `"OK"`

### GET /whatsapp-bot/health
Bot subsystem health.

**Response 200:**
```json
{
  "status": "healthy",
  "degraded_mode": {"degraded": false, "reason": null, "redis_latency_ms": 2.1}
}
```

### GET /whatsapp-bot/metrics
Bot runtime metrics snapshot.

**Response 200:**
```json
{
  "circuit_status": {"open": false, "failures": 0, "threshold": 5},
  "metrics": {
    "webhook_latency": {"count": 500, "avg_ms": 95.2, "p95_ms": 280.0},
    "payment_processing_time": {"count": 12, "avg_ms": 120.5},
    "redis_failures": {"count": 0, "recent": []},
    "stream_length": 4821
  }
}
```

---

## Deals

### GET /deals
List all deals.

### GET /deals/{deal_id}
Get a single deal by ID.

### POST /deals
Create a new deal.

### PATCH /deals/{deal_id}
Update deal status.

---

## Inventory

### GET /inventory
List merchant inventory items.

### POST /inventory
Add an inventory item.

### PATCH /inventory/{item_id}
Update an inventory item.

### DELETE /inventory/{item_id}
Remove an inventory item.

---

## Merchant Portal

### GET /merchant-portal/catalogue
List catalogue items for a merchant.

Query params:
- `slug` (string, required) — Merchant slug
- `page` (int, default 1) — Page number
- `page_size` (int, default 10) — Items per page

**Response 200:**
```json
{
  "items": [...],
  "total": 45,
  "page": 1,
  "total_pages": 5,
  "has_next": true
}
```

---

## Recovery

### POST /recovery/sweep
Scan and reset orphaned bot sessions.

**Response 200:**
```json
{
  "scanned": 1250,
  "orphaned": 2,
  "fixed": [
    {"phone_hash": 42301, "from": "awaiting_payment", "to": "idle", "age_s": 9200}
  ]
}
```

No request body required. Safe to call repeatedly (idempotent within a sweep cycle).

### GET /recovery/health
Recovery subsystem liveness.

**Response 200:**
```json
{"status": "ok", "active_sessions_sampled": 87}
```

---

## Metrics

### GET /metrics/health
Full system health snapshot.

**Response 200:**
```json
{
  "status": "ok",
  "timestamp": 1700000000,
  "degraded_mode": {"degraded": false, "reason": null, "redis_latency_ms": 2.5},
  "circuit_breaker": {"open": false, "failures": 0, "threshold": 5},
  "alerts": {
    "webhook_latency": "ok",
    "redis_failures": "ok",
    "redis_latency": "ok",
    "state_transitions": "ok"
  },
  "thresholds": {
    "webhook_p95_ms_warn": 1000,
    "webhook_p95_ms_crit": 3000,
    "redis_failures_warn": 5,
    "redis_failures_crit": 20,
    "state_transition_fail_warn": 3,
    "redis_latency_ms_warn": 150,
    "redis_latency_ms_crit": 500
  },
  "summary": {
    "webhook_p95_ms": 85.2,
    "redis_failures_recent": 0,
    "state_transition_failures": 0,
    "redis_latency_ms": 2.5,
    "stream_length": 4821
  }
}
```

### GET /metrics/export
Prometheus-compatible metrics export.

Query params:
- `last_n` (int, default 1000, max 10000) — Stream entries to aggregate

**Response 200:**
```json
{
  "metrics": [
    {"name": "anchorflow_webhook_latency_avg_ms", "value": 95.2, "type": "gauge", "help": "..."},
    {"name": "anchorflow_webhook_latency_p95_ms", "value": 280.0, "type": "gauge", "help": "..."},
    {"name": "anchorflow_webhook_count", "value": 500, "type": "counter", "help": "..."},
    {"name": "anchorflow_payment_processing_avg_ms", "value": 120.5, "type": "gauge", "help": "..."},
    {"name": "anchorflow_payment_count", "value": 12, "type": "counter", "help": "..."},
    {"name": "anchorflow_courier_acceptance_avg_ms", "value": 1200.0, "type": "gauge", "help": "..."},
    {"name": "anchorflow_courier_acceptance_count", "value": 8, "type": "counter", "help": "..."},
    {"name": "anchorflow_redis_failures_total", "value": 0, "type": "counter", "help": "..."},
    {"name": "anchorflow_state_transition_failures_total", "value": 0, "type": "counter", "help": "..."},
    {"name": "anchorflow_circuit_breaker_open", "value": 0, "type": "gauge", "help": "..."},
    {"name": "anchorflow_degraded_mode", "value": 0, "type": "gauge", "help": "..."},
    {"name": "anchorflow_redis_latency_ms", "value": 2.5, "type": "gauge", "help": "..."},
    {"name": "anchorflow_metrics_stream_length", "value": 4821, "type": "gauge", "help": "..."}
  ],
  "sample_n": 1000,
  "timestamp": 1700000000,
  "service": "anchorflow-whatsapp-bot"
}
```
