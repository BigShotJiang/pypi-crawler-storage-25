# Operations Guide

## Health Monitoring

### Primary Health Endpoint

```
GET /health
```
Returns `{"status": "healthy"}` — suitable for Railway health check and uptime monitors.

### Detailed System Health

```
GET /metrics/health
```

Returns:
```json
{
  "status": "ok | warning | critical",
  "timestamp": 1700000000,
  "degraded_mode": {
    "degraded": false,
    "reason": null,
    "redis_latency_ms": 2.5
  },
  "circuit_breaker": {
    "open": false,
    "failures": 0,
    "threshold": 5
  },
  "alerts": {
    "webhook_latency": "ok",
    "redis_failures": "ok",
    "redis_latency": "ok",
    "state_transitions": "ok"
  },
  "summary": {
    "webhook_p95_ms": 85.2,
    "redis_failures_recent": 0,
    "state_transition_failures": 0,
    "redis_latency_ms": 2.5
  }
}
```

**Overall status levels:**
- `ok` — all systems healthy
- `warning` — degraded mode active or metric above warn threshold
- `critical` — circuit breaker open or metric above critical threshold

### Prometheus Export

```
GET /metrics/export?last_n=1000
```

Returns flat list of `{name, value, type, help}` objects suitable for Grafana's JSON datasource or a custom Prometheus exporter.

---

## Alert Thresholds

| Metric | Warning | Critical |
|---|---|---|
| Webhook p95 latency | > 1000ms | > 3000ms |
| Redis failures (last N) | > 5 | > 20 |
| Redis round-trip | > 150ms | > 500ms |
| State transition failures | > 3 | > 15 |

---

## Degraded Mode

Degraded mode disables Claude AI calls and reduces Redis pressure. The bot falls back to keyword-only responses.

**Auto-triggers:**
- Redis RTT > 150ms
- Payment queue depth > 1000

**Manual control:**
```bash
# Enable degraded mode (persists 60s, then auto-clears)
redis-cli SET bot:degraded_mode "deploy_in_progress" EX 60

# Disable immediately
redis-cli DEL bot:degraded_mode
```

**Check status:**
```
GET /metrics/health  →  "degraded_mode": {"degraded": true, "reason": "..."}
```

---

## Circuit Breaker

The Redis circuit breaker opens after 5 connection failures within 30 seconds. When open, all Redis calls go to the in-process ephemeral store. The circuit auto-resets after 30 seconds.

**Manual reset** (if the circuit is stuck open after Redis recovers):
```bash
# Restart the Railway service — the in-memory circuit resets on startup
railway restart
```

**Monitor:**
```
GET /metrics/health  →  "circuit_breaker": {"open": true, "failures": 7}
```

---

## Session Recovery Sweep

The recovery sweep detects and resets orphaned bot sessions (stuck states).

### Running the Sweep

```
POST /recovery/sweep
```

Response:
```json
{
  "scanned": 1250,
  "orphaned": 3,
  "fixed": [
    {"phone_hash": 42301, "from": "awaiting_payment", "to": "idle", "age_s": 9200},
    ...
  ]
}
```

### Recommended Schedule

Run every 15 minutes via Railway cron or an external scheduler:
```
POST https://your-app.railway.app/recovery/sweep
```

### Orphan Thresholds

| State | Max age before reset | Reset to |
|---|---|---|
| `awaiting_payment` | 2 hours | `idle` |
| `deal_created` | 2 hours | `idle` |
| `ordering` | 30 minutes | `browsing` |
| `delivery_in_progress` | 24 hours | `idle` |
| `courier_matching` | 1 hour | `idle` |

---

## Escrow Timeout Engine

The `EscrowTimeoutJob` runs every 5 minutes (configurable via `TIMEOUT_JOB_INTERVAL_MINUTES`). It:

1. Scans for `HELD` escrow records older than `ESCROW_TIMEOUT_HOURS` (default 2h)
2. Transitions them to `EXPIRED`
3. Initiates reversal via `PaynowWalletAdapter.reverse_transaction()`
4. Transitions to `REVERSAL_INITIATED` → `REVERSAL_CONFIRMED`

**Monitoring:** Check `EscrowStateLog` in the database for timeout events. Filter by `event_type = 'TIMEOUT'`.

---

## Database Maintenance

### Checking for Stuck Escrows

```sql
SELECT id, status, created_at, updated_at
FROM escrow
WHERE status = 'HELD'
  AND created_at < NOW() - INTERVAL '3 hours'
ORDER BY created_at;
```

### EscrowStateLog Audit Trail

Every state transition is logged:
```sql
SELECT escrow_id, from_status, to_status, event_type, created_at, note
FROM escrow_state_log
WHERE escrow_id = 'ESC-...'
ORDER BY created_at;
```

---

## Log Events to Watch

| Log level | Message pattern | Action |
|---|---|---|
| ERROR | `Startup checks FAILED` | Check env vars and DB/Redis connectivity |
| ERROR | `recovery_sweep failed` | Redis may be down; check circuit breaker |
| WARNING | `Degraded mode ENABLED` | Auto-recovers in 60s; investigate cause |
| WARNING | `atomic_accept: NOSCRIPT` | Redis flushed scripts; non-critical, falls back to NX |
| WARNING | `log_idempotency_event failed` | Idempotency logging down; core functionality unaffected |
| ERROR | `Startup: Redis FAILED` | Redis unreachable at startup; check REDIS_URL |

---

## Incident Response

### Redis Outage
1. Bot continues with ephemeral fallback — active users are not disrupted within the same process
2. After recovery, existing sessions may see a "session reset" — expected behaviour
3. Check `GET /metrics/health` for `circuit_breaker.open: true`
4. No action needed — circuit auto-resets after 30s of stable Redis

### Database Outage
1. Deal creation and payment confirmation will fail
2. Bot will return error messages to users
3. Check startup logs and `GET /health`
4. Restore database connection, then run `alembic upgrade head` to verify schema

### High Webhook Latency
1. Check `GET /metrics/health` for `alerts.webhook_latency: "warning"` or `"critical"`
2. Check if degraded mode is active (Claude calls may be slow)
3. Enable degraded mode manually if p95 > 2s: `redis-cli SET bot:degraded_mode "manual" EX 300`
4. Investigate Claude API response times or Railway resource limits
