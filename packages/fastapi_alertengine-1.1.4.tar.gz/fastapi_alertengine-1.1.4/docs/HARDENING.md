# Production Hardening Guide

This document describes the stability and resilience mechanisms built into AnchorFlow for 50k+ concurrent session operation.

---

## SafeRedis — Circuit Breaker + Ephemeral Fallback

**File:** `app/core/safe_redis.py`

### Problem
Redis is a single point of failure for all bot state. A Redis outage without fallback means all active sessions die.

### Solution
`SafeRedis` wraps `redis.Redis` with:

1. **Retry with backoff** — On `ConnectionError` or `TimeoutError`, retries up to 3 times with 50ms / 100ms / 200ms delays before giving up.

2. **Circuit breaker** — After 5 failures within 30 seconds, the circuit opens. All subsequent calls skip Redis entirely and go straight to the ephemeral store. The circuit auto-resets after 30 seconds.

3. **Ephemeral fallback** — `_EphemeralStore` is an in-memory dict with TTL support that mirrors the full Redis API surface used by the bot (get/set/hset/zadd/xadd/scan_iter/pipeline/etc.). During an outage, the bot continues operating — state is local to the process, not shared.

### Trade-offs
- Ephemeral state is not shared across processes/replicas. During failover, a user hitting a different pod will get a fresh session. This is acceptable — the bot is designed to handle new sessions gracefully.
- Ephemeral state is lost on process restart. After Redis recovers, users will be re-greeted.

### Usage
```python
from app.core.safe_redis import build_safe_redis

_redis = build_safe_redis(url=os.environ["REDIS_URL"], socket_timeout=1.0)
```

### Monitoring
```
GET /whatsapp-bot/metrics  →  circuit_status: {open, failures, threshold}
GET /metrics/health        →  circuit_breaker: {open, failures, threshold}
```

---

## Idempotency — TTL Registry + Audit Stream

**File:** `app/core/idempotency.py`

### Problem
WhatsApp webhooks can deliver the same message multiple times. Payment callbacks can fire more than once. Without dedup, a user could place multiple orders from one tap.

### Solution
All Redis TTL constants are centralised in `idempotency.py`. No handler hardcodes a TTL value — they import from this registry. This prevents TTL drift.

Key TTLs:
| Constant | Value | Purpose |
|---|---|---|
| `TTL_ACTIVE_SESSION` | 86400 (24h) | State key for active deal |
| `TTL_IDLE_SESSION` | 7200 (2h) | State key for idle user |
| `TTL_STATE_LOCK` | 5s | Mutex on concurrent webhooks |
| `TTL_DEDUP_MESSAGE` | 300 (5min) | MessageSid dedup |
| `TTL_PAYMENT_LOCK` | 86400 (24h) | Payment ref dedup |
| `TTL_DEAL_DEDUP` | 180 (3min) | Deal creation dedup |

`log_idempotency_event()` writes a structured entry to `idempotency:events` (Redis Stream, MAXLEN 10k). Never raises — idempotency logging must never block the hot path.

---

## Courier Fence — Atomic First-Accept-Wins

**File:** `app/core/courier_fence.py`

### Problem
When a deal is broadcast to N couriers simultaneously, multiple couriers can accept within the same millisecond. A plain `SET NX` can produce double-assignments under high load because the read-check-write is not atomic.

### Solution
A monotonic fence counter per deal, operated via Lua script:

```
KEYS[1] = bot:courier_fence:{deal_id}   (integer counter)
KEYS[2] = bot:courier_accept:{deal_id}  (JSON lock value)
ARGV[1] = expected fence token (from broadcast job)
ARGV[2] = lock value JSON (courier_phone, assigned_at, fence_token)
ARGV[3] = TTL seconds

Returns: "ok" | "taken" | "stale"
```

The Lua script atomically:
1. Reads current fence value
2. Rejects if it doesn't match the expected token ("stale" — deal re-broadcast since job was issued)
3. Checks for existing lock ("taken" — another courier already won)
4. Sets the lock (NX)
5. Verifies it won (handles concurrent Lua execution on Redis cluster)
6. Increments the fence to invalidate all in-flight accepts with the old token

**Fallback:** If Lua is unavailable (NOSCRIPT), falls back to plain `SET NX`. Correct but without the stale-token check.

---

## Load Shedding

**File:** `app/core/load_shedding.py`

### Problem
Under extreme load or Redis degradation, Claude AI calls (which take 200-800ms each) amplify latency across all concurrent sessions.

### Solution
`bot:degraded_mode` flag in Redis (60s TTL, auto-expiring). When set:
- `should_skip_claude()` returns `True` → bot falls back to keyword-only responses
- Non-critical background work is deferred

**Auto-detection:** `is_degraded()` probes Redis round-trip latency on each call (with `auto_detect=True`). If:
- Redis RTT > 150ms → sets degraded mode flag, returns True
- Payment queue depth > 1000 items → same

**Manual control:**
```python
set_degraded_mode(_redis, True, reason="deploy_in_progress")
set_degraded_mode(_redis, False)   # clears immediately
```

**Recovery:** The 60s TTL means the system self-heals within one minute after conditions improve — no manual intervention required.

---

## Metrics Stream

**File:** `app/core/metrics.py`

All operational metrics are written to `metrics:events` (Redis Stream, MAXLEN 50k). This provides:

- **Non-blocking writes** — `xadd` is O(1), never raises
- **Time-windowed reads** — `XREVRANGE` reads last N entries for aggregation
- **p95 latency** — computed in `aggregate_metrics()` by sorting the window

Metric types recorded:
| Type | Fields |
|---|---|
| `webhook_latency` | `latency_ms` |
| `payment_processing_time` | `ref`, `duration_ms` |
| `courier_acceptance_time` | `deal_id`, `courier_phone`, `duration_ms` |
| `redis_failure` | `operation`, `error` |
| `state_transition_failure` | `from_state`, `to_state`, `phone_hash` |

All phone values are stored as `hash(phone) % 100_000` — never raw phone numbers in metrics.

---

## Session Recovery Sweep

**File:** `app/routers/recovery.py`

**Endpoint:** `POST /recovery/sweep`

Scans `bot:state:*` keys and resets provably orphaned sessions. An orphan is a session in an at-risk state for longer than its configured threshold:

| State | Threshold | Fallback |
|---|---|---|
| `awaiting_payment` | 2h | idle |
| `deal_created` | 2h | idle |
| `ordering` | 30min | browsing |
| `delivery_in_progress` | 24h | idle |
| `courier_matching` | 1h | idle |

**Safety:** Never deletes sessions — only resets state. Order snapshots (in `bot:order:{phone}`) are preserved when falling back to `browsing`.

**Recommended:** Run via cron every 15 minutes.
