<img src="assets/tofamba_logo.png" alt="AnchorFlow — Tofamba. Paid. Delivered. Done." width="400"/>

# AnchorFlow Architecture

## Overview

AnchorFlow is a trust-as-an-API escrow platform for Zimbabwean commerce. It orchestrates multi-party commerce transactions — buyer, merchant, and courier — entirely over WhatsApp, using Twilio for messaging, Paynow Zimbabwe for payments, and PostgreSQL + Redis for state.

**Tofamba is an observer/orchestrator — it never holds funds.** It instructs wallet providers (Paynow, EcoCash, InnBucks, Omari) and records state. The escrow concept is logical, not custodial.

---

## Stack

| Layer | Technology |
|---|---|
| API framework | FastAPI (Python 3.11+) |
| Database | PostgreSQL via SQLAlchemy 2.x |
| Cache / state | Redis 7+ (SafeRedis wrapper with circuit breaker) |
| Messaging | Twilio WhatsApp Business API |
| Payments | Paynow Zimbabwe Send Money API |
| Deployment | Railway (auto-deploy from main branch) |
| Migrations | Alembic |

---

## Request Flow

```
WhatsApp user
     │
     ▼
Twilio webhook → POST /whatsapp-bot/webhook
     │
     ├─ Dedup check (MessageSid NX, 5-min TTL)
     ├─ State lock acquire (bot:state_lock:{phone}, 5s TTL)
     ├─ Load shedding check (should_skip_claude?)
     │
     ▼
BotState machine (26 states)
     │
     ├─ Redis state reads/writes (SafeRedis)
     ├─ DB reads/writes (SQLAlchemy, get_db())
     ├─ Claude AI calls (skipped in degraded mode)
     │
     ▼
Twilio reply → WhatsApp user
```

Paynow payment webhooks arrive at `POST /whatsapp-bot/payment-webhook` and advance the escrow state machine independently.

---

## Bot State Machine (26 States)

```
START
  └─► IDLE
        └─► BROWSING
              └─► SELECTING_MERCHANT
                    └─► VIEWING_CATALOGUE
                          └─► ORDERING
                                └─► CONFIRMING_ORDER
                                      └─► AWAITING_PAYMENT
                                            └─► DEAL_CREATED
                                                  └─► COURIER_MATCHING
                                                        └─► COURIER_ASSIGNED
                                                              └─► DELIVERY_IN_PROGRESS
                                                                    └─► AWAITING_PIN
                                                                          ├─► DEAL_COMPLETE
                                                                          └─► PIN_FAILED (→ retry or escalate)

Parallel flows:
  MERCHANT_PORTAL → MERCHANT_INVENTORY_MGMT → MERCHANT_CATALOGUE_EDIT
  COURIER_PORTAL  → COURIER_AVAILABLE       → COURIER_ON_JOB
```

State is stored in Redis: `bot:state:{phone}` with TTL (24h active, 2h idle).
Timestamp: `bot:state_ts:{phone}` — used by the recovery sweep for orphan detection.

---

## Redis Key Schema

| Key pattern | Type | TTL | Purpose |
|---|---|---|---|
| `bot:state:{phone}` | String | 24h / 2h | Current bot state |
| `bot:state_ts:{phone}` | String | 24h / 2h | State last-set timestamp |
| `bot:state_lock:{phone}` | String | 5s | Mutex for concurrent webhooks |
| `bot:active_deal:{phone}` | String | 24h | Deal ID for recovery |
| `bot:order:{phone}` | String | 24h | In-progress order JSON (zlib if >2KB) |
| `bot:degraded_mode` | String | 60s | Load-shedding flag |
| `bot:payment_queue_len` | String | — | Payment queue depth counter |
| `bot:courier_fence:{deal_id}` | String | 30min | Monotonic fence counter |
| `bot:courier_accept:{deal_id}` | String | 30min | First-accept-wins lock |
| `merchant_catalogue:{slug}` | String | 24h | Cached catalogue JSON |
| `payment_processed:{ref}` | String | 24h | Payment dedup key |
| `msg:{MessageSid}` | String | 5min | Message dedup key |
| `ledger:payment:{ref}` | String | 24h | Idempotency ledger |
| `metrics:events` | Stream | MAXLEN 50k | Structured metrics |
| `idempotency:events` | Stream | MAXLEN 10k | Idempotency audit log |

---

## Escrow State Machine

Database model: `Escrow` table in `app/models/database.py`

```
HELD
  ├─► RELEASED  (PIN confirmed by courier)
  └─► EXPIRED
        └─► REVERSAL_INITIATED
              └─► REVERSAL_CONFIRMED
```

- Escrow timeout: 2 hours (configurable via `ESCROW_TIMEOUT_HOURS`)
- Timeout job: `EscrowTimeoutJob` runs every 5 minutes, HELD → EXPIRED
- Reversal: `PaynowWalletAdapter.reverse_transaction()` → REVERSAL_INITIATED → REVERSAL_CONFIRMED

---

## Adapter Pattern

All payment providers implement `WalletAdapter` (abstract base):

```python
class WalletAdapter(ABC):
    def reverse_transaction(self, instruction: Dict) -> Dict: ...
    def query_transaction_status(self, tx_id: str) -> Dict: ...
```

Concrete adapters: `PaynowWalletAdapter`, `EcoCashWalletAdapter`, `InnBucksWalletAdapter`, `OmariWalletAdapter`.
Fiscal adapters: `FiscalAdapter` → `MockFiscalAdapter`, `ZimraFiscalAdapter`.

---

## Fee Model

- Platform commission: **3.5%** of deal value
- VAT on commission: **15.5%** (applied to the 3.5% only)
- IMTT (2%): levied by wallet providers — Tofamba is observer only, does not collect
- Merchant receives: `deal_amount × (1 - 0.035) - courier_fee`
- Courier receives: `courier_fee` (set at deal creation)

---

## Component Map

```
app/
  routers/
    whatsapp_bot.py     — Main webhook handler, state machine
    deals.py            — Deal CRUD endpoints
    inventory.py        — Merchant inventory endpoints
    merchant_portal.py  — Merchant-facing portal (catalogue mgmt, pagination)
    recovery.py         — Session recovery sweep
    metrics_router.py   — /metrics/health, /metrics/export
  core/
    safe_redis.py       — Circuit-breaker Redis wrapper
    idempotency.py      — TTL registry, audit stream
    courier_fence.py    — Atomic first-accept-wins Lua lock
    load_shedding.py    — Degraded mode detection and management
    metrics.py          — Structured metrics to Redis Stream
  services/
    merchant_catalogue_local.py  — Catalogue cache + pagination
    escrow_timeout_engine.py     — 2-hour timeout job
    settlement_engine.py         — Post-delivery payout logic
  adapters/
    wallet_adapter.py            — Abstract base
    paynow_wallet_adapter.py     — Live Paynow integration
    ecocash_wallet_adapter.py    — Stub (not yet live)
    innbucks_wallet_adapter.py   — Stub (not yet live)
    omari_wallet_adapter.py      — Stub (not yet live)
    mock_wallet_adapter.py       — Test double
  startup/
    health_check.py     — Startup verification suite
  models/
    database.py         — SQLAlchemy models
  config.py             — Settings dataclass, env var loading
security/
  pii_handler.py        — Phone/email masking for logs
  pin_verification.py   — SHA-256 PIN verification with lockout
migrations/             — Alembic migration scripts
docs/                   — This directory
```
