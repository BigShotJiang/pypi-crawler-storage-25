<img src="assets/tofamba_logo.png" alt="AnchorFlow — Tofamba. Paid. Delivered. Done." width="400"/>

# AnchorFlow — Complete System Specification

> Version 1.0 · Production Release · Zimbabwe (SADC)
>
> *"Paid. Delivered. Done."*

---

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Architecture Layers](#2-architecture-layers)
3. [Message Processing Flow](#3-message-processing-flow)
4. [State Machine Definition](#4-state-machine-definition)
5. [Redis Keyspace Specification](#5-redis-keyspace-specification)
6. [PostgreSQL Schema Usage](#6-postgresql-schema-usage)
7. [Payment Flow](#7-payment-flow)
8. [Courier Flow](#8-courier-flow)
9. [Failure Handling Strategy](#9-failure-handling-strategy)
10. [Scalability Design](#10-scalability-design)
11. [Degraded Mode](#11-degraded-mode)
12. [Security & Idempotency](#12-security--idempotency)

---

## 1. System Overview

### What is AnchorFlow?

AnchorFlow is a **WhatsApp-native commerce platform** built for the Zimbabwean and broader SADC market. It connects customers, merchants, and couriers entirely through WhatsApp conversations, with Paynow Zimbabwe handling payment rails.

It operates as a **trust orchestration layer** — it never holds funds directly. Instead, it:
- Coordinates multi-party deals (buyer → merchant → courier)
- Monitors payment state via Paynow webhooks
- Releases funds to merchants and couriers upon verified delivery
- Provides escrow protection: buyer money is logically held until the courier PIN is confirmed

### Core Value Proposition

| Problem | AnchorFlow Solution |
|---|---|
| Buyers don't trust paying before delivery | Logical escrow holds funds until delivery PIN is confirmed |
| Merchants can't verify payment before shipping | Payment confirmation webhook advances state to DEAL_CREATED before courier is dispatched |
| Courier fraud / double-assignment | Atomic Lua fence prevents two couriers accepting the same job |
| No infrastructure for commerce in SADC | Entire UX runs over WhatsApp — zero app install required |

### End-to-End Summary

```
Customer sends WhatsApp message
  → Twilio delivers to AnchorFlow webhook
  → Webhook deduplicates, rate-limits, locks
  → BotEngine reads Redis state, dispatches to handler
  → Handler produces next state + response text
  → BotEngine writes new state to Redis
  → TwiML response returns text to customer
  → (On payment confirmation) Paynow calls payment webhook
  → BotEngine advances state, notifies customer, broadcasts to couriers
  → Courier accepts via atomic fence
  → Courier confirms delivery with PIN
  → Funds released to merchant + courier
```

---

## 2. Architecture Layers

```
┌─────────────────────────────────────────────────────────────────────────┐
│  TRANSPORT LAYER                                                         │
│                                                                          │
│  Customer WhatsApp ──► Twilio Business API ──► POST /webhook/whatsapp   │
│  Paynow Zimbabwe   ──────────────────────────► POST /webhook/payment    │
└──────────────────────────────┬──────────────────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────────────┐
│  WEBHOOK CONTROLLER  (app/routers/webhook_controller.py)                 │
│                                                                          │
│  • Parse Twilio Form / Paynow Form                                       │
│  • Deduplication     → bot:dedup:{MessageSid}                           │
│  • Rate limiting     → bot:rate:{phone}  (20/60s)                       │
│  • Token-safe lock   → bot:state_lock:{phone}                           │
│  • Deal lock (pmt)   → bot:deal_lock:{ref}                              │
│  • Timeout guard     → asyncio.wait_for(10s)                            │
│  • Return TwiML / "OK"                                                   │
└──────────────────────────────┬──────────────────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────────────┐
│  BOT RUNTIME (app/bot/)                                                  │
│                                                                          │
│  BotEngine.process_message(phone, text)                                  │
│  BotEngine.process_event(event_type, payload)                            │
│                                                                          │
│  RedisStateManager  — ALL Redis I/O (no scattered calls)                 │
│  TokenLock          — Lua-based token-safe distributed locks             │
│                                                                          │
│  Handler dispatch:                                                       │
│    browsing.py      → START, IDLE, BROWSING                             │
│    ordering.py      → ORDERING, CONFIRMING_ORDER                        │
│    payment_wait.py  → AWAITING_PAYMENT                                  │
│    courier_flow.py  → DEAL_CREATED, COURIER_MATCHING,                   │
│                        COURIER_ASSIGNED, DELIVERY_IN_PROGRESS,           │
│                        AWAITING_PIN, DEAL_COMPLETE                       │
└──────────────┬──────────────────────────┬───────────────────────────────┘
               │                          │
┌──────────────▼──────────┐  ┌────────────▼──────────────────────────────┐
│  REDIS 7+               │  │  POSTGRESQL (SQLAlchemy 2.x)               │
│                         │  │                                            │
│  Ephemeral state:       │  │  Durable records:                          │
│  • Bot state / role     │  │  • merchants                               │
│  • Session locks        │  │  • merchant_inventory                      │
│  • Payment dedup        │  │  • deals                                   │
│  • Courier fence        │  │  • escrows + escrow_state_log              │
│  • Catalogue cache      │  │  • payment_ledger                          │
│  • Metrics stream       │  │                                            │
│  • Idempotency log      │  │  Written on:                               │
│                         │  │  • deal creation                           │
│  SafeRedis wrapper:     │  │  • payment confirmation                    │
│  • Circuit breaker      │  │  • escrow state transitions                │
│  • Retry backoff        │  │  • delivery PIN verification               │
│  • Ephemeral fallback   │  │                                            │
└─────────────────────────┘  └────────────────────────────────────────────┘
```

### Infrastructure Stack

| Component | Technology | Purpose |
|---|---|---|
| API framework | FastAPI (Python 3.11+) | HTTP / async handlers |
| Database | PostgreSQL + SQLAlchemy 2.x | Durable financial records |
| Cache / state | Redis 7+ (SafeRedis) | Session state + orchestration |
| Messaging | Twilio WhatsApp Business | Send/receive WhatsApp |
| Payments | Paynow Zimbabwe | Mobile money rails |
| Deployment | Railway | Auto-deploy from main branch |
| Migrations | Alembic | Schema versioning |

---

## 3. Message Processing Flow

### Step-by-Step: Customer Sends "hi"

```
Step 1 — Transport
  Customer types "hi" on WhatsApp
  Twilio POSTs to: POST /webhook/whatsapp
  Form fields: From="whatsapp:+263771234567", Body="hi", MessageSid="SMxxx"

Step 2 — Deduplication
  RedisStateManager.is_duplicate("SMxxx")
  Redis: SETNX bot:dedup:SMxxx "1"
  → Returns 1 (new) → proceed
  Redis: EXPIRE bot:dedup:SMxxx 300

Step 3 — Rate limiting
  RedisStateManager.is_rate_limited("+263771234567")
  Redis: INCR bot:rate:+263771234567 → count=1
  Redis: EXPIRE bot:rate:+263771234567 60  (only on count==1)
  count(1) ≤ 20 → proceed

Step 4 — Token-safe lock
  sm.acquire_lock("+263771234567")
  TokenLock: SET bot:state_lock:+263771234567 {token} NX EX 5
  → Returns token "a3f1..." → proceed

Step 5 — BotEngine.process_message
  emit("message_received", {phone_hash, message_len})
  sm.get_state("+263771234567") → "START"  (Redis GET bot:state:...)
  sm.get_role("+263771234567")  → "customer"

  Claude enrichment check:
    should_skip_claude() → False (Redis healthy, not degraded)
    _enrich_with_claude("hi", "START") → "hi"  (no mapping needed)

  _HANDLER_MAP["START"] → handle_browsing

Step 6 — Handler execution
  handle_browsing(phone, "hi", sm, db)
  state == "START", text == "hi" → matches greeting branch
  → sm.set_state("+263771234567", "BROWSING")
  → returns HandlerResult(next_state="BROWSING", response=_GREETING)

Step 7 — State write
  sm.set_state("+263771234567", "BROWSING")
  Redis: SETEX bot:state:+263771234567 7200 "BROWSING"
  Redis: SETEX bot:state_ts:+263771234567 7200 "1700000000"
  emit("state_transition", {from: START, to: BROWSING, phone_hash, duration_ms})

Step 8 — Metrics
  record_webhook_latency(rdb, 45.2)
  log_idempotency_event(rdb, "state_dispatch", "bot:state:...", {...})

Step 9 — Lock release
  sm.release_lock("+263771234567", "a3f1...")
  Lua: GET bot:state_lock:+263771234567 == "a3f1..." → DEL

Step 10 — TwiML response
  <?xml version="1.0" encoding="UTF-8"?>
  <Response>
    <Message>👋 Welcome to AnchorFlow...</Message>
  </Response>
  HTTP 200 → Twilio → Customer WhatsApp
```

### Timing Budget

| Step | Target | Hard limit |
|---|---|---|
| Dedup + rate limit | < 5ms | 50ms |
| Claude enrichment | < 800ms | 3s (timeout) |
| Handler execution | < 500ms | 8s (timeout) |
| Total webhook | < 2s | 10s (timeout) |
| Twilio hard limit | — | 15s |

---

## 4. State Machine Definition

### State Diagram

```
                          ┌─────────────────────────────────┐
                          │           USER ENTRY            │
                          └───────────────┬─────────────────┘
                                          │ any message
                                          ▼
                                       ┌─────┐
                                       │START│
                                       └──┬──┘
                                          │ greeting / any
                                          ▼
                                      ┌───────┐
                             ┌────────│BROWSING│◄────────────┐
                             │        └───┬───┘              │
                             │            │ merchant selected │
                             │            ▼                   │
                             │        ┌────────┐    "back"   │
                             │        │ORDERING│─────────────┘
                             │        └────┬───┘
                             │             │ "checkout"
                             │             ▼
                             │    ┌────────────────┐
                             │    │CONFIRMING_ORDER│
                             │    └───────┬────────┘
                             │            │ "yes"
                             │            ▼
                             │    ┌────────────────┐
                             │    │AWAITING_PAYMENT│◄─────(Paynow pending)
                             │    └───────┬────────┘
                             │            │ Paynow webhook confirmed
                             │            ▼
                             │     ┌────────────┐
                             │     │DEAL_CREATED│
                             │     └─────┬──────┘
                             │           │ courier broadcast sent
                             │           ▼
                             │   ┌────────────────┐
                             │   │COURIER_MATCHING│
                             │   └───────┬────────┘
                             │           │ atomic_accept "ok"
                             │           ▼
                             │  ┌─────────────────┐
                             │  │COURIER_ASSIGNED │
                             │  └────────┬────────┘
                             │           │ "collected"
                             │           ▼
                             │  ┌──────────────────────┐
                             │  │DELIVERY_IN_PROGRESS  │
                             │  └────────┬─────────────┘
                             │           │ "delivered"
                             │           ▼
                             │      ┌────────────┐
                             │      │AWAITING_PIN│
                             │      └─────┬──────┘
                             │            │ PIN verified
                             │            ▼
                             │     ┌───────────────┐
                             └────►│ DEAL_COMPLETE │
                                   └───────────────┘

Merchant role:          MERCHANT_PORTAL ──► (inventory / orders)
Courier role (idle):    COURIER_PORTAL  ──► COURIER_MATCHING
```

### State Reference

| State | Who | Description | Max Duration |
|---|---|---|---|
| `START` | Any | Entry point, no active session | N/A |
| `IDLE` | Any | Session exists, no active deal | 2h TTL |
| `BROWSING` | Customer | Viewing merchant list | 2h TTL |
| `ORDERING` | Customer | Building basket in a catalogue | 2h TTL |
| `CONFIRMING_ORDER` | Customer | Confirming basket before payment | 2h TTL |
| `AWAITING_PAYMENT` | Customer | Payment link sent, waiting for Paynow | 2h (escrow timeout) |
| `DEAL_CREATED` | Customer | Payment confirmed, finding courier | 24h TTL |
| `COURIER_MATCHING` | Courier | Job broadcast received, deciding | 30min (job TTL) |
| `COURIER_ASSIGNED` | Courier | Job accepted, heading to pickup | 24h TTL |
| `DELIVERY_IN_PROGRESS` | Courier | Parcel collected, en route | 24h TTL |
| `AWAITING_PIN` | Courier + Customer | Delivery complete, PIN exchange | 24h TTL |
| `DEAL_COMPLETE` | Any | PIN verified, funds released | Terminal |
| `MERCHANT_PORTAL` | Merchant | Inventory / order management | 24h TTL |
| `COURIER_PORTAL` | Courier | Available, waiting for jobs | 24h TTL |

### Transition Rules

| From | To | Trigger | Guard |
|---|---|---|---|
| START | BROWSING | Any message | — |
| BROWSING | ORDERING | Merchant selected | Catalogue must exist |
| BROWSING | MERCHANT_PORTAL | "2" / "sell" | — |
| BROWSING | COURIER_PORTAL | "3" / "deliver" | — |
| ORDERING | CONFIRMING_ORDER | "checkout" | Basket must be non-empty |
| ORDERING | BROWSING | "back" / "0" | — |
| CONFIRMING_ORDER | AWAITING_PAYMENT | "yes" | Deal ref created |
| CONFIRMING_ORDER | BROWSING | "no" | Basket cleared |
| AWAITING_PAYMENT | DEAL_CREATED | Paynow webhook confirmed | Idempotency dedup |
| AWAITING_PAYMENT | BROWSING | "cancel" + confirm | — |
| DEAL_CREATED | COURIER_MATCHING | Courier broadcast sent | Courier must be COURIER_PORTAL |
| COURIER_MATCHING | COURIER_ASSIGNED | `atomic_accept` "ok" | Lua fence token valid |
| COURIER_ASSIGNED | DELIVERY_IN_PROGRESS | "collected" | — |
| DELIVERY_IN_PROGRESS | AWAITING_PIN | "delivered" | — |
| AWAITING_PIN | DEAL_COMPLETE | PIN correct | SHA-256 match |
| AWAITING_PIN | COURIER_PORTAL | 3 PIN failures | Lockout |
| Any | START | `recovery_sweep` orphan | Age > threshold |

### Invalid Transition Handling

If `bot:state:{phone}` contains a value not in `_HANDLER_MAP`:
1. `record_state_transition_failure()` is called → written to `metrics:events`
2. `emit("state_invalid", {...})` is written to `metrics:events`
3. State is reset to `START` in Redis
4. User receives a welcome-back message
5. Session continues normally from START

---

## 5. Redis Keyspace Specification

All keys managed by `RedisStateManager`. No other module writes these keys directly.

### Session State

| Key | Type | TTL | Example Value | Purpose |
|---|---|---|---|---|
| `bot:state:{phone}` | String | 24h (active) / 2h (idle) | `"ORDERING"` | Current bot state |
| `bot:state_ts:{phone}` | String | Same as state | `"1700000000"` | State last-set epoch (recovery sweep) |
| `bot:role:{phone}` | String | 7 days | `"customer"` | User role: customer / merchant / courier |
| `bot:order:{phone}` | String | 24h | `{"items":[...],"total":15.00}` (zlib if >2KB) | In-progress order snapshot |
| `bot:active_deal:{phone}` | String | 24h | `"TDM-7G4K9"` | Current deal ID for recovery |

### Locking

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `bot:state_lock:{phone}` | String (token) | 5s | Per-phone message serialisation |
| `bot:deal_lock:{deal_id}` | String (token) | 30s | Per-deal payment / courier serialisation |

Lock values are UUID hex tokens. Release uses Lua to match token before DEL — prevents accidental unlock after expiry and re-issue.

### Deduplication & Rate Limiting

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `bot:dedup:{MessageSid}` | String | 5 min | WhatsApp message dedup (Twilio retries) |
| `bot:rate:{phone}` | String (counter) | 60s | Rate limit: 20 msgs / 60s per phone |
| `payment_processed:{ref}` | String | 24h | Payment webhook idempotency |

### Temporary Session Values

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `bot:temp:{phone}:merchants` | String (JSON) | 24h | Cached merchant list for this session |
| `bot:temp:{phone}:merchant_slug` | String | 24h | Selected merchant slug |
| `bot:temp:{phone}:merchant_name` | String | 24h | Selected merchant name |
| `bot:temp:{phone}:cancel_intent` | String | 24h | Cancellation confirmation flag |

### Payment & Deals

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `bot:deal_ref:{paynow_ref}` | String | 24h | Paynow reference → customer phone |
| `ledger:payment:{ref}` | String | 24h | Idempotency ledger for payments |

### Courier

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `bot:courier_job:{courier_phone}` | String (JSON) | 30 min | Active job payload for this courier |
| `bot:courier_fence:{deal_id}` | String (int) | 30 min | Monotonic fence counter (atomic accept) |
| `bot:courier_accept:{deal_id}` | String (JSON) | 30 min | First-accept winner lock (Lua fence) |
| `bot:courier_lock:{deal_id}` | String | 30 min | NX lock (fallback when Lua unavailable) |

### Catalogue

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `merchant_catalogue:{slug}` | String (JSON) | 24h | Cached merchant catalogue |

### Observability & Load Shedding

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `metrics:events` | Stream | MAXLEN 50k | Structured operational metrics |
| `idempotency:events` | Stream | MAXLEN 10k | Deduplication audit trail |
| `bot:degraded_mode` | String | 60s (auto-expire) | Load-shedding flag |
| `bot:payment_queue_len` | String | — | Payment queue depth counter |

---

## 6. PostgreSQL Schema Usage

### `merchants`

Stores registered merchants with their business details.

Used by:
- `handle_browsing()` — loads active merchant list (`is_active = True`)
- `warm_catalogue_cache()` — loads merchant inventory to Redis

Key columns: `business_name`, `slug`, `phone`, `is_active`, `category`

### `merchant_inventory`

Items a merchant has listed for sale.

Used by:
- Catalogue warming: loads items into `merchant_catalogue:{slug}`
- `handle_ordering()` reads items from Redis cache (DB is source of truth for warm)

Key columns: `merchant_id`, `name`, `price`, `is_available`, `image_url`

### `escrows`

**The financial core.** One row per deal. Immutable monetary breakdown.

```
escrows
  id                    — primary key
  order_id              — links to order
  status                — HELD | DELIVERED | RELEASED | EXPIRED | REVERSAL_*
  total_escrow          — buyer payment amount (USD)
  merchant_final_payout — amount merchant receives after fees
  courier_final_payout  — amount courier receives after fees
  total_tandem_fee      — platform revenue (3.5%)
  total_imtt_tax        — IMTT tax (2%, observed only)
  pin_hash              — SHA-256(delivery_pin) — never plaintext
  wallet_provider       — "paynow" | "ecocash" | etc
  external_transaction_id — Paynow reference
  expiry_timestamp      — created_at + 2 hours
```

State transitions (recorded in `escrow_state_log`):
- Created → `HELD` on payment confirmation
- `HELD` → `RELEASED` on PIN verification (`escrow_release.py`)
- `HELD` → `EXPIRED` by `EscrowTimeoutJob` after 2 hours
- `EXPIRED` → `REVERSAL_INITIATED` → `REVERSAL_CONFIRMED` by timeout engine

### `escrow_state_log`

Append-only audit trail of every escrow state change.

```
escrow_state_log
  escrow_id     — FK to escrows
  from_status   — previous EscrowStatus
  to_status     — new EscrowStatus
  event_type    — "PAYMENT" | "PIN_VERIFIED" | "TIMEOUT" | "DISPUTE"
  note          — human-readable context
  created_at    — UTC timestamp
```

### `payment_ledger` (planned)

Idempotency ledger for every payment event, linking Paynow reference to escrow state.
Prevents duplicate state advances if Paynow retries webhooks.

---

## 7. Payment Flow

### Complete Payment Lifecycle

```
1. DEAL CREATION
   ─────────────
   Customer types "checkout" → handle_confirming()
   → _generate_deal_ref(phone) → "TDM-7G4K9"
   → sm.map_deal_ref("TDM-7G4K9", phone)   (bot:deal_ref:TDM-7G4K9 = phone)
   → sm.set_active_deal(phone, "TDM-7G4K9")
   → sm.set_state(phone, "AWAITING_PAYMENT")
   → Response: "Send US$15.00 to Paynow ref TDM-7G4K9"

2. PAYMENT INSTRUCTION
   ────────────────────
   Customer opens EcoCash / Paynow
   Sends US$15.00 to merchant Paynow number
   Reference: TDM-7G4K9

3. PAYNOW WEBHOOK (payment confirmation)
   ──────────────────────────────────────
   Paynow → POST /webhook/payment
     reference=TDM-7G4K9&status=Sent&hash=...

   WebhookController:
   → Respond "OK" immediately (async background task)
   → _process_payment_confirmed("TDM-7G4K9", "Sent")

   Background task:
   → Dedup: SETNX payment_processed:TDM-7G4K9 → new
   → Deal lock: acquire bot:deal_lock:TDM-7G4K9 (token-safe)
   → Resolve: GET bot:deal_ref:TDM-7G4K9 → "+263771234567"
   → BotEngine.process_event("payment_confirmed", {phone, ref})

4. STATE ADVANCE
   ──────────────
   _on_payment_confirmed():
   → Check state == "AWAITING_PAYMENT" ✓
   → sm.set_state(phone, "DEAL_CREATED")
   → init_fence(rdb, ref)   ← initialise courier fence
   → emit("payment_confirmed", {ref, phone_hash})
   → log_idempotency_event(...)

5. CUSTOMER NOTIFICATION
   ──────────────────────
   _send_whatsapp_async(phone, "✅ Payment received! Finding a courier...")
   Customer receives WhatsApp notification

6. COURIER BROADCAST
   ──────────────────
   (Separate system / cron) reads DEAL_CREATED sessions
   → process_event("courier_job_broadcast", {courier_phone, deal_id, ...})
   → Courier receives: "🚚 New delivery job! Pickup: X, Dropoff: Y, Fee: $5"
```

### Payment Idempotency

```
First webhook:   SETNX payment_processed:TDM-7G4K9 → 1 → proceed
Second webhook:  SETNX payment_processed:TDM-7G4K9 → 0 → silently ignore
```

Paynow is known to retry webhooks on non-2xx responses. Responding immediately with "OK" before processing (backgrounded) prevents retries. The `setnx` dedup prevents double-processing if both the initial and a retry reach the background processor.

---

## 8. Courier Flow

### Complete Courier Lifecycle

```
1. COURIER GOES ONLINE
   ────────────────────
   Courier: "deliver" → sm.set_role("courier"), sm.set_state("COURIER_PORTAL")
   Courier is now discoverable for job broadcast

2. JOB BROADCAST
   ────────────────
   New DEAL_CREATED session exists (payment confirmed)
   BotEngine.process_event("courier_job_broadcast", {
     courier_phone:  "+263772000001",
     deal_id:        "TDM-7G4K9",
     fence_token:    "0",               ← current fence value
     pickup_address: "12 Samora Machel, Harare",
     drop_address:   "45 Borrowdale Rd, Harare",
     courier_fee:    "5.00",
     customer_phone: "+263771234567",
   })
   → sm.save_courier_job(courier_phone, job_data)
   → sm.set_state(courier_phone, "COURIER_MATCHING")
   → Courier receives WhatsApp: "🚚 New job! Reply 1 to accept, 2 to skip"

3. COURIER ACCEPTS (atomic fence)
   ──────────────────────────────
   Courier types "1" → handle_courier_matching()

   atomic_accept(rdb, "TDM-7G4K9", courier_phone, expected_fence="0")

   Lua executes atomically:
     GET bot:courier_fence:TDM-7G4K9 → "0"   (exists → not expired)
     "0" == "0"                               (token matches → not stale)
     GET bot:courier_accept:TDM-7G4K9 → nil  (not taken)
     SET bot:courier_accept:TDM-7G4K9 {courier_phone, ts, token} NX EX 1800
     GET bot:courier_accept:TDM-7G4K9 == lock_val → we won!
     INCR bot:courier_fence:TDM-7G4K9 → "1"  (invalidates other in-flight accepts)
     return "ok"

   Result "ok":
   → sm.set_state(courier_phone, "COURIER_ASSIGNED")
   → Courier receives: "✅ Job accepted! Head to pickup..."

   Concurrent courier (arrives 1ms later):
   Lua: GET bot:courier_fence:TDM-7G4K9 → "1" (already incremented)
   "1" ≠ "0" → return "stale"
   → sm.set_state(other_courier, "COURIER_PORTAL")
   → Other courier receives: "Another courier got there first."

4. DELIVERY
   ──────────
   Courier: "collected" → sm.set_state("DELIVERY_IN_PROGRESS")
   Courier: "delivered" → sm.set_state(courier, "AWAITING_PIN")
                        → sm.set_state(customer, "AWAITING_PIN")

5. PIN VERIFICATION
   ──────────────────
   Customer receives 4-digit PIN (out-of-band — e.g. SMS, or shown in-app)

   Courier types PIN → handle_awaiting_pin()
   → PINVerification.verify_pin(deal_id, pin_input, courier_phone)
   → SHA-256(pin_input) == stored hash? ✓
   → sm.set_state(courier, "DEAL_COMPLETE")
   → emit("deal_complete", {deal_id})
   → SettlementEngine releases funds to merchant + courier wallets

6. FUND RELEASE
   ─────────────
   escrow_release.py:
   → Escrow.status: HELD → RELEASED
   → EscrowStateLog: event_type="PIN_VERIFIED"
   → PaynowWalletAdapter.send_payment(merchant_wallet, merchant_final_payout, ref)
   → PaynowWalletAdapter.send_payment(courier_wallet,  courier_final_payout,  ref)
```

### Fence States and Responses

| `atomic_accept` return | Meaning | Bot response |
|---|---|---|
| `"ok"` | Lock acquired, this courier won | "✅ Job accepted!" |
| `"taken"` | Another courier won | "Another courier got there first." |
| `"stale"` | Token mismatch (re-broadcast) | "Job no longer available." |
| `"expired"` | Fence key TTL elapsed (job gone) | "This job is no longer available." |
| `"error"` | Redis failure | "Error — please try again." |

---

## 9. Failure Handling Strategy

### Duplicate Messages

**Cause:** Twilio retries if it doesn't receive a 200 within 15 seconds.

**Mitigation:**
```
SETNX bot:dedup:{MessageSid} "1"  →  1 = new, 0 = duplicate
EXPIRE bot:dedup:{MessageSid} 300
```
Duplicate MessageSids receive an empty TwiML response (HTTP 200) — Twilio stops retrying.

---

### Redis Failure

**Symptom:** SafeRedis circuit breaker opens after 5 failures in 30s.

**Behaviour:**
1. All Redis calls route to `_EphemeralStore` (in-memory, per-process)
2. Bot continues operating — state is process-local during the outage
3. Users on different pods may see session reset — acceptable trade-off

**Recovery:**
- Circuit auto-resets 30s after last failure
- All methods fail-open: `get_state()` returns "START", `acquire_lock()` returns a token
- No customer-facing error unless Redis is down AND Claude is also down simultaneously

---

### Payment Delays

**Scenario:** Customer pays but Paynow webhook is delayed (up to 30 minutes).

**Mitigation:**
- State `AWAITING_PAYMENT` has 24h TTL — customer is not timed out
- Customer can type "status" to see current state + reference
- Escrow timeout is separate (2h on the *escrow record* in PostgreSQL, not on bot state)
- Recovery sweep does NOT reset AWAITING_PAYMENT sessions (threshold = 2h)

---

### Courier Conflicts (Double-Assignment)

**Scenario:** Two couriers accept the same job within the same millisecond.

**Mitigation:** Lua atomic fence:
```lua
GET fence → "0"            -- only one reads "0" first
"0" == expected_fence      -- token match
GET lock → nil             -- not yet taken
SET lock NX                -- atomic NX
GET lock == my_value?      -- did I win the NX race?
INCR fence                 -- invalidate all other in-flight accepts
return "ok"
```
The Lua script executes atomically on Redis. The second courier's Lua script sees the incremented fence (`"1"` ≠ `"0"`) and returns `"stale"`. **Zero double-assignments are possible while Redis is available.**

---

### Bot Restarts

**Scenario:** Railway deploy / crash kills the process.

**Mitigation:**
- All state is in Redis — not in process memory
- New process reads `bot:state:{phone}` and continues from where it left off
- In-flight locks (5s TTL, 30s TTL) expire automatically — no deadlocks
- Ephemeral store state (during Redis outage) is lost — users see START on reconnect

---

### Concurrent Messages (Same Phone)

**Scenario:** User double-taps send; Twilio delivers two copies simultaneously.

**Mitigation:**
1. `bot:dedup:{MessageSid}` catches exact duplicate messages
2. `bot:state_lock:{phone}` (token-safe, 5s TTL) serialises concurrent processing
3. Second message receives "Still processing your last message — just a second!"

---

## 10. Scalability Design

### Stateless Application Layer

```
BotEngine is instantiated per-request.
No class-level mutable state.
No in-process caches for business data (only Redis).
Two concurrent requests for different phones: fully parallel.
Two concurrent requests for same phone: serialised via Redis lock.
```

### Redis as State Layer

```
All session state lives in Redis.
Each bot instance reads from and writes to the same Redis cluster.
Adding N more Railway instances → N more request processors.
Redis connection pool (per instance) handles multiplexing.
```

### Horizontal Scaling Strategy

```
Current (single Railway instance):
  1 process × N concurrent async requests

Scale-out path:
  1. Add Railway replicas (same Redis, same PostgreSQL)
  2. Redis lock prevents same-phone conflicts across replicas
  3. Payment webhook: backgrounded + idempotency dedup prevents double-processing
  4. Courier fence: Lua script is atomic regardless of which replica runs it

Target: 50,000 concurrent sessions
  Redis: ~50k keys × ~500 bytes = ~25 MB (negligible)
  Request throughput: ~10k/min (assuming 1 msg/3s average per session)
  Redis ops/sec: ~100k (well within Redis single-node capacity)
```

### Bottlenecks and Mitigations

| Bottleneck | Mitigation |
|---|---|
| Claude API latency (200-800ms) | Load shedding: disabled in degraded mode; 3s timeout |
| Redis single point of failure | SafeRedis circuit breaker + ephemeral fallback |
| Twilio 15s webhook timeout | 10s internal timeout + backgrounded payment processing |
| PostgreSQL write spikes | Writes only on deal creation + PIN verification (low frequency) |
| Paynow webhook storms | Backgrounded processing + idempotency dedup |

---

## 11. Degraded Mode

### Activation Conditions

Degraded mode (`bot:degraded_mode` key, 60s TTL) activates when:

1. **Explicit flag:** `set_degraded_mode(rdb, True, reason="deploy")` — operator sets it
2. **Auto: Redis latency > 150ms** — `is_degraded()` measures PING RTT
3. **Auto: Payment queue > 1,000 items** — `bot:payment_queue_len` counter

### Behaviour in Degraded Mode

| Feature | Normal Mode | Degraded Mode |
|---|---|---|
| WhatsApp messaging | ✅ Full | ✅ Full (keyword-only) |
| Claude AI enrichment | ✅ Active | ❌ Skipped |
| State machine | ✅ All states | ✅ All states |
| Catalogue loading | ✅ Redis + DB | ✅ Redis only |
| Payment processing | ✅ Full | ✅ Full |
| Courier dispatch | ✅ Full | ✅ Full |

Claude enrichment is the **only feature disabled** in degraded mode. All handlers work with raw keyword input — they are designed to match both `"I want to buy"` (enriched) and `"shop"` (raw).

### Recovery

The 60s TTL means degraded mode auto-clears one minute after conditions improve. No operator intervention required for transient spikes.

For planned maintenance: `set_degraded_mode(rdb, True, reason="deploy")` → clears after 60s or on explicit `set_degraded_mode(rdb, False)`.

---

## 12. Security & Idempotency

### Message Deduplication

```
Key:     bot:dedup:{MessageSid}
Method:  SETNX (atomic: check + set in one Redis op)
TTL:     300s (5 minutes)
Scope:   Per Twilio MessageSid (globally unique per message)
Effect:  Duplicate → HTTP 200 + empty TwiML (Twilio stops retrying)
```

### Payment Idempotency

```
Key:     payment_processed:{paynow_ref}
Method:  SETNX before any state change
TTL:     86400s (24 hours)
Scope:   Per Paynow payment reference
Effect:  Duplicate webhook → silently ignored after first processing
```

Additional layer: `ledger:payment:{ref}` stores the final outcome so any replayed webhook can return the same deterministic result.

### Locking Strategy

**Per-phone message lock** (`bot:state_lock:{phone}`, 5s TTL):
- Prevents concurrent state mutations for the same user
- Token-safe: only the holder can release (Lua check-then-delete)
- Fail-open on Redis error: bot continues, reduced exclusivity

**Per-deal lock** (`bot:deal_lock:{deal_id}`, 30s TTL):
- Prevents race between Paynow webhook retries
- Prevents race between user message and payment confirmation
- Same token-safe Lua mechanism

**Courier acceptance fence** (`bot:courier_fence:{deal_id}`):
- Monotonic integer counter (not a binary lock)
- Lua script: GET fence → compare token → SET NX → verify → INCR
- Returns distinct statuses: ok / taken / stale / expired
- Prevents double-assignment even under exact-millisecond concurrency

### PII Handling

```
Phone numbers:
  Stored in Redis: YES (required for routing)
  Logged to streams: NEVER (hash(phone) % 100_000 only)
  Logged to app logs: NEVER (hash only)

Email addresses:
  Logged: *** @domain.com (PIIHandler.mask_email)
  Stored: DB only

PIN values:
  Stored: SHA-256 hash in JSON envelope ({"hash": "...", "attempts": N})
  Never stored: plaintext PIN value
  Lockout: 3 failed attempts → AWAITING_PIN reset + EscrowStateLog entry
```

### Rate Limiting

```
Key:     bot:rate:{phone}
Method:  INCR + EXPIRE (sliding window, reset on first message per window)
Limit:   20 messages per 60 seconds per phone
Effect:  Over limit → TwiML "You're sending too quickly"
Fail-open: Redis error → rate limit bypassed (availability > protection)
```

---

## Appendix: Key Lua Scripts

### Token-Safe Lock Release

```lua
-- KEYS[1] = lock key
-- ARGV[1] = token (UUID hex)
-- Returns 1 if released, 0 if token mismatch
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
else
    return 0
end
```

### Courier Acceptance Fence

```lua
-- KEYS[1] = bot:courier_fence:{deal_id}
-- KEYS[2] = bot:courier_accept:{deal_id}
-- ARGV[1] = expected fence token
-- ARGV[2] = lock value JSON
-- ARGV[3] = TTL seconds
-- Returns: "ok" | "taken" | "stale" | "expired"

local current = redis.call('GET', KEYS[1])
if current == false then return 'expired' end
if current ~= ARGV[1] then return 'stale' end

local existing = redis.call('GET', KEYS[2])
if existing then return 'taken' end

redis.call('SET', KEYS[2], ARGV[2], 'EX', tonumber(ARGV[3]), 'NX')
if redis.call('GET', KEYS[2]) ~= ARGV[2] then return 'taken' end

redis.call('INCR', KEYS[1])
return 'ok'
```

---

*AnchorFlow v1.0 — Built for real money, real users, SADC scale.*
