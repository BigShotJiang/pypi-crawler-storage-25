<img src="assets/tofamba_logo.png" alt="AnchorFlow — Tofamba. Paid. Delivered. Done." width="400"/>

# Deployment Guide

## Prerequisites

- Railway account with a project configured
- PostgreSQL add-on (Railway managed or external)
- Redis add-on (Railway managed or external)
- Twilio WhatsApp Business account
- Paynow Zimbabwe merchant account

---

## Environment Variables

Copy `.env.example` to `.env` for local development. All variables marked **REQUIRED** must be set before the application will start.

See `docs/CONFIG.md` for the full variable reference.

---

## Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Set required env vars (or copy .env.example → .env and fill in values)
export DATABASE_URL="postgresql://user:pass@localhost:5432/anchorflow"
export REDIS_URL="redis://localhost:6379"
export TWILIO_ACCOUNT_SID="AC..."
export TWILIO_AUTH_TOKEN="..."
export TWILIO_WHATSAPP_NUMBER="whatsapp:+14155238886"
export PAYNOW_INTEGRATION_ID="..."
export PAYNOW_INTEGRATION_KEY="..."
export PAYNOW_MERCHANT_EMAIL="..."

# Run database migrations
alembic upgrade head

# Start the development server
uvicorn main:app --reload --port 8000
```

---

## Database Migrations

Migrations are in `migrations/versions/`. All migrations are idempotent — they use `IF NOT EXISTS` guards and column-existence checks, so re-running is safe.

```bash
# Apply all pending migrations
alembic upgrade head

# Check current revision
alembic current

# Rollback one step
alembic downgrade -1

# Generate a new migration (after changing models)
alembic revision --autogenerate -m "describe_change"
```

**Production:** Migrations run automatically on Railway via the `railway.yaml` deploy command. Verify the migration ran by checking `/health` after deploy.

---

## Railway Deployment

Railway auto-deploys from the `main` branch. The deploy command in `railway.yaml`:

```
alembic upgrade head && uvicorn main:app --host 0.0.0.0 --port $PORT
```

### Setting Environment Variables on Railway

1. Open Railway project → Variables tab
2. Add each variable from `.env.example` (REQUIRED section)
3. Railway injects `DATABASE_URL` and `REDIS_URL` automatically if using Railway add-ons — verify the variable names match

### Verifying Deployment

After deploy, call:

```
GET /health
```

Expected response:
```json
{"status": "healthy", "service": "Tofamba API"}
```

For a full system health check:
```
GET /metrics/health
```

Look for `"status": "ok"` and `"circuit_breaker": {"open": false}`.

---

## Startup Health Checks

On every startup, `run_startup_checks()` runs before traffic is served:

1. **Env vars** — Verifies all required variables are set
2. **Database** — `SELECT 1` against `DATABASE_URL`
3. **Redis** — `PING` against `REDIS_URL`

If any check fails, the app starts in **degraded mode** (logged at WARNING). It does not refuse to start — degraded operation is preferable to complete unavailability.

Check startup logs for lines like:
```
INFO  Startup: env vars OK (8 required vars present)
INFO  Startup: database OK
INFO  Startup: Redis OK
INFO  Startup checks PASSED — all critical dependencies healthy
```

---

## Twilio Webhook Configuration

In Twilio Console → Messaging → Services → WhatsApp Sandbox (or production number):

- **Webhook URL:** `https://your-railway-url.railway.app/whatsapp-bot/webhook`
- **Method:** POST
- **Status callback URL:** (optional) same domain `/whatsapp-bot/status`

For Paynow payment webhooks:
- Configure the `return_url` in your Paynow integration to point to `POST /whatsapp-bot/payment-webhook`

---

## Scaling Considerations

- **Multiple Railway instances:** The ephemeral Redis fallback is per-process. Under normal operation (Redis healthy), all instances share the same Redis state — this is correct. During Redis outage, each instance has its own ephemeral store — users may land on different instances between messages, causing a session reset. Acceptable for the current scale.

- **Connection pool:** SQLAlchemy connection pool is configured in `database.py`. Default pool size is sufficient for Railway's single-instance deploy. Adjust `pool_size` and `max_overflow` if scaling to multiple instances.

- **Redis stream growth:** `metrics:events` is capped at MAXLEN 50k entries with approximate trimming. At 100 webhooks/second, this represents ~8 minutes of data. Adjust `_STREAM_MAXLEN` in `app/core/metrics.py` if longer windows are needed.
