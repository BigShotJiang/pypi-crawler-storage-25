# app/models/database.py

import json
import uuid
from datetime import datetime, UTC, timedelta
from enum import Enum
from sqlalchemy import (
    Boolean, Column, DateTime, Enum as SQLEnum, Index, Integer, String,
    Numeric, ForeignKey, Text, UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, relationship
from sqlalchemy import types as sa_types


class Base(DeclarativeBase):
    pass


# ─────────────────────────────────────────────────────────────────────────────
# Custom column type: transparent Fernet encryption
# ─────────────────────────────────────────────────────────────────────────────

class EncryptedText(sa_types.TypeDecorator):
    """
    SQLAlchemy column type that transparently encrypts on write and decrypts
    on read using Fernet (AES-128-CBC + HMAC-SHA256).

    The encryption key is loaded lazily from KYC_ENCRYPTION_KEY at query time,
    so the module can be imported safely before env vars are present.

    Backward-compatible: if a stored value is not a valid Fernet token
    (e.g. a pre-encryption plaintext row), decrypt_value() returns it unchanged.
    """

    impl              = sa_types.Text
    cache_ok          = True

    def process_bind_param(self, value, dialect):
        """Encrypt before INSERT / UPDATE."""
        if value is None:
            return None
        from app.security.encryption import encrypt_value
        return encrypt_value(str(value))

    def process_result_value(self, value, dialect):
        """Decrypt after SELECT."""
        if value is None:
            return None
        from app.security.encryption import decrypt_value
        return decrypt_value(value)


class EscrowStatus(Enum):
    """Type-safe status enumeration for the financial escrow record."""
    HELD = "held"
    DELIVERED = "delivered"           # Buyer confirmed delivery; pending release
    RELEASED = "released"
    EXPIRED = "expired"
    REVERSAL_INITIATED = "reversal_initiated"
    REVERSAL_CONFIRMED = "reversal_confirmed"


class DealStatus(Enum):
    """Status of the user-facing Deal (the protected deal link)."""
    CREATED   = "created"    # Deal link generated, awaiting buyer payment
    HELD      = "held"       # Payment detected, delivery window active
    DELIVERED = "delivered"  # Buyer confirmed delivery
    COMPLETED = "completed"  # Funds released; deal done
    EXPIRED   = "expired"    # Delivery window elapsed; reversal triggered
    CANCELLED        = "cancelled"         # Cancelled by seller
    IN_TRANSIT       = "in_transit"        # Courier assigned, delivery in progress
    DISPUTE_OPENED   = "dispute_opened"    # Active dispute — release blocked
    UNDER_REVIEW     = "under_review"      # Dispute under admin review
    RESOLVED_RELEASE = "resolved_release"  # Dispute resolved: funds released to merchant
    RESOLVED_REFUND  = "resolved_refund"   # Dispute resolved: funds returned to buyer


class DisputeStatus(Enum):
    """Type-safe status values for the Dispute model."""
    OPEN     = "OPEN"      # Active dispute — release blocked
    REVIEW   = "REVIEW"    # Escalated to human review
    RESOLVED = "RESOLVED"  # Resolved (RELEASE or REFUND)


class Escrow(Base):
    """
    Represents a wallet-to-wallet payment instruction observed by Tofamba.
    
    Immutability:
    - All monetary fields are set at creation, never modified
    - Only status transitions (via EscrowStateLog)
    - created_at and updated_at for audit trail
    """
    
    __tablename__ = "escrows"
    __table_args__ = (
        # Composite index — EscrowTimeoutEngine sweeps on (status, expiry_timestamp)
        Index("idx_escrows_expiry", "status", "expiry_timestamp"),
    )

    # Primary key
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, nullable=False, index=True)
    
    # ─────────────────────────────────────────────────────
    # Monetary Breakdown (IMMUTABLE after creation)
    # ─────────────────────────────────────────────────────
    
    merchant_gross = Column(Numeric(12, 2), nullable=False)        # US$15.00
    courier_gross = Column(Numeric(12, 2), nullable=False)         # US$5.00
    total_escrow = Column(Numeric(12, 2), nullable=False)          # US$20.00
    
    # Tofamba's revenue (5.5% fee) - IMMUTABLE
    merchant_tandem_fee = Column(Numeric(12, 2), nullable=False)   # US$0.825
    courier_tandem_fee = Column(Numeric(12, 2), nullable=False)    # US$0.275
    total_tandem_fee = Column(Numeric(12, 2), nullable=False)      # US$1.10
    
    # Government tax (2% IMTT) - IMMUTABLE
    merchant_imtt_tax = Column(Numeric(12, 2), nullable=False)     # US$0.30
    courier_imtt_tax = Column(Numeric(12, 2), nullable=False)      # US$0.10
    total_imtt_tax = Column(Numeric(12, 2), nullable=False)        # US$0.40
    
    # Final payouts - IMMUTABLE
    merchant_final_payout = Column(Numeric(12, 2), nullable=False) # US$13.87
    courier_final_payout = Column(Numeric(12, 2), nullable=False)  # US$4.62
    
    # ─────────────────────────────────────────────────────
    # State Management
    # ─────────────────────────────────────────────────────
    
    # Type-safe enum (not string)
    status = Column(
        SQLEnum(EscrowStatus),
        default=EscrowStatus.HELD,
        nullable=False,
        index=True
    )
    
    # Security: SHA-256 hash of delivery PIN (never plaintext)
    pin_hash = Column(String(64), nullable=True)
    
    # ─────────────────────────────────────────────────────
    # Timing (UTC-aware, all timezones)
    # ─────────────────────────────────────────────────────
    
    # When escrow was created
    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
        index=True
    )
    
    # When escrow was last updated (for debugging, not audit)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False
    )
    
    # 2-hour expiry window (auto-calculated)
    expiry_timestamp = Column(
        DateTime(timezone=True),
        nullable=False,
        index=True
    )
    
    # ─────────────────────────────────────────────────────
    # Wallet Provider References (IMMUTABLE)
    # ─────────────────────────────────────────────────────
    
    # ISO-4217 currency code (safe default for existing USD-denominated records)
    currency_code = Column(String(5), nullable=False, default="USD", server_default="USD")

    wallet_provider = Column(String(50), nullable=False)           # "ecocash"
    external_transaction_id = Column(String(255), nullable=False, unique=True, index=True)
    payer_wallet_id = Column(String(255), nullable=False)          # Merchant
    payee_wallet_id = Column(String(255), nullable=False)          # Courier
    
    # ─────────────────────────────────────────────────────
    # Reversal Tracking
    # ─────────────────────────────────────────────────────
    
    # When auto-reversal was initiated (NULL until reversal)
    reversal_triggered_at = Column(DateTime(timezone=True), nullable=True)
    
    # Why was it reversed? "timeout", "dispute", "manual"
    reversal_reason = Column(String(100), nullable=True)
    
    # ─────────────────────────────────────────────────────
    # Relationships
    # ─────────────────────────────────────────────────────
    
    state_logs = relationship(
        "EscrowStateLog",
        back_populates="escrow",
        cascade="all, delete-orphan",
        foreign_keys="EscrowStateLog.escrow_id"
    )

    # TODO: restore once Settlement and Dispute models are defined
    # settlement = relationship("Settlement", back_populates="escrow", uselist=False)
    # disputes   = relationship("Dispute",    back_populates="escrow")
    
    # ─────────────────────────────────────────────────────
    # Constructor: Auto-calculate expiry
    # ─────────────────────────────────────────────────────
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Ensure created_at is set
        if self.created_at is None:
            self.created_at = datetime.now(UTC)
        
        # Auto-calculate 2-hour expiry if not explicitly provided
        if self.expiry_timestamp is None:
            self.expiry_timestamp = self.created_at + timedelta(hours=2)
    
    # ─────────────────────────────────────────────────────
    # Validation: Ensure monetary fields are consistent
    # ─────────────────────────────────────────────────────
    
    def validate_amounts(self) -> bool:
        """
        Validate that monetary fields are mathematically consistent.
        Called before commit().
        """
        
        from decimal import Decimal
        
        # Total escrow = merchant_gross + courier_gross
        assert self.total_escrow == self.merchant_gross + self.courier_gross, \
            "total_escrow mismatch"
        
        # Total fee = merchant_fee + courier_fee
        assert self.total_tandem_fee == self.merchant_tandem_fee + self.courier_tandem_fee, \
            "total_tandem_fee mismatch"
        
        # Total tax = merchant_tax + courier_tax
        assert self.total_imtt_tax == self.merchant_imtt_tax + self.courier_imtt_tax, \
            "total_imtt_tax mismatch"
        
        # Payout = gross - fee - tax
        assert self.merchant_final_payout == \
            self.merchant_gross - self.merchant_tandem_fee - self.merchant_imtt_tax, \
            "merchant_final_payout mismatch"
        
        assert self.courier_final_payout == \
            self.courier_gross - self.courier_tandem_fee - self.courier_imtt_tax, \
            "courier_final_payout mismatch"
        
        return True


class EscrowStateLog(Base):
    """
    Append-only audit log of every Escrow state transition.

    One row is written for each status change so the complete lifecycle
    of an escrow can be reconstructed for compliance or debugging.
    """

    __tablename__ = "escrow_state_logs"

    id = Column(Integer, primary_key=True)
    escrow_id = Column(
        Integer,
        ForeignKey("escrows.id", ondelete="CASCADE"),
        nullable=True,   # NULL for system events (low_stock_alert, inventory_updated)
        index=True,
    )

    # Human-readable status strings (e.g. "held", "expired")
    previous_status = Column(String(50), nullable=False)
    new_status = Column(String(50), nullable=False)

    # Who/what triggered the transition ("auto_timeout", "manual", etc.)
    triggered_by = Column(String(100), nullable=False)

    # Optional JSON blob for additional context (provider response, etc.)
    metadata_json = Column(Text, nullable=True)

    # When this log entry was created
    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )

    escrow = relationship("Escrow", back_populates="state_logs")

    def get_metadata(self) -> dict:
        """Parse and return metadata_json; returns {} when absent or null."""
        if not self.metadata_json:
            return {}
        return json.loads(self.metadata_json)


class Deal(Base):
    """
    User-facing Protected Deal record.

    A Deal is created when a seller generates a shareable link.  The linked
    Escrow is created *lazily* — only once a buyer's payment is detected —
    because the buyer's wallet ID is unknown at deal-creation time.

    State machine:
        CREATED → HELD → DELIVERED → COMPLETED
                       ↘ EXPIRED   (timeout, reversal triggered)
    """

    __tablename__ = "deals"
    __table_args__ = (
        Index("idx_deals_seller_phone", "seller_phone"),
    )

    # ─────────────────────────────────────────────────────
    # Identity
    # ─────────────────────────────────────────────────────

    id      = Column(Integer, primary_key=True)
    deal_id = Column(String(10), unique=True, nullable=False, index=True)
    # e.g. "7G4K9"  — 5 chars from [A-Z0-9], ~60 M unique values

    # ─────────────────────────────────────────────────────
    # Deal Details (set at creation, immutable)
    # ─────────────────────────────────────────────────────

    seller_name              = Column(String(100), nullable=False)
    item_description         = Column(Text,        nullable=False)
    price                    = Column(Numeric(12, 2), nullable=False)
    wallet_phone             = Column(String(20),  nullable=False)   # Seller's wallet
    delivery_window_minutes  = Column(Integer,     nullable=False, default=120)

    # ─────────────────────────────────────────────────────
    # State
    # ─────────────────────────────────────────────────────

    status = Column(
        SQLEnum(DealStatus),
        default=DealStatus.CREATED,
        nullable=False,
        index=True,
    )

    # ─────────────────────────────────────────────────────
    # Linked Escrow (NULL until payment detected)
    # ─────────────────────────────────────────────────────

    escrow_id = Column(
        Integer,
        ForeignKey("escrows.id"),
        nullable=True,
    )
    escrow = relationship("Escrow", foreign_keys=[escrow_id])

    # ISO-4217 currency code (safe default for existing USD-denominated records)
    currency_code = Column(String(5), nullable=False, default="USD", server_default="USD")

    # Merchant must acknowledge the deal within 15 min of creation or a
    # Proof-of-Life alert is triggered and the buyer can fast-track-cancel.
    merchant_acknowledged = Column(Boolean, nullable=False, default=False, server_default="0")

    # Inventory linkage — set when deal is created via bot or SKU-based API call
    seller_phone = Column(String(20), nullable=True)    # merchant phone for inventory lookup
    item_sku     = Column(String(100), nullable=True)   # SKU of the reserved item
    quantity     = Column(Integer, nullable=False, default=1)  # units reserved

    # ─────────────────────────────────────────────────────
    # Timestamps
    # ─────────────────────────────────────────────────────

    created_at   = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    expires_at   = Column(DateTime(timezone=True), nullable=True)   # Set on HELD
    completed_at = Column(DateTime(timezone=True), nullable=True)   # Set on COMPLETED/EXPIRED

    # ── Courier assignment (PostgreSQL-backed, Redis is cache only) ───────────
    courier_phone = Column(String(20), nullable=True)   # assigned courier's phone
    buyer_phone   = Column(String(20), nullable=True)   # buyer's phone (set on payment)

    # ─────────────────────────────────────────────────────
    # Computed helpers
    # ─────────────────────────────────────────────────────

    @property
    def payment_reference(self) -> str:
        """The reference buyers must include with their wallet payment."""
        return f"TDM-{self.deal_id}"


class Merchant(Base):
    """
    Registered Tofamba merchant.

    V2 adds KYC fields (legal_name, id_number, id_photo_url, selfie_url,
    kyc_status), brand fields (wallet_type, slug) collected during the
    new /onboard_merchant WhatsApp flow.
    """

    __tablename__ = "merchants"

    id             = Column(Integer, primary_key=True)
    phone          = Column(String(20), unique=True, nullable=False, index=True)
    name           = Column(String(100), nullable=False)         # business/trade name
    wallet_address = Column(String(20), nullable=False)          # EcoCash / InnBucks number
    status         = Column(String(50), nullable=False, default="pending_verification")
    created_at     = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )

    # ── V2 KYC fields ──────────────────────────────────────────────────────
    legal_name   = Column(Text,          nullable=True)          # as on national ID (plaintext)
    # Encrypted at rest via EncryptedText (Fernet AES-128-CBC + HMAC-SHA256)
    id_number    = Column(EncryptedText, nullable=True)          # e.g. 63-123456A79 or PASSPORT:XX — ENCRYPTED
    id_type      = Column(String(20),    nullable=True, default="national_id")  # national_id / passport
    id_photo_url = Column(EncryptedText, nullable=True)          # Twilio MediaUrl — ENCRYPTED
    selfie_url   = Column(EncryptedText, nullable=True)          # Twilio MediaUrl — ENCRYPTED
    kyc_status   = Column(String(20),    nullable=True, default="pending")  # pending/approved/rejected
    wallet_type  = Column(String(20),    nullable=True)          # ecocash / innbucks / omari

    # ── V2 Brand fields ─────────────────────────────────────────────────────
    slug         = Column(String(120), nullable=True, unique=True, index=True)  # URL-safe store slug

    inventory = relationship(
        "MerchantInventory",
        primaryjoin="Merchant.phone == foreign(MerchantInventory.merchant_phone)",
        viewonly=True,
    )


class MerchantInventory(Base):
    """
    A single SKU in a merchant's catalogue.

    Tracks three quantity buckets:
    - quantity_available: units ready to sell
    - quantity_reserved:  units held for pending (CREATED/HELD) deals
    - quantity_sold:      cumulative units successfully delivered

    Invariant: quantity_available >= quantity_reserved (enforced in service layer)

    Lifecycle:
        Deal CREATED  → quantity_reserved += qty
        Deal DELIVERED/RELEASED → quantity_available -= qty, quantity_reserved -= qty, quantity_sold += qty
        Deal EXPIRED  → quantity_reserved -= qty   (release reservation)
    """

    __tablename__ = "merchant_inventory"
    __table_args__ = (
        UniqueConstraint("merchant_phone", "sku", name="uq_merchant_sku"),
    )

    id                 = Column(Integer, primary_key=True)
    merchant_phone     = Column(String(20),      nullable=False, index=True)
    sku                = Column(String(100),     nullable=False, index=True)
    item_name          = Column(String(200),     nullable=False)
    item_description   = Column(Text,            nullable=True)
    item_picture_url   = Column(String(500),     nullable=True)
    photo_url          = Column(Text,            nullable=True)   # V2: Twilio media photo
    price              = Column(Numeric(12, 2),  nullable=False)
    quantity_available = Column(Integer,         nullable=False, default=0)
    quantity_reserved  = Column(Integer,         nullable=False, default=0)
    quantity_sold      = Column(Integer,         nullable=False, default=0)
    reorder_level      = Column(Integer,         nullable=False, default=5)
    last_updated       = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )
    created_at         = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )

    @property
    def quantity_free(self) -> int:
        """Units available for new deals (available minus already reserved)."""
        return self.quantity_available - self.quantity_reserved

    @property
    def status(self) -> str:
        """Human-readable stock status."""
        if self.quantity_free <= 0:
            return "out_of_stock"
        if self.quantity_available <= self.reorder_level:
            return "low_stock"
        return "in_stock"

    variants = relationship(
        "ProductVariant",
        back_populates="inventory",
        cascade="all, delete-orphan",
        foreign_keys="ProductVariant.inventory_id",
    )


class ProductVariant(Base):
    """
    A single variant of a merchant inventory item (e.g. Red/XL/128GB).

    Stock rule:
    - If a product has variants, stock is tracked per variant.
    - The parent MerchantInventory.quantity_available = sum of active variant quantities.
    - Backward compatible: products without variants have no rows here.
    """

    __tablename__ = "product_variants"

    id                 = Column(String(36), primary_key=True,
                                default=lambda: str(uuid.uuid4()))
    inventory_id       = Column(
        Integer,
        ForeignKey("merchant_inventory.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    variant_label      = Column(String(100), nullable=False)     # "Red", "XL", "128GB"
    quantity_available = Column(Integer, nullable=False, default=0)
    quantity_reserved  = Column(Integer, nullable=False, default=0)
    quantity_fulfilled = Column(Integer, nullable=False, default=0)
    is_active          = Column(Boolean, nullable=False, default=True)
    created_at         = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    updated_at         = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )

    inventory = relationship("MerchantInventory", back_populates="variants")

    @property
    def quantity_free(self) -> int:
        return self.quantity_available - self.quantity_reserved

    @property
    def in_stock(self) -> bool:
        return self.is_active and self.quantity_free > 0


# ─────────────────────────────────────────────────────────────────────────────
# Bot session persistence (DB-backed state recovery)
# ─────────────────────────────────────────────────────────────────────────────

class BotSession(Base):
    """
    Persists WhatsApp bot conversation state to the database.

    Redis is the primary state store (fast path). BotSession acts as the
    durable fallback — loaded when the Redis key is missing (e.g. after
    a Redis restart or TTL expiry).

    last_activity is updated on every inbound message and is used by the
    30-minute inactivity guard.
    """

    __tablename__ = "bot_sessions"

    id            = Column(Integer, primary_key=True)
    phone         = Column(String(20), unique=True, nullable=False, index=True)
    state         = Column(String(60),  nullable=False, default="initial")
    last_activity = Column(DateTime(timezone=True), nullable=True)
    created_at    = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    updated_at    = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Order (Buyer Flow V1)
# ─────────────────────────────────────────────────────────────────────────────

class Order(Base):
    """
    A buyer's purchase intent record created when the buyer confirms an order
    on WhatsApp.

    Design constraints (non-custodial):
    - Tofamba NEVER holds funds.
    - An Order is a payment INSTRUCTION only.
    - The buyer must send payment to the merchant's wallet directly using
      the reference_code as the transaction reference.
    - mark_order_paid() is triggered externally (manual confirmation or
      webhook observer) — never auto-called by this model.

    Status lifecycle:
        PENDING_PAYMENT → PAID        (payment observed)
        PENDING_PAYMENT → CANCELLED   (buyer cancelled / timed out)
        PAID            → FULFILLED   (merchant confirmed fulfilment)
    """

    __tablename__ = "orders"

    id             = Column(String(36), primary_key=True,
                            default=lambda: str(uuid.uuid4()))
    merchant_id    = Column(
        Integer,
        ForeignKey("merchants.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    product_id     = Column(
        Integer,
        ForeignKey("merchant_inventory.id", ondelete="SET NULL"),
        nullable=True,
    )
    variant_id     = Column(
        String(36),
        ForeignKey("product_variants.id", ondelete="SET NULL"),
        nullable=True,
    )
    quantity       = Column(Integer,         nullable=False, default=1)
    amount         = Column(Numeric(12, 2),  nullable=False)
    status         = Column(String(30),      nullable=False, default="PENDING_PAYMENT", index=True)
    reference_code = Column(String(20),      unique=True, nullable=False, index=True)
    buyer_phone    = Column(String(20),      nullable=True,  index=True)
    created_at     = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
        index=True,
    )
    updated_at     = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )

    merchant = relationship("Merchant",          foreign_keys=[merchant_id])
    product  = relationship("MerchantInventory", foreign_keys=[product_id])
    variant  = relationship("ProductVariant",    foreign_keys=[variant_id])


# ─────────────────────────────────────────────────────────────────────────────
# Dispute Resolution
# ─────────────────────────────────────────────────────────────────────────────

class Dispute(Base):
    """
    Dispute record raised against a Deal.

    Lifecycle:
        OPEN → REVIEW → RESOLVED
    Resolution:
        RELEASE  — funds released to merchant
        REFUND   — funds returned to buyer

    PostgreSQL is authoritative. Redis key deal:{deal_id}:locked is
    set as a secondary guard (belt-and-suspenders) when a dispute opens.
    """

    __tablename__ = "disputes"

    id         = Column(Integer, primary_key=True)
    deal_id    = Column(
        String(10),
        ForeignKey("deals.deal_id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    opened_by      = Column(String(20),  nullable=False)   # "buyer" | "merchant" | "courier" | "system"
    reason         = Column(Text,        nullable=False)
    # OPEN → REVIEW → RESOLVED
    status         = Column(SQLEnum(DisputeStatus), nullable=False, default=DisputeStatus.OPEN, index=True)
    # RELEASE | REFUND (NULL until resolved)
    resolution     = Column(String(20),  nullable=True)
    # PoD linkage (set when dispute is opened from a PoD confirmation refusal)
    pod_id         = Column(String(36),  nullable=True)
    # Participant phones (denormalised for audit query convenience)
    buyer_phone    = Column(String(30),  nullable=True)
    merchant_phone = Column(String(30),  nullable=True)
    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    resolved_at = Column(DateTime(timezone=True), nullable=True)


# ─────────────────────────────────────────────────────────────────────────────
# Deal Event Log (RBZ audit trail)
# ─────────────────────────────────────────────────────────────────────────────

class DealEvent(Base):
    """
    Append-only audit log for every critical action on a Deal.

    event_type examples:
        PAYMENT_CONFIRMED, COURIER_ASSIGNED, DISPUTE_OPENED,
        DISPUTE_RESOLVED, RELEASE_TRIGGERED, DEAL_CANCELLED

    payload is a JSON string — use json.dumps / json.loads.
    Modelled after EscrowStateLog for consistency.
    """

    __tablename__ = "deal_events"
    __table_args__ = (
        Index("idx_deal_events_deal_id", "deal_id"),
        Index("idx_deal_events_event_type", "event_type"),
    )

    id         = Column(Integer, primary_key=True)
    deal_id    = Column(
        String(10),
        ForeignKey("deals.deal_id", ondelete="CASCADE"),
        nullable=False,
    )
    event_type = Column(String(50),  nullable=False)
    payload    = Column(Text,        nullable=True)   # JSON string
    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )

# ─────────────────────────────────────────────────────────────────────────────
# Alert History (AlertEngine persistence)
# ─────────────────────────────────────────────────────────────────────────────

class AlertSeverity(Enum):
    """Severity levels for persisted alerts."""
    OK       = "ok"
    WARNING  = "warning"
    CRITICAL = "critical"


class AlertHistory(Base):
    """
    Persistent record of every evaluated alert produced by the AlertEngine.

    Alerts are written when a threshold breach is detected and have NOT been
    deduplicated (i.e. a deduplication key was not present in Redis).  The
    ``acknowledged_at`` / ``acknowledged_by`` fields support manual dismissal
    from the operator dashboard.

    Indexes:
      - alert_type   — history queries filtered by type
      - created_at   — time-range queries and 30-day cleanup job
      - severity     — filter by severity (e.g. only critical)

    Non-custodial: this table only stores observability data, never financial
    mutations.  All writes are append-only; acknowledged rows are never deleted
    automatically — use the AlertCleanupJob for that.
    """

    __tablename__ = "alert_history"
    __table_args__ = (
        Index("idx_alert_history_type",     "alert_type"),
        Index("idx_alert_history_created",  "created_at"),
        Index("idx_alert_history_severity", "severity"),
    )

    id             = Column(Integer, primary_key=True)
    alert_type     = Column(String(100), nullable=False)
    severity       = Column(
        SQLEnum(AlertSeverity, values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        index=True,
    )
    value          = Column(Numeric(18, 4), nullable=True)    # observed metric value
    threshold      = Column(Numeric(18, 4), nullable=True)    # threshold that was breached
    reason         = Column(Text, nullable=True)              # human-readable explanation
    metadata_json  = Column(Text, nullable=True)              # extra context (JSON)

    created_at     = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
        index=True,
    )
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
    acknowledged_by = Column(String(100), nullable=True)      # operator id or "system"

    def get_metadata(self) -> dict:
        """Parse and return metadata_json; returns {} when absent or null."""
        if not self.metadata_json:
            return {}
        import json
        return json.loads(self.metadata_json)
