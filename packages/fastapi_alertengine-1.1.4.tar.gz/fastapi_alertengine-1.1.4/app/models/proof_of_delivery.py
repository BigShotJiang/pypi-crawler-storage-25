"""
app/models/proof_of_delivery.py

Proof-of-Delivery ORM model, status enum, and audit log.

Lifecycle::

    PENDING → SUBMITTED → CONFIRMED  (happy path)
                        ↘ DISPUTED   (buyer raises dispute)
                        ↘ EXPIRED    (timeout with no confirmation)

AuditLog captures every material event for RBZ compliance.
"""

import uuid
from datetime import datetime, UTC
from enum import Enum

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey,
    Index, Integer, String, Text, JSON,
)
from sqlalchemy.orm import relationship

from app.models.database import Base


# ─────────────────────────────────────────────────────────────────────────────
# PoD status
# ─────────────────────────────────────────────────────────────────────────────

class PoDStatus(Enum):
    PENDING   = "pending"
    SUBMITTED = "submitted"
    CONFIRMED = "confirmed"
    DISPUTED  = "disputed"
    EXPIRED   = "expired"


# ─────────────────────────────────────────────────────────────────────────────
# Audit event types
# ─────────────────────────────────────────────────────────────────────────────

class AuditEventType(Enum):
    POD_SUBMITTED         = "POD_SUBMITTED"
    POD_CONFIRMED         = "POD_CONFIRMED"
    POD_DISPUTED          = "POD_DISPUTED"
    DISPUTE_AUTO_RESOLVED = "DISPUTE_AUTO_RESOLVED"


# ─────────────────────────────────────────────────────────────────────────────
# ProofOfDelivery
# ─────────────────────────────────────────────────────────────────────────────

class ProofOfDelivery(Base):
    """
    Courier-submitted delivery evidence for a Deal.

    One record per deal (unique on deal_id). Re-submissions increment
    submission_count and overwrite fields (except when already CONFIRMED).
    """

    __tablename__ = "proof_of_delivery"
    __table_args__ = (
        Index("idx_pod_deal_id",    "deal_id"),
        Index("idx_pod_pod_status", "pod_status"),
    )

    id = Column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    deal_id = Column(
        String(10),
        ForeignKey("deals.deal_id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )

    # ── Status ────────────────────────────────────────────────────────────────
    pod_status = Column(
        String(20),
        nullable=False,
        default=PoDStatus.PENDING.value,
        index=True,
    )

    # ── Courier submission ────────────────────────────────────────────────────
    courier_phone        = Column(String(30), nullable=True)
    delivery_photo_url   = Column(Text,       nullable=True)
    gps_lat              = Column(Float,      nullable=True)
    gps_lng              = Column(Float,      nullable=True)
    gps_accuracy_meters  = Column(Float,      nullable=True)

    # ── Submission tracking ───────────────────────────────────────────────────
    submission_count     = Column(Integer, nullable=False, default=0)

    # ── Buyer confirmation ────────────────────────────────────────────────────
    buyer_confirmed      = Column(Boolean,  nullable=True, default=False)
    buyer_confirmed_at   = Column(DateTime(timezone=True), nullable=True)

    # ── Timestamps ────────────────────────────────────────────────────────────
    delivered_at = Column(DateTime(timezone=True), nullable=True)
    created_at   = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    updated_at   = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )

    # ── Relationships ─────────────────────────────────────────────────────────
    deal = relationship("Deal", foreign_keys=[deal_id])


# ─────────────────────────────────────────────────────────────────────────────
# AuditLog
# ─────────────────────────────────────────────────────────────────────────────

class AuditLog(Base):
    """
    Append-only audit trail for PoD and dispute events (RBZ compliance).
    """

    __tablename__ = "audit_logs"
    __table_args__ = (
        Index("idx_audit_entity", "entity_type", "entity_id"),
        Index("idx_audit_actor",  "actor_phone"),
    )

    id          = Column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    event_type  = Column(String(50),  nullable=False, index=True)
    entity_type = Column(String(50),  nullable=False)
    entity_id   = Column(String(36),  nullable=True)
    actor_phone = Column(String(30),  nullable=True)
    payload     = Column(JSON,        nullable=True)
    created_at  = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
