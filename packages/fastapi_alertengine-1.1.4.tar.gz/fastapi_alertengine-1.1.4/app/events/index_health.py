# app/maintenance/index_health.py

from sqlalchemy import text, inspect
from datetime import datetime, UTC, timedelta
import logging

logger = logging.getLogger(__name__)


class IndexHealthMonitor:
    """
    Monitor index performance and health.
    
    Prevents index bloat and ensures query optimization.
    """
    
    def __init__(self, db_engine):
        self.engine = db_engine
    
    # ─────────────────────────────────────────────────────
    # INDEX HEALTH CHECKS
    # ─────────────────────────────────────────────────────
    
    def check_index_bloat(self) -> Dict:
        """
        Identify bloated indexes (high dead tuples).
        
        PostgreSQL-specific: Indexes accumulate dead tuples during updates.
        Regular vacuuming prevents bloat.
        """
        
        query = """
        SELECT
            schemaname,
            tablename,
            indexname,
            pg_size_pretty(pg_relation_size(indexrelid)) as index_size,
            ROUND(
                100 * (pg_relation_size(indexrelid) - pg_relation_size(indexrelid, 'main')) / 
                NULLIF(pg_relation_size(indexrelid), 0)
            ) as dead_ratio
        FROM pg_stat_user_indexes
        WHERE pg_relation_size(indexrelid) > 1000000  -- Indexes > 1MB
        ORDER BY pg_relation_size(indexrelid) DESC;
        """
        
        with self.engine.connect() as conn:
            result = conn.execute(text(query))
            bloated_indexes = result.fetchall()
        
        report = {
            "timestamp": datetime.now(UTC).isoformat(),
            "bloated_indexes": [
                {
                    "schema": idx[0],
                    "table": idx[1],
                    "index": idx[2],
                    "size": idx[3],
                    "dead_ratio": idx[4],
                    "action": "REINDEX" if idx[4] > 30 else "MONITOR",
                }
                for idx in bloated_indexes
            ],
        }
        
        return report
    
    def check_unused_indexes(self) -> Dict:
        """
        Identify indexes that are never used.
        
        Unused indexes waste storage and slow down writes.
        """
        
        query = """
        SELECT
            schemaname,
            tablename,
            indexname,
            idx_scan as scans,
            pg_size_pretty(pg_relation_size(indexrelid)) as size
        FROM pg_stat_user_indexes
        WHERE idx_scan = 0
            AND indexrelname NOT LIKE 'pg_toast%'
        ORDER BY pg_relation_size(indexrelid) DESC;
        """
        
        with self.engine.connect() as conn:
            result = conn.execute(text(query))
            unused = result.fetchall()
        
        return {
            "timestamp": datetime.now(UTC).isoformat(),
            "unused_indexes": [
                {
                    "schema": idx[0],
                    "table": idx[1],
                    "index": idx[2],
                    "scans": idx[3],
                    "size": idx[4],
                    "recommendation": "CONSIDER DROPPING" if idx[4] > "10 MB" else "MONITOR",
                }
                for idx in unused
            ],
        }
    
    def check_missing_indexes(self) -> Dict:
        """
        Identify queries doing full table scans.
        
        Uses pg_stat_statements extension (requires installation).
        """
        
        query = """
        SELECT
            query,
            calls,
            total_time,
            mean_time,
            rows
        FROM pg_stat_statements
        WHERE query NOT LIKE '%pg_stat%'
            AND mean_time > 100  -- Queries taking >100ms on average
        ORDER BY mean_time DESC
        LIMIT 20;
        """
        
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text(query))
                slow_queries = result.fetchall()
            
            return {
                "timestamp": datetime.now(UTC).isoformat(),
                "slow_queries": [
                    {
                        "query": q[0][:100] + "..." if len(q[0]) > 100 else q[0],
                        "calls": q[1],
                        "total_time_ms": q[2],
                        "mean_time_ms": q[3],
                        "rows": q[4],
                    }
                    for q in slow_queries
                ],
                "note": "Consider adding indexes for frequently-scanned tables",
            }
        except Exception as e:
            logger.warning(f"pg_stat_statements not available: {e}")
            return {"status": "pg_stat_statements extension not installed"}
    
    # ─────────────────────────────────────────────────────
    # PARTIAL INDEXES (For Large Tables)
    # ─────────────────────────────────────────────────────
    
    def create_partial_indexes(self) -> Dict:
        """
        Create partial indexes for common queries.
        
        Partial indexes are smaller and faster than full-table indexes.
        Useful for: Indexes on recent data (last N years).
        """
        
        queries = [
            # Index only recent escrows (last 2 years)
            """
            CREATE INDEX idx_escrow_recent_status ON escrows(status, created_at)
            WHERE created_at >= NOW() - INTERVAL '2 years';
            """,
            
            # Index only active sessions
            """
            CREATE INDEX idx_user_session_active ON user_sessions(user_id, created_at)
            WHERE is_active = true;
            """,
            
            # Index only pending fiscal entries
            """
            CREATE INDEX idx_settlement_fiscal_pending ON settlements(settlement_id)
            WHERE fiscal_status != 'confirmed';
            """,
            
            # Index only disputed escrows
            """
            CREATE INDEX idx_dispute_open ON disputes(escrow_id)
            WHERE status IN ('OPEN', 'UNDER_REVIEW');
            """,
        ]
        
        results = []
        
        with self.engine.connect() as conn:
            for query in queries:
                try:
                    conn.execute(text(query))
                    conn.commit()
                    results.append({"status": "created", "query": query[:50]})
                except Exception as e:
                    results.append({"status": "skipped", "reason": str(e)})
        
        return results
    
    # ─────────────────────────────────────────────────────
    # BRIN INDEXES (For Time-Series Data)
    # ─────────────────────────────────────────────────────
    
    def create_brin_indexes(self) -> Dict:
        """
        Create BRIN indexes for date/time columns.
        
        BRIN: Block Range Index. Much smaller than B-tree for range queries.
        Perfect for: Time-series data (escrow_state_logs, settlement records).
        """
        
        queries = [
            # BRIN on escrow_state_logs timestamp
            """
            CREATE INDEX idx_esl_timestamp_brin ON escrow_state_logs 
            USING BRIN (timestamp) WITH (pages_per_range = 128);
            """,
            
            # BRIN on fiscal_logs timestamp
            """
            CREATE INDEX idx_fl_timestamp_brin ON fiscal_logs
            USING BRIN (submitted_at) WITH (pages_per_range = 128);
            """,
            
            # BRIN on session_logs timestamp
            """
            CREATE INDEX idx_sl_timestamp_brin ON session_logs
            USING BRIN (created_at) WITH (pages_per_range = 128);
            """,
        ]
        
        results = []
        
        with self.engine.connect() as conn:
            for query in queries:
                try:
                    conn.execute(text(query))
                    conn.commit()
                    results.append({
                        "status": "created",
                        "type": "BRIN",
                        "purpose": "Range queries on timestamps"
                    })
                except Exception as e:
                    results.append({"status": "skipped", "reason": str(e)})
        
        return results
    
    # ─────────────────────────────────────────────────────
    # SCHEDULED MAINTENANCE
    # ─────────────────────────────────────────────────────
    
    def schedule_maintenance(self):
        """
        Schedule periodic index maintenance.
        
        Add to APScheduler or cron:
        - Daily: VACUUM ANALYZE (reclaims space, updates statistics)
        - Weekly: REINDEX (rebuilds bloated indexes)
        - Monthly: Health check report
        """
        
        from apscheduler.schedulers.background import BackgroundScheduler
        
        scheduler = BackgroundScheduler()
        
        # Daily vacuum
        scheduler.add_job(
            self.run_vacuum,
            "cron",
            hour=2,  # 2 AM
            id="daily_vacuum",
        )
        
        # Weekly reindex
        scheduler.add_job(
            self.run_reindex,
            "cron",
            day_of_week="sun",
            hour=3,
            id="weekly_reindex",
        )
        
        # Monthly health check
        scheduler.add_job(
            self.generate_health_report,
            "cron",
            day=1,
            hour=4,
            id="monthly_health_check",
        )
        
        scheduler.start()
    
    def run_vacuum(self):
        """Reclaim dead space and update statistics."""
        
        with self.engine.connect() as conn:
            conn.execute(text("VACUUM ANALYZE;"))
            conn.commit()
        
        logger.info("VACUUM ANALYZE completed")
    
    def run_reindex(self):
        """Rebuild indexes (if necessary)."""
        
        # Only reindex if needed (based on bloat report)
        bloat_report = self.check_index_bloat()
        
        for idx in bloat_report.get("bloated_indexes", []):
            if idx["action"] == "REINDEX":
                with self.engine.connect() as conn:
                    conn.execute(text(f"REINDEX INDEX {idx['index']};"))
                    conn.commit()
                
                logger.info(f"Reindexed {idx['index']}")
    
    def generate_health_report(self) -> Dict:
        """Generate comprehensive index health report."""
        
        report = {
            "timestamp": datetime.now(UTC).isoformat(),
            "bloat_check": self.check_index_bloat(),
            "unused_indexes": self.check_unused_indexes(),
            "slow_queries": self.check_missing_indexes(),
        }
        
        # Log report
        logger.info(f"Index health report: {report}")
        
        # Could send to monitoring system
        # send_to_monitoring_system(report)
        
        return report