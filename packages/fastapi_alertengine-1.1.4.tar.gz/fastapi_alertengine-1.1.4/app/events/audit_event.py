# app/events/audit_event.py

from dataclasses import dataclass, asdict
from datetime import datetime, UTC
import json


@dataclass
class AuditEvent:
    """
    Unified audit event for both DB and Kafka.
    
    Ensures consistency across append-only sources:
    - EscrowStateLog (database)
    - Event stream (Kafka)
    - Analytics pipeline
    """
    
    event_id: str                          # UUID for idempotency
    event_type: str                        # "ESCROW_CREATED", "PIN_VERIFIED", etc.
    timestamp: str                         # ISO 8601 UTC
    
    # What changed
    escrow_id: int
    previous_status: str
    new_status: str
    
    # Who/what triggered
    triggered_by: str                      # "user_pin", "auto_timeout", "system"
    actor_id: str                          # User, bot, system
    actor_type: str                        # "human", "bot", "service"
    
    # Context
    wallet_provider: str                   # "ecocash", "innbucks"
    external_transaction_id: str
    
    # Metadata (flexible)
    metadata: dict                         # Provider-specific data
    
    def to_json(self) -> str:
        """Serialize to JSON for Kafka/logging."""
        return json.dumps(asdict(self), default=str)
    
    @classmethod
    def from_json(cls, json_str: str):
        """Deserialize from JSON."""
        return cls(**json.loads(json_str))


# Usage in EscrowTimeoutEngine

class EscrowTimeoutEngine:
    
    def trigger_reversal(self, escrow_id: int, reason: str) -> Dict:
        """..."""
        
        escrow = self.db_session.get(Escrow, escrow_id)
        
        # Create unified audit event
        event = AuditEvent(
            event_id=uuid.uuid4().hex,
            event_type="REVERSAL_INITIATED",
            timestamp=datetime.now(UTC).isoformat(),
            
            escrow_id=escrow_id,
            previous_status=escrow.status.value,
            new_status=EscrowStatus.REVERSAL_INITIATED.value,
            
            triggered_by="auto_timeout",
            actor_id="system",
            actor_type="service",
            
            wallet_provider=escrow.wallet_provider,
            external_transaction_id=escrow.external_transaction_id,
            
            metadata={
                "reason": reason,
                "reversal_ref": result.get("reversal_id"),
                "wallet_response": result,
            }
        )
        
        # 1. Store in DB
        log = EscrowStateLog(
            escrow_id=escrow_id,
            previous_status=escrow.status.value,
            new_status=EscrowStatus.REVERSAL_INITIATED.value,
            triggered_by="auto_timeout",
            timestamp=datetime.fromisoformat(event.timestamp),
            metadata_json=event.to_json(),
        )
        self.db_session.add(log)
        self.db_session.commit()
        
        # 2. Publish to Kafka (for event stream)
        self.event_bus.publish(event)
        
        return {"status": "ok", "event_id": event.event_id}