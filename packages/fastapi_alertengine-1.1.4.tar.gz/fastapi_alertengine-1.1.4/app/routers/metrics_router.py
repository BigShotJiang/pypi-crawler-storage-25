# app/routers/metrics_router.py
"""
Metrics and observability endpoints for AnchorFlow.

Endpoints:
    GET /metrics/health   — Live system health snapshot
    GET /metrics/export   — Prometheus-compatible JSON telemetry
    GET /metrics/dashboard/api/health — Dashboard adapter

Mounted at /metrics in main.py
"""

import json
import logging
import time
from datetime import datetime, UTC
from typing import Any, Dict, Optional

from fastapi import APIRouter

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/metrics", tags=["metrics"])

# ─── ALERT THRESHOLDS ─────────────────────────────────────────────────────────

_ALERT_THRESHOLDS = {
    "webhook_p95_ms_warn": 1_000,
    "webhook_p95_ms_crit": 3_000,
    "redis_failures_warn": 5,
    "redis_failures_crit": 20,
    "state_transition_fail_warn": 3,
    "redis_latency_ms_warn": 150,
    "redis_latency_ms_crit": 500,
}


def _get_redis():
    from app.routers.whatsapp_bot import _redis
    return _redis


def _classify_alert(value: float, warn: float, crit: float) -> str:
    if value >= crit:
        return "critical"
    if value >= warn:
        return "warning"
    return "ok"


def _persist_alert(
    alert_type: str,
    severity: str,
    value: float,
    threshold: float,
    reason: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Write one AlertHistory row to the database.

    Never raises — errors are logged and swallowed so a DB outage cannot
    break the /metrics/health endpoint.
    """
    try:
        from app.db import SessionLocal
        from app.models.database import AlertHistory, AlertSeverity

        sev_enum = AlertSeverity(severity)
        record = AlertHistory(
            alert_type=alert_type,
            severity=sev_enum,
            value=value,
            threshold=threshold,
            reason=reason,
            metadata_json=json.dumps(metadata) if metadata else None,
            created_at=datetime.now(UTC),
        )
        db = SessionLocal()
        try:
            db.add(record)
            db.commit()
        finally:
            db.close()
    except Exception as exc:
        logger.warning("_persist_alert failed for [%s]: %s", alert_type, exc)


async def _maybe_fire_alert(
    alert_type: str,
    severity: str,
    value: float,
    threshold: float,
    reason: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Deduplicate → persist → notify pipeline for a single alert.

    Steps:
      1. Check AlertDeduplicator (Redis NX key).
      2. If not suppressed: persist to alert_history and dispatch notification.
    """
    if severity == "ok":
        return

    rdb = _get_redis()
    try:
        from app.core.alert_deduplicator import AlertDeduplicator
        dedup = AlertDeduplicator(rdb)
        if not dedup.should_fire(alert_type, severity):
            return
    except Exception as exc:
        logger.warning("_maybe_fire_alert dedup check failed: %s", exc)

    # Persist to DB (sync, in thread executor is fine since it's fast)
    _persist_alert(alert_type, severity, value, threshold, reason, metadata)

    # Dispatch notification async (best-effort)
    try:
        from app.core.alert_notification_service import AlertNotificationService
        notifier = AlertNotificationService()
        await notifier.notify(
            alert_type=alert_type,
            severity=severity,
            value=value,
            threshold=threshold,
            reason=reason,
            metadata=metadata,
        )
    except Exception as exc:
        logger.warning("_maybe_fire_alert notification failed for [%s]: %s", alert_type, exc)

# ─── HEALTH SNAPSHOT ──────────────────────────────────────────────────────────

@router.get("/health")
async def metrics_health():
    """
    Live system health snapshot (fast, safe, low overhead).
    """

    rdb = _get_redis()

    from app.core.load_shedding import degraded_status
    from app.core.metrics import aggregate_metrics

    ds = degraded_status(rdb)
    agg = aggregate_metrics(rdb, last_n=500)

    circuit = {}
    if hasattr(rdb, "circuit_status"):
        circuit = rdb.circuit_status()

    # ── Core signals ──────────────────────────────────────────────────────────
    webhook_p95 = agg.get("webhook_latency", {}).get("p95_ms", 0.0)
    redis_failures = agg.get("redis_failures", {}).get("count", 0)
    state_fails = agg.get("state_transition_failures", {}).get("count", 0)
    redis_latency = agg.get("redis_latency_ms", 0.0)

    # ── Alerts ────────────────────────────────────────────────────────────────
    alerts = {
        "webhook_latency": _classify_alert(
            webhook_p95,
            _ALERT_THRESHOLDS["webhook_p95_ms_warn"],
            _ALERT_THRESHOLDS["webhook_p95_ms_crit"],
        ),
        "redis_failures": _classify_alert(
            redis_failures,
            _ALERT_THRESHOLDS["redis_failures_warn"],
            _ALERT_THRESHOLDS["redis_failures_crit"],
        ),
        "redis_latency": _classify_alert(
            redis_latency,
            _ALERT_THRESHOLDS["redis_latency_ms_warn"],
            _ALERT_THRESHOLDS["redis_latency_ms_crit"],
        ),
        "state_transitions": _classify_alert(
            state_fails,
            _ALERT_THRESHOLDS["state_transition_fail_warn"],
            _ALERT_THRESHOLDS["state_transition_fail_warn"] * 5,
        ),
    }

    # ── Deduplicate → persist → notify non-ok alerts ──────────────────────────
    _alert_signal_map = {
        "webhook_latency": (
            webhook_p95,
            _ALERT_THRESHOLDS["webhook_p95_ms_warn"],
            "webhook p95 latency exceeded threshold",
        ),
        "redis_failures": (
            redis_failures,
            _ALERT_THRESHOLDS["redis_failures_warn"],
            "Redis failure count exceeded threshold",
        ),
        "redis_latency": (
            redis_latency,
            _ALERT_THRESHOLDS["redis_latency_ms_warn"],
            "Redis latency exceeded threshold",
        ),
        "state_transitions": (
            state_fails,
            _ALERT_THRESHOLDS["state_transition_fail_warn"],
            "State transition failure count exceeded threshold",
        ),
    }
    for _atype, _aseverity in alerts.items():
        if _aseverity != "ok":
            _val, _thr, _reason = _alert_signal_map.get(_atype, (0.0, 0.0, _atype))
            await _maybe_fire_alert(
                alert_type=_atype,
                severity=_aseverity,
                value=float(_val),
                threshold=float(_thr),
                reason=_reason,
                metadata={"snapshot_timestamp": int(time.time())},
            )

    # ── System status ─────────────────────────────────────────────────────────
    if any(v == "critical" for v in alerts.values()) or circuit.get("open"):
        overall = "critical"
    elif any(v == "warning" for v in alerts.values()) or ds.get("degraded"):
        overall = "warning"
    else:
        overall = "ok"

    # ── Intelligence layer ────────────────────────────────────────────────────
    critical_count = sum(1 for v in alerts.values() if v == "critical")
    warning_count = sum(1 for v in alerts.values() if v == "warning")

    if critical_count > 0 or circuit.get("open"):
        risk_level = "critical"
    elif warning_count > 1 or ds.get("degraded"):
        risk_level = "high"
    elif warning_count == 1:
        risk_level = "medium"
    else:
        risk_level = "low"

    base_score = 100
    base_score -= critical_count * 30
    base_score -= warning_count * 15
    if circuit.get("open"):
        base_score -= 25
    if ds.get("degraded"):
        base_score -= 10

    system_health_score = max(0, min(100, base_score))

    top_issue = None
    if alerts:
        top_issue = max(
            alerts.items(),
            key=lambda x: 0 if x[1] == "ok" else (2 if x[1] == "critical" else 1),
        )[0]

    return {
        "status": overall,
        "timestamp": int(time.time()),
        "degraded_mode": ds,
        "circuit_breaker": circuit,
        "alerts": alerts,
        "thresholds": _ALERT_THRESHOLDS,

        "summary": {
            "webhook_p95_ms": webhook_p95,
            "redis_failures_recent": redis_failures,
            "state_transition_failures": state_fails,
            "redis_latency_ms": redis_latency,
            "stream_length": agg.get("stream_length", 0),
        },

        # ── Intelligence (NOW ACTIVE) ──
        "system_health_score": system_health_score,
        "risk_level": risk_level,
        "top_issue": top_issue,
    }


# ─── PROMETHEUS EXPORT ───────────────────────────────────────────────────────

@router.get("/export")
async def metrics_export(last_n: int = 1000):
    if last_n < 1 or last_n > 10_000:
        last_n = 1000

    rdb = _get_redis()

    from app.core.metrics import aggregate_metrics
    from app.core.load_shedding import degraded_status

    agg = aggregate_metrics(rdb, last_n=last_n)
    ds = degraded_status(rdb)

    circuit_open = 0
    if hasattr(rdb, "circuit_status"):
        circuit_open = 1 if rdb.circuit_status().get("open") else 0

    return {
        "metrics": [
            {
                "name": "anchorflow_webhook_latency_p95_ms",
                "value": agg.get("webhook_latency", {}).get("p95_ms", 0.0),
                "type": "gauge",
            },
            {
                "name": "anchorflow_webhook_count",
                "value": agg.get("webhook_latency", {}).get("count", 0),
                "type": "counter",
            },
            {
                "name": "anchorflow_redis_failures_total",
                "value": agg.get("redis_failures", {}).get("count", 0),
                "type": "counter",
            },
            {
                "name": "anchorflow_state_transition_failures_total",
                "value": agg.get("state_transition_failures", {}).get("count", 0),
                "type": "counter",
            },
            {
                "name": "anchorflow_circuit_breaker_open",
                "value": circuit_open,
                "type": "gauge",
            },
            {
                "name": "anchorflow_degraded_mode",
                "value": 1 if ds.get("degraded") else 0,
                "type": "gauge",
            },
            {
                "name": "anchorflow_redis_latency_ms",
                "value": ds.get("redis_latency_ms", 0.0),
                "type": "gauge",
            },
        ],
        "timestamp": int(time.time()),
        "service": "anchorflow",
    }


# ─── DASHBOARD ADAPTER ───────────────────────────────────────────────────────

def _map_health_label(score: int) -> str:
    if score >= 80:
        return "good"
    if score >= 50:
        return "fair"
    return "poor"


@router.get("/dashboard/api/health")
async def dashboard_health_adapter():
    raw = await metrics_health()

    alerts = raw.get("alerts", {})

    if any(v == "critical" for v in alerts.values()):
        score = 40
    elif any(v == "warning" for v in alerts.values()):
        score = 65
    else:
        score = 90

    summary = raw.get("summary", {})
    state_transition_failures = summary.get("state_transition_failures", 0)

    return {
        "health_score": score,
        "health_label": _map_health_label(score),
        "stuck_deals": int(state_transition_failures),
    }
