from fastapi import APIRouter, Depends
from app.security.auth import get_current_user
from app.routers.metrics_router import metrics_health as _metrics_health

router = APIRouter()


@router.get("/dashboard/api/overview")
async def dashboard_overview(user: dict = Depends(get_current_user)):
    try:
        # ── USER BLOCK ─────────────────────────────
        user_block = {
            "id": user.get("user_id"),
            "email": user.get("email"),
            "role": user.get("role"),
            "kyc_status": user.get("kyc_status"),
        }

        # ── HEALTH BLOCK ───────────────────────────
        raw_health = await _metrics_health()

        alert_values = list(raw_health.get("alerts", {}).values())

        if any(v == "critical" for v in alert_values):
            score = 40
            status = "critical"
        elif any(v == "warning" for v in alert_values):
            score = 65
            status = "degraded"
        else:
            score = 90
            status = "healthy"

        health_block = {
            "score": score,
            "status": status,
            "stuck_deals": raw_health.get("summary", {}).get("state_transition_failures", 0),
        }

        # ── INSIGHTS BLOCK ─────────────────────────
        is_merchant = user.get("role") == "merchant"

        personalized_insights = []

        if is_merchant:
            personalized_insights.append("Your merchant dashboard is active.")
            if user.get("kyc_status") != "approved":
                personalized_insights.append("Complete KYC to unlock full trading features.")
        else:
            personalized_insights.append("Standard user access active.")

        return {
            "user": user_block,
            "health": health_block,
            "personalized_insights": personalized_insights
        }

    except Exception:
        return {
            "user": {},
            "health": {
                "score": 50,
                "status": "unknown",
                "stuck_deals": 0
            },
            "personalized_insights": ["Dashboard temporarily degraded"]
        }
