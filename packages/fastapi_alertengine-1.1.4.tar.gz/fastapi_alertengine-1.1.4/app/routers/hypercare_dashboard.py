# app/routes/hypercare_dashboard.py - REVIEW

# STRENGTHS:
# ✅ Comprehensive percentile tracking (p50, p95, p99)
# ✅ Proper latency extraction from logs
# ✅ Safe handling of edge cases (no logs = 0.0)
# ✅ Correct calculation of percentiles

# SUGGESTIONS FOR PRODUCTION:

# 1. Add latency by operation type
# Current: All latencies aggregated
# Better: Pin validation vs settlement vs escrow creation

class LatencyByOperation(BaseModel):
    pin_validation_ms: float
    escrow_creation_ms: float
    settlement_ms: float
    reversal_ms: float


# 2. Add latency tracking over time
# Current: Point-in-time metrics
# Better: 1h ago, 6h ago, 24h ago comparison

class LatencyTrend(BaseModel):
    current_avg_ms: float
    one_hour_ago_ms: float
    six_hours_ago_ms: float
    trend_direction: str  # "improving", "stable", "degrading"


# 3. Add database query latency separately
# Current: Total latency
# Better: Network + DB + processing breakdown

class LatencyBreakdown(BaseModel):
    network_ms: float
    database_ms: float
    processing_ms: float
    total_ms: float


# 4. Add SLO compliance by percentile
# Current: Just values
# Better: Explicit pass/fail for each percentile

class PerformanceMetrics(BaseModel):
    avg_latency_ms: float
    avg_ok: bool  # avg < 2000ms
    p95_latency_ms: float
    p95_ok: bool  # p95 < 4000ms
    p99_latency_ms: float
    p99_ok: bool  # p99 < 5000ms


# PRODUCTION READY: 90%
# Minor additions: Operation-specific latency + trend tracking