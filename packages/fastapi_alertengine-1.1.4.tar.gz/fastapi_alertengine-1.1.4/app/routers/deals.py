"""
Deal Links router — WhatsApp-native protected commerce entry point.

Endpoints
---------
POST /deals                           Create a new protected deal link
GET  /deals/{deal_id}                 Deal status JSON (polled by buyer page)
POST /deals/{deal_id}/payment-detected  Webhook: payment received, create Escrow
POST /deals/{deal_id}/confirm-delivery  Buyer confirms delivery → COMPLETED
GET  /d/{deal_id}                     Mobile-first buyer HTML page
"""

import logging
import os
from decimal import Decimal
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import load_settings
from app.models.database import Base, DealStatus
from app.services import deal_service

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Templates
# ---------------------------------------------------------------------------

_TEMPLATES_DIR = Path(__file__).parent.parent / "templates"
templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))

# ---------------------------------------------------------------------------
# Database dependency
# ---------------------------------------------------------------------------

_settings = load_settings()
_engine   = create_engine(
    _settings.database_url,
    connect_args={"check_same_thread": False} if "sqlite" in _settings.database_url else {},
)
Base.metadata.create_all(_engine)
_SessionLocal = sessionmaker(bind=_engine, autocommit=False, autoflush=False)


def get_db():
    db = _SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CreateDealRequest(BaseModel):
    seller_name:             str            = Field(..., min_length=1, max_length=100)
    item_description:        str            = Field(..., min_length=1)
    price:                   float          = Field(..., gt=0)
    wallet_phone:            str            = Field(..., min_length=9, max_length=20)
    delivery_window_minutes: int            = Field(default=120, ge=10, le=10080)


class CreateDealResponse(BaseModel):
    deal_id:           str
    share_url:         str
    payment_reference: str
    whatsapp_message:  str


class DealStatusResponse(BaseModel):
    deal_id:                 str
    status:                  str
    seller_name:             str
    item_description:        str
    price:                   float
    wallet_phone:            str
    payment_reference:       str
    delivery_window_minutes: int
    expires_at:              Optional[str]
    completed_at:            Optional[str]


class PaymentDetectedRequest(BaseModel):
    payer_wallet:   str   = Field(..., min_length=9, max_length=20)
    transaction_id: str   = Field(..., min_length=1)
    amount:         float = Field(..., gt=0)


class ConfirmDeliveryResponse(BaseModel):
    deal_id: str
    status:  str
    message: str


class FastTrackCancelResponse(BaseModel):
    deal_id: str
    status:  str
    message: str


class AcknowledgeDealResponse(BaseModel):
    deal_id: str
    status:  str
    merchant_acknowledged: bool


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(tags=["deals"])


# ── 1. Create deal ──────────────────────────────────────────────────────────

@router.post("/deals", response_model=CreateDealResponse, status_code=201)
def create_deal(payload: CreateDealRequest, db: Session = Depends(get_db)):
    """
    Seller creates a new Protected Deal link.

    Returns a shareable URL and a suggested WhatsApp message.
    """
    settings = load_settings()
    deal = deal_service.create_deal(
        db,
        seller_name             = payload.seller_name,
        item_description        = payload.item_description,
        price                   = Decimal(str(payload.price)),
        wallet_phone            = payload.wallet_phone,
        delivery_window_minutes = payload.delivery_window_minutes,
    )
    share_url         = deal_service.build_share_url(deal, settings.base_url)
    whatsapp_message  = deal_service.build_whatsapp_message(deal, share_url)

    return CreateDealResponse(
        deal_id           = deal.deal_id,
        share_url         = share_url,
        payment_reference = deal.payment_reference,
        whatsapp_message  = whatsapp_message,
    )


# ── 2. Deal status JSON (polled by buyer page JS) ──────────────────────────

@router.get("/deals/{deal_id}", response_model=DealStatusResponse)
def get_deal_status(deal_id: str, db: Session = Depends(get_db)):
    """Return current deal status as JSON."""
    try:
        deal = deal_service.get_deal(db, deal_id)
    except ValueError:
        raise HTTPException(status_code=404, detail=f"Deal '{deal_id}' not found")

    return DealStatusResponse(
        deal_id                 = deal.deal_id,
        status                  = deal.status.value,
        seller_name             = deal.seller_name,
        item_description        = deal.item_description,
        price                   = float(deal.price),
        wallet_phone            = deal.wallet_phone,
        payment_reference       = deal.payment_reference,
        delivery_window_minutes = deal.delivery_window_minutes,
        expires_at              = deal.expires_at.isoformat() if deal.expires_at else None,
        completed_at            = deal.completed_at.isoformat() if deal.completed_at else None,
    )


# ── 3. Payment detected (Paynow webhook / manual trigger) ─────────────────

@router.post("/deals/{deal_id}/payment-detected")
def payment_detected(
    deal_id: str,
    payload: PaymentDetectedRequest,
    db: Session = Depends(get_db),
):
    """
    Called by the Paynow webhook (or manually during testing) when the buyer's
    wallet payment is confirmed.  Creates the linked Escrow and transitions
    the Deal to HELD.
    """
    try:
        deal = deal_service.detect_payment(
            db,
            deal_id        = deal_id,
            payer_wallet   = payload.payer_wallet,
            transaction_id = payload.transaction_id,
            amount         = Decimal(str(payload.amount)),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return {"deal_id": deal.deal_id, "status": deal.status.value, "escrow_id": deal.escrow_id}


# ── 4. Buyer confirms delivery ─────────────────────────────────────────────

@router.post("/deals/{deal_id}/confirm-delivery", response_model=ConfirmDeliveryResponse)
def confirm_delivery(deal_id: str, db: Session = Depends(get_db)):
    """
    Buyer presses 'Confirm Delivery'.  Transitions the deal to COMPLETED and
    releases the linked Escrow.
    """
    try:
        deal = deal_service.confirm_delivery(db, deal_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return ConfirmDeliveryResponse(
        deal_id = deal.deal_id,
        status  = deal.status.value,
        message = "Transaction completed. Paid. Delivered. Done.",
    )


# ── 5. Buyer fast-track cancel (Proof-of-Life window elapsed) ──────────────

@router.post(
    "/deals/{deal_id}/fast-track-cancel",
    response_model=FastTrackCancelResponse,
    status_code=200,
)
def fast_track_cancel(deal_id: str, db: Session = Depends(get_db)):
    """
    Buyer cancels a deal whose merchant has not acknowledged within 15 minutes.

    Eligibility:
      - Deal must be CREATED (no payment sent yet).
      - ``merchant_acknowledged`` must be False.
      - ``created_at + 15 min`` must have elapsed.
    """
    try:
        deal = deal_service.fast_track_cancel(db, deal_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return FastTrackCancelResponse(
        deal_id = deal.deal_id,
        status  = deal.status.value,
        message = (
            "Deal cancelled. The merchant did not acknowledge in time. "
            "No payment was taken."
        ),
    )


# ── 6. Merchant acknowledges deal ─────────────────────────────────────────

@router.post(
    "/deals/{deal_id}/acknowledge",
    response_model=AcknowledgeDealResponse,
    status_code=200,
)
def acknowledge_deal(deal_id: str, db: Session = Depends(get_db)):
    """
    Merchant confirms awareness of the deal — suppresses the Proof-of-Life alert
    and prevents the buyer from initiating a fast-track cancellation.
    """
    try:
        deal = deal_service.acknowledge_deal(db, deal_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return AcknowledgeDealResponse(
        deal_id               = deal.deal_id,
        status                = deal.status.value,
        merchant_acknowledged = deal.merchant_acknowledged,
    )


# ── 7. Buyer HTML page ─────────────────────────────────────────────────────

@router.get("/d/{deal_id}", response_class=HTMLResponse)
def deal_page(deal_id: str, db: Session = Depends(get_db)):
    """
    Mobile-first buyer page — server-rendered, works in WhatsApp's in-app
    browser.  JavaScript polls /deals/{deal_id} every 3 seconds to update
    the progress indicator without a page reload.
    """
    try:
        deal = deal_service.get_deal(db, deal_id)
    except ValueError:
        raise HTTPException(status_code=404, detail=f"Deal '{deal_id}' not found")

    return HTMLResponse(
        content=(_TEMPLATES_DIR / "deal.html").read_text(),
        status_code=200,
    )
