# app/routers/alert_router.py
"""
Alert history endpoints for AnchorFlow / Tofamba.

Endpoints (all mounted under /alerts):
  GET /alerts/history          — paginated alert history with optional filters
  GET /alerts/stats            — count of alerts grouped by type and severity
  GET /alerts/{alert_id}       — single alert record

All endpoints are read-only (non-custodial, no financial mutations).
Suitable for RBZ audit review.
"""

import json
import logging
from datetime import datetime, UTC
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.db import get_db
from app.models.database import AlertHistory, AlertSeverity
from app.security.auth import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/alerts", tags=["alerts"])


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _alert_to_dict(alert: AlertHistory) -> Dict[str, Any]:
    """Serialise an AlertHistory ORM row to a plain dict."""
    return {
        "id":               alert.id,
        "alert_type":       alert.alert_type,
        "severity":         alert.severity.value if hasattr(alert.severity, "value") else alert.severity,
        "value":            float(alert.value) if alert.value is not None else None,
        "threshold":        float(alert.threshold) if alert.threshold is not None else None,
        "reason":           alert.reason,
        "metadata":         alert.get_metadata(),
        "created_at":       alert.created_at.isoformat() if alert.created_at else None,
        "acknowledged_at":  alert.acknowledged_at.isoformat() if alert.acknowledged_at else None,
        "acknowledged_by":  alert.acknowledged_by,
    }


# ─── GET /alerts/history ──────────────────────────────────────────────────────

@router.get("/history")
def list_alert_history(
    limit: int = Query(default=50, ge=1, le=500),
    severity: Optional[str] = Query(default=None),
    alert_type: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
    _user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Return the most recent alert records, newest first.

    Query parameters:
      limit      — max rows to return (1–500, default 50)
      severity   — filter by severity: ``ok``, ``warning``, or ``critical``
      alert_type — filter by alert type string (exact match)

    Returns a JSON object with ``alerts`` list and ``total`` count.
    """
    try:
        query = db.query(AlertHistory).order_by(AlertHistory.created_at.desc())

        if severity:
            try:
                sev_enum = AlertSeverity(severity.lower())
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid severity '{severity}'. Use: ok, warning, critical",
                )
            query = query.filter(AlertHistory.severity == sev_enum)

        if alert_type:
            query = query.filter(AlertHistory.alert_type == alert_type)

        alerts = query.limit(limit).all()

        return {
            "alerts": [_alert_to_dict(a) for a in alerts],
            "count":  len(alerts),
            "limit":  limit,
        }

    except HTTPException:
        raise
    except Exception as exc:
        logger.error("list_alert_history error: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to fetch alert history")


# ─── GET /alerts/stats ────────────────────────────────────────────────────────

@router.get("/stats")
def alert_stats(
    db: Session = Depends(get_db),
    _user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Return alert counts grouped by type and by severity.

    Response shape::

        {
            "by_severity": {"critical": 5, "warning": 12, "ok": 0},
            "by_type": {
                "webhook_latency": {"critical": 3, "warning": 2},
                ...
            },
            "total": 17
        }
    """
    try:
        from sqlalchemy import func

        # Single aggregation query — avoids loading all rows into memory
        rows = (
            db.query(AlertHistory.alert_type, AlertHistory.severity, func.count().label("cnt"))
            .group_by(AlertHistory.alert_type, AlertHistory.severity)
            .all()
        )

        by_severity: Dict[str, int] = {"ok": 0, "warning": 0, "critical": 0}
        by_type: Dict[str, Dict[str, int]] = {}
        total = 0

        for alert_type, severity, cnt in rows:
            sev = severity.value if hasattr(severity, "value") else str(severity)

            by_severity[sev] = by_severity.get(sev, 0) + cnt

            if alert_type not in by_type:
                by_type[alert_type] = {}
            by_type[alert_type][sev] = by_type[alert_type].get(sev, 0) + cnt

            total += cnt

        return {
            "by_severity": by_severity,
            "by_type":     by_type,
            "total":       total,
        }

    except Exception as exc:
        logger.error("alert_stats error: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to fetch alert stats")


# ─── GET /alerts/{alert_id} ───────────────────────────────────────────────────

@router.get("/{alert_id}")
def get_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    _user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Return a single alert record by its integer ID.

    Raises 404 if the alert does not exist.
    """
    try:
        alert = db.query(AlertHistory).filter(AlertHistory.id == alert_id).first()
        if not alert:
            raise HTTPException(status_code=404, detail=f"Alert {alert_id} not found")
        return _alert_to_dict(alert)

    except HTTPException:
        raise
    except Exception as exc:
        logger.error("get_alert(%s) error: %s", alert_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to fetch alert")
