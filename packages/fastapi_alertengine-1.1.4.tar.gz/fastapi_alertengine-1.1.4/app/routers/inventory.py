"""
Merchant Inventory router.

Endpoints
---------
POST /merchant/{merchant_phone}/inventory/add-or-update
    Upsert a catalogue item (name, price, quantity, reorder_level, …)

GET  /merchant/{merchant_phone}/inventory
    Dashboard view: all items + aggregate totals

GET  /catalogue/{merchant_phone}
    Public catalogue: in-stock items only (for buyer-facing display)
"""

import logging
from decimal import Decimal
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.services import inventory_service
from app.routers.deals import get_db   # reuse the shared DB dependency

logger = logging.getLogger(__name__)

router = APIRouter(tags=["inventory"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class AddOrUpdateItemRequest(BaseModel):
    sku:                str            = Field(..., min_length=1, max_length=100)
    item_name:          str            = Field(..., min_length=1, max_length=200)
    price:              float          = Field(..., gt=0)
    quantity_available: int            = Field(..., ge=0)
    reorder_level:      int            = Field(default=5, ge=0)
    item_description:   Optional[str]  = None
    item_picture_url:   Optional[str]  = Field(default=None, max_length=500)


class InventoryItemResponse(BaseModel):
    id:                 int
    merchant_phone:     str
    sku:                str
    item_name:          str
    item_description:   Optional[str]
    item_picture_url:   Optional[str]
    price:              float
    quantity_available: int
    quantity_reserved:  int
    quantity_sold:      int
    quantity_free:      int
    reorder_level:      int
    status:             str


class InventoryDashboardResponse(BaseModel):
    merchant_phone:       str
    items:                List[InventoryItemResponse]
    total_skus:           int
    total_units_available: int
    total_units_reserved:  int
    total_units_sold:      int
    low_stock_count:       int


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _item_to_response(item) -> InventoryItemResponse:
    return InventoryItemResponse(
        id                 = item.id,
        merchant_phone     = item.merchant_phone,
        sku                = item.sku,
        item_name          = item.item_name,
        item_description   = item.item_description,
        item_picture_url   = item.item_picture_url,
        price              = float(item.price),
        quantity_available = item.quantity_available,
        quantity_reserved  = item.quantity_reserved,
        quantity_sold      = item.quantity_sold,
        quantity_free      = item.quantity_free,
        reorder_level      = item.reorder_level,
        status             = item.status,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/merchant/{merchant_phone}/inventory/add-or-update",
    response_model=InventoryItemResponse,
    status_code=200,
    summary="Add or update a catalogue item",
)
def add_or_update_item(
    merchant_phone: str,
    payload: AddOrUpdateItemRequest,
    db: Session = Depends(get_db),
):
    """
    Upsert a catalogue item for the given merchant.

    - If the SKU already exists its mutable fields are updated (price, name,
      description, picture, quantity, reorder_level). The ``quantity_reserved``
      and ``quantity_sold`` counters are **never** reset.
    - If the SKU is new a fresh record is created.
    """
    try:
        item = inventory_service.add_or_update_item(
            db,
            merchant_phone     = merchant_phone,
            sku                = payload.sku,
            item_name          = payload.item_name,
            price              = Decimal(str(payload.price)),
            quantity_available = payload.quantity_available,
            reorder_level      = payload.reorder_level,
            item_description   = payload.item_description,
            item_picture_url   = payload.item_picture_url,
        )
        db.commit()
        db.refresh(item)
    except Exception as exc:
        db.rollback()
        logger.error("add_or_update_item failed for %s/%s: %s", merchant_phone, payload.sku, exc)
        raise HTTPException(status_code=500, detail=str(exc))

    return _item_to_response(item)


@router.get(
    "/merchant/{merchant_phone}/inventory",
    response_model=InventoryDashboardResponse,
    summary="Merchant inventory dashboard",
)
def get_inventory_dashboard(
    merchant_phone: str,
    db: Session = Depends(get_db),
):
    """
    Return all catalogue items for the merchant along with aggregate
    totals — useful for a merchant-facing dashboard.
    """
    items = inventory_service.list_items(db, merchant_phone, in_stock_only=False)

    total_available = sum(i.quantity_available for i in items)
    total_reserved  = sum(i.quantity_reserved  for i in items)
    total_sold      = sum(i.quantity_sold       for i in items)
    low_stock_count = sum(
        1 for i in items
        if i.quantity_available <= i.reorder_level
    )

    return InventoryDashboardResponse(
        merchant_phone        = merchant_phone,
        items                 = [_item_to_response(i) for i in items],
        total_skus            = len(items),
        total_units_available = total_available,
        total_units_reserved  = total_reserved,
        total_units_sold      = total_sold,
        low_stock_count       = low_stock_count,
    )


@router.get(
    "/catalogue/{merchant_phone}",
    response_model=List[InventoryItemResponse],
    summary="Public catalogue (in-stock items)",
)
def get_catalogue(
    merchant_phone: str,
    db: Session = Depends(get_db),
):
    """
    Return only items with ``quantity_free > 0`` — suitable for the
    buyer-facing catalogue view.
    """
    items = inventory_service.get_catalogue(db, merchant_phone)
    return [_item_to_response(i) for i in items]
