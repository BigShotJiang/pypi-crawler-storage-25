# app/routers/whatsapp_bot.py
"""
Tofamba WhatsApp Bot — V2.1 (Hardened + Buyer Flow)

Merchant Onboarding
  Phase 1  /onboard_merchant  → KYC-Lite (name · ID photo · selfie · ID number)
  Phase 2  (auto-continues)   → Brand Layer (business name · wallet select · wallet number)
  Phase 3  /add_product       → Inventory (photo → Claude vision → price → variants)
           Vision fallback     → INVENTORY_NAME_MANUAL → INVENTORY_DESCRIPTION_MANUAL

Buyer Flow V1
  SHOP {slug}  → BROWSE_STORE → VIEW_PRODUCT → CONFIRM_ORDER → PAYMENT_INSTRUCTION

Hardening
  - KYC PII encrypted at rest (EncryptedText / Fernet)
  - KYC media served only via signed proxy URLs (/kyc/media/{token})
  - Slug uniqueness: DB-check + counter suffix (no UUID appended)
  - State persisted to bot_sessions table (DB) — Redis is the fast path
  - 30-min inactivity guard → RESUME_CONFIRM state
  - AI vision fallback on any parse failure
  - All messages in EN / SN (Shona) / ND (Ndebele)
"""

import base64
import json
import logging
import os
import re
import unicodedata
import uuid
from datetime import datetime, timezone, UTC, timedelta
from typing import Optional

import httpx
import redis
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response as FastAPIResponse
from sqlalchemy.orm import Session
from twilio.request_validator import RequestValidator
from twilio.rest import Client as TwilioClient
from twilio.twiml.messaging_response import MessagingResponse

from app.config import settings
from app.core.ai.intake_ai import IntakeAI
from app.core.state_machine import BotState, RESTING_STATES
from app.db import get_db
from app.security.encryption import generate_signed_url, verify_signed_url
from app.security.pii_handler import PIIHandler

logger = logging.getLogger(__name__)
pii    = PIIHandler()

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

MAX_MESSAGE_LENGTH    = 1_000
DEDUP_TTL_SECONDS     = 300         # 5 min — Twilio retry window
STATE_TTL_SECONDS     = 86_400      # 24 hr Redis TTL
INACTIVITY_SECONDS    = 30 * 60     # 30 min inactivity guard
KYC_PHOTO_MAX_RETRIES = 3

WALLET_REGEX    = re.compile(r"^\+?2637\d{8}$")
NAME_REGEX      = re.compile(r"^[A-Za-z\s'\-]{3,80}$")
ID_NUMBER_REGEX    = re.compile(r"^\d{8}[A-Z]\d{2}$")   # matches cleaned (no separators)
PASSPORT_REGEX     = re.compile(r"^[A-Z0-9]{6,20}$")
PRICE_REGEX     = re.compile(r"^\d+(\.\d{1,2})?$")

WALLET_REGEXES = {
    "ecocash": re.compile(r"^077\d{7}$"),
    "innbucks": re.compile(r"^071\d{7}$"),
    "omari":   re.compile(r"^078\d{7}$"),
}
WALLET_LABELS   = {"ecocash": "EcoCash", "innbucks": "InnBucks", "omari": "O'mari"}
WALLET_EXAMPLES = {"ecocash": "0771234567", "innbucks": "0711234567", "omari": "0781234567"}


# ─────────────────────────────────────────────────────────────────────────────
# TRILINGUAL MESSAGE CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

_MSG: dict = {

    # ── WELCOME ───────────────────────────────────────────────────────────────
    "WELCOME": {
        "EN": (
            "👋 *Welcome to Tofamba!*\n\n"
            "What would you like to do?\n"
            "1️⃣ I'm a Merchant\n"
            "2️⃣ I'm a Courier\n"
            "3️⃣ Help\n\n"
            "Or reply */onboard_merchant* for full verification."
        ),
        "SN": (
            "👋 *Mauya kuTofamba!*\n\n"
            "Chii chinoda kuitwa?\n"
            "1️⃣ Ndiri Mutengesi\n"
            "2️⃣ Ndiri Muchinjikwa\n"
            "3️⃣ Rubatsiro\n\n"
            "Kana dzosera */onboard_merchant* kunyorwa kwakakwana."
        ),
        "ND": (
            "👋 *Siyalemukela eTofamba!*\n\n"
            "Ufuna ukwenzani?\n"
            "1️⃣ NgingumThengisi\n"
            "2️⃣ NginguSomqhubi\n"
            "3️⃣ Usizo\n\n"
            "Noma phendula */onboard_merchant* ukubhaliswa okugcwele."
        ),
    },

    # ── STATE RECOVERY ────────────────────────────────────────────────────────
    "RESUME_CONFIRM": {
        "EN": (
            "⏸️ It looks like you were in the middle of something.\n\n"
            "Would you like to *continue where you left off*?\n\n"
            "Reply *YES* to resume or *NO* to start over."
        ),
        "SN": (
            "⏸️ Zvinoita sezvo waive pakati pokuita chimwe chinhu.\n\n"
            "Unoda *kurambidzira kubva pawakarega*?\n\n"
            "Dzosera *HONGU* kurambidzira kana *KWETE* kutanga patsva."
        ),
        "ND": (
            "⏸️ Kubonakala sengathi ubusemaceleni okwenye into.\n\n"
            "Ufuna *ukuqhubeka lapho owama khona*?\n\n"
            "Phendula *YEBO* ukuqhubeka noma *CHA* ukuqala patsva."
        ),
    },
    "RESUME_NO": {
        "EN": "🔄 Starting fresh! Send */onboard_merchant* or reply *1* for Merchant, *2* for Courier.",
        "SN": "🔄 Kutanga patsva! Tumira */onboard_merchant* kana dzosera *1* yeMutengesi, *2* yeMuchinjikwa.",
        "ND": "🔄 Ukuqala patsva! Thumela */onboard_merchant* noma phendula *1* ngeMthengisi, *2* ngeSomqhubi.",
    },

    # ── PHASE 1: KYC ──────────────────────────────────────────────────────────
    "KYC_NAME": {
        "EN": "📋 *Merchant Verification — Step 1 of 4*\n\nEnter your *full legal name* exactly as it appears on your national ID.",
        "SN": "📋 *Kunyorwa kweMutengesi — Chikamu 1 che4*\n\nNyora *zita rako rechokwadi* serinoratidzwa pane ikhadi rako repasi.",
        "ND": "📋 *Ukubhaliswa kweMthengisi — Isigaba 1 ku4*\n\nBhala *ibizo lakho langempela* njengoba libonakala esithuphini sakho somdabu.",
    },
    "KYC_ID_PHOTO": {
        "EN": "📸 *Step 2 of 4 — ID Photo*\n\nSend a clear photo of the *front of your national ID*.",
        "SN": "📸 *Chikamu 2 che4 — Mufananidzo weID*\n\nTumira mufananidzo wakajeka we*divi rekumberi reikhadi rako repasi*.",
        "ND": "📸 *Isigaba 2 ku4 — Isithombe se-ID*\n\nThumela isithombe esicacile *sohlangothi lwangaphambi lwesithupha sakho somdabu*.",
    },
    "KYC_ID_PHOTO_RETRY": {
        "EN": "⚠️ No photo received. Please send a *photo* of your ID. ({retries_left} attempt(s) left, or reply *SKIP*.)",
        "SN": "⚠️ Hapana mufananidzo. Tumira *mufananidzo* weikhadi. (Mhedzisiro {retries_left} dziri, kana *SKIP*.)",
        "ND": "⚠️ Akukho isithombe. Thumela *isithombe* se-ID. (Izinzame {retries_left} ezikhona, noma *SKIP*.)",
    },
    "KYC_SELFIE": {
        "EN": "🤳 *Step 3 of 4 — Selfie with ID*\n\nSend a selfie of yourself *holding your national ID*. Both your face and ID must be clearly visible.",
        "SN": "🤳 *Chikamu 3 che4 — Mufananidzo wako neikhadi*\n\nTumira mufananidzo une *ikhadi rako repasi*. Chiso chako neikhadi zvinofanira kuonekwa zvakajeka.",
        "ND": "🤳 *Isigaba 3 ku4 — Isithombe sakho le-ID*\n\nThumela isithombe sakho *ubambe isithupha sakho somdabu*. Ubuso bakho kanye ne-ID kumele kubonakale ngokucacile.",
    },
    "KYC_ID_NUMBER": {
        "EN": "🔢 *Step 4 of 4 — ID Number*\n\nEnter your national ID number.\n\nFormat: *63-123456A79*",
        "SN": "🔢 *Chikamu 4 che4 — Nhamba yeID*\n\nNyora nhamba yeikhadi rako repasi.\n\nFomu: *63-123456A79*",
        "ND": "🔢 *Isigaba 4 ku4 — Inombolo ye-ID*\n\nNgenisa inombolo yesithupha sakho somdabu.\n\nIsakhiwo: *63-123456A79*",
    },
    "KYC_ID_NUMBER_INVALID": {
        "EN": "❌ Invalid format. Enter your National ID (e.g. 63-123456X78)",
        "SN": "❌ Fomati isiriyo. Nyora ikhadi rako repasi (mfano: 63-123456X78)",
        "ND": "❌ Isakhiwo esingalungile. Ngenisa i-ID yakho yesizwe (isib.: 63-123456X78)",
    },
    "KYC_ID_TYPE": {
        "EN": (
            "🪪 *Step 4 of 4 — ID Type*\n\n"
            "What type of ID do you have?\n\n"
            "1️⃣ Zimbabwe National ID\n"
            "2️⃣ Passport (foreign nationals)"
        ),
        "SN": (
            "🪪 *Chikamu 4 che4 — Rudzi rweID*\n\n"
            "Une rudzi rupi rweID?\n\n"
            "1️⃣ Ikhadi repasi reZimbabwe\n"
            "2️⃣ Pasipoti (vatorwa)"
        ),
        "ND": (
            "🪪 *Isigaba 4 ku4 — Uhlobo lwe-ID*\n\n"
            "Ulouhlobo luni lwe-ID?\n\n"
            "1️⃣ I-ID yesizwe saseZimbabwe\n"
            "2️⃣ Iphasiphothi (abantu bezizwe)"
        ),
    },
    "KYC_ID_TYPE_INVALID": {
        "EN": "Please reply *1* for National ID or *2* for Passport.",
        "SN": "Dzosera *1* yeikhadi repasi kana *2* yepasipoti.",
        "ND": "Phendula *1* nge-ID yesizwe noma *2* ngephasiphothi.",
    },
    "KYC_PASSPORT_NUMBER": {
        "EN": "🛂 *Passport Number*\n\nEnter your passport number exactly as it appears on your passport.",
        "SN": "🛂 *Nhamba yePasipoti*\n\nNyora nhamba yepasipoti yako sezvairi kupasipoti yako.",
        "ND": "🛂 *Inombolo Yephasiphothi*\n\nNgenisa inombolo yephasiphothi yakho njengoba ibonakala ephasiphothi yakho.",
    },
    "KYC_PASSPORT_INVALID": {
        "EN": "❌ Invalid passport number. Use letters and digits only (6–20 characters).",
        "SN": "❌ Nhamba yepasipoti isiriyo. Shandisa mavara uye nhamba chete (6–20).",
        "ND": "❌ Inombolo yephasiphothi engalungile. Sebenzisa izinhlamvu nezinombolo kuphela (6–20).",
    },

    # ── PHASE 2: BRAND ────────────────────────────────────────────────────────
    "BRAND_NAME": {
        "EN": "🏪 *Business Setup — Step 1 of 3*\n\nWhat is your *business name*?\n\nReply *SKIP* to use your legal name.",
        "SN": "🏪 *Kuseta Bhizimisi — Chikamu 1 che3*\n\nIdzina rebhizimisi rako nderipi?\n\nDzosera *SKIP* kushandisa zita rako rechokwadi.",
        "ND": "🏪 *Ukumisa Ibhizinisi — Isigaba 1 ku3*\n\nIbizo lebhizinisi lakho liyini?\n\nPhendula *SKIP* ukusebenzisa ibizo lakho langempela.",
    },
    "BRAND_WALLET_SELECT": {
        "EN": "💳 *Step 2 of 3 — Select Wallet*\n\n1️⃣ EcoCash\n2️⃣ InnBucks\n3️⃣ O'mari\n\nReply 1, 2, or 3.",
        "SN": "💳 *Chikamu 2 che3 — Sarudza Purse*\n\n1️⃣ EcoCash\n2️⃣ InnBucks\n3️⃣ O'mari\n\nDzosera 1, 2, kana 3.",
        "ND": "💳 *Isigaba 2 ku3 — Khetha Isikhwama*\n\n1️⃣ EcoCash\n2️⃣ InnBucks\n3️⃣ O'mari\n\nPhendula 1, 2, noma 3.",
    },
    "BRAND_WALLET_NUMBER": {
        "EN": "📱 *Step 3 of 3 — {wallet_type} Number*\n\nEnter your {wallet_type} number (e.g. {example}):",
        "SN": "📱 *Chikamu 3 che3 — Nhamba ye{wallet_type}*\n\nNyora nhamba yako ye{wallet_type} (p.s. {example}):",
        "ND": "📱 *Isigaba 3 ku3 — Inombolo ye{wallet_type}*\n\nNgenisa inombolo yakho ye{wallet_type} (isibonelo: {example}):",
    },
    "BRAND_WALLET_INVALID": {
        "EN": "⚠️ Invalid {wallet_type} number. Expected format: *{example}*",
        "SN": "⚠️ Nhamba ye{wallet_type} haienderani. Fomati inotarisirwa: *{example}*",
        "ND": "⚠️ Inombolo ye{wallet_type} ayivumelekile. Isakhiwo esifanele: *{example}*",
    },
    "BRAND_WALLET_CONFIRM": {
        "EN": "📱 You entered: *{number}*\n\nIs this correct? Reply *YES* to confirm or *NO* to re-enter.",
        "SN": "📱 Waisa: *{number}*\n\nNdezvo here? Dzosera *HONGU* kusimbidza kana *KWETE* kudzosera.",
        "ND": "📱 Wangenisa: *{number}*\n\nNgabe kulungile? Phendula *YEBO* ukuqinisekisa noma *CHA* ukufaka kabusha.",
    },
    "BRAND_COMPLETE": {
        "EN": "✅ *Your store is live!*\n\n🏪 *{business_name}*\n🔗 Link: {entry_link}\n\nReply */add_product* to list your first item.",
        "SN": "✅ *Chitoro chako chiri kushanda!*\n\n🏪 *{business_name}*\n🔗 Munyorwa: {entry_link}\n\nDzosera */add_product* kuisa chinhu chako chekutanga.",
        "ND": "✅ *Isitolo sakho siyasebenza!*\n\n🏪 *{business_name}*\n🔗 Isixhumanisi: {entry_link}\n\nPhendula */add_product* ukwengeza into yakho yokuqala.",
    },

    # ── PHASE 3: INVENTORY ────────────────────────────────────────────────────
    "INVENTORY_PHOTO": {
        "EN": "📷 *Add Product — Step 1*\n\nSend a clear photo of the product. I'll detect the name and description automatically.",
        "SN": "📷 *Wedzera Chigadzirwa — Chikamu 1*\n\nTumira mufananidzo wakajeka. Ndichaona zita nekutsanangurwa zvakatomatiki.",
        "ND": "📷 *Engeza Umkhiqizo — Isigaba 1*\n\nThumela isithombe esicacile. Ngizothola igama nenchazelo ngokuzenzakalelayo.",
    },
    "INVENTORY_PHOTO_NEEDED": {
        "EN": "📷 Please send a *photo* of the product to continue.",
        "SN": "📷 Tumira *mufananidzo* wechigadzirwa kuti urambe uchienda.",
        "ND": "📷 Thumela *isithombe* somkhiqizo ukuqhubeka.",
    },
    "INVENTORY_CONFIRM_DETAILS": {
        "EN": "✅ *Product detected:*\n\n*{name}*\n{description}\n\nReply *YES* to confirm, or type a corrected name.",
        "SN": "✅ *Chigadzirwa chawanikwa:*\n\n*{name}*\n{description}\n\nDzosera *HONGU* kusimbisa, kana nyora zita rakaregedzwa.",
        "ND": "✅ *Umkhiqizo utholakele:*\n\n*{name}*\n{description}\n\nPhendula *YEBO* ukukhomba, noma bhala igama eliluliwe.",
    },
    "INVENTORY_PRICE": {
        "EN": "💵 *Step 3 — Price*\n\nEnter the selling price in USD (e.g. *12.50*):",
        "SN": "💵 *Chikamu 3 — Mutengo*\n\nNyora mutengo muUSD (p.s. *12.50*):",
        "ND": "💵 *Isigaba 3 — Intengo*\n\nNgenisa intengo nge-USD (isibonelo: *12.50*):",
    },
    "INVENTORY_PRICE_INVALID": {
        "EN": "❌ Invalid price. Enter a positive amount, e.g. *12.50*",
        "SN": "❌ Mutengo usiriyo. Nyora mari yakaenzana, p.s. *12.50*",
        "ND": "❌ Intengo ayivumelekile. Ngenisa inani elilungile, isibonelo: *12.50*",
    },
    "INVENTORY_HAS_VARIANTS": {
        "EN": "🎨 *Step 4 — Variants*\n\nDoes this product come in different sizes, colours, or versions?\n\nReply *YES* or *NO*.",
        "SN": "🎨 *Chikamu 4 — Marudzi*\n\nChigadzirwa ichi chinouya mukumitero, mavara kana sura dzakasiyanasiyana?\n\nDzosera *HONGU* kana *KWETE*.",
        "ND": "🎨 *Isigaba 4 — Izinhlobo*\n\nLo mkhiqizo uza ngezinhloko ezihlukene, imibala, noma izinguqulo?\n\nPhendula *YEBO* noma *CHA*.",
    },
    "INVENTORY_VARIANT_LABEL": {
        "EN": "🏷️ Enter a variant label (e.g. *Red*, *XL*, *128GB*).\n\nReply *DONE* when finished.",
        "SN": "🏷️ Nyora chiratidzo chemarudzi (p.s. *Tsvuku*, *XL*, *128GB*).\n\nDzosera *MAPEDZO* paunenge waisa marudzi ose.",
        "ND": "🏷️ Ngenisa uphawu lwezinhlobo (isibonelo: *Bomvu*, *XL*, *128GB*).\n\nPhendula *QEDILE* uma ungezile zonke izinhlobo.",
    },
    "INVENTORY_VARIANT_QTY": {
        "EN": "📦 How many units of *{label}* do you have in stock?",
        "SN": "📦 Une zvingani zve*{label}* muhomwe?",
        "ND": "📦 Unezingaki ezi-*{label}* endaweni yakho?",
    },
    "INVENTORY_QTY_INVALID": {
        "EN": "❌ Please enter a whole number ≥ 0, e.g. *10*",
        "SN": "❌ Nyora nhamba yakakwana ≥ 0, p.s. *10*",
        "ND": "❌ Ngenisa inombolo ephelele ≥ 0, isibonelo: *10*",
    },
    "INVENTORY_TOTAL_QTY": {
        "EN": "📦 *Step 5 — Stock*\n\nHow many units do you have in stock?",
        "SN": "📦 *Chikamu 5 — Zvinowanikwa*\n\nUne zvingani zvichikanganiswa?",
        "ND": "📦 *Isigaba 5 — Izikhala*\n\nUnezingaki ezitholakala endaweni yakho?",
    },
    "INVENTORY_LISTED": {
        "EN": "✅ *Product Listed!*\n\n🛍️ *{name}*\n💵 ${price}\n\n🔗 Buy link: {buy_link}\n\nReply */add_product* to list another.",
        "SN": "✅ *Chigadzirwa Charekodwa!*\n\n🛍️ *{name}*\n💵 ${price}\n\n🔗 Renda munyorwa: {buy_link}\n\nDzosera */add_product* kuwedzera chimwe.",
        "ND": "✅ *Umkhiqizo Ubhaliwe!*\n\n🛍️ *{name}*\n💵 ${price}\n\n🔗 Isixhumanisi sokuthengisa: {buy_link}\n\nPhendula */add_product* ukwengeza enye.",
    },
    # Vision fallback
    "INVENTORY_NAME_MANUAL": {
        "EN": "🤔 I couldn't detect the product name from the photo.\n\nWhat is the *product name*?",
        "SN": "🤔 Handikwanisi kuona zita rechigadzirwa kubva mufananidzo.\n\nIsi *zita rechigadzirwa*?",
        "ND": "🤔 Angikwazi ukuthola igama lomkhiqizo esithombeni.\n\nIgama *lomkhiqizo* liyini?",
    },
    "INVENTORY_DESCRIPTION_MANUAL": {
        "EN": "📝 Got it! Now give me a short *description* for *{name}*:",
        "SN": "📝 Zvakanaka! Ipa pfupi *kutsanangurwa* kwe*{name}*:",
        "ND": "📝 Kulungile! Manje ngipha *inchazelo* emfushane ye-*{name}*:",
    },

    # ── BUYER FLOW ────────────────────────────────────────────────────────────
    "BROWSE_STORE": {
        "EN": "🛍️ *{store_name}*\n\n{product_list}\n\nReply with a number to view a product.",
        "SN": "🛍️ *{store_name}*\n\n{product_list}\n\nDzosera nenhamba kuona chigadzirwa.",
        "ND": "🛍️ *{store_name}*\n\n{product_list}\n\nPhendula ngenombolo ukubona umkhiqizo.",
    },
    "BROWSE_EMPTY": {
        "EN": "🏪 *{store_name}* has no products listed yet.",
        "SN": "🏪 *{store_name}* haina zvigadzirwa zvakaiswa zvakamirira.",
        "ND": "🏪 *{store_name}* ayanamkhiqizo oshiwoyo.",
    },
    "STORE_NOT_FOUND": {
        "EN": "❌ Store not found. Please check the link.",
        "SN": "❌ Chitoro hachiwanikanwi. Tarisa munyorwa.",
        "ND": "❌ Isitolo asitholakali. Hlola isixhumanisi.",
    },
    "VIEW_PRODUCT_HEADER": {
        "EN": "🛍️ *{name}*\n💵 ${price}\n\n{description}\n\n",
        "SN": "🛍️ *{name}*\n💵 ${price}\n\n{description}\n\n",
        "ND": "🛍️ *{name}*\n💵 ${price}\n\n{description}\n\n",
    },
    "VIEW_PRODUCT_VARIANTS": {
        "EN": "📦 *Variants:*\n{variant_list}\n\nReply with a number to select, or *BACK* to browse.",
        "SN": "📦 *Marudzi:*\n{variant_list}\n\nDzosera nenhamba kusarudza, kana *DZOKA* kutarisa.",
        "ND": "📦 *Izinhlobo:*\n{variant_list}\n\nPhendula ngenombolo ukukhetha, noma *EMUVA* ukubhrowza.",
    },
    "VIEW_PRODUCT_NO_VARIANTS": {
        "EN": "📦 *{qty}* in stock\n\nReply *BUY* to purchase, or *BACK* to browse.",
        "SN": "📦 *{qty}* muhomwe\n\nDzosera *TENGA* kutenga, kana *DZOKA* kutarisa.",
        "ND": "📦 *{qty}* esitokweni\n\nPhendula *THENGA* ukuthenga, noma *EMUVA* ukubhrowza.",
    },
    "VIEW_PRODUCT_OOS": {
        "EN": "❌ This product is currently out of stock.\n\nReply *BACK* to browse other products.",
        "SN": "❌ Chigadzirwa ichi chine nguva ichi hachipo muhomwe.\n\nDzosera *DZOKA* kuona zvimwe zvigadzirwa.",
        "ND": "❌ Lo mkhiqizo awukho esitokweni njengamanje.\n\nPhendula *EMUVA* ukubhrowza ezinye izinto.",
    },
    "VARIANT_INVALID": {
        "EN": "⚠️ Invalid selection. Please reply with a number from the list.",
        "SN": "⚠️ Sarudzo isiriyo. Dzosera nenhamba kubva mune rondedzero.",
        "ND": "⚠️ Ukukhetha okungavumelekile. Phendula ngenombolo kusuka ohlwini.",
    },
    "CONFIRM_ORDER": {
        "EN": "🛒 *Order Summary*\n\n🛍️ {product_name}\n{variant_line}💵 ${price}\n\nConfirm? Reply *YES* to proceed or *NO* to cancel.",
        "SN": "🛒 *Mutsara weOda*\n\n🛍️ {product_name}\n{variant_line}💵 ${price}\n\nSimbisa? Dzosera *HONGU* kurambidzira kana *KWETE* kugumisa.",
        "ND": "🛒 *Isifinyezo se-Oda*\n\n🛍️ {product_name}\n{variant_line}💵 ${price}\n\nQinisekisa? Phendula *YEBO* ukuqhubeka noma *CHA* ukukhansela.",
    },
    "PAYMENT_INSTRUCTION": {
        "EN": (
            "💳 *Payment Instructions*\n\n"
            "Send *${amount}* to:\n"
            "📱 {wallet_type}: *{wallet_number}*\n\n"
            "⚠️ *Reference (REQUIRED):* `{reference_code}`\n\n"
            "You MUST include the reference in your payment description.\n\n"
            "⏳ Order expires in 30 minutes.\n"
            "📋 Order ID: `{order_id}`"
        ),
        "SN": (
            "💳 *Mirayiridzo yekubhadhara*\n\n"
            "Tumira *${amount}* kuenda:\n"
            "📱 {wallet_type}: *{wallet_number}*\n\n"
            "⚠️ *Referensi (INODIKANWA):* `{reference_code}`\n\n"
            "UNOFANIRA kuisa referensi mubhadharo rako.\n\n"
            "⏳ Oda rinopera mumaminitsi makumi matatu.\n"
            "📋 ID yeOda: `{order_id}`"
        ),
        "ND": (
            "💳 *Imiyalelo Yokukhokha*\n\n"
            "Thumela *${amount}* kuya:\n"
            "📱 {wallet_type}: *{wallet_number}*\n\n"
            "⚠️ *Ireferensi (IYADINGEKA):* `{reference_code}`\n\n"
            "KUMELE ufake ireferensi ukukhokha kwakho.\n\n"
            "⏳ I-oda iphelelwa yisikhathi emaminini angu-30.\n"
            "📋 I-ID ye-Oda: `{order_id}`"
        ),
    },
    "ORDER_CANCELLED": {
        "EN": "❌ Order cancelled. Reply *BACK* to browse.",
        "SN": "❌ Oda ragumiswa. Dzosera *DZOKA* kutarisa.",
        "ND": "❌ I-oda ikhansiliwe. Phendula *EMUVA* ukubhrowza.",
    },

    # ── LEGACY MERCHANT V1 ────────────────────────────────────────────────────
    "MERCHANT_STEP1": {
        "EN": "🏪 *Merchant Onboarding — Step 1 of 2*\n\nSend your *full business name*.\n\n_(For full KYC reply */onboard_merchant*)_",
        "SN": "🏪 *Kunyorwa kweMutengesi — Chikamu 1 che2*\n\nTumira *zita rako rebhizimisi*.",
        "ND": "🏪 *Ukubhaliswa kweMthengisi — Isigaba 1 ku2*\n\nThumela *ibizo lakho lebhizinisi*.",
    },
    "MERCHANT_STEP2": {
        "EN": "✅ Thanks, *{name}*!\n\nSend your *EcoCash / InnBucks number* to receive payments.\n\nFormat: 0771234567",
        "SN": "✅ Maita basa, *{name}*!\n\nTumira *nhamba yako yeEcoCash / InnBucks*.",
        "ND": "✅ Ngiyabonga, *{name}*!\n\nThumela *inombolo yakho ye-EcoCash / InnBucks*.",
    },
    "MERCHANT_COMPLETE": {
        "EN": "🎉 *Welcome aboard, {name}!*\n\nYour account is active.\n💰 Fee: 3.5% + 15.5% VAT + 2% IMTT\n\nReply */add_product* to list an item.",
        "SN": "🎉 *Mauya, {name}!*\n\nAkaunti yako iripo.\n💰 Muripo: 3.5% + 15.5% VAT + 2% IMTT\n\nDzosera */add_product*.",
        "ND": "🎉 *Siyalemukela, {name}!*\n\nI-akhawunti yakho iyasebenza.\n💰 Ifizi: 3.5% + 15.5% VAT + 2% IMTT\n\nPhendula */add_product*.",
    },

    # ── COURIER ───────────────────────────────────────────────────────────────
    "COURIER_STEP1": {
        "EN": "🚗 *Courier Signup — Step 1 of 3*\n\nSend your *full name*.",
        "SN": "🚗 *Kunyorwa kweMuchinjikwa — Chikamu 1 che3*\n\nTumira *zita rako rakazara*.",
        "ND": "🚗 *Ukubhaliswa kukaSomqhubi — Isigaba 1 ku3*\n\nThumela *igama lakho eligcwele*.",
    },
    "COURIER_STEP2": {
        "EN": "Thanks, *{name}*!\n\n🚗 *Step 2 of 3*\n\nVehicle?\n1️⃣ Motorcycle\n2️⃣ Bicycle\n3️⃣ Car\n4️⃣ On foot\n\nReply 1–4.",
        "SN": "Maita, *{name}*!\n\n🚗 *Chikamu 2 che3*\n\nMota?\n1️⃣ Mota imwe chete\n2️⃣ Bhasikoro\n3️⃣ Motokari\n4️⃣ Netsoka\n\nDzosera 1–4.",
        "ND": "Ngiyabonga, *{name}*!\n\n🚗 *Isigaba 2 ku3*\n\nIvayelando?\n1️⃣ Imoto encane\n2️⃣ Ibhayisikili\n3️⃣ Imoto\n4️⃣ Ngezinyawo\n\nPhendula 1–4.",
    },
    "COURIER_STEP3": {
        "EN": "✅ Vehicle: *{vehicle}*\n\n🚗 *Step 3 of 3*\n\nSend your *EcoCash / InnBucks number*.\n\nFormat: 0771234567",
        "SN": "✅ Mota: *{vehicle}*\n\n🚗 *Chikamu 3 che3*\n\nTumira *nhamba yako yeEcoCash / InnBucks*.",
        "ND": "✅ Ivayelando: *{vehicle}*\n\n🚗 *Isigaba 3 ku3*\n\nThumela *inombolo yakho ye-EcoCash / InnBucks*.",
    },
    "COURIER_COMPLETE": {
        "EN": "🎉 *Welcome, {name}!*\n\nYour courier account is active. Start earning today!",
        "SN": "🎉 *Mauya, {name}!*\n\nAkaunti yako yemuchinjikwa iripo. Tanga kuwana mari nhasi!",
        "ND": "🎉 *Siyalemukela, {name}!*\n\nI-akhawunti yakho yomqhubi iyasebenza. Qala ukuhola namhlanje!",
    },

    # ── MISC ──────────────────────────────────────────────────────────────────
    "INVALID_WALLET": {
        "EN": "⚠️ Invalid Zimbabwean mobile number. Format: *0771234567*",
        "SN": "⚠️ Nhamba yemobile yeZimbabwe isiriyo. Fomati: *0771234567*",
        "ND": "⚠️ Inombolo yomakhalekhukhwini eZimbabwe ayivumelekile. Isakhiwo: *0771234567*",
    },
    "INVALID_NAME": {
        "EN": "Please provide a valid name (letters only, 3–80 characters).",
        "SN": "Nyora zita rakakodzera (mavara chete, 3–80).",
        "ND": "Bhala igama elivumelekile (izinhlamvu kuphela, 3–80).",
    },
    "NOT_REGISTERED": {
        "EN": "⚠️ Complete merchant onboarding first.\n\nReply */onboard_merchant*.",
        "SN": "⚠️ Tanga kunyorwa kwemutengesi.\n\nDzosera */onboard_merchant*.",
        "ND": "⚠️ Qedela ukubhaliswa kwemthengisi kuqala.\n\nPhendula */onboard_merchant*.",
    },
    "ERROR": {
        "EN": "❌ Something went wrong. Please try again or contact support@anchorflow.com",
        "SN": "❌ Pane chakashata. Edza zvakare kana taura: support@anchorflow.com",
        "ND": "❌ Kukhona okungahambanga kahle. Zama futhi noma: support@anchorflow.com",
    },
    "HELP": {
        "EN": (
            "❓ *Tofamba Help*\n\n"
            "1️⃣ Payment issue\n"
            "2️⃣ Update details\n"
            "3️⃣ Commission info\n"
            "4️⃣ Something else\n"
            "5️⃣ Talk to support\n\n"
            "Commands: */onboard_merchant* · */add_product* · *SHOP {slug}*\n\n"
            "Reply with your choice (1–5)"
        ),
        "SN": (
            "❓ *Rubatsiro rweTofamba*\n\n"
            "1️⃣ Dambudziko remari\n"
            "2️⃣ Shandura ruzivo\n"
            "3️⃣ Ruzivo rwekomisheni\n"
            "4️⃣ Chimwe chinhu\n"
            "5️⃣ Taura nesupoti\n\n"
            "Mirayiridzo: */onboard_merchant* · */add_product* · *SHOP {slug}*\n\n"
            "Dzosera sarudzo yako (1–5)"
        ),
        "ND": (
            "❓ *Usizo lweTofamba*\n\n"
            "1️⃣ Inkinga yokukhokha\n"
            "2️⃣ Buyekeza imininingwane\n"
            "3️⃣ Ulwazi lwekhomishini\n"
            "4️⃣ Enye into\n"
            "5️⃣ Khuluma nosekela\n\n"
            "Imiyalo: */onboard_merchant* · */add_product* · *SHOP {slug}*\n\n"
            "Phendula ngokukhetha kwakho (1–5)"
        ),
    },
    "PIN_PROMPT": {
        "EN": "📦 *Delivery Confirmation*\n\nOrder: *{order_ref}*\n\nEnter the *6-digit PIN* from the customer.\n\n⏳ Expires in 15 minutes.",
        "SN": "📦 *Kusimbiswa Kwekuendesa*\n\nOda: *{order_ref}*\n\nNyora *PIN yenhamba 6* kubva kumumeri.\n\n⏳ Inopera mumaminitsi gumi nemashanu.",
        "ND": "📦 *Ukuqinisekisa Ukuhambiswa*\n\nUmyalo: *{order_ref}*\n\nNgenisa *PIN yamadijithi ayisi-6* kumthengi.\n\n⏳ Iphelelwa emaminini ali-15.",
    },
}


def _t(key: str, lang: str = "EN", **kwargs) -> str:
    """Look up message key, fall back to EN, format with kwargs."""
    block    = _MSG.get(key, {})
    template = block.get(lang) or block.get("EN", f"[{key}]")
    if kwargs:
        try:
            return template.format(**kwargs)
        except KeyError:
            return template
    return template


# ─────────────────────────────────────────────────────────────────────────────
# SINGLETONS
# ─────────────────────────────────────────────────────────────────────────────

def _build_twilio_client() -> TwilioClient:
    return TwilioClient(os.environ["TWILIO_ACCOUNT_SID"], os.environ["TWILIO_AUTH_TOKEN"])

def _build_redis_client() -> redis.Redis:
    return redis.Redis.from_url(
        os.environ["REDIS_URL"],
        decode_responses=True,
        socket_connect_timeout=3,
        socket_timeout=3,
    )

_twilio_client: TwilioClient     = _build_twilio_client()
_twilio_from:   str              = os.environ["TWILIO_WHATSAPP_NUMBER"]
_redis:         redis.Redis      = _build_redis_client()
_validator:     RequestValidator = RequestValidator(os.environ["TWILIO_AUTH_TOKEN"])


# ─────────────────────────────────────────────────────────────────────────────
# OUTBOUND PUSH CLIENT
#
# ⚠️  This is for PROACTIVE (push) notifications only — payment alerts, delivery
#     assignments, PIN prompts — messages sent outside the webhook request cycle.
#     These legitimately require messages.create() because there is no open
#     webhook response to write into.
#
# ✅  CONVERSATIONAL REPLIES (the bot answering a user's message) do NOT use
#     this class.  The webhook handler calls _bot.handle_message(), which returns
#     a plain string, then wraps it in TwiML and returns it as the HTTP response:
#
#         twiml = MessagingResponse()
#         twiml.message(reply)
#         return FastAPIResponse(content=str(twiml), media_type="application/xml")
#
#     Twilio delivers that TwiML as the outbound message with ZERO outbound API
#     calls and no impact on daily message limits.
# ─────────────────────────────────────────────────────────────────────────────

class TwilioWhatsAppClient:
    """Outbound push notifications only. Never call this from the webhook reply path."""

    def send_message(self, to_phone: str, body: str) -> Optional[str]:
        # Normalise to E.164 — local 077XXXXXXX → +263XXXXXXX
        digits = re.sub(r"\D", "", to_phone)
        if digits.startswith("263") and len(digits) == 12:
            to_phone = f"+{digits}"
        elif digits.startswith("0") and len(digits) == 10:
            to_phone = f"+263{digits[1:]}"
        elif not to_phone.startswith("+"):
            to_phone = f"+{digits}"

        from_  = f"whatsapp:{_twilio_from}"
        to     = f"whatsapp:{to_phone}"
        print(f"[PUSH] Sending WhatsApp: from={from_} to={to}")
        try:
            msg = _twilio_client.messages.create(
                from_=from_,
                to=to,
                body=body,
            )
            print(f"✅ Twilio push OK — SID: {msg.sid}")
            logger.info(f"Push sent to {pii.mask_user_id(to_phone)} SID={msg.sid}")
            return msg.sid
        except Exception as e:
            print(f"❌ Twilio push FAILED")
            print(f"Type: {type(e).__name__}")
            print(f"Error: {str(e)}")
            logger.error(f"Push failed {pii.mask_user_id(to_phone)}: {e}")
            return None


# ─────────────────────────────────────────────────────────────────────────────
# REDIS STATE HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _state_key(phone: str)       -> str: return f"bot:state:{phone}"
def _temp_key(phone: str, f: str) -> str: return f"bot:tmp:{phone}:{f}"
def _lang_key(phone: str)        -> str: return f"bot:lang:{phone}"
def _activity_key(phone: str)    -> str: return f"bot:activity:{phone}"


def get_user_state(phone: str) -> BotState:
    val = _redis.get(_state_key(phone))
    try:
        return BotState(val) if val else BotState.INITIAL
    except ValueError:
        return BotState.INITIAL

def set_user_state(phone: str, state: BotState) -> None:
    _redis.setex(_state_key(phone), STATE_TTL_SECONDS, state.value)

def store_temp(phone: str, field: str, value: str) -> None:
    _redis.setex(_temp_key(phone, field), STATE_TTL_SECONDS, value)

def get_temp(phone: str, field: str) -> Optional[str]:
    return _redis.get(_temp_key(phone, field))

def clear_temp(phone: str, *fields: str) -> None:
    keys = [_temp_key(phone, f) for f in fields]
    if keys:
        _redis.delete(*keys)

def get_user_lang(phone: str) -> str:
    return _redis.get(_lang_key(phone)) or "EN"

def set_user_lang(phone: str, lang: str) -> None:
    if lang in ("EN", "SN", "ND"):
        _redis.setex(_lang_key(phone), STATE_TTL_SECONDS, lang)

def _force_reset_session(phone: str) -> None:
    """Delete ALL Redis keys for phone — hard-reset triggered by /onboard_merchant."""
    fixed_keys = [_state_key(phone), _lang_key(phone), _activity_key(phone)]
    tmp_keys   = _redis.keys(f"bot:tmp:{phone}:*")
    all_keys   = fixed_keys + (list(tmp_keys) if tmp_keys else [])
    _redis.delete(*all_keys)
    print(f"Force-reset: cleared {len(all_keys)} Redis keys for {pii.mask_user_id(phone)}")

def _update_activity_redis(phone: str) -> None:
    _redis.setex(_activity_key(phone), STATE_TTL_SECONDS,
                 str(datetime.now(UTC).timestamp()))

def _get_activity_redis(phone: str) -> Optional[datetime]:
    ts = _redis.get(_activity_key(phone))
    return datetime.fromtimestamp(float(ts), UTC) if ts else None


# ─────────────────────────────────────────────────────────────────────────────
# DB-BACKED SESSION (state recovery)
# ─────────────────────────────────────────────────────────────────────────────

def _sync_session(db: Session, phone: str, state: BotState) -> None:
    """Upsert bot_sessions row — keeps DB in sync on every state change."""
    from app.models.database import BotSession
    now = datetime.now(UTC)
    session = db.query(BotSession).filter(BotSession.phone == phone).first()
    if session:
        session.state         = state.value
        session.last_activity = now
        session.updated_at    = now
    else:
        session = BotSession(phone=phone, state=state.value, last_activity=now)
        db.add(session)
    try:
        db.commit()
    except Exception as exc:
        db.rollback()
        logger.warning(f"BotSession sync failed for {pii.mask_user_id(phone)}: {exc}")


def _load_state_from_db(db: Session, phone: str) -> Optional[BotState]:
    """Load last known state from bot_sessions (Redis-miss fallback)."""
    from app.models.database import BotSession
    try:
        session = db.query(BotSession).filter(BotSession.phone == phone).first()
        if session:
            return BotState(session.state)
    except Exception:
        pass
    return None


def _get_last_activity_db(db: Session, phone: str) -> Optional[datetime]:
    """Return last_activity from DB (used when Redis key is missing)."""
    from app.models.database import BotSession
    try:
        session = db.query(BotSession).filter(BotSession.phone == phone).first()
        return session.last_activity if session else None
    except Exception:
        return None


# ─────────────────────────────────────────────────────────────────────────────
# DEDUPLICATION
# ─────────────────────────────────────────────────────────────────────────────

def _is_duplicate(message_sid: str) -> bool:
    key = f"bot:dedup:{message_sid}"
    return not _redis.set(key, "1", ex=DEDUP_TTL_SECONDS, nx=True)


# ─────────────────────────────────────────────────────────────────────────────
# INPUT HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def sanitise(text: str) -> str:
    text = text[:MAX_MESSAGE_LENGTH]
    text = re.sub(r"[\x00-\x1f\x7f]", "", text)
    return text.strip()

def normalise_wallet(raw: str) -> Optional[str]:
    digits = re.sub(r"\D", "", raw)
    if digits.startswith("263") and len(digits) == 12:
        normalised = f"+{digits}"
    elif digits.startswith("0") and len(digits) == 10:
        normalised = f"+263{digits[1:]}"
    else:
        return None
    return normalised if WALLET_REGEX.match(normalised) else None

def normalise_wallet_by_type(raw: str, wallet_type: str) -> Optional[str]:
    """
    Accept 077XXXXXXX / 71XXXXXXX / 78XXXXXXX (10 digits with leading 0),
    77XXXXXXX / 71XXXXXXX / 78XXXXXXX (9 digits, no leading 0),
    or 263XXXXXXXXX (12 digits with country code).
    Returns normalised 077XXXXXXX local format, or None if invalid.
    """
    digits = re.sub(r"\D", "", raw)
    if digits.startswith("263") and len(digits) == 12:
        local = "0" + digits[3:]
    elif digits.startswith("0") and len(digits) == 10:
        local = digits
    elif len(digits) == 9:
        # No leading zero — e.g. 771234567 → 0771234567
        local = "0" + digits
    else:
        return None
    pattern = WALLET_REGEXES.get(wallet_type)
    if not pattern or not pattern.match(local):
        return None
    return local  # Return 077XXXXXXX local format


# ─────────────────────────────────────────────────────────────────────────────
# SLUG GENERATION (unique, collision-safe)
# ─────────────────────────────────────────────────────────────────────────────

def _to_slug(name: str) -> str:
    """Convert name to lowercase, hyphenated, alphanumeric slug. No suffix."""
    name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    name = name.lower()
    name = re.sub(r"[^\w\s-]", "", name)
    return re.sub(r"[-\s]+", "-", name).strip("-")

def generate_unique_slug(db: Session, name: str, max_attempts: int = 50) -> str:
    """
    Generate a slug from *name* that is unique in the merchants table.
    If the base slug is taken, appends an incrementing counter:
      "leo-store" → "leo-store-2" → "leo-store-3" …
    Falls back to a UUID suffix after max_attempts.
    """
    from app.models.database import Merchant
    base = _to_slug(name) or "store"
    for i in range(max_attempts):
        slug = base if i == 0 else f"{base}-{i + 1}"
        if not db.query(Merchant).filter(Merchant.slug == slug).first():
            return slug
    return f"{base}-{uuid.uuid4().hex[:6]}"


# ─────────────────────────────────────────────────────────────────────────────
# MEDIA + CLAUDE VISION
# ─────────────────────────────────────────────────────────────────────────────

def download_twilio_media(media_url: str) -> bytes:
    """Download Twilio media with Basic Auth (account_sid:auth_token)."""
    sid   = os.environ["TWILIO_ACCOUNT_SID"]
    token = os.environ["TWILIO_AUTH_TOKEN"]
    with httpx.Client(timeout=30) as client:
        resp = client.get(media_url, auth=(sid, token))
        resp.raise_for_status()
        return resp.content

def call_claude_vision(image_bytes: bytes, media_type: str = "image/jpeg") -> dict:
    """
    Send a product image to claude-sonnet-4-5 and extract name + description.

    Returns {"name": str, "description": str}.
    Raises on API error, network failure, or malformed JSON so callers can
    transition to the INVENTORY_NAME_MANUAL fallback state.
    """
    import anthropic  # lazy import
    api_key = os.environ.get("ANTHROPIC_API_KEY") or settings.anthropic_api_key
    client  = anthropic.Anthropic(api_key=api_key)

    b64 = base64.standard_b64encode(image_bytes).decode()
    # VISION MODEL — do NOT change to Haiku (no image support)
    msg = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=256,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {"type": "base64", "media_type": media_type, "data": b64},
                },
                {
                    "type": "text",
                    "text": (
                        "Look at this product image. "
                        "Return ONLY valid JSON — no markdown, no extra text:\n"
                        '{"name": "short product name", "description": "one sentence description"}'
                    ),
                },
            ],
        }],
    )
    raw = msg.content[0].text.strip()
    # Strip markdown fences if the model includes them
    raw = re.sub(r"^```[a-z]*\n?", "", raw)
    raw = re.sub(r"\n?```$", "", raw)
    result = json.loads(raw)
    if "name" not in result or "description" not in result:
        raise ValueError("Missing keys in Claude response")
    return result


# ─────────────────────────────────────────────────────────────────────────────
# BOT CORE
# ─────────────────────────────────────────────────────────────────────────────

YES_WORDS  = {"yes", "hongu", "yebo", "y", "ok", "okay", "confirm"}
NO_WORDS   = {"no", "kwete", "cha", "n", "cancel"}
BACK_WORDS = {"back", "dzoka", "emuva"}
BUY_WORDS  = {"buy", "tenga", "thenga"}
DONE_WORDS = {"done", "mapedzo", "qedile"}


class AIRouter:
    """
    AI layer that interprets user input BEFORE the state machine dispatches.
    Suggests (but does NOT force) next state transitions.
    Runs synchronously — IntakeAI uses the blocking Anthropic client.
    """

    @staticmethod
    def process(body: str, current_state: BotState) -> dict:
        try:
            ai_data = IntakeAI.parse_onboarding(body)
            intent = AIRouter._detect_intent(body, ai_data)
            suggested_next = AIRouter._suggest_next(current_state, ai_data, intent)
            return {
                "extracted": ai_data,
                "intent": intent,
                "suggested_next_phase": suggested_next,
                "raw": body,
            }
        except Exception as e:
            print(f"[AIRouter] error: {e}")
            return {
                "extracted": {},
                "intent": "unknown",
                "suggested_next_phase": None,
                "raw": body,
            }

    @staticmethod
    def _detect_intent(body: str, ai_data: dict) -> str:
        b = body.lower()
        if "/onboard_merchant" in b:
            return "onboard"
        if "/add_product" in b:
            return "add_product"
        if any(x in b for x in ["hi", "hello", "hey", "start"]):
            return "greeting"
        if ai_data.get("wallet"):
            return "provide_wallet"
        if ai_data.get("merchant_name"):
            return "provide_name"
        if ai_data.get("location"):
            return "provide_location"
        return "reply"

    @staticmethod
    def _suggest_next(
        current_state: BotState,
        ai_data: dict,
        intent: str,
    ) -> Optional[BotState]:
        # Route idle/initial users directly into KYC when they signal intent
        if current_state in RESTING_STATES and intent == "onboard":
            return BotState.KYC_NAME
        if current_state in RESTING_STATES and intent == "add_product":
            return BotState.INVENTORY_PHOTO
        # Skip wallet entry if the number was provided naturally in context
        if current_state == BotState.BRAND_WALLET_NUMBER and ai_data.get("wallet"):
            return BotState.BRAND_WALLET_CONFIRM
        return None


class TandemWhatsAppBot:

    def __init__(self):
        self.twilio = TwilioWhatsAppClient()

    # ── Message entry point ────────────────────────────────────────────────────

    def handle_message(
        self,
        db: Session,
        phone: str,
        message_text: str,
        media_url: str = "",
        num_media: int = 0,
    ) -> str:
        message_text = sanitise(message_text)
        lang         = get_user_lang(phone)

        # ── Language switch ──────────────────────────────────────────────────
        if message_text.upper() in ("EN", "SN", "ND"):
            set_user_lang(phone, message_text.upper())
            return f"Language set to {message_text.upper()}.\n\n" + _t("HELP", message_text.upper())

        # ── Load state: Redis → DB fallback ───────────────────────────────────
        state = get_user_state(phone)
        if state == BotState.INITIAL:
            db_state = _load_state_from_db(db, phone)
            if db_state and db_state not in (BotState.INITIAL, None):
                state = db_state
                set_user_state(phone, state)

        logger.info(f"[{pii.mask_user_id(phone)}] state={state.value} media={bool(media_url)}")

        # ── AI Router ─────────────────────────────────────────────────────────
        self._ai_context = AIRouter.process(message_text, state)
        logger.info(
            f"[AIRouter] intent={self._ai_context['intent']} "
            f"extracted={self._ai_context['extracted']} "
            f"suggested={self._ai_context['suggested_next_phase']}"
        )
        # Safe state suggestion — only applied from resting states to avoid
        # interrupting active KYC / onboarding flows mid-sequence
        _suggested = self._ai_context.get("suggested_next_phase")
        if _suggested and _suggested != state and state in RESTING_STATES:
            state = _suggested
            set_user_state(phone, state)

        # ── 30-min inactivity guard ───────────────────────────────────────────
        if state not in RESTING_STATES:
            last = _get_activity_redis(phone) or _get_last_activity_db(db, phone)
            if last and (datetime.now(UTC) - last).total_seconds() > INACTIVITY_SECONDS:
                store_temp(phone, "interrupted_state", state.value)
                set_user_state(phone, BotState.RESUME_CONFIRM)
                _sync_session(db, phone, BotState.RESUME_CONFIRM)
                _update_activity_redis(phone)
                return _t("RESUME_CONFIRM", lang)

        # ── Update activity ───────────────────────────────────────────────────
        _update_activity_redis(phone)

        # ── Dispatch ──────────────────────────────────────────────────────────
        try:
            handlers = {
                BotState.INITIAL:                   self._handle_initial,
                BotState.IDLE:                      self._handle_idle,
                BotState.RESUME_CONFIRM:            self._handle_resume_confirm,
                BotState.MERCHANT_NAME:             self._handle_merchant_name,
                BotState.MERCHANT_WALLET:           self._handle_merchant_wallet,
                BotState.COURIER_NAME:              self._handle_courier_name,
                BotState.COURIER_VEHICLE:           self._handle_courier_vehicle,
                BotState.COURIER_WALLET:            self._handle_courier_wallet,
                BotState.PIN_ENTRY:                 self._handle_pin_entry,
                BotState.KYC_NAME:                  self._handle_kyc_name,
                BotState.KYC_ID_PHOTO:              self._handle_kyc_id_photo,
                BotState.KYC_SELFIE:                self._handle_kyc_selfie,
                BotState.KYC_ID_TYPE:               self._handle_kyc_id_type,
                BotState.KYC_ID_NUMBER:             self._handle_kyc_id_number,
                BotState.KYC_PASSPORT_NUMBER:       self._handle_kyc_passport_number,
                BotState.BRAND_NAME:                self._handle_brand_name,
                BotState.BRAND_WALLET_SELECT:       self._handle_brand_wallet_select,
                BotState.BRAND_WALLET_NUMBER:       self._handle_brand_wallet_number,
                BotState.BRAND_WALLET_CONFIRM:      self._handle_brand_wallet_confirm,
                BotState.INVENTORY_PHOTO:           self._handle_inventory_photo,
                BotState.INVENTORY_CONFIRM_DETAILS: self._handle_inventory_confirm,
                BotState.INVENTORY_PRICE:           self._handle_inventory_price,
                BotState.INVENTORY_HAS_VARIANTS:    self._handle_inventory_has_variants,
                BotState.INVENTORY_VARIANT_LABEL:   self._handle_inventory_variant_label,
                BotState.INVENTORY_VARIANT_QTY:     self._handle_inventory_variant_qty,
                BotState.INVENTORY_TOTAL_QTY:       self._handle_inventory_total_qty,
                BotState.INVENTORY_NAME_MANUAL:     self._handle_inventory_name_manual,
                BotState.INVENTORY_DESCRIPTION_MANUAL: self._handle_inventory_desc_manual,
                BotState.BROWSE_STORE:              self._handle_browse_store,
                BotState.VIEW_PRODUCT:              self._handle_view_product,
                BotState.SELECT_VARIANT:            self._handle_view_product,  # alias
                BotState.CONFIRM_ORDER:             self._handle_confirm_order,
                BotState.PAYMENT_INSTRUCTION:       self._handle_payment_instruction,
                # ── Dispute Resolution ────────────────────────────────────────
                BotState.DISPUTE_REASON:            self._handle_dispute_reason,
            }
            handler = handlers.get(state, lambda db, p, m, mu, nm: _t("HELP", lang))
            reply   = handler(db, phone, message_text, media_url, num_media)
            # Sync new state to DB
            _sync_session(db, phone, get_user_state(phone))
            return reply

        except Exception as exc:
            logger.error(f"[{pii.mask_user_id(phone)}] {exc}", exc_info=True)
            return _t("ERROR", lang)

    # ── RESUME CONFIRM ─────────────────────────────────────────────────────────

    def _handle_resume_confirm(self, db, phone, message, media_url, num_media):
        lang  = get_user_lang(phone)
        choice = message.lower().strip()
        if choice in YES_WORDS:
            interrupted = get_temp(phone, "interrupted_state")
            if interrupted:
                try:
                    state = BotState(interrupted)
                    set_user_state(phone, state)
                    clear_temp(phone, "interrupted_state")
                    return "▶️ " + _t("RESUME_CONFIRM", lang).split("\n\n")[0] + "\n\n" + \
                           self._describe_state(state, lang)
                except ValueError:
                    pass
            set_user_state(phone, BotState.IDLE)
            return _t("HELP", lang)
        else:
            # NO or anything else
            set_user_state(phone, BotState.INITIAL)
            clear_temp(phone, "interrupted_state")
            return _t("RESUME_NO", lang)

    def _describe_state(self, state: BotState, lang: str) -> str:
        """Return a re-prompt for the given state (after resume)."""
        phase_prompts = {
            BotState.KYC_NAME:                  _t("KYC_NAME", lang),
            BotState.KYC_ID_PHOTO:              _t("KYC_ID_PHOTO", lang),
            BotState.KYC_SELFIE:                _t("KYC_SELFIE", lang),
            BotState.KYC_ID_NUMBER:             _t("KYC_ID_NUMBER", lang),
            BotState.BRAND_NAME:                _t("BRAND_NAME", lang),
            BotState.BRAND_WALLET_SELECT:       _t("BRAND_WALLET_SELECT", lang),
            BotState.INVENTORY_PHOTO:           _t("INVENTORY_PHOTO", lang),
            BotState.INVENTORY_PRICE:           _t("INVENTORY_PRICE", lang),
            BotState.INVENTORY_HAS_VARIANTS:    _t("INVENTORY_HAS_VARIANTS", lang),
            BotState.INVENTORY_VARIANT_LABEL:   _t("INVENTORY_VARIANT_LABEL", lang),
            BotState.INVENTORY_TOTAL_QTY:       _t("INVENTORY_TOTAL_QTY", lang),
            BotState.INVENTORY_NAME_MANUAL:     _t("INVENTORY_NAME_MANUAL", lang),
        }
        return phase_prompts.get(state, _t("HELP", lang))

    # ── INITIAL ───────────────────────────────────────────────────────────────

    def _handle_initial(self, db, phone, message, media_url, num_media):
        lang   = get_user_lang(phone)
        choice = message.lower().strip()
        if choice in ("1", "merchant"):
            set_user_state(phone, BotState.MERCHANT_NAME)
            return _t("MERCHANT_STEP1", lang)
        if choice in ("2", "courier"):
            set_user_state(phone, BotState.COURIER_NAME)
            return _t("COURIER_STEP1", lang)
        if choice in ("3", "help"):
            return _t("HELP", lang)
        if choice == "/onboard_merchant":
            set_user_state(phone, BotState.KYC_NAME)
            return _t("KYC_NAME", lang)
        if choice.startswith("shop "):
            return self._start_browse(db, phone, choice[5:].strip(), lang)
        return _t("WELCOME", lang)

    # ── IDLE ──────────────────────────────────────────────────────────────────

    def _handle_idle(self, db, phone, message, media_url, num_media):
        lang   = get_user_lang(phone)
        choice = message.lower().strip()
        if choice == "/add_product":
            return self._start_add_product(db, phone, lang)
        if choice == "/onboard_merchant":
            set_user_state(phone, BotState.KYC_NAME)
            return _t("KYC_NAME", lang)
        if choice.startswith("shop "):
            return self._start_browse(db, phone, choice[5:].strip(), lang)
        if choice in ("1", "payment"):
            return "📞 *Payment Support*\n\n1. Check connection\n2. Retry transaction\n3. Contact: support@anchorflow.com"
        if choice in ("2", "update"):
            return "📝 To update wallet number reply: *wallet:0771234567*"
        if choice in ("3", "commission"):
            return "💰 *Fees:* 3.5% platform + 15.5% VAT on fee + 2% IMTT (govt levy)"
        if choice in ("4", "other"):
            return "What's your question? Type it and we'll help."
        if choice in ("5", "support"):
            return "📞 +263771234567\n📧 support@anchorflow.com\n⏰ 24/7"
        return _t("HELP", lang)

    # ── LEGACY MERCHANT V1 ────────────────────────────────────────────────────

    def _handle_merchant_name(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant
        lang = get_user_lang(phone)
        existing = db.query(Merchant).filter(Merchant.phone == phone).first()
        if existing:
            set_user_state(phone, BotState.IDLE)
            return f"Welcome back, *{existing.name}*! 👋"
        if not NAME_REGEX.match(message):
            return _t("INVALID_NAME", lang)
        store_temp(phone, "merchant_name", message)
        set_user_state(phone, BotState.MERCHANT_WALLET)
        return _t("MERCHANT_STEP2", lang, name=message)

    def _handle_merchant_wallet(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant
        lang   = get_user_lang(phone)
        wallet = normalise_wallet(message)
        if not wallet:
            return _t("INVALID_WALLET", lang)
        name = get_temp(phone, "merchant_name") or "Merchant"
        db.add(Merchant(phone=phone, name=name, wallet_address=wallet,
                        status="pending_verification",
                        created_at=datetime.now(timezone.utc)))
        db.commit()
        clear_temp(phone, "merchant_name")
        set_user_state(phone, BotState.IDLE)
        return _t("MERCHANT_COMPLETE", lang, name=name)

    # ── COURIER ───────────────────────────────────────────────────────────────

    def _handle_courier_name(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        if not NAME_REGEX.match(message):
            return _t("INVALID_NAME", lang)
        store_temp(phone, "courier_name", message)
        set_user_state(phone, BotState.COURIER_VEHICLE)
        return _t("COURIER_STEP2", lang, name=message)

    def _handle_courier_vehicle(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        vehicle_map = {
            "1": "motorcycle", "motorcycle": "motorcycle",
            "2": "bicycle",    "bicycle":    "bicycle",
            "3": "car",        "car":        "car",
            "4": "on_foot",    "foot":       "on_foot", "on foot": "on_foot",
        }
        vehicle = vehicle_map.get(message.lower().strip())
        if not vehicle:
            name = get_temp(phone, "courier_name") or ""
            return _t("COURIER_STEP2", lang, name=name)
        store_temp(phone, "courier_vehicle", vehicle)
        set_user_state(phone, BotState.COURIER_WALLET)
        return _t("COURIER_STEP3", lang, vehicle=vehicle)

    def _handle_courier_wallet(self, db, phone, message, media_url, num_media):
        lang   = get_user_lang(phone)
        wallet = normalise_wallet(message)
        if not wallet:
            return _t("INVALID_WALLET", lang)
        name    = get_temp(phone, "courier_name")    or "Courier"
        vehicle = get_temp(phone, "courier_vehicle") or "motorcycle"
        logger.info(f"Courier signup: {pii.mask_user_id(phone)}, {vehicle}")
        clear_temp(phone, "courier_name", "courier_vehicle")
        set_user_state(phone, BotState.IDLE)
        return _t("COURIER_COMPLETE", lang, name=name)

    # ── PIN ENTRY ─────────────────────────────────────────────────────────────

    def _handle_pin_entry(self, db, phone, message, media_url, num_media):
        from app.services.dispute_service import check_release_allowed
        from app.services.event_log_service import log_event

        escrow_id = get_temp(phone, "pending_escrow_id")
        if not escrow_id:
            set_user_state(phone, BotState.IDLE)
            return "⚠️ No active delivery found. Contact support."

        pin_input = re.sub(r"\D", "", message)
        if len(pin_input) != 6:
            return "Please enter the *6-digit PIN* exactly."

        # ── Resolve deal from escrow_id ───────────────────────────────────────
        from app.models.database import Deal
        try:
            deal = db.query(Deal).filter(
                Deal.escrow_id == int(escrow_id)
            ).first()
        except (ValueError, TypeError):
            deal = None

        # ── Release guard: check disputes before allowing ANY release ─────────
        if deal:
            try:
                check_release_allowed(db, deal.deal_id, _redis)
            except ValueError as guard_err:
                logger.warning(
                    "[PIN] Release blocked for escrow=%s: %s",
                    escrow_id, guard_err,
                )
                return f"⚠️ Release blocked: {guard_err}"

            # ── Courier hardening: persist to DB (Part 3 — not Redis-only) ──────
            if not deal.courier_phone:
                deal.courier_phone = phone

            # ── Audit log ─────────────────────────────────────────────────────
            try:
                log_event(db, deal.deal_id, "RELEASE_TRIGGERED", {
                    "courier_phone": phone,
                    "escrow_id":     escrow_id,
                })
                db.commit()
            except Exception as log_err:
                logger.error("[PIN] log_event failed: %s", log_err)

        logger.warning(
            "[PIN] entry %s escrow=%s — settlement svc pending",
            pii.mask_user_id(phone), escrow_id,
        )
        set_user_state(phone, BotState.IDLE)
        clear_temp(phone, "pending_escrow_id")
        return "⚠️ PIN verified. Settlement pending final implementation. Contact support."

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 1: KYC-LITE
    # ─────────────────────────────────────────────────────────────────────────

    def _handle_kyc_name(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)

        # AI autofill — reuse AIRouter result if available, else call IntakeAI
        ai = getattr(self, "_ai_context", {}).get("extracted") or {}
        if not ai.get("merchant_name"):
            try:
                ai = IntakeAI.parse_onboarding(message)
            except Exception:
                ai = {"merchant_name": None, "location": None, "wallet": None, "role": None}
        if ai.get("merchant_name"):
            store_temp(phone, "kyc_legal_name", ai["merchant_name"])
            store_temp(phone, "kyc_photo_retries", "0")
            set_user_state(phone, BotState.KYC_ID_PHOTO)
            return _t("KYC_ID_PHOTO", lang)

        # Fallback: direct regex match
        if not NAME_REGEX.match(message):
            return _t("INVALID_NAME", lang)
        store_temp(phone, "kyc_legal_name", message)
        store_temp(phone, "kyc_photo_retries", "0")
        set_user_state(phone, BotState.KYC_ID_PHOTO)
        return _t("KYC_ID_PHOTO", lang)

    def _handle_kyc_id_photo(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        if num_media > 0 and media_url:
            # Store raw URL encrypted (via EncryptedText TypeDecorator on model)
            # — here we just store the Twilio URL temporarily; the DB will encrypt it
            store_temp(phone, "kyc_id_photo_url", media_url)
            clear_temp(phone, "kyc_photo_retries")
            set_user_state(phone, BotState.KYC_SELFIE)
            return _t("KYC_SELFIE", lang)
        if message.upper() == "SKIP":
            store_temp(phone, "kyc_id_photo_url", "skipped")
            set_user_state(phone, BotState.KYC_SELFIE)
            return _t("KYC_SELFIE", lang)
        retries = int(get_temp(phone, "kyc_photo_retries") or "0") + 1
        store_temp(phone, "kyc_photo_retries", str(retries))
        left = max(0, KYC_PHOTO_MAX_RETRIES - retries)
        return _t("KYC_ID_PHOTO_RETRY", lang, retries_left=left)

    def _handle_kyc_selfie(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        if num_media > 0 and media_url:
            store_temp(phone, "kyc_selfie_url", media_url)
            set_user_state(phone, BotState.KYC_ID_TYPE)
            return _t("KYC_ID_TYPE", lang)
        if message.upper() == "SKIP":
            store_temp(phone, "kyc_selfie_url", "skipped")
            set_user_state(phone, BotState.KYC_ID_TYPE)
            return _t("KYC_ID_TYPE", lang)
        return _t("KYC_SELFIE", lang)

    def _handle_kyc_id_type(self, db, phone, message, media_url, num_media):
        lang   = get_user_lang(phone)
        choice = re.sub(r"\s+", "", message).lower()
        if choice == "1":
            store_temp(phone, "kyc_id_type", "national_id")
            set_user_state(phone, BotState.KYC_ID_NUMBER)
            return _t("KYC_ID_NUMBER", lang)
        if choice == "2":
            store_temp(phone, "kyc_id_type", "passport")
            set_user_state(phone, BotState.KYC_PASSPORT_NUMBER)
            return _t("KYC_PASSPORT_NUMBER", lang)
        return _t("KYC_ID_TYPE_INVALID", lang)

    def _handle_kyc_id_number(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant
        lang = get_user_lang(phone)
        try:
            body    = message
            cleaned = re.sub(r"[^A-Za-z0-9]", "", body).upper().strip()
            print(f"KYC_ID_NUMBER received: '{body}' cleaned: '{cleaned}' length: {len(cleaned)}")

            if not ID_NUMBER_REGEX.match(cleaned):
                return _t("KYC_ID_NUMBER_INVALID", lang)

            # Format: DDNNNNNNXDD → DD-NNNNNNXDD
            formatted = f"{cleaned[:2]}-{cleaned[2:8]}{cleaned[8]}{cleaned[9:]}"

            legal_name   = get_temp(phone, "kyc_legal_name")   or ""
            id_photo_url = get_temp(phone, "kyc_id_photo_url") or ""
            selfie_url   = get_temp(phone, "kyc_selfie_url")   or ""

            merchant = db.query(Merchant).filter(Merchant.phone == phone).first()
            if merchant:
                merchant.legal_name   = legal_name
                merchant.id_number    = formatted
                merchant.id_type      = "national_id"
                merchant.id_photo_url = id_photo_url if id_photo_url != "skipped" else None
                merchant.selfie_url   = selfie_url   if selfie_url   != "skipped" else None
                merchant.kyc_status   = "pending"
            else:
                merchant = Merchant(
                    phone=phone,
                    name=legal_name,
                    wallet_address="pending",
                    legal_name=legal_name,
                    id_number=formatted,
                    id_type="national_id",
                    id_photo_url=id_photo_url if id_photo_url != "skipped" else None,
                    selfie_url=selfie_url     if selfie_url   != "skipped" else None,
                    kyc_status="pending",
                    status="kyc_pending",
                    created_at=datetime.now(timezone.utc),
                )
                db.add(merchant)
            try:
                merchant.id_number  = formatted
                merchant.id_type    = "national_id"
                merchant.kyc_status = "pending"
                db.commit()
            except Exception as db_err:
                print(f"[KYC DB write error] {type(db_err).__name__}: {db_err}")
                db.rollback()
                try:
                    merchant.id_number  = formatted
                    merchant.kyc_status = "pending"
                    db.commit()
                except Exception as db_err2:
                    print(f"[KYC DB fallback error] {type(db_err2).__name__}: {db_err2}")
                    db.rollback()
                    raise

            clear_temp(phone, "kyc_legal_name", "kyc_id_photo_url", "kyc_selfie_url",
                       "kyc_photo_retries", "kyc_id_type")
            set_user_state(phone, BotState.BRAND_NAME)
            logger.info(f"KYC (national_id) submitted {pii.mask_user_id(phone)}")
            return _t("BRAND_NAME", lang)

        except Exception as e:
            print(f"KYC_ID_NUMBER exception: {type(e).__name__}: {e}")
            import traceback; traceback.print_exc()
            return _t("ERROR", lang)

    def _handle_kyc_passport_number(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant
        lang    = get_user_lang(phone)
        cleaned = re.sub(r"[^A-Za-z0-9]", "", message).upper()
        print(f"KYC_PASSPORT_NUMBER received: '{message}' cleaned: '{cleaned}'")

        if not PASSPORT_REGEX.match(cleaned):
            return _t("KYC_PASSPORT_INVALID", lang)

        stored    = f"PASSPORT:{cleaned}"
        legal_name   = get_temp(phone, "kyc_legal_name")   or ""
        id_photo_url = get_temp(phone, "kyc_id_photo_url") or ""
        selfie_url   = get_temp(phone, "kyc_selfie_url")   or ""

        merchant = db.query(Merchant).filter(Merchant.phone == phone).first()
        if merchant:
            merchant.legal_name   = legal_name
            merchant.id_number    = stored
            merchant.id_type      = "passport"
            merchant.id_photo_url = id_photo_url if id_photo_url != "skipped" else None
            merchant.selfie_url   = selfie_url   if selfie_url   != "skipped" else None
            merchant.kyc_status   = "pending"
        else:
            merchant = Merchant(
                phone=phone,
                name=legal_name,
                wallet_address="pending",
                legal_name=legal_name,
                id_number=stored,
                id_type="passport",
                id_photo_url=id_photo_url if id_photo_url != "skipped" else None,
                selfie_url=selfie_url     if selfie_url   != "skipped" else None,
                kyc_status="pending",
                status="kyc_pending",
                created_at=datetime.now(timezone.utc),
            )
            db.add(merchant)
        try:
            merchant.id_number  = stored
            merchant.id_type    = "passport"
            merchant.kyc_status = "pending"
            db.commit()
        except Exception as db_err:
            print(f"[KYC DB write error] {type(db_err).__name__}: {db_err}")
            db.rollback()
            try:
                merchant.id_number  = stored
                merchant.kyc_status = "pending"
                db.commit()
            except Exception as db_err2:
                print(f"[KYC DB fallback error] {type(db_err2).__name__}: {db_err2}")
                db.rollback()
                raise

        clear_temp(phone, "kyc_legal_name", "kyc_id_photo_url", "kyc_selfie_url",
                   "kyc_photo_retries", "kyc_id_type")
        set_user_state(phone, BotState.BRAND_NAME)
        logger.info(f"KYC (passport) submitted {pii.mask_user_id(phone)}")
        return _t("BRAND_NAME", lang)

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 2: BRAND LAYER
    # ─────────────────────────────────────────────────────────────────────────

    def _handle_brand_name(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant
        lang = get_user_lang(phone)
        if message.upper() == "SKIP":
            m = db.query(Merchant).filter(Merchant.phone == phone).first()
            brand_name = (m.legal_name if m else None) or "My Store"
        else:
            # AI autofill — extract business name from natural language
            try:
                ai = IntakeAI.parse_onboarding(message)
            except Exception:
                ai = {"merchant_name": None, "location": None, "wallet": None, "role": None}
            if ai.get("merchant_name"):
                brand_name = ai["merchant_name"]
            else:
                brand_name = sanitise(message)[:100]
        store_temp(phone, "brand_name", brand_name)
        set_user_state(phone, BotState.BRAND_WALLET_SELECT)
        return _t("BRAND_WALLET_SELECT", lang)

    def _handle_brand_wallet_select(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        wallet_map = {
            "1": "ecocash", "ecocash": "ecocash",
            "2": "innbucks", "innbucks": "innbucks",
            "3": "omari", "omari": "omari", "o'mari": "omari",
        }
        wt = wallet_map.get(message.lower().strip())
        if not wt:
            return _t("BRAND_WALLET_SELECT", lang)
        store_temp(phone, "brand_wallet_type", wt)
        set_user_state(phone, BotState.BRAND_WALLET_NUMBER)
        print(f"State transition → BRAND_WALLET_NUMBER for {pii.mask_user_id(phone)}, wallet_type='{wt}'")
        return _t("BRAND_WALLET_NUMBER", lang,
                  wallet_type=WALLET_LABELS[wt], example=WALLET_EXAMPLES[wt])

    def _handle_brand_wallet_number(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant
        lang        = get_user_lang(phone)
        wallet_type = get_temp(phone, "brand_wallet_type") or "ecocash"
        label       = WALLET_LABELS[wallet_type]
        example     = WALLET_EXAMPLES[wallet_type]
        print(f"BRAND_WALLET_NUMBER state — received: '{message}', wallet_type: '{wallet_type}'")
        # AI autofill — reuse AIRouter result if available, else call IntakeAI
        ai = getattr(self, "_ai_context", {}).get("extracted") or {}
        if not ai.get("wallet"):
            try:
                ai = IntakeAI.parse_onboarding(message)
            except Exception:
                ai = {"merchant_name": None, "location": None, "wallet": None, "role": None}
        body = message
        if ai.get("wallet"):
            normalised_ai = normalise_wallet_by_type(ai["wallet"], wallet_type)
            if normalised_ai:
                body = normalised_ai
        wallet      = normalise_wallet_by_type(body, wallet_type)
        if not wallet:
            print(f"BRAND_WALLET_NUMBER — validation failed for input: '{message}'")
            return f"Invalid number format. Please enter your {label} number (e.g. {example})"

        store_temp(phone, "pending_wallet", wallet)
        set_user_state(phone, BotState.BRAND_WALLET_CONFIRM)
        return _t("BRAND_WALLET_CONFIRM", lang, number=wallet)

    def _handle_brand_wallet_confirm(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant
        lang   = get_user_lang(phone)
        choice = message.lower().strip()

        if choice in ("yes", "yebo", "hongu", "y"):
            wallet      = get_temp(phone, "pending_wallet")
            wallet_type = get_temp(phone, "brand_wallet_type") or "ecocash"
            brand_name  = get_temp(phone, "brand_name") or "My Store"

            if not wallet:
                # Temp expired — restart wallet selection
                set_user_state(phone, BotState.BRAND_WALLET_SELECT)
                return _t("BRAND_WALLET_SELECT", lang)

            slug       = generate_unique_slug(db, brand_name)
            entry_link = f"{settings.base_url}/m/{slug}"

            merchant = db.query(Merchant).filter(Merchant.phone == phone).first()
            if merchant:
                merchant.name           = brand_name
                merchant.wallet_address = wallet
                merchant.wallet_type    = wallet_type
                merchant.slug           = slug
                merchant.status         = "active"
            else:
                merchant = Merchant(phone=phone, name=brand_name, wallet_address=wallet,
                                    wallet_type=wallet_type, slug=slug, status="active",
                                    created_at=datetime.now(timezone.utc))
                db.add(merchant)
            db.commit()

            clear_temp(phone, "brand_name", "brand_wallet_type", "pending_wallet")
            set_user_state(phone, BotState.IDLE)
            logger.info(f"Brand active {pii.mask_user_id(phone)} slug={slug}")
            return _t("BRAND_COMPLETE", lang, business_name=brand_name, entry_link=entry_link)

        if choice in ("no", "cha", "kwete", "n"):
            clear_temp(phone, "pending_wallet")
            set_user_state(phone, BotState.BRAND_WALLET_SELECT)
            return _t("BRAND_WALLET_SELECT", lang)

        # Unrecognised — re-prompt
        wallet = get_temp(phone, "pending_wallet") or ""
        return _t("BRAND_WALLET_CONFIRM", lang, number=wallet)

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 3: INVENTORY (Photo → Vision → Price → Variants)
    # ─────────────────────────────────────────────────────────────────────────

    def _start_add_product(self, db, phone, lang):
        from app.models.database import Merchant
        if not db.query(Merchant).filter(Merchant.phone == phone).first():
            return _t("NOT_REGISTERED", lang)
        set_user_state(phone, BotState.INVENTORY_PHOTO)
        return _t("INVENTORY_PHOTO", lang)

    def _handle_inventory_photo(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        if num_media == 0 or not media_url:
            return _t("INVENTORY_PHOTO_NEEDED", lang)

        # Attempt AI vision — fall back to manual on ANY failure
        try:
            image_bytes = download_twilio_media(media_url)
            detected    = call_claude_vision(image_bytes)
            name        = str(detected.get("name", ""))[:200].strip() or None
            description = str(detected.get("description", ""))[:500].strip()
            if not name:
                raise ValueError("Empty name from vision API")
        except Exception as exc:
            logger.warning(f"Vision fallback for {pii.mask_user_id(phone)}: {exc}")
            store_temp(phone, "inv_photo_url", media_url)
            set_user_state(phone, BotState.INVENTORY_NAME_MANUAL)
            return _t("INVENTORY_NAME_MANUAL", lang)

        store_temp(phone, "inv_photo_url",   media_url)
        store_temp(phone, "inv_name",        name)
        store_temp(phone, "inv_description", description)
        set_user_state(phone, BotState.INVENTORY_CONFIRM_DETAILS)
        return _t("INVENTORY_CONFIRM_DETAILS", lang, name=name, description=description)

    # Vision fallback handlers ─────────────────────────────────────────────────

    def _handle_inventory_name_manual(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        name = sanitise(message)[:200]
        store_temp(phone, "inv_name", name)
        set_user_state(phone, BotState.INVENTORY_DESCRIPTION_MANUAL)
        return _t("INVENTORY_DESCRIPTION_MANUAL", lang, name=name)

    def _handle_inventory_desc_manual(self, db, phone, message, media_url, num_media):
        lang        = get_user_lang(phone)
        description = sanitise(message)[:500]
        name        = get_temp(phone, "inv_name") or "Product"
        store_temp(phone, "inv_description", description)
        set_user_state(phone, BotState.INVENTORY_PRICE)
        return _t("INVENTORY_PRICE", lang)

    # Confirm + price + variants ───────────────────────────────────────────────

    def _handle_inventory_confirm(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        if message.lower().strip() not in YES_WORDS:
            # AI autofill — extract product name from natural language correction
            try:
                ai = IntakeAI.parse_product(message)
            except Exception:
                ai = {"name": None, "sku": None, "qty": None, "color": None, "size": None, "price": None}
            name = ai.get("name") or message
            store_temp(phone, "inv_name", sanitise(name)[:200])
        set_user_state(phone, BotState.INVENTORY_PRICE)
        return _t("INVENTORY_PRICE", lang)

    def _handle_inventory_price(self, db, phone, message, media_url, num_media):
        lang      = get_user_lang(phone)
        price_str = message.strip().replace("$", "").replace(",", ".")
        if not PRICE_REGEX.match(price_str) or float(price_str) <= 0:
            return _t("INVENTORY_PRICE_INVALID", lang)
        store_temp(phone, "inv_price", price_str)
        set_user_state(phone, BotState.INVENTORY_HAS_VARIANTS)
        return _t("INVENTORY_HAS_VARIANTS", lang)

    def _handle_inventory_has_variants(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        if message.lower().strip() in YES_WORDS:
            store_temp(phone, "inv_variants", json.dumps([]))
            set_user_state(phone, BotState.INVENTORY_VARIANT_LABEL)
            return _t("INVENTORY_VARIANT_LABEL", lang)
        set_user_state(phone, BotState.INVENTORY_TOTAL_QTY)
        return _t("INVENTORY_TOTAL_QTY", lang)

    def _handle_inventory_variant_label(self, db, phone, message, media_url, num_media):
        lang = get_user_lang(phone)
        if message.lower().strip() in DONE_WORDS:
            variants = json.loads(get_temp(phone, "inv_variants") or "[]")
            if not variants:
                return "⚠️ Add at least one variant before finishing."
            return self._finalize_inventory(db, phone, lang, variants=variants)
        label = sanitise(message)[:100]
        store_temp(phone, "inv_current_label", label)
        set_user_state(phone, BotState.INVENTORY_VARIANT_QTY)
        return _t("INVENTORY_VARIANT_QTY", lang, label=label)

    def _handle_inventory_variant_qty(self, db, phone, message, media_url, num_media):
        lang    = get_user_lang(phone)
        qty_str = re.sub(r"\D", "", message)
        if not qty_str:
            return _t("INVENTORY_QTY_INVALID", lang)
        qty      = int(qty_str)
        label    = get_temp(phone, "inv_current_label") or "Variant"
        variants = json.loads(get_temp(phone, "inv_variants") or "[]")
        variants.append({"label": label, "qty": qty})
        store_temp(phone, "inv_variants", json.dumps(variants))
        clear_temp(phone, "inv_current_label")
        set_user_state(phone, BotState.INVENTORY_VARIANT_LABEL)
        return _t("INVENTORY_VARIANT_LABEL", lang)

    def _handle_inventory_total_qty(self, db, phone, message, media_url, num_media):
        lang    = get_user_lang(phone)
        qty_str = re.sub(r"\D", "", message)
        if not qty_str:
            return _t("INVENTORY_QTY_INVALID", lang)
        return self._finalize_inventory(db, phone, lang, total_qty=int(qty_str))

    def _finalize_inventory(self, db, phone, lang, variants=None, total_qty=0):
        from app.models.database import Merchant, MerchantInventory, ProductVariant
        name        = get_temp(phone, "inv_name")        or "Product"
        description = get_temp(phone, "inv_description") or ""
        price_str   = get_temp(phone, "inv_price")       or "0"
        photo_url   = get_temp(phone, "inv_photo_url")   or None
        qty_avail   = sum(v["qty"] for v in variants) if variants else total_qty
        sku         = f"SKU-{uuid.uuid4().hex[:8].upper()}"

        item = MerchantInventory(
            merchant_phone=phone, sku=sku, item_name=name,
            item_description=description, photo_url=photo_url,
            price=float(price_str), quantity_available=qty_avail,
        )
        db.add(item)
        db.flush()

        if variants:
            for v in variants:
                db.add(ProductVariant(inventory_id=item.id,
                                      variant_label=v["label"],
                                      quantity_available=v["qty"]))
        db.commit()

        merchant  = db.query(Merchant).filter(Merchant.phone == phone).first()
        slug      = merchant.slug if merchant else "store"
        buy_link  = f"{settings.base_url}/m/{slug}/{sku}"

        clear_temp(phone, "inv_name", "inv_description", "inv_price",
                   "inv_photo_url", "inv_variants", "inv_current_label")
        set_user_state(phone, BotState.IDLE)
        logger.info(f"Inventory {sku} created for {pii.mask_user_id(phone)}")
        return _t("INVENTORY_LISTED", lang, name=name, price=price_str, buy_link=buy_link)

    # ─────────────────────────────────────────────────────────────────────────
    # BUYER FLOW V1
    # ─────────────────────────────────────────────────────────────────────────

    def _start_browse(self, db, phone, slug, lang):
        from app.models.database import Merchant, MerchantInventory
        from app.services.order_service import get_total_stock

        merchant = db.query(Merchant).filter(Merchant.slug == slug).first()
        if not merchant:
            return _t("STORE_NOT_FOUND", lang)

        products = (db.query(MerchantInventory)
                    .filter(MerchantInventory.merchant_phone == merchant.phone)
                    .all())
        if not products:
            return _t("BROWSE_EMPTY", lang, store_name=merchant.name)

        lines       = []
        product_map = {}
        for i, p in enumerate(products, 1):
            stock = get_total_stock(db, p.id)
            if stock == 0:
                label = "❌ out of stock"
            elif p.quantity_available <= p.reorder_level:
                label = f"⚠️ only {stock} left"
            else:
                label = f"{stock} available"
            lines.append(f"{i}. {p.item_name} — {label}")
            product_map[str(i)] = str(p.id)

        store_temp(phone, "browse_slug",        slug)
        store_temp(phone, "browse_product_map", json.dumps(product_map))
        set_user_state(phone, BotState.BROWSE_STORE)
        return _t("BROWSE_STORE", lang,
                  store_name=merchant.name,
                  product_list="\n".join(lines))

    def _handle_browse_store(self, db, phone, message, media_url, num_media):
        lang        = get_user_lang(phone)
        product_map = json.loads(get_temp(phone, "browse_product_map") or "{}")
        choice      = message.strip()

        if choice in product_map:
            product_id = int(product_map[choice])
            store_temp(phone, "browse_product_id", str(product_id))
            return self._show_product(db, phone, product_id, lang)

        slug = get_temp(phone, "browse_slug") or ""
        if slug:
            return self._start_browse(db, phone, slug, lang)
        set_user_state(phone, BotState.IDLE)
        return _t("HELP", lang)

    def _show_product(self, db, phone, product_id, lang):
        from app.models.database import MerchantInventory
        from app.services.order_service import get_total_stock

        product = db.query(MerchantInventory).filter(MerchantInventory.id == product_id).first()
        if not product:
            return _t("STORE_NOT_FOUND", lang)

        header  = _t("VIEW_PRODUCT_HEADER", lang,
                     name=product.item_name,
                     price=str(product.price),
                     description=product.item_description or "")
        total   = get_total_stock(db, product_id)
        variants = [v for v in (product.variants or []) if v.is_active]

        if variants:
            lines       = []
            variant_map = {}
            for i, v in enumerate(variants, 1):
                stock_lbl = f"{v.quantity_free} in stock" if v.quantity_free > 0 else "out of stock"
                lines.append(f"{i}. {v.variant_label} ({stock_lbl})")
                if v.quantity_free > 0:
                    variant_map[str(i)] = v.id
            store_temp(phone, "browse_variant_map", json.dumps(variant_map))
            set_user_state(phone, BotState.VIEW_PRODUCT)
            return header + _t("VIEW_PRODUCT_VARIANTS", lang, variant_list="\n".join(lines))

        if total > 0:
            store_temp(phone, "browse_variant_map", "{}")
            set_user_state(phone, BotState.VIEW_PRODUCT)
            return header + _t("VIEW_PRODUCT_NO_VARIANTS", lang, qty=total)

        set_user_state(phone, BotState.BROWSE_STORE)
        return header + _t("VIEW_PRODUCT_OOS", lang)

    def _handle_view_product(self, db, phone, message, media_url, num_media):
        from app.services.order_service import get_total_stock
        lang         = get_user_lang(phone)
        choice       = message.lower().strip()
        variant_map  = json.loads(get_temp(phone, "browse_variant_map") or "{}")
        product_id_s = get_temp(phone, "browse_product_id") or ""

        if choice in BACK_WORDS:
            slug = get_temp(phone, "browse_slug") or ""
            return self._start_browse(db, phone, slug, lang) if slug else _t("HELP", lang)

        # No-variant product: BUY command
        if not variant_map and choice in BUY_WORDS:
            store_temp(phone, "browse_selected_variant_id", "")
            set_user_state(phone, BotState.CONFIRM_ORDER)
            return self._build_confirm_msg(db, phone, lang)

        # Variant product: numeric selection
        if choice in variant_map:
            variant_id = variant_map[choice]
            store_temp(phone, "browse_selected_variant_id", variant_id)
            set_user_state(phone, BotState.CONFIRM_ORDER)
            return self._build_confirm_msg(db, phone, lang)

        return _t("VARIANT_INVALID", lang)

    def _build_confirm_msg(self, db, phone, lang):
        from app.models.database import MerchantInventory, ProductVariant
        product_id_s = get_temp(phone, "browse_product_id") or "0"
        variant_id   = get_temp(phone, "browse_selected_variant_id") or ""
        product      = db.query(MerchantInventory).filter(
                           MerchantInventory.id == int(product_id_s)).first()
        if not product:
            return _t("STORE_NOT_FOUND", lang)

        variant_line = ""
        if variant_id:
            v = db.query(ProductVariant).filter(ProductVariant.id == variant_id).first()
            if v:
                variant_line = f"🔖 {v.variant_label}\n"

        return _t("CONFIRM_ORDER", lang,
                  product_name=product.item_name,
                  variant_line=variant_line,
                  price=str(product.price))

    def _handle_confirm_order(self, db, phone, message, media_url, num_media):
        from app.models.database import Merchant, MerchantInventory, ProductVariant
        from app.services.order_service import create_order, get_total_stock
        lang   = get_user_lang(phone)
        choice = message.lower().strip()

        if choice in NO_WORDS or choice in BACK_WORDS:
            set_user_state(phone, BotState.BROWSE_STORE)
            slug = get_temp(phone, "browse_slug") or ""
            return (_t("ORDER_CANCELLED", lang) + "\n\n" +
                    (self._start_browse(db, phone, slug, lang) if slug else _t("HELP", lang)))

        if choice not in YES_WORDS:
            return self._build_confirm_msg(db, phone, lang)

        product_id_s = get_temp(phone, "browse_product_id")       or "0"
        variant_id   = get_temp(phone, "browse_selected_variant_id") or None
        product      = db.query(MerchantInventory).filter(
                           MerchantInventory.id == int(product_id_s)).first()
        if not product:
            set_user_state(phone, BotState.IDLE)
            return _t("STORE_NOT_FOUND", lang)

        # Validate stock at order-confirm time
        if variant_id:
            v = db.query(ProductVariant).filter(ProductVariant.id == variant_id).first()
            if not v or v.quantity_free <= 0:
                set_user_state(phone, BotState.BROWSE_STORE)
                return _t("VIEW_PRODUCT_OOS", lang)
        else:
            if get_total_stock(db, product.id) <= 0:
                set_user_state(phone, BotState.BROWSE_STORE)
                return _t("VIEW_PRODUCT_OOS", lang)

        merchant = db.query(Merchant).filter(Merchant.phone == product.merchant_phone).first()
        if not merchant:
            return _t("ERROR", lang)

        order = create_order(
            db,
            merchant_id  = merchant.id,
            product_id   = product.id,
            amount       = float(product.price),
            buyer_phone  = phone,
            variant_id   = variant_id or None,
        )

        store_temp(phone, "current_order_ref", order.reference_code)
        set_user_state(phone, BotState.PAYMENT_INSTRUCTION)
        return _t("PAYMENT_INSTRUCTION", lang,
                  amount        = str(product.price),
                  wallet_type   = WALLET_LABELS.get(merchant.wallet_type or "ecocash", "Wallet"),
                  wallet_number = merchant.wallet_address,
                  reference_code= order.reference_code,
                  order_id      = order.id[:8].upper())

    def _handle_payment_instruction(self, db, phone, message, media_url, num_media):
        lang   = get_user_lang(phone)
        choice = message.lower().strip()
        if choice in BACK_WORDS or choice in ("done", "ok", "okay"):
            set_user_state(phone, BotState.IDLE)
            return _t("HELP", lang)
        # Re-show payment instructions
        return (get_temp(phone, "current_order_ref") and
                "Reply *DONE* when you've completed the payment, or *BACK* to cancel.") or \
               _t("HELP", lang)

    # ── DISPUTE RESOLUTION ────────────────────────────────────────────────────

    def _handle_dispute_reason(self, db, phone, message, media_url, num_media):
        """
        Step 2 of the dispute flow: user provides the dispute reason.

        Entered via /dispute DEAL_ID (handled in webhook before state machine).
        State machine receives the reason text here and calls open_dispute().
        """
        from app.services.dispute_service import open_dispute

        lang    = get_user_lang(phone)
        deal_id = get_temp(phone, "dispute_deal_id")

        if not deal_id:
            set_user_state(phone, BotState.IDLE)
            return "⚠️ Dispute session expired. Send */dispute DEAL_ID* to try again."

        reason = sanitise(message).strip()
        if len(reason) < 10:
            return "Please describe the issue in more detail (at least 10 characters)."

        # Determine actor role from bot state context (buyer by default)
        actor = get_temp(phone, "dispute_actor") or "buyer"

        try:
            open_dispute(db, deal_id, actor=actor, reason=reason, redis_client=_redis)
            clear_temp(phone, "dispute_deal_id", "dispute_actor")
            set_user_state(phone, BotState.IDLE)
            logger.info(
                "[Dispute] opened | deal=%s actor=%s phone=%s",
                deal_id, actor, pii.mask_user_id(phone),
            )
            return (
                f"🛡️ *Dispute Opened*\n\n"
                f"Deal *{deal_id}* is now under review.\n"
                f"No funds will be released until the dispute is resolved.\n\n"
                f"Our team will contact you shortly."
            )
        except ValueError as err:
            set_user_state(phone, BotState.IDLE)
            clear_temp(phone, "dispute_deal_id", "dispute_actor")
            return f"⚠️ Could not open dispute: {err}"
        except Exception as err:
            logger.error("[Dispute] open_dispute failed: %s", err)
            set_user_state(phone, BotState.IDLE)
            clear_temp(phone, "dispute_deal_id", "dispute_actor")
            return "⚠️ System error opening dispute. Please try again or contact support."


# ─────────────────────────────────────────────────────────────────────────────
# BROWSE VARIANT HELPER (used by store router)
# ─────────────────────────────────────────────────────────────────────────────

def format_variant_browse(item) -> str:
    """
    Return a numbered browse list for a product's active variants.
    Out-of-stock variants are listed but marked — only in-stock ones are selectable.
    """
    if not item.variants:
        return ""
    lines = []
    for i, v in enumerate(item.variants, 1):
        if not v.is_active:
            continue
        stock = f"{v.quantity_free} in stock" if v.quantity_free > 0 else "out of stock"
        lines.append(f"{i}. {v.variant_label} ({stock})")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# OUTBOUND PUSH NOTIFICATION HELPERS
# (proactive messages — not webhook replies)
# ─────────────────────────────────────────────────────────────────────────────

_twilio_sender = TwilioWhatsAppClient()


def notify_payment_received(phone: str, merchant_name: str, amount: str) -> bool:
    return bool(_twilio_sender.send_message(phone,
        f"✅ *Payment Received!*\n\nHi {merchant_name},\n\n"
        f"A customer just paid: *${amount}*\n\nProcessing now.\n\nTofamba"))

def notify_merchant_settled(phone: str, merchant_name: str, amount: str) -> bool:
    return bool(_twilio_sender.send_message(phone,
        f"✅ *Payment Settled!*\n\nHi {merchant_name}, your *${amount}* is in your wallet.\n\nTofamba"))

def notify_merchant_reversed(phone: str, merchant_name: str, amount: str) -> bool:
    return bool(_twilio_sender.send_message(phone,
        f"🔄 *Payment Reversed*\n\nHi {merchant_name}, escrow of *${amount}* reversed.\n\nTofamba"))

def notify_delivery_assigned(phone, courier_name, merchant, amount, distance) -> bool:
    return bool(_twilio_sender.send_message(phone,
        f"📦 *New Delivery!*\n\nHi {courier_name},\n• From: {merchant}\n"
        f"• Distance: {distance} km\n• Earnings: ${amount}\n\nReply *accept* or *decline*."))

def notify_delivery_completed(phone: str, courier_name: str, amount: str) -> bool:
    return bool(_twilio_sender.send_message(phone,
        f"✅ *Delivery Complete!*\n\nGreat work, {courier_name}!\n\nYou earned: *${amount}*"))

def prompt_courier_pin(phone: str, escrow_id: str, order_ref: str) -> bool:
    store_temp(phone, "pending_escrow_id", escrow_id)
    set_user_state(phone, BotState.PIN_ENTRY)
    lang = get_user_lang(phone)
    return bool(_twilio_sender.send_message(phone, _t("PIN_PROMPT", lang, order_ref=order_ref)))


# ─────────────────────────────────────────────────────────────────────────────
# FASTAPI ROUTER
# ─────────────────────────────────────────────────────────────────────────────

router = APIRouter(prefix="/whatsapp-bot", tags=["whatsapp-bot"])
_bot   = TandemWhatsAppBot()


@router.post("/webhook")
async def whatsapp_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Twilio WhatsApp webhook.
    1. Validates Twilio HMAC-SHA1 signature
    2. Deduplicates via MessageSid (handles Twilio retries)
    3. Passes MediaUrl0 for photo messages (KYC + inventory)
    4. Routes to TandemWhatsAppBot state machine
    """
    raw_body = await request.body()
    print(f"Webhook hit — Body: {raw_body}")

    try:
        form_data = await request.form()
        signature = request.headers.get("X-Twilio-Signature", "")
        params    = dict(form_data)

        if os.environ.get("TWILIO_VERIFY_SIG", "true").lower() == "true":
            request_url = os.environ.get("INTERNAL_API_BASE", "https://tandemhivev1final-production.up.railway.app") + "/whatsapp-bot/webhook"
            if not _validator.validate(request_url, params, signature):
                logger.warning("Rejected: invalid Twilio signature")
                raise HTTPException(status_code=403, detail="Forbidden")

        sender_phone = params.get("From", "").replace("whatsapp:", "")
        message_body = (params.get("Body") or "").strip()
        message_cmd  = message_body.lower()
        message_sid  = params.get("MessageSid", "")
        num_media    = int(params.get("NumMedia", "0"))
        media_url    = params.get("MediaUrl0", "") if num_media > 0 else ""

        print(f"Incoming message: '{message_body}' from {sender_phone}")

        if not sender_phone:
            raise HTTPException(status_code=400, detail="Missing From")

        # ── 0. /onboard_merchant — bypass dedup, always hard-reset ───────────
        if message_cmd == "/onboard_merchant":
            print(f"FORCE RESET triggered for {sender_phone}")
            _force_reset_session(sender_phone)
            set_user_state(sender_phone, BotState.KYC_NAME)
            resp = MessagingResponse()
            resp.message("Welcome. Let's get you onboarded.\nWhat is your full name?")
            return FastAPIResponse(content=str(resp), media_type="application/xml")

        # ── 0b. /dispute DEAL_ID — start a dispute flow ───────────────────────
        if message_cmd.startswith("/dispute"):
            parts   = message_body.strip().split(maxsplit=1)
            deal_id = parts[1].strip().upper() if len(parts) > 1 else ""
            resp    = MessagingResponse()
            if not deal_id:
                resp.message(
                    "⚠️ Please include your Deal ID.\n\n"
                    "Example: */dispute DEAL_ID*"
                )
            else:
                store_temp(sender_phone, "dispute_deal_id", deal_id)
                store_temp(sender_phone, "dispute_actor",   "buyer")
                set_user_state(sender_phone, BotState.DISPUTE_REASON)
                resp.message(
                    f"🛡️ *Open Dispute — Deal {deal_id}*\n\n"
                    f"Please describe the issue clearly.\n\n"
                    f"What went wrong?"
                )
            return FastAPIResponse(content=str(resp), media_type="application/xml")

        if _is_duplicate(message_sid):
            logger.info(f"Duplicate {message_sid} — skipped")
            resp = MessagingResponse()
            return FastAPIResponse(content=str(resp), media_type="application/xml")

        reply = _bot.handle_message(
            db, sender_phone, message_body,
            media_url=media_url, num_media=num_media,
        )
        # ── TwiML inline reply — zero outbound API calls, no message credits ──
        twiml = MessagingResponse()
        twiml.message(reply)
        return FastAPIResponse(content=str(twiml), media_type="application/xml")

    except HTTPException:
        raise
    except Exception as e:
        print(f"Webhook error: {e}")
        resp = MessagingResponse()
        resp.message("System error. Please try again.")
        return FastAPIResponse(content=str(resp), media_type="application/xml")


@router.get("/kyc/media/{token}")
async def serve_kyc_media(token: str):
    """
    Signed proxy endpoint for KYC media (ID photos, selfies).
    Tokens are generated by encryption.generate_signed_url() and expire in 1 hour.
    The original Twilio media URL is never exposed to the client.
    """
    original_url = verify_signed_url(token)
    if not original_url:
        raise HTTPException(status_code=403, detail="Invalid or expired link")

    sid   = os.environ["TWILIO_ACCOUNT_SID"]
    token_env = os.environ["TWILIO_AUTH_TOKEN"]
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(original_url, auth=(sid, token_env))
        if resp.status_code != 200:
            raise HTTPException(status_code=resp.status_code, detail="Media unavailable")
        content_type = resp.headers.get("content-type", "image/jpeg")
        return FastAPIResponse(content=resp.content, media_type=content_type)


@router.get("/health")
async def health():
    return {"status": "healthy", "service": "Tofamba WhatsApp Bot", "version": "2.1"}
