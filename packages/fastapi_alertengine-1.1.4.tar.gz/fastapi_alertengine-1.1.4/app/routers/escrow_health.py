# app/routes/dashboards/escrow_health.py - REVIEW

# STRENGTHS:
# ✅ Correctly identifies oldest escrow (stuck funds risk)
# ✅ Proper threshold detection (120 min = critical)
# ✅ Counts escrows nearing expiry

# ISSUES TO FIX:

# 1. MISSING: Reversal job health check
# Current: Only age tracking
# CRITICAL: Need to verify escrow_timeout job is actually running

# ADD THIS:
class ReversalJobHealth(BaseModel):
    last_reversal_timestamp: Optional[datetime]
    minutes_since_last_reversal: float
    job_is_healthy: bool  # False if > 30 min without reversal


# 2. MISSING: Escrow value tracking
# Current: Just counts
# IMPORTANT: Know total $ stuck

class EscrowCounts(BaseModel):
    active_count: int
    active_total_value: float  # ADD THIS
    nearing_expiry: int
    nearing_expiry_value: float  # ADD THIS


# 3. MISSING: Escrow distribution
# Current: Just oldest
# BETTER: Show distribution across hold times

class EscrowDistribution(BaseModel):
    under_30min: int      # ADD THESE
    thirty_to_60min: int
    sixty_to_120min: int
    over_120min: int


# 4. MISSING: Reversal reason breakdown
# Current: Just counts reversals
# BETTER: Know why they're reversing

class ReversalBreakdown(BaseModel):
    timeout_reversal: int        # 2h timer expired
    manual_reversal: int         # Merchant triggered
    fraud_reversal: int          # Security team
    payment_failed_reversal: int # Payment provider error


# 5. CRITICAL: Add correlation with other dashboards
# Current: Standalone
# BETTER: Link high reversals to payment provider issues

# PRODUCTION READY: 70%
# REQUIRED FOR PRODUCTION:
# - Reversal job health check
# - Escrow value tracking
# - Reversal reason breakdown