# app/routers/recovery.py
"""
AnchorFlow Session Recovery Router

Provides two endpoints:

POST /recovery/sweep
    Idempotent sweep of all active bot state keys.  Detects and fixes orphaned
    sessions — states that have been stuck longer than their expected maximum
    duration (e.g. a user stuck in AWAITING_PAYMENT for > 2 hours because the
    Paynow webhook never arrived, or an ORDERING session that was abandoned).

    This endpoint is safe to call repeatedly; it only acts on sessions that are
    provably orphaned.  Call from a cron job every 15 minutes.

GET /recovery/health
    Lightweight liveness check for the recovery subsystem.

Design:
    - Uses SCAN to iterate state keys without blocking the Redis event loop.
    - Reads bot:state_ts:{phone} for age calculation (written by set_user_state).
    - Never deletes sessions — only resets them to a safe fallback state.
    - All phone values in logs are PII-masked.
"""

import json
import logging
import time
from typing import Dict, List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/recovery", tags=["recovery"])

# ─── ORPHAN THRESHOLDS (seconds) ─────────────────────────────────────────────
# If a session has been in one of these states for longer than the threshold,
# it is considered orphaned.

_ORPHAN_THRESHOLDS: Dict[str, int] = {
    "awaiting_payment":     7_200,   # 2 h
    "deal_created":         7_200,   # 2 h
    "ordering":             1_800,   # 30 min
    "delivery_in_progress": 86_400,  # 24 h
    "courier_matching":     3_600,   # 1 h
}

# Safe fallback states for each orphaned state
_FALLBACK: Dict[str, str] = {
    "awaiting_payment":     "idle",
    "deal_created":         "idle",
    "ordering":             "browsing",
    "delivery_in_progress": "idle",
    "courier_matching":     "idle",
}


# ─── REDIS ACCESS ─────────────────────────────────────────────────────────────
# Import _redis lazily to avoid circular imports (whatsapp_bot imports recovery
# indirectly via main.py; recovery must not import whatsapp_bot at module level).

def _get_redis():
    from app.routers.whatsapp_bot import _redis
    return _redis


def _get_pii():
    from app.routers.whatsapp_bot import pii
    return pii


# ─── ENDPOINTS ────────────────────────────────────────────────────────────────

@router.post("/sweep")
async def recovery_sweep():
    """
    Scan all bot:state:* keys and reset provably orphaned sessions.

    Orphan criteria: session has been in an at-risk state for longer than its
    configured threshold (bot:state_ts:{phone} key age check).

    Actions taken per orphan:
        - AWAITING_PAYMENT > 2h  → reset to IDLE
        - DEAL_CREATED > 2h      → reset to IDLE
        - ORDERING > 30min       → reset to BROWSING (order snapshot preserved)
        - DELIVERY_IN_PROGRESS > 24h → reset to IDLE
        - COURIER_MATCHING > 1h  → reset to IDLE

    Returns:
        {
            "scanned":  int,
            "orphaned": int,
            "fixed":    list of {"phone_hash": str, "from": str, "to": str},
        }
    """
    rdb  = _get_redis()
    pii_ = _get_pii()
    now  = time.time()

    scanned  = 0
    fixed    = []

    try:
        for key in rdb.scan_iter(match="bot:state:*", count=200):
            scanned += 1
            key_str = key.decode() if isinstance(key, bytes) else key

            # Extract phone from key: "bot:state:{phone}"
            parts = key_str.split("bot:state:", 1)
            if len(parts) != 2:
                continue
            phone = parts[1]

            # Read current state
            raw_state = rdb.get(key_str)
            if not raw_state:
                continue
            state_val = raw_state.decode() if isinstance(raw_state, bytes) else raw_state

            threshold = _ORPHAN_THRESHOLDS.get(state_val)
            if threshold is None:
                continue   # state not in the at-risk list

            # Read state timestamp
            ts_raw = rdb.get(f"bot:state_ts:{phone}")
            if not ts_raw:
                continue   # no timestamp — can't determine age; skip
            try:
                state_age = now - float(ts_raw.decode() if isinstance(ts_raw, bytes) else ts_raw)
            except (ValueError, TypeError):
                continue

            if state_age < threshold:
                continue   # not yet orphaned

            # It's an orphan — reset to fallback
            fallback = _FALLBACK.get(state_val, "idle")
            from app.core.idempotency import TTL_IDLE_SESSION
            try:
                rdb.setex(f"bot:state:{phone}", TTL_IDLE_SESSION, fallback)
                rdb.setex(f"bot:state_ts:{phone}", TTL_IDLE_SESSION, str(int(now)))
            except Exception as exc:
                logger.error("recovery_sweep: failed to reset %s: %s",
                             pii_.mask_user_id(phone), exc)
                continue

            logger.warning(
                "recovery_sweep: orphan fixed phone=%s from=%s to=%s age_s=%.0f",
                pii_.mask_user_id(phone), state_val, fallback, state_age,
            )
            fixed.append({
                "phone_hash": str(hash(phone) % 100_000),
                "from":       state_val,
                "to":         fallback,
                "age_s":      int(state_age),
            })

    except Exception as exc:
        logger.error("recovery_sweep failed: %s", exc)
        return {
            "scanned":  scanned,
            "orphaned": len(fixed),
            "fixed":    fixed,
            "error":    str(exc),
        }

    return {
        "scanned":  scanned,
        "orphaned": len(fixed),
        "fixed":    fixed,
    }


@router.get("/health")
async def recovery_health():
    """Liveness check: verifies the recovery router and Redis SCAN are reachable."""
    rdb = _get_redis()
    try:
        # Count state keys without loading them all
        count = sum(1 for _ in rdb.scan_iter(match="bot:state:*", count=50))
        return {"status": "ok", "active_sessions_sampled": count}
    except Exception as exc:
        logger.error("recovery_health: %s", exc)
        return {"status": "error", "detail": str(exc)}


@router.post("/stuck-scan")
async def stuck_deal_scan(
    background_tasks: BackgroundTasks,
    merchant_phone: Optional[str] = None,
):
    """
    Scan PostgreSQL for HELD deals that are not progressing normally.

    Detection rules:
        AWAITING_COURIER  — HELD > 10 min, no courier assignment yet
        COURIER_STALLED   — HELD > 45 min
        DELIVERY_DELAYED  — HELD > 2 h

    This endpoint is READ-ONLY — it never mutates state.
    For each flagged deal, an event is emitted to the event bus so registered
    handlers (e.g. merchant notifications) can react asynchronously.

    Args:
        merchant_phone: Optional — filter to a single merchant's deals.
                        When absent, scans all merchants (admin/cron use).

    Returns:
        {
            "scanned": int,
            "flagged": int,
            "deals": [
                {
                    "deal_id":           "7G4K9",
                    "merchant":          "077****567",
                    "merchant_name":     "Tafara Foods",
                    "status":            "held",
                    "flag":              "COURIER_STALLED",
                    "time_in_state_sec": 3120,
                    "held_since":        "2026-03-30T12:14:00Z"
                },
                ...
            ]
        }
    """
    from app.recovery.stuck_detector import run_stuck_scan
    from app.core.event_bus import emit_background
    from app.merchant_portal.auth import _get_db_session

    db: Optional[Session] = None
    try:
        # Build own DB session (not a dependency here because the endpoint
        # needs to work both from cron (no auth) and from the dashboard)
        from app.routers.deals import _SessionLocal
        db = _SessionLocal()

        flagged = run_stuck_scan(db, merchant_phone=merchant_phone)

        # Emit one event per flagged deal — handlers execute in background
        for deal in flagged:
            emit_background(
                background_tasks,
                deal["flag"].lower(),   # e.g. "courier_stalled"
                {
                    "deal_id":          deal["deal_id"],
                    "merchant_phone":   merchant_phone,
                    "time_in_state_sec": deal["time_in_state_sec"],
                    "flag":             deal["flag"],
                },
            )

        return {
            "scanned": _count_held_deals(db, merchant_phone),
            "flagged": len(flagged),
            "deals":   flagged,
        }
    except Exception as exc:
        logger.error("stuck_deal_scan failed: %s", exc)
        return {"scanned": 0, "flagged": 0, "deals": [], "error": str(exc)}
    finally:
        if db is not None:
            try:
                db.close()
            except Exception:
                pass


def _count_held_deals(db: Session, merchant_phone: Optional[str]) -> int:
    """Count HELD deals for the scan summary."""
    try:
        from app.models.database import Deal, DealStatus
        q = db.query(Deal).filter(Deal.status == DealStatus.HELD)
        if merchant_phone:
            q = q.filter(Deal.seller_phone == merchant_phone)
        return q.count()
    except Exception:
        return 0


@router.post("/courier-timeout")
async def courier_timeout_scan():
    """
    Scan for couriers who accepted a job but went dark (no progress).

    Thresholds:
      COURIER_ASSIGNED       > 45 min → reassign
      DELIVERY_IN_PROGRESS   > 3 h    → reassign

    For each timed-out courier:
      - State reset to COURIER_PORTAL
      - Customer state reset to DEAL_CREATED (triggers re-broadcast)
      - Courier fence re-initialised for new acceptance token
      - Both parties notified via WhatsApp

    Returns:
        {"scanned": int, "timed_out": int, "details": [...]}

    Safe to call repeatedly (idempotent within a scan cycle).
    Recommended schedule: every 5 minutes.
    """
    rdb = _get_redis()
    try:
        from app.services.courier_timeout_engine import run_courier_timeout_scan
        result = await run_courier_timeout_scan(rdb)
        return result
    except Exception as exc:
        logger.error("courier_timeout_scan failed: %s", exc)
        return {"error": str(exc), "scanned": 0, "timed_out": 0, "details": []}
