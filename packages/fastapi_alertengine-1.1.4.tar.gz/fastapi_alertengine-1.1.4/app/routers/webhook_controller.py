# app/routers/webhook_controller.py
"""
Webhook Controller — hardened HTTP boundary for the Bot Runtime.

Hardening applied (Phase 1):
  [H3] Twilio retry safety: entire message processing is guarded by
       an asyncio.wait_for() timeout of MAX_PROCESSING_S seconds.
       Twilio retries if it doesn't receive a 200 within 15 s.
       Our limit is 10 s — well inside Twilio's window, with budget for
       network overhead.
  [H5] Payment webhook deal locking: each payment callback acquires
       bot:deal_lock:{ref} via TokenLock before advancing state.
       Prevents race between concurrent Paynow retries and user messages.
  [H6] Observability: every path (dedup hit, rate limit, lock contention,
       success, error) emits a structured event to metrics:events.

Endpoints:
  POST /webhook/whatsapp   — inbound WhatsApp message from Twilio
  POST /webhook/payment    — Paynow payment status callback
"""

import asyncio
import logging
import os
import time
from typing import Any, Optional

from fastapi import APIRouter, BackgroundTasks, Form, Request
from fastapi.responses import Response

from app.bot.engine import BotEngine, _emit
from app.bot.state_manager import RedisStateManager
from app.bot.conversation_log import append_message as conv_append
from app.core.metrics import record_payment_processing_time, record_redis_failure
from app.core.idempotency import log_idempotency_event
from app.core.redis_health import redis_healthy

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhook", tags=["webhook"])

# ── Timing constants ──────────────────────────────────────────────────────────

# Hard ceiling for total message processing time.
# Twilio's webhook timeout is 15 s; we respond in ≤10 s and leave budget
# for network round-trips.
MAX_PROCESSING_S = 10.0

# Payment webhook processing ceiling — longer allowed as it's not
# user-facing latency (no TwiML response expected by Paynow).
MAX_PAYMENT_S    = 20.0


# ── TwiML helpers ─────────────────────────────────────────────────────────────

def _twiml(message: str) -> Response:
    """Wrap a plain-text message in minimal TwiML. Returns 200 OK always."""
    body = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        "<Response>\n"
        f"  <Message>{_xml_escape(message)}</Message>\n"
        "</Response>"
    )
    return Response(content=body, media_type="application/xml")


def _twiml_empty() -> Response:
    """Return a valid TwiML response with no message (for duplicate/silent ignore)."""
    body = '<?xml version="1.0" encoding="UTF-8"?>\n<Response></Response>'
    return Response(content=body, media_type="application/xml")


def _xml_escape(text: str) -> str:
    return (
        text.replace("&",  "&amp;")
            .replace("<",  "&lt;")
            .replace(">",  "&gt;")
            .replace('"',  "&quot;")
            .replace("'",  "&apos;")
    )


# ── Static replies ────────────────────────────────────────────────────────────

_MSG_REDIS_DOWN   = "System temporarily busy. Please try again in a moment."
_MSG_RATE_LIMITED = (
    "⏸️ You're sending messages too quickly. "
    "Please wait a moment and try again."
)
_MSG_LOCKED       = "⏳ Still processing your last message — just a second!"
_MSG_TIMEOUT      = "⏳ That took longer than expected. Please try again."
_MSG_ERROR        = "Something went wrong. Please try again."
_MSG_EMPTY        = "I didn't receive a message. Could you resend?"


# ── Dependency factories ──────────────────────────────────────────────────────

def _get_redis() -> Any:
    """Build a SafeRedis client. Connection pool is managed by redis-py."""
    from app.core.safe_redis import build_safe_redis
    return build_safe_redis(url=os.environ["REDIS_URL"], socket_timeout=1.0)


def _get_db():
    """Return a SQLAlchemy Session or None if the database is unavailable."""
    try:
        from database import get_db
        return next(get_db())
    except Exception as exc:
        logger.warning("webhook_controller: DB unavailable: %s", exc)
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# POST /webhook/whatsapp
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/whatsapp")
async def whatsapp_webhook(
    From:       str = Form(...),
    Body:       str = Form(default=""),
    MessageSid: str = Form(default=""),
) -> Response:
    """
    Receive an inbound WhatsApp message from Twilio, return TwiML reply.

    Processing is hard-bounded at MAX_PROCESSING_S seconds to ensure
    Twilio always receives a response within its 15-second window.

    Form fields (Twilio standard):
      From       — sender number, e.g. "whatsapp:+263771234567"
      Body       — message text
      MessageSid — unique Twilio message ID (used for deduplication)
    """
    t0 = time.perf_counter()

    # Normalise phone — strip "whatsapp:" prefix
    phone = From.replace("whatsapp:", "").strip()
    text  = Body.strip()

    if not phone:
        return _twiml(_MSG_EMPTY)

    rdb = _get_redis()

    # ── 0. Redis health guard ─────────────────────────────────────────────────
    # If the circuit breaker is open (Redis unreachable or consistently slow),
    # refuse the request rather than proceeding with ephemeral-only state.
    # Ephemeral state is per-process; two instances would diverge.
    # Fail clean: user retries in a moment, by which time Redis may recover.
    if not redis_healthy(rdb):
        logger.warning(
            "webhook: Redis unhealthy — returning busy message phone_hash=%s",
            hash(phone) % 100_000,
        )
        _emit(rdb, "webhook_redis_unhealthy", {"phone_hash": str(hash(phone) % 100_000)})
        return _twiml(_MSG_REDIS_DOWN)

    sm  = RedisStateManager(rdb)

    # ── 1. Deduplication ─────────────────────────────────────────────────────
    if MessageSid and sm.is_duplicate(MessageSid):
        logger.info("webhook: duplicate MessageSid=%s", MessageSid)
        _emit(rdb, "webhook_dedup_hit", {
            "phone_hash": str(hash(phone) % 100_000),
            "message_sid": MessageSid,
        })
        return _twiml_empty()

    # ── 2. Rate limiting ──────────────────────────────────────────────────────
    if sm.is_rate_limited(phone):
        logger.warning("webhook: rate_limited phone_hash=%s", hash(phone) % 100_000)
        _emit(rdb, "webhook_rate_limited", {
            "phone_hash": str(hash(phone) % 100_000),
        })
        log_idempotency_event(
            rdb, "rate_limited", f"bot:rate:{phone}",
            {"phone_hash": str(hash(phone) % 100_000)},
        )
        return _twiml(_MSG_RATE_LIMITED)

    # ── 3. Empty body ─────────────────────────────────────────────────────────
    if not text:
        return _twiml(_MSG_EMPTY)

    # ── 3a. Conversation log: incoming user message ───────────────────────────
    current_state = sm.get_state(phone)
    conv_append(rdb, phone, role="user", message=text, state=current_state)

    # ── 4. Token-safe per-phone lock ──────────────────────────────────────────
    lock_token = sm.acquire_lock(phone)
    if lock_token is None:
        logger.debug("webhook: lock contention phone_hash=%s", hash(phone) % 100_000)
        _emit(rdb, "webhook_lock_contention", {
            "phone_hash": str(hash(phone) % 100_000),
        })
        return _twiml(_MSG_LOCKED)

    # ── 5. Process with hard timeout ──────────────────────────────────────────
    db = _get_db()
    response_text = _MSG_ERROR
    try:
        engine = BotEngine(sm=sm, db=db)
        response_text = await asyncio.wait_for(
            engine.process_message(phone=phone, message=text),
            timeout=MAX_PROCESSING_S,
        )
    except asyncio.TimeoutError:
        duration_ms = (time.perf_counter() - t0) * 1000
        logger.error(
            "webhook: processing timeout phone_hash=%s after %.0fms",
            hash(phone) % 100_000, duration_ms,
        )
        _emit(rdb, "webhook_timeout", {
            "phone_hash":  str(hash(phone) % 100_000),
            "duration_ms": f"{duration_ms:.1f}",
        })
        response_text = _MSG_TIMEOUT

    except Exception as exc:
        duration_ms = (time.perf_counter() - t0) * 1000
        logger.exception(
            "webhook: unhandled error phone_hash=%s: %s",
            hash(phone) % 100_000, exc,
        )
        record_redis_failure(rdb, "webhook_processing", str(exc)[:100])
        response_text = _MSG_ERROR

    finally:
        # Always release the lock — token ensures we only release our own lock
        sm.release_lock(phone, lock_token)
        if db is not None:
            try:
                db.close()
            except Exception:
                pass

    duration_ms = (time.perf_counter() - t0) * 1000
    _emit(rdb, "webhook_complete", {
        "phone_hash":  str(hash(phone) % 100_000),
        "duration_ms": f"{duration_ms:.1f}",
    })
    logger.info(
        "webhook: done phone_hash=%s %.1fms",
        hash(phone) % 100_000, duration_ms,
    )

    return _twiml(response_text or "")


# ═══════════════════════════════════════════════════════════════════════════════
# POST /webhook/payment
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/payment")
async def payment_webhook(
    background_tasks: BackgroundTasks,
    reference: str  = Form(default=""),
    status:    str  = Form(default=""),
    hash_:     str  = Form(default="", alias="hash"),
) -> Response:
    """
    Receive a Paynow payment status callback.

    [H5] Wrapped in bot:deal_lock:{reference} to prevent race conditions
    between Paynow retries and concurrent user messages.

    Responds immediately with "OK" — heavy processing runs in a background
    task so Paynow's webhook timeout is never hit.

    Paynow status values that mean confirmed:
      "Sent" | "Paid" | "Success"
    """
    if not reference:
        logger.warning("payment_webhook: missing reference")
        return Response(content="MISSING_REF", status_code=400)

    _CONFIRMED = {"Sent", "Paid", "Success", "sent", "paid", "success"}

    if status not in _CONFIRMED:
        logger.info("payment_webhook: ref=%s status=%s — not confirmed, ignoring", reference, status)
        return Response(content="OK")

    # Acknowledge immediately — processing is backgrounded
    background_tasks.add_task(_process_payment_confirmed, reference, status)
    return Response(content="OK")


async def _process_payment_confirmed(reference: str, status: str) -> None:
    """
    Background task: advance state on payment confirmation.

    Write ordering (invariant):
      1. Acquire deal lock             (Redis — prevents concurrent processing)
      2. Check Redis idempotency guard (Redis — READ only, no SET yet)
      3. Write PostgreSQL              (DB    — durable record FIRST)
      4. Mark Redis as processed       (Redis — ONLY after DB succeeds)
      5. Advance bot state             (Redis)
      6. Send notification             (Twilio)

    Rationale for ordering:
      If we SET Redis before writing DB, a crash between those two steps
      leaves Redis saying "processed" but no DB record — the payment is
      silently lost.  By writing DB first, a crash leaves Redis unmarked,
      so Paynow's retry will re-process — the DB write is idempotent
      (we check escrow.status == HELD on repeat calls).
    """
    t0  = time.perf_counter()
    rdb = _get_redis()
    sm  = RedisStateManager(rdb)
    dedup_key = f"payment_processed:{reference}"

    # ── Step 1: Deal lock ─────────────────────────────────────────────────────
    deal_token = sm.acquire_deal_lock(reference)
    if deal_token is None:
        logger.warning("payment_webhook: deal lock contention ref=%s — Paynow will retry", reference)
        _emit(rdb, "payment_webhook_lock_contention", {"ref": reference})
        return

    try:
        # ── Step 2: Idempotency check (READ only — no SET yet) ────────────────
        try:
            already_processed = bool(rdb.exists(dedup_key))
        except Exception as exc:
            logger.warning("payment_webhook: dedup read failed [%s]: %s", reference, exc)
            already_processed = False

        if already_processed:
            logger.info("payment_webhook: duplicate ref=%s — already processed", reference)
            _emit(rdb, "payment_webhook_dedup", {"ref": reference})
            return

        # Resolve phone
        phone = sm.resolve_deal_ref(reference)
        if not phone:
            logger.warning("payment_webhook: no phone mapping for ref=%s", reference)
            _emit(rdb, "payment_webhook_no_mapping", {"ref": reference})
            return

        # ── Step 3: Write PostgreSQL FIRST ────────────────────────────────────
        db = _get_db()
        db_success = False
        try:
            from services.payment_ledger import record_payment_confirmation
            db_success = record_payment_confirmation(
                db=db,
                reference=reference,
                phone=phone,
            )
        except Exception as exc:
            logger.exception("payment_webhook: DB write failed ref=%s: %s", reference, exc)
        finally:
            if db is not None:
                try:
                    db.close()
                except Exception:
                    pass

        if not db_success:
            # DB write failed — do NOT mark Redis as processed.
            # Paynow will retry and we'll try the DB write again.
            logger.error(
                "payment_webhook: DB write failed for ref=%s — "
                "leaving Redis unmarked so Paynow can retry",
                reference,
            )
            _emit(rdb, "payment_webhook_db_failed", {"ref": reference})
            return

        # ── Step 4: Mark Redis as processed (ONLY after DB success) ──────────
        try:
            rdb.setex(dedup_key, 86_400, status)
        except Exception as exc:
            # Redis write failed but DB is committed — log and continue.
            # If Paynow retries, DB's idempotency guard will short-circuit.
            logger.warning(
                "payment_webhook: Redis mark failed ref=%s (DB committed): %s",
                reference, exc,
            )

        # ── Step 5: Advance bot state ─────────────────────────────────────────
        db2 = _get_db()
        message = None
        try:
            engine  = BotEngine(sm=sm, db=db2)
            message = await asyncio.wait_for(
                engine.process_event("payment_confirmed", {"phone": phone, "ref": reference}),
                timeout=MAX_PAYMENT_S,
            )
        except asyncio.TimeoutError:
            logger.error("payment_webhook: state advance timeout ref=%s", reference)
        except Exception as exc:
            logger.exception("payment_webhook: state advance error ref=%s: %s", reference, exc)
        finally:
            if db2 is not None:
                try:
                    db2.close()
                except Exception:
                    pass

        # ── Step 6: Notify customer ───────────────────────────────────────────
        if message:
            await _send_whatsapp_async(phone, message)

    except Exception as exc:
        logger.exception("payment_webhook: unhandled error ref=%s: %s", reference, exc)
        record_redis_failure(rdb, "payment_webhook_processing", str(exc)[:100])

    finally:
        sm.release_deal_lock(reference, deal_token)

    duration_ms = (time.perf_counter() - t0) * 1000
    record_payment_processing_time(rdb, reference, duration_ms)
    _emit(rdb, "payment_webhook_complete", {
        "ref":         reference,
        "duration_ms": f"{duration_ms:.1f}",
    })
    logger.info("payment_webhook: complete ref=%s %.1fms", reference, duration_ms)


# ═══════════════════════════════════════════════════════════════════════════════
# Twilio outbound helper
# ═══════════════════════════════════════════════════════════════════════════════

async def _send_whatsapp_async(to_phone: str, message: str) -> None:
    """
    Proactively send a WhatsApp notification via Twilio.

    Runs in an asyncio executor so it doesn't block the event loop.
    Fails silently — notification loss is preferable to crashing the bot.
    """
    loop = asyncio.get_event_loop()
    try:
        await loop.run_in_executor(None, _send_whatsapp_sync, to_phone, message)
    except Exception as exc:
        logger.error(
            "_send_whatsapp_async failed [phone_hash=%s]: %s",
            hash(to_phone) % 100_000, exc,
        )


def _send_whatsapp_sync(to_phone: str, message: str) -> None:
    """Synchronous Twilio send — called from executor thread."""
    try:
        from twilio.rest import Client  # type: ignore[import]

        account_sid = os.environ.get("TWILIO_ACCOUNT_SID", "")
        auth_token  = os.environ.get("TWILIO_AUTH_TOKEN", "")
        from_number = os.environ.get("TWILIO_WHATSAPP_NUMBER", "")

        if not all([account_sid, auth_token, from_number]):
            logger.warning("_send_whatsapp_sync: Twilio credentials not configured")
            return

        Client(account_sid, auth_token).messages.create(
            from_=from_number,
            body=message,
            to=f"whatsapp:{to_phone}",
        )
        logger.info(
            "_send_whatsapp_sync: sent to phone_hash=%s",
            hash(to_phone) % 100_000,
        )
    except Exception as exc:
        logger.error(
            "_send_whatsapp_sync failed [phone_hash=%s]: %s",
            hash(to_phone) % 100_000, exc,
        )
