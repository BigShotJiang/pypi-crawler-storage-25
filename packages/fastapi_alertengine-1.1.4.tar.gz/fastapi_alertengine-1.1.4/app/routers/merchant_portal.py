# app/routers/merchant_portal.py
"""
Merchant self-service portal — REST endpoints.

Endpoints:
    GET  /merchant/qr/{merchant_slug}     — Serve QR code PNG for download
    GET  /merchant/{merchant_slug}        — Merchant public profile (JSON)
    GET  /merchant/{merchant_slug}/catalogue — Public catalogue listing (JSON)

These are read-only public endpoints. Write operations happen via the
WhatsApp bot (/onboard_merchant, /add_product commands).

Mounted in main.py under the /merchant prefix.
"""

import base64
import logging

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session

from database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/merchant", tags=["merchant-portal"])


# ─── QR CODE IMAGE ────────────────────────────────────────────────────────────

@router.get("/qr/{merchant_slug}")
def serve_qr_code(merchant_slug: str, db: Session = Depends(get_db)):
    """
    Serve the merchant's QR code as a PNG image.

    The QR encodes the WhatsApp entry link (wa.me deep-link).
    Merchants download this and print it / share it with customers.

    Returns: image/png
    """
    from app.models.database import Merchant
    merchant = db.query(Merchant).filter(
        Merchant.merchant_slug == merchant_slug
    ).first()

    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")

    qr_b64 = getattr(merchant, "qr_code_b64", None)
    if not qr_b64:
        raise HTTPException(status_code=404, detail="QR code not yet generated")

    try:
        png_bytes = base64.b64decode(qr_b64)
    except Exception:
        raise HTTPException(status_code=500, detail="QR code is malformed")

    return Response(
        content=png_bytes,
        media_type="image/png",
        headers={
            "Content-Disposition": f'attachment; filename="{merchant_slug}-qr.png"',
            "Cache-Control": "public, max-age=86400",
        },
    )


# ─── MERCHANT PROFILE ─────────────────────────────────────────────────────────

@router.get("/{merchant_slug}")
def merchant_profile(merchant_slug: str, db: Session = Depends(get_db)):
    """
    Public merchant profile.  Returns name, entry_link, product_count.
    QR and payment_id are NOT exposed here (privacy).
    """
    from app.models.database import Merchant
    merchant = db.query(Merchant).filter(
        Merchant.merchant_slug == merchant_slug
    ).first()

    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")

    return {
        "merchant_id":   getattr(merchant, "merchant_slug", merchant_slug),
        "name":          merchant.name,
        "entry_link":    getattr(merchant, "entry_link", None),
        "status":        merchant.status,
        "product_count": getattr(merchant, "product_count", 0),
        "order_count":   getattr(merchant, "order_count", 0),
    }


# ─── PUBLIC CATALOGUE ─────────────────────────────────────────────────────────

@router.get("/{merchant_slug}/catalogue")
def merchant_catalogue(
    merchant_slug: str,
    page: int = 1,
    page_size: int = 10,
    db: Session = Depends(get_db),
):
    """
    Public product catalogue for a merchant, with pagination.

    Query params:
        page      — 1-indexed page number (default 1)
        page_size — items per page (1–100, default 10)

    Returns:
        {
            "items":       [...],
            "total":       int,
            "page":        int,
            "total_pages": int,
            "has_next":    bool,
        }
    """
    page      = max(1, page)
    page_size = max(1, min(100, page_size))

    from app.models.database import Merchant, MerchantInventory
    merchant = db.query(Merchant).filter(
        Merchant.merchant_slug == merchant_slug
    ).first()

    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")

    total = (
        db.query(MerchantInventory)
        .filter(MerchantInventory.merchant_phone == merchant.phone)
        .count()
    )
    offset = (page - 1) * page_size
    rows = (
        db.query(MerchantInventory)
        .filter(MerchantInventory.merchant_phone == merchant.phone)
        .order_by(MerchantInventory.created_at.desc())
        .offset(offset)
        .limit(page_size)
        .all()
    )
    total_pages = max(1, (total + page_size - 1) // page_size)
    return {
        "items": [
            {
                "sku":         item.sku,
                "name":        item.item_name,
                "description": item.item_description or "",
                "price":       float(item.price),
                "in_stock":    item.quantity_free > 0,
                "status":      item.status,
            }
            for item in rows
        ],
        "total":       total,
        "page":        page,
        "total_pages": total_pages,
        "has_next":    offset + page_size < total,
    }
