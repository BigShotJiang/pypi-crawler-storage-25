# app/recovery/__init__.py
"""
AnchorFlow Recovery Package

Modules:
    stuck_detector.py  — PostgreSQL-only scan for non-progressing deals
"""
