# app/recovery/stuck_detector.py
"""
AnchorFlow — Stuck Deal Detector

Scans PostgreSQL for deals that are not progressing at their expected pace
and returns a structured list of flagged deals.

Design principles
─────────────────
1. PostgreSQL-only: zero Redis dependency.  Survivable in Redis-down mode.
2. Read-only: no state mutations, no log appends, no Redis writes.
3. Idempotent: identical results for identical DB state.
4. Caller decides action: this module only detects and reports.

Detection rules
───────────────
Rule              | Deal status | Time threshold  | Flag
────────────────────────────────────────────────────────────────────────────
AWAITING_COURIER  | HELD        | > 10 min        | Payment confirmed; no
                  |             |                 | courier assignment yet
COURIER_STALLED   | HELD        | > 45 min        | Courier accepted but
                  |             |                 | no delivery progress
DELIVERY_DELAYED  | HELD        | > 2 h           | Delivery severely late

"Time in state" uses the timestamp of the most recent EscrowStateLog entry
whose new_status = 'held'.  If no such log entry exists, falls back to
Escrow.created_at.  All computation done in Python after indexed DB fetch.

Phone masking
─────────────
seller_phone values are masked (first 3 + **** + last 3) before appearing
in any return value.  Raw phones never leave this module.

Integration with event bus
──────────────────────────
run_stuck_scan() returns flagged deal dicts.  The caller (POST /recovery/stuck-scan)
is responsible for emitting events:

    for flag in flagged:
        emit_event(flag["flag"].lower(), flag)

Public API
──────────
    run_stuck_scan(db, merchant_phone=None) → List[dict]
    FlaggedDeal: TypedDict with keys listed below
"""

import logging
from datetime import datetime, UTC, timedelta
from typing import Dict, List, Optional, TypedDict

from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

# ── Thresholds ────────────────────────────────────────────────────────────────

_THRESHOLDS: Dict[str, int] = {
    "AWAITING_COURIER": 10 * 60,    # 10 minutes
    "COURIER_STALLED":  45 * 60,    # 45 minutes
    "DELIVERY_DELAYED": 2 * 60 * 60,  # 2 hours
}


# ── Return type ───────────────────────────────────────────────────────────────

class FlaggedDeal(TypedDict):
    deal_id:          str
    merchant:         str   # masked seller_phone (or seller_name if phone absent)
    merchant_name:    str
    status:           str
    flag:             str
    time_in_state_sec: int
    held_since:       str   # ISO8601 UTC


# ── Helpers ───────────────────────────────────────────────────────────────────

def _mask(raw: Optional[str]) -> str:
    if not raw:
        return "***"
    s = str(raw).strip()
    return f"{s[:3]}****{s[-3:]}" if len(s) > 6 else "*" * len(s)


def _tz(dt: Optional[datetime]) -> Optional[datetime]:
    """Return dt with UTC timezone; None-safe."""
    if dt is None:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=UTC)


def _classify_flag(age_seconds: int) -> Optional[str]:
    """
    Return the most severe applicable flag for a HELD deal, or None if ok.

    Rules are evaluated from most-severe to least-severe so each deal
    gets exactly one flag.
    """
    if age_seconds >= _THRESHOLDS["DELIVERY_DELAYED"]:
        return "DELIVERY_DELAYED"
    if age_seconds >= _THRESHOLDS["COURIER_STALLED"]:
        return "COURIER_STALLED"
    if age_seconds >= _THRESHOLDS["AWAITING_COURIER"]:
        return "AWAITING_COURIER"
    return None


def _find_held_at(logs: list) -> Optional[datetime]:
    """
    Return the created_at of the most recent log entry with new_status='held'.
    Falls back to None if no such entry.
    """
    for log in reversed(logs):   # logs ordered ASC; iterate from newest
        if (log.new_status or "").lower() == "held":
            return log.created_at
    return None


# ── Core scan ─────────────────────────────────────────────────────────────────

def run_stuck_scan(
    db:             Session,
    merchant_phone: Optional[str] = None,
) -> List[FlaggedDeal]:
    """
    Scan all HELD deals and return those that are not progressing normally.

    Args:
        db:             SQLAlchemy session (read-only operations only)
        merchant_phone: Optional filter — when provided, only scans deals
                        belonging to this merchant (used from health.py).
                        When None, scans all merchants (cron/admin use).

    Returns:
        Ordered list of FlaggedDeal dicts, most severe first.
        Empty list if no deals are stuck.

    Performance:
        Queries the indexed `deals` table filtered by status=HELD.
        EscrowStateLog rows are loaded per-deal (N+1 avoided in practice
        because HELD deals are typically < 100 at any time).
        Switch to a JOIN query if p99 > 100ms at scale.
    """
    from app.models.database import Deal, DealStatus, EscrowStateLog

    now = datetime.now(UTC)
    flagged: List[FlaggedDeal] = []

    try:
        q = db.query(Deal).filter(Deal.status == DealStatus.HELD)
        if merchant_phone:
            q = q.filter(Deal.seller_phone == merchant_phone)

        held_deals: List[Deal] = q.all()

        for deal in held_deals:
            # Determine "held since" timestamp:
            # Priority: EscrowStateLog 'held' entry → Escrow.created_at → Deal.created_at
            held_since: Optional[datetime] = None

            if deal.escrow_id:
                logs = (
                    db.query(EscrowStateLog)
                    .filter(EscrowStateLog.escrow_id == deal.escrow_id)
                    .order_by(EscrowStateLog.created_at.asc())
                    .all()
                )
                held_since = _find_held_at(logs)
                if held_since is None:
                    # Fall back to escrow.created_at (= time payment was confirmed)
                    escrow = deal.escrow
                    if escrow:
                        held_since = _tz(escrow.created_at)
            else:
                logs = []

            # Last resort: deal creation time
            if held_since is None:
                held_since = _tz(deal.created_at)

            held_since = _tz(held_since)
            if held_since is None:
                continue

            age_seconds = int((now - held_since).total_seconds())
            if age_seconds < 0:
                age_seconds = 0

            flag = _classify_flag(age_seconds)
            if flag is None:
                continue   # Deal is progressing normally

            flagged.append(FlaggedDeal(
                deal_id=deal.deal_id,
                merchant=_mask(deal.seller_phone),
                merchant_name=deal.seller_name or "Unknown",
                status="held",
                flag=flag,
                time_in_state_sec=age_seconds,
                held_since=held_since.isoformat(),
            ))

        # Sort: most severe first, then longest stuck
        _severity = {"DELIVERY_DELAYED": 0, "COURIER_STALLED": 1, "AWAITING_COURIER": 2}
        flagged.sort(key=lambda d: (_severity.get(d["flag"], 9), -d["time_in_state_sec"]))

        logger.info(
            "stuck_detector: scanned=%d flagged=%d merchant=%s",
            len(held_deals),
            len(flagged),
            _mask(merchant_phone) if merchant_phone else "all",
        )

    except Exception as exc:
        logger.error("stuck_detector: scan failed: %s", exc)

    return flagged


# ── Time formatting helper (shared with notifications) ────────────────────────

def fmt_duration(seconds: int) -> str:
    """
    Format a duration in seconds to a human-readable string.

    Examples:
        45    → "45s"
        134   → "2m 14s"   (< 1h)
        8040  → "2h 14m"   (≥ 1h)
        86400 → "24h 0m"
    """
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        secs = seconds % 60
        return f"{minutes}m {secs}s"
    hours   = minutes // 60
    rem_min = minutes % 60
    return f"{hours}h {rem_min}m"
