# app/middleware/request_metrics.py
"""
Request latency middleware for AnchorFlow.

Measures per-request latency and writes events to a Redis Stream
(key: anchorflow:request_metrics) for p95 aggregation.

Overhead target: <1ms typical (non-blocking Redis XADD).
Failures are swallowed — metrics never affect request flow.
"""

import logging
import time
from typing import Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger(__name__)

_STREAM_KEY = "anchorflow:request_metrics"
_STREAM_MAXLEN = 10_000


def _classify(path: str) -> str:
    return "webhook" if "webhook" in path else "api"


class RequestMetricsMiddleware(BaseHTTPMiddleware):
    """
    Records latency, method, path, status code, and traffic type for
    every request into a capped Redis Stream.

    Args:
        app:   The ASGI application.
        redis: A redis.Redis (or redis.asyncio.Redis) client instance.
               Pass None to disable (e.g. during testing).
    """

    def __init__(self, app, redis=None):
        super().__init__(app)
        self._rdb = redis

    async def dispatch(self, request: Request, call_next) -> Response:
        t0 = time.perf_counter()
        response: Response = await call_next(request)
        latency_ms = (time.perf_counter() - t0) * 1_000

        if self._rdb is not None:
            self._write(
                path=request.url.path,
                method=request.method,
                status_code=response.status_code,
                latency_ms=latency_ms,
            )

        return response

    def _write(
        self,
        path: str,
        method: str,
        status_code: int,
        latency_ms: float,
    ) -> None:
        try:
            self._rdb.xadd(
                _STREAM_KEY,
                {
                    "path":       path,
                    "method":     method,
                    "status":     str(status_code),
                    "latency_ms": f"{latency_ms:.3f}",
                    "type":       _classify(path),
                },
                maxlen=_STREAM_MAXLEN,
                approximate=True,
            )
        except Exception as exc:
            logger.warning("request_metrics: Redis write failed: %s", exc)


# ---------------------------------------------------------------------------
# Aggregation helper (call from a background job or /metrics endpoint)
# ---------------------------------------------------------------------------

def aggregate_metrics(rdb, last_n: int = 500) -> dict:
    """
    Read the most recent *last_n* entries from the request metrics stream
    and return p95 latency broken down by traffic type.

    Args:
        rdb:    A synchronous redis.Redis client.
        last_n: Number of most-recent events to aggregate.

    Returns:
        {
            "webhook_latency": {"p95_ms": float, "count": int},
            "api_latency":     {"p95_ms": float, "count": int},
            "overall_latency": {"p95_ms": float, "count": int},
        }
    """
    try:
        raw = rdb.xrevrange(_STREAM_KEY, count=last_n)
    except Exception as exc:
        logger.warning("aggregate_metrics: Redis read failed: %s", exc)
        return _empty_result()

    webhook_ms: list[float] = []
    api_ms:     list[float] = []

    for _stream_id, fields in raw:
        try:
            ms = float(fields.get("latency_ms", 0))
            traffic_type = fields.get("type", "api")
            if traffic_type == "webhook":
                webhook_ms.append(ms)
            else:
                api_ms.append(ms)
        except (ValueError, TypeError):
            continue

    all_ms = webhook_ms + api_ms

    return {
        "webhook_latency": _bucket(webhook_ms),
        "api_latency":     _bucket(api_ms),
        "overall_latency": _bucket(all_ms),
    }


def _p95(values: list[float]) -> Optional[float]:
    if not values:
        return None
    s = sorted(values)
    idx = max(0, int(len(s) * 0.95) - 1)
    return round(s[idx], 3)


def _bucket(values: list[float]) -> dict:
    return {"p95_ms": _p95(values), "count": len(values)}


def _empty_result() -> dict:
    empty = {"p95_ms": None, "count": 0}
    return {
        "webhook_latency": empty,
        "api_latency":     empty,
        "overall_latency": empty,
    }
