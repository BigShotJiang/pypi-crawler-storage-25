"""
Background job that periodically checks for low-stock inventory items and
sends WhatsApp alerts to affected merchants.

Designed to run every 5 minutes alongside the escrow timeout job.  It
delegates to :func:`~app.services.inventory_service.send_low_stock_alerts`
and returns an execution summary suitable for structured logging.
"""

import logging
from typing import Callable, Dict, Optional

from sqlalchemy.orm import Session

from app.services import inventory_service

logger = logging.getLogger(__name__)


class LowStockJob:
    """
    Scheduled job: detect low-stock items and notify merchants via WhatsApp.

    Each execution is idempotent — items are checked against their
    ``reorder_level`` on every run, and an alert is logged (and optionally
    sent) for each one found.

    Args:
        db_session: SQLAlchemy session used for all DB operations.
        notifier:   Callable ``(phone: str, message: str) -> bool``.
                    When ``None`` alerts are logged but not sent — useful
                    in tests and staging environments.
        merchant_phone: If given, restrict the check to one merchant.
    """

    def __init__(
        self,
        db_session: Session,
        notifier: Optional[Callable[[str, str], bool]] = None,
        merchant_phone: Optional[str] = None,
    ):
        self.db_session    = db_session
        self.notifier      = notifier
        self.merchant_phone = merchant_phone

    def execute(self) -> Dict:
        """
        Run one sweep of the low-stock check.

        Returns:
            A dict with execution statistics::

                {
                    "checked":      5,   # items at or below reorder level
                    "alerts_sent":  3,   # alerts successfully delivered
                }
        """
        result = inventory_service.send_low_stock_alerts(
            self.db_session,
            notifier       = self.notifier,
            merchant_phone = self.merchant_phone,
        )
        logger.info("LowStockJob completed: %s", result)
        return result
