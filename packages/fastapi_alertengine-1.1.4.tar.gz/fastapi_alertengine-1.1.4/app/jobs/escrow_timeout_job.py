"""
Background job that periodically checks for expired escrows and triggers
auto-reversals via the wallet provider.

This job is designed to run every 5 minutes (configurable).  It delegates
the heavy lifting to :class:`~app.services.escrow_timeout_engine.EscrowTimeoutEngine`
and the wallet adapter, then returns an execution summary suitable for
structured logging.

Tofamba's role is strictly that of an observer: this job never moves money
directly – it only instructs wallet providers to reverse their own
transactions when the escrow timeout window has elapsed.
"""

import logging
from typing import Dict

from app.adapters.wallet_adapter import WalletAdapter
from app.services.escrow_timeout_engine import EscrowTimeoutEngine

logger = logging.getLogger(__name__)


class EscrowTimeoutJob:
    """
    Scheduled job: detect expired escrows and initiate wallet reversals.

    Runs every 5 minutes (or whatever interval the scheduler is configured
    for).  Each execution is idempotent – escrows that have already been
    moved out of HELD state are ignored by
    :meth:`~app.services.escrow_timeout_engine.EscrowTimeoutEngine.check_expired_escrows`.
    """

    def __init__(self, timeout_engine: EscrowTimeoutEngine, wallet_adapter: WalletAdapter):
        """
        Args:
            timeout_engine: Engine that queries expired escrows and drives
                state transitions.
            wallet_adapter: Provider adapter used (via the engine) to call the
                actual reversal API.
        """
        self.timeout_engine = timeout_engine
        self.wallet_adapter = wallet_adapter

    def execute(self) -> Dict:
        """
        Run one execution of the escrow-timeout sweep.

        Steps:
          1. Call ``timeout_engine.check_expired_escrows()`` to get the list
             of HELD escrows that have passed their 2-hour window.
          2. For each expired escrow call ``timeout_engine.trigger_reversal()``.
          3. Collect results and errors.
          4. Return an execution summary.

        Returns:
            A dict with execution statistics::

                {
                    "processed": 3,   # escrows where reversal was attempted
                    "succeeded": 2,   # escrows where wallet adapter returned success
                    "failed": 1,      # escrows where reversal returned an error
                    "errors": 0,      # escrows where an exception was raised
                }
        """
        expired_instructions = self.timeout_engine.check_expired_escrows()

        succeeded = 0
        failed = 0
        errors = 0

        for instruction in expired_instructions:
            escrow_id = instruction["escrow_id"]
            reason = instruction.get("reason", "timeout")
            try:
                result = self.timeout_engine.trigger_reversal(escrow_id, reason)
                status = result.get("status", "")
                if status == "reversal_initiated":
                    succeeded += 1
                else:
                    failed += 1
            except Exception as exc:
                errors += 1
                logger.error(
                    "EscrowTimeoutJob: unhandled exception for escrow %s: %s",
                    escrow_id,
                    exc,
                    exc_info=True,
                )

        summary = {
            "processed": len(expired_instructions),
            "succeeded": succeeded,
            "failed": failed,
            "errors": errors,
        }
        logger.info("EscrowTimeoutJob completed: %s", summary)
        return summary
