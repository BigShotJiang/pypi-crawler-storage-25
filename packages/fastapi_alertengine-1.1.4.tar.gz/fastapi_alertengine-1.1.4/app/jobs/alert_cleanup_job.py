# app/jobs/alert_cleanup_job.py
"""
Background job: prune alert_history rows older than 30 days.

Runs periodically (suggested interval: daily or hourly depending on alert
volume).  Old rows are deleted in batches to avoid long-running transactions.
Completed rows can optionally be archived to a cold-storage JSON file before
deletion.

Design constraints:
  - Non-custodial: no financial mutations.
  - Idempotent: safe to run multiple times.
  - Append-only audit: does NOT delete acknowledged rows unless they exceed
    the retention window.
  - RBZ auditability: every cleanup run is logged with counts.
"""

import json
import logging
import os
from datetime import datetime, timedelta, UTC
from typing import Dict

logger = logging.getLogger(__name__)

# Retention window: alerts older than this many days are pruned
_DEFAULT_RETENTION_DAYS = 30

# Max rows to delete per batch (prevents long-running transactions)
_BATCH_SIZE = 500


class AlertCleanupJob:
    """
    Scheduled job: delete alert_history rows older than the retention window.

    Args:
        db_session_factory: A callable that returns a SQLAlchemy ``Session``.
            Typically ``app.db.SessionLocal``.
        retention_days: Number of days to keep alert records.
            Defaults to 30.
        archive_path: If set, rows are serialised to a JSONL file at this
            path before deletion (cold-storage archive).  The path is
            appended to on every run so it accumulates across executions.
    """

    def __init__(
        self,
        db_session_factory,
        retention_days: int = _DEFAULT_RETENTION_DAYS,
        archive_path: str = "",
    ) -> None:
        self._session_factory = db_session_factory
        self._retention_days = retention_days
        self._archive_path = archive_path

    # ── Public API ────────────────────────────────────────────────────────────

    def execute(self) -> Dict:
        """
        Run one cleanup sweep.

        Steps:
          1. Calculate the cutoff timestamp (now − retention_days).
          2. Query rows older than cutoff.
          3. Optionally archive them to a JSONL file.
          4. Delete in batches.
          5. Return an execution summary.

        Returns:
            dict with keys ``deleted``, ``archived``, ``cutoff_date``,
            ``retention_days``.
        """
        cutoff = datetime.now(UTC) - timedelta(days=self._retention_days)
        deleted_total = 0
        archived_total = 0

        db = self._session_factory()
        try:
            from app.models.database import AlertHistory

            while True:
                batch = (
                    db.query(AlertHistory)
                    .filter(AlertHistory.created_at < cutoff)
                    .limit(_BATCH_SIZE)
                    .all()
                )
                if not batch:
                    break

                if self._archive_path:
                    archived_total += self._archive_batch(batch)

                ids = [row.id for row in batch]
                db.query(AlertHistory).filter(AlertHistory.id.in_(ids)).delete(
                    synchronize_session=False
                )
                db.commit()
                deleted_total += len(ids)

        except Exception as exc:
            db.rollback()
            logger.error("AlertCleanupJob failed: %s", exc, exc_info=True)
        finally:
            db.close()

        summary = {
            "deleted":        deleted_total,
            "archived":       archived_total,
            "cutoff_date":    cutoff.isoformat(),
            "retention_days": self._retention_days,
        }
        logger.info("AlertCleanupJob completed: %s", summary)
        return summary

    # ── Internal ──────────────────────────────────────────────────────────────

    def _archive_batch(self, rows) -> int:
        """Append rows as JSONL to the archive file. Returns count written."""
        count = 0
        try:
            parent_dir = os.path.dirname(self._archive_path)
            if parent_dir:
                os.makedirs(parent_dir, exist_ok=True)
            with open(self._archive_path, "a", encoding="utf-8") as fh:
                for row in rows:
                    record = {
                        "id":              row.id,
                        "alert_type":      row.alert_type,
                        "severity":        row.severity.value if hasattr(row.severity, "value") else str(row.severity),
                        "value":           float(row.value) if row.value is not None else None,
                        "threshold":       float(row.threshold) if row.threshold is not None else None,
                        "reason":          row.reason,
                        "metadata":        row.get_metadata(),
                        "created_at":      row.created_at.isoformat() if row.created_at else None,
                        "acknowledged_at": row.acknowledged_at.isoformat() if row.acknowledged_at else None,
                        "acknowledged_by": row.acknowledged_by,
                    }
                    fh.write(json.dumps(record) + "\n")
                    count += 1
        except Exception as exc:
            logger.warning("AlertCleanupJob._archive_batch failed: %s", exc)
        return count
