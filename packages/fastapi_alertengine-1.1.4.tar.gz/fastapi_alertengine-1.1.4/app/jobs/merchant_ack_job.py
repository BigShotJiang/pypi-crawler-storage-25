"""
Merchant Proof-of-Life job.

Runs every 5 minutes alongside ``EscrowTimeoutJob``.  Finds deals in
CREATED state where ``merchant_acknowledged`` is still ``False`` and
``created_at + 15 min`` has elapsed, then:

  1. Sends the merchant a WhatsApp alert via ``TwilioAdapter``.
  2. Logs an ``EscrowStateLog`` audit row (escrow_id=NULL) so the event
     is visible in the admin dashboard.

The buyer can separately call ``POST /deals/{id}/fast-track-cancel`` to
cancel a deal that remains unacknowledged — this job handles the *alert*
side only.
"""

import json
import logging
from datetime import datetime, UTC
from typing import Dict, Optional

from sqlalchemy.orm import Session

from app.models.database import Deal, DealStatus, EscrowStateLog
from app.services.deal_service import (
    _MERCHANT_ACK_WINDOW_MINUTES,
    is_merchant_ack_overdue,
)

logger = logging.getLogger(__name__)

_ALERT_MESSAGE_TEMPLATE = (
    "⚠️ AnchorFlow Alert\n\n"
    "You have an unacknowledged deal *{deal_id}* from *{seller_name}*.\n"
    "A buyer is waiting.\n\n"
    "If you do not respond within *{window} minutes* of the deal creation, "
    "the buyer may cancel automatically.\n\n"
    "Reply with the deal ID to acknowledge:\n"
    "  ACK {deal_id}"
)


class MerchantAckJob:
    """
    Scheduled job: alert merchants who have not acknowledged pending deals.

    Args:
        db_session:      SQLAlchemy session.
        twilio_adapter:  Adapter used to send WhatsApp alerts (injectable for
                         tests — use ``MockTwilioAdapter``).
    """

    def __init__(self, db_session: Session, twilio_adapter):
        self.db_session    = db_session
        self.twilio_adapter = twilio_adapter

    def execute(self) -> Dict:
        """
        Sweep for overdue unacknowledged deals and alert their merchants.

        Returns:
            {
                "checked":      int,  # deals found to be overdue
                "alerts_sent":  int,  # merchants successfully notified
                "errors":       int,  # notification failures
            }
        """
        # Find CREATED deals past the 15-min acknowledgement window
        overdue = (
            self.db_session.query(Deal)
            .filter(
                Deal.status               == DealStatus.CREATED,
                Deal.merchant_acknowledged == False,  # noqa: E712
            )
            .all()
        )

        # Filter in Python — timedelta comparison easier here than SQL
        overdue = [d for d in overdue if is_merchant_ack_overdue(d)]

        alerts_sent = 0
        errors      = 0

        for deal in overdue:
            try:
                message = _ALERT_MESSAGE_TEMPLATE.format(
                    deal_id     = deal.deal_id,
                    seller_name = deal.seller_name,
                    window      = _MERCHANT_ACK_WINDOW_MINUTES,
                )
                sent = self.twilio_adapter.send_message(deal.wallet_phone, message)

                # Audit log (escrow_id=NULL — no escrow exists yet for CREATED deals)
                self.db_session.add(EscrowStateLog(
                    escrow_id       = None,
                    previous_status = DealStatus.CREATED.value,
                    new_status      = DealStatus.CREATED.value,  # status unchanged
                    triggered_by    = "merchant_proof_of_life_alert",
                    metadata_json   = json.dumps({
                        "deal_id":         deal.deal_id,
                        "merchant_phone":  deal.wallet_phone,
                        "alert_sent":      sent,
                        "ack_window_min":  _MERCHANT_ACK_WINDOW_MINUTES,
                    }),
                ))
                self.db_session.commit()

                if sent:
                    alerts_sent += 1
                    logger.info(
                        "Proof-of-Life alert sent for deal %s → merchant %s",
                        deal.deal_id, deal.wallet_phone,
                    )
                else:
                    errors += 1
                    logger.warning(
                        "Proof-of-Life alert FAILED for deal %s → merchant %s",
                        deal.deal_id, deal.wallet_phone,
                    )

            except Exception as exc:
                errors += 1
                logger.error(
                    "MerchantAckJob: unhandled error for deal %s: %s",
                    deal.deal_id, exc, exc_info=True,
                )

        summary = {
            "checked":     len(overdue),
            "alerts_sent": alerts_sent,
            "errors":      errors,
        }
        logger.info("MerchantAckJob completed: %s", summary)
        return summary
