"""
Application configuration for Tofamba.

All values are loaded from environment variables with production-safe
defaults. This module is the single source of truth for runtime settings.

Usage::

    from app.config import settings

    adapter = PaynowWalletAdapter(
        integration_id=settings.paynow.integration_id,
        integration_key=settings.paynow.integration_key,
        merchant_email=settings.paynow.merchant_email,
    )

Or create a fresh instance (useful in tests to avoid module-level state)::

    from app.config import load_settings
    settings = load_settings()

Required environment variables for production
--------------------------------------------
PAYNOW_INTEGRATION_ID      Paynow merchant integration ID
PAYNOW_INTEGRATION_KEY     Paynow merchant integration key (hex)
PAYNOW_MERCHANT_EMAIL      Paynow-registered merchant email
DATABASE_URL               SQLAlchemy database URL

Optional environment variables (defaults shown)
-----------------------------------------------
PAYNOW_BASE_URL            https://www.paynow.co.zw
PAYNOW_TIMEOUT_SECONDS     30
PAYNOW_MAX_RETRIES         3
ESCROW_TIMEOUT_HOURS       2
TIMEOUT_JOB_INTERVAL_MINUTES  5
TANDEM_BASE_URL            https://anchorflow.com/tofamba
"""

import os
from dataclasses import dataclass, field


@dataclass
class PaynowSettings:
    """Paynow Zimbabwe API credentials and HTTP tuning parameters."""

    integration_id: str = ""
    integration_key: str = ""
    merchant_email: str = ""
    base_url: str = "https://www.paynow.co.zw"
    timeout_seconds: int = 30
    max_retries: int = 3


@dataclass
class TwilioSettings:
    """Twilio WhatsApp credentials."""

    account_sid: str = ""
    auth_token: str = ""
    whatsapp_number: str = ""   # E.164, e.g. +14155238886
    redis_url: str = "redis://localhost:6379"


@dataclass
class Settings:
    """Top-level application settings."""

    database_url: str = "sqlite:///./tofamba.db"
    paynow: PaynowSettings = field(default_factory=PaynowSettings)
    twilio: TwilioSettings = field(default_factory=TwilioSettings)
    escrow_timeout_hours: int = 2
    timeout_job_interval_minutes: int = 5
    base_url: str = "https://anchorflow.com/tofamba"   # Public-facing URL for deal links
    anthropic_api_key: str = ""           # Claude API key for product image parsing


def load_settings() -> Settings:
    """Build a Settings instance from environment variables."""
    paynow = PaynowSettings(
        integration_id=os.getenv("PAYNOW_INTEGRATION_ID", ""),
        integration_key=os.getenv("PAYNOW_INTEGRATION_KEY", ""),
        merchant_email=os.getenv("PAYNOW_MERCHANT_EMAIL", ""),
        base_url=os.getenv("PAYNOW_BASE_URL", "https://www.paynow.co.zw"),
        timeout_seconds=int(os.getenv("PAYNOW_TIMEOUT_SECONDS", "30")),
        max_retries=int(os.getenv("PAYNOW_MAX_RETRIES", "3")),
    )
    twilio = TwilioSettings(
        account_sid=os.getenv("TWILIO_ACCOUNT_SID", ""),
        auth_token=os.getenv("TWILIO_AUTH_TOKEN", ""),
        whatsapp_number=os.getenv("TWILIO_WHATSAPP_NUMBER", ""),
        redis_url=os.getenv("REDIS_URL", "redis://localhost:6379"),
    )
    return Settings(
        database_url=os.getenv("DATABASE_URL", "sqlite:///./tofamba.db"),
        paynow=paynow,
        twilio=twilio,
        escrow_timeout_hours=int(os.getenv("ESCROW_TIMEOUT_HOURS", "2")),
        timeout_job_interval_minutes=int(
            os.getenv("TIMEOUT_JOB_INTERVAL_MINUTES", "5")
        ),
        base_url=os.getenv("TANDEM_BASE_URL", "https://anchorflow.com/tofamba"),
        anthropic_api_key=os.getenv("ANTHROPIC_API_KEY", ""),
    )


# Module-level singleton — import this for normal application use
settings = load_settings()
