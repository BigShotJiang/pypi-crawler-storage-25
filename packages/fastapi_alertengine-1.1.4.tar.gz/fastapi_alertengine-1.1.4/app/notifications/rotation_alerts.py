# app/notifications/rotation_alerts.py

import logging
import os
from typing import Optional
from slack_sdk import WebClient
import smtplib
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)


class RotationAlertManager:
    """
    Send alerts for key rotation events.
    """
    
    def __init__(self):
        self.slack_client = WebClient(token=os.getenv("SLACK_BOT_TOKEN"))
        self.smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.alert_email = os.getenv("ALERT_EMAIL_FROM")
        self.ops_channel = os.getenv("SLACK_OPS_CHANNEL", "#ops-alerts")
    
    def alert_rotation_success(self, rotation_id: str, rotated_by: str):
        """Alert on successful key rotation."""
        
        message = f"✅ Key Rotation Successful\n\n" \
                 f"Rotation ID: {rotation_id}\n" \
                 f"Rotated by: {rotated_by}\n" \
                 f"Next rotation: 90 days from now"
        
        self._send_slack_message(message, channel=self.ops_channel)
    
    def alert_rotation_failure(self, rotation_id: str, error: str):
        """Alert on key rotation failure."""
        
        message = f"🚨 Key Rotation Failed\n\n" \
                 f"Rotation ID: {rotation_id}\n" \
                 f"Error: {error}\n" \
                 f"Action: INVESTIGATE IMMEDIATELY"
        
        self._send_slack_message(message, channel=self.ops_channel)
        self._send_email_alert(
            subject=f"KEY ROTATION FAILED: {rotation_id}",
            body=message
        )
    
    def alert_reencryption_progress(self, rotation_id: str, progress_percent: float):
        """Alert on re-encryption progress milestones."""
        
        milestones = [25, 50, 75, 100]
        
        if int(progress_percent) in milestones:
            message = f"📊 Re-encryption Progress: {progress_percent}%\n" \
                     f"Rotation ID: {rotation_id}"
            
            self._send_slack_message(message, channel=self.ops_channel)
    
    def alert_vault_error(self, error: str):
        """Alert on Vault connectivity issues."""
        
        message = f"⚠️ Vault Error\n\n" \
                 f"Error: {error}\n" \
                 f"Action: Check Vault status and network connectivity"
        
        self._send_slack_message(message, channel=self.ops_channel)
        self._send_email_alert(
            subject="VAULT CONNECTIVITY ERROR",
            body=message
        )
    
    def _send_slack_message(self, message: str, channel: str):
        """Send Slack message."""
        
        try:
            self.slack_client.chat_postMessage(
                channel=channel,
                text=message,
            )
        except Exception as e:
            logger.error(f"Failed to send Slack alert: {e}")
    
    def _send_email_alert(self, subject: str, body: str):
        """Send email alert."""
        
        try:
            msg = MIMEText(body)
            msg["Subject"] = subject
            msg["From"] = self.alert_email
            msg["To"] = os.getenv("ALERT_EMAIL_TO", "ops@tofamba.local")
            
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(
                    os.getenv("SMTP_USERNAME"),
                    os.getenv("SMTP_PASSWORD")
                )
                server.send_message(msg)
        
        except Exception as e:
            logger.error(f"Failed to send email alert: {e}")


# Usage in KeyRotationManager

class KeyRotationManager:
    """..."""
    
    def __init__(self, db_session, vault_client, **kwargs):
        """..."""
        self.alerts = RotationAlertManager()
    
    def rotate_key(self, rotated_by: str, reason: str = "scheduled"):
        """..."""
        try:
            # ... rotation logic ...
            self.alerts.alert_rotation_success(rotation_id, rotated_by)
        except Exception as e:
            self.alerts.alert_rotation_failure(rotation_id, str(e))
            raise