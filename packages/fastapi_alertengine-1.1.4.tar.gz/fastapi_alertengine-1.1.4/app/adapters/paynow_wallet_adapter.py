"""
Paynow Zimbabwe wallet adapter for Tofamba.

Implements WalletAdapter.reverse_transaction() by calling Paynow's
Send Money API to push funds back to the payer's mobile wallet.

Tofamba's role is strictly that of an observer: it never holds funds,
it only instructs Paynow to reverse a previously observed transaction.

Authentication
--------------
Paynow authenticates requests via an uppercase MD5 hash of all field
values (concatenated in dict order) followed by the integration key.

Idempotency
-----------
The original ``external_transaction_id`` is embedded in the Paynow
reference field (``REVERSAL-{tx_id}``), so repeat calls for the same
escrow produce the same reference, preventing accidental double-refunds.

Retries
-------
HTTP 5xx responses and network-level errors are retried up to
``max_retries`` times with exponential back-off (2^0 s, 2^1 s, ...).
HTTP 4xx responses are returned immediately as a soft failure so that
mis-configured requests do not spam Paynow.

Paynow API reference: https://developers.paynow.co.zw/docs/
"""

import hashlib
import logging
import time
from datetime import datetime, timezone
from typing import Dict, Optional
from urllib.parse import parse_qs, urlencode

import httpx

from app.adapters.wallet_adapter import WalletAdapter

logger = logging.getLogger(__name__)

_RETRY_BACKOFF_BASE = 2.0  # seconds: first wait=1s, second=2s, third=4s, ...


class PaynowError(Exception):
    """Raised when Paynow returns an unrecoverable error after all retries."""


class PaynowWalletAdapter(WalletAdapter):
    """
    Concrete WalletAdapter for Paynow Zimbabwe.

    Calls Paynow's Send Money API to return funds to the payer's mobile
    wallet when an escrow times out or a dispute is resolved in the
    payer's favour.
    """

    _SEND_MONEY_PATH    = "/interface/sendmoney"
    _QUERY_STATUS_PATH  = "/interface/remotetransaction"

    def __init__(
        self,
        integration_id: str,
        integration_key: str,
        merchant_email: str,
        *,
        base_url: str = "https://www.paynow.co.zw",
        timeout_seconds: int = 30,
        max_retries: int = 3,
    ):
        """
        Args:
            integration_id:   Paynow integration ID (from merchant dashboard).
            integration_key:  Paynow integration key (hex string).
            merchant_email:   Merchant's Paynow-registered email address.
            base_url:         Override the Paynow base URL (useful for sandbox
                              testing or staging environments).
            timeout_seconds:  HTTP timeout per attempt in seconds.
            max_retries:      Maximum number of attempts before raising
                              ``PaynowError``.
        """
        self.integration_id = str(integration_id)
        self.integration_key = integration_key
        self.merchant_email = merchant_email
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries

    # ------------------------------------------------------------------
    # WalletAdapter interface
    # ------------------------------------------------------------------

    def reverse_transaction(self, instruction: Dict) -> Dict:
        """
        Instruct Paynow to return escrow funds to the payer's mobile wallet.

        Builds a Send Money request authenticated with the Paynow hash,
        POSTs it with retry logic, and returns a standardised response.

        Args:
            instruction: Must contain:
                - ``external_transaction_id`` (str): Original Paynow reference.
                - ``payer_wallet_id`` (str): Zimbabwean phone number to refund.
                - ``amount`` (float|Decimal): Value to return, in USD.
                - ``reason`` (str, optional): Logged only; not sent to Paynow.

        Returns:
            {
                "success":    bool,
                "reversal_id": str,   # Paynow poll URL or generated reference
                "status":     "confirmed" | "pending" | "failed",
                "timestamp":  str,    # ISO-8601 UTC
            }

        Raises:
            PaynowError: When all retry attempts are exhausted (network errors
                         or repeated 5xx responses).
        """
        tx_id = instruction["external_transaction_id"]
        amount = float(instruction["amount"])
        reason = instruction.get("reason", "escrow_timeout")
        phone = self._normalise_phone(str(instruction["payer_wallet_id"]))

        logger.info(
            "Paynow reversal | ref=%s phone=%s amount=%.2f reason=%s",
            tx_id,
            phone,
            amount,
            reason,
        )

        # Build the Send Money request fields
        fields: Dict[str, str] = {
            "id":        self.integration_id,
            "reference": f"REVERSAL-{tx_id}",
            "amount":    f"{amount:.2f}",
            "authemail": self.merchant_email,
            "phone":     phone,
            "method":    "ecocash",
        }
        fields["hash"] = self._compute_hash(fields)

        url = self.base_url + self._SEND_MONEY_PATH
        raw = self._post_with_retry(url, fields)
        return self._parse_response(raw, tx_id)

    def query_transaction_status(self, external_transaction_id: str) -> Dict:
        """
        Query Paynow for the live status of a specific transaction.

        Called by ``DealService.poll_provider_status()`` to verify that an
        incoming ``payment-detected`` webhook actually corresponds to a settled
        payment before transitioning the Deal to HELD.

        Paynow's ``remotetransaction`` endpoint accepts a reference and returns
        the current status.  We treat ``Sent`` / ``Success`` as confirmed;
        ``Ok`` as still-pending; anything else as failed.

        Returns:
            {
                "success":    bool,    # query itself succeeded
                "confirmed":  bool,    # payment actually settled
                "status_raw": str,     # Paynow's raw status string
                "amount":     float | None,
                "timestamp":  str,     # ISO-8601 UTC
            }
        """
        now = datetime.now(timezone.utc).isoformat()
        fields: Dict[str, str] = {
            "id":        self.integration_id,
            "reference": external_transaction_id,
            "authemail": self.merchant_email,
        }
        fields["hash"] = self._compute_hash(fields)

        url = self.base_url + self._QUERY_STATUS_PATH
        try:
            raw = self._post_with_retry(url, fields)
        except Exception as exc:
            logger.error(
                "Paynow status query failed for ref=%s: %s",
                external_transaction_id, exc,
            )
            return {
                "success":    False,
                "confirmed":  False,
                "status_raw": "network_error",
                "amount":     None,
                "timestamp":  now,
            }

        params = {k: v[0] for k, v in __import__("urllib.parse", fromlist=["parse_qs"]).parse_qs(raw).items()}
        status_raw = params.get("status", "").lower()
        confirmed = status_raw in ("sent", "success")

        amount_raw = params.get("amount")
        amount = float(amount_raw) if amount_raw else None

        logger.info(
            "Paynow status query | ref=%s status=%s confirmed=%s",
            external_transaction_id, status_raw, confirmed,
        )
        return {
            "success":    True,
            "confirmed":  confirmed,
            "status_raw": status_raw,
            "amount":     amount,
            "timestamp":  now,
        }

    # ------------------------------------------------------------------
    # Hash computation
    # ------------------------------------------------------------------

    def _compute_hash(self, fields: Dict) -> str:
        """
        Compute the Paynow request hash.

        Hash = uppercase MD5(all field values concatenated + integration_key).
        The ``hash`` field itself must NOT be present in ``fields`` when
        calling this method.
        """
        payload = "".join(str(v) for v in fields.values()) + self.integration_key
        return hashlib.md5(payload.encode("utf-8")).hexdigest().upper()

    # ------------------------------------------------------------------
    # HTTP transport with retry
    # ------------------------------------------------------------------

    def _post_with_retry(self, url: str, fields: Dict) -> str:
        """
        POST url-encoded fields to a Paynow endpoint.

        Retries on HTTP 5xx and network errors with exponential back-off.
        Returns the raw response text on any non-5xx response.

        Raises:
            PaynowError: After ``max_retries`` failed attempts.
        """
        last_error: Optional[Exception] = None

        for attempt in range(1, self.max_retries + 1):
            try:
                with httpx.Client(timeout=self.timeout_seconds) as client:
                    resp = client.post(
                        url,
                        content=urlencode(fields).encode("utf-8"),
                        headers={"Content-Type": "application/x-www-form-urlencoded"},
                    )

                # 2xx / 3xx / 4xx — don't retry, return as-is
                if resp.status_code < 500:
                    return resp.text

                # 5xx — log and retry
                last_error = PaynowError(f"Paynow HTTP {resp.status_code}")
                logger.warning(
                    "Paynow server error %s (attempt %d/%d)",
                    resp.status_code,
                    attempt,
                    self.max_retries,
                )

            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                last_error = exc
                logger.warning(
                    "Paynow network error (attempt %d/%d): %s",
                    attempt,
                    self.max_retries,
                    exc,
                )

            if attempt < self.max_retries:
                self._sleep(_RETRY_BACKOFF_BASE ** (attempt - 1))

        raise PaynowError(
            f"Paynow unreachable after {self.max_retries} attempt(s): {last_error}"
        )

    def _sleep(self, seconds: float) -> None:
        """Pause between retries. Extracted so tests can suppress the delay."""
        time.sleep(seconds)

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------

    def _parse_response(self, raw: str, original_tx_id: str) -> Dict:
        """
        Parse a URL-encoded Paynow Send Money response.

        Paynow returns responses as url-encoded key=value pairs, e.g.::

            status=Ok&pollurl=https%3A%2F%2F...&hash=ABCDEF

        Status semantics:
            - ``Ok``      → payment submitted, awaiting mobile confirmation
            - ``Sent``    → payment confirmed by mobile provider
            - ``Success`` → alias for Sent
            - anything else → error / rejection
        """
        params = {k: v[0] for k, v in parse_qs(raw).items()}
        status_raw = params.get("status", "").lower()
        now = datetime.now(timezone.utc).isoformat()

        if status_raw in ("ok", "sent", "success"):
            reversal_id = params.get(
                "pollurl",
                params.get("id", f"REV-{original_tx_id}"),
            )
            # "Ok" means the request was accepted but not yet confirmed by the
            # mobile provider; "Sent"/"Success" means confirmed.
            paynow_status = "confirmed" if status_raw in ("sent", "success") else "pending"
            logger.info(
                "Paynow reversal accepted | ref=%s status=%s poll=%s",
                original_tx_id,
                paynow_status,
                reversal_id,
            )
            return {
                "success":    True,
                "reversal_id": reversal_id,
                "status":     paynow_status,
                "timestamp":  now,
            }

        error = params.get("error", params.get("message", status_raw or "unknown"))
        logger.error(
            "Paynow reversal rejected | ref=%s status=%s error=%s",
            original_tx_id,
            status_raw,
            error,
        )
        return {
            "success":    False,
            "reversal_id": "",
            "status":     "failed",
            "timestamp":  now,
        }

    # ------------------------------------------------------------------
    # Phone normalisation
    # ------------------------------------------------------------------

    @staticmethod
    def _normalise_phone(phone: str) -> str:
        """
        Normalise a Zimbabwean number to local 10-digit format (07xxxxxxxx).

        Accepted input formats:
            +263771234567  →  0771234567
             263771234567  →  0771234567
             0771234567    →  0771234567  (unchanged)
        """
        phone = phone.strip().replace(" ", "").replace("-", "")
        if phone.startswith("+263"):
            return "0" + phone[4:]
        if phone.startswith("263"):
            return "0" + phone[3:]
        return phone
