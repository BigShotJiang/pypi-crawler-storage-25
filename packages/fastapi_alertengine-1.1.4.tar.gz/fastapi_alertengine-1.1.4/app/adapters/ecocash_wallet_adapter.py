# app/adapters/ecocash_wallet_adapter.py
"""
EcoCash wallet adapter stub for AnchorFlow.

EcoCash is Zimbabwe's dominant mobile money platform (Econet Wireless).
This stub returns structured error responses until the EcoCash Send Money
API credentials and integration contract are in place.

API reference:  EcoCash Merchant API v2 (requires signed merchant agreement)
Auth:           OAuth2 client_credentials
Send Money:     POST /v2/transactions/sendmoney
Reversal:       POST /v2/transactions/reverse

To activate:
  1. Obtain ECOCASH_CLIENT_ID, ECOCASH_CLIENT_SECRET, ECOCASH_BASE_URL from
     EcoCash merchant portal.
  2. Replace the stub body of reverse_transaction() and
     query_transaction_status() with real API calls.
  3. Add env vars to .env.example and app/config.py.
"""

import logging
import os
from datetime import datetime, timezone
from typing import Dict

from app.adapters.wallet_adapter import WalletAdapter

logger = logging.getLogger(__name__)

_CONFIGURED = bool(
    os.environ.get("ECOCASH_CLIENT_ID")
    and os.environ.get("ECOCASH_CLIENT_SECRET")
)


class EcoCashWalletAdapter(WalletAdapter):
    """
    EcoCash Zimbabwe wallet adapter.

    Returns ``success=False`` with a ``"not_configured"`` status until
    ECOCASH_CLIENT_ID and ECOCASH_CLIENT_SECRET are set in the environment.
    """

    def __init__(
        self,
        client_id: str = "",
        client_secret: str = "",
        base_url: str = "https://api.ecocash.co.zw",
        timeout_seconds: int = 30,
    ) -> None:
        self.client_id      = client_id or os.environ.get("ECOCASH_CLIENT_ID", "")
        self.client_secret  = client_secret or os.environ.get("ECOCASH_CLIENT_SECRET", "")
        self.base_url       = base_url or os.environ.get("ECOCASH_BASE_URL", "https://api.ecocash.co.zw")
        self.timeout        = timeout_seconds
        self._configured    = bool(self.client_id and self.client_secret)

    def reverse_transaction(self, instruction: Dict) -> Dict:
        """
        Reverse a previously settled EcoCash transaction.

        Args:
            instruction: dict with external_transaction_id, payer_wallet_id,
                         amount, reason.

        Returns:
            dict with success, reversal_id, status, timestamp.
            success=False until configured.
        """
        if not self._configured:
            logger.warning(
                "EcoCashWalletAdapter.reverse_transaction: not configured "
                "(ECOCASH_CLIENT_ID / ECOCASH_CLIENT_SECRET missing). "
                "tx_id=%s",
                instruction.get("external_transaction_id", "?"),
            )
            return {
                "success":    False,
                "reversal_id": None,
                "status":     "not_configured",
                "timestamp":  datetime.now(timezone.utc).isoformat(),
                "error":      "EcoCash credentials not set",
            }

        # ── Real implementation goes here ───────────────────────────────────
        # 1. Obtain OAuth2 access token
        # 2. POST /v2/transactions/reverse with instruction payload
        # 3. Parse response and return standardised dict
        logger.warning("EcoCashWalletAdapter.reverse_transaction: STUB (not yet implemented)")
        return {
            "success":    False,
            "reversal_id": None,
            "status":     "stub",
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "error":      "EcoCash reverse_transaction not yet implemented",
        }

    def query_transaction_status(self, external_transaction_id: str) -> Dict:
        """
        Query the status of an EcoCash transaction.

        Returns:
            dict with success, confirmed, status_raw, amount, timestamp.
            success=False until configured.
        """
        if not self._configured:
            logger.warning(
                "EcoCashWalletAdapter.query_transaction_status: not configured. "
                "tx_id=%s", external_transaction_id,
            )
            return {
                "success":    False,
                "confirmed":  False,
                "status_raw": "not_configured",
                "amount":     None,
                "timestamp":  datetime.now(timezone.utc).isoformat(),
                "error":      "EcoCash credentials not set",
            }

        logger.warning("EcoCashWalletAdapter.query_transaction_status: STUB")
        return {
            "success":    False,
            "confirmed":  False,
            "status_raw": "stub",
            "amount":     None,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "error":      "EcoCash query_transaction_status not yet implemented",
        }
