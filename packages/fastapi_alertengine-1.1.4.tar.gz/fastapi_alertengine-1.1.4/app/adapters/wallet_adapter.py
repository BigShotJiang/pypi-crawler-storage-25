"""
Wallet adapter interface for Tofamba.

Tofamba orchestrates wallet-to-wallet settlements but never holds funds itself.
The WalletAdapter is the boundary between Tofamba's escrow state machine and
each money-movement provider (EcoCash, InnBucks, Omari, etc.).

Concrete implementations should subclass WalletAdapter and override every
method.  The base class raises ``NotImplementedError`` so that missing
implementations are caught early in tests rather than silently no-oping.
"""

from typing import Dict


class WalletAdapter:
    """
    Abstract interface for communicating with a wallet provider.

    Tofamba uses this adapter exclusively to *instruct* the provider to move
    or reverse funds – it never stores value itself.
    """

    def reverse_transaction(self, instruction: Dict) -> Dict:
        """
        Ask the wallet provider to reverse a previously settled transaction.

        Tofamba calls this when an escrow expires without a delivery PIN being
        entered, or when a dispute is resolved in the payer's favour.

        Args:
            instruction: A dict containing:
                - ``external_transaction_id`` (str): The provider's own
                  reference for the original settlement.
                - ``payer_wallet_id`` (str): The wallet that should receive
                  the refunded amount.
                - ``amount`` (float): The value to return (in local currency).
                - ``reason`` (str): Human-readable reason, e.g.
                  ``"escrow_timeout"``.

        Returns:
            A dict containing:
                - ``success`` (bool): Whether the reversal was accepted.
                - ``reversal_id`` (str): Provider-assigned reversal reference.
                - ``status`` (str): ``"confirmed"`` or ``"pending"``.
                - ``timestamp`` (str): ISO-8601 timestamp of the response.

        Raises:
            NotImplementedError: Subclasses must override this method.
        """
        raise NotImplementedError(
            "WalletAdapter.reverse_transaction() must be implemented by each "
            "provider-specific subclass."
        )

    def query_transaction_status(self, external_transaction_id: str) -> Dict:
        """
        Query the live status of a transaction from the wallet provider.

        Used by ``DealService.poll_provider_status()`` to independently verify
        that a ``payment-detected`` webhook genuinely reflects a settled
        transaction before Tofamba transitions a Deal to HELD state.

        Args:
            external_transaction_id: The provider's own reference for the
                transaction to query (same value stored in
                ``Escrow.external_transaction_id``).

        Returns:
            A dict containing:
                - ``success`` (bool): True if the query itself succeeded.
                - ``confirmed`` (bool): True if the payment is confirmed by
                  the provider (i.e. funds have moved).
                - ``status_raw`` (str): The provider's original status string
                  for logging/debugging.
                - ``amount`` (float | None): Confirmed amount if available.
                - ``timestamp`` (str): ISO-8601 UTC timestamp of the response.

        Raises:
            NotImplementedError: Subclasses must override this method.
        """
        raise NotImplementedError(
            "WalletAdapter.query_transaction_status() must be implemented by "
            "each provider-specific subclass."
        )
