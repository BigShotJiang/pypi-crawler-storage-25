"""
Twilio WhatsApp adapter for Tofamba.

Thin, injectable wrapper around the Twilio REST API for sending outbound
WhatsApp messages.  Using an adapter rather than calling Twilio directly
keeps the service layer decoupled and fully testable via MockTwilioAdapter.

Usage
-----
Production::

    adapter = TwilioAdapter(account_sid, auth_token, from_number)
    ok = adapter.send_message("0771234567", "Your deal is ready!")

Tests::

    adapter = MockTwilioAdapter()
    # ... call code under test ...
    assert adapter.sent[0]["to"] == "0771234567"
"""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_WA_PREFIX = "whatsapp:"


def _wa(phone: str) -> str:
    """Ensure the phone number has the whatsapp: prefix Twilio requires."""
    phone = phone.strip()
    if not phone.startswith(_WA_PREFIX):
        # Normalise Zimbabwean numbers to international format if needed
        if phone.startswith("0") and len(phone) == 10:
            phone = "+263" + phone[1:]
        return f"{_WA_PREFIX}{phone}"
    return phone


class TwilioAdapter:
    """
    Production adapter — calls the Twilio REST API to send WhatsApp messages.

    The Twilio Python helper library (``twilio``) is a soft dependency: if it
    is not installed the adapter raises ``ImportError`` at construction time
    rather than at send time, giving an early, clear failure message.
    """

    def __init__(
        self,
        account_sid: str,
        auth_token: str,
        from_number: str,
    ):
        """
        Args:
            account_sid:  Twilio Account SID (starts with ``AC``).
            auth_token:   Twilio Auth Token.
            from_number:  Twilio-provisioned WhatsApp sandbox or approved
                          sender number, e.g. ``+14155238886``.
        """
        try:
            from twilio.rest import Client  # type: ignore[import]
        except ImportError as exc:
            raise ImportError(
                "TwilioAdapter requires the 'twilio' package. "
                "Install it with: pip install twilio"
            ) from exc

        self._client = Client(account_sid, auth_token)
        self._from = _wa(from_number)

    def send_message(self, to_phone: str, body: str) -> bool:
        """
        Send a WhatsApp message to *to_phone*.

        Args:
            to_phone: Recipient phone number (Zimbabwean format accepted).
            body:     Plain-text message body (max ~1600 chars for WhatsApp).

        Returns:
            ``True`` if Twilio accepted the message, ``False`` on error.
        """
        to = _wa(to_phone)
        try:
            msg = self._client.messages.create(
                from_=self._from,
                to=to,
                body=body,
            )
            logger.info(
                "Twilio message sent | sid=%s to=%s status=%s",
                msg.sid, to, msg.status,
            )
            return True
        except Exception as exc:
            logger.error("Twilio send failed to %s: %s", to, exc)
            return False


class MockTwilioAdapter:
    """
    In-memory mock for tests and staging — never contacts Twilio.

    All messages are recorded in ``self.sent`` for assertion in tests.
    Configure ``self.should_fail = True`` to simulate delivery failures.
    """

    def __init__(self, *, should_fail: bool = False):
        self.should_fail = should_fail
        self.sent: List[Dict] = []

    def send_message(self, to_phone: str, body: str) -> bool:
        self.sent.append({"to": to_phone, "body": body})
        if self.should_fail:
            logger.warning("MockTwilioAdapter: simulated failure to %s", to_phone)
            return False
        return True

    def reset(self) -> None:
        """Clear recorded messages between tests."""
        self.sent.clear()
