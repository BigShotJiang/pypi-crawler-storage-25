# app/adapters/omari_wallet_adapter.py
"""
Omari wallet adapter stub for AnchorFlow.

Omari is a SADC-focused cross-border mobile money platform enabling USD
transfers across Zimbabwe, Zambia, and other SADC markets.

This stub returns structured error responses until the Omari API
credentials and partnership agreement are in place.

To activate:
  1. Obtain OMARI_API_KEY, OMARI_MERCHANT_ID, OMARI_BASE_URL.
  2. Implement reverse_transaction() and query_transaction_status().
  3. Add env vars to .env.example and app/config.py.
"""

import logging
import os
from datetime import datetime, timezone
from typing import Dict

from app.adapters.wallet_adapter import WalletAdapter

logger = logging.getLogger(__name__)


class OmariWalletAdapter(WalletAdapter):
    """
    Omari SADC wallet adapter.

    Returns ``success=False`` with ``status="not_configured"`` until
    OMARI_API_KEY and OMARI_MERCHANT_ID are set.
    """

    def __init__(
        self,
        api_key: str = "",
        merchant_id: str = "",
        base_url: str = "https://api.omari.io",
        timeout_seconds: int = 30,
    ) -> None:
        self.api_key     = api_key or os.environ.get("OMARI_API_KEY", "")
        self.merchant_id = merchant_id or os.environ.get("OMARI_MERCHANT_ID", "")
        self.base_url    = base_url or os.environ.get("OMARI_BASE_URL", "https://api.omari.io")
        self.timeout     = timeout_seconds
        self._configured = bool(self.api_key and self.merchant_id)

    def reverse_transaction(self, instruction: Dict) -> Dict:
        if not self._configured:
            logger.warning(
                "OmariWalletAdapter.reverse_transaction: not configured. tx_id=%s",
                instruction.get("external_transaction_id", "?"),
            )
            return {
                "success":    False,
                "reversal_id": None,
                "status":     "not_configured",
                "timestamp":  datetime.now(timezone.utc).isoformat(),
                "error":      "Omari credentials not set",
            }

        logger.warning("OmariWalletAdapter.reverse_transaction: STUB")
        return {
            "success":    False,
            "reversal_id": None,
            "status":     "stub",
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "error":      "Omari reverse_transaction not yet implemented",
        }

    def query_transaction_status(self, external_transaction_id: str) -> Dict:
        if not self._configured:
            logger.warning(
                "OmariWalletAdapter.query_transaction_status: not configured. tx_id=%s",
                external_transaction_id,
            )
            return {
                "success":    False,
                "confirmed":  False,
                "status_raw": "not_configured",
                "amount":     None,
                "timestamp":  datetime.now(timezone.utc).isoformat(),
                "error":      "Omari credentials not set",
            }

        logger.warning("OmariWalletAdapter.query_transaction_status: STUB")
        return {
            "success":    False,
            "confirmed":  False,
            "status_raw": "stub",
            "amount":     None,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "error":      "Omari query_transaction_status not yet implemented",
        }
