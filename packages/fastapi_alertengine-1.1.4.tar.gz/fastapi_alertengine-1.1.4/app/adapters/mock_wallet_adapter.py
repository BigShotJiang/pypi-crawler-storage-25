"""
Mock wallet adapter for testing and local development.

Follows the same pattern as MockFiscalAdapter: records every call so
tests can assert on exactly what was sent, and supports configurable
failure injection (soft failure and exception raising).

Usage::

    adapter = MockWalletAdapter()
    result = adapter.reverse_transaction(instruction)
    assert result["success"] is True
    assert len(adapter.recorded_calls) == 1

Failure injection::

    # Soft failure (success=False, no exception):
    adapter = MockWalletAdapter(fail_on_tx_id="TXN-DISPUTED")

    # Hard failure (raises an exception):
    adapter = MockWalletAdapter(raise_on_tx_id="TXN-BROKEN")
"""

import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional

from app.adapters.wallet_adapter import WalletAdapter


class MockWalletAdapter(WalletAdapter):
    """
    In-memory mock adapter for tests. Does NOT contact any external API.

    Each call to ``reverse_transaction()`` is stored in ``recorded_calls``
    as a shallow copy of the instruction dict, so tests can assert on the
    exact arguments that were passed.
    """

    def __init__(
        self,
        *,
        success: bool = True,
        fail_on_tx_id: Optional[str] = None,
        raise_on_tx_id: Optional[str] = None,
        raise_exception: Optional[Exception] = None,
    ):
        """
        Args:
            success:         Default ``success`` value returned in the response.
            fail_on_tx_id:   If set, return ``success=False`` when
                             ``external_transaction_id`` matches this value.
            raise_on_tx_id:  If set, raise ``raise_exception`` when
                             ``external_transaction_id`` matches this value.
            raise_exception: Exception raised when ``raise_on_tx_id`` matches.
                             Defaults to ``RuntimeError("Mock adapter error")``.
        """
        self.success = success
        self.fail_on_tx_id = fail_on_tx_id
        self.raise_on_tx_id = raise_on_tx_id
        self.raise_exception = raise_exception or RuntimeError("Mock adapter error")
        self.recorded_calls: List[Dict] = []
        # Controls what query_transaction_status() returns
        self.query_confirmed: bool = True
        self.query_status_raw: str = "sent"
        self.query_recorded_calls: List[str] = []

    # ------------------------------------------------------------------
    # WalletAdapter interface
    # ------------------------------------------------------------------

    def reverse_transaction(self, instruction: Dict) -> Dict:
        """
        Record the call and return a mock reversal response.

        The call is recorded *before* any failure is triggered, so tests
        that expect an exception can still inspect ``recorded_calls``.
        """
        # Store a copy so later mutations to the original dict don't affect records
        self.recorded_calls.append(dict(instruction))

        tx_id = instruction.get("external_transaction_id", "")

        if self.raise_on_tx_id and tx_id == self.raise_on_tx_id:
            raise self.raise_exception

        if self.fail_on_tx_id and tx_id == self.fail_on_tx_id:
            return {
                "success": False,
                "reversal_id": "",
                "status": "failed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        reversal_id = f"MOCK-REV-{uuid.uuid4().hex[:12].upper()}"
        return {
            "success": self.success,
            "reversal_id": reversal_id,
            "status": "confirmed" if self.success else "failed",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def query_transaction_status(self, external_transaction_id: str) -> Dict:
        """
        Mock implementation — returns a configurable status without any API call.

        Configure via:
            adapter.query_confirmed   = True / False
            adapter.query_status_raw  = "sent" / "ok" / "failed"
        """
        self.query_recorded_calls.append(external_transaction_id)
        return {
            "success":    True,
            "confirmed":  self.query_confirmed,
            "status_raw": self.query_status_raw,
            "amount":     None,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
        }

    # ------------------------------------------------------------------
    # Test helpers
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """Clear all recorded calls — useful when reusing an adapter across tests."""
        self.recorded_calls.clear()
        self.query_recorded_calls.clear()
