# url=https://github.com/Tandem-Media/Tandem_Hive_V1_Final/blob/copilot/update-escrow-model/app/adapters/fiscal_adapter.py
from abc import ABC, abstractmethod
from typing import Dict, List
from decimal import Decimal
from datetime import datetime, date

class FiscalError(Exception):
    """Raised when fiscal entry generation fails"""
    pass


class FiscalAdapter(ABC):
    """
    Abstract interface for tax compliance (fiscalisation).
    
    In Zimbabwe, every transaction earning commission must be 
    fiscally recorded via ZIMRA's Virtual Fiscalisation API.
    
    Tofamba is an observer: we don't hold the money, but we MUST
    report the tax liability.
    """
    
    @abstractmethod
    def generate_fiscal_entry(self, transaction: Dict) -> Dict:
        """
        Generate a fiscal record for a commission earned.
        
        Args:
            transaction: {
                "settlement_id": int,
                "recipient_type": str,  # "merchant" or "courier"
                "recipient_id": str,
                "gross_commission": Decimal,  # e.g., 5.5%
                "vat_rate": Decimal,         # e.g., 15.5%
                "transaction_date": datetime,
                "reference_id": str,         # Escrow ID
            }
        
        Returns:
            {
                "success": bool,
                "fiscal_auth_code": str,     # ZIMRA's response
                "z_number": str,             # Daily fiscal reference
                "tax_invoice_number": str,   # For reconciliation
                "timestamp": str,            # ISO 8601 formatted string
                "raw_response": dict,        # Full ZIMRA response
            }
        
        Raises:
            FiscalError: If ZIMRA API fails
        """
        pass
    
    @abstractmethod
    def generate_tax_report(self, start_date: date, end_date: date) -> Dict:
        """
        Generate ZIMRA-compliant tax report for the specified period.
        
        Args:
            start_date: The start date of the reporting period.
            end_date: The end date of the reporting period.

        Returns:
            {
                "period": str,                  # e.g., "2026-03"
                "total_transactions": int,
                "total_gross_commission": Decimal,
                "total_vat_liability": Decimal,
                "net_revenue": Decimal,
                "fiscal_entries": List[dict],  # List of fiscal entry details
            }
        """
        pass