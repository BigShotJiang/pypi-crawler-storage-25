# url=https://github.com/Tandem-Media/Tandem_Hive_V1_Final/blob/copilot/update-escrow-model/app/adapters/mock_fiscal_adapter.py
from app.adapters.fiscal_adapter import FiscalAdapter, FiscalError
from typing import Dict, List
from decimal import Decimal
from datetime import datetime, date
import uuid


class MockFiscalAdapter(FiscalAdapter):
    """
    Mock implementation of FiscalAdapter for testing and development.
    
    Does NOT contact ZIMRA; generates deterministic fiscal codes
    suitable for local development and integration testing.
    """
    
    def __init__(self, fail_on_pattern: str = None):
        """
        Args:
            fail_on_pattern: If set, any recipient_id matching this pattern
                           will cause fiscal entry generation to fail.
                           Useful for testing error handling.
        """
        self.fail_on_pattern = fail_on_pattern
        self.generated_entries = []  # For debugging/testing
    
    def generate_fiscal_entry(self, transaction: Dict) -> Dict:
        """
        Generate a mock fiscal entry.
        
        Mock fiscal codes follow pattern:
        - fiscal_auth_code: "MOCK-{UUID}"
        - z_number: "Z-{YYYYMMDD}-{SEQUENCE}"
        - tax_invoice_number: "TIN-{settlement_id}-{recipient_type}-{SEQUENCE}"
        """
        
        # Check fail pattern
        recipient_id = transaction.get("recipient_id", "")
        if self.fail_on_pattern and self.fail_on_pattern in recipient_id:
            raise FiscalError(
                f"Mock fiscal adapter configured to fail for pattern: {self.fail_on_pattern}"
            )
        
        settlement_id = transaction.get("settlement_id")
        recipient_type = transaction.get("recipient_type")
        gross_commission = transaction.get("gross_commission")
        vat_rate = transaction.get("vat_rate", Decimal("15.5"))
        transaction_date = transaction.get("transaction_date", datetime.now())
        reference_id = transaction.get("reference_id")
        
        # Calculate VAT
        vat_amount = gross_commission * (vat_rate / Decimal("100"))
        net_amount = gross_commission - vat_amount
        
        # Generate mock codes
        fiscal_auth_code = f"MOCK-{uuid.uuid4().hex[:12].upper()}"
        z_number = f"Z-{transaction_date.strftime('%Y%m%d')}-{settlement_id:06d}"
        tax_invoice_number = f"TIN-{settlement_id}-{recipient_type}-{uuid.uuid4().hex[:8].upper()}"
        
        entry = {
            "success": True,
            "fiscal_auth_code": fiscal_auth_code,
            "z_number": z_number,
            "tax_invoice_number": tax_invoice_number,
            "timestamp": datetime.now().isoformat(),
            "transaction_date": transaction_date.isoformat(),
            "raw_response": {
                "status": "MOCK_SUCCESS",
                "settlement_id": settlement_id,
                "recipient_type": recipient_type,
                "gross_commission": str(gross_commission),
                "vat_rate": str(vat_rate),
                "vat_amount": str(vat_amount),
                "net_amount": str(net_amount),
                "reference_id": reference_id,
            }
        }
        
        # Store for debugging
        self.generated_entries.append(entry)
        
        return entry
    
    def generate_tax_report(self, start_date: date, end_date: date) -> Dict:
        """
        Generate a mock ZIMRA tax report.
        
        Aggregates all generated entries in the date range.
        """
        
        # Filter entries by transaction_date (not system timestamp)
        relevant_entries = [
            e for e in self.generated_entries
            if start_date <= datetime.fromisoformat(e["transaction_date"]).date() <= end_date
        ]
        
        # Calculate totals
        total_transactions = len(relevant_entries)
        total_gross_commission = Decimal("0")
        total_vat_liability = Decimal("0")
        
        for entry in relevant_entries:
            raw = entry.get("raw_response", {})
            total_gross_commission += Decimal(raw.get("gross_commission", "0"))
            total_vat_liability += Decimal(raw.get("vat_amount", "0"))
        
        net_revenue = total_gross_commission - total_vat_liability
        
        return {
            "period": f"{start_date.strftime('%Y-%m')} to {end_date.strftime('%Y-%m')}",
            "total_transactions": total_transactions,
            "total_gross_commission": total_gross_commission,
            "total_vat_liability": total_vat_liability,
            "net_revenue": net_revenue,
            "fiscal_entries": relevant_entries,
            "status": "MOCK",
        }