# app/adapters/innbucks_wallet_adapter.py
"""
InnBucks wallet adapter stub for AnchorFlow.

InnBucks is a Zimbabwean mobile money platform operated by Innscor Africa.
This stub returns structured error responses until the InnBucks API
credentials and integration agreement are in place.

To activate:
  1. Obtain INNBUCKS_API_KEY, INNBUCKS_MERCHANT_CODE, INNBUCKS_BASE_URL.
  2. Implement reverse_transaction() and query_transaction_status().
  3. Add env vars to .env.example and app/config.py.
"""

import logging
import os
from datetime import datetime, timezone
from typing import Dict

from app.adapters.wallet_adapter import WalletAdapter

logger = logging.getLogger(__name__)


class InnBucksWalletAdapter(WalletAdapter):
    """
    InnBucks Zimbabwe wallet adapter.

    Returns ``success=False`` with ``status="not_configured"`` until
    INNBUCKS_API_KEY and INNBUCKS_MERCHANT_CODE are set.
    """

    def __init__(
        self,
        api_key: str = "",
        merchant_code: str = "",
        base_url: str = "https://api.innbucks.co.zw",
        timeout_seconds: int = 30,
    ) -> None:
        self.api_key        = api_key or os.environ.get("INNBUCKS_API_KEY", "")
        self.merchant_code  = merchant_code or os.environ.get("INNBUCKS_MERCHANT_CODE", "")
        self.base_url       = base_url or os.environ.get("INNBUCKS_BASE_URL", "https://api.innbucks.co.zw")
        self.timeout        = timeout_seconds
        self._configured    = bool(self.api_key and self.merchant_code)

    def reverse_transaction(self, instruction: Dict) -> Dict:
        if not self._configured:
            logger.warning(
                "InnBucksWalletAdapter.reverse_transaction: not configured. tx_id=%s",
                instruction.get("external_transaction_id", "?"),
            )
            return {
                "success":    False,
                "reversal_id": None,
                "status":     "not_configured",
                "timestamp":  datetime.now(timezone.utc).isoformat(),
                "error":      "InnBucks credentials not set",
            }

        logger.warning("InnBucksWalletAdapter.reverse_transaction: STUB")
        return {
            "success":    False,
            "reversal_id": None,
            "status":     "stub",
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "error":      "InnBucks reverse_transaction not yet implemented",
        }

    def query_transaction_status(self, external_transaction_id: str) -> Dict:
        if not self._configured:
            logger.warning(
                "InnBucksWalletAdapter.query_transaction_status: not configured. tx_id=%s",
                external_transaction_id,
            )
            return {
                "success":    False,
                "confirmed":  False,
                "status_raw": "not_configured",
                "amount":     None,
                "timestamp":  datetime.now(timezone.utc).isoformat(),
                "error":      "InnBucks credentials not set",
            }

        logger.warning("InnBucksWalletAdapter.query_transaction_status: STUB")
        return {
            "success":    False,
            "confirmed":  False,
            "status_raw": "stub",
            "amount":     None,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "error":      "InnBucks query_transaction_status not yet implemented",
        }
