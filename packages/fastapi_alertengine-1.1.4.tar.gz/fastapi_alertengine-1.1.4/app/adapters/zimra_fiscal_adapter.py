"""
ZIMRA Virtual Fiscalisation adapter for Tofamba.

Replaces the invalid ``zimra_fiscal+adapter.py`` (the ``+`` in the filename
makes it un-importable as a Python module).

Changes from the original stub
-------------------------------
* Filename fixed: ``zimra_fiscal+adapter.py`` → ``zimra_fiscal_adapter.py``
* Task 4 — Fiscalization Audit: ``generate_fiscal_entry()`` now writes all
  submission metadata into ``EscrowStateLog`` so every ZIMRA interaction is
  visible in the platform's audit trail.
* ``db_session`` is accepted as an optional parameter; when provided the
  audit log is written; when ``None`` (e.g. in migration scripts / CLI tools)
  the ZIMRA call proceeds but no audit row is written.

IMPORTANT: This remains a **stub** pending actual ZIMRA API documentation.
The endpoint URLs, payload structure, and response schema are placeholders.
"""

import json
import logging
from datetime import date, datetime, UTC
from decimal import Decimal
from typing import Dict, Optional

import requests

from app.adapters.fiscal_adapter import FiscalAdapter, FiscalError
from app.config import settings

logger = logging.getLogger(__name__)


class ZimraFiscalAdapter(FiscalAdapter):
    """
    Production integration with ZIMRA Virtual Fiscalisation API.

    IMPORTANT: This is a stub pending actual ZIMRA API documentation.

    Expected ZIMRA API:
      - Endpoint: https://fiscalisation.zimra.gov.zw/api/v1/...
      - Authentication: Bearer token (API key)
      - Rate limits: TBD
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        db_session=None,
    ):
        """
        Args:
            api_key:     ZIMRA API authentication token.
            api_url:     Base URL for ZIMRA Virtual Fiscalisation API.
            db_session:  Optional SQLAlchemy session.  When provided, every
                         ``generate_fiscal_entry()`` call writes an audit row
                         into ``EscrowStateLog`` (Task 4 requirement).
        """
        self.api_key    = api_key or getattr(settings, "ZIMRA_API_KEY", None)
        self.api_url    = api_url or getattr(settings, "ZIMRA_API_URL", None)
        self.db_session = db_session
        self.timeout    = 30

        if not self.api_key or not self.api_url:
            raise ValueError(
                "ZIMRA_API_KEY and ZIMRA_API_URL must be set in environment"
            )

    # ------------------------------------------------------------------
    # FiscalAdapter interface
    # ------------------------------------------------------------------

    def generate_fiscal_entry(self, transaction: Dict) -> Dict:
        """
        Submit a fiscal entry to the ZIMRA Virtual Fiscalisation API and
        write a full audit record into ``EscrowStateLog``.

        Audit record
        ~~~~~~~~~~~~
        ``triggered_by`` = ``"fiscal_receipt_submitted"``

        ``metadata_json`` includes:
          - all input transaction fields
          - ZIMRA response: fiscal_auth_code, z_number, tax_invoice_number
          - submission timestamp
          - success / error flag

        The audit row is written whether the ZIMRA call succeeds or fails so
        that failures are also visible in the platform's audit trail.

        Args:
            transaction: Dict containing:
                - ``settlement_id``     (str)
                - ``recipient_type``    (str)  e.g. "merchant"
                - ``recipient_id``      (str)  wallet number or merchant ID
                - ``gross_commission``  (Decimal)
                - ``vat_rate``          (Decimal, default 15.5)
                - ``transaction_date``  (date)
                - ``reference_id``      (str)
                - ``escrow_id``         (int | None)  links the audit row
                - ``deal_id``           (str | None)  for context

        Returns:
            {
                "success":           bool,
                "fiscal_auth_code":  str | None,
                "z_number":          str | None,
                "tax_invoice_number": str | None,
                "timestamp":         str,
                "raw_response":      dict,
            }

        Raises:
            FiscalError: When the ZIMRA API call fails.
        """
        settlement_id     = transaction.get("settlement_id")
        recipient_type    = transaction.get("recipient_type")
        recipient_id      = transaction.get("recipient_id")
        gross_commission  = transaction.get("gross_commission")
        vat_rate          = transaction.get("vat_rate", Decimal("15.5"))
        transaction_date  = transaction.get("transaction_date")
        reference_id      = transaction.get("reference_id")
        escrow_id         = transaction.get("escrow_id")     # for audit link
        deal_id           = transaction.get("deal_id")       # for audit context

        payload = {
            "settlement_id":    settlement_id,
            "recipient_type":   recipient_type,
            "recipient_id":     recipient_id,
            "gross_commission": str(gross_commission),
            "vat_rate":         str(vat_rate),
            "transaction_date": transaction_date.isoformat() if transaction_date else None,
            "reference_id":     reference_id,
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type":  "application/json",
        }

        now = datetime.now(UTC).isoformat()
        result: Dict = {}
        success = False

        try:
            # ZIMRA Endpoint (stub — awaiting actual API)
            response = requests.post(
                f"{self.api_url}/fiscal-entries",
                json=payload,
                headers=headers,
                timeout=self.timeout,
            )
            response.raise_for_status()
            result = response.json()
            success = True

            out = {
                "success":             True,
                "fiscal_auth_code":    result.get("fiscal_auth_code"),
                "z_number":            result.get("z_number"),
                "tax_invoice_number":  result.get("tax_invoice_number"),
                "timestamp":           now,
                "raw_response":        result,
            }

        except requests.exceptions.RequestException as exc:
            logger.error("ZIMRA fiscal entry failed: %s", exc)
            out = {
                "success":             False,
                "fiscal_auth_code":    None,
                "z_number":            None,
                "tax_invoice_number":  None,
                "timestamp":           now,
                "raw_response":        {"error": str(exc)},
            }

        finally:
            # ── Task 4: Audit log ────────────────────────────────────────────
            # Write regardless of success/failure so failures are also auditable.
            self._write_audit_log(
                escrow_id  = escrow_id,
                deal_id    = deal_id,
                payload    = payload,
                result     = out,
                timestamp  = now,
            )

        if not success:
            raise FiscalError(f"Failed to generate fiscal entry: {out['raw_response']}")

        return out

    def generate_tax_report(self, start_date: date, end_date: date) -> Dict:
        """
        Request a ZIMRA tax report for the specified period.

        STUB: Awaiting actual ZIMRA API specification.
        """
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type":  "application/json",
        }
        params = {
            "start_date": start_date.isoformat(),
            "end_date":   end_date.isoformat(),
        }
        try:
            response = requests.get(
                f"{self.api_url}/tax-reports",
                headers=headers,
                params=params,
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error("ZIMRA tax report failed: %s", exc)
            raise FiscalError(f"Failed to generate tax report: {exc}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _write_audit_log(
        self,
        escrow_id: Optional[int],
        deal_id: Optional[str],
        payload: Dict,
        result: Dict,
        timestamp: str,
    ) -> None:
        """
        Write an EscrowStateLog row capturing the full ZIMRA submission.

        Silently skips if no ``db_session`` was injected (e.g. in CLI tools).
        Silently catches DB errors so a logging failure never masks a fiscal
        entry that was already successfully submitted to ZIMRA.
        """
        if self.db_session is None:
            return

        from app.models.database import EscrowStateLog  # local import avoids circular dep

        try:
            log = EscrowStateLog(
                escrow_id       = escrow_id,
                previous_status = "fiscal_pending",
                new_status      = "fiscal_submitted" if result.get("success") else "fiscal_failed",
                triggered_by    = "fiscal_receipt_submitted",
                metadata_json   = json.dumps({
                    "deal_id":            deal_id,
                    "settlement_id":      payload.get("settlement_id"),
                    "recipient_type":     payload.get("recipient_type"),
                    "recipient_id":       payload.get("recipient_id"),
                    "gross_commission":   payload.get("gross_commission"),
                    "vat_rate":           payload.get("vat_rate"),
                    "transaction_date":   payload.get("transaction_date"),
                    "reference_id":       payload.get("reference_id"),
                    "fiscal_auth_code":   result.get("fiscal_auth_code"),
                    "z_number":           result.get("z_number"),
                    "tax_invoice_number": result.get("tax_invoice_number"),
                    "success":            result.get("success"),
                    "timestamp":          timestamp,
                }),
            )
            self.db_session.add(log)
            self.db_session.flush()  # caller manages the commit
            logger.info(
                "ZIMRA fiscal audit log written | escrow_id=%s deal_id=%s success=%s",
                escrow_id, deal_id, result.get("success"),
            )
        except Exception as exc:
            logger.error(
                "Failed to write ZIMRA fiscal audit log (escrow_id=%s): %s",
                escrow_id, exc,
            )
