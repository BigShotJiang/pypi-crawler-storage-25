# app/startup/health_check.py
"""
Startup verification suite for AnchorFlow.

Runs at application startup (via FastAPI lifespan) and logs the status of
every critical dependency.  Never raises — a missing dependency degrades
gracefully rather than preventing startup.

Checks:
  1. Database connectivity (SELECT 1)
  2. Redis connectivity (PING)
  3. Required environment variables
  4. Optional service keys (warns if absent, does not fail)

Usage (in main.py)::

    from contextlib import asynccontextmanager
    from app.startup.health_check import run_startup_checks

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        run_startup_checks()
        yield

    app = FastAPI(lifespan=lifespan)
"""

import logging
import os
from typing import Dict, List

logger = logging.getLogger(__name__)

# ─── REQUIRED VARS ────────────────────────────────────────────────────────────
_REQUIRED = [
    "DATABASE_URL",
    "REDIS_URL",
    "TWILIO_ACCOUNT_SID",
    "TWILIO_AUTH_TOKEN",
    "TWILIO_WHATSAPP_NUMBER",
    "PAYNOW_INTEGRATION_ID",
    "PAYNOW_INTEGRATION_KEY",
    "PAYNOW_MERCHANT_EMAIL",
]

# ─── OPTIONAL VARS (warn if absent, do not fail) ──────────────────────────────
_OPTIONAL = [
    ("ANTHROPIC_API_KEY",       "Claude AI responses disabled — keyword-only mode"),
    ("GOOGLE_MAPS_API_KEY",     "Google Maps disabled — manual distance entry only"),
    ("ECOCASH_CLIENT_ID",       "EcoCash adapter not configured"),
    ("INNBUCKS_API_KEY",        "InnBucks adapter not configured"),
    ("OMARI_API_KEY",           "Omari adapter not configured"),
]


# ─── PUBLIC ENTRY POINT ───────────────────────────────────────────────────────

def run_startup_checks() -> Dict[str, bool]:
    """
    Run all startup checks and return a summary dict.

    Returns:
        {
            "env_vars":  bool,   — all required vars present
            "database":  bool,   — DB responds to SELECT 1
            "redis":     bool,   — Redis responds to PING
            "overall":   bool,   — all critical checks passed
        }

    Never raises — failures are logged and reflected in the returned dict.
    """
    results: Dict[str, bool] = {
        "env_vars":  False,
        "database":  False,
        "redis":     False,
        "overall":   False,
    }

    results["env_vars"]  = _check_env_vars()
    results["database"]  = _check_database()
    results["redis"]     = _check_redis()
    results["overall"]   = all([
        results["env_vars"],
        results["database"],
        results["redis"],
    ])

    _log_optional_vars()

    if results["overall"]:
        logger.info("Startup checks PASSED — all critical dependencies healthy")
    else:
        failed = [k for k, v in results.items() if k != "overall" and not v]
        logger.error(
            "Startup checks FAILED — degraded mode may activate. "
            "Failed: %s", ", ".join(failed),
        )

    return results


# ─── INDIVIDUAL CHECKS ────────────────────────────────────────────────────────

def _check_env_vars() -> bool:
    """Verify all required environment variables are set (non-empty)."""
    missing: List[str] = [v for v in _REQUIRED if not os.environ.get(v)]
    if missing:
        logger.error(
            "Startup: MISSING required env vars: %s. "
            "Set these in Railway Variables or .env before deploying.",
            ", ".join(missing),
        )
        return False
    logger.info("Startup: env vars OK (%d required vars present)", len(_REQUIRED))
    return True


def _check_database() -> bool:
    """Attempt a lightweight SELECT 1 against the configured database."""
    try:
        from sqlalchemy import create_engine, text
        url = os.environ.get("DATABASE_URL", "")
        if not url:
            logger.error("Startup: DATABASE_URL not set — skipping DB check")
            return False

        connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
        engine = create_engine(url, connect_args=connect_args, pool_pre_ping=True)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info("Startup: database OK")
        return True
    except Exception as exc:
        logger.error("Startup: database FAILED — %s", exc)
        return False


def _check_redis() -> bool:
    """Attempt a PING against the configured Redis instance."""
    try:
        import redis as redis_lib
        url = os.environ.get("REDIS_URL", "redis://localhost:6379")
        client = redis_lib.Redis.from_url(
            url,
            socket_connect_timeout=3,
            socket_timeout=3,
            decode_responses=True,
        )
        client.ping()
        logger.info("Startup: Redis OK")
        return True
    except Exception as exc:
        logger.error("Startup: Redis FAILED — %s", exc)
        return False


def _log_optional_vars() -> None:
    """Log warnings for absent optional configuration."""
    for var, message in _OPTIONAL:
        if not os.environ.get(var):
            logger.warning("Startup: %s not set — %s", var, message)
