# app/routes/dashboards/transaction_health.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timezone, timedelta
from sqlalchemy import func
from pydantic import BaseModel, Field
from typing import Dict, List
import logging

from app.dependencies import get_db
from app.models.database import Escrow

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/dashboard/transaction-health",
    tags=["dashboards"],
    description="Dashboard 1: Transaction Health - Ensure payments are flowing"
)

# ────────── Pydantic Models ──────────

class TransactionsMetrics(BaseModel):
    total: int
    successful: int
    failed: int
    reversed: int
    success_rate_percent: float
    reversal_rate_percent: float

class SLOs(BaseModel):
    success_rate_target: float = 99.0
    reversal_rate_max: float = 5.0
    success_rate_ok: bool
    reversal_rate_ok: bool

class Alerts(BaseModel):
    critical: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)

class TransactionHealthMetrics(BaseModel):
    period: str
    timestamp: str
    transactions: TransactionsMetrics
    slos: SLOs
    alerts: Alerts

# ────────── Endpoint ──────────

@router.get(
    "/metrics",
    response_model=TransactionHealthMetrics,
    status_code=200,
    summary="Transaction Health Metrics",
    description="Last 24h transaction volume, success rate, and reversal rate"
)
def transaction_health_metrics(db: Session = Depends(get_db)):
    """
    Dashboard 1: Transaction Health
    
    Purpose: Ensure payments are actually flowing
    
    Metrics:
    - Total transactions
    - Success rate (target: 99%+)
    - Reversal rate (alert if > 5%)
    - Failed transactions
    
    Critical alert if success rate < 95%
    """
    now = datetime.now(timezone.utc)
    t0 = now - timedelta(hours=24)
    
    try:
        # Core metrics
        total_tx = db.query(Escrow).filter(Escrow.created_at >= t0).count()
        successful_tx = db.query(Escrow).filter(
            Escrow.status == "released",
            Escrow.created_at >= t0
        ).count()
        failed_tx = db.query(Escrow).filter(
            Escrow.status.in_(["expired", "reversal_confirmed"]),
            Escrow.created_at >= t0
        ).count()
        reversed_tx = db.query(Escrow).filter(
            Escrow.status == "reversal_confirmed",
            Escrow.created_at >= t0
        ).count()
        
        success_rate = (successful_tx / total_tx * 100) if total_tx > 0 else 0.0
        reversal_rate = (reversed_tx / total_tx * 100) if total_tx > 0 else 0.0
        
        # SLO targets
        success_rate_target = 99.0
        reversal_rate_max = 5.0
        
        success_rate_ok = success_rate >= success_rate_target
        reversal_rate_ok = reversal_rate <= reversal_rate_max
        
        # Alerts
        alerts = Alerts()
        
        if success_rate < 95:
            alerts.critical.append(
                f"🚨 CRITICAL: Success rate {success_rate:.1f}% - below 95% threshold"
            )
        elif success_rate < success_rate_target:
            alerts.warnings.append(
                f"⚠️ Success rate {success_rate:.1f}% - below target {success_rate_target}%"
            )
        
        if reversal_rate > reversal_rate_max:
            alerts.warnings.append(
                f"⚠️ High reversal rate: {reversal_rate:.1f}% (target: ≤{reversal_rate_max}%)"
            )
        
        if total_tx == 0:
            alerts.warnings.append("ℹ️ No transactions in last 24h")
        
        logger.info(
            f"Transaction health: total={total_tx}, success={success_rate:.1f}%, "
            f"reversals={reversal_rate:.1f}%"
        )
        
        return TransactionHealthMetrics(
            period="last_24h",
            timestamp=now.isoformat(),
            transactions=TransactionsMetrics(
                total=total_tx,
                successful=successful_tx,
                failed=failed_tx,
                reversed=reversed_tx,
                success_rate_percent=round(success_rate, 2),
                reversal_rate_percent=round(reversal_rate, 2),
            ),
            slos=SLOs(
                success_rate_target=success_rate_target,
                reversal_rate_max=reversal_rate_max,
                success_rate_ok=success_rate_ok,
                reversal_rate_ok=reversal_rate_ok,
            ),
            alerts=alerts,
        )
    
    except Exception as e:
        logger.error(f"Transaction health metrics error: {e}")
        raise HTTPException(
            status_code=500,
            detail="Failed to calculate transaction health metrics"
        )