# app/services/merchant_experience.py (FINAL PRODUCTION)

from datetime import datetime, timedelta, timezone
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.models.database import Escrow, EscrowStatus
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────
# MODELS
# ─────────────────────────────────────────────────────

class TransactionMetrics(BaseModel):
    """Transaction counts by status"""
    total: int
    released: int
    reversed: int
    expired: int
    pending: int
    success_rate: float

class PerformanceMetrics(BaseModel):
    """Performance indicators"""
    avg_release_seconds: int
    reversal_rate: float
    expiry_rate: float
    slo_met: bool

class HealthScore(BaseModel):
    """Health and category"""
    score: int  # 0-100
    category: str  # Excellent, Healthy, Needs Attention, At Risk
    trend: str  # improving, stable, degrading
    previous_score: Optional[int] = None

class Recommendations(BaseModel):
    """Action items"""
    critical: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    improvements: List[str] = Field(default_factory=list)

class MerchantExperienceScorecard(BaseModel):
    """Complete merchant scorecard"""
    merchant_id: int
    period_days: int
    timestamp: str
    transactions: TransactionMetrics
    performance: PerformanceMetrics
    health: HealthScore
    action_required: bool
    recommendations: Recommendations

# ─────────────────────────────────────────────────────
# SERVICE FUNCTION
# ─────────────────────────────────────────────────────

def calculate_merchant_scorecard(
    db: Session,
    merchant_id: int,
    days: int = 30
) -> MerchantExperienceScorecard:
    """
    Calculate comprehensive merchant experience scorecard.
    
    SLOs:
    - Success rate: >= 95%
    - Avg payout time: < 10 seconds
    - Reversal rate: < 5%
    - Expiry rate: < 3%
    
    Returns health score (0-100) and actionable recommendations.
    """
    
    now = datetime.now(timezone.utc)
    start_time = now - timedelta(days=days)
    
    # ─────────────────────────────────────────────────────
    # TRANSACTION METRICS
    # ─────────────────────────────────────────────────────
    
    total_tx = db.query(func.count(Escrow.id)).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.created_at >= start_time
    ).scalar() or 0
    
    released_tx = db.query(func.count(Escrow.id)).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.status == EscrowStatus.RELEASED,
        Escrow.created_at >= start_time
    ).scalar() or 0
    
    reversed_tx = db.query(func.count(Escrow.id)).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.status == EscrowStatus.REVERSED,
        Escrow.created_at >= start_time
    ).scalar() or 0
    
    expired_tx = db.query(func.count(Escrow.id)).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.status == EscrowStatus.EXPIRED,
        Escrow.created_at >= start_time
    ).scalar() or 0
    
    pending_tx = db.query(func.count(Escrow.id)).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.status == EscrowStatus.HELD,
        Escrow.created_at >= start_time
    ).scalar() or 0
    
    success_rate = (released_tx / total_tx) if total_tx > 0 else 0.0
    reversal_rate = (reversed_tx / total_tx) if total_tx > 0 else 0.0
    expiry_rate = (expired_tx / total_tx) if total_tx > 0 else 0.0
    
    # ─────────────────────────────────────────────────────
    # PAYOUT TIME (True SLO: payment → settlement)
    # ─────────────────────────────────────────────────────
    
    # Preferred: settlement_timestamp - payment_confirmed_time
    true_payout_times = db.query(
        func.extract(
            "epoch",
            Escrow.settlement_timestamp - Escrow.payment_confirmed_time
        )
    ).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.status == EscrowStatus.RELEASED,
        Escrow.settlement_timestamp.isnot(None),
        Escrow.payment_confirmed_time.isnot(None),
        Escrow.created_at >= start_time
    ).all()
    
    valid_payouts = [
        row[0] for row in true_payout_times
        if row[0] is not None and row[0] >= 0
    ]
    
    if valid_payouts:
        avg_payout_seconds = int(
            sum(valid_payouts) / len(valid_payouts)
        )
    else:
        # Fallback: created_at → released_at
        fallback = db.query(
            func.avg(
                func.extract(
                    "epoch",
                    Escrow.released_at - Escrow.created_at
                )
            )
        ).filter(
            Escrow.merchant_id == merchant_id,
            Escrow.status == EscrowStatus.RELEASED,
            Escrow.released_at.isnot(None),
            Escrow.created_at >= start_time
        ).scalar()
        avg_payout_seconds = int(fallback or 0)
    
    # ─────────────────────────────────────────────────────
    # HEALTH SCORE CALCULATION
    # ─────────────────────────────────────────────────────
    
    health_score = 100
    critical_items = []
    warning_items = []
    improvement_items = []
    
    # Success rate (target: 95%)
    if success_rate < 0.90:
        health_score -= 30
        critical_items.append(
            f"Critical: Success rate {success_rate:.1%} - "
            f"major reliability issue"
        )
    elif success_rate < 0.95:
        health_score -= 15
        warning_items.append(
            f"Success rate {success_rate:.1%} - below target 95%"
        )
    else:
        improvement_items.append(
            f"Excellent success rate: {success_rate:.1%}"
        )
    
    # Payout time (target: <10 seconds)
    if avg_payout_seconds > 30:
        health_score -= 35
        critical_items.append(
            f"Critical: Payout takes {avg_payout_seconds}s - "
            f"merchants will churn"
        )
    elif avg_payout_seconds > 10:
        health_score -= 20
        warning_items.append(
            f"Payout time {avg_payout_seconds}s - slow, target <10s"
        )
    else:
        improvement_items.append(
            f"Fast payout: {avg_payout_seconds}s"
        )
    
    # Reversal rate (target: <5%)
    if reversal_rate > 0.10:
        health_score -= 20
        critical_items.append(
            f"Critical: Reversal rate {reversal_rate:.1%} - "
            f"check for fraud or courier issues"
        )
    elif reversal_rate > 0.05:
        health_score -= 10
        warning_items.append(
            f"High reversal rate {reversal_rate:.1%} - above 5%"
        )
    
    # Expiry rate (target: <3%)
    if expiry_rate > 0.10:
        health_score -= 15
        critical_items.append(
            f"Critical: Expiry rate {expiry_rate:.1%} - "
            f"escrows timing out, reversal job issue?"
        )
    elif expiry_rate > 0.03:
        health_score -= 8
        warning_items.append(
            f"High expiry rate {expiry_rate:.1%} - above 3%"
        )
    
    # Volume check
    if total_tx == 0:
        health_score = 50
        warning_items.append("No transactions in period")
    elif total_tx < 5:
        health_score = max(health_score - 20, 0)
        warning_items.append(f"Low volume: only {total_tx} transactions")
    
    health_score = max(0, min(100, health_score))
    
    # ─────────────────────────────────────────────────────
    # CATEGORY & TREND
    # ─────────────────────────────────────────────────────
    
    if health_score >= 90:
        category = "Excellent"
    elif health_score >= 75:
        category = "Healthy"
    elif health_score >= 60:
        category = "Needs Attention"
    else:
        category = "At Risk"
    
    # Trend: compare to previous period
    prev_start = start_time - timedelta(days=days)
    prev_score = _calculate_health_score_for_period(
        db, merchant_id, prev_start, start_time
    ) if days > 0 else health_score
    
    if health_score > prev_score + 5:
        trend = "improving"
    elif health_score < prev_score - 5:
        trend = "degrading"
    else:
        trend = "stable"
    
    # ─────────────────────────────────────────────────────
    # SLO CHECK & ACTION REQUIRED
    # ─────────────────────────────────────────────────────
    
    slo_met = (
        success_rate >= 0.95 and
        avg_payout_seconds < 10 and
        reversal_rate < 0.05 and
        total_tx >= 5
    )
    
    action_required = (
        health_score < 75 or
        bool(critical_items)
    )
    
    logger.info(
        f"Merchant {merchant_id} | Score: {health_score}/100 | "
        f"Category: {category} | Success: {success_rate:.1%} | "
        f"Payout: {avg_payout_seconds}s | Trend: {trend}"
    )
    
    return MerchantExperienceScorecard(
        merchant_id=merchant_id,
        period_days=days,
        timestamp=now.isoformat(),
        transactions=TransactionMetrics(
            total=total_tx,
            released=released_tx,
            reversed=reversed_tx,
            expired=expired_tx,
            pending=pending_tx,
            success_rate=round(success_rate, 3),
        ),
        performance=PerformanceMetrics(
            avg_release_seconds=avg_payout_seconds,
            reversal_rate=round(reversal_rate, 3),
            expiry_rate=round(expiry_rate, 3),
            slo_met=slo_met,
        ),
        health=HealthScore(
            score=health_score,
            category=category,
            trend=trend,
            previous_score=prev_score,
        ),
        action_required=action_required,
        recommendations=Recommendations(
            critical=critical_items,
            warnings=warning_items,
            improvements=improvement_items,
        ),
    )


def _calculate_health_score_for_period(
    db: Session,
    merchant_id: int,
    start_time: datetime,
    end_time: datetime
) -> int:
    """Helper to calculate health score for a specific period."""
    
    total_tx = db.query(func.count(Escrow.id)).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.created_at >= start_time,
        Escrow.created_at < end_time
    ).scalar() or 0
    
    if total_tx == 0:
        return 50
    
    released_tx = db.query(func.count(Escrow.id)).filter(
        Escrow.merchant_id == merchant_id,
        Escrow.status == EscrowStatus.RELEASED,
        Escrow.created_at >= start_time,
        Escrow.created_at < end_time
    ).scalar() or 0
    
    success_rate = (released_tx / total_tx) if total_tx > 0 else 0.0
    
    score = 100
    if success_rate < 0.95:
        score -= 15
    
    return score