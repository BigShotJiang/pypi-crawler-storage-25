# settlement_engine.py
"""
Tofamba — Settlement Engine

Distributes escrow funds to merchant and courier on delivery PIN confirmation.

Fee model (confirmed):
  commission    = gross × 3.5%
  vat           = commission × 15.5%   (VAT on platform fee only)
  receives      = gross - commission - vat   (ROUND_DOWN to 2dp)
  Tofamba absorbs rounding remainder.

  IMTT is NOT in this calculation. EcoCash/InnBucks levy IMTT on wallet-to-wallet
  movements. Tofamba is an observer — it instructs movements
  but never physically holds or passes through IMTT.

Entry point: settle_order_on_pin_verified(db, order_id, courier_phone)
Triggered by: _handle_pin_entry() in whatsapp_bot.py via release_escrow_on_pin()
"""

import logging
from datetime import datetime, timezone
from decimal import ROUND_DOWN, Decimal
from typing import Dict, Tuple

from sqlalchemy.orm import Session

from app.models.database import Escrow, EscrowStatus, Merchant
from services.payment_provider import send_payment

# ── Stub models — not yet in schema, settlement engine is forward-designed ─────
# These stubs make the module importable.  When the full data model lands,
# replace each stub with the real ORM class from app.models.database.

class _Courier:  # noqa
    phone = None; wallet_address = None; commission_rate = None; whatsapp_id = None; name = None
class _Order:    # noqa
    escrow = None; item_price = None; delivery_fee_total = None; status = None; completed_at = None
class _PaymentSplit:  # noqa
    id = None; merchant_tx_id = None; courier_tx_id = None; status = None; processed_at = None
class _PaymentSplitStatus:  # noqa
    PROCESSING = "processing"; COMPLETED = "completed"; FAILED = "failed"
class _VATAccrual:  # noqa
    id = None
class _VATStatus:  # noqa
    ACCRUED = "accrued"
class _AnchorFlow:  # noqa
    id = None

Courier          = _Courier
Order            = _Order
PaymentSplit     = _PaymentSplit
PaymentSplitStatus = _PaymentSplitStatus
VATAccrual       = _VATAccrual
VATStatus        = _VATStatus
AnchorFlow       = _AnchorFlow


def notify_delivery_completed(*args, **kwargs) -> None:  # noqa
    """Stub — replaced when whatsapp_bot notification helpers are importable."""


def notify_merchant_settled(*args, **kwargs) -> None:  # noqa
    """Stub — replaced when whatsapp_bot notification helpers are importable."""

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────

class SettlementConfig:
    PLATFORM_FEE_RATE = Decimal("0.035")   # 3.5%
    VAT_RATE          = Decimal("0.155")   # 15.5% on platform fee only
    TWO_DP            = Decimal("0.01")    # quantize target for ROUND_DOWN
    FOUR_DP           = Decimal("0.0001")  # for rounding_absorbed storage


# ─────────────────────────────────────────────────────────────
# PAYMENT CALCULATOR
# ─────────────────────────────────────────────────────────────

class PaymentCalculator:
    """
    Pure calculation — no DB access, no side effects.
    All inputs and outputs are Decimal.

    Example ($25.00 item + $3.50 delivery):

      MERCHANT:
        commission    = $25.00 × 0.035         = $0.875000
        vat           = $0.875000 × 0.155      = $0.135625
        total_charges = $0.875000 + $0.135625  = $1.010625
        receives      = $25.00 - $1.010625     = $23.989375  → ROUND_DOWN → $23.98

      COURIER:
        commission    = $3.50 × 0.035          = $0.122500
        vat           = $0.122500 × 0.155      = $0.018988
        total_charges = $0.122500 + $0.018988  = $0.141488
        receives      = $3.50 - $0.141488      = $3.358512   → ROUND_DOWN → $3.35

      TOFAMBA:
        total_commission  = $0.875000 + $0.122500 = $0.997500
        total_vat         = $0.135625 + $0.018988 = $0.154613
        distributed       = $23.98 + $3.35 + $0.997500 + $0.154613 = $28.482113
        rounding_absorbed = $28.50 - $28.482113 = $0.017887  ← Tofamba absorbs

      VERIFICATION: $23.98 + $3.35 + $0.9975 + $0.1546 + $0.0179 = $28.50 ✓
    """

    @staticmethod
    def calculate(
        merchant_gross: Decimal,
        courier_gross: Decimal,
        merchant_rate: Decimal = SettlementConfig.PLATFORM_FEE_RATE,
        courier_rate: Decimal  = SettlementConfig.PLATFORM_FEE_RATE,
    ) -> Dict[str, Decimal]:
        """
        Calculate full payment split.

        Args:
            merchant_gross: Item price (what customer paid for item)
            courier_gross:  Delivery fee (what customer paid for delivery)
            merchant_rate:  Platform fee % for merchant (default 3.5%)
            courier_rate:   Platform fee % for courier  (default 3.5%)

        Returns:
            Dict with all split amounts. All values are Decimal.
            merchant_receives and courier_receives are ROUND_DOWN to 2dp.
            tandem_rounding_absorbed is the remainder (4dp precision).
        """
        # Sanitise to Decimal — reject floats silently passed in
        merchant_gross = Decimal(str(merchant_gross))
        courier_gross  = Decimal(str(courier_gross))
        merchant_rate  = Decimal(str(merchant_rate))
        courier_rate   = Decimal(str(courier_rate))

        vat = SettlementConfig.VAT_RATE
        two_dp  = SettlementConfig.TWO_DP
        four_dp = SettlementConfig.FOUR_DP

        # ── Merchant ──────────────────────────────────────────
        m_commission    = merchant_gross * merchant_rate
        m_vat           = m_commission * vat
        m_total_charges = m_commission + m_vat
        m_receives_exact = merchant_gross - m_total_charges
        m_receives      = m_receives_exact.quantize(two_dp, rounding=ROUND_DOWN)

        # ── Courier ───────────────────────────────────────────
        c_commission    = courier_gross * courier_rate
        c_vat           = c_commission * vat
        c_total_charges = c_commission + c_vat
        c_receives_exact = courier_gross - c_total_charges
        c_receives      = c_receives_exact.quantize(two_dp, rounding=ROUND_DOWN)

        # ── Tofamba accounting ────────────────────────────────
        total_commission = m_commission + c_commission
        total_vat        = m_vat + c_vat
        customer_total    = merchant_gross + courier_gross
        # Exact remainder — used for reconciliation check (full precision)
        rounding_absorbed = customer_total - (
            m_receives + c_receives + total_commission + total_vat
        )

        # ── Sanity check — must balance to the cent ───────────
        reconciled = m_receives + c_receives + total_commission + total_vat + rounding_absorbed
        if reconciled != customer_total:
            raise ValueError(
                f"Settlement reconciliation failed: "
                f"distributed={reconciled} != customer_paid={customer_total}"
            )

        return {
            # Merchant
            "merchant_gross":         merchant_gross,
            "merchant_commission":    m_commission.quantize(four_dp),
            "merchant_vat":           m_vat.quantize(four_dp),
            "merchant_total_charges": m_total_charges.quantize(four_dp),
            "merchant_receives":      m_receives,

            # Courier
            "courier_gross":          courier_gross,
            "courier_commission":     c_commission.quantize(four_dp),
            "courier_vat":            c_vat.quantize(four_dp),
            "courier_total_charges":  c_total_charges.quantize(four_dp),
            "courier_receives":       c_receives,

            # Tofamba
            "tandem_commission_merchant": m_commission.quantize(four_dp),
            "tandem_commission_courier":  c_commission.quantize(four_dp),
            "tandem_total_commission":    total_commission.quantize(four_dp),
            "tandem_total_vat":           total_vat.quantize(four_dp),
            "tandem_rounding_absorbed":   rounding_absorbed.quantize(four_dp),
        }


# ─────────────────────────────────────────────────────────────
# SETTLEMENT ENGINE
# ─────────────────────────────────────────────────────────────

class SettlementEngine:
    """
    Orchestrates the full settlement flow after PIN verification:

    1. Validate escrow is in DELIVERY_IN_PROGRESS
    2. Calculate payment split
    3. Mark escrow RELEASED (before payment provider calls — audit safety)
    4. Persist PaymentSplit record
    5. Send merchant payout via payment provider
    6. Send courier payout via payment provider
    7. Accrue VAT for ZIMRA monthly filing
    8. Write AnchorFlow immutable audit record
    9. Commit everything
    10. Send WhatsApp notifications (best-effort, after commit)
    """

    def __init__(self, db: Session):
        self.db = db

    def settle(self, order_id: str) -> Tuple[bool, str, Decimal]:
        """
        Execute settlement for a completed order.

        Returns:
            (success, message, merchant_receives)
            merchant_receives is Decimal("0") on failure.
        """
        logger.info(f"Settlement start | order={order_id}")

        try:
            # ── 1. Load & validate ────────────────────────────
            order = self.db.get(Order, order_id)
            if not order:
                return False, f"Order not found: {order_id}", Decimal("0")

            escrow = order.escrow
            if not escrow:
                return False, f"No escrow for order: {order_id}", Decimal("0")

            if escrow.status != EscrowStatus.DELIVERY_IN_PROGRESS.value:
                return (
                    False,
                    f"Escrow not in DELIVERY_IN_PROGRESS (is: {escrow.status})",
                    Decimal("0"),
                )

            merchant = self.db.get(Merchant, escrow.merchant_id)
            courier  = self.db.get(Courier,  escrow.courier_id) if escrow.courier_id else None

            if not merchant:
                return False, f"Merchant not found: {escrow.merchant_id}", Decimal("0")

            # ── 2. Calculate split ────────────────────────────
            merchant_gross = Decimal(str(order.item_price))
            courier_gross  = Decimal(str(order.delivery_fee_total))

            merchant_rate = Decimal(str(merchant.commission_rate or SettlementConfig.PLATFORM_FEE_RATE))
            courier_rate  = Decimal(str(courier.commission_rate  if courier else SettlementConfig.PLATFORM_FEE_RATE))

            split = PaymentCalculator.calculate(
                merchant_gross, courier_gross, merchant_rate, courier_rate
            )

            logger.info(
                f"Split calculated | merchant_receives={split['merchant_receives']} "
                f"courier_receives={split['courier_receives']} "
                f"tandem_commission={split['tandem_total_commission']} "
                f"vat={split['tandem_total_vat']} "
                f"rounding={split['tandem_rounding_absorbed']}"
            )

            # ── 3. Mark escrow RELEASED before external calls ─
            # Written to DB before payment provider calls — if process dies
            # mid-flight, reconciliation can detect the incomplete state.
            escrow.status     = EscrowStatus.RELEASED.value
            escrow.released_at = _utcnow()
            self.db.flush()

            # ── 4. Persist PaymentSplit ───────────────────────
            payment_split = PaymentSplit(
                order_id=order_id,
                status=PaymentSplitStatus.PROCESSING,

                merchant_gross         = split["merchant_gross"],
                merchant_commission    = split["merchant_commission"],
                merchant_vat           = split["merchant_vat"],
                merchant_total_charges = split["merchant_total_charges"],
                merchant_receives      = split["merchant_receives"],

                courier_gross         = split["courier_gross"],
                courier_commission    = split["courier_commission"],
                courier_vat           = split["courier_vat"],
                courier_total_charges = split["courier_total_charges"],
                courier_receives      = split["courier_receives"],

                tandem_commission_merchant = split["tandem_commission_merchant"],
                tandem_commission_courier  = split["tandem_commission_courier"],
                tandem_total_commission    = split["tandem_total_commission"],
                tandem_total_vat           = split["tandem_total_vat"],
                tandem_rounding_absorbed   = split["tandem_rounding_absorbed"],
            )
            self.db.add(payment_split)
            self.db.flush()

            # ── 5. Pay merchant ───────────────────────────────
            merchant_success, merchant_tx_id = send_payment(
                wallet_address=merchant.wallet_address,
                amount=split["merchant_receives"],
                reference=f"TOFAMBA-M-{order_id}",
            )
            if not merchant_success:
                # Roll back escrow status — payment not sent
                escrow.status = EscrowStatus.DELIVERY_IN_PROGRESS.value
                self.db.rollback()
                return False, f"Merchant payment failed for order {order_id}", Decimal("0")

            payment_split.merchant_tx_id = merchant_tx_id

            # ── 6. Pay courier ────────────────────────────────
            if courier and courier.wallet_address:
                courier_success, courier_tx_id = send_payment(
                    wallet_address=courier.wallet_address,
                    amount=split["courier_receives"],
                    reference=f"TOFAMBA-C-{order_id}",
                )
                if not courier_success:
                    logger.error(
                        f"Courier payment failed for order {order_id} — "
                        f"merchant already paid. Manual courier payout needed."
                    )
                    # Merchant already paid — don't rollback. Flag for manual ops.
                    payment_split.status = PaymentSplitStatus.FAILED
                    self._write_anchor(
                        escrow_id=str(escrow.id),
                        order_id=order_id,
                        action="COURIER_PAYMENT_FAILED",
                        reason="Payment provider rejected courier payout",
                        split=split,
                    )
                    self.db.commit()
                    return False, f"Courier payment failed — ops alerted", Decimal("0")

                payment_split.courier_tx_id = courier_tx_id

            # ── 7. Accrue VAT for ZIMRA ───────────────────────
            now = _utcnow()
            vat_accrual = VATAccrual(
                order_id         = order_id,
                payment_split_id = payment_split.id,
                tandem_commission = split["tandem_total_commission"],
                vat_amount        = split["tandem_total_vat"],
                month  = now.month,
                year   = now.year,
                status = VATStatus.ACCRUED,
            )
            self.db.add(vat_accrual)

            # ── 8. AnchorFlow audit record ────────────────────
            self._write_anchor(
                escrow_id=str(escrow.id),
                order_id=order_id,
                action="FINANCIAL_HANDSHAKE_COMPLETE",
                reason="PIN_VERIFIED",
                split=split,
                extra={
                    "merchant_tx_id": merchant_tx_id,
                    "courier_tx_id":  courier_tx_id if courier else None,
                    "vat_accrual_id": str(vat_accrual.id),
                },
            )

            # ── 9. Mark split complete and commit ─────────────
            payment_split.status       = PaymentSplitStatus.COMPLETED
            payment_split.processed_at = _utcnow()
            order.status               = "completed"
            order.completed_at         = _utcnow()

            self.db.commit()
            logger.info(f"Settlement committed | order={order_id}")

            # ── 10. Notifications (best-effort, after commit) ─
            self._notify(merchant, courier, split, order_id)

            return True, "Settlement complete", split["merchant_receives"]

        except ValueError as exc:
            # Raised by PaymentCalculator if reconciliation fails
            logger.critical(f"Settlement calculation error | order={order_id}: {exc}")
            self.db.rollback()
            return False, str(exc), Decimal("0")

        except Exception as exc:
            logger.error(f"Settlement exception | order={order_id}: {exc}", exc_info=True)
            self.db.rollback()
            return False, f"Exception: {exc}", Decimal("0")

    # ── Private helpers ───────────────────────────────────────

    def _write_anchor(
        self,
        escrow_id: str,
        order_id: str,
        action: str,
        reason: str,
        split: Dict,
        extra: Dict = None,
    ) -> None:
        """Write an immutable AnchorFlow audit record."""
        data = {
            "merchant_receives":      str(split.get("merchant_receives", "")),
            "courier_receives":       str(split.get("courier_receives", "")),
            "tandem_commission":      str(split.get("tandem_total_commission", "")),
            "tandem_vat":             str(split.get("tandem_total_vat", "")),
            "tandem_rounding":        str(split.get("tandem_rounding_absorbed", "")),
        }
        if extra:
            data.update(extra)

        anchor = AnchorFlow(
            transaction_id = order_id,
            escrow_id      = escrow_id,
            action         = action,
            reason         = reason,
            data           = data,
            timestamp      = _utcnow(),
        )
        self.db.add(anchor)

    def _notify(
        self,
        merchant: Merchant,
        courier,
        split: Dict,
        order_id: str,
    ) -> None:
        """Best-effort WhatsApp notifications — never raises."""
        try:
            if merchant.whatsapp_id:
                notify_merchant_settled(
                    merchant.whatsapp_id,
                    merchant.name,
                    str(split["merchant_receives"]),
                )
        except Exception as exc:
            logger.error(f"Merchant notification failed order={order_id}: {exc}")

        try:
            if courier and courier.whatsapp_id:
                notify_delivery_completed(
                    courier.whatsapp_id,
                    courier.name,
                    str(split["courier_receives"]),
                )
        except Exception as exc:
            logger.error(f"Courier notification failed order={order_id}: {exc}")


# ─────────────────────────────────────────────────────────────
# PUBLIC ENTRY POINT
# ─────────────────────────────────────────────────────────────

def settle_order_on_pin_verified(db: Session, order_id: str) -> Decimal:
    """
    Called by release_escrow_on_pin() after PIN is confirmed.

    Returns merchant_receives amount (Decimal) for display in PIN success message.
    Returns Decimal("0") on any failure — caller should handle gracefully.
    """
    engine = SettlementEngine(db)
    success, message, merchant_receives = engine.settle(order_id)

    if not success:
        logger.error(f"Settlement failed | order={order_id}: {message}")

    return merchant_receives


# ─────────────────────────────────────────────────────────────
# UTILITY
# ─────────────────────────────────────────────────────────────

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)
