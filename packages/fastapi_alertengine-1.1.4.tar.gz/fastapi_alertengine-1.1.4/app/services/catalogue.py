# app/services/catalogue.py
"""
Catalogue service for AnchorFlow.

Handles merchant product listings and deal creation via the REST API.
All functions are async and fail gracefully — callers receive empty list
or None on any error rather than an exception.
"""

import logging
from typing import Optional

import httpx

from config import settings

logger = logging.getLogger(__name__)

_TIMEOUT = 10  # seconds for all catalogue API calls


async def fetch_catalogue(merchant_phone: str) -> list:
    """
    Fetch a merchant's product catalogue.

    Calls: GET {base_url}/catalogue/{merchant_phone}

    Returns a list of product dicts (keys: name, price, description, etc.)
    or an empty list on any failure (timeout, 4xx, 5xx, bad JSON).
    """
    url = f"{settings.base_url}/catalogue/{merchant_phone}"
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            data = resp.json()
            return data if isinstance(data, list) else []
    except httpx.TimeoutException:
        logger.error("Timeout fetching catalogue")
        return []
    except httpx.HTTPStatusError as exc:
        logger.error(f"HTTP {exc.response.status_code} fetching catalogue")
        return []
    except Exception as exc:
        logger.error(f"Unexpected error fetching catalogue: {exc}")
        return []


async def create_deal(
    seller_name: str,
    item_description: str,
    price: float,
    wallet_phone: str,
) -> Optional[dict]:
    """
    Create a protected deal link.

    Calls: POST {base_url}/deals

    Returns dict with keys:
        deal_id             str
        share_url           str   — payment link to share with buyer
        payment_reference   str   — reference for reconciliation

    Returns None on any failure.
    """
    url = f"{settings.base_url}/deals"
    payload = {
        "seller_name": seller_name,
        "item_description": item_description,
        "price": price,
        "wallet_phone": wallet_phone,
    }
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return {
                "deal_id":           data.get("deal_id"),
                "share_url":         data.get("share_url"),
                "payment_reference": data.get("payment_reference"),
            }
    except httpx.TimeoutException:
        logger.error("Timeout creating deal")
        return None
    except httpx.HTTPStatusError as exc:
        logger.error(f"HTTP {exc.response.status_code} creating deal")
        return None
    except Exception as exc:
        logger.error(f"Unexpected error creating deal: {exc}")
        return None
