"""
app/services/dual_write.py

Dual-write helper: PostgreSQL first, Redis second.

Execution contract:
1. Execute db_operation_fn() — must include db.commit()
2. Write to Redis (best-effort)
3. Redis failure → DO NOT rollback DB → log and continue

PostgreSQL is the source of truth.
Redis is acceleration / locking only.
"""

import logging
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


def dual_write(
    db_operation_fn: Callable[[], Any],
    redis_client=None,
    redis_key: Optional[str] = None,
    redis_value: Optional[str] = None,
    redis_ttl: Optional[int] = None,
) -> Any:
    """
    Execute a DB operation then optionally write a Redis key.

    Args:
        db_operation_fn: Callable that performs the DB work AND commits.
                         Its return value is forwarded to the caller.
        redis_client:    Redis client (optional — pass None to skip Redis).
        redis_key:       Redis key to write after DB commit.
        redis_value:     Value to store.
        redis_ttl:       TTL in seconds (uses setex if provided, set otherwise).

    Returns:
        The return value of db_operation_fn().
    """
    # ── 1. DB first (authoritative) ──────────────────────────────────────────
    result = db_operation_fn()

    # ── 2. Redis second (best-effort) ────────────────────────────────────────
    if redis_client and redis_key is not None and redis_value is not None:
        try:
            if redis_ttl:
                redis_client.setex(redis_key, redis_ttl, redis_value)
            else:
                redis_client.set(redis_key, redis_value)
        except Exception as exc:
            # Redis failure must NOT roll back the committed DB transaction.
            logger.error(
                "[DualWrite] Redis write failed for key=%s: %s — DB already committed.",
                redis_key, exc,
            )

    return result
