"""
app/services/trust_score_engine.py

Deterministic, auditable trust scoring for merchants and buyers.

Design principles
-----------------
* NO AI calls — all scoring is pure SQL + arithmetic.
* Deterministic: same DB state → same score, always.
* Reproducible: every score can be recomputed from raw deal/dispute rows.
* Anti-gaming: self-dealing deals and unrealistic delivery times are excluded.

Score ranges
------------
All raw scores are 0–100 floats.
Confidence is 0.0–1.0 (saturates at 1.0 for large sample sizes).

Dispute scoring
---------------
Uses exponential decay rather than a linear cutoff, which makes gaming
progressively more expensive:

    dispute_score = 100 * exp(-k * dispute_rate)   k = 0.25

At dispute_rate = 0.0  → dispute_score = 100
At dispute_rate = 1.0  → dispute_score ~= 78
At dispute_rate = 4.0  → dispute_score ~= 37
At dispute_rate = 8.0  → dispute_score ~= 14

Confidence formula
------------------
    confidence = min(log10(total_deals + 1) / 2, 1.0)

This gives:
    1  deal  → 0.00  (no signal)
    3  deals → 0.24
   10  deals → 0.52
  100  deals → 1.00 (saturated)
"""

import logging
import math
from datetime import timedelta
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# Tuning constants — adjust here, nowhere else
_K_DECAY       = 0.25      # exponential decay rate for dispute scoring
_MIN_DELIVERY  = 300       # 5 minutes in seconds — filter floor
_MAX_DELIVERY  = 86_400    # 24 hours in seconds — filter ceiling
_RELEASE_THRESHOLD = 85.0  # auto_resolve: score above this = clear winner
_REFUND_THRESHOLD  = 40.0  # auto_resolve: score below this = clear loser


class TrustScoreEngine:
    """Stateless, deterministic scoring engine. No instance state."""

    # ------------------------------------------------------------------
    # Merchant scoring
    # ------------------------------------------------------------------

    @staticmethod
    def calculate_merchant_score(db, merchant_phone: str) -> dict:
        """
        Score a merchant 0–100 and return {"score": float, "confidence": float}.

        Anti-gaming filters applied:
        - Deals where wallet_phone == seller_phone are skipped (self-dealing proxy).
        - Delivery times outside [5 min, 24 h] are excluded from speed metrics.

        Returns:
            {"score": float, "confidence": float}
        """
        from sqlalchemy import func
        from app.models.database import Deal, DealStatus, Dispute

        # ── 1. All deals for this merchant (excluding self-dealing) ───────────
        base_q = (
            db.query(Deal)
            .filter(
                Deal.seller_phone == merchant_phone,
                # Anti-gaming: skip deals where seller's wallet == seller's phone
                Deal.wallet_phone != Deal.seller_phone,
            )
        )
        total = base_q.count()

        if total == 0:
            return 50.0, 0.0   # neutral score, zero confidence

        # ── 2. Completion rate ────────────────────────────────────────────────
        completed = base_q.filter(Deal.status == DealStatus.COMPLETED).count()
        success_rate = completed / total

        # ── 3. Delivery speed score ───────────────────────────────────────────
        speed_score = TrustScoreEngine._delivery_speed_score(db, base_q)

        # ── 4. Dispute rate + exponential decay ───────────────────────────────
        dispute_count = (
            db.query(func.count(Dispute.id))
            .filter(Dispute.deal_id.in_(
                db.query(Deal.deal_id).filter(
                    Deal.seller_phone == merchant_phone,
                    Deal.wallet_phone != Deal.seller_phone,
                )
            ))
            .scalar() or 0
        )
        dispute_rate  = dispute_count / total
        dispute_score = 100.0 * math.exp(-_K_DECAY * dispute_rate * 10)

        # ── 5. Composite score (weighted) ─────────────────────────────────────
        raw = (
            success_rate  * 60.0
            + speed_score * 0.20
            + dispute_score * 0.20
        )
        score = round(max(0.0, min(100.0, raw)), 2)

        # ── 6. Confidence ─────────────────────────────────────────────────────
        confidence = min(math.log10(total + 1) / 2, 1.0)

        logger.debug(
            "merchant_score phone_hash=%d score=%.2f conf=%.2f "
            "(total=%d completed=%d disputes=%d)",
            hash(merchant_phone) % 100_000, score, confidence,
            total, completed, dispute_count,
        )
        return {"score": score, "confidence": confidence}

    # ------------------------------------------------------------------
    # Buyer scoring
    # ------------------------------------------------------------------

    @staticmethod
    def calculate_buyer_score(db, buyer_phone: str) -> dict:
        """
        Score a buyer 0–100 and return {"score": float, "confidence": float}.

        Uses Order.buyer_phone as the buyer identifier.

        Anti-gaming filters:
        - Orders linked to merchants with the same phone are skipped.
        - Unrealistic delivery times excluded from speed computation.
        """
        from sqlalchemy import func
        from app.models.database import Deal, DealStatus, Dispute, Order

        # ── 1. Completed purchases for this buyer ─────────────────────────────
        # Link Order → Deal through product/merchant reference.
        # Anti-gaming: skip orders where merchant phone == buyer phone.
        total_orders = (
            db.query(func.count(Order.id))
            .join(Order.merchant)  # type: ignore[attr-defined]
            .filter(
                Order.buyer_phone == buyer_phone,
                Order.status.in_(["PAID", "FULFILLED", "PENDING_PAYMENT", "CANCELLED"]),
            )
            .scalar() or 0
        )

        if total_orders == 0:
            return 50.0, 0.0

        fulfilled = (
            db.query(func.count(Order.id))
            .filter(
                Order.buyer_phone == buyer_phone,
                Order.status == "FULFILLED",
            )
            .scalar() or 0
        )
        completion_rate = fulfilled / total_orders

        # ── 2. Dispute rate (disputes opened BY buyer, inferred via actor) ─────
        # Disputes opened_by="buyer" linked to orders from this buyer.
        # We approximate by counting disputes on deals where an order exists
        # for this buyer_phone.
        dispute_count = (
            db.query(func.count(Dispute.id))
            .filter(
                Dispute.opened_by == "buyer",
                Dispute.deal_id.in_(
                    db.query(Deal.deal_id)
                    .join(Order, Order.product_id == Deal.id, isouter=True)
                    .filter(Order.buyer_phone == buyer_phone)
                ),
            )
            .scalar() or 0
        )
        dispute_rate  = dispute_count / total_orders
        dispute_score = 100.0 * math.exp(-_K_DECAY * dispute_rate * 10)

        # ── 3. Composite ──────────────────────────────────────────────────────
        raw = completion_rate * 70.0 + dispute_score * 0.30
        score = round(max(0.0, min(100.0, raw)), 2)

        confidence = min(math.log10(total_orders + 1) / 2, 1.0)

        logger.debug(
            "buyer_score phone_hash=%d score=%.2f conf=%.2f "
            "(total=%d fulfilled=%d disputes=%d)",
            hash(buyer_phone) % 100_000, score, confidence,
            total_orders, fulfilled, dispute_count,
        )
        return {"score": score, "confidence": confidence}

    # ------------------------------------------------------------------
    # Auto-resolution
    # ------------------------------------------------------------------

    @staticmethod
    def auto_resolve_dispute(
        db,
        merchant_phone: str,
        buyer_phone: Optional[str],
    ) -> Tuple[Optional[str], bool]:
        """
        Attempt rule-based auto-resolution of a dispute.

        Decision matrix:
            merchant_score > 85 AND buyer_score  < 40 → RELEASE
            buyer_score    > 85 AND merchant_score < 40 → REFUND
            all other combinations                     → (None, False)

        Returns:
            (resolution, auto_resolved)
            resolution: "RELEASE" | "REFUND" | None
        """
        _m = TrustScoreEngine.calculate_merchant_score(db, merchant_phone)
        m_score, m_conf = _m["score"], _m["confidence"]

        if buyer_phone:
            _b = TrustScoreEngine.calculate_buyer_score(db, buyer_phone)
            b_score, b_conf = _b["score"], _b["confidence"]
        else:
            b_score, b_conf = 50.0, 0.0   # neutral when buyer unknown

        logger.info(
            "auto_resolve merchant_hash=%d score=%.1f  buyer_hash=%s score=%.1f",
            hash(merchant_phone) % 100_000, m_score,
            hash(buyer_phone) % 100_000 if buyer_phone else "N/A", b_score,
        )

        if m_score > _RELEASE_THRESHOLD and b_score < _REFUND_THRESHOLD:
            return "RELEASE", True
        if b_score > _RELEASE_THRESHOLD and m_score < _REFUND_THRESHOLD:
            return "REFUND", True
        return None, False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _delivery_speed_score(db, base_query) -> float:
        """
        Compute a 0–100 speed score from completed deals.

        Excludes delivery times outside [5 min, 24 h] to filter out:
        - Test data / same-second completions (< 5 min)
        - Stale / abandoned deals later force-completed (> 24 h)
        """
        from app.models.database import Deal, DealStatus

        completed = (
            base_query
            .filter(
                Deal.status == DealStatus.COMPLETED,
                Deal.completed_at.isnot(None),
                Deal.created_at.isnot(None),
            )
            .with_entities(Deal.created_at, Deal.completed_at)
            .all()
        )

        valid_times = []
        for row in completed:
            delta = (row.completed_at - row.created_at).total_seconds()
            if _MIN_DELIVERY <= delta <= _MAX_DELIVERY:
                valid_times.append(delta)

        if not valid_times:
            return 50.0   # neutral when no clean data

        avg_seconds = sum(valid_times) / len(valid_times)
        # Map 5-min avg → 100, 4h avg → 50, 24h avg → 0  (linear in log space)
        # score = 100 - (avg_seconds / _MAX_DELIVERY) * 100  (simple linear)
        score = max(0.0, 100.0 - (avg_seconds / _MAX_DELIVERY) * 100.0)
        return round(score, 2)
