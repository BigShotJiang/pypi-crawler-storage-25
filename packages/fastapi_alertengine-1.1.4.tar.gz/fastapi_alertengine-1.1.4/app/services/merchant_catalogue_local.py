# app/services/merchant_catalogue_local.py
"""
Redis-backed local catalogue for self-registered merchants.

Supplements the external HTTP catalogue (app/services/catalogue.py) —
that module is never modified.

Products are stored in Redis for fast WhatsApp-bot access AND mirrored
to MerchantInventory in the DB for inventory tracking and deal linking.

Redis key layout:
    merchant_catalogue:{merchant_slug}  →  JSON list of product dicts

Each product dict:
    {
        "sku":         str,   # SKU-XXXXXXXX
        "name":        str,
        "price":       float,
        "description": str,
        "created_at":  ISO-8601 str,
    }
"""

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

_CATALOGUE_TTL = 30 * 24 * 3600   # 30 days


# ─── KEY HELPER ───────────────────────────────────────────────────────────────

def _catalogue_key(merchant_slug: str) -> str:
    return f"merchant_catalogue:{merchant_slug}"


# ─── WRITE ────────────────────────────────────────────────────────────────────

def add_product(
    rdb,
    db,
    merchant_phone: str,
    merchant_slug: str,
    name: str,
    price: float,
    description: str = "",
) -> dict:
    """
    Add a product to:
      1. Redis — fast catalogue lookup by slug
      2. MerchantInventory DB — for inventory tracking

    Returns the new product dict.
    """
    sku = f"SKU-{uuid.uuid4().hex[:8].upper()}"
    product = {
        "sku":         sku,
        "name":        name,
        "price":       price,
        "description": description,
        "created_at":  datetime.now(timezone.utc).isoformat(),
    }

    # ── Redis ──────────────────────────────────────────────────────────────
    key = _catalogue_key(merchant_slug)
    raw = rdb.get(key)
    items: list = json.loads(raw) if raw else []
    items.append(product)
    rdb.setex(key, _CATALOGUE_TTL, json.dumps(items))

    # ── MerchantInventory DB ───────────────────────────────────────────────
    try:
        from app.models.database import MerchantInventory
        inv = MerchantInventory(
            merchant_phone     = merchant_phone,
            sku                = sku,
            item_name          = name,
            item_description   = description or None,
            price              = price,
            quantity_available = 999,   # Unlimited for self-registered by default
            created_at         = datetime.now(timezone.utc),
        )
        db.add(inv)
        db.commit()
        logger.info(f"Product added to DB: sku={sku}, merchant={merchant_phone}")
    except Exception as exc:
        logger.error(f"MerchantInventory mirror failed for {merchant_phone}: {exc}")
        # Redis write succeeded — catalogue is still functional

    return product


def remove_product(rdb, merchant_slug: str, sku: str) -> bool:
    """
    Remove a product by SKU from the Redis catalogue.
    Returns True if found and removed, False if not found.
    """
    key = _catalogue_key(merchant_slug)
    raw = rdb.get(key)
    if not raw:
        return False
    items: list = json.loads(raw)
    new_items = [p for p in items if p.get("sku") != sku]
    if len(new_items) == len(items):
        return False
    rdb.setex(key, _CATALOGUE_TTL, json.dumps(new_items))
    return True


# ─── READ ─────────────────────────────────────────────────────────────────────

def get_catalogue(rdb, merchant_slug: str) -> list:
    """Return the product list for merchant_slug from Redis. Empty list if none."""
    raw = rdb.get(_catalogue_key(merchant_slug))
    if not raw:
        return []
    try:
        return json.loads(raw)
    except Exception:
        return []


def get_product_count(rdb, merchant_slug: str) -> int:
    """How many products does this merchant have in their local catalogue?"""
    return len(get_catalogue(rdb, merchant_slug))


def format_catalogue_text(catalogue: list, merchant_name: str = "") -> str:
    """
    Format a catalogue list as a numbered WhatsApp message.
    Example:
        Johns Store:
        1. Bread - $1.50
        2. Butter - $2.00
    """
    if not catalogue:
        return "No products listed yet."
    header = f"{merchant_name} products:\n\n" if merchant_name else "Products:\n\n"
    lines = [
        f"{i + 1}. {p.get('name', '?')} - ${p.get('price', 0)}"
        for i, p in enumerate(catalogue[:10])
    ]
    return header + "\n".join(lines) + "\n\nReply with a number to select."


# ─── PAGINATION ───────────────────────────────────────────────────────────────

def get_catalogue_page(
    rdb,
    merchant_slug: str,
    page: int = 1,
    page_size: int = 10,
) -> dict:
    """
    Return a paginated slice of the merchant catalogue.

    Args:
        rdb:           Redis client.
        merchant_slug: Merchant slug identifier.
        page:          1-indexed page number.
        page_size:     Items per page (1–100).

    Returns:
        {
            "items":       list,
            "total":       int,
            "page":        int,
            "total_pages": int,
            "has_next":    bool,
        }
    """
    page      = max(1, page)
    page_size = max(1, min(100, page_size))

    items = get_catalogue(rdb, merchant_slug)
    total = len(items)
    total_pages = max(1, (total + page_size - 1) // page_size)
    start = (page - 1) * page_size
    end   = start + page_size
    return {
        "items":       items[start:end],
        "total":       total,
        "page":        page,
        "total_pages": total_pages,
        "has_next":    end < total,
    }


def warm_catalogue_cache(rdb, db, merchant_phone: str, merchant_slug: str) -> int:
    """
    Load MerchantInventory rows from the DB into the Redis catalogue cache.

    Useful on cold starts or after cache expiry.  Overwrites the existing
    Redis cache for this slug.

    Args:
        rdb:            Redis client.
        db:             SQLAlchemy Session.
        merchant_phone: Merchant phone used as DB filter key.
        merchant_slug:  Slug for the Redis cache key.

    Returns:
        Number of items loaded into cache (0 if DB query fails or is empty).
    """
    from app.core.idempotency import TTL_CATALOGUE
    try:
        from app.models.database import MerchantInventory
        rows = (
            db.query(MerchantInventory)
            .filter(MerchantInventory.merchant_phone == merchant_phone)
            .order_by(MerchantInventory.created_at)
            .all()
        )
        products = [
            {
                "sku":         row.sku,
                "name":        row.item_name,
                "price":       float(row.price),
                "description": row.item_description or "",
                "created_at":  row.created_at.isoformat() if row.created_at else "",
            }
            for row in rows
        ]
        if products:
            rdb.setex(_catalogue_key(merchant_slug), TTL_CATALOGUE, json.dumps(products))
        logger.info("warm_catalogue_cache: loaded %d products for %s", len(products), merchant_slug)
        return len(products)
    except Exception as exc:
        logger.error("warm_catalogue_cache failed for %s: %s", merchant_slug, exc)
        return 0
