"""
app/services/order_service.py

Order lifecycle for Tofamba Buyer Flow V1.

Non-custodial design constraints
---------------------------------
- Tofamba NEVER holds or moves funds.
- An Order is purely a payment INSTRUCTION.
- The buyer sends money directly to the merchant's mobile wallet using the
  reference_code as the transaction reference.
- mark_order_paid() must be called externally (manual confirmation or an
  external webhook observer) — never auto-called here.

Public API
----------
create_order(...)         — create PENDING_PAYMENT order (idempotent)
mark_order_paid(...)      — transition → PAID, reduce stock (idempotent)
cancel_order(...)         — transition → CANCELLED (idempotent)
get_total_stock(...)      — sum of active free variant stock or product stock
mark_product_unavailable  — set quantity_available=0 when total_stock==0
generate_reference_code() — human-readable "TDM-XXXX-XXXX" (public helper)
"""

import uuid
from datetime import datetime, UTC
from typing import Optional

from sqlalchemy.orm import Session

from app.models.database import (
    MerchantInventory,
    Order,
    ProductVariant,
)


# ─────────────────────────────────────────────────────────────────────────────
# Reference code
# ─────────────────────────────────────────────────────────────────────────────

def generate_reference_code() -> str:
    """Return a human-readable unique reference like TDM-A3B9-C7D2."""
    h = uuid.uuid4().hex[:8].upper()
    return f"TDM-{h[:4]}-{h[4:]}"


def _unique_reference(db: Session, max_attempts: int = 20) -> str:
    for _ in range(max_attempts):
        code = generate_reference_code()
        if not db.query(Order).filter(Order.reference_code == code).first():
            return code
    raise RuntimeError("Could not generate a unique reference code — database may be at capacity")


# ─────────────────────────────────────────────────────────────────────────────
# Order CRUD
# ─────────────────────────────────────────────────────────────────────────────

def create_order(
    db: Session,
    merchant_id: int,
    product_id: int,
    amount: float,
    buyer_phone: str,
    variant_id: Optional[str] = None,
    quantity: int = 1,
) -> Order:
    """
    Create a new PENDING_PAYMENT order.

    Idempotent: if an identical pending order already exists for the same
    buyer + product + variant, the existing order is returned unchanged.
    This prevents duplicate orders when a user taps "YES" twice in quick
    succession.
    """
    existing = (
        db.query(Order)
        .filter(
            Order.buyer_phone == buyer_phone,
            Order.product_id  == product_id,
            Order.variant_id  == variant_id,
            Order.status      == "PENDING_PAYMENT",
        )
        .first()
    )
    if existing:
        return existing

    order = Order(
        id             = str(uuid.uuid4()),
        merchant_id    = merchant_id,
        product_id     = product_id,
        variant_id     = variant_id,
        quantity       = quantity,
        amount         = amount,
        status         = "PENDING_PAYMENT",
        reference_code = _unique_reference(db),
        buyer_phone    = buyer_phone,
        created_at     = datetime.now(UTC),
        updated_at     = datetime.now(UTC),
    )
    db.add(order)
    db.commit()
    return order


def mark_order_paid(db: Session, reference_code: str) -> Order:
    """
    Transition order PENDING_PAYMENT → PAID and reduce variant / product stock.

    Idempotent: returns immediately if the order is already PAID.
    Uses SELECT … FOR UPDATE SKIP LOCKED to prevent race conditions on
    concurrent webhook deliveries.

    Called by:
    - Manual confirmation endpoint (merchant / support)
    - Future payment webhook observer

    Raises ValueError for unknown or cancelled orders.
    """
    order = (
        db.query(Order)
        .filter(Order.reference_code == reference_code)
        .with_for_update(skip_locked=True)
        .first()
    )

    if not order:
        raise ValueError(f"Order '{reference_code}' not found")

    if order.status == "PAID":
        return order  # already done — idempotent

    if order.status == "CANCELLED":
        raise ValueError(f"Order '{reference_code}' is cancelled and cannot be paid")

    order.status     = "PAID"
    order.updated_at = datetime.now(UTC)

    # ── Reduce stock ──────────────────────────────────────────────────────────
    if order.variant_id:
        variant = (
            db.query(ProductVariant)
            .filter(ProductVariant.id == order.variant_id)
            .with_for_update()
            .first()
        )
        if variant:
            variant.quantity_available = max(0, variant.quantity_available - order.quantity)
            variant.quantity_fulfilled += order.quantity
            variant.updated_at          = datetime.now(UTC)
            # Keep parent product stock in sync
            _sync_product_stock_from_variants(db, variant.inventory_id)
    else:
        product = (
            db.query(MerchantInventory)
            .filter(MerchantInventory.id == order.product_id)
            .with_for_update()
            .first()
        )
        if product:
            product.quantity_available = max(0, product.quantity_available - order.quantity)
            product.quantity_sold     += order.quantity

    db.commit()
    return order


def cancel_order(db: Session, reference_code: str) -> Optional[Order]:
    """
    Cancel a PENDING_PAYMENT order. Idempotent — returns None if not found.
    """
    order = db.query(Order).filter(Order.reference_code == reference_code).first()
    if not order:
        return None
    if order.status != "PENDING_PAYMENT":
        return order  # Nothing to do
    order.status     = "CANCELLED"
    order.updated_at = datetime.now(UTC)
    db.commit()
    return order


# ─────────────────────────────────────────────────────────────────────────────
# Stock helpers
# ─────────────────────────────────────────────────────────────────────────────

def get_total_stock(db: Session, product_id: int) -> int:
    """
    Return the total freely-available stock for a product.

    - If the product has active variants → sum(variant.quantity_free)
    - Otherwise                          → product.quantity_free
    """
    variants = (
        db.query(ProductVariant)
        .filter(
            ProductVariant.inventory_id == product_id,
            ProductVariant.is_active    == True,  # noqa: E712
        )
        .all()
    )
    if variants:
        return sum(max(0, v.quantity_available - v.quantity_reserved) for v in variants)

    product = db.query(MerchantInventory).filter(MerchantInventory.id == product_id).first()
    return product.quantity_free if product else 0


def mark_product_unavailable(db: Session, product_id: int) -> None:
    """
    Set quantity_available = 0 when get_total_stock() returns 0.
    Called after mark_order_paid() to keep the parent record consistent.
    """
    if get_total_stock(db, product_id) == 0:
        product = db.query(MerchantInventory).filter(MerchantInventory.id == product_id).first()
        if product:
            product.quantity_available = 0
            db.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Private
# ─────────────────────────────────────────────────────────────────────────────

def _sync_product_stock_from_variants(db: Session, product_id: int) -> None:
    """Recompute MerchantInventory.quantity_available as the sum of active variants."""
    variants = (
        db.query(ProductVariant)
        .filter(
            ProductVariant.inventory_id == product_id,
            ProductVariant.is_active    == True,  # noqa: E712
        )
        .all()
    )
    product = db.query(MerchantInventory).filter(MerchantInventory.id == product_id).first()
    if product and variants:
        product.quantity_available = sum(v.quantity_available for v in variants)
