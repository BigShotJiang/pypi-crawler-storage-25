"""
Proof of Delivery Service

Handles:
- Courier PoD submission
- Buyer confirmation / dispute
- Timeout fallback logic
- Audit logging
- Safe release gating (non-custodial enforcement)
"""

import logging
import hashlib
import hmac
from datetime import datetime, UTC
from typing import Optional, Tuple
from uuid import UUID

from sqlalchemy.orm import Session

from app.models.database import Deal, DealStatus, Dispute, DisputeStatus
from app.models.proof_of_delivery import (
    ProofOfDelivery,
    PoDStatus,
    AuditLog,
    AuditEventType,
)
from app.core.config import settings
from app.core.redis import redis_client

logger = logging.getLogger(__name__)


class ProofOfDeliveryService:

    POD_CONFIRMATION_TIMEOUT_MINUTES = 30

    # ─────────────────────────────────────────────
    # HMAC SIGNING
    # ─────────────────────────────────────────────

    @staticmethod
    def create_hmac_signed_url(file_path: str, expires_seconds: int = 3600) -> str:
        timestamp = int(datetime.now(UTC).timestamp())
        expiry = timestamp + expires_seconds

        message = f"{file_path}:{expiry}".encode()

        signature = hmac.new(
            settings.HMAC_SECRET.encode(),
            message,
            hashlib.sha256,
        ).hexdigest()

        return f"{file_path}?sig={signature}&exp={expiry}"

    @staticmethod
    def verify_hmac_signed_url(signed_url: str) -> Tuple[bool, Optional[str]]:
        try:
            parts = signed_url.split("?")
            if len(parts) != 2:
                return False, "invalid_format"

            file_path = parts[0]
            params = dict(p.split("=") for p in parts[1].split("&"))

            expiry = int(params.get("exp", 0))
            provided_sig = params.get("sig")

            if datetime.now(UTC).timestamp() > expiry:
                return False, "expired"

            message = f"{file_path}:{expiry}".encode()

            expected_sig = hmac.new(
                settings.HMAC_SECRET.encode(),
                message,
                hashlib.sha256,
            ).hexdigest()

            if not hmac.compare_digest(provided_sig, expected_sig):
                return False, "invalid_signature"

            return True, file_path

        except Exception as e:
            logger.error(f"HMAC verification failed: {e}")
            return False, str(e)

    # ─────────────────────────────────────────────
    # SUBMIT POD (COURIER)
    # ─────────────────────────────────────────────

    @staticmethod
    def submit_pod(
        db: Session,
        deal_id: UUID,
        courier_phone: str,
        photo_url: str,
        gps_lat: Optional[float],
        gps_lng: Optional[float],
        gps_accuracy_meters: Optional[float],
    ) -> Tuple[bool, str, Optional[ProofOfDelivery]]:

        try:
            deal = db.query(Deal).filter(Deal.id == deal_id).first()

            if not deal:
                return False, "deal_not_found", None

            # Allow IN_TRANSIT → DELIVERED transition
            if deal.status not in [DealStatus.IN_TRANSIT, DealStatus.DELIVERED]:
                return False, f"invalid_state:{deal.status}", None

            if deal.courier_phone != courier_phone:
                return False, "courier_mismatch", None

            existing = db.query(ProofOfDelivery).filter(
                ProofOfDelivery.deal_id == deal_id
            ).first()

            now = datetime.now(UTC)

            # ── RESUBMISSION ───────────────────────
            if existing:
                existing.submission_count += 1

                if existing.pod_status != PoDStatus.CONFIRMED:
                    existing.delivery_photo_url = photo_url
                    existing.gps_lat = gps_lat
                    existing.gps_lng = gps_lng
                    existing.gps_accuracy_meters = gps_accuracy_meters
                    existing.delivered_at = now
                    existing.pod_status = PoDStatus.SUBMITTED

                db.commit()

                _log_audit(
                    db,
                    AuditEventType.POD_SUBMITTED,
                    "proof_of_delivery",
                    existing.id,
                    courier_phone,
                    {"resubmission": True},
                )

                return True, "resubmitted", existing

            # ── NEW POD ────────────────────────────
            pod = ProofOfDelivery(
                deal_id=deal_id,
                courier_phone=courier_phone,
                delivery_photo_url=photo_url,
                gps_lat=gps_lat,
                gps_lng=gps_lng,
                gps_accuracy_meters=gps_accuracy_meters,
                delivered_at=now,
                pod_status=PoDStatus.SUBMITTED,
                submission_count=1,
            )

            db.add(pod)

            # Transition deal state
            if deal.status == DealStatus.IN_TRANSIT:
                deal.status = DealStatus.DELIVERED
                db.add(deal)

            db.commit()

            # Set Redis timeout key
            redis_client.setex(
                f"pod:awaiting_confirmation:{deal_id}",
                ProofOfDeliveryService.POD_CONFIRMATION_TIMEOUT_MINUTES * 60,
                "1",
            )

            _log_audit(
                db,
                AuditEventType.POD_SUBMITTED,
                "proof_of_delivery",
                pod.id,
                courier_phone,
                {"deal_id": str(deal_id)},
            )

            return True, "submitted", pod

        except Exception as e:
            db.rollback()
            logger.error(f"PoD submission failed: {e}")
            return False, str(e), None

    # ─────────────────────────────────────────────
    # CONFIRM POD (BUYER)
    # ─────────────────────────────────────────────

    @staticmethod
    def confirm_pod(
        db: Session,
        deal_id: UUID,
        buyer_phone: str,
        decision: str,
    ) -> Tuple[bool, str]:

        decision = decision.upper()

        pod = db.query(ProofOfDelivery).filter(
            ProofOfDelivery.deal_id == deal_id
        ).first()

        if not pod:
            return False, "pod_not_found"

        deal = db.query(Deal).filter(Deal.id == deal_id).first()

        if not deal or deal.buyer_phone != buyer_phone:
            return False, "buyer_mismatch"

        if pod.pod_status != PoDStatus.SUBMITTED:
            return False, "invalid_pod_state"

        now = datetime.now(UTC)

        if decision == "YES":
            pod.buyer_confirmed = True
            pod.buyer_confirmed_at = now
            pod.pod_status = PoDStatus.CONFIRMED

            db.commit()

            _log_audit(
                db,
                AuditEventType.POD_CONFIRMED,
                "proof_of_delivery",
                pod.id,
                buyer_phone,
                {},
            )

            if not _safe_to_release(db, deal_id):
                return False, "release_blocked"

            from app.services.escrow_service import EscrowService

            return EscrowService.release_escrow(db, deal_id, "pod_confirmed")

        elif decision == "NO":
            pod.pod_status = PoDStatus.DISPUTED
            db.add(pod)

            dispute = Dispute(
                deal_id=deal_id,
                pod_id=pod.id,
                buyer_phone=buyer_phone,
                merchant_phone=deal.seller_phone,
                reason="Delivery disputed",
                opened_by="buyer",
                status=DisputeStatus.OPEN,
            )

            db.add(dispute)
            db.commit()

            _log_audit(
                db,
                AuditEventType.POD_DISPUTED,
                "proof_of_delivery",
                pod.id,
                buyer_phone,
                {},
            )

            return True, "disputed"

        return False, "invalid_decision"

    # ─────────────────────────────────────────────
    # TIMEOUT HANDLER
    # ─────────────────────────────────────────────

    @staticmethod
    def handle_confirmation_timeout(db: Session, deal_id: UUID):

        pod = db.query(ProofOfDelivery).filter(
            ProofOfDelivery.deal_id == deal_id
        ).first()

        if not pod or pod.pod_status != PoDStatus.SUBMITTED:
            return False, "invalid_state"

        deal = db.query(Deal).filter(Deal.id == deal_id).first()

        from app.services.trust_score_engine import TrustScoreEngine

        merchant = TrustScoreEngine.calculate_merchant_score(db, deal.seller_phone)
        buyer = TrustScoreEngine.calculate_buyer_score(db, deal.buyer_phone)

        confidence = min(merchant["confidence"], buyer["confidence"])

        if confidence < 0.7:
            decision = "REFUND"

        elif confidence > 0.85:
            decision = "RELEASE" if merchant["score"] > buyer["score"] else "REFUND"

        else:
            dispute = Dispute(
                deal_id=deal_id,
                pod_id=pod.id,
                buyer_phone=deal.buyer_phone,
                merchant_phone=deal.seller_phone,
                reason="Timeout requires review",
                opened_by="system",
                status=DisputeStatus.REVIEW,
            )
            db.add(dispute)
            db.commit()
            return True, "manual_review"

        pod.pod_status = PoDStatus.CONFIRMED
        db.commit()

        _log_audit(
            db,
            AuditEventType.DISPUTE_AUTO_RESOLVED,
            "proof_of_delivery",
            pod.id,
            None,
            {"decision": decision},
        )

        return True, decision


# ─────────────────────────────────────────────
# SAFETY GUARD
# ─────────────────────────────────────────────

def _safe_to_release(db: Session, deal_id: UUID) -> bool:
    dispute = db.query(Dispute).filter(
        Dispute.deal_id == deal_id,
        Dispute.status == DisputeStatus.OPEN,
    ).first()

    return dispute is None


# ─────────────────────────────────────────────
# AUDIT HELPER
# ─────────────────────────────────────────────

def _log_audit(
    db: Session,
    event_type: AuditEventType,
    entity_type: str,
    entity_id: UUID,
    actor_phone: Optional[str],
    payload: dict,
):
    try:
        audit = AuditLog(
            event_type=event_type,
            entity_type=entity_type,
            entity_id=entity_id,
            actor_phone=actor_phone,
            payload=payload,
        )
        db.add(audit)
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"audit log failed: {e}")
