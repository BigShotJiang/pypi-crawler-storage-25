"""
app/services/recovery_service.py

State recovery — restores minimal Redis keys from PostgreSQL.

Called:
- On application startup (optional warm-up)
- After Redis failure/restart
- Manually by ops to fix stale Redis state

PostgreSQL is always authoritative — this function reads DB and
writes to Redis to re-synchronise the cache layer.
"""

import logging
from typing import Optional

from sqlalchemy.orm import Session

from app.models.database import Deal, DealStatus, Dispute
from app.services.dispute_service import DISPUTE_LOCK_TTL_SECONDS, _lock_key

logger = logging.getLogger(__name__)


def recover_deal_state(
    db: Session,
    deal_id: str,
    redis_client=None,
) -> dict:
    """
    Read deal state from PostgreSQL and restore Redis keys if needed.

    Returns a summary dict:
    {
        "recovered":      bool,
        "deal_id":        str,
        "deal_status":    str,
        "courier_phone":  str | None,
        "restored_keys":  list[str],
        "reason":         str  (only on failure)
    }

    Never raises — errors are logged and returned in the summary.
    """
    try:
        deal = db.query(Deal).filter(Deal.deal_id == deal_id).first()
        if not deal:
            return {"recovered": False, "deal_id": deal_id, "reason": "Deal not found"}

        restored_keys: list = []

        if redis_client:
            # ── Restore dispute lock if DB has an active dispute ─────────────
            active_dispute = (
                db.query(Dispute)
                .filter(
                    Dispute.deal_id == deal_id,
                    Dispute.status.in_(["OPEN", "REVIEW"]),
                )
                .first()
            )
            if active_dispute:
                try:
                    redis_client.setex(_lock_key(deal_id), DISPUTE_LOCK_TTL_SECONDS, "1")
                    restored_keys.append(_lock_key(deal_id))
                    logger.info(
                        "[Recovery] Restored dispute lock for deal %s", deal_id
                    )
                except Exception as exc:
                    logger.error(
                        "[Recovery] Failed to restore Redis lock for deal %s: %s",
                        deal_id, exc,
                    )
            else:
                # No active dispute — ensure lock is cleared
                try:
                    redis_client.delete(_lock_key(deal_id))
                except Exception:
                    pass

        logger.info(
            "[Recovery] deal=%s status=%s courier=%s restored_keys=%s",
            deal_id, deal.status.value,
            deal.courier_phone, restored_keys,
        )

        return {
            "recovered":     True,
            "deal_id":       deal_id,
            "deal_status":   deal.status.value,
            "courier_phone": deal.courier_phone,
            "restored_keys": restored_keys,
        }

    except Exception as exc:
        logger.error("[Recovery] recover_deal_state failed for deal %s: %s", deal_id, exc)
        return {"recovered": False, "deal_id": deal_id, "reason": str(exc)}
