# app/services/merchant_onboarding.py
"""
Merchant self-service onboarding.

Handles:
  - Unique merchant slug generation (slugified name + 6-char hex)
  - WhatsApp entry link construction (wa.me deep-link)
  - QR code generation (base64 PNG, no filesystem dependency)
  - DB record creation / idempotent update

All new — does NOT touch payment, courier, or escrow flows.
"""

import base64
import io
import logging
import os
import re
import uuid
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)


# ─── ID & LINK HELPERS ────────────────────────────────────────────────────────

def _slugify(text: str) -> str:
    """Lowercase, spaces/underscores → hyphens, strip non-alphanumeric."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text[:30].strip("-")


def generate_merchant_id(name: str) -> str:
    """
    Generate a collision-resistant merchant slug.

    Pattern: <slugified-name>-<6-char-hex>
    Example: "Johns Store" → "johns-store-a3f7b2"
    """
    slug = _slugify(name) or "merchant"
    suffix = uuid.uuid4().hex[:6]
    return f"{slug}-{suffix}"


def generate_entry_link(merchant_id: str) -> str:
    """
    Build the WhatsApp deep-link that opens a chat pre-filled with
    "store_<merchant_id>".

    Uses TWILIO_WHATSAPP_NUMBER env var. wa.me requires digits only.
    """
    raw = os.environ.get("TWILIO_WHATSAPP_NUMBER", "")
    number = re.sub(r"\D", "", raw)
    return f"https://wa.me/{number}?text=store_{merchant_id}"


# ─── QR CODE ──────────────────────────────────────────────────────────────────

def generate_qr_code_b64(link: str) -> str:
    """
    Generate a QR code PNG for link and return it as a base64 string.

    Requires: qrcode[pil]>=7.4  (added to requirements.txt)
    Falls back to empty string if qrcode is not installed.
    """
    try:
        import qrcode  # type: ignore

        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
        )
        qr.add_data(link)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode()
    except ImportError:
        logger.warning("qrcode library not installed — QR generation skipped")
        return ""
    except Exception as exc:
        logger.error(f"QR generation error: {exc}")
        return ""


# ─── DB OPERATIONS ────────────────────────────────────────────────────────────

def create_or_update_merchant(
    db,
    phone: str,
    name: str,
    payment_id: str,
    merchant_slug: str,
    entry_link: str,
    qr_code_b64: str,
):
    """
    Persist a self-registered merchant.

    Idempotent: if the phone already exists, updates the onboarding fields
    (slug, payment_id, entry_link, qr_code_b64) without touching monetary
    or escrow columns.

    Returns the Merchant ORM object.
    """
    from app.models.database import Merchant

    existing = db.query(Merchant).filter(Merchant.phone == phone).first()
    if existing:
        existing.merchant_slug = merchant_slug
        existing.payment_id    = payment_id
        existing.entry_link    = entry_link
        existing.qr_code_b64   = qr_code_b64
        existing.status        = "active"
        db.commit()
        db.refresh(existing)
        logger.info(f"Merchant updated: slug={merchant_slug}")
        return existing

    merchant = Merchant(
        phone          = phone,
        name           = name,
        wallet_address = payment_id,   # payment_id doubles as wallet for new self-reg
        status         = "active",
        merchant_slug  = merchant_slug,
        payment_id     = payment_id,
        entry_link     = entry_link,
        qr_code_b64    = qr_code_b64,
        created_at     = datetime.now(timezone.utc),
    )
    db.add(merchant)
    db.commit()
    db.refresh(merchant)
    logger.info(f"Merchant created: slug={merchant_slug}")
    return merchant


def get_merchant_by_slug(db, slug: str) -> Optional[object]:
    """Look up a Merchant by merchant_slug. Returns None if not found."""
    from app.models.database import Merchant
    return db.query(Merchant).filter(Merchant.merchant_slug == slug).first()


def get_merchant_by_phone(db, phone: str) -> Optional[object]:
    """Look up a Merchant by phone. Returns None if not found."""
    from app.models.database import Merchant
    return db.query(Merchant).filter(Merchant.phone == phone).first()
