"""
app/services/dispute_service.py

Dispute resolution system — RBZ compliance layer.

Design principles:
- PostgreSQL is authoritative (disputes table).
- Redis lock (deal:{deal_id}:locked) is a secondary guard.
- All operations are idempotent.
- check_release_allowed() MUST be called before any fund release.
"""

import logging
from datetime import datetime, UTC
from typing import Optional

from sqlalchemy.orm import Session

from app.models.database import Deal, DealStatus, Dispute
from app.services.event_log_service import log_event

logger = logging.getLogger(__name__)

# Redis TTL for dispute lock: 24 hours
DISPUTE_LOCK_TTL_SECONDS = 86_400
_DISPUTE_LOCK_KEY = "deal:{deal_id}:locked"


def _lock_key(deal_id: str) -> str:
    return f"deal:{deal_id}:locked"


def open_dispute(
    db: Session,
    deal_id: str,
    actor: str,
    reason: str,
    redis_client=None,
) -> Dispute:
    """
    Open a dispute against a deal.

    Steps (in order):
    1. Idempotency check — reject if active dispute already exists.
    2. Insert Dispute row (status=OPEN).
    3. Update deal.status → DISPUTE_OPENED.
    4. Log DISPUTE_OPENED event.
    5. db.commit()  ← PostgreSQL committed before Redis.
    6. Set Redis lock deal:{deal_id}:locked = 1 (TTL 24h).

    Args:
        actor:  "buyer" | "merchant" | "courier"
    """
    # ── Idempotency ───────────────────────────────────────────────────────────
    existing = (
        db.query(Dispute)
        .filter(Dispute.deal_id == deal_id, Dispute.status.in_(["OPEN", "REVIEW"]))
        .first()
    )
    if existing:
        raise ValueError(
            f"Active dispute already exists for deal {deal_id} "
            f"(status={existing.status}, opened_by={existing.opened_by})"
        )

    deal = db.query(Deal).filter(Deal.deal_id == deal_id).first()
    if not deal:
        raise ValueError(f"Deal '{deal_id}' not found")

    # ── DB writes (PostgreSQL first) ──────────────────────────────────────────
    dispute = Dispute(
        deal_id   = deal_id,
        opened_by = actor,
        reason    = reason,
        status    = "OPEN",
    )
    db.add(dispute)
    db.flush()  # get dispute.id

    deal.status = DealStatus.DISPUTE_OPENED

    log_event(db, deal_id, "DISPUTE_OPENED", {
        "actor":      actor,
        "reason":     reason,
        "dispute_id": dispute.id,
    })

    db.commit()  # ← PostgreSQL committed
    db.refresh(dispute)
    logger.info("Dispute opened | deal=%s actor=%s", deal_id, actor)

    # ── Redis lock (after commit) ─────────────────────────────────────────────
    if redis_client:
        try:
            redis_client.setex(_lock_key(deal_id), DISPUTE_LOCK_TTL_SECONDS, "1")
        except Exception as exc:
            # Redis failure does NOT undo the committed DB dispute.
            logger.error("[DisputeService] Redis lock failed for deal %s: %s", deal_id, exc)

    return dispute


def resolve_dispute(
    db: Session,
    deal_id: str,
    resolution: str,
    redis_client=None,
) -> Dispute:
    """
    Resolve an active dispute.

    Args:
        resolution: "release" (pay merchant) | "refund" (return to buyer)

    Steps:
    1. Load the active dispute.
    2. Update dispute.status = RESOLVED, dispute.resolution = RELEASE|REFUND.
    3. Update deal.status → RESOLVED_RELEASE | RESOLVED_REFUND.
    4. Log DISPUTE_RESOLVED event.
    5. db.commit()
    6. Delete Redis lock.
    """
    resolution = resolution.lower()
    if resolution not in ("release", "refund"):
        raise ValueError(f"Invalid resolution '{resolution}' — must be 'release' or 'refund'")

    dispute = (
        db.query(Dispute)
        .filter(Dispute.deal_id == deal_id, Dispute.status.in_(["OPEN", "REVIEW"]))
        .first()
    )
    if not dispute:
        raise ValueError(f"No active dispute found for deal '{deal_id}'")

    deal = db.query(Deal).filter(Deal.deal_id == deal_id).first()
    if not deal:
        raise ValueError(f"Deal '{deal_id}' not found")

    # ── DB writes ─────────────────────────────────────────────────────────────
    dispute.status      = "RESOLVED"
    dispute.resolution  = resolution.upper()   # "RELEASE" or "REFUND"
    dispute.resolved_at = datetime.now(UTC)

    deal.status = (
        DealStatus.RESOLVED_RELEASE
        if resolution == "release"
        else DealStatus.RESOLVED_REFUND
    )

    log_event(db, deal_id, "DISPUTE_RESOLVED", {
        "resolution": resolution,
        "dispute_id": dispute.id,
    })

    db.commit()
    db.refresh(dispute)
    logger.info("Dispute resolved | deal=%s resolution=%s", deal_id, resolution)

    # ── Release Redis lock (after commit) ─────────────────────────────────────
    if redis_client:
        try:
            redis_client.delete(_lock_key(deal_id))
        except Exception as exc:
            logger.error("[DisputeService] Redis unlock failed for deal %s: %s", deal_id, exc)

    return dispute


def check_release_allowed(
    db: Session,
    deal_id: str,
    redis_client=None,
) -> None:
    """
    Assert that releasing funds for this deal is permitted.

    Raises ValueError if blocked. Must be called before any release trigger.

    Check order:
    1. PostgreSQL disputes table (authoritative).
    2. Redis lock (belt-and-suspenders).

    If Redis is DOWN, the PostgreSQL check is still enforced — the system
    degrades gracefully rather than blocking all releases.
    """
    # ── Primary guard: PostgreSQL (authoritative) ─────────────────────────────
    active_dispute = (
        db.query(Dispute)
        .filter(Dispute.deal_id == deal_id, Dispute.status.in_(["OPEN", "REVIEW"]))
        .first()
    )
    if active_dispute:
        raise ValueError(
            f"Release BLOCKED — active dispute for deal {deal_id} "
            f"(opened_by={active_dispute.opened_by}, status={active_dispute.status}). "
            f"Resolve the dispute first."
        )

    # ── Secondary guard: Redis lock (belt-and-suspenders) ────────────────────
    if redis_client:
        try:
            if redis_client.get(_lock_key(deal_id)):
                raise ValueError(
                    f"Release BLOCKED — deal {deal_id} has a Redis dispute lock. "
                    f"This may indicate a stale lock; verify disputes table."
                )
        except ValueError:
            raise  # re-raise our own ValueError
        except Exception as exc:
            # Redis failure → fall through (DB check already passed)
            logger.warning(
                "[DisputeService] Redis lock check failed for deal %s: %s "
                "— proceeding (DB authoritative).",
                deal_id, exc,
            )
