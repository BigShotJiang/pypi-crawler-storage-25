# app/services/courier_timeout_engine.py
"""
Courier timeout scanner — detects couriers who went dark after accepting.

Problem
────────
A courier accepts a job (state → COURIER_ASSIGNED) but then:
  - loses network connectivity
  - has an accident
  - decides not to deliver
  - app crashes

Without intervention the customer is stuck in DEAL_CREATED forever.
The escrow would eventually expire (2h) but the customer gets no delivery
and a delayed refund instead of a proactive reassignment.

Solution
─────────
This engine runs on a cron interval (default: every 5 minutes).
It scans `bot:state:*` for couriers in active delivery states and checks
how long they've been in that state against configurable thresholds.

If a courier has been in COURIER_ASSIGNED for > TIMEOUT_COURIER_ASSIGNED_S
without progressing to DELIVERY_IN_PROGRESS, their job is reassigned.

Similarly, DELIVERY_IN_PROGRESS has a maximum before the job is flagged.

Integration
────────────
Called from a FastAPI background task, Railway cron, or directly from
the EscrowTimeoutJob loop.

POST /recovery/courier-timeout  — HTTP trigger (see recovery router)
or schedule via cron: courier_timeout_engine.run_scan()

Usage::

    from app.services.courier_timeout_engine import run_courier_timeout_scan

    # Run once (call from cron or POST /recovery/courier-timeout):
    result = await run_courier_timeout_scan()
"""

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ── Timeout thresholds (seconds) ─────────────────────────────────────────────

# Courier accepted but hasn't confirmed pickup after this long
TIMEOUT_COURIER_ASSIGNED_S     = 45 * 60   # 45 minutes

# Courier confirmed pickup but hasn't confirmed delivery after this long
TIMEOUT_DELIVERY_IN_PROGRESS_S = 3 * 60 * 60   # 3 hours

_THRESHOLDS = {
    "COURIER_ASSIGNED":       TIMEOUT_COURIER_ASSIGNED_S,
    "DELIVERY_IN_PROGRESS":   TIMEOUT_DELIVERY_IN_PROGRESS_S,
}


async def run_courier_timeout_scan(rdb: Any, db=None) -> Dict:
    """
    Scan all active courier sessions for stale delivery states.

    For each timed-out courier:
      1. Read bot:courier_job:{courier_phone} for deal_id + customer_phone
      2. Call BotEngine.process_event("courier_timeout", {...})
      3. Notification is handled inside the event handler

    Returns:
        {
            "scanned":   int,
            "timed_out": int,
            "details":   list of {"courier_hash", "deal_id", "state", "age_s"}
        }
    """
    from app.bot.state_manager import RedisStateManager
    from app.bot.engine import BotEngine

    sm      = RedisStateManager(rdb)
    now     = time.time()
    scanned = 0
    details: List[Dict] = []

    try:
        for raw_key in rdb.scan_iter(match="bot:state:*", count=200):
            scanned += 1
            key_str = raw_key.decode() if isinstance(raw_key, bytes) else raw_key
            # Extract phone from key
            parts = key_str.split("bot:state:", 1)
            if len(parts) != 2 or not parts[1]:
                continue
            courier_phone = parts[1]

            # Read state
            raw_state = rdb.get(key_str)
            if not raw_state:
                continue
            state = raw_state.decode() if isinstance(raw_state, bytes) else raw_state

            threshold = _THRESHOLDS.get(state)
            if threshold is None:
                continue   # Not a courier delivery state

            # Read timestamp
            ts_raw = rdb.get(f"bot:state_ts:{courier_phone}")
            if not ts_raw:
                continue
            try:
                age_s = now - float(ts_raw.decode() if isinstance(ts_raw, bytes) else ts_raw)
            except (ValueError, TypeError):
                continue

            if age_s < threshold:
                continue   # Still within allowed window

            # Courier has gone dark — load job details
            job = sm.get_courier_job(courier_phone)
            deal_id       = job.get("deal_id", "")       if job else ""
            customer_phone = job.get("customer_phone", "") if job else ""

            logger.warning(
                "courier_timeout: courier_hash=%s state=%s age_s=%.0f deal_id=%s",
                hash(courier_phone) % 100_000, state, age_s, deal_id,
            )

            # Dispatch to BotEngine event handler
            try:
                engine = BotEngine(sm=sm, db=db)
                await asyncio.wait_for(
                    engine.process_event("courier_timeout", {
                        "deal_id":        deal_id,
                        "courier_phone":  courier_phone,
                        "customer_phone": customer_phone,
                    }),
                    timeout=15.0,
                )
            except Exception as exc:
                logger.error(
                    "courier_timeout: process_event failed courier_hash=%s: %s",
                    hash(courier_phone) % 100_000, exc,
                )

            details.append({
                "courier_hash": str(hash(courier_phone) % 100_000),
                "deal_id":      deal_id,
                "state":        state,
                "age_s":        int(age_s),
            })

    except Exception as exc:
        logger.error("run_courier_timeout_scan failed: %s", exc)
        return {"scanned": scanned, "timed_out": len(details), "details": details, "error": str(exc)}

    return {"scanned": scanned, "timed_out": len(details), "details": details}
