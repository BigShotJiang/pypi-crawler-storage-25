"""
Escrow timeout / auto-reversal engine.

Tofamba's role is to *observe* wallet-to-wallet settlements, not to hold funds.
When a buyer's payment is locked in escrow and the delivery PIN is not entered
within the 2-hour window, this engine detects the expiry and instructs the
wallet provider to reverse the funds back to the payer automatically.

State transitions managed here::

    HELD ──(expiry detected)──► EXPIRED ──(wallet reversal accepted)──► REVERSAL_INITIATED

Every transition is recorded in EscrowStateLog so that the complete lifecycle
can be audited.

Pessimistic Locking
-------------------
``trigger_reversal()`` acquires a **row-level** ``SELECT … FOR UPDATE SKIP LOCKED``
on the single target escrow row at the start of its transaction.  This means:

* If two workers pick up the same expired escrow concurrently, only one will
  get the lock; the other will see an empty result and exit cleanly ("skipped").
* The lock is released as soon as the transaction commits — i.e. after one DB
  round-trip plus one wallet-API call.  We never hold the lock across the full
  batch.
* SKIP LOCKED is PostgreSQL-specific.  When running under SQLite (unit-tests)
  the ``with_for_update`` call is skipped automatically via dialect detection.
"""

import json
import logging
from datetime import datetime
from typing import Dict, List

from sqlalchemy import inspect as sa_inspect

from app.adapters.wallet_adapter import WalletAdapter
from app.models.database import Deal, Escrow, EscrowStateLog, EscrowStatus
from app.services import inventory_service

logger = logging.getLogger(__name__)


def _supports_for_update(session) -> bool:
    """Return True if the underlying DB dialect supports SELECT … FOR UPDATE."""
    try:
        dialect = session.bind.dialect.name
        return dialect not in ("sqlite",)
    except Exception:
        return False


class EscrowTimeoutEngine:
    """
    Identifies expired escrows and triggers wallet-provider reversals.

    Tofamba never holds money; this engine only produces *instructions* that
    are sent to the wallet provider via the injected ``wallet_adapter``.
    """

    def __init__(self, db_session, wallet_adapter: WalletAdapter):
        """
        Args:
            db_session: A SQLAlchemy session used for all DB operations.
            wallet_adapter: Provider-specific adapter that executes reversals.
        """
        self.db_session = db_session
        self.wallet_adapter = wallet_adapter

    # ------------------------------------------------------------------
    # Expiry detection  (lightweight — no lock held here)
    # ------------------------------------------------------------------

    def check_expired_escrows(self) -> List[Dict]:
        """
        Find all HELD escrows whose expiry window has passed.

        This is a **lightweight, lock-free** sweep.  It returns only the
        minimal fields needed to kick off ``trigger_reversal()``; full
        object state is re-read (with a row lock) inside that method.

        Queries for escrows where:
          - ``status == HELD``
          - ``expiry_timestamp <= now``  (2-hour window elapsed)

        Returns:
            A list of lightweight instruction dicts, one per expired escrow::

                {
                    "escrow_id": 42,
                    "external_transaction_id": "TXN-abc",
                    "payer_wallet_id": "263771234567",
                    "amount": 25.00,
                    "reason": "timeout",
                }
        """
        now = datetime.utcnow()
        # No with_for_update() here — we just need a candidate list.
        # The actual lock is taken per-row inside trigger_reversal().
        expired_escrows = (
            self.db_session.query(Escrow)
            .filter(
                Escrow.status == EscrowStatus.HELD,
                Escrow.expiry_timestamp <= now,
            )
            .all()
        )

        return [
            {
                "escrow_id":              escrow.id,
                "external_transaction_id": escrow.external_transaction_id,
                "payer_wallet_id":         escrow.payer_wallet_id,
                "amount":                  float(escrow.total_escrow),
                "reason":                  "timeout",
            }
            for escrow in expired_escrows
        ]

    # ------------------------------------------------------------------
    # Reversal trigger  (acquires per-row pessimistic lock)
    # ------------------------------------------------------------------

    def trigger_reversal(self, escrow_id: int, reason: str) -> Dict:
        """
        Trigger a reversal for a single escrow that is still in HELD state.

        Pessimistic locking strategy
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        The escrow row is re-fetched inside this method using
        ``SELECT … FOR UPDATE SKIP LOCKED`` (PostgreSQL) so that:

        1. Only **one** worker processes each escrow even under concurrent
           load — the first to acquire the lock wins; others skip silently.
        2. The lock is held for a single DB round-trip + one wallet API call,
           then released on COMMIT.  No long-held locks that starve the DB.
        3. Under SQLite (tests) the ``FOR UPDATE`` clause is omitted
           automatically — behaviour is identical but without the guarantee.

        Workflow
        ~~~~~~~~
        1. Re-fetch the escrow with FOR UPDATE SKIP LOCKED (or plain SELECT on
           SQLite).  If not found / already locked → return ``"skipped"``.
        2. Validate it is still HELD (another worker may have processed it).
        3. Build reversal instruction and call ``wallet_adapter.reverse_transaction()``.
           - On exception: log the error, return without changing DB state so
             the escrow stays HELD and is retried on the next job run.
        4. On adapter success:
             a. HELD → EXPIRED, record EscrowStateLog.
             b. EXPIRED → REVERSAL_INITIATED, record EscrowStateLog.
             c. Set ``reversal_triggered_at``.
             d. Release inventory reservation (if linked to a deal).
             e. Commit — row lock released.
        5. On adapter soft-failure (``success=False``):
             a. HELD → EXPIRED, log state change.
             b. Commit (can be retried later — provider is not flooded).

        Args:
            escrow_id: Primary key of the Escrow to reverse.
            reason: Short label for why the reversal was triggered, e.g.
                ``"timeout"``, ``"dispute"``, ``"manual"``.

        Returns:
            A dict summarising the outcome::

                {
                    "escrow_id": 42,
                    "status": "reversal_initiated",  # "expired" / "error" / "skipped"
                    "reversal_id": "REV-xyz",         # present on success
                }

        Raises:
            ValueError: If the escrow is not found or is not in HELD state
                        (and was not merely skipped due to a lock contention).
        """
        # ── 1. Acquire per-row lock ────────────────────────────────────────
        use_lock = _supports_for_update(self.db_session)

        query = (
            self.db_session.query(Escrow)
            .filter(
                Escrow.id == escrow_id,
                Escrow.status == EscrowStatus.HELD,   # guard: skip already-processed
            )
        )
        if use_lock:
            # SKIP LOCKED: if another worker already holds this row's lock,
            # the query returns nothing rather than blocking.
            query = query.with_for_update(skip_locked=True)

        escrow = query.first()

        if escrow is None:
            # Either the row doesn't exist, it's no longer HELD, or
            # (on PostgreSQL) another worker has it locked — all safe to skip.
            logger.info(
                "Escrow %s not available for reversal (not found, not HELD, "
                "or locked by another worker) — skipping.",
                escrow_id,
            )
            return {"escrow_id": escrow_id, "status": "skipped"}

        # ── 2. Build the reversal instruction ─────────────────────────────
        instruction = {
            "external_transaction_id": escrow.external_transaction_id,
            "payer_wallet_id":         escrow.payer_wallet_id,
            "amount":                  float(escrow.total_escrow),
            "reason":                  reason,
        }

        # ── 3. Call the wallet provider ───────────────────────────────────
        # If this raises, we abort without touching the DB — the escrow stays
        # HELD and will be retried on the next job run.
        try:
            result = self.wallet_adapter.reverse_transaction(instruction)
        except Exception as exc:
            logger.error(
                "Reversal call to wallet adapter failed for escrow %s: %s",
                escrow_id,
                exc,
                exc_info=True,
            )
            return {"escrow_id": escrow_id, "status": "error", "error": str(exc)}

        # ── 4. Transition 1: HELD → EXPIRED ───────────────────────────────
        previous_status = escrow.status.value
        escrow.status = EscrowStatus.EXPIRED
        escrow.reversal_reason = reason

        self.db_session.add(EscrowStateLog(
            escrow_id       = escrow_id,
            previous_status = previous_status,
            new_status      = EscrowStatus.EXPIRED.value,
            triggered_by    = "auto_timeout",
            metadata_json   = json.dumps({
                "external_transaction_id": escrow.external_transaction_id,
            }),
        ))

        if result.get("success"):
            # ── 4b. Transition 2: EXPIRED → REVERSAL_INITIATED ────────────
            escrow.status = EscrowStatus.REVERSAL_INITIATED
            escrow.reversal_triggered_at = datetime.utcnow()

            self.db_session.add(EscrowStateLog(
                escrow_id       = escrow_id,
                previous_status = EscrowStatus.EXPIRED.value,
                new_status      = EscrowStatus.REVERSAL_INITIATED.value,
                triggered_by    = "auto_timeout",
                metadata_json   = json.dumps({
                    "external_transaction_id": escrow.external_transaction_id,
                    "wallet_response":         result,
                }),
            ))

            # ── 4c. Release inventory reservation ─────────────────────────
            deal = (
                self.db_session.query(Deal)
                .filter(Deal.escrow_id == escrow_id)
                .first()
            )
            if deal and deal.seller_phone and deal.item_sku:
                try:
                    inventory_service.release_reservation(
                        self.db_session,
                        merchant_phone = deal.seller_phone,
                        sku            = deal.item_sku,
                        quantity       = deal.quantity,
                        escrow_id      = escrow_id,
                        deal_id        = deal.deal_id,
                    )
                    logger.info(
                        "Released inventory reservation for deal %s (%s × %d) after reversal",
                        deal.deal_id, deal.item_sku, deal.quantity,
                    )
                except Exception as exc:
                    logger.error(
                        "Failed to release inventory for deal %s on reversal: %s",
                        deal.deal_id if deal else "unknown", exc,
                    )

            self.db_session.commit()   # ← row lock released here
            return {
                "escrow_id":  escrow_id,
                "status":     EscrowStatus.REVERSAL_INITIATED.value,
                "reversal_id": result.get("reversal_id"),
            }

        # ── 5. Soft failure: mark EXPIRED, commit, allow future retry ─────
        self.db_session.commit()
        return {"escrow_id": escrow_id, "status": EscrowStatus.EXPIRED.value}
