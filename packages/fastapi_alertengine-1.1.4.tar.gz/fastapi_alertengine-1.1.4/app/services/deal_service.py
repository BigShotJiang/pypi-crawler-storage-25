"""
Deal service — business logic for Tofamba Protected Deal Links.

A Deal is the user-facing entity created when a seller shares a link in
WhatsApp.  The underlying Escrow (financial/audit record) is created lazily
when the buyer's payment is first detected.

State machine
-------------
Deal:   CREATED → HELD → DELIVERED → COMPLETED
                        ↘ EXPIRED   (timeout window elapsed)

Escrow: (not yet)  HELD → RELEASED
                        ↘ EXPIRED → REVERSAL_INITIATED
"""

import json
import logging
import secrets
import string
from datetime import datetime, UTC, timedelta
from decimal import Decimal
from typing import Optional

from sqlalchemy.orm import Session

from app.adapters.wallet_adapter import WalletAdapter
from app.models.database import (
    Deal,
    DealStatus,
    Escrow,
    EscrowStateLog,
    EscrowStatus,
)
from app.services import inventory_service

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_DEAL_ID_ALPHABET = string.ascii_uppercase + string.digits  # A-Z + 0-9
_DEAL_ID_LENGTH   = 5                                        # ~60 M unique IDs
_MAX_ID_ATTEMPTS  = 10                                       # collision guard

_TANDEM_FEE_RATE = Decimal("0.035")    # 3.5 % platform commission
_IMTT_RATE       = Decimal("0.02")     # 2 % government levy (observer only)


def _generate_deal_id() -> str:
    """Return a random 5-character uppercase alphanumeric string."""
    return "".join(secrets.choice(_DEAL_ID_ALPHABET) for _ in range(_DEAL_ID_LENGTH))


def _unique_deal_id(db: Session) -> str:
    """Generate a deal_id that does not already exist in the database."""
    for _ in range(_MAX_ID_ATTEMPTS):
        candidate = _generate_deal_id()
        exists = db.query(Deal).filter(Deal.deal_id == candidate).first()
        if not exists:
            return candidate
    raise RuntimeError("Unable to generate a unique deal_id after multiple attempts")


def _calculate_monetary_breakdown(price: Decimal) -> dict:
    """
    Compute the full monetary breakdown for a deal where the seller is the
    sole recipient (merchant_gross = price, courier_gross = 0).

    Returns a dict compatible with the Escrow model's column names.
    """
    merchant_gross = price
    courier_gross  = Decimal("0.00")
    total_escrow   = price

    merchant_tandem_fee = (merchant_gross * _TANDEM_FEE_RATE).quantize(Decimal("0.01"))
    courier_tandem_fee  = Decimal("0.00")
    total_tandem_fee    = merchant_tandem_fee

    merchant_imtt_tax   = (merchant_gross * _IMTT_RATE).quantize(Decimal("0.01"))
    courier_imtt_tax    = Decimal("0.00")
    total_imtt_tax      = merchant_imtt_tax

    merchant_final_payout = merchant_gross - merchant_tandem_fee - merchant_imtt_tax
    courier_final_payout  = Decimal("0.00")

    return {
        "merchant_gross":          merchant_gross,
        "courier_gross":           courier_gross,
        "total_escrow":            total_escrow,
        "merchant_tandem_fee":     merchant_tandem_fee,
        "courier_tandem_fee":      courier_tandem_fee,
        "total_tandem_fee":        total_tandem_fee,
        "merchant_imtt_tax":       merchant_imtt_tax,
        "courier_imtt_tax":        courier_imtt_tax,
        "total_imtt_tax":          total_imtt_tax,
        "merchant_final_payout":   merchant_final_payout,
        "courier_final_payout":    courier_final_payout,
    }


# ---------------------------------------------------------------------------
# Public service functions
# ---------------------------------------------------------------------------


def create_deal(
    db: Session,
    seller_name: str,
    item_description: str,
    price: Decimal,
    wallet_phone: str,
    delivery_window_minutes: int = 120,
    seller_phone: Optional[str] = None,
    item_sku: Optional[str] = None,
    quantity: int = 1,
) -> Deal:
    """
    Create a new Protected Deal and persist it.

    No Escrow is created at this stage — that happens when the buyer's
    payment is detected via :func:`detect_payment`.

    If *seller_phone* and *item_sku* are provided, one unit of the SKU is
    reserved immediately so that it cannot be sold to another buyer while
    this deal is pending.

    Returns the persisted ``Deal`` instance.
    """
    deal_id = _unique_deal_id(db)

    deal = Deal(
        deal_id                 = deal_id,
        seller_name             = seller_name,
        item_description        = item_description,
        price                   = Decimal(str(price)),
        wallet_phone            = wallet_phone,
        delivery_window_minutes = delivery_window_minutes,
        status                  = DealStatus.CREATED,
        seller_phone            = seller_phone,
        item_sku                = item_sku,
        quantity                = quantity,
    )
    db.add(deal)
    db.flush()   # get deal.id before reserving

    # Reserve inventory immediately so no other deal can grab the same units
    if seller_phone and item_sku:
        inventory_service.reserve_stock(
            db,
            merchant_phone = seller_phone,
            sku            = item_sku,
            quantity       = quantity,
            deal_id        = deal.deal_id,
        )

    db.commit()
    db.refresh(deal)
    logger.info("Created deal %s for '%s' @ $%s", deal_id, item_description, price)
    return deal


def get_deal(db: Session, deal_id: str) -> Deal:
    """
    Return the Deal for *deal_id*.

    Raises:
        ValueError: if no deal with that ID exists.
    """
    deal = db.query(Deal).filter(Deal.deal_id == deal_id).first()
    if deal is None:
        raise ValueError(f"Deal '{deal_id}' not found")
    return deal


def detect_payment(
    db: Session,
    deal_id: str,
    payer_wallet: str,
    transaction_id: str,
    amount: Decimal,
) -> Deal:
    """
    Record that the buyer's wallet payment has been detected.

    This transitions the Deal from CREATED → HELD and creates the linked
    Escrow in HELD state with all monetary fields calculated from the deal
    price.

    Args:
        db:             Active SQLAlchemy session.
        deal_id:        The deal's short ID.
        payer_wallet:   Buyer's wallet number (now known).
        transaction_id: Reference returned by the wallet provider.
        amount:         Amount received (should match deal.price).

    Returns:
        Updated ``Deal`` instance.

    Raises:
        ValueError: If the deal is not in CREATED state or does not exist.
    """
    deal = get_deal(db, deal_id)

    if deal.status != DealStatus.CREATED:
        raise ValueError(
            f"Deal '{deal_id}' cannot accept payment in status '{deal.status.value}'"
        )

    # Build all monetary fields from the deal price
    monetary = _calculate_monetary_breakdown(deal.price)

    now        = datetime.now(UTC)
    expires_at = now + timedelta(minutes=deal.delivery_window_minutes)

    # Create the Escrow in HELD state
    escrow = Escrow(
        order_id                = deal.id,
        wallet_provider         = "paynow",
        external_transaction_id = transaction_id,
        payer_wallet_id         = payer_wallet,
        payee_wallet_id         = deal.wallet_phone,
        status                  = EscrowStatus.HELD,
        **monetary,
    )
    # Override the auto-calculated expiry to match the deal's delivery window
    escrow.expiry_timestamp = expires_at
    db.add(escrow)
    db.flush()   # get escrow.id before linking

    # Write the initial state log
    db.add(EscrowStateLog(
        escrow_id       = escrow.id,
        previous_status = "created",
        new_status      = EscrowStatus.HELD.value,
        triggered_by    = "payment_detected",
        metadata_json   = json.dumps({
            "deal_id":        deal_id,
            "transaction_id": transaction_id,
            "amount":         str(amount),
        }),
    ))

    # Link Escrow to Deal and transition Deal → HELD
    deal.escrow_id = escrow.id
    deal.status    = DealStatus.HELD
    deal.expires_at = expires_at

    db.commit()
    # Audit log — RBZ compliance
    from app.services.event_log_service import log_event
    try:
        log_event(db, deal_id, "PAYMENT_CONFIRMED", {
            "transaction_id": transaction_id,
            "amount":         str(amount),
            "payer_wallet":   payer_wallet,
        })
        db.commit()
    except Exception:
        pass  # log_event failure must never block payment confirmation
    db.refresh(deal)
    logger.info("Payment detected for deal %s — escrow %s created (HELD)", deal_id, escrow.id)
    return deal


def confirm_delivery(db: Session, deal_id: str) -> Deal:
    """
    Buyer confirms that the item was delivered.

    Transitions:
        Deal:   HELD → DELIVERED → COMPLETED
        Escrow: HELD → DELIVERED → RELEASED

    Returns:
        Updated ``Deal`` instance.

    Raises:
        ValueError: If the deal is not in HELD state or has no linked Escrow.
    """
    deal = get_deal(db, deal_id)

    # Task 3c: explicit EXPIRED guard — do not allow delivery confirmation after
    # the window has elapsed and funds have already been reversed.
    if deal.status == DealStatus.EXPIRED:
        raise ValueError(
            f"Deal '{deal_id}' has expired. The escrow window elapsed and any "
            f"funds have been reversed to the buyer. Please create a new deal."
        )
    if deal.status != DealStatus.HELD:
        raise ValueError(
            f"Deal '{deal_id}' cannot be confirmed in status '{deal.status.value}'"
        )
    if deal.escrow_id is None:
        raise ValueError(f"Deal '{deal_id}' has no linked escrow")

    escrow = db.get(Escrow, deal.escrow_id)
    now    = datetime.now(UTC)

    # Escrow: HELD → DELIVERED
    db.add(EscrowStateLog(
        escrow_id       = escrow.id,
        previous_status = EscrowStatus.HELD.value,
        new_status      = EscrowStatus.DELIVERED.value,
        triggered_by    = "buyer_confirmed_delivery",
        metadata_json   = json.dumps({"deal_id": deal_id}),
    ))
    escrow.status = EscrowStatus.DELIVERED

    # Escrow: DELIVERED → RELEASED
    db.add(EscrowStateLog(
        escrow_id       = escrow.id,
        previous_status = EscrowStatus.DELIVERED.value,
        new_status      = EscrowStatus.RELEASED.value,
        triggered_by    = "buyer_confirmed_delivery",
        metadata_json   = json.dumps({"deal_id": deal_id}),
    ))
    escrow.status = EscrowStatus.RELEASED

    # Deal: HELD → DELIVERED → COMPLETED
    deal.status       = DealStatus.COMPLETED
    deal.completed_at = now

    # Confirm the inventory sale — moves units from reserved → sold
    if deal.seller_phone and deal.item_sku:
        inventory_service.confirm_sale(
            db,
            merchant_phone = deal.seller_phone,
            sku            = deal.item_sku,
            quantity       = deal.quantity,
            escrow_id      = escrow.id,
            deal_id        = deal_id,
        )

    db.commit()
    # Audit log — RBZ compliance
    from app.services.event_log_service import log_event
    try:
        log_event(db, deal_id, "DELIVERY_CONFIRMED", {"deal_id": deal_id})
        db.commit()
    except Exception:
        pass
    db.refresh(deal)
    logger.info("Deal %s confirmed delivered and completed", deal_id)
    return deal


def build_share_url(deal: Deal, base_url: str) -> str:
    """Return the public buyer-facing URL for this deal."""
    return f"{base_url.rstrip('/')}/d/{deal.deal_id}"


def build_whatsapp_message(deal: Deal, share_url: str) -> str:
    """Return the suggested WhatsApp message the seller can copy-paste."""
    return (
        f"Let's do this as a Tofamba Protected Deal so we're both safe.\n\n"
        f"You send payment to my wallet as usual. Tofamba only completes the "
        f"transaction after delivery confirmation.\n\n"
        f"Deal link: {share_url}"
    )


# ---------------------------------------------------------------------------
# Task 3a — Webhook fallback: verify payment with Paynow before HELD transition
# ---------------------------------------------------------------------------

def poll_provider_status(
    db: Session,
    deal_id: str,
    external_transaction_id: str,
    wallet_adapter: WalletAdapter,
) -> dict:
    """
    Independently verify with the wallet provider that a payment is genuinely
    settled before transitioning a Deal to HELD.

    Called immediately after receiving a ``payment-detected`` webhook so that
    tampered or replayed webhooks cannot fraudulently unlock escrow funds.

    Workflow:
        1. Fetch the deal and confirm it is in CREATED state.
        2. Call ``wallet_adapter.query_transaction_status(external_transaction_id)``.
        3. If the provider confirms the payment: return ``{"verified": True}``.
        4. If the provider reports the payment as pending or failed: log a
           warning and return ``{"verified": False, "status_raw": ...}`` — the
           caller should NOT proceed with ``detect_payment()``.

    Args:
        db:                       Active SQLAlchemy session.
        deal_id:                  Short deal identifier.
        external_transaction_id:  Transaction reference to verify with provider.
        wallet_adapter:           Adapter connected to the correct wallet provider.

    Returns:
        {
            "verified":   bool,   # True only when provider confirms settlement
            "status_raw": str,    # Provider's original status string
            "deal_id":    str,
        }

    Raises:
        ValueError: If the deal does not exist or is not in CREATED state.
    """
    deal = get_deal(db, deal_id)

    if deal.status != DealStatus.CREATED:
        raise ValueError(
            f"Deal '{deal_id}' is already in '{deal.status.value}' — "
            f"poll_provider_status() only applies to CREATED deals."
        )

    result = wallet_adapter.query_transaction_status(external_transaction_id)

    if result.get("confirmed"):
        logger.info(
            "Provider verification PASSED for deal %s | tx=%s status=%s",
            deal_id, external_transaction_id, result.get("status_raw"),
        )
        return {"verified": True, "status_raw": result.get("status_raw", ""), "deal_id": deal_id}

    logger.warning(
        "Provider verification FAILED for deal %s | tx=%s status=%s — "
        "webhook may be premature or fraudulent; deal stays CREATED.",
        deal_id, external_transaction_id, result.get("status_raw"),
    )
    return {"verified": False, "status_raw": result.get("status_raw", "unconfirmed"), "deal_id": deal_id}


# ---------------------------------------------------------------------------
# Task 3b — Merchant Proof-of-Life: fast-track cancellation
# ---------------------------------------------------------------------------

_MERCHANT_ACK_WINDOW_MINUTES = 15


def is_merchant_ack_overdue(deal: Deal) -> bool:
    """
    Return True if the merchant has not acknowledged the deal within 15 minutes
    of creation — triggering the Proof-of-Life alert.

    SQLite stores DateTime(timezone=True) as naive UTC; PostgreSQL returns
    timezone-aware values.  We normalise both to naive UTC for a consistent
    comparison across dialects.
    """
    if deal.merchant_acknowledged:
        return False
    if deal.status != DealStatus.CREATED:
        return False

    created = deal.created_at
    # Normalise to naive UTC (strips tzinfo if present)
    if getattr(created, "tzinfo", None) is not None:
        created = created.replace(tzinfo=None)
    deadline = created + timedelta(minutes=_MERCHANT_ACK_WINDOW_MINUTES)
    return datetime.utcnow() >= deadline


def fast_track_cancel(db: Session, deal_id: str) -> Deal:
    """
    Allow a buyer to cancel a deal that the merchant has not acknowledged
    within the 15-minute Proof-of-Life window.

    Eligibility requirements (all must be true):
        - Deal is in CREATED state (no payment yet — nothing to reverse).
        - ``merchant_acknowledged`` is False.
        - ``created_at + 15 min`` has elapsed.

    On success:
        - Deal transitions CREATED → CANCELLED.
        - Any inventory reservation is released.
        - An EscrowStateLog row is written (escrow_id=NULL, no Escrow exists yet).

    Args:
        db:       Active SQLAlchemy session.
        deal_id:  Short deal identifier.

    Returns:
        Updated ``Deal`` instance.

    Raises:
        ValueError: If the deal is ineligible for fast-track cancellation.
    """
    deal = get_deal(db, deal_id)

    if deal.status != DealStatus.CREATED:
        raise ValueError(
            f"Deal '{deal_id}' is in status '{deal.status.value}'. "
            f"Fast-track cancellation only applies to CREATED deals."
        )
    if deal.merchant_acknowledged:
        raise ValueError(
            f"Deal '{deal_id}' has already been acknowledged by the merchant "
            f"and cannot be fast-track cancelled."
        )
    if not is_merchant_ack_overdue(deal):
        deadline = deal.created_at + timedelta(minutes=_MERCHANT_ACK_WINDOW_MINUTES)
        raise ValueError(
            f"The 15-minute acknowledgement window for deal '{deal_id}' has not "
            f"yet elapsed (deadline: {deadline.isoformat()}). Please wait."
        )

    # Release any inventory reservation
    if deal.seller_phone and deal.item_sku:
        try:
            inventory_service.release_reservation(
                db,
                merchant_phone = deal.seller_phone,
                sku            = deal.item_sku,
                quantity       = deal.quantity,
                deal_id        = deal_id,
            )
        except Exception as exc:
            logger.error(
                "Failed to release inventory on fast-track cancel for deal %s: %s",
                deal_id, exc,
            )

    deal.status       = DealStatus.CANCELLED
    deal.completed_at = datetime.now(UTC)

    db.add(EscrowStateLog(
        escrow_id       = None,   # No escrow exists for CREATED deals
        previous_status = DealStatus.CREATED.value,
        new_status      = DealStatus.CANCELLED.value,
        triggered_by    = "buyer_fast_track_cancel",
        metadata_json   = json.dumps({
            "deal_id":              deal_id,
            "reason":               "merchant_proof_of_life_timeout",
            "ack_window_minutes":   _MERCHANT_ACK_WINDOW_MINUTES,
        }),
    ))

    db.commit()
    # Audit log — RBZ compliance
    from app.services.event_log_service import log_event
    try:
        log_event(db, deal_id, "DEAL_CANCELLED", {
            "reason": "merchant_proof_of_life_timeout",
        })
        db.commit()
    except Exception:
        pass
    db.refresh(deal)
    logger.info(
        "Deal %s fast-track cancelled by buyer — merchant did not acknowledge within %d min",
        deal_id, _MERCHANT_ACK_WINDOW_MINUTES,
    )
    return deal


def acknowledge_deal(db: Session, deal_id: str) -> Deal:
    """
    Merchant acknowledges a deal, suppressing the Proof-of-Life alert.

    Sets ``merchant_acknowledged = True``.  Can be called from the WhatsApp
    bot (merchant replies to the deal notification) or from a REST endpoint.

    Args:
        db:       Active SQLAlchemy session.
        deal_id:  Short deal identifier.

    Returns:
        Updated ``Deal`` instance.

    Raises:
        ValueError: If the deal is not found or not in CREATED/HELD state.
    """
    deal = get_deal(db, deal_id)
    if deal.status not in (DealStatus.CREATED, DealStatus.HELD):
        raise ValueError(
            f"Deal '{deal_id}' is in '{deal.status.value}' — "
            f"acknowledgement only valid for CREATED or HELD deals."
        )
    deal.merchant_acknowledged = True
    db.commit()
    db.refresh(deal)
    logger.info("Merchant acknowledged deal %s", deal_id)
    return deal
