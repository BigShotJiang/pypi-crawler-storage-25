"""
Inventory service — manages MerchantInventory stock levels and audit logging.

All mutating operations are atomic within the caller's DB session.  The caller
is responsible for commit / rollback.

Stock quantity model
--------------------
quantity_available  Total units stocked by the merchant
quantity_reserved   Units held for pending deals (CREATED or HELD state)
quantity_sold       Cumulative units fully delivered (immutable counter)
quantity_free       (property) = available − reserved  ← governs deal eligibility

Lifecycle
---------
1. Merchant adds/updates item   → quantity_available set; logs "inventory_updated"
2. Deal CREATED with SKU        → quantity_reserved += qty; logs "inventory_reserved"
3. Deal DELIVERED → RELEASED    → quantity_available -= qty; quantity_reserved -= qty;
                                   quantity_sold += qty; logs "inventory_sold"
4. Deal EXPIRED (timeout)       → quantity_reserved -= qty; logs "inventory_released"
5. Low-stock check              → alerts when quantity_available <= reorder_level;
                                   logs "low_stock_alert"
"""

import json
import logging
from datetime import datetime, UTC
from decimal import Decimal
from typing import Callable, Dict, List, Optional

from sqlalchemy.orm import Session

from app.models.database import EscrowStateLog, MerchantInventory

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _log(
    db: Session,
    triggered_by: str,
    item: MerchantInventory,
    previous_qty: int,
    new_qty: int,
    escrow_id: Optional[int] = None,
    extra: Optional[dict] = None,
) -> None:
    """Write one EscrowStateLog row for an inventory event."""
    meta = {
        "merchant_phone": item.merchant_phone,
        "sku":            item.sku,
        "item_name":      item.item_name,
        "qty_change":     new_qty - previous_qty,
    }
    if extra:
        meta.update(extra)

    db.add(EscrowStateLog(
        escrow_id       = escrow_id,
        previous_status = str(previous_qty),
        new_status      = str(new_qty),
        triggered_by    = triggered_by,
        metadata_json   = json.dumps(meta),
    ))


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------

def add_or_update_item(
    db: Session,
    merchant_phone: str,
    sku: str,
    item_name: str,
    price: Decimal,
    quantity_available: int,
    reorder_level: int = 5,
    item_description: Optional[str] = None,
    item_picture_url: Optional[str] = None,
) -> MerchantInventory:
    """
    Upsert a catalogue item for *merchant_phone*.

    If the SKU already exists, updates all mutable fields (price, name,
    description, picture, quantity, reorder_level).  The quantity_reserved
    and quantity_sold counters are never reset by this call.

    Returns the persisted ``MerchantInventory`` instance.
    """
    existing = (
        db.query(MerchantInventory)
        .filter_by(merchant_phone=merchant_phone, sku=sku)
        .first()
    )

    if existing:
        prev_qty = existing.quantity_available
        existing.item_name          = item_name
        existing.item_description   = item_description
        existing.item_picture_url   = item_picture_url
        existing.price              = Decimal(str(price))
        existing.quantity_available = quantity_available
        existing.reorder_level      = reorder_level
        existing.last_updated       = datetime.now(UTC)
        db.flush()
        _log(db, "inventory_updated", existing, prev_qty, quantity_available)
        logger.info("Updated inventory %s/%s → qty %s", merchant_phone, sku, quantity_available)
        return existing

    item = MerchantInventory(
        merchant_phone     = merchant_phone,
        sku                = sku,
        item_name          = item_name,
        item_description   = item_description,
        item_picture_url   = item_picture_url,
        price              = Decimal(str(price)),
        quantity_available = quantity_available,
        quantity_reserved  = 0,
        quantity_sold      = 0,
        reorder_level      = reorder_level,
    )
    db.add(item)
    db.flush()
    _log(db, "inventory_updated", item, 0, quantity_available)
    logger.info("Created inventory %s/%s qty %s", merchant_phone, sku, quantity_available)
    return item


def get_item(db: Session, merchant_phone: str, sku: str) -> MerchantInventory:
    """
    Return the MerchantInventory record for *(merchant_phone, sku)*.

    Raises:
        ValueError: if the SKU does not exist for this merchant.
    """
    item = (
        db.query(MerchantInventory)
        .filter_by(merchant_phone=merchant_phone, sku=sku)
        .first()
    )
    if item is None:
        raise ValueError(f"SKU '{sku}' not found for merchant '{merchant_phone}'")
    return item


def list_items(
    db: Session,
    merchant_phone: str,
    in_stock_only: bool = False,
) -> List[MerchantInventory]:
    """
    Return all inventory items for *merchant_phone*.

    Args:
        in_stock_only: If True, only return items where quantity_free > 0.
    """
    q = db.query(MerchantInventory).filter_by(merchant_phone=merchant_phone)
    items = q.order_by(MerchantInventory.item_name).all()
    if in_stock_only:
        items = [i for i in items if i.quantity_free > 0]
    return items


def get_catalogue(db: Session, merchant_phone: str) -> List[MerchantInventory]:
    """
    Return items with quantity_free > 0 — suitable for the public catalogue.
    """
    return list_items(db, merchant_phone, in_stock_only=True)


def search_items(
    db: Session,
    merchant_phone: str,
    query: str,
) -> List[MerchantInventory]:
    """
    Case-insensitive substring search across item_name for *merchant_phone*.
    Only returns items with quantity_free > 0.
    """
    all_items = list_items(db, merchant_phone, in_stock_only=True)
    q = query.lower()
    return [i for i in all_items if q in i.item_name.lower()]


# ---------------------------------------------------------------------------
# Stock mutations
# ---------------------------------------------------------------------------

def reserve_stock(
    db: Session,
    merchant_phone: str,
    sku: str,
    quantity: int = 1,
    escrow_id: Optional[int] = None,
    deal_id: Optional[str] = None,
) -> MerchantInventory:
    """
    Reserve *quantity* units for a pending deal.

    quantity_reserved += quantity

    Raises:
        ValueError: if quantity_free < quantity (out of stock / insufficient).
    """
    item = get_item(db, merchant_phone, sku)
    if item.quantity_free < quantity:
        raise ValueError(
            f"Insufficient stock for '{sku}': "
            f"{item.quantity_free} free, {quantity} requested"
        )
    prev = item.quantity_reserved
    item.quantity_reserved += quantity
    item.last_updated = datetime.now(UTC)
    db.flush()
    _log(db, "inventory_reserved", item, prev, item.quantity_reserved,
         escrow_id=escrow_id, extra={"deal_id": deal_id, "qty_reserved": quantity})
    logger.info("Reserved %s units of %s/%s", quantity, merchant_phone, sku)
    return item


def release_reservation(
    db: Session,
    merchant_phone: str,
    sku: str,
    quantity: int = 1,
    escrow_id: Optional[int] = None,
    deal_id: Optional[str] = None,
) -> MerchantInventory:
    """
    Release a previously held reservation (deal expired / cancelled).

    quantity_reserved -= quantity
    """
    item = get_item(db, merchant_phone, sku)
    prev = item.quantity_reserved
    item.quantity_reserved = max(0, item.quantity_reserved - quantity)
    item.last_updated = datetime.now(UTC)
    db.flush()
    _log(db, "inventory_released", item, prev, item.quantity_reserved,
         escrow_id=escrow_id, extra={"deal_id": deal_id, "qty_released": quantity})
    logger.info("Released %s units of %s/%s", quantity, merchant_phone, sku)
    return item


def confirm_sale(
    db: Session,
    merchant_phone: str,
    sku: str,
    quantity: int = 1,
    escrow_id: Optional[int] = None,
    deal_id: Optional[str] = None,
) -> MerchantInventory:
    """
    Confirm a completed sale (deal delivered and released).

    quantity_available -= quantity
    quantity_reserved  -= quantity
    quantity_sold      += quantity
    """
    item = get_item(db, merchant_phone, sku)
    prev_avail = item.quantity_available
    item.quantity_available = max(0, item.quantity_available - quantity)
    item.quantity_reserved  = max(0, item.quantity_reserved  - quantity)
    item.quantity_sold      += quantity
    item.last_updated = datetime.now(UTC)
    db.flush()
    _log(db, "inventory_sold", item, prev_avail, item.quantity_available,
         escrow_id=escrow_id, extra={"deal_id": deal_id, "qty_sold": quantity})
    logger.info("Confirmed sale of %s units of %s/%s", quantity, merchant_phone, sku)
    return item


# ---------------------------------------------------------------------------
# Low-stock detection
# ---------------------------------------------------------------------------

def get_low_stock_items(
    db: Session,
    merchant_phone: Optional[str] = None,
) -> List[MerchantInventory]:
    """
    Return items where quantity_available <= reorder_level.

    If *merchant_phone* is given, only that merchant's items are checked.
    """
    q = db.query(MerchantInventory).filter(
        MerchantInventory.quantity_available <= MerchantInventory.reorder_level
    )
    if merchant_phone:
        q = q.filter_by(merchant_phone=merchant_phone)
    return q.all()


def send_low_stock_alerts(
    db: Session,
    notifier: Optional[Callable[[str, str], bool]] = None,
    merchant_phone: Optional[str] = None,
) -> Dict:
    """
    Check for low-stock items and send WhatsApp alerts.

    Args:
        db:             Active SQLAlchemy session.
        notifier:       Callable ``(phone, message) -> bool``.  If None,
                        alerts are logged but not sent (useful for testing).
        merchant_phone: If given, restrict check to one merchant.

    Returns:
        ``{"checked": N, "alerts_sent": M}``
    """
    items = get_low_stock_items(db, merchant_phone=merchant_phone)
    alerts_sent = 0

    for item in items:
        message = (
            f"⚠️ *Low Stock Alert*\n\n"
            f"Item: *{item.item_name}* (SKU: {item.sku})\n"
            f"Available: *{item.quantity_available}* units\n"
            f"Reorder level: {item.reorder_level}\n\n"
            f"Top up your stock to keep selling!"
        )

        sent = False
        if notifier:
            try:
                sent = notifier(item.merchant_phone, message)
            except Exception as exc:
                logger.error("Failed to send low-stock alert to %s: %s",
                             item.merchant_phone, exc)

        # Log the alert regardless of send success
        db.add(EscrowStateLog(
            escrow_id       = None,
            previous_status = str(item.quantity_available),
            new_status      = str(item.quantity_available),
            triggered_by    = "low_stock_alert",
            metadata_json   = json.dumps({
                "merchant_phone":     item.merchant_phone,
                "sku":                item.sku,
                "item_name":          item.item_name,
                "quantity_available": item.quantity_available,
                "reorder_level":      item.reorder_level,
                "alert_sent":         sent,
            }),
        ))
        if sent:
            alerts_sent += 1
        logger.info("Low-stock alert for %s/%s (qty=%s)",
                    item.merchant_phone, item.sku, item.quantity_available)

    db.flush()
    return {"checked": len(items), "alerts_sent": alerts_sent}
