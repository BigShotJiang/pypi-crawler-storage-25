"""
app/services/event_log_service.py

Append-only audit event logger — required for RBZ compliance.

Call log_event() from every critical deal action:
    PAYMENT_CONFIRMED, COURIER_ASSIGNED, DISPUTE_OPENED,
    DISPUTE_RESOLVED, RELEASE_TRIGGERED, DEAL_CANCELLED, etc.

Design:
- Never raises: if DB write fails, logs the error and returns.
- DB is the only store (no Redis — this is the immutable truth).
- Idempotency: multiple calls with same type are fine (append-only).
"""

import json
import logging
from datetime import datetime, UTC
from typing import Optional

from sqlalchemy.orm import Session

from app.models.database import DealEvent

logger = logging.getLogger(__name__)


def log_event(
    db: Session,
    deal_id: str,
    event_type: str,
    payload: Optional[dict] = None,
) -> None:
    """
    Append a DealEvent row for the given deal.

    Guarantees:
    - Never raises — errors are logged and swallowed.
    - Uses db.flush() (not commit) so caller controls the transaction.
    - Caller must commit after calling this (or it will flush with the
      next commit in the calling function).

    Args:
        db:         Active SQLAlchemy session.
        deal_id:    The 5-char deal identifier.
        event_type: e.g. "PAYMENT_CONFIRMED", "DISPUTE_OPENED"
        payload:    Optional dict — serialised to JSON string.
    """
    try:
        event = DealEvent(
            deal_id    = deal_id,
            event_type = event_type,
            payload    = json.dumps(payload or {}),
            created_at = datetime.now(UTC),
        )
        db.add(event)
        db.flush()
        logger.info("[AuditLog] %s | deal=%s", event_type, deal_id)
    except Exception as exc:
        logger.error(
            "[AuditLog] Failed to write %s for deal %s: %s",
            event_type, deal_id, exc,
        )
