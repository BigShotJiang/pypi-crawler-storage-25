# app/bot/handlers/payment_wait.py
"""
AWAITING_PAYMENT state handler.

The user has confirmed their order.  AnchorFlow is waiting for Paynow
(or another wallet provider) to confirm the payment.

While waiting, the user may:
  - Check their deal status ("status", "check")
  - Cancel the deal ("cancel") — only allowed before payment is confirmed
  - Resend the payment link ("resend")
  - Do nothing (most common case — they've gone to pay)

Payment confirmation is NOT handled here.  It arrives via the separate
payment webhook endpoint and calls BotEngine.on_payment_confirmed() which
directly advances the state to DEAL_CREATED.

This handler therefore focuses only on USER-initiated messages while
the bot is in AWAITING_PAYMENT.
"""

import logging
from typing import Optional

from sqlalchemy.orm import Session

from app.bot.handlers import HandlerResult
from app.bot.state_manager import RedisStateManager

logger = logging.getLogger(__name__)

# ── Copy ──────────────────────────────────────────────────────────────────────

_STATUS_PENDING = (
    "⏳ *Payment pending*\n\n"
    "Reference: *{ref}*\n"
    "Total:     *US${total:.2f}*\n\n"
    "We haven't received your payment yet. Please complete the payment on "
    "EcoCash or Paynow and we'll notify you immediately.\n\n"
    "Type *cancel* if you'd like to abandon this order."
)

_STATUS_CANCELLED = (
    "❌ Order *{ref}* has been cancelled.\n\n"
    "Type *1* to start a new order."
)

_RESEND_LINK = (
    "💳 Payment details for *{ref}*:\n\n"
    "Amount: *US${total:.2f}*\n\n"
    "Please send payment via EcoCash or Paynow. We're watching! 👀"
)

_CANCEL_CONFIRM = (
    "Are you sure you want to cancel order *{ref}*?\n\n"
    "Type *yes* to confirm cancellation, or *no* to keep waiting."
)


async def handle_payment_wait(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """
    Handle AWAITING_PAYMENT state.

    The bot sits here waiting for the payment webhook.  User messages
    are limited to status checks, link resend, and cancellation.
    """
    text = message.strip().lower()
    ref  = sm.get_active_deal(phone) or "unknown"

    # Load order for amount display
    order = sm.get_order(phone) or {}
    total = sum(float(i.get("price", 0)) for i in order.get("items", []))

    # ── Status / help ─────────────────────────────────────────────────────────
    if text in ("status", "check", "?", "help", "menu"):
        return HandlerResult(
            next_state="AWAITING_PAYMENT",
            response=_STATUS_PENDING.format(ref=ref, total=total),
        )

    # ── Resend payment link ───────────────────────────────────────────────────
    if text in ("resend", "link", "pay", "payment"):
        return HandlerResult(
            next_state="AWAITING_PAYMENT",
            response=_RESEND_LINK.format(ref=ref, total=total),
        )

    # ── Cancellation flow ─────────────────────────────────────────────────────
    if text in ("cancel", "stop", "abort"):
        # Store cancellation intent in temp, ask to confirm
        sm.set_temp(phone, "cancel_intent", "yes")
        return HandlerResult(
            next_state="AWAITING_PAYMENT",
            response=_CANCEL_CONFIRM.format(ref=ref),
        )

    if text in ("yes", "confirm") and sm.get_temp(phone, "cancel_intent") == "yes":
        # Execute cancellation
        sm.clear_order(phone)
        sm.set_state(phone, "BROWSING")
        sm.set_temp(phone, "cancel_intent", "")

        # DB: mark deal as cancelled (stub)
        _cancel_deal_record(db, ref)

        logger.info("deal_cancelled ref=%s phone_hash=%s", ref, hash(phone) % 100_000)
        return HandlerResult(
            next_state="BROWSING",
            response=_STATUS_CANCELLED.format(ref=ref),
            metadata={"deal_ref": ref, "action": "cancelled"},
        )

    if text in ("no",) and sm.get_temp(phone, "cancel_intent") == "yes":
        sm.set_temp(phone, "cancel_intent", "")
        return HandlerResult(
            next_state="AWAITING_PAYMENT",
            response=_STATUS_PENDING.format(ref=ref, total=total),
        )

    # ── Anything else — gentle reminder to pay ────────────────────────────────
    return HandlerResult(
        next_state="AWAITING_PAYMENT",
        response=(
            "We're waiting for your payment! 💳\n\n"
            f"Reference: *{ref}*\n\n"
            "Type *status* to check, *resend* for payment details, or *cancel* to stop."
        ),
    )


def _cancel_deal_record(db: Optional[Session], ref: str) -> None:
    """Mark the deal as cancelled in PostgreSQL. Stub — expand when Deal model is live."""
    if db is None:
        return
    try:
        logger.info("deal_cancel_db_write ref=%s", ref)
        # Real: db.query(Deal).filter(Deal.ref == ref).update({"status": "CANCELLED"})
        # db.commit()
    except Exception as exc:
        logger.error("_cancel_deal_record failed [%s]: %s", ref, exc)
