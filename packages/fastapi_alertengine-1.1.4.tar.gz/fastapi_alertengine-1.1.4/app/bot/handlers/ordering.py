# app/bot/handlers/ordering.py
"""
ORDERING state handler.

User is browsing a merchant catalogue and building a basket.

Flow:
  ORDERING
    number        → add item to basket, show updated basket
    "checkout"    → validate basket non-empty → CONFIRMING_ORDER
    "clear"       → empty basket, stay in ORDERING
    "0" / "back"  → return to BROWSING
    else          → re-show catalogue with gentle nudge

Confirming order:
  CONFIRMING_ORDER
    "yes" / "confirm"  → create deal → AWAITING_PAYMENT
    "no"  / "cancel"   → clear basket → BROWSING
"""

import json
import logging
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.bot.handlers import HandlerResult
from app.bot.state_manager import RedisStateManager

logger = logging.getLogger(__name__)

# ── Copy ──────────────────────────────────────────────────────────────────────

_BASKET_TEMPLATE = (
    "🛒 *Your basket*\n\n"
    "{lines}\n\n"
    "Total: *US${total:.2f}*\n\n"
    "Type a number to add more, *checkout* to pay, or *clear* to start over."
)

_CONFIRM_TEMPLATE = (
    "✅ *Confirm your order?*\n\n"
    "{lines}\n\n"
    "Total: *US${total:.2f}*\n\n"
    "Type *yes* to confirm and receive a payment link, or *no* to cancel."
)

_PAYMENT_LINK_TEMPLATE = (
    "💳 *Payment required*\n\n"
    "Order total: *US${total:.2f}*\n"
    "Reference:   *{ref}*\n\n"
    "Please send payment via EcoCash / Paynow to the number you'll receive shortly.\n\n"
    "We'll notify you as soon as payment is confirmed. ⏳"
)


# ── Basket helpers ────────────────────────────────────────────────────────────

def _format_basket(items: List[Dict]) -> str:
    if not items:
        return "Your basket is empty."
    lines = []
    for i, item in enumerate(items, start=1):
        lines.append(f"  {i}. {item['name']}  —  US${item['price']:.2f}")
    return "\n".join(lines)


def _basket_total(items: List[Dict]) -> float:
    return sum(float(i.get("price", 0)) for i in items)


def _find_catalogue_item(idx_or_name: str, catalogue_items: List[Dict]) -> Optional[Dict]:
    text = idx_or_name.strip()
    if text.isdigit():
        idx = int(text) - 1
        if 0 <= idx < len(catalogue_items):
            return catalogue_items[idx]
        return None
    lower = text.lower()
    for item in catalogue_items:
        if lower in item.get("name", "").lower():
            return item
    return None


def _load_catalogue_items(slug: str, sm: RedisStateManager) -> List[Dict]:
    """Load catalogue items from Redis cache."""
    cat = sm.get_catalogue(slug)
    if isinstance(cat, dict):
        return cat.get("items", [])
    return []


# ── Deal creation ─────────────────────────────────────────────────────────────

def _generate_deal_ref(phone: str) -> str:
    """Generate a short, human-readable deal reference."""
    import hashlib, time
    raw = f"{phone}{int(time.time() * 1000)}"
    return "TDM-" + hashlib.md5(raw.encode()).hexdigest()[:6].upper()


def _create_deal_record(
    db: Session,
    phone: str,
    order: Dict,
    ref: str,
) -> Optional[Any]:
    """
    Write deal to PostgreSQL.

    Returns the Escrow ORM object on success, None if DB unavailable.
    This is a stub that can be filled in once the Deal model is finalised.
    """
    try:
        # Real implementation: create Deal + Escrow rows, link to merchant
        # For now: log intent and return None (DB write deferred)
        logger.info(
            "deal_create ref=%s phone=%s total=%.2f merchant=%s",
            ref, phone, _basket_total(order.get("items", [])), order.get("merchant_slug"),
        )
        return None   # Swap for Escrow ORM object once Deal model is live
    except Exception as exc:
        logger.error("_create_deal_record failed [%s]: %s", ref, exc)
        return None


# ── Ordering handler ──────────────────────────────────────────────────────────

async def handle_ordering(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """Handle ORDERING state — basket management."""
    text  = message.strip().lower()
    order = sm.get_order(phone) or {}
    items: List[Dict] = order.get("items", [])
    slug  = order.get("merchant_slug", "")

    # Back to menu
    if text in ("0", "back", "menu", "cancel"):
        sm.clear_order(phone)
        sm.set_state(phone, "BROWSING")
        return HandlerResult(
            next_state="BROWSING",
            response="Returning to the main menu. Type *1* to browse merchants.",
        )

    # Clear basket
    if text in ("clear", "empty", "reset"):
        order["items"] = []
        sm.save_order(phone, order)
        return HandlerResult(
            next_state="ORDERING",
            response="🗑️ Basket cleared. Type an item number to add something.",
        )

    # Proceed to confirm
    if text in ("checkout", "buy", "pay", "confirm", "done"):
        if not items:
            return HandlerResult(
                next_state="ORDERING",
                response="Your basket is empty. Add some items first! 🛒",
            )
        sm.set_state(phone, "CONFIRMING_ORDER")
        return HandlerResult(
            next_state="CONFIRMING_ORDER",
            response=_CONFIRM_TEMPLATE.format(
                lines=_format_basket(items),
                total=_basket_total(items),
            ),
        )

    # Add item by number or name
    catalogue_items = _load_catalogue_items(slug, sm)
    item = _find_catalogue_item(text, catalogue_items)
    if item:
        items.append({"name": item["name"], "price": float(item.get("price", 0))})
        order["items"] = items
        sm.save_order(phone, order)
        return HandlerResult(
            next_state="ORDERING",
            response=_BASKET_TEMPLATE.format(
                lines=_format_basket(items),
                total=_basket_total(items),
            ),
            metadata={"item_added": item["name"]},
        )

    # Unrecognised
    return HandlerResult(
        next_state="ORDERING",
        response=(
            "Type an item *number* to add it, *checkout* to pay, or *0* to go back."
        ),
    )


async def handle_confirming(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """Handle CONFIRMING_ORDER state — user says yes or no."""
    text  = message.strip().lower()
    order = sm.get_order(phone) or {}
    items = order.get("items", [])

    if text in ("no", "cancel", "back"):
        sm.clear_order(phone)
        sm.set_state(phone, "BROWSING")
        return HandlerResult(
            next_state="BROWSING",
            response="Order cancelled. Type *1* to start shopping again.",
        )

    if text in ("yes", "confirm", "ok", "y"):
        ref = _generate_deal_ref(phone)
        total = _basket_total(items)

        # DB write (stub)
        _create_deal_record(db, phone, order, ref)

        # Map payment ref → phone so payment webhook can find the session
        sm.map_deal_ref(ref, phone)
        sm.set_active_deal(phone, ref)
        sm.set_state(phone, "AWAITING_PAYMENT")

        return HandlerResult(
            next_state="AWAITING_PAYMENT",
            response=_PAYMENT_LINK_TEMPLATE.format(total=total, ref=ref),
            metadata={"deal_ref": ref, "total": total},
        )

    return HandlerResult(
        next_state="CONFIRMING_ORDER",
        response="Type *yes* to confirm and pay, or *no* to cancel.",
    )
