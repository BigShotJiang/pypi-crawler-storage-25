# app/bot/handlers/__init__.py
"""
State handlers for the AnchorFlow bot runtime.

Each handler corresponds to one or more bot states and has the signature:

    async def handle_<name>(
        phone:   str,
        message: str,
        sm:      RedisStateManager,
        db:      Session,
    ) -> HandlerResult

Handlers are pure orchestrators — they read/write state via RedisStateManager,
query/write the database via the injected Session, and return (next_state,
response_text).  They never call Redis or SQLAlchemy directly.
"""

from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class HandlerResult:
    """
    Returned by every state handler.

    Attributes:
        next_state: BotState name to transition to after this handler runs.
        response:   Plain-text reply to send to the user over WhatsApp.
        metadata:   Optional dict of extra context (logged to metrics stream).
    """
    next_state: str
    response: str
    metadata: Dict[str, Any] = field(default_factory=dict)
