# app/bot/handlers/browsing.py
"""
BROWSING state handler — fully implemented.

Covers two states:
  START    — greet the user, present the main menu
  BROWSING — user is selecting a merchant or asking what's available

Flow:
  START / BROWSING
    "1" or "shop"          → show merchant list → stay BROWSING
    "2" or "sell"          → set role=merchant  → MERCHANT_PORTAL
    "3" or "deliver"       → set role=courier   → COURIER_PORTAL
    merchant slug / name   → load catalogue     → ORDERING
    "help" / "menu" / "0"  → show main menu     → BROWSING
    anything else          → gentle nudge        → BROWSING (no state change)

The handler is intentionally simple and keyword-driven.  Claude AI
enrichment (natural language parsing) is added at the engine level
before dispatching here — this handler only sees normalised intent.
"""

import logging
from typing import Optional

from sqlalchemy.orm import Session

from app.bot.handlers import HandlerResult
from app.bot.state_manager import RedisStateManager

logger = logging.getLogger(__name__)

# ── Static copy ───────────────────────────────────────────────────────────────

_GREETING = (
    "👋 Welcome to *AnchorFlow* — Zimbabwe's trusted commerce network.\n\n"
    "How can I help you today?\n\n"
    "  *1* — Shop (buy goods)\n"
    "  *2* — Sell (merchant portal)\n"
    "  *3* — Deliver (courier portal)\n\n"
    "Reply with a number or type what you need."
)

_MENU = (
    "🏠 *Main Menu*\n\n"
    "  *1* — Browse merchants\n"
    "  *2* — Merchant portal\n"
    "  *3* — Courier portal\n"
    "  *0* — This menu\n\n"
    "Type the number or a merchant name."
)

_MERCHANTS_LOADING = (
    "🛒 Loading merchants near you...\n\n"
    "{merchants}\n\n"
    "Type a *name* or *number* to browse their catalogue."
)

_CATALOGUE_INTRO = (
    "🏪 *{merchant_name}*\n\n"
    "{items}\n\n"
    "Type an item *number* to add it to your order, or *0* to go back."
)

_UNKNOWN = (
    "I didn't quite catch that. 😊\n\n"
    "Type *menu* to see your options, or reply with a merchant name to start shopping."
)


# ── Merchant list helpers ─────────────────────────────────────────────────────

def _format_merchant_list(merchants: list) -> str:
    """Format a list of merchant dicts into a numbered WhatsApp-friendly string."""
    if not merchants:
        return "No merchants available right now. Check back soon!"
    lines = []
    for idx, m in enumerate(merchants, start=1):
        name = m.get("name", "Unknown")
        category = m.get("category", "")
        lines.append(f"  *{idx}* — {name}" + (f" ({category})" if category else ""))
    return "\n".join(lines)


def _format_catalogue(items: list) -> str:
    """Format catalogue items into a numbered WhatsApp-friendly string."""
    if not items:
        return "This merchant has no items listed yet."
    lines = []
    for idx, item in enumerate(items, start=1):
        name  = item.get("name", "Item")
        price = item.get("price", "?")
        lines.append(f"  *{idx}* — {name}  •  US${price}")
    return "\n".join(lines)


def _find_merchant_by_input(text: str, merchants: list) -> Optional[dict]:
    """
    Match user input to a merchant by number or partial name (case-insensitive).
    Returns the merchant dict or None.
    """
    text = text.strip()

    # Numeric selection
    if text.isdigit():
        idx = int(text) - 1
        if 0 <= idx < len(merchants):
            return merchants[idx]
        return None

    # Partial name match
    lower = text.lower()
    for m in merchants:
        if lower in m.get("name", "").lower() or lower in m.get("slug", "").lower():
            return m
    return None


# ── Fallback merchant list (used when DB is unavailable) ─────────────────────
# In production this is replaced by a DB query in _load_merchants().

_FALLBACK_MERCHANTS = [
    {"name": "Harare Fresh Market", "slug": "harare-fresh", "category": "Groceries"},
    {"name": "TechZone Zimbabwe",   "slug": "techzone-zw",  "category": "Electronics"},
    {"name": "Mama's Kitchen",      "slug": "mamas-kitchen","category": "Food"},
]


def _load_merchants(db: Optional[Session]) -> list:
    """
    Load merchant list from DB (Merchant table).

    Falls back to _FALLBACK_MERCHANTS if DB is unavailable or returns nothing.
    Only returns active merchants with at least one published item.
    """
    if db is None:
        return _FALLBACK_MERCHANTS

    try:
        from app.models.database import Merchant  # type: ignore[attr-defined]
        rows = (
            db.query(Merchant)
            .filter(Merchant.is_active.is_(True))  # type: ignore[union-attr]
            .limit(20)
            .all()
        )
        if not rows:
            return _FALLBACK_MERCHANTS
        return [
            {
                "name":     r.business_name,
                "slug":     r.slug,
                "category": getattr(r, "category", ""),
                "phone":    r.phone,
            }
            for r in rows
        ]
    except Exception as exc:
        logger.warning("_load_merchants DB query failed: %s", exc)
        return _FALLBACK_MERCHANTS


# ── Main handler ──────────────────────────────────────────────────────────────

async def handle_browsing(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """
    Handle START and BROWSING states.

    Decision tree:
      greeting / empty     → show welcome
      "1" / "shop"         → list merchants
      "2" / "sell"         → merchant portal pivot
      "3" / "deliver"      → courier portal pivot
      "help" / "menu" / 0  → show menu
      number / slug / name → load catalogue → ORDERING
      else                 → gentle unknown prompt
    """
    text = message.strip().lower()
    current_state = sm.get_state(phone)

    # ── Welcome / re-greeting ─────────────────────────────────────────────────
    if current_state == "START" or text in ("hi", "hello", "hey", "start", ""):
        sm.set_state(phone, "BROWSING")
        return HandlerResult(next_state="BROWSING", response=_GREETING)

    # ── Main menu ─────────────────────────────────────────────────────────────
    if text in ("0", "menu", "help", "back", "home"):
        sm.set_state(phone, "BROWSING")
        return HandlerResult(next_state="BROWSING", response=_MENU)

    # ── Role pivots ───────────────────────────────────────────────────────────
    if text in ("2", "sell", "merchant"):
        sm.set_role(phone, "merchant")
        sm.set_state(phone, "MERCHANT_PORTAL")
        return HandlerResult(
            next_state="MERCHANT_PORTAL",
            response=(
                "🏪 Welcome to the *Merchant Portal*.\n\n"
                "Type *inventory* to manage your items, or *orders* to see recent orders."
            ),
            metadata={"role_pivot": "merchant"},
        )

    if text in ("3", "deliver", "courier"):
        sm.set_role(phone, "courier")
        sm.set_state(phone, "COURIER_PORTAL")
        return HandlerResult(
            next_state="COURIER_PORTAL",
            response=(
                "🛵 Welcome to the *Courier Portal*.\n\n"
                "Type *available* to go online and start receiving delivery jobs."
            ),
            metadata={"role_pivot": "courier"},
        )

    # ── Browse merchant list ──────────────────────────────────────────────────
    if text in ("1", "shop", "browse", "merchants"):
        merchants = _load_merchants(db)
        sm.set_temp(phone, "merchants", __import__("json").dumps(merchants))
        formatted  = _format_merchant_list(merchants)
        return HandlerResult(
            next_state="BROWSING",
            response=_MERCHANTS_LOADING.format(merchants=formatted),
            metadata={"merchant_count": len(merchants)},
        )

    # ── Merchant selection by number or name ──────────────────────────────────
    import json as _json

    cached_merchants_raw = sm.get_temp(phone, "merchants")
    merchants = (
        _json.loads(cached_merchants_raw)
        if cached_merchants_raw
        else _load_merchants(db)
    )

    match = _find_merchant_by_input(text, merchants)
    if match:
        slug         = match["slug"]
        merchant_name = match["name"]

        # Try Redis cache first; fall back to DB or stub
        catalogue = sm.get_catalogue(slug)
        if catalogue is None:
            # Warm cache on cache miss
            try:
                from app.services.merchant_catalogue_local import warm_catalogue_cache
                warm_catalogue_cache(sm._r, db, match.get("phone", ""), slug)
                catalogue = sm.get_catalogue(slug)
            except Exception as exc:
                logger.warning("warm_catalogue_cache failed [%s]: %s", slug, exc)

        items = catalogue.get("items", []) if isinstance(catalogue, dict) else []

        # Save context for the ORDERING handler
        sm.set_temp(phone, "merchant_slug",  slug)
        sm.set_temp(phone, "merchant_name",  merchant_name)
        sm.set_temp(phone, "merchant_phone", match.get("phone", ""))
        sm.save_order(phone, {
            "merchant_slug":  slug,
            "merchant_name":  merchant_name,
            "merchant_phone": match.get("phone", ""),
            "items":          [],
            "total":          0,
        })

        sm.set_state(phone, "ORDERING")
        return HandlerResult(
            next_state="ORDERING",
            response=_CATALOGUE_INTRO.format(
                merchant_name=merchant_name,
                items=_format_catalogue(items),
            ),
            metadata={"merchant_slug": slug, "catalogue_items": len(items)},
        )

    # ── Unrecognised input ────────────────────────────────────────────────────
    return HandlerResult(next_state="BROWSING", response=_UNKNOWN)
