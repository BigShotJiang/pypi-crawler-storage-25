# app/bot/handlers/courier_flow.py
"""
Courier-side flow handlers.

States covered:
  DEAL_CREATED      — payment confirmed; looking for a courier
  COURIER_MATCHING  — job broadcast sent; waiting for acceptance
  COURIER_ASSIGNED  — a courier accepted; delivery in progress
  DELIVERY_IN_PROGRESS — courier on route; customer waiting
  AWAITING_PIN      — parcel delivered; waiting for customer PIN
  DEAL_COMPLETE     — PIN confirmed; deal done

Each sub-handler maps to exactly one state.  The engine dispatches
based on the stored state value — no handler inspects role here
(role routing is done in BotEngine before dispatch).

Customer-side states (DEAL_CREATED, DELIVERY_IN_PROGRESS) and
courier-side states (COURIER_MATCHING, AWAITING_PIN) are mixed here
because they are part of the same deal lifecycle.  Role is checked
within each sub-handler where the same state is visible to both parties.
"""

import json
import logging
import uuid
from typing import Optional

from sqlalchemy.orm import Session

from app.bot.handlers import HandlerResult
from app.bot.state_manager import RedisStateManager
from app.core.courier_fence import init_fence, get_fence_token, atomic_accept
from app.core.idempotency import log_idempotency_event

logger = logging.getLogger(__name__)


# ── Customer: DEAL_CREATED ────────────────────────────────────────────────────

async def handle_deal_created(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """
    Customer is in DEAL_CREATED state — payment confirmed, courier search active.

    The customer can check status or ask for an ETA.
    """
    text = message.strip().lower()
    ref  = sm.get_active_deal(phone) or "unknown"

    if text in ("status", "check", "?", "eta", "where"):
        return HandlerResult(
            next_state="DEAL_CREATED",
            response=(
                "🔍 *Searching for a courier...*\n\n"
                f"Reference: *{ref}*\n\n"
                "We'll notify you as soon as a courier accepts your delivery. "
                "This usually takes 2–5 minutes."
            ),
        )

    return HandlerResult(
        next_state="DEAL_CREATED",
        response=(
            "We're finding you a courier! 🛵\n\n"
            "Type *status* for an update, or just sit tight — we'll message you."
        ),
    )


# ── Courier: COURIER_MATCHING ─────────────────────────────────────────────────

async def handle_courier_matching(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """
    A courier received a job broadcast and is deciding whether to accept.

    Messages handled:
      "accept" / "1" → attempt atomic accept via courier fence
      "reject" / "2" → log rejection, no state change (job stays open)
    """
    text = message.strip().lower()
    job  = sm.get_courier_job(phone)

    if job is None:
        sm.set_state(phone, "COURIER_PORTAL")
        return HandlerResult(
            next_state="COURIER_PORTAL",
            response=(
                "⚠️ No active job found. Type *available* to go online "
                "and receive new delivery requests."
            ),
        )

    deal_id        = job.get("deal_id", "")
    expected_fence = job.get("fence_token")
    pickup_address = job.get("pickup_address", "unknown")
    drop_address   = job.get("drop_address", "unknown")
    fee            = job.get("courier_fee", "?")

    if text in ("accept", "1", "yes"):
        status, payload = atomic_accept(
            sm._r, deal_id, phone, expected_fence=expected_fence
        )

        if status == "ok":
            sm.set_state(phone, "COURIER_ASSIGNED")
            log_idempotency_event(
                sm._r, "courier_accept", f"bot:courier_accept:{deal_id}",
                {"courier_phone_hash": str(hash(phone) % 100_000), "deal_id": deal_id},
            )
            return HandlerResult(
                next_state="COURIER_ASSIGNED",
                response=(
                    f"✅ *Job accepted!*\n\n"
                    f"📦 Pickup:   {pickup_address}\n"
                    f"📍 Dropoff: {drop_address}\n"
                    f"💵 Your fee: US${fee}\n\n"
                    "Head to the pickup location and type *collected* once "
                    "you have the parcel."
                ),
                metadata={"deal_id": deal_id, "action": "accepted"},
            )

        if status == "taken":
            sm.set_state(phone, "COURIER_PORTAL")
            return HandlerResult(
                next_state="COURIER_PORTAL",
                response=(
                    "😕 Another courier got there first. "
                    "Type *available* to receive the next job."
                ),
            )

        # stale / error
        sm.set_state(phone, "COURIER_PORTAL")
        return HandlerResult(
            next_state="COURIER_PORTAL",
            response="This job is no longer available. Type *available* for new jobs.",
        )

    if text in ("reject", "2", "no", "pass", "skip"):
        sm.set_state(phone, "COURIER_PORTAL")
        return HandlerResult(
            next_state="COURIER_PORTAL",
            response="Job skipped. Type *available* to stay online for the next one.",
        )

    # Show job details again
    return HandlerResult(
        next_state="COURIER_MATCHING",
        response=(
            f"🚚 *New delivery job*\n\n"
            f"📦 Pickup:   {pickup_address}\n"
            f"📍 Dropoff: {drop_address}\n"
            f"💵 Your fee: US${fee}\n\n"
            "*1* — Accept\n*2* — Skip"
        ),
    )


# ── Courier: COURIER_ASSIGNED / DELIVERY_IN_PROGRESS ─────────────────────────

async def handle_delivery_in_progress(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """
    Courier has accepted; en route or at delivery.

    "collected" → parcel picked up → DELIVERY_IN_PROGRESS
    "delivered" → parcel dropped off → ask customer to share PIN → AWAITING_PIN
    "status"    → current job summary
    """
    text = message.strip().lower()
    job  = sm.get_courier_job(phone)
    deal_id = job.get("deal_id", "unknown") if job else "unknown"
    customer_phone = job.get("customer_phone", "") if job else ""

    if text in ("collected", "picked", "pickup", "got it"):
        sm.set_state(phone, "DELIVERY_IN_PROGRESS")
        return HandlerResult(
            next_state="DELIVERY_IN_PROGRESS",
            response=(
                "📦 *Parcel collected!*\n\n"
                "Head to the dropoff address and type *delivered* once you've "
                "handed it to the customer."
            ),
            metadata={"deal_id": deal_id, "milestone": "collected"},
        )

    if text in ("delivered", "done", "dropped", "complete"):
        # Advance customer session to AWAITING_PIN
        if customer_phone:
            sm.set_state(customer_phone, "AWAITING_PIN")
        sm.set_state(phone, "AWAITING_PIN")

        return HandlerResult(
            next_state="AWAITING_PIN",
            response=(
                "✅ *Almost done!*\n\n"
                "Ask the customer for their 4-digit delivery PIN to complete "
                "the handover. Type the PIN when they give it to you."
            ),
            metadata={"deal_id": deal_id, "milestone": "delivered"},
        )

    return HandlerResult(
        next_state=sm.get_state(phone),   # preserve current state
        response=(
            "🛵 *Delivery in progress*\n\n"
            "Type *collected* once you have the parcel,\n"
            "or *delivered* once you've handed it over."
        ),
    )


# ── PIN verification: AWAITING_PIN ────────────────────────────────────────────

async def handle_awaiting_pin(
    phone:   str,
    message: str,
    sm:      RedisStateManager,
    db:      Optional[Session],
) -> HandlerResult:
    """
    Courier enters the customer-provided PIN to unlock fund release.

    Uses PINVerification service for SHA-256 hash comparison and
    lockout after 3 failed attempts.
    """
    text    = message.strip()
    ref     = sm.get_active_deal(phone) or ""
    job     = sm.get_courier_job(phone)
    deal_id = job.get("deal_id", ref) if job else ref

    if not text.isdigit() or len(text) != 4:
        return HandlerResult(
            next_state="AWAITING_PIN",
            response=(
                "🔐 Please enter the *4-digit PIN* the customer gave you.\n\n"
                "The PIN unlocks your payment."
            ),
        )

    try:
        from security.pin_verification import PINVerification
        verifier = PINVerification(db)
        result   = verifier.verify_pin(deal_id, text, courier_phone=phone)
    except Exception as exc:
        logger.error("PIN verification error [%s]: %s", deal_id, exc)
        return HandlerResult(
            next_state="AWAITING_PIN",
            response="⚠️ PIN verification temporarily unavailable. Please try again.",
        )

    if result.locked:
        sm.set_state(phone, "COURIER_PORTAL")
        return HandlerResult(
            next_state="COURIER_PORTAL",
            response=(
                "🔒 Too many incorrect PIN attempts. This deal has been escalated "
                "for manual review. Contact support for assistance."
            ),
            metadata={"deal_id": deal_id, "action": "pin_locked"},
        )

    if result.valid:
        sm.set_state(phone, "DEAL_COMPLETE")
        sm.clear_order(phone)

        logger.info("deal_complete deal_id=%s", deal_id)
        return HandlerResult(
            next_state="DEAL_COMPLETE",
            response=(
                "🎉 *Deal complete!*\n\n"
                "PIN accepted. Your payment has been released and will arrive "
                "in your wallet shortly.\n\n"
                "Thank you for delivering with AnchorFlow! 🛵"
            ),
            metadata={"deal_id": deal_id, "action": "pin_verified"},
        )

    attempts_left = result.attempts_remaining
    return HandlerResult(
        next_state="AWAITING_PIN",
        response=(
            f"❌ Incorrect PIN. {attempts_left} attempt{'s' if attempts_left != 1 else ''} remaining.\n\n"
            "Please ask the customer to confirm their PIN."
        ),
        metadata={"deal_id": deal_id, "action": "pin_wrong"},
    )
