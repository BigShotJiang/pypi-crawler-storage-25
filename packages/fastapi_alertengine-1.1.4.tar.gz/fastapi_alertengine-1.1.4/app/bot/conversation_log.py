# app/bot/conversation_log.py
"""
Conversation log — per-user message history for replay and debugging.

Why this exists
────────────────
  • Debugging user issues: "what did they actually send?"
  • Fraud disputes: "did the customer confirm delivery?"
  • Product insights: most common stuck states, dropout points
  • Support tooling: support agents can see what a user experienced

Design
───────
  Key:      conversation:{phone}
  Type:     Redis List (RPUSH + LTRIM to cap at MAX_ENTRIES)
  TTL:      7 days (reset on each append)
  Encoding: One JSON object per list element

  Each entry:
    {
      "role":  "user" | "bot",
      "msg":   str  (capped at MSG_MAX_CHARS),
      "state": str  (bot state at time of message),
      "ts":    int  (millisecond epoch)
    }

  Messages are NEVER stored in metrics:events (that would mix PII with
  operational telemetry).  conversation:{phone} is a separate namespace
  managed only through this module.

Security
─────────
  The key uses the raw phone number, which means Redis holds PII.
  Access to conversation history must be gated by an internal admin
  token — never exposed via a public endpoint.
  The `phone_hash` used in all logging maps to a phone, but only
  this module can reverse that mapping (by key scan).

Usage::

    from app.bot.conversation_log import append_message, get_conversation

    # After receiving a message:
    append_message(rdb, phone, role="user", message=text, state="BROWSING")

    # After generating a response:
    append_message(rdb, phone, role="bot", message=response, state="ORDERING")

    # For debugging / support:
    entries = get_conversation(rdb, phone)
"""

import json
import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────

MAX_ENTRIES   = 50              # keep last N messages per user
MSG_MAX_CHARS = 500             # cap message length in the log
TTL_SECS      = 86_400 * 7     # 7-day retention


def _conv_key(phone: str) -> str:
    return f"conversation:{phone}"


# ── Append ────────────────────────────────────────────────────────────────────

def append_message(
    rdb:     Any,
    phone:   str,
    role:    str,
    message: str,
    state:   str,
) -> None:
    """
    Append one message to the conversation log for this phone.

    Silently drops the entry on Redis error — the conversation log must
    never interfere with message processing.

    Args:
        rdb:     Redis / SafeRedis client.
        phone:   User phone number (stored as-is; access must be gated).
        role:    "user" | "bot"
        message: Message text (truncated to MSG_MAX_CHARS).
        state:   Current bot state at the time of this message.
    """
    if not phone or not message:
        return

    entry = {
        "role":  role,
        "msg":   message[:MSG_MAX_CHARS],
        "state": state,
        "ts":    int(time.time() * 1000),
    }

    key = _conv_key(phone)
    try:
        pipe = rdb.pipeline(transaction=False)
        pipe.rpush(key, json.dumps(entry))
        pipe.ltrim(key, -MAX_ENTRIES, -1)   # keep only last MAX_ENTRIES
        pipe.expire(key, TTL_SECS)
        pipe.execute()
    except Exception as exc:
        # Conversation log is best-effort — swallow and continue
        logger.debug("conversation_log.append_message failed [%s]: %s", phone, exc)


# ── Retrieve ──────────────────────────────────────────────────────────────────

def get_conversation(rdb: Any, phone: str) -> List[Dict]:
    """
    Return the stored conversation history for phone, oldest first.

    Returns an empty list on any error or cache miss.
    """
    key = _conv_key(phone)
    try:
        raw_entries = rdb.lrange(key, 0, -1)
        if not raw_entries:
            return []

        result = []
        for raw in raw_entries:
            try:
                text = raw.decode() if isinstance(raw, bytes) else raw
                result.append(json.loads(text))
            except Exception:
                continue   # skip corrupt entries
        return result

    except Exception as exc:
        logger.debug("conversation_log.get_conversation failed [%s]: %s", phone, exc)
        return []


def get_conversation_summary(rdb: Any, phone: str) -> Dict:
    """
    Return a lightweight summary of the conversation (last state, message count).
    Suitable for /health or support endpoints without exposing raw messages.
    """
    entries = get_conversation(rdb, phone)
    if not entries:
        return {"message_count": 0, "last_state": None, "last_ts": None}

    last = entries[-1]
    return {
        "message_count": len(entries),
        "last_state":    last.get("state"),
        "last_ts":       last.get("ts"),
        "last_role":     last.get("role"),
    }
