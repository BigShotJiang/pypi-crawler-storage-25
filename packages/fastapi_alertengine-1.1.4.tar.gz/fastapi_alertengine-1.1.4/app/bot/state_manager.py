# app/bot/state_manager.py
"""
RedisStateManager — single abstraction for all bot Redis state.

Every Redis key the bot runtime reads or writes goes through this class.
No handler or engine code should call self._redis.* directly — only
RedisStateManager methods.  This makes key naming consistent, TTLs
auditable in one place, and Redis calls mockable in tests.

Key layout
──────────
Existing keys (MUST NOT be renamed):
  bot:state:{phone}          — current BotState name (str)
  bot:state_ts:{phone}       — epoch float of last state change (str)
  bot:state_lock:{phone}     — short-lived processing mutex (5 s)
  bot:order:{phone}          — JSON order snapshot (zlib-compressed if > 2 KB)
  bot:active_deal:{phone}    — deal_id for recovery linking
  merchant_catalogue:{slug}  — cached merchant catalogue JSON

New keys added by this layer (non-conflicting):
  bot:role:{phone}           — user role: customer | merchant | courier (7-day TTL)
  bot:dedup:{MessageSid}     — message-level dedup NX key (5-min TTL)
  bot:rate:{phone}           — rate-limit counter (60-s sliding window)
  bot:deal_ref:{ref}         — Paynow reference → phone mapping (24-h TTL)
  bot:courier_job:{phone}    — courier job payload JSON (30-min TTL)
  bot:courier_lock:{deal_id} — NX first-accept courier lock (30-min TTL)
  bot:temp:{phone}:{key}     — arbitrary short-lived session values (24-h TTL)
"""

import json
import logging
import time
import zlib
from typing import Any, Dict, Optional, Tuple

from app.bot.locks import TokenLock
from app.core.idempotency import (
    TTL_ACTIVE_SESSION,
    TTL_IDLE_SESSION,
    TTL_DEDUP_MESSAGE,
    TTL_COURIER_JOB_MAX,
    TTL_STATE_LOCK,
)

logger = logging.getLogger(__name__)

# ── TTL constants specific to this layer ──────────────────────────────────────
_TTL_ROLE         = 86_400 * 7   # 7 days
_TTL_RATE_WINDOW  = 60           # sliding window for rate limit
_TTL_DEAL_REF     = 86_400       # 24 h — Paynow ref → phone
_TTL_TEMP         = TTL_ACTIVE_SESSION

# Rate limit: max messages per _TTL_RATE_WINDOW seconds per phone
RATE_LIMIT_MAX    = 20

# Compress order payload if serialised size exceeds this many bytes
_COMPRESS_THRESHOLD = 2_048

# States that are considered "idle" (get shorter TTL to conserve Redis memory)
_IDLE_STATES = frozenset({"START", "IDLE", "BROWSING"})


class RedisStateManager:
    """
    Centralised Redis I/O for the bot runtime.

    Instantiated once per request by the webhook controller and injected
    into BotEngine, which passes it down to each handler.

    All public methods swallow exceptions and log at WARNING/ERROR — they
    must never raise, so the engine can always return a response.
    """

    __slots__ = ("_r", "_lock")

    def __init__(self, rdb: Any) -> None:
        self._r    = rdb
        self._lock = TokenLock(rdb)

    # ── Deduplication ─────────────────────────────────────────────────────────

    def is_duplicate(self, message_sid: str) -> bool:
        """
        Return True and do nothing if this MessageSid was already processed.
        Returns False and claims the key if this is the first occurrence.
        """
        key = f"bot:dedup:{message_sid}"
        try:
            claimed = self._r.setnx(key, "1")
            if claimed:
                self._r.expire(key, TTL_DEDUP_MESSAGE)
            return not bool(claimed)
        except Exception as exc:
            logger.warning("is_duplicate check failed [%s]: %s", message_sid, exc)
            return False   # fail open — process the message

    # ── Rate limiting ─────────────────────────────────────────────────────────

    def is_rate_limited(self, phone: str) -> bool:
        """
        Sliding-window rate limiter.

        Increments a counter for this phone in the current 60-second window.
        Returns True (blocked) if the counter exceeds RATE_LIMIT_MAX.
        Fails open on Redis error — never block a user due to Redis being down.
        """
        key = f"bot:rate:{phone}"
        try:
            count = self._r.incr(key)
            if count == 1:
                self._r.expire(key, _TTL_RATE_WINDOW)
            return count > RATE_LIMIT_MAX
        except Exception as exc:
            logger.warning("is_rate_limited check failed [%s]: %s", phone, exc)
            return False

    # ── State ─────────────────────────────────────────────────────────────────

    def get_state(self, phone: str) -> str:
        """
        Return the current bot state for phone.
        Defaults to "START" if the key is missing or Redis is unreachable.
        """
        try:
            raw = self._r.get(f"bot:state:{phone}")
            if raw is None:
                return "START"
            return raw.decode() if isinstance(raw, bytes) else str(raw)
        except Exception as exc:
            logger.warning("get_state failed [%s]: %s", phone, exc)
            return "START"

    def set_state(self, phone: str, state: str) -> None:
        """
        Persist bot state with TTL and update the timestamp key.

        Uses TTL_ACTIVE_SESSION for states with deals in flight,
        TTL_IDLE_SESSION for START/IDLE/BROWSING to save memory.
        """
        ttl = TTL_IDLE_SESSION if state in _IDLE_STATES else TTL_ACTIVE_SESSION
        try:
            self._r.setex(f"bot:state:{phone}", ttl, state)
            self._r.setex(f"bot:state_ts:{phone}", ttl, str(int(time.time())))
        except Exception as exc:
            logger.error("set_state failed [%s → %s]: %s", phone, state, exc)

    # ── Processing lock (token-safe) ──────────────────────────────────────────

    def acquire_lock(self, phone: str) -> Optional[str]:
        """
        Acquire a short-lived token-safe processing mutex for this phone.

        Returns a token string if acquired, None if another request holds it.
        Only the holder of the returned token can release the lock — prevents
        accidental unlocks after TTL expiry and re-issue to another holder.
        """
        return self._lock.acquire(f"bot:state_lock:{phone}", ttl=TTL_STATE_LOCK)

    def release_lock(self, phone: str, token: Optional[str]) -> None:
        """Release the lock only if the token matches the held token."""
        self._lock.release(f"bot:state_lock:{phone}", token)

    def acquire_deal_lock(self, deal_id: str) -> Optional[str]:
        """
        Acquire a per-deal mutex for payment + courier operations.

        Used to prevent races between concurrent payment webhooks and
        user messages that both try to advance the same deal's state.

        TTL: 30 s — long enough for a payment confirmation round trip.
        Returns a token string if acquired, None if already locked.
        """
        return self._lock.acquire(f"bot:deal_lock:{deal_id}", ttl=30)

    def release_deal_lock(self, deal_id: str, token: Optional[str]) -> None:
        """Release the deal lock only if the token matches."""
        self._lock.release(f"bot:deal_lock:{deal_id}", token)

    # ── Role ──────────────────────────────────────────────────────────────────

    def get_role(self, phone: str) -> str:
        """Return user role: 'customer' | 'merchant' | 'courier'. Default: 'customer'."""
        try:
            raw = self._r.get(f"bot:role:{phone}")
            if raw is None:
                return "customer"
            return raw.decode() if isinstance(raw, bytes) else str(raw)
        except Exception as exc:
            logger.warning("get_role failed [%s]: %s", phone, exc)
            return "customer"

    def set_role(self, phone: str, role: str) -> None:
        try:
            self._r.setex(f"bot:role:{phone}", _TTL_ROLE, role)
        except Exception as exc:
            logger.error("set_role failed [%s]: %s", phone, exc)

    # ── Temporary session values ──────────────────────────────────────────────

    def get_temp(self, phone: str, key: str) -> Optional[str]:
        """Retrieve a short-lived session-scoped value."""
        try:
            raw = self._r.get(f"bot:temp:{phone}:{key}")
            if raw is None:
                return None
            return raw.decode() if isinstance(raw, bytes) else str(raw)
        except Exception as exc:
            logger.warning("get_temp failed [%s/%s]: %s", phone, key, exc)
            return None

    def set_temp(self, phone: str, key: str, value: str, ttl: int = _TTL_TEMP) -> None:
        """Store a short-lived session-scoped value under bot:temp:{phone}:{key}."""
        try:
            self._r.setex(f"bot:temp:{phone}:{key}", ttl, value)
        except Exception as exc:
            logger.warning("set_temp failed [%s/%s]: %s", phone, key, exc)

    # ── Order snapshot ────────────────────────────────────────────────────────

    def get_order(self, phone: str) -> Optional[Dict]:
        """
        Load the in-progress order snapshot for phone.

        Returns None if missing or corrupt.
        Transparently decompresses zlib payloads (prefix "z:").
        """
        try:
            raw = self._r.get(f"bot:order:{phone}")
            if raw is None:
                return None
            data: bytes = raw if isinstance(raw, bytes) else raw.encode()
            if data.startswith(b"z:"):
                data = zlib.decompress(data[2:])
            return json.loads(data)
        except Exception as exc:
            logger.warning("get_order failed [%s]: %s", phone, exc)
            return None

    def save_order(self, phone: str, data: Dict) -> None:
        """
        Persist order snapshot.

        Transparently compresses with zlib if the JSON payload exceeds
        _COMPRESS_THRESHOLD bytes, prefixing with "z:" so get_order()
        can detect and decompress.
        """
        try:
            payload: bytes = json.dumps(data).encode()
            if len(payload) > _COMPRESS_THRESHOLD:
                payload = b"z:" + zlib.compress(payload)
            self._r.setex(f"bot:order:{phone}", TTL_ACTIVE_SESSION, payload)
        except Exception as exc:
            logger.error("save_order failed [%s]: %s", phone, exc)

    def clear_order(self, phone: str) -> None:
        """Delete the order snapshot (called after deal is created or abandoned)."""
        try:
            self._r.delete(f"bot:order:{phone}")
        except Exception:
            pass

    # ── Active deal ───────────────────────────────────────────────────────────

    def get_active_deal(self, phone: str) -> Optional[str]:
        try:
            raw = self._r.get(f"bot:active_deal:{phone}")
            if raw is None:
                return None
            return raw.decode() if isinstance(raw, bytes) else str(raw)
        except Exception as exc:
            logger.warning("get_active_deal failed [%s]: %s", phone, exc)
            return None

    def set_active_deal(self, phone: str, deal_id: str) -> None:
        try:
            self._r.setex(f"bot:active_deal:{phone}", TTL_ACTIVE_SESSION, deal_id)
        except Exception as exc:
            logger.error("set_active_deal failed [%s]: %s", phone, exc)

    # ── Payment reference mapping ─────────────────────────────────────────────

    def map_deal_ref(self, paynow_ref: str, phone: str) -> None:
        """Map Paynow payment reference → customer phone for webhook resolution."""
        try:
            self._r.setex(f"bot:deal_ref:{paynow_ref}", _TTL_DEAL_REF, phone)
        except Exception as exc:
            logger.error("map_deal_ref failed [%s]: %s", paynow_ref, exc)

    def resolve_deal_ref(self, paynow_ref: str) -> Optional[str]:
        """Resolve Paynow reference → customer phone. Returns None on cache miss."""
        try:
            raw = self._r.get(f"bot:deal_ref:{paynow_ref}")
            if raw is None:
                return None
            return raw.decode() if isinstance(raw, bytes) else str(raw)
        except Exception as exc:
            logger.warning("resolve_deal_ref failed [%s]: %s", paynow_ref, exc)
            return None

    # ── Courier job ───────────────────────────────────────────────────────────

    def save_courier_job(self, courier_phone: str, job_data: Dict) -> None:
        try:
            self._r.setex(
                f"bot:courier_job:{courier_phone}",
                TTL_COURIER_JOB_MAX,
                json.dumps(job_data),
            )
        except Exception as exc:
            logger.error("save_courier_job failed [%s]: %s", courier_phone, exc)

    def get_courier_job(self, courier_phone: str) -> Optional[Dict]:
        try:
            raw = self._r.get(f"bot:courier_job:{courier_phone}")
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:
            logger.warning("get_courier_job failed [%s]: %s", courier_phone, exc)
            return None

    def acquire_courier_lock(self, deal_id: str, courier_phone: str) -> bool:
        """
        Attempt NX lock for courier acceptance.

        Uses a separate key (bot:courier_lock:{deal_id}) from the Lua fence
        (bot:courier_accept:{deal_id}) — simpler NX-only path for use when
        the atomic Lua fence is not required.

        Returns True if this courier acquired the lock.
        """
        key = f"bot:courier_lock:{deal_id}"
        try:
            acquired = self._r.setnx(key, courier_phone)
            if acquired:
                self._r.expire(key, TTL_COURIER_JOB_MAX)
            return bool(acquired)
        except Exception as exc:
            logger.error("acquire_courier_lock failed [%s]: %s", deal_id, exc)
            return False

    # ── Merchant catalogue ────────────────────────────────────────────────────

    def get_catalogue(self, slug: str) -> Optional[Dict]:
        """
        Load cached merchant catalogue from Redis.

        Returns None on cache miss — callers should fall back to DB
        and repopulate via warm_catalogue_cache().
        """
        try:
            raw = self._r.get(f"merchant_catalogue:{slug}")
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:
            logger.warning("get_catalogue failed [%s]: %s", slug, exc)
            return None
