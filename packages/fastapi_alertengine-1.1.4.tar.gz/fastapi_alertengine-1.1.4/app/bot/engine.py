# app/bot/engine.py
"""
BotEngine — hardened core state machine orchestrator.

Hardening applied (Phase 1):
  [H1] Global error boundary — process_message() NEVER raises; every
       exception is caught, logged to metrics:events, and returns a
       safe fallback message.
  [H2] State validation guard — if state is missing or not in the
       handler map, reset to START and emit a state_invalid event.
  [H3] Full observability — every meaningful event emits to
       metrics:events and/or idempotency:events.
  [H4] process_event() — event-driven entry point for system-generated
       events (payment confirmation, courier actions, timeout sweeps)
       that reuses the same handlers as message processing.
  [H5] Token-safe locking — lock management delegates to TokenLock
       via RedisStateManager.acquire_lock / release_lock.

Architecture:
  WebhookController
    └─ BotEngine.process_message(phone, text)     ← user-driven
    └─ BotEngine.process_event(event_type, data)  ← system-driven
         ├─ RedisStateManager  (all Redis I/O)
         ├─ Handler dispatch   (pure async functions)
         └─ Metrics + logging  (app.core.metrics / app.core.idempotency)
"""

import asyncio
import logging
import time
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from app.bot.state_manager import RedisStateManager
from app.bot.handlers import HandlerResult
from app.bot.handlers.browsing import handle_browsing
from app.bot.handlers.ordering import handle_ordering, handle_confirming
from app.bot.handlers.payment_wait import handle_payment_wait
from app.bot.handlers.courier_flow import (
    handle_deal_created,
    handle_courier_matching,
    handle_delivery_in_progress,
    handle_awaiting_pin,
)
from app.core.load_shedding import should_skip_claude
from app.core.metrics import (
    record_webhook_latency,
    record_state_transition_failure,
    record_redis_failure,
)
from app.core.idempotency import log_idempotency_event
from app.bot.conversation_log import append_message

logger = logging.getLogger(__name__)

# ── Timeouts ─────────────────────────────────────────────────────────────────

# Claude enrichment must complete within this window so the overall
# webhook response stays under Twilio's 15-second timeout.
_CLAUDE_TIMEOUT_S  = 3.0

# Handler execution timeout — safety net for accidental blocking calls.
_HANDLER_TIMEOUT_S = 8.0

# ── Fallback messages ─────────────────────────────────────────────────────────

_MSG_FALLBACK = "Something went wrong. Please try again."

_MSG_STATE_RESET = (
    "👋 Welcome back! Let's start fresh.\n\n"
    "Type *1* to browse merchants, *2* for merchant tools, or *3* to deliver."
)

_MSG_TIMEOUT = (
    "⏳ That took a bit longer than expected. Please try again."
)


# ── Handler dispatch table ────────────────────────────────────────────────────
# Every valid bot state must appear here.  States absent from this map
# trigger the [H2] state validation guard (reset to START).

_HANDLER_MAP = {
    "START":                 handle_browsing,
    "IDLE":                  handle_browsing,
    "BROWSING":              handle_browsing,
    "ORDERING":              handle_ordering,
    "CONFIRMING_ORDER":      handle_confirming,
    "AWAITING_PAYMENT":      handle_payment_wait,
    "DEAL_CREATED":          handle_deal_created,
    "COURIER_MATCHING":      handle_courier_matching,
    "COURIER_ASSIGNED":      handle_delivery_in_progress,
    "DELIVERY_IN_PROGRESS":  handle_delivery_in_progress,
    "AWAITING_PIN":          handle_awaiting_pin,
    # Terminal / portal states re-enter via browsing
    "DEAL_COMPLETE":         handle_browsing,
    "MERCHANT_PORTAL":       handle_browsing,
    "COURIER_PORTAL":        handle_browsing,
}

# ── Event type → engine method mapping ────────────────────────────────────────
# Populated at the bottom of this module after class definition.
_EVENT_HANDLERS: Dict[str, str] = {}


class BotEngine:
    """
    Core orchestrator for the AnchorFlow WhatsApp commerce bot.

    Instantiated per-request — no mutable class-level state.
    Horizontally scalable: all state lives in Redis.

    Args:
        sm:  RedisStateManager — injected, already bound to a Redis client.
        db:  SQLAlchemy Session — may be None; handlers must tolerate this.
    """

    def __init__(self, sm: RedisStateManager, db: Optional[Session] = None) -> None:
        self.sm   = sm
        self.db   = db
        self._rdb: Any = sm._r

    # ═══════════════════════════════════════════════════════════════════════════
    # PUBLIC: User-driven message processing
    # ═══════════════════════════════════════════════════════════════════════════

    async def process_message(self, phone: str, message: str) -> str:
        """
        [H1] Global error boundary — process one WhatsApp message.

        This method NEVER raises.  Every exception path returns a safe
        string that the webhook controller can wrap in TwiML.

        Flow:
          1. Emit message_received event
          2. Read state + role
          3. [H2] Validate state
          4. Optional Claude enrichment (skipped in degraded mode)
          5. Dispatch to handler with timeout guard
          6. Write next state
          7. Emit state_transition event
          8. Return response text
        """
        t0 = time.perf_counter()

        # ── Observability: message received ──────────────────────────────────
        _emit(self._rdb, "message_received", {
            "phone_hash": str(hash(phone) % 100_000),
            "message_len": str(len(message)),
        })

        try:
            return await self._process_message_inner(phone, message, t0)

        except asyncio.TimeoutError:
            duration_ms = (time.perf_counter() - t0) * 1000
            logger.error(
                "bot.process_message timeout phone_hash=%s after %.0fms",
                hash(phone) % 100_000, duration_ms,
            )
            _emit_error(self._rdb, "message_timeout", phone, "handler_timeout", duration_ms)
            return _MSG_TIMEOUT

        except Exception as exc:
            duration_ms = (time.perf_counter() - t0) * 1000
            logger.exception(
                "bot.process_message unhandled exception phone_hash=%s: %s",
                hash(phone) % 100_000, exc,
            )
            _emit_error(self._rdb, "message_error", phone, str(exc), duration_ms)
            return _MSG_FALLBACK

    async def _process_message_inner(
        self, phone: str, message: str, t0: float
    ) -> str:
        """Inner implementation — may raise; outer method catches all."""
        # ── 1. Read state + role ─────────────────────────────────────────────
        state = self.sm.get_state(phone)
        role  = self.sm.get_role(phone)

        logger.info(
            "bot.dispatch phone_hash=%s state=%s role=%s",
            hash(phone) % 100_000, state, role,
        )

        # ── 2. [H2] State validation guard ────────────────────────────────────
        handler = _HANDLER_MAP.get(state)
        if handler is None:
            return self._handle_invalid_state(phone, state)

        # ── 3. Claude enrichment (load-shedding-aware, bounded timeout) ───────
        enriched = message
        if not should_skip_claude(self._rdb):
            try:
                enriched = await asyncio.wait_for(
                    self._enrich_with_claude(message, state),
                    timeout=_CLAUDE_TIMEOUT_S,
                )
            except (asyncio.TimeoutError, Exception) as exc:
                logger.debug("claude_enrichment skipped: %s", exc)
                # Degrade gracefully — continue with raw message

        # ── 4. Handler dispatch with timeout guard ────────────────────────────
        _emit(self._rdb, "handler_start", {
            "state": state,
            "phone_hash": str(hash(phone) % 100_000),
        })
        handler_t0 = time.perf_counter()

        result: HandlerResult = await asyncio.wait_for(
            handler(phone=phone, message=enriched, sm=self.sm, db=self.db),
            timeout=_HANDLER_TIMEOUT_S,
        )

        handler_ms = (time.perf_counter() - handler_t0) * 1000
        _emit(self._rdb, "handler_complete", {
            "state":       state,
            "next_state":  result.next_state,
            "duration_ms": f"{handler_ms:.1f}",
            "phone_hash":  str(hash(phone) % 100_000),
        })

        # ── 5. State transition ───────────────────────────────────────────────
        if result.next_state != state:
            self.sm.set_state(phone, result.next_state)
            logger.info(
                "bot.state_transition phone_hash=%s %s → %s",
                hash(phone) % 100_000, state, result.next_state,
            )
            _emit(self._rdb, "state_transition", {
                "phone_hash": str(hash(phone) % 100_000),
                "from_state": state,
                "to_state":   result.next_state,
                **{k: str(v) for k, v in result.metadata.items()},
            })

        # ── 6. Request-level metrics ──────────────────────────────────────────
        total_ms = (time.perf_counter() - t0) * 1000
        record_webhook_latency(self._rdb, total_ms)

        log_idempotency_event(
            self._rdb, "state_dispatch", f"bot:state:{phone}",
            {
                "from_state":   state,
                "to_state":     result.next_state,
                "duration_ms":  f"{total_ms:.1f}",
                "phone_hash":   str(hash(phone) % 100_000),
            },
        )

        # ── 7. Conversation log ───────────────────────────────────────────────
        # Append AFTER response is generated so the log entry reflects the
        # response text, not a placeholder.  Best-effort; never blocks.
        append_message(self._rdb, phone, role="bot",
                       message=result.response, state=result.next_state)

        return result.response

    # ═══════════════════════════════════════════════════════════════════════════
    # PUBLIC: Event-driven processing (H4)
    # ═══════════════════════════════════════════════════════════════════════════

    async def process_event(self, event_type: str, payload: Dict) -> Optional[str]:
        """
        [H4] Process a system-generated event (not a user WhatsApp message).

        Used by:
          - Payment webhook on confirmation
          - Courier broadcast when a new job is dispatched
          - Recovery sweep on session timeout
          - Escrow timeout engine on expiry

        Returns a notification message to send to the user via Twilio,
        or None if no notification is needed.

        This method NEVER raises.
        """
        t0 = time.perf_counter()
        logger.info("bot.process_event type=%s", event_type)

        _emit(self._rdb, "event_received", {
            "event_type": event_type,
            "payload_keys": ",".join(str(k) for k in payload.keys()),
        })

        handler_name = _EVENT_HANDLERS.get(event_type)
        if handler_name is None:
            logger.warning("bot.process_event unknown event_type=%s", event_type)
            return None

        try:
            method  = getattr(self, handler_name)
            result  = await asyncio.wait_for(method(payload), timeout=10.0)
            duration_ms = (time.perf_counter() - t0) * 1000
            _emit(self._rdb, "event_processed", {
                "event_type":  event_type,
                "duration_ms": f"{duration_ms:.1f}",
                "notified":    str(result is not None),
            })
            return result

        except asyncio.TimeoutError:
            logger.error("bot.process_event timeout event_type=%s", event_type)
            _emit_error(self._rdb, "event_timeout", "", event_type,
                        (time.perf_counter() - t0) * 1000)
            return None

        except Exception as exc:
            logger.exception("bot.process_event error event_type=%s: %s", event_type, exc)
            _emit_error(self._rdb, "event_error", "", str(exc),
                        (time.perf_counter() - t0) * 1000)
            return None

    # ── Event handlers (called via process_event dispatch) ────────────────────

    async def _on_payment_confirmed(self, payload: Dict) -> Optional[str]:
        """
        Advance state AWAITING_PAYMENT → DEAL_CREATED when Paynow confirms.

        Called by process_event("payment_confirmed", {...}) and directly
        by the payment webhook controller.

        payload keys:
          phone (str)  — customer phone
          ref   (str)  — Paynow payment reference
        """
        phone = payload.get("phone", "")
        ref   = payload.get("ref", "")
        if not phone or not ref:
            logger.warning("_on_payment_confirmed: missing phone or ref in payload")
            return None

        state = self.sm.get_state(phone)
        if state != "AWAITING_PAYMENT":
            logger.info(
                "_on_payment_confirmed: skipped — state=%s phone_hash=%s ref=%s",
                state, hash(phone) % 100_000, ref,
            )
            return None

        self.sm.set_state(phone, "DEAL_CREATED")

        try:
            from app.core.courier_fence import init_fence
            init_fence(self._rdb, ref)
        except Exception as exc:
            logger.warning("_on_payment_confirmed: init_fence failed [%s]: %s", ref, exc)

        _emit(self._rdb, "payment_confirmed", {
            "ref":        ref,
            "phone_hash": str(hash(phone) % 100_000),
            "prev_state": state,
        })
        log_idempotency_event(
            self._rdb, "payment_confirmed", f"payment_processed:{ref}",
            {"ref": ref, "phone_hash": str(hash(phone) % 100_000)},
        )

        logger.info("payment_confirmed ref=%s AWAITING_PAYMENT → DEAL_CREATED", ref)
        return (
            "✅ *Payment received!*\n\n"
            f"Reference: *{ref}*\n\n"
            "We're finding a courier for your delivery — sit tight! 🛵"
        )

    async def _on_courier_job_broadcast(self, payload: Dict) -> Optional[str]:
        """
        Push a delivery job to a courier and set their state to COURIER_MATCHING.

        payload keys:
          courier_phone  (str)
          deal_id        (str)
          fence_token    (str)
          pickup_address (str)
          drop_address   (str)
          courier_fee    (str|float)
          customer_phone (str)
        """
        courier_phone = payload.get("courier_phone", "")
        deal_id       = payload.get("deal_id", "")
        if not courier_phone or not deal_id:
            return None

        self.sm.save_courier_job(courier_phone, payload)
        self.sm.set_state(courier_phone, "COURIER_MATCHING")

        _emit(self._rdb, "courier_job_broadcast", {
            "deal_id":      deal_id,
            "courier_hash": str(hash(courier_phone) % 100_000),
        })

        pickup = payload.get("pickup_address", "?")
        drop   = payload.get("drop_address", "?")
        fee    = payload.get("courier_fee", "?")

        return (
            f"🚚 *New delivery job!*\n\n"
            f"📦 Pickup:   {pickup}\n"
            f"📍 Dropoff: {drop}\n"
            f"💵 Your fee: US${fee}\n\n"
            "Reply *1* to accept or *2* to skip."
        )

    async def _on_courier_accepted(self, payload: Dict) -> Optional[str]:
        """
        Notify the customer that a courier has been assigned.

        payload keys:
          customer_phone  (str)
          courier_phone   (str)  — masked before passing to customer
          deal_id         (str)
          eta_minutes     (int, optional)
        """
        customer_phone = payload.get("customer_phone", "")
        deal_id        = payload.get("deal_id", "")
        eta            = payload.get("eta_minutes")

        if not customer_phone:
            return None

        _emit(self._rdb, "courier_accepted", {
            "deal_id":        deal_id,
            "customer_hash":  str(hash(customer_phone) % 100_000),
        })

        eta_line = f"\nEstimated arrival: *{eta} minutes*" if eta else ""
        return (
            f"🛵 *Courier on the way!*\n\n"
            f"Your parcel has been picked up and is heading to you.{eta_line}\n\n"
            "You'll receive a 4-digit PIN to confirm delivery."
        )

    async def _on_session_timeout(self, payload: Dict) -> Optional[str]:
        """
        Handle recovery sweep reset — notify user their session was reset.

        payload keys:
          phone      (str)
          from_state (str)
          deal_id    (str, optional)
        """
        phone      = payload.get("phone", "")
        from_state = payload.get("from_state", "unknown")

        if not phone:
            return None

        self.sm.set_state(phone, "START")
        _emit(self._rdb, "session_timeout", {
            "phone_hash": str(hash(phone) % 100_000),
            "from_state": from_state,
        })

        return (
            "⏰ Your session expired due to inactivity.\n\n"
            "Type *1* to start shopping again."
        )

    async def _on_courier_timeout(self, payload: Dict) -> Optional[str]:
        """
        Handle a courier who accepted a job but went dark.

        Real-world scenario: courier accepts, then loses signal / has an
        accident / decides not to show up.  Without a timeout, the customer
        is stuck in DEAL_CREATED forever.

        What this does:
          1. Validates the courier is still in an active delivery state
          2. Resets courier → COURIER_PORTAL (they become available again)
          3. Resets customer → DEAL_CREATED  (triggers a new broadcast)
          4. Re-initialises the courier fence (new token for next broadcast)
          5. Notifies both parties

        payload keys:
          deal_id        (str)  — deal being delivered
          courier_phone  (str)  — courier who went dark
          customer_phone (str)  — customer waiting for delivery
        """
        deal_id        = payload.get("deal_id", "")
        courier_phone  = payload.get("courier_phone", "")
        customer_phone = payload.get("customer_phone", "")

        if not (deal_id and courier_phone):
            logger.warning("_on_courier_timeout: missing deal_id or courier_phone in payload")
            return None

        courier_state = self.sm.get_state(courier_phone)
        _ACTIVE_DELIVERY_STATES = {"COURIER_ASSIGNED", "DELIVERY_IN_PROGRESS"}

        if courier_state not in _ACTIVE_DELIVERY_STATES:
            logger.info(
                "_on_courier_timeout: courier_hash=%s state=%s — not in active delivery, skipping",
                hash(courier_phone) % 100_000, courier_state,
            )
            return None

        logger.warning(
            "courier_timeout deal_id=%s courier_hash=%s state=%s",
            deal_id, hash(courier_phone) % 100_000, courier_state,
        )

        # Reset courier — they go back to available pool
        self.sm.set_state(courier_phone, "COURIER_PORTAL")

        # Reset customer — they go back to "finding courier" state
        if customer_phone:
            self.sm.set_state(customer_phone, "DEAL_CREATED")

        # Re-initialise fence so a new broadcast gets a fresh token
        try:
            from app.core.courier_fence import init_fence
            init_fence(self._rdb, deal_id)
        except Exception as exc:
            logger.warning("_on_courier_timeout: init_fence failed [%s]: %s", deal_id, exc)

        _emit(self._rdb, "courier_timeout", {
            "deal_id":        deal_id,
            "courier_hash":   str(hash(courier_phone) % 100_000),
            "customer_hash":  str(hash(customer_phone) % 100_000) if customer_phone else "none",
            "prev_state":     courier_state,
        })
        log_idempotency_event(
            self._rdb, "courier_timeout",
            f"bot:courier_job:{courier_phone}",
            {"deal_id": deal_id},
        )

        # Notify customer — send this message to them via Twilio
        if customer_phone:
            customer_msg = (
                "⚠️ Your courier is unreachable.\n\n"
                "We're finding a new courier for your delivery — "
                "you'll hear from us shortly. Sorry for the delay!"
            )
            # Return value is sent by the caller; for multi-recipient events
            # the webhook controller sends separately
            await _send_notification_async(customer_phone, customer_msg)

        # Return message to courier
        return (
            "⚠️ Your delivery job has been reassigned due to inactivity.\n\n"
            "Type *available* to receive new delivery requests."
        )

    async def _on_escrow_expired(self, payload: Dict) -> Optional[str]:
        """
        Notify customer their escrow expired and a reversal is in progress.

        payload keys:
          phone   (str)
          ref     (str)
          amount  (str)
        """
        phone  = payload.get("phone", "")
        ref    = payload.get("ref", "")
        amount = payload.get("amount", "")

        if not phone:
            return None

        self.sm.set_state(phone, "START")
        _emit(self._rdb, "escrow_expired", {
            "phone_hash": str(hash(phone) % 100_000),
            "ref":        ref,
        })

        return (
            f"⏰ *Order {ref} expired.*\n\n"
            f"Amount US${amount} will be refunded to your wallet within 24 hours.\n\n"
            "Type *1* to place a new order."
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # PRIVATE: State validation guard (H2)
    # ═══════════════════════════════════════════════════════════════════════════

    def _handle_invalid_state(self, phone: str, state: str) -> str:
        """
        [H2] State is missing or not in _HANDLER_MAP.

        Reset to START, emit a state_invalid event, return a welcome message.
        This handles: corrupted state values, state schema migrations,
        unknown states written by future code versions.
        """
        logger.warning(
            "bot.invalid_state phone_hash=%s state=%r — resetting to START",
            hash(phone) % 100_000, state,
        )
        record_state_transition_failure(self._rdb, phone, state, "START")
        _emit(self._rdb, "state_invalid", {
            "phone_hash":    str(hash(phone) % 100_000),
            "invalid_state": state,
        })
        self.sm.set_state(phone, "START")
        return _MSG_STATE_RESET

    # ═══════════════════════════════════════════════════════════════════════════
    # PRIVATE: Claude enrichment
    # ═══════════════════════════════════════════════════════════════════════════

    async def _enrich_with_claude(self, message: str, state: str) -> str:
        """
        Normalise free-text input to a canonical handler keyword.

        "I'd like to buy some bread" → "shop"
        "yes please go ahead" → "confirm"

        Returns original message unchanged if API unavailable or slow.
        Bounded by _CLAUDE_TIMEOUT_S in the caller.
        """
        import os
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            return message

        try:
            import anthropic  # type: ignore[import]
            client = anthropic.Anthropic(api_key=api_key)
            prompt = (
                f"Bot state: '{state}'. User: \"{message}\"\n\n"
                "Reply with ONE keyword from: shop, sell, deliver, status, accept, "
                "reject, cancel, confirm, checkout, collected, delivered, menu, "
                "help, back, yes, no. "
                "If none fit exactly, return the original message unchanged."
            )
            # TEXT MODEL — Haiku sufficient, do NOT use Sonnet (cost)
            resp = client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=20,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text.strip().lower()
        except Exception as exc:
            logger.debug("_enrich_with_claude error: %s", exc)
            return message


# ═══════════════════════════════════════════════════════════════════════════════
# Event dispatch registration
# ═══════════════════════════════════════════════════════════════════════════════

_EVENT_HANDLERS = {
    "payment_confirmed":      "_on_payment_confirmed",
    "courier_job_broadcast":  "_on_courier_job_broadcast",
    "courier_accepted":       "_on_courier_accepted",
    "courier_timeout":        "_on_courier_timeout",
    "session_timeout":        "_on_session_timeout",
    "escrow_expired":         "_on_escrow_expired",
}


# ═══════════════════════════════════════════════════════════════════════════════
# Module-level observability helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _emit(rdb: Any, event_type: str, fields: Dict) -> None:
    """
    Write a structured event to metrics:events stream.

    Centralised here so every engine event has a consistent shape:
      { type, ts, ...fields }

    Never raises — metrics must never block or crash business logic.
    """
    from app.core.metrics import _xadd  # type: ignore[attr-defined]
    try:
        _xadd(rdb, event_type, fields)
    except Exception:
        pass


async def _send_notification_async(phone: str, message: str) -> None:
    """
    Fire-and-forget WhatsApp notification.  Never raises.
    Used by event handlers that need to notify multiple parties.
    """
    import asyncio
    try:
        from app.routers.webhook_controller import _send_whatsapp_sync
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, _send_whatsapp_sync, phone, message)
    except Exception as exc:
        logger.debug("_send_notification_async failed [phone_hash=%s]: %s",
                     hash(phone) % 100_000, exc)


def _emit_error(
    rdb: Any,
    event_type: str,
    phone: str,
    error_msg: str,
    duration_ms: float,
) -> None:
    """Emit an error event with standardised fields."""
    from app.core.metrics import record_redis_failure
    _emit(rdb, event_type, {
        "phone_hash":  str(hash(phone) % 100_000) if phone else "system",
        "error":       error_msg[:200],
        "duration_ms": f"{duration_ms:.1f}",
    })
    # Also surface in the redis_failure counter so /metrics/health picks it up
    record_redis_failure(rdb, event_type, error_msg[:100])
