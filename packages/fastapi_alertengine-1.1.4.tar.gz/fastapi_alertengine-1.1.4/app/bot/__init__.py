# app/bot/__init__.py
"""
AnchorFlow Bot Runtime — WhatsApp Commerce Engine.

Public surface:
    BotEngine          — core orchestrator
    RedisStateManager  — Redis abstraction layer

Internal surface (used by BotEngine only):
    app.bot.handlers.*
"""

from app.bot.engine import BotEngine
from app.bot.state_manager import RedisStateManager

__all__ = ["BotEngine", "RedisStateManager"]
