# app/bot/locks.py
"""
Token-based distributed lock manager for the AnchorFlow bot runtime.

Problem with plain SET NX locks
────────────────────────────────
A plain NX lock grants DEL permission to *any* caller, including a
process whose TTL already expired and was re-issued to another holder.
This creates a race:

  T=0  Worker A acquires lock (TTL = 5s)
  T=4  Worker A is slow; TTL not yet expired
  T=5  Redis evicts key; Worker B acquires a NEW lock
  T=6  Worker A finishes, calls DEL — deletes Worker B's lock ❌

Token-safe solution
────────────────────
Each acquire() generates a unique token (UUID hex).  The token is stored
as the lock value.  Release uses a Lua script that:
  1. GETs the current value
  2. Compares it to the caller's token
  3. DELetes only on match

This is atomic — no TOCTOU window.

Keys managed here
─────────────────
  bot:state_lock:{phone}    — per-session mutex (5 s) for message processing
  bot:deal_lock:{deal_id}   — per-deal mutex (30 s) for payment + courier ops

Usage::

    from app.bot.locks import TokenLock

    lock  = TokenLock(rdb)
    token = lock.acquire("bot:state_lock:+263771234567", ttl=5)
    if token:
        try:
            ...
        finally:
            lock.release("bot:state_lock:+263771234567", token)
    else:
        # lock contention — another request is processing this phone
"""

import logging
import uuid
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ── Lua: atomic token-safe release ───────────────────────────────────────────
# Returns 1 if deleted (token matched), 0 if not (token mismatch or key gone).

_RELEASE_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
else
    return 0
end
"""

# Lua: acquire with token — SET NX EX in one round trip
# Returns 'OK' on success, nil on contention.
_ACQUIRE_LUA = """
return redis.call('SET', KEYS[1], ARGV[1], 'NX', 'EX', tonumber(ARGV[2]))
"""


class TokenLock:
    """
    Token-safe distributed lock over Redis.

    Thread-safe: each acquire() call generates a fresh UUID token.
    The only holder that can release the lock is the one that holds the token.

    Fails open:
        - acquire() → returns a dummy token on Redis error (lock not set)
          This preserves availability; we accept reduced exclusivity during
          Redis degradation.
        - release() → logs on failure, does not raise.
    """

    __slots__ = ("_r", "_script_cache")

    def __init__(self, rdb: Any) -> None:
        self._r = rdb
        self._script_cache: dict = {}

    def _get_script(self, name: str, lua: str):
        """Cache registered Lua scripts per name to avoid re-registration."""
        if name not in self._script_cache:
            try:
                self._script_cache[name] = self._r.register_script(lua)
            except Exception:
                self._script_cache[name] = None
        return self._script_cache[name]

    def acquire(self, key: str, ttl: int) -> Optional[str]:
        """
        Attempt to acquire the lock.

        Args:
            key: Redis key for the lock (e.g. "bot:state_lock:+263...").
            ttl: Lock expiry in seconds.  Must be > 0.

        Returns:
            A unique token string if acquired.
            None if the lock is already held.

        Fails open on Redis error: returns a sentinel token so the caller
        continues operating (reduced exclusivity is preferable to total
        unavailability when Redis is degraded).
        """
        token = uuid.uuid4().hex
        try:
            script = self._get_script("acquire", _ACQUIRE_LUA)
            if script is not None:
                result = script(keys=[key], args=[token, str(ttl)])
                if result == b"OK" or result == "OK":
                    return token
                return None   # contention

            # Fallback: plain SET NX EX
            acquired = self._r.set(key, token, nx=True, ex=ttl)
            return token if acquired else None

        except Exception as exc:
            logger.warning("TokenLock.acquire failed [%s]: %s — failing open", key, exc)
            # Fail open: return a fail-open sentinel that will pass release()
            return f"failopen:{token}"

    def release(self, key: str, token: Optional[str]) -> bool:
        """
        Release the lock if and only if the token matches.

        Args:
            key:   Lock key.
            token: Token returned by acquire().

        Returns:
            True if released, False if token mismatch or key already expired.
        """
        if token is None:
            return False

        # Fail-open tokens were issued when Redis was down; no-op release
        if token.startswith("failopen:"):
            return True

        try:
            script = self._get_script("release", _RELEASE_LUA)
            if script is not None:
                result = script(keys=[key], args=[token])
                released = bool(result)
                if not released:
                    logger.debug("TokenLock.release: token mismatch [%s]", key)
                return released

            # Fallback: unsafe DEL (no token check — only used if Lua unavailable)
            logger.warning("TokenLock.release: Lua unavailable — unsafe DEL for [%s]", key)
            self._r.delete(key)
            return True

        except Exception as exc:
            logger.warning("TokenLock.release failed [%s]: %s", key, exc)
            return False

    def is_locked(self, key: str) -> bool:
        """Return True if the lock key exists (convenience for health checks)."""
        try:
            return bool(self._r.exists(key))
        except Exception:
            return False
