# app/maintenance/key_cleanup.py
import logging
import atexit
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Callable, Tuple
from uuid import UUID

logger = logging.getLogger(__name__)


class ExpiredKeyCleanup:
    """
    Scheduled job: Purge expired archived keys from Vault.

    Production Features:
    - Batched deletion (prevents Vault overload)
    - Configurable batch delay (rate limiting / throttling)
    - Idempotent operations (safe to retry)
    - Graceful scheduler shutdown (wait=True)
    - Single-instance scheduler guard (safe for web server contexts)
    - Alert callbacks (Slack, email, PagerDuty, etc.)
    - Comprehensive logging
    - Transaction safety
    - Aggregated failed key reporting (post-mortem analysis)
    """

    # ─────────────────────────────────────────────────────
    # CLASS-LEVEL CONFIGURATION
    # ─────────────────────────────────────────────────────

    DEFAULT_BATCH_SIZE = 50
    DEFAULT_BATCH_DELAY_SECONDS = 0       # 0 = no delay (set >0 for rate-limited Vaults)
    DEFAULT_DRY_RUN_INTERVAL = timedelta(days=7)
    CLEANUP_INTERVAL = timedelta(days=30)

    # Singleton guard: prevents duplicate schedulers in multi-worker web servers
    _scheduler_started: bool = False

    def __init__(
        self,
        db_session,
        vault_client,
        alert_func: Optional[Callable[[str], None]] = None,
        batch_size: int = DEFAULT_BATCH_SIZE,
        batch_delay_seconds: int = DEFAULT_BATCH_DELAY_SECONDS,
    ):
        """
        Args:
            db_session:            SQLAlchemy session
            vault_client:          Vault client (authenticated)
            alert_func:            Optional alert callback (signature: func(message: str))
            batch_size:            Keys to delete per batch (default: 50)
            batch_delay_seconds:   Seconds to sleep between batches (default: 0)
                                   Set > 0 when Vault has strict API rate limits.
        """
        self.db = db_session
        self.vault = vault_client
        self.alert_func = alert_func
        self.batch_size = batch_size
        self.batch_delay_seconds = batch_delay_seconds
        self._scheduler = None

        self._init_scheduler()

    # ─────────────────────────────────────────────────────
    # MAIN CLEANUP LOGIC
    # ─────────────────────────────────────────────────────

    def cleanup_expired_keys(self, dry_run: bool = False) -> Dict:
        """
        Find and purge expired archived keys from Vault.

        Args:
            dry_run: If True, only report what would be deleted (no actual deletion).

        Returns:
            Comprehensive summary dict including:
            - status, checked, expired_count, valid_count,
            - deleted_count, failed_count, errors, deleted, failed
        """
        from app.models.database import KeyCleanupLog

        now = datetime.now(timezone.utc)

        logger.info(
            "Starting key cleanup",
            extra={"dry_run": dry_run, "timestamp": now.isoformat()}
        )

        # ── List Archived Keys ────────────────────────────
        try:
            archived_keys = self.vault.list_secrets("tandem/encryption/archived_keys")
            if not archived_keys:
                logger.info("No archived keys found in Vault.")
                return {
                    "status": "success",
                    "message": "No archived keys to clean",
                    "expired_count": 0,
                    "valid_count": 0,
                    "deleted_count": 0,
                    "failed_count": 0,
                }
        except Exception as e:
            error_msg = f"Failed to list archived keys: {e}"
            logger.error(error_msg, exc_info=True)
            self._send_alert(f"🚨 Key Cleanup Error: {error_msg}")
            return {"status": "failed", "error": error_msg}

        expired_keys: List[Dict] = []
        still_valid: List[str] = []
        scan_errors: List[Dict] = []
        checked = 0

        # ─────────────────────────────────────────────────────
        # PHASE 1: SCAN ALL KEYS
        # ─────────────────────────────────────────────────────

        for key_id in archived_keys:
            try:
                self._validate_key_id(key_id)

                secret = self.vault.get_secret(
                    f"tandem/encryption/archived_keys/{key_id}"
                )

                expiry_str = secret.get("expiry")
                if not expiry_str:
                    logger.warning(f"No expiry date for archived key {key_id}, skipping.")
                    still_valid.append(key_id)
                    checked += 1
                    continue

                expiry = self._parse_timestamp(expiry_str)

                if expiry <= now:
                    expired_keys.append({
                        "key_id": key_id,
                        "expiry": expiry_str,
                        "rotation_id": secret.get("rotation_id"),
                        "archived_at": secret.get("archived_at"),
                    })
                    logger.debug(f"Key {key_id} expired at {expiry_str}")
                else:
                    still_valid.append(key_id)
                    days_remaining = (expiry - now).days
                    logger.debug(f"Key {key_id} valid for {days_remaining} more day(s)")

                checked += 1

            except ValueError as e:
                logger.warning(f"Validation error for key {key_id}: {e}")
                scan_errors.append({"key_id": key_id, "error": str(e)})
            except Exception as e:
                logger.warning(f"Unexpected error checking key {key_id}: {e}")
                scan_errors.append({"key_id": key_id, "error": str(e)})

        # ─────────────────────────────────────────────────────
        # PHASE 2: DRY-RUN REPORT
        # ─────────────────────────────────────────────────────

        cleanup_result = {
            "timestamp": now.isoformat(),
            "dry_run": dry_run,
            "checked": checked,
            "expired_count": len(expired_keys),
            "valid_count": len(still_valid),
            "scan_errors": len(scan_errors),
            "scan_error_details": scan_errors if scan_errors else None,
        }

        if dry_run:
            logger.info(
                "KEY_CLEANUP_DRY_RUN: would delete %d keys, keeping %d valid keys",
                len(expired_keys),
                len(still_valid),
                extra=cleanup_result,
            )
            return {
                **cleanup_result,
                "status": "dry_run_complete",
                "would_delete": [k["key_id"] for k in expired_keys],
                "would_keep": still_valid,
            }

        # ─────────────────────────────────────────────────────
        # PHASE 3: ACTUAL DELETION
        # ─────────────────────────────────────────────────────

        deleted: List[str] = []
        failed: List[Dict] = []

        if expired_keys:
            deleted, failed = self._delete_expired_keys_batched(expired_keys)

        cleanup_result.update({
            "deleted_count": len(deleted),
            "failed_count": len(failed),
            "deleted": deleted,
            "failed": failed if failed else None,   # None when clean; dict when not
        })

        # ─────────────────────────────────────────────────────
        # PHASE 4: LOG & ALERT
        # ─────────────────────────────────────────────────────

        logger.info(
            "KEY_CLEANUP_COMPLETE: deleted=%d, failed=%d, valid=%d",
            len(deleted),
            len(failed),
            len(still_valid),
            extra=cleanup_result,
        )

        if len(deleted) > 10:
            self._send_alert(
                f"✅ Key Cleanup: Deleted {len(deleted)} expired keys. "
                f"{len(still_valid)} remain valid."
            )

        if failed:
            self._send_alert(
                f"⚠️ Key Cleanup: {len(failed)} key(s) failed to delete. "
                f"Review cleanup_result['failed'] for post-mortem details."
            )

        return {**cleanup_result, "status": "success"}

    # ─────────────────────────────────────────────────────
    # BATCHED DELETION WITH TRANSACTION SAFETY
    # ─────────────────────────────────────────────────────

    def _delete_expired_keys_batched(
        self,
        expired_keys: List[Dict],
    ) -> Tuple[List[str], List[Dict]]:
        """
        Delete expired keys in batches with:
        - Atomic transactions per batch
        - Configurable rate-limit delay between batches
        - Aggregated failed key reporting

        Returns:
            Tuple of (deleted_key_ids, failed_entries)
            failed_entries: [{"key_id": str, "error": str}, ...]
        """
        from app.models.database import KeyCleanupLog
        from sqlalchemy.exc import SQLAlchemyError

        all_deleted: List[str] = []
        all_failed: List[Dict] = []
        batch_num = 0

        for i in range(0, len(expired_keys), self.batch_size):
            batch = expired_keys[i : i + self.batch_size]
            batch_num += 1

            batch_deleted: List[str] = []
            batch_failed: List[Dict] = []

            try:
                with self.db.begin_nested():
                    for key_info in batch:
                        key_id = key_info["key_id"]

                        try:
                            # ── Idempotency Guard ─────────────────────
                            if self._already_deleted(key_id):
                                logger.info(
                                    f"Key {key_id} already deleted — skipping (idempotent)"
                                )
                                batch_deleted.append(key_id)
                                continue

                            # ── Vault Deletion ────────────────────────
                            self.vault.delete_secret(
                                f"tandem/encryption/archived_keys/{key_id}"
                            )

                            # ── Audit Log ─────────────────────────────
                            self.db.add(
                                KeyCleanupLog(
                                    key_id=key_id,
                                    rotation_id=key_info.get("rotation_id"),
                                    expiry_date=key_info.get("expiry"),
                                    deleted_at=datetime.now(timezone.utc),
                                    status="deleted",
                                )
                            )
                            batch_deleted.append(key_id)
                            logger.info(f"Batch {batch_num}: Deleted key {key_id}")

                        except Exception as e:
                            logger.error(f"Failed to delete key {key_id}: {e}")

                            # ── Failure Audit Log ─────────────────────
                            self.db.add(
                                KeyCleanupLog(
                                    key_id=key_id,
                                    rotation_id=key_info.get("rotation_id"),
                                    expiry_date=key_info.get("expiry"),
                                    deleted_at=datetime.now(timezone.utc),
                                    status="failed",
                                    error_message=str(e),
                                )
                            )
                            batch_failed.append({"key_id": key_id, "error": str(e)})

                # ── Commit Batch ──────────────────────────────────────
                self.db.commit()
                all_deleted.extend(batch_deleted)
                all_failed.extend(batch_failed)

                logger.info(
                    f"Batch {batch_num} committed: "
                    f"{len(batch_deleted)} deleted, {len(batch_failed)} failed"
                )

            except SQLAlchemyError as e:
                self.db.rollback()
                logger.error(f"DB transaction failed for batch {batch_num}: {e}")
                self._send_alert(f"⚠️ Key Cleanup: Batch {batch_num} DB error: {e}")

            except Exception as e:
                logger.error(
                    f"Unexpected error in batch {batch_num}: {e}", exc_info=True
                )
                self._send_alert(
                    f"🚨 Key Cleanup: Batch {batch_num} unexpected error: {e}"
                )

            # ── Rate Limiting: Sleep Between Batches ──────────────────
            # Prevents overwhelming Vault API under high key volumes.
            if self.batch_delay_seconds > 0:
                logger.debug(
                    f"Sleeping {self.batch_delay_seconds}s before next batch "
                    f"(rate-limit guard)..."
                )
                time.sleep(self.batch_delay_seconds)

        return all_deleted, all_failed

    # ─────────────────────────────────────────────────────
    # IDEMPOTENCY & VALIDATION
    # ─────────────────────────────────────────────────────

    def _already_deleted(self, key_id: str) -> bool:
        """Check if key was already successfully deleted (idempotency guard)."""
        from app.models.database import KeyCleanupLog

        return (
            self.db.query(KeyCleanupLog)
            .filter_by(key_id=key_id, status="deleted")
            .first()
            is not None
        )

    def _validate_key_id(self, key_id: str) -> None:
        """Validate that key_id is a well-formed UUID."""
        try:
            UUID(key_id)
        except ValueError:
            raise ValueError(f"Invalid key_id format (expected UUID): {key_id}")

    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """
        Parse an ISO 8601 timestamp string into a timezone-aware datetime.
        
        Raises:
            ValueError: If the timestamp format is unrecognised.
        """
        try:
            dt = datetime.fromisoformat(timestamp_str)
            # Ensure timezone-aware for safe comparison with UTC now
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError as e:
            raise ValueError(
                f"Invalid timestamp format '{timestamp_str}': {e}"
            )

    # ─────────────────────────────────────────────────────
    # SCHEDULING & LIFECYCLE
    # ─────────────────────────────────────────────────────

    def _init_scheduler(self) -> None:
        """
        Initialise and start the APScheduler BackgroundScheduler.

        Singleton guard prevents duplicate schedulers in multi-worker
        web server deployments (gunicorn, uvicorn, etc.).
        """
        if ExpiredKeyCleanup._scheduler_started:
            logger.warning(
                "Scheduler already started by another instance — skipping. "
                "Ensure only one ExpiredKeyCleanup instance is initialised per process."
            )
            return

        from apscheduler.schedulers.background import BackgroundScheduler

        self._scheduler = BackgroundScheduler()
        self._register_jobs()
        self._scheduler.start()

        ExpiredKeyCleanup._scheduler_started = True
        logger.info("Key cleanup scheduler started.")

        # Explicit wait=True for clean thread join on shutdown
        atexit.register(lambda: self._scheduler.shutdown(wait=True))

    def _register_jobs(self) -> None:
        """
        Register cron jobs on the scheduler.

        Schedule:
            Weekly dry-run  — Every Monday  @ 01:00 UTC (report only)
            Monthly cleanup — Every 15th    @ 01:00 UTC (actual deletion)
        """
        if self._scheduler is None:
            return

        # ── Weekly Dry-Run ────────────────────────────────
        self._scheduler.add_job(
            func=self.cleanup_expired_keys,
            trigger="cron",
            day_of_week="mon",
            hour=1,
            minute=0,
            kwargs={"dry_run": True},
            id="weekly_key_cleanup_dry_run",
            replace_existing=True,       # Safe re-registration on reload
        )

        # ── Monthly Actual Cleanup ────────────────────────
        self._scheduler.add_job(
            func=self.cleanup_expired_keys,
            trigger="cron",
            day=15,
            hour=1,
            minute=0,
            kwargs={"dry_run": False},
            id="monthly_key_cleanup",
            replace_existing=True,
        )

        logger.info(
            "Key cleanup jobs registered: "
            "[weekly_dry_run=Mon@01:00] "
            "[monthly_cleanup=15th@01:00]"
        )

    # ─────────────────────────────────────────────────────
    # ALERTING
    # ─────────────────────────────────────────────────────

    def _send_alert(self, message: str) -> None:
        """
        Dispatch an alert via the configured alert_func.
        Silently no-ops if no alert_func is configured.
        """
        if self.alert_func:
            try:
                self.alert_func(message)
            except Exception as e:
                # Alert failure must NEVER crash the cleanup job
                logger.error(f"Alert dispatch failed: {e}")
