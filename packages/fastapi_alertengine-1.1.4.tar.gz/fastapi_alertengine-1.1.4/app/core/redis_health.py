# app/core/redis_health.py
"""
Redis liveness check for fail-fast webhook guard.

Design philosophy
─────────────────
SafeRedis already handles degraded Redis transparently via its circuit
breaker + ephemeral fallback.  That is the right behaviour for *background*
work (metrics writes, idempotency events) where losing a few entries is
acceptable.

At the *webhook boundary*, however, we must be more conservative:

  If the circuit is OPEN (Redis unreachable for 30s), SafeRedis falls
  back to a per-process _EphemeralStore.  That store has no cross-process
  visibility.  Two Railway instances would each have their own state — a
  user's message on instance A would see a different session from instance B.
  This is a *consistency violation*, not just a performance issue.

  → We refuse to process the message and return a clean "system busy" reply.

We do NOT try to work around Redis failure.  Fail fast, fail clean.

Usage::

    rdb = build_safe_redis(...)
    if not redis_healthy(rdb):
        return _twiml("System temporarily busy. Please try again.")
"""

import logging
import time
from typing import Any

logger = logging.getLogger(__name__)

# Acceptable PING latency before we consider Redis "unhealthy even if connected"
_MAX_LATENCY_MS = 500.0


def redis_healthy(rdb: Any) -> bool:
    """
    Return True only if Redis is reachable AND the circuit breaker is closed.

    Two-phase check:
      1. (Fast, no I/O) If rdb is a SafeRedis and its circuit is OPEN,
         return False immediately — ephemeral fallback is active.
      2. (Live) Issue a PING and measure round-trip.  If it fails or takes
         longer than _MAX_LATENCY_MS, return False.

    Fails CLOSED (returns True) only when both checks pass.
    Fails OPEN (returns False) on any error or circuit-open state.
    """
    # ── Phase 1: circuit breaker state (zero I/O) ─────────────────────────────
    circuit_open = _check_circuit_open(rdb)
    if circuit_open is True:
        logger.warning("redis_health: circuit OPEN — ephemeral fallback active — refusing request")
        return False

    # ── Phase 2: live PING with latency guard ─────────────────────────────────
    t0 = time.perf_counter()
    try:
        rdb.execute_command("PING")
        latency_ms = (time.perf_counter() - t0) * 1000
        if latency_ms > _MAX_LATENCY_MS:
            logger.warning(
                "redis_health: PING latency %.0fms > threshold %.0fms — unhealthy",
                latency_ms, _MAX_LATENCY_MS,
            )
            return False
        return True
    except Exception as exc:
        latency_ms = (time.perf_counter() - t0) * 1000
        logger.warning(
            "redis_health: PING failed after %.0fms: %s", latency_ms, exc
        )
        return False


def _check_circuit_open(rdb: Any) -> bool:
    """
    Return True if SafeRedis reports the circuit breaker as open.
    Returns False if the circuit is closed, or None if rdb is not SafeRedis.
    """
    try:
        # SafeRedis exposes circuit_open as a property
        circuit_open = getattr(rdb, "circuit_open", None)
        if circuit_open is not None:
            return bool(circuit_open)
        # Fallback: check _circuit directly if available
        circuit = getattr(rdb, "_circuit", None)
        if circuit is not None:
            return bool(getattr(circuit, "is_open", False))
    except Exception as exc:
        logger.debug("_check_circuit_open error: %s", exc)
    return False
