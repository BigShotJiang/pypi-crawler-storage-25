# app/core/courier_fence.py
"""
Courier acceptance fence — atomic first-accept-wins locking for deal assignments.

Problem:
  When a deal is broadcast to N couriers simultaneously, multiple couriers may
  accept within the same millisecond.  A plain SET NX is a single-hop race;
  under load it still produces occasional double-assignments.

Solution:
  A monotonic fence counter per deal.  Each courier job includes the expected
  fence token.  Acceptance is a Lua script that atomically:
    1. Reads the current fence value.
    2. Rejects if it doesn't match the expected token (stale broadcast).
    3. Sets the acceptance lock (NX) with courier metadata.
    4. Increments the fence (invalidates any in-flight accepts for this deal).

  If Lua is unavailable (Redis < 2.6 or NOSCRIPT), falls back to plain NX,
  which is still correct — just without the stale-token check.

Keys used:
  bot:courier_fence:{deal_id}   — integer counter, TTL = job TTL
  bot:courier_accept:{deal_id}  — JSON lock value, TTL = job TTL

Usage::

    from app.core.courier_fence import init_fence, get_fence_token, atomic_accept

    # When broadcasting the job:
    init_fence(_redis, deal_id)
    token = get_fence_token(_redis, deal_id)   # include in job_data

    # When courier accepts:
    status, payload = atomic_accept(_redis, deal_id, courier_phone, expected_fence=token)
    if status == "ok":
        # This courier won the race
    elif status == "taken":
        # Another courier already accepted
    elif status == "stale":
        # Courier's token is outdated (deal was re-broadcast)
"""

import json
import logging
import time
from typing import Any, Optional, Tuple

import redis

logger = logging.getLogger(__name__)

# ─── KEY HELPERS ──────────────────────────────────────────────────────────────

def _fence_key(deal_id: str) -> str:
    return f"bot:courier_fence:{deal_id}"

def _lock_key(deal_id: str) -> str:
    return f"bot:courier_accept:{deal_id}"


# ─── LUA SCRIPT ───────────────────────────────────────────────────────────────
# KEYS[1] = fence key, KEYS[2] = lock key
# ARGV[1] = expected fence token (string-encoded int)
# ARGV[2] = lock value (JSON with courier_phone, assigned_at, fence_token)
# ARGV[3] = TTL seconds
#
# Returns:
#   "ok"      — lock acquired, fence incremented
#   "taken"   — another courier already holds the lock (deal already assigned)
#   "stale"   — fence token mismatch (deal re-broadcast; job is outdated)
#   "expired" — fence key is missing (job TTL elapsed; deal is no longer active)
#
# The distinction between "stale" and "expired" is important for UX:
#   "expired" → tell courier the job is gone (no new job from this deal)
#   "stale"   → courier has an old token; a re-broadcast may come

_ACCEPT_LUA = """
local fence_key = KEYS[1]
local lock_key  = KEYS[2]
local expected  = ARGV[1]
local lock_val  = ARGV[2]
local ttl       = tonumber(ARGV[3])

-- Read current fence; missing key means job TTL elapsed → expired
local current = redis.call('GET', fence_key)
if current == false then
    return 'expired'
end

-- Token mismatch → deal was re-broadcast; courier's job is outdated
if current ~= expected then
    return 'stale'
end

-- Check for existing winner (deal already assigned)
local existing = redis.call('GET', lock_key)
if existing then
    return 'taken'
end

-- Acquire lock atomically (NX = only if not exists)
redis.call('SET', lock_key, lock_val, 'EX', ttl, 'NX')

-- Verify we won (guards against exact-same-millisecond concurrent executions)
local winner = redis.call('GET', lock_key)
if winner ~= lock_val then
    return 'taken'
end

-- Increment fence — invalidates all in-flight accepts carrying the old token
redis.call('INCR', fence_key)

return 'ok'
"""

# We register the script lazily per connection pool to avoid
# cross-process NOSCRIPT errors.
_SCRIPT_CACHE: dict = {}   # rdb id → redis.client.Script


def _get_script(rdb: Any):
    """Return a cached registered script for this Redis connection."""
    rdb_id = id(rdb)
    if rdb_id not in _SCRIPT_CACHE:
        try:
            _SCRIPT_CACHE[rdb_id] = rdb.register_script(_ACCEPT_LUA)
        except Exception:
            _SCRIPT_CACHE[rdb_id] = None
    return _SCRIPT_CACHE[rdb_id]


# ─── PUBLIC API ───────────────────────────────────────────────────────────────

def init_fence(rdb: Any, deal_id: str, ttl: int = 1800) -> None:
    """
    Initialise the fence counter for a new deal broadcast.

    Should be called once, when the deal is first assigned to couriers.
    Idempotent: NX means an existing fence is not overwritten.

    Args:
        rdb:     Redis client.
        deal_id: Unique deal identifier (e.g. TDM-7G4K9).
        ttl:     Seconds before the fence key expires (default 30 min).
    """
    try:
        rdb.setnx(_fence_key(deal_id), "0")
        rdb.expire(_fence_key(deal_id), ttl)
    except Exception as exc:
        logger.warning("init_fence failed [%s]: %s", deal_id, exc)


def get_fence_token(rdb: Any, deal_id: str) -> Optional[str]:
    """
    Read the current fence token for a deal.

    Returns None if the fence key is missing (expired or never initialised).
    """
    try:
        raw = rdb.get(_fence_key(deal_id))
        if raw is None:
            return None
        return raw.decode() if isinstance(raw, bytes) else str(raw)
    except Exception as exc:
        logger.warning("get_fence_token failed [%s]: %s", deal_id, exc)
        return None


def atomic_accept(
    rdb: Any,
    deal_id: str,
    courier_phone: str,
    expected_fence: Optional[str],
    ttl: int = 1800,
) -> Tuple[str, Optional[dict]]:
    """
    Attempt to atomically accept a courier job.

    Args:
        rdb:            Redis client.
        deal_id:        Deal identifier.
        courier_phone:  Phone of the accepting courier.
        expected_fence: Fence token from the original job broadcast.
                        If None, falls back to plain NX lock.
        ttl:            Lock TTL in seconds.

    Returns:
        (status, payload) where:
          status  — "ok" | "taken" | "stale" | "error"
          payload — dict with winner details if status == "ok", else None.
    """
    lock_val = json.dumps({
        "courier_phone": courier_phone,
        "assigned_at":   int(time.time() * 1000),
        "fence_token":   expected_fence,
    })

    # ── Lua path ──────────────────────────────────────────────────────────────
    if expected_fence is not None:
        script = _get_script(rdb)
        if script is not None:
            try:
                result = script(
                    keys=[_fence_key(deal_id), _lock_key(deal_id)],
                    args=[expected_fence, lock_val, str(ttl)],
                )
                status = result.decode() if isinstance(result, bytes) else str(result)
                if status == "ok":
                    return "ok", json.loads(lock_val)
                return status, None
            except redis.exceptions.NoScriptError:
                # Script was flushed from Redis — re-register and fall through to NX
                _SCRIPT_CACHE.pop(id(rdb), None)
                logger.warning("atomic_accept: NOSCRIPT — re-registering, falling back to NX")
            except Exception as exc:
                logger.error("atomic_accept Lua error [%s]: %s", deal_id, exc)
                # Fall through to NX plain lock

    # ── NX fallback (no Lua or no fence token) ────────────────────────────────
    try:
        acquired = rdb.setnx(_lock_key(deal_id), lock_val)
        if acquired:
            rdb.expire(_lock_key(deal_id), ttl)
            return "ok", json.loads(lock_val)
        return "taken", None
    except Exception as exc:
        logger.error("atomic_accept NX fallback failed [%s]: %s", deal_id, exc)
        return "error", None
