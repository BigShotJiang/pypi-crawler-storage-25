"""
Centralized Redis client for AnchorFlow.

Purpose:
- Decouple Redis usage from routers/services
- Provide a single, reusable client across the application
- Ensure consistent configuration and connection handling
"""

import redis
from typing import Optional
from app.core.config import settings


class RedisClient:
    """
    Singleton-style Redis client wrapper.

    Ensures:
    - Single connection pool
    - Safe initialization
    - Reusability across services
    """

    _client: Optional[redis.Redis] = None

    @classmethod
    def get_client(cls) -> redis.Redis:
        """Get or initialize Redis client"""
        if cls._client is None:
            cls._client = redis.Redis(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                db=getattr(settings, "REDIS_DB", 0),
                password=getattr(settings, "REDIS_PASSWORD", None),
                decode_responses=True,  # important for string handling
                socket_timeout=5,
                socket_connect_timeout=5,
                retry_on_timeout=True,
            )
        return cls._client


# Public singleton instance
redis_client = RedisClient.get_client()
