"""
app/core/config.py

Settings shim for modules that import from app.core.config.

Wraps the base app.config.settings singleton and extends it with
infrastructure-level config (Redis, HMAC) read from environment variables
that are not part of the core application settings dataclass.

Usage::

    from app.core.config import settings
    settings.REDIS_HOST       # str
    settings.REDIS_PORT       # int
    settings.REDIS_DB         # int
    settings.REDIS_PASSWORD   # str | None
    settings.HMAC_SECRET      # str
"""

import os

from app.config import settings as _base_settings


class _Settings:
    """
    Proxy for app.config.settings that adds infrastructure env vars.

    Attribute lookup order:
    1. Infrastructure overrides (REDIS_*, HMAC_SECRET).
    2. Base Settings dataclass delegation.
    """

    # ── Redis ─────────────────────────────────────────────────────────────────

    @property
    def REDIS_HOST(self) -> str:
        return os.getenv("REDIS_HOST", "localhost")

    @property
    def REDIS_PORT(self) -> int:
        return int(os.getenv("REDIS_PORT", "6379"))

    @property
    def REDIS_DB(self) -> int:
        return int(os.getenv("REDIS_DB", "0"))

    @property
    def REDIS_PASSWORD(self):
        return os.getenv("REDIS_PASSWORD") or None

    # ── HMAC (signed URLs for media proxying) ─────────────────────────────────

    @property
    def HMAC_SECRET(self) -> str:
        return os.getenv("HMAC_SECRET", "change-me-in-production")

    # ── Delegation to base settings ───────────────────────────────────────────

    def __getattr__(self, name: str):
        return getattr(_base_settings, name)


settings = _Settings()
