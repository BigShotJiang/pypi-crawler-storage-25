# app/core/alert_notification_service.py
"""
AlertNotificationService — async, non-blocking alert dispatch.

Sends notifications (email and/or Slack) when a critical alert fires.
Notifications are best-effort: delivery failures are logged but never
propagate exceptions to the caller so they cannot break the health-check
endpoint.

Configuration (environment variables):
  ALERT_EMAIL_TO        — comma-separated recipient emails  (optional)
  ALERT_SLACK_WEBHOOK   — Slack Incoming Webhook URL         (optional)
  SMTP_HOST             — SMTP server host (default: localhost)
  SMTP_PORT             — SMTP server port (default: 587)
  SMTP_USER             — SMTP username (optional)
  SMTP_PASSWORD         — SMTP password (optional)
  SMTP_FROM             — From address (default: alerts@anchorflow.com)

If neither ``ALERT_EMAIL_TO`` nor ``ALERT_SLACK_WEBHOOK`` is set, the service
is effectively a no-op (logs a debug message and returns immediately).

Design constraints:
  - Non-custodial: no financial mutations.
  - Async: callers are not blocked by network I/O.
  - Configurable thresholds by severity (only "critical" by default).
  - All dispatches are logged for RBZ auditability.
"""

import asyncio
import json
import logging
import os
import smtplib
from email.message import EmailMessage
from typing import Any, Dict, List, Optional
from urllib import request as urllib_request

logger = logging.getLogger(__name__)

# Severities that trigger a notification by default
_DEFAULT_NOTIFY_SEVERITIES = {"critical"}


class AlertNotificationService:
    """
    Dispatch email and/or Slack notifications for critical alerts.

    Args:
        notify_severities: Set of severity strings that trigger dispatch.
            Defaults to ``{"critical"}``.

    All public methods are **async** but perform blocking I/O via
    ``asyncio.get_event_loop().run_in_executor`` so the FastAPI event loop
    is never blocked.
    """

    def __init__(
        self,
        notify_severities: Optional[set] = None,
    ) -> None:
        self._notify_severities = notify_severities or _DEFAULT_NOTIFY_SEVERITIES

        # Runtime config — read once at construction so tests can patch env vars
        self._email_to: List[str] = [
            addr.strip()
            for addr in os.getenv("ALERT_EMAIL_TO", "").split(",")
            if addr.strip()
        ]
        self._slack_webhook: str = os.getenv("ALERT_SLACK_WEBHOOK", "")
        self._smtp_host: str = os.getenv("SMTP_HOST", "localhost")
        self._smtp_port: int = int(os.getenv("SMTP_PORT", "587"))
        self._smtp_user: str = os.getenv("SMTP_USER", "")
        self._smtp_password: str = os.getenv("SMTP_PASSWORD", "")
        self._smtp_from: str = os.getenv("SMTP_FROM", "alerts@anchorflow.com")

    # ── Public API ────────────────────────────────────────────────────────────

    async def notify(
        self,
        alert_type: str,
        severity: str,
        value: float,
        threshold: float,
        reason: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Fire-and-forget notification for an alert.

        Only dispatches if ``severity`` is in ``notify_severities``.  Both
        email and Slack targets are attempted independently; a failure in one
        does not prevent the other from being sent.

        Args:
            alert_type: Machine-readable alert identifier.
            severity:   Alert severity string (e.g. ``"critical"``).
            value:      Observed metric value that triggered the alert.
            threshold:  Threshold that was breached.
            reason:     Human-readable description of the alert.
            metadata:   Optional additional context dict.
        """
        if severity not in self._notify_severities:
            logger.debug(
                "alert_notification: severity=%s not in notify_severities — skip",
                severity,
            )
            return

        if not self._email_to and not self._slack_webhook:
            logger.debug(
                "alert_notification: no destinations configured — skip [%s]",
                alert_type,
            )
            return

        payload = {
            "alert_type": alert_type,
            "severity": severity,
            "value": value,
            "threshold": threshold,
            "reason": reason,
            "metadata": metadata or {},
        }

        logger.info(
            "alert_notification: dispatching [%s] severity=%s value=%.4f",
            alert_type, severity, value,
        )

        loop = asyncio.get_event_loop()

        tasks = []
        if self._email_to:
            tasks.append(
                loop.run_in_executor(None, self._send_email, payload)
            )
        if self._slack_webhook:
            tasks.append(
                loop.run_in_executor(None, self._send_slack, payload)
            )

        # Fire both in parallel; swallow all errors
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for result in results:
            if isinstance(result, Exception):
                logger.warning("alert_notification: dispatch error: %s", result)

    # ── Internal (blocking — run in executor) ─────────────────────────────────

    def _send_email(self, payload: Dict[str, Any]) -> None:
        """Send a plain-text alert email via SMTP."""
        subject = (
            f"[AnchorFlow Alert] {payload['severity'].upper()}: "
            f"{payload['alert_type']}"
        )
        body = (
            f"Alert: {payload['alert_type']}\n"
            f"Severity: {payload['severity']}\n"
            f"Value: {payload['value']}\n"
            f"Threshold: {payload['threshold']}\n"
            f"Reason: {payload['reason']}\n"
        )
        if payload.get("metadata"):
            body += f"\nMetadata:\n{json.dumps(payload['metadata'], indent=2)}\n"

        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = self._smtp_from
        msg["To"] = ", ".join(self._email_to)
        msg.set_content(body)

        try:
            with smtplib.SMTP(self._smtp_host, self._smtp_port, timeout=10) as smtp:
                if self._smtp_user and self._smtp_password:
                    smtp.starttls()
                    smtp.login(self._smtp_user, self._smtp_password)
                smtp.send_message(msg)
            logger.info(
                "alert_notification: email sent to %s for [%s]",
                self._email_to, payload["alert_type"],
            )
        except Exception as exc:
            logger.warning(
                "alert_notification: email failed for [%s]: %s",
                payload["alert_type"], exc,
            )
            raise

    def _send_slack(self, payload: Dict[str, Any]) -> None:
        """Post an alert message to a Slack Incoming Webhook."""
        severity_emoji = {
            "critical": ":red_circle:",
            "warning":  ":large_yellow_circle:",
            "ok":       ":large_green_circle:",
        }.get(payload["severity"], ":white_circle:")

        text = (
            f"{severity_emoji} *AnchorFlow Alert* — "
            f"`{payload['alert_type']}` *{payload['severity'].upper()}*\n"
            f"> {payload['reason']}\n"
            f"> Value: `{payload['value']}` / Threshold: `{payload['threshold']}`"
        )

        data = json.dumps({"text": text}).encode("utf-8")
        req = urllib_request.Request(
            self._slack_webhook,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib_request.urlopen(req, timeout=10) as resp:
                if resp.status not in (200, 204):
                    raise RuntimeError(f"Slack webhook returned HTTP {resp.status}")
            logger.info(
                "alert_notification: Slack message sent for [%s]",
                payload["alert_type"],
            )
        except Exception as exc:
            logger.warning(
                "alert_notification: Slack dispatch failed for [%s]: %s",
                payload["alert_type"], exc,
            )
            raise
