# app/core/idempotency.py
"""
Central TTL registry and idempotency event logging for AnchorFlow.

All Redis key TTLs live here so they are never hardcoded in handlers.
The idempotency event stream provides a durable audit trail of
deduplication decisions without impacting the hot path.

Usage::

    from app.core.idempotency import TTL_PAYMENT_LOCK, log_idempotency_event

    already_processed = bool(_redis.setnx(f"payment_processed:{ref}", "1"))
    _redis.expire(f"payment_processed:{ref}", TTL_PAYMENT_LOCK)
    log_idempotency_event(_redis, "payment_dedup", f"payment_processed:{ref}",
                          {"ref": ref, "status": "duplicate"})
"""

import logging
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ─── TTL REGISTRY (seconds) ───────────────────────────────────────────────────

# Session / state keys
TTL_ACTIVE_SESSION  = 86_400   # 24 h  — state key while a deal is in flight
TTL_IDLE_SESSION    = 7_200    # 2 h   — state key for idle users
TTL_STATE_LOCK      = 5        # 5 s   — bot:state_lock:{phone}

# Message / webhook dedup
TTL_DEDUP_MESSAGE   = 300      # 5 min — MessageSid dedup key
TTL_PAYMENT_LOCK    = 86_400   # 24 h  — payment_processed:{ref}

# Deal lifecycle
TTL_DEAL_DEDUP      = 180      # 3 min — deal idempotency NX key
TTL_ACTIVE_DEAL     = 86_400   # 24 h  — bot:active_deal:{phone} (recovery)
TTL_LEDGER          = 86_400   # 24 h  — ledger:payment:{ref}

# Courier job
TTL_COURIER_JOB_MAX = 1_800    # 30 min — max lifetime for a courier job key

# Catalogue cache
TTL_CATALOGUE       = 86_400   # 24 h  — merchant_catalogue:{slug}

# Circuit-breaker degraded-mode flag
TTL_DEGRADED_MODE   = 60       # 60 s  — bot:degraded_mode

# Metrics stream caps (item count, not TTL)
STREAM_MAXLEN_IDEMPOTENCY = 10_000
STREAM_MAXLEN_METRICS     = 50_000


# ─── IDEMPOTENCY EVENT STREAM ─────────────────────────────────────────────────

_IDEMPOTENCY_STREAM = "idempotency:events"


def log_idempotency_event(
    rdb: Any,
    event_type: str,
    key: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Append a structured entry to the Redis idempotency audit stream.

    Args:
        rdb:        Redis (or SafeRedis) client.
        event_type: Short string identifying the decision (e.g. "payment_dedup").
        key:        The Redis key involved in the idempotency check.
        metadata:   Optional dict of scalar values — must be JSON-serialisable.

    This function NEVER raises — errors are swallowed with a warning.
    All metadata values are coerced to strings for XADD compatibility.
    """
    try:
        fields: Dict[str, str] = {
            "event_type": event_type,
            "key":        key,
            "ts":         str(int(time.time() * 1000)),
        }
        if metadata:
            for k, v in metadata.items():
                fields[str(k)] = str(v)

        rdb.xadd(
            _IDEMPOTENCY_STREAM,
            fields,
            maxlen=STREAM_MAXLEN_IDEMPOTENCY,
            approximate=True,
        )
    except Exception as exc:
        logger.warning("log_idempotency_event failed [%s/%s]: %s", event_type, key, exc)
