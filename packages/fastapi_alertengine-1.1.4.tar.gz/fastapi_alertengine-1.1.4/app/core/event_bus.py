# app/core/event_bus.py
"""
AnchorFlow — Lightweight In-Memory Event Bus

Purpose
───────
Decouple system events (payment confirmed, deal stuck, courier assigned)
from their side effects (notifications, metrics, audit logs) without
modifying the core engine.

Design
──────
- Module-level singleton _BUS: a dict mapping event_name → [handler_fn]
- emit_event() calls handlers in the same thread (safe inside BackgroundTasks)
- emit_background() wraps emit_event in a FastAPI BackgroundTask (zero-latency)
- Handlers may be sync or async; async handlers are run via asyncio.run() if
  called from a non-async context, otherwise awaited directly
- Never raises — all handler exceptions are caught and logged
- Thread-safe for read-heavy workloads (registration happens at startup)

Usage
─────
    # At module startup (e.g. main.py or a setup function):
    from app.core.event_bus import register_handler, emit_background
    from app.merchant_portal.notifications import notify_merchant_event

    register_handler("delivery_delayed", notify_merchant_event)
    register_handler("payment_confirmed", notify_merchant_event)

    # In a BackgroundTask after a state change:
    background_tasks.add_task(emit_event, "delivery_delayed", {
        "deal_id": "7G4K9",
        "merchant_phone": "0771234567",
        "duration_sec": 7440,
    })

    # Or fire without BackgroundTasks context:
    emit_event("courier_stalled", {"deal_id": "...", ...})
"""

import asyncio
import inspect
import logging
from collections import defaultdict
from typing import Any, Callable, Dict, List

logger = logging.getLogger(__name__)

# ── Singleton registry ────────────────────────────────────────────────────────
# Maps event_name → ordered list of handler callables.
# Registration is append-only; handlers execute in registration order.

_BUS: Dict[str, List[Callable]] = defaultdict(list)


# ── Registration ──────────────────────────────────────────────────────────────

def register_handler(event_name: str, handler_fn: Callable) -> None:
    """
    Register a handler for an event.

    handler_fn signature must accept (event_name: str, payload: dict).
    Async handlers are supported and run inside emit_event.

    Safe to call multiple times with the same arguments — duplicate handlers
    are silently ignored to prevent double-firing on module reloads.
    """
    existing = _BUS[event_name]
    if handler_fn not in existing:
        existing.append(handler_fn)
        logger.debug(
            "event_bus: registered %s for %r (total=%d)",
            getattr(handler_fn, "__name__", repr(handler_fn)),
            event_name,
            len(existing),
        )


def unregister_handler(event_name: str, handler_fn: Callable) -> bool:
    """Remove a handler.  Returns True if it was found and removed."""
    handlers = _BUS.get(event_name, [])
    if handler_fn in handlers:
        handlers.remove(handler_fn)
        return True
    return False


def registered_events() -> List[str]:
    """Return list of event names that have at least one handler."""
    return [name for name, handlers in _BUS.items() if handlers]


# ── Emission ──────────────────────────────────────────────────────────────────

def emit_event(event_name: str, payload: Dict[str, Any]) -> int:
    """
    Emit an event synchronously, calling all registered handlers in order.

    Safe to call from any context:
    - Inside a BackgroundTask thread (most common)
    - From a sync function
    - From an async function (handlers run via asyncio.run() if needed)

    Returns the number of handlers that completed without error.
    Never raises.
    """
    handlers = _BUS.get(event_name, [])
    if not handlers:
        logger.debug("event_bus: no handlers for %r", event_name)
        return 0

    logger.debug(
        "event_bus: emitting %r to %d handler(s) | payload_keys=%s",
        event_name, len(handlers), list(payload.keys()),
    )

    success_count = 0
    for handler in handlers:
        try:
            if inspect.iscoroutinefunction(handler):
                # Run async handler — try to use the running loop, else spin new one
                try:
                    loop = asyncio.get_running_loop()
                    # We're in an async context; schedule as a task (fire-and-forget)
                    loop.create_task(_safe_async_call(handler, event_name, payload))
                except RuntimeError:
                    # No running loop — spin one (BackgroundTask thread context)
                    asyncio.run(_safe_async_call(handler, event_name, payload))
            else:
                handler(event_name, payload)
            success_count += 1
        except Exception as exc:
            logger.error(
                "event_bus: handler %s raised for event %r: %s",
                getattr(handler, "__name__", repr(handler)),
                event_name,
                exc,
            )
    return success_count


async def _safe_async_call(handler: Callable, event_name: str, payload: dict) -> None:
    """Await an async handler; swallows exceptions."""
    try:
        await handler(event_name, payload)
    except Exception as exc:
        logger.error(
            "event_bus: async handler %s raised for %r: %s",
            getattr(handler, "__name__", repr(handler)), event_name, exc,
        )


def emit_background(
    background_tasks,   # FastAPI BackgroundTasks instance
    event_name: str,
    payload: Dict[str, Any],
) -> None:
    """
    Schedule an event emission as a FastAPI BackgroundTask.

    Call this inside a route handler to fire events without adding
    any latency to the HTTP response:

        emit_background(background_tasks, "payment_confirmed", {"deal_id": "7G4K9"})
    """
    background_tasks.add_task(emit_event, event_name, payload)


# ── Built-in no-op handler (useful for testing) ───────────────────────────────

def _log_handler(event_name: str, payload: Dict[str, Any]) -> None:
    """Debug handler: logs every event it receives."""
    logger.info("event_bus [log_handler]: %s payload=%s", event_name, payload)
