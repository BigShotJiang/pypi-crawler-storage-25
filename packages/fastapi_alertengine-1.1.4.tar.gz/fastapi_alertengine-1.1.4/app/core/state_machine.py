"""
app/core/state_machine.py

Centralised BotState enum for the Tofamba WhatsApp bot.

V2  — KYC-Lite, Brand Layer, Inventory with Variants
V2.1 Hardening — State recovery, AI vision fallback, Buyer Flow V1
"""

from enum import Enum


class BotState(str, Enum):
    # ── Entry / navigation ───────────────────────────────────────────────────
    INITIAL          = "initial"
    IDLE             = "idle"

    # ── Session recovery (30-min inactivity guard) ────────────────────────────
    RESUME_CONFIRM   = "resume_confirm"

    # ── Legacy merchant onboarding (V1 — kept for in-progress users) ─────────
    MERCHANT_NAME    = "merchant_name"
    MERCHANT_WALLET  = "merchant_wallet"

    # ── Courier signup ────────────────────────────────────────────────────────
    COURIER_NAME     = "courier_name"
    COURIER_VEHICLE  = "courier_vehicle"
    COURIER_WALLET   = "courier_wallet"

    # ── Delivery PIN entry ────────────────────────────────────────────────────
    PIN_ENTRY        = "pin_entry"

    # ── Phase 1: KYC-Lite (/onboard_merchant) ────────────────────────────────
    KYC_NAME            = "kyc_name"
    KYC_ID_PHOTO        = "kyc_id_photo"
    KYC_SELFIE          = "kyc_selfie"
    KYC_ID_TYPE         = "kyc_id_type"
    KYC_ID_NUMBER       = "kyc_id_number"
    KYC_PASSPORT_NUMBER = "kyc_passport_number"

    # ── Phase 2: Brand Layer ──────────────────────────────────────────────────
    BRAND_NAME             = "brand_name"
    BRAND_WALLET_SELECT    = "brand_wallet_select"
    BRAND_WALLET_NUMBER    = "brand_wallet_number"
    BRAND_WALLET_CONFIRM   = "brand_wallet_confirm"

    # ── Phase 3: Inventory with Image & Variants (/add_product) ──────────────
    INVENTORY_PHOTO           = "inventory_photo"
    INVENTORY_CONFIRM_DETAILS = "inventory_confirm_details"
    INVENTORY_PRICE           = "inventory_price"
    INVENTORY_HAS_VARIANTS    = "inventory_has_variants"
    INVENTORY_VARIANT_LABEL   = "inventory_variant_label"
    INVENTORY_VARIANT_QTY     = "inventory_variant_qty"
    INVENTORY_TOTAL_QTY       = "inventory_total_qty"

    # ── Phase 3 fallback: manual product detail entry (AI vision failure) ─────
    INVENTORY_NAME_MANUAL        = "inventory_name_manual"
    INVENTORY_DESCRIPTION_MANUAL = "inventory_description_manual"

    # ── Buyer Flow V1 ─────────────────────────────────────────────────────────
    BROWSE_STORE        = "browse_store"
    VIEW_PRODUCT        = "view_product"
    SELECT_VARIANT      = "select_variant"
    CONFIRM_ORDER       = "confirm_order"
    PAYMENT_INSTRUCTION = "payment_instruction"

    # ── Dispute Resolution Flow (/dispute DEAL_ID) ────────────────────────────
    # RBZ compliance — user is asked to provide a reason after /dispute command.
    DISPUTE_REASON      = "dispute_reason"


# Terminal / resting states — inactivity guard is NOT applied here
RESTING_STATES = frozenset({
    BotState.INITIAL,
    BotState.IDLE,
    BotState.RESUME_CONFIRM,
    BotState.PAYMENT_INSTRUCTION,
})
