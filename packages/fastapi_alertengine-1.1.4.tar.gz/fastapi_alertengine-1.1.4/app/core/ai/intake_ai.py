import json
import os
from typing import Dict, Any

import anthropic


class IntakeAI:
    """
    AI extraction layer for onboarding + product ingestion
    """

    client = anthropic.Anthropic(
        api_key=os.getenv("ANTHROPIC_API_KEY")
    )

    @staticmethod
    def parse_onboarding(message: str) -> Dict[str, Any]:
        system_prompt = """
Extract merchant onboarding info from the message.

Return JSON only:
{"merchant_name": null, "location": null, "wallet": null, "role": null}

Rules:
- Fill ONLY explicitly stated fields
- Do NOT guess
- Return valid JSON only
"""

        try:
            # TEXT MODEL — Haiku sufficient, do NOT use Sonnet (cost)
            response = IntakeAI.client.messages.create(
                model="claude-3-haiku-20240307",
                temperature=0,
                max_tokens=200,
                system=system_prompt,
                messages=[{"role": "user", "content": message}]
            )

            text = response.content[0].text
            return json.loads(text)

        except Exception as e:
            print(f"[IntakeAI onboarding error] {e}")
            return {
                "merchant_name": None,
                "location": None,
                "wallet": None,
                "role": None
            }

    @staticmethod
    def parse_product(message: str) -> Dict[str, Any]:
        system_prompt = """
Extract product details.

Return JSON only:
{"name": null, "sku": null, "qty": null, "color": null, "size": null, "price": null}

Rules:
- Do NOT guess
- qty must be integer
- price must be numeric
- Return valid JSON only
"""

        try:
            # TEXT MODEL — Haiku sufficient, do NOT use Sonnet (cost)
            response = IntakeAI.client.messages.create(
                model="claude-3-haiku-20240307",
                temperature=0,
                max_tokens=250,
                system=system_prompt,
                messages=[{"role": "user", "content": message}]
            )

            text = response.content[0].text
            return json.loads(text)

        except Exception as e:
            print(f"[IntakeAI product error] {e}")
            return {
                "name": None,
                "sku": None,
                "qty": None,
                "color": None,
                "size": None,
                "price": None
            }
