import os
import json
import base64
import httpx
import anthropic


class VisionAI:

    client = anthropic.Anthropic(
        api_key=os.getenv("ANTHROPIC_API_KEY")
    )

    @staticmethod
    async def parse_product_image(image_url: str) -> dict:
        try:
            # Download image
            async with httpx.AsyncClient() as client:
                response = await client.get(image_url)
                image_bytes = response.content

            image_base64 = base64.b64encode(image_bytes).decode()

            # VISION MODEL — do NOT change to Haiku (no image support)
            response = VisionAI.client.messages.create(
                model="claude-sonnet-4-5",
                max_tokens=300,
                temperature=0,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": "image/jpeg",
                                    "data": image_base64
                                }
                            },
                            {
                                "type": "text",
                                "text": """
Identify the product in this image.

Return JSON only:
{"name": null, "description": null, "category": null}

Do not guess. Be concise.
"""
                            }
                        ]
                    }
                ]
            )

            text = response.content[0].text
            return json.loads(text)

        except Exception as e:
            print(f"[VisionAI error] {e}")
            return {"name": None, "description": None, "category": None}
