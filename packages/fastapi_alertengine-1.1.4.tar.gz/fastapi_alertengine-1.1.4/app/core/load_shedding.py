# app/core/load_shedding.py
"""
Load-shedding utilities for AnchorFlow under high traffic or Redis degradation.

Degraded mode is a Redis flag (`bot:degraded_mode`) that, when set, causes:
  - Claude AI calls to be skipped (keyword-only responses)
  - Non-critical background operations to be deferred
  - The degraded state to be surfaced in the /health endpoint

Degraded mode is triggered by:
  1. Explicit call to `set_degraded_mode(_redis, True, reason="...")`
  2. Auto-detection: Redis round-trip > 150 ms, OR payment queue > 1 000 items

The flag expires automatically after TTL_DEGRADED_MODE seconds (60s default)
so the system recovers without manual intervention if conditions improve.

Usage::

    from app.core.load_shedding import is_degraded, should_skip_claude

    if should_skip_claude(_redis):
        return keyword_response(message)
    else:
        return await _call_claude(message, ...)
"""

import logging
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ─── CONSTANTS ────────────────────────────────────────────────────────────────

DEGRADED_MODE_KEY    = "bot:degraded_mode"
PAYMENT_QUEUE_KEY    = "bot:payment_queue_len"   # maintained by payment_webhook
_LATENCY_THRESHOLD_MS   = 150   # ms — Redis round-trip above this → degraded
_QUEUE_THRESHOLD        = 1_000  # items in payment queue → degraded
_DEGRADED_MODE_TTL      = 60    # seconds — flag auto-expires


# ─── HELPERS ──────────────────────────────────────────────────────────────────

def _measure_redis_latency_ms(rdb: Any) -> float:
    """Ping Redis and return round-trip time in milliseconds."""
    try:
        t0 = time.perf_counter()
        rdb.execute_command("PING")
        return (time.perf_counter() - t0) * 1000.0
    except Exception:
        return float("inf")


def _payment_queue_length(rdb: Any) -> int:
    """Return current payment queue depth (0 if key missing)."""
    try:
        raw = rdb.get(PAYMENT_QUEUE_KEY)
        if raw is None:
            return 0
        return int(raw)
    except Exception:
        return 0


# ─── PUBLIC API ───────────────────────────────────────────────────────────────

def is_degraded(rdb: Any, *, auto_detect: bool = True) -> bool:
    """
    Return True if the system is in degraded mode.

    Checks (in order):
      1. Explicit degraded-mode flag in Redis.
      2. If auto_detect=True: Redis latency > 150 ms.
      3. If auto_detect=True: payment queue > 1 000 items.

    This function NEVER raises — returns False on any error.
    """
    try:
        raw = rdb.get(DEGRADED_MODE_KEY)
        if raw is not None:
            return True
    except Exception as exc:
        logger.warning("is_degraded: flag check failed: %s", exc)
        # If we can't read Redis at all, treat as degraded
        return True

    if not auto_detect:
        return False

    latency = _measure_redis_latency_ms(rdb)
    if latency > _LATENCY_THRESHOLD_MS:
        logger.warning(
            "is_degraded: Redis latency %.1f ms > threshold %d ms — degraded",
            latency, _LATENCY_THRESHOLD_MS,
        )
        # Auto-set the flag so subsequent requests don't all probe Redis
        set_degraded_mode(rdb, True, reason=f"high_latency:{latency:.0f}ms")
        return True

    queue_len = _payment_queue_length(rdb)
    if queue_len > _QUEUE_THRESHOLD:
        logger.warning(
            "is_degraded: payment queue %d > threshold %d — degraded",
            queue_len, _QUEUE_THRESHOLD,
        )
        set_degraded_mode(rdb, True, reason=f"payment_queue:{queue_len}")
        return True

    return False


def should_skip_claude(rdb: Any) -> bool:
    """
    Return True if Claude AI calls should be skipped.

    Currently equivalent to is_degraded() with auto_detect disabled
    (we don't want to trigger a latency probe on every message).
    """
    try:
        raw = rdb.get(DEGRADED_MODE_KEY)
        return raw is not None
    except Exception:
        return True   # Redis unreachable → skip Claude to conserve resources


def set_degraded_mode(rdb: Any, enabled: bool, reason: str = "") -> None:
    """
    Explicitly set or clear degraded mode.

    When enabled=True, the flag is set with a 60-second auto-expiry.
    When enabled=False, the flag is deleted immediately.

    This function NEVER raises.
    """
    try:
        if enabled:
            rdb.setex(DEGRADED_MODE_KEY, _DEGRADED_MODE_TTL, reason or "manual")
            logger.warning("Degraded mode ENABLED: %s", reason or "manual")
        else:
            rdb.delete(DEGRADED_MODE_KEY)
            logger.info("Degraded mode CLEARED")
    except Exception as exc:
        logger.error("set_degraded_mode failed: %s", exc)


def degraded_status(rdb: Any) -> dict:
    """
    Return a dict suitable for inclusion in /health responses.

    Returns:
        {
            "degraded": bool,
            "reason":   str or None,
            "redis_latency_ms": float,
        }
    """
    try:
        raw = rdb.get(DEGRADED_MODE_KEY)
        reason = raw.decode() if isinstance(raw, bytes) else (raw or None)
    except Exception:
        reason = "redis_unreachable"

    latency = _measure_redis_latency_ms(rdb)
    return {
        "degraded":         reason is not None,
        "reason":           reason,
        "redis_latency_ms": round(latency, 2),
    }
