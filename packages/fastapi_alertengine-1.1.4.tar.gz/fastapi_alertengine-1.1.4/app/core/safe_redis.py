# app/core/safe_redis.py
"""
SafeRedis — drop-in redis.Redis wrapper with resilience primitives.

Features:
- Automatic retry: up to 3 attempts with 50/100/200 ms exponential backoff.
- Per-call timeout: 1 second hard limit via socket_timeout (set at connect time).
- Circuit breaker: after 5 failures in a 30-second window, all calls are
  redirected to _EphemeralStore (an in-memory dict with TTL).  Circuit resets
  automatically after 30 seconds of no new failures.

Design:
- SafeRedis subclasses redis.Redis so isinstance() checks still pass.
- _EphemeralStore implements only the subset used by whatsapp_bot.py:
  get/set/setex/getset/delete/exists/expire/setnx/incr/lpush/lrange/ltrim/
  hset/hget/hgetall/zadd/zrangebyscore/zrem/xadd/xlen — all others are no-ops.
- Thread-safe failure counter uses threading.Lock.
- Circuit state is NOT stored in Redis (that would be circular).

Usage::

    from app.core.safe_redis import build_safe_redis

    _redis = build_safe_redis(url="redis://localhost:6379/0")
"""

import logging
import threading
import time
import zlib
from typing import Any, Dict, List, Optional, Tuple

import redis

logger = logging.getLogger(__name__)

# ─── CIRCUIT BREAKER CONSTANTS ────────────────────────────────────────────────
_FAILURE_THRESHOLD = 5      # failures before opening circuit
_FAILURE_WINDOW    = 30.0   # rolling window (seconds)
_RESET_AFTER       = 30.0   # seconds to wait before half-opening circuit
_RETRY_ATTEMPTS    = 3
_BACKOFF_MS        = [50, 100, 200]   # ms between retries


# ─── IN-MEMORY FALLBACK ───────────────────────────────────────────────────────

class _EphemeralStore:
    """
    Minimal in-memory store used when the circuit is open.

    Keys are plain strings.  TTLs are tracked via a parallel dict.
    Not persisted — data is lost on process restart (acceptable: this
    is a short-lived fallback for a 30-second circuit-open window).
    """

    def __init__(self) -> None:
        self._store: Dict[str, Any] = {}
        self._expiry: Dict[str, float] = {}   # key → unix timestamp of expiry
        self._lock = threading.Lock()

    # ── private ────────────────────────────────────────────────────────────────

    def _is_expired(self, key: str) -> bool:
        exp = self._expiry.get(key)
        return exp is not None and time.time() > exp

    def _clean(self, key: str) -> None:
        """Remove key if expired."""
        if self._is_expired(key):
            self._store.pop(key, None)
            self._expiry.pop(key, None)

    # ── Redis-compatible API ───────────────────────────────────────────────────

    def get(self, key: str) -> Optional[bytes]:
        with self._lock:
            self._clean(key)
            v = self._store.get(key)
            if v is None:
                return None
            return v if isinstance(v, bytes) else str(v).encode()

    def set(self, key: str, value: Any, ex: Optional[int] = None,
            px: Optional[int] = None, nx: bool = False, **_kw) -> bool:
        with self._lock:
            if nx and key in self._store and not self._is_expired(key):
                return False
            self._store[key] = value if isinstance(value, bytes) else str(value).encode()
            if ex:
                self._expiry[key] = time.time() + ex
            elif px:
                self._expiry[key] = time.time() + px / 1000.0
            return True

    def setex(self, key: str, ttl: int, value: Any) -> bool:
        return self.set(key, value, ex=ttl)

    def setnx(self, key: str, value: Any) -> bool:
        return self.set(key, value, nx=True)

    def getset(self, key: str, value: Any) -> Optional[bytes]:
        with self._lock:
            old = self.get(key)
            self.set(key, value)
            return old

    def delete(self, *keys: str) -> int:
        with self._lock:
            deleted = 0
            for k in keys:
                if k in self._store:
                    del self._store[k]
                    self._expiry.pop(k, None)
                    deleted += 1
            return deleted

    def exists(self, *keys: str) -> int:
        with self._lock:
            return sum(1 for k in keys if k in self._store and not self._is_expired(k))

    def expire(self, key: str, seconds: int) -> bool:
        with self._lock:
            if key in self._store and not self._is_expired(key):
                self._expiry[key] = time.time() + seconds
                return True
            return False

    def incr(self, key: str, amount: int = 1) -> int:
        with self._lock:
            self._clean(key)
            current = int(self._store.get(key, b"0"))
            new_val = current + amount
            self._store[key] = str(new_val).encode()
            return new_val

    def lpush(self, key: str, *values: Any) -> int:
        with self._lock:
            lst = self._store.get(key, [])
            if not isinstance(lst, list):
                lst = []
            for v in reversed(values):
                lst.insert(0, v if isinstance(v, bytes) else str(v).encode())
            self._store[key] = lst
            return len(lst)

    def lrange(self, key: str, start: int, end: int) -> List[bytes]:
        with self._lock:
            lst = self._store.get(key, [])
            if not isinstance(lst, list):
                return []
            if end == -1:
                return lst[start:]
            return lst[start:end + 1]

    def ltrim(self, key: str, start: int, end: int) -> bool:
        with self._lock:
            lst = self._store.get(key, [])
            if not isinstance(lst, list):
                return True
            if end == -1:
                self._store[key] = lst[start:]
            else:
                self._store[key] = lst[start:end + 1]
            return True

    def hset(self, key: str, field: str = None, value: Any = None,
             mapping: Dict = None, **_kw) -> int:
        with self._lock:
            h = self._store.get(key, {})
            if not isinstance(h, dict):
                h = {}
            if mapping:
                h.update({k: v if isinstance(v, bytes) else str(v).encode()
                           for k, v in mapping.items()})
            elif field is not None:
                h[field] = value if isinstance(value, bytes) else str(value).encode()
            self._store[key] = h
            return 1

    def hget(self, key: str, field: str) -> Optional[bytes]:
        with self._lock:
            h = self._store.get(key, {})
            if not isinstance(h, dict):
                return None
            v = h.get(field)
            if v is None:
                return None
            return v if isinstance(v, bytes) else str(v).encode()

    def hgetall(self, key: str) -> Dict[bytes, bytes]:
        with self._lock:
            h = self._store.get(key, {})
            if not isinstance(h, dict):
                return {}
            return {(k if isinstance(k, bytes) else k.encode()):
                    (v if isinstance(v, bytes) else str(v).encode())
                    for k, v in h.items()}

    def zadd(self, key: str, mapping: Dict[str, float], nx: bool = False,
             **_kw) -> int:
        with self._lock:
            zset = self._store.get(key, {})
            if not isinstance(zset, dict):
                zset = {}
            added = 0
            for member, score in mapping.items():
                if nx and member in zset:
                    continue
                zset[member] = score
                added += 1
            self._store[key] = zset
            return added

    def zrangebyscore(self, key: str, min_score: Any, max_score: Any,
                      withscores: bool = False) -> List:
        with self._lock:
            zset = self._store.get(key, {})
            if not isinstance(zset, dict):
                return []
            lo = float("-inf") if min_score == "-inf" else float(min_score)
            hi = float("inf")  if max_score == "+inf" else float(max_score)
            result = [(m, s) for m, s in zset.items() if lo <= s <= hi]
            result.sort(key=lambda x: x[1])
            if withscores:
                return [(m if isinstance(m, bytes) else m.encode(), s)
                        for m, s in result]
            return [m if isinstance(m, bytes) else m.encode() for m, _ in result]

    def zrem(self, key: str, *members: Any) -> int:
        with self._lock:
            zset = self._store.get(key, {})
            if not isinstance(zset, dict):
                return 0
            removed = 0
            for m in members:
                mk = m.decode() if isinstance(m, bytes) else m
                if mk in zset:
                    del zset[mk]
                    removed += 1
            return removed

    def xadd(self, key: str, fields: Dict, maxlen: int = None,
             approximate: bool = True, **_kw) -> bytes:
        # Ephemeral store: accept the write, return a fake stream ID
        with self._lock:
            stream = self._store.get(key, [])
            if not isinstance(stream, list):
                stream = []
            stream_id = f"{int(time.time() * 1000)}-0".encode()
            stream.append((stream_id, fields))
            if maxlen and len(stream) > maxlen:
                stream = stream[-maxlen:]
            self._store[key] = stream
            return stream_id

    def xlen(self, key: str) -> int:
        with self._lock:
            stream = self._store.get(key, [])
            return len(stream) if isinstance(stream, list) else 0

    def execute_command(self, *args, **kwargs) -> Any:
        # Catch-all for commands not explicitly implemented — safe no-op
        logger.debug("EphemeralStore: unimplemented command %s (no-op)", args[0] if args else "?")
        return None

    def pipeline(self, transaction: bool = True):
        return _EphemeralPipeline(self)

    def scan_iter(self, match: str = "*", count: int = 100):
        """Yield matching keys (simple prefix/glob match on in-memory store)."""
        import fnmatch
        with self._lock:
            keys = list(self._store.keys())
        for k in keys:
            if fnmatch.fnmatch(k, match):
                yield k.encode() if isinstance(k, str) else k


class _EphemeralPipeline:
    """Bare-minimum pipeline shim for the ephemeral fallback store."""

    def __init__(self, store: _EphemeralStore) -> None:
        self._store = store
        self._cmds: List[Tuple] = []

    def setex(self, key, ttl, value):
        self._cmds.append(("setex", key, ttl, value)); return self

    def delete(self, *keys):
        self._cmds.append(("delete", *keys)); return self

    def execute(self):
        results = []
        for cmd in self._cmds:
            op, *args = cmd
            fn = getattr(self._store, op, None)
            results.append(fn(*args) if fn else None)
        self._cmds.clear()
        return results

    def __enter__(self):
        return self

    def __exit__(self, *_):
        pass


# ─── CIRCUIT BREAKER ──────────────────────────────────────────────────────────

class _CircuitBreaker:
    """
    Per-instance circuit breaker.

    States: CLOSED (normal) → OPEN (fallback) → half-open (one probe) → CLOSED.
    """

    def __init__(self, threshold: int = _FAILURE_THRESHOLD,
                 window: float = _FAILURE_WINDOW,
                 reset_after: float = _RESET_AFTER) -> None:
        self._threshold   = threshold
        self._window      = window
        self._reset_after = reset_after
        self._failures: List[float] = []   # timestamps
        self._opened_at: Optional[float] = None
        self._lock = threading.Lock()

    @property
    def is_open(self) -> bool:
        with self._lock:
            if self._opened_at is None:
                return False
            if time.time() - self._opened_at >= self._reset_after:
                # Auto-reset
                self._opened_at = None
                self._failures.clear()
                logger.info("CircuitBreaker: auto-reset after %.0fs", self._reset_after)
                return False
            return True

    def record_failure(self) -> None:
        with self._lock:
            now = time.time()
            self._failures = [t for t in self._failures if now - t < self._window]
            self._failures.append(now)
            if len(self._failures) >= self._threshold and self._opened_at is None:
                self._opened_at = now
                logger.error(
                    "CircuitBreaker: OPEN after %d failures in %.0fs",
                    len(self._failures), self._window,
                )

    def record_success(self) -> None:
        with self._lock:
            self._failures.clear()
            self._opened_at = None


# ─── SAFE REDIS ───────────────────────────────────────────────────────────────

class SafeRedis(redis.Redis):
    """
    redis.Redis subclass with retry, timeout, and circuit-breaker protection.

    Instantiate via `build_safe_redis()` rather than directly.
    """

    def __init__(self, *args, **kwargs) -> None:
        self._circuit    = _CircuitBreaker()
        self._ephemeral  = _EphemeralStore()
        super().__init__(*args, **kwargs)

    # ── internal retry wrapper ─────────────────────────────────────────────────

    def _safe_call(self, method_name: str, *args, **kwargs) -> Any:
        """
        Execute a Redis call with retry + circuit breaker.

        If the circuit is open, all calls go to _EphemeralStore.
        """
        if self._circuit.is_open:
            fn = getattr(self._ephemeral, method_name, self._ephemeral.execute_command)
            return fn(*args, **kwargs)

        last_exc: Optional[Exception] = None
        for attempt, backoff_ms in enumerate(_BACKOFF_MS[:_RETRY_ATTEMPTS], start=1):
            try:
                result = super().__getattribute__(f"_{SafeRedis.__name__}__real_{method_name}")(*args, **kwargs)
                self._circuit.record_success()
                return result
            except (redis.exceptions.ConnectionError,
                    redis.exceptions.TimeoutError,
                    redis.exceptions.BusyLoadingError) as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < _RETRY_ATTEMPTS:
                    time.sleep(backoff_ms / 1000.0)
                    logger.warning(
                        "SafeRedis: %s attempt %d failed (%s) — retrying",
                        method_name, attempt, exc,
                    )

        # All retries exhausted → fallback
        logger.error(
            "SafeRedis: %s failed after %d attempts, using ephemeral fallback: %s",
            method_name, _RETRY_ATTEMPTS, last_exc,
        )
        fn = getattr(self._ephemeral, method_name, self._ephemeral.execute_command)
        return fn(*args, **kwargs)

    # ── Override hot-path methods ──────────────────────────────────────────────
    # We override only the methods actively used by whatsapp_bot.py.
    # Each override calls the parent via super() directly to avoid infinite
    # recursion, using the retry wrapper only for the public interface.

    def _exec(self, method_name: str, *args, **kwargs) -> Any:
        """Delegate to parent redis.Redis with retry+circuit logic."""
        if self._circuit.is_open:
            fn = getattr(self._ephemeral, method_name, None)
            if fn:
                return fn(*args, **kwargs)
            return None

        last_exc: Optional[Exception] = None
        for attempt, backoff_ms in enumerate(_BACKOFF_MS[:_RETRY_ATTEMPTS], start=1):
            try:
                fn = getattr(super(), method_name)
                result = fn(*args, **kwargs)
                self._circuit.record_success()
                return result
            except (redis.exceptions.ConnectionError,
                    redis.exceptions.TimeoutError,
                    redis.exceptions.BusyLoadingError) as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < _RETRY_ATTEMPTS:
                    time.sleep(backoff_ms / 1000.0)
                    logger.warning(
                        "SafeRedis.%s attempt %d failed: %s",
                        method_name, attempt, exc,
                    )
            except Exception as exc:
                # Non-retryable (e.g. WRONGTYPE, NOSCRIPT) — propagate immediately
                raise

        logger.error(
            "SafeRedis.%s exhausted retries, falling back to ephemeral: %s",
            method_name, last_exc,
        )
        fn = getattr(self._ephemeral, method_name, None)
        if fn:
            return fn(*args, **kwargs)
        return None

    # Public method overrides — each one delegates through _exec

    def get(self, name, **kw):               return self._exec("get", name, **kw)
    def set(self, name, value, **kw):         return self._exec("set", name, value, **kw)
    def setex(self, name, time_, value):      return self._exec("setex", name, time_, value)
    def setnx(self, name, value):             return self._exec("setnx", name, value)
    def getset(self, name, value):            return self._exec("getset", name, value)
    def delete(self, *names):                 return self._exec("delete", *names)
    def exists(self, *names):                 return self._exec("exists", *names)
    def expire(self, name, time_):            return self._exec("expire", name, time_)
    def incr(self, name, amount=1):           return self._exec("incr", name, amount)
    def lpush(self, name, *values):           return self._exec("lpush", name, *values)
    def lrange(self, name, start, end):       return self._exec("lrange", name, start, end)
    def ltrim(self, name, start, end):        return self._exec("ltrim", name, start, end)
    def hset(self, name, key=None, value=None, mapping=None, **kw):
        return self._exec("hset", name, key=key, value=value, mapping=mapping, **kw)
    def hget(self, name, key):                return self._exec("hget", name, key)
    def hgetall(self, name):                  return self._exec("hgetall", name)
    def zadd(self, name, mapping, **kw):      return self._exec("zadd", name, mapping, **kw)
    def zrangebyscore(self, name, min, max, **kw):
        return self._exec("zrangebyscore", name, min, max, **kw)
    def zrem(self, name, *values):            return self._exec("zrem", name, *values)
    def xadd(self, name, fields, **kw):       return self._exec("xadd", name, fields, **kw)
    def xlen(self, name):                     return self._exec("xlen", name)

    def scan_iter(self, match="*", count=100, **kw):
        """scan_iter with circuit-breaker: falls back to ephemeral store scan."""
        if self._circuit.is_open:
            yield from self._ephemeral.scan_iter(match=match, count=count)
            return
        try:
            yield from super().scan_iter(match=match, count=count, **kw)
            self._circuit.record_success()
        except (redis.exceptions.ConnectionError,
                redis.exceptions.TimeoutError) as exc:
            self._circuit.record_failure()
            logger.error("SafeRedis.scan_iter failed: %s — falling back", exc)
            yield from self._ephemeral.scan_iter(match=match, count=count)

    def execute_command(self, *args, **kwargs) -> Any:
        """Catch-all for commands not individually overridden."""
        return self._exec("execute_command", *args, **kwargs)

    # ── Circuit breaker status ─────────────────────────────────────────────────

    @property
    def circuit_open(self) -> bool:
        return self._circuit.is_open

    def circuit_status(self) -> dict:
        return {
            "open": self._circuit.is_open,
            "failures": len(self._circuit._failures),
            "threshold": self._circuit._threshold,
        }


# ─── FACTORY ──────────────────────────────────────────────────────────────────

def build_safe_redis(url: str, socket_timeout: float = 1.0,
                     socket_connect_timeout: float = 2.0,
                     decode_responses: bool = False) -> SafeRedis:
    """
    Build a SafeRedis instance from a redis:// URL.

    Args:
        url:                    Redis connection URL.
        socket_timeout:         Per-command timeout in seconds (default 1s).
        socket_connect_timeout: Connection timeout in seconds (default 2s).
        decode_responses:       If True, return str instead of bytes.

    Returns:
        SafeRedis instance ready to use as a drop-in for redis.Redis.
    """
    pool = redis.ConnectionPool.from_url(
        url,
        socket_timeout=socket_timeout,
        socket_connect_timeout=socket_connect_timeout,
        decode_responses=decode_responses,
    )
    instance = SafeRedis(connection_pool=pool)
    logger.info("SafeRedis initialised (timeout=%.1fs, circuit_threshold=%d)",
                socket_timeout, _FAILURE_THRESHOLD)
    return instance
