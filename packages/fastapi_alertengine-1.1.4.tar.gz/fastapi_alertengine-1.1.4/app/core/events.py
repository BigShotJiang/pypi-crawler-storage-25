# app/core/events.py
"""
Lightweight internal event system for AnchorFlow.

Events are plain dataclasses. Dispatching currently writes a structured log
entry; the dispatcher is designed to be extended to an external bus (Redis
Streams, Kafka, webhook) without callers changing.

Usage::

    from app.core.events import dispatch_event, OrderCreatedEvent

    dispatch_event(OrderCreatedEvent(
        phone=pii.mask_user_id(phone),
        merchant_id=merchant_slug,
        state="deal_created",
        metadata={"deal_id": "TDM-7G4K9", "price": 12.50},
    ))

Design rules:
- dispatch_event() NEVER raises. Errors are swallowed with error logging.
- Callers pass already-masked phone values.
- All metadata is a plain dict — no nested objects that can't be JSON-serialised.
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


# ─── BASE ──────────────────────────────────────────────────────────────────────

@dataclass
class BotEvent:
    """Base class for all AnchorFlow bot events."""

    event_type: str
    phone: str                          # Must be PII-masked before passing in
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    merchant_id: Optional[str] = None   # merchant_slug or merchant_phone
    state: Optional[str] = None         # BotState string value at event time
    metadata: Dict[str, Any] = field(default_factory=dict)


# ─── TYPED EVENTS ─────────────────────────────────────────────────────────────
# Each subclass fixes event_type so callers never type magic strings.

@dataclass
class OrderCreatedEvent(BotEvent):
    event_type: str = field(default="order_created", init=False)

@dataclass
class PaymentConfirmedEvent(BotEvent):
    event_type: str = field(default="payment_confirmed", init=False)

@dataclass
class PaymentMismatchEvent(BotEvent):
    event_type: str = field(default="payment_mismatch", init=False)

@dataclass
class DuplicatePaymentEvent(BotEvent):
    event_type: str = field(default="duplicate_payment_webhook", init=False)

@dataclass
class CourierAssignedEvent(BotEvent):
    event_type: str = field(default="courier_assigned", init=False)

@dataclass
class CourierTimedOutEvent(BotEvent):
    event_type: str = field(default="courier_timeout", init=False)

@dataclass
class CourierDeclinedEvent(BotEvent):
    event_type: str = field(default="courier_declined", init=False)

@dataclass
class MerchantOnboardedEvent(BotEvent):
    event_type: str = field(default="merchant_onboarded", init=False)

@dataclass
class DealAbandonedEvent(BotEvent):
    event_type: str = field(default="order_abandoned", init=False)

@dataclass
class ProductAddedEvent(BotEvent):
    event_type: str = field(default="product_added", init=False)

@dataclass
class InvalidTransitionEvent(BotEvent):
    event_type: str = field(default="invalid_state_transition", init=False)

@dataclass
class DealCreatedEvent(BotEvent):
    event_type: str = field(default="deal_created", init=False)

@dataclass
class MerchantContextMissingEvent(BotEvent):
    event_type: str = field(default="missing_merchant_context", init=False)


# ─── DISPATCHER ───────────────────────────────────────────────────────────────

def dispatch_event(event: BotEvent) -> None:
    """
    Dispatch an event to the logging backend.

    Currently emits a single structured log entry.  To route to an external
    bus, add the publish call here — event callers do not need to change.

    This function NEVER raises: any internal error is caught and logged.
    """
    try:
        logger.info({
            "event":       event.event_type,
            "phone":       event.phone,
            "merchant_id": event.merchant_id,
            "state":       event.state,
            "timestamp":   event.timestamp,
            "metadata":    event.metadata,
        })
    except Exception as exc:
        # Last-resort: if even logging fails, write a plain string
        try:
            logger.error(f"Event dispatch failed [{event.event_type}]: {exc}")
        except Exception:
            pass
