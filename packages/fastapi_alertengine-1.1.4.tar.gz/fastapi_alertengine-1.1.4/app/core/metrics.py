# app/core/metrics.py
"""
Structured metrics collection for AnchorFlow via Redis Streams.

All metrics are written to a Redis Stream (``metrics:events``, MAXLEN 50 000).
Consumers (dashboards, alerting) read from the stream; this module only writes.

Provided helpers:
  record_webhook_latency(rdb, latency_ms)
  record_payment_processing_time(rdb, ref, duration_ms)
  record_courier_acceptance_time(rdb, deal_id, courier_phone, duration_ms)
  record_redis_failure(rdb, operation, error_msg)
  record_state_transition_failure(rdb, phone, from_state, to_state)
  aggregate_metrics(rdb, last_n=1000) → dict   — for the /metrics endpoint

Design:
  - All record_* functions NEVER raise — errors are swallowed with a warning.
  - Metric fields are coerced to strings (Redis Stream field requirement).
  - aggregate_metrics reads the last N entries and returns summary counts/avgs.

Usage::

    from app.core.metrics import record_webhook_latency

    t0 = time.perf_counter()
    await _bot.handle_message(...)
    record_webhook_latency(_redis, (time.perf_counter() - t0) * 1000)
"""

import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

METRICS_STREAM = "metrics:events"
_STREAM_MAXLEN = 50_000


# ─── INTERNAL HELPER ──────────────────────────────────────────────────────────

def _xadd(rdb: Any, metric_type: str, fields: Dict[str, str]) -> None:
    """Append one entry to the metrics stream. Never raises."""
    try:
        payload = {
            "type": metric_type,
            "ts":   str(int(time.time() * 1000)),
            **{k: str(v) for k, v in fields.items()},
        }
        rdb.xadd(METRICS_STREAM, payload, maxlen=_STREAM_MAXLEN, approximate=True)
    except Exception as exc:
        logger.warning("metrics._xadd [%s] failed: %s", metric_type, exc)


# ─── RECORD FUNCTIONS ─────────────────────────────────────────────────────────

def record_webhook_latency(rdb: Any, latency_ms: float) -> None:
    """Record end-to-end WhatsApp webhook processing latency."""
    _xadd(rdb, "webhook_latency", {"latency_ms": f"{latency_ms:.2f}"})


def record_payment_processing_time(rdb: Any, ref: str, duration_ms: float) -> None:
    """Record time taken to process a Paynow payment webhook."""
    _xadd(rdb, "payment_processing_time", {
        "ref":         ref,
        "duration_ms": f"{duration_ms:.2f}",
    })


def record_courier_acceptance_time(
    rdb: Any,
    deal_id: str,
    courier_phone: str,
    duration_ms: float,
) -> None:
    """Record time from broadcast to first courier acceptance."""
    _xadd(rdb, "courier_acceptance_time", {
        "deal_id":      deal_id,
        "courier_phone": courier_phone,
        "duration_ms":  f"{duration_ms:.2f}",
    })


def record_redis_failure(rdb: Any, operation: str, error_msg: str) -> None:
    """
    Record a Redis operation failure.

    Note: rdb here may be the SafeRedis instance falling back to its ephemeral
    store, so this write might not reach the stream — that is acceptable.
    """
    _xadd(rdb, "redis_failure", {
        "operation": operation,
        "error":     error_msg[:200],   # cap length
    })


def record_state_transition_failure(
    rdb: Any,
    phone: str,
    from_state: str,
    to_state: str,
) -> None:
    """Record an invalid state transition attempt."""
    _xadd(rdb, "state_transition_failure", {
        "from_state": from_state,
        "to_state":   to_state,
        # phone is already PII-masked at call sites
        "phone_hash": str(hash(phone) % 100_000),
    })


# ─── AGGREGATION ──────────────────────────────────────────────────────────────

def aggregate_metrics(rdb: Any, last_n: int = 1_000) -> Dict[str, Any]:
    """
    Read the last *last_n* entries from the metrics stream and return
    summary statistics suitable for the /metrics endpoint.

    Returns:
        {
            "webhook_latency":            {"count": int, "avg_ms": float, "p95_ms": float},
            "payment_processing_time":    {"count": int, "avg_ms": float},
            "courier_acceptance_time":    {"count": int, "avg_ms": float},
            "redis_failures":             {"count": int, "recent": [str, ...]},
            "state_transition_failures":  {"count": int},
            "stream_length":              int,
        }

    NEVER raises — returns empty dicts on error.
    """
    result: Dict[str, Any] = {
        "webhook_latency":           {"count": 0, "avg_ms": 0.0, "p95_ms": 0.0},
        "payment_processing_time":   {"count": 0, "avg_ms": 0.0},
        "courier_acceptance_time":   {"count": 0, "avg_ms": 0.0},
        "redis_failures":            {"count": 0, "recent": []},
        "state_transition_failures": {"count": 0},
        "stream_length":             0,
    }

    try:
        result["stream_length"] = rdb.xlen(METRICS_STREAM)

        # Read last N entries using XREVRANGE
        raw: List = rdb.execute_command(
            "XREVRANGE", METRICS_STREAM, "+", "-", "COUNT", str(last_n)
        ) or []

        webhook_latencies:  List[float] = []
        payment_times:      List[float] = []
        courier_times:      List[float] = []
        redis_errors:       List[str]   = []
        state_failures:     int         = 0

        for _stream_id, fields in raw:
            # fields is bytes dict from redis-py
            mtype = fields.get(b"type", b"").decode(errors="ignore")
            if mtype == "webhook_latency":
                try:
                    webhook_latencies.append(float(fields.get(b"latency_ms", 0)))
                except ValueError:
                    pass
            elif mtype == "payment_processing_time":
                try:
                    payment_times.append(float(fields.get(b"duration_ms", 0)))
                except ValueError:
                    pass
            elif mtype == "courier_acceptance_time":
                try:
                    courier_times.append(float(fields.get(b"duration_ms", 0)))
                except ValueError:
                    pass
            elif mtype == "redis_failure":
                err = fields.get(b"error", b"").decode(errors="ignore")
                redis_errors.append(err)
            elif mtype == "state_transition_failure":
                state_failures += 1

        # Webhook latency summary
        if webhook_latencies:
            webhook_latencies.sort()
            n = len(webhook_latencies)
            p95_idx = int(n * 0.95)
            result["webhook_latency"] = {
                "count":   n,
                "avg_ms":  round(sum(webhook_latencies) / n, 2),
                "p95_ms":  round(webhook_latencies[min(p95_idx, n - 1)], 2),
            }

        # Payment processing summary
        if payment_times:
            n = len(payment_times)
            result["payment_processing_time"] = {
                "count":  n,
                "avg_ms": round(sum(payment_times) / n, 2),
            }

        # Courier acceptance summary
        if courier_times:
            n = len(courier_times)
            result["courier_acceptance_time"] = {
                "count":  n,
                "avg_ms": round(sum(courier_times) / n, 2),
            }

        result["redis_failures"] = {
            "count":  len(redis_errors),
            "recent": redis_errors[:10],
        }
        result["state_transition_failures"] = {"count": state_failures}

    except Exception as exc:
        logger.warning("aggregate_metrics failed: %s", exc)

    return result
