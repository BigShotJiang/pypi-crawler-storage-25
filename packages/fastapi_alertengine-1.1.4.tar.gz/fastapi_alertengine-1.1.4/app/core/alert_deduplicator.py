# app/core/alert_deduplicator.py
"""
AlertDeduplicator — Redis-backed alert deduplication.

Prevents the same alert type from firing repeatedly within a configurable
cooldown window (default: 5 minutes).  Uses Redis SET NX with a TTL so the
dedup key expires automatically after the cooldown elapses.

Usage::

    deduplicator = AlertDeduplicator(redis_client)
    if deduplicator.should_fire("webhook_latency", severity="critical"):
        # emit notification, persist alert record, etc.

Design:
  - Redis key: ``alert:dedup:{alert_type}``
  - Non-blocking: Redis errors are swallowed so alerting is never gated
    by Redis availability.
  - Non-custodial: no financial mutations.
  - All dedup decisions are logged for RBZ auditability.
"""

import logging
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Default cooldown between identical alerts (seconds)
_DEFAULT_COOLDOWN_SECONDS = 300  # 5 minutes


class AlertDeduplicator:
    """
    Prevent spamming of identical alerts using a Redis TTL key.

    Each alert type has a separate dedup key.  Once an alert fires, the key
    is set with a TTL equal to ``cooldown_seconds``.  While the key exists,
    :meth:`should_fire` returns ``False`` and the alert is suppressed.

    Args:
        redis: A Redis client (sync) — typically the ``_redis`` singleton from
            ``app.routers.whatsapp_bot``.
        cooldown_seconds: Minimum seconds between identical alert types.
            Defaults to 300 (5 minutes).
    """

    def __init__(self, redis: Any, cooldown_seconds: int = _DEFAULT_COOLDOWN_SECONDS) -> None:
        self._redis = redis
        self._cooldown = cooldown_seconds

    # ── Public API ────────────────────────────────────────────────────────────

    def should_fire(self, alert_type: str, severity: str = "warning") -> bool:
        """
        Return ``True`` if the alert should be emitted now (first occurrence
        within the cooldown window), ``False`` if it is a duplicate.

        Sets a Redis NX key with TTL on first occurrence so subsequent calls
        within the cooldown window are suppressed.

        Args:
            alert_type: Identifier for the alert (e.g. ``"webhook_latency"``).
            severity:   Severity string — stored in the dedup key value for
                        observability but does not affect dedup logic.

        Returns:
            ``True`` if the alert should be emitted; ``False`` otherwise.
        """
        key = self._dedup_key(alert_type)
        try:
            # SET key value NX EX ttl  — returns True if key was newly set
            result = self._redis.set(
                key,
                f"{severity}:{int(time.time())}",
                nx=True,
                ex=self._cooldown,
            )
            fired = bool(result)
            if not fired:
                logger.debug(
                    "alert_deduplicator: suppressed duplicate alert [%s] severity=%s",
                    alert_type, severity,
                )
            return fired
        except Exception as exc:
            # Redis failure → allow alert to fire (fail-open for observability)
            logger.warning(
                "alert_deduplicator: Redis error for key %s — failing open: %s",
                key, exc,
            )
            return True

    def reset(self, alert_type: str) -> None:
        """
        Manually clear the dedup key for ``alert_type``, allowing it to fire
        immediately on the next evaluation.

        Used by tests and operator tooling.
        """
        key = self._dedup_key(alert_type)
        try:
            self._redis.delete(key)
        except Exception as exc:
            logger.warning("alert_deduplicator.reset failed for %s: %s", key, exc)

    def ttl(self, alert_type: str) -> Optional[int]:
        """
        Return remaining TTL (seconds) for the dedup key, or ``None`` if the
        key does not exist.
        """
        key = self._dedup_key(alert_type)
        try:
            val = self._redis.ttl(key)
            return val if val >= 0 else None
        except Exception:
            return None

    # ── Internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _dedup_key(alert_type: str) -> str:
        return f"alert:dedup:{alert_type}"
