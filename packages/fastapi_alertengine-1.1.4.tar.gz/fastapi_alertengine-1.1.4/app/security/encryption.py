"""
app/security/encryption.py

Symmetric encryption and signed-URL utilities for KYC PII protection.

Encryption
----------
Uses Fernet (AES-128-CBC + HMAC-SHA256) from the `cryptography` package.
Key must be a URL-safe base64-encoded 32-byte value stored in the
KYC_ENCRYPTION_KEY environment variable.

Generate a new key:
    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

Signed URLs
-----------
KYC media (id_photo_url, selfie_url) must never be exposed publicly.
generate_signed_url() produces a time-limited proxy path:
    /kyc/media/{token}

The token encodes: original_url | expiry_timestamp | HMAC-SHA256 signature.
verify_signed_url() returns the original URL or None (expired / tampered).

Design constraints
------------------
- Keys loaded lazily from env — never at import time
- decrypt_value() returns ciphertext unchanged if it is not a valid Fernet token
  (backward-compatibility with unencrypted rows written before this module was deployed)
- All errors are surfaced; callers must decide how to handle
"""

import base64
import hashlib
import hmac
import os
import time
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_fernet() -> Fernet:
    raw = os.environ.get("KYC_ENCRYPTION_KEY", "")
    if not raw:
        raise RuntimeError(
            "KYC_ENCRYPTION_KEY is not set. "
            "Generate one with: python -c \"from cryptography.fernet import Fernet; "
            "print(Fernet.generate_key().decode())\""
        )
    return Fernet(raw.encode() if isinstance(raw, str) else raw)


def _signing_key() -> bytes:
    """
    Prefer KYC_SIGNING_KEY; fall back to KYC_ENCRYPTION_KEY.
    The key is hashed with SHA-256 so any byte length is accepted.
    """
    raw = os.environ.get("KYC_SIGNING_KEY") or os.environ.get("KYC_ENCRYPTION_KEY", "")
    if not raw:
        raise RuntimeError("KYC_SIGNING_KEY (or KYC_ENCRYPTION_KEY) is not set.")
    return hashlib.sha256(raw.encode()).digest()


# ─────────────────────────────────────────────────────────────────────────────
# Field encryption / decryption
# ─────────────────────────────────────────────────────────────────────────────

def encrypt_value(plaintext: str) -> str:
    """
    Encrypt *plaintext* with Fernet.

    Returns a URL-safe base64 ciphertext string suitable for TEXT columns.
    Empty / None strings are returned unchanged.
    """
    if not plaintext:
        return plaintext
    return _get_fernet().encrypt(plaintext.encode()).decode()


def decrypt_value(ciphertext: str) -> str:
    """
    Decrypt a Fernet-encrypted string.

    If *ciphertext* does not look like a valid Fernet token (e.g. a legacy
    plaintext row) the value is returned unchanged — this preserves backward
    compatibility during the rollout period.
    """
    if not ciphertext:
        return ciphertext
    try:
        return _get_fernet().decrypt(ciphertext.encode()).decode()
    except (InvalidToken, Exception):
        # Not encrypted — return as-is (graceful degradation)
        return ciphertext


# ─────────────────────────────────────────────────────────────────────────────
# Signed proxy URLs for KYC media
# ─────────────────────────────────────────────────────────────────────────────

def generate_signed_url(original_url: str, expires_in_seconds: int = 3_600) -> str:
    """
    Produce a signed proxy path for a Twilio KYC media URL.

    Token format (base64url-encoded):
        {original_url}|{expiry_unix_ts}|{hmac_sha256_hex}

    The caller is expected to prepend the proxy mount point:
        /kyc/media/{token}
    """
    expiry_ts = int(time.time()) + expires_in_seconds
    payload   = f"{original_url}|{expiry_ts}"
    sig       = hmac.new(_signing_key(), payload.encode(), hashlib.sha256).hexdigest()
    token_raw = f"{payload}|{sig}"
    return base64.urlsafe_b64encode(token_raw.encode()).decode()


def verify_signed_url(token: str) -> Optional[str]:
    """
    Verify a signed URL token produced by generate_signed_url().

    Returns the original URL string on success.
    Returns None if the token is expired, malformed, or tampered with.
    """
    try:
        token_raw = base64.urlsafe_b64decode(token.encode()).decode()
        # Split from the right to handle URLs that contain pipe characters
        parts = token_raw.rsplit("|", 2)
        if len(parts) != 3:
            return None
        original_url, expiry_ts_str, provided_sig = parts

        if int(time.time()) > int(expiry_ts_str):
            return None  # Expired

        payload      = f"{original_url}|{expiry_ts_str}"
        expected_sig = hmac.new(_signing_key(), payload.encode(), hashlib.sha256).hexdigest()

        if not hmac.compare_digest(provided_sig, expected_sig):
            return None  # Tampered

        return original_url

    except Exception:
        return None
