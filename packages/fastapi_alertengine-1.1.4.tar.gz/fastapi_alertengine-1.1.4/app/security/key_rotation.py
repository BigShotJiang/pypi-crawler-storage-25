# app/security/key_rotation.py

import os
import uuid
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timezone, timedelta
from cryptography.fernet import Fernet, InvalidToken
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class RotationMetadata:
    """Type-safe rotation metadata."""
    rotation_id: str
    key: str
    archived_at: str
    expiry: str
    status: str
    rotated_by: str
    reason: str


class VaultConnectionError(Exception):
    """Raised when Vault is unreachable."""
    pass


class KeyNotFoundError(Exception):
    """Raised when key is not found in Vault."""
    pass


class KeyRotationManager:
    """
    Production-grade encryption key rotation with archival.
    
    Features:
    - Quarterly key rotation
    - Async re-encryption (batched, non-blocking)
    - Vault integration (secrets never in code)
    - Comprehensive audit logging
    - Graceful degradation on Vault outages
    """
    
    # Configuration
    ROTATION_INTERVAL = timedelta(days=90)
    ARCHIVED_KEY_RETENTION = timedelta(days=365)
    MAX_VAULT_RETRIES = 3
    VAULT_RETRY_DELAY = 5  # seconds
    
    def __init__(
        self,
        db_session,
        vault_client,
        batch_size: int = 1000,
        batch_interval_seconds: int = 60,
    ):
        """
        Args:
            db_session: SQLAlchemy database session
            vault_client: HashiCorp Vault client (already authenticated)
            batch_size: Number of rows per re-encryption batch
            batch_interval_seconds: Delay between batches (to avoid load spikes)
        """
        self.db = db_session
        self.vault = vault_client
        self.batch_size = batch_size
        self.batch_interval_seconds = batch_interval_seconds
    
    # ─────────────────────────────────────────────────────
    # KEY LIFECYCLE
    # ─────────────────────────────────────────────────────
    
    def get_active_key(self, retry: int = 0) -> str:
        """
        Get current active encryption key from Vault.
        
        With retry logic for transient failures.
        """
        
        try:
            secret = self.vault.get_secret("tandem/encryption/active_key")
            
            # Handle both dict and string responses
            if isinstance(secret, dict):
                if "key" not in secret:
                    raise KeyNotFoundError("'key' field missing from Vault response")
                return secret["key"]
            
            return secret
        
        except Exception as e:
            if retry < self.MAX_VAULT_RETRIES:
                import time
                logger.warning(
                    f"Vault unavailable (attempt {retry + 1}/{self.MAX_VAULT_RETRIES}), retrying...",
                    exc_info=True
                )
                time.sleep(self.VAULT_RETRY_DELAY)
                return self.get_active_key(retry=retry + 1)
            
            logger.error(f"Vault unreachable after {self.MAX_VAULT_RETRIES} retries")
            raise VaultConnectionError(f"Cannot retrieve active key from Vault: {str(e)}")
    
    def get_archived_keys(self) -> List[RotationMetadata]:
        """
        Get all archived keys for decryption fallback.
        
        Ensures old data remains decryptable even after rotation.
        """
        
        try:
            keys_list = self.vault.list_secrets("tandem/encryption/archived_keys")
            
            archived = []
            for key_id in keys_list:
                try:
                    secret = self.vault.get_secret(f"tandem/encryption/archived_keys/{key_id}")
                    
                    # Parse into typed metadata
                    metadata = RotationMetadata(
                        rotation_id=secret.get("rotation_id"),
                        key=secret.get("key"),
                        archived_at=secret.get("archived_at"),
                        expiry=secret.get("expiry"),
                        status=secret.get("status", "archived"),
                        rotated_by=secret.get("rotated_by", "unknown"),
                        reason=secret.get("reason", "rotation"),
                    )
                    
                    archived.append(metadata)
                
                except Exception as e:
                    logger.warning(f"Failed to retrieve archived key {key_id}: {e}")
                    continue
            
            return archived
        
        except Exception as e:
            logger.error(f"Failed to list archived keys: {e}")
            raise VaultConnectionError(f"Cannot retrieve archived keys: {str(e)}")
    
    # ─────────────────────────────────────────────────────
    # KEY ROTATION
    # ─────────────────────────────────────────────────────
    
    def rotate_key(self, rotated_by: str, reason: str = "scheduled") -> Dict[str, Any]:
        """
        Rotate encryption key (quarterly).
        
        Workflow:
        1. Generate new key
        2. Archive old key (with 1-year retention)
        3. Store new key as active in Vault
        4. Schedule async re-encryption job
        5. Log rotation event
        
        Args:
            rotated_by: User/service performing rotation (for audit)
            reason: Why rotation is happening ("scheduled", "manual", "emergency")
        
        Returns:
            Status dict with rotation_id and next_rotation_date
        """
        
        rotation_id = self._generate_rotation_id()
        now = datetime.now(timezone.utc)
        
        try:
            # 1. Generate new key
            new_key = Fernet.generate_key().decode('utf-8')
            
            # 2. Get current active key
            old_key = self.get_active_key()
            
            # 3. Archive old key
            archive_entry = {
                "rotation_id": rotation_id,
                "key": old_key,
                "archived_at": now.isoformat(),
                "rotated_by": rotated_by,
                "reason": reason,
                "expiry": (now + self.ARCHIVED_KEY_RETENTION).isoformat(),
                "status": "archived",
            }
            
            self.vault.put_secret(
                f"tandem/encryption/archived_keys/{rotation_id}",
                archive_entry,
            )
            
            # Validate archival succeeded
            verified = self.vault.get_secret(
                f"tandem/encryption/archived_keys/{rotation_id}"
            )
            
            if not verified:
                raise KeyRotationError("Failed to verify archived key in Vault")
            
            # 4. Store new key as active
            self.vault.put_secret(
                "tandem/encryption/active_key",
                {
                    "key": new_key,
                    "active_since": now.isoformat(),
                    "rotation_id": rotation_id,
                    "rotated_by": rotated_by,
                    "reason": reason,
                },
            )
            
            # 5. Schedule re-encryption job
            self._schedule_reencryption_job(old_key, new_key, rotation_id)
            
            # 6. Log rotation event
            self._log_rotation(rotation_id, rotated_by, reason, "success")
            
            logger.info(
                "KEY_ROTATION_COMPLETED",
                extra={
                    "rotation_id": rotation_id,
                    "rotated_by": rotated_by,
                    "reason": reason,
                    "archived_key_count": len(self.get_archived_keys()),
                }
            )
            
            return {
                "status": "rotated",
                "rotation_id": rotation_id,
                "rotated_at": now.isoformat(),
                "next_rotation": (now + self.ROTATION_INTERVAL).isoformat(),
                "archived_key_count": len(self.get_archived_keys()),
            }
        
        except Exception as e:
            self._log_rotation(rotation_id, rotated_by, reason, "failed", str(e))
            logger.error(f"Key rotation failed: {e}", exc_info=True)
            
            # Alert ops team
            self._alert_rotation_failure(rotation_id, str(e))
            
            raise KeyRotationError(f"Key rotation failed: {str(e)}")
    
    # ─────────────────────────────────────────────────────
    # RE-ENCRYPTION (Async, Batched, Non-Blocking)
    # ─────────────────────────────────────────────────────
    
    def _schedule_reencryption_job(
        self,
        old_key: str,
        new_key: str,
        rotation_id: str,
    ) -> None:
        """
        Schedule async re-encryption of all PII encrypted with old key.
        
        Batches are spread over time to avoid performance impact:
        - Batch size: configurable (default 1000)
        - Interval: configurable (default 60 seconds)
        - Total time: ~= num_batches * interval
        """
        
        from app.tasks.reencryption_task import ReencryptionTask
        from app.models.database import Escrow
        
        # Estimate number of rows to re-encrypt
        encrypted_count = self.db.query(Escrow)\
            .filter(Escrow.created_by_ip_address.isnot(None))\
            .count()
        
        if encrypted_count == 0:
            logger.info("No rows to re-encrypt")
            return
        
        num_batches = (encrypted_count // self.batch_size) + 1
        total_duration_minutes = (num_batches * self.batch_interval_seconds) / 60
        
        # Create re-encryption tracking record
        self._create_reencryption_job(
            rotation_id=rotation_id,
            total_batches=num_batches,
            batch_size=self.batch_size,
        )
        
        # Queue batches
        for batch_num in range(num_batches):
            delay = batch_num * self.batch_interval_seconds
            
            ReencryptionTask.apply_async(
                args=(old_key, new_key, rotation_id, batch_num, self.batch_size),
                countdown=delay,
                task_id=f"reenc-{rotation_id}-batch-{batch_num}",
            )
        
        logger.info(
            "RE_ENCRYPTION_SCHEDULED",
            extra={
                "rotation_id": rotation_id,
                "total_rows": encrypted_count,
                "batch_size": self.batch_size,
                "total_batches": num_batches,
                "estimated_duration_minutes": total_duration_minutes,
            }
        )
    
    # ─────────────────────────────────────────────────────
    # DECRYPTION WITH FALLBACK
    # ─────────────────────────────────────────────────────
    
    def decrypt_pii(
        self,
        encrypted_value: str,
        key_id: Optional[str] = None,
        audit_user: Optional[str] = None,
        audit_reason: Optional[str] = None,
    ) -> str:
        """
        Decrypt PII value using appropriate key.
        
        Strategy:
        1. Try active key (most recent)
        2. If fails: try archived keys (oldest first)
        3. If all fail: raise error
        
        Args:
            encrypted_value: The encrypted PII string
            key_id: Optional specific key to use (for old data)
            audit_user: User requesting decryption (for audit log)
            audit_reason: Why decryption is needed ("support", "audit", "fraud_investigation")
        
        Returns:
            Decrypted plaintext value
        """
        
        if not encrypted_value:
            return None
        
        from cryptography.fernet import InvalidToken
        
        # Try active key first
        try:
            active_key = self.get_active_key()
            cipher = Fernet(active_key.encode('utf-8'))
            decrypted = cipher.decrypt(encrypted_value.encode('utf-8')).decode('utf-8')
            
            # Log successful decryption
            if audit_user:
                self._log_decryption(
                    user_id=audit_user,
                    pii_type="generic",
                    reason=audit_reason or "unknown",
                    key_source="active",
                    success=True,
                )
            
            return decrypted
        
        except InvalidToken:
            logger.warning("Failed to decrypt with active key, trying archived...")
        except Exception as e:
            logger.error(f"Error decrypting with active key: {e}", exc_info=True)
        
        # Try archived keys (fallback)
        archived_keys = self.get_archived_keys()
        
        for archived in archived_keys:
            try:
                cipher = Fernet(archived.key.encode('utf-8'))
                decrypted = cipher.decrypt(encrypted_value.encode('utf-8')).decode('utf-8')
                
                logger.info(
                    "DECRYPTED_WITH_ARCHIVED_KEY",
                    extra={"rotation_id": archived.rotation_id}
                )
                
                # Log decryption with archived key
                if audit_user:
                    self._log_decryption(
                        user_id=audit_user,
                        pii_type="generic",
                        reason=audit_reason or "unknown",
                        key_source=f"archived:{archived.rotation_id}",
                        success=True,
                    )
                
                return decrypted
            
            except InvalidToken:
                continue
            except Exception as e:
                logger.warning(f"Error with archived key {archived.rotation_id}: {e}")
                continue
        
        # All keys failed
        logger.error("Could not decrypt value with any available key")
        
        if audit_user:
            self._log_decryption(
                user_id=audit_user,
                pii_type="generic",
                reason=audit_reason or "unknown",
                key_source="none",
                success=False,
            )
        
        raise KeyNotFoundError("Could not decrypt value with any available key")
    
    # ─────────────────────────────────────────────────────
    # AUDIT LOGGING
    # ─────────────────────────────────────────────────────
    
    def _log_rotation(
        self,
        rotation_id: str,
        rotated_by: str,
        reason: str,
        status: str,
        error_message: Optional[str] = None,
    ) -> None:
        """Log key rotation event (immutable audit trail)."""
        
        from app.models.database import KeyRotationLog
        
        log = KeyRotationLog(
            rotation_id=rotation_id,
            rotated_by=rotated_by,
            reason=reason,
            status=status,
            error_message=error_message,
            rotated_at=datetime.now(timezone.utc),
        )
        
        self.db.add(log)
        self.db.commit()
    
    def _log_decryption(
        self,
        user_id: str,
        pii_type: str,
        reason: str,
        key_source: str,
        success: bool,
    ) -> None:
        """Log PII decryption event (for compliance audits)."""
        
        from app.models.database import DecryptionLog
        
        log = DecryptionLog(
            user_id=user_id,
            pii_type=pii_type,
            reason=reason,
            key_source=key_source,
            success=success,
            accessed_at=datetime.now(timezone.utc),
        )
        
        self.db.add(log)
        self.db.commit()
        
        logger.info(
            "PII_DECRYPTION_LOG",
            extra={
                "user_id": user_id,
                "pii_type": pii_type,
                "reason": reason,
                "key_source": key_source,
                "success": success,
            }
        )
    
    # ─────────────────────────────────────────────────────
    # RE-ENCRYPTION STATUS TRACKING
    # ─────────────────────────────────────────────────────
    
    def _create_reencryption_job(
        self,
        rotation_id: str,
        total_batches: int,
        batch_size: int,
    ) -> None:
        """Create tracking record for re-encryption job."""
        
        from app.models.database import ReencryptionJob
        
        job = ReencryptionJob(
            rotation_id=rotation_id,
            total_batches=total_batches,
            completed_batches=0,
            batch_size=batch_size,
            status="pending",
            started_at=datetime.now(timezone.utc),
        )
        
        self.db.add(job)
        self.db.commit()
    
    def get_reencryption_status(self, rotation_id: str) -> Dict[str, Any]:
        """Get status of re-encryption job."""
        
        from app.models.database import ReencryptionJob
        
        job = self.db.query(ReencryptionJob)\
            .filter_by(rotation_id=rotation_id)\
            .first()
        
        if not job:
            return {"status": "not_found"}
        
        progress_percent = (job.completed_batches / job.total_batches * 100) if job.total_batches > 0 else 0
        
        return {
            "rotation_id": rotation_id,
            "status": job.status,
            "completed_batches": job.completed_batches,
            "total_batches": job.total_batches,
            "progress_percent": progress_percent,
            "started_at": job.started_at.isoformat(),
            "completed_at": job.completed_at.isoformat() if job.completed_at else None,
        }
    
    # ─────────────────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────────────────
    
    def _generate_rotation_id(self) -> str:
        """Generate unique, non-predictable rotation ID."""
        return str(uuid.uuid4())
    
    def _alert_rotation_failure(self, rotation_id: str, error: str) -> None:
        """Alert ops team of rotation failure."""
        
        logger.error(
            "KEY_ROTATION_FAILED_ALERT",
            extra={
                "rotation_id": rotation_id,
                "error": error,
                "action": "INVESTIGATE_IMMEDIATELY",
            }
        )
        
        # Integrate with alerting system (Slack, PagerDuty, etc.)
        # notify_ops_team(f"Key rotation {rotation_id} failed: {error}")


class KeyRotationError(Exception):
    """Custom exception for key rotation errors."""
    pass