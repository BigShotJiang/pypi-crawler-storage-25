from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, Dict, Any
import jwt
from datetime import datetime, timezone

from app.security.encryption import decrypt_value  # available for future use


# -----------------------------
# CONFIG (adjust if needed)
# -----------------------------
SECRET_KEY = "CHANGE_ME_IN_ENV"
ALGORITHM = "HS256"


# -----------------------------
# FASTAPI BEARER SCHEME
# -----------------------------
bearer_scheme = HTTPBearer(auto_error=False)


# -----------------------------
# CORE: TOKEN DECODING
# -----------------------------
def decode_token(token: str) -> Dict[str, Any]:
    """
    Decodes JWT token and returns payload.
    Raises exception if invalid.
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired",
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
        )


# -----------------------------
# GET CURRENT USER
# -----------------------------
def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
) -> Dict[str, Any]:
    """
    Extracts and validates user from Bearer token.
    Safe for public endpoints (returns error only when required).
    """

    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication token",
        )

    token = credentials.credentials
    payload = decode_token(token)

    # Normalize user structure (important for frontend stability)
    user = {
        "user_id": payload.get("sub"),
        "role": payload.get("role", "user"),
        "email": payload.get("email"),
        "kyc_status": payload.get("kyc_status", "unknown"),
        "issued_at": payload.get("iat"),
    }

    return user


# -----------------------------
# OPTIONAL: SOFT USER (non-blocking)
# -----------------------------
def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
) -> Optional[Dict[str, Any]]:
    """
    Like get_current_user but does NOT throw errors.
    Useful for public dashboard views.
    """

    if not credentials:
        return None

    try:
        token = credentials.credentials
        payload = decode_token(token)

        return {
            "user_id": payload.get("sub"),
            "role": payload.get("role", "user"),
            "email": payload.get("email"),
            "kyc_status": payload.get("kyc_status", "unknown"),
        }
    except Exception:
        return None


# -----------------------------
# ROLE CHECK HELPERS
# -----------------------------
def require_role(required_role: str):
    """
    Dependency factory for role-based access control.
    """

    def checker(user: Dict[str, Any] = Depends(get_current_user)):
        if user.get("role") != required_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires role: {required_role}",
            )
        return user

    return checker
