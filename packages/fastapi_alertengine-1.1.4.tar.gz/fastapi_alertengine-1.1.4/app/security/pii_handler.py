"""
app/security/pii_handler.py

Minimal PII masking utility for safe log output.
Phone numbers and wallet IDs are partially masked so logs remain useful
without leaking personal data.
"""

import re


class PIIHandler:
    """Masks personally-identifiable values before they reach log sinks."""

    def mask_user_id(self, phone: str) -> str:
        """
        Returns a partially masked phone number.
        E.g. "+263771234567" → "+263***4567"
        """
        phone = str(phone).strip()
        if len(phone) <= 6:
            return "***"
        return phone[:4] + "***" + phone[-4:]

    def mask_wallet(self, wallet: str) -> str:
        """Same masking applied to wallet addresses."""
        return self.mask_user_id(wallet)

    def mask_url(self, url: str) -> str:
        """Replace path segments that look like IDs with [redacted]."""
        return re.sub(r"/[A-Za-z0-9+/=]{20,}", "/[redacted]", url)
