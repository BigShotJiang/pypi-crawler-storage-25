# app/merchant_portal/service.py
"""
Merchant Dashboard V2 — data service layer.

Design principles
─────────────────
1. PostgreSQL-authoritative: all deal/escrow data sourced from the DB.
   Redis is used ONLY for optional live courier status enrichment.

2. Read-only except for record_ready_for_pickup(), which appends one
   EscrowStateLog row.  Zero payment or escrow financial mutations.

3. Phone masking applied before any data leaves this layer.

4. Recovery flags computed directly from deal.updated_at and deal.status
   (query-layer logic) rather than scanning log entries.  This is the V2
   equivalent of a SQL CASE WHEN block — deterministic and index-friendly.

5. READY_FOR_PICKUP is state-safe: the write path re-verifies the deal is
   still in HELD status immediately before committing.  If the deal has
   transitioned away from HELD between the initial read and the write, the
   operation is aborted without error — the log entry is never appended.

6. Pagination: LIMIT/OFFSET with optional keyset cursor parameters threaded
   through.  Structure allows drop-in replacement with keyset WHERE clause.

7. Per-call structured observability log emitted by the public surface
   functions (list_deals, get_deal).  Never blocks on error.

Public surface
──────────────
    list_deals(db, merchant_phone, page, page_size, ...)  → PaginatedDeals
    get_deal(db, merchant_phone, deal_id)                 → DealDetail | None
    get_analytics(db, merchant_phone, window_hours)       → AnalyticsSummary
    record_ready_for_pickup(db, merchant_phone, deal_id)  → (bool, str)
"""

import logging
import time
from datetime import datetime, UTC, timedelta
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from app.merchant_portal.schemas import (
    AnalyticsSummary,
    CourierStatus,
    DealDetail,
    DealSummary,
    EscrowEvent,
    PaginatedDeals,
)

logger = logging.getLogger(__name__)

# ─── Recovery thresholds (mirrors courier_timeout_engine thresholds) ──────────

_COURIER_TIMEOUT_MIN  = 45      # COURIER_ASSIGNED > 45 min → COURIER_TIMEOUT
_DELIVERY_DELAY_H     = 3       # DELIVERY_IN_PROGRESS > 3 h → DELIVERY_DELAY
_EXPIRY_WARNING_MIN   = 30      # < 30 min to expiry → APPROACHING_EXPIRY


# ─── Phone masking ────────────────────────────────────────────────────────────

def _mask_phone(raw: Optional[str]) -> str:
    if not raw:
        return "***"
    s = str(raw).strip()
    if len(s) <= 6:
        return "*" * len(s)
    return f"{s[:3]}****{s[-3:]}"


# ─── Badge colour ─────────────────────────────────────────────────────────────

def _badge_color(
    status: str,
    recovery_active: bool = False,
    escrow_status: Optional[str] = None,
) -> str:
    if recovery_active:
        return "orange"
    s  = status.lower() if status else ""
    es = (escrow_status or "").lower()
    if s == "completed":
        return "green"
    if s in ("expired", "cancelled") or es in ("reversal_initiated", "reversal_confirmed"):
        return "red"
    return "yellow"


# ─── Recovery flag computation (query-layer) ──────────────────────────────────

def _compute_recovery_flag(
    deal_status:  str,
    updated_at:   Optional[datetime],
    expires_at:   Optional[datetime],
) -> Optional[str]:
    """
    Pure Python equivalent of:

        CASE
          WHEN status = 'COURIER_ASSIGNED'
           AND now() - updated_at > interval '45 minutes'
            THEN 'COURIER_TIMEOUT'
          WHEN status = 'DELIVERY_IN_PROGRESS'
           AND now() - updated_at > interval '3 hours'
            THEN 'DELIVERY_DELAY'
          WHEN expires_at IS NOT NULL
           AND expires_at - now() < interval '30 minutes'
            THEN 'APPROACHING_EXPIRY'
        END

    Returns the flag string or None.
    """
    now = datetime.now(UTC)

    # Normalise timestamps to UTC-aware
    def _tz(dt: Optional[datetime]) -> Optional[datetime]:
        if dt is None:
            return None
        return dt if dt.tzinfo else dt.replace(tzinfo=UTC)

    ua  = _tz(updated_at)
    exp = _tz(expires_at)
    s   = deal_status.lower() if deal_status else ""

    if s == "courier_assigned" and ua:
        age_min = (now - ua).total_seconds() / 60
        if age_min > _COURIER_TIMEOUT_MIN:
            return "COURIER_TIMEOUT"

    if s == "delivery_in_progress" and ua:
        age_h = (now - ua).total_seconds() / 3600
        if age_h > _DELIVERY_DELAY_H:
            return "DELIVERY_DELAY"

    if exp is not None:
        min_left = (exp - now).total_seconds() / 60
        if 0 < min_left < _EXPIRY_WARNING_MIN:
            return "APPROACHING_EXPIRY"

    return None


def _recovery_from_flag(
    flag: Optional[str],
    expires_at: Optional[datetime],
) -> Tuple[bool, Optional[str], Optional[str]]:
    """Convert a recovery_flag string to (active, reason, next_action)."""
    if not flag:
        return (False, None, None)

    actions = {
        "COURIER_TIMEOUT":    "A new courier is being matched. Customer has been notified.",
        "DELIVERY_DELAY":     "Delivery is taking longer than expected. Courier may need check-in.",
        "APPROACHING_EXPIRY": _expiry_msg(expires_at),
    }
    return (True, flag, actions.get(flag, "Recovery action in progress."))


def _expiry_msg(expires_at: Optional[datetime]) -> str:
    if expires_at is None:
        return "Deal is close to expiry. Confirm delivery PIN now."
    dt = expires_at if expires_at.tzinfo else expires_at.replace(tzinfo=UTC)
    mins_left = max(0, int((dt - datetime.now(UTC)).total_seconds() / 60))
    return f"Deal expires in {mins_left} min. Confirm delivery PIN now."


# ─── Derived timing metrics ───────────────────────────────────────────────────

def _time_in_state_sec(updated_at: Optional[datetime]) -> Optional[int]:
    """Seconds since the last status change (deal.updated_at or escrow.updated_at)."""
    if not updated_at:
        return None
    dt = updated_at if updated_at.tzinfo else updated_at.replace(tzinfo=UTC)
    return int((datetime.now(UTC) - dt).total_seconds())


def _time_since_payment_sec(escrow_created_at: Optional[datetime]) -> Optional[int]:
    """Seconds since the escrow was created (= payment confirmed)."""
    if not escrow_created_at:
        return None
    dt = escrow_created_at if escrow_created_at.tzinfo else escrow_created_at.replace(tzinfo=UTC)
    return int((datetime.now(UTC) - dt).total_seconds())


def _courier_assignment_latency_sec(
    escrow_logs: List[Any],
    payment_confirmed_at: Optional[datetime],
) -> Optional[int]:
    """
    Time from payment confirmed (escrow created) to courier assigned.
    Reads the first COURIER_ASSIGNED log entry's created_at.
    """
    if not payment_confirmed_at:
        return None
    for log in escrow_logs:
        if (log.new_status or "").lower() in ("courier_assigned", "courier_matching"):
            assigned_at = log.created_at
            if assigned_at.tzinfo is None:
                assigned_at = assigned_at.replace(tzinfo=UTC)
            pca = payment_confirmed_at if payment_confirmed_at.tzinfo else payment_confirmed_at.replace(tzinfo=UTC)
            return max(0, int((assigned_at - pca).total_seconds()))
    return None


# ─── Redis courier status enrichment (best-effort) ───────────────────────────

_COURIER_STATE_ETA: Dict[str, int] = {
    "courier_assigned":       20,  # Just picked up: ~20 min
    "delivery_in_progress":   15,  # En route: ~15 min
    "awaiting_pin":            5,  # At the door: ~5 min
}


def _get_courier_status_from_redis(deal_id: str) -> Optional[CourierStatus]:
    """Best-effort Redis read.  Returns None on any failure."""
    try:
        from app.routers.whatsapp_bot import _redis
        import json
        rdb = _redis

        raw = rdb.get(f"bot:courier_job_by_deal:{deal_id}")
        if not raw:
            return None
        job = json.loads(raw.decode() if isinstance(raw, bytes) else raw)
        courier_phone = job.get("courier_phone", "")
        if not courier_phone:
            return None

        # State
        state_raw = rdb.get(f"bot:state:{courier_phone}")
        state = (state_raw.decode() if isinstance(state_raw, bytes) else state_raw) or "unknown"

        # Age + last_update timestamp
        ts_raw = rdb.get(f"bot:state_ts:{courier_phone}")
        age_minutes  = None
        last_update  = None
        if ts_raw:
            try:
                ts_float  = float(ts_raw.decode() if isinstance(ts_raw, bytes) else ts_raw)
                age_s     = time.time() - ts_float
                age_minutes = int(age_s / 60)
                last_update = datetime.fromtimestamp(ts_float, tz=UTC)
            except (ValueError, TypeError):
                pass

        # ETA heuristic
        state_lower = state.lower()
        base_eta    = _COURIER_STATE_ETA.get(state_lower)
        eta_minutes = None
        if base_eta is not None and age_minutes is not None:
            eta_minutes = max(0, base_eta - age_minutes)

        return CourierStatus(
            phone_masked=_mask_phone(courier_phone),
            state=state,
            deal_id=deal_id,
            age_minutes=age_minutes,
            last_update=last_update,
            eta_minutes=eta_minutes,
        )
    except Exception as exc:
        logger.debug("_get_courier_status deal=%s: %s", deal_id, exc)
        return None


# ─── Observability ────────────────────────────────────────────────────────────

def _obs_log(
    endpoint:      str,
    merchant_hash: int,
    latency_ms:    float,
    rows:          int,
) -> None:
    """Emit a structured per-request observability log line.  Never raises."""
    try:
        logger.info(
            '{"merchant":%d,"endpoint":"%s","latency_ms":%.1f,"rows":%d}',
            merchant_hash, endpoint, latency_ms, rows,
        )
    except Exception:
        pass


# ─── Ready-for-pickup helpers ─────────────────────────────────────────────────

def _check_ready_for_pickup(escrow_logs: List[Any]) -> bool:
    return any((l.new_status or "").lower() == "ready_for_pickup" for l in escrow_logs)


# ─── Public: list_deals ───────────────────────────────────────────────────────

def list_deals(
    db:             Session,
    merchant_phone: str,
    page:           int = 1,
    page_size:      int = 20,
    status_filter:  Optional[str] = None,
    cursor_ts:      Optional[str] = None,
    cursor_id:      Optional[int] = None,
) -> PaginatedDeals:
    """
    Return a paginated list of deals for a merchant.

    cursor_ts / cursor_id are accepted but currently used only to populate
    the PaginatedDeals.next_cursor_* fields (enabling future keyset swap
    without any API contract change).
    """
    from app.models.database import Deal, EscrowStateLog

    t0 = time.perf_counter()

    page      = max(1, page)
    page_size = max(1, min(100, page_size))
    offset    = (page - 1) * page_size

    q = db.query(Deal).filter(Deal.seller_phone == merchant_phone)
    if status_filter:
        q = q.filter(Deal.status.in_([status_filter, status_filter.lower(), status_filter.upper()]))

    total = q.count()
    rows: List[Deal] = (
        q.order_by(Deal.created_at.desc())
        .offset(offset)
        .limit(page_size)
        .all()
    )

    summaries: List[DealSummary] = []
    for deal in rows:
        status_str = deal.status.value if hasattr(deal.status, "value") else str(deal.status)
        escrow = deal.escrow if deal.escrow_id else None
        escrow_status_str = None
        if escrow:
            escrow_status_str = (
                escrow.status.value if hasattr(escrow.status, "value") else str(escrow.status)
            )

        customer_masked = _mask_phone(escrow.payer_wallet_id) if escrow else "Pending"
        updated_at = getattr(escrow, "updated_at", None) or deal.created_at
        expires_at = getattr(escrow, "expiry_timestamp", None) or deal.expires_at

        # Query-layer recovery flag (no log scan needed)
        rflag = _compute_recovery_flag(status_str, updated_at, expires_at)
        recovery_active, recovery_reason, _ = _recovery_from_flag(rflag, expires_at)

        # Best-effort Redis courier state
        courier_obj = _get_courier_status_from_redis(deal.deal_id)

        summaries.append(DealSummary(
            deal_id=deal.deal_id,
            status=status_str,
            amount=float(deal.price),
            currency=getattr(deal, "currency_code", "USD"),
            customer=customer_masked,
            created_at=deal.created_at,
            updated_at=updated_at,
            courier_status=courier_obj.state if courier_obj else None,
            badge_color=_badge_color(status_str, recovery_active, escrow_status_str),
            recovery_active=recovery_active,
            recovery_reason=recovery_reason,
            recovery_flag=rflag,
            time_in_state_sec=_time_in_state_sec(updated_at),
        ))

    # Keyset cursor values (for next page — populated even with LIMIT/OFFSET)
    next_cursor_ts = None
    next_cursor_id = None
    if rows:
        last = rows[-1]
        next_cursor_ts = last.created_at.isoformat()
        next_cursor_id = last.id

    total_pages = max(1, (total + page_size - 1) // page_size)
    result = PaginatedDeals(
        deals=summaries,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        has_next=offset + page_size < total,
        next_cursor_ts=next_cursor_ts if offset + page_size < total else None,
        next_cursor_id=next_cursor_id if offset + page_size < total else None,
    )

    _obs_log("list_deals", hash(merchant_phone) % 100_000,
             (time.perf_counter() - t0) * 1000, len(summaries))
    return result


# ─── Public: get_deal ─────────────────────────────────────────────────────────

def get_deal(
    db:             Session,
    merchant_phone: str,
    deal_id:        str,
) -> Optional[DealDetail]:
    """
    Return full deal detail.  Returns None if not found or not owned by merchant.
    """
    from app.models.database import Deal, EscrowStateLog

    t0 = time.perf_counter()

    deal: Optional[Deal] = (
        db.query(Deal)
        .filter(Deal.deal_id == deal_id, Deal.seller_phone == merchant_phone)
        .first()
    )
    if not deal:
        _obs_log("get_deal:miss", hash(merchant_phone) % 100_000,
                 (time.perf_counter() - t0) * 1000, 0)
        return None

    status_str = deal.status.value if hasattr(deal.status, "value") else str(deal.status)
    escrow = deal.escrow if deal.escrow_id else None
    escrow_status_str = None
    reversal_reason   = None
    if escrow:
        escrow_status_str = (
            escrow.status.value if hasattr(escrow.status, "value") else str(escrow.status)
        )
        reversal_reason = getattr(escrow, "reversal_reason", None)

    logs: List[EscrowStateLog] = []
    if deal.escrow_id:
        logs = (
            db.query(EscrowStateLog)
            .filter(EscrowStateLog.escrow_id == deal.escrow_id)
            .order_by(EscrowStateLog.created_at.asc())
            .all()
        )

    escrow_events = [
        EscrowEvent(
            id=log.id,
            previous_status=log.previous_status or "",
            new_status=log.new_status or "",
            triggered_by=log.triggered_by or "",
            created_at=log.created_at,
            metadata=log.get_metadata(),
        )
        for log in logs
    ]

    customer_masked = _mask_phone(escrow.payer_wallet_id) if escrow else "Pending"
    updated_at = getattr(escrow, "updated_at", None) or deal.created_at
    expires_at = getattr(escrow, "expiry_timestamp", None) or deal.expires_at
    escrow_created_at = getattr(escrow, "created_at", None)

    # Query-layer recovery flag
    rflag = _compute_recovery_flag(status_str, updated_at, expires_at)
    recovery_active, recovery_reason, recovery_next_action = _recovery_from_flag(rflag, expires_at)

    # Live courier
    courier_obj = _get_courier_status_from_redis(deal_id)

    # Ready for pickup
    ready = _check_ready_for_pickup(logs)

    # Derived metrics
    tis  = _time_in_state_sec(updated_at)
    tsps = _time_since_payment_sec(escrow_created_at)
    cala = _courier_assignment_latency_sec(logs, escrow_created_at)

    badge = _badge_color(status_str, recovery_active, escrow_status_str)

    _obs_log("get_deal", hash(merchant_phone) % 100_000,
             (time.perf_counter() - t0) * 1000, len(logs))

    return DealDetail(
        deal_id=deal.deal_id,
        status=status_str,
        amount=float(deal.price),
        currency=getattr(deal, "currency_code", "USD"),
        customer=customer_masked,
        seller_name=deal.seller_name,
        item_description=deal.item_description,
        quantity=deal.quantity,
        merchant_acknowledged=bool(deal.merchant_acknowledged),
        created_at=deal.created_at,
        updated_at=updated_at,
        expires_at=expires_at,
        escrow_status=escrow_status_str,
        reversal_reason=reversal_reason,
        courier=courier_obj,
        escrow_history=escrow_events,
        recovery_active=recovery_active,
        recovery_reason=recovery_reason,
        recovery_next_action=recovery_next_action,
        recovery_flag=rflag,
        ready_for_pickup=ready,
        badge_color=badge,
        time_in_state_sec=tis,
        time_since_payment_sec=tsps,
        courier_assignment_latency_sec=cala,
    )


# ─── Public: get_analytics ────────────────────────────────────────────────────

def get_analytics(
    db:             Session,
    merchant_phone: str,
    window_hours:   int = 24,
) -> AnalyticsSummary:
    """
    Compute lightweight analytics for the last window_hours.

    All queries filter on seller_phone (indexed) + created_at range.
    """
    from app.models.database import Deal, DealStatus

    t0  = time.perf_counter()
    now = datetime.now(UTC)
    since = now - timedelta(hours=window_hours)

    base_q = (
        db.query(Deal)
        .filter(
            Deal.seller_phone == merchant_phone,
            Deal.created_at >= since,
        )
    )

    today_orders     = base_q.count()
    completed_orders = base_q.filter(Deal.status == DealStatus.COMPLETED).count()
    expired_count    = base_q.filter(Deal.status == DealStatus.EXPIRED).count()
    cancelled_count  = base_q.filter(Deal.status == DealStatus.CANCELLED).count()

    # Active = held + in-flight courier states (these are Deal statuses in our model)
    # Our Deal model has: CREATED, HELD, DELIVERED, COMPLETED, EXPIRED, CANCELLED
    active_deals = base_q.filter(
        Deal.status.in_([DealStatus.HELD, DealStatus.DELIVERED])
    ).count()
    pending_payment = base_q.filter(Deal.status == DealStatus.CREATED).count()

    # Average delivery time: completed_at - created_at for COMPLETED deals
    avg_delivery_time_sec: Optional[float] = None
    try:
        completed_rows = (
            base_q.filter(
                Deal.status == DealStatus.COMPLETED,
                Deal.completed_at.isnot(None),
            )
            .with_entities(Deal.created_at, Deal.completed_at)
            .all()
        )
        if completed_rows:
            deltas = []
            for row in completed_rows:
                ca = row.created_at if row.created_at.tzinfo else row.created_at.replace(tzinfo=UTC)
                co = row.completed_at if row.completed_at.tzinfo else row.completed_at.replace(tzinfo=UTC)
                deltas.append((co - ca).total_seconds())
            avg_delivery_time_sec = sum(deltas) / len(deltas)
    except Exception as exc:
        logger.debug("analytics: avg_delivery_time_sec failed: %s", exc)

    failure_count = expired_count + cancelled_count
    failure_rate  = (failure_count / today_orders) if today_orders > 0 else 0.0

    _obs_log("get_analytics", hash(merchant_phone) % 100_000,
             (time.perf_counter() - t0) * 1000, today_orders)

    return AnalyticsSummary(
        window_hours=window_hours,
        today_orders=today_orders,
        completed_orders=completed_orders,
        avg_delivery_time_sec=avg_delivery_time_sec,
        failure_rate=round(failure_rate, 4),
        active_deals=active_deals,
        pending_payment=pending_payment,
        generated_at=now,
    )


# ─── Public: record_ready_for_pickup ─────────────────────────────────────────

def record_ready_for_pickup(
    db:             Session,
    merchant_phone: str,
    deal_id:        str,
) -> Tuple[bool, str]:
    """
    State-safe, idempotent READY_FOR_PICKUP marker.

    Safety guarantee (V2):
        The deal's status is re-verified inside the transaction immediately
        before writing the log entry.  If the status has changed away from
        HELD since the initial read (race condition), the write is aborted
        and (False, "deal_not_actionable:<status>") is returned.

    Write: EscrowStateLog(new_status="ready_for_pickup") only.
    No mutations to Escrow, Deal, or any financial field.
    """
    from app.models.database import Deal, DealStatus, EscrowStateLog

    try:
        # ── Initial load ──────────────────────────────────────────────────────
        deal: Optional[Deal] = (
            db.query(Deal)
            .filter(Deal.deal_id == deal_id, Deal.seller_phone == merchant_phone)
            .first()
        )
        if not deal:
            return (False, "deal_not_found")
        if not deal.escrow_id:
            return (False, "escrow_not_linked")

        # ── Idempotency: check for existing log ───────────────────────────────
        existing = (
            db.query(EscrowStateLog)
            .filter(
                EscrowStateLog.escrow_id == deal.escrow_id,
                EscrowStateLog.new_status == "ready_for_pickup",
            )
            .first()
        )
        if existing:
            return (True, "already_marked")

        # ── State-safe guard: re-read status immediately before write ─────────
        # db.refresh forces a re-query rather than using the cached ORM state
        db.refresh(deal)
        status_str = deal.status.value if hasattr(deal.status, "value") else str(deal.status)
        if status_str not in ("held", "HELD"):
            return (False, f"deal_not_actionable:{status_str}")

        # ── Read last log for previous_status ─────────────────────────────────
        last_log = (
            db.query(EscrowStateLog)
            .filter(EscrowStateLog.escrow_id == deal.escrow_id)
            .order_by(EscrowStateLog.created_at.desc())
            .first()
        )
        prev_status = last_log.new_status if last_log else status_str

        # ── Append audit log ──────────────────────────────────────────────────
        log_entry = EscrowStateLog(
            escrow_id=deal.escrow_id,
            previous_status=prev_status,
            new_status="ready_for_pickup",
            triggered_by="merchant_dashboard",
            metadata_json=None,
        )
        db.add(log_entry)
        db.commit()

        # ── Advisory Redis signal (best-effort, after commit) ─────────────────
        try:
            from app.routers.whatsapp_bot import _redis
            import json as _json
            _redis.setex(
                f"bot:ready_for_pickup:{deal_id}",
                3_600,
                _json.dumps({"deal_id": deal_id, "merchant_phone": merchant_phone}),
            )
        except Exception:
            pass   # DB committed; Redis failure doesn't invalidate the write

        logger.info(
            "record_ready_for_pickup: deal=%s merchant_hash=%s",
            deal_id, hash(merchant_phone) % 100_000,
        )
        return (True, "marked")

    except Exception as exc:
        logger.error("record_ready_for_pickup failed deal=%s: %s", deal_id, exc)
        try:
            db.rollback()
        except Exception:
            pass
        return (False, f"internal_error:{exc}")
