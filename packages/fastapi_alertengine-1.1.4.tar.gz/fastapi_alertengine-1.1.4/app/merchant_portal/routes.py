# app/merchant_portal/routes.py
"""
Merchant Dashboard V2 — FastAPI router.

Changes from V1:
  - ETag support on /api/deals and /api/deal/{id} (304 Not Modified)
  - Per-request observability header X-Latency-Ms
  - GET /dashboard/api/analytics — 24h merchant analytics
  - Keyset cursor params (?cursor_ts, ?cursor_id) threaded through
  - BackgroundTask notification trigger after ready-for-pickup

All endpoints require Authorization: Bearer <token>.
merchant_phone is always resolved from the validated session — never from the
client request body, query string, or URL segment.

Prefix: /dashboard
"""

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Optional

from fastapi import (
    APIRouter, BackgroundTasks, Depends, Header, HTTPException,
    Query, Request, Response, status,
)
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.merchant_portal.auth import get_merchant_context, _get_db_session
from app.merchant_portal.schemas import (
    AnalyticsSummary,
    DealDetail,
    MerchantContext,
    PaginatedDeals,
    ReadyForPickupResponse,
)
from app.merchant_portal import service
from app.merchant_portal.health import compute_health_score, MerchantHealthScore

logger = logging.getLogger(__name__)

router     = APIRouter(prefix="/dashboard", tags=["merchant-dashboard"])
templates  = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))


# ─── Event bus registration (once at import time) ─────────────────────────────
# Handlers are idempotent — registering twice is a no-op (dedup in register_handler)

def _register_event_handlers() -> None:
    try:
        from app.core.event_bus import register_handler
        from app.merchant_portal.notifications import notify_merchant_event
        for evt in (
            "payment_confirmed",
            "courier_assigned",
            "courier_delayed",
            "delivery_completed",
            "awaiting_courier",
            "courier_stalled",
            "delivery_delayed",
        ):
            register_handler(evt, notify_merchant_event)
        logger.info("event_bus: merchant notification handlers registered")
    except Exception as exc:
        logger.warning("event_bus: handler registration failed (non-fatal): %s", exc)


_register_event_handlers()


# ─── ETag helpers ─────────────────────────────────────────────────────────────

def _compute_etag(data: dict) -> str:
    """MD5 of stable JSON serialisation → weak ETag string."""
    canonical = json.dumps(data, sort_keys=True, default=str)
    digest    = hashlib.md5(canonical.encode(), usedforsecurity=False).hexdigest()
    return f'W/"{digest}"'


def _etag_response(
    data:       dict,
    if_none_match: Optional[str],
) -> Response:
    """
    Return 304 if the client's ETag matches, else 200 with JSON + ETag header.
    """
    etag = _compute_etag(data)
    if if_none_match and if_none_match.strip('"').lstrip("W/").strip('"') == etag.strip('"').lstrip("W/").strip('"'):
        return Response(status_code=304, headers={"ETag": etag})
    content = json.dumps(data, default=str)
    return Response(
        content=content,
        media_type="application/json",
        headers={"ETag": etag, "Cache-Control": "no-cache"},
    )


# ─── HTML: dashboard ─────────────────────────────────────────────────────────

@router.get("/", response_class=HTMLResponse, include_in_schema=False)
async def dashboard_page(
    request:       Request,
    page:          int           = Query(default=1, ge=1),
    page_size:     int           = Query(default=20, ge=1, le=100),
    status_filter: Optional[str] = Query(default=None, alias="status"),
    merchant=Depends(get_merchant_context),
    db: Session = Depends(_get_db_session),
):
    """HTML deal list with analytics panel, 12s auto-refresh polling."""
    t0 = time.perf_counter()

    result    = service.list_deals(
        db=db, merchant_phone=merchant.phone,
        page=page, page_size=page_size, status_filter=status_filter,
    )
    analytics = service.get_analytics(db=db, merchant_phone=merchant.phone)

    resp = templates.TemplateResponse(
        "dashboard.html",
        {
            "request":       request,
            "merchant_name": merchant.name,
            "deals":         result.deals,
            "pagination":    result,
            "page":          page,
            "page_size":     page_size,
            "status_filter": status_filter or "",
            "analytics":     analytics,
        },
    )
    resp.headers["X-Latency-Ms"] = f"{(time.perf_counter() - t0) * 1000:.1f}"
    return resp


# ─── HTML: deal detail ────────────────────────────────────────────────────────

@router.get("/deal/{deal_id}/view", response_class=HTMLResponse, include_in_schema=False)
async def deal_detail_page(
    deal_id:  str,
    request:  Request,
    merchant=Depends(get_merchant_context),
    db: Session = Depends(_get_db_session),
):
    """HTML detail view; escrow timeline, courier tracking, 15s polling."""
    t0 = time.perf_counter()
    detail = service.get_deal(db=db, merchant_phone=merchant.phone, deal_id=deal_id)
    if not detail:
        raise HTTPException(status_code=404, detail="Deal not found")

    resp = templates.TemplateResponse(
        "deal_detail.html",
        {
            "request":       request,
            "merchant_name": merchant.name,
            "deal":          detail,
        },
    )
    resp.headers["X-Latency-Ms"] = f"{(time.perf_counter() - t0) * 1000:.1f}"
    return resp


# ─── JSON: list deals ─────────────────────────────────────────────────────────

@router.get(
    "/api/deals",
    summary="List merchant deals (paginated + ETag)",
    description=(
        "Paginated deal list. Supports If-None-Match for 304 short-circuit. "
        "Optional keyset cursor params for future pagination upgrade."
    ),
)
async def api_list_deals(
    page:          int           = Query(default=1, ge=1),
    page_size:     int           = Query(default=20, ge=1, le=100),
    status_filter: Optional[str] = Query(default=None, alias="status"),
    cursor_ts:     Optional[str] = Query(default=None, description="Keyset cursor (ISO8601)"),
    cursor_id:     Optional[int] = Query(default=None, description="Keyset cursor (deal DB id)"),
    if_none_match: Optional[str] = Header(default=None, alias="if-none-match"),
    merchant=Depends(get_merchant_context),
    db: Session = Depends(_get_db_session),
) -> Response:
    """
    Returns a paginated deal list with pre-computed badges and recovery flags.

    ETag behaviour:
        Send the ETag value from a previous response as If-None-Match.
        If the data is unchanged, 304 Not Modified is returned with no body,
        saving bandwidth on the 12-second polling cycle.

    Keyset cursors (cursor_ts + cursor_id):
        Currently accepted but used only to populate next_cursor_* in the
        response.  The service layer is structured to accept keyset WHERE
        clauses as a drop-in replacement for LIMIT/OFFSET without any API
        contract changes.
    """
    t0 = time.perf_counter()
    try:
        result = service.list_deals(
            db=db,
            merchant_phone=merchant.phone,
            page=page,
            page_size=page_size,
            status_filter=status_filter,
            cursor_ts=cursor_ts,
            cursor_id=cursor_id,
        )
    except Exception as exc:
        logger.error("api_list_deals merchant_hash=%s: %s",
                     hash(merchant.phone) % 100_000, exc)
        raise HTTPException(status_code=500, detail="Failed to load deals")

    data = result.model_dump()
    resp = _etag_response(data, if_none_match)
    resp.headers["X-Latency-Ms"] = f"{(time.perf_counter() - t0) * 1000:.1f}"
    return resp


# ─── JSON: deal detail ────────────────────────────────────────────────────────

@router.get(
    "/api/deal/{deal_id}",
    summary="Get deal detail with timeline + metrics (ETag)",
    description=(
        "Full deal detail: escrow history, live courier status, derived metrics. "
        "Supports If-None-Match 304 short-circuit."
    ),
)
async def api_get_deal(
    deal_id:       str,
    if_none_match: Optional[str] = Header(default=None, alias="if-none-match"),
    merchant=Depends(get_merchant_context),
    db: Session = Depends(_get_db_session),
) -> Response:
    """
    Full deal detail with:
      - escrow_history: ordered audit timeline
      - courier: live state, age, last_update, eta_minutes (Redis, best-effort)
      - recovery_flag: SQL-computed (COURIER_TIMEOUT / DELIVERY_DELAY / APPROACHING_EXPIRY)
      - time_in_state_sec, time_since_payment_sec, courier_assignment_latency_sec

    ETag: send as If-None-Match on the 15-second polling cycle.
    """
    t0 = time.perf_counter()
    detail = service.get_deal(db=db, merchant_phone=merchant.phone, deal_id=deal_id)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Deal {deal_id!r} not found")

    data = detail.model_dump()
    resp = _etag_response(data, if_none_match)
    resp.headers["X-Latency-Ms"] = f"{(time.perf_counter() - t0) * 1000:.1f}"
    return resp


# ─── JSON: analytics ─────────────────────────────────────────────────────────

@router.get(
    "/api/analytics",
    response_model=AnalyticsSummary,
    summary="Merchant analytics (last 24h)",
    description=(
        "Lightweight analytics for the authenticated merchant over the last 24 hours. "
        "All values computed from indexed PostgreSQL queries."
    ),
)
async def api_analytics(
    window_hours: int = Query(default=24, ge=1, le=168, description="Look-back window in hours"),
    merchant=Depends(get_merchant_context),
    db: Session = Depends(_get_db_session),
) -> AnalyticsSummary:
    """
    Returns:
        {
            "window_hours": 24,
            "today_orders": 12,
            "completed_orders": 8,
            "avg_delivery_time_sec": 1842.5,
            "failure_rate": 0.0833,
            "active_deals": 3,
            "pending_payment": 1,
            "generated_at": "2026-03-30T14:00:00Z"
        }

    Uses indexed queries on (seller_phone, created_at).
    Redis is not used — PostgreSQL is the authoritative data source.
    """
    try:
        return service.get_analytics(
            db=db,
            merchant_phone=merchant.phone,
            window_hours=window_hours,
        )
    except Exception as exc:
        logger.error("api_analytics merchant_hash=%s: %s",
                     hash(merchant.phone) % 100_000, exc)
        raise HTTPException(status_code=500, detail="Analytics query failed")


# ─── POST: ready-for-pickup ───────────────────────────────────────────────────

@router.post(
    "/api/deal/{deal_id}/ready-for-pickup",
    response_model=ReadyForPickupResponse,
    summary="Mark deal ready for courier pickup",
    description=(
        "State-safe, idempotent. Only succeeds if deal is still in HELD status. "
        "Appends EscrowStateLog audit entry. No financial mutations. "
        "Fires a background merchant notification."
    ),
)
async def api_ready_for_pickup(
    deal_id:           str,
    background_tasks:  BackgroundTasks,
    merchant=Depends(get_merchant_context),
    db: Session = Depends(_get_db_session),
) -> ReadyForPickupResponse:
    """
    Marks the deal as packaged and ready for courier collection.

    State guard (V2):
        The service layer re-verifies deal.status == HELD immediately before
        writing the audit log entry.  If the deal has moved out of HELD since
        the HTTP request was received, the write is aborted — no log appended.

    Side effects:
        1. EscrowStateLog(new_status="ready_for_pickup", triggered_by="merchant_dashboard")
        2. Redis advisory key bot:ready_for_pickup:{deal_id} (1h TTL)
        3. Background WhatsApp notification to merchant (courier_assigned confirmation)
    """
    success, message = service.record_ready_for_pickup(
        db=db,
        merchant_phone=merchant.phone,
        deal_id=deal_id,
    )

    if not success:
        if message == "deal_not_found":
            raise HTTPException(status_code=404, detail="Deal not found")
        if message.startswith("deal_not_actionable"):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Deal not in HELD status: {message.split(':', 1)[-1]}",
            )
        if message == "escrow_not_linked":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Payment not yet confirmed — escrow not linked",
            )
        raise HTTPException(status_code=500, detail="Failed to record ready_for_pickup")

    # Fire background notification only on first mark (not re-marks)
    if message == "marked":
        from app.merchant_portal.notifications import notify_merchant
        background_tasks.add_task(notify_merchant, "courier_assigned", deal_id, db)

    return ReadyForPickupResponse(deal_id=deal_id, success=True, message=message)


# ─── GET: current merchant identity ─────────────────────────────────────────

@router.get(
    "/api/me",
    summary="Current merchant identity",
    description="Returns name and phone for the authenticated merchant. Used by the client-side dashboard to identify the session.",
)
async def api_me(merchant=Depends(get_merchant_context)) -> dict:
    """Phone and name for the authenticated merchant session."""
    return {"phone": merchant.phone, "name": merchant.name, "slug": getattr(merchant, "slug", None)}


# ─── GET: merchant health score ───────────────────────────────────────────────

@router.get(
    "/api/health",
    response_model=MerchantHealthScore,
    summary="Merchant health score (0–100)",
    description=(
        "Computes a composite health score from last-24h PostgreSQL data. "
        "Weighted: 50% success_rate + 30% delivery speed + 20% low delay ratio. "
        "Also runs the stuck-deal detector scoped to this merchant."
    ),
)
async def api_health(
    merchant=Depends(get_merchant_context),
    db: Session = Depends(_get_db_session),
) -> MerchantHealthScore:
    """
    Returns:
        {
            "success_rate":          0.94,
            "avg_delivery_time_sec": 1800.0,
            "delay_ratio":           0.12,
            "stuck_deals":           2,
            "health_score":          87,
            "health_label":          "good",
            "total_deals_24h":       16,
            "generated_at":          "2026-03-30T14:00:00Z"
        }

    health_label:
        "good"  — score ≥ 80
        "fair"  — score 60–79
        "poor"  — score < 60

    PostgreSQL-only: no Redis dependency.
    """
    t0 = time.perf_counter()
    try:
        result = compute_health_score(db=db, merchant_phone=merchant.phone)
        logger.info(
            "api_health: merchant_hash=%d score=%d latency_ms=%.1f",
            hash(merchant.phone) % 100_000,
            result.health_score,
            (time.perf_counter() - t0) * 1000,
        )
        return result
    except Exception as exc:
        logger.error("api_health merchant_hash=%d: %s",
                     hash(merchant.phone) % 100_000, exc)
        raise HTTPException(status_code=500, detail="Health score computation failed")
