# app/merchant_portal/notifications.py
"""
Merchant WhatsApp Notifications V2 — contextual, atomic dedup.

Changes from V1
───────────────
1. Atomic dedup: Redis SET NX EX instead of GET + conditional SET.
   Only one process can win the NX write; duplicates are silently dropped.

2. Contextual messages: templates embed time_in_state, courier state,
   deal amounts — no more generic "delay detected" strings.

3. New events from stuck_detector:
       awaiting_courier   → payment arrived, no courier yet
       courier_stalled    → courier assigned but no movement
       delivery_delayed   → stuck in delivery > 2h

4. Time formatting: 134 min → "2h 14m" (uses fmt_duration from stuck_detector)

5. Structured event handler compatible with event_bus.py:
       notify_merchant_event(event_name: str, payload: dict)
   Register once at startup; the bus calls it for every matching event.

Dedup key
─────────
    notify_sent:{deal_id}:{event_type}   TTL = 24h (86400s)
    SET … NX EX 86400 — atomic: returns 1 on first write, None on duplicate

Redis unavailability
────────────────────
    _atomic_dedup() returns True (permit send) on any Redis error.
    Duplicate risk is preferable to silent drop on Redis failure.
    A warning is logged so ops teams can investigate.

Non-blocking
────────────
    All functions are sync — designed for BackgroundTask executor threads.
    Never raises.
"""

import logging
from typing import Optional

from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

_NOTIFY_DEDUP_TTL = 86_400   # 24 h


# ── Time formatting ───────────────────────────────────────────────────────────

def fmt_duration(seconds: int) -> str:
    """
    134 s  → "2m 14s"
    8040 s → "2h 14m"
    45 s   → "45s"
    """
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m {seconds % 60}s"
    return f"{minutes // 60}h {minutes % 60}m"


# ── Contextual message templates ──────────────────────────────────────────────
# Each template is a callable that receives the deal ORM object + extra kwargs
# and returns a formatted string.

def _msg_payment_confirmed(deal, **kw) -> str:
    escrow = getattr(deal, "escrow", None)
    amount = float(getattr(escrow, "total_escrow", deal.price) if escrow else deal.price)
    currency = getattr(deal, "currency_code", "USD")
    return (
        f"✅ *Payment confirmed!*\n"
        f"Deal #{deal.deal_id} — {deal.item_description[:50]}\n"
        f"Amount: {currency} {amount:.2f}\n\n"
        f"Start preparing the order and mark it *Ready for Pickup* on your dashboard."
    )


def _msg_courier_assigned(deal, **kw) -> str:
    return (
        f"🚚 *Courier assigned!*\n"
        f"Deal #{deal.deal_id} — {deal.item_description[:50]}\n"
        f"A courier is on the way to collect your package."
    )


def _msg_courier_delayed(deal, **kw) -> str:
    duration = kw.get("time_in_state_sec")
    dur_str  = f" ({fmt_duration(int(duration))})" if duration else ""
    return (
        f"⚠️ *Delivery delay detected*\n"
        f"Deal #{deal.deal_id}{dur_str} has been in progress longer than expected.\n"
        f"Courier may be delayed. AnchorFlow is monitoring. No action needed from you."
    )


def _msg_delivery_completed(deal, **kw) -> str:
    escrow   = getattr(deal, "escrow", None)
    payout   = float(getattr(escrow, "merchant_final_payout", deal.price) if escrow else deal.price)
    currency = getattr(deal, "currency_code", "USD")
    return (
        f"🎉 *Delivery confirmed!*\n"
        f"Deal #{deal.deal_id} — {deal.item_description[:50]}\n"
        f"Your payout: {currency} {payout:.2f}\n"
        f"Funds will be released to your wallet shortly. Well done! 🙌"
    )


def _msg_awaiting_courier(deal, **kw) -> str:
    duration = kw.get("time_in_state_sec")
    dur_str  = fmt_duration(int(duration)) if duration else "a few minutes"
    return (
        f"🔍 *Looking for a courier*\n"
        f"Deal #{deal.deal_id} — {deal.item_description[:50]}\n"
        f"Payment confirmed {dur_str} ago. We're still matching a courier.\n"
        f"We'll notify you as soon as one is assigned."
    )


def _msg_courier_stalled(deal, **kw) -> str:
    duration = kw.get("time_in_state_sec")
    dur_str  = fmt_duration(int(duration)) if duration else "45+ minutes"
    return (
        f"⚠️ *Courier may be unresponsive*\n"
        f"Deal #{deal.deal_id} — assigned {dur_str} ago with no delivery update.\n"
        f"AnchorFlow is investigating and will reassign if needed.\n"
        f"Your order is protected. No action needed."
    )


def _msg_delivery_delayed(deal, **kw) -> str:
    duration = kw.get("time_in_state_sec")
    dur_str  = fmt_duration(int(duration)) if duration else "over 2 hours"
    return (
        f"⚠️ *Delivery significantly delayed*\n"
        f"Deal #{deal.deal_id} has been in delivery for {dur_str}.\n"
        f"Our team has flagged this for immediate review.\n"
        f"Customer has been notified. We'll update you shortly."
    )


_TEMPLATE_MAP = {
    "payment_confirmed":   _msg_payment_confirmed,
    "courier_assigned":    _msg_courier_assigned,
    "courier_delayed":     _msg_courier_delayed,
    "delivery_completed":  _msg_delivery_completed,
    "awaiting_courier":    _msg_awaiting_courier,
    "courier_stalled":     _msg_courier_stalled,
    "delivery_delayed":    _msg_delivery_delayed,
}


# ── Atomic dedup ──────────────────────────────────────────────────────────────

def _atomic_dedup(deal_id: str, event_type: str) -> bool:
    """
    Attempt to claim the dedup slot for this (deal_id, event_type) pair.

    Uses Redis SET … NX EX (atomic) so only one process/thread wins per
    24-hour window.

    Returns:
        True  — slot acquired → notification should be sent
        False — slot already claimed → notification is a duplicate, skip it
        True  — Redis unavailable → allow send (fail-open), log warning
    """
    key = f"notify_sent:{deal_id}:{event_type}"
    try:
        from app.routers.whatsapp_bot import _redis
        result = _redis.set(key, "1", nx=True, ex=_NOTIFY_DEDUP_TTL)
        if result is None:
            # NX failed → key already exists → duplicate
            logger.debug("notifications: dedup block deal=%s event=%s", deal_id, event_type)
            return False
        return True
    except Exception as exc:
        logger.warning(
            "notifications: Redis dedup unavailable — sending without guard "
            "deal=%s event=%s err=%s",
            deal_id, event_type, exc,
        )
        return True   # fail-open: send rather than silently drop


# ── Twilio helper ─────────────────────────────────────────────────────────────

def _get_twilio():
    try:
        from app.config import load_settings
        from app.adapters.twilio_adapter import TwilioAdapter
        s     = load_settings()
        sid   = getattr(s, "twilio_account_sid",  None)
        tok   = getattr(s, "twilio_auth_token",   None)
        from_n = getattr(s, "twilio_from_number", None)
        if not all([sid, tok, from_n]):
            return None
        return TwilioAdapter(account_sid=sid, auth_token=tok, from_number=from_n)
    except Exception as exc:
        logger.debug("notifications: twilio unavailable: %s", exc)
        return None


def _load_deal(deal_id: str, db: Session):
    try:
        from app.models.database import Deal
        return db.query(Deal).filter(Deal.deal_id == deal_id).first()
    except Exception:
        return None


# ── Public: notify_merchant ───────────────────────────────────────────────────

def notify_merchant(
    event_type:  str,
    deal_id:     str,
    db:          Session,
    **extra,
) -> bool:
    """
    Send a contextual WhatsApp notification to a merchant.

    Idempotent via atomic Redis SET NX EX — safe to call multiple times for
    the same (deal_id, event_type) pair.

    Args:
        event_type: One of the keys in _TEMPLATE_MAP
        deal_id:    Deal.deal_id (not DB id)
        db:         SQLAlchemy session
        **extra:    Additional context injected into the message template
                    (e.g. time_in_state_sec=8040)

    Returns:
        True if message was sent or legitimately skipped (duplicate).
        False on unrecoverable error.
    """
    try:
        # ── Dedup guard (atomic) ──────────────────────────────────────────────
        if not _atomic_dedup(deal_id, event_type):
            return True   # Duplicate; idempotent success

        # ── Load deal ─────────────────────────────────────────────────────────
        deal = _load_deal(deal_id, db)
        if not deal:
            logger.warning("notifications: deal not found deal=%s", deal_id)
            return False

        merchant_phone = getattr(deal, "seller_phone", None)
        if not merchant_phone:
            logger.debug("notifications: no seller_phone on deal=%s", deal_id)
            return False

        # ── Render contextual message ─────────────────────────────────────────
        template_fn = _TEMPLATE_MAP.get(event_type)
        if not template_fn:
            logger.warning("notifications: unknown event_type=%s deal=%s", event_type, deal_id)
            return False

        body = template_fn(deal, **extra)

        # ── Send ──────────────────────────────────────────────────────────────
        twilio = _get_twilio()
        if not twilio:
            logger.debug("notifications: twilio not configured, skip deal=%s", deal_id)
            return False

        sent = twilio.send_message(merchant_phone, body)
        if sent:
            logger.info(
                "notifications: sent merchant_hash=%d deal=%s event=%s",
                hash(merchant_phone) % 100_000, deal_id, event_type,
            )
        else:
            logger.warning(
                "notifications: send failed merchant_hash=%d deal=%s event=%s",
                hash(merchant_phone) % 100_000, deal_id, event_type,
            )
        return sent

    except Exception as exc:
        logger.error("notifications: unexpected error deal=%s event=%s: %s",
                     deal_id, event_type, exc)
        return False


# ── Public: notify_merchant_event (event bus handler) ────────────────────────

def notify_merchant_event(event_name: str, payload: dict) -> None:
    """
    Event bus handler — signature matches register_handler() contract.

    Bridges the event bus to notify_merchant().  Register once at startup:

        from app.core.event_bus import register_handler
        from app.merchant_portal.notifications import notify_merchant_event

        register_handler("delivery_delayed",  notify_merchant_event)
        register_handler("courier_stalled",   notify_merchant_event)
        register_handler("awaiting_courier",  notify_merchant_event)
        register_handler("payment_confirmed", notify_merchant_event)
        register_handler("courier_assigned",  notify_merchant_event)
        register_handler("delivery_completed", notify_merchant_event)

    Payload must contain at minimum: deal_id, (db is fetched from payload if
    present, otherwise a fresh session is opened).
    """
    deal_id = payload.get("deal_id")
    if not deal_id:
        logger.warning("notify_merchant_event: missing deal_id in payload for %s", event_name)
        return

    # db may be injected in the payload (preferred) or opened fresh
    db = payload.get("db")
    _own_db = False
    if db is None:
        try:
            from app.routers.deals import _SessionLocal
            db = _SessionLocal()
            _own_db = True
        except Exception as exc:
            logger.error("notify_merchant_event: cannot open DB session: %s", exc)
            return

    try:
        extra = {k: v for k, v in payload.items() if k not in ("deal_id", "db")}
        notify_merchant(event_name, deal_id, db, **extra)
    finally:
        if _own_db:
            try:
                db.close()
            except Exception:
                pass


# ── Bulk helper ───────────────────────────────────────────────────────────────

def notify_merchant_bulk(events: list, db: Session) -> dict:
    """Send multiple notifications. events: [(event_type, deal_id, **extra)] tuples."""
    results = {}
    for item in events:
        event_type, deal_id = item[0], item[1]
        extra = item[2] if len(item) > 2 else {}
        ok = notify_merchant(event_type, deal_id, db, **extra)
        results.setdefault(deal_id, {})[event_type] = ok
    return results
