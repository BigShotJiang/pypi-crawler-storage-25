# app/merchant_portal/schemas.py
"""
Pydantic response models for Merchant Dashboard V2.

Changes from V1:
  - DealSummary:   +recovery_flag, +time_in_state_sec
  - DealDetail:    +time_in_state_sec, +time_since_payment_sec,
                   +courier_assignment_latency_sec
  - CourierStatus: +last_update, +eta_minutes
  - New: AnalyticsSummary
  - New: KeysetCursor (keyset pagination prep — currently advisory only)

All phone numbers are masked before reaching these schemas.
No raw PII is ever serialised into API responses.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ── Escrow timeline event ─────────────────────────────────────────────────────

class EscrowEvent(BaseModel):
    """One row from EscrowStateLog — drives the timeline view."""
    id:              int
    previous_status: str
    new_status:      str
    triggered_by:    str
    created_at:      datetime
    metadata:        Dict[str, Any] = Field(default_factory=dict)


# ── Courier status snapshot ───────────────────────────────────────────────────

class CourierStatus(BaseModel):
    """
    Live courier status — read from Redis bot state keys.
    Absent when Redis is unavailable or no courier assigned yet.
    """
    phone_masked:  str
    state:         str                  # COURIER_ASSIGNED | DELIVERY_IN_PROGRESS | …
    deal_id:       str
    age_minutes:   Optional[int] = None # Minutes in current state
    last_update:   Optional[datetime] = None  # Wall-clock of last state transition
    eta_minutes:   Optional[int] = None # Estimated minutes to delivery (heuristic)


# ── Deal list row ─────────────────────────────────────────────────────────────

class DealSummary(BaseModel):
    """
    Lightweight deal row for the paginated dashboard table.

    badge_color and recovery_flag are pre-computed so the template performs
    zero business logic.
    """
    deal_id:            str
    status:             str
    amount:             float
    currency:           str = "USD"
    customer:           str             # Masked: "077****123"
    created_at:         datetime
    updated_at:         Optional[datetime] = None
    courier_status:     Optional[str] = None    # state string from Redis
    badge_color:        str                     # green | yellow | orange | red
    recovery_active:    bool = False
    recovery_reason:    Optional[str] = None
    # New V2 fields
    recovery_flag:      Optional[str] = None    # SQL-layer flag (may differ from reason)
    time_in_state_sec:  Optional[int] = None    # Seconds since last status change


# ── Deal detail ───────────────────────────────────────────────────────────────

class DealDetail(BaseModel):
    """
    Full deal record for the detail view, including escrow timeline
    and optional live courier status.
    """
    deal_id:               str
    status:                str
    amount:                float
    currency:              str = "USD"
    customer:              str           # Masked
    seller_name:           str
    item_description:      str
    quantity:              int
    merchant_acknowledged: bool
    created_at:            datetime
    updated_at:            Optional[datetime] = None
    expires_at:            Optional[datetime] = None

    # Escrow detail
    escrow_status:         Optional[str] = None
    reversal_reason:       Optional[str] = None

    # Courier (live, best-effort Redis)
    courier:               Optional[CourierStatus] = None

    # Audit timeline (oldest → newest)
    escrow_history:        List[EscrowEvent] = Field(default_factory=list)

    # Recovery
    recovery_active:       bool = False
    recovery_reason:       Optional[str] = None
    recovery_next_action:  Optional[str] = None
    recovery_flag:         Optional[str] = None   # SQL-derived

    # Merchant readiness
    ready_for_pickup:      bool = False

    # Badge
    badge_color:           str = "yellow"

    # Derived timing metrics (V2)
    time_in_state_sec:              Optional[int] = None
    time_since_payment_sec:         Optional[int] = None
    courier_assignment_latency_sec: Optional[int] = None


# ── Paginated list wrapper ────────────────────────────────────────────────────

class PaginatedDeals(BaseModel):
    deals:       List[DealSummary]
    total:       int
    page:        int
    page_size:   int
    total_pages: int
    has_next:    bool
    # Keyset cursor (V2 — optional, None when not applicable)
    next_cursor_ts: Optional[str] = None    # ISO8601 of last row created_at
    next_cursor_id: Optional[int] = None    # DB id of last row


# ── Analytics ─────────────────────────────────────────────────────────────────

class AnalyticsSummary(BaseModel):
    """
    Lightweight analytics for the last 24 hours, filtered by merchant.

    All values computed with indexed SQL queries (seller_phone + created_at).
    """
    window_hours:          int = 24
    today_orders:          int     # Deals created in window
    completed_orders:      int     # Deals in COMPLETED status
    avg_delivery_time_sec: Optional[float] = None  # created_at → completed_at
    failure_rate:          float = 0.0  # (expired + cancelled) / total
    active_deals:          int = 0     # held + courier_assigned + delivery_in_progress
    pending_payment:       int = 0     # created (no payment yet)
    generated_at:          datetime    # Server time of computation


# ── Action responses ──────────────────────────────────────────────────────────

class ReadyForPickupResponse(BaseModel):
    deal_id: str
    success: bool
    message: str


class MerchantContext(BaseModel):
    """Resolved merchant identity (from auth layer, never client-provided)."""
    phone:         str
    name:          str
    merchant_slug: Optional[str] = None
    status:        str
