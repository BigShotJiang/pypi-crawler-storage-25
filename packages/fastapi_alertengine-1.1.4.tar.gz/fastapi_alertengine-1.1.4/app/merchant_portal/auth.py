# app/merchant_portal/auth.py
"""
Merchant Dashboard — request-context identity extraction.

V2 Authentication contract
──────────────────────────
Merchants authenticate using:

    Authorization: Bearer <token>

<token> is a 64-character hex session token (256 bits, secrets.token_hex(32)).
It is issued once by the WhatsApp bot after verifying merchant identity and
sent back to the merchant via WhatsApp DM.

Session storage (V2 — structured JSON):
────────────────────────────────────────
    Redis key:  merchant_session:{token}
    Value:      JSON {"merchant_phone": "...", "issued_at": <unix_ts_float>}
    TTL:        24h (sliding — reset on every successful API call)

V1 backward compatibility:
    Sessions stored as a plain phone string (not JSON) are accepted and
    automatically upgraded to the V2 format on first use.

Validation chain:
    1. Extract Bearer token from Authorization header
    2. Lookup Redis → parse JSON payload → extract merchant_phone
    3. Enforce issued_at < 24h (guards against Redis TTL-bypass edge cases)
    4. Validate merchant record in PostgreSQL (account exists and not suspended)

Production upgrade path:
    Replace the Redis lookup with a verified JWT (RS256).  The `sub` claim
    becomes merchant_phone.  The FastAPI Depends signature is unchanged.
"""

import json
import logging
import secrets
import time
from typing import Optional

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────

_SESSION_TTL_S   = 86_400       # 24 h sliding window
_MAX_SESSION_AGE = 86_400.0     # Hard reject if issued_at older than this


# ─── DB dependency ────────────────────────────────────────────────────────────

def _get_db_session() -> Session:
    """
    Lazily import the shared SQLAlchemy session factory from deals router to
    avoid creating a second connection pool.  Falls back to building its own
    session on ImportError (test environments, standalone startup).
    """
    try:
        from app.routers.deals import _SessionLocal
        db = _SessionLocal()
        try:
            yield db
        finally:
            db.close()
    except ImportError:
        from app.config import load_settings
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from app.models.database import Base

        settings = load_settings()
        engine = create_engine(
            settings.database_url,
            connect_args={"check_same_thread": False} if "sqlite" in settings.database_url else {},
        )
        Base.metadata.create_all(engine)
        Session_ = sessionmaker(bind=engine, autocommit=False, autoflush=False)
        db = Session_()
        try:
            yield db
        finally:
            db.close()


# ─── Redis helpers ────────────────────────────────────────────────────────────

def _get_rdb():
    """Return the shared Redis client; raises if unavailable."""
    from app.routers.whatsapp_bot import _redis
    return _redis


def _resolve_token_from_redis(token: str) -> Optional[str]:
    """
    Resolve a session token → merchant_phone.

    Handles both V2 (JSON) and V1 (plain string) session formats.
    On V1 format, silently upgrades to V2 in place.
    Slides the TTL on every successful read.

    Returns merchant_phone, or None if:
      - key missing (expired / never issued)
      - issued_at > _MAX_SESSION_AGE seconds ago
      - any Redis error
    """
    try:
        rdb  = _get_rdb()
        key  = f"merchant_session:{token}"
        raw  = rdb.get(key)
        if not raw:
            return None

        text = raw.decode() if isinstance(raw, bytes) else raw

        # ── V2: structured JSON ───────────────────────────────────────────────
        if text.startswith("{"):
            try:
                payload      = json.loads(text)
                merchant_phone = payload.get("merchant_phone", "")
                issued_at    = float(payload.get("issued_at", 0))
            except (json.JSONDecodeError, TypeError, ValueError):
                logger.warning("auth: corrupt session payload for token prefix=%s…", token[:8])
                return None

            # Hard-enforce age even if TTL somehow didn't fire
            if time.time() - issued_at > _MAX_SESSION_AGE:
                logger.info("auth: session too old, rejecting token prefix=%s…", token[:8])
                rdb.delete(key)
                return None

        else:
            # ── V1: plain phone string — upgrade in place ─────────────────────
            merchant_phone = text.strip()
            if not merchant_phone:
                return None
            _store_session(rdb, key, merchant_phone)   # upgrade to V2

        if not merchant_phone:
            return None

        # Slide TTL
        rdb.expire(key, _SESSION_TTL_S)
        return merchant_phone

    except Exception as exc:
        logger.debug("auth: redis token resolution failed: %s", exc)
        return None


def _store_session(rdb, key: str, merchant_phone: str) -> None:
    """Write or refresh a V2 structured session into Redis."""
    payload = json.dumps({
        "merchant_phone": merchant_phone,
        "issued_at":      time.time(),
    })
    rdb.setex(key, _SESSION_TTL_S, payload)


# ─── FastAPI dependency ───────────────────────────────────────────────────────

def get_merchant_context(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(_get_db_session),
):
    """
    FastAPI dependency: resolve and validate merchant identity from Bearer token.

    Returns a validated SQLAlchemy Merchant ORM object.
    merchant_phone is NEVER read from the client request body or query params.

    Raises:
        401 — missing/invalid/expired token
        403 — suspended account
    """
    from app.models.database import Merchant

    # ── 1. Extract Bearer token ───────────────────────────────────────────────
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or malformed Authorization header. Use: Bearer <token>",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = authorization.removeprefix("Bearer ").strip()
    if not token or len(token) < 16:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token format",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # ── 2. Token → merchant_phone ─────────────────────────────────────────────
    merchant_phone = _resolve_token_from_redis(token)
    if not merchant_phone:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session expired or invalid. Re-authenticate via WhatsApp.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # ── 3. Validate against PostgreSQL ────────────────────────────────────────
    merchant = db.query(Merchant).filter(
        Merchant.phone == merchant_phone
    ).first()

    if not merchant:
        logger.warning(
            "auth: token resolved to unknown merchant phone_hash=%s",
            hash(merchant_phone) % 100_000,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Merchant account not found",
        )

    # ── 4. Account status guard ───────────────────────────────────────────────
    if getattr(merchant, "status", "") == "suspended":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Merchant account is suspended. Contact support.",
        )

    return merchant


# ─── Session issuance (called by WhatsApp bot login flow) ────────────────────

def issue_merchant_session(merchant_phone: str) -> str:
    """
    Issue a V2 structured session token for a merchant.

    Generates a 64-char hex token, stores a JSON payload with issued_at
    timestamp in Redis under merchant_session:{token}, and returns the token.

    Raises RuntimeError if Redis is unavailable (prevents issuing unusable tokens).
    """
    token = secrets.token_hex(32)   # 256 bits entropy
    try:
        rdb = _get_rdb()
        _store_session(rdb, f"merchant_session:{token}", merchant_phone)
        logger.info(
            "auth: V2 session issued for merchant_hash=%s",
            hash(merchant_phone) % 100_000,
        )
    except Exception as exc:
        logger.error("auth: session issuance failed: %s", exc)
        raise RuntimeError("Session storage unavailable") from exc
    return token


# ─── Admin: revoke session ────────────────────────────────────────────────────

def revoke_merchant_session(token: str) -> bool:
    """
    Explicitly revoke a session token (logout).
    Safe to call with an already-expired token — returns False rather than raising.
    """
    try:
        rdb = _get_rdb()
        deleted = rdb.delete(f"merchant_session:{token}")
        return bool(deleted)
    except Exception as exc:
        logger.debug("auth: revoke failed: %s", exc)
        return False
