# app/merchant_portal/health.py
"""
Merchant Health Scoring — GET /dashboard/api/health

Produces a single 0–100 health score for a merchant based on three weighted
factors computed from the last 24 hours of PostgreSQL data.

Score formula
─────────────
    health_score = (
        success_rate  * 50   +   # 50% weight: % deals completed
        delivery_norm * 30   +   # 30% weight: inverse of avg delivery time
        delay_norm    * 20       # 20% weight: inverse of delay ratio
    )

Where:
    success_rate   = completed_24h / total_24h          (0–1)
    delivery_norm  = max(0, 1 − avg_delivery_sec / BENCHMARK_SEC)
                       BENCHMARK_SEC = 3600 (1 h)
                       Score 1.0 when avg < 1h; 0.0 when avg ≥ 1h
    delay_norm     = 1 − clamp(delay_ratio, 0, 1)

    delay_ratio    = (stuck_deals + expired) / total_24h

Design
──────
- PostgreSQL-only (no Redis dependency for the score itself)
- stuck_deals count from run_stuck_scan() filtered to this merchant
- Gracefully handles zero-deal case (returns health_score = 100 with no data)
- Never raises — returns a safe default score on any DB error

Response shape
──────────────
{
    "success_rate": 0.94,
    "avg_delivery_time_sec": 1800.0,
    "delay_ratio": 0.12,
    "stuck_deals": 2,
    "health_score": 87,
    "health_label": "good",
    "total_deals_24h": 16,
    "generated_at": "2026-03-30T14:00:00Z"
}
"""

import logging
from datetime import datetime, UTC, timedelta
from typing import Optional

from pydantic import BaseModel
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

# ── Score calibration ─────────────────────────────────────────────────────────
_BENCHMARK_DELIVERY_SEC = 3_600   # 1 hour — perfect score if avg ≤ this
_WINDOW_H               = 24


# ── Response schema ───────────────────────────────────────────────────────────

class MerchantHealthScore(BaseModel):
    success_rate:          float           # 0.0–1.0
    avg_delivery_time_sec: Optional[float] # None if no completed deals
    delay_ratio:           float           # 0.0–1.0
    stuck_deals:           int
    health_score:          int             # 0–100
    health_label:          str             # "good" | "fair" | "poor"
    total_deals_24h:       int
    generated_at:          datetime


# ── Health label ──────────────────────────────────────────────────────────────

def _label(score: int) -> str:
    if score >= 80:
        return "good"
    if score >= 60:
        return "fair"
    return "poor"


# ── Core computation ──────────────────────────────────────────────────────────

def compute_health_score(
    db:             Session,
    merchant_phone: str,
) -> MerchantHealthScore:
    """
    Compute and return a MerchantHealthScore for the given merchant.

    All queries are scoped to the last 24 hours and filtered by seller_phone
    (indexed column).  Never raises — returns a 100-point safe default on any
    unrecoverable error so the dashboard always has a value to display.
    """
    from app.models.database import Deal, DealStatus
    from app.recovery.stuck_detector import run_stuck_scan

    now   = datetime.now(UTC)
    since = now - timedelta(hours=_WINDOW_H)

    try:
        base_q = (
            db.query(Deal)
            .filter(
                Deal.seller_phone == merchant_phone,
                Deal.created_at   >= since,
            )
        )

        total       = base_q.count()
        completed   = base_q.filter(Deal.status == DealStatus.COMPLETED).count()
        expired     = base_q.filter(Deal.status == DealStatus.EXPIRED).count()
        cancelled   = base_q.filter(Deal.status == DealStatus.CANCELLED).count()

        # ── success_rate ──────────────────────────────────────────────────────
        if total == 0:
            # No deals in window → perfect score by default (no evidence of failure)
            return MerchantHealthScore(
                success_rate=1.0,
                avg_delivery_time_sec=None,
                delay_ratio=0.0,
                stuck_deals=0,
                health_score=100,
                health_label="good",
                total_deals_24h=0,
                generated_at=now,
            )

        success_rate = completed / total

        # ── avg delivery time ────────────────────────────────────────────────
        avg_delivery_sec: Optional[float] = None
        try:
            completed_rows = (
                base_q.filter(
                    Deal.status       == DealStatus.COMPLETED,
                    Deal.completed_at.isnot(None),
                )
                .with_entities(Deal.created_at, Deal.completed_at)
                .all()
            )
            if completed_rows:
                deltas = []
                for row in completed_rows:
                    ca = row.created_at if row.created_at.tzinfo else row.created_at.replace(tzinfo=UTC)
                    co = row.completed_at if row.completed_at.tzinfo else row.completed_at.replace(tzinfo=UTC)
                    deltas.append((co - ca).total_seconds())
                avg_delivery_sec = sum(deltas) / len(deltas)
        except Exception as exc:
            logger.debug("health: avg_delivery query failed: %s", exc)

        # ── stuck deals (scoped to this merchant) ────────────────────────────
        stuck_list = run_stuck_scan(db, merchant_phone=merchant_phone)
        stuck_count = len(stuck_list)

        # ── delay_ratio ───────────────────────────────────────────────────────
        # Delayed = expired + cancelled + currently stuck
        delay_ratio = min(1.0, (expired + cancelled + stuck_count) / total)

        # ── score components ──────────────────────────────────────────────────

        # 50% — success rate component (direct linear scale)
        success_component = success_rate * 50

        # 30% — delivery time component (inverse, benchmarked at 1h)
        if avg_delivery_sec is not None:
            delivery_norm = max(0.0, 1.0 - avg_delivery_sec / _BENCHMARK_DELIVERY_SEC)
        else:
            delivery_norm = 1.0   # No completed deals → no penalty
        delivery_component = delivery_norm * 30

        # 20% — delay component (inverse delay ratio)
        delay_component = (1.0 - delay_ratio) * 20

        raw_score    = success_component + delivery_component + delay_component
        health_score = max(0, min(100, round(raw_score)))

        logger.info(
            "health: merchant_hash=%d score=%d (success=%.2f delivery_norm=%.2f delay_norm=%.2f) "
            "total=%d stuck=%d",
            hash(merchant_phone) % 100_000,
            health_score, success_rate, delivery_norm, 1.0 - delay_ratio,
            total, stuck_count,
        )

        return MerchantHealthScore(
            success_rate=round(success_rate, 4),
            avg_delivery_time_sec=round(avg_delivery_sec, 1) if avg_delivery_sec is not None else None,
            delay_ratio=round(delay_ratio, 4),
            stuck_deals=stuck_count,
            health_score=health_score,
            health_label=_label(health_score),
            total_deals_24h=total,
            generated_at=now,
        )

    except Exception as exc:
        logger.error("health: compute failed for merchant_hash=%d: %s",
                     hash(merchant_phone) % 100_000, exc)
        # Safe default — avoids a 500 on the dashboard
        return MerchantHealthScore(
            success_rate=0.0,
            avg_delivery_time_sec=None,
            delay_ratio=0.0,
            stuck_deals=0,
            health_score=0,
            health_label="poor",
            total_deals_24h=0,
            generated_at=now,
        )
