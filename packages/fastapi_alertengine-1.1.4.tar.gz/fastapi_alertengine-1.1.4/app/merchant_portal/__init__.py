# app/merchant_portal/__init__.py
"""
Merchant Dashboard V1

Authenticated merchant-facing dashboard for deal management.
Provides read-only deal visibility + a single READY_FOR_PICKUP write action.

Package layout:
    auth.py     — request-context merchant identity extraction (never client-provided)
    schemas.py  — Pydantic response models
    service.py  — PostgreSQL-authoritative data layer; Redis for optional courier status
    routes.py   — FastAPI router (prefix: /dashboard)
    templates/  — Jinja2 HTML (dashboard.html, deal_detail.html)
"""
