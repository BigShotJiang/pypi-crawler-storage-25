# ⚡ fastapi-alertengine

Drop-in request monitoring + alerting for FastAPI — in under 60 seconds.

No Prometheus. No Grafana. No dashboards.

Just install → add middleware → get real-time alerts.

---

## 🚀 Quick Start

```python
from fastapi import FastAPI
from fastapi_alertengine import RequestMetricsMiddleware, get_alert_engine
import redis

app = FastAPI()

redis_client = redis.Redis.from_url("redis://localhost:6379/0")

app.add_middleware(RequestMetricsMiddleware, redis=redis_client)
```

---

## ⚡ Live Alerts Endpoint

Expose real-time system health:

```python
alert_engine = get_alert_engine(redis_client=redis_client)

@app.get("/health/alerts")
def alerts():
    return alert_engine.evaluate(window_size=200)
```

---

## 📊 Example Output

```json
{
  "status": "ok | warning | critical",
  "metrics": {
    "overall_p95_ms": 123.4,
    "webhook_p95_ms": 234.5,
    "api_p95_ms": 110.2,
    "error_rate": 0.03,
    "anomaly_score": 0.8,
    "sample_size": 187
  }
}
```

---

## ⚡ What You Get Instantly

- 📊 P95 latency (overall, API, webhook)
- 🚨 Error rate detection (failure pressure signal)
- 🧠 Anomaly detection vs baseline
- ⚡ Rolling window analysis (real-time)
- 🔌 Simple JSON health endpoint

---

## 🧠 Why This Exists

Most FastAPI monitoring stacks require:

- Prometheus
- Grafana
- Complex dashboards

That's overkill for most teams.

**fastapi-alertengine** gives you the core signals that actually matter:

- Is the system slowing down?
- Are failures increasing?
- Is something anomalous happening right now?

---

## 🏦 Financial-Grade Design

This system is derived from production infrastructure used in AnchorFlow.

Designed for:

- High-reliability environments
- Payment orchestration systems
- Audit-friendly monitoring outputs

Key characteristics:

- Deterministic P95 calculation
- Failure pressure signal (error rate)
- Structured JSON output for downstream systems
- Safe middleware (never breaks request flow)

---

## ⚙️ Default Thresholds

- P95 Warning: 1000ms
- P95 Critical: 3000ms
- Error Rate Critical: 20%

---

## 📦 Public API

```python
AlertEngine
RequestMetricsMiddleware
get_alert_engine
```

---

## 🤖 AI-Agent Friendly

Designed for:

- Claude Code
- GitHub Copilot
- Cursor

Agents can integrate it automatically in seconds.

---

## 💼 Production Setup (Starter Pack — $49)

Includes:

- Redis + FastAPI deployment setup
- Alert tuning for real workloads
- Scaling patterns
- Direct support

📩 Contact: advovowabantuevents@gmail.com

---

## 🧱 Roadmap

- Slack / email alerting
- Remote alert engine (SaaS)
- Multi-service correlation
- Lightweight dashboard

---

## 📜 Requirements

- Python 3.10+
- FastAPI
- Redis
