"""
Tofamba API — application entry point.

Run locally:
    uvicorn main:app --reload --port 8000

Railway deployment:
    See railway.yaml for the start command.
"""

import io
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from fastapi.templating import Jinja2Templates

from app.routers import deals, inventory
from app.routers.whatsapp_bot import router as whatsapp_router, _redis as _bot_redis
from app.merchant_portal.routes import router as dashboard_router
from app.routers.alert_router import router as alert_router
from app.middleware.request_metrics import RequestMetricsMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    from alembic.config import Config
    from alembic import command
    try:
        alembic_cfg = Config("alembic.ini")
        command.upgrade(alembic_cfg, "head")
        print("Alembic migrations: up to date")
    except Exception as e:
        print(f"Alembic migration warning: {e}")
    yield


app = FastAPI(
    title="Tofamba API",
    description=(
        "Trust-as-an-API escrow platform for Zimbabwean commerce. "
        "Paid. Delivered. Done."
    ),
    version="2.0.0",
    lifespan=lifespan,
)

# Request latency metrics — writes to Redis Stream anchorflow:request_metrics
# Must be added BEFORE CORSMiddleware so it wraps the full request.
app.add_middleware(RequestMetricsMiddleware, redis=_bot_redis)

# Allow WhatsApp in-app browser (and local dev) to reach the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(deals.router)
app.include_router(inventory.router)
app.include_router(whatsapp_router)
app.include_router(dashboard_router)
app.include_router(alert_router)

# ── Merchant dashboard (self-contained client-side SPA) ───────────────────────
_templates = Jinja2Templates(directory="app/templates")


@app.get("/dashboard", include_in_schema=False)
async def merchant_dashboard_page(request: Request):
    """
    Serve the self-contained merchant dashboard HTML page.

    Authentication is handled entirely client-side: the page reads a Bearer
    token from localStorage (key: tofamba_token) or a ?token= URL param and
    sends it as Authorization: Bearer <token> on all /dashboard/api/* calls.
    No server-side auth is required to load this page.
    """
    return _templates.TemplateResponse("merchant_dashboard.html", {"request": request})


# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["meta"])
def health():
    return {"status": "healthy", "service": "Tofamba API", "version": "2.0.0"}


# ── Merchant store QR code ────────────────────────────────────────────────────
@app.get("/m/{slug}/qr.png", tags=["merchant-store"])
def merchant_qr_code(slug: str):
    """
    Generate and return a QR code PNG for the merchant's store entry link.
    Used by the WhatsApp bot BRAND_COMPLETE message and merchant dashboard.

    Example:
        GET /m/joes-compumart-a3f9b2/qr.png
    """
    try:
        import qrcode
        from app.config import settings

        store_url = f"{settings.base_url}/m/{slug}"
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=8,
            border=4,
        )
        qr.add_data(store_url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return Response(content=buf.read(), media_type="image/png")

    except ImportError:
        raise HTTPException(
            status_code=503,
            detail="QR code generation requires 'qrcode[pil]' package.",
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/m/{slug}", tags=["merchant-store"])
def merchant_store(slug: str):
    """
    Merchant storefront entry point.
    Returns basic store info — frontend SPA handles the full UI.
    """
    from app.db import get_db
    from app.models.database import Merchant

    db = next(get_db())
    try:
        merchant = db.query(Merchant).filter(Merchant.slug == slug).first()
        if not merchant:
            raise HTTPException(status_code=404, detail="Store not found")
        return {
            "store_name": merchant.name,
            "slug": merchant.slug,
            "qr_url": f"/m/{slug}/qr.png",
        }
    finally:
        db.close()
