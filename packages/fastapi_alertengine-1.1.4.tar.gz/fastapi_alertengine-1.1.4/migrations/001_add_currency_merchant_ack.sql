-- =============================================================================
-- Migration 001: Currency codes, merchant acknowledgement, new indexes
-- AnchorFlow / Tandem Hive — apply against PostgreSQL on Railway
--
-- Safe-defaults for ALL existing records:
--   currency_code        → 'USD'  (all existing deals/escrows are USD)
--   merchant_acknowledged→ FALSE  (conservative; existing deals are grandfathered)
--   merchants.status     → 'pending_verification' if null (already exists in model)
--
-- All ALTER TABLE statements use IF NOT EXISTS / IF EXISTS guards so this
-- script is idempotent — safe to re-run.
-- =============================================================================

BEGIN;

-- -----------------------------------------------------------------------------
-- 1. merchants — status column
--    The SQLAlchemy model already defines this with default='pending_verification'.
--    Guard here in case the column was never created on an older DB snapshot.
-- -----------------------------------------------------------------------------

ALTER TABLE merchants
    ADD COLUMN IF NOT EXISTS status VARCHAR(50) NOT NULL DEFAULT 'pending_verification';

-- Back-fill any NULLs introduced before the NOT NULL constraint was added
UPDATE merchants SET status = 'pending_verification' WHERE status IS NULL;


-- -----------------------------------------------------------------------------
-- 2. deals — currency_code
-- -----------------------------------------------------------------------------

ALTER TABLE deals
    ADD COLUMN IF NOT EXISTS currency_code VARCHAR(5) NOT NULL DEFAULT 'USD';

UPDATE deals SET currency_code = 'USD' WHERE currency_code IS NULL;


-- -----------------------------------------------------------------------------
-- 3. deals — merchant_acknowledged
-- -----------------------------------------------------------------------------

ALTER TABLE deals
    ADD COLUMN IF NOT EXISTS merchant_acknowledged BOOLEAN NOT NULL DEFAULT FALSE;

UPDATE deals SET merchant_acknowledged = FALSE WHERE merchant_acknowledged IS NULL;


-- -----------------------------------------------------------------------------
-- 4. escrows — currency_code
-- -----------------------------------------------------------------------------

ALTER TABLE escrows
    ADD COLUMN IF NOT EXISTS currency_code VARCHAR(5) NOT NULL DEFAULT 'USD';

UPDATE escrows SET currency_code = 'USD' WHERE currency_code IS NULL;


-- -----------------------------------------------------------------------------
-- 5. Indexes
-- -----------------------------------------------------------------------------

-- Named status index on deals (supplements the auto-created ix_deals_status)
CREATE INDEX IF NOT EXISTS idx_deals_status
    ON deals (status);

-- Seller-phone index supports inventory lookups and WhatsApp bot queries
CREATE INDEX IF NOT EXISTS idx_deals_seller_phone
    ON deals (seller_phone);

-- Composite index for EscrowTimeoutEngine's expiry sweep
-- (status, expiry_timestamp) — covers the WHERE status='held' AND expiry_timestamp<=now
CREATE INDEX IF NOT EXISTS idx_escrows_expiry
    ON escrows (status, expiry_timestamp);


COMMIT;

-- =============================================================================
-- Rollback (copy-paste manually if needed — run outside a transaction)
-- =============================================================================
-- ALTER TABLE merchants  DROP COLUMN IF EXISTS status;
-- ALTER TABLE deals      DROP COLUMN IF EXISTS currency_code;
-- ALTER TABLE deals      DROP COLUMN IF EXISTS merchant_acknowledged;
-- ALTER TABLE escrows    DROP COLUMN IF EXISTS currency_code;
-- DROP INDEX IF EXISTS idx_deals_status;
-- DROP INDEX IF EXISTS idx_deals_seller_phone;
-- DROP INDEX IF EXISTS idx_escrows_expiry;
