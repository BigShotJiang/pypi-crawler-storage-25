"""Add currency_code, merchant_acknowledged columns and named performance indexes.

Changes
-------
escrows
  + currency_code VARCHAR(5)  NOT NULL DEFAULT 'USD'
  + Index("idx_escrows_expiry", status, expiry_timestamp)   — composite for timeout sweep

deals
  + currency_code        VARCHAR(5)     NOT NULL DEFAULT 'USD'
  + merchant_acknowledged BOOLEAN       NOT NULL DEFAULT FALSE
  + Index("idx_deals_seller_phone", seller_phone)
  + Index("idx_deals_status", status)   — was unnamed/implicit; now named for referenceability

Production safety
-----------------
All ADD COLUMN statements guard against re-running:
  - The Python upgrade() checks whether the column already exists before
    issuing op.add_column().
  - op.create_index(..., if_not_exists=True) guards each index.

To apply on a Railway instance (after stamping the baseline):
    alembic upgrade 002_currency_merchant_ack

Revision ID: 002_currency_merchant_ack
Revises: 001_baseline
Create Date: 2025-03-11 00:00:01.000000
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "002_currency_merchant_ack"
down_revision: Union[str, None] = "001_baseline"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _column_exists(inspector: sa.Inspector, table: str, column: str) -> bool:
    """Return True if *column* already exists in *table*."""
    return any(
        col["name"] == column
        for col in inspector.get_columns(table)
    )


def _index_exists(inspector: sa.Inspector, table: str, index_name: str) -> bool:
    """Return True if an index named *index_name* exists on *table*."""
    return any(
        idx["name"] == index_name
        for idx in inspector.get_indexes(table)
    )


# ---------------------------------------------------------------------------
# upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """
    Add Task-1 columns and named indexes.

    All operations are idempotent — safe to retry if the migration
    was interrupted midway through.
    """
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    # ── escrows: currency_code ────────────────────────────────────────────
    if not _column_exists(inspector, "escrows", "currency_code"):
        op.add_column(
            "escrows",
            sa.Column(
                "currency_code",
                sa.String(length=5),
                nullable=False,
                server_default="USD",
            ),
        )

    # ── escrows: composite index (status, expiry_timestamp) ───────────────
    if not _index_exists(inspector, "escrows", "idx_escrows_expiry"):
        op.create_index(
            "idx_escrows_expiry",
            "escrows",
            ["status", "expiry_timestamp"],
        )

    # ── deals: currency_code ──────────────────────────────────────────────
    if not _column_exists(inspector, "deals", "currency_code"):
        op.add_column(
            "deals",
            sa.Column(
                "currency_code",
                sa.String(length=5),
                nullable=False,
                server_default="USD",
            ),
        )

    # ── deals: merchant_acknowledged ──────────────────────────────────────
    if not _column_exists(inspector, "deals", "merchant_acknowledged"):
        op.add_column(
            "deals",
            sa.Column(
                "merchant_acknowledged",
                sa.Boolean(),
                nullable=False,
                server_default="0",   # FALSE for PostgreSQL/SQLite
            ),
        )

    # ── deals: idx_deals_seller_phone ─────────────────────────────────────
    if not _index_exists(inspector, "deals", "idx_deals_seller_phone"):
        op.create_index(
            "idx_deals_seller_phone",
            "deals",
            ["seller_phone"],
        )

    # ── deals: idx_deals_status (named; column already indexed but unnamed) ─
    if not _index_exists(inspector, "deals", "idx_deals_status"):
        op.create_index(
            "idx_deals_status",
            "deals",
            ["status"],
        )


# ---------------------------------------------------------------------------
# downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """
    Remove Task-1 columns and named indexes.

    Reverting to the baseline schema.
    """
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    # ── Remove indexes first (required before dropping columns) ───────────
    if _index_exists(inspector, "deals", "idx_deals_status"):
        op.drop_index("idx_deals_status", table_name="deals")

    if _index_exists(inspector, "deals", "idx_deals_seller_phone"):
        op.drop_index("idx_deals_seller_phone", table_name="deals")

    if _index_exists(inspector, "escrows", "idx_escrows_expiry"):
        op.drop_index("idx_escrows_expiry", table_name="escrows")

    # ── Remove columns ────────────────────────────────────────────────────
    if _column_exists(inspector, "deals", "merchant_acknowledged"):
        op.drop_column("deals", "merchant_acknowledged")

    if _column_exists(inspector, "deals", "currency_code"):
        op.drop_column("deals", "currency_code")

    if _column_exists(inspector, "escrows", "currency_code"):
        op.drop_column("escrows", "currency_code")
