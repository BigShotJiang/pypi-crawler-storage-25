"""Buyer Flow V1 — bot_sessions table, orders table, widen id_number column.

Changes
-------
merchants
  * id_number  VARCHAR(20) → TEXT   (Fernet ciphertext is ~100 chars)
  * id_photo_url TEXT (already TEXT, no change)
  * selfie_url   TEXT (already TEXT, no change)

bot_sessions (new)
  id            SERIAL PRIMARY KEY
  phone         VARCHAR(20)  UNIQUE NOT NULL
  state         VARCHAR(60)  NOT NULL DEFAULT 'initial'
  last_activity TIMESTAMP WITH TIME ZONE
  created_at    TIMESTAMP WITH TIME ZONE
  updated_at    TIMESTAMP WITH TIME ZONE

orders (new)
  id             VARCHAR(36)   PRIMARY KEY
  merchant_id    INTEGER        FK → merchants(id) ON DELETE SET NULL
  product_id     INTEGER        FK → merchant_inventory(id) ON DELETE SET NULL
  variant_id     VARCHAR(36)    FK → product_variants(id) ON DELETE SET NULL
  quantity       INTEGER        NOT NULL DEFAULT 1
  amount         NUMERIC(12,2)  NOT NULL
  status         VARCHAR(30)    NOT NULL DEFAULT 'PENDING_PAYMENT'
  reference_code VARCHAR(20)    UNIQUE NOT NULL
  buyer_phone    VARCHAR(20)
  created_at     TIMESTAMP WITH TIME ZONE
  updated_at     TIMESTAMP WITH TIME ZONE

Revision ID: 004_buyer_flow_orders
Revises: 003_merchant_onboarding_v2
Create Date: 2025-04-02 00:00:00.000000
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "004_buyer_flow_orders"
down_revision: Union[str, None] = "003_merchant_onboarding_v2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _column_exists(inspector: sa.Inspector, table: str, column: str) -> bool:
    return any(col["name"] == column for col in inspector.get_columns(table))


def _table_exists(inspector: sa.Inspector, table: str) -> bool:
    return table in inspector.get_table_names()


def _index_exists(inspector: sa.Inspector, table: str, name: str) -> bool:
    return any(idx["name"] == name for idx in inspector.get_indexes(table))


# ---------------------------------------------------------------------------
# upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    bind      = op.get_bind()
    inspector = sa.inspect(bind)
    dialect   = bind.dialect.name  # "postgresql" | "sqlite"

    # ── merchants.id_number: VARCHAR(20) → TEXT ───────────────────────────────
    # Fernet ciphertext is ~100–180 chars; VARCHAR(20) is too short.
    # SQLite does not enforce VARCHAR length, so this is a PostgreSQL-only concern.
    if dialect == "postgresql":
        op.alter_column(
            "merchants",
            "id_number",
            type_=sa.Text(),
            existing_type=sa.String(20),
            existing_nullable=True,
        )

    # ── bot_sessions ──────────────────────────────────────────────────────────
    if not _table_exists(inspector, "bot_sessions"):
        op.create_table(
            "bot_sessions",
            sa.Column("id",            sa.Integer(),                   primary_key=True),
            sa.Column("phone",         sa.String(20),  nullable=False),
            sa.Column("state",         sa.String(60),  nullable=False, server_default="initial"),
            sa.Column("last_activity", sa.DateTime(timezone=True), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                server_default=sa.text("CURRENT_TIMESTAMP"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                server_default=sa.text("CURRENT_TIMESTAMP"),
                nullable=False,
            ),
        )
        op.create_index("idx_bot_sessions_phone", "bot_sessions", ["phone"], unique=True)

    # ── orders ────────────────────────────────────────────────────────────────
    if not _table_exists(inspector, "orders"):
        op.create_table(
            "orders",
            sa.Column("id",             sa.String(36),                 primary_key=True),
            sa.Column(
                "merchant_id",
                sa.Integer(),
                sa.ForeignKey("merchants.id", ondelete="SET NULL"),
                nullable=True,
            ),
            sa.Column(
                "product_id",
                sa.Integer(),
                sa.ForeignKey("merchant_inventory.id", ondelete="SET NULL"),
                nullable=True,
            ),
            sa.Column(
                "variant_id",
                sa.String(36),
                sa.ForeignKey("product_variants.id", ondelete="SET NULL"),
                nullable=True,
            ),
            sa.Column("quantity",       sa.Integer(),         nullable=False, server_default="1"),
            sa.Column("amount",         sa.Numeric(12, 2),    nullable=False),
            sa.Column("status",         sa.String(30),        nullable=False,
                      server_default="PENDING_PAYMENT"),
            sa.Column("reference_code", sa.String(20),        nullable=False),
            sa.Column("buyer_phone",    sa.String(20),        nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                server_default=sa.text("CURRENT_TIMESTAMP"),
                nullable=False,
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                server_default=sa.text("CURRENT_TIMESTAMP"),
                nullable=False,
            ),
        )
        op.create_index("idx_orders_merchant_id",    "orders", ["merchant_id"])
        op.create_index("idx_orders_buyer_phone",    "orders", ["buyer_phone"])
        op.create_index("idx_orders_status",         "orders", ["status"])
        op.create_index("idx_orders_created_at",     "orders", ["created_at"])
        op.create_index("idx_orders_reference_code", "orders", ["reference_code"], unique=True)


# ---------------------------------------------------------------------------
# downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    bind      = op.get_bind()
    inspector = sa.inspect(bind)
    dialect   = bind.dialect.name

    if _table_exists(inspector, "orders"):
        op.drop_table("orders")

    if _table_exists(inspector, "bot_sessions"):
        op.drop_table("bot_sessions")

    if dialect == "postgresql":
        op.alter_column(
            "merchants",
            "id_number",
            type_=sa.String(20),
            existing_type=sa.Text(),
            existing_nullable=True,
        )
