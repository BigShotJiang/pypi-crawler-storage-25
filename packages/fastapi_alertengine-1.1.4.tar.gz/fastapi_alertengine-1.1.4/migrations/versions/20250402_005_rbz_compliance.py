"""RBZ compliance — disputes, deal_events, courier_phone, extended DealStatus.

Changes
-------
deals
  * courier_phone  VARCHAR(20)  nullable  — PostgreSQL-backed courier assignment

disputes (new)
  id          SERIAL PRIMARY KEY
  deal_id     VARCHAR(10)  FK → deals.deal_id  ON DELETE CASCADE
  opened_by   VARCHAR(20)  NOT NULL            — "buyer" | "merchant" | "courier"
  reason      TEXT         NOT NULL
  status      VARCHAR(20)  NOT NULL DEFAULT 'OPEN'
  resolution  VARCHAR(20)  nullable            — "RELEASE" | "REFUND"
  created_at  TIMESTAMP WITH TIME ZONE
  resolved_at TIMESTAMP WITH TIME ZONE nullable

deal_events (new — RBZ audit trail)
  id          SERIAL PRIMARY KEY
  deal_id     VARCHAR(10)  FK → deals.deal_id  ON DELETE CASCADE
  event_type  VARCHAR(50)  NOT NULL
  payload     TEXT         nullable            — JSON string
  created_at  TIMESTAMP WITH TIME ZONE

DealStatus enum (PostgreSQL only)
  + in_transit
  + dispute_opened
  + under_review
  + resolved_release
  + resolved_refund

Revision ID: 005_rbz_compliance
Revises: 004_buyer_flow_orders
Create Date: 2025-04-02 12:00:00.000000
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "005_rbz_compliance"
down_revision: Union[str, None] = "004_buyer_flow_orders"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _column_exists(inspector: sa.Inspector, table: str, column: str) -> bool:
    return any(col["name"] == column for col in inspector.get_columns(table))


def _table_exists(inspector: sa.Inspector, table: str) -> bool:
    return table in inspector.get_table_names()


def _index_exists(inspector: sa.Inspector, table: str, name: str) -> bool:
    return any(idx["name"] == name for idx in inspector.get_indexes(table))


# ---------------------------------------------------------------------------
# upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    bind      = op.get_bind()
    inspector = sa.inspect(bind)
    dialect   = bind.dialect.name  # "postgresql" | "sqlite"

    # ── 1. Extend DealStatus enum (PostgreSQL native ENUM) ───────────────────
    # SQLAlchemy creates the PostgreSQL type name as the lowercased class name:
    # DealStatus → "dealstatus"
    # ALTER TYPE ... ADD VALUE IF NOT EXISTS requires PostgreSQL 9.6+
    # (Railway uses 14+, so this is safe).
    # ADD VALUE cannot be run in a transaction on PG < 12, but PG 12+ allows it.
    if dialect == "postgresql":
        new_values = [
            "in_transit",
            "dispute_opened",
            "under_review",
            "resolved_release",
            "resolved_refund",
        ]
        for value in new_values:
            op.execute(
                sa.text(
                    f"ALTER TYPE dealstatus ADD VALUE IF NOT EXISTS :val"
                ).bindparams(val=value)
            )

    # ── 2. Add courier_phone to deals ─────────────────────────────────────────
    if not _column_exists(inspector, "deals", "courier_phone"):
        op.add_column(
            "deals",
            sa.Column("courier_phone", sa.String(20), nullable=True),
        )

    # ── 3. Create disputes table ──────────────────────────────────────────────
    if not _table_exists(inspector, "disputes"):
        op.create_table(
            "disputes",
            sa.Column("id",         sa.Integer(),    primary_key=True),
            sa.Column(
                "deal_id",
                sa.String(10),
                sa.ForeignKey("deals.deal_id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("opened_by",  sa.String(20),   nullable=False),
            sa.Column("reason",     sa.Text(),        nullable=False),
            sa.Column("status",     sa.String(20),   nullable=False, server_default="OPEN"),
            sa.Column("resolution", sa.String(20),   nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                server_default=sa.text("CURRENT_TIMESTAMP"),
                nullable=False,
            ),
            sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        )
        op.create_index("idx_disputes_deal_id", "disputes", ["deal_id"])
        op.create_index("idx_disputes_status",  "disputes", ["status"])

    # ── 4. Create deal_events table ───────────────────────────────────────────
    if not _table_exists(inspector, "deal_events"):
        op.create_table(
            "deal_events",
            sa.Column("id",         sa.Integer(),    primary_key=True),
            sa.Column(
                "deal_id",
                sa.String(10),
                sa.ForeignKey("deals.deal_id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("event_type", sa.String(50),   nullable=False),
            sa.Column("payload",    sa.Text(),        nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                server_default=sa.text("CURRENT_TIMESTAMP"),
                nullable=False,
            ),
        )
        op.create_index("idx_deal_events_deal_id",    "deal_events", ["deal_id"])
        op.create_index("idx_deal_events_event_type", "deal_events", ["event_type"])


# ---------------------------------------------------------------------------
# downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    bind      = op.get_bind()
    inspector = sa.inspect(bind)

    if _table_exists(inspector, "deal_events"):
        op.drop_table("deal_events")

    if _table_exists(inspector, "disputes"):
        op.drop_table("disputes")

    if _column_exists(inspector, "deals", "courier_phone"):
        op.drop_column("deals", "courier_phone")

    # Note: PostgreSQL ENUM values cannot be removed with ALTER TYPE DROP VALUE
    # (not supported). Downgrade leaves the new enum values in place.
    # This is safe — the Python DealStatus enum can be reverted and the DB
    # will simply never write those values.
