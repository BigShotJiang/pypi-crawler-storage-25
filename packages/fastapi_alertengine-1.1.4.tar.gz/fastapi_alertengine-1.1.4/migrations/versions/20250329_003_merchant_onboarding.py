"""Add merchant onboarding columns to merchants table.

Adds four nullable columns to support the self-service merchant
onboarding system introduced in the stoic-mccarthy branch:

    merchant_slug   VARCHAR(100)   — URL-safe unique identifier, e.g. "johns-store-a3f7b2"
    payment_id      VARCHAR(100)   — Paynow/EcoCash/Bank payment reference
    entry_link      VARCHAR(500)   — WhatsApp wa.me deep-link for this merchant
    qr_code_b64     TEXT           — Base64-encoded QR PNG image

Also adds two counters for Part 7 (Merchant Record Extension):
    product_count   INTEGER DEFAULT 0
    order_count     INTEGER DEFAULT 0

All columns are nullable / have server defaults so this migration is
safe to run against a production DB that already has the merchants table
(existing rows get NULL / 0, no data is lost).

Production safety
-----------------
Column additions are idempotent — each ADD COLUMN is wrapped in a check
for the column's existence so re-running this migration is a no-op.

Revision ID: 003_merchant_onboarding
Revises:     002_add_currency_merchant_ack_indexes
Create Date: 2025-03-29
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "003_merchant_onboarding"
down_revision: Union[str, None] = "002_add_currency_merchant_ack_indexes"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _column_exists(bind, table: str, column: str) -> bool:
    inspector = sa.inspect(bind)
    return column in {c["name"] for c in inspector.get_columns(table)}


def _index_exists(bind, index_name: str) -> bool:
    inspector = sa.inspect(bind)
    for table in inspector.get_table_names():
        for idx in inspector.get_indexes(table):
            if idx["name"] == index_name:
                return True
    return False


# ---------------------------------------------------------------------------
# upgrade
# ---------------------------------------------------------------------------

def upgrade() -> None:
    bind = op.get_bind()

    # ── merchant_slug ──────────────────────────────────────────────────────
    if not _column_exists(bind, "merchants", "merchant_slug"):
        op.add_column(
            "merchants",
            sa.Column("merchant_slug", sa.String(100), nullable=True),
        )

    # ── payment_id ─────────────────────────────────────────────────────────
    if not _column_exists(bind, "merchants", "payment_id"):
        op.add_column(
            "merchants",
            sa.Column("payment_id", sa.String(100), nullable=True),
        )

    # ── entry_link ─────────────────────────────────────────────────────────
    if not _column_exists(bind, "merchants", "entry_link"):
        op.add_column(
            "merchants",
            sa.Column("entry_link", sa.String(500), nullable=True),
        )

    # ── qr_code_b64 ────────────────────────────────────────────────────────
    if not _column_exists(bind, "merchants", "qr_code_b64"):
        op.add_column(
            "merchants",
            sa.Column("qr_code_b64", sa.Text, nullable=True),
        )

    # ── product_count ──────────────────────────────────────────────────────
    if not _column_exists(bind, "merchants", "product_count"):
        op.add_column(
            "merchants",
            sa.Column(
                "product_count",
                sa.Integer,
                nullable=False,
                server_default="0",
            ),
        )

    # ── order_count ────────────────────────────────────────────────────────
    if not _column_exists(bind, "merchants", "order_count"):
        op.add_column(
            "merchants",
            sa.Column(
                "order_count",
                sa.Integer,
                nullable=False,
                server_default="0",
            ),
        )

    # ── unique index on merchant_slug ──────────────────────────────────────
    if not _index_exists(bind, "idx_merchants_slug"):
        op.create_index(
            "idx_merchants_slug",
            "merchants",
            ["merchant_slug"],
            unique=True,
        )


# ---------------------------------------------------------------------------
# downgrade
# ---------------------------------------------------------------------------

def downgrade() -> None:
    bind = op.get_bind()

    if _index_exists(bind, "idx_merchants_slug"):
        op.drop_index("idx_merchants_slug", table_name="merchants")

    for col in ("order_count", "product_count", "qr_code_b64",
                "entry_link", "payment_id", "merchant_slug"):
        if _column_exists(bind, "merchants", col):
            op.drop_column("merchants", col)
