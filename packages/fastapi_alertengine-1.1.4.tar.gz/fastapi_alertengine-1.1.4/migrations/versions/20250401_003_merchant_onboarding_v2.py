"""Merchant Onboarding V2 — KYC columns, photo_url, product_variants table.

Changes
-------
merchants
  + legal_name      TEXT
  + id_number       VARCHAR(20)
  + id_photo_url    TEXT
  + selfie_url      TEXT
  + kyc_status      VARCHAR(20)  DEFAULT 'pending'
  + wallet_type     VARCHAR(20)
  + slug            VARCHAR(120) UNIQUE  (generated from business name)

merchant_inventory
  + photo_url       TEXT

product_variants (new table)
  id               VARCHAR(36) PRIMARY KEY
  inventory_id     VARCHAR(36) / INTEGER  FK → merchant_inventory(id)
  variant_label    VARCHAR(100) NOT NULL
  quantity_available INT NOT NULL DEFAULT 0
  quantity_reserved  INT NOT NULL DEFAULT 0
  quantity_fulfilled INT NOT NULL DEFAULT 0
  is_active        BOOLEAN NOT NULL DEFAULT TRUE
  created_at       TIMESTAMP
  updated_at       TIMESTAMP

Production safety
-----------------
All ADD COLUMN / CREATE TABLE are idempotent (check-before-act pattern).

Revision ID: 003_merchant_onboarding_v2
Revises: 002_currency_merchant_ack
Create Date: 2025-04-01 00:00:00.000000
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "003_merchant_onboarding_v2"
down_revision: Union[str, None] = "002_currency_merchant_ack"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _column_exists(inspector: sa.Inspector, table: str, column: str) -> bool:
    return any(col["name"] == column for col in inspector.get_columns(table))


def _table_exists(inspector: sa.Inspector, table: str) -> bool:
    return table in inspector.get_table_names()


def _index_exists(inspector: sa.Inspector, table: str, index_name: str) -> bool:
    return any(idx["name"] == index_name for idx in inspector.get_indexes(table))


# ---------------------------------------------------------------------------
# upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    # ── merchants: KYC & brand columns ───────────────────────────────────────
    new_merchant_cols = [
        ("legal_name",   sa.Text(),         None),
        ("id_number",    sa.String(20),     None),
        ("id_photo_url", sa.Text(),         None),
        ("selfie_url",   sa.Text(),         None),
        ("kyc_status",   sa.String(20),     "pending"),
        ("wallet_type",  sa.String(20),     None),
        ("slug",         sa.String(120),    None),
    ]
    for col_name, col_type, default in new_merchant_cols:
        if not _column_exists(inspector, "merchants", col_name):
            kwargs = {"nullable": True}
            if default is not None:
                kwargs["server_default"] = default
            op.add_column("merchants", sa.Column(col_name, col_type, **kwargs))

    # Unique index on slug (only after column exists)
    if _column_exists(inspector, "merchants", "slug"):
        if not _index_exists(inspector, "merchants", "idx_merchants_slug"):
            op.create_index("idx_merchants_slug", "merchants", ["slug"], unique=True)

    # ── merchant_inventory: photo_url ─────────────────────────────────────────
    if not _column_exists(inspector, "merchant_inventory", "photo_url"):
        op.add_column(
            "merchant_inventory",
            sa.Column("photo_url", sa.Text(), nullable=True),
        )

    # ── product_variants table ────────────────────────────────────────────────
    if not _table_exists(inspector, "product_variants"):
        op.create_table(
            "product_variants",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column(
                "inventory_id",
                sa.Integer(),
                sa.ForeignKey("merchant_inventory.id", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("variant_label", sa.String(100), nullable=False),
            sa.Column("quantity_available", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("quantity_reserved",  sa.Integer(), nullable=False, server_default="0"),
            sa.Column("quantity_fulfilled", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("is_active", sa.Boolean(), nullable=False, server_default="1"),
            sa.Column("created_at", sa.DateTime(), server_default=sa.text("CURRENT_TIMESTAMP")),
            sa.Column("updated_at", sa.DateTime(), server_default=sa.text("CURRENT_TIMESTAMP")),
        )
        op.create_index(
            "idx_product_variants_inventory_id",
            "product_variants",
            ["inventory_id"],
        )


# ---------------------------------------------------------------------------
# downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    # Drop product_variants
    if _table_exists(inspector, "product_variants"):
        op.drop_table("product_variants")

    # Drop merchant_inventory.photo_url
    if _column_exists(inspector, "merchant_inventory", "photo_url"):
        op.drop_column("merchant_inventory", "photo_url")

    # Drop merchant KYC columns
    for col in ("slug", "wallet_type", "kyc_status", "selfie_url",
                 "id_photo_url", "id_number", "legal_name"):
        if _column_exists(inspector, "merchants", col):
            op.drop_column("merchants", col)
