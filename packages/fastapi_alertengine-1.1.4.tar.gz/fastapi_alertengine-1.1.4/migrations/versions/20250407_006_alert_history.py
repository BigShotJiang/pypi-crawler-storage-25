"""Add alert_history table for AlertEngine persistence.

Revision ID: 006_alert_history
Revises: 005_rbz_compliance
Create Date: 2025-04-07 10:00:00.000000
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "006_alert_history"
down_revision: Union[str, None] = "005_rbz_compliance"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Upgrade
# ---------------------------------------------------------------------------

def upgrade() -> None:
    """Create alert_history table with indexes on type, created_at, severity."""

    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing_tables = inspector.get_table_names()

    if "alert_history" in existing_tables:
        return

    op.create_table(
        "alert_history",
        sa.Column("id",             sa.Integer(),                    nullable=False),
        sa.Column("alert_type",     sa.String(100),                  nullable=False),
        sa.Column("severity",       sa.String(20),                   nullable=False),
        sa.Column("value",          sa.Numeric(18, 4),               nullable=True),
        sa.Column("threshold",      sa.Numeric(18, 4),               nullable=True),
        sa.Column("reason",         sa.Text(),                       nullable=True),
        sa.Column("metadata_json",  sa.Text(),                       nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("acknowledged_at", sa.DateTime(timezone=True),    nullable=True),
        sa.Column("acknowledged_by", sa.String(100),                 nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_index("idx_alert_history_type",     "alert_history", ["alert_type"])
    op.create_index("idx_alert_history_created",  "alert_history", ["created_at"])
    op.create_index("idx_alert_history_severity", "alert_history", ["severity"])


# ---------------------------------------------------------------------------
# Downgrade
# ---------------------------------------------------------------------------

def downgrade() -> None:
    """Drop alert_history table and its indexes."""

    op.drop_index("idx_alert_history_severity", table_name="alert_history")
    op.drop_index("idx_alert_history_created",  table_name="alert_history")
    op.drop_index("idx_alert_history_type",     table_name="alert_history")
    op.drop_table("alert_history")
