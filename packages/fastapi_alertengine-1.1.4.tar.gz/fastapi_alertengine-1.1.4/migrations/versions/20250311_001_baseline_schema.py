"""Baseline schema — all tables as they existed before engineering tasks.

Creates: escrows, escrow_state_logs, deals, merchants, merchant_inventory

Production safety
-----------------
Every CREATE TABLE statement uses checkfirst=True (which maps to
IF NOT EXISTS in the generated DDL) so this migration is safe to run
against a Railway PostgreSQL instance that already has the tables.

To stamp an existing production database without running DDL:
    alembic stamp 001_baseline

Revision ID: 001_baseline
Revises: —
Create Date: 2025-03-11 00:00:00.000000
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# ---------------------------------------------------------------------------
# Revision identifiers
# ---------------------------------------------------------------------------

revision: str = "001_baseline"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# upgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    """
    Create all core tables and their baseline indexes.

    Uses checkfirst=True everywhere so running this migration against a DB
    that already has the tables is a no-op (IF NOT EXISTS semantics).
    """
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing_tables = inspector.get_table_names()

    # ── escrows ───────────────────────────────────────────────────────────
    if "escrows" not in existing_tables:
        op.create_table(
            "escrows",
            sa.Column("id",                      sa.Integer(),                 nullable=False),
            sa.Column("order_id",                sa.Integer(),                 nullable=False),
            # Monetary breakdown
            sa.Column("merchant_gross",          sa.Numeric(12, 2),            nullable=False),
            sa.Column("courier_gross",           sa.Numeric(12, 2),            nullable=False),
            sa.Column("total_escrow",            sa.Numeric(12, 2),            nullable=False),
            # Tofamba fee
            sa.Column("merchant_tandem_fee",     sa.Numeric(12, 2),            nullable=False),
            sa.Column("courier_tandem_fee",      sa.Numeric(12, 2),            nullable=False),
            sa.Column("total_tandem_fee",        sa.Numeric(12, 2),            nullable=False),
            # IMTT tax
            sa.Column("merchant_imtt_tax",       sa.Numeric(12, 2),            nullable=False),
            sa.Column("courier_imtt_tax",        sa.Numeric(12, 2),            nullable=False),
            sa.Column("total_imtt_tax",          sa.Numeric(12, 2),            nullable=False),
            # Payouts
            sa.Column("merchant_final_payout",   sa.Numeric(12, 2),            nullable=False),
            sa.Column("courier_final_payout",    sa.Numeric(12, 2),            nullable=False),
            # Status
            sa.Column("status",                  sa.String(length=50),         nullable=False),
            sa.Column("pin_hash",                sa.String(length=64),         nullable=True),
            # Timing
            sa.Column("created_at",              sa.DateTime(timezone=True),   nullable=False),
            sa.Column("updated_at",              sa.DateTime(timezone=True),   nullable=False),
            sa.Column("expiry_timestamp",        sa.DateTime(timezone=True),   nullable=False),
            # Wallet provider
            sa.Column("wallet_provider",         sa.String(length=50),         nullable=False),
            sa.Column("external_transaction_id", sa.String(length=255),        nullable=False),
            sa.Column("payer_wallet_id",         sa.String(length=255),        nullable=False),
            sa.Column("payee_wallet_id",         sa.String(length=255),        nullable=False),
            # Reversal
            sa.Column("reversal_triggered_at",   sa.DateTime(timezone=True),   nullable=True),
            sa.Column("reversal_reason",         sa.String(length=100),        nullable=True),
            sa.PrimaryKeyConstraint("id"),
            sa.UniqueConstraint("external_transaction_id"),
        )
        op.create_index("ix_escrows_order_id",               "escrows", ["order_id"])
        op.create_index("ix_escrows_status",                 "escrows", ["status"])
        op.create_index("ix_escrows_created_at",             "escrows", ["created_at"])
        op.create_index("ix_escrows_expiry_timestamp",       "escrows", ["expiry_timestamp"])
        op.create_index("ix_escrows_external_transaction_id","escrows", ["external_transaction_id"])

    # ── escrow_state_logs ─────────────────────────────────────────────────
    if "escrow_state_logs" not in existing_tables:
        op.create_table(
            "escrow_state_logs",
            sa.Column("id",              sa.Integer(),                 nullable=False),
            sa.Column("escrow_id",       sa.Integer(),                 nullable=True),
            sa.Column("previous_status", sa.String(length=50),         nullable=False),
            sa.Column("new_status",      sa.String(length=50),         nullable=False),
            sa.Column("triggered_by",    sa.String(length=100),        nullable=False),
            sa.Column("metadata_json",   sa.Text(),                    nullable=True),
            sa.Column("created_at",      sa.DateTime(timezone=True),   nullable=False),
            sa.ForeignKeyConstraint(
                ["escrow_id"], ["escrows.id"],
                ondelete="CASCADE",
            ),
            sa.PrimaryKeyConstraint("id"),
        )
        op.create_index("ix_escrow_state_logs_escrow_id", "escrow_state_logs", ["escrow_id"])

    # ── deals ─────────────────────────────────────────────────────────────
    if "deals" not in existing_tables:
        op.create_table(
            "deals",
            sa.Column("id",                      sa.Integer(),                 nullable=False),
            sa.Column("deal_id",                 sa.String(length=10),         nullable=False),
            sa.Column("seller_name",             sa.String(length=100),        nullable=False),
            sa.Column("item_description",        sa.Text(),                    nullable=False),
            sa.Column("price",                   sa.Numeric(12, 2),            nullable=False),
            sa.Column("wallet_phone",            sa.String(length=20),         nullable=False),
            sa.Column("delivery_window_minutes", sa.Integer(),                 nullable=False),
            sa.Column("status",                  sa.String(length=50),         nullable=False),
            sa.Column("escrow_id",               sa.Integer(),                 nullable=True),
            sa.Column("seller_phone",            sa.String(length=20),         nullable=True),
            sa.Column("item_sku",                sa.String(length=100),        nullable=True),
            sa.Column("quantity",                sa.Integer(),                 nullable=False,
                      server_default="1"),
            sa.Column("created_at",              sa.DateTime(timezone=True),   nullable=False),
            sa.Column("expires_at",              sa.DateTime(timezone=True),   nullable=True),
            sa.Column("completed_at",            sa.DateTime(timezone=True),   nullable=True),
            sa.ForeignKeyConstraint(["escrow_id"], ["escrows.id"]),
            sa.PrimaryKeyConstraint("id"),
            sa.UniqueConstraint("deal_id"),
        )
        op.create_index("ix_deals_deal_id", "deals", ["deal_id"])
        op.create_index("ix_deals_status",  "deals", ["status"])

    # ── merchants ─────────────────────────────────────────────────────────
    if "merchants" not in existing_tables:
        op.create_table(
            "merchants",
            sa.Column("id",             sa.Integer(),               nullable=False),
            sa.Column("phone",          sa.String(length=20),       nullable=False),
            sa.Column("name",           sa.String(length=100),      nullable=False),
            sa.Column("wallet_address", sa.String(length=20),       nullable=False),
            sa.Column("status",         sa.String(length=50),       nullable=False,
                      server_default="pending_verification"),
            sa.Column("created_at",     sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            sa.UniqueConstraint("phone"),
        )
        op.create_index("ix_merchants_phone", "merchants", ["phone"])

    # ── merchant_inventory ────────────────────────────────────────────────
    if "merchant_inventory" not in existing_tables:
        op.create_table(
            "merchant_inventory",
            sa.Column("id",                 sa.Integer(),               nullable=False),
            sa.Column("merchant_phone",     sa.String(length=20),       nullable=False),
            sa.Column("sku",                sa.String(length=100),      nullable=False),
            sa.Column("item_name",          sa.String(length=200),      nullable=False),
            sa.Column("item_description",   sa.Text(),                  nullable=True),
            sa.Column("item_picture_url",   sa.String(length=500),      nullable=True),
            sa.Column("price",              sa.Numeric(12, 2),          nullable=False),
            sa.Column("quantity_available", sa.Integer(),               nullable=False,
                      server_default="0"),
            sa.Column("quantity_reserved",  sa.Integer(),               nullable=False,
                      server_default="0"),
            sa.Column("quantity_sold",      sa.Integer(),               nullable=False,
                      server_default="0"),
            sa.Column("reorder_level",      sa.Integer(),               nullable=False,
                      server_default="5"),
            sa.Column("last_updated",       sa.DateTime(timezone=True), nullable=False),
            sa.Column("created_at",         sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            sa.UniqueConstraint("merchant_phone", "sku", name="uq_merchant_sku"),
        )
        op.create_index("ix_merchant_inventory_merchant_phone",
                        "merchant_inventory", ["merchant_phone"])
        op.create_index("ix_merchant_inventory_sku",
                        "merchant_inventory", ["sku"])


# ---------------------------------------------------------------------------
# downgrade
# ---------------------------------------------------------------------------


def downgrade() -> None:
    """
    Drop all baseline tables in reverse dependency order.

    WARNING: This is a destructive operation — all data will be lost.
    Only use in development / staging.  Never run on production without
    a verified backup.
    """
    op.drop_table("merchant_inventory")
    op.drop_table("merchants")
    op.drop_table("deals")
    op.drop_table("escrow_state_logs")
    op.drop_table("escrows")
