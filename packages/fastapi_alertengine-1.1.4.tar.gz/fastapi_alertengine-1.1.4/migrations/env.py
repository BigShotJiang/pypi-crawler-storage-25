"""
Alembic environment configuration for Tofamba.

DATABASE_URL resolution order
------------------------------
1. ``DATABASE_URL`` environment variable (Railway, local dev, CI)
2. ``app.config.settings.DATABASE_URL`` as a fallback
3. Hard-coded SQLite path ``sqlite:///./tofamba.db`` as a last resort

The same env.py works for:
- Online mode  (alembic upgrade head   → connects to DB and runs DDL)
- Offline mode (alembic upgrade --sql  → emits SQL script to stdout)
"""

import os
import sys
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool

from alembic import context

# ── 0. Make sure `app` is on sys.path ─────────────────────────────────────
# alembic.ini sets prepend_sys_path = . so this is usually unnecessary, but
# keep it as an explicit guard for environments that ignore ini settings.
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

# ── 1. Import our models so Alembic can diff them ─────────────────────────
from app.models.database import Base  # noqa: E402  (import after path fix)

# ── 2. Read Alembic's own logging config from alembic.ini ─────────────────
config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# ── 3. Tell Alembic which metadata to compare against ─────────────────────
target_metadata = Base.metadata


# ── 4. Resolve DATABASE_URL ───────────────────────────────────────────────

def get_database_url() -> str:
    """
    Return the database URL, trying three sources in order.

    Raises RuntimeError if none of the sources provide a URL.
    """
    # Priority 1: environment variable (Railway, .env, CI)
    url = os.environ.get("DATABASE_URL", "").strip()
    if url:
        # Railway injects postgres:// which SQLAlchemy 2 requires as
        # postgresql://.  Fix the scheme transparently.
        if url.startswith("postgres://"):
            url = url.replace("postgres://", "postgresql://", 1)
        return url

    # Priority 2: app settings object (loaded from env vars in config.py)
    try:
        from app.config import settings  # noqa: PLC0415
        url = getattr(settings, "DATABASE_URL", "").strip()
        if url:
            if url.startswith("postgres://"):
                url = url.replace("postgres://", "postgresql://", 1)
            return url
    except Exception:
        pass

    # Priority 3: safe local default for development
    return "sqlite:///./tofamba.db"


# ── 5. Online mode ────────────────────────────────────────────────────────

def run_migrations_online() -> None:
    """
    Run migrations against a live database connection.

    A connection is obtained from engine_from_config(), which reads
    ``sqlalchemy.url`` from alembic.ini.  We override that key here so
    alembic.ini can safely leave it blank and DATABASE_URL drives
    everything.
    """
    # Merge our resolved URL into the config section Alembic reads
    configuration = config.get_section(config.config_ini_section, {})
    configuration["sqlalchemy.url"] = get_database_url()

    connectable = engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            # Compare server defaults so Alembic detects DEFAULT value changes
            compare_server_defaults=True,
            # Include schemas if you ever add multi-schema support
            include_schemas=False,
        )
        with context.begin_transaction():
            context.run_migrations()


# ── 6. Offline mode ───────────────────────────────────────────────────────

def run_migrations_offline() -> None:
    """
    Emit SQL to stdout without a live DB connection.

    Useful for generating migration scripts to review before applying,
    or for DBAs who apply DDL manually.

    Usage:
        alembic upgrade head --sql > migration.sql
    """
    url = get_database_url()

    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_server_defaults=True,
    )

    with context.begin_transaction():
        context.run_migrations()


# ── 7. Dispatch ───────────────────────────────────────────────────────────

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
