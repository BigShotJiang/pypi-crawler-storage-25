# services/catalogue.py  (root-level shim)
"""
Re-exports fetch_catalogue and create_deal from app.services.catalogue so that
``from services.catalogue import fetch_catalogue, create_deal`` works from
modules in the project root (e.g. whatsapp_bot.py).
"""

from app.services.catalogue import fetch_catalogue, create_deal  # noqa: F401
