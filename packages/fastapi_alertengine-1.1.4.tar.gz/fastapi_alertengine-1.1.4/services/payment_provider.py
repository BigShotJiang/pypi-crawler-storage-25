# services/payment_provider.py
"""
Payment provider stub for settlement engine.

``send_payment()`` is called by ``app/services/settlement_engine.py`` to
push payouts to merchants and couriers after PIN verification.

This module is a stub that logs and returns success=False until a
real implementation (EcoCash / InnBucks / Omari / Paynow Send Money)
is wired in.  The settlement engine is designed to handle payment
failures gracefully — this stub ensures the system is importable and
the audit trail is written correctly even before the adapter is live.

To activate:
  Replace the stub body with a call to the appropriate WalletAdapter's
  send_money() method once it is available.
"""

import logging
from decimal import Decimal
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


def send_payment(
    wallet_address: str,
    amount: Decimal,
    reference: str,
) -> Tuple[bool, Optional[str]]:
    """
    Send a payment to a wallet address.

    Args:
        wallet_address: Recipient wallet phone / number.
        amount:         Amount to send (Decimal, 2dp).
        reference:      Payment reference for reconciliation.

    Returns:
        (success: bool, transaction_id: str | None)
        Returns (False, None) until a real implementation is wired in.

    NEVER raises — all exceptions are caught and logged.
    """
    logger.warning(
        "send_payment: STUB called — no real payment provider configured. "
        "ref=%s amount=%s to=%s",
        reference, amount, wallet_address[-4:] if wallet_address else "??",
    )
    # Return False so the settlement engine flags the payout as needing
    # manual processing rather than silently succeeding.
    return False, None
