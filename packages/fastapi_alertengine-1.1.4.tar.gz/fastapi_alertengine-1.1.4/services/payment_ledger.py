# services/payment_ledger.py
"""
Payment ledger — durable PostgreSQL record for payment confirmations.

Invariant enforced here
────────────────────────
  "If a payment is confirmed, it MUST exist in PostgreSQL BEFORE
   Redis is marked as processed."

This module is the single point of truth for that write.

Write ordering in _process_payment_confirmed():
  1. Acquire deal lock               (Redis)
  2. Check Redis idempotency guard   (Redis  — read-only check, no SET yet)
  3. record_payment_confirmation()   (PostgreSQL ← THIS FUNCTION)
  4. Mark Redis as processed         (Redis  — only on DB success)
  5. Advance bot state               (Redis)

If step 3 fails, step 4 never executes.  Redis idempotency key is
never set.  Paynow will retry → the next delivery attempt will succeed
once the database recovers.  This is "at-least-once with DB durability".

PostgreSQL writes
─────────────────
  • If an Escrow row with matching external_transaction_id exists:
      - Guard: if already HELD, return True (idempotent)
      - Transition status → HELD
      - Append EscrowStateLog row
  • Always: append an EscrowStateLog row with escrow_id=NULL
    (the "payment_ledger" entry — survives even if no Escrow row exists yet)
  • Both operations are in a single transaction.  Either both commit
    or neither does — no partial writes.
"""

import logging
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)


def record_payment_confirmation(
    db,
    reference: str,
    phone: str,
    amount: Optional[str] = None,
    wallet_provider: str = "paynow",
) -> bool:
    """
    Write payment confirmation durably to PostgreSQL.

    This function MUST be called before Redis is marked as processed.

    Args:
        db:              SQLAlchemy Session (may be None — see return value).
        reference:       Paynow payment reference (= Escrow.external_transaction_id).
        phone:           Customer phone (for audit trail only — NOT stored in escrow).
        amount:          Payment amount as string, e.g. "15.00" (informational).
        wallet_provider: Provider name, default "paynow".

    Returns:
        True  — DB write succeeded (or was already done — idempotent).
        False — DB write failed; caller must NOT mark Redis as processed.
    """
    if db is None:
        # DB unavailable — log and return False so Redis is NOT marked.
        # Payment will be retried by Paynow.
        logger.error(
            "record_payment_confirmation: db=None for ref=%s — "
            "cannot guarantee durability; blocking Redis mark",
            reference,
        )
        return False

    try:
        return _write_in_transaction(db, reference, phone, amount, wallet_provider)
    except Exception as exc:
        logger.exception(
            "record_payment_confirmation: unexpected error ref=%s: %s",
            reference, exc,
        )
        try:
            db.rollback()
        except Exception:
            pass
        return False


def _write_in_transaction(
    db,
    reference: str,
    phone: str,
    amount: Optional[str],
    wallet_provider: str,
) -> bool:
    """
    Perform all DB writes within a single transaction.

    Returns True on success, raises on failure (caller does rollback).
    """
    from app.models.database import Escrow, EscrowStatus, EscrowStateLog

    now = datetime.now(timezone.utc)

    # ── 1. Locate matching Escrow (by Paynow reference) ───────────────────────
    escrow: Optional[Escrow] = None
    try:
        escrow = (
            db.query(Escrow)
            .filter(Escrow.external_transaction_id == reference)
            .first()
        )
    except Exception as exc:
        logger.warning("record_payment_confirmation: escrow lookup failed [%s]: %s", reference, exc)
        # Proceed without escrow link — the ledger entry still records the event

    # ── 2. Idempotency guard: already HELD → nothing to do ───────────────────
    if escrow is not None and escrow.status == EscrowStatus.HELD:
        logger.info(
            "record_payment_confirmation: escrow already HELD ref=%s — idempotent, skipping",
            reference,
        )
        return True   # Considered success — don't re-process

    # ── 3. Transition Escrow to HELD ─────────────────────────────────────────
    if escrow is not None:
        prev_status = escrow.status.value if hasattr(escrow.status, "value") else str(escrow.status)
        try:
            escrow.status     = EscrowStatus.HELD
            escrow.updated_at = now
            db.add(escrow)
        except Exception as exc:
            logger.error("record_payment_confirmation: escrow update failed [%s]: %s", reference, exc)
            raise

    # ── 4. Append EscrowStateLog (always, even without an Escrow row) ─────────
    # This is the durable "payment ledger" entry.  escrow_id=None is allowed
    # by the schema (for system events).
    log_entry = EscrowStateLog(
        escrow_id        = escrow.id if escrow else None,
        previous_status  = prev_status if escrow else "none",
        new_status       = EscrowStatus.HELD.value,
        triggered_by     = f"paynow_webhook:{reference}",
        # note, created_at etc. have defaults on the model
    )
    try:
        db.add(log_entry)
    except Exception as exc:
        logger.error("record_payment_confirmation: state log insert failed [%s]: %s", reference, exc)
        raise

    # ── 5. Commit ─────────────────────────────────────────────────────────────
    db.commit()
    logger.info(
        "record_payment_confirmation: committed ref=%s escrow_id=%s",
        reference,
        escrow.id if escrow else "none",
    )
    return True
