# services/escrow_release.py
"""
Escrow release on PIN verification.

Called by ``_handle_pin_entry()`` in ``whatsapp_bot.py`` after a valid PIN.

Transitions the Escrow from DELIVERY_IN_PROGRESS → RELEASED and records
an audit log entry.  Returns the merchant payout amount for display in the
bot's confirmation message.

Note: The full multi-party settlement (PaymentSplit, VATAccrual, etc.) is
handled by ``app/services/settlement_engine.py``.  This module is the
lightweight escrow-state transition used by the bot.  Full settlement
runs asynchronously in the background.
"""

import json
import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import Union

logger = logging.getLogger(__name__)


def release_escrow_on_pin(
    db,
    escrow_id: Union[int, str],
    courier_phone: str,
) -> Decimal:
    """
    Release an escrow after PIN is confirmed by the courier.

    Workflow:
      1. Load escrow by ID.
      2. Validate status (must be HELD or DELIVERED — not already RELEASED).
      3. Transition to RELEASED, record EscrowStateLog entry.
      4. Commit.

    Args:
        db:           SQLAlchemy Session.
        escrow_id:    Escrow primary key (int or str accepted).
        courier_phone: Courier's phone number (for audit log).

    Returns:
        Decimal: The merchant's final payout amount (for display in bot message).
                 Returns Decimal("0") if the escrow cannot be found or is
                 already in a terminal state — caller handles gracefully.

    Never raises — all exceptions are caught and logged.
    """
    try:
        from app.models.database import Escrow, EscrowStateLog, EscrowStatus

        escrow = db.query(Escrow).filter(Escrow.id == int(escrow_id)).first()

        if not escrow:
            logger.error("release_escrow_on_pin: escrow %s not found", escrow_id)
            return Decimal("0")

        # Guard against double-release
        terminal = {EscrowStatus.RELEASED, EscrowStatus.REVERSAL_INITIATED,
                    EscrowStatus.REVERSAL_CONFIRMED}
        if escrow.status in terminal:
            logger.warning(
                "release_escrow_on_pin: escrow %s already in terminal state %s",
                escrow_id, escrow.status,
            )
            return Decimal(str(escrow.merchant_final_payout or 0))

        previous = escrow.status.value if hasattr(escrow.status, "value") else str(escrow.status)
        escrow.status = EscrowStatus.RELEASED

        db.add(EscrowStateLog(
            escrow_id       = int(escrow_id),
            previous_status = previous,
            new_status      = EscrowStatus.RELEASED.value,
            triggered_by    = "pin_verified",
            metadata_json   = json.dumps({
                "courier_phone": courier_phone,
                "timestamp":     datetime.now(timezone.utc).isoformat(),
            }),
        ))
        db.commit()

        amount = Decimal(str(escrow.merchant_final_payout or 0))
        logger.info(
            "release_escrow_on_pin: escrow %s released, merchant_payout=%s",
            escrow_id, amount,
        )
        return amount

    except Exception as exc:
        logger.error(
            "release_escrow_on_pin failed for escrow %s: %s", escrow_id, exc,
            exc_info=True,
        )
        try:
            db.rollback()
        except Exception:
            pass
        return Decimal("0")
