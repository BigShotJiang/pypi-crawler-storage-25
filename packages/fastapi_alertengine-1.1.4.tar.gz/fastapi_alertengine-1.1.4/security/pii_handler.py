# security/pii_handler.py
"""
PII masking for AnchorFlow.

Phone numbers are the primary PII in this system.  Every phone that appears
in a log, event, or Redis key that might be read by ops must pass through
``PIIHandler.mask_user_id()`` first.

Masking strategy:
  +263771234567  →  +263***4567
  263771234567   →  263***4567
  0771234567     →  0***4567

The last 4 digits are retained so that support can correlate masked IDs
across log lines without seeing the full number.
"""

import re


class PIIHandler:
    """Masks personally-identifiable information for safe logging."""

    # Minimum length before masking is applied (very short strings are masked fully)
    _MIN_LEN = 6

    def mask_user_id(self, phone: str) -> str:
        """
        Mask a phone number, retaining only the last 4 digits.

        Args:
            phone: Raw phone number string (any format).

        Returns:
            Masked representation, e.g. ``"+263***4567"``.
            Returns ``"[masked]"`` for empty/None input.
        """
        if not phone:
            return "[masked]"
        phone = str(phone).strip()
        if len(phone) <= self._MIN_LEN:
            return "[masked]"

        # Strip non-digit characters for masking, keep prefix
        digits_only = re.sub(r"\D", "", phone)
        if len(digits_only) < 4:
            return "[masked]"

        # Preserve leading non-digit prefix (e.g. "+")
        prefix_match = re.match(r"^(\D*)", phone)
        prefix = prefix_match.group(1) if prefix_match else ""

        last4 = digits_only[-4:]
        return f"{prefix}***{last4}"

    def mask_email(self, email: str) -> str:
        """Mask an email address, retaining domain only."""
        if not email or "@" not in email:
            return "[masked]"
        _, domain = email.split("@", 1)
        return f"***@{domain}"
