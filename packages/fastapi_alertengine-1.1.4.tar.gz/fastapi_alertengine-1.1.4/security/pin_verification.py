# security/pin_verification.py
"""
PIN verification for AnchorFlow escrow release.

A 6-digit PIN is set when an escrow is created and hashed (SHA-256) before
storage.  The courier enters the PIN on delivery; this module verifies it
and enforces a 3-attempt lockout to prevent brute-force.

Attempt counter is stored in the Escrow row's pin_hash alongside the hash.
Lock state is persisted via EscrowStateLog so ops can audit lockouts.

Usage::

    pin_svc = PINVerification(db)
    result  = pin_svc.verify_pin(escrow_id, pin_input, courier_phone=phone)
    if result.locked:
        ...  # too many attempts
    if not result.valid:
        ...  # wrong PIN, result.attempts_remaining tells how many left
    # result.valid == True → proceed to release_escrow_on_pin
"""

import hashlib
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

_MAX_ATTEMPTS = 3


@dataclass
class VerifyResult:
    """Result of a PIN verification attempt."""
    valid:              bool
    locked:             bool  = False
    attempts_remaining: int   = _MAX_ATTEMPTS


class PINVerification:
    """
    Stateful PIN verifier bound to a SQLAlchemy session.

    Attempt count is tracked in the Escrow.pin_hash field using a simple
    JSON envelope:  ``{"hash": "<sha256>", "attempts": <int>}``.
    When attempts reach _MAX_ATTEMPTS, ``locked=True`` is returned and no
    further attempts are accepted.
    """

    def __init__(self, db):
        self.db = db

    def verify_pin(
        self,
        escrow_id: str,
        pin_input: str,
        courier_phone: Optional[str] = None,
    ) -> VerifyResult:
        """
        Verify a 6-digit PIN against the stored hash.

        Args:
            escrow_id:    Escrow primary key (int or str).
            pin_input:    Raw digits entered by the courier.
            courier_phone: For audit logging only (optional).

        Returns:
            VerifyResult with valid, locked, and attempts_remaining.

        Never raises — returns locked=True on any internal error to fail safe.
        """
        try:
            from app.models.database import Escrow, EscrowStateLog

            escrow = self.db.query(Escrow).filter(Escrow.id == int(escrow_id)).first()
            if not escrow:
                logger.error("PINVerification: escrow %s not found", escrow_id)
                return VerifyResult(valid=False, locked=True, attempts_remaining=0)

            # Parse pin_hash envelope
            envelope = self._parse_envelope(escrow.pin_hash)
            if envelope is None:
                logger.error("PINVerification: no PIN set for escrow %s", escrow_id)
                return VerifyResult(valid=False, locked=True, attempts_remaining=0)

            stored_hash = envelope.get("hash", "")
            attempts    = envelope.get("attempts", 0)

            if attempts >= _MAX_ATTEMPTS:
                return VerifyResult(valid=False, locked=True, attempts_remaining=0)

            # Verify
            input_hash = hashlib.sha256(pin_input.encode()).hexdigest()
            if input_hash == stored_hash:
                # Success — reset attempt counter
                escrow.pin_hash = json.dumps({"hash": stored_hash, "attempts": 0})
                self.db.commit()
                return VerifyResult(valid=True, locked=False, attempts_remaining=_MAX_ATTEMPTS)

            # Failed attempt
            attempts += 1
            escrow.pin_hash = json.dumps({"hash": stored_hash, "attempts": attempts})

            if attempts >= _MAX_ATTEMPTS:
                self._log_lockout(escrow_id, courier_phone)
                self.db.commit()
                return VerifyResult(valid=False, locked=True, attempts_remaining=0)

            self.db.commit()
            return VerifyResult(
                valid=False,
                locked=False,
                attempts_remaining=_MAX_ATTEMPTS - attempts,
            )

        except Exception as exc:
            logger.error("PINVerification.verify_pin error: %s", exc, exc_info=True)
            return VerifyResult(valid=False, locked=True, attempts_remaining=0)

    # ── helpers ───────────────────────────────────────────────────────────────

    def _parse_envelope(self, pin_hash: Optional[str]) -> Optional[dict]:
        """Parse JSON envelope or treat bare SHA-256 hash as envelope with 0 attempts."""
        if not pin_hash:
            return None
        try:
            data = json.loads(pin_hash)
            if isinstance(data, dict) and "hash" in data:
                return data
        except (json.JSONDecodeError, TypeError):
            pass
        # Legacy: bare SHA-256 string
        if len(pin_hash) == 64:
            return {"hash": pin_hash, "attempts": 0}
        return None

    def _log_lockout(self, escrow_id: str, courier_phone: Optional[str]) -> None:
        """Append a lockout event to EscrowStateLog."""
        try:
            from app.models.database import EscrowStateLog
            self.db.add(EscrowStateLog(
                escrow_id       = int(escrow_id),
                previous_status = "delivery_in_progress",
                new_status      = "pin_locked",
                triggered_by    = "pin_verification",
                metadata_json   = json.dumps({
                    "reason":        "max_attempts_exceeded",
                    "courier_phone": courier_phone or "unknown",
                    "timestamp":     datetime.now(timezone.utc).isoformat(),
                }),
            ))
        except Exception as exc:
            logger.error("_log_lockout failed: %s", exc)

    @staticmethod
    def hash_pin(pin: str) -> str:
        """Hash a plain-text PIN for storage. Returns JSON envelope string."""
        return json.dumps({
            "hash":     hashlib.sha256(pin.encode()).hexdigest(),
            "attempts": 0,
        })
