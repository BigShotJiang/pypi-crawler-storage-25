# REAL TEST EXECUTION MANUAL

## Introduction
This manual provides step-by-step instructions for running the $15 real transaction test using the API. It includes all necessary API calls, expected responses, screenshots, and a troubleshooting guide to assist testers.

## Pre-requisites
- An active user account.
- Access to the API documentation.
- Tools: Postman or Curl or any API testing tool.

## Step-by-Step Instructions
1. **Login to the API**: Make sure you are logged in to the API service.
2. **Initiate a Real Transaction**:
   - Use the following API endpoint to initiate a transaction.
   - **API Call**: `POST /api/transaction/start`
   - **Parameters**:
     - `amount`: 15
   - **Expected Response**: `200 OK`
3. **Confirm the Transaction**:
   - Check the response for confirmation.
4. **Finalize the Transaction**:
   - Use the API call to complete the transaction.

## API Calls
- **Start Transaction**  
  `POST /api/transaction/start` 
  - Parameters: {"amount": 15}
  - Expected Response: {"status": "success", "transactionId": "12345"}

- **Complete Transaction**  
  `POST /api/transaction/complete` 
  - Parameters: {"transactionId": "12345"}
  - Expected Response: {"status": "completed"}

## Expected Responses
- **Successful Initialization**:  
  ```json  
  {  
    "status": "success", 
    "transactionId": "12345"  
  }  
  ```

- **Successful Completion**:  
  ```json  
  {  
    "status": "completed" 
  }  
  ```

## Screenshots
- Screenshot of the API tool showing the request and response for starting a transaction.
- Screenshot of the transaction confirmation.

## Troubleshooting Guide
- **Issue**: Failed to start transaction.  
  **Solution**: Verify that you have entered the correct amount and are logged in to your account.

- **Issue**: Transaction not completing.  
  **Solution**: Check if the transaction ID is correct and try again.

## Conclusion
This manual serves as a guide for executing the $15 real transaction test. For additional resources, please refer to the API documentation or contact support.