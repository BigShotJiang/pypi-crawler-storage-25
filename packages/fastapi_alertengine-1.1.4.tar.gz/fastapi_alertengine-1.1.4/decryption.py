# decryption.py (Enhanced)
"""
WhatsApp Flow Decryption Handler
Handles RSA + AES-GCM encrypted payloads from WhatsApp Flows
With error recovery and retry logic
"""

import base64
import json
import logging
import hashlib
from typing import Dict, Optional, Tuple
from datetime import datetime, timedelta
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

logger = logging.getLogger(__name__)


class WhatsAppFlowDecryptionError(Exception):
    """Custom exception for decryption errors."""
    pass


class DecryptionFailure:
    """Track decryption failures for security monitoring"""
    
    def __init__(self):
        self.failures = {}  # hash -> {count, first_time, last_time}
        self.max_failures = 5
        self.failure_window = timedelta(hours=1)
    
    def record_failure(self, payload_hash: str) -> bool:
        """
        Record a decryption failure.
        Returns True if threshold exceeded.
        """
        now = datetime.now()
        
        if payload_hash not in self.failures:
            self.failures[payload_hash] = {
                "count": 1,
                "first_time": now,
                "last_time": now
            }
            return False
        
        failure = self.failures[payload_hash]
        
        # Check if we're within the failure window
        if now - failure["first_time"] > self.failure_window:
            # Reset: outside window
            self.failures[payload_hash] = {
                "count": 1,
                "first_time": now,
                "last_time": now
            }
            return False
        
        # Still within window, increment
        failure["count"] += 1
        failure["last_time"] = now
        
        return failure["count"] >= self.max_failures


# Global failure tracker
failure_tracker = DecryptionFailure()


class WhatsAppFlowDecryptor:
    """
    Decrypts WhatsApp Flow encrypted payloads.
    Uses RSA for key exchange, AES-GCM for data encryption.
    Includes retry logic and error recovery.
    """

    def __init__(self, private_key_pem: str):
        """
        Initialize with WABA private key.

        Args:
            private_key_pem: Private key in PEM format (from WABA settings)
            
        Raises:
            ValueError: If the key cannot be loaded.
        """
        try:
            self.private_key = serialization.load_pem_private_key(
                private_key_pem.encode(),
                password=None
            )
            logger.info("WhatsApp private key loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load private key: {e}", exc_info=True)
            raise ValueError("Invalid private key provided") from e

    def _hash_payload(
        self,
        encrypted_aes_key_b64: str,
        encrypted_flow_data_b64: str
    ) -> str:
        """
        Create hash of payload for tracking duplicate failures.
        Helps identify replay attacks or corrupt data.
        """
        combined = f"{encrypted_aes_key_b64[:50]}{encrypted_flow_data_b64[:50]}"
        return hashlib.sha256(combined.encode()).hexdigest()

    def _validate_inputs(
        self,
        encrypted_aes_key_b64: str,
        encrypted_flow_data_b64: str,
        initial_vector_b64: str
    ) -> Tuple[bool, str]:
        """
        Validate input format before decryption.
        
        Returns:
            (is_valid: bool, error_message: str)
        """
        
        # Check for empty inputs
        if not encrypted_aes_key_b64:
            return False, "encrypted_aes_key is empty"
        if not encrypted_flow_data_b64:
            return False, "encrypted_flow_data is empty"
        if not initial_vector_b64:
            return False, "initial_vector is empty"
        
        # Try to decode base64
        try:
            base64.b64decode(encrypted_aes_key_b64)
        except Exception:
            return False, "encrypted_aes_key is not valid base64"
        
        try:
            base64.b64decode(encrypted_flow_data_b64)
        except Exception:
            return False, "encrypted_flow_data is not valid base64"
        
        try:
            base64.b64decode(initial_vector_b64)
        except Exception:
            return False, "initial_vector is not valid base64"
        
        # Check size constraints
        aes_key_size = len(base64.b64decode(encrypted_aes_key_b64))
        if aes_key_size < 128:  # RSA 2048 min
            return False, f"encrypted_aes_key too small: {aes_key_size} bytes"
        
        if aes_key_size > 512:  # RSA 4096 max
            return False, f"encrypted_aes_key too large: {aes_key_size} bytes"
        
        flow_data_size = len(base64.b64decode(encrypted_flow_data_b64))
        if flow_data_size < 16:  # At minimum the GCM tag
            return False, f"encrypted_flow_data too small: {flow_data_size} bytes"
        
        if flow_data_size > 1024 * 1024:  # 1MB max
            return False, f"encrypted_flow_data too large: {flow_data_size} bytes"
        
        iv_size = len(base64.b64decode(initial_vector_b64))
        if iv_size not in (12, 16):
            return False, f"initial_vector invalid size: {iv_size} bytes (expected 12 or 16)"
        
        return True, ""

    def decrypt_flow_payload(
        self,
        encrypted_aes_key_b64: str,
        encrypted_flow_data_b64: str,
        initial_vector_b64: str,
        retry_count: int = 0
    ) -> Dict:
        """
        Decrypt WhatsApp Flow payload with error recovery.

        Process:
        1. Validate inputs
        2. Decode base64 encrypted AES key
        3. Decrypt AES key using RSA private key
        4. Decode base64 encrypted flow data
        5. Decrypt flow data using AES-GCM
        6. Parse JSON result

        Args:
            encrypted_aes_key_b64: Base64-encoded RSA-encrypted AES key
            encrypted_flow_data_b64: Base64-encoded AES-GCM encrypted data
            initial_vector_b64: Base64-encoded IV for AES-GCM
            retry_count: Current retry attempt (for logging)

        Returns:
            Decrypted JSON payload as dict.

        Raises:
            WhatsAppFlowDecryptionError: If decryption or parsing fails.
        """
        
        payload_hash = self._hash_payload(encrypted_aes_key_b64, encrypted_flow_data_b64)
        
        logger.info(f"Decryption attempt {retry_count + 1}, payload_hash={payload_hash[:16]}...")

        try:
            # ─────────────────────────────────────────────────────
            # VALIDATION PHASE
            # ─────────────────────────────────────────────────────
            
            logger.debug("Validating input format...")
            is_valid, error_msg = self._validate_inputs(
                encrypted_aes_key_b64,
                encrypted_flow_data_b64,
                initial_vector_b64
            )
            
            if not is_valid:
                logger.error(f"Input validation failed: {error_msg}")
                raise WhatsAppFlowDecryptionError(error_msg)
            
            logger.debug("Input validation passed")

            # ─────────────────────────────────────────────────────
            # DECRYPTION PHASE 1: RSA (AES key)
            # ─────────────────────────────────────────────────────
            
            logger.debug("Phase 1: Decoding encrypted AES key...")
            try:
                encrypted_aes_key = base64.b64decode(encrypted_aes_key_b64)
                logger.debug(f"Encoded AES key size: {len(encrypted_aes_key)} bytes")
            except Exception as e:
                logger.error(f"Base64 decode error (AES key): {e}")
                raise WhatsAppFlowDecryptionError("Failed to decode encrypted_aes_key") from e

            logger.debug("Phase 1: Decrypting AES key with RSA...")
            try:
                aes_key = self.private_key.decrypt(
                    encrypted_aes_key,
                    padding.OAEP(
                        mgf=padding.MGF1(algorithm=hashes.SHA256()),
                        algorithm=hashes.SHA256(),
                        label=None
                    )
                )
                logger.info(f"AES key decrypted: {len(aes_key)} bytes")
                
                # Validate AES key size
                if len(aes_key) not in (16, 24, 32):  # 128, 192, 256 bits
                    logger.error(f"Invalid AES key size: {len(aes_key)} bytes")
                    raise WhatsAppFlowDecryptionError("Invalid AES key size")
                    
            except WhatsAppFlowDecryptionError:
                raise
            except Exception as e:
                logger.error(f"RSA decryption error: {e}", exc_info=True)
                
                # Check for repeated failures (possible attack)
                if failure_tracker.record_failure(payload_hash):
                    logger.critical(
                        f"Multiple RSA decryption failures for payload {payload_hash[:16]}, "
                        f"possible attack or corrupted key"
                    )
                
                raise WhatsAppFlowDecryptionError("RSA decryption failed") from e

            # ─────────────────────────────────────────────────────
            # DECRYPTION PHASE 2: AES-GCM (Flow data)
            # ─────────────────────────────────────────────────────
            
            logger.debug("Phase 2: Decoding encrypted flow data and IV...")
            try:
                encrypted_flow_data = base64.b64decode(encrypted_flow_data_b64)
                iv = base64.b64decode(initial_vector_b64)
                logger.debug(f"Encrypted data size: {len(encrypted_flow_data)} bytes, IV size: {len(iv)} bytes")
            except Exception as e:
                logger.error(f"Base64 decode error (flow data or IV): {e}")
                raise WhatsAppFlowDecryptionError("Failed to decode encrypted_flow_data or initial_vector") from e

            # Extract ciphertext and authentication tag (GCM: [ciphertext][16-byte tag])
            if len(encrypted_flow_data) < 16:
                logger.error("Encrypted data too short to contain GCM tag")
                raise WhatsAppFlowDecryptionError("Ciphertext too short for tag extraction")

            ciphertext = encrypted_flow_data[:-16]
            tag = encrypted_flow_data[-16:]

            logger.debug(f"Ciphertext: {len(ciphertext)} bytes, Tag: {len(tag)} bytes")

            logger.debug("Phase 2: Decrypting with AES-GCM...")
            try:
                aesgcm = AESGCM(aes_key)
                decrypted_data = aesgcm.decrypt(iv, ciphertext + tag, None)
                logger.info("AES-GCM decryption successful")
            except Exception as e:
                logger.error(f"AES-GCM decryption failed (authentication/tag error): {e}", exc_info=True)
                
                # Check for repeated failures
                if failure_tracker.record_failure(payload_hash):
                    logger.critical(
                        f"Multiple AES-GCM failures for payload {payload_hash[:16]}, "
                        f"possible attack or corrupted data"
                    )
                
                raise WhatsAppFlowDecryptionError("AES-GCM authentication failed") from e

            # ─────────────────────────────────────────────────────
            # JSON PARSING PHASE
            # ─────────────────────────────────────────────────────
            
            logger.debug("Parsing JSON payload...")
            try:
                payload = json.loads(decrypted_data.decode('utf-8'))
            except json.JSONDecodeError as e:
                logger.error(f"JSON decode error: {e}")
                raise WhatsAppFlowDecryptionError(f"Failed to parse JSON: {e}") from e
            except UnicodeDecodeError as e:
                logger.error(f"Unicode decode error: {e}")
                raise WhatsAppFlowDecryptionError("Failed to decode UTF-8") from e

            logger.info(f"Payload successfully decrypted: {list(payload.keys())}")
            return payload

        except WhatsAppFlowDecryptionError:
            # Already logged, re-raise
            raise
        except Exception as e:
            logger.error(f"Unexpected error during decryption: {e}", exc_info=True)
            raise WhatsAppFlowDecryptionError(f"Unexpected error: {e}") from e


def get_decryptor(private_key_pem: str) -> WhatsAppFlowDecryptor:
    """
    Factory function to create decryptor instance.

    Args:
        private_key_pem: PEM string of private key

    Returns:
        WhatsAppFlowDecryptor instance
        
    Raises:
        ValueError: If private key is invalid
    """
    return WhatsAppFlowDecryptor(private_key_pem)