// anchorflow_script_word.js — AnchorFlow Explainer Script → Word Document
"use strict";
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, BorderStyle, WidthType, ShadingType, VerticalAlign,
  PageBreak, Header, Footer, PageNumber,
} = require("docx");
const fs = require("fs");

// ── Brand Colors ──────────────────────────────────────────────
const NAVY     = "1A2B3C";
const TEAL     = "20C997";
const ORANGE   = "FF6B35";
const DARKTEAL = "17A87F";
const WHITE    = "FFFFFF";
const MUTED    = "7A9BB5";
const TEXTDK   = "152233";
const LTBG     = "F5FAFB";

// ── Layout ────────────────────────────────────────────────────
// US Letter, 1" margins → content width 9360 DXA
const CONTENT_W = 9360;
const COL_L     = 4500;  // Visual Description
const COL_R     = 4860;  // Voiceover

// ── Border Helpers ────────────────────────────────────────────
const solidBorder = (color, sz = 1) => ({ style: BorderStyle.SINGLE, size: sz, color });
const noBorder = () => ({ style: BorderStyle.NIL, size: 0, color: "auto" });
const cellBorders = (color = "C5D5E0") => ({
  top: solidBorder(color), bottom: solidBorder(color),
  left: solidBorder(color), right: solidBorder(color),
});

// ── Paragraph Helpers ─────────────────────────────────────────
const gap = (after = 100) => new Paragraph({ children: [], spacing: { before: 0, after } });

const run = (text, opts = {}) => new TextRun({
  text, font: "Calibri",
  size: opts.size || 22,
  bold: opts.bold || false,
  italics: opts.italic || false,
  color: opts.color || TEXTDK,
  characterSpacing: opts.charSpacing || 0,
});

const para = (children, opts = {}) => new Paragraph({
  children: Array.isArray(children) ? children : [children],
  alignment: opts.align || AlignmentType.LEFT,
  spacing: { before: opts.before || 0, after: opts.after || 80 },
  indent: opts.indent ? { left: opts.indent } : undefined,
});

// ── Scene Table Builder ───────────────────────────────────────
function buildSceneTable(sceneNum, timing, title, accentColor, leftBeats, rightLines) {
  // Row 1: Scene header (spans both columns)
  const headerRow = new TableRow({
    children: [
      new TableCell({
        columnSpan: 2,
        width: { size: CONTENT_W, type: WidthType.DXA },
        shading: { fill: NAVY, type: ShadingType.CLEAR },
        borders: {
          top: solidBorder(accentColor, 8),
          bottom: solidBorder("2E4A60", 2),
          left: noBorder(), right: noBorder(),
        },
        margins: { top: 120, bottom: 120, left: 180, right: 180 },
        children: [
          para([
            run(`SCENE ${sceneNum}`, { size: 16, bold: true, color: accentColor, charSpacing: 40 }),
            run(`   \u00B7   ${timing}`, { size: 16, bold: true, color: accentColor }),
            run(`   |   ${title}`, { size: 20, bold: true, color: WHITE }),
          ]),
        ],
      }),
    ],
  });

  // Row 2: Column labels
  const labelCell = (text, w) => new TableCell({
    width: { size: w, type: WidthType.DXA },
    shading: { fill: "EBF5F7", type: ShadingType.CLEAR },
    borders: {
      top: noBorder(),
      bottom: solidBorder(accentColor, 4),
      left: noBorder(),
      right: noBorder(),
    },
    margins: { top: 80, bottom: 80, left: 180, right: 180 },
    children: [
      para(run(text, { size: 16, bold: true, color: accentColor, charSpacing: 40 })),
    ],
  });

  const labelRow = new TableRow({
    children: [labelCell("VISUAL DESCRIPTION", COL_L), labelCell("VOICEOVER SCRIPT", COL_R)],
  });

  // Row 3: Content
  // Left cell: beats
  const leftChildren = [];
  leftBeats.forEach(({ label, body }, i) => {
    if (i > 0) leftChildren.push(gap(100));
    // keepNext: true prevents the label being orphaned from its body at a page break
    leftChildren.push(new Paragraph({
      children: [run(label, { size: 20, bold: true, color: DARKTEAL })],
      spacing: { before: 0, after: 40 },
      keepNext: true,
    }));
    leftChildren.push(para(run(body, { size: 20, color: TEXTDK }), { after: 0 }));
  });

  // Right cell: lines (each is { text, italic, bold, muted, stageDir })
  const rightChildren = rightLines.map(({ text, italic, bold, muted, stageDir }) =>
    para(
      run(text, {
        size: stageDir ? 18 : 20,
        italic: italic || stageDir || false,
        bold: bold || false,
        color: (muted || stageDir) ? MUTED : TEXTDK,
      }),
      { after: stageDir ? 40 : 100 }
    )
  );

  const contentRow = new TableRow({
    children: [
      new TableCell({
        width: { size: COL_L, type: WidthType.DXA },
        borders: {
          top: noBorder(), bottom: noBorder(), left: noBorder(),
          right: solidBorder("C5D5E0", 2),
        },
        shading: { fill: WHITE, type: ShadingType.CLEAR },
        margins: { top: 180, bottom: 200, left: 180, right: 220 },
        verticalAlign: VerticalAlign.TOP,
        children: leftChildren,
      }),
      new TableCell({
        width: { size: COL_R, type: WidthType.DXA },
        borders: { top: noBorder(), bottom: noBorder(), left: noBorder(), right: noBorder() },
        shading: { fill: LTBG, type: ShadingType.CLEAR },
        margins: { top: 180, bottom: 200, left: 220, right: 180 },
        verticalAlign: VerticalAlign.TOP,
        children: rightChildren,
      }),
    ],
  });

  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [COL_L, COL_R],
    rows: [headerRow, labelRow, contentRow],
  });
}

// ═══════════════════════════════════════════════════════════════
// DOCUMENT CONTENT
// ═══════════════════════════════════════════════════════════════

const scenes = [
  // ── SCENE 1 ────────────────────────────────────────────────
  buildSceneTable(
    1, "0:00 \u2013 0:20", "The Irony \u2014 The Trust Gap", ORANGE,
    [
      {
        label: "Opening Frame",
        body: "Glowing smartphone fills screen. Vibrant WhatsApp-style marketplace \u2014 colorful products, fire emojis, \u2018BUY NOW!\u2019 buttons. Bold Corporate Memphis character taps BUY with a wide grin and a triumphant thumb.",
      },
      {
        label: "The Break",
        body: "Screen CRACKS \u2014 jarring glitch-cut. Character teleports: now standing on a sun-bleached, dusty street corner. Petrol station sign. Another stranger approaches from the opposite direction. Both look uncertain.",
      },
      {
        label: "Frustration Close-up",
        body: "Overlay: \u20182 HOURS LATER.\u2019 Sweat droplets. A rattling matatu exhaust cloud rolls past. Color palette slowly drains \u2014 from warm digital gold to dry, muted ochre and grey.",
      },
    ],
    [
      { text: "\u201CYou found the perfect deal.", italic: true },
      { text: "On your phone.", italic: true },
      { text: "In seconds.\u201D", italic: true },
      { text: "[Beat \u2014 low mbira drone]", stageDir: true },
      { text: "\u201C...But when it\u2019s time to pay \u2014\u201D", italic: true },
      { text: "[SCREEN CRACK SFX]", stageDir: true },
      { text: "\u201C...you\u2019re standing at a petrol station.", italic: true },
      { text: "Two hours from home.", italic: true },
      { text: "Waiting for a stranger.", italic: true },
      { text: "Because in Southern Africa,", italic: true },
      { text: "the deal lives online \u2014", italic: true },
      { text: "but the trust?", italic: true },
      { text: "It lives in the real world.\u201D", italic: true },
    ]
  ),

  // ── SCENE 2 ────────────────────────────────────────────────
  buildSceneTable(
    2, "0:20 \u2013 0:40", "Introducing AnchorFlow", DARKTEAL,
    [
      {
        label: "Logo Entry",
        body: "Dusty street corner dims to a grey silhouette. The AnchorFlow SYNCHRONIZED FEET logo steps in from screen-left \u2014 two stylized teal feet moving in perfect lockstep rhythm.",
      },
      {
        label: "The Bridge Builds",
        body: "Logo pulses with a warm teal radial glow. A glowing digital bridge materializes \u2014 arching gracefully from a buyer\u2019s phone (left) to a seller\u2019s phone (right). Tiny nodes of light travel along its arc like fiber-optic data streams.",
      },
      {
        label: "Transition Out",
        body: "The dusty street corner dissolves beneath the bridge. The world transforms \u2014 clean, bright, fully digital. The bridge expands to fill the screen in vibrant teal.",
      },
    ],
    [
      { text: "\u201CIntroducing AnchorFlow.\u201D", bold: true },
      { text: "\u201CTrust. As an API.\u201D", italic: true },
      { text: "[Music lifts \u2014 confident Afrobeats-tech groove]", stageDir: true },
      { text: "\u201CA secure digital escrow bridge that holds payment safely \u2014 while your goods travel.", italic: true },
      { text: "The buyer is protected.", italic: true },
      { text: "The seller is guaranteed.", italic: true },
      { text: "Nobody has to go anywhere.", italic: true },
      { text: "The deal stays digital.", italic: true },
      { text: "Start. To. Finish.\u201D", italic: true },
    ]
  ),

  // ── SCENE 3 ────────────────────────────────────────────────
  buildSceneTable(
    3, "0:40 \u2013 1:10", "How It Works \u2014 Paid. Delivered. Done.", TEAL,
    [
      {
        label: "BEAT 1 \u2014 \u2018PAID\u2019",
        body: "Buyer taps \u2018Pay.\u2019 A glowing vault icon SNAPS shut around animated coins with a satisfying click. Both the buyer\u2019s and seller\u2019s phones light up with a \u2018Funds Secured \u2713\u2019 teal notification.",
      },
      {
        label: "BEAT 2 \u2014 \u2018DELIVERED\u2019",
        body: "Corporate Memphis courier \u2014 teal vest, confident stride \u2014 collects a package from the seller. A real-time tracking dot moves steadily across a stylized SADC map. Arrows animate the route.",
      },
      {
        label: "BEAT 3 \u2014 \u2018DONE\u2019",
        body: "Buyer taps \u2018Accept Delivery.\u2019 Vault BURSTS open. Animated coins split and flow simultaneously \u2014 right to seller, left to courier. \u2018INSTANT RELEASE \u26A1\u2019 label punches onto screen.",
      },
    ],
    [
      { text: "\u201CHere\u2019s how AnchorFlow works.\u201D" },
      { text: "[BEAT 1 drum hit]", stageDir: true },
      { text: "\u201CPAID \u2014 The buyer locks funds in escrow. The seller can\u2019t be stiffed. The buyer can\u2019t lose their money.\u201D", italic: true },
      { text: "[BEAT 2 drum hit]", stageDir: true },
      { text: "\u201CDELIVERED \u2014 A verified courier picks up and tracks the shipment, live.\u201D", italic: true },
      { text: "[BEAT 3 drum hit]", stageDir: true },
      { text: "\u201CDONE \u2014 Buyer confirms. Funds release instantly to seller and courier.", italic: true },
      { text: "No meetups.", italic: true },
      { text: "No risk.", italic: true },
      { text: "No drama.\u201D", italic: true },
    ]
  ),

  // ── SCENE 4 ────────────────────────────────────────────────
  buildSceneTable(
    4, "1:10 \u2013 1:25", "Empowerment \u2014 The Growth Engine", TEAL,
    [
      {
        label: "Opening",
        body: "Tight shot: a small home kitchen. A bold, warm Corporate Memphis baker icing a cake at a tiny table. Intimate, golden-hour lighting.",
      },
      {
        label: "The Zoom-Out",
        body: "Camera pulls back to reveal a stylized map of Southern Africa. Teal arrows radiate outward from her kitchen to customers across Zimbabwe, Zambia, Botswana, Mozambique. Each arrow pulses as a new order notification pings.",
      },
      {
        label: "The Growth Burst",
        body: "Customer counter animates: \u20181 \u2192 50 \u2192 500.\u2019 Additional micro-business icons bloom across the map \u2014 tailor, phone-repair tech, fresh produce vendor. Each connected by the same glowing teal trust-grid. Badge explodes: \u2018TRUST = UNLOCKED.\u2019",
      },
    ],
    [
      { text: "\u201CWhen trust is no longer a barrier \u2014\u201D", italic: true },
      { text: "[Music swells \u2014 melodic hook lifts]", stageDir: true },
      { text: "\u201CEvery hustle becomes a business.", italic: true },
      { text: "A baker in Harare ships to Bulawayo.", italic: true },
      { text: "A tailor in Lusaka reaches all of Zambia.", italic: true },
      { text: "A phone-repair shop in Gaborone serves the whole of SADC.", italic: true },
      { text: "AnchorFlow doesn\u2019t just process payments.", italic: true },
      { text: "It unlocks an economy.\u201D", italic: true },
    ]
  ),

  // ── SCENE 5 ────────────────────────────────────────────────
  buildSceneTable(
    5, "1:25 \u2013 1:30", "The Call to Action", TEAL,
    [
      {
        label: "Clean Cut",
        body: "Hard cut to pure Deep Navy (#1A2B3C). One beat of visual silence \u2014 nothing but the color.",
      },
      {
        label: "Logo Reveal",
        body: "AnchorFlow SYNCHRONIZED FEET logo pulses to center screen, glowing softly. Tagline fades in below: \u2018Paid. Delivered. Done.\u2019 in Vibrant Teal, Georgia italic.",
      },
      {
        label: "CTA Button",
        body: "A teal Indiegogo-style rounded button pulses with a soft glow: \u2018BACK US TODAY \u2192\u2019. Small white campaign URL appears beneath. Final hold: Logo + tagline + button for full 3-second end card.",
      },
    ],
    [
      { text: "[One beat of silence]", stageDir: true },
      { text: "\u201CAnchorFlow.\u201D", bold: true },
      { text: "[Single resonant teal piano chord]", stageDir: true },
      { text: "\u201CPaid.", bold: true, italic: true },
      { text: "Delivered.", bold: true, italic: true },
      { text: "Done.\u201D", bold: true, italic: true },
      { text: "\u201CBack us on Indiegogo today.\u201D", italic: true },
      { text: "[END CARD \u2014 Logo hold, 3 seconds. Music fades to silence.]", stageDir: true },
    ]
  ),
];

// ── Music Direction Table ─────────────────────────────────────
function buildMusicTable() {
  const sceneColors   = [ORANGE, DARKTEAL, TEAL, TEAL, TEAL];
  const sceneTimes    = ["0:00\u20130:20", "0:20\u20130:40", "0:40\u20131:10", "1:10\u20131:25", "1:25\u20131:30"];
  const sceneMoods    = [
    "Tense, dissonant. Low mbira drone layered under a stumbling, muted hip-hop beat. The rhythm feels \u2018broken\u2019 \u2014 reflecting the digital-to-analog regression. Muted bass. No melody.",
    "Pivot moment. Single clear piano note on logo entry. Then a confident Afrobeats-influenced tech groove builds steadily. Warmth enters the soundscape as the teal bridge appears.",
    "Full upbeat rhythmic tech track \u2014 tight and forward-moving. Each \u2018PAID / DELIVERED / DONE\u2019 beat lands on a sharp drum hit. Confident pulse. Reference: lo-fi Afrotech / Amapiano hybrid.",
    "Triumphant melodic swell. The bass line grows with each new customer arrow. Joyful, aspirational \u2014 the sound of an economy unlocking. Feels earned, not forced.",
    "Music resolves to a single resonant teal piano chord. One beat of complete silence precedes it \u2014 maximizes impact. Hold on logo. Fade out slowly.",
  ];

  // Header row
  const headerRow = new TableRow({
    tableHeader: true,
    children: [
      new TableCell({
        width: { size: 1800, type: WidthType.DXA },
        shading: { fill: NAVY, type: ShadingType.CLEAR },
        borders: cellBorders("2E4A60"),
        margins: { top: 100, bottom: 100, left: 140, right: 140 },
        children: [para(run("SCENE / TIMING", { size: 17, bold: true, color: WHITE, charSpacing: 20 }))],
      }),
      new TableCell({
        width: { size: 7560, type: WidthType.DXA },
        shading: { fill: NAVY, type: ShadingType.CLEAR },
        borders: cellBorders("2E4A60"),
        margins: { top: 100, bottom: 100, left: 140, right: 140 },
        children: [para(run("MOOD & MUSICAL DIRECTION", { size: 17, bold: true, color: WHITE, charSpacing: 20 }))],
      }),
    ],
  });

  const dataRows = [1, 2, 3, 4, 5].map((n, i) =>
    new TableRow({
      children: [
        new TableCell({
          width: { size: 1800, type: WidthType.DXA },
          shading: { fill: "F0F6F9", type: ShadingType.CLEAR },
          borders: cellBorders("C5D5E0"),
          margins: { top: 100, bottom: 100, left: 140, right: 140 },
          verticalAlign: VerticalAlign.TOP,
          children: [
            para(run(`Scene ${n}`, { size: 20, bold: true, color: sceneColors[i] }), { after: 30 }),
            para(run(sceneTimes[i], { size: 18, color: MUTED }), { after: 0 }),
          ],
        }),
        new TableCell({
          width: { size: 7560, type: WidthType.DXA },
          shading: { fill: WHITE, type: ShadingType.CLEAR },
          borders: cellBorders("C5D5E0"),
          margins: { top: 100, bottom: 100, left: 140, right: 140 },
          verticalAlign: VerticalAlign.TOP,
          children: [para(run(sceneMoods[i], { size: 20, color: TEXTDK }))],
        }),
      ],
    })
  );

  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [1800, 7560],
    rows: [headerRow, ...dataRows],
  });
}

// ── Color Palette Table ───────────────────────────────────────
function buildColorTable() {
  const swatches = [
    { hex: "1A2B3C", name: "Deep Navy",    usage: "Dark backgrounds, authority, end card" },
    { hex: "20C997", name: "Vibrant Teal", usage: "Brand, bridge, CTA buttons, all accents" },
    { hex: "FF6B35", name: "Alert Orange", usage: "Scene 1 frustration, glitch effect" },
    { hex: "FFFFFF", name: "Pure White",   usage: "Text on dark backgrounds, clean frames" },
    { hex: "EDF4F8", name: "Ice Blue",     usage: "Light background tones, digital world" },
  ];

  const headerRow = new TableRow({
    tableHeader: true,
    children: ["HEX CODE", "NAME", "USAGE"].map((label, idx) => {
      const widths = [1600, 2000, 5760];
      return new TableCell({
        width: { size: widths[idx], type: WidthType.DXA },
        shading: { fill: NAVY, type: ShadingType.CLEAR },
        borders: cellBorders("2E4A60"),
        margins: { top: 100, bottom: 100, left: 140, right: 140 },
        children: [para(run(label, { size: 17, bold: true, color: WHITE, charSpacing: 20 }))],
      });
    }),
  });

  const dataRows = swatches.map(({ hex, name, usage }) =>
    new TableRow({
      children: [
        new TableCell({
          width: { size: 1600, type: WidthType.DXA },
          shading: { fill: hex === "FFFFFF" ? "F0F6F9" : hex, type: ShadingType.CLEAR },
          borders: cellBorders("C5D5E0"),
          margins: { top: 100, bottom: 100, left: 140, right: 140 },
          children: [para(run(`#${hex}`, {
            size: 20, bold: true,
            color: ["1A2B3C", "FF6B35", "20C997"].includes(hex) ? WHITE : NAVY,
          }))],
        }),
        new TableCell({
          width: { size: 2000, type: WidthType.DXA },
          shading: { fill: "F5FAFB", type: ShadingType.CLEAR },
          borders: cellBorders("C5D5E0"),
          margins: { top: 100, bottom: 100, left: 140, right: 140 },
          children: [para(run(name, { size: 20, bold: true, color: TEXTDK }))],
        }),
        new TableCell({
          width: { size: 5760, type: WidthType.DXA },
          shading: { fill: WHITE, type: ShadingType.CLEAR },
          borders: cellBorders("C5D5E0"),
          margins: { top: 100, bottom: 100, left: 140, right: 140 },
          children: [para(run(usage, { size: 20, color: MUTED }))],
        }),
      ],
    })
  );

  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [1600, 2000, 5760],
    rows: [headerRow, ...dataRows],
  });
}

// ── Style Guide Note ──────────────────────────────────────────
function styleNotes() {
  const items = [
    ["Animation Style", "2D Vector / Corporate Memphis. Bold, simplified human figures. No gradients \u2014 flat color blocks only."],
    ["Typography (VO)",  "Clean sans-serif on screen titles. Georgia italic for the tagline. Calibri for data/UI elements."],
    ["Transitions",      "Scene 1\u21922: Hard glitch-cut. Scene 2\u21923: Smooth wipe. Scene 3\u21924: Dynamic push. Scene 4\u21925: Clean cut to navy."],
    ["VO Delivery",      "Warm, authoritative, unhurried. Slight Southern African accent welcome. Confident \u2014 not salesy."],
    ["Duration",         "Exactly 90 seconds. Scene 3 is the longest at 30 seconds \u2014 allow breathing room for each \u2018beat.\u2019"],
  ];
  return items.map(([label, note]) =>
    para([
      run(label + ":  ", { size: 20, bold: true, color: TEAL }),
      run(note, { size: 20, color: TEXTDK }),
    ], { after: 120 })
  );
}

// ═══════════════════════════════════════════════════════════════
// BUILD DOCUMENT
// ═══════════════════════════════════════════════════════════════
const doc = new Document({
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 }, // US Letter
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              children: [
                new TextRun({ text: "AnchorFlow \u2014 90-Second Cartoon Explainer Script", font: "Calibri", size: 16, color: MUTED }),
                new TextRun({ text: "\t", font: "Calibri", size: 16 }),
                new TextRun({ text: "Paid. Delivered. Done.", font: "Calibri", size: 16, italics: true, color: TEAL }),
              ],
              alignment: AlignmentType.LEFT,
              border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "C5D5E0" } },
            }),
          ],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              children: [
                new TextRun({ text: "Tandem Hive \u2014 Trust as an API  \u00B7  Indiegogo Campaign 2026", font: "Calibri", size: 16, color: MUTED }),
                new TextRun({ text: "\t", font: "Calibri", size: 16 }),
                new TextRun({ text: "Page ", font: "Calibri", size: 16, color: MUTED }),
                new TextRun({ children: [PageNumber.CURRENT], font: "Calibri", size: 16, color: MUTED }),
              ],
              alignment: AlignmentType.LEFT,
              border: { top: { style: BorderStyle.SINGLE, size: 4, color: "C5D5E0" } },
            }),
          ],
        }),
      },
      children: [

        // ── TITLE BLOCK ──────────────────────────────────────
        gap(200),
        new Paragraph({
          children: [run("AnchorFlow", { size: 72, bold: true, color: NAVY })],
          alignment: AlignmentType.LEFT,
          spacing: { before: 0, after: 120 },
        }),
        new Paragraph({
          children: [run("90-Second Cartoon Explainer Script", { size: 32, color: TEAL })],
          spacing: { before: 0, after: 200 },
        }),
        new Paragraph({
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "C5D5E0" } },
          children: [],
          spacing: { before: 0, after: 200 },
        }),
        new Paragraph({
          children: [run("Paid.  Delivered.  Done.", { size: 32, bold: false, italic: true, color: NAVY })],
          spacing: { before: 0, after: 120 },
        }),
        para([
          run("Visual Style:  ", { size: 20, bold: true, color: MUTED }),
          run("2D Vector Animation  \u00B7  Corporate Memphis", { size: 20, color: TEXTDK }),
          run("     |     ", { size: 20, color: MUTED }),
          run("Audience:  ", { size: 20, bold: true, color: MUTED }),
          run("Investors, Hustlers, Micro-businesses", { size: 20, color: TEXTDK }),
        ], { after: 80 }),
        para([
          run("Color Palette:  ", { size: 20, bold: true, color: MUTED }),
          run("Deep Navy #1A2B3C  +  Vibrant Teal #20C997", { size: 20, color: TEXTDK }),
          run("     |     ", { size: 20, color: MUTED }),
          run("Duration:  ", { size: 20, bold: true, color: MUTED }),
          run("Exactly 90 seconds", { size: 20, color: TEXTDK }),
        ], { after: 400 }),

        // ── SCENES ───────────────────────────────────────────
        ...scenes.flatMap((table, i) => [
          table,
          i < scenes.length - 1 ? gap(400) : gap(200),
        ]),

        // ── PAGE BREAK ───────────────────────────────────────
        new Paragraph({ children: [new PageBreak()] }),

        // ── PRODUCTION REFERENCE ─────────────────────────────
        new Paragraph({
          children: [run("Production Reference", { size: 40, bold: true, color: NAVY })],
          spacing: { before: 0, after: 80 },
        }),
        new Paragraph({
          children: [run("Music Direction  \u00B7  Color Palette  \u00B7  Style Notes", { size: 24, color: MUTED })],
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "C5D5E0" } },
          spacing: { before: 0, after: 300 },
        }),

        // Music section heading
        new Paragraph({
          children: [run("MUSIC DIRECTION", { size: 18, bold: true, color: TEAL, charSpacing: 40 })],
          spacing: { before: 0, after: 160 },
        }),
        buildMusicTable(),

        gap(360),

        // Color section heading
        new Paragraph({
          children: [run("COLOR PALETTE", { size: 18, bold: true, color: TEAL, charSpacing: 40 })],
          spacing: { before: 0, after: 160 },
        }),
        buildColorTable(),

        gap(360),

        // Style notes heading
        new Paragraph({
          children: [run("STYLE & PRODUCTION NOTES", { size: 18, bold: true, color: TEAL, charSpacing: 40 })],
          spacing: { before: 0, after: 160 },
        }),
        ...styleNotes(),
      ],
    },
  ],
});

// ── WRITE FILE ────────────────────────────────────────────────
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("AnchorFlow_Explainer_Script.docx", buf);
  console.log("\u2705  AnchorFlow_Explainer_Script.docx written successfully");
}).catch(err => {
  console.error("\u274C  Error:", err);
  process.exit(1);
});
