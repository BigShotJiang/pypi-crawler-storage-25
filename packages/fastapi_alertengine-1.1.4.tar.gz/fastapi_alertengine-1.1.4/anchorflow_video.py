"""
anchorflow_video.py
AnchorFlow — 90-Second Motion Graphics Explainer Video

Output : AnchorFlow_Explainer.mp4 (1280x720, 24fps)
Deps   : pip install "moviepy<2" Pillow numpy
"""

import math, random, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from moviepy.editor import VideoClip

# ── Config ────────────────────────────────────────────────────
W, H   = 1280, 720
FPS    = 24
TOTAL  = 90.0
FONTS  = "C:/Windows/Fonts/"
OUTPUT = "AnchorFlow_Explainer.mp4"

# ── Brand Colors (RGB) ────────────────────────────────────────
NAVY      = (26,  43,  60)
DARKNAVY  = (12,  22,  32)
TEAL      = (32,  201, 151)
DARKTEAL  = (23,  168, 127)
ORANGE    = (255, 107, 53)
WHITE     = (255, 255, 255)
LTBLUE    = (200, 225, 235)
MUTED     = (120, 160, 185)
DUSTY_BG  = (208, 192, 164)
DUSTY_FG  = (140, 110, 70)
GOLD      = (255, 210, 80)

# ── Fonts ────────────────────────────────────────────────────
def F(name, size):
    try:    return ImageFont.truetype(os.path.join(FONTS, name), size)
    except: return ImageFont.load_default()

Geo96 = F("georgiab.ttf",  96)
Geo72 = F("georgiab.ttf",  72)
Geo56 = F("georgiab.ttf",  56)
Geo44 = F("georgiab.ttf",  44)
Geo36 = F("georgiab.ttf",  36)
Geo28 = F("georgiai.ttf",  28)
Cal40 = F("calibrib.ttf",  40)
Cal34 = F("calibrib.ttf",  34)
Cal28 = F("calibri.ttf",   28)
Cal22 = F("calibri.ttf",   22)
Cal18 = F("calibri.ttf",   18)
Ari20 = F("arialbd.ttf",   20)

# ── Maths & Easing ───────────────────────────────────────────
def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def prog(t, a, b):
    """progress of t within window [a, b] → 0..1"""
    return clamp((t - a) / max(b - a, 1e-9))

def ease_out(x):
    return 1 - (1 - x) ** 3

def ease_in_out(x):
    return x * x * (3 - 2 * x)

def lerp(a, b, t):
    return a + (b - a) * t

def lerp_col(c1, c2, t):
    return tuple(int(lerp(c1[i], c2[i], clamp(t))) for i in range(3))

def alpha(col, a):
    """append alpha to RGB → RGBA"""
    return (*col, int(clamp(a) * 255))

# ── Drawing Helpers ───────────────────────────────────────────
def blank(col=NAVY):
    return Image.new("RGBA", (W, H), (*col, 255))

def draw_rect(d, x1, y1, x2, y2, fill, r=0, outline=None, ow=0):
    kw = dict(fill=fill)
    if outline: kw["outline"] = outline; kw["width"] = ow
    if r > 0:   d.rounded_rectangle([x1, y1, x2, y2], radius=r, **kw)
    else:        d.rectangle([x1, y1, x2, y2], **kw)

def center_text(d, text, y, font, col):
    bb = d.textbbox((0, 0), text, font=font)
    x  = (W - (bb[2] - bb[0])) // 2
    d.text((x, y), text, font=font, fill=col)

def right_align_text(d, text, y, font, col, margin=60):
    bb = d.textbbox((0, 0), text, font=font)
    x  = W - (bb[2] - bb[0]) - margin
    d.text((x, y), text, font=font, fill=col)

def text_w(d, text, font):
    bb = d.textbbox((0, 0), text, font=font)
    return bb[2] - bb[0]

def text_h(d, text, font):
    bb = d.textbbox((0, 0), text, font=font)
    return bb[3] - bb[1]

def glow_rect(img, x1, y1, x2, y2, col, blur=18):
    """Draw a glowing rectangle by blurring a color layer."""
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    ld.rounded_rectangle([x1-4, y1-4, x2+4, y2+4], radius=8, fill=(*col, 160))
    layer = layer.filter(ImageFilter.GaussianBlur(blur))
    img.paste(Image.new("RGBA", (W, H), (0, 0, 0, 0)), mask=layer.split()[3])
    img = Image.alpha_composite(img, layer)
    return img

def draw_circle_at(d, cx, cy, r, fill):
    d.ellipse([cx-r, cy-r, cx+r, cy+r], fill=fill)

# ── Characters (Corporate Memphis style) ─────────────────────
def draw_character(d, cx, by, skin, shirt, scale=1.0, direction=1):
    """Simple geometric human figure. by = bottom y."""
    s = scale
    hw = int(22*s)   # head half-width
    hh = int(26*s)   # head half-height
    bh = int(110*s)  # body height
    bw = int(34*s)   # body half-width
    lh = int(90*s)   # leg height
    ah = int(60*s)   # arm length

    hy = by - lh - bh - hh*2   # head top
    hy2 = hy + hh*2
    by2 = hy2 + bh
    # Head
    d.ellipse([cx-hw, hy, cx+hw, hy2], fill=skin)
    # Body
    draw_rect(d, cx-bw, hy2, cx+bw, by2, shirt, r=4)
    # Arms
    arm_y = hy2 + int(20*s)
    arm_end = arm_y + ah
    d.line([(cx - bw, arm_y), (cx - bw - int(direction*15*s), arm_end)], fill=skin, width=int(10*s))
    d.line([(cx + bw, arm_y), (cx + bw + int(direction*15*s), arm_end)], fill=skin, width=int(10*s))
    # Legs
    d.line([(cx - int(12*s), by2), (cx - int(18*s), by)], fill=(40, 35, 30), width=int(10*s))
    d.line([(cx + int(12*s), by2), (cx + int(18*s), by)], fill=(40, 35, 30), width=int(10*s))

# ── Courier character ─────────────────────────────────────────
def draw_courier(d, cx, by, t_walk):
    """Teal-vested courier with walking motion."""
    walk = math.sin(t_walk * 6) * 8
    draw_character(d, cx, by, (210, 175, 140), DARKTEAL, scale=0.95, direction=1)
    # Package under arm
    px = cx + 30; py = by - 90
    draw_rect(d, px, int(py + walk*0.3), px+44, int(py+36 + walk*0.3), GOLD, r=4)
    d.rectangle([px, int(py+14+walk*0.3), px+44, int(py+18+walk*0.3)], fill=DARKTEAL)

# ── Phone shape ───────────────────────────────────────────────
def draw_phone(d, cx, cy, screen_img=None, scale=1.0, glow_col=None):
    s = scale
    pw = int(200*s); ph = int(380*s)
    x1 = cx - pw//2;  y1 = cy - ph//2
    x2 = cx + pw//2;  y2 = cy + ph//2
    # Glow
    if glow_col:
        for i in range(5):
            exp = (5-i)*3
            draw_rect(d, x1-exp, y1-exp, x2+exp, y2+exp,
                      alpha(glow_col, 0.06), r=22+exp)
    # Body
    draw_rect(d, x1, y1, x2, y2, (245, 245, 255), r=20)
    draw_rect(d, x1+2, y1+2, x2-2, y2-2, WHITE, r=18)
    # Screen
    sx1=x1+10; sy1=y1+40; sx2=x2-10; sy2=y2-14
    if screen_img:
        s_crop = screen_img.resize((sx2-sx1, sy2-sy1))
        d._image.paste(s_crop, (sx1, sy1))
    else:
        draw_rect(d, sx1, sy1, sx2, sy2, (240, 248, 255), r=4)
    # Home button
    d.ellipse([cx-14, y2-28, cx+14, y2-2], fill=(220, 220, 230))

# ── Vault ────────────────────────────────────────────────────
def draw_vault(d, cx, cy, scale=1.0, locked=True, glow=0.0):
    s = scale
    w = int(120*s); h = int(130*s)
    x1=cx-w//2; y1=cy-h//2; x2=cx+w//2; y2=cy+h//2
    # Glow
    if glow > 0:
        for i in range(6):
            exp = (6-i)*4
            draw_rect(d, x1-exp, y1-exp, x2+exp, y2+exp,
                      alpha(TEAL, glow*0.07), r=14+exp)
    # Body
    draw_rect(d, x1, y1, x2, y2, NAVY, r=10)
    draw_rect(d, x1+4, y1+4, x2-4, y2-4, (35, 60, 85), r=8)
    # Door seam
    d.line([(cx, y1+10), (cx, y2-10)], fill=MUTED, width=3)
    # Handle
    hx = cx - int(20*s); hy = cy
    d.ellipse([hx-int(14*s), hy-int(14*s), hx+int(14*s), hy+int(14*s)],
              fill=(180, 200, 220), outline=TEAL, width=3)
    # Lock icon
    if locked:
        lx=cx+int(8*s); ly=cy-int(18*s); lw=int(22*s); lh=int(20*s)
        draw_rect(d, lx-lw//2, ly+int(8*s), lx+lw//2, ly+lh+int(8*s), TEAL, r=3)
        d.arc([lx-int(10*s), ly-int(8*s), lx+int(10*s), ly+int(10*s)],
              start=200, end=340, fill=TEAL, width=4)
    # Coin slots (when unlocked)
    else:
        for i in range(3):
            gy = y1 + int(25*s) + i * int(26*s)
            d.ellipse([cx-int(10*s), gy, cx+int(10*s), gy+int(14*s)], fill=GOLD)

# ── Coin ─────────────────────────────────────────────────────
def draw_coin(d, cx, cy, r=18):
    d.ellipse([cx-r, cy-r, cx+r, cy+r], fill=GOLD, outline=(200, 160, 30), width=2)
    d.text((cx-8, cy-10), "$", font=Cal22, fill=(140, 100, 10))

# ── Map (simplified southern Africa outline) ─────────────────
SA_POINTS = [
    (480,310),(500,290),(540,270),(580,255),(630,250),(680,248),(730,252),
    (780,260),(820,270),(855,285),(875,300),(890,320),(895,345),(885,375),
    (870,410),(855,445),(845,475),(835,500),(820,520),(800,535),(775,545),
    (750,550),(720,548),(700,540),(680,525),(660,510),(640,490),(620,475),
    (600,470),(575,465),(550,468),(525,472),(505,480),(490,472),(478,460),
    (465,445),(458,425),(452,405),(450,385),(452,360),(458,340),(465,322),(480,310),
]

def draw_sadc_map(d, ox=0, oy=0, col=MUTED, fill_col=None, scale=1.0):
    pts = [(int(x*scale+ox), int(y*scale+oy)) for x, y in SA_POINTS]
    if fill_col:
        d.polygon(pts, fill=fill_col, outline=col)
    else:
        d.polygon(pts, outline=col, fill=(0,0,0,0))

CITY_COORDS = {
    "Harare":    (720, 360),
    "Bulawayo":  (665, 430),
    "Lusaka":    (650, 320),
    "Gaborone":  (640, 450),
    "Maputo":    (780, 460),
}

# ── Arrow drawing ─────────────────────────────────────────────
def draw_arrow(d, x1, y1, x2, y2, col, width=3, head=10):
    d.line([(x1,y1),(x2,y2)], fill=col, width=width)
    # Arrowhead
    angle = math.atan2(y2-y1, x2-x1)
    for side in [0.4, -0.4]:
        ax = x2 - head*math.cos(angle-side)
        ay = y2 - head*math.sin(angle-side)
        d.line([(x2,y2),(int(ax),int(ay))], fill=col, width=width)

# ─────────────────────────────────────────────────────────────
# SCENE 1  The Irony  (0 – 20s)
# ─────────────────────────────────────────────────────────────
def scene1(t):
    rng = random.Random(int(t * 1000))  # deterministic per-frame RNG

    # ── Phase A: Digital marketplace (0-10s) ──────────────────
    if t < 10:
        p = prog(t, 0, 10)
        img = blank((30, 25, 15))
        d   = ImageDraw.Draw(img, "RGBA")

        # Warm golden background flooding in
        bg_p = ease_out(prog(t, 0, 2))
        warm = lerp_col((30, 25, 15), (255, 244, 210), bg_p)
        draw_rect(d, 0, 0, W, H, warm)

        # WhatsApp-green header bar
        if t > 0.5:
            hp = ease_out(prog(t, 0.5, 2.0))
            draw_rect(d, 0, 0, W, int(80*hp), (37, 211, 102), r=0)
            if hp > 0.8:
                d.text((24, 24), "WhatsApp Marketplace", font=Cal34, fill=WHITE)

        # Product cards sliding in
        cards = [
            (60,  100, 580, 310, (255, 100, 80),  "🌽  Fresh Produce",   "$8"),
            (640, 100, 1220,310, (80,  160, 255),  "📱  Electronics",     "$45"),
            (60,  340, 580, 540, (50,  200, 120),  "👗  Fashion",         "$22"),
            (640, 340, 1220,540, TEAL,              "🔧  Services",        "$15"),
        ]
        for i, (x1, y1, x2, y2, col, label, price) in enumerate(cards):
            cp = ease_out(prog(t, 0.3 + i*0.35, 2.5 + i*0.2))
            if cp > 0:
                slide_y = int(50*(1-cp))
                draw_rect(d, x1, y1+slide_y, x2, y2+slide_y, alpha(col, cp), r=14)
                draw_rect(d, x1+8, y1+slide_y+8, x2-8, y2+slide_y-8,
                          alpha(WHITE, cp*0.9), r=10)
                if cp > 0.6:
                    ta = clamp(cp*3 - 1.5)
                    d.text((x1+20, y1+slide_y+20), label, font=Cal34, fill=alpha((30,30,30), ta))
                    # Price badge
                    draw_rect(d, x2-90, y1+slide_y+12, x2-12, y1+slide_y+50,
                              alpha(col, ta), r=8)
                    d.text((x2-78, y1+slide_y+18), price, font=Cal28, fill=alpha(WHITE, ta))

        # "BUY NOW!" button + character (center, foreground)
        if t > 3.5:
            bp = ease_out(prog(t, 3.5, 5.5))
            bx1, by1, bx2, by2 = W//2-130, 590, W//2+130, 650
            draw_rect(d, bx1, int(by1+40*(1-bp)), bx2, int(by2+40*(1-bp)),
                      alpha(ORANGE, bp), r=12)
            if bp > 0.7:
                center_text(d, "BUY NOW!  →", int(600+40*(1-bp))+4, Cal40, alpha(WHITE, bp))

        # Big character tapping phone (enters from right)
        if t > 4.5:
            ep = ease_out(prog(t, 4.5, 6.5))
            cx = int(W + 200 - (W//2 + 320)*ep)
            draw_character(d, cx, H-20, (220, 175, 130), (80, 160, 255), scale=1.1)
            # Phone in hand
            if ep > 0.6:
                phx = cx + 55; phy = H - 280
                draw_rect(d, phx, phy, phx+60, phy+110, (230,230,245), r=8)
                draw_rect(d, phx+5, phy+12, phx+55, phy+100, (255,245,200), r=4)
                d.text((phx+5, phy+40), "BUY", font=Cal22, fill=ORANGE)

        # VO text
        if t > 7:
            vp = ease_in_out(prog(t, 7, 9.5))
            lines = ['"You found the perfect deal."',
                     'On your phone. In seconds.']
            for i, line in enumerate(lines):
                lp = clamp(vp*3 - i*1.0)
                if lp > 0:
                    center_text(d, line, 620 + i*44, Geo28,
                                alpha(lerp_col(ORANGE, (60,35,10), 0.4), lp))

    # ── Phase B: GLITCH (10-13s) ──────────────────────────────
    elif t < 13:
        p = prog(t, 10, 13)
        img = blank((255, 244, 210))
        arr = np.array(img)
        # Horizontal slice distortion
        n_slices = int(p * 35)
        for _ in range(n_slices):
            y  = rng.randint(0, H-4)
            ht = rng.randint(2, 18)
            sh = rng.randint(-70, 70)
            col = rng.choice([(255,0,80,255), (0,220,180,255), (255,160,0,255), (80,100,255,255)])
            arr[y:y+ht, :] = col
            if abs(sh) > 0:
                arr[y:y+ht, :] = np.roll(arr[y:y+ht, :], sh, axis=1)
        # Dark vignette building
        fade_p = ease_in_out(prog(t, 11.5, 13))
        if fade_p > 0:
            dark = np.zeros((H, W, 4), dtype=np.uint8)
            dark[:, :, 3] = 255  # fully opaque black
            arr = (arr * (1-fade_p) + dark * fade_p).astype(np.uint8)
        img = Image.fromarray(arr)
        d = ImageDraw.Draw(img, "RGBA")
        # "CRACK" flash
        if p > 0.25 and p < 0.65:
            cp = math.sin(prog(p, 0.25, 0.65) * math.pi)
            center_text(d, "✕  TRUST GAP  ✕", H//2-28, Geo44, alpha(ORANGE, cp))
        # Glitch lines
        for _ in range(int(p*8)):
            y = rng.randint(0, H)
            d.line([(0, y), (W, y)], fill=alpha(TEAL, 0.4), width=1)

    # ── Phase C: Street corner (13-20s) ──────────────────────
    else:
        p = prog(t, 13, 20)
        img = blank(DUSTY_BG)
        d   = ImageDraw.Draw(img, "RGBA")

        # Dusty sky gradient (top third)
        for row in range(280):
            frac = row / 280
            c = lerp_col((220, 210, 190), DUSTY_BG, frac)
            d.line([(0, row), (W, row)], fill=c)

        # Ground
        draw_rect(d, 0, H-110, W, H, (150, 130, 95))
        d.line([(0, H-110), (W, H-110)], fill=(120, 100, 70), width=4)

        # Road markings
        for i in range(8):
            rx = 120 + i*160
            draw_rect(d, rx, H-78, rx+80, H-62, (180, 170, 140))

        # Petrol station (right side)
        if p > 0.08:
            sp = ease_out(prog(p, 0.08, 0.45))
            sx = int(900 + 180*(1-sp))
            # Canopy
            draw_rect(d, sx, 160, sx+220, 190, (160, 45, 45))
            draw_rect(d, sx, 190, sx+220, 400, (240, 230, 210), r=4)
            d.text((sx+18, 210), "CALTEX", font=Cal28, fill=(160, 45, 45))
            d.text((sx+18, 252), "PETROL", font=Cal28, fill=DUSTY_FG)
            # Pumps
            for pi in range(2):
                px = sx + 30 + pi*90
                draw_rect(d, px, 310, px+50, 395, (200, 190, 170), r=4)
                draw_rect(d, px+10, 320, px+40, 350, (240, 80, 60), r=2)
            # Pole
            d.line([(sx+110, 400), (sx+110, H-110)], fill=(130, 120, 100), width=5)

        # Character 1 — buyer (left, arrives)
        if p > 0.15:
            cp1 = ease_out(prog(p, 0.15, 0.55))
            cx1 = int(lerp(W+100, 300, cp1))
            draw_character(d, cx1, H-20, (230, 185, 140), (80, 140, 220),
                           scale=1.0, direction=1)

        # Character 2 — seller (right, approaches)
        if p > 0.25:
            cp2 = ease_out(prog(p, 0.25, 0.65))
            cx2 = int(lerp(-100, 870, cp2))
            draw_character(d, cx2, H-20, (190, 155, 115), (170, 110, 50),
                           scale=1.0, direction=-1)

        # Question marks (confusion cloud)
        if p > 0.55:
            qp = ease_in_out(prog(p, 0.55, 0.75))
            for qi, (qx, qy) in enumerate([(305, H-380), (865, H-385), (580, H-420)]):
                d.text((qx, qy), "?", font=Geo44,
                       fill=alpha(DUSTY_FG, qp * (0.6 + qi*0.15)))

        # "2 HOURS LATER" overlay
        if t > 17:
            hl = ease_in_out(prog(t, 17, 18.5))
            draw_rect(d, 0, H//2-55, W, H//2+55, alpha(DARKNAVY, hl*0.82))
            if hl > 0.3:
                center_text(d, "2 HOURS LATER", H//2-30, Geo44,
                            alpha(ORANGE, hl))

        # VO text
        if t > 15 and t < 17.5:
            vp = prog(t, 15, 17)
            lines = [
                '"...waiting for a stranger."',
                "In Southern Africa, the deal lives online —",
                "but the trust lives in the real world.",
            ]
            for i, ln in enumerate(lines):
                lp = clamp(vp * 4 - i * 0.8)
                d.text((60, 50 + i*52), ln, font=Cal28,
                       fill=alpha(DUSTY_FG, lp * 0.85))

    return np.array(img.convert("RGB"))


# ─────────────────────────────────────────────────────────────
# SCENE 2  Introducing AnchorFlow  (20 – 40s)
# ─────────────────────────────────────────────────────────────
def scene2(t):
    img = blank(DARKNAVY)
    d   = ImageDraw.Draw(img, "RGBA")

    # ── Fade from dusty to navy (20-22s) ──────────────────────
    if t < 22:
        fp = ease_in_out(prog(t, 20, 22))
        draw_rect(d, 0, 0, W, H, alpha(NAVY, fp))

    # ── Teal ambient glow pulse ────────────────────────────────
    pulse = 0.5 + 0.5 * math.sin((t - 22) * 1.4)
    cx = W // 2
    for r_i in range(6, 0, -1):
        gr = r_i * 80
        draw_circle_at(d, cx, H//2+30, gr, alpha(TEAL, 0.018 * pulse * (7-r_i)))

    # ── AnchorFlow logo text (22-27s) ─────────────────────────
    if t > 22:
        lp = ease_out(prog(t, 22, 25.5))
        # Teal "feet" (two stepping triangles)
        foot_y = H//2 - 80
        f1x = int(lerp(-120, W//2 - 230, ease_out(prog(t, 22, 24.5))))
        f2x = int(lerp(W+120, W//2 + 120, ease_out(prog(t, 22.4, 25.0))))
        for fx, flip in [(f1x, 1), (f2x, -1)]:
            pts = [
                (fx,         foot_y),
                (fx + 80*flip, foot_y),
                (fx + 50*flip, foot_y + 55),
                (fx - 10*flip, foot_y + 55),
            ]
            d.polygon(pts, fill=alpha(TEAL, lp * 0.85))
            d.polygon(pts, outline=alpha(WHITE, lp * 0.4), width=2)
        # "·" step line
        if lp > 0.6:
            sl = clamp((lp - 0.6) / 0.4)
            mid_x1 = W//2 - 100
            mid_x2 = int(lerp(mid_x1, W//2 + 100, sl))
            d.line([(mid_x1, foot_y + 65), (mid_x2, foot_y + 65)],
                   fill=alpha(TEAL, sl), width=3)

        # Logo word-mark
        tw = text_w(d, "AnchorFlow", Geo72)
        logo_y = H//2 - 18
        # Shadow
        d.text((W//2 - tw//2 + 3, logo_y + 3), "AnchorFlow",
               font=Geo72, fill=alpha(DARKNAVY, lp * 0.6))
        # Main text
        d.text((W//2 - tw//2, logo_y), "AnchorFlow",
               font=Geo72, fill=alpha(WHITE, lp))
        # Tagline
        if lp > 0.7:
            tp = clamp((lp - 0.7) / 0.3)
            center_text(d, "Trust  ·  As an API", H//2 + 70, Geo28,
                        alpha(TEAL, tp))

    # ── Bridge drawing (27-37s) ───────────────────────────────
    if t > 27:
        bp = ease_out(prog(t, 27, 36))

        # Left phone (buyer)
        if t > 27.5:
            pp = ease_out(prog(t, 27.5, 29.5))
            phx = int(lerp(-130, 90, pp))
            draw_rect(d, phx, H//2 - 100, phx+90, H//2 + 130, (230,235,250), r=10)
            draw_rect(d, phx+6, H//2-88, phx+84, H//2+118, (100,200,255), r=6)
            d.text((phx+10, H//2-50), "BUYER", font=Cal22, fill=WHITE)
            if pp > 0.8:
                d.text((phx+6, H//2+10), "✓ Paid", font=Cal22, fill=GOLD)

        # Right phone (seller)
        if t > 28.5:
            pp = ease_out(prog(t, 28.5, 30.5))
            phx = int(lerp(W+130, W-180, pp))
            draw_rect(d, phx, H//2 - 100, phx+90, H//2 + 130, (230,235,250), r=10)
            draw_rect(d, phx+6, H//2-88, phx+84, H//2+118, (50,200,140), r=6)
            d.text((phx+8, H//2-50), "SELLER", font=Cal22, fill=WHITE)
            if pp > 0.8:
                d.text((phx+6, H//2+10), "✓ Ready", font=Cal22, fill=GOLD)

        # Teal bridge arc (draws progressively)
        arc_steps = int(bp * 200)
        arc_cx = W // 2
        arc_cy = H // 2 + 120
        arc_rx = 440
        arc_ry = 90
        if arc_steps > 1:
            pts = []
            for i in range(arc_steps + 1):
                angle = math.pi + (i / 200) * math.pi  # 0 → π
                x = arc_cx + arc_rx * math.cos(angle)
                y = arc_cy - arc_ry * math.sin(angle)
                pts.append((int(x), int(y)))
            for i in range(len(pts)-1):
                frac = i / max(len(pts)-1, 1)
                col  = lerp_col(ORANGE, TEAL, frac)
                d.line([pts[i], pts[i+1]], fill=col, width=7)

        # Traveling data nodes
        if bp > 0.3:
            for ni in range(4):
                nt  = ((t - 27) * 0.45 + ni * 0.25) % 1.0
                if nt > bp: continue
                angle = math.pi + nt * math.pi
                nx = arc_cx + arc_rx * math.cos(angle)
                ny = arc_cy - arc_ry * math.sin(angle)
                draw_circle_at(d, int(nx), int(ny), 8, alpha(WHITE, 0.9))
                draw_circle_at(d, int(nx), int(ny), 4, TEAL)

        # "Introducing AnchorFlow." text reveal
        if t > 36:
            rp = ease_in_out(prog(t, 36, 38))
            center_text(d, '"A secure digital bridge for every deal."',
                        H - 130, Cal34, alpha(LTBLUE, rp))

    return np.array(img.convert("RGB"))


# ─────────────────────────────────────────────────────────────
# SCENE 3  How It Works  (40 – 70s)
# ─────────────────────────────────────────────────────────────
def scene3(t):
    img = blank(NAVY)
    d   = ImageDraw.Draw(img, "RGBA")

    # Subtle grid background
    for xi in range(0, W, 80):
        d.line([(xi, 0), (xi, H)], fill=alpha(TEAL, 0.04))
    for yi in range(0, H, 80):
        d.line([(0, yi), (W, yi)], fill=alpha(TEAL, 0.04))

    # ── Intro text (40-43s) ───────────────────────────────────
    if t < 43:
        ip = ease_in_out(prog(t, 40, 42.5))
        center_text(d, "Here's how AnchorFlow works.", H//2-20, Geo44,
                    alpha(WHITE, ip))
        if ip > 0.7:
            center_text(d, "Paid.  Delivered.  Done.", H//2+50, Geo36,
                        alpha(TEAL, (ip-0.7)/0.3))
        return np.array(img.convert("RGB"))

    # BEAT labels (persistent)
    beats     = ["PAID", "DELIVERED", "DONE"]
    beat_cols = [TEAL, DARKTEAL, ORANGE]
    beat_x    = [200, 640, 1080]
    beat_win  = [(43, 53), (53, 62), (62, 70)]

    # Determine active beat
    active = -1
    for i, (bs, be) in enumerate(beat_win):
        if t >= bs: active = i

    # Beat column tabs
    for i, (label, col, bx) in enumerate(zip(beats, beat_cols, beat_x)):
        is_active = (i == active)
        tab_a  = 1.0 if is_active else 0.35
        tab_y1 = 50; tab_y2 = 100
        draw_rect(d, bx-140, tab_y1, bx+140, tab_y2,
                  alpha(col, tab_a), r=8)
        center_text_at = lambda tx, text, ty, font, c: \
            d.text((tx - text_w(d,text,font)//2, ty), text, font=font, fill=c)
        center_text_at(bx, label, tab_y1+14, Cal34, alpha(NAVY, tab_a))

    # ── BEAT 1: PAID (43-53s) ─────────────────────────────────
    if t < 53:
        p = prog(t, 43, 53)

        # Vault sliding in
        vault_x = int(lerp(W+200, W//2, ease_out(prog(p, 0.0, 0.4))))
        vault_y = H//2 - 40
        locked  = prog(p, 0.5, 0.65) < 1.0
        glow_v  = ease_in_out(prog(p, 0.45, 0.7))
        draw_vault(d, vault_x, vault_y, scale=1.3, locked=locked, glow=glow_v)

        # Coins flying into vault
        if p > 0.25 and p < 0.7:
            cp = prog(p, 0.25, 0.7)
            for ci in range(5):
                ct = (cp * 5 - ci * 0.4) % 1.0
                if ct < 0 or ct > 1: continue
                fp = ease_in_out(ct)
                cx_c = int(lerp(200 + ci*60, vault_x, fp))
                cy_c = int(lerp(H - 180, vault_y, fp))
                draw_coin(d, cx_c, cy_c, r=int(lerp(22, 8, fp)))

        # "Funds Secured ✓" notification
        if p > 0.55:
            np_ = ease_out(prog(p, 0.55, 0.8))
            for ni, (nx, ny) in enumerate([(160, H-220), (W-360, H-220)]):
                draw_rect(d, nx, ny, nx+280, ny+70, alpha(DARKNAVY, np_*0.95), r=10)
                draw_rect(d, nx, ny, nx+6,   ny+70, alpha(TEAL, np_), r=0)
                if np_ > 0.4:
                    d.text((nx+16, ny+10), "Funds Secured ✓", font=Cal28,
                           fill=alpha(TEAL, np_))
                    d.text((nx+16, ny+38), "Your money is safe", font=Cal22,
                           fill=alpha(LTBLUE, np_*0.7))

        # VO
        if p > 0.7:
            vp = ease_in_out(prog(p, 0.7, 1.0))
            lines = ['"PAID — The buyer locks funds in escrow.',
                     'Nobody can cheat."']
            for i, ln in enumerate(lines):
                center_text(d, ln, H-120+i*42, Cal28, alpha(LTBLUE, vp))

    # ── BEAT 2: DELIVERED (53-62s) ────────────────────────────
    elif t < 62:
        p = prog(t, 53, 62)

        # Map background
        map_ox, map_oy = W//2 - 200, H//2 - 220
        draw_sadc_map(d, map_ox, map_oy, col=alpha(MUTED, 0.4),
                      fill_col=alpha((30, 55, 80), 0.6), scale=0.9)

        # Seller location (origin)
        d.text((map_ox + 190, map_oy + 100), "⬤  SELLER", font=Cal22, fill=ORANGE)

        # Courier + route
        if p > 0.2:
            rp  = ease_out(prog(p, 0.2, 0.85))
            # Route line
            rx1, ry1 = map_ox+220, map_oy+130
            rx2, ry2 = map_ox+350, map_oy+230
            ex = int(lerp(rx1, rx2, rp))
            ey = int(lerp(ry1, ry2, rp))
            d.line([(rx1,ry1),(ex,ey)], fill=alpha(TEAL,0.8), width=4)
            # Courier figure
            draw_courier(d, ex, ey+60, t*3.0)
            # Pulsing dot
            dp = 0.5 + 0.5*math.sin(t*6)
            draw_circle_at(d, ex, ey, int(8+dp*4), alpha(TEAL, 0.6))
            draw_circle_at(d, ex, ey, 6, WHITE)

        # LIVE label
        lbp = ease_in_out(prog(p, 0.3, 0.6))
        if lbp > 0:
            draw_rect(d, W-200, 130, W-40, 170, alpha((200,30,30), lbp*0.9), r=6)
            d.text((W-188, 137), "⬤  LIVE", font=Cal28, fill=alpha(WHITE, lbp))

        # VO
        if p > 0.75:
            vp = ease_in_out(prog(p, 0.75, 1.0))
            center_text(d, '"DELIVERED — Courier picks up and tracks live."',
                        H-90, Cal28, alpha(LTBLUE, vp))

    # ── BEAT 3: DONE (62-70s) ─────────────────────────────────
    else:
        p = prog(t, 62, 70)

        # Vault (open)
        draw_vault(d, W//2, H//2-30, scale=1.2, locked=False, glow=0.8)

        # Coins splitting left and right
        if p > 0.2:
            sp = ease_out(prog(p, 0.2, 0.85))
            # Left stream (seller)
            for ci in range(6):
                ct = clamp(sp*3 - ci*0.25)
                if ct <= 0: continue
                cx_c = int(lerp(W//2, 150 + ci*40, ease_out(ct)))
                cy_c = int(lerp(H//2-30, H//2 + 120 + ci*18, ease_out(ct)))
                draw_coin(d, cx_c, cy_c, r=int(lerp(14, 10, ct)))
            # Right stream (courier)
            for ci in range(4):
                ct = clamp(sp*3 - ci*0.25 - 0.4)
                if ct <= 0: continue
                cx_c = int(lerp(W//2, W-200 + ci*30, ease_out(ct)))
                cy_c = int(lerp(H//2-30, H//2 + 140 + ci*18, ease_out(ct)))
                draw_coin(d, cx_c, cy_c, r=int(lerp(12, 9, ct)))

        # Labels
        if p > 0.5:
            lp = ease_in_out(prog(p, 0.5, 0.85))
            d.text((60, H//2+160), "SELLER", font=Cal34, fill=alpha(TEAL, lp))
            d.text((W-210, H//2+160), "COURIER", font=Cal34, fill=alpha(TEAL, lp))

        # "INSTANT RELEASE" badge
        if p > 0.6:
            rp = ease_out(prog(p, 0.6, 0.85))
            draw_rect(d, W//2-200, 140, W//2+200, 200, alpha(TEAL, rp*0.9), r=10)
            center_text(d, "⚡  INSTANT RELEASE  ⚡", 150, Cal34, alpha(NAVY, rp))

        # VO
        if p > 0.8:
            vp = ease_in_out(prog(p, 0.8, 1.0))
            lines = ['"DONE — Buyer confirms. Funds release instantly.',
                     'No meetups. No risk. No drama."']
            for i, ln in enumerate(lines):
                center_text(d, ln, H-110+i*40, Cal28, alpha(LTBLUE, vp))

    return np.array(img.convert("RGB"))


# ─────────────────────────────────────────────────────────────
# SCENE 4  Empowerment  (70 – 85s)
# ─────────────────────────────────────────────────────────────
def scene4(t):
    img = blank(NAVY)
    d   = ImageDraw.Draw(img, "RGBA")

    p_full = prog(t, 70, 85)

    # ── Baker kitchen (70-75s) ────────────────────────────────
    if t < 76:
        kp = ease_out(prog(t, 70, 73.5))

        # Kitchen background
        draw_rect(d, 0, 0, W, H, lerp_col(DARKNAVY, (35, 28, 18), kp))
        # Table
        draw_rect(d, W//2-350, H-160, W//2+350, H-110, alpha((90,70,45), kp), r=4)
        # Cake
        if kp > 0.3:
            cp = ease_out(prog(prog(t,70,73.5), 0.3, 1.0))
            bx = W//2-60; by = H-240
            draw_rect(d, bx, by, bx+120, H-160, alpha((220,120,80), cp), r=6)
            draw_rect(d, bx, by-30, bx+120, by, alpha((245,200,180), cp), r=6)
            d.ellipse([bx+50, by-58, bx+70, by-28], fill=alpha(TEAL, cp))  # candle
            if cp > 0.8:
                draw_circle_at(d, bx+60, by-62, 6, alpha(GOLD, cp))  # flame

        # Baker character
        if kp > 0.4:
            bp = ease_out(prog(prog(t,70,73.5), 0.4, 1.0))
            draw_character(d, W//2-160, H-20, (210,175,135), (255,220,180),
                           scale=1.05, direction=1)
            # Chef hat
            chx = W//2-160
            draw_rect(d, chx-28, H-420, chx+28, H-380, alpha(WHITE, bp), r=4)
            draw_rect(d, chx-20, H-450, chx+20, H-420, alpha(WHITE, bp*0.9), r=8)

        # "When trust is no longer a barrier —" reveal
        if t > 73:
            vp = ease_in_out(prog(t, 73, 75))
            center_text(d, '"When trust is no longer a barrier —"',
                        60, Geo36, alpha(WHITE, vp))
            if vp > 0.6:
                center_text(d, "every hustle becomes a business.",
                            116, Geo28, alpha(TEAL, (vp-0.6)/0.4))

    # ── Map + arrows expanding (75-83s) ──────────────────────
    else:
        ap = prog(t, 75, 83)

        # Soft BG for map section
        draw_rect(d, 0, 0, W, H, (18, 30, 45))

        # Map
        mx, my = W//2-185, H//2-185
        draw_sadc_map(d, mx, my, col=alpha(MUTED, 0.5),
                      fill_col=alpha((25, 50, 70), 0.7), scale=0.85)

        # Origin star (Harare)
        hx, hy = mx + int(720*0.85) - 205, my + int(360*0.85) - 185
        hx, hy = W//2 - 8, H//2 - 12  # approximate center of map
        draw_circle_at(d, hx, hy, 12, ORANGE)
        d.text((hx+16, hy-10), "Harare", font=Cal22, fill=ORANGE)

        # Radiating arrows (stagger)
        arrow_targets = [
            (hx-220, hy+100, "Bulawayo"),
            (hx-260, hy-90,  "Lusaka"),
            (hx+200, hy-100, "Maputo"),
            (hx-60,  hy+160, "Gaborone"),
            (hx+300, hy+50,  "Beira"),
        ]
        for i, (tx, ty, city) in enumerate(arrow_targets):
            arr_p = ease_out(prog(ap, i*0.1, i*0.1+0.5))
            if arr_p <= 0: continue
            ex = int(lerp(hx, tx, arr_p))
            ey = int(lerp(hy, ty, arr_p))
            d.line([(hx, hy), (ex, ey)], fill=alpha(TEAL, arr_p*0.9), width=3)
            # Dot at tip
            draw_circle_at(d, ex, ey, 7, alpha(TEAL, arr_p))
            if arr_p > 0.9:
                d.text((ex+10, ey-10), city, font=Cal18, fill=alpha(WHITE, arr_p))
            # Pulse ring
            ring_p = (t * 2 + i * 0.4) % 1.0
            ring_r = int(ring_p * 30)
            d.ellipse([ex-ring_r, ey-ring_r, ex+ring_r, ey+ring_r],
                      outline=alpha(TEAL, (1-ring_p)*0.5), width=2)

        # Customer counter
        if ap > 0.5:
            cp = prog(ap, 0.5, 0.9)
            val = int(lerp(1, 500, ease_in_out(cp)))
            center_text(d, f"{val}+ customers", H-180, Geo56, alpha(WHITE, cp*1.2))
            center_text(d, "and growing ↗", H-110, Cal34, alpha(TEAL, cp))

        # "TRUST = UNLOCKED" badge
        if ap > 0.85:
            ulp = ease_out(prog(ap, 0.85, 1.0))
            bw = 480; bh = 70
            draw_rect(d, W//2-bw//2, 50, W//2+bw//2, 50+bh, alpha(TEAL, ulp*0.95), r=12)
            center_text(d, "TRUST  =  UNLOCKED  🔓", 64, Cal40, alpha(NAVY, ulp))

    return np.array(img.convert("RGB"))


# ─────────────────────────────────────────────────────────────
# SCENE 5  The CTA  (85 – 90s)
# ─────────────────────────────────────────────────────────────
def scene5(t):
    img = blank(DARKNAVY)
    d   = ImageDraw.Draw(img, "RGBA")

    p = prog(t, 85, 90)

    # Ambient teal pulse
    pulse = 0.4 + 0.6 * math.sin((t - 85) * 2.2)
    for ri in range(5, 0, -1):
        draw_circle_at(d, W//2, H//2-20, ri*80, alpha(TEAL, 0.015 * pulse * (6-ri)))

    # Logo (85.5 → 87s)
    if t > 85.5:
        lp = ease_out(prog(t, 85.5, 87.0))
        # Feet
        fy = H//2 - 100
        for fx, flip in [(W//2-130, 1), (W//2+50, -1)]:
            pts = [(fx, fy), (fx+70*flip, fy),
                   (fx+44*flip, fy+48), (fx-8*flip, fy+48)]
            d.polygon(pts, fill=alpha(TEAL, lp))
        # Wordmark
        tw = text_w(d, "AnchorFlow", Geo72)
        d.text((W//2-tw//2+3, H//2-22+3), "AnchorFlow",
               font=Geo72, fill=alpha(DARKNAVY, lp*0.5))
        d.text((W//2-tw//2, H//2-22), "AnchorFlow",
               font=Geo72, fill=alpha(WHITE, lp))

    # Tagline (87 → 88.2s)
    if t > 87:
        tp = ease_in_out(prog(t, 87, 88.2))
        center_text(d, "Paid.  Delivered.  Done.", H//2+60, Geo44,
                    alpha(TEAL, tp))

    # CTA button pulse (88.2 → 90s)
    if t > 88.2:
        bp = ease_out(prog(t, 88.2, 89.2))
        btn_pulse = 0.88 + 0.12 * math.sin((t-88.2)*5)
        bw = int(380 * btn_pulse)
        bh = int(70  * btn_pulse)
        draw_rect(d, W//2-bw//2, H//2+130, W//2+bw//2, H//2+130+bh,
                  alpha(TEAL, bp * 0.95), r=12)
        if bp > 0.5:
            center_text(d, "BACK US ON INDIEGOGO  →", H//2+148, Cal34,
                        alpha(NAVY, bp))

        # URL
        if t > 89:
            up = ease_in_out(prog(t, 89, 90))
            center_text(d, "anchorflow.io", H//2+225, Cal28, alpha(MUTED, up))

    return np.array(img.convert("RGB"))


# ─────────────────────────────────────────────────────────────
# MASTER FRAME DISPATCHER
# ─────────────────────────────────────────────────────────────
def make_frame(t):
    # Cross-fade boundary helpers
    def blend_scenes(frame_a, frame_b, blend_t, blend_dur):
        alpha_f = ease_in_out(prog(blend_t, 0, blend_dur))
        arr_a = frame_a.astype(np.float32)
        arr_b = frame_b.astype(np.float32)
        return (arr_a * (1-alpha_f) + arr_b * alpha_f).astype(np.uint8)

    if t < 20:
        return scene1(t)
    elif t < 21:
        # 1-second cross-fade 20→21
        return blend_scenes(scene1(t), scene2(t), t-20, 1.0)
    elif t < 40:
        return scene2(t)
    elif t < 41:
        return blend_scenes(scene2(t), scene3(t), t-40, 1.0)
    elif t < 70:
        return scene3(t)
    elif t < 71:
        return blend_scenes(scene3(t), scene4(t), t-70, 1.0)
    elif t < 85:
        return scene4(t)
    elif t < 86:
        return blend_scenes(scene4(t), scene5(t), t-85, 1.0)
    else:
        return scene5(t)


# ─────────────────────────────────────────────────────────────
# RENDER
# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"Rendering {TOTAL}s @ {FPS}fps -> {W}x{H}  [{int(TOTAL*FPS)} frames]")
    print("This will take a few minutes ...\n")

    clip = VideoClip(make_frame, duration=TOTAL)
    clip.write_videofile(
        OUTPUT,
        fps        = FPS,
        codec      = "libx264",
        audio      = False,
        preset     = "medium",
        ffmpeg_params=["-crf", "22"],
        logger     = "bar",
    )
    print(f"\nDone! Saved: {OUTPUT}")
