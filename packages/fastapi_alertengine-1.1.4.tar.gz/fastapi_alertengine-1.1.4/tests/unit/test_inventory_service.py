"""
Unit tests for app/services/inventory_service.py

Covers:
- add_or_update_item(): create, upsert, audit log written
- get_item(): returns item; raises ValueError on unknown SKU
- list_items(): all items; in_stock_only filter
- get_catalogue(): delegates to list_items(in_stock_only=True)
- search_items(): case-insensitive substring; no match → empty list
- reserve_stock(): increments quantity_reserved; raises on insufficient stock
- release_reservation(): decrements quantity_reserved; floors at zero
- confirm_sale(): decrements available + reserved; increments sold
- get_low_stock_items(): quantity_available <= reorder_level
- send_low_stock_alerts(): calls notifier; logs to EscrowStateLog; counts correctly
- Audit log content (EscrowStateLog rows) for every mutating operation
"""

import pytest
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.database import Base, EscrowStateLog, MerchantInventory
from app.services import inventory_service


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture(scope="function")
def db():
    """In-memory SQLite session, re-created per test."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()
    Base.metadata.drop_all(engine)


@pytest.fixture
def merchant():
    return "0772123456"


@pytest.fixture
def sample_item(db, merchant):
    """A persisted inventory item for use in stock-mutation tests."""
    return inventory_service.add_or_update_item(
        db,
        merchant_phone     = merchant,
        sku                = "IPHONE13",
        item_name          = "iPhone 13",
        price              = Decimal("450.00"),
        quantity_available = 10,
        reorder_level      = 3,
    )


# ─────────────────────────────────────────────────────────────────────────────
# add_or_update_item — create
# ─────────────────────────────────────────────────────────────────────────────


class TestAddOrUpdateItemCreate:
    def test_returns_merchant_inventory_instance(self, db, merchant):
        item = inventory_service.add_or_update_item(
            db, merchant, "SKU1", "Widget", Decimal("10.00"), 5
        )
        assert isinstance(item, MerchantInventory)

    def test_fields_stored_correctly(self, db, merchant):
        item = inventory_service.add_or_update_item(
            db,
            merchant_phone     = merchant,
            sku                = "SKU2",
            item_name          = "Gadget",
            price              = Decimal("99.99"),
            quantity_available = 20,
            reorder_level      = 4,
            item_description   = "A cool gadget",
            item_picture_url   = "https://example.com/pic.jpg",
        )
        assert item.merchant_phone   == merchant
        assert item.sku              == "SKU2"
        assert item.item_name        == "Gadget"
        assert item.price            == Decimal("99.99")
        assert item.quantity_available == 20
        assert item.reorder_level    == 4
        assert item.item_description == "A cool gadget"
        assert item.item_picture_url == "https://example.com/pic.jpg"

    def test_initial_reserved_and_sold_are_zero(self, db, merchant):
        item = inventory_service.add_or_update_item(
            db, merchant, "SKU3", "Doohickey", Decimal("5.00"), 3
        )
        assert item.quantity_reserved == 0
        assert item.quantity_sold     == 0

    def test_quantity_free_equals_available_when_no_reservations(self, db, merchant):
        item = inventory_service.add_or_update_item(
            db, merchant, "SKU4", "Thingamajig", Decimal("15.00"), 8
        )
        assert item.quantity_free == 8

    def test_audit_log_written_on_create(self, db, merchant):
        item = inventory_service.add_or_update_item(
            db, merchant, "SKU5", "Whatsit", Decimal("7.50"), 2
        )
        logs = db.query(EscrowStateLog).filter_by(triggered_by="inventory_updated").all()
        assert len(logs) == 1
        assert logs[0].escrow_id is None   # inventory event has no escrow


# ─────────────────────────────────────────────────────────────────────────────
# add_or_update_item — upsert
# ─────────────────────────────────────────────────────────────────────────────


class TestAddOrUpdateItemUpsert:
    def test_upsert_updates_name_price_quantity(self, db, merchant, sample_item):
        updated = inventory_service.add_or_update_item(
            db,
            merchant_phone     = merchant,
            sku                = "IPHONE13",
            item_name          = "iPhone 13 Pro",
            price              = Decimal("500.00"),
            quantity_available = 15,
        )
        assert updated.id              == sample_item.id   # same row
        assert updated.item_name       == "iPhone 13 Pro"
        assert updated.price           == Decimal("500.00")
        assert updated.quantity_available == 15

    def test_upsert_does_not_reset_reserved_qty(self, db, merchant, sample_item):
        """Reserved counter must survive an inventory update."""
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=2)
        inventory_service.add_or_update_item(
            db, merchant, "IPHONE13", "iPhone 13", Decimal("450.00"), 20
        )
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_reserved == 2

    def test_upsert_does_not_reset_sold_qty(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=1)
        inventory_service.confirm_sale(db, merchant, "IPHONE13", quantity=1)
        inventory_service.add_or_update_item(
            db, merchant, "IPHONE13", "iPhone 13", Decimal("450.00"), 20
        )
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_sold == 1

    def test_upsert_only_one_db_row(self, db, merchant, sample_item):
        inventory_service.add_or_update_item(
            db, merchant, "IPHONE13", "iPhone 13", Decimal("450.00"), 5
        )
        count = db.query(MerchantInventory).filter_by(
            merchant_phone=merchant, sku="IPHONE13"
        ).count()
        assert count == 1

    def test_audit_log_written_on_upsert(self, db, merchant, sample_item):
        inventory_service.add_or_update_item(
            db, merchant, "IPHONE13", "iPhone 13", Decimal("450.00"), 5
        )
        logs = db.query(EscrowStateLog).filter_by(triggered_by="inventory_updated").all()
        assert len(logs) == 2   # one on create, one on update


# ─────────────────────────────────────────────────────────────────────────────
# get_item
# ─────────────────────────────────────────────────────────────────────────────


class TestGetItem:
    def test_returns_correct_item(self, db, merchant, sample_item):
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.id == sample_item.id

    def test_raises_value_error_for_unknown_sku(self, db, merchant):
        with pytest.raises(ValueError, match="not found"):
            inventory_service.get_item(db, merchant, "NOSUCHSKU")

    def test_raises_value_error_for_wrong_merchant(self, db, merchant, sample_item):
        with pytest.raises(ValueError):
            inventory_service.get_item(db, "0799999999", "IPHONE13")


# ─────────────────────────────────────────────────────────────────────────────
# list_items / get_catalogue / search_items
# ─────────────────────────────────────────────────────────────────────────────


class TestListAndSearch:
    def _add(self, db, merchant, sku, name, qty):
        return inventory_service.add_or_update_item(
            db, merchant, sku, name, Decimal("10.00"), qty
        )

    def test_list_items_returns_all(self, db, merchant):
        self._add(db, merchant, "A", "Alpha", 5)
        self._add(db, merchant, "B", "Beta",  0)
        items = inventory_service.list_items(db, merchant)
        assert len(items) == 2

    def test_list_items_in_stock_only_excludes_zero_free(self, db, merchant):
        self._add(db, merchant, "A", "Alpha", 5)
        self._add(db, merchant, "B", "Beta",  0)
        items = inventory_service.list_items(db, merchant, in_stock_only=True)
        assert len(items) == 1
        assert items[0].sku == "A"

    def test_list_items_scoped_to_merchant(self, db, merchant):
        self._add(db, merchant, "A", "Alpha", 5)
        self._add(db, "0799000000", "A", "Alpha", 5)
        items = inventory_service.list_items(db, merchant)
        assert len(items) == 1

    def test_get_catalogue_returns_in_stock_only(self, db, merchant):
        self._add(db, merchant, "A", "Alpha", 5)
        self._add(db, merchant, "B", "Beta",  0)
        catalogue = inventory_service.get_catalogue(db, merchant)
        skus = [i.sku for i in catalogue]
        assert "A" in skus
        assert "B" not in skus

    def test_search_items_finds_by_substring(self, db, merchant):
        self._add(db, merchant, "IP13", "iPhone 13",   5)
        self._add(db, merchant, "IP14", "iPhone 14",   3)
        self._add(db, merchant, "AP",   "AirPods Pro", 2)
        results = inventory_service.search_items(db, merchant, "iphone")
        assert len(results) == 2

    def test_search_items_case_insensitive(self, db, merchant):
        self._add(db, merchant, "IP13", "iPhone 13", 5)
        results = inventory_service.search_items(db, merchant, "IPHONE")
        assert len(results) == 1

    def test_search_items_empty_on_no_match(self, db, merchant):
        self._add(db, merchant, "IP13", "iPhone 13", 5)
        results = inventory_service.search_items(db, merchant, "samsung")
        assert results == []

    def test_search_items_only_returns_in_stock(self, db, merchant):
        self._add(db, merchant, "IP13", "iPhone 13", 0)
        results = inventory_service.search_items(db, merchant, "iphone")
        assert results == []


# ─────────────────────────────────────────────────────────────────────────────
# reserve_stock
# ─────────────────────────────────────────────────────────────────────────────


class TestReserveStock:
    def test_increments_reserved_by_quantity(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=3)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_reserved == 3

    def test_quantity_free_decreases_after_reserve(self, db, merchant, sample_item):
        before = sample_item.quantity_free
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=2)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_free == before - 2

    def test_raises_when_insufficient_stock(self, db, merchant, sample_item):
        with pytest.raises(ValueError, match="Insufficient stock"):
            inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=100)

    def test_raises_when_exactly_out_of_stock(self, db, merchant):
        inventory_service.add_or_update_item(
            db, merchant, "ZERO", "Empty Item", Decimal("1.00"), 0
        )
        with pytest.raises(ValueError):
            inventory_service.reserve_stock(db, merchant, "ZERO", quantity=1)

    def test_audit_log_written(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=1)
        logs = db.query(EscrowStateLog).filter_by(triggered_by="inventory_reserved").all()
        assert len(logs) == 1

    def test_audit_log_contains_deal_id(self, db, merchant, sample_item):
        inventory_service.reserve_stock(
            db, merchant, "IPHONE13", quantity=1, deal_id="ABC12"
        )
        log = db.query(EscrowStateLog).filter_by(triggered_by="inventory_reserved").first()
        import json
        meta = json.loads(log.metadata_json)
        assert meta["deal_id"] == "ABC12"


# ─────────────────────────────────────────────────────────────────────────────
# release_reservation
# ─────────────────────────────────────────────────────────────────────────────


class TestReleaseReservation:
    def test_decrements_reserved(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=3)
        inventory_service.release_reservation(db, merchant, "IPHONE13", quantity=2)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_reserved == 1

    def test_floors_reserved_at_zero(self, db, merchant, sample_item):
        """Releasing more than reserved should not go negative."""
        inventory_service.release_reservation(db, merchant, "IPHONE13", quantity=999)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_reserved == 0

    def test_quantity_free_increases_after_release(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=3)
        before_free = inventory_service.get_item(db, merchant, "IPHONE13").quantity_free
        inventory_service.release_reservation(db, merchant, "IPHONE13", quantity=2)
        after_free = inventory_service.get_item(db, merchant, "IPHONE13").quantity_free
        assert after_free == before_free + 2

    def test_audit_log_written(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=1)
        inventory_service.release_reservation(db, merchant, "IPHONE13", quantity=1)
        logs = db.query(EscrowStateLog).filter_by(triggered_by="inventory_released").all()
        assert len(logs) == 1


# ─────────────────────────────────────────────────────────────────────────────
# confirm_sale
# ─────────────────────────────────────────────────────────────────────────────


class TestConfirmSale:
    def test_decrements_available(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=1)
        inventory_service.confirm_sale(db, merchant, "IPHONE13", quantity=1)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_available == 9   # 10 − 1

    def test_decrements_reserved(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=2)
        inventory_service.confirm_sale(db, merchant, "IPHONE13", quantity=2)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_reserved == 0

    def test_increments_sold(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=3)
        inventory_service.confirm_sale(db, merchant, "IPHONE13", quantity=3)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_sold == 3

    def test_multiple_sales_accumulate(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=2)
        inventory_service.confirm_sale(db, merchant, "IPHONE13", quantity=1)
        inventory_service.confirm_sale(db, merchant, "IPHONE13", quantity=1)
        item = inventory_service.get_item(db, merchant, "IPHONE13")
        assert item.quantity_sold == 2

    def test_audit_log_written(self, db, merchant, sample_item):
        inventory_service.reserve_stock(db, merchant, "IPHONE13", quantity=1)
        inventory_service.confirm_sale(db, merchant, "IPHONE13", quantity=1)
        logs = db.query(EscrowStateLog).filter_by(triggered_by="inventory_sold").all()
        assert len(logs) == 1


# ─────────────────────────────────────────────────────────────────────────────
# get_low_stock_items
# ─────────────────────────────────────────────────────────────────────────────


class TestGetLowStockItems:
    def test_returns_items_at_or_below_reorder_level(self, db, merchant):
        inventory_service.add_or_update_item(
            db, merchant, "LOW",  "Low Item",  Decimal("1.00"), 3,  reorder_level=5
        )
        inventory_service.add_or_update_item(
            db, merchant, "OK",   "OK Item",   Decimal("1.00"), 10, reorder_level=5
        )
        low = inventory_service.get_low_stock_items(db, merchant_phone=merchant)
        assert len(low) == 1
        assert low[0].sku == "LOW"

    def test_returns_empty_when_all_above_reorder(self, db, merchant):
        inventory_service.add_or_update_item(
            db, merchant, "OK", "OK Item", Decimal("1.00"), 20, reorder_level=5
        )
        assert inventory_service.get_low_stock_items(db, merchant_phone=merchant) == []

    def test_no_merchant_filter_returns_all_merchants(self, db, merchant):
        inventory_service.add_or_update_item(
            db, merchant, "A", "Alpha", Decimal("1.00"), 1, reorder_level=5
        )
        inventory_service.add_or_update_item(
            db, "0799000001", "B", "Beta", Decimal("1.00"), 1, reorder_level=5
        )
        low = inventory_service.get_low_stock_items(db)
        assert len(low) == 2


# ─────────────────────────────────────────────────────────────────────────────
# send_low_stock_alerts
# ─────────────────────────────────────────────────────────────────────────────


class TestSendLowStockAlerts:
    def _setup_low_item(self, db, merchant):
        return inventory_service.add_or_update_item(
            db, merchant, "LOW", "Low Item", Decimal("5.00"), 2, reorder_level=5
        )

    def test_returns_checked_count(self, db, merchant):
        self._setup_low_item(db, merchant)
        result = inventory_service.send_low_stock_alerts(db, merchant_phone=merchant)
        assert result["checked"] == 1

    def test_returns_alerts_sent_zero_when_no_notifier(self, db, merchant):
        self._setup_low_item(db, merchant)
        result = inventory_service.send_low_stock_alerts(db, merchant_phone=merchant)
        assert result["alerts_sent"] == 0

    def test_calls_notifier_for_each_low_item(self, db, merchant):
        self._setup_low_item(db, merchant)
        calls = []
        def notifier(phone, msg):
            calls.append((phone, msg))
            return True
        inventory_service.send_low_stock_alerts(db, notifier=notifier, merchant_phone=merchant)
        assert len(calls) == 1
        assert calls[0][0] == merchant

    def test_returns_alerts_sent_count_on_success(self, db, merchant):
        self._setup_low_item(db, merchant)
        result = inventory_service.send_low_stock_alerts(
            db,
            notifier       = lambda phone, msg: True,
            merchant_phone = merchant,
        )
        assert result["alerts_sent"] == 1

    def test_alert_logged_to_escrow_state_log(self, db, merchant):
        self._setup_low_item(db, merchant)
        inventory_service.send_low_stock_alerts(db, merchant_phone=merchant)
        logs = db.query(EscrowStateLog).filter_by(triggered_by="low_stock_alert").all()
        assert len(logs) == 1
        assert logs[0].escrow_id is None

    def test_alert_message_contains_sku(self, db, merchant):
        self._setup_low_item(db, merchant)
        messages = []
        inventory_service.send_low_stock_alerts(
            db,
            notifier       = lambda phone, msg: messages.append(msg) or True,
            merchant_phone = merchant,
        )
        assert "LOW" in messages[0]

    def test_no_alerts_when_all_above_reorder(self, db, merchant):
        inventory_service.add_or_update_item(
            db, merchant, "OK", "OK Item", Decimal("1.00"), 20, reorder_level=5
        )
        result = inventory_service.send_low_stock_alerts(
            db,
            notifier       = lambda phone, msg: True,
            merchant_phone = merchant,
        )
        assert result["checked"]     == 0
        assert result["alerts_sent"] == 0

    def test_failed_notifier_does_not_raise(self, db, merchant):
        self._setup_low_item(db, merchant)
        def bad_notifier(phone, msg):
            raise RuntimeError("Twilio is down")
        # Should complete without raising
        result = inventory_service.send_low_stock_alerts(
            db, notifier=bad_notifier, merchant_phone=merchant
        )
        assert result["checked"] == 1
        assert result["alerts_sent"] == 0
