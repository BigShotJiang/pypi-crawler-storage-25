# tests/unit/test_courier_fence.py
"""Tests for app.core.courier_fence — init_fence, get_fence_token, atomic_accept."""

import json
from unittest.mock import MagicMock, patch, call

import pytest

from app.core.courier_fence import (
    _fence_key,
    _lock_key,
    _SCRIPT_CACHE,
    init_fence,
    get_fence_token,
    atomic_accept,
)


# ─── Key helpers ──────────────────────────────────────────────────────────────

class TestKeyHelpers:
    def test_fence_key_format(self):
        assert _fence_key("TDM-123") == "bot:courier_fence:TDM-123"

    def test_lock_key_format(self):
        assert _lock_key("TDM-123") == "bot:courier_accept:TDM-123"


# ─── init_fence ───────────────────────────────────────────────────────────────

class TestInitFence:
    def test_sets_fence_with_setnx(self):
        rdb = MagicMock()
        init_fence(rdb, "DEAL-1")
        rdb.setnx.assert_called_once_with("bot:courier_fence:DEAL-1", "0")

    def test_sets_expire_after_setnx(self):
        rdb = MagicMock()
        init_fence(rdb, "DEAL-1", ttl=600)
        rdb.expire.assert_called_once_with("bot:courier_fence:DEAL-1", 600)

    def test_default_ttl_is_1800(self):
        rdb = MagicMock()
        init_fence(rdb, "DEAL-1")
        rdb.expire.assert_called_once_with("bot:courier_fence:DEAL-1", 1800)

    def test_never_raises_on_redis_error(self):
        rdb = MagicMock()
        rdb.setnx.side_effect = Exception("Redis down")
        init_fence(rdb, "DEAL-1")   # must not raise


# ─── get_fence_token ──────────────────────────────────────────────────────────

class TestGetFenceToken:
    def test_returns_string_for_bytes_value(self):
        rdb = MagicMock()
        rdb.get.return_value = b"3"
        assert get_fence_token(rdb, "DEAL-1") == "3"

    def test_returns_string_for_string_value(self):
        rdb = MagicMock()
        rdb.get.return_value = "5"
        assert get_fence_token(rdb, "DEAL-1") == "5"

    def test_returns_none_when_key_missing(self):
        rdb = MagicMock()
        rdb.get.return_value = None
        assert get_fence_token(rdb, "DEAL-1") is None

    def test_returns_none_on_redis_error(self):
        rdb = MagicMock()
        rdb.get.side_effect = Exception("conn error")
        assert get_fence_token(rdb, "DEAL-1") is None

    def test_reads_fence_key(self):
        rdb = MagicMock()
        rdb.get.return_value = b"0"
        get_fence_token(rdb, "TDM-999")
        rdb.get.assert_called_once_with("bot:courier_fence:TDM-999")


# ─── atomic_accept — Lua path ─────────────────────────────────────────────────

class TestAtomicAcceptLuaPath:
    def _rdb_with_script(self, script_result):
        """Return a mock rdb where register_script returns a callable returning script_result."""
        rdb = MagicMock()
        # Clear any cached script for this mock
        _SCRIPT_CACHE.pop(id(rdb), None)
        mock_script = MagicMock(return_value=script_result)
        rdb.register_script.return_value = mock_script
        return rdb, mock_script

    def test_lua_ok_returns_ok_and_payload(self):
        rdb, script = self._rdb_with_script(b"ok")
        status, payload = atomic_accept(rdb, "DEAL-1", "+263771234567", "0")
        assert status == "ok"
        assert payload is not None
        assert payload["courier_phone"] == "+263771234567"

    def test_lua_taken_returns_taken_none(self):
        rdb, _ = self._rdb_with_script(b"taken")
        status, payload = atomic_accept(rdb, "DEAL-1", "+263771234567", "0")
        assert status == "taken"
        assert payload is None

    def test_lua_stale_returns_stale_none(self):
        rdb, _ = self._rdb_with_script(b"stale")
        status, payload = atomic_accept(rdb, "DEAL-1", "+263771234567", "0")
        assert status == "stale"
        assert payload is None

    def test_lua_script_called_with_correct_keys_and_args(self):
        rdb, script = self._rdb_with_script(b"ok")
        atomic_accept(rdb, "DEAL-2", "+263779999999", "2", ttl=300)
        script.assert_called_once()
        _, kwargs = script.call_args
        assert kwargs["keys"][0] == "bot:courier_fence:DEAL-2"
        assert kwargs["keys"][1] == "bot:courier_accept:DEAL-2"
        assert kwargs["args"][0] == "2"
        assert kwargs["args"][2] == "300"


# ─── atomic_accept — NX fallback ─────────────────────────────────────────────

class TestAtomicAcceptNXFallback:
    def _rdb_no_script(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.register_script.side_effect = Exception("Lua not supported")
        return rdb

    def test_no_fence_token_uses_nx_fallback(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.setnx.return_value = True
        status, payload = atomic_accept(rdb, "DEAL-1", "+263771111111", expected_fence=None)
        assert status == "ok"
        rdb.setnx.assert_called_once()

    def test_nx_fallback_taken_when_setnx_returns_false(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.setnx.return_value = False
        status, payload = atomic_accept(rdb, "DEAL-1", "+263771111111", expected_fence=None)
        assert status == "taken"
        assert payload is None

    def test_nx_fallback_sets_expire_on_success(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.setnx.return_value = True
        atomic_accept(rdb, "DEAL-1", "+263771111111", expected_fence=None, ttl=900)
        rdb.expire.assert_called_once_with("bot:courier_accept:DEAL-1", 900)

    def test_nx_fallback_returns_error_on_exception(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.setnx.side_effect = Exception("Redis down")
        status, payload = atomic_accept(rdb, "DEAL-1", "+263771111111", expected_fence=None)
        assert status == "error"
        assert payload is None


# ─── atomic_accept — payload structure ───────────────────────────────────────

class TestAtomicAcceptPayload:
    def test_ok_payload_contains_courier_phone(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.setnx.return_value = True
        _, payload = atomic_accept(rdb, "DEAL-1", "+263777654321", expected_fence=None)
        assert payload["courier_phone"] == "+263777654321"

    def test_ok_payload_contains_assigned_at(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.setnx.return_value = True
        with patch("time.time", return_value=1700000000.0):
            _, payload = atomic_accept(rdb, "DEAL-1", "+263777654321", expected_fence=None)
        assert payload["assigned_at"] == 1700000000000

    def test_ok_payload_contains_fence_token(self):
        rdb = MagicMock()
        _SCRIPT_CACHE.pop(id(rdb), None)
        rdb.setnx.return_value = True
        _, payload = atomic_accept(rdb, "DEAL-1", "+263777654321", expected_fence=None)
        assert "fence_token" in payload
