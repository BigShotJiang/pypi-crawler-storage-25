# tests/unit/test_idempotency.py
"""Tests for app.core.idempotency — TTL constants and log_idempotency_event."""

from unittest.mock import MagicMock, call, patch

import pytest

from app.core.idempotency import (
    TTL_ACTIVE_DEAL,
    TTL_ACTIVE_SESSION,
    TTL_CATALOGUE,
    TTL_COURIER_JOB_MAX,
    TTL_DEAL_DEDUP,
    TTL_DEDUP_MESSAGE,
    TTL_DEGRADED_MODE,
    TTL_IDLE_SESSION,
    TTL_LEDGER,
    TTL_PAYMENT_LOCK,
    TTL_STATE_LOCK,
    STREAM_MAXLEN_IDEMPOTENCY,
    STREAM_MAXLEN_METRICS,
    log_idempotency_event,
)


# ─── TTL constant contracts ───────────────────────────────────────────────────

class TestTTLConstants:
    def test_all_ttls_are_positive_integers(self):
        ttls = [
            TTL_ACTIVE_SESSION, TTL_IDLE_SESSION, TTL_STATE_LOCK,
            TTL_DEDUP_MESSAGE, TTL_PAYMENT_LOCK, TTL_DEAL_DEDUP,
            TTL_ACTIVE_DEAL, TTL_LEDGER, TTL_COURIER_JOB_MAX,
            TTL_CATALOGUE, TTL_DEGRADED_MODE,
        ]
        for ttl in ttls:
            assert isinstance(ttl, int), f"Expected int, got {type(ttl)}"
            assert ttl > 0, f"Expected positive, got {ttl}"

    def test_active_session_longer_than_idle(self):
        assert TTL_ACTIVE_SESSION > TTL_IDLE_SESSION

    def test_state_lock_is_short(self):
        # Must be short enough to prevent deadlocks
        assert TTL_STATE_LOCK <= 30

    def test_payment_lock_is_at_least_one_hour(self):
        assert TTL_PAYMENT_LOCK >= 3600

    def test_stream_maxlen_are_positive(self):
        assert STREAM_MAXLEN_IDEMPOTENCY > 0
        assert STREAM_MAXLEN_METRICS > 0

    def test_metrics_stream_larger_than_idempotency(self):
        assert STREAM_MAXLEN_METRICS > STREAM_MAXLEN_IDEMPOTENCY

    def test_courier_job_max_shorter_than_active_session(self):
        assert TTL_COURIER_JOB_MAX < TTL_ACTIVE_SESSION


# ─── log_idempotency_event ────────────────────────────────────────────────────

class TestLogIdempotencyEvent:
    def _mock_rdb(self):
        rdb = MagicMock()
        rdb.xadd.return_value = b"1234-0"
        return rdb

    def test_calls_xadd_with_correct_stream(self):
        rdb = self._mock_rdb()
        log_idempotency_event(rdb, "payment_dedup", "payment_processed:REF123")
        rdb.xadd.assert_called_once()
        args, kwargs = rdb.xadd.call_args
        assert args[0] == "idempotency:events"

    def test_fields_include_event_type_and_key(self):
        rdb = self._mock_rdb()
        log_idempotency_event(rdb, "message_dedup", "msg:SID123")
        _, kwargs = rdb.xadd.call_args
        # fields dict is second positional arg
        args, _ = rdb.xadd.call_args
        fields = args[1]
        assert fields["event_type"] == "message_dedup"
        assert fields["key"] == "msg:SID123"

    def test_fields_include_timestamp(self):
        rdb = self._mock_rdb()
        with patch("time.time", return_value=1700000000.0):
            log_idempotency_event(rdb, "test", "k")
        args, _ = rdb.xadd.call_args
        fields = args[1]
        assert "ts" in fields
        assert fields["ts"] == "1700000000000"

    def test_metadata_values_coerced_to_strings(self):
        rdb = self._mock_rdb()
        log_idempotency_event(rdb, "test", "k", metadata={"count": 42, "flag": True})
        args, _ = rdb.xadd.call_args
        fields = args[1]
        assert fields["count"] == "42"
        assert fields["flag"] == "True"

    def test_metadata_keys_coerced_to_strings(self):
        rdb = self._mock_rdb()
        log_idempotency_event(rdb, "test", "k", metadata={1: "val"})
        args, _ = rdb.xadd.call_args
        fields = args[1]
        assert "1" in fields

    def test_no_metadata_still_works(self):
        rdb = self._mock_rdb()
        log_idempotency_event(rdb, "test", "k")
        rdb.xadd.assert_called_once()

    def test_maxlen_passed_to_xadd(self):
        rdb = self._mock_rdb()
        log_idempotency_event(rdb, "test", "k")
        _, kwargs = rdb.xadd.call_args
        assert kwargs.get("maxlen") == STREAM_MAXLEN_IDEMPOTENCY

    def test_approximate_trimming_enabled(self):
        rdb = self._mock_rdb()
        log_idempotency_event(rdb, "test", "k")
        _, kwargs = rdb.xadd.call_args
        assert kwargs.get("approximate") is True

    def test_never_raises_on_xadd_failure(self):
        rdb = MagicMock()
        rdb.xadd.side_effect = Exception("Redis is down")
        # Should not raise
        log_idempotency_event(rdb, "test", "k", metadata={"x": "y"})

    def test_never_raises_on_any_redis_error(self):
        import redis as redis_lib
        rdb = MagicMock()
        rdb.xadd.side_effect = redis_lib.exceptions.ConnectionError("conn refused")
        log_idempotency_event(rdb, "test", "k")   # must not raise
