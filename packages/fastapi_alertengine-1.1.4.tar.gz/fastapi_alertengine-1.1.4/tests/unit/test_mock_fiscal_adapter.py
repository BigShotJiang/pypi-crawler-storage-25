# url=https://github.com/Tandem-Media/Tandem_Hive_V1_Final/blob/copilot/update-escrow-model/tests/unit/test_mock_fiscal_adapter.py
"""
Unit tests for MockFiscalAdapter.

Tests cover:
- Fiscal entry generation with unique codes
- VAT calculations (15.5%)
- Tax report aggregation
- Date range filtering
- Error handling (fail_on_pattern)
- Edge cases (empty ranges, large amounts, precision)
- Integration scenarios (multiple recipients, chronological ordering)
"""

import pytest
from decimal import Decimal
from datetime import datetime, date, timedelta
from app.adapters.mock_fiscal_adapter import MockFiscalAdapter
from app.adapters.fiscal_adapter import FiscalError


# ─────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────���───────────────────────────────


@pytest.fixture
def fiscal_adapter():
    """Fresh MockFiscalAdapter for each test."""
    return MockFiscalAdapter()


@pytest.fixture
def fiscal_adapter_with_fail_pattern():
    """MockFiscalAdapter configured to fail on specific pattern."""
    return MockFiscalAdapter(fail_on_pattern="FAIL")


@pytest.fixture
def base_transaction():
    """Template transaction for testing."""
    return {
        "settlement_id": 1,
        "recipient_type": "merchant",
        "recipient_id": "MERCHANT_001",
        "gross_commission": Decimal("5.50"),
        "vat_rate": Decimal("15.5"),
        "transaction_date": datetime(2026, 3, 3, 14, 2, 0),
        "reference_id": "ESC-1001",
    }


# ─────────────────────────────────────────────────────────────────
# Test: Fiscal Entry Generation - Basic Functionality
# ─────────────────────────────────────────────────────────────────


class TestFiscalEntryGeneration:
    """Tests for generate_fiscal_entry() method."""
    
    def test_generates_fiscal_entry_with_required_fields(self, fiscal_adapter, base_transaction):
        """Fiscal entry must contain all required fields."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert result["success"] is True
        assert "fiscal_auth_code" in result
        assert "z_number" in result
        assert "tax_invoice_number" in result
        assert "timestamp" in result
        assert "raw_response" in result
    
    def test_fiscal_auth_code_format(self, fiscal_adapter, base_transaction):
        """Fiscal auth code must follow MOCK-{UUID} pattern."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        auth_code = result["fiscal_auth_code"]
        assert auth_code.startswith("MOCK-")
        assert len(auth_code) == 17  # "MOCK-" (5) + 12 hex chars
    
    def test_z_number_format(self, fiscal_adapter, base_transaction):
        """Z-number must follow Z-{YYYYMMDD}-{settlement_id} pattern."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        z_number = result["z_number"]
        assert z_number.startswith("Z-20260303-")
        assert z_number == "Z-20260303-000001"
    
    def test_tax_invoice_number_format(self, fiscal_adapter, base_transaction):
        """Tax invoice number must follow TIN-{settlement_id}-{recipient_type}-{UUID} pattern."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        tin = result["tax_invoice_number"]
        assert tin.startswith("TIN-1-merchant-")
        assert len(tin) > 15  # TIN-1-merchant- (14) + 8 hex chars
    
    def test_generates_unique_codes_per_entry(self, fiscal_adapter, base_transaction):
        """Each fiscal entry must have unique codes."""
        result1 = fiscal_adapter.generate_fiscal_entry(base_transaction)
        result2 = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert result1["fiscal_auth_code"] != result2["fiscal_auth_code"]
        assert result1["tax_invoice_number"] != result2["tax_invoice_number"]
    
    def test_timestamp_is_iso_format(self, fiscal_adapter, base_transaction):
        """Timestamp must be ISO 8601 formatted."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        timestamp = result["timestamp"]
        # Verify it can be parsed as ISO format
        datetime.fromisoformat(timestamp)


# ─────────────────────────────────────────────────────────────────
# Test: VAT Calculation
# ─────────────────────────────────────────────────────────────────


class TestVATCalculation:
    """Tests for correct VAT calculation (15.5% of gross commission)."""
    
    def test_vat_calculation_standard_rate(self, fiscal_adapter, base_transaction):
        """VAT should be 15.5% of gross commission."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        raw = result["raw_response"]
        gross = Decimal(raw["gross_commission"])
        vat = Decimal(raw["vat_amount"])
        
        expected_vat = gross * Decimal("0.155")
        assert vat == expected_vat
    
    def test_net_amount_calculation(self, fiscal_adapter, base_transaction):
        """Net amount should be gross minus VAT."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        raw = result["raw_response"]
        gross = Decimal(raw["gross_commission"])
        vat = Decimal(raw["vat_amount"])
        net = Decimal(raw["net_amount"])
        
        expected_net = gross - vat
        assert net == expected_net
    
    def test_vat_with_large_commission(self, fiscal_adapter, base_transaction):
        """VAT calculation should work with large amounts."""
        base_transaction["gross_commission"] = Decimal("1000.00")
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        raw = result["raw_response"]
        vat = Decimal(raw["vat_amount"])
        
        expected_vat = Decimal("155.00")
        assert vat == expected_vat
    
    def test_vat_with_small_commission(self, fiscal_adapter, base_transaction):
        """VAT calculation should work with small amounts."""
        base_transaction["gross_commission"] = Decimal("0.10")
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        raw = result["raw_response"]
        vat = Decimal(raw["vat_amount"])
        
        # 0.10 * 0.155 = 0.0155
        expected_vat = Decimal("0.01")  # Rounded
        assert vat >= Decimal("0.01")
    
    def test_vat_with_zero_commission(self, fiscal_adapter, base_transaction):
        """VAT should be zero when commission is zero."""
        base_transaction["gross_commission"] = Decimal("0.00")
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        raw = result["raw_response"]
        vat = Decimal(raw["vat_amount"])
        
        assert vat == Decimal("0.00")


# ─────────────────────────────────────────────────────────────────
# Test: Recipient Type Handling
# ─────────────────────────────────────────────────────────────────


class TestRecipientTypes:
    """Tests for different recipient types (merchant, courier)."""
    
    def test_merchant_recipient_type(self, fiscal_adapter, base_transaction):
        """Fiscal entry should accept 'merchant' recipient type."""
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert result["raw_response"]["recipient_type"] == "merchant"
        assert "merchant" in result["tax_invoice_number"]
    
    def test_courier_recipient_type(self, fiscal_adapter, base_transaction):
        """Fiscal entry should accept 'courier' recipient type."""
        base_transaction["recipient_type"] = "courier"
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert result["raw_response"]["recipient_type"] == "courier"
        assert "courier" in result["tax_invoice_number"]
    
    def test_multiple_recipients_same_settlement(self, fiscal_adapter, base_transaction):
        """Multiple entries for same settlement (merchant + courier) should have different INs."""
        # Merchant entry
        base_transaction["recipient_type"] = "merchant"
        merchant_result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # Courier entry
        base_transaction["recipient_type"] = "courier"
        courier_result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert merchant_result["tax_invoice_number"] != courier_result["tax_invoice_number"]
        assert "merchant" in merchant_result["tax_invoice_number"]
        assert "courier" in courier_result["tax_invoice_number"]


# ─────────────────────────────────────────────────────────────────
# Test: Entry Storage & Retrieval
# ─────────────────────────────────────────────────────────────────


class TestEntryStorage:
    """Tests for internal storage of generated entries."""
    
    def test_entries_stored_after_generation(self, fiscal_adapter, base_transaction):
        """Generated entries should be stored in adapter."""
        assert len(fiscal_adapter.generated_entries) == 0
        
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert len(fiscal_adapter.generated_entries) == 1
    
    def test_multiple_entries_stored(self, fiscal_adapter, base_transaction):
        """Multiple entries should all be stored."""
        for i in range(5):
            base_transaction["settlement_id"] = i + 1
            fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert len(fiscal_adapter.generated_entries) == 5
    
    def test_stored_entries_are_copies(self, fiscal_adapter, base_transaction):
        """Stored entries should not be affected by subsequent modifications."""
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        first_entry = fiscal_adapter.generated_entries[0]
        first_code = first_entry["fiscal_auth_code"]
        
        # Generate another entry
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # First entry should be unchanged
        assert fiscal_adapter.generated_entries[0]["fiscal_auth_code"] == first_code


# ─────────────────────────────────────────────────────────────────
# Test: Error Handling - fail_on_pattern
# ─────────────────────────────────────────────────────────────────


class TestErrorHandling:
    """Tests for error scenarios and pattern-based failures."""
    
    def test_raises_fiscal_error_when_pattern_matches(
        self, fiscal_adapter_with_fail_pattern, base_transaction
    ):
        """Should raise FiscalError when recipient_id matches fail_on_pattern."""
        base_transaction["recipient_id"] = "FAIL_123"
        
        with pytest.raises(FiscalError):
            fiscal_adapter_with_fail_pattern.generate_fiscal_entry(base_transaction)
    
    def test_error_message_contains_pattern(
        self, fiscal_adapter_with_fail_pattern, base_transaction
    ):
        """Error message should indicate the fail pattern."""
        base_transaction["recipient_id"] = "FAIL_RECIPIENT"
        
        with pytest.raises(FiscalError) as exc_info:
            fiscal_adapter_with_fail_pattern.generate_fiscal_entry(base_transaction)
        
        assert "FAIL" in str(exc_info.value)
    
    def test_no_error_when_pattern_doesnt_match(
        self, fiscal_adapter_with_fail_pattern, base_transaction
    ):
        """Should succeed when recipient_id doesn't match fail_on_pattern."""
        base_transaction["recipient_id"] = "GOOD_123"
        
        result = fiscal_adapter_with_fail_pattern.generate_fiscal_entry(base_transaction)
        
        assert result["success"] is True
    
    def test_no_entry_stored_on_error(self, fiscal_adapter_with_fail_pattern, base_transaction):
        """Entry should not be stored if generation fails."""
        base_transaction["recipient_id"] = "FAIL_123"
        
        with pytest.raises(FiscalError):
            fiscal_adapter_with_fail_pattern.generate_fiscal_entry(base_transaction)
        
        assert len(fiscal_adapter_with_fail_pattern.generated_entries) == 0


# ─────────────────────────────────────────────────────────────────
# Test: Tax Report Generation
# ─────────────────────────────────────────────────────────────────


class TestTaxReportGeneration:
    """Tests for generate_tax_report() method."""
    
    def test_tax_report_has_required_fields(self, fiscal_adapter, base_transaction):
        """Tax report must contain all required fields."""
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert "period" in report
        assert "total_transactions" in report
        assert "total_gross_commission" in report
        assert "total_vat_liability" in report
        assert "net_revenue" in report
        assert "fiscal_entries" in report
        assert "status" in report
    
    def test_status_is_mock(self, fiscal_adapter, base_transaction):
        """Status should indicate this is a mock adapter."""
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert report["status"] == "MOCK"
    
    def test_period_string_format(self, fiscal_adapter, base_transaction):
        """Period string should show date range."""
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert "2026-03" in report["period"]
    
    def test_transaction_count(self, fiscal_adapter, base_transaction):
        """Total transactions should match number of entries in range."""
        for i in range(3):
            base_transaction["settlement_id"] = i + 1
            fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert report["total_transactions"] == 3
    
    def test_commission_aggregation(self, fiscal_adapter, base_transaction):
        """Total gross commission should be sum of all entries."""
        commissions = [Decimal("5.50"), Decimal("2.75"), Decimal("10.00")]
        
        for i, comm in enumerate(commissions):
            base_transaction["settlement_id"] = i + 1
            base_transaction["gross_commission"] = comm
            fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        expected_total = sum(commissions)
        assert report["total_gross_commission"] == expected_total
    
    def test_vat_aggregation(self, fiscal_adapter, base_transaction):
        """Total VAT should be sum of all VAT amounts."""
        commissions = [Decimal("5.50"), Decimal("2.75"), Decimal("10.00")]
        
        for i, comm in enumerate(commissions):
            base_transaction["settlement_id"] = i + 1
            base_transaction["gross_commission"] = comm
            fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        expected_vat = sum(comm * Decimal("0.155") for comm in commissions)
        assert report["total_vat_liability"] == expected_vat
    
    def test_net_revenue_calculation(self, fiscal_adapter, base_transaction):
        """Net revenue should be gross commission minus VAT liability."""
        base_transaction["gross_commission"] = Decimal("100.00")
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        expected_vat = Decimal("15.50")
        expected_net = Decimal("84.50")
        
        assert report["total_vat_liability"] == expected_vat
        assert report["net_revenue"] == expected_net


# ─────────────────────────────────────────────────────────────────
# Test: Date Range Filtering
# ─────────────────────────────────────────────────────────────────


class TestDateRangeFiltering:
    """Tests for date range filtering in tax reports."""
    
    def test_empty_date_range_returns_zero_transactions(self, fiscal_adapter, base_transaction):
        """Report for date range with no entries should return zero transactions."""
        base_transaction["transaction_date"] = datetime(2026, 3, 3, 14, 2, 0)
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # Query different date range
        report = fiscal_adapter.generate_tax_report(
            date(2026, 4, 1), date(2026, 4, 30)
        )
        
        assert report["total_transactions"] == 0
        assert report["total_gross_commission"] == Decimal("0")
    
    def test_single_entry_in_range(self, fiscal_adapter, base_transaction):
        """Report should include single entry when it's in range."""
        base_transaction["transaction_date"] = datetime(2026, 3, 15, 10, 0, 0)
        base_transaction["gross_commission"] = Decimal("50.00")
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert report["total_transactions"] == 1
        assert report["total_gross_commission"] == Decimal("50.00")
    
    def test_entries_outside_range_excluded(self, fiscal_adapter, base_transaction):
        """Entries outside date range should not be included."""
        # Entry 1: March
        base_transaction["settlement_id"] = 1
        base_transaction["transaction_date"] = datetime(2026, 3, 15, 10, 0, 0)
        base_transaction["gross_commission"] = Decimal("50.00")
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # Entry 2: April (outside range)
        base_transaction["settlement_id"] = 2
        base_transaction["transaction_date"] = datetime(2026, 4, 15, 10, 0, 0)
        base_transaction["gross_commission"] = Decimal("25.00")
        fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # Query only March
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert report["total_transactions"] == 1
        assert report["total_gross_commission"] == Decimal("50.00")
    
    def test_multiple_entries_span_range(self, fiscal_adapter, base_transaction):
        """Multiple entries across range should all be included."""
        dates = [
            datetime(2026, 3, 5, 10, 0, 0),
            datetime(2026, 3, 15, 10, 0, 0),
            datetime(2026, 3, 25, 10, 0, 0),
        ]
        
        for i, dt in enumerate(dates):
            base_transaction["settlement_id"] = i + 1
            base_transaction["transaction_date"] = dt
            base_transaction["gross_commission"] = Decimal("30.00")
            fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert report["total_transactions"] == 3
        assert report["total_gross_commission"] == Decimal("90.00")


# ─────────────────────────────────────────────────────────────────
# Test: Integration Scenarios
# ─────────────────────────────────────────────────────────────────


class TestIntegrationScenarios:
    """Tests for realistic multi-transaction scenarios."""
    
    def test_merchant_and_courier_split_scenario(self, fiscal_adapter, base_transaction):
        """Test realistic scenario: merchant and courier from same escrow."""
        # Merchant entry: 5.5% of $15
        base_transaction["settlement_id"] = 1
        base_transaction["recipient_type"] = "merchant"
        base_transaction["recipient_id"] = "MERCHANT_001"
        base_transaction["gross_commission"] = Decimal("0.825")  # 5.5% of $15
        
        merchant_result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # Courier entry: 5.5% of $5
        base_transaction["settlement_id"] = 1
        base_transaction["recipient_type"] = "courier"
        base_transaction["recipient_id"] = "COURIER_001"
        base_transaction["gross_commission"] = Decimal("0.275")  # 5.5% of $5
        
        courier_result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # Verify both entries exist
        assert len(fiscal_adapter.generated_entries) == 2
        
        # Generate report
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert report["total_transactions"] == 2
        assert report["total_gross_commission"] == Decimal("1.10")
    
    def test_chronological_ordering_preserved(self, fiscal_adapter, base_transaction):
        """Entries should maintain chronological order."""
        dates = [
            datetime(2026, 3, 1, 10, 0, 0),
            datetime(2026, 3, 10, 10, 0, 0),
            datetime(2026, 3, 20, 10, 0, 0),
            datetime(2026, 3, 5, 10, 0, 0),  # Out of order in generation
        ]
        
        for i, dt in enumerate(dates):
            base_transaction["settlement_id"] = i + 1
            base_transaction["transaction_date"] = dt
            fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        # All entries should be retrievable
        assert len(fiscal_adapter.generated_entries) == 4
        
        # Report should capture all
        report = fiscal_adapter.generate_tax_report(
            date(2026, 3, 1), date(2026, 3, 31)
        )
        
        assert report["total_transactions"] == 4


# ─────────────────────────────────────────────────────────────────
# Test: Edge Cases & Decimal Precision
# ─────────────────────────────────────────────────────────────────


class TestEdgeCases:
    """Tests for edge cases and boundary conditions."""
    
    def test_very_large_commission_amount(self, fiscal_adapter, base_transaction):
        """Should handle very large commission amounts."""
        base_transaction["gross_commission"] = Decimal("999999.99")
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert result["success"] is True
        raw = result["raw_response"]
        vat = Decimal(raw["vat_amount"])
        expected_vat = Decimal("999999.99") * Decimal("0.155")
        assert vat == expected_vat
    
    def test_very_small_commission_amount(self, fiscal_adapter, base_transaction):
        """Should handle very small commission amounts."""
        base_transaction["gross_commission"] = Decimal("0.01")
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert result["success"] is True
        raw = result["raw_response"]
        vat = Decimal(raw["vat_amount"])
        assert vat >= Decimal("0")
    
    def test_high_precision_decimal(self, fiscal_adapter, base_transaction):
        """Should maintain Decimal precision."""
        base_transaction["gross_commission"] = Decimal("5.6789")
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        raw = result["raw_response"]
        gross = Decimal(raw["gross_commission"])
        assert gross == Decimal("5.6789")
    
    def test_default_vat_rate_applied(self, fiscal_adapter, base_transaction):
        """Should apply 15.5% VAT rate when not specified."""
        # This is already in base_transaction, but test explicitly
        del base_transaction["vat_rate"]
        result = fiscal_adapter.generate_fiscal_entry(base_transaction)
        
        assert result["success"] is True
        raw = result["raw_response"]
        vat = Decimal(raw["vat_amount"])
        # Should still calculate with 15.5%
        expected = Decimal("5.50") * Decimal("0.155")
        assert vat == expected