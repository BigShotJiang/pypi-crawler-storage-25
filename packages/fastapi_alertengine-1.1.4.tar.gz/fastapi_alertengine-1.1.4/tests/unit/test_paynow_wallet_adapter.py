"""
Unit tests for PaynowWalletAdapter.

Uses monkeypatching to replace httpx.Client so no real network calls
are made. Tests cover four layers of the adapter:

  1. Hash computation (_compute_hash)
  2. Phone normalisation (_normalise_phone)
  3. Response parsing (_parse_response)
  4. HTTP transport / retry logic (_post_with_retry)
  5. Full reverse_transaction end-to-end flow
"""

import hashlib
from datetime import datetime
from urllib.parse import urlencode, parse_qs

import pytest

from app.adapters.paynow_wallet_adapter import PaynowWalletAdapter, PaynowError

# ---------------------------------------------------------------------------
# Test constants
# ---------------------------------------------------------------------------

INTEGRATION_ID = "99999"
INTEGRATION_KEY = "testintegrationkey1234567890abcd"
MERCHANT_EMAIL = "ops@anchorflow.com"
POLL_URL = "https://www.paynow.co.zw/interface/check/test-poll"

BASE_INSTRUCTION = {
    "external_transaction_id": "TXN-E2E-001",
    "payer_wallet_id": "0771234567",
    "amount": 25.00,
    "reason": "timeout",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_adapter(**kwargs) -> PaynowWalletAdapter:
    """Create a PaynowWalletAdapter with test credentials and max_retries=1."""
    defaults = {
        "integration_id": INTEGRATION_ID,
        "integration_key": INTEGRATION_KEY,
        "merchant_email": MERCHANT_EMAIL,
        "max_retries": 1,
    }
    defaults.update(kwargs)
    return PaynowWalletAdapter(**defaults)


def ok_response(poll_url: str = POLL_URL) -> str:
    """URL-encoded Paynow success response (status=Ok, awaiting confirmation)."""
    return urlencode({"status": "Ok", "pollurl": poll_url})


def sent_response(poll_url: str = POLL_URL) -> str:
    """URL-encoded Paynow confirmed response (status=Sent)."""
    return urlencode({"status": "Sent", "pollurl": poll_url})


def error_response(error: str = "Invalid merchant") -> str:
    """URL-encoded Paynow error response."""
    return urlencode({"status": "Error", "error": error})


# ---------------------------------------------------------------------------
# Fake httpx.Client implementations for monkeypatching
# ---------------------------------------------------------------------------


class _FakeHTTPClient:
    """
    Minimal httpx.Client stand-in that supports the context manager protocol
    and a ``post()`` method.

    ``responses`` is a shared list (used as a queue) so that state is
    preserved across multiple instantiations within a single retry loop —
    each call to ``httpx.Client()`` creates a new instance, but they all
    dequeue from the same list.  The last entry is repeated when the queue
    is exhausted.
    """

    def __init__(self, responses, **kwargs):
        """
        Args:
            responses: A mutable list of (status_code, text) tuples.
                       Items are popped from the front on each ``post()`` call.
        """
        self._responses = responses  # shared reference, not a copy

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def post(self, url, content=None, headers=None):
        import httpx
        if len(self._responses) > 1:
            status_code, text = self._responses.pop(0)
        else:
            status_code, text = self._responses[0]
        return httpx.Response(status_code, text=text)


class _NetworkErrorClient:
    """Raises httpx.NetworkError on every ``post()`` call."""

    def __init__(self, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def post(self, url, content=None, headers=None):
        import httpx
        raise httpx.NetworkError("Simulated connection refused")


class _TimeoutClient:
    """Raises httpx.TimeoutException on every ``post()`` call."""

    def __init__(self, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def post(self, url, content=None, headers=None):
        import httpx
        raise httpx.TimeoutException("Simulated timeout")


class _CapturingClient:
    """Records every request body for assertion; returns a configurable response."""

    def __init__(self, response_text: str = "", status_code: int = 200, **kwargs):
        self.captured = []
        self._response_text = response_text
        self._status_code = status_code

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def post(self, url, content=None, headers=None):
        import httpx
        self.captured.append({
            "url": url,
            "body": content.decode() if content else "",
        })
        return httpx.Response(self._status_code, text=self._response_text)


# ---------------------------------------------------------------------------
# 1. Hash computation
# ---------------------------------------------------------------------------


class TestHashComputation:
    def test_returns_32_char_uppercase_hex(self):
        adapter = make_adapter()
        fields = {"id": "123", "reference": "REF-1", "amount": "10.00"}
        result = adapter._compute_hash(fields)
        assert len(result) == 32
        assert result == result.upper()
        assert all(c in "0123456789ABCDEF" for c in result)

    def test_is_deterministic(self):
        adapter = make_adapter()
        fields = {"id": "123", "reference": "REF-1", "amount": "10.00"}
        assert adapter._compute_hash(fields) == adapter._compute_hash(fields)

    def test_different_integration_keys_give_different_hash(self):
        fields = {"id": "123", "amount": "10.00"}
        adapter_a = make_adapter(integration_key="key_A")
        adapter_b = make_adapter(integration_key="key_B")
        assert adapter_a._compute_hash(fields) != adapter_b._compute_hash(fields)

    def test_different_amounts_give_different_hash(self):
        adapter = make_adapter()
        a = adapter._compute_hash({"amount": "10.00"})
        b = adapter._compute_hash({"amount": "20.00"})
        assert a != b

    def test_matches_expected_md5(self):
        """Verify the algorithm: MD5(values + key).upper()."""
        adapter = make_adapter()
        fields = {"id": "99999", "ref": "TEST"}
        raw = "99999TEST" + INTEGRATION_KEY
        expected = hashlib.md5(raw.encode("utf-8")).hexdigest().upper()
        assert adapter._compute_hash(fields) == expected


# ---------------------------------------------------------------------------
# 2. Phone normalisation
# ---------------------------------------------------------------------------


class TestPhoneNormalisation:
    def test_plus_international_format(self):
        assert PaynowWalletAdapter._normalise_phone("+263771234567") == "0771234567"

    def test_bare_international_format(self):
        assert PaynowWalletAdapter._normalise_phone("263771234567") == "0771234567"

    def test_local_format_unchanged(self):
        assert PaynowWalletAdapter._normalise_phone("0771234567") == "0771234567"

    def test_strips_spaces(self):
        assert PaynowWalletAdapter._normalise_phone("077 123 4567") == "0771234567"

    def test_strips_hyphens(self):
        assert PaynowWalletAdapter._normalise_phone("077-123-4567") == "0771234567"

    def test_strips_leading_trailing_whitespace(self):
        assert PaynowWalletAdapter._normalise_phone("  0771234567  ") == "0771234567"

    def test_plus263_longer_number(self):
        assert PaynowWalletAdapter._normalise_phone("+263712345678") == "0712345678"


# ---------------------------------------------------------------------------
# 3. Response parsing
# ---------------------------------------------------------------------------


class TestResponseParsing:
    def test_ok_status_success_true(self):
        adapter = make_adapter()
        result = adapter._parse_response(ok_response(), "TXN-001")
        assert result["success"] is True

    def test_ok_status_is_pending(self):
        """'Ok' means Paynow accepted it but the provider hasn't confirmed yet."""
        adapter = make_adapter()
        result = adapter._parse_response(ok_response(), "TXN-001")
        assert result["status"] == "pending"

    def test_ok_status_reversal_id_is_poll_url(self):
        adapter = make_adapter()
        result = adapter._parse_response(ok_response(), "TXN-001")
        assert result["reversal_id"] == POLL_URL

    def test_sent_status_is_confirmed(self):
        adapter = make_adapter()
        result = adapter._parse_response(sent_response(), "TXN-002")
        assert result["success"] is True
        assert result["status"] == "confirmed"

    def test_success_status_is_confirmed(self):
        adapter = make_adapter()
        raw = urlencode({"status": "Success", "pollurl": POLL_URL})
        result = adapter._parse_response(raw, "TXN-003")
        assert result["success"] is True
        assert result["status"] == "confirmed"

    def test_error_status_returns_failure(self):
        adapter = make_adapter()
        result = adapter._parse_response(error_response(), "TXN-004")
        assert result["success"] is False
        assert result["status"] == "failed"
        assert result["reversal_id"] == ""

    def test_unknown_status_returns_failure(self):
        adapter = make_adapter()
        raw = urlencode({"status": "SomethingUnexpected"})
        result = adapter._parse_response(raw, "TXN-005")
        assert result["success"] is False

    def test_response_contains_iso_timestamp(self):
        adapter = make_adapter()
        result = adapter._parse_response(ok_response(), "TXN-006")
        datetime.fromisoformat(result["timestamp"])  # must not raise

    def test_missing_pollurl_falls_back_to_generated_ref(self):
        adapter = make_adapter()
        raw = urlencode({"status": "Ok"})
        result = adapter._parse_response(raw, "TXN-007")
        assert result["success"] is True
        assert "TXN-007" in result["reversal_id"]


# ---------------------------------------------------------------------------
# 4. HTTP transport / retry logic
# ---------------------------------------------------------------------------


class TestHTTPRetry:
    """Tests for _post_with_retry."""

    def _patch_http(self, monkeypatch, client_factory):
        monkeypatch.setattr(
            "app.adapters.paynow_wallet_adapter.httpx.Client", client_factory
        )
        monkeypatch.setattr(
            "app.adapters.paynow_wallet_adapter.PaynowWalletAdapter._sleep",
            lambda self, s: None,
        )

    def test_5xx_triggers_retry(self, monkeypatch):
        responses = [(500, "Server Error"), (200, ok_response())]
        self._patch_http(monkeypatch, lambda **kw: _FakeHTTPClient(responses))
        adapter = make_adapter(max_retries=2)
        result = adapter._post_with_retry("https://example.com", {"a": "1"})
        assert "Ok" in result

    def test_4xx_does_not_retry(self, monkeypatch):
        """400 errors are returned immediately without consuming retry budget."""
        call_count = []

        def make_counting_client(**kw):
            call_count.append(1)
            return _FakeHTTPClient([(400, error_response())])

        self._patch_http(monkeypatch, make_counting_client)
        adapter = make_adapter(max_retries=3)
        adapter._post_with_retry("https://example.com", {"a": "1"})
        assert len(call_count) == 1  # only one client instantiated

    def test_network_error_retries_then_raises(self, monkeypatch):
        self._patch_http(monkeypatch, lambda **kw: _NetworkErrorClient())
        adapter = make_adapter(max_retries=2)
        with pytest.raises(PaynowError, match="attempt"):
            adapter._post_with_retry("https://example.com", {"a": "1"})

    def test_timeout_retries_then_raises(self, monkeypatch):
        self._patch_http(monkeypatch, lambda **kw: _TimeoutClient())
        adapter = make_adapter(max_retries=2)
        with pytest.raises(PaynowError, match="attempt"):
            adapter._post_with_retry("https://example.com", {"a": "1"})

    def test_eventual_success_after_two_5xx(self, monkeypatch):
        responses = [(500, "err"), (500, "err"), (200, ok_response())]
        self._patch_http(monkeypatch, lambda **kw: _FakeHTTPClient(responses))
        adapter = make_adapter(max_retries=3)
        result = adapter._post_with_retry("https://example.com", {"a": "1"})
        assert "Ok" in result

    def test_exhausted_retries_raises_paynow_error(self, monkeypatch):
        self._patch_http(monkeypatch, lambda **kw: _FakeHTTPClient([(500, "err")]))
        adapter = make_adapter(max_retries=2)
        with pytest.raises(PaynowError):
            adapter._post_with_retry("https://example.com", {"a": "1"})


# ---------------------------------------------------------------------------
# 5. Full reverse_transaction end-to-end
# ---------------------------------------------------------------------------


class TestReverseTransaction:
    """Full flow tests for reverse_transaction()."""

    def _patch_and_capture(self, monkeypatch, response_text: str, status_code: int = 200):
        """Patch httpx.Client with a capturing client; return the client store."""
        clients = []

        def make_client(**kw):
            c = _CapturingClient(response_text=response_text, status_code=status_code)
            clients.append(c)
            return c

        monkeypatch.setattr("app.adapters.paynow_wallet_adapter.httpx.Client", make_client)
        monkeypatch.setattr(
            "app.adapters.paynow_wallet_adapter.PaynowWalletAdapter._sleep",
            lambda self, s: None,
        )
        return clients

    def test_successful_reversal_returns_success_true(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = make_adapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["success"] is True
        assert result["reversal_id"] == POLL_URL

    def test_paynow_error_response_returns_success_false(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, error_response())
        adapter = make_adapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["success"] is False

    def test_phone_normalised_to_local_format(self, monkeypatch):
        """International phone number must be normalised before the request."""
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = make_adapter()
        inst = dict(BASE_INSTRUCTION, payer_wallet_id="+263771234567")
        adapter.reverse_transaction(inst)
        assert clients, "No HTTP client was created"
        assert "phone=0771234567" in clients[0].captured[0]["body"]

    def test_hash_field_included_in_request(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = make_adapter()
        adapter.reverse_transaction(BASE_INSTRUCTION)
        assert "hash=" in clients[0].captured[0]["body"]

    def test_reference_contains_original_tx_id(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = make_adapter()
        inst = dict(BASE_INSTRUCTION, external_transaction_id="TXN-UNIQUE-XYZ")
        adapter.reverse_transaction(inst)
        body = clients[0].captured[0]["body"]
        assert "TXN-UNIQUE-XYZ" in body

    def test_amount_formatted_to_2_decimal_places(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = make_adapter()
        inst = dict(BASE_INSTRUCTION, amount=7.5)
        adapter.reverse_transaction(inst)
        assert "amount=7.50" in clients[0].captured[0]["body"]

    def test_network_failure_raises_paynow_error(self, monkeypatch):
        monkeypatch.setattr(
            "app.adapters.paynow_wallet_adapter.httpx.Client",
            lambda **kw: _NetworkErrorClient(),
        )
        monkeypatch.setattr(
            "app.adapters.paynow_wallet_adapter.PaynowWalletAdapter._sleep",
            lambda self, s: None,
        )
        adapter = make_adapter(max_retries=2)
        with pytest.raises(PaynowError):
            adapter.reverse_transaction(BASE_INSTRUCTION)

    def test_uses_configured_base_url(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = PaynowWalletAdapter(
            integration_id="1",
            integration_key="k",
            merchant_email="e@e.com",
            base_url="https://sandbox.paynow.co.zw",
            max_retries=1,
        )
        adapter.reverse_transaction(BASE_INSTRUCTION)
        assert clients[0].captured[0]["url"].startswith("https://sandbox.paynow.co.zw")

    def test_merchant_email_included_in_request(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = make_adapter()
        adapter.reverse_transaction(BASE_INSTRUCTION)
        body = clients[0].captured[0]["body"]
        assert "ops%40anchorflow.com" in body or "authemail=" in body

    def test_sent_response_returns_confirmed_status(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, sent_response())
        adapter = make_adapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["success"] is True
        assert result["status"] == "confirmed"

    def test_result_has_all_required_keys(self, monkeypatch):
        clients = self._patch_and_capture(monkeypatch, ok_response())
        adapter = make_adapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        for key in ("success", "reversal_id", "status", "timestamp"):
            assert key in result, f"Missing key in response: {key}"
