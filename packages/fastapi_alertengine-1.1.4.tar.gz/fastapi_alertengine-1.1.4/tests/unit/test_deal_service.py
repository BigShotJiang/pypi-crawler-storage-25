"""
Unit tests for app/services/deal_service.py

Covers:
- create_deal(): generates unique deal_id, persists all fields
- build_share_url(): correct URL format
- build_whatsapp_message(): contains share URL
- get_deal(): returns deal; raises ValueError on unknown ID
- detect_payment(): CREATED → HELD, creates linked Escrow with correct
  monetary breakdown, validates payout arithmetic
- confirm_delivery(): HELD → COMPLETED, releases Escrow, records audit logs
- Guard clauses: wrong-state transitions raise ValueError
"""

import pytest
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.database import Base, Deal, DealStatus, Escrow, EscrowStateLog, EscrowStatus
from app.services import deal_service


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture(scope="function")
def db():
    """In-memory SQLite session, rolled back after each test."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()
    Base.metadata.drop_all(engine)


@pytest.fixture
def sample_deal(db):
    """A persisted CREATED deal for use in payment/delivery tests."""
    return deal_service.create_deal(
        db,
        seller_name             = "Blessing M",
        item_description        = "iPhone 13",
        price                   = Decimal("450.00"),
        wallet_phone            = "0772123456",
        delivery_window_minutes = 120,
    )


# ─────────────────────────────────────────────────────────────────────────────
# create_deal
# ─────────────────────────────────────────────────────────────────────────────


class TestCreateDeal:
    def test_returns_deal_instance(self, db):
        deal = deal_service.create_deal(
            db, "Alice", "Laptop", Decimal("800.00"), "0771000001"
        )
        assert isinstance(deal, Deal)

    def test_deal_id_is_five_chars_uppercase_alphanumeric(self, db):
        deal = deal_service.create_deal(
            db, "Alice", "Laptop", Decimal("800.00"), "0771000001"
        )
        assert len(deal.deal_id) == 5
        assert deal.deal_id == deal.deal_id.upper()
        assert deal.deal_id.isalnum()

    def test_deal_persisted_in_db(self, db):
        deal = deal_service.create_deal(
            db, "Bob", "TV", Decimal("200.00"), "0772000001"
        )
        fetched = db.query(Deal).filter(Deal.deal_id == deal.deal_id).first()
        assert fetched is not None
        assert fetched.item_description == "TV"

    def test_initial_status_is_created(self, db):
        deal = deal_service.create_deal(
            db, "Carol", "Chair", Decimal("50.00"), "0773000001"
        )
        assert deal.status == DealStatus.CREATED

    def test_fields_stored_correctly(self, db):
        deal = deal_service.create_deal(
            db,
            seller_name             = "Dave",
            item_description        = "Headphones",
            price                   = Decimal("75.50"),
            wallet_phone            = "0774000001",
            delivery_window_minutes = 60,
        )
        assert deal.seller_name             == "Dave"
        assert deal.item_description        == "Headphones"
        assert deal.price                   == Decimal("75.50")
        assert deal.wallet_phone            == "0774000001"
        assert deal.delivery_window_minutes == 60

    def test_two_deals_have_different_ids(self, db):
        d1 = deal_service.create_deal(db, "E", "Item1", Decimal("10"), "0771")
        d2 = deal_service.create_deal(db, "F", "Item2", Decimal("20"), "0772")
        assert d1.deal_id != d2.deal_id

    def test_payment_reference_format(self, db):
        deal = deal_service.create_deal(db, "G", "Watch", Decimal("120"), "0775")
        assert deal.payment_reference == f"TDM-{deal.deal_id}"

    def test_no_escrow_created_at_creation(self, db):
        deal = deal_service.create_deal(db, "H", "Bag", Decimal("30"), "0776")
        assert deal.escrow_id is None

    def test_default_delivery_window_is_120(self, db):
        deal = deal_service.create_deal(db, "I", "Shoes", Decimal("40"), "0777")
        assert deal.delivery_window_minutes == 120


# ─────────────────────────────────────────────────────────────────────────────
# build_share_url / build_whatsapp_message
# ─────────────────────────────────────────────────────────────────────────────


class TestBuildHelpers:
    def test_share_url_contains_deal_id(self, db, sample_deal):
        url = deal_service.build_share_url(sample_deal, "https://anchorflow.com/tofamba")
        assert sample_deal.deal_id in url

    def test_share_url_format(self, db, sample_deal):
        url = deal_service.build_share_url(sample_deal, "https://anchorflow.com/tofamba")
        assert url == f"https://anchorflow.com/tofamba/d/{sample_deal.deal_id}"

    def test_share_url_strips_trailing_slash(self, db, sample_deal):
        url = deal_service.build_share_url(sample_deal, "https://anchorflow.com/tofamba/")
        assert url == f"https://anchorflow.com/tofamba/d/{sample_deal.deal_id}"

    def test_whatsapp_message_contains_share_url(self, db, sample_deal):
        url = deal_service.build_share_url(sample_deal, "https://anchorflow.com/tofamba")
        msg = deal_service.build_whatsapp_message(sample_deal, url)
        assert url in msg

    def test_whatsapp_message_contains_tandem_branding(self, db, sample_deal):
        url = deal_service.build_share_url(sample_deal, "https://anchorflow.com/tofamba")
        msg = deal_service.build_whatsapp_message(sample_deal, url)
        assert "Tofamba" in msg


# ─────────────────────────────────────────────────────────────────────────────
# get_deal
# ─────────────────────────────────────────────────────────────────────────────


class TestGetDeal:
    def test_returns_correct_deal(self, db, sample_deal):
        fetched = deal_service.get_deal(db, sample_deal.deal_id)
        assert fetched.deal_id == sample_deal.deal_id

    def test_raises_value_error_for_unknown_id(self, db):
        with pytest.raises(ValueError, match="not found"):
            deal_service.get_deal(db, "XXXXX")


# ─────────────────────────────────────────────────────────────────────────────
# detect_payment
# ─────────────────────────────────────────────────────────────────────────────


class TestDetectPayment:
    def _detect(self, db, deal):
        return deal_service.detect_payment(
            db,
            deal_id        = deal.deal_id,
            payer_wallet   = "0771999888",
            transaction_id = "TXN-TEST-001",
            amount         = deal.price,
        )

    def test_deal_transitions_to_held(self, db, sample_deal):
        deal = self._detect(db, sample_deal)
        assert deal.status == DealStatus.HELD

    def test_escrow_is_created_and_linked(self, db, sample_deal):
        deal = self._detect(db, sample_deal)
        assert deal.escrow_id is not None
        escrow = db.get(Escrow, deal.escrow_id)
        assert escrow is not None

    def test_escrow_status_is_held(self, db, sample_deal):
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        assert escrow.status == EscrowStatus.HELD

    def test_escrow_total_equals_price(self, db, sample_deal):
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        assert escrow.total_escrow == sample_deal.price

    def test_escrow_payee_is_seller_wallet(self, db, sample_deal):
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        assert escrow.payee_wallet_id == sample_deal.wallet_phone

    def test_escrow_payer_is_buyer_wallet(self, db, sample_deal):
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        assert escrow.payer_wallet_id == "0771999888"

    def test_monetary_breakdown_validates(self, db, sample_deal):
        """merchant_final_payout = price − fee − imtt."""
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        expected_payout = (
            escrow.merchant_gross
            - escrow.merchant_tandem_fee
            - escrow.merchant_imtt_tax
        )
        assert escrow.merchant_final_payout == expected_payout

    def test_tandem_fee_is_3_5_percent(self, db, sample_deal):
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        expected_fee = (sample_deal.price * Decimal("0.035")).quantize(Decimal("0.01"))
        assert escrow.merchant_tandem_fee == expected_fee

    def test_imtt_is_2_percent(self, db, sample_deal):
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        expected_imtt = (sample_deal.price * Decimal("0.02")).quantize(Decimal("0.01"))
        assert escrow.merchant_imtt_tax == expected_imtt

    def test_courier_fields_are_zero(self, db, sample_deal):
        """Deal Links are seller-only; courier fields must be zero."""
        deal   = self._detect(db, sample_deal)
        escrow = db.get(Escrow, deal.escrow_id)
        assert escrow.courier_gross         == Decimal("0.00")
        assert escrow.courier_tandem_fee    == Decimal("0.00")
        assert escrow.courier_final_payout  == Decimal("0.00")

    def test_state_log_written(self, db, sample_deal):
        deal = self._detect(db, sample_deal)
        logs = db.query(EscrowStateLog).filter_by(escrow_id=deal.escrow_id).all()
        assert len(logs) >= 1

    def test_expires_at_set(self, db, sample_deal):
        deal = self._detect(db, sample_deal)
        assert deal.expires_at is not None

    def test_raises_if_already_held(self, db, sample_deal):
        self._detect(db, sample_deal)
        with pytest.raises(ValueError):
            self._detect(db, sample_deal)


# ─────────────────────────────────────────────────────────────────────────────
# confirm_delivery
# ─────────────────────────────────────────────────────────────────────────────


class TestConfirmDelivery:
    def _held_deal(self, db, sample_deal):
        """Helper: advance deal to HELD state."""
        return deal_service.detect_payment(
            db,
            deal_id        = sample_deal.deal_id,
            payer_wallet   = "0771888777",
            transaction_id = "TXN-CONFIRM-001",
            amount         = sample_deal.price,
        )

    def test_deal_transitions_to_completed(self, db, sample_deal):
        self._held_deal(db, sample_deal)
        deal = deal_service.confirm_delivery(db, sample_deal.deal_id)
        assert deal.status == DealStatus.COMPLETED

    def test_completed_at_is_set(self, db, sample_deal):
        self._held_deal(db, sample_deal)
        deal = deal_service.confirm_delivery(db, sample_deal.deal_id)
        assert deal.completed_at is not None

    def test_escrow_transitions_to_released(self, db, sample_deal):
        held = self._held_deal(db, sample_deal)
        deal_service.confirm_delivery(db, sample_deal.deal_id)
        escrow = db.get(Escrow, held.escrow_id)
        assert escrow.status == EscrowStatus.RELEASED

    def test_audit_logs_written(self, db, sample_deal):
        held = self._held_deal(db, sample_deal)
        deal_service.confirm_delivery(db, sample_deal.deal_id)
        logs = db.query(EscrowStateLog).filter_by(escrow_id=held.escrow_id).all()
        statuses = [log.new_status for log in logs]
        assert EscrowStatus.DELIVERED.value in statuses
        assert EscrowStatus.RELEASED.value  in statuses

    def test_raises_if_not_held(self, db, sample_deal):
        """Cannot confirm delivery before payment detected."""
        with pytest.raises(ValueError):
            deal_service.confirm_delivery(db, sample_deal.deal_id)

    def test_raises_if_already_completed(self, db, sample_deal):
        self._held_deal(db, sample_deal)
        deal_service.confirm_delivery(db, sample_deal.deal_id)
        with pytest.raises(ValueError):
            deal_service.confirm_delivery(db, sample_deal.deal_id)
