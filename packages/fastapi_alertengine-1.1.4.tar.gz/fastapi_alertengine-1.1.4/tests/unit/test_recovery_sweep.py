# tests/unit/test_recovery_sweep.py
"""
Tests for the recovery sweep logic.

We test the core sweep logic by exercising the helper functions and
their interactions with Redis — the FastAPI endpoint itself is thin,
so we focus on:
  - _ORPHAN_THRESHOLDS values and structure
  - _FALLBACK mapping completeness
  - The sweep logic: correct key parsing, age comparison, fallback state applied
"""

import time
from unittest.mock import MagicMock, patch, call

import pytest

from app.routers.recovery import (
    _ORPHAN_THRESHOLDS,
    _FALLBACK,
)


# ─── Threshold and fallback config ───────────────────────────────────────────

class TestOrphanThresholds:
    def test_all_thresholds_are_positive_ints(self):
        for state, secs in _ORPHAN_THRESHOLDS.items():
            assert isinstance(secs, int), f"{state} threshold is not int"
            assert secs > 0, f"{state} threshold is not positive"

    def test_awaiting_payment_is_two_hours(self):
        assert _ORPHAN_THRESHOLDS["awaiting_payment"] == 7_200

    def test_ordering_is_shorter_than_deal_created(self):
        assert _ORPHAN_THRESHOLDS["ordering"] < _ORPHAN_THRESHOLDS["deal_created"]

    def test_delivery_in_progress_is_longest(self):
        max_threshold = max(_ORPHAN_THRESHOLDS.values())
        assert _ORPHAN_THRESHOLDS["delivery_in_progress"] == max_threshold


class TestFallbackMapping:
    def test_all_orphan_states_have_fallbacks(self):
        for state in _ORPHAN_THRESHOLDS:
            assert state in _FALLBACK, f"No fallback for state: {state}"

    def test_fallback_values_are_strings(self):
        for state, fallback in _FALLBACK.items():
            assert isinstance(fallback, str), f"Fallback for {state} is not str"
            assert fallback, f"Fallback for {state} is empty"

    def test_awaiting_payment_falls_back_to_idle(self):
        assert _FALLBACK["awaiting_payment"] == "idle"

    def test_ordering_falls_back_to_browsing(self):
        assert _FALLBACK["ordering"] == "browsing"


# ─── Sweep logic (unit-tested via direct function calls to _sweep_one) ───────
# Since the sweep logic lives inside the route handler, we test it through
# a helper that mirrors the sweep decision logic.

def _is_orphaned(state: str, state_age_s: float) -> bool:
    """Mirror the orphan check from recovery_sweep."""
    threshold = _ORPHAN_THRESHOLDS.get(state)
    if threshold is None:
        return False
    return state_age_s >= threshold


class TestOrphanDetectionLogic:
    def test_non_tracked_state_never_orphaned(self):
        assert not _is_orphaned("idle", 999_999)
        assert not _is_orphaned("browsing", 999_999)

    def test_at_threshold_is_orphaned(self):
        for state, secs in _ORPHAN_THRESHOLDS.items():
            assert _is_orphaned(state, secs), f"{state} at threshold should be orphaned"

    def test_just_under_threshold_is_not_orphaned(self):
        for state, secs in _ORPHAN_THRESHOLDS.items():
            assert not _is_orphaned(state, secs - 1), \
                f"{state} just under threshold should not be orphaned"

    def test_well_over_threshold_is_orphaned(self):
        for state, secs in _ORPHAN_THRESHOLDS.items():
            assert _is_orphaned(state, secs * 2), \
                f"{state} well over threshold should be orphaned"


# ─── Redis key extraction logic ───────────────────────────────────────────────

class TestKeyExtraction:
    def _extract_phone(self, key: str):
        """Mirror the phone extraction from recovery_sweep."""
        parts = key.split("bot:state:", 1)
        if len(parts) != 2:
            return None
        return parts[1]

    def test_extracts_phone_from_standard_key(self):
        assert self._extract_phone("bot:state:+263771234567") == "+263771234567"

    def test_extracts_phone_with_country_code(self):
        assert self._extract_phone("bot:state:+263779876543") == "+263779876543"

    def test_returns_none_for_malformed_key(self):
        assert self._extract_phone("other:key") is None

    def test_returns_none_for_bare_prefix(self):
        result = self._extract_phone("bot:state:")
        assert result == ""  # empty string after split — treated as no-op in sweep


# ─── FastAPI endpoint contract (response shape) ──────────────────────────────
# These tests call the async endpoint with a fully mocked Redis.

import asyncio


def run_async(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


class TestRecoverySweepEndpoint:
    def _mock_redis_empty(self):
        rdb = MagicMock()
        rdb.scan_iter.return_value = iter([])
        return rdb

    def _mock_pii(self):
        pii = MagicMock()
        pii.mask_user_id.side_effect = lambda p: "+263***4567"
        return pii

    def test_empty_redis_returns_zero_scanned(self):
        from app.routers.recovery import recovery_sweep
        rdb = self._mock_redis_empty()
        with patch("app.routers.recovery._get_redis", return_value=rdb):
            with patch("app.routers.recovery._get_pii", return_value=self._mock_pii()):
                result = run_async(recovery_sweep())
        assert result["scanned"] == 0
        assert result["orphaned"] == 0
        assert result["fixed"] == []

    def test_non_orphaned_state_not_fixed(self):
        from app.routers.recovery import recovery_sweep
        now = time.time()
        rdb = MagicMock()
        rdb.scan_iter.return_value = iter([b"bot:state:+263771111111"])
        rdb.get.side_effect = lambda key: (
            b"awaiting_payment" if "bot:state:+" in key and "ts" not in key
            else str(now - 100).encode()   # only 100s old — not orphaned
        )
        with patch("app.routers.recovery._get_redis", return_value=rdb):
            with patch("app.routers.recovery._get_pii", return_value=self._mock_pii()):
                result = run_async(recovery_sweep())
        assert result["orphaned"] == 0

    def test_orphaned_session_gets_fixed(self):
        from app.routers.recovery import recovery_sweep
        now = time.time()
        rdb = MagicMock()
        rdb.scan_iter.return_value = iter([b"bot:state:+263771111111"])
        rdb.get.side_effect = lambda key: (
            b"awaiting_payment" if "bot:state:+" in key and "ts" not in key
            else str(now - 10_000).encode()   # 10_000s old — orphaned
        )
        with patch("app.routers.recovery._get_redis", return_value=rdb):
            with patch("app.routers.recovery._get_pii", return_value=self._mock_pii()):
                result = run_async(recovery_sweep())
        assert result["orphaned"] == 1
        assert result["fixed"][0]["from"] == "awaiting_payment"
        assert result["fixed"][0]["to"] == "idle"

    def test_response_has_required_keys(self):
        from app.routers.recovery import recovery_sweep
        rdb = self._mock_redis_empty()
        with patch("app.routers.recovery._get_redis", return_value=rdb):
            with patch("app.routers.recovery._get_pii", return_value=self._mock_pii()):
                result = run_async(recovery_sweep())
        assert "scanned" in result
        assert "orphaned" in result
        assert "fixed" in result
