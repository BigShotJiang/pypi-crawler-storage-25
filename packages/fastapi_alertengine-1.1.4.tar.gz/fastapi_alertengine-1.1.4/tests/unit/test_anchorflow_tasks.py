"""
Tests for the four AnchorFlow engineering tasks.

Task 1  — Schema: new columns present and have correct defaults
Task 2  — Pessimistic locking: trigger_reversal skips already-processed rows
Task 3a — poll_provider_status: verified/unverified webhook fallback
Task 3b — Merchant Proof-of-Life: fast_track_cancel, acknowledge_deal, MerchantAckJob
Task 3c — confirm_delivery: EXPIRED guard raises a specific error
Task 4  — ZIMRA fiscal adapter: audit log written to EscrowStateLog
"""

import json
import pytest
from datetime import datetime, UTC, timedelta
from decimal import Decimal

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models.database import (
    Base,
    Deal,
    DealStatus,
    Escrow,
    EscrowStateLog,
    EscrowStatus,
    Merchant,
    MerchantInventory,
)
from app.adapters.mock_wallet_adapter import MockWalletAdapter
from app.adapters.twilio_adapter import MockTwilioAdapter
from app.services import deal_service
from app.services.escrow_timeout_engine import EscrowTimeoutEngine
from app.jobs.merchant_ack_job import MerchantAckJob


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture(scope="function")
def db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()
    Base.metadata.drop_all(engine)


def _make_escrow(db, tx_id="TXN-001", hours_ago=3):
    """Create a HELD escrow that is already past its 2-hour window."""
    e = Escrow(
        order_id                = 1,
        merchant_gross          = Decimal("100.00"),
        courier_gross           = Decimal("0.00"),
        total_escrow            = Decimal("100.00"),
        merchant_tandem_fee     = Decimal("3.50"),
        courier_tandem_fee      = Decimal("0.00"),
        total_tandem_fee        = Decimal("3.50"),
        merchant_imtt_tax       = Decimal("2.00"),
        courier_imtt_tax        = Decimal("0.00"),
        total_imtt_tax          = Decimal("2.00"),
        merchant_final_payout   = Decimal("94.50"),
        courier_final_payout    = Decimal("0.00"),
        status                  = EscrowStatus.HELD,
        wallet_provider         = "paynow",
        external_transaction_id = tx_id,
        payer_wallet_id         = "0771111111",
        payee_wallet_id         = "0772222222",
    )
    e.expiry_timestamp = datetime.now(UTC) - timedelta(hours=hours_ago)
    db.add(e)
    db.commit()
    db.refresh(e)
    return e


def _make_deal(db, status=DealStatus.CREATED, merchant_acked=False, created_minutes_ago=20):
    d = Deal(
        deal_id                 = "TSTD1",
        seller_name             = "Test Seller",
        item_description        = "Test Item",
        price                   = Decimal("100.00"),
        wallet_phone            = "0771111111",
        delivery_window_minutes = 120,
        status                  = status,
        merchant_acknowledged   = merchant_acked,
    )
    d.created_at = datetime.now(UTC) - timedelta(minutes=created_minutes_ago)
    db.add(d)
    db.commit()
    db.refresh(d)
    return d


# ─────────────────────────────────────────────────────────────────────────────
# TASK 1 — Schema: new columns present with correct defaults
# ─────────────────────────────────────────────────────────────────────────────


class TestSchemaChanges:
    def test_deal_has_currency_code_defaulting_to_usd(self, db):
        d = _make_deal(db)
        assert d.currency_code == "USD"

    def test_deal_has_merchant_acknowledged_defaulting_to_false(self, db):
        d = _make_deal(db)
        assert d.merchant_acknowledged is False

    def test_escrow_has_currency_code_defaulting_to_usd(self, db):
        e = _make_escrow(db)
        assert e.currency_code == "USD"

    def test_merchant_status_column_exists(self, db):
        m = Merchant(
            phone          = "0771234567",
            name           = "Test Merchant",
            wallet_address = "0771234567",
        )
        db.add(m)
        db.commit()
        db.refresh(m)
        assert m.status == "pending_verification"

    def test_deal_currency_code_is_settable(self, db):
        d = _make_deal(db)
        d.currency_code = "ZWL"
        db.commit()
        db.refresh(d)
        assert d.currency_code == "ZWL"

    def test_deal_merchant_acknowledged_is_settable(self, db):
        d = _make_deal(db)
        d.merchant_acknowledged = True
        db.commit()
        db.refresh(d)
        assert d.merchant_acknowledged is True


# ─────────────────────────────────────────────────────────────────────────────
# TASK 2 — Pessimistic locking: skipped row behaviour on SQLite
# ─────────────────────────────────────────────────────────────────────────────


class TestPessimisticLocking:
    """
    SQLite does not support FOR UPDATE — the engine falls back to a plain
    SELECT.  We verify the "skipped" code path by checking the result when
    trigger_reversal() finds no eligible row (already processed by another
    "worker", simulated by pre-advancing the status).
    """

    def test_trigger_reversal_returns_skipped_when_escrow_not_held(self, db):
        e = _make_escrow(db)
        # Simulate another worker already processed it
        e.status = EscrowStatus.EXPIRED
        db.commit()

        engine = EscrowTimeoutEngine(db, MockWalletAdapter())
        result = engine.trigger_reversal(e.id, "timeout")
        assert result["status"] == "skipped"

    def test_trigger_reversal_returns_skipped_for_unknown_escrow(self, db):
        engine = EscrowTimeoutEngine(db, MockWalletAdapter())
        result = engine.trigger_reversal(99999, "timeout")
        assert result["status"] == "skipped"

    def test_trigger_reversal_succeeds_when_row_is_held(self, db):
        e = _make_escrow(db)
        engine = EscrowTimeoutEngine(db, MockWalletAdapter(success=True))
        result = engine.trigger_reversal(e.id, "timeout")
        assert result["status"] == EscrowStatus.REVERSAL_INITIATED.value

    def test_check_expired_escrows_does_not_lock(self, db):
        """check_expired_escrows is lightweight — must return candidates without error."""
        _make_escrow(db, tx_id="TXN-A")
        _make_escrow(db, tx_id="TXN-B")
        engine = EscrowTimeoutEngine(db, MockWalletAdapter())
        candidates = engine.check_expired_escrows()
        assert len(candidates) == 2

    def test_check_expired_escrows_returns_only_held(self, db):
        held    = _make_escrow(db, tx_id="TXN-HELD")
        expired = _make_escrow(db, tx_id="TXN-EXPIRED")
        expired.status = EscrowStatus.EXPIRED
        db.commit()

        engine = EscrowTimeoutEngine(db, MockWalletAdapter())
        candidates = engine.check_expired_escrows()
        ids = [c["escrow_id"] for c in candidates]
        assert held.id in ids
        assert expired.id not in ids


# ─────────────────────────────────────────────────────────────────────────────
# TASK 3a — poll_provider_status: webhook fallback verification
# ─────────────────────────────────────────────────────────────────────────────


class TestPollProviderStatus:
    def test_returns_verified_true_when_provider_confirms(self, db):
        d = _make_deal(db)
        adapter = MockWalletAdapter()
        adapter.query_confirmed = True

        result = deal_service.poll_provider_status(db, d.deal_id, "TXN-001", adapter)
        assert result["verified"] is True
        assert result["deal_id"] == d.deal_id

    def test_returns_verified_false_when_provider_denies(self, db):
        d = _make_deal(db)
        adapter = MockWalletAdapter()
        adapter.query_confirmed = False
        adapter.query_status_raw = "ok"

        result = deal_service.poll_provider_status(db, d.deal_id, "TXN-001", adapter)
        assert result["verified"] is False
        assert "unconfirmed" in result["status_raw"] or result["status_raw"] == "ok"

    def test_calls_query_transaction_status_on_adapter(self, db):
        d = _make_deal(db)
        adapter = MockWalletAdapter()
        deal_service.poll_provider_status(db, d.deal_id, "TXN-XYZ", adapter)
        assert "TXN-XYZ" in adapter.query_recorded_calls

    def test_raises_if_deal_not_created(self, db):
        d = _make_deal(db, status=DealStatus.HELD)
        adapter = MockWalletAdapter()
        with pytest.raises(ValueError, match="CREATED"):
            deal_service.poll_provider_status(db, d.deal_id, "TXN-001", adapter)

    def test_raises_if_deal_not_found(self, db):
        adapter = MockWalletAdapter()
        with pytest.raises(ValueError):
            deal_service.poll_provider_status(db, "NOPE1", "TXN-001", adapter)


# ─────────────────────────────────────────────────────────────────────────────
# TASK 3b — Merchant Proof-of-Life
# ─────────────────────────────────────────────────────────────────────────────


class TestIsAckOverdue:
    def test_overdue_when_window_elapsed_and_not_acked(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=False)
        assert deal_service.is_merchant_ack_overdue(d) is True

    def test_not_overdue_within_window(self, db):
        d = _make_deal(db, created_minutes_ago=5, merchant_acked=False)
        assert deal_service.is_merchant_ack_overdue(d) is False

    def test_not_overdue_if_already_acked(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=True)
        assert deal_service.is_merchant_ack_overdue(d) is False

    def test_not_overdue_if_deal_is_not_created(self, db):
        d = _make_deal(db, status=DealStatus.HELD, created_minutes_ago=20)
        assert deal_service.is_merchant_ack_overdue(d) is False


class TestFastTrackCancel:
    def test_cancels_eligible_deal(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=False)
        cancelled = deal_service.fast_track_cancel(db, d.deal_id)
        assert cancelled.status == DealStatus.CANCELLED

    def test_writes_audit_log(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=False)
        deal_service.fast_track_cancel(db, d.deal_id)
        log = db.query(EscrowStateLog).filter_by(
            triggered_by="buyer_fast_track_cancel"
        ).first()
        assert log is not None
        assert log.escrow_id is None   # no escrow on CREATED deal
        meta = json.loads(log.metadata_json)
        assert meta["deal_id"] == d.deal_id

    def test_raises_if_already_acked(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=True)
        with pytest.raises(ValueError, match="acknowledged"):
            deal_service.fast_track_cancel(db, d.deal_id)

    def test_raises_if_window_not_elapsed(self, db):
        d = _make_deal(db, created_minutes_ago=5, merchant_acked=False)
        with pytest.raises(ValueError, match="window"):
            deal_service.fast_track_cancel(db, d.deal_id)

    def test_raises_if_deal_not_created(self, db):
        d = _make_deal(db, status=DealStatus.HELD, created_minutes_ago=20)
        with pytest.raises(ValueError, match="CREATED"):
            deal_service.fast_track_cancel(db, d.deal_id)


class TestAcknowledgeDeal:
    def test_sets_merchant_acknowledged_true(self, db):
        d = _make_deal(db, merchant_acked=False)
        updated = deal_service.acknowledge_deal(db, d.deal_id)
        assert updated.merchant_acknowledged is True

    def test_deal_stays_created_after_ack(self, db):
        d = _make_deal(db)
        updated = deal_service.acknowledge_deal(db, d.deal_id)
        assert updated.status == DealStatus.CREATED

    def test_raises_on_completed_deal(self, db):
        d = _make_deal(db, status=DealStatus.COMPLETED)
        with pytest.raises(ValueError):
            deal_service.acknowledge_deal(db, d.deal_id)


class TestMerchantAckJob:
    def test_sends_alert_for_overdue_deal(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=False)
        twilio = MockTwilioAdapter()
        job = MerchantAckJob(db, twilio)
        result = job.execute()
        assert result["checked"] == 1
        assert result["alerts_sent"] == 1

    def test_no_alert_for_acked_deal(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=True)
        twilio = MockTwilioAdapter()
        job = MerchantAckJob(db, twilio)
        result = job.execute()
        assert result["checked"] == 0

    def test_no_alert_within_window(self, db):
        d = _make_deal(db, created_minutes_ago=5, merchant_acked=False)
        twilio = MockTwilioAdapter()
        job = MerchantAckJob(db, twilio)
        result = job.execute()
        assert result["checked"] == 0

    def test_twilio_failure_counted_as_error(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=False)
        twilio = MockTwilioAdapter(should_fail=True)
        job = MerchantAckJob(db, twilio)
        result = job.execute()
        assert result["errors"] == 1
        assert result["alerts_sent"] == 0

    def test_audit_log_written_on_alert(self, db):
        d = _make_deal(db, created_minutes_ago=20, merchant_acked=False)
        job = MerchantAckJob(db, MockTwilioAdapter())
        job.execute()
        log = db.query(EscrowStateLog).filter_by(
            triggered_by="merchant_proof_of_life_alert"
        ).first()
        assert log is not None
        assert log.escrow_id is None


# ─────────────────────────────────────────────────────────────────────────────
# TASK 3c — confirm_delivery EXPIRED guard
# ─────────────────────────────────────────────────────────────────────────────


class TestConfirmDeliveryDisputeGuard:
    def test_raises_specific_error_for_expired_deal(self, db):
        d = _make_deal(db, status=DealStatus.EXPIRED)
        with pytest.raises(ValueError) as exc_info:
            deal_service.confirm_delivery(db, d.deal_id)
        assert "expired" in str(exc_info.value).lower()
        assert "reversed" in str(exc_info.value).lower()

    def test_raises_generic_error_for_completed_deal(self, db):
        d = _make_deal(db, status=DealStatus.COMPLETED)
        with pytest.raises(ValueError) as exc_info:
            deal_service.confirm_delivery(db, d.deal_id)
        # Should NOT be the EXPIRED-specific message
        assert "reversed" not in str(exc_info.value).lower()

    def test_raises_generic_error_for_cancelled_deal(self, db):
        d = _make_deal(db, status=DealStatus.CANCELLED)
        with pytest.raises(ValueError):
            deal_service.confirm_delivery(db, d.deal_id)


# ─────────────────────────────────────────────────────────────────────────────
# TASK 4 — ZIMRA fiscal adapter audit log
# ─────────────────────────────────────────────────────────────────────────────


class TestZimraFiscalAuditLog:
    """
    We test the audit-logging logic in isolation by monkeypatching the
    requests.post call so no real HTTP request is made.
    """

    def _make_adapter(self, db, monkeypatch, *, should_fail=False):
        """Build a ZimraFiscalAdapter with mocked HTTP and a real db_session."""
        import unittest.mock as mock
        from app.adapters.zimra_fiscal_adapter import ZimraFiscalAdapter

        if should_fail:
            monkeypatch.setattr(
                "app.adapters.zimra_fiscal_adapter.requests.post",
                mock.Mock(side_effect=__import__("requests").exceptions.ConnectionError("down")),
            )
        else:
            fake_response = mock.Mock()
            fake_response.json.return_value = {
                "fiscal_auth_code":   "FAC-001",
                "z_number":           "Z-9999",
                "tax_invoice_number": "TIN-42",
            }
            fake_response.raise_for_status = mock.Mock()
            monkeypatch.setattr(
                "app.adapters.zimra_fiscal_adapter.requests.post",
                mock.Mock(return_value=fake_response),
            )

        return ZimraFiscalAdapter(
            api_key    = "test-key",
            api_url    = "https://zimra.test",
            db_session = db,
        )

    def _transaction(self, escrow_id=1, deal_id="TST01"):
        from datetime import date
        return {
            "settlement_id":    "SET-001",
            "recipient_type":   "merchant",
            "recipient_id":     "0771234567",
            "gross_commission": Decimal("15.75"),
            "vat_rate":         Decimal("15.5"),
            "transaction_date": date.today(),
            "reference_id":     "REF-001",
            "escrow_id":        escrow_id,
            "deal_id":          deal_id,
        }

    def test_audit_log_written_on_success(self, db, monkeypatch):
        adapter = self._make_adapter(db, monkeypatch)
        adapter.generate_fiscal_entry(self._transaction(escrow_id=None))

        log = db.query(EscrowStateLog).filter_by(
            triggered_by="fiscal_receipt_submitted"
        ).first()
        assert log is not None
        meta = json.loads(log.metadata_json)
        assert meta["success"] is True
        assert meta["fiscal_auth_code"] == "FAC-001"
        assert meta["z_number"] == "Z-9999"
        assert meta["tax_invoice_number"] == "TIN-42"

    def test_audit_log_written_on_failure(self, db, monkeypatch):
        adapter = self._make_adapter(db, monkeypatch, should_fail=True)
        import pytest
        with pytest.raises(Exception):
            adapter.generate_fiscal_entry(self._transaction(escrow_id=None))

        log = db.query(EscrowStateLog).filter_by(
            triggered_by="fiscal_receipt_submitted"
        ).first()
        assert log is not None
        meta = json.loads(log.metadata_json)
        assert meta["success"] is False

    def test_audit_log_contains_deal_id(self, db, monkeypatch):
        adapter = self._make_adapter(db, monkeypatch)
        adapter.generate_fiscal_entry(self._transaction(escrow_id=None, deal_id="MYDT1"))

        log = db.query(EscrowStateLog).filter_by(
            triggered_by="fiscal_receipt_submitted"
        ).first()
        meta = json.loads(log.metadata_json)
        assert meta["deal_id"] == "MYDT1"

    def test_audit_log_has_null_escrow_id_when_none_provided(self, db, monkeypatch):
        adapter = self._make_adapter(db, monkeypatch)
        adapter.generate_fiscal_entry(self._transaction(escrow_id=None))

        log = db.query(EscrowStateLog).filter_by(
            triggered_by="fiscal_receipt_submitted"
        ).first()
        assert log.escrow_id is None

    def test_no_audit_log_when_no_db_session(self, db, monkeypatch):
        """When db_session=None, generate_fiscal_entry proceeds but logs nothing."""
        from app.adapters.zimra_fiscal_adapter import ZimraFiscalAdapter
        import unittest.mock as mock

        fake_response = mock.Mock()
        fake_response.json.return_value = {"fiscal_auth_code": "FAC-999"}
        fake_response.raise_for_status = mock.Mock()
        monkeypatch.setattr(
            "app.adapters.zimra_fiscal_adapter.requests.post",
            mock.Mock(return_value=fake_response),
        )

        adapter = ZimraFiscalAdapter(
            api_key    = "test-key",
            api_url    = "https://zimra.test",
            db_session = None,   # ← no session
        )
        # Should not raise
        adapter.generate_fiscal_entry(self._transaction(escrow_id=None))

        # No rows written
        count = db.query(EscrowStateLog).filter_by(
            triggered_by="fiscal_receipt_submitted"
        ).count()
        assert count == 0
