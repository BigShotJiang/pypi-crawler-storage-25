"""
Unit tests for MockWalletAdapter.

Validates:
  - Call recording (including isolation from caller mutations)
  - Default success response shape
  - Configurable soft failure (success=False)
  - Configurable hard failure (exception raising)
  - reset() helper
  - Drop-in compatibility with the WalletAdapter interface
"""

import pytest

from app.adapters.mock_wallet_adapter import MockWalletAdapter
from app.adapters.wallet_adapter import WalletAdapter

# ---------------------------------------------------------------------------
# Shared fixtures / constants
# ---------------------------------------------------------------------------

BASE_INSTRUCTION = {
    "external_transaction_id": "TXN-MOCK-001",
    "payer_wallet_id": "0771234567",
    "amount": 50.00,
    "reason": "timeout",
}


def make_instruction(**overrides) -> dict:
    inst = dict(BASE_INSTRUCTION)
    inst.update(overrides)
    return inst


# ---------------------------------------------------------------------------
# Call recording
# ---------------------------------------------------------------------------


class TestRecording:
    def test_records_single_call(self):
        adapter = MockWalletAdapter()
        adapter.reverse_transaction(BASE_INSTRUCTION)
        assert len(adapter.recorded_calls) == 1

    def test_recorded_call_matches_instruction(self):
        adapter = MockWalletAdapter()
        adapter.reverse_transaction(BASE_INSTRUCTION)
        assert adapter.recorded_calls[0] == BASE_INSTRUCTION

    def test_records_multiple_calls(self):
        adapter = MockWalletAdapter()
        for _ in range(3):
            adapter.reverse_transaction(BASE_INSTRUCTION)
        assert len(adapter.recorded_calls) == 3

    def test_recorded_call_is_a_copy(self):
        """Mutating the original dict must not affect recorded history."""
        adapter = MockWalletAdapter()
        inst = make_instruction(amount=50.00)
        adapter.reverse_transaction(inst)
        inst["amount"] = 999.0  # mutate after the call
        assert adapter.recorded_calls[0]["amount"] == 50.00

    def test_reset_clears_recorded_calls(self):
        adapter = MockWalletAdapter()
        adapter.reverse_transaction(BASE_INSTRUCTION)
        adapter.reset()
        assert adapter.recorded_calls == []

    def test_reset_allows_fresh_recording(self):
        adapter = MockWalletAdapter()
        adapter.reverse_transaction(BASE_INSTRUCTION)
        adapter.reset()
        adapter.reverse_transaction(BASE_INSTRUCTION)
        assert len(adapter.recorded_calls) == 1


# ---------------------------------------------------------------------------
# Default success response
# ---------------------------------------------------------------------------


class TestSuccessResponse:
    def test_default_success_true(self):
        adapter = MockWalletAdapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["success"] is True

    def test_default_status_confirmed(self):
        adapter = MockWalletAdapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["status"] == "confirmed"

    def test_reversal_id_is_non_empty_string(self):
        adapter = MockWalletAdapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert isinstance(result["reversal_id"], str)
        assert len(result["reversal_id"]) > 0

    def test_reversal_ids_are_unique_across_calls(self):
        adapter = MockWalletAdapter()
        r1 = adapter.reverse_transaction(BASE_INSTRUCTION)
        r2 = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert r1["reversal_id"] != r2["reversal_id"]

    def test_timestamp_is_iso_format(self):
        from datetime import datetime
        adapter = MockWalletAdapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        # Must not raise
        datetime.fromisoformat(result["timestamp"])

    def test_success_false_override(self):
        adapter = MockWalletAdapter(success=False)
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["success"] is False
        assert result["status"] == "failed"


# ---------------------------------------------------------------------------
# Soft failure injection (fail_on_tx_id)
# ---------------------------------------------------------------------------


class TestSoftFailureInjection:
    def test_fail_on_tx_id_returns_success_false(self):
        adapter = MockWalletAdapter(fail_on_tx_id="TXN-MOCK-001")
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["success"] is False

    def test_fail_on_tx_id_returns_empty_reversal_id(self):
        adapter = MockWalletAdapter(fail_on_tx_id="TXN-MOCK-001")
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["reversal_id"] == ""

    def test_fail_on_tx_id_returns_failed_status(self):
        adapter = MockWalletAdapter(fail_on_tx_id="TXN-MOCK-001")
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        assert result["status"] == "failed"

    def test_fail_on_tx_id_does_not_affect_other_transactions(self):
        adapter = MockWalletAdapter(fail_on_tx_id="TXN-MOCK-001")
        other = make_instruction(external_transaction_id="TXN-OTHER")
        result = adapter.reverse_transaction(other)
        assert result["success"] is True

    def test_call_is_recorded_on_soft_failure(self):
        adapter = MockWalletAdapter(fail_on_tx_id="TXN-MOCK-001")
        adapter.reverse_transaction(BASE_INSTRUCTION)
        assert len(adapter.recorded_calls) == 1


# ---------------------------------------------------------------------------
# Hard failure injection (raise_on_tx_id)
# ---------------------------------------------------------------------------


class TestHardFailureInjection:
    def test_raise_on_tx_id_raises_default_runtime_error(self):
        adapter = MockWalletAdapter(raise_on_tx_id="TXN-MOCK-001")
        with pytest.raises(RuntimeError, match="Mock adapter error"):
            adapter.reverse_transaction(BASE_INSTRUCTION)

    def test_raise_on_tx_id_raises_custom_exception(self):
        exc = ValueError("Custom test exception")
        adapter = MockWalletAdapter(
            raise_on_tx_id="TXN-MOCK-001",
            raise_exception=exc,
        )
        with pytest.raises(ValueError, match="Custom test exception"):
            adapter.reverse_transaction(BASE_INSTRUCTION)

    def test_raise_on_tx_id_does_not_affect_other_transactions(self):
        adapter = MockWalletAdapter(raise_on_tx_id="TXN-MOCK-001")
        other = make_instruction(external_transaction_id="TXN-SAFE")
        result = adapter.reverse_transaction(other)
        assert result["success"] is True

    def test_call_is_recorded_before_exception_is_raised(self):
        """The recording happens before the exception, so tests can inspect it."""
        adapter = MockWalletAdapter(raise_on_tx_id="TXN-MOCK-001")
        with pytest.raises(RuntimeError):
            adapter.reverse_transaction(BASE_INSTRUCTION)
        assert len(adapter.recorded_calls) == 1


# ---------------------------------------------------------------------------
# Interface compatibility
# ---------------------------------------------------------------------------


class TestInterfaceCompatibility:
    def test_is_wallet_adapter_subclass(self):
        adapter = MockWalletAdapter()
        assert isinstance(adapter, WalletAdapter)

    def test_satisfies_reverse_transaction_contract(self):
        """Response dict must contain all keys required by WalletAdapter docs."""
        adapter = MockWalletAdapter()
        result = adapter.reverse_transaction(BASE_INSTRUCTION)
        for key in ("success", "reversal_id", "status", "timestamp"):
            assert key in result, f"Missing key: {key}"
