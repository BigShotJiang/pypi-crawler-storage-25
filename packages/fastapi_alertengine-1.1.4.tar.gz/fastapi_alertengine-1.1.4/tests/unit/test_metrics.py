# tests/unit/test_metrics.py
"""Tests for app.core.metrics — record_* helpers and aggregate_metrics."""

from unittest.mock import MagicMock, patch, call

import pytest

from app.core.metrics import (
    METRICS_STREAM,
    record_webhook_latency,
    record_payment_processing_time,
    record_courier_acceptance_time,
    record_redis_failure,
    record_state_transition_failure,
    aggregate_metrics,
)


# ─── Shared helpers ───────────────────────────────────────────────────────────

def _xadd_fields(rdb):
    """Return the fields dict from the most recent rdb.xadd call."""
    args, _ = rdb.xadd.call_args
    return args[1]


# ─── record_webhook_latency ───────────────────────────────────────────────────

class TestRecordWebhookLatency:
    def test_calls_xadd_on_metrics_stream(self):
        rdb = MagicMock()
        record_webhook_latency(rdb, 120.5)
        rdb.xadd.assert_called_once()
        args, _ = rdb.xadd.call_args
        assert args[0] == METRICS_STREAM

    def test_sets_type_field(self):
        rdb = MagicMock()
        record_webhook_latency(rdb, 50.0)
        fields = _xadd_fields(rdb)
        assert fields["type"] == "webhook_latency"

    def test_latency_ms_field_is_string(self):
        rdb = MagicMock()
        record_webhook_latency(rdb, 99.99)
        fields = _xadd_fields(rdb)
        assert "latency_ms" in fields
        assert isinstance(fields["latency_ms"], str)
        assert float(fields["latency_ms"]) == pytest.approx(99.99)

    def test_includes_timestamp(self):
        rdb = MagicMock()
        with patch("time.time", return_value=1700000000.0):
            record_webhook_latency(rdb, 10.0)
        fields = _xadd_fields(rdb)
        assert fields["ts"] == "1700000000000"

    def test_never_raises_on_redis_error(self):
        rdb = MagicMock()
        rdb.xadd.side_effect = Exception("Redis down")
        record_webhook_latency(rdb, 50.0)   # must not raise


# ─── record_payment_processing_time ──────────────────────────────────────────

class TestRecordPaymentProcessingTime:
    def test_sets_correct_type(self):
        rdb = MagicMock()
        record_payment_processing_time(rdb, "REF123", 200.0)
        fields = _xadd_fields(rdb)
        assert fields["type"] == "payment_processing_time"

    def test_includes_ref_field(self):
        rdb = MagicMock()
        record_payment_processing_time(rdb, "PAYNOW-XYZ", 50.0)
        fields = _xadd_fields(rdb)
        assert fields["ref"] == "PAYNOW-XYZ"

    def test_includes_duration_ms(self):
        rdb = MagicMock()
        record_payment_processing_time(rdb, "REF", 300.5)
        fields = _xadd_fields(rdb)
        assert float(fields["duration_ms"]) == pytest.approx(300.5)

    def test_never_raises(self):
        rdb = MagicMock()
        rdb.xadd.side_effect = Exception("down")
        record_payment_processing_time(rdb, "REF", 100.0)


# ─── record_courier_acceptance_time ──────────────────────────────────────────

class TestRecordCourierAcceptanceTime:
    def test_sets_correct_type(self):
        rdb = MagicMock()
        record_courier_acceptance_time(rdb, "DEAL-1", "+263771234567", 1500.0)
        fields = _xadd_fields(rdb)
        assert fields["type"] == "courier_acceptance_time"

    def test_includes_deal_id_and_courier_phone(self):
        rdb = MagicMock()
        record_courier_acceptance_time(rdb, "TDM-ABC", "+263771234567", 200.0)
        fields = _xadd_fields(rdb)
        assert fields["deal_id"] == "TDM-ABC"
        assert fields["courier_phone"] == "+263771234567"

    def test_never_raises(self):
        rdb = MagicMock()
        rdb.xadd.side_effect = RuntimeError("stream full")
        record_courier_acceptance_time(rdb, "D", "+26377", 10.0)


# ─── record_redis_failure ─────────────────────────────────────────────────────

class TestRecordRedisFailure:
    def test_sets_correct_type(self):
        rdb = MagicMock()
        record_redis_failure(rdb, "get", "conn refused")
        fields = _xadd_fields(rdb)
        assert fields["type"] == "redis_failure"

    def test_includes_operation_and_error(self):
        rdb = MagicMock()
        record_redis_failure(rdb, "setex", "timeout after 1s")
        fields = _xadd_fields(rdb)
        assert fields["operation"] == "setex"
        assert "timeout" in fields["error"]

    def test_error_capped_at_200_chars(self):
        rdb = MagicMock()
        long_msg = "x" * 500
        record_redis_failure(rdb, "get", long_msg)
        fields = _xadd_fields(rdb)
        assert len(fields["error"]) <= 200

    def test_never_raises(self):
        rdb = MagicMock()
        rdb.xadd.side_effect = Exception("meta-failure")
        record_redis_failure(rdb, "set", "err")


# ─── record_state_transition_failure ─────────────────────────────────────────

class TestRecordStateTransitionFailure:
    def test_sets_correct_type(self):
        rdb = MagicMock()
        record_state_transition_failure(rdb, "+263771234567", "idle", "delivery_complete")
        fields = _xadd_fields(rdb)
        assert fields["type"] == "state_transition_failure"

    def test_does_not_store_raw_phone(self):
        rdb = MagicMock()
        record_state_transition_failure(rdb, "+263771234567", "idle", "invalid_state")
        fields = _xadd_fields(rdb)
        # Raw phone must not appear
        for v in fields.values():
            assert "+263771234567" not in str(v)

    def test_stores_phone_hash(self):
        rdb = MagicMock()
        record_state_transition_failure(rdb, "+263771234567", "idle", "invalid_state")
        fields = _xadd_fields(rdb)
        assert "phone_hash" in fields

    def test_phone_hash_is_bounded(self):
        rdb = MagicMock()
        record_state_transition_failure(rdb, "+263771234567", "a", "b")
        fields = _xadd_fields(rdb)
        assert 0 <= int(fields["phone_hash"]) < 100_000

    def test_never_raises(self):
        rdb = MagicMock()
        rdb.xadd.side_effect = Exception("down")
        record_state_transition_failure(rdb, "+263771234567", "a", "b")


# ─── aggregate_metrics ───────────────────────────────────────────────────────

def _make_stream_entry(mtype, **kwargs):
    """Build a fake XREVRANGE entry tuple."""
    fields = {b"type": mtype.encode()}
    for k, v in kwargs.items():
        fields[k.encode()] = str(v).encode()
    return (b"1234-0", fields)


class TestAggregateMetrics:
    def _rdb_with_entries(self, entries, stream_len=None):
        rdb = MagicMock()
        rdb.xlen.return_value = stream_len if stream_len is not None else len(entries)
        rdb.execute_command.return_value = entries
        return rdb

    def test_returns_all_expected_keys(self):
        rdb = self._rdb_with_entries([])
        result = aggregate_metrics(rdb)
        assert "webhook_latency" in result
        assert "payment_processing_time" in result
        assert "courier_acceptance_time" in result
        assert "redis_failures" in result
        assert "state_transition_failures" in result
        assert "stream_length" in result

    def test_empty_stream_returns_zeros(self):
        rdb = self._rdb_with_entries([], stream_len=0)
        result = aggregate_metrics(rdb)
        assert result["webhook_latency"]["count"] == 0
        assert result["webhook_latency"]["avg_ms"] == 0.0
        assert result["stream_length"] == 0

    def test_webhook_latency_average(self):
        entries = [
            _make_stream_entry("webhook_latency", latency_ms=100.0),
            _make_stream_entry("webhook_latency", latency_ms=200.0),
        ]
        rdb = self._rdb_with_entries(entries)
        result = aggregate_metrics(rdb)
        assert result["webhook_latency"]["count"] == 2
        assert result["webhook_latency"]["avg_ms"] == pytest.approx(150.0)

    def test_webhook_p95_calculation(self):
        # 20 values: 1..20. p95 index = int(20 * 0.95) = 19 → value 20
        entries = [
            _make_stream_entry("webhook_latency", latency_ms=float(i))
            for i in range(1, 21)
        ]
        rdb = self._rdb_with_entries(entries)
        result = aggregate_metrics(rdb)
        assert result["webhook_latency"]["p95_ms"] >= 18.0

    def test_payment_processing_time_average(self):
        entries = [
            _make_stream_entry("payment_processing_time", duration_ms=300.0, ref="R1"),
            _make_stream_entry("payment_processing_time", duration_ms=100.0, ref="R2"),
        ]
        rdb = self._rdb_with_entries(entries)
        result = aggregate_metrics(rdb)
        assert result["payment_processing_time"]["count"] == 2
        assert result["payment_processing_time"]["avg_ms"] == pytest.approx(200.0)

    def test_redis_failures_counted(self):
        entries = [
            _make_stream_entry("redis_failure", operation="get", error="timeout"),
            _make_stream_entry("redis_failure", operation="set", error="conn refused"),
        ]
        rdb = self._rdb_with_entries(entries)
        result = aggregate_metrics(rdb)
        assert result["redis_failures"]["count"] == 2

    def test_state_transition_failures_counted(self):
        entries = [
            _make_stream_entry("state_transition_failure", from_state="idle", to_state="invalid"),
            _make_stream_entry("state_transition_failure", from_state="idle", to_state="invalid"),
            _make_stream_entry("state_transition_failure", from_state="idle", to_state="invalid"),
        ]
        rdb = self._rdb_with_entries(entries)
        result = aggregate_metrics(rdb)
        assert result["state_transition_failures"]["count"] == 3

    def test_stream_length_from_xlen(self):
        rdb = self._rdb_with_entries([], stream_len=12345)
        result = aggregate_metrics(rdb)
        assert result["stream_length"] == 12345

    def test_never_raises_on_redis_error(self):
        rdb = MagicMock()
        rdb.xlen.side_effect = Exception("Redis down")
        rdb.execute_command.side_effect = Exception("Redis down")
        result = aggregate_metrics(rdb)   # must not raise
        assert "webhook_latency" in result

    def test_uses_xrevrange_command(self):
        rdb = self._rdb_with_entries([])
        aggregate_metrics(rdb, last_n=500)
        rdb.execute_command.assert_called_once_with(
            "XREVRANGE", METRICS_STREAM, "+", "-", "COUNT", "500"
        )
