"""
Unit tests for the Tofamba escrow timeout / auto-reversal system.

These tests validate:
  - Escrow creation with correct expiry timestamp (created_at + 2 hours)
  - Timeout detection (check_expired_escrows)
  - Reversal trigger state transitions and audit logging
  - Graceful failure when the wallet adapter raises an exception
  - Full end-to-end timeout flow via EscrowTimeoutJob
"""

import json
import logging
from datetime import datetime, timedelta
from decimal import Decimal
from unittest.mock import MagicMock, patch

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.adapters.wallet_adapter import WalletAdapter
from app.jobs.escrow_timeout_job import EscrowTimeoutJob
from app.models.database import Base, Escrow, EscrowStateLog, EscrowStatus
from app.services.escrow_timeout_engine import EscrowTimeoutEngine

# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="function")
def db_session():
    """Provide an in-memory SQLite session, rolling back after each test."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()
    Base.metadata.drop_all(engine)


@pytest.fixture
def mock_wallet_adapter():
    """A MagicMock that satisfies the WalletAdapter interface."""
    return MagicMock(spec=WalletAdapter)


@pytest.fixture
def timeout_engine(db_session, mock_wallet_adapter):
    return EscrowTimeoutEngine(db_session, mock_wallet_adapter)


@pytest.fixture
def timeout_job(timeout_engine, mock_wallet_adapter):
    return EscrowTimeoutJob(timeout_engine, mock_wallet_adapter)


def make_escrow(db_session, **kwargs) -> Escrow:
    """Helper: create, add and flush an Escrow with sensible defaults.

    All monetary NOT NULL columns are pre-populated with internally
    consistent values so the DB accepts the row without calling
    validate_amounts().  Individual tests may override any field via kwargs.
    """
    defaults = {
        "order_id": 1,
        # Monetary breakdown (merchant $80, courier $20 → total $100)
        "merchant_gross":       Decimal("80.00"),
        "courier_gross":        Decimal("20.00"),
        "total_escrow":         Decimal("100.00"),
        # Tofamba fee (3.5%)
        "merchant_tandem_fee":  Decimal("2.80"),
        "courier_tandem_fee":   Decimal("0.70"),
        "total_tandem_fee":     Decimal("3.50"),
        # IMTT (2%)
        "merchant_imtt_tax":    Decimal("1.60"),
        "courier_imtt_tax":     Decimal("0.40"),
        "total_imtt_tax":       Decimal("2.00"),
        # Final payouts
        "merchant_final_payout": Decimal("75.60"),
        "courier_final_payout":  Decimal("18.90"),
        # State / identity
        "status":                     EscrowStatus.HELD,
        "wallet_provider":            "ecocash",
        "external_transaction_id":    "TXN-001",
        "payer_wallet_id":            "263771234567",
        "payee_wallet_id":            "263771234568",
    }
    defaults.update(kwargs)
    escrow = Escrow(**defaults)
    db_session.add(escrow)
    db_session.flush()
    return escrow


# ---------------------------------------------------------------------------
# Test 1 – Escrow creation & expiry tracking
# ---------------------------------------------------------------------------


class TestEscrowCreationAndExpiry:
    def test_escrow_created_with_expiry_timestamp(self, db_session):
        """Escrow must be persisted with a non-null expiry_timestamp."""
        escrow = make_escrow(db_session)
        assert escrow.expiry_timestamp is not None

    def test_escrow_expiry_timestamp_is_2_hours_from_creation(self, db_session):
        """expiry_timestamp must equal created_at + 2 hours (within 1 second)."""
        escrow = make_escrow(db_session)
        expected_expiry = escrow.created_at + timedelta(hours=2)
        delta = abs((escrow.expiry_timestamp - expected_expiry).total_seconds())
        assert delta < 1, (
            f"Expected expiry ≈ {expected_expiry}, got {escrow.expiry_timestamp}"
        )

    def test_escrow_default_status_is_held(self, db_session):
        """Newly created escrows must start in HELD state."""
        escrow = make_escrow(db_session)
        assert escrow.status == EscrowStatus.HELD

    def test_escrow_stores_all_audit_fields(self, db_session):
        """All new wallet-provider fields must be persisted correctly."""
        escrow = make_escrow(
            db_session,
            pin_hash="abc123",
            wallet_provider="innbucks",
            external_transaction_id="TXN-999",
            payer_wallet_id="wallet-A",
            payee_wallet_id="wallet-B",
        )
        db_session.commit()
        db_session.refresh(escrow)

        assert escrow.pin_hash == "abc123"
        assert escrow.wallet_provider == "innbucks"
        assert escrow.external_transaction_id == "TXN-999"
        assert escrow.payer_wallet_id == "wallet-A"
        assert escrow.payee_wallet_id == "wallet-B"


# ---------------------------------------------------------------------------
# Test 2 – Timeout detection (check_expired_escrows)
# ---------------------------------------------------------------------------


class TestCheckExpiredEscrows:
    def test_check_expired_escrows_returns_held_escrows_past_2_hours(
        self, db_session, timeout_engine
    ):
        """
        Scenario:
          - Create escrow at T=0, status=HELD
          - Set expiry_timestamp to 1 minute in the past (T=2h 1m has passed)
          - Call check_expired_escrows()
          - Assert: this escrow is included in the returned list
        """
        escrow = make_escrow(db_session)
        # Force expiry into the past
        escrow.expiry_timestamp = datetime.utcnow() - timedelta(minutes=1)
        db_session.commit()

        instructions = timeout_engine.check_expired_escrows()

        escrow_ids = [i["escrow_id"] for i in instructions]
        assert escrow.id in escrow_ids

    def test_check_expired_escrows_ignores_non_held_status(
        self, db_session, timeout_engine
    ):
        """
        Scenario:
          - Create escrow with status=RELEASED (already handled)
          - Set expiry_timestamp in the past
          - Call check_expired_escrows()
          - Assert: this escrow is NOT returned
        """
        escrow = make_escrow(db_session, status=EscrowStatus.RELEASED)
        escrow.expiry_timestamp = datetime.utcnow() - timedelta(minutes=1)
        db_session.commit()

        instructions = timeout_engine.check_expired_escrows()

        escrow_ids = [i["escrow_id"] for i in instructions]
        assert escrow.id not in escrow_ids

    def test_check_expired_escrows_ignores_fresh_escrows(
        self, db_session, timeout_engine
    ):
        """
        Scenario:
          - Create escrow at T=0, status=HELD
          - expiry_timestamp is 30 minutes in the future (window not elapsed)
          - Call check_expired_escrows()
          - Assert: this escrow is NOT returned
        """
        escrow = make_escrow(db_session)
        escrow.expiry_timestamp = datetime.utcnow() + timedelta(minutes=30)
        db_session.commit()

        instructions = timeout_engine.check_expired_escrows()

        escrow_ids = [i["escrow_id"] for i in instructions]
        assert escrow.id not in escrow_ids

    def test_check_expired_escrows_returns_instruction_fields(
        self, db_session, timeout_engine
    ):
        """Each returned instruction must contain the required keys."""
        escrow = make_escrow(db_session)
        escrow.expiry_timestamp = datetime.utcnow() - timedelta(minutes=1)
        db_session.commit()

        instructions = timeout_engine.check_expired_escrows()

        assert len(instructions) == 1
        inst = instructions[0]
        assert inst["escrow_id"] == escrow.id
        assert inst["external_transaction_id"] == escrow.external_transaction_id
        assert inst["payer_wallet_id"] == escrow.payer_wallet_id
        assert inst["amount"] == float(escrow.total_escrow)
        assert inst["reason"] == "timeout"


# ---------------------------------------------------------------------------
# Test 3 – Reversal trigger (CRITICAL)
# ---------------------------------------------------------------------------


class TestTriggerReversal:
    def test_trigger_reversal_updates_escrow_status_to_expired(
        self, db_session, timeout_engine, mock_wallet_adapter
    ):
        """
        Scenario:
          - Create escrow with status=HELD
          - Mock wallet adapter to return soft failure (success=False)
          - Call trigger_reversal(escrow_id, reason="timeout")
          - Assert: escrow.status changes to EXPIRED
        """
        escrow = make_escrow(db_session)
        mock_wallet_adapter.reverse_transaction.return_value = {"success": False}

        timeout_engine.trigger_reversal(escrow.id, "timeout")

        db_session.refresh(escrow)
        assert escrow.status == EscrowStatus.EXPIRED

    def test_trigger_reversal_calls_wallet_adapter(
        self, db_session, timeout_engine, mock_wallet_adapter
    ):
        """
        Scenario:
          - Create escrow with external_transaction_id, payer_wallet_id, amount
          - Mock wallet_adapter.reverse_transaction()
          - Call trigger_reversal()
          - Assert: wallet_adapter.reverse_transaction() called with correct
            instruction dict
        """
        escrow = make_escrow(
            db_session,
            external_transaction_id="TXN-XYZ",
            payer_wallet_id="wallet-PAYER",
            merchant_gross=Decimal("60.00"),
            courier_gross=Decimal("15.50"),
            total_escrow=Decimal("75.50"),
        )
        mock_wallet_adapter.reverse_transaction.return_value = {"success": True, "reversal_id": "R1"}

        timeout_engine.trigger_reversal(escrow.id, "timeout")

        mock_wallet_adapter.reverse_transaction.assert_called_once_with(
            {
                "external_transaction_id": "TXN-XYZ",
                "payer_wallet_id": "wallet-PAYER",
                "amount": 75.5,
                "reason": "timeout",
            }
        )

    def test_trigger_reversal_logs_state_transition(
        self, db_session, timeout_engine, mock_wallet_adapter
    ):
        """
        Scenario:
          - Create escrow
          - Call trigger_reversal()
          - Assert: EscrowStateLog entry created with:
              previous_status=HELD, new_status=EXPIRED,
              triggered_by="auto_timeout",
              metadata includes external_transaction_id
        """
        escrow = make_escrow(db_session, external_transaction_id="TXN-LOG")
        mock_wallet_adapter.reverse_transaction.return_value = {"success": False}

        timeout_engine.trigger_reversal(escrow.id, "timeout")

        logs = (
            db_session.query(EscrowStateLog)
            .filter_by(escrow_id=escrow.id)
            .order_by(EscrowStateLog.id)
            .all()
        )
        assert len(logs) >= 1
        expiry_log = logs[0]
        assert expiry_log.previous_status == EscrowStatus.HELD.value
        assert expiry_log.new_status == EscrowStatus.EXPIRED.value
        assert expiry_log.triggered_by == "auto_timeout"

        meta = expiry_log.get_metadata()
        assert meta.get("external_transaction_id") == "TXN-LOG"

    def test_trigger_reversal_on_wallet_adapter_success(
        self, db_session, timeout_engine, mock_wallet_adapter
    ):
        """
        Scenario:
          - Create escrow
          - Mock wallet_adapter.reverse_transaction() returns
            {"success": True, "reversal_id": "REV123"}
          - Call trigger_reversal()
          - Assert: escrow.status becomes REVERSAL_INITIATED
          - Assert: escrow.reversal_triggered_at is set
          - Assert: EscrowStateLog shows transition to REVERSAL_INITIATED
        """
        escrow = make_escrow(db_session)
        mock_wallet_adapter.reverse_transaction.return_value = {
            "success": True,
            "reversal_id": "REV123",
            "status": "confirmed",
        }

        result = timeout_engine.trigger_reversal(escrow.id, "timeout")

        db_session.refresh(escrow)
        assert escrow.status == EscrowStatus.REVERSAL_INITIATED
        assert escrow.reversal_triggered_at is not None

        # Check the REVERSAL_INITIATED log entry exists
        reversal_log = (
            db_session.query(EscrowStateLog)
            .filter_by(
                escrow_id=escrow.id,
                new_status=EscrowStatus.REVERSAL_INITIATED.value,
            )
            .first()
        )
        assert reversal_log is not None
        assert reversal_log.previous_status == EscrowStatus.EXPIRED.value
        assert reversal_log.triggered_by == "auto_timeout"

        assert result["status"] == EscrowStatus.REVERSAL_INITIATED.value
        assert result["reversal_id"] == "REV123"

    def test_trigger_reversal_on_wallet_adapter_failure(
        self, db_session, timeout_engine, mock_wallet_adapter, caplog
    ):
        """
        Scenario:
          - Create escrow
          - Mock wallet_adapter.reverse_transaction() raises an exception
          - Call trigger_reversal()
          - Assert: escrow remains HELD (no state change)
          - Assert: error is logged with escrow_id and exception details
          - Assert: EscrowStateLog is NOT created
        """
        escrow = make_escrow(db_session)
        mock_wallet_adapter.reverse_transaction.side_effect = ConnectionError(
            "provider unavailable"
        )

        with caplog.at_level(logging.ERROR):
            result = timeout_engine.trigger_reversal(escrow.id, "timeout")

        db_session.refresh(escrow)
        assert escrow.status == EscrowStatus.HELD

        log_count = (
            db_session.query(EscrowStateLog).filter_by(escrow_id=escrow.id).count()
        )
        assert log_count == 0

        assert result["status"] == "error"
        assert any(str(escrow.id) in record.message for record in caplog.records)

    def test_trigger_reversal_skips_non_held_escrow(
        self, db_session, timeout_engine
    ):
        """
        trigger_reversal must return {"status": "skipped"} when the escrow
        is not in HELD state.

        Under the pessimistic-locking (SKIP LOCKED) contract the engine never
        raises ValueError for an already-processed or wrong-state row — it
        returns "skipped" so that concurrent workers can pass cleanly.
        """
        escrow = make_escrow(db_session, status=EscrowStatus.RELEASED)

        result = timeout_engine.trigger_reversal(escrow.id, "manual")

        assert result["status"] == "skipped"
        assert result["escrow_id"] == escrow.id

    def test_trigger_reversal_skips_missing_escrow(
        self, db_session, timeout_engine
    ):
        """
        trigger_reversal must return {"status": "skipped"} when the escrow
        ID does not exist.

        Same SKIP LOCKED contract: a missing row is treated identically to
        a locked row — silently skipped rather than raising an exception.
        """
        result = timeout_engine.trigger_reversal(99999, "timeout")

        assert result["status"] == "skipped"
        assert result["escrow_id"] == 99999


# ---------------------------------------------------------------------------
# Test 4 – Full end-to-end timeout flow
# ---------------------------------------------------------------------------


class TestEndToEndTimeoutFlow:
    def test_end_to_end_escrow_timeout_and_reversal(
        self, db_session, timeout_engine, mock_wallet_adapter, timeout_job
    ):
        """
        Scenario:
          1. Create escrow with status=HELD, expiry already in the past
          2. Mock wallet adapter to return success
          3. Call timeout_job.execute()
          4. Assert: check_expired_escrows identifies the escrow
          5. Assert: trigger_reversal is called
          6. Assert: wallet_adapter.reverse_transaction is called with the
             correct instruction
          7. Assert: escrow.status = REVERSAL_INITIATED
          8. Assert: EscrowStateLog contains full audit trail
        """
        escrow = make_escrow(
            db_session,
            order_id=100,
            total_escrow=Decimal("50.00"),
            external_transaction_id="TXN-E2E",
            payer_wallet_id="wallet-E2E",
        )
        # Force the escrow to be already expired
        escrow.expiry_timestamp = datetime.utcnow() - timedelta(minutes=5)
        db_session.commit()

        mock_wallet_adapter.reverse_transaction.return_value = {
            "success": True,
            "reversal_id": "REV-E2E",
            "status": "confirmed",
        }

        summary = timeout_job.execute()

        # Job processed exactly one escrow
        assert summary["processed"] == 1
        assert summary["succeeded"] == 1
        assert summary["failed"] == 0
        assert summary["errors"] == 0

        # Escrow reached REVERSAL_INITIATED
        db_session.refresh(escrow)
        assert escrow.status == EscrowStatus.REVERSAL_INITIATED
        assert escrow.reversal_triggered_at is not None

        # Wallet adapter was called with the correct instruction
        mock_wallet_adapter.reverse_transaction.assert_called_once_with(
            {
                "external_transaction_id": "TXN-E2E",
                "payer_wallet_id": "wallet-E2E",
                "amount": 50.0,
                "reason": "timeout",
            }
        )

        # Full audit trail: HELD → EXPIRED → REVERSAL_INITIATED
        logs = (
            db_session.query(EscrowStateLog)
            .filter_by(escrow_id=escrow.id)
            .order_by(EscrowStateLog.id)
            .all()
        )
        assert len(logs) == 2

        held_to_expired = logs[0]
        assert held_to_expired.previous_status == EscrowStatus.HELD.value
        assert held_to_expired.new_status == EscrowStatus.EXPIRED.value
        assert held_to_expired.triggered_by == "auto_timeout"

        expired_to_initiated = logs[1]
        assert expired_to_initiated.previous_status == EscrowStatus.EXPIRED.value
        assert expired_to_initiated.new_status == EscrowStatus.REVERSAL_INITIATED.value
        assert expired_to_initiated.triggered_by == "auto_timeout"

        # Wallet response is stored in the metadata of the second log entry
        meta = expired_to_initiated.get_metadata()
        assert meta.get("external_transaction_id") == "TXN-E2E"
        assert meta["wallet_response"]["reversal_id"] == "REV-E2E"

    def test_job_handles_multiple_expired_escrows(
        self, db_session, timeout_engine, mock_wallet_adapter, timeout_job
    ):
        """All expired escrows in a single job run should be processed."""
        for i in range(3):
            e = make_escrow(
                db_session,
                order_id=i + 1,
                external_transaction_id=f"TXN-{i}",
            )
            e.expiry_timestamp = datetime.utcnow() - timedelta(minutes=1)
        db_session.commit()

        mock_wallet_adapter.reverse_transaction.return_value = {
            "success": True,
            "reversal_id": "REV-MULTI",
            "status": "confirmed",
        }

        summary = timeout_job.execute()

        assert summary["processed"] == 3
        assert summary["succeeded"] == 3
        assert mock_wallet_adapter.reverse_transaction.call_count == 3

    def test_job_skips_non_expired_escrows(
        self, db_session, timeout_engine, mock_wallet_adapter, timeout_job
    ):
        """Escrows still within their 2-hour window must not be touched."""
        fresh = make_escrow(db_session, order_id=10)
        fresh.expiry_timestamp = datetime.utcnow() + timedelta(hours=1)
        db_session.commit()

        summary = timeout_job.execute()

        assert summary["processed"] == 0
        mock_wallet_adapter.reverse_transaction.assert_not_called()


# ---------------------------------------------------------------------------
# Test 5 – EscrowStatus enum completeness
# ---------------------------------------------------------------------------


class TestEscrowStatusEnum:
    def test_all_required_statuses_exist(self):
        """All required EscrowStatus values must be present."""
        statuses = {s.value for s in EscrowStatus}
        assert "held" in statuses
        assert "released" in statuses
        assert "expired" in statuses
        assert "reversal_initiated" in statuses
        assert "reversal_confirmed" in statuses

    def test_escrow_state_log_get_metadata_empty(self, db_session):
        """get_metadata() should return an empty dict when metadata_json is None."""
        escrow = make_escrow(db_session)
        log = EscrowStateLog(
            escrow_id=escrow.id,
            previous_status="held",
            new_status="expired",
            triggered_by="auto_timeout",
        )
        db_session.add(log)
        db_session.flush()

        assert log.get_metadata() == {}
