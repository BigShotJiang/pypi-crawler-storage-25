# tests/unit/test_alert_engine_enhancements.py
"""
Tests for the enhanced AlertEngine system.

Covers:
  - AlertDeduplicator (Redis NX dedup, fail-open on error)
  - AlertNotificationService (severity gating, no-op without destinations)
  - AlertCleanupJob (batch deletion, archive, retention logic)
  - metrics_router dashboard_health_adapter bug fix (stuck_deals)
"""

import asyncio
from datetime import datetime, UTC, timedelta
from unittest.mock import AsyncMock, MagicMock, patch, call

import pytest

from app.core.alert_deduplicator import AlertDeduplicator
from app.core.alert_notification_service import AlertNotificationService


# ─── AlertDeduplicator ────────────────────────────────────────────────────────

class TestAlertDeduplicator:
    """Unit tests for AlertDeduplicator."""

    def test_first_fire_returns_true(self):
        """A fresh key should allow the alert to fire."""
        rdb = MagicMock()
        rdb.set.return_value = True   # SET NX succeeds → key was newly set
        dedup = AlertDeduplicator(rdb)
        assert dedup.should_fire("webhook_latency", "critical") is True

    def test_duplicate_returns_false(self):
        """A pre-existing key should suppress the alert."""
        rdb = MagicMock()
        rdb.set.return_value = None   # SET NX fails → key already exists
        dedup = AlertDeduplicator(rdb)
        assert dedup.should_fire("webhook_latency", "critical") is False

    def test_redis_key_format(self):
        """Key must follow the alert:dedup:{alert_type} convention."""
        rdb = MagicMock()
        rdb.set.return_value = True
        dedup = AlertDeduplicator(rdb)
        dedup.should_fire("redis_failures")
        args, kwargs = rdb.set.call_args
        assert args[0] == "alert:dedup:redis_failures"

    def test_set_called_with_nx_and_ttl(self):
        """Redis SET must use NX and EX flags."""
        rdb = MagicMock()
        rdb.set.return_value = True
        dedup = AlertDeduplicator(rdb, cooldown_seconds=120)
        dedup.should_fire("state_transitions", "warning")
        _, kwargs = rdb.set.call_args
        assert kwargs.get("nx") is True
        assert kwargs.get("ex") == 120

    def test_fail_open_on_redis_error(self):
        """If Redis raises, should_fire must return True (fail-open)."""
        rdb = MagicMock()
        rdb.set.side_effect = Exception("Redis down")
        dedup = AlertDeduplicator(rdb)
        assert dedup.should_fire("webhook_latency", "critical") is True

    def test_reset_deletes_key(self):
        """reset() must delete the dedup key."""
        rdb = MagicMock()
        dedup = AlertDeduplicator(rdb)
        dedup.reset("webhook_latency")
        rdb.delete.assert_called_once_with("alert:dedup:webhook_latency")

    def test_reset_swallows_redis_error(self):
        """reset() must not raise even if Redis is unavailable."""
        rdb = MagicMock()
        rdb.delete.side_effect = Exception("down")
        dedup = AlertDeduplicator(rdb)
        dedup.reset("webhook_latency")   # must not raise

    def test_ttl_returns_value(self):
        """ttl() returns remaining seconds when key exists."""
        rdb = MagicMock()
        rdb.ttl.return_value = 250
        dedup = AlertDeduplicator(rdb)
        assert dedup.ttl("webhook_latency") == 250

    def test_ttl_returns_none_when_key_absent(self):
        """ttl() returns None when the dedup key doesn't exist (-2 from Redis)."""
        rdb = MagicMock()
        rdb.ttl.return_value = -2
        dedup = AlertDeduplicator(rdb)
        assert dedup.ttl("webhook_latency") is None

    def test_different_alert_types_use_different_keys(self):
        """Two different alert types should use independent dedup keys."""
        assert AlertDeduplicator._dedup_key("a") != AlertDeduplicator._dedup_key("b")


# ─── AlertNotificationService ────────────────────────────────────────────────

class TestAlertNotificationService:
    """Unit tests for AlertNotificationService."""

    def _run(self, coro):
        return asyncio.get_event_loop().run_until_complete(coro)

    def test_notify_does_nothing_without_destinations(self):
        """When no email or Slack is configured, notify() is a no-op."""
        with patch.dict("os.environ", {"ALERT_EMAIL_TO": "", "ALERT_SLACK_WEBHOOK": ""}):
            svc = AlertNotificationService()
            # Should complete without raising
            self._run(svc.notify(
                alert_type="webhook_latency",
                severity="critical",
                value=5000.0,
                threshold=3000.0,
                reason="p95 too high",
            ))

    def test_notify_skips_non_critical_by_default(self):
        """By default only critical alerts are dispatched."""
        with patch.dict("os.environ", {
            "ALERT_EMAIL_TO": "ops@example.com",
            "ALERT_SLACK_WEBHOOK": "",
        }):
            svc = AlertNotificationService()
            with patch.object(svc, "_send_email") as mock_email:
                self._run(svc.notify(
                    alert_type="redis_failures",
                    severity="warning",
                    value=6.0,
                    threshold=5.0,
                    reason="warning threshold breached",
                ))
            mock_email.assert_not_called()

    def test_notify_dispatches_critical_via_email(self):
        """Critical alerts must attempt email dispatch."""
        with patch.dict("os.environ", {
            "ALERT_EMAIL_TO": "ops@example.com",
            "ALERT_SLACK_WEBHOOK": "",
        }):
            svc = AlertNotificationService()
            with patch.object(svc, "_send_email") as mock_email:
                self._run(svc.notify(
                    alert_type="webhook_latency",
                    severity="critical",
                    value=5000.0,
                    threshold=3000.0,
                    reason="p95 critical",
                ))
            mock_email.assert_called_once()

    def test_notify_dispatches_critical_via_slack(self):
        """Critical alerts must attempt Slack dispatch when webhook configured."""
        with patch.dict("os.environ", {
            "ALERT_EMAIL_TO": "",
            "ALERT_SLACK_WEBHOOK": "https://hooks.slack.com/test",
        }):
            svc = AlertNotificationService()
            with patch.object(svc, "_send_slack") as mock_slack:
                self._run(svc.notify(
                    alert_type="webhook_latency",
                    severity="critical",
                    value=5000.0,
                    threshold=3000.0,
                    reason="p95 critical",
                ))
            mock_slack.assert_called_once()

    def test_custom_severity_threshold(self):
        """Notifications can be configured to fire on 'warning' as well."""
        with patch.dict("os.environ", {
            "ALERT_EMAIL_TO": "ops@example.com",
            "ALERT_SLACK_WEBHOOK": "",
        }):
            svc = AlertNotificationService(notify_severities={"critical", "warning"})
            with patch.object(svc, "_send_email") as mock_email:
                self._run(svc.notify(
                    alert_type="redis_failures",
                    severity="warning",
                    value=6.0,
                    threshold=5.0,
                    reason="warning",
                ))
            mock_email.assert_called_once()

    def test_email_failure_does_not_raise(self):
        """A failing email dispatch must not propagate an exception."""
        with patch.dict("os.environ", {
            "ALERT_EMAIL_TO": "ops@example.com",
            "ALERT_SLACK_WEBHOOK": "",
        }):
            svc = AlertNotificationService()
            with patch.object(svc, "_send_email", side_effect=Exception("SMTP down")):
                self._run(svc.notify(
                    alert_type="webhook_latency",
                    severity="critical",
                    value=5000.0,
                    threshold=3000.0,
                    reason="critical",
                ))   # must not raise


# ─── AlertCleanupJob ──────────────────────────────────────────────────────────

class TestAlertCleanupJob:
    """Unit tests for AlertCleanupJob."""

    def _make_mock_row(self, alert_id, days_ago):
        row = MagicMock()
        row.id = alert_id
        row.alert_type = "webhook_latency"
        row.severity = MagicMock()
        row.severity.value = "critical"
        row.value = 5000.0
        row.threshold = 3000.0
        row.reason = "test"
        row.get_metadata.return_value = {}
        row.created_at = datetime.now(UTC) - timedelta(days=days_ago)
        row.acknowledged_at = None
        row.acknowledged_by = None
        return row

    def test_deletes_old_rows(self):
        """Rows older than retention_days should be deleted."""
        from app.jobs.alert_cleanup_job import AlertCleanupJob

        old_row = self._make_mock_row(1, days_ago=35)

        db = MagicMock()
        # First query returns one row; second returns empty (loop ends)
        db.query.return_value.filter.return_value.limit.return_value.all.side_effect = [
            [old_row],
            [],
        ]
        db.query.return_value.filter.return_value.delete.return_value = 1

        session_factory = MagicMock(return_value=db)

        job = AlertCleanupJob(session_factory, retention_days=30)
        result = job.execute()

        assert result["deleted"] == 1
        db.commit.assert_called()

    def test_empty_table_returns_zero_deleted(self):
        """No rows to delete → deleted count is 0."""
        from app.jobs.alert_cleanup_job import AlertCleanupJob

        db = MagicMock()
        db.query.return_value.filter.return_value.limit.return_value.all.return_value = []

        session_factory = MagicMock(return_value=db)
        job = AlertCleanupJob(session_factory, retention_days=30)
        result = job.execute()

        assert result["deleted"] == 0

    def test_retention_days_in_result(self):
        """Result summary must include the retention_days parameter."""
        from app.jobs.alert_cleanup_job import AlertCleanupJob

        db = MagicMock()
        db.query.return_value.filter.return_value.limit.return_value.all.return_value = []

        session_factory = MagicMock(return_value=db)
        job = AlertCleanupJob(session_factory, retention_days=14)
        result = job.execute()

        assert result["retention_days"] == 14

    def test_db_error_does_not_raise(self):
        """A DB error during cleanup must not propagate."""
        from app.jobs.alert_cleanup_job import AlertCleanupJob

        db = MagicMock()
        db.query.side_effect = Exception("DB down")

        session_factory = MagicMock(return_value=db)
        job = AlertCleanupJob(session_factory, retention_days=30)
        result = job.execute()   # must not raise

        assert "deleted" in result


# ─── metrics_router bug fix ───────────────────────────────────────────────────

class TestDashboardHealthAdapterBugFix:
    """
    Verify that line 250 of metrics_router.py no longer references
    the undefined ``stuck_deals`` variable and instead uses
    ``state_transition_failures``.
    """

    def test_dashboard_health_adapter_source_uses_state_transition_failures(self):
        """The source of metrics_router.py must not contain 'stuck_deals' as a variable."""
        import inspect
        import app.routers.metrics_router as mod
        source = inspect.getsource(mod)
        # The word 'stuck_deals' must not appear as an undefined variable reference
        # (it can only appear as the dict key string "stuck_deals")
        lines = source.splitlines()
        for line in lines:
            stripped = line.strip()
            # The only valid usage is as a string key: "stuck_deals":
            if "stuck_deals" in stripped and ":" in stripped:
                # Ensure the RHS of the assignment uses state_transition_failures
                assert "state_transition_failures" in stripped, (
                    f"Expected state_transition_failures on same line as stuck_deals key, got: {stripped}"
                )

    def test_no_bare_stuck_deals_variable(self):
        """There must be no bare ``stuck_deals`` variable reference."""
        import ast
        import app.routers.metrics_router as mod
        import inspect

        source = inspect.getsource(mod)
        tree = ast.parse(source)

        # Collect all Name nodes that are NOT in a string context
        names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
        assert "stuck_deals" not in names, (
            "Undefined variable 'stuck_deals' found in metrics_router module"
        )
