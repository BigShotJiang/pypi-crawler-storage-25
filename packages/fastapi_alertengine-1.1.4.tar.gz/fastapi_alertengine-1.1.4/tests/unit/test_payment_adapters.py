# tests/unit/test_payment_adapters.py
"""
Tests for EcoCash, InnBucks, and Omari wallet adapter stubs.

Verifies:
  - All adapters inherit from WalletAdapter
  - Unconfigured adapters return structured not_configured responses
  - Configured instances accept credentials
  - Required response keys are always present
  - No exceptions raised on any input
"""

import os
from unittest.mock import patch

import pytest

from app.adapters.wallet_adapter import WalletAdapter
from app.adapters.ecocash_wallet_adapter import EcoCashWalletAdapter
from app.adapters.innbucks_wallet_adapter import InnBucksWalletAdapter
from app.adapters.omari_wallet_adapter import OmariWalletAdapter


# ─── Adapter inheritance ──────────────────────────────────────────────────────

class TestAdapterInheritance:
    def test_ecocash_is_wallet_adapter(self):
        assert issubclass(EcoCashWalletAdapter, WalletAdapter)

    def test_innbucks_is_wallet_adapter(self):
        assert issubclass(InnBucksWalletAdapter, WalletAdapter)

    def test_omari_is_wallet_adapter(self):
        assert issubclass(OmariWalletAdapter, WalletAdapter)


# ─── Shared contract helpers ─────────────────────────────────────────────────

_REVERSAL_REQUIRED_KEYS   = {"success", "reversal_id", "status", "timestamp"}
_QUERY_STATUS_REQUIRED_KEYS = {"success", "confirmed", "status_raw", "timestamp"}


def _assert_reversal_shape(result: dict):
    missing = _REVERSAL_REQUIRED_KEYS - result.keys()
    assert not missing, f"Missing keys in reversal response: {missing}"


def _assert_query_shape(result: dict):
    missing = _QUERY_STATUS_REQUIRED_KEYS - result.keys()
    assert not missing, f"Missing keys in query response: {missing}"


# ─── EcoCashWalletAdapter ────────────────────────────────────────────────────

class TestEcoCashNotConfigured:
    def setup_method(self):
        # Ensure env vars not set
        for var in ("ECOCASH_CLIENT_ID", "ECOCASH_CLIENT_SECRET"):
            os.environ.pop(var, None)
        self.adapter = EcoCashWalletAdapter()

    def test_not_configured(self):
        assert not self.adapter._configured

    def test_reverse_transaction_returns_not_configured(self):
        result = self.adapter.reverse_transaction({
            "external_transaction_id": "TX123",
            "amount": "10.00",
        })
        assert result["success"] is False
        assert result["status"] == "not_configured"

    def test_reverse_transaction_response_shape(self):
        result = self.adapter.reverse_transaction({"external_transaction_id": "TX1"})
        _assert_reversal_shape(result)

    def test_query_status_returns_not_configured(self):
        result = self.adapter.query_transaction_status("TX123")
        assert result["success"] is False
        assert result["status_raw"] == "not_configured"
        assert result["confirmed"] is False

    def test_query_status_response_shape(self):
        result = self.adapter.query_transaction_status("TX1")
        _assert_query_shape(result)

    def test_reverse_never_raises(self):
        # Should not raise even with empty/malformed input
        self.adapter.reverse_transaction({})
        self.adapter.reverse_transaction({"external_transaction_id": None})

    def test_query_never_raises(self):
        self.adapter.query_transaction_status("")
        self.adapter.query_transaction_status(None)


class TestEcoCashCredentialsAccepted:
    def test_configured_when_credentials_provided(self):
        adapter = EcoCashWalletAdapter(client_id="ID123", client_secret="SEC456")
        assert adapter._configured is True

    def test_credentials_stored(self):
        adapter = EcoCashWalletAdapter(client_id="myid", client_secret="mysec")
        assert adapter.client_id == "myid"
        assert adapter.client_secret == "mysec"

    def test_env_var_credentials_accepted(self):
        with patch.dict(os.environ, {
            "ECOCASH_CLIENT_ID": "env_id",
            "ECOCASH_CLIENT_SECRET": "env_sec",
        }):
            adapter = EcoCashWalletAdapter()
            assert adapter._configured is True


# ─── InnBucksWalletAdapter ───────────────────────────────────────────────────

class TestInnBucksNotConfigured:
    def setup_method(self):
        for var in ("INNBUCKS_API_KEY", "INNBUCKS_MERCHANT_CODE"):
            os.environ.pop(var, None)
        self.adapter = InnBucksWalletAdapter()

    def test_not_configured(self):
        assert not self.adapter._configured

    def test_reverse_returns_not_configured(self):
        result = self.adapter.reverse_transaction({"external_transaction_id": "IB123"})
        assert result["success"] is False
        assert result["status"] == "not_configured"

    def test_reverse_response_shape(self):
        result = self.adapter.reverse_transaction({})
        _assert_reversal_shape(result)

    def test_query_returns_not_configured(self):
        result = self.adapter.query_transaction_status("IB123")
        assert result["success"] is False
        assert result["status_raw"] == "not_configured"

    def test_query_response_shape(self):
        result = self.adapter.query_transaction_status("IB1")
        _assert_query_shape(result)

    def test_never_raises(self):
        self.adapter.reverse_transaction({})
        self.adapter.query_transaction_status("")


class TestInnBucksCredentialsAccepted:
    def test_configured_with_api_key_and_merchant_code(self):
        adapter = InnBucksWalletAdapter(api_key="KEY", merchant_code="MERCH")
        assert adapter._configured is True

    def test_env_var_credentials(self):
        with patch.dict(os.environ, {
            "INNBUCKS_API_KEY": "ib_key",
            "INNBUCKS_MERCHANT_CODE": "ib_merch",
        }):
            adapter = InnBucksWalletAdapter()
            assert adapter._configured is True


# ─── OmariWalletAdapter ───────────────────────────────────────────────────────

class TestOmariNotConfigured:
    def setup_method(self):
        for var in ("OMARI_API_KEY", "OMARI_MERCHANT_ID"):
            os.environ.pop(var, None)
        self.adapter = OmariWalletAdapter()

    def test_not_configured(self):
        assert not self.adapter._configured

    def test_reverse_returns_not_configured(self):
        result = self.adapter.reverse_transaction({"external_transaction_id": "OM123"})
        assert result["success"] is False
        assert result["status"] == "not_configured"

    def test_reverse_response_shape(self):
        result = self.adapter.reverse_transaction({})
        _assert_reversal_shape(result)

    def test_query_returns_not_configured(self):
        result = self.adapter.query_transaction_status("OM123")
        assert result["success"] is False
        assert result["status_raw"] == "not_configured"

    def test_query_response_shape(self):
        result = self.adapter.query_transaction_status("OM1")
        _assert_query_shape(result)

    def test_never_raises(self):
        self.adapter.reverse_transaction({})
        self.adapter.query_transaction_status("")


class TestOmariCredentialsAccepted:
    def test_configured_with_api_key_and_merchant_id(self):
        adapter = OmariWalletAdapter(api_key="KEY", merchant_id="MID")
        assert adapter._configured is True

    def test_env_var_credentials(self):
        with patch.dict(os.environ, {
            "OMARI_API_KEY": "om_key",
            "OMARI_MERCHANT_ID": "om_mid",
        }):
            adapter = OmariWalletAdapter()
            assert adapter._configured is True
