# tests/unit/test_load_shedding.py
"""Tests for app.core.load_shedding."""

from unittest.mock import MagicMock, patch, call

import pytest

from app.core.load_shedding import (
    DEGRADED_MODE_KEY,
    is_degraded,
    should_skip_claude,
    set_degraded_mode,
    degraded_status,
)


# ─── is_degraded ──────────────────────────────────────────────────────────────

class TestIsDegraded:
    def _rdb_with_flag(self, flag_value=b"manual"):
        rdb = MagicMock()
        def get_side_effect(key):
            if key == DEGRADED_MODE_KEY:
                return flag_value
            return None
        rdb.get.side_effect = get_side_effect
        return rdb

    def _rdb_no_flag(self):
        rdb = MagicMock()
        rdb.get.return_value = None
        return rdb

    def test_returns_true_when_flag_set(self):
        rdb = self._rdb_with_flag(b"manual")
        assert is_degraded(rdb) is True

    def test_returns_false_when_flag_absent_and_no_issues(self):
        rdb = self._rdb_no_flag()
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=10.0):
            with patch("app.core.load_shedding._payment_queue_length", return_value=0):
                assert is_degraded(rdb) is False

    def test_returns_true_on_redis_read_error(self):
        rdb = MagicMock()
        rdb.get.side_effect = Exception("conn refused")
        assert is_degraded(rdb) is True

    def test_auto_detect_high_latency_triggers_degraded(self):
        rdb = self._rdb_no_flag()
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=200.0):
            with patch("app.core.load_shedding._payment_queue_length", return_value=0):
                with patch("app.core.load_shedding.set_degraded_mode") as mock_set:
                    result = is_degraded(rdb, auto_detect=True)
        assert result is True
        mock_set.assert_called_once()

    def test_auto_detect_high_queue_triggers_degraded(self):
        rdb = self._rdb_no_flag()
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=10.0):
            with patch("app.core.load_shedding._payment_queue_length", return_value=5000):
                with patch("app.core.load_shedding.set_degraded_mode") as mock_set:
                    result = is_degraded(rdb, auto_detect=True)
        assert result is True
        mock_set.assert_called_once()

    def test_auto_detect_false_skips_latency_check(self):
        rdb = self._rdb_no_flag()
        with patch("app.core.load_shedding._measure_redis_latency_ms") as mock_latency:
            result = is_degraded(rdb, auto_detect=False)
        mock_latency.assert_not_called()
        assert result is False


# ─── should_skip_claude ───────────────────────────────────────────────────────

class TestShouldSkipClaude:
    def test_returns_false_when_flag_absent(self):
        rdb = MagicMock()
        rdb.get.return_value = None
        assert should_skip_claude(rdb) is False

    def test_returns_true_when_flag_set(self):
        rdb = MagicMock()
        rdb.get.return_value = b"high_latency"
        assert should_skip_claude(rdb) is True

    def test_returns_true_on_redis_error(self):
        rdb = MagicMock()
        rdb.get.side_effect = Exception("Redis down")
        assert should_skip_claude(rdb) is True

    def test_reads_degraded_mode_key(self):
        rdb = MagicMock()
        rdb.get.return_value = None
        should_skip_claude(rdb)
        rdb.get.assert_called_with(DEGRADED_MODE_KEY)


# ─── set_degraded_mode ────────────────────────────────────────────────────────

class TestSetDegradedMode:
    def test_enable_calls_setex(self):
        rdb = MagicMock()
        set_degraded_mode(rdb, True, reason="test_reason")
        rdb.setex.assert_called_once_with(DEGRADED_MODE_KEY, 60, "test_reason")

    def test_enable_with_empty_reason_uses_manual(self):
        rdb = MagicMock()
        set_degraded_mode(rdb, True)
        rdb.setex.assert_called_once_with(DEGRADED_MODE_KEY, 60, "manual")

    def test_disable_calls_delete(self):
        rdb = MagicMock()
        set_degraded_mode(rdb, False)
        rdb.delete.assert_called_once_with(DEGRADED_MODE_KEY)

    def test_never_raises_on_redis_error(self):
        rdb = MagicMock()
        rdb.setex.side_effect = Exception("Redis down")
        set_degraded_mode(rdb, True, reason="test")   # must not raise

    def test_disable_never_raises_on_redis_error(self):
        rdb = MagicMock()
        rdb.delete.side_effect = Exception("Redis down")
        set_degraded_mode(rdb, False)   # must not raise


# ─── degraded_status ─────────────────────────────────────────────────────────

class TestDegradedStatus:
    def test_returns_dict_with_required_keys(self):
        rdb = MagicMock()
        rdb.get.return_value = None
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=5.0):
            result = degraded_status(rdb)
        assert "degraded" in result
        assert "reason" in result
        assert "redis_latency_ms" in result

    def test_degraded_false_when_no_flag(self):
        rdb = MagicMock()
        rdb.get.return_value = None
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=5.0):
            result = degraded_status(rdb)
        assert result["degraded"] is False
        assert result["reason"] is None

    def test_degraded_true_when_flag_set(self):
        rdb = MagicMock()
        rdb.get.return_value = b"high_latency:200ms"
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=200.0):
            result = degraded_status(rdb)
        assert result["degraded"] is True
        assert result["reason"] == "high_latency:200ms"

    def test_redis_latency_is_float(self):
        rdb = MagicMock()
        rdb.get.return_value = None
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=42.5):
            result = degraded_status(rdb)
        assert isinstance(result["redis_latency_ms"], float)

    def test_handles_redis_get_error_gracefully(self):
        rdb = MagicMock()
        rdb.get.side_effect = Exception("Redis down")
        with patch("app.core.load_shedding._measure_redis_latency_ms", return_value=float("inf")):
            result = degraded_status(rdb)
        # Should not raise; reason should indicate issue
        assert "degraded" in result
