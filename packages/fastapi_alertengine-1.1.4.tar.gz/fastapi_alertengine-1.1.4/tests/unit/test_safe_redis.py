# tests/unit/test_safe_redis.py
"""Tests for SafeRedis, _EphemeralStore, and _CircuitBreaker."""

import time
import threading
import unittest
from unittest.mock import MagicMock, patch, call

import pytest

from app.core.safe_redis import (
    _EphemeralStore,
    _EphemeralPipeline,
    _CircuitBreaker,
    SafeRedis,
    build_safe_redis,
    _FAILURE_THRESHOLD,
    _RESET_AFTER,
)


# ─── _EphemeralStore ──────────────────────────────────────────────────────────

class TestEphemeralStoreBasic:
    def setup_method(self):
        self.store = _EphemeralStore()

    def test_get_missing_key_returns_none(self):
        assert self.store.get("missing") is None

    def test_set_and_get(self):
        self.store.set("k", "hello")
        assert self.store.get("k") == b"hello"

    def test_setex_and_get(self):
        self.store.setex("k", 300, "world")
        assert self.store.get("k") == b"world"

    def test_setnx_sets_when_absent(self):
        result = self.store.setnx("k", "first")
        assert result is True
        assert self.store.get("k") == b"first"

    def test_setnx_does_not_overwrite(self):
        self.store.set("k", "original")
        result = self.store.setnx("k", "new")
        assert result is False
        assert self.store.get("k") == b"original"

    def test_getset_returns_old_value(self):
        self.store.set("k", "old")
        old = self.store.getset("k", "new")
        assert old == b"old"
        assert self.store.get("k") == b"new"

    def test_delete_removes_key(self):
        self.store.set("k", "v")
        self.store.delete("k")
        assert self.store.get("k") is None

    def test_delete_returns_count(self):
        self.store.set("a", "1")
        self.store.set("b", "2")
        count = self.store.delete("a", "b", "missing")
        assert count == 2

    def test_exists_present(self):
        self.store.set("k", "v")
        assert self.store.exists("k") == 1

    def test_exists_absent(self):
        assert self.store.exists("missing") == 0

    def test_expire_sets_ttl(self):
        self.store.set("k", "v")
        self.store.expire("k", 1)
        # Key should still be accessible immediately
        assert self.store.get("k") == b"v"

    def test_incr_starts_at_one_for_new_key(self):
        assert self.store.incr("counter") == 1

    def test_incr_increments_existing(self):
        self.store.incr("counter")
        assert self.store.incr("counter") == 2


class TestEphemeralStoreTTLExpiry:
    def setup_method(self):
        self.store = _EphemeralStore()

    def test_expired_key_returns_none(self):
        with patch("time.time", return_value=1000.0):
            self.store.setex("k", 10, "v")
        with patch("time.time", return_value=1011.0):  # past expiry
            assert self.store.get("k") is None

    def test_non_expired_key_accessible(self):
        with patch("time.time", return_value=1000.0):
            self.store.setex("k", 60, "v")
        with patch("time.time", return_value=1050.0):  # before expiry
            assert self.store.get("k") == b"v"

    def test_expired_key_not_counted_by_exists(self):
        with patch("time.time", return_value=1000.0):
            self.store.setex("k", 5, "v")
        with patch("time.time", return_value=1010.0):
            assert self.store.exists("k") == 0


class TestEphemeralStoreList:
    def setup_method(self):
        self.store = _EphemeralStore()

    def test_lpush_and_lrange(self):
        self.store.lpush("lst", "c", "b", "a")
        result = self.store.lrange("lst", 0, -1)
        # lpush prepends: a, b, c pushed in reverse → a is at front
        assert len(result) == 3

    def test_lrange_slice(self):
        self.store.lpush("lst", "c")
        self.store.lpush("lst", "b")
        self.store.lpush("lst", "a")
        result = self.store.lrange("lst", 0, 1)
        assert len(result) == 2

    def test_ltrim(self):
        for i in range(5):
            self.store.lpush("lst", str(i))
        self.store.ltrim("lst", 0, 2)
        assert len(self.store.lrange("lst", 0, -1)) == 3


class TestEphemeralStoreHash:
    def setup_method(self):
        self.store = _EphemeralStore()

    def test_hset_and_hget(self):
        self.store.hset("h", "field", "value")
        assert self.store.hget("h", "field") == b"value"

    def test_hget_missing_field_returns_none(self):
        assert self.store.hget("h", "missing") is None

    def test_hset_mapping(self):
        self.store.hset("h", mapping={"a": "1", "b": "2"})
        assert self.store.hget("h", "a") == b"1"
        assert self.store.hget("h", "b") == b"2"

    def test_hgetall(self):
        self.store.hset("h", mapping={"x": "10", "y": "20"})
        result = self.store.hgetall("h")
        assert len(result) == 2


class TestEphemeralStoreSortedSet:
    def setup_method(self):
        self.store = _EphemeralStore()

    def test_zadd_and_zrangebyscore(self):
        self.store.zadd("z", {"a": 1.0, "b": 2.0, "c": 3.0})
        result = self.store.zrangebyscore("z", 1.0, 2.0)
        assert len(result) == 2

    def test_zrem(self):
        self.store.zadd("z", {"a": 1.0, "b": 2.0})
        removed = self.store.zrem("z", "a")
        assert removed == 1
        result = self.store.zrangebyscore("z", "-inf", "+inf")
        assert len(result) == 1


class TestEphemeralStoreStream:
    def setup_method(self):
        self.store = _EphemeralStore()

    def test_xadd_returns_stream_id(self):
        sid = self.store.xadd("stream", {"type": "test", "ts": "123"})
        assert sid is not None

    def test_xlen_after_xadd(self):
        self.store.xadd("stream", {"k": "v"})
        self.store.xadd("stream", {"k": "v2"})
        assert self.store.xlen("stream") == 2

    def test_xlen_empty_stream(self):
        assert self.store.xlen("nonexistent") == 0


class TestEphemeralStoreScanIter:
    def setup_method(self):
        self.store = _EphemeralStore()

    def test_scan_iter_matches_pattern(self):
        self.store.set("bot:state:123", "idle")
        self.store.set("bot:state:456", "browsing")
        self.store.set("other:key", "value")
        matches = list(self.store.scan_iter(match="bot:state:*"))
        assert len(matches) == 2

    def test_scan_iter_no_match(self):
        self.store.set("other:key", "value")
        matches = list(self.store.scan_iter(match="bot:state:*"))
        assert len(matches) == 0


class TestEphemeralPipeline:
    def test_pipeline_execute(self):
        store = _EphemeralStore()
        pipe = store.pipeline()
        pipe.setex("k1", 60, "v1")
        pipe.setex("k2", 60, "v2")
        results = pipe.execute()
        assert store.get("k1") == b"v1"
        assert store.get("k2") == b"v2"

    def test_pipeline_context_manager(self):
        store = _EphemeralStore()
        with store.pipeline() as pipe:
            pipe.setex("k", 60, "v")
            pipe.execute()
        assert store.get("k") == b"v"


# ─── _CircuitBreaker ──────────────────────────────────────────────────────────

class TestCircuitBreaker:
    def setup_method(self):
        self.cb = _CircuitBreaker(threshold=3, window=30.0, reset_after=30.0)

    def test_starts_closed(self):
        assert not self.cb.is_open

    def test_opens_after_threshold_failures(self):
        with patch("time.time", return_value=1000.0):
            for _ in range(3):
                self.cb.record_failure()
            assert self.cb.is_open

    def test_stays_closed_below_threshold(self):
        with patch("time.time", return_value=1000.0):
            self.cb.record_failure()
            self.cb.record_failure()
        assert not self.cb.is_open

    def test_auto_resets_after_reset_after(self):
        with patch("time.time", return_value=1000.0):
            for _ in range(3):
                self.cb.record_failure()
        with patch("time.time", return_value=1031.0):  # past reset window
            assert not self.cb.is_open

    def test_record_success_clears_failures(self):
        with patch("time.time", return_value=1000.0):
            self.cb.record_failure()
            self.cb.record_failure()
            self.cb.record_success()
        assert not self.cb.is_open
        assert len(self.cb._failures) == 0

    def test_failures_outside_window_not_counted(self):
        # Old failure (outside 30s window)
        with patch("time.time", return_value=900.0):
            self.cb.record_failure()
            self.cb.record_failure()
        # New failures (within window)
        with patch("time.time", return_value=1000.0):
            self.cb.record_failure()
        # Only 1 failure in the current window — should not open
        assert not self.cb.is_open


# ─── SafeRedis ────────────────────────────────────────────────────────────────

class TestSafeRedis:
    """Test SafeRedis retry and circuit breaker via mocked parent calls."""

    def _make_safe_redis(self):
        """Build a SafeRedis with a mocked connection pool."""
        import redis
        pool = MagicMock()
        instance = SafeRedis(connection_pool=pool)
        return instance

    def test_successful_call_returns_value(self):
        rdb = self._make_safe_redis()
        # Mock the parent get to succeed
        with patch.object(type(rdb).__bases__[0], "get", return_value=b"hello"):
            result = rdb.get("k")
        assert result == b"hello"

    def test_retries_on_connection_error(self):
        import redis as redis_lib
        rdb = self._make_safe_redis()
        call_count = [0]

        def flaky_get(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] < 3:
                raise redis_lib.exceptions.ConnectionError("conn refused")
            return b"recovered"

        with patch.object(type(rdb).__bases__[0], "get", side_effect=flaky_get):
            with patch("time.sleep"):
                result = rdb.get("k")
        assert result == b"recovered"
        assert call_count[0] == 3

    def test_falls_back_to_ephemeral_after_all_retries_fail(self):
        import redis as redis_lib
        rdb = self._make_safe_redis()

        def always_fail(*args, **kwargs):
            raise redis_lib.exceptions.ConnectionError("down")

        rdb._ephemeral.set("k", "ephemeral_value")
        with patch.object(type(rdb).__bases__[0], "get", side_effect=always_fail):
            with patch("time.sleep"):
                result = rdb.get("k")
        assert result == b"ephemeral_value"

    def test_circuit_opens_and_skips_real_redis(self):
        import redis as redis_lib
        rdb = self._make_safe_redis()

        with patch("time.time", return_value=1000.0):
            for _ in range(5):
                rdb._circuit.record_failure()

        # Circuit is open — get should go straight to ephemeral
        rdb._ephemeral.set("k", "fallback")
        parent_get = MagicMock(return_value=b"from_redis")
        with patch.object(type(rdb).__bases__[0], "get", parent_get):
            result = rdb.get("k")

        parent_get.assert_not_called()
        assert result == b"fallback"

    def test_circuit_status_returns_dict(self):
        rdb = self._make_safe_redis()
        status = rdb.circuit_status()
        assert "open" in status
        assert "failures" in status
        assert "threshold" in status

    def test_circuit_open_property_false_initially(self):
        rdb = self._make_safe_redis()
        assert rdb.circuit_open is False


class TestBuildSafeRedis:
    def test_returns_safe_redis_instance(self):
        with patch("redis.ConnectionPool.from_url") as mock_pool:
            mock_pool.return_value = MagicMock()
            rdb = build_safe_redis("redis://localhost:6379")
        assert isinstance(rdb, SafeRedis)
