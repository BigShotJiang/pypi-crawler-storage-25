# tests/test_engine_basic.py
"""
Basic tests for AlertEngine and RequestMetricsMiddleware.

Uses fakeredis — no running Redis instance required.
"""

import pytest
import fakeredis
from fastapi import FastAPI, Response
from fastapi.testclient import TestClient

from fastapi_alertengine import (
    AlertConfig,
    AlertEngine,
    RequestMetricsMiddleware,
    get_alert_engine,
)
from fastapi_alertengine.storage import write_metric, read_metrics, p95


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture()
def rdb():
    return fakeredis.FakeRedis(decode_responses=True)


@pytest.fixture()
def config():
    return AlertConfig()


@pytest.fixture()
def engine(rdb, config):
    return AlertEngine(redis=rdb, config=config)


@pytest.fixture()
def app(engine):
    _app = FastAPI()
    _app.add_middleware(RequestMetricsMiddleware, alert_engine=engine)

    @_app.get("/fast")
    def fast(): return {"ok": True}

    @_app.get("/webhook/event")
    def webhook(): return {"ok": True}

    @_app.get("/error")
    def error(): return Response(status_code=500)

    return _app


@pytest.fixture()
def client(app):
    return TestClient(app)


# ── evaluate() shape ──────────────────────────────────────────────────────────

def test_evaluate_no_data_returns_ok(engine):
    result = engine.evaluate()
    assert result["status"] == "ok"
    assert result["reason"] == "no_data"
    assert result["metrics"]["sample_size"] == 0


def test_evaluate_returns_required_keys(engine, client):
    client.get("/fast")
    result = engine.evaluate()
    assert set(result.keys()) >= {"status", "metrics", "thresholds", "timestamp"}
    assert set(result["metrics"].keys()) == {
        "overall_p95_ms", "webhook_p95_ms", "api_p95_ms",
        "error_rate", "anomaly_score", "sample_size",
    }


def test_evaluate_window_size_param(engine, client):
    for _ in range(10):
        client.get("/fast")
    result = engine.evaluate(window_size=5)
    assert result["metrics"]["sample_size"] == 5


def test_evaluate_status_is_valid_string(engine, client):
    client.get("/fast")
    result = engine.evaluate()
    assert result["status"] in ("ok", "warning", "critical")


# ── Metrics accuracy ──────────────────────────────────────────────────────────

def test_error_rate_reflects_500s(engine, client):
    for _ in range(8): client.get("/fast")
    for _ in range(2): client.get("/error")
    result = engine.evaluate()
    # 2 errors / 10 total = 0.2 exactly
    assert abs(result["metrics"]["error_rate"] - 0.2) < 0.01


def test_webhook_traffic_classified_separately(engine, client):
    for _ in range(5): client.get("/fast")
    for _ in range(5): client.get("/webhook/event")
    result = engine.evaluate()
    assert result["metrics"]["webhook_p95_ms"] > 0
    assert result["metrics"]["api_p95_ms"] > 0


def test_sample_size_matches_requests(engine, client):
    for _ in range(7): client.get("/fast")
    result = engine.evaluate()
    assert result["metrics"]["sample_size"] == 7


# ── Fail-safe behaviour ───────────────────────────────────────────────────────

def test_evaluate_broken_redis_returns_ok():
    import redis as real_redis
    broken = real_redis.Redis(host="localhost", port=19999, socket_timeout=0.1)
    engine = AlertEngine(redis=broken, config=AlertConfig())
    result = engine.evaluate()
    assert result["status"] == "ok"
    assert result["reason"] == "no_data"


def test_middleware_broken_redis_never_crashes_requests():
    import redis as real_redis
    broken = real_redis.Redis(host="localhost", port=19999, socket_timeout=0.1)
    engine = AlertEngine(redis=broken, config=AlertConfig())

    _app = FastAPI()
    _app.add_middleware(RequestMetricsMiddleware, alert_engine=engine)

    @_app.get("/ping")
    def ping(): return {"alive": True}

    c = TestClient(_app)
    r = c.get("/ping")
    assert r.status_code == 200


# ── storage layer ─────────────────────────────────────────────────────────────

def test_write_then_read_metric(rdb, config):
    write_metric(rdb, config, {"latency_ms": 42.5, "type": "api", "status_code": 200, "timestamp": 1000})
    events = read_metrics(rdb, config, count=10)
    assert len(events) == 1
    assert events[0]["latency_ms"] == 42.5
    assert events[0]["status_code"] == 200
    assert events[0]["type"] == "api"


def test_write_metric_broken_redis_does_not_raise(config):
    import redis as real_redis
    broken = real_redis.Redis(host="localhost", port=19999, socket_timeout=0.1)
    write_metric(broken, config, {"latency_ms": 1.0, "type": "api", "status_code": 200, "timestamp": 1})
    # should not raise


def test_p95_empty():
    assert p95([]) == 0.0


def test_p95_single():
    assert p95([42.0]) == 42.0


def test_p95_values():
    values = list(range(1, 21))   # [1..20]
    assert p95(values) == 20      # 95th percentile of 20 items


# ── get_alert_engine singleton ────────────────────────────────────────────────

def test_get_alert_engine_returns_engine(rdb):
    engine = get_alert_engine(redis_client=rdb)
    assert isinstance(engine, AlertEngine)
    assert engine.redis is rdb
    assert engine.config is not None


def test_get_alert_engine_singleton(rdb):
    e1 = get_alert_engine(redis_client=rdb)
    e2 = get_alert_engine(redis_client=rdb)
    assert e1 is e2
