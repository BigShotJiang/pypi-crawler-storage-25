# database.py  (root-level shim)
"""
SQLAlchemy session factory — root-level shim for legacy imports.

Exposes ``get_db`` (FastAPI dependency) and ``SessionLocal`` so that
modules using ``from database import get_db`` continue to work while
the ORM models live under ``app/models/database.py``.
"""

import os
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.models.database import Base  # noqa: F401 — re-exported for convenience

_DATABASE_URL: str = os.environ.get("DATABASE_URL", "sqlite:///./tofamba.db")

# SQLite needs check_same_thread=False; other dialects ignore it
_connect_args = {"check_same_thread": False} if _DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(
    _DATABASE_URL,
    connect_args=_connect_args,
    pool_pre_ping=True,   # detect stale connections
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a database session and closes it on exit."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
