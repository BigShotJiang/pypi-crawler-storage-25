# examples/main.py
"""
fastapi_alertengine — minimal demo app.

Three endpoints:
  GET /fast   — responds in ~5ms   (normal traffic)
  GET /slow   — responds in ~600ms (triggers warning)
  GET /error  — returns HTTP 500   (drives up error rate)

Run:
    pip install "fastapi[standard]" redis fastapi-alertengine
    redis-server &
    uvicorn examples.main:app --reload

Then hit the endpoints a few times and check:
    curl http://localhost:8000/alerts
"""

import asyncio
import os

import redis
from fastapi import FastAPI, HTTPException

from fastapi_alertengine import (
    AlertConfig,
    RequestMetricsMiddleware,
    aggregate,
    get_alert_engine,
)

# ── Redis + engine ────────────────────────────────────────────────────────────

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
rdb       = redis.Redis.from_url(REDIS_URL, decode_responses=True)
engine    = get_alert_engine(redis_client=rdb)

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(title="fastapi_alertengine demo", version="1.1.4")

# Register metrics middleware — must come before any other middleware
app.add_middleware(RequestMetricsMiddleware, alert_engine=engine)

# ── Demo endpoints ────────────────────────────────────────────────────────────

@app.get("/fast", tags=["demo"])
async def fast_endpoint():
    """Normal response — ~5ms latency."""
    await asyncio.sleep(0.005)
    return {"endpoint": "fast", "latency": "~5ms"}


@app.get("/slow", tags=["demo"])
async def slow_endpoint():
    """Slow response — ~600ms latency, will push p95 into warning range."""
    await asyncio.sleep(0.6)
    return {"endpoint": "slow", "latency": "~600ms"}


@app.get("/error", tags=["demo"])
async def error_endpoint():
    """Always returns 500 — drives up the error rate metric."""
    raise HTTPException(status_code=500, detail="Intentional error for demo")


# ── Alert status endpoint ─────────────────────────────────────────────────────

@app.get("/alerts", tags=["observability"])
def alert_status():
    """
    Evaluate current alert status from recent request metrics.

    Returns the AlertEngine result plus a p95 breakdown by traffic type.
    """
    return {
        **engine.evaluate(window_size=200),
        "aggregated": aggregate(rdb, engine.config),
    }
