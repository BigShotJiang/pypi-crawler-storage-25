// anchorflow_script.js — AnchorFlow 90-Second Explainer Script PPTX
"use strict";
const pptxgen = require("pptxgenjs");

const pres = new pptxgen();
pres.layout  = "LAYOUT_16x9"; // 10" × 5.625"
pres.author  = "Tandem Hive Creative";
pres.title   = "AnchorFlow — 90-Second Cartoon Explainer Script";
pres.subject = "Indiegogo Campaign Script";

// ── Brand Palette ─────────────────────────────────────────────
const NAVY     = "1A2B3C";   // Deep Navy — primary dark bg
const TEAL     = "20C997";   // Vibrant Teal — brand accent
const DARKTEAL = "17A87F";   // Darker teal — hover / confirm
const WHITE    = "FFFFFF";
const LTBG     = "EDF4F8";   // Ice-blue — light slide bg
const MUTED    = "7A9BB5";   // Muted blue-gray — supporting text
const TEXTDK   = "152233";   // Very dark navy — body text on light bg
const ORANGE   = "FF6B35";   // Alert orange — Scene 1 frustration
const HDARK    = "0F1E2B";   // Header bar darken
const BDRLINE  = "2E4A60";   // Border / divider

// ── Helper: always fresh shadow object (PptxGenJS mutates in-place) ──
const mkShadow = () => ({ type: "outer", blur: 10, offset: 3, angle: 135, color: "000000", opacity: 0.20 });


// ═══════════════════════════════════════════════════════════════
// SLIDE 1 — COVER
// ═══════════════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: NAVY };

  // Left teal accent stripe
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 0, w: 0.22, h: 5.625,
    fill: { color: TEAL }, line: { color: TEAL }
  });

  // Bottom footer bar
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 5.27, w: 10, h: 0.355,
    fill: { color: HDARK }, line: { color: HDARK }
  });
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 5.27, w: 10, h: 0.04,
    fill: { color: TEAL }, line: { color: TEAL }
  });

  // Top eyebrow
  s.addText("INDIEGOGO CAMPAIGN  ·  2026  ·  TRUST AS AN API", {
    x: 0.55, y: 0.28, w: 9.1, h: 0.28,
    fontSize: 8.5, fontFace: "Calibri", color: MUTED,
    charSpacing: 3, align: "left", margin: 0
  });

  // Big title
  s.addText("AnchorFlow", {
    x: 0.55, y: 0.65, w: 9.1, h: 1.25,
    fontSize: 76, fontFace: "Georgia", color: WHITE,
    bold: true, align: "left", margin: 0
  });

  // Subtitle
  s.addText("90-Second Cartoon Explainer Script", {
    x: 0.55, y: 1.85, w: 9.1, h: 0.52,
    fontSize: 22, fontFace: "Calibri", color: TEAL,
    bold: false, align: "left", margin: 0
  });

  // Thin rule
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0.55, y: 2.46, w: 4.0, h: 0.04,
    fill: { color: BDRLINE }, line: { color: BDRLINE }
  });

  // Tagline
  s.addText("Paid.  Delivered.  Done.", {
    x: 0.55, y: 2.6, w: 9.1, h: 0.58,
    fontSize: 21, fontFace: "Georgia", color: WHITE,
    italic: true, charSpacing: 1, align: "left", margin: 0
  });

  // Deliverables list
  s.addText([
    { text: "Two-Column Script (Visual + Voiceover)  ·  ", options: {} },
    { text: "Music Mood Guide", options: { color: TEAL } },
    { text: "  ·  ", options: {} },
    { text: "Color & Style Reference", options: { color: TEAL } },
  ], {
    x: 0.55, y: 3.28, w: 9.1, h: 0.35,
    fontSize: 12, fontFace: "Calibri", color: MUTED, align: "left", margin: 0
  });

  // Scene index pills (5 scenes)
  const pills = [
    { label: "Scene 1\nThe Irony",       bg: ORANGE },
    { label: "Scene 2\nAnchorFlow",      bg: DARKTEAL },
    { label: "Scene 3\nHow It Works",    bg: TEAL },
    { label: "Scene 4\nEmpowerment",     bg: DARKTEAL },
    { label: "Scene 5\nThe CTA",         bg: "1E3A52" },
  ];
  pills.forEach((pill, i) => {
    const x = 0.30 + i * 1.86;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x, y: 3.85, w: 1.68, h: 0.72,
      fill: { color: pill.bg }, line: { color: pill.bg }, rectRadius: 0.08
    });
    // Determine readable text color against each pill background
    const textColor = ["1A2B3C","1E3A52"].includes(pill.bg) ? TEAL : NAVY;
    s.addText(pill.label, {
      x, y: 3.85, w: 1.68, h: 0.72,
      fontSize: 9, fontFace: "Calibri", color: textColor,
      bold: true, align: "center", valign: "middle", margin: 0
    });
  });

  // Footer text
  s.addText("2D Vector Animation  ·  Corporate Memphis Style  ·  Vibrant Teal + Deep Navy", {
    x: 0.55, y: 5.31, w: 9.1, h: 0.25,
    fontSize: 8, fontFace: "Calibri", color: MUTED,
    charSpacing: 1, align: "left", margin: 0
  });
}


// ═══════════════════════════════════════════════════════════════
// SCENE SLIDE BUILDER
// ═══════════════════════════════════════════════════════════════
function addSceneSlide({ sceneNum, timing, sceneColor, title, mood, leftContent, rightContent }) {
  const s = pres.addSlide();
  s.background = { color: LTBG };

  // ── Header bar ──────────────────────────────
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 0, w: 10, h: 0.76,
    fill: { color: NAVY }, line: { color: NAVY }
  });
  // Colored left stripe on header
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 0, w: 0.22, h: 0.76,
    fill: { color: sceneColor }, line: { color: sceneColor }
  });

  // Scene number label
  s.addText(`SCENE ${sceneNum}`, {
    x: 0.38, y: 0.06, w: 1.5, h: 0.25,
    fontSize: 8, fontFace: "Calibri", color: sceneColor,
    bold: true, charSpacing: 3, margin: 0
  });

  // Scene title
  s.addText(title, {
    x: 0.38, y: 0.34, w: 6.5, h: 0.3,
    fontSize: 15, fontFace: "Georgia", color: WHITE,
    bold: true, margin: 0
  });

  // Timing badge
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, {
    x: 8.25, y: 0.13, w: 1.48, h: 0.44,
    fill: { color: sceneColor }, line: { color: sceneColor }, rectRadius: 0.07
  });
  s.addText(timing, {
    x: 8.25, y: 0.13, w: 1.48, h: 0.44,
    fontSize: 10, fontFace: "Calibri", color: NAVY,
    bold: true, align: "center", valign: "middle", margin: 0
  });

  // Mood tag
  if (mood) {
    s.addText(`♪  ${mood}`, {
      x: 6.5, y: 0.26, w: 1.65, h: 0.22,
      fontSize: 8, fontFace: "Calibri", color: MUTED,
      italic: true, align: "right", margin: 0
    });
  }

  // ── Column headers ──────────────────────────
  s.addText("VISUAL DESCRIPTION", {
    x: 0.28, y: 0.88, w: 4.6, h: 0.24,
    fontSize: 8, fontFace: "Calibri", color: sceneColor,
    bold: true, charSpacing: 3, margin: 0
  });
  s.addText("VOICEOVER SCRIPT", {
    x: 5.22, y: 0.88, w: 4.6, h: 0.24,
    fontSize: 8, fontFace: "Calibri", color: sceneColor,
    bold: true, charSpacing: 3, margin: 0
  });

  // Column divider
  s.addShape(pres.shapes.LINE, {
    x: 5.05, y: 0.82, w: 0, h: 4.62,
    line: { color: "B8CDD8", width: 1, dashType: "dash" }
  });

  // ── Left column: visual description ────────
  s.addText(leftContent, {
    x: 0.28, y: 1.18, w: 4.62, h: 4.2,
    fontSize: 11, fontFace: "Calibri", color: TEXTDK,
    align: "left", valign: "top", margin: 0
  });

  // ── Right column: voiceover ─────────────────
  s.addText(rightContent, {
    x: 5.22, y: 1.18, w: 4.55, h: 4.2,
    fontSize: 11, fontFace: "Calibri", color: TEXTDK,
    align: "left", valign: "top", margin: 0
  });

  // ── Bottom teal bar ─────────────────────────
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 5.46, w: 10, h: 0.165,
    fill: { color: sceneColor }, line: { color: sceneColor }
  });
}


// ═══════════════════════════════════════════════════════════════
// SLIDE 2 — SCENE 1: THE IRONY (0:00–0:20)
// ═══════════════════════════════════════════════════════════════
addSceneSlide({
  sceneNum: 1,
  timing: "0:00 – 0:20",
  sceneColor: ORANGE,
  title: "The Irony — The Trust Gap",
  mood: "Tense → Frustrated",

  leftContent: [
    { text: "Opening Frame\n", options: { bold: true, color: ORANGE } },
    { text: "Glowing smartphone fills screen. Vibrant WhatsApp-style marketplace — colorful products, fire emojis, 'BUY NOW!' buttons. Bold Corporate Memphis character taps BUY with a wide grin and a triumphant thumb.\n\n", options: {} },

    { text: "The Break\n", options: { bold: true, color: ORANGE } },
    { text: "Screen CRACKS — jarring glitch-cut. In a single frame the character teleports: now standing on a sun-bleached, dusty street corner. A petrol station sign. Another stranger approaches from the opposite direction. Both look uncertain.\n\n", options: {} },

    { text: "Frustration Close-up\n", options: { bold: true, color: ORANGE } },
    { text: "Overlay: '2 HOURS LATER.' Sweat droplets. A rattling matatu exhaust cloud rolls past. Color palette slowly drains — from warm digital gold to dry, muted ochre and grey.", options: {} },
  ],

  rightContent: [
    { text: '"You found the perfect deal.\nOn your phone.\nIn seconds."\n\n', options: { italic: true } },
    { text: "[Beat — low mbira drone]\n\n", options: { color: MUTED, italic: true } },
    { text: '"...But when it\'s time to pay —"\n\n', options: { italic: true } },
    { text: "[SCREEN CRACK SFX]\n\n", options: { color: MUTED, italic: true } },
    { text: '"...you\'re standing at a petrol station.\nTwo hours from home.\nWaiting for a stranger.\n\nBecause in Southern Africa,\nthe deal lives online —\nbut the trust?\n\nIt lives in the real world."', options: { italic: true } },
  ]
});


// ═══════════════════════════════════════════════════════════════
// SLIDE 3 — SCENE 2: INTRODUCING ANCHORFLOW (0:20–0:40)
// ═══════════════════════════════════════════════════════════════
addSceneSlide({
  sceneNum: 2,
  timing: "0:20 – 0:40",
  sceneColor: DARKTEAL,
  title: "Introducing AnchorFlow",
  mood: "Pivot → Hopeful Tech",

  leftContent: [
    { text: "Logo Entry\n", options: { bold: true, color: DARKTEAL } },
    { text: "Dusty street corner dims to a grey silhouette. The AnchorFlow SYNCHRONIZED FEET logo steps in from screen-left — two stylized teal feet moving in perfect lockstep rhythm.\n\n", options: {} },

    { text: "The Bridge Builds\n", options: { bold: true, color: DARKTEAL } },
    { text: "Logo pulses with a warm teal radial glow. A glowing digital bridge materializes — arching gracefully from a buyer's phone (left) to a seller's phone (right). Tiny nodes of light travel along its arc like fiber-optic data streams.\n\n", options: {} },

    { text: "Transition Out\n", options: { bold: true, color: DARKTEAL } },
    { text: "The dusty street corner dissolves beneath the bridge. The world transforms — clean, bright, fully digital. The bridge expands to fill the screen in vibrant teal.", options: {} },
  ],

  rightContent: [
    { text: '"Introducing AnchorFlow."\n\n', options: { bold: true } },
    { text: '"Trust. As an API."\n\n', options: { italic: true } },
    { text: "[Music lifts — confident Afrobeats-tech groove]\n\n", options: { color: MUTED, italic: true } },
    { text: '"A secure digital escrow bridge that holds payment safely — while your goods travel.\n\nThe buyer is protected.\nThe seller is guaranteed.\n\nNobody has to go anywhere.\n\nThe deal stays digital.\nStart.\nTo.\nFinish."', options: { italic: true } },
  ]
});


// ═══════════════════════════════════════════════════════════════
// SLIDE 4 — SCENE 3: HOW IT WORKS (0:40–1:10)
// ═══════════════════════════════════════════════════════════════
addSceneSlide({
  sceneNum: 3,
  timing: "0:40 – 1:10",
  sceneColor: TEAL,
  title: "How It Works — Paid. Delivered. Done.",
  mood: "Upbeat Rhythmic Tech",

  leftContent: [
    { text: "BEAT 1 — 'PAID'\n", options: { bold: true, color: DARKTEAL } },
    { text: "Buyer taps 'Pay.' A glowing vault icon SNAPS shut around animated coins with a satisfying click. Both the buyer's and seller's phones light up with a 'Funds Secured ✓' teal notification.\n\n", options: {} },

    { text: "BEAT 2 — 'DELIVERED'\n", options: { bold: true, color: DARKTEAL } },
    { text: "Corporate Memphis courier — teal vest, confident stride — collects a package from the seller. A real-time tracking dot moves steadily across a stylized SADC map. Arrows animate the route.\n\n", options: {} },

    { text: "BEAT 3 — 'DONE'\n", options: { bold: true, color: DARKTEAL } },
    { text: "Buyer taps 'Accept Delivery.' Vault BURSTS open. Animated coins split and flow simultaneously — right to seller, left to courier. 'INSTANT RELEASE ⚡' label punches onto screen. All three characters fist-bump across the screen.", options: {} },
  ],

  rightContent: [
    { text: '"Here\'s how AnchorFlow works."\n\n', options: {} },
    { text: "[BEAT 1 drum hit]\n", options: { color: MUTED, italic: true } },
    { text: '"PAID — The buyer locks funds in escrow. The seller can\'t be stiffed. The buyer can\'t lose their money."\n\n', options: { italic: true } },
    { text: "[BEAT 2 drum hit]\n", options: { color: MUTED, italic: true } },
    { text: '"DELIVERED — A verified courier picks up and tracks the shipment, live."\n\n', options: { italic: true } },
    { text: "[BEAT 3 drum hit]\n", options: { color: MUTED, italic: true } },
    { text: '"DONE — Buyer confirms. Funds release instantly to seller and courier.\n\nNo meetups.\nNo risk.\nNo drama."', options: { italic: true } },
  ]
});


// ═══════════════════════════════════════════════════════════════
// SLIDE 5 — SCENE 4: EMPOWERMENT (1:10–1:25)
// ═══════════════════════════════════════════════════════════════
addSceneSlide({
  sceneNum: 4,
  timing: "1:10 – 1:25",
  sceneColor: TEAL,
  title: "Empowerment — The Growth Engine",
  mood: "Joyful + Triumphant Swell",

  leftContent: [
    { text: "Opening\n", options: { bold: true, color: TEAL } },
    { text: "Tight shot: a small home kitchen. A bold, warm Corporate Memphis baker icing a cake at a tiny table. Intimate, golden-hour lighting.\n\n", options: {} },

    { text: "The Zoom-Out\n", options: { bold: true, color: TEAL } },
    { text: "Camera pulls back to reveal a stylized map of Southern Africa. Teal arrows radiate outward from her kitchen to customers across Zimbabwe, Zambia, Botswana, Mozambique. Each arrow pulses as a new order notification pings.\n\n", options: {} },

    { text: "The Growth Burst\n", options: { bold: true, color: TEAL } },
    { text: "Customer counter animates: '1 → 50 → 500.' Additional micro-business icons bloom across the map — tailor, phone-repair tech, fresh produce vendor. Each connected by the same glowing teal trust-grid. Badge explodes: 'TRUST = UNLOCKED.'", options: {} },
  ],

  rightContent: [
    { text: '"When trust is no longer a barrier —"\n\n', options: { italic: true } },
    { text: "[Music swells — melodic hook lifts]\n\n", options: { color: MUTED, italic: true } },
    { text: '"Every hustle becomes a business.\n\nA baker in Harare ships to Bulawayo.\nA tailor in Lusaka reaches all of Zambia.\nA phone-repair shop in Gaborone serves the whole of SADC.\n\nAnchorFlow doesn\'t just process payments.\n\nIt unlocks\nan economy."', options: { italic: true } },
  ]
});


// ═══════════════════════════════════════════════════════════════
// SLIDE 6 — SCENE 5: THE CTA (1:25–1:30)
// ═══════════════════════════════════════════════════════════════
addSceneSlide({
  sceneNum: 5,
  timing: "1:25 – 1:30",
  sceneColor: TEAL,
  title: "The Call to Action",
  mood: "Confident Resolve",

  leftContent: [
    { text: "Clean Cut\n", options: { bold: true, color: TEAL } },
    { text: "Hard cut to pure Deep Navy (#1A2B3C). One beat of visual silence — nothing but the color.\n\n", options: {} },

    { text: "Logo Reveal\n", options: { bold: true, color: TEAL } },
    { text: "AnchorFlow SYNCHRONIZED FEET logo pulses to center screen, glowing softly. Tagline fades in below:\n'Paid. Delivered. Done.' in Vibrant Teal, Georgia italic.\n\n", options: {} },

    { text: "CTA Button\n", options: { bold: true, color: TEAL } },
    { text: "A teal Indiegogo-style rounded button pulses with a soft glow: 'BACK US TODAY →'\n\nSmall white URL appears beneath the button.\n\nFinal hold: Logo + tagline + button for full 3-second end card.", options: {} },
  ],

  rightContent: [
    { text: "[One beat of silence]\n\n", options: { color: MUTED, italic: true } },
    { text: '"AnchorFlow."\n\n', options: { bold: true } },
    { text: "[Single resonant teal piano chord]\n\n", options: { color: MUTED, italic: true } },
    { text: '"Paid.\nDelivered.\nDone."\n\n', options: { bold: true, italic: true } },
    { text: '"Back us on Indiegogo today."\n\n', options: { italic: true } },
    { text: "[END CARD — Logo hold, 3 seconds\n Music fades to silence]", options: { color: MUTED, italic: true } },
  ]
});


// ═══════════════════════════════════════════════════════════════
// SLIDE 7 — PRODUCTION REFERENCE (Music + Color + Style)
// ═══════════════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: NAVY };

  // Header bar
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 0, w: 10, h: 0.76,
    fill: { color: HDARK }, line: { color: HDARK }
  });
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 0, w: 0.22, h: 0.76,
    fill: { color: TEAL }, line: { color: TEAL }
  });

  s.addText("PRODUCTION REFERENCE", {
    x: 0.38, y: 0.06, w: 6, h: 0.25,
    fontSize: 8, fontFace: "Calibri", color: TEAL,
    bold: true, charSpacing: 3, margin: 0
  });
  s.addText("Music Direction  ·  Color Palette  ·  Style Notes", {
    x: 0.38, y: 0.34, w: 9, h: 0.3,
    fontSize: 14, fontFace: "Georgia", color: WHITE,
    bold: false, margin: 0
  });

  // ── MUSIC SECTION ────────────────────────────────────────
  s.addText("MUSIC DIRECTION", {
    x: 0.35, y: 0.92, w: 9, h: 0.24,
    fontSize: 8, fontFace: "Calibri", color: TEAL,
    bold: true, charSpacing: 3, margin: 0
  });

  const musicData = [
    [
      { text: "SCENE / TIMING", options: { bold: true, color: WHITE, fill: { color: "0A1825" }, fontSize: 8.5, align: "center" } },
      { text: "MOOD & MUSICAL DIRECTION", options: { bold: true, color: WHITE, fill: { color: "0A1825" }, fontSize: 8.5, align: "center" } },
    ],
    [
      { text: "Scene 1\n0:00–0:20", options: { color: ORANGE, bold: true, fontSize: 9.5, fill: { color: "1F3347" } } },
      { text: "Tense, dissonant. Low mbira drone layered under a stumbling, muted hip-hop beat. The rhythm feels 'broken' — reflecting the digital-to-analog regression. Muted bass. No melody.", options: { color: "C8DCE8", fontSize: 9.5, fill: { color: "182D3E" } } },
    ],
    [
      { text: "Scene 2\n0:20–0:40", options: { color: DARKTEAL, bold: true, fontSize: 9.5, fill: { color: "1F3347" } } },
      { text: "Pivot moment. Single clear piano note on logo entry. Then a confident Afrobeats-influenced tech groove builds steadily. Warmth enters the soundscape as the teal bridge appears.", options: { color: "C8DCE8", fontSize: 9.5, fill: { color: "182D3E" } } },
    ],
    [
      { text: "Scene 3\n0:40–1:10", options: { color: TEAL, bold: true, fontSize: 9.5, fill: { color: "1F3347" } } },
      { text: "Full upbeat rhythmic tech track — tight and forward-moving. Each 'PAID / DELIVERED / DONE' beat lands on a sharp drum hit. Confident pulse. Reference: lo-fi Afrotech / Amapiano hybrid.", options: { color: "C8DCE8", fontSize: 9.5, fill: { color: "182D3E" } } },
    ],
    [
      { text: "Scene 4\n1:10–1:25", options: { color: TEAL, bold: true, fontSize: 9.5, fill: { color: "1F3347" } } },
      { text: "Triumphant melodic swell. The bass line grows with each new customer arrow. Joyful, aspirational — the sound of an economy unlocking. Feels earned, not forced.", options: { color: "C8DCE8", fontSize: 9.5, fill: { color: "182D3E" } } },
    ],
    [
      { text: "Scene 5\n1:25–1:30", options: { color: TEAL, bold: true, fontSize: 9.5, fill: { color: "1F3347" } } },
      { text: "Music resolves to a single resonant teal piano chord. One beat of complete silence precedes it — maximizes impact. Hold on logo. Fade out slowly.", options: { color: "C8DCE8", fontSize: 9.5, fill: { color: "182D3E" } } },
    ],
  ];

  s.addTable(musicData, {
    x: 0.28, y: 1.22, w: 9.45, h: 2.4,
    border: { pt: 0.75, color: BDRLINE },
    colW: [1.55, 7.9],
    rowH: [0.3, 0.42, 0.42, 0.42, 0.42, 0.42],
  });

  // ── COLOR PALETTE ────────────────────────────────────────
  s.addText("COLOR PALETTE", {
    x: 0.35, y: 3.78, w: 9, h: 0.24,
    fontSize: 8, fontFace: "Calibri", color: TEAL,
    bold: true, charSpacing: 3, margin: 0
  });

  const swatches = [
    { hex: "1A2B3C", name: "Deep Navy",     usage: "Dark BGs, authority, end card" },
    { hex: "20C997", name: "Vibrant Teal",  usage: "Brand, bridge, CTA, accents" },
    { hex: "FF6B35", name: "Alert Orange",  usage: "Scene 1 frustration, glitch" },
    { hex: "FFFFFF", name: "Pure White",    usage: "Text on dark backgrounds" },
    { hex: "EDF4F8", name: "Ice Blue",      usage: "Light slide backgrounds" },
  ];

  swatches.forEach((sw, i) => {
    const x = 0.28 + i * 1.9;
    // Swatch block
    s.addShape(pres.shapes.RECTANGLE, {
      x, y: 4.1, w: 1.72, h: 0.7,
      fill: { color: sw.hex }, line: { color: BDRLINE }
    });
    // Hex label on swatch
    const onDark = ["1A2B3C", "20C997", "FF6B35"].includes(sw.hex);
    const swTextColor = onDark ? WHITE : NAVY;
    s.addText(`#${sw.hex}`, {
      x, y: 4.1, w: 1.72, h: 0.7,
      fontSize: 9, fontFace: "Calibri", color: swTextColor,
      bold: true, align: "center", valign: "middle", margin: 0
    });
    // Name
    s.addText(sw.name, {
      x, y: 4.84, w: 1.72, h: 0.22,
      fontSize: 9, fontFace: "Calibri", color: WHITE,
      bold: true, align: "center", margin: 0
    });
    // Usage note
    s.addText(sw.usage, {
      x, y: 5.06, w: 1.72, h: 0.22,
      fontSize: 7.5, fontFace: "Calibri", color: MUTED,
      align: "center", margin: 0
    });
  });

  // Bottom bar
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 5.46, w: 10, h: 0.165,
    fill: { color: TEAL }, line: { color: TEAL }
  });
}


// ═══════════════════════════════════════════════════════════════
// WRITE FILE
// ═══════════════════════════════════════════════════════════════
const outFile = "AnchorFlow_Explainer_Script.pptx";
pres.writeFile({ fileName: outFile })
  .then(() => console.log(`\u2705  Written: ${outFile}`))
  .catch(err => { console.error("\u274C  Error:", err); process.exit(1); });
