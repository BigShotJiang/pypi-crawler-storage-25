"""
amelis2dame - A library for fetching and decrypting S/MIME encrypted emails.

This library provides tools to:
- Load S/MIME certificates and private keys
- Connect to IMAP mailboxes
- Fetch and decrypt S/MIME encrypted emails
- Extract PDF attachments
- Manage email post-processing (mark as seen, delete, move)
"""

from amelis2dame.certificate import SMIMECertificate
from amelis2dame.imap import MailboxClient, EmailAction
from amelis2dame.smime import decrypt_email
from amelis2dame.attachment import extract_attachments

__version__ = "0.2.6"

__all__ = [
    "SMIMECertificate",
    "MailboxClient",
    "EmailAction",
    "decrypt_email",
    "extract_attachments",
]
