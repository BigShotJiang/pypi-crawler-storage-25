"""PDF parsing and renaming functionality for lab reports."""

import logging
import os
import re
from datetime import date, datetime
from pathlib import Path
from typing import Dict, Optional

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None

logger = logging.getLogger(__name__)


class PDFData:
    """Container for extracted PDF data."""

    def __init__(self):
        self.last_name: Optional[str] = None
        self.first_name: Optional[str] = None
        self.birth_date: Optional[date] = None
        self.barcode_number: Optional[str] = None
        self.samplecollectiondate: Optional[date] = None
        self.receipt_datetime: Optional[datetime] = None
        self.finalreport: Optional[date] = None

    def to_dict(self) -> Dict[str, Optional[str]]:
        """Convert to dictionary for template formatting."""
        return {
            "last_name": self.last_name or "",
            "first_name": self.first_name or "",
            "birth_date": self.birth_date.strftime("%d.%m.%Y") if self.birth_date else "",
            "barcode_number": self.barcode_number or "",
            "samplecollectiondate": self.samplecollectiondate.strftime("%d.%m.%Y") if self.samplecollectiondate else "",
            "receipt_datetime": self.receipt_datetime.strftime("%d.%m.%Y %H:%M") if self.receipt_datetime else "",
            "finalreport": self.finalreport.strftime("%d.%m.%Y") if self.finalreport else "",
        }

    def __repr__(self):
        return (
            f"PDFData(last_name={self.last_name}, first_name={self.first_name}, "
            f"birth_date={self.birth_date}, barcode_number={self.barcode_number}, "
            f"samplecollectiondate={self.samplecollectiondate}, receipt_datetime={self.receipt_datetime}, finalreport={self.finalreport})"
        )


def extract_pdf_data(pdf_path: str) -> Optional[PDFData]:
    """
    Extract structured data from lab report PDF.

    Extracts:
    - Last name (from "Name" field)
    - First name (from "Name" field)
    - Birth date (from "geb. am" field)
    - Barcode number (from "Barcodenummer" field)
    - Entnahme (sample collection date)
    - Eingang (receipt date)
    - Endbefund (final report date)

    Args:
        pdf_path: Path to PDF file

    Returns:
        PDFData object with extracted fields, or None if extraction fails
    """
    if PdfReader is None:
        logger.error("pypdf library not installed. Install with: uv add pypdf")
        return None

    try:
        reader = PdfReader(pdf_path)
        if not reader.pages:
            logger.warning(f"PDF has no pages: {pdf_path}")
            return None

        # Extract text from first page
        text = reader.pages[0].extract_text()

        data = PDFData()

        # Extract Name: locate the "Name … geb. am" section, then find
        # "LASTNAME, FIRSTNAME" within. Some PDF layouts insert salutation,
        # title or placeholder tokens between the "Name" label and the actual
        # comma-separated name pair; a section-bounded inner match handles both
        # the direct ("Name LASTNAME, FIRSTNAME") and the multi-token layouts.
        name_section = re.search(
            r"Name(.{0,200}?)(?:geb\.\s*am|Eingang|Auftraggeber|Kostentr)",
            text,
            re.IGNORECASE | re.DOTALL,
        )
        if name_section:
            # The lab PDFs render the patient name in at least three ways
            # depending on the source layout, and pypdf's text extraction
            # reflects that 1:1:
            #
            #   (a) "Name LAST, FIRST"           -- single line
            #   (b) "Name\nLAST, FIRST"          -- name on its own line
            #   (c) "Name\nLA\nST\n,\n \nF\nI\nR\nST"
            #       -- one character per line, with a separate ',' and ' '
            #          token (happens when the lab letters individual glyphs)
            #   (d) "Name\nLAST1-\nLAST2, TOM"
            #       "Name\n\nLAST1\n-\nLAST2, TOM"
            #       -- hyphenated double name split at the hyphen
            #
            # We rebuild last/first by ignoring the line structure entirely:
            # split the section at the first comma, then collect every letter
            # (and hyphen) up to the next field marker. Whitespace --
            # newlines included -- is treated as glyph spacing, not as a
            # name terminator.
            section_text = name_section.group(1)
            comma_idx = section_text.find(",")
            if comma_idx > 0:
                before = section_text[:comma_idx]
                after = section_text[comma_idx + 1 :]

                # Last name: letters and hyphens before the comma, in order.
                last_chars = re.findall(r"[A-Za-zÄÖÜäöüß\-]", before)
                if last_chars:
                    data.last_name = "".join(last_chars)

                # First name: letters between the comma and the next field.
                # The next field starts with a lowercase token (e.g.
                # "Entnahme"... no, that's capitalised) -- safer to stop at
                # any of the known section markers, or at a digit, or at a
                # double newline.
                after = re.split(
                    r"\n\s*(?:Entnahme|Eingang|geb\.|Auftraggeber|"
                    r"Kostentr|Tagesnummer|Endbefund|Barcode|\d)",
                    after,
                    maxsplit=1,
                )[0]
                first_chars = re.findall(r"[A-Za-zÄÖÜäöüß\-]", after)
                if first_chars:
                    data.first_name = "".join(first_chars)

        # Extract birth date (format: "geb. am DD.MM.YYYY")
        # Digits may be on separate lines, need to collect them
        birth_match = re.search(
            r"geb\.\s*am(.{0,100}?)(?:Eingang|Kostenträger|Jahre)",
            text,
            re.IGNORECASE | re.DOTALL,
        )
        if birth_match:
            birth_section = birth_match.group(1)
            # Extract digits and periods, then reconstruct date
            chars = re.findall(r"[\d.]", birth_section)
            if chars:
                date_str = "".join(chars)
                # Match DD.MM.YYYY pattern in the extracted string
                date_pattern = re.match(r"(\d{2}\.\d{2}\.\d{4})", date_str)
                if date_pattern:
                    data.birth_date = datetime.strptime(date_pattern.group(1), "%d.%m.%Y").date()

        # Extract Barcodenummer (digits may be on separate lines in PDF extraction)
        # Find text between "Barcodenummer" and next field (Kostenträger/Tagesnummer/Endbefund)
        barcode_match = re.search(
            r"Barcodenummer(.{0,100}?)(?:Kostenträger|Tagesnummer|Endbefund)",
            text,
            re.IGNORECASE | re.DOTALL,
        )
        if barcode_match:
            # Extract all consecutive digits from the matched section
            digits = re.findall(r"\d", barcode_match.group(1))
            if digits:
                data.barcode_number = "".join(digits)

        # Extract Entnahme (sample collection date)
        samplecollectiondate_match = re.search(
            r"Entnahme\s+(\d{2}\.\d{2}\.\d{4})", text, re.IGNORECASE
        )
        if samplecollectiondate_match:
            data.samplecollectiondate = datetime.strptime(samplecollectiondate_match.group(1).strip(), "%d.%m.%Y").date()

        # Extract Eingang (receipt date and time)
        receiptdate_match = re.search(
            r"Eingang\s+(\d{2}\.\d{2}\.\d{4}(?:\s+\d{2}:\d{2})?)", text, re.IGNORECASE
        )
        if receiptdate_match:
            raw = receiptdate_match.group(1).strip()
            try:
                data.receipt_datetime = datetime.strptime(raw, "%d.%m.%Y %H:%M")
            except ValueError:
                data.receipt_datetime = datetime.strptime(raw, "%d.%m.%Y")

        # Extract Endbefund (final report date)
        finalreport_match = re.search(
            r"Endbefund\s+(\d{2}\.\d{2}\.\d{4})", text, re.IGNORECASE
        )
        if finalreport_match:
            data.finalreport = datetime.strptime(finalreport_match.group(1).strip(), "%d.%m.%Y").date()

        logger.debug(f"Extracted data: {data}")
        return data

    except Exception as e:
        logger.error(f"Failed to extract data from PDF {pdf_path}: {e}")
        return None



def apply_rename_pattern(pattern: str, pdf_data: PDFData) -> str:
    """
    Apply rename pattern to PDF data.

    Supports variables:
    - {last_name} - Last name
    - {first_name} - First name
    - {birth_date} - Birth date (DD.MM.YYYY)
    - {barcode_number} - Barcode number
    - {samplecollectiondate} - Sample collection date
    - {receipt_datetime} - Receipt date and time
    - {finalreport} - Final report date
    - {samplecollectiondate_yyyymmdd} - Sample date in YYYYMMDD format
    - {receipt_datetime_yyyymmdd} - Receipt date in YYYYMMDD format
    - {finalreport_yyyymmdd} - Final report date in YYYYMMDD format

    Example patterns:
    - "{last_name}_{first_name}_{barcode_number}.pdf"
    - "{finalreport_yyyymmdd}_{last_name}_{barcode_number}.pdf"
    - "Lab_{barcode_number}_{samplecollectiondate_yyyymmdd}.pdf"

    Args:
        pattern: Rename pattern with variable placeholders
        pdf_data: Extracted PDF data

    Returns:
        Formatted filename
    """
    data = pdf_data.to_dict()

    # Add formatted date versions
    if pdf_data.samplecollectiondate:
        data["samplecollectiondate_yyyymmdd"] = pdf_data.samplecollectiondate.strftime("%Y%m%d")
    if pdf_data.receipt_datetime:
        data["receipt_datetime_yyyymmdd"] = pdf_data.receipt_datetime.strftime("%Y%m%d")
    if pdf_data.finalreport:
        data["finalreport_yyyymmdd"] = pdf_data.finalreport.strftime("%Y%m%d")

    # Apply pattern
    try:
        new_name = pattern.format(**data)
        # Sanitize filename (remove invalid characters)
        new_name = re.sub(r'[<>:"/\\|?*]', "_", new_name)
        return new_name
    except KeyError as e:
        logger.error(f"Invalid variable in rename pattern: {e}")
        raise ValueError(f"Unknown variable in pattern: {e}")


def rename_pdf(
    pdf_path: str, rename_pattern: str, dry_run: bool = False
) -> Optional[str]:
    """
    Rename PDF file based on extracted data and pattern.

    Args:
        pdf_path: Path to original PDF file
        rename_pattern: Rename pattern with variable placeholders
        dry_run: If True, only log the new name without renaming

    Returns:
        New file path if successful, None otherwise
    """
    # Extract data from PDF
    pdf_data = extract_pdf_data(pdf_path)
    if not pdf_data:
        logger.error(f"Could not extract data from PDF: {pdf_path}")
        return None

    # Apply rename pattern
    try:
        new_filename = apply_rename_pattern(rename_pattern, pdf_data)
    except ValueError as e:
        logger.error(f"Invalid rename pattern: {e}")
        return None

    # Ensure .pdf extension
    if not new_filename.lower().endswith(".pdf"):
        new_filename += ".pdf"

    # Build new path
    original_path = Path(pdf_path)
    new_path = original_path.parent / new_filename

    # Check if file already exists
    if new_path.exists() and new_path != original_path:
        logger.warning(f"Target file already exists: {new_path}")
        # Add counter suffix
        counter = 1
        base_name = new_path.stem
        while new_path.exists():
            new_filename = f"{base_name}_{counter}.pdf"
            new_path = original_path.parent / new_filename
            counter += 1
        logger.info(f"Using alternative filename: {new_filename}")

    if dry_run:
        logger.info(f"[DRY RUN] Would rename: {original_path.name} -> {new_filename}")
        return str(new_path)

    # Perform rename
    try:
        os.rename(pdf_path, new_path)
        logger.info(f"Renamed: {original_path.name} -> {new_filename}")
        return str(new_path)
    except OSError as e:
        logger.error(f"Failed to rename file: {e}")
        return None
