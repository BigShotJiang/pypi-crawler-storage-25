"""Command-line interface for amelis2dame."""

import argparse
import logging
import os
import sys
from collections import defaultdict
from datetime import datetime
from email.message import EmailMessage
from email.utils import parsedate_to_datetime
from typing import List, Tuple, Optional
from dotenv import load_dotenv

from amelis2dame import __version__
from amelis2dame.certificate import SMIMECertificate
from amelis2dame.imap import MailboxClient, EmailAction
from amelis2dame.smime import decrypt_email
from amelis2dame.attachment import extract_attachments
from amelis2dame.pdf_parser import rename_pdf, extract_pdf_data
from amelis2dame.dame import create_dame_document
from pydifact_aek.constants import Specialities

logger = logging.getLogger(__name__)


def get_email_timestamp(msg: EmailMessage) -> datetime:
    """
    Extract timestamp from email message.

    Tries Date header first, falls back to current time if missing/invalid.

    Args:
        msg: Email message

    Returns:
        datetime object representing email timestamp
    """
    try:
        date_header = msg.get("Date")
        if date_header:
            return parsedate_to_datetime(date_header)
    except Exception as e:
        logger.debug(f"Failed to parse Date header: {e}")

    # Fall back to current time if Date header is missing/invalid
    logger.warning("Email has invalid/missing Date header, using current time")
    return datetime.now()


def deduplicate_emails_by_subject(
    emails: List[Tuple[str, EmailMessage]],
) -> Tuple[List[Tuple[str, EmailMessage]], List[Tuple[str, EmailMessage]]]:
    """
    Group emails by subject and return only the latest email per subject.

    When multiple emails have the exact same subject, only the most recent
    email (by Date header timestamp) is kept for processing.

    Args:
        emails: List of (email_id, EmailMessage) tuples

    Returns:
        Tuple of:
            - List of latest emails (one per unique subject)
            - List of older duplicate emails to handle
    """
    # Group emails by subject
    subject_groups = defaultdict(list)

    for email_id, msg in emails:
        subject = msg.get("Subject", "").strip()
        if not subject:
            subject = "(No Subject)"

        timestamp = get_email_timestamp(msg)
        subject_groups[subject].append((email_id, msg, timestamp))

    latest_emails = []
    duplicate_emails = []

    # For each subject group, find the latest email
    for subject, group in subject_groups.items():
        if len(group) == 1:
            # No duplicates, keep the single email
            email_id, msg, _ = group[0]
            latest_emails.append((email_id, msg))
        else:
            # Sort by timestamp descending (most recent first)
            group.sort(key=lambda x: x[2], reverse=True)

            # Keep the latest email
            latest_id, latest_msg, latest_timestamp = group[0]
            latest_emails.append((latest_id, latest_msg))

            logger.info(
                f"Found {len(group)} emails with subject '{subject}', "
                f"using latest from {latest_timestamp.strftime('%Y-%m-%d %H:%M:%S')}"
            )

            # Mark older emails as duplicates
            for email_id, msg, timestamp in group[1:]:
                duplicate_emails.append((email_id, msg))
                logger.debug(
                    f"  - Duplicate (older): {timestamp.strftime('%Y-%m-%d %H:%M:%S')}"
                )

    return latest_emails, duplicate_emails


def parse_email_action(action_str: str) -> tuple[EmailAction, str | None]:
    """
    Parse email action string.

    Formats:
        - "mark_seen" -> (EmailAction.MARK_SEEN, None)
        - "delete" -> (EmailAction.DELETE, None)
        - "move:Archive" -> (EmailAction.MOVE_TO_FOLDER, "Archive")

    Args:
        action_str: Action string from environment or CLI

    Returns:
        Tuple of (EmailAction, folder_name)
    """
    if not action_str:
        return EmailAction.MARK_SEEN, None

    action_str = action_str.strip()
    action_lower = action_str.lower()

    if action_lower == "delete":
        return EmailAction.DELETE, None
    elif action_lower.startswith("move:"):
        folder = action_str.split(":", 1)[1].strip()
        if "/" in folder:
            raise ValueError(
                "Folder name cannot contain '/' - did you mean "
                f"'{folder.replace('/', '.')}''"
            )
        return EmailAction.MOVE_TO_FOLDER, folder
    else:
        # Default to mark_seen
        return EmailAction.MARK_SEEN, None


def parse_arguments() -> argparse.Namespace:
    """
    Parse command-line arguments.

    CLI arguments override .env configuration values.
    """
    parser = argparse.ArgumentParser(
        prog="amelis2dame",
        description="Fetch and decrypt S/MIME encrypted emails, extract PDF attachments",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Use .env configuration
  amelis2dame

  # Override specific settings
  amelis2dame --subject "Invoice" --output ./invoices

  # Full CLI configuration (no .env needed)
  amelis2dame \\
    --imap-server imap.example.com \\
    --imap-user user@example.com \\
    --imap-pass secret \\
    --cert certificate.p12 \\
    --password pfx_pass \\
    --subject "Order" \\
    --output ./orders \\
    --email-action delete \\
    --duplicate-action "move:Duplicates"

Action formats:
  mark_seen              - Mark email as read (default)
  delete                 - Delete email from mailbox
  move:FolderName        - Move email to specified IMAP folder
        """,
    )

    # IMAP connection settings
    imap_group = parser.add_argument_group("IMAP Configuration")
    imap_group.add_argument(
        "--imap-server",
        dest="imap_server",
        help="IMAP server hostname (default: from .env IMAP_SERVER)",
    )
    imap_group.add_argument(
        "--imap-port",
        dest="imap_port",
        type=int,
        help="IMAP server port (default: from .env IMAP_PORT or 993)",
    )
    imap_group.add_argument(
        "--imap-user",
        dest="imap_user",
        help="IMAP username/email account (default: from .env EMAIL_ACCOUNT)",
    )
    imap_group.add_argument(
        "--imap-pass",
        dest="imap_pass",
        help="IMAP password (default: from .env EMAIL_PASSWORD)",
    )

    # Certificate settings
    cert_group = parser.add_argument_group("S/MIME Certificate")
    cert_group.add_argument(
        "--cert",
        dest="cert_path",
        help="Path to P12/PFX certificate file (default: from .env P12_CERTIFICATE_PATH)",
    )
    cert_group.add_argument(
        "--password",
        dest="cert_password",
        help="Certificate password (default: from .env PFX_PASSWORD)",
    )

    # Processing settings
    process_group = parser.add_argument_group("Email Processing")
    process_group.add_argument(
        "--subject",
        dest="subject_keyword",
        help='Subject keyword to filter emails (default: from .env SUBJECT_KEYWORD or "Auftrag")',
    )
    process_group.add_argument(
        "--output",
        dest="output_dir",
        help="Output directory for PDF attachments (default: from .env SAVE_DIRECTORY or ./output)",
    )
    process_group.add_argument(
        "--email-action",
        dest="email_action",
        help='Action for successfully processed emails: mark_seen|delete|move:Folder (default: from .env EMAIL_ACTION or "mark_seen")',
    )
    process_group.add_argument(
        "--duplicate-action",
        dest="duplicate_action",
        help='Action for older duplicate emails (same subject): mark_seen|delete|move:Folder (default: from .env DUPLICATE_ACTION or "mark_seen")',
    )
    process_group.add_argument(
        "--rename",
        dest="rename_pattern",
        help="Rename PDFs using pattern with variables: {last_name}, {first_name}, {birth_date}, {barcode_number}, {samplecollectiondate}, {receipt_datetime}, {finalreport}, {samplecollectiondate_yyyymmdd}, {receipt_datetime_yyyymmdd}, {finalreport_yyyymmdd} (default: from .env RENAME_PATTERN)",
    )
    process_group.add_argument(
        "--dame-sender",
        dest="dame_sender",
        help="EDIFACT sender ID for DAME output; requires --dame-receiver. When both are set (via CLI or .env DAME_SENDER/DAME_RECEIVER), PDFs are converted to AEK-EDIFACT documents and the original PDF is replaced. (default: from .env DAME_SENDER)",
    )
    process_group.add_argument(
        "--dame-receiver",
        dest="dame_receiver",
        help="EDIFACT receiver ID for DAME output; requires --dame-sender. (default: from .env DAME_RECEIVER)",
    )

    # General options
    parser.add_argument(
        "--config",
        dest="config_file",
        metavar="PATH",
        help="Path to a custom .env config file (default: .env in current directory)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose/debug logging"
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )

    return parser.parse_args()


def get_config_value(
    cli_value: Optional[str], env_key: str, default: str = None
) -> Optional[str]:
    """
    Get configuration value with priority: CLI arg > .env > default.

    Args:
        cli_value: Value from command-line argument (None if not provided)
        env_key: Environment variable key to check
        default: Default value if neither CLI nor env is set

    Returns:
        Configuration value
    """
    if cli_value is not None:
        return cli_value
    return os.getenv(env_key, default)


def main():
    """CLI entry point for amelis2dame."""

    # Parse command-line arguments
    args = parse_arguments()

    # Load environment variables (from custom config file or default .env)
    load_dotenv(dotenv_path=args.config_file)

    # Resolve DAME identifiers: CLI args take precedence, then .env.
    # The CLI flags above are namespaced as args.dame_sender/dame_receiver;
    # we overwrite them here so the downstream code (line ~470) sees the
    # effective value regardless of source.
    args.dame_sender = get_config_value(args.dame_sender, "DAME_SENDER")
    args.dame_receiver = get_config_value(args.dame_receiver, "DAME_RECEIVER")

    # Validate DAME options: both must be provided or neither
    if bool(args.dame_sender) != bool(args.dame_receiver):
        print(
            "error: DAME_SENDER and DAME_RECEIVER must both be set (via CLI flags or .env)",
            file=sys.stderr,
        )
        return 1

    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Load configuration: CLI args override .env values
    imap_server = get_config_value(args.imap_server, "IMAP_SERVER")
    imap_port = (
        args.imap_port
        if args.imap_port is not None
        else int(os.getenv("IMAP_PORT", 993))
    )
    email_account = get_config_value(args.imap_user, "EMAIL_ACCOUNT")
    email_password = get_config_value(args.imap_pass, "EMAIL_PASSWORD")
    p12_cert_path = get_config_value(args.cert_path, "P12_CERTIFICATE_PATH")
    pfx_password = get_config_value(args.cert_password, "PFX_PASSWORD", "")
    save_directory = get_config_value(args.output_dir, "SAVE_DIRECTORY", "./output")
    subject_keyword = get_config_value(
        args.subject_keyword, "SUBJECT_KEYWORD", "Auftrag"
    )
    email_action_str = get_config_value(args.email_action, "EMAIL_ACTION", "mark_seen")
    duplicate_action_str = get_config_value(
        args.duplicate_action, "DUPLICATE_ACTION", "mark_seen"
    )
    rename_pattern = get_config_value(args.rename_pattern, "RENAME_PATTERN")

    # Validate required configuration
    if not all([imap_server, email_account, email_password, p12_cert_path]):
        logger.critical(
            "Missing required configuration. Please check your .env file (or --config) for: "
            "IMAP_SERVER, EMAIL_ACCOUNT, EMAIL_PASSWORD, P12_CERTIFICATE_PATH"
        )
        return 1

    # Parse email actions
    email_action, target_folder = parse_email_action(email_action_str)
    logger.info(f"Email post-processing action: {email_action.value}")
    if target_folder:
        logger.info(f"Target folder: {target_folder}")

    duplicate_action, duplicate_folder = parse_email_action(duplicate_action_str)
    logger.info(f"Duplicate email action: {duplicate_action.value}")
    if duplicate_folder:
        logger.info(f"Duplicate target folder: {duplicate_folder}")

    # Log rename configuration
    if rename_pattern:
        logger.info(f"PDF rename pattern: {rename_pattern}")
    else:
        logger.info("PDF renaming disabled (no pattern specified)")

    # Load S/MIME certificate
    try:
        certificate = SMIMECertificate.from_p12(p12_cert_path, pfx_password)
        if not certificate.validate():
            logger.critical("Certificate validation failed")
            return 1
    except Exception as e:
        logger.critical(f"Failed to load certificate: {e}")
        return 1

    # Ensure output directory exists
    if not os.path.exists(save_directory):
        os.makedirs(save_directory)
        logger.info(f"Created output directory: {save_directory}")

    # Connect to mailbox and process emails
    try:
        with MailboxClient(
            host=imap_server,
            port=imap_port,
            username=email_account,
            password=email_password,
        ) as mailbox:

            # Fetch emails matching criteria
            all_emails = mailbox.fetch_emails(subject=subject_keyword, unseen=False)

            if not all_emails:
                logger.info("No emails found matching criteria.")
                return 0

            logger.info(f"Fetched {len(all_emails)} email(s) matching criteria")

            # Deduplicate emails by subject (keep only latest per subject)
            emails, duplicates = deduplicate_emails_by_subject(all_emails)

            logger.info(
                f"Processing {len(emails)} unique email(s) after deduplication..."
            )

            # Handle duplicate emails first
            if duplicates:
                logger.info(
                    f"Handling {len(duplicates)} older duplicate email(s) "
                    f"with action: {duplicate_action.value}"
                )
                for dup_id, dup_msg in duplicates:
                    try:
                        mailbox.handle_email(dup_id, duplicate_action, duplicate_folder)
                    except Exception as e:
                        logger.error(f"Error handling duplicate email {dup_id}: {e}")

            # Process unique emails (latest per subject)
            for email_id, msg in emails:
                subject = msg.get("Subject", "No Subject")
                logger.info(f"Processing: {subject}")

                try:
                    # Decrypt email
                    decrypted_msg = decrypt_email(msg, certificate)

                    if not decrypted_msg:
                        logger.error(f"Decryption failed for: {subject}")
                        continue

                    # Extract PDF attachments
                    saved_files = extract_attachments(decrypted_msg, save_directory)

                    if saved_files:
                        logger.info(
                            f"Saved {len(saved_files)} attachment(s) from: {subject}"
                        )

                        # Track final paths (after optional rename) for DAME conversion
                        final_paths = list(saved_files)

                        # Rename PDFs if pattern is specified
                        if rename_pattern:
                            for i, pdf_path in enumerate(saved_files):
                                try:
                                    new_path = rename_pdf(pdf_path, rename_pattern)
                                    if new_path:
                                        logger.debug(
                                            f"Renamed PDF: {pdf_path} -> {new_path}"
                                        )
                                        final_paths[i] = new_path
                                except Exception as e:
                                    logger.error(
                                        f"Failed to rename PDF {pdf_path}: {e}"
                                    )

                        # Convert to DAME (AEK-EDIFACT) .bef document if requested
                        if args.dame_sender and args.dame_receiver:
                            for pdf_path in final_paths:
                                try:
                                    pdf_data = extract_pdf_data(pdf_path)
                                    if pdf_data:
                                        bef_path = create_dame_document(
                                            pdf_path,
                                            pdf_data,
                                            sender_id=args.dame_sender,
                                            receiver_id=args.dame_receiver,
                                            specialty=Specialities["160"],
                                        )
                                        if bef_path:
                                            logger.info(
                                                f"DAME document saved: {bef_path}"
                                            )
                                    else:
                                        logger.warning(
                                            f"Could not extract PDF data for DAME conversion: {pdf_path}"
                                        )
                                except Exception as e:
                                    logger.error(
                                        f"Failed to create DAME document for {pdf_path}: {e}"
                                    )
                    else:
                        logger.warning(f"No PDF attachments found in: {subject}")

                    # Handle email post-processing
                    mailbox.handle_email(email_id, email_action, target_folder)

                except ValueError as e:
                    logger.warning(f"Skipping email (not encrypted): {subject}")
                    # Restore unseen status for non-encrypted emails
                    mailbox._connection.store(email_id, "-FLAGS", "\\Seen")

                except Exception as e:
                    logger.error(f"Error processing email '{subject}': {e}")

            logger.info("Processing complete.")
            return 0

    except Exception as e:
        logger.critical(f"Fatal error: {e}")
        return 1


if __name__ == "__main__":
    exit(main())
