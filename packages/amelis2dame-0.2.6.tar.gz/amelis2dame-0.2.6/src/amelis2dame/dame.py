"""DAME (AEK-EDIFACT) document creation from PDF metadata."""

import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from pydifact_aek import EdifactTextBefund

from amelis2dame.pdf_parser import PDFData

logger = logging.getLogger(__name__)


def create_dame_document(
    pdf_path: str,
    pdf_data: PDFData,
    sender_id: str,
    receiver_id: str,
    specialty: str,
) -> Optional[str]:
    """
    Create an AEK-EDIFACT (DAME) document from PDF metadata and embed the PDF as payload.

    The resulting .bef file contains an EDIFACT MEDRPT envelope with patient metadata
    in the header segments (UNB, UNH, BGM, NAD) and the original PDF bytes as payload.
    The source PDF file is removed after the .bef file is written.

    Args:
        pdf_path: Path to the source PDF file (will be deleted on success).
        pdf_data: Metadata extracted from the PDF.
        sender_id: EDIFACT sender identifier (UNB sender field).
        receiver_id: EDIFACT receiver identifier (UNB receiver field).

    Returns:
        Path to the created .bef file, or None if creation fails.
    """
    try:
        doc = EdifactTextBefund()

        # --- Interchange / message metadata ---
        doc.metadata.sender = sender_id
        doc.metadata.receiver = receiver_id
        doc.metadata.document_name = "MEDRPT"
        doc.metadata.reference = "1"
        # UNH message reference: prefer the lab's barcode number so each
        # message has a stable, unique identifier downstream consumers can
        # use to deduplicate.
        doc.metadata.message_reference = pdf_data.barcode_number or "1"
        doc.metadata.specialty = "160"

        doc.metadata.patient_city = None
        doc.metadata.patient_address = None
        doc.metadata.patient_zip = None
        doc.metadata.patient_phone = None
        doc.metadata.findings = None
        doc.metadata.preparation_timestamp = pdf_data.receipt_datetime

        # --- Patient identity ---
        name_parts = [p for p in [pdf_data.last_name, pdf_data.first_name] if p]
        if name_parts:
            # write_file() splits patient_name by space to derive last/first for NAD
            doc.metadata.patient_name = " ".join(name_parts)

        if pdf_data.birth_date:
            doc.metadata.patient_birth_date = pdf_data.birth_date

        # # Barcode number used as social insurance / order number
        # if pdf_data.barcode_number:
        #     doc.metadata.social_insurance_number = pdf_data.barcode_number

        # --- Report date ---
        report_date = pdf_data.finalreport
        if report_date:
            doc.metadata.report_date = report_date
            doc.metadata.report_datetime = datetime.combine(
                report_date, datetime.min.time()
            )

        # --- Embed PDF as binary payload ---
        with open(pdf_path, "rb") as f:
            doc.payload = f.read()

        # --- Write .bef file next to the original PDF ---
        path_without_suffix = str(Path(pdf_path).with_suffix(""))
        output_path = path_without_suffix + "_dame" + ".pdf"
        doc.write_file(str(output_path))
        logger.info(f"Created DAME PDF document: {output_path}")

        # Remove the original PDF (it is now embedded in the .bef file)
        os.remove(pdf_path)
        logger.debug(f"Removed original PDF: {pdf_path}")

        return str(output_path)

    except Exception as e:
        logger.error(f"Failed to create DAME document for {pdf_path}: {e}")
        return None
