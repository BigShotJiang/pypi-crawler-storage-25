# Data Models Reference

All models use Pydantic for validation. This document covers the core data structures.

---

## Gradient v2.6 Event Data Models

### GradientEventRow

A single event row from a Gradient v2.6 JSON file. Represents one possession event with embedded tracking data.

| Field | Type | Description |
|-------|------|-------------|
| `game_id` | `int` | Game identifier (alias: `GAME_ID`) |
| `competition_id` | `int` | Competition identifier |
| `competition_name` | `str` | e.g. "Premier League" |
| `season` | `str` | e.g. "2025-2026" |
| `game_event_id` | `int` | Game event identifier |
| `possession_event_id` | `float \| None` | Possession event identifier |
| `start_time` | `float` | Event start (video-relative seconds) |
| `end_time` | `float \| None` | Event end |
| `duration` | `float` | Duration in seconds |
| `event_time` | `float` | When the event took place |
| `sequence` | `float \| None` | Possession sequence number |
| `video_url` | `str` | Link to video clip |
| `frame_num` | `int` | Frame number |
| `updated_at` | `int` | Last update timestamp |
| `game_events` | `dict \| None` | Game event info (raw dict) |
| `initial_touch` | `dict \| None` | First touch info (raw dict) |
| `possession_events` | `dict \| None` | Possession event details (raw dict) |
| `fouls` | `dict \| None` | Foul info (raw dict) |
| `grades` | `dict \| None` | Player grades (raw dict) |
| `stadium_metadata` | `dict \| None` | Stadium/pitch info (raw dict) |
| `home_players` | `list[GradientPlayer]` | Home team tracking snapshot |
| `away_players` | `list[GradientPlayer]` | Away team tracking snapshot |
| `ball` | `list[GradientBall]` | Ball tracking snapshot |

### GradientPlayer

| Field | Type | Description |
|-------|------|-------------|
| `player_id` | `int` | Player identifier |
| `jersey_num` | `int` | Jersey number |
| `x` | `float` | X coordinate |
| `y` | `float` | Y coordinate |
| `speed` | `float \| None` | Speed |
| `position` | `str \| None` | Position code |
| `confidence` | `str \| None` | Tracking confidence |
| `visibility` | `str \| None` | Visibility status |

### GradientBall

| Field | Type | Description |
|-------|------|-------------|
| `x` | `float \| None` | X coordinate |
| `y` | `float \| None` | Y coordinate |
| `z` | `float \| None` | Z coordinate (height) |
| `visibility` | `str \| None` | Visibility status |

### GradientGameEventType

`1KO`, `2KO`, `3KO`, `4KO`, `END`, `FOUL`, `G` (woodwork), `OFF`, `ON`, `OTB`, `OUT`, `SUB`

### GradientPossessionEventType

`BC` (Ball Carry), `CH` (Challenge), `CL` (Clearance), `CR` (Cross), `FO` (Foul), `IT` (Interception), `PA` (Pass), `RE` (Rebound), `SH` (Shot), `TC` (Touch Control)

---

## Joining Events and Tracking Data

Gradient v2.6 event rows and PFF tracking frames share three join keys:

| Join key | Event field (`GradientEventRow`) | Tracking field (`PFF_Frame`) | Relationship |
|----------|--------------------------------|------------------------------|-------------|
| Game event ID | `game_event_id` (`GAME_EVENT_ID`) | `event_id` (`game_event_id`) | 1 event -> ~42 frames (avg) |
| Possession event ID | `possession_event_id` (`POSSESSION_EVENT_ID`) | `possession_id` (`possession_event_id`) | 1 possession -> tracking frames with that possession |
| Frame number | `frame_num` (`FRAME_NUM`) | `frame_id` (`frameNum`) | 1:1 -- exact frame at event time |

**Key observations:**
- `frame_num` / `frame_id` is the most precise join -- 1:1 mapping, ~100% coverage
- `game_event_id` gives you all tracking frames within an event's time window (start_frame to end_frame)
- `possession_event_id` has 100% coverage between events and tracking

See the [Usage Guide](usage-guide.md#joining-events-with-tracking-data) for code examples.

---

## Tracking Data Models

### PFF_Frame

A single video frame with all player and ball positions.

| Field | Type | Description |
|-------|------|-------------|
| `frame_id` | `int` | Frame identifier (alias: `frameNum`) |
| `period` | `int` | Match period |
| `match_id` | `int \| None` | Match ID (alias: `gameRefId`) |
| `elapsed_seconds` | `float` | Elapsed time in period (alias: `periodElapsedTime`) |
| `game_clock_seconds` | `float` | Game clock time (alias: `periodGameClockTime`) |
| `video_time_milli` | `float` | Video timestamp in milliseconds (alias: `videoTimeMs`) |
| `home_players` | `list[Frame_Player] \| None` | Home team positions (alias: `homePlayers`) |
| `away_players` | `list[Frame_Player] \| None` | Away team positions (alias: `awayPlayers`) |
| `home_players_with_kalman` | `list[Frame_Player] \| None` | Smoothed home positions (alias: `homePlayersSmoothed`) |
| `away_players_with_kalman` | `list[Frame_Player] \| None` | Smoothed away positions (alias: `awayPlayersSmoothed`) |
| `ball` | `list[Ball] \| None` | Ball position(s) (alias: `balls`) |
| `ball_with_kalman` | `Ball \| None` | Smoothed ball position (alias: `ballsSmoothed`) |
| `event` | `Frame_Event \| None` | Linked game event (alias: `game_event`) |
| `event_id` | `int \| None` | Game event ID (alias: `game_event_id`) |
| `possession` | `Frame_Possession \| None` | Linked possession event (alias: `possession_event`) |
| `possession_id` | `int \| None` | Possession event ID (alias: `possession_event_id`) |
| `home_ball` | `int \| None` | Home team has ball |
| `generated_time` | `datetime \| None` | Frame generation timestamp (alias: `generatedTime`) |
| `sequence` | `int \| None` | Sequence number |
| `version` | `str \| None` | Data version |

### Frame_Player

| Field | Type | Description |
|-------|------|-------------|
| `shirt` | `int` | Jersey number (alias: `jerseyNum`) |
| `shirt_confidence` | `JerseyConfidence` | HIGH, MEDIUM, LOW |
| `visibility` | `Visibility` | VISIBLE, ESTIMATED |
| `x` | `float` | X coordinate |
| `y` | `float` | Y coordinate |

### Ball

| Field | Type | Description |
|-------|------|-------------|
| `visibility` | `Visibility` | VISIBLE, ESTIMATED |
| `x` | `float \| None` | X coordinate |
| `y` | `float \| None` | Y coordinate |
| `z` | `float \| None` | Z coordinate (height) |

### Frame_Event

Event metadata linked to a frame.

| Field | Type | Description |
|-------|------|-------------|
| `game_id` | `int` | Game ID |
| `game_event_type` | `PFF_Frame_GameEventType` | Event type |
| `competition_id` | `int \| None` | Competition ID |
| `season` | `str \| int \| None` | Season |
| `clock` | `str \| None` | Formatted game clock (alias: `formatted_game_clock`) |
| `player_id` | `int \| None` | Player ID |
| `team_id` | `int \| None` | Team ID |
| `setpiece_type` | `SetPieceType \| None` | Set piece type |
| `touches` | `int \| None` | Number of on-the-ball touches |
| `touches_in_box` | `int \| None` | On-the-ball touches in the box |
| `start_time_seconds` | `float` | Event start (alias: `start_time`) |
| `end_time_seconds` | `float \| None` | Event end (alias: `end_time`) |
| `duration_seconds` | `float \| None` | Duration (alias: `duration`) |
| `video_missing` | `bool \| None` | Whether video is missing |
| `start_frame` | `int` | Start frame |
| `end_frame` | `int \| None` | End frame |
| `inserted_at` | `datetime \| None` | Record insertion timestamp |
| `updated_at` | `datetime \| None` | Record update timestamp |

### Frame_Possession

Possession event metadata linked to a frame.

| Field | Type | Description |
|-------|------|-------------|
| `game_id` | `int` | Game ID |
| `game_event_id` | `int` | Parent game event ID |
| `possession_event_type` | `Frame_PossessionEventType` | BALL_CARRY, PASS, SHOT, etc. |
| `start_time_seconds` | `float` | Possession start (alias: `start_time`) |
| `end_time_seconds` | `float \| None` | Possession end (alias: `end_time`) |
| `duration_seconds` | `float \| None` | Duration (alias: `duration`) |
| `game_clock` | `str \| None` | Formatted game clock (alias: `formatted_game_clock`) |
| `start_frame` | `int` | Start frame |
| `end_frame` | `int \| None` | End frame |
| `inserted_at` | `datetime \| None` | Record insertion timestamp |
| `updated_at` | `datetime \| None` | Record update timestamp |

---

## Roster Models

### PFF_Roster

A player entry in a match roster.

| Field | Type | Description |
|-------|------|-------------|
| `id` | `str \| None` | Roster entry ID |
| `game` | `dict \| None` | Game reference |
| `player` | `Player` | Player details |
| `positionGroupType` | `PositionGroupType` | Position classification |
| `shirtNumber` | `str \| int` | Jersey number |
| `started` | `bool \| None` | Whether the player started |
| `team` | `PFF_Team` | Team |

### Player

| Field | Type |
|-------|------|
| `id` | `str` |
| `firstName` | `str \| None` |
| `lastName` | `str \| None` |
| `nickname` | `str \| None` |
| `preferredFoot` | `str \| None` |
| `positionGroupType` | `PositionGroupType \| None` |
| `dob` | `str \| None` |
| `height` | `float \| None` |
| `weight` | `float \| None` |
| `gender` | `str \| None` |
| `nationality` | `Nation \| None` |
| `secondNationality` | `Nation \| None` |
| `countryOfBirth` | `Nation \| None` |

### PFF_Team

| Field | Type |
|-------|------|
| `id` | `str` |
| `name` | `str \| None` |
| `shortName` | `str \| None` |

### PositionGroupType

`AM`, `CF`, `CM`, `D`, `DM`, `F`, `GK`, `LB`, `LCB`, `LM`, `LW`, `LWB`, `M`, `MCB`, `RB`, `RCB`, `CB`, `RM`, `RW`, `RWB`

---

## Gandula-Level Models

### GandulaFrame

A pitch-standardized frame wrapping `PFF_Frame` with coordinate metadata.

| Field | Type | Description |
|-------|------|-------------|
| `frame` | `PFF_Frame` | The underlying frame |
| `pitch_center` | `GandulaPitchCoordinateCenter` | Coordinate origin |
| `pitch_size` | `GandulaPitchSize` | Pitch dimensions |

### AtomicSpadl

SPADL (Soccer Player Action Description Language) action representation.

| Field | Type | Description |
|-------|------|-------------|
| `match_id` | `int` | Match ID |
| `event_id` | `int` | Event ID |
| `period_id` | `int` | Period |
| `player_id` | `int` | Player ID |
| `team_id` | `int` | Team ID |
| `time_seconds` | `float` | Action time (> 0) |
| `x` | `float` | X coordinate (0-105) |
| `y` | `float` | Y coordinate (0-68) |
| `dx` | `float` | X displacement (-105 to 105) |
| `dy` | `float` | Y displacement (-68 to 68) |
| `action_type` | `SpadlAction` | Action classification |
| `bodypart` | `SpadlBodyPart` | Body part used |

**SpadlAction enum values:** PASS, CROSS, THROW_IN, FREEKICK_CROSSED, FREEKICK_SHORT, CORNER_CROSSED, CORNER_SHORT, TAKE_ON, FOUL, TACKLE, INTERCEPTION, SHOT, SHOT_PENALTY, SHOT_FREEKICK, KEEPER_SAVE, KEEPER_CLAIM, KEEPER_PUNCH, KEEPER_PICK_UP, CLEARANCE, BAD_TOUCH, NON_ACTION, DRIBBLE, GOALKICK, RECEIVAL, OUT, OFFSIDE, GOAL, OWN_GOAL, YELLOW_CARD, RED_CARD, CORNER, FREEKICK

---

## Coordinate Systems

### PFF Default
- **Origin:** Centre spot
- **X range:** -52.5 to 52.5 (meters)
- **Y range:** -34 to 34 (meters)

### Available Transformations

| Center | Origin Point |
|--------|-------------|
| `CENTRE_SPOT` | Pitch center (0,0) |
| `BOTTOM_LEFT_CORNER` | Bottom-left (0,0 at corner) |
| `TOP_LEFT_CORNER` | Top-left (0,0 at corner, y inverted) |

| Size Type | Dimensions |
|-----------|-----------|
| `METERS` | 105 x 68 |
| `YARDS` | 115 x 74 |
| `CUSTOM` | User-defined x_axis, y_axis |
