# API Reference

## Top-Level Exports

All primary functions are available directly from the `gandula` package:

```python
import gandula
```

---

## S3 Tracking Data

### `gandula.list_s3_matches`

```python
list_s3_matches(
    competition_id: str | int,
    season: str,
    *,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None
) -> list[str]
```

Lists available tracking data files on S3 for a competition/season. Returns S3 keys for `.jsonl` and `.bz2` files.

### `gandula.get_s3_frames`

```python
get_s3_frames(
    key: str,
    *,
    record_filter: Callable | None = None,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None
) -> list[PFF_Frame]
```

Streams a tracking data file from S3, parses JSONL/BZ2, and validates each frame into a `PFF_Frame` object.

### `gandula.get_s3_match_metadata`

```python
get_s3_match_metadata(
    competition_id: str | int,
    season: str,
    match_id: str | int,
    *,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None
) -> dict
```

Loads match metadata from S3 (`metadata.json`). Returns a dictionary with match info (teams, competition, date, etc.).

### `gandula.get_s3_rosters`

```python
get_s3_rosters(
    competition_id: str | int,
    season: str,
    match_id: str | int,
    *,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None
) -> list[dict]
```

Loads match rosters from S3 (`rosters.json`). Returns a list of player roster entries.

### `gandula.download_tracking_data`

```python
download_tracking_data(
    competition_id: str | int,
    season: str,
    out_dir: str,
    *,
    max_workers: int | None = None,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None
) -> tuple[list[str], list[tuple[str, str]]]
```

Downloads all tracking data for a competition/season from S3. Returns `(successful_keys, failed_keys_with_errors)`.

---

## Gradient v2.6 Event Data

### `gandula.get_events`

```python
get_events(
    file_path: str | Path,
    *,
    match_id: int | None = None
) -> list[GradientEventRow]
```

Loads Gradient v2.6 event data from a local JSON file. Each row is validated into a `GradientEventRow` Pydantic model.

**Parameters:**
- `file_path` — Path to the JSON file (e.g. `41177.json`).
- `match_id` — Optional filter to keep only events matching this `GAME_ID`.

### `gandula.gradient_events_to_dataframe`

```python
gradient_events_to_dataframe(
    events: list[GradientEventRow],
    *,
    include_tracking: bool = False
) -> DataFrame
```

Converts validated Gradient events into a flat pandas DataFrame. Nested dicts (`game_events`, `possession_events`, etc.) are flattened with `_` separator. All column names are lowercased.

**Parameters:**
- `events` — List of `GradientEventRow` objects from `get_events()`.
- `include_tracking` — If `True`, keeps `home_players`, `away_players`, and `ball` as list columns. Otherwise they are excluded (default).

---

## Tracking Frames

### `gandula.get_frames`

```python
get_frames(
    data_dir: str,
    match_id: int,
    *,
    competition_name: str | None = None,
    season: str | None = None,
    record_filter: Callable | None = None
) -> list[PFF_Frame]
```

Loads tracking frames from local JSONL or BZ2 files.

**Parameters:**
- `data_dir` — Root directory containing tracking data files.
- `match_id` — The match ID to load.
- `competition_name` — Subdirectory for competition (optional).
- `season` — Subdirectory for season (optional).
- `record_filter` — A callable `(dict) -> bool` to filter frames during loading.

---

## Pitch Control

### `compute_pitch_control_from_frames`

```python
from gandula.utils import compute_pitch_control_from_frames

compute_pitch_control_from_frames(
    frames: list[PFF_Frame],
    *,
    attacking_team: 'home' | 'away',
    config: PitchControlConfig | None = None,
    start_frame: int | None = None,
    end_frame: int | None = None,
    period: int | None = None,
    smoothed: bool = False
) -> PitchControlResult
```

Computes pitch control directly from PFF frame objects. Handles coordinate conversion automatically.

### `compute_pitch_control_from_dataframe`

```python
from gandula.utils import compute_pitch_control_from_dataframe

compute_pitch_control_from_dataframe(
    data: DataFrame,
    *,
    attacking_team: 'home' | 'away',
    config: PitchControlConfig | None = None
) -> PitchControlResult
```

Computes pitch control from a pre-normalized DataFrame (bottom-left origin coordinates expected).

### `PitchControlConfig`

```python
from gandula.utils import PitchControlConfig

config = PitchControlConfig(
    grid_x=50,                          # Grid resolution X
    grid_y=30,                          # Grid resolution Y
    reaction_time=0.7,                  # Player reaction time (seconds)
    max_player_speed=5.0,               # Max player speed (m/s)
    average_ball_speed=15.0,            # Ball speed (m/s)
    sigma=4.029665766610985,            # Steepness parameter
    lamb=4.3,                           # Lambda parameter
    gauss_points=50,                    # Quadrature points
    fps_hint=10.0,                      # Expected frames per second for velocity estimation
    torch_device='cpu',                 # 'cpu', 'cuda', or 'mps'
)
```

### `PitchControlService`

```python
from gandula.utils import PitchControlService

service = PitchControlService(config=config)
result = service.compute_from_frames(frames, attacking_team='home', period=1)
result = service.compute_window(normalized_df, attacking_team='home')
service = service.with_device('cuda')  # Returns new service with different device
```

### `PitchControlResult`

```python
result.team_control            # Torch tensor (T, grid_x, grid_y)
result.team_control_numpy()    # NumPy array (T, grid_x, grid_y)
result.player_control          # Per-player control tensor
result.frame_ids               # list[int]
result.attacking_player_ids    # list[str]
result.defending_player_ids    # list[str]
result.x_grid                  # Grid x coordinates
result.y_grid                  # Grid y coordinates
```

### Visualization

```python
from gandula.visualization.pitch_control import view_pitch_control, view_pitch_control_with_frame

# Heatmap only
view_pitch_control(result, frame_index=0)

# Heatmap with player overlay
view_pitch_control_with_frame(pff_frame, result, frame_index=0)
```

`PitchControlResult` also works with `gandula.view()`:

```python
gandula.view(result, frame_index=0)
```

---

## Export

### `gandula.export`

```python
export(
    frames: list[PFF_Frame] | PFF_Frame,
    *,
    fmt: ExportFormat,
    fps: int = 25,
    filename: str | None = None,
    **kwargs
) -> str | list[str] | tuple[DataFrame, DataFrame]
```

Exports frames to the specified format.

**Parameters:**
- `fmt` — `'gif'`, `'png'`, `'mp4'`, or `'dataframe'`
- `fps` — Frames per second for GIF/MP4 export (default: 25)
- `filename` — Output filename (required for `'gif'`, `'png'`, `'mp4'`)

**Returns:**
- `'gif'` — URI path to the GIF file
- `'png'` — List of URI paths to PNG files
- `'mp4'` — URI path to the MP4 file
- `'dataframe'` — Tuple of `(metadata_df, players_ball_df)`

### `gandula.pff_frames_to_dataframe`

```python
pff_frames_to_dataframe(
    frames: list[PFF_Frame] | list[GandulaFrame],
    **kwargs
) -> tuple[DataFrame, DataFrame]
```

Converts frames into two pandas DataFrames:
- **metadata_df** — Frame-level info: frame_id, period, elapsed time, event/possession references
- **players_ball_df** — Per-frame player positions (x, y, shirt, team) and ball position (x, y, z)

### `gandula.gradient_events_to_dataframe`

See [Gradient v2.6 Event Data](#gradient-v26-event-data) above.

### `pff_rosters_to_dataframe`

```python
from gandula.export import pff_rosters_to_dataframe

pff_rosters_to_dataframe(
    rosters: list[PFF_Roster | dict] | None
) -> DataFrame
```

Converts match rosters into a normalized player DataFrame with columns for player info, team, position, nationality, etc.

---

## Visualization

### `gandula.view`

```python
view(objs, **kwargs)
```

Universal visualization function. Dispatches based on input type:

| Input Type | Output |
|------------|--------|
| `PFF_Frame` (single) | Pitch plot with players and ball |
| `PFF_Frame` (list) | Animated pitch sequence |
| `GandulaFrame` (single/list) | Same as above with pitch standards |
| `PitchControlResult` | Pitch control heatmap |
| Pydantic model | `model_dump()` |

**Common kwargs for frame visualization:**
- `home_colors` — Tuple of `(fill, text)` colors for home team
- `away_colors` — Tuple of `(fill, text)` colors for away team
- `ball_color` — Ball marker color
- `fps` — Animation speed (default: 25)

### `gandula.video`

```python
video(
    event: GradientEventRow,
    *,
    width: int | str = '80%',
    height: int | str = 500
) -> None
```

Displays the video for a Gradient event in Jupyter/IPython using the event's `video_url` field.

**Parameters:**
- `event` — A `GradientEventRow` with a `video_url`.
- `width` — Iframe width (default: `'80%'`).
- `height` — Iframe height in pixels (default: `500`).

---

## Pitch Coordinate Transformation

### `gandula.utils.gandula_enhancer.change_pitch_standards`

```python
change_pitch_standards(
    frames: list[PFF_Frame] | tuple[DataFrame, DataFrame],
    pitch_size: GandulaPitchSize,
    pitch_center: GandulaPitchCoordinateCenter
) -> list[GandulaFrame] | tuple[DataFrame, DataFrame]
```

Converts frame coordinates to a different pitch standard. Works with both `PFF_Frame` lists and DataFrames.

**Coordinate centers:**
- `GandulaPitchCoordinateCenter.CENTRE_SPOT` — Origin at pitch center (PFF default)
- `GandulaPitchCoordinateCenter.BOTTOM_LEFT_CORNER` — Origin at bottom-left
- `GandulaPitchCoordinateCenter.TOP_LEFT_CORNER` — Origin at top-left

**Pitch sizes:**
```python
from gandula.schemas.pitch.schema import PredefinedGandulaPitchSize, CustomGandulaPitchSize

# Meters (105 x 68)
meters = PredefinedGandulaPitchSize(type='meters')

# Yards (115 x 74)
yards = PredefinedGandulaPitchSize(type='yards')

# Custom
custom = CustomGandulaPitchSize(type='custom', x_axis=100, y_axis=100)
```

---

## Feature Engineering

### `gandula.features.pff.speed.add_players_speed`

```python
add_players_speed(frames_df: DataFrame) -> DataFrame
```

Computes per-player velocity (`vx`, `vy`), acceleration (`ax`, `ay`), and `speed` from positional data. Groups by period, team, and shirt number.

### `gandula.features.pff.speed.add_ball_speed`

```python
add_ball_speed(frames_df: DataFrame) -> DataFrame
```

Computes ball velocity (`ball_vx`, `ball_vy`, `ball_vz`), acceleration, and speed. Groups by period.

---

## Local File Loading

Available via `gandula.providers.pff.local.loader`:

```python
from gandula.providers.pff.local import loader
```

| Function | Description |
|----------|-------------|
| `loader.read_json(path)` | Load a JSON file (returns `list[dict]`) |
| `loader.read_jsonl(path, *, record_filter)` | Stream JSONL file with optional filter |
| `loader.read_bz2(path, *, record_filter)` | Decompress and stream BZ2 file |
| `loader.read_csv(path)` | Load CSV as DataFrame |
| `loader.read_pickle(path)` | Load pickle as DataFrame |
| `loader.find_available_matches(data_dir, ...)` | List available match files in directory |

---

## Data Models

See [Data Models Reference](data-models.md) for full details on all Pydantic models.
