# Gandula Architecture

## Overview

Gandula is a Python library for handling football (soccer) data from PFF (Pro Football Focus / Gradient Sports). It provides tools for fetching, validating, transforming, and visualizing both **event data** (passes, shots, fouls, etc.) and **tracking data** (player/ball positions per frame).

## Data Pipeline

```
               Data Sources
              /            \
        S3 Bucket       Local Files
      (boto3 client)  (JSON/JSONL/BZ2)
            |                |
            v                v
       Raw Responses      Raw Dicts
              \            /
               v          v
         Pydantic Validation
         (GradientEventRow,
          PFF_Frame, etc.)
                  |
                  v
        Enhancement / Transformation
        ├── Pitch Standardization
        │   (GandulaFrame with
        │    custom coordinate systems)
        └── Feature Engineering
            (speed, acceleration)
                  |
                  v
          Export / Visualization
          ├── DataFrames (pandas)
          ├── Images (PNG/GIF)
          ├── Video (HLS in notebooks)
          └── Typed Objects (Pydantic)
```

## Module Structure

```
gandula/
├── api/                    # High-level public API
│   └── match.py            # Match, frame, and S3 retrieval
│
├── providers/pff/          # PFF-specific implementation
│   ├── s3/                 # S3 tracking data access
│   │   ├── client.py       # boto3 client creation, credentials
│   │   └── loader.py       # Stream, download, list S3 objects
│   ├── local/
│   │   ├── loader.py       # File I/O (JSON, JSONL, BZ2, CSV, pickle)
│   │   └── event_loader.py # Gradient v2.6 event JSON loader
│   └── schema/
│       ├── gradient_event.py # Gradient v2.6 event models (GradientEventRow, etc.)
│       ├── roster.py       # Roster and player models (PFF_Roster, Player, PFF_Team)
│       └── tracking.py     # Tracking/frame data models
│
├── schemas/                # Gandula-level schemas
│   ├── atomic_spadl/       # SPADL action representation
│   │   ├── schema.py       # AtomicSpadl model
│   │   └── types.py        # SpadlAction, SpadlBodyPart enums
│   ├── frame/
│   │   └── schema.py       # GandulaFrame (pitch-standardized frame)
│   └── pitch/
│       ├── enums.py        # Coordinate center, pitch size type enums
│       ├── schema.py       # Pitch size models
│       └── utils.py        # Coordinate transformation functions
│
├── utils/                  # Data transformation utilities
│   ├── helpers.py          # General helpers (flatten_dict)
│   ├── gandula_enhancer.py # Pitch standard conversion
│   ├── pff_tracking_enhancer.py # Frame coordinate transformation
│   └── pitch_control/      # Pitch control computation
│       ├── adapters.py     # PFF frame -> pitch control DataFrame conversion
│       ├── config.py       # PitchControlConfig defaults
│       ├── engine.py       # PyTorch-based pitch control engine
│       ├── service.py      # High-level PitchControlService
│       └── types.py        # PitchControlResult and related types
│
├── export/                 # Data export
│   ├── dataframe.py        # Frames -> pandas DataFrames
│   ├── gif.py              # Frames -> animated GIF
│   ├── mp4.py              # Frames -> MP4 video
│   └── png.py              # Frames -> PNG images
│
├── features/               # Feature engineering
│   └── pff/
│       └── speed.py        # Player/ball speed calculations
│
├── visualization/          # Plotting and display
│   ├── pitch.py            # Pitch drawing (mplsoccer)
│   ├── frame.py            # Frame visualization (players + ball)
│   ├── pitch_control.py    # Pitch control heatmap visualization
│   ├── video.py            # Video playback in notebooks
│   └── view.py             # Universal view() dispatcher
│
├── config.py               # Constants (pitch dimensions, video buffer)
├── jinja.py                # Jinja2 template environment
└── logging.py              # Structured logging setup
```

## Key Design Decisions

### 1. Provider Abstraction
All PFF-specific code lives under `providers/pff/`. The high-level `api/` module wraps provider calls, making it possible to add new data providers in the future.

### 2. Pydantic Validation
All data entering the system is validated through Pydantic models. This catches schema mismatches early and provides type safety throughout the pipeline.

### 3. Coordinate System Flexibility
Gandula supports multiple pitch coordinate systems:
- **Center types:** `CENTRE_SPOT`, `BOTTOM_LEFT_CORNER`, `TOP_LEFT_CORNER`
- **Pitch sizes:** Meters (105x68), Yards (115x74), or custom dimensions
- The `transform_coordinates()` function handles all conversions.

### 4. Dual Data Model
- **PFF_Frame** — raw tracking data from PFF
- **GandulaFrame** — pitch-standardized wrapper with coordinate metadata

### 5. Event–Tracking Joining
Events and tracking frames are joined explicitly via shared keys (`frame_id`/`frame_num`, `event_id`/`game_event_id`, `possession_id`/`possession_event_id`) rather than at load time. This keeps loading fast and gives users full control over the join strategy.

## Environment & Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `PFF_AWS_ACCESS_KEY_ID` | AWS access key for S3 | Falls back to `AWS_ACCESS_KEY_ID` |
| `PFF_AWS_SECRET_ACCESS_KEY` | AWS secret key for S3 | Falls back to `AWS_SECRET_ACCESS_KEY` |

## Data Formats

### Event Data (Gradient v2.6)
- **Source:** Local JSON files (`{game_id}.json`)
- **Model:** `GradientEventRow` with typed top-level fields, raw nested dicts, and typed tracking snapshots (`GradientPlayer`, `GradientBall`)
- **Loader:** `event_loader.load_gradient_events()` → `api.match.get_events()` → `export.dataframe.gradient_events_to_dataframe()`

### Tracking Data
- **Source:** S3 bucket or local JSONL/BZ2 files (streamed for memory efficiency)
- **Model:** `PFF_Frame` with `Frame_Player`, `Ball`, `Frame_Event`, `Frame_Possession`
- **Features:** Raw positions + Kalman-filtered (smoothed) positions
