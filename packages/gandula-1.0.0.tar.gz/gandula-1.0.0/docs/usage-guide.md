# Usage Guide

## Setup

### 1. Set your AWS credentials

Create a `.env` file in the project root:

```bash
PFF_AWS_ACCESS_KEY_ID='YOUR_AWS_ACCESS_KEY'
PFF_AWS_SECRET_ACCESS_KEY='YOUR_AWS_SECRET_KEY'
```

Then load it in your shell before running code:

```bash
export $(cat .env | xargs)
```

Or pass credentials directly to functions:

```python
gandula.list_s3_matches('1', '2024-2025', aws_access_key_id='...', aws_secret_access_key='...')
```

---

## Working with S3 Tracking Data

### Browse available matches

```python
import gandula

# List tracking files for a competition/season
matches = gandula.list_s3_matches(competition_id=1, season='2024-2025')
# ['1/2024-2025/111/111.jsonl.bz2', '1/2024-2025/222/222.jsonl', ...]
```

### Load frames from S3

```python
frames = gandula.get_s3_frames(matches[0])
```

### Download tracking data to disk

```python
successes, failures = gandula.download_tracking_data(
    competition_id=1,
    season='2024-2025',
    out_dir='/data/tracking/',
    max_workers=4
)
```

---

## Working with Event Data (Gradient v2.6)

### Load events

```python
# Load from a Gradient v2.6 JSON file
events = gandula.get_events('41177.json')

# Optionally filter by game ID
events = gandula.get_events('41177.json', match_id=41177)
```

### Explore events

```python
e = events[0]
print(e.game_id, e.competition_name, e.season)
print(e.video_url)

# Nested dicts (raw, untyped)
print(e.game_events['GAME_EVENT_TYPE'])
print(e.possession_events['POSSESSION_EVENT_TYPE'])

# Embedded tracking snapshot
print(f'Home players: {len(e.home_players)}, Away: {len(e.away_players)}')
print(e.home_players[0])  # GradientPlayer with player_id, jersey_num, x, y, speed, ...
```

### Filter events

```python
from gandula.providers.pff.schema.gradient_event import GradientPossessionEventType

shots = [
    e for e in events
    if e.possession_events
    and e.possession_events.get('POSSESSION_EVENT_TYPE') == GradientPossessionEventType.SHOT
]
```

### Convert to DataFrame

```python
df = gandula.gradient_events_to_dataframe(events)

# Include tracking as nested list columns
df_with_tracking = gandula.gradient_events_to_dataframe(events, include_tracking=True)
```

---

## Joining Events with Tracking Data

Gradient v2.6 events and S3 tracking frames share three join keys:

| Join key | Event field | Tracking field | Cardinality | Overlap |
|----------|-------------|----------------|-------------|---------|
| Game event ID | `GAME_EVENT_ID` | `frame.event_id` | 1 event → many frames (avg ~42) | ~92% |
| Possession event ID | `POSSESSION_EVENT_ID` | `frame.possession_id` | 1 possession → ~1 frame with possession data | 100% |
| Frame number | `FRAME_NUM` | `frame.frame_id` | 1:1 | ~100% |

### Which key to use

- **Enrich each tracking frame with event context** — join on `game_event_id`. Each event spans many frames (the window between `event.start_frame` and `event.end_frame`), so you get the full tracking sequence for each event.
- **Get the exact tracking state at each event** — join on `frame_num` = `frame_id`. This is a 1:1 match giving you the precise player/ball positions at the moment the event was recorded.
- **Match possession-level data** — join on `possession_event_id`. 100% coverage, links each possession action to the tracking frame(s) that carry its metadata.

### Example: merge in pandas

```python
import gandula

# Load both sources
events = gandula.get_events('41177.json')
frames = gandula.get_s3_frames('1/2025-2026/41177/41177.jsonl.bz2')

# Convert to DataFrames
events_df = gandula.gradient_events_to_dataframe(events)
metadata_df, players_ball_df = gandula.pff_frames_to_dataframe(frames)

# 1:1 join — exact tracking state at each event
merged = events_df.merge(
    metadata_df,
    left_on='frame_num',
    right_on='frame_id',
    how='left',
)

# 1:many join — all tracking frames for each event
merged_all = metadata_df.merge(
    events_df[['game_event_id', 'video_url', 'possession_events_possession_event_type']],
    left_on='event_id',
    right_on='game_event_id',
    how='left',
)
```

### Example: get tracking frames for a specific event

```python
# Find a goal event
goal = next(
    e for e in events
    if e.possession_events
    and e.possession_events.get('SHOT_OUTCOME_TYPE') == 'G'
)

# Get all tracking frames for that game event
goal_tracking = [
    f for f in frames
    if f.event_id == goal.game_event_id
]
print(f'Frames for this goal event: {len(goal_tracking)}')

# Or get the exact frame at the event moment
frame_at_event = next(f for f in frames if f.frame_id == goal.frame_num)
gandula.view(frame_at_event)
```

### Watch event video (Jupyter only)

```python
# Display the video for any event that has a video_url
gandula.video(events[0])

# Adjust iframe dimensions
gandula.video(events[0], width='100%', height=600)
```

---

## Working with Tracking Data (Local Files)

### Load frames

```python
# Simple: all files in a flat directory
frames = gandula.get_frames(
    data_dir='/path/to/tracking/',
    match_id=4621
)

# With competition/season subdirectory structure
frames = gandula.get_frames(
    data_dir='/data/',
    match_id=4621,
    competition_name='Premier League',
    season='2022-23'
)
# Looks for: /data/Premier League/2022-23/4621.jsonl (or .bz2)
```

### Filter frames during loading

```python
# Only load frames 10000 to 10250
def my_filter(record: dict) -> bool:
    fid = record.get('frameId', 0)
    return 10000 <= fid <= 10250

frames = gandula.get_frames(
    data_dir='/path/to/tracking/',
    match_id=4621,
    record_filter=my_filter
)
```

### Visualize frames

```python
# Single frame
gandula.view(frames[0])

# Animated sequence (returns HTML animation in Jupyter)
gandula.view(
    frames[100:200],
    home_colors=('#FFFFFF', '#000000'),
    away_colors=('#FF0000', '#FFFFFF'),
    ball_color='#FFD700'
)
```

---

## Exporting Data

### To pandas DataFrames

```python
metadata_df, players_ball_df = gandula.export(frames, fmt='dataframe')

# Or directly:
metadata_df, players_ball_df = gandula.pff_frames_to_dataframe(frames)
```

**metadata_df** contains: frame_id, period, elapsed_seconds, game_clock_seconds, event info, possession info.

**players_ball_df** contains: per-frame rows with home/away player positions (x, y, shirt), ball position (x, y, z), confidence, visibility.

### To GIF

```python
path = gandula.export(
    frames[100:200],
    fmt='gif',
    filename='play_animation',
    fps=25
)
# Saves to play_animation.gif
```

### To PNG

```python
paths = gandula.export(
    frames[0],
    fmt='png',
    filename='frame_snapshot'
)
# Saves individual PNG files
```

---

## Pitch Coordinate Transformation

PFF data uses centre-spot origin with meters (x: -52.5 to 52.5, y: -34 to 34). You can convert to other systems.

### With frame objects

```python
from gandula.utils.gandula_enhancer import change_pitch_standards
from gandula.schemas.pitch.schema import PredefinedGandulaPitchSize, CustomGandulaPitchSize
from gandula.schemas.pitch.enums import GandulaPitchCoordinateCenter

# Convert to bottom-left origin, meters
gandula_frames = change_pitch_standards(
    frames,
    pitch_size=PredefinedGandulaPitchSize(type='meters'),
    pitch_center=GandulaPitchCoordinateCenter.BOTTOM_LEFT_CORNER
)
# Coordinates now: x (0 to 105), y (0 to 68)

# Custom 100x100 pitch
gandula_frames = change_pitch_standards(
    frames,
    pitch_size=CustomGandulaPitchSize(type='custom', x_axis=100, y_axis=100),
    pitch_center=GandulaPitchCoordinateCenter.TOP_LEFT_CORNER
)
```

### With DataFrames

```python
metadata_df, players_df = gandula.pff_frames_to_dataframe(frames)

new_meta, new_players = change_pitch_standards(
    (metadata_df, players_df),
    pitch_size=PredefinedGandulaPitchSize(type='meters'),
    pitch_center=GandulaPitchCoordinateCenter.BOTTOM_LEFT_CORNER
)
```

---

## Feature Engineering

### Player speed

```python
from gandula.features.pff.speed import add_players_speed, add_ball_speed

_, players_df = gandula.pff_frames_to_dataframe(frames)

# Adds columns: vx, vy, ax, ay, speed
players_df = add_players_speed(players_df)

# Adds columns: ball_vx, ball_vy, ball_vz, ball_ax, ball_ay, ball_az, ball_speed
players_df = add_ball_speed(players_df)
```

---

## Notebooks

The `notebooks/` directory contains working examples:

| Notebook | What it shows |
|----------|---------------|
| `pff-load-from-json.ipynb` | Load and explore Gradient v2.6 event data |
| `pff-data-transformation.ipynb` | Transform events to DataFrames, filter, group |
| `pff-search.ipynb` | Search events by type, extract video URLs |
| `pff-tracking.ipynb` | Load, visualize, and export S3 tracking data |
| `pff-defensive-line-height.ipynb` | Defensive line metric from tracking data |
| `pff-events-withing-tracking-to-pandas.ipynb` | Merge events and tracking in pandas |
| `s3_tracking_and_pitch_control.ipynb` | S3 tracking data loading and pitch control computation |
| `walkthrough.ipynb` | End-to-end walkthrough of gandula features |
| `frames_to_dataframes.ipynb` | Converting frames to pandas DataFrames |
| `visualizing_data.ipynb` | Pitch plots, animations, GIF/PNG export, video playback |
| `change_pitch_standards.ipynb` | Coordinate system transformations |
| `features.ipynb` | Speed/acceleration feature extraction |
| `generate_shot_frames_json.ipynb` | Batch processing all matches for shot frames |
| `xG_pt.ipynb` | Building an xG model (angle + distance) |
| `xG_pt_ver_2.ipynb` | Refined xG model (distance-based) |
