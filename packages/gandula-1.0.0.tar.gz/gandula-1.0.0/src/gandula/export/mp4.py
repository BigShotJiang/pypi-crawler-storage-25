"""Exports sequences of frames as mp4 videos."""

import io
from pathlib import Path

import imageio
from matplotlib.pyplot import close, savefig

from ..providers.pff.schema.tracking import PFF_Frame
from ..visualization.frame import view_pff_frame


def _resolve_output_path(filename: str) -> Path:
    output_path = Path(filename)
    if output_path.suffix.lower() != '.mp4':
        output_path = output_path.with_suffix('.mp4')

    output_path.parent.mkdir(parents=True, exist_ok=True)
    return output_path


def _open_mp4_writer(filepath: Path, fps: int):
    try:
        return imageio.get_writer(filepath.as_posix(), fps=fps, format='FFMPEG')
    except (ImportError, ModuleNotFoundError, ValueError) as exc:
        raise RuntimeError(
            'MP4 export requires an imageio video backend. '
            'Install it with: pip install "imageio[ffmpeg]"'
        ) from exc


def export_frame_sequence_as_mp4(
    frames: list[PFF_Frame], filename: str, fps=25, **kwargs
) -> str:
    """
    Exports a sequence of frames as an MP4 file.

    Args:
    ----------
    frames (list of dict): List of frames, each containing player and ball positions.
    filename : (str): Filename to save the MP4.
    fps (int): Frames per second for the MP4.
    **kwargs: Extra visualization options forwarded to `view_pff_frame`.
    """
    filepath = _resolve_output_path(filename)

    with _open_mp4_writer(filepath, fps=fps) as writer:
        for frame in frames:
            frame_plot_kwargs = kwargs.copy()
            ax = view_pff_frame(frame, **frame_plot_kwargs)
            fig = ax.get_figure()

            buf = io.BytesIO()
            savefig(buf, format='png')

            buf.seek(0)
            image = imageio.imread(buf)

            if image.ndim == 3 and image.shape[-1] == 4:
                image = image[:, :, :3]

            writer.append_data(image)

            close(fig)
            buf.close()

    return filepath.resolve().as_uri()
