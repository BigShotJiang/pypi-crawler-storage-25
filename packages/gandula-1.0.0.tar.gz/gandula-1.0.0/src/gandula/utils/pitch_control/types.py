"""Shared typed containers for pitch control."""

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class PitchControlTensors:
    """Prepared tensors for one computation window."""

    att_pos: Any
    def_pos: Any
    att_v: Any
    def_v: Any
    ball: Any
    frame_ids: list[int]
    att_player_ids: list[str]
    def_player_ids: list[str]


@dataclass(frozen=True)
class PitchControlResult:
    """Pitch control outputs for one window."""

    team_control: Any
    player_control: Any
    x_grid: Any
    y_grid: Any
    frame_ids: list[int]
    attacking_player_ids: list[str]
    defending_player_ids: list[str]

    def team_control_numpy(self) -> np.ndarray:
        """Returns team control tensor as a NumPy array [T, X, Y]."""
        if hasattr(self.team_control, 'detach'):
            return self.team_control.detach().cpu().numpy()
        return np.asarray(self.team_control)
