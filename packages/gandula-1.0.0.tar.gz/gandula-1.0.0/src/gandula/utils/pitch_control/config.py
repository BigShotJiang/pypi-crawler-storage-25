"""Configuration for pitch control computation."""

from dataclasses import dataclass


@dataclass(frozen=True)
class PitchControlConfig:
    """Numerical and grid parameters for pitch control."""

    grid_x: int = 50
    grid_y: int = 30
    reaction_time: float = 0.7
    max_player_speed: float = 5.0
    average_ball_speed: float = 15.0
    sigma: float = 4.029665766610985
    lamb: float = 4.3
    gauss_points: int = 50
    fps_hint: float = 10.0
    torch_device: str = 'cpu'
