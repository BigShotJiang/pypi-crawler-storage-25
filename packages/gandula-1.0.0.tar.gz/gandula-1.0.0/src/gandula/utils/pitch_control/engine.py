"""Numerical pitch control computation engine."""

import numpy as np
from pandas import DataFrame, to_numeric

from .config import PitchControlConfig
from .types import PitchControlResult, PitchControlTensors


def _require_torch():
    try:
        import torch
        import torch.nn.functional as torch_functional

        return torch, torch_functional
    except ImportError as exc:
        raise ImportError(
            'Pitch control requires PyTorch. Install torch in your environment.'
        ) from exc


def _to_tensor(values, *, torch, device: str, dtype):
    return torch.tensor(values, device=device, dtype=dtype)


def _compute_delta_t(
    elapsed_seconds: np.ndarray,
    *,
    fps_hint: float,
) -> np.ndarray:
    if elapsed_seconds.size < 2:
        raise ValueError('Too few samples to compute frame deltas.')

    delta_t = np.diff(elapsed_seconds).astype(float, copy=False)
    delta_t[delta_t <= 0] = np.nan
    fill = np.nanmedian(delta_t)
    if not np.isfinite(fill):
        fill = 1.0 / fps_hint
    return np.nan_to_num(delta_t, nan=fill)


def prepare_window_tensors(
    window_df: DataFrame,
    *,
    attacking_team: str,
    config: PitchControlConfig,
) -> PitchControlTensors:
    """Builds model tensors for one time window."""
    torch, _ = _require_torch()

    if attacking_team not in {'home', 'away'}:
        raise ValueError("attacking_team must be either 'home' or 'away'.")

    required_columns = {
        'frame_id',
        'team',
        'player_uid',
        'x',
        'y',
        'ball_x',
        'ball_y',
        'elapsed_seconds',
    }
    missing = required_columns.difference(window_df.columns)
    if missing:
        raise ValueError(f'Missing required columns: {sorted(missing)}')

    data = window_df.sort_values(['frame_id', 'player_uid']).copy()
    data['x'] = to_numeric(data['x'], errors='coerce')
    data['y'] = to_numeric(data['y'], errors='coerce')
    data['ball_x'] = to_numeric(data['ball_x'], errors='coerce')
    data['ball_y'] = to_numeric(data['ball_y'], errors='coerce')
    data['elapsed_seconds'] = to_numeric(data['elapsed_seconds'], errors='coerce')
    data = data.dropna(subset=['x', 'y']).copy()

    frames = sorted(data['frame_id'].unique().tolist())
    if len(frames) < 3:
        raise ValueError('Too few frames in window to compute velocities.')

    attacking = data[data['team'] == attacking_team].copy()
    defending = data[data['team'] != attacking_team].copy()

    if attacking.empty or defending.empty:
        raise ValueError('Both attacking and defending players are required.')

    def _build_stack(side: DataFrame):
        player_x = (
            side.pivot(index='frame_id', columns='player_uid', values='x')
            .reindex(index=frames)
            .sort_index()
            .fillna(-1000.0)
        )
        player_y = (
            side.pivot(index='frame_id', columns='player_uid', values='y')
            .reindex(index=frames)
            .sort_index()
            .fillna(-1000.0)
        )
        xy = np.stack([player_x.to_numpy(), player_y.to_numpy()], axis=2)
        xy = np.transpose(xy, (1, 0, 2))
        player_ids = [str(pid) for pid in player_x.columns]
        return xy, player_ids

    att_pos_np, att_ids = _build_stack(attacking)
    def_pos_np, def_ids = _build_stack(defending)

    ball = (
        data.drop_duplicates('frame_id')[['frame_id', 'ball_x', 'ball_y']]
        .set_index('frame_id')
        .reindex(frames)
        .sort_index()
        .ffill()
        .bfill()
    )
    ball_np = ball.to_numpy(dtype=float)

    elapsed = (
        data.drop_duplicates('frame_id')[['frame_id', 'elapsed_seconds']]
        .set_index('frame_id')
        .reindex(frames)
        .sort_index()['elapsed_seconds']
    )
    elapsed_np = elapsed.to_numpy(dtype=float)
    delta_t = _compute_delta_t(elapsed_np, fps_hint=config.fps_hint)

    att_v_np = (att_pos_np[:, 1:, :] - att_pos_np[:, :-1, :]) / delta_t[None, :, None]
    def_v_np = (def_pos_np[:, 1:, :] - def_pos_np[:, :-1, :]) / delta_t[None, :, None]

    dtype = torch.float32
    att_pos = _to_tensor(
        att_pos_np[:, 1:, None, None, :],
        torch=torch,
        device=config.torch_device,
        dtype=dtype,
    )
    def_pos = _to_tensor(
        def_pos_np[:, 1:, None, None, :],
        torch=torch,
        device=config.torch_device,
        dtype=dtype,
    )
    att_v = _to_tensor(
        att_v_np[:, :, None, None, :],
        torch=torch,
        device=config.torch_device,
        dtype=dtype,
    )
    def_v = _to_tensor(
        def_v_np[:, :, None, None, :],
        torch=torch,
        device=config.torch_device,
        dtype=dtype,
    )
    ball_t = _to_tensor(
        ball_np[1:][None, :, None, None, :],
        torch=torch,
        device=config.torch_device,
        dtype=dtype,
    )

    return PitchControlTensors(
        att_pos=att_pos,
        def_pos=def_pos,
        att_v=att_v,
        def_v=def_v,
        ball=ball_t,
        frame_ids=[int(frame_id) for frame_id in frames[1:]],
        att_player_ids=att_ids,
        def_player_ids=def_ids,
    )


def compute_pitch_control(
    tensors: PitchControlTensors,
    *,
    config: PitchControlConfig,
) -> PitchControlResult:
    """Computes team and per-player pitch control for a prepared window."""
    torch, torch_functional = _require_torch()
    dtype = torch.float32

    x_grid, y_grid = torch.meshgrid(
        torch.linspace(0, 105, config.grid_x, device=config.torch_device, dtype=dtype),
        torch.linspace(0, 68, config.grid_y, device=config.torch_device, dtype=dtype),
        indexing='ij',
    )
    target = torch.stack([x_grid, y_grid], dim=2)[None, None, :, :, :]

    ti_np, wi_np = np.polynomial.legendre.leggauss(config.gauss_points)
    ti_tensor = torch.tensor(ti_np, device=config.torch_device, dtype=dtype)
    wi_tensor = torch.tensor(wi_np, device=config.torch_device, dtype=dtype)

    ball_tt = torch.norm(target - tensors.ball, dim=-1).div_(config.average_ball_speed)

    r_att = (tensors.att_pos + tensors.att_v * config.reaction_time) - target
    r_def = (tensors.def_pos + tensors.def_v * config.reaction_time) - target

    tti_att = (
        torch.norm(r_att, dim=-1)
        .add_(config.reaction_time)
        .div_(config.max_player_speed)
    )
    tti_def = (
        torch.norm(r_def, dim=-1)
        .add_(config.reaction_time)
        .div_(config.max_player_speed)
    )

    tti = torch.cat([tti_att, tti_def], dim=0)
    tmp2 = config.sigma * (ball_tt - tti)[:, :, :, :, None]
    tmp1 = config.sigma * 0.5 * (ti_tensor + 1) * 10.0
    tmp1 = tmp1.view(1, 1, 1, 1, -1) + tmp2

    hh_full = torch.sigmoid(tmp1).mul_(config.lamb)
    num_att = tti_att.shape[0]
    h_team = hh_full[:num_att].sum(dim=0)

    attenuation = torch.exp(
        -config.lamb
        * (torch_functional.softplus(tmp1) - torch_functional.softplus(tmp2))
        .sum(dim=0)
        .div_(config.sigma)
    )

    team_control = torch.tensordot(attenuation * h_team, wi_tensor, dims=([-1], [0])).mul_(
        5.0
    )

    player_control = (
        attenuation.unsqueeze(0) * hh_full
    ) * wi_tensor.view(1, 1, 1, 1, -1)
    player_control = player_control.sum(dim=-1).mul_(5.0)

    return PitchControlResult(
        team_control=team_control,
        player_control=player_control,
        x_grid=x_grid,
        y_grid=y_grid,
        frame_ids=tensors.frame_ids,
        attacking_player_ids=tensors.att_player_ids,
        defending_player_ids=tensors.def_player_ids,
    )
