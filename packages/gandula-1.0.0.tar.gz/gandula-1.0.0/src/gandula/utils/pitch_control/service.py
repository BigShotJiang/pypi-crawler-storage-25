"""Service layer for pitch control orchestration."""

from dataclasses import replace

from pandas import DataFrame

from ...export.dataframe import pff_frames_to_dataframe
from ...providers.pff.schema.tracking import PFF_Frame
from ...schemas.pitch import GandulaPitchCoordinateCenter
from ...schemas.pitch.schema import PredefinedGandulaPitchSize
from ...utils.gandula_enhancer import change_pitch_standards
from .adapters import TeamSide, pff_frames_to_pitch_control_df, slice_pitch_control_window
from .config import PitchControlConfig
from .engine import compute_pitch_control, prepare_window_tensors
from .types import PitchControlResult


class PitchControlService:
    """Orchestrates pitch control runs with explicit validation and typing."""

    def __init__(self, config: PitchControlConfig | None = None):
        self.config = config or PitchControlConfig()

    def with_device(self, torch_device: str) -> 'PitchControlService':
        """Returns a copy of the service with a different torch device."""
        return PitchControlService(replace(self.config, torch_device=torch_device))

    def compute_window(
        self,
        data: DataFrame,
        *,
        attacking_team: TeamSide,
    ) -> PitchControlResult:
        """Runs pitch control for a normalized dataframe window."""
        tensors = prepare_window_tensors(
            data,
            attacking_team=attacking_team,
            config=self.config,
        )
        return compute_pitch_control(tensors, config=self.config)

    def compute_from_frames(
        self,
        frames: list[PFF_Frame],
        *,
        attacking_team: TeamSide,
        start_frame: int | None = None,
        end_frame: int | None = None,
        period: int | None = None,
        smoothed: bool = False,
    ) -> PitchControlResult:
        """Runs pitch control directly from PFF frames.

        Handles coordinate conversion from PFF centre-spot origin
        to bottom-left origin automatically.
        """
        metadata_df, players_ball_df = pff_frames_to_dataframe(frames)
        metadata_df, players_ball_df = change_pitch_standards(
            (metadata_df, players_ball_df),
            PredefinedGandulaPitchSize(type='meters'),
            GandulaPitchCoordinateCenter.BOTTOM_LEFT_CORNER,
        )
        normalized = pff_frames_to_pitch_control_df(metadata_df, players_ball_df)
        window = slice_pitch_control_window(
            normalized,
            start_frame=start_frame,
            end_frame=end_frame,
            period=period,
        )
        return self.compute_window(window, attacking_team=attacking_team)


def compute_pitch_control_from_dataframe(
    data: DataFrame,
    *,
    attacking_team: TeamSide,
    config: PitchControlConfig | None = None,
) -> PitchControlResult:
    """Functional API for pitch control from a normalized dataframe."""
    service = PitchControlService(config=config)
    return service.compute_window(data, attacking_team=attacking_team)


def compute_pitch_control_from_frames(
    frames: list[PFF_Frame],
    *,
    attacking_team: TeamSide,
    config: PitchControlConfig | None = None,
    start_frame: int | None = None,
    end_frame: int | None = None,
    period: int | None = None,
    smoothed: bool = False,
) -> PitchControlResult:
    """Functional API for pitch control from raw PFF frame objects."""
    service = PitchControlService(config=config)
    return service.compute_from_frames(
        frames,
        attacking_team=attacking_team,
        start_frame=start_frame,
        end_frame=end_frame,
        period=period,
        smoothed=smoothed,
    )
