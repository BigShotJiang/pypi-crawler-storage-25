"""Adapters between gandula frame structures and pitch control inputs."""

from typing import Literal

from pandas import DataFrame

from ...export.dataframe import pff_frames_to_dataframe
from ...providers.pff.schema.tracking import PFF_Frame

TeamSide = Literal['home', 'away']


def _build_player_uid(team: str, shirt: int) -> str:
    return f'{team}:{shirt}'


def _coalesce_columns(data: DataFrame, base_name: str) -> DataFrame:
    """Coalesces base and suffixed columns into a single canonical column."""
    if base_name in data.columns:
        return data

    left = f'{base_name}_x'
    right = f'{base_name}_y'

    if left in data.columns and right in data.columns:
        data[base_name] = data[left].combine_first(data[right])
        return data

    if left in data.columns:
        data[base_name] = data[left]
        return data

    if right in data.columns:
        data[base_name] = data[right]

    return data


def pff_frames_to_pitch_control_df(
    metadata_df, players_ball_df,
) -> DataFrame:
    """Converts PFF frames to a normalized dataframe for pitch control.

    Returned dataframe has one row per player per frame with ball coordinates.
    """

    columns = [
        'frame_id',
        'period',
        'elapsed_seconds',
        'team',
        'shirt',
        'x',
        'y',
        'ball_x',
        'ball_y',
    ]
    merged = players_ball_df.merge(
        metadata_df[['frame_id', 'period', 'elapsed_seconds']],
        on='frame_id',
        how='left',
    )

    # Depending on upstream export version, period/elapsed_seconds may already
    # exist in players_ball_df, so merge can create *_x/*_y columns.
    merged = _coalesce_columns(merged, 'period')
    merged = _coalesce_columns(merged, 'elapsed_seconds')

    normalized = merged[columns].copy()
    normalized['player_uid'] = normalized.apply(
        lambda row: _build_player_uid(str(row['team']), int(row['shirt'])), axis=1
    )

    return normalized


def slice_pitch_control_window(
    data: DataFrame,
    *,
    start_frame: int | None = None,
    end_frame: int | None = None,
    period: int | None = None,
) -> DataFrame:
    """Slices a normalized dataframe by frame range and optional period."""
    window = data.copy()

    if period is not None:
        window = window[window['period'] == period]
    if start_frame is not None:
        window = window[window['frame_id'] >= start_frame]
    if end_frame is not None:
        window = window[window['frame_id'] <= end_frame]

    return window
