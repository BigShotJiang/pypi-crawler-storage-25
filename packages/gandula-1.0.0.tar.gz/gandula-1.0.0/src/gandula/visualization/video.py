"""Implements functionality for watching videos of events."""

from IPython import get_ipython  # type: ignore
from IPython.display import HTML, display

from ..providers.pff.schema.gradient_event import GradientEventRow


def video(
    event: GradientEventRow,
    *,
    width: int | str = '80%',
    height: int | str = 500,
) -> None:
    """Display a video for a GradientEventRow on IPython environments.

    Parameters
    ----------
    event : GradientEventRow
        The event we want to see.
    width : int | str, optional
        The width of the iframe, by default '80%'.
    height : int | str, optional
        The height of the iframe, by default 500.
    """
    if not get_ipython():
        raise RuntimeError('This function is only available on IPython environments')

    if not event.video_url:
        raise ValueError('No video URL found for this event.')

    width_attr = f'{width}px' if isinstance(width, int) else width
    height_attr = f'{height}px' if isinstance(height, int) else height

    html = (
        f'<iframe src="{event.video_url}" '
        f'width="{width_attr}" height="{height_attr}" '
        f'frameborder="0" allowfullscreen></iframe>'
    )

    display(HTML(html))
