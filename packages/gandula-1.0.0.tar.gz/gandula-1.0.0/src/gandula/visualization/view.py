"""Functions to visualize gandula objects."""

from ..providers.pff.schema.tracking import PFF_Frame
from ..schemas.frame.schema import GandulaFrame
from ..utils.pitch_control.types import PitchControlResult
from .frame import (
    view_gandula_frame,
    view_gandula_frame_sequence,
    view_pff_frame,
    view_pff_frame_sequence,
)
from .pitch_control import view_pitch_control

from ..config import PYDANTIC_DUMP_OPTIONS


def view(objs, **kwargs):
    """Single entry point for visualizing gandula objects.

    Parameters
    ----------
    objs : PFF_Frame | GandulaFrame | PitchControlResult | any Pydantic model
        The object to be visualized.
    kwargs : dict
        Options to be passed to the view function.
    """
    if isinstance(objs, list) and not objs:
        raise ValueError('`objs` cannot be an empty list.')

    obj = objs[0] if isinstance(objs, list) else objs

    if isinstance(obj, PFF_Frame):
        if isinstance(objs, list):
            return view_pff_frame_sequence(objs, **kwargs)
        return view_pff_frame(objs, **kwargs)

    if isinstance(obj, GandulaFrame):
        if isinstance(objs, list):
            return view_gandula_frame_sequence(
                objs,
                **kwargs,
            )
        return view_gandula_frame(
            obj,
            **kwargs,
        )

    if isinstance(obj, PitchControlResult):
        return view_pitch_control(obj, **kwargs)

    if hasattr(obj, 'model_dump'):
        options = {**PYDANTIC_DUMP_OPTIONS, **kwargs}
        if isinstance(objs, list):
            return [o.model_dump(**options) for o in objs]
        return obj.model_dump(**options)

    raise ValueError(f'Cannot view object of type {type(obj)}')
