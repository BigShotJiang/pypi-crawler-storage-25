"""Visualization helpers for pitch control outputs."""

from matplotlib.axes import Axes

from ..config import PITCH_LENGTH, PITCH_WIDTH
from ..providers.pff.schema.tracking import PFF_Frame
from ..utils.pitch_control.types import PitchControlResult
from .frame import view_pff_frame
from .pitch import get_pitch

pitch_control_heatmap_options = {
    'cmap': 'coolwarm_r',
    'alpha': 0.75,
    'interpolation': 'bilinear',
}


def view_pitch_control(
    result: PitchControlResult,
    *,
    frame_index: int = 0,
    ax: Axes | None = None,
    pitch_length=PITCH_LENGTH,
    pitch_width=PITCH_WIDTH,
    vmin: float = 0.0,
    vmax: float = 1.0,
    show_colorbar: bool = True,
    colorbar_label: str = 'Attacking Team Control',
    **kwargs,
) -> Axes:
    """Plots one pitch-control heatmap frame."""
    _, _, ax = get_pitch(pitch_length=pitch_length, pitch_width=pitch_width, ax=ax)

    options = {**pitch_control_heatmap_options, **kwargs}
    team_control = result.team_control_numpy()
    if frame_index < 0 or frame_index >= team_control.shape[0]:
        raise IndexError('frame_index out of range for pitch control window.')

    image = ax.imshow(
        team_control[frame_index].T,
        origin='lower',
        extent=[0, pitch_length, 0, pitch_width],
        vmin=vmin,
        vmax=vmax,
        **options,
    )

    if show_colorbar:
        colorbar = ax.figure.colorbar(image, ax=ax, shrink=0.8)
        colorbar.set_label(colorbar_label)

    return ax


def view_pitch_control_with_frame(
    frame: PFF_Frame,
    result: PitchControlResult,
    *,
    frame_index: int = 0,
    ax: Axes | None = None,
    pitch_length=PITCH_LENGTH,
    pitch_width=PITCH_WIDTH,
    home_colors=('#FFFFFF', '#000000'),
    away_colors=('#000000', '#FFFFFF'),
    ball_color='#000000',
    **kwargs,
) -> Axes:
    """Overlays pitch control heatmap and tracking frame markers."""
    ax = view_pitch_control(
        result,
        frame_index=frame_index,
        ax=ax,
        pitch_length=pitch_length,
        pitch_width=pitch_width,
        **kwargs,
    )

    return view_pff_frame(
        frame,
        ax=ax,
        pitch_length=pitch_length,
        pitch_width=pitch_width,
        home_colors=home_colors,
        away_colors=away_colors,
        ball_color=ball_color,
    )
