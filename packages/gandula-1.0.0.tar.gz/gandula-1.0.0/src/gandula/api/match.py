from collections.abc import Callable
from pathlib import Path

import structlog
from tqdm.auto import tqdm

from ..providers.pff.local import loader as local_loader
from ..providers.pff.local.event_loader import load_gradient_events
from ..providers.pff.schema.gradient_event import GradientEventRow
from ..providers.pff.schema.tracking import PFF_Frame

logger = structlog.get_logger()


def get_events(
    file_path: str | Path,
    *,
    match_id: int | None = None,
) -> list[GradientEventRow]:
    """Load Gradient v2.6 event data from a local JSON file.

    :param file_path: Path to the JSON file (e.g. ``41177.json``).
    :param match_id: Optional filter — keep only events for this game ID.
    :return: List of validated GradientEventRow objects.
    """
    try:
        raw_events = load_gradient_events(file_path)

        if match_id is not None:
            raw_events = [e for e in raw_events if e.get('GAME_ID') == match_id]

        events = [
            GradientEventRow.model_validate(event)
            for event in tqdm(
                raw_events,
                desc='Validating events',
                unit=' events',
                leave=False,
            )
        ]

        return events
    except Exception as exc:
        logger.error(f'Error loading events from {file_path}', exc_info=exc)
        raise Exception(f'Error loading events from {file_path}') from exc


def get_frames(
    data_dir: str,
    match_id: int,
    *,
    competition_name: str | None = None,
    season: str | None = None,
    record_filter: Callable | None = None,
) -> list[PFF_Frame]:
    """Load tracking frames from local JSONL or BZ2 files.

    :param data_dir: Root directory containing tracking data files.
    :param match_id: The match ID to load.
    :param competition_name: Subdirectory for competition (optional).
    :param season: Subdirectory for season (optional).
    :param record_filter: Optional filter applied to each raw record.
    :return: List of validated PFF_Frame objects.
    """
    try:
        frames = local_loader.get_frames(
            data_dir,
            match_id,
            competition_name=competition_name,
            season=season,
            record_filter=record_filter,
        )

        frames = [
            PFF_Frame.model_validate(frame)
            for frame in tqdm(
                frames, desc='Validating frames', unit=' frames', leave=False
            )
        ]

        return frames
    except Exception as exc:
        logger.error(f'Error getting frames for match_id={match_id}', exc_info=exc)
        raise Exception(f'Error getting frames for match_id={match_id}') from exc


# ---------------------------------------------------------------------------
# S3-based tracking data access
# ---------------------------------------------------------------------------


def list_s3_matches(
    competition_id: str | int,
    season: str,
    *,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
) -> list[str]:
    """List available tracking data files on S3 for a competition/season.

    :param competition_id: The PFF competition ID.
    :param season: The season string (e.g. '2024-2025').
    :param aws_access_key_id: AWS access key. Falls back to env vars.
    :param aws_secret_access_key: AWS secret key. Falls back to env vars.
    :return: List of S3 keys for tracking data files (.jsonl / .bz2).
    """
    from ..providers.pff.s3.client import get_s3_client
    from ..providers.pff.s3.loader import find_available_matches

    client = get_s3_client(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )
    return find_available_matches(
        competition_id=competition_id,
        season=season,
        client=client,
    )


def download_tracking_data(
    competition_id: str | int,
    season: str,
    out_dir: str,
    *,
    max_workers: int | None = None,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
) -> tuple[list[str], list[tuple[str, str]]]:
    """Download tracking data from S3 for a competition/season.

    :param competition_id: The PFF competition ID.
    :param season: The season string (e.g. '2024-2025').
    :param out_dir: Local directory to save files to.
    :param max_workers: Number of parallel download workers.
    :param aws_access_key_id: AWS access key. Falls back to env vars.
    :param aws_secret_access_key: AWS secret key. Falls back to env vars.
    :return: Tuple of (successful_keys, failed_keys_with_errors).
    """
    from ..providers.pff.s3.client import get_s3_client
    from ..providers.pff.s3.loader import download_files, find_available_matches

    client = get_s3_client(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )
    keys = find_available_matches(
        competition_id=competition_id,
        season=season,
        client=client,
    )

    if not keys:
        logger.info(
            f'No tracking data found for competition={competition_id}, '
            f'season={season}'
        )
        return [], []

    logger.info(f'Found {len(keys)} files to download')
    return download_files(
        keys,
        out_dir,
        max_workers=max_workers,
        client=client,
    )


def get_s3_match_metadata(
    competition_id: str | int,
    season: str,
    match_id: str | int,
    *,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
) -> dict:
    """Load match metadata from S3.

    :param competition_id: The PFF competition ID.
    :param season: The season string (e.g. '2024-2025').
    :param match_id: The match ID.
    :param aws_access_key_id: AWS access key. Falls back to env vars.
    :param aws_secret_access_key: AWS secret key. Falls back to env vars.
    :return: Match metadata dictionary.
    """
    from ..providers.pff.s3.client import get_s3_client
    from ..providers.pff.s3.loader import load_json_object

    client = get_s3_client(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )
    key = f'{competition_id}/{season}/{match_id}/metadata.json'
    return load_json_object(key, client=client)


def get_s3_rosters(
    competition_id: str | int,
    season: str,
    match_id: str | int,
    *,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
) -> list[dict]:
    """Load match rosters from S3.

    :param competition_id: The PFF competition ID.
    :param season: The season string (e.g. '2024-2025').
    :param match_id: The match ID.
    :param aws_access_key_id: AWS access key. Falls back to env vars.
    :param aws_secret_access_key: AWS secret key. Falls back to env vars.
    :return: List of roster dictionaries.
    """
    from ..providers.pff.s3.client import get_s3_client
    from ..providers.pff.s3.loader import load_json_object

    client = get_s3_client(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )
    key = f'{competition_id}/{season}/{match_id}/rosters.json'
    return load_json_object(key, client=client)


def get_s3_frames(
    key: str,
    *,
    record_filter: Callable | None = None,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
) -> list[PFF_Frame]:
    """Load and validate frames directly from an S3 key.

    Streams the file from S3, parses JSONL/BZ2 content, and validates
    each frame into a PFF_Frame model.

    :param key: The S3 object key for the tracking data file.
    :param record_filter: Optional filter function applied to each record.
    :param aws_access_key_id: AWS access key. Falls back to env vars.
    :param aws_secret_access_key: AWS secret key. Falls back to env vars.
    :return: List of validated PFF_Frame objects.
    """
    from ..providers.pff.s3.client import get_s3_client
    from ..providers.pff.s3.loader import stream_frames

    client = get_s3_client(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )
    frames_data = stream_frames(key, client=client, record_filter=record_filter)

    frames = [
        PFF_Frame.model_validate(frame)
        for frame in tqdm(
            frames_data,
            desc='Loading frames from S3',
            unit=' frames',
            leave=False,
        )
    ]

    return frames
