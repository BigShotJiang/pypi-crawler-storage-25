from pathlib import Path

import structlog

from . import loader

logger = structlog.get_logger()


def load_gradient_events(file_path: str | Path) -> list[dict]:
    """Load Gradient v2.6 event data from a local JSON file.

    :param file_path: Path to the JSON file (e.g. ``41177.json``).
    :return: List of raw event dictionaries.
    :raises IOError: If the file cannot be read or parsed.
    """
    try:
        path = Path(file_path)
        logger.debug('Loading gradient events', file_path=str(path))
        data = loader.read_json(path)
        logger.debug('Loaded gradient events', count=len(data))
        return data
    except Exception as exc:
        raise IOError(f'Failed to load gradient events from {file_path}') from exc
