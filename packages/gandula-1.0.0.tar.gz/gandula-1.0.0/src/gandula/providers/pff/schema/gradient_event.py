from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class GradientGameEventType(str, Enum):
    FIRST_HALF_KICKOFF = '1KO'
    SECOND_HALF_KICKOFF = '2KO'
    THIRD_KICKOFF = '3KO'
    FOURTH_KICKOFF = '4KO'
    END_OF_HALF = 'END'
    FOUL = 'FOUL'
    WOODWORK = 'G'
    PLAYER_OFF = 'OFF'
    PLAYER_ON = 'ON'
    ON_THE_BALL = 'OTB'
    OUT_OF_PLAY = 'OUT'
    SUB = 'SUB'


class GradientPossessionEventType(str, Enum):
    BALL_CARRY = 'BC'
    CHALLENGE = 'CH'
    CLEARANCE = 'CL'
    CROSS = 'CR'
    FOUL = 'FO'
    INTERCEPTION = 'IT'
    PASS = 'PA'
    REBOUND = 'RE'
    SHOT = 'SH'
    TOUCH_CONTROL = 'TC'


class GradientPlayer(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    player_id: int = Field(alias='PLAYER_ID')
    jersey_num: int = Field(alias='JERSEY_NUM')
    x: float = Field(alias='X')
    y: float = Field(alias='Y')
    speed: float | None = Field(None, alias='SPEED')
    position: str | None = Field(None, alias='POSITION')
    confidence: str | None = Field(None, alias='CONFIDENCE')
    visibility: str | None = Field(None, alias='VISIBILITY')


class GradientBall(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    x: float | None = Field(None, alias='X')
    y: float | None = Field(None, alias='Y')
    z: float | None = Field(None, alias='Z')
    visibility: str | None = Field(None, alias='VISIBILITY')


class GradientEventRow(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    # Top-level typed fields
    game_id: int = Field(alias='GAME_ID')
    competition_id: int = Field(alias='COMPETITION_ID')
    competition_name: str = Field(alias='COMPETITION_NAME')
    season: str = Field(alias='SEASON')
    game_event_id: int = Field(alias='GAME_EVENT_ID')
    possession_event_id: float | None = Field(None, alias='POSSESSION_EVENT_ID')
    start_time: float = Field(alias='START_TIME')
    end_time: float | None = Field(None, alias='END_TIME')
    duration: float = Field(alias='DURATION')
    event_time: float = Field(alias='EVENT_TIME')
    sequence: float | None = Field(None, alias='SEQUENCE')
    video_url: str = Field(alias='VIDEO_URL')
    frame_num: int = Field(alias='FRAME_NUM')
    updated_at: int = Field(alias='UPDATED_AT')

    # Raw dicts — not typed
    game_events: dict | None = Field(None, alias='GAME_EVENTS')
    initial_touch: dict | None = Field(None, alias='INITIAL_TOUCH')
    possession_events: dict | None = Field(None, alias='POSSESSION_EVENTS')
    fouls: dict | None = Field(None, alias='FOULS')
    grades: dict | None = Field(None, alias='GRADES')
    stadium_metadata: dict | None = Field(None, alias='STADIUM_METADATA')

    # Typed tracking
    home_players: list[GradientPlayer] = Field(default_factory=list, alias='HOME_PLAYERS')
    away_players: list[GradientPlayer] = Field(default_factory=list, alias='AWAY_PLAYERS')
    ball: list[GradientBall] = Field(default_factory=list, alias='BALL')
