from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class PositionGroupType(str, Enum):
    ATTACK_MID = 'AM'
    CENTER_FORWARD = 'CF'
    CENTER_MID = 'CM'
    DEFENDER = 'D'
    DEFENSIVE_MID = 'DM'
    FORWARD = 'F'
    GK = 'GK'
    LEFT_BACK = 'LB'
    LEFT_CENTER_BACK = 'LCB'
    LEFT_MID = 'LM'
    LEFT_WINGER = 'LW'
    LEFT_WING_BACK = 'LWB'
    MIDFIELDER = 'M'
    MID_CENTER_BACK = 'MCB'
    RIGHT_BACK = 'RB'
    RIGHT_CENTER_BACK = 'RCB'
    CENTER_BACK = 'CB'
    RIGHT_MID = 'RM'
    RIGHT_WINGER = 'RW'
    RIGHT_WING_BACK = 'RWB'


class Confederation(BaseModel):
    id: str | None = None
    abbreviation: str | None = None
    name: str | None = None


class Federation(BaseModel):
    id: str | None = None
    name: str | None = None
    englishName: str | None = None
    abbreviation: str | None = None
    confederation: Confederation | None = None
    country: str | None = None


class Nation(BaseModel):
    country: str | None = None
    federation: Federation | None = None
    fifaCode: str | None = None
    id: str | None = None
    iocCode: str | None = None


class Player(BaseModel):
    id: str
    dob: str | None = None
    firstName: str | None = None
    gender: str | None = None
    height: float | None = None  # in cm
    lastName: str | None = None
    nickname: str | None = None
    preferredFoot: str | None = None
    weight: float | None = None
    positionGroupType: PositionGroupType | None = None
    nationality: Nation | None = None
    secondNationality: Nation | None = None
    countryOfBirth: Nation | None = None


class PFF_Team(BaseModel):
    id: str
    name: str | None = None
    shortName: str | None = None


class PFF_Roster(BaseModel):
    id: str | None = None
    game: dict | None = None
    player: Player
    positionGroupType: PositionGroupType
    shirtNumber: str | int
    started: bool | None = None
    team: PFF_Team
