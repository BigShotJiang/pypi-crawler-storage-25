"""S3 client configuration for PFF tracking data bucket."""

from __future__ import annotations

import os

import structlog

logger = structlog.get_logger()

BUCKET_NAME = 'pff-soccer-production-tracking-data-processed'
REGION_NAME = 'us-east-2'


def get_s3_credentials() -> tuple[str, str]:
    """Get AWS credentials from environment variables.

    Looks for PFF_AWS_ACCESS_KEY_ID / PFF_AWS_SECRET_ACCESS_KEY first,
    then falls back to AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY.
    """
    access_key = os.environ.get('PFF_AWS_ACCESS_KEY_ID') or os.environ.get(
        'AWS_ACCESS_KEY_ID'
    )
    secret_key = os.environ.get('PFF_AWS_SECRET_ACCESS_KEY') or os.environ.get(
        'AWS_SECRET_ACCESS_KEY'
    )

    if not access_key or not secret_key:
        raise EnvironmentError(
            'AWS credentials not found. Set PFF_AWS_ACCESS_KEY_ID and '
            'PFF_AWS_SECRET_ACCESS_KEY (or AWS_ACCESS_KEY_ID and '
            'AWS_SECRET_ACCESS_KEY) environment variables.'
        )

    return access_key, secret_key


def get_s3_client(
    *,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    region_name: str = REGION_NAME,
):
    """Create a boto3 S3 client for the PFF tracking data bucket.

    :param aws_access_key_id: AWS access key. Falls back to env vars.
    :param aws_secret_access_key: AWS secret key. Falls back to env vars.
    :param region_name: AWS region. Defaults to us-east-2.
    :return: A boto3 S3 client.
    """
    try:
        import boto3
        from botocore.config import Config
    except ImportError as err:
        raise ImportError(
            'boto3 is required for S3 access. ' 'Install it with: pip install boto3'
        ) from err

    if not aws_access_key_id or not aws_secret_access_key:
        aws_access_key_id, aws_secret_access_key = get_s3_credentials()

    return boto3.client(
        's3',
        region_name=region_name,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        config=Config(retries={'max_attempts': 10, 'mode': 'adaptive'}),
    )
