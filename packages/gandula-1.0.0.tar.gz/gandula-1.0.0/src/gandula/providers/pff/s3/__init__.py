from .client import BUCKET_NAME as BUCKET_NAME
from .client import REGION_NAME as REGION_NAME
from .client import get_s3_client as get_s3_client
from .loader import download_file as download_file
from .loader import download_files as download_files
from .loader import find_available_matches as find_available_matches
from .loader import list_keys as list_keys
from .loader import load_json_object as load_json_object
from .loader import stream_frames as stream_frames

# Bucket key structure: {competition_id}/{season}/{match_id}/{files}
# Example: 1/2024-2025/5001/5001.jsonl.bz2
