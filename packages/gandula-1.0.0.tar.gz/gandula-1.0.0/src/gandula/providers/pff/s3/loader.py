"""S3-based loader for PFF tracking data.

Bucket key structure: {competition_id}/{season}/{match_id}/{files}
Example: 1/2024-2025/5001/5001.jsonl.bz2
"""

from __future__ import annotations

import bz2
import concurrent.futures as cf
import os
from pathlib import Path
from typing import Callable, Generator

import orjson
import structlog
from tqdm.auto import tqdm

from .client import BUCKET_NAME, get_s3_client

logger = structlog.get_logger()


def _build_prefix(
    competition_id: str | int,
    season: str,
    match_id: str | int | None = None,
) -> str:
    """Build the S3 prefix for a competition/season/match."""
    prefix = f'{competition_id}/{season}/'
    if match_id is not None:
        prefix += f'{match_id}/'
    return prefix


def list_keys(
    *,
    competition_id: str | int,
    season: str,
    match_id: str | int | None = None,
    client=None,
    bucket: str = BUCKET_NAME,
) -> list[str]:
    """List all S3 keys for a competition/season (and optionally a match).

    :param competition_id: The PFF competition ID.
    :param season: The season string (e.g. '2024-2025').
    :param match_id: Optional match ID to narrow listing.
    :param client: Optional pre-configured boto3 S3 client.
    :param bucket: S3 bucket name.
    :return: List of matching S3 keys.
    """
    if client is None:
        client = get_s3_client()

    prefix = _build_prefix(competition_id, season, match_id)

    paginator = client.get_paginator('list_objects_v2')
    matched = []
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get('Contents', []):
            matched.append(obj['Key'])

    logger.debug(
        'S3 key listing complete',
        prefix=prefix,
        matched=len(matched),
    )
    return matched


def find_available_matches(
    *,
    competition_id: str | int,
    season: str,
    client=None,
    bucket: str = BUCKET_NAME,
) -> list[str]:
    """List available tracking data files on S3 for a competition/season.

    Returns only .jsonl and .bz2 file keys.

    :param competition_id: The PFF competition ID.
    :param season: The season string (e.g. '2024-2025').
    :param client: Optional pre-configured boto3 S3 client.
    :param bucket: S3 bucket name.
    :return: List of matching S3 keys for tracking data files.
    """
    keys = list_keys(
        competition_id=competition_id,
        season=season,
        client=client,
        bucket=bucket,
    )
    return [k for k in keys if k.endswith('.jsonl') or k.endswith('.bz2')]


def download_file(
    key: str,
    out_dir: str | Path,
    *,
    client=None,
    bucket: str = BUCKET_NAME,
) -> Path:
    """Download a single file from S3.

    :param key: The S3 object key.
    :param out_dir: Local directory to download into.
    :param client: Optional pre-configured boto3 S3 client.
    :param bucket: S3 bucket name.
    :return: Path to the downloaded file.
    """
    if client is None:
        client = get_s3_client()

    from boto3.s3.transfer import TransferConfig

    destination = Path(out_dir) / key
    destination.parent.mkdir(parents=True, exist_ok=True)

    cfg = TransferConfig(
        multipart_threshold=32 * 1024 * 1024,
        max_concurrency=10,
        multipart_chunksize=8 * 1024 * 1024,
        use_threads=True,
    )
    client.download_file(bucket, key, str(destination), Config=cfg)
    return destination


def download_files(
    keys: list[str],
    out_dir: str | Path,
    *,
    max_workers: int | None = None,
    client=None,
    bucket: str = BUCKET_NAME,
) -> tuple[list[str], list[tuple[str, str]]]:
    """Download multiple files from S3 in parallel.

    :param keys: List of S3 keys to download.
    :param out_dir: Local directory to download into.
    :param max_workers: Number of parallel workers. Defaults to CPU count.
    :param client: Optional pre-configured boto3 S3 client.
    :param bucket: S3 bucket name.
    :return: Tuple of (successful_keys, failed_keys_with_errors).
    """
    if client is None:
        client = get_s3_client()

    if max_workers is None:
        max_workers = os.cpu_count() or 8

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    successes: list[str] = []
    failures: list[tuple[str, str]] = []

    with cf.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_key = {
            executor.submit(download_file, k, out, client=client, bucket=bucket): k
            for k in keys
        }
        for future in tqdm(
            cf.as_completed(future_to_key),
            total=len(keys),
            desc='Downloading from S3',
            unit=' files',
        ):
            key = future_to_key[future]
            try:
                future.result()
                successes.append(key)
            except Exception as exc:
                failures.append((key, str(exc)))
                logger.warning(f'Failed to download {key}: {exc}')

    return successes, failures


def load_json_object(
    key: str,
    *,
    client=None,
    bucket: str = BUCKET_NAME,
) -> dict | list:
    """Load and parse a JSON object from S3.

    :param key: The S3 object key (e.g. '1/2022-2023/4436/metadata.json').
    :param client: Optional pre-configured boto3 S3 client.
    :param bucket: S3 bucket name.
    :return: Parsed JSON content.
    """
    if client is None:
        client = get_s3_client()

    response = client.get_object(Bucket=bucket, Key=key)
    return orjson.loads(response['Body'].read())


def stream_frames(
    key: str,
    *,
    client=None,
    bucket: str = BUCKET_NAME,
    record_filter: Callable | None = None,
) -> Generator[dict, None, None]:
    """Stream frames directly from an S3 object without saving to disk.

    Supports both .jsonl and .jsonl.bz2 files.

    :param key: The S3 object key.
    :param client: Optional pre-configured boto3 S3 client.
    :param bucket: S3 bucket name.
    :param record_filter: Optional filter function applied to each record.
    :yields: Frame dictionaries.
    """
    if client is None:
        client = get_s3_client()

    response = client.get_object(Bucket=bucket, Key=key)
    body = response['Body'].read()

    if key.endswith('.bz2'):
        body = bz2.decompress(body)

    for line in body.split(b'\n'):
        line = line.strip()
        if not line:
            continue
        record = orjson.loads(line)
        if record_filter and record_filter(record) is False:
            continue
        yield record
