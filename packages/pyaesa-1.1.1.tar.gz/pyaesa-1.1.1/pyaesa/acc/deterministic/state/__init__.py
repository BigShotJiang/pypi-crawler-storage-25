"""Deterministic aCC state ownership."""
