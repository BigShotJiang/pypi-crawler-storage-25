"""Deterministic aCC internal ownership."""
