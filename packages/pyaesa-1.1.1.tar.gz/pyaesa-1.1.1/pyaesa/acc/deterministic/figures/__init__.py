"""Deterministic aCC figure owners."""
