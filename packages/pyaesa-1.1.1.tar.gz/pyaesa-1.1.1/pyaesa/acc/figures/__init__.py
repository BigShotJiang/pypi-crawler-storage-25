"""Shared aCC figure helpers."""
