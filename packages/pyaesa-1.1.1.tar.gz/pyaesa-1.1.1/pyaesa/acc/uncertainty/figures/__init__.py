"""Uncertainty aCC figure owners."""
