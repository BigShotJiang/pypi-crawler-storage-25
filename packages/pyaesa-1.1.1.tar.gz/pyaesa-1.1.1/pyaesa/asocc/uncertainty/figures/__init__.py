"""aSoCC uncertainty figure generation."""
