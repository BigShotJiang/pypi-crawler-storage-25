"""aSoCC uncertainty engine helpers."""
