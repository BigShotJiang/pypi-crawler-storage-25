"""aSoCC setup loading owners."""
