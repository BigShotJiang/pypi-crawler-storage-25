"""aSoCC setup formatting owners."""
