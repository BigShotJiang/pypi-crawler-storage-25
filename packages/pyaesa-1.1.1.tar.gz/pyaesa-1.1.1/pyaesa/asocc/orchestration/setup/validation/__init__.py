"""aSoCC setup validation owners."""
