"""Write stage orchestration package."""
