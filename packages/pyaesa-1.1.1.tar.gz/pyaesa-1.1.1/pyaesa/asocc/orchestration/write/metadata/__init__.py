"""aSoCC write metadata owners."""
