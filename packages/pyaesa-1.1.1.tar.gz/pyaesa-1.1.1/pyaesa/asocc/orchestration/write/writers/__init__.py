"""aSoCC output writer owners."""
