"""Yearly stage orchestration package."""
