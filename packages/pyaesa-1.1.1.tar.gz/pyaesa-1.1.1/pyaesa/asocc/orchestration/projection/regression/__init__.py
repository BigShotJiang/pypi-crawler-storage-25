"""Projection regression kernels."""
