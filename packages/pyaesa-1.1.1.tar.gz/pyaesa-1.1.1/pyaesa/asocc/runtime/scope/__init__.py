"""aSoCC runtime scope owners."""
