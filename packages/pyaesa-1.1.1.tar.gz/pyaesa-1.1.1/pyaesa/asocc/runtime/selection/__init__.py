"""Runtime method selection package."""
