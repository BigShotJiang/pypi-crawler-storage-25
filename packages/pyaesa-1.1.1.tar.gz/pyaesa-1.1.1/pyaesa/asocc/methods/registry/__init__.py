"""Methods registry package."""
