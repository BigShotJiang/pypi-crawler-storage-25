"""Deterministic ASR figure ownership."""
