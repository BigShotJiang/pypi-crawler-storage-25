"""Deterministic ASR state ownership."""
