"""ASR uncertainty internals."""
