"""ASR uncertainty figure rendering."""
