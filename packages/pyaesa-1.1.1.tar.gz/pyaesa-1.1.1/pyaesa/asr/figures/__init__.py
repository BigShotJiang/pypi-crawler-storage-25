"""Shared ASR figure support."""
