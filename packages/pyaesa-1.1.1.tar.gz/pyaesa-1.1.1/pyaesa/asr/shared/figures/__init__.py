"""ASR shared figure owners."""
