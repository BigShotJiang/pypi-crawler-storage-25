"""ASR shared runtime owners."""
