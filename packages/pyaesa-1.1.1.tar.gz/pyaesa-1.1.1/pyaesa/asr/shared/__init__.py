"""Internal ASR shared package."""
