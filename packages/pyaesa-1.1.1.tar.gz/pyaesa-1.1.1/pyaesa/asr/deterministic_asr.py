"""Public entrypoint for deterministic absolute sustainability ratio (ASR)."""

from dataclasses import replace
from pathlib import Path
from typing import Any, cast

from pyaesa.external_inputs.asocc.schema.contracts import (
    normalize_external_method_selector,
    validate_external_method_collisions,
)
from pyaesa.shared.acc_asr_common.branches.config import (
    normalize_base_cc_args,
    require_asr_static_cc_source_compatibility,
)
from pyaesa.shared.acc_asr_common.branches.expand import iter_cc_method_branches
from pyaesa.shared.acc_asr_common.deterministic.downstream.tabular_io import (
    normalize_downstream_output_format,
)
from pyaesa.shared.acc_asr_common.deterministic.state.scope_guard import (
    branch_coverage,
    branch_identity_payload,
    branch_reuse_mode_or_raise,
)
from pyaesa.shared.acc_asr_common.persistence.requests import (
    build_public_cc_branch_args,
    build_public_composite_request_payload,
)
from pyaesa.shared.acc_asr_common.reporting import build_downstream_common_scope_lines
from pyaesa.shared.acc_asr_common.scope.composite import (
    base_asocc_kwargs_from_allocate_args,
    build_composite_base_allocate_args,
    normalize_base_asocc_args,
    normalize_mrio_scope,
    normalize_shared_lcia_methods,
)
from pyaesa.asocc.runtime.scope.branch_resolution import resolve_allocate_project_base
from pyaesa.asocc.runtime.request.normalization import normalize_base_allocate_args
from pyaesa.asr.shared.lca.request import (
    normalize_lca_args,
    selected_lca_type,
    selected_lca_version_name,
)
from pyaesa.asr.deterministic.runtime.prerequisites import ensure_asr_branch_prerequisites
from pyaesa.shared.figures.request_validation import (
    normalize_figure_format,
    normalize_figure_options,
    resolve_nested_polar_years,
)
from pyaesa.shared.runtime.reporting.composite_phase_index import (
    CompositePhaseIndexEntry,
    PHASE_C_ASR,
    phase_index_path_for_metadata,
    phase_ready_detail,
    phase_reused_detail,
    public_phase_reuse_status,
    read_phase_index,
    write_phase_index,
)
from pyaesa.shared.runtime.reporting.phase import NullPhasePrinter, PhasePrinter
from pyaesa.shared.runtime.reporting.output_roots import public_output_root_from_path
from pyaesa.shared.runtime.reporting.summary_log import summary_log_path, write_summary_log
from pyaesa.shared.selectors.request_targets import build_asocc_target_selector
from pyaesa.shared.selectors.time_selectors import (
    normalize_requested_years,
    normalize_time_selector_mapping,
)

from .deterministic.runner import run_single_asr
from .deterministic.state.metadata import load_run_metadata
from .deterministic.state.reports import (
    ASRBranchReport,
    ComputeASRReport,
    asr_phase_inventory_lines,
    asr_phase_summary_lines,
)
from .shared.runtime.paths import build_asr_path_context, get_asr_meta_path


def _resolve_proj_base(base_allocate_args: dict[str, Any]) -> Path:
    return resolve_allocate_project_base(
        base_allocate_args=normalize_base_allocate_args(
            base_asocc_kwargs_from_allocate_args(base_allocate_args=base_allocate_args)
        )
    )


def _build_branch_signature(
    *,
    public_request_payload: dict[str, Any],
) -> dict[str, Any]:
    normalized_payload = cast(
        dict[str, Any],
        normalize_time_selector_mapping(public_request_payload),
    )
    return {
        "function": "deterministic_asr",
        **normalized_payload,
    }


def _build_figure_signature(
    *,
    figure_format: dict[str, Any],
    figure_options: dict[str, Any],
) -> dict[str, Any]:
    """Return deterministic ASR figure request signature."""
    return {
        "function": "deterministic_asr_figures",
        "figure_format": dict(figure_format),
        "figure_options": dict(figure_options),
    }


def deterministic_asr(
    *,
    project_name: str,
    source: str,
    group_reg: bool = False,
    group_sec: bool = False,
    group_version: str = "",
    years: int | list[int] | range,
    fu_code: str,
    s_p: str | list[str] | None = None,
    r_p: str | list[str] | None = None,
    r_c: str | list[str] | None = None,
    r_f: str | list[str] | None = None,
    aggreg_indices: bool = False,
    lcia_method: str | list[str],
    base_asocc_args: dict = {
        "method_plan": "default",
        "l1_methods": None,
        "one_step_methods": None,
        "two_step_methods": None,
        "l1_l2_pairs": None,
        "l1_reg_aggreg": "post",
        "reference_years": None,
        "ssp_scenario": ["SSP1", "SSP2", "SSP3", "SSP4", "SSP5"],
        "projection_mode": "regression",
        "reg_window": None,
        "l2_reuse_years": None,
        "include_lcia_based_allocation_methods": True,
    },
    external_method: dict | None = None,
    base_cc_args: dict = {
        "static": {"active": True, "exclude_max_cc": False},
        "dynamic_ar6": {
            "active": False,
            "harmonization": True,
            "harmonization_method": "offset",
            "category": ["C1", "C2", "C3", "C4"],
            "ssp_scenario": ["SSP1", "SSP2", "SSP3", "SSP4", "SSP5"],
            "emission_type": "kyoto_gases",
            "include_afolu": False,
            "emissions_mode": "gross_alt",
            "subset_version": None,
        },
    },
    lca_args: dict = {
        "external_lca": {"active": True, "version_name": None},
        "io_lca": {"active": False},
    },
    output_format: str = "csv",
    figures: bool = True,
    figure_options: dict = {
        "per_method": True,
        "multi_method": True,
        "polar": {"active": True, "polar_years": None},
    },
    figure_format: dict = {"format": "png", "dpi": 500},
    subfigures: bool = True,
    refresh: bool = False,
) -> ComputeASRReport:
    """Compute deterministic absolute sustainability ratio (ASR) outputs.

    The function creates or reuses deterministic allocated carrying capacity
    (aCC) and IO-LCA prerequisites when required, consumes
    staged external LCA when selected, and computes ``ASR = LCA / aCC``. It
    writes deterministic ASR tables and renders figures when requested. Omit
    arguments to use their default.

    Args:
        project_name: Required project name used to build
            ``<repo>/<project_name>``.
        source: MRIO source key (``"exiobase_396_ixi"``,
            ``"exiobase_396_pxp"``, ``"exiobase_3102_ixi"``,
            ``"exiobase_3102_pxp"``, or ``"oecd_v2025"``), or ``"iso3"``
            for ISO3 only mode (L1 EG/PR(GDPcap) only).
        group_reg: If ``True``, aggregate regions using a grouping file.
            Default ``False`` keeps native source regions.
        group_sec: If ``True``, aggregate sectors using a grouping file.
            Default ``False`` keeps native source sectors.
        group_version: Grouping version tag used to resolve the region/sector
            mapping CSVs. Required when ``group_reg`` or ``group_sec`` is True.
            Defaults to an empty string for ungrouped processing. Follow
            ``README_grouping.txt`` in the active
            ``data_raw/mrio/<source>/grouping`` folder to name grouping
            versions and place the matching mapping CSVs.
        years: Studied years. Accepts a single year, list, or range. If
            omitted, all available MRIO
            years for the selected source/group version are used.
        lcia_method: Shared downstream LCIA method name or list of names. When
            static carrying capacity (CC) is active, the denominator requires
            a matching carrying capacity CSV. The package includes static CC files for
            ``"pb_lcia"``, ``"gwp100_lcia"``, and ``"ef_3.1"``; among these,
            ``"ef_3.1"`` is the default carrying capacity method that
            currently has no MRIO LCIA characterization matrix. It is still
            dynamic AR6 compatible for its ``"GWP_100"`` impact category.
            Dynamic AR6 CC is supported for ``"gwp100_lcia"`` and for
            ``"ef_3.1"`` impact ``"GWP_100"`` only. Custom static CC methods
            also require a matching file in
            ``data_raw/carrying_capacities/``; follow
            ``README_add_custom_carrying_capacities.txt``. When upstream
            allocated shares of carrying capacities (aSoCC) LCIA based methods
            or IO-LCA generation is in scope, custom EXIOBASE MRIO LCIA
            methods must be prepared with
            ``data_raw/mrio/exiobase_3/lcia/characterization_factors_matrices/README_add_custom_lcia_characterization_matrices.txt``
            and processed with ``process_mrio(...)``.
            ``base_asocc_args["include_lcia_based_allocation_methods"]``
            controls whether LCIA based allocation methods are included. When
            it is ``False``, upstream aSoCC keeps only non LCIA dependent
            methods, so the requested ``lcia_method`` may be non MRIO when the
            matching carrying capacity and selected LCA numerator prerequisites
            exist.
        fu_code: Required functional unit code (for example ``"L1.a"``,
            ``"L2.c.b"``). See
            ``data_raw/methodological_notes/methodological_note__asocc_fus_allocation_methods.pdf``
            for all available functional unit codes and the system
            boundaries each represents.
        s_p: Producing sector filter(s), single string or list. If this is a
            required axis for ``fu_code`` and the argument is omitted, the run
            expands to all valid producing sectors. To identify valid sector
            names, see the first column of the relevant
            ``data_raw/mrio/.../grouping/.../group_sec_template.csv`` file. For
            EXIOBASE sector definitions, see
            ``data_raw/mrio/exiobase_3/sector_classification.xlsx``; EXIOBASE
            ixi and pxp use different sector lists.
        r_p: Producing region filter(s), single string or list. If this is a
            required axis for ``fu_code`` and the argument is omitted, the run
            expands to all valid producing regions. To identify valid region
            names, see the first column of the relevant
            ``data_raw/mrio/.../grouping/group_reg_template.csv`` file.
        r_c: Consuming region filter(s), single string or list. If this is a
            required axis for ``fu_code`` and the argument is omitted, the run
            expands to all valid consuming regions. To identify valid region
            names, see the first column of the relevant
            ``data_raw/mrio/.../grouping/group_reg_template.csv`` file.
        r_f: Final demand region filter(s), single string or list. If this is
            a required axis for ``fu_code`` and the argument is omitted, the
            run expands to all valid final demand regions. To identify valid
            region names, see the first column of the relevant
            ``data_raw/mrio/.../grouping/group_reg_template.csv`` file.
        aggreg_indices: Whether multiple selected region/sector indices are
            reported as separate rows or summed into one row after the
            selected MRIO scope is computed.
            - ``False`` (default): keep selected values as independent rows.
            - ``True``: sum selected values into one row.
            Not allowed for ``L2.a.b``, ``L2.b.b``, and ``L2.c.b`` because
            aggregating CBA total demand system boundaries can double count.
            For these functional units, define the aggregation from
            ``process_mrio(...)`` onward with
            ``group_reg``/``group_sec``/``group_version``.
        base_asocc_args: Optional aSoCC only envelope reused to resolve the
            deterministic upstream aSoCC prerequisite. Write nested arguments
            as ``base_asocc_args={"method_plan": "default"}``. Omit the
            envelope or any accepted key to use its default.

            Nested keys:

            - ``method_plan``: ``method_plan`` defaults to ``"default"`` and
              accepts ``"default"``, ``"one_step"``, ``"two_steps"``,
              ``"pairs"``, or ``"one_step_pairs"``. When omitted, all pyaesa
              allocation methods available for the selected ``fu_code`` are
              applied. See
              ``data_raw/methodological_notes/methodological_note__asocc_fus_allocation_methods.pdf``
              for the allocation methods available per functional unit,
              including definitions and mathematical expressions.
            - ``l1_methods``: Optional L1 subset. Omit it to keep all L1
              methods allowed by ``method_plan``. In ``"default"``, this
              filters only L1 weights used by two step methods. In
              ``"two_steps"``, it filters the two step cartesian L1 side.
            - ``one_step_methods``: Optional one step L2 subset. Omit it to
              keep all one step methods allowed by ``method_plan``.
            - ``two_step_methods``: Optional two step L2 subset. Omit it to
              keep all two step L2 methods allowed by ``method_plan``.
            - ``l1_l2_pairs``: Explicit pair list formatted as
              ``"L1METHOD::L2METHOD"``. Omit it unless ``method_plan`` is
              ``"pairs"`` or ``"one_step_pairs"``.
            - ``l1_reg_aggreg``: L1 aggregation mode for methods where timing
              matters (``PR(GDPcap)``, ``PR-HR(Ecap)`` and ``AR(Ecap)``).
              ``"pre"`` aggregates regions before L1 computation. ``"post"``
              (default) computes on original regions, then aggregates.
            - ``reference_years``: Acquired rights (AR) methods reference
              year selector. Accepts a single year, list, or range. If
              omitted, AR routes use all historical years in the studied range
              up to the source registry historical cutoff. For EXIOBASE
              3.10.2 and OECD ICIO v2025, the cutoff is 2022; other supported
              MRIO sources use their own registry cutoff.
            - ``projection_mode``: Projection policy for post historical
              years of L2 utilitarian (UT) methods (MRIO economic enacting
              metrics). Defaults to ``"regression"``. ``"regression"``
              projects UT inputs for future years. ``"historical_reuse"``
              reuses historical UT structures.
            - ``reg_window``: Historical regression fit window for regression
              mode. Provide it as ``range(start_year, end_year + 1)`` or as
              an explicit list of consecutive years in fit window order. When
              omitted, the source registry supplies the default fit window
              from the modeled year minimum through the source historical
              cutoff. For EXIOBASE 3.10.2 and OECD ICIO v2025, this resolves
              to 1995 to 2022; other supported MRIO sources use their own
              registry window.
            - ``l2_reuse_years``: Historical L2 reuse year selector used by
              all UT historical reuse routes. In
              ``projection_mode="historical_reuse"`` it applies to all UT
              methods; in ``projection_mode="regression"`` it applies to
              adjusted UT routes (``UT(FDa)``, ``UT(GVAa)``), which always
              use historical reuse as regression is not supported (would
              require regression on full MRIO). If omitted, defaults to
              ``reg_window`` when required.
            - ``include_lcia_based_allocation_methods``: Whether to include
              LCIA based allocation methods (e.g.: acquired rights - AR, or
              historical responsibility - PR-HR). Defaults to ``True``.
              ``False`` keeps only non LCIA dependent allocation methods.
        base_cc_args: Carrying capacity family envelope. The package default
            is static active and dynamic AR6 inactive. Provide a
            ``dynamic_ar6`` block to add dynamic AR6 carrying capacities. Set
            ``static.active=False`` for dynamic only runs.

            Nested keys:

            - ``static``: Static carrying capacity branch. It is active by
              default unless ``active=False`` is provided.

              Nested keys:

              - ``active``: Whether the static branch is active. Defaults to
                ``True``.
              - ``exclude_max_cc``: Whether to use only ``min_cc``. Defaults
                to ``False``. ``False`` keeps the paired
                ``min_cc`` plus ``max_cc`` interpretation when ``max_cc`` is
                present. ``True`` uses only ``min_cc``.

            - ``dynamic_ar6``: Dynamic AR6 carrying capacity branch. It is
              inactive when omitted. When the block is provided, it is active
              unless ``active=False`` is provided. It uses top level
              ``years`` and requires at least two consecutive years.

              Nested keys:

              - ``active``: Whether the dynamic AR6 branch is active.
              - ``harmonization``: Whether to harmonize retained AR6 pathways
                to the historical baseline. Defaults to ``True``.
              - ``harmonization_method``: Harmonization method applied only
                when ``harmonization=True``. Defaults to ``"offset"``. The
                only supported value is currently ``"offset"``. Ignored when
                ``harmonization=False``.
              - ``category``: AR6 category classification selector for global
                warming trajectories, as a string or list, such as ``"C2"``
                or ``["C1", "C2"]``. Defaults to C1 to C4.
              - ``ssp_scenario``: Canonical SSP selector as a string, list,
                or ``None``, such as ``"SSP2"`` or ``["SSP1", "SSP2"]``.
                Defaults to SSP1 to SSP5.
              - ``emission_type``: Dynamic AR6 emission type. Accepted values
                are ``"kyoto_gases"`` (default) and ``"co2"``.
                ``emission_type="kyoto_gases"`` uses the GWP100 Kyoto Gases
                aggregate; ``emission_type="co2"`` uses direct CO2 pathways.
              - ``include_afolu``: Whether AFOLU is included inside the
                selected ``emission_type``. Defaults to ``False``.
              - ``emissions_mode``: Dynamic AR6 emissions mode. Accepted
                values are ``"net"``, ``"gross"``, and ``"gross_alt"``.
                Defaults to ``"gross_alt"``. Gross modes write positive
                emissions denominator rows and signed negative sequestration
                companion rows; downstream aCC and ASR consume only the
                denominator gross positive rows. ``"gross"`` removes all
                sequestration sources from net emissions. ``"gross_alt"``
                removes all sequestration sources except CCS, as it does not
                directly capture CO2 from the atmosphere; IPCC AR6 recommends
                treating CCS separately from net negative sequestration. See
                ``data_raw/methodological_notes/methodological_note__steady_state__dynamic_cc.pdf``
                for the methodological explanation.
              - ``subset_version``: Optional selector for a subset of AR6
                model-scenario pairs. Follow
                ``data_processed/ar6/<processed_scope>/README_model_scenario_subset.txt``
                to create the subset CSV.
        lca_args: Required LCA numerator route envelope. Exactly one route
            block must have ``active=True``. The default signature selects
            ``external_lca``. Set ``external_lca.active=False`` and
            ``io_lca.active=True`` to use IO-LCA generation.

            Nested keys:

            - ``external_lca``: External LCA route block.

              Nested keys:

              - ``active``: Whether staged external LCA files under
                ``A_lca/external_lca/`` are used.
              - ``version_name``: External LCA version selected from staged
                files. Use ``prepare_external_inputs(...)`` to import the
                external LCA real input folders, README guidance, and runnable CSV
                examples, then follow the imported README guidance for version syntax and
                data input format.

            - ``io_lca``: IO-LCA generation route block.

              Nested key:

              - ``active``: Whether IO-LCA generation is used.
        external_method: Optional external aSoCC method selector. Use
            ``{"l1_methods": [...]}`` for L1 functional units. For L2
            functional units use ``{"one_step_methods": [...]}`` and/or
            ``{"l1_l2_pairs": ["<l1_method>::<l2_method>", ...]}``.
            Omit this argument or pass ``None`` when using only native pyaesa
            deterministic aSoCC methods. Use ``prepare_external_inputs(...)``
            to import the external aSoCC README guidance and runnable CSV examples, then
            follow the imported README guidance for external method names, selector
            syntax, and deterministic or Monte Carlo external aSoCC CSV
            preparation.
        output_format: Persisted output file format: ``"csv"`` (default),
            ``"pickle"``, or ``"parquet"``.
        figures: Whether to render figures.
            Default is ``True``.
        figure_options: Deterministic ASR figure options. Defaults to
            ``{"per_method": True, "multi_method": True, "polar": {"active": True,``
            ``"polar_years": None}}``.

            Nested keys:

            - ``per_method``: Whether to render method specific figures, with
              one separate figure for each allocation method.
            - ``multi_method``: Whether to render cross method comparison
              figures, with multiple allocation methods shown in the same
              figure.
            - ``polar``: Nested deterministic polar figure selector. The
              block is optional and defaults to ``{"active": True,
              "polar_years": None}``. Its ``active`` key enables
              deterministic polar figures and defaults to ``True``. Its
              ``polar_years`` key selects studied output years evaluated by
              deterministic ASR polar figures; when omitted, polar figures
              use only the first and last studied years in the requested
              studied year set. Deterministic ASR does not support
              ``polar_style`` because deterministic polar figures use a fixed
              deterministic style.
        figure_format: Figure render settings mapping. Defaults to
            ``{"format": "png", "dpi": 500}``.

            Nested keys:

            - ``format``: Figure file format. Accepted values are ``"png"``,
              ``"pdf"``, and ``"svg"``.
            - ``dpi``: Positive integer figure resolution used for raster
              outputs.
        subfigures: Whether prerequisite LCA and dynamic AR6 CC figures are
            also rendered during the automatic prerequisite cascade when
            ``figures=True``. Default is ``True``.

        refresh: If ``True``, clear and recompute the resolved deterministic
            ASR output scope for this project, source and group version,
            numerator route, carrying capacity source, and carrying capacity
            type, plus the matching deterministic aCC prerequisite scope and,
            when the numerator route is IO-LCA, the IO-LCA prerequisite scope
            used by that request. Through the deterministic aCC prerequisite,
            this can include the matching deterministic aSoCC output scope
            and, when dynamic AR6 CC is used, the matching processed AR6
            output scope selected by ``process_ar6(...)`` and the matching
            ``deterministic_ar6_cc(...)`` output scope. The refresh removes the
            scope manifest plus recorded ASR result tables and figures for that
            scope before recomputation. For example, for
            ``project_name="demo"``, ``source="exiobase_3102_ixi"``,
            ``group_version="elec"``, external LCA version ``"test_v1"``, and
            static ``cc_source="gwp100_lcia"``, the refreshed scope is
            ``<repo>/demo/C_asr/exiobase_3102_ixi__elec/external_lca__test_v1/deterministic/static__gwp100_lcia``.
            External LCA staged inputs, processed MRIO inputs, processed
            population and GDP, and raw downloads are not refreshed. Defaults
            to ``False``.

    Returns:
        ``ComputeASRReport`` describing deterministic ASR table outputs and
        figure outputs when figures are requested.

    Raises:
        ValueError: If the shared scope is invalid or a prerequisite contract
            is not satisfied. This includes missing required envelope keys,
            envelope keys or values outside the accepted contract, dynamic AR6
            branches with a scenario dependent denominator aSoCC branch that
            uses a different SSP set from the selected dynamic AR6 scope, and
            external LCA routes whose SSP set is incompatible with the
            denominator side aSoCC scope.

    Notes:
        The repository root is taken from the package default configured by
        ``set_workspace()``; call ``set_workspace()`` before invoking this
        function.
        Required deterministic prerequisites are created or reused through
        ``deterministic_acc(...)`` and
        ``deterministic_io_lca(...)``. External LCA routes consume user staged
        deterministic LCA files.
        When denominator aSoCC shares are impact independent, ASR keeps the
        denominator impact category axis when matching numerator LCA rows.

    Example:
        Compute static ASR for ``L2.c.b`` producing sector ``Paper`` and
        consuming region ``FR`` with IO-LCA inputs::

            deterministic_asr(
                project_name="demo",
                source="exiobase_3102_ixi",
                years=range(2020, 2031),
                lcia_method="gwp100_lcia",
                fu_code="L2.c.b",
                s_p=["Paper"],
                r_c=["FR"],
                lca_args={
                    "external_lca": {"active": False, "version_name": None},
                    "io_lca": {"active": True},
                },
            )
    """
    shared_methods = normalize_shared_lcia_methods(lcia_method)
    requested_years = normalize_requested_years(years)
    mrio_scope = normalize_mrio_scope(
        source=source,
        group_reg=group_reg,
        group_sec=group_sec,
        group_version=group_version,
        aggreg_indices=aggreg_indices,
    )
    asocc_config = normalize_base_asocc_args(base_asocc_args, fu_code=fu_code)
    cc_config = normalize_base_cc_args(base_cc_args)
    lca_config = normalize_lca_args(lca_args)
    lca_type = selected_lca_type(lca_args=lca_config)
    lca_version_name = selected_lca_version_name(lca_args=lca_config)
    external_method_norm = normalize_external_method_selector(
        external_method,
        fu_code=fu_code,
        argument_name="external_method",
    )
    base_allocate_args = build_composite_base_allocate_args(
        project_name=project_name,
        years=years,
        lcia_method=shared_methods,
        fu_code=fu_code,
        r_p=r_p,
        s_p=s_p,
        r_c=r_c,
        r_f=r_f,
        source=cast(str, mrio_scope["source"]),
        group_reg=cast(bool, mrio_scope["group_reg"]),
        group_sec=cast(bool, mrio_scope["group_sec"]),
        group_version=cast(str | None, mrio_scope["group_version"]),
        aggreg_indices=cast(bool, mrio_scope["aggreg_indices"]),
        base_asocc_args=asocc_config,
    )
    native_selector = build_asocc_target_selector(base_asocc_args=base_allocate_args)
    validate_external_method_collisions(
        native_labels=native_selector.get("methods"),
        external_method=external_method_norm,
        fu_code=fu_code,
        where="deterministic_asr",
    )
    fmt = normalize_downstream_output_format(output_format)
    figure_options_norm = normalize_figure_options(
        figure_options,
        allow_single_year_style=False,
        allow_polar_years=False,
        allow_per_method=True,
        allow_multi_method=True,
        allow_polar=True,
        allow_nested_polar_style=False,
    )
    resolve_nested_polar_years(
        studied_years=requested_years,
        polar=dict(figure_options_norm["polar"]),
        argument_name="figure_options.polar",
    )
    figure_format_norm = normalize_figure_format(figure_format)
    if not isinstance(subfigures, bool):
        raise ValueError("subfigures must be a boolean. Use True or False.")
    subfigures_norm = all((figures, subfigures))
    figure_output_format = str(figure_format_norm["format"])
    figure_dpi = int(figure_format_norm["dpi"])
    proj_base = _resolve_proj_base(base_allocate_args)
    source_label = str(base_allocate_args["source"]).strip()
    branches: list[ASRBranchReport] = []
    for branch in iter_cc_method_branches(
        lcia_methods=shared_methods,
        base_cc_args=cc_config,
        years=years,
    ):
        is_dynamic_branch = branch["cc_type"] == "dynamic_ar6"
        if branch["cc_type"] == "static":
            require_asr_static_cc_source_compatibility(
                cc_source=branch["cc_source"],
                static_cc_bounds=list(branch["static_cc_bounds"]),
            )
        public_request_payload = build_public_composite_request_payload(
            project_name=project_name,
            years=years,
            lcia_method=[str(branch["cc_source"])],
            fu_code=fu_code,
            r_p=r_p,
            s_p=s_p,
            r_c=r_c,
            r_f=r_f,
            source=cast(str, mrio_scope["source"]),
            group_reg=cast(bool, mrio_scope["group_reg"]),
            group_sec=cast(bool, mrio_scope["group_sec"]),
            group_version=cast(str | None, mrio_scope["group_version"]),
            aggreg_indices=cast(bool, mrio_scope["aggreg_indices"]),
            base_asocc_args=asocc_config,
            base_cc_args=build_public_cc_branch_args(branch=branch),
            lca_args=lca_config,
            external_method=external_method_norm,
        )
        branch_static_cc_bounds = (
            list(branch["static_cc_bounds"])
            if branch["cc_type"] == "static"
            else list(branch["category"] or [])
        )
        branch_harmonization = cast(bool, branch["harmonization"]) if is_dynamic_branch else True
        branch_harmonization_method = (
            str(branch["harmonization_method"]) if is_dynamic_branch else "offset"
        )
        branch_category = branch["category"] if is_dynamic_branch else None
        branch_ssp_scenario = branch["ssp_scenario"] if is_dynamic_branch else None
        branch_emission_type = str(branch["emission_type"]) if is_dynamic_branch else "kyoto_gases"
        branch_include_afolu = cast(bool, branch["include_afolu"]) if is_dynamic_branch else False
        branch_emissions_mode = str(branch["emissions_mode"]) if is_dynamic_branch else "gross_alt"
        branch_subset_version = branch["subset_version"] if is_dynamic_branch else None
        if not refresh and not figures and not subfigures_norm and branch["cc_type"] == "static":
            path_context = build_asr_path_context(
                proj_base=proj_base,
                source_label=source_label,
                group_version=base_allocate_args["group_version"],
                fu_code=fu_code,
                lca_type=lca_type,
                cc_source=branch["cc_source"],
                cc_type=branch["cc_type"],
                lca_version_name=lca_version_name,
            )
            meta_path = get_asr_meta_path(context=path_context)
            existing_metadata = load_run_metadata(meta_path)
            identity_payload = branch_identity_payload(
                public_request_payload=public_request_payload,
                cc_type=branch["cc_type"],
            )
            coverage = branch_coverage(
                cc_type=branch["cc_type"],
                requested_years=normalize_requested_years(years),
                static_cc_bounds=branch_static_cc_bounds,
                category=branch_category,
                ssp_scenario=branch_ssp_scenario,
            )
            signature = _build_branch_signature(public_request_payload=identity_payload)
            if (
                existing_metadata
                and branch_reuse_mode_or_raise(
                    existing_metadata=existing_metadata,
                    requested_identity=signature,
                    requested_coverage=coverage,
                    scope_label=str(path_context),
                    function_name="deterministic_asr",
                )
                == "reuse"
            ):
                result = run_single_asr(
                    proj_base=proj_base,
                    build_branch_signature=_build_branch_signature,
                    build_figure_signature=_build_figure_signature,
                    public_request_payload=public_request_payload,
                    source_label=source_label,
                    base_allocate_args=base_allocate_args,
                    fu_code=fu_code,
                    external_method=external_method_norm,
                    cc_source=branch["cc_source"],
                    cc_type=branch["cc_type"],
                    years=years,
                    static_cc_bounds=branch_static_cc_bounds,
                    harmonization=branch_harmonization,
                    harmonization_method=branch_harmonization_method,
                    category=branch_category,
                    ssp_scenario=branch_ssp_scenario,
                    emission_type=branch_emission_type,
                    include_afolu=branch_include_afolu,
                    emissions_mode=branch_emissions_mode,
                    subset_version=branch_subset_version,
                    lca_type=lca_type,
                    lca_version_name=lca_version_name,
                    acc_output_files=[],
                    output_format=fmt,
                    figures=False,
                    figure_options=figure_options_norm,
                    figure_output_format=figure_output_format,
                    figure_dpi=figure_dpi,
                    subfigures=False,
                    refresh=False,
                    status=NullPhasePrinter(),
                )
                meta_file = cast(Path, result.meta_file)
                phase_index_path = phase_index_path_for_metadata(metadata_path=meta_file)
                branches.append(
                    replace(
                        result,
                        phase_entries=read_phase_index(metadata_path=meta_file),
                        phase_index_path=phase_index_path if phase_index_path.exists() else None,
                    )
                )
                continue
        phase = PhasePrinter("deterministic_asr")
        prerequisites = ensure_asr_branch_prerequisites(
            phase=phase,
            project_name=project_name,
            years=years,
            fu_code=fu_code,
            r_p=r_p,
            s_p=s_p,
            r_c=r_c,
            r_f=r_f,
            source=cast(str, mrio_scope["source"]),
            group_reg=cast(bool, mrio_scope["group_reg"]),
            group_sec=cast(bool, mrio_scope["group_sec"]),
            group_version=cast(str | None, mrio_scope["group_version"]),
            aggreg_indices=cast(bool, mrio_scope["aggreg_indices"]),
            base_asocc_args=asocc_config,
            branch=branch,
            external_method=external_method_norm,
            lca_type=lca_type,
            lca_version_name=lca_version_name,
            output_format=fmt,
            figures=subfigures_norm,
            figure_options=figure_options_norm,
            figure_output_format=figure_output_format,
            figure_dpi=figure_dpi,
            refresh=refresh,
        )
        phase_entries = prerequisites.phase_entries
        phase.announce(PHASE_C_ASR, "deterministic_asr")
        result = run_single_asr(
            proj_base=proj_base,
            build_branch_signature=_build_branch_signature,
            build_figure_signature=_build_figure_signature,
            public_request_payload=public_request_payload,
            source_label=source_label,
            base_allocate_args=base_allocate_args,
            fu_code=fu_code,
            external_method=external_method_norm,
            cc_source=branch["cc_source"],
            cc_type=branch["cc_type"],
            years=years,
            static_cc_bounds=branch_static_cc_bounds,
            harmonization=branch_harmonization,
            harmonization_method=branch_harmonization_method,
            category=branch_category,
            ssp_scenario=branch_ssp_scenario,
            emission_type=branch_emission_type,
            include_afolu=branch_include_afolu,
            emissions_mode=branch_emissions_mode,
            subset_version=branch_subset_version,
            lca_type=lca_type,
            lca_version_name=lca_version_name,
            acc_output_files=prerequisites.acc_output_files,
            output_format=fmt,
            figures=figures,
            figure_options=figure_options_norm,
            figure_output_format=figure_output_format,
            figure_dpi=figure_dpi,
            subfigures=subfigures_norm,
            refresh=refresh,
            status=phase,
        )
        meta_file = cast(Path, result.meta_file)
        branch_output_root = public_output_root_from_path(meta_file)
        if result.reuse_status == "reused_exact":
            phase.complete(
                phase_reused_detail(
                    scope_name="ASR",
                    output_root=branch_output_root,
                )
            )
        else:
            phase.complete(
                phase_ready_detail(
                    scope_name="ASR",
                    output_root=branch_output_root,
                )
            )
        result = replace(result, dynamic_ar6_summary=prerequisites.dynamic_ar6_summary)
        phase_entries.append(
            CompositePhaseIndexEntry(
                phase=PHASE_C_ASR,
                function="deterministic_asr",
                status="complete",
                reuse_status=public_phase_reuse_status(run_status=result.reuse_status),
                output_root=branch_output_root,
                summary_lines=asr_phase_summary_lines(branch=result),
                inventory_lines=asr_phase_inventory_lines(branch=result),
            )
        )
        result = replace(
            result,
            phase_entries=tuple(phase_entries),
            phase_index_path=write_phase_index(
                metadata_path=meta_file,
                entries=phase_entries,
            ),
        )
        branches.append(result)
        phase.finish()
    lca_route = lca_type if lca_version_name is None else f"{lca_type} ({lca_version_name})"
    report = ComputeASRReport(
        branches=branches,
        output_root=proj_base,
        common_lines=build_downstream_common_scope_lines(
            project_name=project_name,
            years=requested_years,
            lcia_methods=shared_methods,
            fu_code=fu_code,
            group_reg=cast(bool, mrio_scope["group_reg"]),
            group_sec=cast(bool, mrio_scope["group_sec"]),
            group_version=cast(str | None, mrio_scope["group_version"]),
            aggreg_indices=cast(bool, mrio_scope["aggreg_indices"]),
            ssp_scenarios=cast(list[str] | None, asocc_config.get("ssp_scenario")),
            lca_route=lca_route,
        ),
    )
    for branch in branches:
        meta_file = cast(Path, branch.meta_file)
        write_summary_log(
            path=summary_log_path(logs_dir=meta_file.parent),
            summary=str(report),
        )
    return report
