from __future__ import annotations

import sys
import uuid
from typing import Any, Dict, List, Optional

try:
    import pandas as pd
    _HAS_PANDAS = True
except ImportError:
    _HAS_PANDAS = False

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False

# Primary store: ref -> object
_STORE: Dict[str, Any] = {}

# Alias registry: latest_key -> current unique ref
# Keeps _latest pointers separate so deleting a unique ref
# does not silently leave a dangling _latest alias.
_LATEST: Dict[str, str] = {}


def _make_ref(function_name: str, output_key: str) -> tuple[str, str]:
    """Build a unique ref and its _latest alias from function + output key.

    Format:
        unique : obj_<full.module.function>.<output_key>_<6hex>
        latest : obj_<full.module.function>.<output_key>_latest
    """
    suffix = uuid.uuid4().hex[:6]
    base = f"obj_{function_name}.{output_key}" if function_name else f"obj_{output_key or 'unknown'}"
    return f"{base}_{suffix}", f"{base}_latest"


def store_object(obj: Any, *, function_name: str = "", output_key: str = "") -> str:
    """Store an object and return its unique ref.

    Also updates the _latest alias so callers can always access the most
    recent result of a function via ``obj_<module.fn>.<key>_latest``.

    Args:
        obj:           The object to store.
        function_name: Full qualified function name, e.g. mrkt.login.generate_new_token.
        output_key:    Output key name (without _ref suffix), e.g. result, df, features.

    Returns:
        Unique ref string, e.g. obj_mrkt.login.generate_new_token.result_a1b2c3
    """
    ref, latest_key = _make_ref(function_name, output_key)
    _STORE[ref] = obj
    _LATEST[latest_key] = ref
    return ref


def retrieve_object(ref: str) -> Optional[Any]:
    """Retrieve an object by ref or _latest alias."""
    # Resolve _latest alias first
    if ref in _LATEST:
        real_ref = _LATEST[ref]
        return _STORE.get(real_ref)
    return _STORE.get(ref)


def delete_object(ref: str) -> bool:
    """Delete an object by its unique ref.

    Also clears the _latest alias if it pointed to this ref.
    """
    if ref in _STORE:
        del _STORE[ref]
        # Clear any _latest alias that pointed to this ref
        stale = [k for k, v in _LATEST.items() if v == ref]
        for k in stale:
            del _LATEST[k]
        return True
    return False


def list_refs() -> Dict[str, List[str]]:
    """Return all refs grouped by unique refs and latest aliases.

    Returns:
        {
            "refs":   [...unique refs...],
            "latest": {...latest_key: unique_ref...}
        }
    """
    return {
        "refs": list(_STORE.keys()),
        "latest": dict(_LATEST),
    }


def object_count() -> int:
    return len(_STORE)


def _object_size(obj: Any) -> int:
    try:
        if _HAS_PANDAS and isinstance(obj, pd.DataFrame):
            return int(obj.memory_usage(deep=True).sum())
        if _HAS_NUMPY and isinstance(obj, np.ndarray):
            return obj.nbytes
        return sys.getsizeof(obj)
    except Exception:
        return 0


def summarize_object(ref: str) -> Optional[dict]:
    """Summarize a stored object by ref or _latest alias."""
    # Resolve alias
    actual_ref = _LATEST.get(ref, ref)
    obj = _STORE.get(actual_ref)
    if obj is None:
        return None

    type_name = type(obj).__name__
    summary: dict = {"type": type_name, "actual_ref": actual_ref}

    if _HAS_PANDAS and isinstance(obj, pd.DataFrame):
        summary["shape"] = list(obj.shape)
        summary["columns"] = list(obj.columns)
        summary["dtypes"] = {str(k): str(v) for k, v in obj.dtypes.items()}
        summary["memory_bytes"] = _object_size(obj)
        try:
            summary["preview"] = obj.head(5).to_dict(orient="records")
        except Exception:
            summary["preview"] = []

    elif _HAS_NUMPY and isinstance(obj, np.ndarray):
        summary["shape"] = list(obj.shape)
        summary["dtype"] = str(obj.dtype)
        summary["memory_bytes"] = obj.nbytes

    elif isinstance(obj, dict):
        summary["size"] = len(obj)
        summary["keys_preview"] = list(obj.keys())[:20]
        summary["memory_bytes"] = _object_size(obj)

    elif isinstance(obj, list):
        summary["length"] = len(obj)
        summary["memory_bytes"] = _object_size(obj)

    else:
        summary["repr"] = repr(obj)[:300]
        summary["memory_bytes"] = _object_size(obj)

    return summary


def get_memory_usage() -> dict:
    total = 0
    breakdown: Dict[str, int] = {}
    for ref, obj in _STORE.items():
        size = _object_size(obj)
        total += size
        breakdown[ref] = size
    return {"total_bytes": total, "objects": breakdown}
