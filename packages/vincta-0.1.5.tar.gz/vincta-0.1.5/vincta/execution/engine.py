from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional, Tuple

from vincta.object_store.store import store_object, retrieve_object

try:
    import pandas as pd
    _HAS_PANDAS = True
except ImportError:
    _HAS_PANDAS = False

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False

# Max byte size of JSON-serialized value to include inline alongside the ref.
# Configurable via VINCTA_INLINE_MAX_BYTES env var. Default: 10 MB.
_INLINE_MAX_BYTES: int = int(os.environ.get("VINCTA_INLINE_MAX_BYTES", 10 * 1024 * 1024))


def _is_obj_ref(value: Any) -> bool:
    return isinstance(value, str) and value.startswith("obj_")


def _resolve_inputs(raw_inputs: Dict[str, Any]) -> Dict[str, Any]:
    resolved: Dict[str, Any] = {}
    for key, value in raw_inputs.items():
        if _is_obj_ref(value):
            obj = retrieve_object(value)
            if obj is None:
                raise KeyError(f"Object ref '{value}' not found in store")
            resolved[key] = obj
        else:
            resolved[key] = value
    return resolved


def _ref_key(declared_key: str) -> str:
    """Response JSON key for the ref.
    If declared key already ends with _ref keep it, otherwise append _ref.
    """
    return declared_key if declared_key.endswith("_ref") else f"{declared_key}_ref"


def _value_key(declared_key: str) -> str:
    """Response JSON key for the inline value and the object store output_key.
    Strip _ref suffix if present, otherwise use as-is.
    """
    return declared_key[:-4] if declared_key.endswith("_ref") else declared_key


def _try_serialize(obj: Any) -> Optional[Tuple[Any, int]]:
    """Try to JSON-serialize obj. Returns (obj, byte_size) or None."""
    if _HAS_PANDAS and isinstance(obj, pd.DataFrame):
        return None
    if _HAS_NUMPY and isinstance(obj, np.ndarray):
        return None
    try:
        serialized = json.dumps(obj)
        return obj, len(serialized.encode("utf-8"))
    except (TypeError, ValueError):
        return None


def _package_output(
    value: Any,
    declared_key: str,
    function_name: str = "",
) -> Dict[str, Any]:
    """Always store value in object store with readable ref naming.

    Ref format:
        obj_<full.module.function>.<output_key>_<6hex>   (unique)
        obj_<full.module.function>.<output_key>_latest    (alias, auto-updated)

    Returns the ref always. Also returns the inline value if JSON-serializable
    and under the configured byte threshold (VINCTA_INLINE_MAX_BYTES).
    """
    out_key = _value_key(declared_key)
    ref = store_object(value, function_name=function_name, output_key=out_key)

    ref_k = _ref_key(declared_key)
    result: Dict[str, Any] = {ref_k: ref}

    inline = _try_serialize(value)
    if inline is not None:
        _, byte_size = inline
        if byte_size <= _INLINE_MAX_BYTES:
            result[out_key] = value

    return result


def execute(function_name: str, raw_inputs: Dict[str, Any]) -> Dict[str, Any]:
    from vincta.registry.registry import get_function, AmbiguousNameError

    try:
        entry = get_function(function_name)
    except AmbiguousNameError:
        raise

    if entry is None:
        raise ValueError(f"Function '{function_name}' not found in registry")

    fn = entry["fn"]
    # Use the full registered name for readable ref naming
    full_name = entry["name"]
    declared_outputs: Dict[str, str] = entry.get("outputs", {})

    resolved = _resolve_inputs(raw_inputs)
    result = fn(**resolved)

    if result is None:
        return {}

    # Tuple return -> zip with declared output keys
    if isinstance(result, tuple):
        output_keys = list(declared_outputs.keys())
        packaged: Dict[str, Any] = {}
        for i, val in enumerate(result):
            key = output_keys[i] if i < len(output_keys) else f"result_{i}"
            packaged.update(_package_output(val, key, function_name=full_name))
        return packaged

    # Single return value
    key = next(iter(declared_outputs), "result")
    return _package_output(result, key, function_name=full_name)
