from __future__ import annotations

import ast
import importlib.util
import inspect
import sys
import types
from pathlib import Path
from typing import List, Optional

_ALWAYS_EXCLUDE = {"__pycache__", ".git", ".venv", "venv", "node_modules", ".mypy_cache"}

# Top-level AST node types that are safe to execute during discovery.
# Everything else (bare calls, loops, with-blocks) is skipped to prevent
# side effects from scripts that lack an if __name__ == "__main__" guard.
_SAFE_NODES = (
    ast.Import,
    ast.ImportFrom,
    ast.FunctionDef,
    ast.AsyncFunctionDef,
    ast.ClassDef,
    ast.Assign,       # module-level constants, logger = ..., app = ...
    ast.AnnAssign,    # annotated assignments
    ast.AugAssign,    # x += ...
    ast.If,           # TYPE_CHECKING guards and __name__ == "__main__" blocks
    ast.Try,          # import fallbacks: try: import ujson except: import json
)


def _should_exclude(path: Path, patterns: List[str]) -> bool:
    for part in path.parts:
        if part in _ALWAYS_EXCLUDE:
            return True
    for pattern in patterns:
        if path.match(pattern):
            return True
    return False


def _path_to_module_name(file: Path, base: Path) -> str:
    rel = file.relative_to(base)
    parts = list(rel.with_suffix("").parts)
    return ".".join(parts)


def _safe_exec(py_file: Path, module: types.ModuleType) -> int:
    """Execute only the safe top-level statements of a module.

    Skips bare expression statements (e.g. ``main()``, ``run()``) and
    control flow (``for``, ``while``, ``with``) that would cause side
    effects when a script is imported without an __name__ guard.

    Returns the number of top-level statements that were skipped.
    """
    source = py_file.read_text(encoding="utf-8", errors="replace")
    tree = ast.parse(source, filename=str(py_file))

    safe_body = []
    skipped = 0
    for node in tree.body:
        if isinstance(node, _SAFE_NODES):
            safe_body.append(node)
        else:
            skipped += 1

    if skipped:
        print(
            f"[discovery] {py_file.name}: skipped {skipped} top-level "
            f"statement(s) to prevent side effects (wrap in "
            f"'if __name__ == \"__main__\"' to suppress this warning)"
        )

    safe_tree = ast.Module(body=safe_body, type_ignores=[])
    ast.fix_missing_locations(safe_tree)
    code = compile(safe_tree, str(py_file), "exec")
    exec(code, module.__dict__)
    return skipped


def _auto_register_module_functions(module: types.ModuleType) -> int:
    from vincta.registry.registry import is_registered, register

    count = 0
    for attr_name, obj in inspect.getmembers(module, inspect.isfunction):
        if attr_name.startswith("_"):
            continue
        # Only register functions defined in this module (not imported ones)
        if getattr(obj, "__module__", None) != module.__name__:
            continue
        if is_registered(obj):
            continue
        qualified_name = f"{module.__name__}.{attr_name}"
        try:
            register(obj, name=qualified_name, module=module.__name__)
            count += 1
        except ValueError:
            # Already registered (duplicate full name) — skip silently
            pass
    return count


def discover_and_import(
    directories: List[Path],
    exclude_patterns: Optional[List[str]] = None,
    extra_sys_paths: Optional[List[Path]] = None,
) -> dict:
    exclude_patterns = exclude_patterns or []
    results = {"imported": [], "auto_registered": 0, "errors": [], "skipped_statements": 0}

    # Prepend caller-supplied paths first so they win over anything already
    # on sys.path. Typical use: dependency directories for codebases that
    # use flat (non-package) imports.
    for p in reversed(extra_sys_paths or []):
        s = str(p)
        if p.exists() and s not in sys.path:
            sys.path.insert(0, s)

    for directory in directories:
        if not directory.exists():
            continue

        # Add both the directory and its parent to sys.path.
        # - parent    -> enables `import <dirname>.<module>` style
        # - directory -> enables flat `from <module> import ...` style
        for p in (directory.parent, directory):
            s = str(p)
            if s not in sys.path:
                sys.path.insert(0, s)

        for py_file in sorted(directory.rglob("*.py")):
            if _should_exclude(py_file, exclude_patterns):
                continue
            if py_file.name == "__init__.py":
                continue

            module_name = _path_to_module_name(py_file, directory.parent)

            try:
                if module_name in sys.modules:
                    module = sys.modules[module_name]
                else:
                    spec = importlib.util.spec_from_file_location(module_name, py_file)
                    if spec is None or spec.loader is None:
                        continue
                    module = types.ModuleType(module_name)
                    module.__name__ = module_name
                    module.__file__ = str(py_file)
                    module.__spec__ = spec
                    sys.modules[module_name] = module
                    skipped = _safe_exec(py_file, module)
                    results["skipped_statements"] += skipped

                count = _auto_register_module_functions(module)
                results["imported"].append(module_name)
                results["auto_registered"] += count

            except Exception as e:
                msg = f"{py_file}: {e}"
                results["errors"].append(msg)
                print(f"[discovery] Failed to import {msg}")

    return results
