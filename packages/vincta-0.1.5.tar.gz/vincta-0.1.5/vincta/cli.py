from __future__ import annotations

import argparse
import os
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="vincta",
        description="Pure function orchestration engine - serve Python functions over HTTP.",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument(
        "--dir",
        action="append",
        dest="dirs",
        default=[],
        metavar="DIR",
        help="Directory to discover functions from (repeatable)",
    )
    parser.add_argument(
        "--sys-path",
        action="append",
        dest="sys_paths",
        default=[],
        metavar="PATH",
        help="Extra path prepended to sys.path before discovery (repeatable)",
    )
    parser.add_argument(
        "--exclude",
        default="test_*,*.test.py",
        help="Comma-separated glob patterns to exclude from discovery",
    )
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (development)")
    parser.add_argument(
        "--workers", type=int, default=1, help="Number of worker processes (ignored with --reload)"
    )

    args = parser.parse_args()

    if args.dirs:
        os.environ["VINCTA_DIRS"] = os.pathsep.join(args.dirs)
    if args.sys_paths:
        os.environ["VINCTA_SYS_PATHS"] = os.pathsep.join(args.sys_paths)
    os.environ["VINCTA_EXCLUDE"] = args.exclude

    try:
        import uvicorn
    except ImportError:
        print("uvicorn is required: pip install uvicorn[standard]", file=sys.stderr)
        sys.exit(1)

    uvicorn.run(
        "vincta.server:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=1 if args.reload else args.workers,
    )


if __name__ == "__main__":
    main()
