from typing import Any, Dict

from fastapi import APIRouter, HTTPException

from vincta.registry.registry import AmbiguousNameError
from vincta.schemas.models import RunRequest
from vincta.services.execution_service import run_function

router = APIRouter(prefix="/function", tags=["execution"])


@router.post("/run", response_model=Dict[str, Any])
def run_function_endpoint(req: RunRequest) -> Dict[str, Any]:
    """Execute a registered function by name.

    - Use the full qualified name (e.g. ``transforms.compute_returns``) for precision.
    - Short names (e.g. ``compute_returns``) work if unique across all modules.
    - Ambiguous short names return 400 with the list of matching full names.

    Inputs that are object refs (``obj_*``) are automatically resolved from the
    object store before calling the function.

    Every output is stored in the object store. The ref is always returned.
    The inline value is also returned if it is JSON-serializable and under
    the configured size threshold (default 10 MB).
    """
    try:
        return run_function(req.function, req.inputs)
    except AmbiguousNameError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except KeyError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except TypeError as e:
        raise HTTPException(status_code=422, detail=f"Argument error: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Execution error: {e}")
