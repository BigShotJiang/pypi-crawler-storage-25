﻿from fastapi import APIRouter

from vincta.registry.registry import list_functions
from vincta.schemas.models import FunctionListResponse, FunctionSchema

router = APIRouter(prefix="/functions", tags=["functions"])


@router.get("", response_model=FunctionListResponse)
def get_functions():
    """Return all registered functions with their schemas and descriptions."""
    entries = list_functions()
    return FunctionListResponse(
        functions=[
            FunctionSchema(
                name=e["name"],
                module=e["module"],
                description=e.get("description"),
                inputs=e["inputs"],
                outputs=e["outputs"],
            )
            for e in entries
        ]
    )


