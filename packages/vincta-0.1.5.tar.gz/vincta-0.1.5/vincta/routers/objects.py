from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException

from vincta.object_store.store import (
    delete_object,
    get_memory_usage,
    list_refs,
    summarize_object,
)
from vincta.schemas.models import (
    DeleteResponse,
    MemoryStats,
    ObjectListResponse,
    ObjectSummary,
)

router = APIRouter(prefix="/object", tags=["objects"])


@router.get("/list", response_model=ObjectListResponse)
def list_objects():
    """List all object refs and their _latest aliases currently in the store."""
    data = list_refs()
    return ObjectListResponse(refs=data["refs"], latest=data["latest"])


@router.get("/memory", response_model=MemoryStats)
def memory_stats():
    """Return memory usage breakdown for all stored objects."""
    usage = get_memory_usage()
    return MemoryStats(total_bytes=usage["total_bytes"], objects=usage["objects"])


@router.get("/{ref:path}", response_model=ObjectSummary)
def get_object_summary(ref: str):
    """Preview a stored object by unique ref or _latest alias.
    Returns metadata and a head sample, never the full payload.
    """
    summary = summarize_object(ref)
    if summary is None:
        raise HTTPException(status_code=404, detail=f"Object '{ref}' not found")
    obj_type = summary.pop("type")
    return ObjectSummary(ref=ref, type=obj_type, summary=summary)


@router.delete("/{ref:path}", response_model=DeleteResponse)
def delete_object_endpoint(ref: str):
    """Remove an object from the store and free its memory.
    Also clears the _latest alias if it pointed to this ref.
    """
    if not delete_object(ref):
        raise HTTPException(status_code=404, detail=f"Object '{ref}' not found")
    return DeleteResponse(deleted=ref)
