from vincta.cli import main

main()
