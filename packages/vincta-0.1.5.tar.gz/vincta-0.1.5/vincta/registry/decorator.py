from __future__ import annotations

from typing import Callable, Dict, Optional

from vincta.registry.registry import register


def register_function(
    name: Optional[str] = None,
    inputs: Optional[Dict[str, str]] = None,
    outputs: Optional[Dict[str, str]] = None,
    description: Optional[str] = None,
    overwrite: bool = False,
):
    """Decorator for explicit function registration with schema override.

    The full qualified name (module.function) is used as the registry key.
    Short names are supported at call time if they are unambiguous.

    Usage::

        @register_function(
            name="transforms.clean_data",
            inputs={"df_ref": "str", "threshold": "float"},
            outputs={"clean_ref": "str"},
            description="Drop rows with nulls above threshold.",
        )
        def clean_data(df: pd.DataFrame, threshold: float) -> pd.DataFrame:
            ...

        # Overwrite an existing registration
        @register_function(name="transforms.clean_data", overwrite=True)
        def clean_data_v2(df: pd.DataFrame, threshold: float) -> pd.DataFrame:
            ...

    Decorator schema takes precedence over inferred type hints.
    """
    def decorator(fn: Callable) -> Callable:
        register(
            fn,
            name=name,
            inputs=inputs,
            outputs=outputs,
            description=description,
            explicit=True,
            overwrite=overwrite,
        )
        return fn

    return decorator
