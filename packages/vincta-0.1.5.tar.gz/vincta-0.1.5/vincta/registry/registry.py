from __future__ import annotations

import inspect
import typing
from typing import Any, Callable, Dict, List, Optional

try:
    import pandas as pd
    _PD_DATAFRAME = pd.DataFrame
except ImportError:
    _PD_DATAFRAME = None

try:
    import numpy as np
    _NP_NDARRAY = np.ndarray
except ImportError:
    _NP_NDARRAY = None

# Keyed by full qualified name (module.function).
_REGISTRY: Dict[str, dict] = {}

# Short name index: last segment -> [full qualified names]
_SHORT_INDEX: Dict[str, List[str]] = {}

# Tracks function object ids registered via decorator so auto-discovery skips them.
_REGISTERED_FN_IDS: set = set()


class AmbiguousNameError(Exception):
    """Raised when a short function name matches more than one registered function."""
    def __init__(self, name: str, matches: List[str]):
        options = "\n  ".join(matches)
        super().__init__(
            f"Function name '{name}' is ambiguous. Use the full qualified name:\n  {options}"
        )
        self.name = name
        self.matches = matches


def _type_to_str(t: Any) -> str:
    if t is inspect.Parameter.empty or t is type(None):
        return "Any"
    if _PD_DATAFRAME is not None and t is _PD_DATAFRAME:
        return "DataFrame"
    if _NP_NDARRAY is not None and t is _NP_NDARRAY:
        return "ndarray"
    origin = getattr(t, "__origin__", None)
    if origin is not None:
        args = getattr(t, "__args__", ())
        origin_name = getattr(origin, "__name__", str(origin))
        if args:
            arg_strs = ", ".join(_type_to_str(a) for a in args)
            return f"{origin_name}[{arg_strs}]"
        return origin_name
    if hasattr(t, "__name__"):
        return t.__name__
    return str(t)


def _extract_schema(fn: Callable) -> dict:
    try:
        hints = typing.get_type_hints(fn)
    except Exception:
        hints = {}

    sig = inspect.signature(fn)
    inputs: Dict[str, str] = {}

    for param_name, param in sig.parameters.items():
        if param_name == "self":
            continue
        hint = hints.get(param_name, inspect.Parameter.empty)
        inputs[param_name] = _type_to_str(hint)

    return_hint = hints.get("return", inspect.Parameter.empty)
    if return_hint is type(None) or return_hint is inspect.Parameter.empty:
        outputs: Dict[str, str] = {}
    else:
        outputs = {"result": _type_to_str(return_hint)}

    return {
        "inputs": inputs,
        "outputs": outputs,
        "description": inspect.getdoc(fn),
    }


def _short_name(full_name: str) -> str:
    """Last segment of a dotted name: 'transforms.compute_returns' -> 'compute_returns'."""
    return full_name.rsplit(".", 1)[-1]


def _add_to_short_index(full_name: str) -> None:
    short = _short_name(full_name)
    if short not in _SHORT_INDEX:
        _SHORT_INDEX[short] = []
    if full_name not in _SHORT_INDEX[short]:
        _SHORT_INDEX[short].append(full_name)


def _remove_from_short_index(full_name: str) -> None:
    short = _short_name(full_name)
    if short in _SHORT_INDEX:
        _SHORT_INDEX[short] = [n for n in _SHORT_INDEX[short] if n != full_name]
        if not _SHORT_INDEX[short]:
            del _SHORT_INDEX[short]


def register(
    fn: Callable,
    *,
    name: Optional[str] = None,
    inputs: Optional[Dict[str, str]] = None,
    outputs: Optional[Dict[str, str]] = None,
    description: Optional[str] = None,
    module: Optional[str] = None,
    explicit: bool = False,
    overwrite: bool = False,
) -> None:
    _module = module or getattr(fn, "__module__", "unknown")

    # Default name: module.qualname — ensures uniqueness across modules
    fn_name = name or f"{_module}.{fn.__qualname__}"

    # Duplicate guard
    if fn_name in _REGISTRY and not overwrite:
        raise ValueError(
            f"Function '{fn_name}' is already registered. "
            "Use overwrite=True to replace it."
        )

    schema = _extract_schema(fn)
    if inputs is not None:
        schema["inputs"] = inputs
    if outputs is not None:
        schema["outputs"] = outputs
    if description is not None:
        schema["description"] = description

    # Remove stale short-index entry if overwriting
    if fn_name in _REGISTRY:
        _remove_from_short_index(fn_name)

    _REGISTRY[fn_name] = {
        "fn": fn,
        "name": fn_name,
        "module": _module,
        "inputs": schema["inputs"],
        "outputs": schema["outputs"],
        "description": schema["description"],
    }

    _add_to_short_index(fn_name)

    if explicit:
        _REGISTERED_FN_IDS.add(id(fn))


def is_registered(fn: Callable) -> bool:
    return id(fn) in _REGISTERED_FN_IDS


def get_function(name: str) -> Optional[dict]:
    # 1. Exact match (full qualified name)
    if name in _REGISTRY:
        return _REGISTRY[name]

    # 2. Short name lookup
    matches = _SHORT_INDEX.get(name, [])
    if len(matches) == 1:
        return _REGISTRY[matches[0]]
    if len(matches) > 1:
        raise AmbiguousNameError(name, matches)

    return None


def list_functions() -> List[dict]:
    return [
        {k: v for k, v in entry.items() if k != "fn"}
        for entry in _REGISTRY.values()
    ]


def function_count() -> int:
    return len(_REGISTRY)
