﻿from typing import Any, Dict

from vincta.execution.engine import execute


def run_function(function_name: str, inputs: Dict[str, Any]) -> Dict[str, Any]:
    return execute(function_name, inputs)


