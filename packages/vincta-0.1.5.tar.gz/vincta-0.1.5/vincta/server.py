from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI

from vincta.routers import execution, functions, objects
from vincta.registry.registry import function_count
from vincta.object_store.store import object_count


def _discovery_config():
    dirs_raw = os.environ.get("VINCTA_DIRS", "")
    paths_raw = os.environ.get("VINCTA_SYS_PATHS", "")
    exclude_raw = os.environ.get("VINCTA_EXCLUDE", "test_*,*.test.py")
    dirs = [Path(d) for d in dirs_raw.split(os.pathsep) if d]
    sys_paths = [Path(p) for p in paths_raw.split(os.pathsep) if p]
    exclude = [p.strip() for p in exclude_raw.split(",") if p.strip()]
    return dirs, sys_paths, exclude


@asynccontextmanager
async def lifespan(app: FastAPI):
    from vincta.discovery.autodiscover import discover_and_import

    dirs, sys_paths, exclude = _discovery_config()
    results = discover_and_import(dirs, exclude, sys_paths)
    print(f"[startup] Imported modules:   {results['imported']}")
    print(f"[startup] Auto-registered:    {results['auto_registered']} functions")
    if results.get("skipped_statements"):
        print(f"[startup] Skipped statements: {results['skipped_statements']} (top-level calls/loops — wrap in __main__ guard to silence)")
    if results["errors"]:
        print(f"[startup] Import errors:      {results['errors']}")
    yield


app = FastAPI(
    title="vincta",
    description=(
        "Pure function orchestration engine - auto-discover and serve Python functions "
        "over HTTP with a built-in RAM object store."
    ),
    version="0.1.5",
    lifespan=lifespan,
)

app.include_router(functions.router)
app.include_router(execution.router)
app.include_router(objects.router)


@app.get("/health", tags=["meta"])
def health():
    return {
        "status": "ok",
        "registered_functions": function_count(),
        "stored_objects": object_count(),
    }
