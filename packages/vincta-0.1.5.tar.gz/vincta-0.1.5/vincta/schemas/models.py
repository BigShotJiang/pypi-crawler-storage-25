from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class FunctionSchema(BaseModel):
    name: str
    module: str
    description: Optional[str] = None
    inputs: Dict[str, str]
    outputs: Dict[str, str]


class FunctionListResponse(BaseModel):
    functions: List[FunctionSchema]


class RunRequest(BaseModel):
    function: str
    inputs: Dict[str, Any] = {}


class ObjectSummary(BaseModel):
    ref: str
    type: str
    summary: Dict[str, Any]


class MemoryStats(BaseModel):
    total_bytes: int
    objects: Dict[str, int]


class ObjectListResponse(BaseModel):
    refs: List[str]
    latest: Dict[str, str] = {}   # latest_key -> current unique ref


class DeleteResponse(BaseModel):
    deleted: str


class HealthResponse(BaseModel):
    status: str
    registered_functions: int
    stored_objects: int
