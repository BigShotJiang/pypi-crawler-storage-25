import asyncio
import datetime
import hashlib
import os
import re as regex
import string
import sys
import zlib
from collections.abc import Coroutine
from io import StringIO
from pathlib import Path
from typing import Any, TextIO
from urllib.parse import urlparse

import aiofiles
import click
import httpx
import requests
import urllib3
from bs4 import BeautifulSoup, Tag
from dateutil.parser import parse
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TaskProgressColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.theme import Theme
from tqdm import tqdm
from tqdm.asyncio import tqdm as async_tqdm


def crc32_str(encode_string: str) -> int:
    """crc32 checksum of string"""
    return zlib.crc32(bytes(encode_string, "utf-8"))


def md5_str(encode_string: str) -> str:
    """md5 checksum of string"""
    return hashlib.md5(bytes(encode_string, "utf-8")).hexdigest()


def get_filename(url: str) -> str:
    """Get filename from url"""
    name = urlparse(url).path
    name = Path(name).name
    return name


def append_filename(target: Path) -> Path:
    """Append -1 to filename if exists"""
    cp_count = 1
    while target.exists():
        if cp_count == 1:
            pth = Path(target.name)
            name, ext = pth.stem, pth.suffix
            target = Path(f"{target.parent}/{name}-1.{ext}")
        else:
            target = Path(
                regex.sub("(-\d{,3})?(\..*?)$", f"-{cp_count}\\2", str(target), regex.I)
            )
        cp_count += 1
    return target


def hash_filename(link: str, fn: str) -> tuple[str, str]:
    """
    Get a hash of the link and use it for the filename, returns crc and md5 filenames
    """

    crc = crc32_str(link)
    md5 = md5_str(link)
    pth = Path(fn)
    nm, ext = pth.stem, pth.suffix
    crc_out = f"{nm}_{crc}{ext}"
    md5_out = f"{nm}_{md5}{ext}"
    return crc_out, md5_out


def get_latest_user_agent(mobile: bool = False) -> str | None:
    """
    Get latest user agent from https://www.useragents.me/
    TODO:
    Update with newer modules, like hrequests/browserforge
    """

    r = requests.get("https://www.useragents.me/", timeout=10)
    soup: BeautifulSoup = BeautifulSoup(r.content, "html.parser")
    selector_id = (
        "latest-windows-desktop-useragents"
        if not mobile
        else "latest-android-mobile-useragents"
    )

    def get_ua_string(soup: BeautifulSoup) -> str | None:
        # ua_string = (
        #     soup.select_one(f"h2#{selector_id} + p + p + div.table-responsive")
        #     .select_one(".ua-textarea")
        #     .text
        # )
        sel: Tag | None = soup.select_one(
            f"h2#{selector_id} + p + p + div.table-responsive"
        )
        if sel:
            sel2: Tag | None = sel.select_one(".ua-textarea")
            if sel2:
                text: str = sel2.text
                return text
        return None

    ua_string: str | None = get_ua_string(soup)
    return ua_string


def parse_bytes(value: str | int, suffixes: str = "bkmgtp") -> float:
    """
    Convert a bytes-amount ("500k", "2.5M", ...) to an integer.

    Args:
        value (str): The bytes-amount value to be converted.
        suffixes (str, optional): The list of suffixes to be used for conversion. Defaults to "bkmgtp".

    Returns:
        int: The converted bytes-amount value.

    """

    # Get the last character of the value and convert it to lowercase
    if isinstance(value, str):
        # Set the value float
        value_num: float = float("".join(v for v in value if v in string.digits + "."))
        # Set the suffix, defaulting to 'b' if none is provided
        last: str = value[-1].lower() if value[-1].lower() in suffixes else "b"
    else:
        # Set the value float
        value_num = float(value)
        # Set the suffix, since the value isn't a string, assuming it is 'b'
        last = "b"

    # Calculate the multiplier
    mul = 1024 ** suffixes.index(last)

    # Return the converted value
    return round(float(value_num) * mul)


async def async_get_latest_user_agent(mobile: bool = False) -> str | None:
    """
    Get latest user agent from https://www.useragents.me/ asyncronously
    """

    client: httpx.AsyncClient = httpx.AsyncClient()
    r: httpx.Response = await client.get("https://www.useragents.me/")
    soup: BeautifulSoup = BeautifulSoup(r.content, "html.parser")
    selector_id: str = (
        "latest-windows-desktop-useragents"
        if not mobile
        else "latest-android-mobile-useragents"
    )

    def get_ua_string(soup: BeautifulSoup) -> str | None:
        # ua_string = (
        #     soup.select_one(f"h2#{selector_id} + p + p + div.table-responsive")
        #     .select_one(".ua-textarea")
        #     .text
        # )
        sel: Tag | None = soup.select_one(
            f"h2#{selector_id} + p + p + div.table-responsive"
        )
        if sel:
            sel2: Tag | None = sel.select_one(".ua-textarea")
            if sel2:
                text: str = sel2.text
                return text
        return None

    ua_string: str | None = get_ua_string(soup)
    return ua_string


def pywget(
    url: str,
    path: str = "./",
    filename: str = "",
    timestamping: bool = False,
    noclobber: bool = False,
    cont: bool = False,
    overwrite: bool = False,
    quiet: bool = False,
    crc_name: bool = False,
    md5_name: bool = False,
    force_filename: bool = False,
    spder: bool = False,
    stdout: TextIO = sys.stdout,
    hide_ignore: bool = False,
    session: requests.Session = requests.Session(),
    use_rich: bool = False,
    get_user_agent: bool = False,
    use_mobile_user_agent: bool = False,
    min_filesize: str | int | None = None,
    max_filesize: str | int | None = None,
    verify_ssl: bool = True,
) -> dict | None:
    """
    :param url:
    URL to download.
    :param path:
    Folder to download files to, can be relative or absolute. Accepts pathlib objects.
    :param filename:
    Optional: set file instead of getting it from url
    :param timestamping:
    Don't download if already saved file is newer than url.
    :param noclobber:
    Don't download already saved files, no overwrite.
    :param cont:
    Continue downloads.
    :param overwrite:
    Overwrite original file
    :param rename:
    Rename new downloads instead of overwrite
    :param quiet:
    Hide all download progress
    :param crc_name:
    Append crc32 value of link to filename
    :param md5_name:
    Append md5 value of link to filename
    :param force_filename:
    Don't try and get filename, only use the one provided
    :param spder:
    Print the file name and info for the url. Does not download.
    :param stdout:
    Provide a custom file to output print statements to.
    :param hide_ignore:
    If true, hide the print statements for noclobber and timestamping conflicts. Will be overriden by the quiet parameter.
    :param use_rich:
    If true, use the rich module for the progress bar. If false, will use tqdm for the progress bar.
    :param get_user_agent:
    If true, get latest desktop user-agent, if false use none
    :param use_mobile_user_agent:
    If true and 'get_user_agent' is also true, use the latest mobile/android user agent. If false will be ignored.
    :param min_filesize:
    Minimum file size to download. Ignored if None is passed or if content-length header is not returned.
    :param max_filesize:
    Maximum file size to download. Ignored if None is passed or if content-length header is not returned.
    :param verify_ssl:
    Verify SSL certificate
    :return:
    """

    if not verify_ssl:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    if spder:
        spider_result: dict = spider(url)
        return spider_result

    blank: TextIO = StringIO()  # open("nul", "w")
    fl_out: TextIO = stdout if not quiet else blank
    ignore_messages: TextIO = stdout if not any([quiet, hide_ignore]) else blank
    if force_filename or filename:
        fn: str = filename
    else:
        fn = get_filename(url)

    out_path: str = path if path else "./"

    crc_fn, md5_fn = hash_filename(url, fn)
    if crc_name:
        fn = crc_fn
    elif md5_name:
        fn = md5_fn

    output: Path = Path(out_path, fn)
    headers: dict = {}
    if get_user_agent:
        headers["user-agent"] = get_latest_user_agent(mobile=use_mobile_user_agent)
    writemode = "wb"
    tz = datetime.datetime.now().astimezone().tzinfo

    if output.exists():
        if cont:
            headers["Range"] = f"bytes={output.stat().st_size}-"
            writemode = "ab"
        elif timestamping:
            file_stat = os.stat(output)
            resp = session.get(url, stream=True, allow_redirects=True)
            if "last-modified" in resp.headers.keys():
                modtime = parse(resp.headers["last-modified"]).astimezone(tz=tz)
            else:
                modtime = datetime.datetime.now()
            if file_stat.st_mtime >= modtime.timestamp():
                print(
                    f'"{fn}" exists, ignoring because of timestamping (-n).',
                    file=ignore_messages,
                )
                return None
        elif noclobber:
            print(
                f'"{fn}" exists, ignoring because of noclobber (-nc).',
                file=ignore_messages,
            )
            return None
        elif overwrite:
            pass
        else:
            output = append_filename(output)

    os.makedirs(output.parent, exist_ok=True)
    if "resp" not in locals():
        resp = session.get(
            url, stream=True, allow_redirects=True, headers=headers, verify=verify_ssl
        )

    if (status_code := resp.status_code) in range(400, 600):
        raise requests.exceptions.HTTPError(
            f"Error code {status_code} on url, stopping."
        )

    if "modtime" not in locals():
        if "last-modified" in resp.headers.keys():
            modtime = parse(resp.headers["last-modified"]).astimezone(tz=tz)
        else:
            modtime = datetime.datetime.now()

    if "content-length" in resp.headers.keys():
        content_length = int(resp.headers["content-length"])
    else:
        content_length = None

    if min_filesize and content_length:
        min_bytes = parse_bytes(min_filesize)
        if content_length < min_bytes:
            return None
    if max_filesize and content_length:
        max_bytes = parse_bytes(max_filesize)
        if content_length > max_bytes:
            return None

    try:
        if not use_rich:
            # tqdm
            with open(output, writemode) as f:
                with tqdm(
                    total=content_length,
                    unit="B",
                    unit_scale=True,
                    desc=output.name[:75],
                    initial=0,
                    ascii=True,
                    disable=quiet,
                    file=fl_out,
                ) as pbar:
                    for chunk in resp.iter_content(chunk_size=1024):
                        f.write(chunk)
                        pbar.update(len(chunk))

        if use_rich:
            # rich
            theme = Theme(
                {
                    "progress.elapsed": "white",
                    "progress.download": "white",
                    "progress.remaining": "white",
                    "progress.percentage": "white",
                    "progress.data.speed": "white",
                    "bar.complete": "green",
                    "bar.finished": "white",
                    "bar.pulse": "yellow4",
                }
            )
            console = Console(theme=theme)
            progress_columns = (
                "{task.description}:",
                TaskProgressColumn(),
                BarColumn(),
                DownloadColumn(),
                "[",
                TimeRemainingColumn(compact=True),
                "/",
                TransferSpeedColumn(),
                "]",
            )

            with open(output, writemode) as f, Progress(
                *progress_columns,
                console=console,
                disable=quiet,
            ) as prog:
                task = prog.add_task(
                    output.name[:75],
                    total=content_length,
                    visible=False if quiet else True,
                )
                for chunk in resp.iter_content(chunk_size=1024):
                    f.write(chunk)
                    prog.update(task, advance=len(chunk))
                prog.refresh()

        # After Processing
        file_stat = os.stat(output)
        os.utime(output, (file_stat.st_atime, modtime.timestamp()))
        return None
    except (ConnectionResetError, requests.exceptions.ChunkedEncodingError) as error:
        # raise Exception("Connection reset, stopping.")
        raise error


async def async_pywget(
    url: str,
    path: str = "./",
    filename: str = "",
    timestamping: bool = False,
    noclobber: bool = False,
    cont: bool = False,
    overwrite: bool = False,
    quiet: bool = False,
    crc_name: bool = False,
    md5_name: bool = False,
    force_filename: bool = False,
    spder: bool = False,
    stdout: TextIO = sys.stdout,
    hide_ignore: bool = False,
    session: httpx.AsyncClient = httpx.AsyncClient(),
    get_user_agent: bool = False,
    use_mobile_user_agent: bool = False,
    min_filesize: str | int | None = None,
    max_filesize: str | int | None = None,
) -> dict | None:
    """
    Download a file from a URL using the asyncio module.

    Args:
        url: The URL of the file to download.
        path: The folder to download the file to. Defaults to the current working directory.
        filename: The filename to save the file as. If not specified, the filename will be extracted from the URL.
        timestamping: If True, the file will only be downloaded if the local file is older than the file on the remote server.
        noclobber: If True, the file will not be downloaded if it already exists.
        cont: If True, the download will be resumed if the file already exists.
        overwrite: If True, the existing file will be overwritten.
        quiet: If True, no progress information will be printed.
        crc_name: If True, the filename will be appended with the CRC32 hash of the file.
        md5_name: If True, the filename will be appended with the MD5 hash of the file.
        force_filename: If True, the specified filename will be used, even if it does not match the filename in the URL.
        spder: If True, print the file name and info for the URL. Does not download.
        stdout: The file to output print statements to. Defaults to sys.stdout.
        hide_ignore: If True, hide the print statements for noclobber and timestamping conflicts.
        session: The httpx.AsyncClient instance to use for the download.
        get_user_agent: If True, get the latest desktop user-agent. If False, use None.
        use_mobile_user_agent: If True and get_user_agent is also True, use the latest mobile/android user agent. If False, will be ignored.
        min_filesize: Minimum file size to download. Ignored if None is passed or if content-length header is not returned.
        max_filesize: Maximum file size to download. Ignored if None is passed or if content-length header is not returned.

    Returns:
        None"""

    if spder:
        spider_result: dict = spider(url)
        return spider_result

    blank = StringIO()  # open("nul", "w")
    fl_out = stdout if not quiet else blank
    ignore_messages = stdout if not any([quiet, hide_ignore]) else blank
    if force_filename or filename:
        fn = filename
    else:
        fn = get_filename(url)

    if not path:
        path = "./"

    crc_fn, md5_fn = hash_filename(url, fn)
    if crc_name:
        fn = crc_fn
    elif md5_name:
        fn = md5_fn

    output = Path(path, fn)
    headers = {}
    if get_user_agent:
        headers["user-agent"] = await async_get_latest_user_agent(
            mobile=use_mobile_user_agent
        )
    writemode = "wb"
    tz = datetime.datetime.now().astimezone().tzinfo

    async with session.stream("GET", url, follow_redirects=True) as resp:
        if output.exists():
            if cont:
                headers["Range"] = f"bytes={output.stat().st_size}-"
                writemode = "ab"
            elif timestamping:
                file_stat = os.stat(output)
                if "last-modified" in resp.headers.keys():
                    modtime = parse(resp.headers["last-modified"]).astimezone(tz=tz)
                else:
                    modtime = datetime.datetime.now()
                if file_stat.st_mtime >= modtime.timestamp():
                    print(
                        f'"{fn}" exists, ignoring because of timestamping (-n).',
                        file=ignore_messages,
                    )
                    return None
            elif noclobber:
                print(
                    f'"{fn}" exists, ignoring because of noclobber (-nc).',
                    file=ignore_messages,
                )
                return None
            elif overwrite:
                pass
            else:
                output = append_filename(output)

        os.makedirs(output.parent, exist_ok=True)

        if resp.status_code in range(400, 600):
            resp.raise_for_status()

        if "modtime" not in locals():
            if "last-modified" in resp.headers.keys():
                modtime = parse(resp.headers["last-modified"]).astimezone(tz=tz)
            else:
                modtime = datetime.datetime.now()

        if "content-length" in resp.headers.keys():
            content_length = int(resp.headers["content-length"])
        else:
            content_length = None

        if min_filesize and content_length:
            min_bytes = parse_bytes(min_filesize)
            if content_length < min_bytes:
                return None
        if max_filesize and content_length:
            max_bytes = parse_bytes(max_filesize)
            if content_length > max_bytes:
                return None

        try:
            # tqdm
            async with aiofiles.open(file=output, mode=writemode) as f:
                with async_tqdm(
                    total=content_length,
                    unit="B",
                    unit_scale=True,
                    desc=output.name[:75],
                    initial=0,
                    ascii=True,
                    disable=quiet,
                    file=fl_out,
                ) as pbar:
                    async for chunk in resp.aiter_bytes(chunk_size=1024):
                        await f.write(chunk)
                        pbar.update(len(chunk))

            # After Processing
            file_stat = os.stat(output)
            os.utime(output, (file_stat.st_atime, modtime.timestamp()))
        finally:
            pass

    return None


def async_pywget_list(
    urls: list[str],
    path: str = "./",
    filename: str = "",
    timestamping: bool = False,
    noclobber: bool = False,
    cont: bool = False,
    overwrite: bool = False,
    quiet: bool = False,
    crc_name: bool = False,
    md5_name: bool = False,
    force_filename: bool = False,
    spder: bool = False,
    stdout: TextIO = sys.stdout,
    hide_ignore: bool = False,
    session: httpx.AsyncClient = httpx.AsyncClient(),
    get_user_agent: bool = False,
    use_mobile_user_agent: bool = False,
    min_filesize: str | int | None = None,
    max_filesize: str | int | None = None,
    semaphore_size: int = 10,
) -> None:
    """
    Asynchronously download a list of URLs.

    Args:
        urls: The list of URLs to download.
        path: The folder to download the files to. Defaults to the current working directory.
        filename: The filename to save the file as. If not specified, the filename will be extracted from the URL.
        timestamping: If True, the file will only be downloaded if the local file is older than the file on the remote server.
        noclobber: If True, the file will not be downloaded if it already exists.
        cont: If True, the download will be resumed if the file already exists.
        overwrite: If True, the existing file will be overwritten.
        quiet: If True, no progress information will be printed.
        crc_name: If True, the filename will be appended with the CRC32 hash of the file.
        md5_name: If True, the filename will be appended with the MD5 hash of the file.
        force_filename: If True, the specified filename will be used, even if it does not match the filename in the URL.
        spder: If True, print the file name and info for the URL. Does not download.
        stdout: The file to output print statements to. Defaults to sys.stdout.
        hide_ignore: If True, hide the print statements for noclobber and timestamping conflicts.
        session: The httpx.AsyncClient instance to use for the download.
        get_user_agent: If True, get the latest desktop user-agent. If False, use None.
        use_mobile_user_agent: If True and get_user_agent is also True, use the latest mobile/android user agent. If False, will be ignored.
        min_filesize: Minimum file size to download. Ignored if None is passed or if content-length header is not returned.
        max_filesize: Maximum file size to download. Ignored if None is passed or if content-length header is not returned.
        semaphore_size: The size of the semaphore to use for concurrent downloads.

    Raises:
        Any exceptions raised by the `async_pywget` function.
    """

    coros = []
    for url in urls:
        coro = async_pywget(
            url=url,
            path=path,
            filename=filename,
            timestamping=timestamping,
            noclobber=noclobber,
            cont=cont,
            overwrite=overwrite,
            quiet=quiet,
            crc_name=crc_name,
            md5_name=md5_name,
            force_filename=force_filename,
            spder=spder,
            stdout=stdout,
            hide_ignore=hide_ignore,
            session=session,
            get_user_agent=get_user_agent,
            use_mobile_user_agent=use_mobile_user_agent,
            min_filesize=min_filesize,
            max_filesize=max_filesize,
        )
        coros.append(coro)

    async def sema_wrap(sema: asyncio.Semaphore, coro: Coroutine) -> Any:
        async with sema:
            res: Any = await coro
            if res:
                return res

    if semaphore_size == 0 or semaphore_size is None:
        semaphore_size = len(urls)

    semaphore = asyncio.Semaphore(semaphore_size)
    loop = asyncio.get_event_loop()
    tasks = [loop.create_task(sema_wrap(semaphore, c)) for c in coros]

    loop.run_until_complete(asyncio.wait(tasks))


@click.command()
@click.argument("url", nargs=-1)
@click.option("-p", "--prefix", "path", type=str)
@click.option("-o", "--output", "filename", type=str)
@click.option("-n", "--timestamping", "timestamping", is_flag=True)
@click.option("-nc", "--noclobber", "noclobber", is_flag=True)
@click.option("-c", "--cont", "cont", is_flag=True)
@click.option("-ov", "--overwrite", "overwrite", is_flag=True)
@click.option("-q", "--quiet", "quiet", is_flag=True)
@click.option("-crc", "crc_name", is_flag=True)
@click.option("-md5", "md5_name", is_flag=True)
@click.option("-ff", "--force-filename", "force_filename", is_flag=True)
@click.option("-s", "--spider", "spder", is_flag=True)
@click.option("--hide_ignore", "hide_ignore", is_flag=True)
@click.option("--use_rich", "use_rich", is_flag=True)
@click.option("-ua", "--get_user_agent", "get_user_agent", is_flag=True)
@click.option(
    "-mobile", "--use_mobile_user_agent", "use_mobile_user_agent", is_flag=True
)
@click.option("-min", "--min_filesize", "min_filesize", type=str)
@click.option("-max", "--max_filesize", "max_filesize", type=str)
@click.option("-ssl", "--ssl", "ssl", is_flag=True)
def cli_pywget(
    url: tuple,
    path: str = "./",
    filename: str = "",
    timestamping: bool = False,
    noclobber: bool = False,
    cont: bool = False,
    overwrite: bool = False,
    quiet: bool = False,
    crc_name: bool = False,
    md5_name: bool = False,
    force_filename: bool = False,
    spder: bool = False,
    hide_ignore: bool = False,
    use_rich: bool = False,
    get_user_agent: bool = False,
    use_mobile_user_agent: bool = False,
    min_filesize: str | int | None = None,
    max_filesize: str | int | None = None,
    verify_ssl: bool = True,
) -> dict | None:
    """
    :param url:
    URL(s) to download.
    :param path:
    Folder to download files to, can be relative or absolute. Accepts pathlib objects.
    :param filename:
    Optional: set file instead of getting it from url
    :param timestamping:
    Don't download if already saved file is newer than url.
    :param noclobber:
    Don't download already saved files, no overwrite.
    :param cont:
    Continue downloads.
    :param overwrite:
    Overwrite original file
    :param rename:
    Rename new downloads instead of overwrite
    :param quiet:
    Hide all download progress
    :param crc_name:
    Append crc32 value of link to filename
    :param md5_name:
    Append md5 value of link to filename
    :param force_filename:
    Don't try and get filename, only use the one provided
    :param spder:
    Print the file name and info for the url. Does not download.
    :param hide_ignore:
    If true, hide the print statements for noclobber and timestamping conflicts. Will be overriden by the quiet parameter.
    :param use_rich:
    If true, use the rich module for the progress bar. If false, will use tqdm for the progress bar.
    :param get_user_agent:
    If true, get latest desktop user-agent, if false use none
    :param use_mobile_user_agent:
    If true and 'get_user_agent' is also true, use the latest mobile/android user agent. If false will be ignored.
    :param min_filesize:
    Minimum file size to download. Ignored if None is passed or if content-length header is not returned.
    :param max_filesize:
    Maximum file size to download. Ignored if None is passed or if content-length header is not returned.
    :param verify_ssl:
    Verify SSL certificate
    :return:
    """

    if spder:
        if len(url) == 1:
            spider_result: dict = spider(url[0])
            return spider_result
        else:
            for l in url:
                spider(
                    url=l,
                    get_user_agent=get_user_agent,
                    use_mobile_user_agent=use_mobile_user_agent,
                )
        return None

    else:
        for l in url:
            pywget(
                url=l,
                path=path,
                filename=filename,
                timestamping=timestamping,
                noclobber=noclobber,
                cont=cont,
                overwrite=overwrite,
                quiet=quiet,
                crc_name=crc_name,
                md5_name=md5_name,
                force_filename=force_filename,
                hide_ignore=hide_ignore,
                use_rich=use_rich,
                get_user_agent=get_user_agent,
                use_mobile_user_agent=use_mobile_user_agent,
                min_filesize=min_filesize,
                max_filesize=max_filesize,
                verify_ssl=verify_ssl,
            )
        return None


def spider(
    url: str,
    get_user_agent: bool = False,
    use_mobile_user_agent: bool = False,
) -> dict[str, str | int | datetime.datetime | requests.Response]:
    """
    :param url:
    URL to get info on.

    Get the filename, size, and modified time of URL.
    """
    fn = get_filename(url)
    headers = {}
    if get_user_agent:
        headers["user-agent"] = get_latest_user_agent(mobile=use_mobile_user_agent)
    resp = requests.get(
        url, stream=True, allow_redirects=True, headers=headers, timeout=10
    )
    size = int(resp.headers["content-length"]) // 1024
    tz = datetime.datetime.now().astimezone().tzinfo
    modtime = parse(resp.headers["last-modified"]).astimezone(tz=tz)
    print(
        f"Filename: {fn}\nSize: {size}kB\nModified: {modtime:%Y-%m-%d %I:%M:%S %p %Z}\n"
    )
    info_dict: dict[str, str | int | datetime.datetime | requests.Response] = {
        "filename": fn,
        "size": size,
        "modtime": modtime,
        "resp": resp,
    }
    return info_dict


if __name__ == "__main__":
    cli_pywget()  # pylint: disable=E1120
    # Test
    # pywget(url="https://i.redd.it/jqgnqnq73oaa1.jpg", path=r"C:\Users\Crank\Downloads")
    # coro = async_pywget(
    #     url="https://i.redd.it/jqgnqnq73oaa1.jpg", path=r"C:\dev\python\MyWheels\pywget"
    # )
    # asyncio.run(coro)
