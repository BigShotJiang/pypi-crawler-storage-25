#!/usr/bin/env python3
"""Example usage of Healthcheck method."""

from radiens_core import AllegoClient
from radiens_core.exceptions import RadiensError


def main() -> None:
    """Demonstrate Healthcheck usage."""
    with AllegoClient() as client:
        try:
            # Perform lightweight health check
            client.healthcheck()
            print("✅ System health check passed")

            # For comprehensive system information, use get_status()
            status = client.get_status()
            print(f"System connected: {status.is_connected}")
            print(f"Stream mode: {status.streaming.stream_mode}")
            print(f"Record mode: {status.recording.record_mode}")

        except RadiensError as e:
            print(f"❌ Health check failed: {e}")


if __name__ == "__main__":
    main()
