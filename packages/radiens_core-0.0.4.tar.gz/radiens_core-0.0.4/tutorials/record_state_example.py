#!/usr/bin/env python3
"""Example usage of SetRecordState method."""

from time import sleep

from radiens_core import AllegoClient
from radiens_core.models.status import RecordMode, RecordStateRequest


def main() -> None:
    """Demonstrate SetRecordState usage."""
    with AllegoClient() as client:
        # System-level recording control (all ports)
        print("=== System-Level Recording ===")

        # Start recording (system level)
        start_request = RecordStateRequest(mode=RecordMode.ON)
        client.set_record_state(start_request)
        print("✅ System recording started")
        sleep(2)  # Simulate some recording time

        # Check status
        status = client.get_status()
        print(f"Current record mode: {status.recording.record_mode}")
        print(f"Active filename: {status.recording.active_filename}")
        sleep(2)  # Simulate more recording time

        # Stop recording (system level)
        stop_request = RecordStateRequest(mode=RecordMode.OFF)
        client.set_record_state(stop_request)
        print("✅ System recording stopped")


if __name__ == "__main__":
    main()
