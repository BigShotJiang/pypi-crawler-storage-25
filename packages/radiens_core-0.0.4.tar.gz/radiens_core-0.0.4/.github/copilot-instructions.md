# Agent Instructions: radiens-core-python

This is the next-generation implementation of the core Radiens Python client. It prioritizes stability, feature completeness, and proto-driven type safety using a strictly layered architecture with immutable domain models.

## Critical Setup Rules

- **NEVER use `pip`** directly. Always use `uv`.
- **NEVER modify `requirements.txt`** manually. Dependencies are managed through `pyproject.toml`.
- Python 3.12+ required
- Run `uv sync` to set up the environment

## Type Checking Workflow (Foundation Gate)

Type checking is the primary quality gate and change-detection mechanism.

1. Make changes
2. Run `uv run mypy --strict src/ tests/`
3. Fix ALL errors before considering code complete
4. Type errors cascade from `_converters/` outward — fixing converters automatically cascades fixes upward

**Pre-commit checklist** (run before every commit):

```bash
./scripts/check-fix.sh
```

This runs `ruff check --fix`, `ruff format`, `mypy --strict`, and `pytest` in sequence.

## Architecture & Layered Design

```text
src/radiens_core/
  models/                  # Pydantic v2, ZERO proto dependency
  _converters/             # Proto <-> domain (primary place importing _generated/)
  _services/               # RPC wrappers (domain in, domain out)
  _transport/              # gRPC channels, auth, error mapping
  _generated/              # Proto stubs (DO NOT EDIT)
  _base_client.py          # Base class (channel pool, auth, lifecycle)
  _base_file_client.py     # Shared base for file-based clients (Videre, Curate)
  _constants.py            # Ports, limits, defaults
  _typing_helpers.py       # Post-coercion narrowing helpers for @validate_call
  exceptions.py            # Exception hierarchy
  allego_client.py         # Real-time client
  videre_client.py         # Offline file client (extends BaseFileClient)
  curate_client.py         # Curation client (extends BaseFileClient)
```

### Critical Import Rules

| Layer | Can import from |
| --- | --- |
| `models/` | stdlib, pydantic, numpy only |
| `_converters/` | `models/`, `_generated/` |
| `_services/` | `_converters/`, `_generated/`, `_transport/`, `models/` |
| `_base_client.py` | `_transport/` |
| Client classes | `_services/`, `_transport/`, `_generated/`, `models/` |

Proto types are **never exposed in the public API**. Clients may import from `_generated/` to build proto request objects internally, but all public method signatures use domain models only. `_converters/` is the canonical place for proto ↔ domain translation.

## Proto-Driven Type Safety

The type system is the change-detection mechanism. Proto generation is owned by the `core_packages/radix` repo (`go/protos/make_grpc.py` copies stubs here automatically).

When proto stubs are regenerated in `_generated/`:

1. Copy updated `.pyi` and `_pb2.py` files from radix repo
2. Run `uv run mypy --strict src/` immediately
3. mypy will flag broken field references in `_converters/` with exact line numbers
4. Fix converters first — errors cascade upward to models → services → clients
5. Commit the updated `_generated/` alongside your fixes

## Key Conventions

- **`from __future__ import annotations`** everywhere (enables `TYPE_CHECKING` imports, makes annotations strings at runtime)
- **Pydantic models**: Use `# type: ignore[explicit-any]` on `class X(BaseModel):` line (required for disallow_any_explicit in strict mode)
- **Frozen models**: All domain models use `model_config = ConfigDict(frozen=True)` (immutable after creation)
- **`_generated/`**: Excluded from linting but mypy reads `.pyi` stubs for type info
- **Docstrings**: Use **Google style** (required by mkdocs config `docstring_style: google`)

### Flex Types & `@validate_call`

Flex types are `Annotated` aliases that accept multiple input forms and coerce at runtime via `BeforeValidator`:

| Type | Accepts |
| --- | --- |
| `FlexTimeRange` | `TimeRangeSpec \| list \| tuple` |
| `FlexSignalSpec` | `SignalSpec \| list[int] \| dict` |
| `FlexDataset` | `DatasetMetadata \| str \| Path` |

- **With `@validate_call`:** import Flex types at **top level** (Pydantic needs them at runtime)
- **Without `@validate_call`:** import inside **`TYPE_CHECKING`** (ruff TC001 enforces this)
- Use `typing.cast` with a string literal to satisfy mypy after coercion

### Converter Naming

- `*_to_proto(domain_model)` — converts a full domain model to a proto message
- `build_*_proto(param1, param2, ...)` — builds a proto message from individual parameters

### API Design

- **`update_`** for partial updates (server merges fields); **`set_`** only for full replacement
- **Keyword-only args** (`*`) for non-obvious parameters
- **Split boolean methods**: prefer `enable_X()` / `disable_X()` over `set_X(enabled: bool)`
- **Deprecation**: keep old method as a shim that delegates to the new one with `warnings.warn`
