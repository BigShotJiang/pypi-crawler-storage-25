# radiens-core

**A typed Python client for the Radiens electrophysiology platform.**

`radiens-core` gives Python scripts and Jupyter notebooks access to the same acquisition, analysis, and curation workflows available in the [Radiens](https://www.neuronexus.com/products/software/radiens) desktop applications (Allego, Videre, Curate).

> **Note:** This package is in its initial release series (0.x). While fully functional, minor API adjustments may occur before 1.0.

## Quick Example

```python
from radiens_core import AllegoClient

with AllegoClient() as client:
    client.healthcheck()
    status = client.get_status()
    print(f"Streaming: {status.streaming.stream_mode}")
    print(f"Recording: {status.recording.record_mode}")
```

All public methods return typed Python objects with strong IDE autocomplete and inline documentation support.

## Installation

```bash
pip install radiens-core
```

Requires **Python 3.12+**.

## Prerequisites

Use with a local [Radiens](https://www.neuronexus.com/products/software/radiens/) desktop application:

- **Allego** — real-time acquisition (`AllegoClient`)
- **Videre** — offline file analysis (`VidereClient`)
- **Curate** — data curation and transformation (`CurateClient`)

See the [Radiens product page](https://www.neuronexus.com/products/software/radiens/) for information on software download and installation.

## Key Capabilities

| Client | Purpose |
| --- | --- |
| `AllegoClient` | Control streaming/recording, retrieve live signals, configure DSP filters, manage stimulation, read hardware diagnostics |
| `VidereClient` | Link recorded files, retrieve signal segments, apply filters, compute signal-quality metrics and spike data |
| `CurateClient` | Filter, re-reference, downsample, and slice recorded datasets; supports bulk operations and reusable transform protocols |

## Documentation

Full API reference, getting-started guide, and examples: <https://neuronexus.github.io/radiens-core-python/latest/>

## Support

- **Web**: [Contact Us](https://www.neuronexus.com/contact-us/)
- **Email**: <support@neuronexus.com>

## License

This project is licensed under the terms described in the LICENSE file included with this distribution.
