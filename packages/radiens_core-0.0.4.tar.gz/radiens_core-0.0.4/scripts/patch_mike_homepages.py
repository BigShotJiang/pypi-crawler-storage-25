from __future__ import annotations

import argparse
import re
from pathlib import Path

ARTICLE_RE = re.compile(
    r"<article class=\"md-content__inner md-typeset\">.*?</article>",
    re.DOTALL,
)
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")


def extract_article(html_path: Path) -> str:
    html = html_path.read_text(encoding="utf-8")
    match = ARTICLE_RE.search(html)
    if match is None:
        raise ValueError(f"Could not find main article block in {html_path}")
    return match.group(0)


def candidate_targets(gh_pages_root: Path) -> list[Path]:
    targets: list[Path] = []
    for child in sorted(gh_pages_root.iterdir()):
        if not child.is_dir():
            continue
        if child.name in {"dev", "latest"} or SEMVER_RE.match(child.name):
            index_html = child / "index.html"
            if index_html.exists():
                targets.append(index_html)
    return targets


def patch_target(index_html: Path, new_article: str) -> bool:
    html = index_html.read_text(encoding="utf-8")
    patched, count = ARTICLE_RE.subn(new_article, html, count=1)
    if count != 1:
        return False
    if patched == html:
        return False
    index_html.write_text(patched, encoding="utf-8")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Patch mike version homepages with updated Home article content.",
    )
    parser.add_argument(
        "--source-html",
        type=Path,
        required=True,
        help="Path to built site index.html used as the source content.",
    )
    parser.add_argument(
        "--gh-pages-root",
        type=Path,
        required=True,
        help="Path to checked out gh-pages tree.",
    )
    args = parser.parse_args()

    source_article = extract_article(args.source_html)
    changed: list[Path] = []

    for index_html in candidate_targets(args.gh_pages_root):
        if patch_target(index_html, source_article):
            changed.append(index_html)

    if changed:
        print("Patched version homepages:")
        for path in changed:
            print(path)
    else:
        print("No homepage changes were needed.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
