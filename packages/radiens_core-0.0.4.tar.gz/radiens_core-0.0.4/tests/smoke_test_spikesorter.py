"""Functional smoke test for Spike Sorter Control.

Usage (Allego):
    uv run python tests/smoke_test_spikesorter.py allego

Usage (Videre):
    uv run python tests/smoke_test_spikesorter.py videre /path/to/recording.xdat
"""

from __future__ import annotations

import argparse
import sys
import time

from radiens_core.allego_client import AllegoClient
from radiens_core.models.spikesorter import (
    SpikeDetectParams,
    SpikeSorterCommand,
    SpikeSorterLaunchParams,
    SpikeSorterSubCommand,
)
from radiens_core.videre_client import VidereClient


def run_allego_smoke() -> None:
    print("Connecting to Allego...")
    with AllegoClient() as client:
        print("  healthcheck...")
        client.healthcheck()
        print("  OK")

        print("  checking system status...")
        status = client.get_status()
        from radiens_core.models.status import StreamMode

        if status.streaming.stream_mode != StreamMode.ON:
            print("  Starting data streaming...")
            client.start_streaming()
            time.sleep(2)
        else:
            print("  System is already streaming.")

        print("\nQuerying active spike sorters...")
        ids = client.get_spike_sorter_ids()
        print(f"  Active sorter IDs: {ids}")

        if not ids:
            print("  No active sorters found. Skipping further Allego tests.")
            return

        sorter_id = ids[0]
        print(f"\nTesting sorter: {sorter_id}")

        print("  get_spike_sorter_state...")
        state = client.get_spike_sorter_state(sorter_id)
        print(f"    sys: {state.sys}, isOn: {state.is_on}, msg: {state.msg}")

        # Ensure we are setting parameters while the sorter is active or before turning it on
        print("  get_detect_params (channel 0)...")
        params = client.get_detect_params(sorter_id, channels=[0])
        assert 0 in params, "Channel 0 should be in the detection parameters"
        p = params[0]
        print(f"    Current Ch 0 Thr SD: {p.thr_sd}")

        new_thr_sd = [p.thr_sd[0] - 0.1, p.thr_sd[1] + 0.1] if p.thr_sd else [-4.1, 4.1]
        print(f"    set_detect_params (Ch 0, new Thr SD: {new_thr_sd})...")
        client.set_detect_params(sorter_id, SpikeDetectParams(thr_sd=new_thr_sd), channels=[0])

        # Verify
        updated_params = client.get_detect_params(sorter_id, channels=[0])
        print(f"    Updated Ch 0 Thr SD: {updated_params[0].thr_sd}")
        assert updated_params[0].thr_sd is not None, "Updated Thr SD should not be None"
        for i in range(len(new_thr_sd)):
            assert abs(updated_params[0].thr_sd[i] - new_thr_sd[i]) < 1e-5, f"Thr SD mismatch at index {i}"

        if not state.is_on:
            print("  Testing command: ON...")
            client.spike_sorter_command(sorter_id, SpikeSorterCommand.ON)
            print("    Waiting for sorter to turn ON...")
            for _ in range(5):
                state = client.get_spike_sorter_state(sorter_id)
                print(f"      State: {state.sys}, isOn: {state.is_on}")
                if state.is_on:
                    break
                time.sleep(1)
            assert client.get_spike_sorter_state(sorter_id).is_on, "Sorter should be ON after command"

        print("  get_spike_sorter_dashboard...")
        dash = client.get_spike_sorter_dashboard(sorter_id)
        assert dash.general is not None, "Dashboard general info should be present"
        print(f"    Neurons: {dash.general.num_neurons}, Active Sites: {dash.general.num_active_sites}")


def run_videre_smoke(path: str) -> None:
    print(f"Connecting to Videre, linking file: {path}")
    with VidereClient() as client:
        print("  healthcheck...")
        client.healthcheck()
        print("  OK")

        meta = client.link_data_file(path)
        print(f"  Linked dataset ID: {meta.id}")

        print("\nLaunching spike sorter (DETECT_ONLY)...")
        launch_params = SpikeSorterLaunchParams(
            dsource_id=meta.id,
            discover_noise=True,
            is_auto_on=True,
            sub_cmd=SpikeSorterSubCommand.DETECT_ONLY,
        )
        result = client.spike_sorter_launch(launch_params)
        sorter_id = result.spike_sorter_id
        print(f"  Launched sorter ID: {sorter_id}")

        try:
            print("\nWaiting for sorter to initialize...")
            for _ in range(15):
                state = client.get_spike_sorter_state(sorter_id)
                print(f"    State: {state.sys} ({state.frac_complete * 100:.1f}%) - {state.msg}")
                if state.is_on:
                    break
                time.sleep(1)

            print("\nQuerying dashboard...")
            dash = client.get_spike_sorter_dashboard(sorter_id)
            if dash.general:
                print(f"    Neurons: {dash.general.num_neurons}, Active Sites: {dash.general.num_active_sites}")

            print("\nTesting get/set detection parameters (Ch 0)...")
            params = client.get_detect_params(sorter_id, channels=[0])
            assert 0 in params, "Channel 0 should be in the detection parameters"
            p = params[0]
            print(f"    Current Ch 0 Shadow: {p.shadow} s")
            new_shadow = (p.shadow + 0.0001) if p.shadow is not None else 0.0011
            print(f"    set_detect_params (Ch 0, new Shadow: {new_shadow})...")
            client.set_detect_params(sorter_id, SpikeDetectParams(shadow=new_shadow), channels=[0])

            # Verify
            updated_params = client.get_detect_params(sorter_id, channels=[0])
            print(f"    Updated Ch 0 Shadow: {updated_params[0].shadow} s")
            assert updated_params[0].shadow is not None, "Updated Shadow should not be None"
            assert abs(updated_params[0].shadow - new_shadow) < 1e-6, "Shadow period mismatch"

            print("\nTesting command: REBASE")
            client.spike_sorter_command(sorter_id, SpikeSorterCommand.REBASE)
            print("    OK")

            print("\nTesting command: OFF (Destructive in Videre)")
            client.spike_sorter_command(sorter_id, SpikeSorterCommand.OFF)
            print("    OK")

        finally:
            print(f"\nDeleting sorter (cleanup): {sorter_id}")
            # Use try-except because OFF might have already deleted it
            try:
                client.spike_sorter_delete(sorter_id)
                print("    OK")
            except Exception as e:
                if "not found" in str(e).lower():
                    print("    Already deleted (OK)")
                else:
                    print(f"    Delete failed: {e}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Spike Sorter Smoke Test")
    subparsers = parser.add_subparsers(dest="client", required=True)

    subparsers.add_parser("allego", help="Test AllegoClient")

    videre_parser = subparsers.add_parser("videre", help="Test VidereClient")
    videre_parser.add_argument("path", help="Path to recording file")

    args = parser.parse_args()

    try:
        if args.client == "allego":
            run_allego_smoke()
        elif args.client == "videre":
            run_videre_smoke(args.path)
    except Exception as e:
        print(f"\nERROR: {e}")
        sys.exit(1)

    print("\nSmoke test completed successfully.")


if __name__ == "__main__":
    main()
