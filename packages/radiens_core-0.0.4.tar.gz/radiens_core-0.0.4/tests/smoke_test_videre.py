"""Quick functional smoke test for VidereClient.get_signals.

Usage:
    uv run python smoke_test_videre.py /path/to/recording.xdat

Optionally override start/end seconds and channel indices:
    uv run python smoke_test_videre.py /path/to/recording.xdat --start 0 --end 2 --channels 0 1 2
"""

from __future__ import annotations

import argparse

from radiens_core.videre_client import VidereClient


def main() -> None:
    parser = argparse.ArgumentParser(description="Smoke test for VidereClient")
    parser.add_argument("path", help="Path to recording file (e.g. .xdat)")
    parser.add_argument("--start", type=float, default=0.0, help="Start time in seconds (default 0)")
    parser.add_argument("--end", type=float, default=1.0, help="End time in seconds (default 1)")
    parser.add_argument(
        "--channels", type=int, nargs="+", default=[0], metavar="CH", help="Amp channel indices to fetch (default: [0])"
    )
    args = parser.parse_args()

    print("Connecting to radiensserver...")
    with VidereClient() as client:
        print("  healthcheck...")
        client.healthcheck()
        print("  OK")

        print(f"\nLinking file: {args.path}")
        meta = client.link_data_file(args.path)
        print(f"  id         : {meta.id}")
        print(f"  base_name  : {meta.base_name}")
        print(f"  fs         : {meta.sampling_rate} Hz")
        print(f"  duration   : {meta.duration:.3f} s")
        tr = meta.time_range
        print(f"  time range : [{tr.sec[0]:.3f}, {tr.sec[1]:.3f}] s  ({tr.n} samples)")
        cm = meta.channel_metadata
        print(f"  amp ch     : {cm.num_channels}")

        print(f"\nget_signals: t=[{args.start}, {args.end}]s  channels={args.channels}")
        sigs = client.get_signals(meta, time_range=[args.start, args.end], signals=args.channels)

        print("\nResult (SignalArrays):")
        if sigs.amp is not None:
            print(f"  amp shape  : {sigs.amp.shape}  (channels x samples)")
            print(f"  amp dtype  : {sigs.amp.dtype}")
            print(f"  amp range  : [{sigs.amp.min():.4f}, {sigs.amp.max():.4f}]")
        else:
            print("  amp        : None")

        if sigs.gpio_ain is not None:
            print(f"  ain shape  : {sigs.gpio_ain.shape}")
        if sigs.gpio_din is not None:
            print(f"  din shape  : {sigs.gpio_din.shape}")

    print("\nDone.")


if __name__ == "__main__":
    main()
