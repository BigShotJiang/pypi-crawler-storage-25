from radiens_core._converters._dsp import (
    domain_to_proto_dsp_params,
    proto_to_domain_dsp_group,
    proto_to_domain_dsp_params,
)
from radiens_core._generated import common_pb2
from radiens_core.models.dsp import DSPParams, DSPType, FilterStage, FreqSpecBand


def test_dsp_params_conversion() -> None:
    # Domain -> Proto
    domain_params = DSPParams(
        type=DSPType.LOWPASS,
        stage=FilterStage.STAGE1,
        freq=1000.0,
        user_label="Test LP",
        filter_order=4,
    )
    proto = domain_to_proto_dsp_params(domain_params)

    assert proto.type == common_pb2.LOWPASS
    assert proto.stage == common_pb2.STAGE1
    assert proto.freq == 1000.0
    assert proto.userLabel == "Test LP"
    assert proto.filterOrder == 4

    # Proto -> Domain
    domain_back = proto_to_domain_dsp_params(proto)
    assert domain_back == domain_params


def test_dsp_params_with_band_conversion() -> None:
    domain_params = DSPParams(
        type=DSPType.BANDPASS,
        stage=FilterStage.STAGE2,
        freq_spec_band=FreqSpecBand(low_freq=300.0, high_freq=3000.0),
        is_aux=True,
        aux_chan_idx=1,
    )
    proto = domain_to_proto_dsp_params(domain_params)

    assert proto.type == common_pb2.BANDPASS
    assert proto.freqSpecBand.lowFreq == 300.0
    assert proto.freqSpecBand.highFreq == 3000.0
    assert proto.isAux is True
    assert proto.auxChanIdx == 1

    domain_back = proto_to_domain_dsp_params(proto)
    assert domain_back == domain_params


def test_dsp_group_conversion() -> None:
    proto_params = common_pb2.DSPParams(
        type=common_pb2.HIGHPASS,
        stage=common_pb2.STAGE_HARDWARE,
        freq=1.0,
    )
    proto_group = common_pb2.DSPGroup(
        hardware=[proto_params],
        softwareStage1=[],
        softwareStage2=[],
        spikeSorter=[],
    )

    domain_group = proto_to_domain_dsp_group(proto_group)

    assert len(domain_group.hardware) == 1
    assert domain_group.hardware[0].type == DSPType.HIGHPASS
    assert domain_group.hardware[0].stage == FilterStage.STAGE_HARDWARE
    assert domain_group.hardware[0].freq == 1.0
    assert len(domain_group.software_stage1) == 0
