"""Test StimParams to proto conversion."""

from radiens_core._converters._stim import stim_params_to_proto
from radiens_core._generated import allegoserver_pb2
from radiens_core.models.stim import (
    StimParams,
    StimPolarity,
    StimPulseMode,
    StimShape,
    StimTriggerEdgeOrLevel,
    StimTriggerHighOrLow,
)


class TestStimParamsToProto:
    """Test stim_params_to_proto functionality."""

    def test_converts_stim_params_to_proto(self) -> None:
        """Test that stim_params_to_proto converts domain model to proto correctly."""
        # Arrange — all timing values in microseconds (μs)
        stim_params = StimParams(
            stim_shape=StimShape.BIPHASIC,
            stim_polarity=StimPolarity.CATHODIC_FIRST,
            first_phase_duration=100.0,  # 100 μs
            second_phase_duration=100.0,  # 100 μs
            interphase_delay=50.0,  # 50 μs
            first_phase_amplitude=100.0,
            second_phase_amplitude=-100.0,
            baseline_voltage=0.0,
            trigger_edge_or_level=StimTriggerEdgeOrLevel.EDGE,
            trigger_high_or_low=StimTriggerHighOrLow.HIGH,
            enabled=True,
            post_trigger_delay=1000.0,  # 1 ms
            pulse_or_train=StimPulseMode.SINGLE_PULSE,
            number_of_stim_pulses=1,
            pulse_train_period=20000.0,  # 20 ms
            refractory_period=10000.0,  # 10 ms
            pre_stim_amp_settle=1000.0,  # 1 ms
            post_stim_amp_settle=1000.0,  # 1 ms
            maintain_amp_settle=False,
            enable_amp_settle=True,
            post_stim_charge_recov_on=1000.0,  # 1 ms
            post_stim_charge_recov_off=0.0,
            enable_charge_recovery=True,
            trigger_source_is_keypress=False,
            trigger_source_idx=0,
            stim_sys_chan_idx=42,
        )

        # Act
        result = stim_params_to_proto(stim_params)

        # Assert
        assert isinstance(result, allegoserver_pb2.StimParams)
        assert result.stimShape == allegoserver_pb2.BIPHASIC
        assert result.stimPolarity == allegoserver_pb2.CATHODIC_FIRST
        assert result.firstPhaseDuration == 100.0
        assert result.secondPhaseDuration == 100.0
        assert result.interphaseDelay == 50.0
        assert result.firstPhaseAmplitude == 100.0
        assert result.secondPhaseAmplitude == -100.0
        assert result.baselineVoltage == 0.0
        assert result.triggerEdgeOrLevel == allegoserver_pb2.ST_EDGE
        assert result.triggerHighOrLow == allegoserver_pb2.ST_HIGH
        assert result.enabled is True
        assert result.postTriggerDelay == 1000.0
        assert result.pulseOrTrain == allegoserver_pb2.SINGLE_PULSE
        assert result.numberOfStimPulses == 1
        assert result.pulseTrainPeriod == 20000.0
        assert result.refractoryPeriod == 10000.0
        assert result.preStimAmpSettle == 1000.0
        assert result.postStimAmpSettle == 1000.0
        assert result.maintainAmpSettle is False
        assert result.enableAmpSettle is True
        assert result.postStimChargeRecovOn == 1000.0
        assert result.postStimChargeRecovOff == 0.0
        assert result.enableChargeRecovery is True
        assert result.triggerSourceIsKeypress is False
        assert result.triggerSourceIdx == 0
        assert result.stimSysChanIdx == 42
