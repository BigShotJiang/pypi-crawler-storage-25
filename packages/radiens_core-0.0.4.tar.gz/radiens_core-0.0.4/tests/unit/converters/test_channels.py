"""Tests for channel metadata converters."""

from __future__ import annotations

import pytest

from radiens_core._converters._channels import channel_metadata_from_proto
from radiens_core._generated import common_pb2
from radiens_core.models.channels import AreaUnits, ChannelInfo
from radiens_core.models.signals import SignalType


def _amp_channel(**kwargs: object) -> common_pb2.ChannelRecord:
    """Build a minimal AMP ChannelRecord with sensible defaults."""
    defaults: dict[str, object] = {"chanType": common_pb2.PRI}
    defaults.update(kwargs)
    return common_pb2.ChannelRecord(**defaults)  # type: ignore[arg-type]


def _sig_group(*channels: common_pb2.ChannelRecord) -> common_pb2.SignalGroup:
    sg = common_pb2.SignalGroup()
    for ch in channels:
        sg.channels.append(ch)
    return sg


# ---------------------------------------------------------------------------
# Coordinate scaling (existing coverage)
# ---------------------------------------------------------------------------


class TestChannelCoordinateScaling:
    def test_site_ctr_x_scaled_by_10(self) -> None:
        """siteCtrX in proto (10s of microns) must be multiplied by 10 in domain."""
        ch = _amp_channel(siteCtrX=5.0, siteCtrY=0.0, siteCtrZ=0.0)
        metadata = channel_metadata_from_proto(_sig_group(ch))

        assert len(metadata.site_positions) == 1
        assert metadata.site_positions[0].probe_x == 50.0

    def test_all_site_coordinates_scaled(self) -> None:
        """All site coordinate fields must be scaled by 10."""
        ch = _amp_channel(siteCtrX=1.0, siteCtrY=2.0, siteCtrZ=3.0)
        metadata = channel_metadata_from_proto(_sig_group(ch))

        pos = metadata.site_positions[0]
        assert pos.probe_x == 10.0
        assert pos.probe_y == 20.0
        assert pos.probe_z == 30.0


# ---------------------------------------------------------------------------
# Channel name extraction
# ---------------------------------------------------------------------------


class TestChannelNameExtraction:
    def test_chan_name_stored_in_metadata(self) -> None:
        ch = _amp_channel(chanName="CH-001")
        metadata = channel_metadata_from_proto(_sig_group(ch))

        assert metadata.chan_names[SignalType.AMP][0] == "CH-001"

    def test_ntv_chan_name_stored_in_metadata(self) -> None:
        ch = _amp_channel(ntvChanName="ntv-0")
        metadata = channel_metadata_from_proto(_sig_group(ch))

        assert metadata.ntv_chan_names[SignalType.AMP][0] == "ntv-0"

    def test_get_channel_info_returns_name(self) -> None:
        ch = _amp_channel(chanName="AMP-CH01", ntvChanName="ntv-1", ntvChanIdx=1)
        metadata = channel_metadata_from_proto(_sig_group(ch))

        info = metadata.get_channel_info(ntv_idx=1, sig_type=SignalType.AMP)
        assert info.name == "AMP-CH01"
        assert info.ntv_name == "ntv-1"

    def test_multiple_signal_types_have_separate_name_lists(self) -> None:
        amp_ch = _amp_channel(chanName="AMP-0", ntvChanIdx=0)
        ain_ch = common_pb2.ChannelRecord(
            chanType=common_pb2.AUX,
            chanName="AIN-0",
            ntvChanIdx=0,
        )
        metadata = channel_metadata_from_proto(_sig_group(amp_ch, ain_ch))

        assert metadata.chan_names[SignalType.AMP][0] == "AMP-0"
        assert metadata.chan_names[SignalType.AIN][0] == "AIN-0"


# ---------------------------------------------------------------------------
# is_selected
# ---------------------------------------------------------------------------


class TestIsSelected:
    def test_selected_channel(self) -> None:
        ch = _amp_channel(ntvChanIdx=0, isSelected=True)
        metadata = channel_metadata_from_proto(_sig_group(ch))

        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)
        assert info.is_selected is True

    def test_unselected_channel(self) -> None:
        ch = _amp_channel(ntvChanIdx=0, isSelected=False)
        metadata = channel_metadata_from_proto(_sig_group(ch))

        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)
        assert info.is_selected is False


# ---------------------------------------------------------------------------
# Hardware IDs
# ---------------------------------------------------------------------------


class TestHardwareIds:
    def test_probe_id_round_trip(self) -> None:
        ch = _amp_channel(ntvChanIdx=0, probeID="probe-A1")
        metadata = channel_metadata_from_proto(_sig_group(ch))

        assert metadata.probe_ids[SignalType.AMP][0] == "probe-A1"
        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)
        assert info.probe_id == "probe-A1"

    def test_headstage_id_round_trip(self) -> None:
        ch = _amp_channel(ntvChanIdx=0, headstageID="hs-X")
        metadata = channel_metadata_from_proto(_sig_group(ch))

        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)
        assert info.headstage_id == "hs-X"

    def test_sensor_id_round_trip(self) -> None:
        ch = _amp_channel(ntvChanIdx=0, sensorID="sensor-99")
        metadata = channel_metadata_from_proto(_sig_group(ch))

        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)
        assert info.sensor_id == "sensor-99"


# ---------------------------------------------------------------------------
# ChannelInfo position properties
# ---------------------------------------------------------------------------


class TestChannelInfoPositionProperties:
    def _amp_info(self, **kwargs: object) -> ChannelInfo:
        """Return a ChannelInfo for an AMP channel with full position data."""
        ch = _amp_channel(
            ntvChanIdx=0,
            siteCtrX=1.0,
            siteCtrY=2.0,
            siteCtrZ=3.0,
            siteLimXMin=0.5,
            siteLimXMax=1.5,
            siteLimYMin=1.5,
            siteLimYMax=2.5,
            siteLimZMin=2.5,
            siteLimZMax=3.5,
            siteAreaMicron2=100.0,
            **kwargs,
        )
        metadata = channel_metadata_from_proto(_sig_group(ch))
        return metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)

    def test_has_position_true_for_amp(self) -> None:
        info = self._amp_info()
        assert info.has_position is True

    def test_has_position_false_for_ain(self) -> None:
        ain_ch = common_pb2.ChannelRecord(chanType=common_pb2.AUX, ntvChanIdx=0)
        metadata = channel_metadata_from_proto(_sig_group(ain_ch))
        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AIN)
        assert info.has_position is False

    def test_site_position_property_matches_site_positions_list(self) -> None:
        ch = _amp_channel(
            ntvChanIdx=0,
            siteCtrX=1.0,
            siteCtrY=2.0,
            siteCtrZ=3.0,
        )
        metadata = channel_metadata_from_proto(_sig_group(ch))
        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)

        sp_from_property = info.site_position
        sp_from_list = metadata.site_positions[0]

        assert sp_from_property is not None
        assert sp_from_property.probe_x == sp_from_list.probe_x
        assert sp_from_property.probe_y == sp_from_list.probe_y
        assert sp_from_property.probe_z == sp_from_list.probe_z

    def test_site_position_property_none_for_ain(self) -> None:
        ain_ch = common_pb2.ChannelRecord(chanType=common_pb2.AUX, ntvChanIdx=0)
        metadata = channel_metadata_from_proto(_sig_group(ain_ch))
        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AIN)
        assert info.site_position is None

    def test_bounding_box_size_computed(self) -> None:
        info = self._amp_info()
        bb = info.bounding_box_size
        assert bb is not None
        # lim values are in 10s of microns in proto, scaled x10 in domain
        # siteLimXMin=0.5 → 5.0, siteLimXMax=1.5 → 15.0 → width = 10.0
        assert bb[0] == pytest.approx(10.0)
        assert bb[1] == pytest.approx(10.0)
        assert bb[2] == pytest.approx(10.0)

    def test_bounding_box_size_none_for_non_amp(self) -> None:
        ain_ch = common_pb2.ChannelRecord(chanType=common_pb2.AUX, ntvChanIdx=0)
        metadata = channel_metadata_from_proto(_sig_group(ain_ch))
        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AIN)
        assert info.bounding_box_size is None

    def test_get_area_delegates_to_site_position(self) -> None:
        info = self._amp_info()
        # siteAreaMicron2=100.0 → 100 µm²
        area_um2 = info.get_area(AreaUnits.SQUARE_MICROMETERS)
        assert area_um2 == pytest.approx(100.0)

        area_mm2 = info.get_area(AreaUnits.SQUARE_MILLIMETERS)
        assert area_mm2 == pytest.approx(100.0 / 1_000_000)

    def test_get_area_none_for_non_amp(self) -> None:
        ain_ch = common_pb2.ChannelRecord(chanType=common_pb2.AUX, ntvChanIdx=0)
        metadata = channel_metadata_from_proto(_sig_group(ain_ch))
        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AIN)
        assert info.get_area(AreaUnits.SQUARE_MICROMETERS) is None

    def test_inline_probe_coordinates_match_site_positions_list(self) -> None:
        ch = _amp_channel(ntvChanIdx=0, siteCtrX=5.0, siteCtrY=6.0, siteCtrZ=7.0)
        metadata = channel_metadata_from_proto(_sig_group(ch))
        info = metadata.get_channel_info(ntv_idx=0, sig_type=SignalType.AMP)

        assert info.probe_x == pytest.approx(50.0)
        assert info.probe_y == pytest.approx(60.0)
        assert info.probe_z == pytest.approx(70.0)
        # Also match the site_positions list
        assert info.probe_x == metadata.site_positions[0].probe_x
