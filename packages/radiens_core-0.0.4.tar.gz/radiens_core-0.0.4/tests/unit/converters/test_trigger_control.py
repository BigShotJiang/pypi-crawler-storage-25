"""Tests for trigger control converters."""

from __future__ import annotations

from radiens_core._converters._trigger_control import manual_stim_trigger_request_to_proto
from radiens_core.models.stim import StimKeypressIndex
from radiens_core.models.triggers import ManualStimTriggerRequest


class TestManualStimTriggerRequestToProto:
    def test_key1_maps_to_proto_0(self) -> None:
        """StimKeypressIndex.KEYPRESS_1 (value 1) must produce trigger=0 in proto."""
        req = ManualStimTriggerRequest(trigger=StimKeypressIndex.KEYPRESS_1, trigger_on=True)
        proto = manual_stim_trigger_request_to_proto(req)
        assert proto.trigger == 0

    def test_key8_maps_to_proto_7(self) -> None:
        """StimKeypressIndex.KEYPRESS_8 (value 8) must produce trigger=7 in proto."""
        req = ManualStimTriggerRequest(trigger=StimKeypressIndex.KEYPRESS_8, trigger_on=False)
        proto = manual_stim_trigger_request_to_proto(req)
        assert proto.trigger == 7

    def test_trigger_on_is_passed_through(self) -> None:
        req = ManualStimTriggerRequest(trigger=StimKeypressIndex.KEYPRESS_3, trigger_on=True)
        proto = manual_stim_trigger_request_to_proto(req)
        assert proto.triggerOn is True
