"""Tests for restart converters."""

from radiens_core._converters._restart import restart_request_to_proto
from radiens_core.models.status import BackboneMode, RestartRequest


def test_restart_request_to_proto() -> None:
    """Test conversion of RestartRequest to proto."""
    # Test different backbone modes
    request_smartbox = RestartRequest(mode=BackboneMode.SMARTBOX_PRO)
    proto_smartbox = restart_request_to_proto(request_smartbox)
    assert proto_smartbox.mode == 0  # SMARTBOX_PRO proto value

    # Test simulation mode
    request_sim = RestartRequest(mode=BackboneMode.SMARTBOX_SIM_GEN_SINE)
    proto_sim = restart_request_to_proto(request_sim)
    assert proto_sim.mode == 1  # SMARTBOX_SIM_GEN_SINE proto value

    # Test XDAQ mode
    request_xdaq = RestartRequest(mode=BackboneMode.XDAQ_ONE_REC)
    proto_xdaq = restart_request_to_proto(request_xdaq)
    assert proto_xdaq.mode == 15  # XDAQ_ONE_REC proto value
