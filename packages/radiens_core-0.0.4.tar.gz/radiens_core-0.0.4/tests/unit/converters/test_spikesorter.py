"""Tests for spike sorter converters."""

from __future__ import annotations

from radiens_core._converters._spikesorter import (
    build_spike_sorter_command_proto,
    build_spike_sorter_set_params_proto,
    dash_element_to_proto,
    spike_detect_params_from_proto,
    spike_sorter_clusterer_params_to_proto,
    spike_sorter_dashboard_from_proto,
    spike_sorter_feature_params_to_proto,
    spike_sorter_launch_params_to_proto,
    spike_sorter_launch_result_from_proto,
    spike_sorter_state_from_proto,
)
from radiens_core._generated import common_pb2, spikesorter_pb2
from radiens_core.models.ports import Port
from radiens_core.models.spikesorter import (
    DashElement,
    InputFeatureType,
    SpikeDetectParams,
    SpikeSorterClustererParams,
    SpikeSorterCommand,
    SpikeSorterFeatureParams,
    SpikeSorterLaunchParams,
    SpikeSorterParamCommand,
    SpikeSorterStateSystem,
    SpikeSorterSubCommand,
    SpikeSorterType,
)


def test_spike_sorter_state_from_proto() -> None:
    proto = spikesorter_pb2.SpikeSorterState(
        sys=spikesorter_pb2.SYS_ON,
        fracComplete=0.5,
        isOn=True,
        msg="Sorting...",
    )
    domain = spike_sorter_state_from_proto(proto)
    assert domain.sys == SpikeSorterStateSystem.ON
    assert domain.frac_complete == 0.5
    assert domain.is_on is True
    assert domain.msg == "Sorting..."


def test_spike_sorter_launch_params_to_proto() -> None:
    params = SpikeSorterLaunchParams(
        dsource_id="data1",
        discover_noise=False,
        is_auto_on=True,
        clusterer_params=SpikeSorterClustererParams(eps=0.5, min_pts=5),
        feature_params=SpikeSorterFeatureParams(num_features=10),
    )
    proto = spike_sorter_launch_params_to_proto(params)
    assert proto.dsourceID == "data1"
    assert proto.discoverNoise is False
    assert proto.isAutoOn is True
    assert proto.clustererParams.eps == 0.5
    assert proto.clustererParams.minPts == 5
    assert proto.featureParams.numFeatures == 10


def test_spike_sorter_launch_result_from_proto() -> None:
    proto = spikesorter_pb2.SpikeSorterLaunchReply(
        spikeSorterID="ss1",
        sorterType=spikesorter_pb2.SORTER_VEX_FILE,
        msg="Launched",
    )
    domain = spike_sorter_launch_result_from_proto(proto)
    assert domain.spike_sorter_id == "ss1"
    assert domain.sorter_type == SpikeSorterType.VEX_FILE
    assert domain.msg == "Launched"


def test_build_spike_sorter_command_proto() -> None:
    proto = build_spike_sorter_command_proto(
        spike_sorter_id="ss1",
        cmd=SpikeSorterCommand.REBASE,
        sub_cmd=SpikeSorterSubCommand.NULL,
    )
    assert proto.spikeSorterID == "ss1"
    assert proto.cmd == spikesorter_pb2.SORTER_CMD_REBASE
    assert proto.subCmd == spikesorter_pb2.SORTER_SUBCMD_NULL


def test_spike_sorter_dashboard_from_proto() -> None:
    proto = spikesorter_pb2.SpikeSorterDashboardReply(
        enabledPorts=[common_pb2.A, common_pb2.B],
        general=spikesorter_pb2.SpikeSorterDashboardGeneralRec(
            state=spikesorter_pb2.SpikeSorterState(sys=spikesorter_pb2.SYS_ON),
            sorterType=spikesorter_pb2.SORTER_VEX_STREAM,
            sorterID="ss1",
            datasourceID="ds1",
            timeRange=[0.0, 100.0],
            numTotalSites=64,
            numEnabledSites=32,
            numActiveSites=16,
            numNeurons=10,
            probeYield=0.5,
            siteYield=0.6,
            numSpikesProcessed=1000,
            numSpikesLabeled=800,
            sortEfficiency=0.8,
        ),
    )
    domain = spike_sorter_dashboard_from_proto(proto)
    assert domain.enabled_ports == [Port.A, Port.B]
    assert domain.general is not None
    assert domain.general.sorter_id == "ss1"
    assert domain.general.time_range == (0.0, 100.0)
    assert domain.general.probe_yield == 0.5


def test_dash_element_to_proto() -> None:
    assert dash_element_to_proto(DashElement.AI) == spikesorter_pb2.AI


def test_spike_detect_params_from_proto() -> None:
    proto = common_pb2.SpikeSorterParamCommandRecord(
        ntvChanIdx=3,
        thr=[-150.0, 150.0],
        shadow=0.001,
        thrWdw=[0.0005, 0.001, 0.0015],
    )
    domain = spike_detect_params_from_proto(proto)
    assert domain.ntv_chan_idx == 3
    assert domain.thr == [-150.0, 150.0]
    assert domain.shadow == 0.001
    assert domain.thr_wdw == [0.0005, 0.001, 0.0015]
    # Fields not set in proto should be None
    assert domain.thr_sd is None
    assert domain.weak_thr is None
    assert domain.is_enabled is None


def test_build_spike_sorter_set_params_proto_shadow() -> None:
    params = SpikeDetectParams(shadow=0.002)
    proto = build_spike_sorter_set_params_proto("ss1", params, [0, 1])
    assert len(proto.params) == 1
    req = proto.params[0]
    assert req.spikeSorterID == "ss1"
    assert req.cmd == SpikeSorterParamCommand.SHADOW.value
    assert req.regFloat64 == [0.002]
    assert req.ntvChanIdx == [0, 1]


def test_build_spike_sorter_set_params_proto_multiple() -> None:
    params = SpikeDetectParams(thr=[-100.0, 100.0], shadow=0.001, weak_thr=[-50.0, 50.0])
    proto = build_spike_sorter_set_params_proto("ss1", params, [5])
    # Expect 3 requests: thr, shadow, weak_thr
    assert len(proto.params) == 3
    cmds = [r.cmd for r in proto.params]
    assert SpikeSorterParamCommand.THR_LEVEL.value in cmds
    assert SpikeSorterParamCommand.SHADOW.value in cmds
    assert SpikeSorterParamCommand.WEAK_THR_LEVEL.value in cmds


def test_build_spike_sorter_set_params_proto_empty() -> None:
    params = SpikeDetectParams()  # All fields None
    proto = build_spike_sorter_set_params_proto("ss1", params, [0])
    assert len(proto.params) == 0


def test_spike_sorter_feature_params_to_proto() -> None:
    for feature_type, expected_proto_val in [
        (InputFeatureType.WFM, spikesorter_pb2.FTR_TYPE_WFM),
        (InputFeatureType.SPD, spikesorter_pb2.FTR_TYPE_SPD),
        (InputFeatureType.WFM_POS, spikesorter_pb2.FTR_TYPE_WFM_POS),
        (InputFeatureType.SPD_POS, spikesorter_pb2.FTR_TYPE_SPD_POS),
    ]:
        params = SpikeSorterFeatureParams(num_features=8, feature_type=feature_type)
        proto = spike_sorter_feature_params_to_proto(params)
        assert proto.numFeatures == 8
        assert proto.featureType == expected_proto_val


def test_spike_sorter_clusterer_params_to_proto() -> None:
    params = SpikeSorterClustererParams(eps=0.3, min_pts=10, disabled=False)
    proto = spike_sorter_clusterer_params_to_proto(params)
    assert proto.eps == 0.3
    assert proto.minPts == 10
    assert proto.disabled is False
    # Optional fields not set should not be present
    assert proto.posInfluenceFrac == 0.0  # default proto value
    assert proto.wfmShapeInfluenceFrac == 0.0
