"""Tests for FlexTimeRange and FlexSignalSpec coercion aliases."""

from __future__ import annotations

import pytest
from pydantic import BaseModel, ConfigDict, ValidationError

from radiens_core.models.dataset import FlexTimeRange, TimeRangeSpec, TrsMode
from radiens_core.models.signals import FlexSignalSpec, SignalSpec, SignalType

# ===================================================================
# Helper models that use the flex aliases
# ===================================================================


class _TimeRangeModel(BaseModel):
    model_config = ConfigDict(frozen=True)
    tr: FlexTimeRange


class _SignalSpecModel(BaseModel):
    model_config = ConfigDict(frozen=True)
    sig: FlexSignalSpec


# ===================================================================
# FlexTimeRange
# ===================================================================


class TestFlexTimeRange:
    def test_passthrough_spec(self) -> None:
        spec = TimeRangeSpec.subset(0, 10)
        m = _TimeRangeModel(tr=spec)
        assert m.tr is spec

    def test_list_subset(self) -> None:
        m = _TimeRangeModel(tr=[0, 10])
        assert isinstance(m.tr, TimeRangeSpec)
        assert m.tr.mode == TrsMode.SUBSET
        assert m.tr.start == 0
        assert m.tr.end == 10

    def test_tuple_subset(self) -> None:
        m = _TimeRangeModel(tr=(1.5, 3.5))
        assert isinstance(m.tr, TimeRangeSpec)
        assert m.tr.mode == TrsMode.SUBSET
        assert m.tr.start == 1.5
        assert m.tr.end == 3.5

    def test_list_lookback(self) -> None:

        m = _TimeRangeModel(tr=[5.0, float("nan")])
        assert isinstance(m.tr, TimeRangeSpec)
        assert m.tr.mode == TrsMode.FROM_HEAD
        assert m.tr.start == 5.0
        assert m.tr.end is None

    def test_invalid_type_raises(self) -> None:
        with pytest.raises(ValidationError):
            _TimeRangeModel(tr="invalid")  # type: ignore[arg-type]

    def test_invalid_type_string_raises(self) -> None:
        with pytest.raises(ValidationError):
            _TimeRangeModel(tr=42)  # type: ignore[arg-type]

    def test_wrong_length_list_raises(self) -> None:
        with pytest.raises(ValidationError):
            _TimeRangeModel(tr=[1, 2, 3])


# ===================================================================
# FlexSignalSpec
# ===================================================================


class TestFlexSignalSpec:
    def test_passthrough_spec(self) -> None:
        spec = SignalSpec.amp([0, 1, 2])
        m = _SignalSpecModel(sig=spec)
        assert m.sig is spec

    def test_list_of_ints_becomes_amp(self) -> None:
        m = _SignalSpecModel(sig=[0, 1, 2])
        assert isinstance(m.sig, SignalSpec)
        assert m.sig.sig_type == SignalType.AMP
        assert m.sig.channels == (0, 1, 2)

    def test_dict_becomes_multi(self) -> None:
        m = _SignalSpecModel(sig={"amp": [0, 1], "din": "all"})
        assert isinstance(m.sig, SignalSpec)
        assert m.sig.is_multi()
        assert m.sig.multi_select is not None
        assert SignalType.AMP in m.sig.multi_select
        assert SignalType.DIN in m.sig.multi_select

    def test_invalid_type_raises(self) -> None:
        with pytest.raises(ValidationError):
            _SignalSpecModel(sig="invalid")

    def test_invalid_type_int_raises(self) -> None:
        with pytest.raises(ValidationError):
            _SignalSpecModel(sig=42)  # type: ignore[arg-type]

    def test_empty_dict_raises(self) -> None:
        with pytest.raises(ValidationError):
            _SignalSpecModel(sig={})


# ===================================================================
# FlexPort
# ===================================================================


class TestFlexPort:
    def test_passthrough_enum(self) -> None:
        from radiens_core.models.ports import FlexPort, Port

        class M(BaseModel):
            model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)
            p: FlexPort

        m = M(p=Port.A)
        assert m.p is Port.A

    def test_string_lowercase(self) -> None:
        from radiens_core.models.ports import FlexPort, Port

        class M(BaseModel):
            model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)
            p: FlexPort

        assert M(p="a").p is Port.A
        assert M(p="h").p is Port.H

    def test_string_uppercase(self) -> None:
        from radiens_core.models.ports import FlexPort, Port

        class M(BaseModel):
            model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)
            p: FlexPort

        assert M(p="B").p is Port.B

    def test_int(self) -> None:
        from radiens_core.models.ports import FlexPort, Port

        class M(BaseModel):
            model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)
            p: FlexPort

        assert M(p=0).p is Port.A
        assert M(p=7).p is Port.H

    def test_invalid_int_raises(self) -> None:
        from radiens_core.models.ports import FlexPort

        class M(BaseModel):
            model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)
            p: FlexPort

        with pytest.raises(ValidationError):
            M(p=99)  # type: ignore[arg-type]

    def test_invalid_string_raises(self) -> None:
        from radiens_core.models.ports import FlexPort

        class M(BaseModel):
            model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)
            p: FlexPort

        with pytest.raises(ValidationError):
            M(p="z")

    def test_coerce_port_function(self) -> None:
        from radiens_core.models.ports import Port, _coerce_port

        assert _coerce_port(Port.C) is Port.C
        assert _coerce_port("c") is Port.C
        assert _coerce_port("D") is Port.D
        assert _coerce_port(2) is Port.C
        with pytest.raises(ValueError):
            _coerce_port(99)
        with pytest.raises(ValueError):
            _coerce_port("z")


# ===================================================================
# FlexSignalType
# ===================================================================


class TestFlexSignalType:
    def test_passthrough(self) -> None:
        from radiens_core.models.signals import SignalType, _coerce_signal_type

        assert _coerce_signal_type(SignalType.AMP) is SignalType.AMP

    def test_canonical_strings(self) -> None:
        from radiens_core.models.signals import SignalType, _coerce_signal_type

        assert _coerce_signal_type("amp") is SignalType.AMP
        assert _coerce_signal_type("ain") is SignalType.AIN
        assert _coerce_signal_type("din") is SignalType.DIN
        assert _coerce_signal_type("dout") is SignalType.DOUT

    def test_case_insensitive(self) -> None:
        from radiens_core.models.signals import SignalType, _coerce_signal_type

        assert _coerce_signal_type("AMP") is SignalType.AMP
        assert _coerce_signal_type("DOUT") is SignalType.DOUT

    def test_invalid_string_raises(self) -> None:
        from radiens_core.models.signals import _coerce_signal_type

        with pytest.raises(ValueError, match="Invalid SignalType"):
            _coerce_signal_type("xyz")

    def test_removed_aliases_raise(self) -> None:
        from radiens_core.models.signals import _coerce_signal_type

        with pytest.raises(ValueError, match="Invalid SignalType"):
            _coerce_signal_type("pri")
        with pytest.raises(ValueError, match="Invalid SignalType"):
            _coerce_signal_type("aux")


# ===================================================================
# FlexFilterStage
# ===================================================================


class TestFlexFilterStage:
    def test_passthrough(self) -> None:
        from radiens_core.models.dsp import FilterStage, _coerce_filter_stage

        assert _coerce_filter_stage(FilterStage.STAGE1) is FilterStage.STAGE1

    def test_canonical_strings(self) -> None:
        from radiens_core.models.dsp import FilterStage, _coerce_filter_stage

        assert _coerce_filter_stage("hardware") is FilterStage.STAGE_HARDWARE
        assert _coerce_filter_stage("stage1") is FilterStage.STAGE1
        assert _coerce_filter_stage("stage2") is FilterStage.STAGE2
        assert _coerce_filter_stage("spike_sorter") is FilterStage.SPIKE_SORTER

    def test_uppercase_canonical_strings(self) -> None:
        from radiens_core.models.dsp import FilterStage, _coerce_filter_stage

        assert _coerce_filter_stage("HARDWARE") is FilterStage.STAGE_HARDWARE
        assert _coerce_filter_stage("STAGE1") is FilterStage.STAGE1
        assert _coerce_filter_stage("STAGE2") is FilterStage.STAGE2
        assert _coerce_filter_stage("SPIKE_SORTER") is FilterStage.SPIKE_SORTER

    def test_aliases(self) -> None:
        from radiens_core.models.dsp import _coerce_filter_stage

        # Previously accepted aliases should now raise
        with pytest.raises(ValueError, match="Invalid FilterStage"):
            _coerce_filter_stage("hw")
        with pytest.raises(ValueError, match="Invalid FilterStage"):
            _coerce_filter_stage("ss")
        with pytest.raises(ValueError, match="Invalid FilterStage"):
            _coerce_filter_stage("1")

    def test_int(self) -> None:
        from radiens_core.models.dsp import FilterStage, _coerce_filter_stage

        assert _coerce_filter_stage(0) is FilterStage.STAGE_HARDWARE
        assert _coerce_filter_stage(1) is FilterStage.STAGE1
        assert _coerce_filter_stage(3) is FilterStage.SPIKE_SORTER

    def test_invalid_string_raises(self) -> None:
        from radiens_core.models.dsp import _coerce_filter_stage

        with pytest.raises(ValueError, match="Invalid FilterStage"):
            _coerce_filter_stage("nope")

    def test_invalid_int_raises(self) -> None:
        from radiens_core.models.dsp import _coerce_filter_stage

        with pytest.raises(ValueError, match="Invalid FilterStage"):
            _coerce_filter_stage(99)


# ===================================================================
# FlexTriggerChannel
# ===================================================================


class TestFlexTriggerChannel:
    def test_passthrough(self) -> None:
        from radiens_core.models.triggers import TriggerChannel, _coerce_trigger_channel

        assert _coerce_trigger_channel(TriggerChannel.T_DIN_0) is TriggerChannel.T_DIN_0

    def test_without_prefix(self) -> None:
        from radiens_core.models.triggers import TriggerChannel, _coerce_trigger_channel

        assert _coerce_trigger_channel("din_0") is TriggerChannel.T_DIN_0
        assert _coerce_trigger_channel("dout_5") is TriggerChannel.T_DOUT_5
        assert _coerce_trigger_channel("none") is TriggerChannel.T_NONE

    def test_with_prefix_raises(self) -> None:
        from radiens_core.models.triggers import _coerce_trigger_channel

        # Full T_-prefixed names are no longer accepted; use short form only
        with pytest.raises(ValueError, match="Invalid TriggerChannel"):
            _coerce_trigger_channel("T_DIN_0")
        with pytest.raises(ValueError, match="Invalid TriggerChannel"):
            _coerce_trigger_channel("t_dout_3")

    def test_int(self) -> None:
        from radiens_core.models.triggers import TriggerChannel, _coerce_trigger_channel

        assert _coerce_trigger_channel(0) is TriggerChannel.T_DIN_0
        assert _coerce_trigger_channel(32) is TriggerChannel.T_NONE

    def test_invalid_string_raises(self) -> None:
        from radiens_core.models.triggers import _coerce_trigger_channel

        with pytest.raises(ValueError, match="Invalid TriggerChannel"):
            _coerce_trigger_channel("xyz")

    def test_invalid_int_raises(self) -> None:
        from radiens_core.models.triggers import _coerce_trigger_channel

        with pytest.raises(ValueError, match="Invalid TriggerChannel"):
            _coerce_trigger_channel(99)


# ===================================================================
# FlexBackboneMode
# ===================================================================


class TestFlexBackboneMode:
    def test_passthrough(self) -> None:
        from radiens_core.models.status import BackboneMode, _coerce_backbone_mode

        assert _coerce_backbone_mode(BackboneMode.SMARTBOX_PRO) is BackboneMode.SMARTBOX_PRO

    def test_string_lowercase(self) -> None:
        from radiens_core.models.status import BackboneMode, _coerce_backbone_mode

        assert _coerce_backbone_mode("smartbox_pro") is BackboneMode.SMARTBOX_PRO

    def test_string_uppercase(self) -> None:
        from radiens_core.models.status import BackboneMode, _coerce_backbone_mode

        assert _coerce_backbone_mode("XDAQ_CORE_STIM") is BackboneMode.XDAQ_CORE_STIM

    def test_string_mixed(self) -> None:
        from radiens_core.models.status import BackboneMode, _coerce_backbone_mode

        assert _coerce_backbone_mode("Xdaq_One_Rec") is BackboneMode.XDAQ_ONE_REC

    def test_invalid_string_raises(self) -> None:
        from radiens_core.models.status import _coerce_backbone_mode

        with pytest.raises(ValueError, match="Invalid BackboneMode"):
            _coerce_backbone_mode("unknown_mode")


# ===================================================================
# FlexSpikeSorterCommand / FlexSpikeSorterSubCommand
# ===================================================================


class TestFlexSpikeSorterCommand:
    def test_passthrough(self) -> None:
        from radiens_core.models.spikesorter import SpikeSorterCommand, _coerce_spike_sorter_command

        assert _coerce_spike_sorter_command(SpikeSorterCommand.ON) is SpikeSorterCommand.ON

    def test_string(self) -> None:
        from radiens_core.models.spikesorter import SpikeSorterCommand, _coerce_spike_sorter_command

        assert _coerce_spike_sorter_command("on") is SpikeSorterCommand.ON
        assert _coerce_spike_sorter_command("off") is SpikeSorterCommand.OFF
        assert _coerce_spike_sorter_command("clear_sort") is SpikeSorterCommand.CLEAR_SORT
        assert _coerce_spike_sorter_command("rebase") is SpikeSorterCommand.REBASE
        assert _coerce_spike_sorter_command("init") is SpikeSorterCommand.INIT

    def test_uppercase_string(self) -> None:
        from radiens_core.models.spikesorter import SpikeSorterCommand, _coerce_spike_sorter_command

        assert _coerce_spike_sorter_command("ON") is SpikeSorterCommand.ON
        assert _coerce_spike_sorter_command("CLEAR_SORT") is SpikeSorterCommand.CLEAR_SORT

    def test_invalid_raises(self) -> None:
        from radiens_core.models.spikesorter import _coerce_spike_sorter_command

        with pytest.raises(ValueError, match="Invalid SpikeSorterCommand"):
            _coerce_spike_sorter_command("xyz")


class TestFlexSpikeSorterSubCommand:
    def test_string(self) -> None:
        from radiens_core.models.spikesorter import SpikeSorterSubCommand, _coerce_spike_sorter_sub_command

        assert _coerce_spike_sorter_sub_command("null") is SpikeSorterSubCommand.NULL
        assert _coerce_spike_sorter_sub_command("detect_only") is SpikeSorterSubCommand.DETECT_ONLY

    def test_invalid_raises(self) -> None:
        from radiens_core.models.spikesorter import _coerce_spike_sorter_sub_command

        with pytest.raises(ValueError, match="Invalid SpikeSorterSubCommand"):
            _coerce_spike_sorter_sub_command("bad")


# ===================================================================
# FlexDashElement
# ===================================================================


class TestFlexDashElement:
    def test_passthrough(self) -> None:
        from radiens_core.models.spikesorter import DashElement, _coerce_dash_element

        assert _coerce_dash_element(DashElement.GENERAL) is DashElement.GENERAL

    def test_string(self) -> None:
        from radiens_core.models.spikesorter import DashElement, _coerce_dash_element

        assert _coerce_dash_element("general") is DashElement.GENERAL
        assert _coerce_dash_element("ENABLED_PORTS") is DashElement.ENABLED_PORTS
        assert _coerce_dash_element("port_stats") is DashElement.PORT_STATS
        assert _coerce_dash_element("ai") is DashElement.AI

    def test_int(self) -> None:
        from radiens_core.models.spikesorter import DashElement, _coerce_dash_element

        assert _coerce_dash_element(1) is DashElement.ENABLED_PORTS
        assert _coerce_dash_element(8) is DashElement.AI

    def test_invalid_int_raises(self) -> None:
        from radiens_core.models.spikesorter import _coerce_dash_element

        with pytest.raises(ValueError, match="Invalid DashElement"):
            _coerce_dash_element(0)

    def test_invalid_string_raises(self) -> None:
        from radiens_core.models.spikesorter import _coerce_dash_element

        with pytest.raises(ValueError, match="Invalid DashElement"):
            _coerce_dash_element("nope")


# ===================================================================
# FlexStimKeypressIndex
# ===================================================================


class TestFlexStimKeypressIndex:
    def test_passthrough(self) -> None:
        from radiens_core.models.stim import StimKeypressIndex, _coerce_stim_keypress_index

        assert _coerce_stim_keypress_index(StimKeypressIndex.KEYPRESS_3) is StimKeypressIndex.KEYPRESS_3

    def test_int(self) -> None:
        from radiens_core.models.stim import StimKeypressIndex, _coerce_stim_keypress_index

        assert _coerce_stim_keypress_index(1) is StimKeypressIndex.KEYPRESS_1
        assert _coerce_stim_keypress_index(8) is StimKeypressIndex.KEYPRESS_8

    def test_invalid_int_raises(self) -> None:
        from radiens_core.models.stim import _coerce_stim_keypress_index

        with pytest.raises(ValueError, match="Invalid StimKeypressIndex"):
            _coerce_stim_keypress_index(0)
        with pytest.raises(ValueError, match="Invalid StimKeypressIndex"):
            _coerce_stim_keypress_index(9)

    def test_invalid_type_raises(self) -> None:
        from radiens_core.models.stim import _coerce_stim_keypress_index

        with pytest.raises(ValueError, match="Expected"):
            _coerce_stim_keypress_index("3")  # type: ignore[arg-type]


# ===================================================================
# FlexKpiMetricId
# ===================================================================


class TestFlexKpiMetricId:
    def test_passthrough(self) -> None:
        from radiens_core.models.kpi import KpiMetric, KpiMetricId, KpiMode, _coerce_kpi_metric_id

        mid = KpiMetricId(mode=KpiMode.BASE, name=KpiMetric.MEAN)
        assert _coerce_kpi_metric_id(mid) is mid

    def test_string_defaults_to_base(self) -> None:
        from radiens_core.models.kpi import KpiMetric, KpiMode, _coerce_kpi_metric_id

        result = _coerce_kpi_metric_id("mean")
        assert result.mode is KpiMode.BASE
        assert result.name is KpiMetric.MEAN

    def test_string_case_insensitive(self) -> None:
        from radiens_core.models.kpi import KpiMetric, KpiMode, _coerce_kpi_metric_id

        result = _coerce_kpi_metric_id("RMS")
        assert result.mode is KpiMode.BASE
        assert result.name is KpiMetric.RMS

    def test_tuple_string_mode_and_metric(self) -> None:
        from radiens_core.models.kpi import KpiMetric, KpiMode, _coerce_kpi_metric_id

        result = _coerce_kpi_metric_id(("avg", "rms"))
        assert result.mode is KpiMode.AVG
        assert result.name is KpiMetric.RMS

    def test_tuple_enum_mode_and_string_metric(self) -> None:
        from radiens_core.models.kpi import KpiMetric, KpiMode, _coerce_kpi_metric_id

        result = _coerce_kpi_metric_id((KpiMode.STREAM, "snr"))
        assert result.mode is KpiMode.STREAM
        assert result.name is KpiMetric.SNR

    def test_invalid_metric_string_raises(self) -> None:
        from radiens_core.models.kpi import _coerce_kpi_metric_id

        with pytest.raises(ValueError, match="Invalid KpiMetric"):
            _coerce_kpi_metric_id("not_a_metric")

    def test_invalid_tuple_length_raises(self) -> None:
        from radiens_core.models.kpi import _coerce_kpi_metric_id

        with pytest.raises(ValueError, match="2-element"):
            _coerce_kpi_metric_id(("base",))  # type: ignore[arg-type]


# ===================================================================
# Tier 3 — Model field coercion
# ===================================================================


class TestTier3ModelFieldCoercion:
    def test_stim_params_shape_from_string(self) -> None:
        from radiens_core.models.stim import StimParams, StimShape

        p = StimParams(stim_sys_chan_idx=0, stim_shape="biphasic", trigger_source_idx=0)  # type: ignore[arg-type]
        assert p.stim_shape is StimShape.BIPHASIC

    def test_stim_params_polarity_from_string(self) -> None:
        from radiens_core.models.stim import StimParams, StimPolarity

        p = StimParams(stim_sys_chan_idx=0, stim_polarity="anodic_first", trigger_source_idx=0)  # type: ignore[arg-type]
        assert p.stim_polarity is StimPolarity.ANODIC_FIRST

    def test_recording_config_type_from_string(self) -> None:
        from radiens_core.models.status import DataRecordingType, RecordingConfig

        c = RecordingConfig(
            base_file_name="test",
            base_file_path="/tmp",
            recording_type="spikes",  # type: ignore[arg-type]
        )
        assert c.recording_type is DataRecordingType.SPIKES

    def test_dsp_params_type_from_string(self) -> None:
        from radiens_core.models.dsp import DSPParams, DSPType, FilterStage

        p = DSPParams(type="highpass", stage=FilterStage.STAGE1)  # type: ignore[arg-type]
        assert p.type is DSPType.HIGHPASS

    def test_dsp_params_stage_from_string(self) -> None:
        from radiens_core.models.dsp import DSPParams, DSPType, FilterStage

        p = DSPParams(type=DSPType.HIGHPASS, stage="stage1")  # type: ignore[arg-type]
        assert p.stage is FilterStage.STAGE1

    def test_dsp_params_port_from_string(self) -> None:
        from radiens_core.models.dsp import DSPParams, DSPType, FilterStage
        from radiens_core.models.ports import Port

        p = DSPParams(type=DSPType.NOTCH, stage=FilterStage.STAGE2, port="a")  # type: ignore[arg-type]
        assert p.port is Port.A

    def test_dsp_params_port_none_passthrough(self) -> None:
        from radiens_core.models.dsp import DSPParams, DSPType, FilterStage

        p = DSPParams(type=DSPType.HIGHPASS, stage=FilterStage.STAGE1)
        assert p.port is None

    def test_dsp_params_dict_shorthand_with_string_port(self) -> None:
        from radiens_core.models.dsp import DSPParams, DSPType, FilterStage, _resolve_dsp_param
        from radiens_core.models.ports import Port

        d = {"type": "notch", "notch_bandwidth": 2.0, "freq": 60.0, "port": "A"}
        result = _resolve_dsp_param(d, FilterStage.STAGE2)  # type: ignore[arg-type]
        assert isinstance(result, DSPParams)
        assert result.type is DSPType.NOTCH
        assert result.port is Port.A
        assert result.stage is FilterStage.STAGE2

    def test_spike_sorter_feature_params_from_string(self) -> None:
        from radiens_core.models.spikesorter import InputFeatureType, SpikeSorterFeatureParams

        p = SpikeSorterFeatureParams(num_features=3, feature_type="spd")  # type: ignore[arg-type]
        assert p.feature_type is InputFeatureType.SPD

    def test_spike_sorter_dynamic_criteria_from_string(self) -> None:
        from radiens_core.models.spikesorter import SpikeSorterCriterionLevel, SpikeSorterDynamicCriteria

        c = SpikeSorterDynamicCriteria(detect="balanced", train="more")  # type: ignore[arg-type]
        assert c.detect is SpikeSorterCriterionLevel.BALANCED
        assert c.train is SpikeSorterCriterionLevel.MORE
