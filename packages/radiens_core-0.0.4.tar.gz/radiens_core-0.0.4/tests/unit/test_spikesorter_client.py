"""Tests for Spike Sorter Client methods."""

from __future__ import annotations

from typing import Any
from unittest.mock import patch

import pytest

from radiens_core._generated import common_pb2, spikesorter_pb2
from radiens_core.allego_client import AllegoClient
from radiens_core.exceptions import RadiensError
from radiens_core.models.spikesorter import (
    SpikeDetectParams,
    SpikeSorterCommand,
    SpikeSorterLaunchParams,
    SpikeSorterStateSystem,
)
from radiens_core.videre_client import VidereClient

# ...


def test_allego_get_detect_params(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()
    mock_res = spikesorter_pb2.GetSpikeSorterParamCommandReply(
        spikeSorterID="ss1",
        rec=[common_pb2.SpikeSorterParamCommandRecord(ntvChanIdx=0, thr=[-100.0, 100.0])],
    )
    with patch("radiens_core.allego_client.spike_sorter_get_param_proto", return_value=mock_res) as mock_rpc:
        params = client.get_detect_params("ss1")
        mock_rpc.assert_called_once()
        assert 0 in params
        assert params[0].thr == [-100.0, 100.0]


def test_allego_set_detect_params(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()
    with patch("radiens_core.allego_client.spike_sorter_set_params_proto") as mock_rpc:
        params = SpikeDetectParams(thr=[-50.0, 50.0])
        client.set_detect_params("ss1", params, [0, 1])
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        req = args[2]
        assert len(req.params) == 1
        assert req.params[0].spikeSorterID == "ss1"
        assert req.params[0].ntvChanIdx == [0, 1]
        assert req.params[0].regFloat64 == [-50.0, 50.0]


def test_videre_get_detect_params(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    mock_res = spikesorter_pb2.GetSpikeSorterParamCommandReply(
        spikeSorterID="ss1",
        rec=[common_pb2.SpikeSorterParamCommandRecord(ntvChanIdx=5, shadow=0.001)],
    )
    with patch("radiens_core.videre_client.spike_sorter_get_param_proto", return_value=mock_res) as mock_rpc:
        params = client.get_detect_params("ss1")
        mock_rpc.assert_called_once()
        assert 5 in params
        assert params[5].shadow == 0.001


def test_videre_set_detect_params(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    with patch("radiens_core.videre_client.spike_sorter_set_params_proto") as mock_rpc:
        params = SpikeDetectParams(shadow=0.002)
        client.set_detect_params("ss1", params, [5])
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        req = args[2]
        assert len(req.params) == 1
        assert req.params[0].spikeSorterID == "ss1"
        assert req.params[0].ntvChanIdx == [5]
        assert req.params[0].regFloat64 == [0.002]


@pytest.fixture
def mock_allego_discovery() -> Any:
    with patch("radiens_core._transport._discovery.discover_radiens_addresses") as mock:
        mock.return_value = {
            "ALLEGO_CORE": "localhost:50051",
            "ALLEGO_NEURONS": "localhost:50052",
        }
        yield mock


@pytest.fixture
def mock_videre_discovery() -> Any:
    with patch("radiens_core._base_file_client.discover_radiens_addresses") as mock:
        mock.return_value = {
            "RADIENS_CORE": "localhost:50055",
            "RADIENS_SPIKE_SORTER": "localhost:50056",
        }
        yield mock


@pytest.fixture
def mock_auth() -> Any:
    with patch("radiens_core._base_client.AuthInterceptor") as mock:
        yield mock


def test_allego_get_spike_sorter_ids(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()
    mock_res = spikesorter_pb2.GetSpikeSorterIDsReply(spikeSorterIDs=["ss1", "ss2"])

    with patch("radiens_core.allego_client.get_spike_sorter_ids_proto", return_value=mock_res) as mock_rpc:
        ids = client.get_spike_sorter_ids()
        assert ids == ["ss1", "ss2"]
        mock_rpc.assert_called_once()


def test_allego_spike_sorter_command(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()

    with patch("radiens_core.allego_client.spike_sorter_command_proto") as mock_rpc:
        client.spike_sorter_command("ss1", SpikeSorterCommand.ON)
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        # Verify the proto request built by the converter
        assert args[2].spikeSorterID == "ss1"
        assert args[2].cmd == spikesorter_pb2.SORTER_CMD_ON


def test_videre_spike_sorter_launch(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    mock_res = spikesorter_pb2.SpikeSorterLaunchReply(
        spikeSorterID="new_ss",
        sorterType=spikesorter_pb2.SORTER_VEX_FILE,
    )

    params = SpikeSorterLaunchParams(dsource_id="ds1")
    with patch("radiens_core.videre_client.spike_sorter_launch_proto", return_value=mock_res) as mock_rpc:
        result = client.spike_sorter_launch(params)
        assert result.spike_sorter_id == "new_ss"
        mock_rpc.assert_called_once()


def test_videre_spike_sorter_delete(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()

    with patch("radiens_core.videre_client.spike_sorter_delete_proto") as mock_rpc:
        client.spike_sorter_delete("ss1")
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        assert args[2] == "ss1"


def test_allego_get_spike_sorter_state(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()
    mock_res = spikesorter_pb2.SpikeSorterState(sys=spikesorter_pb2.SYS_ON, fracComplete=0.75)
    with patch("radiens_core.allego_client.spike_sorter_get_state_proto", return_value=mock_res) as mock_rpc:
        state = client.get_spike_sorter_state("ss1")
        mock_rpc.assert_called_once()
        assert state.sys == SpikeSorterStateSystem.ON
        assert state.frac_complete == 0.75


def test_allego_get_default_spike_sorter_id_success(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()
    mock_res = spikesorter_pb2.GetSpikeSorterIDsReply(spikeSorterIDs=["ss1", "ss2"])
    with patch("radiens_core.allego_client.get_spike_sorter_ids_proto", return_value=mock_res):
        sorter_id = client.get_default_spike_sorter_id()
        assert sorter_id == "ss1"


def test_allego_get_default_spike_sorter_id_empty(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()
    mock_res = spikesorter_pb2.GetSpikeSorterIDsReply(spikeSorterIDs=[])
    with (
        patch("radiens_core.allego_client.get_spike_sorter_ids_proto", return_value=mock_res),
        pytest.raises(RadiensError),
    ):
        client.get_default_spike_sorter_id()


def test_allego_get_spike_sorter_dashboard(mock_allego_discovery: Any, mock_auth: Any) -> None:
    client = AllegoClient()
    mock_res = spikesorter_pb2.SpikeSorterDashboardReply()
    with patch("radiens_core.allego_client.spike_sorter_get_dashboard_proto", return_value=mock_res) as mock_rpc:
        client.get_spike_sorter_dashboard("ss1")
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        req = args[2]
        assert req.spikeSorterID == "ss1"
        # Default elements: ENABLED_PORTS=1, GENERAL=2
        assert set(req.dashElements) == {1, 2}


def test_videre_get_spike_sorter_ids(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    mock_res = spikesorter_pb2.GetSpikeSorterIDsReply(spikeSorterIDs=["ss10"])
    with (
        patch("radiens_core.videre_client.get_spike_sorter_ids_proto", return_value=mock_res) as mock_rpc,
        patch("radiens_core.videre_client.VidereClient._resolve_dataset") as mock_resolve,
    ):
        mock_resolve.return_value = type("Meta", (), {"id": "ds1"})()
        ids = client.get_spike_sorter_ids("ds1")
        mock_rpc.assert_called_once()
        assert ids == ["ss10"]


def test_videre_spike_sorter_cancel(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    with patch("radiens_core.videre_client.spike_sorter_command_proto") as mock_rpc:
        client.spike_sorter_cancel("ss1")
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        req = args[2]
        # spike_sorter_cancel delegates to spike_sorter_command(OFF)
        assert req.spikeSorterID == "ss1"
        assert req.cmd == spikesorter_pb2.SORTER_CMD_OFF
        assert req.subCmd == spikesorter_pb2.SORTER_SUBCMD_NULL


def test_videre_spike_sorter_command(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    with patch("radiens_core.videre_client.spike_sorter_command_proto") as mock_rpc:
        client.spike_sorter_command("ss1", SpikeSorterCommand.REBASE)
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        req = args[2]
        assert req.spikeSorterID == "ss1"
        assert req.cmd == spikesorter_pb2.SORTER_CMD_REBASE


def test_videre_get_spike_sorter_state(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    mock_res = spikesorter_pb2.SpikeSorterState(sys=spikesorter_pb2.SYS_OFF)
    with patch("radiens_core.videre_client.spike_sorter_get_state_proto", return_value=mock_res) as mock_rpc:
        state = client.get_spike_sorter_state("ss1")
        mock_rpc.assert_called_once()
        assert state.sys == SpikeSorterStateSystem.OFF


def test_videre_get_spike_sorter_dashboard(mock_videre_discovery: Any, mock_auth: Any) -> None:
    client = VidereClient()
    mock_res = spikesorter_pb2.SpikeSorterDashboardReply()
    with patch("radiens_core.videre_client.spike_sorter_get_dashboard_proto", return_value=mock_res) as mock_rpc:
        client.get_spike_sorter_dashboard("ss1")
        mock_rpc.assert_called_once()
        args, _ = mock_rpc.call_args
        req = args[2]
        assert req.spikeSorterID == "ss1"
        assert set(req.dashElements) == {1, 2}
