"""Tests for ChannelPool."""

import pytest

from radiens_core._transport._channel_pool import ChannelPool


def test_pool_creates_channel() -> None:
    pool = ChannelPool()
    ch = pool.get_channel("localhost:50051")
    assert ch is not None
    pool.close()


def test_pool_reuses_channel() -> None:
    pool = ChannelPool()
    ch1 = pool.get_channel("localhost:50051")
    ch2 = pool.get_channel("localhost:50051")
    assert ch1 is ch2
    pool.close()


def test_pool_different_addresses() -> None:
    pool = ChannelPool()
    ch1 = pool.get_channel("localhost:50051")
    ch2 = pool.get_channel("localhost:50052")
    assert ch1 is not ch2
    pool.close()


def test_pool_close_idempotent() -> None:
    pool = ChannelPool()
    pool.get_channel("localhost:50051")
    pool.close()
    pool.close()  # should not raise


def test_pool_raises_after_close() -> None:
    pool = ChannelPool()
    pool.close()
    with pytest.raises(RuntimeError, match="closed"):
        pool.get_channel("localhost:50051")


def test_pool_context_manager() -> None:
    with ChannelPool() as pool:
        ch = pool.get_channel("localhost:50051")
        assert ch is not None
    assert pool.is_closed
