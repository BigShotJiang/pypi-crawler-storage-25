"""Exception hierarchy for the radiens package."""


class RadiensError(Exception):
    """Base exception for all radiens-specific errors."""


class ConfigurationError(RadiensError):
    """Error in client configuration or initialization."""


class DatasetError(RadiensError):
    """Error related to dataset operations."""


class TimeRangeError(RadiensError):
    """Error related to time range specification or validation."""


class SignalSelectionError(RadiensError):
    """Error related to signal/channel selection."""


class ServerCommunicationError(RadiensError):
    """Error communicating with radiens servers."""


class DataProcessingError(RadiensError):
    """Error during data processing operations."""


class ServerDiscoveryError(RadiensError):
    """No running Radiens servers could be found."""
