"""Stream state converters — domain models <-> proto messages."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._converters._common_enums import (
    stream_mode_to_proto,
)
from radiens_core._generated import allegoserver_pb2
from radiens_core.models.status import StreamMode

if TYPE_CHECKING:
    from radiens_core.models.status import StreamStateRequest


def stream_state_request_to_proto(
    request: StreamStateRequest,
) -> allegoserver_pb2.SetStreamRequest:
    """Convert domain StreamStateRequest to proto SetStreamRequest."""
    return allegoserver_pb2.SetStreamRequest(
        mode=stream_mode_to_proto(request.mode),
    )


def build_start_streaming_proto() -> allegoserver_pb2.SetStreamRequest:
    """Build a SetStreamRequest proto for starting the stream."""
    return allegoserver_pb2.SetStreamRequest(
        mode=stream_mode_to_proto(StreamMode.ON),
    )


def build_stop_streaming_proto() -> allegoserver_pb2.SetStreamRequest:
    """Build a SetStreamRequest proto for stopping the stream."""
    return allegoserver_pb2.SetStreamRequest(
        mode=stream_mode_to_proto(StreamMode.OFF),
    )
