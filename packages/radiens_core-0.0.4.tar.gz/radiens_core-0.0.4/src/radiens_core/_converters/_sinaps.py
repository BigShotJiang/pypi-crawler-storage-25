"""Sinaps converters — domain models <-> proto messages."""

from __future__ import annotations

from radiens_core._generated import allegoserver_pb2
from radiens_core.models.status import SinapsStatusRegisters


def sinaps_status_registers_from_proto(
    pb: allegoserver_pb2.SinapsStatusRegisters,
) -> SinapsStatusRegisters:
    """Convert proto SinapsStatusRegisters to domain SinapsStatusRegisters."""
    return SinapsStatusRegisters(
        calibration_state=pb.calibrationState,
        calibration_progress=pb.calibrationProgress,
        num_active_pixels_shank0=pb.numActivePixelsShank0,
        num_active_pixels_shank1=pb.numActivePixelsShank1,
        num_active_pixels_shank2=pb.numActivePixelsShank2,
        num_active_pixels_shank3=pb.numActivePixelsShank3,
        v_ref_ffa=pb.vRefFFA,
        v_ref_ffb=pb.vRefFFB,
        v_ref_ffc=pb.vRefFFC,
        v_ref_ffd=pb.vRefFFD,
        is_error0=pb.isError0,
        is_error1=pb.isError1,
        is_error2=pb.isError2,
        is_error3=pb.isError3,
        host_counter=pb.hostCounter,
        fpga_counter=pb.fpgaCounter,
        firmware_version=pb.firmwareVersion,
        probe_generation=pb.probeGeneration,
        probe_model=pb.probeModel,
    )


def build_load_all_mosi_proto(
    register_vals: list[int],
) -> allegoserver_pb2.LoadAllMosiRequest:
    """Build a LoadAllMosiRequest proto from a list of register values."""
    return allegoserver_pb2.LoadAllMosiRequest(registerVals=register_vals)


def build_read_wire_out_proto(
    wire_out_address: int,
) -> allegoserver_pb2.ReadWireOutRequest:
    """Build a ReadWireOutRequest proto from a wire-out address."""
    return allegoserver_pb2.ReadWireOutRequest(wireOutAddress=wire_out_address)


def wire_out_value_from_proto(
    pb: allegoserver_pb2.ReadWireOutReply,
) -> int:
    """Extract the wire-out value from a ReadWireOutReply proto."""
    return int(pb.wireOutValue)


def build_flash_sinaps_proto(
    bitfile: str,
) -> allegoserver_pb2.FlashSinapsRequest:
    """Build a FlashSinapsRequest proto from a bitfile path."""
    return allegoserver_pb2.FlashSinapsRequest(bitfile=bitfile)
