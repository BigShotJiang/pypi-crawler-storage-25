"""DAC (Analog Output) converters — proto <-> domain."""

from __future__ import annotations

from radiens_core._generated import allegoserver_pb2, common_pb2
from radiens_core.models.dac import AnalogOutChannel, AnalogOutRegister, DACHighPass


def set_dac_gain_to_proto(gain: int) -> allegoserver_pb2.DACGainRequest:
    """Convert gain integer to ``DACGainRequest`` proto."""
    return allegoserver_pb2.DACGainRequest(gain=gain)


def set_dac_stream_to_proto(dac_idx: int, ntv_chan_idx: int, stream_group_id: str) -> common_pb2.DACStreamRequest:
    """Convert DAC stream parameters to ``DACStreamRequest`` proto."""
    return common_pb2.DACStreamRequest(
        DAC=dac_idx,
        NtvChanIdx=ntv_chan_idx,
        streamGroupId=stream_group_id,
    )


def set_dac_off_to_proto(stream_group_id: str) -> common_pb2.DACOffRequest:
    """Convert stream group ID to ``DACOffRequest`` proto."""
    return common_pb2.DACOffRequest(streamGroupId=stream_group_id)


def dac_highpass_from_proto(proto: allegoserver_pb2.DACHighPassRegister) -> DACHighPass:
    """Convert ``DACHighPassRegister`` proto to domain model."""
    return DACHighPass(
        enable=proto.enable,
        cutoff_freq=proto.cutoffFreq,
    )


def dac_highpass_to_proto(domain: DACHighPass) -> allegoserver_pb2.DACHighPassRegister:
    """Convert ``DACHighPass`` domain model to proto."""
    return allegoserver_pb2.DACHighPassRegister(
        enable=domain.enable,
        cutoffFreq=domain.cutoff_freq,
    )


def analog_out_channel_from_proto(
    proto: allegoserver_pb2.AnalogOutChannelRegister,
) -> AnalogOutChannel:
    """Convert ``AnalogOutChannelRegister`` proto to domain model."""
    return AnalogOutChannel(
        pri_ntv_chan_idx=proto.PriNtvChanIdx,
        analog_out_ntv_chan_idx=proto.AnalogOutNtvChanIdx,
        stream=proto.Stream,
        stream_offset_idx=proto.StreamOffsetIdx,
    )


def analog_out_register_from_proto(
    proto: allegoserver_pb2.AnalogOutRegister,
) -> AnalogOutRegister:
    """Convert ``AnalogOutRegister`` proto to domain model."""
    return AnalogOutRegister(
        gain=proto.gain,
        highpass_reg=dac_highpass_from_proto(proto.highpassReg),
        channels=[analog_out_channel_from_proto(c) for c in proto.analogOutChannels],
    )
