"""VidereClient — offline file-based analysis client."""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, ClassVar, cast

from pydantic import ConfigDict, validate_call

from radiens_core._base_file_client import BaseFileClient
from radiens_core._converters._dsp import (
    domain_to_proto_dsp_params,
    proto_to_domain_dsp_group,
)
from radiens_core._converters._kpi import (
    build_bundle_req,
    kpi_metrics_result_from_proto,
    kpi_status_from_proto,
)
from radiens_core._converters._signals import sig_select_to_proto, signal_arrays_from_signals2
from radiens_core._converters._spikes import (
    channel_spike_data_from_raster,
    merge_waveforms_channel,
    merge_waveforms_neuron,
    neuron_spike_data_from_raster,
    neurons_result_from_proto,
    spikes_spec_from_proto,
)
from radiens_core._converters._spikesorter import (
    build_spike_sorter_command_proto,
    build_spike_sorter_set_params_proto,
    dash_element_to_proto,
    spike_detect_params_from_proto,
    spike_sorter_dashboard_from_proto,
    spike_sorter_launch_params_to_proto,
    spike_sorter_launch_result_from_proto,
    spike_sorter_state_from_proto,
)
from radiens_core._converters._time_range import time_range_to_proto, trs_mode_to_proto
from radiens_core._converters._validation import validate_proto
from radiens_core._generated import biointerface_pb2, common_pb2, spikesorter_pb2
from radiens_core._services._radiens_core import (
    biointerface_get_neurons_proto,
    get_dsp_group_proto,
    get_hd_snapshot_py_proto,
    get_kpi_status_radiens_proto,
    kpi_calculate_proto,
    kpi_clear_proto,
    kpi_get_metrics_radiens_proto,
    set_dsp_group_proto,
    set_kpi_packet_dur_radiens_proto,
)
from radiens_core._services._radiens_spikesorter import (
    get_spike_sorter_ids_proto,
    spike_sorter_command_proto,
    spike_sorter_delete_proto,
    spike_sorter_get_dashboard_proto,
    spike_sorter_get_param_proto,
    spike_sorter_get_state_proto,
    spike_sorter_launch_proto,
    spike_sorter_set_params_proto,
    spikes_get_dense_proto,
    spikes_get_raster_data_proto,
    spikes_get_spec_proto,
)
from radiens_core._typing_helpers import validated
from radiens_core.exceptions import RadiensError
from radiens_core.models.common import ClientType, ServiceEndpoint
from radiens_core.models.dataset import DatasetMetadata, FlexDataset, FlexTimeRange, TimeRangeSpec
from radiens_core.models.dsp import _coerce_filter_stage, _resolve_dsp_param
from radiens_core.models.kpi import FlexKpiMetricId, KpiMetricId, KpiMetricsResult, KpiStatus
from radiens_core.models.signals import FlexSignalSpec, FlexSignalType, SignalArrays, SignalSpec, SignalType
from radiens_core.models.spikes import ChannelSpikeData, NeuronSpikeData, NeuronsResult, SpikesSpec
from radiens_core.models.spikesorter import (
    DashElement,
    FlexDashElement,
    FlexSpikeSorterCommand,
    FlexSpikeSorterSubCommand,
    SpikeDetectParams,
    SpikeSorterCommand,
    SpikeSorterDashboard,
    SpikeSorterLaunchParams,
    SpikeSorterLaunchResult,
    SpikeSorterState,
    SpikeSorterSubCommand,
)

if TYPE_CHECKING:
    from radiens_core.models.dsp import DSPGroup, FilterStage, FlexDSPParams, FlexFilterStage


class VidereClient(BaseFileClient):
    """Client for offline file-based analysis.

    Auto-discovers a running ``radiensserver`` on the local machine.

    Usage::

        with VidereClient() as client:
            meta = client.link_data_file("/path/to/recording.xdat")
            sigs = client.get_signals(meta, time_range=[0, 1], signals=[0, 1, 2])
    """

    _client_type: ClassVar[ClientType] = ClientType.VIDERE

    # --- Public API ---

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_signals(
        self,
        dataset: FlexDataset,
        time_range: FlexTimeRange | None = None,
        signals: FlexSignalSpec | None = None,
    ) -> SignalArrays:
        """Retrieve signal data for a specific time range and channel selection.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).
            time_range: Time range specification (e.g. ``[start, end]`` in seconds).
                ``None`` returns the full recording. Lookback mode is not supported for offline files.
            signals: Signal selection (e.g. list of amplifier channel indices).
                ``None`` returns all amplifier channels.

        Returns:
            The requested signal data as numpy arrays.

        Raises:
            ValueError: If lookback time range mode is used (not supported offline).
            RadiensError: On communication failure or server error.
        """

        meta = self._resolve_dataset(dataset)

        if time_range is not None:
            tr_spec = validated(time_range, TimeRangeSpec)
            concrete_tr = tr_spec.resolve(dataset_metadata=meta)
            if concrete_tr is None:
                # FROM_HEAD (lookback) mode is not meaningful for offline files
                raise ValueError(
                    f"lookback() time range is not supported for offline files; "
                    f"use TimeRangeSpec.subset(start, end) or TimeRangeSpec.full() instead. Got: {time_range}"
                )
        else:
            tr_spec = TimeRangeSpec.full()
            concrete_tr = tr_spec.resolve(dataset_metadata=meta)
            assert concrete_tr is not None  # full() always resolves

        sig_spec = validated(signals, SignalSpec) if signals is not None else SignalSpec.all_amp()

        sig_select = sig_spec.to_sig_select(meta.channel_metadata)

        # Build proto request
        req = common_pb2.HDSnapshotRequest2(
            dsourceID=meta.id,
            tR=time_range_to_proto(concrete_tr),
            selMode=trs_mode_to_proto(tr_spec.mode),
            sigSel=sig_select_to_proto(sig_select),
        )
        validate_proto(req)

        # Execute RPC
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = get_hd_snapshot_py_proto(self._pool, addr, req)

        return signal_arrays_from_signals2(response.sigs)

    def get_dsp_group(self, dataset: FlexDataset) -> DSPGroup:
        """Get DSP filter configuration for a dataset.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).

        Returns:
            The current hardware and software filter parameters.
        """
        meta = self._resolve_dataset(dataset)
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = get_dsp_group_proto(self._pool, addr, meta.id)
        return proto_to_domain_dsp_group(response)

    def set_dsp_group(
        self,
        dataset: FlexDataset,
        *,
        stage: FlexFilterStage,
        params: list[FlexDSPParams],
    ) -> None:
        """Update DSP filter configuration for a specific dataset and stage.

        Args:
            dataset: Dataset to update (metadata object, ID string, or file path).
            stage: The filter stage to update. Accepts ``FilterStage`` enum,
                string alias (``"stage1"``, ``"hw"``), or int index (``0``-``3``).
            params: List of filter parameters for this stage. Each item can be a
                ``DSPParams`` object or a dict (``stage`` is injected from *stage*
                if omitted).
        """
        meta = self._resolve_dataset(dataset)
        stage_enum: FilterStage = _coerce_filter_stage(stage)
        actual_params = [_resolve_dsp_param(p, stage_enum) for p in params]
        req = common_pb2.SetDSPGroupRequest(
            streamGroupId=meta.id,
            stage=cast("common_pb2.FilterStage.ValueType", stage_enum.value),
            dspParams=[domain_to_proto_dsp_params(p) for p in actual_params],
        )
        validate_proto(req)

        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        set_dsp_group_proto(self._pool, addr, req)

    # ===================================================================
    # KPI Metrics
    # ===================================================================

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_kpi_metrics(
        self,
        dataset: FlexDataset,
        metrics: list[FlexKpiMetricId],
        channel_indices: list[int] | None = None,
        time_range: FlexTimeRange | None = None,
        signal_type: FlexSignalType = SignalType.AMP,
    ) -> KpiMetricsResult:
        """Retrieve computed KPI signal metrics for a linked dataset.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).
            metrics: List of KPI metric identifiers. Accepts ``KpiMetricId``
                objects, metric name strings (default ``KpiMode.BASE``), or
                ``(mode, name)`` tuples.
            channel_indices: Native channel indices (ntvIdxs) to query.
                ``None`` returns metrics for all channels.
            time_range: Time range within the dataset (e.g. ``[start, end]`` in seconds).
                ``None`` returns metrics over the full recording. Lookback mode is not supported for offline files.
            signal_type: Signal type to query. Accepts ``SignalType`` enum or
                string name (e.g. ``"amp"``). Defaults to ``AMP``.

        Returns:
            Metric values as a ``(n_channels, n_metrics)`` numpy array with row/column labels.

        Raises:
            ValueError: If lookback time range mode is used (not supported offline).
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)

        if time_range is not None:
            tr_spec = validated(time_range, TimeRangeSpec)
            concrete_tr = tr_spec.resolve(dataset_metadata=meta)
            if concrete_tr is None:
                raise ValueError(
                    "lookback() time range is not supported for offline files; "
                    f"use TimeRangeSpec.subset(start, end) or TimeRangeSpec.full() instead. Got: {time_range}"
                )
        else:
            tr_spec = TimeRangeSpec.full()
            concrete_tr = tr_spec.resolve(dataset_metadata=meta)
            assert concrete_tr is not None  # full() always resolves

        st = validated(signal_type, SignalType)
        metrics_coerced = cast("list[KpiMetricId]", metrics)
        chan_list = channel_indices if channel_indices is not None else []
        req = common_pb2.KpiMetricsReq(
            streamGroupId=meta.id,
            stype=cast("common_pb2.SignalType.ValueType", st.value),
            arg=build_bundle_req(chan_list, list(concrete_tr.sec), metrics_coerced),
        )
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = kpi_get_metrics_radiens_proto(self._pool, addr, req)
        return kpi_metrics_result_from_proto(response)

    def get_kpi_status(self, dataset: FlexDataset) -> KpiStatus:
        """Get the current KPI cache status for a dataset.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).

        Returns:
            Number of packets in cache, packet duration, memory usage, and availability state.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.GetKpiStatusRequest(streamGroupId=meta.id)
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = get_kpi_status_radiens_proto(self._pool, addr, req)
        return kpi_status_from_proto(response)

    def kpi_calculate(self, dataset: FlexDataset) -> None:
        """Trigger KPI computation for a linked dataset.

        Must be called before ``get_kpi_metrics`` returns useful data
        on a freshly linked file.

        Args:
            dataset: Dataset to compute KPIs for (metadata object, ID string, or file path).

        Raises:
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.KpiStandardRequest(dsourceID=[meta.id])
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = kpi_calculate_proto(self._pool, addr, req)
        if response.errMsg:
            raise RadiensError(f"KPI calculate failed: {response.errMsg}")

    def kpi_clear(self, dataset: FlexDataset) -> None:
        """Clear the KPI cache for a dataset.

        Resets accumulated KPI state. Useful before rerunning with
        changed parameters.

        Args:
            dataset: Dataset to clear KPI state for (metadata object, ID string, or file path).

        Raises:
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.KpiStandardRequest(dsourceID=[meta.id])
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = kpi_clear_proto(self._pool, addr, req)
        if response.errMsg:
            raise RadiensError(f"KPI clear failed: {response.errMsg}")

    def set_kpi_packet_dur(self, dataset: FlexDataset, packet_dur: float) -> None:
        """Set the KPI packet duration (integration window) for a dataset.

        Args:
            dataset: Dataset to configure (metadata object, ID string, or file path).
            packet_dur: Duration of each KPI packet in seconds.

        Raises:
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        req = common_pb2.SetKpiParamRequest(streamGroupId=meta.id, param=packet_dur)
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = set_kpi_packet_dur_radiens_proto(self._pool, addr, req)
        if response.errMsg:
            raise RadiensError(f"Failed to set KPI packet duration: {response.errMsg}")

    # ===================================================================
    # Spike Data
    # ===================================================================

    def _resolve_spikes_id(
        self,
        meta: DatasetMetadata,
        spikes_id: str | None = None,
    ) -> str:
        """Return a spikes datasource ID for a dataset.

        Args:
            meta: Dataset metadata.
            spikes_id: Explicit spikes datasource ID. When ``None``, falls
                back to the first entry in ``meta.associated_spikes_ids``.

        Raises:
            RadiensError: If *spikes_id* is ``None`` and no ``.spikes`` file
                was found when the dataset was linked.
        """
        if spikes_id is not None:
            return spikes_id
        if meta.associated_spikes_ids:
            return meta.associated_spikes_ids[0]
        raise RadiensError(
            f"No spike data registered for dataset '{meta.id}'. "
            "Ensure a .spikes file is present alongside the recording file."
        )

    def _resolve_amp_channels(
        self,
        channels: FlexSignalSpec | None,
        meta: DatasetMetadata,
    ) -> list[int]:
        """Resolve a channel specification to a list of AMP native indices.

        Args:
            channels: Channel specification (list[int], SignalSpec, "all", or None).
                ``None`` returns all amplifier channels.
            meta: Dataset metadata for channel resolution.

        Returns:
            Sorted list of native AMP channel indices.
        """
        sig_spec = validated(channels, SignalSpec) if channels is not None else SignalSpec.all_amp()
        sig_select = sig_spec.to_sig_select(meta.channel_metadata)
        return sorted(int(i) for i in sig_select.amp)

    def get_spikes_spec(
        self,
        dataset: FlexDataset,
        *,
        spikes_id: str | None = None,
    ) -> SpikesSpec:
        """Retrieve spike interface metadata for a linked dataset.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).
            spikes_id: Explicit spikes datasource ID. When ``None`` (the
                default), uses the first entry from
                ``DatasetMetadata.associated_spikes_ids``.

        Returns:
            Spike metadata including the biointerface ID, enabled channel indices, and spike time range.

        Raises:
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        spikes_id = self._resolve_spikes_id(meta, spikes_id)
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = spikes_get_spec_proto(self._pool, addr, spikes_id)
        return spikes_spec_from_proto(response)

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_spikes_by_channel(
        self,
        dataset: FlexDataset,
        channels: FlexSignalSpec | None = None,
        time_range: FlexTimeRange | None = None,
        include_waveforms: bool = False,
        *,
        spikes_id: str | None = None,
    ) -> dict[int, ChannelSpikeData]:
        """Retrieve spike timestamps and neuron labels per recording channel.

        Returns one ``ChannelSpikeData`` entry per channel that has spikes in the requested time range.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).
            channels: Channels to include. Accepts a ``list[int]`` of amplifier
                channel indices, a ``SignalSpec``, ``"all"``, or ``None``.
                ``None`` returns all amplifier channels.
            time_range: Time range within the dataset (e.g. ``[start, end]`` in seconds).
                ``None`` returns spikes over the full recording. Lookback mode is not supported for offline files.
            include_waveforms: If ``True``, also fetch waveform snippets for each spike.
                Adds a second RPC call. Default ``False``.
            spikes_id: Explicit spikes datasource ID. When ``None`` (the
                default), uses the first entry from
                ``DatasetMetadata.associated_spikes_ids``.

        Returns:
            Map from native channel index to spike data.

        Raises:
            ValueError: If lookback time range mode is used (not supported offline).
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        amp_indices = self._resolve_amp_channels(channels, meta)

        if time_range is not None:
            tr_spec = validated(time_range, TimeRangeSpec)
            concrete_tr = tr_spec.resolve(dataset_metadata=meta)
            if concrete_tr is None:
                raise ValueError(
                    "lookback() time range is not supported for offline files; "
                    f"use TimeRangeSpec.subset(start, end) or TimeRangeSpec.full() instead. Got: {time_range}"
                )
            start, end = concrete_tr.sec
        else:
            start, end = 0.0, meta.duration

        resolved_spikes_id = self._resolve_spikes_id(meta, spikes_id)
        addr_core = self._server_address(ServiceEndpoint.RADIENS_CORE)
        spec_reply = spikes_get_spec_proto(self._pool, addr_core, resolved_spikes_id)

        duration = end - start
        raster_req = spikesorter_pb2.SpikeSorterGetRasterDataRequest(
            spikeSorterID=spec_reply.biointerfaceID,
            timeRange=[start, end],
            mode=spikesorter_pb2.RasterMode.CHANNELS,
            timeWindow=duration,
            plotWidthPoints=max(meta.sampling_rate * duration, 1.0),
            componentID="radiens_core_python",
            ntvChanIdx=amp_indices,
        )
        raster_reply = spikes_get_raster_data_proto(self._pool, addr_core, raster_req)
        result = channel_spike_data_from_raster(raster_reply)

        if include_waveforms:
            dense_req = biointerface_pb2.SpikesGetSpikesRequest(
                dsourceID=resolved_spikes_id,
                ntvChanIdx=amp_indices,
                timeStart=start,
                timeStop=end,
                mode=biointerface_pb2.NeuronsSignalMode.SpikeWaveforms,
                maxSpikesPerChannel=-1,
            )
            dense_reply = spikes_get_dense_proto(self._pool, addr_core, dense_req)
            result = merge_waveforms_channel(result, raster_reply, dense_reply)

        return result

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_spikes_by_neuron(
        self,
        dataset: FlexDataset,
        channels: FlexSignalSpec | None = None,
        time_range: FlexTimeRange | None = None,
        include_waveforms: bool = False,
        *,
        spikes_id: str | None = None,
    ) -> dict[int, NeuronSpikeData]:
        """Retrieve spike timestamps per sorted neuron.

        Same data as ``get_spikes_by_channel()`` but regrouped by neuron identity rather than by channel.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).
            channels: Channels to include. Accepts a ``list[int]`` of amplifier
                channel indices, a ``SignalSpec``, ``"all"``, or ``None``.
                ``None`` returns all amplifier channels.
            time_range: Time range within the dataset (e.g. ``[start, end]`` in seconds).
                ``None`` returns spikes over the full recording. Lookback mode is not supported for offline files.
            include_waveforms: If ``True``, also fetch waveform snippets for each spike.
                Adds a second RPC call. Default ``False``.
            spikes_id: Explicit spikes datasource ID. When ``None`` (the
                default), uses the first entry from
                ``DatasetMetadata.associated_spikes_ids``.

        Returns:
            Map from integer neuron label to spike data.

        Raises:
            ValueError: If lookback time range mode is used (not supported offline).
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        amp_indices = self._resolve_amp_channels(channels, meta)

        if time_range is not None:
            tr_spec = validated(time_range, TimeRangeSpec)
            concrete_tr = tr_spec.resolve(dataset_metadata=meta)
            if concrete_tr is None:
                raise ValueError(
                    "lookback() time range is not supported for offline files; "
                    f"use TimeRangeSpec.subset(start, end) or TimeRangeSpec.full() instead. Got: {time_range}"
                )
            start, end = concrete_tr.sec
        else:
            start, end = 0.0, meta.duration

        resolved_spikes_id = self._resolve_spikes_id(meta, spikes_id)
        addr_core = self._server_address(ServiceEndpoint.RADIENS_CORE)
        spec_reply = spikes_get_spec_proto(self._pool, addr_core, resolved_spikes_id)

        # Build neuron-label → channel mapping from the spec
        label_to_chan: dict[int, int] = {}
        for site in spec_reply.site:
            for nd in site.neuron:
                with contextlib.suppress(ValueError):
                    label_to_chan[int(nd.spikeLabel)] = nd.siteNtvChanIdx

        duration = end - start
        raster_req = spikesorter_pb2.SpikeSorterGetRasterDataRequest(
            spikeSorterID=spec_reply.biointerfaceID,
            timeRange=[start, end],
            mode=spikesorter_pb2.RasterMode.NEURONS,
            timeWindow=duration,
            plotWidthPoints=max(meta.sampling_rate * duration, 1.0),
            componentID="radiens_core_python",
            ntvChanIdx=amp_indices,
        )
        raster_reply = spikes_get_raster_data_proto(self._pool, addr_core, raster_req)
        result = neuron_spike_data_from_raster(raster_reply, label_to_chan)

        if include_waveforms:
            dense_req = biointerface_pb2.SpikesGetSpikesRequest(
                dsourceID=resolved_spikes_id,
                ntvChanIdx=amp_indices,
                timeStart=start,
                timeStop=end,
                mode=biointerface_pb2.NeuronsSignalMode.SpikeWaveforms,
                maxSpikesPerChannel=-1,
            )
            dense_reply = spikes_get_dense_proto(self._pool, addr_core, dense_req)
            result = merge_waveforms_neuron(result, raster_reply, dense_reply)

        return result

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_neurons(
        self,
        dataset: FlexDataset,
        channels: FlexSignalSpec | None = None,
        time_range: FlexTimeRange | None = None,
        *,
        spikes_id: str | None = None,
    ) -> NeuronsResult:
        """Retrieve neuron descriptors for a linked dataset.

        Returns spike count, rate, SNR, waveform peak amplitude, and probe
        position for each sorted neuron, organized by recording channel.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).
            channels: Channels to include. Accepts a ``list[int]`` of amplifier
                channel indices, a ``SignalSpec``, ``"all"``, or ``None``.
                ``None`` returns all amplifier channels.
            time_range: Time range within the dataset (e.g. ``[start, end]`` in seconds).
                ``None`` returns neurons over the full recording. Lookback mode is not
                supported for offline files.
            spikes_id: Explicit spikes datasource ID. When ``None`` (the
                default), uses the first entry from
                ``DatasetMetadata.associated_spikes_ids``.

        Returns:
            Neuron descriptors grouped by native channel index.

        Raises:
            ValueError: If lookback time range mode is used (not supported offline).
            RadiensError: On communication failure or server error.
        """
        meta = self._resolve_dataset(dataset)
        amp_indices = self._resolve_amp_channels(channels, meta)
        resolved_spikes_id = self._resolve_spikes_id(meta, spikes_id)

        if time_range is not None:
            tr_spec = validated(time_range, TimeRangeSpec)
            concrete_tr = tr_spec.resolve(dataset_metadata=meta)
            if concrete_tr is None:
                raise ValueError(
                    "lookback() time range is not supported for offline files; "
                    "use TimeRangeSpec.subset(start, end) or TimeRangeSpec.full() instead."
                )
            tr_list: list[float] = list(concrete_tr.sec)
        else:
            tr_list = [0.0, meta.duration]

        req = biointerface_pb2.BiointerfaceGetNeuronsRequest(
            dsourceID=resolved_spikes_id,
            ntvChanIdx=amp_indices,
            timeRange=tr_list,
        )
        addr = self._server_address(ServiceEndpoint.RADIENS_CORE)
        response = biointerface_get_neurons_proto(self._pool, addr, req)
        return neurons_result_from_proto(response)

    # ===================================================================
    # Spike Sorter Control
    # ===================================================================

    @property
    def _spikesorter_address(self) -> str:
        return self._server_address(ServiceEndpoint.RADIENS_SPIKE_SORTER)

    @property
    def _radiens_core_address(self) -> str:
        return self._server_address(ServiceEndpoint.RADIENS_CORE)

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_spike_sorter_ids(self, dataset: FlexDataset) -> list[str]:
        """Get the IDs of all active spike sorters for a dataset.

        Args:
            dataset: Dataset to query (metadata object, ID string, or file path).

        Returns:
            List of active spike sorter IDs.
        """
        meta = self._resolve_dataset(dataset)
        response = get_spike_sorter_ids_proto(self._pool, self._radiens_core_address, meta.id)
        return list(response.spikeSorterIDs)

    @validate_call
    def spike_sorter_launch(self, params: SpikeSorterLaunchParams) -> SpikeSorterLaunchResult:
        """Launch a new spike sorter on a dataset.

        Args:
            params: Parameters for the sorter launch, including the target
                dataset ID, optional clustering/feature parameters, and
                noise discovery settings.

        Returns:
            The unique ID and type of the launched sorter.

        Raises:
            RadiensError: On communication failure or server error.
        """
        req = spike_sorter_launch_params_to_proto(params)
        response = spike_sorter_launch_proto(self._pool, self._spikesorter_address, req)
        return spike_sorter_launch_result_from_proto(response)

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def spike_sorter_command(
        self,
        spike_sorter_id: str,
        cmd: FlexSpikeSorterCommand,
        *,
        sub_cmd: FlexSpikeSorterSubCommand = SpikeSorterSubCommand.NULL,
    ) -> None:
        """Send a command to a running spike sorter.

        Args:
            spike_sorter_id: Unique ID of the spike sorter to control.
            cmd: The command to execute. Accepts ``SpikeSorterCommand`` enum or
                string (e.g. ``"off"``, ``"rebase"``, ``"clear_sort"``).
            sub_cmd: Optional sub-command modifier. Accepts ``SpikeSorterSubCommand``
                enum or string (``"null"``, ``"detect_only"``).
        """
        _cmd = validated(cmd, SpikeSorterCommand)
        _sub_cmd = validated(sub_cmd, SpikeSorterSubCommand)
        req = build_spike_sorter_command_proto(spike_sorter_id, _cmd, sub_cmd=_sub_cmd)
        spike_sorter_command_proto(self._pool, self._spikesorter_address, req)

    @validate_call
    def spike_sorter_cancel(self, spike_sorter_id: str) -> None:
        """Cancel a running spike sorter.

        Sends an OFF command. **After this call, the server removes the sorter
        immediately** — subsequent calls to ``get_spike_sorter_state`` or
        ``get_spike_sorter_dashboard`` with the same ID will raise
        ``ServerCommunicationError`` ("not found"). Use
        ``spike_sorter_delete()`` afterward only if auto-cleanup did not occur.

        Equivalent to ``spike_sorter_command(id, SpikeSorterCommand.OFF)``.

        Args:
            spike_sorter_id: Unique ID of the spike sorter to cancel.
        """
        self.spike_sorter_command(spike_sorter_id, SpikeSorterCommand.OFF)

    @validate_call
    def get_spike_sorter_state(self, spike_sorter_id: str) -> SpikeSorterState:
        """Get the current state and progress of a spike sorter.

        Args:
            spike_sorter_id: Unique ID of the spike sorter to query.

        Returns:
            Current state including system status, progress, and messages.
        """
        response = spike_sorter_get_state_proto(self._pool, self._spikesorter_address, spike_sorter_id)
        return spike_sorter_state_from_proto(response)

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def get_spike_sorter_dashboard(
        self,
        spike_sorter_id: str,
        elements: list[FlexDashElement] | None = None,
    ) -> SpikeSorterDashboard:
        """Get the spike sorter dashboard for monitoring sorting progress.

        Args:
            spike_sorter_id: Unique ID of the spike sorter to query.
            elements: Optional list of dashboard elements to include. Each element
                can be a ``DashElement`` enum, string name (e.g. ``"general"``),
                or int value (``1``-``8``).
                If ``None``, returns all default elements.

        Returns:
            Comprehensive dashboard data including summary metrics and port status.
        """
        if elements is None:
            elements = [DashElement.ENABLED_PORTS, DashElement.GENERAL]

        elements_coerced = cast("list[DashElement]", elements)
        req = spikesorter_pb2.SpikeSorterDashboardRequest(
            spikeSorterID=spike_sorter_id,
            dashElements=[dash_element_to_proto(e) for e in elements_coerced],
        )
        response = spike_sorter_get_dashboard_proto(self._pool, self._spikesorter_address, req)
        return spike_sorter_dashboard_from_proto(response)

    @validate_call
    def get_detect_params(
        self,
        spike_sorter_id: str,
        channels: list[int] | None = None,
    ) -> dict[int, SpikeDetectParams]:
        """Fetch active detection configurations per channel.

        Args:
            spike_sorter_id: Unique ID of the spike sorter.
            channels: Optional list of native channel indices. If ``None``, returns params for all configured channels.

        Returns:
            Map from native channel index to its ``SpikeDetectParams``.
        """
        response = spike_sorter_get_param_proto(self._pool, self._spikesorter_address, spike_sorter_id)
        params_map = {}
        for rec in response.rec:
            if channels is None or rec.ntvChanIdx in channels:
                params_map[rec.ntvChanIdx] = spike_detect_params_from_proto(rec)
        return params_map

    @validate_call
    def set_detect_params(
        self,
        spike_sorter_id: str,
        params: SpikeDetectParams,
        channels: list[int],
    ) -> None:
        """Bulk-apply threshold, shadow, and window updates to targeted channels.

        Fields in ``params`` that are ``None`` will not be modified.

        Args:
            spike_sorter_id: Unique ID of the spike sorter.
            params: The detection parameters to apply.
            channels: List of native channel indices to apply the parameters to.
        """
        req = build_spike_sorter_set_params_proto(spike_sorter_id, params, channels)
        if req.params:
            spike_sorter_set_params_proto(self._pool, self._spikesorter_address, req)

    @validate_call
    def spike_sorter_delete(self, spike_sorter_id: str) -> None:
        """Delete a spike sorter and release its resources.

        Args:
            spike_sorter_id: Unique ID of the spike sorter to delete.

        Raises:
            RadiensError: On communication failure or server error.
        """
        spike_sorter_delete_proto(self._pool, self._spikesorter_address, spike_sorter_id)
