"""Neurons1 RPC wrappers (allegoserver) — thin service layer (proto only)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import grpc

from radiens_core._generated import (
    allegoserver_pb2_grpc,
    common_pb2,
    spikesorter_pb2,
)
from radiens_core._transport._errors import handle_grpc_error
from radiens_core.models.common import ClientType

if TYPE_CHECKING:
    from radiens_core._transport._channel_pool import ChannelPool


def get_spike_sorter_ids_proto(
    pool: ChannelPool,
    addr: str,
) -> spikesorter_pb2.GetSpikeSorterIDsReply:
    """Send ``GetSpikeSorterIDs`` RPC, return raw proto response.

    NOTE: In Allego, this is in AllegoCore service.
    """
    channel = pool.get_channel(addr)
    stub = allegoserver_pb2_grpc.AllegoCoreStub(channel)
    req = common_pb2.StandardRequest()
    try:
        return stub.GetSpikeSorterIDs(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.ALLEGO)
        raise


def spike_sorter_command_proto(
    pool: ChannelPool,
    addr: str,
    request: spikesorter_pb2.SpikeSorterCommandRequest,
) -> None:
    """Send ``SpikeSorterCommand`` RPC."""
    channel = pool.get_channel(addr)
    # SpikeSorterCommand is in Neurons1 for Allego.
    stub = allegoserver_pb2_grpc.Neurons1Stub(channel)
    try:
        stub.SpikeSorterCommand(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.ALLEGO)
        raise


def spike_sorter_get_param_proto(
    pool: ChannelPool,
    addr: str,
    spike_sorter_id: str,
) -> spikesorter_pb2.GetSpikeSorterParamCommandReply:
    """Send ``SpikeSorterGetParam`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = allegoserver_pb2_grpc.Neurons1Stub(channel)
    req = spikesorter_pb2.SpikeSorterStandardRequest(spikeSorterID=spike_sorter_id)
    try:
        return stub.SpikeSorterGetParam(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.ALLEGO)
        raise


def spike_sorter_set_params_proto(
    pool: ChannelPool,
    addr: str,
    request: common_pb2.SpikeSorterSetParamsRequest,
) -> None:
    """Send ``SpikeSorterSetParams`` RPC."""
    channel = pool.get_channel(addr)
    stub = allegoserver_pb2_grpc.Neurons1Stub(channel)
    try:
        stub.SpikeSorterSetParams(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.ALLEGO)
        raise


def spike_sorter_get_state_proto(
    pool: ChannelPool,
    addr: str,
    spike_sorter_id: str,
) -> spikesorter_pb2.SpikeSorterState:
    """Send ``SpikeSorterGetState`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = allegoserver_pb2_grpc.Neurons1Stub(channel)
    req = spikesorter_pb2.SpikeSorterStandardRequest(spikeSorterID=spike_sorter_id)
    try:
        return stub.SpikeSorterGetState(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.ALLEGO)
        raise


def spike_sorter_get_dashboard_proto(
    pool: ChannelPool,
    addr: str,
    request: spikesorter_pb2.SpikeSorterDashboardRequest,
) -> spikesorter_pb2.SpikeSorterDashboardReply:
    """Send ``SpikeSorterGetDashboard`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = allegoserver_pb2_grpc.Neurons1Stub(channel)
    try:
        return stub.SpikeSorterGetDashboard(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.ALLEGO)
        raise
