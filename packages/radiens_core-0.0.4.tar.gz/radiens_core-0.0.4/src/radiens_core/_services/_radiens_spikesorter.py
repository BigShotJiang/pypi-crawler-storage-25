"""RadiensSpikeSorter1 RPC wrappers (radiensserver) — thin service layer (proto only)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import grpc

from radiens_core._generated import (
    biointerface_pb2,
    common_pb2,
    datasource_pb2,
    radiensserver_pb2_grpc,
    spikesorter_pb2,
)
from radiens_core._transport._errors import handle_grpc_error
from radiens_core.models.common import ClientType

if TYPE_CHECKING:
    from radiens_core._transport._channel_pool import ChannelPool


def get_spike_sorter_ids_proto(
    pool: ChannelPool,
    addr: str,
    stream_group_id: str,
) -> spikesorter_pb2.GetSpikeSorterIDsReply:
    """Send ``GetSpikeSorterIDs`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensCoreStub(channel)
    req = spikesorter_pb2.GetSpikeSorterIDsRequest(streamGroupID=stream_group_id)
    try:
        return stub.GetSpikeSorterIDs(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spike_sorter_launch_proto(
    pool: ChannelPool,
    addr: str,
    request: spikesorter_pb2.SpikeSorterLaunchRequest,
) -> spikesorter_pb2.SpikeSorterLaunchReply:
    """Send ``SpikeSorterLaunch`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensSpikeSorter1Stub(channel)
    try:
        return stub.SpikeSorterLaunch(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spike_sorter_command_proto(
    pool: ChannelPool,
    addr: str,
    request: spikesorter_pb2.SpikeSorterCommandRequest,
) -> None:
    """Send ``SpikeSorterCommand`` RPC."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensSpikeSorter1Stub(channel)
    try:
        stub.SpikeSorterCommand(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spike_sorter_get_param_proto(
    pool: ChannelPool,
    addr: str,
    spike_sorter_id: str,
) -> spikesorter_pb2.GetSpikeSorterParamCommandReply:
    """Send ``SpikeSorterGetParam`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensSpikeSorter1Stub(channel)
    req = spikesorter_pb2.SpikeSorterStandardRequest(spikeSorterID=spike_sorter_id)
    try:
        return stub.SpikeSorterGetParam(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spike_sorter_set_params_proto(
    pool: ChannelPool,
    addr: str,
    request: common_pb2.SpikeSorterSetParamsRequest,
) -> None:
    """Send ``SpikeSorterSetParams`` RPC."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensSpikeSorter1Stub(channel)
    try:
        stub.SpikeSorterSetParams(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spike_sorter_get_state_proto(
    pool: ChannelPool,
    addr: str,
    spike_sorter_id: str,
) -> spikesorter_pb2.SpikeSorterState:
    """Send ``SpikeSorterGetState`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensSpikeSorter1Stub(channel)
    req = spikesorter_pb2.SpikeSorterStandardRequest(spikeSorterID=spike_sorter_id)
    try:
        return stub.SpikeSorterGetState(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spike_sorter_get_dashboard_proto(
    pool: ChannelPool,
    addr: str,
    request: spikesorter_pb2.SpikeSorterDashboardRequest,
) -> spikesorter_pb2.SpikeSorterDashboardReply:
    """Send ``SpikeSorterGetDashboard`` RPC, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensSpikeSorter1Stub(channel)
    try:
        return stub.SpikeSorterGetDashboard(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spike_sorter_delete_proto(
    pool: ChannelPool,
    addr: str,
    spike_sorter_id: str,
) -> None:
    """Send ``SpikeSorterDelete`` RPC."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensSpikeSorter1Stub(channel)
    req = spikesorter_pb2.SpikeSorterStandardRequest(spikeSorterID=spike_sorter_id)
    try:
        stub.SpikeSorterDelete(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spikes_get_spec_proto(
    pool: ChannelPool,
    addr: str,
    dsource_id: str,
) -> biointerface_pb2.SpikesSpecReply:
    """Send ``SpikesGetSpec`` RPC, return raw proto response.

    NOTE: This RPC is in RadiensCore service.
    """
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensCoreStub(channel)
    req = datasource_pb2.DataSourceRequest(dsourceID=[dsource_id])
    try:
        return stub.SpikesGetSpec(req)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spikes_get_raster_data_proto(
    pool: ChannelPool,
    addr: str,
    request: spikesorter_pb2.SpikeSorterGetRasterDataRequest,
) -> spikesorter_pb2.SpikeSorterRasterDataReply:
    """Send ``SpikesGetRasterData`` RPC, return raw proto response.

    NOTE: This RPC is in RadiensCore service.
    """
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensCoreStub(channel)
    try:
        return stub.SpikesGetRasterData(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise


def spikes_get_dense_proto(
    pool: ChannelPool,
    addr: str,
    request: biointerface_pb2.SpikesGetSpikesRequest,
) -> biointerface_pb2.SpikesSpikeDataDenseReply:
    """Send ``SpikesGetSpikesDense`` RPC to RadiensCore, return raw proto response."""
    channel = pool.get_channel(addr)
    stub = radiensserver_pb2_grpc.RadiensCoreStub(channel)
    try:
        return stub.SpikesGetSpikesDense(request)
    except grpc.RpcError as ex:
        handle_grpc_error(ex, ClientType.VIDERE)
        raise
