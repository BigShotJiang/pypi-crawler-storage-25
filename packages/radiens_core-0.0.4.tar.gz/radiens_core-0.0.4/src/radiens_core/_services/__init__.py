"""gRPC service call wrappers — domain in, domain out."""
