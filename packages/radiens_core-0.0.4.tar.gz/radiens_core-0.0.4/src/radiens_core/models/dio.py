"""DIO (Digital Output) domain models and enums."""

from __future__ import annotations

from enum import IntEnum

from pydantic import BaseModel, ConfigDict


class DIOMode(IntEnum):
    """Digital Output mode. Values match proto ``allego.DIOMode``."""

    MANUAL = 0
    EVENTS = 1
    GATED = 2
    PULSE = 3


class DigitalOutChannelRegister(BaseModel):
    """Register state for a single digital output channel.

    Attributes:
        manual_state: Manual state of the digital output channel.
        event_threshold: Event threshold in microvolts.
        event_polarity: Event polarity of the channel.
        ntv_chan_idx: Native channel index.
        pulse_interval_sec: Pulse interval in seconds.
        pulse_duration_sec: Pulse duration in seconds.
    """

    model_config = ConfigDict(frozen=True)

    manual_state: bool
    event_threshold: float
    event_polarity: bool
    ntv_chan_idx: int
    pulse_interval_sec: float
    pulse_duration_sec: float


class DigitalOutRegister(BaseModel):
    """Complete DIO (Digital Output) register state.

    Attributes:
        mode: Digital output mode. References DIOMode.
        dout_chan_registers: List of digital output channel registers.
        gated_polarity: Gated polarity of the register.
        req_pulse_interval_sec: Requested pulse interval in seconds.
        req_pulse_duration_sec: Requested pulse duration in seconds.
        req_pulse_ntv_chan_idx: Requested pulse native channel index.
    """

    model_config = ConfigDict(frozen=True)

    mode: DIOMode
    dout_chan_registers: list[DigitalOutChannelRegister]
    gated_polarity: bool
    req_pulse_interval_sec: float
    req_pulse_duration_sec: float
    req_pulse_ntv_chan_idx: int
