"""Spike sorter control and status domain models."""

from __future__ import annotations

from enum import IntEnum
from typing import Annotated, Literal

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field

from radiens_core.models.ports import Port


class SpikeSorterType(IntEnum):
    """Supported spike sorter types."""

    NULL = 0
    VEX_STREAM = 1
    SPIKES_STREAM = 2
    VEX_FILE = 3
    SPIKES_FILE = 4


class SpikeSorterParamCommand(IntEnum):
    """Commands for updating individual spike sorter detection parameters."""

    THR_LEVEL = 1
    THR_LEVEL_SD = 4
    THR_WDW = 8
    WEAK_THR_LEVEL = 10
    WEAK_THR_LEVEL_SD = 13
    SHADOW = 17
    THR_ACTIVATE = 19
    WEAK_THR_ACTIVATE = 21


class SpikeSorterCriterionLevel(IntEnum):
    """Stringency levels for AI evaluation."""

    LEAST = 0
    LESS = 1
    BALANCED = 2
    MORE = 3
    MOST = 4


def _coerce_spike_sorter_criterion_level(v: object) -> SpikeSorterCriterionLevel:
    """Coerce raw Python types into ``SpikeSorterCriterionLevel``."""
    if isinstance(v, SpikeSorterCriterionLevel):
        return v
    if isinstance(v, int):
        try:
            return SpikeSorterCriterionLevel(v)
        except ValueError:
            valid_ints = [lv.value for lv in SpikeSorterCriterionLevel]
            raise ValueError(f"Invalid SpikeSorterCriterionLevel int {v!r} — valid values: {valid_ints}") from None
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return SpikeSorterCriterionLevel[key]
        except KeyError:
            valid_strs = [lv.name for lv in SpikeSorterCriterionLevel]
            raise ValueError(f"Invalid SpikeSorterCriterionLevel string {v!r} — valid values: {valid_strs}") from None
    raise ValueError(f"Expected SpikeSorterCriterionLevel, str, or int — got {type(v).__name__}") from None


SpikeSorterCriterionLevelStr = Literal["LEAST", "LESS", "BALANCED", "MORE", "MOST"]


class SpikeDetectParams(BaseModel):
    """Detection parameters for a single recording channel.

    All fields are optional to allow for partial updates.

    Attributes:
        is_enabled: Whether detection is enabled on this channel.
        ntv_chan_idx: Native channel index (used in return structures, not set via bulk update).
        thr: Threshold values in microvolts ``[neg, pos]``.
        thr_sd: Threshold values in standard deviations ``[neg, pos]``.
        thr_wdw_pts: Threshold window in points ``[pre, post, total]``.
        thr_wdw: Threshold window in seconds ``[pre, post, total]``.
        shadow: Shadow period in seconds.
        shadow_pts: Shadow period in points.
        is_set_thr: Whether threshold is set ``[neg, pos]``.
        weak_thr: Weak threshold values in microvolts ``[neg, pos]``.
        weak_thr_sd: Weak threshold values in standard deviations ``[neg, pos]``.
    """

    model_config = ConfigDict(frozen=True)

    is_enabled: bool | None = None
    ntv_chan_idx: int | None = None
    thr: list[float] | None = None
    thr_sd: list[float] | None = None
    thr_wdw_pts: list[int] | None = None  # Read-only; populated by server, ignored by set_detect_params.
    thr_wdw: list[float] | None = None
    shadow: float | None = None
    shadow_pts: int | None = None  # Read-only; populated by server, ignored by set_detect_params.
    is_set_thr: list[bool] | None = None
    weak_thr: list[float] | None = None
    weak_thr_sd: list[float] | None = None


class SpikeSorterDynamicCriteria(BaseModel):
    """Criteria stringency levels for AI auto-updates."""

    model_config = ConfigDict(frozen=True)

    detect: (
        Annotated[
            SpikeSorterCriterionLevel | SpikeSorterCriterionLevelStr,
            BeforeValidator(_coerce_spike_sorter_criterion_level),
        ]
        | None
    ) = None
    train: (
        Annotated[
            SpikeSorterCriterionLevel | SpikeSorterCriterionLevelStr,
            BeforeValidator(_coerce_spike_sorter_criterion_level),
        ]
        | None
    ) = None
    sort: (
        Annotated[
            SpikeSorterCriterionLevel | SpikeSorterCriterionLevelStr,
            BeforeValidator(_coerce_spike_sorter_criterion_level),
        ]
        | None
    ) = None


class SpikeSorterDynamicUpdatePeriod(BaseModel):
    """Update periods in seconds for AI auto-updates."""

    model_config = ConfigDict(frozen=True)

    detect: float | None = None
    train: float | None = None
    sort: float | None = None


class SpikeSorterDynamicConfig(BaseModel):
    """Configuration for AI dynamic tracking auto-updates.

    Attributes:
        is_enabled: Whether dynamic AI tracking is enabled.
        update_period_sec: Schedule for dynamic updates.
        criteria: Stringency criteria for updates.
    """

    model_config = ConfigDict(frozen=True)

    is_enabled: bool | None = None
    update_period_sec: SpikeSorterDynamicUpdatePeriod | None = None
    criteria: SpikeSorterDynamicCriteria | None = None


class SpikeSorterCommand(IntEnum):
    """Commands for controlling an active spike sorter."""

    ON = 0
    OFF = 1
    CLEAR_SORT = 2
    REBASE = 4
    INIT = 5


_SPIKE_SORTER_COMMAND_MAP: dict[str, SpikeSorterCommand] = {
    "on": SpikeSorterCommand.ON,
    "off": SpikeSorterCommand.OFF,
    "clear_sort": SpikeSorterCommand.CLEAR_SORT,
    "rebase": SpikeSorterCommand.REBASE,
    "init": SpikeSorterCommand.INIT,
}


def _coerce_spike_sorter_command(v: object) -> SpikeSorterCommand:
    """Coerce raw Python types into ``SpikeSorterCommand``."""
    if isinstance(v, SpikeSorterCommand):
        return v
    if isinstance(v, str):
        key = v.strip().lower()
        if key in _SPIKE_SORTER_COMMAND_MAP:
            return _SPIKE_SORTER_COMMAND_MAP[key]
        valid = [k.upper() for k in _SPIKE_SORTER_COMMAND_MAP]
        raise ValueError(f"Invalid SpikeSorterCommand string {v!r} — valid values: {valid}")
    raise ValueError(f"Expected SpikeSorterCommand or str — got {type(v).__name__}")


SpikeSorterCommandStr = Literal["ON", "OFF", "CLEAR_SORT", "REBASE", "INIT"]

FlexSpikeSorterCommand = Annotated[
    SpikeSorterCommand | SpikeSorterCommandStr, BeforeValidator(_coerce_spike_sorter_command)
]
"""``SpikeSorterCommand`` that also accepts a string name (case-insensitive)."""


class SpikeSorterSubCommand(IntEnum):
    """Sub-commands for spike sorter operations."""

    NULL = 0  # Full sorting with clustering
    DETECT_ONLY = 2  # Detect spikes without sorting/clustering


_SPIKE_SORTER_SUB_COMMAND_MAP: dict[str, SpikeSorterSubCommand] = {
    "null": SpikeSorterSubCommand.NULL,
    "detect_only": SpikeSorterSubCommand.DETECT_ONLY,
}


def _coerce_spike_sorter_sub_command(v: object) -> SpikeSorterSubCommand:
    """Coerce raw Python types into ``SpikeSorterSubCommand``."""
    if isinstance(v, SpikeSorterSubCommand):
        return v
    if isinstance(v, str):
        key = v.strip().lower()
        if key in _SPIKE_SORTER_SUB_COMMAND_MAP:
            return _SPIKE_SORTER_SUB_COMMAND_MAP[key]
        valid = [k.upper() for k in _SPIKE_SORTER_SUB_COMMAND_MAP]
        raise ValueError(f"Invalid SpikeSorterSubCommand string {v!r} — valid values: {valid}")
    raise ValueError(f"Expected SpikeSorterSubCommand or str — got {type(v).__name__}")


SpikeSorterSubCommandStr = Literal["NULL", "DETECT_ONLY"]

FlexSpikeSorterSubCommand = Annotated[
    SpikeSorterSubCommand | SpikeSorterSubCommandStr, BeforeValidator(_coerce_spike_sorter_sub_command)
]
"""``SpikeSorterSubCommand`` that also accepts a string name (case-insensitive)."""


class SpikeSorterStateSystem(IntEnum):
    """Overall system state of a spike sorter."""

    ON = 0
    OFF = 1
    NOT_CONFIGURED = 2


class SpikeSorterState(BaseModel):
    """Current state and progress of a spike sorter.

    Attributes:
        sys: Overall system state (ON, OFF, NOT_CONFIGURED).
        frac_complete: Fraction of the current operation completed (0.0 to 1.0).
        is_on: Whether the sorter is currently active.
        msg: Status message from the server.
        error_msg: Error message if the sorter is in an error state.
        warn_msg: Warning message from the server.
    """

    model_config = ConfigDict(frozen=True)

    sys: SpikeSorterStateSystem
    frac_complete: float = 0.0
    is_on: bool = False
    msg: str = ""
    error_msg: str = ""
    warn_msg: str = ""


class InputFeatureType(IntEnum):
    """Feature types used for spike sorting."""

    WFM = 0
    SPD = 1
    WFM_POS = 2
    SPD_POS = 3


def _coerce_input_feature_type(v: object) -> InputFeatureType:
    """Coerce raw Python types into ``InputFeatureType``."""
    if isinstance(v, InputFeatureType):
        return v
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return InputFeatureType[key]
        except KeyError:
            valid = [t.name for t in InputFeatureType]
            raise ValueError(f"Invalid InputFeatureType string {v!r} — valid values: {valid}") from None
    raise ValueError(f"Expected InputFeatureType or str — got {type(v).__name__}") from None


InputFeatureTypeStr = Literal["WFM", "SPD", "WFM_POS", "SPD_POS"]


class SpikeSorterFeatureParams(BaseModel):
    """Parameters for feature extraction during spike sorting.

    Attributes:
        num_features: Number of features to extract.
        feature_type: Type of features to extract. Also accepts string names
            (e.g. ``"wfm"``, ``"spd_pos"``).
        latent_dim: Latent dimension for feature reduction.
        resample_wfm_len: Length to resample waveforms to.
    """

    model_config = ConfigDict(frozen=True)

    num_features: int
    feature_type: Annotated[InputFeatureType | InputFeatureTypeStr, BeforeValidator(_coerce_input_feature_type)] = (
        InputFeatureType.WFM
    )
    latent_dim: int | None = None
    resample_wfm_len: int | None = None


class SpikeSorterClustererParams(BaseModel):
    """Parameters for the spike clustering algorithm.

    Attributes:
        pos_influence_frac: Influence of spike position on clustering.
        wfm_shape_influence_frac: Influence of waveform shape on clustering.
        eps: Epsilon parameter for DBSCAN-like clustering.
        min_pts: Minimum points for a cluster.
        disabled: Whether clustering is disabled.
    """

    model_config = ConfigDict(frozen=True)

    pos_influence_frac: float | None = None
    wfm_shape_influence_frac: float | None = None
    eps: float | None = None
    min_pts: int | None = None
    disabled: bool = False


class SpikeSorterLaunchParams(BaseModel):
    """Parameters for launching a new spike sorter.

    Attributes:
        dsource_id: ID of the data source to sort (required for file sorting).
        discover_noise: Whether to perform noise discovery.
        is_auto_on: Whether to automatically start sorting after launch.
        nbr_pattern: Neighbor pattern for multi-channel sorting.
        sink_dsrc_id: ID for the resultant .spikes file.
        sub_cmd: Sub-command for the sorting operation.
        clusterer_params: Optional clustering parameters.
        feature_params: Optional feature extraction parameters.
    """

    model_config = ConfigDict(frozen=True)

    dsource_id: str | None = None
    discover_noise: bool = True
    is_auto_on: bool = True
    nbr_pattern: int | None = None
    sink_dsrc_id: str | None = None
    sub_cmd: SpikeSorterSubCommand = SpikeSorterSubCommand.NULL
    clusterer_params: SpikeSorterClustererParams | None = None
    feature_params: SpikeSorterFeatureParams | None = None


class SpikeSorterLaunchResult(BaseModel):
    """Result of a spike sorter launch request.

    Attributes:
        spike_sorter_id: Unique ID of the launched sorter.
        sorter_type: Type of the launched sorter.
        msg: Status message from the server.
    """

    model_config = ConfigDict(frozen=True)

    spike_sorter_id: str
    sorter_type: SpikeSorterType
    msg: str = ""


class DashElement(IntEnum):
    """Elements available for the spike sorter dashboard."""

    ENABLED_PORTS = 1
    GENERAL = 2
    PORT_STATS = 3
    SITE_STATS = 4
    SITE_PANEL = 5
    NEURON_STATS = 6
    NEURON_PANEL = 7
    AI = 8


def _coerce_dash_element(v: object) -> DashElement:
    """Coerce raw Python types into ``DashElement``.

    Accepted inputs:

    - ``DashElement`` — pass-through
    - ``str`` — case-insensitive enum name (e.g. ``"general"``, ``"port_stats"``)
    - ``int`` — enum value (``1``-``8``)
    """
    if isinstance(v, DashElement):
        return v
    if isinstance(v, int):
        try:
            return DashElement(v)
        except ValueError:
            valid_ints = [e.value for e in DashElement]
            raise ValueError(f"Invalid DashElement int {v!r} — valid values: {valid_ints}") from None
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return DashElement[key]
        except KeyError:
            valid_strs = [e.name for e in DashElement]
            raise ValueError(f"Invalid DashElement string {v!r} — valid values: {valid_strs}") from None
    raise ValueError(f"Expected DashElement, str, or int — got {type(v).__name__}") from None


DashElementStr = Literal[
    "ENABLED_PORTS",
    "GENERAL",
    "PORT_STATS",
    "SITE_STATS",
    "SITE_PANEL",
    "NEURON_STATS",
    "NEURON_PANEL",
    "AI",
]

FlexDashElement = Annotated[DashElement | DashElementStr | int, BeforeValidator(_coerce_dash_element)]
"""``DashElement`` that also accepts a string name or int value."""


class SpikeSorterDashboardGeneral(BaseModel):
    """General summary metrics for the spike sorter dashboard."""

    model_config = ConfigDict(frozen=True)

    state: SpikeSorterState
    sorter_type: SpikeSorterType
    sorter_id: str
    datasource_id: str
    time_range: tuple[float, float]
    num_total_sites: int
    num_enabled_sites: int
    num_active_sites: int
    num_neurons: int
    probe_yield: float
    site_yield: float
    num_spikes_processed: int
    num_spikes_labeled: int
    sort_efficiency: float


class SpikeSorterDashboard(BaseModel):
    """Comprehensive spike sorter dashboard data.

    Attributes:
        enabled_ports: List of hardware ports with active sorting.
        general: General summary metrics.
    """

    model_config = ConfigDict(frozen=True)

    enabled_ports: list[Port] = Field(default_factory=list)
    general: SpikeSorterDashboardGeneral | None = None
