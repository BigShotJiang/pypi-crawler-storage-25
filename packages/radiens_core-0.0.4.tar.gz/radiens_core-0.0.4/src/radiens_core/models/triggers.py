"""Trigger control domain models and enums."""

from __future__ import annotations

from enum import IntEnum
from typing import Annotated

from pydantic import BaseModel, BeforeValidator, ConfigDict

from radiens_core.models.ports import Port
from radiens_core.models.stim import StimKeypressIndex


class TriggerChannel(IntEnum):
    """Trigger channel identifier. Values match proto ``allego.TriggerChannel``."""

    T_DIN_0 = 0
    T_DIN_1 = 1
    T_DIN_2 = 2
    T_DIN_3 = 3
    T_DIN_4 = 4
    T_DIN_5 = 5
    T_DIN_6 = 6
    T_DIN_7 = 7
    T_DIN_8 = 8
    T_DIN_9 = 9
    T_DIN_10 = 10
    T_DIN_11 = 11
    T_DIN_12 = 12
    T_DIN_13 = 13
    T_DIN_14 = 14
    T_DIN_15 = 15
    T_DOUT_0 = 16
    T_DOUT_1 = 17
    T_DOUT_2 = 18
    T_DOUT_3 = 19
    T_DOUT_4 = 20
    T_DOUT_5 = 21
    T_DOUT_6 = 22
    T_DOUT_7 = 23
    T_DOUT_8 = 24
    T_DOUT_9 = 25
    T_DOUT_10 = 26
    T_DOUT_11 = 27
    T_DOUT_12 = 28
    T_DOUT_13 = 29
    T_DOUT_14 = 30
    T_DOUT_15 = 31
    T_NONE = 32


def _coerce_trigger_channel(v: object) -> TriggerChannel:
    """Coerce raw Python types into ``TriggerChannel``.

    Accepted inputs:

    - ``TriggerChannel`` — pass-through
    - ``str`` — short name without ``T_`` prefix, case-insensitive
      (e.g. ``"din_0"``, ``"dout_5"``, ``"none"``)
    - ``int`` — raw IntEnum value (``0``-``32``)
    """
    if isinstance(v, TriggerChannel):
        return v
    if isinstance(v, int):
        try:
            return TriggerChannel(v)
        except ValueError:
            valid_range = (TriggerChannel.T_DIN_0.value, TriggerChannel.T_NONE.value)
            raise ValueError(
                f"Invalid TriggerChannel int {v!r} — valid range: {valid_range[0]}-{valid_range[1]}"
            ) from None
    if isinstance(v, str):
        s = v.strip().upper()
        # Accept short name without T_ prefix (e.g. "din_0" -> T_DIN_0)
        try:
            return TriggerChannel["T_" + s]
        except KeyError:
            pass
        valid_examples = ["din_0", "dout_5", "none"]
        raise ValueError(
            f"Invalid TriggerChannel string {v!r} — "
            f"use short name without 'T_' prefix (e.g. {valid_examples}), "
            f"or an int 0-32"
        )
    raise ValueError(f"Expected TriggerChannel, str, or int — got {type(v).__name__}")


FlexTriggerChannel = Annotated[TriggerChannel | str | int, BeforeValidator(_coerce_trigger_channel)]
"""``TriggerChannel`` that also accepts a string name or int value.

String inputs use the short name without the ``T_`` prefix, case-insensitively
(e.g. ``"din_0"``, ``"dout_5"``, ``"none"``).

Use with ``@validate_call``::

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def enable_trigger(self, *, channel: FlexTriggerChannel, ...) -> None:
        ch = validated(channel, TriggerChannel)
        ...
"""


class SetTriggerStateRequest(BaseModel):
    """Request to set trigger channel state.

    Attributes:
        channel: Trigger channel identifier. References TriggerChannel.
        enabled: Whether the channel should be enabled.
        port: Hardware port identifier. References Port.
    """

    model_config = ConfigDict(frozen=True)

    channel: TriggerChannel
    enabled: bool
    port: Port


class TriggerState(BaseModel):
    """Current trigger channel configuration.

    Attributes:
        enabled_channels: List of currently enabled trigger channels.
        ports: List of ports with enabled triggers.
    """

    model_config = ConfigDict(frozen=True)

    enabled_channels: list[TriggerChannel]
    ports: list[Port]


class ManualStimTriggerRequest(BaseModel):
    """Request for manual stimulation trigger.

    Attributes:
        trigger: Keypress trigger (1-8). References StimKeypressIndex.
        trigger_on: Whether to turn the trigger on or off.
    """

    model_config = ConfigDict(frozen=True)

    trigger: StimKeypressIndex
    trigger_on: bool


class ManualStimTriggerToggleRequest(BaseModel):
    """Request to toggle manual stimulation trigger.

    Attributes:
        trigger: Keypress trigger (1-8). References StimKeypressIndex.
    """

    model_config = ConfigDict(frozen=True)

    trigger: StimKeypressIndex
