"""Port and GPIO domain models and enums."""

from __future__ import annotations

from enum import IntEnum
from typing import Annotated, Literal

from pydantic import BaseModel, BeforeValidator, ConfigDict


class Port(IntEnum):
    """Hardware port identifier. Values match proto ``common.Port``."""

    A = 0
    B = 1
    C = 2
    D = 3
    E = 4
    F = 5
    G = 6
    H = 7


def _coerce_port(v: object) -> Port:
    """Coerce raw Python types into ``Port``.

    Accepted inputs:

    - ``Port`` — pass-through
    - ``str`` — case-insensitive single-letter name (``"a"`` through ``"h"``)
    - ``int`` — positional index (``0``-``7``)
    """
    if isinstance(v, Port):
        return v
    if isinstance(v, int):
        try:
            return Port(v)
        except ValueError:
            valid_ints = [p.value for p in Port]
            raise ValueError(f"Invalid Port int {v!r} — valid values: {valid_ints}") from None
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return Port[key]
        except KeyError:
            valid_strs = [p.name for p in Port]
            raise ValueError(f"Invalid Port string {v!r} — valid values: {valid_strs}") from None
    raise ValueError(f"Expected Port, int, or str — got {type(v).__name__}") from None


PortStr = Literal["A", "B", "C", "D", "E", "F", "G", "H"]

FlexPort = Annotated[Port | PortStr | int, BeforeValidator(_coerce_port)]
"""``Port`` that also accepts a single-letter string or int index.

Use with ``@validate_call``::

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def start_recording(self, *, port: FlexPort | None = None) -> None:
        p = validated(port, Port) if port is not None else None
        ...
"""


class PortChannelCount(BaseModel):
    """Port channel count information.

    Attributes:
        port: Hardware port identifier. References Port.
        channel_count: Number of channels on the port.
    """

    model_config = ConfigDict(frozen=True)

    port: Port
    channel_count: int


class GPIOChannelCount(BaseModel):
    """GPIO channel count information.

    Attributes:
        n_aux: Number of auxiliary channels.
        n_din: Number of digital input channels.
        n_dout: Number of digital output channels.
    """

    model_config = ConfigDict(frozen=True)

    n_aux: int
    n_din: int
    n_dout: int
