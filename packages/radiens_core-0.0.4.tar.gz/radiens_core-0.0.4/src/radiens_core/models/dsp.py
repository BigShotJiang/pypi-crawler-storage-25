"""Digital Signal Processing (DSP) domain models and enums."""

from __future__ import annotations

from enum import IntEnum
from typing import Annotated, Literal, Required, TypedDict

from pydantic import BaseModel, BeforeValidator, ConfigDict

from radiens_core.models.ports import Port, PortStr, _coerce_port


class DSPType(IntEnum):
    """Digital Signal Processing filter type. Values match proto ``common.DSPType``."""

    LOWPASS = 0
    HIGHPASS = 1
    BANDPASS = 2
    NOTCH = 3
    BANDSTOP = 4
    CAR = 5
    VIRTUAL_REFERENCE = 6
    PAIRED_REFERENCE = 7


def _coerce_dsp_type(v: object) -> DSPType:
    """Coerce raw Python types into ``DSPType``.

    Accepted inputs:

    - ``DSPType`` — pass-through
    - ``str`` — case-insensitive name (``"LOWPASS"``, ``"HIGHPASS"``, etc.)
    - ``int`` — enum value
    """
    if isinstance(v, DSPType):
        return v
    if isinstance(v, int):
        try:
            return DSPType(v)
        except ValueError:
            valid_ints = [t.value for t in DSPType]
            raise ValueError(f"Invalid DSPType int {v!r} — valid values: {valid_ints}") from None
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return DSPType[key]
        except KeyError:
            valid_strs = [t.name for t in DSPType]
            raise ValueError(f"Invalid DSPType string {v!r} — valid values: {valid_strs}") from None
    raise ValueError(f"Expected DSPType, int, or str — got {type(v).__name__}") from None


DSPTypeStr = Literal[
    "LOWPASS", "HIGHPASS", "BANDPASS", "NOTCH", "BANDSTOP", "CAR", "VIRTUAL_REFERENCE", "PAIRED_REFERENCE"
]

FlexDSPType = Annotated[DSPType | DSPTypeStr | int, BeforeValidator(_coerce_dsp_type)]
"""``DSPType`` that also accepts a string name or int value."""


class FilterStage(IntEnum):
    """Digital Signal Processing filter stage. Values match proto ``common.FilterStage``."""

    STAGE_HARDWARE = 0
    STAGE1 = 1
    STAGE2 = 2
    SPIKE_SORTER = 3


_FILTER_STAGE_ALIASES: dict[str, FilterStage] = {
    "hardware": FilterStage.STAGE_HARDWARE,
    "stage1": FilterStage.STAGE1,
    "stage2": FilterStage.STAGE2,
    "spike_sorter": FilterStage.SPIKE_SORTER,
}


def _coerce_filter_stage(v: object) -> FilterStage:
    """Coerce raw Python types into ``FilterStage``.

    Accepted inputs:

    - ``FilterStage`` — pass-through
    - ``str`` — canonical name (``"HARDWARE"``, ``"STAGE1"``, ``"STAGE2"``, ``"SPIKE_SORTER"``), case-insensitive
    - ``int`` — positional index (``0``-``3``)
    """
    if isinstance(v, FilterStage):
        return v
    if isinstance(v, int):
        try:
            return FilterStage(v)
        except ValueError:
            valid_ints = [s.value for s in FilterStage]
            raise ValueError(f"Invalid FilterStage int {v!r} — valid values: {valid_ints}") from None
    if isinstance(v, str):
        key = v.strip().lower()
        if key in _FILTER_STAGE_ALIASES:
            return _FILTER_STAGE_ALIASES[key]
        valid_strs = [k.upper() for k in _FILTER_STAGE_ALIASES]
        raise ValueError(f"Invalid FilterStage string {v!r} — valid values: {valid_strs}")
    raise ValueError(f"Expected FilterStage, int, or str — got {type(v).__name__}")


FilterStageStr = Literal["HARDWARE", "STAGE1", "STAGE2", "SPIKE_SORTER"]

FlexFilterStage = Annotated[FilterStage | FilterStageStr | int, BeforeValidator(_coerce_filter_stage)]
"""``FilterStage`` that also accepts a canonical string name or int index.

Use with ``@validate_call`` or pass to ``_coerce_filter_stage()`` for manual coercion::

    stage_enum: FilterStage = _coerce_filter_stage(stage)
"""


class FreqSpecBand(BaseModel):
    """Frequency band specification for filters.

    Attributes:
        low_freq: Low frequency in Hertz.
        high_freq: High frequency in Hertz.
    """

    model_config = ConfigDict(frozen=True)

    low_freq: float
    high_freq: float


def _coerce_port_optional(v: object) -> Port | None:
    """Coerce raw Python types into ``Port`` or pass ``None`` through."""
    if v is None:
        return None
    return _coerce_port(v)


class DSPParams(BaseModel):
    """Configuration parameters for a single DSP filter stage.

    Attributes:
        type: DSP filter type. References DSPType. Also accepts string names (e.g. ``"highpass"``).
        stage: DSP filter stage. References FilterStage. Also accepts string names or int index.
        freq: Filter frequency. Defaults to None.
        freq_spec_band: Frequency band specification. Defaults to None.
        ref_ntv_chan_idx: Reference native channel index. Defaults to None.
        notch_bandwidth: Notch filter bandwidth. Defaults to None.
        user_label: User-defined label for the filter. Defaults to "".
        port: Port configuration. References Port. Also accepts string name or int index. Defaults to None.
        target_ntv_chan_idx: Target native channel index. Defaults to None.
        is_aux: Whether this is an auxiliary filter. Defaults to False.
        aux_chan_idx: Auxiliary channel index. Defaults to None.
        filter_order: Filter order. Defaults to None.
        zero_phase: Whether to use zero-phase filtering. Defaults to False.
        force_sos: Whether to force Second-Order Sections. Defaults to False.
    """

    model_config = ConfigDict(frozen=True)

    type: Annotated[DSPType | DSPTypeStr, BeforeValidator(_coerce_dsp_type)]
    stage: Annotated[FilterStage | FilterStageStr | int, BeforeValidator(_coerce_filter_stage)]
    freq: float | None = None
    freq_spec_band: FreqSpecBand | None = None
    ref_ntv_chan_idx: int | None = None
    notch_bandwidth: float | None = None
    user_label: str = ""
    port: Annotated[Port | PortStr | int | None, BeforeValidator(_coerce_port_optional)] = None
    target_ntv_chan_idx: float | None = None
    is_aux: bool = False
    aux_chan_idx: int | None = None
    filter_order: int | None = None
    zero_phase: bool = False
    force_sos: bool = False


class DSPParamsDict(TypedDict, total=False):
    """Typed dict shorthand for :class:`DSPParams`.

    The ``type`` key is required; all other keys are optional. ``stage`` is
    injected from the calling method's ``stage=`` argument if omitted.

    Example::

        {"type": "highpass", "freq": 300.0}
        {"type": "bandpass", "freq_spec_band": {"low_freq": 300.0, "high_freq": 5000.0}}
    """

    type: Required[DSPType | DSPTypeStr]
    stage: FilterStage | FilterStageStr | int
    freq: float | None
    freq_spec_band: FreqSpecBand | None
    ref_ntv_chan_idx: int | None
    notch_bandwidth: float | None
    user_label: str
    port: Port | PortStr | int | None
    target_ntv_chan_idx: float | None
    is_aux: bool
    aux_chan_idx: int | None
    filter_order: int | None
    zero_phase: bool
    force_sos: bool


FlexDSPParams = DSPParams | DSPParamsDict
"""``DSPParams`` that also accepts a :class:`DSPParamsDict` typed-dict shorthand.

When used in ``set_dsp_group``, the ``stage`` key is optional — the method
injects it from its own ``stage=`` argument if omitted.

Example::

    client.set_dsp_group(stage="stage1", params=[{"type": "highpass", "freq": 300.0}])
"""


def _resolve_dsp_param(p: DSPParams | DSPParamsDict, stage: FilterStage) -> DSPParams:
    """Coerce a typed-dict shorthand or pass-through a ``DSPParams``, injecting ``stage`` if absent."""
    if isinstance(p, DSPParams):
        return p
    d = dict(p)
    if "stage" not in d:
        d["stage"] = stage
    return DSPParams(**d)  # type: ignore[arg-type]


class DSPGroup(BaseModel):
    """Group of DSP filter stages, organized by hardware/software layers.

    Attributes:
        hardware: List of hardware filter stages.
        software_stage1: List of software stage 1 filters.
        software_stage2: List of software stage 2 filters.
        spike_sorter: List of spike sorter filters.
    """

    model_config = ConfigDict(frozen=True)

    hardware: list[DSPParams]
    software_stage1: list[DSPParams]
    software_stage2: list[DSPParams]
    spike_sorter: list[DSPParams]
