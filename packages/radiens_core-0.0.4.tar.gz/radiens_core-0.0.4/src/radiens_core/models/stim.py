"""Stimulation domain models and enums."""

from __future__ import annotations

from enum import IntEnum
from typing import Annotated, Literal

from pydantic import BaseModel, BeforeValidator, ConfigDict

# ===================================================================
# Stimulation enums
# ===================================================================


class StimShape(IntEnum):
    """Stimulation waveform shape. Values match proto ``allego.StimShape``."""

    BIPHASIC = 0
    BIPHASIC_INTERPHASE_DELAY = 1
    TRIPHASIC = 2
    MONOPHASIC = 3


def _coerce_stim_shape(v: object) -> StimShape:
    """Coerce raw Python types into ``StimShape``."""
    if isinstance(v, StimShape):
        return v
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return StimShape[key]
        except KeyError:
            valid = [s.name for s in StimShape]
            raise ValueError(f"Invalid StimShape string {v!r} — valid values: {valid}") from None
    raise ValueError(f"Expected StimShape or str — got {type(v).__name__}") from None


StimShapeStr = Literal["BIPHASIC", "BIPHASIC_INTERPHASE_DELAY", "TRIPHASIC", "MONOPHASIC"]


class StimPolarity(IntEnum):
    """Stimulation polarity. Values match proto ``allego.StimPolarity``."""

    CATHODIC_FIRST = 0
    ANODIC_FIRST = 1


def _coerce_stim_polarity(v: object) -> StimPolarity:
    """Coerce raw Python types into ``StimPolarity``."""
    if isinstance(v, StimPolarity):
        return v
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return StimPolarity[key]
        except KeyError:
            valid = [p.name for p in StimPolarity]
            raise ValueError(f"Invalid StimPolarity string {v!r} — valid values: {valid}") from None
    raise ValueError(f"Expected StimPolarity or str — got {type(v).__name__}") from None


StimPolarityStr = Literal["CATHODIC_FIRST", "ANODIC_FIRST"]


class StimTriggerEdgeOrLevel(IntEnum):
    """Stimulation trigger edge/level mode. Values match proto ``allego.StimTriggerEdgeOrLevel``."""

    EDGE = 0
    LEVEL = 1


def _coerce_stim_trigger_edge_or_level(v: object) -> StimTriggerEdgeOrLevel:
    """Coerce raw Python types into ``StimTriggerEdgeOrLevel``."""
    if isinstance(v, StimTriggerEdgeOrLevel):
        return v
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return StimTriggerEdgeOrLevel[key]
        except KeyError:
            valid = [e.name for e in StimTriggerEdgeOrLevel]
            raise ValueError(f"Invalid StimTriggerEdgeOrLevel string {v!r} — valid values: {valid}") from None
    raise ValueError(f"Expected StimTriggerEdgeOrLevel or str — got {type(v).__name__}") from None


StimTriggerEdgeOrLevelStr = Literal["EDGE", "LEVEL"]


class StimTriggerHighOrLow(IntEnum):
    """Stimulation trigger high/low. Values match proto ``allego.StimTriggerHighOrLow``."""

    HIGH = 0
    LOW = 1


def _coerce_stim_trigger_high_or_low(v: object) -> StimTriggerHighOrLow:
    """Coerce raw Python types into ``StimTriggerHighOrLow``."""
    if isinstance(v, StimTriggerHighOrLow):
        return v
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return StimTriggerHighOrLow[key]
        except KeyError:
            valid = [h.name for h in StimTriggerHighOrLow]
            raise ValueError(f"Invalid StimTriggerHighOrLow string {v!r} — valid values: {valid}") from None
    raise ValueError(f"Expected StimTriggerHighOrLow or str — got {type(v).__name__}") from None


StimTriggerHighOrLowStr = Literal["HIGH", "LOW"]


class StimPulseMode(IntEnum):
    """Stimulation pulse mode. Values match proto ``allego.StimPulseOrTrain``."""

    SINGLE_PULSE = 0
    PULSE_TRAIN = 1


def _coerce_stim_pulse_mode(v: object) -> StimPulseMode:
    """Coerce raw Python types into ``StimPulseMode``."""
    if isinstance(v, StimPulseMode):
        return v
    if isinstance(v, str):
        key = v.strip().upper()
        try:
            return StimPulseMode[key]
        except KeyError:
            valid = [m.name for m in StimPulseMode]
            raise ValueError(f"Invalid StimPulseMode string {v!r} — valid values: {valid}") from None
    raise ValueError(f"Expected StimPulseMode or str — got {type(v).__name__}") from None


StimPulseModeStr = Literal["SINGLE_PULSE", "PULSE_TRAIN"]


class StimKeypressIndex(IntEnum):
    KEYPRESS_1 = 1
    KEYPRESS_2 = 2
    KEYPRESS_3 = 3
    KEYPRESS_4 = 4
    KEYPRESS_5 = 5
    KEYPRESS_6 = 6
    KEYPRESS_7 = 7
    KEYPRESS_8 = 8


def _coerce_stim_keypress_index(v: object) -> StimKeypressIndex:
    """Coerce raw Python types into ``StimKeypressIndex``.

    Accepted inputs:

    - ``StimKeypressIndex`` — pass-through
    - ``int`` — keypress number (``1``-``8``)
    """
    if isinstance(v, StimKeypressIndex):
        return v
    if isinstance(v, int):
        try:
            return StimKeypressIndex(v)
        except ValueError:
            valid = [k.value for k in StimKeypressIndex]
            raise ValueError(f"Invalid StimKeypressIndex int {v!r} — valid values: {valid} (1-8)") from None
    raise ValueError(f"Expected StimKeypressIndex or int — got {type(v).__name__}") from None


FlexStimKeypressIndex = Annotated[StimKeypressIndex | int, BeforeValidator(_coerce_stim_keypress_index)]
"""``StimKeypressIndex`` that also accepts a plain int (1-8).

Use with ``@validate_call``::

    @validate_call(config=ConfigDict(arbitrary_types_allowed=True))
    def set_stim_trigger(self, *, trigger: FlexStimKeypressIndex, on: bool) -> None:
        t = validated(trigger, StimKeypressIndex)
        ...
"""


class StimStep(IntEnum):
    """Stimulation step size. Values match proto ``allego.StimStep``."""

    STIM_STEP_SIZE_MIN = 0
    STIM_STEP_SIZE_10_NA = 1
    STIM_STEP_SIZE_20_NA = 2
    STIM_STEP_SIZE_50_NA = 3
    STIM_STEP_SIZE_100_NA = 4
    STIM_STEP_SIZE_200_NA = 5
    STIM_STEP_SIZE_500_NA = 6
    STIM_STEP_SIZE_1_UA = 7
    STIM_STEP_SIZE_2_UA = 8
    STIM_STEP_SIZE_5_UA = 9
    STIM_STEP_SIZE_10_UA = 10
    STIM_STEP_SIZE_MAX = 11


class StimParamsPartial(BaseModel):
    """Partial version of ``StimParams`` where all fields are optional.

    Use for filtering/stim event lookup where only a subset of parameters is known.
    Any field left as ``None`` is treated as "don't care" by the callee.

    Attributes:
        stim_sys_chan_idx: System channel index (ntvAbsKeyIdx).
        stim_shape: Stimulation waveform shape.
        stim_polarity: Stimulation polarity.
        first_phase_duration: Duration of the first phase in μs.
        second_phase_duration: Duration of the second phase in μs.
        interphase_delay: Delay between phases in μs.
        first_phase_amplitude: Amplitude of the first phase (μA for amp, V for DAC).
        second_phase_amplitude: Amplitude of the second phase (μA for amp, V for DAC).
        baseline_voltage: Baseline voltage in V.
        trigger_edge_or_level: Trigger mode.
        trigger_high_or_low: Trigger polarity.
        enabled: Whether stimulation is enabled for this channel.
        post_trigger_delay: Delay after trigger before stimulation in μs.
        pulse_or_train: Pulse or train mode.
        number_of_stim_pulses: Number of pulses in a train.
        pulse_train_period: Period of pulses in a train in μs.
        refractory_period: Refractory period in μs.
        pre_stim_amp_settle: Pre-stimulation amplifier settle time in μs.
        post_stim_amp_settle: Post-stimulation amplifier settle time in μs.
        maintain_amp_settle: Whether to maintain amplifier settle.
        enable_amp_settle: Whether to enable amplifier settle.
        headstage_global_amp_settle: Whether to enable global headstage amp settle.
        post_stim_charge_recov_on: Post-stimulation charge recovery on time in μs.
        post_stim_charge_recov_off: Post-stimulation charge recovery off time in μs.
        enable_charge_recovery: Whether to enable charge recovery.
        trigger_source_is_keypress: Whether the trigger source is a keypress.
        trigger_source_idx: AIN/DIN system channel index, or keypress number.
    """

    model_config = ConfigDict(frozen=True)

    stim_sys_chan_idx: int | None = None
    stim_shape: Annotated[StimShape | StimShapeStr, BeforeValidator(_coerce_stim_shape)] | None = None
    stim_polarity: Annotated[StimPolarity | StimPolarityStr, BeforeValidator(_coerce_stim_polarity)] | None = None
    first_phase_duration: float | None = None
    second_phase_duration: float | None = None
    interphase_delay: float | None = None
    first_phase_amplitude: float | None = None
    second_phase_amplitude: float | None = None
    baseline_voltage: float | None = None
    trigger_edge_or_level: (
        Annotated[
            StimTriggerEdgeOrLevel | StimTriggerEdgeOrLevelStr, BeforeValidator(_coerce_stim_trigger_edge_or_level)
        ]
        | None
    ) = None
    trigger_high_or_low: (
        Annotated[StimTriggerHighOrLow | StimTriggerHighOrLowStr, BeforeValidator(_coerce_stim_trigger_high_or_low)]
        | None
    ) = None
    enabled: bool | None = None
    post_trigger_delay: float | None = None
    pulse_or_train: Annotated[StimPulseMode | StimPulseModeStr, BeforeValidator(_coerce_stim_pulse_mode)] | None = None
    number_of_stim_pulses: int | None = None
    pulse_train_period: float | None = None
    refractory_period: float | None = None
    pre_stim_amp_settle: float | None = None
    post_stim_amp_settle: float | None = None
    maintain_amp_settle: bool | None = None
    enable_amp_settle: bool | None = None
    headstage_global_amp_settle: bool | None = None
    post_stim_charge_recov_on: float | None = None
    post_stim_charge_recov_off: float | None = None
    enable_charge_recovery: bool | None = None
    trigger_source_is_keypress: bool | None = None
    trigger_source_idx: int | StimKeypressIndex | None = None

    def valid_keys(self) -> list[str]:
        """Return a list of only the fields that are not None."""
        return [k for k, v in self.model_dump().items() if v is not None]


class StimParams(BaseModel):
    """Stimulation parameters for a single channel.

    All timing values are in microseconds (μs). Current amplitudes are in μA
    for amplifier channels and V for DAC channels.

    Attributes:
        stim_sys_chan_idx: System channel index (ntvAbsKeyIdx).
        stim_shape: Stimulation waveform shape. References StimShape. Also accepts
            string names (e.g. ``"biphasic"``). Defaults to StimShape.BIPHASIC.
        stim_polarity: Stimulation polarity. References StimPolarity. Also accepts
            string names (e.g. ``"cathodic_first"``). Defaults to StimPolarity.CATHODIC_FIRST.
        first_phase_duration: Duration of the first phase in μs. Defaults to 100.0.
        second_phase_duration: Duration of the second phase in μs. Defaults to 100.0.
        interphase_delay: Delay between phases in μs. Defaults to 0.0.
        first_phase_amplitude: Amplitude of the first phase (μA for amp, V for DAC). Defaults to 0.1.
        second_phase_amplitude: Amplitude of the second phase (μA for amp, V for DAC). Defaults to 0.0.
        baseline_voltage: Baseline voltage in V. Defaults to 0.0.
        trigger_edge_or_level: Trigger mode. References StimTriggerEdgeOrLevel. Also accepts
            string names. Defaults to StimTriggerEdgeOrLevel.EDGE.
        trigger_high_or_low: Trigger polarity. References StimTriggerHighOrLow. Also accepts
            string names. Defaults to StimTriggerHighOrLow.HIGH.
        enabled: Whether stimulation is enabled for this channel. Defaults to True.
        post_trigger_delay: Delay after trigger before stimulation in μs. Defaults to 0.0.
        pulse_or_train: Pulse or train mode. References StimPulseMode. Also accepts string
            names. Defaults to StimPulseMode.SINGLE_PULSE.
        number_of_stim_pulses: Number of pulses in a train. Defaults to 1.
        pulse_train_period: Period of pulses in a train in μs. Defaults to 0.0.
        refractory_period: Refractory period in μs. Defaults to 0.0.
        pre_stim_amp_settle: Pre-stimulation amplifier settle time in μs. Defaults to 0.0.
        post_stim_amp_settle: Post-stimulation amplifier settle time in μs. Defaults to 0.0.
        maintain_amp_settle: Whether to maintain amplifier settle. Defaults to False.
        enable_amp_settle: Whether to enable amplifier settle. Defaults to False.
        headstage_global_amp_settle: Whether to enable global headstage amp settle. Defaults to False.
        post_stim_charge_recov_on: Post-stimulation charge recovery on time in μs. Defaults to 0.0.
        post_stim_charge_recov_off: Post-stimulation charge recovery off time in μs. Defaults to 0.0.
        enable_charge_recovery: Whether to enable charge recovery. Defaults to False.
        trigger_source_is_keypress: Whether the trigger source is a keypress. Defaults to False.
        trigger_source_idx: AIN/DIN system channel index, or keypress number. References StimKeypressIndex if keypress.
    """

    model_config = ConfigDict(frozen=True)

    stim_sys_chan_idx: int
    stim_shape: Annotated[StimShape | StimShapeStr, BeforeValidator(_coerce_stim_shape)] = StimShape.BIPHASIC
    stim_polarity: Annotated[StimPolarity | StimPolarityStr, BeforeValidator(_coerce_stim_polarity)] = (
        StimPolarity.CATHODIC_FIRST
    )
    first_phase_duration: float = 100.0
    second_phase_duration: float = 100.0
    interphase_delay: float = 0.0
    first_phase_amplitude: float = 0.1
    second_phase_amplitude: float = 0.0
    baseline_voltage: float = 0.0
    trigger_edge_or_level: Annotated[
        StimTriggerEdgeOrLevel | StimTriggerEdgeOrLevelStr,
        BeforeValidator(_coerce_stim_trigger_edge_or_level),
    ] = StimTriggerEdgeOrLevel.EDGE
    trigger_high_or_low: Annotated[
        StimTriggerHighOrLow | StimTriggerHighOrLowStr,
        BeforeValidator(_coerce_stim_trigger_high_or_low),
    ] = StimTriggerHighOrLow.HIGH
    enabled: bool = True
    post_trigger_delay: float = 0.0
    pulse_or_train: Annotated[StimPulseMode | StimPulseModeStr, BeforeValidator(_coerce_stim_pulse_mode)] = (
        StimPulseMode.SINGLE_PULSE
    )
    number_of_stim_pulses: int = 1
    pulse_train_period: float = 0.0
    refractory_period: float = 0.0
    pre_stim_amp_settle: float = 0.0
    post_stim_amp_settle: float = 0.0
    maintain_amp_settle: bool = False
    enable_amp_settle: bool = False
    headstage_global_amp_settle: bool = False
    post_stim_charge_recov_on: float = 0.0
    post_stim_charge_recov_off: float = 0.0
    enable_charge_recovery: bool = False
    trigger_source_is_keypress: bool = False
    trigger_source_idx: int | StimKeypressIndex

    @classmethod
    def biphasic(
        cls: type[StimParams],
        *,
        amplitude: float,
        pulse_duration: float,
        polarity: StimPolarity,
        stim_sys_chan_idx: int,
        enabled: bool = True,
        **overrides: object,
    ) -> StimParams:
        """Create biphasic stimulation parameters.

        Args:
            amplitude: First phase amplitude (μA for amp channels)
            pulse_duration: Phase duration in microseconds
            polarity: Stimulation polarity (cathodic or anodic first)
            stim_sys_chan_idx: System channel index
            **overrides: Override any other StimParams field

        Returns:
            StimParams configured for biphasic stimulation
        """
        return cls(
            stim_shape=StimShape.BIPHASIC,
            stim_polarity=polarity,
            first_phase_duration=pulse_duration,
            second_phase_duration=pulse_duration,
            first_phase_amplitude=amplitude,
            second_phase_amplitude=amplitude,
            stim_sys_chan_idx=stim_sys_chan_idx,
            enabled=enabled,
            **overrides,  # type: ignore[arg-type]
        )


class StimStepRequest(BaseModel):
    """Request to set stimulation step size.

    Attributes:
        stim_step: Target stimulation step size. References StimStep.
    """

    model_config = ConfigDict(frozen=True)

    stim_step: StimStep


class StimStepState(BaseModel):
    """Current stimulation step size setting.

    Attributes:
        stim_step: Current stimulation step size. References StimStep.
    """

    model_config = ConfigDict(frozen=True)

    stim_step: StimStep
