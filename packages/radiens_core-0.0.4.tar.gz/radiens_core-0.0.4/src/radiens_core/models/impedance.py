"""Impedance measurement models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class ImpedanceValue(BaseModel):
    """Single channel impedance measurement.

    Attributes:
        ntv_chan_idx: Native channel index.
        magnitude_ohm: Impedance magnitude in Ohms.
        phase_deg: Impedance phase in degrees.
    """

    model_config = ConfigDict(frozen=True)
    ntv_chan_idx: int
    magnitude_ohm: float
    phase_deg: float


class Impedance(BaseModel):
    """Impedance measurements for multiple channels.

    Attributes:
        measurements: List of individual channel impedance measurements.
    """

    model_config = ConfigDict(frozen=True)
    measurements: list[ImpedanceValue]
