"""Cato — Universal AI agent safety layer."""
__version__ = "0.3.7"
