import json
import logging
import threading

from .notification import Notification, NotificationCluster

logger = logging.getLogger(__name__)


class DataManager:
  __slots__ = "tree", "map", "lock", "configs", "dump_path", "last"

  def __init__(self, configs, dump_path):

    self.tree = NotificationCluster()
    self.map = dict()
    self.last = None

    self.lock = threading.Lock()
    self.configs = configs
    self.dump_path = dump_path

    try:
      with open(dump_path, "r") as f:
        for d in json.load(f):
          self.add_notification(Notification(**d))
    except FileNotFoundError:
      logger.info("No dump file found, starting fresh.")
    except json.JSONDecodeError:
      logger.info("Dump file was empty or invalid, starting fresh.")
    except Exception as e:
      logger.error(f"Failed to load dump file: {e}")

  def _recursive_add_notification(cluster, notification, keys, i=0):
    if i == len(keys):
      return

    if keys[i] not in cluster.notifications:
      cluster.notifications[keys[i]] = NotificationCluster()

    DataManager._recursive_add_notification(
      cluster.notifications[keys[i]], notification, keys, i + 1
    )
    cluster.add(keys[i], notification)

  def add_notification(self, notification):
    for config in self.configs:
      if config.should_apply(notification):
        config.update_notification(notification)
        notification.config = config
        break

    keys = notification.keys()

    if notification.id in self.map:
      self.remove_notification(notification.id)

    with self.lock:
      self.last = notification
      self.map[notification.id] = keys
      DataManager._recursive_add_notification(
        self.tree, notification, [*keys, notification.id]
      )

  def _recursive_remove_notification(cluster, keys, i=0):
    key = keys[i]
    best_key = i == len(keys) - 1
    has_key = key in cluster.notifications
    if best_key and not has_key:
      # Short-cutted view, descend
      key = list(cluster.notifications.keys())[0]
      i -= 1

    stop_case = best_key and has_key
    if stop_case:
      cluster_to_delete = cluster.notifications[key]
      best = cluster_to_delete.best
      urgency = cluster.urgency
      nremoved = len(cluster_to_delete)
    else:
      nremoved, best, urgency = DataManager._recursive_remove_notification(
        cluster.notifications[key], keys, i + 1
      )

    if len(cluster.notifications[key]) == 0 or stop_case:
      del cluster.notifications[key]

    cluster._len -= nremoved

    if best is cluster._best:
      cluster._best = None

    if urgency == cluster._urgency:
      cluster._urgency = None

    return nremoved, best, urgency

  def remove_notification(self, id, context=()):
    with self.lock:
      if isinstance(id, int):
        if self.last and id == self.last.id:
          self.last = None

        context = self.map.pop(id)
        notification = self.get_context(context).notifications[id]
        if notification.timer is not None:
          notification.timer.cancel()
      else:
        for leaf in self.get_context(context).notifications[id].leafs():
          if self.last and leaf.id == self.last.id:
            self.last = None
          if leaf.timer is not None:
            leaf.timer.cancel()
          self.map.pop(leaf.id)

      DataManager._recursive_remove_notification(self.tree, [*context, id], i=0)

  def get_context_by_id(self, id):
    return self.get_context(self.map[id])

  def get_context(self, context=(), auto_descend=True):
    p = self.tree

    if context and context[0] not in p.notifications:
      while len(p.notifications) == 1:
        p = next(iter(p.notifications.values()))

    for key in context:
      p = p.notifications[key]

    while auto_descend and len(p.notifications) == 1:
      child = next(iter(p.notifications.values()))

      if isinstance(child, Notification):
        break

      p = child

    return p

  def dump(self):
    try:
      with open(self.dump_path, "w") as f:
        json.dump(
          [notification.to_dict() for notification in self.tree.leafs()],
          f,
          indent=4,
        )
    except Exception as e:
      logger.error(f"Failed to dump notifications: {e}")

  def cancel_timers(self):
    for notification in self.tree.leafs():
      if notification.timer is not None:
        notification.timer.cancel()
