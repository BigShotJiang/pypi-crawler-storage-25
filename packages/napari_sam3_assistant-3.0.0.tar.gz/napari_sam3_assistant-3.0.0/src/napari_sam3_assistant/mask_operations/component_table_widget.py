from __future__ import annotations

from collections.abc import Callable

from qtpy.QtCore import Qt
from qtpy.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QMenu,
    QTableWidget,
    QTableWidgetItem,
)

from .models import ComponentRecord


class NumericTableWidgetItem(QTableWidgetItem):
    def __lt__(self, other) -> bool:
        left = self.data(Qt.UserRole)
        right = other.data(Qt.UserRole)
        if left is not None and right is not None:
            return left < right
        return super().__lt__(other)


class ComponentTableWidget(QTableWidget):
    def __init__(self, delete_callback: Callable[[], None] | None = None) -> None:
        super().__init__(0, 6)
        self._delete_callback = delete_callback
        self.setObjectName("componentAnalysisTable")
        self.setHorizontalHeaderLabels(["Component ID", "Label", "Area", "Centroid Y", "Centroid X", "BBox"])
        self.setAlternatingRowColors(True)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.setSortingEnabled(True)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._open_context_menu)

    def set_records(self, records: list[ComponentRecord]) -> None:
        self.setSortingEnabled(False)
        self.setRowCount(0)
        for record in records:
            row = self.rowCount()
            self.insertRow(row)
            self._set_numeric_item(row, 0, record.component_id)
            self._set_numeric_item(row, 1, record.label_value)
            self._set_numeric_item(row, 2, record.area)
            self._set_float_item(row, 3, record.centroid_y)
            self._set_float_item(row, 4, record.centroid_x)
            self.setItem(row, 5, QTableWidgetItem(record.bbox_text))
        self.setSortingEnabled(True)

    def selected_component_ids(self) -> list[int]:
        ids: list[int] = []
        for index in self.selectionModel().selectedRows():
            item = self.item(index.row(), 0)
            if item is not None:
                ids.append(int(item.data(Qt.UserRole)))
        return ids

    def _set_numeric_item(self, row: int, column: int, value: int) -> None:
        item = NumericTableWidgetItem(str(value))
        item.setData(Qt.UserRole, int(value))
        self.setItem(row, column, item)

    def _set_float_item(self, row: int, column: int, value: float) -> None:
        item = NumericTableWidgetItem(f"{value:.2f}")
        item.setData(Qt.UserRole, float(value))
        self.setItem(row, column, item)

    def _open_context_menu(self, position) -> None:
        if self._delete_callback is None or not self.selected_component_ids():
            return
        menu = QMenu(self)
        action = menu.addAction("Delete Selected Components")
        if menu.exec_(self.viewport().mapToGlobal(position)) == action:
            self._delete_callback()
