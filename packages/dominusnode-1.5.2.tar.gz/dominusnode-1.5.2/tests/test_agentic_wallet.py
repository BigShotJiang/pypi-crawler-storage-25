"""Tests for AgenticWalletResource -- create, list, get, fund, freeze/unfreeze,
delete, update policy, transactions, input validation, and error handling."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from dominusnode.agent_wallet import AgenticWalletResource
from dominusnode.errors import (
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from dominusnode.types import AgenticWallet, AgenticWalletTransaction


class TestAgenticWalletResourceCreate:
    """Tests for AgenticWalletResource.create()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_create_returns_wallet(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.return_value = {
            "id": "aw-001",
            "label": "Scraper Bot",
            "balanceCents": 0,
            "spendingLimitCents": 10000,
            "status": "active",
            "createdAt": "2024-06-01T00:00:00Z",
            "dailyLimitCents": 500,
            "allowedDomains": ["example.com"],
        }

        result = aw.create(
            "Scraper Bot",
            spending_limit_cents=10000,
            daily_limit_cents=500,
            allowed_domains=["example.com"],
        )
        assert isinstance(result, AgenticWallet)
        assert result.id == "aw-001"
        assert result.label == "Scraper Bot"
        assert result.spending_limit_cents == 10000
        assert result.daily_limit_cents == 500
        assert result.allowed_domains == ["example.com"]
        assert result.status == "active"

    def test_create_minimal(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.return_value = {
            "id": "aw-002",
            "label": "Simple Bot",
            "balanceCents": 0,
            "spendingLimitCents": 5000,
            "status": "active",
        }

        result = aw.create("Simple Bot", spending_limit_cents=5000)
        assert result.label == "Simple Bot"
        assert result.daily_limit_cents is None
        assert result.allowed_domains is None
        mock_http.post.assert_called_once_with(
            "/api/agent-wallet",
            json={"label": "Simple Bot", "spendingLimitCents": 5000},
        )

    def test_create_validates_spending_limit_zero(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.create("Bot", spending_limit_cents=0)

    def test_create_validates_spending_limit_negative(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.create("Bot", spending_limit_cents=-100)

    def test_create_validates_spending_limit_overflow(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.create("Bot", spending_limit_cents=2_147_483_648)

    def test_create_validates_daily_limit(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.create("Bot", spending_limit_cents=10000, daily_limit_cents=0)

    def test_create_401_raises(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.side_effect = AuthenticationError("Not authenticated")

        with pytest.raises(AuthenticationError):
            aw.create("Bot", spending_limit_cents=10000)


class TestAgenticWalletResourceList:
    """Tests for AgenticWalletResource.list()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_list_returns_wallets(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.get.return_value = {
            "wallets": [
                {
                    "id": "aw-001",
                    "label": "Bot 1",
                    "balanceCents": 500,
                    "spendingLimitCents": 10000,
                    "status": "active",
                },
                {
                    "id": "aw-002",
                    "label": "Bot 2",
                    "balanceCents": 0,
                    "spendingLimitCents": 5000,
                    "status": "frozen",
                },
            ],
        }

        result = aw.list()
        assert len(result) == 2
        assert isinstance(result[0], AgenticWallet)
        assert result[0].label == "Bot 1"
        assert result[1].status == "frozen"

    def test_list_empty(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.get.return_value = {"wallets": []}

        result = aw.list()
        assert result == []


class TestAgenticWalletResourceGet:
    """Tests for AgenticWalletResource.get()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_get_returns_wallet(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.get.return_value = {
            "id": "aw-001",
            "label": "Scraper Bot",
            "balanceCents": 2000,
            "spendingLimitCents": 10000,
            "status": "active",
            "dailyLimitCents": 500,
            "allowedDomains": ["example.com"],
        }

        result = aw.get("aw-001")
        assert result.id == "aw-001"
        assert result.balance_cents == 2000
        mock_http.get.assert_called_once_with("/api/agent-wallet/aw-001")

    def test_get_url_encodes_id(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.get.return_value = {
            "id": "aw/special",
            "label": "Test",
            "balanceCents": 0,
            "spendingLimitCents": 1000,
            "status": "active",
        }

        aw.get("aw/special")
        mock_http.get.assert_called_once_with("/api/agent-wallet/aw%2Fspecial")

    def test_get_404_raises(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.get.side_effect = NotFoundError("Wallet not found")

        with pytest.raises(NotFoundError, match="Wallet not found"):
            aw.get("aw-nonexistent")


class TestAgenticWalletResourceFund:
    """Tests for AgenticWalletResource.fund()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_fund_returns_transaction(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.return_value = {
            "transaction": {
                "id": "awtx-001",
                "walletId": "aw-001",
                "type": "fund",
                "amountCents": 1000,
                "description": "Fund from main wallet",
                "sessionId": None,
                "createdAt": "2024-06-01T00:00:00Z",
            },
        }

        result = aw.fund("aw-001", 1000)
        assert isinstance(result, AgenticWalletTransaction)
        assert result.amount_cents == 1000
        assert result.type == "fund"
        assert result.wallet_id == "aw-001"

    def test_fund_zero_raises(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.fund("aw-001", 0)

    def test_fund_negative_raises(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.fund("aw-001", -500)

    def test_fund_overflow_raises(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.fund("aw-001", 2_147_483_648)


class TestAgenticWalletResourceTransactions:
    """Tests for AgenticWalletResource.transactions()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_transactions_returns_list(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.get.return_value = {
            "transactions": [
                {
                    "id": "awtx-001",
                    "walletId": "aw-001",
                    "type": "fund",
                    "amountCents": 1000,
                    "description": "Fund",
                    "createdAt": "2024-06-01",
                },
                {
                    "id": "awtx-002",
                    "walletId": "aw-001",
                    "type": "debit",
                    "amountCents": -50,
                    "description": "Usage",
                    "sessionId": "sess-abc",
                    "createdAt": "2024-06-02",
                },
            ],
        }

        result = aw.transactions("aw-001")
        assert len(result) == 2
        assert isinstance(result[0], AgenticWalletTransaction)
        assert result[0].type == "fund"
        assert result[1].session_id == "sess-abc"

    def test_transactions_empty(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.get.return_value = {"transactions": []}

        result = aw.transactions("aw-001")
        assert result == []


class TestAgenticWalletResourceFreezeUnfreeze:
    """Tests for AgenticWalletResource.freeze() and unfreeze()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_freeze_returns_frozen_wallet(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.return_value = {
            "id": "aw-001",
            "label": "Bot",
            "balanceCents": 500,
            "spendingLimitCents": 10000,
            "status": "frozen",
        }

        result = aw.freeze("aw-001")
        assert result.status == "frozen"
        mock_http.post.assert_called_once_with("/api/agent-wallet/aw-001/freeze", json={})

    def test_unfreeze_returns_active_wallet(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.return_value = {
            "id": "aw-001",
            "label": "Bot",
            "balanceCents": 500,
            "spendingLimitCents": 10000,
            "status": "active",
        }

        result = aw.unfreeze("aw-001")
        assert result.status == "active"
        mock_http.post.assert_called_once_with("/api/agent-wallet/aw-001/unfreeze", json={})

    def test_freeze_404_raises(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.side_effect = NotFoundError("Wallet not found")

        with pytest.raises(NotFoundError):
            aw.freeze("aw-nonexistent")

    def test_unfreeze_403_raises(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.post.side_effect = AuthorizationError("Cannot unfreeze")

        with pytest.raises(AuthorizationError):
            aw.unfreeze("aw-001")


class TestAgenticWalletResourceDelete:
    """Tests for AgenticWalletResource.delete()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_delete_returns_refunded_cents(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.delete.return_value = {"refundedCents": 450}

        result = aw.delete("aw-001")
        assert result == 450
        mock_http.delete.assert_called_once_with("/api/agent-wallet/aw-001")

    def test_delete_zero_refund(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.delete.return_value = {"refundedCents": 0}

        result = aw.delete("aw-empty")
        assert result == 0

    def test_delete_404_raises(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.delete.side_effect = NotFoundError("Wallet not found")

        with pytest.raises(NotFoundError):
            aw.delete("aw-nonexistent")


class TestAgenticWalletResourceUpdatePolicy:
    """Tests for AgenticWalletResource.update_wallet_policy()."""

    def _make_aw(self) -> tuple[AgenticWalletResource, MagicMock]:
        mock_http = MagicMock()
        aw = AgenticWalletResource(mock_http)
        return aw, mock_http

    def test_update_policy_daily_limit(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.patch.return_value = {
            "id": "aw-001",
            "label": "Bot",
            "balanceCents": 500,
            "spendingLimitCents": 10000,
            "status": "active",
            "dailyLimitCents": 1000,
        }

        result = aw.update_wallet_policy("aw-001", daily_limit_cents=1000)
        assert result.daily_limit_cents == 1000

    def test_update_policy_allowed_domains(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.patch.return_value = {
            "id": "aw-001",
            "label": "Bot",
            "balanceCents": 500,
            "spendingLimitCents": 10000,
            "status": "active",
            "allowedDomains": ["api.example.com", "data.example.com"],
        }

        result = aw.update_wallet_policy(
            "aw-001",
            allowed_domains=["api.example.com", "data.example.com"],
        )
        assert result.allowed_domains == ["api.example.com", "data.example.com"]

    def test_update_policy_validates_daily_limit(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.update_wallet_policy("aw-001", daily_limit_cents=0)

    def test_update_policy_validates_daily_limit_overflow(self) -> None:
        aw, mock_http = self._make_aw()
        with pytest.raises(ValueError, match="positive integer"):
            aw.update_wallet_policy("aw-001", daily_limit_cents=2_147_483_648)

    def test_update_policy_url_encodes_id(self) -> None:
        aw, mock_http = self._make_aw()
        mock_http.patch.return_value = {
            "id": "aw/special",
            "label": "Bot",
            "balanceCents": 0,
            "spendingLimitCents": 1000,
            "status": "active",
        }

        aw.update_wallet_policy("aw/special", allowed_domains=["test.com"])
        mock_http.patch.assert_called_once_with(
            "/api/agent-wallet/aw%2Fspecial/policy",
            json={"allowedDomains": ["test.com"]},
        )
