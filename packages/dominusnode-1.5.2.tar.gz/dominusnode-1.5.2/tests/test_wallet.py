"""Tests for WalletResource -- balance, transactions, top-ups (Stripe, crypto, PayPal),
forecast, input validation, and error handling."""

from __future__ import annotations

import math
from unittest.mock import MagicMock

import pytest

from dominusnode.errors import (
    AuthenticationError,
    InsufficientBalanceError,
    ServerError,
    ValidationError,
)
from dominusnode.wallet import WalletResource, _validate_amount_cents
from dominusnode.types import (
    CryptoInvoice,
    PaypalOrder,
    StripeCheckout,
    Wallet,
    WalletForecast,
    WalletTransaction,
)


class TestValidateAmountCents:
    """Tests for the _validate_amount_cents helper."""

    def test_valid_amount(self) -> None:
        _validate_amount_cents(100, "amount")  # Should not raise

    def test_valid_max_amount(self) -> None:
        _validate_amount_cents(2_147_483_647, "amount")  # Should not raise

    def test_zero_amount_raises(self) -> None:
        with pytest.raises(ValueError, match="positive integer"):
            _validate_amount_cents(0, "amount")

    def test_negative_amount_raises(self) -> None:
        with pytest.raises(ValueError, match="positive integer"):
            _validate_amount_cents(-100, "amount")

    def test_overflow_amount_raises(self) -> None:
        with pytest.raises(ValueError, match="positive integer"):
            _validate_amount_cents(2_147_483_648, "amount")

    def test_float_amount_raises(self) -> None:
        with pytest.raises(ValueError):
            _validate_amount_cents(10.5, "amount")  # type: ignore

    def test_string_amount_raises(self) -> None:
        with pytest.raises(ValueError):
            _validate_amount_cents("100", "amount")  # type: ignore

    def test_one_cent_valid(self) -> None:
        _validate_amount_cents(1, "amount")  # Should not raise


class TestWalletResourceBalance:
    """Tests for WalletResource.get_balance()."""

    def _make_wallet(self) -> tuple[WalletResource, MagicMock]:
        mock_http = MagicMock()
        wallet = WalletResource(mock_http)
        return wallet, mock_http

    def test_get_balance_returns_wallet(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {
            "balanceCents": 5000,
            "balanceUsd": 50.0,
            "currency": "usd",
            "lastToppedUp": "2024-06-01T12:00:00Z",
        }

        result = wallet.get_balance()
        assert isinstance(result, Wallet)
        assert result.balance_cents == 5000
        assert result.balance_usd == 50.0
        assert result.currency == "usd"
        assert result.last_topped_up == "2024-06-01T12:00:00Z"
        mock_http.get.assert_called_once_with("/api/wallet")

    def test_get_balance_without_last_topped_up(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {
            "balanceCents": 0,
            "balanceUsd": 0.0,
            "currency": "usd",
        }

        result = wallet.get_balance()
        assert result.balance_cents == 0
        assert result.last_topped_up is None

    def test_get_balance_401_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.side_effect = AuthenticationError("Not authenticated")

        with pytest.raises(AuthenticationError):
            wallet.get_balance()

    def test_get_balance_500_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.side_effect = ServerError("Database error")

        with pytest.raises(ServerError):
            wallet.get_balance()


class TestWalletResourceTransactions:
    """Tests for WalletResource.get_transactions()."""

    def _make_wallet(self) -> tuple[WalletResource, MagicMock]:
        mock_http = MagicMock()
        wallet = WalletResource(mock_http)
        return wallet, mock_http

    def test_get_transactions_returns_list(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {
            "transactions": [
                {
                    "id": "tx-1",
                    "type": "topup",
                    "amountCents": 1000,
                    "amountUsd": 10.0,
                    "description": "Stripe top-up",
                    "paymentProvider": "stripe",
                    "createdAt": "2024-06-01T12:00:00Z",
                },
                {
                    "id": "tx-2",
                    "type": "debit",
                    "amountCents": -50,
                    "amountUsd": -0.5,
                    "description": "Usage charge",
                    "createdAt": "2024-06-02T10:00:00Z",
                },
            ],
        }

        result = wallet.get_transactions(limit=10, offset=0)
        assert len(result) == 2
        assert isinstance(result[0], WalletTransaction)
        assert result[0].id == "tx-1"
        assert result[0].type == "topup"
        assert result[0].amount_cents == 1000
        assert result[0].payment_provider == "stripe"
        assert result[1].type == "debit"
        assert result[1].payment_provider is None

        mock_http.get.assert_called_once_with(
            "/api/wallet/transactions",
            params={"limit": 10, "offset": 0},
        )

    def test_get_transactions_empty_list(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {"transactions": []}

        result = wallet.get_transactions()
        assert result == []

    def test_get_transactions_default_params(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {"transactions": []}

        wallet.get_transactions()
        mock_http.get.assert_called_once_with(
            "/api/wallet/transactions",
            params={"limit": 50, "offset": 0},
        )


class TestWalletResourceStripeTopUp:
    """Tests for WalletResource.top_up_stripe()."""

    def _make_wallet(self) -> tuple[WalletResource, MagicMock]:
        mock_http = MagicMock()
        wallet = WalletResource(mock_http)
        return wallet, mock_http

    def test_top_up_stripe_returns_checkout(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.post.return_value = {
            "sessionId": "cs_test_abc123",
            "url": "https://checkout.stripe.com/pay/cs_test_abc123",
        }

        result = wallet.top_up_stripe(2000)
        assert isinstance(result, StripeCheckout)
        assert result.session_id == "cs_test_abc123"
        assert "stripe.com" in result.url
        mock_http.post.assert_called_once_with(
            "/api/wallet/topup/stripe",
            json={"amountCents": 2000},
        )

    def test_top_up_stripe_zero_cents_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="positive integer"):
            wallet.top_up_stripe(0)

    def test_top_up_stripe_negative_cents_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="positive integer"):
            wallet.top_up_stripe(-500)

    def test_top_up_stripe_overflow_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="positive integer"):
            wallet.top_up_stripe(2_147_483_648)

    def test_top_up_stripe_max_valid(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.post.return_value = {
            "sessionId": "cs_max",
            "url": "https://checkout.stripe.com/cs_max",
        }
        result = wallet.top_up_stripe(2_147_483_647)
        assert result.session_id == "cs_max"


class TestWalletResourceCryptoTopUp:
    """Tests for WalletResource.top_up_crypto()."""

    def _make_wallet(self) -> tuple[WalletResource, MagicMock]:
        mock_http = MagicMock()
        wallet = WalletResource(mock_http)
        return wallet, mock_http

    def test_top_up_crypto_returns_invoice(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.post.return_value = {
            "invoiceId": "inv-btc-123",
            "invoiceUrl": "https://nowpayments.io/payment/inv-btc-123",
            "payCurrency": "btc",
            "priceAmount": 0.00025,
        }

        result = wallet.top_up_crypto(10.0, "btc")
        assert isinstance(result, CryptoInvoice)
        assert result.invoice_id == "inv-btc-123"
        assert result.pay_currency == "btc"
        assert result.price_amount == 0.00025
        mock_http.post.assert_called_once_with(
            "/api/wallet/topup/crypto",
            json={"amountUsd": 10.0, "currency": "btc"},
        )

    def test_top_up_crypto_minimum_10_usd(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="Minimum crypto top-up"):
            wallet.top_up_crypto(9.99, "btc")

    def test_top_up_crypto_nan_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="finite number"):
            wallet.top_up_crypto(float("nan"), "btc")

    def test_top_up_crypto_infinity_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="finite number"):
            wallet.top_up_crypto(float("inf"), "eth")

    def test_top_up_crypto_negative_infinity_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="finite number"):
            wallet.top_up_crypto(float("-inf"), "xmr")

    def test_top_up_crypto_string_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError):
            wallet.top_up_crypto("not a number", "btc")  # type: ignore


class TestWalletResourcePaypalTopUp:
    """Tests for WalletResource.top_up_paypal()."""

    def _make_wallet(self) -> tuple[WalletResource, MagicMock]:
        mock_http = MagicMock()
        wallet = WalletResource(mock_http)
        return wallet, mock_http

    def test_top_up_paypal_returns_order(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.post.return_value = {
            "orderId": "pp-order-123",
            "approvalUrl": "https://paypal.com/checkoutnow?token=pp-order-123",
            "amountCents": 1000,
        }

        result = wallet.top_up_paypal(1000)
        assert isinstance(result, PaypalOrder)
        assert result.order_id == "pp-order-123"
        assert "paypal.com" in result.approval_url
        assert result.amount_cents == 1000

    def test_top_up_paypal_minimum_500_cents(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="Minimum PayPal top-up"):
            wallet.top_up_paypal(499)

    def test_top_up_paypal_exactly_500_cents(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.post.return_value = {
            "orderId": "pp-min",
            "approvalUrl": "https://paypal.com/min",
            "amountCents": 500,
        }
        result = wallet.top_up_paypal(500)
        assert result.amount_cents == 500

    def test_top_up_paypal_zero_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        with pytest.raises(ValueError, match="positive integer"):
            wallet.top_up_paypal(0)


class TestWalletResourceForecast:
    """Tests for WalletResource.get_forecast()."""

    def _make_wallet(self) -> tuple[WalletResource, MagicMock]:
        mock_http = MagicMock()
        wallet = WalletResource(mock_http)
        return wallet, mock_http

    def test_get_forecast(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {
            "dailyAvgCents": 150,
            "daysRemaining": 33.3,
            "trend": "stable",
            "trendPct": 2,
        }

        result = wallet.get_forecast()
        assert isinstance(result, WalletForecast)
        assert result.daily_avg_cents == 150
        assert result.days_remaining == 33.3
        assert result.trend == "stable"
        assert result.trend_pct == 2

    def test_get_forecast_no_days_remaining(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {
            "dailyAvgCents": 0,
            "daysRemaining": None,
            "trend": "stable",
            "trendPct": 0,
        }

        result = wallet.get_forecast()
        assert result.days_remaining is None

    def test_get_forecast_downward_trend(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.return_value = {
            "dailyAvgCents": 300,
            "daysRemaining": 16.7,
            "trend": "down",
            "trendPct": -15,
        }

        result = wallet.get_forecast()
        assert result.trend == "down"
        assert result.trend_pct == -15

    def test_get_forecast_402_raises(self) -> None:
        wallet, mock_http = self._make_wallet()
        mock_http.get.side_effect = InsufficientBalanceError("No balance")

        with pytest.raises(InsufficientBalanceError):
            wallet.get_forecast()
