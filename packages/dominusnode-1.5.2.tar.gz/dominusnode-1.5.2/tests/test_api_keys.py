"""Tests for KeysResource -- create, list, revoke, and error handling."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from dominusnode.errors import (
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from dominusnode.keys import KeysResource
from dominusnode.types import ApiKey, CreatedApiKey


class TestKeysResourceCreate:
    """Tests for KeysResource.create()."""

    def _make_keys(self) -> tuple[KeysResource, MagicMock]:
        mock_http = MagicMock()
        keys = KeysResource(mock_http)
        return keys, mock_http

    def test_create_returns_created_api_key(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.post.return_value = {
            "key": "dn_live_abc123def456",
            "id": "k-1",
            "prefix": "dn_live_abc1",
            "label": "My Production Key",
            "created_at": "2024-06-01T12:00:00Z",
        }

        result = keys.create("My Production Key")
        assert isinstance(result, CreatedApiKey)
        assert result.key == "dn_live_abc123def456"
        assert result.id == "k-1"
        assert result.prefix == "dn_live_abc1"
        assert result.label == "My Production Key"
        assert result.created_at == "2024-06-01T12:00:00Z"
        mock_http.post.assert_called_once_with(
            "/api/keys",
            json={"label": "My Production Key"},
        )

    def test_create_uses_default_label(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.post.return_value = {
            "key": "dn_live_xyz",
            "id": "k-2",
            "prefix": "dn_live_xyz",
            "label": "Default",
            "created_at": "2024-06-01T12:00:00Z",
        }

        result = keys.create()
        assert result.label == "Default"
        mock_http.post.assert_called_once_with(
            "/api/keys",
            json={"label": "Default"},
        )

    def test_create_401_raises_authentication_error(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.post.side_effect = AuthenticationError("Not authenticated")

        with pytest.raises(AuthenticationError):
            keys.create("Test Key")

    def test_create_403_raises_authorization_error(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.post.side_effect = AuthorizationError("Email not verified")

        with pytest.raises(AuthorizationError, match="Email not verified"):
            keys.create("Test Key")

    def test_create_500_raises_server_error(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.post.side_effect = ServerError("Database error")

        with pytest.raises(ServerError):
            keys.create("Test Key")


class TestKeysResourceList:
    """Tests for KeysResource.list()."""

    def _make_keys(self) -> tuple[KeysResource, MagicMock]:
        mock_http = MagicMock()
        keys = KeysResource(mock_http)
        return keys, mock_http

    def test_list_returns_api_keys(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.get.return_value = {
            "keys": [
                {
                    "id": "k-1",
                    "prefix": "dn_live_abc1",
                    "label": "Production",
                    "created_at": "2024-06-01T12:00:00Z",
                    "revoked_at": None,
                },
                {
                    "id": "k-2",
                    "prefix": "dn_live_xyz",
                    "label": "Staging",
                    "created_at": "2024-05-01T10:00:00Z",
                    "revoked_at": "2024-05-15T14:00:00Z",
                },
            ],
        }

        result = keys.list()
        assert len(result) == 2
        assert isinstance(result[0], ApiKey)
        assert result[0].id == "k-1"
        assert result[0].label == "Production"
        assert result[0].revoked_at is None
        assert result[1].revoked_at is not None

    def test_list_returns_empty_list(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.get.return_value = {"keys": []}

        result = keys.list()
        assert result == []

    def test_list_single_key(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.get.return_value = {
            "keys": [
                {
                    "id": "k-only",
                    "prefix": "dn_live_only",
                    "label": "Only Key",
                    "created_at": "2024-01-01T00:00:00Z",
                },
            ],
        }

        result = keys.list()
        assert len(result) == 1
        assert result[0].revoked_at is None  # Missing revoked_at defaults to None

    def test_list_401_raises_authentication_error(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.get.side_effect = AuthenticationError("Token expired")

        with pytest.raises(AuthenticationError):
            keys.list()


class TestKeysResourceRevoke:
    """Tests for KeysResource.revoke()."""

    def _make_keys(self) -> tuple[KeysResource, MagicMock]:
        mock_http = MagicMock()
        keys = KeysResource(mock_http)
        return keys, mock_http

    def test_revoke_calls_delete_endpoint(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.delete.return_value = None

        keys.revoke("k-1")
        mock_http.delete.assert_called_once_with("/api/keys/k-1")

    def test_revoke_url_encodes_key_id(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.delete.return_value = None

        keys.revoke("key/with/slashes")
        mock_http.delete.assert_called_once_with("/api/keys/key%2Fwith%2Fslashes")

    def test_revoke_404_raises_not_found(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.delete.side_effect = NotFoundError("Key not found")

        with pytest.raises(NotFoundError, match="Key not found"):
            keys.revoke("k-nonexistent")

    def test_revoke_403_raises_authorization_error(self) -> None:
        keys, mock_http = self._make_keys()
        mock_http.delete.side_effect = AuthorizationError("Cannot revoke another user's key")

        with pytest.raises(AuthorizationError):
            keys.revoke("k-other-user")


class TestCreatedApiKeyRedaction:
    """Verify credential scrubbing in API key representations."""

    def test_repr_redacts_raw_key(self) -> None:
        key = CreatedApiKey(
            key="dn_live_super_secret_key_value",
            id="k-1",
            prefix="dn_live_supe",
            label="Test",
            created_at="2024-01-01",
        )
        repr_str = repr(key)
        assert "dn_live_super_secret_key_value" not in repr_str
        assert "[REDACTED]" in repr_str
        # But ID and prefix should still be visible
        assert "k-1" in repr_str
        assert "dn_live_supe" in repr_str

    def test_key_not_in_str(self) -> None:
        key = CreatedApiKey(
            key="dn_live_abc123",
            id="k-1",
            prefix="dn_live_abc1",
            label="Test",
            created_at="2024-01-01",
        )
        # str() should also use __repr__ for frozen dataclass
        str_output = repr(key)
        assert "dn_live_abc123" not in str_output
