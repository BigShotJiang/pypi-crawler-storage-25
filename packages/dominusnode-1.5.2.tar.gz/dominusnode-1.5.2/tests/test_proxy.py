"""Tests for proxy URL building, ProxyResource methods (health, status, config),
and error handling."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from dominusnode import ProxyError, ProxyUrlOptions
from dominusnode.errors import AuthenticationError, ServerError
from dominusnode.proxy import ProxyResource, build_proxy_url
from dominusnode.types import ProxyConfig, ProxyHealth, ProxyStatus


class TestBuildProxyUrl:
    """Tests for the build_proxy_url function."""

    def test_basic_http_url(self) -> None:
        url = build_proxy_url(
            "dn_live_abc123",
            proxy_host="proxy.dominusnode.com",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
        )
        assert url == "http://user:dn_live_abc123@proxy.dominusnode.com:8080"

    def test_socks5_url(self) -> None:
        url = build_proxy_url(
            "dn_live_abc123",
            proxy_host="proxy.dominusnode.com",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(protocol="socks5"),
        )
        assert url == "socks5://user:dn_live_abc123@proxy.dominusnode.com:1080"

    def test_with_country(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(country="us"),
        )
        assert url == "http://user-country-US:dn_live_key@proxy.test.io:8080"

    def test_with_country_and_state(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(country="us", state="CA"),
        )
        assert url == "http://user-country-US-state-CA:dn_live_key@proxy.test.io:8080"

    def test_with_country_state_city(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(country="us", state="CA", city="Los Angeles"),
        )
        assert url == "http://user-country-US-state-CA-city-Los%20Angeles:dn_live_key@proxy.test.io:8080"

    def test_with_asn(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(asn=13335),
        )
        assert "asn-13335" in url

    def test_with_session_id(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(session_id="sess-12345"),
        )
        assert url == "http://user-session-sess-12345:dn_live_key@proxy.test.io:8080"

    def test_with_all_options(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(
                country="gb",
                state="London",
                city="Camden",
                asn=9009,
                session_id="sticky-1",
                protocol="http",
            ),
        )
        assert "country-GB" in url
        assert "state-London" in url
        assert "city-Camden" in url
        assert "asn-9009" in url
        assert "session-sticky-1" in url
        assert url.startswith("http://")
        assert url.endswith("@proxy.test.io:8080")

    def test_with_socks5_and_country(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(country="de", protocol="socks5"),
        )
        assert url.startswith("socks5://")
        assert url.endswith("@proxy.test.io:1080")
        assert "country-DE" in url

    def test_special_characters_in_key_are_encoded(self) -> None:
        url = build_proxy_url(
            "dn_live_key+with/special=chars",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
        )
        assert "dn_live_key%2Bwith%2Fspecial%3Dchars" in url

    def test_empty_api_key_raises(self) -> None:
        with pytest.raises(ProxyError, match="API key is required"):
            build_proxy_url(
                "",
                proxy_host="proxy.test.io",
                http_proxy_port=8080,
                socks5_proxy_port=1080,
            )

    def test_none_api_key_raises(self) -> None:
        with pytest.raises((ProxyError, TypeError)):
            build_proxy_url(
                None,  # type: ignore
                proxy_host="proxy.test.io",
                http_proxy_port=8080,
                socks5_proxy_port=1080,
            )

    def test_custom_ports(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="localhost",
            http_proxy_port=9999,
            socks5_proxy_port=7777,
        )
        assert url == "http://user:dn_live_key@localhost:9999"

        url_socks = build_proxy_url(
            "dn_live_key",
            proxy_host="localhost",
            http_proxy_port=9999,
            socks5_proxy_port=7777,
            options=ProxyUrlOptions(protocol="socks5"),
        )
        assert url_socks == "socks5://user:dn_live_key@localhost:7777"

    def test_none_options_uses_defaults(self) -> None:
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=None,
        )
        assert url == "http://user:dn_live_key@proxy.test.io:8080"

    def test_invalid_proxy_host_with_space_raises(self) -> None:
        with pytest.raises(ValueError, match="invalid characters"):
            build_proxy_url(
                "dn_live_key",
                proxy_host="proxy host.com",
                http_proxy_port=8080,
                socks5_proxy_port=1080,
            )

    def test_invalid_proxy_host_with_slash_raises(self) -> None:
        with pytest.raises(ValueError, match="invalid characters"):
            build_proxy_url(
                "dn_live_key",
                proxy_host="proxy/host",
                http_proxy_port=8080,
                socks5_proxy_port=1080,
            )

    def test_invalid_proxy_host_with_at_raises(self) -> None:
        with pytest.raises(ValueError, match="invalid characters"):
            build_proxy_url(
                "dn_live_key",
                proxy_host="user@host",
                http_proxy_port=8080,
                socks5_proxy_port=1080,
            )

    def test_country_uppercased(self) -> None:
        """Country codes should always be uppercased."""
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(country="jp"),
        )
        assert "country-JP" in url

    def test_session_id_url_encoded(self) -> None:
        """Session IDs with special chars should be URL-encoded."""
        url = build_proxy_url(
            "dn_live_key",
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            options=ProxyUrlOptions(session_id="sess/with spaces"),
        )
        assert "sess%2Fwith%20spaces" in url


class TestProxyUrlOptionsCombinations:
    """Test various ProxyUrlOptions combinations."""

    def test_only_session(self) -> None:
        opts = ProxyUrlOptions(session_id="abc")
        assert opts.country is None
        assert opts.state is None
        assert opts.city is None
        assert opts.session_id == "abc"
        assert opts.protocol == "http"

    def test_defaults(self) -> None:
        opts = ProxyUrlOptions()
        assert opts.country is None
        assert opts.protocol == "http"
        assert opts.asn is None
        assert opts.session_id is None

    def test_frozen(self) -> None:
        opts = ProxyUrlOptions(country="US")
        with pytest.raises(AttributeError):
            opts.country = "DE"  # type: ignore


class TestProxyResourceBuildUrl:
    """Tests for ProxyResource.build_url()."""

    def _make_proxy(self, api_key: str | None = "dn_live_key") -> tuple[ProxyResource, MagicMock]:
        mock_http = MagicMock()
        proxy = ProxyResource(
            mock_http,
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            get_api_key=lambda: api_key,
        )
        return proxy, mock_http

    def test_build_url_uses_stored_key(self) -> None:
        proxy, _ = self._make_proxy("dn_live_test_key")
        url = proxy.build_url()
        assert "dn_live_test_key" in url

    def test_build_url_without_key_raises(self) -> None:
        proxy, _ = self._make_proxy(None)
        with pytest.raises(ProxyError, match="No API key set"):
            proxy.build_url()

    def test_build_url_with_options(self) -> None:
        proxy, _ = self._make_proxy("dn_live_key")
        url = proxy.build_url(ProxyUrlOptions(country="US", protocol="socks5"))
        assert "country-US" in url
        assert url.startswith("socks5://")


class TestProxyResourceGetHealth:
    """Tests for ProxyResource.get_health()."""

    def _make_proxy(self) -> tuple[ProxyResource, MagicMock]:
        mock_http = MagicMock()
        proxy = ProxyResource(
            mock_http,
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            get_api_key=lambda: "dn_live_key",
        )
        return proxy, mock_http

    def test_get_health_returns_health(self) -> None:
        proxy, mock_http = self._make_proxy()
        mock_http.get.return_value = {
            "status": "healthy",
            "activeSessions": 42,
            "uptimeSeconds": 86400,
        }

        result = proxy.get_health()
        assert isinstance(result, ProxyHealth)
        assert result.status == "healthy"
        assert result.active_sessions == 42
        assert result.uptime_seconds == 86400

    def test_get_health_defaults(self) -> None:
        proxy, mock_http = self._make_proxy()
        mock_http.get.return_value = {}

        result = proxy.get_health()
        assert result.status == "unknown"
        assert result.active_sessions == 0
        assert result.uptime_seconds == 0


class TestProxyResourceGetStatus:
    """Tests for ProxyResource.get_status()."""

    def _make_proxy(self) -> tuple[ProxyResource, MagicMock]:
        mock_http = MagicMock()
        proxy = ProxyResource(
            mock_http,
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            get_api_key=lambda: "dn_live_key",
        )
        return proxy, mock_http

    def test_get_status_returns_full_status(self) -> None:
        proxy, mock_http = self._make_proxy()
        mock_http.get.return_value = {
            "status": "healthy",
            "activeSessions": 100,
            "userActiveSessions": 3,
            "avgLatencyMs": 45.2,
            "providers": [
                {
                    "name": "webshare-dc",
                    "state": "active",
                    "consecutiveFailures": 0,
                    "totalRequests": 50000,
                    "totalErrors": 12,
                    "avgLatencyMs": 35.0,
                    "fallbackOnly": False,
                },
            ],
            "endpoints": {
                "http": "http://proxy.test.io:8080",
                "socks5": "socks5://proxy.test.io:1080",
            },
            "supportedCountries": ["US", "GB", "DE"],
            "uptimeSeconds": 172800,
        }

        result = proxy.get_status()
        assert isinstance(result, ProxyStatus)
        assert result.status == "healthy"
        assert result.active_sessions == 100
        assert result.user_active_sessions == 3
        assert result.avg_latency_ms == 45.2
        assert len(result.providers) == 1
        assert result.providers[0].name == "webshare-dc"
        assert result.providers[0].fallback_only is False
        assert result.endpoints.http == "http://proxy.test.io:8080"
        assert len(result.supported_countries) == 3

    def test_get_status_401_raises(self) -> None:
        proxy, mock_http = self._make_proxy()
        mock_http.get.side_effect = AuthenticationError("Unauthorized")

        with pytest.raises(AuthenticationError):
            proxy.get_status()


class TestProxyResourceGetConfig:
    """Tests for ProxyResource.get_config()."""

    def _make_proxy(self) -> tuple[ProxyResource, MagicMock]:
        mock_http = MagicMock()
        proxy = ProxyResource(
            mock_http,
            proxy_host="proxy.test.io",
            http_proxy_port=8080,
            socks5_proxy_port=1080,
            get_api_key=lambda: "dn_live_key",
        )
        return proxy, mock_http

    def test_get_config_returns_full_config(self) -> None:
        proxy, mock_http = self._make_proxy()
        mock_http.get.return_value = {
            "httpProxy": {"host": "proxy.test.io", "port": 8080},
            "socks5Proxy": {"host": "proxy.test.io", "port": 1080},
            "supportedCountries": ["US", "GB"],
            "blockedCountries": ["CU", "IR", "KP", "RU", "SY"],
            "maxRotationIntervalMinutes": 60,
            "minRotationIntervalMinutes": 1,
            "geoTargeting": {
                "stateSupport": True,
                "citySupport": True,
                "asnSupport": True,
                "usStates": [{"code": "CA", "name": "California"}],
                "majorUsCities": [{"name": "Los Angeles", "state": "CA"}],
            },
        }

        result = proxy.get_config()
        assert isinstance(result, ProxyConfig)
        assert result.http_proxy.host == "proxy.test.io"
        assert result.http_proxy.port == 8080
        assert result.socks5_proxy.port == 1080
        assert "CU" in result.blocked_countries
        assert result.geo_targeting.state_support is True
        assert result.geo_targeting.asn_support is True

    def test_get_config_defaults_for_missing_fields(self) -> None:
        proxy, mock_http = self._make_proxy()
        mock_http.get.return_value = {}

        result = proxy.get_config()
        assert result.http_proxy.port == 8080
        assert result.socks5_proxy.port == 1080
        assert result.supported_countries == []
        assert result.blocked_countries == []
        assert result.geo_targeting.state_support is False
