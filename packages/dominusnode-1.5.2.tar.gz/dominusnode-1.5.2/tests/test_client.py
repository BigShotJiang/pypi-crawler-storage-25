"""Tests for DominusNodeClient and AsyncDominusNodeClient initialization, connection,
disconnect, context management, error handling, and credential scrubbing."""

from __future__ import annotations

import time

import pytest
import httpx
import respx

from dominusnode import (
    AsyncDominusNodeClient,
    DominusNodeClient,
    AuthenticationError,
)
from dominusnode.auth import AuthResource, AsyncAuthResource
from dominusnode.keys import KeysResource, AsyncKeysResource
from dominusnode.wallet import WalletResource, AsyncWalletResource
from dominusnode.usage import UsageResource, AsyncUsageResource
from dominusnode.plans import PlansResource, AsyncPlansResource
from dominusnode.sessions import SessionsResource, AsyncSessionsResource
from dominusnode.proxy import ProxyResource, AsyncProxyResource
from dominusnode.admin import AdminResource, AsyncAdminResource
from dominusnode.agent_wallet import AgenticWalletResource, AsyncAgenticWalletResource
from dominusnode.teams import TeamsResource, AsyncTeamsResource
from dominusnode.constants import DEFAULT_BASE_URL, DEFAULT_PROXY_HOST
from tests.conftest import make_jwt


class TestDominusNodeClientInit:
    """Test sync client initialization modes."""

    def test_default_initialization(self) -> None:
        client = DominusNodeClient()
        try:
            assert client.auth is not None
            assert isinstance(client.auth, AuthResource)
            assert isinstance(client.keys, KeysResource)
            assert isinstance(client.wallet, WalletResource)
            assert isinstance(client.usage, UsageResource)
            assert isinstance(client.plans, PlansResource)
            assert isinstance(client.sessions, SessionsResource)
            assert isinstance(client.proxy, ProxyResource)
            assert isinstance(client.admin, AdminResource)
        finally:
            client.close()

    def test_custom_base_url(self) -> None:
        client = DominusNodeClient(base_url="http://localhost:3000")
        try:
            assert client.auth is not None
        finally:
            client.close()

    def test_custom_proxy_settings(self) -> None:
        client = DominusNodeClient(
            proxy_host="myproxy.local",
            http_proxy_port=9090,
            socks5_proxy_port=1081,
        )
        try:
            assert client._proxy_host == "myproxy.local"
            assert client._http_proxy_port == 9090
            assert client._socks5_proxy_port == 1081
        finally:
            client.close()

    def test_pre_existing_tokens(self) -> None:
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)
        client = DominusNodeClient(
            access_token=access,
            refresh_token=refresh,
        )
        try:
            assert client._token_manager.has_tokens is True
            assert client._token_manager.access_token == access
        finally:
            client.close()

    def test_pre_existing_tokens_require_both(self) -> None:
        """Only access_token without refresh_token should NOT set tokens."""
        access = make_jwt()
        client = DominusNodeClient(access_token=access)
        try:
            # Both must be provided for tokens to be set
            assert client._token_manager.has_tokens is False
        finally:
            client.close()

    def test_context_manager(self) -> None:
        with DominusNodeClient() as client:
            assert client.auth is not None

    def test_resource_properties_exist(self) -> None:
        """Verify all resource properties are accessible."""
        with DominusNodeClient() as client:
            assert isinstance(client.agentic_wallets, AgenticWalletResource)
            assert isinstance(client.teams, TeamsResource)
            assert client.x402 is not None
            assert client.wallet_auth is not None
            assert client.mpp is not None
            assert client.slots is not None

    def test_custom_timeout(self) -> None:
        """Client should accept custom timeout."""
        client = DominusNodeClient(timeout=60.0)
        try:
            assert client._http is not None
        finally:
            client.close()

    def test_agent_secret_passed_to_http_client(self) -> None:
        """Agent secret should be forwarded to the HTTP client."""
        client = DominusNodeClient(agent_secret="das_test_secret_123")
        try:
            assert client._http._agent_secret == "das_test_secret_123"
        finally:
            client.close()

    @respx.mock
    def test_connect_with_key(self) -> None:
        """Test that connect_with_key calls verify-key endpoint."""
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/verify-key").mock(
            return_value=httpx.Response(
                200,
                json={
                    "valid": True,
                    "token": access,
                    "refreshToken": refresh,
                    "userId": "u-123",
                    "email": "test@example.com",
                },
            )
        )

        with DominusNodeClient(base_url="http://localhost:3000") as client:
            result = client.connect_with_key("dn_live_test_key_123")
            assert result.token == access
            assert result.refresh_token == refresh
            assert result.user is not None
            assert result.user.id == "u-123"
            assert client._api_key == "dn_live_test_key_123"

    @respx.mock
    def test_connect_with_credentials(self) -> None:
        """Test that connect_with_credentials calls login endpoint."""
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/login").mock(
            return_value=httpx.Response(
                200,
                json={
                    "token": access,
                    "refreshToken": refresh,
                    "user": {
                        "id": "u-456",
                        "email": "user@example.com",
                        "created_at": "2024-01-01T00:00:00Z",
                        "is_admin": False,
                    },
                },
            )
        )

        with DominusNodeClient(base_url="http://localhost:3000") as client:
            result = client.connect_with_credentials("user@example.com", "password123")
            assert result.user is not None
            assert result.user.email == "user@example.com"
            assert result.mfa_required is False

    @respx.mock
    def test_connect_with_mfa_required(self) -> None:
        """Test login flow when MFA is required."""
        respx.post("http://localhost:3000/api/auth/login").mock(
            return_value=httpx.Response(
                200,
                json={
                    "mfaRequired": True,
                    "mfaChallengeToken": "challenge_token_abc",
                },
            )
        )

        with DominusNodeClient(base_url="http://localhost:3000") as client:
            result = client.connect_with_credentials("user@example.com", "password123")
            assert result.mfa_required is True
            assert result.mfa_challenge_token == "challenge_token_abc"
            assert result.user is None

    @respx.mock
    def test_disconnect(self) -> None:
        """Test that disconnect calls logout and clears state."""
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/verify-key").mock(
            return_value=httpx.Response(
                200,
                json={
                    "valid": True,
                    "token": access,
                    "refreshToken": refresh,
                    "userId": "u-123",
                    "email": "test@example.com",
                },
            )
        )
        respx.post("http://localhost:3000/api/auth/logout").mock(
            return_value=httpx.Response(200, json={"message": "Logged out successfully"})
        )

        with DominusNodeClient(base_url="http://localhost:3000") as client:
            client.connect_with_key("dn_live_test_key")
            assert client._token_manager.has_tokens is True
            client.disconnect()
            assert client._token_manager.has_tokens is False
            assert client._api_key is None

    @respx.mock
    def test_disconnect_clears_state_even_on_logout_failure(self) -> None:
        """Disconnect should clear tokens even if logout endpoint fails."""
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/verify-key").mock(
            return_value=httpx.Response(
                200,
                json={
                    "valid": True,
                    "token": access,
                    "refreshToken": refresh,
                    "userId": "u-123",
                    "email": "test@example.com",
                },
            )
        )
        # Logout fails with 500
        respx.post("http://localhost:3000/api/auth/logout").mock(
            return_value=httpx.Response(500, json={"error": "Internal error"})
        )

        with DominusNodeClient(base_url="http://localhost:3000") as client:
            client.connect_with_key("dn_live_test_key")
            client.disconnect()
            # State should still be cleared
            assert client._token_manager.has_tokens is False
            assert client._api_key is None

    @respx.mock
    def test_auto_connect_with_key_on_init(self) -> None:
        """Sync client auto-connects when api_key is passed to constructor."""
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/verify-key").mock(
            return_value=httpx.Response(
                200,
                json={
                    "valid": True,
                    "token": access,
                    "refreshToken": refresh,
                    "userId": "u-auto",
                    "email": "auto@example.com",
                },
            )
        )

        client = DominusNodeClient(
            base_url="http://localhost:3000",
            api_key="dn_live_auto_key",
        )
        try:
            assert client._token_manager.has_tokens is True
            assert client._api_key == "dn_live_auto_key"
        finally:
            client.close()

    @respx.mock
    def test_auto_connect_failure_clears_credentials(self) -> None:
        """If auto-connect fails, credentials should be cleared."""
        respx.post("http://localhost:3000/api/auth/verify-key").mock(
            return_value=httpx.Response(401, json={"error": "Invalid key"})
        )

        with pytest.raises(AuthenticationError):
            DominusNodeClient(
                base_url="http://localhost:3000",
                api_key="dn_live_bad_key",
            )


class TestAsyncDominusNodeClientInit:
    """Test async client initialization."""

    def test_default_initialization(self) -> None:
        client = AsyncDominusNodeClient()
        assert isinstance(client.auth, AsyncAuthResource)
        assert isinstance(client.keys, AsyncKeysResource)
        assert isinstance(client.wallet, AsyncWalletResource)
        assert isinstance(client.usage, AsyncUsageResource)
        assert isinstance(client.plans, AsyncPlansResource)
        assert isinstance(client.sessions, AsyncSessionsResource)
        assert isinstance(client.proxy, AsyncProxyResource)
        assert isinstance(client.admin, AsyncAdminResource)

    def test_custom_settings(self) -> None:
        client = AsyncDominusNodeClient(
            base_url="http://localhost:3000",
            proxy_host="myproxy.local",
            http_proxy_port=9090,
            socks5_proxy_port=1081,
        )
        assert client._proxy_host == "myproxy.local"

    def test_pre_existing_tokens(self) -> None:
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)
        client = AsyncDominusNodeClient(access_token=access, refresh_token=refresh)
        assert client._token_manager.has_tokens is True

    def test_async_resource_properties(self) -> None:
        """Verify all async resource properties are accessible."""
        client = AsyncDominusNodeClient()
        assert isinstance(client.agentic_wallets, AsyncAgenticWalletResource)
        assert isinstance(client.teams, AsyncTeamsResource)
        assert client.x402 is not None
        assert client.wallet_auth is not None
        assert client.mpp is not None

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_context_manager_with_key(self) -> None:
        """Test async context manager auto-connects with API key."""
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/verify-key").mock(
            return_value=httpx.Response(
                200,
                json={
                    "valid": True,
                    "token": access,
                    "refreshToken": refresh,
                    "userId": "u-789",
                    "email": "async@example.com",
                },
            )
        )

        async with AsyncDominusNodeClient(
            base_url="http://localhost:3000",
            api_key="dn_live_async_key",
        ) as client:
            assert client._token_manager.has_tokens is True
            assert client._api_key == "dn_live_async_key"

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_connect_with_credentials(self) -> None:
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/login").mock(
            return_value=httpx.Response(
                200,
                json={
                    "token": access,
                    "refreshToken": refresh,
                    "user": {
                        "id": "u-async",
                        "email": "async@example.com",
                        "created_at": "2024-01-01T00:00:00Z",
                        "is_admin": False,
                    },
                },
            )
        )

        async with AsyncDominusNodeClient(base_url="http://localhost:3000") as client:
            result = await client.connect_with_credentials("async@example.com", "pass123")
            assert result.user is not None
            assert result.user.email == "async@example.com"

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_disconnect_clears_credentials(self) -> None:
        """Async disconnect should clear all credential fields."""
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        respx.post("http://localhost:3000/api/auth/verify-key").mock(
            return_value=httpx.Response(
                200,
                json={
                    "valid": True,
                    "token": access,
                    "refreshToken": refresh,
                    "userId": "u-dc",
                    "email": "dc@example.com",
                },
            )
        )
        respx.post("http://localhost:3000/api/auth/logout").mock(
            return_value=httpx.Response(200, json={"message": "ok"})
        )

        async with AsyncDominusNodeClient(base_url="http://localhost:3000") as client:
            await client.connect_with_key("dn_live_async_key")
            assert client._token_manager.has_tokens is True
            await client.disconnect()
            assert client._token_manager.has_tokens is False
            assert client._api_key is None
            # Deferred credentials should also be cleared
            assert client._deferred_api_key is None
            assert client._deferred_email is None
            assert client._deferred_password is None


class TestLoginResultRedaction:
    """Verify that LoginResult repr redacts tokens."""

    def test_login_result_repr_redacts_token(self) -> None:
        from dominusnode.types import LoginResult
        result = LoginResult(token="secret-token-abc", refresh_token="secret-refresh-xyz")
        repr_str = repr(result)
        assert "secret-token-abc" not in repr_str
        assert "secret-refresh-xyz" not in repr_str
        assert "[REDACTED]" in repr_str

    def test_login_result_repr_shows_none_when_no_token(self) -> None:
        from dominusnode.types import LoginResult
        result = LoginResult()
        repr_str = repr(result)
        assert "None" in repr_str
        assert "[REDACTED]" not in repr_str


class TestCreatedApiKeyRedaction:
    """Verify that CreatedApiKey repr redacts the raw key."""

    def test_created_api_key_repr_redacts_key(self) -> None:
        from dominusnode.types import CreatedApiKey
        key = CreatedApiKey(
            key="dn_live_abc123def456",
            id="k-1",
            prefix="dn_live_abc1",
            label="Test",
            created_at="2024-01-01",
        )
        repr_str = repr(key)
        assert "dn_live_abc123def456" not in repr_str
        assert "[REDACTED]" in repr_str
        assert "k-1" in repr_str


class TestMfaSetupRedaction:
    """Verify that MfaSetup repr redacts secrets."""

    def test_mfa_setup_repr_redacts_secret(self) -> None:
        from dominusnode.types import MfaSetup
        setup = MfaSetup(
            secret="JBSWY3DPEHPK3PXP",
            otpauth_uri="otpauth://totp/Test?secret=JBSWY3DPEHPK3PXP",
            backup_codes=["code1", "code2", "code3"],
        )
        repr_str = repr(setup)
        assert "JBSWY3DPEHPK3PXP" not in repr_str
        assert "[REDACTED]" in repr_str
        assert "3 codes" in repr_str
