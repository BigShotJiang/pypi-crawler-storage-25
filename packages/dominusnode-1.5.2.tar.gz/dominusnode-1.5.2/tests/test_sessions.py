"""Tests for SessionsResource -- list active sessions, empty responses,
and error handling."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from dominusnode.errors import AuthenticationError, ServerError
from dominusnode.sessions import SessionsResource
from dominusnode.types import ActiveSession


class TestSessionsResourceGetActive:
    """Tests for SessionsResource.get_active()."""

    def _make_sessions(self) -> tuple[SessionsResource, MagicMock]:
        mock_http = MagicMock()
        sessions = SessionsResource(mock_http)
        return sessions, mock_http

    def test_get_active_returns_sessions(self) -> None:
        sessions, mock_http = self._make_sessions()
        mock_http.get.return_value = {
            "sessions": [
                {
                    "id": "sess-001",
                    "startedAt": "2024-06-15T10:00:00Z",
                    "status": "active",
                },
                {
                    "id": "sess-002",
                    "startedAt": "2024-06-15T10:05:00Z",
                    "status": "active",
                },
                {
                    "id": "sess-003",
                    "startedAt": "2024-06-15T10:10:00Z",
                    "status": "active",
                },
            ],
        }

        result = sessions.get_active()
        assert len(result) == 3
        assert all(isinstance(s, ActiveSession) for s in result)
        assert result[0].id == "sess-001"
        assert result[0].started_at == "2024-06-15T10:00:00Z"
        assert result[0].status == "active"
        mock_http.get.assert_called_once_with("/api/sessions/active")

    def test_get_active_empty_list(self) -> None:
        sessions, mock_http = self._make_sessions()
        mock_http.get.return_value = {"sessions": []}

        result = sessions.get_active()
        assert result == []

    def test_get_active_single_session(self) -> None:
        sessions, mock_http = self._make_sessions()
        mock_http.get.return_value = {
            "sessions": [
                {
                    "id": "sess-only",
                    "startedAt": "2024-06-15T12:00:00Z",
                    "status": "active",
                },
            ],
        }

        result = sessions.get_active()
        assert len(result) == 1
        assert result[0].id == "sess-only"

    def test_get_active_default_status(self) -> None:
        """When status is missing from response, it should default to 'active'."""
        sessions, mock_http = self._make_sessions()
        mock_http.get.return_value = {
            "sessions": [
                {
                    "id": "sess-no-status",
                    "startedAt": "2024-06-15T12:00:00Z",
                },
            ],
        }

        result = sessions.get_active()
        assert result[0].status == "active"

    def test_get_active_401_raises(self) -> None:
        sessions, mock_http = self._make_sessions()
        mock_http.get.side_effect = AuthenticationError("Not authenticated")

        with pytest.raises(AuthenticationError):
            sessions.get_active()

    def test_get_active_500_raises(self) -> None:
        sessions, mock_http = self._make_sessions()
        mock_http.get.side_effect = ServerError("Internal error")

        with pytest.raises(ServerError):
            sessions.get_active()


class TestActiveSessionDataclass:
    """Tests for ActiveSession dataclass properties."""

    def test_active_session_is_frozen(self) -> None:
        session = ActiveSession(id="s-1", started_at="2024-01-01", status="active")
        with pytest.raises(AttributeError):
            session.status = "ended"  # type: ignore

    def test_active_session_does_not_include_proxy_ip(self) -> None:
        """ActiveSession must NOT include proxy_ip (upstream infra detail per SDK rules)."""
        session = ActiveSession(id="s-1", started_at="2024-01-01", status="active")
        assert not hasattr(session, "proxy_ip")

    def test_active_session_fields(self) -> None:
        session = ActiveSession(id="s-1", started_at="2024-01-01T00:00:00Z", status="active")
        assert session.id == "s-1"
        assert session.started_at == "2024-01-01T00:00:00Z"
        assert session.status == "active"
