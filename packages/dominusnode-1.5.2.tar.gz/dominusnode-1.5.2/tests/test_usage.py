"""Tests for UsageResource -- usage stats, daily usage, top hosts, CSV export,
and error handling."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from dominusnode.errors import AuthenticationError, ServerError
from dominusnode.usage import UsageResource
from dominusnode.types import DailyUsage, TopHost, UsageResponse, UsageSummary


class TestUsageResourceGet:
    """Tests for UsageResource.get() -- primary usage endpoint."""

    def _make_usage(self) -> tuple[UsageResource, MagicMock]:
        mock_http = MagicMock()
        usage = UsageResource(mock_http)
        return usage, mock_http

    def test_get_returns_usage_response(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {
            "summary": {
                "totalBytes": 1073741824,
                "totalCostCents": 500,
                "requestCount": 150,
                "totalGB": 1.0,
                "totalCostUsd": 5.0,
            },
            "records": [
                {
                    "id": "rec-1",
                    "sessionId": "sess-1",
                    "bytesIn": 500000,
                    "bytesOut": 100000,
                    "totalBytes": 600000,
                    "costCents": 1,
                    "proxyType": "http",
                    "targetHost": "example.com",
                    "createdAt": "2024-06-01T12:00:00Z",
                },
            ],
            "pagination": {"limit": 200, "offset": 0, "total": 1},
            "period": {"since": "2024-06-01", "until": "2024-06-30"},
        }

        result = usage.get()
        assert isinstance(result, UsageResponse)
        assert isinstance(result.summary, UsageSummary)
        assert result.summary.total_bytes == 1073741824
        assert result.summary.total_gb == 1.0
        assert result.summary.total_cost_cents == 500
        assert result.summary.request_count == 150
        assert len(result.records) == 1
        assert result.records[0].target_host == "example.com"
        assert result.pagination.total == 1
        assert result.period.since == "2024-06-01"

    def test_get_with_date_range(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {
            "summary": {
                "totalBytes": 0,
                "totalCostCents": 0,
                "requestCount": 0,
                "totalGB": 0,
                "totalCostUsd": 0,
            },
            "records": [],
            "pagination": {"limit": 200, "offset": 0, "total": 0},
            "period": {"since": "2024-06-15", "until": "2024-06-20"},
        }

        result = usage.get(since="2024-06-15", until="2024-06-20", limit=50, offset=10)
        mock_http.get.assert_called_once_with(
            "/api/usage",
            params={"since": "2024-06-15", "until": "2024-06-20", "limit": 50, "offset": 10},
        )
        assert result.summary.total_bytes == 0

    def test_get_default_params(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {
            "summary": {
                "totalBytes": 0,
                "totalCostCents": 0,
                "requestCount": 0,
                "totalGB": 0,
                "totalCostUsd": 0,
            },
            "records": [],
            "pagination": {"limit": 200, "offset": 0, "total": 0},
            "period": {},
        }

        usage.get()
        mock_http.get.assert_called_once_with(
            "/api/usage",
            params={"limit": 200, "offset": 0},
        )

    def test_get_multiple_records(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {
            "summary": {
                "totalBytes": 2000000,
                "totalCostCents": 10,
                "requestCount": 5,
                "totalGB": 0.002,
                "totalCostUsd": 0.10,
            },
            "records": [
                {
                    "id": f"rec-{i}",
                    "sessionId": f"sess-{i}",
                    "bytesIn": 200000,
                    "bytesOut": 200000,
                    "totalBytes": 400000,
                    "costCents": 2,
                    "proxyType": "http",
                    "targetHost": f"host-{i}.com",
                    "createdAt": f"2024-06-0{i+1}T12:00:00Z",
                }
                for i in range(5)
            ],
            "pagination": {"limit": 200, "offset": 0, "total": 5},
            "period": {"since": "2024-06-01", "until": "2024-06-30"},
        }

        result = usage.get()
        assert len(result.records) == 5
        assert result.records[2].target_host == "host-2.com"

    def test_get_401_raises(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.side_effect = AuthenticationError("Token expired")

        with pytest.raises(AuthenticationError):
            usage.get()

    def test_get_500_raises(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.side_effect = ServerError("Database error")

        with pytest.raises(ServerError):
            usage.get()


class TestUsageResourceGetDaily:
    """Tests for UsageResource.get_daily()."""

    def _make_usage(self) -> tuple[UsageResource, MagicMock]:
        mock_http = MagicMock()
        usage = UsageResource(mock_http)
        return usage, mock_http

    def test_get_daily_returns_daily_usage_list(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {
            "days": [
                {
                    "date": "2024-06-01",
                    "totalBytes": 500000000,
                    "totalGB": 0.47,
                    "totalCostCents": 235,
                    "totalCostUsd": 2.35,
                    "requestCount": 75,
                },
                {
                    "date": "2024-06-02",
                    "totalBytes": 800000000,
                    "totalGB": 0.74,
                    "totalCostCents": 370,
                    "totalCostUsd": 3.70,
                    "requestCount": 120,
                },
            ],
        }

        result = usage.get_daily()
        assert len(result) == 2
        assert isinstance(result[0], DailyUsage)
        assert result[0].date == "2024-06-01"
        assert result[0].total_gb == 0.47
        assert result[1].request_count == 120

    def test_get_daily_empty(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {"days": []}

        result = usage.get_daily()
        assert result == []

    def test_get_daily_with_date_range(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {"days": []}

        usage.get_daily(since="2024-06-01", until="2024-06-30")
        mock_http.get.assert_called_once_with(
            "/api/usage/daily",
            params={"since": "2024-06-01", "until": "2024-06-30"},
        )

    def test_get_daily_without_date_range(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {"days": []}

        usage.get_daily()
        mock_http.get.assert_called_once_with(
            "/api/usage/daily",
            params={},
        )


class TestUsageResourceGetTopHosts:
    """Tests for UsageResource.get_top_hosts()."""

    def _make_usage(self) -> tuple[UsageResource, MagicMock]:
        mock_http = MagicMock()
        usage = UsageResource(mock_http)
        return usage, mock_http

    def test_get_top_hosts_returns_host_list(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {
            "hosts": [
                {
                    "targetHost": "api.example.com",
                    "totalBytes": 2000000000,
                    "totalGB": 1.86,
                    "requestCount": 300,
                },
                {
                    "targetHost": "data.example.com",
                    "totalBytes": 500000000,
                    "totalGB": 0.47,
                    "requestCount": 50,
                },
            ],
        }

        result = usage.get_top_hosts(limit=5)
        assert len(result) == 2
        assert isinstance(result[0], TopHost)
        assert result[0].target_host == "api.example.com"
        assert result[0].total_gb == 1.86
        assert result[1].request_count == 50
        mock_http.get.assert_called_once_with(
            "/api/usage/top-hosts",
            params={"limit": 5},
        )

    def test_get_top_hosts_default_limit(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {"hosts": []}

        usage.get_top_hosts()
        mock_http.get.assert_called_once_with(
            "/api/usage/top-hosts",
            params={"limit": 10},
        )

    def test_get_top_hosts_empty(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {"hosts": []}

        result = usage.get_top_hosts()
        assert result == []

    def test_get_top_hosts_with_date_range(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get.return_value = {"hosts": []}

        usage.get_top_hosts(since="2024-06-01", until="2024-06-30", limit=20)
        mock_http.get.assert_called_once_with(
            "/api/usage/top-hosts",
            params={"since": "2024-06-01", "until": "2024-06-30", "limit": 20},
        )


class TestUsageResourceExportCsv:
    """Tests for UsageResource.export_csv()."""

    def _make_usage(self) -> tuple[UsageResource, MagicMock]:
        mock_http = MagicMock()
        usage = UsageResource(mock_http)
        return usage, mock_http

    def test_export_csv_returns_text(self) -> None:
        usage, mock_http = self._make_usage()
        mock_response = MagicMock()
        mock_response.text = "date,bytes,cost\n2024-06-01,500000000,235\n"
        mock_http.get_raw.return_value = mock_response

        result = usage.export_csv()
        assert "date,bytes,cost" in result
        mock_http.get_raw.assert_called_once_with(
            "/api/usage/export",
            params={},
        )

    def test_export_csv_with_date_range(self) -> None:
        usage, mock_http = self._make_usage()
        mock_response = MagicMock()
        mock_response.text = "date,bytes,cost\n"
        mock_http.get_raw.return_value = mock_response

        usage.export_csv(since="2024-06-01", until="2024-06-30")
        mock_http.get_raw.assert_called_once_with(
            "/api/usage/export",
            params={"since": "2024-06-01", "until": "2024-06-30"},
        )

    def test_export_csv_empty(self) -> None:
        usage, mock_http = self._make_usage()
        mock_response = MagicMock()
        mock_response.text = ""
        mock_http.get_raw.return_value = mock_response

        result = usage.export_csv()
        assert result == ""

    def test_export_csv_401_raises(self) -> None:
        usage, mock_http = self._make_usage()
        mock_http.get_raw.side_effect = AuthenticationError("Unauthorized")

        with pytest.raises(AuthenticationError):
            usage.export_csv()
