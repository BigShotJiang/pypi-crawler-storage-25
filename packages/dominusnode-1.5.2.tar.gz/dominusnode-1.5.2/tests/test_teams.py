"""Tests for TeamsResource -- create, list, get, update, delete, members, invites,
wallet operations, API keys, and error handling."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from dominusnode.errors import (
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from dominusnode.teams import TeamsResource
from dominusnode.types import (
    Team,
    TeamDeleteResponse,
    TeamInvite,
    TeamKey,
    TeamKeyCreateResponse,
    TeamMember,
    TeamTransaction,
)


class TestTeamsResourceCreate:
    """Tests for TeamsResource.create()."""

    def _make_teams(self) -> tuple[TeamsResource, MagicMock]:
        mock_http = MagicMock()
        teams = TeamsResource(mock_http)
        return teams, mock_http

    def test_create_returns_team(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "id": "team-001",
            "name": "Engineering",
            "ownerId": "usr-abc",
            "maxMembers": 10,
            "status": "active",
            "balanceCents": 0,
            "createdAt": "2024-06-01T00:00:00Z",
        }

        result = teams.create("Engineering", max_members=10)
        assert isinstance(result, Team)
        assert result.id == "team-001"
        assert result.name == "Engineering"
        assert result.owner_id == "usr-abc"
        assert result.max_members == 10
        assert result.status == "active"
        assert result.balance_cents == 0
        mock_http.post.assert_called_once_with(
            "/api/teams",
            json={"name": "Engineering", "maxMembers": 10},
        )

    def test_create_without_max_members(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "id": "team-002",
            "name": "Sales",
            "ownerId": "usr-abc",
            "maxMembers": 5,
            "status": "active",
            "balanceCents": 0,
        }

        result = teams.create("Sales")
        assert result.name == "Sales"
        mock_http.post.assert_called_once_with(
            "/api/teams",
            json={"name": "Sales"},
        )

    def test_create_401_raises(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.side_effect = AuthenticationError("Not authenticated")

        with pytest.raises(AuthenticationError):
            teams.create("Team")


class TestTeamsResourceList:
    """Tests for TeamsResource.list()."""

    def _make_teams(self) -> tuple[TeamsResource, MagicMock]:
        mock_http = MagicMock()
        teams = TeamsResource(mock_http)
        return teams, mock_http

    def test_list_returns_teams(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = [
            {
                "id": "team-001",
                "name": "Engineering",
                "ownerId": "usr-abc",
                "maxMembers": 10,
                "status": "active",
                "balanceCents": 5000,
            },
            {
                "id": "team-002",
                "name": "Marketing",
                "ownerId": "usr-def",
                "maxMembers": 5,
                "status": "active",
                "balanceCents": 2000,
            },
        ]

        result = teams.list()
        assert len(result) == 2
        assert isinstance(result[0], Team)
        assert result[0].name == "Engineering"
        assert result[1].name == "Marketing"

    def test_list_empty(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = []

        result = teams.list()
        assert result == []


class TestTeamsResourceGetUpdateDelete:
    """Tests for TeamsResource.get(), update(), and delete()."""

    def _make_teams(self) -> tuple[TeamsResource, MagicMock]:
        mock_http = MagicMock()
        teams = TeamsResource(mock_http)
        return teams, mock_http

    def test_get_returns_team(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = {
            "id": "team-001",
            "name": "Engineering",
            "ownerId": "usr-abc",
            "maxMembers": 10,
            "status": "active",
            "balanceCents": 5000,
        }

        result = teams.get("team-001")
        assert result.id == "team-001"
        mock_http.get.assert_called_once_with("/api/teams/team-001")

    def test_get_url_encodes_id(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = {
            "id": "team/special",
            "name": "Test",
            "ownerId": "usr-abc",
            "status": "active",
        }

        teams.get("team/special")
        mock_http.get.assert_called_once_with("/api/teams/team%2Fspecial")

    def test_get_404_raises(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.side_effect = NotFoundError("Team not found")

        with pytest.raises(NotFoundError, match="Team not found"):
            teams.get("nonexistent")

    def test_update_team(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.patch.return_value = {
            "id": "team-001",
            "name": "Engineering (updated)",
            "ownerId": "usr-abc",
            "maxMembers": 20,
            "status": "active",
            "balanceCents": 5000,
        }

        result = teams.update("team-001", name="Engineering (updated)", max_members=20)
        assert result.name == "Engineering (updated)"
        assert result.max_members == 20

    def test_delete_returns_refund(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.return_value = {"refundedCents": 3000}

        result = teams.delete("team-001")
        assert isinstance(result, TeamDeleteResponse)
        assert result.refunded_cents == 3000

    def test_delete_403_raises(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.side_effect = AuthorizationError("Only owner can delete")

        with pytest.raises(AuthorizationError):
            teams.delete("team-001")


class TestTeamsResourceWallet:
    """Tests for TeamsResource wallet operations."""

    def _make_teams(self) -> tuple[TeamsResource, MagicMock]:
        mock_http = MagicMock()
        teams = TeamsResource(mock_http)
        return teams, mock_http

    def test_fund_wallet(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "transaction": {
                "id": "ttx-001",
                "teamId": "team-001",
                "type": "fund",
                "amountCents": 2000,
                "description": "Wallet fund",
                "createdAt": "2024-06-01T00:00:00Z",
            },
        }

        result = teams.fund_wallet("team-001", 2000)
        assert isinstance(result, TeamTransaction)
        assert result.amount_cents == 2000
        assert result.type == "fund"

    def test_fund_wallet_zero_raises(self) -> None:
        teams, mock_http = self._make_teams()
        with pytest.raises(ValueError, match="positive integer"):
            teams.fund_wallet("team-001", 0)

    def test_fund_wallet_negative_raises(self) -> None:
        teams, mock_http = self._make_teams()
        with pytest.raises(ValueError, match="positive integer"):
            teams.fund_wallet("team-001", -100)

    def test_fund_wallet_overflow_raises(self) -> None:
        teams, mock_http = self._make_teams()
        with pytest.raises(ValueError, match="positive integer"):
            teams.fund_wallet("team-001", 2_147_483_648)

    def test_get_transactions(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = {
            "transactions": [
                {
                    "id": "ttx-001",
                    "teamId": "team-001",
                    "type": "fund",
                    "amountCents": 2000,
                    "description": "Fund",
                    "createdAt": "2024-06-01",
                },
                {
                    "id": "ttx-002",
                    "teamId": "team-001",
                    "type": "debit",
                    "amountCents": -50,
                    "description": "Usage",
                    "createdAt": "2024-06-02",
                },
            ],
        }

        result = teams.get_transactions("team-001", limit=10, offset=0)
        assert len(result) == 2
        assert isinstance(result[0], TeamTransaction)
        assert result[0].type == "fund"
        assert result[1].type == "debit"


class TestTeamsResourceMembers:
    """Tests for TeamsResource member operations."""

    def _make_teams(self) -> tuple[TeamsResource, MagicMock]:
        mock_http = MagicMock()
        teams = TeamsResource(mock_http)
        return teams, mock_http

    def test_list_members(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = {
            "members": [
                {
                    "id": "m-1",
                    "teamId": "team-001",
                    "userId": "usr-abc",
                    "email": "owner@example.com",
                    "role": "owner",
                    "joinedAt": "2024-01-01",
                },
                {
                    "id": "m-2",
                    "teamId": "team-001",
                    "userId": "usr-def",
                    "email": "member@example.com",
                    "role": "member",
                    "joinedAt": "2024-02-01",
                },
            ],
        }

        result = teams.list_members("team-001")
        assert len(result) == 2
        assert isinstance(result[0], TeamMember)
        assert result[0].role == "owner"
        assert result[1].email == "member@example.com"

    def test_add_member(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "userId": "usr-new",
            "email": "new@example.com",
            "role": "member",
        }

        result = teams.add_member("team-001", "new@example.com", role="member")
        assert isinstance(result, TeamMember)
        assert result.email == "new@example.com"
        assert result.role == "member"

    def test_add_member_without_role(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "userId": "usr-new",
            "email": "new@example.com",
            "role": "member",
        }

        teams.add_member("team-001", "new@example.com")
        mock_http.post.assert_called_once_with(
            "/api/teams/team-001/members",
            json={"email": "new@example.com"},
        )

    def test_update_member_role(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.patch.return_value = {
            "userId": "usr-def",
            "email": "member@example.com",
            "role": "admin",
        }

        result = teams.update_member_role("team-001", "usr-def", "admin")
        assert result.role == "admin"

    def test_remove_member(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.return_value = None

        teams.remove_member("team-001", "usr-def")
        mock_http.delete.assert_called_once_with("/api/teams/team-001/members/usr-def")

    def test_remove_member_url_encodes_ids(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.return_value = None

        teams.remove_member("team/1", "user/2")
        mock_http.delete.assert_called_once_with("/api/teams/team%2F1/members/user%2F2")


class TestTeamsResourceInvites:
    """Tests for TeamsResource invite operations."""

    def _make_teams(self) -> tuple[TeamsResource, MagicMock]:
        mock_http = MagicMock()
        teams = TeamsResource(mock_http)
        return teams, mock_http

    def test_create_invite(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "id": "inv-001",
            "teamId": "team-001",
            "email": "invite@example.com",
            "role": "member",
            "token": "invite_token_xyz",
            "expiresAt": "2024-07-01T00:00:00Z",
            "createdAt": "2024-06-01T00:00:00Z",
        }

        result = teams.create_invite("team-001", "invite@example.com", role="member")
        assert isinstance(result, TeamInvite)
        assert result.email == "invite@example.com"
        assert result.token == "invite_token_xyz"

    def test_list_invites(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = {
            "invites": [
                {
                    "id": "inv-001",
                    "teamId": "team-001",
                    "email": "pending@example.com",
                    "role": "member",
                    "expiresAt": "2024-07-01",
                },
            ],
        }

        result = teams.list_invites("team-001")
        assert len(result) == 1
        assert result[0].email == "pending@example.com"

    def test_cancel_invite(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.return_value = None

        teams.cancel_invite("team-001", "inv-001")
        mock_http.delete.assert_called_once_with("/api/teams/team-001/invites/inv-001")

    def test_accept_invite(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "userId": "usr-new",
            "email": "new@example.com",
            "role": "member",
        }

        result = teams.accept_invite("invite_token_xyz")
        assert isinstance(result, TeamMember)
        assert result.email == "new@example.com"
        mock_http.post.assert_called_once_with(
            "/api/teams/invites/invite_token_xyz/accept",
            json={},
        )


class TestTeamsResourceKeys:
    """Tests for TeamsResource API key operations."""

    def _make_teams(self) -> tuple[TeamsResource, MagicMock]:
        mock_http = MagicMock()
        teams = TeamsResource(mock_http)
        return teams, mock_http

    def test_create_key(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.post.return_value = {
            "id": "tk-001",
            "key": "dn_live_team_key_abc123",
            "keyPrefix": "dn_live_team",
            "label": "Team Production Key",
        }

        result = teams.create_key("team-001", "Team Production Key")
        assert isinstance(result, TeamKeyCreateResponse)
        assert result.key == "dn_live_team_key_abc123"
        assert result.label == "Team Production Key"

    def test_create_key_repr_redacts(self) -> None:
        """TeamKeyCreateResponse repr should redact the raw key."""
        key = TeamKeyCreateResponse(
            id="tk-001",
            key="dn_live_secret_team_key",
            key_prefix="dn_live_secr",
            label="Test",
        )
        repr_str = repr(key)
        assert "dn_live_secret_team_key" not in repr_str
        assert "[REDACTED]" in repr_str

    def test_list_keys(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.get.return_value = {
            "keys": [
                {
                    "id": "tk-001",
                    "keyPrefix": "dn_live_team",
                    "label": "Production",
                    "createdAt": "2024-06-01",
                },
                {
                    "id": "tk-002",
                    "keyPrefix": "dn_live_stag",
                    "label": "Staging",
                    "createdAt": "2024-06-02",
                },
            ],
        }

        result = teams.list_keys("team-001")
        assert len(result) == 2
        assert isinstance(result[0], TeamKey)
        assert result[0].label == "Production"

    def test_revoke_key(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.return_value = None

        teams.revoke_key("team-001", "tk-001")
        mock_http.delete.assert_called_once_with("/api/teams/team-001/keys/tk-001")

    def test_revoke_key_url_encodes(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.return_value = None

        teams.revoke_key("team/1", "key/1")
        mock_http.delete.assert_called_once_with("/api/teams/team%2F1/keys/key%2F1")

    def test_revoke_key_404_raises(self) -> None:
        teams, mock_http = self._make_teams()
        mock_http.delete.side_effect = NotFoundError("Key not found")

        with pytest.raises(NotFoundError):
            teams.revoke_key("team-001", "tk-nonexistent")
