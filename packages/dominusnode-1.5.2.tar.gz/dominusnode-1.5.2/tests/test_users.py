"""Tests for AuthResource -- register, login, logout, get profile, verify email,
reset password, MFA flows, and error handling."""

from __future__ import annotations

import time
from unittest.mock import MagicMock

import pytest

from dominusnode.auth import AuthResource, _parse_login_result
from dominusnode.errors import (
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from dominusnode.token_manager import TokenManager
from dominusnode.types import LoginResult, MfaSetup, MfaStatus, User
from tests.conftest import make_jwt


class TestParseLoginResult:
    """Tests for the _parse_login_result helper."""

    def test_parses_successful_login(self) -> None:
        data = {
            "token": "access-tok",
            "refreshToken": "refresh-tok",
            "user": {
                "id": "u-1",
                "email": "test@example.com",
                "created_at": "2024-01-01T00:00:00Z",
                "is_admin": False,
            },
        }
        result = _parse_login_result(data)
        assert result.token == "access-tok"
        assert result.refresh_token == "refresh-tok"
        assert result.user is not None
        assert result.user.id == "u-1"
        assert result.user.email == "test@example.com"
        assert result.mfa_required is False

    def test_parses_mfa_required_response(self) -> None:
        data = {
            "mfaRequired": True,
            "mfaChallengeToken": "challenge_abc",
        }
        result = _parse_login_result(data)
        assert result.mfa_required is True
        assert result.mfa_challenge_token == "challenge_abc"
        assert result.user is None
        assert result.token is None

    def test_parses_login_without_user(self) -> None:
        data = {
            "token": "tok",
            "refreshToken": "rtok",
        }
        result = _parse_login_result(data)
        assert result.token == "tok"
        assert result.user is None

    def test_parses_admin_user(self) -> None:
        data = {
            "token": "admin-tok",
            "refreshToken": "admin-rtok",
            "user": {
                "id": "u-admin",
                "email": "admin@example.com",
                "created_at": "2024-01-01T00:00:00Z",
                "is_admin": True,
            },
        }
        result = _parse_login_result(data)
        assert result.user is not None
        assert result.user.is_admin is True

    def test_parses_missing_created_at(self) -> None:
        data = {
            "token": "tok",
            "refreshToken": "rtok",
            "user": {
                "id": "u-1",
                "email": "test@example.com",
            },
        }
        result = _parse_login_result(data)
        assert result.user is not None
        assert result.user.created_at == ""


class TestAuthResourceRegister:
    """Tests for AuthResource.register()."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_register_stores_tokens(self) -> None:
        auth, mock_http, tm = self._make_auth()
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": access,
            "refreshToken": refresh,
            "user": {
                "id": "u-new",
                "email": "new@example.com",
                "created_at": "2024-01-01",
                "is_admin": False,
            },
        }

        result = auth.register("new@example.com", "password123")
        assert result.user is not None
        assert result.user.email == "new@example.com"
        assert tm.access_token == access
        assert tm.refresh_token == refresh

    def test_register_returns_user_object(self) -> None:
        auth, mock_http, tm = self._make_auth()
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": access,
            "refreshToken": refresh,
            "user": {
                "id": "u-new",
                "email": "fresh@example.com",
                "created_at": "2024-07-01T10:00:00Z",
                "is_admin": False,
            },
        }

        result = auth.register("fresh@example.com", "strongpass!")
        assert isinstance(result, LoginResult)
        assert isinstance(result.user, User)
        assert result.user.id == "u-new"

    def test_register_409_conflict_raises(self) -> None:
        auth, mock_http, tm = self._make_auth()
        from dominusnode.errors import ConflictError
        mock_http.post.side_effect = ConflictError("Email already registered")

        with pytest.raises(ConflictError, match="already registered"):
            auth.register("existing@example.com", "password")

    def test_register_400_validation_error(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.side_effect = ValidationError("Password too short")

        with pytest.raises(ValidationError, match="Password too short"):
            auth.register("user@example.com", "ab")


class TestAuthResourceLogin:
    """Tests for AuthResource.login()."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_login_stores_tokens(self) -> None:
        auth, mock_http, tm = self._make_auth()
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": access,
            "refreshToken": refresh,
            "user": {
                "id": "u-1",
                "email": "user@test.com",
                "created_at": "2024-01-01",
                "is_admin": False,
            },
        }

        result = auth.login("user@test.com", "pass")
        assert result.user is not None
        assert result.user.email == "user@test.com"
        assert tm.has_tokens is True

    def test_login_returns_mfa_required(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.return_value = {
            "mfaRequired": True,
            "mfaChallengeToken": "challenge_xyz",
        }

        result = auth.login("user@test.com", "pass")
        assert result.mfa_required is True
        assert result.mfa_challenge_token == "challenge_xyz"
        assert tm.has_tokens is False

    def test_login_401_raises_authentication_error(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.side_effect = AuthenticationError("Invalid credentials")

        with pytest.raises(AuthenticationError, match="Invalid credentials"):
            auth.login("bad@example.com", "wrongpass")

    def test_login_500_raises_server_error(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.side_effect = ServerError("Internal error")

        with pytest.raises(ServerError):
            auth.login("user@example.com", "pass")


class TestAuthResourceLogout:
    """Tests for AuthResource.logout()."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_logout_clears_tokens(self) -> None:
        auth, mock_http, tm = self._make_auth()
        tm.set_tokens(make_jwt(), make_jwt(exp=int(time.time()) + 7 * 86400))
        mock_http.post.return_value = None

        auth.logout()
        assert tm.has_tokens is False

    def test_logout_calls_api(self) -> None:
        auth, mock_http, tm = self._make_auth()
        tm.set_tokens(make_jwt(), make_jwt(exp=int(time.time()) + 7 * 86400))
        mock_http.post.return_value = None

        auth.logout()
        mock_http.post.assert_called_once_with("/api/auth/logout")


class TestAuthResourceProfile:
    """Tests for AuthResource.me() -- get current profile."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_me_returns_user(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.get.return_value = {
            "user": {
                "id": "u-me",
                "email": "me@test.com",
                "created_at": "2024-06-01",
                "is_admin": True,
            },
        }

        user = auth.me()
        assert user.id == "u-me"
        assert user.email == "me@test.com"
        assert user.is_admin is True
        assert isinstance(user, User)

    def test_me_returns_non_admin_user(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.get.return_value = {
            "user": {
                "id": "u-regular",
                "email": "regular@test.com",
                "created_at": "2024-06-01",
            },
        }

        user = auth.me()
        assert user.is_admin is False

    def test_me_401_raises_authentication_error(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.get.side_effect = AuthenticationError("Token expired")

        with pytest.raises(AuthenticationError):
            auth.me()


class TestAuthResourceVerifyKey:
    """Tests for AuthResource.verify_key()."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_verify_key_stores_tokens(self) -> None:
        auth, mock_http, tm = self._make_auth()
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "valid": True,
            "token": access,
            "refreshToken": refresh,
            "userId": "u-key",
            "email": "key@test.com",
        }

        result = auth.verify_key("dn_live_test_key")
        assert result.token == access
        assert result.user is not None
        assert result.user.id == "u-key"
        assert tm.access_token == access

    def test_verify_key_without_user_id(self) -> None:
        auth, mock_http, tm = self._make_auth()
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": access,
            "refreshToken": refresh,
        }

        result = auth.verify_key("dn_live_test_key")
        assert result.user is None
        assert tm.access_token == access


class TestAuthResourceChangePassword:
    """Tests for AuthResource.change_password()."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_change_password_sends_correct_payload(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.return_value = None

        auth.change_password("oldpass", "newpass123")
        mock_http.post.assert_called_once_with(
            "/api/auth/change-password",
            json={"currentPassword": "oldpass", "newPassword": "newpass123"},
        )

    def test_change_password_403_raises(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.side_effect = AuthorizationError("Current password incorrect")

        with pytest.raises(AuthorizationError):
            auth.change_password("wrong_old", "new")


class TestAuthResourceMfa:
    """Tests for MFA-related auth operations."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_mfa_setup_returns_setup_data(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.return_value = {
            "secret": "JBSWY3DPEHPK3PXP",
            "otpauthUri": "otpauth://totp/Dominus Node:test@test.com?secret=JBSWY3DPEHPK3PXP",
            "backupCodes": ["12345678", "87654321"],
        }

        setup = auth.mfa_setup()
        assert isinstance(setup, MfaSetup)
        assert setup.secret == "JBSWY3DPEHPK3PXP"
        assert "otpauth://" in setup.otpauth_uri
        assert len(setup.backup_codes) == 2

    def test_mfa_enable_returns_true(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.return_value = {"enabled": True}

        result = auth.mfa_enable("123456")
        assert result is True
        mock_http.post.assert_called_once_with(
            "/api/auth/mfa/enable",
            json={"code": "123456"},
        )

    def test_mfa_disable_returns_true(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.post.return_value = {"enabled": False}

        result = auth.mfa_disable("password", "123456")
        assert result is True
        mock_http.post.assert_called_once_with(
            "/api/auth/mfa/disable",
            json={"password": "password", "code": "123456"},
        )

    def test_mfa_status(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.get.return_value = {
            "enabled": True,
            "backupCodesRemaining": 8,
        }

        status = auth.mfa_status()
        assert isinstance(status, MfaStatus)
        assert status.enabled is True
        assert status.backup_codes_remaining == 8

    def test_mfa_status_disabled(self) -> None:
        auth, mock_http, tm = self._make_auth()
        mock_http.get.return_value = {
            "enabled": False,
            "backupCodesRemaining": 0,
        }

        status = auth.mfa_status()
        assert status.enabled is False
        assert status.backup_codes_remaining == 0

    def test_verify_mfa_stores_tokens(self) -> None:
        auth, mock_http, tm = self._make_auth()
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": access,
            "refreshToken": refresh,
            "user": {
                "id": "u-mfa",
                "email": "mfa@test.com",
                "created_at": "2024-01-01",
                "is_admin": False,
            },
        }

        result = auth.verify_mfa("123456", mfa_challenge_token="challenge_tok")
        assert result.token == access
        assert tm.access_token == access
        mock_http.post.assert_called_once_with(
            "/api/auth/mfa/verify",
            json={"code": "123456", "isBackupCode": False, "mfaChallengeToken": "challenge_tok"},
        )

    def test_verify_mfa_with_backup_code(self) -> None:
        auth, mock_http, tm = self._make_auth()
        access = make_jwt()
        refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": access,
            "refreshToken": refresh,
            "user": {
                "id": "u-mfa",
                "email": "mfa@test.com",
                "created_at": "2024-01-01",
                "is_admin": False,
            },
        }

        result = auth.verify_mfa("BACKUP-CODE-1", is_backup_code=True)
        assert result.token == access
        mock_http.post.assert_called_once_with(
            "/api/auth/mfa/verify",
            json={"code": "BACKUP-CODE-1", "isBackupCode": True},
        )


class TestAuthResourceRefresh:
    """Tests for AuthResource.refresh()."""

    def _make_auth(self) -> tuple[AuthResource, MagicMock, TokenManager]:
        mock_http = MagicMock()
        tm = TokenManager()
        auth = AuthResource(mock_http, tm)
        return auth, mock_http, tm

    def test_refresh_returns_token_pair(self) -> None:
        auth, mock_http, tm = self._make_auth()
        old_refresh = make_jwt(exp=int(time.time()) + 7 * 86400)
        tm.set_tokens(make_jwt(), old_refresh)

        new_access = make_jwt()
        new_refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": new_access,
            "refreshToken": new_refresh,
        }

        access, refresh = auth.refresh()
        assert access == new_access
        assert refresh == new_refresh
        assert tm.access_token == new_access

    def test_refresh_without_token_raises(self) -> None:
        auth, mock_http, tm = self._make_auth()
        with pytest.raises(ValueError, match="No refresh token"):
            auth.refresh()

    def test_refresh_with_explicit_token(self) -> None:
        auth, mock_http, tm = self._make_auth()
        new_access = make_jwt()
        new_refresh = make_jwt(exp=int(time.time()) + 7 * 86400)

        mock_http.post.return_value = {
            "token": new_access,
            "refreshToken": new_refresh,
        }

        explicit_rt = "explicit-refresh-token"
        access, refresh = auth.refresh(refresh_token=explicit_rt)
        assert access == new_access
        mock_http.post.assert_called_once_with(
            "/api/auth/refresh",
            json={"refreshToken": explicit_rt},
        )
