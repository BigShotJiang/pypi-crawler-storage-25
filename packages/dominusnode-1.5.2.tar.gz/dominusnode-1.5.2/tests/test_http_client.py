"""Tests for the HTTP client layer -- status code mapping, error extraction,
retry logic, response size limits, and credential scrubbing."""

from __future__ import annotations

import httpx
import pytest

from dominusnode.errors import (
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    DominusNodeError,
    InsufficientBalanceError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from dominusnode.http_client import (
    _add_jitter,
    _extract_error_message,
    _parse_retry_after,
    _raise_for_status,
    MAX_RESPONSE_BYTES,
)


def _make_response(status_code: int, json_body: dict | None = None, headers: dict | None = None) -> httpx.Response:
    """Build a fake httpx.Response for testing."""
    if json_body is not None:
        import json
        content = json.dumps(json_body).encode()
        resp_headers = {"content-type": "application/json"}
    else:
        content = b""
        resp_headers = {}
    if headers:
        resp_headers.update(headers)
    return httpx.Response(
        status_code,
        content=content,
        headers=resp_headers,
        request=httpx.Request("GET", "http://test.local/api/test"),
    )


class TestRaiseForStatus:
    """Tests for _raise_for_status -- HTTP status code to exception mapping."""

    def test_200_does_not_raise(self) -> None:
        resp = _make_response(200, {"ok": True})
        _raise_for_status(resp)  # Should not raise

    def test_201_does_not_raise(self) -> None:
        resp = _make_response(201, {"created": True})
        _raise_for_status(resp)

    def test_204_does_not_raise(self) -> None:
        resp = _make_response(204)
        _raise_for_status(resp)

    def test_400_raises_validation_error(self) -> None:
        resp = _make_response(400, {"error": "Invalid email format"})
        with pytest.raises(ValidationError, match="Invalid email format"):
            _raise_for_status(resp)

    def test_401_raises_authentication_error(self) -> None:
        resp = _make_response(401, {"error": "Token expired"})
        with pytest.raises(AuthenticationError, match="Token expired"):
            _raise_for_status(resp)

    def test_402_raises_insufficient_balance_error(self) -> None:
        resp = _make_response(402, {"error": "Insufficient funds"})
        with pytest.raises(InsufficientBalanceError, match="Insufficient funds"):
            _raise_for_status(resp)

    def test_403_raises_authorization_error(self) -> None:
        resp = _make_response(403, {"error": "Admin only"})
        with pytest.raises(AuthorizationError, match="Admin only"):
            _raise_for_status(resp)

    def test_404_raises_not_found_error(self) -> None:
        resp = _make_response(404, {"error": "Resource not found"})
        with pytest.raises(NotFoundError, match="Resource not found"):
            _raise_for_status(resp)

    def test_409_raises_conflict_error(self) -> None:
        resp = _make_response(409, {"error": "Already exists"})
        with pytest.raises(ConflictError, match="Already exists"):
            _raise_for_status(resp)

    def test_429_raises_rate_limit_error(self) -> None:
        resp = _make_response(429, {"error": "Too many requests"}, headers={"retry-after": "120"})
        with pytest.raises(RateLimitError) as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.retry_after_seconds == 120

    def test_429_default_retry_after(self) -> None:
        resp = _make_response(429, {"error": "Rate limited"})
        with pytest.raises(RateLimitError) as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.retry_after_seconds == 60

    def test_429_invalid_retry_after_header(self) -> None:
        resp = _make_response(429, {"error": "Rate limited"}, headers={"retry-after": "not-a-number"})
        with pytest.raises(RateLimitError) as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.retry_after_seconds == 60

    def test_500_raises_server_error(self) -> None:
        resp = _make_response(500, {"error": "Internal error"})
        with pytest.raises(ServerError, match="Internal error") as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.status_code == 500

    def test_502_raises_server_error(self) -> None:
        resp = _make_response(502, {"error": "Bad gateway"})
        with pytest.raises(ServerError) as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.status_code == 502

    def test_503_raises_server_error(self) -> None:
        resp = _make_response(503, {"error": "Service unavailable"})
        with pytest.raises(ServerError) as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.status_code == 503

    def test_unknown_4xx_raises_dominus_node_error(self) -> None:
        resp = _make_response(418, {"error": "I'm a teapot"})
        with pytest.raises(DominusNodeError, match="I'm a teapot") as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.status_code == 418


class TestExtractErrorMessage:
    """Tests for _extract_error_message."""

    def test_extracts_error_field(self) -> None:
        resp = _make_response(400, {"error": "Bad request body"})
        msg = _extract_error_message(resp)
        assert msg == "Bad request body"

    def test_truncates_long_messages(self) -> None:
        long_msg = "x" * 1000
        resp = _make_response(400, {"error": long_msg})
        msg = _extract_error_message(resp)
        assert len(msg) <= 500

    def test_handles_non_json_body(self) -> None:
        resp = httpx.Response(
            500,
            content=b"<html>Internal Server Error</html>",
            headers={"content-type": "text/html"},
            request=httpx.Request("GET", "http://test.local/api/test"),
        )
        msg = _extract_error_message(resp)
        assert len(msg) > 0  # Should return something, not crash

    def test_handles_empty_body(self) -> None:
        resp = _make_response(500)
        msg = _extract_error_message(resp)
        assert len(msg) > 0


class TestParseRetryAfter:
    """Tests for _parse_retry_after."""

    def test_valid_retry_after(self) -> None:
        resp = _make_response(429, headers={"retry-after": "5"})
        assert _parse_retry_after(resp) == 5.0

    def test_missing_retry_after(self) -> None:
        resp = _make_response(429)
        assert _parse_retry_after(resp) == 1.0

    def test_invalid_retry_after(self) -> None:
        resp = _make_response(429, headers={"retry-after": "invalid"})
        assert _parse_retry_after(resp) == 1.0

    def test_nan_retry_after(self) -> None:
        resp = _make_response(429, headers={"retry-after": "nan"})
        # "nan" parses as float NaN, should be guarded
        result = _parse_retry_after(resp)
        assert result == 1.0

    def test_infinity_retry_after(self) -> None:
        resp = _make_response(429, headers={"retry-after": "inf"})
        result = _parse_retry_after(resp)
        assert result == 1.0

    def test_zero_retry_after_clamps_to_min(self) -> None:
        resp = _make_response(429, headers={"retry-after": "0"})
        result = _parse_retry_after(resp)
        assert result >= 0.1

    def test_very_small_retry_after_clamps(self) -> None:
        resp = _make_response(429, headers={"retry-after": "0.01"})
        result = _parse_retry_after(resp)
        assert result >= 0.1


class TestAddJitter:
    """Tests for _add_jitter."""

    def test_jitter_is_within_range(self) -> None:
        for _ in range(100):
            result = _add_jitter(5.0)
            # Should be within +/- 10% of 5.0 = [4.5, 5.5], but also >= 0.1
            assert 0.1 <= result <= 6.0

    def test_jitter_minimum_floor(self) -> None:
        # Very small input should still return at least 0.1
        result = _add_jitter(0.001)
        assert result >= 0.1

    def test_jitter_zero_returns_minimum(self) -> None:
        result = _add_jitter(0.0)
        assert result >= 0.1


class TestMaxResponseBytes:
    """Tests for response size limit constant."""

    def test_max_response_bytes_is_10mb(self) -> None:
        assert MAX_RESPONSE_BYTES == 10 * 1024 * 1024


class TestCredentialScrubbing:
    """Verify that API keys and tokens are not leaked in error messages."""

    def test_error_message_does_not_contain_raw_api_key(self) -> None:
        """If the server accidentally returns an API key in error, it should
        still be in the error (that's the server's fault), but the SDK error
        hierarchy itself should not introduce key exposure."""
        err = AuthenticationError("Invalid key")
        # The message itself is the server message -- that's fine.
        # The key point is that DominusNodeError doesn't contain credentials
        # that the SDK has stored.
        assert "dn_live_" not in str(err)

    def test_all_errors_inherit_from_base(self) -> None:
        """All errors can be caught with a single except DominusNodeError."""
        error_classes = [
            AuthenticationError,
            AuthorizationError,
            RateLimitError,
            InsufficientBalanceError,
            ValidationError,
            NotFoundError,
            ConflictError,
            ServerError,
            NetworkError,
        ]
        for cls in error_classes:
            err = cls()
            assert isinstance(err, DominusNodeError)
