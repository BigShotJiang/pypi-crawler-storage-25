"""x402 V2 (HTTP 402 Payment Required) protocol information resource.

V2 changes from V1:
- Protocol version "2" (was "1")
- CAIP-2 network IDs (e.g. "eip155:8453" instead of "base")
- Payment header: PAYMENT-SIGNATURE (was X-PAYMENT)
- Response header: PAYMENT-RESPONSE (was X-PAYMENT-RESPONSE)
- Requirements header: PAYMENT-REQUIRED
- New token: EURC (in addition to USDC)
- New scheme: permit2 (in addition to exact)
- Additional facilitator chains: Ethereum (eip155:1), Optimism (eip155:10),
  Arbitrum (eip155:42161), and Solana
"""

from __future__ import annotations

from typing import List
from dataclasses import dataclass, field

from .http_client import AsyncHttpClient, SyncHttpClient

# x402 V2 protocol version.
X402_PROTOCOL_VERSION = "2"

# x402 V2 header constants.
# V2 renamed the payment headers.  Servers should accept both old and new
# for backward compatibility during the transition period.
X402_HEADER_PAYMENT_SIGNATURE = "PAYMENT-SIGNATURE"
X402_HEADER_PAYMENT_SIGNATURE_LEGACY = "X-PAYMENT"
X402_HEADER_PAYMENT_RESPONSE = "PAYMENT-RESPONSE"
X402_HEADER_PAYMENT_RESPONSE_LEGACY = "X-PAYMENT-RESPONSE"
X402_HEADER_PAYMENT_REQUIRED = "PAYMENT-REQUIRED"


@dataclass(frozen=True)
class X402Facilitator:
    address: str
    chain: str
    """Human-readable network name (e.g. "base", "ethereum")."""
    network: str
    """CAIP-2 network identifier (e.g. "eip155:8453"). Added in V2."""
    network_id: str = ""


@dataclass(frozen=True)
class X402Pricing:
    per_request_cents: int
    per_gb_cents: int
    currency: str


@dataclass(frozen=True)
class X402PaymentHeaders:
    """Header names used by the current protocol version."""
    request: str = X402_HEADER_PAYMENT_SIGNATURE
    response: str = X402_HEADER_PAYMENT_RESPONSE
    required: str = X402_HEADER_PAYMENT_REQUIRED


@dataclass(frozen=True)
class X402Info:
    supported: bool
    enabled: bool
    protocol: str
    """Protocol version -- "2" for x402 V2."""
    version: str
    facilitators: List[X402Facilitator]
    pricing: X402Pricing
    """Supported token symbols (e.g. ["USDC", "EURC"])."""
    currencies: List[str]
    """Supported payment schemes (e.g. ["exact", "permit2"])."""
    schemes: List[str] = field(default_factory=list)
    wallet_type: str = ""
    agentic_wallets: bool = False
    """Header names used by this protocol version."""
    payment_headers: X402PaymentHeaders = field(default_factory=X402PaymentHeaders)


def _parse_x402_info(data: dict) -> X402Info:
    """Parse x402 info response into typed dataclass."""
    facilitators = [
        X402Facilitator(
            address=f["address"],
            chain=f["chain"],
            network=f["network"],
            network_id=f.get("networkId", ""),
        )
        for f in data.get("facilitators", [])
    ]
    pricing_data = data.get("pricing", {})
    pricing = X402Pricing(
        per_request_cents=pricing_data.get("perRequestCents", 0),
        per_gb_cents=pricing_data.get("perGbCents", 0),
        currency=pricing_data.get("currency", ""),
    )
    headers_data = data.get("paymentHeaders", {})
    payment_headers = X402PaymentHeaders(
        request=headers_data.get("request", X402_HEADER_PAYMENT_SIGNATURE),
        response=headers_data.get("response", X402_HEADER_PAYMENT_RESPONSE),
        required=headers_data.get("required", X402_HEADER_PAYMENT_REQUIRED),
    )
    return X402Info(
        supported=data.get("supported", False),
        enabled=data.get("enabled", False),
        protocol=data.get("protocol", ""),
        version=data.get("version", ""),
        facilitators=facilitators,
        pricing=pricing,
        currencies=data.get("currencies", []),
        schemes=data.get("schemes", []),
        wallet_type=data.get("walletType", ""),
        agentic_wallets=data.get("agenticWallets", False),
        payment_headers=payment_headers,
    )


class X402Resource:
    """Synchronous x402 V2 protocol information operations."""

    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def get_info(self) -> X402Info:
        """Get x402 V2 protocol information (no auth required)."""
        data = self._http.get("/api/x402/info", requires_auth=False)
        return _parse_x402_info(data)


class AsyncX402Resource:
    """Asynchronous x402 V2 protocol information operations."""

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_info(self) -> X402Info:
        """Get x402 V2 protocol information (no auth required)."""
        data = await self._http.get("/api/x402/info", requires_auth=False)
        return _parse_x402_info(data)
