"""Tests for the CLI entry point."""

import logging
import re
import sys
from pathlib import Path
from unittest.mock import patch, AsyncMock

import pytest

from cruise.cli import main, configure_logging


def test_version_flag_exits_zero(capsys):
    """--version prints version string and exits with code 0."""
    with patch("sys.argv", ["cruise", "--version"]):
        with pytest.raises(SystemExit) as exc_info:
            main()
    assert exc_info.value.code == 0
    captured = capsys.readouterr()
    assert re.match(r"cruise \d+\.\d+\.\d+", captured.out)


def test_configure_logging_no_file(tmp_path):
    """configure_logging without log_file does not add any FileHandler for a real path."""
    root = logging.getLogger()
    original_handlers = root.handlers[:]
    try:
        configure_logging(verbose=False, log_file=None)
        # No FileHandler pointing to a real path should be added
        new_file_handlers = [
            h for h in root.handlers
            if h not in original_handlers and isinstance(h, logging.FileHandler)
        ]
        assert len(new_file_handlers) == 0
    finally:
        for h in root.handlers[:]:
            if h not in original_handlers:
                h.close()
                root.removeHandler(h)


def test_configure_logging_with_file(tmp_path):
    """configure_logging with log_file adds a FileHandler writing to that path."""
    log_path = tmp_path / "cruise.log"
    root = logging.getLogger()
    original_handlers = root.handlers[:]
    try:
        configure_logging(verbose=False, log_file=str(log_path))
        new_file_handlers = [
            h for h in root.handlers
            if h not in original_handlers and isinstance(h, logging.FileHandler)
        ]
        assert len(new_file_handlers) == 1
        assert new_file_handlers[0].baseFilename == str(log_path)
    finally:
        for h in root.handlers[:]:
            if h not in original_handlers:
                h.close()
                root.removeHandler(h)


def test_log_file_writes_output(tmp_path):
    """Log messages are written to the log file when --log-file is given."""
    log_path = tmp_path / "cruise.log"
    root = logging.getLogger()
    original_handlers = root.handlers[:]
    try:
        configure_logging(verbose=False, log_file=str(log_path))
        logging.getLogger("test.logfile").info("hello from test")
        # Flush all new file handlers
        for h in root.handlers:
            if h not in original_handlers and isinstance(h, logging.FileHandler):
                h.flush()
        content = log_path.read_text()
        assert "hello from test" in content
    finally:
        for h in root.handlers[:]:
            if h not in original_handlers:
                h.close()
                root.removeHandler(h)


def test_log_file_flag_accepted(tmp_path):
    """--log-file flag is accepted by the CLI argument parser."""
    log_path = tmp_path / "test.log"
    with patch("sys.argv", ["cruise", "--version"]):
        with pytest.raises(SystemExit) as exc_info:
            main()
    # Just verify --version still works (parser didn't break)
    assert exc_info.value.code == 0
