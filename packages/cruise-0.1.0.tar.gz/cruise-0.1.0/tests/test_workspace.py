"""Tests for workspace (git worktree) management."""

import asyncio
from pathlib import Path

import pytest

from cruise.workspace import (
    WorkspaceError,
    create_worktree,
    remove_worktree,
    worktree_exists,
)


@pytest.fixture
def git_repo(tmp_path):
    """Create a minimal git repo with an initial commit and an origin remote."""
    repo = tmp_path / "repo"
    repo.mkdir()

    async def setup():
        await _run("git", "init", cwd=repo)
        await _run("git", "config", "user.email", "test@test.com", cwd=repo)
        await _run("git", "config", "user.name", "Test", cwd=repo)
        # Create initial commit
        (repo / "README.md").write_text("# Test")
        await _run("git", "add", ".", cwd=repo)
        await _run("git", "commit", "-m", "init", cwd=repo)
        # Create a bare clone to act as "origin"
        origin = tmp_path / "origin.git"
        await _run("git", "clone", "--bare", str(repo), str(origin))
        await _run("git", "remote", "add", "origin", str(origin), cwd=repo)
        await _run("git", "fetch", "origin", cwd=repo)

    asyncio.get_event_loop().run_until_complete(setup())
    return repo


async def _run(*args, cwd=None):
    proc = await asyncio.create_subprocess_exec(
        *args,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()
    return proc.returncode


@pytest.mark.asyncio
async def test_create_worktree(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    path = await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")

    assert path == ws_root / "PROJ-1"
    assert path.exists()
    assert (path / "README.md").exists()
    assert worktree_exists(ws_root, "PROJ-1")


@pytest.mark.asyncio
async def test_create_worktree_idempotent(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    path1 = await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")
    path2 = await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")
    assert path1 == path2


@pytest.mark.asyncio
async def test_remove_worktree(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    await create_worktree(git_repo, ws_root, "PROJ-1", "aryan")
    assert worktree_exists(ws_root, "PROJ-1")

    await remove_worktree(git_repo, ws_root, "PROJ-1")
    assert not worktree_exists(ws_root, "PROJ-1")


@pytest.mark.asyncio
async def test_remove_nonexistent_worktree(git_repo, tmp_path):
    ws_root = tmp_path / "workspaces"
    # Should not raise
    await remove_worktree(git_repo, ws_root, "PROJ-999")


def test_worktree_exists_false(tmp_path):
    assert not worktree_exists(tmp_path, "PROJ-1")
