"""Tests for the Linear API client."""

import base64
from datetime import datetime, timezone

import httpx
import pytest
import respx

from cruise.linear import (
    Comment,
    Issue,
    IssueAttachment,
    LinearClient,
    _parse_attachment,
    _parse_comment,
    _parse_issue,
    extract_image_urls_from_markdown,
)


def test_parse_issue_minimal():
    raw = {
        "id": "abc-123",
        "identifier": "PROJ-1",
        "title": "Fix the bug",
        "state": {"name": "Todo"},
    }
    issue = _parse_issue(raw)
    assert issue.id == "abc-123"
    assert issue.identifier == "PROJ-1"
    assert issue.title == "Fix the bug"
    assert issue.state == "Todo"
    assert issue.description == ""
    assert issue.labels == []


def test_parse_issue_full():
    raw = {
        "id": "abc-123",
        "identifier": "PROJ-2",
        "title": "Add feature",
        "description": "Some details",
        "url": "https://linear.app/team/issue/PROJ-2",
        "priority": 2,
        "createdAt": "2026-03-30T10:00:00.000Z",
        "branchName": "feature/PROJ-2",
        "state": {"name": "In Progress"},
        "labels": {"nodes": [{"name": "bug"}, {"name": "urgent"}]},
    }
    issue = _parse_issue(raw)
    assert issue.description == "Some details"
    assert issue.url == "https://linear.app/team/issue/PROJ-2"
    assert issue.priority == 2
    assert issue.labels == ["bug", "urgent"]
    assert issue.branch_name == "feature/PROJ-2"
    assert issue.created_at == datetime(2026, 3, 30, 10, 0, 0, tzinfo=timezone.utc)


def test_parse_issue_null_description():
    raw = {
        "id": "x",
        "identifier": "P-1",
        "title": "T",
        "description": None,
        "state": {"name": "Todo"},
    }
    issue = _parse_issue(raw)
    assert issue.description == ""


def test_parse_issue_missing_labels():
    raw = {
        "id": "x",
        "identifier": "P-1",
        "title": "T",
        "state": {"name": "Todo"},
    }
    issue = _parse_issue(raw)
    assert issue.labels == []


# --- Comment tests ---


def test_parse_comment_minimal():
    raw = {
        "id": "cmt-1",
        "body": "Please add error handling",
    }
    comment = _parse_comment(raw)
    assert comment.id == "cmt-1"
    assert comment.body == "Please add error handling"
    assert comment.created_at is None
    assert comment.is_bot is False


def test_parse_comment_bot_actor():
    raw = {
        "id": "cmt-bot",
        "body": "## Claude Workpad\n### Plan\n...",
        "botActor": {"id": "bot-123"},
    }
    comment = _parse_comment(raw)
    assert comment.is_bot is True


def test_parse_comment_no_bot_actor():
    raw = {
        "id": "cmt-human",
        "body": "Please refactor this",
        "botActor": None,
    }
    comment = _parse_comment(raw)
    assert comment.is_bot is False


def test_parse_comment_with_date():
    raw = {
        "id": "cmt-2",
        "body": "LGTM",
        "createdAt": "2026-03-30T12:00:00.000Z",
    }
    comment = _parse_comment(raw)
    assert comment.created_at == datetime(2026, 3, 30, 12, 0, 0, tzinfo=timezone.utc)


def test_parse_comment_without_parent():
    raw = {"id": "cmt-3", "body": "Top-level comment"}
    comment = _parse_comment(raw)
    assert comment.parent_id is None


def test_parse_comment_with_parent():
    raw = {
        "id": "cmt-4",
        "body": "Reply to another",
        "parent": {"id": "cmt-3"},
    }
    comment = _parse_comment(raw)
    assert comment.parent_id == "cmt-3"


@pytest.mark.asyncio
@respx.mock
async def test_fetch_issue_comments_returns_list():
    respx.post("https://api.linear.app/graphql/").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": {
                    "issue": {
                        "comments": {
                            "nodes": [
                                {"id": "c1", "body": "First comment", "createdAt": "2026-03-30T10:00:00.000Z"},
                                {"id": "c2", "body": "Second comment", "createdAt": "2026-03-30T11:00:00.000Z"},
                            ]
                        }
                    }
                }
            },
        )
    )

    client = LinearClient("test-key")
    comments = await client.fetch_issue_comments("issue-abc")
    await client.close()

    assert len(comments) == 2
    assert comments[0].id == "c1"
    assert comments[0].body == "First comment"
    assert comments[1].id == "c2"


# --- IssueAttachment / attachment tests ---


def test_parse_attachment_minimal():
    raw = {"id": "att-1", "url": "https://uploads.linear.app/img.png", "title": ""}
    att = _parse_attachment(raw)
    assert att.id == "att-1"
    assert att.url == "https://uploads.linear.app/img.png"
    assert att.content_type == ""
    assert att.source_type == ""


def test_parse_attachment_full():
    raw = {
        "id": "att-2",
        "url": "https://uploads.linear.app/diagram.jpg",
        "title": "Architecture diagram",
        "metadata": {"contentType": "image/jpeg"},
        "sourceType": "upload",
    }
    att = _parse_attachment(raw)
    assert att.title == "Architecture diagram"
    assert att.content_type == "image/jpeg"
    assert att.source_type == "upload"


# --- extract_image_urls_from_markdown ---


def test_extract_image_urls_from_markdown_finds_urls():
    text = (
        "Hello\n"
        "![screenshot](https://uploads.linear.app/img.png)\n"
        "![diagram](https://example.com/d.jpg)"
    )
    urls = extract_image_urls_from_markdown(text)
    assert urls == [
        "https://uploads.linear.app/img.png",
        "https://example.com/d.jpg",
    ]


def test_extract_image_urls_from_markdown_no_images():
    text = "No images here, just [a link](https://example.com)"
    urls = extract_image_urls_from_markdown(text)
    assert urls == []


def test_extract_image_urls_from_markdown_empty_string():
    assert extract_image_urls_from_markdown("") == []


# --- fetch_issue_attachments ---


@pytest.mark.asyncio
@respx.mock
async def test_fetch_issue_attachments_returns_list():
    respx.post("https://api.linear.app/graphql/").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": {
                    "issue": {
                        "attachments": {
                            "nodes": [
                                {
                                    "id": "att-1",
                                    "url": "https://uploads.linear.app/img.png",
                                    "title": "Screenshot",
                                    "metadata": {"contentType": "image/png"},
                                    "sourceType": "upload",
                                }
                            ]
                        }
                    }
                }
            },
        )
    )

    client = LinearClient("test-key")
    attachments = await client.fetch_issue_attachments("issue-abc")
    await client.close()

    assert len(attachments) == 1
    assert attachments[0].id == "att-1"
    assert attachments[0].content_type == "image/png"


@pytest.mark.asyncio
@respx.mock
async def test_fetch_issue_attachments_empty():
    respx.post("https://api.linear.app/graphql/").mock(
        return_value=httpx.Response(
            200,
            json={"data": {"issue": {"attachments": {"nodes": []}}}},
        )
    )

    client = LinearClient("test-key")
    attachments = await client.fetch_issue_attachments("issue-xyz")
    await client.close()

    assert attachments == []


# --- download_image_as_base64 ---


@pytest.mark.asyncio
@respx.mock
async def test_download_image_as_base64_returns_data_and_type():
    image_bytes = b"\x89PNG\r\n\x1a\n"  # fake PNG header bytes
    respx.get("https://uploads.linear.app/img.png").mock(
        return_value=httpx.Response(
            200,
            content=image_bytes,
            headers={"Content-Type": "image/png"},
        )
    )

    client = LinearClient("test-key")
    result = await client.download_image_as_base64("https://uploads.linear.app/img.png")
    await client.close()

    assert result is not None
    data, media_type = result
    assert media_type == "image/png"
    assert base64.b64decode(data) == image_bytes


@pytest.mark.asyncio
@respx.mock
async def test_download_image_as_base64_returns_none_on_error():
    respx.get("https://uploads.linear.app/broken.png").mock(
        return_value=httpx.Response(404)
    )

    client = LinearClient("test-key")
    result = await client.download_image_as_base64("https://uploads.linear.app/broken.png")
    await client.close()

    assert result is None


@pytest.mark.asyncio
@respx.mock
async def test_fetch_issue_comments_empty():
    respx.post("https://api.linear.app/graphql/").mock(
        return_value=httpx.Response(
            200,
            json={"data": {"issue": {"comments": {"nodes": []}}}},
        )
    )

    client = LinearClient("test-key")
    comments = await client.fetch_issue_comments("issue-xyz")
    await client.close()

    assert comments == []
