"""Tests for the polling/orchestration logic."""

import asyncio
import time
from unittest.mock import AsyncMock, patch

import pytest

from cruise.config import AgentConfig, Config, LinearConfig, PollingConfig, RepoConfig

from cruise.linear import Comment, Issue, IssueAttachment
from cruise.poller import CompletedAgent, Poller, RetryEntry, RunningAgent


def _make_config(tmp_path) -> Config:
    return Config(
        linear=LinearConfig(
            api_key="test-key",
            team_key="test-slug",
            active_states=["Todo", "In Progress"],
            terminal_states=["Done", "Cancelled"],
        ),
        repo=RepoConfig(
            path=tmp_path / "repo",
            workspace_root=tmp_path / "workspaces",
            branch_prefix="test",
        ),
        polling=PollingConfig(interval_seconds=1),
        agent=AgentConfig(
            max_concurrent=2,
            max_turns=5,
            stall_timeout_seconds=60,
            max_retry_attempts=3,
        ),
    )


def _make_issue(id="issue-1", identifier="PROJ-1", title="Test", state="Todo") -> Issue:
    return Issue(id=id, identifier=identifier, title=title, state=state)


class TestPollerRetryScheduling:
    def test_schedule_retry(self, tmp_path):
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        poller._schedule_retry(issue, attempt=1, error="test error")

        assert issue.id in poller.retries
        entry = poller.retries[issue.id]
        assert entry.attempt == 2
        assert entry.error == "test error"

    def test_schedule_retry_exponential_backoff(self, tmp_path):
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        # Attempt 1 -> 10s delay
        poller._schedule_retry(issue, attempt=1)
        entry1 = poller.retries[issue.id]
        expected_due1 = time.monotonic() + 10
        assert abs(entry1.due_at - expected_due1) < 2

        # Attempt 2 -> 20s delay
        poller._schedule_retry(issue, attempt=2)
        entry2 = poller.retries[issue.id]
        expected_due2 = time.monotonic() + 20
        assert abs(entry2.due_at - expected_due2) < 2

    @pytest.mark.asyncio
    async def test_process_retries_dispatches_due(self, tmp_path):
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        poller.retries[issue.id] = RetryEntry(
            issue=issue,
            attempt=2,
            due_at=time.monotonic() - 1,  # Already past due
        )

        with patch.object(poller, "_dispatch", new_callable=AsyncMock) as mock_dispatch:
            await poller._process_retries()
            assert issue.id not in poller.retries
            mock_dispatch.assert_called_once_with(
                issue, attempt=2, resume_session_id=None,
            )

    @pytest.mark.asyncio
    async def test_process_retries_keeps_future(self, tmp_path):
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        poller.retries[issue.id] = RetryEntry(
            issue=issue,
            attempt=2,
            due_at=time.monotonic() + 1000,
        )

        with patch.object(poller, "_dispatch", new_callable=AsyncMock) as mock_dispatch:
            await poller._process_retries()
            assert issue.id in poller.retries
            mock_dispatch.assert_not_called()


class TestPollerDryRun:
    @pytest.mark.asyncio
    async def test_dry_run_does_not_dispatch(self, tmp_path):
        """poll_once_dry() logs candidates but never calls _dispatch or creates worktrees."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issues = [_make_issue("id-1", "PROJ-1", "First issue"), _make_issue("id-2", "PROJ-2", "Second issue")]

        with patch.object(poller.linear, "fetch_team_issues", new_callable=AsyncMock, return_value=issues), \
             patch.object(poller.linear, "close", new_callable=AsyncMock) as mock_close, \
             patch.object(poller, "_dispatch", new_callable=AsyncMock) as mock_dispatch:
            await poller.poll_once_dry()

        mock_dispatch.assert_not_called()
        mock_close.assert_called_once()

    @pytest.mark.asyncio
    async def test_dry_run_returns_issues(self, tmp_path):
        """poll_once_dry() returns the fetched issue list."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issues = [_make_issue("id-1", "PROJ-1", "First issue")]

        with patch.object(poller.linear, "fetch_team_issues", new_callable=AsyncMock, return_value=issues), \
             patch.object(poller.linear, "close", new_callable=AsyncMock):
            result = await poller.poll_once_dry()

        assert result == issues


class TestPollerDispatchLogic:
    @pytest.mark.asyncio
    async def test_dispatch_skips_running_issues(self, tmp_path):
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        # Simulate a running agent
        fake_task = asyncio.create_task(asyncio.sleep(1000))
        from cruise.poller import RunningAgent
        poller.running[issue.id] = RunningAgent(issue=issue, task=fake_task)

        with patch.object(poller, "_dispatch", new_callable=AsyncMock) as mock_dispatch:
            await poller._dispatch_new([issue])
            mock_dispatch.assert_not_called()

        fake_task.cancel()
        try:
            await fake_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_dispatch_skips_retry_issues(self, tmp_path):
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        poller.retries[issue.id] = RetryEntry(
            issue=issue, attempt=2, due_at=time.monotonic() + 1000
        )

        with patch.object(poller, "_dispatch", new_callable=AsyncMock) as mock_dispatch:
            await poller._dispatch_new([issue])
            mock_dispatch.assert_not_called()


class TestPollerCommentPolling:
    @pytest.mark.asyncio
    async def test_poll_comments_queues_new_comments(self, tmp_path):
        """New comments on running issues are added to the comment_queue."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")

        comment_queue: asyncio.Queue[str] = asyncio.Queue()
        fake_task = asyncio.create_task(asyncio.sleep(1000))
        poller.running[issue.id] = RunningAgent(
            issue=issue,
            task=fake_task,
            comment_queue=comment_queue,
            seen_comment_ids=set(),
        )

        new_comment = Comment(id="c1", body="Please refactor this")

        with patch.object(
            poller.linear, "fetch_issue_comments", new_callable=AsyncMock,
            return_value=[new_comment]
        ):
            await poller._poll_comments()

        assert comment_queue.qsize() == 1
        assert comment_queue.get_nowait() == "Please refactor this"
        assert "c1" in poller.running[issue.id].seen_comment_ids

        fake_task.cancel()
        try:
            await fake_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_poll_comments_skips_seen_comments(self, tmp_path):
        """Comments already in seen_comment_ids are not re-queued."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")

        comment_queue: asyncio.Queue[str] = asyncio.Queue()
        fake_task = asyncio.create_task(asyncio.sleep(1000))
        poller.running[issue.id] = RunningAgent(
            issue=issue,
            task=fake_task,
            comment_queue=comment_queue,
            seen_comment_ids={"c1"},  # Already seen
        )

        old_comment = Comment(id="c1", body="Old comment")

        with patch.object(
            poller.linear, "fetch_issue_comments", new_callable=AsyncMock,
            return_value=[old_comment]
        ):
            await poller._poll_comments()

        assert comment_queue.empty()

        fake_task.cancel()
        try:
            await fake_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_poll_comments_skips_bot_comments(self, tmp_path):
        """Bot-authored comments (e.g. workpad updates) are not injected."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")

        comment_queue: asyncio.Queue[str] = asyncio.Queue()
        fake_task = asyncio.create_task(asyncio.sleep(1000))
        poller.running[issue.id] = RunningAgent(
            issue=issue,
            task=fake_task,
            comment_queue=comment_queue,
            seen_comment_ids=set(),
        )

        bot_comment = Comment(id="c-bot", body="## Claude Workpad\n### Plan\n...", is_bot=True)
        human_comment = Comment(id="c-human", body="Please also add tests")

        with patch.object(
            poller.linear, "fetch_issue_comments", new_callable=AsyncMock,
            return_value=[bot_comment, human_comment]
        ):
            await poller._poll_comments()

        # Only the human comment should be queued
        assert comment_queue.qsize() == 1
        assert comment_queue.get_nowait() == "Please also add tests"
        # Bot comment should still be marked as seen (to avoid re-checking)
        assert "c-bot" in poller.running[issue.id].seen_comment_ids

        fake_task.cancel()
        try:
            await fake_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_poll_comments_skips_workpad_from_personal_api_key(self, tmp_path):
        """Workpad comments posted via personal API key (no botActor) are still filtered."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")

        comment_queue: asyncio.Queue[str] = asyncio.Queue()
        fake_task = asyncio.create_task(asyncio.sleep(1000))
        poller.running[issue.id] = RunningAgent(
            issue=issue,
            task=fake_task,
            comment_queue=comment_queue,
            seen_comment_ids=set(),
        )

        # is_bot=False because posted with personal API key via curl
        workpad_comment = Comment(
            id="c-workpad", body="## Claude Workpad\n### Plan\n- [ ] Do stuff", is_bot=False,
        )
        claude_asks = Comment(
            id="c-asks", body="\U0001f916 Claude asks:\n\n**Should I proceed?**", is_bot=False,
        )
        human_comment = Comment(id="c-human", body="Yes go ahead")

        with patch.object(
            poller.linear, "fetch_issue_comments", new_callable=AsyncMock,
            return_value=[workpad_comment, claude_asks, human_comment]
        ):
            await poller._poll_comments()

        assert comment_queue.qsize() == 1
        assert comment_queue.get_nowait() == "Yes go ahead"

        fake_task.cancel()
        try:
            await fake_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_poll_comments_no_running_agents(self, tmp_path):
        """_poll_comments does nothing when no agents are running."""
        config = _make_config(tmp_path)
        poller = Poller(config)

        with patch.object(
            poller.linear, "fetch_issue_comments", new_callable=AsyncMock
        ) as mock_fetch:
            await poller._poll_comments()

        mock_fetch.assert_not_called()


class TestPollerWorktreeCleanup:
    @pytest.mark.asyncio
    async def test_handle_result_cleans_up_on_success(self, tmp_path):
        """Worktree is cleaned up when agent completes successfully."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        from cruise.dispatcher import AgentResult
        result = AgentResult(success=True, num_turns=3)

        with patch.object(poller, "_cleanup_issue", new_callable=AsyncMock) as mock_cleanup, \
             patch.object(poller.linear, "post_comment", new_callable=AsyncMock):
            await poller._handle_result(issue, result, attempt=1)

        mock_cleanup.assert_called_once_with(issue.identifier)

    @pytest.mark.asyncio
    async def test_handle_result_cleans_up_on_max_retries(self, tmp_path):
        """Worktree is cleaned up when max retries are exhausted."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        from cruise.dispatcher import AgentResult
        result = AgentResult(success=False, num_turns=3, error="failed")

        with patch.object(poller, "_cleanup_issue", new_callable=AsyncMock) as mock_cleanup, \
             patch.object(poller.linear, "post_comment", new_callable=AsyncMock):
            # attempt == max_retry_attempts means no more retries
            await poller._handle_result(issue, result, attempt=config.agent.max_retry_attempts)

        mock_cleanup.assert_called_once_with(issue.identifier)

    @pytest.mark.asyncio
    async def test_handle_result_no_cleanup_on_retry(self, tmp_path):
        """Worktree is NOT cleaned up when agent will be retried."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        from cruise.dispatcher import AgentResult
        result = AgentResult(success=False, num_turns=3, error="failed")

        with patch.object(poller, "_cleanup_issue", new_callable=AsyncMock) as mock_cleanup:
            await poller._handle_result(issue, result, attempt=1)

        mock_cleanup.assert_not_called()


class TestPollerFetchIssueImages:
    @pytest.mark.asyncio
    async def test_returns_empty_list_when_no_images(self, tmp_path):
        """_fetch_issue_images returns [] when description has no images and no attachments."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")
        issue.description = "No images here"

        with patch.object(
            poller.linear,
            "fetch_issue_attachments",
            new_callable=AsyncMock,
            return_value=[],
        ):
            result = await poller._fetch_issue_images(issue)

        assert result == []

    @pytest.mark.asyncio
    async def test_collects_images_from_description_markdown(self, tmp_path):
        """Images embedded in description are downloaded and returned as content blocks."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")
        issue.description = "Look: ![screenshot](https://uploads.linear.app/img.png)"

        with (
            patch.object(
                poller.linear,
                "fetch_issue_attachments",
                new_callable=AsyncMock,
                return_value=[],
            ),
            patch.object(
                poller.linear,
                "download_image_as_base64",
                new_callable=AsyncMock,
                return_value=("base64data", "image/png"),
            ),
        ):
            result = await poller._fetch_issue_images(issue)

        assert len(result) == 1
        assert result[0]["type"] == "image"
        assert result[0]["source"]["type"] == "base64"
        assert result[0]["source"]["media_type"] == "image/png"
        assert result[0]["source"]["data"] == "base64data"

    @pytest.mark.asyncio
    async def test_collects_images_from_attachments(self, tmp_path):
        """Image attachments from Linear are downloaded and returned as content blocks."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")
        issue.description = ""

        attachment = IssueAttachment(
            id="att-1",
            url="https://uploads.linear.app/diagram.jpg",
            title="Diagram",
            content_type="image/jpeg",
            source_type="upload",
        )

        with (
            patch.object(
                poller.linear,
                "fetch_issue_attachments",
                new_callable=AsyncMock,
                return_value=[attachment],
            ),
            patch.object(
                poller.linear,
                "download_image_as_base64",
                new_callable=AsyncMock,
                return_value=("jpegdata", "image/jpeg"),
            ),
        ):
            result = await poller._fetch_issue_images(issue)

        assert len(result) == 1
        assert result[0]["source"]["media_type"] == "image/jpeg"

    @pytest.mark.asyncio
    async def test_skips_failed_downloads(self, tmp_path):
        """Images that fail to download are silently skipped."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")
        issue.description = "![img](https://uploads.linear.app/broken.png)"

        with (
            patch.object(
                poller.linear,
                "fetch_issue_attachments",
                new_callable=AsyncMock,
                return_value=[],
            ),
            patch.object(
                poller.linear,
                "download_image_as_base64",
                new_callable=AsyncMock,
                return_value=None,  # download failed
            ),
        ):
            result = await poller._fetch_issue_images(issue)

        assert result == []

    @pytest.mark.asyncio
    async def test_deduplicates_urls(self, tmp_path):
        """The same URL appearing in description and attachments is only downloaded once."""
        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")
        # Same URL in both description and as an attachment
        url = "https://uploads.linear.app/img.png"
        issue.description = f"![img]({url})"

        attachment = IssueAttachment(
            id="att-1", url=url, content_type="image/png"
        )

        download_mock = AsyncMock(return_value=("data", "image/png"))
        with (
            patch.object(
                poller.linear,
                "fetch_issue_attachments",
                new_callable=AsyncMock,
                return_value=[attachment],
            ),
            patch.object(
                poller.linear, "download_image_as_base64", download_mock
            ),
        ):
            result = await poller._fetch_issue_images(issue)

        # Only one content block despite the URL appearing twice
        assert len(result) == 1
        download_mock.assert_called_once_with(url)


class TestRunningAgentEventTracking:
    def test_running_agent_has_last_event_field(self, tmp_path):
        """RunningAgent initialises with last_event=None."""
        issue = _make_issue()
        fake_task = asyncio.get_event_loop().create_future()
        agent = RunningAgent(issue=issue, task=fake_task)
        assert agent.last_event is None



class TestCompletedAgentTracking:
    @pytest.mark.asyncio
    async def test_handle_result_records_completed_agent(self, tmp_path):
        """Successful agent completion is appended to poller.completed."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")

        result = AgentResult(
            success=True,
            num_turns=3,
            cost_usd=0.05,
            duration_ms=5000,
        )

        with patch.object(poller, "_cleanup_issue", new_callable=AsyncMock), \
             patch.object(poller.linear, "post_comment", new_callable=AsyncMock):
            await poller._handle_result(issue, result, attempt=1)

        assert len(poller.completed) == 1
        completed = poller.completed[0]
        assert completed.issue.id == issue.id
        assert completed.cost_usd == 0.05

    @pytest.mark.asyncio
    async def test_handle_result_fetches_current_state(self, tmp_path):
        """Completed agent records the issue's current state, not the stale dispatch-time state."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        # Issue was "Todo" at dispatch time
        issue = _make_issue(state="Todo")

        result = AgentResult(success=True, num_turns=3, cost_usd=0.05)

        # Agent moved it to "Human Review" during its run
        fetched_issue = _make_issue(state="Human Review")

        with patch.object(poller, "_cleanup_issue", new_callable=AsyncMock), \
             patch.object(
                 poller.linear, "fetch_issues_by_ids", new_callable=AsyncMock,
                 return_value=[fetched_issue],
             ):
            await poller._handle_result(issue, result, attempt=1)

        assert len(poller.completed) == 1
        assert poller.completed[0].issue.state == "Human Review"

    @pytest.mark.asyncio
    async def test_handle_result_records_failed_agent(self, tmp_path):
        """Failed agent completion (with retries exhausted) also goes to completed."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue(state="In Progress")

        result = AgentResult(
            success=False,
            num_turns=3,
            error="something went wrong",
            duration_ms=2000,
        )

        # max_retry_attempts=3; passing attempt=3 means retries are exhausted
        with patch.object(poller, "_cleanup_issue", new_callable=AsyncMock), \
             patch.object(poller.linear, "post_comment", new_callable=AsyncMock):
            await poller._handle_result(issue, result, attempt=3)

        assert len(poller.completed) == 1
        completed = poller.completed[0]
        assert completed.issue.id == issue.id
        assert completed.success is False

    @pytest.mark.asyncio
    async def test_completed_list_capped_at_50(self, tmp_path):
        """poller.completed never grows beyond 50 entries."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)

        result = AgentResult(success=True, num_turns=1, duration_ms=100)

        with patch.object(poller, "_cleanup_issue", new_callable=AsyncMock), \
             patch.object(poller.linear, "post_comment", new_callable=AsyncMock):
            for i in range(60):
                issue = _make_issue(id=f"issue-{i}", identifier=f"PROJ-{i}")
                await poller._handle_result(issue, result, attempt=1)

        assert len(poller.completed) == 50


class TestCompletionComment:
    @pytest.mark.asyncio
    async def test_posts_comment_on_success(self, tmp_path):
        """A summary comment is posted to Linear when the agent completes successfully."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        result = AgentResult(
            success=True,
            num_turns=4,
            cost_usd=0.012,
            duration_ms=90000,
            session_id="sess-abc",
        )

        with patch.object(
            poller.linear, "post_comment", new_callable=AsyncMock
        ) as mock_post:
            await poller._handle_result(issue, result, attempt=1)

        mock_post.assert_called_once()
        body = mock_post.call_args[0][1]
        assert "✅" in body
        assert "4" in body  # num_turns

    @pytest.mark.asyncio
    async def test_posts_comment_on_failure(self, tmp_path):
        """A summary comment is posted when retries are exhausted."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        result = AgentResult(
            success=False,
            num_turns=3,
            error="something went wrong",
            duration_ms=20000,
        )

        with patch.object(
            poller.linear, "post_comment", new_callable=AsyncMock
        ) as mock_post:
            # attempt == max_retry_attempts → exhausted
            await poller._handle_result(issue, result, attempt=config.agent.max_retry_attempts)

        mock_post.assert_called_once()
        body = mock_post.call_args[0][1]
        assert "❌" in body
        assert "something went wrong" in body

    @pytest.mark.asyncio
    async def test_posts_comment_when_turn_limit_exhausted(self, tmp_path):
        """A summary comment is posted when max continuations are exhausted."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        # Hit the turn limit
        result = AgentResult(success=True, num_turns=config.agent.max_turns)

        with patch.object(
            poller.linear, "post_comment", new_callable=AsyncMock
        ) as mock_post:
            await poller._handle_result(
                issue, result, attempt=config.agent.max_continuations
            )

        mock_post.assert_called_once()
        body = mock_post.call_args[0][1]
        assert "⚠️" in body

    @pytest.mark.asyncio
    async def test_no_comment_on_intermediate_retry(self, tmp_path):
        """No summary comment is posted when the agent is scheduled for retry."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        result = AgentResult(success=False, num_turns=3, error="transient error")

        with patch.object(
            poller.linear, "post_comment", new_callable=AsyncMock
        ) as mock_post:
            await poller._handle_result(issue, result, attempt=1)

        mock_post.assert_not_called()

    @pytest.mark.asyncio
    async def test_no_comment_on_turn_limit_continuation(self, tmp_path):
        """No summary comment is posted when a turn-limit continuation is scheduled."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        result = AgentResult(success=True, num_turns=config.agent.max_turns)

        with patch.object(
            poller.linear, "post_comment", new_callable=AsyncMock
        ) as mock_post:
            # attempt=1 < max_continuations → schedules continuation, not terminal
            await poller._handle_result(issue, result, attempt=1)

        mock_post.assert_not_called()

    @pytest.mark.asyncio
    async def test_comment_failure_does_not_raise(self, tmp_path):
        """If posting the summary comment fails, the error is swallowed."""
        from cruise.dispatcher import AgentResult

        config = _make_config(tmp_path)
        poller = Poller(config)
        issue = _make_issue()

        result = AgentResult(success=True, num_turns=2)

        with patch.object(
            poller.linear,
            "post_comment",
            new_callable=AsyncMock,
            side_effect=Exception("network error"),
        ):
            # Must not raise
            await poller._handle_result(issue, result, attempt=1)


class TestBuildCompletionComment:
    def test_success_comment(self):
        """Build comment for a successful agent run."""
        from cruise.dispatcher import AgentResult
        from cruise.poller import _build_completion_comment

        result = AgentResult(
            success=True,
            num_turns=5,
            cost_usd=0.0234,
            duration_ms=150000,
            session_id="sess-xyz",
        )
        body = _build_completion_comment(result)

        assert "✅" in body
        assert "5" in body
        assert "$0.0234" in body
        assert "2m 30s" in body
        # Session ID is not relevant per the ticket
        assert "sess-xyz" not in body

    def test_final_message_is_primary_content(self):
        """When a final_message is present, it should be the primary content of the comment."""
        from cruise.dispatcher import AgentResult
        from cruise.poller import _build_completion_comment

        result = AgentResult(
            success=True,
            num_turns=5,
            cost_usd=0.01,
            duration_ms=60000,
            final_message="I've implemented the feature and opened PR #42. All tests pass.",
        )
        body = _build_completion_comment(result)

        assert "I've implemented the feature and opened PR #42. All tests pass." in body

    def test_no_final_message_still_works(self):
        """When no final_message is set, comment is built without it."""
        from cruise.dispatcher import AgentResult
        from cruise.poller import _build_completion_comment

        result = AgentResult(success=True, num_turns=3)
        body = _build_completion_comment(result)

        assert "✅" in body
        assert "3" in body

    def test_failure_comment(self):
        """Build comment for a failed agent run."""
        from cruise.dispatcher import AgentResult
        from cruise.poller import _build_completion_comment

        result = AgentResult(
            success=False,
            num_turns=3,
            error="out of memory",
            duration_ms=30000,
        )
        body = _build_completion_comment(result)

        assert "❌" in body
        assert "out of memory" in body
        assert "3" in body

    def test_turn_limit_comment(self):
        """Build comment for a run stopped due to turn limit exhaustion."""
        from cruise.dispatcher import AgentResult
        from cruise.poller import _build_completion_comment

        result = AgentResult(success=True, num_turns=5)
        body = _build_completion_comment(result, gave_up_on_turns=True)

        assert "⚠️" in body
        assert "turn limit" in body

    def test_duration_formatting(self):
        """Duration is formatted as human-readable string."""
        from cruise.poller import _format_duration

        assert _format_duration(0) == "0s"
        assert _format_duration(45000) == "45s"
        assert _format_duration(60000) == "1m"
        assert _format_duration(90000) == "1m 30s"
        assert _format_duration(3600000) == "60m"
