"""Tests for config loading."""

import os
from pathlib import Path

import pytest
import yaml

from cruise.config import load_config


@pytest.fixture
def config_file(tmp_path):
    """Create a minimal config file and return its path."""

    def _write(data: dict) -> Path:
        path = tmp_path / "config.yaml"
        path.write_text(yaml.dump(data))
        return path

    return _write


def test_load_minimal_config(config_file):
    path = config_file(
        {
            "linear": {"api_key": "test-key", "team_key": "test-slug"},
            "repo": {"path": "/tmp/repo", "workspace_root": "/tmp/workspaces"},
        }
    )
    cfg = load_config(path)
    assert cfg.linear.api_key == "test-key"
    assert cfg.linear.team_key == "test-slug"
    assert cfg.repo.path == Path("/tmp/repo")
    assert cfg.repo.workspace_root == Path("/tmp/workspaces")
    assert cfg.repo.branch_prefix == ""
    assert cfg.polling.interval_seconds == 30
    assert cfg.linear.dispatch_label == ""
    assert cfg.agent.max_concurrent == 3
    assert cfg.agent.model is None
    assert cfg.agent.max_continuations == 10


def test_load_full_config(config_file):
    path = config_file(
        {
            "linear": {
                "api_key": "key-123",
                "team_key": "proj",
                "active_states": ["Todo"],
                "terminal_states": ["Done"],
            },
            "repo": {
                "path": "/code/repo",
                "workspace_root": "/code/ws",
                "branch_prefix": "dev",
            },
            "polling": {"interval_seconds": 10},
            "agent": {
                "max_concurrent": 5,
                "max_turns": 10,
                "stall_timeout_seconds": 300,
                "max_retry_attempts": 2,
                "permission_mode": "acceptEdits",
            },
        }
    )
    cfg = load_config(path)
    assert cfg.linear.active_states == ["Todo"]
    assert cfg.linear.terminal_states == ["Done"]
    assert cfg.repo.branch_prefix == "dev"
    assert cfg.polling.interval_seconds == 10
    assert cfg.agent.max_concurrent == 5
    assert cfg.agent.max_turns == 10
    assert cfg.agent.permission_mode == "acceptEdits"


def test_env_var_resolution(config_file, monkeypatch):
    monkeypatch.setenv("LINEAR_API_KEY", "env-key-value")
    path = config_file(
        {
            "linear": {"api_key": "$LINEAR_API_KEY", "team_key": "slug"},
            "repo": {"path": "/tmp/r", "workspace_root": "/tmp/w"},
        }
    )
    cfg = load_config(path)
    assert cfg.linear.api_key == "env-key-value"


def test_missing_env_var_raises(config_file, monkeypatch):
    monkeypatch.delenv("NONEXISTENT_VAR", raising=False)
    path = config_file(
        {
            "linear": {"api_key": "$NONEXISTENT_VAR", "team_key": "slug"},
            "repo": {"path": "/tmp/r", "workspace_root": "/tmp/w"},
        }
    )
    with pytest.raises(ValueError, match="NONEXISTENT_VAR"):
        load_config(path)


def test_tilde_expansion(config_file):
    path = config_file(
        {
            "linear": {"api_key": "key", "team_key": "slug"},
            "repo": {"path": "~/code/repo", "workspace_root": "~/workspaces"},
        }
    )
    cfg = load_config(path)
    assert str(cfg.repo.path).startswith(os.path.expanduser("~"))
    assert "~" not in str(cfg.repo.path)


def test_missing_config_file():
    with pytest.raises(FileNotFoundError):
        load_config("/nonexistent/config.yaml")


def test_missing_required_fields(config_file):
    path = config_file({"linear": {"api_key": "key"}})
    with pytest.raises(KeyError):
        load_config(path)


def test_load_config_with_model(config_file):
    path = config_file(
        {
            "linear": {"api_key": "key", "team_key": "slug"},
            "repo": {"path": "/tmp/r", "workspace_root": "/tmp/w"},
            "agent": {"model": "us.anthropic.claude-sonnet-4-6"},
        }
    )
    cfg = load_config(path)
    assert cfg.agent.model == "us.anthropic.claude-sonnet-4-6"


def test_load_config_with_dispatch_label(config_file):
    path = config_file(
        {
            "linear": {"api_key": "key", "team_key": "slug", "dispatch_label": "agent"},
            "repo": {"path": "/tmp/r", "workspace_root": "/tmp/w"},
        }
    )
    cfg = load_config(path)
    assert cfg.linear.dispatch_label == "agent"
