"""Linear GraphQL API client."""

import base64
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime

import httpx

LINEAR_API_URL = "https://api.linear.app/graphql"

logger = logging.getLogger(__name__)

# Matches markdown image syntax: ![alt text](url)
_MD_IMAGE_RE = re.compile(r"!\[.*?\]\((https?://[^)\s]+)\)")


@dataclass
class Comment:
    id: str
    body: str
    created_at: datetime | None = None
    parent_id: str | None = None
    is_bot: bool = False


@dataclass
class Issue:
    id: str
    identifier: str
    title: str
    state: str
    description: str = ""
    url: str = ""
    labels: list[str] = field(default_factory=list)
    priority: int | None = None
    created_at: datetime | None = None
    branch_name: str | None = None


@dataclass
class IssueAttachment:
    id: str
    url: str
    title: str = ""
    content_type: str = ""
    source_type: str = ""


def extract_image_urls_from_markdown(text: str) -> list[str]:
    """Return all image URLs found in markdown text (![alt](url) syntax)."""
    return _MD_IMAGE_RE.findall(text)


class LinearClient:
    def __init__(self, api_key: str):
        self._client = httpx.AsyncClient(
            base_url=LINEAR_API_URL,
            headers={
                "Authorization": api_key,
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def close(self):
        await self._client.aclose()

    async def _graphql(self, query: str, variables: dict | None = None) -> dict:
        payload = {"query": query}
        if variables:
            payload["variables"] = variables
        response = await self._client.post("", json=payload)
        response.raise_for_status()
        result = response.json()
        if "errors" in result:
            raise LinearAPIError(result["errors"])
        return result.get("data", {})

    async def fetch_team_issues(
        self, team_key: str, active_states: list[str], dispatch_label: str = ""
    ) -> list[Issue]:
        """Fetch issues in active states for a given team."""
        query = """
        query TeamIssues($key: String!) {
            teams(filter: { key: { eq: $key } }, first: 1) {
                nodes {
                    issues(first: 100) {
                        nodes {
                            id
                            identifier
                            title
                            description
                            url
                            priority
                            createdAt
                            branchName
                            state { name }
                            labels { nodes { name } }
                        }
                    }
                }
            }
        }
        """
        data = await self._graphql(query, {"key": team_key})
        teams = data.get("teams", {}).get("nodes", [])
        if not teams:
            return []

        issues = teams[0].get("issues", {}).get("nodes", [])
        normalized_active = {s.lower().strip() for s in active_states}

        result = []
        for raw in issues:
            state_name = raw.get("state", {}).get("name", "")
            if state_name.lower().strip() not in normalized_active:
                continue
            issue = _parse_issue(raw)
            if dispatch_label and dispatch_label.lower() not in [l.lower() for l in issue.labels]:
                continue
            result.append(issue)

        return result

    async def fetch_issues_by_ids(self, issue_ids: list[str]) -> list[Issue]:
        """Fetch issues by their internal IDs."""
        if not issue_ids:
            return []
        query = """
        query IssuesByIds($ids: [ID!]!) {
            issues(filter: { id: { in: $ids } }, first: 100) {
                nodes {
                    id
                    identifier
                    title
                    description
                    url
                    priority
                    createdAt
                    branchName
                    state { name }
                    labels { nodes { name } }
                }
            }
        }
        """
        data = await self._graphql(query, {"ids": issue_ids})
        nodes = data.get("issues", {}).get("nodes", [])
        return [_parse_issue(raw) for raw in nodes]

    async def fetch_issue_comments(self, issue_id: str) -> list[Comment]:
        """Fetch comments for an issue, ordered by createdAt ascending."""
        query = """
        query IssueComments($id: String!) {
            issue(id: $id) {
                comments(orderBy: createdAt) {
                    nodes {
                        id
                        body
                        createdAt
                        parent { id }
                        botActor { id }
                    }
                }
            }
        }
        """
        data = await self._graphql(query, {"id": issue_id})
        nodes = data.get("issue", {}).get("comments", {}).get("nodes", [])
        return [_parse_comment(raw) for raw in nodes]

    async def fetch_team_states(self, issue_id: str) -> dict[str, str]:
        """Fetch workflow states for an issue's team. Returns {state_name: state_id}."""
        query = """
        query IssueTeamStates($id: String!) {
            issue(id: $id) {
                team {
                    states { nodes { id name } }
                }
            }
        }
        """
        data = await self._graphql(query, {"id": issue_id})
        issue = data.get("issue", {})
        states = issue.get("team", {}).get("states", {}).get("nodes", [])
        return {s["name"]: s["id"] for s in states if "name" in s and "id" in s}

    async def update_issue_state(self, issue_id: str, state_id: str) -> bool:
        """Move an issue to a different workflow state."""
        query = """
        mutation MoveIssue($id: String!, $stateId: String!) {
            issueUpdate(id: $id, input: { stateId: $stateId }) {
                success
            }
        }
        """
        data = await self._graphql(query, {"id": issue_id, "stateId": state_id})
        return data.get("issueUpdate", {}).get("success", False)

    async def post_comment(
        self, issue_id: str, body: str, parent_id: str | None = None
    ) -> str | None:
        """Create a comment on an issue. Returns the comment ID.

        Pass parent_id to post a threaded reply to an existing comment.
        """
        if parent_id:
            query = """
            mutation CreateComment($issueId: String!, $body: String!, $parentId: String!) {
                commentCreate(input: { issueId: $issueId, body: $body, parentId: $parentId }) {
                    success
                    comment { id }
                }
            }
            """
            variables = {"issueId": issue_id, "body": body, "parentId": parent_id}
        else:
            query = """
            mutation CreateComment($issueId: String!, $body: String!) {
                commentCreate(input: { issueId: $issueId, body: $body }) {
                    success
                    comment { id }
                }
            }
            """
            variables = {"issueId": issue_id, "body": body}

        data = await self._graphql(query, variables)
        result = data.get("commentCreate", {})
        if result.get("success"):
            return result.get("comment", {}).get("id")
        return None

    async def update_comment(self, comment_id: str, body: str) -> bool:
        """Update an existing comment."""
        query = """
        mutation UpdateComment($id: String!, $body: String!) {
            commentUpdate(id: $id, input: { body: $body }) {
                success
            }
        }
        """
        data = await self._graphql(query, {"id": comment_id, "body": body})
        return data.get("commentUpdate", {}).get("success", False)

    async def fetch_issue_attachments(self, issue_id: str) -> list[IssueAttachment]:
        """Fetch file attachments for an issue."""
        query = """
        query IssueAttachments($id: String!) {
            issue(id: $id) {
                attachments {
                    nodes {
                        id
                        url
                        title
                        metadata
                        sourceType
                    }
                }
            }
        }
        """
        data = await self._graphql(query, {"id": issue_id})
        nodes = data.get("issue", {}).get("attachments", {}).get("nodes", [])
        return [_parse_attachment(raw) for raw in nodes]

    async def download_image_as_base64(
        self, url: str
    ) -> tuple[str, str] | None:
        """Download an image URL and return (base64_data, media_type).

        Returns None if the download fails or the response is not an image.
        Adds the Authorization header for linear.app URLs.
        """
        headers = {}
        if "linear.app" in url:
            headers["Authorization"] = self._client.headers.get("Authorization", "")
        try:
            async with httpx.AsyncClient(timeout=30.0) as download_client:
                response = await download_client.get(url, headers=headers, follow_redirects=True)
            response.raise_for_status()
            content_type = response.headers.get("Content-Type", "").split(";")[0].strip()
            if not content_type.startswith("image/"):
                logger.debug(f"Skipping non-image URL {url} (content-type: {content_type})")
                return None
            data = base64.b64encode(response.content).decode()
            return data, content_type
        except Exception:
            logger.debug(f"Failed to download image from {url}", exc_info=True)
            return None


class LinearAPIError(Exception):
    def __init__(self, errors: list[dict]):
        self.errors = errors
        messages = [e.get("message", str(e)) for e in errors]
        super().__init__(f"Linear API errors: {'; '.join(messages)}")


def _parse_comment(raw: dict) -> Comment:
    created_at = None
    if raw.get("createdAt"):
        try:
            created_at = datetime.fromisoformat(
                raw["createdAt"].replace("Z", "+00:00")
            )
        except (ValueError, TypeError):
            pass

    parent_id = None
    if raw.get("parent"):
        parent_id = raw["parent"].get("id")

    is_bot = bool(raw.get("botActor"))

    return Comment(
        id=raw["id"],
        body=raw.get("body", ""),
        created_at=created_at,
        parent_id=parent_id,
        is_bot=is_bot,
    )


def _parse_issue(raw: dict) -> Issue:
    labels_raw = raw.get("labels", {}).get("nodes", [])
    labels = [l["name"] for l in labels_raw if "name" in l]

    created_at = None
    if raw.get("createdAt"):
        try:
            created_at = datetime.fromisoformat(
                raw["createdAt"].replace("Z", "+00:00")
            )
        except (ValueError, TypeError):
            pass

    return Issue(
        id=raw["id"],
        identifier=raw["identifier"],
        title=raw["title"],
        state=raw.get("state", {}).get("name", ""),
        description=raw.get("description") or "",
        url=raw.get("url", ""),
        labels=labels,
        priority=raw.get("priority"),
        created_at=created_at,
        branch_name=raw.get("branchName"),
    )


def _parse_attachment(raw: dict) -> IssueAttachment:
    content_type = raw.get("metadata", {}).get("contentType", "") if raw.get("metadata") else ""
    return IssueAttachment(
        id=raw["id"],
        url=raw.get("url", ""),
        title=raw.get("title", ""),
        content_type=content_type,
        source_type=raw.get("sourceType", ""),
    )
