"""Build agent prompts from issue context and a template file."""

import logging
import re
from pathlib import Path

from cruise.linear import Comment, Issue

logger = logging.getLogger(__name__)

CONTINUATION_PROMPT = (
    "Continuation guidance:\n\n"
    "- The previous turn completed normally, but the Linear issue is still in an active state.\n"
    "- This is continuation turn #{turn_number} of {max_turns} for the current agent run.\n"
    "- Resume from the current workspace and workpad state instead of restarting from scratch.\n"
    "- The original task instructions and prior turn context are already present in this session.\n"
    "- Focus on the remaining ticket work and do not end the turn while the issue stays active unless you are truly blocked.\n"
)

ATTEMPT_CONTEXT_TEMPLATE = (
    "Continuation context:\n\n"
    "- This is retry attempt #{attempt} because the ticket is still in an active state.\n"
    "- Resume from the current workspace state instead of restarting from scratch.\n"
    "- Do not repeat already-completed investigation or validation unless needed for new code changes.\n"
    "- Do not end the turn while the issue remains in an active state unless you are blocked "
    "by missing required permissions/secrets.\n"
)

DEFAULT_TEMPLATE = """\
You are working on a Linear ticket `{issue.identifier}`

{attempt_context}

Issue context:
Identifier: {issue.identifier}
Title: {issue.title}
Current status: {issue.state}
Labels: {issue.labels}
URL: {issue.url}

Description:
{issue.description}

Instructions:

1. This is an unattended orchestration session. Never ask a human to perform follow-up actions.
2. Only stop early for a true blocker (missing required auth/permissions/secrets).
3. Work only in the provided repository copy. Do not touch any other path.
4. Use `gh` CLI for GitHub operations (creating PRs, pushing, etc.).
5. Use `curl` with the LINEAR_API_KEY environment variable for Linear API operations.
6. Create a branch, implement the work, commit, push, and open a PR.
"""


def load_template(template_path: Path | None) -> str:
    """Load a prompt template from a file, or return the default."""
    if template_path and template_path.exists():
        return template_path.read_text()
    return DEFAULT_TEMPLATE


def build_prompt(
    issue: Issue,
    template: str,
    attempt: int | None = None,
    comments: list[Comment] | None = None,
) -> str:
    """Render a prompt template with issue context.

    If comments are provided, they are appended to the rendered prompt so the
    agent sees any user steering notes left on the Linear issue before it starts.
    """
    labels_str = ", ".join(issue.labels) if issue.labels else "none"
    description = issue.description if issue.description else "No description provided."

    attempt_context = ""
    if attempt and attempt > 1:
        attempt_context = _replace_placeholders(
            ATTEMPT_CONTEXT_TEMPLATE, {"attempt": str(attempt)}
        )

    replacements = {
        "issue.identifier": issue.identifier,
        "issue.title": issue.title,
        "issue.state": issue.state,
        "issue.labels": labels_str,
        "issue.url": issue.url,
        "issue.description": description,
        "attempt_context": attempt_context,
    }

    prompt = _replace_placeholders(template, replacements)

    if comments:
        lines = ["\n\nUser comments on this issue (read before starting work):"]
        for comment in comments:
            lines.append(f"\n- {comment.body}")
        prompt += "".join(lines)

    return prompt


def build_continuation_prompt(turn_number: int, max_turns: int) -> str:
    """Build a continuation prompt for subsequent turns."""
    return _replace_placeholders(
        CONTINUATION_PROMPT,
        {"turn_number": str(turn_number), "max_turns": str(max_turns)},
    )


def _replace_placeholders(template: str, replacements: dict[str, str]) -> str:
    """Replace {key} placeholders in template. Unknown placeholders are left as-is."""

    def replacer(match: re.Match) -> str:
        key = match.group(1)
        if key in replacements:
            return replacements[key]
        return match.group(0)

    return re.sub(r"\{([^{}]+)\}", replacer, template)
