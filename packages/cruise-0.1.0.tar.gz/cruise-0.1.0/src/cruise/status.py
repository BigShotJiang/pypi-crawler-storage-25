"""Rich-based live status display for the Supervisor polling loop."""

import time
from typing import TYPE_CHECKING

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from cruise.poller import CompletedAgent, Poller, RunningAgent

# How often the live display refreshes (seconds).
REFRESH_INTERVAL = 0.5

_MAX_EVENT_WIDTH = 80


def _fmt_duration(seconds: float) -> str:
    """Format a duration in seconds as a human-readable string like '2m 34s'."""
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    minutes, secs = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m {secs}s"
    hours, mins = divmod(minutes, 60)
    return f"{hours}h {mins}m"


def _fmt_cost(cost_usd: float | None) -> str:
    if cost_usd is None:
        return "-"
    if cost_usd < 0.001:
        return f"${cost_usd:.5f}"
    return f"${cost_usd:.4f}"


def _truncate(text: str, width: int) -> str:
    """Truncate text to width, collapsing newlines to spaces."""
    text = text.replace("\n", " ").strip()
    if len(text) <= width:
        return text
    return text[: width - 1] + "…"


def _build_header(
    poller: "Poller",
    max_concurrent: int,
    next_refresh_in: float,
) -> Panel:
    now = time.monotonic()
    uptime = _fmt_duration(now - poller._started_at)
    running_count = len(poller.running)
    team = poller.config.linear.team_key
    next_refresh = max(0.0, next_refresh_in)

    lines = [
        f"[bold cyan]Agents:[/bold cyan] {running_count}/{max_concurrent}",
        f"[bold cyan]Runtime:[/bold cyan] {uptime}",
        f"[bold cyan]Project:[/bold cyan] {team}",
        f"[bold cyan]Next refresh:[/bold cyan] {next_refresh:.0f}s",
    ]
    return Panel(" | ".join(lines), title="[bold]SUPERVISOR STATUS[/bold]", expand=True)


def _build_running_table(running: dict[str, "RunningAgent"]) -> Table:
    table = Table(show_header=True, header_style="bold", expand=True, box=None)
    table.add_column("ID", style="cyan", no_wrap=True, min_width=8)
    table.add_column("STAGE", no_wrap=True, min_width=10)
    table.add_column("AGE", no_wrap=True, min_width=8)
    table.add_column("EVENT", overflow="fold")

    now = time.monotonic()
    for agent in running.values():
        age = _fmt_duration(now - agent.started_at)
        event_text = _truncate(agent.last_event or "", _MAX_EVENT_WIDTH)
        table.add_row(
            f"● {agent.issue.identifier}",
            agent.issue.state,
            age,
            event_text,
        )

    return table


def _build_done_table(completed: list["CompletedAgent"]) -> Table:
    table = Table(show_header=True, header_style="bold", expand=True, box=None)
    table.add_column("ID", style="cyan", no_wrap=True, min_width=8)
    table.add_column("STAGE", no_wrap=True, min_width=10)
    table.add_column("TIME", no_wrap=True, min_width=8)
    table.add_column("COST", no_wrap=True, min_width=8)

    for entry in reversed(completed):
        duration = _fmt_duration(entry.completed_at - entry.started_at)
        status_style = "green" if entry.success else "red"
        table.add_row(
            f"[{status_style}]{entry.issue.identifier}[/{status_style}]",
            entry.issue.state,
            duration,
            _fmt_cost(entry.cost_usd),
        )

    return table


def _render(poller: "Poller", next_refresh_in: float) -> Layout:
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="running"),
        Layout(name="done"),
    )

    layout["header"].update(
        _build_header(poller, poller.config.agent.max_concurrent, next_refresh_in)
    )

    running_panel = Panel(
        _build_running_table(poller.running),
        title=f"[bold]Running[/bold] ({len(poller.running)})",
        expand=True,
    )
    layout["running"].update(running_panel)

    done_count = len(poller.completed)
    done_panel = Panel(
        _build_done_table(poller.completed),
        title=f"[bold]Done[/bold] ({done_count})",
        expand=True,
    )
    layout["done"].update(done_panel)

    return layout


class StatusDisplay:
    """Live-updating Rich TUI for the Supervisor status view."""

    def __init__(self) -> None:
        self._console = Console()
        self._live = Live(
            console=self._console,
            screen=True,
            auto_refresh=False,
        )
        # Tracks the monotonic time of the last poll cycle completion so we can
        # compute the "next refresh" countdown in the header.
        self._last_poll_at: float = time.monotonic()

    def mark_poll_complete(self) -> None:
        """Called by the poller after each poll cycle to reset the countdown."""
        self._last_poll_at = time.monotonic()

    def update(self, poller: "Poller") -> None:
        """Re-render the display with current poller state."""
        interval = poller.config.polling.interval_seconds
        elapsed_since_poll = time.monotonic() - self._last_poll_at
        next_refresh_in = max(0.0, interval - elapsed_since_poll)
        self._live.update(_render(poller, next_refresh_in), refresh=True)

    def __enter__(self) -> "StatusDisplay":
        self._live.__enter__()
        return self

    def __exit__(self, *args) -> None:
        self._live.__exit__(*args)
