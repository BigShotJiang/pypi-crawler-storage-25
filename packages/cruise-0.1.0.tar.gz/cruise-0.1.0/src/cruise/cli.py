"""CLI entry point for Cruise."""

import argparse
import asyncio
import logging
import signal
import sys
from importlib.metadata import version

from cruise.config import load_config
from cruise.poller import Poller


async def _dry_run(config):
    poller = Poller(config)
    await poller.poll_once_dry()


async def _run(config):
    poller = Poller(config)
    loop = asyncio.get_running_loop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            sig,
            lambda s=sig: (
                logging.info(f"Received {signal.Signals(s).name}, shutting down..."),
                poller.stop(),
            ),
        )

    await poller.run()


async def _run_with_status(config):
    from cruise.status import StatusDisplay

    poller = Poller(config)
    loop = asyncio.get_running_loop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            sig,
            lambda s=sig: (
                logging.info(f"Received {signal.Signals(s).name}, shutting down..."),
                poller.stop(),
            ),
        )

    with StatusDisplay() as display:
        await poller.run(status=display)


def configure_logging(verbose: bool, log_file: str | None) -> None:
    """Configure root logger with optional file output.

    Always sets up a StreamHandler. When log_file is given, also attaches a
    FileHandler so every log record is written to that path in addition to
    stdout/stderr.
    """
    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    logging.basicConfig(level=level, format=fmt, datefmt=datefmt)
    # basicConfig is a no-op when handlers already exist; set level explicitly.
    logging.getLogger().setLevel(level)

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_handler.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
        logging.getLogger().addHandler(file_handler)

    # Suppress noisy HTTP-level logs
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)


def main():
    parser = argparse.ArgumentParser(
        description="Cruise: poll Linear and dispatch Claude Code agents"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"cruise {version('cruise')}",
    )
    parser.add_argument(
        "--config",
        default="config.yaml",
        help="Path to config file (default: config.yaml)",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Poll once, log candidate issues, and exit without dispatching agents",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="Show a live Rich TUI status view instead of plain log output",
    )
    parser.add_argument(
        "--log-file",
        default=None,
        help="Write log output to this file in addition to stdout",
    )
    args = parser.parse_args()

    configure_logging(verbose=args.verbose, log_file=args.log_file)

    try:
        config = load_config(args.config)
    except (FileNotFoundError, ValueError, KeyError) as e:
        logging.error(f"Failed to load config: {e}")
        sys.exit(1)

    if args.dry_run:
        asyncio.run(_dry_run(config))
    elif args.status:
        # Suppress console logging so it doesn't leak into the TUI.
        logging.getLogger().handlers.clear()
        logging.getLogger().addHandler(logging.NullHandler())
        asyncio.run(_run_with_status(config))
    else:
        asyncio.run(_run(config))


if __name__ == "__main__":
    main()
