# Cruise

A Python service that polls Linear for issues and dispatches Claude Code agents to work on them autonomously.

## Project Overview

Cruise monitors a Linear project board. When issues appear in active states (Todo, In Progress), it:
1. Creates an isolated git worktree for the issue
2. Dispatches a Claude Code agent (via the Claude Agent SDK) to work on it
3. The agent implements the ticket, opens a PR, and updates the Linear issue
4. Cruise monitors for stalls, retries, and terminal state transitions

## Tech Stack

- **Python 3.12+** with `uv` for package management
- **claude-agent-sdk** for dispatching Claude Code agents
- **asyncio** for concurrent agent sessions
- **httpx** for Linear API polling
- **PyYAML** for configuration

## Project Structure

```
src/cruise/           # Main package
  cli.py              # Entry point
  poller.py           # Linear polling loop + orchestration
  dispatcher.py       # Agent session management (Agent SDK)
  workspace.py        # Git worktree lifecycle
  linear.py           # Linear GraphQL API client
  prompt.py           # Prompt building from template
config.yaml           # Runtime config (gitignored)
config.example.yaml   # Config template (checked in)
prompt.md             # Workflow prompt template with Liquid-style variables
.claude/skills/       # Skills available to dispatched agents
tests/                # Test suite
```

## Conventions

- Use `httpx.AsyncClient` for all HTTP calls.
- Use `asyncio.Semaphore` for concurrency limits.
- All Linear API interaction goes through `src/cruise/linear.py`.
- All Agent SDK interaction goes through `src/cruise/dispatcher.py`.
- Config is loaded once at startup from `config.yaml` via `src/cruise/config.py`.
- Prompt templates use Python string `.format()` or simple `{variable}` substitution (not Liquid/Jinja — keep it simple).

## Reference Material

The design is inspired by [OpenAI's Symphony](https://github.com/openai/symphony), an Elixir-based orchestrator for Codex. A local copy lives at `~/Desktop/repos/symphony/`.

Key Symphony files to reference:
- `~/Desktop/repos/symphony/SPEC.md` — the formal Symphony specification
- `~/Desktop/repos/symphony/elixir/WORKFLOW.md` — workflow prompt template and config
- `~/Desktop/repos/symphony/.codex/skills/` — Codex skills (ported to `.claude/skills/` here)
- `~/Desktop/repos/symphony/elixir/lib/symphony_elixir/orchestrator.ex` — polling/dispatch logic
- `~/Desktop/repos/symphony/elixir/lib/symphony_elixir/agent_runner.ex` — agent session lifecycle
- `~/Desktop/repos/symphony/elixir/lib/symphony_elixir/codex/app_server.ex` — Codex protocol (replaced by Agent SDK)

## Running

```bash
cd ~/Desktop/repos/cruise
uv run cruise --config config.yaml
```

## Testing

```bash
uv run pytest
```
