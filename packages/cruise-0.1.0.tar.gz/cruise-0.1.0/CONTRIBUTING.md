# Contributing

## Dev Environment Setup

Requirements: Python 3.12+, [uv](https://github.com/astral-sh/uv)

```bash
git clone <repo>
cd cruise
uv sync
cp config.example.yaml config.yaml  # then fill in your API keys
```

## Running Tests

```bash
uv run pytest
```

## Branch Naming

Prefix branches with your name:

```
yourname/short-description
# e.g. aryan/add-retry-logic
```

## Commit Messages

Use the imperative mood in the subject line. Keep it under 72 characters.
Reference the Linear ticket when relevant.

```
Add retry logic for stalled agents

- Detect stall via idle timeout
- Re-queue issue for dispatch

Refs: SUP-12
```
