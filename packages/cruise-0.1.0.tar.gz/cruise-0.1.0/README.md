# Cruise

A Python service that polls [Linear](https://linear.app) for issues and dispatches [Claude Code](https://docs.anthropic.com/claude/docs/claude-code) agents to work on them autonomously.

When an issue enters an active state (e.g. *Todo* or *In Progress*) and carries the configured dispatch label, Cruise:

1. Creates an isolated git worktree for the issue.
2. Launches a Claude Code agent session scoped to that worktree.
3. The agent implements the ticket, opens a pull request, and updates the Linear issue.
4. Cruise monitors for stalls, retries on failure, and cleans up after terminal state transitions.

## Requirements

- Python 3.12+
- [uv](https://github.com/astral-sh/uv) package manager
- A Linear account with a personal API key
- A GitHub repository (the agent uses `gh` CLI to open PRs)
- [Claude Code](https://docs.anthropic.com/claude/docs/claude-code) installed and authenticated

## Installation

```bash
git clone https://github.com/aryanbhasin/cruise.git
cd cruise
uv sync
```

## Configuration

Copy the example config and fill in your values:

```bash
cp config.example.yaml config.yaml
```

Key settings in `config.yaml`:

| Section | Key | Description |
|---|---|---|
| `linear` | `api_key` | Linear personal API key (or set `LINEAR_API_KEY` env var) |
| `linear` | `team_key` | Your Linear team prefix, e.g. `SUP` |
| `linear` | `dispatch_label` | Only issues with this label are dispatched (default: `agent`) |
| `repo` | `path` | Absolute path to your source git repository |
| `repo` | `workspace_root` | Directory where per-issue worktrees are created |
| `agent` | `max_concurrent` | Max simultaneous Claude Code sessions (default: 3) |

See `config.example.yaml` for the full list of options with descriptions.

## Quick Start

```bash
# Dry run: poll once, log candidate issues, do not dispatch any agents
uv run cruise --config config.yaml --dry-run

# Run normally (polls Linear every 30 seconds by default)
uv run cruise --config config.yaml

# Run with a live Rich TUI status view
uv run cruise --config config.yaml --status

# Enable debug logging
uv run cruise --config config.yaml --verbose
```

Cruise runs until interrupted (`Ctrl+C` / `SIGTERM`), at which point it stops accepting new work and waits for in-flight agents to finish.

## How It Works

```
Linear issue → Todo/In Progress + label
        ↓
Cruise creates git worktree
        ↓
Claude Code agent session (isolated worktree)
        ↓
Agent opens PR, updates Linear issue → Human Review
        ↓
Human approves → Merging → land flow → Done
        ↓
Cruise cleans up worktree
```

The agent receives a prompt built from `prompt.md`, which describes the full workflow the agent should follow (status transitions, PR conventions, Linear updates, etc.).

## Development

See [CONTRIBUTING.md](CONTRIBUTING.md) for dev environment setup, running tests, branch naming, and commit message conventions.
