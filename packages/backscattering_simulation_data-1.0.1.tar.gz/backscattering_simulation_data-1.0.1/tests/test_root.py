from tempfile import NamedTemporaryFile
from unittest import TestCase
from urllib.parse import urlparse

from astropy.units import Quantity
from gwpy.frequencyseries import FrequencySeries
from h5py import File
from numpy import complex128
from numpy.random import default_rng

from backscattering_simulation_data.metadata.git import Git
from backscattering_simulation_data.metadata.interferometer import (
    Interferometer,
)
from backscattering_simulation_data.metadata.root import (
    Root as Metadata,
)
from backscattering_simulation_data.metadata.simulation import (
    Simulation,
)
from backscattering_simulation_data.root import Root


class TestRoot(TestCase):
    def test_save(self) -> None:
        rng = default_rng(seed=100)
        n = 1000
        darm = rng.normal(0, 1, size=(n, 2)).view(complex128).reshape(n)

        root = Root(
            metadata=Metadata(
                name="root name",
                maxtem=0,
                git=Git(
                    urlparse("https://example.org"),
                    commit="commit",
                    version="version",
                    branch="main",
                ),
                interferometer=Interferometer(
                    dark_fringe_power=Quantity(1, "W"),
                    injection_power=Quantity(1, "W"),
                    sr_yaw=Quantity(1, "rad"),
                    north_arm=Quantity(1, "m"),
                    west_arm=Quantity(1, "m"),
                ),
                simulation=Simulation(
                    maps=[],
                    model_modifiers=[],
                ),
            ),
            scatterers=[],
            power_measurements=[],
            darm=FrequencySeries(
                data=darm,
                f0=5,
                df=(10000 - 5) / n,
            ),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                root.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_root = Root.from_hdf5(file)

        self.assertEqual(
            len(root.darm),
            len(stored_root.darm),
            "different darm length",
        )
        self.assertEqual(
            root.darm.f0,
            stored_root.darm.f0,
            "different darm f0",
        )
        self.assertEqual(
            root.darm.df,
            stored_root.darm.df,
            "different darm df",
        )
        self.assertLessEqual(
            (root.darm.value - stored_root.darm.value).all(),
            1e-100,
            "different darm",
        )
