from tempfile import NamedTemporaryFile
from unittest import TestCase

from h5py import File

from backscattering_simulation_data.metadata.powermeasurement import (
    PowerMeasurement,
)


class TestMetadataPowerMeasurement(TestCase):
    def test_save(self) -> None:
        power_measurement = PowerMeasurement(
            port="a port",
            name="a name",
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                power_measurement.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_power_measurement = PowerMeasurement.from_hdf5(
                    file,
                )

        self.assertEqual(
            power_measurement.name,
            stored_power_measurement.name,
            "different name",
        )
        self.assertEqual(
            power_measurement.port,
            stored_power_measurement.port,
            "different port",
        )
