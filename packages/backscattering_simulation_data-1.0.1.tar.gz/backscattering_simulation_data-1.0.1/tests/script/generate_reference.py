from pathlib import Path
from urllib.parse import urlparse

from astropy.table import QTable
from astropy.units import Quantity
from gwpy.frequencyseries import FrequencySeries
from h5py import File
from numpy import complex128
from numpy.random import default_rng

from backscattering_simulation_data import (
    PowerMeasurement,
    Root,
    Scatterer,
)
from backscattering_simulation_data.metadata import (
    Git,
    Interferometer,
    Map,
    MapType,
    MetadataPowerMeasurement,
    MetadataRoot,
    MetadataScatterer,
    PointAbsorber,
    Simulation,
)
from backscattering_simulation_data.metadata.modifiers import (
    ElementUpdate,
)

current_directory = Path(__file__).parent

rng = default_rng(seed=100)
n = 1000
kn = rng.normal(0, 1, size=(n, 2)).view(complex128).reshape(n)
kp = rng.normal(0, 1, size=(n, 2)).view(complex128).reshape(n)
darm = rng.normal(0, 1, size=(n, 2)).view(complex128).reshape(n)

root = Root(
    metadata=MetadataRoot(
        name="reference file to catch incompatible change",
        maxtem=3,
        git=Git(
            remote=urlparse("https://example.org"),
            commit="CECI EST UN HASH DE COMMIT",
            version="1.0.0",
            branch="main",
        ),
        interferometer=Interferometer(
            dark_fringe_power=Quantity(18, "W"),
            injection_power=Quantity(6, "mW"),
            sr_yaw=Quantity(6, "urad"),
            north_arm=Quantity(3, "km"),
            west_arm=Quantity(3, "km"),
        ),
        simulation=Simulation(
            maps=[
                Map(
                    mirror="SR",
                    length=Quantity(34, "mm"),
                    resolution=Quantity(0.5, "mm"),
                    points_absorber=[
                        PointAbsorber(
                            x=Quantity(0.1, "mm"),
                            y=Quantity(0.1, "mm"),
                            radius=Quantity(1, "mm"),
                            power=Quantity(20, "mW"),
                        ),
                    ],
                    type_=MapType.CIRCULAR,
                ),
            ],
            model_modifiers=[
                ElementUpdate(
                    element="SR",
                    parameters=QTable(
                        data=[
                            [Quantity(3, "urad")],
                        ],
                        names=[
                            "xbeta",
                        ],
                    ),
                ),
            ],
        ),
    ),
    scatterers=[
        Scatterer(
            metadata=MetadataScatterer(
                name="SDB1",
                reflectivity=Quantity(1e-6, None),
            ),
            kn=FrequencySeries(
                data=kn,
                f0=5,
                df=(10000 - 5) / n,
            ),
            kp=FrequencySeries(
                data=kp,
                f0=5,
                df=(10000 - 5) / n,
            ),
        ),
    ],
    power_measurements=[
        PowerMeasurement(
            metadata=MetadataPowerMeasurement(
                port="SDB1.p1",
                name="B1",
            ),
            modes=QTable(
                data=[
                    [
                        Quantity(6, "mW"),
                        Quantity(0.1, "mW"),
                        Quantity(0.1, "uW"),
                    ],
                    [
                        Quantity(0.1, "mW"),
                        Quantity(0.1, "uW"),
                        Quantity(0, "W"),
                    ],
                    [
                        Quantity(0.1, "uW"),
                        Quantity(0, "W"),
                        Quantity(0, "W"),
                    ],
                ],
                names=[
                    "n=0",
                    "n=1",
                    "n=3",
                ],
            ),
        ),
    ],
    darm=FrequencySeries(
        data=darm,
        f0=5,
        df=(10000 - 5) / n,
    ),
)

with File(
    current_directory.parent / Path("data/reference.hdf5"), "w"
) as file:
    root.to_hdf5(file)
