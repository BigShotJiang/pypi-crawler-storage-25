from tempfile import NamedTemporaryFile
from unittest import TestCase
from urllib.parse import urlparse

from astropy.units import Quantity
from h5py import File

from backscattering_simulation_data.metadata.git import Git
from backscattering_simulation_data.metadata.interferometer import (
    Interferometer,
)
from backscattering_simulation_data.metadata.root import (
    Root,
)
from backscattering_simulation_data.metadata.simulation import (
    Simulation,
)


class TestMetadataRoot(TestCase):
    def test_init(self) -> None:
        with self.assertRaises(ValueError):
            Root(
                name="name",
                maxtem=-1,
                git=Git(
                    remote=urlparse("https://example.org"),
                    commit="COMMIT",
                    version="0.0.1",
                    branch="main",
                ),
                interferometer=Interferometer(
                    dark_fringe_power=Quantity(1, "W"),
                    injection_power=Quantity(1, "W"),
                    sr_yaw=Quantity(0, "rad"),
                    north_arm=Quantity(1, "m"),
                    west_arm=Quantity(1, "m"),
                ),
                simulation=Simulation(
                    maps=[],
                    model_modifiers=[],
                ),
            )

    def test_save(self) -> None:
        root = Root(
            name="name",
            maxtem=3,
            git=Git(
                remote=urlparse("https://example.org"),
                commit="COMMIT",
                version="0.0.1",
                branch="main",
            ),
            interferometer=Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(0, "rad"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(1, "m"),
            ),
            simulation=Simulation(
                maps=[],
                model_modifiers=[],
            ),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                root.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_root = Root.from_hdf5(file)

        self.assertEqual(
            root.name,
            stored_root.name,
            "different name",
        )
        self.assertEqual(
            root.maxtem,
            stored_root.maxtem,
            "different maxtem",
        )
