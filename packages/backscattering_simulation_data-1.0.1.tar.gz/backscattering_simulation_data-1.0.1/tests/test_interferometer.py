from tempfile import NamedTemporaryFile
from unittest import TestCase

from astropy.units import Quantity
from h5py import File
from numpy.random import default_rng

from backscattering_simulation_data.metadata.interferometer import (
    Interferometer,
)


class TestInterferometer(TestCase):
    def test_init(self) -> None:
        with self.assertRaises(TypeError):
            Interferometer(
                dark_fringe_power=Quantity(1, "m"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(1, "m"),
            )
        with self.assertRaises(ValueError):
            Interferometer(
                dark_fringe_power=Quantity(-1, "W"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(1, "m"),
            )
        with self.assertRaises(TypeError):
            Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(1, "m"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(1, "m"),
            )
        with self.assertRaises(ValueError):
            Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(-1, "W"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(1, "m"),
            )
        with self.assertRaises(TypeError):
            Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(1, "m"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(1, "m"),
            )
        with self.assertRaises(TypeError):
            Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(1, "W"),
                west_arm=Quantity(1, "m"),
            )
        with self.assertRaises(ValueError):
            Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(-1, "m"),
                west_arm=Quantity(1, "m"),
            )
        with self.assertRaises(TypeError):
            Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(1, "W"),
            )
        with self.assertRaises(ValueError):
            Interferometer(
                dark_fringe_power=Quantity(1, "W"),
                injection_power=Quantity(1, "W"),
                sr_yaw=Quantity(1, "rad"),
                north_arm=Quantity(1, "m"),
                west_arm=Quantity(-1, "m"),
            )

    def test_save(self) -> None:
        rng = default_rng()
        dark_fringe_power, injection_power = rng.uniform(0, 1, size=2)
        sr_yaw = rng.uniform(-1, 1)
        north_arm, west_arm = rng.uniform(0, 1, size=2)

        interferometer = Interferometer(
            dark_fringe_power=Quantity(dark_fringe_power, "W"),
            injection_power=Quantity(injection_power, "W"),
            sr_yaw=Quantity(sr_yaw, "rad"),
            north_arm=Quantity(north_arm, "m"),
            west_arm=Quantity(west_arm, "m"),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                interferometer.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_interferometer = Interferometer.from_hdf5(file)

        self.assertEqual(
            interferometer.dark_fringe_power,
            stored_interferometer.dark_fringe_power,
            "different dark fringe power",
        )
        self.assertEqual(
            interferometer.injection_power,
            stored_interferometer.injection_power,
            "different injection power",
        )
        self.assertEqual(
            interferometer.sr_yaw,
            stored_interferometer.sr_yaw,
            "different sr yaw",
        )
        self.assertEqual(
            interferometer.north_arm,
            stored_interferometer.north_arm,
            "different north arm",
        )
        self.assertEqual(
            interferometer.west_arm,
            stored_interferometer.west_arm,
            "different west arm",
        )
