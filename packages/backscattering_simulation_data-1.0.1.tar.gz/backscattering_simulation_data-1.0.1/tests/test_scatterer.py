from tempfile import NamedTemporaryFile
from unittest import TestCase

from astropy.units import Quantity
from gwpy.frequencyseries import FrequencySeries
from h5py import File
from numpy import complex128
from numpy.random import default_rng

from backscattering_simulation_data.metadata.scatterer import (
    Scatterer as Metadata,
)
from backscattering_simulation_data.scatterer import Scatterer


class TestScatterer(TestCase):
    def test_save(self) -> None:
        rng = default_rng(seed=100)
        n = 1000
        kn = rng.normal(0, 1, size=(n, 2)).view(complex128).reshape(n)
        kp = rng.normal(0, 1, size=(n, 2)).view(complex128).reshape(n)

        scatterer = Scatterer(
            metadata=Metadata(
                name="a name",
                reflectivity=Quantity(0.5, None),
            ),
            kn=FrequencySeries(kn, f0=5, df=(10000 - 5) / n),
            kp=FrequencySeries(kp, f0=5, df=(10000 - 5) / n),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                scatterer.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_scatterer = Scatterer.from_hdf5(file)

        self.assertEqual(
            len(scatterer.kn),
            len(stored_scatterer.kn),
            "different kn length",
        )
        self.assertEqual(
            scatterer.kn.f0,
            stored_scatterer.kn.f0,
            "different kn f0",
        )
        self.assertEqual(
            scatterer.kn.df,
            stored_scatterer.kn.df,
            "different kn df",
        )
        self.assertLessEqual(
            (scatterer.kn.value - stored_scatterer.kn.value).all(),
            1e-100,
            "different kn",
        )
        self.assertEqual(
            len(scatterer.kp),
            len(stored_scatterer.kp),
            "different kp length",
        )
        self.assertEqual(
            scatterer.kp.f0,
            stored_scatterer.kp.f0,
            "different kp f0",
        )
        self.assertEqual(
            scatterer.kp.df,
            stored_scatterer.kp.df,
            "different kp df",
        )
        self.assertLessEqual(
            (scatterer.kp.value - stored_scatterer.kp.value).all(),
            1e-100,
            "different kp",
        )
