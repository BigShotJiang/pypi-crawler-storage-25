from tempfile import NamedTemporaryFile
from unittest import TestCase

from astropy.table import QTable
from astropy.units import Quantity
from h5py import File

from backscattering_simulation_data.metadata.powermeasurement import (
    PowerMeasurement as Metadata,
)
from backscattering_simulation_data.powermeasurement import (
    PowerMeasurement,
)


class TestPowerMeasurement(TestCase):
    def test_save(self) -> None:
        power_measurement = PowerMeasurement(
            metadata=Metadata(port="port", name="name"),
            modes=QTable(
                data=[
                    Quantity([1, 0.5], "W"),
                    Quantity([0.5, 0], "W"),
                ],
                names=["n=0", "n=1"],
            ),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                power_measurement.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_power_measurement = PowerMeasurement.from_hdf5(
                    file,
                )

        for col_name in power_measurement.modes.colnames:
            for index in range(len(power_measurement.modes)):
                self.assertLessEqual(
                    (
                        power_measurement.modes[col_name][index]
                        - stored_power_measurement.modes[col_name][
                            index
                        ]
                    ),
                    Quantity(1e-100, "W"),
                    "different power on modes",
                )
