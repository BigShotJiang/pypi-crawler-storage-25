from tempfile import NamedTemporaryFile
from unittest import TestCase

from astropy.units import Quantity
from h5py import File
from numpy.random import default_rng

from backscattering_simulation_data.metadata.pointabsorber import (
    PointAbsorber,
)


class TestPointAbsorber(TestCase):
    def test_init(self) -> None:
        with self.assertRaises(TypeError):
            PointAbsorber(
                x=Quantity(1, "W"),
                y=Quantity(1, "m"),
                radius=Quantity(1, "m"),
                power=Quantity(1, "W"),
            )
        with self.assertRaises(TypeError):
            PointAbsorber(
                x=Quantity(1, "m"),
                y=Quantity(1, "W"),
                radius=Quantity(1, "m"),
                power=Quantity(1, "W"),
            )
        with self.assertRaises(TypeError):
            PointAbsorber(
                x=Quantity(1, "m"),
                y=Quantity(1, "m"),
                radius=Quantity(1, "W"),
                power=Quantity(1, "W"),
            )
        with self.assertRaises(ValueError):
            PointAbsorber(
                x=Quantity(1, "m"),
                y=Quantity(1, "m"),
                radius=Quantity(-1, "m"),
                power=Quantity(1, "W"),
            )
        with self.assertRaises(TypeError):
            PointAbsorber(
                x=Quantity(1, "m"),
                y=Quantity(1, "m"),
                radius=Quantity(1, "m"),
                power=Quantity(1, "m"),
            )
        with self.assertRaises(ValueError):
            PointAbsorber(
                x=Quantity(1, "m"),
                y=Quantity(1, "m"),
                radius=Quantity(1, "m"),
                power=Quantity(-1, "W"),
            )

    def test_save(self) -> None:
        rng = default_rng(seed=100)
        x, y = rng.uniform(-1, 1, size=2)
        radius = rng.uniform(0, 1)
        power = rng.uniform(0, 1)

        point_absorber = PointAbsorber(
            x=Quantity(x, "m"),
            y=Quantity(y, "m"),
            radius=Quantity(radius, "m"),
            power=Quantity(power, "W"),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                point_absorber.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_point_absorber = PointAbsorber.from_hdf5(file)

        self.assertEqual(
            point_absorber.x,
            stored_point_absorber.x,
            "different x",
        )
        self.assertEqual(
            point_absorber.y,
            stored_point_absorber.y,
            "different y",
        )
        self.assertEqual(
            point_absorber.radius,
            stored_point_absorber.radius,
            "different radius",
        )
        self.assertEqual(
            point_absorber.power,
            stored_point_absorber.power,
            "different power",
        )
