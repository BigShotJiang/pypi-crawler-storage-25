from tempfile import NamedTemporaryFile
from unittest import TestCase

from h5py import File

from backscattering_simulation_data.metadata.simulation import (
    Simulation,
)


class TestSimulation(TestCase):
    def test_save(self) -> None:
        simulation = Simulation(
            maps=[],
            model_modifiers=[],
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                simulation.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_simulation = Simulation.from_hdf5(file)

        self.assertEqual(
            simulation.maps,
            stored_simulation.maps,
            "different maps",
        )
        self.assertEqual(
            simulation.model_modifiers,
            stored_simulation.model_modifiers,
            "different model modifiers",
        )
