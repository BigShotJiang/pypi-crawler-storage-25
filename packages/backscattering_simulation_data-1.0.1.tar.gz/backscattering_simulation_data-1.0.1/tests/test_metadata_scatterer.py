from tempfile import NamedTemporaryFile
from unittest import TestCase

from astropy.units import Quantity
from h5py import File
from numpy.random import default_rng

from backscattering_simulation_data.metadata.scatterer import Scatterer


class TestMetadataScatterer(TestCase):
    def test_init(self) -> None:
        with self.assertRaises(TypeError):
            Scatterer(
                name="test",
                reflectivity=Quantity(1, "m"),
            )
        with self.assertRaises(ValueError):
            Scatterer(name="test", reflectivity=Quantity(-1))
        with self.assertRaises(ValueError):
            Scatterer(name="test", reflectivity=Quantity(2))

    def test_save(self) -> None:
        rng = default_rng(seed=100)
        reflectivity = rng.uniform(0, 1)

        scatterer = Scatterer(
            name="test",
            reflectivity=Quantity(reflectivity),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                scatterer.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_scatterer = Scatterer.from_hdf5(file)

        self.assertEqual(
            scatterer.name,
            stored_scatterer.name,
            "different name",
        )
        self.assertEqual(
            scatterer.reflectivity,
            stored_scatterer.reflectivity,
            "different reflectivity",
        )
