from tempfile import NamedTemporaryFile
from unittest import TestCase

from astropy.units import Quantity
from h5py import File
from numpy.random import default_rng

from backscattering_simulation_data.metadata.map import Map, MapType


class TestMap(TestCase):
    def test_init(self) -> None:
        with self.assertRaises(TypeError):
            Map(
                mirror="SR",
                length=Quantity(1, "W"),
                resolution=Quantity(1, "m"),
                points_absorber=[],
                type_=MapType.CIRCULAR,
            )
        with self.assertRaises(ValueError):
            Map(
                mirror="SR",
                length=Quantity(-1, "m"),
                resolution=Quantity(1, "m"),
                points_absorber=[],
                type_=MapType.CIRCULAR,
            )
        with self.assertRaises(TypeError):
            Map(
                mirror="SR",
                length=Quantity(1, "m"),
                resolution=Quantity(1, "W"),
                points_absorber=[],
                type_=MapType.CIRCULAR,
            )
        with self.assertRaises(ValueError):
            Map(
                mirror="SR",
                length=Quantity(1, "m"),
                resolution=Quantity(-1, "m"),
                points_absorber=[],
                type_=MapType.CIRCULAR,
            )
        with self.assertRaises(ValueError):
            # resolution higher than length
            Map(
                mirror="SR",
                length=Quantity(0.1, "m"),
                resolution=Quantity(1, "m"),
                points_absorber=[],
                type_=MapType.CIRCULAR,
            )

    def test_save(self) -> None:
        rng = default_rng(seed=100)
        length = rng.uniform(0.1, 1)
        resolution = length / 100

        map_ = Map(
            mirror="SR",
            length=Quantity(length, "m"),
            resolution=Quantity(resolution, "m"),
            points_absorber=[],
            type_=MapType.FREE,
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                map_.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_map = Map.from_hdf5(file)

        self.assertEqual(
            map_.mirror,
            stored_map.mirror,
            "different mirror",
        )
        self.assertEqual(
            map_.length,
            stored_map.length,
            "different length",
        )
        self.assertEqual(
            map_.resolution,
            stored_map.resolution,
            "different resolution",
        )
        self.assertEqual(
            map_.points_absorber,
            stored_map.points_absorber,
            "different point absorbers",
        )
        self.assertEqual(map_.type, stored_map.type, "different type")
