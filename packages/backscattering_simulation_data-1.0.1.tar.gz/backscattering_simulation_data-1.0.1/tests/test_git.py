from tempfile import NamedTemporaryFile
from unittest import TestCase
from urllib.parse import urlparse

from h5py import File

from backscattering_simulation_data.metadata.git import Git


class TestGit(TestCase):
    def test_save(self) -> None:
        git = Git(
            remote=urlparse("https://example.org"),
            commit="COMMIT HASH",
            version="1.0.0",
            branch="development",
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                git.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_git = Git.from_hdf5(file)

        self.assertEqual(
            git.remote,
            stored_git.remote,
            "different remote",
        )
        self.assertEqual(
            git.commit,
            stored_git.commit,
            "different commit",
        )
        self.assertEqual(
            git.version,
            stored_git.version,
            "different version",
        )
        self.assertEqual(
            git.branch,
            stored_git.branch,
            "different branch",
        )
