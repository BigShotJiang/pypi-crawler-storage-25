from tempfile import NamedTemporaryFile
from unittest import TestCase

from astropy.table import QTable
from astropy.units import Quantity
from h5py import File

from backscattering_simulation_data.metadata.modifiers.update import (
    ElementUpdate,
)


class TestElementUpdate(TestCase):
    def test_save(self) -> None:
        element_update = ElementUpdate(
            element="an element",
            parameters=QTable(
                data=[
                    [Quantity(0.9, None)],
                    [Quantity(0.1, None)],
                    [Quantity(2.0, "urad")],
                ],
                names=["T", "R", "xbeta"],
            ),
        )

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                element_update.to_hdf5(file)

            with File(temp_file, "r") as file:
                stored_element_update = ElementUpdate.from_hdf5(file)

        self.assertEqual(
            element_update.element,
            stored_element_update.element,
            "different element",
        )
        self.assertEqual(
            element_update.parameters,
            stored_element_update.parameters,
            "different parameters",
        )
