from pathlib import Path
from tempfile import NamedTemporaryFile
from unittest import TestCase

from h5py import Dataset, File, Group
from numpy import array_equal

from backscattering_simulation_data import (
    Root,
)

current_dir = Path(__file__).parent


def compare_attrs(
    element_1: Group | Dataset,
    element_2: Group | Dataset,
) -> None:
    """
    Compare the attributes of two Group or Dataset
    """
    for key in set(element_1.attrs.keys()) | set(
        element_2.attrs.keys()
    ):
        if key not in element_1.attrs:
            raise ValueError(f"attribute {key} not found in element_1")
        if key not in element_2.attrs:
            raise ValueError(f"attribute {key} not found in element_2")
        if element_1.attrs[key] != element_2.attrs[key]:
            raise ValueError(f"attr {key} are different in both group")


def compare_hdf5(file_1: Group, file_2: Group) -> None:
    """
    Compare two HDF5 files and print differences.
    """
    compare_attrs(file_1, file_2)
    for key in set(file_1.keys()) | set(file_2.keys()):
        if key not in file_1:
            raise ValueError(f"{key} not found in file_1")
        if key not in file_2:
            raise ValueError(f"{key} not found in file_2")
        element_1, element_2 = file_1.get(key), file_2.get(key)
        if element_1 is element_2.__class__:
            raise TypeError(
                f"{key} is type {type(element_1)}, ",
                f"{key} is type {type(element_2)}",
            )
        if isinstance(element_1, Group) and isinstance(
            element_2, Group
        ):
            compare_hdf5(element_1, element_2)
            continue
        if isinstance(
            element_1,
            Dataset,
        ) and isinstance(
            element_2,
            Dataset,
        ):
            compare_attrs(element_1, element_2)
            if element_1.shape != element_2.shape:
                raise ValueError(
                    f"{key} element do not have the same length"
                )
            if not array_equal(element_1, element_2):
                raise ValueError(f"{key} elements have different value")
            continue
        raise TypeError(

                f"element 1: {type(element_1)}, element_2:"
                f"{type(element_2)} for key {key}"

        )


class TestLegacy(TestCase):
    """
    Check old version support
    """

    def test_load(self) -> None:
        """
        Does the reference file load ?
        """
        with File(current_dir / Path("data/reference.hdf5")) as file:
            reference = Root.from_hdf5(file)

        with NamedTemporaryFile() as temp_file:
            with File(temp_file, "w") as file:
                reference.to_hdf5(file)

            with (
                File(
                    current_dir / Path("data/reference.hdf5"),
                    "r",
                ) as file_1,
                File(
                    temp_file,
                    "r",
                ) as file_2,
            ):
                compare_hdf5(
                    file_1,
                    file_2,
                )
