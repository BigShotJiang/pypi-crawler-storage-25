# Reference

## UML

```mermaid
classDiagram
    class Section {
        to_hdf5(store: h5py.Group) None
        from_hdf5(store: h5py.Group) Section$
    }
    class Metadata {
    }
    class Root {
        metadata: RootMetadata
        scatterers: list[Scatterer]
        power_measurements: list[PowerMeasurement]
        darm: gwpy.frequencyseries.FrequencySeries
    }
    class RootMetadata {
    name: str
    maxtem: int
    git: Git
    interferometer: Interferometer
    simulation: Simulation
    }
    class Git {
    remote: urllib.parse.ParseResult
    commit: str
    version: str
    branch: str
    }
    class Interferometer {
        dark_fringe_power: Quantity[power]
        injection_power: Quantity[power]
        sr_yaw: Quantity[angle]
        north_arm: Quantity[length]
        west_arm: Quantity[length]
    }
    class Simulation {
        maps: list[Map]
        model_modifiers: list[ModelModifier]
    }
    class Map {
        mirror: str
        length: Quantity[length]
        resolution: Quantity[length]
        points_absorber: list[PointAbsorber]
        roc_offset: Quantity[length]
        type: MapType
    }
    class MapType {
        CIRCULAR = "circular"
        FREE = "free"
    }
    <<Enumeration>> MapType
    class PointAbsorber {
        x: Quantity[length]
        y: Quantity[length]
        radius: Quantity[length]
        power: Quantity[power]
    }
    class ModelModifier {
    }
    class ElementUpdate {
        element: str
        parameters: astropy.table.QTable
    }
    class Scatterer {
        metadata: ScattererMetadata
        kn: gwpy.frequencyseries.FrequencySeries
        kp: gwpy.frequencyseries.FrequencySeries
    }
    class ScattererMetadata {
        name: str
        reflectivity: Quantity[dimensionless]
    }
    class PowerMeasurement {
        metadata: PowerMeasurementMetadata
        modes: astropy.table.QTable
    }
        class PowerMeasurementMetadata {
        name: str
        port: str
    }

    Section <|-- Root
    Section <|-- Scatterer
    Section <|-- PowerMeasurement

    Section <|-- Metadata
    Metadata <|-- RootMetadata
    Metadata <|-- Git
    Metadata <|-- Interferometer
    Metadata <|-- Simulation
    Metadata <|-- Map
    Metadata <|-- PointAbsorber
    Metadata <|-- ModelModifier
    Metadata <|-- ScattererMetadata
    Metadata <|-- PowerMeasurementMetadata

    Root *--> RootMetadata
    Root *--> "0..*" Scatterer
    Root *--> "0..*" PowerMeasurement

    RootMetadata *--> Git
    RootMetadata *--> Interferometer
    RootMetadata *--> Simulation

    Simulation *--> "0..*" Map
    Simulation *--> "0..*" ModelModifier

    Map *--> MapType
    Map *--> "0..*" PointAbsorber

    ModelModifier <|-- ElementUpdate

    Scatterer *--> ScattererMetadata

    PowerMeasurement *--> PowerMeasurementMetadata
```
