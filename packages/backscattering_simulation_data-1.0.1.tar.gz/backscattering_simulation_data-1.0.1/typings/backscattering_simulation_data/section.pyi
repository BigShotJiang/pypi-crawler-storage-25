from pathlib import Path

from astropy.table import QTable as QTable
from astropy.units import Quantity as Quantity
from gwpy.frequencyseries import FrequencySeries as FrequencySeries
from h5py import File as File
from h5py import Group as Group

class Section:
    def get(
        self, attribute: str
    ) -> Section | FrequencySeries | QTable | Quantity | int: ...
    def set(
        self,
        attribute: str,
        value: Section | FrequencySeries | QTable | Quantity | int,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Section: ...
    @staticmethod
    def from_folder(folder: Path) -> Section: ...
    def to_hdf5(self, store: File | Group) -> Group | File: ...
