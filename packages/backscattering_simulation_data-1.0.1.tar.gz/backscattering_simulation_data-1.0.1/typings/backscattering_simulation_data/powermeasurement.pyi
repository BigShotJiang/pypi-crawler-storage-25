from _typeshed import Incomplete
from astropy.table import QTable
from h5py import File as File
from h5py import Group as Group

from .metadata import MetadataPowerMeasurement as Metadata
from .section import Section as Section

class PowerMeasurement(Section):
    metadata: Incomplete
    modes: Incomplete
    def __init__(self, metadata: Metadata, modes: QTable) -> None: ...
    @staticmethod
    def from_hdf5(store: Group | File) -> PowerMeasurement: ...
    def to_hdf5(self, store: File | Group) -> Group | File: ...
