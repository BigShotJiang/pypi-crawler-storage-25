from enum import StrEnum

from _typeshed import Incomplete
from astropy.units import Quantity
from h5py import File as File
from h5py import Group

from .metadata import Metadata as Metadata
from .pointabsorber import PointAbsorber as PointAbsorber

class MapType(StrEnum):
    FREE = "free"
    CIRCULAR = "circular"

class Map(Metadata):
    mirror: Incomplete
    length: Incomplete
    resolution: Incomplete
    points_absorber: Incomplete
    type: Incomplete
    def __init__(
        self,
        mirror: str,
        length: Quantity,
        resolution: Quantity,
        points_absorber: list[PointAbsorber],
        type_: MapType,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Map: ...
    def to_hdf5(self, store: Group | File) -> Group | File: ...
