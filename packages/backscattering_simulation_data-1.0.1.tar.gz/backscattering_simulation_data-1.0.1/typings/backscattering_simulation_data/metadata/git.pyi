from urllib.parse import ParseResult as ParseResult

from _typeshed import Incomplete
from h5py import File as File
from h5py import Group as Group

from .metadata import Metadata as Metadata

class Git(Metadata):
    remote: Incomplete
    commit: Incomplete
    version: Incomplete
    branch: Incomplete
    def __init__(
        self,
        remote: ParseResult,
        commit: str,
        version: str,
        branch: str,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Git: ...
    def to_hdf5(self, store: File | Group) -> File | Group: ...
