from h5py import Group as Group

from .metadata import Metadata as Metadata

class ModelModifier(Metadata):
    @staticmethod
    def from_hdf5(store: Group) -> ModelModifier: ...
    def to_hdf5(self, store: Group) -> Group: ...
