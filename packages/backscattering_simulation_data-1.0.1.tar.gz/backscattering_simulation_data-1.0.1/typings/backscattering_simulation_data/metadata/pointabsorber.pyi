from _typeshed import Incomplete
from astropy.units import Quantity
from h5py import File as File
from h5py import Group as Group

from .metadata import Metadata as Metadata

class PointAbsorber(Metadata):
    x: Incomplete
    y: Incomplete
    radius: Incomplete
    power: Incomplete
    def __init__(
        self,
        x: Quantity,
        y: Quantity,
        radius: Quantity,
        power: Quantity,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> PointAbsorber: ...
    def to_hdf5(self, store: File | Group) -> Group | File: ...
