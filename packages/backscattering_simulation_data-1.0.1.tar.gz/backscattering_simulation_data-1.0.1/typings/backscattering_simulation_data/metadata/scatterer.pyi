from _typeshed import Incomplete
from astropy.units import Quantity
from astropy.units.physical import dimensionless as dimensionless
from h5py import File as File
from h5py import Group as Group

from .metadata import Metadata as Metadata

class Scatterer(Metadata):
    name: Incomplete
    reflectivity: Incomplete
    def __init__(
        self, name: str, reflectivity: Quantity[dimensionless]
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Scatterer: ...
    def to_hdf5(self, store: File | Group) -> File | Group: ...
