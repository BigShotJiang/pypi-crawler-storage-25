from _typeshed import Incomplete
from h5py import File as File
from h5py import Group

from .map import Map as Map
from .metadata import Metadata as Metadata
from .modelmodifier import ModelModifier as ModelModifier

class Simulation(Metadata):
    maps: Incomplete
    model_modifiers: Incomplete
    def __init__(
        self, maps: list[Map], model_modifiers: list[ModelModifier]
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Simulation: ...
    def to_hdf5(self, store: File | Group) -> File | Group: ...
