from _typeshed import Incomplete
from astropy.units import Quantity
from astropy.units.physical import (
    angle as angle,
)
from astropy.units.physical import (
    length as length,
)
from astropy.units.physical import (
    power as power,
)
from h5py import File as File
from h5py import Group as Group

from .metadata import Metadata as Metadata

class Interferometer(Metadata):
    dark_fringe_power: Incomplete
    injection_power: Incomplete
    sr_yaw: Incomplete
    north_arm: Incomplete
    west_arm: Incomplete
    def __init__(
        self,
        dark_fringe_power: Quantity[power],
        injection_power: Quantity[power],
        sr_yaw: Quantity[angle],
        north_arm: Quantity[length],
        west_arm: Quantity[length],
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Interferometer: ...
    def to_hdf5(self, store: File | Group) -> File | Group: ...
