from _typeshed import Incomplete
from h5py import File as File
from h5py import Group

from .git import Git as Git
from .interferometer import Interferometer as Interferometer
from .metadata import Metadata as Metadata
from .simulation import Simulation as Simulation

class Root(Metadata):
    name: Incomplete
    maxtem: Incomplete
    git: Incomplete
    interferometer: Incomplete
    simulation: Incomplete
    def __init__(
        self,
        name: str,
        maxtem: int,
        git: Git,
        interferometer: Interferometer,
        simulation: Simulation,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Root: ...
    def to_hdf5(self, store: File | Group) -> Group | File: ...
