from _typeshed import Incomplete
from astropy.table import QTable
from h5py import Group as Group

from ..elementtype import ElementType as ElementType
from ..modelmodifier import ModelModifier as ModelModifier
from .deletion import ElementDeletion as ElementDeletion

class ElementAddition(ModelModifier):
    requirements: Incomplete
    port: Incomplete
    element: Incomplete
    element_type: Incomplete
    parameters: Incomplete
    def __init__(
        self,
        requirements: list[ElementAddition | ElementDeletion],
        port: str,
        element: str,
        element_type: ElementType,
        parameters: QTable,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: Group) -> ElementAddition: ...
    def to_hdf5(self, store: Group) -> Group: ...
