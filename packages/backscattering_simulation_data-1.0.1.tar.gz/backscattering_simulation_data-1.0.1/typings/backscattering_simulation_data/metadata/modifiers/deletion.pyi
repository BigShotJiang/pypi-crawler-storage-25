from _typeshed import Incomplete
from h5py import Group as Group

from ..modelmodifier import ModelModifier as ModelModifier

class ElementDeletion(ModelModifier):
    element: Incomplete
    def __init__(self, element: str) -> None: ...
    @staticmethod
    def from_hdf5(store: Group) -> ElementDeletion: ...
    def to_hdf5(self, store: Group) -> Group: ...
