from _typeshed import Incomplete
from astropy.table import QTable
from h5py import Group as Group

from ..modelmodifier import ModelModifier as ModelModifier

class ElementUpdate(ModelModifier):
    element: Incomplete
    parameters: Incomplete
    def __init__(self, element: str, parameters: QTable) -> None: ...
    @staticmethod
    def from_hdf5(store: Group) -> ElementUpdate: ...
    def to_hdf5(self, store: Group) -> Group: ...
