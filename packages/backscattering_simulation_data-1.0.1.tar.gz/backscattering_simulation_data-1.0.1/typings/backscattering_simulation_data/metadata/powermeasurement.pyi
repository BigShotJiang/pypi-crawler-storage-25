from _typeshed import Incomplete
from h5py import File as File
from h5py import Group as Group

from .metadata import Metadata as Metadata

class PowerMeasurement(Metadata):
    port: Incomplete
    name: Incomplete
    def __init__(self, port: str, name: str) -> None: ...
    @staticmethod
    def from_hdf5(store: Group | File) -> PowerMeasurement: ...
    def to_hdf5(self, store: File | Group) -> Group | File: ...
