from gwpy.frequencyseries import FrequencySeries
from h5py import Dataset as Dataset
from h5py import File as File
from h5py import Group as Group

def dataset_to_frequencyseries(dataset: Dataset) -> FrequencySeries: ...
def frequencyseries_to_dataset(
    store: File | Group, name: str, frequencyseries: FrequencySeries
) -> Dataset: ...
