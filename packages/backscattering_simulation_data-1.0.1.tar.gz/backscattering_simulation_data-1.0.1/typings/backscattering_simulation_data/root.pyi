from pathlib import Path

from _typeshed import Incomplete
from gwpy.frequencyseries import FrequencySeries as FrequencySeries
from h5py import File as File
from h5py import Group
from numpy.typing import NDArray as NDArray

from .metadata.root import Root as Metadata
from .powermeasurement import PowerMeasurement as PowerMeasurement
from .scatterer import Scatterer as Scatterer
from .section import Section as Section
from .utils import (
    dataset_to_frequencyseries as dataset_to_frequencyseries,
)
from .utils import (
    frequencyseries_to_dataset as frequencyseries_to_dataset,
)

class Root(Section):
    metadata: Incomplete
    scatterers: Incomplete
    power_measurements: Incomplete
    darm: Incomplete
    def __init__(
        self,
        metadata: Metadata,
        scatterers: list[Scatterer],
        power_measurements: list[PowerMeasurement],
        darm: FrequencySeries,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Root: ...
    def to_hdf5(self, store: File | Group) -> File | Group: ...
    def to_matlab(self, path: Path) -> None: ...
