from _typeshed import Incomplete
from gwpy.frequencyseries import FrequencySeries as FrequencySeries
from h5py import File as File
from h5py import Group as Group

from .metadata.scatterer import Scatterer as MetadataScatterer
from .section import Section as Section
from .utils import (
    dataset_to_frequencyseries as dataset_to_frequencyseries,
)
from .utils import (
    frequencyseries_to_dataset as frequencyseries_to_dataset,
)

class Scatterer(Section):
    metadata: Incomplete
    kn: Incomplete
    kp: Incomplete
    def __init__(
        self,
        metadata: MetadataScatterer,
        kn: FrequencySeries,
        kp: FrequencySeries,
    ) -> None: ...
    @staticmethod
    def from_hdf5(store: File | Group) -> Scatterer: ...
    def to_hdf5(self, store: File | Group) -> Group | File: ...
