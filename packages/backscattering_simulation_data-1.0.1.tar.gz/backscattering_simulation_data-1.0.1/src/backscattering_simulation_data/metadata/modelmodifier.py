from h5py import Group

from .metadata import Metadata


class ModelModifier(Metadata):
    """Information about a modification of the finesse model"""

    @staticmethod
    def from_hdf5(store: Group) -> "ModelModifier":
        if "type" not in store.attrs:
            raise ValueError("no type in model modifier metadata")

        type_ = store.attrs["type"]

        if not isinstance(type_, str):
            raise TypeError("type must be a string")

        if type_ == "addition":
            from .modifiers import ElementAddition

            return ElementAddition.from_hdf5(store)
        if type_ == "deletion":
            from .modifiers import ElementDeletion

            return ElementDeletion.from_hdf5(store)
        if type_ == "update":
            from .modifiers import ElementUpdate

            return ElementUpdate.from_hdf5(store)
        raise ValueError(f"unknown type {type_}")

    def to_hdf5(self, store: Group) -> Group:
        from .modifiers import (
            ElementAddition,
            ElementDeletion,
            ElementUpdate,
        )

        if isinstance(self, ElementAddition):
            store.attrs["type"] = "addition"
        elif isinstance(self, ElementDeletion):
            store.attrs["type"] = "deletion"
        elif isinstance(self, ElementUpdate):
            store.attrs["type"] = "update"

        return store
