from astropy.units import Quantity
from h5py import File, Group

from .metadata import Metadata


class PointAbsorber(Metadata):
    """Information about a point absorber"""

    def __init__(
        self,
        x: Quantity,
        y: Quantity,
        radius: Quantity,
        power: Quantity,
    ) -> None:
        """Parameters
        ----------
        x: Quantity[length]
            X position of the point
        y: Quantity[length]
            Y position of the point
        radius: Quantity[length]
            Radius of the point
        power: Quantity[power]
            Absorption power of the point

        """
        if (
            x.unit is None
            or y.unit is None
            or radius.unit is None
            or power.unit is None
        ):
            raise TypeError("every quantities must have an unit")
        if (
            x.unit.physical_type != "length"
            or y.unit.physical_type != "length"
            or radius.unit.physical_type != "length"
        ):
            raise TypeError("x, y and radius must be length")
        if power.unit.physical_type != "power":
            raise TypeError("power must be power")
        if radius <= Quantity(0, "m"):
            raise ValueError("radius must be positive")
        if power <= Quantity(0, "W"):
            raise ValueError("power must be positive")

        self.x = x
        self.y = y
        self.radius = radius
        self.power = power

    @staticmethod
    def from_hdf5(store: File | Group) -> "PointAbsorber":
        for attribute in ["x", "y", "radius", "power"]:
            if attribute not in store.attrs:
                raise ValueError(
                    f"no {attribute} in absorber point metadata",
                )

        x = store.attrs["x"]
        y = store.attrs["y"]
        radius = store.attrs["radius"]
        power = store.attrs["power"]

        message = "absorber point {} should be a string, not {}"
        if not isinstance(x, str):
            raise TypeError(message.format("x", type(x)))
        if not isinstance(y, str):
            raise TypeError(message.format("y", type(y)))
        if not isinstance(radius, str):
            raise TypeError(message.format("radius", type(radius)))
        if not isinstance(power, str):
            raise TypeError(message.format("power", type(power)))

        x = Quantity(x)
        y = Quantity(y)
        radius = Quantity(radius)
        power = Quantity(power)

        return PointAbsorber(
            x=x,
            y=y,
            radius=radius,
            power=power,
        )

    def to_hdf5(self, store: File | Group) -> Group | File:
        store.attrs["x"] = self.x.to_string()
        store.attrs["y"] = self.y.to_string()
        store.attrs["radius"] = self.radius.to_string()
        store.attrs["power"] = self.power.to_string()
        return store
