from enum import StrEnum


class ElementType(StrEnum):
    MIRROR = "mirror"
    LENS = "lens"
