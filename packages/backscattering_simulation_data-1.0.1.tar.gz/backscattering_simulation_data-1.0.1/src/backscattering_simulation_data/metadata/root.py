from h5py import File, Group
from numpy import int64

from .git import Git
from .interferometer import Interferometer
from .metadata import Metadata
from .simulation import Simulation


class Root(Metadata):
    """Metadata associated to the Root section"""

    def __init__(
        self,
        name: str,
        maxtem: int,
        git: Git,
        interferometer: Interferometer,
        simulation: Simulation,
    ) -> None:
        """Parameters
        ----------
        name : str
            Unique name to indentify this simulation data
        maxtem : int
            Number of High Order Modes modelised
        git : Git
            Information about the git repo that generated this data
        interferometer : Interferometer
            Information about the simulated interferometer for this data
        simulation : Simulation
            Information about the simulation details for this data

        """
        if maxtem < 0:
            raise ValueError("maxtem must be positive")

        self.name = name
        self.maxtem = maxtem
        self.git = git
        self.interferometer = interferometer
        self.simulation = simulation

    @staticmethod
    def from_hdf5(store: File | Group) -> "Root":
        for attribute in ["name", "maxtem"]:
            if attribute not in store.attrs:
                raise ValueError(f"no {attribute} for simulation data")
        name = store.attrs["name"]
        maxtem = store.attrs["maxtem"]

        message = "simulation {} should be a {}, not {}"
        if not isinstance(name, str):
            raise ValueError(
                message.format("name", "string", type(name)),
            )
        if not isinstance(maxtem, int64):
            raise ValueError(
                message.format("maxtem", "int", type(maxtem)),
            )

        git_group = store.get("git")
        interferometer_group = store.get("interferometer")
        message = "{} information should be stored in a group, not {}"
        if not isinstance(git_group, Group):
            raise ValueError(message.format("git", type(git_group)))
        if not isinstance(interferometer_group, Group):
            raise ValueError(
                message.format(
                    "interferometer",
                    type(interferometer_group),
                ),
            )

        try:
            simulation_group = store["simulation"]  # can throw KeyError
            if not isinstance(simulation_group, Group):
                raise TypeError(
                    message.format(
                        "simulation",
                        type(simulation_group),
                    ),
                )
            simulation = Simulation.from_hdf5(simulation_group)
        except KeyError:
            # Legacy support, simulation is not defined for file
            # generated before 0.3.0
            simulation = Simulation(maps=[], model_modifiers=[])

        git = Git.from_hdf5(git_group)
        interferometer = Interferometer.from_hdf5(interferometer_group)
        return Root(
            name=name,
            maxtem=maxtem,
            git=git,
            interferometer=interferometer,
            simulation=simulation,
        )

    def to_hdf5(self, store: File | Group) -> Group | File:
        store.attrs["name"] = self.name
        store.attrs["maxtem"] = self.maxtem
        _ = self.git.to_hdf5(store.create_group("git"))
        _ = self.interferometer.to_hdf5(
            store.create_group("interferometer"),
        )
        _ = self.simulation.to_hdf5(store.create_group("simulation"))
        return store
