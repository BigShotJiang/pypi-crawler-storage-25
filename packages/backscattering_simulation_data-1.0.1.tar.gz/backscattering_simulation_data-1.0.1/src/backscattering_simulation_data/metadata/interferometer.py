from astropy.units import Quantity
from astropy.units.physical import angle, length, power
from h5py import File, Group

from .metadata import Metadata


class Interferometer(Metadata):
    """Information about the interferometer state"""

    def __init__(
        self,
        dark_fringe_power: Quantity[power],
        injection_power: Quantity[power],
        sr_yaw: Quantity[angle],
        north_arm: Quantity[length],
        west_arm: Quantity[length],
    ) -> None:
        """Parameters
        ----------
        dark_fringe_power : Quantity[power]
            Power on dark fringe (dark fringe offset)
        injection_power : Quantity[power]
            Power injected in the interferometer
        sr_yaw : Quantity[angle]
            Yaw angle of SR
        north_arm : Quantity[length]
            Length of the north arm
        west_arm : Quantity[length]
            Length of the west arm

        """
        if (
            dark_fringe_power.unit is None
            or injection_power.unit is None
            or sr_yaw.unit is None
            or north_arm.unit is None
            or west_arm.unit is None
        ):
            raise TypeError("every quantities must have an unit")
        if (
            dark_fringe_power.unit.physical_type != "power"
            or injection_power.unit.physical_type != "power"
        ):
            raise TypeError("dark fringe and injection must be power")
        if sr_yaw.unit.physical_type != "angle":
            raise TypeError("sr yaw must be an angle")
        if (
            north_arm.unit.physical_type != "length"
            or west_arm.unit.physical_type != "length"
        ):
            raise TypeError("north arm and west arm must be length")
        if dark_fringe_power < Quantity(0, "W"):
            raise ValueError("dark fringe power must be positive")
        if injection_power < Quantity(0, "W"):
            raise ValueError("injection power must be positive")
        if north_arm < Quantity(0, "m"):
            raise ValueError("north arm length must be positive")
        if west_arm < Quantity(0, "m"):
            raise ValueError("west arm length must be positive")

        self.dark_fringe_power = dark_fringe_power
        self.injection_power = injection_power
        self.sr_yaw = sr_yaw
        self.north_arm = north_arm
        self.west_arm = west_arm

    @staticmethod
    def from_hdf5(store: File | Group) -> "Interferometer":
        for attribute in [
            "dark fringe power",
            "injection power",
            "SR yaw",
            "north arm",
            "west arm",
        ]:
            if attribute not in store.attrs:
                raise ValueError(
                    f"no {attribute} in interferometer information",
                )
        dark_fringe_power = store.attrs["dark fringe power"]
        injection_power = store.attrs["injection power"]
        sr_yaw = store.attrs["SR yaw"]
        north_arm = store.attrs["north arm"]
        west_arm = store.attrs["west arm"]

        message = "interferometer {} should be a string, not {}"
        if not isinstance(dark_fringe_power, str):
            raise ValueError(
                message.format(
                    "dark fringe power",
                    type(dark_fringe_power),
                ),
            )
        if not isinstance(injection_power, str):
            raise ValueError(
                message.format(
                    "injection power",
                    type(injection_power),
                ),
            )
        if not isinstance(sr_yaw, str):
            raise ValueError(message.format("SR yaw", type(sr_yaw)))
        if not isinstance(north_arm, str):
            raise ValueError(
                message.format("north arm", type(north_arm)),
            )
        if not isinstance(west_arm, str):
            raise ValueError(message.format("west arm", type(west_arm)))

        dark_fringe_power = Quantity(dark_fringe_power)
        injection_power = Quantity(injection_power)
        sr_yaw = Quantity(sr_yaw)
        north_arm = Quantity(north_arm)
        west_arm = Quantity(west_arm)

        return Interferometer(
            dark_fringe_power=dark_fringe_power,
            injection_power=injection_power,
            sr_yaw=sr_yaw,
            north_arm=north_arm,
            west_arm=west_arm,
        )

    def to_hdf5(self, store: File | Group) -> File | Group:
        store.attrs["dark fringe power"] = (
            self.dark_fringe_power.to_string()
        )
        store.attrs["injection power"] = (
            self.injection_power.to_string()
        )
        store.attrs["SR yaw"] = self.sr_yaw.to_string()
        store.attrs["north arm"] = self.north_arm.to_string()
        store.attrs["west arm"] = self.west_arm.to_string()
        return store
