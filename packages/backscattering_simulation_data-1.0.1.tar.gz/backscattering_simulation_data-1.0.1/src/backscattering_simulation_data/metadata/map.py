from enum import StrEnum

from astropy.units import Quantity
from h5py import File, Group

from .metadata import Metadata
from .pointabsorber import PointAbsorber


class MapType(StrEnum):
    FREE = "free"
    CIRCULAR = "circular"


class Map(Metadata):
    """Information about a map on a given mirror in the simulation"""

    def __init__(
        self,
        mirror: str,
        length: Quantity,
        resolution: Quantity,
        points_absorber: list[PointAbsorber],
        type_: MapType,
    ) -> None:
        """Parameters
        ----------
        mirror: str
            Name of the mirror associated to this map
        length : Quantity[length]
            Total length of eaqh side of the squared map
        resolution : Quantity[length]
            Distance between two pixel on the squared map
        absorber_point : list[PointAbsorber]
            List of point absorber considered in this simulation
        map_type : MapType
            Type of the amplitude map

        """
        if length.unit is None or resolution.unit is None:
            raise TypeError("every quantities must have an unit")
        if (
            length.unit.physical_type != "length"
            or resolution.unit.physical_type != "length"
        ):
            raise TypeError(
                "length, resolution and roc offset must be length",
            )
        if length <= Quantity(0, "m"):
            raise ValueError("length must be positive")
        if resolution <= Quantity(0, "m"):
            raise ValueError("resolution must be positive")
        if length <= resolution:
            raise ValueError("resolution must be lower than length")

        self.mirror = mirror
        self.length = length
        self.resolution = resolution
        self.points_absorber = points_absorber
        self.type = type_

    @staticmethod
    def from_hdf5(store: File | Group) -> "Map":
        for attribute in [
            "mirror",
            "length",
            "resolution",
            "type",
        ]:
            if attribute not in store.attrs:
                raise ValueError(f"no {attribute} in map metadata")
        mirror = store.attrs["mirror"]
        length = store.attrs["length"]
        resolution = store.attrs["resolution"]
        map_type = store.attrs["type"]

        message = "map {} should be a string, not {}"
        if not isinstance(mirror, str):
            raise TypeError(message.format("mirror", type(mirror)))
        if not isinstance(length, str):
            raise TypeError(message.format("length", type(length)))
        if not isinstance(resolution, str):
            raise TypeError(
                message.format("resolution", type(resolution)),
            )
        if not isinstance(map_type, str):
            raise TypeError(message.format("map type", type(map_type)))

        length = Quantity(length)
        resolution = Quantity(resolution)
        map_type = MapType(map_type)

        points_absorber_group = store.get("points absorber")
        if not isinstance(points_absorber_group, Group):
            message = (
                "points absorber information should be stored in a "
                f"group, not {type(points_absorber_group)}"
            )
            raise TypeError(message)
        points_absorber = points_absorber_group.values()

        return Map(
            mirror=mirror,
            length=length,
            resolution=resolution,
            points_absorber=[
                PointAbsorber.from_hdf5(point_absorber)
                for point_absorber in points_absorber
            ],
            type_=map_type,
        )

    def to_hdf5(self, store: Group | File) -> Group | File:
        store.attrs["mirror"] = self.mirror
        store.attrs["length"] = self.length.to_string()
        store.attrs["resolution"] = self.resolution.to_string()
        store.attrs["type"] = str(self.type)
        _ = store.create_group("points absorber")

        for index in range(len(self.points_absorber)):
            point_absorber = self.points_absorber[index]
            _ = point_absorber.to_hdf5(
                store.require_group("points absorber").create_group(
                    str(index),
                ),
            )
        return store
