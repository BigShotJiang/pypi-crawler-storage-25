from h5py import File, Group

from .map import Map
from .metadata import Metadata
from .modelmodifier import ModelModifier


class Simulation(Metadata):
    """Information about the simulation state"""

    def __init__(
        self,
        maps: list[Map],
        model_modifiers: list[ModelModifier],
    ) -> None:
        """Parameters
        ----------
        maps: list[Map]
            List of simulated maps associated to mirrors in the
            simulation

        """
        self.maps = maps
        self.model_modifiers = model_modifiers

    @staticmethod
    def from_hdf5(store: File | Group) -> "Simulation":
        maps_group = store.get("maps")
        model_modifiers_group = store.get("model modifiers")
        if not isinstance(maps_group, Group):
            message = (
                "Maps information should be stored in a group, not "
                f"{type(maps_group)}"
            )
            raise ValueError(message)
        if not isinstance(model_modifiers_group, Group):
            message = (
                "Model modifiers must be stored in a group, not "
                f"{type(model_modifiers_group)}"
            )
            raise ValueError(message)

        maps = maps_group.values()
        model_modifiers = model_modifiers_group.values()

        return Simulation(
            maps=[Map.from_hdf5(map_) for map_ in maps],
            model_modifiers=[
                ModelModifier.from_hdf5(model_modifier)
                for model_modifier in model_modifiers
            ],
        )

    def to_hdf5(self, store: File | Group) -> File | Group:
        _ = store.create_group("maps")
        _ = store.create_group("model modifiers")
        for map_ in self.maps:
            _ = map_.to_hdf5(
                store.require_group("maps").create_group(map_.mirror),
            )
        for i in range(len(self.model_modifiers)):
            model_modifier = self.model_modifiers[i]
            _ = model_modifier.to_hdf5(
                store.require_group("model modifiers").create_group(
                    str(i),
                ),
            )
        return store
