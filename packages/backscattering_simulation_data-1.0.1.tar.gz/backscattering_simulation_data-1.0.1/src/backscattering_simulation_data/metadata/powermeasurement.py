from h5py import File, Group

from .metadata import Metadata


class PowerMeasurement(Metadata):
    """Information about a power measurement"""

    def __init__(
        self,
        port: str,
        name: str,
    ) -> None:
        """Parameters
        ----------
        port : str
            Specific port where the power was measured in the simulation
            model
        name : str
            Simple name of the place where the power was measured

        """
        self.port = port
        self.name = name

    @staticmethod
    def from_hdf5(store: Group | File) -> "PowerMeasurement":
        for attribute in ["port", "name"]:
            if attribute not in store.attrs:
                raise ValueError(
                    f"no {attribute} in power measurement metadata",
                )

        port = store.attrs["port"]
        name = store.attrs["name"]

        message = "power measurement {} should be a string, not {}"
        if not isinstance(port, str):
            raise TypeError(message.format("port", type(port)))
        if not isinstance(name, str):
            raise TypeError(message.format("name", type(name)))

        return PowerMeasurement(port=port, name=name)

    def to_hdf5(self, store: File | Group) -> Group | File:
        store.attrs["port"] = self.port
        store.attrs["name"] = self.name
        return store
