from astropy.units import Quantity
from astropy.units.physical import dimensionless
from h5py import File, Group
from numpy import float64

from .metadata import Metadata


class Scatterer(Metadata):
    """Metadata associated to a scatterer"""

    def __init__(
        self,
        name: str,
        reflectivity: Quantity[dimensionless],
    ) -> None:
        """Parameters
        ----------
        name : str
            Name of the scatterer
        reflectivity : Quantity[dimensionless]
            The reflectivity of the scatterer (simulated as a mirror)
            in the simulation

        """
        if (
            reflectivity.unit is not None
            and reflectivity.unit.physical_type != "dimensionless"
        ):
            raise TypeError("reflectivity must not have any unit")
        if reflectivity < Quantity(0):
            raise ValueError("reflectivity must be positive")
        if reflectivity > Quantity(1):
            raise ValueError("reflectivity must be below 1")

        self.name = name
        self.reflectivity = reflectivity

    @staticmethod
    def from_hdf5(store: File | Group) -> "Scatterer":
        if "name" not in store.attrs:
            raise ValueError("no name for a scatterer")
        if "reflectivity" not in store.attrs:
            raise ValueError("no reflectivity for a scatterer")
        name = store.attrs["name"]
        reflectivity = store.attrs["reflectivity"]
        if not isinstance(name, str):
            raise ValueError(f"name must be a string, not {type(name)}")
        if not isinstance(reflectivity, str) and not isinstance(
            reflectivity,
            float64,
        ):
            message = (
                "reflectivity must be a string or a float, not"
                f"{type(reflectivity)}"
            )
            raise ValueError(message)
        reflectivity = Quantity(value=reflectivity, unit=None)
        return Scatterer(name=name, reflectivity=reflectivity)

    def to_hdf5(self, store: File | Group) -> File | Group:
        store.attrs["name"] = self.name
        if isinstance(self.reflectivity, Quantity):
            store.attrs["reflectivity"] = self.reflectivity.to_string()
        else:
            message = (
                "reflectivity must be an unitless Quantity, not"
                f"{self.reflectivity}"
            )
            raise ValueError(message)
        return store
