from backscattering_simulation_data.section import Section


class Metadata(Section):
    """Conceptual class that do nothing on its own. All metadata classes
    inherit from this one.
    """
