from astropy.table import QTable
from h5py import Group

from ..modelmodifier import ModelModifier


class ElementUpdate(ModelModifier):
    """
    Information about the update of an existing element to the model
    """

    def __init__(
        self,
        element: str,
        parameters: QTable,
    ) -> None:
        self.element = element
        self.parameters = parameters

    @staticmethod
    def from_hdf5(store: Group) -> "ElementUpdate":
        if "element" not in store.attrs:
            raise ValueError("no element in model update metadata")

        element = store.attrs["element"]

        if not isinstance(element, str):
            message = (
                "element of model update must be a string, not",
                f"{type(element)}",
            )
            raise TypeError(message)

        parameters = QTable.read(
            store,
            format="hdf5",
            path="parameters",
        )

        return ElementUpdate(
            element=element,
            parameters=parameters,
        )

    def to_hdf5(self, store: Group) -> Group:
        store.attrs["element"] = self.element

        self.parameters.write(
            store,
            format="hdf5",
            path="parameters",
            serialize_meta=True,
        )

        return ModelModifier.to_hdf5(self, store)
