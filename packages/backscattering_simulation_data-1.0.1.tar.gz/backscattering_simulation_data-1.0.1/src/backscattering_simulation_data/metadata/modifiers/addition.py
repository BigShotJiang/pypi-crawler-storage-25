from typing import TYPE_CHECKING

from astropy.table import QTable
from h5py import Dataset, Group

from ..elementtype import ElementType
from ..modelmodifier import ModelModifier

if TYPE_CHECKING:
    from .deletion import ElementDeletion


class ElementAddition(ModelModifier):
    """Information about an addition of an element to the model"""

    def __init__(
        self,
        requirements: list["ElementAddition | ElementDeletion"],
        port: str,
        element: str,
        element_type: ElementType,
        parameters: QTable,
    ) -> None:
        self.requirements = requirements
        self.port = port
        self.element = element
        self.element_type = element_type
        self.parameters = parameters

    @staticmethod
    def from_hdf5(store: Group) -> "ElementAddition":
        for attribute in ["element", "element type", "port"]:
            if attribute not in store.attrs:
                raise ValueError(
                    f"no {attribute} in model addition metadata",
                )

        element = store.attrs["element"]
        element_type_str = store.attrs["element type"]
        port = store.attrs["port"]

        message = "model addition {} should be a string, not {}"
        if not isinstance(element, str):
            raise TypeError(message.format("element", type(element)))
        if not isinstance(element_type_str, str):
            raise TypeError(
                message.format(
                    element_type_str,
                    type(element_type_str),
                ),
            )
        if not isinstance(port, str):
            raise TypeError(message.format(port, type(port)))

        element_type = ElementType(element_type_str)

        requirements_dataset = store.get("requirements")

        if not isinstance(requirements_dataset, Dataset):
            message = (
                "requirements must be stored in a Dataset, not "
                f"{type(requirements_dataset)}"
            )
            raise TypeError(message)

        requirements = list(requirements_dataset)

        parameters = QTable.read(
            store,
            format="hdf5",
            path="parameters",
        )

        return ElementAddition(
            element=element,
            element_type=element_type,
            port=port,
            requirements=requirements,
            parameters=parameters,
        )

    def to_hdf5(self, store: Group) -> Group:
        store.attrs["element"] = self.element
        store.attrs["element type"] = self.element_type
        store.attrs["port"] = self.port

        _ = store.create_dataset(
            "requirements",
            data=[
                requirement.element for requirement in self.requirements
            ],
        )

        self.parameters.write(
            store,
            format="hdf5",
            path="parameters",
            serialize_meta=True,
        )

        return ModelModifier.to_hdf5(self, store)
