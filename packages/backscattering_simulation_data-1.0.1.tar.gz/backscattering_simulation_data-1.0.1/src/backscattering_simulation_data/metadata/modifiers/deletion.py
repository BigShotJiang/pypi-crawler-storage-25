from h5py import Group

from ..modelmodifier import ModelModifier


class ElementDeletion(ModelModifier):
    """Information about the deletion of an element to the model"""

    def __init__(
        self,
        element: str,
    ) -> None:
        self.element = element

    @staticmethod
    def from_hdf5(store: Group) -> "ElementDeletion":
        if "element" not in store.attrs:
            raise ValueError("no element in model deletion metadata")
        element = store.attrs["element"]
        if not isinstance(element, str):
            message = (
                "element of model deletion must be a string, not "
                f"{type(element)}"
            )
            raise TypeError(message)
        return ElementDeletion(element=element)

    def to_hdf5(self, store: Group) -> Group:
        store.attrs["element"] = self.element

        return ModelModifier.to_hdf5(self, store)
