from urllib.parse import ParseResult, urlparse

from h5py import File, Group

from .metadata import Metadata


class Git(Metadata):
    """
    Information about the git repo of the algorithm which generated the
    simulation data
    """

    def __init__(
        self,
        remote: ParseResult,
        commit: str,
        version: str,
        branch: str,
    ) -> None:
        """Parameters
        ----------
        remote :  ParseResult
            Repo location, must be the remote URI
        commit : str
            Latest commit hash when the simulation was computed
        version : str
            Version of the script which generated the simulation data
        branch : str
            Name of the branch of the git repo

        """
        self.remote = remote
        self.commit = commit
        self.version = version
        self.branch = branch

    @staticmethod
    def from_hdf5(store: File | Group) -> "Git":
        for attribute in [
            "remote",
            "commit",
            "version",
            "branch",
        ]:
            if attribute not in store.attrs:
                raise ValueError("no {} in git information")
        remote = store.attrs["remote"]
        commit = store.attrs["commit"]
        version = store.attrs["version"]
        branch = store.attrs["branch"]

        message = "git {} should be a string, not {}"
        if not isinstance(remote, str):
            raise ValueError(message.format("remote", type(remote)))
        if not isinstance(commit, str):
            raise ValueError(message.format("commit", type(commit)))
        if not isinstance(version, str):
            raise ValueError(message.format("version", type(version)))
        if not isinstance(branch, str):
            raise ValueError(message.format("branch", type(branch)))

        remote = urlparse(remote)

        return Git(
            remote=remote,
            commit=commit,
            version=version,
            branch=branch,
        )

    def to_hdf5(self, store: File | Group) -> File | Group:
        store.attrs["remote"] = self.remote.geturl()
        store.attrs["commit"] = self.commit
        store.attrs["version"] = self.version
        store.attrs["branch"] = self.branch
        return store
