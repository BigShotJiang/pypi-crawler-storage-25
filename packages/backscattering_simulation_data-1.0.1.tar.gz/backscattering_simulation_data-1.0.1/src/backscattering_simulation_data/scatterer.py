from gwpy.frequencyseries import FrequencySeries
from h5py import Dataset, File, Group

from .metadata.scatterer import Scatterer as MetadataScatterer
from .section import Section
from .utils import (
    dataset_to_frequencyseries,
    frequencyseries_to_dataset,
)


class Scatterer(Section):
    """Contains Transfer Function between a scatterer and the DC dark
    fringe power
    """

    def __init__(
        self,
        metadata: MetadataScatterer,
        kn: FrequencySeries,
        kp: FrequencySeries,
    ) -> None:
        """Parameters
        ----------
        metadata : MetadataScatterer
            Metadata associated to this scatterer
        kn : FrequencySeries
            Kp transfer function (scatterer is located so that the
            reflected light is out of phase with the recoupled beam)
        kp : FrequencySeries
            Kn transfer function (scatterer is located so that the
            reflected light is in phase with the recoupled beam)

        """
        self.metadata = metadata
        self.kn = kn
        self.kp = kp

    @staticmethod
    def from_hdf5(store: File | Group) -> "Scatterer":
        kn_dataset = store.get("kn")
        kp_dataset = store.get("kp")
        if not isinstance(kn_dataset, Dataset):
            raise ValueError(
                f"kn should exists, and not be {type(kn_dataset)}",
            )
        if not isinstance(kp_dataset, Dataset):
            raise ValueError(
                f"kp should exists, and not be {type(kp_dataset)}",
            )
        return Scatterer(
            metadata=MetadataScatterer.from_hdf5(store),
            kn=dataset_to_frequencyseries(kn_dataset),
            kp=dataset_to_frequencyseries(kp_dataset),
        )

    def to_hdf5(self, store: File | Group) -> Group | File:
        _ = self.metadata.to_hdf5(store)
        _ = frequencyseries_to_dataset(store, "kn", self.kn)
        _ = frequencyseries_to_dataset(store, "kp", self.kp)
        return store
