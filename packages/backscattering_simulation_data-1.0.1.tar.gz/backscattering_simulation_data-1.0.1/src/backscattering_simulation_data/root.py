from pathlib import Path
from typing import TYPE_CHECKING

from gwpy.frequencyseries import FrequencySeries
from h5py import Dataset, File, Group
from numpy import array, mean
from scipy.io.matlab import savemat

from .metadata.root import Root as Metadata
from .powermeasurement import PowerMeasurement
from .scatterer import Scatterer
from .section import Section
from .utils import (
    dataset_to_frequencyseries,
    frequencyseries_to_dataset,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


class Root(Section):
    """Simulation data identified with an unique name, with information
    about the code that generated it
    """

    def __init__(
        self,
        metadata: Metadata,
        scatterers: list[Scatterer],
        power_measurements: list[PowerMeasurement],
        darm: FrequencySeries,
    ) -> None:
        """Parameters
        ----------
        metadata : Metadata
            Metadata associated to this data package
        scatterers: list[Scatterer]
            Scatterers data list
        darm : FrequencySeries
            common DARM transfer function for all this simulation data

        """
        self.metadata = metadata
        self.scatterers = scatterers
        self.power_measurements = power_measurements
        self.darm = darm

    @staticmethod
    def from_hdf5(store: File | Group) -> "Root":
        scatterers_group = store.get("scatterers")
        darm_dataset = store.get("DARM")
        message = "{} should exists, and not be {}"
        if not isinstance(scatterers_group, Group):
            raise TypeError(
                message.format(
                    "scatterers group",
                    type(scatterers_group),
                ),
            )
        if not isinstance(darm_dataset, Dataset):
            raise ValueError(
                message.format("DARM dataset", type(darm_dataset)),
            )
        scatterers = scatterers_group.values()

        try:
            power_measurements_group = store["power measurements"]
            if not isinstance(power_measurements_group, Group):
                raise TypeError(
                    message.format(
                        "power measurements",
                        type(power_measurements_group),
                    ),
                )
            power_measurements_values = (
                power_measurements_group.values()
            )
            power_measurements = [
                PowerMeasurement.from_hdf5(power_measurement)
                for power_measurement in power_measurements_values
            ]
        except KeyError:
            # Legcay support, power measurements is not defined for file
            # generated before 0.3.0
            power_measurements = []

        return Root(
            metadata=Metadata.from_hdf5(store),
            scatterers=[
                Scatterer.from_hdf5(scatterer)
                for scatterer in scatterers
            ],
            power_measurements=power_measurements,
            darm=dataset_to_frequencyseries(darm_dataset),
        )

    def to_hdf5(self, store: File | Group) -> File | Group:
        _ = self.metadata.to_hdf5(store)
        _ = store.create_group(
            "scatterers",
        )  # create the group even if scatterers list is empty
        _ = store.create_group("power measurements")
        for scatterer in self.scatterers:
            _ = scatterer.to_hdf5(
                store.require_group("scatterers").create_group(
                    scatterer.metadata.name,
                ),
            )
        for power_measurement in self.power_measurements:
            _ = power_measurement.to_hdf5(
                store.require_group("power measurements").create_group(
                    power_measurement.metadata.name,
                ),
            )
        _ = frequencyseries_to_dataset(store, "DARM", self.darm)
        return store

    def to_matlab(self, path: Path) -> None:
        if len(self.scatterers) < 1:
            raise ValueError("no scatterer to save")
        data: dict[str, NDArray] = {}
        for scatterer in self.scatterers:
            data[f"{scatterer.metadata.name}mat"] = array(
                [tf.to_value() for tf in [scatterer.kn, scatterer.kp]],
            )
            north_arm = self.metadata.interferometer.north_arm.to_value(
                "m",
            )
            west_arm = self.metadata.interferometer.west_arm.to_value(
                "m",
            )
            if not isinstance(north_arm, float):
                raise TypeError
            if not isinstance(west_arm, float):
                raise TypeError
            arm_length = mean([north_arm, west_arm])
            data[f"{scatterer.metadata.name}coupling"] = array(
                [
                    tf.to_value() / self.darm.to_value() / arm_length
                    for tf in [scatterer.kn, scatterer.kp]
                ],
            )
        data["freq"] = self.scatterers[0].kn.frequencies

        savemat(str(path), data)
