from astropy.table import QTable
from h5py import File, Group

from .metadata import MetadataPowerMeasurement as Metadata
from .section import Section


class PowerMeasurement(Section):
    """A power measurement in a specific place in the simulated
    interferometer
    """

    def __init__(
        self,
        metadata: Metadata,
        modes: QTable,
    ) -> None:
        """Paremeters
        ----------
        metadata : Metadata
            Information about this power measurement
        modes : QTable
            Power on the different modes (can be 1D if only TEM00)
        """
        self.metadata = metadata
        self.modes = modes

    @staticmethod
    def from_hdf5(store: Group | File) -> "PowerMeasurement":
        return PowerMeasurement(
            metadata=Metadata.from_hdf5(store),
            modes=QTable.read(
                store,
                format="hdf5",
                path="modes",
            ),
        )

    def to_hdf5(self, store: File | Group) -> Group | File:
        _ = self.metadata.to_hdf5(store)
        self.modes.write(
            store,
            format="hdf5",
            path="modes",
            serialize_meta=True,
        )
        return store
