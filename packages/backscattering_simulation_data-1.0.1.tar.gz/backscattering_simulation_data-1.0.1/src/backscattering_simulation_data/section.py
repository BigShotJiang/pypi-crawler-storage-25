from pathlib import Path
from typing import TYPE_CHECKING

from h5py import File, Group

if TYPE_CHECKING:
    from astropy.table import QTable
    from astropy.units import Quantity
    from gwpy.frequencyseries import FrequencySeries


class Section:
    """Any class that represent a set of data."""

    def get(
        self,
        attribute: str,
    ) -> "Section | FrequencySeries | QTable | Quantity | int":
        """Get an attribute of this section

        Parameters
        ----------
        attribute : str
            Attribute to get

        Returns
        -------
        Any : The value of the given attribute

        """
        return getattr(self, attribute)

    def set(
        self,
        attribute: str,
        value: "Section | FrequencySeries | QTable | Quantity | int",
    ) -> None:
        """Set an attribute of this section

        Parameters
        ----------
        attribute : str
            Attribute to set
        value : Any
            Value to set

        """
        return setattr(self, attribute, value)

    @staticmethod
    def from_hdf5(store: File | Group) -> "Section":  # pyright: ignore [reportUnusedParameter]
        """Convert an hdf5 file or group to the corresponding section

        Parameters
        ----------
        store : File | Group
            Group corresponding to a given section

        Returns
        -------
        An instance of a subclass of Section

        """
        raise NotImplementedError(
            "this method has not been implemented for this class",
        )

    @staticmethod
    def from_folder(folder: Path) -> "Section":  # pyright: ignore [reportUnusedParameter]
        """Convert a folder to the corresponding section

        Parameters
        ----------
        folder : Path
            Folder containing all the data

        Returns
        -------
        An instance of a subclass of Section

        """
        raise NotImplementedError(
            "this method has not been implemented for this class",
        )

    def to_hdf5(self, store: File | Group) -> Group | File:  # pyright: ignore [reportUnusedParameter]
        """Convert this set of data to a HDF5 group

        Parameters
        ----------
        store : File | Group
            Where to insert this group

        Notes
        -----
        It recursively create sub groups

        Returns
        -------
        Group : new created group

        """
        raise NotImplementedError(
            "this method has not been implemented for this class",
        )
