from astropy.units import Quantity, Unit
from gwpy.frequencyseries import FrequencySeries
from h5py import Dataset, File, Group
from numpy import array


def dataset_to_frequencyseries(dataset: Dataset) -> FrequencySeries:
    """
    Convert a h5df dataset to a FrequencySeries keeping the units right

    Parameters
    ----------
    dataset : Dataset
        Dataset to convert

    Returns
    -------
    TimeSeries : TimeSeries with a good unit

    """
    unit = None
    if "units" in dataset.attrs:
        units = dataset.attrs["units"]
        if isinstance(units, str):
            unit = Unit(units)
        else:
            raise ValueError(f"cannot convert {units} to a unit")
    if "f0" not in dataset.attrs:
        raise ValueError(
            "no starting time defined for this frequencyseries",
        )
    if "df" not in dataset.attrs:
        message = (
            "no time sample separation defined for the",
            "frequencyseries",
        )
        raise ValueError(message)
    f0 = dataset.attrs["f0"]
    df = dataset.attrs["df"]
    if not isinstance(f0, str):
        raise ValueError(f"f0 must be stored as string, not {type(f0)}")
    if not isinstance(df, str):
        raise ValueError(f"df must be stored as string, not {type(df)}")
    f0 = Quantity(f0)
    df = Quantity(df)
    return FrequencySeries(
        data=array(dataset),
        unit=unit,
        f0=f0,
        df=df,
    )


def frequencyseries_to_dataset(
    store: File | Group,
    name: str,
    frequencyseries: FrequencySeries,
) -> Dataset:
    """
    Convert a gwpy FrequencySeries to a hdf5 dataset keeping the units
    right

    Parameters
    ----------
    store : File | Group
        hdf5 element which will store the Dataset
    name : str
        Name of the dataset in the store
    timeseries : TimeSeries
        Data to store in the Dataset

    Returns
    -------
    Dataset : Created dataset

    """
    dataset = store.create_dataset(name, data=frequencyseries.data)
    if frequencyseries.unit is not None:
        dataset.attrs["units"] = frequencyseries.unit.to_string()
    if not isinstance(frequencyseries.f0, Quantity):
        raise ValueError(
            f"f0 must be a quantity, not {type(frequencyseries.f0)}",
        )
    if not isinstance(frequencyseries.df, Quantity):
        raise ValueError(
            f"f0 must be a quantity, not {type(frequencyseries.df)}",
        )
    dataset.attrs["f0"] = frequencyseries.f0.to_string()
    dataset.attrs["df"] = frequencyseries.df.to_string()
    return dataset
