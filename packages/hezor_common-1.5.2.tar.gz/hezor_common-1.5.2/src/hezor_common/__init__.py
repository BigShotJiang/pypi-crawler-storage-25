"""Hezor Common - Common utilities for Hezor projects."""

from hezor_common import exceptions

__version__ = "1.5.2"


def hello() -> str:
    """Return a greeting message."""
    return "Hello from hezor-common!"


__all__ = ["__version__", "hello", "exceptions"]
