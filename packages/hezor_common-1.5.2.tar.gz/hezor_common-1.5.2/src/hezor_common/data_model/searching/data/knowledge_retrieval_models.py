"""Knowledge retrieval models shared by Hezor services and SDKs.

This module defines the structured response models for
``knowledge_retrieve`` webhook action.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from hezor_common.utilities.text_helpers import to_camel


class Chunk(BaseModel):
    """Knowledge chunk.

    Parameters
    ----------
    vector_id : str
        Vector ID.
    batch_id : str
        Batch ID.
    content_id : str
        Content ID.
    text : str
        Chunk text.
    text_length : int
        Text length.
    vector_dimension : int
        Vector dimension.
    chunk_id : str
        Chunk ID.
    doc_id : str
        Document ID.
    doc_name : str
        Document name.
    page : int
        Page number.
    update_at : str
        Updated time.
    status : str
        Status.
    source_file : str
        Source file.
    file_type : str
        File type.
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    vector_id: str = Field(..., description="向量 ID（唯一标识）")
    batch_id: str = Field(default="", description="批次 ID")
    content_id: str = Field(default="", description="内容 ID")
    text: str = Field(default="", description="文本内容")
    text_length: int = Field(default=0, description="文本长度")
    vector_dimension: int = Field(default=0, description="向量维度")
    chunk_id: str = Field(default="", description="分块 ID")
    doc_id: str = Field(default="", description="关联文档 ID")
    doc_name: str = Field(default="", description="文档名称")
    page: int = Field(default=0, description="所在页码")
    update_at: str = Field(default="", description="更新时间")
    status: str = Field(default="ok", description="状态")
    source_file: str = Field(default="", description="来源文件路径")
    file_type: str = Field(default="", description="文件类型")
    kb_ids: list[str] = Field(
        default_factory=list,
        description="此分块已挂载的逻辑知识库 ID 列表",
    )


class OntologyEntity(BaseModel):
    """Ontology entity."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    id: str = Field(..., description="点 ID（数据库主键）")
    entity_id: str = Field(..., description="实体简短 ID")
    entity_type: str = Field(..., description="实体类型")
    name: str = Field(..., description="实体名称")
    aliases: list[str] = Field(default_factory=list, description="实体别名列表")
    description: str = Field(default="", description="实体描述")
    doc_ids: list[str] = Field(default_factory=list, description="关联文档 ID 列表")
    source_chunk_ids: list[str] = Field(default_factory=list, description="来源分块 ID 列表")
    source_picture_ids: list[str] = Field(default_factory=list, description="来源图片 ID 列表")
    updated_at: str = Field(default="", description="更新时间")
    status: str = Field(default="ok", description="状态")
    batch_id: str = Field(default="", description="批次 ID")
    content_id: str = Field(default="", description="内容 ID")
    source_file: str = Field(default="", description="来源文件")
    kb_ids: list[str] = Field(
        default_factory=list,
        description="此实体已挂载的逻辑知识库 ID 列表",
    )


class CommunityFinding(BaseModel):
    """Community finding."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    summary: str = Field(default="", description="发现摘要")
    explanation: str = Field(default="", description="发现解释")


class Community(BaseModel):
    """Knowledge community."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    id: str = Field(..., description="点 ID（数据库主键）")
    community_id: str = Field(..., description="社区标识")
    title: str = Field(..., description="社区标题")
    summary: str = Field(default="", description="社区摘要")
    level: int = Field(default=1, description="社区层级")
    entity_ids: list[str] = Field(default_factory=list, description="关联实体 ID 列表")
    relationship_ids: list[str] = Field(default_factory=list, description="关联关系 ID 列表")
    parent_id: str | None = Field(default=None, description="父社区 ID")
    children_ids: list[str] = Field(default_factory=list, description="子社区 ID 列表")
    rating: float = Field(default=0.0, description="社区评分（0-10）")
    rating_explanation: str = Field(default="", description="评分说明")
    findings: list[CommunityFinding] = Field(default_factory=list, description="核心发现列表")
    updated_at: str = Field(default="", description="更新时间")
    status: str = Field(default="ok", description="状态")
    batch_id: str = Field(default="", description="批次 ID")
    content_id: str = Field(default="", description="内容 ID")
    source_file: str = Field(default="", description="来源文件")
    kb_ids: list[str] = Field(
        default_factory=list,
        description="此社区已挂载的逻辑知识库 ID 列表",
    )


class GalleryPicture(BaseModel):
    """Knowledge gallery picture."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    vector_id: str = Field(..., description="向量 ID（唯一标识）")
    batch_id: str = Field(default="", description="批次 ID")
    content_id: str = Field(default="", description="内容 ID")
    text: str = Field(default="", description="图片描述文本")
    text_length: int = Field(default=0, description="描述文本长度")
    vector_dimension: int = Field(default=0, description="向量维度")
    pic_id: str = Field(default="", description="图片 ID")
    description: str = Field(default="", description="图片详细描述")
    filename: str = Field(default="", description="图片文件路径")
    doc_id: str = Field(default="", description="关联文档 ID")
    doc_name: str = Field(default="", description="文档名称")
    page: int = Field(default=0, description="所在页码")
    update_at: str = Field(default="", description="更新时间")
    status: str = Field(default="ok", description="状态")
    source_file: str = Field(default="", description="来源文件路径")
    file_type: str = Field(default="", description="文件类型")
    kb_ids: list[str] = Field(
        default_factory=list,
        description="此图片已挂载的逻辑知识库 ID 列表",
    )


class OntologyRelationship(BaseModel):
    """Ontology relationship.

    Parameters
    ----------
    id : str
        点 ID（数据库主键）。
    relation_id : str
        关系简短 ID。
    relationship_type : str
        关系类型。
    description : str
        关系描述。
    weight : float
        关系权重。
    source : str
        源实体名称。
    source_id : str
        源实体 ID。
    target : str
        目标实体名称。
    target_id : str
        目标实体 ID。
    source_chunk_ids : list[str]
        来源分块 ID 列表。
    source_picture_ids : list[str]
        来源图片 ID 列表。
    updated_at : str
        更新时间。
    status : str
        状态。
    batch_id : str
        批次 ID。
    content_id : str
        内容 ID。
    source_file : str
        来源文件。
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    id: str = Field(..., description="点 ID（数据库主键）")
    relation_id: str = Field(..., description="关系简短 ID")
    relationship_type: str = Field(default="", description="关系类型")
    description: str = Field(default="", description="关系描述")
    weight: float = Field(default=0.0, description="关系权重")
    source: str = Field(default="", description="源实体名称")
    source_id: str = Field(default="", description="源实体 ID")
    target: str = Field(default="", description="目标实体名称")
    target_id: str = Field(default="", description="目标实体 ID")
    source_chunk_ids: list[str] = Field(default_factory=list, description="来源分块 ID 列表")
    source_picture_ids: list[str] = Field(default_factory=list, description="来源图片 ID 列表")
    updated_at: str = Field(default="", description="更新时间")
    status: str = Field(default="ok", description="状态")
    batch_id: str = Field(default="", description="批次 ID")
    content_id: str = Field(default="", description="内容 ID")
    source_file: str = Field(default="", description="来源文件")


class ScoredChunk(BaseModel):
    """Chunk result with score and rank."""

    chunk: Chunk = Field(..., description="分块详情")
    score: float = Field(..., description="相似度分数")
    rank: int = Field(..., description="排名")


class ScoredEntity(BaseModel):
    """Entity result with score and rank."""

    entity: OntologyEntity = Field(..., description="实体详情")
    score: float = Field(..., description="相似度分数")
    rank: int = Field(..., description="排名")


class ScoredCommunity(BaseModel):
    """Community result with score and rank."""

    community: Community = Field(..., description="社区详情")
    score: float = Field(..., description="相似度分数")
    rank: int = Field(..., description="排名")


class ScoredPicture(BaseModel):
    """Picture result with score and rank."""

    picture: GalleryPicture = Field(..., description="图片详情")
    score: float = Field(..., description="相似度分数")
    rank: int = Field(..., description="排名")


class ChunkSearchResultList(BaseModel):
    """Chunk search result list."""

    items: list[ScoredChunk] = Field(default_factory=list, description="结果列表")
    collection: str = Field(default="", description="集合名称")
    query: str = Field(default="", description="查询文本")
    total: int = Field(default=0, description="结果数量")


class EntitySearchResultList(BaseModel):
    """Entity search result list."""

    items: list[ScoredEntity] = Field(default_factory=list, description="结果列表")
    collection: str = Field(default="", description="集合名称")
    query: str = Field(default="", description="查询文本")
    total: int = Field(default=0, description="结果数量")


class CommunitySearchResultList(BaseModel):
    """Community search result list."""

    items: list[ScoredCommunity] = Field(default_factory=list, description="结果列表")
    collection: str = Field(default="", description="集合名称")
    query: str = Field(default="", description="查询文本")
    total: int = Field(default=0, description="结果数量")


class PictureSearchResultList(BaseModel):
    """Picture search result list."""

    items: list[ScoredPicture] = Field(default_factory=list, description="结果列表")
    collection: str = Field(default="", description="集合名称")
    query: str = Field(default="", description="查询文本")
    total: int = Field(default=0, description="结果数量")


class KnowledgeSearchResult(BaseModel):
    """Cross-collection knowledge search result."""

    chunks: ChunkSearchResultList = Field(
        default_factory=ChunkSearchResultList,
        description="分块检索结果",
    )
    entities: EntitySearchResultList = Field(
        default_factory=EntitySearchResultList,
        description="实体检索结果",
    )
    communities: CommunitySearchResultList = Field(
        default_factory=CommunitySearchResultList,
        description="社区检索结果",
    )
    pictures: PictureSearchResultList = Field(
        default_factory=PictureSearchResultList,
        description="图片检索结果",
    )
    query: str = Field(default="", description="查询文本")


__all__ = [
    "Chunk",
    "ChunkSearchResultList",
    "Community",
    "CommunityFinding",
    "CommunitySearchResultList",
    "EntitySearchResultList",
    "GalleryPicture",
    "KnowledgeSearchResult",
    "OntologyEntity",
    "OntologyRelationship",
    "PictureSearchResultList",
    "ScoredChunk",
    "ScoredCommunity",
    "ScoredEntity",
    "ScoredPicture",
]
