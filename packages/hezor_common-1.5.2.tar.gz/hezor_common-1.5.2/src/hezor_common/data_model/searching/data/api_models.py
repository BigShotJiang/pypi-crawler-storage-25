"""Data API models.

数据API的请求和响应模型定义。
"""

from typing import Any

from pydantic import BaseModel, Field


class ParameterPropertySchema(BaseModel):
    """参数属性定义。"""

    type: str = Field(
        default="string",
        description="参数类型: string, integer, number, boolean, object, array",
    )
    desc: str = Field(default="", description="参数描述")
    properties: dict[str, "ParameterPropertySchema"] | None = Field(
        default=None,
        description="对象属性定义",
    )
    items: "ParameterPropertySchema | None" = Field(
        default=None,
        description="数组元素类型",
    )
    enum: list[Any] | None = Field(default=None, description="枚举值列表")


class ParameterSchema(BaseModel):
    """参数定义。"""

    type: str = Field(description="参数类型: string, integer, number, boolean, object, array")
    desc: str = Field(description="参数描述")
    props: dict[str, ParameterPropertySchema] | None = Field(
        default=None,
        description="对象属性定义",
    )
    required: list[str] | None = Field(default=None, description="必需的参数列表")


class ToolStats(BaseModel):
    """工具调用统计。"""

    success_count: int = Field(default=0, description="成功调用次数")
    failure_count: int = Field(default=0, description="失败调用次数")
    total_duration: float = Field(default=0.0, description="总耗时（秒）")
    max_duration: float = Field(default=0.0, description="最大耗时（秒）")
    avg_duration: float = Field(default=0.0, description="平均耗时（秒）")
    last_called_at: str | None = Field(default=None, description="最后调用时间")


class ToolSchema(BaseModel):
    """工具定义。"""

    name: str = Field(description="工具名称")
    desc: str = Field(description="工具描述")
    params: ParameterSchema = Field(description="参数定义")
    returns: str | None = Field(default=None, description="返回值描述")
    db_deps: list[str] = Field(
        default_factory=list,
        description="工具执行所需的数据库类别列表",
    )
    stats: ToolStats | None = Field(default=None, description="工具调用统计")
    group: str | None = Field(default=None, description="工具分组，支持多级分组如'餐饮/收入'")


class SearchResponse(BaseModel):
    """搜索响应。"""

    tools: list[ToolSchema] = Field(description="匹配的工具列表")


class ToolsListResponse(BaseModel):
    """工具列表响应。"""

    total: int = Field(description="工具总数")
    tools: list[ToolSchema] = Field(description="所有工具的列表")


class ToolkitToolSummary(BaseModel):
    """工具包内工具摘要。"""

    name: str = Field(description="工具名称")
    desc: str = Field(default="", description="工具描述")
    group: str | None = Field(default=None, description="工具分组")


class ToolkitSchema(BaseModel):
    """工具包定义。"""

    id: str = Field(description="工具包唯一标识")
    name: str = Field(description="工具包名称")
    summary: str = Field(default="", description="工具包摘要描述")
    tool_count: int = Field(default=0, description="工具包中的工具数量")
    tools: list[ToolkitToolSummary] | None = Field(
        default=None,
        description="工具列表，仅在 include_tools=true 时返回",
    )


class ToolkitsResponse(BaseModel):
    """工具包列表响应。"""

    total: int = Field(description="工具包总数")
    toolkits: list[ToolkitSchema] = Field(description="工具包列表")


class ExecuteRequest(BaseModel):
    """执行请求。"""

    tool: str = Field(description="工具名称")
    args: dict[str, Any] = Field(description="工具参数")


class ExecuteResponse(BaseModel):
    """执行响应。"""

    success: bool = Field(default=True, description="执行是否成功")
    data: dict[str, Any] | list[Any] = Field(
        default={}, description="执行结果数据，可以是字典或列表"
    )
    count: int = Field(default=0, description="结果数量")
    error: str = Field(default="", description="错误信息")
    desc: str = Field(default="", description="结果描述")


class DataRetrieveResult(BaseModel):
    """data_retrieve webhook 响应数据。"""

    query: str = Field(..., description="原始查询语句")
    results: dict[str, ExecuteResponse] = Field(
        default_factory=dict,
        description="工具名称到执行结果的映射",
    )
