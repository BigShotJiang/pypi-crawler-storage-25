"""Base SDK constants.

Common constants used across base SDK components.
"""

# --- Request header keys ---
REQ_HEADER_META_INFO_KEY = "X-META-INFO"
REQ_HEADER_APP_NAME_KEY = "X-APP-NAME"

# --- MetaInfo extras keys ---
META_EXTRAS_KEY_AUTHORIZED_TOOLKITS = "authorized_toolkits"
# 用户在当前会话选择的知识库 ID 列表；由 prepare_contexts 填充。
#
# DANGER
# ------
# 当此字段为空或缺省时，向下层 workflow / API 表示“拥有全部 KB
# 访问权”，这是类型迁移期的兼容语义。未来会收紧为“空即无
# 访问权”，调用方不要依赖于“不填=全开”的行为。
META_EXTRAS_KEY_AUTHORIZED_KB_IDS = "authorized_kb_ids"
# OAuth 模式下本次令牌实际生效的 scope 列表；由平台签发时写入，
# 下游服务可据此做细粒度鉴权，不可由调用方自报。
META_EXTRAS_KEY_EFFECTIVE_SCOPES = "effective_scopes"
# OAuth grant 版本号快照；令牌签发时将当前 grant_version 写入 extras，
# 供无状态网关与 grant_version 字段联合校验，避免撤权后旧令牌仍生效。
META_EXTRAS_KEY_SCOPE_GRANT_VERSION = "scope_grant_version"

# --- MetaInfo auth_mode 取值 ---
# 第三方后端用 Ed25519 私钥签发 MetaInfo JWT（历史模式，``extras.authorized_*``
# 由调用方自报）。
META_AUTH_MODE_PRIVATE_KEY = "private_key"
# 用户在 ``/oauth/consent`` 主动授权后由平台签发；``extras.authorized_toolkits``
# 应等于 ``grants ∩ subscriptions``，调用方不得自报。
META_AUTH_MODE_OAUTH = "oauth"

# --- Anonymous keys ---
ANONYMOUS_HEADER_PRIVATE_KEY = """-----BEGIN ENCRYPTED PRIVATE KEY-----
MIGjMF8GCSqGSIb3DQEFDTBSMDEGCSqGSIb3DQEFDDAkBBApd1A1zS2kYA2PacTL
ga12AgIIADAMBggqhkiG9w0CCQUAMB0GCWCGSAFlAwQBKgQQLqgqVXR/1YxTjbJ6
wleoyARAf2ENSGpjGhuZ1b1j4Y7YvRyzDNC5Nw5FQfVSll9BkyBP5fYv0+zRuUqu
XE1mIsWI/vEuRcDP/U/EG46uOfaDKg==
-----END ENCRYPTED PRIVATE KEY-----"""

ANONYMOUS_HEADER_PRIVATE_KEY_PASSWORD = b"file_password"

ANONYMOUS_HEADER_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEArzeACVckM68Jf83BVPzX4ZNWFkyAvbsOwadn/lg7l0c=
-----END PUBLIC KEY-----"""
