"""Data API 客户端。

用于与数据 API 网关进行交互，支持工具搜索和执行。
"""

import logging
from pathlib import Path
from typing import Any

import httpx

from hezor_common.data_model.searching.data.api_models import (
    ExecuteRequest,
    ExecuteResponse,
    SearchResponse,
    ToolkitsResponse,
    ToolsListResponse,
)
from hezor_common.transfer.base_sdk import BaseAPIClient, MetaInfo
from hezor_common.transfer.datahub_sdk.base.constants import (
    DEFAULT_DATA_API_BASE_URL,
    DEFAULT_DATA_API_KEY,
)

logger = logging.getLogger(__name__)


class DataAPIClient(BaseAPIClient):
    """数据API客户端。

    用于与数据API网关进行交互，支持工具搜索和执行。
    继承自 BaseAPIClient，提供通用的认证和请求头管理功能。
    """

    def __init__(
        self,
        base_url: str = DEFAULT_DATA_API_BASE_URL,
        timeout: float = 120.0,
        api_key: str | None = DEFAULT_DATA_API_KEY,
        meta_info: MetaInfo | None = None,
        private_key_path: str | Path | None = None,
        password: bytes | None = None,
        meta_info_expires_in: int = 3600,
        app_name: str | None = None,
    ):
        """初始化客户端。

        Parameters
        ----------
        base_url : str
            API基础URL
        timeout : float
            请求超时时间（秒）
        api_key : str | None
            API密钥，用于Bearer token认证。如果为None，则不添加Authorization头
        meta_info : MetaInfo | None
            元信息对象，用于生成请求头。如果为None，则不添加元信息头
        private_key_path : str | Path | None
            私钥文件路径，用于JWT签名。如果为None且提供了meta_info，将使用匿名密钥
        password : bytes | None
            私钥密码，如果私钥加密则需要提供
        meta_info_expires_in : int
            MetaInfo JWT token过期时间（秒），默认3600秒
        app_name : str | None
            应用名称，通过 X-APP-NAME 头传递给服务端
        """
        super().__init__(
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            meta_info=meta_info,
            private_key_path=private_key_path,
            password=password,
            meta_info_expires_in=meta_info_expires_in,
            app_name=app_name,
        )

    async def search_tools(
        self,
        query: str,
        top_k: int = 3,
    ) -> SearchResponse:
        """搜索工具接口。

        根据语义搜索工具，返回匹配的工具定义。

        Parameters
        ----------
        query : str
            搜索查询字符串
        top_k : int
            返回的最大工具数量，默认为3

        Returns
        -------
        SearchResponse
            搜索响应，包含匹配的工具列表

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     response = await client.search_tools("查询天气", top_k=5)
        ...     for tool in response.tools:
        ...         print(f"Tool: {tool.name} - {tool.desc}")
        """
        path = "/api/search"
        params = {"query": query, "top_k": top_k}

        logger.debug(f"Searching tools with query: {query}, top_k: {top_k}")

        try:
            response = await self.get(path, params=params)
            response.raise_for_status()

            data = response.json()
            search_response = SearchResponse.model_validate(data)

            logger.debug(f"Found {len(search_response.tools)} tools")
            return search_response

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during tool search: {e}")
            raise
        except Exception as e:
            logger.error(f"Error parsing search response: {e}")
            raise ValueError(f"Invalid search response format: {e}") from e

    async def list_tools(self) -> ToolsListResponse:
        """列出所有工具接口。

        返回所有已注册的工具及其详细信息，包括工具名称、描述、
        参数定义和调用统计。

        Returns
        -------
        ToolsListResponse
            工具列表响应，包含工具总数和工具列表

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     response = await client.list_tools()
        ...     print(f"Total: {response.total}")
        ...     for tool in response.tools:
        ...         print(f"Tool: {tool.name} - {tool.desc}")
        """
        path = "/api/tools"

        logger.debug("Listing all tools")

        try:
            response = await self.get(path)
            response.raise_for_status()

            data = response.json()
            result = ToolsListResponse.model_validate(data)

            logger.debug(f"Found {result.total} tools")
            return result

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during list tools: {e}")
            raise
        except Exception as e:
            logger.error(f"Error parsing list tools response: {e}")
            raise ValueError(f"Invalid list tools response format: {e}") from e

    async def get_tool_groups(self) -> list[str]:
        """获取所有工具分组。

        返回所有已定义的工具分组列表，包括未分组的工具。

        Returns
        -------
        list[str]
            工具分组名称列表

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     groups = await client.get_tool_groups()
        ...     for group in groups:
        ...         print(f"Group: {group}")
        """
        path = "/api/tools/groups"

        logger.debug("Getting tool groups")

        try:
            response = await self.get(path)
            response.raise_for_status()

            data = response.json()
            if isinstance(data, list):
                groups = data
            elif isinstance(data, dict) and "groups" in data:
                groups = data["groups"]
            else:
                raise ValueError(f"Unexpected response format: {type(data)}")

            logger.debug(f"Found {len(groups)} tool groups")
            return groups

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during get tool groups: {e}")
            raise
        except ValueError:
            raise
        except Exception as e:
            logger.error(f"Error parsing tool groups response: {e}")
            raise ValueError(f"Invalid tool groups response format: {e}") from e

    async def get_tools_by_group(
        self,
        group: str | None = None,
    ) -> ToolsListResponse:
        """按分组获取工具。

        返回指定分组下的所有工具，或所有工具（当 group 为 None 时）。

        Parameters
        ----------
        group : str | None
            分组名称，如果不指定则返回所有工具

        Returns
        -------
        ToolsListResponse
            工具列表响应，包含工具总数和工具列表

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     response = await client.get_tools_by_group("餐饮/收入")
        ...     for tool in response.tools:
        ...         print(f"Tool: {tool.name}")
        """
        path = "/api/tools/by-group"
        params: dict[str, str] = {}
        if group is not None:
            params["group"] = group

        logger.debug(f"Getting tools by group: {group}")

        try:
            response = await self.get(path, params=params)
            response.raise_for_status()

            data = response.json()
            result = ToolsListResponse.model_validate(data)

            logger.debug(f"Found {result.total} tools in group '{group}'")
            return result

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during get tools by group: {e}")
            raise
        except Exception as e:
            logger.error(f"Error parsing tools by group response: {e}")
            raise ValueError(f"Invalid tools by group response format: {e}") from e

    async def get_tools_stats(self) -> dict[str, Any]:
        """获取工具调用统计汇总。

        返回所有工具的调用统计汇总信息，包括：
        总工具数、总调用数、成功率、未使用的工具列表、
        慢工具列表（平均耗时超过阈值）。

        Returns
        -------
        dict[str, Any]
            工具统计汇总信息

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     stats = await client.get_tools_stats()
        ...     print(f"Total tools: {stats.get('total_tools')}")
        ...     print(f"Success rate: {stats.get('success_rate')}")
        """
        path = "/api/tools/stats"

        logger.debug("Getting tools stats")

        try:
            response = await self.get(path)
            response.raise_for_status()

            data = response.json()

            logger.debug("Got tools stats")
            return data

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during get tools stats: {e}")
            raise
        except Exception as e:
            logger.error(f"Error parsing tools stats response: {e}")
            raise ValueError(f"Invalid tools stats response format: {e}") from e

    async def get_toolkits(
        self,
        include_tools: bool = False,
    ) -> ToolkitsResponse:
        """获取所有工具包。

        返回所有已注册的工具包及其摘要信息。

        Parameters
        ----------
        include_tools : bool
            是否包含每个工具包中的工具列表（默认 False）

        Returns
        -------
        ToolkitsResponse
            工具包列表响应，包含工具包总数和工具包列表

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     response = await client.get_toolkits(include_tools=True)
        ...     print(f"Total: {response.total}")
        ...     for tk in response.toolkits:
        ...         print(f"Toolkit: {tk.name} ({tk.tool_count} tools)")
        """
        path = "/api/toolkits"
        params: dict[str, str] = {}
        if include_tools:
            params["include_tools"] = "true"

        logger.debug(f"Getting toolkits (include_tools={include_tools})")

        try:
            response = await self.get(path, params=params)
            response.raise_for_status()

            data = response.json()
            result = ToolkitsResponse.model_validate(data)

            logger.debug(f"Found {result.total} toolkits")
            return result

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during get toolkits: {e}")
            raise
        except Exception as e:
            logger.error(f"Error parsing toolkits response: {e}")
            raise ValueError(f"Invalid toolkits response format: {e}") from e

    async def execute_tool(
        self,
        tool_name: str,
        args: dict[str, Any],
    ) -> ExecuteResponse:
        """执行工具接口。

        执行指定的工具并返回结果。

        Parameters
        ----------
        tool_name : str
            工具名称
        args : dict[str, Any]
            工具参数字典

        Returns
        -------
        ExecuteResponse
            执行响应，包含执行结果数据

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     response = await client.execute_tool(
        ...         tool_name="get_weather",
        ...         args={"city": "北京", "date": "2025-12-18"}
        ...     )
        ...     print(f"Result: {response.data}")
        """
        path = "/api/execute"

        # 构造请求
        request = ExecuteRequest(tool=tool_name, args=args)

        logger.debug(f"Executing tool: {tool_name} with args: {args}")

        try:
            response = await self.post(
                path,
                json=request.model_dump(),
            )
            response.raise_for_status()

            data = response.json()
            execute_response = ExecuteResponse.model_validate(data)

            logger.debug(f"Tool execution completed: {tool_name}")
            return execute_response

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during tool execution: {e}")
            raise
        except Exception as e:
            logger.error(f"Error parsing execution response: {e}")
            raise ValueError(f"Invalid execution response format: {e}") from e

    async def execute_tool_from_json(
        self,
        request_json: str,
    ) -> ExecuteResponse:
        """从JSON字符串执行工具接口。

        从JSON字符串构建ExecuteRequest并执行工具。

        Parameters
        ----------
        request_json : str
            JSON格式的执行请求字符串

        Returns
        -------
        ExecuteResponse
            执行响应，包含执行结果数据

        Raises
        ------
        httpx.HTTPError
            HTTP请求失败时抛出
        ValueError
            JSON格式错误或响应数据格式错误时抛出

        Examples
        --------
        >>> async with DataAPIClient() as client:
        ...     json_str = '{"tool": "get_weather", "args": {"city": "北京"}}'
        ...     response = await client.execute_tool_from_json(json_str)
        ...     print(f"Result: {response.data}")
        """
        path = "/api/execute"

        try:
            # 从JSON字符串构建请求
            request = ExecuteRequest.model_validate_json(request_json)
            logger.debug(f"Executing tool from JSON: {request.tool}")

            response = await self.post(
                path,
                json=request.model_dump(),
            )
            response.raise_for_status()

            data = response.json()
            execute_response = ExecuteResponse.model_validate(data)

            logger.debug(f"Tool execution completed: {request.tool}")
            return execute_response

        except httpx.HTTPError as e:
            logger.error(f"HTTP error during tool execution: {e}")
            raise
        except Exception as e:
            logger.error(f"Error parsing request or response: {e}")
            raise ValueError(f"Invalid JSON format or execution response: {e}") from e
