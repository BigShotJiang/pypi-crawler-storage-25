"""OAuth 主体（/oauth/authorize + /oauth/token + consent）相关错误类。

与 hezor2 ``hezor_core/api/oauth/_errors.py`` 的占位类一一对应；下游 R2
切换 import 后即可删除占位文件。
"""

from __future__ import annotations

from hezor_common.exceptions.base import HezorError


class OAuthError(HezorError):
    """OAuth 链路通用基类。"""


class ScopeNotAllowedError(OAuthError):
    """请求的 scope 不在 ``app_extensions.allowed_scopes`` 白名单内。"""

    def __init__(self, detail: str = "scope not allowed") -> None:
        super().__init__(code="invalid_scope", detail=detail, status_code=400)


class ToolkitSubscriptionRequiredError(OAuthError):
    """用户未订阅请求中的某个 toolkit。

    Notes
    -----
    与 ``SubscriptionRequiredError`` 的区别：本错误发生在 OAuth consent
    阶段（用户尚未拿到 token，需要先去订阅），返回 403 而非 402；
    ``SubscriptionRequiredError`` 则用于 token 已签发后调用受限资源被拦。
    """

    def __init__(self, detail: str = "toolkit subscription required") -> None:
        super().__init__(
            code="toolkit_subscription_required",
            detail=detail,
            status_code=403,
        )


class InvalidRedirectUriError(OAuthError):
    """``redirect_uri`` 不在 Application 白名单内。"""

    def __init__(self, detail: str = "redirect_uri not registered") -> None:
        super().__init__(code="invalid_redirect_uri", detail=detail, status_code=400)


class ClientNotFoundError(OAuthError):
    """``client_id`` 不存在或未启用 OAuth 模式。"""

    def __init__(self, detail: str = "client not found or oauth disabled") -> None:
        super().__init__(code="invalid_client", detail=detail, status_code=400)


class InvalidGrantError(OAuthError):
    """授权码无效 / 已被使用 / 与签发上下文不匹配。"""

    def __init__(self, detail: str = "invalid or expired authorization code") -> None:
        super().__init__(code="invalid_grant", detail=detail, status_code=400)


__all__ = [
    "OAuthError",
    "ScopeNotAllowedError",
    "ToolkitSubscriptionRequiredError",
    "InvalidRedirectUriError",
    "ClientNotFoundError",
    "InvalidGrantError",
]
