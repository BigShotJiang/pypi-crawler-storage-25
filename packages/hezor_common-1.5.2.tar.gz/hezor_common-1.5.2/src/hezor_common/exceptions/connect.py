"""Connect 链路（私钥模式 + code 交换）相关错误类。

与 hezor2 ``hezor_core/api/connect_security/_errors.py`` 的占位类一一对应。
"""

from __future__ import annotations

from hezor_common.exceptions.base import HezorError


class ConnectError(HezorError):
    """Connect 链路通用基类。"""


class InvalidGrantError(ConnectError):
    """``connect_code`` 不存在 / 已被消费 / 与签发上下文不匹配。"""

    def __init__(self, detail: str = "invalid or expired connect_code") -> None:
        super().__init__(code="invalid_grant", detail=detail, status_code=400)


class AppMismatchError(ConnectError):
    """exchange 时传入的 ``app_name`` 与 code 签发上下文不一致。"""

    def __init__(self, detail: str = "app_name mismatch with issued code") -> None:
        super().__init__(code="invalid_grant", detail=detail, status_code=400)


__all__ = [
    "ConnectError",
    "InvalidGrantError",
    "AppMismatchError",
]
