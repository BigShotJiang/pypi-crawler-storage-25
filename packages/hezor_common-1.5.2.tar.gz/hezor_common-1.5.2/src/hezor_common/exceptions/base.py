"""Hezor 错误基类。

所有通用错误统一继承 ``HezorError``，便于上层在边界处一次性捕获。
"""

from __future__ import annotations


class HezorError(Exception):
    """Hezor 平台通用错误基类。

    Attributes
    ----------
    code : str
        OAuth 风格的短 token，跨语言稳定（如 ``invalid_scope``）。
    detail : str
        人类可读说明。
    status_code : int
        建议的 HTTP 状态码。

    Examples
    --------
    >>> err = HezorError(code="invalid_request", detail="missing client_id")
    >>> err.code
    'invalid_request'
    >>> err.status_code
    400
    """

    code: str
    detail: str
    status_code: int

    def __init__(self, *, code: str, detail: str, status_code: int = 400) -> None:
        super().__init__(detail)
        self.code = code
        self.detail = detail
        self.status_code = status_code


class SubscriptionRequiredError(HezorError):
    """402 Payment / Subscription Required。

    用户访问了一个需要订阅但当前未订阅的 toolkit / KB / 资源。
    hezor2-sdk ``BaseApiClient`` 拦截 402 时会构造本错误并触发
    ``onSubscriptionRequired`` 回调，由前端引导订阅。

    Examples
    --------
    >>> err = SubscriptionRequiredError(detail="toolkit weather not subscribed")
    >>> err.status_code
    402
    """

    def __init__(self, detail: str = "subscription required") -> None:
        super().__init__(
            code="subscription_required",
            detail=detail,
            status_code=402,
        )


__all__ = ["HezorError", "SubscriptionRequiredError"]
