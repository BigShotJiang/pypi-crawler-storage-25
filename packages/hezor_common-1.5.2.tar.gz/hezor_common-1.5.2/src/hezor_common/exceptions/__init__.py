"""Hezor 通用异常类。

本模块为下游仓（hezor2 / hezor2-sdk / starship）提供统一的错误类型定义，
覆盖 OAuth / Connect 等用户级授权链路。每个错误类都携带：

- ``code`` ：OAuth 风格的短 token（如 ``invalid_scope`` / ``invalid_grant``），
  用于跨语言序列化与前端 i18n 映射；
- ``detail`` ：人类可读说明；
- ``status_code`` ：建议的 HTTP 状态码，路由层可直接据此映射。

Notes
-----
- 异常类不强依赖 FastAPI / pydantic，纯 Python 即可使用；
- 业务方应捕获 ``HezorError`` 基类，再按 ``code`` 做细粒度分支；
- ``SubscriptionRequiredError`` 对应 HTTP 402，hezor2-sdk
  ``BaseApiClient`` 在 R1 引入 402 拦截后会触发 ``onSubscriptionRequired``。

Examples
--------
>>> from hezor_common.exceptions import oauth
>>> try:
...     raise oauth.ScopeNotAllowedError("kb:write")
... except oauth.OAuthError as exc:
...     exc.code, exc.status_code
('invalid_scope', 400)
"""

from hezor_common.exceptions.base import HezorError, SubscriptionRequiredError

from . import connect, oauth

__all__ = [
    "HezorError",
    "SubscriptionRequiredError",
    "oauth",
    "connect",
]
