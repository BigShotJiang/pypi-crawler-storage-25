"""DataHub SDK 工具列表与分组使用示例。

本示例演示通过 DataHub SDK 调用工具管理接口：

1. 列出所有工具（list_tools）
2. 获取工具分组（get_tool_groups）
3. 按分组获取工具（get_tools_by_group）
4. 获取工具统计信息（get_tools_stats）

Usage
-----
运行所有示例:
    uv run examples/transfer/datahub_sdk/tools_example.py

运行指定示例:
    uv run examples/transfer/datahub_sdk/tools_example.py 1
    uv run examples/transfer/datahub_sdk/tools_example.py 2

列出所有示例:
    uv run examples/transfer/datahub_sdk/tools_example.py --list
"""

import asyncio
import json
import logging
import sys
from pathlib import Path

from dotenv import load_dotenv

# ⚠️ 重要：必须在导入 SDK 之前加载环境变量
# 因为 constants.py 在模块导入时会读取环境变量创建默认值
env_file = Path(__file__).parent.parent.parent / ".env"
load_dotenv(dotenv_path=env_file)

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from hezor_common.transfer.datahub_sdk import DatahubSDK, MetaInfo  # noqa: E402
from hezor_common.transfer.datahub_sdk.env_config import DataHubEnvConfig  # noqa: E402

logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

print(f"✓ 已加载环境变量: {env_file}")
print()

config = DataHubEnvConfig()
print(f"✓ API Base URL: {config.datahub_api_base_url}")
print()


def example_1_list_tools():
    """Example 1: 列出所有工具。"""
    print("=== Example 1: 列出所有工具 ===")
    print()

    async def run():
        async with DatahubSDK() as sdk:
            response = await sdk.list_tools()
            print(f"✓ 工具总数: {response.total}")
            print()
            for tool in response.tools:
                group_info = f" [{tool.group}]" if tool.group else ""
                stats_info = ""
                if tool.stats:
                    total_calls = tool.stats.success_count + tool.stats.failure_count
                    stats_info = f" (调用 {total_calls} 次)"
                print(f"  - {tool.name}{group_info}{stats_info}")
                print(f"    描述: {tool.desc}")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


def example_2_get_tool_groups():
    """Example 2: 获取所有工具分组。"""
    print("=== Example 2: 获取所有工具分组 ===")
    print()

    async def run():
        async with DatahubSDK() as sdk:
            groups = await sdk.get_tool_groups()
            print(f"✓ 分组总数: {len(groups)}")
            print()
            for group in groups:
                print(f"  - {group}")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


def example_3_get_tools_by_group():
    """Example 3: 按分组获取工具。"""
    print("=== Example 3: 按分组获取工具 ===")
    print()

    async def run():
        async with DatahubSDK() as sdk:
            # 先获取分组列表
            groups = await sdk.get_tool_groups()
            if not groups:
                print("✗ 没有可用的分组")
                return

            # 获取第一个分组的工具
            target_group = groups[0]
            print(f"✓ 查询分组: {target_group}")
            print()

            response = await sdk.get_tools_by_group(target_group)
            print(f"✓ 该分组下工具数: {response.total}")
            print()
            for tool in response.tools:
                print(f"  - {tool.name}")
                print(f"    描述: {tool.desc}")
                if tool.db_deps:
                    print(f"    数据库依赖: {', '.join(tool.db_deps)}")

            # 也演示不传分组参数的情况
            print()
            print("--- 不传分组参数（返回所有工具）---")
            all_response = await sdk.get_tools_by_group()
            print(f"✓ 所有工具数: {all_response.total}")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


def example_4_get_tools_stats():
    """Example 4: 获取工具统计信息。"""
    print("=== Example 4: 获取工具统计信息 ===")
    print()

    async def run():
        async with DatahubSDK() as sdk:
            stats = await sdk.get_tools_stats()
            print("✓ 工具统计汇总:")
            print()
            print(json.dumps(stats, indent=2, ensure_ascii=False))

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


def example_5_get_toolkits():
    """Example 5: 获取所有工具包。"""
    print("=== Example 5: 获取所有工具包 ===")
    print()

    async def run():
        async with DatahubSDK() as sdk:
            # 不含工具列表
            response = await sdk.get_toolkits()
            print(f"✓ 工具包总数: {response.total}")
            print()
            for tk in response.toolkits:
                print(f"  - {tk.name} (id: {tk.id})")
                print(f"    摘要: {tk.summary}")
                print(f"    工具数: {tk.tool_count}")

            # 含工具列表（include_tools=True）
            print()
            print("--- 使用 include_tools=True 获取第一个工具包的工具列表 ---")
            print()
            response_with_tools = await sdk.get_toolkits(include_tools=True)
            first_tk = response_with_tools.toolkits[0]
            print(f"  工具包: {first_tk.name}")
            tools = first_tk.tools or []
            print(f"  包含 {len(tools)} 个工具")
            for tool in tools[:5]:
                print(f"    - {tool.name}: {tool.desc[:40]}...")
            if len(tools) > 5:
                print(f"    ... 还有 {len(tools) - 5} 个工具")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


def example_6_list_tools_with_auth():
    """Example 6: 使用认证获取工具列表。"""
    print("=== Example 6: 使用认证获取工具列表 ===")
    print()

    # 检查 private key 文件是否存在
    if not config.datahub_header_pk_filepath:
        print("✗ 环境变量未设置 DATAHUB_HEADER_PK_FILEPATH！")
        print("  请在 examples/.env 中设置该配置项")
        print()
        return

    private_key_path = Path(config.datahub_header_pk_filepath)
    if not private_key_path.is_absolute():
        examples_dir = Path(__file__).parent.parent.parent
        private_key_path = examples_dir / private_key_path

    if not private_key_path.exists():
        print("✗ Private key 文件不存在！")
        print(f"  期望路径: {private_key_path}")
        print()
        return

    print(f"✓ 找到 private key: {private_key_path}")
    print()

    meta_info = MetaInfo(
        caller_id="example/tools",
        subject="示例租户",
        subject_code="example_tenant",
    )

    async def run():
        async with DatahubSDK(
            base_url=config.datahub_api_base_url,
            api_key=config.datahub_api_key,
            meta_info=meta_info,
            private_key_path=str(private_key_path),
            password=config.datahub_header_pk_password.encode()
            if config.datahub_header_pk_password
            else None,
        ) as sdk:
            response = await sdk.list_tools()
            print(f"✓ 工具总数: {response.total}")
            print()
            for tool in response.tools[:5]:
                print(f"  - {tool.name}: {tool.desc}")
            if response.total > 5:
                print(f"  ... 还有 {response.total - 5} 个工具")

    try:
        asyncio.run(run())
    except Exception as e:
        print(f"调用失败（需要连接 DataHub API）: {e}")

    print()


# 列出和主函数
def list_examples():
    """列出所有可用示例。"""
    examples = {
        1: ("列出所有工具", example_1_list_tools),
        2: ("获取工具分组", example_2_get_tool_groups),
        3: ("按分组获取工具", example_3_get_tools_by_group),
        4: ("获取工具统计信息", example_4_get_tools_stats),
        5: ("获取所有工具包", example_5_get_toolkits),
        6: ("使用认证获取工具列表", example_6_list_tools_with_auth),
    }

    print("可用示例:")
    for num, (name, _) in examples.items():
        print(f"  {num}. {name}")
    print()
    print("使用方法:")
    print(f"  uv run {sys.argv[0]} [示例编号]")
    print(f"  uv run {sys.argv[0]}              # 运行所有示例")
    print(f"  uv run {sys.argv[0]} --list       # 列出示例")

    return examples


def main():
    """运行示例。"""
    examples = {
        1: ("列出所有工具", example_1_list_tools),
        2: ("获取工具分组", example_2_get_tool_groups),
        3: ("按分组获取工具", example_3_get_tools_by_group),
        4: ("获取工具统计信息", example_4_get_tools_stats),
        5: ("获取所有工具包", example_5_get_toolkits),
        6: ("使用认证获取工具列表", example_6_list_tools_with_auth),
    }

    # 解析命令行参数
    if len(sys.argv) > 1:
        arg = sys.argv[1]

        if arg in ["--list", "-l", "list"]:
            list_examples()
            return

        try:
            example_num = int(arg)
            if example_num not in examples:
                print(f"错误: 示例 {example_num} 不存在。")
                print()
                list_examples()
                sys.exit(1)

            # 运行单个示例
            name, func = examples[example_num]
            print("=" * 60)
            print(f"DataHub SDK Tools - 示例 {example_num}")
            print("=" * 60)
            print()
            func()
            print("=" * 60)
            print(f"示例 {example_num} 完成！")
            print("=" * 60)
            return

        except ValueError:
            print(f"错误: 无效的参数 '{arg}'")
            print()
            list_examples()
            sys.exit(1)

    # 运行所有示例
    print("=" * 60)
    print("DataHub SDK Tools - 使用示例")
    print("=" * 60)
    print()

    for func in [
        example_1_list_tools,
        example_2_get_tool_groups,
        example_3_get_tools_by_group,
        example_4_get_tools_stats,
        example_5_get_toolkits,
        example_6_list_tools_with_auth,
    ]:
        func()

    print("=" * 60)
    print("所有示例完成！")
    print("=" * 60)


if __name__ == "__main__":
    main()
