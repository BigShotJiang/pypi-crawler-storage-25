"""``hezor_common.exceptions`` 单测。

覆盖 OAuth / Connect 错误类的基本属性、HTTP 状态码映射，以及 402
``SubscriptionRequiredError``。
"""

from __future__ import annotations

from collections.abc import Callable

import pytest

from hezor_common.exceptions import (
    HezorError,
    SubscriptionRequiredError,
    connect,
    oauth,
)


class TestHezorError:
    """``HezorError`` 基类。"""

    def test_attributes(self) -> None:
        err = HezorError(code="invalid_request", detail="missing client_id")
        assert err.code == "invalid_request"
        assert err.detail == "missing client_id"
        assert err.status_code == 400
        assert str(err) == "missing client_id"

    def test_custom_status_code(self) -> None:
        err = HezorError(code="server_error", detail="boom", status_code=500)
        assert err.status_code == 500


class TestSubscriptionRequiredError:
    """402 拦截入口。"""

    def test_default(self) -> None:
        err = SubscriptionRequiredError()
        assert err.code == "subscription_required"
        assert err.status_code == 402
        assert isinstance(err, HezorError)

    def test_custom_detail(self) -> None:
        err = SubscriptionRequiredError("toolkit weather not subscribed")
        assert err.detail == "toolkit weather not subscribed"


class TestOAuthErrors:
    """OAuth 错误类。"""

    @pytest.mark.parametrize(
        ("cls", "expected_code", "expected_status"),
        [
            (oauth.ScopeNotAllowedError, "invalid_scope", 400),
            (oauth.ToolkitSubscriptionRequiredError, "toolkit_subscription_required", 403),
            (oauth.InvalidRedirectUriError, "invalid_redirect_uri", 400),
            (oauth.ClientNotFoundError, "invalid_client", 400),
            (oauth.InvalidGrantError, "invalid_grant", 400),
        ],
    )
    def test_codes_and_status(
        self,
        cls: Callable[[], oauth.OAuthError],
        expected_code: str,
        expected_status: int,
    ) -> None:
        err = cls()
        assert err.code == expected_code
        assert err.status_code == expected_status
        assert isinstance(err, oauth.OAuthError)
        assert isinstance(err, HezorError)


class TestConnectErrors:
    """Connect 错误类。"""

    @pytest.mark.parametrize(
        ("cls", "expected_code", "expected_status"),
        [
            (connect.InvalidGrantError, "invalid_grant", 400),
            (connect.AppMismatchError, "invalid_grant", 400),
        ],
    )
    def test_codes_and_status(
        self,
        cls: Callable[[], connect.ConnectError],
        expected_code: str,
        expected_status: int,
    ) -> None:
        err = cls()
        assert err.code == expected_code
        assert err.status_code == expected_status
        assert isinstance(err, connect.ConnectError)
        assert isinstance(err, HezorError)
