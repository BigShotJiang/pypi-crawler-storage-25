"""MetaInfo ``auth_mode`` / ``grant_version`` 兼容性单测。

确保旧序列化数据反序列化通过、新字段可选、空值默认行为不变。
"""

from __future__ import annotations

from hezor_common.transfer.base_sdk import MetaInfo
from hezor_common.transfer.base_sdk.constants import (
    META_AUTH_MODE_OAUTH,
    META_AUTH_MODE_PRIVATE_KEY,
)


def _legacy_payload() -> dict:
    """旧版本（v1.3.x）序列化形态：无 ``auth_mode`` / ``grant_version``。"""
    return {
        "subject": "鮨大山",
        "subject_code": "wdyl_001",
        "caller_id": "user_123",
        "data_coverage": "202401-202412",
        "creation_slug": "single_store_profit_model",
        "creation_name": "单店盈利模型",
    }


class TestMetaInfoLegacyCompatibility:
    """旧序列化数据反序列化必须通过。"""

    def test_legacy_payload_loads(self) -> None:
        meta = MetaInfo.model_validate(_legacy_payload())
        assert meta.auth_mode is None
        assert meta.grant_version is None

    def test_new_fields_default_none(self) -> None:
        meta = MetaInfo(
            subject="x",
            subject_code="y",
            caller_id="z",
        )
        assert meta.auth_mode is None
        assert meta.grant_version is None

    def test_dump_includes_new_fields(self) -> None:
        meta = MetaInfo.model_validate(_legacy_payload())
        dumped = meta.model_dump()
        assert "auth_mode" in dumped
        assert "grant_version" in dumped
        assert dumped["auth_mode"] is None
        assert dumped["grant_version"] is None


class TestMetaInfoOAuthMode:
    """OAuth 模式下的字段语义。"""

    def test_oauth_mode_with_grant_version(self) -> None:
        payload = _legacy_payload() | {
            "auth_mode": META_AUTH_MODE_OAUTH,
            "grant_version": 3,
        }
        meta = MetaInfo.model_validate(payload)
        assert meta.auth_mode == "oauth"
        assert meta.grant_version == 3

    def test_private_key_mode_constant(self) -> None:
        meta = MetaInfo(
            subject="x",
            subject_code="y",
            caller_id="z",
            auth_mode=META_AUTH_MODE_PRIVATE_KEY,
        )
        assert meta.auth_mode == "private_key"
