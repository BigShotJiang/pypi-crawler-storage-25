"""E2E tests for ``cloudagent sessions`` commands."""

from __future__ import annotations

import json

from cloudagent_cli.main import app as cli_app
from tests.e2e.conftest import make_event, make_session, runner


class TestSessionsCreate:
    def test_create_success(self, mock_api, invoke):
        session = make_session()
        mock_api.post("/v1/sessions").respond(status_code=201, json=session)

        result = invoke(
            "sessions", "create",
            "--agent", "agent_cli-test-001",
        )
        assert result.exit_code == 0
        assert "sess_cli-test-001" in result.output

    def test_create_with_title(self, mock_api, invoke):
        session = make_session(title="cli-test-title")
        mock_api.post("/v1/sessions").respond(status_code=201, json=session)

        result = invoke(
            "sessions", "create",
            "--agent", "agent_cli-test-001",
            "--title", "cli-test-title",
        )
        assert result.exit_code == 0

    def test_create_with_environment(self, mock_api, invoke):
        session = make_session(environment_id="env_cli-test-001")
        mock_api.post("/v1/sessions").respond(status_code=201, json=session)

        result = invoke(
            "sessions", "create",
            "--agent", "agent_cli-test-001",
            "--environment", "env_cli-test-001",
        )
        assert result.exit_code == 0

    def test_create_missing_agent(self, invoke):
        """--agent is required."""
        result = invoke("sessions", "create")
        assert result.exit_code != 0

    def test_create_json_output(self, mock_api, invoke):
        session = make_session()
        mock_api.post("/v1/sessions").respond(status_code=201, json=session)

        result = invoke(
            "sessions", "create",
            "--agent", "agent_cli-test-001",
            "--json",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["id"] == "sess_cli-test-001"


class TestSessionsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/sessions").respond(
            json={"data": [make_session()], "next_page": None}
        )
        result = invoke("sessions", "list")
        assert result.exit_code == 0
        assert "sess_cli-test-001" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/sessions").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("sessions", "list")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/sessions").respond(
            json={"data": [make_session()], "next_page": None}
        )
        result = invoke("sessions", "list", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)


class TestSessionsGet:
    def test_get_success(self, mock_api, invoke):
        session = make_session()
        mock_api.get("/v1/sessions/sess_cli-test-001").respond(json=session)

        result = invoke("sessions", "get", "sess_cli-test-001")
        assert result.exit_code == 0
        assert "sess_cli-test-001" in result.output

    def test_get_not_found(self, mock_api, invoke):
        mock_api.get("/v1/sessions/sess_nonexistent").respond(
            status_code=404, json={"detail": "Session not found"}
        )
        result = invoke("sessions", "get", "sess_nonexistent")
        assert result.exit_code != 0

    def test_get_json_output(self, mock_api, invoke):
        session = make_session()
        mock_api.get("/v1/sessions/sess_cli-test-001").respond(json=session)

        result = invoke("sessions", "get", "sess_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["status"] == "active"


class TestSessionsSend:
    def test_send_with_agent_reply(self, mock_api, invoke):
        """send message -> poll events -> find agent.message -> print reply."""
        # POST events (send user message)
        mock_api.post("/v1/sessions/sess_cli-test-001/events").respond(
            json={"data": [{"id": "ev_001", "type": "user.message"}]}
        )
        # GET events (poll for reply) — return an agent.message
        mock_api.get("/v1/sessions/sess_cli-test-001/events").respond(
            json={
                "data": [
                    {
                        "id": "ev_002",
                        "type": "agent.message",
                        "content": [{"type": "text", "text": "Hello from agent!"}],
                        "processed_at": "2026-04-16T00:00:02Z",
                    },
                ],
                "next_page": None,
            }
        )

        result = invoke("sessions", "send", "sess_cli-test-001", "Hello")
        assert result.exit_code == 0
        assert "Hello from agent!" in result.output

    def test_send_json_output(self, mock_api, invoke):
        mock_api.post("/v1/sessions/sess_cli-test-001/events").respond(
            json={"data": [{"id": "ev_001", "type": "user.message"}]}
        )
        mock_api.get("/v1/sessions/sess_cli-test-001/events").respond(
            json={
                "data": [
                    {
                        "id": "ev_002",
                        "type": "agent.message",
                        "content": [{"type": "text", "text": "Agent reply"}],
                        "processed_at": "2026-04-16T00:00:02Z",
                    },
                ],
                "next_page": None,
            }
        )

        result = invoke("sessions", "send", "sess_cli-test-001", "Hi", "--json")
        assert result.exit_code == 0
        # The send command prints progress text ("Sending...", "Waiting...")
        # before the JSON block. Extract JSON from first '{' onward.
        raw = result.output
        json_start = raw.index("{")
        parsed = json.loads(raw[json_start:])
        assert parsed["reply"] == "Agent reply"

    def test_send_to_nonexistent_session(self, mock_api, invoke):
        mock_api.post("/v1/sessions/sess_nonexistent/events").respond(
            status_code=404, json={"detail": "Session not found"}
        )
        result = invoke("sessions", "send", "sess_nonexistent", "Hello")
        assert result.exit_code != 0


class TestSessionsEvents:
    def test_events_success(self, mock_api, invoke):
        events = {
            "data": [
                make_event("ev_001", "user.message"),
                make_event("ev_002", "agent.message"),
            ],
            "next_page": None,
        }
        mock_api.get("/v1/sessions/sess_cli-test-001/events").respond(json=events)

        result = invoke("sessions", "events", "sess_cli-test-001")
        assert result.exit_code == 0
        assert "ev_001" in result.output

    def test_events_json_output(self, mock_api, invoke):
        events = {"data": [make_event()], "next_page": None}
        mock_api.get("/v1/sessions/sess_cli-test-001/events").respond(json=events)

        result = invoke("sessions", "events", "sess_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)

    def test_events_not_found(self, mock_api, invoke):
        mock_api.get("/v1/sessions/sess_nonexistent/events").respond(
            status_code=404, json={"detail": "Session not found"}
        )
        result = invoke("sessions", "events", "sess_nonexistent")
        assert result.exit_code != 0
