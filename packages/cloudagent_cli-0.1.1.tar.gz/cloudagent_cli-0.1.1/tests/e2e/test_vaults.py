"""E2E tests for ``cloudagent vaults`` commands (vaults + credentials)."""

from __future__ import annotations

import json

from tests.e2e.conftest import make_credential, make_vault, runner


class TestVaultsCreate:
    def test_create_success(self, mock_api, invoke):
        vault = make_vault()
        mock_api.post("/v1/vaults").respond(status_code=201, json=vault)

        result = invoke("vaults", "create", "--name", "cli-test-vault")
        assert result.exit_code == 0
        assert "vault_cli-test-001" in result.output

    def test_create_missing_name(self, invoke):
        result = invoke("vaults", "create")
        assert result.exit_code != 0

    def test_create_json_output(self, mock_api, invoke):
        vault = make_vault()
        mock_api.post("/v1/vaults").respond(status_code=201, json=vault)

        result = invoke("vaults", "create", "--name", "cli-test-vault", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["id"] == "vault_cli-test-001"


class TestVaultsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [make_vault()], "next_page": None}
        )
        result = invoke("vaults", "list")
        assert result.exit_code == 0
        assert "cli-test-vault" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("vaults", "list")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [make_vault()], "next_page": None}
        )
        result = invoke("vaults", "list", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)


class TestVaultsGet:
    def test_get_success(self, mock_api, invoke):
        vault = make_vault()
        mock_api.get("/v1/vaults/vault_cli-test-001").respond(json=vault)

        result = invoke("vaults", "get", "vault_cli-test-001")
        assert result.exit_code == 0
        assert "cli-test-vault" in result.output

    def test_get_not_found(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_nonexistent").respond(
            status_code=404, json={"detail": "Vault not found"}
        )
        result = invoke("vaults", "get", "vault_nonexistent")
        assert result.exit_code != 0

    def test_get_json_output(self, mock_api, invoke):
        vault = make_vault()
        mock_api.get("/v1/vaults/vault_cli-test-001").respond(json=vault)

        result = invoke("vaults", "get", "vault_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["display_name"] == "cli-test-vault"


class TestCredentialsCreate:
    def test_create_success(self, mock_api, invoke):
        cred = make_credential()
        mock_api.post("/v1/vaults/vault_cli-test-001/credentials").respond(
            status_code=201, json=cred
        )

        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
        )
        assert result.exit_code == 0
        assert "cred_cli-test-001" in result.output

    def test_create_missing_name(self, invoke):
        result = invoke("vaults", "credentials-create", "vault_cli-test-001")
        assert result.exit_code != 0

    def test_create_json_output(self, mock_api, invoke):
        cred = make_credential()
        mock_api.post("/v1/vaults/vault_cli-test-001/credentials").respond(
            status_code=201, json=cred
        )

        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--json",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["id"] == "cred_cli-test-001"


class TestCredentialsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_cli-test-001/credentials").respond(
            json={"data": [make_credential()], "next_page": None}
        )
        result = invoke("vaults", "credentials-list", "vault_cli-test-001")
        assert result.exit_code == 0
        assert "cli-test-cred" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_cli-test-001/credentials").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("vaults", "credentials-list", "vault_cli-test-001")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_cli-test-001/credentials").respond(
            json={"data": [make_credential()], "next_page": None}
        )
        result = invoke(
            "vaults", "credentials-list", "vault_cli-test-001", "--json"
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)
