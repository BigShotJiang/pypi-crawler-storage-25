"""E2E tests for ``cloudagent models`` commands."""

from __future__ import annotations

import json

from tests.e2e.conftest import make_model_registration, runner


class TestModelsRegister:
    def test_register_success(self, mock_api, invoke):
        reg = make_model_registration()
        mock_api.post("/v1/models").respond(status_code=201, json=reg)

        result = invoke(
            "models", "register",
            "--provider", "dashscope",
            "--model", "qwen-turbo",
            "--api-key", "sk-cli-test-dashscope",
        )
        assert result.exit_code == 0
        assert "modreg_cli-test-001" in result.output

    def test_register_with_display_name(self, mock_api, invoke):
        reg = make_model_registration(display_name="cli-test-display")
        mock_api.post("/v1/models").respond(status_code=201, json=reg)

        result = invoke(
            "models", "register",
            "--provider", "dashscope",
            "--model", "qwen-turbo",
            "--api-key", "sk-cli-test-dashscope",
            "--display-name", "cli-test-display",
        )
        assert result.exit_code == 0

    def test_register_with_base_url(self, mock_api, invoke):
        reg = make_model_registration(base_url="https://custom.api/v1")
        mock_api.post("/v1/models").respond(status_code=201, json=reg)

        result = invoke(
            "models", "register",
            "--provider", "dashscope",
            "--model", "qwen-turbo",
            "--api-key", "sk-cli-test-dashscope",
            "--base-url", "https://custom.api/v1",
        )
        assert result.exit_code == 0

    def test_register_missing_provider(self, invoke):
        result = invoke(
            "models", "register",
            "--model", "qwen-turbo",
            "--api-key", "sk-test",
        )
        assert result.exit_code != 0

    def test_register_missing_model(self, invoke):
        result = invoke(
            "models", "register",
            "--provider", "dashscope",
            "--api-key", "sk-test",
        )
        assert result.exit_code != 0

    def test_register_missing_api_key(self, invoke):
        result = invoke(
            "models", "register",
            "--provider", "dashscope",
            "--model", "qwen-turbo",
        )
        assert result.exit_code != 0

    def test_register_json_output(self, mock_api, invoke):
        reg = make_model_registration()
        mock_api.post("/v1/models").respond(status_code=201, json=reg)

        result = invoke(
            "models", "register",
            "--provider", "dashscope",
            "--model", "qwen-turbo",
            "--api-key", "sk-cli-test-dashscope",
            "--json",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["provider"] == "dashscope"


class TestModelsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/models").respond(
            json={"data": [make_model_registration()]}
        )
        result = invoke("models", "list")
        assert result.exit_code == 0
        assert "qwen-turbo" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/models").respond(json={"data": []})
        result = invoke("models", "list")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/models").respond(
            json={"data": [make_model_registration()]}
        )
        result = invoke("models", "list", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)


class TestModelsAvailable:
    def test_available_success(self, mock_api, invoke):
        mock_api.get("/v1/models/available").respond(
            json={
                "data": [
                    {
                        "model_id": "qwen3.6-plus",
                        "provider": "dashscope",
                        "display_name": "Qwen 3.6 Plus",
                        "status": "available",
                        "source": "system",
                    },
                    {
                        "model_id": "gpt-4o",
                        "provider": "openai",
                        "display_name": "GPT-4o",
                        "status": "not_configured",
                        "source": "known",
                    },
                ]
            }
        )
        result = invoke("models", "available")
        assert result.exit_code == 0
        assert "qwen3.6-plus" in result.output

    def test_available_json_output(self, mock_api, invoke):
        mock_api.get("/v1/models/available").respond(
            json={"data": []}
        )
        result = invoke("models", "available", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)
