"""Tests for the HTTP client wrapper."""

from __future__ import annotations

import httpx
import pytest

from cloudagent_cli.client import CloudAgentClient, CloudAgentError


def _mock_client(respx_mock, method, path, json_body, status=200):
    """Register a mock route and return a client."""
    route = getattr(respx_mock, method)(url__regex=f".*{path}.*")
    route.respond(status_code=status, json=json_body)
    return CloudAgentClient(api_key="sk-test", base_url="https://mock.api")


class TestCloudAgentClient:
    def test_no_api_key_raises(self, monkeypatch):
        monkeypatch.setattr("cloudagent_cli.client.get_api_key", lambda: None)
        with pytest.raises(CloudAgentError, match="No API key"):
            CloudAgentClient()

    def test_create_agent(self, respx_mock):
        respx_mock.post(url__regex=r".*/v1/agents.*").respond(
            status_code=201,
            json={"id": "agent_001", "name": "test"},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.create_agent(name="test", model="qwen3.6-plus")
        assert result["id"] == "agent_001"

    def test_list_agents(self, respx_mock):
        respx_mock.get(url__regex=r".*/v1/agents.*").respond(
            json={"data": [{"id": "a1"}], "next_page": None},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.list_agents()
        assert len(result["data"]) == 1

    def test_error_handling(self, respx_mock):
        respx_mock.get(url__regex=r".*/v1/agents.*").respond(
            status_code=401,
            json={"detail": "Unauthorized"},
        )
        client = CloudAgentClient(api_key="sk-bad", base_url="https://mock.api")
        with pytest.raises(CloudAgentError, match="401"):
            client.list_agents()

    def test_create_session(self, respx_mock):
        respx_mock.post(url__regex=r".*/v1/sessions.*").respond(
            status_code=201,
            json={"id": "sess_001", "agent_id": "agent_001"},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.create_session(agent_id="agent_001")
        assert result["id"] == "sess_001"

    def test_send_events(self, respx_mock):
        respx_mock.post(url__regex=r".*/v1/sessions/.*/events.*").respond(
            json={"events": [{"id": "ev_001", "type": "user.message"}]},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.send_events("sess_001", [{"type": "user.message", "content": [{"type": "text", "text": "hi"}]}])
        assert result["events"][0]["id"] == "ev_001"

    def test_list_environments(self, respx_mock):
        respx_mock.get(url__regex=r".*/v1/environments.*").respond(
            json={"data": [], "next_page": None},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.list_environments()
        assert result["data"] == []

    def test_create_vault(self, respx_mock):
        respx_mock.post(url__regex=r".*/v1/vaults.*").respond(
            status_code=201,
            json={"id": "vault_001", "display_name": "test"},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.create_vault(display_name="test")
        assert result["id"] == "vault_001"

    def test_list_models(self, respx_mock):
        respx_mock.get(url__regex=r".*/v1/models$").respond(
            json={"data": [{"id": "m1", "provider": "anthropic"}]},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.list_models()
        assert len(result["data"]) == 1

    def test_list_files(self, respx_mock):
        respx_mock.get(url__regex=r".*/v1/files.*").respond(
            json={"data": [], "next_page": None},
        )
        client = CloudAgentClient(api_key="sk-test", base_url="https://mock.api")
        result = client.list_files()
        assert result["data"] == []
