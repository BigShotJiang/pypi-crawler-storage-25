"""Tests for CLI command parsing and help output."""

from __future__ import annotations

from typer.testing import CliRunner

from cloudagent_cli.main import app

runner = CliRunner()


class TestMainHelp:
    def test_main_help(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "cloudagent" in result.output.lower() or "CloudAgent" in result.output
        # All subcommands should appear
        for cmd in ("auth", "agents", "sessions", "environments", "vaults", "models", "files"):
            assert cmd in result.output


class TestSubcommandHelp:
    """Each subcommand group shows its own help."""

    def test_agents_help(self):
        result = runner.invoke(app, ["agents", "--help"])
        assert result.exit_code == 0
        for sub in ("create", "list", "get", "update", "archive", "versions"):
            assert sub in result.output

    def test_sessions_help(self):
        result = runner.invoke(app, ["sessions", "--help"])
        assert result.exit_code == 0
        for sub in ("create", "list", "get", "send", "events"):
            assert sub in result.output

    def test_environments_help(self):
        result = runner.invoke(app, ["environments", "--help"])
        assert result.exit_code == 0
        for sub in ("create", "list", "get"):
            assert sub in result.output

    def test_vaults_help(self):
        result = runner.invoke(app, ["vaults", "--help"])
        assert result.exit_code == 0
        for sub in ("create", "list", "get", "credentials-create", "credentials-list"):
            assert sub in result.output

    def test_models_help(self):
        result = runner.invoke(app, ["models", "--help"])
        assert result.exit_code == 0
        for sub in ("register", "list", "available"):
            assert sub in result.output

    def test_files_help(self):
        result = runner.invoke(app, ["files", "--help"])
        assert result.exit_code == 0
        for sub in ("upload", "list", "get"):
            assert sub in result.output

    def test_auth_help(self):
        result = runner.invoke(app, ["auth", "--help"])
        assert result.exit_code == 0
        for sub in ("login", "status", "logout"):
            assert sub in result.output


class TestAuthCommands:
    def test_login_with_key(self, tmp_path, monkeypatch):
        cfg_file = tmp_path / "config.json"
        monkeypatch.setattr("cloudagent_cli.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("cloudagent_cli.config.CONFIG_FILE", cfg_file)
        monkeypatch.setattr("cloudagent_cli.commands.auth.load_config", lambda: {})
        monkeypatch.setattr("cloudagent_cli.commands.auth.save_config", lambda c: None)
        result = runner.invoke(app, ["auth", "login", "--api-key", "sk-test-xyz"])
        assert result.exit_code == 0

    def test_logout(self, monkeypatch):
        deleted = []
        monkeypatch.setattr("cloudagent_cli.commands.auth.delete_config", lambda: deleted.append(True))
        result = runner.invoke(app, ["auth", "logout"])
        assert result.exit_code == 0
        assert len(deleted) == 1
