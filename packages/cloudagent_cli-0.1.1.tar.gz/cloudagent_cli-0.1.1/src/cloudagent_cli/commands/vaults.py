"""Vault and credential commands."""

from __future__ import annotations

from typing import Optional

import typer

from cloudagent_cli.client import CloudAgentClient, CloudAgentError
from cloudagent_cli.output import bail, print_detail, print_json, print_table

app = typer.Typer(no_args_is_help=True)

JSON_FLAG = typer.Option(False, "--json", "-j", help="Output raw JSON.")

VAULT_COLUMNS = ["id", "display_name", "created_at"]
CRED_COLUMNS = ["id", "vault_id", "display_name", "created_at"]


def _client() -> CloudAgentClient:
    try:
        return CloudAgentClient()
    except CloudAgentError as e:
        bail(str(e))
        raise


# ---------- Vault CRUD ----------


@app.command("create")
def create_vault(
    name: str = typer.Option(..., "--name", "-n", help="Vault display name."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Create a new vault."""
    client = _client()
    try:
        data = client.create_vault(display_name=name)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, VAULT_COLUMNS)


@app.command("list")
def list_vaults(
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List vaults."""
    client = _client()
    try:
        data = client.list_vaults(limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), VAULT_COLUMNS)


@app.command("get")
def get_vault(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Get vault details."""
    client = _client()
    try:
        data = client.get_vault(vault_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data)


# ---------- Credentials ----------


@app.command("credentials-create")
def create_credential(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    display_name: str = typer.Option(..., "--name", "-n", help="Credential display name."),
    auth_type: str = typer.Option(..., "--auth-type", "-t", help="Auth type: static_bearer or mcp_oauth."),
    token: Optional[str] = typer.Option(None, "--token", help="Bearer token (for static_bearer)."),
    access_token: Optional[str] = typer.Option(None, "--access-token", help="OAuth access token (for mcp_oauth)."),
    mcp_server_url: str = typer.Option(..., "--mcp-server-url", "-s", help="MCP server URL."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Create a credential in a vault."""
    if auth_type == "static_bearer":
        if not token:
            bail("--token is required for static_bearer auth type.")
            return
        auth: dict = {"type": "static_bearer", "token": token, "mcp_server_url": mcp_server_url}
    elif auth_type == "mcp_oauth":
        if not access_token:
            bail("--access-token is required for mcp_oauth auth type.")
            return
        auth = {"type": "mcp_oauth", "access_token": access_token, "mcp_server_url": mcp_server_url}
    else:
        bail(f"Unknown auth type: {auth_type}. Use 'static_bearer' or 'mcp_oauth'.")
        return
    client = _client()
    try:
        data = client.create_credential(vault_id, display_name=display_name, auth=auth)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, CRED_COLUMNS)


@app.command("credentials-list")
def list_credentials(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List credentials in a vault."""
    client = _client()
    try:
        data = client.list_credentials(vault_id, limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), CRED_COLUMNS)
