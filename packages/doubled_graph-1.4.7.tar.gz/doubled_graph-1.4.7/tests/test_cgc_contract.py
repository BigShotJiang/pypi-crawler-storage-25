"""Contract tests against the real codegraphcontext package.

Why this file exists separately from `test_smoke.py`:
    `test_smoke.py` mocks the entire CGC class — it does
    `monkeypatch.setattr(analyze_mod, "CGC", _FakeCGC)` so the wrapper's
    `_ensure()` never runs. That shape is correct for testing OUR logic
    in isolation, but it means upstream API drift in `codegraphcontext`
    goes uncaught until a user hits a `TypeError` in production.

    Concrete loss this file plugs: CGC 0.4 added two required positional
    args to `GraphBuilder.__init__` (`job_manager`, `loop`); doubled-graph
    1.0.9 still called `GraphBuilder(db)` and crashed at runtime. Nothing
    in the suite caught it because nothing exercised the real CGC.

These tests run the import path AND the real `_ensure()` against whatever
`codegraphcontext` is currently installed, plus signature snapshots of
every upstream symbol our wrapper depends on. If CGC changes a constructor
or drops a method we call, this file is where it shows up — at `pytest`
time, not at user runtime.

The whole module is skipped if `codegraphcontext` isn't importable, so
CI without the dep (or with a broken transitive) stays green and we
don't inflate the smoke suite's setup cost.
"""

from __future__ import annotations

import inspect
import subprocess
from pathlib import Path

import pytest

# Skip the entire module if CGC isn't importable in this env.
pytest.importorskip("codegraphcontext")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _required_positional_params(func) -> list[str]:
    """Return positional / positional-or-keyword params with no default, minus self.

    We deliberately ignore `*args` / `**kwargs` and keyword-only — the bug
    class we care about is "upstream added a required positional arg" or
    "removed one we were passing". Those are exactly POSITIONAL_OR_KEYWORD
    with no default.
    """
    sig = inspect.signature(func)
    out: list[str] = []
    for name, p in sig.parameters.items():
        if name == "self":
            continue
        if p.default is not inspect.Parameter.empty:
            continue
        if p.kind not in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            continue
        out.append(name)
    return out


# ---------------------------------------------------------------------------
# Signature snapshots — fast (microseconds), no DB or event loop needed.
#
# These are the cheap canary tests: if upstream rearranges `__init__` args
# of anything we construct, the right answer is "fail at pytest time, not
# in production". Each test names exactly which wrapper site the contract
# is keeping in sync, so the failure message points at the file to edit.
# ---------------------------------------------------------------------------


def test_graphbuilder_constructor_signature_matches_wrapper():
    """`integrations/cgc.py:_ensure` constructs `GraphBuilder(db, job_manager, loop)`.
    Pin that contract: any drift in required args fails here."""
    from codegraphcontext.tools.graph_builder import GraphBuilder

    required = _required_positional_params(GraphBuilder.__init__)
    assert required == ["db_manager", "job_manager", "loop"], (
        f"GraphBuilder.__init__ now requires {required}; "
        "doubled-graph integrations/cgc.py:_ensure passes (db, job_manager, loop). "
        "Update _ensure or pin codegraphcontext to a wrapper-compatible version."
    )


def test_codefinder_constructor_signature_matches_wrapper():
    """`integrations/cgc.py:_ensure` constructs `CodeFinder(db_manager)`."""
    from codegraphcontext.tools.code_finder import CodeFinder

    required = _required_positional_params(CodeFinder.__init__)
    assert required == ["db_manager"], (
        f"CodeFinder.__init__ now requires {required}; wrapper passes only db_manager. "
        "Update integrations/cgc.py:_ensure."
    )


def test_jobmanager_constructor_takes_no_required_args():
    """`integrations/cgc.py:_ensure` does `JobManager()` — no args."""
    from codegraphcontext.core.jobs import JobManager

    required = _required_positional_params(JobManager.__init__)
    assert required == [], (
        f"JobManager() now requires {required}; wrapper passes nothing. "
        "Update integrations/cgc.py:_ensure."
    )


def test_get_database_manager_takes_no_required_args():
    """`integrations/cgc.py:_ensure` calls `get_database_manager()` — no args."""
    from codegraphcontext.core import get_database_manager

    required = _required_positional_params(get_database_manager)
    assert required == [], (
        f"get_database_manager() now requires {required}; wrapper passes nothing."
    )


def test_graphbuilder_methods_we_call_exist():
    """Smoke-check the methods our wrapper invokes on `GraphBuilder`.

    Only checks attribute presence + callability — full signature pinning
    on every method would be too brittle (CGC adds optional args often).
    Catches the common "method renamed / removed" failure at pytest time.
    """
    from codegraphcontext.tools.graph_builder import GraphBuilder

    expected = [
        "add_repository_to_graph",   # called from analyze_full
        "delete_file_from_graph",    # called from analyze_incremental
        "parse_file",                # called from analyze_incremental
        "link_function_calls",       # called from analyze_incremental
        "link_inheritance",          # called from analyze_incremental
    ]
    missing = [name for name in expected if not callable(getattr(GraphBuilder, name, None))]
    assert not missing, (
        f"GraphBuilder dropped or renamed methods we depend on: {missing}. "
        "See integrations/cgc.py:analyze_full / analyze_incremental for callers."
    )


def test_codefinder_methods_we_call_exist():
    """Smoke-check methods our wrapper invokes on `CodeFinder`."""
    from codegraphcontext.tools.code_finder import CodeFinder

    expected = [
        "find_by_function_name",        # called from find_symbol
        "analyze_code_relationships",   # called from find_callers / find_callees
    ]
    missing = [name for name in expected if not callable(getattr(CodeFinder, name, None))]
    assert not missing, (
        f"CodeFinder dropped or renamed methods we depend on: {missing}. "
        "See integrations/cgc.py:find_symbol / find_callers / find_callees."
    )


# ---------------------------------------------------------------------------
# Real `_ensure()` integration — actually instantiates against installed CGC.
#
# Catches failures the signature tests can't see: e.g. a constructor that
# accepts the right args but raises during __init__ (schema creation, driver
# load, etc.). This is the test that would have caught the 1.0.10 TypeError
# at pytest time.
# ---------------------------------------------------------------------------


def test_real_cgc_ensure_succeeds(tmp_path: Path):
    """Run the actual `_ensure()` against the installed codegraphcontext.

    If you remove a required arg from our wrapper — or upstream adds one —
    this fails. No mocks; real DB driver, real GraphBuilder, real loop.
    """
    from doubled_graph.integrations.cgc import CGC

    cgc = CGC(tmp_path)
    cgc._ensure()  # must not raise

    assert cgc._db is not None, "db_manager not initialised"
    assert cgc._builder is not None, "GraphBuilder not constructed"
    assert cgc._finder is not None, "CodeFinder not constructed"
    assert cgc._job_manager is not None, "JobManager not constructed"
    assert cgc._loop is not None, "event loop not created"


def test_real_cgc_ensure_is_idempotent(tmp_path: Path):
    """Multiple `_ensure()` calls must short-circuit, not rebuild objects.

    Cheap regression guard: it would be easy to refactor away the
    `if self._builder is not None: return` line and not notice — except
    that subsequent calls would silently allocate fresh event loops.
    """
    from doubled_graph.integrations.cgc import CGC

    cgc = CGC(tmp_path)
    cgc._ensure()
    builder1, finder1, loop1 = cgc._builder, cgc._finder, cgc._loop
    cgc._ensure()
    assert cgc._builder is builder1, "GraphBuilder rebuilt on second _ensure call"
    assert cgc._finder is finder1, "CodeFinder rebuilt on second _ensure call"
    assert cgc._loop is loop1, "event loop replaced on second _ensure call"


# ---------------------------------------------------------------------------
# End-to-end analyze — slowest test, but the only one that exercises the
# wrapper through the real CGC stack with real files.
# ---------------------------------------------------------------------------


def test_analyze_full_runs_against_real_cgc_on_tiny_repo(tmp_path: Path):
    """Full analyze pipeline through the real CGC stack on a 1-file repo.

    Anything that breaks between wrapper construction, parser load, and
    DB write surfaces here as either a crash or a forbidden warning code.
    Other warnings (parser-language gaps, etc.) are acceptable; the two
    listed in `forbidden` are exactly the symptom codes of the bug
    classes this file is policing.
    """
    # Bare git init (no commit) is enough — `_git_head` returns "" gracefully
    # when HEAD is missing, so the fingerprint write doesn't crash.
    subprocess.run(["git", "init", "-q", str(tmp_path)], check=True)
    (tmp_path / "a.py").write_text(
        "def hello():\n"
        "    return 'world'\n"
        "\n"
        "def main():\n"
        "    return hello()\n",
        encoding="utf-8",
    )

    from doubled_graph.tools.analyze import analyze

    result = analyze(repo_path=tmp_path, mode="full", force=True)

    forbidden = {"CGC_BACKEND_FAIL", "CGC_ANALYZE_FAIL"}
    seen_forbidden = forbidden & {w.code for w in result.warnings}
    assert not seen_forbidden, (
        f"Real-CGC analyze emitted forbidden warnings {seen_forbidden}: "
        + "; ".join(
            f"{w.code}={w.detail}" for w in result.warnings if w.code in forbidden
        )
    )
    assert result.stats.files_processed >= 1, (
        f"Expected files_processed>=1, got {result.stats.files_processed}. "
        f"Warnings: {[w.code for w in result.warnings]}"
    )
