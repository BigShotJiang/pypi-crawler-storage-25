---
name: doubled-graph-manual-edit
description: "Use when the human edited code without AI assistance. Triggers: 'I edited X manually', 'I changed Y myself', 'look at what I did', 'check my changes', commit shows files AI didn't touch in the last hour, or DG-Authored: human/mixed trailer in commit message."
---

# doubled-graph — после ручной правки человеком

**Триггер:**

- пользователь явно говорит «я поправил X сам, посмотри»;
- `prepare-commit-msg` hook добавил `DG-Authored: human` или `DG-Authored: mixed`;
- в `post-commit` логах появились файлы, которых ИИ не трогал в последний час.

**Цель:** уважительно интегрировать ручные правки в дисциплину дрейфа — не удалять, не перекодировать, но сверить с контрактами и якорями.

**Маршрут:** все шаги через MCP-tools `doubled-graph.*`.

---

## Шаг 1 — пересчитай computed graph

Если `post-commit` hook ещё не запустился (правки на диске, ещё не коммит):

```
doubled-graph.analyze(mode="incremental", paths=["<изменённые-файлы>"])
```

В Claude Code с активным PostToolUse hook'ом — пропусти (но hook срабатывает на ИИ-правки, не на ручные; нужно проверить, что `analyze` действительно прошёл — посмотри timestamp в `.doubled-graph/cache/code-fingerprint.json`).

---

## Шаг 2 — определи режим

Прочитай `AGENTS.md` phase.

- **`migration`** → активируй `doubled-graph-drift` § A. Код = ground-truth, ручные правки тоже.
- **`post_migration`** → продолжай ниже.

---

## Шаг 3 — drift check

```
doubled-graph.detect_changes(scope="branch", base_ref="main")
```

Заметь — `scope="branch"`, не `staged`. Пользователь мог править за пределами одного коммита (несколько правок, не закоммиченных или закоммиченных по очереди).

- **Drift пуст** — всё в порядке. Ручные правки прошли по контрактам. Дальше — только шаги 4 и 5.
- **Drift непуст** → активируй `doubled-graph-drift` § B (post_migration branch).

---

## Шаг 4 — проверь якоря

Ручные правки часто **ломают** разметку:

- забыли `END_BLOCK_*` после копипаста;
- переименовали функцию, но старое `START_CONTRACT: oldName` осталось;
- добавили новый метод без обновления `MODULE_MAP`;
- убрали `START_CHANGE_SUMMARY`/`END_CHANGE_SUMMARY` целиком.

```
doubled-graph.lint()
```

Если упало — спроси:

> Ручная правка нарушила разметку в N файлах:
> - <file1>: `END_BLOCK_DECODE_JWT` отсутствует
> - <file2>: `START_CONTRACT: oldName` указывает на удалённую функцию
>
> Могу починить автоматически (только якоря, без правки логики). Разрешить?

Если `да` — правь **только якоря** через Edit, повтори `doubled-graph.lint()`. **Не меняй логику кода**.

---

## Шаг 5 — обнови `CHANGE_SUMMARY`

Добавь запись в каждый изменённый файл (синтаксис комментария — по языку файла):

```
// START_CHANGE_SUMMARY
// ...
// 2026-04-18: <краткое описание ручной правки> (DG-Authored: human)
// END_CHANGE_SUMMARY
```

Для Python:

```python
# START_CHANGE_SUMMARY
# ...
# 2026-04-18: <описание> (DG-Authored: human)
# END_CHANGE_SUMMARY
```

Зачем это нужно:

- провенанс при будущих drift-investigations (через полгода никто не вспомнит, кто и почему правил);
- формальная фиксация, что правка прошла с пониманием контекста, даже если не через ИИ;
- разделение «что наработал ИИ» vs «что наработал человек» — критично для post-mortem инцидентов.

---

## Шаг 6 — обнови declared graph руками, если семантика изменилась

Если ручная правка изменила публичные экспорты или зависимости (новый импорт из другого `M-*`, изменённая сигнатура) — обнови `docs/*.xml` через `Edit`:

- `docs/knowledge-graph.xml` — `<Export>` / `<CrossLink>` / pre/post/invariant под новую реальность;
- `docs/development-plan.xml` — если сменился `<Path>` или `<criticality>`.

Подробности — `doubled-graph-after-edit` шаг 2.

---

## Чего НЕ делать

- **Не удаляй ручные правки** «потому что они не соответствуют плану». В `migration` они = источник истины. В `post_migration` — возможное новое требование, решает пользователь, не ты.
- **Не меняй поведение кода при фиксе разметки.** Только якоря. Если хочешь поправить и логику — спроси отдельно, не сваливай в один шаг.
- **Не пиши в `docs/DRIFT.md` сам.** Это для нерешённых случаев — пользователь подписывает.
- **Не утверждай «всё в порядке»** без `lint` + `detect_changes`. Ручные правки чаще всего ломают именно то, чего ИИ бы не сломал (например, забывают `END_*` якорь).

---

## Шпаргалка

```
MANUAL-EDIT (всё через MCP):
1. doubled-graph.analyze(mode="incremental", paths=[touched])
2. read AGENTS.md phase
   migration -> doubled-graph-drift § A
3. doubled-graph.detect_changes(scope="branch", base_ref="main")
   drift -> doubled-graph-drift § B
4. doubled-graph.lint()
   broken anchors -> ask user; fix anchors only via Edit (not logic)
5. update CHANGE_SUMMARY with (DG-Authored: human) entry
6. if public semantics changed -> Edit docs/knowledge-graph.xml (Export/CrossLink) + docs/development-plan.xml (Path/criticality)
```
