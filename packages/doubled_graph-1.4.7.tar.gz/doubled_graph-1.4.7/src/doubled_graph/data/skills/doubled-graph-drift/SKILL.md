---
name: doubled-graph-drift
description: "Use when doubled-graph.detect_changes returns non-empty drift OR when code and docs/*.xml artifacts are out of sync. Walks through resolution per drift type (code_without_module, contract_mismatch, stale_crosslinks, etc). Triggers: detect_changes returned issues, drift detected, divergence between code and docs, fix the dual graph."
---

# doubled-graph — обнаружен дрейф

**Триггер:** `doubled-graph.detect_changes()` вернул непустой drift.

Дрейф из 5+ items, каждый — решение пользователя. Локальная модель забывает первые к 7-му item. **Журнал обязателен.**

**Маршрут:** все шаги через MCP-tools `doubled-graph.*`. Bash — только для `git diff` / `git commit`.

---

## Externalize state (обязательно)

- Файл: `.doubled-graph/drafts/drift-session-<ISO>.md` — append-only.
- Поля per item: `тип`, `target`, `время`, `user-decision` (`new-req` / `bug` / `defer`), `next action`, `status`.
- Конец сессии — `Status: completed`. **Не удалять** (audit trail для постмортем).

Пример записи:

```markdown
## item-3 (2026-04-18T10:22:04Z)
- type: contract_mismatch
- target: M-AUTH-VALIDATE.validateUser
- decision: bug
- next: Edit src/auth/validate.ts, restore signature to match `<Module M-AUTH-VALIDATE>` contract
- status: in-progress
```

---

## Шаг 0 — определи режим

Прочитай `AGENTS.md`, ищи блок `<!-- doubled-graph:phase:start -->`.

- **`migration`** → § A (просто refresh).
- **`post_migration`** → § B (per-type решение).

Если `AGENTS.md` нет — default `post_migration`.

---

## § A. Режим `migration`

Код = ground-truth. Артефакты догоняют без вопросов.

**A.1 — пройди по items drift'а и обнови `docs/*.xml` через `Edit`.** Маппинг типов:

| тип drift'а | что править |
|---|---|
| `code_without_module` | `docs/development-plan.xml` — добавить `<Module id="M-NEW">` с `<Path>` и `<criticality>` (спроси у пользователя если не очевидно) |
| `module_without_code` | `docs/development-plan.xml` — пометить `<Module>` как `<Status>deprecated</Status>` или удалить |
| `contract_mismatch` | `docs/knowledge-graph.xml` — обновить `<Export>` / `pre`/`post`/`invariant` под реальную сигнатуру |
| `stale_crosslinks` | `docs/knowledge-graph.xml` — удалить `<CrossLink to="..."/>` |
| `missing_verification` | `docs/verification-plan.xml` — добавить `<V-M-*>` (см. skill `doubled-graph-verify`) |
| `markup_missing` | через `Edit` в самом code-файле — добавить `MODULE_CONTRACT` блок (см. § B.6) |

Возьми текущий контракт через `doubled-graph.module_show(target=<M-id>)` как baseline.

**A.2 — ревью diff.**

Покажи пользователю `git diff docs/` (через Bash). Пользователь подтверждает одним из:

- «ок, коммить» → коммит `chore(sync): sync docs after code changes`;
- «откати X» → правишь по инструкции пользователя.

**A.3 — вернись на `doubled-graph-after-edit` шаг 4** (`lint` + тесты).

---

## § B. Режим `post_migration`

Артефакты = ground-truth. Дрейф — подозрение на баг или неодобренное требование.

Обрабатывай **каждый тип отдельно**. Не сваливай в одно решение «refresh всё».

### B.1 — `code_without_module`

Функция / класс есть в коде, не покрыт ни одним `M-*`.

Спроси пользователя:

> Обнаружен код без модуля:
> - `<file>:<line> — <function/class>`
>
> Варианты:
>  (a) это новое требование — добавляю `<UC-*>` в `docs/requirements.xml` + новый `<Module M-xxx>` в `docs/development-plan.xml` (Edit), затем размечаю код якорями (`MODULE_CONTRACT`/etc) — нужен ли planning-цикл с approval-gate, скажи;
>  (b) это баг (код не должен был попасть) — удаляю файл/функцию через Edit;
>  (c) вспомогательный dev/test код — выношу в `tests/` или `dev/` и помечаю исключением в `.grace-lint.json`;
>  (d) не знаю — пишу в `docs/DRIFT.md`, модуль-кандидат блокируется для дальнейших правок ИИ до решения.

Выполни выбор пользователя.

### B.2 — `module_without_code`

`M-*` есть в `development-plan.xml`, файлов под него нет.

- Если модуль помечен `in-progress` в `DRIFT.md` с не истекшим deadline → молча пропусти (ожидаем реализации).
- Иначе спроси: (a) модуль устарел, помечаем `deprecated`; (b) забыли реализовать, создаём issue/задачу.

### B.3 — `contract_mismatch`

Реальная сигнатура / pre/post / invariant ≠ декларированному контракту.

Спроси:

> Контракт `M-AUTH-VALIDATE.validateUser` заявляет `(req: Request) -> User | null`.
> Фактическая сигнатура: `(req: Request, opts?: Options) -> User | null`.
>
> Варианты:
>  (a) новое требование (`opts` важен) — обнови контракт `<Module M-AUTH-VALIDATE>` в `docs/knowledge-graph.xml` (Edit) под новую сигнатуру; контракт-change должен быть отдельным коммитом с явным trailer `Contract-change: M-AUTH-VALIDATE signature`;
>  (b) баг (`opts` случайно добавлен) — Edit `src/auth/validate.ts`, откати `opts` параметр под существующий контракт; запиши `(DG-Authored: ai)` в `CHANGE_SUMMARY`;
>  (c) не знаю — `DRIFT.md`.

### B.4 — `stale_crosslinks`

CrossLink `M-A → M-B` есть в `knowledge-graph.xml`, в computed нет вызовов между файлами модулей.

- Намеренный рефакторинг → удали `<CrossLink to="M-B"/>` из `<Module M-A>` в `docs/knowledge-graph.xml` через `Edit` после подтверждения пользователя.
- Подозрительно (неожиданная потеря связи) → `DRIFT.md`, спроси не потерялась ли функциональность.

### B.5 — `missing_verification`

`M-*` есть код, нет `V-M-*` записи в `verification-plan.xml`.

- Критический модуль (`criticality="critical"`) → активируй skill `doubled-graph-verify` для полного покрытия. Если пользователь откладывает — заблокируй `Gate G-pre-merge` для этого модуля.
- Standard → активируй skill `doubled-graph-verify` (happy path + один error case).
- Helper → запись в `DRIFT.md` как «verification pending», low priority.

### B.6 — `markup_missing`

В файле нет `MODULE_CONTRACT` или `MODULE_MAP`.

- Добавь разметку **руками** через Edit по конвенции комментариев языка:
  - C-family / Java / Go / Rust / TS / JS: `// START_MODULE_CONTRACT` ... `// END_MODULE_CONTRACT`
  - Python / Ruby / shell: `# START_MODULE_CONTRACT` ... `# END_MODULE_CONTRACT`
  - HTML / XML / Vue templates: `<!-- START_MODULE_CONTRACT --> ... <!-- END_MODULE_CONTRACT -->`
  - C# / VB: `#region START_BLOCK_NAME` ... `#endregion END_BLOCK_NAME` (нативный region парный с якорем).
- Запусти `doubled-graph.lint()` для проверки.

---

## Шаг B.N — после обработки всех типов

1. Повтори `doubled-graph.detect_changes(scope="staged")`. Непусто → к соответствующему §.
2. Пусто → возвращайся в `doubled-graph-after-edit` шаг 4.

---

## Записи в `docs/DRIFT.md`

Любой пункт с ответом «не знаю» создаёт/обновляет запись:

```markdown
## D-042 — M-AUTH-VALIDATE contract_mismatch (2026-04-18)

**Тип:** contract_mismatch.
**Обнаружено:** `doubled-graph.detect_changes()` в коммите `abc1234`.
**Суть:** контракт заявляет 1 аргумент, реальная сигнатура — 2.
**Решение откладывается пользователем. До решения — модуль M-AUTH-VALIDATE заблокирован для ИИ-правок.**
**Deadline:** 2026-04-22 (assumed).
**Owner:** <никто пока>.
```

Коммить отдельным коммитом: `docs(drift): register D-042 on M-AUTH-VALIDATE contract mismatch`.

---

## Anti-patterns

- Не «refresh всё подряд» в режиме `post_migration` — это маскирует баги под намеренные изменения.
- Не пиши в `docs/DRIFT.md` сам без явного «не знаю» от пользователя. Это для **нерешённых** случаев.
- Не блокируй модуль для ИИ-правок без записи в `DRIFT.md` — иначе следующая сессия не узнает о блокировке.
- Не смешивай правку артефактов и кода в одном коммите при разрешении дрейфа.

---

## Шпаргалка

```
ON-DRIFT:
read AGENTS.md phase
migration -> Edit docs/*.xml per drift type table (§ A.1); git diff docs/; user confirm; commit chore(sync)
post_migration -> per drift type:
  code_without_module -> user: new req (Edit UC + Module) | bug (delete) | dev (move to tests/) | drift
  module_without_code -> deprecated (Edit Status) | issue
  contract_mismatch -> new req (Edit knowledge-graph.xml; commit Contract-change) | bug (Edit code) | drift
  stale_crosslinks -> Edit knowledge-graph.xml (drop CrossLink) | drift (functionality-loss check)
  missing_verification -> activate doubled-graph-verify skill | gate block
  markup_missing -> Edit code-file; doubled-graph.lint()
unknown -> DRIFT.md, block module for AI edits
re-run doubled-graph.detect_changes(scope="staged") until empty
goto doubled-graph-after-edit step 4
```
