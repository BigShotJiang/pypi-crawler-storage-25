---
name: doubled-graph-refactor
description: "Use when the user wants to safely rename, move, split, merge or extract a function/class/module across the codebase. Coordinates the rename across all callers, the declared graph (docs/*.xml) references, and the verification entries. Triggers: rename function, rename class, move module, split module, extract module, refactor X to Y."
---

# doubled-graph — рефакторинг (rename / move / split / extract)

**Триггер:** пользователь просит переименовать функцию/класс/модуль, переместить, разделить или извлечь часть.
**Цель:** не потерять ни одного caller'а, не разорвать crosslinks в `docs/*.xml`, не оставить устаревших `V-M-*` ссылок.

**Маршрут:** `doubled-graph.impact()` собирает blast radius, дальше — атомарные правки через `Edit`. Финальный gate — `doubled-graph.lint()` + `doubled-graph.detect_changes()`.

---

## Шаг 1 — собрать blast radius

```
doubled-graph.impact(
  target="<старое-имя>",
  direction="upstream",
  depth=3
)
```

Получишь:
- `target_resolved.module_id` — какой `M-*` владеет символом;
- `direct[]` / `transitive[]` — все callers, по уровням;
- `affected_modules[]` — все `M-*` затронутые;
- `affected_verification[]` — все `V-M-*` тесты, которые могут упасть;
- `risk.level` — насколько опасен рефакторинг.

Если `risk.level >= HIGH` — **остановись**, покажи `risk.reasons` пользователю, жди подтверждения.

---

## Шаг 2 — найди все XML-ссылки на старое имя

Ручной поиск через Grep по `docs/`:

```bash
grep -rn "<старое-имя>" docs/
```

Возможные места:
- `<Export name="..."/>` в `docs/knowledge-graph.xml`;
- `<Module id="..."/>` в `docs/development-plan.xml` (если переименовывается модуль);
- `<V-M-*><Module>...</Module>` в `docs/verification-plan.xml`;
- `<UC-*><Implements>...</Implements>` в `docs/requirements.xml`.

Собери полный список ссылок — они все должны обновиться вместе с кодом.

---

## Шаг 3 — покажи план пользователю

До правок выложи единый план:

```
План рефакторинга <старое> → <новое>:

CODE EDITS (N файлов):
- src/auth/login.ts:42  — call site
- src/api/middleware.ts:15  — call site
- src/auth/validate.ts:10  — definition
...

XML EDITS (M файлов):
- docs/knowledge-graph.xml:23  — <Export name="старое"/>
- docs/verification-plan.xml:8  — <V-M-AUTH-1><Module>M-AUTH-старое</Module>
...

RISK: MEDIUM (12 callers, 1 affected V-M-*)
```

Жди явного «ок, поехали» или «откати X».

---

## Шаг 4 — применить (атомарно)

**Code edits сначала, XML — после.** Если правка кода упадёт посередине — XML ещё не обновлён, репо в консистентном состоянии (старое имя везде).

Для каждого файла из списка — `Edit` с whole-word replacement:
- Не делай blind sed-like replace — он попадёт в комментарии, строки, partial matches.
- Используй Edit с достаточным context'ом вокруг каждого вхождения (минимум сигнатура функции / строка вызова целиком).

Для XML — то же самое, Edit с context'ом тега.

---

## Шаг 5 — обнови `CHANGE_SUMMARY` в затронутых файлах

В каждый файл, где правил код (не только xml):

```
// 2026-04-18: rename <старое> → <новое>; affected callers: N (DG-Authored: ai)
```

---

## Шаг 6 — проверка

```
doubled-graph.analyze(mode="incremental", paths=[<все тронутые файлы>])
doubled-graph.lint()
doubled-graph.detect_changes(scope="staged")
```

- `lint` упал → разметка/якоря/ID-ссылки сломаны → найди что и поправь.
- `detect_changes` непуст:
  - `stale_crosslinks` на старое имя → ты пропустил XML-ссылку, найди через Grep.
  - `code_without_module` на новое имя → не обновил `<Export>` в knowledge-graph.xml.
  - `contract_mismatch` → возможно сменил сигнатуру (а не только имя), это уже не rename, активируй `doubled-graph-before-edit` для contract-change цикла.

---

## Шаг 7 — прогон тестов

Из списка `affected_verification` (шаг 1) запусти все `V-M-*` через Bash. Тесты упали → откат через `git restore` или быстрый fix через Edit.

---

## Шаг 8 — коммит

```
refactor: rename <старое> → <новое>

Affected: <M-ids>
LINKS: <UC-ids>
```

Если переименовался модуль (M-* id поменялся) — отдельная строка `M-rename: M-OLD → M-NEW`.

---

## Сложные случаи

### Move (функция переезжает в другой модуль)
- Шаг 2 расширяется: ищи и обновляй ссылки на ОБА — старый `M-*` (откуда уходит) и новый `M-*` (куда пришла).
- В `knowledge-graph.xml`: переноси `<Export>` из старого `<Module>` в новый.
- В `development-plan.xml`: возможно меняется `<Path>` модуля.

### Split (модуль распадается на два)
- Не делать как rename — это comparable scope с planning-циклом (Edit `<UC-*>`/`<Module>` в `docs/*.xml`, явный approval-gate перед кодогенерацией).
- Активируй `doubled-graph-before-edit` для contract-change → запроси у пользователя цикл планирования.

### Extract (вынести функцию в отдельный модуль)
- То же — это новый `M-*`, через `doubled-graph-before-edit` + plan цикл.

---

## Anti-patterns

- Не делай blind sed/grep + replace без `impact` — пропустишь dynamic references, JSON-конфиги, тесты.
- Не правь только код без XML — `detect_changes` найдёт `stale_crosslinks` на следующем шаге.
- Не правь только XML без кода — это дрейф наоборот, `code_without_module` на новое имя.
- Не разрешай contract changes (другая сигнатура, не только имя) внутри refactor — это plan-цикл, не rename.

---

## Шпаргалка

```
REFACTOR (rename):
1. doubled-graph.impact(target=<old>, direction="upstream", depth=3)
   risk HIGH/CRITICAL -> STOP, ask
2. Grep docs/ for <old> references
3. show plan: code edits + XML edits + risk
4. wait for user "ок, поехали"
5. apply: code edits first (Edit), XML edits second
6. update CHANGE_SUMMARY in touched files
7. doubled-graph.analyze(...) + .lint() + .detect_changes()
   stale_crosslinks -> missed XML; code_without_module -> missed Export
8. run V-M-* tests
9. git commit "refactor: <old> → <new>" with Affected, LINKS

Move/Split/Extract -> not pure rename, route via doubled-graph-before-edit
```
