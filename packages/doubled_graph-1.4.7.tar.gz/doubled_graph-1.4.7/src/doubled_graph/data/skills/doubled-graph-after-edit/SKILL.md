---
name: doubled-graph-after-edit
description: "Use AFTER completing any code edit, BEFORE creating a git commit. Runs drift detection, anchor lint, verification tests, and contract-change check to verify the change is safe to commit. Triggers: finished editing, ready to commit, want to push, made changes to code."
---

# doubled-graph — после правки, до коммита

**Триггер:** только что сохранил изменённый файл. До `git commit`.
**Цель:** убедиться, что правка не создаёт дрейфа, не ломает разметку, не нарушает контракт без подтверждения.

Этот skill — финальный gate перед коммитом. Без него дрейф уйдёт в репо.

**Маршрут:** все шаги через MCP-tools `doubled-graph.*`. Bash — только для `git commit` и degraded-mode fallback.

---

## Шаг 1 — обновить computed graph

В Claude Code с PostToolUse hook'ом — пропусти, hook сделал.
В остальных IDE:

```
doubled-graph.analyze(mode="incremental", paths=["<тронутые-файлы>"])
```

---

## Шаг 2 — обновить declared graph руками (если правка семантическая)

Семантическая правка — это:

- изменение публичных экспортов модуля (добавил / удалил / переименовал функцию, изменил сигнатуру);
- новый импорт из другого `M-*` модуля;
- поведение, влияющее на `verification-plan.xml` записи.

Если такое — **обнови соответствующие `docs/*.xml` через `Edit`** (нет MCP-команды, которая делала бы это автоматически):

1. **`docs/knowledge-graph.xml`** — `<Module id="M-id">`:
   - добавил/удалил функцию → обнови `<Export name="..."/>` список;
   - сменил сигнатуру → обнови pre/post/invariant внутри `<Module>`;
   - новый импорт из M-OTHER → добавь `<CrossLink to="M-OTHER"/>`.

2. **`docs/development-plan.xml`** — `<Module id="M-id">`:
   - сменился `<Path>` или `<criticality>` — обнови.

3. **`docs/verification-plan.xml`** — `<V-M-*>`:
   - сменилась тестовая команда / asserts — обнови.

Используй `doubled-graph.module_show(target="<M-id>")` для текущего состояния модуля как baseline. Если правка чисто внутренняя (логика внутри блока, контракт неизменён, экспорты те же) — пропусти этот шаг.

---

## Шаг 3 — drift check (обязательно)

```
doubled-graph.detect_changes(scope="staged")
```

- **Drift пуст** — продолжай.
- **Drift непуст** — активируй skill `doubled-graph-drift`. После разрешения — вернись сюда на шаг 4.

---

## Шаг 4 — lint якорей

```
doubled-graph.lint()
```

Проверяет парность якорей `START_*` / `END_*`, корректность `MODULE_CONTRACT` блоков, валидность ID-ссылок (`M-*`, `UC-*`, `V-M-*`).

Три варианта ответа — действуй по `result.ok` / `error`:

| Ответ | Что значит | Действие |
|---|---|---|
| `{"result": {"ok": true, "violations": []}}` | lint clean | продолжай шаг 5 |
| `{"result": {"ok": false, "violations": [...]}}` | lint нашёл нарушения | для каждого `{file, line, rule, detail}` — `Edit` файл, поправь разметку. Перезапусти `doubled-graph.lint()`. **Не коммить через `--no-verify`** до `ok: true`. |
| `{"error": "GRACE_CLI_ERROR", "detail": "..."}` | grace сам упал (не lint findings) | `detail` содержит rc + stderr — покажи пользователю, не пытайся «починить разметку» на пустом месте. Чаще всего проблема в `docs/*.xml` (malformed XML). |
| `{"error": "GRACE_CLI_MISSING", ...}` | `grace` CLI не установлен | `bun add -g @osovv/grace-cli` или `doubled-graph setup` (если Bun отсутствует — поставится tsx-fallback). |

---

## Шаг 5 — релевантные тесты

Из `verification-plan.xml` найди записи `V-M-*` для тронутых модулей. Выполни их `Command` через Bash (тестовая команда указана в самой записи).

**Тесты упали** — останови, покажи ошибку пользователю. **Не коммить сломанное.**

---

## Шаг 6 — contract-change check

Если правка изменила:

- сигнатуру публичного экспорта,
- pre/post/invariant в `<MODULE_CONTRACT>`,
- `<PublicExports>`,
- CrossLinks,
- `criticality`

— **остановись**, покажи отдельным блоком:

```
⚠ CONTRACT CHANGE в <M-ID>:
  было: <old signature/pre/post/inv>
  стало: <new signature/pre/post/inv>
  причина: <из задачи / из diff>
  callers затронуты: <из impact depth=1>
```

Жди явного подтверждения от пользователя («contract change ок», «откати contract и оставь только реализацию» и т.п.). Без подтверждения — не коммить.

Внутренние правки (без изменения экспортов и контракта) этого шага не требуют.

---

## Шаг 7 — коммит

Все четыре gate должны быть зелёные:

1. `detect_changes` пусто,
2. `lint` прошёл,
3. тесты прошли,
4. `impact` перед правкой был не CRITICAL (или был явно одобрен пользователем).

Сам commit делается через Bash (`git commit`). Сообщение содержит минимум:

```
<краткое описание изменения>

Affected: <M-ids через запятую>
LINKS: <UC-ids через запятую>
```

Если был contract-change — добавь строку `Contract-change: <M-ID> <что изменилось>`.

В Claude Code по умолчанию добавится `Co-Authored-By: Claude`. Если установлен `prepare-commit-msg` hook (через `doubled-graph init-hooks`) — добавится `DG-Authored: ai`.

---

## Что коммитить, что не коммитить

**Коммитим:**

- изменённый код,
- обновлённые `docs/*.xml` (если `refresh` их изменил),
- обновлённый `CHANGE_SUMMARY` в файле кода.

**НЕ коммитим:**

- `.doubled-graph/cache/` (в `.gitignore` после `setup`),
- `.doubled-graph/logs/` (в `.gitignore`),
- временные файлы тест-фреймворка.

**Коммитить отдельно, если много изменений:**

- chore-правки (переименование без логики) — отдельный commit;
- markup-правки (только якоря) — отдельный commit в режиме `migration`, чтобы diff контракта был читаемый.

---

## Anti-patterns

- Не коммить без `detect_changes`. Методология требует drift-check.
- Не коммить только `docs/*.xml` без кода (если это не `refresh` pass — это и есть дрейф).
- Не коммить через `--no-verify`. Если hook упал — поправь проблему, не обходи.
- Не смешивай правку > 1 модуля в один коммит без обоснования. Мелкие атомарные коммиты упрощают revert.

---

## Шпаргалка (<1 KB)

```
AFTER-EDIT (всё через MCP, кроме git и Edit для XML):
1. doubled-graph.analyze(mode="incremental", paths=[touched]) if no hook
2. semantic change -> Edit docs/knowledge-graph.xml (Export/CrossLink)
                       Edit docs/development-plan.xml (Path/criticality if needed)
                       Edit docs/verification-plan.xml (V-M-* if needed)
3. doubled-graph.detect_changes(scope="staged")
   drift -> goto doubled-graph-drift
4. doubled-graph.lint()
5. run V-M-* tests for touched modules (Bash)
6. contract change -> show diff block, await user confirmation
7. git commit -m "..." with Affected, LINKS, [Contract-change] trailers
```

---

## Если MCP недоступен (degraded mode)

Fallback в Bash:
- `doubled-graph analyze --mode incremental --paths X`
- `doubled-graph detect-changes --scope staged`
- `doubled-graph lint`

Эквивалентный результат, медленнее (subprocess + Python startup на каждый вызов).
