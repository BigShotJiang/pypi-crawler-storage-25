"""doubled-graph — MCP facade for the doubled-graph methodology.

Public entry points:
  - `python -m doubled_graph`      : start MCP server on stdio
  - `doubled-graph` (CLI, via pyproject script): same + `init-hooks`, `analyze` one-shot

See SPEC.md and TOOLS.md for the full contract.
"""

# Single source of truth for the version: pyproject.toml.
# We read it at import time via `importlib.metadata` so the runtime never
# disagrees with what pipx/pip actually installed. Hardcoding `__version__`
# here previously let the constant drift behind pyproject across releases —
# users' JSON `meta.tool_version` reported a version that was several
# releases stale, which made every "what version are you on?" debug
# round-trip dishonest.
from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("doubled-graph")
except PackageNotFoundError:
    # Running from a source checkout without an installed dist (rare; mostly
    # tooling quirks). Mark it visibly rather than picking a misleading
    # number — anything debugging this will see the suffix and know to look.
    __version__ = "0.0.0+source"
