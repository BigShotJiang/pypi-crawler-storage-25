"""grace-cli (Bun binary) integration — subprocess wrapper."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class GraceCLIMissing(RuntimeError):
    """Raised when `grace` executable is not in $PATH."""


_PACKAGE = "@osovv/grace-cli"

# Ordered preference of JS package managers for installing grace-cli.
# Bun is upstream's default; npm/yarn/pnpm are accepted fallbacks so users
# without Bun (e.g. typical Node installs) don't hit a dead end.
INSTALLERS: list[tuple[str, list[str]]] = [
    ("bun", ["bun", "add", "-g", _PACKAGE]),
    ("npm", ["npm", "install", "-g", _PACKAGE]),
    ("yarn", ["yarn", "global", "add", _PACKAGE]),
    ("pnpm", ["pnpm", "add", "-g", _PACKAGE]),
]


# Per-package-manager commands — keep classification hints portable across bun/npm/yarn/pnpm.
_INSTALL_CMD = {
    "bun":  f"bun add -g {_PACKAGE}",
    "npm":  f"npm install -g {_PACKAGE}",
    "yarn": f"yarn global add {_PACKAGE}",
    "pnpm": f"pnpm add -g {_PACKAGE}",
}

_UNINSTALL_CMD = {
    "bun":  f"bun remove -g {_PACKAGE}",
    "npm":  f"npm uninstall -g {_PACKAGE}",
    "yarn": f"yarn global remove {_PACKAGE}",
    "pnpm": f"pnpm remove -g {_PACKAGE}",
}

_PROXY_HINT = {
    "bun":  "Bun reads `HTTP_PROXY` / `HTTPS_PROXY` env vars and `~/.bunfig.toml`.",
    "npm":  "For npm: `npm config set proxy <url>` and `npm config set https-proxy <url>`.",
    "yarn": "For yarn: `yarn config set proxy <url>` and `yarn config set https-proxy <url>`.",
    "pnpm": "For pnpm: `pnpm config set proxy <url>` and `pnpm config set https-proxy <url>`.",
}

_PERMISSION_HINT = {
    "bun":  (
        "Global install was denied. Ensure `~/.bun/bin` is writable and on PATH; "
        "don't run Bun with sudo (it installs into the invoking user's home)."
    ),
    "npm":  (
        "Global install was denied by the OS. Don't run with sudo; instead point npm "
        "at a user-writable prefix: `npm config set prefix ~/.npm-global` and add "
        "`~/.npm-global/bin` to PATH."
    ),
    "yarn": (
        "Global install was denied. Check write access to `yarn global dir` — run as "
        "the owning user, not sudo."
    ),
    "pnpm": (
        "Global install was denied. Set `PNPM_HOME` to a user-writable directory and "
        "ensure it is on PATH (`pnpm setup` configures this for you)."
    ),
}


def _classify_install_error(pm: str, output: str) -> tuple[str, str]:
    """Best-effort: map package-manager output to (error_type, actionable hint).

    The tokens we look for span bun/npm/yarn/pnpm phrasings — Node-style errno
    codes (ETIMEDOUT, EACCES, …) which appear in npm/yarn/pnpm, plus the plain-
    English variants that bun emits. The hint is then formatted per `pm` so we
    never tell a bun user to run an npm command.

    The raw output stays in `stderr` for bug reports; this just surfaces the
    actionable bit so the user doesn't have to parse a 2000-char log.
    """
    out = output.lower()
    install_cmd = _INSTALL_CMD.get(pm, _INSTALL_CMD["npm"])
    uninstall_cmd = _UNINSTALL_CMD.get(pm, _UNINSTALL_CMD["npm"])
    proxy_hint = _PROXY_HINT.get(pm, _PROXY_HINT["npm"])

    if any(t in out for t in ("etimedout", "esockettimedout", "econnreset", "timed out", " timeout")):
        return (
            "network_timeout",
            f"Registry request timed out. Check network/VPN and retry. {proxy_hint}",
        )
    if any(
        t in out
        for t in (
            "enotfound", "getaddrinfo", "econnrefused", "connection refused",
            "failed to resolve", "unable to resolve host", "could not resolve host",
        )
    ):
        return (
            "network_unreachable",
            f"DNS/connection to the registry failed. Check network/VPN/proxy, then retry. {proxy_hint}",
        )
    if "eacces" in out or "eperm" in out or "permission denied" in out:
        return ("permission_denied", _PERMISSION_HINT.get(pm, _PERMISSION_HINT["npm"]))
    if any(
        t in out
        for t in (
            "e404", "404 not found", "not in this registry", "not found in registry",
            "no matching version", "package not found", "package \"" + _PACKAGE,
        )
    ):
        return (
            "package_not_found",
            f"The package {_PACKAGE} could not be resolved. Check your registry is "
            f"reachable and the package name is correct. Manual retry: `{install_cmd}`.",
        )
    if "eexist" in out or "already exists" in out:
        return (
            "conflict",
            f"A conflicting install exists. Try `{uninstall_cmd}` and rerun.",
        )
    return (
        "install_failed",
        f"Install command failed. See `stderr` below or rerun manually: `{install_cmd}`.",
    )


def _run_installer(cmd: list[str], tee_to_stderr: bool) -> tuple[int, str]:
    """Run an install command, optionally streaming its output live to stderr.

    Always returns (exit_code, merged_output) — even when streaming, so failures
    can still be classified and reported with structured fields. Streams stdout
    and stderr together so progress bars from npm/bun show up in real time.
    """
    if not tee_to_stderr:
        p = subprocess.run(cmd, capture_output=True, text=True, check=False)
        merged = ((p.stdout or "") + (p.stderr or "")).strip()
        return p.returncode, merged

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    assert proc.stdout is not None
    lines: list[str] = []
    for line in proc.stdout:
        sys.stderr.write(line)
        sys.stderr.flush()
        lines.append(line)
    proc.wait()
    return proc.returncode, "".join(lines).strip()


# Per-installer uninstall + tsx-install commands. Mirrored from INSTALLERS
# so each installer has a known counterpart for cleanup and for adding tsx
# (the Node-based TypeScript runner we use as a Bun-runtime fallback).
_UNINSTALLERS: dict[str, list[str]] = {
    "bun":  ["bun", "remove", "-g", _PACKAGE],
    "npm":  ["npm", "uninstall", "-g", _PACKAGE],
    "yarn": ["yarn", "global", "remove", _PACKAGE],
    "pnpm": ["pnpm", "remove", "-g", _PACKAGE],
}

_TSX_INSTALLERS: dict[str, list[str]] = {
    "bun":  ["bun", "add", "-g", "tsx"],
    "npm":  ["npm", "install", "-g", "tsx"],
    "yarn": ["yarn", "global", "add", "tsx"],
    "pnpm": ["pnpm", "add", "-g", "tsx"],
}

# Per-PM commands to query global node_modules root. Used by
# `_global_node_modules_roots` to find packages installed by any PM.
_PM_GLOBAL_ROOT_CMDS: dict[str, list[str]] = {
    "npm":  ["npm", "root", "-g"],
    "pnpm": ["pnpm", "root", "-g"],
    # yarn classic returns a *parent* dir; the actual node_modules is inside.
    # We try both forms in `_global_node_modules_roots`.
    "yarn": ["yarn", "global", "dir"],
}

# Per-PM strategies for finding the global *bin* directory. npm 9+ removed
# `npm bin -g` (use `npm prefix -g` + `/bin`); pnpm has `pnpm bin -g` only
# in 9+; yarn classic has `yarn global bin`; bun has `bun pm bin -g`. Each
# entry is (command, suffix). When suffix is non-empty, we append it to
# the command's stdout to get the bin dir (handles npm's prefix-not-bin output).
_PM_GLOBAL_BIN_STRATEGIES: dict[str, tuple[list[str], str]] = {
    "npm":  (["npm", "prefix", "-g"], "bin"),     # npm prefix is install root
    "pnpm": (["pnpm", "bin", "-g"], ""),
    "yarn": (["yarn", "global", "bin"], ""),
    "bun":  (["bun", "pm", "bin", "-g"], ""),
}


def _pm_query(pm: str, cmds_map: dict[str, list[str]]) -> Path | None:
    """Run `cmds_map[pm]` and return its stdout as a Path, or None on failure."""
    if shutil.which(pm) is None:
        return None
    cmd = cmds_map.get(pm)
    if not cmd:
        return None
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10, check=False
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None
    out = (result.stdout or "").strip()
    return Path(out) if out else None


def _pm_global_bin(pm: str) -> Path | None:
    """Return the directory where `pm` puts global executables, if any.

    Strategy varies per PM (and per PM version): npm 9+ removed `npm bin -g`
    so we use `npm prefix -g` + "/bin" as a fallback. pnpm/yarn/bun have
    direct equivalents. Used to find binaries placed during global install
    when the PM's bin dir isn't on $PATH — yarn/pnpm regularly leave their
    bin dirs unconfigured until `pnpm setup` / shell-profile changes.
    """
    if shutil.which(pm) is None:
        return None
    strategy = _PM_GLOBAL_BIN_STRATEGIES.get(pm)
    if strategy is None:
        return None
    cmd, suffix = strategy
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10, check=False
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None
    out = (result.stdout or "").strip()
    if not out:
        return None
    base = Path(out)
    return (base / suffix) if suffix else base


def _global_node_modules_roots() -> list[Path]:
    """Best-effort: every directory that might contain a global node_modules.

    Combines:
      1. Each installed PM's "where do you keep globals" output (yarn classic
         needs both the dir and dir/node_modules tried).
      2. Common hardcoded defaults so users with broken PM CLIs but standard
         layouts still resolve (e.g. ~/.npm-global/lib/node_modules).
    Returned in priority order, de-duplicated.
    """
    candidates: list[Path] = []
    for pm in ("npm", "pnpm", "yarn", "bun"):
        root = _pm_query(pm, _PM_GLOBAL_ROOT_CMDS)
        if root is None:
            continue
        # npm/pnpm: root *is* node_modules. yarn: parent. We try both layouts
        # so the same code works regardless of PM specifics.
        candidates.append(root)
        candidates.append(root / "node_modules")
    home = Path.home()
    candidates += [
        home / ".npm-global" / "lib" / "node_modules",
        home / ".yarn" / "global" / "node_modules",
        home / "Library" / "pnpm" / "global" / "5" / "node_modules",  # macOS pnpm
        home / ".local" / "share" / "pnpm" / "global" / "5" / "node_modules",  # Linux pnpm
        Path("/usr/local/lib/node_modules"),
        Path("/opt/homebrew/lib/node_modules"),
    ]
    seen: set[Path] = set()
    deduped: list[Path] = []
    for p in candidates:
        if p in seen:
            continue
        seen.add(p)
        deduped.append(p)
    return deduped


def _resolve_executable(name: str, prefer_pm: str | None = None) -> str | None:
    """Locate an executable across $PATH and every known PM's global bin dir.

    Order:
      1. Plain $PATH (`shutil.which`).
      2. `prefer_pm`'s global bin (e.g. the PM that just installed it).
      3. Each other installed PM's global bin.
    Returns absolute path string or None if not found anywhere we look.

    Why this is needed: yarn/pnpm regularly leave their global bin off $PATH
    until the user explicitly runs `pnpm setup` or adds `yarn global bin`
    output to their shell profile. We can't ask users to re-source their
    shell mid-`doubled-graph setup`, so resolving by absolute path keeps
    install reliable across PM configurations.
    """
    direct = shutil.which(name)
    if direct:
        return direct
    order = [prefer_pm] if prefer_pm else []
    order += [pm for pm in ("bun", "npm", "yarn", "pnpm") if pm != prefer_pm]
    for pm in order:
        if pm is None:
            continue
        bin_dir = _pm_global_bin(pm)
        if bin_dir is None:
            continue
        candidate = bin_dir / name
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


def _grace_runs_ok(grace_cmd: str = "grace") -> bool:
    """Smoke-test that `grace` not only exists but actually executes.

    @osovv/grace-cli ships a TS source file as `bin` with `#!/usr/bin/env bun`.
    npm/yarn/pnpm install the package and PATH-shim the binary, but invocation
    needs Bun runtime. We can't detect this from the install exit code (it's 0);
    the only reliable check is to actually invoke the binary.
    """
    if shutil.which(grace_cmd) is None:
        return False
    try:
        result = subprocess.run(
            [grace_cmd, "--help"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return False
    if result.returncode != 0:
        return False
    combined = (result.stderr or "") + (result.stdout or "")
    if "bun: No such file" in combined or "command not found: bun" in combined:
        return False
    return True


def _locate_grace_entry() -> Path | None:
    """Find the upstream grace.ts entry under any global node_modules.

    Walks every PM's reported global root (npm/pnpm/yarn/bun) plus a few
    standard hardcoded paths. Used as the target of the tsx-based fallback
    when Bun isn't available: tsx invokes the file directly and bypasses
    the Bun shebang.
    """
    for nm in _global_node_modules_roots():
        candidate = nm / "@osovv" / "grace-cli" / "src" / "grace.ts"
        if candidate.exists():
            return candidate
    return None


def _grace_via_tsx_works(entry: Path, prefer_pm: str | None = None) -> bool:
    """Smoke-test running grace.ts under `tsx` (Node-based TS runner).

    Resolves tsx through `_resolve_executable` so an install via yarn/pnpm
    works even when their global bin dir isn't on $PATH. grace-cli source
    uses no Bun-specific APIs (verified against upstream 3.8.0), so any
    working TS runner executes it cleanly.
    """
    tsx_path = _resolve_executable("tsx", prefer_pm=prefer_pm)
    if tsx_path is None:
        return False
    try:
        result = subprocess.run(
            [tsx_path, str(entry), "--help"],
            capture_output=True, text=True, timeout=15, check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return False
    return result.returncode == 0


def _uninstall_via(pm: str, log_to_stderr: bool, reason: str) -> None:
    """Best-effort uninstall via a specific package manager.

    Used after we install the package via `pm` but the binary is broken
    (typically Node-based PM + Bun-only package). Removing it lets the
    next installer in the ladder place its own without PATH shadowing.
    """
    if shutil.which(pm) is None:
        return
    cmd = _UNINSTALLERS.get(pm)
    if not cmd:
        return
    if log_to_stderr:
        print(
            f"Removing {pm}-installed grace ({reason}) before trying next installer…",
            file=sys.stderr,
            flush=True,
        )
    try:
        subprocess.run(cmd, capture_output=True, text=True, timeout=60, check=False)
    except (subprocess.TimeoutExpired, OSError):
        pass


def _try_install_tsx(pm: str, log_to_stderr: bool) -> bool:
    """Best-effort install of tsx via `pm`. Returns True on success.

    Resolves via `_resolve_executable` so a successful yarn/pnpm install
    counts as "tsx is available" even when its global bin dir isn't on
    $PATH — we'll invoke it by absolute path.
    """
    if _resolve_executable("tsx", prefer_pm=pm) is not None:
        return True
    cmd = _TSX_INSTALLERS.get(pm)
    if not cmd:
        return False
    if log_to_stderr:
        print(f"Installing tsx (TypeScript runner) via {pm}…", file=sys.stderr, flush=True)
    exit_code, _ = _run_installer(cmd, tee_to_stderr=log_to_stderr)
    return exit_code == 0 and _resolve_executable("tsx", prefer_pm=pm) is not None


def try_install_grace_cli(
    dry_run: bool = False,
    grace_cmd: str = "grace",
    log_to_stderr: bool = False,
) -> dict[str, Any]:
    """Install grace-cli with a runtime-aware ladder + tsx fallback.

    Two-tier strategy:
      1. Direct: install via bun/npm/yarn/pnpm. After each install, smoke-test
         `grace --help`. If the binary actually runs (Bun present), report
         `installed` and stop.
      2. tsx fallback: if a Node-based PM placed grace.ts on disk but the
         binary doesn't execute (no Bun), install `tsx` (also via the same
         PM) and verify `tsx /path/to/grace.ts --help` works. If yes, report
         `installed_via_tsx` with the entry path — callers run grace via tsx
         instead of the broken shebang.
      3. If neither tier yields a working invocation across all available
         installers — return `failed` with `error_type: "broken_runtime"` and
         a hint listing both Bun and tsx as resolution options. doubled-graph
         keeps going; grace-cli failure is non-fatal for `setup`.

    Return shape:
      - already_installed: {"status", optional "runtime"/"entry"}
      - dry_run:           {"status", "via", "command"}
      - installed:         {"status", "via", "command", "runtime": "bun"}
      - installed_via_tsx: {"status", "via", "command", "runtime": "tsx",
                            "entry": "<path to grace.ts>"}
      - failed:            {"status", "via", "error_type", "hint", ...}
      - no_package_manager:{"status", "hint"}
    """
    if _grace_runs_ok(grace_cmd):
        return {"status": "already_installed", "runtime": "bun"}

    # tsx may already be set up from a previous run (across any PM's globals).
    pre_entry = _locate_grace_entry()
    if pre_entry is not None and _grace_via_tsx_works(pre_entry):
        return {
            "status": "already_installed",
            "runtime": "tsx",
            "entry": str(pre_entry),
            "tsx": _resolve_executable("tsx"),
        }

    last_attempt: dict[str, Any] | None = None
    runtime_breakage_seen = False

    for pm, cmd in INSTALLERS:
        if shutil.which(pm) is None:
            continue
        command_str = " ".join(cmd)
        if dry_run:
            return {"status": "dry_run", "via": pm, "command": command_str}

        if log_to_stderr:
            print(
                f"`{grace_cmd}` not (cleanly) installed — trying {pm}: {command_str}",
                file=sys.stderr,
                flush=True,
            )
        exit_code, output = _run_installer(cmd, tee_to_stderr=log_to_stderr)

        if exit_code != 0:
            error_type, hint = _classify_install_error(pm, output)
            last_attempt = {
                "via": pm,
                "command": command_str,
                "exit_code": exit_code,
                "error_type": error_type,
                "hint": hint,
                "stderr": output[-1500:] if output else "",
            }
            continue

        # Tier 1: direct invocation works (Bun present).
        if _grace_runs_ok(grace_cmd):
            return {
                "status": "installed",
                "via": pm,
                "command": command_str,
                "runtime": "bun",
            }

        # Tier 2: binary on disk but shebang requires bun. Try tsx fallback.
        runtime_breakage_seen = True
        entry = _locate_grace_entry()
        if (
            entry is not None
            and _try_install_tsx(pm, log_to_stderr)
            and _grace_via_tsx_works(entry, prefer_pm=pm)
        ):
            return {
                "status": "installed_via_tsx",
                "via": pm,
                "command": command_str,
                "runtime": "tsx",
                "entry": str(entry),
                "tsx": _resolve_executable("tsx", prefer_pm=pm),
            }

        # Neither tier worked through this PM — clean up and keep trying.
        _uninstall_via(pm, log_to_stderr, reason="installed but doesn't execute, tsx fallback also failed")
        last_attempt = {
            "via": pm,
            "command": command_str,
            "error_type": "broken_runtime",
        }

    if last_attempt is None:
        return {
            "status": "no_package_manager",
            "hint": (
                "No JS package manager found. Install one of: Bun (https://bun.sh/), "
                "Node.js+npm, yarn, or pnpm, then rerun `doubled-graph setup`."
            ),
        }

    if runtime_breakage_seen:
        return {
            "status": "failed",
            "error_type": "broken_runtime",
            "hint": (
                "@osovv/grace-cli's bin is a TypeScript file with `#!/usr/bin/env bun` "
                "shebang. We tried every available installer and also the tsx fallback "
                "(Node-based TS runner) but none produced a runnable grace. Resolve by "
                "either:\n"
                "  • Installing Bun runtime:\n"
                "      macOS:   brew install bun\n"
                "      Linux:   curl -fsSL https://bun.sh/install | bash\n"
                "      Windows: powershell -c \"irm bun.sh/install.ps1 | iex\"\n"
                "  • Or installing tsx manually: `npm install -g tsx`, then rerun setup.\n"
                "doubled-graph itself works without grace-cli; only the gateway "
                "subcommands `lint`, `module show`, `file show` need it."
            ),
            **{k: v for k, v in last_attempt.items() if k != "hint"},
        }

    return {"status": "failed", **last_attempt}


@dataclass
class ModuleRecord:
    id: str
    found: bool = True   # 1.4.4: false when grace says "module not in declared graph"
    purpose: str = ""
    exports: list[str] | None = None
    crosslinks: list[str] | None = None
    raw: dict | None = None


@dataclass
class FileRecord:
    path: str
    found: bool = True   # 1.4.4: false when grace says "file not found / no anchors"
    module_contract: str | None = None
    module_map: list[str] | None = None
    contracts: list[dict] | None = None
    blocks: list[dict] | None = None
    change_summary: list[dict] | None = None
    raw: dict | None = None


class GraceCLI:
    """Thin subprocess wrapper around the upstream `grace` CLI (Bun, MIT).

    Why this class: grace CLI is the only lightweight way to query grace
    artifacts (`docs/*.xml`, module records, file-level anchors) without
    re-implementing the parser. Everywhere in doubled-graph where we need
    those, we go through this wrapper — never shell out inline — so that:

      1. If `grace` CLI is missing, we fail with one consistent error
         (`GraceCLIMissing`) instead of cryptic FileNotFoundError.
      2. When upstream changes its flag names / stdout format, the fix is
         localized here (not in every caller).
      3. Our gateway commands (`doubled-graph lint|module|file`) have a
         predictable boundary to subprocess.
    """

    def __init__(self, repo_path: Path, command: str = "grace"):
        self.repo_path = repo_path
        self.command = command
        # Resolved at first `_run` call: either ("bun", [grace_cmd]) when the
        # binary runs natively, or ("tsx", [tsx, grace.ts]) when we have a
        # Node-based fallback. Cached so subsequent calls don't re-probe.
        self._invocation: tuple[str, list[str]] | None = None

    def _check(self) -> None:
        """Verify a working `grace` invocation exists, auto-installing if not.

        Accepts both native (Bun runtime) and tsx (Node-based) installations —
        the install ladder in `try_install_grace_cli` decides which one a
        given environment ends up with.

        Caches invocation prefix off `result["runtime"]`, NOT off `status`.
        Reason: `try_install_grace_cli` returns `status="already_installed"`
        for both bun-direct and tsx-fallback (when a previous setup left tsx
        wired up). Using `status` alone caches `("bun", [grace])` for the
        tsx case too — the next `_run` then executes the bun-shebang grace
        binary and fails with rc=127 `env: bun: No such file or directory`.
        Fixed in 1.4.1: dispatch on `runtime` field, which `try_install`
        sets unambiguously.

        Also resolves `tsx` to an absolute path here (via `_resolve_executable`)
        rather than relying on the literal "tsx" being on PATH at exec time —
        same GUI-launcher PATH-stripping issue we fixed for the MCP entry in
        1.0.11. Caching a literal "tsx" string would fail in IDE-spawned
        contexts where pnpm/yarn-installed tsx isn't on $PATH.
        """
        result = try_install_grace_cli(grace_cmd=self.command, log_to_stderr=True)
        status = result["status"]
        if status not in ("already_installed", "installed", "installed_via_tsx"):
            raise GraceCLIMissing(
                f"`{self.command}` is not runnable in this environment "
                f"(status={status}). Hint: {result.get('hint', 'see structured report')}"
            )

        runtime = result.get("runtime")
        entry = result.get("entry")
        if runtime == "tsx" and entry:
            # Prefer the absolute tsx path the installer reported; fall back to
            # cross-PM resolution (npm/yarn/pnpm/bun globals + standard paths).
            tsx_path = result.get("tsx") or _resolve_executable("tsx")
            if tsx_path is None:
                raise GraceCLIMissing(
                    f"`{self.command}` reports tsx-runtime but tsx executable "
                    "is not resolvable. Reinstall via `doubled-graph setup`."
                )
            self._invocation = ("tsx", [tsx_path, str(entry)])
        elif self._invocation is None:
            self._invocation = ("bun", [self.command])

    def _build_cmd(self, args: list[str]) -> list[str]:
        """Return the full subprocess argv for invoking grace with `args`.

        Probes once between two strategies:
          1. Direct: `grace ...args`. Works when Bun is present.
          2. tsx: `<resolved-tsx-path> <path-to-grace.ts> ...args`. Works on
             Node-only systems via tsx; resolves tsx by absolute path so
             yarn/pnpm globals work even when their bin dir isn't on $PATH.

        Raises GraceCLIMissing if neither strategy is viable. Cached on the
        instance — flips only across processes (e.g. after a fresh setup).
        """
        if self._invocation is not None:
            return [*self._invocation[1], *args]

        if _grace_runs_ok(self.command):
            self._invocation = ("bun", [self.command])
            return [self.command, *args]

        entry = _locate_grace_entry()
        if entry is not None:
            tsx_path = _resolve_executable("tsx")
            if tsx_path is not None and _grace_via_tsx_works(entry):
                self._invocation = ("tsx", [tsx_path, str(entry)])
                return [tsx_path, str(entry), *args]

        raise GraceCLIMissing(
            f"`{self.command}` is on PATH but won't execute, and no tsx fallback "
            "is available. Install Bun (https://bun.sh/) or tsx (`npm install -g tsx`)."
        )

    def _run_soft(self, args: list[str]) -> dict[str, Any]:
        """Run grace, return rc/stdout/stderr structured. Raise only on real failure.

        Soft-failure protocol (1.4.4): rc=0 = success, rc=1 = expected
        non-success (lint findings, module not found, file missing, no
        matches). rc≥2 OR rc=1 with empty stdout AND empty stderr = real
        tool failure (raise).

        Why this exists: pre-1.4.4 every grace wrapper called `_run` which
        raised on any rc!=0. The MCP layer caught the RuntimeError and
        wrapped it as `GRACE_CLI_ERROR` — same noisy shape for both real
        crashes and "not found" lookups. Models couldn't tell the cases
        apart from the JSON. `_run_soft` returns structured rc to callers
        that want to handle "not found" as a normal outcome (return record
        with `found: false`); legacy `_run` still raises for callers that
        actually want raise-on-failure semantics.
        """
        self._check()
        cmd = self._build_cmd(args)
        proc = subprocess.run(
            cmd,
            cwd=str(self.repo_path),
            capture_output=True,
            text=True,
            check=False,
        )
        rc = proc.returncode
        out = proc.stdout
        err = proc.stderr

        # Real failure: tool crashed (rc≥2) OR rc=1 with no output of any
        # kind (grace returned a failure code but didn't say why — treat as
        # ambiguous and surface as error; the alternative would silently
        # swallow real errors as "not found").
        if rc >= 2 or (rc == 1 and not out.strip() and not err.strip()):
            parts = [f"grace {' '.join(args)} failed (rc={rc})"]
            if err.strip():
                parts.append(f"stderr: {err.strip()}")
            if out.strip():
                parts.append(f"stdout: {out.strip()}")
            raise RuntimeError("\n  ".join(parts))

        return {"rc": rc, "ok": rc == 0, "stdout": out, "stderr": err}

    def _run(self, args: list[str]) -> str:
        """Run `grace <args>` synchronously, capture stdout, raise on non-zero exit.

        Intentionally plain: no streaming, no async, no retries. Callers that
        need richer handling should wrap this, not fork it. Routing between
        native bun and tsx fallback is delegated to `_build_cmd`.

        Errors include BOTH stdout and stderr (1.4.2 fix): grace tools tend to
        write findings/diagnostics to stdout and only fatal traces to stderr,
        so dropping stdout on failure was the same as throwing away the actual
        explanation of what went wrong. The model would see "rc=1: <empty>"
        and have nothing to act on.
        """
        self._check()
        cmd = self._build_cmd(args)
        proc = subprocess.run(
            cmd,
            cwd=str(self.repo_path),
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            stderr = proc.stderr.strip()
            stdout = proc.stdout.strip()
            parts = [f"grace {' '.join(args)} failed (rc={proc.returncode})"]
            if stderr:
                parts.append(f"stderr: {stderr}")
            if stdout:
                parts.append(f"stdout: {stdout}")
            raise RuntimeError("\n  ".join(parts))
        return proc.stdout

    def lint(self, verbose: bool = False) -> dict:
        """Run `grace lint` — the upstream validator of anchors and references.

        Why we expose this: `grace lint` is a methodology gate (pre-commit and
        pre-merge). Exposing it through `doubled-graph lint` keeps CI configs
        tool-name-consistent (one binary in the scripts).

        Exit-code semantics (1.4.2): `grace lint` returns rc=1 when it finds
        violations (broken anchors, dangling refs, etc) — that's normal, the
        findings are on stdout. Only rc≥2 (or rc=1 with empty stdout) is a
        real tool failure. Uses `_run_soft` (1.4.4) to share rc-handling
        with `module_show` / `file_show` / `module_find` — same protocol
        across all wrappers: rc=0 = success, rc=1 = soft failure (findings,
        not-found, no-matches), rc≥2 = real failure (raises).
        """
        args = ["lint", "--path", str(self.repo_path)]
        if verbose:
            args.append("--verbose")

        soft = self._run_soft(args)  # raises only on rc≥2 / ambiguous
        out = soft["stdout"]
        err = soft["stderr"].strip()

        # rc==0 (clean) or rc==1 (findings) — both return findings, just with
        # different `ok` and `exit_code`. Try JSON first; fall back to raw text.
        try:
            parsed = json.loads(out)
            if isinstance(parsed, dict):
                parsed.setdefault("exit_code", soft["rc"])
                parsed.setdefault("ok", soft["ok"])
                if err:
                    parsed.setdefault("stderr", err)
                return parsed
        except json.JSONDecodeError:
            pass
        return {"raw": out, "exit_code": soft["rc"], "ok": soft["ok"], "stderr": err}

    def module_show(self, id_or_path: str, with_verification: bool = False) -> ModuleRecord:
        """Fetch module record: contract + exports + deps + (opt.) V-M-* list.

        Called from `on-before-edit` and `grace-fix`-style flows when the agent
        needs to read the contract BEFORE opening the code — saves context
        window, which matters a lot for local models.

        Soft-failure shape (1.4.4): if grace can't find the module (rc=1),
        returns ModuleRecord with `found=False` instead of raising. The
        MCP layer surfaces this as `{"result": {"found": false, "id": "M-X",
        "raw": {...detail}}}` — clean signal to the model "no such module"
        without the GRACE_CLI_ERROR noise. rc≥2 still raises (real failure).

        Output shape: tries `--json` first; falls back to raw text under
        `raw.stdout` on older grace versions. The agent gets structured
        fields or raw text — both actionable.
        """
        cmd_args = ["module", "show", id_or_path, "--path", str(self.repo_path)]
        if with_verification:
            cmd_args += ["--with", "verification"]
        return self._show_with_json_fallback(
            cmd_args=cmd_args,
            constructor=lambda parsed, raw, found: ModuleRecord(
                id=id_or_path,
                found=found,
                purpose=(parsed or {}).get("purpose", "") if found else "",
                exports=(parsed or {}).get("exports") if found else None,
                crosslinks=(parsed or {}).get("crosslinks") if found else None,
                raw=parsed if (parsed and found) else ({"stdout": raw} if raw else None),
            ),
        )

    def module_find(self, query: str) -> dict:
        """Search modules by id/name/path/annotation.

        Soft-failure shape (1.4.4): empty result (rc=1, "no matches") returns
        `{"query": ..., "matches": [], "found": false}` instead of raising.
        Pre-1.4.4 raised RuntimeError → wrapped as `GRACE_CLI_ERROR` — noisy
        for an entirely normal "search returned nothing" outcome.
        """
        soft = self._run_soft(["module", "find", query, "--path", str(self.repo_path)])
        out = soft["stdout"]
        err = soft["stderr"].strip()

        if not soft["ok"]:
            # rc=1: no matches (or grace's "not found" path). Surface as empty
            # matches with explanation, don't raise.
            return {
                "query": query,
                "matches": [],
                "found": False,
                "raw": {"stdout": out, "stderr": err} if (out or err) else None,
            }

        try:
            parsed = json.loads(out)
            if isinstance(parsed, list):
                return {"query": query, "matches": parsed, "found": len(parsed) > 0}
            if isinstance(parsed, dict):
                return {"query": query, "matches": parsed, "found": True}
        except json.JSONDecodeError:
            pass
        return {"query": query, "stdout": out, "found": bool(out.strip())}

    def file_show(self, path: str, contracts: bool = True, blocks: bool = True) -> FileRecord:
        """Extract only anchor-framed sections of a file (not full content).

        The cornerstone of RAG-over-anchors: instead of dumping a 2000-line
        file into the LLM prompt, we fetch just CONTRACT + BLOCK_* the model
        needs. Without this, long files blow out local-model context budgets.

        Soft-failure shape (1.4.4): if grace can't find the file or it has
        no anchors (rc=1), returns FileRecord with `found=False` instead of
        raising. Output shape: same `--json`-with-text-fallback as
        `module_show`.
        """
        cmd_args = ["file", "show", path, "--path", str(self.repo_path)]
        if contracts:
            cmd_args.append("--contracts")
        if blocks:
            cmd_args.append("--blocks")
        return self._show_with_json_fallback(
            cmd_args=cmd_args,
            constructor=lambda parsed, raw, found: FileRecord(
                path=path,
                found=found,
                module_contract=(parsed or {}).get("module_contract") if found else None,
                module_map=(parsed or {}).get("module_map") if found else None,
                contracts=(parsed or {}).get("contracts") if found else None,
                blocks=(parsed or {}).get("blocks") if found else None,
                change_summary=(parsed or {}).get("change_summary") if found else None,
                raw=parsed if (parsed and found) else ({"stdout": raw} if raw else None),
            ),
        )

    def _show_with_json_fallback(self, cmd_args: list[str], constructor):
        """Run a grace `show`-style command, try `--json`, fall back to text.

        Soft-failure shape (1.4.4): rc=0 → constructor(parsed, raw, found=True).
        rc=1 → constructor(None, raw_with_stderr, found=False). rc≥2 → re-raise
        (real failure). Allows callers to distinguish "no such module/file"
        (a normal lookup result) from "grace tool crashed" (an actual error).

        Why two-attempt JSON probe: `module show` / `file show` both want
        structured output when grace supports it, but older grace versions
        reject `--json` with rc=1 (treated by us as "soft failure" of the
        --json variant, not the underlying lookup). On that fallback path,
        we re-run without --json and re-classify rc.
        """
        # Probe with --json. soft={rc, ok, stdout, stderr}; raises only on rc≥2.
        json_args = [*cmd_args, "--json"]
        soft = self._run_soft(json_args)
        out = soft["stdout"]
        err = soft["stderr"].strip()

        if soft["ok"]:
            try:
                parsed = json.loads(out)
                if isinstance(parsed, dict):
                    return constructor(parsed, out, True)
            except json.JSONDecodeError:
                pass  # grace returned rc=0 with non-JSON despite --json
            # rc=0 but unparseable → treat as found with raw text
            return constructor(None, out, True)

        # rc=1 with --json. Two possibilities:
        #   (a) grace doesn't support --json → retry without it
        #   (b) module/file genuinely not found → return found=False
        # Distinguish by retrying without --json:
        soft2 = self._run_soft(cmd_args)
        out2 = soft2["stdout"]
        err2 = soft2["stderr"].strip()

        if soft2["ok"]:
            return constructor(None, out2, True)

        # Both attempts came back rc=1 → genuinely "not found".
        return constructor(
            None,
            (out2 or out) + ("\n" + (err2 or err) if (err2 or err) else ""),
            False,
        )
