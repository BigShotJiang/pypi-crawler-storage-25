# doubled-graph

MCP-сервер для LLM-агентов, работающих с большими кодовыми базами.

Проблема: агент правит код не зная, кто вызывает функцию и какой у неё контракт — получаем регрессии и тихий дрейф. `doubled-graph` даёт агенту два графа одновременно:

- **Computed graph** — AST-граф реального кода (через CodeGraphContext): кто вызывает что, где определено.
- **Declared graph** — граф из артефактов (`docs/*.xml`): замысел, контракты, верификация.

Четыре MCP-инструмента:

| Инструмент | Когда |
|---|---|
| `analyze` | построить/обновить граф |
| `impact` | радиус влияния изменений — **до** правки |
| `context` | 360° вид: символ + контракт + вызовы |
| `detect_changes` | дрейф кода от артефактов — **до** коммита |

---

## Установка

**Требования:** Python 3.11+, Bun/Node (для grace-cli), [pipx](https://pipx.pypa.io/).

`doubled-graph` — CLI-утилита. Рекомендуемый способ — `pipx`: он ставит её в изолированный venv и кладёт бинарь в PATH. Это также обходит PEP 668 (`externally-managed-environment`) на современных Homebrew/Debian/Ubuntu.

### 1. Установить pipx

| OS | Команда |
|---|---|
| macOS | `brew install pipx` |
| Debian / Ubuntu | `sudo apt install pipx` |
| Fedora | `sudo dnf install pipx` |
| Arch | `sudo pacman -S python-pipx` |
| Windows / прочее | `python3 -m pip install --user pipx` |

После установки один раз добавьте pipx-папку в PATH и перезапустите терминал:

```bash
pipx ensurepath
```

### 2. Установить doubled-graph

```bash
pipx install doubled-graph
```

> Уже работаете в своём venv или conda-окружении? Тогда подойдёт обычная установка: `python3 -m pip install doubled-graph`.

---

## Первые шаги

### 1. Онбординг репозитория

```bash
cd your-project
doubled-graph setup
```

Одна команда:
- установит `@osovv/grace-cli` через первый найденный JS-менеджер (`bun` → `npm` → `yarn` → `pnpm`); если Bun отсутствует — установит `tsx` тем же менеджером и запустит grace под Node
- скопирует `prompts/` и `methodology/` в репозиторий
- запишет 5 наших skills в native-формат для всех известных IDE одновременно (`.claude/skills/`, `.cursor/rules/`, `.continue/rules/`, `.roo/rules/`, `.kilocode/rules/`, `.opencode/rules/` + `opencode.json`, `.windsurfrules`) — мы не знаем, каким клиентом вы пользуетесь
- зарегистрирует MCP-сервер в вашей IDE (Claude Code / Cursor / Continue)
- установит `git post-commit` хук для автообновления графа
- запустит первый полный `analyze`

Посмотреть план без реальных изменений:

```bash
doubled-graph setup --dry-run
```

Явно указать IDE:

```bash
doubled-graph setup --ide claude-code
```

### 2. Подключить MCP вручную (если нужно)

Рекомендуем `doubled-graph setup` — он сам сгенерирует `.mcp.json` с правильными значениями. Это важно: GUI-приложения (Claude Desktop, Cursor, Continue) на macOS стартуют без `~/.local/bin` в PATH, и простая запись `command: "doubled-graph"` у них не работает.

Если нужно прописать руками — используйте абсолютный путь к Python, в который установлен `doubled-graph`:

```bash
# Узнать путь к нужному Python:
doubled-graph --version  # проверить, что бинарь работает
head -1 "$(which doubled-graph)"  # вывести shebang — это и есть нужный python
```

`.mcp.json` в корне репозитория:

```json
{
  "mcpServers": {
    "doubled-graph": {
      "command": "/Users/you/.local/pipx/venvs/doubled-graph/bin/python",
      "args": ["-m", "doubled_graph", "serve"]
    }
  }
}
```

### 3. Инициализация

Введите в ваш ИИ первый промт. Остальные промты он сам подгрузит.

Сценарий 1. Новый проект -  `prompts/new-project/00-entry-prompt.md`.

Сценарий 2. Миграция существующего - `prompts/migrate-existing-project/00-entry-prompt.md`.


---

## Другие команды

```bash
# Обновить граф вручную
doubled-graph analyze --mode auto

# 360° контекст символа
doubled-graph context validateUser

# Текущая фаза методологии (migration | post_migration)
doubled-graph phase get
doubled-graph phase set post_migration --reason "migration complete"
```

---

## Удаление

```bash
pipx uninstall doubled-graph
```

(или `python3 -m pip uninstall doubled-graph`, если ставили в venv).

Это снимает сам CLI и Python-зависимости. Артефакты, которые `doubled-graph setup` создал в вашем репозитории, нужно удалить вручную:

- запись `doubled-graph` в `.mcp.json` (Claude Code) / `.cursor/mcp.json` / `.continue/config.json`
- скопированные `prompts/` и `methodology/` — если они больше не нужны
- skill-файлы для IDE: каталоги `.claude/skills/doubled-graph-*/`, `.cursor/rules/doubled-graph-*.mdc`, `.continue/rules/doubled-graph-*.md`, `.roo/rules/doubled-graph-*.md`, `.kilocode/rules/doubled-graph-*.md`, `.opencode/rules/doubled-graph-*.md`, блок между `<!-- doubled-graph-skills:start -->` / `<!-- ... :end -->` в `.windsurfrules`, и запись `.opencode/rules/*.md` в `opencode.json` `instructions`
- git-хук `.git/hooks/post-commit` (проверьте содержимое — там может быть ваша логика поверх нашей)
- локальный кеш графа: `rm -rf .doubled-graph`
- grace-cli (отдельный Bun/Node-пакет) — через тот менеджер, которым ставился: `bun remove -g @osovv/grace-cli` или `npm uninstall -g @osovv/grace-cli`

---

## Документация

- [SPEC.md](docs/SPEC.md) — архитектура, хранилище `.doubled-graph/`
- [TOOLS.md](docs/TOOLS.md) — подробные схемы инструментов
- [HOOKS.md](docs/HOOKS.md) — git и Claude Code хуки
- [CHANGELOG.md](docs/CHANGELOG.md) — история изменений

---

## Лицензия

MIT. Upstream-компоненты (CodeGraphContext, grace-marketplace) — MIT.
