# for-ai-maintenance — пакет для ежедневной поддержки

**Этот каталог — для ИИ-агента, который работает в проекте, уже прошедшем сценарий «новый проект» или «миграцию» (см. `methodology/workflow.md`).**

Режим `AGENTS.md` — обычно `post_migration` (если иначе — см. [drift-and-priority.md](../methodology/drift-and-priority.md)).

---

## Чтение (ссылки, активируются по триггерам)

### Перед правкой любого кода
→ [../prompts/maintenance/on-before-edit.md](../prompts/maintenance/on-before-edit.md).

**Триггер:** намерение изменить существующую функцию/класс/модуль.
**Обязательная операция:** `doubled-graph.impact(target, direction="upstream")`.
**Если `risk.level ∈ {HIGH, CRITICAL}`** — остановись, покажи, жди подтверждения.

### После правки, до коммита
→ [../prompts/maintenance/on-after-edit.md](../prompts/maintenance/on-after-edit.md).

**Последовательность:** `doubled-graph.analyze(mode="incremental")` → если семантика, `Edit` `docs/knowledge-graph.xml` (Export/CrossLink) и `docs/development-plan.xml` (Path/criticality) → `doubled-graph.detect_changes(scope="staged")` → `doubled-graph.lint()` → тесты → commit.

### Обнаружен дрейф
→ [../prompts/maintenance/on-drift-detected.md](../prompts/maintenance/on-drift-detected.md) (или skill `doubled-graph-drift`).

**Триггер:** `doubled-graph.detect_changes()` вернул непустой drift.
**В `migration`:** `Edit` `docs/*.xml` под код per drift type (см. skill `doubled-graph-drift` § A); diff ревью; commit.
**В `post_migration`:** ask user per drift type (new req / bug / drift unknown), см. skill § B.

### После ручной правки человеком
→ [../prompts/maintenance/on-user-manual-edit.md](../prompts/maintenance/on-user-manual-edit.md).

**Триггер:** файлы изменены без участия ИИ (коммит от человека, DG-Authored: human/mixed).

---

## Hooks (автоматика)

Установлены (или должны быть — `doubled-graph init-hooks --all`):

1. **`git post-commit`** — `doubled-graph analyze --mode incremental` автоматически после каждого коммита.
2. **Claude Code `PostToolUse`** (если IDE — Claude Code) — `doubled-graph analyze` после каждой Edit/Write tool-use.
3. **`prepare-commit-msg`** (опц.) — добавляет `DG-Authored: ai | human | mixed` trailer.

См. [../docs/HOOKS.md](../docs/HOOKS.md) для деталей.

---

## Что ИИ **не делает** в maintenance-режиме

- Не создаёт новые `M-*` модули без явного цикла обновления `<UC-*>` в `requirements.xml` + `<Module>` в `development-plan.xml` + approval-gate.
- Не меняет контракты существующих модулей без подтверждения — это новое требование.
- Не переключает phase в `AGENTS.md`.
- Не удаляет записи из `DRIFT.md` без resolution.
- Не пушит / не мёрджит — пользователь.

---

## Fallback'и (важно)

Если инструменты недоступны:

- **MCP-сервер `doubled-graph` не отвечает** → fallback в Bash CLI: `doubled-graph analyze --mode incremental --paths X`, `doubled-graph impact <symbol>`, `doubled-graph detect-changes --scope staged`, `doubled-graph lint`. Эквивалентный результат, медленнее (subprocess overhead).
- **`grace` CLI недоступен** (нужен для wrapper-tools `lint`/`module_show`/`file_show`) → ставится автоматически при `doubled-graph setup` (через `bun add -g @osovv/grace-cli` или tsx-фолбек на Node-системах). Без него — `Read` `docs/*.xml` напрямую.
- **`doubled-graph.impact` вернул `target_resolved.module_id=None`** → возможно символ не найден в computed graph. Прочти `development-plan.xml` напрямую, найди `<Path>` с тронутым файлом, классифицируй risk консервативно (default `MEDIUM`).
