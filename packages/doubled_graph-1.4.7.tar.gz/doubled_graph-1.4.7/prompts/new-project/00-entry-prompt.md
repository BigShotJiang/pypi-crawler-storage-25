# Новый проект — вход

**Скопируй этот текст в свой ИИ-ассистент** (Claude Code, Cursor, Continue, …) как первое сообщение после открытия пустого репозитория.


## Что произойдёт дальше

ИИ должен прочитать `prompts/new-project/01-intent-interview.md` и задать вопросы. 

## Если у тебя нет пустого репозитория

Используй `prompts/migrate-existing-project/00-entry-prompt.md` вместо этого.

## Если ИИ в IDE без tools+MCP

Методология не работает без MCP и tools — см. `methodology/README.md § Предусловия`. Подключи MCP (в IDE-adapter из `methodology/runtime-adapters/`) или смени IDE.


---

# Промт


```
Я начинаю новый проект по методологии doubled-graph.

Твоя задача — провести меня через полный цикл от бизнес-идеи до работающего MVP с артефактами, разметкой, тестами, hooks.

Последовательность шагов — ровно такая:
1. Intent-интервью (prompts/new-project/01-intent-interview.md).
2. Bootstrap артефактов (prompts/new-project/02-requirements.md): через Write создай docs/*.xml шаблоны (минимум: requirements.xml, technology.xml, development-plan.xml, knowledge-graph.xml, verification-plan.xml, operational-packets.xml) и AGENTS.md с phase-блоком `post_migration`.
   Глубина артефактов — всегда максимальная, никаких lite-вариантов (methodology/auto-scaling.md).
3. Technology (03-technology.md) — ДО написания development-plan.
4. Development plan (04-development-plan.md) — approval gate обязателен.
5. Verification plan (05-verification-plan.md).
6. Генерация кода по фазам (06-generate.md). Каждую фазу подтверждаем отдельно.
7. Первый `doubled-graph.analyze(mode="full")`.
8. Установка hooks (07-post-init-sync.md).

Правила:
- Все approval-gates — явные. Не иди дальше без моего подтверждения.
- Перед любой правкой уже созданного файла — активируй skill `doubled-graph-before-edit` (или fallback: prompts/maintenance/on-before-edit.md).
- В конце каждой фазы кодогенерации — skill `doubled-graph-after-edit` (или prompts/maintenance/on-after-edit.md).
- Доступные MCP-инструменты: `doubled-graph.analyze`, `doubled-graph.impact`, `doubled-graph.context`, `doubled-graph.detect_changes`, `doubled-graph.lint`, `doubled-graph.module_show/find`, `doubled-graph.file_show`, `doubled-graph.health`. Всё остальное (создание/правка `docs/*.xml`) — через стандартные Read/Edit/Write.
- **Каждый шаг начинается с явного чтения соответствующего файла промпта через Read tool.** Не угадывай содержимое — читай файл и следуй его инструкциям точно.

Если что-то из этого неясно или отсутствует — скажи сейчас, прежде чем начать.

Начнём с шага 1 — прочитай `prompts/new-project/01-intent-interview.md` и следуй его инструкциям.
```

