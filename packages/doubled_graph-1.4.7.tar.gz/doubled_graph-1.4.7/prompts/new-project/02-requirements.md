# 02 — Requirements

**Роль ИИ:** заполнить `docs/requirements.xml` на основе intent-интервью. Использовать AAG-нотацию.

---

## Инструкция

**Шаг 0 — прочитай scratchpad интервью.**

Обязательный первый шаг:

```
Read: .doubled-graph/drafts/interview.md
```

**Этот файл — единственный источник истины** по ответам пользователя. Не пытайся вспомнить ответы из истории чата — для локальной модели середина контекста ненадёжна. Все `UC-*` заполняются строго из scratchpad'а.

Если scratchpad **отсутствует** (пользователь запустил 02 напрямую) — остановись, скажи пользователю: «Интервью не проведено, не могу заполнить requirements.xml без данных. Вернись к `01-intent-interview.md`.» Не угадывай.

Если scratchpad **имеет `Status: in-progress`** — остановись, скажи «интервью не завершено, продолжим его».

**Шаг 1 — bootstrap артефактов.** Если их ещё нет в `docs/`, создай через `Write`:

- `docs/requirements.xml`, `docs/technology.xml`, `docs/development-plan.xml`, `docs/knowledge-graph.xml`, `docs/verification-plan.xml`, `docs/operational-packets.xml` — пустые контейнеры с корневыми элементами (`<Requirements>`, `<Technology>`, `<DevelopmentPlan>`, etc), готовые к заполнению.
- `AGENTS.md` — minimal stub + phase-блок (см. ниже).

Шаблоны элементов и примеры — в [`methodology/artifacts.md`](../../methodology/artifacts.md). Для guideance можно посмотреть upstream [grace-init templates](https://github.com/osovv/grace-marketplace/tree/main/skills/grace/grace-init/assets/docs).

В `AGENTS.md` сразу добавь phase-блок:

```markdown
<!-- doubled-graph:phase:start -->
## doubled-graph phase
phase: post_migration
updated: <сегодняшняя дата ISO>
<!-- doubled-graph:phase:end -->
```

**Шаг 2.** Заполни `docs/requirements.xml` согласно ответам из Блока A scratchpad'а (`.doubled-graph/drafts/interview.md`).

Формат — см. `methodology/artifacts.md § 1`. Каждый `UseCase` должен иметь:
- `Actor` — кто делает;
- `Action` — что делает (snake_case глагольная фраза);
- `Goal` — ожидаемый результат или критерий успеха;
- `NonFunctional` — **обязательно** для каждого UC (latency, security, audit, privacy). Если non-functional не проговорён в интервью — вернись к пользователю и уточни, не оставляй пустым.

Примеры AAG:

```xml
<UseCase id="UC-001">
  <Actor>Buyer</Actor>
  <Action>place_order</Action>
  <Goal>получить подтверждение в течение 3 секунд</Goal>
</UseCase>

<UseCase id="UC-002">
  <Actor>Admin</Actor>
  <Action>revoke_user</Action>
  <Goal>доступ пользователя прекращён в течение 60 секунд с момента revoke</Goal>
  <NonFunctional>
    <Audit>событие revocation логируется с anchor="revokeUser:BLOCK_FINALIZE"</Audit>
  </NonFunctional>
</UseCase>
```

**Шаг 3.** Покажи пользователю в **таком порядке**:

1. **Саммари**: количество UC, список Actor's, по каждому UC одной строкой «Actor → Action → Goal».
2. **⚠ Что требует особого внимания**:
   - UC, у которых Goal не измерим (нет числа, только проза);
   - UC с PII (помечены `<NonFunctional><Privacy>PII-touching</Privacy>`) — критичный путь для verification;
   - UC, которые я склеил/разделил относительно сказанного в интервью (интерпретация ИИ);
   - non-functional-ограничения, которые были упомянуты в интервью, но я не смог однозначно разместить.
   Если ничего — «отклонений нет».
3. **Чек-лист одобрения**:
   - [ ] нет UC, объединяющих два действия (регистрация + вход — это два UC);
   - [ ] Goal измерим там, где это возможно на старте проекта;
   - [ ] все упомянутые в интервью акторы присутствуют;
   - [ ] PII-связанные UC помечены;
   - [ ] non-functional из интервью не потерялись.
4. **Вопрос** (Approval-gate, не upstream, но наш — перед технологией):

   > Это твой набор use-cases? Чтобы одобрить — пройдись по чек-листу выше. Если нужно уточнить/добавить/удалить — назовите UC-id и что изменить.

Пока пользователь не подтвердил явно — **не** переходи к шагу 3 `03-technology.md`. Ответ «ок» без упоминания чек-листа — просьба подтвердить явно.

**При revision**: показывай diff относительно предыдущей версии (добавлены/удалены/изменены UC), не полный список заново.

---

## Правила заполнения

- **UC-id формат**: `UC-NNN`, три цифры с нулями. Не меняй при рефакторинге (stable IDs).
- **Одно действие — один UC.** Не объединяй «зарегистрироваться и войти» в один UC.
- **Goal измерим.** Не «быстро», а «p95 < 3s». Если на данном этапе цифры нет — пиши прозу, но возвращайся к измеримости на approval.
- **Приватность.** Если UC связан с PII — явно помечай `<NonFunctional><Privacy>PII-touching</Privacy></NonFunctional>`.

---

## Переход к шагу 3

После подтверждения пользователя — прочитай `prompts/new-project/03-technology.md` через Read tool и следуй его инструкциям.
