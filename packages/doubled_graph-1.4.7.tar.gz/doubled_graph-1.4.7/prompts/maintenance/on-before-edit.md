# on-before-edit — перед любой правкой функции/класса/модуля

**Целевая аудитория:** ИИ-ассистент в IDE.
**Триггер:** намерение изменить существующий код.
**Время на исполнение:** ≤ 2 секунды если index свежий, ≤ 10 секунд если требуется инкремент.

---

## Канонический workflow — skill `doubled-graph-before-edit`

`doubled-graph setup` устанавливает skill `doubled-graph-before-edit` (см. `.claude/skills/doubled-graph-before-edit/SKILL.md` или эквиваленты для других IDE). Этот промпт-файл — fallback / навигационный пункт для случаев когда skill не загружен.

---

## Шаги (краткая форма)

**1. Обновить computed graph** (если в IDE нет PostToolUse hook):

```
doubled-graph.analyze(mode="incremental", paths=["<тронутые-файлы>"])
```

**2. Impact analysis (обязательно):**

```
doubled-graph.impact(target="<имя-функции/класса/путь>", direction="upstream", depth=3)
```

Возвращается JSON со структурой `risk.level`, `risk.reasons`, `direct[]`, `transitive[]`, `affected_modules[]`, `affected_verification[]`, `target_resolved.module_id`.

**3. Интерпретация risk.level:**

| risk.level | Действие |
|---|---|
| `NONE` / `LOW` | Продолжай правку без подтверждения. |
| `MEDIUM` | Скажи пользователю: «правлю X, затрагивает N callers: [...]». Продолжай. |
| `HIGH` | **Останови.** Покажи `risk.reasons`. Жди явного «продолжай». |
| `CRITICAL` | **Останови.** Покажи `risk.reasons` + `affected_modules` + `affected_verification`. Предложи альтернативу. Жди явного «продолжай». |

**4. Режим и контракт.** Прочитай `AGENTS.md`, найди блок `<!-- doubled-graph:phase:start -->`.

**В `post_migration` (артефакты = ground-truth):**
1. Возьми `module_id` из `impact().target_resolved.module_id`.
2. Прочитай контракт: `doubled-graph.file_show(path="<file>", contracts=true)`.
3. Если правка нарушает контракт — это **новое требование**. **Останови.** Запроси у пользователя planning-цикл: `Edit` `<UC-*>` в `requirements.xml` + `<Module>` в `development-plan.xml`, явный approval, потом правишь код.

**В `migration` (код = ground-truth):**
- Правки разрешены свободнее.
- После правки **обязательно** `Edit` `docs/*.xml` под новые экспорты/контракт (см. `on-after-edit.md` шаг 2).

**5. Провести правку.** Используй Edit/Write. Сохрани якоря (`START_CONTRACT`, `START_BLOCK_*`, `MODULE_CONTRACT`, `MODULE_MAP`). Если в файле есть `START_CHANGE_SUMMARY` — добавь запись с датой ISO и кратким why.

**6. Перейти на `on-after-edit.md`.**

---

## Anti-patterns

- Не правь без `impact`. Это базовый risk-gate.
- Не игнорируй HIGH/CRITICAL «молча» — пользователь должен видеть `risk.reasons`.
- Не меняй `phase:` в `AGENTS.md` без явной просьбы.
- Не удаляй якоря при правке.
- Не утверждай «я починил всех вызывающих» без явного `detect_changes` или повторного `impact` после.

---

## Если инструмент недоступен

- **`doubled-graph.impact` упал**: предупреди пользователя, сделай `grep` вызовов руками, классифицируй risk консервативно (default `MEDIUM`).
- **`doubled-graph.file_show` недоступен** (`grace` CLI не установлен): прочитай файл напрямую через `Read`, найди `MODULE_CONTRACT` блоки руками.
- **`AGENTS.md` нет**: default `post_migration`, предупреди пользователя.
