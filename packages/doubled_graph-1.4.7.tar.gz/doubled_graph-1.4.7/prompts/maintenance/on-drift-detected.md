# on-drift-detected — обнаружен дрейф

**Целевая аудитория:** ИИ-ассистент.
**Триггер:** `doubled-graph.detect_changes()` вернул непустой drift.

См. также: skill `doubled-graph-drift` (полная версия), `methodology/drift-and-priority.md`, `methodology/principles.md § Операционный паттерн — externalize state`.

---

## Externalize state (обязательно)

Drift из 5+ items, каждый — решение пользователя. К 7-му item локалка забудет первые. Журнал обязателен.

- Файл: `.doubled-graph/drafts/drift-session-<ISO>.md` — append-only.
- Поля per item: `тип`, `target`, `время`, `user-decision` (`new-req` / `bug` / `defer`), `next action`, `status`.
- Конец сессии — `Status: completed`, не удалять (audit trail).

---

## Шаг 0 — определи режим

Прочитай `AGENTS.md` phase-блок.

- **`migration`** → § A.
- **`post_migration`** → § B.

---

## § A. Режим `migration`

Код = ground-truth. Артефакты догоняют без вопросов.

**A.1 — пройди по items drift'а и обнови `docs/*.xml` через `Edit`.** Маппинг типов:

| тип drift'а | что править |
|---|---|
| `code_without_module` | `docs/development-plan.xml` — добавить `<Module id="M-NEW">` с `<Path>` и `<criticality>` (спроси у пользователя если не очевидно) |
| `module_without_code` | `docs/development-plan.xml` — пометить `<Module>` как `<Status>deprecated</Status>` или удалить |
| `contract_mismatch` | `docs/knowledge-graph.xml` — обновить `<Export>` / pre/post/invariant под реальную сигнатуру |
| `stale_crosslinks` | `docs/knowledge-graph.xml` — удалить `<CrossLink to="..."/>` |
| `missing_verification` | активируй skill `doubled-graph-verify` |
| `markup_missing` | через `Edit` в самом code-файле — добавь `MODULE_CONTRACT` блок (см. § B.6) |

Возьми текущий контракт через `doubled-graph.module_show(target=<M-id>)` как baseline.

**A.2 — ревью diff.** Покажи пользователю `git diff docs/`. Пользователь подтверждает: «ок, коммить» → коммит `chore(sync): sync docs after code changes`; «откати X» → правишь по инструкции.

**A.3 — вернись на `on-after-edit.md` шаг 4** (`lint` + тесты).

---

## § B. Режим `post_migration`

Артефакты = ground-truth. Дрейф — подозрение на баг или неодобренное требование. Обрабатывай **каждый тип отдельно**.

### B.1 — `code_without_module`
Функция / класс есть в коде, не покрыт ни одним `M-*`. Спроси:

> Обнаружен код без модуля: `<file>:<line> — <function/class>`
>
> Варианты:
>  (a) новое требование — добавляю `<UC-*>` в `requirements.xml` + новый `<Module M-xxx>` в `development-plan.xml` через `Edit`, размечаю код якорями, нужен ли planning-цикл с approval — скажи;
>  (b) баг (код не должен был попасть) — удаляю файл/функцию через `Edit`;
>  (c) вспомогательный dev/test код — выношу в `tests/` или `dev/`, помечаю исключением в `.grace-lint.json`;
>  (d) не знаю — пишу в `docs/DRIFT.md`, модуль-кандидат блокируется до решения.

### B.2 — `module_without_code`
`M-*` есть в плане, файлов нет. Помечен `in-progress` в `DRIFT.md` с не истекшим deadline → пропусти. Иначе спроси: (a) `deprecated`; (b) забыли реализовать → создаём issue.

### B.3 — `contract_mismatch`
Реальная сигнатура / pre/post / invariant ≠ декларированному контракту. Спроси:

> Контракт `M-AUTH-VALIDATE.validateUser` заявляет `(req: Request) -> User | null`.
> Фактическая сигнатура: `(req: Request, opts?: Options) -> User | null`.
>
> Варианты:
>  (a) новое требование (`opts` важен) — `Edit` `<Module>` в `knowledge-graph.xml` под новую сигнатуру; контракт-change должен быть отдельным коммитом с trailer `Contract-change: M-AUTH-VALIDATE signature`;
>  (b) баг (`opts` случайно добавлен) — `Edit` `src/auth/validate.ts`, откати `opts` под существующий контракт; запиши `(DG-Authored: ai)` в `CHANGE_SUMMARY`;
>  (c) не знаю — `DRIFT.md`.

### B.4 — `stale_crosslinks`
CrossLink `M-A → M-B` есть в `knowledge-graph.xml`, в computed нет вызовов между файлами модулей.

- Намеренный рефакторинг → `Edit` `knowledge-graph.xml`, удали `<CrossLink to="M-B"/>` из `<Module M-A>` после подтверждения пользователя.
- Подозрительно (потеря связи) → `DRIFT.md`, спроси не потерялась ли функциональность.

### B.5 — `missing_verification`
`M-*` есть код, нет `V-M-*`. Активируй skill `doubled-graph-verify`. Если пользователь откладывает (для critical-модуля) — заблокируй `Gate G-pre-merge` для этого модуля.

### B.6 — `markup_missing`
В файле нет `MODULE_CONTRACT` или `MODULE_MAP`. Добавь разметку **руками** по конвенции комментариев языка:
- C-family / Java / Go / Rust / TS / JS: `// START_MODULE_CONTRACT` ... `// END_MODULE_CONTRACT`
- Python / Ruby / shell: `# START_MODULE_CONTRACT` ...
- HTML / XML / Vue templates: `<!-- START_MODULE_CONTRACT --> ...`
- C# / VB: `#region START_BLOCK_NAME` ... `#endregion END_BLOCK_NAME` (нативный region парный с якорем).

Запусти `doubled-graph.lint()` для проверки.

---

## Шаг B.N — после обработки всех типов

1. Повтори `doubled-graph.detect_changes(scope="staged")`. Непусто → к соответствующему §.
2. Пусто → возвращайся в `on-after-edit.md` шаг 4.

---

## Записи в `docs/DRIFT.md`

«Не знаю» создаёт запись:

```markdown
## D-042 — M-AUTH-VALIDATE contract_mismatch (2026-04-18)

**Тип:** contract_mismatch.
**Обнаружено:** `doubled-graph.detect_changes()` в коммите `abc1234`.
**Суть:** контракт заявляет 1 аргумент, реальная сигнатура — 2.
**Решение откладывается. До решения — модуль M-AUTH-VALIDATE заблокирован для ИИ-правок.**
**Deadline:** 2026-04-22 (assumed).
**Owner:** <никто пока>.
```

Коммить отдельным коммитом: `docs(drift): register D-042 on M-AUTH-VALIDATE contract mismatch`.
