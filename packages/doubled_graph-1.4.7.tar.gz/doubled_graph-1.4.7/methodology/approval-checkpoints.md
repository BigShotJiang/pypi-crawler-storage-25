# Approval checkpoints

Ключевой принцип 2: **каждый артефакт утверждается человеком перед тем, как стать входом для следующего шага**.

**Правило без исключений:** если gate не пройден, следующий шаг не начинается. Технически это обеспечивают workflow'ы skills семейства `doubled-graph-*` (явная остановка в скиле и ожидание ответа пользователя), `doubled-graph.lint()` в CI и `doubled-graph.detect_changes()` как pre-commit/pre-merge gate.

---

## 1. Workflow gates

Точки остановки в наших skills и in-flow workflow (`prompts/new-project/`, `prompts/migrate-existing-project/`, `prompts/maintenance/`).

### Bootstrap артефактов (новый проект / миграция)
**Нет явного approval.** Создание `docs/*.xml` шаблонов + `AGENTS.md` через `Write`. Дополнительный review можно сделать руками (посмотреть, что создано) — не обязательно.

Шаблоны — inline в `prompts/new-project/` или из upstream [grace-marketplace docs templates](https://github.com/osovv/grace-marketplace/tree/main/skills/grace/grace-init/assets/docs).

### Архитектура модулей — approval-gate
После того как агент задрафтил `<Module>` записи в `docs/development-plan.xml` (через `Edit`), останавливается и показывает пользователю список.

**Что показывается:** список модулей с contract draft'ами (purpose, criticality, public exports).

**Критерий одобрения:**
- модули покрывают все `UC-*` из `requirements.xml`;
- `criticality` расставлен осознанно (`critical` / `standard` / `helper`);
- нет модулей, у которых scope не ясен.

Пользователь либо апрувит — workflow продолжается на verification draft, либо правит список — агент `Edit`-ит `development-plan.xml` и снова показывает.

### Verification draft — approval-gate
Агент по подтверждённым модулям драфтит `<V-M-*>` записи в `docs/verification-plan.xml` (через `Edit`).

**Что показывается:** список `V-M-*` записей с `kind` (unit/integration/e2e) и предварительными `Command` / `Asserts`.

**Критерий:**
- каждый модуль с `criticality ∈ {critical, standard}` имеет ≥ 1 `V-M-*`;
- для критических модулей — минимум один `integration`-тест (не только unit).

### План исполнения — approval-gate
Агент драфтит фазы / порядок исполнения в `docs/development-plan.xml`.

**Что показывается:** фазы → шаги → модули с порядком исполнения, estimated impact, зависимости.

**Критерий:**
- порядок исполнения не нарушает зависимости;
- разбивка на шаги адекватна (не слишком крупные шаги, которые могут сорвать);
- risk-level (через `doubled-graph.impact()`) для каждого затронутого символа < CRITICAL, либо явно принят.

### Contract-change — approval-gate (in-flow, маленькие)
Каждое изменение публичной сигнатуры / pre/post / invariant модуля — отдельный gate в skill `doubled-graph-after-edit` шаг 6. Агент показывает diff контракта, ждёт явного «contract change ок» / «откати».

---

## 2. doubled-graph-собственные gates (инфраструктурные)

### Phase-switch gate
Переключение `migration` → `post_migration` и обратно через `doubled-graph phase set`. Всегда требует человеческого подтверждения. Параметры:

- переход в `post_migration` — проверяется, что `doubled-graph.lint()` + `doubled-graph.detect_changes(scope="all")` оба возвращают чистый результат;
- откат → `migration` — обязательна запись в `docs/DRIFT.md` с причиной и ожидаемым окончанием.

### Pre-commit gate (рекомендован, опционален локально, обязателен в CI)

```bash
doubled-graph lint \
  && doubled-graph detect-changes --scope staged \
  && доступные unit-тесты
```

Если `detect-changes` непуст и drift не задокументирован в `DRIFT.md` — merge блокируется.

### Pre-merge gate (обязателен)

Определяется в `docs/verification-plan.xml`:

```xml
<Gate id="G-pre-merge" kind="required">
  <Check>doubled-graph lint</Check>
  <Check>doubled-graph detect-changes --scope compare --base-ref main</Check>
  <Check>pnpm test</Check>
</Gate>
```

---

## 3. Eval gates (обязательны при наличии critical-модулей)

В `verification-plan.xml` добавляется секция eval, если в `development-plan.xml` есть хотя бы один модуль с `criticality="critical"`:

```xml
<EvalGate id="E-prompt-quality" kind="required-for-critical-modules">
  <Dataset>datasets/golden-cases.jsonl</Dataset>
  <Judge kind="structured-rubric" model="<независимая-от-генератора>" />
  <Threshold metric="pass-rate" min="0.85" />
</EvalGate>
```

**Что проверяется:**
- `prompt-quality` — соответствие сгенерированного кода контракту на golden-датасете.
- `ai-regression` — прогон сохранённых сценариев, сравнение с baseline.

**LLM-as-Judge bias**: используем swap-and-compare + diverse judge (модель-судья отличается от модели-генератора).

**Важно:** eval-gates **не заменяют** unit/integration тесты (принцип 9). Это дополнительный слой для агентного поведения.

---

## 4. Drift-resolution gates (post_migration)

В `post_migration` каждый item drift'а — отдельный gate. Агент НЕ применяет автоматическую резолюцию: просит у пользователя выбор «new requirement / bug / defer» (см. skill `doubled-graph-drift` § B). «Не знаю» → запись в `docs/DRIFT.md`, модуль блокируется для ИИ-правок до решения.

В `migration` drift-resolution автоматическая (см. skill `doubled-graph-drift` § A) — артефакты обновляются под код через `Edit`, ревьюется только итоговый `git diff docs/`.

---

## 5. Таблица gates vs сценарии

| Сценарий / шаг | gate |
|---|---|
| Новый проект, intent-интервью | — (сбор данных, не gate) |
| Новый проект, bootstrap `docs/*.xml` | — |
| Новый проект, архитектура модулей | **approval-gate** |
| Новый проект, verification draft | **approval-gate** |
| Новый проект, план исполнения | **approval-gate** |
| Миграция, requirements recovery | **approval-gate** (утверждаем восстановленные требования) |
| Миграция, план | **approval-gate** (архитектура) |
| Миграция, переход в `post_migration` | **phase-switch gate** |
| Поддержка, любая правка | `impact` HIGH/CRITICAL → **approval перед правкой** |
| Поддержка, contract-change | **approval-gate** (skill `doubled-graph-after-edit` шаг 6) |
| Поддержка, drift в post_migration | **approval per item** (skill `doubled-graph-drift` § B) |
| Поддержка, перед коммитом | **pre-commit gate** (рекомендован) |
| Перед merge в main | **pre-merge gate** (обязателен) |

---

## 6. Что делать при провале gate'а

Зависит от типа провала:

- **approval отказан** → вернуться на один шаг назад, переделать артефакт.
- **`doubled-graph.lint()` не проходит** → фикс разметки якорей, чаще всего простой (см. response shape в skill `doubled-graph-after-edit` шаг 4).
- **`doubled-graph.detect_changes()` показывает drift** → применить skill `doubled-graph-drift`.
- **тесты не проходят** → стандартный debug-флоу. Skill `doubled-graph-before-edit` для понимания blast radius перед фиксом.
- **eval-gate показывает регрессию** → скорее всего изменился промпт или модель; откатываем промпт/модель или добавляем новые golden cases.

**Что не делаем:** никогда не обходим gate через `--no-verify` или эквивалент. Если gate мешает — чиним его, а не отключаем.
