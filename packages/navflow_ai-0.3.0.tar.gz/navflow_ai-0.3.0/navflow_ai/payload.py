"""Typed parsers for the payload NavFlow POSTs to your agent.

NavFlow sends a single unified shape for every invocation:

    {
      "trigger":          { ... },
      "pending_triggers": [ { "data": {...}, "timestamp": "..." } ],
      "context":          { "key": "...", "events": [...], "stats": {...} },
      "_metadata":        { "request_id": "...", "project_id": "...", ... }
    }

This module gives you typed access to it. Pydantic is required —
install with ``pip install navflow-ai[parse]``.

Typical use::

    from navflow_ai.payload import AgentPayload

    @app.post("/process")
    async def process(request: Request):
        payload  = AgentPayload.from_dict(await request.json())
        trigger  = payload.trigger
        context  = payload.context           # None or Context
        metadata = payload.metadata          # always present

        if context:
            for event in context.events:
                ...
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

try:
    from pydantic import BaseModel, ConfigDict, Field
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "navflow_ai.payload requires pydantic. Install with: "
        "pip install 'navflow-ai[parse]'"
    ) from exc


__all__ = [
    "AgentPayload",
    "Context",
    "Metadata",
    "WindowEvent",
    "WindowStats",
]


# Permissive config: extra fields are kept on .model_extra rather than dropped,
# so SDK consumers don't lose data when NavFlow adds fields server-side.
_CONFIG = ConfigDict(extra="allow")


class WindowEvent(BaseModel):
    """A single event captured in the context window."""

    model_config = _CONFIG

    data: dict[str, Any]
    timestamp: datetime


class WindowStats(BaseModel):
    """Summary statistics for the events in a context window."""

    model_config = _CONFIG

    count: int
    duration_ms: int
    first_at: datetime
    last_at: datetime


class Context(BaseModel):
    """Sliding context window delivered with the trigger.

    Present only when context windows are enabled on the pipeline.
    Events are oldest-first within the window.
    """

    model_config = _CONFIG

    key: str
    events: list[WindowEvent]
    stats: WindowStats


class Metadata(BaseModel):
    """Per-invocation metadata. Always present.

    The request_id matches the X-Request-ID header NavFlow sent — pass it
    back via NavFlow.send_output(request_id=...) so output can be traced
    end-to-end.
    """

    model_config = _CONFIG

    request_id: str
    project_id: str
    triggered_at: datetime
    context_events: int = 0
    pending_triggers: int = 0
    group_key: str | None = None


class AgentPayload(BaseModel):
    """The complete payload NavFlow POSTs to your agent.

    Use ``AgentPayload.from_dict(body)`` rather than the raw constructor —
    it normalizes the wire field name ``_metadata`` to the Python attribute
    ``metadata`` for ergonomic access.
    """

    model_config = _CONFIG

    trigger: dict[str, Any]
    pending_triggers: list[WindowEvent] = Field(default_factory=list)
    context: Context | None = None
    metadata: Metadata = Field(alias="_metadata")

    @classmethod
    def from_dict(cls, body: dict[str, Any]) -> "AgentPayload":
        """Parse a request body dict into a typed AgentPayload.

        Accepts the wire shape directly (with ``_metadata``); no manual
        renaming needed.
        """
        return cls.model_validate(body)

    @classmethod
    def from_bytes(cls, body: bytes | str) -> "AgentPayload":
        """Parse a raw request body (bytes or str) into a typed AgentPayload."""
        return cls.model_validate_json(body)
