"""HTTP client for sending agent output back to NavFlow."""

from __future__ import annotations

import uuid
from typing import Any

import requests


class NavFlow:
    """NavFlow Python SDK client.

    Sends agent output to the NavFlow receiver, which routes it to your
    configured sinks (Slack, webhooks, etc.).

    Args:
        api_key: A NavFlow API key (``nf_...``). Project-scoped or org-scoped.
        endpoint: The NavFlow receiver URL. Defaults to
            ``https://receiver.navflow.ai``.
        timeout: Per-request timeout in seconds. Defaults to ``30``.

    Example::

        from navflow_ai import NavFlow

        nf = NavFlow(api_key="nf_...")

        nf.send_output(
            payload={"summary": "Auth failures spiked at 14:02"},
            request_id=x_request_id,         # from the X-Request-ID header
            project_id=x_project_id,         # required for org-scoped keys
        )
    """

    DEFAULT_ENDPOINT = "https://ingest.navflow.ai"

    def __init__(
        self,
        api_key: str,
        endpoint: str = DEFAULT_ENDPOINT,
        timeout: float = 30.0,
    ):
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.endpoint = endpoint.rstrip("/")
        self.timeout = timeout

        self._session = requests.Session()
        self._session.headers.update({
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        })

    def send_output(
        self,
        payload: Any,
        request_id: str | None = None,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Send agent output to the NavFlow receiver.

        Args:
            payload: The output payload. Any JSON-serializable value.
            request_id: The invocation's request ID (matches the
                ``X-Request-ID`` header NavFlow sent). Auto-generated
                if omitted, but pass the real one through for end-to-end
                tracing.
            project_id: The target project UUID. Required when
                ``api_key`` is org-scoped; ignored for project-scoped keys.

        Returns:
            The receiver's JSON response, typically ``{"status": "ok"}``.

        Raises:
            requests.HTTPError: If the receiver returns a non-2xx status.
            requests.RequestException: On network errors / timeouts.
        """
        if request_id is None:
            request_id = str(uuid.uuid4())

        url = f"{self.endpoint}/v1/agent-outputs"
        headers = {}
        if project_id:
            headers["X-Project-ID"] = project_id

        resp = self._session.post(
            url,
            json={"request_id": request_id, "payload": payload},
            headers=headers,
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        """Close the underlying HTTP session. Safe to call multiple times."""
        self._session.close()

    def __enter__(self) -> "NavFlow":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"NavFlow(endpoint={self.endpoint!r})"


# Backwards compatibility for the original GlassFlow alias.
GlassFlow = NavFlow
