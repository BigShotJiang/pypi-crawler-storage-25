"""NavFlow Python SDK.

Send agent output back to NavFlow:

    from navflow_ai import NavFlow
    nf = NavFlow(api_key="nf_...")        # endpoint defaults to https://ingest.navflow.ai
    nf.send_output(payload={"summary": "..."}, request_id=x_request_id)

Parse the payload NavFlow POSTs to your agent (requires pydantic — install
with ``pip install navflow-ai[parse]``)::

    from navflow_ai.payload import AgentPayload
    payload = AgentPayload.from_dict(await request.json())
"""

from .client import GlassFlow, NavFlow

__all__ = ["NavFlow", "GlassFlow"]
__version__ = "0.2.1"
