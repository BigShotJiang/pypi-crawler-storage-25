"""Tests for the NavFlow output client."""

import json

import pytest
import requests
from pytest_httpserver import HTTPServer

from navflow_ai import NavFlow


def test_send_output_basic(httpserver: HTTPServer):
    """Project-scoped key: posts payload and request_id, returns receiver response."""
    httpserver.expect_request(
        "/v1/agent-outputs",
        method="POST",
    ).respond_with_json({"status": "ok"})

    nf = NavFlow(api_key="nf_project_key", endpoint=httpserver.url_for(""))
    result = nf.send_output(
        payload={"summary": "test"},
        request_id="req-123",
    )

    assert result == {"status": "ok"}

    # Inspect the actual request the server saw
    assert len(httpserver.log) == 1
    req, _ = httpserver.log[0]
    assert req.headers["X-API-Key"] == "nf_project_key"
    assert req.headers["Content-Type"] == "application/json"
    assert "X-Project-ID" not in req.headers
    body = json.loads(req.get_data())
    assert body == {"request_id": "req-123", "payload": {"summary": "test"}}


def test_send_output_org_scoped_includes_project_id(httpserver: HTTPServer):
    """Org-scoped key: X-Project-ID header is sent through."""
    httpserver.expect_request(
        "/v1/agent-outputs",
        method="POST",
    ).respond_with_json({"status": "ok"})

    nf = NavFlow(api_key="nf_org_key", endpoint=httpserver.url_for(""))
    nf.send_output(
        payload={"x": 1},
        request_id="req-abc",
        project_id="proj-uuid-1234",
    )

    req, _ = httpserver.log[0]
    assert req.headers["X-Project-ID"] == "proj-uuid-1234"


def test_send_output_auto_request_id(httpserver: HTTPServer):
    """When request_id is omitted, a UUID is generated."""
    httpserver.expect_request("/v1/agent-outputs").respond_with_json(
        {"status": "ok"}
    )

    nf = NavFlow(api_key="nf_x", endpoint=httpserver.url_for(""))
    nf.send_output(payload={"a": 1})

    req, _ = httpserver.log[0]
    body = json.loads(req.get_data())
    # UUID4 has 36 chars including dashes
    assert len(body["request_id"]) == 36
    assert body["request_id"].count("-") == 4


def test_send_output_raises_on_5xx(httpserver: HTTPServer):
    """5xx responses raise HTTPError."""
    httpserver.expect_request("/v1/agent-outputs").respond_with_data(
        "boom", status=500
    )
    nf = NavFlow(api_key="nf_x", endpoint=httpserver.url_for(""))
    with pytest.raises(requests.HTTPError):
        nf.send_output(payload={})


def test_send_output_raises_on_401(httpserver: HTTPServer):
    """401 from invalid API key raises HTTPError."""
    httpserver.expect_request("/v1/agent-outputs").respond_with_data(
        '{"error":"invalid api key"}', status=401
    )
    nf = NavFlow(api_key="nf_bad", endpoint=httpserver.url_for(""))
    with pytest.raises(requests.HTTPError):
        nf.send_output(payload={"a": 1})


def test_endpoint_trailing_slash_stripped():
    """Endpoint URL is normalized (no trailing slash)."""
    nf = NavFlow(api_key="nf_x", endpoint="https://example.com/")
    assert nf.endpoint == "https://example.com"


def test_empty_api_key_raises():
    with pytest.raises(ValueError):
        NavFlow(api_key="")


def test_context_manager_closes_session(httpserver: HTTPServer):
    """Using NavFlow as a context manager closes the underlying session."""
    httpserver.expect_request("/v1/agent-outputs").respond_with_json(
        {"status": "ok"}
    )
    with NavFlow(api_key="nf_x", endpoint=httpserver.url_for("")) as nf:
        nf.send_output(payload={"a": 1})
    # session.close() is idempotent — verifying no exception
    nf.close()


def test_glassflow_alias_is_navflow():
    """Backwards-compat alias still works."""
    from navflow_ai import GlassFlow

    assert GlassFlow is NavFlow
