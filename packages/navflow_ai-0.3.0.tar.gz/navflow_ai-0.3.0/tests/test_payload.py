"""Tests for the payload-parsing layer."""

import json

import pytest

from navflow_ai.payload import AgentPayload, Context, Metadata


# A representative payload covering all optional fields. Mirrors the wire
# shape produced by navflow-core/internal/pipeline/service.go.
FULL_PAYLOAD = {
    "trigger": {
        "action": "opened",
        "pull_request": {"number": 42, "title": "Fix login bug"},
    },
    "pending_triggers": [
        {
            "data": {"action": "synchronize", "pull_request": {"number": 42}},
            "timestamp": "2026-04-14T10:32:15.123456Z",
        }
    ],
    "context": {
        "key": "repo:acme/backend",
        "events": [
            {
                "data": {"action": "opened", "pull_request": {"number": 41}},
                "timestamp": "2026-04-14T10:10:00Z",
            },
            {
                "data": {"action": "closed", "pull_request": {"number": 41}},
                "timestamp": "2026-04-14T10:20:00Z",
            },
        ],
        "stats": {
            "count": 2,
            "duration_ms": 600000,
            "first_at": "2026-04-14T10:10:00Z",
            "last_at": "2026-04-14T10:20:00Z",
        },
    },
    "_metadata": {
        "request_id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
        "project_id": "proj-abc",
        "triggered_at": "2026-04-14T10:35:22Z",
        "context_events": 2,
        "pending_triggers": 1,
        "group_key": "repo:acme/backend",
    },
}


# Trigger-only payload — what your agent gets when context windows are off
# and there's no debounce queue.
MINIMAL_PAYLOAD = {
    "trigger": {"action": "opened", "pull_request": {"number": 42}},
    "_metadata": {
        "request_id": "req-1",
        "project_id": "proj-1",
        "triggered_at": "2026-04-14T10:00:00Z",
        "context_events": 0,
        "pending_triggers": 0,
        "group_key": "default",
    },
}


def test_from_dict_full():
    payload = AgentPayload.from_dict(FULL_PAYLOAD)

    assert payload.trigger["action"] == "opened"
    assert payload.trigger["pull_request"]["number"] == 42

    assert len(payload.pending_triggers) == 1
    assert payload.pending_triggers[0].data["action"] == "synchronize"

    assert isinstance(payload.context, Context)
    assert payload.context.key == "repo:acme/backend"
    assert len(payload.context.events) == 2
    assert payload.context.stats.count == 2
    assert payload.context.stats.duration_ms == 600000

    assert isinstance(payload.metadata, Metadata)
    assert payload.metadata.request_id == "f47ac10b-58cc-4372-a567-0e02b2c3d479"
    assert payload.metadata.group_key == "repo:acme/backend"


def test_from_dict_minimal_no_context():
    """Trigger-only payloads parse cleanly with context=None."""
    payload = AgentPayload.from_dict(MINIMAL_PAYLOAD)

    assert payload.trigger["pull_request"]["number"] == 42
    assert payload.pending_triggers == []
    assert payload.context is None
    assert payload.metadata.request_id == "req-1"
    assert payload.metadata.context_events == 0


def test_from_bytes():
    """Raw bytes (e.g. from request.body()) parse the same as dict."""
    raw = json.dumps(FULL_PAYLOAD).encode("utf-8")
    payload = AgentPayload.from_bytes(raw)
    assert payload.trigger == FULL_PAYLOAD["trigger"]
    assert payload.metadata.request_id == FULL_PAYLOAD["_metadata"]["request_id"]


def test_from_bytes_str():
    """Raw str works too."""
    raw = json.dumps(MINIMAL_PAYLOAD)
    payload = AgentPayload.from_bytes(raw)
    assert payload.trigger == MINIMAL_PAYLOAD["trigger"]


def test_extra_fields_preserved():
    """Server-added fields don't break parsing — they're kept on model_extra."""
    body = dict(MINIMAL_PAYLOAD)
    body["future_field"] = "some-value"
    payload = AgentPayload.from_dict(body)
    assert payload.model_extra and payload.model_extra.get("future_field") == "some-value"


def test_metadata_extra_fields_preserved():
    """Same for metadata: extras don't drop."""
    body = json.loads(json.dumps(MINIMAL_PAYLOAD))
    body["_metadata"]["future_field"] = "x"
    payload = AgentPayload.from_dict(body)
    assert payload.metadata.model_extra and payload.metadata.model_extra.get("future_field") == "x"


def test_missing_metadata_raises():
    """_metadata is required by the wire contract."""
    body = {"trigger": {"x": 1}}
    with pytest.raises(Exception):  # noqa: B017 — pydantic ValidationError
        AgentPayload.from_dict(body)


def test_iterating_window_events():
    """Common usage: walk the window events."""
    payload = AgentPayload.from_dict(FULL_PAYLOAD)
    assert payload.context is not None
    actions = [e.data["action"] for e in payload.context.events]
    assert actions == ["opened", "closed"]


def test_pending_triggers_default_empty():
    """Missing pending_triggers field defaults to empty list."""
    body = json.loads(json.dumps(MINIMAL_PAYLOAD))
    body.pop("pending_triggers", None)  # not present
    payload = AgentPayload.from_dict(body)
    assert payload.pending_triggers == []
