"""Components comprising Interchange objects."""
