"""Export to Amber files."""
