"""Interfaces with GROMACS."""
