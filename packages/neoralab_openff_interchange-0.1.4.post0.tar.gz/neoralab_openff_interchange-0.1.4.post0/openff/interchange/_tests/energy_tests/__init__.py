"""Energy tests."""
