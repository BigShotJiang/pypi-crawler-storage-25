"""Tests of LAMMPS exporter."""
