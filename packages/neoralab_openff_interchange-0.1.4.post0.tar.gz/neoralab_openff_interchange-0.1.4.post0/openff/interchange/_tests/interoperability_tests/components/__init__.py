"""Interoperability tests with components."""
