# Mac App Store Sandbox & iPhone Communication Research

## Executive Summary

A sandboxed Mac App Store app **cannot feasibly** communicate with an iPhone to read/write SpringBoard icon state using any currently approved mechanism. The fundamental blocker is that all paths to the `com.apple.springboardservices` lockdown service require either (a) access to the `/var/run/usbmuxd` Unix socket, (b) Mach service lookups to `com.apple.usbmuxd`, or (c) creating raw network tunnels -- all of which the App Sandbox blocks, and none of which Apple has approved temporary exceptions for in third-party Mac App Store apps.

**Recommendation:** Distribute via Developer ID + notarization (direct distribution), exactly as iMazing, AnyTrans, and every other iPhone management tool does. The Mac App Store path is a dead end for this category of application.

However, there is one speculative future path worth monitoring: the iOS 17+ RemoteXPC tunnel architecture, which converts device communication to standard TCP/IPv6 networking. If Apple's `tunneld` daemon exposes tunnel services in a way accessible to sandboxed apps with `com.apple.security.network.client`, this could eventually open a path. Details below.

---

## 1. SMAppService / SMJobBless Privileged Helper Tools

### Background

- **SMJobBless** (legacy): Installs a privileged helper tool that runs as root. Cannot be used from a sandboxed app. Requires Authorization Services for installation. Deprecated in favor of SMAppService.
- **SMAppService** (macOS 13+): Modern replacement. Registers Launch Daemons, Launch Agents, and Login Items via a clean API. User approval happens in System Settings rather than via a password prompt.

### Can a Sandboxed Mac App Store App Use This?

**Partially, but with critical limitations:**

1. **Sandboxed app + daemon = sandboxed daemon.** As of macOS 14.2, if the main application is sandboxed, the daemon it registers via SMAppService **must also be sandboxed**. There is no mixed-mode: you cannot run an unsandboxed daemon from a sandboxed app. The daemon and app must both be sandboxed, and they must share an App Group for XPC communication.

2. **A sandboxed daemon cannot access usbmuxd.** The daemon inherits the same sandbox restrictions. It cannot connect to `/var/run/usbmuxd` (Unix socket) or perform Mach lookups to `com.apple.usbmuxd` without temporary exception entitlements.

3. **Temporary exception entitlements for Mach lookups.** The `com.apple.security.temporary-exception.mach-lookup.global-name` entitlement could theoretically grant access to `com.apple.usbmuxd`. However:
   - Apple requires justification filed via Feedback Assistant
   - App Review must approve it
   - Apple has **never** approved this for usbmuxd access in a third-party App Store app
   - Apple Configurator 2 (Apple's own app) uses `com.apple.configurator.launchagent.DeviceService` and `com.apple.configurator.launchagent.AirTrafficService` -- custom Apple-internal Mach services, not direct usbmuxd access

4. **App Review stance.** Apple's general posture is that temporary exception entitlements are "temporary" -- the expectation is that you migrate to a supported API. There is no supported API for iOS device management from the sandbox.

### Feasibility: NOT VIABLE for Mac App Store

The SMAppService path does not solve the fundamental problem: even the privileged helper would be sandboxed and unable to reach usbmuxd.

### Sources
- [macOS Apps With Embedded Daemons](https://dev.to/brysontyrrell/macos-apps-with-embedded-daemons-333a)
- [SMAppService API Notes](https://theevilbit.github.io/posts/smappservice/)
- [SMAppService.daemon as root](https://developer.apple.com/forums/thread/751439)
- [XPC between sandboxed application and launchd daemon](https://developer.apple.com/forums/thread/99602)
- [Struggling with SMJobBless in a sandboxed app](https://developer.apple.com/forums/thread/707026?page=2)

---

## 2. CoreDevice Framework (macOS 14+)

### What CoreDevice Is

Starting with macOS 14 (Sonoma) and iOS 17, Apple introduced the CoreDevice framework as a public replacement for the private MobileDevice.framework. It fundamentally changes how macOS communicates with iOS devices:

- **Old model (iOS <= 16):** usbmuxd multiplexes TCP connections over USB. Lockdown services connect via usbmuxd Unix socket. Communication is TCP+TLS.
- **New model (iOS 17+):** Ethernet-over-USB creates an IPv6 network interface. A QUIC or TCP tunnel (TLS-PSK) is established through `tunneld`/`remoted` daemons. Services are discovered via RemoteXPC over HTTP/2. Approximately 90+ services are exposed.

### Does It Expose SpringBoard Services?

**Yes, but indirectly.** The traditional `com.apple.springboardservices` lockdown service has a remote variant: `com.apple.springboardservices.shim.remote`, which operates over the RemoteXPC tunnel. This means the service is accessible through the new tunnel infrastructure, not just the legacy usbmuxd path.

### Can Sandboxed Apps Use CoreDevice?

**No public API exists for third-party use.** Apple provides `devicectl` as a command-line utility, but:

- CoreDevice is used internally by Xcode, Instruments, and Apple Configurator
- There is no public Swift/ObjC framework API documented for third-party apps
- The `com.apple.private.CoreDevice.canDebugApplicationsOnDevice` entitlement (visible in service properties) is a private entitlement
- `devicectl` does not expose springboard services -- it focuses on developer workflows (app install, debug, process management)

### The Tunnel Opportunity

The architectural shift to TCP/IPv6 tunnels is significant because:

1. Once a tunnel is established by `tunneld` (which Xcode triggers), the iOS device's services are accessible via standard TCP on a localhost IPv6 address
2. A sandboxed app with `com.apple.security.network.client` (outgoing network connections) could **theoretically** connect to these TCP ports if it knew the addresses
3. The tunnel creates actual `utun` network interfaces visible to the system

**However**, the tunnel establishment itself requires:
- Pairing (which goes through `remotepairingd`, likely requiring private entitlements)
- QUIC/TLS-PSK negotiation
- Root-level TUN device creation

A sandboxed app cannot establish the tunnel itself. It could only piggyback on a tunnel already established by Xcode or `tunneld`.

### Feasibility: NOT CURRENTLY VIABLE, but worth monitoring

If Apple ever exposes a public CoreDevice API or allows third-party apps to request tunnel access, this becomes the cleanest path. For now, there is no documented way to use it from a sandboxed third-party app.

### Sources
- [Frida 16.3.0 - CoreDevice support](https://frida.re/news/2024/05/31/frida-16-3-0-released/)
- [pymobiledevice3 RemoteXPC documentation](https://github.com/doronz88/pymobiledevice3/blob/master/misc/RemoteXPC.md)
- [Hex-Rays: Debugging iOS via CoreDevice](https://docs.hex-rays.com/user-guide/debugger/debugger-tutorials/ios_debugging_coredevice)
- [Meet CoreDevice and devicectl](https://speakerdeck.com/scenee/meet-coredevice-and-devicectl)
- [NowSecure: The Road to Frida iOS 17 Support](https://www.nowsecure.com/blog/2024/08/14/the-road-to-frida-ios-17-support-and-beyond/)

---

## 3. pymobiledevice3 Tunnel Transport for iOS 17+

### How the Tunnel Works

pymobiledevice3 reimplements Apple's tunnel infrastructure in pure Python:

1. **Device discovery:** mDNS locates the IPv6 address of the RemoteServiceDiscovery (RSD) service on the iOS device
2. **Pairing:** SRP key exchange via `remotepairingd` protocol (similar to HomeKit pairing)
3. **Tunnel creation:** QUIC (UDP, MTU 1420) or TCP (TLS-PSK, MTU 16000) tunnel established
4. **Virtual network:** TUN/TAP device created for routing IPv6 packets
5. **Service access:** All lockdown services accessible through the tunnel, including `com.apple.springboardservices`

Key improvement in iOS 17.4: A new lockdown service allows establishing trusted tunnels over an existing lockdown connection (no separate pairing needed). This uses TCP tunnels, which are significantly faster.

### Could a Sandboxed App Use the Network-Based Path?

**In theory, partially. In practice, no.**

The argument for:
- The tunnel converts all device communication to standard TCP/IPv6 networking
- A sandboxed app with `com.apple.security.network.client` can make outgoing TCP connections
- If the tunnel is already established (by another process), the sandboxed app could connect to the IPv6 address + port

The problems:
1. **Tunnel creation requires root privileges.** Creating TUN/TAP devices, binding to low-level network interfaces, and the QUIC/TLS-PSK negotiation all require capabilities a sandboxed app does not have.
2. **Service port discovery.** The available service ports are communicated during tunnel handshake and written to system logs. A sandboxed app has no standard way to discover them.
3. **The pairing flow requires usbmuxd access.** Even the initial pairing (which must happen at least once) goes through usbmuxd on pre-17.4 devices.
4. **An external tunnel daemon would need to run unsandboxed.** You are back to the SMAppService problem.

### Hybrid Architecture (Speculative)

One could imagine:
1. A non-sandboxed helper tool (distributed separately, or via SMAppService outside the App Store) establishes the tunnel
2. The helper advertises tunnel endpoints via a local TCP server or shared App Group container
3. The sandboxed main app connects to the tunnel's TCP endpoints

This is architecturally valid but defeats the purpose of Mac App Store distribution -- the helper tool is the thing that needs to be outside the sandbox.

### Feasibility: NOT VIABLE for a pure Mac App Store app

The tunnel approach is excellent for non-sandboxed apps (and is how pymobiledevice3 works), but the tunnel establishment cannot happen inside a sandbox.

### Sources
- [pymobiledevice3 GitHub](https://github.com/doronz88/pymobiledevice3)
- [pymobiledevice3 RemoteXPC documentation](https://github.com/doronz88/pymobiledevice3/blob/master/misc/RemoteXPC.md)
- [pymobiledevice3 protocol layers](https://github.com/doronz88/pymobiledevice3/blob/master/misc/understanding_idevice_protocol_layers.md)
- [pymobiledevice3 SpringBoard services](https://deepwiki.com/doronz88/pymobiledevice3/5.4-springboard-and-ui-services)
- [go-ios: communicate without usbmux?](https://github.com/danielpaulus/go-ios/issues/392)

---

## 4. com.apple.security.device.usb Entitlement

### What It Grants

The `com.apple.security.device.usb` entitlement is a Boolean value that grants a sandboxed app permission to interact with USB devices via IOKit USB APIs (IOUSBDeviceInterface, IOUSBInterfaceInterface, etc.).

### What It Does NOT Grant

- **It does NOT grant access to usbmuxd.** usbmuxd is a Mach service / Unix domain socket, not a USB device. The USB entitlement controls access to raw USB hardware via IOKit, not to Apple's multiplexing daemon.
- **It does NOT grant access to MobileDevice.framework.** MobileDevice.framework communicates with usbmuxd, not directly with USB hardware.
- **It does NOT help with iOS device communication.** The iPhone, as seen by macOS over USB, is not a generic USB device that you'd interact with via IOKit. Apple's own software (usbmuxd) handles the USB-level protocol.

### What It IS For

- Hardware security keys (FIDO2/WebAuthn)
- USB MIDI controllers
- Custom USB hardware (lab equipment, industrial controllers)
- USB serial adapters

### Feasibility: IRRELEVANT to this use case

This entitlement operates at the wrong layer. iOS device communication goes through usbmuxd, not raw USB access.

### Sources
- [com.apple.security.device.usb documentation](https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.security.device.usb)
- [App Sandbox USB device entitlement forum](https://developer.apple.com/forums/thread/65780)
- [Entitlements for app accessing USB](https://forums.developer.apple.com/forums/thread/732995)

---

## 5. How iMazing, AnyTrans, and Similar Tools Handle This

### Key Finding: None Are on the Mac App Store

No iPhone management tool that communicates with iOS lockdown services has ever been distributed through the Mac App Store. Every single one uses direct distribution:

| Tool | Distribution | Approach |
|------|-------------|----------|
| **iMazing** | Direct (Developer ID + notarization) | Uses MobileDevice.framework / libimobiledevice. Code-signed, notarized by Apple. Distributed via imazing.com |
| **AnyTrans** | Direct (Developer ID + notarization) | Similar approach. Primarily USB-based. Distributed via imobie.com |
| **iExplorer** | Direct | Uses MobileDevice.framework |
| **3uTools** | Direct (Windows only) | Uses iTunes/MobileDevice COM interfaces |
| **Apple Configurator 2** | Mac App Store | **Apple's own app** -- uses private entitlements unavailable to third parties |

### Why They Cannot Be on the Mac App Store

1. **Sandbox blocks usbmuxd access.** All these tools communicate via `/var/run/usbmuxd` (Unix socket) or the `com.apple.usbmuxd` Mach service. The sandbox blocks both.
2. **MobileDevice.framework is private.** Apple's framework for iOS device communication is not a public API. Using it would violate App Review guidelines.
3. **No alternative public API exists.** Apple has not provided a sandboxed-compatible API for third-party iOS device management.

### iMazing's Specific Approach

iMazing is "code-signed with an official Apple Developer ID certificate" and each version is "submitted to Apple's servers, where Apple scans it for malware, and if it passes, Apple notarizes it." This means:
- It meets Apple's security requirements
- macOS allows it to run without Gatekeeper warnings
- It simply does not use the sandbox, because it does not need to

### Sources
- [iMazing FAQ](https://imazing.com/faq)
- [Is iMazing approved by Apple?](https://imazing.org/2025/10/01/is-imazing-approved-by-apple/)
- [iMazing vs AnyTrans comparison](https://thesweetbits.com/imazing-vs-anytrans/)
- [Distributing Mac apps outside the App Store](https://www.rambo.codes/posts/2021-01-08-distributing-mac-apps-outside-the-app-store)

---

## 6. Apple Configurator 2 Entitlements

### Actual Entitlements (Dumped via codesign)

Apple Configurator 2 is the **only** iPhone management tool on the Mac App Store, and it achieves this by using **private Apple-only entitlements**:

**Sandbox: YES** -- `com.apple.security.app-sandbox` is true.

**Key private entitlements:**
- `com.apple.private.accounts.allaccounts` -- Full account access
- `com.apple.private.applemediaservices` -- Apple media services access
- `com.apple.private.aps-connection-initiate` -- Push notification connection
- `com.apple.private.commerce` -- App Store commerce
- `com.apple.private.security.restricted-application-groups` -- Restricted app groups
- `com.apple.private.security.storage.mobilesync` -- **MobileSync storage access** (this is how it accesses backup/sync data)
- `com.apple.private.tcc.allow-prompting` -- TCC prompting

**Custom Mach service lookups (temporary exceptions):**
- `com.apple.configurator.launchagent.DeviceService` -- Custom Apple agent for device communication
- `com.apple.configurator.launchagent.AirTrafficService` -- Custom Apple agent for content transfer
- `com.apple.configurator.launchagent.InternetService` -- Custom Apple agent for internet operations
- Plus multiple App Store-related Mach services

**Custom sandbox profile extensions (SBPL):**
- `(allow authorization-right-obtain (right-name "com.apple.ServiceManagement.daemons.modify"))` -- Can modify daemons
- `(allow default job-creation)` -- Can create launchd jobs
- MobileSync backup path access: `~/Library/Application Support/MobileSync/Backup/`
- Various App Store and commerce-related sandbox extensions

### Can Third Parties Request These?

**No.** Every entitlement prefixed with `com.apple.private.*` is restricted to Apple's own signing identity. Third-party Developer ID certificates and App Store provisioning profiles cannot include these entitlements. Apple's code signing infrastructure will reject them.

The `com.apple.configurator.launchagent.*` Mach services are custom launch agents that Apple ships as part of the Configurator installation. They run outside the sandbox and handle the actual device communication. A third party cannot register services in the `com.apple.` namespace.

### What This Tells Us

Apple Configurator 2 proves that even Apple cannot do this within the standard sandbox. They needed:
1. Private entitlements for storage access
2. Custom launch agents (outside the sandbox) for device communication
3. Custom sandbox profile extensions (SBPL) for additional capabilities
4. The `com.apple.private.*` entitlement namespace that is restricted to Apple

**This is the strongest evidence that the Mac App Store path is not viable for third parties.**

### Sources
- Entitlements dumped directly from `/Applications/Apple Configurator 2.app` via `codesign -d --entitlements :-`

---

## 7. Network Extension / System Extension / DriverKit Approach

### DriverKit (USBDriverKit)

**What it is:** DriverKit allows creation of user-space USB device drivers. USBDriverKit specifically targets USB peripherals.

**Why it does not help:**
- DriverKit is for creating **drivers** for USB hardware (HID devices, serial adapters, custom hardware)
- An iPhone connected via USB is not a generic USB device to be driven by a third-party driver
- Apple's own `AppleMobileDevice.kext` and `usbmuxd` handle the iPhone USB protocol
- You would need to reimplement the entire iPhone USB protocol stack (proprietary Apple protocol) at the USB descriptor level
- Even if you could, this would conflict with Apple's own drivers
- DriverKit entitlements require Apple approval for distribution, and Apple would not approve a driver that reimplements their iPhone USB protocol

### NetworkExtension

**What it is:** Framework for creating VPN clients, content filters, DNS proxies, and WiFi hotspot helpers.

**Why it does not help:**
- NetworkExtension operates at the IP packet level (layer 3) or DNS level
- It cannot intercept or create USB communication channels
- It could theoretically be used to create a local VPN that routes to an iOS device's tunnel interface, but:
  - The tunnel must already be established (same problem as #3)
  - You would need to know the tunnel endpoints
  - App Review would question why an iPhone layout app needs a network extension

### System Extension

**What it is:** Generic container for DriverKit drivers, network extensions, and endpoint security extensions.

**Why it does not help:**
- Same limitations as the specific extension types above
- Requires Apple-approved entitlements for distribution
- App Review would reject an endpoint security extension for a home screen layout tool

### Feasibility: NOT VIABLE

None of the extension frameworks operate at the right layer. iPhone communication happens through usbmuxd (Mach service + Unix socket), not through raw USB or IP networking.

### Sources
- [System Extensions and DriverKit](https://developer.apple.com/system-extensions/)
- [USBDriverKit documentation](https://developer.apple.com/documentation/usbdriverkit)
- [Demystify code signing for DriverKit](https://developer.apple.com/news/?id=c63qcok4)
- [DriverKit architecture for USB-C device](https://developer.apple.com/forums/thread/747490)

---

## Overall Feasibility Matrix

| Approach | Mac App Store? | Technical Feasibility | App Review Risk | Verdict |
|----------|---------------|----------------------|-----------------|---------|
| SMAppService daemon | No | Daemon must be sandboxed too | Would be rejected | **Dead end** |
| CoreDevice public API | No (doesn't exist yet) | No public API | N/A | **Future possibility** |
| RemoteXPC tunnel (network) | No | Tunnel creation requires root | N/A | **Dead end for sandbox** |
| com.apple.security.device.usb | No | Wrong layer entirely | N/A | **Irrelevant** |
| Mach lookup temp exception for usbmuxd | Theoretically possible, practically no | Works technically | Almost certain rejection | **Extremely unlikely** |
| File access temp exception for /var/run/usbmuxd | Theoretically possible, practically no | Works technically | Almost certain rejection | **Extremely unlikely** |
| DriverKit USB driver | No | Would need to reimplement Apple's protocol | Would be rejected | **Dead end** |
| NetworkExtension | No | Wrong layer | Would be questioned | **Dead end** |
| Piggyback on Xcode's tunnel | Fragile, requires Xcode | Partially works | N/A for App Store | **Not a product** |

---

## Recommended Path Forward

### Primary: Direct Distribution (Developer ID + Notarization)

This is the proven path used by every iPhone management tool:

1. **No sandbox restrictions** -- Full access to usbmuxd, MobileDevice.framework, libimobiledevice
2. **Apple-approved security** -- Code signing + notarization provides Gatekeeper trust
3. **Sparkle for updates** -- Standard macOS update framework
4. **Proven model** -- iMazing, AnyTrans, and dozens of others use this approach
5. **No App Review for functionality** -- Only notarization (malware scan)

### Secondary: Monitor CoreDevice Public API

Watch WWDC each year for:
- Public CoreDevice framework APIs
- New sandboxing entitlements for device communication
- Changes to `devicectl` capabilities
- Any signals that Apple is opening up iOS device management APIs

### Tertiary: Hybrid Approach (Future)

If Mac App Store presence becomes critical:
1. Mac App Store app handles UI/UX only
2. Separate "Helper Tool" installer (direct distribution) handles device communication
3. Communication between them via local network (localhost TCP)
4. This splits the user experience but allows App Store visibility

This is similar to how some apps handle tasks requiring elevated privileges, but it creates a poor user experience and requires two separate installations.

---

## Key Takeaway

The Mac App Store sandbox is fundamentally incompatible with iOS device management. This is not a technical oversight -- it appears to be a deliberate architectural decision by Apple. Apple Configurator 2 itself requires private entitlements that are unavailable to third parties. Direct distribution with Developer ID + notarization is the correct and only viable approach.
