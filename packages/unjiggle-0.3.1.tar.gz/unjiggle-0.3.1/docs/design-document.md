# Unjiggle — Design Document

*A Mac app for reorganizing iPhone home screens with intelligence.*

## The Problem (in one sentence)

Rearranging apps on an iPhone is so tedious that people avoid doing it entirely — and no good tool exists to fix this, despite 1.46 billion iPhones in the world.

## Why Now

Three forces converge:

1. **iOS 18 made home screens more complex.** Free icon placement, tinted icons, large icons, widgets in more sizes — more customization options means more to organize, and more reasons you'd want a Mac's precision instead of fat-fingering it on a phone.

2. **Apple explicitly rejected building this.** Craig Federighi killed an AI home screen proposal in January 2026, saying it would "disorient users." Apple's philosophy is anti-dynamic-rearrangement. A manual tool with smart *suggestions* doesn't conflict with Apple's stated position — it complements it.

3. **Every past attempt abandoned the feature as a side project.** AnyTrans, iCareFone, and Apple themselves (iTunes 12.7) all tried and quit. But they all buried it as a minor feature inside a general-purpose tool. Nobody has built a **purpose-built** app for this with modern UX and intelligent algorithms.

---

## Technical Foundation (The Make-or-Break)

### Primary Path: SpringBoard Services over USB

The `com.apple.springboardservices` lockdown service exposes direct APIs:

| API | Purpose |
|-----|---------|
| `get_icon_state()` | Read entire home screen layout |
| `set_icon_state()` | **Write** a new layout to the device |
| `get_icon_pngdata(bundleId)` | Get any app's icon as PNG |
| `get_homescreen_icon_metrics()` | Grid dimensions per device model |
| `get_wallpaper_pngdata()` | Get current wallpaper |

**No jailbreak. No supervision. No exploit.** Just USB trust pairing. Two mature open-source libraries implement this: **libimobiledevice** (C, 15+ years) and **pymobiledevice3** (Python, actively maintained, 9.7k GitHub stars, iOS 17/18 support).

**sbmanager** — an abandoned GTK app in the libimobiledevice org — was literally a working GUI for this exact product concept. Proof it once worked end-to-end.

### Critical Unknown

**Does `set_icon_state()` still work on iOS 17/18?** The read path is confirmed. The write path needs hands-on validation. Before writing a single line of product code:

```bash
pip3 install pymobiledevice3
pymobiledevice3 springboard get-icon-state > layout.json
# swap two app positions in layout.json
pymobiledevice3 springboard set-icon-state < layout.json
```

If the write succeeds: **green light.** If silently ignored: fall back to backup manipulation (modify `IconState.plist` in a backup, partial restore via `mobilebackup2` service).

### Data Format

`IconState.plist` — binary plist at `/private/var/mobile/Library/SpringBoard/IconState.plist`:

- `buttonBar`: dock contents (array of bundle IDs)
- `iconLists`: array of arrays — each inner array is one page, items ordered left-to-right, top-to-bottom
- Apps: string bundle IDs (`com.apple.Maps`)
- Folders: dicts with `displayName`, nested `iconLists`, `listType: "folder"`
- Widgets: dicts with `elementType: "widget"`, `containerBundleIdentifier`, `gridSize` (small/medium/extraLarge)
- `ignored`: apps in App Library but NOT on home screen

### Distribution — Dual Strategy

**Both Mac App Store and direct download.** USB device communication requires usbmuxd access, which the Mac App Store sandbox blocks (confirmed: no viable workaround — SMAppService helpers must also be sandboxed on macOS 14.2+, CoreDevice framework is internal-only, and `com.apple.security.device.usb` grants IOKit access not usbmuxd). Even Apple Configurator uses private entitlements unavailable to third parties.

**The solution: two editions with different capabilities.**

| | Mac App Store Edition (Free/Lite) | Direct Download Edition (Pro) |
|---|---|---|
| **How it gets layout data** | User selects Finder backup via `NSOpenPanel` (sandbox-safe) | Live USB via libimobiledevice/usbmuxd |
| **Read layout** | Yes (from backup `IconState.plist`) | Yes (real-time, 2-3 seconds) |
| **Visualize & score** | Yes | Yes |
| **AI suggestions** | Yes | Yes |
| **Drag-and-drop editor** | Yes | Yes |
| **Apply to iPhone** | Export modified backup → user restores via Finder | One-click apply via `set_icon_state()` |
| **Named snapshots** | Yes (file-based) | Yes (file + live device) |
| **Live wallpaper/icons** | No (uses backup data or generic placeholders) | Yes (fetched from device in real-time) |
| **Signing** | App Store distribution certificate | Developer ID + notarization |
| **Updates** | App Store auto-update | Sparkle framework |
| **Payments** | App Store (30%/15% cut) | Paddle or LemonSqueezy (5-10% cut) |

**Strategic rationale**: The App Store edition is a **top-of-funnel acquisition tool**. Users discover it via App Store search, see their messy home screen visualized with an organization score, get hooked on the suggestions, then upgrade to the direct download edition for the seamless one-click USB experience. This is the Transmit/BBEdit model — App Store for discovery, direct for power features.

The backup-based approach isn't just a compromise — seeing your layout from a backup *before* trusting a USB tool reduces "is this safe?" friction and validates the product value proposition with zero risk perception.

---

## The Algorithm — Planogram for Your Phone

Retail planogram optimization is the closest solved problem: items with varying demand, positions with varying value, adjacency preferences, capacity constraints.

### Phase 1: Multi-Signal Feature Extraction

For each app, compute a feature vector:

| Signal | Source | Weight |
|--------|--------|--------|
| Launch frequency (7d, 30d) | User-provided Screen Time screenshot (OCR) | High |
| Frecency score | Frequency x recency decay | High |
| Time-of-day usage pattern | Screen Time data or user self-report | Medium |
| App Store category | Bundle ID -> App Store lookup | Medium |
| Co-usage (apps opened in same session) | User self-report or inference | Low |
| Name/description embedding | Sentence-BERT on app name | Low |

### Phase 2: HDBSCAN Clustering

- No need to pre-specify number of groups (K)
- Naturally identifies "noise" apps that don't fit any cluster -> goes to misc page or App Library
- Produces hierarchical clusters that map to pages > folders
- User can name/rename/split/merge groups after auto-suggestion

### Phase 3: Page Allocation (Bin Packing)

- Sort clusters by total frecency score
- Highest-frecency cluster -> Page 1
- First Fit Decreasing to pack clusters into pages of 24 slots
- Dock: top 4 apps by frecency, regardless of cluster

### Phase 4: Within-Page Layout (Thumb-Zone Optimization)

A reachability heat map weights each grid position by thumb accessibility (Bergstrom-Lehtovirta & Oulasvirta, CHI 2014):

```
Grid position value (right-handed, 6x4 grid):
  [ 2  3  3  2 ]   <- hardest to reach
  [ 3  5  5  3 ]
  [ 5  7  7  5 ]
  [ 7  9  9  7 ]
  [ 8 10 10  8 ]
  [ 9 10 10  9 ]   <- easiest (thumb arc)
```

Hungarian algorithm assigns highest-frecency apps to highest-value positions. O(n^3) per page, trivial for n=24.

### Phase 5: Stability Penalty

The single most important algorithmic insight: Oulasvirta et al. (2012) showed spatial memory is the primary way users find apps. Moving everything destroys muscle memory.

```
total_cost = layout_cost + lambda * displacement_cost
```

Where lambda starts high (conservative, minimal changes) and the user can slide toward "full reorganize." Default suggestions should move as few apps as possible to achieve the biggest improvement.

### The Semi-Automatic Principle

Every analogous domain (Fences, Hazel, Gmail categories) confirms: **users want to define the groups; the system handles sorting within groups.** The algorithm proposes; the user disposes. Never auto-apply.

---

## UX Vision

### The 60-Second Magic Moment

**Pro edition (USB):**
1. **Connect iPhone** via USB cable -> "Trust this computer" tap
2. **Auto-scan** (2-3 seconds) -> all pages rendered on Mac canvas for the first time
3. **Instant insight**: "You have 147 apps across 7 pages. Your most-used app (Instagram) is buried on page 4."
4. **One-click suggestion**: "Move your top 10 apps to page 1?" with before/after preview
5. **The reveal**: slider comparison — drag to see Before <-> After

**App Store edition (backup):**
1. **Open backup** -> file picker pointed at `~/Library/Application Support/MobileSync/Backup/`
2. **Auto-detect** latest backup -> identify device name and date -> parse layout
3. **Same instant insight** and suggestion flow as Pro
4. **After editing**: "To apply, restore this backup via Finder" walkthrough + **"Want one-click apply? Get Unjiggle Pro"** upsell

The goal: deliver a dopamine hit before the user learns any features. The App Store edition delivers the same "wow" moment — the only difference is the final apply step.

### Canvas Interaction (Figma Model)

Three zoom tiers on an infinite, pannable canvas:

| Zoom Level | What You See | Primary Action |
|------------|-------------|----------------|
| **Overview** | All pages as thumbnails (4-8 visible) | Reorder entire pages, see full layout at a glance |
| **Page** | 1-2 pages fill the screen | Drag apps between adjacent pages, arrange within page |
| **Detail** | Single page, enlarged, with metadata | Fine-tune positions, edit folders, configure widgets |

Multi-select via rubber-band lasso, Cmd+click toggle, Shift+click range. This is the Mac's killer advantage over on-device jiggle mode.

### Window Layout

```
+----------------------------------------------------------+
| Toolbar: [Zoom controls] [View mode] [Score: 72] [Apply] |
+----------+---------------------------------------+-------+
|          |                                       |       |
| Sidebar  |           Main Canvas                 | Insp. |
|          |                                       | Panel |
| - Pages  |    [Page 1]  [Page 2]  [Page 3]      |       |
|   - P1   |    +------+  +------+  +------+      | App   |
|   - P2   |    | grid |  | grid |  | grid |      | Info  |
|   - P3   |    |      |  |      |  |      |      |       |
| - Dock   |    +------+  +------+  +------+      | Usage |
| - Library|                                       | Stats |
| - Folders|                                       |       |
| - Suggest|           [Dock: 4 slots]             |       |
|          |                                       |       |
+----------+---------------------------------------+-------+
```

### The Emotional Centerpiece: Before/After

A slider-based split view with summary statistics and organization score:

- Score: 0-100 with labels ("Cluttered" -> "Getting There" -> "Well Organized" -> "Perfectly Tuned")
- Weighted: Accessibility (40%), Coherence (30%), Efficiency (20%), Simplicity (10%)
- Framed as opportunity: "You could save 12 swipes per day" not "Your layout is inefficient"

### Trust Architecture

1. **Never touch the phone without explicit confirmation.** All edits are local until "Apply."
2. **Auto-backup before every sync.** Restore anytime.
3. **Named snapshots.** Save layouts: "Before reorganizing," "Work mode," "Weekend mode."
4. **Conservative defaults.** First suggestion moves minimum apps for maximum improvement.
5. **Transparent about limitations.** Widgets can be moved but not created. System apps can't be removed.

### Visual Design

Aesthetic: Things 3 / Bear — calm, clean, minimal chrome, subtle spring animations. Not playful, not enterprise.

- Follow system appearance (light/dark)
- Stylized device frame (rounded rect + shadow), not photorealistic mockup
- Muted category color coding as optional overlay (Notion-style pastels)
- Spring animations on app pickup (1.15x scale + shadow) and drop (slight overshoot bounce)
- Haptic feedback on Force Touch trackpads when apps snap to grid

---

## Architecture

```
+------------------------------------------------------+
|           Unjiggle.app (Swift/SwiftUI)                |
|                                                        |
|  +---------+  +----------+  +----------+              |
|  | Canvas  |  |Algorithm |  | Themes   |              |
|  | Engine  |  | Engine   |  | Store    |              |
|  |(SwiftUI)|  |(HDBSCAN, |  |          |              |
|  |         |  | Hungarian|  |          |              |
|  +----+----+  +----+-----+  +----------+              |
|       |            |                                   |
|  +----+------------+-----+                            |
|  |   Layout Data Layer    |  <-- Protocol abstraction  |
|  +-------+----------+----+                            |
|          |          |                                  |
|  +-------+--+  +----+----------+                      |
|  | Backup   |  | USB Bridge    |                      |
|  | Reader   |  | (libimobile-  |                      |
|  | (NSOpen  |  |  device)      |                      |
|  |  Panel)  |  +------+--------+                      |
|  +----------+         |                                |
|  [App Store]   [Direct Download]                       |
+------------------------------------------------------+
                        |
              (USB / usbmuxd)
                        v
                 +--------------+
                 |    iPhone     |
                 |  sbservices   |
                 +--------------+
```

The **Layout Data Layer** is a protocol (`LayoutDataProvider`) with two concrete implementations:
- **BackupReader**: Reads `IconState.plist` from a user-selected Finder backup directory. Sandbox-safe via `NSOpenPanel` + security-scoped bookmarks. Used in the Mac App Store edition.
- **USBBridge**: Wraps libimobiledevice for live read/write via `com.apple.springboardservices`. Used in the direct download edition.

Both implementations return the same `HomeScreenLayout` model, so the entire UI layer (canvas, algorithm, suggestions, snapshots) works identically regardless of data source.

---

## V1 Scope

### Must Have (Both Editions)
- Read and display all home screen pages on a zoomable canvas
- Drag-and-drop single apps and multi-select groups between pages
- Show existing widgets (movable but not creatable)
- Before/after comparison view
- Undo/redo (100+ levels)
- Named layout snapshots

### Must Have (Direct Download / Pro Only)
- Live USB device connection and real-time layout read
- "Apply to iPhone" with auto-backup of previous layout
- Live app icon and wallpaper fetching from device

### Must Have (Mac App Store / Lite Only)
- Open Finder backup via `NSOpenPanel` to read layout
- Export modified layout (user restores via Finder manually)
- "Upgrade to Pro" prompt linking to website for USB features

### Should Have
- Organization score
- One-click "Quick Organize" suggestion (move top apps to page 1)
- Category color overlay
- App Library sidebar (drag apps on/off home screen)

### Could Have (V2)
- Full algorithmic reorganization (HDBSCAN + thumb-zone optimization)
- Theme marketplace
- Shareable layout configs
- Usage heatmap overlay
- Focus Mode layout management

### Won't Have (V1)
- Wireless sync (USB only for reliability)
- Widget creation (only moving existing ones)
- iOS Shortcuts integration
- Windows version

---

## Market Position

- **Mac App Store edition**: Free (visualization + score + suggestions) — acquisition funnel
- **Direct download Pro**: $12.99 one-time (full USB read/write + one-click apply)
- **Distribution**: Dual — Mac App Store for discovery, direct download for power features
- **Revenue ceiling**: $100K-$500K/yr standalone; theme marketplace could be larger
- **Competitive moat**: Purpose-built UX + smart algorithms + community/marketplace

## Key Risks

| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| `set_icon_state()` blocked on iOS 18 | High | Unknown | Validate immediately; backup fallback ready |
| Apple ships native Mac home screen editor | Fatal | Medium (2-3yr) | Federighi's rejection buys time; pivot to marketplace |
| iOS update breaks sbservices | High | Low (stable 15+ yrs) | pymobiledevice3 community adapts quickly |
| Small TAM, not enough pain to pay | Medium | Medium-High | Validate with landing page before building |
| Widget manipulation causes SpringBoard crash | Medium | Medium | V1: move-only, no creation; extensive device testing |

## What Makes This Different From Past Failures

1. **Purpose-built**, not a side feature in a file manager
2. **Smart algorithms** (HDBSCAN, Fitts's Law optimization) — no prior tool had this
3. **Modern UX** (Figma-style canvas, before/after, organization score) — prior tools had 2010-era interfaces
4. **The stability principle** — prior tools moved everything; this moves the minimum for maximum improvement
5. **Theme marketplace potential** — prior tools had no network effects
