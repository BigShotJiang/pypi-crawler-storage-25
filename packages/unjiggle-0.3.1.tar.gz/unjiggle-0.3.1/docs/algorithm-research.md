# Algorithm Research: Organizing Phone Home Screens

## The Signal Problem

App Store categories are too coarse (~27 categories). A robust categorization needs multiple signals:

- **Usage frequency** (Screen Time data)
- **Frecency** (frequency x recency decay)
- **Time-of-day patterns** (morning apps, work apps, evening apps)
- **Co-usage patterns** (apps used in the same session)
- **App Store category** (coarse but free metadata)
- **Name/description embedding** (NLP similarity)
- **Icon visual similarity** (color histograms)

---

## Clustering Algorithms

### HDBSCAN (Recommended)

- No need to pre-specify K (number of clusters)
- Naturally identifies "noise" apps that don't fit any group
- Works well with mixed feature types
- Reference: Campello, Moulavi, Sander (2013)

### K-Means
- Good when target number of groups is known
- K-Medoids (PAM) variant more robust to outliers
- Challenge: choosing K

### Hierarchical Agglomerative Clustering (HAC)
- Natural fit — home screen IS hierarchical (pages > folders > positions)
- Ward's method produces balanced clusters
- Dendrograms let users "cut" at different granularity levels

### Topic Modeling / Embeddings
- **App2Vec** (Zhao et al., 2019): Train embeddings from co-usage sequences
- **Sentence-BERT on app descriptions**: Captures functional similarity better than category labels
- **LDA**: Treat each user's app collection as a "document," discover latent categories

---

## Spatial Layout Optimization

### The Core Problem

Given G groups of apps, place them on grid pages (each ~24 slots: 6x4) such that:
1. Most-used apps are most accessible (Fitts's Law)
2. Related apps are spatially proximate
3. Groups are visually coherent
4. Total number of pages is minimized

### Relevant Frameworks

**Bin Packing (page allocation)**
- First Fit Decreasing: sort groups by size descending, place each in first page with room
- Handles macro layout: which groups go on which pages

**Quadratic Assignment Problem (QAP)**
- Minimize sum of (flow between items) x (distance between positions)
- Flow = co-usage frequency or semantic similarity
- Distance = grid distance between positions
- NP-hard, but metaheuristics work well for ~200 items

**Treemap Algorithms**
- Squarified Treemaps (Bruls et al., 2000): divide rectangle into sub-rectangles proportional to weight
- Applicable at group-allocation level

**Force-Directed Graph Layout**
- Attractive forces between related apps, repulsive between unrelated
- Run physics simulation, snap to grid
- Algorithms: Fruchterman-Reingold, ForceAtlas2

**Hungarian Algorithm**
- Optimal bipartite matching of apps to positions
- O(n^3) per page, trivial for n=24
- Best for within-page assignment with thumb-zone weights

### Fitts's Law and Thumb Zones

Fitts's Law: Time to acquire target = a + b * log2(1 + D/W)

Since all icons are same size, minimizing time means minimizing distance from thumb rest.

**Thumb Zone Research:**
- Steven Hoober (2013): 49% of users use one-handed thumb grip
- Scott Hurff (2014): Mapped "easy," "stretch," "hard-to-reach" zones
- Bergstrom-Lehtovirta & Oulasvirta (CHI 2014): Formal model of thumb reachability

**Reachability heat map (right-handed, 6x4 grid):**
```
  [ 2  3  3  2 ]   <- hardest to reach (top corners)
  [ 3  5  5  3 ]
  [ 5  7  7  5 ]
  [ 7  9  9  7 ]
  [ 8 10 10  8 ]
  [ 9 10 10  9 ]   <- easiest (thumb arc, bottom center)
```

---

## Analogous Domains

### Desktop Icon Organization — Stardock Fences (Windows)
- Most successful desktop organizer
- Key insight: user-defined regions with auto-sort within them
- Semi-automatic beats fully automatic

### File Auto-Organization — Hazel (macOS)
- Rule-based: users define rules, system executes
- Most adoptable auto-organization is rule-based and transparent

### Email — Gmail Priority Inbox / Categories
- ML classifier (logistic regression) trained per-user
- Universal categories work: "Primary," "Social," "Promotions"
- Personalized models beat global ones

### Photo Organization — Apple Photos
- Face clustering: deep learning embeddings + agglomerative clustering
- Place clustering: DBSCAN on GPS coordinates
- Multi-signal clustering (time + content + location) creates meaningful groups

### Retail Planograms — THE CLOSEST ANALOGY
- Optimizes product placement on shelves
- Objectives: maximize sales, category adjacency, minimize restocking
- Algorithms: genetic algorithms, simulated annealing, constraint programming
- "Eye-level = buy-level" analogous to "thumb-zone = prime real estate"
- Category adjacency rules: "chips next to dips" = "Camera next to Photos"
- Reference: Corstjens & Doyle (1981), "A Model for Optimizing Retail Space Allocations"

### Keyboard Layout Optimization — Dvorak, Colemak, Carpalx
- Optimize letter placement for frequency and finger travel
- Simulated annealing over the permutation space
- Key insight: **muscle memory is powerful** — optimal layout (Dvorak) failed adoption
- Any reorganizer must account for disruption cost

---

## Smart Suggestions & Context-Aware Layouts

### Frecency (Firefox, ~2005)
- Score = frequency x recency_weight
- Firefox: score = visit_count x (100 if <4 days, 70 if <14 days, ...)
- Simple, effective, used in many autocomplete systems
- Best single ranking signal for this problem

### Time-Based Layouts
- Morning: Weather, News, Calendar, Health
- Work: Slack, Email, Calendar, Zoom
- Evening: Netflix, YouTube, Social, Games
- Implementation: discrete modes (like Focus Modes) or continuous prediction

### Location-Based Layouts
- Home: streaming, smart home, personal
- Office: productivity, communication
- Gym: music, workout tracking

### Relevant Research
- Shin et al. (2012): Time-of-day is strongest predictor of next app launch
- Yan et al. (2012): "FALCON" — 4x improvement over frequency-based ranking
- Bohmer et al. (CHI 2011): Large-scale app usage by time of day

---

## Practical Algorithm Pipeline

### Phase 1: Feature Extraction
Per app: frecency, temporal distribution (4 buckets), App Store category (one-hot), name embedding, co-usage graph

### Phase 2: HDBSCAN Clustering
- Auto-determines K, identifies noise points
- Post-process: merge tiny clusters (<3 apps), cap max cluster at page capacity
- User names/renames groups

### Phase 3: Page Allocation
- Sort groups by total frecency
- First Fit Decreasing bin packing
- Dock: top 4 by frecency regardless of group

### Phase 4: Within-Page Layout
- Build thumb-zone weight matrix
- Sort apps by frecency within page
- Hungarian algorithm for optimal assignment

### Phase 5: Stability
- Penalty for displacement from current positions
- total_cost = layout_cost + lambda * displacement_cost
- Lambda starts high (conservative) — user can lower it
- Default: move minimum apps for maximum improvement

### Performance
- 200 apps, ~8 pages of 24 slots
- HDBSCAN: O(n^2), trivial for n=200
- Hungarian per page: O(24^3), trivial
- Total: well under 1 second

---

## Key Academic References

| Paper | Year | Key Contribution |
|-------|------|-----------------|
| Shin et al., "Understanding and Prediction of Mobile Application Usage" | 2012 | Contextual app prediction |
| Yan et al., "FALCON: Fast App Launcher" | 2012 | Bayesian context-aware launcher |
| Al-Subaihin et al., "App Store Mining and Analysis" | 2016 | NLP-based app categorization |
| Zhao et al., "App2Vec" | 2019 | App embeddings from co-usage |
| Bruls et al., "Squarified Treemaps" | 2000 | Space-filling layout algorithm |
| Bergstrom-Lehtovirta & Oulasvirta, "Modeling Thumb Reachability" | 2014 | Fitts's Law for mobile grids |
| Oulasvirta et al., "Springboard: Finding What You Need" | 2012 | Spatial memory for app finding |
| Corstjens & Doyle, "Optimizing Retail Space Allocations" | 1981 | Shelf/planogram optimization |
| Koskela et al., "Mobile Phone Home Screen Organization" | 2004 | HCI study on phone menu organization |
| Karlson et al., "Organizing from Smartphone Data" | 2010 | Users employ 3-5 strategies simultaneously |

---

## Key Takeaways

1. **Multi-signal clustering beats single-signal**: Combine usage, temporal, semantic, and co-usage.
2. **HDBSCAN is the best-fit algorithm**: No pre-specified K, handles noise, works with mixed features.
3. **Thumb-zone weighting is essential**: Optimal layout is thumb-arc outward, not top-left to bottom-right.
4. **Planogram analogy is the strongest**: Same mathematical structure as retail shelf optimization.
5. **Stability must be first-class**: Spatial memory is how users find apps. Minimize displacement.
6. **Context-aware layouts are the frontier**: Time + location layouts are the biggest UX win.
7. **Semi-automatic beats fully automatic**: Users define groups, system sorts within them.
8. **Frecency is the best single ranking signal**: Frequency x recency outperforms either alone.
