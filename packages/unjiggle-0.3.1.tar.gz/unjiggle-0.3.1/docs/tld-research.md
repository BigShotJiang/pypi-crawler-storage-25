# TLD Research: Domain Strategy for Unjiggle

*Research date: March 2026*

## Executive Summary

For a Mac developer tool like Unjiggle, the TLD choice is primarily a **branding and trust decision**, not an SEO decision. Google officially treats all gTLDs equally in rankings. The real differences are in user trust perception, memorability, and the signal a TLD sends to your target audience. The evidence points to **.app** as the strongest choice for this product category, with **.com** as the gold standard if available and affordable.

---

## 1. Do Search Engines Rank TLDs Differently?

**Official answer: No.**

Google's John Mueller has stated explicitly and repeatedly:

> "The TLD is not something we take into account." ([Search Engine Journal](https://www.searchenginejournal.com/google-on-generic-top-level-domains-for-seo/561305/))

> "There's absolutely no SEO advantage from using a [keyword] domain." ([SE Roundtable](https://www.seroundtable.com/google-new-tlds-seo-20630.html))

> "Google's systems treat new gTLDs like other gTLDs (like .com & .org)." ([Stan Ventures](https://www.stanventures.com/news/google-says-keyword-gtlds-offer-zero-seo-advantage-5823/))

**Key nuances:**

- **No algorithmic penalty** exists for .app, .dev, .io, .one, or .lol. Google does not rank .com higher than new gTLDs.
- **Indirect SEO effects** exist through click-through rates (CTR). If users in search results skip an unfamiliar TLD, lower CTR can eventually affect rankings. This is a user trust issue, not an algorithm issue.
- **Spam-associated TLDs** like .xyz, .top, .loan, and .bid face practical disadvantages because they attract so much abuse that email providers and security tools flag them. None of .app/.dev/.io/.one/.lol appear on Spamhaus's worst TLD lists. The worst offenders are .xin (82% malicious), .qpon (71%), .locker (68%), and similar obscure gTLDs. ([Stobbs](https://www.iamstobbs.com/insights/an-updated-view-of-bad-tlds))
- **Country-code TLDs** (ccTLDs like .de, .fr) do carry geographic signals. Generic new TLDs do not.

**Bottom line:** Search engines will not penalize Unjiggle for using any of these TLDs. The domain choice should be made on branding grounds.

Sources: [Search Engine Land](https://searchengineland.com/domain-extensions-seo-454524), [Search Engine Journal](https://www.searchenginejournal.com/google-on-generic-top-level-domains-for-seo/561305/), [Hover](https://hover.blog/do-new-top-level-domains-affect-seo/)

---

## 2. What TLDs Do Successful Developer Tools Use?

| Product | Domain | TLD | Category |
|---------|--------|-----|----------|
| Homebrew | brew.sh | .sh | Package manager (shell pun) |
| Vercel | vercel.com | .com | Cloud platform |
| Linear | linear.app | .app | Project management |
| Raycast | raycast.com | .com | Launcher |
| Arc | arc.net | .net | Browser |
| Warp | warp.dev | .dev | Terminal |
| Fig | fig.io | .io | Terminal autocomplete (acquired by AWS, now sunset) |
| iTerm2 | iterm2.com | .com | Terminal |

**Pattern:** The most established/funded tools use .com. Newer developer-focused tools lean toward .app and .dev. The .sh choice by Homebrew is a clever domain hack (shell script file extension). Fig used .io but was acquired and sunset; the .io domain served it fine during its growth phase.

Notably, **Vercel uses .com** for its corporate site but provides all deployments under **.vercel.app** subdomains, using .app as its infrastructure TLD.

---

## 3. What TLDs Do Successful Indie Mac Apps Use?

| Product | Domain | TLD | Category |
|---------|--------|-----|----------|
| CleanShot X | cleanshot.com | .com | Screenshot tool |
| Bartender | macbartender.com | .com | Menu bar manager |
| Raycast | raycast.com | .com | Launcher |
| iStat Menus | istatmenus.com (via bjango.com) | .com | System monitor |
| Fantastical | flexibits.com | .com | Calendar |
| Things 3 | culturedcode.com | .com | Task manager |
| Bear | bear.app | .app | Notes |
| Craft | craft.do | .do | Notes/docs |

**Pattern:** The dominant pattern among successful indie Mac apps is overwhelmingly **.com**. The notable exception is **Bear** at bear.app, which uses .app effectively because the product literally is an app and the domain reads naturally ("bear app"). Craft uses .do as a domain hack ("craft do" = "do crafting").

---

## 4. Is .app Specifically Trusted Because Google Owns It?

**Yes, .app has concrete technical trust advantages:**

- **Google Registry** operates .app (launched May 2018). ([The SSL Store](https://www.thesslstore.com/blog/google-launches-dot-app/))
- **HTTPS-only enforcement:** .app is on the HSTS preload list at the TLD level. Every .app domain can only be loaded over HTTPS, enforced by Chrome, Firefox, Safari, Opera, and Edge. This is a hard technical guarantee, not a policy suggestion. ([Comodo SSL Store](https://comodosslstore.com/blog/google-launches-app-top-level-domain-with-hsts-as-a-default.html))
- **Same applies to .dev:** Google also operates .dev with identical HSTS preload enforcement. ([Google blog](https://blog.google/technology/developers/why-app-and-dev-are-perfect-homes-for-developer-tools/))
- Google enforces HTTPS on **45 TLDs** it operates, including .app, .dev, .page, .new, and others. ([The SSL Store](https://www.thesslstore.com/blog/google-forcing-https-connections-45-tlds-hsts/))

**Does this affect trust perception?** The HTTPS enforcement is invisible to users (they just see the lock icon). The trust benefit is:
1. **Technical:** eliminates protocol downgrade attacks and cookie hijacking on first connection.
2. **Signaling:** developers who know about this (your target audience) will recognize .app and .dev as quality signals.
3. **Ecosystem:** Google actively promotes .app and .dev for developer tools, which reinforces the association.

**The .app and .dev TLDs are not just "Google-owned" -- they are technically more secure than .com by default.**

---

## 5. Do People Actually Type Domains Anymore?

**Mostly no, but memorability still matters.**

Traffic source data (2025):
- **Organic search:** 53.1% of website traffic ([SQ Magazine](https://sqmagazine.co.uk/website-statistics/))
- **Direct traffic** (URL typing + bookmarks): 21-22% of traffic
- **Referral/social/other:** remainder

However, for a **Mac app product page**, the traffic pattern is different:
- Users discover the app through search, Hacker News, Reddit, Twitter/X, YouTube reviews, or word of mouth
- They navigate via links, not typing
- The domain matters most for **recognition when shared** (a tweet saying "check out unjiggle.app" vs "check out unjiggle.lol")
- **Memorability data** from GrowthBadger's 1,500-person study shows .com is remembered correctly 44% of the time vs 33% for .co and 24-31% for other TLDs. When people misremember, they default to .com at a 3.8x rate over any other TLD. ([GrowthBadger](https://growthbadger.com/top-level-domains/))

**Key insight for Unjiggle:** Your users will find you through links and search, not typing. But when someone says "Unjiggle" in conversation, the listener will mentally append ".com" or ".app" -- not ".lol" or ".one". The TLD needs to be guessable from context.

---

## 6. TLD-by-TLD Analysis for Unjiggle

### .com -- The Default

- **Trust:** Highest. 95% awareness, 70%+ of people trust .com more than alternatives. ([ICANN study](https://www.icann.org/en/announcements/details/icann-commissioned-study-finds-increased-awareness-and-trust-in-domain-name-system-23-6-2016-en))
- **Memorability:** Highest (44% recall rate, 3.8x default assumption).
- **Signal:** "Established business." Does not signal "developer tool" specifically.
- **Availability:** unjiggle.com DNS returns no records (may be parked/reserved -- needs registrar check).
- **Cost:** Premium if available on aftermarket. Standard .com registration is ~$10-15/year.
- **Verdict:** Best if available at reasonable cost. Signals "real product."

### .app -- The Strong Contender

- **Trust:** Good within tech audiences. Google-operated. HTTPS-only.
- **Memorability:** Lower than .com but reads naturally ("Unjiggle app").
- **Signal:** "This is an app" -- perfect semantic fit for a Mac app product.
- **Availability:** **Already registered.** unjiggle.app resolves to 91.227.138.66. The site shows minimal content (just the word "Unjiggle"), suggesting it may be squatted or an early-stage project.
- **Cost:** ~$14-20/year for new registration.
- **Examples in market:** linear.app, bear.app, bartender.app (macOS apps using this TLD successfully).
- **Verdict:** Semantically ideal for "Unjiggle" as a Mac app. Reads like a natural phrase. Would need to acquire from current owner.

### .dev -- The Developer Signal

- **Trust:** Good within developer audiences. Google-operated. HTTPS-only.
- **Memorability:** Lower than .com. Reads as "Unjiggle dev" which could imply development/beta.
- **Signal:** "This is for developers" or "this is in development." Slight ambiguity.
- **Availability:** **Registered.** unjiggle.dev resolves to 136.40.68.155.
- **Cost:** ~$12-16/year.
- **Examples in market:** warp.dev (terminal). Strong for developer-only tools.
- **Risk:** "unjiggle.dev" could read as "the dev environment for Unjiggle" rather than the product itself. Warp gets away with it because "warp" is not a compound word -- "warp.dev" clearly means "Warp, a dev tool." "unjiggle.dev" could mean "Unjiggle's development site."
- **Verdict:** Good but semantically ambiguous for this specific product name.

### .io -- The Startup Classic

- **Trust:** Strong in developer/startup circles. Ranked 24th globally by usage (0.47% of domains).
- **Memorability:** Moderate. Well-known among tech audiences.
- **Signal:** "Tech startup / SaaS." Less specifically "app" than .app.
- **Availability:** **Registered.** unjiggle.io resolves to 136.40.68.155 (same IP as .dev, possibly same owner).
- **Cost:** Expensive at $50-100/year. ([Domain Details](https://domaindetails.com/tlds/compare/io-vs-dev))
- **Sovereignty risk:** The British Indian Ocean Territory is being transferred to Mauritius. ICANN has a 5-year (extendable to 10-year) retirement process if .io is delisted from ISO 3166-1. Not imminent, but a real long-term uncertainty. Precedent: .su (Soviet Union) still exists 35+ years later. ([The Register](https://www.theregister.com/2024/10/10/io_domain_uk_mauritius/), [ICANN blog](https://www.icann.org/en/blogs/details/the-chagos-archipelago-and-the-io-domain-14-11-2024-en))
- **Ethical concern:** Some developers avoid .io due to the forced displacement of the Chagossian people. Minor factor but exists. ([Domain Details](https://domaindetails.com/tlds/compare/io-vs-dev))
- **Verdict:** Would work but expensive, has geopolitical risk, and the .io era may be waning as .app and .dev gain traction.

### .one -- The Wildcard

- **Trust:** Low awareness. Ranked 143rd globally (0.02% of domains).
- **Memorability:** Poor. Users will not guess "unjiggle.one" from hearing "Unjiggle."
- **Signal:** Unclear. Does not communicate "app" or "developer tool."
- **Availability:** DNS returns no records. Likely available.
- **Cost:** ~$10-15/year.
- **Examples in market:** No prominent developer tools use .one.
- **Verdict:** Inexpensive and available but sends no meaningful signal. "unjiggle.one" reads strangely -- "Unjiggle one" implies a version number, not a product category.

### .lol -- The Gamble

- **Trust:** Very low awareness. Ranked 322nd globally (0.01% of domains).
- **Memorability:** Poor for a productivity tool. Memorable as a novelty, forgettable as a brand.
- **Signal:** "Fun/joke/meme." Directly conflicts with "serious tool for developers."
- **Availability:** DNS returns no records. Likely available.
- **Cost:** ~$3-30/year depending on registrar.
- **Examples in market:** No developer tools use .lol. Used for joke sites and memes.
- **Verdict:** Would actively harm credibility for a developer productivity tool. A Mac-owning developer seeing "unjiggle.lol" will assume it is a joke, a meme page, or not a real product. This is the worst option for the stated audience.

---

## 7. "Real Product" vs "Side Project" Signal

Based on the evidence, here is how TLDs map to perceived seriousness for Mac-owning developers:

| TLD | Perceived Signal |
|-----|-----------------|
| .com | Established business, real product |
| .app | Real product, specifically a polished app |
| .dev | Developer-focused tool, possibly still in active development |
| .io | Tech startup, SaaS product, credible but "startup-ey" |
| .net | Older tool, established but not flashy |
| .sh | Clever (for CLI tools only) |
| .one | Unknown quantity, no signal |
| .lol | Not a real product, joke, or side project |

The dividing line between "real product" and "side project" in domain choice:

**"Real product" signals:** .com, .app, custom domain matching the brand
**"Could go either way":** .dev, .io
**"Side project" signals:** .one, .xyz, .lol, .me, most obscure gTLDs

---

## 8. Recommendation

**Ranked options for Unjiggle:**

1. **unjiggle.app** -- Best fit. "Unjiggle" is literally a Mac app. The domain reads as a natural phrase. Google-backed, HTTPS-enforced, used by Linear, Bear, and other successful Mac/developer apps. **Primary recommendation** if acquirable from the current registrant.

2. **unjiggle.com** -- Best for raw trust and memorability. Less semantically specific than .app but universally recognized. Worth investigating availability/aftermarket price.

3. **unjiggle.dev** -- Acceptable fallback. Signals developer focus. Mild semantic ambiguity ("is this the dev site?"). Already registered; same IP as .io suggests same owner.

4. **unjiggle.io** -- Viable but expensive and carries geopolitical uncertainty. The .io-as-startup signal is less distinctive than it was in 2015-2020.

5. **unjiggle.one** -- Not recommended. No signal value. Would require extra marketing spend to overcome the "what is this?" reaction.

6. **unjiggle.lol** -- Actively harmful to credibility for this product category. Do not use.

**Practical note:** unjiggle.app, unjiggle.dev, and unjiggle.io are all currently registered. Acquisition costs and the existing registrant's willingness to sell are likely the decisive factor.

---

## Sources

- [Search Engine Land: Domain Extensions and SEO](https://searchengineland.com/domain-extensions-seo-454524)
- [Search Engine Journal: Google on Generic Top Level Domains](https://www.searchenginejournal.com/google-on-generic-top-level-domains-for-seo/561305/)
- [SE Roundtable: New TLDs Have No Magical SEO Bonus](https://www.seroundtable.com/google-new-tlds-seo-20630.html)
- [Stan Ventures: Google Says Keyword gTLDs Offer Zero SEO Advantage](https://www.stanventures.com/news/google-says-keyword-gtlds-offer-zero-seo-advantage-5823/)
- [Target Internet: Google Confirms TLD Keywords Not a Ranking Factor](https://targetinternet.com/resources/google-analyst-confirms-tld-keywords-are-not-a-factor-in-rankings)
- [GrowthBadger: TLD Trust and Memorability Study (n=1,500)](https://growthbadger.com/top-level-domains/)
- [ICANN: Consumer Trust Survey](https://www.icann.org/en/announcements/details/icann-commissioned-study-finds-increased-awareness-and-trust-in-domain-name-system-23-6-2016-en)
- [Varn: 70% Don't Trust Newer Domains](https://varn.co.uk/insights/70-of-people-dont-trust-newer-website-domains/)
- [The SSL Store: Google Launches .app with HTTPS](https://www.thesslstore.com/blog/google-launches-dot-app/)
- [Comodo: .app HSTS Default](https://comodosslstore.com/blog/google-launches-app-top-level-domain-with-hsts-as-a-default.html)
- [The SSL Store: Google Forces HTTPS on 45 TLDs](https://www.thesslstore.com/blog/google-forcing-https-connections-45-tlds-hsts/)
- [Google Blog: Why .app and .dev Are Perfect for Developer Tools](https://blog.google/technology/developers/why-app-and-dev-are-perfect-homes-for-developer-tools/)
- [Domain Details: .IO vs .DEV Comparison](https://domaindetails.com/tlds/compare/io-vs-dev)
- [The Register: .io Domain Isn't Going Anywhere Soon](https://www.theregister.com/2024/10/10/io_domain_uk_mauritius/)
- [ICANN Blog: The Chagos Archipelago and .io](https://www.icann.org/en/blogs/details/the-chagos-archipelago-and-the-io-domain-14-11-2024-en)
- [DNS Institute: TLD Popularity Rankings](https://dnsinstitute.com/research/popular-tld-rank/)
- [Spamhaus: Domain Reputation Reports](https://www.spamhaus.org/resource-hub/domain-reputation/domain-reputation-update-oct-2024-mar-2025/)
- [Stobbs: Updated View of Bad TLDs](https://www.iamstobbs.com/insights/an-updated-view-of-bad-tlds)
- [SQ Magazine: Website Traffic Statistics 2025](https://sqmagazine.co.uk/website-statistics/)
- [Domain Details: Best TLDs for Startups](https://domaindetails.com/kb/best-tlds-for-startups)
