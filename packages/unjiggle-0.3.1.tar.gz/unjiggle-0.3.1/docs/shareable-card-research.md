# Shareable Summary Card Research: Visual Patterns from the Best Consumer Apps

*Research date: March 2026*

---

## 1. Spotify Wrapped 2025

### The Hero Visual
**Oversized typography on flat color fields.** The 2025 aesthetic shifted to a stripped-back palette of black, white, green, and red -- inspired by 90s urban street culture and analog mixtapes. The hero element on any given card is a single enormous number or name: "127,482 minutes" or "BAD BUNNY" rendered at scale that fills 60-70% of the card. Grunge textures, ripped paper edges, and holographic accents serve as background treatment, never competing with the data.

### Card Structure (per screen in the story flow)
```
+----------------------------------+
|  [Small context label]           |  <- "Your top artist was"
|                                  |
|                                  |
|     MASSIVE TYPOGRAPHY           |  <- The hero: artist name, number, or song title
|     (fills 60% of frame)        |     in condensed italic font with retro outlines
|                                  |
|  [Supporting detail]             |  <- "You listened 847 times"
|                                  |
|  [Gradient/texture background]   |  <- Flat color or grunge texture
|                                  |
|  [Spotify logo - bottom corner]  |
+----------------------------------+
```

### What Makes It Personal
- YOUR specific artist, YOUR minute count, YOUR top genre
- "Top 0.5% of listeners" -- ranking you against all other fans
- "Listening Age" -- comparing your taste to a demographic
- Fan Leaderboard position among that artist's global audience
- Each card is unreplicable -- nobody else has the same combination

### What Makes It Universal
- Everyone knows what a "top artist" is -- zero learning curve
- The format is a cultural event (December = Wrapped season)
- Numbers are inherently comparable ("my minutes vs. yours")
- The archetype/personality framing invites debate

### Aspect Ratio and Composition
- **9:16 portrait** (1080x1920) -- native to Instagram Stories, TikTok, Snapchat
- Sequential story cards, each with ONE data point per screen
- High-contrast text on flat or gradient backgrounds
- Typography IS the visual -- no charts, no graphs, no infographics
- Bold type on simple backgrounds; "text as form and pattern"

### Key Design Principle
**One number, one screen.** Wrapped never shows a dashboard. Each card reveals one fact at a time, creating a narrative arc of escalating personal reveals. The share screen is a condensed derivative with larger, bolder font than the in-app version.

---

## 2. Apple Music Replay 2025

### The Hero Visual
**Album art collage with animated transitions.** Unlike Spotify's typography-first approach, Apple leads with album artwork. The hero is a mosaic of your most-listened album covers, animated with smooth Instagram Stories-style transitions. The artwork itself IS the personalization -- your taste rendered as a visual grid of covers.

### Card Structure
```
+----------------------------------+
|                                  |
|  [Album art grid / collage]      |  <- 3-4 album covers arranged artfully
|                                  |
|  YOUR TOP ARTISTS                |  <- Clean SF Pro typography
|  1. Artist Name                  |
|  2. Artist Name                  |
|  3. Artist Name                  |
|                                  |
|  [Total minutes: 42,891]         |  <- Supporting stat
|                                  |
|  [Apple Music wordmark]          |
+----------------------------------+
```

### What Makes It Personal
- Album artwork collage is visually unique to each person
- Listening habits categorized: "Discovery," "Loyalty," "Comebacks"
- Total minutes, artist count, genre breakdown
- Highlight Reel is a 30-second shareable video with YOUR music playing

### What Makes It Universal
- Album covers are instantly recognizable cultural objects
- "Top 3 artists" is a universal format everyone understands
- Clean Apple aesthetic is aspirational -- people share it because it looks polished

### Aspect Ratio and Composition
- **9:16 portrait** for Stories, with a 30-second video highlight reel
- SF Pro typography, clean white/dark backgrounds
- Album art serves as color palette (adapts to your music taste)
- Transitions modeled on Instagram Stories swipe format

### Key Design Principle
**The content IS the visual.** Apple doesn't need bold typography tricks because album art is inherently visually rich and personal. The design simply frames your existing visual identity (your music taste as expressed through cover art).

---

## 3. Strava Year in Sport 2025

### The Hero Visual
**A single enormous stat with athletic context.** The hero is typically total distance or total activities -- "2,847 km" rendered in large type against a backdrop inspired by race bibs and athletic apparel. The color palette deliberately draws from navy, olive green, and warm orange (Strava's accent), evoking the outdoor environments where athletes train.

### Card Structure (sequential story)
```
+----------------------------------+
|  YOUR YEAR IN SPORT              |  <- Header / branding
|                                  |
|                                  |
|        2,847 km                  |  <- HERO: single dominant stat
|        Total Distance            |
|                                  |
|  --------------------------------|
|  147 activities  |  312 hours    |  <- Supporting grid of stats
|  18,400m elev.   |  Longest: 42k|
|  --------------------------------|
|                                  |
|  [Activity photo or route map]   |  <- Personal visual anchor
|                                  |
|  [Strava logo]                   |
+----------------------------------+
```

### What Makes It Personal
- YOUR total distance, hours, elevation -- impossible to fake
- "Flyover Card" showing your most-beloved route with embedded imagery
- Year-over-year comparisons ("23% more than 2024")
- Benchmarking against global Strava community, age group, region
- Customizable: choose cumulative vs. sport-specific, include/exclude profile photo

### What Makes It Universal
- Distance is universally understood (everyone knows what "2,847 km" means)
- Athletic achievement has inherent social currency
- Comparative framing creates instant competition ("mine vs. yours")
- The numbers tell a story of dedication regardless of sport type

### Aspect Ratio and Composition
- **9:16 portrait** stories format, plus a summary share card
- Animated via Lottie (After Effects to JSON), Instagram Stories-like carousel
- Three-act narrative structure: overview totals, hard-won efforts, achievements
- Dark/athletic color palette (navy, olive, Strava orange)
- Minimal design elements: lines, dots, color strips, circles, typography

### Key Design Principle
**Celebration, not analysis.** The design never judges. Even casual users (3 activities/year) get a celebratory experience. The stat is always framed as an achievement, never a shortcoming. 86% view-through rate proves this works.

---

## 4. GitHub Contribution Graph

### The Hero Visual
**A 52x7 grid of colored squares.** This is arguably the most iconic data visualization in tech. Each square is one day, the color intensity maps to contribution count, and the overall pattern across a year becomes a fingerprint of your work ethic. The grid reads left to right like a calendar, with months labeled at top and weekdays on the left.

### Grid Structure
```
     Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep  Oct  Nov  Dec
Mon  [ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ]...
Tue  [ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ]...
Wed  [ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ]...
Thu  [ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ]...
Fri  [ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ]...
Sat  [ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ]...
Sun  [ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ][ ]...
```

### Technical Specifications
- **Cell size**: 11x11 pixels with 2px border-radius (rounded squares)
- **Gutter**: 4px between cells
- **Color scale**: 4 intensity levels of green + gray for zero
  - Gray (#ebedf0): No contributions
  - Light green (#4dd05a): 1-9 contributions
  - Medium green (#37a446): 10-19
  - Medium-dark green (#166b34): 20-29
  - Dark green (#14432a): 30+
- **Layout**: 52-53 columns (weeks) x 7 rows (days)
- **Labels**: Abbreviated months across top, weekdays on left margin

### What Makes It Personal
- The pattern is literally unique to each person -- a visual fingerprint
- Density communicates work ethic at a glance (all green = dedicated)
- Gaps are visible and create narrative (vacation, burnout, project switch)
- People manipulate it as art (pixel-art commits), proving it has cultural meaning

### What Makes It Universal
- The format requires ZERO explanation -- color = activity, darker = more
- Developers worldwide recognize it instantly (it IS GitHub's brand)
- It's landscape-oriented, which makes it ideal for profile headers
- The contrast between "green-filled" and "sparse" profiles is immediately readable

### Aspect Ratio and Composition
- **Landscape, roughly 5:1** -- very wide, very short
- Embedded in profile pages (not a standalone shareable, but people screenshot it)
- The density of the grid IS the information -- no additional text needed
- Third-party tools (Green Wall, GitHub Contributions Chart Generator) exist specifically to make it more shareable -- proving demand for the format

### Key Design Principle
**The pattern IS the message.** No numbers, no labels, no narrative needed. A dense green grid says "I shipped a lot" and a sparse one says "I didn't." The simplicity of color-as-data makes it the most efficient information-to-pixel ratio of any shareable visualization.

---

## 5. iOS Screen Time Weekly Report

### The Hero Visual
**A stacked bar chart with a single dominant number.** The hero is your total daily/weekly screen time in hours and minutes ("4h 23m") displayed prominently above a color-coded bar chart showing category breakdown. The chart uses Apple's system colors for categories (blue for Social, purple for Entertainment, etc.).

### Layout Structure
```
+----------------------------------+
|  SCREEN TIME                     |
|                                  |
|  4h 23m                          |  <- HERO: total usage, large
|  2 min below average             |  <- Comparative context
|                                  |
|  [Stacked bar chart]             |  <- 7 days, color-coded by category
|  |||||||||||||||||||||           |
|  Mo Tu We Th Fr Sa Su            |
|                                  |
|  Most Used                       |
|  1. Instagram  1h 47m            |  <- Ranked app list
|  2. Safari     52m               |
|  3. Messages   38m               |
|                                  |
|  Pickups: 94 (12% more)         |  <- Secondary stat
+----------------------------------+
```

### What Makes It Personal
- YOUR specific usage hours -- a number people are genuinely shocked by
- Category breakdown reveals where your time actually goes
- "Most Used" app ranking exposes habitual behavior
- Pickup count quantifies an unconscious habit (checking your phone)
- Week-over-week comparison creates accountability

### What Makes It Universal
- Everyone has screen time -- it's universal to all iPhone users
- The format is embedded in iOS settings -- 1B+ people see it weekly
- The shock factor ("I use my phone HOW much?") transcends demographics
- Category colors are consistent, so people can compare breakdowns

### Aspect Ratio and Composition
- **Portrait, roughly 3:4** within the iOS Settings UI (not designed for sharing)
- Bar chart is the primary visualization, with drill-down to daily views
- Apple system colors for categories, clean SF Pro typography
- Notably NOT optimized for sharing -- no export, no shareable card
  - This is a missed opportunity that third-party apps exploit

### Key Design Principle
**Shock through specificity.** Screen Time works because it quantifies behavior people thought was invisible. "4h 23m on your phone today" is a data point about yourself that you never asked for but can't ignore. The emotional reaction (guilt, surprise, defensiveness) is what drives people to screenshot and share it despite Apple providing no sharing mechanism.

---

## Cross-Cutting Analysis: The Five Patterns

### Pattern 1: ONE Hero Element Per Card
Every successful shareable has a single dominant visual element:
- Spotify: The artist name or minute count (oversized type)
- Apple Music: Album art collage
- Strava: Total distance number
- GitHub: The green grid itself
- Screen Time: Total hours number

**Rule: If you can't identify the hero in 0.5 seconds, the card fails.**

### Pattern 2: Personal + Comparative = Shareable
Pure personal data is interesting but not shareable. Adding comparison makes it social:
- Spotify: "Top 0.5% of listeners" (you vs. all fans)
- Strava: "23% more than last year" (you vs. yourself)
- GitHub: Green density (you vs. the blank grid)
- Screen Time: "2 min below average" (you vs. all users)

**Rule: The card needs both "here's YOUR data" and "here's where you RANK."**

### Pattern 3: 9:16 Portrait Is the Shareable Standard
Four of five examples use or are optimized for 9:16 portrait format. GitHub is the exception (landscape, profile-embedded). The shareable artifact must be native to Stories/TikTok without cropping.

### Pattern 4: Sequential Reveal > Dashboard
Spotify and Strava both use sequential story cards (one fact per screen) rather than a dense dashboard. Apple Music uses a video highlight reel. The one-at-a-time reveal creates narrative tension and multiple share moments.

**Exception: GitHub is the opposite -- everything visible at once. But it works because the PATTERN is the data, not individual numbers.**

### Pattern 5: Identity Label > Raw Score
Spotify's archetypes ("Top 0.5% listener") and Strava's celebration ("Your biggest climb") outperform raw scores. Screen Time's "4h 23m" works because it implicitly labels you ("heavy user"). A score of "72/100" means nothing. A label of "Digital Hoarder" means everything.

---

## The Unjiggle Hero Visual: The Proposal

### The Data We Have
- 226 apps across 8 pages
- Category distribution (Social 13, Entertainment 8, Games 19, Productivity 37, etc.)
- A color-coded grid of all apps on page 1 (and all pages)
- An archetype label ("The Hyperconnected Optimizer")
- A score (70/100)
- AI observations (text)
- A personality narrative (text paragraph)

### What Should the ONE Hero Visual Be?

## The "App DNA" Grid -- A Color-Coded Home Screen Map

The hero visual for Unjiggle should be **a miniaturized, color-coded representation of the user's entire home screen layout across all pages** -- what I'm calling the "App DNA" grid. Here is why, and here is exactly what it looks like.

### The Visual
```
+------------------------------------------+
|                                          |
|     "The Hyperconnected Optimizer"       |  <- Archetype label (large, bold)
|                                          |
|     +--+ +--+ +--+ +--+ +--+ +--+ +--+ +--+
|     |P1| |P2| |P3| |P4| |P5| |P6| |P7| |P8|
|     |  | |  | |  | |  | |  | |  | |  | |  |  <- 8 mini-grids, 4x6 each
|     |  | |  | |  | |  | |  | |  | |  | |  |     Every cell is a colored square
|     |  | |  | |  | |  | |  | |  | |  | |  |     representing one app's category
|     +--+ +--+ +--+ +--+ +--+ +--+ +--+ +--+
|                                          |
|     226 apps  |  8 pages  |  70/100      |  <- Three key stats
|                                          |
|     [unjiggle.app]                      |
|                                          |
+------------------------------------------+
```

Each of the 8 mini-grids is a 4x6 (or 6x4) matrix where every cell is a small colored square representing one app, colored by category:

| Category | Color | Count |
|----------|-------|-------|
| Productivity | Green | 37 |
| Games | Orange | 19 |
| Social | Blue | 13 |
| Entertainment | Purple | 8 |
| Health & Fitness | Red | 7 |
| Finance | Teal | 11 |
| Utilities | Gray | 18 |
| Photo & Video | Pink | 9 |
| Other | Light gray | remaining |

### Why This Is the Right Hero

**1. It's a GitHub contribution graph for your phone.**
The same principle -- a grid of colored cells where the PATTERN is the data. Dense green on GitHub = productive developer. Scattered rainbow on Unjiggle = chaotic home screen. Organized color blocks = curated user. The pattern communicates in 0.5 seconds without reading a single word.

**2. It's immediately recognizable as "a phone's home screen."**
Everyone with an iPhone instantly recognizes a 4x6 grid of icons. Eight of them in a row is visually novel (nobody has seen their entire home screen layout rendered this way) but immediately comprehensible. This is the DaisyDisk moment -- making the invisible visible.

**3. The chaos IS the visual.**
A messy home screen produces a Jackson Pollock painting of scattered colors across 8 grids. An organized one produces clean color blocks. The visual difference between chaos and order is dramatic and requires zero explanation. This is the before/after color overlay concept from the viral strategy doc, elevated to hero status.

**4. It creates a visual fingerprint.**
Just like GitHub's green grid, no two Unjiggle grids will look the same. The specific pattern of colors across 8 pages is unique to each person. This satisfies the "personal data reveal" requirement -- you're looking at YOUR digital life rendered as a color pattern.

**5. It pairs with the archetype label.**
The grid provides the visual; the archetype provides the narrative. Together they create the Spotify Wrapped formula: a visual pattern (album art / green grid / color grid) plus an identity label (top 0.5% / Digital Hoarder / Hyperconnected Optimizer).

### The Full Card Composition (9:16 Portrait, 1080x1920)

```
+------------------------------------------+  1080px
|                                          |
|  [Unjiggle logo - small, top-left]      |  <- 80px from top
|                                          |
|  YOUR HOME SCREEN DNA                    |  <- Section label, 16pt, muted
|                                          |
|  +----- THE HERO ZONE (40% of card) ---+ |
|  |                                      | |
|  |   "The Hyperconnected               | |  <- Archetype: 36pt bold
|  |    Optimizer"                        | |
|  |                                      | |
|  |   +--+ +--+ +--+ +--+               | |
|  |   |P1| |P2| |P3| |P4|               | |  <- Row 1: Pages 1-4
|  |   |  | |  | |  | |  |               | |     Each grid ~120x180px
|  |   |  | |  | |  | |  |               | |     Cells: 5x5px, 2px gap
|  |   +--+ +--+ +--+ +--+               | |
|  |   +--+ +--+ +--+ +--+               | |
|  |   |P5| |P6| |P7| |P8|               | |  <- Row 2: Pages 5-8
|  |   |  | |  | |  | |  |               | |
|  |   |  | |  | |  | |  |               | |
|  |   +--+ +--+ +--+ +--+               | |
|  |                                      | |
|  +--------------------------------------+ |
|                                          |
|  --- THE NUMBERS ---                     |  <- Divider
|                                          |
|  226 apps across 8 pages                 |  <- Stats block
|  37 productivity apps, but Games are     |
|    on page 1                             |
|  Your most-used app is buried on page 5  |
|  19 games but 0 on your first 2 pages    |
|                                          |
|  +--------------------------------------+|
|  | ORGANIZATION SCORE                    ||
|  | [======70%==========----------] 70    ||  <- Score bar
|  | "Getting There"                       ||
|  +--------------------------------------+|
|                                          |
|  unjiggle.app                           |  <- CTA, bottom
|                                          |
+------------------------------------------+  1920px
```

### Why This Layout Works (Mapped to the Five Patterns)

| Pattern | How Unjiggle Applies It |
|---------|------------------------|
| **ONE hero element** | The 8-grid color map IS the hero -- visible in 0.5 seconds, unique per user |
| **Personal + Comparative** | Your grid pattern + archetype label + score percentile |
| **9:16 portrait** | Native to Stories/TikTok -- no cropping needed |
| **Identity label > raw score** | "The Hyperconnected Optimizer" is the headline, score is secondary |
| **Pattern IS the data** | Like GitHub's green grid -- color distribution tells the story without words |

### The Psychological Hook

When someone sees this card on their feed, three things happen in sequence:

1. **0.5 seconds**: "That's a bunch of colored grids" -- pattern recognition kicks in
2. **1-2 seconds**: "Oh, those are phone home screen pages" -- the 4x6 grid is universally recognizable
3. **2-3 seconds**: "That's really messy/organized" -- the color scatter vs. color blocks tells a story
4. **3-5 seconds**: Reads the archetype label -- "The Hyperconnected Optimizer" -- identity hook
5. **5-10 seconds**: Reads the stats -- "226 apps across 8 pages" -- shock/recognition
6. **Result**: "I wonder what mine would look like" -- the viral loop starts

This mirrors exactly how Spotify Wrapped propagates: see someone's card, wonder about your own, download, generate, share.

### What Unjiggle's Grid Has That GitHub's Doesn't

The GitHub contribution graph is powerful but it's one-dimensional (activity level only). Unjiggle's grid is multi-dimensional:

- **Color** = category (what kinds of apps)
- **Position within grid** = placement priority (top-left = first seen)
- **Distribution across pages** = organization strategy
- **Color clustering** = whether apps are grouped logically
- **Color scatter** = chaos level (the before state)
- **Empty cells** = pages with room vs. packed pages

This density of information in a simple visual format is what makes it screenshot-worthy. A single glance reveals: how many apps, how many pages, how organized, what categories dominate, and whether there's any logic to the arrangement.

### Alternative Heroes Considered and Rejected

| Alternative | Why Rejected |
|------------|-------------|
| **Just the score (70/100)** | Abstract, meaningless without context, not visual. "72" means nothing on a feed. |
| **The archetype label alone** | Text-only isn't screenshot-worthy. Needs a visual anchor. |
| **A single page 1 grid** | Doesn't show the full picture. The 8-page spread IS the story. |
| **A pie chart of categories** | Generic, forgettable, looks like every analytics dashboard. |
| **A radar/spider chart** | Requires explanation, not immediately legible, too "quantified self." |
| **The AI personality narrative** | Too much text. Nobody reads a paragraph on a social feed. |
| **Before/after slider** | Good for the SECOND card (conversion), not the first (viral hook). |

### The Second Card (Post-Reorganization)

After the user accepts Unjiggle's reorganization suggestions, generate a transformation card:

```
+------------------------------------------+
|                                          |
|  BEFORE               AFTER             |
|  +--+ +--+ +--+ +--+  +--+ +--+ +--+   |
|  |P1| |P2| |P3| |P4|  |P1| |P2| |P3|   |  <- 8 grids vs 3 grids
|  +--+ +--+ +--+ +--+  |  | |  | |  |   |     Scattered vs. blocked
|  +--+ +--+ +--+ +--+  +--+ +--+ +--+   |
|  |P5| |P6| |P7| |P8|                    |
|  +--+ +--+ +--+ +--+                    |
|                                          |
|  8 pages  --->  3 pages                  |
|  Score: 70  --->  Score: 92              |
|  "Saved 47 swipes per day"              |
|                                          |
|  [Reorganized with Unjiggle]            |
|  unjiggle.app                           |
|                                          |
+------------------------------------------+
```

The before grids show scattered color; the after grids show clean color blocks. The page count drop (8 to 3) is the headline stat. This is the transformation card -- the conversion tool.

---

## Implementation Recommendation

### Priority Order
1. **Build the color-coded mini-grid renderer first.** This is the atomic unit of the entire visual system. Get each page rendering as a 4x6 color grid with the right category mapping.
2. **Build the 8-page composite layout.** Arrange the mini-grids in a 4x2 formation that reads as "my entire phone."
3. **Build the archetype assignment engine.** Rule-based classification from the existing 12 archetypes.
4. **Build the card compositor.** Combine grid + archetype + stats + score into the 1080x1920 card.
5. **Build one-tap share.** Generate the image, open the system share sheet. Under 3 seconds from tap to post.

### The Litmus Test (from the viral strategy doc)
> "Would I screenshot this and text it to a friend with zero context, and would they immediately understand it and want to get their own?"

The App DNA grid with archetype label passes this test. A scattered rainbow of colors across 8 tiny grids labeled "The Digital Hoarder" with "226 apps across 8 pages" is immediately comprehensible, personally revealing, and makes the viewer wonder about their own.

---

## Sources

### Spotify Wrapped 2025
- [Spotify Wrapped 2025 Design Aesthetic - Envato Elements](https://elements.envato.com/learn/spotify-wrapped-design-aesthetic)
- [2025 Wrapped User Experience - Spotify Newsroom](https://newsroom.spotify.com/2025-12-03/2025-wrapped-user-experience/)
- [Spotify Wrapped 2025 Templates - Figma](https://www.figma.com/community/file/1580122793950964435/spotify-wrapped-2025-templates)
- [Three Design Elements That Made Spotify Wrapped 2024 Great - Medium](https://medium.com/designright/three-design-elements-that-made-spotify-wrapped-2024-great-0a8e2b133b72)

### Apple Music Replay 2025
- [Apple Music Replay 2025 Now Fully Available - MacRumors](https://www.macrumors.com/2025/12/02/apple-music-replay-2025-fully-available/)
- [Apple Music Replay 2025 - Apple Insider](https://appleinsider.com/inside/apple-music/tips/how-to-check-apple-music-replay-2025-and-share-your-year)
- [Apple Music Replay For Instagram Stories - Figma](https://www.figma.com/community/file/1177352188692605989/apple-music-replay-for-instagram-stories)

### Strava Year in Sport
- [Strava Year in Sport Design - It's Nice That](https://www.itsnicethat.com/articles/manual-strava-year-in-sport-graphic-design-150321)
- [Year in Sport 2024 - Khoi B Phan Portfolio](https://www.khoibphan.com/portfolio/strava-year-in-sport-24)
- [Strava Year in Sport - Webby Award Winner](https://winners.webbyawards.com/2025/apps-software/app-features/best-visual-design-aesthetic/332962/strava--year-in-sport)
- [Strava Year in Sport - Manual Creative](https://manualcreative.com/work/strava)

### GitHub Contribution Graph
- [Green Wall - GitHub Contributions Generator](https://github.com/Codennnn/Green-Wall)
- [Understanding Your Contribution Graph - GitHub Community](https://github.com/orgs/community/discussions/176081)
- [GitHub-like Contribution Heatmap in JS - DEV Community](https://dev.to/ajaykrupalk/github-like-contribution-heatmap-in-js-4201)

### iOS Screen Time
- [Breaking Down Apple's iOS Screen Time Report - Vicki Boykis](https://vickiboykis.com/2019/04/29/breaking-down-apples-ios-screen-time-report/)
- [Screen Time Report Guide 2026 - FamiSafe](https://famisafe.wondershare.com/screen-time/ios-screen-time-report-guide.html)
- [Mastering Apple's Screen Time API - Medium](https://medium.com/@manishdevstudio/mastering-apples-screen-time-api-part-4-visualizing-and-managing-activity-data-a761a8daed55)
