# AI-Powered Feature Brainstorm: The "Holy Shit" Features

*Generated 2026-03-27. Goal: features that make people screenshot the result and post it.*

---

## Ranked Feature List

### #1. Personality Mirror

**What the user sees**: After scanning their 150+ apps, Unjiggle generates a brutally accurate personality profile written like a psychic reading. "You downloaded 4 meditation apps between March and June 2024 but your total Screen Time in all of them combined is 47 minutes. You have commitment issues with self-improvement. Meanwhile, your actual coping mechanism is the 2.3 hours/day you spend in Reddit." It identifies phases of your life encoded in your app graveyard: the sourdough phase, the day-trading phase, the "I'm going to learn Japanese" phase. Each phase shown as a timeline with the relevant apps clustered together.

**The wow moment**: Reading something so accurate about yourself that it feels like the app is roasting you. The profile is presented as a beautifully typeset card with your top apps as illustrations, explicitly designed to be screenshotted and shared.

**AI technique**: LLM (Claude/GPT) receives the full app list with App Store metadata (descriptions, categories, install date ranges inferred from app version history), Screen Time data if provided, and generates a structured personality analysis. The LLM is prompted to be witty, specific, and slightly mean -- like a comedy roast, not a horoscope. Clustering by install time windows detects "phases." Embeddings on app descriptions find contradictions (meditation apps vs. doomscrolling apps).

**Shareability**: 10/10 -- This is the viral loop. People cannot resist sharing something that accurately describes them. It's the "Spotify Wrapped for your home screen" moment. Every result is unique and personal. Twitter/X would eat this alive.

**Disorientation mitigation**: 10/10 -- This feature does not move anything. It is pure insight. Zero spatial disruption.

---

### #2. The Archaeology Layer

**What the user sees**: A toggle on the canvas called "Archaeology Mode." When activated, each app gets a subtle glow -- bright for apps used in the last week, dim for last month, completely dark/ghosted for apps untouched in 3+ months. Suddenly the user sees their home screen the way it really is: 60% of their prime real estate is occupied by apps they never open. A ghost town with a few bright spots scattered across 7 pages.

Then the kicker: a single animation where the bright apps consolidate onto pages 1-2, and the ghosted apps fade to a "graveyard" page or App Library. The before/after is visually stunning -- it looks like cleaning a window.

**The wow moment**: The visual shock of seeing how much dead weight is on your home screen. The heatmap-to-cleanup animation is the moment people reach for the screenshot button.

**AI technique**: Screen Time data (from user-provided screenshot, OCR'd) or simple recency heuristics from any available signals. Color mapping is a continuous gradient from "hot" (daily use) to "cold" (months dormant). The consolidation animation uses the existing HDBSCAN clustering but weighted 90% on recency/frequency, with the stability penalty set to zero temporarily for the dramatic reveal (actual suggestion uses normal stability).

**Shareability**: 9/10 -- The before/after heatmap is inherently visual. "I had 47 dead apps on my first 3 pages" is a stat people will share.

**Disorientation mitigation**: 8/10 -- The dramatic animation is a preview only. The actual suggestion preserves the relative ordering of surviving apps and only moves the dead ones. Your muscle memory for apps you actually use stays intact because those apps barely move.

---

### #3. Doppelganger Detection

**What the user sees**: Unjiggle identifies clusters of apps that do the same thing. A panel shows: "You have 5 photo editors (VSCO, Snapseed, Lightroom, Darkroom, Afterlight). You opened Lightroom 34 times last month. You haven't opened the other 4 in 90+ days." Then: "You have 3 weather apps." "You have 4 note-taking apps." Each cluster shown as a visual card with the apps' icons side-by-side, ranked by actual usage. A one-click action: "Keep the winners, send the rest to App Library."

But the clever part: it also finds *hidden* duplicates that aren't obvious. "Google Maps and Citymapper both do navigation. You use Google Maps 95% of the time." Or "Safari, Chrome, Firefox, and DuckDuckGo -- you have 4 browsers."

**The wow moment**: Realizing you've been hoarding functionally identical apps. The "5 photo editors" card is inherently funny and relatable. The hidden duplicates feel like AI magic.

**AI technique**: Two-stage pipeline. First: text embeddings (sentence-BERT or similar) on App Store descriptions to compute pairwise cosine similarity. Cluster apps with similarity > 0.75 as potential duplicates. Second: LLM takes the clusters and validates/explains them in natural language, filtering false positives and finding non-obvious connections. Usage data ranks within each cluster. Vision model on app icons can supplement -- apps with visually similar icons often compete (all those blue-and-white messaging apps).

**Shareability**: 8/10 -- "Unjiggle just told me I have 5 photo editors and I only use one" is a universally relatable tweet. The discovery of hidden duplicates gets shared as "I didn't realize..."

**Disorientation mitigation**: 9/10 -- This only moves apps you don't use. Your primary app in each category stays exactly where it is. The duplicates you never open were never in your spatial memory anyway.

---

### #4. The Layout Genome -- "Show Me Someone Like Me"

**What the user sees**: Unjiggle computes a "layout genome" -- a fingerprint of your app collection and organization style. Then it matches you to anonymized layout archetypes: "You're a Creator (heavy in photo/video/design tools), organized like a Stacker (lots of folders, few loose apps)." It shows you how other Creators organized their screens -- not specific people, but aggregated patterns. "Creators who use Final Cut also tend to keep Compressor, Motion, and Frame.io on the same page."

Optional: the user can export their layout genome as a shareable "setup card" (like a trading card with their archetype, top apps, organization style, and aesthetic stats).

**The wow moment**: Being categorized and seeing that there's a "type" for how you use your phone. The trading card is designed for sharing.

**AI technique**: App collection represented as a sparse vector over all possible bundle IDs. Dimensionality reduction (UMAP) to 2D for visualization. K-means clustering on the reduced space defines archetypes. Archetype descriptions generated by LLM analyzing the centroid apps. The "people like you also..." recommendations use collaborative filtering (users with similar app sets, aggregated patterns). Privacy-preserving: all data is local; archetypes are pre-computed from public App Store category distributions, not actual user data.

**Shareability**: 9/10 -- Trading cards and personality types are sharing gold. "I'm a Creator-Stacker, what are you?" drives engagement.

**Disorientation mitigation**: 7/10 -- If the user applies a recommended layout from their archetype, it could move things significantly. Mitigated by showing it as inspiration, not auto-applying, and always showing the stability slider.

---

### #5. Aesthetic Harmonizer

**What the user sees**: Unjiggle analyzes the visual properties of every app icon on each page and shows an "aesthetic score." It then suggests rearrangements that create visual harmony -- grouping icons by dominant color, creating gradients across the page, or ensuring visual weight is balanced. The preview shows the current page (visually chaotic, random colors) next to the harmonized version (smooth color flow, balanced composition). A toggle switches between "Organize by function" and "Organize by aesthetics" with a slider to blend both.

The most dramatic mode: "Rainbow Flow" -- sorts all apps across all pages in a continuous color spectrum from red to violet. The overview zoom level shows your entire home screen as a rainbow gradient. It looks incredible.

**The wow moment**: The rainbow gradient view at overview zoom. This is the single most screenshottable output the app can produce. It's beautiful, it's unexpected, and it's impossible to do manually.

**AI technique**: Extract dominant colors from app icons using k-means clustering on pixel RGB values (simple computer vision, no ML needed). Convert to HSL color space. For "Rainbow Flow": sort by hue. For "Aesthetic Harmony": minimize color distance between adjacent icons using a traveling salesman heuristic (nearest-neighbor in color space). For balanced composition: treat icon brightness as "visual weight" and balance it across the grid like a center-of-mass calculation. Optional: vision model (CLIP) embeddings on icons for style clustering beyond just color.

**Shareability**: 10/10 -- The rainbow home screen is the most visually stunning output possible. This is the feature that gets posted on Instagram, TikTok, and design Twitter. It's art.

**Disorientation mitigation**: 3/10 -- This deliberately breaks functional grouping in favor of aesthetics. Mitigation: position it as a "fun mode" separate from the organization suggestions. The blending slider lets users find their balance. And some users genuinely prefer aesthetic organization (the r/iOSsetups community).

---

### #6. The Habit Rewire

**What the user sees**: Unjiggle asks "Which apps do you want to use more? Which apps do you want to use less?" The user drags apps into "More" and "Less" buckets (or the AI infers from categories -- social media into "Less," reading/fitness into "More"). Then it generates a layout where the "More" apps are in the thumb zone on page 1, and the "Less" apps are buried deep -- page 5+, inside folders, or moved to App Library entirely.

But the clever twist: it also identifies "gateway apps" -- apps you open right before your problem apps. "You open Instagram within 2 minutes of closing Mail 73% of the time. Moving Mail away from Instagram breaks the chain." It physically separates the trigger-action pairs.

**The wow moment**: The gateway app insight. "You didn't know you had a Mail -> Instagram pipeline, but your Screen Time data proves it." People will share these behavioral chains because they're surprising and personal.

**AI technique**: Screen Time data analysis: compute transition probabilities between consecutive app launches (bigram model on app launch sequences). Identify high-probability pairs where app B (undesirable) follows app A (neutral) with short inter-launch intervals. LLM generates the narrative explanation. Layout optimization uses a modified objective function that maximizes grid distance between identified trigger-action pairs while keeping "More" apps in high-accessibility positions.

**Shareability**: 8/10 -- The behavioral chain insight is highly shareable. "My phone was literally designed to make me scroll Instagram after checking email, and this app fixed it."

**Disorientation mitigation**: 6/10 -- This intentionally moves things, but the user opted in explicitly. The key UX: show exactly which apps move and why before applying. The "why" (breaking a bad habit chain) provides emotional motivation to accept the disorientation.

---

### #7. Context Scenes

**What the user sees**: Unjiggle generates named "scenes" -- complete home screen layouts optimized for different contexts. "Morning Routine" puts Weather, Calendar, News, and your podcast app on page 1. "Deep Work" surfaces Notion, Slack, and your IDE while burying social media. "Weekend" promotes streaming, games, and food delivery. Each scene is visualized as a complete layout preview. The user can activate scenes manually or (future) tie them to Focus Modes.

The twist: the scenes aren't just moving the same apps around. Each scene also suggests which apps to *hide entirely* (move to App Library) for that context, making the phone feel like a different device for each mode.

**The wow moment**: Seeing your phone reimagined for 3-4 distinct contexts, each one clean and purposeful. The comparison between "all 150 apps" and "the 20 you need for Deep Work" is startling.

**AI technique**: Temporal clustering on Screen Time data: identify apps co-occurring in the same time windows (morning, work hours, evening, weekend). LLM receives the temporal clusters and generates scene names and narratives. Optionally, the user describes their routines in natural language and the LLM maps apps to scenes. Each scene's layout uses the same HDBSCAN + thumb-zone optimization pipeline but with a filtered app list.

**Shareability**: 7/10 -- The concept is cool and the comparison views are shareable, but it's more utilitarian than the personality/aesthetic features. Strongest on productivity Twitter.

**Disorientation mitigation**: 5/10 -- Each scene is a radically different layout. But it's modeled on Focus Modes, which users already understand. The key insight: disorientation is contextual. You don't need spatial memory for your Deep Work layout while you're at brunch. Each context has its own spatial memory.

---

### #8. The One-Page Challenge

**What the user sees**: Unjiggle issues a challenge: "Can you survive with just ONE home screen page?" It analyzes usage and identifies the 20-24 apps that cover 95% of your actual launches. Everything else goes to App Library (still searchable, still accessible via Spotlight, just not on the home screen). It generates a single, perfectly organized page with your essential apps in thumb-zone-optimized positions, plus a clean wallpaper showing through the gaps.

A counter shows: "You went from 7 pages (168 app icons) to 1 page (22 icons). That's an 87% reduction."

**The wow moment**: The before/after is the most dramatic transformation possible. Seven cluttered pages versus one clean page. The minimalism is aspirational. The stat ("87% reduction") is tweetable.

**AI technique**: Pareto analysis on Screen Time data: identify the apps that account for 95% of total launches (usually 15-25 apps for most users). LLM generates the narrative framing and handles edge cases ("You never open Calculator from the home screen -- you use Control Center -- so it doesn't need a spot"). Thumb-zone optimization for the single page.

**Shareability**: 9/10 -- Minimalism content is evergreen on social media. The before/after (7 pages -> 1 page) is the most dramatic visual transformation. "I took the One-Page Challenge" could be a viral meme.

**Disorientation mitigation**: 4/10 -- Radical change, but the user opted in as a "challenge." The 22 remaining apps can be placed in positions similar to where they were on page 1 originally. And the apps you never opened weren't really in your spatial memory -- you were already using Spotlight to find them.

---

### #9. The Family Map

**What the user sees**: If the user scans multiple devices (their phone, partner's, kid's), Unjiggle generates a "Family App Map" -- a visual comparison showing which apps are shared across devices, which are unique, and how each person organized differently. "You and Sarah both have Instagram, but she keeps it on page 1 and you buried it in a folder on page 4. You both have 3 weather apps (why does anyone need 3 weather apps?)."

For parents: it surfaces apps on a kid's phone that might warrant a conversation -- not surveillance, but "Did you know your 12-year-old has 4 social media apps you've never heard of?"

**The wow moment**: Seeing your household's digital life laid out side by side. The shared-but-differently-organized apps reveal personality differences. Parents discovering unknown apps on kids' phones.

**AI technique**: Set operations on bundle ID lists across devices (intersection, symmetric difference). LLM generates comparative narrative. For unknown-app detection: cross-reference child's apps against a curated list of age-appropriate apps + App Store age ratings. Embedding similarity to flag apps that are functionally similar to flagged categories (e.g., an app with a description similar to social media but marketed as "messaging").

**Shareability**: 7/10 -- The comparison view is interesting for couples/families. The "household digital portrait" concept is novel. Less universally shareable than individual features.

**Disorientation mitigation**: 10/10 -- Comparing doesn't change anything. Purely informational until the user decides to act.

---

### #10. AI Layout From a Screenshot

**What the user sees**: The user finds a gorgeous home screen setup on Reddit, Instagram, or Pinterest. They drag the screenshot into Unjiggle. The AI identifies every visible app icon in the screenshot, maps them to installed apps, and reconstructs the layout -- automatically handling apps the user doesn't have (suggesting equivalents or leaving gaps). In seconds, the user has a layout that matches the inspiration image, customized with their own apps.

**The wow moment**: Drag a screenshot from r/iOSsetups, get the layout on your phone in 30 seconds. This closes the loop on the entire home screen customization community.

**AI technique**: Vision model (GPT-4V, Claude vision, or fine-tuned YOLO model) detects app icon positions in the screenshot. Each detected icon is matched against: (a) the user's installed app icons using perceptual hashing (pHash) or CLIP embeddings for visual similarity, (b) a database of known app icons. For apps the user doesn't have, the system suggests the closest installed equivalent based on category + description embedding similarity. Grid position extraction from the screenshot maps to the target device's grid dimensions.

**Shareability**: 8/10 -- The concept of "copy anyone's home screen from a screenshot" is magical. Demo videos would go viral on TikTok. The community already shares screenshots -- this makes them actionable.

**Disorientation mitigation**: 4/10 -- Applying someone else's layout is a complete reorganization. But it's entirely user-initiated ("I want to look like THAT"), so the disorientation is expected and desired. The preview step lets them back out.

---

### #11. Spatial Memory Anchoring (The Federighi Feature)

**What the user sees**: Before any reorganization, Unjiggle identifies the user's "anchor apps" -- the 8-12 apps with the strongest spatial memory signal (high usage + long tenure in current position + consistent location across backup history). These anchors are shown with a "lock" icon and are excluded from any automatic suggestion. The reorganization happens *around* the anchors, like rearranging furniture while keeping the couch and bed in place.

A visualization: the current layout with anchor apps highlighted in gold and all other apps grayed out. "These are your muscle-memory apps. We won't touch them."

**The wow moment**: Not a flashy moment -- a trust moment. The user thinks "this app actually understands how I use my phone." It directly addresses the Federighi objection and differentiates from any "nuke and pave" reorganizer.

**AI technique**: Spatial memory strength heuristic: score = frequency * log(days_in_current_position) * consistency_across_backups. Apps above a threshold are "anchors." During optimization, anchor positions are hard constraints in the Hungarian algorithm assignment. The stability penalty (lambda * displacement_cost) applies to all apps, but anchors have lambda = infinity. LLM explains why each app is anchored: "You've opened Safari from this exact position 2,100+ times. Moving it would be disorienting."

**Shareability**: 5/10 -- Not inherently viral, but the concept resonates emotionally. "This app knows I'd lose my mind if it moved Safari" is relatable content. Best shared as part of a larger before/after where the anchors are visibly preserved.

**Disorientation mitigation**: 10/10 -- This IS the disorientation solution. It should be the default behavior of every other feature on this list. Not a separate feature so much as a foundational principle made visible.

---

### #12. The App Obituary

**What the user sees**: For apps that haven't been opened in 6+ months, Unjiggle generates a humorous "obituary." "Duolingo (2019-2024): Downloaded with great ambition and a 47-day streak. Died of neglect when you discovered that 'cinco minutos por dia' was a lie. Survived by Google Translate, which you actually use." Each obituary is a short paragraph with the app's icon, install era, peak usage period, and cause of death. Collected in a "Digital Graveyard" section.

**The wow moment**: Reading the obituary for an app you forgot you had. The humor makes the cleanup feel fun rather than shameful. The format is perfect for screenshots.

**AI technique**: LLM receives: app name, category, description, estimated install era, last usage date, peak usage period (if Screen Time data available), and what replaced it (the app with highest embedding similarity that IS still used). Prompted to write in obituary style -- dry wit, specific details, gentle roasting. Each obituary is 2-3 sentences max.

**Shareability**: 10/10 -- This is pure content. Each obituary is a standalone tweet. "My Duolingo obituary from Unjiggle" would trend. The format is inherently funny and personal. This might be the most viral individual piece of content the app generates, though the Personality Mirror is the more complete feature.

**Disorientation mitigation**: 9/10 -- Obituaries are written for apps you don't use. Removing dead apps from the home screen doesn't affect spatial memory for apps you actively use. The humor makes users more willing to let go.

---

### #13. The Swipe Tax Calculator

**What the user sees**: Unjiggle calculates the physical cost of the current layout. "Your current layout requires an average of 3.2 swipes to reach any app. Your most-used app (Messages) is optimally placed (page 1, dock). But your #3 most-used app (Spotify) is on page 4 -- that's ~1,460 unnecessary swipes per year." A "Swipe Tax" number shows the total unnecessary swipes per year across all apps. After reorganization, the Swipe Tax drops dramatically: "You just saved yourself 8,400 swipes per year."

**The wow moment**: The concrete number. "8,400 unnecessary swipes per year" is specific enough to feel real and absurd enough to feel motivating. The per-app breakdown reveals surprising inefficiencies.

**AI technique**: Simple arithmetic: for each app, compute (page_number - 1) * daily_opens = daily_swipes_to_reach. Sum across all apps. Compare current layout vs. optimized layout. The per-app breakdown sorts by "wasted swipes" (frequency * excess_page_distance). No ML required -- pure math -- but the LLM formats the insights as a compelling narrative.

**Shareability**: 8/10 -- "I was wasting 8,400 swipes per year" is a tweetable stat. The absurdity of the number drives engagement. Compare with friends: "What's your swipe tax?"

**Disorientation mitigation**: 8/10 -- The feature itself is informational. The suggested fix (move high-frequency apps closer) is the least disorienting optimization possible -- it only moves the apps you use most to where you'd expect them.

---

### #14. The Vibe Check

**What the user sees**: Unjiggle applies CLIP or a multimodal model to all app icons simultaneously and generates an overall "vibe analysis" of each page. "Page 1 vibes: Corporate Blue (7 blue-and-white icons, all productivity). Page 3 vibes: Chaos Goblin (23 apps from 14 different categories with no organizing principle)." It also generates a composite "average icon" for each page by blending all the icons together -- creating an abstract artwork that represents the visual essence of that page.

**The wow moment**: The composite "average icon" images. They're visually fascinating -- abstract smears of color that somehow capture the character of each page. Seeing "Page 1 Average" as a clean blue square and "Page 5 Average" as a muddy brown mess tells the whole story instantly.

**AI technique**: CLIP embeddings on each icon, averaged per page, then decoded back to a description via LLM. The composite image: literally average the pixel values of all icons on a page, or use a style-transfer model to blend them. The "vibe label" is LLM-generated from the icon descriptions and categories. Could also cluster icons by CLIP embedding to show which pages have coherent visual identity vs. random noise.

**Shareability**: 9/10 -- The composite "average icon" images are weird, beautiful, and unique. "Here's what each of my home screen pages looks like as a single icon" is extremely shareable content. The vibe labels add humor.

**Disorientation mitigation**: 9/10 -- Pure analysis, no rearrangement. The insight might motivate the user to reorganize, but the feature itself moves nothing.

---

### #15. Natural Language Reorganization

**What the user sees**: A text field where the user types instructions in plain English: "Put all my social media on page 2 in a folder called 'Danger Zone.' Move my banking apps to a folder called 'Money' on page 1. I want my dock to be Phone, Safari, Messages, Spotify." Unjiggle interprets the instructions and generates the layout change as a preview. Multiple instructions can be chained. The user can iterate: "Actually, move Spotify to page 1 instead of the dock."

**The wow moment**: Describing your ideal layout in words and seeing it materialize. It feels like having a personal assistant organize your phone. The conversational iteration ("actually, move that...") makes it feel magical.

**AI technique**: LLM function-calling / structured output. The LLM receives: the current layout (as structured data), the user's instruction, and the available app list. It outputs a sequence of layout operations (move_app, create_folder, rename_folder, set_dock). The app validates the operations against layout constraints (page capacity, dock size, widget conflicts) and renders the preview. Multi-turn conversation maintained for iterative refinement.

**Shareability**: 6/10 -- The interaction is cool but harder to capture in a screenshot. Best shared as a screen recording. The result (a well-organized layout) is less inherently unique than other features.

**Disorientation mitigation**: 7/10 -- The user controls exactly what moves because they described it. No surprises. The preview step adds safety. But users might issue broad instructions ("reorganize everything") that cause significant change.

---

## Summary: The Feature Portfolio

| Rank | Feature | Shareability | Disorientation Safety | Primary AI | Effort |
|------|---------|:---:|:---:|---|---|
| 1 | Personality Mirror | 10 | 10 | LLM generation | Medium |
| 2 | Archaeology Layer | 9 | 8 | Heatmap + clustering | Low |
| 3 | Doppelganger Detection | 8 | 9 | Embeddings + LLM | Medium |
| 4 | Layout Genome | 9 | 7 | UMAP + collaborative filtering | High |
| 5 | Aesthetic Harmonizer | 10 | 3 | Color extraction + TSP | Medium |
| 6 | Habit Rewire | 8 | 6 | Bigram transition model + LLM | Medium |
| 7 | Context Scenes | 7 | 5 | Temporal clustering + LLM | High |
| 8 | One-Page Challenge | 9 | 4 | Pareto analysis | Low |
| 9 | Family Map | 7 | 10 | Set operations + LLM | Medium |
| 10 | AI Layout From Screenshot | 8 | 4 | Vision model + icon matching | High |
| 11 | Spatial Memory Anchoring | 5 | 10 | Frequency-tenure heuristic | Low |
| 12 | App Obituary | 10 | 9 | LLM creative writing | Low |
| 13 | Swipe Tax Calculator | 8 | 8 | Arithmetic + LLM narrative | Low |
| 14 | Vibe Check | 9 | 9 | CLIP + pixel averaging | Medium |
| 15 | Natural Language Reorg | 6 | 7 | LLM function calling | Medium |

---

## The Killer Combo: V1 Launch Strategy

Ship these three together for maximum viral impact with minimum engineering:

1. **Personality Mirror** (#1) -- The viral hook. Gets people talking, sharing, downloading.
2. **App Obituary** (#12) -- The content engine. Every obituary is a standalone tweet.
3. **Spatial Memory Anchoring** (#11) -- The trust foundation. Every reorganization respects muscle memory.

Then add **Archaeology Layer** (#2) and **Swipe Tax Calculator** (#13) as the "now do something about it" features that convert insight into action.

The Aesthetic Harmonizer (#5) and One-Page Challenge (#8) are the screenshot factories for the r/iOSsetups community.

---

## The Federighi Principle: How Every Feature Addresses Disorientation

Craig Federighi's concern is valid: moving apps disorients users. The solution is a three-layer approach:

1. **Insight features** (Personality Mirror, Vibe Check, Swipe Tax, Family Map) move nothing. They reveal patterns. Users share these freely because there's zero risk.

2. **Surgical features** (Archaeology Layer, Doppelganger Detection, App Obituary) only move apps the user doesn't actually use. Your spatial memory is for apps you open. Dead apps are invisible to muscle memory.

3. **Transformation features** (Aesthetic Harmonizer, One-Page Challenge, Context Scenes, Screenshot Import) make big changes but are opt-in, preview-first, and positioned as aspirational choices, not corrections.

**Spatial Memory Anchoring** is the connective tissue: it identifies your muscle-memory apps and protects them across ALL features. Even the most radical reorganization (Rainbow Flow, One-Page Challenge) preserves anchor positions.

The marketing message: "Unjiggle never moves the apps you actually use. It cleans up the apps you forgot you had."
