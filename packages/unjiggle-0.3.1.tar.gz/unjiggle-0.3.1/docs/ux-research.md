# UX Research: Mac App for iPhone Home Screen Reorganization

## Core Interaction Model

### Multi-Page Presentation: Hybrid Artboard + Horizontal Scroll (Figma Model)

Each home screen page is a discrete "artboard" arranged horizontally on an infinite canvas. The user can:
- **Zoom out** to see all pages at once (overview)
- **Zoom in** to focus on a single page
- **Scroll horizontally** with trackpad gestures
- **Pinch to zoom** between overview and detail

This is superior to alternatives:
- A **grid of pages** (like Apple Configurator) makes drag-and-drop between non-adjacent pages awkward
- A **tab/pagination model** (like iOS itself) hides context — can't see page 3 while working on page 1
- The artboard model preserves spatial memory ("social apps are to the left, work to the right")

### Three Zoom Tiers

| Level | What You See | Primary Action |
|-------|-------------|----------------|
| **Overview** (fit all) | All pages as small thumbnails | Reorder entire pages, see full layout |
| **Page** (1-2 pages) | Full detail of 1-2 pages | Drag apps between pages, arrange within |
| **Detail** (single page) | One page with app names, usage stats | Fine-tune position, edit folders, widgets |

### Drag-and-Drop Mechanics

**Single App**: Click and drag. Icon lifts with 1.1x scale + shadow. Ghost placeholder in original position.

**Multi-Select** (Mac's killer advantage):
- Click to select, Shift+Click for range, Cmd+Click for toggle
- Rubber-band selection (click-drag on empty space to lasso)
- Selected apps highlight with colored border
- Dragging any selected app moves entire group
- Overflow apps push to next page

**Folders**: Double-click to expand inline as overlay. Drag apps in/out. Drag one app onto another to create folder.

---

## Precedent App Analysis

### Apple Configurator 2 — Cautionary Example
- Small, fixed thumbnails in horizontal strip
- Stiff drag-and-drop, no animation, no snap feedback
- No undo, no before/after comparison
- Proves the concept but demonstrates purely utilitarian approach fails

### Figma — Gold Standard for Canvas Interaction
- Infinite canvas with zoom, scroll wheel zooms, trackpad pans
- Zoom-to-fit (Shift+1), zoom-to-selection (Shift+2)
- Frames/artboards as independent coordinate spaces
- Auto Layout maps to home screen grid constraints
- **Borrow**: canvas navigation, snapping. **Don't borrow**: layers panel complexity.

### Trello / Linear — Card Organization
- Columns map to pages, cards to apps
- Blue insertion line for drop feedback
- **Borrow**: insertion indicator, keyboard bulk-move patterns

### DaisyDisk / GrandPerspective — Making the Invisible Visible
- Spatial visualization of abstract data
- The "aha" of seeing something you've never seen before
- **Borrow**: category color overlay, staging/unsorted tray concept

### Apple Photos / Lightroom — Non-Destructive Organization
- Adding to album creates reference, doesn't move from library
- Smart Collections (auto) + regular Collections (manual)
- **Borrow**: smart/manual page duality, App Library as "source"

### iTunes / Music.app — Source List Navigation
- Left sidebar: different views of same content
- **Borrow**: sidebar with Pages, Dock, Library, Suggestions

---

## Key UX Decisions

### Preview vs. Commit

**Explicit "Apply to iPhone" step with live preview on canvas.**

1. **Working state**: Canvas reflects proposed layout. Changes instant on-screen.
2. **Comparison mode**: Toggle current vs. proposed side-by-side.
3. **Apply**: Prominent "Apply to iPhone" button. Only moment that touches device.

This matches Figma (edit freely, "Present" to see result) and Time Machine (browse freely, "Restore" to commit). Live sync is psychologically dangerous — users feel anxious if every drag rearranges their phone.

### Undo/History

Full undo stack (100+ levels) + named snapshots:
- Save current layout ("Before reorganizing," "Work mode," "Vacation mode")
- Restore any snapshot instantly
- Compare two snapshots side-by-side
- Borrowed from Photoshop History panel and Figma Version History

### Templates

Positioned as "inspiration" not "configuration":
- Gallery of curated layouts ("The Minimalist," "The Power Grid," "Digital Wellbeing")
- Applying a template creates proposed layout, customizable before applying
- Templates are adaptive (rules, not fixed positions)
- Community-shareable (future)

### Before/After Comparison — THE MOST IMPORTANT FEATURE

Slider-based split view (like photo editing apps):
- Left side: current layout (Before)
- Right side: proposed layout (After)
- Drag divider to reveal more of either side
- Summary statistics between them:
  - "Reduced from 7 pages to 3"
  - "Your most-used apps are now on page 1"
  - Organization score rises from old to new value

### Onboarding / First Experience — 60-Second Magic

1. Connect iPhone (cable) -> "Trust" tap
2. App reads layout, displays on canvas with "analyzing" animation
3. Presents one-click suggestion: "Your most-used apps are scattered across 6 pages. Consolidate to pages 1 and 2?"
4. Before/after preview
5. Accept, modify, or dismiss

Goal: dopamine hit within 60 seconds. DaisyDisk model — immediate visualization, no configuration needed.

### Trust

1. Always show what will change before it changes
2. Automatic backup before every sync
3. Incremental changes instead of "reorganize everything"
4. Transparent about limitations
5. Dry-run mode (preview overlay on phone without actually moving)

---

## Visual Design Direction

### Tone: Calm Professionalism (Things 3 / Bear)
- Clean, confident, minimal chrome
- Subtle animations that reward interaction
- Not playful (no confetti), not sterile (not enterprise)
- Like "cleaning your room" — organized workspace feeling

### Dark/Light Mode
- Default to system appearance (non-negotiable)
- Canvas background: neutral mid-tone in both modes (like Figma's gray)
- iPhone page representations clearly framed against canvas

### iPhone Frame
- Stylized rounded rectangle with subtle shadow
- NOT photorealistic (dates the app, wastes pixels)
- Status bar with simplified clock at detail zoom
- Minimal at overview zoom, more definition at detail zoom

### Micro-Interactions

**App pickup**: Scale to 1.15x with spring animation + soft shadow. Nearby apps shift to show drop positions.

**App drop**: Spring into grid with slight overshoot bounce (damping ~0.7). Displaced apps slide smoothly.

**Page transition**: Auto-scroll with ease-in-out when dragging to page edge. "Entering page 3" label fades in.

**Apply to iPhone**: Progress animation — proposed layout miniaturizes and "flies" toward iPhone icon, or radial progress.

**Snap**: Subtle haptic pulse on Force Touch trackpads + faint snap sound.

### Category Color Coding (Optional)

| Category | Color |
|----------|-------|
| Social Networking | Blue |
| Productivity | Green |
| Entertainment | Purple |
| Games | Orange |
| Health & Fitness | Red |
| Finance | Teal |
| Utilities | Gray |
| Photo & Video | Pink |

Colors muted/desaturated (Notion/Linear style). Powerful at overview zoom — instantly see that "productivity page" has entertainment apps mixed in.

---

## The "Magic Moment"

### The Before/After Reveal
1. User finishes reorganizing or accepts auto-suggestion
2. Clicks "Compare"
3. Screen splits with animation: Before (left) / After (right)
4. Summary statistics appear
5. Organization score animates from old to new value

### Organization Score (0-100)

| Component | Weight |
|-----------|--------|
| Accessibility (most-used on page 1?) | 40% |
| Coherence (similar apps grouped?) | 30% |
| Efficiency (swipes to reach any app?) | 20% |
| Simplicity (fewer pages, good folders?) | 10% |

Labels: "Cluttered" (0-30), "Getting There" (31-60), "Well Organized" (61-85), "Perfectly Tuned" (86-100)

Never judgmental: "You could save 12 swipes per day" not "Your layout is inefficient."

### The "Wow" Moments
1. **First scan**: Seeing ALL pages laid out on Mac for the first time
2. **Category overlay**: Visual pattern of how apps are distributed
3. **Usage heatmap**: Most-used app buried on page 4, suddenly visible
4. **One-click organize**: 200+ apps smoothly animate into suggested layout
5. **Apply and verify**: Picking up iPhone and seeing new layout there

---

## Edge Cases

### Heavy Users (500+ Apps)
- Artboards shrink proportionally at overview zoom
- Minimap in corner (like VS Code)
- Search/filter bar to highlight specific app
- Suggest App Library strategy: "Keep top 2 pages, move rest to App Library"

### Minimalists (20 Apps)
- Default to detail zoom (single page)
- Emphasize widget arrangement and aesthetic layout
- Wallpaper-aware placement suggestions

### Widgets
- Rendered at proportional size, distinct visual treatment
- Snap to valid positions only (show prohibition indicator for invalid)
- Widget gallery sidebar for adding/resizing
- V1: move only, don't create

### Folders
- Represented as grouped icon (3x3 mini-grid preview)
- Double-click to expand inline
- Drag apps in/out, one-onto-another creates new folder
- Right-click to rename
- Drag all apps out to dissolve

### App Library
- Sidebar section showing all apps not on home screen
- Drag from Library to page (add to home screen)
- Drag from page to Library (remove from home screen, don't uninstall)
- Search and category filtering

---

## Window Layout

```
+----------------------------------------------------------+
| Toolbar: [Zoom controls] [View mode] [Score: 72] [Apply] |
+----------+---------------------------------------+-------+
| Sidebar  |           Main Canvas                 | Insp. |
| (~200px) |     (flexible, zoomable, pannable)    |(~240px|
|          |                                       |toggle)|
| Pages    |    [Page 1]  [Page 2]  [Page 3]      |       |
|  - P1    |                                       | Name  |
|  - P2    |                                       | Cat.  |
| Dock     |                                       | Usage |
| Library  |       [Dock: 4 slots]                 | Last  |
| Folders  |                                       | Open  |
| Suggest  |                                       |       |
+----------+---------------------------------------+-------+
```

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Cmd+Z / Cmd+Shift+Z | Undo / Redo |
| Space + Drag | Pan canvas |
| Cmd+0 | Zoom to fit all |
| Cmd+1 through Cmd+9 | Jump to page N |
| Cmd+F | Search apps |
| Delete | Move selected to App Library |
| Cmd+G | Group into folder |
| Cmd+Shift+G | Ungroup folder |
| Arrow keys | Move selected within grid |
| Cmd+S | Save snapshot |
| Cmd+Return | Apply to iPhone |
