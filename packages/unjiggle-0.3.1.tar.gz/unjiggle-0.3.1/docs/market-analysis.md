# Market Analysis: iPhone Home Screen Reorganizer

## Market Size & Demand

### iPhone User Base
- **Global**: ~1.46 billion active iPhones (2025)
- **US**: ~150-160 million (57% smartphone market share)
- **Key demographic**: Gen Z and Millennials (16-35) highest customization engagement

### Customization Behavior
- **iOS 14 inflection point** (2020): Widgetsmith hit #1, 30M+ downloads. Proved massive latent demand.
- Pinterest reported 190% increase in "iPhone home screen ideas" searches (2020)
- Reorganization is periodic: most users reorganize 2-4 times per year

### Community Size
- r/iOSsetups: ~95,000 members (active)
- r/iOSthemes: ~185,000 members
- r/widgetsmith: ~15,000 members
- TikTok/Instagram "#homescreen": billions of combined views
- YouTube home screen setup videos: 500K-2M+ views routinely

**Assessment**: Real community, but hobbyist/enthusiast niche, not mass-market pain point. Most users tolerate messy home screens rather than seeking solutions.

### Historical Signal
iTunes used to let you rearrange from desktop. Apple removed it in iTunes 12.7 (2017) and never brought it back. Suggests Apple sees it as low-priority, but users genuinely miss it.

---

## Competitive Landscape

### Direct Competitors

| App | Home Screen Feature | Price | Status |
|-----|-------------------|-------|--------|
| AnyTrans (iMobie) | Had manager, de-emphasized | $49.99/yr or $79.99 lifetime | Active |
| iMazing (DigiDNA) | No layout feature | $44.99/device or $54.99/yr | Active |
| 3uTools (Windows only) | Basic management | Free | Active, China-based |
| Apple Configurator 2 | MDM profiles | Free | Enterprise tool |

### Adjacent Customization Apps (iOS Revenue)

| App | What It Does | Estimated Revenue |
|-----|-------------|-------------------|
| Widgetsmith | Custom widgets | $1-2M/yr (down from peak) |
| Color Widgets | Widget themes | $5-10M+/yr |
| Aesthetic Kit | Icons + wallpapers + widgets | High grossing |
| Brass | Icon packs | Smaller niche |

**iOS customization market**: Likely $50-100M+/yr globally. But a Mac layout tool is a different product.

### Why Past Attempts Failed

| Tool | What Happened | Why |
|------|--------------|-----|
| iTunes | Apple removed feature (2017) | Low priority for Apple |
| AnyTrans | De-emphasized feature | iOS updates kept breaking it; maintenance > revenue |
| iCareFone | Removed feature | Same as AnyTrans |
| 3uTools | Still has it (free) | Not commercially successful for this feature |

**Pattern**: Feature tried and abandoned multiple times. Always a side feature, never purpose-built. Maintenance cost exceeded incremental revenue.

---

## Business Model

### Comparable Mac Utility Pricing

| App | Price | Model |
|-----|-------|-------|
| CleanMyMac X | $39.95/yr or $89.95 | Sub or perpetual |
| Bartender | $16 | One-time |
| Raycast | Free + $8/mo Pro | Freemium/sub |
| Alfred | Free + £34 Powerpack | Freemium + one-time |
| Pastebot | $12.99 | One-time |

### Recommended Pricing

- **Free tier**: View layout, organization score, basic analytics
- **One-time purchase**: $12.99 for full reorganization features
- **Optional**: Theme packs $2.99 each or $4.99/yr for AI suggestions

**Subscription doesn't work**: Usage is episodic (2-4x/year). Users would feel ripped off paying monthly. Churn would be brutal.

**$12.99 is the sweet spot**: Comparable to Bartender ($16), Pastebot ($13). Single-purpose utility price.

### Willingness to Pay Assessment

**Low to moderate.** Problem is real but not acute. Most people can do it manually (it's annoying, not impossible).

Audience willing to pay:
- People setting up new iPhone perfectly
- Customization enthusiasts who change layouts frequently
- Power users with 150+ apps

**Estimated addressable**: 500K-2M globally. At $12.99 with 1-3% conversion: **$50K-$500K/yr**.

---

## Distribution

### Dual Distribution Strategy: Mac App Store + Direct Download

USB device communication requires access to usbmuxd (a system Mach service), which the Mac App Store sandbox definitively blocks. Investigated and ruled out: SMAppService privileged helpers (must also be sandboxed on macOS 14.2+), CoreDevice framework (internal-only), `com.apple.security.device.usb` (IOKit-level, wrong layer), DriverKit/NetworkExtension (wrong abstraction). Even Apple Configurator uses private entitlements unavailable to third parties. No iPhone management tool has ever shipped on the Mac App Store.

**However**, a sandboxed app CAN read files the user explicitly selects via `NSOpenPanel`. iPhone backups (including `IconState.plist`) live at `~/Library/Application Support/MobileSync/Backup/`. This enables a reduced-functionality App Store edition.

| Factor | Mac App Store Edition | Direct Download Edition |
|--------|----------------------|------------------------|
| **Layout source** | User-selected Finder backup | Live USB via libimobiledevice |
| **Core features** | Visualize, score, edit, suggest | All of Lite + one-click apply |
| **Apply changes** | Export modified backup, user restores via Finder | Direct write via `set_icon_state()` |
| **Discovery** | App Store search, editorial features | SEO, Product Hunt, word of mouth |
| **Trust** | Apple-reviewed, one-click install | Notarized, but Gatekeeper warning |
| **Revenue share** | 30% (15% small business) | 5-10% (Paddle/LemonSqueezy) |
| **Pricing** | Free (acquisition funnel) | $12.99 one-time |
| **Updates** | App Store auto-update | Sparkle framework |

**Verdict: Both.** The Mac App Store edition is a free top-of-funnel acquisition tool. Users discover it, see their messy home screen scored and visualized, then upgrade to the direct download Pro edition for seamless USB. This is the Transmit/BBEdit model — App Store for reach, direct for power features and better margins.

### Could This Be Part of a Larger App?

An "iPhone Manager for Mac" broadens value and justifies $29.99-$49.99. But then you're competing with iMazing (well-established, well-funded). The purpose-built approach is more differentiated.

---

## Timing & Trends

### iOS 18 Impact (2024)

**Mixed, leaning negative for "need" but positive for "complexity":**
- More customization options = more to organize = more desire for Mac tool
- Apple made on-device customization much easier (reduced the gap)
- Free placement makes Mac precision more valuable (fiddly on touchscreen)

### Apple's Customization Trajectory
- iOS 14: Widgets
- iOS 16: Lock Screen customization
- iOS 17: StandBy, interactive widgets
- iOS 18: Free placement, tinting, Control Center

**Trend**: Apple steadily opening up customization. Tailwind for customization culture, headwind for third-party tools.

### Sherlock Risk: HIGH

Apple is on clear trajectory of improving home screen management. Specific risks:
- Could bring back desktop management
- Could add native "themes" or "layouts"
- Apple Intelligence could offer smart reorganization

**Mitigating signal**: Federighi rejected AI home screen in Jan 2026. Not imminent, but 2-3 year risk is real.

---

## Adjacent Opportunities

### Theme Marketplace (Biggest Opportunity)
- Designers create/sell home screen "theme packs" (arrangement + wallpaper + widgets)
- Take 30% cut
- Challenge: generating supply
- Revenue potential: larger than standalone tool if marketplace works

### Social/Sharing
- Share layouts as downloadable configs
- "Setup of the week" features
- Import layouts from screenshots using AI/OCR
- Taps into r/iOSsetups community

### Shortcuts Integration
- Automated layout switching (time, location, Focus mode)
- "Work layout" vs "Weekend layout"
- Genuinely novel differentiator

### Enterprise/Education (MDM-Lite)
- Parents configure kid's phone from Mac
- Teachers set up class iPads
- Challenge: Apple Configurator already does this (free)

---

## Risk Assessment

| Risk | Severity | Likelihood | Mitigation |
|------|----------|------------|------------|
| Apple builds it natively | Fatal | Medium-High (2-3yr) | Move fast, build marketplace moat |
| Technical access blocked | High | Medium | Multiple access methods, community adapts |
| Small TAM / not enough pain | High | Medium-High | Validate with landing page first |
| Subscription fatigue | Medium | High | One-time pricing |
| Competitors already failed | Medium | Already happened | Understand why; solve those problems |
| Maintenance burden | Medium | High | Budget 2-4 weeks/yr for iOS updates |

---

## Summary

### Bull Case
1.46B iPhones, proven customization demand, no good desktop tool exists, AI suggestions are novel, theme marketplace could create network effects.

### Bear Case
Past attempts failed and were abandoned, Apple building features natively (Sherlock risk), pain isn't acute enough for purchases, every iOS update risks breakage.

### Bottom Line

**$100K-$500K/yr niche business standalone, with significant platform risk.** The bigger opportunity is using the tool as a hook into a theme marketplace with network effects.

**Recommended validation**: Landing page + ads to r/iOSsetups. Target 1,000 email signups before writing code. If you can't get 1,000 signups, the market signal is clear.
