# Unjiggle Viral Strategy: Making the Output Inherently Shareable

## The Core Insight: Why Current Output Isn't "Wow"

The current plan produces a slider-based before/after with a 0-100 organization score. The problem: **a score is abstract, and a cleaner grid looks like... a slightly different grid.** Nobody screenshots "72 -> 89." The output needs to be a *mirror* -- it needs to tell users something about themselves they didn't know, wrapped in a visual format that is immediately legible to anyone scrolling a feed.

Every viral utility moment follows the same formula:

```
VIRAL OUTPUT = Personal Data Reveal + Surprising Narrative + Visual Format Optimized for Screenshots
```

- Spotify Wrapped: your listening data + "you're in the top 1% of Taylor Swift listeners" + story-card format
- Widgetsmith: your aesthetic choices + visible identity expression + home screen screenshot
- HaveIBeenPwned: your email + "exposed in 7 breaches" shock + simple number
- ChatGPT: your prompt + unexpectedly good output + screenshot of the conversation

Unjiggle's equivalent: **your app collection is a behavioral fingerprint.** 150+ apps, organized (or not), reveal habits, priorities, contradictions, and personality. The reorganization itself is the utility -- but the *diagnosis* is the viral moment.

---

## 1. The Visual Output Format: "Home Screen Report Card"

### Not a slider. Not a side-by-side. A single, portrait-oriented card.

The shareable artifact should be a **single image** (1080x1920, Instagram Story / TikTok native) that contains:

```
+------------------------------------------+
|                                          |
|          [Unjiggle logo small]          |
|                                          |
|    YOUR HOME SCREEN PERSONALITY          |
|                                          |
|    +---------------------------------+   |
|    |                                 |   |
|    |   THE DIGITAL HOARDER           |   |
|    |   (or archetype name)           |   |
|    |                                 |   |
|    |   [Miniaturized "before" grid   |   |
|    |    with category color overlay  |   |
|    |    -- the chaos is the visual]  |   |
|    |                                 |   |
|    +---------------------------------+   |
|                                          |
|    --- THE NUMBERS ---                   |
|                                          |
|    173 apps across 8 pages               |
|    Your most-used app is on page 5       |
|    47 apps you haven't opened in 90 days |
|    3 apps do the same thing              |
|    You swipe past 94 apps to reach       |
|      your #1 most-used app               |
|                                          |
|    CHAOS SCORE: 23/100                   |
|    [filled bar visualization]            |
|                                          |
|    unjiggle.app                         |
|                                          |
+------------------------------------------+
```

### Why this format works:

1. **Portrait orientation**: Native to Stories, TikTok, tweets with images. No cropping needed.
2. **The miniaturized grid IS the visual**: A color-coded 8-page home screen layout is immediately recognizable to any iPhone user. The chaos is visually obvious and funny.
3. **The archetype is the hook**: People share identity labels. "I'm a Digital Hoarder" is a statement about yourself.
4. **The stats are the surprise**: "47 apps you haven't opened in 90 days" is the kind of fact that makes you say "wait, really?" out loud.
5. **The score is low on purpose**: A low chaos score (or high chaos score, depending on framing) creates urgency and humor. Nobody shares "I scored 95." Everybody shares "I scored 23."
6. **Branded but not obnoxious**: Small logo, URL at bottom. The content sells, not the brand.

### The Second Card: The "After"

After the user accepts the reorganization, generate a second card:

```
+------------------------------------------+
|                                          |
|    BEFORE              AFTER             |
|    [mini grid,         [mini grid,       |
|     chaotic colors]     organized        |
|                         color blocks]    |
|                                          |
|    8 pages     --->    3 pages           |
|    Score: 23   --->    Score: 87         |
|                                          |
|    "Saved 47 swipes per day"             |
|                                          |
|    [Applied with Unjiggle]              |
|    unjiggle.app                         |
|                                          |
+------------------------------------------+
```

This is the *transformation* card. The before/after mini-grids use the same category color overlay, so the visual difference is dramatic: scattered rainbow vs. organized color blocks. This is the equivalent of a messy room / clean room photo -- instantly legible.

---

## 2. Narrative Elements: Personal and Surprising

### The "Home Screen Personality" System (Spotify Wrapped Model)

Assign every user one of 12 archetypes based on their actual layout data. These must be:
- Specific enough to feel accurate
- Funny enough to share
- Relatable enough that friends argue about theirs

#### The 12 Home Screen Archetypes

| Archetype | Trigger Condition | Description |
|-----------|------------------|-------------|
| **The Digital Hoarder** | 150+ apps, 6+ pages, no folders | "You've never met an app you wouldn't download. Your home screen is an archaeological dig." |
| **The Folder Addict** | 10+ folders | "Everything has a folder. Your folders have folders. You file your apps like tax returns." |
| **The One-Pager** | Most apps in App Library, 1-2 pages | "Minimalism isn't a lifestyle, it's a personality trait. You have 4 apps on your home screen and judge everyone else." |
| **The Junk Drawer** | No organizational logic, random distribution | "Page 1 has a banking app next to a game next to a weather app. There is no system. You are the system." |
| **The Creature of Habit** | Top 5 apps all on page 1, rest untouched | "You use the same 5 apps every day. The other 120 are paying rent for nothing." |
| **The Aesthetic** | Custom widgets, themed wallpaper, curated page 1 | "Your home screen is a mood board. Function follows form. Your weather widget matches your wallpaper." |
| **The Work-Life Blender** | Slack and Netflix on same page, no separation | "There is no boundary between work and play. Your Slack notifications arrive between TikTok videos." |
| **The Ghost Town** | 40+ apps unused in 60 days | "Half your apps are digital ghosts. They're installed but forgotten, haunting your storage." |
| **The Power User** | High app count + strong organization + folders | "You have 200 apps AND they're organized. You are the 1%. Everyone else should study your layout." |
| **The Default Derek** | Layout barely changed from factory + App Store defaults | "You set up your phone in 2021 and never looked back. The apps are where Apple put them." |
| **The Social Butterfly** | 8+ social/messaging apps on page 1 | "Your page 1 is a communications dashboard. You have 4 messaging apps that all do the same thing." |
| **The App Rotator** | Frequent installs/uninstalls, high churn | "You install apps like you're swiping on Tinder. Most don't make it past the first date." |

#### Why archetypes go viral:

Spotify Wrapped proved this. The archetype is not the product -- it's the **social object**. People don't share "Spotify reorganized my playlists." They share "I'm in the top 0.5% of Radiohead listeners." The archetype gives people a label to post, argue about, and compare with friends.

### Surprising Stats (The "Wait, Really?" Moments)

The algorithm should surface 3-5 of these, selected for maximum surprise:

| Stat | Why It's Surprising |
|------|-------------------|
| "Your #1 most-used app (Instagram) is buried on page 4" | Reveals irrational behavior you do every day without noticing |
| "You swipe past 94 apps to reach Messages" | Quantifies invisible friction |
| "47 apps haven't been opened in 90+ days" | Digital hoarding made visible |
| "You have 3 weather apps" | Reveals duplicates you forgot about |
| "Your home screen hasn't changed meaningfully in 14 months" | Quantifies inertia |
| "73% of your page 1 apps are NOT in your top 10 most-used" | Reveals the gap between layout and behavior |
| "Your thumb travels an estimated 2.3 miles per year finding apps" | Physical metaphor for digital inefficiency |
| "You have more games (23) than productivity apps (8) but your games are hidden on page 6" | Reveals contradictions in self-image |
| "Your most productive app arrangement would save you 12 swipes per day -- that's 4,380 swipes per year" | Small daily inefficiency, large annual number |

The best stat is the one that reveals a **contradiction between how users think they use their phone and how they actually use it**. This is the same psychology behind Screen Time's weekly report (people are genuinely shocked by their own usage numbers).

---

## 3. Three Example Viral Posts

### Post 1: The Shock/Humor Post (Twitter/X)

```
just found out my most-used app is on page 5 and I have 47 apps
I haven't opened since 2024

apparently I'm a "Digital Hoarder"

this app just exposed my entire life

[IMAGE: Home Screen Report Card showing 173 apps, 8 pages,
archetype "The Digital Hoarder", chaos score 23/100,
with the color-coded chaos grid]
```

**Why this works**: Self-deprecating humor. The user is laughing at themselves. The image is immediately legible (colorful chaos grid + low score). The archetype label is quotable. Other people want to find out what theirs is.

### Post 2: The Transformation Post (Instagram/TikTok)

```
before / after letting AI reorganize my iPhone

173 apps. 8 pages. Chaos score: 23.

one click later: 3 pages. Score: 87.

I've been living wrong.

[IMAGE: Before/After card showing chaotic color grid vs.
organized color blocks, with the page count and score change]
```

**Why this works**: Dramatic visual transformation. The before/after format is one of the most proven viral formats on the internet (fitness, home renovation, organization, art). The numbers tell a clear story. "I've been living wrong" is relatable and funny.

### Post 3: The Challenge/Comparison Post (Any Platform)

```
my home screen chaos score is 31 and I'm a "Junk Drawer"

I refuse to believe anyone's is worse

drop yours

unjiggle.app

[IMAGE: Report Card with archetype "The Junk Drawer"
and the chaotic mini-grid visualization]
```

**Why this works**: Creates a challenge/competition loop. People will reply with their own scores and archetypes. This is the HaveIBeenPwned dynamic -- "my number is worse than yours" becomes a game. The call-to-action is implicit: you need to go get your score to participate.

---

## 4. Minimum Viable Transformation That Looks Dramatic

The visual trick: **category color coding makes any reorganization look 10x more dramatic than it is.**

### The Insight

Two grids of gray app icons look almost identical whether organized or not. But overlay category colors (Social = Blue, Productivity = Green, Entertainment = Purple, Games = Orange, etc.) and suddenly:

- **Before**: A Jackson Pollock painting. Random splashes of color across 8 pages. Visually chaotic, immediately reads as "mess."
- **After**: Clean color blocks. Blue cluster on one page, green cluster on another. Visually organized, immediately reads as "order."

This means even a modest reorganization (moving 20-30 apps) looks like a *complete transformation* when rendered with color coding. The user doesn't need to understand the specific apps -- the color pattern tells the story instantly.

### What the minimum viable transformation actually does:

1. **Consolidates the top 10 most-used apps to page 1** (biggest impact, fewest moves)
2. **Groups same-category apps onto the same page** (creates the color-block visual)
3. **Moves unused apps (60+ days) to a "cold storage" page or App Library** (reduces page count)
4. **Fills dock with top 4 frecency apps** (immediate daily improvement)

This is maybe 30-40 app moves total. But the before/after color visualization makes it look like a gut renovation. The page count drop (8 pages to 3 pages) is the headline number that sells the transformation.

### Why "pages reduced" is the killer metric:

- It's concrete and simple: "8 pages to 3 pages"
- Everyone understands it immediately
- It's visually obvious in the before/after
- It implies the apps are still there (not deleted), just better organized
- The number is almost always dramatic for heavy users (150+ apps)

---

## 5. Focus: Chaos Diagnosis (Before) vs. Clean Result (After)

### Lead with the chaos. Close with the transformation.

**The diagnosis is the viral moment. The transformation is the product moment.**

Here's why:

| Aspect | Chaos Diagnosis (Before) | Clean Result (After) |
|--------|------------------------|---------------------|
| **Emotional trigger** | Surprise, humor, self-recognition | Satisfaction, aspiration |
| **Shareability** | High -- self-deprecating, relatable, funny | Medium -- aspirational but less personal |
| **Engagement** | Creates conversation ("mine is worse!") | Creates desire ("I want that") |
| **Virality driver** | Identity (who am I?) | Utility (what can I do?) |
| **Audience needed** | Anyone with an iPhone | People who already want to reorganize |

**The chaos diagnosis reaches people who didn't know they had a problem.** That's the top-of-funnel moment. A clean "after" only resonates with people who already cared about organization.

The ideal viral loop:

```
1. User sees friend's "Digital Hoarder" card on social media
2. Thinks: "I wonder what mine would be"
3. Downloads Unjiggle (free App Store edition)
4. Gets their own diagnosis -- surprised, amused
5. Shares their card
6. THEN sees the reorganization suggestion
7. Wants the transformation -> downloads Pro
```

The chaos diagnosis is the acquisition hook. The transformation is the conversion event.

### The Two-Card System

**Card 1 (shareable, viral, top-of-funnel)**: Your Home Screen Personality report card. Archetype + stats + chaos score + color-coded chaos grid. This is what people post.

**Card 2 (shareable, conversion-driving, bottom-of-funnel)**: The before/after transformation. Side-by-side color grids + page reduction + score jump. This is what convinces fence-sitters.

Both cards should be one-tap exportable. "Share to Stories" button that generates the correctly-sized image with no extra steps.

---

## 6. The "Home Screen Personality" Deep Dive

### Why This Is the Entire Growth Strategy

The archetype system isn't a nice-to-have feature. It IS the growth engine. Here's the full system:

### Tier 1: The Archetype (Identity)

One of 12 types assigned based on layout analysis. This is the headline of the report card. It's what people put in their posts. It's the Spotify Wrapped equivalent.

### Tier 2: The Sub-Stats (Specificity)

3-5 personalized statistics that support the archetype assignment. These make it feel like the analysis is deep, not just a random label. Examples:

For "The Digital Hoarder":
- "173 apps installed. Industry average: 80."
- "8 home screen pages. Average iPhone user: 3."
- "47 apps unopened in 90+ days."
- "Your newest app (downloaded 2 days ago) is already on page 7."

For "The Work-Life Blender":
- "Slack and Netflix are 2 apps apart on page 1."
- "You have no separation between work and personal apps."
- "Your Calendar is on page 4 but your Games are on page 1."
- "Suggested: a 'Work' page would reduce context-switching by 60%."

### Tier 3: The Comparison (Social Proof)

- "Only 8% of Unjiggle users are Digital Hoarders"
- "The average Hoarder has 156 apps. You have 173. You're more Hoarder than most Hoarders."
- "Most similar to you: @friend_who_shared (if social features exist)"

This tier makes the archetype feel like membership in a group, which increases sharing.

### Tier 4: The Prescription (Conversion)

- "Unjiggle suggests reducing to 3 pages. Want to see what that looks like?"
- "Your optimized layout would save 12 swipes per day."
- "One-click reorganize available in Unjiggle Pro."

This tier converts the viral moment into product usage.

---

## Implementation Priority

### Phase 1: The Viral Engine (Ship First)

Even before the full reorganization algorithm is complete, build:

1. **Layout analysis and stat generation** -- parse IconState.plist, compute all the "surprising stats"
2. **Archetype assignment** -- rule-based classification from layout data
3. **Report card image generation** -- the shareable portrait card
4. **Category color overlay** -- the visual that makes chaos visible
5. **One-tap share** -- generate image, open share sheet

This can ship as the FREE App Store edition with zero reorganization features. It's purely diagnostic. And it's the most viral part of the product.

### Phase 2: The Transformation (Convert)

Then layer on:
1. Before/after visualization with color coding
2. One-click reorganization suggestions
3. The transformation card (second shareable image)
4. Pro upsell for USB one-click apply

### Phase 3: The Social Layer (Retain/Expand)

1. Aggregate stats ("most common archetype this month")
2. Leaderboards ("lowest chaos score")
3. Shareable layout configs
4. "Reorganize challenge" seasonal events (like Spotify Wrapped's annual release)

---

## The Anti-Patterns to Avoid

1. **Don't lead with the score alone.** "72/100" means nothing. "You're a Digital Hoarder with 47 ghost apps" means everything.

2. **Don't make the "after" generic.** "Move Salesforce to a Work folder" is boring because it's what the user would have done themselves. The suggestion needs to feel like it saw something the user couldn't see -- like the category color overlay revealing hidden patterns.

3. **Don't require the full product to get the viral moment.** The diagnosis should be available in the free App Store edition. The share button should appear before the user ever sees reorganization features.

4. **Don't make sharing require effort.** The report card image should be generated automatically after analysis. One tap to share. Pre-written caption suggested. The user should be able to share in under 3 seconds.

5. **Don't make it mean.** "Your home screen is a disaster" feels judgmental. "You're a Digital Hoarder" feels like a personality quiz. Same information, different framing. The tone should be amused, not critical.

---

## The Litmus Test

Before shipping any shareable output, ask:

> "Would I screenshot this and text it to a friend with zero context, and would they immediately understand it and want to get their own?"

If the answer isn't an immediate yes, the format isn't right yet.

The report card with the color-coded chaos grid, the archetype label, and 3 surprising stats passes this test. A slider-based before/after comparison does not.
