# Unjiggle AI Interaction Model

## The Core Experience

The product is not a score with suggestions. The product is an AI that walks you through reorganizing your phone, showing you what each change looks like in real-time. You just say yes or no.

Think of it like an AI interior designer who rearranges your room, but you can see the result before they move a single piece of furniture. Except the furniture goes back if you don't like it.

## The Interface

A split view on your Mac:

```
+---------------------------+---------------------------+
|                           |                           |
|     YOUR PHONE NOW        |    YOUR PHONE AFTER       |
|     (current layout)      |    (live preview)         |
|                           |                           |
|     [real app icons]      |    [real app icons]       |
|     [real positions]      |    [proposed positions]   |
|     [color-coded]         |    [color-coded]          |
|                           |                           |
+---------------------------+---------------------------+
|                                                       |
|  AI OBSERVATION #1 of 7:                              |
|                                                       |
|  "You have 47 apps on pages 4-8 that you navigate     |
|   by search, not memory. None of them are in your     |
|   top 10 most-accessed apps. Right now they're         |
|   scattered across 5 pages with no grouping logic.     |
|                                                       |
|   I can consolidate them into 2 organized pages by     |
|   category: a Social + Communication page and a        |
|   Utilities + Finance page. This would take you from   |
|   8 pages to 5."                                       |
|                                                       |
|  The preview on the right shows what this looks like.  |
|                                                       |
|  [Apply This Change]  [Skip]  [Adjust...]             |
|                                                       |
+-------------------------------------------------------+
```

The right panel updates IN REAL-TIME as the AI describes each change. You can see exactly what moves where before committing. The left panel stays fixed as your "before" reference.

## The AI Walkthrough (Stepwise)

The LLM analyzes the full layout and generates a sequence of observations + recommendations. Each one is independent and skippable. The preview updates live as you accept/reject each step.

### Example Session

**Step 1: The Archaeology**
> "You have 12 apps that haven't been updated in over 2 years and 8 apps from companies that no longer exist. These are digital fossils. Moving them to App Library would clear 20 slots across 3 pages."
>
> [Preview shows: pages 6-8 disappearing, 8 → 5 pages]
>
> [Apply] [Skip] [Show me which apps]

**Step 2: The Duplicates**
> "You have 3 weather apps (Weather, Dark Sky, CARROT), 4 note-taking apps (Notes, Notion, Bear, Drafts), and 2 authenticators (1Password, Salesforce Authenticator). For each group, I'd keep your most-used one on the home screen and move the others to App Library."
>
> [Preview shows: 7 apps removed from visible pages, cleaner grid]
>
> [Apply] [Skip] [Let me choose which to keep]

**Step 3: The Dead Zone Cleanup**
> "Pages 3-5 are a mix of everything: social apps next to banking next to kids' games next to developer tools. I can group them by how you actually use them: a 'Family' page (kids apps + shared services), a 'Work' page (Slack, Salesforce, Notion, Authenticator), and a 'Life' page (fitness, food, entertainment)."
>
> [Preview shows: 3 scattered pages → 3 themed pages, color-coded]
>
> [Apply] [Skip] [Rename the groups] [Adjust which apps go where]

**Step 4: Page 1 Optimization** (only if trust is established)
> "Your page 1 has Salesforce and Authenticator taking up 2 of 24 slots. You probably don't launch Salesforce from the home screen more than once a day. Moving them to the Work page and bringing up Spotify and Messages (which are currently on page 2) would put your actual daily drivers in thumb range."
>
> [Preview shows: page 1 with usage-aligned apps, subtle repositioning]
>
> [Apply] [Skip] [I like my page 1 as-is]

**Step 5: The Folder Intelligence**
> "Your 'L BV' folder has Uber, Lyft, and 3 other transport apps. I'd rename it 'Transport' so future-you can find it. Your 'VDG FLOW' folder has apps from what looks like a past project. Want to archive that folder to App Library?"
>
> [Preview shows: renamed folder, archived folder]
>
> [Apply] [Skip] [Rename to something else]

**Step 6: The Dock Suggestion**
> "Your dock has [app with 301 badges], Safari, Messages, and ChatGPT. The 301-badge app might be worth swapping for Phone or Maps, which you access more frequently. Or we can just clear the badges."
>
> [Preview shows: dock with swapped app]
>
> [Apply] [Skip] [I like my dock]

**Step 7: The Personality Summary**
> "Here's your phone's story: an iPhone user since the early days, you've accumulated the archaeology of a full life. Kids' apps from phases they've outgrown, exercise apps from resolutions that didn't stick, developer tools from projects that shipped and projects that didn't. Your page 1 is the curated you. Pages 2-8 are the real you. After today's cleanup, you went from 8 pages to 4, removed 31 apps to App Library, and your organization score went from 38 to 79."
>
> [Show Before/After Card] [Share] [Apply All Remaining] [Done]

## What Makes This Different From "Suggestions"

1. **LIVE PREVIEW.** You don't read a suggestion and imagine what it means. You SEE it. The right panel is your phone, transformed, in real-time. Every step updates the preview.

2. **STEPWISE AGENCY.** You control every change. Skip anything. Adjust anything. The AI proposes, you dispose. This directly addresses Federighi's "disorientation" concern because the user is in control at every step.

3. **NARRATIVE, NOT BULLET POINTS.** The AI doesn't say "move app X to folder Y." It tells you WHY. "These are digital fossils." "This folder name won't mean anything to you in 6 months." "Your page 1 has 2 enterprise apps taking prime real estate." The observations are the product.

4. **CUMULATIVE TRANSFORMATION.** Each step builds on the last. The preview accumulates all accepted changes. By step 7, you've watched your phone transform from chaos to order, one comprehensible step at a time. The final before/after is dramatic because you understand every change that got you there.

5. **THE PERSONALITY IS THE NARRATIVE, NOT A LABEL.** The LLM doesn't assign you "Digital Hoarder." It tells the story of your phone. "Kids' apps from phases they've outgrown, exercise apps from resolutions that didn't stick." That's personal. That's shareable. That's what you screenshot.

## LLM Integration

### What the LLM receives:
- Full list of bundle IDs with App Store metadata (name, category, description, icon URL, last updated date)
- Current layout (page, position, folder membership)
- Device model and iOS version
- App icon images (for visual analysis if using a vision model)
- Optionally: Screen Time data if user provides screenshot

### What the LLM generates:
- Ordered sequence of observations (most impactful first)
- For each observation: narrative text + structured intent (e.g., "consolidate social apps onto one page")
- Personality narrative (final step)
- Stats for the shareable card

### Two-pass architecture (LLM + Layout Engine):

The LLM does NOT output raw layout operations. It outputs intent. A deterministic layout engine resolves intent into valid operations.

```
Pass 1: LLM generates observations + intent
  "Consolidate your 14 social apps onto one page"
  "Move these 12 abandoned apps to App Library"
  "Rename 'L BV' to 'Transport'"

Pass 2: Layout engine resolves intent into operations
  - Validates each app exists (by exact bundle ID from prompt)
  - Checks page capacity (24 slots, minus widget slots)
  - Prevents duplicate placement
  - Enforces dock limit (4 apps)
  - Handles widget collision avoidance
  - Falls back gracefully if intent can't be fully resolved
```

The LLM references apps by exact bundle ID (provided in the prompt context). The layout engine rejects any operation referencing a bundle ID not in the current layout. This eliminates hallucinated apps.

Use structured output / function calling (Claude tool_use or OpenAI function_calling) to constrain the LLM's output format rather than parsing free-text JSON.

### Observation tracks (dependency management):

Observations are grouped into independent tracks. Steps within a track are sequential, but tracks themselves are independent. Skipping a track does not affect other tracks.

```
Track A: Cleanup (removing apps)
  - Step 1: Abandoned/defunct apps → App Library
  - Step 2: Duplicate-function apps → keep best, archive rest

Track B: Organization (rearranging remaining apps)
  - Step 3: Dead zone (pages 3+) category grouping
  - Step 4: Folder intelligence (rename, merge, archive)

Track C: Optimization (fine-tuning, optional)
  - Step 5: Page 1 optimization
  - Step 6: Dock suggestion

Final: Personality summary (always last, independent)
```

If user skips Track A, Track B operates on the full app set (more apps to organize, different page composition, but still valid). The LLM generates all tracks in one call; the layout engine resolves each track against the current accumulated state.

### Narrative quality tiers:

The LLM output quality depends on available data:

**Tier 1 (bundle IDs + App Store metadata only):**
- Category-based observations: "Three meditation apps, four fitness trackers, and a calorie counter."
- Defunct app detection via last-update date: "Dark Sky hasn't been updated since Apple acquired it in 2020. The built-in Weather app absorbed its features."
- Ecosystem detection: "You have 4 Salesforce apps. These belong together."
- Duplicate detection via description similarity: "Bear, Drafts, and Notes all do the same thing."
- This is the default tier. 80% of outputs will be this quality. It's observational and useful.

**Tier 2 (+ Screen Time screenshot, optional):**
- Usage-based narratives: "Duolingo streak died in March."
- "Your most-used app is buried on page 5."
- "73% of your page 1 apps aren't in your top 10."
- This tier produces the biographical narrative. It's a delightful upgrade, not a requirement.

Design for Tier 1. Let Tier 2 be the pleasant surprise when users provide Screen Time data.

### Model choice:

Use Claude Sonnet (or equivalent) for the full analysis. ~$0.11 per session. At $12.99 one-time purchase, budget for ~10 sessions per user lifetime = ~$1.10 total LLM cost. Healthy margin. Cap at 10 sessions (after 10 reorganizations, the phone is clean).

Do NOT use Haiku/4o-mini. The narrative quality difference is the product. Flat category-based output from a cheap model makes the product feel like a database report. The LLM's voice is the brand.

### Why LLM, not rules:
- Rules can say "you have 3 weather apps." LLM can say "you downloaded Dark Sky in 2019, before Apple bought it. It hasn't been updated since. CARROT Weather is the one you actually check. The built-in Weather app absorbed most of Dark Sky's features. You're carrying a ghost."
- Rules can group by category. LLM can infer intent: "These 4 apps are all from the same company's ecosystem. They probably belong together, and 'Salesforce' is a better folder name than the generic 'Business.'"
- Rules see categories. LLM sees stories.

### Cost and latency:
- One LLM call per analysis session (send full context, get back structured observations)
- ~$0.01-0.05 per analysis with Claude Haiku or GPT-4o-mini
- ~2-5 seconds for the full analysis
- Preview rendering is instant (local layout manipulation, no LLM needed per step)

## The Shareable Artifact

After the walkthrough, the before/after card generates automatically:

```
+----------------------------------+
|  Unjiggle                       |
|                                  |
|  [Before Grid]  [After Grid]    |
|  (color-coded)  (color-coded)   |
|                                  |
|  8 pages → 4 pages              |
|  31 apps decluttered             |
|  Score: 38 → 79                  |
|                                  |
|  "An iPhone user since the       |
|   early days. Kids' phases,      |
|   abandoned resolutions, and     |
|   projects that shipped."        |
|                                  |
|  unjiggle.app                   |
+----------------------------------+
```

The personality narrative IS the caption. People share it because it's about them, not about the tool.

## Aggressiveness Control

A single slider that affects all AI suggestions:

```
Conservative ←————————————→ Aggressive

Conservative: Only touch pages 4+, only remove clearly unused apps
Moderate: Touch pages 2+, group by category, rename opaque folders
Aggressive: Full reorganization including page 1 and dock
```

The AI adjusts its suggestions based on the slider. All steps still require approval in stepwise mode.

## "Just Fix It" Mode (dangerouslyApplyAll)

For users who trust the AI or don't want to step through 7 observations:

```
[Step Through Changes]  [Just Fix It →]
```

"Just Fix It" runs all AI suggestions at once, shows a single summary screen with every change listed, the before/after side-by-side, and one confirmation button. It's the `dangerouslySkipPermissions` equivalent: skip the stepwise review, see the aggregate result, apply with one click.

The summary screen shows:
- Total apps moved, removed to App Library, folders renamed
- Page count before → after
- Score before → after
- A scrollable list of every individual change (expandable) so power users can spot-check
- The personality narrative
- [Apply All] [Go Back to Stepwise] [Cancel]

Auto-backup happens before apply regardless of mode. One-tap undo restores the original layout.

This serves two user types:
1. **Impatient users** who want the transformation without the walkthrough
2. **Repeat users** who've done the stepwise flow once and trust it

The stepwise mode is the default for first-time users. "Just Fix It" becomes the default after the first successful session.
