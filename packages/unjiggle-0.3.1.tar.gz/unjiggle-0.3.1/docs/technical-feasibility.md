# Technical Feasibility Research

## How iPhone Home Screen Layout Data is Stored

### File Location & Format

The home screen layout is stored in a binary property list (plist):

- **Path**: `/private/var/mobile/Library/SpringBoard/IconState.plist`
- **Format**: Binary plist (convertible to XML or JSON)

### IconState.plist Schema

**Root-level keys:**

| Key | Type | Description |
|-----|------|-------------|
| `iconLists` | Array of Arrays | Each inner array = one home screen page. Items ordered left-to-right, top-to-bottom. |
| `buttonBar` | Array | Dock icons |
| `today` | Array | Today View widget configuration |
| `ignored` | Array | Bundle IDs of apps in App Library but NOT on home screen |

**Icon representation (within page arrays):**

- **App**: Simple string with bundle ID, e.g. `<string>com.apple.mobilephone</string>`
- **Folder**: Dictionary with keys:
  - `displayName` (String) — folder label
  - `iconLists` (Array of Arrays) — nested pages within the folder
  - `listType` (String) — `"folder"` for standard
- **Widget**: Dictionary with keys:
  - `elementType`: `"widget"`
  - `containerBundleIdentifier`: e.g. `"com.apple.weather"`
  - `gridSize`: `small` (2x2), `medium` (4x2), `extraLarge` (4x4)
- **Smart Stack**: Widget container with multiple sub-widgets

### Backup Location

In iOS backups:
- **Domain**: `HomeDomain`
- **Relative path**: `Library/SpringBoard/IconState.plist`
- **Backup file hash**: `SHA1("HomeDomain-Library/SpringBoard/IconState.plist")` = `aeacdfd9fadbbe56548a40e02b7685d324050e54`

---

## Access Methods — Ranked by Viability

### A) USB Lockdown Service (springboardservices) — MOST PROMISING

iOS exposes `com.apple.springboardservices` (available since iOS 3.1) providing direct read/write access to the icon state over USB. No jailbreak, no supervision, no exploit. Just "Trust this computer."

**API:**

| Function | Description |
|----------|-------------|
| `get_icon_state(format_version="2")` | Returns complete home screen layout as plist/dict |
| `set_icon_state(newstate)` | Writes a new layout to the device |
| `get_icon_pngdata(bundle_id)` | Gets an app's icon as PNG |
| `get_wallpaper_pngdata()` | Gets the wallpaper |
| `get_homescreen_icon_metrics()` | Gets grid dimensions/spacing per device model |
| `get_interface_orientation()` | Gets current screen orientation |
| `reload_icon_state()` | Forces SpringBoard to reload |

**Key facts:**
- Standard lockdown service (not developer service), available on all iOS versions including iOS 17/18
- pymobiledevice3 supports tunnel-based transport for iOS 17+
- Also has a remote variant: `com.apple.springboardservices.shim.remote` (over RemoteXPC tunnel)
- Works over USB (usbmuxd), WiFi, and RemoteXPC tunnels (iOS 17+)
- iOS 17+ architecture: Ethernet-over-USB creates IPv6 interface, QUIC/TCP tunnel via `tunneld`/`remoted`
- iOS 17.4+ adds lockdown-based tunnel creation (no extra pairing, TCP, faster)
- ~90+ services exposed over RemoteXPC tunnel, including springboard services

**Existing implementations:**
- **libimobiledevice** (C): `sbservices.h` / `sbservices.c` — mature, cross-platform
- **pymobiledevice3** (Python): `SpringBoardServicesService` class — actively maintained, iOS 17/18
- **sbmanager** (C/GTK): Full drag-and-drop GUI for icon arrangement — INACTIVE but proof of concept

**Critical unknown:** Whether `set_icon_state()` is still honored by SpringBoard on iOS 17/18. Read path is confirmed working. Write path needs hands-on testing.

**Risk level:** Medium. Read path solid. Write path needs validation.

### B) Finder Backup Reading — MAC APP STORE EDITION

Read `IconState.plist` directly from existing Finder backups on disk. This is the **sandbox-compatible path** for the Mac App Store edition.

**How it works:**
1. User clicks "Open Backup" → `NSOpenPanel` navigates to `~/Library/Application Support/MobileSync/Backup/`
2. App reads `Manifest.db` (SQLite) to locate `IconState.plist` entry for `HomeDomain`
3. Find actual file using hash `aeacdfd9fadbbe56548a40e02b7685d324050e54`
4. Parse plist → identical `HomeScreenLayout` model as the USB path
5. Security-scoped bookmark stored for repeat access without re-prompting

**Why this is sandbox-safe:**
- `NSOpenPanel` grants user-consented access to the selected directory
- Security-scoped bookmarks persist access across app launches
- No usbmuxd, no private frameworks, no privileged helpers needed
- Only standard APIs: Foundation (plist parsing), SQLite, `NSOpenPanel`

**For applying changes (App Store edition):**
- Export modified `IconState.plist` to user-chosen location
- User restores backup via Finder (manual step — documented in-app with walkthrough)
- Not as seamless as USB, but validates the product before users commit to the Pro edition

**Advantages:**
- Fully sandbox-compatible → Mac App Store distribution
- Most users already have a recent Finder backup
- Lower friction first experience (no "Trust this computer" step)
- Zero risk to device (read-only from backup)

**Disadvantages:**
- Backup may be stale (not real-time)
- Encrypted backups require password
- Apply step requires user to manually restore via Finder
- No live icon/wallpaper fetching (use backup data or App Store API for icons)

**Risk level:** Low. Standard macOS APIs, no private framework dependencies.

### C) iTunes Backup Modification — WRITE FALLBACK

If `set_icon_state()` is blocked on iOS 17/18, the direct download edition can fall back to modifying the backup and restoring it.

**Process:**
1. Create unencrypted backup via Finder/iTunes (or programmatically via `mobilebackup2` service)
2. Open `Manifest.db` (SQLite), locate the entry for `HomeDomain` / `Library/SpringBoard/IconState.plist`
3. Find actual file using hash `aeacdfd9fadbbe56548a40e02b7685d324050e54`
4. Modify the plist
5. Update file hash in `Manifest.db`
6. Restore the backup

**Advantages:**
- Well-documented (forensics community)
- Cowabunga Lite proved partial backup restores work
- `mobilebackup2` service available in pymobiledevice3 and libimobiledevice

**Disadvantages:**
- Full backup/restore cycle is slow (minutes)
- Encrypted backups require password
- iOS may regenerate IconState.plist during restore

**Risk level:** Medium-High.

### D) MDM / Configuration Profile — REQUIRES SUPERVISION (NOT VIABLE)

The `com.apple.homescreenlayout` payload requires supervised devices. Supervising erases all data. Not viable for consumer devices.

### E) Apple Configurator 2 — PARTIALLY WORKS

Uses the same sbservices under the hood. Works for some operations on non-supervised devices but is unreliable. Many users report changes not saving. Validates that the sbservices approach works at least partially.

### F) iOS Shortcuts / Accessibility APIs — NOT VIABLE

No Shortcuts actions, no accessibility APIs, no Screen Time APIs expose layout management.

### G) SparseRestore / BookRestore Exploits — NOT VIABLE FOR A PRODUCT

Get patched with each iOS update. Building on exploits is a ticking time bomb.

---

## Existing Open Source Tools

| Tool | Language | Status | What it does |
|------|----------|--------|--------------|
| [pymobiledevice3](https://github.com/doronz88/pymobiledevice3) | Python | **Active** (9.7k stars) | Full springboard service access, iOS 17/18 |
| [libimobiledevice](https://github.com/libimobiledevice/libimobiledevice) | C | **Active** | sbservices API, backup service, cross-platform |
| [sbmanager](https://github.com/libimobiledevice/sbmanager) | C/GTK | **INACTIVE** | Full GUI for icon drag-and-drop — proof of concept |
| [IconState](https://iconstate.github.io/) | Web/JS | Maintained | Web-based IconState.plist editor |
| [Cowabunga Lite](https://github.com/leminlimez/CowabungaLite) | Swift/Python | iOS 15-17 | Partial backup restore for SpringBoard |
| [Nugget](https://github.com/leminlimez/Nugget) | Swift | iOS 16-18 | Exploit-based customization |
| [iOSbackup](https://github.com/avibrazil/iOSbackup) | Python | Maintained | Parse/extract iOS backup files |

---

## Apple's Restrictions

### Mac App Store — CONFIRMED NOT VIABLE
- Sandbox required, blocks MobileDevice.framework (private framework)
- Sandbox blocks `/var/run/usbmuxd` Unix socket access
- Sandbox blocks `com.apple.usbmuxd` Mach service lookup
- `com.apple.security.device.usb` entitlement is for raw USB hardware (IOKit), NOT usbmuxd
- Temporary exception entitlements for mach-lookup/file-access would almost certainly be rejected by App Review
- Apple Configurator 2 (Apple's own app) requires `com.apple.private.*` entitlements unavailable to third parties
- No iPhone management tool has ever been distributed through the Mac App Store (except Apple's own)
- SMAppService daemons must also be sandboxed when the main app is sandboxed (macOS 14.2+)
- CoreDevice framework has no public third-party API
- iOS 17+ RemoteXPC tunnels require root-level TUN device creation
- **See detailed analysis: [sandbox-distribution-research.md](sandbox-distribution-research.md)**
- **Verdict: USB features require direct distribution — but a backup-based App Store edition IS viable**

### Dual Distribution Strategy

**Mac App Store edition** (sandbox-compatible via backup reading — method B above):
- Reads layout from Finder backups via `NSOpenPanel` + security-scoped bookmarks
- Full visualization, scoring, drag-and-drop editing, AI suggestions
- Export modified layout; user restores backup via Finder manually
- Free — serves as top-of-funnel acquisition for Pro edition
- Standard App Store distribution certificate, App Store auto-updates

**Direct download edition** (Pro — full USB):
- Live USB read/write via libimobiledevice + usbmuxd
- One-click "Apply to iPhone" with auto-backup
- Live app icon and wallpaper fetching from device
- Developer ID + notarization, Sparkle for auto-updates
- $12.99 one-time via Paddle or LemonSqueezy

**Shared codebase (>90%)**: Both editions share all UI, algorithm, and editing code. The only difference is the `LayoutDataProvider` implementation — `BackupReader` (App Store) vs `USBBridge` (Direct). Compile-time flag (`APPSTORE_EDITION`) controls which provider is linked.

### Trust Pairing (Direct Download Edition Only)
- One-time "Trust this computer" tap on iPhone
- Standard UX for all iPhone management tools

---

## Widget Considerations

### What's Possible
- Reading widget placement from IconState.plist
- Moving existing widgets by rearranging position in iconLists
- Widget sizes: small (2x2), medium (4x2), extraLarge (4x4)

### What's Difficult
- Creating new widget instances (requires WidgetKit configuration state)
- Configuring widget preferences (stored separately)
- MDM payload doesn't support widgets at all

### V1 Recommendation
Support moving and reordering existing widgets, not creating new ones.

---

## Recommended Architecture

```
[Mac App (Swift/SwiftUI)]
         |
    [LayoutDataProvider protocol]
         |
    +----+----+
    |         |
[Backup    [USB Bridge
 Reader]    (libimobiledevice)]
    |              |
[NSOpenPanel →    [usbmuxd]
 backup dir]       |
                   v
            [iPhone: com.apple.springboardservices]

App Store edition: BackupReader only
Direct download:   Both (BackupReader + USBBridge)
```

### Tech Stack
- **Language**: Swift (native Mac) wrapping libimobiledevice (C)
- **UI**: SwiftUI
- **Device Communication**: libimobiledevice or pymobiledevice3 (Direct Download edition)
- **Backup Parsing**: Foundation plist APIs + SQLite (both editions)
- **Distribution**: Mac App Store (Lite) + Developer ID + notarization + Sparkle (Pro)

### Validation Test (30 minutes)

```bash
pip3 install pymobiledevice3
pymobiledevice3 springboard get-icon-state > current_layout.json
# Modify: swap two app positions
pymobiledevice3 springboard set-icon-state < modified_layout.json
# Check iPhone — if apps moved, green light
```

---

## Risk Matrix

| Risk | Severity | Mitigation |
|------|----------|------------|
| `set_icon_state()` silently ignored on iOS 17/18 | HIGH | Test immediately. Backup fallback. |
| Apple patches lockdown service | Medium | pymobiledevice3 adapts; stable 15+ years |
| Widget placement breaks things | Medium | V1: move only, don't create |
| iOS 18 large icon mode not in plist | Low | Detect and warn; graceful degradation |
| Backup/restore fallback is slow | Medium | Partial restore (only IconState.plist) |
