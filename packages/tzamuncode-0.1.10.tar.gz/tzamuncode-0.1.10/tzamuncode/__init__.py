"""
TzamunCode - AI Coding Assistant

Privacy-first AI coding assistant powered by local models.
Built by Tzamun Arabia IT Co. 🇸🇦
"""

__version__ = "0.1.10"
__author__ = "Tzamun Arabia IT Co."
__email__ = "info@tzamun.com"
