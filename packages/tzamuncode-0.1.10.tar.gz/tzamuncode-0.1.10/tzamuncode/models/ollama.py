"""
Ollama client for TzamunCode
"""

import requests
import os
from typing import List, Dict, Generator, Optional
import json

class OllamaClient:
    """Client for interacting with Ollama API"""
    
    def __init__(
        self,
        base_url: str = None,
        model: str = "qwen2.5:32b",
        timeout: int = 120
    ):
        # Use environment variable if available, otherwise default to localhost
        # Support both OLLAMA_HOST and OLLAMA_BASE_URL for compatibility
        if base_url is None:
            base_url = os.getenv('OLLAMA_HOST') or os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434')
        self.base_url = base_url.rstrip('/')
        self.model = model
        self.timeout = timeout
    
    def generate(self, prompt: str, system: Optional[str] = None) -> str:
        """Generate a response from the model"""
        url = f"{self.base_url}/api/generate"
        
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 4096
            }
        }
        
        if system:
            payload["system"] = system
        
        try:
            response = requests.post(url, json=payload, timeout=self.timeout)
            response.raise_for_status()
            return response.json()["response"]
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to generate response: {e}")
    
    def chat(self, messages: List[Dict[str, str]]) -> str:
        """Chat with the model using conversation history"""
        url = f"{self.base_url}/api/chat"
        
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 4096
            }
        }
        
        try:
            response = requests.post(url, json=payload, timeout=self.timeout)
            response.raise_for_status()
            return response.json()["message"]["content"]
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to chat: {e}")
    
    def chat_stream(self, messages: List[Dict[str, str]]) -> Generator[str, None, None]:
        """Stream chat responses"""
        url = f"{self.base_url}/api/chat"
        
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": 0.7,
                "num_predict": 4096
            }
        }
        
        try:
            response = requests.post(url, json=payload, timeout=self.timeout, stream=True)
            response.raise_for_status()
            
            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    if "message" in data:
                        content = data["message"].get("content", "")
                        if content:
                            yield content
                    
                    if data.get("done", False):
                        break
                        
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to stream chat: {e}")
    
    def list_models(self) -> List[str]:
        """List available models"""
        url = f"{self.base_url}/api/tags"
        
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            models = response.json().get("models", [])
            return [model["name"] for model in models]
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to list models: {e}")
    
    def pull_model(self, model_name: str) -> bool:
        """Pull a model from Ollama library"""
        url = f"{self.base_url}/api/pull"
        
        payload = {
            "name": model_name
        }
        
        try:
            response = requests.post(url, json=payload, timeout=600)
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to pull model: {e}")
