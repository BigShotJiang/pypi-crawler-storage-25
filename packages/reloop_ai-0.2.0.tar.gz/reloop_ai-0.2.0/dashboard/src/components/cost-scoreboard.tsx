"use client";

import { useState, useEffect, useRef } from "react";
import type { Attempt } from "@/lib/types";
import { cn } from "@/lib/utils";
import { TrendingDown, DollarSign, Zap, ArrowRight } from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Animated counter hook                                              */
/* ------------------------------------------------------------------ */

function useAnimatedNumber(target: number, duration = 800): number {
  const [value, setValue] = useState(0);
  const frameRef = useRef<number | null>(null);
  const startRef = useRef<number | null>(null);
  const startValueRef = useRef(0);

  useEffect(() => {
    startValueRef.current = value;
    startRef.current = null;

    function animate(timestamp: number) {
      if (!startRef.current) startRef.current = timestamp;
      const elapsed = timestamp - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(startValueRef.current + (target - startValueRef.current) * eased);
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(animate);
      }
    }

    frameRef.current = requestAnimationFrame(animate);
    return () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, duration]);

  return value;
}

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */

interface CostScoreboardProps {
  attempts: Attempt[];
  totalCost: number;
  maxBudget?: number;
  /** When provided, shows the A/B scoreboard: without-memory cost vs with-memory cost */
  withoutMemoryCost?: number;
  className?: string;
  compact?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Per-attempt bar                                                    */
/* ------------------------------------------------------------------ */

function AttemptBar({
  attempt,
  maxCost,
}: {
  attempt: Attempt;
  maxCost: number;
}) {
  const heightPct = maxCost > 0 ? (attempt.cost_usd / maxCost) * 100 : 0;
  const isSuccess = attempt.status === "succeeded";
  const isFailed = attempt.status === "failed";

  const colorClass = isSuccess
    ? "bg-emerald-500"
    : isFailed
      ? "bg-red-500"
      : "bg-amber-500";

  const textColorClass = isSuccess
    ? "text-emerald-500"
    : isFailed
      ? "text-red-500"
      : "text-amber-500";

  return (
    <div className="flex flex-col items-center gap-1">
      <span className="text-[10px] font-normal text-muted-foreground font-mono tabular-nums">
        ${attempt.cost_usd.toFixed(2)}
      </span>
      <div
        className={cn("w-5 rounded-[3px] opacity-75 transition-[height] duration-400 ease-out", colorClass)}
        style={{ height: `${Math.max(4, heightPct * 0.44)}px` }}
      />
      <span className={cn("text-[10px] font-semibold", textColorClass)}>
        A{attempt.attempt_number}
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main scoreboard                                                    */
/* ------------------------------------------------------------------ */

export function CostScoreboard({
  attempts,
  totalCost,
  maxBudget = 1.0,
  withoutMemoryCost,
  className,
  compact = false,
}: CostScoreboardProps) {
  // Estimate "without memory" cost = cost of first attempt x number of attempts
  // (agent would blindly retry same approach each time)
  const firstAttemptCost = attempts[0]?.cost_usd ?? 0;
  const estimatedWithoutMemory =
    withoutMemoryCost ?? firstAttemptCost * attempts.length;

  const savedAmount = Math.max(0, estimatedWithoutMemory - totalCost);
  const savedPct =
    estimatedWithoutMemory > 0
      ? Math.round((savedAmount / estimatedWithoutMemory) * 100)
      : 0;

  const budgetUsedPct = Math.min(100, (totalCost / maxBudget) * 100);
  const maxCost = Math.max(...attempts.map((a) => a.cost_usd), 0.001);

  // Animated values
  const animWithout = useAnimatedNumber(estimatedWithoutMemory);
  const animWith = useAnimatedNumber(totalCost);
  const animSaved = useAnimatedNumber(savedAmount);
  const animPct = useAnimatedNumber(savedPct);

  if (compact) {
    return (
      <div className={cn("flex items-center gap-4", className)}>
        <div className="space-y-1 min-w-[88px]">
          <p className="uppercase text-[11px] font-semibold text-muted-foreground tracking-widest">
            Budget
          </p>
          <p className="text-[17px] font-semibold text-white tracking-tight tabular-nums">
            ${animWith.toFixed(4)}
          </p>
          <p className="text-[11px] font-normal text-muted-foreground tracking-tight">
            of ${maxBudget.toFixed(2)}
          </p>
          {/* Budget bar */}
          <div className="flex items-center gap-2">
            <div className="flex-1 overflow-hidden h-[2px] rounded-full bg-white/[0.08]">
              <div
                className="h-full rounded-full transition-[width] duration-500 ease-out"
                style={{
                  width: `${budgetUsedPct}%`,
                  backgroundColor: budgetUsedPct > 80 ? "var(--apple-yellow)" : "var(--apple-blue)",
                }}
              />
            </div>
            <span className="text-[11px] font-normal text-white/80 tracking-tight tabular-nums">
              {Math.round(budgetUsedPct)}%
            </span>
          </div>
        </div>

        <div className="w-px h-12 bg-white/[0.06]" />

        {/* Per-attempt bars */}
        <div className="flex-1 min-w-0">
          <p className="uppercase mb-2 text-[11px] font-semibold text-muted-foreground tracking-widest">
            Per Attempt
          </p>
          <div className="flex items-end gap-2">
            {attempts.map((attempt) => (
              <AttemptBar
                key={attempt.attempt_number}
                attempt={attempt}
                maxCost={maxCost}
              />
            ))}
          </div>
        </div>

        {savedAmount > 0.001 && (
          <>
            <div className="w-px h-12 bg-white/[0.06]" />
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-[10px] bg-emerald-500/[0.08] border border-emerald-500/[0.15]">
              <TrendingDown className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
              <div>
                <p className="uppercase leading-tight text-[10px] font-semibold text-emerald-500/70 tracking-widest">
                  Memory saved
                </p>
                <p className="text-[15px] font-bold text-emerald-500 tracking-tight tabular-nums">
                  {Math.round(animPct)}%
                </p>
              </div>
            </div>
          </>
        )}
      </div>
    );
  }

  // Full scoreboard (for A/B page or prominent placement)
  return (
    <div
      className={cn(
        "space-y-4 rounded-xl p-5 border border-white/[0.06]",
        className,
      )}
      style={{ backgroundColor: "var(--apple-bg-near-black)" }}
    >
      {/* Header */}
      <div className="flex items-center gap-2">
        <DollarSign className="h-4 w-4" style={{ color: "var(--apple-blue)" }} />
        <h3 className="text-sm font-semibold text-white tracking-tight">
          Cost Scoreboard
        </h3>
      </div>

      {/* Big numbers row */}
      <div className="grid grid-cols-3 gap-3">
        {/* Without memory */}
        <div className="p-3 space-y-1 rounded-lg bg-red-500/[0.06] border border-red-500/[0.12]">
          <p className="uppercase text-[10px] font-semibold text-red-500/70 tracking-widest">
            Without Memory
          </p>
          <p className="text-[22px] font-bold text-red-500 tracking-tight tabular-nums">
            ${animWithout.toFixed(2)}
          </p>
          <p className="text-[11px] font-normal text-muted-foreground">
            blind retries
          </p>
        </div>

        {/* Arrow */}
        <div className="flex items-center justify-center">
          <div className="flex flex-col items-center gap-1">
            <ArrowRight className="h-4 w-4 text-white/[0.24]" />
            <span className="text-[10px] font-normal text-white/[0.24]">
              vs
            </span>
          </div>
        </div>

        {/* With memory */}
        <div className="p-3 space-y-1 rounded-lg bg-emerald-500/[0.06] border border-emerald-500/[0.12]">
          <p className="uppercase text-[10px] font-semibold text-emerald-500/70 tracking-widest">
            With Memory
          </p>
          <p className="text-[22px] font-bold text-emerald-500 tracking-tight tabular-nums">
            ${animWith.toFixed(2)}
          </p>
          <p className="text-[11px] font-normal text-muted-foreground">
            informed retries
          </p>
        </div>
      </div>

      {/* Savings highlight */}
      {savedAmount > 0.001 && (
        <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-500/[0.08] border border-emerald-500/20">
          <div className="flex items-center gap-2">
            <TrendingDown className="h-4 w-4 text-emerald-500" />
            <span className="text-[13px] font-semibold text-emerald-500 tracking-tight">
              Memory saved ${animSaved.toFixed(4)} ({Math.round(animPct)}% reduction)
            </span>
          </div>
          <Zap className="h-3.5 w-3.5 text-emerald-500" />
        </div>
      )}

      {/* Per-attempt breakdown */}
      {attempts.length > 0 && (
        <div className="space-y-2">
          <p className="uppercase text-[10px] font-semibold text-muted-foreground tracking-widest">
            Cost per Attempt
          </p>
          <div className="flex items-end gap-3">
            {attempts.map((attempt) => (
              <AttemptBar
                key={attempt.attempt_number}
                attempt={attempt}
                maxCost={maxCost}
              />
            ))}
          </div>
        </div>
      )}

      {/* Budget bar */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <p className="uppercase text-[10px] font-semibold text-muted-foreground tracking-widest">
            Budget Used
          </p>
          <span className="text-[11px] font-normal text-white/80 tabular-nums">
            ${totalCost.toFixed(4)} / ${maxBudget.toFixed(2)}
          </span>
        </div>
        <div className="overflow-hidden h-1 rounded-full bg-white/[0.08]">
          <div
            className="h-full rounded-full transition-[width] duration-500 ease-out"
            style={{
              width: `${budgetUsedPct}%`,
              backgroundColor: budgetUsedPct > 80 ? "var(--apple-yellow)" : "var(--apple-blue)",
            }}
          />
        </div>
      </div>
    </div>
  );
}
