"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import { useRouter } from "next/navigation";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  RefreshCw,
  Plus,
  RotateCcw,
  Zap,
  Brain,
  DollarSign,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  ShieldCheck,
  ArrowUpRight,
  ChevronDown,
  Command,
  Loader2,
  Activity,
  ShieldAlert,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { fetchTasks, createTask, getMockTasks, fetchMemoryStats, predictFailures } from "@/lib/api";
import type { TaskResponse, TaskStatus, MemoryStats, PredictionResult } from "@/lib/types";

/* ── Status Badge ──────────────────────────────────────────────────────── */

const statusConfig: Record<
  string,
  { icon: React.ReactNode; label: string; colorClass: string; dotClass: string }
> = {
  succeeded: {
    icon: <CheckCircle2 className="w-3.5 h-3.5" />,
    label: "Succeeded",
    colorClass: "text-emerald-400",
    dotClass: "bg-emerald-400",
  },
  running: {
    icon: <Activity className="w-3.5 h-3.5" />,
    label: "Running",
    colorClass: "text-amber-400",
    dotClass: "bg-amber-400",
  },
  failed: {
    icon: <XCircle className="w-3.5 h-3.5" />,
    label: "Failed",
    colorClass: "text-red-400",
    dotClass: "bg-red-400",
  },
  pending: {
    icon: <Clock className="w-3.5 h-3.5" />,
    label: "Pending",
    colorClass: "text-zinc-400",
    dotClass: "bg-zinc-400",
  },
};

function StatusBadge({ status }: { status: TaskStatus }) {
  const c = statusConfig[status] ?? {
    icon: null,
    label: status,
    colorClass: "text-zinc-400",
    dotClass: "bg-zinc-400",
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 text-xs font-medium ${c.colorClass}`}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full ${c.dotClass}`}
        style={{ boxShadow: `0 0 6px currentColor` }}
      />
      {c.label}
    </span>
  );
}

/* ── Task Card ─────────────────────────────────────────────────────────── */

function TaskCard({
  task,
  onClick,
}: {
  task: TaskResponse;
  onClick: () => void;
}) {
  const [ageMs, setAgeMs] = useState<number>(
    () => Date.now() - new Date(task.created_at).getTime()
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setAgeMs(Date.now() - new Date(task.created_at).getTime());
    }, 60000);
    return () => clearInterval(interval);
  }, [task.created_at]);

  const ageMin = Math.round(ageMs / 1000 / 60);
  const ageLabel =
    ageMin < 1
      ? "just now"
      : ageMin < 60
        ? `${ageMin}m ago`
        : `${Math.round(ageMin / 60)}h ago`;

  return (
    <div
      onClick={onClick}
      className="group cursor-pointer"
      style={{
        padding: "16px 20px",
        borderRadius: "var(--radius-lg, 12px)",
        backgroundColor: "var(--bg-surface, #0a0a0a)",
        border: "1px solid var(--border-default, #1e1e1e)",
        transition: "all var(--transition-normal, 250ms) ease",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-2px)";
        e.currentTarget.style.borderColor = "var(--border-hover, #333)";
        e.currentTarget.style.boxShadow = "var(--shadow-md, 0 4px 24px rgba(0,0,0,0.3))";
        e.currentTarget.style.backgroundColor = "var(--bg-surface-hover, #111)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
        e.currentTarget.style.boxShadow = "none";
        e.currentTarget.style.backgroundColor = "var(--bg-surface, #0a0a0a)";
      }}
    >
      <div className="flex items-start gap-4">
        <div className="flex-1 min-w-0">
          <p
            className="line-clamp-2 text-[15px] font-medium leading-relaxed tracking-tight"
            style={{ color: "var(--text-primary, #f4f4f5)", margin: 0 }}
          >
            {task.instruction}
          </p>

          <div className="flex items-center gap-4 mt-3">
            <StatusBadge status={task.status} />

            <span className="inline-flex items-center gap-1 text-xs" style={{ color: "var(--text-muted, #52525b)" }}>
              <RotateCcw className="w-3 h-3" />
              {task.total_attempts}
            </span>

            <span className="inline-flex items-center gap-1 text-xs" style={{ color: "var(--text-muted, #52525b)" }}>
              <DollarSign className="w-3 h-3" />
              ${task.total_cost_usd.toFixed(3)}
            </span>

            <span className="inline-flex items-center gap-1 text-xs" style={{ color: "var(--text-muted, #52525b)" }}>
              <Clock className="w-3 h-3" />
              {ageLabel}
            </span>
          </div>
        </div>

        <div
          className="w-7 h-7 flex items-center justify-center shrink-0 mt-0.5 rounded-md"
          style={{
            color: "var(--text-muted, #52525b)",
            transition: "all var(--transition-fast, 150ms) ease",
          }}
        >
          <ChevronRight className="w-4 h-4 transition-transform duration-150 group-hover:translate-x-0.5" />
        </div>
      </div>
    </div>
  );
}

/* ── Stat Card ─────────────────────────────────────────────────────────── */

function StatCard({
  label,
  value,
  icon,
  accentColor,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  accentColor?: string;
}) {
  return (
    <div
      className="group"
      style={{
        padding: 24,
        borderRadius: "var(--radius-lg, 12px)",
        backgroundColor: "var(--bg-surface, #0a0a0a)",
        border: "1px solid var(--border-default, #1e1e1e)",
        transition: "all var(--transition-normal, 250ms) ease",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "var(--border-hover, #333)";
        e.currentTarget.style.boxShadow = "var(--shadow-sm, 0 2px 12px rgba(0,0,0,0.2))";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <div className="flex items-center justify-between mb-3">
        <p
          className="text-xs font-medium uppercase tracking-wider"
          style={{ color: "var(--text-muted, #52525b)", margin: 0 }}
        >
          {label}
        </p>
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{
            backgroundColor: accentColor
              ? `${accentColor}15`
              : "rgba(255,255,255,0.04)",
            color: accentColor ?? "var(--text-secondary, #a1a1aa)",
          }}
        >
          {icon}
        </div>
      </div>
      <p
        className="text-2xl font-semibold tracking-tight"
        style={{ color: "var(--text-primary, #f4f4f5)", margin: 0 }}
      >
        {value}
      </p>
    </div>
  );
}

/* ── Filter Tab ────────────────────────────────────────────────────────── */

function FilterTab({
  label,
  count,
  active,
  onClick,
}: {
  label: string;
  count: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="inline-flex items-center gap-1.5 text-sm font-medium"
      style={{
        padding: "6px 14px",
        borderRadius: "var(--radius-md, 8px)",
        border: "none",
        outline: "none",
        cursor: "pointer",
        letterSpacing: "-0.01em",
        color: active
          ? "var(--text-primary, #f4f4f5)"
          : "var(--text-muted, #52525b)",
        background: active ? "rgba(255,255,255,0.06)" : "transparent",
        transition: "all var(--transition-fast, 150ms) ease",
      }}
    >
      {label}
      <span
        className="text-xs tabular-nums"
        style={{
          color: active
            ? "var(--text-secondary, #a1a1aa)"
            : "var(--text-muted, #52525b)",
        }}
      >
        {count}
      </span>
    </button>
  );
}

/* ── Memory Health Section ─────────────────────────────────────────────── */

function MemoryHealthSection({
  stats,
  useMock,
}: {
  stats: MemoryStats | null;
  useMock: boolean;
}) {
  const categories =
    stats?.top_error_categories ??
    (useMock
      ? {
          dependency_error: 3,
          runtime_error: 2,
          type_error: 2,
          config_error: 1,
        }
      : {});

  const segments = Object.entries(categories).map(([key, value]) => ({
    label: key,
    value: value as number,
  }));

  const maxSegValue = Math.max(...segments.map((s) => s.value), 1);

  const antiPatterns = useMock
    ? [
        {
          pattern: "Assuming all dependencies are installed",
          count: 3,
          confidence: 0.95,
        },
        {
          pattern: "Hardcoding port without checking availability",
          count: 2,
          confidence: 0.92,
        },
        {
          pattern: "Implicit type coercion in TypeScript",
          count: 2,
          confidence: 0.88,
        },
      ]
    : [];

  const totalMemories = stats
    ? stats.total_failures + stats.total_successes
    : useMock
      ? 11
      : 0;
  const avgConfidence = stats?.avg_confidence ?? (useMock ? 0.92 : 0);
  const healthScore = Math.round(avgConfidence * 100);

  const cardStyle = {
    padding: 24,
    borderRadius: "var(--radius-lg, 12px)",
    backgroundColor: "var(--bg-surface, #0a0a0a)",
    border: "1px solid var(--border-default, #1e1e1e)",
    transition: "all var(--transition-normal, 250ms) ease",
  };

  const sectionLabelStyle: React.CSSProperties = {
    fontSize: 11,
    fontWeight: 600,
    color: "var(--text-muted, #52525b)",
    letterSpacing: "0.05em",
    margin: 0,
    lineHeight: 1.33,
    textTransform: "uppercase" as const,
  };

  const categoryColors = [
    "var(--danger, #ef4444)",
    "var(--warning, #f59e0b)",
    "var(--accent, #10b981)",
    "#6366f1",
  ];

  return (
    <div className="grid grid-cols-3 gap-4">
      {/* Error Distribution */}
      <div
        style={cardStyle}
        onMouseEnter={(e) => {
          e.currentTarget.style.borderColor = "var(--border-hover, #333)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
        }}
      >
        <p className="flex items-center gap-2" style={sectionLabelStyle}>
          <AlertTriangle className="w-3.5 h-3.5" style={{ color: "var(--danger, #ef4444)" }} />
          Error Distribution
        </p>
        <div className="mt-4">
          {segments.length > 0 ? (
            <div className="flex flex-col gap-3">
              {segments.map((seg, i) => (
                <div key={seg.label}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className="text-sm capitalize"
                      style={{ color: "var(--text-secondary, #a1a1aa)" }}
                    >
                      {seg.label.replace(/_/g, " ")}
                    </span>
                    <span
                      className="text-sm font-semibold tabular-nums"
                      style={{ color: "var(--text-primary, #f4f4f5)" }}
                    >
                      {seg.value}
                    </span>
                  </div>
                  <div
                    className="w-full overflow-hidden"
                    style={{
                      height: 4,
                      backgroundColor: "rgba(255,255,255,0.04)",
                      borderRadius: 2,
                    }}
                  >
                    <div
                      style={{
                        height: "100%",
                        width: `${(seg.value / maxSegValue) * 100}%`,
                        backgroundColor: categoryColors[i % categoryColors.length],
                        borderRadius: 2,
                        transition: "width 500ms ease",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8">
              <AlertTriangle
                className="w-8 h-8 mb-2"
                style={{ color: "var(--text-muted, #52525b)", opacity: 0.4 }}
              />
              <p
                className="text-sm"
                style={{ color: "var(--text-muted, #52525b)", margin: 0 }}
              >
                No errors recorded
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Anti-Patterns */}
      <div
        style={cardStyle}
        onMouseEnter={(e) => {
          e.currentTarget.style.borderColor = "var(--border-hover, #333)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
        }}
      >
        <p className="flex items-center gap-2" style={sectionLabelStyle}>
          <Brain className="w-3.5 h-3.5" style={{ color: "#a78bfa" }} />
          Anti-Patterns Learned
        </p>
        <div className="mt-4">
          {antiPatterns.length > 0 ? (
            <div className="flex flex-col gap-4">
              {antiPatterns.map((ap, i) => (
                <div key={i}>
                  <p
                    className="text-sm leading-snug"
                    style={{
                      color: "var(--text-secondary, #a1a1aa)",
                      margin: 0,
                    }}
                  >
                    {ap.pattern}
                  </p>
                  <div className="flex items-center gap-2.5 mt-2">
                    <div
                      className="flex-1 overflow-hidden"
                      style={{
                        height: 4,
                        backgroundColor: "rgba(255,255,255,0.04)",
                        borderRadius: 2,
                      }}
                    >
                      <div
                        style={{
                          height: "100%",
                          width: `${ap.confidence * 100}%`,
                          backgroundColor: "var(--accent, #10b981)",
                          borderRadius: 2,
                          transition: "width 500ms ease",
                        }}
                      />
                    </div>
                    <span
                      className="text-xs font-medium tabular-nums"
                      style={{ color: "var(--text-muted, #52525b)" }}
                    >
                      {Math.round(ap.confidence * 100)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8">
              <Brain
                className="w-8 h-8 mb-2"
                style={{ color: "var(--text-muted, #52525b)", opacity: 0.4 }}
              />
              <p
                className="text-sm"
                style={{ color: "var(--text-muted, #52525b)", margin: 0 }}
              >
                No patterns learned yet
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Memory Health */}
      <div
        style={cardStyle}
        onMouseEnter={(e) => {
          e.currentTarget.style.borderColor = "var(--border-hover, #333)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
        }}
      >
        <p className="flex items-center gap-2" style={sectionLabelStyle}>
          <ShieldCheck className="w-3.5 h-3.5" style={{ color: "var(--accent, #10b981)" }} />
          Memory Health
        </p>
        <div className="mt-4">
          {/* Health ring */}
          <div className="flex flex-col items-center">
            <div className="relative inline-flex items-center justify-center">
              <svg
                width="72"
                height="72"
                style={{ transform: "rotate(-90deg)" }}
              >
                <circle
                  cx="36"
                  cy="36"
                  r="28"
                  fill="none"
                  stroke="rgba(255,255,255,0.04)"
                  strokeWidth="5"
                />
                <circle
                  cx="36"
                  cy="36"
                  r="28"
                  fill="none"
                  stroke="var(--accent, #10b981)"
                  strokeWidth="5"
                  strokeDasharray={`${(healthScore / 100) * 175.9} 175.9`}
                  strokeLinecap="round"
                  style={{
                    filter: "drop-shadow(0 0 6px rgba(16,185,129,0.3))",
                    transition: "stroke-dasharray 500ms ease",
                  }}
                />
              </svg>
              <span
                className="absolute text-xl font-bold tabular-nums"
                style={{ color: "var(--text-primary, #f4f4f5)" }}
              >
                {healthScore}
              </span>
            </div>
            <p
              className="text-xs mt-2"
              style={{ color: "var(--text-muted, #52525b)", margin: "8px 0 0 0" }}
            >
              Confidence Score
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3 mt-6">
            <div
              className="text-center rounded-lg py-3"
              style={{ backgroundColor: "rgba(255,255,255,0.02)" }}
            >
              <p
                className="font-mono text-xl font-semibold tabular-nums"
                style={{
                  color: "var(--text-primary, #f4f4f5)",
                  margin: 0,
                  lineHeight: 1.2,
                }}
              >
                {totalMemories}
              </p>
              <p
                className="text-xs mt-1"
                style={{ color: "var(--text-muted, #52525b)", margin: "4px 0 0 0" }}
              >
                Memories
              </p>
            </div>
            <div
              className="text-center rounded-lg py-3"
              style={{ backgroundColor: "rgba(255,255,255,0.02)" }}
            >
              <p
                className="font-mono text-xl font-semibold tabular-nums"
                style={{
                  color: "var(--text-primary, #f4f4f5)",
                  margin: 0,
                  lineHeight: 1.2,
                }}
              >
                {stats?.total_failures ?? (useMock ? 8 : 0)}
              </p>
              <p
                className="text-xs mt-1"
                style={{ color: "var(--text-muted, #52525b)", margin: "4px 0 0 0" }}
              >
                Failures
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Template Button ───────────────────────────────────────────────────── */

function TemplateButton({
  label,
  description,
  onClick,
}: {
  label: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left group/tpl"
      style={{
        padding: "12px 16px",
        borderRadius: "var(--radius-md, 8px)",
        border: "1px solid var(--border-default, #1e1e1e)",
        backgroundColor: "var(--bg-surface, #0a0a0a)",
        cursor: "pointer",
        outline: "none",
        transition: "all var(--transition-fast, 150ms) ease",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "var(--border-hover, #333)";
        e.currentTarget.style.backgroundColor = "var(--bg-surface-hover, #111)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
        e.currentTarget.style.backgroundColor = "var(--bg-surface, #0a0a0a)";
      }}
    >
      <p
        className="text-sm font-medium"
        style={{
          color: "var(--text-primary, #f4f4f5)",
          margin: 0,
          lineHeight: 1.43,
        }}
      >
        {label}
      </p>
      <p
        className="text-xs overflow-hidden text-ellipsis whitespace-nowrap mt-0.5"
        style={{
          color: "var(--text-muted, #52525b)",
          margin: "2px 0 0 0",
          lineHeight: 1.33,
        }}
      >
        {description}
      </p>
    </button>
  );
}

/* ── Main Dashboard ────────────────────────────────────────────────────── */

export default function DashboardPage() {
  const router = useRouter();
  const [tasks, setTasks] = useState<TaskResponse[]>([]);
  const [stats, setStats] = useState<MemoryStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [instruction, setInstruction] = useState("");
  const [creating, setCreating] = useState(false);
  const [useMock, setUseMock] = useState(false);
  const [taskFilter, setTaskFilter] = useState("all");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [maxRetries, setMaxRetries] = useState(5);
  const [maxBudget, setMaxBudget] = useState(1.0);
  const [dashPredictions, setDashPredictions] = useState<PredictionResult[]>([]);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [t, s] = await Promise.all([fetchTasks(), fetchMemoryStats()]);
      setTasks(t);
      setStats(s);
      setUseMock(false);
      // Load predictions based on the most recent running/pending task
      const activeTask = t.find((tk) => tk.status === "running") ?? t[0];
      if (activeTask) {
        predictFailures(activeTask.instruction).then((preds) => {
          setDashPredictions(preds);
        }).catch(() => { /* ignore */ });
      }
    } catch {
      setTasks(getMockTasks());
      setUseMock(true);
      setDashPredictions([
        { error_type: "ModuleNotFoundError", prediction_score: 0.68, root_cause: "Missing npm dependency", suggested_prevention: "Run npm install sharp before build", based_on_failures: 3 },
        { error_type: "EADDRINUSE", prediction_score: 0.54, root_cause: "Port already occupied", suggested_prevention: "Use --port 3001 or kill existing process", based_on_failures: 2 },
        { error_type: "TS2322", prediction_score: 0.41, root_cause: "Type mismatch in auth module", suggested_prevention: "Add explicit type conversions for session IDs", based_on_failures: 2 },
      ]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  async function handleCreateTask() {
    if (!instruction.trim()) return;
    setCreating(true);
    try {
      if (useMock) {
        setDialogOpen(false);
        router.push("/tasks/demo001");
        return;
      }
      const task = await createTask({
        instruction: instruction.trim(),
        max_retries: maxRetries,
        max_budget_usd: maxBudget,
      });
      setDialogOpen(false);
      setInstruction("");
      router.push(`/tasks/${task.id}`);
    } catch {
      setDialogOpen(false);
      router.push("/tasks/demo001");
    } finally {
      setCreating(false);
    }
  }

  const totalCost = tasks.reduce((sum, t) => sum + t.total_cost_usd, 0);
  const totalFailures = stats?.total_failures ?? (useMock ? 8 : 0);
  const totalSuccesses =
    stats?.total_successes ??
    (useMock ? tasks.filter((t) => t.status === "succeeded").length : 0);
  const successRate =
    tasks.length > 0
      ? Math.round(
          (tasks.filter((t) => t.status === "succeeded").length / tasks.length) *
            100
        )
      : 0;

  const filteredTasks = useMemo(() => {
    if (taskFilter === "all") return tasks;
    return tasks.filter((t) => t.status === taskFilter);
  }, [tasks, taskFilter]);

  const filterCounts = useMemo(
    () => ({
      all: tasks.length,
      running: tasks.filter((t) => t.status === "running").length,
      succeeded: tasks.filter((t) => t.status === "succeeded").length,
      failed: tasks.filter((t) => t.status === "failed").length,
    }),
    [tasks]
  );

  const templates = [
    {
      label: "Fix broken build",
      description:
        "Resolve compilation errors, missing deps, and type issues",
      instruction:
        "Fix and deploy the broken Next.js project with missing dependencies and port conflicts",
    },
    {
      label: "Debug runtime error",
      description: "Investigate and fix a production runtime error",
      instruction:
        "Debug and fix the runtime error causing the application to crash on startup",
    },
    {
      label: "Resolve type errors",
      description:
        "Fix TypeScript strict mode violations across the codebase",
      instruction:
        "Resolve TypeScript type errors in the authentication module",
    },
  ];

  return (
    <AppShell
      navCenter={
        <>
          {/* Stats pills */}
          <div className="flex items-center gap-4 ml-2">
            <span
              className="inline-flex items-center gap-1.5 font-mono text-xs tabular-nums"
              style={{ color: "var(--text-muted, #52525b)" }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: "var(--text-secondary, #a1a1aa)" }}
              />
              {tasks.length} tasks
            </span>
            <span
              className="inline-flex items-center gap-1.5 font-mono text-xs tabular-nums"
              style={{ color: "var(--text-muted, #52525b)" }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: "var(--accent, #10b981)" }}
              />
              {totalFailures} rules
            </span>
            <span
              className="inline-flex items-center gap-1.5 font-mono text-xs tabular-nums"
              style={{ color: "var(--text-muted, #52525b)" }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: "var(--success, #10b981)" }}
              />
              {successRate}% success
            </span>
          </div>
          {useMock && (
            <div
              className="flex items-center gap-1.5 ml-3 text-[10px] font-semibold tracking-wider uppercase"
              style={{
                padding: "3px 10px",
                borderRadius: "var(--radius-md, 8px)",
                backgroundColor: "rgba(245,158,11,0.1)",
                color: "var(--warning, #f59e0b)",
                border: "1px solid rgba(245,158,11,0.2)",
              }}
            >
              <Zap className="w-3 h-3" />
              DEMO
            </div>
          )}
        </>
      }
      navRight={
        <>
          <button
            onClick={() => void loadData()}
            className="inline-flex items-center gap-1.5 text-sm font-medium"
            style={{
              padding: "7px 14px",
              borderRadius: "var(--radius-md, 8px)",
              border: "1px solid var(--border-default, #1e1e1e)",
              backgroundColor: "transparent",
              color: "var(--text-secondary, #a1a1aa)",
              cursor: "pointer",
              outline: "none",
              transition: "all var(--transition-fast, 150ms) ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = "var(--border-hover, #333)";
              e.currentTarget.style.backgroundColor = "var(--bg-surface-hover, #111)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
              e.currentTarget.style.backgroundColor = "transparent";
            }}
          >
            <RefreshCw
              className="w-3.5 h-3.5"
              style={{
                animation: loading ? "spin 1s linear infinite" : "none",
              }}
            />
            Refresh
          </button>
          <button
            onClick={() => setDialogOpen(true)}
            className="inline-flex items-center gap-1.5 text-sm font-medium"
            style={{
              padding: "7px 14px",
              borderRadius: "var(--radius-md, 8px)",
              border: "none",
              backgroundColor: "var(--accent, #10b981)",
              color: "#ffffff",
              cursor: "pointer",
              outline: "none",
              transition: "all var(--transition-fast, 150ms) ease",
              boxShadow: "var(--shadow-accent, 0 0 20px rgba(16,185,129,0.15))",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.filter = "brightness(1.1)";
              e.currentTarget.style.boxShadow = "0 0 28px rgba(16,185,129,0.25)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.filter = "none";
              e.currentTarget.style.boxShadow = "var(--shadow-accent, 0 0 20px rgba(16,185,129,0.15))";
            }}
          >
            <Plus className="w-3.5 h-3.5" />
            New Task
          </button>
        </>
      }
    >
      {/* ── Main content ───────────────────────────────────────────────── */}
      <main className="flex-1 overflow-y-auto">
        <div
          className="max-w-5xl mx-auto flex flex-col gap-8"
          style={{ padding: "32px 32px 48px" }}
        >
          {/* ── Header area ────────────────────────────────────────── */}
          <div>
            <h1
              className="text-2xl font-bold tracking-tight"
              style={{ color: "var(--text-primary, #f4f4f5)", margin: 0 }}
            >
              Dashboard
            </h1>
            <p
              className="text-sm mt-1"
              style={{ color: "var(--text-muted, #52525b)", margin: "4px 0 0 0" }}
            >
              Monitor tasks, track failure memory, and watch your agent get smarter.
            </p>
          </div>

          {/* ── Stats cards ─────────────────────────────────────────── */}
          <div className="grid grid-cols-4 gap-4">
            <StatCard
              label="Total Tasks"
              value={String(tasks.length)}
              icon={<Activity className="w-4 h-4" />}
              accentColor="#6366f1"
            />
            <StatCard
              label="Failures Learned"
              value={String(totalFailures)}
              icon={<Brain className="w-4 h-4" />}
              accentColor="#ef4444"
            />
            <StatCard
              label="Successes"
              value={String(totalSuccesses)}
              icon={<CheckCircle2 className="w-4 h-4" />}
              accentColor="#10b981"
            />
            <StatCard
              label="Total Spend"
              value={`$${totalCost.toFixed(2)}`}
              icon={<DollarSign className="w-4 h-4" />}
              accentColor="#f59e0b"
            />
          </div>

          {/* ── Predicted Risks ──────────────────────────────────────── */}
          {dashPredictions.length > 0 && (
            <div
              style={{
                borderRadius: "var(--radius-lg, 12px)",
                border: "1px solid rgba(245, 158, 11, 0.2)",
                backgroundColor: "rgba(245, 158, 11, 0.03)",
                overflow: "hidden",
              }}
            >
              <div
                className="flex items-center justify-between"
                style={{
                  padding: "14px 20px",
                  borderBottom: "1px solid rgba(245, 158, 11, 0.12)",
                }}
              >
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4" style={{ color: "#f59e0b" }} />
                  <h2
                    className="text-sm font-semibold tracking-tight"
                    style={{ color: "#f59e0b", margin: 0 }}
                  >
                    Predicted Risks
                  </h2>
                  <span
                    className="text-xs"
                    style={{ color: "rgba(245, 158, 11, 0.6)" }}
                  >
                    Proactive failure analysis from memory
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-0">
                {dashPredictions.map((pred, i) => (
                  <div
                    key={pred.error_type}
                    className="flex flex-col gap-2"
                    style={{
                      padding: "16px 20px",
                      borderRight:
                        i < dashPredictions.length - 1
                          ? "1px solid rgba(245, 158, 11, 0.08)"
                          : "none",
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className="font-mono text-sm"
                        style={{ color: "var(--text-primary, #f4f4f5)", fontWeight: 500 }}
                      >
                        {pred.error_type}
                      </span>
                      <span
                        className="font-mono text-lg tabular-nums"
                        style={{
                          color: pred.prediction_score > 0.6 ? "#f59e0b" : "var(--text-muted, #52525b)",
                          fontWeight: 700,
                        }}
                      >
                        {Math.round(pred.prediction_score * 100)}%
                      </span>
                    </div>
                    <div
                      className="w-full overflow-hidden"
                      style={{
                        height: 3,
                        backgroundColor: "rgba(255,255,255,0.04)",
                        borderRadius: 2,
                      }}
                    >
                      <div
                        style={{
                          height: "100%",
                          width: `${pred.prediction_score * 100}%`,
                          backgroundColor: "#f59e0b",
                          borderRadius: 2,
                          transition: "width 500ms ease",
                          boxShadow: "0 0 8px rgba(245, 158, 11, 0.3)",
                        }}
                      />
                    </div>
                    <p
                      className="text-xs"
                      style={{
                        color: "var(--text-muted, #52525b)",
                        margin: 0,
                        lineHeight: 1.5,
                      }}
                    >
                      {pred.suggested_prevention}
                    </p>
                    <span
                      className="text-[10px]"
                      style={{ color: "rgba(255,255,255,0.24)" }}
                    >
                      Based on {pred.based_on_failures} past failure{pred.based_on_failures !== 1 ? "s" : ""}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Task list ───────────────────────────────────────────── */}
          <div
            style={{
              borderRadius: "var(--radius-lg, 12px)",
              border: "1px solid var(--border-default, #1e1e1e)",
              backgroundColor: "var(--bg-surface, #0a0a0a)",
              overflow: "hidden",
            }}
          >
            {/* Section heading */}
            <div
              className="flex items-center justify-between"
              style={{
                padding: "16px 24px",
                borderBottom: "1px solid var(--border-default, #1e1e1e)",
              }}
            >
              <h2
                className="text-base font-semibold tracking-tight"
                style={{ color: "var(--text-primary, #f4f4f5)", margin: 0 }}
              >
                Tasks
              </h2>
              <div className="flex items-center gap-0.5">
                <FilterTab
                  label="All"
                  count={filterCounts.all}
                  active={taskFilter === "all"}
                  onClick={() => setTaskFilter("all")}
                />
                <FilterTab
                  label="Running"
                  count={filterCounts.running}
                  active={taskFilter === "running"}
                  onClick={() => setTaskFilter("running")}
                />
                <FilterTab
                  label="Succeeded"
                  count={filterCounts.succeeded}
                  active={taskFilter === "succeeded"}
                  onClick={() => setTaskFilter("succeeded")}
                />
                <FilterTab
                  label="Failed"
                  count={filterCounts.failed}
                  active={taskFilter === "failed"}
                  onClick={() => setTaskFilter("failed")}
                />
              </div>
            </div>

            {/* Task list content */}
            <div style={{ padding: "8px" }}>
              {loading ? (
                <div className="flex flex-col gap-2">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      style={{
                        padding: "16px 20px",
                        borderRadius: "var(--radius-md, 8px)",
                      }}
                    >
                      <div
                        className="animate-pulse"
                        style={{
                          height: 14,
                          backgroundColor: "rgba(255,255,255,0.04)",
                          borderRadius: 6,
                          width: "65%",
                        }}
                      />
                      <div className="flex gap-3 mt-3">
                        <div
                          className="animate-pulse"
                          style={{
                            height: 12,
                            backgroundColor: "rgba(255,255,255,0.03)",
                            borderRadius: 6,
                            width: 72,
                          }}
                        />
                        <div
                          className="animate-pulse"
                          style={{
                            height: 12,
                            backgroundColor: "rgba(255,255,255,0.03)",
                            borderRadius: 6,
                            width: 56,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 px-6">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: "rgba(255,255,255,0.03)" }}
                  >
                    <Zap
                      className="w-5 h-5"
                      style={{ color: "var(--text-muted, #52525b)" }}
                    />
                  </div>
                  <p
                    className="text-base font-semibold"
                    style={{
                      color: "var(--text-secondary, #a1a1aa)",
                      margin: 0,
                    }}
                  >
                    {taskFilter === "all"
                      ? "No tasks yet"
                      : `No ${taskFilter} tasks`}
                  </p>
                  <p
                    className="text-sm mt-1.5"
                    style={{
                      color: "var(--text-muted, #52525b)",
                      margin: "6px 0 0 0",
                    }}
                  >
                    {taskFilter === "all"
                      ? "Create your first task to watch ReLoop self-heal."
                      : "Try a different filter or create a new task."}
                  </p>
                  {taskFilter === "all" && (
                    <button
                      onClick={() => setDialogOpen(true)}
                      className="inline-flex items-center gap-1.5 mt-6 text-sm font-medium"
                      style={{
                        padding: "8px 16px",
                        borderRadius: "var(--radius-md, 8px)",
                        border: "none",
                        backgroundColor: "var(--accent, #10b981)",
                        color: "#ffffff",
                        cursor: "pointer",
                        outline: "none",
                        transition: "all var(--transition-fast, 150ms) ease",
                        boxShadow: "var(--shadow-accent, 0 0 20px rgba(16,185,129,0.15))",
                      }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Create first task
                    </button>
                  )}
                </div>
              ) : (
                <div className="flex flex-col gap-1.5">
                  {filteredTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onClick={() => router.push(`/tasks/${task.id}`)}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ── Memory Health ─────────────────────────────────────── */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2
                  className="text-base font-semibold tracking-tight"
                  style={{ color: "var(--text-primary, #f4f4f5)", margin: 0 }}
                >
                  Memory Health
                </h2>
                <p
                  className="text-sm mt-0.5"
                  style={{ color: "var(--text-muted, #52525b)", margin: "2px 0 0 0" }}
                >
                  Failure patterns, anti-patterns, and confidence metrics
                </p>
              </div>
            </div>
            <MemoryHealthSection stats={stats} useMock={useMock} />
          </div>
        </div>
      </main>

      {/* ── New Task Dialog ─────────────────────────────────────────── */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent
          className="sm:max-w-lg"
          style={{
            backgroundColor: "var(--bg-surface, #0a0a0a)",
            border: "1px solid var(--border-default, #1e1e1e)",
            borderRadius: "var(--radius-lg, 12px)",
            boxShadow: "0 24px 48px rgba(0,0,0,0.5)",
          }}
        >
          <DialogHeader>
            <DialogTitle
              className="flex items-center gap-3 text-lg font-semibold tracking-tight"
              style={{ color: "var(--text-primary, #f4f4f5)" }}
            >
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center"
                style={{
                  backgroundColor: "rgba(16,185,129,0.1)",
                  border: "1px solid rgba(16,185,129,0.2)",
                }}
              >
                <Zap className="w-4 h-4" style={{ color: "var(--accent, #10b981)" }} />
              </div>
              New Task
            </DialogTitle>
            <DialogDescription
              className="text-sm"
              style={{
                color: "var(--text-muted, #52525b)",
                lineHeight: 1.5,
              }}
            >
              Describe what the agent should accomplish. ReLoop will retry
              with accumulated failure memory until it succeeds.
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col gap-6">
            {/* Templates */}
            <div>
              <p
                className="text-xs font-semibold uppercase tracking-wider mb-3"
                style={{ color: "var(--text-muted, #52525b)", margin: "0 0 12px 0" }}
              >
                Quick Templates
              </p>
              <div className="flex flex-col gap-2">
                {templates.map((tpl) => (
                  <TemplateButton
                    key={tpl.label}
                    label={tpl.label}
                    description={tpl.description}
                    onClick={() => setInstruction(tpl.instruction)}
                  />
                ))}
              </div>
            </div>

            {/* Instruction textarea */}
            <div>
              <label
                className="block text-xs font-semibold uppercase tracking-wider"
                style={{
                  color: "var(--text-muted, #52525b)",
                  marginBottom: 8,
                }}
              >
                Instruction
              </label>
              <textarea
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                placeholder="e.g. Fix and deploy the broken Next.js project with missing dependencies..."
                className="w-full resize-none outline-none box-border text-sm"
                style={{
                  height: 100,
                  backgroundColor: "rgba(255,255,255,0.03)",
                  border: "1px solid var(--border-default, #1e1e1e)",
                  borderRadius: "var(--radius-md, 8px)",
                  padding: "12px 14px",
                  color: "var(--text-secondary, #a1a1aa)",
                  lineHeight: 1.5,
                  transition: "border-color var(--transition-fast, 150ms) ease",
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = "var(--accent, #10b981)";
                  e.currentTarget.style.boxShadow = "0 0 0 1px var(--accent, #10b981)";
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
                  e.currentTarget.style.boxShadow = "none";
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                    void handleCreateTask();
                  }
                }}
              />
            </div>

            {/* Advanced options */}
            <div>
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center gap-1.5 p-0 outline-none text-sm font-medium"
                style={{
                  color: "var(--accent, #10b981)",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ChevronDown
                  className="w-3.5 h-3.5 transition-transform duration-200"
                  style={{
                    transform: showAdvanced ? "rotate(180deg)" : "none",
                  }}
                />
                Advanced Options
              </button>

              {showAdvanced && (
                <div className="grid grid-cols-2 gap-4 mt-3">
                  <div>
                    <label
                      className="block text-xs font-semibold"
                      style={{
                        color: "var(--text-muted, #52525b)",
                        marginBottom: 6,
                      }}
                    >
                      Max Retries
                    </label>
                    <input
                      type="number"
                      value={maxRetries}
                      onChange={(e) =>
                        setMaxRetries(Number(e.target.value))
                      }
                      min={1}
                      max={20}
                      className="w-full outline-none box-border text-sm"
                      style={{
                        height: 36,
                        backgroundColor: "rgba(255,255,255,0.03)",
                        border: "1px solid var(--border-default, #1e1e1e)",
                        borderRadius: "var(--radius-md, 8px)",
                        padding: "0 12px",
                        color: "var(--text-primary, #f4f4f5)",
                        transition: "border-color var(--transition-fast, 150ms) ease",
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = "var(--accent, #10b981)";
                        e.currentTarget.style.boxShadow = "0 0 0 1px var(--accent, #10b981)";
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
                        e.currentTarget.style.boxShadow = "none";
                      }}
                    />
                  </div>
                  <div>
                    <label
                      className="block text-xs font-semibold"
                      style={{
                        color: "var(--text-muted, #52525b)",
                        marginBottom: 6,
                      }}
                    >
                      Max Budget (USD)
                    </label>
                    <input
                      type="number"
                      value={maxBudget}
                      onChange={(e) =>
                        setMaxBudget(Number(e.target.value))
                      }
                      min={0.1}
                      max={100}
                      step={0.1}
                      className="w-full outline-none box-border text-sm"
                      style={{
                        height: 36,
                        backgroundColor: "rgba(255,255,255,0.03)",
                        border: "1px solid var(--border-default, #1e1e1e)",
                        borderRadius: "var(--radius-md, 8px)",
                        padding: "0 12px",
                        color: "var(--text-primary, #f4f4f5)",
                        transition: "border-color var(--transition-fast, 150ms) ease",
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = "var(--accent, #10b981)";
                        e.currentTarget.style.boxShadow = "0 0 0 1px var(--accent, #10b981)";
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = "var(--border-default, #1e1e1e)";
                        e.currentTarget.style.boxShadow = "none";
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <div className="flex items-center justify-between w-full">
              <div
                className="flex items-center gap-1 text-xs"
                style={{ color: "var(--text-muted, #52525b)" }}
              >
                <Command className="w-3 h-3" />
                <span>+ Enter to submit</span>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setDialogOpen(false)}
                  className="text-sm font-medium"
                  style={{
                    padding: "8px 16px",
                    borderRadius: "var(--radius-md, 8px)",
                    border: "1px solid var(--border-default, #1e1e1e)",
                    backgroundColor: "transparent",
                    color: "var(--text-secondary, #a1a1aa)",
                    cursor: "pointer",
                    outline: "none",
                    transition: "all var(--transition-fast, 150ms) ease",
                  }}
                >
                  Cancel
                </button>
                <button
                  disabled={!instruction.trim() || creating}
                  onClick={() => void handleCreateTask()}
                  className="inline-flex items-center gap-1.5 justify-center text-sm font-medium"
                  style={{
                    padding: "8px 16px",
                    borderRadius: "var(--radius-md, 8px)",
                    border: "none",
                    backgroundColor:
                      !instruction.trim() || creating
                        ? "rgba(16,185,129,0.3)"
                        : "var(--accent, #10b981)",
                    color: "#ffffff",
                    cursor:
                      !instruction.trim() || creating
                        ? "not-allowed"
                        : "pointer",
                    outline: "none",
                    minWidth: 100,
                    transition: "all var(--transition-fast, 150ms) ease",
                    boxShadow:
                      !instruction.trim() || creating
                        ? "none"
                        : "var(--shadow-accent, 0 0 20px rgba(16,185,129,0.15))",
                  }}
                >
                  {creating ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  )}
                  {creating ? "Creating..." : "Run Task"}
                </button>
              </div>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Keyframe for spinner */}
      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </AppShell>
  );
}
