"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import {
  Play,
  Brain,
  BrainCircuit,
  XCircle,
  CheckCircle2,
  Clock,
  DollarSign,
  Zap,
  TrendingDown,
  AlertCircle,
  Loader2,
  ShieldAlert,
  Lightbulb,
  ArrowRight,
  Package,
  Plug,
  Globe,
  Trophy,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { runABComparison, fetchTask } from "@/lib/api";
import type { Task, Attempt } from "@/lib/types";

/* ── colour tokens ─────────────────────────────────────────────────────── */

const C = {
  bg: "#000000",
  surface: "#0a0a0a",
  surfaceRaised: "#111111",
  border: "#1e1e1e",
  borderHover: "#333333",
  text: "#f4f4f5",
  textSecondary: "#a1a1aa",
  textMuted: "#52525b",
  accent: "#10b981",
  accentGlow: "rgba(16,185,129,0.15)",
  danger: "#ef4444",
  dangerGlow: "rgba(239,68,68,0.10)",
  dangerSubtle: "rgba(239,68,68,0.06)",
  warning: "#f59e0b",
  warningGlow: "rgba(245,158,11,0.10)",
  success: "#10b981",
  successGlow: "rgba(16,185,129,0.10)",
  successSubtle: "rgba(16,185,129,0.06)",
  blue: "#2997ff",
  blueGlow: "rgba(0,113,227,0.12)",
} as const;

/* ── Presets ─────────────────────────────────────────────────────────────── */

const PRESETS = [
  {
    label: "Express App",
    icon: Globe,
    instruction:
      "Install express, create server.js with GET /health returning {status:'ok'} and GET /users returning an array of 3 users. Start on port 3000 and verify with node -e \"require('http').get('http://localhost:3000/health', r => { let d=''; r.on('data',c=>d+=c); r.on('end',()=>console.log(d)) })\"",
  },
  {
    label: "TypeScript Build",
    icon: Package,
    instruction:
      "Run: npm init -y && npm install typescript && mkdir -p src && create src/index.ts with a User interface (id: number, name: string) and a getUser function returning a User. Create tsconfig.json with strict:true and outDir:dist. Compile with npx tsc.",
  },
  {
    label: "Config Server",
    icon: Plug,
    instruction:
      "Create a Node.js HTTP server in server.js that reads port from config.json. First create config.json with {\"port\":4000}. The server should respond to any request with the config as JSON. Start it and verify with node -e \"require('http').get('http://localhost:4000', r=>{let d='';r.on('data',c=>d+=c);r.on('end',()=>console.log(d))})\"",
  },
  {
    label: "Test Suite",
    icon: CheckCircle2,
    instruction:
      "Create calculator.js exporting add(a,b), subtract(a,b), multiply(a,b), divide(a,b) functions. divide should throw on zero. Write test.js with assert module testing all 4 functions including edge cases. Run with node test.js.",
  },
] as const;

/* ── Attempt timeline node ──────────────────────────────────────────────── */

interface AttemptNodeProps {
  attempt: Attempt;
  index: number;
  maxIndex: number;
  showMemory: boolean;
}

function AttemptNode({
  attempt,
  index,
  maxIndex,
  showMemory,
}: AttemptNodeProps) {
  const isFailed = attempt.status === "failed";
  const isSuccess = attempt.status === "succeeded";
  const hasMemory = showMemory && attempt.recalled_memories.length > 0;

  const statusColor = isSuccess ? C.success : isFailed ? C.danger : C.warning;
  const statusBg = isSuccess ? C.successGlow : isFailed ? C.dangerGlow : C.warningGlow;

  return (
    <div className="flex items-center" style={{ animationDelay: `${index * 80}ms` }}>
      <div className="flex flex-col items-center gap-2 relative">
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200"
          style={{
            backgroundColor: statusBg,
            border: `1.5px solid ${statusColor}30`,
          }}
        >
          {isSuccess ? (
            <CheckCircle2 className="h-4 w-4" style={{ color: statusColor }} />
          ) : isFailed ? (
            <XCircle className="h-4 w-4" style={{ color: statusColor }} />
          ) : (
            <Loader2 className="h-4 w-4 animate-spin" style={{ color: statusColor }} />
          )}
        </div>

        <span
          className="font-mono uppercase"
          style={{
            color: statusColor,
            fontSize: 10,
            fontWeight: 500,
            letterSpacing: "0.06em",
          }}
        >
          {isSuccess ? "PASS" : isFailed ? "FAIL" : "RUN"}
        </span>

        {hasMemory && (
          <div className="absolute -top-1 -right-1">
            <div
              className="w-4 h-4 rounded-full flex items-center justify-center"
              style={{ backgroundColor: C.blueGlow, border: `1px solid ${C.blue}30` }}
            >
              <Brain className="h-2.5 w-2.5" style={{ color: C.blue }} />
            </div>
          </div>
        )}
      </div>

      {index < maxIndex && (
        <div className="mx-1.5">
          <div className="h-px w-5" style={{ backgroundColor: C.border }} />
        </div>
      )}
    </div>
  );
}

/* ── Skeleton timeline ──────────────────────────────────────────────────── */

function SkeletonTimeline() {
  return (
    <div className="flex items-center gap-0">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="flex items-center">
          <div className="flex flex-col items-center gap-2">
            <div
              className="w-9 h-9 rounded-full animate-pulse"
              style={{ backgroundColor: `${C.text}08` }}
            />
            <div
              className="h-1.5 w-5 rounded animate-pulse"
              style={{ backgroundColor: `${C.text}08` }}
            />
          </div>
          {i < 3 && (
            <div
              className="h-px w-5 mx-1.5"
              style={{ backgroundColor: `${C.text}06` }}
            />
          )}
        </div>
      ))}
    </div>
  );
}

/* ── Memory callout ─────────────────────────────────────────────────────── */

function MemoryCallout({ count }: { count: number }) {
  return (
    <div
      className="inline-flex items-center gap-2 px-3 py-1.5"
      style={{
        backgroundColor: C.blueGlow,
        borderRadius: 8,
        border: `1px solid ${C.blue}20`,
      }}
    >
      <BrainCircuit className="h-3.5 w-3.5 shrink-0" style={{ color: C.blue }} />
      <span style={{ color: C.blue, fontSize: 12, fontWeight: 500, letterSpacing: "-0.12px" }}>
        Recalled {count} past failure{count !== 1 ? "s" : ""}
      </span>
    </div>
  );
}

function SkippedErrorLabel() {
  return (
    <div
      className="inline-flex items-center gap-1.5 px-3 py-1.5"
      style={{
        backgroundColor: C.successGlow,
        borderRadius: 8,
        border: `1px solid ${C.success}20`,
      }}
    >
      <Lightbulb className="h-3 w-3 shrink-0" style={{ color: C.success }} />
      <span style={{ color: C.success, fontSize: 12, fontWeight: 500, letterSpacing: "-0.12px" }}>
        Skipped known error
      </span>
    </div>
  );
}

/* ── Side panel ─────────────────────────────────────────────────────────── */

interface SidePanelProps {
  side: "left" | "right";
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  showMemory: boolean;
  task: Task | null;
  isRunning: boolean;
  isDone: boolean;
}

function SidePanel({
  side,
  title,
  subtitle,
  icon,
  showMemory,
  task,
  isRunning,
  isDone,
}: SidePanelProps) {
  const attempts = task?.attempts ?? [];
  const totalCost = task?.total_cost_usd ?? 0;
  const succeeded = task?.status === "succeeded";
  const isLeft = side === "left";
  const sideColor = isLeft ? C.danger : C.success;
  const sideBg = isLeft ? C.dangerSubtle : C.successSubtle;

  const totalMemories = attempts.reduce(
    (sum, a) => sum + a.recalled_memories.length,
    0
  );

  return (
    <div
      className="relative flex-1 flex flex-col min-w-0 overflow-hidden"
      style={{ backgroundColor: C.surface }}
    >
      {/* Top accent bar -- red for left, green for right */}
      <div
        style={{
          height: 3,
          background: `linear-gradient(90deg, ${sideColor}60, ${sideColor}20)`,
        }}
      />

      <div className="relative z-10 flex flex-col h-full p-5 lg:p-6 space-y-5">
        {/* Panel header */}
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{
                backgroundColor: sideBg,
                border: `1.5px solid ${sideColor}20`,
              }}
            >
              {icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2.5">
                <h2
                  style={{
                    color: C.text,
                    fontWeight: 600,
                    fontSize: 16,
                    letterSpacing: "-0.3px",
                    lineHeight: 1.3,
                  }}
                >
                  {title}
                </h2>
                {isRunning && (
                  <span
                    className="animate-pulse"
                    style={{
                      backgroundColor: C.warningGlow,
                      color: C.warning,
                      fontSize: 10,
                      fontWeight: 600,
                      padding: "2px 8px",
                      borderRadius: 10,
                      letterSpacing: "0.04em",
                    }}
                  >
                    LIVE
                  </span>
                )}
                {isDone && task && (
                  <span
                    style={{
                      fontSize: 10,
                      fontWeight: 600,
                      padding: "2px 8px",
                      borderRadius: 10,
                      letterSpacing: "0.04em",
                      backgroundColor: succeeded ? C.successGlow : C.dangerGlow,
                      color: succeeded ? C.success : C.danger,
                      border: `1px solid ${succeeded ? C.success : C.danger}20`,
                    }}
                  >
                    {succeeded ? "SUCCESS" : "FAILED"}
                  </span>
                )}
              </div>
              <p style={{ color: C.textMuted, fontSize: 12, marginTop: 2, letterSpacing: "-0.12px" }}>
                {subtitle}
              </p>
            </div>
          </div>
        </div>

        {/* Phase indicator when running */}
        {isRunning && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span
                className="uppercase font-mono"
                style={{ color: C.textMuted, fontSize: 10, fontWeight: 600, letterSpacing: "0.06em" }}
              >
                {attempts.length === 0
                  ? "Initializing"
                  : `Attempt ${attempts.length}`}
              </span>
              <span className="font-mono animate-pulse" style={{ color: C.warning, fontSize: 11 }}>
                {attempts.length === 0
                  ? "creating sandbox..."
                  : attempts[attempts.length - 1]?.status === "failed"
                  ? "retrying with context..."
                  : "executing in sandbox..."}
              </span>
            </div>
            <div
              className="h-0.5 rounded-full overflow-hidden"
              style={{ backgroundColor: `${C.text}0a` }}
            >
              <div
                className="h-full w-1/4 rounded-full animate-progress"
                style={{ backgroundColor: `${sideColor}60` }}
              />
            </div>
          </div>
        )}

        {/* Timeline nodes */}
        <div className="flex items-center gap-0 flex-wrap py-1">
          {attempts.length > 0 ? (
            <>
              {attempts.map((attempt, idx) => (
                <AttemptNode
                  key={attempt.attempt_number}
                  attempt={attempt}
                  index={idx}
                  maxIndex={attempts.length - 1 + (isRunning ? 1 : 0)}
                  showMemory={showMemory}
                />
              ))}
              {isRunning && (
                <div className="flex items-center">
                  <div className="mx-1.5">
                    <div className="h-px w-5" style={{ backgroundColor: C.border }} />
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: C.warningGlow, border: `1.5px dashed ${C.warning}30` }}
                    >
                      <Loader2 className="h-4 w-4 animate-spin" style={{ color: C.warning }} />
                    </div>
                    <span className="font-mono uppercase" style={{ color: C.warning, fontSize: 10, fontWeight: 500, letterSpacing: "0.06em" }}>
                      NEXT
                    </span>
                  </div>
                </div>
              )}
            </>
          ) : isRunning ? (
            <SkeletonTimeline />
          ) : (
            <span className="font-mono" style={{ color: C.textMuted, fontSize: 12 }}>
              Waiting for run...
            </span>
          )}
        </div>

        {/* Memory annotations */}
        {showMemory && (isDone || isRunning) && attempts.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {totalMemories > 0 && <MemoryCallout count={totalMemories} />}
            {attempts.length < 4 && succeeded && <SkippedErrorLabel />}
          </div>
        )}

        {/* Attempt log -- detail cards */}
        <div className="space-y-2.5 flex-1 min-h-[60px] overflow-y-auto">
          {isRunning && attempts.length === 0 ? (
            <div className="space-y-2">
              <div
                className="px-3 py-3"
                style={{
                  backgroundColor: C.surfaceRaised,
                  borderRadius: 12,
                  border: `1px solid ${C.border}`,
                }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Loader2 className="h-3 w-3 animate-spin" style={{ color: C.warning }} />
                  <span className="font-mono" style={{ color: C.warning, fontSize: 11 }}>
                    Creating sandbox environment...
                  </span>
                </div>
                <div className="h-1 rounded-full overflow-hidden" style={{ backgroundColor: `${C.text}08` }}>
                  <div className="h-full w-1/3 rounded-full animate-progress" style={{ backgroundColor: `${C.warning}40` }} />
                </div>
              </div>
              {Array.from({ length: 2 }).map((_, i) => (
                <div
                  key={i}
                  className="h-12 animate-pulse"
                  style={{ backgroundColor: `${C.text}04`, borderRadius: 12 }}
                />
              ))}
            </div>
          ) : (
            attempts.map((attempt) => {
              const memApplied = showMemory && attempt.recalled_memories.length > 0;
              const isOk = attempt.status === "succeeded";
              const stepCount = attempt.steps.length;
              const costStr = attempt.cost_usd > 0 ? `$${attempt.cost_usd.toFixed(4)}` : "";
              const cardBorder = isOk ? C.success : C.danger;

              return (
                <div
                  key={attempt.attempt_number}
                  className="font-mono"
                  style={{
                    backgroundColor: C.surfaceRaised,
                    borderRadius: 12,
                    border: `1px solid ${C.border}`,
                    borderLeftWidth: 3,
                    borderLeftColor: cardBorder,
                    animation: "fadeSlideIn 0.3s ease-out",
                    transition: "border-color 150ms ease",
                  }}
                >
                  {/* Header row */}
                  <div className="flex items-center gap-2 px-3.5 pt-3 pb-1.5">
                    <span
                      className="shrink-0 uppercase"
                      style={{
                        color: isOk ? C.success : C.danger,
                        fontSize: 10,
                        fontWeight: 600,
                        letterSpacing: "0.06em",
                      }}
                    >
                      Attempt {attempt.attempt_number}
                    </span>
                    <span
                      className="px-2 py-0.5 rounded-md"
                      style={{
                        backgroundColor: isOk ? C.successGlow : C.dangerGlow,
                        color: isOk ? C.success : C.danger,
                        fontSize: 9,
                        fontWeight: 600,
                        letterSpacing: "0.04em",
                        border: `1px solid ${isOk ? C.success : C.danger}15`,
                      }}
                    >
                      {isOk ? "PASS" : "FAIL"}
                    </span>
                    {memApplied && (
                      <span
                        className="flex items-center gap-1 px-2 py-0.5 rounded-md"
                        style={{
                          backgroundColor: C.blueGlow,
                          fontSize: 9,
                          color: C.blue,
                          border: `1px solid ${C.blue}15`,
                        }}
                      >
                        <Brain className="h-2 w-2" />
                        {attempt.recalled_memories.length} memories
                      </span>
                    )}
                    <span className="ml-auto" style={{ color: C.textMuted, fontSize: 10 }}>
                      {stepCount} step{stepCount !== 1 ? "s" : ""}
                      {costStr && <> &middot; {costStr}</>}
                    </span>
                  </div>

                  {/* Step details */}
                  <div className="px-3.5 pb-3 space-y-1.5">
                    {attempt.steps.map((step) => {
                      const stepOk = step.status === "succeeded";
                      const errorText = step.error || (!stepOk ? step.output : null);
                      const displayError = errorText
                        ? errorText.length > 200 ? errorText.slice(0, 200) + "..." : errorText
                        : null;
                      const displayOutput = step.output
                        ? step.output.length > 120 ? step.output.slice(0, 120) + "..." : step.output
                        : null;

                      return (
                        <div key={step.step_number}>
                          {step.command && (
                            <div
                              className="px-2.5 py-1.5 rounded-md"
                              style={{
                                backgroundColor: `${C.text}05`,
                                fontSize: 10,
                                color: C.textSecondary,
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                              }}
                            >
                              <span style={{ color: C.textMuted }}>$ </span>
                              {step.command.length > 80
                                ? step.command.replace(/^#[^\n]*\n/gm, "").slice(0, 80) + "..."
                                : step.command.replace(/^#[^\n]*\n/gm, "")}
                            </div>
                          )}
                          {stepOk && displayOutput && (
                            <div
                              className="mt-1 px-2.5 py-1.5 rounded-md"
                              style={{
                                backgroundColor: C.successSubtle,
                                fontSize: 10,
                                color: `${C.success}b0`,
                                lineHeight: 1.5,
                                wordBreak: "break-all",
                              }}
                            >
                              {displayOutput}
                            </div>
                          )}
                          {!stepOk && displayError && (
                            <div
                              className="mt-1 px-2.5 py-1.5 rounded-md"
                              style={{
                                backgroundColor: C.dangerSubtle,
                                fontSize: 10,
                                color: `${C.danger}b0`,
                                lineHeight: 1.5,
                                wordBreak: "break-all",
                              }}
                            >
                              {displayError}
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {attempt.steps.length === 0 && (
                      <div style={{ fontSize: 10, color: C.textMuted }}>
                        No step details available
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}

          {/* Live processing indicator at bottom when running */}
          {isRunning && attempts.length > 0 && (
            <div
              className="flex items-center gap-2 px-3.5 py-2.5"
              style={{
                backgroundColor: C.warningGlow,
                borderRadius: 12,
                border: `1px dashed ${C.warning}25`,
              }}
            >
              <Loader2 className="h-3 w-3 animate-spin shrink-0" style={{ color: C.warning }} />
              <span style={{ color: C.warning, fontSize: 11 }}>
                Processing next attempt...
              </span>
            </div>
          )}
        </div>

        {/* Stats row */}
        <div className="mt-auto space-y-3">
          <div style={{ height: 1, backgroundColor: C.border }} />
          <div className="grid grid-cols-3 gap-3">
            {[
              {
                label: "ATTEMPTS",
                value: attempts.length > 0
                  ? attempts.length
                  : isRunning
                  ? null
                  : null,
                color: succeeded ? C.success : isRunning ? C.warning : C.danger,
              },
              {
                label: "COST",
                value: attempts.length > 0
                  ? `$${totalCost.toFixed(3)}`
                  : isRunning
                  ? null
                  : null,
                color: C.text,
              },
              {
                label: "RESULT",
                value: isRunning
                  ? "LIVE"
                  : task
                  ? succeeded
                    ? "WIN"
                    : "STUCK"
                  : null,
                color: isRunning ? C.warning : succeeded ? C.success : C.danger,
              },
            ].map((stat) => (
              <div
                key={stat.label}
                className="space-y-1 p-2.5 rounded-lg"
                style={{ backgroundColor: `${C.text}04` }}
              >
                <p
                  className="uppercase font-mono"
                  style={{ color: C.textMuted, fontSize: 10, fontWeight: 600, letterSpacing: "0.06em" }}
                >
                  {stat.label}
                </p>
                {stat.value !== null ? (
                  <p
                    className="font-mono"
                    style={{ color: stat.color, fontWeight: 600, fontSize: 20, letterSpacing: "-0.3px", lineHeight: 1.2 }}
                  >
                    {stat.value}
                  </p>
                ) : (
                  <div
                    className="h-6 w-10 animate-pulse rounded-md"
                    style={{ backgroundColor: `${C.text}06` }}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Summary stat card ──────────────────────────────────────────────────── */

function SummaryCard({
  icon,
  label,
  value,
  sub,
  color,
  highlight,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  color: string;
  highlight?: boolean;
}) {
  return (
    <div
      className="relative overflow-hidden p-5 text-center rounded-xl transition-all duration-200"
      style={{
        backgroundColor: highlight ? `${color}08` : C.surfaceRaised,
        border: `1px solid ${highlight ? `${color}30` : C.border}`,
        boxShadow: highlight ? `0 0 30px ${color}10` : "none",
      }}
    >
      <div className="flex justify-center mb-2.5">{icon}</div>
      <p
        className="font-mono tracking-tight"
        style={{ color, fontWeight: 700, fontSize: 24, lineHeight: 1.15, letterSpacing: "-0.5px" }}
      >
        {value}
      </p>
      <p
        className="mt-1.5"
        style={{ color: C.text, fontSize: 13, fontWeight: 500, letterSpacing: "-0.2px" }}
      >
        {label}
      </p>
      <p className="mt-1 font-mono" style={{ color: C.textMuted, fontSize: 11, letterSpacing: "-0.1px" }}>
        {sub}
      </p>
    </div>
  );
}

/* ── Main page ──────────────────────────────────────────────────────────── */

type RunState = "idle" | "running" | "done" | "error";

export default function ABPage() {
  const [runState, setRunState] = useState<RunState>("idle");
  const [instruction, setInstruction] = useState<string>(PRESETS[0].instruction);
  const [withoutTask, setWithoutTask] = useState<Task | null>(null);
  const [withTask, setWithTask] = useState<Task | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (runState === "running") {
      timerRef.current = setInterval(() => {
        setElapsed((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [runState]);

  useEffect(() => {
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, []);

  const handleStart = useCallback(async () => {
    if (!instruction.trim()) return;

    setElapsed(0);
    setRunState("running");
    setWithoutTask(null);
    setWithTask(null);
    setErrorMsg(null);

    // Clean up any previous poll
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }

    try {
      // This now returns immediately with task IDs
      const result = await runABComparison(instruction.trim());
      const noMemId = result.without_memory.task_id;
      const withMemId = result.with_memory.task_id;

      // Poll both tasks every 1.5 seconds for snappy live updates
      const poll = setInterval(async () => {
        try {
          const [noMemTask, withMemTask] = await Promise.all([
            fetchTask(noMemId),
            fetchTask(withMemId),
          ]);

          setWithoutTask(noMemTask);
          setWithTask(withMemTask);

          // Stop polling when both tasks reach a terminal state
          const terminal = ["succeeded", "failed", "abandoned"];
          const noMemDone = terminal.includes(noMemTask.status);
          const withMemDone = terminal.includes(withMemTask.status);

          if (noMemDone && withMemDone) {
            clearInterval(poll);
            pollRef.current = null;
            setRunState("done");
          }
        } catch {
          // Ignore individual poll errors -- keep polling
        }
      }, 1500);

      pollRef.current = poll;
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Unknown error");
      setRunState("error");
    }
  }, [instruction]);

  const isRunning = runState === "running";
  const isDone = runState === "done";
  const isIdle = runState === "idle";

  const withoutAttempts = withoutTask?.attempts.length ?? 0;
  const withAttempts = withTask?.attempts.length ?? 0;
  const savedAttempts = withoutAttempts - withAttempts;
  const withoutCost = withoutTask?.total_cost_usd ?? 0;
  const withCost = withTask?.total_cost_usd ?? 0;
  const savedCost = withoutCost - withCost;
  const memorySucceeded = withTask?.status === "succeeded";

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return m > 0
      ? `${m}:${sec.toString().padStart(2, "0")}`
      : `${sec}s`;
  };

  return (
    <AppShell
      navCenter={
        <div className="flex items-center gap-3">
          <span className="font-mono" style={{ color: C.textMuted, fontSize: 12, letterSpacing: "-0.12px" }}>
            Memory vs No Memory
          </span>
        </div>
      }
      navRight={
        <>
          {isRunning && (
            <div className="flex items-center gap-2 font-mono" style={{ fontSize: 12 }}>
              <Clock className="h-3 w-3" style={{ color: C.warning }} />
              <span style={{ color: C.warning }}>{formatTime(elapsed)}</span>
            </div>
          )}
          <button
            style={{
              backgroundColor: isRunning ? C.surfaceRaised : C.accent,
              color: isRunning ? C.textMuted : "#ffffff",
              fontSize: 13,
              fontWeight: 500,
              padding: "6px 16px",
              borderRadius: 8,
              border: isRunning ? `1px solid ${C.border}` : "none",
              cursor: isRunning ? "not-allowed" : "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
              letterSpacing: "-0.2px",
              transition: "all 150ms ease",
            }}
            disabled={isRunning}
            onClick={() => void handleStart()}
          >
            {isRunning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
            {isRunning ? "Running..." : isDone ? "Run Again" : "Start Comparison"}
          </button>
        </>
      }
    >
      {/* ── Task input + presets ──────────────────────────────────────── */}
      <div style={{ backgroundColor: C.bg, borderBottom: `1px solid ${C.border}` }}>
        <div className="px-5 py-3 space-y-3">
          <div className="flex items-center gap-3">
            <Zap className="h-3.5 w-3.5 shrink-0" style={{ color: C.textMuted }} />
            <span className="shrink-0" style={{ color: C.text, fontWeight: 600, fontSize: 13, letterSpacing: "-0.2px" }}>
              Task:
            </span>
            <input
              type="text"
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              disabled={isRunning}
              className="flex-1 bg-transparent outline-none disabled:opacity-50 font-mono"
              style={{ color: C.textSecondary, fontSize: 13, letterSpacing: "-0.15px" }}
              placeholder="Enter task instruction..."
            />
          </div>

          <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
            <span
              className="uppercase shrink-0 font-mono"
              style={{ color: C.textMuted, fontSize: 10, fontWeight: 600, letterSpacing: "0.06em" }}
            >
              Presets:
            </span>
            {PRESETS.map((preset) => {
              const Icon = preset.icon;
              const isActive = instruction === preset.instruction;
              return (
                <button
                  key={preset.label}
                  disabled={isRunning}
                  onClick={() => setInstruction(preset.instruction)}
                  title={preset.instruction}
                  className="flex items-center gap-1.5 shrink-0 disabled:opacity-50"
                  style={{
                    backgroundColor: isActive ? C.accentGlow : C.surfaceRaised,
                    color: isActive ? C.accent : C.textSecondary,
                    fontSize: 12,
                    fontWeight: 500,
                    padding: "5px 12px",
                    borderRadius: 8,
                    border: isActive ? `1px solid ${C.accent}30` : `1px solid ${C.border}`,
                    cursor: isRunning ? "not-allowed" : "pointer",
                    letterSpacing: "-0.12px",
                    transition: "all 150ms ease",
                  }}
                >
                  <Icon className="h-3 w-3" />
                  {preset.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Running progress bar ─────────────────────────────────────── */}
      {isRunning && (
        <div
          className="px-5 py-2.5"
          style={{ backgroundColor: C.surface, borderBottom: `1px solid ${C.border}` }}
        >
          <div className="flex items-center gap-3" style={{ fontSize: 12, letterSpacing: "-0.12px" }}>
            <div className="flex items-center gap-2" style={{ color: C.warning }}>
              <Loader2 className="h-3.5 w-3.5 animate-spin shrink-0" />
              <span style={{ fontWeight: 600 }}>
                Running both agents in parallel
              </span>
            </div>
            <ArrowRight className="h-3 w-3" style={{ color: C.textMuted }} />
            <span className="font-mono" style={{ color: C.textMuted }}>
              {(() => {
                const noMemAttempts = withoutTask?.attempts.length ?? 0;
                const withMemAttempts = withTask?.attempts.length ?? 0;
                if (noMemAttempts === 0 && withMemAttempts === 0) return "Initializing sandboxes...";
                const parts: string[] = [];
                if (withoutTask && !["succeeded", "failed", "abandoned"].includes(withoutTask.status))
                  parts.push(`No-mem: attempt ${noMemAttempts}`);
                else if (withoutTask)
                  parts.push(`No-mem: ${withoutTask.status}`);
                if (withTask && !["succeeded", "failed", "abandoned"].includes(withTask.status))
                  parts.push(`Memory: attempt ${withMemAttempts}`);
                else if (withTask)
                  parts.push(`Memory: ${withTask.status}`);
                return parts.join(" | ") || "Executing...";
              })()}
            </span>
            <span className="ml-auto font-mono" style={{ color: C.textMuted }}>
              {formatTime(elapsed)}
            </span>
          </div>
        </div>
      )}

      {/* ── Error banner ─────────────────────────────────────────────── */}
      {runState === "error" && errorMsg && (
        <div
          className="px-5 py-2.5"
          style={{ backgroundColor: C.dangerSubtle, borderBottom: `1px solid ${C.danger}20` }}
        >
          <div className="flex items-center gap-2.5" style={{ fontSize: 12, color: C.danger, letterSpacing: "-0.12px" }}>
            <ShieldAlert className="h-3.5 w-3.5 shrink-0" />
            <span className="font-mono flex-1">{errorMsg}</span>
            <button
              style={{
                color: "#ffffff",
                backgroundColor: C.danger,
                fontSize: 12,
                fontWeight: 500,
                padding: "4px 14px",
                borderRadius: 8,
                border: "none",
                cursor: "pointer",
                letterSpacing: "-0.12px",
              }}
              onClick={() => void handleStart()}
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* ── Idle state -- cinematic hero ─────────────────────────────── */}
      {isIdle && (
        <div className="flex-1 flex items-center justify-center px-5" style={{ minHeight: "60vh" }}>
          <div className="text-center space-y-8 max-w-lg">
            {/* Icon pair with VS divider */}
            <div className="flex items-center justify-center gap-8">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{
                  backgroundColor: C.dangerSubtle,
                  border: `1.5px solid ${C.danger}20`,
                  boxShadow: `0 0 40px ${C.danger}08`,
                }}
              >
                <XCircle className="h-6 w-6" style={{ color: `${C.danger}80` }} />
              </div>
              <span
                className="font-mono"
                style={{ color: C.textMuted, fontSize: 11, fontWeight: 600, letterSpacing: "0.1em" }}
              >
                VS
              </span>
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{
                  backgroundColor: C.successSubtle,
                  border: `1.5px solid ${C.success}20`,
                  boxShadow: `0 0 40px ${C.success}08`,
                }}
              >
                <Brain className="h-6 w-6" style={{ color: `${C.success}80` }} />
              </div>
            </div>

            <div>
              <h1
                style={{
                  color: C.text,
                  fontWeight: 700,
                  fontSize: 38,
                  lineHeight: 1.12,
                  letterSpacing: "-0.8px",
                }}
              >
                See the difference
                <br />
                memory makes.
              </h1>
              <p
                className="mt-4 mx-auto"
                style={{
                  color: C.textSecondary,
                  fontSize: 16,
                  lineHeight: 1.5,
                  letterSpacing: "-0.3px",
                  maxWidth: 380,
                }}
              >
                Watch an agent{" "}
                <span style={{ color: `${C.danger}cc` }}>blindly repeat mistakes</span>{" "}
                vs one that{" "}
                <span style={{ color: `${C.success}cc` }}>learns from every failure</span>.
              </p>
            </div>

            <button
              onClick={() => void handleStart()}
              style={{
                backgroundColor: C.accent,
                color: "#ffffff",
                fontSize: 15,
                fontWeight: 500,
                padding: "10px 26px",
                borderRadius: 10,
                border: "none",
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                letterSpacing: "-0.2px",
                boxShadow: `0 0 30px ${C.accent}30`,
                transition: "all 200ms ease",
              }}
            >
              <Play className="h-4 w-4" />
              Start Comparison
            </button>

            <p className="font-mono" style={{ color: C.textMuted, fontSize: 12, letterSpacing: "-0.12px" }}>
              Select a preset above or enter a custom task
            </p>
          </div>
        </div>
      )}

      {/* ── Main split panels ────────────────────────────────────────── */}
      {runState !== "idle" && (
        <div className="flex flex-1 overflow-hidden">
          <SidePanel
            side="left"
            title="Without Memory"
            subtitle="Blind retries -- same mistakes repeated"
            icon={<XCircle className="h-4 w-4" style={{ color: C.danger }} />}
            showMemory={false}
            task={withoutTask}
            isRunning={!withoutTask || withoutTask.status === "running" || withoutTask.status === "pending"}
            isDone={!!withoutTask && ["succeeded", "failed", "abandoned"].includes(withoutTask.status)}
          />

          {/* Center divider with gradient */}
          <div
            style={{
              width: 1,
              background: `linear-gradient(180deg, ${C.border}, ${C.textMuted}40, ${C.border})`,
            }}
          />

          <SidePanel
            side="right"
            title="With Memory"
            subtitle="ReLoop recalls past failures -- learns each attempt"
            icon={<Brain className="h-4 w-4" style={{ color: C.success }} />}
            showMemory={true}
            task={withTask}
            isRunning={!withTask || withTask.status === "running" || withTask.status === "pending"}
            isDone={!!withTask && ["succeeded", "failed", "abandoned"].includes(withTask.status)}
          />
        </div>
      )}

      {/* ── Summary bar ──────────────────────────────────────────────── */}
      {isDone && withoutTask && withTask && (
        <div
          className="px-5 py-5"
          style={{
            backgroundColor: memorySucceeded ? `${C.success}06` : C.surface,
            borderTop: `1px solid ${memorySucceeded ? `${C.success}20` : C.border}`,
          }}
        >
          <div className="max-w-3xl mx-auto space-y-4">
            {/* Result banner */}
            <div className="flex items-center justify-center gap-3">
              {memorySucceeded ? (
                <>
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{
                      backgroundColor: C.successGlow,
                      border: `1.5px solid ${C.success}30`,
                      boxShadow: `0 0 20px ${C.success}20`,
                    }}
                  >
                    <Trophy className="h-4 w-4" style={{ color: C.success }} />
                  </div>
                  <span style={{ color: C.text, fontWeight: 700, fontSize: 18, letterSpacing: "-0.4px" }}>
                    ReLoop won with {withAttempts} attempt
                    {withAttempts !== 1 ? "s" : ""} vs {withoutAttempts}
                  </span>
                </>
              ) : (
                <>
                  <AlertCircle className="h-5 w-5" style={{ color: C.warning }} />
                  <span style={{ color: C.textSecondary, fontWeight: 500, fontSize: 16, letterSpacing: "-0.3px" }}>
                    Both agents ran &mdash; Memory used {withAttempts} attempts vs{" "}
                    {withoutAttempts} without
                  </span>
                </>
              )}
            </div>

            {/* Stat cards */}
            <div className="grid grid-cols-3 gap-3">
              <SummaryCard
                icon={<Zap className="h-5 w-5" style={{ color: savedAttempts > 0 ? C.accent : C.textMuted }} />}
                label="Fewer Attempts"
                value={
                  savedAttempts > 0
                    ? `-${savedAttempts}`
                    : savedAttempts < 0
                    ? `+${Math.abs(savedAttempts)}`
                    : "="
                }
                sub={`${withAttempts} vs ${withoutAttempts}`}
                color={
                  savedAttempts > 0
                    ? C.accent
                    : savedAttempts < 0
                    ? C.danger
                    : C.textMuted
                }
                highlight={savedAttempts > 0}
              />
              <SummaryCard
                icon={<DollarSign className="h-5 w-5" style={{ color: savedCost > 0 ? C.success : C.textMuted }} />}
                label="Cost Saved"
                value={
                  savedCost > 0
                    ? `-$${savedCost.toFixed(3)}`
                    : savedCost < 0
                    ? `+$${Math.abs(savedCost).toFixed(3)}`
                    : "$0.000"
                }
                sub={`$${withCost.toFixed(3)} vs $${withoutCost.toFixed(3)}`}
                color={
                  savedCost > 0
                    ? C.success
                    : savedCost < 0
                    ? C.danger
                    : C.textMuted
                }
                highlight={savedCost > 0}
              />
              <SummaryCard
                icon={<TrendingDown className="h-5 w-5" style={{ color: savedAttempts > 0 ? C.blue : C.textMuted }} />}
                label="Efficiency Gain"
                value={
                  withoutAttempts > 0
                    ? `${savedAttempts > 0 ? "+" : ""}${Math.round(
                        ((withoutAttempts - withAttempts) / withoutAttempts) *
                          100
                      )}%`
                    : "N/A"
                }
                sub="attempts reduction"
                color={
                  savedAttempts > 0 ? C.blue : C.textMuted
                }
                highlight={savedAttempts > 0}
              />
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
