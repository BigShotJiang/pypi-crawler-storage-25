// ReLoop — TypeScript types matching backend Pydantic models

export type TaskStatus = "pending" | "running" | "succeeded" | "failed" | "abandoned";
export type AttemptStatus = "pending" | "running" | "succeeded" | "failed";
export type ErrorCategory =
  | "dependency_error"
  | "runtime_error"
  | "config_error"
  | "type_error"
  | "network_error"
  | "permission_error"
  | "timeout_error"
  | "unknown";

export type TimelineEventType =
  | "task.created"
  | "attempt.started"
  | "step.started"
  | "step.completed"
  | "step.failed"
  | "memory.recalled"
  | "memory.stored"
  | "prediction"
  | "checkpoint.created"
  | "checkpoint.restored"
  | "attempt.succeeded"
  | "attempt.failed"
  | "task.completed"
  | "task.abandoned";

export interface ErrorSignature {
  error_type: string;
  error_category: ErrorCategory;
  error_message: string;
  error_hash: string;
  code_context: string;
}

export interface FailureAnalysis {
  root_cause: string;
  what_was_tried: string;
  why_it_failed: string;
  suggested_fix: string;
  anti_pattern: string;
  confidence: number; // 0.0 – 1.0
}

export interface FailureRecord {
  id: string;
  task_id: string;
  attempt_number: number;
  timestamp: string;
  signature: ErrorSignature;
  analysis: FailureAnalysis;
  context: Record<string, unknown>;
  topics: string[];
  cost_usd: number;
}

export interface SuccessRecord {
  id: string;
  task_id: string;
  attempt_number: number;
  timestamp: string;
  solution: Record<string, string>;
  learning: Record<string, unknown>;
  metrics: Record<string, unknown>;
}

export interface Checkpoint {
  id: string;
  task_id: string;
  attempt_number: number;
  step_number: number;
  sandbox_snapshot_id: string;
  working_memory_snapshot: Record<string, unknown>;
  description: string;
  created_at: string;
  reversible: boolean;
}

export interface StepResult {
  step_number: number;
  description: string;
  command: string;
  output: string;
  status: AttemptStatus;
  error: string | null;
  started_at: string;
  completed_at: string | null;
  cost_usd: number;
}

export interface Attempt {
  attempt_number: number;
  status: AttemptStatus;
  steps: StepResult[];
  recalled_memories: string[];
  failure_record_id: string | null;
  checkpoint_id: string | null;
  started_at: string;
  completed_at: string | null;
  cost_usd: number;
}

export interface Task {
  id: string;
  instruction: string;
  status: TaskStatus;
  attempts: Attempt[];
  current_attempt: number;
  max_retries: number;
  max_budget_usd: number;
  total_cost_usd: number;
  created_at: string;
  completed_at: string | null;
  result: string | null;
  metadata: Record<string, unknown>;
}

export interface TaskResponse {
  id: string;
  instruction: string;
  status: TaskStatus;
  current_attempt: number;
  total_attempts: number;
  total_cost_usd: number;
  created_at: string;
  completed_at: string | null;
  result: string | null;
}

export interface TimelineEvent {
  id: string;
  task_id: string;
  event_type: TimelineEventType;
  attempt_number: number;
  step_number: number;
  timestamp: string;
  data: Record<string, unknown>;
  message: string;
}

export interface MemoryStats {
  total_failures: number;
  total_successes: number;
  top_error_categories: Record<string, number>;
  avg_confidence: number;
}

export interface CreateTaskRequest {
  instruction: string;
  max_retries?: number;
  max_budget_usd?: number;
  metadata?: Record<string, unknown>;
}

export interface MemorySearchRequest {
  query: string;
  error_type?: string;
  error_category?: ErrorCategory;
  limit?: number;
}

export interface ABComparisonSide {
  task_id: string;
  status: string;
  succeeded: boolean;
  total_attempts: number;
  total_cost_usd: number;
}

export interface ABComparisonResult {
  without_memory: ABComparisonSide;
  with_memory: ABComparisonSide;
}

export interface CircuitBreakerState {
  is_open: boolean;
  reason: string;
  consecutive_same_error: number;
  error_hash: string;
  error_type: string;
  recommendation: string;
}

export interface PlaybookExport {
  name: string;
  version: string;
  exported_at: string;
  domain: string;
  failures: FailureRecord[];
  stats: Record<string, unknown>;
}

export interface PredictionResult {
  error_type: string;
  prediction_score: number;
  root_cause: string;
  suggested_prevention: string;
  based_on_failures: number;
  matched?: boolean; // true if this prediction later matched an actual failure
}
