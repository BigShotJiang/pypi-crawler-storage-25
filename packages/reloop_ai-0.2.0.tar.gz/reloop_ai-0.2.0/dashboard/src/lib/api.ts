// ReLoop API client

import type {
  TaskResponse,
  Task,
  CreateTaskRequest,
  FailureRecord,
  MemoryStats,
  TimelineEvent,
  Checkpoint,
  MemorySearchRequest,
  ABComparisonResult,
  CircuitBreakerState,
  PlaybookExport,
  PredictionResult,
} from "./types";

const BASE_URL =
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json", ...init?.headers },
    ...init,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => res.statusText);
    throw new Error(`API ${res.status}: ${text}`);
  }
  return res.json() as Promise<T>;
}

// ─── Tasks ────────────────────────────────────────────────────────────────────

export async function fetchTasks(): Promise<TaskResponse[]> {
  return apiFetch<TaskResponse[]>("/v1/tasks");
}

export async function fetchTask(id: string): Promise<Task> {
  return apiFetch<Task>(`/v1/tasks/${id}`);
}

export async function createTask(req: CreateTaskRequest): Promise<TaskResponse> {
  return apiFetch<TaskResponse>("/v1/tasks", {
    method: "POST",
    body: JSON.stringify(req),
  });
}

export async function retryTask(id: string): Promise<TaskResponse> {
  return apiFetch<TaskResponse>(`/v1/tasks/${id}/retry`, { method: "POST" });
}

export async function fetchTimeline(id: string): Promise<TimelineEvent[]> {
  return apiFetch<TimelineEvent[]>(`/v1/tasks/${id}/timeline`);
}

// ─── A/B Comparison ──────────────────────────────────────────────────────────

export async function runABComparison(
  instruction: string,
  maxRetries?: number,
): Promise<ABComparisonResult> {
  return apiFetch<ABComparisonResult>("/v1/tasks/ab-comparison", {
    method: "POST",
    body: JSON.stringify({
      instruction,
      ...(maxRetries !== undefined ? { max_retries: maxRetries } : {}),
    }),
  });
}

// ─── Checkpoints ─────────────────────────────────────────────────────────────

export async function fetchCheckpoints(taskId: string): Promise<Checkpoint[]> {
  return apiFetch<Checkpoint[]>(`/v1/tasks/${taskId}/checkpoints`);
}

export async function restoreCheckpoint(
  taskId: string,
  checkpointId: string,
): Promise<{ message: string; checkpoint_id: string; task_id: string }> {
  return apiFetch(`/v1/tasks/${taskId}/checkpoints/${checkpointId}/restore`, {
    method: "POST",
  });
}

// ─── Memories ────────────────────────────────────────────────────────────────

export async function searchMemories(req: MemorySearchRequest): Promise<FailureRecord[]> {
  const resp = await apiFetch<{ failures: FailureRecord[]; total_count: number }>("/v1/memories/search", {
    method: "POST",
    body: JSON.stringify(req),
  });
  return resp.failures;
}

export async function fetchFailures(): Promise<FailureRecord[]> {
  return apiFetch<FailureRecord[]>("/v1/memories/failures");
}

export async function fetchMemoryStats(): Promise<MemoryStats> {
  return apiFetch<MemoryStats>("/v1/memories/stats");
}

// ─── SSE Streaming ────────────────────────────────────────────────────────────

export type SSEHandler = (event: TimelineEvent) => void;
export type SSECleanup = () => void;

export function subscribeToTimeline(
  taskId: string,
  onEvent: SSEHandler,
  onError?: (err: Event) => void,
): SSECleanup {
  const url = `${BASE_URL}/v1/tasks/${taskId}/sse`;
  const source = new EventSource(url);

  source.onmessage = (e: MessageEvent) => {
    try {
      const event = JSON.parse(e.data as string) as TimelineEvent;
      onEvent(event);
    } catch {
      // ignore parse errors
    }
  };

  source.onerror = (e: Event) => {
    onError?.(e);
  };

  return () => source.close();
}

// ─── Health & Providers ───────────────────────────────────────────────────────

export async function fetchHealth(): Promise<{ status: string; version: string }> {
  return apiFetch("/v1/health");
}

export async function fetchProviders(): Promise<Record<string, string | null>> {
  return apiFetch("/v1/providers");
}

// ─── Circuit Breaker ──────────────────────────────────────────────────────────

export async function fetchCircuitBreaker(taskId: string): Promise<CircuitBreakerState> {
  return apiFetch(`/v1/tasks/${taskId}/circuit-breaker`);
}

// ─── Predictions & Playbooks ─────────────────────────────────────────────────

export async function predictFailures(instruction: string, context?: Record<string, string>): Promise<PredictionResult[]> {
  return apiFetch("/v1/memories/predict", {
    method: "POST",
    body: JSON.stringify({ instruction, context }),
  });
}

export async function exportPlaybook(domain?: string): Promise<PlaybookExport> {
  const params = domain ? `?domain=${encodeURIComponent(domain)}` : "";
  return apiFetch(`/v1/memories/export${params}`);
}

export async function importPlaybook(failures: FailureRecord[], domain?: string): Promise<{ imported: number; errors: number; total: number }> {
  return apiFetch("/v1/memories/import", {
    method: "POST",
    body: JSON.stringify({ failures, domain }),
  });
}

// ─── Demo / Mock data for when backend is offline ────────────────────────────

export function getMockTasks(): TaskResponse[] {
  return [
    {
      id: "demo001",
      instruction: "Fix and deploy the broken Next.js project with missing dependencies",
      status: "succeeded",
      current_attempt: 4,
      total_attempts: 4,
      total_cost_usd: 0.32,
      created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
      completed_at: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
      result: "Project deployed successfully on port 3001",
    },
    {
      id: "demo002",
      instruction: "Install sharp image processing library and configure Next.js image optimization",
      status: "running",
      current_attempt: 2,
      total_attempts: 2,
      total_cost_usd: 0.08,
      created_at: new Date(Date.now() - 1000 * 60 * 3).toISOString(),
      completed_at: null,
      result: null,
    },
    {
      id: "demo003",
      instruction: "Resolve TypeScript type errors in the authentication module",
      status: "failed",
      current_attempt: 5,
      total_attempts: 5,
      total_cost_usd: 0.45,
      created_at: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
      completed_at: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
      result: null,
    },
  ];
}

export function getMockTask(id: string): Task {
  const attempts = [
    {
      attempt_number: 1,
      status: "failed" as const,
      steps: [
        {
          step_number: 1,
          description: "Install dependencies",
          command: "npm install",
          output: "npm ERR! missing dependency: sharp@0.33.2",
          status: "failed" as const,
          error: "Missing required dependency: sharp",
          started_at: new Date(Date.now() - 1000 * 60 * 14).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 13).toISOString(),
          cost_usd: 0.02,
        },
      ],
      recalled_memories: [],
      failure_record_id: "fail001",
      checkpoint_id: "ckpt001",
      started_at: new Date(Date.now() - 1000 * 60 * 14).toISOString(),
      completed_at: new Date(Date.now() - 1000 * 60 * 13).toISOString(),
      cost_usd: 0.02,
    },
    {
      attempt_number: 2,
      status: "failed" as const,
      steps: [
        {
          step_number: 1,
          description: "Install dependencies with sharp",
          command: "npm install sharp",
          output: "added 12 packages in 3.2s",
          status: "succeeded" as const,
          error: null,
          started_at: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 11).toISOString(),
          cost_usd: 0.02,
        },
        {
          step_number: 2,
          description: "Start dev server",
          command: "npm run dev -- --port 3000",
          output: "Error: EADDRINUSE: address already in use :::3000",
          status: "failed" as const,
          error: "Port 3000 already in use",
          started_at: new Date(Date.now() - 1000 * 60 * 11).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
          cost_usd: 0.04,
        },
      ],
      recalled_memories: ["fail001"],
      failure_record_id: "fail002",
      checkpoint_id: "ckpt002",
      started_at: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
      completed_at: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
      cost_usd: 0.06,
    },
    {
      attempt_number: 3,
      status: "failed" as const,
      steps: [
        {
          step_number: 1,
          description: "Install dependencies with sharp",
          command: "npm install sharp",
          output: "added 12 packages in 3.2s",
          status: "succeeded" as const,
          error: null,
          started_at: new Date(Date.now() - 1000 * 60 * 9).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 8.5).toISOString(),
          cost_usd: 0.02,
        },
        {
          step_number: 2,
          description: "Start dev server on port 3001",
          command: "npm run dev -- --port 3001",
          output: "ready - started server on 0.0.0.0:3001",
          status: "succeeded" as const,
          error: null,
          started_at: new Date(Date.now() - 1000 * 60 * 8.5).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
          cost_usd: 0.02,
        },
        {
          step_number: 3,
          description: "TypeScript compilation check",
          command: "npx tsc --noEmit",
          output: "src/auth/session.ts(42,9): error TS2322: Type 'string' is not assignable to type 'number'",
          status: "failed" as const,
          error: "TypeScript type error in authentication module",
          started_at: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 7).toISOString(),
          cost_usd: 0.08,
        },
      ],
      recalled_memories: ["fail001", "fail002"],
      failure_record_id: "fail003",
      checkpoint_id: "ckpt003",
      started_at: new Date(Date.now() - 1000 * 60 * 9).toISOString(),
      completed_at: new Date(Date.now() - 1000 * 60 * 7).toISOString(),
      cost_usd: 0.12,
    },
    {
      attempt_number: 4,
      status: "succeeded" as const,
      steps: [
        {
          step_number: 1,
          description: "Install all dependencies including sharp",
          command: "npm install sharp && npm install",
          output: "added 12 packages in 3.2s\nadded 1 package\nfound 0 vulnerabilities",
          status: "succeeded" as const,
          error: null,
          started_at: new Date(Date.now() - 1000 * 60 * 6).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 5.5).toISOString(),
          cost_usd: 0.02,
        },
        {
          step_number: 2,
          description: "Fix TypeScript type error in session.ts",
          command: "sed -i 's/userId: session.id/userId: Number(session.id)/' src/auth/session.ts",
          output: "File updated successfully",
          status: "succeeded" as const,
          error: null,
          started_at: new Date(Date.now() - 1000 * 60 * 5.5).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
          cost_usd: 0.04,
        },
        {
          step_number: 3,
          description: "Start dev server on available port",
          command: "npm run dev -- --port 3001",
          output: "ready - started server on 0.0.0.0:3001\n✓ Compiled successfully",
          status: "succeeded" as const,
          error: null,
          started_at: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
          completed_at: new Date(Date.now() - 1000 * 60 * 4.5).toISOString(),
          cost_usd: 0.04,
        },
      ],
      recalled_memories: ["fail001", "fail002", "fail003"],
      failure_record_id: null,
      checkpoint_id: null,
      started_at: new Date(Date.now() - 1000 * 60 * 6).toISOString(),
      completed_at: new Date(Date.now() - 1000 * 60 * 4.5).toISOString(),
      cost_usd: 0.12,
    },
  ];

  return {
    id,
    instruction: "Fix and deploy the broken Next.js project with missing dependencies",
    status: "succeeded",
    attempts,
    current_attempt: 4,
    max_retries: 5,
    max_budget_usd: 1.0,
    total_cost_usd: 0.32,
    created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    completed_at: new Date(Date.now() - 1000 * 60 * 4.5).toISOString(),
    result: "Project deployed successfully on port 3001",
    metadata: {},
  };
}

export function getMockFailures(): FailureRecord[] {
  return [
    {
      id: "fail001",
      task_id: "demo001",
      attempt_number: 1,
      timestamp: new Date(Date.now() - 1000 * 60 * 13).toISOString(),
      signature: {
        error_type: "ModuleNotFoundError",
        error_category: "dependency_error",
        error_message: "Cannot find module 'sharp'",
        error_hash: "a1b2c3d4",
        code_context: "import sharp from 'sharp'",
      },
      analysis: {
        root_cause: "The 'sharp' image processing package is not listed in package.json and was never installed",
        what_was_tried: "Running npm install without specifying sharp",
        why_it_failed: "Next.js image optimization requires sharp for production builds",
        suggested_fix: "Run `npm install sharp` before starting the server",
        anti_pattern: "Assuming all dependencies are installed",
        confidence: 0.95,
      },
      context: { framework: "next.js", language: "typescript" },
      topics: ["dependency", "npm", "sharp"],
      cost_usd: 0.02,
    },
    {
      id: "fail002",
      task_id: "demo001",
      attempt_number: 2,
      timestamp: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
      signature: {
        error_type: "EADDRINUSE",
        error_category: "runtime_error",
        error_message: "Error: EADDRINUSE: address already in use :::3000",
        error_hash: "e5f6g7h8",
        code_context: "app.listen(3000)",
      },
      analysis: {
        root_cause: "Port 3000 is already occupied by another process on this machine",
        what_was_tried: "Starting the Next.js server on the default port 3000",
        why_it_failed: "Another Next.js instance or process is using port 3000",
        suggested_fix: "Use `--port 3001` or kill the process using port 3000 with `lsof -ti:3000 | xargs kill`",
        anti_pattern: "Hardcoding port 3000 without checking availability",
        confidence: 0.92,
      },
      context: { framework: "next.js", language: "typescript" },
      topics: ["port", "network", "eaddrinuse"],
      cost_usd: 0.04,
    },
    {
      id: "fail003",
      task_id: "demo001",
      attempt_number: 3,
      timestamp: new Date(Date.now() - 1000 * 60 * 7).toISOString(),
      signature: {
        error_type: "TS2322",
        error_category: "type_error",
        error_message: "Type 'string' is not assignable to type 'number'",
        error_hash: "i9j0k1l2",
        code_context: "userId: session.id // session.id is string, userId expects number",
      },
      analysis: {
        root_cause: "Session ID is stored as a string but the userId field expects a numeric type",
        what_was_tried: "Directly assigning session.id to userId without type conversion",
        why_it_failed: "TypeScript strict mode rejects implicit string-to-number coercion",
        suggested_fix: "Use `Number(session.id)` or `parseInt(session.id, 10)` to convert the type",
        anti_pattern: "Implicit type coercion in TypeScript",
        confidence: 0.88,
      },
      context: { framework: "next.js", language: "typescript", file: "src/auth/session.ts" },
      topics: ["typescript", "type-error", "session"],
      cost_usd: 0.08,
    },
  ];
}
