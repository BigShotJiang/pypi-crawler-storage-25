"""Tests for the real ReLoopAgent from src/core/agent.py.

Uses mock providers from conftest.py — InMemoryBackend, MockSandboxProvider,
MockLLMProvider — to test actual agent logic without external services.
"""

from __future__ import annotations

import pytest

from src.core.agent import ReLoopAgent
from src.core.timeline import TimelineManager
from src.models import (
    AttemptStatus,
    Task,
    TaskStatus,
    TimelineEventType,
)
from src.providers.base import ExecutionResult
from tests.conftest import (
    InMemoryBackend,
    MockLLMProvider,
    MockSandboxProvider,
    make_task,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def memory():
    return InMemoryBackend()


@pytest.fixture
def sandbox():
    return MockSandboxProvider()


@pytest.fixture
def llm():
    # Provide canned responses for classify_error and distill_failure/success
    return MockLLMProvider(canned_responses=[
        '{"category": "dependency_error"}',
        '{"root_cause": "missing dep", "what_was_tried": "npm run build", '
        '"why_it_failed": "sharp not installed", "suggested_fix": "npm install sharp", '
        '"anti_pattern": "", "confidence": 0.9}',
        '{"approach": "installed sharp", "key_insight": "check deps first", '
        '"failures_that_helped": ["missing sharp"], "transferable": true}',
    ])


@pytest.fixture
def agent(memory, sandbox, llm):
    return ReLoopAgent(
        memory=memory,
        sandbox=sandbox,
        llm=llm,
        max_retries=3,
        max_budget_usd=1.0,
        circuit_breaker_threshold=3,
    )


# ---------------------------------------------------------------------------
# Init tests
# ---------------------------------------------------------------------------


class TestReLoopAgentInit:
    def test_init_with_all_providers(self, memory, sandbox, llm):
        agent = ReLoopAgent(memory=memory, sandbox=sandbox, llm=llm)
        assert agent._sandbox is sandbox
        assert agent._llm is llm
        assert agent._memory is not None
        assert agent._retry_engine is not None

    def test_init_without_providers(self):
        agent = ReLoopAgent()
        assert agent._sandbox is None
        assert agent._llm is None
        assert agent._memory is None
        assert agent._retry_engine is None

    def test_init_with_memory_backend_kwarg(self, memory, llm):
        agent = ReLoopAgent(memory_backend=memory, llm=llm)
        assert agent._memory is not None
        assert agent._memory._backend is memory

    def test_init_custom_retries(self, memory, sandbox, llm):
        agent = ReLoopAgent(
            memory=memory, sandbox=sandbox, llm=llm,
            max_retries=10, max_budget_usd=5.0, circuit_breaker_threshold=5,
        )
        assert agent._max_retries == 10
        assert agent._max_budget_usd == 5.0
        assert agent._circuit_breaker_threshold == 5

    def test_init_defaults_from_settings(self, memory, sandbox, llm):
        agent = ReLoopAgent(memory=memory, sandbox=sandbox, llm=llm)
        # Should use settings defaults (5, 1.0, 3)
        assert agent._max_retries == 5
        assert agent._max_budget_usd == 1.0
        assert agent._circuit_breaker_threshold == 3


# ---------------------------------------------------------------------------
# Run tests
# ---------------------------------------------------------------------------


class TestReLoopAgentRun:
    @pytest.mark.asyncio
    async def test_run_success_first_attempt(self, agent, sandbox):
        """Task succeeds on first attempt — no retries needed."""
        task = make_task()
        result = await agent.run(task)

        assert result.status == TaskStatus.SUCCEEDED
        assert result.current_attempt == 1
        assert len(result.attempts) == 1
        assert result.attempts[0].status == AttemptStatus.SUCCEEDED
        assert result.completed_at is not None

    @pytest.mark.asyncio
    async def test_run_failure_then_success(self, memory, llm):
        """Task fails first attempt, succeeds on second."""
        sandbox = MockSandboxProvider()
        # First command fails, second succeeds
        fail_result = ExecutionResult(exit_code=1, stdout="", stderr="ModuleNotFoundError: sharp")
        ok_result = ExecutionResult(exit_code=0, stdout="Server running", stderr="")

        call_count = 0

        async def execute_side_effect(sandbox_id, command, timeout=120):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return fail_result
            return ok_result

        sandbox.execute = execute_side_effect

        # Need enough LLM responses for classify_error + distill_failure + classify + distill_success
        llm_responses = [
            '{"category": "dependency_error"}',
            '{"root_cause": "sharp missing", "what_was_tried": "build", '
            '"why_it_failed": "no sharp", "suggested_fix": "npm i sharp", '
            '"anti_pattern": "", "confidence": 0.9}',
            '{"category": "dependency_error"}',
            '{"root_cause": "sharp missing 2", "what_was_tried": "build", '
            '"why_it_failed": "still no sharp", "suggested_fix": "npm i sharp", '
            '"anti_pattern": "", "confidence": 0.9}',
            '{"approach": "installed", "key_insight": "deps", '
            '"failures_that_helped": ["sharp"], "transferable": true}',
        ]
        llm = MockLLMProvider(canned_responses=llm_responses)
        agent = ReLoopAgent(
            memory=memory, sandbox=sandbox, llm=llm,
            max_retries=5, max_budget_usd=1.0,
        )

        task = make_task()
        result = await agent.run(task)

        assert result.current_attempt == 2
        assert result.attempts[0].status == AttemptStatus.FAILED
        assert result.attempts[1].status == AttemptStatus.SUCCEEDED
        assert result.status == TaskStatus.SUCCEEDED

    @pytest.mark.asyncio
    async def test_run_abandoned_no_sandbox(self):
        """Agent without sandbox abandons immediately."""
        agent = ReLoopAgent()
        task = make_task()
        result = await agent.run(task)

        assert result.status == TaskStatus.ABANDONED
        assert result.completed_at is not None

    @pytest.mark.asyncio
    async def test_run_max_retries_exhausted(self, memory, llm):
        """Task fails until max retries are exhausted."""
        sandbox = MockSandboxProvider()
        fail_result = ExecutionResult(exit_code=1, stdout="", stderr="Error: something broke")
        sandbox.set_result("Fix and start the demo Next.js project", fail_result)

        # Override execute to always fail
        async def always_fail(sandbox_id, command, timeout=120):
            return fail_result

        sandbox.execute = always_fail

        # Many LLM responses for repeated classify + distill cycles
        responses = []
        for _ in range(10):
            responses.extend([
                '{"category": "runtime_error"}',
                '{"root_cause": "unknown", "what_was_tried": "run", '
                '"why_it_failed": "broke", "suggested_fix": "fix it", '
                '"anti_pattern": "", "confidence": 0.5}',
            ])
        llm = MockLLMProvider(canned_responses=responses)
        agent = ReLoopAgent(
            memory=memory, sandbox=sandbox, llm=llm,
            max_retries=2, max_budget_usd=10.0,
            circuit_breaker_threshold=10,  # high so retries limit kicks in first
        )

        task = make_task(max_retries=2)
        result = await agent.run(task)

        assert result.status == TaskStatus.ABANDONED
        assert result.current_attempt == 2

    @pytest.mark.asyncio
    async def test_run_tracks_cost(self, agent):
        """Agent accumulates cost across attempts."""
        task = make_task()
        result = await agent.run(task)

        # Cost should be non-negative (LLM calls cost something)
        assert result.total_cost_usd >= 0.0

    @pytest.mark.asyncio
    async def test_timeline_events_emitted(self, memory, sandbox, llm):
        """Agent emits timeline events during execution."""
        timeline = TimelineManager()
        agent = ReLoopAgent(
            memory=memory, sandbox=sandbox, llm=llm,
            timeline=timeline, max_retries=3,
        )

        task = make_task()
        await agent.run(task)

        events = timeline.get_timeline(task.id)
        assert len(events) > 0
        event_types = [e.event_type for e in events]
        assert TimelineEventType.TASK_CREATED in event_types


# ---------------------------------------------------------------------------
# Utility method tests
# ---------------------------------------------------------------------------


class TestBuildCommand:
    def test_no_context(self):
        cmd = ReLoopAgent._build_command("npm run build", {})
        assert cmd == "npm run build"

    def test_with_memory_context(self):
        ctx = {"recalled_memories": "Previous failures:\n1. missing sharp"}
        cmd = ReLoopAgent._build_command("npm run build", ctx)
        assert "# [ReLoop Memory Context]" in cmd
        assert "npm run build" in cmd

    def test_with_anti_patterns(self):
        ctx = {"anti_patterns": ["Don't use sudo", "Avoid global installs"]}
        cmd = ReLoopAgent._build_command("npm run build", ctx)
        assert "# [Anti-patterns to avoid]" in cmd
        assert "Don't use sudo" in cmd

    def test_with_prediction_warnings(self):
        ctx = {"prediction_warnings": ["WARNING: ModuleNotFoundError likely"]}
        cmd = ReLoopAgent._build_command("npm run build", ctx)
        assert "# [Predicted Failures" in cmd


class TestInferErrorType:
    def test_python_error(self):
        result = ReLoopAgent._infer_error_type("ModuleNotFoundError: No module named 'sharp'")
        assert "ModuleNotFoundError" in result

    def test_npm_error(self):
        result = ReLoopAgent._infer_error_type("npm ERR! missing script: start")
        assert result == "NpmError"

    def test_port_conflict(self):
        result = ReLoopAgent._infer_error_type("Error: EADDRINUSE: port 3000 already in use")
        assert result == "PortConflict"

    def test_typescript_error(self):
        result = ReLoopAgent._infer_error_type("error TS2322: Type 'string' is not assignable")
        assert result == "TypeScriptError"

    def test_command_not_found(self):
        result = ReLoopAgent._infer_error_type("bash: node: command not found")
        assert result == "CommandNotFound"

    def test_empty_string(self):
        result = ReLoopAgent._infer_error_type("")
        assert result == "UnknownError"

    def test_unknown_error(self):
        result = ReLoopAgent._infer_error_type("something went wrong")
        assert result == "something went wrong"


class TestExtractResult:
    def test_extract_from_successful_step(self):
        from src.models import Attempt, StepResult
        attempt = Attempt(attempt_number=1, status=AttemptStatus.SUCCEEDED)
        step = StepResult(
            step_number=1, description="run",
            output="Server started on port 3000",
            status=AttemptStatus.SUCCEEDED,
        )
        attempt.steps.append(step)
        result = ReLoopAgent._extract_result(attempt)
        assert "Server started" in result

    def test_extract_no_output(self):
        from src.models import Attempt, StepResult
        attempt = Attempt(attempt_number=1, status=AttemptStatus.SUCCEEDED)
        step = StepResult(
            step_number=1, description="run", output="",
            status=AttemptStatus.SUCCEEDED,
        )
        attempt.steps.append(step)
        result = ReLoopAgent._extract_result(attempt)
        assert result == "Task completed successfully"
