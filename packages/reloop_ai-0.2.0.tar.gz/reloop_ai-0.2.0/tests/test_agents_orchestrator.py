"""Tests for src/providers/llm/agents_orchestrator.py.

The OpenAI Agents SDK is NOT required — we mock it entirely and test
the orchestrator's prompt building, result parsing, and fallback logic.
"""

from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from src.providers.llm.agents_orchestrator import (
    AgentsOrchestrator,
    PlanResult,
)
from tests.conftest import make_failure_record


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_failure_history(n: int = 2) -> list:
    records = []
    for i in range(1, n + 1):
        records.append(make_failure_record(
            task_id="task-001",
            attempt_number=i,
            error_type=f"Error{i}",
            error_message=f"something broke in attempt {i}",
            suggested_fix=f"try fix {i}",
        ))
    return records


# ---------------------------------------------------------------------------
# _build_prompt tests
# ---------------------------------------------------------------------------


class TestBuildPrompt:
    """Test the AgentsOrchestrator._build_prompt method directly."""

    def _make_orchestrator(self) -> AgentsOrchestrator:
        """Create orchestrator without the agents SDK (mock _make_tools/_build_agents)."""
        # We only test _build_prompt which doesn't use agents SDK
        obj = object.__new__(AgentsOrchestrator)
        obj._memory = None
        obj._sandbox = None
        obj._tools = {}
        obj._agents = {}
        return obj

    def test_first_attempt_no_history(self):
        orch = self._make_orchestrator()
        prompt = orch._build_prompt(
            instruction="npm run build",
            failure_history=[],
            retry_context={},
            sandbox_id="sb-1",
        )
        assert "TASK: npm run build" in prompt
        assert "SANDBOX_ID: sb-1" in prompt
        assert "ATTEMPT NUMBER: 1" in prompt
        assert "None (this is the first attempt)" in prompt

    def test_with_failure_history(self):
        orch = self._make_orchestrator()
        failures = _make_failure_history(2)
        prompt = orch._build_prompt(
            instruction="npm run build",
            failure_history=failures,
            retry_context={},
            sandbox_id="sb-1",
        )
        assert "FAILURE HISTORY (2 previous attempts)" in prompt
        assert "Error1" in prompt
        assert "Error2" in prompt
        assert "try fix 1" in prompt

    def test_with_recalled_memories(self):
        orch = self._make_orchestrator()
        ctx = {"recalled_memories": "Previously: sharp was missing"}
        prompt = orch._build_prompt(
            instruction="npm run build",
            failure_history=[],
            retry_context=ctx,
            sandbox_id="sb-1",
        )
        assert "RECALLED MEMORIES" in prompt
        assert "sharp was missing" in prompt

    def test_with_anti_patterns(self):
        orch = self._make_orchestrator()
        ctx = {"anti_patterns": ["Don't use sudo", "Avoid global npm"]}
        prompt = orch._build_prompt(
            instruction="npm run build",
            failure_history=[],
            retry_context=ctx,
            sandbox_id="sb-1",
        )
        assert "ANTI-PATTERNS TO AVOID" in prompt
        assert "Don't use sudo" in prompt


# ---------------------------------------------------------------------------
# _parse_result tests
# ---------------------------------------------------------------------------


class TestParseResult:
    def _make_orchestrator(self) -> AgentsOrchestrator:
        obj = object.__new__(AgentsOrchestrator)
        obj._memory = None
        obj._sandbox = None
        obj._tools = {}
        obj._agents = {}
        return obj

    def test_parse_json_string_output(self):
        orch = self._make_orchestrator()
        data = {
            "strategy": "Install sharp first",
            "commands": ["npm install sharp", "npm run build"],
            "avoid_patterns": ["sudo npm"],
            "confidence": 0.85,
        }
        result_mock = SimpleNamespace(final_output=json.dumps(data))
        plan = orch._parse_result(result_mock, "npm run build")
        assert isinstance(plan, PlanResult)
        assert plan.strategy == "Install sharp first"
        assert plan.commands == ["npm install sharp", "npm run build"]
        assert plan.confidence == 0.85

    def test_parse_json_with_markdown_fences(self):
        orch = self._make_orchestrator()
        data = {
            "strategy": "Fix deps",
            "commands": ["npm install"],
            "confidence": 0.7,
        }
        text = f"```json\n{json.dumps(data)}\n```"
        result_mock = SimpleNamespace(final_output=text)
        plan = orch._parse_result(result_mock, "npm run build")
        assert plan.strategy == "Fix deps"
        assert plan.commands == ["npm install"]

    def test_parse_plain_text_fallback(self):
        orch = self._make_orchestrator()
        result_mock = SimpleNamespace(final_output="Just run the build command directly")
        plan = orch._parse_result(result_mock, "npm run build")
        assert plan.commands == ["npm run build"]
        assert plan.confidence == 0.5

    def test_parse_malformed_json(self):
        orch = self._make_orchestrator()
        result_mock = SimpleNamespace(final_output="{broken json")
        plan = orch._parse_result(result_mock, "npm run build")
        # Should fall back gracefully
        assert plan.commands == ["npm run build"]
        assert plan.confidence <= 0.5

    def test_parse_structured_output_with_model_dump(self):
        orch = self._make_orchestrator()
        mock_output = MagicMock()
        mock_output.model_dump.return_value = {
            "strategy": "structured",
            "commands": ["cmd1"],
            "avoid_patterns": ["bad"],
            "confidence": 0.9,
        }
        result_mock = SimpleNamespace(final_output=mock_output)
        plan = orch._parse_result(result_mock, "npm run build")
        assert plan.strategy == "structured"
        assert plan.confidence == 0.9

    def test_confidence_clamped(self):
        orch = self._make_orchestrator()
        data = {"strategy": "test", "commands": ["cmd"], "confidence": 2.5}
        result_mock = SimpleNamespace(final_output=json.dumps(data))
        plan = orch._parse_result(result_mock, "cmd")
        assert plan.confidence == 1.0

        data2 = {"strategy": "test", "commands": ["cmd"], "confidence": -0.5}
        result_mock2 = SimpleNamespace(final_output=json.dumps(data2))
        plan2 = orch._parse_result(result_mock2, "cmd")
        assert plan2.confidence == 0.0


# ---------------------------------------------------------------------------
# _fallback_plan tests
# ---------------------------------------------------------------------------


class TestFallbackPlan:
    def test_fallback_returns_instruction_as_command(self):
        plan = AgentsOrchestrator._fallback_plan("npm run build", [])
        assert plan.commands == ["npm run build"]
        assert plan.confidence == 0.3

    def test_fallback_includes_anti_patterns_from_history(self):
        failures = _make_failure_history(2)
        failures[0].analysis.anti_pattern = "don't do X"
        failures[1].analysis.anti_pattern = "avoid Y"
        plan = AgentsOrchestrator._fallback_plan("npm run build", failures)
        assert "don't do X" in plan.avoid_patterns
        assert "avoid Y" in plan.avoid_patterns

    def test_fallback_skips_empty_anti_patterns(self):
        failures = _make_failure_history(1)
        failures[0].analysis.anti_pattern = ""
        plan = AgentsOrchestrator._fallback_plan("npm run build", failures)
        assert plan.avoid_patterns == []
