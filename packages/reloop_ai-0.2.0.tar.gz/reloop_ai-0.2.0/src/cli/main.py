"""ReLoop CLI — command-line interface for the ReLoop agent."""

from __future__ import annotations

import asyncio
import shutil
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="reloop",
    help="ReLoop — The Self-Healing Agent with Failure Memory",
    no_args_is_help=True,
)
console = Console()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _api_url() -> str:
    """Return the base API URL from config."""
    from src.config import settings
    return f"http://{settings.api_host}:{settings.api_port}"


def _http_client():
    """Create an httpx client for API calls."""
    import httpx
    return httpx.Client(base_url=_api_url(), timeout=30.0)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@app.command()
def run(
    instruction: str = typer.Argument(..., help="Task instruction for the agent"),
    max_retries: int = typer.Option(5, "--max-retries", "-r", help="Maximum retry attempts"),
    budget: float = typer.Option(1.0, "--budget", "-b", help="Maximum budget in USD"),
) -> None:
    """Create and run a new task."""
    client = _http_client()
    try:
        resp = client.post(
            "/v1/tasks",
            json={
                "instruction": instruction,
                "max_retries": max_retries,
                "max_budget_usd": budget,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        console.print(f"[green]Task created:[/green] {data.get('id', 'unknown')}")
        console.print(f"Status: {data.get('status', 'unknown')}")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def status(
    task_id: str = typer.Argument(..., help="Task ID to check"),
) -> None:
    """Get status of a task."""
    client = _http_client()
    try:
        resp = client.get(f"/v1/tasks/{task_id}")
        resp.raise_for_status()
        data = resp.json()
        table = Table(title=f"Task {task_id}")
        table.add_column("Field", style="cyan")
        table.add_column("Value")
        table.add_row("Status", data.get("status", "unknown"))
        table.add_row("Attempts", str(data.get("total_attempts", 0)))
        table.add_row("Cost", f"${data.get('total_cost_usd', 0):.4f}")
        if data.get("result"):
            table.add_row("Result", str(data["result"])[:200])
        console.print(table)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def memories(
    query: str = typer.Option("", "--query", "-q", help="Search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Max results"),
) -> None:
    """Search or list failure memories."""
    client = _http_client()
    try:
        if query:
            resp = client.post(
                "/v1/memories/search",
                json={"query": query, "limit": limit},
            )
        else:
            resp = client.get("/v1/memories/failures", params={"limit": limit})
        resp.raise_for_status()
        data = resp.json()
        failures = data.get("results", data) if isinstance(data, dict) else data
        if not failures:
            console.print("[yellow]No memories found.[/yellow]")
            return
        for f in failures[:limit]:
            if isinstance(f, dict):
                console.print(
                    f"[red]{f.get('signature', {}).get('error_type', 'unknown')}[/red]: "
                    f"{f.get('analysis', {}).get('root_cause', 'unknown')}"
                )
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def stats() -> None:
    """Show memory statistics."""
    client = _http_client()
    try:
        resp = client.get("/v1/memories/stats")
        resp.raise_for_status()
        data = resp.json()
        table = Table(title="Memory Statistics")
        table.add_column("Metric", style="cyan")
        table.add_column("Value")
        table.add_row("Total Failures", str(data.get("total_failures", 0)))
        table.add_row("Total Successes", str(data.get("total_successes", 0)))
        table.add_row("Avg Confidence", f"{data.get('avg_confidence', 0):.2f}")
        categories = data.get("top_error_categories", {})
        if categories:
            table.add_row("Top Categories", ", ".join(f"{k}: {v}" for k, v in categories.items()))
        console.print(table)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def serve(
    host: str = typer.Option("0.0.0.0", "--host", help="Host to bind to"),
    port: int = typer.Option(8000, "--port", "-p", help="Port to bind to"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload"),
) -> None:
    """Start the ReLoop API server."""
    import uvicorn
    console.print(f"[green]Starting ReLoop API server on {host}:{port}[/green]")
    uvicorn.run("src.api.server:app", host=host, port=port, reload=reload)


@app.command()
def health() -> None:
    """Check API server health."""
    client = _http_client()
    try:
        resp = client.get("/v1/health")
        resp.raise_for_status()
        data = resp.json()
        console.print(f"[green]Server is healthy[/green]: {data}")
    except Exception as exc:
        console.print(f"[red]Server unreachable:[/red] {exc}", style="bold red")
        raise typer.Exit(code=1)


@app.command()
def init() -> None:
    """Initialize ReLoop in current directory — creates .env template and config."""
    env_path = Path(".env")
    config_path = Path("reloop.yaml")

    if env_path.exists():
        console.print("[yellow].env already exists — skipping.[/yellow]")
    else:
        env_path.write_text(
            "# ReLoop environment variables\n"
            "REDIS_URL=redis://localhost:6379\n"
            "REDIS_MEMORY_INDEX=reloop-failures\n"
            "OPENAI_API_KEY=\n"
            "BLAXEL_API_KEY=\n"
            "BLAXEL_WORKSPACE=\n"
            "API_PORT=8000\n"
            "API_HOST=0.0.0.0\n"
            "NEXT_PUBLIC_API_URL=http://localhost:8000\n"
            "MAX_RETRIES=5\n"
            "MAX_BUDGET_USD=1.00\n"
        )
        console.print("[green]Created .env template.[/green]")

    if config_path.exists():
        console.print("[yellow]reloop.yaml already exists — skipping.[/yellow]")
    else:
        default_config = Path(__file__).resolve().parents[2] / "reloop.yaml"
        if default_config.exists():
            shutil.copy(default_config, config_path)
            console.print("[green]Created reloop.yaml from default.[/green]")
        else:
            config_path.write_text(
                "# ReLoop configuration\n"
                "max_retries: 5\n"
                "max_budget_usd: 1.0\n"
                "circuit_breaker_threshold: 3\n"
            )
            console.print("[green]Created reloop.yaml.[/green]")

    console.print(Panel("ReLoop initialized. Edit .env with your API keys, then run [bold]reloop serve[/bold]."))


@app.command()
def demo() -> None:
    """Run the demo scenario (broken Next.js project with 4 bugs)."""
    from src.config import settings
    from src.core.agent import ReLoopAgent
    from src.models import Task as ReLoopTask
    from src.providers.memory.sqlite_backend import SQLiteMemoryBackend

    console.print(Panel("[bold]ReLoop Demo[/bold] — Broken Next.js project with 4 deliberate bugs"))

    async def _run_demo() -> None:
        memory = SQLiteMemoryBackend()
        await memory.initialize()
        agent = ReLoopAgent(memory=memory)

        task = ReLoopTask(
            instruction="Fix the broken Next.js project in data/demo-project that has 4 bugs: "
            "missing dependency (sharp), port conflict (3000), TypeScript error, and bad DATABASE_URL.",
            max_retries=settings.max_retries,
            max_budget_usd=settings.max_budget_usd,
        )
        console.print(f"[bold]Task:[/bold] {task.id}")

        result = await agent.run(task)
        status_color = "green" if result.status.value == "succeeded" else "red"
        console.print(f"[{status_color}]Result: {result.status.value}[/{status_color}]")
        console.print(f"  Attempts: {len(result.attempts)}")

    asyncio.run(_run_demo())


@app.command()
def version() -> None:
    """Show ReLoop version."""
    console.print("ReLoop v0.2.0")


if __name__ == "__main__":
    app()
