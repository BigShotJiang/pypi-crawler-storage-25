"""OpenAI Agents SDK Orchestrator — REJD loop via multi-agent handoffs.

Four specialist agents mirror the REJD phases:

  Retriever  -> queries failure memory for similar past errors
  Executor   -> runs code/commands in the sandbox
  Judge      -> classifies execution results (success / failure)
  Distiller  -> extracts structured learnings

A top-level REJD Orchestrator agent coordinates the handoffs and manages
the retry budget.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from pydantic import BaseModel, Field

from src.config import settings
from src.providers.llm.openai import _estimate_cost

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pydantic output types for structured agent responses
# ---------------------------------------------------------------------------

class JudgeResult(BaseModel):
    """Output from the Judge agent — classifies an execution result."""

    succeeded: bool = False
    error_type: str = ""
    error_category: str = "unknown"
    error_message: str = ""
    root_cause: str = ""
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    summary: str = ""


class DistilledLearning(BaseModel):
    """Output from the Distiller agent — structured learnings."""

    # Failure fields
    root_cause: str = ""
    what_was_tried: str = ""
    why_it_failed: str = ""
    suggested_fix: str = ""
    anti_pattern: str = ""

    # Success fields
    approach: str = ""
    key_insight: str = ""
    failures_that_helped: list[str] = Field(default_factory=list)
    transferable: bool = False

    confidence: float = Field(default=0.5, ge=0.0, le=1.0)


class PlanResult(BaseModel):
    """Structured plan returned by the orchestrator for an attempt."""

    strategy: str = ""
    commands: list[str] = Field(default_factory=list)
    avoid_patterns: list[str] = Field(default_factory=list)
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    cost_usd: float = 0.0


# ---------------------------------------------------------------------------
# Tool function wrappers (closures created per-run)
# ---------------------------------------------------------------------------

def _make_tools(
    memory_manager: Any | None,
    sandbox_provider: Any | None,
) -> dict[str, Any]:
    """Create tool functions that wrap existing ReLoop functionality.

    Returns a dict of tool functions keyed by name.  These are plain
    async callables that the Agents SDK can invoke.
    """
    from agents import function_tool  # type: ignore[import]

    @function_tool
    async def search_memories(error_type: str, error_message: str, limit: int = 5) -> str:
        """Search failure memory for similar past errors.

        Args:
            error_type: The type/class of error to search for.
            error_message: The error message text.
            limit: Maximum number of results to return.
        """
        if memory_manager is None:
            return json.dumps({"failures": [], "message": "No memory backend configured"})
        try:
            failures = await memory_manager.recall(
                error_type=error_type,
                error_message=error_message,
                limit=limit,
            )
            results = []
            for f in failures:
                results.append({
                    "id": f.id,
                    "error_type": f.signature.error_type,
                    "error_message": f.signature.error_message[:256],
                    "root_cause": f.analysis.root_cause,
                    "suggested_fix": f.analysis.suggested_fix,
                    "anti_pattern": f.analysis.anti_pattern,
                    "confidence": f.analysis.confidence,
                })
            return json.dumps({"failures": results, "count": len(results)})
        except Exception as exc:
            logger.warning("search_memories tool failed: %s", exc)
            return json.dumps({"failures": [], "error": str(exc)})

    @function_tool
    async def get_anti_patterns(task_id: str) -> str:
        """Get known anti-patterns from past failures for a task.

        Args:
            task_id: The task ID to look up failures for.
        """
        if memory_manager is None:
            return json.dumps({"anti_patterns": []})
        try:
            failures = await memory_manager._backend.get_failures_for_task(task_id)
            patterns = []
            for f in failures:
                if f.analysis.anti_pattern:
                    patterns.append(f.analysis.anti_pattern)
            return json.dumps({"anti_patterns": list(set(patterns))})
        except Exception as exc:
            logger.warning("get_anti_patterns tool failed: %s", exc)
            return json.dumps({"anti_patterns": [], "error": str(exc)})

    @function_tool
    async def execute_in_sandbox(sandbox_id: str, command: str, timeout: int = 120) -> str:
        """Execute a command in the sandbox environment.

        Args:
            sandbox_id: The ID of the sandbox to execute in.
            command: The shell command to execute.
            timeout: Timeout in seconds.
        """
        if sandbox_provider is None:
            return json.dumps({"success": False, "error": "No sandbox provider configured"})
        try:
            result = await sandbox_provider.execute(
                sandbox_id=sandbox_id,
                command=command,
                timeout=timeout,
            )
            return json.dumps({
                "success": result.success,
                "exit_code": result.exit_code,
                "stdout": result.stdout[:2048],
                "stderr": result.stderr[:2048],
                "duration_ms": result.duration_ms,
            })
        except Exception as exc:
            logger.warning("execute_in_sandbox tool failed: %s", exc)
            return json.dumps({"success": False, "error": str(exc)})

    return {
        "search_memories": search_memories,
        "get_anti_patterns": get_anti_patterns,
        "execute_in_sandbox": execute_in_sandbox,
    }


# ---------------------------------------------------------------------------
# Agent definitions
# ---------------------------------------------------------------------------

def _build_agents(tools: dict[str, Any]) -> dict[str, Any]:
    """Build the four specialist agents and the orchestrator.

    Returns a dict with keys: retriever, executor, judge, distiller, orchestrator.
    """
    from agents import Agent  # type: ignore[import]

    retriever_agent = Agent(
        name="Retriever",
        handoff_description="Retrieves similar past failures from memory",
        instructions=(
            "You are the Retriever agent in the ReLoop REJD cycle. "
            "Query the failure memory for similar past errors. "
            "Return the top matches with their root causes and suggested fixes. "
            "If no memories are found, say so explicitly."
        ),
        tools=[tools["search_memories"], tools["get_anti_patterns"]],
        model=settings.fast_model or "gpt-4o-mini",
    )

    executor_agent = Agent(
        name="Executor",
        handoff_description="Executes code in sandbox",
        instructions=(
            "You are the Executor agent in the ReLoop REJD cycle. "
            "Execute the given code/command in the sandbox. "
            "Apply any failure-informed fixes before running. "
            "Report the full output including exit code, stdout, and stderr."
        ),
        tools=[tools["execute_in_sandbox"]],
        model=settings.fast_model or "gpt-4o-mini",
    )

    judge_agent = Agent(
        name="Judge",
        handoff_description="Classifies execution results as success or failure",
        instructions=(
            "You are the Judge agent in the ReLoop REJD cycle. "
            "Analyse the execution result. Classify as success or failure. "
            "If failure, identify: error type, error category (one of: "
            "dependency_error, runtime_error, config_error, type_error, "
            "network_error, permission_error, timeout_error, unknown), "
            "root cause, and confidence score (0.0-1.0)."
        ),
        output_type=JudgeResult,
        model=settings.fast_model or "gpt-4o-mini",
    )

    distiller_agent = Agent(
        name="Distiller",
        handoff_description="Extracts learnings from results",
        instructions=(
            "You are the Distiller agent in the ReLoop REJD cycle. "
            "Extract structured learnings from the execution result. "
            "For failures: what went wrong, why, what to try next, and any anti-pattern. "
            "For successes: what worked, key insight, which past failures helped."
        ),
        output_type=DistilledLearning,
        model=settings.fast_model or "gpt-4o-mini",
    )

    rejd_orchestrator = Agent(
        name="REJD Orchestrator",
        instructions=(
            "You orchestrate the ReLoop self-healing cycle (REJD loop):\n"
            "1. RETRIEVE: Hand off to Retriever to find similar past failures\n"
            "2. EXECUTE: Hand off to Executor to run the task with failure context\n"
            "3. JUDGE: Hand off to Judge to classify the result\n"
            "4. DISTILL: Hand off to Distiller to extract learnings\n\n"
            "If the task failed and retries remain, loop back to RETRIEVE with new knowledge.\n"
            "Always follow this order. Report each phase's result clearly."
        ),
        handoffs=[retriever_agent, executor_agent, judge_agent, distiller_agent],
        model=settings.codex_model or "gpt-4o",
    )

    return {
        "retriever": retriever_agent,
        "executor": executor_agent,
        "judge": judge_agent,
        "distiller": distiller_agent,
        "orchestrator": rejd_orchestrator,
    }


# ---------------------------------------------------------------------------
# Budget guardrail
# ---------------------------------------------------------------------------

def _make_budget_guardrail(max_budget_usd: float, spent_usd_ref: list[float]):
    """Create an input guardrail that trips when budget is exceeded.

    `spent_usd_ref` is a single-element list used as a mutable reference
    so the caller can update the running cost.
    """
    from agents import input_guardrail, GuardrailFunctionOutput  # type: ignore[import]

    @input_guardrail
    async def budget_guardrail(ctx, agent, input_data):
        over_budget = spent_usd_ref[0] >= max_budget_usd
        return GuardrailFunctionOutput(
            output_info={"spent_usd": spent_usd_ref[0], "max_usd": max_budget_usd},
            tripwire_triggered=over_budget,
        )

    return budget_guardrail


# ---------------------------------------------------------------------------
# Token usage extraction from Agents SDK results
# ---------------------------------------------------------------------------

def _extract_usage_cost(result: Any) -> float:
    """Extract token usage from an Agents SDK RunResult and compute USD cost.

    The Agents SDK ``Runner.run()`` result exposes a ``.raw_responses`` list,
    each element being a ``ModelResponse`` with a ``.usage`` attribute
    containing ``prompt_tokens``, ``completion_tokens``, and ``total_tokens``.

    We iterate over all raw responses, sum the tokens per model, and apply
    ``_estimate_cost`` from the OpenAI provider for accurate pricing.
    """
    total_cost = 0.0
    try:
        raw_responses = getattr(result, "raw_responses", None) or []
        for resp in raw_responses:
            usage = getattr(resp, "usage", None)
            if usage is None:
                continue
            prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
            completion_tokens = getattr(usage, "completion_tokens", 0) or 0
            # Determine which model produced this response.
            model = getattr(resp, "model", "") or ""
            if not model:
                # Fall back to the orchestrator's configured model.
                model = settings.codex_model or "gpt-4o"
            total_cost += _estimate_cost(model, prompt_tokens, completion_tokens)
    except Exception as exc:
        logger.warning("Failed to extract usage cost from Agents SDK result: %s", exc)
    return total_cost


# ---------------------------------------------------------------------------
# Public API — run the REJD loop
# ---------------------------------------------------------------------------

class AgentsOrchestrator:
    """Orchestrates the REJD loop using the OpenAI Agents SDK.

    Uses a multi-agent system where each REJD phase is handled by a
    specialist agent.
    """

    def __init__(
        self,
        memory_manager: Any | None = None,
        sandbox_provider: Any | None = None,
    ) -> None:
        self._memory = memory_manager
        self._sandbox = sandbox_provider
        self._tools = _make_tools(memory_manager, sandbox_provider)
        self._agents = _build_agents(self._tools)

    async def plan_next_action(
        self,
        instruction: str,
        failure_history: list[Any],
        retry_context: dict[str, Any],
        sandbox_id: str = "",
    ) -> PlanResult:
        """Plan the next execution attempt using the Agents SDK orchestrator.

        This method is designed to be a drop-in replacement for
        ``Planner.plan_next_action()``.

        Args:
            instruction: The original task instruction.
            failure_history: List of FailureRecord objects from previous attempts.
            retry_context: The retry context dict from the RETRIEVE step.
            sandbox_id: The sandbox ID for execution (passed to tools).

        Returns:
            A PlanResult with strategy, commands, avoid_patterns, confidence.
        """
        from agents import Runner, trace  # type: ignore[import]

        # Build the prompt with full failure context
        prompt = self._build_prompt(instruction, failure_history, retry_context, sandbox_id)

        try:
            with trace("reloop-plan", group_id=sandbox_id or "no-sandbox"):
                result = await Runner.run(
                    self._agents["orchestrator"],
                    prompt,
                    max_turns=10,
                )

            # Parse the orchestrator's final output into a PlanResult
            plan = self._parse_result(result, instruction)

            # Extract token usage from the Agents SDK result and compute cost.
            plan.cost_usd = _extract_usage_cost(result)

            return plan

        except Exception as exc:
            logger.warning("AgentsOrchestrator.plan_next_action failed: %s", exc)
            return self._fallback_plan(instruction, failure_history)

    def _build_prompt(
        self,
        instruction: str,
        failure_history: list[Any],
        retry_context: dict[str, Any],
        sandbox_id: str,
    ) -> str:
        """Build the orchestration prompt with full context."""
        lines: list[str] = [
            f"TASK: {instruction}",
            f"SANDBOX_ID: {sandbox_id}",
            f"ATTEMPT NUMBER: {len(failure_history) + 1}",
            "",
        ]

        if failure_history:
            lines.append(f"FAILURE HISTORY ({len(failure_history)} previous attempts):")
            for fr in failure_history:
                lines.extend([
                    f"  Attempt {fr.attempt_number}:",
                    f"    Error type:     {fr.signature.error_type}",
                    f"    Root cause:     {fr.analysis.root_cause}",
                    f"    What was tried: {fr.analysis.what_was_tried}",
                    f"    Why it failed:  {fr.analysis.why_it_failed}",
                    f"    Suggested fix:  {fr.analysis.suggested_fix}",
                ])
                if fr.analysis.anti_pattern:
                    lines.append(f"    Anti-pattern:   {fr.analysis.anti_pattern}")
                lines.append("")
        else:
            lines.extend([
                "FAILURE HISTORY: None (this is the first attempt)",
                "",
            ])

        recalled = retry_context.get("recalled_memories", "")
        if recalled:
            lines.extend([
                "RECALLED MEMORIES FROM SIMILAR PAST FAILURES:",
                str(recalled)[:1000],
                "",
            ])

        anti_patterns = retry_context.get("anti_patterns", [])
        if anti_patterns:
            lines.extend([
                "KNOWN ANTI-PATTERNS TO AVOID:",
                *[f"  - {ap}" for ap in anti_patterns],
                "",
            ])

        prediction_warnings = retry_context.get("prediction_warnings", [])
        if prediction_warnings:
            lines.extend([
                "PREDICTION WARNINGS (failure patterns likely to recur):",
                *[f"  - {w}" for w in prediction_warnings],
                "YOU MUST address these predicted failures in your plan.",
                "",
            ])

        lines.extend([
            "",
            "Plan the next execution attempt. Output a clear strategy, "
            "concrete shell commands, and anti-patterns to avoid.",
        ])

        return "\n".join(lines)

    def _parse_result(self, result: Any, instruction: str) -> PlanResult:
        """Parse the Runner result into a PlanResult."""
        try:
            output = result.final_output
            if isinstance(output, str):
                # Try to parse as JSON
                text = output.strip()
                if "```" in text:
                    for fence in ("```json", "```"):
                        text = text.replace(fence, "")
                    text = text.strip()
                start = text.find("{")
                end = text.rfind("}") + 1
                if start != -1 and end > 0:
                    data = json.loads(text[start:end])
                    return PlanResult(
                        strategy=str(data.get("strategy", output[:200])),
                        commands=[str(c) for c in data.get("commands", [instruction])],
                        avoid_patterns=[str(p) for p in data.get("avoid_patterns", [])],
                        confidence=min(1.0, max(0.0, float(data.get("confidence", 0.5)))),
                    )
                # Plain text — use as strategy, instruction as command
                return PlanResult(
                    strategy=output[:200],
                    commands=[instruction],
                    confidence=0.5,
                )
            # Structured output (unlikely from orchestrator, but handle it)
            if hasattr(output, "model_dump"):
                data = output.model_dump()
                return PlanResult(
                    strategy=str(data.get("strategy", "")),
                    commands=data.get("commands", [instruction]),
                    avoid_patterns=data.get("avoid_patterns", []),
                    confidence=float(data.get("confidence", 0.5)),
                )
        except Exception as exc:
            logger.warning("Failed to parse orchestrator result: %s", exc)

        return PlanResult(
            strategy="Execute task directly (orchestrator output unparseable)",
            commands=[instruction],
            confidence=0.3,
        )

    @staticmethod
    def _fallback_plan(instruction: str, failure_history: list[Any]) -> PlanResult:
        """Minimal fallback when the orchestrator is unavailable."""
        avoid: list[str] = []
        for fr in failure_history:
            if hasattr(fr, "analysis") and fr.analysis.anti_pattern:
                avoid.append(fr.analysis.anti_pattern)

        return PlanResult(
            strategy="Execute the task directly (Agents SDK orchestrator unavailable)",
            commands=[instruction],
            avoid_patterns=avoid,
            confidence=0.3,
        )
