"""OpenAI LLM Provider — fallback LLM backend for ReLoop.

Uses the official openai async Python client.
Provides generate, generate_with_tools, stream, and embed.
"""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator

from src.config import settings
from src.providers.base import LLMProvider, LLMResponse

logger = logging.getLogger(__name__)

# Cost estimates per 1M tokens — used for rough USD accounting
_COST_PER_1M: dict[str, dict[str, float]] = {
    # GPT-5.4 family (latest, most capable)
    "gpt-5.4": {"input": 2.50, "output": 10.00},
    "gpt-5.4-mini": {"input": 0.30, "output": 1.25},
    "gpt-5.4-nano": {"input": 0.10, "output": 0.40},
    # GPT-5 family
    "gpt-5": {"input": 5.00, "output": 15.00},
    "gpt-5-mini": {"input": 1.25, "output": 5.00},
    "gpt-5-nano": {"input": 0.30, "output": 1.25},
    # o-series reasoning models
    "o1-pro": {"input": 150.00, "output": 600.00},
    # Previous generation (still supported)
    "gpt-4.1": {"input": 2.00, "output": 8.00},
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    # Embeddings
    "text-embedding-3-small": {"input": 0.02, "output": 0.0},
    "text-embedding-3-large": {"input": 0.13, "output": 0.0},
}

_DEFAULT_EMBED_MODEL = "text-embedding-3-small"


def _estimate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    """Rough cost estimate in USD from token counts."""
    # Match by prefix
    pricing = None
    for key, val in _COST_PER_1M.items():
        if model.startswith(key):
            pricing = val
            break
    if pricing is None:
        # Fallback: assume gpt-4o mini pricing
        pricing = {"input": 0.15, "output": 0.60}
    cost = (prompt_tokens / 1_000_000) * pricing["input"] + (
        completion_tokens / 1_000_000
    ) * pricing["output"]
    return round(cost, 6)


class OpenAILLM(LLMProvider):
    """OpenAI async chat-completion LLM provider."""

    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
    ) -> None:
        self._api_key = api_key or settings.openai_api_key
        self._model = model or settings.codex_model or "gpt-5.4"
        self._client: Any = None  # openai.AsyncOpenAI

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_client(self) -> Any:
        """Lazily initialise the OpenAI async client."""
        if self._client is None:
            try:
                from openai import AsyncOpenAI  # type: ignore[import]

                self._client = AsyncOpenAI(api_key=self._api_key)
            except ImportError as exc:
                raise ImportError(
                    "openai package is not installed. Run: pip install openai"
                ) from exc
        return self._client

    def _messages_from(self, prompt: str, system: str) -> list[dict[str, str]]:
        msgs: list[dict[str, str]] = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        return msgs

    # ------------------------------------------------------------------
    # LLMProvider interface
    # ------------------------------------------------------------------

    async def generate(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.3,
    ) -> LLMResponse:
        """Standard async chat completion."""
        client = self._get_client()
        try:
            resp = await client.chat.completions.create(
                model=self._model,
                messages=self._messages_from(prompt, system),
                temperature=temperature,
            )
            content = resp.choices[0].message.content or ""
            prompt_tokens = resp.usage.prompt_tokens if resp.usage else 0
            completion_tokens = resp.usage.completion_tokens if resp.usage else 0
            tokens_used = prompt_tokens + completion_tokens
            cost_usd = _estimate_cost(self._model, prompt_tokens, completion_tokens)
            return LLMResponse(
                content=content,
                tokens_used=tokens_used,
                cost_usd=cost_usd,
                model=self._model,
            )
        except Exception as exc:
            logger.error("generate failed: %s", exc)
            return LLMResponse(content="", model=self._model)

    async def generate_with_tools(
        self,
        prompt: str,
        system: str = "",
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
    ) -> LLMResponse:
        """Chat completion with optional tool/function calling."""
        client = self._get_client()
        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": self._messages_from(prompt, system),
            "temperature": temperature,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
        try:
            resp = await client.chat.completions.create(**kwargs)
            choice = resp.choices[0]
            content = choice.message.content or ""
            raw_tool_calls = choice.message.tool_calls or []
            tool_calls = []
            for tc in raw_tool_calls:
                try:
                    import json

                    args = json.loads(tc.function.arguments or "{}")
                except Exception:
                    args = {}
                tool_calls.append(
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": args,
                        },
                    }
                )
            prompt_tokens = resp.usage.prompt_tokens if resp.usage else 0
            completion_tokens = resp.usage.completion_tokens if resp.usage else 0
            tokens_used = prompt_tokens + completion_tokens
            cost_usd = _estimate_cost(self._model, prompt_tokens, completion_tokens)
            return LLMResponse(
                content=content,
                tool_calls=tool_calls,
                tokens_used=tokens_used,
                cost_usd=cost_usd,
                model=self._model,
            )
        except Exception as exc:
            logger.error("generate_with_tools failed: %s", exc)
            return LLMResponse(content="", model=self._model)

    async def stream(
        self,
        prompt: str,
        system: str = "",
    ) -> AsyncIterator[str]:
        """Streaming chat completion — yield delta text chunks."""
        client = self._get_client()
        try:
            async with client.chat.completions.stream(
                model=self._model,
                messages=self._messages_from(prompt, system),
            ) as stream:
                async for event in stream:
                    # openai >= 1.x streaming returns ChatCompletionChunk objects
                    try:
                        delta = event.choices[0].delta.content
                        if delta:
                            yield delta
                    except (AttributeError, IndexError):
                        continue
        except Exception as exc:
            logger.error("stream failed: %s", exc)
            return

    async def embed(self, text: str) -> list[float]:
        """Generate text embedding using text-embedding-3-small."""
        client = self._get_client()
        try:
            resp = await client.embeddings.create(
                model=_DEFAULT_EMBED_MODEL,
                input=text,
            )
            return resp.data[0].embedding
        except Exception as exc:
            logger.error("embed failed: %s", exc)
            return []
