"""
Schema naming utilities for the Supero Platform.

Handles:
- Schema name normalization (PascalCase → snake_case)
- Attribute name validation (reserved keyword detection)
- Storage filename generation
- Display name generation with acronym uppercasing

DESIGN: Hybrid approach
1. Acronym map for COMMON EDGE CASES (OAuth, iOS, IoT, compound acronyms)
2. Simple deterministic algorithm for everything else
"""
import re
import keyword
from typing import Tuple, Dict, Any, Optional, Set, List


# =============================================================================
# PYTHON RESERVED KEYWORDS + BUILTINS
# =============================================================================
# These cannot be used as attribute names in generated Python code

PYTHON_RESERVED_KEYWORDS: Set[str] = set(keyword.kwlist) | {
    # Add lowercase versions of capitalized keywords
    'true', 'false', 'none',
}

# Additional Python builtins that would shadow important functions
PYTHON_BUILTINS_TO_AVOID: Set[str] = {
    # Types
    'int', 'str', 'float', 'bool', 'list', 'dict', 'set', 'tuple',
    'bytes', 'bytearray', 'complex', 'frozenset', 'object', 'type',
    
    # Functions that are commonly used
    'id', 'input', 'print', 'open', 'file', 'format', 'hash', 'help',
    'len', 'max', 'min', 'next', 'range', 'sum', 'sorted', 'reversed',
    'map', 'filter', 'zip', 'enumerate', 'all', 'any', 'iter',
    
    # Object methods
    'self', 'cls', 'super',
    
    # Exception handling
    'Exception', 'BaseException', 'Error',
    
    # Common attribute names that conflict
    'vars', 'dir', 'globals', 'locals', 'exec', 'eval', 'compile',
    'getattr', 'setattr', 'delattr', 'hasattr', 'callable', 'isinstance',
    'issubclass', 'property', 'staticmethod', 'classmethod',
    
    # Math
    'abs', 'divmod', 'pow', 'round',
    
    # Other
    'repr', 'ascii', 'bin', 'hex', 'oct', 'ord', 'chr',
    'slice', 'memoryview', 'breakpoint',
}

# Combined set for validation
ALL_RESERVED_NAMES: Set[str] = PYTHON_RESERVED_KEYWORDS | PYTHON_BUILTINS_TO_AVOID


# =============================================================================
# ACRONYM MAP - For edge cases and compound acronyms
# =============================================================================
# These are patterns that the simple algorithm would handle incorrectly

EDGE_CASE_ACRONYMS: Dict[str, str] = {
    # -------------------------------------------------------------------------
    # Lowercase-start brand names (would split at lowercase-uppercase boundary)
    # -------------------------------------------------------------------------
    'iOS': 'ios',
    'iPad': 'ipad',
    'iPhone': 'iphone',
    'iMac': 'imac',
    'iTunes': 'itunes',
    'iCloud': 'icloud',
    'eBay': 'ebay',
    'eBook': 'ebook',
    'eCommerce': 'ecommerce',
    'eLearning': 'elearning',
    'mRNA': 'mrna',
    
    # -------------------------------------------------------------------------
    # IoT - special case (would become io_t)
    # -------------------------------------------------------------------------
    'IoT': 'iot',
    'IoTDevice': 'iot_device',
    'IoTSensor': 'iot_sensor',
    'IoTAPI': 'iot_api',
    'IoTAPIClient': 'iot_api_client',
    'IoTDeviceSDK': 'iot_device_sdk',
    
    # -------------------------------------------------------------------------
    # Single lowercase before uppercase (would split wrongly)
    # -------------------------------------------------------------------------
    'OAuth': 'oauth',
    'OAuth2': 'oauth2',
    'OAuthToken': 'oauth_token',
    'LaTeX': 'latex',
    
    # -------------------------------------------------------------------------
    # Product names with unusual casing
    # -------------------------------------------------------------------------
    'MacOS': 'macos',
    'macOS': 'macos',
    'MySQL': 'mysql',
    'MySQLConfig': 'mysql_config',
    'MySQLConnection': 'mysql_connection',
    'PostgreSQL': 'postgresql',
    'MongoDB': 'mongodb',
    'GraphQL': 'graphql',
    'GraphQLSchema': 'graphql_schema',
    'NoSQL': 'nosql',
    'DevOps': 'devops',
    'DevOpsPipeline': 'devops_pipeline',
    'GitLab': 'gitlab',
    'GitHub': 'github',
    'GitHubRepo': 'github_repo',
    'GitOps': 'gitops',
    'TypeScript': 'typescript',
    'JavaScript': 'javascript',
    'CoffeeScript': 'coffeescript',
    'ActionScript': 'actionscript',
    'OpenAPI': 'openapi',
    'OpenID': 'openid',
    'OAuth2Provider': 'oauth2_provider',
    'OAuth2Config': 'oauth2_config',
    'OAuth2Client': 'oauth2_client',
    
    # -------------------------------------------------------------------------
    # Compound acronyms that need explicit splits
    # -------------------------------------------------------------------------
    # HTTPS + API
    'HTTPSAPI': 'https_api',
    'HTTPSAPIEndpoint': 'https_api_endpoint',
    
    # HTTP + API
    'HTTPAPI': 'http_api',
    
    # REST + API
    'RESTAPI': 'rest_api',
    'RESTAPIHandler': 'rest_api_handler',
    
    # JSON + API
    'JSONAPI': 'json_api',
    'JSONAPIResponse': 'json_api_response',
    
    # XML + API
    'XMLAPI': 'xml_api',
    
    # XML + HTTP
    'XMLHTTP': 'xml_http',
    'XMLHTTPRequest': 'xml_http_request',
    
    # REST + CRUD
    'RESTCRUD': 'rest_crud',
    'RESTCRUDHandler': 'rest_crud_handler',
    
    # AWS compounds
    'AWSSDK': 'aws_sdk',
    'AWSSDKConfig': 'aws_sdk_config',
    'AWSS3': 'aws_s3',
    'AWSS3Bucket': 'aws_s3_bucket',
    'AWSEC2': 'aws_ec2',
    'AWSAPI': 'aws_api',
    'AWSAPIGateway': 'aws_api_gateway',
    
    # GCP compounds
    'GCPVM': 'gcp_vm',
    
    # ML + Model
    'MLModel': 'ml_model',
    'MLModelAPI': 'ml_model_api',
}

# Known acronyms for display name uppercasing
KNOWN_ACRONYMS: Set[str] = {
    'api', 'http', 'https', 'json', 'xml', 'html', 'css', 'sql', 'url', 'uri',
    'uuid', 'id', 'tcp', 'udp', 'ip', 'dns', 'vpn', 'ssl', 'tls', 'ssh',
    'ftp', 'smtp', 'imap', 'pop', 'jwt', 'oauth', 'sms', 'mms', 'sdk',
    'aws', 's3', 'ec2', 'gcp', 'cdn', 'vpc', 'iam', 'rds', 'sqs', 'sns',
    'ai', 'ml', 'nlp', 'gpu', 'cpu', 'ram', 'ssd', 'hdd', 'usb', 'hdmi',
    'iot', 'crud', 'rest', 'soap', 'grpc', 'graphql', 'nosql',
    'pdf', 'csv', 'png', 'jpg', 'gif', 'svg', 'mp3', 'mp4',
    'ui', 'ux', 'cli', 'gui', 'ide', 'os', 'vm', 'ci', 'cd',
    'bgp', 'vip',
}


def _check_edge_case(name: str) -> Optional[str]:
    """Check if name matches an edge case pattern."""
    # Exact match first
    if name in EDGE_CASE_ACRONYMS:
        return EDGE_CASE_ACRONYMS[name]
    
    # Check if name STARTS WITH an edge case pattern (longest match first)
    for pattern, replacement in sorted(EDGE_CASE_ACRONYMS.items(), key=lambda x: -len(x[0])):
        if name.startswith(pattern):
            rest = name[len(pattern):]
            if rest:
                rest_normalized = normalize_schema_name(rest)
                return f"{replacement}_{rest_normalized}" if rest_normalized else replacement
            return replacement
    
    return None


def normalize_schema_name(name: str) -> str:
    """
    Normalize schema name to snake_case.
    
    Algorithm:
    1. Check edge case map for common problematic patterns
    2. Protect version patterns (v2, x64) from wrong splits
    3. Standard CamelCase to snake_case conversion
    
    Args:
        name: Original schema name (e.g., "UserAccount", "HTTPServer")
        
    Returns:
        Normalized snake_case name (e.g., "user_account", "http_server")
        
    Examples:
        >>> normalize_schema_name("UserAccount")
        'user_account'
        >>> normalize_schema_name("HTTPServer")
        'http_server'
        >>> normalize_schema_name("OAuth2Provider")
        'oauth2_provider'
        >>> normalize_schema_name("iOSApp")
        'ios_app'
        >>> normalize_schema_name("IoTDevice")
        'iot_device'
    """
    if not name:
        return name
    
    # Strip whitespace
    name = name.strip()
    if not name:
        return ""
    
    # Remove .json extension if present
    name = name.replace('.json', '')
    
    # Step 1: Check edge case map
    edge_result = _check_edge_case(name)
    if edge_result is not None:
        return edge_result
    
    # Step 2: Protect version patterns (APIv2 → api_v2, not ap_iv2)
    name = re.sub(r'([a-zA-Z])([vVxX])(\d)', r'\1_\2\3', name)
    
    # Step 3: Standard CamelCase to snake_case
    # Insert underscore before uppercase that follows lowercase/digit
    result = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', name)
    
    # Handle consecutive uppercase followed by lowercase (e.g., HTTPServer → HTTP_Server)
    result = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', result)
    
    # Replace hyphens and spaces with underscores
    result = result.replace('-', '_').replace(' ', '_')
    
    # Lowercase everything
    result = result.lower()
    
    # Remove duplicate underscores and trim
    result = re.sub(r'_+', '_', result)
    result = result.strip('_')
    
    return result


def normalize_attribute_name(name: str) -> str:
    """
    Normalize attribute name to snake_case.
    
    Similar to schema name normalization but specifically for attributes.
    
    Args:
        name: Original attribute name
        
    Returns:
        Normalized snake_case attribute name
    """
    return normalize_schema_name(name)


def is_reserved_keyword(name: str) -> bool:
    """
    Check if a name is a Python reserved keyword or problematic builtin.
    
    Args:
        name: The name to check
        
    Returns:
        True if the name should not be used as an attribute
    """
    if not name:
        return False
    return name.lower() in ALL_RESERVED_NAMES or name in ALL_RESERVED_NAMES


def validate_attribute_name(name: str, raise_on_error: bool = True) -> Tuple[bool, str]:
    """
    Validate an attribute name for use in generated code.
    
    Checks:
    1. Not empty
    2. Starts with letter or underscore (BEFORE normalization)
    3. Contains only valid characters
    4. Not a Python reserved keyword
    5. Not a problematic Python builtin
    
    Args:
        name: The attribute name to validate
        raise_on_error: If True, raises ValueError on invalid name
        
    Returns:
        Tuple of (is_valid, error_message)
        
    Raises:
        ValueError: If raise_on_error=True and name is invalid
    """
    if not name or not name.strip():
        error_msg = "Attribute name cannot be empty"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    name = name.strip()
    
    # Check original name starts with letter or underscore (BEFORE normalization)
    if not name[0].isalpha() and name[0] != '_':
        error_msg = f"Attribute name must start with a letter or underscore: '{name}'"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    normalized = normalize_attribute_name(name)
    
    # Check normalized name has valid characters (alphanumeric + underscore)
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', normalized):
        error_msg = f"Attribute name contains invalid characters: '{name}' → '{normalized}'"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    # Check reserved keywords
    if normalized in PYTHON_RESERVED_KEYWORDS:
        error_msg = f"Attribute name '{name}' normalizes to Python keyword '{normalized}'"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    # Check problematic builtins
    if normalized in PYTHON_BUILTINS_TO_AVOID:
        error_msg = f"Attribute name '{name}' normalizes to Python builtin '{normalized}'"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    return True, ''


def validate_schema_name(name: str, raise_on_error: bool = True) -> Tuple[bool, str]:
    """
    Validate schema name according to platform rules.
    
    Accepts names in various formats (CamelCase, snake_case, kebab-case),
    normalizes them, and validates the result.
    
    Checks:
    1. Not empty
    2. Starts with a letter
    3. Contains only valid characters (letters, numbers, underscores, hyphens)
    4. Does not normalize to a reserved word
    
    Args:
        name: The schema name to validate (any format)
        raise_on_error: If True, raises ValueError on invalid name
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not name or not name.strip():
        error_msg = "Schema name cannot be empty"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    name = name.strip()
    
    # Check starts with letter
    if not name[0].isalpha():
        error_msg = f"Schema name must start with a letter: '{name}'"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    # Check valid characters in original name (letters, numbers, underscores, hyphens)
    if not re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', name):
        error_msg = f"Schema name contains invalid characters: '{name}'"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    # Normalize and check for reserved words
    normalized = normalize_schema_name(name)
    
    if normalized in ALL_RESERVED_NAMES:
        error_msg = f"Schema name '{name}' normalizes to reserved word '{normalized}'"
        if raise_on_error:
            raise ValueError(error_msg)
        return False, error_msg
    
    return True, ''


def suggest_alternative_name(name: str) -> str:
    """
    Suggest an alternative name if the given name is reserved.
    
    Args:
        name: The problematic name
        
    Returns:
        A suggested alternative name
        
    Examples:
        >>> suggest_alternative_name("type")
        'type_value'
        >>> suggest_alternative_name("id")
        'id_value'
        >>> suggest_alternative_name("class")
        'class_name'
    """
    normalized = normalize_attribute_name(name)
    
    # Common suffixes based on the type of reserved word
    type_words = {'type', 'class', 'object', 'dict', 'list', 'set', 'tuple', 'str', 'int', 'float', 'bool'}
    id_words = {'id', 'hash', 'uuid'}
    
    if normalized in type_words:
        return f"{normalized}_value"
    elif normalized in id_words:
        return f"{normalized}_value"
    elif normalized in {'input', 'output'}:
        return f"{normalized}_data"
    elif normalized in {'format', 'print', 'open', 'file'}:
        return f"{normalized}_func"
    else:
        return f"{normalized}_attr"


def add_edge_case(pattern: str, normalized: str) -> None:
    """Add a new edge case to the acronym map at runtime."""
    EDGE_CASE_ACRONYMS[pattern] = normalized


def get_edge_cases() -> Dict[str, str]:
    """Return a copy of the current edge case map."""
    return EDGE_CASE_ACRONYMS.copy()


def get_reserved_keywords() -> Set[str]:
    """Return a copy of all reserved names."""
    return ALL_RESERVED_NAMES.copy()


def to_pascal_case(snake_name: str) -> str:
    """Convert snake_case to PascalCase."""
    if not snake_name:
        return snake_name
    parts = snake_name.split('_')
    return ''.join(part.capitalize() for part in parts if part)


def to_camel_case(snake_name: str) -> str:
    """Convert snake_case to camelCase."""
    pascal = to_pascal_case(snake_name)
    if not pascal:
        return pascal
    return pascal[0].lower() + pascal[1:]


def get_storage_filename(schema_name: str) -> str:
    """Derive storage path from schema name.
    Namespaced schemas use sub-path: crm/invoice.json (not crm_invoice.json).
    This matches schema_service._upload_schema_to_s3() sub-path layout.

    Examples:
        "invoice"       -> "invoice.json"
        "crm:invoice"   -> "crm/invoice.json"
    """
    ns = None
    name = schema_name.strip()

    if name.endswith(".json"):
        name = name[:-5]

    if ":" in name:
        ns, name = name.split(":", 1)
        ns = ns.strip().lower().replace("-", "_")

    normalized = normalize_schema_name(name)

    if ns:
        return f"{ns}/{normalized}.json"

    return f"{normalized}.json"

def get_schema_logical_name(schema_name: str) -> str:
    if ':' in schema_name:
        ns, bare = schema_name.split(':', 1)
        ns = ns.strip().lower().replace('-', '_')
        bare = normalize_schema_name(bare)
        return f"{ns}:{bare}"
    return normalize_schema_name(schema_name)

def get_schema_storage_name(schema_name: str) -> str:
    """Storage name with sub-path: crm/invoice (not crm_invoice)."""
    if ':' in schema_name:
        ns, bare = schema_name.split(':', 1)
        ns = ns.strip().lower().replace('-', '_')
        bare = normalize_schema_name(bare)
        return f"{ns}/{bare}"
    return normalize_schema_name(schema_name)

def get_display_name(schema_name: str) -> str:
    """
    Generate user-friendly display name from snake_case.
    
    Uppercases known acronyms (API, HTTP, SMS, etc.).
    
    Args:
        schema_name: snake_case schema name
        
    Returns:
        Title Case display name with acronyms uppercased
        
    Examples:
        >>> get_display_name("user_account")
        'User Account'
        >>> get_display_name("api_key")
        'API Key'
        >>> get_display_name("sms_data")
        'SMS Data'
        >>> get_display_name("http_server")
        'HTTP Server'
    """
    if not schema_name:
        return schema_name
    
    words = schema_name.split('_')
    result_words = []
    
    for word in words:
        if not word:
            continue
        # Check if this word is a known acronym
        if word.lower() in KNOWN_ACRONYMS:
            result_words.append(word.upper())
        else:
            result_words.append(word.capitalize())
    
    return ' '.join(result_words)


def process_schema_upload(schema_content: Dict[str, Any], 
                          preserve_original_name: bool = True) -> Tuple[Dict[str, Any], str]:
    """
    Process uploaded schema content for storage.
    
    Validates and normalizes the schema name, and sets display_name
    to a human-readable format (e.g., "User Account" from "UserAccount").
    
    Args:
        schema_content: The schema dictionary (must have 'name' field)
        preserve_original_name: If True, generates display_name from normalized name
        
    Returns:
        Tuple of (processed_schema, storage_filename)
        
    Raises:
        ValueError: If schema is invalid
    """
    if not isinstance(schema_content, dict):
        raise ValueError("Schema content must be a dictionary")
    
    if 'name' not in schema_content:
        raise ValueError("Schema must have a 'name' field")
    
    original_name = schema_content['name']
    
    if not original_name:
        raise ValueError("Schema 'name' field cannot be empty")
    
    # Normalize the name
    normalized_name = normalize_schema_name(original_name)
    schema_content['name'] = normalized_name
    
    # Set display_name if not already present (preserve user's custom display_name)
    # Generate human-readable display name: "user_account" → "User Account"
    if preserve_original_name and 'display_name' not in schema_content:
        schema_content['display_name'] = get_display_name(normalized_name)
    
    storage_filename = f"{normalized_name}.json"
    
    return schema_content, storage_filename
