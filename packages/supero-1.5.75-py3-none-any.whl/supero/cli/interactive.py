"""
supero.cli.interactive — Credential setup for Supero generated apps.

The domain and project are FIXED at generation time (bundled in .env).
This module only handles credential entry when needed:

  1. API key mode (zero prompts): .env has SUPERO_API_KEY → skip everything
  2. Password mode (one prompt):  .env has domain+email → prompt for password only
  3. Fresh install (rare):        No .env → prompt for email + password

Domain registration is NEVER done here — the domain was already created
when the user generated the app from the Supero UI.
"""

import os
import sys
import getpass

from supero.cli.env_manager import EnvManager


# ── ANSI colors ──
class _C:
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"

if not sys.stdout.isatty():
    for attr in ('GREEN', 'YELLOW', 'RED', 'CYAN', 'BOLD', 'DIM', 'RESET'):
        setattr(_C, attr, '')


import re as _re_proj

RESERVED_PROJECT_NAMES = {"default-project", "default", "system", "admin", "platform"}

def prompt_project(domain: str) -> str:
    """Prompt for project name with validation. Rejects reserved names."""
    base = domain.replace("-corp", "").replace("-inc", "").replace("-llc", "")
    suggested = f"{base}-app" if base else "myapp"

    while True:
        try:
            raw = input(f"  Project name [{suggested}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            raw = ""

        val = raw or suggested

        if val.lower() in RESERVED_PROJECT_NAMES:
            print(f"  ✗ '{val}' is reserved by the platform. Pick a different name.")
            continue

        if not _re_proj.match(r'^[a-z][a-z0-9_-]{1,49}$', val):
            print(f"  ✗ Must be lowercase, start with a letter, and use only "
                  f"letters/digits/underscores/dashes (max 50 chars).")
            continue

        return val


def _ok(msg):   print(f"  {_C.GREEN}✓{_C.RESET} {msg}")
def _warn(msg): print(f"  {_C.YELLOW}⚠{_C.RESET} {msg}")
def _fail(msg): print(f"  {_C.RED}✗{_C.RESET} {msg}")
def _info(msg): print(f"  {_C.DIM}{msg}{_C.RESET}")


def interactive_setup(env: EnvManager) -> EnvManager:
    """
    Configure credentials for a generated Supero app.

    Domain and project are FIXED — read from .env (set at generation time).
    Only credentials (API key or email+password) are prompted if missing.

    Returns the updated EnvManager instance.
    """
    domain = env.get("SUPERO_DOMAIN")
    project = env.get("SUPERO_PROJECT", "default-project")
    api_key = env.get("SUPERO_API_KEY")
    email = env.get("SUPERO_ADMIN_EMAIL")
    password = env.get("SUPERO_PASSWORD")
    url = env.get("SUPERO_URL", "https://api.supero.dev")

    # ── Show what this app is built for ──
    print()
    if domain:
        print(f"  {_C.BOLD}This app is built for:{_C.RESET}")
        print(f"    Domain:  {_C.CYAN}{domain}{_C.RESET}")
        print(f"    Project: {_C.CYAN}{project}{_C.RESET}")
        print(f"    Server:  {_C.DIM}{url}{_C.RESET}")
        print()
    else:
        # No domain in .env — this shouldn't happen for generated apps
        # but handle gracefully for manually created projects
        _warn("No domain configured in .env")
        _info("This app was not generated from the Supero UI.")
        print()
        domain = _prompt("  Domain name: ", required=True)
        env.set("SUPERO_DOMAIN", domain)

        # Prompt for project name (rejects reserved names like default-project)
        project = prompt_project(domain)
        env.set("SUPERO_PROJECT", project)
        print(f"  \u2713 Project: {project}")
    # ── Mode 1: API key present → zero prompts ──
    if api_key and api_key.startswith("ak_"):
        _ok(f"API key: ...{api_key[-4:]}")
        if email:
            _ok(f"Email:   {email}")
        _ok("Pre-configured — no credentials needed")
        env.save()
        return env

    # ── Mode 2: Email present, need password ──
    if email and not password:
        _ok(f"Email: {email}")
        print()
        print(f"  {_C.BOLD}Enter your password to set up this app:{_C.RESET}")
        print()
        password = _prompt_password(f"  Password for {email}: ")
        if not password:
            _fail("Password is required")
            sys.exit(1)
        env.set("SUPERO_PASSWORD", password)
        env.save()
        return env

    # ── Mode 3: Email + password both present → ready ──
    if email and password:
        _ok(f"Email:    {email}")
        _ok(f"Password: {'*' * min(len(password), 8)}")
        env.save()
        return env

    # ── Mode 4: No email, no API key — prompt for both ──
    # This happens when .env only has domain (e.g., manual setup)
    print(f"  {_C.BOLD}Enter your credentials:{_C.RESET}")
    print()

    if not email:
        default_email = f"admin@{domain}.com" if domain else ""
        email = _prompt(
            f"  Email [{default_email}]: ",
            default=default_email,
            required=True,
        )
        env.set("SUPERO_ADMIN_EMAIL", email)

    if not password:
        password = _prompt_password(f"  Password for {email}: ")
        if not password:
            _fail("Password is required")
            sys.exit(1)
        env.set("SUPERO_PASSWORD", password)

    # Set defaults
    if not env.get("SUPERO_URL"):
        env.set("SUPERO_URL", url)
    if not env.get("SUPERO_PROJECT"):
        env.set("SUPERO_PROJECT", project)

    env.save()
    print()
    _ok("Credentials saved to .env")

    return env


# ── Prompt helpers ─────────────────────────────────────────

def _prompt(msg: str, default: str = "", required: bool = False) -> str:
    """Prompt for input with optional default."""
    try:
        value = input(msg).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        value = ""

    if not value and default:
        value = default
    if required and not value:
        _fail("This field is required")
        sys.exit(1)
    return value


def _prompt_password(msg: str) -> str:
    """Prompt for password (hidden input)."""
    try:
        if sys.stdout.isatty():
            return getpass.getpass(msg)
        else:
            # Non-interactive — read from stdin
            return input(msg).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ""
