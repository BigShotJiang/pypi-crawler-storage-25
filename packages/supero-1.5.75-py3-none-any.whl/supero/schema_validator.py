#!/usr/bin/env python3
"""
Unified Schema Validator - Runtime validation + Schema structure validation

UNIFIED VERSION combining:
- api-server/src/schema_validator.py (runtime validation, encryption, v3.2 fix)
- utils/schema_validator.py (better error messages, comprehensive checks)

TWO VALIDATION MODES:
1. RUNTIME VALIDATION: Validates object data against schemas (API requests)
   - validate_object(), validate_field_type(), validate_partial_update()
   
2. SCHEMA STRUCTURE VALIDATION: Validates schema definitions before resolution
   - validate_schema(), validate_all_schemas(), validate_schemas_before_resolution()

FEATURES:
- ✅ v3.2 FIX: Validates 'values' constraints for inline enum validation
- ✅ Encryption support - skips validation for encrypted fields
- ✅ Works with pre-loaded schemas (resolved with inheritance)
- ✅ Comprehensive error messages with suggestions
- ✅ System attribute type mismatch detection
- ✅ Unknown type detection with suggestions
- ✅ Object vs Type usage validation
- ✅ Reference naming convention validation
"""
import logging
import re
from typing import Dict, Any, List, Optional, Set, Tuple
try:
    from schema_naming import normalize_schema_name
except ImportError:
    from .schema_naming import normalize_schema_name

try:
    import inflection
except ImportError:
    # Fallback for environments without inflection
    class inflection:
        @staticmethod
        def underscore(s):
            s = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', s)
            return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s).lower()
        
        @staticmethod
        def camelize(s, uppercase_first_letter=True):
            if uppercase_first_letter:
                return ''.join(x.capitalize() or '_' for x in s.split('_'))
            else:
                parts = s.split('_')
                return parts[0] + ''.join(x.capitalize() for x in parts[1:])
        
        @staticmethod
        def dasherize(s):
            return s.replace('_', '-')

try:
    from schema_storage import SchemaStorage, SchemaNotFoundError
except ImportError:
    # Fallback for environments without schema_storage
    class SchemaNotFoundError(Exception):
        pass
    SchemaStorage = None

# Schema model loader - dynamic type loading from schema_model.json
try:
    from schema_model_loader import get_builtin_types as _get_model_builtin_types
    from schema_model_loader import get_type_map as _get_model_type_map
    _SCHEMA_MODEL_AVAILABLE = True
except ImportError:
    _SCHEMA_MODEL_AVAILABLE = False



class SchemaValidationError(Exception):
    """Raised when schema validation fails."""
    def __init__(self, message: str, field: str = None, value: Any = None,
                 errors: List[str] = None, schema_name: str = None,
                 file_path: str = None):
        self.field = field
        self.value = value
        self.errors = errors or []
        self.schema_name = schema_name
        self.file_path = file_path

        if self.errors:
            # Combine main message with detailed errors
            detailed_errors = "; ".join(self.errors)
            full_message = f"{message}: {detailed_errors}"
        else:
            full_message = message

        super().__init__(full_message)


class SchemaValidator:
    """
    Unified schema validator for both runtime object validation and schema structure validation.
    
    FEATURES:
    - Runtime validation: Validates object data against schemas
    - Schema structure validation: Validates schema definitions
    - Encryption support: Skips validation for encrypted values
    - Pre-loaded schemas: Works with resolved schemas (inheritance merged)
    - Comprehensive error messages with suggestions
    
    BACKWARD COMPATIBLE with both previous versions.
    """
    
    # =========================================================================
    # SYSTEM FIELDS - Skipped during runtime object validation
    # =========================================================================
    SYSTEM_FIELDS = {
        'uuid', 'name', 'fq_name', 'parent_uuid', 'parent-uuid', 'obj_type', 'obj-type',
        'parent_type', 'topic', '_encrypted', '_id', 'description',
        'display_name', 'created_by', 'created_at', 'updated_at',
        'display-name', 'created-by', 'created-at', 'updated-at',
        '_base_class', '_base_package',
        '_base-class', '_base-package'
    }
    
    SYSTEM_SCHEMA_TYPES = {
        'domain', 'api_key', 'schema_registry', 'global_system_config', 'client_sdk',
        'api-key', 'schema-registry', 'global-system-config', 'client-sdk'
    }
    
    # =========================================================================
    # SYSTEM ATTRIBUTES - For schema structure validation
    # =========================================================================
    SYSTEM_ATTRIBUTES = {
        # Required system attributes
        'name': {'type': 'string', 'required': True},
        'uuid': {'type': 'string', 'required': True, 'compatible': ['uuid']},
        'fq_name': {'type': 'list', 'required': True, 'compatible': ['array']},
        'parent_type': {'type': 'string', 'required': True},
        'parent_uuid': {'type': 'string', 'required': True, 'compatible': ['uuid']},
        'obj_type': {'type': 'string', 'required': True},
        
        # Optional system attributes
        'display_name': {'type': 'string', 'required': False},
        'description': {'type': 'string', 'required': False},
        'created_by': {'type': 'string', 'required': False},
        'created_at': {'type': 'datetime', 'required': False, 'compatible': ['string', 'timestamp']},
        'updated_at': {'type': 'datetime', 'required': False, 'compatible': ['string', 'timestamp']},
        
        # Legacy/deprecated (still reserved)
        'last_modified': {'type': 'datetime', 'required': False, 'compatible': ['string', 'timestamp']},
        'id': {'type': 'string', 'required': False, 'compatible': ['uuid', 'int', 'integer']},
        'perms2': {'type': 'object', 'required': False, 'compatible': ['dict', 'json']},
        'owner': {'type': 'string', 'required': False},
    }
    
    # Keep set for backwards compatibility
    RESERVED_ATTRIBUTES = set(SYSTEM_ATTRIBUTES.keys())
    
    # Built-in types for schema structure validation
    BUILTIN_TYPES = {
        'string', 'int', 'integer', 'float', 'double', 'boolean', 'bool',
        'datetime', 'date', 'time', 'timestamp', 'uuid', 'json', 'object',
        'array', 'list', 'dict', 'map', 'number', 'null', 'any', 'bytes', 'binary'
    }

    @classmethod
    def _get_builtin_types_from_model(cls):
        """Load builtin types from schema_model.json, fallback to hardcoded."""
        if _SCHEMA_MODEL_AVAILABLE:
            try:
                return _get_model_builtin_types()
            except Exception:
                pass
        return cls.BUILTIN_TYPES

    
    def __init__(self, 
                 schema_storage: Optional['SchemaStorage'] = None,
                 tenant_id: str = 'default-domain',
                 logger: Optional[logging.Logger] = None,
                 schemas: Optional[Dict[str, Dict]] = None):
        """
        Initialize unified schema validator.
        
        ENHANCED: Can work with pre-loaded schemas (no storage needed).
        
        Args:
            schema_storage: Schema storage instance (optional if schemas provided)
            tenant_id: Tenant identifier for multi-tenant support
            logger: Logger instance
            schemas: Pre-loaded schemas dict {schema_name: schema_content} (optional)
                    These should be resolved schemas with inheritance merged
        """
        self.storage = schema_storage
        self.tenant_id = tenant_id
        self.logger = logger or logging.getLogger(__name__)
        
        # Pre-loaded schemas (resolved with inheritance)
        self._preloaded_schemas = schemas or {}
        
        # Cache for loaded schemas
        self._schema_cache: Dict[str, Dict] = {}
        
        # Type mapping from schema types to Python types (for runtime validation)
        # Tries schema_model.json first, falls back to hardcoded
        self.type_map = self._build_type_map()
        
        # Built-in types (also maintain as instance variable)
        self.builtin_types = self._get_builtin_types_from_model()
    
    # =============================================================================
    # ENCRYPTION DETECTION
    # =============================================================================
    
    @staticmethod
    def is_encrypted_value(value: Any) -> bool:
        """
        Check if a value is encrypted.
        
        Encrypted values have format: "ENC:VERSION:BASE64_CIPHERTEXT"
        
        Args:
            value: Value to check
            
        Returns:
            True if value is encrypted
        """
        return isinstance(value, str) and value.startswith("ENC:")
    
    def contains_encrypted_values(self, data: Dict[str, Any]) -> bool:
        """
        Check if data contains any encrypted field values.
        
        Args:
            data: Dictionary to check
            
        Returns:
            True if any field contains encrypted data
        """
        for key, value in data.items():
            if key in self.SYSTEM_FIELDS:
                continue
            
            if self.is_encrypted_value(value):
                return True
            
            if isinstance(value, list):
                if any(self.is_encrypted_value(v) for v in value if isinstance(v, str)):
                    return True
            
            if isinstance(value, dict):
                if self.contains_encrypted_values(value):
                    return True
        
        return False
    
    # =============================================================================
    # SCHEMA RETRIEVAL (FOR RUNTIME VALIDATION)
    # =============================================================================
    
    def get_schema(self, schema_name: str, schema_type: str = 'objects') -> Dict[str, Any]:
        """
        Get schema from pre-loaded schemas or storage.
        
        ENHANCED: 
        - Normalizes input to snake_case
        - Prioritizes pre-loaded schemas (resolved with inheritance)
        
        Args:
            schema_name: Schema name (any case format)
            schema_type: Schema type (objects/types/enums)
            
        Returns:
            Schema dictionary (may include inherited attributes)
        """
        # Normalize to snake_case for consistent lookups
        # Preserve namespace prefix (e.g. 'nstest:test_widget' → 'nstest:test_widget')
        if ':' in schema_name:
            _ns, _bare = schema_name.split(':', 1)
            normalized_name = f"{_ns}:{normalize_schema_name(_bare)}"
        else:
            normalized_name = normalize_schema_name(schema_name)
        
        # Check pre-loaded schemas first (these are resolved)
        if normalized_name in self._preloaded_schemas:
            schema = self._preloaded_schemas[normalized_name]
            # Log if this schema has inheritance
            if schema.get('_base_class'):
                self.logger.debug(
                    f"Using resolved schema for {normalized_name} "
                    f"(extends {schema.get('_base_class')})"
                )
            return schema
        
        # Check cache with normalized name
        cache_key = f"{schema_type}:{normalized_name}"
        if cache_key in self._schema_cache:
            return self._schema_cache[cache_key]
        
        # Try to load from storage (storage also handles normalization)
        if not self.storage:
            raise SchemaNotFoundError(
                f"Schema not found for type '{normalized_name}' and no storage available"
            )
        
        try:
            # Storage.get_schema already handles name variations
            schema = self.storage.get_schema(self.tenant_id, normalized_name, schema_type)
            self._schema_cache[cache_key] = schema
            return schema
        except SchemaNotFoundError:
            # PascalCase fallback — ONLY for names that came in as CamelCase
            # (i.e. not already snake_case and not namespace-qualified).
            # Skipping this for snake_case names prevents inflection.camelize
            # from dropping underscores before digits:
            #   'test_widget_5' → camelize → 'TestWidget5'
            #   → normalize_schema_name → 'test_widget5'  ← WRONG
            is_snake = normalized_name == normalized_name.lower() and '_' in normalized_name
            is_qualified = ':' in normalized_name
            if is_snake or is_qualified:
                raise SchemaNotFoundError(
                    f"Schema not found: {schema_name} (tried: {normalized_name})"
                )
            try:
                pascal_name = inflection.camelize(normalized_name)
                schema = self.storage.get_schema(self.tenant_id, pascal_name, schema_type)
                self._schema_cache[cache_key] = schema
                return schema
            except SchemaNotFoundError:
                raise SchemaNotFoundError(
                    f"Schema not found: {schema_name} (tried: {normalized_name}, {pascal_name})"
                )

    def normalize_field_name(self, field_name: str) -> str:
        """Convert field name to Python snake_case convention."""
        return inflection.underscore(field_name)
    
    def find_field_value(self, data: Dict[str, Any], field_name: str) -> Tuple[Optional[str], Any]:
        """
        Find field value in data using multiple naming conventions.
        
        Returns:
            Tuple of (found_key, value) or (None, None) if not found
        """
        # Try multiple naming variations
        variations = [
            field_name,                              # original
            self.normalize_field_name(field_name),   # snake_case
            field_name.replace('_', '-'),            # kebab-case
            inflection.dasherize(field_name),        # dasherize
            inflection.camelize(field_name, False),  # camelCase
        ]
        
        # Remove duplicates while preserving order
        variations = list(dict.fromkeys(variations))
        
        for variant in variations:
            if variant in data:
                return variant, data[variant]
        
        return None, None
    
    # =============================================================================
    # RUNTIME FIELD VALIDATION (WITH ENCRYPTION SUPPORT)
    # =============================================================================
    
    def validate_field_type(self, value: Any, field_type: str, 
                           field_name: str, is_list: bool = False) -> Any:
        """
        Validate a field value against its type (RUNTIME VALIDATION).
        
        Automatically detects and skips validation for encrypted values.
        
        Args:
            value: The value to validate
            field_type: Expected type name
            field_name: Field name for error messages
            is_list: Whether this is a list field
            
        Returns:
            The validated value
            
        Raises:
            SchemaValidationError: If validation fails
        """
        if value is None:
            return [] if is_list else None
        
        # Check if value is encrypted
        if self.is_encrypted_value(value):
            self.logger.debug(f"Field '{field_name}' is encrypted - skipping value validation")
            return value  # Return encrypted value as-is
        
        if is_list:
            if not isinstance(value, list):
                raise SchemaValidationError(
                    f"Field '{field_name}' must be a list, got {type(value).__name__}",
                    field=field_name,
                    value=value
                )
            
            # Check if list contains encrypted values
            has_encrypted = any(self.is_encrypted_value(item) for item in value if isinstance(item, str))
            if has_encrypted:
                self.logger.debug(f"List field '{field_name}' contains encrypted values - skipping validation")
                return value  # Return list with encrypted values as-is
            
            # Validate each item in the list (non-encrypted)
            validated_items = []
            for i, item in enumerate(value):
                try:
                    validated_item = self.validate_field_type(
                        item, field_type, f"{field_name}[{i}]", is_list=False
                    )
                    validated_items.append(validated_item)
                except SchemaValidationError as e:
                    raise SchemaValidationError(
                        f"List item {i} validation failed: {str(e)}",
                        field=f"{field_name}[{i}]",
                        value=item
                    )
            return validated_items
        
        # Check if it's a built-in type
        python_type = self.type_map.get(field_type.lower())
        
        if python_type:
            # Validate built-in type
            if not isinstance(value, python_type):
                # Try to coerce certain types
                if python_type == int and isinstance(value, (float, str)):
                    try:
                        return int(value)
                    except (ValueError, TypeError):
                        pass
                elif python_type == float and isinstance(value, (int, str)):
                    try:
                        return float(value)
                    except (ValueError, TypeError):
                        pass
                elif python_type == bool and isinstance(value, str):
                    return value.lower() in ('true', '1', 'yes', 'on')
                elif python_type == str:
                    return str(value)
                elif python_type == dict and isinstance(value, str):
                    try:
                        import json
                        parsed = json.loads(value)
                        if isinstance(parsed, dict):
                            return parsed
                    except (json.JSONDecodeError, TypeError):
                        pass
                elif python_type == (dict, list) and isinstance(value, str):
                    # json type: coerce JSON string → dict or list
                    try:
                        import json
                        parsed = json.loads(value)
                        if isinstance(parsed, (dict, list)):
                            return parsed
                    except (json.JSONDecodeError, TypeError):
                        pass

                type_name = (
                    " | ".join(t.__name__ for t in python_type)
                    if isinstance(python_type, tuple)
                    else python_type.__name__
                )
                raise SchemaValidationError(
                    f"Field '{field_name}' expected {type_name}, got {type(value).__name__}",
                    field=field_name,
                    value=value
                )
            return value
        
        # Check if it's an enum type
        if self.storage:
            try:
                enum_schema = self.storage.get_enum_schema(field_type, self.tenant_id)
                if enum_schema:
                    # Validate enum value (only for plaintext values)
                    allowed_values = enum_schema.get('values', [])
                    if value not in allowed_values:
                        raise SchemaValidationError(
                            f"Invalid enum value for '{field_name}': '{value}' not in {allowed_values}",
                            field=field_name,
                            value=value
                        )
                    return value
            except:
                pass  # Not an enum, continue
        
        # For custom types, validate structure if it's a dict
        if isinstance(value, dict):
            # Try to validate nested custom type
            try:
                return self.validate_object(value, field_type, is_create=False, 
                                           validate_parent=False, schema_type='types')
            except:
                # If validation fails, return as-is
                self.logger.debug(f"Could not validate custom type '{field_type}' for field '{field_name}'")
                return value
        
        return value
    

    def _build_type_map(self):
        """Build runtime type map. Tries schema_model.json, falls back to hardcoded."""
        _type_name_to_class = {
            'str': str, 'int': int, 'float': float,
            'bool': bool, 'dict': dict,
        }
        if _SCHEMA_MODEL_AVAILABLE:
            try:
                model_map = _get_model_type_map()
                return {
                    k: _type_name_to_class.get(v, str)
                    for k, v in model_map.items()
                }
            except Exception:
                pass
        # Hardcoded fallback
        return {
            'string': str, 'str': str,
            'integer': int, 'int': int,
            'boolean': bool, 'bool': bool,
            'float': float, 'number': float,
            'uuid': str, 'date': str, 'datetime': str,
            'json': (dict, list), 'map': dict, 'dict': dict, 'object': dict,
        }

    def _is_attr_list(self, attr):
        """Check if attribute is a list type."""
        if not attr:
            return False
        is_list = (attr.get("IsList") or attr.get("List") or attr.get("isList") or 
                   attr.get("is-list") or attr.get("list") or attr.get("is_list"))
        return bool(is_list)

    # =============================================================================
    # RUNTIME OBJECT VALIDATION (WITH INHERITANCE, ENCRYPTION, AND v3.2 FIX)
    # =============================================================================
    
    def validate_object(self, obj_data: Dict[str, Any], obj_type: str,
                       is_create: bool = True,
                       validate_parent: bool = True,
                       schema_type: str = 'objects') -> Dict[str, Any]:
        """
        Validate an object against its schema (RUNTIME VALIDATION).

        ENHANCED:
        - Automatically handles encrypted field values
        - Works with resolved schemas (inheritance already merged)
        - Validates against all attributes including inherited ones
        - ✅ v3.2 FIX: Validates 'values' constraints for inline enum validation

        Args:
            obj_data: Object data to validate
            obj_type: Object type (snake_case or PascalCase)
            is_create: Whether this is a create operation (validates mandatory fields)
            validate_parent: Whether to validate parent exists (not implemented here)
            schema_type: Schema category ('objects', 'types', 'enums')

        Returns:
            Normalized and validated object data

        Raises:
            SchemaValidationError: If validation fails
        """
        # Convert obj_type to schema name (PascalCase)
        schema_name = normalize_schema_name(obj_type)

        try:
            schema = self.get_schema(schema_name, schema_type)
        except SchemaNotFoundError as e:
            raise SchemaValidationError(
                f"Schema not found for object type '{obj_type}': {str(e)}",
                errors=[str(e)]
            )

        validated_data = {}
        errors = []

        # Get schema attributes (includes inherited attributes if schema is resolved)
        attributes = schema.get('attributes', [])
        parent_type = schema.get('parent_type', 'config-root')
        references = schema.get('references', [])

        # Log if validating against resolved schema with inheritance
        base_class = schema.get('_base_class')
        if base_class:
            self.logger.info(
                f"Validating {obj_type} against resolved schema "
                f"(extends {base_class}, {len(attributes)} total attributes)"
            )

        # Validate attributes (includes inherited attributes)
        for attr in attributes:
            attr_name = attr['name']
            attr_type = attr.get('type', 'string')
            is_mandatory = attr.get('mandatory', False)
            is_list = self._is_attr_list(attr)
            default_value = attr.get('default-value')
            is_static = attr.get('static', False)

            # Skip static fields
            if is_static:
                continue

            # Find field in data (flexible naming)
            found_key, field_value = self.find_field_value(obj_data, attr_name)

            # Check mandatory fields on create (skip uuid - optional even if mandatory)
            if is_create and is_mandatory and not found_key and default_value is None:
                if attr_name != 'uuid':  # UUID is special case
                    errors.append(f"Missing mandatory field: {attr_name}")
                    continue

            # Validate if field is present
            if found_key:
                try:
                    # validate_field_type handles encrypted values automatically
                    validated_value = self.validate_field_type(
                        field_value, attr_type, attr_name, is_list
                    )

                    # ✅ v3.2 FIX: Check 'values' constraint (inline enum validation)
                    values = attr.get('values')
                    if values and validated_value is not None:
                        # Skip validation for encrypted values
                        if not self.is_encrypted_value(validated_value):
                            if is_list:
                                # Validate each item in list
                                for i, item in enumerate(validated_value):
                                    if not self.is_encrypted_value(item) and item not in values:
                                        raise SchemaValidationError(
                                            f"Invalid value '{item}' for field '{attr_name}[{i}]'. "
                                            f"Allowed values: {values}",
                                            field=f"{attr_name}[{i}]",
                                            value=item
                                        )
                            else:
                                # Validate single value
                                if validated_value not in values:
                                    raise SchemaValidationError(
                                        f"Invalid value '{validated_value}' for field '{attr_name}'. "
                                        f"Allowed values: {values}",
                                        field=attr_name,
                                        value=validated_value
                                    )

                    # Store with normalized name
                    normalized_name = self.normalize_field_name(attr_name)
                    validated_data[normalized_name] = validated_value
                except SchemaValidationError as e:
                    errors.append(str(e))
            elif default_value is not None:
                # Apply default value
                normalized_name = self.normalize_field_name(attr_name)
                validated_data[normalized_name] = default_value

        # Validate references (for objects only) - RUNTIME VALIDATION
        if schema_type == 'objects' and references:
            for ref in references:
                ref_name = ref['name']
                ref_field_name = self.normalize_field_name(ref_name) + '_refs'

                # Find reference field
                found_key, ref_value = self.find_field_value(obj_data, ref_field_name)

                if found_key:
                    # Validate reference structure
                    # (additional validation logic here if needed)
                    normalized_name = self.normalize_field_name(ref_name) + '_refs'
                    validated_data[normalized_name] = ref_value

        # ================================================================
        # SYSTEM FIELD: display_name (preserve or auto-generate)
        # ================================================================
        if obj_data.get('display_name'):
            validated_data['display_name'] = obj_data['display_name']
        elif validated_data.get('name') and is_create:
            pascal = inflection.camelize(validated_data['name'].replace('-', '_'))
            validated_data['display_name'] = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', pascal)

        # If there were validation errors, raise exception
        if errors:
            raise SchemaValidationError(
                f"Validation failed for {obj_type}",
                errors=errors
            )

        return validated_data
    
    # =============================================================================
    # RUNTIME HELPER METHODS
    # =============================================================================
    
    def get_parent_type(self, obj_type: str, namespace: str = None) -> str:
        """
        Get the parent type for an object schema.
        Works with resolved schemas.
        """
        if namespace:
            obj_type = f"{namespace}:{obj_type}"

        schema_name = normalize_schema_name(obj_type)
        schema = self.get_schema(schema_name, 'objects')
        parent = schema.get('parent_type') or 'config-root'
        return self.normalize_field_name(parent)

    def get_parent_chain(self, obj_type: str, namespace: str = None) -> list:
        chain = []
        if namespace:
            current = f"{namespace}:{normalize_schema_name(obj_type)}"
        else:
            current = normalize_schema_name(obj_type)

        while True:
            schema = self.get_schema(current, 'objects')
            parent = schema.get('parent_type')
            if not parent:
                break
            parent = self.normalize_field_name(parent)
            if parent in ('system_root', 'config_root'):
                break
            chain.insert(0, parent)
            # Qualify parent with namespace if it's a custom type (not platform hierarchy)
            # This ensures the S3 lookup uses the namespaced path
            if parent not in ('domain', 'project', 'tenant') and namespace and ':' not in parent:
                current = f"{namespace}:{parent}"
            else:
                current = parent

        return chain

    def resolve_parent_fq_name(
        self,
        *,
        obj_type: str,
        name: str,
        parent_fq_name: list | None,
        parent_context: dict,
        namespace: str = None
    ) -> list:
        """
        Resolve full fq_name using:
        - schema parent hierarchy
        - partial parent_fq_name (optional)
        - parent_context (tenant / project)

        FAILS FAST if fq_name cannot be deterministically resolved.
        """

        if not name:
            raise SchemaValidationError(
                f"Cannot resolve fq_name for '{obj_type}': missing object name"
            )

        parent_chain = self.get_parent_chain(obj_type, namespace)
        # example: ['tenant', 'project']

        context_map = dict(parent_context)

        resolved_parent_fq = []

        if parent_fq_name:
            if not isinstance(parent_fq_name, list):
                raise SchemaValidationError(
                    "parent_fq_name must be a list if provided"
                )

            offset = len(parent_chain) - len(parent_fq_name)
            if offset < 0:
                raise SchemaValidationError(
                    f"Cannot resolve fq_name for '{obj_type}': "
                    f"parent_fq_name deeper than schema hierarchy"
                )

            # fill missing parents from context
            for p in parent_chain[:offset]:
                val = context_map.get(p)
                if not val:
                    raise SchemaValidationError(
                        f"Cannot resolve fq_name for '{obj_type}': "
                        f"missing '{p}' in parent_context"
                    )
                resolved_parent_fq.append(val)

            resolved_parent_fq.extend(parent_fq_name)

        else:
            # no parent_fq_name → must resolve entirely from context
            for p in parent_chain:
                val = context_map.get(p)
                if not val:
                    raise SchemaValidationError(
                        f"Cannot resolve fq_name for '{obj_type}': "
                        f"missing '{p}' in parent_context"
                    )
                resolved_parent_fq.append(val)

        # final fq_name
        return resolved_parent_fq + [name]

    def get_references(self, obj_type: str, namespace: str=None) -> List[str]:
        """
        Get list of reference names for an object schema.
        Works with resolved schemas (includes inherited references).
        """
        if namespace:
            obj_type = f'{namespace}:{obj_type}'
        schema_name = normalize_schema_name(obj_type)
        schema = self.get_schema(schema_name, 'objects')
        refs = schema.get('references', [])
        # Return normalized reference names (for ref_update validation)
        return [self.normalize_field_name(ref['name']) for ref in refs]
    
    def get_mandatory_fields(self, obj_type: str, schema_type: str = 'objects') -> List[str]:
        """
        Get list of mandatory field names for a schema.
        Works with resolved schemas (includes inherited mandatory fields).
        """
        schema_name = normalize_schema_name(obj_type)
        schema = self.get_schema(schema_name, schema_type)
        attributes = schema.get('attributes', [])
        
        mandatory = []
        for attr in attributes:
            if attr.get('mandatory', False) and not attr.get('static', False):
                normalized_name = self.normalize_field_name(attr['name'])
                mandatory.append(normalized_name)
        
        return mandatory
    
    def validate_partial_update(self, obj_data: Dict[str, Any], obj_type: str) -> Dict[str, Any]:
        """
        Validate a partial update (only validates fields that are present).
        
        Works with resolved schemas and handles encrypted values automatically.
        
        Args:
            obj_data: Partial object data to validate
            obj_type: Object type
            
        Returns:
            Validated partial data
        """
        return self.validate_object(obj_data, obj_type, is_create=False, validate_parent=False)
    
    def get_attribute_count(self, obj_type: str, schema_type: str = 'objects') -> Dict[str, int]:
        """
        Get attribute count statistics for a schema.
        Useful for debugging inheritance resolution.
        
        Returns:
            Dict with 'total', 'mandatory', 'optional' counts
        """
        try:
            schema_name = normalize_schema_name(obj_type)
            schema = self.get_schema(schema_name, schema_type)
            attributes = schema.get('attributes', [])
            
            total = len(attributes)
            mandatory = sum(1 for attr in attributes if attr.get('mandatory', False))
            optional = total - mandatory
            
            stats = {
                'total': total,
                'mandatory': mandatory,
                'optional': optional
            }
            
            # Add inheritance info if available
            if schema.get('_base_class'):
                stats['base_class'] = schema.get('_base_class')
                stats['has_inheritance'] = True
            else:
                stats['has_inheritance'] = False
            
            return stats
        except Exception as e:
            self.logger.error(f"Failed to get attribute count for {obj_type}: {e}")
            return {'total': 0, 'mandatory': 0, 'optional': 0, 'has_inheritance': False}

    @property
    def schemas(self) -> Dict[str, Dict]:
        """
        Get all available schemas (for testing/inspection).
        
        Returns combined view of preloaded schemas and cache.
        """
        # Combine preloaded schemas with cached schemas
        all_schemas = {}
        all_schemas.update(self._preloaded_schemas)
        
        # Add cached schemas (strip type prefix from cache keys)
        for cache_key, schema in self._schema_cache.items():
            # cache_key format: "objects:schema_name" or "types:schema_name"
            if ':' in cache_key:
                _, schema_name = cache_key.split(':', 1)
            else:
                schema_name = cache_key
            
            if schema_name not in all_schemas:
                all_schemas[schema_name] = schema
        
        return all_schemas

    # =============================================================================
    # SCHEMA STRUCTURE VALIDATION (FOR SCHEMA DEFINITIONS)
    # =============================================================================
    # These methods validate schema .json files BEFORE resolution
    # =============================================================================
    
    def _normalize_type_name(self, type_name: str) -> str:
        """
        Normalize type name for comparison.
        Handles: PascalCase, snake_case, kebab-case
        
        Examples:
            OrderLineItem -> orderlineitem
            order_line_item -> orderlineitem
            order-line-item -> orderlineitem
        """
        return type_name.lower().replace('_', '').replace('-', '')
    
    def _normalize_reference_name(self, ref_name: str) -> str:
        """
        Normalize reference name for comparison.
        Handles: PascalCase, snake_case, camelCase, kebab-case
        
        Examples:
            TeamMembers -> teammembers
            team_members -> teammembers
            teamMembers -> teammembers
            team-members -> teammembers
        """
        return ref_name.lower().replace('_', '').replace('-', '')
    
    def _is_valid_reference_name(self, ref_name: str) -> bool:
        """
        Validate reference name allows multiple naming conventions:
        - snake_case: team_members, user_account
        - PascalCase: TeamMembers, UserAccount  
        - camelCase: teamMembers, userAccount
        - kebab-case: team-members (also supported)
        
        Pattern: starts with letter or underscore, contains letters, numbers, underscores, hyphens
        """
        if not ref_name or not isinstance(ref_name, str):
            return False
        # Allow: snake_case, PascalCase, camelCase, kebab-case
        return bool(re.match(r'^[a-zA-Z_][a-zA-Z0-9_-]*$', ref_name))
    
    def _is_type_compatible(self, user_type: str, system_type: str, 
                           compatible_types: list = None) -> bool:
        """
        Check if user-defined type is compatible with system attribute type.
        """
        if not user_type:
            return True  # No type specified, will use system default
            
        user_type = user_type.lower().strip()
        system_type = system_type.lower().strip()
        
        # Exact match
        if user_type == system_type:
            return True
        
        # Check compatible types
        if compatible_types and user_type in [t.lower() for t in compatible_types]:
            return True
        
        # Common type aliases
        type_aliases = {
            'str': 'string',
            'int': 'integer',
            'bool': 'boolean',
            'dict': 'object',
            'list': 'array',
            'float': 'number',
            'double': 'number',
        }
        
        normalized_user = type_aliases.get(user_type, user_type)
        normalized_system = type_aliases.get(system_type, system_type)
        
        return normalized_user == normalized_system
    
    def _is_object_schema(self, schema: Dict, file_path: str = None) -> bool:
        """
        Determine if this is an object schema (vs custom type or enum).
        """
        # Check explicit type field
        schema_type = schema.get('schema_type')
        if schema_type:
            return schema_type.lower() in ['object']

        # If it's an enum, it's not an object
        if schema.get('enum') or 'values' in schema:
            return False
        
        # If no parent_type, it's likely a TYPE not an OBJECT
        if 'parent_type' not in schema:
            return False

        # Check file path hints
        if file_path:
            path_lower = file_path.lower()
            if '/types/' in path_lower:
                return False
            if '/enums/' in path_lower:
                return False
            if '/objects/' in path_lower:
                return True

        # Has parent_type = likely an object
        return True
    
    def _schema_error(self, message: str, schema_name: str = None, 
                     file_path: str = None, field: str = None) -> str:
        """Format schema error message with context"""
        context = []
        if file_path:
            context.append(f"File: {file_path}")
        if schema_name:
            context.append(f"Schema: {schema_name}")
        if field:
            context.append(f"Field: {field}")
        
        if context:
            return f"{message}\n  " + "\n  ".join(context)
        return message
    
    # Alias for backward compatibility
    _error = _schema_error
    
    def _find_similar_types(self, type_name: str, known_types, 
                           max_suggestions: int = 3) -> List[str]:
        """Find similar type names for suggestions"""
        suggestions = []
        type_lower = type_name.lower()
        
        for known in known_types:
            known_lower = known.lower()
            words = type_lower.replace('_', ' ').replace('-', ' ').split()
            for word in words:
                if len(word) > 2 and word in known_lower:
                    suggestions.append(known)
                    break
        
        return suggestions[:max_suggestions]

    def _validate_extends(self, schema: Dict, schema_name: str,
                         file_path: str) -> List[str]:
        """Backward compatibility alias for _validate_schema_extends"""
        return self._validate_schema_extends(schema, schema_name, file_path)

    def _validate_attributes(self, schema: Dict, schema_name: str,
                            file_path: str) -> List[str]:
        """Backward compatibility alias for _validate_schema_attributes"""
        return self._validate_schema_attributes(schema, schema_name, file_path)

    def _validate_references(self, schema: Dict, schema_name: str,
                            file_path: str) -> List[str]:
        """Backward compatibility alias for _validate_schema_references"""
        return self._validate_schema_references(schema, schema_name, file_path)

    def _validate_enum(self, schema: Dict, schema_name: str,
                      file_path: str) -> List[str]:
        """Backward compatibility alias for _validate_schema_enum"""
        return self._validate_schema_enum(schema, schema_name, file_path)


    def _validate_schema_extends(self, schema: Dict, schema_name: str, 
                                file_path: str) -> List[str]:
        """Validate extends field format"""
        errors = []
        extends = schema['extends']
        
        if not isinstance(extends, str):
            errors.append(self._schema_error(
                f"'extends' must be a string, got {type(extends).__name__}",
                schema_name, file_path, 'extends'
            ))
            return errors
        
        # Check for incorrect dot notation
        if '.' in extends:
            errors.append(self._schema_error(
                f"Invalid extends format: '{extends}'. "
                f"Use colon notation (e.g., 'subdomain:ClassName') not dot notation",
                schema_name, file_path, 'extends'
            ))
        
        # Require subdomain prefix
        if ':' not in extends:
            errors.append(self._schema_error(
                f"Invalid extends format: '{extends}'. "
                f"Subdomain prefix is required. Use 'subdomain:ClassName' format.\n"
                f"Examples:\n"
                f"  - 'general:Project' (from public/general)\n"
                f"  - 'healthcare:Patient' (from public/healthcare)\n"
                f"  - 'tenant:{extends}' (from tenant's own schemas)",
                schema_name, file_path, 'extends'
            ))
            return errors
        
        # Check for multiple colons
        if extends.count(':') > 1:
            errors.append(self._schema_error(
                f"Invalid extends format: '{extends}'. "
                f"Use exactly one colon (e.g., 'subdomain:ClassName')",
                schema_name, file_path, 'extends'
            ))
        
        # Validate subdomain and class name
        parts = extends.split(':', 1)
        subdomain = parts[0]
        class_name = parts[1]
        
        if not subdomain:
            errors.append(self._schema_error(
                f"Empty subdomain in extends: '{extends}'",
                schema_name, file_path, 'extends'
            ))
        
        if not class_name:
            errors.append(self._schema_error(
                f"Empty class name in extends: '{extends}'",
                schema_name, file_path, 'extends'
            ))
        
        if subdomain and not re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', subdomain):
            errors.append(self._schema_error(
                f"Invalid subdomain name: '{subdomain}'. "
                f"Must start with letter and contain only letters, numbers, hyphens, underscores",
                schema_name, file_path, 'extends'
            ))
        
        if class_name and not re.match(r'^[A-Z][a-zA-Z0-9]*$', class_name):
            errors.append(self._schema_error(
                f"Invalid class name: '{class_name}'. "
                f"Must be PascalCase (start with uppercase letter)",
                schema_name, file_path, 'extends'
            ))
        
        return errors
    
    def _validate_reserved_attributes(self, schema: Dict, schema_name: str, 
                                     file_path: str) -> List[str]:
        """
        Validate system attributes in OBJECT schemas.
        
        Allows system attribute with MATCHING type.
        Errors on MISMATCHING type.
        """
        errors = []
        attributes = schema.get('attributes', [])
        
        # Handle both list and dict format
        attr_map = {}
        if isinstance(attributes, list):
            for attr in attributes:
                if isinstance(attr, dict) and 'name' in attr:
                    attr_map[attr['name']] = attr
        elif isinstance(attributes, dict):
            attr_map = attributes
        
        # Check each attribute against system attributes
        for attr_name, attr_details in attr_map.items():
            if attr_name not in self.SYSTEM_ATTRIBUTES:
                continue
            
            system_attr = self.SYSTEM_ATTRIBUTES[attr_name]
            system_type = system_attr['type']
            compatible = system_attr.get('compatible', [])
            
            user_type = None
            if isinstance(attr_details, dict):
                user_type = attr_details.get('type')
            
            if not user_type:
                continue
            
            if not self._is_type_compatible(user_type, system_type, compatible):
                compatible_str = f" (or: {', '.join(compatible)})" if compatible else ""
                errors.append(self._schema_error(
                    f"❌ SYSTEM ATTRIBUTE TYPE MISMATCH: '{attr_name}'\n"
                    f"\n"
                    f"You defined '{attr_name}' with type '{user_type}', but the system\n"
                    f"requires type '{system_type}'{compatible_str}.\n"
                    f"\n"
                    f"💡 SOLUTIONS:\n"
                    f"   1. Change type to '{system_type}'\n"
                    f"   2. Remove the attribute (system will provide it)\n"
                    f"   3. Use a different attribute name\n"
                    f"\n"
                    f"✓ TIP: You CAN define system attributes to add constraints\n"
                    f"  (description, min-length, etc.) - just keep the correct type.",
                    schema_name, file_path, f'attributes.{attr_name}'
                ))
        
        return errors
    
    def _validate_schema_attributes(self, schema: Dict, schema_name: str, 
                                   file_path: str) -> List[str]:
        """Validate attributes structure in schema definition"""
        errors = []
        attributes = schema['attributes']
        
        if isinstance(attributes, dict):
            for attr_name, attr_details in attributes.items():
                if not isinstance(attr_details, dict):
                    errors.append(self._schema_error(
                        f"Attribute '{attr_name}' must be a dict with 'type' field",
                        schema_name, file_path, f'attributes.{attr_name}'
                    ))
                    continue
                
                if 'type' not in attr_details:
                    if attr_name not in self.SYSTEM_ATTRIBUTES:
                        errors.append(self._schema_error(
                            f"Attribute '{attr_name}' missing required field: 'type'",
                            schema_name, file_path, f'attributes.{attr_name}'
                        ))
        
        elif isinstance(attributes, list):
            seen_names = set()
            
            for i, attr in enumerate(attributes):
                if not isinstance(attr, dict):
                    errors.append(self._schema_error(
                        f"Attribute at index {i} must be a dict",
                        schema_name, file_path, f'attributes[{i}]'
                    ))
                    continue
                
                if 'name' not in attr:
                    errors.append(self._schema_error(
                        f"Attribute at index {i} missing required field: 'name'",
                        schema_name, file_path, f'attributes[{i}]'
                    ))
                else:
                    attr_name = attr['name']
                    if attr_name in seen_names:
                        errors.append(self._schema_error(
                            f"Duplicate attribute name: '{attr_name}'",
                            schema_name, file_path, f'attributes[{i}]'
                        ))
                    seen_names.add(attr_name)
                
                if 'type' not in attr:
                    attr_name = attr.get('name', f'index_{i}')
                    if attr_name not in self.SYSTEM_ATTRIBUTES:
                        errors.append(self._schema_error(
                            f"Attribute '{attr_name}' missing required field: 'type'",
                            schema_name, file_path, f'attributes[{i}]'
                        ))
        else:
            errors.append(self._schema_error(
                f"'attributes' must be a list or dict, got {type(attributes).__name__}",
                schema_name, file_path, 'attributes'
            ))
        
        return errors
    
    def _validate_schema_references(self, schema: Dict, schema_name: str, 
                                   file_path: str) -> List[str]:
        """Validate references structure and naming conventions in schema definition"""
        errors = []
        references = schema['references']
        
        if not isinstance(references, list):
            errors.append(self._schema_error(
                f"'references' must be a list, got {type(references).__name__}",
                schema_name, file_path, 'references'
            ))
            return errors
        
        seen_names = set()
        seen_normalized_names = {}
        
        for i, ref in enumerate(references):
            if not isinstance(ref, dict):
                errors.append(self._schema_error(
                    f"Reference at index {i} must be a dict",
                    schema_name, file_path, f'references[{i}]'
                ))
                continue
            
            if 'name' not in ref and 'type' not in ref:
                errors.append(self._schema_error(
                    f"Reference at index {i} must have 'name' or 'type' field",
                    schema_name, file_path, f'references[{i}]'
                ))
                continue
            
            ref_name = ref.get('name') or ref.get('type')
            
            if ref_name and not self._is_valid_reference_name(ref_name):
                errors.append(self._schema_error(
                    f"Invalid reference name: '{ref_name}'\n"
                    f"\n"
                    f"Reference names must:\n"
                    f"  - Start with a letter or underscore\n"
                    f"  - Contain only letters, numbers, underscores, or hyphens\n"
                    f"\n"
                    f"✅ Allowed formats:\n"
                    f"   - snake_case: team_members, user_account\n"
                    f"   - PascalCase: TeamMembers, UserAccount\n"
                    f"   - camelCase: teamMembers, userAccount\n"
                    f"   - kebab-case: team-members",
                    schema_name, file_path, f'references[{i}].name'
                ))
                continue
            
            if ref_name in seen_names:
                errors.append(self._schema_error(
                    f"Duplicate reference name: '{ref_name}'",
                    schema_name, file_path, f'references[{i}]'
                ))
            seen_names.add(ref_name)
            
            if ref_name:
                normalized = self._normalize_reference_name(ref_name)
                if normalized in seen_normalized_names:
                    original = seen_normalized_names[normalized]
                    if original != ref_name:
                        errors.append(self._schema_error(
                            f"⚠️ Reference name collision: '{ref_name}' and '{original}'\n"
                            f"\n"
                            f"These names normalize to the same identifier and will\n"
                            f"conflict in generated code.\n"
                            f"\n"
                            f"💡 Use distinct names to avoid collisions.",
                            schema_name, file_path, f'references[{i}].name'
                        ))
                else:
                    seen_normalized_names[normalized] = ref_name
            
            if 'attr' in ref:
                attr_type = ref['attr']
                if attr_type and not isinstance(attr_type, str):
                    errors.append(self._schema_error(
                        f"Reference 'attr' must be a string (TYPE or ENUM name), got {type(attr_type).__name__}",
                        schema_name, file_path, f'references[{i}].attr'
                    ))
            
            if 'cardinality' in ref:
                cardinality = ref['cardinality']
                if cardinality not in ('one', 'many'):
                    errors.append(self._schema_error(
                        f"Reference 'cardinality' must be 'one' or 'many', got '{cardinality}'",
                        schema_name, file_path, f'references[{i}].cardinality'
                    ))
            
            ref_type = ref.get('type')
            if ref_type and not isinstance(ref_type, str):
                errors.append(self._schema_error(
                    f"Reference 'type' must be a string, got {type(ref_type).__name__}",
                    schema_name, file_path, f'references[{i}].type'
                ))
            elif ref_type and not self._is_valid_reference_name(ref_type) and ':' not in ref_type:
                errors.append(self._schema_error(
                    f"Invalid reference type: '{ref_type}'\n"
                    f"\n"
                    f"Reference types must:\n"
                    f"  - Start with a letter or underscore\n"
                    f"  - Contain only letters, numbers, underscores, or hyphens\n"
                    f"  - Or use namespace:type format (e.g., 'general:Project')\n"
                    f"\n"
                    f"✅ Allowed formats:\n"
                    f"   - snake_case: team_member, user_account\n"
                    f"   - PascalCase: TeamMember, UserAccount\n"
                    f"   - camelCase: teamMember, userAccount\n"
                    f"   - Namespaced: general:Project, healthcare:Patient",
                    schema_name, file_path, f'references[{i}].type'
                ))
        
        return errors
    
    def _validate_attribute_types_exist(self, schema: Dict, schema_name: str,
                                        file_path: str, 
                                        known_schemas: Dict[str, Dict]) -> List[str]:
        """Validate that all attribute types reference existing schemas"""
        errors = []
        attributes = schema.get('attributes', [])
        
        if not known_schemas:
            return errors
        
        normalized_to_actual = {}
        for name in known_schemas.keys():
            normalized = self._normalize_type_name(name)
            normalized_to_actual[normalized] = name
        
        attr_list = []
        if isinstance(attributes, list):
            attr_list = attributes
        elif isinstance(attributes, dict):
            attr_list = [{'name': k, **v} for k, v in attributes.items()]
        
        for attr in attr_list:
            if not isinstance(attr, dict):
                continue
                
            attr_name = attr.get('name', 'unknown')
            attr_type = attr.get('type', '')
            
            if not attr_type or attr_type.lower() in self.builtin_types:
                continue
            
            if ':' in attr_type:
                continue
            
            normalized_type = self._normalize_type_name(attr_type)
            
            if normalized_type not in normalized_to_actual:
                suggestions = self._find_similar_types(attr_type, known_schemas.keys())
                suggestion_str = ""
                if suggestions:
                    suggestion_str = f"\n\n💡 Did you mean: {', '.join(suggestions)}?"
                
                errors.append(self._schema_error(
                    f"❌ UNKNOWN TYPE: '{attr_type}'\n"
                    f"\n"
                    f"Attribute '{attr_name}' references type '{attr_type}' which doesn't exist.\n"
                    f"\n"
                    f"💡 SOLUTIONS:\n"
                    f"   1. Create a TYPE schema named '{attr_type}'\n"
                    f"   2. Check spelling of the type name\n"
                    f"   3. Use a builtin type: string, integer, boolean, etc."
                    f"{suggestion_str}",
                    schema_name, file_path, f'attributes.{attr_name}'
                ))
        
        return errors
    
    def _validate_type_vs_object_usage(self, schema: Dict, schema_name: str,
                                       file_path: str,
                                       known_schemas: Dict[str, Dict]) -> List[str]:
        """Validate that OBJECTs aren't used as attribute types"""
        errors = []
        attributes = schema.get('attributes', [])
        
        if not known_schemas:
            return errors
        
        normalized_to_schema = {}
        for name, s in known_schemas.items():
            normalized = self._normalize_type_name(name)
            normalized_to_schema[normalized] = (name, s)
        
        attr_list = []
        if isinstance(attributes, list):
            attr_list = attributes
        elif isinstance(attributes, dict):
            attr_list = [{'name': k, **v} for k, v in attributes.items()]
        
        for attr in attr_list:
            if not isinstance(attr, dict):
                continue
            
            attr_name = attr.get('name', 'unknown')
            attr_type = attr.get('type', '')
            
            if not attr_type or attr_type.lower() in self.builtin_types:
                continue
            
            if ':' in attr_type:
                continue
            
            normalized_type = self._normalize_type_name(attr_type)
            
            if normalized_type in normalized_to_schema:
                actual_name, referenced_schema = normalized_to_schema[normalized_type]
                
                has_parent_type = 'parent_type' in referenced_schema
                is_enum = referenced_schema.get('enum') or 'values' in referenced_schema
                
                if has_parent_type and not is_enum:
                    errors.append(self._schema_error(
                        f"❌ OBJECT USED AS TYPE: '{actual_name}'\n"
                        f"\n"
                        f"Attribute '{attr_name}' uses '{actual_name}' as its type,\n"
                        f"but '{actual_name}' is an OBJECT (has parent_type).\n"
                        f"\n"
                        f"OBJECTs cannot be used as attribute types.\n"
                        f"\n"
                        f"💡 SOLUTIONS:\n"
                        f"   1. Convert '{actual_name}' to a TYPE (remove parent_type)\n"
                        f"   2. Use 'references' array instead:\n"
                        f"      \"references\": [{{\"type\": \"{actual_name}\"}}]\n"
                        f"   3. Create a separate TYPE for embedded data",
                        schema_name, file_path, f'attributes.{attr_name}'
                    ))
        
        return errors
    
    def _validate_reference_types_exist(self, schema: Dict, schema_name: str,
                                        file_path: str, 
                                        known_schemas: Dict[str, Dict]) -> List[str]:
        """Validate that all reference types exist in known schemas"""
        errors = []
        references = schema.get('references', [])
        
        if not references or not known_schemas:
            return errors
        
        normalized_to_actual = {}
        for name in known_schemas.keys():
            normalized = self._normalize_type_name(name)
            normalized_to_actual[normalized] = name
        
        for i, ref in enumerate(references):
            if not isinstance(ref, dict):
                continue
            
            ref_type = ref.get('type')
            ref_name = ref.get('name', f'ref_{i}')
            
            if not ref_type:
                ref_type = ref_name
            
            if not ref_type:
                continue
            
            if ':' in ref_type:
                continue
            
            normalized_type = self._normalize_type_name(ref_type)
            
            if normalized_type not in normalized_to_actual:
                suggestions = self._find_similar_types(ref_type, known_schemas.keys())
                suggestion_str = ""
                if suggestions:
                    suggestion_str = f"\n\n💡 Did you mean: {', '.join(suggestions)}?"
                
                errors.append(self._schema_error(
                    f"❌ UNKNOWN REFERENCE TYPE: '{ref_type}'\n"
                    f"\n"
                    f"Reference '{ref_name}' targets type '{ref_type}' which doesn't exist.\n"
                    f"\n"
                    f"💡 SOLUTIONS:\n"
                    f"   1. Create an OBJECT schema named '{ref_type}'\n"
                    f"   2. Check spelling of the type name\n"
                    f"   3. Use namespace prefix for external types (e.g., 'general:Project')"
                    f"{suggestion_str}",
                    schema_name, file_path, f'references[{i}].type'
                ))
            
            attr_type = ref.get('attr')
            if attr_type:
                if ':' in attr_type:
                    continue
                
                normalized_attr = self._normalize_type_name(attr_type)
                
                if normalized_attr not in normalized_to_actual:
                    suggestions = self._find_similar_types(attr_type, known_schemas.keys())
                    suggestion_str = ""
                    if suggestions:
                        suggestion_str = f"\n\n💡 Did you mean: {', '.join(suggestions)}?"
                    
                    errors.append(self._schema_error(
                        f"❌ UNKNOWN LINK DATA TYPE: '{attr_type}'\n"
                        f"\n"
                        f"Reference '{ref_name}' uses '{attr_type}' for link data,\n"
                        f"but this type doesn't exist.\n"
                        f"\n"
                        f"💡 SOLUTIONS:\n"
                        f"   1. Create a TYPE schema named '{attr_type}'\n"
                        f"   2. Create an ENUM schema named '{attr_type}'\n"
                        f"   3. Check spelling of the type name"
                        f"{suggestion_str}",
                        schema_name, file_path, f'references[{i}].attr'
                    ))
                else:
                    actual_name = normalized_to_actual.get(normalized_attr)
                    attr_schema = known_schemas.get(actual_name) if actual_name else None
                    
                    if attr_schema:
                        has_parent_type = 'parent_type' in attr_schema
                        is_enum = attr_schema.get('enum') or 'values' in attr_schema
                        
                        if has_parent_type and not is_enum:
                            errors.append(self._schema_error(
                                f"❌ OBJECT USED AS LINK DATA: '{actual_name}'\n"
                                f"\n"
                                f"Reference '{ref_name}' uses '{actual_name}' for link data (attr),\n"
                                f"but '{actual_name}' is an OBJECT (has parent_type).\n"
                                f"\n"
                                f"Link data must be a TYPE or ENUM, not an OBJECT.\n"
                                f"\n"
                                f"💡 SOLUTIONS:\n"
                                f"   1. Create a TYPE schema for link metadata\n"
                                f"   2. Use an ENUM for simple link attributes\n"
                                f"   3. Remove 'attr' if no link data needed",
                                schema_name, file_path, f'references[{i}].attr'
                            ))
        
        return errors
    
    def _validate_schema_enum(self, schema: Dict, schema_name: str, 
                             file_path: str) -> List[str]:
        """Validate enum structure"""
        errors = []
        
        if 'values' not in schema:
            errors.append(self._schema_error(
                "Enum must have 'values' field",
                schema_name, file_path, 'values'
            ))
            return errors
        
        values = schema['values']
        
        if not isinstance(values, list):
            errors.append(self._schema_error(
                f"Enum 'values' must be a list, got {type(values).__name__}",
                schema_name, file_path, 'values'
            ))
            return errors
        
        if len(values) == 0:
            errors.append(self._schema_error(
                "Enum 'values' cannot be empty",
                schema_name, file_path, 'values'
            ))
        
        seen = set()
        for val in values:
            if val in seen:
                errors.append(self._schema_error(
                    f"Duplicate enum value: '{val}'",
                    schema_name, file_path, 'values'
                ))
            seen.add(val)
        
        if 'type' in schema:
            enum_type = schema['type']
            if enum_type not in ['string', 'int', 'integer', 'float']:
                errors.append(self._schema_error(
                    f"Enum 'type' must be string, int, or float, got '{enum_type}'",
                    schema_name, file_path, 'type'
                ))
        
        return errors
    
    def validate_schema(self, schema: Dict, schema_name: str = None, 
                       file_path: str = None,
                       known_schemas: Dict[str, Dict] = None) -> List[str]:
        """
        Validate a single schema DEFINITION and return list of error messages.
        
        This validates the schema structure itself, NOT object data.
        
        Args:
            schema: Schema dictionary to validate
            schema_name: Name of the schema (for context)
            file_path: File path (for context)
            known_schemas: Dict of all known schemas (for type validation)
            
        Returns:
            List of error messages (empty if valid)
        """
        errors = []
        schema_name = schema_name or schema.get('name', 'unknown')
        
        if 'name' not in schema:
            errors.append(self._schema_error("Missing required field: 'name'", 
                                            schema_name, file_path))
        
        if 'name' in schema:
            name = schema['name']
            if not name or not isinstance(name, str):
                errors.append(self._schema_error("Schema 'name' must be a non-empty string", 
                                                schema_name, file_path, 'name'))
        
        if 'extends' in schema:
            errors.extend(self._validate_schema_extends(schema, schema_name, file_path))
        
        if 'attributes' in schema:
            is_object_schema = self._is_object_schema(schema, file_path)
            if is_object_schema:
                errors.extend(self._validate_reserved_attributes(schema, schema_name, file_path))
            errors.extend(self._validate_schema_attributes(schema, schema_name, file_path))
        
        if 'attributes' in schema and known_schemas:
            errors.extend(self._validate_attribute_types_exist(
                schema, schema_name, file_path, known_schemas
            ))
            errors.extend(self._validate_type_vs_object_usage(
                schema, schema_name, file_path, known_schemas
            ))
        
        if 'references' in schema:
            errors.extend(self._validate_schema_references(schema, schema_name, file_path))
        
        if 'references' in schema and known_schemas:
            errors.extend(self._validate_reference_types_exist(
                schema, schema_name, file_path, known_schemas
            ))
        
        if schema.get('enum') or 'values' in schema:
            errors.extend(self._validate_schema_enum(schema, schema_name, file_path))
        
        if schema.get('enum') and 'attributes' in schema:
            errors.append(self._schema_error(
                "Schema cannot be both an enum and have attributes",
                schema_name, file_path
            ))
        
        return errors
    
    def validate_all_schemas(self, schemas: Dict[str, Dict], 
                            base_path: str = None) -> Dict[str, List[str]]:
        """
        Validate multiple schema DEFINITIONS with cross-schema type checking.
        
        Args:
            schemas: Dict of {schema_name: schema_content}
            base_path: Base path for file context
            
        Returns:
            Dict of {schema_name: [error_messages]} for schemas with errors
        """
        all_errors = {}
        
        for schema_name, schema in schemas.items():
            file_path = None
            if base_path:
                category = schema.get('_category', 'object')
                file_path = f"{base_path}/{category}/{schema.get('name', schema_name)}.json"
            
            errors = self.validate_schema(schema, schema_name, file_path, 
                                         known_schemas=schemas)
            if errors:
                all_errors[schema_name] = errors
        
        return all_errors
    
    def validate_schema_batch(self, schemas: List[Dict], 
                             base_path: str = None) -> Dict[str, List[str]]:
        """
        Validate a batch of schema definitions (list format).
        
        Args:
            schemas: List of schema dictionaries
            base_path: Base path for file context
            
        Returns:
            Dict of {schema_name: [error_messages]} for schemas with errors
        """
        schema_dict = {}
        for schema in schemas:
            name = schema.get('name', f'unknown_{len(schema_dict)}')
            schema_dict[name] = schema
        
        return self.validate_all_schemas(schema_dict, base_path)

    def format_validation_report(self, all_errors: Dict[str, List[str]]) -> str:
        """Format validation errors into a readable report"""
        if not all_errors:
            return "✓ All schemas valid"

        report = [f"✗ Found {len(all_errors)} schema(s) with errors:\n"]

        for schema_name, errors in all_errors.items():
            report.append(f"Schema '{schema_name}':")
            for error in errors:
                for line in error.split('\n'):
                    report.append(f"  {line}")
            report.append("")

        return "\n".join(report)


# =============================================================================
# MODULE-LEVEL FUNCTIONS (FOR BACKWARD COMPATIBILITY)
# =============================================================================

def validate_schemas_before_resolution(tenant_schemas: Dict[str, Dict],
                                       public_schemas: Dict[str, Dict],
                                       tenant_path: str = None,
                                       system_schemas: Dict[str, Dict] = None) -> None:
    """
    Validate all schemas before resolution.
    
    Raises SchemaValidationError if validation fails.
    
    Args:
        tenant_schemas: Tenant-specific schema definitions
        public_schemas: Public/shared schema definitions
        tenant_path: Path to tenant schemas (for error context)
        system_schemas: System schema definitions (Image, File, Address, etc.)
    """
    validator = SchemaValidator()
    
    # Combine all schemas for cross-schema validation
    # System schemas provide types like Image, File, Address that tenants reference
    all_schemas = {}
    if system_schemas:
        all_schemas.update(system_schemas)
    all_schemas.update(public_schemas)
    all_schemas.update(tenant_schemas)
    
    # Validate tenant schemas (with access to public + system schemas for type lookup)
    tenant_errors = {}
    for name, schema in tenant_schemas.items():
        errors = validator.validate_schema(schema, name, known_schemas=all_schemas)
        if errors:
            tenant_errors[name] = errors
    
    if tenant_errors:
        report = validator.format_validation_report(tenant_errors)
        raise SchemaValidationError(
            f"Schema validation failed:\n\n{report}"
        )


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'SchemaValidator',
    'SchemaValidationError',
    'SchemaNotFoundError',
    'validate_schemas_before_resolution',
]
