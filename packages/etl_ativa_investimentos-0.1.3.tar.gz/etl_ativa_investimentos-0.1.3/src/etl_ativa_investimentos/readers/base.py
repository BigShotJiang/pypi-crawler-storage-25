from abc import ABC
from types import ModuleType

import pandas as pd
from pandera.errors import SchemaError

from etl_ativa_investimentos.result import ValidationResult


class ExcelReader(ABC):
    _SHEETS: list[str] = []
    _reader_module: ModuleType
    _schema_module: ModuleType

    def __init__(self, path: str) -> None:
        self._path = path
        self._cache: dict[str, pd.DataFrame] = {}

    def _load(self, sheet: str) -> pd.DataFrame:
        if sheet not in self._cache:
            reader_fn = getattr(self._reader_module, f"read_{sheet}")
            self._cache[sheet] = reader_fn(self._path)
        return self._cache[sheet]

    def load(self) -> None:
        for sheet in self._SHEETS:
            self._load(sheet)

    def validate_all(self) -> ValidationResult:
        result = ValidationResult()
        for sheet in self._SHEETS:
            schema = getattr(self._schema_module, sheet, None)
            if schema is None:
                continue
            try:
                schema.validate(self._load(sheet))
            except SchemaError as e:
                result.add_error(sheet, str(e))
        return result

    def load_and_print_errors(self) -> None:
        result = self.validate_all()
        if result.ok:
            print("Validação OK — nenhum erro encontrado.")
        else:
            print("Erros de validação encontrados:")
            for sheet, messages in result.errors.items():
                print(f"\n  [{sheet}]")
                for msg in messages:
                    print(f"    - {msg}")
