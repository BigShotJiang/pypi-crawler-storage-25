import pandas as pd

from etl_ativa_investimentos import movimentacao_b3 as _reader
from etl_ativa_investimentos.schemas import movimentacao_b3 as _schemas
from etl_ativa_investimentos.readers.base import ExcelReader


class MovimentacaoB3(ExcelReader):
    _SHEETS = ["movimentacao"]
    _reader_module = _reader
    _schema_module = _schemas

    def movimentacao(self) -> pd.DataFrame:
        return self._load("movimentacao")
