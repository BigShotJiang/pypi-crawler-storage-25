import pandas as pd

from etl_ativa_investimentos import posicao_consolidada as _reader
from etl_ativa_investimentos.schemas import posicao_consolidada as _schemas
from etl_ativa_investimentos.readers.base import ExcelReader


class PosicaoConsolidada(ExcelReader):
    _SHEETS = [
        "acoes",
        "clubes_e_fundos",
        "financeiro",
        "renda_fixa_privada",
        "renda_fixa_publica",
    ]
    _reader_module = _reader
    _schema_module = _schemas

    def acoes(self) -> pd.DataFrame:
        return self._load("acoes")

    def clubes_e_fundos(self) -> pd.DataFrame:
        return self._load("clubes_e_fundos")

    def financeiro(self) -> pd.DataFrame:
        return self._load("financeiro")

    def renda_fixa_privada(self) -> pd.DataFrame:
        return self._load("renda_fixa_privada")

    def renda_fixa_publica(self) -> pd.DataFrame:
        return self._load("renda_fixa_publica")
