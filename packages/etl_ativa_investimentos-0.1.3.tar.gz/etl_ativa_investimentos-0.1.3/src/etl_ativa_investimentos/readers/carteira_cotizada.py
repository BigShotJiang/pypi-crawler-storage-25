from datetime import date
from pathlib import Path
import re

import pandas as pd

from etl_ativa_investimentos import carteira_cotizada as _reader
from etl_ativa_investimentos.schemas import carteira_cotizada as _schemas
from etl_ativa_investimentos.readers.base import ExcelReader


class CarteiraCotzada(ExcelReader):
    _SHEETS = [
        "variacao_patrimonial",
        "composicao_patrimonio",
        "carteira_analitica",
        "rentabilidade_carteira",
        "rentabilidade_no_ano",
        "rentabilidade_ultimos_meses",
        "rentabilidade_ativos",
        "provisoes",
        "renda_fixa_detalhada",
        "clubes_e_fundos_detalhados",
    ]
    _reader_module = _reader
    _schema_module = _schemas

    def infer_excel_date(self) -> date | None:
        filename = Path(self._path).name
        match = re.search(r"(\d{4})\.(\d{2})\.(\d{2})", filename)
        if match is None:
            return None
        year, month, day = map(int, match.groups())
        try:
            return date(year, month, day)
        except ValueError:
            return None

    def variacao_patrimonial(self) -> pd.DataFrame:
        return self._load("variacao_patrimonial")

    def composicao_patrimonio(self) -> pd.DataFrame:
        return self._load("composicao_patrimonio")

    def carteira_analitica(self) -> pd.DataFrame:
        return self._load("carteira_analitica")

    def rentabilidade_carteira(self) -> pd.DataFrame:
        return self._load("rentabilidade_carteira")

    def rentabilidade_no_ano(self) -> pd.DataFrame:
        return self._load("rentabilidade_no_ano")

    def rentabilidade_ultimos_meses(self) -> pd.DataFrame:
        return self._load("rentabilidade_ultimos_meses")

    def rentabilidade_ativos(self) -> pd.DataFrame:
        return self._load("rentabilidade_ativos")

    def provisoes(self) -> pd.DataFrame:
        return self._load("provisoes")

    def renda_fixa_detalhada(self) -> pd.DataFrame:
        return self._load("renda_fixa_detalhada")

    def clubes_e_fundos_detalhados(self) -> pd.DataFrame:
        return self._load("clubes_e_fundos_detalhados")
