import pandera.pandas as pa
from pandera.pandas import Column, DataFrameSchema

# "Preço unitário" e "Valor da Operação" são object porque podem conter
# traços ("-") para operações sem valor financeiro (ex: transferências).
movimentacao = DataFrameSchema(
    {
        "Entrada/Saída": Column(pa.String),
        "Data": Column(pa.String),
        "Movimentação": Column(pa.String),
        "Produto": Column(pa.String),
        "Instituição": Column(pa.String),
        "Quantidade": Column(pa.Float64),
        "Preço unitário": Column(pa.Object, nullable=True),
        "Valor da Operação": Column(pa.Object, nullable=True),
    }
)
