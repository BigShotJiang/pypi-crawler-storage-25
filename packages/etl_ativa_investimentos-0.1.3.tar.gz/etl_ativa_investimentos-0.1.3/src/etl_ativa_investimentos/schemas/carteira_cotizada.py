import pandera.pandas as pa
from pandera.pandas import Column, DataFrameSchema

variacao_patrimonial = DataFrameSchema(
    {
        "Patrimönio Bruto": Column(pa.Float64),
        "Patrimônio Liquido": Column(pa.Float64),
        "Variação %": Column(pa.Float64),
        "Data Início Controle": Column(pa.DateTime),
    }
)

composicao_patrimonio = DataFrameSchema(
    {
        "Descrição": Column(pa.String),
        "Valor Dia": Column(pa.Float64),
        "Provisão IR": Column(pa.Float64),
        "Provisão IOF": Column(pa.Int64),
        "Valor Liq Dia": Column(pa.Float64),
    }
)

carteira_analitica = DataFrameSchema(
    {
        "Mercado": Column(pa.String),
        "Ativo": Column(pa.String),
        "QTD": Column(pa.String),
        "PU Custo": Column(pa.Float64),
        "Fin. Custo": Column(pa.Float64),
        "PU Atual": Column(pa.Float64),
        "Fin. Mercado": Column(pa.Float64),
        "Rendimentos": Column(pa.Float64),
        "Fin. Total": Column(pa.Float64),
        "% Var": Column(pa.Float64),
        "L/P a Realizar": Column(pa.Float64),
        "Var.Dia": Column(pa.Float64),
        "% L/P": Column(pa.Float64),
        "% Carteira": Column(pa.Float64),
        "Realizado Mês": Column(pa.Float64),
        "DT Venc": Column(pa.DateTime, nullable=True),
    }
)

rentabilidade_carteira = DataFrameSchema(
    {
        "Descrição": Column(pa.String),
        "% Dia": Column(pa.Float64),
        "% Mês": Column(pa.Float64),
        "DT Mês": Column(pa.DateTime),
        "% 30 Dias": Column(pa.Float64),
        "DT 30 Dias": Column(pa.DateTime),
        "% no Ano": Column(pa.Float64),
        "DT Ano": Column(pa.DateTime),
        "%  12 Meses": Column(pa.Float64),
        "DT 12 Meses": Column(pa.DateTime),
        "% Inicio": Column(pa.Float64),
        "DT Inicio": Column(pa.DateTime),
    }
)

# Colunas mensais (Jan-Dez) são dinâmicas e validadas via regex
rentabilidade_no_ano = DataFrameSchema(
    {
        "Investimento": Column(pa.String),
        "Ano": Column(pa.Float64),
        r"^(Jan|Fev|Mar|Abr|Mai|Jun|Jul|Ago|Set|Out|Nov|Dez)$": Column(
            pa.Float64, required=False, regex=True, nullable=True
        ),
    }
)

# Colunas de meses no formato "YYYY/MM" são dinâmicas e validadas via regex
rentabilidade_ultimos_meses = DataFrameSchema(
    {
        "Investimento": Column(pa.String),
        "Ano": Column(pa.Float64),
        r"^\d{4}/\d{2}$": Column(
            pa.Float64, required=False, regex=True, nullable=True
        ),
    }
)

rentabilidade_ativos = DataFrameSchema(
    {
        "Ativo": Column(pa.String),
        "Mercado": Column(pa.String),
        "% Dia": Column(pa.Float64),
        "% Mes": Column(pa.Float64),
        "% 3 Meses": Column(pa.Float64),
        "% 6 Meses": Column(pa.Float64),
        "% Ano": Column(pa.Float64),
        "% 12 Meses": Column(pa.Float64),
        "% Desde Início": Column(pa.Float64),
        "Cota Atual": Column(pa.Float64),
        "Data Inicio": Column(pa.DateTime),
        "Cota Inicial": Column(pa.Int64),
    }
)

provisoes = DataFrameSchema(
    {
        "Data Provisão": Column(pa.DateTime),
        "Data Pagamento": Column(pa.DateTime),
        "Descrição": Column(pa.String),
        "Valor Anterior": Column(pa.Float64),
        "Variação Dia": Column(pa.Float64),
        "Valor Atual": Column(pa.Float64),
    }
)

renda_fixa_detalhada = DataFrameSchema(
    {
        "Mercado": Column(pa.String),
        "Título": Column(pa.String),
        "NM_ATV": Column(pa.String),
        "Qtd": Column(pa.Float64),
        "Pu Aquisição": Column(pa.Float64),
        "Pu Atual": Column(pa.Float64),
        "Valor Bruto": Column(pa.Float64),
        "Dt Venc": Column(pa.DateTime),
        "Emissor": Column(pa.String),
        "Dt Emissão": Column(pa.DateTime),
        "Correção": Column(pa.String),
        "Variação": Column(pa.Float64),
        "Pu Ant": Column(pa.Float64),
        "I.R": Column(pa.Float64),
        "IOF": Column(pa.Int64),
        "Valor Liquido": Column(pa.Float64),
        "A Realizar": Column(pa.Float64),
    }
)

clubes_e_fundos_detalhados = DataFrameSchema(
    {
        "Mercado": Column(pa.String),
        "Clube/Fundo": Column(pa.String),
        "Qtd Cotas": Column(pa.Float64),
        "Cota Aquisição": Column(pa.Float64),
        "Vl Investido": Column(pa.Float64),
        "Cota Ant": Column(pa.Float64),
        "Cota Atual": Column(pa.Float64),
        "Vl Bruto": Column(pa.Float64),
        "% L/P": Column(pa.Float64),
        "Var Dia": Column(pa.Int64),
        "I.R": Column(pa.Float64),
        "IOF": Column(pa.Int64),
        "Créd.Fiscal": Column(pa.Int64),
        "Vl Liquido": Column(pa.Float64),
        "Data da Cota": Column(pa.String),
    }
)
