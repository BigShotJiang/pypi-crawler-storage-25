import pandera.pandas as pa
from pandera.pandas import Column, DataFrameSchema

# Colunas "Unnamed:" são artefatos de células mescladas no Excel e ignoradas
# pelo schema (strict=False por padrão).

acoes = DataFrameSchema(
    {
        "Código": Column(pa.String, nullable=True),
        "Nome": Column(pa.String, nullable=True),
        "Carteira": Column(pa.String, nullable=True),
        "Quantidade": Column(pa.Object, nullable=True),
        "Preço": Column(pa.Float64, nullable=True),
        "Total": Column(pa.Float64, nullable=True),
    }
)

clubes_e_fundos = DataFrameSchema(
    {
        "Nome do fundo": Column(pa.String, nullable=True),
        "Data": Column(pa.Object, nullable=True),
        "Valor da Aplicação": Column(pa.Float64, nullable=True),
        "Quantidade": Column(pa.Float64, nullable=True),
        "Cota": Column(pa.Float64, nullable=True),
        "Valor": Column(pa.Object, nullable=True),
    }
)

financeiro = DataFrameSchema(
    {
        "Conta": Column(pa.Int64),
        "Tipo": Column(pa.String),
        "Disponível": Column(pa.Float64),
        "Projeto (D+1, D+2, D>2)": Column(pa.Int64),
        "Total": Column(pa.Float64),
    }
)

renda_fixa_privada = DataFrameSchema(
    {
        "Ticker": Column(pa.String, nullable=True),
        "Títulos": Column(pa.String, nullable=True),
        "Emissor": Column(pa.String, nullable=True),
        "Remuneração": Column(pa.String, nullable=True),
        "Data": Column(pa.Object, nullable=True),
        "PU de Compra": Column(pa.Float64, nullable=True),
        "PU de Referência": Column(pa.String, nullable=True),
        "PU atual": Column(pa.Float64, nullable=True),
        "Quantidade": Column(pa.Float64, nullable=True),
        "Total": Column(pa.Float64, nullable=True),
    }
)

renda_fixa_publica = DataFrameSchema(
    {
        "Título": Column(pa.String),
        "Emissor": Column(pa.String),
        "Indexador": Column(pa.String),
        "Remuneração": Column(pa.String),
        "Data Vencimento": Column(pa.DateTime),
        "PU de Referência": Column(pa.Object, nullable=True),
        "PU Atual": Column(pa.Float64),
        "Quantidade": Column(pa.Float64),
        "Total": Column(pa.Float64),
    }
)
