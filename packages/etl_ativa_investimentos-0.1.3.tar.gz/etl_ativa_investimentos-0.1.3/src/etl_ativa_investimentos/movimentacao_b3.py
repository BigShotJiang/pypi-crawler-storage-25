import pandas as pd

_ENGINE = "calamine"


def read_movimentacao(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="Movimentação", engine=_ENGINE)


def read_all(path: str) -> dict[str, pd.DataFrame]:
    """Lê todas as abas e retorna um dict {nome_aba: DataFrame}."""
    return {
        "movimentacao": read_movimentacao(path),
    }
