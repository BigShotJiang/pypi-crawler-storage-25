from dataclasses import dataclass, field


@dataclass
class ValidationResult:
    ok: bool = True
    errors: dict[str, list[str]] = field(default_factory=dict)

    def add_error(self, sheet: str, message: str) -> None:
        self.ok = False
        self.errors.setdefault(sheet, []).append(message)
