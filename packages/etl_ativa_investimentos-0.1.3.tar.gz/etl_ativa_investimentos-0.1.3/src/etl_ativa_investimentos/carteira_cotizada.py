import pandas as pd

_ENGINE = "calamine"


def read_variacao_patrimonial(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="1-Variação Patrimonial da Cart", engine=_ENGINE
    )


def read_composicao_patrimonio(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="2-Composição do Patrimônio da ", engine=_ENGINE
    )


def read_carteira_analitica(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="3-Carteira Analítica Consolida", engine=_ENGINE
    )


def read_rentabilidade_carteira(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="4-Rentabilidade da Carteira", engine=_ENGINE
    )


def read_rentabilidade_no_ano(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="5-Rentabilidade da Carteira no", engine=_ENGINE
    )


def read_rentabilidade_ultimos_meses(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="6-Rentabilidade da Carteira Úl", engine=_ENGINE
    )


def read_rentabilidade_ativos(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="7-Rentabilidade dos Ativos em ", engine=_ENGINE
    )


def read_provisoes(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="8-Provisões da Carteira", engine=_ENGINE
    )


def read_renda_fixa_detalhada(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="9-Carteira Detalhada Renda Fix", engine=_ENGINE
    )


def read_clubes_e_fundos_detalhados(path: str) -> pd.DataFrame:
    return pd.read_excel(
        path, sheet_name="10-Carteira Detalhada Clubes e", engine=_ENGINE
    )


def read_all(path: str) -> dict[str, pd.DataFrame]:
    """Lê todas as abas e retorna um dict {nome_aba: DataFrame}."""
    return {
        "variacao_patrimonial": read_variacao_patrimonial(path),
        "composicao_patrimonio": read_composicao_patrimonio(path),
        "carteira_analitica": read_carteira_analitica(path),
        "rentabilidade_carteira": read_rentabilidade_carteira(path),
        "rentabilidade_no_ano": read_rentabilidade_no_ano(path),
        "rentabilidade_ultimos_meses": read_rentabilidade_ultimos_meses(path),
        "rentabilidade_ativos": read_rentabilidade_ativos(path),
        "provisoes": read_provisoes(path),
        "renda_fixa_detalhada": read_renda_fixa_detalhada(path),
        "clubes_e_fundos_detalhados": read_clubes_e_fundos_detalhados(path),
    }
