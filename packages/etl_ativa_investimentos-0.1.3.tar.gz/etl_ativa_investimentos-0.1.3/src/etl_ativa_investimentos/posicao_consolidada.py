import pandas as pd


def read_acoes(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="Ações", engine="calamine")


def read_clubes_e_fundos(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="Clubes e Fundos", engine="calamine")


def read_financeiro(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="Financeiro", engine="calamine")


def read_renda_fixa_privada(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="Renda Fixa Privada", engine="calamine")


def read_renda_fixa_publica(path: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name="Renda Fixa Pública", engine="calamine")


def read_all(path: str) -> dict[str, pd.DataFrame]:
    """Lê todas as abas e retorna um dict {nome_aba: DataFrame}."""
    return {
        "acoes": read_acoes(path),
        "clubes_e_fundos": read_clubes_e_fundos(path),
        "financeiro": read_financeiro(path),
        "renda_fixa_privada": read_renda_fixa_privada(path),
        "renda_fixa_publica": read_renda_fixa_publica(path),
    }
