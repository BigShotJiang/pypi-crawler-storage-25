"""Tests for wizard subflow support.

Tests cover:
- SubflowContext dataclass creation and serialization
- WizardState subflow properties (is_in_subflow, subflow_depth)
- WizardFSM subflow registry methods
- Data mapping (parent -> subflow) and result mapping (subflow -> parent)
- TransitionRecord subflow fields
- Subflow state serialization/deserialization
- Integration: subflow push through finalize_turn (non-streaming)
- Integration: subflow push through stream_finalize_turn (streaming)
"""

import time
from typing import Any

import pytest

from dataknobs_bots.reasoning.observability import (
    TransitionRecord,
    create_transition_record,
)
from dataknobs_bots.reasoning.wizard import (
    SubflowContext,
    WizardReasoning,
    WizardState,
)
from dataknobs_bots.reasoning.wizard_subflows import (
    _apply_data_mapping,
    _apply_result_mapping,
)
from dataknobs_bots.testing import BotTestHarness, WizardConfigBuilder
from dataknobs_llm.testing import text_response


class TestSubflowContext:
    """Tests for SubflowContext dataclass."""

    def test_create_context(self) -> None:
        """Test creating a subflow context."""
        context = SubflowContext(
            parent_stage="configure_knowledge",
            parent_data={"domain_id": "test", "kb_type": "faq"},
            parent_history=["welcome", "configure_knowledge"],
            return_stage="configure_tools",
            result_mapping={"kb_config": "kb_config", "kb_resources": "kb_resources"},
            subflow_network="knowledge_base_acquisition",
        )

        assert context.parent_stage == "configure_knowledge"
        assert context.parent_data == {"domain_id": "test", "kb_type": "faq"}
        assert context.parent_history == ["welcome", "configure_knowledge"]
        assert context.return_stage == "configure_tools"
        assert context.result_mapping == {
            "kb_config": "kb_config",
            "kb_resources": "kb_resources",
        }
        assert context.subflow_network == "knowledge_base_acquisition"
        assert context.push_timestamp > 0

    def test_create_context_with_timestamp(self) -> None:
        """Test creating a subflow context with explicit timestamp."""
        timestamp = 1234567890.0
        context = SubflowContext(
            parent_stage="stage1",
            parent_data={},
            parent_history=["stage1"],
            return_stage="stage2",
            result_mapping={},
            subflow_network="subflow1",
            push_timestamp=timestamp,
        )

        assert context.push_timestamp == timestamp

    def test_to_dict(self) -> None:
        """Test converting context to dictionary."""
        timestamp = 1234567890.0
        context = SubflowContext(
            parent_stage="configure_knowledge",
            parent_data={"domain_id": "test"},
            parent_history=["welcome"],
            return_stage="configure_tools",
            result_mapping={"kb_config": "config"},
            subflow_network="kb_acquisition",
            push_timestamp=timestamp,
        )

        data = context.to_dict()

        assert data["parent_stage"] == "configure_knowledge"
        assert data["parent_data"] == {"domain_id": "test"}
        assert data["parent_history"] == ["welcome"]
        assert data["return_stage"] == "configure_tools"
        assert data["result_mapping"] == {"kb_config": "config"}
        assert data["subflow_network"] == "kb_acquisition"
        assert data["push_timestamp"] == timestamp

    def test_from_dict(self) -> None:
        """Test creating context from dictionary."""
        data = {
            "parent_stage": "stage_a",
            "parent_data": {"key": "value"},
            "parent_history": ["welcome", "stage_a"],
            "return_stage": "stage_b",
            "result_mapping": {"result": "output"},
            "subflow_network": "my_subflow",
            "push_timestamp": 9876543210.0,
        }

        context = SubflowContext.from_dict(data)

        assert context.parent_stage == "stage_a"
        assert context.parent_data == {"key": "value"}
        assert context.parent_history == ["welcome", "stage_a"]
        assert context.return_stage == "stage_b"
        assert context.result_mapping == {"result": "output"}
        assert context.subflow_network == "my_subflow"
        assert context.push_timestamp == 9876543210.0

    def test_from_dict_missing_optional_fields(self) -> None:
        """Test creating context from dict with missing optional fields."""
        data = {
            "parent_stage": "stage_a",
            "parent_data": {},
            "parent_history": [],
            "return_stage": "stage_b",
            "subflow_network": "my_subflow",
        }

        context = SubflowContext.from_dict(data)

        assert context.result_mapping == {}
        # push_timestamp defaults to current time
        assert context.push_timestamp > 0


class TestWizardStateSubflow:
    """Tests for WizardState subflow properties."""

    def test_is_in_subflow_false_when_empty(self) -> None:
        """Test is_in_subflow is False when subflow_stack is empty."""
        state = WizardState(
            current_stage="welcome",
            subflow_stack=[],
        )

        assert state.is_in_subflow is False

    def test_is_in_subflow_true_when_has_subflow(self) -> None:
        """Test is_in_subflow is True when subflow_stack has entries."""
        context = SubflowContext(
            parent_stage="stage1",
            parent_data={},
            parent_history=[],
            return_stage="stage2",
            result_mapping={},
            subflow_network="subflow1",
        )
        state = WizardState(
            current_stage="subflow_stage1",
            subflow_stack=[context],
        )

        assert state.is_in_subflow is True

    def test_subflow_depth_zero_when_empty(self) -> None:
        """Test subflow_depth is 0 when in main flow."""
        state = WizardState(
            current_stage="welcome",
            subflow_stack=[],
        )

        assert state.subflow_depth == 0

    def test_subflow_depth_one_when_in_subflow(self) -> None:
        """Test subflow_depth is 1 when in one subflow."""
        context = SubflowContext(
            parent_stage="stage1",
            parent_data={},
            parent_history=[],
            return_stage="stage2",
            result_mapping={},
            subflow_network="subflow1",
        )
        state = WizardState(
            current_stage="subflow_stage1",
            subflow_stack=[context],
        )

        assert state.subflow_depth == 1

    def test_subflow_depth_nested(self) -> None:
        """Test subflow_depth reflects nesting level."""
        context1 = SubflowContext(
            parent_stage="main_stage",
            parent_data={},
            parent_history=[],
            return_stage="main_return",
            result_mapping={},
            subflow_network="subflow1",
        )
        context2 = SubflowContext(
            parent_stage="subflow1_stage",
            parent_data={},
            parent_history=[],
            return_stage="subflow1_return",
            result_mapping={},
            subflow_network="nested_subflow",
        )
        state = WizardState(
            current_stage="nested_stage",
            subflow_stack=[context1, context2],
        )

        assert state.subflow_depth == 2

    def test_current_subflow_none_when_empty(self) -> None:
        """Test current_subflow is None in main flow."""
        state = WizardState(
            current_stage="welcome",
            subflow_stack=[],
        )

        assert state.current_subflow is None

    def test_current_subflow_returns_top_of_stack(self) -> None:
        """Test current_subflow returns most recent subflow context."""
        context1 = SubflowContext(
            parent_stage="main_stage",
            parent_data={},
            parent_history=[],
            return_stage="main_return",
            result_mapping={},
            subflow_network="subflow1",
        )
        context2 = SubflowContext(
            parent_stage="subflow1_stage",
            parent_data={},
            parent_history=[],
            return_stage="subflow1_return",
            result_mapping={},
            subflow_network="nested_subflow",
        )
        state = WizardState(
            current_stage="nested_stage",
            subflow_stack=[context1, context2],
        )

        assert state.current_subflow == context2
        assert state.current_subflow.subflow_network == "nested_subflow"


class TestTransitionRecordSubflowFields:
    """Tests for subflow fields in TransitionRecord."""

    def test_create_record_with_subflow_push(self) -> None:
        """Test creating a transition record for subflow push."""
        record = TransitionRecord(
            from_stage="configure_knowledge",
            to_stage="kb_welcome",
            timestamp=time.time(),
            trigger="subflow_push",
            subflow_push="knowledge_base_acquisition",
            subflow_depth=1,
        )

        assert record.subflow_push == "knowledge_base_acquisition"
        assert record.subflow_pop is None
        assert record.subflow_depth == 1

    def test_create_record_with_subflow_pop(self) -> None:
        """Test creating a transition record for subflow pop."""
        record = TransitionRecord(
            from_stage="kb_complete",
            to_stage="configure_tools",
            timestamp=time.time(),
            trigger="subflow_pop",
            subflow_pop="knowledge_base_acquisition",
            subflow_depth=0,
        )

        assert record.subflow_push is None
        assert record.subflow_pop == "knowledge_base_acquisition"
        assert record.subflow_depth == 0

    def test_create_record_default_subflow_fields(self) -> None:
        """Test that subflow fields default correctly."""
        record = TransitionRecord(
            from_stage="welcome",
            to_stage="configure",
            timestamp=time.time(),
            trigger="user_input",
        )

        assert record.subflow_push is None
        assert record.subflow_pop is None
        assert record.subflow_depth == 0

    def test_factory_with_subflow_fields(self) -> None:
        """Test create_transition_record factory with subflow fields."""
        record = create_transition_record(
            from_stage="stage1",
            to_stage="subflow_start",
            trigger="subflow_push",
            subflow_push="my_subflow",
            subflow_depth=1,
        )

        assert record.subflow_push == "my_subflow"
        assert record.subflow_depth == 1

    def test_to_dict_includes_subflow_fields(self) -> None:
        """Test that to_dict includes subflow fields."""
        record = TransitionRecord(
            from_stage="stage1",
            to_stage="subflow_start",
            timestamp=1234567890.0,
            trigger="subflow_push",
            subflow_push="my_subflow",
            subflow_pop=None,
            subflow_depth=1,
        )

        data = record.to_dict()

        assert data["subflow_push"] == "my_subflow"
        assert data["subflow_pop"] is None
        assert data["subflow_depth"] == 1

    def test_from_dict_restores_subflow_fields(self) -> None:
        """Test that from_dict restores subflow fields."""
        data = {
            "from_stage": "kb_complete",
            "to_stage": "configure_tools",
            "timestamp": 1234567890.0,
            "trigger": "subflow_pop",
            "duration_in_stage_ms": 0.0,
            "data_snapshot": None,
            "user_input": None,
            "condition_evaluated": None,
            "condition_result": None,
            "error": None,
            "subflow_push": None,
            "subflow_pop": "kb_acquisition",
            "subflow_depth": 0,
        }

        record = TransitionRecord.from_dict(data)

        assert record.subflow_push is None
        assert record.subflow_pop == "kb_acquisition"
        assert record.subflow_depth == 0


class TestSubflowStateSerialization:
    """Tests for subflow state serialization in WizardState."""

    def test_serialize_empty_subflow_stack(self) -> None:
        """Test that empty subflow_stack serializes correctly."""
        state = WizardState(
            current_stage="welcome",
            data={},
            history=["welcome"],
            subflow_stack=[],
        )

        # Simulate what _save_wizard_state does
        serialized_stack = [s.to_dict() for s in state.subflow_stack]

        assert serialized_stack == []

    def test_serialize_with_subflow(self) -> None:
        """Test that subflow_stack serializes correctly."""
        context = SubflowContext(
            parent_stage="configure_knowledge",
            parent_data={"domain_id": "test"},
            parent_history=["welcome", "configure_knowledge"],
            return_stage="configure_tools",
            result_mapping={"kb_config": "kb_config"},
            subflow_network="kb_acquisition",
            push_timestamp=1234567890.0,
        )
        state = WizardState(
            current_stage="kb_welcome",
            data={"kb_type": "faq"},
            history=["kb_welcome"],
            subflow_stack=[context],
        )

        serialized_stack = [s.to_dict() for s in state.subflow_stack]

        assert len(serialized_stack) == 1
        assert serialized_stack[0]["parent_stage"] == "configure_knowledge"
        assert serialized_stack[0]["subflow_network"] == "kb_acquisition"

    def test_deserialize_subflow_stack(self) -> None:
        """Test that subflow_stack deserializes correctly."""
        serialized_stack = [
            {
                "parent_stage": "configure_knowledge",
                "parent_data": {"domain_id": "test"},
                "parent_history": ["welcome", "configure_knowledge"],
                "return_stage": "configure_tools",
                "result_mapping": {"kb_config": "kb_config"},
                "subflow_network": "kb_acquisition",
                "push_timestamp": 1234567890.0,
            }
        ]

        restored_stack = [
            SubflowContext.from_dict(s) for s in serialized_stack
        ]

        assert len(restored_stack) == 1
        assert restored_stack[0].parent_stage == "configure_knowledge"
        assert restored_stack[0].subflow_network == "kb_acquisition"

    def test_serialize_nested_subflows(self) -> None:
        """Test serialization of nested subflows."""
        context1 = SubflowContext(
            parent_stage="main_stage",
            parent_data={"key1": "value1"},
            parent_history=["welcome", "main_stage"],
            return_stage="main_return",
            result_mapping={"r1": "o1"},
            subflow_network="subflow1",
            push_timestamp=1000.0,
        )
        context2 = SubflowContext(
            parent_stage="subflow1_stage",
            parent_data={"key2": "value2"},
            parent_history=["subflow1_welcome", "subflow1_stage"],
            return_stage="subflow1_return",
            result_mapping={"r2": "o2"},
            subflow_network="nested_subflow",
            push_timestamp=2000.0,
        )
        state = WizardState(
            current_stage="nested_current",
            subflow_stack=[context1, context2],
        )

        serialized = [s.to_dict() for s in state.subflow_stack]

        assert len(serialized) == 2
        assert serialized[0]["subflow_network"] == "subflow1"
        assert serialized[1]["subflow_network"] == "nested_subflow"

        # Restore and verify
        restored = [SubflowContext.from_dict(s) for s in serialized]
        assert restored[0].subflow_network == "subflow1"
        assert restored[1].subflow_network == "nested_subflow"
        assert restored[0].push_timestamp == 1000.0
        assert restored[1].push_timestamp == 2000.0


class TestDataMapping:
    """Tests for data mapping helper functions.

    These test the _apply_data_mapping and _apply_result_mapping
    logic used during subflow push/pop operations.
    """

    def test_apply_data_mapping_basic(self) -> None:
        """Test basic data mapping from parent to subflow."""
        source_data = {
            "domain_id": "my_domain",
            "kb_type": "faq",
            "other_field": "ignored",
        }
        mapping = {
            "domain_id": "domain",  # parent_field -> subflow_field
            "kb_type": "type",
        }

        result = _apply_data_mapping(source_data, mapping)

        assert result == {"domain": "my_domain", "type": "faq"}
        assert "other_field" not in result

    def test_apply_data_mapping_empty(self) -> None:
        """Test data mapping with empty mapping."""
        source_data = {"field1": "value1"}
        mapping: dict = {}

        result = _apply_data_mapping(source_data, mapping)

        assert result == {}

    def test_apply_data_mapping_missing_field(self) -> None:
        """Test data mapping when source field doesn't exist."""
        source_data = {"field1": "value1"}
        mapping = {"missing_field": "target"}

        result = _apply_data_mapping(source_data, mapping)

        assert result == {}

    def test_apply_result_mapping_basic(self) -> None:
        """Test basic result mapping from subflow to parent."""
        source_data = {
            "kb_config": {"sources": ["doc1", "doc2"]},
            "kb_resources": 5,
            "internal_field": "not_mapped",
        }
        mapping = {
            "kb_config": "knowledge_config",  # subflow_field -> parent_field
            "kb_resources": "resource_count",
        }

        result = _apply_result_mapping(source_data, mapping)

        assert result == {
            "knowledge_config": {"sources": ["doc1", "doc2"]},
            "resource_count": 5,
        }

    def test_apply_result_mapping_preserves_types(self) -> None:
        """Test that result mapping preserves complex types."""
        source_data = {
            "list_field": [1, 2, 3],
            "dict_field": {"nested": "value"},
            "none_field": None,
        }
        mapping = {
            "list_field": "output_list",
            "dict_field": "output_dict",
            "none_field": "output_none",
        }

        result = _apply_result_mapping(source_data, mapping)

        assert result["output_list"] == [1, 2, 3]
        assert result["output_dict"] == {"nested": "value"}
        assert result["output_none"] is None


class TestShouldPushSubflowGuard:
    """Tests for SubflowManager.should_push guard against duplicate pushes.

    This tests the fix for the subflow double-push bug where a subflow would
    be pushed twice when wizard state is restored after bot recreation
    (e.g., due to cache TTL expiration). The guard ensures we don't push
    a subflow if we're already in one.
    """

    @pytest.fixture
    def wizard_config_with_subflow(self) -> dict:
        """Create a wizard config with a subflow transition."""
        return {
            "name": "test-wizard-subflow",
            "version": "1.0",
            "stages": [
                {
                    "name": "welcome",
                    "is_start": True,
                    "prompt": "Welcome!",
                    "transitions": [{"target": "configure"}],
                },
                {
                    "name": "configure",
                    "prompt": "Configure the feature",
                    "schema": {
                        "type": "object",
                        "properties": {"enable_feature": {"type": "boolean"}},
                    },
                    "transitions": [
                        {
                            "target": "_subflow",
                            "condition": "data.get('enable_feature') == True",
                            "subflow": {
                                "network": "feature_setup",
                                "return_stage": "complete",
                                "data_mapping": {"domain": "domain"},
                                "result_mapping": {"result": "feature_result"},
                            },
                        },
                        {"target": "complete"},
                    ],
                },
                {
                    "name": "complete",
                    "is_end": True,
                    "prompt": "Done!",
                },
            ],
            "subflows": {
                "feature_setup": {
                    "stages": [
                        {
                            "name": "subflow_start",
                            "is_start": True,
                            "prompt": "Configure the feature details",
                            "transitions": [{"target": "subflow_complete"}],
                        },
                        {
                            "name": "subflow_complete",
                            "is_end": True,
                            "prompt": "Feature configured!",
                        },
                    ]
                }
            },
        }

    @pytest.fixture
    def wizard_with_subflow(
        self, wizard_config_with_subflow: dict
    ) -> "WizardReasoning":
        """Create a WizardReasoning instance with subflow support."""
        from dataknobs_bots.reasoning.wizard import WizardReasoning
        from dataknobs_bots.reasoning.wizard_loader import WizardConfigLoader

        loader = WizardConfigLoader()
        wizard_fsm = loader.load_from_dict(wizard_config_with_subflow)
        return WizardReasoning(wizard_fsm=wizard_fsm, strict_validation=False)

    def test_returns_none_when_already_in_subflow(
        self, wizard_with_subflow: "WizardReasoning"
    ) -> None:
        """Test that SubflowManager.should_push returns None when already in a subflow.

        This is the key guard that prevents duplicate subflow pushes after
        wizard state restoration (e.g., when bot is recreated due to cache
        TTL expiration).
        """
        # Create a wizard state that is already in a subflow
        subflow_context = SubflowContext(
            parent_stage="configure",
            parent_data={"enable_feature": True},
            parent_history=["welcome", "configure"],
            return_stage="complete",
            result_mapping={"result": "feature_result"},
            subflow_network="feature_setup",
        )
        wizard_state = WizardState(
            current_stage="subflow_start",
            data={"domain": "test"},
            history=["subflow_start"],
            subflow_stack=[subflow_context],  # Already in subflow!
        )

        # Verify the state thinks it's in a subflow
        assert wizard_state.is_in_subflow is True

        # The guard should return None - no new subflow should be pushed
        result = wizard_with_subflow._subflows.should_push(
            wizard_state, "user message"
        )

        assert result is None

    def test_returns_config_when_not_in_subflow_and_condition_matches(
        self, wizard_with_subflow: "WizardReasoning"
    ) -> None:
        """Test that SubflowManager.should_push returns config when conditions are met.

        When not already in a subflow and the condition matches, the method
        should return the subflow configuration.
        """
        # Create a wizard state at configure stage with matching condition
        wizard_state = WizardState(
            current_stage="configure",
            data={"enable_feature": True},  # Matches the subflow condition
            history=["welcome", "configure"],
            subflow_stack=[],  # Not in a subflow
        )

        # Set up the FSM to be at the configure stage via the public API
        wizard_with_subflow._fsm.restore(
            {"current_stage": "configure", "data": {}}
        )

        # Verify the state is not in a subflow
        assert wizard_state.is_in_subflow is False

        # Should return the subflow config since condition matches
        result = wizard_with_subflow._subflows.should_push(
            wizard_state, "user message"
        )

        assert result is not None
        assert result.get("network") == "feature_setup"
        assert result.get("return_stage") == "complete"

    def test_returns_none_when_condition_does_not_match(
        self, wizard_with_subflow: "WizardReasoning"
    ) -> None:
        """Test that SubflowManager.should_push returns None when condition fails.

        When the subflow transition condition doesn't match, the method
        should return None even if not in a subflow.
        """
        # Create a wizard state with condition that doesn't match
        wizard_state = WizardState(
            current_stage="configure",
            data={"enable_feature": False},  # Does NOT match subflow condition
            history=["welcome", "configure"],
            subflow_stack=[],
        )

        # Set up the FSM to be at the configure stage via the public API
        wizard_with_subflow._fsm.restore(
            {"current_stage": "configure", "data": {}}
        )

        # Verify the state is not in a subflow
        assert wizard_state.is_in_subflow is False

        # Should return None since condition doesn't match
        result = wizard_with_subflow._subflows.should_push(
            wizard_state, "user message"
        )

        assert result is None

    def test_guard_prevents_duplicate_push_after_state_restoration(
        self, wizard_with_subflow: "WizardReasoning"
    ) -> None:
        """Integration test: guard prevents double-push after bot recreation.

        This simulates the scenario from the bug:
        1. User enters subflow (wizard_state.is_in_subflow = True)
        2. Bot is recreated (e.g., cache TTL expires)
        3. State is restored from conversation metadata
        4. SubflowManager.should_push is called again with restored state
        5. Guard should prevent pushing the same subflow again
        """
        # Simulate restored state after bot recreation
        # The subflow stack was correctly restored
        subflow_context = SubflowContext(
            parent_stage="configure",
            parent_data={"enable_feature": True},
            parent_history=["welcome", "configure"],
            return_stage="complete",
            result_mapping={"result": "feature_result"},
            subflow_network="feature_setup",
            push_timestamp=1234567890.0,  # Previous push time
        )

        # Restored wizard state - note is_in_subflow should be True
        # because subflow_stack is not empty
        restored_state = WizardState(
            current_stage="subflow_start",
            data={"domain": "test", "enable_feature": True},
            history=["subflow_start"],
            subflow_stack=[subflow_context],
        )

        # Verify state was restored correctly
        assert restored_state.is_in_subflow is True
        assert restored_state.subflow_depth == 1
        assert restored_state.current_subflow is not None
        assert restored_state.current_subflow.subflow_network == "feature_setup"

        # Even if called again (e.g., on next message after bot recreation),
        # the guard should prevent a duplicate push
        result = wizard_with_subflow._subflows.should_push(
            restored_state, "continue working"
        )

        assert result is None, (
            "Guard failed: would have pushed duplicate subflow after "
            "state restoration"
        )


# =========================================================================
# Integration: subflow push through finalize_turn / stream_finalize_turn
# =========================================================================

def _build_subflow_wizard_config() -> dict[str, Any]:
    """Build wizard config with a subflow using WizardConfigBuilder."""
    return (
        WizardConfigBuilder("subflow-integration-test")
        .stage(
            "configure",
            is_start=True,
            prompt="Configure the feature. Say yes to enable it.",
            response_template="Please configure the feature.",
            confirm_first_render=False,
        )
            .field("enable_feature", field_type="boolean")
            .transition(
                "complete",
                condition="data.get('enable_feature') == True",
                subflow_network="feature_setup",
                result_mapping={"setup_done": "setup_done"},
            )
            .transition("complete")
        .stage("complete", is_end=True, prompt="All done!",
               response_template="Setup complete.")
        .subflow("feature_setup", {
            "stages": [
                {
                    "name": "detail_gather",
                    "is_start": True,
                    "prompt": "Enter feature details.",
                    "response_template": "Now entering feature setup.",
                    "confirm_first_render": False,
                    "transitions": [{"target": "subflow_done"}],
                },
                {
                    "name": "subflow_done",
                    "is_end": True,
                    "prompt": "Feature configured!",
                    "response_template": "Feature setup complete.",
                },
            ]
        })
        .build()
    )


class TestSubflowPushIntegration:
    """Integration tests for subflow push through finalize_turn.

    Verifies the non-streaming subflow push path: when a transition
    targets ``_subflow`` and the condition matches, the wizard pushes
    the subflow and returns the subflow's first stage response.
    """

    @pytest.mark.asyncio
    async def test_subflow_push_via_chat(self) -> None:
        """Non-streaming: extraction triggers subflow push, response is
        from subflow's start stage (finalize_turn path).
        """
        async with await BotTestHarness.create(
            wizard_config=_build_subflow_wizard_config(),
            main_responses=[
                text_response("Now entering feature setup."),
            ],
            extraction_results=[[{"enable_feature": True}]],
        ) as harness:
            # greet() renders the start stage template
            await harness.greet()
            # User message triggers extraction → subflow push
            result = await harness.chat("Yes, enable it")

        # The wizard should have pushed into the subflow
        assert harness.wizard_stage == "detail_gather"
        assert "feature setup" in result.response.lower()

    @pytest.mark.asyncio
    async def test_subflow_push_via_stream_chat(self) -> None:
        """Streaming: extraction triggers subflow push, streamed response
        is from subflow's start stage (stream_finalize_turn path).
        """
        async with await BotTestHarness.create(
            wizard_config=_build_subflow_wizard_config(),
            main_responses=[
                text_response("Now entering feature setup."),
            ],
            extraction_results=[[{"enable_feature": True}]],
        ) as harness:
            await harness.greet()
            result = await harness.stream_chat("Yes, enable it")

        # Same assertions as non-streaming
        assert harness.wizard_stage == "detail_gather"
        assert "feature setup" in result.response.lower()

    @pytest.mark.asyncio
    async def test_no_subflow_when_condition_not_met(self) -> None:
        """When the subflow condition is not met, the wizard transitions
        normally (to 'complete') and does not push a subflow.
        """
        async with await BotTestHarness.create(
            wizard_config=_build_subflow_wizard_config(),
            main_responses=[
                text_response("Setup complete."),
            ],
            extraction_results=[[{"enable_feature": False}]],
        ) as harness:
            await harness.greet()
            result = await harness.chat("No, skip it")

        assert harness.wizard_stage == "complete"
        assert "complete" in result.response.lower()


# =========================================================================
# dk-42: Subflow push must NOT increment render count
# =========================================================================


def _build_subflow_confirmation_config() -> dict[str, Any]:
    """Build wizard config for testing subflow push render_count semantics.

    The parent stage (``project_name``) uses ``confirm_first_render=False``
    so it transitions immediately on extraction.  The subflow's first
    stage (``team_lead``) uses the default ``confirm_first_render=True``
    so the confirmation path is exercised there.  If render_count is
    incorrectly set to 1 after the subflow push, confirmation on
    ``team_lead`` will be skipped.
    """
    return (
        WizardConfigBuilder("subflow-confirmation-test")
        .stage(
            "project_name",
            is_start=True,
            prompt="What is the project name?",
            response_template="Please enter the project name.",
            confirm_first_render=False,
        )
            .field("project_name", field_type="string", required=True)
            .transition(
                "done",
                condition="data.get('project_name')",
                subflow_network="team_details",
                result_mapping={"lead_name": "lead_name"},
            )
        .stage("done", is_end=True, prompt="All done!",
               response_template="Project setup complete.")
        .subflow("team_details", {
            "stages": [
                {
                    "name": "team_lead",
                    "is_start": True,
                    "prompt": "Who is the team lead?",
                    "response_template": "Who is the team lead?",
                    # confirm_first_render defaults to True —
                    # confirmation SHOULD fire after first extraction.
                    "schema": {
                        "type": "object",
                        "properties": {
                            "lead_name": {
                                "type": "string",
                                "description": "Team lead name",
                            },
                        },
                        "required": ["lead_name"],
                    },
                    "transitions": [{"target": "subflow_done"}],
                },
                {
                    "name": "subflow_done",
                    "is_end": True,
                    "prompt": "Team details captured.",
                    "response_template": "Team details complete.",
                },
            ],
        })
        .build()
    )


class TestSubflowPushRenderCount:
    """dk-42: Subflow push must not increment render count.

    When a subflow is pushed, the subflow's first stage template is
    displayed as a question. render_count should remain 0 so that the
    confirmation logic fires when the user responds with data. The bug
    (introduced in commit 7140c998) increments render_count to 1 during
    the push, causing confirmation to be silently skipped.
    """

    @pytest.mark.asyncio
    async def test_render_count_zero_after_subflow_push(self) -> None:
        """After subflow push, the subflow stage's render_count must be 0."""
        async with await BotTestHarness.create(
            wizard_config=_build_subflow_confirmation_config(),
            main_responses=[
                # Response for the subflow's first stage (team_lead)
                text_response("Who is the team lead?"),
            ],
            extraction_results=[
                # Turn 1: extract project_name → triggers subflow push
                [{"project_name": "Alpha Project"}],
            ],
        ) as harness:
            await harness.greet()
            # User provides project name → extraction → subflow push
            await harness.chat("Alpha Project")

            # The wizard should be in the subflow at team_lead
            assert harness.wizard_stage == "team_lead"

            # CRITICAL: render_count for team_lead must be 0.
            # The subflow's first stage template was displayed as a
            # question — the user hasn't responded yet.
            assert "_stage_render_counts" not in harness.wizard_data or \
                harness.wizard_data["_stage_render_counts"].get("team_lead", 0) == 0, (
                "render_count for team_lead should be 0 after subflow push, "
                f"got {harness.wizard_data.get('_stage_render_counts', {}).get('team_lead', 0)}"
            )

    @pytest.mark.asyncio
    async def test_confirmation_fires_after_subflow_push(self) -> None:
        """After subflow push, the user's data response must trigger
        confirmation — not skip straight to transition.
        """
        async with await BotTestHarness.create(
            wizard_config=_build_subflow_confirmation_config(),
            main_responses=[],
            extraction_results=[
                # Turn 1: project_name → subflow push
                [{"project_name": "Alpha Project"}],
                # Turn 2: lead_name extracted → auto-confirmation
                [{"lead_name": "Alice Johnson"}],
            ],
        ) as harness:
            await harness.greet()
            # Turn 1: project name → subflow push
            await harness.chat("Alpha Project")
            assert harness.wizard_stage == "team_lead"

            # Turn 2: user provides team lead name
            await harness.chat("Alice Johnson")

            # Confirmation should fire: wizard stays on team_lead
            # (not advance to subflow_done)
            assert harness.wizard_stage == "team_lead", (
                f"Expected wizard to stay on 'team_lead' for confirmation, "
                f"but it advanced to '{harness.wizard_stage}'"
            )

    @pytest.mark.asyncio
    async def test_confirmation_shows_extracted_data(self) -> None:
        """dk-43: Confirmation auto-generates summary from extracted data.

        When confirmation fires, the response must include the newly
        extracted data so the user can verify it — not re-render the
        question template.
        """
        async with await BotTestHarness.create(
            wizard_config=_build_subflow_confirmation_config(),
            main_responses=[],
            extraction_results=[
                [{"project_name": "Alpha Project"}],
                [{"lead_name": "Alice Johnson"}],
            ],
        ) as harness:
            await harness.greet()
            await harness.chat("Alpha Project")
            result = await harness.chat("Alice Johnson")

            # Auto-generated confirmation must include the extracted value
            assert "Alice Johnson" in result.response, (
                "Confirmation response should contain extracted lead name"
            )
            # Must include the schema description as label
            assert "Team lead name" in result.response, (
                "Confirmation response should use schema description as label"
            )
            # Must ask for verification
            assert "correct" in result.response.lower(), (
                "Confirmation response should ask user to verify"
            )

    @pytest.mark.asyncio
    async def test_confirmation_template_override(self) -> None:
        """dk-43: confirmation_template overrides auto-generation.

        Uses a subflow pattern (the natural render_count=0 scenario)
        with a confirmation_template on the subflow's first stage.
        """
        config = (
            WizardConfigBuilder("confirm-template-test")
            .stage(
                "project_name",
                is_start=True,
                prompt="What is the project name?",
                response_template="Enter the project name.",
                confirm_first_render=False,
            )
                .field("project_name", field_type="string", required=True)
                .transition(
                    "done",
                    condition="data.get('project_name')",
                    subflow_network="team_details",
                    result_mapping={"lead_name": "lead_name"},
                )
            .stage("done", is_end=True, prompt="Done.",
                   response_template="Complete.")
            .subflow("team_details", {
                "stages": [
                    {
                        "name": "team_lead",
                        "is_start": True,
                        "prompt": "Who is the team lead?",
                        "response_template": "Who is the team lead?",
                        "confirmation_template": (
                            "Lead: {{ lead_name }}. Correct?"
                        ),
                        "schema": {
                            "type": "object",
                            "properties": {
                                "lead_name": {
                                    "type": "string",
                                    "description": "Team lead name",
                                },
                            },
                            "required": ["lead_name"],
                        },
                        "transitions": [{"target": "subflow_done"}],
                    },
                    {
                        "name": "subflow_done",
                        "is_end": True,
                        "prompt": "Done.",
                        "response_template": "Team details complete.",
                    },
                ],
            })
            .build()
        )
        async with await BotTestHarness.create(
            wizard_config=config,
            main_responses=[],
            extraction_results=[
                [{"project_name": "Alpha"}],
                [{"lead_name": "Alice Johnson"}],
            ],
        ) as harness:
            await harness.greet()
            await harness.chat("Alpha")
            result = await harness.chat("Alice Johnson")

            assert result.response.strip() == "Lead: Alice Johnson. Correct?"
            assert harness.wizard_stage == "team_lead"

    @pytest.mark.asyncio
    async def test_auto_confirmation_multi_field(self) -> None:
        """dk-43: Auto-generated confirmation lists all newly extracted fields.

        Uses a subflow with a multi-field schema to verify the
        auto-generated confirmation includes all extracted fields
        with their schema descriptions.
        """
        config = (
            WizardConfigBuilder("multi-field-confirm")
            .stage(
                "start",
                is_start=True,
                prompt="Begin.",
                response_template="Starting.",
                confirm_first_render=False,
            )
                .field("trigger", field_type="string", required=True)
                .transition(
                    "done",
                    condition="data.get('trigger')",
                    subflow_network="details",
                    result_mapping={
                        "name": "name", "age": "age",
                    },
                )
            .stage("done", is_end=True, prompt="Done.",
                   response_template="Complete.")
            .subflow("details", {
                "stages": [
                    {
                        "name": "gather",
                        "is_start": True,
                        "prompt": "Enter details.",
                        "response_template": "Name and age?",
                        "schema": {
                            "type": "object",
                            "properties": {
                                "name": {
                                    "type": "string",
                                    "description": "Full name",
                                },
                                "age": {
                                    "type": "integer",
                                    "description": "Age in years",
                                },
                            },
                            "required": ["name", "age"],
                        },
                        "transitions": [{"target": "sub_done"}],
                    },
                    {
                        "name": "sub_done",
                        "is_end": True,
                        "prompt": "Done.",
                        "response_template": "Details complete.",
                    },
                ],
            })
            .build()
        )
        async with await BotTestHarness.create(
            wizard_config=config,
            main_responses=[],
            extraction_results=[
                [{"trigger": "go"}],
                [{"name": "Carol", "age": 30}],
            ],
        ) as harness:
            await harness.greet()
            await harness.chat("go")
            result = await harness.chat("Carol, 30")

            # Both fields should appear in auto-generated confirmation
            assert "Carol" in result.response
            assert "30" in str(result.response)
            assert "Full name" in result.response
            assert "Age in years" in result.response

    @pytest.mark.asyncio
    async def test_render_count_zero_after_subflow_push_streaming(
        self,
    ) -> None:
        """Streaming path: same render_count=0 assertion after subflow push."""
        async with await BotTestHarness.create(
            wizard_config=_build_subflow_confirmation_config(),
            main_responses=[
                text_response("Who is the team lead?"),
            ],
            extraction_results=[
                [{"project_name": "Alpha Project"}],
            ],
        ) as harness:
            await harness.greet()
            await harness.stream_chat("Alpha Project")

            assert harness.wizard_stage == "team_lead"

            assert "_stage_render_counts" not in harness.wizard_data or \
                harness.wizard_data["_stage_render_counts"].get("team_lead", 0) == 0, (
                "render_count for team_lead should be 0 after subflow push "
                f"(streaming), got {harness.wizard_data.get('_stage_render_counts', {}).get('team_lead', 0)}"
            )
