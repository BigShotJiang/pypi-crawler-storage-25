"""Pydantic adapters for common scientific libraries

Adapters in the root of this package are for Python standard library types ONLY.

The current supported types from the standard library (above and beyond what
`pydantic` already supports) are:

- `Ellipsis` - [EllipsisAdapter][scientific_pydantic.EllipsisAdapter]
- `range` - [RangeAdapter][scientific_pydantic.RangeAdapter]
- `slice` - [SliceAdapter][scientific_pydantic.SliceAdapter]

Subpackages shall follow the structure of their library and exist at the same
path as the type they are adapting. For instance, the adapter
`astropy.units.UnitBase` lives in `scientific_pydantic.astropy.units`.
"""

from importlib.metadata import PackageNotFoundError, version

from . import astropy, numpy, pyproj, scipy, shapely
from .ellipsis import EllipsisAdapter, EllipsisLiteral
from .range import RangeAdapter
from .schema import Encoding
from .slice import IntSliceAdapter, SliceAdapter

__all__ = [
    "EllipsisAdapter",
    "EllipsisLiteral",
    "Encoding",
    "IntSliceAdapter",
    "RangeAdapter",
    "SliceAdapter",
    "astropy",
    "numpy",
    "pyproj",
    "scipy",
    "shapely",
]

try:
    __version__ = version("scientific_pydantic")
except PackageNotFoundError:
    __version__ = "unknown"
