from ..models import (
    IssueTokenRequest,
    IssueTokenResponse,
    ServiceCreating,
    ServiceDeleting,
    ServiceDetail,
    ServiceReading,
    ServiceSummary,
    ServiceUpdating,
)
from .base import ModelClient


class Service(
    ModelClient[
        ServiceCreating,
        ServiceReading,
        ServiceUpdating,
        ServiceDeleting,
        ServiceSummary,
        ServiceDetail,
    ]
):
    Creating = ServiceCreating
    Reading = ServiceReading
    Updating = ServiceUpdating
    Deleting = ServiceDeleting
    Summary = ServiceSummary
    Detail = ServiceDetail

    def issue_token(self, *, id) -> IssueTokenResponse:
        """Mint a 90-day JWT scoped to the given service.

        The token is what a CLI / IDE pastes into the
        ``Authorization: Bearer <token>`` header when calling the
        service's public Ingress; the broker's ForwardAuth endpoint
        validates the binding between the token's ``service_id`` claim
        and the service in the URL.
        """
        body = IssueTokenRequest(id=id)
        resp = self.request(
            "POST",
            endpoint="issue-token",
            data=body,
            return_model=IssueTokenResponse,
        )
        assert isinstance(resp, IssueTokenResponse)
        return resp

    async def issue_token_async(self, *, id) -> IssueTokenResponse:
        body = IssueTokenRequest(id=id)
        resp = await self.request_async(
            "POST",
            endpoint="issue-token",
            data=body,
            return_model=IssueTokenResponse,
        )
        assert isinstance(resp, IssueTokenResponse)
        return resp
