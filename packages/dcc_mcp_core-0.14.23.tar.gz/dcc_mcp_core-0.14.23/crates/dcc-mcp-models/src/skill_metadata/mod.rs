//! SkillMetadata — parsed from SKILL.md frontmatter.
//!
//! Supports three skill standards simultaneously:
//!
//! - **agentskills.io / Anthropic Skills**: `name`, `description`, `license`,
//!   `compatibility`, `metadata`, `allowed-tools`
//! - **ClawHub / OpenClaw**: `version`, `metadata.openclaw.*` (requires, install,
//!   primaryEnv, emoji, homepage, os, always, skillKey)
//! - **dcc-mcp-core extensions**: `dcc`, `tags`, `tools`, `depends`, `scripts`
//!
//! The same SKILL.md file can satisfy all three formats simultaneously.

#[cfg(feature = "stub-gen")]
use pyo3_stub_gen_derive::gen_stub_pyclass;

use dcc_mcp_naming::{DEFAULT_DCC, DEFAULT_VERSION};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

mod methods;
mod serde_impl;

use serde_impl::{
    default_dcc, default_version, deserialize_allowed_tools, deserialize_tool_declarations,
};

// ── SkillMetadata ─────────────────────────────────────────────────────────

/// Metadata parsed from a SKILL.md frontmatter.
///
/// Supports all three skill standards:
///
/// ## Minimal (agentskills.io compatible)
/// ```yaml
/// ---
/// name: my-skill
/// description: What it does and when to use it.
/// ---
/// ```
///
/// ## Full (all standards)
/// ```yaml
/// ---
/// name: maya-bevel
/// description: Bevel tools for Maya polygon modeling.
/// # agentskills.io standard
/// license: MIT
/// compatibility: Maya 2022+, Python 3.7+
/// allowed-tools: Bash Read
/// metadata:
///   author: studio-name
///   category: modeling
/// # ClawHub / OpenClaw
/// version: "1.0.0"
/// metadata:
///   openclaw:
///     requires:
///       bins: [maya]
///     emoji: "🎨"
///     homepage: https://example.com
/// # dcc-mcp-core extensions
/// dcc: maya
/// tags: [modeling, polygon]
/// tools:
///   - name: bevel
///     description: Apply bevel to selected edges
/// ---
/// ```
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[cfg_attr(feature = "stub-gen", gen_stub_pyclass)]
#[cfg_attr(
    feature = "python-bindings",
    pyo3::pyclass(name = "SkillMetadata", from_py_object)
)]
// `#[derive(PyWrapper)]` (#528 M3.3) emits the trivial String / Vec<T>
// getters and setters as a sibling `#[pymethods]` block. Custom logic
// (`metadata` JSON round-trip, `policy` / `external_deps` serde, the
// curated `__repr__`, plus every `py_*` method) stays hand-written in
// `crate::python::skill_metadata`. The attribute is gated on
// `python-bindings` because the macro and its `py_wrapper(...)` inert
// attribute live in `dcc-mcp-pybridge-derive`, which is itself only
// linked under that feature.
#[cfg_attr(
    feature = "python-bindings",
    derive(dcc_mcp_pybridge::derive::PyWrapper)
)]
#[cfg_attr(
    feature = "python-bindings",
    py_wrapper(fields(
        name: String => [get(by_str), set],
        description: String => [get(by_str), set],
        license: String => [get(by_str), set],
        compatibility: String => [get(by_str), set],
        allowed_tools: Vec<String> => [get(clone), set],
        dcc: String => [get(by_str), set],
        tags: Vec<String> => [get(clone), set],
        search_hint: String => [get(by_str), set],
        scripts: Vec<String> => [get(clone), set],
        skill_path: String => [get(by_str), set],
        version: String => [get(by_str), set],
        depends: Vec<String> => [get(clone), set],
        metadata_files: Vec<String> => [get(clone), set],
        tools: Vec<crate::skill_metadata::ToolDeclaration> => [get(clone), set],
        groups: Vec<crate::skill_metadata::SkillGroup> => [get(clone), set],
        legacy_extension_fields: Vec<String> => [get(clone)],
        layer: Option<String> => [get(clone), set],
    ))
)]
pub struct SkillMetadata {
    /// Skill identifier — lowercase, hyphens only.
    /// Must match the parent directory name (agentskills.io requirement).
    pub name: String,

    /// Human-readable description of what the skill does and when to use it.
    /// Shown in skill discovery results. Keep under 1024 chars.
    #[serde(default)]
    pub description: String,

    // ── agentskills.io / Anthropic Skills standard fields ─────────────
    /// SPDX license identifier or short license description.
    /// Example: `"MIT"`, `"Apache-2.0"`, `"Proprietary"`
    #[serde(default)]
    pub license: String,

    /// Environment and dependency requirements for this skill.
    /// Example: `"Python 3.7+, Maya 2022+"`, `"Requires docker and git"`
    /// Keep under 500 chars.
    #[serde(default)]
    pub compatibility: String,

    /// Pre-approved tools this skill may use (agentskills.io `allowed-tools`).
    /// Space-delimited in SKILL.md YAML, stored as Vec<String> here.
    ///
    /// This is distinct from `tools` (MCP tool declarations):
    /// - `allowed-tools`: permission whitelist for agent capabilities (e.g. `["Bash", "Read"]`)
    /// - `tools`: MCP tool definitions with schemas
    ///
    /// Supports both space-delimited strings and YAML lists:
    /// ```yaml
    /// allowed-tools: Bash Read Write
    /// # or:
    /// allowed-tools: [Bash, Read, Write]
    /// ```
    #[serde(
        default,
        rename = "allowed-tools",
        alias = "allowed_tools",
        deserialize_with = "deserialize_allowed_tools"
    )]
    pub allowed_tools: Vec<String>,

    /// Arbitrary metadata key-value pairs.
    ///
    /// Used by both agentskills.io (flat KV strings) and ClawHub (`openclaw.*`
    /// nested structure). Stored as a JSON value to support both:
    ///
    /// ```yaml
    /// # agentskills.io flat style
    /// metadata:
    ///   author: studio-name
    ///   category: modeling
    ///
    /// # ClawHub nested style
    /// metadata:
    ///   openclaw:
    ///     requires:
    ///       bins: [ffmpeg]
    ///     emoji: "🎬"
    /// ```
    #[serde(default, skip_serializing_if = "serde_json::Value::is_null")]
    pub metadata: serde_json::Value,

    // ── dcc-mcp-core extension fields ─────────────────────────────────
    /// Target DCC application (e.g. "maya", "blender", "houdini", "python").
    #[serde(default = "default_dcc")]
    pub dcc: String,

    /// Searchable tags for skill discovery.
    #[serde(default)]
    pub tags: Vec<String>,

    /// Short search hint for lightweight skill discovery.
    ///
    /// Used by `search_skills` to match against without loading full tool schemas.
    /// Should be a comma-separated list of keywords or a short phrase, e.g.:
    /// `"polygon modeling, bevel, extrude, mesh editing"`
    ///
    /// Falls back to `description` if not set.
    #[serde(default, rename = "search-hint", alias = "search_hint")]
    pub search_hint: String,

    /// MCP tool declarations — defines the tools this skill exposes.
    ///
    /// Accepts both simple names and full declarations:
    /// ```yaml
    /// tools: ["bevel", "extrude"]
    /// # or with full schema:
    /// tools:
    ///   - name: bevel
    ///     description: Apply bevel to edges
    ///     source_file: scripts/bevel.py
    /// ```
    #[serde(default, deserialize_with = "deserialize_tool_declarations")]
    pub tools: Vec<ToolDeclaration>,

    /// Semantic version string.
    #[serde(default = "default_version")]
    pub version: String,

    /// Skill dependencies — names of other skills this skill requires.
    #[serde(default)]
    pub depends: Vec<String>,

    // ── Runtime-populated fields (not in YAML) ─────────────────────────
    /// Script files discovered in the `scripts/` subdirectory.
    /// Populated at load time, not from SKILL.md frontmatter.
    #[serde(default)]
    pub scripts: Vec<String>,

    /// Absolute path to the skill's root directory.
    /// Populated at load time.
    #[serde(default)]
    pub skill_path: String,

    /// Markdown files discovered in the `metadata/` subdirectory.
    /// Populated at load time.
    #[serde(default)]
    pub metadata_files: Vec<String>,

    // ── dcc-mcp-core: progressive discovery extensions ─────────────────
    /// Invocation policy declared in SKILL.md frontmatter.
    ///
    /// Controls whether the skill may be loaded implicitly and which
    /// DCC products it is available for.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub policy: Option<SkillPolicy>,

    /// External dependencies declared in SKILL.md frontmatter.
    ///
    /// Declares required MCP servers, environment variables, or binaries
    /// that must be available for this skill to function correctly.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub external_deps: Option<SkillDependencies>,

    /// Declared tool groups for progressive exposure (see [`SkillGroup`]).
    ///
    /// When a tool declares a group name that is not present in this list,
    /// the catalog auto-inserts an inactive placeholder group at load time.
    #[serde(default)]
    pub groups: Vec<SkillGroup>,

    /// Names of legacy top-level extension fields detected while parsing
    /// this skill's SKILL.md (issue #356).
    ///
    /// Populated by the loader, not by serde. When empty the skill uses the
    /// agentskills.io-compliant `metadata.dcc-mcp.*` form exclusively; when
    /// non-empty the skill still relies on deprecated top-level extension
    /// keys. See [`SkillMetadata::is_spec_compliant`].
    #[serde(default, skip_serializing, skip_deserializing)]
    pub legacy_extension_fields: Vec<String>,

    /// Sibling-file reference for the MCP prompts primitive (issues #351, #355).
    ///
    /// Set from `metadata.dcc-mcp.prompts` in SKILL.md frontmatter. The value
    /// is a path relative to the skill root — either a single YAML file that
    /// contains a top-level `prompts:` (and optional `workflows:`) list, or a
    /// glob (`prompts/*.prompt.yaml`) that enumerates one file per prompt.
    ///
    /// Parsing is deferred until the MCP server handles a `prompts/list` or
    /// `prompts/get` call, so a skill with 50 prompt files pays zero cost at
    /// scan / load time.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prompts_file: Option<String>,

    /// Architectural layer for skill routing and search partitioning.
    ///
    /// Set from `metadata.dcc-mcp.layer` in SKILL.md frontmatter. Valid values:
    ///
    /// - `"infrastructure"` — low-level mechanism skill (diagnostics, scripting,
    ///   scene I/O). Not intended as the final answer to user intent; use when
    ///   the domain skill's `on-failure` chain calls it.
    /// - `"domain"` — intent-oriented skill mapping user workflows to DCC calls
    ///   (geometry, animation, lighting, rendering). This is the primary entry
    ///   point for AI agents.
    /// - `"example"` — authoring reference or tutorial skill; not for production.
    ///
    /// Unset (`None`) is allowed for backward compatibility; tools that need to
    /// filter by layer treat `None` as "any layer".
    ///
    /// See `skills/README.md#skill-layering` and `AGENTS.md` for the layering
    /// rules that govern description prefixes and `search-hint` partitioning.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub layer: Option<String>,

    /// Sibling-file reference for skill recipes (issue #466).
    ///
    /// Set from `metadata.dcc-mcp.recipes` in SKILL.md frontmatter. The value
    /// is a path relative to the skill root pointing to a TOML or YAML file
    /// that declares pre-composed parameter templates for common workflows.
    ///
    /// Parsing is deferred; the path is stored here so callers can load it
    /// lazily on demand.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub recipes_file: Option<String>,

    /// Sibling-file reference for skill introspection metadata (issue #466).
    ///
    /// Set from `metadata.dcc-mcp.introspection` in SKILL.md frontmatter.
    /// The value is a path relative to the skill root pointing to a YAML file
    /// that describes capability probes, version checks, or runtime-discovery
    /// hooks used by agents to verify skill compatibility before invocation.
    ///
    /// Parsing is deferred; the path is stored here so callers can load it
    /// lazily on demand.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub introspection_file: Option<String>,
}

mod execution;
mod skill_dependency;
mod skill_policy;
mod tests;
mod tool_declaration;

pub use execution::*;
pub use skill_dependency::*;
pub use skill_policy::*;
pub use tool_declaration::*;
