from typing import Protocol, runtime_checkable, Iterable

from flask_socketio import SocketIO

from bussdcc import ContextProtocol, Event, Message

from .base import FlaskApp


@runtime_checkable
class WebPlugin(Protocol):
    name: str

    def init_app(self, app: FlaskApp, ctx: ContextProtocol) -> None: ...

    def event_types(self) -> Iterable[type[Message]]: ...

    def handle_event(
        self,
        app: FlaskApp,
        socketio: SocketIO,
        ctx: ContextProtocol,
        evt: Event[Message],
    ) -> None: ...
