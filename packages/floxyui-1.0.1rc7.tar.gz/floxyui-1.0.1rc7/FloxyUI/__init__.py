"""FloxyUI Package - runs a minimal Flask OLED black loading page server."""

__version__ = '1.0.1rc7'
__author__ = 'floxxy0'

from flask import Flask, request, jsonify, redirect
import os
import json

_app = Flask(__name__)

_html = f"""<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FloxyUI</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            background: #050505;
            color: #ffffff;
            font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', 'JetBrains Mono', monospace;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
        }}

        .grid {{
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(16, 163, 127, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(16, 163, 127, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
        }}

        .glow {{
            position: fixed;
            width: 500px;
            height: 500px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(16, 163, 127, 0.06) 0%, transparent 70%);
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 0;
            animation: pulseGlow 4s ease-in-out infinite;
        }}

        @keyframes pulseGlow {{
            0%, 100% {{ opacity: 0.5; transform: translate(-50%, -50%) scale(1); }}
            50% {{ opacity: 1; transform: translate(-50%, -50%) scale(1.3); }}
        }}

        .container {{
            position: relative;
            z-index: 1;
            text-align: center;
            user-select: none;
        }}

        .loader {{
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 16px;
            margin-bottom: 36px;
        }}

        .dot {{
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #10a37f;
            animation: bounce 1.4s infinite ease-in-out both;
            box-shadow: 0 0 15px rgba(16, 163, 127, 0.4);
        }}

        .dot:nth-child(1) {{ animation-delay: -0.32s; }}
        .dot:nth-child(2) {{ animation-delay: -0.16s; }}
        .dot:nth-child(3) {{ animation-delay: 0s; }}

        @keyframes bounce {{
            0%, 80%, 100% {{
                transform: scale(0.4) translateY(0);
                opacity: 0.3;
                box-shadow: 0 0 0 0 rgba(16, 163, 127, 0);
            }}
            40% {{
                transform: scale(1.2) translateY(-24px);
                opacity: 1;
                box-shadow: 0 0 30px rgba(16, 163, 127, 0.6);
            }}
        }}

        .loading-text {{
            font-size: 0.85rem;
            font-weight: 400;
            letter-spacing: 6px;
            text-transform: uppercase;
            margin-bottom: 12px;
            opacity: 0.7;
            color: #888;
        }}

        .loading-text span {{
            animation: flicker 2s infinite;
        }}

        @keyframes flicker {{
            0%, 100% {{ opacity: 0.7; }}
            50% {{ opacity: 1; }}
        }}

        .version-text {{
            font-size: 0.65rem;
            color: #333;
            letter-spacing: 2px;
        }}

        .cursor {{
            display: inline-block;
            width: 2px;
            height: 1em;
            background: #10a37f;
            margin-left: 4px;
            animation: blink 1s step-end infinite;
            vertical-align: text-bottom;
        }}

        @keyframes blink {{
            50% {{ opacity: 0; }}
        }}

        .line {{
            font-size: 0.75rem;
            color: #444;
            margin-bottom: 32px;
            letter-spacing: 2px;
        }}

        .line span {{
            color: #10a37f;
        }}
    </style>
</head>
<body>
    <div class="grid"></div>
    <div class="glow"></div>
    <div class="container">
        <div class="loader">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>
        <div class="line"><span>$</span> system<span class="cursor"></span></div>
        <div class="loading-text"><span>Loading</span></div>
        <div class="version-text">v{__version__}</div>
    </div>
</body>
</html>"""

_onboarding_html = """<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup - FloxyUI</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            background: #050505;
            color: #ffffff;
            font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', 'JetBrains Mono', monospace;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
            position: relative;
        }}

        .grid {{
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(16, 163, 127, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(16, 163, 127, 0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
        }}

        .glow {{
            position: fixed;
            width: 600px;
            height: 600px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(16, 163, 127, 0.07) 0%, transparent 70%);
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 0;
            animation: pulseGlow 4s ease-in-out infinite;
        }}

        @keyframes pulseGlow {{
            0%, 100% {{ opacity: 0.5; transform: translate(-50%, -50%) scale(1); }}
            50% {{ opacity: 1; transform: translate(-50%, -50%) scale(1.2); }}
        }}

        .container {{
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 400px;
            padding: 48px 40px;
        }}

        .card {{
            background: rgba(10, 10, 10, 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(16, 163, 127, 0.1);
            border-radius: 16px;
            padding: 40px 36px;
            box-shadow: 0 0 40px rgba(16, 163, 127, 0.03);
            animation: cardIn 0.8s ease-out;
        }}

        @keyframes cardIn {{
            from {{
                opacity: 0;
                transform: scale(0.95) translateY(10px);
            }}
            to {{
                opacity: 1;
                transform: scale(1) translateY(0);
            }}
        }}

        .terminal-line {{
            font-size: 0.75rem;
            color: #444444;
            margin-bottom: 32px;
            letter-spacing: 2px;
            display: block;
        }}

        .terminal-line span {{
            color: #10a37f !important;
            font-weight: 600;
        }}

        @keyframes fadeIn {{
            to {{ opacity: 1; }}
        }}

        h1 {{
            font-size: 1.1rem;
            font-weight: 400;
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-bottom: 8px;
            opacity: 0;
            animation: fadeIn 0.6s ease-out 0.2s forwards;
        }}

        .subtitle {{
            font-size: 0.7rem;
            color: #555;
            letter-spacing: 2px;
            margin-bottom: 36px;
            opacity: 0;
            animation: fadeIn 0.6s ease-out 0.3s forwards;
        }}

        .form-group {{
            margin-bottom: 22px;
            opacity: 0;
            animation: slideUp 0.6s ease-out forwards;
        }}

        .form-group:nth-child(1) {{ animation-delay: 0.3s; }}
        .form-group:nth-child(2) {{ animation-delay: 0.4s; }}
        .form-group:nth-child(3) {{ animation-delay: 0.5s; }}

        @keyframes slideUp {{
            from {{
                opacity: 0;
                transform: translateY(16px);
            }}
            to {{
                opacity: 1;
                transform: translateY(0);
            }}
        }}

        label {{
            display: block;
            font-size: 0.6rem;
            text-transform: uppercase;
            letter-spacing: 3px;
            color: #555;
            margin-bottom: 8px;
        }}

        .input-wrap {{
            position: relative;
        }}

        .input-wrap::before {{
            content: '>';
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #10a37f;
            font-size: 0.85rem;
            opacity: 0.5;
            z-index: 1;
        }}

        input {{
            width: 100%;
            padding: 14px 16px 14px 32px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 10px;
            color: #fff;
            font-family: inherit;
            font-size: 0.85rem;
            outline: none;
            transition: all 0.3s ease;
        }}

        input:focus {{
            border-color: rgba(16, 163, 127, 0.4);
            background: rgba(16, 163, 127, 0.04);
            box-shadow: 0 0 0 4px rgba(16, 163, 127, 0.06), 0 0 30px rgba(16, 163, 127, 0.05);
        }}

        input::placeholder {{
            color: #333;
            font-size: 0.75rem;
        }}

        button {{
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #10a37f, #0d8a6a);
            border: none;
            border-radius: 10px;
            color: #fff;
            font-family: inherit;
            font-size: 0.75rem;
            font-weight: 500;
            letter-spacing: 4px;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 28px;
            opacity: 0;
            animation: slideUp 0.6s ease-out 0.6s forwards;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }}

        button::after {{
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, transparent, rgba(255,255,255,0.1), transparent);
            transform: translateX(-100%);
            transition: transform 0.6s ease;
        }}

        button:hover::after {{
            transform: translateX(100%);
        }}

        button:hover {{
            transform: translateY(-2px);
            box-shadow: 0 12px 40px rgba(16, 163, 127, 0.3);
        }}

        button:active {{
            transform: translateY(0);
        }}
    </style>
</head>
<body>
    <div class="grid"></div>
    <div class="glow"></div>
    <div class="container">
        <div class="card">
            <div class="terminal-line" style="color: #555555; font-size: 12px; letter-spacing: 2px;"><span style="color: #10a37f;">$</span> setup --init</div>
            <h1>Welcome</h1>
            <div class="subtitle">create your account</div>
            <form id="setupForm">
                <div class="form-group">
                    <label>Username</label>
                    <div class="input-wrap">
                        <input type="text" name="username" required placeholder="enter username">
                    </div>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <div class="input-wrap">
                        <input type="password" name="password" required placeholder="enter password">
                    </div>
                </div>
                <div class="form-group">
                    <label>E-Mail</label>
                    <div class="input-wrap">
                        <input type="email" name="email" required placeholder="enter email">
                    </div>
                </div>
                <button type="submit">Continue</button>
            </form>
        </div>
    </div>
    <script>
        document.getElementById('setupForm').addEventListener('submit', async (e) => {{
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            const res = await fetch('/api/register', {{
                method: 'POST',
                headers: {{'Content-Type': 'application/json'}},
                body: JSON.stringify(data)
            }});
            
            if (res.ok) {{
                window.location.href = '/';
            }}
        }});
    </script>
</body>
</html>"""

users_file = 'data/users.json'

def has_users():
    return os.path.exists(users_file)

@_app.route('/')
def home():
    if not has_users():
        return redirect('/onboarding')
    return _html

@_app.route('/onboarding')
def onboarding():
    if has_users():
        return redirect('/')
    return _onboarding_html

@_app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    user = {
        'username': data.get('username'),
        'password': data.get('password'),
        'email': data.get('email')
    }
    with open(users_file, 'w') as f:
        json.dump([user], f, indent=2)
    return jsonify({'success': True})

def start(ip: str, port: int):
    """Starts a Flask HTTP server that shows an animated loading dots on root route."""
    os.makedirs('data', exist_ok=True)
    print(f"Starting Flask server on {ip}:{port}")
    _app.run(host=ip, port=port)