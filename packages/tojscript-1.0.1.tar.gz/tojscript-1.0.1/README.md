# TojScript 🇹🇯

Забони барномасозии тоҷикӣ / Язык программирования на таджикском

## Насб / Установка
```
pip install tojscript
```

## Истифода / Использование
```
toj main.py
toj main.toj
```

## Мисол / Пример (main.py)
```python
import tojscript
оғоз() {
a = бутун(ворид())
чоп(a)
}
```
