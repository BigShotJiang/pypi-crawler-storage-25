from setuptools import setup, find_packages

setup(
    name="tojscript",
    version="1.0.1",
    packages=find_packages(),
    install_requires=["colorama"],
    entry_points={
        "console_scripts": [
            "toj=tojscript:main",
        ],
    },
)
