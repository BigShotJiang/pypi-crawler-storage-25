#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Utility for reading mock service configuration headers from init.yaml.

The Go mock integrations server (rs-mock-integrations-go) accepts X-Mock-*
HTTP headers to control data generation at runtime.  This module reads
per-service header values from the ``mockServicesConfig`` section of
init.yaml, prepends the ``X-Mock-`` prefix, and returns them as a dict
suitable for injection into HTTP requests.

Example init.yaml::

    mockServicesConfig:
      crowdstrike:
        Incident-Count: 400
        Vuln-Count: 1000
        Seed: 42
      gcp:
        Finding-Count: 200

Usage::

    from regscale.core.app.utils.mock_service_headers import get_mock_service_headers

    headers = get_mock_service_headers("crowdstrike")
    # -> {"X-Mock-Incident-Count": "400", "X-Mock-Vuln-Count": "1000", "X-Mock-Seed": "42"}
"""

import logging
from typing import Dict

logger = logging.getLogger("regscale")


_HEADER_PREFIX = "X-Mock-"


def get_mock_service_headers(service_name: str) -> Dict[str, str]:
    """Return X-Mock-* headers for a mock service from init.yaml.

    Reads ``mockServicesConfig.<service_name>`` from the application
    config, prepends ``X-Mock-`` to each key, and returns the entries
    as a ``{header: value}`` dict with all values stringified.

    Keys that already start with ``X-Mock-`` are passed through unchanged.

    Returns an empty dict when:
    - ``mockServicesConfig`` is missing (production environments)
    - The requested *service_name* has no entry
    - The entry is not a dict

    :param str service_name: Mock service key (e.g. "crowdstrike", "gcp")
    :return: Header dict ready to merge into HTTP requests
    :rtype: Dict[str, str]
    """
    from regscale.core.app.application import Application

    app = Application()
    mock_config = app.config.get("mockServicesConfig")
    if not isinstance(mock_config, dict):
        return {}

    service_config = mock_config.get(service_name)
    if not isinstance(service_config, dict):
        return {}

    headers: Dict[str, str] = {}
    for key, value in service_config.items():
        header_name = str(key) if str(key).startswith(_HEADER_PREFIX) else f"{_HEADER_PREFIX}{key}"
        headers[header_name] = str(value)
    if headers:
        logger.debug("Mock headers for %s: %s", service_name, headers)
    return headers
