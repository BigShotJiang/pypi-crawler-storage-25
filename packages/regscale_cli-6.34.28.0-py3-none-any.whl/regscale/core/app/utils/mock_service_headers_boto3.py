#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Helper for injecting mock service X-Mock-* headers into boto3 clients."""

import logging

from regscale.core.app.utils.mock_service_headers import get_mock_service_headers

logger = logging.getLogger("regscale")


def apply_mock_headers_to_boto3_client(client, service_name: str) -> None:
    """Register a ``before-send`` hook on *client* that injects mock headers.

    :param client: boto3 client (e.g. ``boto3.client("s3")``)
    :param str service_name: Command-group key for init.yaml lookup
    """
    headers = get_mock_service_headers(service_name)
    if not headers:
        return

    def _inject_headers(request, **_kwargs):
        request.headers.update(headers)

    client.meta.events.register("before-send.*.*", _inject_headers)
    logger.debug("Registered boto3 mock header hook for %s", service_name)
