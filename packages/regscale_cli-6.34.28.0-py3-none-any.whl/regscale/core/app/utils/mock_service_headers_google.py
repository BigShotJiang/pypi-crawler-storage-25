#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Helpers for injecting mock service X-Mock-* headers into google clients."""

import logging
from typing import Any, Optional

from google.auth.credentials import Credentials

from regscale.core.app.utils.mock_service_headers import get_mock_service_headers

logger = logging.getLogger("regscale")


class _StaticTokenCredentials(Credentials):
    """Credentials that hold a static bearer token and never refresh.

    Used when targeting a mock or alternate non-Google endpoint that does not
    enforce real OAuth2 (e.g. ``rs-mock-integrations-go/gcp`` accepts any bearer
    token). The google-cloud SDK calls ``refresh()`` before every request, so
    ``AnonymousCredentials`` (which raises) cannot be used here.
    """

    def __init__(self, token: str) -> None:
        super().__init__()
        self.token = token

    def refresh(self, request) -> None:  # noqa: ARG002
        """No-op: token is static and treated as never-expiring."""
        return None


def build_google_discovery(api: str, version: str, command_group: str = "gcp", **kwargs):
    """Build a googleapiclient discovery service with optional X-Mock-* header injection.

    Production behavior (no ``mockServicesConfig.<command_group>``):
        Returns ``build(api, version, **kwargs)`` unchanged. Application Default
        Credentials are discovered by googleapiclient as normal. Byte-identical
        to a codebase without mock-header support.

    Mock behavior (``mockServicesConfig.<command_group>`` is configured):
        Builds an ``AuthorizedHttp`` from real ADC credentials, then wraps its
        ``request`` method to merge X-Mock-* headers into every outbound call.
        Authentication is preserved; mock headers ride on top.

    The caller never constructs an http object — that responsibility lives here
    so the production path cannot accidentally be made unauthenticated.

    :param str api: Discovery API name (e.g. "serviceusage", "sqladmin")
    :param str version: API version (e.g. "v1")
    :param str command_group: init.yaml mockServicesConfig key (default "gcp")
    :param kwargs: Forwarded to ``googleapiclient.discovery.build``
    """
    from googleapiclient.discovery import build

    mock_headers = get_mock_service_headers(command_group)
    if not mock_headers:
        return build(api, version, **kwargs)

    import google.auth
    from google_auth_httplib2 import AuthorizedHttp
    from googleapiclient.http import build_http

    creds, _ = google.auth.default()
    authed_http = AuthorizedHttp(creds, http=build_http())
    original_request = authed_http.request

    def patched_request(uri, method="GET", body=None, headers=None, *args, **request_kwargs):
        merged = {**(headers or {}), **mock_headers}
        return original_request(uri, method, body, merged, *args, **request_kwargs)

    authed_http.request = patched_request  # type: ignore[method-assign]
    logger.debug("Built google discovery %s/%s with mock headers for %s", api, version, command_group)
    return build(api, version, http=authed_http, **kwargs)


def build_google_rest_client(
    client_cls,
    service_name: str,
    api_endpoint: Optional[str] = None,
    **client_kwargs: Any,
):
    """Construct a google-cloud client with optional REST transport, mock headers, and endpoint override.

    Behavior:
    - If neither ``mockServicesConfig.<service_name>`` headers nor ``api_endpoint`` are set, the
      client is constructed with the caller-supplied kwargs unchanged (default transport, real GCP).
    - If ``api_endpoint`` is set, the client is constructed with ``transport="rest"`` and a
      ``ClientOptions(api_endpoint=...)`` so requests go to the override URL instead of the
      production Google endpoint. Anonymous credentials are used when no real credentials were
      passed via ``client_kwargs``.
    - If ``mockServicesConfig.<service_name>`` headers are present, REST transport is forced and
      the underlying session is wrapped with the configured X-Mock-* headers.

    Both behaviors compose: a mock URL with mock-count headers is the typical mock-server setup.

    :param client_cls: google-cloud client class (e.g. ``securitycenter.SecurityCenterClient``)
    :param str service_name: Command-group key for init.yaml header lookup
    :param Optional[str] api_endpoint: Override URL for the API endpoint (e.g. ``http://localhost:8453``)
    :param client_kwargs: Passed through to the client constructor
    """
    mock_headers = get_mock_service_headers(service_name)

    # Fast path: no mock config and no endpoint override - real GCP, default transport.
    if not mock_headers and not api_endpoint:
        return client_cls(**client_kwargs)

    # Either mock headers or endpoint override is set; force REST transport in both cases.
    client_kwargs.setdefault("transport", "rest")

    if api_endpoint:
        from google.api_core.client_options import ClientOptions

        existing_options = client_kwargs.get("client_options")
        if existing_options is None:
            client_kwargs["client_options"] = ClientOptions(api_endpoint=api_endpoint)
        elif isinstance(existing_options, ClientOptions):
            existing_options.api_endpoint = api_endpoint
        elif isinstance(existing_options, dict):
            existing_options.setdefault("api_endpoint", api_endpoint)
        # When pointing at a non-Google endpoint, real credentials are not appropriate.
        # AnonymousCredentials raises on refresh(), which the REST transport calls before
        # every request, so use a static-token credential that never refreshes.
        if "credentials" not in client_kwargs:
            client_kwargs["credentials"] = _StaticTokenCredentials("mock-oauth2-bearer-token")
        logger.info("Using GCP API endpoint override for %s: %s", service_name, api_endpoint)

    client = client_cls(**client_kwargs)

    if mock_headers:
        transport = getattr(client, "transport", None) or getattr(client, "_transport", None)
        session = getattr(transport, "_session", None)
        if session is not None and hasattr(session, "headers"):
            session.headers.update(mock_headers)
            logger.debug("Injected mock headers into google REST transport for %s", service_name)
        else:
            logger.warning(
                "Could not locate REST transport session for %s — mock headers NOT injected",
                service_name,
            )

    return client
