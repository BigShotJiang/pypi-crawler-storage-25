"""
Description: A class to handle reading and writing data to a pickle file in a thread-safe manner.
"""

import logging
import pickle
import threading
from os import PathLike
from pathlib import Path
from pickle import UnpicklingError
from typing import Any, Generator

logger = logging.getLogger(__name__)


class PickleFileHandler:
    """
    A class to handle reading and writing data to a pickle file in a thread-safe manner.

    :param PathLike[str] file_path: The path to the pickle file.
    """

    def __init__(self, file_path: PathLike[str]):
        self.file_path: Path = Path(file_path)
        self.lock = threading.Lock()

    def write(self, data: Any):
        """
        Writes data to the pickle file in a thread-safe manner.

        :param Any data: The data to be pickled and written to the file.
        """
        with self.lock:
            with open(self.file_path, "wb") as file:
                pickle.dump(data, file)

    def write_chunked(self, data: Any) -> None:
        """
        Write data to pickle file in chunked format for memory-efficient reading.

        If data is a list, each item is pickled individually so that read_chunked()
        can yield one item at a time without loading the full list into memory.

        :param Any data: The data to write. Lists are chunked; other types written as-is.
        """
        with self.lock:
            with open(self.file_path, "wb") as file:
                if isinstance(data, list):
                    for item in data:
                        pickle.dump(item, file)
                else:
                    pickle.dump(data, file)

    def read_chunked(self) -> Generator[Any, None, None]:
        """
        Read chunked pickle data, yielding one item at a time.

        Reads individual pickled objects written by write_chunked().
        Each object is loaded independently, keeping memory usage proportional
        to a single item rather than the entire file.

        :returns: Generator yielding individual items
        :yields: Any -- Individual items from the pickle file
        """
        with open(self.file_path, "rb") as file:
            while True:
                try:
                    yield pickle.load(file)
                except EOFError:
                    break
                except UnpicklingError as e:
                    logger.debug("Error reading chunked pickle item: %s", e)
                    break

    def read(self) -> Generator[Any, None, None]:
        """
        Reads data from the pickle file in a thread-safe manner and returns a generator.

        :returns: A generator yielding the data read from the pickle file.
        :yields: Any -- The data read from the pickle file.
        """
        with open(self.file_path, "rb") as file:
            data = None
            try:
                data = pickle.load(file)
            except EOFError:
                pass
            except UnpicklingError as e:
                logger.debug("Error reading pickle file: %s", e)
            if data:
                if isinstance(data, list):
                    yield from data
                else:
                    yield data
