"""
gRPC client for the RegScale Asset Ingestion service.

Provides a high-level client that wraps the generated AssetIngestionServiceStub
with connection management, authentication, and logging.

Usage::

    from regscale.core.grpc import AssetIngestionClient
    from rs_data.v1.asset_pb2 import AssetBase, AssetUpsert

    with AssetIngestionClient(target="ingest.regscale.internal:443") as client:
        assets = [
            AssetUpsert(
                source="MyScanner",
                base=AssetBase(name="server-01", ip_address="10.0.0.1"),
            )
        ]
        response = client.batch_create_or_update(assets=assets, source="MyScanner")
        print(f"Created: {len(response.created)}, Updated: {len(response.updated)}")
"""

from __future__ import annotations

import logging
import uuid
from typing import TYPE_CHECKING, Iterator, Optional, Sequence

import grpc

if TYPE_CHECKING:
    from rs_data.v1.asset_pb2 import (
        AssetUpsert,
        BatchCreateOrUpdateAssetsResponse,
        BatchCreateOrUpdateOptions,
        StreamBatchCreateOrUpdateAssetsResponse,
    )
    from rs_data.v1.asset_service_pb2_grpc import AssetIngestionServiceStub

logger = logging.getLogger("regscale")

# Default timeout for unary RPCs (seconds).
DEFAULT_TIMEOUT_SECONDS = 300

# Default batch size for server-side chunking.
DEFAULT_BATCH_SIZE = 500

# Maximum message size: 50 MB (protobuf default is 4 MB).
MAX_MESSAGE_SIZE = 50 * 1024 * 1024


def _build_channel_options() -> list[tuple[str, int]]:
    """Build gRPC channel options with sensible defaults for large payloads."""
    return [
        ("grpc.max_send_message_length", MAX_MESSAGE_SIZE),
        ("grpc.max_receive_message_length", MAX_MESSAGE_SIZE),
    ]


class AssetIngestionClient:
    """High-level gRPC client for the RegScale Asset Ingestion service.

    Supports both secure (TLS) and insecure channels, optional Bearer-token
    authentication, and context-manager usage for clean resource management.

    :param str target: gRPC server address (host:port).
    :param bool insecure: Use an insecure (plaintext) channel. Defaults to False.
    :param Optional[str] token: Bearer token for call-level authentication.
    :param Optional[grpc.ChannelCredentials] channel_credentials: Custom TLS credentials.
        When *None* and *insecure* is False, default SSL credentials are used.
    :param int timeout: Default timeout in seconds for unary RPCs.
    """

    def __init__(
        self,
        target: str,
        *,
        insecure: bool = False,
        token: Optional[str] = None,  # SECURITY: Do not log or expose in error messages
        channel_credentials: Optional[grpc.ChannelCredentials] = None,
        timeout: int = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self._target = target
        self._insecure = insecure
        self._token = token
        self._timeout = timeout
        self._channel: Optional[grpc.Channel] = None
        self._stub: Optional[AssetIngestionServiceStub] = None

        options = _build_channel_options()

        if insecure:
            self._channel = grpc.insecure_channel(target, options=options)
        else:
            creds = channel_credentials or grpc.ssl_channel_credentials()
            if token:
                call_creds = grpc.access_token_call_credentials(token)
                creds = grpc.composite_channel_credentials(creds, call_creds)
            self._channel = grpc.secure_channel(target, creds, options=options)

        # Secure channels embed the token via composite channel credentials above.
        # Insecure channels have no credential mechanism, so inject the token as
        # per-call metadata instead.
        self._call_metadata: list[tuple[str, str]] = (
            [("authorization", f"Bearer {token}")] if insecure and token else []
        )

        from rs_data.v1.asset_service_pb2_grpc import AssetIngestionServiceStub

        self._stub = AssetIngestionServiceStub(self._channel)
        logger.debug("gRPC channel opened to %s (insecure=%s)", target, insecure)

    # -- Context manager --------------------------------------------------

    def __enter__(self) -> "AssetIngestionClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        self.close()
        return False

    def close(self) -> None:
        """Close the underlying gRPC channel."""
        if self._channel is not None:
            self._channel.close()
            self._channel = None
            self._stub = None
            logger.debug("gRPC channel to %s closed", self._target)

    # -- Public API -------------------------------------------------------

    def batch_create_or_update(
        self,
        assets: Sequence[AssetUpsert],
        *,
        source: str,
        unique_key_fields: Optional[Sequence[str]] = None,
        enable_mop_up: bool = False,
        mop_up_status: str = "Off-Network",
        batch_size: int = DEFAULT_BATCH_SIZE,
        batch_import_uuid: Optional[str] = None,
        parent_id: Optional[int] = None,
        parent_module: str = "",
        timeout: Optional[int] = None,
    ) -> BatchCreateOrUpdateAssetsResponse:
        """Batch create-or-update assets in a single blocking call.

        :param Sequence[AssetUpsert] assets: Assets to upsert.
        :param str source: Source system identifier (e.g. "Tenable", "Qualys").
        :param Optional[Sequence[str]] unique_key_fields: Fields for dedup composite key.
        :param bool enable_mop_up: Mark absent records with *mop_up_status*.
        :param str mop_up_status: Status for absent records. Defaults to "Off-Network".
        :param int batch_size: Server-side chunk size. Defaults to 500.
        :param Optional[str] batch_import_uuid: Session UUID for this batch.
        :param Optional[int] parent_id: Parent record ID for RBAC.
        :param str parent_module: Parent module name (e.g. "security_plans").
        :param Optional[int] timeout: RPC timeout in seconds. Falls back to instance default.
        :return: Combined response with created/updated assets and statistics.
        :rtype: BatchCreateOrUpdateAssetsResponse
        """
        from rs_data.v1.asset_pb2 import BatchCreateOrUpdateAssetsRequest

        options = self._build_options(
            source=source,
            unique_key_fields=unique_key_fields,
            enable_mop_up=enable_mop_up,
            mop_up_status=mop_up_status,
            batch_size=batch_size,
            batch_import_uuid=batch_import_uuid,
            parent_id=parent_id,
            parent_module=parent_module,
        )
        request = BatchCreateOrUpdateAssetsRequest(assets=assets, options=options)

        rpc_timeout = timeout or self._timeout
        logger.info(
            "BatchCreateOrUpdateAssets: sending %d assets (source=%s, timeout=%ds)",
            len(assets),
            source,
            rpc_timeout,
        )

        response: BatchCreateOrUpdateAssetsResponse = self._stub.BatchCreateOrUpdateAssets(
            request,
            timeout=rpc_timeout,
            metadata=self._call_metadata or None,
        )

        logger.info(
            "BatchCreateOrUpdateAssets: created=%d updated=%d total=%d success=%s (%dms)",
            len(response.created),
            len(response.updated),
            response.total_processed,
            response.is_successful,
            response.processing_time_ms,
        )
        if not response.is_successful:
            logger.error("BatchCreateOrUpdateAssets failed: %s", response.error_message)

        return response

    def stream_batch_create_or_update(
        self,
        assets: Sequence[AssetUpsert],
        *,
        source: str,
        unique_key_fields: Optional[Sequence[str]] = None,
        enable_mop_up: bool = False,
        mop_up_status: str = "Off-Network",
        batch_size: int = DEFAULT_BATCH_SIZE,
        batch_import_uuid: Optional[str] = None,
        parent_id: Optional[int] = None,
        parent_module: str = "",
        timeout: Optional[int] = None,
    ) -> Iterator[StreamBatchCreateOrUpdateAssetsResponse]:
        """Batch create-or-update assets with server-side streaming progress.

        Yields one response per server-side processing chunk, allowing the caller
        to observe progress without waiting for the full batch to complete.

        :param Sequence[AssetUpsert] assets: Assets to upsert.
        :param str source: Source system identifier.
        :param Optional[Sequence[str]] unique_key_fields: Fields for dedup composite key.
        :param bool enable_mop_up: Mark absent records with *mop_up_status*.
        :param str mop_up_status: Status for absent records. Defaults to "Off-Network".
        :param int batch_size: Server-side chunk size. Defaults to 500.
        :param Optional[str] batch_import_uuid: Session UUID for this batch.
        :param Optional[int] parent_id: Parent record ID for RBAC.
        :param str parent_module: Parent module name (e.g. "security_plans").
        :param Optional[int] timeout: RPC timeout in seconds. Falls back to instance default.
            For large batches, recommend at least ``(len(assets) / batch_size) * 5`` seconds.
            Example: 10,000 assets with batch_size=500 needs roughly 100 seconds minimum.
        :yields: StreamBatchCreateOrUpdateAssetsResponse chunks.
        """
        from rs_data.v1.asset_pb2 import StreamBatchCreateOrUpdateAssetsRequest

        options = self._build_options(
            source=source,
            unique_key_fields=unique_key_fields,
            enable_mop_up=enable_mop_up,
            mop_up_status=mop_up_status,
            batch_size=batch_size,
            batch_import_uuid=batch_import_uuid,
            parent_id=parent_id,
            parent_module=parent_module,
        )
        request = StreamBatchCreateOrUpdateAssetsRequest(assets=assets, options=options)

        rpc_timeout = timeout or self._timeout
        logger.info(
            "StreamBatchCreateOrUpdateAssets: sending %d assets (source=%s, timeout=%ds)",
            len(assets),
            source,
            rpc_timeout,
        )

        for chunk in self._stub.StreamBatchCreateOrUpdateAssets(
            request,
            timeout=rpc_timeout,
            metadata=self._call_metadata or None,
        ):
            logger.debug(
                "Chunk %d: processed=%d ok=%d err=%d (%dms)",
                chunk.chunk_number,
                chunk.processed_count,
                chunk.success_count,
                chunk.error_count,
                chunk.processing_time_ms,
            )
            for error in chunk.errors:
                logger.warning(
                    "Chunk %d item %d error: %s",
                    chunk.chunk_number,
                    error.item_index,
                    error.error_message,
                )
            yield chunk

    # -- Helpers ----------------------------------------------------------

    @staticmethod
    def _build_options(
        *,
        source: str,
        unique_key_fields: Optional[Sequence[str]],
        enable_mop_up: bool,
        mop_up_status: str,
        batch_size: int,
        batch_import_uuid: Optional[str],
        parent_id: Optional[int],
        parent_module: str,
    ) -> BatchCreateOrUpdateOptions:
        """Construct a BatchCreateOrUpdateOptions message."""
        from rs_data.v1.asset_pb2 import BatchCreateOrUpdateOptions

        opts = BatchCreateOrUpdateOptions(
            source=source,
            batch_import_uuid=batch_import_uuid or str(uuid.uuid4()),
            enable_mop_up=enable_mop_up,
            mop_up_status=mop_up_status,
            batch_size=batch_size,
            parent_module=parent_module,
        )
        if unique_key_fields:
            opts.unique_key_fields.extend(unique_key_fields)
        if parent_id is not None:
            opts.parent_id = parent_id
        return opts
