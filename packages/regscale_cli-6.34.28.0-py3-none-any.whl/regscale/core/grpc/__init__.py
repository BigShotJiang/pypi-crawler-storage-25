"""
RegScale gRPC client package.

Provides gRPC client functionality for communicating with RegScale's
Asset Ingestion gRPC microservice (rs-data).

Proto message classes are imported directly from the ``rs-data`` package::

    from rs_data.v1 import asset_pb2, asset_service_pb2_grpc
"""

from regscale.core.grpc.client import AssetIngestionClient

__all__ = ["AssetIngestionClient"]
