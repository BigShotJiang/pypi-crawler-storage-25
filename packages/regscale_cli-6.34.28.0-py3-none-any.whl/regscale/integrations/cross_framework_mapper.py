#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Cross-framework control mapping utility.

Maps control IDs between compliance frameworks (e.g., NIST -> SOC2)
using known public crosswalk data shipped with the package.
"""

import json
import logging
from importlib.resources import open_text
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("regscale")


class CrossFrameworkMapper:
    """Maps control IDs between compliance frameworks using known crosswalks.

    Usage:
        mapper = CrossFrameworkMapper()
        soc2_controls = mapper.map_controls("NIST", "SOC2", ["AC-1", "AC-2"])
        # Returns: {"AC-1": ["CC1.1", "CC1.2"], "AC-2": ["CC6.1", "CC6.2"]}
    """

    # Crosswalk files shipped with the package
    _CROSSWALK_FILES = {
        ("NIST", "CSF"): "nist_to_csf",
        ("NIST", "SOC2"): "nist_to_soc2",
        ("NIST", "CMMC"): "nist_to_cmmc",
        ("NIST", "ISO"): "nist_to_iso27001",
        ("NIST", "CIS"): "nist_to_cis",
    }

    # Required top-level keys for crosswalk JSON files
    _REQUIRED_KEYS = {"mappings"}
    _REQUIRED_CUSTOM_KEYS = {"source_framework", "target_framework", "mappings"}

    def __init__(self, custom_crosswalk_dir: Optional[str] = None) -> None:
        """Load built-in crosswalks, optionally overlay custom ones.

        :param Optional[str] custom_crosswalk_dir: Path to directory with custom crosswalk JSON files
        """
        self._crosswalks: Dict[Tuple[str, str], Dict[str, List[str]]] = {}
        # Pre-computed upper-case index for O(1) case-insensitive lookups
        self._upper_index: Dict[Tuple[str, str], Dict[str, str]] = {}
        self._custom_dir = custom_crosswalk_dir
        self._load_builtin_crosswalks()
        if custom_crosswalk_dir:
            self._load_custom_crosswalks(custom_crosswalk_dir)

    def _build_upper_index(self, key: Tuple[str, str], mappings: Dict[str, List[str]]) -> None:
        """Build upper-case key index for O(1) case-insensitive lookups.

        :param Tuple[str, str] key: (source, target) framework pair
        :param Dict[str, List[str]] mappings: The crosswalk mappings
        """
        self._upper_index[key] = {k.upper(): k for k in mappings}

    @staticmethod
    def _validate_crosswalk_structure(data: dict, required_keys: set, label: str) -> Optional[str]:
        """Validate that crosswalk JSON has required keys and correct types.

        :param dict data: Parsed JSON data
        :param set required_keys: Keys that must be present
        :param str label: Label for error messages
        :return: Error message if invalid, None if valid
        :rtype: Optional[str]
        """
        if not isinstance(data, dict):
            return "%s: expected a JSON object, got %s" % (label, type(data).__name__)

        missing = required_keys - set(data.keys())
        if missing:
            return "%s: missing required keys: %s" % (label, ", ".join(sorted(missing)))

        mappings = data.get("mappings")
        if not isinstance(mappings, dict):
            return "%s: 'mappings' must be a dict, got %s" % (label, type(mappings).__name__)

        return None

    def _load_builtin_crosswalks(self) -> None:
        """Load all built-in crosswalk JSON files from package resources."""
        for (source, target), filename in self._CROSSWALK_FILES.items():
            try:
                with open_text("regscale.integrations.commercial.mappings.crosswalks", f"{filename}.json") as f:
                    data = json.load(f)

                error = self._validate_crosswalk_structure(data, self._REQUIRED_KEYS, filename)
                if error:
                    logger.warning("Skipping crosswalk %s -> %s: %s", source, target, error)
                    continue

                mappings = data["mappings"]
                if mappings:
                    self._crosswalks[(source, target)] = mappings
                    self._build_upper_index((source, target), mappings)
                    # Auto-generate reverse mapping
                    reverse = self._reverse_mapping(mappings)
                    if reverse:
                        self._crosswalks[(target, source)] = reverse
                        self._build_upper_index((target, source), reverse)

                    logger.debug(
                        "Loaded crosswalk %s -> %s with %d mappings",
                        source,
                        target,
                        len(mappings),
                    )
            except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
                logger.debug("Could not load crosswalk %s -> %s: %s", source, target, e)

    def _load_custom_crosswalks(self, directory: str) -> None:
        """Load custom crosswalk files from a directory.

        :param str directory: Path to directory with custom crosswalk JSON files
        """
        import os

        if not os.path.isdir(directory):
            logger.warning("Custom crosswalk directory not found: %s", directory)
            return

        for filename in os.listdir(directory):
            if not filename.endswith(".json"):
                continue
            filepath = os.path.join(directory, filename)
            try:
                with open(filepath) as f:
                    data = json.load(f)

                error = self._validate_crosswalk_structure(data, self._REQUIRED_CUSTOM_KEYS, filename)
                if error:
                    logger.warning("Skipping custom crosswalk %s: %s", filename, error)
                    continue

                source = data["source_framework"]
                target = data["target_framework"]
                mappings = data["mappings"]

                if source and target and mappings:
                    self._crosswalks[(source, target)] = mappings
                    self._build_upper_index((source, target), mappings)
                    reverse = self._reverse_mapping(mappings)
                    if reverse:
                        self._crosswalks[(target, source)] = reverse
                        self._build_upper_index((target, source), reverse)
                    logger.debug("Loaded custom crosswalk %s -> %s from %s", source, target, filename)
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning("Failed to load custom crosswalk %s: %s", filename, e)

    @staticmethod
    def _reverse_mapping(mappings: Dict[str, List[str]]) -> Dict[str, List[str]]:
        """Reverse a mapping dict (source->targets becomes target->sources).

        :param Dict[str, List[str]] mappings: Forward mapping
        :return: Reversed mapping
        :rtype: Dict[str, List[str]]
        """
        reverse: Dict[str, List[str]] = {}
        for source_id, target_ids in mappings.items():
            for target_id in target_ids:
                reverse.setdefault(target_id, []).append(source_id)
        return reverse

    def map_controls(
        self,
        source_framework: str,
        target_framework: str,
        control_ids: List[str],
    ) -> Dict[str, List[str]]:
        """Map a list of control IDs from source to target framework.

        :param str source_framework: Source framework name (e.g., "NIST")
        :param str target_framework: Target framework name (e.g., "SOC2")
        :param List[str] control_ids: Control IDs to map
        :return: Dict mapping each source control to list of target controls
        :rtype: Dict[str, List[str]]
        """
        crosswalk = self._crosswalks.get((source_framework, target_framework))
        if not crosswalk:
            logger.debug("No crosswalk available for %s -> %s", source_framework, target_framework)
            return {}

        upper_index = self._upper_index.get((source_framework, target_framework), {})

        result: Dict[str, List[str]] = {}
        for control_id in control_ids:
            # Try exact match first
            targets = crosswalk.get(control_id)
            if targets:
                result[control_id] = targets
                continue

            # O(1) case-insensitive lookup via pre-computed index
            canonical_key = upper_index.get(control_id.upper())
            if canonical_key:
                result[control_id] = crosswalk[canonical_key]

        return result

    def get_available_crosswalks(self) -> List[Tuple[str, str]]:
        """Return list of (source, target) framework pairs with data.

        :return: Available crosswalk pairs
        :rtype: List[Tuple[str, str]]
        """
        return list(self._crosswalks.keys())

    def has_crosswalk(self, source: str, target: str) -> bool:
        """Check if a crosswalk exists between two frameworks.

        :param str source: Source framework
        :param str target: Target framework
        :return: True if crosswalk data exists
        :rtype: bool
        """
        return (source, target) in self._crosswalks
