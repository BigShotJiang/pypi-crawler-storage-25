"""
Azure Container Registry (ACR) Scanner Integration

Pulls container images/repositories from ACR registries and syncs them
as software assets in RegScale.
"""

import logging
from typing import Iterator, Optional

from regscale.integrations.commercial.microsoft_defender.defender_api import DefenderApi
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
)
from regscale.models import IssueSeverity
from regscale.utils.string import generate_html_table_from_dict

logger = logging.getLogger("regscale")

ACR_RESOURCE_TYPE = "microsoft.containerregistry/registries/images"


class ACRContainerScanner(ScannerIntegration):
    title = "Azure Container Registry"
    asset_identifier_field = "otherTrackingNumber"
    finding_severity_map = {
        "Critical": IssueSeverity.Critical,
        "High": IssueSeverity.High,
        "Medium": IssueSeverity.Moderate,
        "Low": IssueSeverity.Low,
    }

    def __init__(self, *args, **kwargs):
        self.acr_name: Optional[str] = kwargs.pop("acr_name", None)
        self.system = kwargs.pop("system", "cloud")
        super().__init__(*args, **kwargs)
        self.api = DefenderApi(system=self.system)

    def fetch_assets(self, *args, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Fetches container images from ACR registries and yields IntegrationAssets.

        :yields: Iterator[IntegrationAsset]
        """
        registries = self.api.list_acr_registries(acr_name=self.acr_name)
        total_images = 0

        for registry in registries:
            registry_name = registry.get("name", "")
            properties = registry.get("properties", {})
            login_server = properties.get("loginServer", "")
            registry_id = registry.get("id", "")

            if not login_server:
                logger.warning("Skipping registry %s: no loginServer found.", registry_name)
                continue

            logger.info("Processing ACR registry: %s (%s)", registry_name, login_server)

            try:
                acr_token = self.api.get_acr_access_token(login_server)
            except (Exception, SystemExit) as exc:
                logger.error("Failed to authenticate to ACR %s: %s", login_server, exc)
                continue

            try:
                repositories = self.api.list_acr_repositories(login_server, acr_token)
            except (Exception, SystemExit) as exc:
                logger.error("Failed to list repositories in %s: %s", login_server, exc)
                continue

            for repo in repositories:
                try:
                    tags = self.api.list_acr_tags(login_server, repo, acr_token)
                except (Exception, SystemExit) as exc:
                    logger.error("Failed to list tags for %s/%s: %s", login_server, repo, exc)
                    continue

                if not tags:
                    logger.info("No tags found for %s/%s, skipping.", login_server, repo)
                    continue

                for tag_info in tags:
                    total_images += 1
                    yield self.parse_asset(
                        tag_info=tag_info,
                        repository=repo,
                        registry_name=registry_name,
                        login_server=login_server,
                        registry_id=registry_id,
                    )

        self.num_assets_to_process = total_images
        logger.info(
            "Discovered %d container image(s) across %d registr%s.",
            total_images,
            len(registries),
            "y" if len(registries) == 1 else "ies",
        )

    def fetch_findings(self, *args, **kwargs) -> Iterator[IntegrationFinding]:
        """
        Not implemented for ACR container sync (no findings to fetch).

        :yields: Iterator[IntegrationFinding]
        """
        return iter([])

    def parse_asset(
        self,
        tag_info: dict,
        repository: str,
        registry_name: str,
        login_server: str,
        registry_id: str,
    ) -> IntegrationAsset:
        """
        Map an ACR container image tag to an IntegrationAsset.

        :param dict tag_info: Tag metadata from the ACR tags API
        :param str repository: Repository name (e.g. "myapp/backend")
        :param str registry_name: The ACR registry name (e.g. "myregistry")
        :param str login_server: The ACR login server (e.g. "myregistry.azurecr.io")
        :param str registry_id: The ARM resource ID of the registry
        :return: IntegrationAsset for the container image
        :rtype: IntegrationAsset
        """
        tag_name = tag_info.get("name", "latest") if isinstance(tag_info, dict) else str(tag_info)
        digest = tag_info.get("digest", "") if isinstance(tag_info, dict) else ""
        created_time = tag_info.get("createdTime", "") if isinstance(tag_info, dict) else ""
        last_update_time = tag_info.get("lastUpdateTime", "") if isinstance(tag_info, dict) else ""

        image_ref = f"{login_server}/{repository}:{tag_name}"
        asset_id = f"{registry_id}/repositories/{repository}/tags/{tag_name}"

        source_data = {
            "registryName": registry_name,
            "loginServer": login_server,
            "registryId": registry_id,
            "repository": repository,
            "tag": tag_name,
            "digest": digest,
            "createdTime": created_time,
            "lastUpdateTime": last_update_time,
            "imageReference": image_ref,
        }
        if isinstance(tag_info, dict):
            source_data.update(
                {k: v for k, v in tag_info.items() if k not in ("name", "digest", "createdTime", "lastUpdateTime")}
            )

        description = generate_html_table_from_dict(source_data)

        from regscale.models import regscale_models

        return IntegrationAsset(
            name=image_ref,
            description=description,
            other_tracking_number=asset_id,
            azure_identifier=asset_id,
            external_id=asset_id,
            identifier=asset_id,
            asset_type=regscale_models.AssetType.Other,
            asset_category=regscale_models.AssetCategory.Software,
            parent_id=self.plan_id,
            parent_module=(
                regscale_models.Component.get_module_slug()
                if self.is_component
                else regscale_models.SecurityPlan.get_module_slug()
            ),
            status=regscale_models.AssetStatus.Active,
            software_name=repository,
            software_version=tag_name,
            software_function=f"Container image hosted in ACR registry {registry_name}",
            fqdn=login_server,
            is_virtual=True,
            is_public_facing=False,
            baseline_configuration="Azure Hardening Guide",
            component_names=[ACR_RESOURCE_TYPE],
            source_data=source_data,
        )
