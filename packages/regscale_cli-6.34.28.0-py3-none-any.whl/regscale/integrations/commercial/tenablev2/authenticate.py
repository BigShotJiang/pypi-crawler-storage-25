from typing import TYPE_CHECKING

from regscale import __version__
from regscale.core.app.utils.mock_service_headers import get_mock_service_headers
from regscale.integrations.commercial.tenablev2.constants import REGSCALE_CLI, REGSCALE_INC
from regscale.integrations.commercial.tenablev2.variables import TenableVariables
from regscale.integrations.variables import ScannerVariables

# Delay import of Tenable libraries
if TYPE_CHECKING:
    from tenable.io import TenableIO
    from tenable.sc import TenableSC


def _apply_mock_headers(client: object, service_name: str) -> None:
    """Inject X-Mock-* headers onto the underlying pytenable requests.Session.

    pytenable's ``TenableIO``/``TenableSC`` inherit from ``restfly.APISession``
    which holds a ``requests.Session`` at ``_session`` (also exposed as
    ``session``). This helper is a no-op when the service has no
    ``mockServicesConfig`` entry (production path).
    """
    mock_headers = get_mock_service_headers(service_name)
    if not mock_headers:
        return
    sess = getattr(client, "_session", None) or getattr(client, "session", None)
    if sess is not None and hasattr(sess, "headers"):
        sess.headers.update(mock_headers)


def gen_tio() -> "TenableIO":
    """
    Generate Tenable IO Object

    :return: Tenable IO client
    :rtype: "TenableIO"
    """

    from tenable.io import TenableIO

    client = TenableIO(
        url=TenableVariables.tenableUrl.rstrip("/"),
        access_key=TenableVariables.tenableAccessKey,
        secret_key=TenableVariables.tenableSecretKey,
        vendor=REGSCALE_INC,
        product=REGSCALE_CLI,
        build=__version__,
    )
    _apply_mock_headers(client, "tenable_io")
    return client


def gen_tsc() -> "TenableSC":
    """
    Generate Tenable SC Object

    Prefers SC-specific credentials (tenableScAccessKey, tenableScSecretKey, tenableScUrl)
    and falls back to the shared Tenable IO credentials if SC-specific ones are not configured.

    :return: Tenable SC client
    :rtype: "TenableSC"
    """

    from tenable.sc import TenableSC

    url = TenableVariables.tenableScUrl or TenableVariables.tenableUrl
    access_key = TenableVariables.tenableScAccessKey or TenableVariables.tenableAccessKey
    secret_key = TenableVariables.tenableScSecretKey or TenableVariables.tenableSecretKey

    client = TenableSC(
        url=url.rstrip("/"),
        access_key=access_key,
        secret_key=secret_key,
        vendor=REGSCALE_INC,
        product=REGSCALE_CLI,
        build=__version__,
        ssl_verify=ScannerVariables.sslVerify,
    )
    _apply_mock_headers(client, "tenable_sc")
    return client
