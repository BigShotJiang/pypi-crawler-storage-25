"""
Shared constants for the Tenable V2 integration.
"""

from regscale.models import regscale_models

REGSCALE_INC = "RegScale, Inc."
REGSCALE_CLI = "RegScale CLI"
FULLY_IMPLEMENTED = "Fully Implemented"
NOT_IMPLEMENTED = "Not Implemented"
IN_REMEDIATION = "In Remediation"
ARTIFACTS_DIR = "./artifacts"
TENABLE_SC_CATEGORY = "Tenable SC Vulnerability"

# Shared severity map for Tenable.io integrations (lowercase keys)
TENABLE_IO_SEVERITY_MAP = {
    "critical": regscale_models.IssueSeverity.Critical,
    "high": regscale_models.IssueSeverity.High,
    "medium": regscale_models.IssueSeverity.Moderate,
    "low": regscale_models.IssueSeverity.Low,
}

# Shared checklist status map for CIS integrations
CIS_CHECKLIST_STATUS_MAP = {
    "PASSED": regscale_models.ChecklistStatus.PASS,
    "FAILED": regscale_models.ChecklistStatus.FAIL,
    "WARNING": regscale_models.ChecklistStatus.NOT_REVIEWED,
    "ERROR": regscale_models.ChecklistStatus.FAIL,
    "NOT_APPLICABLE": regscale_models.ChecklistStatus.NOT_APPLICABLE,
}
